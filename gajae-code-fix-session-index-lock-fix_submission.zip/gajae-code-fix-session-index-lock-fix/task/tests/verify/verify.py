"""Behavioral verifier for the session-index lock-contention fix (#4544).

The repo under test is a Bun workspace: `packages/coding-agent` runs its suite
with `bun test`, and the behavioral test file (lock_contention.test.ts, next to
this file) uses `bun:test` APIs (vi.spyOn on module namespaces, Bun.sleep). The
in-tree JS runner only speaks jest/vitest JSON, so this verifier shells out to
`bun test` directly and re-exposes each behavioral case as its own pytest test
so the grader records per-case pass/fail.

This module imports NO repository code — it only drives the `bun` binary as a
subprocess — so it runs under the shared verifier interpreter (VERIFIER_PYTHON)
with no interpreter override needed. The behavioral file is copied into the
package's own `test/` directory at run time so its `../src/...` relative imports
resolve against the edited source, then removed in teardown.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

REPO_DIR = Path(os.environ.get("REPO_DIR", "/repo/gajae-code"))
PACKAGE_DIR = REPO_DIR / "packages" / "coding-agent"
TEST_DIR = PACKAGE_DIR / "test"

# The behavioral file ships alongside this verifier; it is copied under a
# namespaced basename so a repo file is never shadowed or left behind.
_SRC_TEST = Path(__file__).with_name("lock_contention.test.ts")
_STAGED_BASENAME = "zz_ssb_lock_contention.verify.test.ts"

_BUN = shutil.which("bun") or "/usr/local/bin/bun"
_BUN_TIMEOUT_SEC = 480
_JUNIT_OUT = Path(os.environ.get("VERIFIER_LOGS_DIR", "/logs/verifier")) / "bun_lock_contention.xml"

# Each behavioral case the bun file defines, keyed by a stable substring of its
# `it(...)` title, mapped to the human aspect it gates. The verifier asserts
# every one of these ran and passed; a case that never appears in bun's report
# is treated as a failure (the file did not load / a case was renamed away).
_CASES: dict[str, str] = {
    "append path's OS incarnation": "no OS probe under the lock on the append path",
    "heartbeat checkpoint's OS probes": "no OS probe under the lock on the heartbeat path",
    "conditional-unregister pass's OS probes": "no OS probe under the lock on the unregister path",
    "no longer fresh by the time the lock holds it": "heartbeat checkpoint fails closed on a stale observation batch",
    "wall clock steps backward but monotonic time has advanced": "freshness bound is monotonic, not wall-clock",
    "names the holding process when a launch exhausts": "exhaustion error names the same-host holder",
    "foreign-host lock owner without mislabeling": "exhaustion error reports a foreign-host owner without mislabeling a local pid",
    "releases the lock when a critical section throws": "stale-lock safety: throw releases, abort fails fast",
    "bounds concurrent launches behind a legitimate holder": "concurrent launches converge to a consistent index",
}

# Populated once by _bun_results(): title-substring -> (passed, detail).
_RESULTS_CACHE: dict[str, tuple[bool, str]] | None = None


def _run_bun() -> tuple[int, str]:
    """Stage the behavioral file into the package and run `bun test` on it once.

    Returns the process exit code and combined output. The JUnit report is
    written to a logs path the grader already collects.
    """
    staged = TEST_DIR / _STAGED_BASENAME
    _JUNIT_OUT.parent.mkdir(parents=True, exist_ok=True)
    TEST_DIR.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(_SRC_TEST, staged)
    try:
        proc = subprocess.run(
            [
                _BUN,
                "test",
                str(staged.relative_to(PACKAGE_DIR)),
                "--reporter=junit",
                f"--reporter-outfile={_JUNIT_OUT}",
            ],
            capture_output=True,
            text=True,
            timeout=_BUN_TIMEOUT_SEC,
            cwd=str(PACKAGE_DIR),
            check=False,
        )
        return proc.returncode, (proc.stdout or "") + (proc.stderr or "")
    finally:
        try:
            staged.unlink()
        except OSError:
            pass


def _parse_junit() -> dict[str, tuple[bool, str]]:
    """Map each testcase in bun's JUnit report to (passed, failure-detail)."""
    parsed: dict[str, tuple[bool, str]] = {}
    if not _JUNIT_OUT.exists():
        return parsed
    root = ET.parse(str(_JUNIT_OUT)).getroot()  # noqa: S314 - our own tool output
    for tc in root.iter("testcase"):
        name = tc.get("name", "")
        failure = tc.find("failure")
        errored = tc.find("error")
        bad = failure if failure is not None else errored
        if bad is not None:
            detail = (bad.get("message") or bad.text or "").strip()
            parsed[name] = (False, detail[:400])
        else:
            parsed[name] = (True, "")
    return parsed


def _bun_results() -> dict[str, tuple[bool, str]]:
    """Run bun once (cached) and resolve each known case substring to a result."""
    global _RESULTS_CACHE
    if _RESULTS_CACHE is not None:
        return _RESULTS_CACHE

    returncode, output = _run_bun()
    by_name = _parse_junit()

    resolved: dict[str, tuple[bool, str]] = {}
    for needle in _CASES:
        match = next(((p, d) for name, (p, d) in by_name.items() if needle in name), None)
        if match is None:
            # The case never appeared: either the whole file failed to load
            # (compile error, missing export) or the title drifted. Surface the
            # process output so the failure is diagnosable.
            tail = output[-1200:]
            resolved[needle] = (
                False,
                f"case not found in bun report (bun exit {returncode}); output tail:\n{tail}",
            )
        else:
            resolved[needle] = match

    _RESULTS_CACHE = resolved
    return resolved


def _check(needle: str) -> None:
    passed, detail = _bun_results()[needle]
    assert passed, f"{_CASES[needle]}: {detail}"


# ── One pytest case per behavioral aspect (fail_to_pass + pass_to_pass) ──────


def test_no_probe_under_lock_append() -> None:
    _check("append path's OS incarnation")


def test_no_probe_under_lock_heartbeat() -> None:
    _check("heartbeat checkpoint's OS probes")


def test_no_probe_under_lock_unregister() -> None:
    _check("conditional-unregister pass's OS probes")


def test_fail_closed_stale_batch() -> None:
    _check("no longer fresh by the time the lock holds it")


def test_monotonic_freshness() -> None:
    _check("wall clock steps backward but monotonic time has advanced")


def test_exhaustion_error_names_holder_same_host() -> None:
    _check("names the holding process when a launch exhausts")


def test_exhaustion_error_reports_foreign_host() -> None:
    _check("foreign-host lock owner without mislabeling")


def test_stale_lock_safety_preserved() -> None:
    _check("releases the lock when a critical section throws")


def test_concurrent_launches_converge() -> None:
    _check("bounds concurrent launches behind a legitimate holder")
