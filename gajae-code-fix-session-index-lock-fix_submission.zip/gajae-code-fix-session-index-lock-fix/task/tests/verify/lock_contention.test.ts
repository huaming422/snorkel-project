// Behavioral verifier for the session-index lock-contention fix (issue #4544).
//
// A live detached broker used to hold the machine-global session-index lock
// across a synchronous OS liveness probe (on Windows a powershell.exe spawn
// that can wedge indefinitely), so every other launch on the host exhausted the
// 600-attempt / 100ms acquire budget (~60s) and crashed on startup. The fix has
// to (a) keep every OS liveness probe OUT of the locked critical section,
// (b) handle the pid-reuse hazard that moving the probe out creates, fail-closed
// on a clock that cannot run backward, and (c) make the exhaustion error name
// the holder instead of a bare attempt count — all while preserving the
// stale-lock recovery discipline (a proven-live owner is never displaced).
//
// Every assertion runs through pre-existing, stable public surface: the
// SessionIndex class methods (append / checkpointLiveHeartbeats /
// unregisterIfCurrent / listSessions / withLocked / open / diagnose) and the
// exported withFileLock. processIncarnation and withFileLock are observed via
// spies ONLY to witness when a probe runs relative to how deep the lock is held
// — no implementation-private internal symbol is imported or asserted on.

import { describe, expect, it, vi } from "bun:test";
import * as fs from "node:fs/promises";
import * as os from "node:os";
import * as path from "node:path";
import * as lockModule from "../src/config/file-lock";
import * as incarnationModule from "../src/sdk/broker/process-incarnation";
import { SessionIndex } from "../src/sdk/broker/session-index";

// A self-pid host registration: append derives this host's own OS identity for
// pid === process.pid, which is the observable side of the pre-lock probe move.
const registration = (sessionId: string) => ({
	type: "host_registered" as const,
	sessionId,
	locator: { repo: "r", stateRoot: "q" },
	endpointGeneration: 1,
	pid: process.pid,
});

function deferred<T = void>() {
	return Promise.withResolvers<T>();
}

// Drive withFileLock through a depth-counting wrapper so any probe that runs
// while depth > 0 is provably inside the machine-global critical section. The
// wrapper calls the real lock so acquisition/release semantics are unchanged.
function instrumentLockDepth() {
	const realWithFileLock = lockModule.withFileLock;
	const state = { depth: 0, probedUnderLock: false };
	const lockSpy = vi
		.spyOn(lockModule, "withFileLock")
		.mockImplementation(async (filePath: Parameters<typeof realWithFileLock>[0], fn, options) => {
			state.depth++;
			try {
				return await realWithFileLock(filePath, fn, options);
			} finally {
				state.depth--;
			}
		});
	const realProcessIncarnation = incarnationModule.processIncarnation;
	const incarnationSpy = vi.spyOn(incarnationModule, "processIncarnation").mockImplementation(pid => {
		if (state.depth > 0) state.probedUnderLock = true;
		return realProcessIncarnation(pid);
	});
	return { state, lockSpy, incarnationSpy };
}

// Fail-closed harness, independent of control-flow shape. Every valid fix
// gathers OS observations (via processIncarnation) and then acquires the
// machine-global lock on the index log to commit a heartbeat — whether the probe
// runs before the first acquisition (probe-before-lock) or between a
// replay-release and the write (probe-after-release). This fires `advance()`
// exactly when that commit acquisition happens AFTER the probe batch was
// gathered, so a time-bounded freshness guard must observe the batch as aged and
// skip the write — regardless of where in the flow the guard lives.
function failClosedHarness(advance: () => void) {
	let incarnationCalls = 0;
	const realProcessIncarnation = incarnationModule.processIncarnation;
	const incarnationSpy = vi.spyOn(incarnationModule, "processIncarnation").mockImplementation(pid => {
		incarnationCalls++;
		return realProcessIncarnation(pid);
	});
	const handle = {
		advanced: false,
		restore() {
			lockSpy.mockRestore();
			incarnationSpy.mockRestore();
			vi.restoreAllMocks();
		},
	};
	const realWithFileLock = lockModule.withFileLock;
	const lockSpy = vi
		.spyOn(lockModule, "withFileLock")
		.mockImplementation(async (filePath: Parameters<typeof realWithFileLock>[0], fn, options) => {
			if (!handle.advanced && incarnationCalls > 0 && String(filePath).endsWith("index.jsonl")) {
				handle.advanced = true;
				advance();
			}
			return await realWithFileLock(filePath, fn, options);
		});
	return handle;
}

describe("sdk session index lock contention", () => {
	it("derives the append path's OS incarnation without holding the index lock", async () => {
		const dir = await fs.mkdtemp(path.join(os.tmpdir(), "ssb-ix-append-"));
		const index = await new SessionIndex(dir).open();
		const { state, lockSpy, incarnationSpy } = instrumentLockDepth();
		try {
			// Self-pid registration forces the host-incarnation derivation.
			const appended = await index.append(registration("probe"));
			expect(appended.hostIncarnation).toBeDefined();
			// The probe must have run (liveness is still observed) ...
			expect(incarnationSpy).toHaveBeenCalled();
			// ... but never while the machine-global lock was held.
			expect(state.probedUnderLock).toBe(false);
			// The unlocked projection still reflects the registration.
			expect(index.listSessions().sessions).toHaveLength(1);
		} finally {
			incarnationSpy.mockRestore();
			lockSpy.mockRestore();
		}
	});

	it("keeps the heartbeat checkpoint's OS probes outside the lock-held section", async () => {
		const dir = await fs.mkdtemp(path.join(os.tmpdir(), "ssb-ix-heartbeat-"));
		const index = await new SessionIndex(dir).open();
		await index.append(registration("live-host"));
		const { state, lockSpy, incarnationSpy } = instrumentLockDepth();
		try {
			expect(await index.checkpointLiveHeartbeats()).toBe(1);
			expect(incarnationSpy).toHaveBeenCalled();
			expect(state.probedUnderLock).toBe(false);
		} finally {
			incarnationSpy.mockRestore();
			lockSpy.mockRestore();
		}
	});

	it("keeps the conditional-unregister pass's OS probes outside the lock-held section", async () => {
		const dir = await fs.mkdtemp(path.join(os.tmpdir(), "ssb-ix-unregister-"));
		const index = await new SessionIndex(dir).open();
		const appended = await index.append(registration("retire-me"));
		expect(appended.hostIncarnation).toBeDefined();
		const { state, lockSpy, incarnationSpy } = instrumentLockDepth();
		try {
			expect(
				await index.unregisterIfCurrent({
					sessionId: "retire-me",
					locator: { repo: "r", stateRoot: "q" },
					endpointGeneration: 1,
					pid: process.pid,
					indexSeq: appended.indexSeq,
					processIncarnation: appended.processIncarnation,
					hostIncarnation: appended.hostIncarnation,
					identityProvenance: "composite",
					ambiguous: false,
					live: true,
					terminal: false,
					terminalUncertain: false,
				}),
			).toBe(true);
			expect(incarnationSpy).toHaveBeenCalled();
			expect(state.probedUnderLock).toBe(false);
		} finally {
			incarnationSpy.mockRestore();
			lockSpy.mockRestore();
		}
	});

	it("fails closed when the probe batch is no longer fresh by the time the lock holds it", async () => {
		const dir = await fs.mkdtemp(path.join(os.tmpdir(), "ssb-ix-stale-"));
		const seed = await new SessionIndex(dir).open();
		await seed.append(registration("slow-replay"));
		const index = await new SessionIndex(dir).open();
		// The OS observation batch is gathered (processIncarnation) before the
		// machine-global lock is acquired to commit a heartbeat. A pid can exit and
		// be reused in that window, so an observation that has aged past any
		// reasonable trust bound must be discarded (no heartbeat this cycle) rather
		// than checkpointing a possibly-reused pid. Jump the clock far past any
		// plausible freshness bound exactly when the commit acquisition of the index
		// log happens after the probe — independent of whether the probe ran before
		// the first acquisition or between a replay-release and the write. Advance
		// BOTH monotonic and wall clocks so this case admits any time-based bound;
		// the separate backward-step case below is what pins regression safety.
		const h = failClosedHarness(() => {
			const realMono = performance.now.bind(performance);
			vi.spyOn(performance, "now").mockImplementation(() => realMono() + 120_000);
			const realNow = Date.now;
			vi.spyOn(Date, "now").mockImplementation(() => realNow() + 120_000);
		});
		try {
			expect(await index.checkpointLiveHeartbeats()).toBe(0);
			expect(h.advanced).toBe(true);
			// No heartbeat was recorded for the still-live host.
			const rows = index.listSessions().sessions;
			expect(rows).toHaveLength(1);
			expect(rows[0]?.lastHeartbeatAt).toBeUndefined();
		} finally {
			h.restore();
		}
		// A subsequent fast pass re-observes and writes normally.
		expect(await index.checkpointLiveHeartbeats()).toBe(1);
	});

	it("keeps failing closed when the wall clock steps backward but monotonic time has advanced", async () => {
		const dir = await fs.mkdtemp(path.join(os.tmpdir(), "ssb-ix-clock-"));
		const seed = await new SessionIndex(dir).open();
		await seed.append(registration("clock-regress"));
		const index = await new SessionIndex(dir).open();
		// A backward wall-clock step (manual fix, NTP slew, VM snapshot restore)
		// would make a Date.now()-based interval negative and sail past the bound,
		// consuming an arbitrarily stale batch. A freshness check on a clock that
		// cannot run backward must ignore the wall-clock regression and still fail
		// closed because monotonic time has advanced past the bound.
		const h = failClosedHarness(() => {
			const realNow = Date.now;
			vi.spyOn(Date, "now").mockImplementation(() => realNow() - 70_000);
			const realMono = performance.now.bind(performance);
			vi.spyOn(performance, "now").mockImplementation(() => realMono() + 120_000);
		});
		try {
			expect(await index.checkpointLiveHeartbeats()).toBe(0);
			expect(h.advanced).toBe(true);
			const rows = index.listSessions().sessions;
			expect(rows[0]?.lastHeartbeatAt).toBeUndefined();
		} finally {
			h.restore();
		}
		expect(await index.checkpointLiveHeartbeats()).toBe(1);
	});

	it("names the holding process when a launch exhausts the lock budget", async () => {
		const dir = await fs.mkdtemp(path.join(os.tmpdir(), "ssb-ix-owner-"));
		const sessionsDir = path.join(dir, "sdk", "sessions");
		await fs.mkdir(sessionsDir, { recursive: true });
		const logPath = path.join(sessionsDir, "index.jsonl");
		// A live owner's lock dir shaped exactly like the reporter's record.
		const lockDir = `${logPath}.lock`;
		await fs.mkdir(lockDir);
		await fs.writeFile(
			path.join(lockDir, "info"),
			JSON.stringify({ pid: process.pid, start_time: "unknown", timestamp: Date.now() }),
		);
		let failure: unknown;
		try {
			await lockModule.withFileLock(logPath, async () => {}, { retries: 2, retryDelayMs: 5 });
		} catch (error) {
			failure = error;
		}
		expect(failure).toBeInstanceOf(Error);
		const message = (failure as Error).message;
		// The error must identify the holder so an operator can act, instead of
		// reporting only an attempt count (the pre-fix message). Assert the holder
		// is named by DATA — the owning pid, as a non-digit-delimited number —
		// rather than by any particular wording, so any actionable phrasing is
		// accepted. The pre-fix error carries no pid; that is the separating signal.
		expect(new RegExp(`(^|[^0-9])${process.pid}([^0-9]|$)`).test(message)).toBe(true);
		// Stale-lock safety: the proven-live owner's lock is never stolen.
		expect(await fs.exists(lockDir)).toBe(true);
	});

	it("reports a foreign-host lock owner without mislabeling a coincident local pid", async () => {
		const dir = await fs.mkdtemp(path.join(os.tmpdir(), "ssb-ix-foreign-"));
		const sessionsDir = path.join(dir, "sdk", "sessions");
		await fs.mkdir(sessionsDir, { recursive: true });
		const logPath = path.join(sessionsDir, "index.jsonl");
		// A shared-volume lock record owned by another host: its pid is meaningful
		// only there. The same number is a live LOCAL process here (this test's own
		// pid), so a naive liveness probe would wrongly call it the live holder.
		const lockDir = `${logPath}.lock`;
		await fs.mkdir(lockDir, { recursive: true });
		await fs.writeFile(
			path.join(lockDir, "info"),
			JSON.stringify({
				pid: process.pid,
				start_time: "unknown",
				timestamp: Date.now(),
				owner_host_id: "another-host",
			}),
		);
		let failure: unknown;
		try {
			await lockModule.withFileLock(logPath, async () => {}, {
				retries: 2,
				retryDelayMs: 5,
				ownerHostId: "this-host",
			});
		} catch (error) {
			failure = error;
		}
		expect(failure).toBeInstanceOf(Error);
		const message = (failure as Error).message;
		// The owning host is surfaced by DATA so the record is actionable: the
		// foreign host-id value appears verbatim (it is known only from the lock
		// record), alongside the recorded pid number ...
		expect(message).toContain("another-host");
		expect(new RegExp(`(^|[^0-9])${process.pid}([^0-9]|$)`).test(message)).toBe(true);
		// ... and the coincident LOCAL pid is never asserted to be live, because
		// liveness of a foreign host's pid cannot be proven from here. Any claim of
		// liveness is a parenthesised "(live)" affirmation in the diagnostic family;
		// its absence is what distinguishes a correct foreign-owner report from one
		// that naively probes the local pid space.
		expect(message).not.toContain("(live)");
		expect(await fs.exists(lockDir)).toBe(true);
	});

	it("releases the lock when a critical section throws and fails an aborted acquisition fast", async () => {
		const dir = await fs.mkdtemp(path.join(os.tmpdir(), "ssb-ix-throw-"));
		const index = await new SessionIndex(dir).open();
		await index.append(registration("one"));
		const boom = new Error("critical section failed");
		await expect(
			index.withLocked(async () => {
				throw boom;
			}),
		).rejects.toBe(boom);
		// A throw inside the critical section must not leave the lock held: the
		// next operation acquires immediately rather than burning the retry budget.
		const next = await index.append(registration("two"));
		expect(next.indexSeq).toBe(2);
		expect(await fs.exists(path.join(dir, "sdk", "sessions", "index.jsonl.lock"))).toBe(false);

		// An aborted acquisition must fail fast rather than exhaust its full retry
		// budget: hold the lock in the background, start a competing acquisition,
		// and abort it while it is genuinely contending.
		const controller = new AbortController();
		const acquired = deferred();
		const holderDone = deferred();
		void (async () => {
			await lockModule.withFileLock(path.join(dir, "sdk", "sessions", "index.jsonl"), async () => {
				acquired.resolve();
				await holderDone.promise;
			});
		})();
		await acquired.promise;
		const started = Date.now();
		const competing = lockModule
			.withFileLock(path.join(dir, "sdk", "sessions", "index.jsonl"), async () => {}, {
				signal: controller.signal,
				retries: 600,
				retryDelayMs: 100,
			})
			.catch(error => error as Error);
		setTimeout(() => controller.abort(), 150);
		const outcome = await competing;
		holderDone.resolve();
		expect(outcome).toBeInstanceOf(Error);
		expect(Date.now() - started).toBeLessThan(5_000);
	});

	it("bounds concurrent launches behind a legitimate holder and converges after release", async () => {
		const dir = await fs.mkdtemp(path.join(os.tmpdir(), "ssb-ix-concurrent-"));
		const seed = await new SessionIndex(dir).open();
		await seed.append(registration("seed"));
		// A long-but-bounded holder (e.g. compaction on a large index) holds the
		// machine-global lock for a fixed delay, then releases. The holder's exit
		// is time-bounded, not test-gated, so launches can never deadlock behind an
		// unresolved promise.
		const holder = seed.withLocked(async () => {
			await Bun.sleep(400);
		});
		const launches = await Promise.all(
			[0, 1, 2].map(async i => {
				await Bun.sleep(i * 25);
				const launch = await new SessionIndex(dir).open();
				return (await launch.append(registration(`launch-${i}`))).indexSeq;
			}),
		);
		await holder;
		// Every launch landed a distinct, contiguous sequence — no corruption, no
		// lost update.
		expect(new Set(launches)).toEqual(new Set([2, 3, 4]));
		const replay = await new SessionIndex(dir).open();
		expect(replay.indexSeq).toBe(4);
		expect((await replay.diagnose()).status).toBe("healthy");
	}, 30_000);
});
