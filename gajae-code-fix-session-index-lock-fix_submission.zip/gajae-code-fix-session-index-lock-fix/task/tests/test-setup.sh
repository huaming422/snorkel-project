#!/usr/bin/env bash
# Environment bootstrap for the verifier.
#
# Sourced (not exec'd) by the harbor runner so env vars set here stay live for
# the verifier subprocess. The agent phase is offline (agent_offline = true); the
# full JS dependency closure (node_modules + workspace links) was baked into the
# image at the base commit, so this script performs NO dependency resolution —
# it only verifies the baked closure is intact and exports REPO_DIR.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/gajae-code}"
export REPO_DIR
cd "$REPO_DIR"

# The repo's unit suite runs under `bun test`; the verifier drives bun directly.
# Fail early and clearly if the runtime or the baked workspace closure is missing,
# rather than surfacing a confusing "cannot find module" from inside bun test.
if ! command -v bun >/dev/null 2>&1; then
    echo "test-setup.sh: bun runtime not found on PATH." >&2
    exit 1
fi

if [ ! -d node_modules ]; then
    echo "test-setup.sh: node_modules missing — the baked dependency closure is absent." >&2
    exit 1
fi

# Sanity: the three source modules the focused suite imports must resolve from
# the workspace. A missing workspace symlink (@gajae-code/utils) is the most
# likely corruption and would make every test error at import time.
if [ ! -e node_modules/@gajae-code/utils ]; then
    echo "test-setup.sh: @gajae-code/utils workspace link missing from node_modules." >&2
    exit 1
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR bun=$(bun --version 2>/dev/null || echo unknown)"
