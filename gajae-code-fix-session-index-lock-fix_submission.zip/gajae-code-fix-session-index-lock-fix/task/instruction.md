## Task

we keep hitting a startup crash on `gjc`. every so often a fresh launch just dies with something like `Failed to acquire lock for …/sdk/sessions/index.jsonl after 600 attempts`, and before it crashes it hangs for about a minute. it's intermittent, and it shows up far more often on windows than anywhere else.

what we've pieced together: it only happens while a detached background process from an earlier session is still alive. if we hunt that stray process down and kill it by hand, new launches go back to working. that's the only workaround we've found so far.

the error itself is useless for debugging. it tells us an attempt count and nothing else, never what's actually holding the lock.

one live background session shouldn't be able to starve everybody else's launches. dig into the root cause and fix it.
