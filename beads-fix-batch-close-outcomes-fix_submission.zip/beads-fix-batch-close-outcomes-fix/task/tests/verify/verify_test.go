package httpapi

// Behavioral checks for the many-issue batch-close custom method, driven
// through the real HTTP endpoint over the pre-existing in-package harness
// (newBatchCloseServer / roleBatchCloser / rolesConfig). Every assertion is a
// wire-observable fact — HTTP status, the published `code` vocabulary, and the
// presence or absence of `outcomes` / `issue` / `already_closed` in the decoded
// body. Nothing here reaches for a type, method, or field the fix introduces,
// so a reconciliation placed in a wrapper, inlined in the handler, or folded
// into the per-item projection all read identically from out here.
//
// The endpoint obtains its closer two ways, and the request cannot tell them
// apart: a directly-configured role when no unit-of-work provider is set, and a
// provider-built role when one is. The first four tests drive the role source
// (newBatchCloseServer); the last two drive the same wire facts through the
// PROVIDER source, so a reconciliation placed on only one of the two seams is
// caught here rather than left for the rubric. The provider-source harness is
// test-only infrastructure, injected alongside this file (see test-setup.sh);
// it exists because a real provider-built closer cannot itself emit the
// malformed shapes under test.

import (
	"fmt"
	"net/http"
	"testing"

	"github.com/steveyegge/beads/issueops"
)

// A result whose outcome count does not match the request cannot be walked
// against the caller's items at all: projected positionally it would report one
// item's answer under the next item's id for the rest of the array, silently,
// inside a 200. The honest answer is to fail the WHOLE request — a 500 carrying
// the `internal` problem code and NO per-item array. Both the short and the
// long mismatch are covered.
func TestVerifyBatchCloseRefusesMiscountedResult(t *testing.T) {
	for _, tc := range []struct {
		name     string
		outcomes []issueops.CloseOutcome
	}{
		{"fewer outcomes than items", []issueops.CloseOutcome{
			{IssueID: "bd-1", Issue: closedIssue("bd-1"), Changed: true},
		}},
		{"more outcomes than items", []issueops.CloseOutcome{
			{IssueID: "bd-1", Issue: closedIssue("bd-1"), Changed: true},
			{IssueID: "bd-2", Issue: closedIssue("bd-2"), Changed: true},
			{IssueID: "bd-3", Issue: closedIssue("bd-3"), Changed: true},
		}},
	} {
		t.Run(tc.name, func(t *testing.T) {
			ts := newBatchCloseServer(t, &roleBatchCloser{
				result: issueops.CloseBatchResult{Outcomes: tc.outcomes},
			})

			resp := ts.batchClose(t, `{"actor":"alice","items":[{"id":"bd-1"},{"id":"bd-2"}]}`)
			if resp.StatusCode != http.StatusInternalServerError {
				t.Fatalf("status = %d, want 500: %s", resp.StatusCode, readAll(t, resp))
			}
			body := decodeBody(t, resp)
			if body["code"] != string(CodeInternal) {
				t.Errorf("code = %v, want %s", body["code"], CodeInternal)
			}
			// A problem document, never a short or long array: a client reading
			// `outcomes` positionally would misattribute every entry past the
			// first mismatch.
			if _, present := body["outcomes"]; present {
				t.Errorf("a miscounted result was projected onto the wire anyway: %v", body)
			}
		})
	}
}

// An outcome carrying neither an issue row nor a refusal error has no honest
// wire shape: `code`'s absence promises `issue`, so projected as-is it is a
// success with no row. Because this batch is not all-or-nothing — the survivors
// have already committed — the bad entry folds into ITS OWN item (reported as
// an `internal` refusal) while every other item answers normally.
func TestVerifyBatchCloseFoldsContentlessOutcome(t *testing.T) {
	ts := newBatchCloseServer(t, &roleBatchCloser{result: issueops.CloseBatchResult{
		Outcomes: []issueops.CloseOutcome{
			{IssueID: "bd-1", Issue: closedIssue("bd-1"), Changed: true},
			{IssueID: "bd-2", Changed: true},
		},
	}})

	resp := ts.batchClose(t, `{"actor":"alice","items":[{"id":"bd-1"},{"id":"bd-2"}]}`)
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("status = %d, want 200: a post-commit fault on one item must not hide the others: %s",
			resp.StatusCode, readAll(t, resp))
	}
	outcomes := outcomesOf(t, resp)
	if len(outcomes) != 2 {
		t.Fatalf("outcomes = %v, want one per requested item", outcomes)
	}
	// The item that landed is untouched — that is the whole reason the fold is
	// per-item and not a whole-batch refusal.
	if _, present := outcomes[0]["code"]; present {
		t.Errorf("the item that landed was reported as a refusal: %v", outcomes[0])
	}
	if _, present := outcomes[0]["issue"]; !present {
		t.Errorf("the item that landed lost its row: %v", outcomes[0])
	}
	// The contentless item is reported as an internal refusal, and crucially
	// not as a rowless success.
	if outcomes[1]["code"] != string(CodeInternal) {
		t.Errorf("code = %v, want %s for an outcome with neither an issue nor a refusal",
			outcomes[1]["code"], CodeInternal)
	}
	if _, present := outcomes[1]["issue"]; present {
		t.Errorf("an outcome with no row carried an issue: %v", outcomes[1])
	}
	if _, present := outcomes[1]["already_closed"]; present {
		t.Errorf("an outcome with no row was reported as a success: %v", outcomes[1])
	}
}

// The outcomes slice belongs to the role, so the correction must operate on a
// copy. A role that answers repeated requests from one prepared result would
// otherwise carry the server's correction into everything it hands back next.
// Two sequential requests against one shared, prepared contentless result must
// be corrected identically, and the role's own stored error must stay nil.
func TestVerifyBatchCloseDoesNotMutateRoleResult(t *testing.T) {
	closer := &roleBatchCloser{result: issueops.CloseBatchResult{
		Outcomes: []issueops.CloseOutcome{{IssueID: "bd-1", Changed: true}},
	}}
	ts := newBatchCloseServer(t, closer)

	const body = `{"actor":"alice","items":[{"id":"bd-1"}]}`

	resp := ts.batchClose(t, body)
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("first request: status = %d, want 200: %s", resp.StatusCode, readAll(t, resp))
	}
	if outcome := outcomesOf(t, resp)[0]; outcome["code"] != string(CodeInternal) {
		t.Fatalf("first request: code = %v, want %s", outcome["code"], CodeInternal)
	}
	// The role's own result must be left alone — correcting it in place is the
	// aliasing bug this guards against.
	if err := closer.result.Outcomes[0].Err; err != nil {
		t.Fatalf("the correction was written into the role's own result: %v", err)
	}
	// The second request reads the same prepared result; it must fold identically
	// rather than being mis-served from a poisoned fixture.
	resp = ts.batchClose(t, body)
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("second request: status = %d, want 200: %s", resp.StatusCode, readAll(t, resp))
	}
	if outcome := outcomesOf(t, resp)[0]; outcome["code"] != string(CodeInternal) {
		t.Errorf("second request: code = %v, want %s", outcome["code"], CodeInternal)
	}
}

// Regression guard: a well-formed result — one outcome per requested item, each
// carrying a closed record or a typed refusal — still projects exactly the 200
// body it did before. This passes on the unfixed code and on any correct fix.
func TestVerifyBatchClosePreservesWellFormedResult(t *testing.T) {
	ts := newBatchCloseServer(t, &roleBatchCloser{result: issueops.CloseBatchResult{
		Outcomes: []issueops.CloseOutcome{
			{IssueID: "bd-1", Issue: closedIssue("bd-1"), Changed: true},
			{IssueID: "bd-missing", Err: fmt.Errorf("get: %w", issueops.ErrNotFound)},
		},
	}})

	resp := ts.batchClose(t, `{"actor":"alice","items":[{"id":"bd-1"},{"id":"bd-missing"}]}`)
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("status = %d, want 200: %s", resp.StatusCode, readAll(t, resp))
	}
	outcomes := outcomesOf(t, resp)
	if len(outcomes) != 2 {
		t.Fatalf("outcomes = %v, want one per requested item", outcomes)
	}
	// The success keeps its row and carries no refusal code.
	if _, present := outcomes[0]["code"]; present {
		t.Errorf("the successful item carries a code: %v", outcomes[0])
	}
	if _, present := outcomes[0]["issue"]; !present {
		t.Errorf("the successful item lost its row: %v", outcomes[0])
	}
	// The typed refusal keeps its published code and carries no row.
	if outcomes[1]["code"] != string(CodeNotFound) {
		t.Errorf("code = %v, want %s for a not-found refusal", outcomes[1]["code"], CodeNotFound)
	}
	if _, present := outcomes[1]["issue"]; present {
		t.Errorf("a refusal carried an issue row: %v", outcomes[1])
	}
}

// newProviderBatchCloseServer binds a server whose closer comes from the
// PROVIDER source rather than a directly-configured role, and hands that source
// the supplied closer so a case can still drive a malformed result down it. The
// endpoint picks its seam by whether a provider is configured, and this is the
// configured-provider half of that choice — the path a real server/shared-server
// deployment runs on. providerBatchCloseSource is defined in the injected
// provider-source harness (see test-setup.sh).
func newProviderBatchCloseServer(t *testing.T, closer *roleBatchCloser) *testServer {
	t.Helper()
	return newTestServer(t, Config{Provider: newProviderBatchCloseSource(closer)})
}

// A miscounted result refused on the DIRECT seam must be refused on the PROVIDER
// seam too: the same whole-batch 500 carrying `internal` and no per-item array.
// A reconciliation wired onto only the direct branch ships the mismatched array
// here, which is the production path's bug left standing.
func TestVerifyBatchCloseRefusesMiscountedResultFromProvider(t *testing.T) {
	ts := newProviderBatchCloseServer(t, &roleBatchCloser{
		result: issueops.CloseBatchResult{Outcomes: []issueops.CloseOutcome{
			{IssueID: "bd-1", Issue: closedIssue("bd-1"), Changed: true},
		}},
	})

	resp := ts.batchClose(t, `{"actor":"alice","items":[{"id":"bd-1"},{"id":"bd-2"}]}`)
	if resp.StatusCode != http.StatusInternalServerError {
		t.Fatalf("status = %d, want 500: %s", resp.StatusCode, readAll(t, resp))
	}
	body := decodeBody(t, resp)
	if body["code"] != string(CodeInternal) {
		t.Errorf("code = %v, want %s", body["code"], CodeInternal)
	}
	if _, present := body["outcomes"]; present {
		t.Errorf("a miscounted result was projected onto the wire from the provider seam: %v", body)
	}
}

// A contentless outcome folded per-item on the DIRECT seam must fold the same
// way on the PROVIDER seam: 200, the item that landed untouched, the empty entry
// reported as an `internal` refusal rather than a rowless success. A fix that
// guards only the direct branch leaves this entry shipping as a bogus success
// on the production path.
func TestVerifyBatchCloseFoldsContentlessOutcomeFromProvider(t *testing.T) {
	ts := newProviderBatchCloseServer(t, &roleBatchCloser{
		result: issueops.CloseBatchResult{Outcomes: []issueops.CloseOutcome{
			{IssueID: "bd-1", Issue: closedIssue("bd-1"), Changed: true},
			{IssueID: "bd-2", Changed: true},
		}},
	})

	resp := ts.batchClose(t, `{"actor":"alice","items":[{"id":"bd-1"},{"id":"bd-2"}]}`)
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("status = %d, want 200: a post-commit fault on one item must not hide the others: %s",
			resp.StatusCode, readAll(t, resp))
	}
	outcomes := outcomesOf(t, resp)
	if len(outcomes) != 2 {
		t.Fatalf("outcomes = %v, want one per requested item", outcomes)
	}
	if _, present := outcomes[0]["code"]; present {
		t.Errorf("the item that landed was reported as a refusal: %v", outcomes[0])
	}
	if _, present := outcomes[0]["issue"]; !present {
		t.Errorf("the item that landed lost its row: %v", outcomes[0])
	}
	if outcomes[1]["code"] != string(CodeInternal) {
		t.Errorf("code = %v, want %s for an outcome with neither an issue nor a refusal",
			outcomes[1]["code"], CodeInternal)
	}
	if _, present := outcomes[1]["issue"]; present {
		t.Errorf("an outcome with no row carried an issue: %v", outcomes[1])
	}
	if _, present := outcomes[1]["already_closed"]; present {
		t.Errorf("an outcome with no row was reported as a success: %v", outcomes[1])
	}
}
