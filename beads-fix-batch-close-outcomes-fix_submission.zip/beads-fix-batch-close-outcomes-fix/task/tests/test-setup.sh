#!/bin/bash
# Setup for the beads-fix-batch-close-outcomes verifier.
#
# The verifier is a native Go test added to internal/httpapi. Everything it
# needs — the Go toolchain, the module cache, and a build cache warmed at the
# base commit — is already baked into the image (image/Dockerfile blocks 3, 6,
# 7). The oracle adds or removes no Go module, so no dependency is fetched here.
#
# This step also installs test-only provider-seam infrastructure that lets the
# verifier drive the batch-close endpoint's PROVIDER branch with a malformed
# result. It is applied HERE, after the solving agent's diff has already been
# captured (test.sh commits the agent's work before sourcing this script), so
# none of it is visible to the agent or counted against the agent's patch.
#
# Why it is needed: the endpoint obtains its closer two ways — a directly
# configured role (no unit-of-work provider), or one the server builds over the
# provider (the provider path a real server/shared-server deployment runs on).
# The pre-existing harness can only seed a result on the DIRECT path; the
# provider-built closer is correct by construction and cannot itself emit the
# miscounted or contentless shapes the reconciliation exists to catch. Without a
# provider-path case, a fix that guards only the direct branch scores a perfect
# correctness while leaving the production provider path shipping the untrusted
# array. The two pieces below give the verifier a provider-seam it can feed a
# malformed result:
#
#   1. A provider-source harness file (providerBatchCloseSource) copied into the
#      httpapi package so the verifier can bind a server on the provider seam.
#   2. A seam helper (batchcloser_testseam.go) plus a one-line re-route of
#      timedProvider.BatchCloser so a provider carrying the test override hands
#      back its own closer. No production provider implements the override, so
#      production behavior is unchanged; the re-route keeps the accessor a sole
#      constructor call over the receiver, so the package's own
#      TestEveryTimedProviderAccessorBindsToTheWrapper structural pin still
#      passes.
#
# The oracle touches neither claim.go nor this new file, so both edits apply as
# no-op-safe text operations on whatever the agent left behind.

set -euo pipefail

export REPO_NAME=beads
REPO_DIR="/repo/beads"
PKG_DIR="$REPO_DIR/internal/httpapi"

cd "$REPO_DIR"

# Confirm the toolchain and module cache are present and usable offline. `go
# version` resolves entirely from the baked toolchain; no network is touched.
go version

# 1. Provider-source harness, next to the package's own test files. It is a
#    `_test.go` file, so it compiles only under `go test` and ships no
#    production symbol. The runner leaves pre-existing *_test.go in place (the
#    verifier defines no TestMain), so it compiles alongside verify_test.go.
cp /tests/verify/provider_source_harness_test.go "$PKG_DIR/provider_source_harness_test.go"

# 2a. Seam helper (a real .go file; its override branch is dead code for every
#     production provider and is exercised only by the test provider).
cp /tests/verify/batchcloser_testseam.go.txt "$PKG_DIR/batchcloser_testseam.go"

# 2b. Re-route timedProvider.BatchCloser through the helper. Idempotent and
#     anchored on the exact base-commit body; if an agent rewrote that accessor
#     (the oracle does not), the re-route is skipped and the provider-path cases
#     simply fail to bind — they do not silently pass.
python3 - <<'PY'
import sys

path = "/repo/beads/internal/httpapi/claim.go"
src = open(path).read()

if "batchCloserForTest(p)" in src:
    print("provider-seam re-route already present; skipping")
    sys.exit(0)

anchor = (
    "func (p timedProvider) BatchCloser() (issueops.BatchCloser, error) {\n"
    "\treturn uow.NewBatchCloser(p)\n"
    "}"
)
replacement = (
    "func (p timedProvider) BatchCloser() (issueops.BatchCloser, error) {\n"
    "\treturn batchCloserForTest(p)\n"
    "}"
)

if anchor not in src:
    print("WARNING: timedProvider.BatchCloser anchor not found; provider-seam "
          "re-route not installed (provider-path cases will fail to bind)", file=sys.stderr)
    sys.exit(0)

open(path, "w").write(src.replace(anchor, replacement, 1))
print("provider-seam re-route installed in claim.go")
PY
