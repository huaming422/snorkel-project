## Task

heads up, the batch-close endpoint is occasionally handing back garbage.
clients send it a list of issues to close and get back one result per issue,
lined up with the request by position. every so often it returns 200 like it
worked, but the results are wrong: one item shows up under a different issue's
id, or is reported closed with no record behind it, while the rest look fine.
it says success, so nothing flags it.

seems to happen when whatever performs the close hands back a result set that
doesn't line up one-to-one with what we asked. it should never return a
per-item array a client can't trust position-for-position; when the result
can't be reconciled, surface that through the error channel instead of a
bogus 200.

other endpoints already guard against internals handing back something they
can't honestly serve, so there's precedent. a well-formed close (one result
per item, each carrying a record or a refusal) should still go through clean;
it's the malformed result that needs catching. dig in and fix it?
