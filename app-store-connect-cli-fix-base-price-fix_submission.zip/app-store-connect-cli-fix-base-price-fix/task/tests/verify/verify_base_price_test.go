package cmdtest

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/rudrankriyam/App-Store-Connect-CLI/internal/asc"
	"github.com/rudrankriyam/App-Store-Connect-CLI/internal/cli/validate"
	"github.com/rudrankriyam/App-Store-Connect-CLI/internal/validation"
)

// basePriceScenario parameterizes the price-schedule side of the readiness run.
// Everything else is served from the healthy validValidateFixture() data so the
// only variable under test is how the app's base-territory price reads back.
type basePriceScenario struct {
	// priceSchedule is the body for GET /v1/apps/app-1/appPriceSchedule.
	// Empty means a healthy schedule whose id is "sched-1".
	priceSchedule string
	// baseTerritory is the body for GET /v1/appPriceSchedules/{id}/baseTerritory.
	// Empty means the USA base territory.
	baseTerritory string
	// baseTerritoryStatus overrides the base-territory HTTP status (0 = 200).
	baseTerritoryStatus int
	// manualPrices is the body for GET /v1/appPriceSchedules/{id}/manualPrices.
	// Empty means a single present USA price.
	manualPrices string
	// manualPricesStatus overrides the manual-prices HTTP status (0 = 200).
	manualPricesStatus int
}

const (
	healthyPriceScheduleBody = `{"data":{"type":"appPriceSchedules","id":"sched-1","attributes":{}}}`
	usaBaseTerritoryBody     = `{"data":{"type":"territories","id":"USA","attributes":{"currency":"USD"}}}`
)

// manualPriceWithWindow builds a manual-prices page carrying one USA price with
// the given start/end dates. An empty endDate means the price never ends. The
// price carries both a territory and an appPricePoint relationship so it is
// attributable to USA.
func manualPriceWithWindow(startDate, endDate string) string {
	end := ""
	if strings.TrimSpace(endDate) != "" {
		end = fmt.Sprintf(`,"endDate":%q`, endDate)
	}
	return fmt.Sprintf(`{"data":[{"type":"appPrices","id":"price-1","attributes":{"manual":true,"startDate":%q%s},"relationships":{"territory":{"data":{"type":"territories","id":"USA"}},"appPricePoint":{"data":{"type":"appPricePoints","id":"pp-1"}}}}],"links":{"next":""}}`, startDate, end)
}

// newBasePriceTestClient serves the healthy readiness data and overlays the
// scenario's price-schedule, base-territory, and manual-price responses. It
// adds the base-territory and manual-price schedule sub-resource routes that the
// readiness run reads when deciding whether the base territory is priced.
func newBasePriceTestClient(t *testing.T, scenario basePriceScenario) *asc.Client {
	t.Helper()

	tmpDir := t.TempDir()
	keyPath := filepath.Join(tmpDir, "key.p8")
	writeECDSAPEM(t, keyPath)

	f := validValidateFixture()

	priceSchedule := scenario.priceSchedule
	if priceSchedule == "" {
		priceSchedule = healthyPriceScheduleBody
	}
	baseTerritory := scenario.baseTerritory
	if baseTerritory == "" {
		baseTerritory = usaBaseTerritoryBody
	}

	transport := roundTripFunc(func(req *http.Request) (*http.Response, error) {
		if req.Method != http.MethodGet {
			return jsonResponse(http.StatusMethodNotAllowed, `{"errors":[{"status":405}]}`)
		}

		path := req.URL.Path
		switch {
		case path == "/v1/apps/app-1":
			return jsonResponse(http.StatusOK, f.app)
		case path == "/v1/apps/app-1/appStoreVersions":
			return jsonResponse(http.StatusOK, f.versions)
		case path == "/v1/appStoreVersions/ver-1":
			return jsonResponse(http.StatusOK, f.version)
		case path == "/v1/apps/app-1/appInfos":
			return jsonResponse(http.StatusOK, f.appInfos)
		case path == "/v1/appInfos/info-1/appInfoLocalizations":
			return jsonResponse(http.StatusOK, f.appInfoLocs)
		case path == "/v1/appInfos/info-1/relationships/primaryCategory":
			return jsonResponse(http.StatusOK, f.primaryCategory)
		case path == "/v1/appStoreVersions/ver-1/appStoreVersionLocalizations":
			return jsonResponse(http.StatusOK, f.versionLocs)
		case path == "/v1/appInfos/info-1/ageRatingDeclaration":
			return jsonResponse(http.StatusOK, f.ageRating)
		case path == "/v1/appStoreVersions/ver-1/appStoreReviewDetail":
			return jsonResponse(http.StatusOK, f.reviewDetails)
		case path == "/v1/appStoreVersions/ver-1/build":
			return jsonResponse(http.StatusOK, f.build)

		case path == "/v1/apps/app-1/appPriceSchedule":
			return jsonResponse(http.StatusOK, priceSchedule)
		case strings.HasPrefix(path, "/v1/appPriceSchedules/") && strings.HasSuffix(path, "/baseTerritory"):
			if scenario.baseTerritoryStatus != 0 {
				return jsonResponse(scenario.baseTerritoryStatus, baseTerritory)
			}
			return jsonResponse(http.StatusOK, baseTerritory)
		case strings.HasPrefix(path, "/v1/appPriceSchedules/") && strings.HasSuffix(path, "/manualPrices"):
			if scenario.manualPricesStatus != 0 {
				return jsonResponse(scenario.manualPricesStatus, scenario.manualPrices)
			}
			if scenario.manualPrices != "" {
				return jsonResponse(http.StatusOK, scenario.manualPrices)
			}
			return jsonResponse(http.StatusOK, manualPriceWithWindow("2020-01-01", ""))

		case path == "/v1/apps/app-1/appAvailabilityV2":
			return jsonResponse(http.StatusOK, f.availabilityV2)
		case path == "/v1/territories":
			return jsonResponse(http.StatusOK, f.pricingTerritories)
		case strings.HasPrefix(path, "/v2/appAvailabilities/") && strings.HasSuffix(path, "/territoryAvailabilities"):
			return jsonResponse(http.StatusOK, f.territories)
		case strings.HasPrefix(path, "/v1/appStoreVersionLocalizations/") && strings.HasSuffix(path, "/appScreenshotSets"):
			localizationID := strings.TrimSuffix(strings.TrimPrefix(path, "/v1/appStoreVersionLocalizations/"), "/appScreenshotSets")
			if body, ok := f.screenshotSets[localizationID]; ok {
				return jsonResponse(http.StatusOK, body)
			}
			return jsonResponse(http.StatusOK, `{"data":[]}`)
		case strings.HasPrefix(path, "/v1/appScreenshotSets/") && strings.HasSuffix(path, "/appScreenshots"):
			setID := strings.TrimSuffix(strings.TrimPrefix(path, "/v1/appScreenshotSets/"), "/appScreenshots")
			if body, ok := f.screenshotsBySet[setID]; ok {
				return jsonResponse(http.StatusOK, body)
			}
			return jsonResponse(http.StatusOK, `{"data":[]}`)
		case path == "/v1/apps/app-1/subscriptionGroups":
			return jsonResponse(http.StatusOK, f.subscriptionGroups)
		case strings.HasPrefix(path, "/v1/subscriptionGroups/") && strings.HasSuffix(path, "/subscriptionGroupLocalizations"):
			return jsonResponse(http.StatusOK, `{"data":[]}`)
		case strings.HasPrefix(path, "/v1/subscriptionGroups/") && strings.HasSuffix(path, "/subscriptions"):
			groupID := strings.TrimSuffix(strings.TrimPrefix(path, "/v1/subscriptionGroups/"), "/subscriptions")
			if body, ok := f.subscriptionsByGroup[groupID]; ok {
				return jsonResponse(http.StatusOK, body)
			}
			return jsonResponse(http.StatusOK, `{"data":[]}`)
		case strings.HasPrefix(path, "/v1/subscriptions/") && strings.HasSuffix(path, "/subscriptionLocalizations"):
			return jsonResponse(http.StatusOK, `{"data":[]}`)
		case strings.HasPrefix(path, "/v1/subscriptions/") && strings.HasSuffix(path, "/prices"):
			return jsonResponse(http.StatusOK, `{"data":[]}`)
		case strings.HasPrefix(path, "/v1/subscriptions/") && strings.HasSuffix(path, "/images"):
			subscriptionID := strings.TrimSuffix(strings.TrimPrefix(path, "/v1/subscriptions/"), "/images")
			if body, ok := f.imagesBySubscription[subscriptionID]; ok {
				return jsonResponse(http.StatusOK, body)
			}
			return jsonResponse(http.StatusOK, `{"data":[]}`)
		case path == "/v1/apps/app-1/inAppPurchasesV2":
			return jsonResponse(http.StatusOK, `{"data":[]}`)
		}

		return jsonResponse(http.StatusNotFound, `{"errors":[{"status":404}]}`)
	})

	client, err := asc.NewClientWithHTTPClient("KEY123", "ISS456", keyPath, &http.Client{Transport: transport})
	if err != nil {
		t.Fatalf("failed to create client: %v", err)
	}
	return client
}

// runReadiness drives the real validate command against the scenario and returns
// the parsed JSON report plus the run error (non-nil and a ReportedError when the
// report has blocking issues).
func runReadiness(t *testing.T, scenario basePriceScenario) (validation.Report, error) {
	t.Helper()

	client := newBasePriceTestClient(t, scenario)
	restore := validate.SetClientFactory(func() (*asc.Client, error) {
		return client, nil
	})
	defer restore()

	root := RootCommand("1.2.3")

	var runErr error
	stdout, _ := captureOutput(t, func() {
		if err := root.Parse([]string{"validate", "--app", "app-1", "--version-id", "ver-1"}); err != nil {
			t.Fatalf("parse error: %v", err)
		}
		runErr = root.Run(context.Background())
	})

	var report validation.Report
	if err := json.Unmarshal([]byte(stdout), &report); err != nil {
		t.Fatalf("failed to parse JSON report: %v\nstdout: %s", err, stdout)
	}
	return report, runErr
}

func isReportedError(err error) bool {
	if err == nil {
		return false
	}
	_, ok := errors.AsType[ReportedError](err)
	return ok
}

// pricingErrorIDs returns the IDs of every error-severity check attributed to
// pricing. A check is attributed to pricing when its ID is in the pricing.*
// namespace or it references the app price schedule resource.
func pricingErrorIDs(report validation.Report) []string {
	ids := make([]string, 0)
	for _, check := range report.Checks {
		if check.Severity != validation.SeverityError {
			continue
		}
		if strings.HasPrefix(check.ID, "pricing.") ||
			check.ResourceType == "appPriceSchedule" ||
			check.Field == "appPriceSchedule" ||
			check.Field == "manualPrices" {
			ids = append(ids, check.ID)
		}
	}
	return ids
}

func hasCheckAtSeverity(report validation.Report, id string, severity validation.Severity) bool {
	for _, check := range report.Checks {
		if check.ID == id && check.Severity == severity {
			return true
		}
	}
	return false
}

// Criterion #1: a configured schedule whose base territory has no
// current-or-scheduled price must raise a new blocking pricing issue, while a
// present (free or future-scheduled) price must pass. A price whose end date is
// today or earlier does not count because App Store Connect end dates are
// exclusive.
func TestReadinessBlocksConfiguredScheduleWithoutBasePrice(t *testing.T) {
	today := time.Now().UTC().Format("2006-01-02")

	cases := []struct {
		name         string
		manualPrices string
	}{
		{
			name:         "empty manual price list",
			manualPrices: `{"data":[],"links":{"next":""}}`,
		},
		{
			name:         "only price ended today",
			manualPrices: manualPriceWithWindow("2020-01-01", today),
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			report, runErr := runReadiness(t, basePriceScenario{manualPrices: tc.manualPrices})

			if ids := pricingErrorIDs(report); len(ids) == 0 {
				t.Fatalf("expected a blocking pricing issue, got checks %+v", report.Checks)
			}
			if !isReportedError(runErr) {
				t.Fatalf("expected the run to report a blocking error, got %v", runErr)
			}
		})
	}
}

func TestReadinessAcceptsPresentBasePrice(t *testing.T) {
	cases := []struct {
		name         string
		manualPrices string
	}{
		{
			name:         "free price active now",
			manualPrices: manualPriceWithWindow("2020-01-01", ""),
		},
		{
			name:         "price scheduled to start later",
			manualPrices: manualPriceWithWindow("2999-01-01", ""),
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			report, runErr := runReadiness(t, basePriceScenario{manualPrices: tc.manualPrices})

			if ids := pricingErrorIDs(report); len(ids) != 0 {
				t.Fatalf("expected no pricing error for a present price, got %v (checks %+v)", ids, report.Checks)
			}
			if runErr != nil {
				t.Fatalf("expected the run to stay non-blocking, got %v", runErr)
			}
		})
	}
}

// Criterion #2: an app that never configured a price (synthetic schedule whose
// id equals the app id, and schedule prices that read back as the "no resource
// of type 'null'" 404) must raise the existing missing-schedule error and must
// not raise an additional base-price error.
func TestReadinessReportsNeverConfiguredScheduleAsMissing(t *testing.T) {
	scenario := basePriceScenario{
		priceSchedule:      `{"data":{"type":"appPriceSchedules","id":"app-1"}}`,
		manualPricesStatus: http.StatusNotFound,
		manualPrices:       `{"errors":[{"status":"404","code":"NOT_FOUND","title":"Not Found","detail":"There is no resource of type 'null' with id 'app-1'"}]}`,
	}

	report, runErr := runReadiness(t, scenario)

	if !hasCheckAtSeverity(report, "pricing.schedule.missing", validation.SeverityError) {
		t.Fatalf("expected the existing pricing.schedule.missing error, got %+v", report.Checks)
	}
	if hasCheckWithID(report.Checks, "pricing.base_price.missing") {
		t.Fatalf("did not expect a base-price error for a never-configured schedule, got %+v", report.Checks)
	}
	if ids := pricingErrorIDs(report); len(ids) != 1 || ids[0] != "pricing.schedule.missing" {
		t.Fatalf("expected exactly the missing-schedule pricing error, got %v", ids)
	}
	if !isReportedError(runErr) {
		t.Fatalf("expected the run to report a blocking error, got %v", runErr)
	}
}

// Criterion #3: when the base-territory price cannot be read or attributed
// (rate limiting, an unrelated 404, or a price with no territory), readiness
// must degrade to the existing non-blocking unverified warning rather than a
// blocking missing-price error.
func TestReadinessDegradesUnreadablePricingToWarning(t *testing.T) {
	cases := []struct {
		name     string
		scenario basePriceScenario
	}{
		{
			name:     "manual prices rate limited",
			scenario: basePriceScenario{manualPricesStatus: http.StatusTooManyRequests, manualPrices: `{"errors":[{"status":"429","code":"RATE_LIMITED","title":"Too Many Requests","detail":"rate limited"}]}`},
		},
		{
			name:     "manual prices unrelated not found",
			scenario: basePriceScenario{manualPricesStatus: http.StatusNotFound, manualPrices: `{"errors":[{"status":"404","code":"NOT_FOUND","title":"Not Found","detail":"resource not found"}]}`},
		},
		{
			name:     "manual price has no territory",
			scenario: basePriceScenario{manualPrices: `{"data":[{"type":"appPrices","id":"opaque","attributes":{"manual":true}}],"links":{"next":""}}`},
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			report, runErr := runReadiness(t, tc.scenario)

			if !hasCheckAtSeverity(report, "pricing.schedule.unverified", validation.SeverityWarning) {
				t.Fatalf("expected the pricing.schedule.unverified warning, got %+v", report.Checks)
			}
			if ids := pricingErrorIDs(report); len(ids) != 0 {
				t.Fatalf("expected no blocking pricing error for an unreadable price, got %v (checks %+v)", ids, report.Checks)
			}
			if runErr != nil {
				t.Fatalf("expected the run to stay non-blocking, got %v", runErr)
			}
		})
	}
}
