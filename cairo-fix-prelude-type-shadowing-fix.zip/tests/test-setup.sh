#!/usr/bin/env bash
# Test-setup for cairo-fix-prelude-type-shadowing.
#
# The verifier injects a native integration test into
# crates/cairo-lang-starknet/tests/ and runs it via `cargo test`. That test
# drives the public contract compiler (cairo_lang_starknet::compile::compile_path)
# over small .cairo sources. The image already baked the workspace build at the
# base commit (Dockerfile block 7) and the dev corelib symlink
# (/opt/cache/corelib -> /repo/cairo/corelib) that detect_corelib needs, so the
# verifier's first `cargo test` only has to compile and run the injected binary.
#
# No services to start, no data to seed. Pre-warm the crate's test build so the
# grade-time compile is incremental.
set -euo pipefail

cd /repo/cairo

echo "[test-setup] Rust version:   $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:  $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root: /repo/cairo"

# Pre-compile cairo-lang-starknet and its test dependencies (offline — the
# closure is already in the cargo cache) so the verifier only compiles the
# injected integration test. A clean workspace keeps the agent's diff pristine.
cargo test -p cairo-lang-starknet --no-run --offline > /tmp/warm.log 2>&1 \
    || { echo "[test-setup] warm build failed (verifier will cold-compile):"; tail -40 /tmp/warm.log; }

echo "[test-setup] Setup complete."
