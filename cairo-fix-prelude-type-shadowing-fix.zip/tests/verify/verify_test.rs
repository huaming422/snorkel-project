//! Behavioural verifier for `cairo-fix-prelude-type-shadowing`.
//!
//! Every test compiles a small, self-contained Cairo project through the
//! public entry point `cairo_lang_starknet::compile::compile_path`, the same
//! function the `starknet-compile` binary and the crate's own `compile_test.rs`
//! use, and asserts only on whether compilation succeeded.
//!
//!   * Each test writes a `cairo_project.toml` and a `lib.cairo` to a scratch
//!     directory and compiles it. Nothing inspects generated source text.
//!   * The diagnostics reporter is `ignoring().allow_warnings()`: a compile
//!     fails only on errors. Contracts that declare types they never use get
//!     unused-item warnings, which are not what these tests are about.
//!   * Each project uses Cairo edition `2024_07`, the edition of the crate's own
//!     `cairo_level_tests` contracts.

use std::path::PathBuf;

use cairo_lang_compiler::CompilerConfig;
use cairo_lang_compiler::diagnostics::DiagnosticsReporter;
use cairo_lang_lowering::utils::InliningStrategy;
use cairo_lang_starknet::compile::compile_path;

/// `cairo_project.toml` pinning the crate root and the compiler edition.
const PROJECT_TOML: &str = "\
[crate_roots]
contract = \".\"

[config.global]
edition = \"2024_07\"
";

/// Compiles a single standalone contract crate and returns whether it compiled.
///
/// Writes `src` as the crate root (`lib.cairo`) of a fresh scratch directory
/// alongside a `cairo_project.toml`, then drives the public `compile_path`.
/// Returns `true` iff compilation succeeded (no error diagnostics).
fn contract_compiles(scratch_name: &str, src: &str) -> bool {
    // Unique per test and per process, so repeated runs never collide.
    let dir: PathBuf =
        std::env::temp_dir().join(format!("sbverify_shadow_{}_{}", std::process::id(), scratch_name));

    // Clean any stale copy, then materialise the project.
    let _ = std::fs::remove_dir_all(&dir);
    std::fs::create_dir_all(&dir).expect("create scratch project dir");
    std::fs::write(dir.join("cairo_project.toml"), PROJECT_TOML).expect("write cairo_project.toml");
    std::fs::write(dir.join("lib.cairo"), src).expect("write lib.cairo");

    let result = compile_path(
        dir.as_path(),
        None,
        CompilerConfig {
            // Only errors fail the compile; warnings such as unused types do not.
            diagnostics_reporter: DiagnosticsReporter::ignoring().allow_warnings(),
            replace_ids: true,
            add_statements_functions: false,
            add_statements_code_locations: false,
            add_functions_debug_info: false,
            add_type_names: false,
        },
        InliningStrategy::default(),
    );

    // Best-effort cleanup; the Result is already owned.
    let _ = std::fs::remove_dir_all(&dir);

    result.is_ok()
}

// ---------------------------------------------------------------------------
// Contracts that declare their own types named like standard-library types.
// ---------------------------------------------------------------------------

/// A storage-only contract (no callable entry points) that declares its own
/// `struct Array`.
#[test]
fn compiles_with_shadowed_array() {
    let src = "\
#[starknet::contract]
mod test_contract {
    #[storage]
    struct Storage {}

    struct Array {}
}
";
    assert!(
        contract_compiles("shadowed_array", src),
        "a storage-only contract that declares its own `struct Array` should compile"
    );
}

/// A storage-only contract that declares its own `struct Span`.
#[test]
fn compiles_with_shadowed_span() {
    let src = "\
#[starknet::contract]
mod test_contract {
    #[storage]
    struct Storage {}

    struct Span {}
}
";
    assert!(
        contract_compiles("shadowed_span", src),
        "a storage-only contract that declares its own `struct Span` should compile"
    );
}

/// A storage-only contract that declares its own `enum Option`.
#[test]
fn compiles_with_shadowed_option() {
    let src = "\
#[starknet::contract]
mod test_contract {
    #[storage]
    struct Storage {}

    enum Option {}
}
";
    assert!(
        contract_compiles("shadowed_option", src),
        "a storage-only contract that declares its own `enum Option` should compile"
    );
}

/// A contract that declares its own `struct Span` and exposes an external
/// function taking that struct as an argument. The contract must compile and
/// the argument must still be the contract's own `Span` (it reads the
/// struct's fields).
#[test]
fn compiles_with_shadowed_span_and_entrypoint() {
    let src = "\
#[starknet::contract]
mod test_contract {
    #[storage]
    struct Storage {}

    #[derive(Drop, Serde)]
    struct Span {
        start: felt252,
        end: felt252,
    }

    #[external(v0)]
    fn width(self: @ContractState, range: Span) -> felt252 {
        range.end - range.start
    }
}
";
    assert!(
        contract_compiles("shadowed_span_and_entrypoint", src),
        "a contract that declares its own `struct Span` and takes it as an external function \
         argument should compile, with the argument resolving to the contract's own struct"
    );
}

/// A contract that declares its own `struct Span` next to a
/// `#[starknet::interface]` trait declared inside the same contract module,
/// and embeds an implementation of that interface.
#[test]
fn compiles_with_shadowed_span_and_local_interface() {
    let src = "\
#[starknet::contract]
mod test_contract {
    use starknet::storage::{StoragePointerReadAccess, StoragePointerWriteAccess};

    #[starknet::interface]
    trait ICounter<TContractState> {
        fn get_count(self: @TContractState) -> felt252;
        fn increment(ref self: TContractState);
    }

    #[storage]
    struct Storage {
        count: felt252,
    }

    struct Span {}

    #[abi(embed_v0)]
    impl CounterImpl of ICounter<ContractState> {
        fn get_count(self: @ContractState) -> felt252 {
            self.count.read()
        }
        fn increment(ref self: ContractState) {
            self.count.write(self.count.read() + 1);
        }
    }
}
";
    assert!(
        contract_compiles("shadowed_span_and_local_interface", src),
        "a contract that declares its own `struct Span` alongside a starknet::interface trait \
         declared in the same contract module should compile"
    );
}

/// A contract that declares its own `Array`, `Span` and `Option` types and
/// also has real events: an event struct with a key field, a nested event
/// variant, and a flat event variant.
#[test]
fn compiles_with_shadowed_types_and_events() {
    let src = "\
#[starknet::contract]
mod test_contract {
    struct Array {}
    struct Span {}
    enum Option {}

    #[storage]
    struct Storage {}

    #[derive(Drop, starknet::Event)]
    struct Stored {
        #[key]
        key: felt252,
        value: felt252,
    }

    #[derive(Drop, starknet::Event)]
    struct Pinged {}

    #[derive(Drop, starknet::Event)]
    enum Admin {
        Pinged: Pinged,
    }

    #[event]
    #[derive(Drop, starknet::Event)]
    enum Event {
        Stored: Stored,
        #[flat]
        Admin: Admin,
    }
}
";
    assert!(
        contract_compiles("shadowed_types_and_events", src),
        "a contract that declares its own `Array`, `Span` and `Option` types and has an event \
         struct, a nested event variant and a flat event variant should compile"
    );
}

/// A project that declares its own `enum Result` next to a
/// `#[starknet::interface]` trait whose functions return it, and a contract
/// that implements the interface and imports that `Result`.
#[test]
fn compiles_with_shadowed_result_and_interface() {
    let src = "\
#[derive(Drop, Serde)]
pub enum Result {
    Pending,
    Passed,
    Rejected,
}

#[starknet::interface]
pub trait IBallot<TContractState> {
    fn result(self: @TContractState) -> Result;
    fn close(ref self: TContractState, approved: bool);
}

#[starknet::contract]
mod ballot {
    use starknet::storage::{StoragePointerReadAccess, StoragePointerWriteAccess};
    use super::Result;

    #[storage]
    struct Storage {
        closed: bool,
        approved: bool,
    }

    #[abi(embed_v0)]
    impl BallotImpl of super::IBallot<ContractState> {
        fn result(self: @ContractState) -> Result {
            if !self.closed.read() {
                Result::Pending
            } else if self.approved.read() {
                Result::Passed
            } else {
                Result::Rejected
            }
        }
        fn close(ref self: ContractState, approved: bool) {
            self.closed.write(true);
            self.approved.write(approved);
        }
    }
}
";
    assert!(
        contract_compiles("shadowed_result_and_interface", src),
        "a project that declares its own `enum Result` next to a starknet::interface trait \
         returning it, with a contract implementing that interface, should compile"
    );
}

// ---------------------------------------------------------------------------
// Ordinary contracts with no colliding names. These must keep their current
// result: the first two compile, the last one is rejected.
// ---------------------------------------------------------------------------

/// A contract that uses the standard-library `Array`, `Span` and `Option`
/// types in its external functions, and whose events are declared outside the
/// contract module.
#[test]
fn ordinary_prelude_contract_compiles() {
    let src = "\
#[derive(Drop, starknet::Event)]
struct ValuesMade {
    count: u32,
}

#[derive(Drop, starknet::Event)]
enum Event {
    ValuesMade: ValuesMade,
}

#[starknet::contract]
mod ordinary_contract {
    #[event]
    use super::Event;

    #[storage]
    struct Storage {}

    #[external(v0)]
    fn make_values(self: @ContractState) -> Array<felt252> {
        let mut data = array![];
        data.append(1);
        data.append(2);
        data
    }

    #[external(v0)]
    fn first_value(self: @ContractState, values: Span<felt252>) -> Option<felt252> {
        if values.len() == 0 {
            Option::None
        } else {
            Option::Some(*values[0])
        }
    }
}
";
    assert!(
        contract_compiles("ordinary_prelude", src),
        "a contract that uses the standard-library `Array`, `Span` and `Option` types, with its \
         events declared outside the contract module, should compile"
    );
}

/// A contract whose own source passes the wrong number of generic arguments
/// to the standard-library `Array` (it takes exactly one; this passes two).
/// The compiler must keep rejecting it.
#[test]
fn genuine_arity_error_still_fails() {
    let src = "\
#[starknet::contract]
mod test_contract {
    #[storage]
    struct Storage {}

    #[external(v0)]
    fn take(self: @ContractState, x: Array<felt252, u32>) -> felt252 {
        0
    }
}
";
    assert!(
        !contract_compiles("genuine_arity_error", src),
        "a contract that writes `Array<felt252, u32>` must not compile; the generic-argument \
         count error for user-written code must still be reported"
    );
}

/// A conventional storage + interface contract (a counter with a setter and
/// getter), mirroring the crate's own `hello_starknet` example.
#[test]
fn hello_starknet_contract_compiles() {
    let src = "\
#[starknet::interface]
trait HelloStarknetTrait<TContractState> {
    fn increase_balance(ref self: TContractState, amount: usize);
    fn get_balance(self: @TContractState) -> usize;
}

#[starknet::contract]
mod hello_starknet {
    use starknet::storage::{StoragePointerReadAccess, StoragePointerWriteAccess};
    #[storage]
    struct Storage {
        balance: usize,
    }

    #[abi(embed_v0)]
    impl HelloStarknetImpl of super::HelloStarknetTrait<ContractState> {
        fn increase_balance(ref self: ContractState, amount: usize) {
            self.balance.write(self.balance.read() + amount);
        }
        fn get_balance(self: @ContractState) -> usize {
            self.balance.read()
        }
    }
}
";
    assert!(
        contract_compiles("hello_starknet", src),
        "a conventional counter contract (storage + interface impl) should compile"
    );
}
