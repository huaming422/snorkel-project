## Task

A user's Starknet contract stopped compiling once they declared a struct named `Span` inside the contract module. The compiler fails with a generic-argument count error along the lines of "Expected 0 generic arguments, found 1", and renaming the struct makes it go away. Even a bare contract with only storage and no callable entry points fails this way. Their contract also has a raw-output entry point that returns the standard-library span, and with their own `Span` in the module they can't find a way to write that return type that compiles.

It isn't only `Span`, either. Other users have hit the same kind of build failure after giving their own types the names of other standard-library generic types, including types that live next to an interface whose functions take or return them. Nobody should have to rename their types to get any of this to build, and contracts that use the standard-library types themselves should compile, or fail to compile, exactly as they do today.
