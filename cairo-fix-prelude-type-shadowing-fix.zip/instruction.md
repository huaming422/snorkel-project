## Task

A user reported that their Starknet contract stopped compiling once they declared a type inside the contract module whose name matches a common standard-library type. Theirs was a struct named `Span`. The compiler fails with a generic-argument count error along the lines of "Expected 0 generic arguments, found 1", even though their own code doesn't use generics anywhere.

Renaming the type makes the contract compile again. It also doesn't take much to hit: a bare contract with only storage and no callable entry points fails the same way.

People should be able to give their own types ordinary names without the compile breaking just because a name matches a standard-library type. Please work out what's going on and fix it. A contract that declares and uses its own type with a standard-library name should compile, and a contract that actually uses the standard-library type should compile the same as before.
