## Task

A user reported that their Starknet contract stopped compiling once they declared a type inside the contract module whose name matches a common standard-library type. Theirs was a struct named `Span`. The compiler fails with a generic-argument count error along the lines of "Expected 0 generic arguments, found 1", even though their own code doesn't use generics anywhere.

Renaming the type makes the contract compile again. It also doesn't take much to hit: a bare contract with only storage and no callable entry points fails the same way.

`Span` is only the name they happened to pick. Users should be able to name their own types after any of the standard library's generic types without breaking the compile. Those types don't always live in the contract module either; often they sit in the same module as the interface whose functions take or return them. Please work out what's going on and fix it. A project that declares and uses its own type with one of those names, inside a contract module or next to an interface, should compile, and code that actually uses the standard-library types should compile the same as before.
