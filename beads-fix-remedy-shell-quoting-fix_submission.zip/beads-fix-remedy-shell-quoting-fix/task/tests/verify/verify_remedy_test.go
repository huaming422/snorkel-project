//go:build cgo

// Behavioral verifier for the remedy-command shell-quoting fix.
//
// Every assertion is made through two pre-existing, stable package entry
// points in cmd/bd, never through any helper the fix may rename or reshape:
//
//   - refuseUninitializableTarget(beadsDir string) error
//     Reached by `bd create --repo` / `bd migrate-personal`. For a target
//     with no metadata.json whose own config.yaml selects Dolt server mode,
//     it prints a `bd init ... --server-host <host> ...` remedy whose host
//     comes from the target's config. Its signature is unchanged by the fix.
//
//   - repoSyncMirrorRefusal(issue *types.Issue, planningPath, goos string) error
//     The phase-0 `bd repo sync` mirror refusal. It prints
//     `bd repo remove <path>` / `bd repo add <path>` remedies whose path is
//     the recorded source_repo. It already took an explicit goos parameter
//     before the fix, so BOTH platforms' quoting rules are exercisable on a
//     Linux host through this one stable entry point.
//
// The Windows quoting rules are a distinct surface from the POSIX ones, but
// both platforms route the same value through the same quoting chokepoint. On
// a Linux runner refuseUninitializableTarget's host branch is reached only
// under runtime.GOOS (=linux), so the Windows rules are driven instead through
// repoSyncMirrorRefusal(issue, planningPath, "windows"): it takes an explicit
// goos parameter and quotes the recorded source_repo through the same shared
// chokepoint the host remedy uses, so a Windows-blind fix is rejected there on
// behavior, on a Linux host, through a genuinely stable signature.
//
// The verifier deliberately does NOT call serverInitRemedy or any
// shellQuotedFor/escapedValue/printedValue helper: those names and signatures
// are the submitter's free choice (the reference example renamed, resplit, and
// reshaped them — e.g. serverInitRemedy gained a goos parameter and a second
// return). Asserting only through the two stable entry points keeps the test
// coupled to the observable message contract alone, so every valid
// restructuring (centralizing paste-safety at the shared quoting chokepoint,
// relocating the helper, or inlining the checks) compiles and is scored on
// behavior; a pre-fix tree fails behaviorally (the stable refusals compile and
// misbehave), scoring it zero, as the unfixed tree should score.
//
// This file owns TestMain purely so the shared Go runner isolates it as the
// sole test file in the package: a correct fix that renames the quoting helper
// must also update the package's own pre-existing tests, and isolating the
// verifier keeps such legitimate edits from turning into a build error that
// would mis-score a behaviorally-correct submission.
package main

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"

	"github.com/steveyegge/beads/internal/types"
)

func TestMain(m *testing.M) {
	os.Exit(m.Run())
}

// writeTarget builds a .beads directory holding only a config.yaml and returns
// its path, the shape refuseUninitializableTarget reads a target's mode/host
// from. The agent phase never reads this fixture, so the harness owns its
// shape (a repo-defined config.yaml layout).
func writeTarget(t *testing.T, configYAML string) string {
	t.Helper()
	beadsDir := filepath.Join(t.TempDir(), ".beads")
	if err := os.MkdirAll(beadsDir, 0o755); err != nil {
		t.Fatal(err)
	}
	if configYAML != "" {
		if err := os.WriteFile(filepath.Join(beadsDir, "config.yaml"), []byte(configYAML), 0o644); err != nil {
			t.Fatal(err)
		}
	}
	return beadsDir
}

// serverModeByHost yields a config.yaml that selects Dolt server mode by a
// non-local dolt.host, driving refuseUninitializableTarget's host remedy.
func serverModeByHost(host string) string {
	return "dolt:\n  host: " + host + "\n  port: 3307\n"
}

// vrTerminalActive reports whether s holds a raw character that, printed into a
// terminal line beside or inside a paste-ready command, can redraw, reorder or
// split it: a carriage return, an ESC that starts a control sequence, the
// U+202E bidi override, or the U+2028/U+2029 separators. These must never reach
// the printed message raw, whether inside the command or in a value named
// beside it.
func vrTerminalActive(s string) bool {
	for _, r := range []rune{'\r', '\x1b', '\u202e', '\u2028', '\u2029'} {
		if strings.ContainsRune(s, r) {
			return true
		}
	}
	return false
}

// vrRemedyArg returns the single argument the printed command passes after
// anchor (e.g. "bd repo remove "), reading up to the next occurrence of stop.
// It lets a round-trip test paste exactly what the operator would copy.
func vrRemedyArg(msg, anchor, stop string) string {
	i := strings.Index(msg, anchor)
	if i < 0 {
		return ""
	}
	rest := msg[i+len(anchor):]
	if j := strings.Index(rest, stop); j >= 0 {
		return rest[:j]
	}
	return rest
}

// --- Criterion 1 (pass_to_pass): a benign host/path is still printed inside
// the command, quoted for the platform, byte-for-byte as before the fix. This
// holds identically on a fixed and an unfixed tree, so it guards against a
// "fix" that over-escapes an ordinary value or drops the port.
func TestBenignRemedyUnchanged(t *testing.T) {
	// refuseUninitializableTarget: an ordinary remote host stays single-quoted
	// on POSIX with its configured port, inside the bd init remedy.
	beadsDir := writeTarget(t, serverModeByHost("db.example.com"))
	err := refuseUninitializableTarget(beadsDir)
	if err == nil {
		t.Fatalf("refuseUninitializableTarget: expected a refusal for a non-local dolt.host, got nil")
	}
	const wantInit = "--server-host 'db.example.com' --server-port 3307 --database <name>"
	if !strings.Contains(err.Error(), wantInit) {
		t.Errorf("benign host remedy:\n got %q\n want substring %q", err.Error(), wantInit)
	}

	// repoSyncMirrorRefusal: a benign path is single-quoted on POSIX and
	// double-quoted on Windows, in the remove remedy.
	issue := &types.Issue{ID: "mps-1", SourceRepo: "/home/me/proj"}
	for _, tc := range []struct{ goos, want string }{
		{"linux", "bd repo remove '/home/me/proj'"},
		{"windows", `bd repo remove "/home/me/proj"`},
	} {
		msg := repoSyncMirrorRefusal(issue, "/plan/path", tc.goos).Error()
		if !strings.Contains(msg, tc.want) {
			t.Errorf("[%s] benign source_repo remedy:\n got %q\n want substring %q", tc.goos, msg, tc.want)
		}
	}
}

// --- Criterion 2 (fail_to_pass): a host crafted to inject or to redraw the
// terminal is NEVER rendered so that a shell-active or terminal-active
// character survives in the printed refusal. The assertions are on observable
// SECURITY behavior — the injected payload does not survive, the recognizable
// benign part of the value is still named, and no raw terminal-active character
// reaches the line — never on any particular rendering the fix chooses (a
// placeholder token, an escaped form, a stripped form all pass). Driven through
// refuseUninitializableTarget's host surface.
func TestCraftedHostNeutralized(t *testing.T) {
	// A host whose tail breaks out of POSIX single quotes (a literal ') to run
	// a command: the dangerous tail must not appear raw in the refusal, while
	// the benign leading part bd recorded is still named (fidelity).
	injErr := refuseUninitializableTarget(writeTarget(t, serverModeByHost(`"myhost'; id #"`)))
	if injErr == nil {
		t.Fatalf("refuseUninitializableTarget: expected a refusal for a crafted dolt.host, got nil")
	}
	injMsg := injErr.Error()
	if strings.Contains(injMsg, "'; id") {
		t.Errorf("crafted host: the injected shell tail survives raw in the refusal, got %q", injMsg)
	}
	if !strings.Contains(injMsg, "myhost") {
		t.Errorf("crafted host: the recorded host value is not named at all (lost fidelity), got %q", injMsg)
	}

	// A host carrying a carriage return, an ESC/terminal sequence, and a U+202E
	// right-to-left override must not reach the printed line raw, or a
	// pasted/redrawn or visually-reordered command differs from the one bd
	// showed. The bidi override matters on its own: it is a graphic-category
	// character a C0/C1 control-stripper leaves untouched (it is above U+00A0),
	// so a "fix" that only strips control bytes still lets it reorder the line;
	// a correct fix neutralizes any character that is not shown as itself.
	termErr := refuseUninitializableTarget(writeTarget(t, serverModeByHost("\"db\\r\\u001b[2K\\u202E\\u2028x\"")))
	if termErr == nil {
		t.Fatalf("refuseUninitializableTarget: expected a refusal for a control-char dolt.host, got nil")
	}
	if vrTerminalActive(termErr.Error()) {
		t.Errorf("control-char host: a raw terminal-active character reached the printed line, got %q", termErr.Error())
	}

	// The target path the refusal names ahead of the bd init remedy is a second
	// attacker-influenced value (filepath.Dir of the target's .beads). A path
	// holding a carriage return must likewise not reach the printed line raw, or
	// it could redraw the remedy that follows it. The host here is benign, so the
	// only crafted input is the path.
	ctrlBeads := filepath.Join(t.TempDir(), "we\rird", ".beads")
	if err := os.MkdirAll(ctrlBeads, 0o755); err != nil {
		t.Fatalf("mkdir target with a control character in its path: %v", err)
	}
	if err := os.WriteFile(filepath.Join(ctrlBeads, "config.yaml"), []byte(serverModeByHost("db.example.com")), 0o644); err != nil {
		t.Fatal(err)
	}
	pathErr := refuseUninitializableTarget(ctrlBeads)
	if pathErr == nil {
		t.Fatalf("refuseUninitializableTarget: expected a refusal for a control-char target path, got nil")
	}
	if vrTerminalActive(pathErr.Error()) {
		t.Errorf("control-char target path: a raw terminal-active character reached the printed line, got %q", pathErr.Error())
	}
}

// --- Criterion 3 (fail_to_pass): the bd repo sync undo remedy embeds a benign
// path quoted for the platform (covered in Criterion 1), but a source_repo no
// shell passes through unchanged is rendered so the dangerous substring does not
// survive raw, while the recorded path is still recognizably named; the issue ID
// and planning path it also names carry no raw control character. Assertions are
// on observable security behavior, not on any chosen rendering. Driven through
// repoSyncMirrorRefusal on both platforms (its goos parameter makes the Windows
// rules reachable on a Linux host). Because the source_repo and the Windows
// host remedy route the same value through the same shared quoting chokepoint,
// driving the full Windows crafted charset through this stable entry point
// also rejects a host-quoting fix that is Windows-blind — no reach into the
// reshaped serverInitRemedy helper is needed.
func TestRepoSyncRefusalNeutralized(t *testing.T) {
	for _, tc := range []struct {
		name, goos, sourceRepo string
		fidelity               string // a benign fragment of the value that must still be named
		dangerRaw              string // the dangerous substring that must NOT survive raw
	}{
		// POSIX: a literal ' breaks out of single quotes (fish treats \ as an
		// escape there, and PowerShell on POSIX ends them even at
		// doltutil.ShellQuote's escaped form), so the `; id` tail would run.
		{"posix single-quote break-out", "linux", "repoA'; id #", "repoA", "'; id"},
		// Windows: $ expands under PowerShell inside the double quotes.
		{"windows dollar expansion", "windows", `C:\repoB$(id)`, "repoB", "$(id)"},
		// Windows: a trailing backslash escapes the closing double quote, so the
		// whole quoted path (ending in \") is itself the hazard and must not be
		// emitted verbatim inside the command.
		{"windows trailing backslash", "windows", `C:\repoC\`, "repoC", `C:\repoC\`},
		// Windows: a " ends cmd.exe's quotes so the rest runs; & chains a command.
		{"windows quote-ampersand breakout", "windows", `C:\repoD" & calc & "x`, "repoD", `" & calc`},
		// Windows: cmd.exe reads ; , = as separating a .cmd shim's arguments, so a
		// shim that reads them one by one is handed a second argument; a fix that
		// neutralizes only " $ & but leaves these live is still materially unsafe.
		{"windows semicolon shim split", "windows", `C:\repoE;calc`, "repoE", ";calc"},
		{"windows comma shim split", "windows", `C:\repoF,calc`, "repoF", ",calc"},
		{"windows equals shim split", "windows", `C:\repoG=calc`, "repoG", "=calc"},
		// Windows: cmd.exe acts on | < > ^ in an argument PowerShell hands a .cmd
		// shim unquoted.
		{"windows pipe", "windows", `C:\repoH|calc`, "repoH", "|calc"},
		{"windows redirect in", "windows", `C:\repoI<calc`, "repoI", "<calc"},
		{"windows redirect out", "windows", `C:\repoJ>calc`, "repoJ", ">calc"},
		{"windows caret", "windows", `C:\repoK^calc`, "repoK", "^calc"},
		// Windows: bash/Git Bash collapses a backslash-backslash pair to one, so a
		// path holding \\ cannot be passed through plain double quotes unchanged.
		{"windows double backslash pair", "windows", `C:\repoL\\x`, "repoL", `repoL\\x`},
	} {
		issue := &types.Issue{ID: "mps-1", SourceRepo: tc.sourceRepo}
		msg := repoSyncMirrorRefusal(issue, "/plan/path", tc.goos).Error()
		if strings.Contains(msg, tc.dangerRaw) {
			t.Errorf("[%s] the crafted path's dangerous substring %q survives raw, got %q", tc.name, tc.dangerRaw, msg)
		}
		if !strings.Contains(msg, tc.fidelity) {
			t.Errorf("[%s] the recorded path is not recognizably named (lost fidelity), got %q", tc.name, msg)
		}
	}

	// The source_repo, issue ID, and planning path named beside the command must
	// not carry a raw terminal-active character either — including a U+202E bidi
	// override, which a control-byte stripper leaves intact (it is a graphic
	// character above U+00A0) yet still reorders how the line displays.
	ctrlIssue := &types.Issue{ID: "mps\r1", SourceRepo: "db\x1b[2K\u202e\u2028x"}
	ctrlMsg := repoSyncMirrorRefusal(ctrlIssue, "/plan\rpath", "linux").Error()
	if vrTerminalActive(ctrlMsg) {
		t.Errorf("control-char repo sync refusal: a raw terminal-active character reached the printed line, got %q", ctrlMsg)
	}
}

// --- Criterion 4 (fail_to_pass): a printed form that IS quotable, run through
// the actual target shell, passes the value to the program unchanged; a form
// derived from an injecting value does not run the injection. This is the
// behavioral proof the quoting is correct, independent of how it is coded.
func TestPrintedFormRoundTripsThroughShell(t *testing.T) {
	// Quotable values: paste the printed remove-arg into the real shell and
	// require it to reproduce the value byte-for-byte. POSIX forms go through
	// sh; Windows forms through bash, as Git Bash runs them.
	for _, tc := range []struct{ goos, shell, value string }{
		{"linux", "sh", "/home/me/proj"},
		{"linux", "sh", "/tmp/$HOME/`id`"},
		{"windows", "bash", `C:\Users\Jane Doe\Proj (x86)`},
	} {
		issue := &types.Issue{ID: "mps-1", SourceRepo: tc.value}
		msg := repoSyncMirrorRefusal(issue, "/plan/path", tc.goos).Error()
		arg := vrRemedyArg(msg, "bd repo remove ", "`, then rerun")
		if arg == "" || strings.Contains(arg, "<path>") {
			t.Fatalf("[%s %q] expected a quotable path printed in the command, got arg %q from %q", tc.goos, tc.value, arg, msg)
		}
		out, _ := exec.Command(tc.shell, "-c", "printf %s "+arg).Output()
		if string(out) != tc.value {
			t.Errorf("[%s %q] printed form did not round-trip through %s:\n got %q\n want %q", tc.goos, tc.value, tc.shell, string(out), tc.value)
		}
	}

	// An injecting value (PowerShell/bash command substitution) must NOT run
	// when the printed remove-arg is pasted: a correct fix prints a placeholder
	// instead of the raw value, so the marker never executes.
	inject := &types.Issue{ID: "mps-1", SourceRepo: "x$(echo PWNED)y"}
	injMsg := repoSyncMirrorRefusal(inject, "/plan/path", "windows").Error()
	injArg := vrRemedyArg(injMsg, "bd repo remove ", "`, then rerun")
	injOut, _ := exec.Command("bash", "-c", "printf %s "+injArg).CombinedOutput()
	if strings.Contains(string(injOut), "PWNED") {
		t.Errorf("injecting value executed when pasted: arg %q produced %q", injArg, string(injOut))
	}
}

// --- Criterion 5 (pass_to_pass): the conditions under which bd refuses a
// target (server-mode detection, local-host exemption, no-config) are
// unchanged by the fix. Guards against a "fix" that alters when/why bd
// declines while changing how it quotes.
func TestRefusalConditionsUnchanged(t *testing.T) {
	for _, tc := range []struct {
		name, config string
		wantRefused  bool
	}{
		{"non-local host selects server mode", serverModeByHost("db.example.com"), true},
		{"dolt.mode server selects server mode", "dolt:\n  mode: server\n", true},
		{"local host is exempt", serverModeByHost("127.0.0.1"), false},
		{"no config is not refused", "", false},
	} {
		beadsDir := writeTarget(t, tc.config)
		err := refuseUninitializableTarget(beadsDir)
		if (err != nil) != tc.wantRefused {
			t.Errorf("[%s] refused=%v, want refused=%v (err=%v)", tc.name, err != nil, tc.wantRefused, err)
		}
	}
}
