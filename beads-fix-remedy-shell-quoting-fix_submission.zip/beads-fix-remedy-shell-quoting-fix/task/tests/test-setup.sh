#!/usr/bin/env bash
# Verifier test-setup for beads-fix-remedy-shell-quoting.
#
# This is an offline-agent task: the image already carries the full dependency
# closure at the base commit (Go module + build caches warmed in image/Dockerfile
# blocks 5 and 7), and the oracle introduces only stdlib imports — no new module.
# The Go verifier compiles and runs entirely from what is already baked, so there
# is nothing to install here. The behavioral verifier also pipes printed commands
# through sh/bash, both present in the base image.
#
# Kept as an explicit no-op (rather than absent) so the contract is visible and a
# future dependency can be added offline-first with a logged online fallback.
set -euo pipefail

echo "test-setup: no additional setup required (dependency closure baked at base commit)"
