## Task

heads up, this looks like a security problem. when `bd` refuses to set up or migrate a repo whose own config points its database at a remote host, or when it offers the commands to undo a `bd repo sync` copy, it prints a ready-to-paste command telling the operator what to run next. a repo's config is content someone else may have written, and a hostile repo can craft those values so the printed command does the wrong thing: paste it and it quietly runs an extra command nobody typed, or the line redraws itself in the terminal so what you copy isn't what's on screen. it's worst on Windows but reproduces on Linux and macOS too.

please make the commands `bd` prints in these refusals safe to paste on every shell it targets, no matter what a repo's config contains. when and why `bd` declines is already correct and should stay as it is; it's only how these messages render values that come from the config that needs to change.
