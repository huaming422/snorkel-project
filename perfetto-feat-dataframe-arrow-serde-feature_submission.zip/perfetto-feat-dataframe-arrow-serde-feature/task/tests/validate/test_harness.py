"""Plumbing for the Arrow validation stories.

The stories drive a prebuilt standalone program (built by validation-setup.sh,
not by the test) that serializes an example frame to a file and prints a JSON
report of the frame it read back. This module only exposes the binary path and a
thin runner; all assertions live in the story procedures.

Nothing here constructs or parses the serialized format: the round-trip story
reads the program's JSON stdout, and the interop story opens the written file
with an independent columnar reader. That keeps the on-disk Arrow layout owned
by the implementation, never transcribed by the harness.
"""

from __future__ import annotations

import json
import os
import subprocess
import tempfile

# Built by validation-setup.sh via perfetto_host_executable, copied to the build
# root. The module under test lives at /repo/perfetto.
REPO_DIR: str = "/repo/perfetto"
HARNESS_BIN: str = os.path.join(REPO_DIR, "out", "dist", "arrow_roundtrip_harness")


def run_case(case: str) -> tuple[dict, str]:
    """Run one driver case.

    Serializes the named example frame to a fresh temp file and returns
    ``(report, output_path)`` where ``report`` is the program's parsed JSON
    stdout (the recovered-frame digest) and ``output_path`` is the file holding
    the serialized bytes (for the interop story to re-open). Raises on a
    non-zero exit or unparseable output so an unsolved/broken build fails the
    story rather than silently passing.
    """
    fd, output_path = tempfile.mkstemp(prefix=f"arrow_{case}_", suffix=".arrow")
    os.close(fd)
    proc = subprocess.run(
        [HARNESS_BIN, case, output_path],
        cwd=REPO_DIR,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            f"driver case {case!r} exited {proc.returncode}: {proc.stderr.strip()}"
        )
    report = json.loads(proc.stdout.strip())
    return report, output_path
