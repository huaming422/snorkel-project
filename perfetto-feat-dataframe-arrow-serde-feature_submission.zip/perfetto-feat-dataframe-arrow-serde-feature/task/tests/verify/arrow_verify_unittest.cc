/*
 * Copyright (C) 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Behavioural checks for dataframe Arrow serialization/deserialization. This
// translation unit is fully self-contained: it binds only to the public
// serializer/deserializer entry points and the pre-existing public dataframe
// APIs, and it re-declares the small set of Apache Arrow wire-format constants
// and packed structs it needs to inspect framing. It deliberately does not
// include any module-private Arrow header, so it stays valid against any
// conforming implementation of the two entry points.

#include "src/trace_processor/core/dataframe/arrow_deserializer.h"
#include "src/trace_processor/core/dataframe/arrow_serializer.h"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <optional>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include "perfetto/base/status.h"
#include "perfetto/ext/base/string_view.h"
#include "perfetto/trace_processor/trace_blob.h"
#include "perfetto/trace_processor/trace_blob_view.h"
#include "src/base/test/status_matchers.h"
#include "src/trace_processor/containers/string_pool.h"
#include "src/trace_processor/core/dataframe/dataframe.h"
#include "src/trace_processor/core/dataframe/specs.h"
#include "src/trace_processor/core/dataframe/typed_cursor.h"
#include "src/trace_processor/util/flatbuffer_reader.h"
#include "src/trace_processor/util/trace_blob_view_reader.h"
#include "test/gtest_and_gmock.h"

namespace perfetto::trace_processor::core::dataframe {
namespace {

using perfetto::base::gtest_matchers::IsError;

// --- Locally declared Apache Arrow wire-format constants -------------------
//
// These mirror the official Arrow columnar/IPC "file" format. They are
// declared here (rather than shared from a module header) so that the checks
// below describe the Arrow standard itself, not any particular internal layout.

constexpr char kMagic[] = "ARROW1";
constexpr size_t kMagicSize = sizeof(kMagic) - 1;      // 6 bytes.
constexpr uint32_t kContinuation = 0xFFFFFFFF;
constexpr uint32_t kMessagePrefixSize = 8;             // continuation + size.
constexpr uint32_t kFileTrailerSize = 10;              // int32 footer size + magic.

// Flatbuffer field indices from the official Arrow schema.
namespace message_field {
constexpr uint32_t kHeader = 2;
}
namespace record_batch_field {
constexpr uint32_t kLength = 0;
constexpr uint32_t kNodes = 1;
constexpr uint32_t kBuffers = 2;
}  // namespace record_batch_field
namespace footer_field {
constexpr uint32_t kRecordBatches = 3;
}

struct MessagePrefix {
  uint32_t continuation;
  int32_t metadata_size;
};
static_assert(sizeof(MessagePrefix) == kMessagePrefixSize);

struct FieldNode {
  int64_t length;
  int64_t null_count;
};
static_assert(sizeof(FieldNode) == 2 * sizeof(int64_t));

struct ArrowBuffer {
  int64_t offset;
  int64_t length;
};
static_assert(sizeof(ArrowBuffer) == 2 * sizeof(int64_t));

struct Block {
  int64_t offset;
  int32_t metadata_length;
  int32_t padding;
  int64_t body_length;
};
static_assert(sizeof(Block) == 2 * sizeof(int64_t) + 2 * sizeof(int32_t));

template <typename T>
T Load(const uint8_t* data, uint32_t index) {
  T value;
  memcpy(&value, data + static_cast<size_t>(index) * sizeof(T), sizeof(T));
  return value;
}

// --- Inlined helpers (not shared with the module under test) ---------------

std::vector<uint8_t> Serialize(Dataframe& dataframe, const StringPool& pool) {
  dataframe.Finalize();
  ArrowSerializer serializer;
  auto prepared_size = serializer.Prepare(dataframe, &pool);
  EXPECT_OK(prepared_size);
  if (!prepared_size.ok()) {
    return {};
  }
  size_t expected_size = *prepared_size;
  std::vector<uint8_t> output;
  base::Status status =
      serializer.Write(dataframe, &pool, [&](const uint8_t* data, size_t size) {
        output.insert(output.end(), data, data + size);
        return base::OkStatus();
      });
  EXPECT_OK(status);
  EXPECT_EQ(output.size(), expected_size);
  return output;
}

util::TraceBlobViewReader MakeReader(const std::vector<uint8_t>& bytes,
                                     size_t chunk_size = 0) {
  util::TraceBlobViewReader reader;
  if (chunk_size == 0) {
    chunk_size = bytes.empty() ? 1 : bytes.size();
  }
  for (size_t i = 0; i < bytes.size(); i += chunk_size) {
    size_t length = std::min(chunk_size, bytes.size() - i);
    reader.PushBack(
        TraceBlobView(TraceBlob::CopyFrom(bytes.data() + i, length)));
  }
  return reader;
}

base::StatusOr<Dataframe> Deserialize(const std::vector<uint8_t>& bytes,
                                      StringPool* pool,
                                      const DataframeSpec& spec,
                                      size_t chunk_size = 0) {
  util::TraceBlobViewReader reader = MakeReader(bytes, chunk_size);
  return DeserializeFromArrow(reader, pool, spec);
}

template <typename Spec, typename... Values>
Dataframe MakeDataframe(const Spec& spec, StringPool* pool, Values&&... values) {
  Dataframe dataframe = Dataframe::CreateFromTypedSpec(spec, pool);
  (dataframe.InsertUnchecked(spec, std::monostate{},
                             std::forward<Values>(values)),
   ...);
  return dataframe;
}

// Parses the serialized bytes as an Arrow file and returns its single record
// batch's framing metadata using the pre-existing flatbuffer reader.
struct RecordBatch {
  Block block;
  int64_t rows;
  size_t body_offset;
  util::FlatBufferScalarVec<FieldNode> nodes;
  util::FlatBufferScalarVec<ArrowBuffer> buffers;
};

std::optional<RecordBatch> ReadRecordBatch(const std::vector<uint8_t>& bytes) {
  if (bytes.size() < kFileTrailerSize + kMagicSize) {
    return std::nullopt;
  }
  uint32_t footer_size =
      Load<uint32_t>(bytes.data() + bytes.size() - kFileTrailerSize, 0);
  if (footer_size > bytes.size() - kFileTrailerSize) {
    return std::nullopt;
  }
  size_t footer_offset = bytes.size() - kFileTrailerSize - footer_size;
  auto footer = util::FlatBufferReader::GetRoot(bytes.data() + footer_offset,
                                                footer_size);
  if (!footer) {
    return std::nullopt;
  }
  auto blocks = footer->VecScalar<Block>(footer_field::kRecordBatches);
  if (blocks.size() != 1) {
    return std::nullopt;
  }
  Block block = blocks[0];
  if (block.offset < 0 || block.metadata_length < 0) {
    return std::nullopt;
  }
  // Every framing offset derived from the (agent-produced) block table is
  // bounds-checked against the byte buffer before it is dereferenced, so a
  // non-conformant serialized file makes this helper return nullopt (a clean
  // test FAIL at the caller's ASSERT_TRUE(batch)) rather than reading out of
  // bounds and crashing the whole suite.
  size_t message_offset = static_cast<size_t>(block.offset);
  if (message_offset + kMessagePrefixSize > bytes.size()) {
    return std::nullopt;
  }
  MessagePrefix prefix = Load<MessagePrefix>(bytes.data() + message_offset, 0);
  if (prefix.continuation != kContinuation || prefix.metadata_size <= 0) {
    return std::nullopt;
  }
  size_t metadata_offset = message_offset + kMessagePrefixSize;
  if (metadata_offset + static_cast<size_t>(prefix.metadata_size) >
      bytes.size()) {
    return std::nullopt;
  }
  size_t body_offset = message_offset + static_cast<size_t>(block.metadata_length);
  if (body_offset > bytes.size()) {
    return std::nullopt;
  }
  auto message = util::FlatBufferReader::GetRoot(
      bytes.data() + metadata_offset,
      static_cast<uint32_t>(prefix.metadata_size));
  auto record_batch = message ? message->Table(message_field::kHeader)
                              : util::FlatBufferReader{};
  if (!record_batch) {
    return std::nullopt;
  }
  return RecordBatch{
      block, record_batch.Scalar<int64_t>(record_batch_field::kLength),
      body_offset,
      record_batch.VecScalar<FieldNode>(record_batch_field::kNodes),
      record_batch.VecScalar<ArrowBuffer>(record_batch_field::kBuffers)};
}

template <typename T>
T ReadBodyValue(const std::vector<uint8_t>& bytes,
                const RecordBatch& batch,
                uint32_t buffer_index,
                uint32_t value_index) {
  ArrowBuffer buffer = batch.buffers[buffer_index];
  // The buffer offset/length come from the (agent-produced) record-batch
  // metadata. Bounds-check the read against the byte buffer before touching it,
  // so a non-conformant file fails the EXPECT below (default-constructed T
  // mismatches the expected value) rather than reading out of bounds and
  // SIGSEGV-ing the whole suite.
  size_t value_offset = batch.body_offset + static_cast<size_t>(buffer.offset) +
                        static_cast<size_t>(value_index) * sizeof(T);
  if (buffer.offset < 0 || value_offset + sizeof(T) > bytes.size()) {
    ADD_FAILURE() << "body read out of range: buffer " << buffer_index
                  << " value " << value_index;
    return T{};
  }
  return Load<T>(
      bytes.data() + batch.body_offset + static_cast<size_t>(buffer.offset),
      value_index);
}

// Follows a flatbuffer relative offset stored at |offset_location| to the data
// it points at, returning a mutable pointer into |bytes|.
uint8_t* FollowMutableOffset(std::vector<uint8_t>* bytes,
                             const uint8_t* offset_location) {
  uint32_t relative_offset;
  memcpy(&relative_offset, offset_location, sizeof(relative_offset));
  size_t location = static_cast<size_t>(offset_location - bytes->data());
  return bytes->data() + location + relative_offset;
}

uint8_t* MutableVectorData(std::vector<uint8_t>* bytes,
                           const util::FlatBufferReader& table,
                           uint32_t field) {
  const uint8_t* vector_offset = table.FieldRaw(field, sizeof(uint32_t));
  EXPECT_NE(vector_offset, nullptr);
  uint8_t* vector = FollowMutableOffset(bytes, vector_offset);
  uint32_t count;
  memcpy(&count, vector, sizeof(count));
  EXPECT_GT(count, 0u);
  return vector + sizeof(count);
}

size_t FooterOffset(const std::vector<uint8_t>& bytes) {
  uint32_t footer_size;
  memcpy(&footer_size, bytes.data() + bytes.size() - kFileTrailerSize,
         sizeof(footer_size));
  return bytes.size() - kFileTrailerSize - footer_size;
}

Block ReadBlock(const std::vector<uint8_t>& bytes) {
  size_t footer_offset = FooterOffset(bytes);
  uint32_t footer_size =
      static_cast<uint32_t>(bytes.size() - kFileTrailerSize - footer_offset);
  auto footer = util::FlatBufferReader::GetRoot(bytes.data() + footer_offset,
                                                footer_size);
  EXPECT_TRUE(footer.has_value());
  auto blocks = footer->VecScalar<Block>(footer_field::kRecordBatches);
  EXPECT_EQ(blocks.size(), 1u);
  return blocks[0];
}

uint8_t* MutableBlock(std::vector<uint8_t>* bytes) {
  size_t footer_offset = FooterOffset(*bytes);
  uint32_t footer_size =
      static_cast<uint32_t>(bytes->size() - kFileTrailerSize - footer_offset);
  auto footer = util::FlatBufferReader::GetRoot(bytes->data() + footer_offset,
                                                footer_size);
  EXPECT_TRUE(footer.has_value());
  return MutableVectorData(bytes, *footer, footer_field::kRecordBatches);
}

util::FlatBufferReader MutableRecordBatch(std::vector<uint8_t>* bytes) {
  Block block = ReadBlock(*bytes);
  uint32_t metadata_size;
  memcpy(&metadata_size, bytes->data() + block.offset + sizeof(uint32_t),
         sizeof(metadata_size));
  auto message = util::FlatBufferReader::GetRoot(
      bytes->data() + block.offset + kMessagePrefixSize, metadata_size);
  EXPECT_TRUE(message.has_value());
  auto record_batch = message->Table(message_field::kHeader);
  EXPECT_TRUE(static_cast<bool>(record_batch));
  return record_batch;
}

// --- Dataframe specs used by the checks ------------------------------------

inline constexpr auto kUint32NonNull = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Uint32{}, NonNull{}, Unsorted{}));

inline constexpr auto kInt32NonNull = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Int32{}, NonNull{}, Unsorted{}));

inline constexpr auto kInt64NonNull = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Int64{}, NonNull{}, Unsorted{}));

inline constexpr auto kDoubleNonNull = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Double{}, NonNull{}, Unsorted{}));

inline constexpr auto kStringNonNull = CreateTypedDataframeSpec(
    {"_auto_id", "str"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(String{}, NonNull{}, Unsorted{}));

inline constexpr auto kUint32DenseNull = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Uint32{}, DenseNull{}, Unsorted{}));

inline constexpr auto kDoubleDenseNull = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Double{}, DenseNull{}, Unsorted{}));

inline constexpr auto kInt32Sparse = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Int32{}, SparseNull{}, Unsorted{}));

inline constexpr auto kInt64SparsePopcountAlways = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Int64{}, SparseNullWithPopcountAlways{}, Unsorted{}));

inline constexpr auto kStringSparse = CreateTypedDataframeSpec(
    {"_auto_id", "name"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(String{}, SparseNullWithPopcountAlways{}, Unsorted{}));

inline constexpr auto kStringDenseNull = CreateTypedDataframeSpec(
    {"_auto_id", "name"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(String{}, DenseNull{}, Unsorted{}));

inline constexpr auto kMultiColumn = CreateTypedDataframeSpec(
    {"_auto_id", "ts", "name", "value"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Int64{}, NonNull{}, Sorted{}),
    CreateTypedColumnSpec(String{}, NonNull{}, Unsorted{}),
    CreateTypedColumnSpec(Double{}, DenseNull{}, Unsorted{}));

inline constexpr auto kIdOnly = CreateTypedDataframeSpec(
    {"_auto_id"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}));

// ===========================================================================
// Round-trip fidelity through the public cell accessor.
// ===========================================================================

TEST(ArrowVerify, RoundtripPrimitiveUint32) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{10}, uint32_t{20},
                           uint32_t{30});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32NonNull, 0)), 10u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32NonNull, 1)), 20u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32NonNull, 2)), 30u);
}

TEST(ArrowVerify, RoundtripPrimitiveInt32) {
  StringPool pool;
  auto src = MakeDataframe(kInt32NonNull, &pool, int32_t{-5}, int32_t{0},
                           int32_t{2147483647});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kInt32NonNull, 0)), -5);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kInt32NonNull, 1)), 0);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kInt32NonNull, 2)), 2147483647);
}

TEST(ArrowVerify, RoundtripPrimitiveInt64) {
  StringPool pool;
  auto src = MakeDataframe(kInt64NonNull, &pool, int64_t{-1000000000000},
                           int64_t{0}, int64_t{1000000000000});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kInt64NonNull, 0)), -1000000000000);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kInt64NonNull, 2)), 1000000000000);
}

TEST(ArrowVerify, RoundtripPrimitiveDouble) {
  StringPool pool;
  auto src = MakeDataframe(kDoubleNonNull, &pool, double{1.5}, double{-2.25},
                           double{3.0});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  EXPECT_DOUBLE_EQ((dst.GetCellUnchecked<1>(kDoubleNonNull, 0)), 1.5);
  EXPECT_DOUBLE_EQ((dst.GetCellUnchecked<1>(kDoubleNonNull, 1)), -2.25);
  EXPECT_DOUBLE_EQ((dst.GetCellUnchecked<1>(kDoubleNonNull, 2)), 3.0);
}

TEST(ArrowVerify, RoundtripStringIncludingEmpty) {
  StringPool pool;
  auto hello = pool.InternString(base::StringView("hello"));
  auto world = pool.InternString(base::StringView("world"));
  auto empty = pool.InternString(base::StringView(""));
  auto src = MakeDataframe(kStringNonNull, &pool, hello, world, empty);

  // Deserialize into a fresh pool: the recovered strings must be re-interned by
  // value, independently of the source pool's ids.
  std::vector<uint8_t> bytes = Serialize(src, pool);
  StringPool other_pool;
  auto dst_or = Deserialize(bytes, &other_pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  EXPECT_EQ(
      other_pool.Get(dst.GetCellUnchecked<1>(kStringNonNull, 0)).ToStdString(),
      "hello");
  EXPECT_EQ(
      other_pool.Get(dst.GetCellUnchecked<1>(kStringNonNull, 1)).ToStdString(),
      "world");
  EXPECT_EQ(
      other_pool.Get(dst.GetCellUnchecked<1>(kStringNonNull, 2)).ToStdString(),
      "");
}

TEST(ArrowVerify, RoundtripDenseNull) {
  StringPool pool;
  auto src =
      MakeDataframe(kUint32DenseNull, &pool, std::optional<uint32_t>{10},
                    std::optional<uint32_t>{}, std::optional<uint32_t>{30},
                    std::optional<uint32_t>{}, std::optional<uint32_t>{50});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 5u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32DenseNull, 0)),
            std::optional<uint32_t>{10});
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32DenseNull, 1)),
            std::optional<uint32_t>{});
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32DenseNull, 2)),
            std::optional<uint32_t>{30});
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32DenseNull, 3)),
            std::optional<uint32_t>{});
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32DenseNull, 4)),
            std::optional<uint32_t>{50});
}

TEST(ArrowVerify, RoundtripDoubleDenseNull) {
  StringPool pool;
  auto src = MakeDataframe(kDoubleDenseNull, &pool, std::optional<double>{1.5},
                           std::optional<double>{}, std::optional<double>{3.0});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  auto v0 = dst.GetCellUnchecked<1>(kDoubleDenseNull, 0);
  auto v1 = dst.GetCellUnchecked<1>(kDoubleDenseNull, 1);
  auto v2 = dst.GetCellUnchecked<1>(kDoubleDenseNull, 2);
  ASSERT_TRUE(v0.has_value());
  EXPECT_DOUBLE_EQ(*v0, 1.5);
  EXPECT_FALSE(v1.has_value());
  ASSERT_TRUE(v2.has_value());
  EXPECT_DOUBLE_EQ(*v2, 3.0);
}

TEST(ArrowVerify, RoundtripSparseNull) {
  StringPool pool;
  auto src = MakeDataframe(kInt64SparsePopcountAlways, &pool,
                           std::optional<int64_t>{-7}, std::optional<int64_t>{},
                           std::optional<int64_t>{99});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kInt64SparsePopcountAlways, 0)),
            std::optional<int64_t>{-7});
  EXPECT_EQ((dst.GetCellUnchecked<1>(kInt64SparsePopcountAlways, 1)),
            std::optional<int64_t>{});
  EXPECT_EQ((dst.GetCellUnchecked<1>(kInt64SparsePopcountAlways, 2)),
            std::optional<int64_t>{99});
}

// A sparse column longer than 64 rows: the present/missing pattern must survive
// reconstruction across the 64-bit validity-word boundary.
TEST(ArrowVerify, RoundtripSparseNullAcrossWordBoundary) {
  StringPool pool;
  auto src = Dataframe::CreateFromTypedSpec(kInt64SparsePopcountAlways, &pool);
  for (int64_t i = 0; i < 200; i++) {
    src.InsertUnchecked(kInt64SparsePopcountAlways, std::monostate{},
                        i % 3 == 0 ? std::optional<int64_t>{}
                                   : std::optional<int64_t>{i * 100});
  }
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 200u);
  for (uint32_t i = 0; i < 200; i++) {
    auto expected = i % 3 == 0 ? std::optional<int64_t>{}
                               : std::optional<int64_t>{int64_t{i} * 100};
    EXPECT_EQ((dst.GetCellUnchecked<1>(kInt64SparsePopcountAlways, i)), expected)
        << "row " << i;
  }
}

TEST(ArrowVerify, RoundtripAllNullSparseColumn) {
  StringPool pool;
  auto src =
      MakeDataframe(kInt64SparsePopcountAlways, &pool, std::optional<int64_t>{},
                    std::optional<int64_t>{}, std::optional<int64_t>{});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  for (uint32_t row = 0; row < dst.row_count(); ++row) {
    EXPECT_FALSE(
        (dst.GetCellUnchecked<1>(kInt64SparsePopcountAlways, row)).has_value());
  }
}

TEST(ArrowVerify, RoundtripEmptySparseColumn) {
  StringPool pool;
  auto src = Dataframe::CreateFromTypedSpec(kInt32Sparse, &pool);
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);
  EXPECT_EQ(dst.row_count(), 0u);
}

TEST(ArrowVerify, RoundtripStringSparseNull) {
  StringPool pool;
  auto hello = pool.InternString(base::StringView("hello"));
  auto world = pool.InternString(base::StringView("world"));
  auto src = MakeDataframe(
      kStringSparse, &pool, std::optional<StringPool::Id>{hello},
      std::optional<StringPool::Id>{}, std::optional<StringPool::Id>{world});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  auto v0 = dst.GetCellUnchecked<1>(kStringSparse, 0);
  auto v1 = dst.GetCellUnchecked<1>(kStringSparse, 1);
  auto v2 = dst.GetCellUnchecked<1>(kStringSparse, 2);
  ASSERT_TRUE(v0.has_value());
  EXPECT_EQ(pool.Get(*v0).ToStdString(), "hello");
  EXPECT_FALSE(v1.has_value());
  ASSERT_TRUE(v2.has_value());
  EXPECT_EQ(pool.Get(*v2).ToStdString(), "world");
}

TEST(ArrowVerify, RoundtripStringDenseNull) {
  StringPool pool;
  auto hello = pool.InternString(base::StringView("hello"));
  auto src = MakeDataframe(kStringDenseNull, &pool,
                           std::optional<StringPool::Id>{hello},
                           std::optional<StringPool::Id>{});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 2u);
  auto v0 = dst.GetCellUnchecked<1>(kStringDenseNull, 0);
  ASSERT_TRUE(v0.has_value());
  EXPECT_EQ(pool.Get(*v0).ToStdString(), "hello");
  EXPECT_FALSE((dst.GetCellUnchecked<1>(kStringDenseNull, 1)).has_value());
}

TEST(ArrowVerify, RoundtripIdOnly) {
  StringPool pool;
  auto src = Dataframe::CreateFromTypedSpec(kIdOnly, &pool);
  src.InsertUnchecked(kIdOnly, std::monostate{});
  src.InsertUnchecked(kIdOnly, std::monostate{});
  src.InsertUnchecked(kIdOnly, std::monostate{});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  EXPECT_EQ((dst.GetCellUnchecked<0>(kIdOnly, 0)), 0u);
  EXPECT_EQ((dst.GetCellUnchecked<0>(kIdOnly, 2)), 2u);
}

TEST(ArrowVerify, RoundtripMultiColumn) {
  StringPool pool;
  auto a = pool.InternString(base::StringView("a"));
  auto bb = pool.InternString(base::StringView("bb"));
  auto src = Dataframe::CreateFromTypedSpec(kMultiColumn, &pool);
  src.InsertUnchecked(kMultiColumn, std::monostate{}, int64_t{100}, a,
                      std::optional<double>{0.5});
  src.InsertUnchecked(kMultiColumn, std::monostate{}, int64_t{200}, bb,
                      std::optional<double>{});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 2u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kMultiColumn, 0)), 100);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kMultiColumn, 1)), 200);
  EXPECT_EQ(pool.Get(dst.GetCellUnchecked<2>(kMultiColumn, 0)).ToStdString(),
            "a");
  EXPECT_EQ(pool.Get(dst.GetCellUnchecked<2>(kMultiColumn, 1)).ToStdString(),
            "bb");
  auto d0 = dst.GetCellUnchecked<3>(kMultiColumn, 0);
  ASSERT_TRUE(d0.has_value());
  EXPECT_DOUBLE_EQ(*d0, 0.5);
  EXPECT_FALSE((dst.GetCellUnchecked<3>(kMultiColumn, 1)).has_value());
}

// ===========================================================================
// Reader input shapes: chunked, non-zero start offset, unaligned.
// ===========================================================================

TEST(ArrowVerify, RoundtripChunkedInput) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1}, uint32_t{2},
                           uint32_t{3}, uint32_t{4});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec(), /*chunk_size=*/7);
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);
  ASSERT_EQ(dst.row_count(), 4u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32NonNull, 0)), 1u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32NonNull, 3)), 4u);
}

TEST(ArrowVerify, RoundtripNonZeroStartOffset) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{42});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  // A reader whose window does not start at file offset zero.
  util::TraceBlobViewReader reader;
  std::vector<uint8_t> padding(123, 0xAB);
  reader.PushBack(
      TraceBlobView(TraceBlob::CopyFrom(padding.data(), padding.size())));
  reader.PushBack(
      TraceBlobView(TraceBlob::CopyFrom(bytes.data(), bytes.size())));
  ASSERT_TRUE(reader.PopFrontUntil(padding.size()));

  auto dst_or = DeserializeFromArrow(reader, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);
  ASSERT_EQ(dst.row_count(), 1u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32NonNull, 0)), 42u);
}

TEST(ArrowVerify, RoundtripUnalignedInput) {
  StringPool pool;
  auto value = pool.InternString(base::StringView("unaligned"));
  auto src = MakeDataframe(kStringNonNull, &pool, value);
  std::vector<uint8_t> bytes = Serialize(src, pool);

  // A single-byte prefix shifts every Arrow buffer off its natural alignment.
  std::vector<uint8_t> combined(1, 0xAB);
  combined.insert(combined.end(), bytes.begin(), bytes.end());
  util::TraceBlobViewReader reader;
  reader.PushBack(
      TraceBlobView(TraceBlob::CopyFrom(combined.data(), combined.size())));
  ASSERT_TRUE(reader.PopFrontBytes(1));

  StringPool output_pool;
  auto dst_or = DeserializeFromArrow(reader, &output_pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);
  EXPECT_EQ(
      output_pool.Get(dst.GetCellUnchecked<1>(kStringNonNull, 0)).ToStdString(),
      "unaligned");
}

// ===========================================================================
// Arrow file-format conformance (framing inspected via flatbuffer parsing).
// ===========================================================================

TEST(ArrowVerify, SerializeArrowMagicHeadAndFoot) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  ASSERT_GE(bytes.size(), 2 * kMagicSize);
  EXPECT_EQ(memcmp(bytes.data(), kMagic, kMagicSize), 0);
  EXPECT_EQ(memcmp(bytes.data() + bytes.size() - kMagicSize, kMagic, kMagicSize),
            0);
}

TEST(ArrowVerify, SerializeFramingIsReadable) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{10}, uint32_t{20},
                           uint32_t{30});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto batch = ReadRecordBatch(bytes);
  ASSERT_TRUE(batch);
  EXPECT_EQ(batch->rows, 3);
}

TEST(ArrowVerify, SerializePrimitiveBuffer) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{10}, uint32_t{20},
                           uint32_t{30});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto batch = ReadRecordBatch(bytes);

  ASSERT_TRUE(batch);
  ASSERT_EQ(batch->rows, 3);
  ASSERT_EQ(batch->nodes.size(), 1u);
  EXPECT_EQ(batch->nodes[0].null_count, 0);
  ASSERT_EQ(batch->buffers.size(), 2u);
  EXPECT_EQ(batch->buffers[0].length, 0);  // Validity buffer empty (all valid).
  // The Arrow IPC buffer.length field is the logical (unpadded) byte count;
  // padding between buffers is implicit. Accept any length >= the logical
  // minimum — a conformant serializer may round up for alignment.
  EXPECT_GE(batch->buffers[1].length,
            static_cast<int64_t>(3 * sizeof(uint32_t)));
  EXPECT_EQ(ReadBodyValue<uint32_t>(bytes, *batch, 1, 0), 10u);
  EXPECT_EQ(ReadBodyValue<uint32_t>(bytes, *batch, 1, 1), 20u);
  EXPECT_EQ(ReadBodyValue<uint32_t>(bytes, *batch, 1, 2), 30u);
}

// A sparse numeric column must be densified on write: null count correct,
// validity bitmap matching the present mask, and gap slots zero-filled.
TEST(ArrowVerify, SerializeValidityBitmapDensifiesSparse) {
  StringPool pool;
  auto src =
      MakeDataframe(kInt32Sparse, &pool, std::optional<int32_t>{11},
                    std::optional<int32_t>{}, std::optional<int32_t>{33});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto batch = ReadRecordBatch(bytes);

  ASSERT_TRUE(batch);
  ASSERT_EQ(batch->nodes.size(), 1u);
  EXPECT_EQ(batch->nodes[0].null_count, 1);
  ASSERT_EQ(batch->buffers.size(), 2u);
  // 3 rows fit in 1 validity byte; accept >= 1 (alignment padding is allowed).
  EXPECT_GE(batch->buffers[0].length, 1);
  // Rows 0 and 2 present, row 1 missing -> bits 0b00000101.
  EXPECT_EQ(ReadBodyValue<uint8_t>(bytes, *batch, 0, 0), 0b00000101);
  EXPECT_EQ(ReadBodyValue<int32_t>(bytes, *batch, 1, 0), 11);
  EXPECT_EQ(ReadBodyValue<int32_t>(bytes, *batch, 1, 1), 0);  // Gap zero-filled.
  EXPECT_EQ(ReadBodyValue<int32_t>(bytes, *batch, 1, 2), 33);
}

TEST(ArrowVerify, SerializeUtf8OffsetAndDataBuffers) {
  StringPool pool;
  auto hello = pool.InternString(base::StringView("hello"));
  auto empty = pool.InternString(base::StringView(""));
  auto world = pool.InternString(base::StringView("world"));
  auto src = MakeDataframe(kStringNonNull, &pool, hello, empty, world);
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto batch = ReadRecordBatch(bytes);

  ASSERT_TRUE(batch);
  ASSERT_EQ(batch->buffers.size(), 3u);  // Validity + offsets + data.
  EXPECT_EQ(batch->buffers[0].length, 0);
  // n+1 int32 offsets; accept >= logical minimum (alignment padding allowed).
  EXPECT_GE(batch->buffers[1].length,
            static_cast<int64_t>(4 * sizeof(int32_t)));
  // 10 data bytes ("hello" + "" + "world"); accept >= 10 (alignment padding).
  EXPECT_GE(batch->buffers[2].length, 10);
  // Monotonic offsets: 0,5,5,10.
  EXPECT_EQ(ReadBodyValue<int32_t>(bytes, *batch, 1, 0), 0);
  EXPECT_EQ(ReadBodyValue<int32_t>(bytes, *batch, 1, 1), 5);
  EXPECT_EQ(ReadBodyValue<int32_t>(bytes, *batch, 1, 2), 5);
  EXPECT_EQ(ReadBodyValue<int32_t>(bytes, *batch, 1, 3), 10);
  ArrowBuffer strings = batch->buffers[2];
  const char* string_data = reinterpret_cast<const char*>(
      bytes.data() + batch->body_offset + strings.offset);
  // strings.length >= 10; read exactly the 10 logical data bytes.
  EXPECT_EQ(std::string_view(string_data, 10), "helloworld");
}

TEST(ArrowVerify, OmitsImplicitIdColumn) {
  StringPool pool;
  auto src = Dataframe::CreateFromTypedSpec(kIdOnly, &pool);
  src.InsertUnchecked(kIdOnly, std::monostate{});
  src.InsertUnchecked(kIdOnly, std::monostate{});
  src.InsertUnchecked(kIdOnly, std::monostate{});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto batch = ReadRecordBatch(bytes);

  ASSERT_TRUE(batch);
  EXPECT_EQ(batch->rows, 3);  // Row count still recorded.
  EXPECT_EQ(batch->nodes.size(), 0u);
  EXPECT_EQ(batch->buffers.size(), 0u);
  EXPECT_EQ(batch->block.body_length, 0);
}

// ===========================================================================
// Serializer lifecycle and reuse.
// ===========================================================================

TEST(ArrowVerify, PrepareWriteLifecycle) {
  StringPool pool;
  auto value = pool.InternString(base::StringView("value"));
  auto source = MakeDataframe(kStringNonNull, &pool, value);
  auto other = MakeDataframe(kStringNonNull, &pool, value);
  StringPool other_pool;
  ArrowSerializer serializer;
  auto sink = [](const uint8_t*, size_t) { return base::OkStatus(); };

  // Write before Prepare, and Prepare on a non-finalized frame, must error.
  EXPECT_THAT(serializer.Write(source, &pool, sink), IsError());
  EXPECT_THAT(serializer.Prepare(source, &pool), IsError());

  source.Finalize();
  other.Finalize();
  // Prepare with a mismatched pool must error.
  EXPECT_THAT(serializer.Prepare(source, &other_pool), IsError());
  ASSERT_OK(serializer.Prepare(source, &pool));
  // Write with a frame/pool that differs from the one Prepared must error.
  EXPECT_THAT(serializer.Write(other, &pool, sink), IsError());
  EXPECT_THAT(serializer.Write(source, &other_pool, sink), IsError());
  // The matching sequence succeeds.
  EXPECT_OK(serializer.Write(source, &pool, sink));
}

TEST(ArrowVerify, PreparedSizeEqualsWrittenLength) {
  StringPool pool;
  auto source = MakeDataframe(kUint32NonNull, &pool, uint32_t{1}, uint32_t{2});
  source.Finalize();
  ArrowSerializer serializer;
  auto size = serializer.Prepare(source, &pool);
  ASSERT_OK(size);
  size_t written = 0;
  ASSERT_OK(serializer.Write(source, &pool, [&](const uint8_t*, size_t len) {
    written += len;
    return base::OkStatus();
  }));
  EXPECT_EQ(written, *size);
}

TEST(ArrowVerify, CanBeReusedAcrossDataframes) {
  StringPool pool;
  auto first = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  auto second = MakeDataframe(kUint32NonNull, &pool, uint32_t{2}, uint32_t{3});
  first.Finalize();
  second.Finalize();
  ArrowSerializer serializer;
  std::vector<uint8_t> first_bytes;
  std::vector<uint8_t> second_bytes;

  auto write_to = [&](const Dataframe& dataframe, std::vector<uint8_t>* out) {
    auto size = serializer.Prepare(dataframe, &pool);
    ASSERT_OK(size);
    ASSERT_OK(serializer.Write(dataframe, &pool,
                               [&](const uint8_t* data, size_t length) {
                                 out->insert(out->end(), data, data + length);
                                 return base::OkStatus();
                               }));
    EXPECT_EQ(out->size(), *size);
  };
  write_to(first, &first_bytes);
  write_to(second, &second_bytes);

  // Each produced buffer must deserialize back to its own frame.
  auto first_or = Deserialize(first_bytes, &pool, first.CreateSpec());
  ASSERT_OK(first_or);
  EXPECT_EQ(first_or->row_count(), 1u);
  EXPECT_EQ((first_or->GetCellUnchecked<1>(kUint32NonNull, 0)), 1u);
  auto second_or = Deserialize(second_bytes, &pool, second.CreateSpec());
  ASSERT_OK(second_or);
  EXPECT_EQ(second_or->row_count(), 2u);
  EXPECT_EQ((second_or->GetCellUnchecked<1>(kUint32NonNull, 1)), 3u);
}

TEST(ArrowVerify, PropagatesWriteError) {
  StringPool pool;
  auto source = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  source.Finalize();
  ArrowSerializer serializer;
  ASSERT_OK(serializer.Prepare(source, &pool));
  uint32_t calls = 0;
  base::Status status =
      serializer.Write(source, &pool, [&](const uint8_t*, size_t) {
        if (++calls == 2) {
          return base::ErrStatus("sink failed");
        }
        return base::OkStatus();
      });
  EXPECT_THAT(status, IsError());
  EXPECT_EQ(status.message(), "sink failed");
  EXPECT_EQ(calls, 2u);
}

// ===========================================================================
// Deserializer hardening: malformed input is rejected via status, no crash.
// ===========================================================================

TEST(ArrowVerify, RejectsInvalidDataframeSpec) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  DataframeSpec invalid_spec{{"only_a_name"}, {}};
  EXPECT_THAT(Deserialize(bytes, &pool, invalid_spec), IsError());
}

TEST(ArrowVerify, RejectsTruncatedInput) {
  StringPool pool;
  auto src = MakeDataframe(kStringSparse, &pool,
                           std::optional<StringPool::Id>{pool.InternString(
                               base::StringView("some string data"))},
                           std::optional<StringPool::Id>{});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  for (size_t len = 0; len < bytes.size(); len += 7) {
    std::vector<uint8_t> truncated(bytes.begin(),
                                   bytes.begin() + static_cast<ptrdiff_t>(len));
    EXPECT_THAT(Deserialize(truncated, &pool, src.CreateSpec()), IsError())
        << "len " << len;
  }
}

TEST(ArrowVerify, RejectsCorruptFooterSize) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  uint32_t huge = 0x7FFFFFFF;
  memcpy(bytes.data() + bytes.size() - kFileTrailerSize, &huge, sizeof(huge));
  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsInconsistentBlockLength) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  Block block;
  memcpy(&block, MutableBlock(&bytes), sizeof(block));
  block.body_length += 8;
  memcpy(MutableBlock(&bytes), &block, sizeof(block));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsInconsistentFieldNode) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  auto record_batch = MutableRecordBatch(&bytes);
  uint8_t* node_data =
      MutableVectorData(&bytes, record_batch, record_batch_field::kNodes);
  FieldNode node;
  memcpy(&node, node_data, sizeof(node));
  node.null_count = 1;  // Claims a null where the buffers encode none.
  memcpy(node_data, &node, sizeof(node));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsInvalidEmptyValidityBufferOffset) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  auto record_batch = MutableRecordBatch(&bytes);
  uint8_t* buffer_data =
      MutableVectorData(&bytes, record_batch, record_batch_field::kBuffers);
  ArrowBuffer buffer;
  memcpy(&buffer, buffer_data, sizeof(buffer));
  ASSERT_EQ(buffer.length, 0);
  buffer.offset = -1;  // Negative offset for the (empty) validity buffer.
  memcpy(buffer_data, &buffer, sizeof(buffer));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsInvalidStringOffsets) {
  StringPool pool;
  auto value = pool.InternString(base::StringView("value"));
  auto src = MakeDataframe(kStringNonNull, &pool, value);
  std::vector<uint8_t> bytes = Serialize(src, pool);

  Block block = ReadBlock(bytes);
  auto record_batch = MutableRecordBatch(&bytes);
  uint8_t* buffer_data =
      MutableVectorData(&bytes, record_batch, record_batch_field::kBuffers);
  ArrowBuffer offsets_buffer;
  memcpy(&offsets_buffer, buffer_data + sizeof(ArrowBuffer),
         sizeof(offsets_buffer));
  int32_t invalid_offset = -1;  // Non-monotonic / negative Utf8 offset.
  memcpy(bytes.data() + block.offset + block.metadata_length +
             offsets_buffer.offset + sizeof(int32_t),
         &invalid_offset, sizeof(invalid_offset));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsSchemaShapeMismatch) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  // The requested schema has a different column shape than the encoded batch.
  auto dst = Dataframe::CreateFromTypedSpec(kMultiColumn, &pool);
  EXPECT_THAT(Deserialize(bytes, &pool, dst.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsGarbageInput) {
  StringPool pool;
  std::vector<uint8_t> bytes(256, 0xCD);
  auto dst = Dataframe::CreateFromTypedSpec(kUint32NonNull, &pool);
  EXPECT_THAT(Deserialize(bytes, &pool, dst.CreateSpec()), IsError());
}

// ===========================================================================
// The deserialized frame is a real finalized, queryable Dataframe.
// ===========================================================================

TEST(ArrowVerify, DeserializedFrameIsFinalized) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);
  EXPECT_TRUE(dst.finalized());
  EXPECT_EQ(dst.row_count(), 1u);
}

TEST(ArrowVerify, DeserializedFrameSupportsIndexesAndCursors) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{20}, uint32_t{10});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  uint32_t indexed_column = 1;
  auto index = dst.BuildIndex(&indexed_column, &indexed_column + 1);
  ASSERT_OK(index);
  Dataframe indexed = dst.AddIndex(std::move(*index));
  TypedCursor cursor(
      &indexed, std::vector<FilterSpec>{},
      std::vector<SortSpec>{{indexed_column, SortDirection::kAscending}});
  cursor.ExecuteUnchecked();
  ASSERT_FALSE(cursor.Eof());
  EXPECT_EQ(cursor.GetCellUnchecked<1>(kUint32NonNull), 10u);
  cursor.Next();
  ASSERT_FALSE(cursor.Eof());
  EXPECT_EQ(cursor.GetCellUnchecked<1>(kUint32NonNull), 20u);
  cursor.Next();
  EXPECT_TRUE(cursor.Eof());
}

}  // namespace
}  // namespace perfetto::trace_processor::core::dataframe
