#!/usr/bin/env bash
# verify.sh — native C++ verifier entry point.
#
# The behavioural checks live in a compiled gtest translation unit
# (arrow_verify_unittest.cc) that tests/test-setup.sh stages into the dataframe
# module and links into perfetto_unittests before any verifier runs. This script
# only selects that suite and makes its exit code authoritative: the shell
# runner records a single pass/fail from the process exit status, and gtest exits
# non-zero if any case fails, so no assertion logic belongs here.
#
# Invoked by the shell runner with the repo root as the working directory
# (/repo/perfetto). The unit-test binary was produced by the image's build and
# re-linked incrementally in test-setup.sh, so there is nothing to build here.
set -euo pipefail

BINARY="out/dist/perfetto_unittests"
if [ ! -x "$BINARY" ]; then
    echo "verify: $BINARY missing or non-executable (test-setup must build it first)" >&2
    exit 1
fi

OUT_DIR="${SSB_LOGS_DIR:-/logs/verifier}"
mkdir -p "$OUT_DIR" 2>/dev/null || true

# Run only the self-contained verifier suite. --gtest_output writes a JUnit XML
# alongside the log for debugging; the shell runner keys solely off the exit
# code. A failing or absent suite (empty filter -> zero tests run) must fail
# loudly, so we also reject a zero-test run.
set +e
"$BINARY" \
    --gtest_filter='ArrowVerify.*' \
    --gtest_output="xml:${OUT_DIR}/arrow_verify_results.xml" \
    > "${OUT_DIR}/arrow_verify.log" 2>&1
status=$?
set -e

tail -n 200 "${OUT_DIR}/arrow_verify.log" || true

if [ "$status" -ne 0 ]; then
    echo "verify: ArrowVerify suite failed (exit $status)" >&2
    exit "$status"
fi

# Guard against a filter that matches nothing (e.g. the suite never linked in):
# that would exit 0 with zero tests and silently pass.
if ! grep -q '\[  PASSED  \]' "${OUT_DIR}/arrow_verify.log"; then
    echo "verify: no ArrowVerify tests ran — suite not linked into the binary?" >&2
    exit 1
fi
if grep -qE '\[  PASSED  \] 0 tests' "${OUT_DIR}/arrow_verify.log"; then
    echo "verify: ArrowVerify filter matched zero tests" >&2
    exit 1
fi

echo "verify: ArrowVerify suite passed."
