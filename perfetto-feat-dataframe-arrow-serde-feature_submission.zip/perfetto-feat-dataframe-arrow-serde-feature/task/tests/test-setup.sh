#!/usr/bin/env bash
# test-setup.sh — sourced by tests/test.sh before every verifier runs
# (set -euo pipefail inherited from test.sh).
#
# Performs the incremental rebuild of the unit-test binary after the agent's
# edits, then re-links perfetto_unittests. The image pre-built the whole
# out/dist tree at image-build time (gn gen + a full `ninja perfetto_unittests`
# against the pinned base commit), so this incremental step only recompiles the
# translation units the agent touched and re-links — typically well under a
# minute.
#
# The agent works offline; the image baked the entire dependency closure
# (hermetic gn/ninja + the C++ third-party source trees via
# tools/install-build-deps, plus the distro clang-14/libc++ toolchain). There
# is nothing to fetch here — no project install runs online. This script must
# therefore run with the network cut (the smoke gate sources it inside
# `docker run --network none`).
set -euo pipefail

cd /repo/perfetto

# Interpreter for the small, offline BUILD.gn text edits below. These are build
# wiring, not grading infrastructure, so any Python 3 serves; prefer the baked
# verifier runtime when test.sh has already exported it, else the system python.
_SETUP_PY="${VERIFIER_PYTHON:-python3}"

# ── Stage + wire the native verifier translation unit ───────────────────────
# The verifier is a self-contained gtest translation unit shipped under
# /tests/verify/. Copy it next to the dataframe module where GN expects module
# sources, then add it — plus the few build dependencies it needs — to the
# dataframe *unit-test* source set. The edit is scoped to the unittest target
# block (NOT the library target, which the solving agent may have given the same
# deps), and is fully idempotent: the copy overwrites, and every insertion is
# applied only when absent from that block, so re-runs and the agent's own
# BUILD.gn edits never double-insert.
DF_DIR="src/trace_processor/core/dataframe"
VERIFY_TU="arrow_verify_unittest.cc"
SRC_TU="/tests/verify/${VERIFY_TU}"
DST_TU="${DF_DIR}/${VERIFY_TU}"
BUILD_GN="${DF_DIR}/BUILD.gn"

if [ ! -f "$SRC_TU" ]; then
    echo "test-setup: verifier TU $SRC_TU missing" >&2
    exit 1
fi
cp "$SRC_TU" "$DST_TU"

if [ ! -f "$BUILD_GN" ]; then
    echo "test-setup: $BUILD_GN missing" >&2
    exit 1
fi

# Scoped, idempotent GN wiring. Operates only within the
# perfetto_unittest_source_set("unittests") { ... } block so the library
# target (which the oracle/agent edit touches with overlapping dep labels) is
# never the match surface.
"$_SETUP_PY" - "$BUILD_GN" "$VERIFY_TU" <<'PY'
import re
import sys

path, tu = sys.argv[1], sys.argv[2]
deps_to_add = [
    "../../util:flatbuffer_reader",
    "../../util:trace_blob_view_reader",
    "../../../../include/perfetto/trace_processor:util",
]
text = open(path).read()

# Locate the unittest target block and bound it by brace matching.
m = re.search(r'perfetto_unittest_source_set\("unittests"\)\s*\{', text)
if not m:
    sys.exit(f"test-setup: unittest source set not found in {path}")
block_start = m.end() - 1  # at the opening brace
depth, i = 0, block_start
while i < len(text):
    if text[i] == "{":
        depth += 1
    elif text[i] == "}":
        depth -= 1
        if depth == 0:
            break
    i += 1
block_end = i
block = text[block_start:block_end]


def insert_into_list(block, list_name, entry):
    """Insert "entry" into the named GN list inside block, if not already there."""
    lm = re.search(r'\b' + re.escape(list_name) + r'\s*=\s*\[', block)
    if not lm:
        sys.exit(f"test-setup: {list_name} list not found in unittests block")
    # Find the matching close bracket for this list.
    depth, j = 0, lm.end() - 1
    while j < len(block):
        if block[j] == "[":
            depth += 1
        elif block[j] == "]":
            depth -= 1
            if depth == 0:
                break
        j += 1
    list_body = block[lm.end():j]
    if f'"{entry}"' in list_body:
        return block  # already present
    # Indentation from the first existing entry, else a 4-space default.
    em = re.search(r'\n(\s*)"', list_body)
    indent = em.group(1) if em else "    "
    new_body = list_body.rstrip("\n ") + f'\n{indent}"{entry}",\n' + " " * (len(indent) - 2 if len(indent) >= 2 else 0)
    return block[:lm.end()] + new_body + block[j:]


block = insert_into_list(block, "sources", tu)
for dep in deps_to_add:
    block = insert_into_list(block, "deps", dep)

text = text[:block_start] + block + text[block_end:]
open(path, "w").write(text)
PY

# The reward stage adds its gtest translation unit to the dataframe unit-test
# source set and re-runs `gn gen` only if it changed the build graph. gn gen is
# cheap and idempotent; re-running it here keeps the build description in sync
# with whatever sources the agent (and the verifier) added, using the exact
# arch-neutral toolchain the image was configured with. All inputs are already
# on disk, so this never touches the network.
tools/gn gen out/dist \
    --args='is_debug=true is_hermetic_clang=false is_clang=true cc="clang" cxx="clang++"' \
    > /tmp/test-setup-gn.log 2>&1 \
  || { echo "test-setup: gn gen failed" >&2; tail -n 120 /tmp/test-setup-gn.log >&2; exit 1; }

# Incremental rebuild: ninja recomputes the dependency graph and rebuilds only
# the translation units the agent (and the staged suite TU) touched, then
# re-links the unit-test binary.
#
# This step is deliberately NON-fatal. The staged suite translation unit binds
# by #include and symbol to the module's new public entry points; a tree that
# has not introduced them cannot compile/link that TU, and ninja then leaves the
# image's pre-built binary in place (it carries none of the staged suite's
# cases). That outcome is not an infrastructure death to abort on — it is a
# state the suite runner is designed to observe and report: verify.sh runs the
# staged suite's filter against whatever binary exists and fails loudly when the
# filter matches zero cases (the TU never linked in). Aborting here instead
# would discard that signal and surface as an opaque missing-result. So log the
# failure in full and continue; the suite runner is the authority on the result.
echo "test-setup: incremental rebuild of perfetto_unittests..."
if ! tools/ninja -C out/dist perfetto_unittests > /tmp/test-setup-ninja.log 2>&1; then
    echo "test-setup: incremental rebuild did not complete; the staged suite may" >&2
    echo "test-setup: not link against this tree. Leaving the existing binary for" >&2
    echo "test-setup: the suite runner to evaluate. Build log tail:" >&2
    tail -n 160 /tmp/test-setup-ninja.log >&2
fi

# Confirm a runnable binary exists at all. If even the image's pre-built binary
# is gone, there is nothing for the suite runner to evaluate — that IS an
# infrastructure fault, so abort.
if [ ! -x out/dist/perfetto_unittests ]; then
    echo "test-setup: out/dist/perfetto_unittests missing or non-executable" >&2
    exit 1
fi

echo "test-setup: ready."
