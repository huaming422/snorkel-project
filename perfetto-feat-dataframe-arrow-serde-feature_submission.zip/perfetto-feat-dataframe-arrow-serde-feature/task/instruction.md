## Task

We want trace_processor dataframes to go out to disk and come back: add serialization of a finalized dataframe to the Apache Arrow format, and deserialization back into a dataframe. This work lives in `src/trace_processor/core/dataframe/`: put the serializer in `arrow_serializer.h` / `arrow_serializer.cc` and the deserializer in `arrow_deserializer.h` / `arrow_deserializer.cc`, exposing the public entry points named below.

Serialization produces a standard Arrow file holding the whole dataframe as one record batch, in the on-disk Arrow columnar / IPC "file" format with its magic markers. It is a two-step contract on a serializer object named `ArrowSerializer`: a `Prepare` step takes the finalized dataframe and its string pool and returns the exact output size; a `Write` step then streams the bytes through a caller-supplied sink callback. `Prepare` runs before `Write`; the dataframe must be finalized, and neither it nor the string pool may change between the steps. Stream with bounded working memory rather than one full buffer, surface a sink-callback error back to the caller, and let one serializer handle several dataframes.

Numeric columns map to Arrow numeric arrays, string columns to Arrow's variable-length UTF-8 type, and columns allowing missing values to a validity bitmap plus null count. The implicit id column is a logical row index, not stored data: leave it out and rebuild it on read. Columns that store only present values expand to Arrow's dense layout, every logical row present with gaps marked in the validity bitmap.

Deserialization is a function named `DeserializeFromArrow` that takes the bytes (through the module's incremental byte-reader), the target string pool, and the full dataframe schema, and returns a freshly built, finalized dataframe. The schema is passed separately because the Arrow form carries none of perfetto's column properties (null storage, sort, duplicate state). Validate before reading any column data: check the file framing, record-batch metadata, and every buffer's extent, erroring on malformed, truncated, or inconsistent input rather than crashing or reading out of bounds. It need only accept the layout this serializer emits.

Expose exactly these public entry points, using the module's existing `StringPool` (`src/trace_processor/containers/string_pool.h`) and `util::TraceBlobViewReader` (`src/trace_processor/util/trace_blob_view_reader.h`):

    class ArrowSerializer {
     public:
      using WriteFn = std::function<base::Status(const uint8_t*, size_t)>;
      base::StatusOr<size_t> Prepare(const Dataframe&, const StringPool*);
      base::Status Write(const Dataframe&, const StringPool*, const WriteFn&);
    };

    base::StatusOr<Dataframe> DeserializeFromArrow(
        const util::TraceBlobViewReader&, StringPool*, const DataframeSpec&);

## User stories / requirements

- A finalized dataframe written out to the Arrow format and then read back reproduces the original exactly: the same rows, the same values in every column, and the same pattern of present and missing entries. What comes back is a fully usable, finalized dataframe.
- The written-out form is a genuine Arrow file, not a private encoding only this code can make sense of. Standard, independent Arrow tooling can open it and read its rows and columns back without any special knowledge of how it was produced.
