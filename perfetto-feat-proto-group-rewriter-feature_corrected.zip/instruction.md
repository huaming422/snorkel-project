## Task

SMB v2 producers hand us packets that still use proto-group framing: a nested message starts with a start-group tag, ends with a bare 0x04 byte and carries no length. Everything that reads the buffer back only understands ordinary length-delimited protobuf. So TraceBufferV2 has to take those producers' batches and give back plain length-delimited packets that decode to the same thing. That takes two pieces: a rewriter that lives beside TraceBufferV2 and builds into the service, and an SMB v2 path in TraceBufferV2 that stores the batches and rewrites each packet as it's read.

Rewrite() takes one reassembled packet, which can be big and spread over several non-empty slices in order. Other code compiles against these declarations, so keep their shape:

```cpp
// #include "src/tracing/service/proto_group_rewriter.h"
namespace perfetto::tracing_v2 {

// What a single Rewrite() call did.
enum class RewriteResult {
  kRewritten,       // the new packet is in *out
  kUnchanged,       // nothing to rewrite; *out is not touched, use the input
  kMalformedInput,  // rejected; *out is not touched
  kGroupTooLarge,   // a group's content came out over the maximum message
                    // size; *out is not touched
};

class ProtoGroupRewriter {
 public:
  // Deepest group nesting that is accepted.
  static constexpr std::size_t kMaxNestingDepth = 1024;
  // Converts one reassembled packet.
  RewriteResult Rewrite(const Slices& packet, std::optional<Slice>* out);
};

}  // namespace perfetto::tracing_v2

// New public methods of perfetto::TraceBufferV2.

// Stores one ordered batch of a writer's fragments. Each fragment is a whole
// packet, except that the first can continue the writer's previous batch and
// the last can continue in its next one. An empty fragment can have a null
// data pointer. Returns true if the batch was stored. A batch with no
// fragments is refused and changes nothing.
bool CopyChunkV2Untrusted(const PacketSequenceProperties& sequence,
                          const protozero::ConstBytes* fragments,
                          size_t num_fragments,
                          bool first_continues_from_prev,
                          bool last_continues_on_next);

// The transport lost this writer's data after its last stored batch.
void RecordChunkV2DataLoss(ProducerID, WriterID);
```

TraceStats.BufferStats gets an optional uint64 oversized_packets_dropped for SMB v2 packets dropped because a group in them is over the size limit.

It all has to build warning-free in our hermetic clang config (gn args is_debug=true), which uses -Weverything and -Werror; the prebuilt out/dist came from the system clang and hides those warnings.

## User stories / requirements

- Rewriting a packet with groups should give me something that decodes to exactly what the groups held, wherever the slice boundaries fell, and a group with 127 bytes of content or less gets a one-byte length. If the packet has no groups I get `kUnchanged` and keep using my own slices.
- Broken input gets `kMalformedInput` and no output: field id 0, wire type 6 or 7, a standard end-group tag, a varint cut short or past ten bytes, a fixed or length-delimited value missing bytes, an unclosed group, or a top-level 0x04. The next good packet on that same rewriter still converts.
- Nesting tops out at 1024 levels. That deep still converts; at 1025 I want `kMalformedInput` and no output even if every group is closed.
- Reading back gives me each SMB v2 writer's packets in order, already rewritten and joined across batches, beside SMB writers. Empty fragments are skipped, a packet I've read stays valid after later reads and writes, and every stored batch counts once in chunks_written and, when overwritten, is reported as an SMB chunk would be.
- A packet the rewriter refuses is dropped, counted in abi_violations or oversized_packets_dropped, flagging the writer's next packet DATA_LOSS_CHUNK_CORRUPTED. A writer ID keeps its first format. Malformed batches, ones too big for a buffer chunk or the buffer, and the other format are ABI violations; a full discard buffer or ProtoVM producer counts in chunks_discarded.
- A loss I record, or a non-empty batch the buffer refuses, shows up as DATA_LOSS_READ_GAP on that writer's first packet stored afterwards, never on ones already stored, and a packet split across it is dropped. A loss for an SMB or unknown writer does nothing, and a clone keeps every loss not yet read.
