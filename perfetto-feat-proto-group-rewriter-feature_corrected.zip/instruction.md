## Task

SMB v2 producers hand us packets that still use proto-group framing: a nested message starts with a start-group tag, ends with a bare 0x04 byte and carries no length. Everything that reads the buffer back only understands ordinary length-delimited protobuf. I need a standalone rewriter in src/tracing/service that rewrites one reassembled packet as plain length-delimited protobuf decoding to the same thing, plus the GN wiring that builds it into the service. Hooking it into TraceBufferV2 and the loss and stats bookkeeping is a separate change.

A packet arrives as non-empty slices in order (the existing Slices and Slice types) and may span several of them. Other code will compile against this header, so keep this shape:

```cpp
// declared in proto_group_rewriter.h, defined in proto_group_rewriter.cc
namespace perfetto::tracing_v2 {

// What a single Rewrite() call did.
enum class RewriteResult {
  kRewritten,       // the new packet is in *out
  kUnchanged,       // nothing to rewrite; *out stays empty, use the input
  kMalformedInput,  // rejected; *out is not touched
  kGroupTooLarge,   // rejected; *out is not touched
};

class ProtoGroupRewriter {
 public:
  // Deepest group nesting that is accepted.
  static constexpr std::size_t kMaxNestingDepth = 1024;
  // Converts one reassembled packet.
  RewriteResult Rewrite(const Slices& packet, std::optional<Slice>* out);
};

}  // namespace perfetto::tracing_v2
```

How it works inside is up to you. It does have to compile cleanly in our usual hermetic clang setup (gn args of just is_debug=true), which builds with -Weverything and -Werror. The prebuilt out/dist was generated against the system clang and won't show you those warnings.

## User stories / requirements

- When I rewrite a packet with groups in it, decoding the result gives me back exactly what the groups held, however the packet was split across slices. A group with 127 bytes of content or less comes out with a single length byte. No groups at all and I get `kUnchanged` and use my slices.
- When I feed it a broken packet (field id 0, wire type 6 or 7, a standard end-group tag, a truncated or overlong varint, a short fixed or length-delimited value, a group never closed or a 0x04 at the top level), I get `kMalformedInput` and no output, and a good packet afterwards still converts.
- When I nest groups 1024 deep the packet converts, but at 1025 deep, even with every group closed, or after a long run of start tags that never close, I get `kMalformedInput` and no output.
