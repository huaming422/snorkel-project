## Task

SMB v2 producers hand us packets that still use proto-group framing: a nested message starts with a start-group tag, ends with a bare 0x04 byte and carries no length. Everything that reads the buffer back only understands ordinary length-delimited protobuf. I need a standalone rewriter in src/tracing/service that rewrites one reassembled packet as plain length-delimited protobuf decoding to the same thing, plus the GN wiring that builds it into the service. Hooking it into TraceBufferV2 and the loss and stats bookkeeping is a separate change.

A packet arrives as non-empty slices in order (the existing Slices and Slice types) and may span several of them. Other code will compile against this header, so keep this shape:

```cpp
// declared in proto_group_rewriter.h, defined in proto_group_rewriter.cc
namespace perfetto::tracing_v2 {

// What a single Rewrite() call did.
enum class RewriteResult {
  kRewritten,       // the new packet is in *out
  kUnchanged,       // nothing to rewrite; *out is not touched, use the input
  kMalformedInput,  // rejected; *out is not touched
  kGroupTooLarge,   // a group came out over proto_utils::kMaxMessageLength
                    // bytes of content; *out is not touched
};

class ProtoGroupRewriter {
 public:
  // Deepest group nesting that is accepted.
  static constexpr std::size_t kMaxNestingDepth = 1024;
  // Converts one reassembled packet.
  RewriteResult Rewrite(const Slices& packet, std::optional<Slice>* out);
};

}  // namespace perfetto::tracing_v2
```

It will run on every packet read back from the buffer, and a packet can be big and spread over many slices. It has to compile cleanly in our usual hermetic clang setup (gn args of just is_debug=true), which builds with -Weverything and -Werror. The prebuilt out/dist was generated against the system clang and won't show you those warnings.

## User stories / requirements

- Rewriting a packet with groups should give me something that decodes to exactly what the groups held, wherever the slice boundaries fell, and a group with 127 bytes of content or less gets a one-byte length. If the packet has no groups I get `kUnchanged` and keep using my own slices.
- Broken input is refused with `kMalformedInput` and no output: field id 0, wire type 6 or 7, a standard end-group tag, a varint that's cut short or runs past ten bytes, a fixed or length-delimited value missing bytes, a group that never closes, or a 0x04 at the top level. I reuse one rewriter for many packets, so the next good packet I hand it after a bad one has to convert.
- Nesting tops out at 1024 levels. That deep still converts; at 1025 I want `kMalformedInput` and no output even if every group is closed, and the same for a long run of start tags that never close.
