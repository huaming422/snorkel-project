// smb_v2_buffer_cli.cc, validation harness (not part of the
// repo). Compiled by validation-setup.sh against TraceBufferV2's public
// methods: Create(), CopyChunkV2Untrusted(), RecordChunkV2DataLoss(),
// CopyChunkUntrusted(), BeginRead(), ReadNextTracePacket() and stats().
//
// stdin, one command per line, run in order against one buffer:
//
//   buffer <size_bytes> <overwrite|discard>   new buffer; prints OK
//   append <producer> <writer> <first_continues 0|1> <last_continues 0|1> <frags>
//       one SMB v2 batch; prints STORED or REFUSED. <frags> is a
//       comma-separated list of fragments, each lowercase hex (empty for an
//       empty fragment) or fill:<byte hex>:<count>. A lone "-" sends zero
//       fragments.
//   loss <producer> <writer>                  RecordChunkV2DataLoss(); prints OK
//   smb <producer> <writer> <chunk_id> <hex>  one legacy SMB chunk holding one
//                                             packet; prints OK
//   read                                      BeginRead(), then every packet:
//       PACKET <producer> <writer> <loss flags, decimal> <bytes as hex>
//       followed by END
//   stats
//       STATS abi_violations=N chunks_discarded=N oversized_packets_dropped=N
//             chunks_written=N chunks_overwritten=N   (one line)
//
// Every sequence uses uid 42. exit 0 when all commands parsed, exit 2 on a
// malformed command line.

#include "src/tracing/service/trace_buffer_v2.h"

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <memory>
#include <sstream>
#include <string>
#include <vector>

#include "perfetto/ext/tracing/core/client_identity.h"
#include "perfetto/ext/tracing/core/trace_packet.h"
#include "perfetto/protozero/field.h"

namespace {

using perfetto::ClientIdentity;
using perfetto::TraceBuffer;
using perfetto::TraceBufferV2;

[[noreturn]] void Misuse(const std::string& line) {
  std::cerr << "smb_v2_buffer_cli: cannot parse: " << line << "\n";
  std::exit(2);
}

bool HexToBytes(const std::string& hex, std::vector<uint8_t>* out) {
  if (hex.size() % 2 != 0)
    return false;
  out->clear();
  for (size_t i = 0; i < hex.size(); i += 2) {
    char* end = nullptr;
    std::string two = hex.substr(i, 2);
    unsigned long v = std::strtoul(two.c_str(), &end, 16);
    if (end != two.c_str() + 2)
      return false;
    out->push_back(static_cast<uint8_t>(v));
  }
  return true;
}

std::string BytesToHex(const std::vector<uint8_t>& bytes) {
  static const char kDigits[] = "0123456789abcdef";
  std::string out;
  out.reserve(bytes.size() * 2);
  for (uint8_t b : bytes) {
    out.push_back(kDigits[b >> 4]);
    out.push_back(kDigits[b & 0xf]);
  }
  return out;
}

bool ParseFragment(const std::string& token, std::vector<uint8_t>* out) {
  if (token.rfind("fill:", 0) == 0) {
    size_t colon = token.find(':', 5);
    if (colon == std::string::npos)
      return false;
    std::vector<uint8_t> byte;
    if (!HexToBytes(token.substr(5, colon - 5), &byte) || byte.size() != 1)
      return false;
    char* end = nullptr;
    unsigned long long count = std::strtoull(token.c_str() + colon + 1, &end, 10);
    if (*end != '\0')
      return false;
    out->assign(static_cast<size_t>(count), byte[0]);
    return true;
  }
  return HexToBytes(token, out);
}

std::vector<std::string> SplitCommas(const std::string& s) {
  std::vector<std::string> parts;
  size_t start = 0;
  for (;;) {
    size_t comma = s.find(',', start);
    parts.push_back(s.substr(start, comma - start));
    if (comma == std::string::npos)
      break;
    start = comma + 1;
  }
  return parts;
}

}  // namespace

int main() {
  std::unique_ptr<TraceBufferV2> buf;
  std::string line;
  while (std::getline(std::cin, line)) {
    if (line.empty())
      continue;
    std::istringstream in(line);
    std::string cmd;
    in >> cmd;

    if (cmd == "buffer") {
      size_t size = 0;
      std::string policy;
      if (!(in >> size >> policy) ||
          (policy != "overwrite" && policy != "discard"))
        Misuse(line);
      buf = TraceBufferV2::Create(
          size, policy == "discard" ? TraceBuffer::kDiscard
                                    : TraceBuffer::kOverwrite);
      if (!buf)
        Misuse(line);
      std::cout << "OK\n";
      continue;
    }
    if (!buf)
      Misuse(line);

    if (cmd == "append") {
      uint32_t producer = 0, writer = 0;
      int first = 0, last = 0;
      std::string frags;
      if (!(in >> producer >> writer >> first >> last))
        Misuse(line);
      std::getline(in >> std::ws, frags);
      std::vector<std::vector<uint8_t>> storage;
      if (frags != "-") {
        for (const std::string& token : SplitCommas(frags)) {
          storage.emplace_back();
          if (!ParseFragment(token, &storage.back()))
            Misuse(line);
        }
      }
      std::vector<protozero::ConstBytes> views;
      for (const auto& f : storage)
        views.push_back({f.empty() ? nullptr : f.data(), f.size()});
      TraceBuffer::PacketSequenceProperties seq{
          static_cast<perfetto::ProducerID>(producer), ClientIdentity(42, 0),
          static_cast<perfetto::WriterID>(writer)};
      bool stored = buf->CopyChunkV2Untrusted(
          seq, views.empty() ? nullptr : views.data(), views.size(),
          first != 0, last != 0);
      std::cout << (stored ? "STORED" : "REFUSED") << "\n";
    } else if (cmd == "loss") {
      uint32_t producer = 0, writer = 0;
      if (!(in >> producer >> writer))
        Misuse(line);
      buf->RecordChunkV2DataLoss(static_cast<perfetto::ProducerID>(producer),
                                 static_cast<perfetto::WriterID>(writer));
      std::cout << "OK\n";
    } else if (cmd == "smb") {
      uint32_t producer = 0, writer = 0, chunk_id = 0;
      std::string hex;
      std::vector<uint8_t> payload;
      if (!(in >> producer >> writer >> chunk_id >> hex) ||
          !HexToBytes(hex, &payload) || payload.size() > 127)
        Misuse(line);
      std::vector<uint8_t> chunk;
      chunk.push_back(static_cast<uint8_t>(payload.size()));
      chunk.insert(chunk.end(), payload.begin(), payload.end());
      buf->CopyChunkUntrusted(
          static_cast<perfetto::ProducerID>(producer), ClientIdentity(42, 0),
          static_cast<perfetto::WriterID>(writer),
          static_cast<perfetto::ChunkID>(chunk_id), /*num_fragments=*/1,
          /*chunk_flags=*/0, /*chunk_complete=*/true, chunk.data(),
          chunk.size());
      std::cout << "OK\n";
    } else if (cmd == "read") {
      buf->BeginRead();
      for (;;) {
        perfetto::TracePacket packet;
        TraceBuffer::PacketSequenceProperties props{};
        uint32_t loss = 0;
        if (!buf->ReadNextTracePacket(&packet, &props, &loss))
          break;
        std::vector<uint8_t> bytes;
        for (const perfetto::Slice& s : packet.slices()) {
          const uint8_t* p = static_cast<const uint8_t*>(s.start);
          bytes.insert(bytes.end(), p, p + s.size);
        }
        std::cout << "PACKET " << props.producer_id_trusted << " "
                  << props.writer_id << " " << loss << " " << BytesToHex(bytes)
                  << "\n";
      }
      std::cout << "END\n";
    } else if (cmd == "stats") {
      const auto& st = buf->stats();
      std::cout << "STATS abi_violations=" << st.abi_violations()
                << " chunks_discarded=" << st.chunks_discarded()
                << " oversized_packets_dropped="
                << st.oversized_packets_dropped()
                << " chunks_written=" << st.chunks_written()
                << " chunks_overwritten=" << st.chunks_overwritten() << "\n";
    } else {
      Misuse(line);
    }
  }
  return 0;
}
