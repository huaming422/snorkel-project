// proto_group_rewrite_cli.cc, reward-owned validation harness (NOT in the
// agent repo). Compiled by validation-setup.sh against the AGENT's public
// contract only:
//
//   #include "src/tracing/service/proto_group_rewriter.h"
//   perfetto::tracing_v2::ProtoGroupRewriter
//   perfetto::tracing_v2::RewriteResult { kRewritten, kUnchanged,
//                                         kMalformedInput, kGroupTooLarge }
//   RewriteResult Rewrite(const Slices& input, std::optional<Slice>* output);
//
// It names NO internal symbol, so EVERY valid implementation links against it.
//
// I/O contract (harness-owned, a pure test fixture the agent never reads or
// defines; stable across all solutions):
//
//   stdin  : one or more packets, each written as
//            line 1 = N (slice count, decimal), then
//            next N lines = one slice each, lowercase hex (may be empty for a
//            zero-length slice, though the contract uses non-empty slices,
//            the harness tolerates empties by representing them as "").
//            All packets go through the same ProtoGroupRewriter, in order.
//   stdout : per packet, line 1 = one of UNCHANGED | REWRITTEN | MALFORMED |
//                     TOO_LARGE
//            line 2 = for REWRITTEN only, the rewritten output bytes as
//                     lowercase hex (empty line if zero-length). For
//                     UNCHANGED/MALFORMED/TOO_LARGE no second line is written
//                     (output is, by contract, unset/untouched).
//            Each packet starts with an unset output. If Rewrite() sets it
//            for UNCHANGED/MALFORMED/TOO_LARGE, line 1 gets a _WITH_OUTPUT
//            suffix; REWRITTEN with the output left unset prints
//            REWRITTEN_NO_OUTPUT and no second line.
//   exit   : always 0 on a well-formed invocation; the result is on stdout.
//            exit 2 only on harness misuse (unreadable input / bad hex).

#include "src/tracing/service/proto_group_rewriter.h"

#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <optional>
#include <string>
#include <vector>

#include "perfetto/ext/tracing/core/slice.h"

namespace {

bool HexToBytes(const std::string& hex, std::vector<uint8_t>* out) {
  if (hex.size() % 2 != 0)
    return false;
  out->clear();
  out->reserve(hex.size() / 2);
  auto nibble = [](char c, int* v) -> bool {
    if (c >= '0' && c <= '9') { *v = c - '0'; return true; }
    if (c >= 'a' && c <= 'f') { *v = c - 'a' + 10; return true; }
    if (c >= 'A' && c <= 'F') { *v = c - 'A' + 10; return true; }
    return false;
  };
  for (size_t i = 0; i < hex.size(); i += 2) {
    int hi, lo;
    if (!nibble(hex[i], &hi) || !nibble(hex[i + 1], &lo))
      return false;
    out->push_back(static_cast<uint8_t>((hi << 4) | lo));
  }
  return true;
}

std::string BytesToHex(const uint8_t* data, size_t size) {
  static const char* kHex = "0123456789abcdef";
  std::string s;
  s.reserve(size * 2);
  for (size_t i = 0; i < size; ++i) {
    s.push_back(kHex[data[i] >> 4]);
    s.push_back(kHex[data[i] & 0x0f]);
  }
  return s;
}

// Reads one packet's slices into |storage| and |slices|. Returns 1 on a clean
// end of input, 2 on harness misuse and 0 when a packet was read.
int ReadPacket(std::vector<std::vector<uint8_t>>* storage,
               perfetto::Slices* slices) {
  std::string first;
  if (!std::getline(std::cin, first))
    return 1;
  // Perfetto compiles with -fno-exceptions, so parse with strtol (no stol/throw).
  errno = 0;
  char* end = nullptr;
  long n = std::strtol(first.c_str(), &end, 10);
  if (end == first.c_str() || *end != '\0' || errno != 0) {
    std::fprintf(stderr, "cli: slice count is not a number: %s\n", first.c_str());
    return 2;
  }
  if (n < 0) {
    std::fprintf(stderr, "cli: negative slice count\n");
    return 2;
  }

  // Own the backing storage for the lifetime of the Rewrite() call; Slice is a
  // (pointer,size) view, so the vectors must outlive |slices|.
  storage->clear();
  storage->reserve(static_cast<size_t>(n));
  slices->clear();
  for (long i = 0; i < n; ++i) {
    std::string line;
    if (!std::getline(std::cin, line)) {
      std::fprintf(stderr, "cli: expected %ld slices, got %ld\n", n, i);
      return 2;
    }
    // Strip a trailing CR if the input used CRLF.
    if (!line.empty() && line.back() == '\r')
      line.pop_back();
    std::vector<uint8_t> bytes;
    if (!HexToBytes(line, &bytes)) {
      std::fprintf(stderr, "cli: bad hex on slice %ld: %s\n", i, line.c_str());
      return 2;
    }
    storage->push_back(std::move(bytes));
    slices->emplace_back(storage->back().data(), storage->back().size());
  }
  return 0;
}

}  // namespace

int main() {
  using perfetto::Slice;
  using perfetto::Slices;
  using perfetto::tracing_v2::ProtoGroupRewriter;
  using perfetto::tracing_v2::RewriteResult;

  ProtoGroupRewriter rewriter;
  std::vector<std::vector<uint8_t>> storage;
  Slices slices;
  for (size_t packet = 0;; ++packet) {
    const int read = ReadPacket(&storage, &slices);
    if (read == 2)
      return 2;
    if (read == 1) {
      if (packet == 0) {
        std::fprintf(stderr, "cli: missing slice count on line 1\n");
        return 2;
      }
      break;
    }

    std::optional<Slice> output;
    RewriteResult result = rewriter.Rewrite(slices, &output);
    const char* suffix = output.has_value() ? "_WITH_OUTPUT" : "";

    switch (result) {
      case RewriteResult::kUnchanged:
        std::printf("UNCHANGED%s\n", suffix);
        break;
      case RewriteResult::kRewritten: {
        if (!output.has_value()) {
          std::printf("REWRITTEN_NO_OUTPUT\n");
          break;
        }
        std::printf("REWRITTEN\n");
        std::string hex = BytesToHex(static_cast<const uint8_t*>(output->start),
                                     output->size);
        std::printf("%s\n", hex.c_str());
        break;
      }
      case RewriteResult::kMalformedInput:
        std::printf("MALFORMED%s\n", suffix);
        break;
      case RewriteResult::kGroupTooLarge:
        std::printf("TOO_LARGE%s\n", suffix);
        break;
    }
  }
  return 0;
}
