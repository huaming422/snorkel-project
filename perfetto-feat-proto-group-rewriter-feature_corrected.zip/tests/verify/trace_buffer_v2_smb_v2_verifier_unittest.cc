/*
 * Copyright (C) 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// SMB v2 batches stored in TraceBufferV2 and read back. Every case goes
// through the buffer's public methods only: CopyChunkV2Untrusted(),
// RecordChunkV2DataLoss(), CopyChunkUntrusted() for SMB chunks,
// ReadNextTracePacket(), CloneReadOnly() and stats().

#include <stddef.h>
#include <stdint.h>

#include <algorithm>
#include <map>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "perfetto/ext/tracing/core/basic_types.h"
#include "perfetto/ext/tracing/core/client_identity.h"
#include "perfetto/ext/tracing/core/trace_packet.h"
#include "perfetto/protozero/field.h"
#include "perfetto/protozero/proto_decoder.h"
#include "perfetto/protozero/proto_utils.h"
#include "protos/perfetto/trace/trace_packet.pbzero.h"
#include "src/tracing/service/trace_buffer_v2.h"
#include "src/tracing/test/fake_packet.h"
#include "test/gtest_and_gmock.h"

namespace perfetto {
namespace {

namespace pu = ::protozero::proto_utils;
using DataLossReason = protos::pbzero::TracePacket_DataLossReason;
using Bytes = std::vector<uint8_t>;

constexpr uint32_t kPresent = DataLossReason::DATA_LOSS_PRESENT;
constexpr uint32_t kReadGap = DataLossReason::DATA_LOSS_READ_GAP;
constexpr uint32_t kCorrupted = DataLossReason::DATA_LOSS_CHUNK_CORRUPTED;
constexpr uint32_t kOverwrite = DataLossReason::DATA_LOSS_OVERWRITE;

void AppendVarInt(uint64_t value, Bytes* out) {
  uint8_t tmp[pu::kMaxSimpleFieldEncodedSize];
  uint8_t* end = pu::WriteVarInt(value, tmp);
  out->insert(out->end(), tmp, end);
}

// One varint field.
Bytes VarIntField(uint32_t field_id, uint64_t value) {
  Bytes out;
  AppendVarInt(pu::MakeTagVarInt(field_id), &out);
  AppendVarInt(value, &out);
  return out;
}

// One length-delimited field holding |payload|.
Bytes BytesField(uint32_t field_id, const Bytes& payload) {
  Bytes out;
  AppendVarInt(pu::MakeTagLengthDelimited(field_id), &out);
  AppendVarInt(payload.size(), &out);
  out.insert(out.end(), payload.begin(), payload.end());
  return out;
}

// A start-group tag, |content|, then the bare 0x04 end byte.
Bytes Group(uint32_t field_id, const Bytes& content) {
  Bytes out;
  AppendVarInt(pu::MakeTagStartGroup(field_id), &out);
  out.insert(out.end(), content.begin(), content.end());
  out.push_back(0x04);
  return out;
}

Bytes Concat(std::initializer_list<Bytes> parts) {
  Bytes out;
  for (const Bytes& p : parts)
    out.insert(out.end(), p.begin(), p.end());
  return out;
}

// A packet of |size| bytes made of one varint field 1 (the packet's number)
// followed by a bytes field 2 of filler.
Bytes NumberedPacket(uint64_t number, size_t size) {
  Bytes head = VarIntField(1, number);
  const size_t overhead = head.size() + 1 + (size > 130 ? 2 : 1);
  Bytes filler(size > overhead ? size - overhead : 0, 0x5a);
  Bytes out = Concat({head, BytesField(2, filler)});
  return out;
}

uint64_t PacketNumber(const Bytes& packet) {
  protozero::ProtoDecoder dec(packet.data(), packet.size());
  protozero::Field f = dec.FindField(1);
  return f.valid() ? f.as_uint64() : UINT64_MAX;
}

struct ReadResult {
  ProducerID producer = 0;
  WriterID writer = 0;
  uid_t uid = 0;
  uint32_t loss = 0;
  Bytes bytes;
};

class SmbV2BufferTest : public ::testing::Test {
 protected:
  void Reset(size_t size,
             TraceBuffer::OverwritePolicy policy = TraceBuffer::kOverwrite) {
    buf_ = TraceBufferV2::Create(size, policy);
    ASSERT_TRUE(buf_);
  }

  TraceBufferV2* buf() { return buf_.get(); }

  static TraceBuffer::PacketSequenceProperties Seq(ProducerID p,
                                                   WriterID w,
                                                   uid_t uid = 42) {
    return {p, ClientIdentity(uid, 0), w};
  }

  // Stores one batch. |frags| may hold empty fragments.
  bool Append(ProducerID p,
              WriterID w,
              const std::vector<Bytes>& frags,
              bool first_continues_from_prev = false,
              bool last_continues_on_next = false,
              uid_t uid = 42) {
    std::vector<protozero::ConstBytes> views;
    for (const Bytes& f : frags)
      views.push_back({f.empty() ? nullptr : f.data(), f.size()});
    return buf_->CopyChunkV2Untrusted(Seq(p, w, uid), views.data(),
                                      views.size(), first_continues_from_prev,
                                      last_continues_on_next);
  }

  void AppendSmbChunk(ProducerID p, WriterID w, ChunkID c, size_t size,
                      char seed) {
    FakeChunk(buf_.get(), p, w, c).AddPacket(size, seed).CopyIntoTraceBuffer();
  }

  // Reads the next packet without calling BeginRead().
  static bool ReadOne(TraceBuffer* b, ReadResult* r) {
    TracePacket packet;
    TraceBuffer::PacketSequenceProperties props{};
    uint32_t loss = 0;
    if (!b->ReadNextTracePacket(&packet, &props, &loss))
      return false;
    r->producer = props.producer_id_trusted;
    r->writer = props.writer_id;
    r->uid = props.producer_uid_trusted();
    r->loss = loss;
    r->bytes.clear();
    for (const Slice& s : packet.slices()) {
      const uint8_t* start = static_cast<const uint8_t*>(s.start);
      r->bytes.insert(r->bytes.end(), start, start + s.size);
    }
    return true;
  }

  // BeginRead(), then every packet available.
  static std::vector<ReadResult> ReadAll(TraceBuffer* b) {
    b->BeginRead();
    std::vector<ReadResult> out;
    ReadResult r;
    while (ReadOne(b, &r))
      out.push_back(r);
    return out;
  }

  std::vector<ReadResult> ReadAll() { return ReadAll(buf_.get()); }

  static std::vector<ReadResult> ForWriter(const std::vector<ReadResult>& all,
                                           ProducerID p,
                                           WriterID w) {
    std::vector<ReadResult> out;
    for (const ReadResult& r : all) {
      if (r.producer == p && r.writer == w)
        out.push_back(r);
    }
    return out;
  }

  std::unique_ptr<TraceBufferV2> buf_;
};

// ---------------------------------------------------------------------------
// Reading back
// ---------------------------------------------------------------------------

TEST_F(SmbV2BufferTest, WholePacketsComeBackRewrittenInOrder) {
  Reset(4096);
  const Bytes plain = VarIntField(1, 7);
  const Bytes grouped = Group(2, VarIntField(1, 5));
  const Bytes deep = Concat({VarIntField(3, 300),
                             Group(4, Concat({Group(5, VarIntField(1, 1)),
                                              BytesField(6, {0x04, 0x04})}))});
  ASSERT_TRUE(Append(1, 1, {plain, grouped, deep}));

  auto all = ReadAll();
  ASSERT_EQ(all.size(), 3u);
  for (const ReadResult& r : all) {
    EXPECT_EQ(r.producer, 1u);
    EXPECT_EQ(r.writer, 1u);
    EXPECT_EQ(r.uid, 42u);
    EXPECT_EQ(r.loss, 0u);
  }
  EXPECT_EQ(all[0].bytes, plain);
  EXPECT_EQ(all[1].bytes, (Bytes{0x12, 0x02, 0x08, 0x05}));
  EXPECT_EQ(all[2].bytes,
            (Bytes{0x18, 0xac, 0x02, 0x22, 0x08, 0x2a, 0x02, 0x08, 0x01, 0x32,
                   0x02, 0x04, 0x04}));

  EXPECT_TRUE(ReadAll().empty());
}

TEST_F(SmbV2BufferTest, PacketSplitAcrossBatchesIsReassembled) {
  Reset(4096);
  const Bytes before = VarIntField(9, 1);
  const Bytes split = Concat({Group(1, VarIntField(2, 100)), VarIntField(3, 1),
                              Group(4, Group(5, BytesField(1, {1, 2, 3})))});
  const Bytes after = VarIntField(9, 2);
  const auto a = static_cast<ptrdiff_t>(3);
  const auto b = static_cast<ptrdiff_t>(split.size() - 4);
  const Bytes p1(split.begin(), split.begin() + a);
  const Bytes p2(split.begin() + a, split.begin() + b);
  const Bytes p3(split.begin() + b, split.end());

  ASSERT_TRUE(Append(1, 1, {before, p1}, false, true));
  ASSERT_TRUE(Append(1, 1, {p2}, true, true));

  // The split packet is not complete yet.
  auto first = ReadAll();
  ASSERT_EQ(first.size(), 1u);
  EXPECT_EQ(first[0].bytes, before);

  ASSERT_TRUE(Append(1, 1, {p3, after}, true, false));
  auto second = ReadAll();
  ASSERT_EQ(second.size(), 2u);
  EXPECT_EQ(second[0].loss, 0u);
  EXPECT_EQ(second[0].bytes,
            (Bytes{0x0a, 0x02, 0x10, 0x64, 0x18, 0x01, 0x22, 0x07, 0x2a, 0x05,
                   0x0a, 0x03, 0x01, 0x02, 0x03}));
  EXPECT_EQ(second[1].loss, 0u);
  EXPECT_EQ(second[1].bytes, after);
}

TEST_F(SmbV2BufferTest, WritersAndProducersStayApart) {
  Reset(4096);
  ASSERT_TRUE(Append(1, 1, {VarIntField(1, 10)}, false, false, 42));
  ASSERT_TRUE(Append(1, 2, {VarIntField(1, 20)}, false, false, 42));
  ASSERT_TRUE(Append(2, 1, {Group(1, VarIntField(1, 30))}, false, false, 43));
  ASSERT_TRUE(Append(1, 1, {VarIntField(1, 11)}, false, false, 42));

  auto all = ReadAll();
  ASSERT_EQ(all.size(), 4u);
  auto w11 = ForWriter(all, 1, 1);
  auto w12 = ForWriter(all, 1, 2);
  auto w21 = ForWriter(all, 2, 1);
  ASSERT_EQ(w11.size(), 2u);
  ASSERT_EQ(w12.size(), 1u);
  ASSERT_EQ(w21.size(), 1u);
  EXPECT_EQ(w11[0].bytes, VarIntField(1, 10));
  EXPECT_EQ(w11[1].bytes, VarIntField(1, 11));
  EXPECT_EQ(w12[0].bytes, VarIntField(1, 20));
  EXPECT_EQ(w21[0].bytes, (Bytes{0x0a, 0x02, 0x08, 0x1e}));
  EXPECT_EQ(w21[0].uid, 43u);
  for (const ReadResult& r : all)
    EXPECT_EQ(r.loss, 0u);
}

TEST_F(SmbV2BufferTest, SmbAndSmbV2WritersShareTheBuffer) {
  Reset(4096);
  AppendSmbChunk(1, 3, 0, 10, 'a');
  ASSERT_TRUE(Append(1, 1, {Group(1, VarIntField(2, 2))}));
  AppendSmbChunk(1, 3, 1, 6, 'b');

  auto all = ReadAll();
  ASSERT_EQ(all.size(), 3u);
  auto smb = ForWriter(all, 1, 3);
  auto v2 = ForWriter(all, 1, 1);
  ASSERT_EQ(smb.size(), 2u);
  ASSERT_EQ(v2.size(), 1u);
  EXPECT_EQ(FakePacketFragment(smb[0].bytes.data(), smb[0].bytes.size()),
            FakePacketFragment(10, 'a'));
  EXPECT_EQ(FakePacketFragment(smb[1].bytes.data(), smb[1].bytes.size()),
            FakePacketFragment(6, 'b'));
  EXPECT_EQ(v2[0].bytes, (Bytes{0x0a, 0x02, 0x10, 0x02}));
  for (const ReadResult& r : all)
    EXPECT_EQ(r.loss, 0u);
}

TEST_F(SmbV2BufferTest, EmptyFragmentsAreSkipped) {
  Reset(4096);
  ASSERT_TRUE(Append(1, 1, {Bytes{}}));
  EXPECT_TRUE(ReadAll().empty());

  ASSERT_TRUE(Append(1, 1, {VarIntField(1, 1), Bytes{}, VarIntField(1, 2)}));
  auto all = ReadAll();
  ASSERT_EQ(all.size(), 2u);
  EXPECT_EQ(all[0].bytes, VarIntField(1, 1));
  EXPECT_EQ(all[1].bytes, VarIntField(1, 2));
  EXPECT_EQ(all[1].loss, 0u);
}

TEST_F(SmbV2BufferTest, LargePacketsAcrossManyBatches) {
  Reset(16 * 1024 * 1024);
  // 4 MiB of repeated "field 1 = 0", no groups.
  Bytes flat(4 * 1024 * 1024 + 2, 0);
  for (size_t i = 0; i < flat.size(); i += 2)
    flat[i] = 0x08;
  // About 3 MiB of the same inside one group.
  Bytes inner(3 * 1024 * 1024, 0);
  for (size_t i = 0; i < inner.size(); i += 2)
    inner[i] = 0x08;
  const Bytes grouped = Concat({VarIntField(2, 2), Group(3, inner)});

  const Bytes* const packets[] = {&flat, &grouped};
  for (const Bytes* packet : packets) {
    for (size_t off = 0; off < packet->size();) {
      const size_t n = std::min<size_t>(60000, packet->size() - off);
      Bytes piece(packet->begin() + static_cast<ptrdiff_t>(off),
                  packet->begin() + static_cast<ptrdiff_t>(off + n));
      ASSERT_TRUE(Append(1, 1, {piece}, off > 0, off + n < packet->size()));
      off += n;
    }
  }

  auto all = ReadAll();
  ASSERT_EQ(all.size(), 2u);
  EXPECT_EQ(all[0].loss, 0u);
  EXPECT_TRUE(all[0].bytes == flat);
  EXPECT_EQ(all[1].loss, 0u);

  protozero::ProtoDecoder dec(all[1].bytes.data(), all[1].bytes.size());
  protozero::Field f2 = dec.ReadField();
  ASSERT_TRUE(f2.valid());
  EXPECT_EQ(f2.id(), 2u);
  EXPECT_EQ(f2.as_uint64(), 2u);
  protozero::Field f3 = dec.ReadField();
  ASSERT_TRUE(f3.valid());
  EXPECT_EQ(f3.id(), 3u);
  ASSERT_EQ(f3.type(), pu::ProtoWireType::kLengthDelimited);
  ASSERT_EQ(f3.size(), inner.size());
  EXPECT_TRUE(Bytes(f3.data(), f3.data() + f3.size()) == inner);
  EXPECT_FALSE(dec.ReadField().valid());
  EXPECT_EQ(dec.bytes_left(), 0u);
}

TEST_F(SmbV2BufferTest, ReadPacketOutlivesLaterReadsAndWrites) {
  Reset(4096);
  ASSERT_TRUE(Append(1, 1, {Group(1, VarIntField(2, 42))}));
  buf()->BeginRead();
  TracePacket first;
  TraceBuffer::PacketSequenceProperties props{};
  uint32_t loss = 0;
  ASSERT_TRUE(buf()->ReadNextTracePacket(&first, &props, &loss));
  std::string expected;
  first.GetRawBytes(&expected);
  ASSERT_EQ(expected, std::string("\x0a\x02\x10\x2a", 4));

  for (uint64_t i = 0; i < 200; ++i)
    ASSERT_TRUE(Append(1, 1, {Group(1, VarIntField(2, 99 + i % 3))}));
  ReadAll();

  std::string actual;
  first.GetRawBytes(&actual);
  EXPECT_EQ(actual, expected);
}

// ---------------------------------------------------------------------------
// Packets the rewriter refuses
// ---------------------------------------------------------------------------

TEST_F(SmbV2BufferTest, MalformedPacketIsDroppedAndReported) {
  Reset(4096);
  const Bytes a = VarIntField(1, 1);
  const Bytes b = Group(1, VarIntField(1, 2));
  const Bytes top_level_end = {0x08, 0x01, 0x04};
  ASSERT_TRUE(Append(1, 1, {a, top_level_end, b}));
  ASSERT_TRUE(Append(1, 2, {VarIntField(1, 3)}));

  auto all = ReadAll();
  auto w1 = ForWriter(all, 1, 1);
  auto w2 = ForWriter(all, 1, 2);
  ASSERT_EQ(w1.size(), 2u);
  ASSERT_EQ(w2.size(), 1u);
  EXPECT_EQ(w1[0].bytes, a);
  EXPECT_EQ(w1[0].loss, 0u);
  EXPECT_EQ(w1[1].bytes, (Bytes{0x0a, 0x02, 0x08, 0x02}));
  EXPECT_EQ(w1[1].loss, kPresent | kCorrupted);
  EXPECT_EQ(w2[0].loss, 0u);
  EXPECT_EQ(buf()->stats().abi_violations(), 1u);
  EXPECT_EQ(buf()->stats().oversized_packets_dropped(), 0u);
}

TEST_F(SmbV2BufferTest, MalformedLastPacketReportsOnALaterRead) {
  Reset(4096);
  const Bytes unclosed = Concat({Group(1, {}), {0x0b, 0x08, 0x01}});
  ASSERT_TRUE(Append(1, 1, {VarIntField(1, 1), unclosed}));

  auto first = ReadAll();
  ASSERT_EQ(first.size(), 1u);
  EXPECT_EQ(first[0].loss, 0u);
  EXPECT_EQ(buf()->stats().abi_violations(), 1u);

  ASSERT_TRUE(Append(1, 1, {VarIntField(1, 2)}));
  auto second = ReadAll();
  ASSERT_EQ(second.size(), 1u);
  EXPECT_EQ(second[0].bytes, VarIntField(1, 2));
  EXPECT_EQ(second[0].loss, kPresent | kCorrupted);
}

TEST_F(SmbV2BufferTest, OversizedGroupIsDroppedAndCounted) {
  // One group whose content is proto_utils::kMaxMessageLength + 1 bytes,
  // stored as about 4100 batches.
  const size_t payload_size = pu::kMaxMessageLength - 4;
  Bytes packet;
  packet.reserve(payload_size + 16);
  AppendVarInt(pu::MakeTagStartGroup(1), &packet);
  AppendVarInt(pu::MakeTagLengthDelimited(1), &packet);
  AppendVarInt(payload_size, &packet);
  ASSERT_EQ(packet.size(), 6u);
  packet.resize(packet.size() + payload_size, 0x11);
  packet.push_back(0x04);

  Reset(320 * 1024 * 1024);
  ASSERT_TRUE(Append(1, 1, {VarIntField(1, 1)}));
  for (size_t off = 0; off < packet.size();) {
    const size_t n = std::min<size_t>(65000, packet.size() - off);
    protozero::ConstBytes piece{packet.data() + off, n};
    ASSERT_TRUE(buf()->CopyChunkV2Untrusted(Seq(1, 1), &piece, 1, off > 0,
                                            off + n < packet.size()));
    off += n;
  }
  ASSERT_TRUE(Append(1, 1, {VarIntField(1, 2)}));
  Bytes().swap(packet);

  auto all = ReadAll();
  ASSERT_EQ(all.size(), 2u);
  EXPECT_EQ(all[0].bytes, VarIntField(1, 1));
  EXPECT_EQ(all[0].loss, 0u);
  EXPECT_EQ(all[1].bytes, VarIntField(1, 2));
  EXPECT_EQ(all[1].loss, kPresent | kCorrupted);
  EXPECT_EQ(buf()->stats().oversized_packets_dropped(), 1u);
  EXPECT_EQ(buf()->stats().abi_violations(), 0u);
}

// ---------------------------------------------------------------------------
// Recorded losses
// ---------------------------------------------------------------------------

TEST_F(SmbV2BufferTest, LossShowsOnTheFirstPacketStoredAfterIt) {
  Reset(4096);
  ASSERT_TRUE(Append(1, 1, {VarIntField(1, 1), VarIntField(1, 2)}));
  buf()->RecordChunkV2DataLoss(1, 1);
  buf()->RecordChunkV2DataLoss(1, 1);
  ASSERT_TRUE(Append(1, 1, {VarIntField(1, 3), VarIntField(1, 4)}));
  ASSERT_TRUE(Append(1, 1, {VarIntField(1, 5)}));
  ASSERT_TRUE(Append(1, 2, {VarIntField(1, 6)}));

  auto all = ReadAll();
  auto w1 = ForWriter(all, 1, 1);
  ASSERT_EQ(w1.size(), 5u);
  EXPECT_EQ(w1[0].loss, 0u);
  EXPECT_EQ(w1[1].loss, 0u);
  EXPECT_EQ(w1[2].bytes, VarIntField(1, 3));
  EXPECT_EQ(w1[2].loss, kPresent | kReadGap);
  EXPECT_EQ(w1[3].loss, 0u);
  EXPECT_EQ(w1[4].loss, 0u);
  auto w2 = ForWriter(all, 1, 2);
  ASSERT_EQ(w2.size(), 1u);
  EXPECT_EQ(w2[0].loss, 0u);
}

TEST_F(SmbV2BufferTest, LossAfterTheLastBatchWaitsForTheNextOne) {
  Reset(4096);
  ASSERT_TRUE(Append(1, 1, {VarIntField(1, 1)}));
  buf()->RecordChunkV2DataLoss(1, 1);

  auto first = ReadAll();
  ASSERT_EQ(first.size(), 1u);
  EXPECT_EQ(first[0].loss, 0u);
  EXPECT_TRUE(ReadAll().empty());

  ASSERT_TRUE(Append(1, 1, {VarIntField(1, 2)}));
  auto second = ReadAll();
  ASSERT_EQ(second.size(), 1u);
  EXPECT_EQ(second[0].loss, kPresent | kReadGap);
}

TEST_F(SmbV2BufferTest, LossInsideASplitPacketDropsThatPacket) {
  Reset(4096);
  const Bytes split = Group(1, VarIntField(2, 7));
  const Bytes head(split.begin(), split.begin() + 2);
  const Bytes tail(split.begin() + 2, split.end());
  ASSERT_TRUE(Append(1, 1, {VarIntField(1, 1), head}, false, true));
  buf()->RecordChunkV2DataLoss(1, 1);
  ASSERT_TRUE(Append(1, 1, {tail, VarIntField(1, 2)}, true, false));
  ASSERT_TRUE(Append(1, 1, {VarIntField(1, 3)}));

  auto all = ReadAll();
  ASSERT_EQ(all.size(), 3u);
  EXPECT_EQ(all[0].bytes, VarIntField(1, 1));
  EXPECT_EQ(all[0].loss, 0u);
  EXPECT_EQ(all[1].bytes, VarIntField(1, 2));
  EXPECT_NE(all[1].loss & kPresent, 0u);
  EXPECT_EQ(all[2].bytes, VarIntField(1, 3));
  EXPECT_EQ(all[2].loss, 0u);
}

TEST_F(SmbV2BufferTest, EmptySplitPacketKeepsAPendingLoss) {
  Reset(4096);
  ASSERT_TRUE(Append(1, 1, {VarIntField(1, 1)}));
  buf()->RecordChunkV2DataLoss(1, 1);
  ASSERT_TRUE(Append(1, 1, {Bytes{}}, false, true));
  ASSERT_TRUE(Append(1, 1, {Bytes{}}, true, false));
  ASSERT_TRUE(Append(1, 1, {VarIntField(1, 2)}));

  auto all = ReadAll();
  ASSERT_EQ(all.size(), 2u);
  EXPECT_EQ(all[0].loss, 0u);
  EXPECT_EQ(all[1].bytes, VarIntField(1, 2));
  EXPECT_NE(all[1].loss & kReadGap, 0u);
}

TEST_F(SmbV2BufferTest, LossAndDroppedPacketReasonsAddUp) {
  Reset(4096);
  ASSERT_TRUE(Append(1, 1, {VarIntField(1, 1)}));
  buf()->RecordChunkV2DataLoss(1, 1);
  ASSERT_TRUE(Append(1, 1, {Bytes{0x04}}));
  ASSERT_TRUE(Append(1, 1, {VarIntField(1, 2)}));

  auto all = ReadAll();
  ASSERT_EQ(all.size(), 2u);
  EXPECT_EQ(all[0].loss, 0u);
  EXPECT_EQ(all[1].bytes, VarIntField(1, 2));
  EXPECT_EQ(all[1].loss, kPresent | kReadGap | kCorrupted);
}

TEST_F(SmbV2BufferTest, LossForUnknownOrSmbWritersChangesNothing) {
  Reset(4096);
  AppendSmbChunk(1, 7, 0, 8, 'a');
  buf()->RecordChunkV2DataLoss(1, 7);
  buf()->RecordChunkV2DataLoss(1, 8);
  AppendSmbChunk(1, 7, 1, 8, 'b');
  ASSERT_TRUE(Append(1, 8, {VarIntField(1, 1)}));

  auto all = ReadAll();
  ASSERT_EQ(all.size(), 3u);
  for (const ReadResult& r : all)
    EXPECT_EQ(r.loss, 0u);
  EXPECT_EQ(ForWriter(all, 1, 7).size(), 2u);
  EXPECT_EQ(ForWriter(all, 1, 8).size(), 1u);
}

TEST_F(SmbV2BufferTest, RefusedBatchCountsAsLoss) {
  Reset(4096);
  const Bytes split = VarIntField(1, 300);
  ASSERT_EQ(split.size(), 3u);
  ASSERT_TRUE(Append(1, 1, {VarIntField(2, 1), Bytes(split.begin(),
                                                     split.begin() + 1)},
                     false, true));
  // One fragment bigger than a buffer chunk can hold.
  EXPECT_FALSE(Append(1, 1, {Bytes(70000, 0)}));
  ASSERT_TRUE(Append(1, 1, {Bytes(split.begin() + 1, split.end()),
                            VarIntField(2, 3)},
                     true, false));

  auto all = ReadAll();
  ASSERT_EQ(all.size(), 2u);
  EXPECT_EQ(all[0].bytes, VarIntField(2, 1));
  EXPECT_EQ(all[0].loss, 0u);
  EXPECT_EQ(all[1].bytes, VarIntField(2, 3));
  EXPECT_NE(all[1].loss & kPresent, 0u);
}

// ---------------------------------------------------------------------------
// Batches the buffer refuses
// ---------------------------------------------------------------------------

TEST_F(SmbV2BufferTest, InvalidBatchesAreAbiViolationsAndEvictNothing) {
  Reset(4096);
  ASSERT_TRUE(Append(1, 1, {VarIntField(1, 1)}));

  // A null payload with a nonzero size.
  protozero::ConstBytes null_payload{nullptr, 1};
  EXPECT_FALSE(buf()->CopyChunkV2Untrusted(Seq(1, 1), &null_payload, 1, false,
                                           false));
  EXPECT_EQ(buf()->stats().abi_violations(), 1u);

  // A large first fragment then a null payload: refused as a whole.
  Bytes large(4000, 0);
  protozero::ConstBytes mixed[] = {{large.data(), large.size()},
                                   {nullptr, 1}};
  EXPECT_FALSE(buf()->CopyChunkV2Untrusted(Seq(1, 1), mixed, 2, false, false));
  EXPECT_EQ(buf()->stats().abi_violations(), 2u);

  // A batch bigger than the whole buffer.
  EXPECT_FALSE(Append(1, 1, {Bytes(8000, 0)}));
  EXPECT_EQ(buf()->stats().abi_violations(), 3u);

  EXPECT_EQ(buf()->stats().chunks_written(), 1u);
  EXPECT_EQ(buf()->stats().chunks_overwritten(), 0u);
  EXPECT_EQ(buf()->stats().chunks_discarded(), 0u);

  ASSERT_TRUE(Append(1, 1, {VarIntField(1, 2)}));
  auto all = ReadAll();
  ASSERT_EQ(all.size(), 2u);
  EXPECT_EQ(all[0].bytes, VarIntField(1, 1));
  EXPECT_EQ(all[0].loss, 0u);
  EXPECT_EQ(all[1].bytes, VarIntField(1, 2));
  EXPECT_NE(all[1].loss & kReadGap, 0u);
}

TEST_F(SmbV2BufferTest, BatchOverOneChunkIsRefused) {
  Reset(256 * 1024);
  const Bytes half(32 * 1024, 0);
  EXPECT_FALSE(Append(1, 1, {half, half}));
  EXPECT_EQ(buf()->stats().abi_violations(), 1u);
  EXPECT_EQ(buf()->stats().chunks_written(), 0u);
  EXPECT_FALSE(buf()->has_data());

  Bytes big = BytesField(1, Bytes(60000, 0x33));
  ASSERT_TRUE(Append(1, 1, {big}));
  auto all = ReadAll();
  ASSERT_EQ(all.size(), 1u);
  EXPECT_TRUE(all[0].bytes == big);
}

TEST_F(SmbV2BufferTest, EmptyBatchChangesNothing) {
  Reset(4096);
  ASSERT_TRUE(Append(1, 1, {VarIntField(1, 1)}));
  EXPECT_FALSE(buf()->CopyChunkV2Untrusted(Seq(1, 1), nullptr, 0, false,
                                           false));
  EXPECT_FALSE(Append(1, 1, {}));
  ASSERT_TRUE(Append(1, 1, {VarIntField(1, 2)}));

  EXPECT_EQ(buf()->stats().abi_violations(), 0u);
  EXPECT_EQ(buf()->stats().chunks_discarded(), 0u);
  EXPECT_EQ(buf()->stats().chunks_written(), 2u);
  auto all = ReadAll();
  ASSERT_EQ(all.size(), 2u);
  EXPECT_EQ(all[0].loss, 0u);
  EXPECT_EQ(all[1].loss, 0u);
}

TEST_F(SmbV2BufferTest, WriterIdKeepsItsFirstFormat) {
  Reset(4096);
  // SMB first, then an SMB v2 batch on the same writer.
  AppendSmbChunk(1, 7, 0, 8, 'a');
  EXPECT_FALSE(Append(1, 7, {VarIntField(1, 1)}));
  EXPECT_EQ(buf()->stats().abi_violations(), 1u);
  EXPECT_EQ(buf()->stats().chunks_written(), 1u);

  // SMB v2 first, then an SMB chunk and a patch on the same writer.
  ASSERT_TRUE(Append(1, 8, {VarIntField(1, 2)}));
  AppendSmbChunk(1, 8, 0, 8, 'b');
  EXPECT_EQ(buf()->stats().abi_violations(), 2u);
  EXPECT_FALSE(buf()->TryPatchChunkContents(1, 8, 0, nullptr, 0, false));
  ASSERT_TRUE(Append(1, 8, {VarIntField(1, 3)}));

  // The same writer ID under another producer is another sequence.
  ASSERT_TRUE(Append(2, 7, {VarIntField(1, 4)}));

  auto all = ReadAll();
  auto smb = ForWriter(all, 1, 7);
  ASSERT_EQ(smb.size(), 1u);
  EXPECT_EQ(FakePacketFragment(smb[0].bytes.data(), smb[0].bytes.size()),
            FakePacketFragment(8, 'a'));
  EXPECT_EQ(smb[0].loss, 0u);
  auto v2 = ForWriter(all, 1, 8);
  ASSERT_EQ(v2.size(), 2u);
  EXPECT_EQ(v2[0].bytes, VarIntField(1, 2));
  EXPECT_EQ(v2[0].loss, 0u);
  EXPECT_EQ(v2[1].bytes, VarIntField(1, 3));
  EXPECT_EQ(v2[1].loss, 0u);
  auto other = ForWriter(all, 2, 7);
  ASSERT_EQ(other.size(), 1u);
  EXPECT_EQ(other[0].loss, 0u);
  EXPECT_EQ(all.size(), 4u);
}

TEST_F(SmbV2BufferTest, ProducerWithAProtoVmIsRefused) {
  Reset(4096);
  buf()->MaybeSetUpProtoVm("test", "", 1024, 1);
  ASSERT_EQ(buf()->GetProtoVmInstances().size(), 1u);

  EXPECT_FALSE(Append(1, 1, {VarIntField(1, 1)}));
  EXPECT_EQ(buf()->stats().chunks_discarded(), 1u);
  EXPECT_EQ(buf()->stats().abi_violations(), 0u);
  EXPECT_FALSE(buf()->has_data());

  ASSERT_TRUE(Append(2, 1, {Group(1, VarIntField(1, 2))}));
  auto all = ReadAll();
  ASSERT_EQ(all.size(), 1u);
  EXPECT_EQ(all[0].producer, 2u);
  EXPECT_EQ(all[0].bytes, (Bytes{0x0a, 0x02, 0x08, 0x02}));
  EXPECT_EQ(all[0].loss, 0u);
}

TEST_F(SmbV2BufferTest, FullDiscardBufferRefusesBatches) {
  Reset(4096, TraceBuffer::kDiscard);
  size_t stored = 0;
  size_t refused = 0;
  for (uint64_t i = 0; i < 10; ++i) {
    if (Append(1, 1, {NumberedPacket(i, 1500)}))
      ++stored;
    else
      ++refused;
  }
  ASSERT_GT(stored, 0u);
  ASSERT_GT(refused, 0u);
  EXPECT_EQ(buf()->stats().chunks_discarded(), refused);
  EXPECT_EQ(buf()->stats().abi_violations(), 0u);

  auto all = ReadAll();
  ASSERT_EQ(all.size(), stored);
  for (size_t i = 0; i < all.size(); ++i) {
    EXPECT_EQ(PacketNumber(all[i].bytes), i);
    EXPECT_EQ(all[i].loss, 0u);
  }
}

// ---------------------------------------------------------------------------
// Overwrites and clones
// ---------------------------------------------------------------------------

TEST_F(SmbV2BufferTest, OverwrittenBatchesAreReportedOnTheSurvivors) {
  Reset(4096);
  for (uint64_t i = 0; i < 30; ++i)
    ASSERT_TRUE(Append(1, 1, {NumberedPacket(i, 500)}));
  EXPECT_GT(buf()->stats().chunks_overwritten(), 0u);

  auto all = ReadAll();
  ASSERT_GT(all.size(), 1u);
  ASSERT_LT(all.size(), 30u);
  const uint64_t first = 30 - all.size();
  for (size_t i = 0; i < all.size(); ++i) {
    EXPECT_EQ(PacketNumber(all[i].bytes), first + i);
    if (i == 0) {
      EXPECT_NE(all[i].loss & kOverwrite, 0u);
    } else {
      EXPECT_EQ(all[i].loss, 0u);
    }
  }
}

TEST_F(SmbV2BufferTest, OverwriteAndPendingLossBothReach) {
  Reset(4096);
  ASSERT_TRUE(Append(1, 1, {NumberedPacket(0, 1500)}));
  buf()->RecordChunkV2DataLoss(1, 1);
  ASSERT_TRUE(Append(1, 1, {NumberedPacket(1, 20)}));

  // Small batches from another writer until the first batch is overwritten.
  for (uint64_t i = 0; i < 1000 && buf()->stats().chunks_overwritten() == 0;
       ++i) {
    ASSERT_TRUE(Append(1, 2, {NumberedPacket(i, 100)}));
  }
  ASSERT_EQ(buf()->stats().chunks_overwritten(), 1u);

  auto clone = buf()->CloneReadOnly();
  ASSERT_TRUE(clone);
  for (TraceBuffer* b : {static_cast<TraceBuffer*>(buf()), clone.get()}) {
    auto w1 = ForWriter(ReadAll(b), 1, 1);
    ASSERT_EQ(w1.size(), 1u);
    EXPECT_EQ(PacketNumber(w1[0].bytes), 1u);
    EXPECT_NE(w1[0].loss & kReadGap, 0u);
    EXPECT_NE(w1[0].loss & kOverwrite, 0u);
  }
}

TEST_F(SmbV2BufferTest, ClonesKeepLossesNotYetRead) {
  Reset(4096);
  ASSERT_TRUE(Append(1, 1, {VarIntField(1, 1)}));
  buf()->RecordChunkV2DataLoss(1, 1);
  ASSERT_TRUE(Append(1, 1, {VarIntField(1, 2), Group(1, VarIntField(1, 3))}));
  auto before = buf()->CloneReadOnly();
  ASSERT_TRUE(before);

  buf()->BeginRead();
  ReadResult r;
  ASSERT_TRUE(ReadOne(buf(), &r));
  EXPECT_EQ(r.loss, 0u);
  ASSERT_TRUE(ReadOne(buf(), &r));
  EXPECT_EQ(r.loss, kPresent | kReadGap);

  auto after = buf()->CloneReadOnly();
  ASSERT_TRUE(after);
  for (TraceBuffer* b : {static_cast<TraceBuffer*>(buf()), after.get()}) {
    auto rest = ReadAll(b);
    ASSERT_EQ(rest.size(), 1u);
    EXPECT_EQ(rest[0].bytes, (Bytes{0x0a, 0x02, 0x08, 0x03}));
    EXPECT_EQ(rest[0].loss, 0u);
  }

  auto all = ReadAll(before.get());
  ASSERT_EQ(all.size(), 3u);
  EXPECT_EQ(all[0].loss, 0u);
  EXPECT_EQ(all[1].bytes, VarIntField(1, 2));
  EXPECT_EQ(all[1].loss, kPresent | kReadGap);
  EXPECT_EQ(all[2].bytes, (Bytes{0x0a, 0x02, 0x08, 0x03}));
  EXPECT_EQ(all[2].loss, 0u);
}

}  // namespace
}  // namespace perfetto
