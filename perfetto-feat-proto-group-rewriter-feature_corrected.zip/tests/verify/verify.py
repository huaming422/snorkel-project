"""Behavioral verifier for perfetto-feat-proto-group-rewriter.

Tests through the ONLY contract the feature pins: the public C++ interface
``perfetto::tracing_v2::ProtoGroupRewriter`` declared in
``src/tracing/service/proto_group_rewriter.h`` (namespace, enum
``RewriteResult``, ``kMaxNestingDepth``, and
``Rewrite(const Slices&, std::optional<Slice>*)``). The verifier does not
import, name or inspect anything behind that header; only the bytes that come
out and the result codes matter, so any correct algorithm passes.

Mechanism: the gtest suite (``proto_group_rewriter_verifier_unittest.cc``
+ its independent reference ``proto_group_rewriter_reference_for_testing.h``)
is bundled alongside this file and copied into the repo + wired into the
``perfetto_unittest_source_set("unittests")`` GN target by
``tests/test-setup.sh`` BEFORE grading. That build compiles the suite
against the AGENT's header, so every valid implementation links. This file
runs the compiled ``perfetto_unittests`` binary ONCE, filtered to
``*ProtoGroupRewriter*``, captures the gtest JSON report, and routes the
named gtest cases to one ``test_*`` function per task criterion.

Self-contained and implementation-agnostic:
- stdlib + pytest only; imports no project-internal Python and no repo code,
  so it collects and runs under VERIFIER_PYTHON with no interpreter override;
- the set of ``test_*`` functions is FIXED, so pytest always collects 12
  cases regardless of whether the agent's code builds, a submission that
  fails to compile the rewriter fails these tests cleanly (correctness 0.0)
  instead of producing zero collected tests (which the runner would treat as
  an invalid trial);
- each criterion asserts its gtest cases were *actually present and passed*
  in the report, so a stale/leftover binary or a filter that matches nothing
  FAILS the criterion rather than passing vacuously.
"""

from __future__ import annotations

import json
import os
import subprocess
import tempfile
from pathlib import Path

import pytest

# The compiled gtest binary. test-setup.sh (re-)exports this; the default is
# the image's pre-built out dir. A valid submission's incremental build
# refreshes this binary to include the agent's rewriter + the bundled suite.
PERFETTO_UNITTESTS = os.environ.get(
    "PERFETTO_UNITTESTS", "/repo/perfetto/out/dist/perfetto_unittests"
)

# All four suites the bundled .cc defines start with this prefix:
#   ProtoGroupRewriterTest        (value-parameterized over 3 slice splits)
#   ProtoGroupRewriterSliceTest   (plain TEST)
#   ProtoGroupRewriterSizeTest    (plain TEST, groups at 256 MiB)
#   ProtoGroupRewriterRandomTest  (differential, seed-fixed → deterministic)
GTEST_FILTER = "*ProtoGroupRewriter*"

# Generous head-room; the differential RandomTest (3000 iters × 3 splits) is
# the long pole and still completes in well under this on the task container.
# Kept below verify.toml's pytest timeout so a hang yields a clean failure
# message here rather than an outer kill.
RUN_TIMEOUT_SEC = 1500

# Populated once, lazily, by _suite(). Maps gtest base case name
# (e.g. "EmptyGroup", with any "/<param>" suffix stripped) -> list[bool]
# (one entry per parameter instantiation, True iff that instance passed).
# "error" holds a human-readable reason the whole run is unusable (binary
# missing, crashed before emitting JSON, matched zero tests, ...); when set,
# every criterion fails with that reason.
_CACHE: dict | None = None


def _run_suite() -> dict:
    """Run perfetto_unittests once, parse the gtest JSON, build the case map."""
    binary = Path(PERFETTO_UNITTESTS)
    if not binary.is_file() or not os.access(binary, os.X_OK):
        return {
            "cases": {},
            "error": (
                f"gtest binary not found or not executable at {binary!s}. "
                "The submission's rewriter likely failed to build, so the "
                "bundled ProtoGroupRewriter suite could not be compiled/linked."
            ),
        }

    out_dir = Path(tempfile.mkdtemp(prefix="pgr_gtest_"))
    json_path = out_dir / "gtest.json"
    cmd = [
        str(binary),
        f"--gtest_filter={GTEST_FILTER}",
        f"--gtest_output=json:{json_path}",
        "--gtest_color=no",
    ]
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=RUN_TIMEOUT_SEC,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return {
            "cases": {},
            "error": f"perfetto_unittests timed out after {RUN_TIMEOUT_SEC}s running {GTEST_FILTER}",
        }

    if not json_path.is_file():
        tail = (proc.stdout or "")[-1500:] + "\n" + (proc.stderr or "")[-1500:]
        return {
            "cases": {},
            "error": (
                f"perfetto_unittests produced no gtest JSON (exit {proc.returncode}); "
                f"the binary may have crashed before finalizing the report.\n--- tail ---\n{tail}"
            ),
        }

    try:
        report = json.loads(json_path.read_text())
    except Exception as exc:  # noqa: BLE001
        return {"cases": {}, "error": f"could not parse gtest JSON: {exc!r}"}

    cases: dict[str, list[bool]] = {}
    for suite in report.get("testsuites", []):
        for tc in suite.get("testsuite", []):
            raw_name = tc.get("name", "")
            base = raw_name.split("/", 1)[0]  # strip "/0","/1","/2" param suffix
            # gtest JSON marks a passing, actually-executed case as
            # status=="RUN" with no "failures" array and result=="COMPLETED".
            passed = (
                tc.get("status") == "RUN"
                and "failures" not in tc
                and tc.get("result") != "SKIPPED"
            )
            cases.setdefault(base, []).append(bool(passed))

    if not cases:
        tail = (proc.stdout or "")[-1500:]
        return {
            "cases": {},
            "error": (
                f"filter {GTEST_FILTER!r} matched ZERO tests, the bundled "
                "ProtoGroupRewriter suite was not compiled into this binary.\n"
                f"--- stdout tail ---\n{tail}"
            ),
        }

    return {"cases": cases, "error": None}


def _suite() -> dict:
    global _CACHE
    if _CACHE is None:
        _CACHE = _run_suite()
    return _CACHE


def _assert_cases(*case_names: str) -> None:
    """Fail unless EVERY named gtest case was present and all its instances passed."""
    suite = _suite()
    if suite["error"]:
        pytest.fail(suite["error"])

    cases = suite["cases"]
    missing = [c for c in case_names if c not in cases or not cases[c]]
    failed = [
        c
        for c in case_names
        if c in cases and cases[c] and not all(cases[c])
    ]

    problems = []
    if missing:
        problems.append(
            "gtest cases not present in the report (binary stale or suite not "
            f"built): {', '.join(sorted(missing))}"
        )
    if failed:
        detail = ", ".join(
            f"{c} ({sum(cases[c])}/{len(cases[c])} split-instances passed)"
            for c in sorted(failed)
        )
        problems.append(f"gtest cases failed: {detail}")
    if problems:
        pytest.fail("; ".join(problems))


# ── One test per task criterion ─────────────────────────────────────────────
# Case names mirror the TEST_P / TEST identifiers in the bundled
# proto_group_rewriter_verifier_unittest.cc. ProtoGroupRewriterTest.* cases each run
# under 3 slice-split instantiations (kWhole / kEveryByte / kThirds); all
# three instances must pass for the criterion to pass.


def test_empty_and_nested_rewrite() -> None:
    """Empty group and group-in-group rewrite to the contract's exact bytes."""
    _assert_cases("EmptyGroup", "GroupInsideGroup")


def test_v1_length_encoding() -> None:
    """Content length encodes correctly: <=127 -> 1 byte; >127 -> any valid varint that decodes to the same length."""
    _assert_cases("LengthFieldFollowsV1Rule", "VarintValueBoundaries")


def test_tag_rewrite_preserves_field_ids() -> None:
    """Start-group tag rewritten by clearing only the wire-type bit; all field-id bytes preserved."""
    _assert_cases("FieldIdBoundaries", "NonMinimalTagKeepsItsBytes")


def test_opaque_payload() -> None:
    """A 0x04 byte inside a length-delimited value is opaque data, not a group close."""
    _assert_cases("ProtoGroupEndByteInsideAPayloadStaysOpaque")


def test_cross_slice_streaming() -> None:
    """Fields/varints/values straddling slice boundaries parse and copy correctly."""
    _assert_cases(
        "LongValueCrossesSliceBoundary",
        "ScalarFieldsInsideAndAroundGroups",
        "OrdinaryFieldsWithAndWithoutGroups",
    )


def test_nesting_limit() -> None:
    """Nesting up to 1024 rewrites; 1025 (and runaway start-tags) is rejected as malformed."""
    _assert_cases("NestingUpToTheLimit", "NestingBeyondTheLimitIsRejected")


def test_group_size_limit() -> None:
    """A group with kMaxMessageLength bytes of content converts; one byte more is kGroupTooLarge with the output untouched."""
    _assert_cases("GroupAtTheSizeLimitConverts", "GroupOverTheSizeLimitIsRejected")


def test_malformed_taxonomy_rejected() -> None:
    """The full malformed taxonomy returns kMalformedInput and never crashes."""
    _assert_cases(
        "MalformedTagsAndValuesAreRejected",
        "StandardEndGroupTagIsRejected",
        "ProtoGroupEndAtRootIsRejected",
        "UnclosedGroupIsRejected",
    )


def test_result_contract() -> None:
    """kUnchanged leaves output unset with the caller; kRewritten owns a slice; rejects leave output untouched."""
    _assert_cases(
        "EmptyInput",
        "OrdinaryFieldsWithAndWithoutGroups",
        "RejectedPacketLeavesOutputUnset",
        "ExistingOutputIsPreserved",
    )


def test_reuse_state_reset() -> None:
    """A reused rewriter does not inherit open-group state from a prior rejected packet."""
    _assert_cases("ReuseAfterRejectedPacket")


def test_real_packet_roundtrip() -> None:
    """A genuine kProtoGroup TracePacket rewrites to bytes that parse as standard protobuf."""
    _assert_cases("GeneratedTracePacketRoundTrips", "SiblingsAndDeepNestingRoundTrip")


def test_differential_reference() -> None:
    """Output decodes to the same field/value tree as an independent reference rewriter across the random corpus."""
    _assert_cases("MatchesReferenceOnRandomPacketsAndSplits")
