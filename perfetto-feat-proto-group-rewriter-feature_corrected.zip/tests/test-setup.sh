#!/usr/bin/env bash
# test-setup.sh, sourced by /tests/test.sh BEFORE the verifier runs.
#
# Responsibilities (in order):
#   1. Wire the bundled native gtest suites into the repo. GN does NOT
#      auto-discover a new .cc (unlike Cargo), so we copy the three staged
#      assets into src/tracing/service/ and append them, plus the two
#      protozero deps the test file itself needs, to the
#      perfetto_unittest_source_set("unittests") target. These assets live in
#      /tests/verify/ and are copied into the tree only for this run.
#   2. Regenerate the GN build graph and (re)build perfetto_unittests against
#      the repo's proto_group_rewriter.{h,cc} and trace_buffer_v2.{h,cc}.
#   3. Export PERFETTO_UNITTESTS for verify.py.
#
# CRITICAL, this script is SOURCED into test.sh, which runs under
# `set -euo pipefail`. A naked non-zero from gn/ninja would abort test.sh
# before run_verify.py ever runs, turning a non-compiling submission into an
# INVALID trial (reward=None) instead of a clean correctness 0.0. That would
# also break the empty-patch check: an empty submission has no
# proto_group_rewriter.{h,cc} at all, so the suite CANNOT compile for it, and
# that MUST score 0.0, not invalidate.
#
# Therefore every fallible build command is run inside an `if ! ...; then`
# guard. Commands in a conditional are exempt from errexit, so a build
# failure is handled inline (logged, binary left absent) while `set -e` stays
# active to catch genuine infra typos / unset vars. We also DELETE any
# pre-image binary before building, so a failed build leaves NO binary and
# verify.py reports a clean, unambiguous failure rather than running a stale
# binary that lacks the ProtoGroupRewriter cases.
set -euo pipefail

REPO=/repo/perfetto
cd "${REPO}"

OUT=out/dist
SVC_DIR=src/tracing/service
BUILD_GN="${SVC_DIR}/BUILD.gn"
VERIFY_ASSETS=/tests/verify
UNITTEST_CC=proto_group_rewriter_verifier_unittest.cc
REFERENCE_H=proto_group_rewriter_reference_for_testing.h
BUFFER_UNITTEST_CC=trace_buffer_v2_smb_v2_verifier_unittest.cc

export PERFETTO_UNITTESTS="${REPO}/${OUT}/perfetto_unittests"

# ── Sanity: the baked GN out dir must exist (built at image time) ───────────
if [ ! -f "${OUT}/args.gn" ]; then
    echo "test-setup: ${OUT}/args.gn missing, image was not built correctly" >&2
    # This is an image/infra defect, not a submission outcome; fail loud.
    exit 1
fi

# ── 1. Copy the bundled native test assets into the repo ────────────────────
# These must be present for gn gen to accept the `sources +=` edit below.
for f in "${UNITTEST_CC}" "${REFERENCE_H}" "${BUFFER_UNITTEST_CC}"; do
    if [ ! -f "${VERIFY_ASSETS}/${f}" ]; then
        echo "test-setup: bundled verifier asset ${VERIFY_ASSETS}/${f} missing" >&2
        exit 1   # infra defect (asset not shipped), not a submission outcome
    fi
    cp -f "${VERIFY_ASSETS}/${f}" "${SVC_DIR}/${f}"
done
echo "test-setup: staged native test assets into ${SVC_DIR}/"

# ── 2. Wire the assets into perfetto_unittest_source_set("unittests") ───────
# Idempotent: a marker comment guards against double-injection on re-runs.
# We inject ONLY the three bundled sources and the two protozero deps the test
# file includes directly (perfetto/protozero/{root_message,scattered_*}.h).
# We deliberately do NOT add a dep on the rewriter's source_set: its
# object links transitively through the unittests target's existing `:service`
# dep (base.md requires the rewriter be wired into the service build), so this
# works regardless of what the GN target is named, avoiding a
# false-negative coupling to an unpinned internal name.
INJECT_MARKER="# proto-group-rewriter verifier wiring (reward-owned, injected by test-setup.sh)"
if ! grep -qF "${INJECT_MARKER}" "${BUILD_GN}"; then
    if ! python3 - "${BUILD_GN}" "${INJECT_MARKER}" "${UNITTEST_CC}" "${REFERENCE_H}" "${BUFFER_UNITTEST_CC}" <<'PY'
import os
import re
import sys

path, marker, unittest_cc, reference_h, buffer_unittest_cc = sys.argv[1:6]
src = open(path).read().splitlines(keepends=True)

n = len(src)

# ── Pass 0: collect the basenames of files ALREADY listed in the unittests
# target's `sources = [` list. A valid change follows the perfetto convention
# (<component>_unittest.cc added to this same list), so a
# proto_group_rewriter_unittest.cc may already be here. Injecting a second
# source with the same basename makes GN emit a duplicate object file and the
# whole build fails, scoring every submission 0.0 regardless of correctness.
# So we skip injecting any verifier source whose basename already appears.
existing_source_basenames = set()
_i = 0
_in_unittests = False
_depth = 0
_in_sources = False
while _i < n:
    line = src[_i]
    if not _in_unittests:
        if 'perfetto_unittest_source_set("unittests")' in line and "{" in line:
            _in_unittests = True
            _depth = line.count("{") - line.count("}")
        _i += 1
        continue
    _depth += line.count("{") - line.count("}")
    stripped = line.strip()
    if not _in_sources:
        if stripped == "sources = [":
            _in_sources = True
    else:
        if stripped.startswith("]"):
            _in_sources = False
        else:
            for m in re.findall(r'"([^"]+)"', line):
                existing_source_basenames.add(os.path.basename(m))
    if _depth <= 0:
        _in_unittests = False  # left the unittests target
    _i += 1

# Build the source injection, skipping any basename already present so the
# wiring is dedupe-aware (backward-compatible: a change that does NOT list the
# unittest still gets every verifier source injected).
source_entries = [reference_h, unittest_cc, buffer_unittest_cc]
skipped = [f for f in source_entries if os.path.basename(f) in existing_source_basenames]
to_inject = [f for f in source_entries if os.path.basename(f) not in existing_source_basenames]
for f in skipped:
    sys.stderr.write(
        f"test-setup: sources list already contains a file named "
        f"{os.path.basename(f)!r}; skipping injection to avoid a GN duplicate-"
        f"object-file collision\n"
    )

out = []
i = 0
in_unittests = False
depth = 0
done_deps = False
done_sources = False

# Lines we append inside the top-level `deps = [` and `sources = [` lists of
# the perfetto_unittest_source_set("unittests") target.
dep_lines = [
    f'    {marker}\n',
    '    "../../../include/perfetto/protozero",\n',
    '    "../../protozero",\n',
]
source_lines = [f'    {marker}\n'] + [f'    "{f}",\n' for f in to_inject]

while i < n:
    line = src[i]
    out.append(line)

    if not in_unittests:
        if 'perfetto_unittest_source_set("unittests")' in line and "{" in line:
            in_unittests = True
            depth = line.count("{") - line.count("}")
        i += 1
        continue

    # Track brace depth to know when the target block ends.
    depth += line.count("{") - line.count("}")

    stripped = line.strip()
    # Inject after the FIRST top-level `deps = [` / `sources = [` of the block.
    if not done_deps and stripped == "deps = [":
        out.extend(dep_lines)
        done_deps = True
    elif not done_sources and stripped == "sources = [":
        out.extend(source_lines)
        done_sources = True

    if depth <= 0:
        in_unittests = False  # left the unittests target

    i += 1

if not (done_deps and done_sources):
    sys.stderr.write(
        "test-setup: could not locate deps/sources lists in unittests target "
        f"(deps={done_deps}, sources={done_sources})\n"
    )
    sys.exit(2)

open(path, "w").write("".join(out))
PY
    then
        echo "test-setup: BUILD.gn injection failed, verifier will report missing cases" >&2
    else
        echo "test-setup: wired native suite into ${BUILD_GN}"
    fi
else
    echo "test-setup: BUILD.gn already wired (idempotent re-run)"
fi

# ── 3. Remove any stale binary so a failed build leaves NO binary ───────────
rm -f "${OUT}/perfetto_unittests"

# ── 4. Regenerate the build graph ───────────────────────────────────────────
echo "test-setup: regenerating GN build graph..."
if ! tools/gn gen "${OUT}" --args='is_debug=true' > /tmp/gn-setup.log 2>&1; then
    echo "test-setup: gn gen FAILED (submission may be missing files / BUILD wiring):" >&2
    tail -n 120 /tmp/gn-setup.log >&2
    echo "test-setup: continuing; verify.py will report the absent binary as a clean failure." >&2
    return 0 2>/dev/null || exit 0
fi

# ── 5. Build perfetto_unittests against the repo's rewriter ────────────────
echo "test-setup: building perfetto_unittests (incremental)..."
if ! tools/ninja -C "${OUT}" perfetto_unittests > /tmp/ninja-setup.log 2>&1; then
    echo "test-setup: ninja build FAILED (agent code did not compile/link):" >&2
    tail -n 160 /tmp/ninja-setup.log >&2
    echo "test-setup: continuing; verify.py will report the absent binary as a clean failure." >&2
    return 0 2>/dev/null || exit 0
fi

if [ ! -x "${PERFETTO_UNITTESTS}" ]; then
    echo "test-setup: build reported success but ${PERFETTO_UNITTESTS} is absent/non-exec" >&2
    echo "test-setup: continuing; verify.py will report this as a clean failure." >&2
    return 0 2>/dev/null || exit 0
fi

echo "test-setup: ready, perfetto_unittests built at ${PERFETTO_UNITTESTS}"
