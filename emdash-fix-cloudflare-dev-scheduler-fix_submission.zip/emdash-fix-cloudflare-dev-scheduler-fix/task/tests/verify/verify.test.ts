// @ts-nocheck
//
// Correctness check for the Cloudflare-dev scheduled-maintenance
// regression. It drives pre-existing, stable interfaces that exist at the
// base commit and are already exercised by the package's own unit suite,
// and it asserts the fix's full reason-for-being: not just that the doomed
// in-worker timer is gone, but that maintenance KEEPS RUNNING through a
// host-driven heartbeat that actually invokes a working maintenance entry
// point.
//
//   NEGATIVE half — the scheduler module must stop handing the worker a timer:
//     createVirtualModulesPlugin(options, astroCommand?)  (src/astro/integration/vite-config.ts)
//       + RESOLVED_VIRTUAL_SCHEDULER_ID                   (src/astro/integration/virtual-modules.ts)
//
//   POSITIVE half — a replacement must actually keep maintenance running:
//     emdash(config)                                      (src/astro/integration/index.ts)
//       driven through its astro:config:setup AND astro:server:setup hooks
//       (the same seams the package's own integration tests use), plus the
//       pre-existing public maintenance entry point
//       runScheduledTasks()                               (src/astro/middleware.ts)
//     and the pre-existing auth/CSRF middleware the heartbeat must survive:
//       onRequest()                                       (src/astro/middleware/auth.ts)
//       driven exactly as the package's own middleware unit suite drives it.
//
// Why BOTH halves — and why the positive half must EXECUTE, not just inspect:
//   Under the Cloudflare adapter during local `astro dev`, the scheduler
//   virtual module used to emit a long-lived in-process timer, but the worker
//   runtime has no persistent event loop between requests: the timer is armed
//   once and then discarded, so maintenance silently stops after the first
//   request. A correct fix must (a) stop handing the worker that doomed timer
//   AND (b) keep maintenance running some other way — by driving it from the
//   long-lived dev host that DOES have a persistent event loop. Checking only
//   (a), or merely checking that a dev-only route PATTERN is injected, would
//   accept a "solution" that emits the inert module and wires an inert route
//   behind which nothing runs maintenance — making maintenance run ZERO times,
//   strictly worse than the symptom. So the positive half DRIVES the behavior:
//   it runs the server-setup heartbeat and confirms it repeatedly calls the
//   dev-only route, and it invokes the discovered route handler and confirms it
//   runs maintenance in dev while refusing it outside dev.
//
//   There is one more load-bearing seam the positive half must cross. The host
//   heartbeat re-enters the worker as a cookieless, cross-origin-free POST (no
//   browser, so no session cookie and no custom CSRF header). On the base
//   commit the auth middleware CSRF-rejects exactly that request on an
//   /_emdash/api route, so a "fix" that wires the route and runs maintenance in
//   its handler but never exempts the route from the dev auth/CSRF gate scores
//   every other check yet still fails in a real dev server: the heartbeat POST
//   is 403'd before the handler ever runs, and maintenance never fires. So the
//   final check drives the pre-existing auth middleware directly and confirms
//   the discovered dev-only route is reachable by that cookieless POST in dev,
//   and refused outside dev (the exemption must not widen production).
//
// Interface discipline:
//   Every assertion is on OBSERVABLE BEHAVIOUR through interfaces that exist at
//   the base commit — the emitted scheduler-module text, the set of routes the
//   integration injects for a given adapter and command, the server-setup
//   hook's outbound requests, and the public `runScheduledTasks` maintenance
//   routine. The dev-only maintenance entry point is DISCOVERED generically, as
//   the one route the integration wires only on the Cloudflare dev path (absent
//   for other adapters, for the no-adapter case, and for the Cloudflare
//   production build), and its handler is loaded through the entrypoint the
//   integration itself reports — never by a hard-coded file, option, route, or
//   symbol the fix happens to introduce. Any endpoint name or host->worker
//   transport the implementation chooses satisfies the checks.

import { beforeEach, describe, expect, it, vi } from "vitest";

import { emdash } from "../../../../src/astro/integration/index.js";
import { libsql } from "../../../../src/db/adapters.js";
import { RESOLVED_VIRTUAL_SCHEDULER_ID } from "../../../../src/astro/integration/virtual-modules.js";
import {
	createVirtualModulesPlugin,
	type VitePluginOptions,
} from "../../../../src/astro/integration/vite-config.js";

// The route handler drives scheduled maintenance through the package's
// pre-existing public entry point, `runScheduledTasks` (src/astro/middleware.ts
// — present at the base commit, the only public request-free maintenance API).
// We replace it with a spy so the positive handler check can prove maintenance
// is actually driven, without reaching into any fix-invented internal. This
// is a stable-interface stub, not a name pin on the fix.
const { maintenanceSpy } = vi.hoisted(() => ({
	maintenanceSpy: vi.fn(async () => ({ published: [] })),
}));
vi.mock("../../../../src/astro/middleware.js", () => ({
	runScheduledTasks: maintenanceSpy,
}));

// The auth/CSRF middleware (src/astro/middleware/auth.ts) is a base-commit
// interface the final check drives directly. It imports three modules that do
// not exist in the plain-node vitest environment — Astro's defineMiddleware,
// the statically-bundled auth virtual module, and the @emdash-cms/auth adapter
// (whose dist must be built for Vite to resolve its entry; test-setup.sh builds
// it). Stub them EXACTLY as the package's own middleware unit suite does
// (tests/unit/middleware/*.test.ts). These are stable base-commit seams, not
// names the fix introduces, and none of them is in the import closure of the
// scheduler-module or integration-route checks above, so those remain unchanged.
vi.mock("astro:middleware", () => ({ defineMiddleware: (handler: unknown) => handler }));
vi.mock("virtual:emdash/auth", () => ({ authenticate: vi.fn() }));
vi.mock("@emdash-cms/auth", () => ({ hasScope: vi.fn(() => false), TRANSFER_SCOPES: [] }));
vi.mock("@emdash-cms/auth/adapters/kysely", () => ({
	createKyselyAdapter: vi.fn(() => ({ getUserById: vi.fn(), getUserByEmail: vi.fn() })),
}));

// ---------------------------------------------------------------------------
// NEGATIVE half: the emitted scheduler module.
// ---------------------------------------------------------------------------

// A Vite plugin hook may be a bare function or a { handler } object.
function callHook<T>(hook: unknown, ...args: unknown[]): T {
	const fn = typeof hook === "function" ? hook : (hook as { handler: unknown }).handler;
	return (fn as (...a: unknown[]) => T)(...args);
}

// Build the plugin for a given adapter. The optional second argument is the
// Astro command at the base commit (removed by a valid fix); we pass "dev" so
// that, pre-fix, the local dev session is correctly modelled. Post-fix the
// extra argument is simply ignored (JS drops surplus args), so this call shape
// is valid for both the buggy and the fixed signature.
function schedulerModuleFor(adapterName: string | undefined): string {
	const options = {
		serializableConfig: {},
		resolvedConfig: {},
		pluginDescriptors: [],
		astroConfig: { adapter: adapterName ? { name: adapterName } : undefined },
	} as unknown as VitePluginOptions;

	const plugin = createVirtualModulesPlugin(options, "dev");
	// Reproduce the Cloudflare nested-build pass that happens during `astro dev`.
	callHook(plugin.configResolved, { command: "build" });
	return callHook<string>(plugin.load, RESOLVED_VIRTUAL_SCHEDULER_ID);
}

// A timer-factory module exports a callable `createScheduler` backed by the
// long-lived in-process cron timer; the inert module exports it as `null`.
// We detect the timer factory by its observable shape rather than any single
// identifier, so the assertion is robust to cosmetic differences.
function injectsInWorkerTimer(moduleSource: string): boolean {
	const emitsNull = /createScheduler\s*=\s*null/.test(moduleSource);
	const emitsFactory = /createScheduler\s*\(/.test(moduleSource) || /NodeCronScheduler/.test(moduleSource);
	return emitsFactory && !emitsNull;
}

// ---------------------------------------------------------------------------
// POSITIVE half: the routes the integration injects + the behavior behind them.
// ---------------------------------------------------------------------------

// Drive the real emdash() integration's astro:config:setup hook for a given
// adapter + command and collect the routes it injects. This is the same seam
// the package's own integration tests exercise. Each entry carries both the
// public URL `pattern` and the `entrypoint` the integration reports for that
// route — we never hard-code either, and we never re-call the lower-level
// route injector with a pinned option name. We only need the routes, so the
// other hook callbacks are stubs and the config is the minimal shape those
// tests use.
function injectedRoutes(
	adapterName: string | undefined,
	command: "dev" | "build" | "preview" | "sync",
): Array<{ pattern: string; entrypoint: string }> {
	const root = new URL("file:///tmp/emdash-verify/");
	const astroConfig = {
		root,
		srcDir: new URL("src/", root),
		security: {},
		trailingSlash: "ignore",
		adapter: adapterName ? { name: adapterName } : undefined,
		integrations: [{ name: "@astrojs/react", hooks: {} }],
	};
	const logger = { debug: vi.fn(), error: vi.fn(), info: vi.fn(), warn: vi.fn() };
	const routes: Array<{ pattern: string; entrypoint: string }> = [];

	const integration = emdash({ database: libsql({ url: "libsql://verify.example.com" }) });
	const setup = integration.hooks["astro:config:setup"];
	if (typeof setup !== "function") throw new Error("emdash() has no astro:config:setup hook");
	callHook(setup, {
		command,
		config: astroConfig,
		logger,
		injectRoute: (route: { pattern: string; entrypoint: string }) =>
			routes.push({ pattern: route.pattern, entrypoint: route.entrypoint }),
		addMiddleware: vi.fn(),
		updateConfig: vi.fn(),
	});
	return routes;
}

function injectedRoutePatterns(
	adapterName: string | undefined,
	command: "dev" | "build" | "preview" | "sync",
): string[] {
	return injectedRoutes(adapterName, command).map((route) => route.pattern);
}

// The dev-only maintenance entry point, discovered generically: the route(s)
// the integration injects ONLY on the Cloudflare dev path — not for other
// adapters, not for the no-adapter case, and not for the Cloudflare production
// build. We never name the route; we identify it by WHEN it is wired, which is
// exactly the contract ("a dev-only maintenance entry point, present only for
// Cloudflare dev"). Any endpoint name or transport the fix chooses satisfies
// this.
function cloudflareDevOnlyRoutes(): string[] {
	const cloudflareDev = new Set(injectedRoutePatterns("@astrojs/cloudflare", "dev"));
	const baselines = [
		injectedRoutePatterns("@astrojs/cloudflare", "build"), // Cloudflare production
		injectedRoutePatterns("@astrojs/node", "dev"), // another adapter's dev
		injectedRoutePatterns(undefined, "dev"), // no-adapter dev
	];
	const everElsewhere = new Set(baselines.flat());
	return [...cloudflareDev].filter((pattern) => !everElsewhere.has(pattern));
}

// The full dev-only route record (pattern + the entrypoint the integration
// itself reports), discovered by the same Cloudflare-dev-only set difference
// over the real emdash() hook's output. We load the handler through the path
// the integration would mount — never a hard-coded file path or option name,
// so any route name/file the fix chooses is honored. Returns undefined if no
// such route exists (the shortcut case), which the caller asserts against.
function cloudflareDevOnlyRouteEntry(): { pattern: string; entrypoint: string } | undefined {
	const devPatterns = new Set(cloudflareDevOnlyRoutes());
	if (devPatterns.size === 0) return undefined;
	const cloudflareDevRoutes = injectedRoutes("@astrojs/cloudflare", "dev");
	return cloudflareDevRoutes.find((route) => devPatterns.has(route.pattern));
}

// Import a route module through the entrypoint the integration reports. In this
// source-resolved test environment the built artifact (.mjs) is not present, so
// fall back to the co-located TypeScript source, exactly as the integration's
// own resolveRoute() does at dev time. Name-agnostic: the path comes from the
// integration, not from us.
async function loadRouteModule(entrypoint: string): Promise<Record<string, unknown>> {
	const candidates = [entrypoint, entrypoint.replace(/\.(mjs|js)$/, ".ts")];
	for (const candidate of candidates) {
		try {
			return (await import(/* @vite-ignore */ candidate)) as Record<string, unknown>;
		} catch {
			// try next candidate
		}
	}
	throw new Error(`could not import discovered dev-only route entrypoint: ${entrypoint}`);
}

// The route's request handler, discovered by shape: the first HTTP-method
// export that is a function. We never assume which verb the fix chooses.
function routeHandler(mod: Record<string, unknown>): ((ctx: unknown) => unknown) | undefined {
	for (const method of ["ALL", "POST", "PUT", "PATCH", "DELETE", "GET"]) {
		if (typeof mod[method] === "function") return mod[method] as (ctx: unknown) => unknown;
	}
	return undefined;
}

function requestContext(url: string): unknown {
	return {
		request: new Request(url, { method: "POST" }),
		url: new URL(url),
		locals: {},
		params: {},
	};
}

// The pre-existing auth/CSRF middleware entry point. Loaded dynamically (after
// the module mocks above are in place) exactly as the package's own middleware
// unit suite loads it. Name-agnostic about the fix: we only use the stable
// `onRequest` export.
async function loadAuthOnRequest(): Promise<
	(ctx: unknown, next: () => Promise<Response>) => Promise<Response>
> {
	const mod = await import("../../../../src/astro/middleware/auth.js");
	const onRequest = (mod as Record<string, unknown>).onRequest;
	if (typeof onRequest !== "function") {
		throw new Error("auth middleware has no onRequest export");
	}
	return onRequest as (ctx: unknown, next: () => Promise<Response>) => Promise<Response>;
}

// A cookieless, cross-origin-free POST to a given route — the exact shape the
// long-lived dev host's heartbeat issues (no browser: no session cookie, no
// X-EmDash-Request header, no Origin). This is the request that must survive
// the auth/CSRF middleware in dev for maintenance to actually run.
function heartbeatContext(pattern: string): unknown {
	const url = new URL(pattern, "http://localhost:4321");
	return {
		url,
		request: new Request(url, { method: "POST" }),
		locals: { emdash: { db: {}, config: {} } },
		session: {
			get: vi.fn().mockResolvedValue(null),
			set: vi.fn(),
			destroy: vi.fn(),
		},
		redirect: (location: string) =>
			new Response(null, { status: 302, headers: { Location: location } }),
	};
}

function isClientRejection(response: Response): boolean {
	return response.status >= 400 && response.status < 500;
}

describe("Cloudflare dev scheduled-maintenance driver", () => {
	beforeEach(() => {
		maintenanceSpy.mockClear();
	});

	it("does not wire a detached in-worker timer under the Cloudflare adapter on the dev path", () => {
		const source = schedulerModuleFor("@astrojs/cloudflare");
		// The root-cause invariant: the Cloudflare worker must not be handed a
		// long-lived timer it cannot keep alive.
		expect(injectsInWorkerTimer(source)).toBe(false);
		expect(source).toMatch(/createScheduler\s*=\s*null/);
		expect(source).not.toMatch(/NodeCronScheduler/);
	});

	it("keeps the in-process timer factory for a long-lived adapter (Node)", () => {
		const source = schedulerModuleFor("@astrojs/node");
		expect(injectsInWorkerTimer(source)).toBe(true);
		expect(source).toMatch(/NodeCronScheduler/);
		expect(source).not.toMatch(/createScheduler\s*=\s*null/);
	});

	it("keeps the in-process timer factory when no adapter is configured", () => {
		const source = schedulerModuleFor(undefined);
		expect(injectsInWorkerTimer(source)).toBe(true);
		expect(source).not.toMatch(/createScheduler\s*=\s*null/);
	});

	it("wires a dev-only maintenance entry point so maintenance still runs under Cloudflare dev", () => {
		// The positive half of the fix: dropping the in-worker timer alone makes
		// maintenance run ZERO times. A correct fix must drive it from the
		// long-lived dev host instead, which means wiring a dev-only maintenance
		// entry point reachable only on the Cloudflare dev path. Discovered
		// generically (see cloudflareDevOnlyRoutes) so any endpoint name or
		// host->worker transport the fix chooses passes; a "fix" that emits the
		// inert scheduler module and wires nothing in its place wires no such
		// route and fails.
		const devOnlyRoutes = cloudflareDevOnlyRoutes();
		expect(devOnlyRoutes.length).toBeGreaterThan(0);
	});

	it("drives the dev-only maintenance route from the long-lived host on a repeating heartbeat", async () => {
		// The core of the fix. The long-lived Vite/Node dev host — which DOES have
		// a persistent event loop — must re-enter the worker through an ordinary
		// request on an interval so maintenance keeps running. We drive the
		// integration's astro:server:setup hook for Cloudflare + dev with a fake
		// http server, advance time, and confirm it issues a POST to the
		// generically-discovered dev-only route REPEATEDLY (not a single one-shot
		// run). A shortcut that wires nothing, or runs maintenance only once at
		// startup, issues zero/one such request and fails.
		const devOnlyPatterns = new Set(cloudflareDevOnlyRoutes());
		expect(devOnlyPatterns.size).toBeGreaterThan(0);

		vi.useFakeTimers();
		const realFetch = globalThis.fetch;
		// The host heartbeat re-enters the worker through an ordinary HTTP request.
		// Stub the global request transport so no real socket is opened and we can
		// observe where (and how often) the heartbeat fires. Accept any transport
		// the fix routes through global fetch.
		const fetchMock = vi.fn(async () => ({
			ok: true,
			status: 204,
			json: async () => ({}),
			text: async () => "",
		}));
		globalThis.fetch = fetchMock as unknown as typeof fetch;

		try {
			const root = new URL("file:///tmp/emdash-verify/");
			const astroConfig = {
				root,
				srcDir: new URL("src/", root),
				security: {},
				trailingSlash: "ignore",
				adapter: { name: "@astrojs/cloudflare" },
				integrations: [{ name: "@astrojs/react", hooks: {} }],
			};
			const logger = { debug: vi.fn(), error: vi.fn(), info: vi.fn(), warn: vi.fn() };
			const integration = emdash({ database: libsql({ url: "libsql://verify.example.com" }) });

			// astro:config:setup captures command + adapter so server:setup knows
			// it is on the Cloudflare dev path.
			callHook(integration.hooks["astro:config:setup"], {
				command: "dev",
				config: astroConfig,
				logger,
				injectRoute: vi.fn(),
				addMiddleware: vi.fn(),
				updateConfig: vi.fn(),
			});

			// A minimal dev-server double. The host heartbeat attaches to the
			// server's lifecycle; we record every "listening" subscriber (several
			// integration features subscribe) and a resolved origin for the host to
			// target. `environments: {}` satisfies the unrelated dev-typegen
			// listener the same hook installs.
			const listeners: Record<string, Array<() => void>> = {};
			const httpServer = {
				once(event: string, cb: () => void) {
					(listeners[event] ||= []).push(cb);
					return httpServer;
				},
				address: () => ({ address: "127.0.0.1", port: 4321, family: "IPv4" }),
			};
			const server = {
				httpServer,
				environments: {},
				resolvedUrls: { local: ["http://localhost:4321/"], network: [] },
			};

			const serverSetup = integration.hooks["astro:server:setup"];
			if (typeof serverSetup !== "function") {
				throw new Error("emdash() has no astro:server:setup hook");
			}
			callHook(serverSetup, { server, logger });

			// The dev server comes up: fire the lifecycle subscribers so the host
			// heartbeat arms itself.
			for (const cb of listeners.listening ?? []) cb();

			// Advance well past several heartbeat intervals. A repeating host-driven
			// heartbeat re-fires; a one-shot or absent one does not.
			await vi.advanceTimersByTimeAsync(10 * 60_000);

			const hitsDevOnlyRoute = (call: unknown[]): boolean => {
				const target = call[0];
				const href = target instanceof URL ? target.href : String(target);
				let pathname: string;
				try {
					pathname = new URL(href).pathname;
				} catch {
					pathname = href;
				}
				if (!devOnlyPatterns.has(pathname)) return false;
				// The host drives maintenance via a mutating request (POST), not a
				// plain GET page load.
				const init = call[1] as { method?: string } | undefined;
				const method = (init?.method ?? "GET").toUpperCase();
				return method === "POST";
			};

			const devRouteHeartbeats = fetchMock.mock.calls.filter(hitsDevOnlyRoute);
			// Repeats on an interval => at least two POSTs across the window.
			expect(devRouteHeartbeats.length).toBeGreaterThanOrEqual(2);
		} finally {
			globalThis.fetch = realFetch;
			vi.useRealTimers();
		}
	});

	it("runs maintenance behind the dev-only route in development and refuses it outside development", async () => {
		// The route behind the heartbeat must actually run maintenance in dev and
		// decline to run it outside dev. We load the handler through the entrypoint
		// the integration itself reports for the discovered dev-only route (never a
		// hard-coded file) and drive it directly. A route whose handler runs no
		// maintenance — the cheapest shortcut that still injects a route PATTERN —
		// fails the dev assertion; a route that runs maintenance unconditionally
		// (including outside dev) fails the production-scoping assertion.
		const entry = cloudflareDevOnlyRouteEntry();
		expect(entry).toBeTruthy();

		const mod = await loadRouteModule(entry!.entrypoint);
		const handler = routeHandler(mod);
		expect(typeof handler).toBe("function");

		const ctx = requestContext("http://localhost:4321/_maintenance");

		// Development: maintenance runs and the handler accepts the call.
		maintenanceSpy.mockClear();
		const devResponse = (await handler!(ctx)) as Response;
		expect(maintenanceSpy).toHaveBeenCalledTimes(1);
		expect(devResponse.status).toBeGreaterThanOrEqual(200);
		expect(devResponse.status).toBeLessThan(300);

		// Outside development: maintenance must NOT run and the handler must refuse
		// (a client-error status). import.meta.env.DEV is the standard dev flag the
		// middleware/handler already key on; flip it for this one call.
		maintenanceSpy.mockClear();
		vi.stubEnv("DEV", false);
		try {
			const prodResponse = (await handler!(ctx)) as Response;
			expect(maintenanceSpy).not.toHaveBeenCalled();
			expect(prodResponse.status).toBeGreaterThanOrEqual(400);
			expect(prodResponse.status).toBeLessThan(500);
		} finally {
			vi.unstubAllEnvs();
		}
	});

	it("does not expose that maintenance entry point for other adapters, no adapter, or the production build", () => {
		// Fairness + security guard: the dev-only maintenance entry point must be
		// scoped to the Cloudflare dev path. It must NOT be injected for the Node
		// adapter, the no-adapter case, or the Cloudflare production build. Since
		// cloudflareDevOnlyRoutes() already excludes anything present in those
		// baselines, re-deriving the baselines here and confirming they share no
		// pattern with the discovered dev-only set keeps the scoping explicit.
		const devOnlyRoutes = new Set(cloudflareDevOnlyRoutes());
		const elsewhere = [
			injectedRoutePatterns("@astrojs/cloudflare", "build"),
			injectedRoutePatterns("@astrojs/node", "dev"),
			injectedRoutePatterns(undefined, "dev"),
		].flat();
		for (const pattern of elsewhere) {
			expect(devOnlyRoutes.has(pattern)).toBe(false);
		}
	});

	it("lets the cookieless host heartbeat pass the auth/CSRF middleware in dev, and refuses it outside dev", async () => {
		// The final load-bearing seam. The host heartbeat re-enters the worker as
		// a cookieless, cross-origin-free POST to the dev-only /_emdash/api route.
		// On the base commit the auth middleware CSRF-rejects exactly that request,
		// so a fix that wires the route and runs maintenance in its handler but
		// never exempts the route from the dev auth/CSRF gate still fails in a real
		// dev server: the POST is 403'd before the handler runs and maintenance
		// never fires. We drive the pre-existing auth middleware directly (same seam
		// the package's own middleware unit suite uses) against the
		// generically-discovered dev-only route — no route name is pinned — and
		// require it to be reachable by the cookieless POST in dev. The exemption
		// must not leak into production, so the same POST must be refused when
		// import.meta.env.DEV is false.
		const [pattern] = cloudflareDevOnlyRoutes();
		expect(pattern).toBeTruthy();

		const onRequest = await loadAuthOnRequest();

		// Dev: the heartbeat POST must pass the middleware through to the route.
		vi.stubEnv("DEV", true);
		const devNext = vi.fn(async () => new Response(null, { status: 204 }));
		let devResponse: Response;
		try {
			devResponse = await onRequest(heartbeatContext(pattern), devNext);
		} finally {
			vi.unstubAllEnvs();
		}
		expect(devNext).toHaveBeenCalledTimes(1);
		expect(isClientRejection(devResponse)).toBe(false);

		// Outside dev: the same cookieless POST must be refused (auth/CSRF 4xx) and
		// must never reach the route handler.
		vi.stubEnv("DEV", false);
		const prodNext = vi.fn(async () => new Response(null, { status: 204 }));
		let prodResponse: Response;
		try {
			prodResponse = await onRequest(heartbeatContext(pattern), prodNext);
		} finally {
			vi.unstubAllEnvs();
		}
		expect(prodNext).not.toHaveBeenCalled();
		expect(isClientRejection(prodResponse)).toBe(true);
	});
});
