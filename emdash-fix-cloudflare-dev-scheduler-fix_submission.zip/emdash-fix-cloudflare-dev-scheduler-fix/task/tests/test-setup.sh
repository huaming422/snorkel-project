#!/usr/bin/env bash
# Environment bootstrap for the verifier. Sourced (not exec'd) so env
# vars set here stay live for the verifier subprocess.
#
# The agent phase is offline (agent_offline = true); the full dependency
# closure is already baked into the image at the base commit via
# `pnpm install --frozen-lockfile` with a warm /opt/cache/pnpm-dev store.
# This script runs with the network up (verifier phase) and is
# offline-first: it only touches the network as a logged fallback if the
# baked install is somehow missing. The verifier parses verify.toml with
# the canonical /opt/tooling venv (Python 3.12, tomllib built in), so no
# tomli shim is needed.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/emdash}"
export REPO_DIR
cd "$REPO_DIR"

CORE_DIR="$REPO_DIR/packages/core"

# vitest must be resolvable for packages/core; a miss means a corrupted
# node_modules. The deps are baked offline-first — reinstall from the warm
# pnpm store (offline) only if the binary is actually missing, with a loud
# logged online fallback.
if ! node -e 'require.resolve("vitest/package.json", { paths: ["'"$CORE_DIR"'"] })' >/dev/null 2>&1; then
    echo "test-setup.sh: vitest not resolvable from packages/core. " \
         "The baked node_modules looks corrupt — reinstalling." >&2
    pnpm install --frozen-lockfile --ignore-scripts --offline > /tmp/test-setup-install.log 2>&1 \
        || { echo "test-setup.sh: offline reinstall failed; retrying online." >&2; \
             pnpm install --frozen-lockfile --ignore-scripts > /tmp/test-setup-install.log 2>&1; } \
        || { tail -50 /tmp/test-setup-install.log >&2; exit 1; }
fi

# The verifier and the repo's own unit tests import core source files
# directly via relative paths (src/**/*.ts under the vitest node
# environment), so the agent's edits to packages/core are visible without a
# dist/ rebuild.
#
# One interface the verifier drives — the full `emdash()` Astro integration
# (src/astro/integration/index.ts) — transitively imports the built
# `@emdash-cms/admin` package (its `dist/index.js` + locale manifest). The
# admin dist is gitignored and is NOT present in the baked image, so the
# package's own integration tests that import `emdash()` cannot resolve it
# until it is built. Build it here, exactly as the repo's own `build` script
# does. The admin build compiles only local TypeScript + locale catalogs +
# Tailwind CSS from the already-installed dependency closure, so it runs
# offline; it writes only gitignored outputs (dist/, compiled locales), so it
# does not dirty the graded working tree. It does NOT touch packages/core, so
# the agent's edits are unaffected.
ADMIN_DIR="$REPO_DIR/packages/admin"
if ! node -e 'require.resolve("@emdash-cms/admin", { paths: ["'"$CORE_DIR"'"] })' >/dev/null 2>&1 \
    || [ ! -f "$CORE_DIR/node_modules/@emdash-cms/admin/dist/index.js" ]; then
    echo "test-setup.sh: building @emdash-cms/admin dist (needed by the emdash() integration interface)." >&2
    ( cd "$ADMIN_DIR" && node --run build ) > /tmp/test-setup-admin-build.log 2>&1 \
        || { echo "test-setup.sh: admin build failed." >&2; tail -50 /tmp/test-setup-admin-build.log >&2; exit 1; }
fi

# A second base-commit interface the verifier drives — the auth/CSRF middleware
# (src/astro/middleware/auth.ts, the seam that must exempt the dev-only
# maintenance route) — imports `@emdash-cms/auth` and its `/adapters/kysely`
# subpath. That package's `exports` map points at `dist/*.mjs`, which is
# gitignored and NOT baked into the image, so Vite cannot even resolve the entry
# to apply the test's module mock until the dist exists (the package's own
# middleware unit suite has the same prerequisite). Build it here, exactly as
# the repo's own `build` script does (tsdown over local TypeScript only — no
# network, writes only the gitignored dist/, does not touch packages/core, so
# the agent's edits are unaffected).
AUTH_DIR="$REPO_DIR/packages/auth"
if [ ! -f "$AUTH_DIR/dist/index.mjs" ] || [ ! -f "$AUTH_DIR/dist/adapters/kysely.mjs" ]; then
    echo "test-setup.sh: building @emdash-cms/auth dist (needed by the auth-middleware interface)." >&2
    ( cd "$AUTH_DIR" && node --run build ) > /tmp/test-setup-auth-build.log 2>&1 \
        || { echo "test-setup.sh: auth build failed." >&2; tail -50 /tmp/test-setup-auth-build.log >&2; exit 1; }
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR core=$CORE_DIR"
