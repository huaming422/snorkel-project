## Task

when we run the site locally in development under the cloudflare adapter (`astro dev`), the scheduled background maintenance (plugin cron, scheduled publishing, cleanup, that whole recurring sweep) fires once right around when the app first spins up and then never again for the rest of the dev session. the dev server itself is totally fine: pages serve, nothing crashes, nothing shows up in the console. the only way you notice is that the recurring work silently stops happening. leave the server sitting idle for a minute or so and no further maintenance runs.

it works correctly under the node and bun dev setups, and it works correctly on a deployed cloudflare environment. only local cloudflare dev is broken.

dig in, find the root cause, and get scheduled maintenance running on its normal cadence for the whole local cloudflare dev session. the node and bun dev paths and the production path should keep behaving the way they do today.
