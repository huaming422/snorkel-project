## Task

We have a server-killer in RESTORE of stream values.
A crafted value either takes the process down on the spot or leaves behind a key that looks fine until something touches it later, and the server dies then.
We have reproduced both.
A hostile master can do the same to a replica and a crafted snapshot does it at startup, and with no auth by default the bar to trigger this is network access.

I want these rejected.
RESTORE comes back with an error, no key is left behind and the process keeps serving.
The same bad bytes arriving in a snapshot or from a master leave no key behind either.
Normal stream keys have to keep working as they do today.
