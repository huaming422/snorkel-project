## Task

We keep getting reports that urx crawls come back short.
The run exits clean, with no error and no warning, but the URL list is a fraction of what the archive holds for that domain.
Small domains are fine, the gap shows up on larger, busier ones.
It is not tied to a single archive either, people have hit it with different providers enabled.

Figure out why and fix it.
Users need the full set, and when a crawl cannot get everything they should see a warning that the result may be incomplete instead of a clean exit.
