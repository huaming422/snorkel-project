#!/usr/bin/env bash
# Test-setup for urx-fix-cdx-silent-truncation.
#
# The image bakes the full dependency closure at the base commit and pre-builds
# the test harness (`cargo build --locked --tests`), so the editing phase is
# offline and the verifier's first `cargo test --bin urx` is fast. This script
# only verifies the toolchain and warms the build offline-first, with a logged
# online fallback (this script runs with network; the editing phase does not).

set -euo pipefail

echo "[test-setup] Rust:   $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo:  $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Repo:   /repo/urx"

cd /repo/urx

# Offline-first warm; fall back to a networked build only if the offline cache
# is somehow cold, and log loudly so a fetch at grade time is never silent.
if cargo build --bin urx --offline > /tmp/test-setup-build.log 2>&1; then
    echo "[test-setup] Offline build OK."
else
    echo "[test-setup] Offline build failed; retrying online:" >&2
    tail -40 /tmp/test-setup-build.log >&2 || true
    cargo build --bin urx > /tmp/test-setup-build-online.log 2>&1 \
        || { tail -80 /tmp/test-setup-build-online.log >&2; exit 1; }
    echo "[test-setup] Online fallback build OK."
fi

echo "[test-setup] Setup complete."
