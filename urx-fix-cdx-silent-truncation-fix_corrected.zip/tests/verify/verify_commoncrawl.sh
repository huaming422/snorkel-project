#!/usr/bin/env bash
# Behavioral verifier - Common Crawl page-failure handling.
#
# Same in-crate mechanism as verify_arquivo.sh: append a cfg(test) module to the
# provider source, run it under `cargo test --bin urx`, restore the source.
# Graded on exit code.
set -uo pipefail

CRATE_DIR="${CRATE_DIR:-$PWD}"
[ -f "$CRATE_DIR/Cargo.toml" ] || CRATE_DIR="/repo/urx"
cd "$CRATE_DIR" || { echo "verify_commoncrawl: cannot cd to crate dir"; exit 2; }

SRC="src/providers/commoncrawl.rs"
[ -f "$SRC" ] || { echo "verify_commoncrawl: $SRC not found under $CRATE_DIR"; exit 2; }

BAK="$(mktemp)"
cp "$SRC" "$BAK"
trap 'cp -f "$BAK" "$SRC"; rm -f "$BAK"' EXIT

printf '\n' >> "$SRC"
cat >> "$SRC" <<'RUSTEOF'
#[cfg(test)]
mod verify_commoncrawl {
    // Checks go through the pre-existing mock seam (the cfg(test) base_url
    // field) and the shared partial-result signal (is_partial). The page-count
    // probe uses the default index so no collinfo lookup is needed. Nothing
    // here depends on a newly introduced symbol or tuning constant.
    use super::*;

    // Fixture: the index advertises 3 pages; page 0 and page 2 return one row
    // each, page 1 returns 503. Expected: the fetch succeeds with the URLs from
    // pages 0 and 2, every page is requested at least once (the counts are
    // lower bounds, so retrying the failed page is allowed), and the result is
    // flagged partial.
    #[tokio::test]
    async fn verify_isolated_page_failure_is_survived_and_flagged() {
        let mut server = mockito::Server::new_async().await;

        let _probe = server
            .mock("GET", "/CC-MAIN-2026-17-index")
            .match_query(mockito::Matcher::UrlEncoded(
                "showNumPages".into(),
                "true".into(),
            ))
            .with_status(200)
            .with_body(r#"{"pages": 3, "pageSize": 5, "blocks": 12}"#)
            .expect_at_least(1)
            .create_async()
            .await;
        let page0 = server
            .mock("GET", "/CC-MAIN-2026-17-index")
            .match_query(mockito::Matcher::UrlEncoded("page".into(), "0".into()))
            .with_status(200)
            .with_body("{\"url\": \"https://example.com/a\"}")
            .expect_at_least(1)
            .create_async()
            .await;
        let page1 = server
            .mock("GET", "/CC-MAIN-2026-17-index")
            .match_query(mockito::Matcher::UrlEncoded("page".into(), "1".into()))
            .with_status(503)
            .expect_at_least(1)
            .create_async()
            .await;
        let page2 = server
            .mock("GET", "/CC-MAIN-2026-17-index")
            .match_query(mockito::Matcher::UrlEncoded("page".into(), "2".into()))
            .with_status(200)
            .with_body("{\"url\": \"https://example.com/c\"}")
            .expect_at_least(1)
            .create_async()
            .await;

        let mut provider = CommonCrawlProvider::new();
        provider.base_url = server.url();
        provider.with_retries(0); // no retry back-off in the test

        let reporter = ProgressReporter::new(indicatif::ProgressBar::hidden(), "verify · ");
        let urls = provider
            .fetch_urls_with_progress("example.com", Some(reporter.clone()))
            .await
            .expect("the fetch must succeed");

        assert_eq!(
            urls,
            vec![
                "https://example.com/a".to_string(),
                "https://example.com/c".to_string(),
            ],
            "the rows from pages 0 and 2 must both be returned"
        );
        assert!(
            reporter.is_partial(),
            "a page that returned no rows leaves a gap, so the result must be flagged partial"
        );
        page0.assert();
        page1.assert();
        page2.assert(); // the page after the failure was requested
    }

    // Fixture: the index advertises 2 pages and every page request returns 404.
    // Expected: the fetch returns an error rather than an empty result.
    #[tokio::test]
    async fn verify_first_page_failure_is_fatal() {
        let mut server = mockito::Server::new_async().await;

        let _probe = server
            .mock("GET", "/CC-MAIN-2026-17-index")
            .match_query(mockito::Matcher::UrlEncoded(
                "showNumPages".into(),
                "true".into(),
            ))
            .with_status(200)
            .with_body(r#"{"pages": 2, "pageSize": 5, "blocks": 6}"#)
            .expect_at_least(1)
            .create_async()
            .await;
        let _page0 = server
            .mock("GET", "/CC-MAIN-2026-17-index")
            .match_query(mockito::Matcher::Regex("page=".into()))
            .with_status(404)
            .create_async()
            .await;

        let mut provider = CommonCrawlProvider::new();
        provider.base_url = server.url();
        provider.with_retries(0);

        assert!(
            provider.fetch_urls("example.com").await.is_err(),
            "a failure with nothing collected must surface as an error, not an empty success"
        );
    }

    // Fixture: the index advertises 50 pages; page 0 returns one row and every
    // later page returns 503. Expected: the fetch succeeds with the page 0 URL,
    // the result is flagged partial, and at most 20 of the 49 failing pages
    // are requested.
    #[tokio::test]
    async fn verify_persistent_failures_end_the_walk_early() {
        let mut server = mockito::Server::new_async().await;

        let _probe = server
            .mock("GET", "/CC-MAIN-2026-17-index")
            .match_query(mockito::Matcher::UrlEncoded(
                "showNumPages".into(),
                "true".into(),
            ))
            .with_status(200)
            .with_body(r#"{"pages": 50, "pageSize": 5, "blocks": 250}"#)
            .expect_at_least(1)
            .create_async()
            .await;
        let page0 = server
            .mock("GET", "/CC-MAIN-2026-17-index")
            .match_query(mockito::Matcher::UrlEncoded("page".into(), "0".into()))
            .with_status(200)
            .with_body("{\"url\": \"https://example.com/a\"}")
            .expect_at_least(1)
            .create_async()
            .await;
        // Every page from 1 upwards fails.
        let failing = server
            .mock("GET", "/CC-MAIN-2026-17-index")
            .match_query(mockito::Matcher::Regex(r"page=[1-9][0-9]*".into()))
            .with_status(503)
            .expect_at_least(1)
            .expect_at_most(20)
            .create_async()
            .await;

        let mut provider = CommonCrawlProvider::new();
        provider.base_url = server.url();
        provider.with_retries(0);

        let reporter = ProgressReporter::new(indicatif::ProgressBar::hidden(), "verify · ");
        let urls = provider
            .fetch_urls_with_progress("example.com", Some(reporter.clone()))
            .await
            .expect("the first page succeeded, so the fetch must return what it has");

        assert_eq!(
            urls,
            vec!["https://example.com/a".to_string()],
            "the row from page 0 must be returned"
        );
        assert!(
            reporter.is_partial(),
            "pages were never read, so the result must be flagged partial"
        );
        page0.assert();
        failing.assert(); // request-count bound on the failing pages
    }
}
RUSTEOF

LOG="$(mktemp)"
cargo test --bin urx --offline verify_commoncrawl -- --test-threads=1 --nocapture >"$LOG" 2>&1
RC=$?
cat "$LOG"
EXPECTED=3
if [ "$RC" -ne 0 ]; then
    echo "verify_commoncrawl: FAIL - cargo test exited $RC"
    rm -f "$LOG"
    exit 1
fi
if ! grep -qE "test result: ok\. ${EXPECTED} passed; 0 failed" "$LOG"; then
    echo "verify_commoncrawl: FAIL - expected exactly ${EXPECTED} passing tests; summary:"
    grep -E "test result:" "$LOG" || echo "  (no test-result summary - zero tests ran?)"
    rm -f "$LOG"
    exit 1
fi
echo "verify_commoncrawl: PASS (${EXPECTED} tests)"
rm -f "$LOG"
exit 0
