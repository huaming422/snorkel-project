#!/usr/bin/env bash
# Behavioral verifier - Arquivo.pt result completeness.
#
# urx is a binary crate. The provider's mock seam (with_base_url) and the
# partial-result signal (is_partial) are crate-internal and cfg(test)-gated, so
# the checks run as an in-crate unit test: this script appends a cfg(test)
# module to the provider source, runs it under `cargo test --bin urx`, and
# restores the source afterwards. Graded on exit code: non-zero on any failure,
# including a run in which zero tests executed.
set -uo pipefail

CRATE_DIR="${CRATE_DIR:-$PWD}"
[ -f "$CRATE_DIR/Cargo.toml" ] || CRATE_DIR="/repo/urx"
cd "$CRATE_DIR" || { echo "verify_arquivo: cannot cd to crate dir"; exit 2; }

SRC="src/providers/arquivo.rs"
[ -f "$SRC" ] || { echo "verify_arquivo: $SRC not found under $CRATE_DIR"; exit 2; }

BAK="$(mktemp)"
cp "$SRC" "$BAK"
trap 'cp -f "$BAK" "$SRC"; rm -f "$BAK"' EXIT

# --- appended verifier module -------------------------------------------------
printf '\n' >> "$SRC"
cat >> "$SRC" <<'RUSTEOF'
#[cfg(test)]
mod verify_arquivo {
    // Checks go through the pre-existing mock seam (with_base_url) and the
    // shared partial-result signal (is_partial). Nothing here depends on a
    // newly introduced symbol.
    use super::*;

    // Fixture: the mock CDX endpoint answers every request with the same two
    // rows. Expected: both URLs come back, the result is not flagged partial,
    // and the endpoint is hit at most twice.
    #[tokio::test]
    async fn verify_short_page_is_complete() {
        let mut server = mockito::Server::new_async().await;
        let mock = server
            .mock("GET", "/wayback/cdx")
            .match_query(mockito::Matcher::Any)
            .with_status(200)
            .with_body(
                "{\"url\":\"http://example.com/a\"}\n{\"url\":\"http://example.com/b\"}\n",
            )
            .expect_at_least(1)
            .expect_at_most(2)
            .create_async()
            .await;

        let mut provider = ArquivoProvider::new();
        provider.with_base_url(server.url());

        let reporter = ProgressReporter::new(indicatif::ProgressBar::hidden(), "verify · ");
        let urls = provider
            .fetch_urls_with_progress("example.com", Some(reporter.clone()))
            .await
            .expect("short-page fetch should succeed");

        assert_eq!(
            urls,
            vec![
                "http://example.com/a".to_string(),
                "http://example.com/b".to_string(),
            ],
            "a short page must return the complete URL set"
        );
        assert!(
            !reporter.is_partial(),
            "a complete result must not be flagged partial"
        );
        mock.assert(); // request-count bound
    }

    // Fixture: the mock answers every request with the same 100_000 rows,
    // which collapse to 1_000 distinct URLs; no request parameter changes the
    // body. Expected: the 1_000 distinct URLs are returned, the result is
    // flagged partial, and the endpoint is hit between one and four times.
    #[tokio::test]
    async fn verify_capped_page_with_duplicate_captures_is_partial() {
        let mut body = String::with_capacity(4_000_000);
        for i in 0..100_000usize {
            body.push_str(&format!("{{\"url\":\"http://example.com/p{}\"}}\n", i % 1000));
        }

        let mut server = mockito::Server::new_async().await;
        let mock = server
            .mock("GET", "/wayback/cdx")
            .match_query(mockito::Matcher::Any)
            .with_status(200)
            .with_body(body)
            .expect_at_least(1)
            .expect_at_most(4)
            .create_async()
            .await;

        let mut provider = ArquivoProvider::new();
        provider.with_base_url(server.url());

        let reporter = ProgressReporter::new(indicatif::ProgressBar::hidden(), "verify · ");
        let urls = provider
            .fetch_urls_with_progress("example.com", Some(reporter.clone()))
            .await
            .expect("capped fetch should still return the recovered URLs");

        assert_eq!(
            urls.len(),
            1000,
            "the distinct URLs from the capped page must be retained"
        );
        assert!(
            reporter.is_partial(),
            "a capped page leaves rows unread, so the result must be flagged partial"
        );
        mock.assert(); // request-count bound
    }
}
RUSTEOF
# -----------------------------------------------------------------------------

LOG="$(mktemp)"
cargo test --bin urx --offline verify_arquivo -- --test-threads=1 --nocapture >"$LOG" 2>&1
RC=$?
cat "$LOG"
EXPECTED=2
if [ "$RC" -ne 0 ]; then
    echo "verify_arquivo: FAIL - cargo test exited $RC"
    rm -f "$LOG"
    exit 1
fi
if ! grep -qE "test result: ok\. ${EXPECTED} passed; 0 failed" "$LOG"; then
    echo "verify_arquivo: FAIL - expected exactly ${EXPECTED} passing tests; summary:"
    grep -E "test result:" "$LOG" || echo "  (no test-result summary - zero tests ran?)"
    rm -f "$LOG"
    exit 1
fi
echo "verify_arquivo: PASS (${EXPECTED} tests)"
rm -f "$LOG"
exit 0
