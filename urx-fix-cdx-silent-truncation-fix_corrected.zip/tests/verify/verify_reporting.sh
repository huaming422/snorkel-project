#!/usr/bin/env bash
# Behavioral verifier - an incomplete crawl reaches the user-facing report.
#
# Same in-crate mechanism as the provider verifiers, applied one layer up:
# append a cfg(test) module to the runner source, drive a real provider through
# process_domains against a mock archive, and read the per-provider stats that
# the summary line and the --stats report are built from. The source is
# restored on exit. Graded on exit code.
set -uo pipefail

CRATE_DIR="${CRATE_DIR:-$PWD}"
[ -f "$CRATE_DIR/Cargo.toml" ] || CRATE_DIR="/repo/urx"
cd "$CRATE_DIR" || { echo "verify_reporting: cannot cd to crate dir"; exit 2; }

SRC="src/runner/mod.rs"
[ -f "$SRC" ] || { echo "verify_reporting: $SRC not found under $CRATE_DIR"; exit 2; }

BAK="$(mktemp)"
cp "$SRC" "$BAK"
trap 'cp -f "$BAK" "$SRC"; rm -f "$BAK"' EXIT

printf '\n' >> "$SRC"
cat >> "$SRC" <<'RUSTEOF'
#[cfg(test)]
mod verify_reporting {
    // Drives the Wayback provider through the runner so the partial-result
    // signal is observed where a user sees it: the per-provider stats that
    // feed the summary line and the --stats report. Uses only pre-existing
    // seams (with_base_url, build_test_args) and the runner's entry point.
    use super::*;
    use crate::providers::wayback::WaybackMachineProvider;
    use crate::test_support::build_test_args;

    // The runner only tracks partial results when output is on, so the run is
    // not silent. Progress bars stay hidden.
    fn run_args() -> Args {
        let mut args = build_test_args();
        args.silent = false;
        args.no_progress = true;
        args
    }

    async fn run_one(provider: WaybackMachineProvider) -> ProviderRunResult {
        let providers: Vec<Box<dyn Provider>> = vec![Box::new(provider)];
        let names = vec!["Wayback Machine".to_string()];
        let args = run_args();
        process_domains(
            vec!["example.com".to_string()],
            &args,
            &ProgressManager::new(true),
            &providers,
            &names,
            None,
        )
        .await
    }

    // Fixture: a Wayback mock whose resume cursor cycles (start -> A -> B -> A),
    // each key always serving the same slice.
    // Expected: the run reports three URLs for the domain, counts one partial
    // fetch for the provider, and counts no error.
    #[tokio::test]
    async fn verify_incomplete_crawl_is_counted_partial_in_provider_stats() {
        let mut server = mockito::Server::new_async().await;
        let _mock = server
            .mock("GET", "/cdx/search/cdx")
            .match_query(mockito::Matcher::Any)
            .with_status(200)
            .expect_at_least(1)
            .with_body_from_request(|req| {
                let q = req.path_and_query();
                let (slice, next) = if q.contains("resumeKey=A") {
                    ("a", "B")
                } else if q.contains("resumeKey=B") {
                    ("b", "A")
                } else {
                    ("start", "A")
                };
                format!("http://example.com/{slice}\n\n{next}\n").into_bytes()
            })
            .create_async()
            .await;

        let mut provider = WaybackMachineProvider::new();
        provider.with_base_url(server.url());

        let result = run_one(provider).await;

        assert_eq!(result.urls.len(), 3, "the URLs collected before the stop are reported");
        let stats = &result.stats[0];
        assert_eq!(stats.error_count, 0, "an incomplete crawl is not reported as an error");
        assert_eq!(stats.url_count, 3, "the provider stats count the reported URLs");
        assert_eq!(
            stats.partial_count, 1,
            "an incomplete crawl must be counted as partial, which is what the summary line and the --stats report show the user"
        );
    }

    // Fixture: a single page with two URLs and no resume key.
    // Expected: two URLs, no partial count, no error count.
    #[tokio::test]
    async fn verify_complete_crawl_is_not_counted_partial() {
        let mut server = mockito::Server::new_async().await;
        let _mock = server
            .mock("GET", "/cdx/search/cdx")
            .match_query(mockito::Matcher::Any)
            .with_status(200)
            .with_body("http://example.com/a\nhttp://example.com/b\n")
            .expect_at_least(1)
            .create_async()
            .await;

        let mut provider = WaybackMachineProvider::new();
        provider.with_base_url(server.url());

        let result = run_one(provider).await;

        assert_eq!(result.urls.len(), 2, "both URLs are reported");
        let stats = &result.stats[0];
        assert_eq!(stats.error_count, 0, "a complete crawl is not an error");
        assert_eq!(stats.partial_count, 0, "a complete crawl must not be reported as partial");
    }
}
RUSTEOF

LOG="$(mktemp)"
cargo test --bin urx --offline verify_reporting -- --test-threads=1 --nocapture >"$LOG" 2>&1
RC=$?
cat "$LOG"
EXPECTED=2
if [ "$RC" -ne 0 ]; then
    echo "verify_reporting: FAIL - cargo test exited $RC"
    rm -f "$LOG"
    exit 1
fi
if ! grep -qE "test result: ok\. ${EXPECTED} passed; 0 failed" "$LOG"; then
    echo "verify_reporting: FAIL - expected exactly ${EXPECTED} passing tests; summary:"
    grep -E "test result:" "$LOG" || echo "  (no test-result summary - zero tests ran?)"
    rm -f "$LOG"
    exit 1
fi
echo "verify_reporting: PASS (${EXPECTED} tests)"
rm -f "$LOG"
exit 0
