#!/usr/bin/env bash
# Behavioral verifier - Wayback Machine resume-cursor termination.
#
# Same in-crate mechanism as the other behavioral verifiers: append a cfg(test)
# module to the provider source, run it under `cargo test --bin urx`, restore the
# source. Graded on exit code.
set -uo pipefail

CRATE_DIR="${CRATE_DIR:-$PWD}"
[ -f "$CRATE_DIR/Cargo.toml" ] || CRATE_DIR="/repo/urx"
cd "$CRATE_DIR" || { echo "verify_wayback: cannot cd to crate dir"; exit 2; }

SRC="src/providers/wayback.rs"
[ -f "$SRC" ] || { echo "verify_wayback: $SRC not found under $CRATE_DIR"; exit 2; }

BAK="$(mktemp)"
cp "$SRC" "$BAK"
trap 'cp -f "$BAK" "$SRC"; rm -f "$BAK"' EXIT

printf '\n' >> "$SRC"
cat >> "$SRC" <<'RUSTEOF'
#[cfg(test)]
mod verify_wayback {
    // Checks go through the pre-existing mock seam (with_base_url) and the
    // shared partial-result signal (is_partial). Nothing here depends on a
    // newly introduced symbol.
    use super::*;
    use std::sync::atomic::{AtomicUsize, Ordering};
    use std::sync::Arc;

    // Fixture: the first response carries slice "start" and resume key A; a
    // request with key A returns slice "a" and key B; a request with key B
    // returns slice "b" and key A. The same key always returns the same body.
    // Expected: the fetch returns (no error, no hang) after 3 to 8 requests,
    // all three distinct URLs are present, and the result is flagged partial.
    #[tokio::test]
    async fn verify_cycling_cursor_terminates_and_flags_partial() {
        let requests = Arc::new(AtomicUsize::new(0));
        let counter = requests.clone();

        let mut server = mockito::Server::new_async().await;
        let _mock = server
            .mock("GET", "/cdx/search/cdx")
            .match_query(mockito::Matcher::Any)
            .with_status(200)
            .expect_at_least(1)
            .with_body_from_request(move |req| {
                counter.fetch_add(1, Ordering::SeqCst);
                let q = req.path_and_query();
                let (slice, next) = if q.contains("resumeKey=A") {
                    ("a", "B")
                } else if q.contains("resumeKey=B") {
                    ("b", "A")
                } else {
                    ("start", "A")
                };
                format!("http://example.com/{slice}\n\n{next}\n").into_bytes()
            })
            .create_async()
            .await;

        let mut provider = WaybackMachineProvider::new();
        provider.with_base_url(server.url());

        let reporter = ProgressReporter::new(indicatif::ProgressBar::hidden(), "verify · ");
        let urls = provider
            .fetch_urls_with_progress("example.com", Some(reporter.clone()))
            .await
            .expect("the fetch must return, not error");

        let n = requests.load(Ordering::SeqCst);
        assert!(
            (3..=8).contains(&n),
            "the fetch must finish within a handful of requests, made {n}"
        );
        assert_eq!(
            urls,
            vec![
                "http://example.com/a".to_string(),
                "http://example.com/b".to_string(),
                "http://example.com/start".to_string(),
            ],
            "every distinct slice served before the stop is kept"
        );
        assert!(
            reporter.is_partial(),
            "the server still advertised more results, so the result must be flagged partial"
        );
    }

    // Fixture: the first response carries no rows and resume key KEY2; the
    // response for KEY2 carries two rows and no resume key. Expected: both URLs
    // are returned, each endpoint is hit exactly once, and the result is not
    // flagged partial.
    #[tokio::test]
    async fn verify_new_key_past_empty_page_completes_clean() {
        let mut server = mockito::Server::new_async().await;
        let empty = server
            .mock("GET", "/cdx/search/cdx")
            .match_query(mockito::Matcher::UrlEncoded(
                "showResumeKey".into(),
                "true".into(),
            ))
            .with_status(200)
            .with_body("\nKEY2\n")
            .expect(1)
            .create_async()
            .await;
        let page2 = server
            .mock("GET", "/cdx/search/cdx")
            .match_query(mockito::Matcher::UrlEncoded(
                "resumeKey".into(),
                "KEY2".into(),
            ))
            .with_status(200)
            .with_body("http://example.com/a\nhttp://example.com/b\n")
            .expect(1)
            .create_async()
            .await;

        let mut provider = WaybackMachineProvider::new();
        provider.with_base_url(server.url());

        let reporter = ProgressReporter::new(indicatif::ProgressBar::hidden(), "verify · ");
        let urls = provider
            .fetch_urls_with_progress("example.com", Some(reporter.clone()))
            .await
            .expect("the fetch must succeed");

        assert_eq!(
            urls,
            vec![
                "http://example.com/a".to_string(),
                "http://example.com/b".to_string(),
            ],
            "the rows behind the second key must be returned"
        );
        assert!(
            !reporter.is_partial(),
            "a response with no resume key ends the walk cleanly, so nothing is flagged"
        );
        empty.assert();
        page2.assert();
    }
}
RUSTEOF

LOG="$(mktemp)"
cargo test --bin urx --offline verify_wayback -- --test-threads=1 --nocapture >"$LOG" 2>&1
RC=$?
cat "$LOG"
EXPECTED=2
if [ "$RC" -ne 0 ]; then
    echo "verify_wayback: FAIL - cargo test exited $RC"
    rm -f "$LOG"
    exit 1
fi
if ! grep -qE "test result: ok\. ${EXPECTED} passed; 0 failed" "$LOG"; then
    echo "verify_wayback: FAIL - expected exactly ${EXPECTED} passing tests; summary:"
    grep -E "test result:" "$LOG" || echo "  (no test-result summary - zero tests ran?)"
    rm -f "$LOG"
    exit 1
fi
echo "verify_wayback: PASS (${EXPECTED} tests)"
rm -f "$LOG"
exit 0
