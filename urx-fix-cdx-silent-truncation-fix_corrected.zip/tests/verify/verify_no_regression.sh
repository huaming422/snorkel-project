#!/usr/bin/env bash
# Structural verifier (pass_to_pass) - no-regression guard.
#
# Confirms the change does not break behavior it does not touch:
#   1. the crate still builds (`cargo build --bin urx`), and
#   2. the behavior-stable subset of the pre-existing unit suite still passes.
#
# Scope note (why the arquivo test module is skipped):
#   Several tests in that module pin the provider's old request shape and old
#   stop condition, which a correct change replaces, so they are not
#   behavior-stable. The module is excluded as a whole rather than per test so
#   the guard never depends on which of those tests a submission chose to keep
#   or rewrite. Correctness for the three providers is gated by the behavioral
#   verify_* scripts, not here. Every other module's tests (commoncrawl,
#   wayback, otx, urlscan, network, filters, progress, output, ...) must keep
#   passing. One otx test performs a live DNS lookup and is excluded as
#   environment-dependent.
#
# This runs the submission's own in-tree tests unmodified; it appends nothing and
# mutates no source. Graded on exit code.
set -uo pipefail

CRATE_DIR="${CRATE_DIR:-$PWD}"
[ -f "$CRATE_DIR/Cargo.toml" ] || CRATE_DIR="/repo/urx"
cd "$CRATE_DIR" || { echo "verify_no_regression: cannot cd to crate dir"; exit 2; }

# 1. Compile guard - the binary must still build.
BLOG="$(mktemp)"
cargo build --bin urx --offline >"$BLOG" 2>&1
BRC=$?
cat "$BLOG"
rm -f "$BLOG"
if [ "$BRC" -ne 0 ]; then
    echo "verify_no_regression: FAIL - cargo build --bin urx exited $BRC"
    exit 1
fi

# 2. Behavior-stable subset of the pre-existing suite.
LOG="$(mktemp)"
cargo test --bin urx --offline -- \
    --skip 'providers::arquivo::tests::' \
    --skip 'providers::otx::tests::test_fetch_urls_with_nonexistent_domain' \
    >"$LOG" 2>&1
RC=$?
cat "$LOG"
if [ "$RC" -ne 0 ]; then
    echo "verify_no_regression: FAIL - pre-existing suite regressed (cargo test exited $RC)"
    rm -f "$LOG"
    exit 1
fi
# Fail closed: a result summary with zero tests passed means the skip filters
# swallowed the whole suite (or nothing ran) - treat that as a broken guard, not
# a vacuous pass.
if ! grep -qE "test result: ok\. [1-9][0-9]* passed; 0 failed" "$LOG"; then
    echo "verify_no_regression: FAIL - expected a non-empty all-passing test run; summary:"
    grep -E "test result:" "$LOG" || echo "  (no test-result summary at all)"
    rm -f "$LOG"
    exit 1
fi
echo "verify_no_regression: PASS (build ok; behavior-stable suite green)"
rm -f "$LOG"
exit 0
