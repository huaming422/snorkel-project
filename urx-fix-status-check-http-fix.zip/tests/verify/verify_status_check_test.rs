// Behavioral checks for urx's status-check, link-extraction and discovery
// HTTP behavior.
//
// urx is a binary-only crate (no library target), so every check drives the
// compiled `urx` CLI through `std::process::Command::new(env!("CARGO_BIN_EXE_urx"))`
// and asserts only on what a user sees: stdout, what the local origin was asked
// for, and how long the run took.
//
// Everything runs offline on loopback (127.0.0.1), which is up even under
// `--network none`. The origins are small HTTP/1.1 servers on std threads; the
// "unreachable" URLs point at a closed loopback port, which refuses at once.
//
// Covers:
//   - a redirecting URL under --check-status is reported with its own 3xx, and
//     the page it points at is never requested;
//   - --include-status 30x keeps a redirecting URL;
//   - with --retries 0, --check-status and --extract-links each still make
//     their one request (a reachable URL gets its result) and do not wait on
//     unreachable URLs;
//   - with --retries 1, both modes wait before the retry of an unreachable URL
//     and not again once it has no attempt left;
//   - --extract-links still follows a redirect to the page it points at;
//   - robots.txt and sitemap discovery against a target host still follow a
//     redirect to the moved file.

use std::io::{Read, Write};
use std::net::{TcpListener, TcpStream};
use std::process::Command;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};

/// Unreachable URLs in each timing run. They are tested one at a time
/// (`--parallel 1`), so whatever wait each of them costs is paid this many
/// times over.
const DEAD_URLS: u32 = 5;

/// How long urx waits before retrying a failed request.
const RETRY_WAIT: Duration = Duration::from_millis(500);

/// Upper bound for a `--retries 0` run over one reachable and `DEAD_URLS`
/// unreachable URLs: start-up plus one refused connect per dead URL, with no
/// waits (tens of ms). A wait of 500ms per dead URL makes it 2.5s; even 60ms
/// per dead URL goes over.
const NO_RETRY_LIMIT: Duration = Duration::from_millis(300);

/// Room above the retry waits in a `--retries 1` run, for start-up and the
/// refused connects. A second wait on every dead URL adds 2.5s, far past it.
const RETRY_RUN_SLACK: Duration = Duration::from_millis(400);

/// Each timing check takes the best of this many runs, so one slow process
/// start on a loaded host cannot fail a correct run. A wait is a floor every
/// run pays, so taking the fastest does not hide it.
const TIMING_RUNS: usize = 3;

/// Read one request from `stream` and return its path (the second token of
/// the request line), or `/` when the bytes are not an HTTP request.
fn read_request_path(stream: &mut TcpStream) -> String {
    let mut buf = [0u8; 1024];
    let n = stream.read(&mut buf).unwrap_or(0);
    let req = String::from_utf8_lossy(&buf[..n]);
    req.lines()
        .next()
        .and_then(|l| l.split_whitespace().nth(1))
        .unwrap_or("/")
        .to_string()
}

/// Write a complete response and close: an explicit length and
/// `Connection: close`, so the client sees a clean end with no keep-alive.
fn respond(stream: &mut TcpStream, status_line: &str, headers: &str, body: &str) {
    let response = format!(
        "{status_line}\r\n{headers}Content-Length: {}\r\nConnection: close\r\n\r\n{body}",
        body.len()
    );
    let _ = stream.write_all(response.as_bytes());
    let _ = stream.flush();
}

/// A loopback HTTP/1.1 origin: `GET /redir` answers with `status` and
/// `Location: /final`; any other path (including `/final` and `/ok`) answers
/// `200` with a small HTML page carrying one absolute `<a href>`. Returns the
/// bound port and a counter of how many times `/final` was requested.
fn start_redirect_server(status: u16, reason: &str) -> (u16, Arc<AtomicUsize>) {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind loopback origin");
    let port = listener.local_addr().expect("local addr").port();
    let final_hits = Arc::new(AtomicUsize::new(0));
    let final_hits_thread = Arc::clone(&final_hits);
    let status_line = format!("HTTP/1.1 {status} {reason}");

    std::thread::spawn(move || {
        for stream in listener.incoming() {
            let mut stream = match stream {
                Ok(s) => s,
                Err(_) => continue,
            };
            let path = read_request_path(&mut stream);
            if path.starts_with("/redir") {
                respond(&mut stream, &status_line, "Location: /final\r\n", "");
            } else {
                if path.starts_with("/final") {
                    final_hits_thread.fetch_add(1, Ordering::SeqCst);
                }
                // A tiny HTML page with one absolute link, so an extraction run
                // that reaches this page has something to emit.
                respond(
                    &mut stream,
                    "HTTP/1.1 200 OK",
                    "Content-Type: text/html\r\n",
                    "<html><body><a href=\"http://example.com/found\">link</a></body></html>",
                );
            }
        }
    });

    (port, final_hits)
}

/// A loopback target host whose robots.txt and sitemap.xml have both moved:
/// `/robots.txt` and `/sitemap.xml` answer `301` with a `Location` under
/// `/moved/`, and only the moved copies hold anything (a `Disallow:
/// /from-robots` line, and a sitemap listing `/from-sitemap` on this host).
/// Every other request, including the TLS hello of an https:// attempt, gets a
/// `404`. Returns the bound port.
fn start_moved_discovery_server() -> u16 {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind loopback origin");
    let port = listener.local_addr().expect("local addr").port();
    let moved = "HTTP/1.1 301 Moved Permanently";
    let robots = "User-agent: *\nDisallow: /from-robots\n".to_string();
    let sitemap = format!(
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\
         <urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n\
         <url><loc>http://127.0.0.1:{port}/from-sitemap</loc></url>\n\
         </urlset>\n"
    );

    std::thread::spawn(move || {
        for stream in listener.incoming() {
            let mut stream = match stream {
                Ok(s) => s,
                Err(_) => continue,
            };
            match read_request_path(&mut stream).as_str() {
                "/robots.txt" => respond(&mut stream, moved, "Location: /moved/robots.txt\r\n", ""),
                "/sitemap.xml" => {
                    respond(&mut stream, moved, "Location: /moved/sitemap.xml\r\n", "")
                }
                "/moved/robots.txt" => respond(
                    &mut stream,
                    "HTTP/1.1 200 OK",
                    "Content-Type: text/plain\r\n",
                    &robots,
                ),
                "/moved/sitemap.xml" => respond(
                    &mut stream,
                    "HTTP/1.1 200 OK",
                    "Content-Type: application/xml\r\n",
                    &sitemap,
                ),
                _ => respond(&mut stream, "HTTP/1.1 404 Not Found", "", ""),
            }
        }
    });

    port
}

/// Write `contents` to a `urls.txt` under a fresh temp dir; returns the dir
/// (keep it alive for the file's lifetime) and the file path.
fn urls_file(contents: &str) -> (tempfile::TempDir, std::path::PathBuf) {
    let dir = tempfile::tempdir().expect("temp dir");
    let path = dir.path().join("urls.txt");
    std::fs::write(&path, contents).expect("write urls file");
    (dir, path)
}

/// A loopback port that is closed: bind :0, record the port, drop the
/// listener. Connecting there fails at once (connection refused) with no
/// network wait.
fn closed_loopback_port() -> u16 {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind to reserve port");
    let port = listener.local_addr().expect("local addr").port();
    drop(listener);
    port
}

/// `DEAD_URLS` distinct URLs on one closed loopback port.
fn dead_urls() -> Vec<String> {
    let port = closed_loopback_port();
    (0..DEAD_URLS)
        .map(|i| format!("http://127.0.0.1:{port}/nope-{i}"))
        .collect()
}

fn run_urx(args: &[&str]) -> (std::process::Output, Duration) {
    let start = Instant::now();
    let output = Command::new(env!("CARGO_BIN_EXE_urx"))
        .args(args)
        // Disable ANSI coloring so stdout assertions are on plain text.
        .env("NO_COLOR", "1")
        .output()
        .expect("urx should run");
    let elapsed = start.elapsed();
    (output, elapsed)
}

/// Run urx `TIMING_RUNS` times and return each run's stdout with the fastest
/// wall time.
fn run_urx_best_of(args: &[&str]) -> (Vec<String>, Duration) {
    let mut outputs = Vec::new();
    let mut best = Duration::MAX;
    for _ in 0..TIMING_RUNS {
        let (output, elapsed) = run_urx(args);
        outputs.push(String::from_utf8_lossy(&output.stdout).into_owned());
        best = best.min(elapsed);
    }
    (outputs, best)
}

/// Every dead URL must still be listed in `stdout` (no --include-status
/// allowlist, so a failed check is kept).
fn assert_lists_dead_urls(stdout: &str, dead: &[String], mode: &str) {
    for url in dead {
        assert!(
            stdout.contains(url.as_str()),
            "{mode} should still list the unreachable URL {url}; stdout was: {stdout:?}"
        );
    }
}

#[test]
fn check_status_reports_redirect_with_its_own_status() {
    let (port, final_hits) = start_redirect_server(301, "Moved Permanently");
    let url = format!("http://127.0.0.1:{port}/redir");
    let (_dir, path) = urls_file(&format!("{url}\n"));

    let (output, _) = run_urx(&[
        "--files",
        path.to_str().unwrap(),
        "--check-status",
        "--no-progress",
    ]);
    let stdout = String::from_utf8_lossy(&output.stdout);

    // The checked URL must be reported with its own redirect status (301),
    // never the 200 of the page it points at. Anchor on the bracketed status
    // field (`{url} [{status}]`) so a random loopback port that happens to
    // contain "200"/"301" in its digits can't skew the match.
    assert!(
        stdout.contains("[301"),
        "status line should report the redirect's own 301 status; stdout was: {stdout:?}"
    );
    assert!(
        !stdout.contains("[200"),
        "status check must not report the 200 of the page the redirect points at; stdout was: {stdout:?}"
    );
    assert_eq!(
        final_hits.load(Ordering::SeqCst),
        0,
        "a status check must not request the page the redirect points at (/final)"
    );
}

#[test]
fn include_status_30x_keeps_redirecting_url() {
    let (port, _final_hits) = start_redirect_server(302, "Found");
    let url = format!("http://127.0.0.1:{port}/redir");
    let (_dir, path) = urls_file(&format!("{url}\n"));

    let (output, _) = run_urx(&[
        "--files",
        path.to_str().unwrap(),
        "--check-status",
        "--include-status",
        "30x",
        "--no-progress",
    ]);
    let stdout = String::from_utf8_lossy(&output.stdout);

    assert!(
        stdout.contains(&url) && stdout.contains("[302"),
        "--include-status 30x should keep the redirecting URL with its 302 status; stdout was: {stdout:?}"
    );
}

#[test]
fn check_status_with_no_retries_does_not_wait_on_unreachable_urls() {
    let (live_port, _final_hits) = start_redirect_server(301, "Moved Permanently");
    let live = format!("http://127.0.0.1:{live_port}/ok");
    let dead = dead_urls();
    let (_dir, path) = urls_file(&format!("{live}\n{}\n", dead.join("\n")));

    let (outputs, best) = run_urx_best_of(&[
        "--files",
        path.to_str().unwrap(),
        "--check-status",
        "--retries",
        "0",
        "--parallel",
        "1",
        "--no-progress",
    ]);

    for stdout in &outputs {
        // --retries 0 means no retries, not no request: the reachable URL
        // still gets checked and reported with its status.
        assert!(
            stdout.contains(&format!("{live} [200")),
            "with --retries 0 the reachable URL must still be checked and reported as 200; stdout was: {stdout:?}"
        );
        assert_lists_dead_urls(stdout, &dead, "--check-status");
    }
    assert!(
        best < NO_RETRY_LIMIT,
        "--check-status --retries 0 must not wait on any of {DEAD_URLS} unreachable URLs; fastest of {TIMING_RUNS} runs took {best:?} (limit {NO_RETRY_LIMIT:?})"
    );
}

#[test]
fn extract_links_with_no_retries_does_not_wait_on_unreachable_urls() {
    let (live_port, _final_hits) = start_redirect_server(301, "Moved Permanently");
    let live = format!("http://127.0.0.1:{live_port}/final");
    let dead = dead_urls();
    let (_dir, path) = urls_file(&format!("{live}\n{}\n", dead.join("\n")));

    let (outputs, best) = run_urx_best_of(&[
        "--files",
        path.to_str().unwrap(),
        "--extract-links",
        "--retries",
        "0",
        "--parallel",
        "1",
        "--no-progress",
    ]);

    for stdout in &outputs {
        // The reachable page is still fetched once and its link extracted.
        assert!(
            stdout.contains("http://example.com/found"),
            "with --retries 0 the reachable page must still be fetched and its link extracted; stdout was: {stdout:?}"
        );
        assert_lists_dead_urls(stdout, &dead, "--extract-links");
    }
    assert!(
        best < NO_RETRY_LIMIT,
        "--extract-links --retries 0 must not wait on any of {DEAD_URLS} unreachable URLs; fastest of {TIMING_RUNS} runs took {best:?} (limit {NO_RETRY_LIMIT:?})"
    );
}

/// With one retry allowed, each unreachable URL gets a second attempt after
/// one `RETRY_WAIT`, and nothing more once that attempt fails too. Over
/// `DEAD_URLS` URLs tested one at a time, the run takes the sum of those waits
/// plus start-up.
fn assert_waits_only_between_attempts(mode: &str) {
    let dead = dead_urls();
    let (_dir, path) = urls_file(&format!("{}\n", dead.join("\n")));

    let (outputs, best) = run_urx_best_of(&[
        "--files",
        path.to_str().unwrap(),
        mode,
        "--retries",
        "1",
        "--parallel",
        "1",
        "--no-progress",
    ]);

    for stdout in &outputs {
        assert_lists_dead_urls(stdout, &dead, mode);
    }
    let waits = RETRY_WAIT * DEAD_URLS;
    let floor = waits * 9 / 10;
    let ceiling = waits + RETRY_RUN_SLACK;
    assert!(
        best >= floor,
        "{mode} --retries 1 should wait before the second attempt on each of {DEAD_URLS} unreachable URLs (about {waits:?} in all), but the fastest of {TIMING_RUNS} runs took only {best:?}"
    );
    assert!(
        best <= ceiling,
        "{mode} --retries 1 should not wait again once an unreachable URL has no attempt left; fastest of {TIMING_RUNS} runs took {best:?}, over the {waits:?} of retry waits plus {RETRY_RUN_SLACK:?}"
    );
}

#[test]
fn check_status_with_retries_waits_only_between_attempts() {
    assert_waits_only_between_attempts("--check-status");
}

#[test]
fn extract_links_with_retries_waits_only_between_attempts() {
    assert_waits_only_between_attempts("--extract-links");
}

#[test]
fn extract_links_still_follows_redirects() {
    // Link extraction is after the page's content, so it still follows a
    // redirect: /redir -> 301 -> /final (200, HTML with one link).
    let (port, final_hits) = start_redirect_server(301, "Moved Permanently");
    let url = format!("http://127.0.0.1:{port}/redir");
    let (_dir, path) = urls_file(&format!("{url}\n"));

    let (output, _) = run_urx(&[
        "--files",
        path.to_str().unwrap(),
        "--extract-links",
        "--no-progress",
    ]);
    let stdout = String::from_utf8_lossy(&output.stdout);

    assert!(
        final_hits.load(Ordering::SeqCst) >= 1,
        "--extract-links should follow the redirect and fetch /final; stdout was: {stdout:?}"
    );
    // The link that only exists on /final must surface in the output, so the
    // page behind the redirect was parsed, not just fetched.
    assert!(
        stdout.contains("http://example.com/found"),
        "the link on the page behind the redirect should appear in output; stdout was: {stdout:?}"
    );
}

#[test]
fn robots_and_sitemap_discovery_still_follow_redirects() {
    // Discovery reads files from the target host itself, so a positional
    // 127.0.0.1:PORT target keeps the run on loopback. Only the robots and
    // sitemap providers run, and the cache is off so a stored result from an
    // earlier run cannot stand in for this one.
    let port = start_moved_discovery_server();
    let target = format!("127.0.0.1:{port}");

    let (output, _) = run_urx(&[
        &target,
        "--providers",
        "robots,sitemap",
        "--no-cache",
        "--no-progress",
    ]);
    let stdout = String::from_utf8_lossy(&output.stdout);
    let stderr = String::from_utf8_lossy(&output.stderr);

    // Each URL exists only in the moved copy, so it shows up only if the
    // provider followed the 301 and read the file behind it.
    let from_robots = format!("http://127.0.0.1:{port}/from-robots");
    let from_sitemap = format!("http://127.0.0.1:{port}/from-sitemap");
    assert!(
        stdout.contains(&from_robots),
        "robots.txt discovery should follow the 301 and list {from_robots}; stdout was: {stdout:?}; stderr was: {stderr:?}"
    );
    assert!(
        stdout.contains(&from_sitemap),
        "sitemap discovery should follow the 301 and list {from_sitemap}; stdout was: {stdout:?}; stderr was: {stderr:?}"
    );
}
