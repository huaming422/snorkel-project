// Behavioral checks for urx's status-check and link-extraction HTTP behavior.
//
// urx is a binary-only crate (no library target), so every check drives the
// compiled `urx` CLI through `std::process::Command::new(env!("CARGO_BIN_EXE_urx"))`
// and asserts only on what a user sees: stdout, what the local origin was asked
// for, and how long the run took.
//
// Everything runs offline on loopback (127.0.0.1), which is up even under
// `--network none`. The origin is a small HTTP/1.1 server on a std thread; the
// "unreachable" URLs point at a closed loopback port, which refuses at once.
//
// Covers:
//   - a redirecting URL under --check-status is reported with its own 3xx, and
//     the page it points at is never requested;
//   - --include-status 30x keeps a redirecting URL;
//   - with --retries 0, --check-status and --extract-links each still make
//     their one request (a reachable URL gets its result) and do not wait on
//     an unreachable URL;
//   - with retries on, both modes still wait between attempts;
//   - --extract-links still follows a redirect to the page it points at.

use std::io::{Read, Write};
use std::net::TcpListener;
use std::process::Command;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};

/// Upper bound for a `--retries 0` run that hits one unreachable URL. A run
/// that pauses after its only attempt takes at least 500ms on top of start-up;
/// one that does not takes start-up plus a refused connect (tens of ms).
const NO_RETRY_LIMIT: Duration = Duration::from_millis(400);

/// Lower bound for a `--retries 1` run against an unreachable URL: there is a
/// second attempt, and urx waits before making it.
const RETRY_WAIT_FLOOR: Duration = Duration::from_millis(250);

/// The fast-path timing is the best of this many runs, so one slow process
/// start on a loaded host cannot fail a run that never pauses. A pause after
/// the last attempt is a floor every run pays, so taking the minimum does not
/// hide it.
const TIMING_RUNS: usize = 3;

/// A loopback HTTP/1.1 origin: `GET /redir` answers with `status` and
/// `Location: /final`; any other path (including `/final` and `/ok`) answers
/// `200` with a small HTML page carrying one absolute `<a href>`. Returns the
/// bound port and a counter of how many times `/final` was requested.
fn start_redirect_server(status: u16, reason: &str) -> (u16, Arc<AtomicUsize>) {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind loopback origin");
    let port = listener.local_addr().expect("local addr").port();
    let final_hits = Arc::new(AtomicUsize::new(0));
    let final_hits_thread = Arc::clone(&final_hits);
    let status_line = format!("HTTP/1.1 {status} {reason}\r\n");

    std::thread::spawn(move || {
        for stream in listener.incoming() {
            let mut stream = match stream {
                Ok(s) => s,
                Err(_) => continue,
            };
            let mut buf = [0u8; 1024];
            let n = stream.read(&mut buf).unwrap_or(0);
            let req = String::from_utf8_lossy(&buf[..n]);
            // The second token of the request line is the path.
            let path = req
                .lines()
                .next()
                .and_then(|l| l.split_whitespace().nth(1))
                .unwrap_or("/")
                .to_string();

            let response = if path.starts_with("/redir") {
                // Redirect response: zero-length body, close the connection so
                // the client sees a clean end without chunked/keep-alive games.
                format!(
                    "{status_line}Location: /final\r\nContent-Length: 0\r\nConnection: close\r\n\r\n"
                )
            } else {
                if path.starts_with("/final") {
                    final_hits_thread.fetch_add(1, Ordering::SeqCst);
                }
                // A tiny HTML page with one absolute link, so an extraction run
                // that reaches this page has something to emit.
                let body =
                    "<html><body><a href=\"http://example.com/found\">link</a></body></html>";
                format!(
                    "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",
                    body.len(),
                    body
                )
            };
            let _ = stream.write_all(response.as_bytes());
            let _ = stream.flush();
        }
    });

    (port, final_hits)
}

/// Write `contents` to a `urls.txt` under a fresh temp dir; returns the dir
/// (keep it alive for the file's lifetime) and the file path.
fn urls_file(contents: &str) -> (tempfile::TempDir, std::path::PathBuf) {
    let dir = tempfile::tempdir().expect("temp dir");
    let path = dir.path().join("urls.txt");
    std::fs::write(&path, contents).expect("write urls file");
    (dir, path)
}

/// A loopback port that is closed: bind :0, record the port, drop the
/// listener. Connecting there fails at once (connection refused) with no
/// network wait.
fn closed_loopback_port() -> u16 {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind to reserve port");
    let port = listener.local_addr().expect("local addr").port();
    drop(listener);
    port
}

fn run_urx(args: &[&str]) -> (std::process::Output, Duration) {
    let start = Instant::now();
    let output = Command::new(env!("CARGO_BIN_EXE_urx"))
        .args(args)
        // Disable ANSI coloring so stdout assertions are on plain text.
        .env("NO_COLOR", "1")
        .output()
        .expect("urx should run");
    let elapsed = start.elapsed();
    (output, elapsed)
}

/// Run urx `TIMING_RUNS` times and return each run's stdout with the fastest
/// wall time.
fn run_urx_best_of(args: &[&str]) -> (Vec<String>, Duration) {
    let mut outputs = Vec::new();
    let mut best = Duration::MAX;
    for _ in 0..TIMING_RUNS {
        let (output, elapsed) = run_urx(args);
        outputs.push(String::from_utf8_lossy(&output.stdout).into_owned());
        best = best.min(elapsed);
    }
    (outputs, best)
}

#[test]
fn check_status_reports_redirect_with_its_own_status() {
    let (port, final_hits) = start_redirect_server(301, "Moved Permanently");
    let url = format!("http://127.0.0.1:{port}/redir");
    let (_dir, path) = urls_file(&format!("{url}\n"));

    let (output, _) = run_urx(&[
        "--files",
        path.to_str().unwrap(),
        "--check-status",
        "--no-progress",
    ]);
    let stdout = String::from_utf8_lossy(&output.stdout);

    // The checked URL must be reported with its own redirect status (301),
    // never the 200 of the page it points at. Anchor on the bracketed status
    // field (`{url} [{status}]`) so a random loopback port that happens to
    // contain "200"/"301" in its digits can't skew the match.
    assert!(
        stdout.contains("[301"),
        "status line should report the redirect's own 301 status; stdout was: {stdout:?}"
    );
    assert!(
        !stdout.contains("[200"),
        "status check must not report the 200 of the page the redirect points at; stdout was: {stdout:?}"
    );
    assert_eq!(
        final_hits.load(Ordering::SeqCst),
        0,
        "a status check must not request the page the redirect points at (/final)"
    );
}

#[test]
fn include_status_30x_keeps_redirecting_url() {
    let (port, _final_hits) = start_redirect_server(302, "Found");
    let url = format!("http://127.0.0.1:{port}/redir");
    let (_dir, path) = urls_file(&format!("{url}\n"));

    let (output, _) = run_urx(&[
        "--files",
        path.to_str().unwrap(),
        "--check-status",
        "--include-status",
        "30x",
        "--no-progress",
    ]);
    let stdout = String::from_utf8_lossy(&output.stdout);

    assert!(
        stdout.contains(&url) && stdout.contains("[302"),
        "--include-status 30x should keep the redirecting URL with its 302 status; stdout was: {stdout:?}"
    );
}

#[test]
fn check_status_with_no_retries_does_not_wait_on_unreachable_url() {
    let (live_port, _final_hits) = start_redirect_server(301, "Moved Permanently");
    let live = format!("http://127.0.0.1:{live_port}/ok");
    let dead = format!("http://127.0.0.1:{}/nope", closed_loopback_port());
    let (_dir, path) = urls_file(&format!("{live}\n{dead}\n"));

    let (outputs, best) = run_urx_best_of(&[
        "--files",
        path.to_str().unwrap(),
        "--check-status",
        "--retries",
        "0",
        "--no-progress",
    ]);

    for stdout in &outputs {
        // --retries 0 means no retries, not no request: the reachable URL
        // still gets checked and reported with its status.
        assert!(
            stdout.contains(&format!("{live} [200")),
            "with --retries 0 the reachable URL must still be checked and reported as 200; stdout was: {stdout:?}"
        );
        // And the unreachable one is still listed (no --include-status
        // allowlist, so a failed check is kept with a failure marker).
        assert!(
            stdout.contains(&dead),
            "the unreachable URL should still be listed; stdout was: {stdout:?}"
        );
    }
    assert!(
        best < NO_RETRY_LIMIT,
        "--check-status --retries 0 must not wait after the only attempt on an unreachable URL; fastest of {TIMING_RUNS} runs took {best:?}"
    );
}

#[test]
fn extract_links_with_no_retries_does_not_wait_on_unreachable_url() {
    let (live_port, _final_hits) = start_redirect_server(301, "Moved Permanently");
    let live = format!("http://127.0.0.1:{live_port}/final");
    let dead = format!("http://127.0.0.1:{}/nope", closed_loopback_port());
    let (_dir, path) = urls_file(&format!("{live}\n{dead}\n"));

    let (outputs, best) = run_urx_best_of(&[
        "--files",
        path.to_str().unwrap(),
        "--extract-links",
        "--retries",
        "0",
        "--no-progress",
    ]);

    for stdout in &outputs {
        // The reachable page is still fetched once and its link extracted.
        assert!(
            stdout.contains("http://example.com/found"),
            "with --retries 0 the reachable page must still be fetched and its link extracted; stdout was: {stdout:?}"
        );
        assert!(
            stdout.contains(&dead),
            "the unreachable URL should still be listed; stdout was: {stdout:?}"
        );
    }
    assert!(
        best < NO_RETRY_LIMIT,
        "--extract-links --retries 0 must not wait after the only attempt on an unreachable URL; fastest of {TIMING_RUNS} runs took {best:?}"
    );
}

/// With one retry allowed, an unreachable URL gets a second attempt and urx
/// waits before making it.
fn assert_waits_before_retry(mode: &str) {
    let dead = format!("http://127.0.0.1:{}/nope", closed_loopback_port());
    let (_dir, path) = urls_file(&format!("{dead}\n"));

    let (output, elapsed) = run_urx(&[
        "--files",
        path.to_str().unwrap(),
        mode,
        "--retries",
        "1",
        "--no-progress",
    ]);
    let stdout = String::from_utf8_lossy(&output.stdout);

    assert!(
        stdout.contains(&dead),
        "{mode} should still list the unreachable URL; stdout was: {stdout:?}"
    );
    assert!(
        elapsed >= RETRY_WAIT_FLOOR,
        "{mode} --retries 1 should wait between its two attempts on an unreachable URL, but the run took only {elapsed:?}"
    );
}

#[test]
fn check_status_retries_still_wait_between_attempts() {
    assert_waits_before_retry("--check-status");
}

#[test]
fn extract_links_retries_still_wait_between_attempts() {
    assert_waits_before_retry("--extract-links");
}

#[test]
fn extract_links_still_follows_redirects() {
    // Link extraction is after the page's content, so it still follows a
    // redirect: /redir -> 301 -> /final (200, HTML with one link).
    let (port, final_hits) = start_redirect_server(301, "Moved Permanently");
    let url = format!("http://127.0.0.1:{port}/redir");
    let (_dir, path) = urls_file(&format!("{url}\n"));

    let (output, _) = run_urx(&[
        "--files",
        path.to_str().unwrap(),
        "--extract-links",
        "--no-progress",
    ]);
    let stdout = String::from_utf8_lossy(&output.stdout);

    assert!(
        final_hits.load(Ordering::SeqCst) >= 1,
        "--extract-links should follow the redirect and fetch /final; stdout was: {stdout:?}"
    );
    // The link that only exists on /final must surface in the output, so the
    // page behind the redirect was parsed, not just fetched.
    assert!(
        stdout.contains("http://example.com/found"),
        "the link on the page behind the redirect should appear in output; stdout was: {stdout:?}"
    );
}
