## Task

`urx --check-status` gets redirects wrong. A URL that answers 301 is listed with the status of the page it points to, and `--include-status 30x` never keeps anything, even though the docs use it in their examples. Only the status check has this problem. The providers and `--extract-links` should still follow a redirect to the page it leads to.

Both `--check-status` and `--extract-links` are also slow on lists with dead hosts. Every unreachable URL holds up the run before urx moves on, even with `--retries 0`. When retries are turned on, keep the wait between attempts.
