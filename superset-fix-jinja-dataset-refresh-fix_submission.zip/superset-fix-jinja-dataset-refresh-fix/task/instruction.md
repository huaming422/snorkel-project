## Task

saving a virtual dataset whose sql has jinja in it (the `{% if ... %}` / `{{ ... }}` kind) incorrectly throws an "Invalid SQL" error toast in the dataset editor, but the save actually goes through fine. reopen the editor and all your edits are there, so the error is wrong. it only happens with jinja in the sql; plain-sql virtual datasets save with no complaint. figure out why we're surfacing that spurious error and stop it.
