#!/usr/bin/env bash
# Confirm that the aube and aube-store library targets build successfully.
# Return the compiler exit status and diagnostics to the caller.
set -euo pipefail
cd /repo/aube
cargo check -p aube -p aube-store
