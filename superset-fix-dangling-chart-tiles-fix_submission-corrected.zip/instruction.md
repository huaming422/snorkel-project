## Task

When a chart gets deleted, every dashboard that had it keeps a dead tile. The chart comes off the dashboard's chart list, but its layout node stays. Each save from the editor writes that node back as type CHART, with the old `chartId` and a null `uuid`. A PUT with a raw `position_json` keeps the node too, and so does Save as.

A dead tile needs to hold its row position and size and stop pointing at any chart, so nothing reflows. That goes for all three, with or without copying the charts on Save as.

Older and imported layouts sometimes hold a `chartId` as a digit string or a whole-number float, like `"42"` or `42.0`. Those still mean chart 42, in saves and in copies. Anything else, like `true` or `"CHART-3"`, doesn't name a chart. Today an editor save with such a value either goes through, and the chart behind that tile falls off the list, or dies with an error that doesn't say what's wrong. We want that save turned down with a validation error and the dashboard left as it was, and the same for a copy with such a tile.

When Save as copies the charts and a tile names a chart that still exists but isn't on the dashboard, the copy blanks that tile today. We want that copy turned down too.

Some clients PUT a `position_json` of `null` or `5`, valid JSON with no tiles in it. Store that as sent, whichever dashboard it's on.
