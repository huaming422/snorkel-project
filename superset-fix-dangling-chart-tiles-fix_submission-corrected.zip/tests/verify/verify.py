"""Dashboard layout and chart list, checked through the dashboard REST API.

Every case sends a request to PUT /api/v1/dashboard/<id> or
POST /api/v1/dashboard/<id>/copy/ and reads what's stored afterwards. No case
names anything below the routes, so where the work happens is open.

The app runs on in-memory SQLite with one session shared by the test and the
routes. Access checks are switched off the way the repo's own unit tests do it.

Layouts have the shape the dashboard editor saves: DASHBOARD_VERSION_KEY, ROOT_ID,
GRID_ID and HEADER_ID, one row, and chart tiles next to a markdown note.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Iterator
from unittest.mock import patch

import pytest

GONE_ID = 987_654_321
GONE_UUID = "11111111-2222-3333-4444-555555555555"

# What a dashboard row can hold and draw, from the frontend's own child rules. Any
# other type draws nothing, and the row closes up around it.
ROW_CHILD_TYPES = frozenset({"CHART", "MARKDOWN", "COLUMN", "DYNAMIC"})

# The statuses the API answers a validation error with.
VALIDATION_STATUSES = (400, 422)


@pytest.fixture(scope="session")
def _app() -> Iterator[Any]:
    from superset.app import SupersetApp
    from superset.extensions import appbuilder
    from superset.initialization import SupersetAppInitializer

    app = SupersetApp(__name__)
    app.config.from_object("superset.config")
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite://"
    app.config["WTF_CSRF_ENABLED"] = False
    app.config["TESTING"] = True
    app.config["RATELIMIT_ENABLED"] = False
    app.config["PREVENT_UNSAFE_DB_CONNECTIONS"] = False
    app.config["CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["FILTER_STATE_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["EXPLORE_FORM_DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["GLOBAL_ASYNC_QUERIES_REDIS_CONFIG"] = None
    app.config["TALISMAN_ENABLED"] = False

    # The appbuilder singleton keeps views across inits, so clear it first.
    appbuilder.baseviews = []
    SupersetAppInitializer(app).init_app()

    with app.app_context():
        yield app


@pytest.fixture
def session(_app: Any, monkeypatch: pytest.MonkeyPatch) -> Iterator[Any]:
    """A fresh in-memory database behind superset.db.session for each test."""
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    from sqlalchemy.pool import StaticPool

    from superset import db as _db
    from superset import security_manager
    from superset.models.dashboard import Dashboard

    engine = create_engine(
        "sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool
    )
    in_memory_session = sessionmaker(bind=engine)()
    # Flask calls db.session.remove() on teardown.
    in_memory_session.remove = lambda: None  # type: ignore[method-assign]
    monkeypatch.setattr(_db, "session", in_memory_session, raising=False)
    monkeypatch.setattr(
        type(security_manager), "session", in_memory_session, raising=False
    )
    Dashboard.metadata.create_all(engine)
    try:
        yield in_memory_session
    finally:
        in_memory_session.close()
        engine.dispose()


@pytest.fixture
def client(_app: Any, session: Any) -> Iterator[Any]:
    from flask_appbuilder.security.sqla.models import User

    from superset import security_manager

    editor = User(
        first_name="Ann",
        last_name="Editor",
        username="ann",
        email="ann@example.com",
        active=True,
    )
    session.add(editor)
    session.commit()
    with (
        patch("flask_login.utils._get_user", return_value=editor),
        patch(
            "flask_appbuilder.security.decorators.verify_jwt_in_request",
            return_value=True,
        ),
        patch.object(security_manager, "is_item_public", return_value=True),
        patch.object(security_manager, "has_access", return_value=True),
        patch.object(security_manager, "can_access_all_databases", return_value=True),
        patch.object(security_manager, "is_admin", return_value=True),
        patch.object(security_manager, "is_editor", return_value=True),
        patch.object(security_manager, "raise_for_editorship"),
        patch.object(security_manager, "raise_for_access"),
    ):
        with _app.test_client() as test_client:
            yield test_client


@pytest.fixture
def trash_is_on(_app: Any) -> Iterator[None]:
    """SOFT_DELETE on, so a trashed chart is hidden from ordinary reads."""
    from superset.extensions import feature_flag_manager

    original = feature_flag_manager.get_feature_flags

    def _with_soft_delete() -> dict[str, bool]:
        return {**(feature_flag_manager._feature_flags or {}), "SOFT_DELETE": True}

    feature_flag_manager.get_feature_flags = _with_soft_delete  # type: ignore[assignment]
    try:
        yield
    finally:
        feature_flag_manager.get_feature_flags = original  # type: ignore[assignment]


def _tile(key: str, chart_id: Any, width: int = 4, height: int = 50) -> dict[str, Any]:
    return {
        "type": "CHART",
        "id": key,
        "children": [],
        "parents": ["ROOT_ID", "GRID_ID", "ROW-1"],
        "meta": {
            "chartId": chart_id,
            "width": width,
            "height": height,
            "uuid": GONE_UUID,
            "sliceName": "A chart",
        },
    }


def _layout(*tiles: dict[str, Any]) -> dict[str, Any]:
    layout: dict[str, Any] = {
        "DASHBOARD_VERSION_KEY": "v2",
        "ROOT_ID": {"id": "ROOT_ID", "type": "ROOT", "children": ["GRID_ID"]},
        "GRID_ID": {
            "id": "GRID_ID",
            "type": "GRID",
            "children": ["ROW-1"],
            "parents": ["ROOT_ID"],
        },
        "HEADER_ID": {"id": "HEADER_ID", "type": "HEADER", "meta": {"text": "Sales"}},
        "ROW-1": {
            "id": "ROW-1",
            "type": "ROW",
            "children": [tile["id"] for tile in tiles] + ["MARKDOWN-1"],
            "parents": ["ROOT_ID", "GRID_ID"],
            "meta": {"background": "BACKGROUND_TRANSPARENT"},
        },
        "MARKDOWN-1": {
            "id": "MARKDOWN-1",
            "type": "MARKDOWN",
            "children": [],
            "parents": ["ROOT_ID", "GRID_ID", "ROW-1"],
            "meta": {"code": "Notes", "width": 2, "height": 20},
        },
    }
    for tile in tiles:
        layout[tile["id"]] = tile
    return layout


def _tabbed_layout() -> dict[str, Any]:
    return {
        "ROOT_ID": {"id": "ROOT_ID", "type": "ROOT", "children": ["TABS-1"]},
        "TABS-1": {"id": "TABS-1", "type": "TABS", "children": ["TAB-1"]},
        "TAB-1": {
            "id": "TAB-1",
            "type": "TAB",
            "children": [],
            "meta": {"text": "Tab one"},
        },
    }


def _seed(
    session: Any,
    *,
    members: int = 2,
    others: int = 0,
    trashed: int = 0,
    stored: dict[str, Any] | None = None,
) -> tuple[Any, list[Any]]:
    """A dashboard with its charts committed.

    The list holds the members first, then the trashed members, then charts that
    exist and aren't on the dashboard.
    """
    from superset.connectors.sqla.models import Database, SqlaTable
    from superset.models.dashboard import Dashboard
    from superset.models.slice import Slice

    dataset = SqlaTable(
        table_name="sales",
        database=Database(database_name="main", sqlalchemy_uri="sqlite://"),
    )
    session.add(dataset)
    session.flush()
    charts = []
    for index in range(members + trashed + others):
        fields: dict[str, Any] = {
            "slice_name": f"chart {index}",
            "datasource_id": dataset.id,
            "datasource_type": "table",
        }
        if members <= index < members + trashed:
            fields["deleted_at"] = datetime(2026, 1, 1, tzinfo=timezone.utc)
        charts.append(Slice(**fields))
    session.add_all(charts)
    session.flush()
    dashboard = Dashboard(
        dashboard_title="Sales",
        slices=charts[: members + trashed],
        published=True,
    )
    if stored is not None:
        dashboard.position_json = json.dumps(stored)
    session.add(dashboard)
    session.commit()
    return dashboard, charts


def _put(client: Any, dashboard: Any, payload: dict[str, Any]) -> Any:
    return client.put(f"/api/v1/dashboard/{dashboard.id}", json=payload)


def _save(client: Any, dashboard: Any, layout: dict[str, Any]) -> Any:
    """What the dashboard editor sends: the layout as positions in json_metadata."""
    return _put(client, dashboard, {"json_metadata": json.dumps({"positions": layout})})


def _copy(client: Any, dashboard: Any, layout: dict[str, Any], with_charts: bool) -> Any:
    return client.post(
        f"/api/v1/dashboard/{dashboard.id}/copy/",
        json={
            "dashboard_title": "Sales copy",
            "json_metadata": json.dumps({"positions": layout}),
            "duplicate_slices": with_charts,
        },
    )


def _stored_layout(session: Any, dashboard: Any) -> Any:
    session.rollback()
    session.expire(dashboard, ["position_json"])
    return json.loads(dashboard.position_json) if dashboard.position_json else None


def _member_ids(session: Any, dashboard: Any) -> set[int]:
    from superset.models.helpers import skip_visibility_filter
    from superset.models.slice import Slice

    session.rollback()
    with skip_visibility_filter(session, Slice):
        session.expire(dashboard, ["slices"])
        return {chart.id for chart in dashboard.slices}


def _copy_result(session: Any, response: Any) -> Any:
    from superset.models.dashboard import Dashboard

    assert response.status_code == 200, response.get_data(as_text=True)
    session.rollback()
    return session.get(Dashboard, response.get_json()["result"]["id"])


def _names_a_chart(node: dict[str, Any]) -> bool:
    if node.get("type") != "CHART":
        return False
    meta = node.get("meta")
    return isinstance(meta, dict) and meta.get("chartId") is not None


def _assert_live(node: dict[str, Any], chart_id: int) -> None:
    assert _names_a_chart(node), node
    assert int(node["meta"]["chartId"]) == chart_id, node


def _assert_inert_slot(
    layout: dict[str, Any], key: str, width: int, height: int
) -> None:
    """The slot is still in its row at its size and points at no chart."""
    assert key in layout, sorted(layout)
    node = layout[key]
    assert not _names_a_chart(node), node
    assert node.get("type") in ROW_CHILD_TYPES, node
    assert node.get("id") == key, node
    assert node.get("parents") == ["ROOT_ID", "GRID_ID", "ROW-1"], node
    meta = node.get("meta") or {}
    assert (meta.get("width"), meta.get("height")) == (width, height), node
    assert meta.get("chartId") != GONE_ID, node
    assert not meta.get("uuid"), node


def _strings_in(value: Any) -> list[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, dict):
        return [s for k, v in value.items() for s in (*_strings_in(k), *_strings_in(v))]
    if isinstance(value, list):
        return [s for item in value for s in _strings_in(item)]
    return []


def _assert_refused_naming(response: Any, key: str, value: Any) -> None:
    """A validation error whose message names the tile's key or quotes its value."""
    body = response.get_data(as_text=True)
    assert response.status_code in VALIDATION_STATUSES, body
    try:
        message = " ".join(_strings_in(response.get_json()))
    except Exception:  # noqa: BLE001
        message = body
    spellings = {
        key,
        json.dumps(value),
        json.dumps(value, separators=(",", ":")),
        repr(value),
        str(value),
    }
    assert any(spelling in message for spelling in spellings), body


def _chart_ids_on(layout: dict[str, Any]) -> set[int]:
    return {
        int(node["meta"]["chartId"])
        for node in layout.values()
        if isinstance(node, dict) and _names_a_chart(node)
    }


# ---------------------------------------------------------------------------- #
# A save from the editor with a tile whose chart no longer exists.
# ---------------------------------------------------------------------------- #
def test_save_turns_dead_tile_into_an_empty_slot(client: Any, session: Any) -> None:
    dashboard, charts = _seed(session, members=2)
    live_id = charts[0].id
    layout = _layout(_tile("CHART-live", live_id), _tile("CHART-gone", GONE_ID, 6, 30))

    response = _save(client, dashboard, layout)

    assert response.status_code == 200, response.get_data(as_text=True)
    saved = _stored_layout(session, dashboard)
    _assert_inert_slot(saved, "CHART-gone", 6, 30)
    _assert_live(saved["CHART-live"], live_id)
    assert saved["ROW-1"]["children"] == ["CHART-live", "CHART-gone", "MARKDOWN-1"]
    assert saved["MARKDOWN-1"] == layout["MARKDOWN-1"]
    assert saved["HEADER_ID"] == layout["HEADER_ID"]
    assert saved["DASHBOARD_VERSION_KEY"] == "v2"
    assert _member_ids(session, dashboard) == {live_id}


def test_save_after_really_deleting_the_chart(client: Any, session: Any) -> None:
    dashboard, charts = _seed(session, members=2)
    live_id, deleted_id = charts[0].id, charts[1].id
    layout = _layout(_tile("CHART-live", live_id), _tile("CHART-gone", deleted_id, 6, 30))
    dashboard.position_json = json.dumps(layout)
    session.commit()
    session.delete(charts[1])
    session.commit()

    response = _save(client, dashboard, layout)

    assert response.status_code == 200, response.get_data(as_text=True)
    saved = _stored_layout(session, dashboard)
    _assert_inert_slot(saved, "CHART-gone", 6, 30)
    assert saved["CHART-gone"].get("meta", {}).get("chartId") != deleted_id
    _assert_live(saved["CHART-live"], live_id)
    assert _member_ids(session, dashboard) == {live_id}


def test_save_empties_every_dead_tile_and_nothing_else(
    client: Any, session: Any
) -> None:
    dashboard, charts = _seed(session, members=1)
    layout = _layout(
        _tile("CHART-gone-1", GONE_ID, 7, 11),
        _tile("CHART-live", charts[0].id),
        _tile("CHART-gone-2", GONE_ID + 1, 3, 40),
    )

    assert _save(client, dashboard, layout).status_code == 200

    saved = _stored_layout(session, dashboard)
    _assert_inert_slot(saved, "CHART-gone-1", 7, 11)
    _assert_inert_slot(saved, "CHART-gone-2", 3, 40)
    _assert_live(saved["CHART-live"], charts[0].id)
    assert _chart_ids_on(saved) == {charts[0].id}


def test_save_after_the_repair_keeps_the_empty_slot(client: Any, session: Any) -> None:
    dashboard, charts = _seed(session, members=1)
    layout = _layout(
        _tile("CHART-live", charts[0].id), _tile("CHART-gone", GONE_ID, 6, 30)
    )
    assert _save(client, dashboard, layout).status_code == 200
    first = _stored_layout(session, dashboard)

    response = _save(client, dashboard, first)

    assert response.status_code == 200, response.get_data(as_text=True)
    second = _stored_layout(session, dashboard)
    _assert_inert_slot(second, "CHART-gone", 6, 30)
    _assert_live(second["CHART-live"], charts[0].id)
    assert _member_ids(session, dashboard) == {charts[0].id}


def test_save_keeps_a_trashed_member_as_a_chart(
    client: Any, session: Any, trash_is_on: None
) -> None:
    dashboard, charts = _seed(session, members=1, trashed=1)
    live_id, trashed_id = charts[0].id, charts[1].id
    layout = _layout(
        _tile("CHART-live", live_id),
        _tile("CHART-trashed", trashed_id),
        _tile("CHART-gone", GONE_ID, 6, 30),
    )

    assert _save(client, dashboard, layout).status_code == 200

    saved = _stored_layout(session, dashboard)
    _assert_live(saved["CHART-trashed"], trashed_id)
    _assert_live(saved["CHART-live"], live_id)
    _assert_inert_slot(saved, "CHART-gone", 6, 30)
    assert _member_ids(session, dashboard) == {live_id, trashed_id}


# ---------------------------------------------------------------------------- #
# Saves with nothing dead in them.
# ---------------------------------------------------------------------------- #
def test_save_leaves_a_layout_of_present_charts_as_it_is(
    client: Any, session: Any
) -> None:
    dashboard, charts = _seed(session, members=2)
    layout = _layout(_tile("CHART-a", charts[0].id), _tile("CHART-b", charts[1].id, 3, 20))

    assert _save(client, dashboard, layout).status_code == 200

    saved = _stored_layout(session, dashboard)
    assert set(saved) == set(layout)
    for key, node in layout.items():
        if key.startswith("CHART-"):
            kept = {**saved[key], "meta": {**saved[key]["meta"], "uuid": GONE_UUID}}
            assert kept == node, saved[key]
        else:
            assert saved[key] == node, saved[key]
    assert _member_ids(session, dashboard) == {charts[0].id, charts[1].id}


def test_save_chart_list_follows_the_layout(client: Any, session: Any) -> None:
    dashboard, charts = _seed(session, members=2, others=1)
    kept_id, taken_off_id, new_id = (chart.id for chart in charts)
    layout = _layout(_tile("CHART-kept", kept_id), _tile("CHART-new", new_id))

    assert _save(client, dashboard, layout).status_code == 200

    saved = _stored_layout(session, dashboard)
    _assert_live(saved["CHART-kept"], kept_id)
    _assert_live(saved["CHART-new"], new_id)
    assert _member_ids(session, dashboard) == {kept_id, new_id}
    assert taken_off_id not in _chart_ids_on(saved)


def test_save_accepts_an_empty_slot_left_by_an_older_copy(
    client: Any, session: Any
) -> None:
    dashboard, charts = _seed(session, members=1)
    layout = _layout(_tile("CHART-live", charts[0].id), _tile("CHART-empty", None, 6, 30))
    layout["CHART-empty"]["meta"].pop("uuid")

    response = _save(client, dashboard, layout)

    assert response.status_code == 200, response.get_data(as_text=True)
    saved = _stored_layout(session, dashboard)
    _assert_inert_slot(saved, "CHART-empty", 6, 30)
    _assert_live(saved["CHART-live"], charts[0].id)
    assert _member_ids(session, dashboard) == {charts[0].id}


@pytest.mark.parametrize("form", ["digit_string", "whole_float"])
def test_save_reads_an_id_written_as_a_number_in_another_form(
    client: Any, session: Any, form: str
) -> None:
    dashboard, charts = _seed(session, members=2)
    first_id, second_id = charts[0].id, charts[1].id
    first_uuid = str(charts[0].uuid)
    written: Any = str(first_id) if form == "digit_string" else float(first_id)
    layout = _layout(_tile("CHART-first", written), _tile("CHART-second", second_id))

    response = _save(client, dashboard, layout)

    assert response.status_code == 200, response.get_data(as_text=True)
    saved = _stored_layout(session, dashboard)
    _assert_live(saved["CHART-first"], first_id)
    assert saved["CHART-first"]["meta"]["uuid"] == first_uuid, saved["CHART-first"]
    _assert_live(saved["CHART-second"], second_id)
    assert _member_ids(session, dashboard) == {first_id, second_id}


# ---------------------------------------------------------------------------- #
# A save from the editor with a chart reference nothing can read.
# ---------------------------------------------------------------------------- #
UNREADABLE: list[tuple[str, Any]] = [
    ("true", True),
    ("text", "CHART-bad"),
    ("digits_then_text", "1abc"),
    ("list", [1]),
    ("object", {"id": 1}),
    ("fraction", 1.25),
]


@pytest.mark.parametrize(
    "unreadable", [value for _, value in UNREADABLE], ids=[name for name, _ in UNREADABLE]
)
def test_save_refuses_an_unreadable_chart_id(
    client: Any, session: Any, unreadable: Any
) -> None:
    # The first chart is off the dashboard, so reading true or "1abc" as 1 would
    # pull it in.
    dashboard, charts = _seed(session, members=0, others=3)
    other_id, on_layout_id, off_layout_id = (chart.id for chart in charts)
    dashboard.slices = [charts[1], charts[2]]
    before = _layout(_tile("CHART-ok", on_layout_id))
    dashboard.position_json = json.dumps(before)
    session.commit()
    assert other_id == 1
    layout = _layout(_tile("CHART-ok", on_layout_id), _tile("CHART-bad", unreadable, 6, 30))

    response = _save(client, dashboard, layout)

    _assert_refused_naming(response, "CHART-bad", unreadable)
    assert _stored_layout(session, dashboard) == before
    assert _member_ids(session, dashboard) == {on_layout_id, off_layout_id}


# ---------------------------------------------------------------------------- #
# A PUT that sends the layout in the raw position_json field.
# ---------------------------------------------------------------------------- #
RAW_PAYLOADS: dict[str, dict[str, str]] = {
    "alone": {},
    "next_to_other_metadata": {"json_metadata": json.dumps({"color_scheme": "d3Category10"})},
    "next_to_null_positions": {"json_metadata": json.dumps({"positions": None})},
}


@pytest.mark.parametrize("extra", list(RAW_PAYLOADS))
def test_raw_layout_put_empties_a_dead_tile(
    client: Any, session: Any, trash_is_on: None, extra: str
) -> None:
    dashboard, charts = _seed(session, members=1, trashed=1)
    live_id, trashed_id = charts[0].id, charts[1].id
    layout = _layout(
        _tile("CHART-live", live_id),
        _tile("CHART-trashed", trashed_id),
        _tile("CHART-gone", GONE_ID, 6, 30),
    )

    response = _put(
        client, dashboard, {"position_json": json.dumps(layout), **RAW_PAYLOADS[extra]}
    )

    assert response.status_code == 200, response.get_data(as_text=True)
    saved = _stored_layout(session, dashboard)
    _assert_inert_slot(saved, "CHART-gone", 6, 30)
    _assert_live(saved["CHART-live"], live_id)
    _assert_live(saved["CHART-trashed"], trashed_id)
    assert saved["ROW-1"]["children"] == [
        "CHART-live",
        "CHART-trashed",
        "CHART-gone",
        "MARKDOWN-1",
    ]
    assert {live_id, trashed_id} <= _member_ids(session, dashboard)


@pytest.mark.parametrize("form", ["digit_string", "whole_float"])
def test_raw_layout_put_reads_an_id_written_in_another_form(
    client: Any, session: Any, form: str
) -> None:
    dashboard, charts = _seed(session, members=2)
    first_id, second_id = charts[0].id, charts[1].id
    written: Any = str(first_id) if form == "digit_string" else float(first_id)
    layout = _layout(
        _tile("CHART-first", written),
        _tile("CHART-second", second_id),
        _tile("CHART-gone", GONE_ID, 6, 30),
    )

    response = _put(client, dashboard, {"position_json": json.dumps(layout)})

    assert response.status_code == 200, response.get_data(as_text=True)
    saved = _stored_layout(session, dashboard)
    _assert_live(saved["CHART-first"], first_id)
    _assert_live(saved["CHART-second"], second_id)
    _assert_inert_slot(saved, "CHART-gone", 6, 30)
    assert {first_id, second_id} <= _member_ids(session, dashboard)


@pytest.mark.parametrize(
    "raw_layout",
    ["null", "5", "1.5", "true", "[]", '"text"'],
    ids=["null", "integer", "float", "true", "list", "text"],
)
def test_put_stores_a_layout_that_is_not_an_object_as_sent(
    client: Any, session: Any, raw_layout: str
) -> None:
    dashboard, charts = _seed(session, members=2, stored=_tabbed_layout())
    member_ids = {chart.id for chart in charts}

    response = _put(client, dashboard, {"position_json": raw_layout})

    assert response.status_code == 200, response.get_data(as_text=True)
    assert _stored_layout(session, dashboard) == json.loads(raw_layout)
    assert _member_ids(session, dashboard) == member_ids


# ---------------------------------------------------------------------------- #
# Save as, with the charts copied along and without them.
# ---------------------------------------------------------------------------- #
@pytest.mark.parametrize("with_charts", [True, False], ids=["with_charts", "same_charts"])
def test_copy_turns_dead_tile_into_an_empty_slot(
    client: Any, session: Any, with_charts: bool
) -> None:
    dashboard, charts = _seed(session, members=1)
    live_id = charts[0].id
    layout = _layout(_tile("CHART-live", live_id), _tile("CHART-gone", GONE_ID, 6, 30))
    dashboard.position_json = json.dumps(layout)
    session.commit()

    copied = _copy_result(session, _copy(client, dashboard, layout, with_charts))

    saved = _stored_layout(session, copied)
    _assert_inert_slot(saved, "CHART-gone", 6, 30)
    assert saved["ROW-1"]["children"] == ["CHART-live", "CHART-gone", "MARKDOWN-1"]
    assert _names_a_chart(saved["CHART-live"]), saved["CHART-live"]
    copy_ids = _member_ids(session, copied)
    assert _chart_ids_on(saved) == copy_ids
    assert (live_id in copy_ids) is (not with_charts)
    assert len(copy_ids) == 1


@pytest.mark.parametrize("form", ["digit_string", "whole_float"])
@pytest.mark.parametrize("with_charts", [True, False], ids=["with_charts", "same_charts"])
def test_copy_follows_an_id_written_in_another_form(
    client: Any, session: Any, form: str, with_charts: bool
) -> None:
    dashboard, charts = _seed(session, members=2)
    first_id, second_id = charts[0].id, charts[1].id
    written: Any = str(first_id) if form == "digit_string" else float(first_id)
    layout = _layout(_tile("CHART-first", written), _tile("CHART-second", second_id))

    copied = _copy_result(session, _copy(client, dashboard, layout, with_charts))

    saved = _stored_layout(session, copied)
    copy_ids = _member_ids(session, copied)
    assert _chart_ids_on(saved) == copy_ids
    assert len(copy_ids) == 2
    if with_charts:
        assert not copy_ids & {first_id, second_id}
    else:
        assert copy_ids == {first_id, second_id}


def test_copy_with_charts_refuses_a_live_chart_off_the_dashboard(
    client: Any, session: Any
) -> None:
    from superset.models.dashboard import Dashboard
    from superset.models.slice import Slice

    dashboard, charts = _seed(session, members=1, others=1)
    layout = _layout(_tile("CHART-member", charts[0].id), _tile("CHART-out", charts[1].id))
    dashboard.position_json = json.dumps(layout)
    session.commit()

    response = _copy(client, dashboard, layout, True)

    assert response.status_code in VALIDATION_STATUSES, response.get_data(as_text=True)
    session.rollback()
    assert session.query(Dashboard).count() == 1
    assert session.query(Slice).count() == 2


@pytest.mark.parametrize(
    "unreadable", [value for _, value in UNREADABLE], ids=[name for name, _ in UNREADABLE]
)
@pytest.mark.parametrize("with_charts", [True, False], ids=["with_charts", "same_charts"])
def test_copy_refuses_an_unreadable_chart_id(
    client: Any, session: Any, unreadable: Any, with_charts: bool
) -> None:
    from superset.models.dashboard import Dashboard

    # The member is chart 1, so reading true or "1abc" as 1 would clone it.
    dashboard, charts = _seed(session, members=1, others=1)
    assert charts[0].id == 1
    layout = _layout(_tile("CHART-ok", charts[0].id), _tile("CHART-bad", unreadable, 6, 30))

    response = _copy(client, dashboard, layout, with_charts)

    _assert_refused_naming(response, "CHART-bad", unreadable)
    session.rollback()
    assert session.query(Dashboard).count() == 1


@pytest.mark.parametrize("loaded_first", [False, True], ids=["fresh", "already_loaded"])
def test_copy_with_charts_goes_through_with_a_trashed_member(
    client: Any, session: Any, trash_is_on: None, loaded_first: bool
) -> None:
    dashboard, charts = _seed(session, members=1, trashed=1)
    live_id, trashed_id = charts[0].id, charts[1].id
    layout = _layout(_tile("CHART-live", live_id), _tile("CHART-trashed", trashed_id, 6, 30))
    dashboard.position_json = json.dumps(layout)
    session.commit()
    if loaded_first:
        _member_ids(session, dashboard)

    copied = _copy_result(session, _copy(client, dashboard, layout, True))

    saved = _stored_layout(session, copied)
    copy_ids = _member_ids(session, copied)
    assert _chart_ids_on(saved) == copy_ids
    assert trashed_id not in copy_ids
    assert live_id not in copy_ids
    assert _names_a_chart(saved["CHART-live"]), saved["CHART-live"]
    assert _member_ids(session, dashboard) == {live_id, trashed_id}
