## Task

one of our users hit a weird one. their starknet contract compiled fine until they declared a type inside the contract module whose name happens to match a common standard-library type (they had a struct named `Span`). now it refuses to compile, failing with a generic-argument count error, something like "Expected 0 generic arguments, found 1", even though their code uses no generics at all.

renaming that colliding type makes everything compile again, clean. and it doesn't take anything fancy to trigger: a bare contract with only storage and no callable entry points hits it too.

a user picking an ordinary name for one of their own types shouldn't be able to wedge the compile like this just because it matches a standard-library name. figure out what's going on and fix it, so a contract whose own type collides with a standard-library name compiles, and a contract that genuinely uses that standard-library type compiles just the same.
