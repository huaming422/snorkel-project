//! Behavioural verifier for `cairo-fix-prelude-type-shadowing`.
//!
//! Tests THROUGH the pre-existing, stable public entry point
//! `cairo_lang_starknet::compile::compile_path` — the same function the
//! `starknet-compile` binary and the crate's own `compile_test.rs` drive. Each
//! test writes a self-contained Cairo project (a `cairo_project.toml` + a
//! `lib.cairo`) to a scratch directory, compiles it, and asserts ONLY on the
//! returned `Result` (`Ok`/`Err`). It never inspects generated source text, and
//! it never names any of the plugin functions the fix touches
//! (`handle_struct`/`handle_enum` in derive/event.rs,
//! `generate_entry_point_wrapper` in entry_point.rs, `handle_trait` in
//! dispatcher.rs) — so any valid fix passes regardless of how it is built.
//!
//! Decoupling rationale:
//!
//!   * Only `compile_path` is imported from the crate under test. The fix is a
//!     set of emitted-code changes inside the `#[starknet::contract]` expansion
//!     plugin; the tests observe the compile outcome that expansion governs, not
//!     the expansion itself. The reference fix fully-qualifies the prelude
//!     references (`core::array::Array`, `core::option::Option`, ...); an
//!     alias-and-rename fix or a mixed fix produces structurally different
//!     generated text but the SAME compile outcome, so all pass here.
//!   * Pass/fail is decided by `Result::is_ok()`, the behavioural signal. A
//!     contract whose own type shadows a prelude name referenced by generated
//!     code fails to compile pre-fix (`error[E2163]: Expected 0 generic
//!     arguments, found 1`, because the bare `Array`/`Span`/`Option` the plugin
//!     emits resolves to the user's 0-generic type) and compiles post-fix.
//!   * The diagnostics reporter is `ignoring().allow_warnings()`: the compile
//!     fails ONLY on hard errors, never on warnings. Shadowing contracts carry
//!     unused-type warnings for the colliding user types; counting those as
//!     failures would couple the result to incidental lint output instead of the
//!     E2163 error the task is about.
//!   * Each contract compiles at Cairo edition `2024_07` — the same edition the
//!     crate's own `cairo_level_tests` contracts (driven through `compile_path`
//!     by `compile_test.rs`) use. This is a stable repo fact, not a solution
//!     choice.

use std::path::PathBuf;

use cairo_lang_compiler::CompilerConfig;
use cairo_lang_compiler::diagnostics::DiagnosticsReporter;
use cairo_lang_lowering::utils::InliningStrategy;
use cairo_lang_starknet::compile::compile_path;

/// `cairo_project.toml` pinning the crate root and the compiler edition.
/// Edition `2024_07` matches the crate's own `cairo_level_tests` contracts,
/// which `compile_test.rs` compiles through `compile_path` today.
const PROJECT_TOML: &str = "\
[crate_roots]
contract = \".\"

[config.global]
edition = \"2024_07\"
";

/// Compiles a single standalone contract crate and returns whether it compiled.
///
/// Writes `src` as the crate root (`lib.cairo`) of a fresh scratch directory
/// alongside a `cairo_project.toml`, then drives the public `compile_path`.
/// Returns `true` iff compilation succeeded (no hard error diagnostics).
fn contract_compiles(scratch_name: &str, src: &str) -> bool {
    // Unique per test (the function name) and per process, so parallel or
    // repeated runs never collide. `--test-threads=1` already serialises tests.
    let dir: PathBuf =
        std::env::temp_dir().join(format!("sbverify_shadow_{}_{}", std::process::id(), scratch_name));

    // Clean any stale copy, then materialise the project.
    let _ = std::fs::remove_dir_all(&dir);
    std::fs::create_dir_all(&dir).expect("create scratch project dir");
    std::fs::write(dir.join("cairo_project.toml"), PROJECT_TOML).expect("write cairo_project.toml");
    std::fs::write(dir.join("lib.cairo"), src).expect("write lib.cairo");

    let result = compile_path(
        dir.as_path(),
        None,
        CompilerConfig {
            // Only hard errors fail the compile; warnings (e.g. the unused
            // shadowing types) are irrelevant to the contract under test.
            diagnostics_reporter: DiagnosticsReporter::ignoring().allow_warnings(),
            replace_ids: true,
            add_statements_functions: false,
            add_statements_code_locations: false,
            add_functions_debug_info: false,
            add_type_names: false,
        },
        InliningStrategy::default(),
    );

    // Best-effort cleanup; the Result is already owned.
    let _ = std::fs::remove_dir_all(&dir);

    result.is_ok()
}

// ---------------------------------------------------------------------------
// fail_to_pass: contracts whose own types shadow prelude names. Each FAILS to
// compile pre-fix (E2163) and compiles post-fix.
// ---------------------------------------------------------------------------

/// Basic root-cause reproduction: a storage-only contract (no callable entry
/// points) whose own `struct Array` shadows the prelude `Array` referenced by
/// the always-generated empty `Event` impl. Pre-fix the generated
/// `append_keys_and_data`/`deserialize` refer to the bare `Array`, which now
/// resolves to the user's 0-generic type → `Expected 0 generic arguments,
/// found 1`. Post-fix the generated references are prelude-anchored and it
/// compiles.
#[test]
fn compiles_with_shadowed_array() {
    let src = "\
#[starknet::contract]
mod test_contract {
    #[storage]
    struct Storage {}

    struct Array {}
}
";
    assert!(
        contract_compiles("shadowed_array", src),
        "a storage-only contract whose own `struct Array` shadows the prelude `Array` should \
         compile (pre-fix this fails with E2163 from the generated Event impl's bare `Array`)"
    );
}

/// Same shadowing fault via `Span`, which the generated event code also
/// references in `deserialize`.
#[test]
fn compiles_with_shadowed_span() {
    let src = "\
#[starknet::contract]
mod test_contract {
    #[storage]
    struct Storage {}

    struct Span {}
}
";
    assert!(
        contract_compiles("shadowed_span", src),
        "a storage-only contract whose own `struct Span` shadows the prelude `Span` should \
         compile (pre-fix this fails with E2163 from the generated Event impl's bare `Span`)"
    );
}

/// Same shadowing fault via `Option`, which the generated event code references
/// as a return type and via `Option::Some`/`Option::None`. An Array-only fix
/// that leaves `Option` unqualified fails this case.
#[test]
fn compiles_with_shadowed_option() {
    let src = "\
#[starknet::contract]
mod test_contract {
    #[storage]
    struct Storage {}

    enum Option {}
}
";
    assert!(
        contract_compiles("shadowed_option", src),
        "a storage-only contract whose own `enum Option` shadows the prelude `Option` should \
         compile (pre-fix this fails from the generated Event impl's bare `Option`)"
    );
}

/// Breadth case: the shadowing collision must also be handled at the
/// entry-point wrapper emit sites — a DIFFERENT generated surface than the Event
/// impl, living in `entry_point.rs` rather than `derive/event.rs`.
///
/// The name is `Span` (not `Array`) deliberately: the generated wrapper for an
/// `#[external(v0)]` fn is `fn __wrapper__get_value(mut data: Span::<felt252>)
/// -> Span::<felt252> { ... }` — its only bare, user-shadowable prelude
/// reference is `Span`. (The wrapper's other prelude uses are the TRAIT
/// `ArrayTrait::new()` and already-qualified `core::array::*`; a user `struct
/// Array {}` shadows none of them, so an `Array`-named contract would exercise
/// only the Event impl here and add nothing over `compiles_with_shadowed_span`.)
/// By shadowing `Span` AND exposing an entry point, this case fails pre-fix on
/// the wrapper's bare `Span` in addition to the Event impl's `Span`, so a fix
/// that qualifies the event derive but leaves the entry-point wrapper untouched
/// still fails here — the behavioural gate on the `entry_point.rs` fix site.
#[test]
fn compiles_with_shadowed_span_and_entrypoint() {
    let src = "\
#[starknet::contract]
mod test_contract {
    #[storage]
    struct Storage {}

    struct Span {}

    #[external(v0)]
    fn get_value(self: @ContractState, value: felt252) -> felt252 {
        value
    }
}
";
    assert!(
        contract_compiles("shadowed_span_and_entrypoint", src),
        "a contract that shadows `Span` and also exposes an entry point should compile; the \
         generated entry-point wrapper's `data: Span::<felt252>` signature makes this fail pre-fix \
         (and fail any fix that qualifies the event derive but not the entry-point wrapper)"
    );
}

// ---------------------------------------------------------------------------
// pass_to_pass: ordinary contracts that do NOT shadow prelude names. These must
// compile both pre-fix and post-fix — the fix must not regress them.
// ---------------------------------------------------------------------------

/// Regression guard: a contract that genuinely uses the prelude `Array` (builds
/// and returns an `Array<felt252>`) must keep compiling. This proves the fix
/// qualifies the GENERATED references without breaking real user uses of the
/// prelude types.
#[test]
fn ordinary_prelude_contract_compiles() {
    let src = "\
#[starknet::contract]
mod ordinary_contract {
    #[storage]
    struct Storage {}

    #[external(v0)]
    fn make_values(self: @ContractState) -> Array<felt252> {
        let mut data = array![];
        data.append(1);
        data.append(2);
        data
    }
}
";
    assert!(
        contract_compiles("ordinary_prelude", src),
        "a contract that genuinely uses the prelude `Array` must compile at both the pre-fix and \
         post-fix states"
    );
}

/// Anti-over-correction guard: a contract whose OWN source genuinely misuses a
/// prelude type's arity (`Array` takes exactly one generic argument; this passes
/// two) must STILL fail to compile — both pre-fix and post-fix, under every valid
/// fix. The shadowing fix only qualifies the references the PLUGIN generates; it
/// never changes how user-written source is arity-checked, so a correct fix
/// leaves this `Err`.
///
/// This exists to catch the cheapest over-correction: a "fix" that silences the
/// symptom by globally disabling or suppressing the generic-arity diagnostic
/// (E2163) rather than qualifying the generated references. Such a hack makes all
/// the shadowing cases above compile — but it would ALSO make this genuinely
/// broken contract compile, flipping this assertion. Asserting it stays `Err`
/// behaviourally rejects that whole class of blunt suppression, independently of
/// the rubric's source-vs-workaround judgement.
#[test]
fn genuine_arity_error_still_fails() {
    let src = "\
#[starknet::contract]
mod test_contract {
    #[storage]
    struct Storage {}

    #[external(v0)]
    fn take(self: @ContractState, x: Array<felt252, u32>) -> felt252 {
        0
    }
}
";
    assert!(
        !contract_compiles("genuine_arity_error", src),
        "a contract whose own source passes the wrong number of generic arguments to a prelude \
         type must NOT compile; if it does, the arity diagnostic has been suppressed/disabled \
         rather than the generated references qualified"
    );
}

/// Breadth case: a contract that shadows `Span` AND has a `#[starknet::contract]`
/// that emits a non-empty `#[event]` enum with a data-carrying variant must compile.
///
/// Pre-fix failure path:
///   * `handle_enum` (derive/event.rs) generates the contract's `EventIsEvent`
///     impl.  For a non-empty event enum it emits per-variant deserialize code
///     — `return Option::Some(Event::Stored(starknet::Event::deserialize(...)?))` —
///     as well as `Option::None` in the fallthrough, plus the impl signature
///     `ref keys: Span<felt252>`.  With `struct Span {}` in scope every bare
///     `Span<felt252>` resolves to the user's 0-generic type → E2163.
/// Post-fix all bare `Span`/`Array`/`Option` references are prelude-anchored
/// and the contract compiles.
///
/// This test exercises the coverage gap the quality audit identified: all
/// existing f2p contracts use storage-only modules whose auto-generated
/// `Event` enum has zero variants, so the per-variant `Option::Some` path in
/// `handle_enum` is never compiled.  Introducing a named variant forces it.
#[test]
fn compiles_with_data_carrying_event() {
    let src = "\
#[starknet::contract]
mod test_contract {
    // Shadow the prelude `Span` — the generated EventIsEvent impl's
    // deserialize uses bare Span<felt252> in its signature, and the
    // per-variant deserialize path uses bare Option::Some / Option::None.
    struct Span {}

    #[storage]
    struct Storage {}

    // Event struct payload that also derives starknet::Event.
    // This exercises handle_struct: its generated FooDataIsEvent uses bare
    // Array<felt252> in append_keys_and_data and bare Span<felt252>/Option
    // in deserialize — all collide with struct Span {} pre-fix.
    #[derive(Drop, starknet::Event)]
    struct Stored {
        value: felt252,
    }

    // Non-empty event enum: its starknet::Event derive calls handle_enum,
    // which generates per-variant deserialize code using bare prelude refs:
    //   Option::Some(Event::Stored(...)) and Option::None
    // These collide with struct Span {} in scope pre-fix.
    #[event]
    #[derive(Drop, starknet::Event)]
    enum Event {
        Stored: Stored,
    }
}
";
    assert!(
        contract_compiles("data_carrying_event", src),
        "a contract with a shadowed `Span` and a data-carrying #[event] enum should compile; \
         pre-fix the generated event-struct IsEvent impl and the enum variant deserialize sites \
         emit bare `Span`/`Option` references that resolve to the user's 0-generic type"
    );
}

/// Breadth case: a contract that shadows `Span` AND implements a
/// `#[starknet::interface]` trait via `#[abi(embed_v0)]` must compile.
///
/// The `starknet::interface` derive generates a dispatcher/forward-wrapper
/// (`fn __wrapper__...(data: Span::<felt252>) -> Span::<felt252>`) in
/// `dispatcher.rs`.  Pre-fix this wrapper uses bare `Span::<felt252>`; with
/// `struct Span {}` in scope the reference resolves to the user's 0-generic
/// type → `Expected 0 generic arguments, found 1`.  Post-fix the wrapper uses
/// `core::array::Span::<felt252>` and the contract compiles.
///
/// A fix that qualifies the event-derive sites (derive/event.rs) and the
/// entry-point wrappers (entry_point.rs) but omits the dispatcher forward-
/// wrapper (dispatcher.rs) still fails here — the behavioural gate on the
/// dispatcher.rs fix site.
#[test]
fn compiles_with_shadowed_span_and_dispatcher() {
    let src = "\
#[starknet::interface]
trait ICounter<TContractState> {
    fn get_count(self: @TContractState) -> felt252;
    fn increment(ref self: TContractState);
}

#[starknet::contract]
mod test_contract {
    use starknet::storage::{StoragePointerReadAccess, StoragePointerWriteAccess};

    #[storage]
    struct Storage {
        count: felt252,
    }

    // Shadow the prelude Span — the dispatcher-generated forward wrapper uses
    // bare `Span::<felt252>` pre-fix.
    struct Span {}

    #[abi(embed_v0)]
    impl CounterImpl of super::ICounter<ContractState> {
        fn get_count(self: @ContractState) -> felt252 {
            self.count.read()
        }
        fn increment(ref self: ContractState) {
            self.count.write(self.count.read() + 1);
        }
    }
}
";
    assert!(
        contract_compiles("shadowed_span_and_dispatcher", src),
        "a contract that shadows `Span` and embeds a starknet::interface implementation should \
         compile; pre-fix the generated dispatcher forward-wrapper emits bare `Span::<felt252>` \
         which resolves to the user's 0-generic struct"
    );
}

/// Regression guard: a conventional storage + interface contract (a counter
/// with a setter and getter) must keep compiling. Mirrors the crate's own
/// `hello_starknet` example.
#[test]
fn hello_starknet_contract_compiles() {
    let src = "\
#[starknet::interface]
trait HelloStarknetTrait<TContractState> {
    fn increase_balance(ref self: TContractState, amount: usize);
    fn get_balance(self: @TContractState) -> usize;
}

#[starknet::contract]
mod hello_starknet {
    use starknet::storage::{StoragePointerReadAccess, StoragePointerWriteAccess};
    #[storage]
    struct Storage {
        balance: usize,
    }

    #[abi(embed_v0)]
    impl HelloStarknetImpl of super::HelloStarknetTrait<ContractState> {
        fn increase_balance(ref self: ContractState, amount: usize) {
            self.balance.write(self.balance.read() + amount);
        }
        fn get_balance(self: @ContractState) -> usize {
            self.balance.read()
        }
    }
}
";
    assert!(
        contract_compiles("hello_starknet", src),
        "a conventional counter contract (storage + interface impl) must compile at both the \
         pre-fix and post-fix states"
    );
}
