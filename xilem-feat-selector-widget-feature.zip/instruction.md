## Task

Masonry has tooltips and other overlays, but an app that wants a drop-down
still has to build its own. I'd like a selector widget in the library: a compact
control that shows the current option and lets the user switch to another from
a menu that opens over the rest of the window.

The control owns the choice. Nothing outside it should have to close the menu
or update the shown text after a pick or a dismissal. Existing widgets have
to keep building and behaving as they do today.

This runs headless with no GPU, so painting and pixel layout don't matter here.

## User stories / requirements

- Opening the selector shows a menu with one selectable row for each option, in the order the options were given. The menu is laid over the rest of the window rather than nested inside the control, and assistive technology sees the control as a combo box and every row as a selectable item.
- Choosing a row tells the application which option was picked, giving the option's text and its zero-based position among the options. One pick sends exactly one report, and merely opening the menu sends none.
- After a pick the control displays the chosen option and the menu goes away on its own. Opening the control again brings back the full list.
- A click anywhere outside the open menu, or the window losing focus, closes the menu without choosing. The control keeps showing the option it showed before, the application gets no report, and the control can be opened again afterwards.
