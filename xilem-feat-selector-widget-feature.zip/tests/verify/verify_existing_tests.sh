#!/usr/bin/env bash
#
# Regression check: the unit tests that already ship in masonry_core, masonry
# and masonry_testing still pass after the change.
#
# The feature touches the core mutate pass and the layer types those crates
# test (masonry/src/tests/mutate.rs checks the order mutate callbacks run in),
# so a change that keeps everything compiling but alters how the existing
# by-handle method behaves fails here. Render tests need a GPU and are skipped
# through the repo's own SKIP_RENDER_TESTS switch, which the image sets.
#
# This check passes on the unchanged repository by design: it guards existing
# behavior and names nothing new.
#
# Exit codes:
#   0          every existing unit test passed
#   non-zero   propagates the cargo failure

set -euo pipefail

export RUSTUP_HOME="${RUSTUP_HOME:-/usr/local/rustup}"
export CARGO_HOME="${CARGO_HOME:-/usr/local/cargo}"
export PATH="$CARGO_HOME/bin:$PATH"
export CARGO_NET_OFFLINE=true
export SKIP_RENDER_TESTS=1

cd /repo/xilem

cargo test -p masonry_core -p masonry -p masonry_testing --all-features --lib
