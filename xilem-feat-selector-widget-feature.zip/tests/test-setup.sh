#!/usr/bin/env bash
# No services to start, no data to seed: the image pre-warms the full cargo
# cache (deps fetched + workspace test binaries built at the base commit), so
# the checks need nothing beyond what the image already holds.
set -euo pipefail

# The test phase has network to the model gateway only. Make any stray
# cargo resolution fail fast against the warm cache rather than hang on a dead
# network. Scoped to this shell's cargo invocations.
export CARGO_NET_OFFLINE=true

echo "[test-setup] Rust version:    $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:   $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root:  /repo/xilem"
echo "[test-setup] Setup complete."
