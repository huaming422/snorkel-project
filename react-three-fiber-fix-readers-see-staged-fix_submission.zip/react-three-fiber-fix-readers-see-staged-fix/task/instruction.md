## Task

on the v10 line the WebGPUMotionBlur demo comes up as a blank canvas: the shaders fail to compile and it throws a wall of WebGPU shader/validation errors. every other WebGPU scene renders fine, it's just this one. dig in and figure out why this scene produces invalid output, and fix it so the demo renders with motion blur and no shader or validation errors.
