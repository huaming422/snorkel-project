#!/usr/bin/env bash
# Structural pass_to_pass gate: the pre-existing @react-three/tsl and
# @react-three/fiber suites must stay green. The reader-overlay change touches
# the shared registry read path and every reader hook, so a fix that regresses
# creator-mode registration, reactivity via useSyncExternalStore, or any
# existing hook behavior is caught here even when the focused behavioral
# verifier passes.
#
# Run without --coverage: the root vitest config carries a coverage ratchet
# that is irrelevant to correctness and would make this gate flake on unrelated
# line-count drift. We only care that every existing test still passes.
set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/react-three-fiber}"
cd "$REPO_DIR"

export NODE_OPTIONS="${NODE_OPTIONS:---max-old-space-size=4096}"

echo "[existing-suites] running packages/tsl + packages/fiber (no coverage)..."
pnpm exec vitest run packages/tsl packages/fiber --no-coverage
