// @ts-nocheck
//
// Behavioral verifier for the "readers see same-render staged entries" fix.
//
// Everything is driven through the four PUBLIC reader hooks exported from
// `@react-three/tsl` (`useUniforms`, `useNodes`, `useBuffers`,
// `useGPUStorage`) rendered under the repo's own `context.Provider` test
// store (`packages/tsl/tests/store.ts`). Nothing here imports the internal
// registry or any helper the fix may add: the behavior is observable at the
// hook boundary, which is where every correct implementation converges
// (shared helper, inline overlay, composed-from-existing-helpers — all pass).
//
// The shape under test: a parent in creator mode declares an entry during
// render; a child in reader mode reads it. React renders the parent before
// the child and runs the child's layout effects before the parent's, so the
// child's first render (and anything it bakes into a layout effect) happens
// before the parent's commit-phase flush. A reader that only returns the
// committed map hands the child `undefined`. The motion-blur demo baked that
// `undefined` into a render pipeline (`velocity * null` in WGSL) and drew a
// blank canvas.
//
// This file lives in packages/tsl/tests at grade time (verify.toml
// test_parent), so `../src` and `./store` resolve against the tsl package.

import { describe, expect, it, beforeEach, afterEach, vi } from 'vitest'
import * as React from 'react'
import { act } from 'react'
import { render } from '@testing-library/react'
import * as THREE from 'three/webgpu'
import { float, instancedArray } from 'three/tsl'

import type { RootStore } from '@react-three/fiber/webgpu'
import { useBuffers, useGPUStorage, useNodes, useUniforms } from '../src'
import { createStore, context } from './store'

const noop = () => {}
const makeStore = () => createStore(noop, noop)

let warnSpy: ReturnType<typeof vi.spyOn>
beforeEach(() => {
  warnSpy = vi.spyOn(console, 'warn').mockImplementation(noop)
})
afterEach(() => warnSpy.mockRestore())

async function mount(store: RootStore, children: React.ReactNode) {
  const tree = <context.Provider value={store}>{children}</context.Provider>
  let view: ReturnType<typeof render> = null!
  await act(async () => {
    view = render(tree)
  })
  return view
}

/** Records the value a reader saw on each render, in order. */
function recorder<T>() {
  const renders: T[] = []
  return { renders, first: () => renders[0], last: () => renders[renders.length - 1] }
}

//* ── readers_see_same_render_staged (fail_to_pass, basic_functionality) ──
// A child reader sees an ancestor's same-render staged entry, not `undefined`,
// on its FIRST render — for both the whole-store and the scoped reader form.
// Pre-fix: the child's first render returns the committed map (no parent entry
// yet) and captures `undefined`. Post-fix: it sees the parent's entry.

describe('reader hooks see a parent entry staged in the same render', () => {
  it('useUniforms() (whole-store) sees a uniform its parent staged this render', async () => {
    const store = makeStore()
    const created = recorder<unknown>()
    const read = recorder<unknown>()

    function Child() {
      read.renders.push(useUniforms<{ uSpeed: number }>().uSpeed)
      return null
    }
    function Parent() {
      created.renders.push(useUniforms({ uSpeed: 2 }).uSpeed)
      return <Child />
    }

    await mount(store, <Parent />)

    // The key assertion: first render must not be undefined, and it is the
    // very node the parent created.
    expect(read.first()).toBeDefined()
    expect(read.first()).toBe(created.first())
    // After commit the reader holds the committed node — the same object.
    expect(read.last()).toBe(store.getState().uniforms.uSpeed)
  })

  it("useUniforms('scope') sees a scoped uniform its parent staged this render", async () => {
    const store = makeStore()
    const created = recorder<unknown>()
    const read = recorder<unknown>()

    function Child() {
      read.renders.push(useUniforms<{ uHealth: number }>('player').uHealth)
      return null
    }
    function Parent() {
      created.renders.push(useUniforms({ uHealth: 100 }, 'player').uHealth)
      return <Child />
    }

    await mount(store, <Parent />)

    expect(read.first()).toBeDefined()
    expect(read.first()).toBe(created.first())
    expect(read.last()).toBe((store.getState().uniforms.player as Record<string, unknown>).uHealth)
  })

  it('a child bakes the real uniform (not undefined) into a layout-effect build', async () => {
    // The motion-blur failure shape: a descendant reads a uniform with
    // useUniforms() and closes over it in a pipeline built during its layout
    // effect, which runs BEFORE the ancestor's flush. Whatever the first
    // render returned is what gets baked in.
    const store = makeStore()
    const captured: unknown[] = []
    let registered: unknown = null

    function PipelineManager() {
      const { blurAmount } = useUniforms<{ blurAmount: number }>()
      React.useLayoutEffect(() => {
        captured.push(blurAmount) // built once, like a render-pipeline graph
      }, [])
      return null
    }
    function Experience() {
      registered = useUniforms({ blurAmount: 1 }).blurAmount
      return <PipelineManager />
    }

    await mount(store, <Experience />)

    expect(captured).toHaveLength(1)
    expect(captured[0]).toBeDefined()
    expect(captured[0]).toBe(registered)
    expect(captured[0]).toBe(store.getState().uniforms.blurAmount)
  })
})

//* ── all_four_hooks_fixed (fail_to_pass) ──
// One independent case per hook, each exercising the parent-stages /
// child-reads shape in both root and scoped forms. A partial fix that touches
// only a subset of hooks leaves at least one of these failing.

describe('the overlay fix is applied to every reader hook, not just useUniforms', () => {
  it('useNodes() and useNodes(scope) see nodes their parent staged this render', async () => {
    const store = makeStore()
    const created = recorder<{ wobble: unknown; offset: unknown }>()
    const root = recorder<unknown>()
    const scoped = recorder<unknown>()
    const nested = recorder<unknown>()

    function Child() {
      const all = useNodes()
      root.renders.push(all.wobble)
      nested.renders.push((all.player as Record<string, unknown> | undefined)?.offset)
      scoped.renders.push(useNodes('player').offset)
      return null
    }
    function Parent() {
      const { wobble } = useNodes(() => ({ wobble: float(1) }))
      const { offset } = useNodes(() => ({ offset: float(2) }), 'player')
      created.renders.push({ wobble, offset })
      return <Child />
    }

    await mount(store, <Parent />)

    expect(root.first()).toBeDefined()
    expect(root.first()).toBe(created.first().wobble)
    expect(scoped.first()).toBe(created.first().offset)
    // The whole-store form also exposes the staged scope, nested under its key.
    expect(nested.first()).toBe(created.first().offset)
    expect(root.last()).toBe(store.getState().nodes.wobble)
  })

  it('useBuffers() and useBuffers(scope) see buffers their parent staged this render', async () => {
    const store = makeStore()
    const positions = new Float32Array(4)
    const velocities = instancedArray(4, 'vec2')
    const root = recorder<unknown>()
    const scoped = recorder<unknown>()

    function Child() {
      root.renders.push(useBuffers().positions)
      scoped.renders.push(useBuffers('particles').velocities)
      return null
    }
    function Parent() {
      useBuffers(() => ({ positions }))
      useBuffers(() => ({ velocities }), 'particles')
      return <Child />
    }

    await mount(store, <Parent />)

    expect(root.first()).toBe(positions)
    expect(scoped.first()).toBe(velocities)
    expect(root.last()).toBe(store.getState().buffers.positions)
  })

  it('useGPUStorage() and useGPUStorage(scope) see storage their parent staged this render', async () => {
    const store = makeStore()
    const heightMap = new THREE.StorageTexture(8, 8)
    const normal = new THREE.StorageTexture(8, 8)
    const root = recorder<unknown>()
    const scoped = recorder<unknown>()

    function Child() {
      root.renders.push(useGPUStorage().heightMap)
      scoped.renders.push(useGPUStorage('terrain').normal)
      return null
    }
    function Parent() {
      useGPUStorage(() => ({ heightMap }))
      useGPUStorage(() => ({ normal }), 'terrain')
      return <Child />
    }

    await mount(store, <Parent />)

    expect(root.first()).toBe(heightMap)
    expect(scoped.first()).toBe(normal)
    expect(scoped.last()).toBe((store.getState().gpuStorage.terrain as Record<string, unknown>).normal)
  })
})

//* ── scoped_read_guard_preserved (fail_to_pass) ──
// A scoped read keeps the leaf-vs-scope guard: a leaf stored directly under a
// name that collides with a scope name is NOT returned as a scope map. And the
// whole-store read still overlays a staged scope over its committed entries
// without the root staging bucket leaking in.

describe('scoped reads preserve the leaf-vs-scope guard and merge staged over committed', () => {
  it('a leaf stored under a name is not exposed as a scope by the scoped reader form', async () => {
    const store = makeStore()
    // Register a ROOT-level uniform named "player" (a leaf), no scope "player".
    function Creator() {
      useUniforms({ player: 1 })
      return null
    }
    await mount(store, <Creator />)
    // Sanity: it committed as a root leaf carrying the uniform-node marker.
    const leaf = store.getState().uniforms.player as Record<string, unknown>
    expect(leaf).toBeDefined()
    expect(leaf.isUniformNode).toBe(true)

    const scoped = recorder<Record<string, unknown>>()
    function Reader() {
      // Reading "player" as a SCOPE must not surface the leaf as a scope map.
      scoped.renders.push(useUniforms('player') as Record<string, unknown>)
      return null
    }
    await act(async () => {
      render(
        <context.Provider value={store}>
          <Reader />
        </context.Provider>,
      )
    })

    // Guard held: the scoped read is an empty scope (only hook utility fns).
    // If the leaf-vs-scope guard were dropped, the leaf node would be treated
    // as a scope and its own members (`isUniformNode`, `value`, ...) would leak
    // in as scope keys. Assert the marker does NOT appear.
    const seen = scoped.first()
    expect(seen.player).toBeUndefined()
    expect(seen.isUniformNode).toBeUndefined()
    expect(seen.value).toBeUndefined()
  })

  it("the root pseudo-scope ('') is never peeked as a user scope on a scoped read", async () => {
    // A root-level creator stages its entry under the internal root bucket this
    // render. A sibling child that reads '' AS A SCOPE must not receive the
    // staged root entries: a fix that peeked staged for '' would leak the root
    // staging bucket into the scoped read.
    const store = makeStore()
    const scoped = recorder<Record<string, unknown>>()

    function Child() {
      scoped.renders.push(useUniforms('') as Record<string, unknown>)
      return null
    }
    function Parent() {
      useUniforms({ uRoot: 1 }) // stages under the root pseudo-scope this render
      return <Child />
    }

    await mount(store, <Parent />)

    // The root-staged entry must NOT surface through a '' scoped read.
    expect(scoped.first().uRoot).toBeUndefined()
  })

  it('useUniforms() merges a staged scope over its already-committed entries', async () => {
    const store = makeStore()
    function Existing() {
      useUniforms({ uOld: 1 }, 'fx')
      return null
    }
    const view = await mount(store, <Existing />)
    const committedOld = (store.getState().uniforms.fx as Record<string, unknown>).uOld

    const read = recorder<Record<string, unknown> | undefined>()
    function Child() {
      read.renders.push(useUniforms().fx as Record<string, unknown> | undefined)
      return null
    }
    function Parent() {
      useUniforms({ uNew: 2 }, 'fx')
      return <Child />
    }
    await act(async () => {
      view.rerender(
        <context.Provider value={store}>
          <Existing />
          <Parent />
        </context.Provider>,
      )
    })

    // The child sees BOTH the committed entry and the freshly staged one.
    expect(read.first()?.uOld).toBe(committedOld)
    expect(read.first()?.uNew).toBeDefined()
    expect(read.first()?.uNew).toBe((store.getState().uniforms.fx as Record<string, unknown>).uNew)
  })
})

//* ── reader_identity_stable (pass_to_pass, basic_functionality) ──
// With nothing staged for the reader's render (the steady state, and every
// render after a flush), the reader returns the committed scope object itself,
// not a fresh copy — so a consumer keyed on reference identity sees no
// spurious change at commit. Catches over-corrections that always spread into
// a new object.

describe('reader identity is stable when nothing is staged', () => {
  it('returns the committed scope object itself across a nothing-staged render', async () => {
    const store = makeStore()
    const read = recorder<unknown>()
    function Creator() {
      useUniforms({ uA: 1 }, 'fx')
      return null
    }
    function Reader() {
      read.renders.push(useUniforms().fx)
      return null
    }
    const view = await mount(store, <Creator />)

    await act(async () => {
      view.rerender(
        <context.Provider value={store}>
          <Creator />
          <Reader />
        </context.Provider>,
      )
    })

    // Nothing was staged for the reader's render: the committed object as-is.
    expect(read.first()).toBe(store.getState().uniforms.fx)
  })

  it('still updates reactively when another component registers in a later render', async () => {
    // Identity stability must not come at the cost of reactivity: a reader that
    // renders before any creator still picks up an entry once it commits.
    const store = makeStore()
    const read = recorder<unknown>()
    function Reader() {
      read.renders.push(useUniforms<{ uLate: number }>().uLate)
      return null
    }
    function Late() {
      useUniforms({ uLate: 7 })
      return null
    }

    const view = await mount(store, <Reader />)
    expect(read.last()).toBeUndefined()

    await act(async () => {
      view.rerender(
        <context.Provider value={store}>
          <Reader />
          <Late />
        </context.Provider>,
      )
    })

    expect(read.last()).toBeDefined()
    expect(read.last()).toBe(store.getState().uniforms.uLate)
  })
})
