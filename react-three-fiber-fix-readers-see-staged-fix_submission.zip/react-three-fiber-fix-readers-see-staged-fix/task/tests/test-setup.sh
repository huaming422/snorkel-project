#!/usr/bin/env bash
# Sourced (not exec'd) by the harbor runner so env vars and any background
# process state stays alive for the verifier.
#
# The image already baked the full dependency closure at the base commit
# (`pnpm install --frozen-lockfile`, including the postinstall that generates
# packages/*/dist stubs and packages/fiber/react-reconciler/). So in the common
# case there is nothing to do here beyond a sanity check. We keep an
# offline-first install with a logged online fallback in case node_modules is
# missing (e.g. a reset tree) — `pnpm install --offline` materialises from the
# warm store baked at /opt/cache/pnpm-store without touching the network.

# `pipefail` is critical: without it, `pnpm install ... | tail` masks a pnpm
# failure behind a successful `tail` and we'd never reach the network fallback.
set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/react-three-fiber}"
cd "$REPO_DIR"

install_deps() {
    echo "[test-setup] installing workspace dependencies (pnpm, offline-first)..."
    cd "$REPO_DIR"
    # offline-then-online fallback is ONE sync attempt (same command, if/else block)
    if pnpm install --offline --frozen-lockfile 2>&1 | tail -20; then
        echo "[test-setup] offline install succeeded"
    else
        echo "[test-setup] offline install failed; retrying online..."
        pnpm install --frozen-lockfile 2>&1 | tail -30
    fi
}

# node_modules and the generated react-reconciler patch are baked into the image.
# Only reinstall if the tree is missing them.
if [ ! -d "$REPO_DIR/node_modules" ] || [ ! -d "$REPO_DIR/packages/fiber/react-reconciler" ]; then
    install_deps
    # The postinstall (`pnpm stub && pnpm patch-react-reconciler`) regenerates
    # the local stubs and the react-reconciler ESM build; both are local builds
    # needing no network. Run it explicitly in case --ignore-scripts was implied.
    if [ ! -d "$REPO_DIR/packages/fiber/react-reconciler" ]; then
        pnpm run stub 2>&1 | tail -20
        pnpm run patch-react-reconciler 2>&1 | tail -20
    fi
fi

# pnpm install can touch pnpm-lock.yaml as an infrastructure side-effect; mark it
# assume-unchanged so repo-integrity checks don't flag a dirty tree.
git update-index --assume-unchanged pnpm-lock.yaml 2>/dev/null || true

# Sanity: vitest must be runnable from the repo root (the verifier runs it).
pnpm exec vitest --version >/dev/null 2>&1 \
    || echo "[test-setup] WARNING: pnpm exec vitest not runnable from $REPO_DIR"

echo "[test-setup] ready: $REPO_DIR (node=$(node -v 2>/dev/null), pnpm=$(pnpm -v 2>/dev/null))"
