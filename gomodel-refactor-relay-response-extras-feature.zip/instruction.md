## Task

Chat completions from OpenAI-compatible providers lose response members on the way back. Relay those members to the caller, keeping the values the gateway sets for itself authoritative. Also retire the non-streaming passthrough shortcut, so that every non-streaming chat completion takes the translated path whatever the provider type.

## User stories / requirements

- A provider's extension members reach the caller at the top level of the reply and on every choice, whichever OpenAI-compatible provider type served it. The name the gateway stamps beats an upstream echo, finish reasons and token totals survive, and a plain reply comes back with nothing added.
- Callers get the same complete reply, extension members included, whether they ask by plain model name, by a provider-qualified selector or by a configured alias.
- A reply holding a null usage, a null entry in choices, or both stays a success, and whatever real choices and extension members sit beside the nulls still arrive.
- A truncated or mistyped reply from a provider reaches the caller as an error naming that provider, never as a success, on every OpenAI-compatible provider type.
- A conversation prefix long enough to plan still goes upstream with its prompt cache key, a short one or an unsupported provider type goes without, and the reply carries the provider's extension members either way.
