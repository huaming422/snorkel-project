// Behavioral checks for the gateway's non-streaming chat completions endpoint,
// driven end to end through the real routed HTTP server against a stub upstream.
// Each test POSTs to /v1/chat/completions, lets the gateway route to a real
// provider adapter pointed at an httptest upstream, and inspects the JSON the
// client receives (and, for cache planning, the JSON the upstream receives).
// The assertions stay on the wire: no member, type or method inside the gateway
// is named, so this suite holds for any way of capturing those members.
//
// The provider types matter. groq is always translated. openai, openrouter and
// azure are the types older gateway releases served through a non-streaming
// passthrough for a bare model name, and there those releases handed a broken
// upstream reply to the client as a 200.
package server_test

import (
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"

	"github.com/enterpilot/gomodel/internal/core"
	"github.com/enterpilot/gomodel/internal/llmclient"
	"github.com/enterpilot/gomodel/internal/providers"
	"github.com/enterpilot/gomodel/internal/providers/azure"
	"github.com/enterpilot/gomodel/internal/providers/groq"
	"github.com/enterpilot/gomodel/internal/providers/openai"
	"github.com/enterpilot/gomodel/internal/providers/openrouter"
	"github.com/enterpilot/gomodel/internal/server"
)

const probeModel = "llama-3.1-8b-instant"

// allProviderTypes pairs the always-translated type with the three older gateway
// releases passed through, so every behavior is seen on all four.
var allProviderTypes = []string{"groq", "openai", "openrouter", "azure"}

// baseURLSetter is the adapter method each provider type already exports.
type baseURLSetter interface {
	core.Provider
	SetBaseURL(string)
}

func newProviderOfType(t *testing.T, providerType string, client *http.Client) baseURLSetter {
	t.Helper()
	switch providerType {
	case "groq":
		return groq.NewWithHTTPClient("test-key", client, llmclient.Hooks{})
	case "openai":
		return openai.NewWithHTTPClient("test-key", client, llmclient.Hooks{})
	case "openrouter":
		return openrouter.NewWithHTTPClient("test-key", client, llmclient.Hooks{})
	case "azure":
		return azure.NewWithHTTPClient("test-key", client, llmclient.Hooks{})
	}
	t.Fatalf("unknown provider type %q", providerType)
	return nil
}

// aliasResolver maps one alias onto probeModel through the existing config seam.
type aliasResolver struct{ alias string }

func (r aliasResolver) ResolveModel(requested core.RequestedModelSelector) (core.ModelSelector, bool, error) {
	if requested.Model == r.alias {
		return core.ModelSelector{Model: probeModel}, true, nil
	}
	return core.ModelSelector{}, false, nil
}

// stubUpstream records the chat request bodies it receives.
type stubUpstream struct {
	mu     sync.Mutex
	bodies [][]byte
}

func (s *stubUpstream) chatRequests() [][]byte {
	s.mu.Lock()
	defer s.mu.Unlock()
	return append([][]byte(nil), s.bodies...)
}

// newRelayServer wires a server the way production does: a real model registry
// and router in front of a real adapter whose transport points at a stub. The
// stub answers the model-listing probe and returns chatBody for a chat call.
func newRelayServer(t *testing.T, providerType, chatBody string, cfg *server.Config) (*server.Server, *stubUpstream) {
	t.Helper()

	stub := &stubUpstream{}
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		if strings.HasSuffix(r.URL.Path, "/models") {
			_, _ = io.WriteString(w, `{"object":"list","data":[{"id":"`+probeModel+`","object":"model","owned_by":"stub"}]}`)
			return
		}
		body, _ := io.ReadAll(r.Body)
		stub.mu.Lock()
		stub.bodies = append(stub.bodies, body)
		stub.mu.Unlock()
		_, _ = io.WriteString(w, chatBody)
	}))
	t.Cleanup(upstream.Close)

	provider := newProviderOfType(t, providerType, upstream.Client())
	provider.SetBaseURL(upstream.URL)

	registry := providers.NewModelRegistry()
	registry.RegisterProviderWithNameAndType(provider, providerType, providerType)
	if err := registry.Initialize(context.Background()); err != nil {
		t.Fatalf("registry initialize: %v", err)
	}
	router, err := providers.NewRouter(registry)
	if err != nil {
		t.Fatalf("new router: %v", err)
	}
	if cfg == nil {
		cfg = &server.Config{LogOnlyModelInteractions: true}
	}
	return server.New(router, cfg), stub
}

func chatRequestBody(model string) string {
	return `{"model":"` + model + `","messages":[{"role":"user","content":"Hi"}]}`
}

func postChat(t *testing.T, srv *server.Server, body string) *httptest.ResponseRecorder {
	t.Helper()
	req := httptest.NewRequest(http.MethodPost, "/v1/chat/completions", bytes.NewReader([]byte(body)))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	srv.ServeHTTP(rec, req)
	return rec
}

func decodeObject(t *testing.T, raw []byte) map[string]json.RawMessage {
	t.Helper()
	var obj map[string]json.RawMessage
	if err := json.Unmarshal(raw, &obj); err != nil {
		t.Fatalf("not a JSON object: %v\nbody=%s", err, string(raw))
	}
	return obj
}

func decodeChoices(t *testing.T, top map[string]json.RawMessage) []map[string]json.RawMessage {
	t.Helper()
	var choices []map[string]json.RawMessage
	if err := json.Unmarshal(top["choices"], &choices); err != nil {
		t.Fatalf("choices not an array of objects: %v", err)
	}
	return choices
}

// assertMember compares one member's JSON value, ignoring formatting.
func assertMember(t *testing.T, obj map[string]json.RawMessage, key, wantJSON string) {
	t.Helper()
	raw, ok := obj[key]
	if !ok {
		t.Fatalf("member %q missing from %v", key, keysOf(obj))
	}
	var got, want any
	if err := json.Unmarshal(raw, &got); err != nil {
		t.Fatalf("member %q is not JSON: %v", key, err)
	}
	if err := json.Unmarshal([]byte(wantJSON), &want); err != nil {
		t.Fatalf("bad expected value %s: %v", wantJSON, err)
	}
	gotText, _ := json.Marshal(got)
	wantText, _ := json.Marshal(want)
	if !bytes.Equal(gotText, wantText) {
		t.Fatalf("member %q = %s, want %s", key, gotText, wantText)
	}
}

func keysOf(obj map[string]json.RawMessage) []string {
	keys := make([]string, 0, len(obj))
	for k := range obj {
		keys = append(keys, k)
	}
	return keys
}

// assertNoDuplicateTopLevelKeys fails a body that repeats a member, which a map
// decode would hide: an upstream echo re-emitted beside the gateway's own value.
func assertNoDuplicateTopLevelKeys(t *testing.T, raw []byte) {
	t.Helper()
	dec := json.NewDecoder(bytes.NewReader(raw))
	if _, err := dec.Token(); err != nil {
		t.Fatalf("body is not JSON: %v", err)
	}
	seen := map[string]bool{}
	for dec.More() {
		tok, err := dec.Token()
		if err != nil {
			t.Fatalf("body is not JSON: %v", err)
		}
		key, _ := tok.(string)
		if seen[key] {
			t.Fatalf("top-level member %q appears twice\nbody=%s", key, string(raw))
		}
		seen[key] = true
		var skip json.RawMessage
		if err := dec.Decode(&skip); err != nil {
			t.Fatalf("body is not JSON: %v", err)
		}
	}
}

// Members the gateway does not model reach the client at the top level and on
// EVERY choice, the stamped provider beats the upstream echo, and modeled fields
// survive, on every type in allProviderTypes.
func TestChatCompletionRelaysProviderResponseExtras(t *testing.T) {
	upstreamBody := `{` +
		`"id":"chatcmpl-extras","object":"chat.completion","model":"` + probeModel + `",` +
		`"provider":"upstream-echoed-value",` +
		`"citations":["https://example.com/a","https://example.com/b"],` +
		`"service_tier":"on_demand",` +
		`"choices":[` +
		`{"index":0,"finish_reason":"stop","native_finish_reason":"end_turn","message":{"role":"assistant","content":"Hello!"}},` +
		`{"index":1,"finish_reason":"length","native_finish_reason":"max_output","message":{"role":"assistant","content":"Again"}}` +
		`],` +
		`"usage":{"prompt_tokens":5,"completion_tokens":2,"total_tokens":7}}`

	for _, providerType := range allProviderTypes {
		t.Run(providerType, func(t *testing.T) {
			srv, _ := newRelayServer(t, providerType, upstreamBody, nil)
			rec := postChat(t, srv, chatRequestBody(probeModel))
			if rec.Code != http.StatusOK {
				t.Fatalf("status = %d, want 200\nbody=%s", rec.Code, rec.Body.String())
			}
			assertNoDuplicateTopLevelKeys(t, rec.Body.Bytes())

			top := decodeObject(t, rec.Body.Bytes())
			assertMember(t, top, "citations", `["https://example.com/a","https://example.com/b"]`)
			assertMember(t, top, "service_tier", `"on_demand"`)
			assertMember(t, top, "provider", `"`+providerType+`"`)

			choices := decodeChoices(t, top)
			if len(choices) != 2 {
				t.Fatalf("len(choices) = %d, want 2", len(choices))
			}
			assertMember(t, choices[0], "native_finish_reason", `"end_turn"`)
			assertMember(t, choices[0], "finish_reason", `"stop"`)
			assertMember(t, choices[1], "native_finish_reason", `"max_output"`)
			assertMember(t, choices[1], "finish_reason", `"length"`)

			var usage struct {
				PromptTokens     int `json:"prompt_tokens"`
				CompletionTokens int `json:"completion_tokens"`
				TotalTokens      int `json:"total_tokens"`
			}
			if err := json.Unmarshal(top["usage"], &usage); err != nil {
				t.Fatalf("usage not an object: %v", err)
			}
			if usage.PromptTokens != 5 || usage.CompletionTokens != 2 || usage.TotalTokens != 7 {
				t.Fatalf("usage = %+v, want 5/2/7", usage)
			}
		})
	}
}

// Every selector shape reaches the same complete reply with the extra relayed.
// An alias and a provider/model selector always take the translated path on
// openai, so those two pairs show that path relays the extra.
func TestChatCompletionRelaysAcrossRequestShapes(t *testing.T) {
	upstreamBody := `{"id":"chatcmpl-ok","object":"chat.completion","model":"` + probeModel + `",` +
		`"service_tier":"on_demand",` +
		`"choices":[{"index":0,"finish_reason":"stop","message":{"role":"assistant","content":"Hello!"}}],` +
		`"usage":{"prompt_tokens":5,"completion_tokens":2,"total_tokens":7}}`

	for _, providerType := range []string{"groq", "openai"} {
		shapes := []struct {
			name, model string
			cfg         *server.Config
		}{
			{"bare", probeModel, nil},
			{"qualified", providerType + "/" + probeModel, nil},
			{"alias", "fast-chat", &server.Config{ModelResolver: aliasResolver{alias: "fast-chat"}, LogOnlyModelInteractions: true}},
		}
		for _, shape := range shapes {
			t.Run(providerType+"_"+shape.name, func(t *testing.T) {
				srv, _ := newRelayServer(t, providerType, upstreamBody, shape.cfg)
				rec := postChat(t, srv, chatRequestBody(shape.model))
				if rec.Code != http.StatusOK {
					t.Fatalf("status = %d, want 200\nbody=%s", rec.Code, rec.Body.String())
				}
				top := decodeObject(t, rec.Body.Bytes())
				assertMember(t, top, "id", `"chatcmpl-ok"`)
				assertMember(t, top, "service_tier", `"on_demand"`)
				choices := decodeChoices(t, top)
				if len(choices) != 1 {
					t.Fatalf("len(choices) = %d, want 1", len(choices))
				}
				var msg struct {
					Content string `json:"content"`
				}
				if err := json.Unmarshal(choices[0]["message"], &msg); err != nil || msg.Content != "Hello!" {
					t.Fatalf("message = %s, want content Hello! (err %v)", choices[0]["message"], err)
				}
			})
		}
	}
}

var knownTopKeys = map[string]bool{
	"id": true, "object": true, "model": true, "provider": true,
	"system_fingerprint": true, "choices": true, "usage": true, "created": true,
}

var knownChoiceKeys = map[string]bool{
	"message": true, "finish_reason": true, "index": true,
	"logprobs": true, "stop_sequence": true,
}

// Regression control: a reply with no extras gains no stray keys. Older gateway
// releases already behave this way.
func TestChatCompletionCleanResponseHasNoUnmodeledKeys(t *testing.T) {
	upstreamBody := `{"id":"chatcmpl-clean","object":"chat.completion","model":"` + probeModel + `",` +
		`"choices":[{"index":0,"finish_reason":"stop","message":{"role":"assistant","content":"Hi there"}}],` +
		`"usage":{"prompt_tokens":3,"completion_tokens":2,"total_tokens":5}}`

	for _, providerType := range allProviderTypes {
		t.Run(providerType, func(t *testing.T) {
			srv, _ := newRelayServer(t, providerType, upstreamBody, nil)
			rec := postChat(t, srv, chatRequestBody(probeModel))
			if rec.Code != http.StatusOK {
				t.Fatalf("status = %d, want 200\nbody=%s", rec.Code, rec.Body.String())
			}
			top := decodeObject(t, rec.Body.Bytes())
			for k := range top {
				if !knownTopKeys[k] {
					t.Fatalf("unexpected top-level member %q\nbody=%s", k, rec.Body.String())
				}
			}
			assertMember(t, top, "id", `"chatcmpl-clean"`)
			choices := decodeChoices(t, top)
			if len(choices) != 1 {
				t.Fatalf("len(choices) = %d, want 1", len(choices))
			}
			for k := range choices[0] {
				if !knownChoiceKeys[k] {
					t.Fatalf("unexpected per-choice member %q\nbody=%s", k, rec.Body.String())
				}
			}
		})
	}
}

// A null usage block beside a real choice stays a success and the extras next to
// it are still relayed.
func TestChatCompletionToleratesNullUsage(t *testing.T) {
	upstreamBody := `{"id":"chatcmpl-null-usage","object":"chat.completion","model":"` + probeModel + `",` +
		`"citations":["https://example.com/a"],` +
		`"choices":[{"index":0,"finish_reason":"stop","message":{"role":"assistant","content":"Hi"}}],` +
		`"usage":null}`

	for _, providerType := range []string{"groq", "openai"} {
		t.Run(providerType, func(t *testing.T) {
			srv, _ := newRelayServer(t, providerType, upstreamBody, nil)
			rec := postChat(t, srv, chatRequestBody(probeModel))
			if rec.Code != http.StatusOK {
				t.Fatalf("status = %d, want 200\nbody=%s", rec.Code, rec.Body.String())
			}
			top := decodeObject(t, rec.Body.Bytes())
			assertMember(t, top, "id", `"chatcmpl-null-usage"`)
			assertMember(t, top, "citations", `["https://example.com/a"]`)
		})
	}
}

// Regression control: a null entry in choices decodes in older gateway releases,
// so it keeps returning 200 with the modeled members beside it intact. How the
// entry comes back (an empty choice, or dropped) is open, and this suite does not
// assert it.
func TestChatCompletionToleratesNullChoiceEntry(t *testing.T) {
	upstreamBody := `{"id":"chatcmpl-null-choice","object":"chat.completion","model":"` + probeModel + `",` +
		`"choices":[null],"usage":{"prompt_tokens":1,"completion_tokens":1,"total_tokens":2}}`

	for _, providerType := range []string{"groq", "openai"} {
		t.Run(providerType, func(t *testing.T) {
			srv, _ := newRelayServer(t, providerType, upstreamBody, nil)
			rec := postChat(t, srv, chatRequestBody(probeModel))
			if rec.Code != http.StatusOK {
				t.Fatalf("status = %d, want 200\nbody=%s", rec.Code, rec.Body.String())
			}
			top := decodeObject(t, rec.Body.Bytes())
			assertMember(t, top, "id", `"chatcmpl-null-choice"`)
			var usage struct {
				TotalTokens int `json:"total_tokens"`
			}
			if err := json.Unmarshal(top["usage"], &usage); err != nil || usage.TotalTokens != 2 {
				t.Fatalf("usage = %s, want total_tokens 2 (err %v)", top["usage"], err)
			}
		})
	}
}

// Regression control: both nulls at once. Older gateway releases already return 200.
func TestChatCompletionToleratesNullUsageAndNullChoice(t *testing.T) {
	upstreamBody := `{"id":"chatcmpl-null","object":"chat.completion","model":"` + probeModel + `","choices":[null],"usage":null}`

	for _, providerType := range []string{"groq", "openai"} {
		t.Run(providerType, func(t *testing.T) {
			srv, _ := newRelayServer(t, providerType, upstreamBody, nil)
			rec := postChat(t, srv, chatRequestBody(probeModel))
			if rec.Code != http.StatusOK {
				t.Fatalf("status = %d, want 200\nbody=%s", rec.Code, rec.Body.String())
			}
			assertMember(t, decodeObject(t, rec.Body.Bytes()), "id", `"chatcmpl-null"`)
		})
	}
}

// A null entry must not cost the real choice beside it its content or extras,
// or the reply its top-level extras. The real choice is found by content, so
// keeping or dropping the null entry both pass.
func TestChatCompletionKeepsExtrasBesideNullChoice(t *testing.T) {
	upstreamBody := `{"id":"chatcmpl-mixed","object":"chat.completion","model":"` + probeModel + `",` +
		`"service_tier":"on_demand",` +
		`"choices":[null,{"index":1,"finish_reason":"stop","native_finish_reason":"end_turn","message":{"role":"assistant","content":"Real"}}],` +
		`"usage":{"prompt_tokens":1,"completion_tokens":1,"total_tokens":2}}`

	for _, providerType := range []string{"groq", "openai"} {
		t.Run(providerType, func(t *testing.T) {
			srv, _ := newRelayServer(t, providerType, upstreamBody, nil)
			rec := postChat(t, srv, chatRequestBody(probeModel))
			if rec.Code != http.StatusOK {
				t.Fatalf("status = %d, want 200\nbody=%s", rec.Code, rec.Body.String())
			}
			top := decodeObject(t, rec.Body.Bytes())
			assertMember(t, top, "service_tier", `"on_demand"`)

			for _, choice := range decodeChoices(t, top) {
				var msg struct {
					Content string `json:"content"`
				}
				if raw, ok := choice["message"]; ok && json.Unmarshal(raw, &msg) == nil && msg.Content == "Real" {
					assertMember(t, choice, "native_finish_reason", `"end_turn"`)
					return
				}
			}
			t.Fatalf("real choice missing\nbody=%s", rec.Body.String())
		})
	}
}

// A broken upstream reply is an error, never a success, on every type. On the
// three passed through for a bare model name, older gateway releases relayed
// these bytes with a 200.
func TestChatCompletionRejectsMalformedUpstreamBody(t *testing.T) {
	bodies := map[string]string{
		"truncated": `{"id":"chatcmpl-bad","object":"chat.completion","choices":`,
		"mistyped":  `{"id":7,"object":"chat.completion","choices":[]}`,
	}
	for _, providerType := range allProviderTypes {
		for name, body := range bodies {
			t.Run(providerType+"_"+name, func(t *testing.T) {
				srv, _ := newRelayServer(t, providerType, body, nil)
				rec := postChat(t, srv, chatRequestBody(probeModel))
				if rec.Code < http.StatusBadRequest {
					t.Fatalf("status = %d, want an error status for a broken upstream reply\nbody=%s", rec.Code, rec.Body.String())
				}
			})
		}
	}
}

// Prompt cache planning works: a conversation prefix long enough to plan goes
// upstream with its key, a short one does not, a type with no plan stays clean,
// and the reply to a planned request still carries the extra.
func TestChatCompletionKeepsPromptCachePlanning(t *testing.T) {
	upstreamBody := `{"id":"chatcmpl-plan","object":"chat.completion","model":"` + probeModel + `",` +
		`"service_tier":"on_demand",` +
		`"choices":[{"index":0,"finish_reason":"stop","message":{"role":"assistant","content":"Hi"}}],` +
		`"usage":{"prompt_tokens":1,"completion_tokens":1,"total_tokens":2}}`
	longPrefix := strings.Repeat("the quick brown fox jumps over the lazy dog ", 800)

	cases := []struct {
		name, providerType, prefix string
		wantKey                    bool
	}{
		{"openai_long_prefix", "openai", longPrefix, true},
		{"openai_short_prefix", "openai", "Be brief.", false},
		{"groq_long_prefix", "groq", longPrefix, false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			srv, stub := newRelayServer(t, tc.providerType, upstreamBody, nil)
			request, err := json.Marshal(map[string]any{
				"model": probeModel,
				"messages": []map[string]string{
					{"role": "system", "content": tc.prefix},
					{"role": "user", "content": "Hi"},
				},
			})
			if err != nil {
				t.Fatalf("marshal request: %v", err)
			}
			rec := postChat(t, srv, string(request))
			if rec.Code != http.StatusOK {
				t.Fatalf("status = %d, want 200\nbody=%s", rec.Code, rec.Body.String())
			}
			assertMember(t, decodeObject(t, rec.Body.Bytes()), "service_tier", `"on_demand"`)

			sent := stub.chatRequests()
			if len(sent) != 1 {
				t.Fatalf("upstream chat calls = %d, want 1", len(sent))
			}
			_, hasKey := decodeObject(t, sent[0])["prompt_cache_key"]
			if hasKey != tc.wantKey {
				t.Fatalf("prompt_cache_key sent upstream = %v, want %v", hasKey, tc.wantKey)
			}
		})
	}
}
