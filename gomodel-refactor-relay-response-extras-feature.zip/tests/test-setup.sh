#!/usr/bin/env bash
#
# Sourced (not exec'd) by the test runner before `go test` runs, so
# the env we set persists for the runner. Re-asserts the Go test runtime
# defensively in case the repo's environment changed. Runs with the network
# allowed; the development environment is offline and the
# image already carries the full dependency closure, so the online steps
# here are recovery fallbacks, not the normal path.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/GoModel}"
cd "$REPO_DIR"

# internal/server and internal/core are pure Go; CGO is not required.
# Keep the module/toolchain env explicit in case the runner scrubbed it.
export GOTOOLCHAIN=local
export GOFLAGS=-mod=mod

# Make `go` reachable even if the runner scrubbed PATH.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

# Prefer the warm module cache baked into the image (offline); fall
# back to a logged network fetch only if the layer was wiped.
if ! GOPROXY=off go mod download 2>/tmp/go-mod-offline.log; then
    echo "test-setup.sh: offline module cache miss, retrying online" >&2
    go mod download 2>&1 | tail -20 >&2 || true
fi

# pytest is required by the test runner (run_verify.py drives the
# Python runner even when the checks themselves are Go). The image's
# /opt/tooling venv already carries it (pytest==9.1.1); this is a defensive
# recovery only, pinned to the tooling-stack version. Redirects are kept on
# the surrounding block so the install lines name only the pinned package.
if ! "${VERIFIER_PYTHON:-python3}" -c 'import pytest' >/dev/null 2>&1; then
    {
        pip install --quiet --break-system-packages 'pytest==9.1.1' \
            || pip install --quiet 'pytest==9.1.1' \
            || true
    } >/dev/null 2>&1
fi

echo "test-setup.sh: ready (GOTOOLCHAIN=$GOTOOLCHAIN, GOFLAGS=$GOFLAGS)"
