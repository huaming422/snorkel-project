#!/usr/bin/env bash
# Validation setup. Two jobs:
#   1. Rebuild the `mcap` CLI binary from the working tree (incremental: the
#      image baked a build, so only changed code recompiles and relinks).
#   2. Stage the fixtures the stories drive under /tmp/mcap_fixtures/.
# Idempotent: re-running re-stages the fixtures; the cargo cache survives.
set -euo pipefail

# Re-export the toolchain paths the image set (each phase starts a fresh shell,
# so Dockerfile ENV from RUN lines is not inherited).
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export RUSTUP_TOOLCHAIN="${RUSTUP_TOOLCHAIN:-1.99.0}"
export PATH="$CARGO_HOME/bin:$PATH"

REPO=/repo/mcap
RUST_DIR="$REPO/rust"
DATA_DIR="$RUST_DIR/mcap/tests/data"
FIXTURES=/tmp/mcap_fixtures

echo "validation-setup: rustc=$(rustc --version 2>&1 | head -1)"
echo "validation-setup: cargo=$(cargo --version 2>&1 | head -1)"

# Step 1: Rebuild the mcap binary from the working tree (incremental).
echo "validation-setup: building mcap-cli (incremental)..."
( cd "$RUST_DIR" && cargo build -p mcap-cli > /tmp/mcap-cli-validate-build.log 2>&1 ) || {
    echo "ERROR: cargo build -p mcap-cli failed" >&2
    tail -120 /tmp/mcap-cli-validate-build.log >&2
    exit 1
}

# Locate the produced binary (target dir is redirected by the image, with an
# in-tree fallback).
MCAP_BIN="$CARGO_TARGET_DIR/debug/mcap"
if [ ! -x "$MCAP_BIN" ]; then
    MCAP_BIN="$RUST_DIR/target/debug/mcap"
fi
if [ ! -x "$MCAP_BIN" ]; then
    echo "ERROR: built mcap binary not found (looked in $CARGO_TARGET_DIR/debug and $RUST_DIR/target/debug)" >&2
    exit 1
fi
"$MCAP_BIN" --help >/dev/null 2>&1 || {
    echo "ERROR: built mcap binary is not runnable at $MCAP_BIN" >&2
    exit 1
}
echo "validation-setup: mcap built at $MCAP_BIN"

# Step 2: Stage fixtures.
rm -rf "$FIXTURES"
mkdir -p "$FIXTURES"

# Real, chunked MCAP with a normal summary/index (drives the free-tier summary
# read, the chunked-cat gate, and both merge inputs).
test -f "$DATA_DIR/uncompressed.mcap" || {
    echo "ERROR: expected repo fixture $DATA_DIR/uncompressed.mcap (git-lfs not pulled?)" >&2
    exit 1
}
cp "$DATA_DIR/uncompressed.mcap" "$FIXTURES/local.mcap"
cp "$DATA_DIR/uncompressed.mcap" "$FIXTURES/local2.mcap"

# A real MCAP whose footer has no summary section (summary_start == 0). This repo
# fixture ships summaryless, so it drives the summaryless gate directly.
test -f "$DATA_DIR/zstd_chunk_with_padding.mcap" || {
    echo "ERROR: expected repo fixture $DATA_DIR/zstd_chunk_with_padding.mcap" >&2
    exit 1
}
cp "$DATA_DIR/zstd_chunk_with_padding.mcap" "$FIXTURES/summaryless.mcap"

# Pick an interpreter for the two byte-crafted fixtures. The isolated tooling
# venv is always present in the image; fall back to the system python3.
PYBIN=/opt/tooling/venv/bin/python
if [ ! -x "$PYBIN" ]; then PYBIN="$(command -v python3)"; fi
test -n "$PYBIN" || { echo "ERROR: no python interpreter available to craft fixtures" >&2; exit 1; }

# Craft five valid MCAP files the repo doesn't ship. Each opens with the base
# CLI's info, the unchunked and no-summary ones also pass cat and doctor, and
# the metadata records read back with the base CLI, so a malformed file can't
# decide a story.
"$PYBIN" - "$FIXTURES" <<'PY'
import os, struct, sys

out_dir = sys.argv[1]
MAGIC = bytes([0x89, 0x4D, 0x43, 0x41, 0x50, 0x30, 0x0D, 0x0A])


def rec(op, body):
    return bytes([op]) + struct.pack("<Q", len(body)) + body


def s(text):
    b = text.encode()
    return struct.pack("<I", len(b)) + b


def footer(summary_start):
    return rec(0x02, struct.pack("<QQI", summary_start, 0, 0)) + MAGIC


header = MAGIC + rec(0x01, s("") + s("fixture"))
data_end = rec(0x0F, struct.pack("<I", 0))

# (a) Unchunked messages: messages in the data section and no chunks, so the
#     summary has no chunk index. unchunked.mcap has three messages and a
#     Statistics record.
schema = rec(0x03, struct.pack("<H", 1) + s("Example") + s("jsonschema") + struct.pack("<I", 2) + b"{}")
channel = rec(0x04, struct.pack("<HH", 1, 1) + s("/example") + s("json") + struct.pack("<I", 0))
messages = b"".join(
    rec(0x05, struct.pack("<HIQQ", 1, i, 1000 + i, 1000 + i) + b'{"n":%d}' % i) for i in range(3)
)
data = header + schema + channel + messages + data_end
stats = rec(
    0x0B,
    struct.pack("<QHIIII", 3, 1, 1, 0, 0, 0)
    + struct.pack("<QQ", 1000, 1002)
    + struct.pack("<I", 10)
    + struct.pack("<HQ", 1, 3),
)
# unchunked_nostats.mcap: 30000 unchunked messages (about 1 MB of message data)
# with a summary that has no Statistics record (Statistics is optional), so a
# refusal that reads message data shows up in the bytes served.
many = b"".join(
    rec(0x05, struct.pack("<HIQQ", 1, i, 1000 + i, 1000 + i) + b'{"n":%d}' % i) for i in range(30000)
)
nostats_data = header + schema + channel + many + data_end
with open(os.path.join(out_dir, "unchunked_nostats.mcap"), "wb") as f:
    f.write(nostats_data + schema + channel + footer(len(nostats_data)))
# The same messages with no summary section at all (summary_start == 0).
with open(os.path.join(out_dir, "nosummary.mcap"), "wb") as f:
    f.write(data + footer(0))


def metadata_record(name, value_len):
    """A Metadata record holding one key whose value is value_len zero bytes."""
    entry_len = 4 + 4 + 4 + value_len  # key "blob", then the value string
    body_head = s(name) + struct.pack("<I", entry_len) + s("blob") + struct.pack("<I", value_len)
    return bytes([0x0C]) + struct.pack("<Q", len(body_head) + value_len) + body_head


def metadata_index(offset, length, name):
    return rec(0x0D, struct.pack("<QQ", offset, length) + s(name))


# unchunked.mcap also carries one small, indexed metadata record ("calib").
small = metadata_record("calib", 16) + bytes(16)
small_at = len(data) - len(data_end)
with_meta = data[:small_at] + small + data_end
with open(os.path.join(out_dir, "unchunked.mcap"), "wb") as f:
    f.write(
        with_meta + schema + channel + stats
        + metadata_index(small_at, len(small), "calib") + footer(len(with_meta))
    )

# (c) big_metadata.mcap: 256 indexed metadata records of 1 MiB each. No single
#     record is large, but listing them all would read 256 MiB, far more than
#     any sane total budget. Each record holds a tiny map followed by 1 MiB of
#     trailing padding (readers skip trailing record bytes), so a listing stays
#     short. Written sparse like the oversized summary.
ONE = 1024 * 1024
with open(os.path.join(out_dir, "big_metadata.mcap"), "wb") as f:
    f.write(header)
    indexes = b""
    for n in range(256):
        start = f.tell()
        name = "m%03d" % n
        body = s(name) + struct.pack("<I", 4 + 1 + 4 + 1) + s("k") + s("v")
        f.write(bytes([0x0C]) + struct.pack("<Q", len(body) + ONE) + body)
        f.seek(ONE, 1)
        indexes += metadata_index(start, f.tell() - start, name)
    f.write(data_end)
    summary_at = f.tell()
    f.write(indexes + footer(summary_at))

# (b) A valid MCAP whose summary is one 256 MiB schema record, far above any
#     sane bounded-read budget. Written sparse: the schema bytes are a hole of
#     zeros, so the file costs almost no disk.
LARGE = 256 * 1024 * 1024
summary_start = len(header) + len(data_end)
schema_head = (
    bytes([0x03])
    + struct.pack("<Q", 2 + (4 + 3) + 4 + 4 + LARGE)
    + struct.pack("<H", 1)
    + s("big")
    + s("")
    + struct.pack("<I", LARGE)
)
with open(os.path.join(out_dir, "oversized_summary.mcap"), "wb") as f:
    f.write(header + data_end + schema_head)
    end = f.tell() + LARGE
    f.truncate(end)
    f.seek(end)
    f.write(footer(summary_start))
print("crafted unchunked.mcap, unchunked_nostats.mcap, nosummary.mcap, oversized_summary.mcap, big_metadata.mcap")
PY

# A real ROS1 bag (3 messages: two on /chatter, one on /diagnostics) to drive
# convert. The image pulls it from git-lfs next to the MCAP fixtures.
test "$(head -c 13 "$REPO/testdata/bags/demo.bag")" = "#ROSBAG V2.0" || {
    echo "ERROR: expected repo fixture $REPO/testdata/bags/demo.bag (git-lfs not pulled?)" >&2
    exit 1
}
cp "$REPO/testdata/bags/demo.bag" "$FIXTURES/demo.bag"

# Step 3: Loud smoke guard. The binary must read the real local fixture, and
# each crafted fixture must have the size the stories rely on.
"$MCAP_BIN" info "$FIXTURES/local.mcap" >/dev/null 2>&1 || {
    echo "ERROR: mcap info failed on staged local fixture" >&2
    exit 1
}
# The crafted bytes are fixed, so their sizes are too. These checks don't run the
# built binary, so a solution that breaks local reads fails its stories rather
# than this setup step.
test "$(stat -c%s "$FIXTURES/unchunked.mcap")" -eq 503 || { echo "ERROR: unchunked.mcap wrong size" >&2; exit 1; }
test "$(stat -c%s "$FIXTURES/unchunked_nostats.mcap")" -eq 1249130 || { echo "ERROR: unchunked_nostats.mcap wrong size" >&2; exit 1; }
test "$(stat -c%s "$FIXTURES/nosummary.mcap")" -eq 275 || { echo "ERROR: nosummary.mcap wrong size" >&2; exit 1; }
oversized_sz=$(stat -c%s "$FIXTURES/oversized_summary.mcap")
test "$oversized_sz" -gt "$((250*1024*1024))" || { echo "ERROR: oversized_summary.mcap too small ($oversized_sz)" >&2; exit 1; }
big_meta_sz=$(stat -c%s "$FIXTURES/big_metadata.mcap")
test "$big_meta_sz" -gt "$((250*1024*1024))" || { echo "ERROR: big_metadata.mcap too small ($big_meta_sz)" >&2; exit 1; }

echo "validation-setup: done. Fixtures staged under $FIXTURES:"
ls -l "$FIXTURES"
