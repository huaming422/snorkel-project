"""Compile-gate verifier for mcap-feat-remote-scan-opt-in.

Behavior is checked by the validation stories, which drive the built `mcap`
binary against local fixtures and a local HTTP range server. This file is a
compile check over the CLI crate (package `mcap-cli`), so a change that doesn't
type-check fails here before the stories try to build it.

Stays implementation-agnostic: it builds through the pre-existing, stable cargo
package interface (`-p mcap-cli`), imports no module by name, searches for no
symbol or flag spelling, and does not run the crate's test suite (so it is
insensitive to which tests exist). Any plumbing shape that compiles passes; the
behavior is graded by the validation stories.
"""

from __future__ import annotations

import os
import subprocess
import textwrap


# Rust workspace root inside the task container. The CLI crate lives under
# rust/cli, but cargo is invoked from the workspace root with the package name.
RUST_DIR = "/repo/mcap/rust"

# The CLI crate, addressed by its cargo package name (the `-p` argument) rather
# than an on-disk path.
PACKAGE = "mcap-cli"

# 10 minutes is generous: a cold workspace check is a few minutes, a warm run
# completes in seconds. The image pre-builds the workspace and test-setup.sh
# rebuilds the binary, so this is usually fast.
CHECK_TIMEOUT_SEC = 600


def _toolchain_env() -> dict[str, str]:
    """os.environ with the image's Rust toolchain paths defaulted in.

    Each verifier phase starts a fresh shell, so the Dockerfile's ENV lines
    are re-asserted here with setdefault (never clobbering values the harness
    already exported).
    """
    env = {**os.environ}
    env.setdefault("RUSTUP_HOME", "/opt/rustup")
    env.setdefault("CARGO_HOME", "/opt/cargo")
    env.setdefault("CARGO_TARGET_DIR", "/opt/cache/cargo-target")
    env.setdefault("RUSTUP_TOOLCHAIN", "1.99.0")
    env["PATH"] = f"{env['CARGO_HOME']}/bin:" + env.get("PATH", "")
    return env


def test_cli_crate_compiles() -> None:
    """The modified CLI crate must still `cargo check` cleanly.

    Runs `cargo check -p mcap-cli --message-format=short` from the Rust
    workspace root. On failure, dumps the last 200 lines of stdout + stderr so
    the failure mode is visible in the verifier log without flooding the judge
    prompt.
    """
    cmd = ["cargo", "check", "-p", PACKAGE, "--message-format=short"]

    result = subprocess.run(
        cmd,
        cwd=RUST_DIR,
        capture_output=True,
        text=True,
        timeout=CHECK_TIMEOUT_SEC,
        env=_toolchain_env(),
        check=False,
    )

    if result.returncode == 0:
        return

    def _tail(text: str, n: int = 200) -> str:
        return "\n".join(text.splitlines()[-n:])

    msg = textwrap.dedent(
        f"""\
        cargo check failed (exit {result.returncode}).
        The {PACKAGE} crate no longer type-checks.

        --- cargo check stdout (last 200 lines) ---
        {_tail(result.stdout)}

        --- cargo check stderr (last 200 lines) ---
        {_tail(result.stderr)}
        """
    )
    raise AssertionError(msg)
