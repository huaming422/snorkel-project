#!/usr/bin/env bash
# test-setup.sh: setup that runs before the compile check and the stories.
# The image already installed the Rust toolchain, warmed the cargo registry at
# the base commit, and pre-built the workspace tests. This script re-exports the
# toolchain env (each phase starts a fresh shell, so Dockerfile ENV from RUN
# lines is not inherited) and makes sure the `mcap` binary is built so the
# validation stories can drive it. Offline-first: the dependency closure is
# already baked into the image; any build here compiles from the warm cache.
set -euo pipefail

# Re-export the toolchain paths the Dockerfile set (block 0 ENV).
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export RUSTUP_TOOLCHAIN="${RUSTUP_TOOLCHAIN:-1.99.0}"
export PATH="$CARGO_HOME/bin:$PATH"

REPO_DIR="${REPO_DIR:-/repo/mcap}"
RUST_DIR="$REPO_DIR/rust"

# Sanity check: the toolchain must be present.
rustc --version >/dev/null 2>&1 || {
    echo "ERROR: rustc not found on PATH (CARGO_HOME=$CARGO_HOME)" >&2
    exit 1
}
cargo --version >/dev/null 2>&1 || {
    echo "ERROR: cargo not found on PATH" >&2
    exit 1
}

# Build the CLI binary the validation stories drive. Incremental: the image
# pre-built the workspace tests, so this compiles only what changed. Build
# offline from the warm cargo cache; the image carries the full dependency
# closure.
cd "$RUST_DIR"
echo "[test-setup] building mcap-cli (offline)..."
cargo build --offline -p mcap-cli > /tmp/mcap-cli-build.log 2>&1 || {
    echo "[test-setup] offline build failed; retrying with network (verifier phase has gateway only)" >&2
    cargo build -p mcap-cli > /tmp/mcap-cli-build.log 2>&1 || {
        tail -80 /tmp/mcap-cli-build.log >&2
        exit 1
    }
}

# Locate and sanity-check the produced binary.
MCAP_BIN="$CARGO_TARGET_DIR/debug/mcap"
if [ ! -x "$MCAP_BIN" ]; then
    MCAP_BIN="$RUST_DIR/target/debug/mcap"
fi
"$MCAP_BIN" --help >/dev/null 2>&1 || {
    echo "ERROR: built mcap binary is not runnable at $MCAP_BIN" >&2
    exit 1
}

echo "test-setup: rustc=$(rustc --version), mcap=$MCAP_BIN"
