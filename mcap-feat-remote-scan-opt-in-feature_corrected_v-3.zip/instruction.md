## Task

The Rust port of the `mcap` CLI (`rust/cli`, the `mcap-cli` crate) can read MCAP files straight from an HTTP URL. That's handy for a quick `mcap info`, since it only fetches the summary at the end of the file. The trouble is that every other command takes a URL too, and something like `mcap filter https://...` will happily drag a multi-gigabyte recording over the network without asking.

I'd like remote reads that can get big to need an explicit yes from the user, given as a new global flag that every subcommand accepts. A refusal should be cheap: it can read the footer and up to a conservative budget of summary or index, but none of the message data. Keep this to the Rust CLI. The Go CLI, the MCAP format and the core `mcap` library crate stay as they are.

## User stories / requirements

- The new flag works before or after the subcommand name, and an ordinary command on a local file runs the same with it as without it.
- A command that pulls the whole remote file (convert, filter, sort, compress, decompress, recover, doctor or du) is refused without the flag before any of the file body is downloaded, and the error names the flag. With the flag it gives the same result as on a local copy. Local files never need it.
- Printing messages from a remote file with cat is refused without the flag when it would fetch message chunks, and also when the file has no chunk index to say where its messages are. With the flag every message prints.
- A remote file with no summary section can't be read without the flag, since the only way in is a full scan. With the flag it opens and all of its messages print.
- A remote summary or index over a conservative budget is refused without the flag, since that small read would become most of the file, and so is listing metadata whose records add up to more than a budget. With the flag the summary reads fine. Normal-sized ones still work with info and the channel list.
- Merging needs the flag as soon as any input is remote, and each remote input is checked wherever it sits in the list. With the flag the merged file holds every message from all inputs, and merge takes several remote inputs at once.
- When a remote read is refused, the error still names the host but never shows credentials from the URL, whether they sit in the query string or in a user:password part.
