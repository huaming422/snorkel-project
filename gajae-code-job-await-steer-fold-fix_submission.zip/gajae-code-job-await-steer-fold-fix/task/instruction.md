## Task

users report that when the agent is waiting on a running `job` (say, mid `job poll`) and they send a steer, nothing happens until the poll's own timeout finally elapses. they're stuck behind the long wait with no way to redirect.

worth noting: in the same session, a steer that lands while a foreground `bash` command is still waiting gets picked up right away. the `bash` path already handles a mid-wait steer the way you'd expect. job awaits just don't get that treatment.

what we want is for a steer during a job await to be handled just as promptly: return control to the user, while the underlying job keeps running on its original deadline and surfaces its results on a later turn. don't kill, cancel, or restart the job to make this happen, and make sure each job completion still lands exactly once. the `bash` steer behavior is already correct, so leave it as it is. dig in and fix it.
