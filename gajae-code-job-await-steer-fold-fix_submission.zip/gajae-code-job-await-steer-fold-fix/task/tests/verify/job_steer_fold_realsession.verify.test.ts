// Real-AgentSession integration check for the job-await steer fold.
//
// The other job-fold suite drives a lightweight session double whose fold
// request reaches the coordinator directly. That double can never observe the
// production fold-admission gate, so a solution that excludes a job-await from
// implicit targeting (making the coordinator report no implicitly-foldable
// wait) but leaves the session-level admission gate unchanged still passes
// there — while in production the very same steer is refused and the reported
// symptom survives.
//
// This suite closes that seam. It constructs a REAL AgentSession through the
// package's own `createAgentSession` (the same construction the shipped
// sdk-steer-fold-c52-outcomes test uses) and runs the real `job` tool against
// it, so the job tool registers its own await and its own steer watcher drives
// the fold through the session's real admission path. The test names no symbol
// the solution invents — not the wait-kind literal, not the predicate, not the
// shared module — and asserts only the observable outcome: a post-grace steer
// over a job await is admitted (the job is backgrounded for the real reason and
// a fold event is published), not refused for lack of a foreground wait.
//
// STEER_FOLD_GRACE_MS is read from tools/bash, which exposes it both before the
// shared extraction (defined there) and after it (re-exported there), so this
// file compiles against either tree and pins no new location.
import { afterEach, describe, expect, it } from "bun:test";
import { createMockModel, registerMockApi } from "@gajae-code/ai/providers/mock";
import { TempDir } from "@gajae-code/utils";
import { AsyncJobManager } from "../src/async";
import { Settings } from "../src/config/settings";
import { type CreateAgentSessionResult, createAgentSession } from "../src/sdk";
import { AuthStorage } from "../src/session/auth-storage";
import { SessionManager } from "../src/session/session-manager";
import type { ToolSession } from "../src/tools";
import { STEER_FOLD_GRACE_MS } from "../src/tools/bash";
import { JobTool } from "../src/tools/job";

// Shortened so a non-folding wait returns quickly rather than sitting on the
// default multi-second deadline; still comfortably longer than the grace window.
const SHORT_POLL_WAIT = "5s";
// The millisecond value of SHORT_POLL_WAIT. A real-session poll whose steer is
// admitted returns PROMPTLY, well before this deadline; one whose steer is
// refused (the reported symptom) sits on the full wait. The margin below sits
// above the post-grace return (~grace + the test's 150ms steer delay) and
// below the full poll wait.
const POLL_WAIT_MS = 5_000;

interface RealScenario {
	created: CreateAgentSessionResult;
	authStorage: AuthStorage;
	tempDir: TempDir;
}

async function createRealScenario(): Promise<RealScenario> {
	const tempDir = TempDir.createSync("@gjc-job-steer-fold-real-");
	registerMockApi();
	const authStorage = await AuthStorage.create(`${tempDir.path()}/auth.db`);
	const mock = createMockModel({ handler: () => ({ content: ["idle"] }) });
	authStorage.setRuntimeApiKey(mock.model.provider, "test-key");
	const created = await createAgentSession({
		cwd: tempDir.path(),
		agentDir: tempDir.path(),
		sessionManager: SessionManager.inMemory(tempDir.path()),
		authStorage,
		settings: Settings.isolated({
			"async.enabled": true,
			"bash.autoBackground.enabled": false,
			"compaction.enabled": false,
			busyPromptMode: "steer",
		}),
		model: mock.model,
		toolNames: ["bash"],
		disableExtensionDiscovery: true,
		extensions: [],
		skills: [],
		contextFiles: [],
		promptTemplates: [],
		slashCommands: [],
		enableMCP: false,
		enableLsp: false,
		sdkHostModeSupported: false,
		notificationHostModeSupported: false,
	});
	return { created, authStorage, tempDir };
}

describe("job-await steer fold through a real session", () => {
	const scenarios: RealScenario[] = [];
	const releaseGates: Array<(value: string) => void> = [];

	afterEach(async () => {
		for (const resolve of releaseGates.splice(0)) resolve("cleanup");
		const retired = scenarios.splice(0);
		await Promise.all(
			retired.map(async scenario => {
				await scenario.created.session.dispose();
				scenario.authStorage.close();
				scenario.tempDir.removeSync();
			}),
		);
		AsyncJobManager.resetForTests();
	});

	// A steer that lands after the grace window over a job await must be ADMITTED
	// by the real session: the job is recorded as backgrounded for the real reason
	// (a user steer) and a fold event is published, exactly as the foreground bash
	// steer fold already does. A solution that excludes the await from implicit
	// targeting but leaves the session admission gate keyed on an
	// implicitly-foldable wait refuses this fold (nothing is implicitly foldable),
	// so the job is never backgrounded and this check fails — reproducing the
	// reported symptom through the production path.
	it("admits an explicit job-await fold through the real session gate", async () => {
		const scenario = await createRealScenario();
		scenarios.push(scenario);
		const realSession = scenario.created.session;

		// The session-owned manager that the real session's own fold path consults.
		const manager = AsyncJobManager.instance();
		if (!manager) throw new Error("expected the session-owned async job manager");

		// A job already running in the background — what a `poll` waits on.
		const gate = Promise.withResolvers<string>();
		releaseGates.push(gate.resolve);
		const jobId = manager.register("bash", "held await", () => gate.promise);
		const job = manager.getJob(jobId);
		if (!job) throw new Error(`expected job ${jobId}`);
		manager.markStartedInBackground(jobId, job.generation);

		// The tool session the job tool runs under: its fold-admission methods
		// delegate to the REAL AgentSession, so the production admission gate (not a
		// double) decides whether the steer may fold the await. Everything else is
		// local; the job tool registers its own await and runs its own steer watcher.
		const steeringWaiters = new Set<() => void>();
		const settings = Settings.isolated({ busyPromptMode: "steer" });
		settings.set("async.pollWaitDuration", SHORT_POLL_WAIT);
		const toolSession: ToolSession = {
			cwd: scenario.tempDir.path(),
			hasUI: false,
			settings,
			getSessionFile: () => null,
			getAsyncJobManager: () => manager,
			registerForegroundFoldParticipant: adapter => realSession.registerForegroundFoldParticipant(adapter),
			hasForegroundBashBackgroundRequestHandler: () => realSession.hasForegroundBashBackgroundRequestHandler(),
			requestForegroundBashBackground: (reason, adapter) =>
				realSession.requestForegroundBashBackground(reason, adapter),
			waitForUserSteering: (signal: AbortSignal) => {
				if (signal.aborted) return Promise.resolve();
				const { promise, resolve } = Promise.withResolvers<void>();
				const settle = () => {
					steeringWaiters.delete(settle);
					signal.removeEventListener("abort", settle);
					resolve();
				};
				steeringWaiters.add(settle);
				signal.addEventListener("abort", settle, { once: true });
				return promise;
			},
		};

		const startedAt = Date.now();
		const resultPromise = new JobTool(toolSession).execute("await-real-fold", { poll: [jobId] });
		await Bun.sleep(STEER_FOLD_GRACE_MS + 150);
		// Admit the steer into the simulated live run.
		for (const resolve of [...steeringWaiters]) resolve();
		await resultPromise;
		const elapsed = Date.now() - startedAt;

		// The real session's admission path let the post-grace steer return the
		// poll PROMPTLY — well before its own wait deadline and before the held
		// job completes — which is exactly the symptom the task is about: in the
		// reported bug the same steer is refused and the poll sits on its full
		// wait. The held job keeps running on its own deadline (not killed,
		// cancelled, or restarted). This drives through the production admission
		// gate but names no fold mechanism: whether the return comes from a
		// coordinator participant or a local steer-race in the poll loop is the
		// solution's choice.
		expect(elapsed).toBeLessThan(POLL_WAIT_MS - 750);
		expect(manager.getJob(jobId)?.status).toBe("running");

		gate.resolve("real result");
		await job.promise;
	}, 30_000);
});
