// Behavioral checks for bringing a running-job await to parity with the
// foreground shell wait when a redirect lands mid-wait.
//
// Everything here drives through stable, pre-existing surfaces only:
//   * the job tool's public `execute({ poll })` entry point,
//   * the shared steer-fold test helpers (a hermetic copy shipped alongside
//     this file so the check does not depend on the repo's own test tree),
//   * the session coordinator's public read API (slotStateFor / onDelivery /
//     resolveTarget / hasFoldableParticipant) and the manager's fold-event
//     stream (JobFoldEvent) + job metadata.
// It never imports a symbol the solution invents (no predicate name, no new
// module, no new wait-kind literal) and never asserts a model-facing wording
// the solution is free to choose — only the observable enum values, job
// lifecycle state, event counts, and delivery dispositions the contract fixes.
//
// STEER_FOLD_GRACE_MS is read from tools/bash, which exposes it both before the
// shared extraction (defined there) and after it (re-exported there) — so this
// file compiles against either tree and pins no new location.
import { afterEach, beforeEach, describe, expect, it } from "bun:test";
import { AsyncJobManager } from "../src/async";
import type { FoldAdapter } from "../src/session/fold-coordinator";
import { STEER_FOLD_GRACE_MS } from "../src/tools/bash";
import { JobTool } from "../src/tools/job";
import { createSteerHarness, type SteerHarness, textOf } from "./helpers/steer_fold_verify_harness";

// The poll's own wait is shortened so a non-folding wait (the prior behaviour
// and the deliberately-non-folding cases) returns quickly instead of sitting on
// the default multi-second deadline. It stays comfortably longer than the grace
// window, so a steer admitted after the grace window still has room to fold
// before the wait would otherwise return on its own.
const SHORT_POLL_WAIT = "5s";
// The millisecond value of SHORT_POLL_WAIT. A folded await returns PROMPTLY,
// well before this deadline; a wait with no fold path sits on it in full. The
// margin below (POLL_WAIT_MS - 750) sits comfortably above the post-grace fold
// return (~grace + the test's 150ms steer delay) and below the full poll wait,
// so the prompt-return assertion separates a folding solution from one that
// never admits the steer — without naming how the fold is implemented.
const POLL_WAIT_MS = 5_000;

describe("steer-triggered job await parity", () => {
	let harness: SteerHarness | undefined;

	function useHarness(options?: Parameters<typeof createSteerHarness>[1]): SteerHarness {
		const h = createSteerHarness(process.cwd(), options);
		h.session.settings.set("async.pollWaitDuration", SHORT_POLL_WAIT);
		harness = h;
		return h;
	}

	beforeEach(() => {
		harness = undefined;
	});

	afterEach(async () => {
		await harness?.manager.dispose({ timeoutMs: 200 });
		harness = undefined;
		AsyncJobManager.resetForTests();
	});

	// Register a job that stays running until the test resolves its gate, and
	// mark it as already running in the background (what a `poll` waits on).
	function registerHeldJob(h: SteerHarness, label: string, type: "bash" | "task" = "bash") {
		const gate = Promise.withResolvers<string>();
		const id = h.manager.register(type, label, () => gate.promise);
		const job = h.manager.getJob(id);
		if (!job) throw new Error(`expected job ${id}`);
		h.manager.markStartedInBackground(id, job.generation);
		return { gate, id, job };
	}

	// Criterion 1: a redirect that lands after the grace window RETURNS THE POLL
	// PROMPTLY — well before its own wait deadline and before any watched job
	// completes — while every watched job keeps running on its own deadline
	// (not killed, cancelled, or restarted), and each completion still surfaces
	// exactly once on a later poll. These are the observable behaviors the
	// contract fixes; how the prompt return is achieved is the solution's
	// choice (a coordinator fold, a local steer-race in the poll loop, etc.),
	// so this check names no fold mechanism. Before the change the steer is
	// ignored and the poll sits on its full wait deadline.
	it("returns a post-grace await promptly and keeps every watched job running", async () => {
		const h = useHarness();
		const first = registerHeldJob(h, "first await");
		const second = registerHeldJob(h, "second await");
		const tool = new JobTool(h.session);
		const startedAt = Date.now();
		const resultPromise = tool.execute("await-fold", { poll: [first.id, second.id] });

		await Bun.sleep(STEER_FOLD_GRACE_MS + 150);
		h.steer();
		await resultPromise;
		const elapsed = Date.now() - startedAt;

		// The poll came back promptly after the steer — well under its own wait
		// deadline. A solution with no steer path would instead sit on the full
		// POLL_WAIT_MS before returning.
		expect(elapsed).toBeLessThan(POLL_WAIT_MS - 750);
		// Neither watched job completed to cause the return: both are still
		// running (not killed, cancelled, or restarted) on their own deadlines.
		expect(h.manager.getJob(first.id)?.status).toBe("running");
		expect(h.manager.getJob(second.id)?.status).toBe("running");

		// Each completion surfaces exactly once on a later poll.
		first.gate.resolve("first result");
		second.gate.resolve("second result");
		await Promise.all([first.job.promise, second.job.promise]);
		const completed = await tool.execute("await-complete", { poll: [first.id, second.id] });
		const text = textOf(completed);
		expect(text).toContain("first result");
		expect(text).toContain("second result");
		expect(text.split("first result").length - 1).toBe(1);
		expect(text.split("second result").length - 1).toBe(1);
	}, 15_000);

	// Criterion 2 + 3: the implicitly-targeted folds (the fold chord and the SDK
	// background control, neither of which names a wait) must never resolve to a
	// job await. With only a job poll in flight nothing is implicitly foldable,
	// the await leaves no delivery slot, and the eventual completion is an
	// ordinary (single) delivery — not a second, receipt-bearing wake.
	it("never lets an implicitly-targeted fold resolve to a job await", async () => {
		const h = useHarness();
		const held = registerHeldJob(h, "implicit-immune await");
		const tool = new JobTool(h.session);
		const resultPromise = tool.execute("await-implicit", { poll: [held.id] });
		await Bun.sleep(100);

		// No implicit fold target exists, and asking for one changes nothing.
		expect(h.coordinator.hasFoldableParticipant()).toBe(false);
		expect(h.coordinator.resolveTarget()).toBeUndefined();
		expect(h.session.hasForegroundBashBackgroundRequestHandler?.()).toBe(false);
		expect(await h.session.requestForegroundBashBackground?.("chord")).toBe(false);
		expect(await h.session.requestForegroundBashBackground?.("sdk_control")).toBe(false);
		expect(h.folds).toHaveLength(0);
		expect(h.coordinator.slotStateFor(held.job)).toBe("none");
		expect(h.manager.getJob(held.id)?.metadata?.foldReason).toBeUndefined();

		held.gate.resolve("implicit-immune result");
		await resultPromise;
		// No phantom slot survived: the completion is a single ordinary delivery.
		expect(h.coordinator.onDelivery(held.job, "implicit-immune result")).toEqual({ kind: "ordinary" });
	}, 15_000);

	// Criterion 2 (parity theft): a foreground shell wait that is in play keeps
	// the implicit fold target even when a job poll registers its await AFTER it.
	// The chord resolves to the shell wait, never to the later job await.
	it("keeps a foreground shell wait as the implicit target when a job poll registers after it", async () => {
		const h = useHarness();
		// A foreground shell wait: a bash-managed participant (a pre-existing wait
		// kind) registered through the session the same way the shell tool does.
		const foreground = registerHeldJob(h, "foreground shell");
		const detached: Array<{ reason: string }> = [];
		const bashAdapter: FoldAdapter = {
			kind: "bash-managed",
			jobId: foreground.id,
			jobGeneration: foreground.job.generation,
			label: foreground.job.label,
			cwdSensitive: true,
			originatingTurn: true,
			outputRef: { jobId: foreground.id, generation: foreground.job.generation, instruction: "tail it" },
			getJob: () => h.manager.getJob(foreground.id),
			detachObserver: receipt => {
				detached.push({ reason: receipt.reason });
				return "resolved";
			},
			resolveForegroundObserver: () => "resolved",
		};
		h.session.registerForegroundFoldParticipant?.(bashAdapter);

		// Now a job poll comes in and registers its await (a later registration).
		const held = registerHeldJob(h, "later job await");
		const pollPromise = new JobTool(h.session).execute("await-after-shell", { poll: [held.id] });
		await Bun.sleep(100);

		// The implicit target is still the shell wait, not the newer job await.
		expect(h.coordinator.resolveTarget()).toBe(bashAdapter);
		const chord = await h.coordinator.requestFold();
		expect(chord.status).toBe("folded");
		expect(detached).toHaveLength(1);
		// The job await was not touched by the implicit fold.
		expect(h.coordinator.slotStateFor(held.job)).toBe("none");
		expect(h.manager.getJob(held.id)?.metadata?.foldReason).toBeUndefined();

		held.gate.resolve("later result");
		foreground.gate.resolve("shell result");
		await pollPromise;
	}, 15_000);

	// (The former criterion-4 case — that an explicitly `chord`-folded await
	// records `foldReason == "chord"` and registers as a coordinator
	// participant — was removed from the correctness gate: it pinned the
	// reference's FoldCoordinator participant mechanism and a chord-driven
	// job-await fold path, neither of which the contract promises. A solution
	// is free to admit the steer without a coordinator participant at all. The
	// "records the real fold reason" concern lives in the rubric only.)

	// Criterion 5: steering a poll over a job an earlier fold already moved to
	// the background still RELEASES the await promptly, and the eventual
	// completion still lands exactly once. The job is already backgrounded (an
	// earlier fold owns it), so there is "nothing left to move" — a correct
	// solution must still return the poll on the post-grace steer rather than
	// sit on its full wait, and must not double-deliver the completion from the
	// already-owned receipt. This names no fold mechanism: the prior fold is
	// established through the manager's pre-existing public `markBackgrounded`,
	// and the assertions are the observable return-promptly / still-running /
	// exactly-once outcomes.
	it("releases a steered await over an already-backgrounded job and delivers exactly once", async () => {
		const h = useHarness();
		const held = registerHeldJob(h, "previously folded");
		// An earlier fold already moved this job to the background with a reason;
		// `markBackgrounded` is a pre-existing manager surface, not a fold
		// mechanism the solution must invent.
		h.manager.markBackgrounded(held.id, held.job.generation, "chord");

		// Now a poll steers over that same, already-moved job.
		const startedAt = Date.now();
		const tool = new JobTool(h.session);
		const resultPromise = tool.execute("await-refold", { poll: [held.id] });
		await Bun.sleep(STEER_FOLD_GRACE_MS + 150);
		h.steer();
		await resultPromise;
		const elapsed = Date.now() - startedAt;

		// Returned promptly (not on the full wait) and the job is still running.
		expect(elapsed).toBeLessThan(POLL_WAIT_MS - 750);
		expect(h.manager.getJob(held.id)?.status).toBe("running");

		// The completion lands exactly once on a later poll.
		held.gate.resolve("refold result");
		await held.job.promise;
		const completed = await tool.execute("await-refold-complete", { poll: [held.id] });
		const text = textOf(completed);
		expect(text).toContain("refold result");
		expect(text.split("refold result").length - 1).toBe(1);
	}, 15_000);

	// Criterion 6: a task-backed job (type `task` / subagent work) is watched by a
	// job poll, but the fold machinery never ENGAGES it — no coordinator fold
	// event, no recorded fold reason, no delivery slot — and the subagent keeps
	// running regardless of the steer. This guards against a solution that mints a
	// bogus steer fold / receipt slot on a subagent (which would pollute implicit
	// targeting or double-deliver the subagent's result). It pins NO design for
	// the poll's own observation window: whether the poll ends early on the steer
	// (mirroring the pre-existing subagent-await-ends-on-steer behavior) or waits
	// the task out is the solution's choice, so this check asserts neither a
	// prompt return nor a block-through. (The earlier form of this case additionally
	// required the poll to BLOCK through the steer — that pinned the reference's
	// task-exclusion policy, a design choice base.md never states and the
	// subagent-await precedent contradicts, so it was dropped. "The new fold
	// machinery treats task/subagent awaits as a non-goal" lives in the rubric as a
	// taste criterion.)
	it("watches a task-backed job without minting a fold on it", async () => {
		const h = useHarness();
		const task = registerHeldJob(h, "subagent task", "task");
		const resultPromise = new JobTool(h.session).execute("await-task", { poll: [task.id] });
		await Bun.sleep(STEER_FOLD_GRACE_MS + 150);
		expect(h.session.hasForegroundBashBackgroundRequestHandler?.()).toBe(false);
		h.steer();
		await Bun.sleep(100);

		// The new fold machinery never engaged the subagent: no coordinator fold
		// event, no recorded fold reason, no delivery slot. A solution that folded a
		// subagent through the coordinator (minting a steer fold-event/receipt on it)
		// would fail here.
		expect(h.folds).toHaveLength(0);
		expect(h.manager.getJob(task.id)?.metadata?.foldReason).toBeUndefined();
		expect(h.coordinator.slotStateFor(task.job)).toBe("none");
		// The subagent keeps running on its own deadline — the steer never killed,
		// cancelled, or restarted it (whether or not the poll itself returned early).
		expect(h.manager.getJob(task.id)?.status).toBe("running");

		// Release the subagent so the poll settles and the test cleans up; its
		// result surfaces through the manager's own delivery exactly as before.
		task.gate.resolve("task result");
		await resultPromise;
		expect(h.folds).toHaveLength(0);
	}, 15_000);

	// Guard (supports criterion 1): a steer admitted INSIDE the grace window must
	// not fold — the wait only folds once the shared grace window has elapsed, the
	// same window the bash path honors. The watched job is deliberately NOT
	// resolved before the non-settlement probe below, so a solution that admits
	// ANY steer regardless of elapsed time (no grace check) is observable here as a
	// prompt return while the job is still running — rather than slipping through
	// because the completed job's result happened to win the race. The job is
	// released only after the probe proves the poll is still waiting.
	it("does not fold a steer admitted inside the grace window", async () => {
		const h = useHarness();
		const held = registerHeldJob(h, "early await");
		const resultPromise = new JobTool(h.session).execute("await-early", { poll: [held.id] });
		// Steer well inside the shared grace window (STEER_FOLD_GRACE_MS). A
		// grace-respecting solution must NOT fold on this steer.
		await Bun.sleep(100);
		h.steer();

		// The poll must still be waiting a moment later: a no-grace shortcut would
		// have folded and returned the poll by now. Race the poll against a probe
		// window (still comfortably inside the grace window) — the probe must win.
		const stillPending = Symbol("still-pending");
		const raced = await Promise.race([
			resultPromise.then(() => "returned-early" as const),
			Bun.sleep(300).then(() => stillPending),
		]);
		expect(raced).toBe(stillPending);
		// ...and the job kept running the whole time (never killed/cancelled).
		expect(h.manager.getJob(held.id)?.status).toBe("running");

		// The wait ends normally once the job completes — no fold ever happened.
		held.gate.resolve("early result");
		const result = await resultPromise;
		expect(h.folds).toHaveLength(0);
		expect(h.manager.getJob(held.id)?.metadata?.foldReason).toBeUndefined();
		expect(textOf(result)).toContain("early result");
	}, 15_000);
});
