import { randomUUID } from 'node:crypto'
import { mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import type { PrismaClient } from '@prisma/client'
import { afterEach, describe, expect, it, vi } from 'vitest'

import {
  literatureItemInputSchema,
  type LiteratureItemView,
  type LiteratureMetadataCompletionResult
} from '../../shared/literature'
import type { LiteratureJob } from '../../shared/literature-jobs'
import { migrateApplicationDatabase } from '../database/migration-service'
import { createProjectDbClient } from '../projects/prisma-client'
import { LiteratureBatchJobs } from './batch-jobs'
import { LiteratureCatalog } from './catalog'
import { LiteratureMetadataEnricher } from './metadata-enricher'

// Everything here goes through the existing public surface: LiteratureCatalog on a real migrated
// SQLite database, LiteratureMetadataEnricher.applyReviewed(), and the LiteratureBatchJobs request
// API. Nothing names where or how a change keeps track of an update that already landed.

// The write operations Prisma can emit while saving a reference update.
const WRITE_OPERATIONS = new Set<string>([
  'create',
  'createMany',
  'createManyAndReturn',
  'update',
  'updateMany',
  'updateManyAndReturn',
  'upsert',
  'delete',
  'deleteMany',
  'executeRaw',
  'executeRawUnsafe',
  '$executeRaw',
  '$executeRawUnsafe'
])

// A content fingerprint of every application row, so a change left behind in any table is
// visible. Prisma returns INTEGER columns as BigInt over raw SQL, so those serialize as strings.
const fingerprintDatabase = async (client: PrismaClient): Promise<string> => {
  const tables = await client.$queryRawUnsafe<Array<{ name: string }>>(
    "SELECT name FROM sqlite_schema WHERE type = 'table' " +
      "AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '_prisma_%' ORDER BY name"
  )
  const parts: string[] = []
  for (const { name } of tables) {
    const rows = await client.$queryRawUnsafe<Array<Record<string, unknown>>>(`SELECT * FROM "${name}"`)
    const serialized = rows
      .map((row) => JSON.stringify(row, (_key, value) => (typeof value === 'bigint' ? value.toString() : value)))
      .sort()
      .join('|')
    parts.push(`${name}=${rows.length}:${serialized}`)
  }
  return parts.join('\n')
}

const itemView = (view: LiteratureItemView): LiteratureItemView => structuredClone(view)

// A reviewed-metadata snapshot carrying its own review token, shaped like a renderer-driven review.
const review = (
  current: LiteratureItemView,
  token: string
): LiteratureMetadataCompletionResult => ({
  mode: 'preview',
  reviewVersion: 1,
  provider: 'crossref',
  sourceUrl: 'https://crossref.org',
  item: itemView(current),
  filled: [],
  conflicts: [],
  reviewToken: token,
  source: {
    provider: 'crossref',
    externalId: '10.1234/example',
    sourceUrl: 'https://crossref.org',
    rawMetadata: { DOI: '10.1234/example', 'container-title': ['Committed journal'] }
  }
})

const seedItem = literatureItemInputSchema.parse({
  itemType: 'journalArticle',
  title: 'Original title',
  identifiers: [{ scheme: 'doi', value: '10.1234/example' }]
})

describe('Literature metadata replay', () => {
  let storageRoot: string | undefined
  let client: PrismaClient | undefined
  const closers: Array<() => Promise<void>> = []

  afterEach(async () => {
    for (const close of closers.splice(0).reverse()) await close()
    await client?.$disconnect()
    if (storageRoot) await rm(storageRoot, { recursive: true, force: true })
  })

  const setup = async (): Promise<{ catalog: LiteratureCatalog; enricher: LiteratureMetadataEnricher }> => {
    storageRoot = await mkdtemp(join(tmpdir(), 'literature-replay-db-'))
    client = createProjectDbClient(storageRoot)
    await migrateApplicationDatabase(client)
    await client.project.create({ data: { id: 'project-1', name: 'Research' } })
    const catalog = new LiteratureCatalog(async () => client!)
    const enricher = new LiteratureMetadataEnricher(
      catalog,
      vi.fn(async () => {
        throw new Error('network should not be used')
      }) as unknown as typeof fetch
    )
    return { catalog, enricher }
  }

  // Applying the same reviewed update again after it already landed reports success and leaves
  // the reference exactly as the first apply left it.
  it('reports success when replaying a metadata operation that already committed', async () => {
    const { catalog, enricher } = await setup()
    const created = await catalog.transact({ kind: 'create-item', item: seedItem })
    const before = (await catalog.get(created.id))!

    const snapshot = review(before, 'replay-operation')
    const first = await enricher.applyReviewed(snapshot, [])
    expect(first.mode).toBe('commit')

    const committed = (await catalog.get(created.id))!
    expect(committed.metadataRevision).toBeGreaterThan(before.metadataRevision)

    // Replay the identical operation; the reference is already at (or past) the committed state.
    const replay = await enricher.applyReviewed(snapshot, [])
    expect(replay.mode).toBe('commit')

    // No duplicate re-application: the reference is byte-for-byte what the first commit produced.
    const afterReplay = (await catalog.get(created.id))!
    expect(afterReplay.metadataRevision).toBe(committed.metadataRevision)
    expect(afterReplay.item.containerTitle).toBe(committed.item.containerTitle)
  })

  // A review that never landed is refused once an unrelated edit has moved the reference on, and
  // the refusal leaves that edit in place.
  it('still conflicts on a stale unrelated operation with no reconciling prior commit', async () => {
    const { catalog, enricher } = await setup()
    const created = await catalog.transact({ kind: 'create-item', item: seedItem })
    const before = (await catalog.get(created.id))!

    // Advance the reference out from under the review via an unrelated edit.
    await catalog.transact({
      kind: 'update-item',
      itemId: created.id,
      expectedMetadataRevision: before.metadataRevision,
      item: { ...before.item, title: 'Moved on' }
    })
    const current = (await catalog.get(created.id))!
    expect(current.metadataRevision).toBeGreaterThan(before.metadataRevision)

    // The review still carries the pre-edit revision and a fresh, never-committed token.
    const stale = review(before, 'unrelated-operation')
    await expect(enricher.applyReviewed(stale, [])).rejects.toThrow()
    expect(await catalog.get(created.id)).toEqual(current)
  })

  // The earlier success is still recognised after someone edits the reference later, and applying
  // it again does not overwrite that later edit.
  it('reports success for an already-landed update even after a later unrelated edit', async () => {
    const { catalog, enricher } = await setup()
    const created = await catalog.transact({ kind: 'create-item', item: seedItem })
    const before = (await catalog.get(created.id))!

    const snapshot = review(before, 'landed-then-edited')
    expect((await enricher.applyReviewed(snapshot, [])).mode).toBe('commit')
    const committed = (await catalog.get(created.id))!

    await catalog.transact({
      kind: 'update-item',
      itemId: created.id,
      expectedMetadataRevision: committed.metadataRevision,
      item: { ...committed.item, title: 'Edited later' }
    })
    const edited = (await catalog.get(created.id))!
    expect(edited.metadataRevision).toBeGreaterThan(committed.metadataRevision)

    const replay = await enricher.applyReviewed(snapshot, [])
    expect(replay.mode).toBe('commit')
    expect(await catalog.get(created.id)).toEqual(edited)
  })

  // A review that never landed is refused even when an unrelated edit happens to leave the reference
  // looking exactly like that review's result.
  it('refuses a never-landed review when an unrelated edit made the reference look like its result', async () => {
    const { catalog, enricher } = await setup()

    // Learn what this review produces by letting it land on a twin reference.
    const twin = await catalog.transact({ kind: 'create-item', item: seedItem })
    const twinBefore = (await catalog.get(twin.id))!
    expect((await enricher.applyReviewed(review(twinBefore, 'twin-landed'), [])).mode).toBe('commit')
    const produced = (await catalog.get(twin.id))!.item

    const created = await catalog.transact({ kind: 'create-item', item: seedItem })
    const before = (await catalog.get(created.id))!
    const stale = review(before, 'never-landed')

    await catalog.transact({
      kind: 'update-item',
      itemId: created.id,
      expectedMetadataRevision: before.metadataRevision,
      item: produced
    })
    const edited = (await catalog.get(created.id))!
    expect(edited.metadataRevision).toBeGreaterThan(before.metadataRevision)
    expect(edited.item).toEqual(produced)

    await expect(enricher.applyReviewed(stale, [])).rejects.toThrow()
    expect(await catalog.get(created.id)).toEqual(edited)
  })

  // An earlier landed update from the same source does not vouch for a later review that never
  // landed: that review is refused once the reference moved on after it was taken.
  it('refuses a never-landed review even when an earlier update from the same source landed', async () => {
    const { catalog, enricher } = await setup()
    const created = await catalog.transact({ kind: 'create-item', item: seedItem })
    const before = (await catalog.get(created.id))!
    expect((await enricher.applyReviewed(review(before, 'first-landed'), [])).mode).toBe('commit')
    const landed = (await catalog.get(created.id))!

    const second = review(landed, 'second-never-landed')
    await catalog.transact({
      kind: 'update-item',
      itemId: created.id,
      expectedMetadataRevision: landed.metadataRevision,
      item: { ...landed.item, title: 'Moved on' }
    })
    const edited = (await catalog.get(created.id))!

    await expect(enricher.applyReviewed(second, [])).rejects.toThrow()
    expect(await catalog.get(created.id)).toEqual(edited)
  })

  // If saving an update fails at its last write, nothing from that update is left in the database.
  // A successful apply on one reference first counts how many writes an apply emits; a fresh apply
  // on another reference then has its last write fail, and every table must be unchanged.
  it('rolls back the metadata change and its source when its last write fails', async () => {
    const { catalog } = await setup()
    const net = (): typeof fetch =>
      vi.fn(async () => {
        throw new Error('network should not be used')
      }) as unknown as typeof fetch

    // Count the writes of one successful apply.
    const discovery = await catalog.transact({ kind: 'create-item', item: seedItem })
    const discoveryBefore = (await catalog.get(discovery.id))!
    let writeCount = 0
    const counting = client!.$extends({
      query: {
        $allOperations({ operation, args, query }) {
          if (WRITE_OPERATIONS.has(operation)) writeCount += 1
          return query(args)
        }
      }
    })
    await new LiteratureMetadataEnricher(
      new LiteratureCatalog(async () => counting as unknown as PrismaClient),
      net()
    ).applyReviewed(review(discoveryBefore, 'discovery-operation'), [])
    const writesPerCommit = writeCount
    expect(writesPerCommit, 'a successful commit should emit at least one write').toBeGreaterThan(0)

    // A fresh reference whose apply fails at its last write.
    const target = await catalog.transact({ kind: 'create-item', item: seedItem })
    const targetBefore = (await catalog.get(target.id))!
    const fingerprintBefore = await fingerprintDatabase(client!)

    let seen = 0
    const failing = client!.$extends({
      query: {
        $allOperations({ operation, args, query }) {
          if (WRITE_OPERATIONS.has(operation)) {
            seen += 1
            if (seen === writesPerCommit) throw new Error('Storage unavailable')
          }
          return query(args)
        }
      }
    })
    await expect(
      new LiteratureMetadataEnricher(
        new LiteratureCatalog(async () => failing as unknown as PrismaClient),
        net()
      ).applyReviewed(review(targetBefore, 'interrupted-operation'), [])
    ).rejects.toThrow()

    // The reference and every other table are exactly as they were before.
    expect(await catalog.get(targetBefore.id)).toEqual(targetBefore)
    expect(await fingerprintDatabase(client!)).toBe(fingerprintBefore)
  })
  // Task-level replay, through the background task service wired to the real catalog and enricher.
  const seedTask = async (
    catalog: LiteratureCatalog,
    enricher: LiteratureMetadataEnricher,
    rowItem: LiteratureItemView
  ): Promise<{
    jobId: string
    checkpoint: string
    checkpointText: string
    open: () => LiteratureBatchJobs
  }> => {
    const directory = await mkdtemp(join(tmpdir(), 'literature-replay-jobs-'))
    closers.push(() => rm(directory, { recursive: true, force: true }))
    const path = join(directory, 'jobs.json')
    const jobId = randomUUID()
    const job: LiteratureJob = {
      id: jobId,
      mode: 'metadata',
      phase: 'search',
      state: 'review',
      createdAt: 1,
      updatedAt: 1,
      rows: [
        {
          id: rowItem.id,
          status: 'ready',
          checked: true,
          item: itemView(rowItem),
          metadata: review(rowItem, randomUUID())
        }
      ]
    }
    await mkdir(`${path}.d`, { recursive: true })
    const checkpoint = join(`${path}.d`, `${jobId}.json`)
    const checkpointText = JSON.stringify(job)
    await writeFile(checkpoint, checkpointText)
    await writeFile(path, JSON.stringify({ version: 2, jobIds: [jobId] }))
    const open = (): LiteratureBatchJobs => {
      const service = new LiteratureBatchJobs({
        path,
        catalog,
        metadata: enricher,
        fullText: {
          run: vi.fn(async () => {
            throw new Error('network should not be used')
          })
        },
        onError: vi.fn(),
        spacingMs: 0
      } as unknown as ConstructorParameters<typeof LiteratureBatchJobs>[0])
      closers.push(() => service.close())
      return service
    }
    return { jobId, checkpoint, checkpointText, open }
  }

  const settledJob = async (service: LiteratureBatchJobs, jobId: string): Promise<LiteratureJob> => {
    await vi.waitFor(
      async () => {
        const job = (await service.run({ action: 'get', jobId })).jobs[0]!
        expect(['queued', 'running', 'pausing']).not.toContain(job.state)
      },
      { timeout: 10_000 }
    )
    return (await service.run({ action: 'get', jobId })).jobs[0]!
  }

  // The app stops after a task's metadata update landed but before the task saved that row as
  // finished. Applying the task again finishes it cleanly instead of failing the row.
  it('finishes a task whose metadata update landed before the app stopped', async () => {
    const { catalog, enricher } = await setup()
    const created = await catalog.transact({ kind: 'create-item', item: seedItem })
    const before = (await catalog.get(created.id))!
    const task = await seedTask(catalog, enricher, before)

    const first = task.open()
    await first.run({ action: 'apply', jobId: task.jobId, selections: [{ itemId: created.id }] })
    expect((await settledJob(first, task.jobId)).rows[0]!.status).toBe('done')
    await first.close()
    const committed = (await catalog.get(created.id))!
    expect(committed.metadataRevision).toBeGreaterThan(before.metadataRevision)

    // The finished row never reached disk: the task comes back as it was before the apply.
    await writeFile(task.checkpoint, task.checkpointText)

    const second = task.open()
    await second.run({ action: 'apply', jobId: task.jobId, selections: [{ itemId: created.id }] })
    const replayed = await settledJob(second, task.jobId)
    expect(replayed.rows[0]).toMatchObject({ id: created.id, status: 'done' })
    expect(replayed.state).toBe('completed')
    expect(await catalog.get(created.id)).toEqual(committed)
  })

  // A task row whose review never landed still fails once an unrelated edit moved the reference
  // on, and the edit stays in place.
  it('fails a task row whose review never landed after an unrelated edit', async () => {
    const { catalog, enricher } = await setup()
    const created = await catalog.transact({ kind: 'create-item', item: seedItem })
    const before = (await catalog.get(created.id))!
    const task = await seedTask(catalog, enricher, before)

    await catalog.transact({
      kind: 'update-item',
      itemId: created.id,
      expectedMetadataRevision: before.metadataRevision,
      item: { ...before.item, title: 'Moved on' }
    })
    const edited = (await catalog.get(created.id))!

    const service = task.open()
    await service.run({ action: 'apply', jobId: task.jobId, selections: [{ itemId: created.id }] })
    const job = await settledJob(service, task.jobId)
    expect(job.rows[0]!.status).toBe('error')
    expect(await catalog.get(created.id)).toEqual(edited)
  })
})
