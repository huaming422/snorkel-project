import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import type { PrismaClient } from '@prisma/client'
import { afterEach, describe, expect, it, vi } from 'vitest'

import {
  literatureItemInputSchema,
  type LiteratureItemView,
  type LiteratureMetadataCompletionResult
} from '../../shared/literature'
import {
  MIGRATION_MANIFEST,
  checksumMigrationPayload,
  migrateApplicationDatabase,
  verifyCurrentApplicationSchema
} from '../database/migration-service'
import { createProjectDbClient } from '../projects/prisma-client'
import { LiteratureCatalog } from './catalog'
import { LiteratureMetadataEnricher } from './metadata-enricher'

// The app's migration ledger stays self-consistent, a migrated database passes the app's own schema
// verification, re-running migrations keeps existing data, and using the literature catalog after
// migrating never creates schema objects of its own. No migration id, checksum or table name that a
// change might add is named here.

const schemaObjects = async (db: PrismaClient): Promise<string[]> =>
  (
    await db.$queryRawUnsafe<Array<{ type: string; name: string }>>(
      "SELECT type, name FROM sqlite_schema WHERE name NOT LIKE 'sqlite_%' ORDER BY type, name"
    )
  ).map(({ type, name }) => `${type}:${name}`)

const review = (current: LiteratureItemView, token: string): LiteratureMetadataCompletionResult => ({
  mode: 'preview',
  reviewVersion: 1,
  provider: 'crossref',
  sourceUrl: 'https://crossref.org',
  item: structuredClone(current),
  filled: [],
  conflicts: [],
  reviewToken: token,
  source: {
    provider: 'crossref',
    externalId: '10.9999/field',
    sourceUrl: 'https://crossref.org',
    rawMetadata: { DOI: '10.9999/field', 'container-title': ['Field journal'] }
  }
})

type ManifestEntry = {
  id: string
  checksum: string
  statements: readonly string[]
  verifiers: Parameters<typeof checksumMigrationPayload>[2]
  operations?: Parameters<typeof checksumMigrationPayload>[3]
}

describe('Application migration ledger consistency', () => {
  let storageRoot: string | undefined
  let client: PrismaClient | undefined

  afterEach(async () => {
    await client?.$disconnect()
    if (storageRoot) await rm(storageRoot, { recursive: true, force: true })
  })

  const migrate = async (): Promise<PrismaClient> => {
    storageRoot = await mkdtemp(join(tmpdir(), 'literature-ledger-'))
    client = createProjectDbClient(storageRoot)
    await migrateApplicationDatabase(client)
    return client
  }

  // Every registered migration's checksum matches the one computed from its own contents.
  it('records manifest checksums that re-derive from each migration snapshot', () => {
    for (const entry of MIGRATION_MANIFEST as readonly ManifestEntry[]) {
      const recomputed = checksumMigrationPayload(
        entry.id,
        entry.statements,
        entry.verifiers,
        entry.operations ?? []
      )
      expect(recomputed, `checksum for ${entry.id}`).toBe(entry.checksum)
    }
  })

  // A freshly migrated database records exactly the registered migrations and their checksums.
  it('writes a ledger that matches the in-code migration manifest', async () => {
    const db = await migrate()
    const rows = await db.$queryRawUnsafe<Array<{ id: string; checksum: string }>>(
      'SELECT "id", "checksum" FROM "_open_science_migrations" ORDER BY "id"'
    )
    const manifest = (MIGRATION_MANIFEST as readonly ManifestEntry[]).map((entry) => ({
      id: entry.id,
      checksum: entry.checksum
    }))
    const sortedManifest = [...manifest].sort((a, b) => a.id.localeCompare(b.id))
    expect(rows).toEqual(sortedManifest)
  })

  // A freshly migrated database passes the app's own schema verification.
  it('passes the current runtime schema verification after migrating', async () => {
    const db = await migrate()
    await expect(verifyCurrentApplicationSchema(db)).resolves.toBeUndefined()
  })

  // Applying and re-applying reviewed metadata after migrating leaves the schema exactly as the
  // migrations set it up: nothing is created on the fly outside the migration process.
  it('creates no schema objects outside the migrations when metadata is applied', async () => {
    const db = await migrate()
    await db.project.create({ data: { id: 'migration-ledger-project', name: 'Field' } })
    const migrated = await schemaObjects(db)

    const catalog = new LiteratureCatalog(async () => db)
    const enricher = new LiteratureMetadataEnricher(
      catalog,
      vi.fn(async () => {
        throw new Error('network should not be used')
      }) as unknown as typeof fetch
    )
    const seeded = await catalog.transact({
      kind: 'create-item',
      item: literatureItemInputSchema.parse({
        itemType: 'journalArticle',
        title: 'Field reference',
        identifiers: [{ scheme: 'doi', value: '10.9999/field' }]
      })
    })
    const snapshot = review((await catalog.get(seeded.id))!, 'schema-probe')
    expect((await enricher.applyReviewed(snapshot, [])).mode).toBe('commit')
    expect((await enricher.applyReviewed(snapshot, [])).mode).toBe('commit')

    expect(await schemaObjects(db)).toEqual(migrated)
    await expect(verifyCurrentApplicationSchema(db)).resolves.toBeUndefined()
  })

  // Re-running migrations over a database that already holds data, as an app restart does, keeps
  // that data and the schema still verifies.
  it('preserves existing field data when migrations are re-applied to a populated database', async () => {
    const db = await migrate()
    const catalog = new LiteratureCatalog(async () => db)
    await db.project.create({ data: { id: 'migration-ledger-project', name: 'Field' } })
    const seeded = await catalog.transact({
      kind: 'create-item',
      item: literatureItemInputSchema.parse({
        itemType: 'journalArticle',
        title: 'Field reference',
        identifiers: [{ scheme: 'doi', value: '10.9999/field' }]
      })
    })
    const before = (await catalog.get(seeded.id))!
    const itemsBefore = await db.literatureItem.count()

    await migrateApplicationDatabase(db)

    expect(await db.literatureItem.count()).toBe(itemsBefore)
    expect(await catalog.get(seeded.id)).toEqual(before)
    await expect(verifyCurrentApplicationSchema(db)).resolves.toBeUndefined()
  })
})
