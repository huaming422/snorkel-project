import { randomUUID } from 'node:crypto'
import { mkdtemp, readFile, rm, rename, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, expect, it, vi } from 'vitest'
import {
  literatureItemInputSchema,
  type LiteratureItemView,
  type LiteratureFullTextResult,
  type LiteratureMetadataCompletionResult
} from '../../shared/literature'
import type { LiteratureJob } from '../../shared/literature-jobs'
import { LiteratureBatchJobs } from './batch-jobs'

// Background tasks are driven through the service's request API and its saved checkpoint files,
// the same way the project's own batch-jobs suite does.

const item = (id: string): LiteratureItemView => ({
  id,
  metadataRevision: 1,
  createdAt: 1,
  updatedAt: 1,
  item: literatureItemInputSchema.parse({
    itemType: 'journalArticle',
    title: id,
    identifiers: [{ scheme: 'doi', value: '10.1234/example' }]
  }),
  attachments: [],
  collectionIds: [],
  projectIds: []
})
const preview = (id: string): LiteratureMetadataCompletionResult => ({
  mode: 'preview',
  reviewVersion: 1,
  provider: 'crossref',
  sourceUrl: 'https://crossref.org',
  item: item(id),
  filled: [{ field: 'journal', value: 'Journal' }],
  conflicts: []
})

const cleanup: Array<() => Promise<void>> = []
afterEach(async () => {
  for (const close of cleanup.splice(0).reverse()) await close()
})

async function setup(): Promise<{
  path: string
  jobs: LiteratureBatchJobs
  options: ConstructorParameters<typeof LiteratureBatchJobs>[0]
  metadata: ReturnType<typeof vi.fn>
  fullText: ReturnType<typeof vi.fn>
}> {
  const directory = await mkdtemp(join(tmpdir(), 'literature-jobs-recovery-'))
  cleanup.push(() => rm(directory, { recursive: true, force: true }))
  const metadata = vi.fn(async ({ itemId }: { itemId: string }) => preview(itemId))
  const fullText = vi.fn(async (): Promise<LiteratureFullTextResult> => ({
    mode: 'search',
    candidates: [],
    notices: []
  }))
  const options = {
    path: join(directory, 'jobs.json'),
    catalog: { get: async (id: string) => item(id) },
    metadata: {
      complete: metadata,
      applyReviewed: vi.fn(async (review: LiteratureMetadataCompletionResult) => {
        const current = await options.catalog.get(review.item.id)
        if (!current || current.metadataRevision !== review.item.metadataRevision)
          throw new Error('Reference changed')
        return review
      })
    },
    fullText: { run: fullText },
    onError: vi.fn(),
    spacingMs: 0
  }
  const jobs = new LiteratureBatchJobs(options)
  cleanup.push(() => jobs.close())
  return { path: options.path, jobs, options, metadata, fullText }
}

async function state(jobs: LiteratureBatchJobs, jobId: string): Promise<LiteratureJob> {
  return (await jobs.run({ action: 'get', jobId })).jobs[0]!
}

// Pausing a lookup part way and applying its ready results leaves the task paused and
// searchable, with the unsearched reference still counted.
it('reopens a paused partial search to searchable after applying only the ready rows', async () => {
  const { jobs, metadata, options } = await setup()
  let release!: () => void
  metadata.mockImplementationOnce(async () => {
    await new Promise<void>((resolve) => {
      release = resolve
    })
    return preview('a')
  })
  const jobId = randomUUID()
  await jobs.run({ action: 'create', mode: 'metadata', itemIds: ['a', 'b'], requestId: jobId })
  await vi.waitFor(() => expect(release).toBeTypeOf('function'))
  try {
    await jobs.run({ action: 'pause', jobId })
  } finally {
    release()
  }
  await vi.waitFor(async () => expect((await state(jobs, jobId)).state).toBe('paused'))
  expect((await state(jobs, jobId)).rows.map(({ status }) => status)).toEqual(['ready', 'pending'])

  await jobs.run({ action: 'apply', jobId, selections: [{ itemId: 'a' }] })
  await vi.waitFor(async () => {
    expect(['paused', 'completed']).toContain((await state(jobs, jobId)).state)
  })

  // Only the single ready selection was committed.
  expect(options.metadata.applyReviewed).toHaveBeenCalledOnce()
  // The task stays paused in the search phase, not completed.
  expect(await state(jobs, jobId)).toMatchObject({ state: 'paused', phase: 'search' })
  expect((await state(jobs, jobId)).rows.map(({ status }) => status)).toEqual(['done', 'pending'])
  // The pending reference is counted (checked<total) and surfaced by the summary.
  expect((await jobs.run({ action: 'list' })).summaries?.[0]).toMatchObject({
    total: 2,
    checked: 1,
    done: 1,
    ready: 0,
    failed: 0
  })

  // Resuming finishes the remaining reference without repeating the completed one.
  await jobs.run({ action: 'resume', jobId })
  await vi.waitFor(async () => expect((await state(jobs, jobId)).state).toBe('review'))
  expect(metadata).toHaveBeenCalledTimes(2)
  expect(metadata).toHaveBeenLastCalledWith({ mode: 'preview', itemId: 'b' })
  expect((await state(jobs, jobId)).rows.map(({ status }) => status)).toEqual(['done', 'ready'])
})

// A task saved earlier as Completed while a reference was still unsearched comes back paused and
// searchable when the app loads it.
it('reopens a historically completed checkpoint that still holds a pending row on load', async () => {
  const { jobs, options, path, metadata } = await setup()
  const jobId = randomUUID()
  await jobs.run({ action: 'create', mode: 'metadata', itemIds: ['a'], requestId: jobId })
  await vi.waitFor(async () => expect((await state(jobs, jobId)).state).toBe('review'))
  await jobs.close()

  const checkpoint = join(`${path}.d`, `${jobId}.json`)
  const stored = JSON.parse(await readFile(checkpoint, 'utf8'))
  stored.state = 'completed'
  stored.phase = 'apply'
  stored.phaseItemIds = ['a']
  stored.rows[0].status = 'done'
  stored.rows.push({ id: 'b', status: 'pending', checked: true })
  await writeFile(checkpoint, JSON.stringify(stored))

  const reopened = new LiteratureBatchJobs(options)
  cleanup.push(() => reopened.close())
  // Recovered to a paused, searchable state.
  expect(await state(reopened, jobId)).toMatchObject({ state: 'paused', phase: 'search' })

  metadata.mockClear()
  await reopened.run({ action: 'resume', jobId })
  await vi.waitFor(async () => expect((await state(reopened, jobId)).state).toBe('review'))
  // Only the unfinished reference is searched again; the already-done one is left alone.
  expect(metadata).toHaveBeenCalledExactlyOnceWith({ mode: 'preview', itemId: 'b' })
})

// At the task limit, adding a task removes a finished task, never one with unsearched references.
it('never prunes a completed task that still holds unfinished rows when adding a task', async () => {
  const { options, path } = await setup()
  const finishedIds: string[] = []

  // One completed task that still carries a pending row, unfinished work.
  const pendingBearing: LiteratureJob = {
    id: randomUUID(),
    mode: 'metadata',
    phase: 'apply',
    state: 'completed',
    createdAt: 1,
    updatedAt: 1,
    rows: [
      { id: 'a', status: 'done', checked: true },
      { id: 'b', status: 'pending', checked: true }
    ]
  }
  // Fill the remaining slots up to the threshold with fully done/skipped completed tasks.
  const settled: LiteratureJob[] = []
  for (let i = 0; i < 49; i++) {
    const id = randomUUID()
    finishedIds.push(id)
    settled.push({
      id,
      mode: 'metadata',
      phase: 'apply',
      state: 'completed',
      createdAt: 1,
      updatedAt: 1,
      rows: [{ id: `done-${i}`, status: i % 2 === 0 ? 'done' : 'skipped', checked: true }]
    })
  }
  // The task with unfinished work is the newest one in the list.
  const seeded = [...settled, pendingBearing]
  const { mkdir } = await import('node:fs/promises')
  await mkdir(`${path}.d`, { recursive: true })
  for (const job of seeded) await writeFile(join(`${path}.d`, `${job.id}.json`), JSON.stringify(job))
  await writeFile(path, JSON.stringify({ version: 2, jobIds: seeded.map(({ id }) => id) }))

  const service = new LiteratureBatchJobs(options)
  cleanup.push(() => service.close())

  const added = randomUUID()
  await service.run({ action: 'create', mode: 'metadata', itemIds: ['new'], requestId: added })

  const listed = (await service.run({ action: 'list' })).summaries ?? []
  const ids = listed.map(({ id }) => id)
  // The pending-bearing task survives; the newly added task is present.
  expect(ids).toContain(pendingBearing.id)
  expect(ids).toContain(added)
  // Its pending row is intact and still counted as unfinished.
  const survivor = await state(service, pendingBearing.id)
  expect(survivor.rows.map(({ status }) => status)).toContain('pending')
  // Exactly one fully-finished task was pruned to make room.
  const survivingFinished = finishedIds.filter((id) => ids.includes(id))
  expect(survivingFinished).toHaveLength(48)
})

// Applying results only changes references whose results were ready; a reference still waiting
// for lookup keeps its selection.
it('applies selections to ready rows only and leaves non-ready rows untouched', async () => {
  const { options, path } = await setup()
  const jobId = randomUUID()
  // A paused job whose rows mix a ready row with a non-ready (pending, currently checked) row.
  const seeded: LiteratureJob = {
    id: jobId,
    mode: 'metadata',
    phase: 'search',
    state: 'paused',
    createdAt: 1,
    updatedAt: 1,
    rows: [
      { id: 'a', status: 'ready', checked: false, item: item('a'), metadata: preview('a') },
      { id: 'b', status: 'pending', checked: true }
    ]
  }
  const { mkdir } = await import('node:fs/promises')
  await mkdir(`${path}.d`, { recursive: true })
  await writeFile(join(`${path}.d`, `${jobId}.json`), JSON.stringify(seeded))
  await writeFile(path, JSON.stringify({ version: 2, jobIds: [jobId] }))

  const service = new LiteratureBatchJobs(options)
  cleanup.push(() => service.close())

  // Apply selecting only the ready row.
  await service.run({ action: 'apply', jobId, selections: [{ itemId: 'a' }] })
  await vi.waitFor(async () => {
    const rows = (await state(service, jobId)).rows
    expect(rows.find(({ id }) => id === 'a')!.status).toBe('done')
  })

  const rows = (await state(service, jobId)).rows
  // The ready row was applied and checked.
  expect(rows.find(({ id }) => id === 'a')).toMatchObject({ status: 'done', checked: true })
  // The non-ready row keeps its status and its prior checked flag.
  expect(rows.find(({ id }) => id === 'b')).toMatchObject({ status: 'pending', checked: true })
})

// A task list that failed to load is read again on the next request once the file is back, and
// requests made while it is broken all fail without touching the saved index.
it('retries a repaired checkpoint load and shares one in-flight load across concurrent requests', async () => {
  const { jobs, options, path } = await setup()
  const first = randomUUID()
  const second = randomUUID()
  for (const jobId of [first, second]) {
    await jobs.run({ action: 'create', mode: 'metadata', itemIds: ['a'], requestId: jobId })
    await vi.waitFor(async () => expect((await state(jobs, jobId)).state).toBe('review'))
  }
  await jobs.close()

  const indexBefore = await readFile(path, 'utf8')
  const checkpoint = join(`${path}.d`, `${first}.json`)
  // Hide one task file so loading fails.
  await rename(checkpoint, `${checkpoint}.saved`)

  const reopened = new LiteratureBatchJobs(options)
  cleanup.push(() => reopened.close())

  // Requests made while the task file is missing all fail and leave the saved index untouched.
  const blocked = await Promise.allSettled([
    reopened.run({ action: 'list' }),
    reopened.run({ action: 'get', jobId: second }),
    reopened.run({ action: 'remove', jobId: second })
  ])
  expect(blocked.map((result) => result.status)).toEqual(['rejected', 'rejected', 'rejected'])
  expect(await readFile(path, 'utf8')).toBe(indexBefore)

  // Put the file back; the next request on the same service succeeds.
  await rename(`${checkpoint}.saved`, checkpoint)
  await expect(reopened.run({ action: 'list' })).resolves.toMatchObject({
    summaries: [{ id: second }, { id: first }]
  })
  expect((await state(reopened, second)).state).toBe('review')
  await reopened.run({ action: 'remove', jobId: second })
  expect((await reopened.run({ action: 'list' })).summaries?.map(({ id }) => id)).toEqual([first])
})
