// @vitest-environment jsdom
import { act, cleanup, fireEvent, render, screen } from '@testing-library/react'
import { StrictMode } from 'react'
import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import {
  literatureItemInputSchema,
  type LiteratureItemView
} from '../../../../shared/literature'
import type {
  LiteratureJob,
  LiteratureJobRequest,
  LiteratureJobSummary
} from '../../../../shared/literature-jobs'
import { LiteratureBackgroundTasks } from './LiteratureBackgroundTasks'
import { LiteratureBatchLookupDialog } from './LiteratureBatchLookupDialog'

// Renderer behavior is observed through rendered output and the window.api.literature client the
// components already call.

afterEach(cleanup)

const summary: LiteratureJobSummary = {
  id: 'job',
  mode: 'metadata',
  phase: 'search',
  state: 'running',
  total: 3,
  checked: 1,
  ready: 1,
  done: 0,
  failed: 0,
  createdAt: 1,
  updatedAt: 1
}

async function showTasks(summaries: LiteratureJobSummary[]): Promise<void> {
  Object.defineProperty(window, 'api', {
    configurable: true,
    value: { literature: { jobs: vi.fn(async () => ({ jobs: [], summaries })) } }
  })
  await act(async () => {
    render(<LiteratureBackgroundTasks onOpen={vi.fn()} />)
  })
}

// A fully finished task does not keep the Background Tasks button on screen.
it('still hides a fully finished completed task', async () => {
  await showTasks([{ ...summary, state: 'completed', total: 3, checked: 3, ready: 0, done: 3 }])
  expect(screen.queryByRole('button', { name: 'Background tasks' })).toBeNull()
})

// ---- Review dialog overlay / retire ----

const item: LiteratureItemView = {
  id: 'first',
  metadataRevision: 1,
  createdAt: 1,
  updatedAt: 1,
  attachments: [],
  projectIds: [],
  collectionIds: [],
  item: literatureItemInputSchema.parse({ itemType: 'journalArticle', title: 'First paper' })
}
const id = '9323d39a-2ae2-49c8-8826-a589c78f1f5d'
let job: LiteratureJob
const jobs = vi.fn<(request: LiteratureJobRequest) => Promise<{ jobs: LiteratureJob[] }>>(
  async () => ({ jobs: [structuredClone(job)] })
)
const flush = async (): Promise<void> => {
  await act(async () => {
    await vi.advanceTimersByTimeAsync(1001)
  })
}

beforeEach(() => {
  vi.useFakeTimers()
  vi.clearAllMocks()
  jobs.mockImplementation(async (request) => {
    if (request.action === 'review') {
      for (const selection of request.selections)
        Object.assign(job.rows.find(({ id }) => id === selection.itemId)!, selection)
      job.updatedAt += 1
    }
    return { jobs: [structuredClone(job)] }
  })
  job = {
    id,
    mode: 'metadata',
    phase: 'search',
    state: 'running',
    createdAt: 1,
    updatedAt: 1,
    rows: [{ id: item.id, item, checked: true, status: 'searching' }]
  }
  Object.defineProperty(window, 'api', { configurable: true, value: { literature: { jobs } } })
})
afterEach(() => {
  cleanup()
  vi.useRealTimers()
})

const open = (jobId?: string, mode: 'metadata' | 'full-text' = 'metadata'): void => {
  render(
    <StrictMode>
      <LiteratureBatchLookupDialog
        itemIds={[item.id]}
        initialItems={[item]}
        mode={mode}
        jobId={jobId}
        fieldLabel={(field) => field}
        onClose={vi.fn()}
        onChanged={vi.fn()}
      />
    </StrictMode>
  )
}

// A review window with no unsaved changes of its own shows a selection change another window
// saved, and applies what it shows.
it('adopts another window saved deselection when this window has no pending draft', async () => {
  job.state = 'review'
  job.rows[0]!.status = 'ready'
  job.rows.push({
    id: 'second',
    item: { ...item, id: 'second', item: { ...item.item, title: 'Second paper' } },
    checked: true,
    status: 'ready'
  })
  open(id)
  await flush()
  expect(
    (screen.getByRole('checkbox', { name: 'Select reference: First paper' }) as HTMLInputElement)
      .checked
  ).toBe(true)

  // Another window saves a deselection of the first row.
  job.rows[0]!.checked = false
  job.updatedAt += 1
  fireEvent(window, new Event('literature-job-refresh'))
  await act(async () => {})

  // This window, holding no pending draft of its own, reflects the saved deselection.
  expect(
    (screen.getByRole('checkbox', { name: 'Select reference: First paper' }) as HTMLInputElement)
      .checked
  ).toBe(false)

  fireEvent.click(screen.getByRole('button', { name: /Apply metadata/ }))
  await act(async () => {})
  expect(jobs).toHaveBeenLastCalledWith({
    action: 'apply',
    jobId: id,
    selections: [{ itemId: 'second', candidateId: undefined }]
  })
})

// After an apply fails here and another window saves different choices, retrying here does not
// send the old apply again.
it('retires a failed apply selection when another window saves a different review', async () => {
  job.state = 'review'
  job.rows[0]!.status = 'ready'
  jobs.mockImplementation(async (request) => {
    if (request.action === 'apply') throw new Error('checkpoint unavailable')
    return { jobs: [structuredClone(job)] }
  })
  open(id)
  await flush()
  fireEvent.click(screen.getByRole('button', { name: 'Apply metadata (1)' }))
  await act(async () => {})
  expect(screen.getByRole('alert')).toBeTruthy()

  // Another window saves a deselection, invalidating the failed apply's selection.
  job.rows[0]!.checked = false
  job.updatedAt += 1
  fireEvent(window, new Event('literature-job-refresh'))
  await act(async () => {})

  expect((screen.getByRole('checkbox') as HTMLInputElement).checked).toBe(false)
  const retry = screen.queryByRole('button', { name: 'Retry' })
  if (retry) fireEvent.click(retry)
  await act(async () => {})
  // The retired request is not resent: only the single original apply call was ever made.
  expect(jobs.mock.calls.filter(([request]) => request.action === 'apply')).toHaveLength(1)
})
