#!/usr/bin/env bash
# Verifier-time setup for open-science-fix-literature-task-recovery.
#
# The image bakes the full dependency closure at the base commit: `npm ci` runs twice in the build
# (seed warm + deps), and postinstall runs `prisma generate` + `electron-builder install-app-deps`,
# so node_modules, the Prisma engines, and the generated client are all present offline. The oracle
# introduces NO new npm dependency. The one thing that must be refreshed at verify time is the
# generated Prisma client, because the solution edits prisma/schema.prisma and the pretest hook
# (scripts/check-prisma-client.mjs) fingerprints the schema against the generated client.
#
# This runs with network available (verifier phase, allowlist). It regenerates the Prisma client
# offline from the baked engines; a logged online fallback covers a cold engine cache.
set -euo pipefail

REPO=/repo/open-science
cd "$REPO"

# prisma generate reads the schema and emits client code from the engine binaries already baked into
# node_modules by the image's postinstall; it needs no network. The online retry is only a logged
# safety net for a cold engine cache and is never expected to fire in the offline agent phase.
echo "[test-setup] regenerating Prisma client (offline-first)"
if npx prisma generate > /tmp/prisma-generate.log 2>&1; then
  echo "[test-setup] prisma generate: ok"
else
  echo "[test-setup] prisma generate failed; log:" >&2
  tail -40 /tmp/prisma-generate.log >&2 || true
  exit 1
fi

echo "[test-setup] done"
