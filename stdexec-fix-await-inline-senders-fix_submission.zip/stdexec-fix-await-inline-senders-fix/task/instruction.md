## Task

the library's coroutine task type (`ex::task<T>` from `<exec/task.hpp>`, with `namespace ex = std::execution`) lets you `co_await` senders. it falls over when a coroutine awaits a lot of cheap, synchronously-completing senders back to back.

smallest reproducer is a `task<int>` whose body is

```cpp
int sum = 0;
for (int i = 0; i < 1'000'000; ++i)
    sum += co_await ex::just(42);
co_return sum;
```

driven with `ex::sync_wait(...)`. instead of returning the sum, the process dies with a stack overflow.

it's specific to many chained synchronous awaits in one coroutine. drop the count to a few thousand and it runs fine; individual and non-looping awaits are fine. awaiting isn't broken, the stack cost grows with each back-to-back synchronous await, and a million blows the stack.

make these coroutines run to completion without the stack growing without bound, so the reproducer returns its result. awaits that genuinely complete asynchronously should keep behaving as they do now.

the library is header-only; its source at `/repo/stdexec` is already configured and built under `/repo/stdexec/build`, so rebuilds are incremental. you work offline, everything the build needs is here.
