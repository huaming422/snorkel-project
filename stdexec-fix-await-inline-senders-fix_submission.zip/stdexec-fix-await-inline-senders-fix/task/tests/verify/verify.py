"""Behavioral verifier for stdexec-fix-await-inline-senders.

Tests through the library's PUBLIC coroutine surface only — define an
``ex::task<T>`` coroutine, ``co_await`` senders inside it, and drive it with
``ex::sync_wait``. Nothing here inspects an internal symbol
(``__sender_awaitable``, ``__completes_inline``, the receiver split, the
``await_suspend`` return type, …) or a file path the fix might live in. Any
valid fix that keeps the stack flat across a long run of statically-inline
awaits passes, regardless of how it is named, factored, or which detail
header it edits (see the task's ``alternative_implementations``).

Mechanism: each test writes a small standalone C++20 program, compiles it
against the agent-patched headers under ``/repo/stdexec/include`` with the
project's own namespace flag, and runs it. The million-iteration loops run on
a worker thread with a deliberately small, fixed stack (512 KiB) so that the
pre-fix O(n) stack growth is guaranteed to overflow (the process dies with a
signal) while a correct flat-stack fix finishes with comfortable head-room.

The verifier is self-contained: it imports no project-internal Python and
does not depend on any repo test-harness layout. It shells out to ``g++-12``
only, so it needs no ``[pytest] command`` override — it runs under the
canonical verifier interpreter (``VERIFIER_PYTHON``).
"""

from __future__ import annotations

import glob
import os
import subprocess
import tempfile

import pytest


# ── Toolchain / repo constants (stable facts) ──────────────────────────────
#
# Provenance:
#  - ``g++-12``: the task image installs gcc-12/g++-12 as the distro compiler
#    (stdexec requires GCC >= 12). Stable fact (Dockerfile §1).
#  - ``-std=c++20``: the library is a C++20 header-only library; GCC 12 has
#    coroutines on by default under this flag. Stable fact.
#  - ``-DSTDEXEC_NAMESPACE=std::execution``: the project build and its own
#    tests compile with this, so ``std::execution`` is the real namespace the
#    headers populate; a standalone program must match. Stable fact
#    (blueprint §"Namespace / API facts").
#  - ``/repo/stdexec/include``: fixed header-only source location. Stable fact.
#  - ``-lpthread``: the bounded-stack worker uses POSIX threads. Stable fact.
CXX = os.environ.get("STDEXEC_CXX", "g++-12")
REPO = os.environ.get("STDEXEC_REPO", "/repo/stdexec")
INCLUDE = f"{REPO}/include"
BUILD = f"{REPO}/build"

CXX_FLAGS = [
    "-std=c++20",
    "-DSTDEXEC_NAMESPACE=std::execution",
    f"-I{INCLUDE}",
]
LINK_FLAGS = ["-lpthread"]

# Compiling template-heavy stdexec translation units dominates each test's
# wall-clock; the loops themselves run in well under a second post-fix (and
# crash early pre-fix). These budgets leave generous head-room on a slow CI
# runner while staying far inside the 1200 s verifier timeout and the 20 min
# full-stack budget.
COMPILE_TIMEOUT = 300
RUN_TIMEOUT = 120

# The pure ``sum = 0; 1,000,000 × (sum += 42)`` loops total 42,000,000. (The
# PR's own regression test asserts 42,000,042 only because it prepends one
# ``co_await nested()`` == 42 before the loop; we use the pure loop and keep
# the asserted constant consistent with it.)
EXPECTED_SUM_1M = 42_000_000

# Bounded worker-thread stack. Large enough that a correct O(1)-stack fix
# finishes comfortably, small enough that the pre-fix O(n) growth overflows
# long before a million frames. Empirically validated: pre-fix overflows
# (SIGSEGV) and the fixed headers exit cleanly at this size.
WORKER_STACK_BYTES = 512 * 1024


# ── C++ programs (public-surface only) ─────────────────────────────────────

# Criterion 1 — headline fail_to_pass. A million inline-completing awaits of
# ``just(42)`` in one task frame, driven by sync_wait on a 512 KiB stack.
PROG_HEADLINE = r"""
#include <exec/task.hpp>
#include <stdexec/execution.hpp>
#include <cstdio>
#include <pthread.h>
namespace ex = std::execution;

static long g_result = -999;

ex::task<int> loop_just() {
  int sum = 0;
  for (int i = 0; i < 1000000; ++i)
    sum += co_await ex::just(42);
  co_return sum;
}

static void* worker(void*) {
  auto r = ex::sync_wait(loop_just());
  g_result = r ? (long)std::get<0>(*r) : -2;
  return nullptr;
}

int main() {
  pthread_attr_t attr;
  pthread_attr_init(&attr);
  pthread_attr_setstacksize(&attr, %(stack)d);
  pthread_t t;
  if (pthread_create(&t, &attr, worker, nullptr) != 0) { std::printf("spawn-fail\n"); return 3; }
  pthread_join(t, nullptr);
  pthread_attr_destroy(&attr);
  std::printf("result=%%ld\n", g_result);
  return g_result == %(expected)d ? 0 : 1;
}
""" % {"stack": WORKER_STACK_BYTES, "expected": EXPECTED_SUM_1M}

# Criterion 2 — generality fail_to_pass. Same million-await loop but over a
# DIFFERENT inline-completing sender factory: ``read_env(get_scheduler)``. A
# fix special-cased to ``just`` still overflows here; only a fix that keys off
# the sender's static completion behavior keeps this flat. (``just | then``
# and ``let_value`` are NOT used here — they do not overflow pre-fix through
# the task path, so they would not separate a just-only shortcut from a
# general fix.)
PROG_GENERALITY = r"""
#include <exec/task.hpp>
#include <stdexec/execution.hpp>
#include <cstdio>
#include <pthread.h>
namespace ex = std::execution;

static long g_result = -999;

ex::task<int> loop_readenv() {
  int sum = 0;
  for (int i = 0; i < 1000000; ++i) {
    co_await ex::read_env(ex::get_scheduler);
    sum += 42;
  }
  co_return sum;
}

static void* worker(void*) {
  auto r = ex::sync_wait(loop_readenv());
  g_result = r ? (long)std::get<0>(*r) : -2;
  return nullptr;
}

int main() {
  pthread_attr_t attr;
  pthread_attr_init(&attr);
  pthread_attr_setstacksize(&attr, %(stack)d);
  pthread_t t;
  if (pthread_create(&t, &attr, worker, nullptr) != 0) { std::printf("spawn-fail\n"); return 3; }
  pthread_join(t, nullptr);
  pthread_attr_destroy(&attr);
  std::printf("result=%%ld\n", g_result);
  return g_result == %(expected)d ? 0 : 1;
}
""" % {"stack": WORKER_STACK_BYTES, "expected": EXPECTED_SUM_1M}

# Criterion 3a — pass_to_pass. A handful of ordinary inline awaits still
# return the right value (0+1+2+3+4 = 10). Guards a fix that flattens the
# stack but corrupts the short-loop value path.
PROG_SMALL = r"""
#include <exec/task.hpp>
#include <stdexec/execution.hpp>
#include <cstdio>
namespace ex = std::execution;

ex::task<int> small() {
  int s = 0;
  for (int i = 0; i < 5; ++i) s += co_await ex::just(i);
  co_return s;
}

int main() {
  auto r = ex::sync_wait(small());
  long v = r ? (long)std::get<0>(*r) : -1;
  std::printf("small=%ld\n", v);
  return v == 10 ? 0 : 1;
}
"""

# Criterion 3b — pass_to_pass. An awaited sender that completes with an error
# must still surface that error as an exception out of ``sync_wait``; the
# flattening fix must not swallow errors. Prints the caught message so the
# test asserts the actual error value, not a boolean.
PROG_ERROR = r"""
#include <exec/task.hpp>
#include <stdexec/execution.hpp>
#include <cstdio>
#include <stdexcept>
namespace ex = std::execution;

ex::task<int> errtask() {
  int x = co_await (ex::just() | ex::then([]() -> int { throw std::runtime_error("boom"); }));
  co_return x;
}

int main() {
  try {
    auto r = ex::sync_wait(errtask());
    std::printf("NO-EXCEPTION has-value=%d\n", (int)(bool)r);
    return 1;  // the error should have propagated as an exception
  } catch (const std::runtime_error& e) {
    std::printf("caught=%s\n", e.what());
    return 0;
  } catch (...) {
    std::printf("caught=other\n");
    return 0;
  }
}
"""


# ── Compile / run helpers ──────────────────────────────────────────────────


def _compile(source: str, stem: str, workdir: str) -> str:
    """Compile *source* against the agent-patched headers; return binary path.

    A compile failure is a real test failure (the agent's header edit must
    leave the public coroutine surface usable), surfaced with the compiler's
    stderr tail.
    """
    src_path = os.path.join(workdir, f"{stem}.cpp")
    bin_path = os.path.join(workdir, stem)
    with open(src_path, "w") as f:
        f.write(source)

    cmd = [CXX, *CXX_FLAGS, src_path, "-o", bin_path, *LINK_FLAGS]
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=COMPILE_TIMEOUT, check=False
        )
    except subprocess.TimeoutExpired:
        pytest.fail(
            f"compiling {stem}.cpp exceeded {COMPILE_TIMEOUT}s against "
            f"{INCLUDE} — the patched headers compile far too slowly."
        )
    assert proc.returncode == 0, (
        f"{stem}.cpp failed to compile against the patched headers "
        f"(exit {proc.returncode}). The fix must keep the public "
        f"task/co_await/sync_wait surface compilable.\n"
        f"--- compiler stderr (tail) ---\n{proc.stderr[-3000:]}"
    )
    assert os.path.isfile(bin_path), f"{stem}: compiler produced no binary"
    return bin_path


def _run(bin_path: str, stem: str) -> subprocess.CompletedProcess:
    try:
        return subprocess.run(
            [bin_path], capture_output=True, text=True, timeout=RUN_TIMEOUT, check=False
        )
    except subprocess.TimeoutExpired:
        pytest.fail(
            f"{stem} did not terminate within {RUN_TIMEOUT}s — a correct fix "
            f"completes the loop near-instantly; a hang indicates the fix "
            f"stalled the coroutine."
        )


# ── Tests ──────────────────────────────────────────────────────────────────


def test_criterion1_million_inline_just_awaits_flat_stack():
    """Criterion 1 (fail_to_pass, headline).

    A ``task<int>`` that awaits one million ``just(42)`` senders in a loop,
    driven by ``sync_wait`` on a 512 KiB worker stack, must run to completion
    and return 42,000,000. Pre-fix the inline completions resume the awaiting
    coroutine from inside ``await_suspend``, nesting a frame per await, so the
    bounded stack overflows and the process is killed by a signal (non-zero
    exit). Post-fix the stack stays flat and the program exits 0.
    """
    with tempfile.TemporaryDirectory(prefix="stdexec-verify-") as wd:
        binary = _compile(PROG_HEADLINE, "headline", wd)
        proc = _run(binary, "headline")
        assert proc.returncode == 0, (
            f"the million-await loop did not complete under a {WORKER_STACK_BYTES}-byte "
            f"stack (exit {proc.returncode}). A negative/139 code means the stack "
            f"overflowed — the inline awaits are still nesting a resume frame per "
            f"iteration instead of continuing on the normal return path.\n"
            f"stdout: {proc.stdout!r}\nstderr: {proc.stderr[-800:]!r}"
        )
        assert f"result={EXPECTED_SUM_1M}" in proc.stdout, (
            f"expected 'result={EXPECTED_SUM_1M}', got stdout {proc.stdout!r} — the "
            f"loop completed but produced the wrong sum."
        )


def test_criterion2_generality_non_just_inline_sender():
    """Criterion 2 (fail_to_pass, generality).

    The same million-iteration loop over a DIFFERENT inline-completing sender
    (``read_env(get_scheduler)``) must also stay flat. A fix hard-coded to
    ``just`` leaves this sender recursing and the bounded stack still
    overflows; only a fix that detects inline completion from the sender's
    static completion behavior passes both this and Criterion 1.
    """
    with tempfile.TemporaryDirectory(prefix="stdexec-verify-") as wd:
        binary = _compile(PROG_GENERALITY, "generality", wd)
        proc = _run(binary, "generality")
        assert proc.returncode == 0, (
            f"the million-await loop over read_env(get_scheduler) did not complete "
            f"under a {WORKER_STACK_BYTES}-byte stack (exit {proc.returncode}). This "
            f"is the generality check: a just-only special case still overflows here.\n"
            f"stdout: {proc.stdout!r}\nstderr: {proc.stderr[-800:]!r}"
        )
        assert f"result={EXPECTED_SUM_1M}" in proc.stdout, (
            f"expected 'result={EXPECTED_SUM_1M}', got stdout {proc.stdout!r}."
        )


def test_criterion3a_small_count_awaits_return_value():
    """Criterion 3a (pass_to_pass, semantics).

    A short loop of ordinary inline awaits returns the correct value both
    before and after the fix. Guards against a flattening change that breaks
    the value path for the common small-count case.
    """
    with tempfile.TemporaryDirectory(prefix="stdexec-verify-") as wd:
        binary = _compile(PROG_SMALL, "small", wd)
        proc = _run(binary, "small")
        assert proc.returncode == 0 and "small=10" in proc.stdout, (
            f"a 5-await task<int> must return 10; got exit {proc.returncode}, "
            f"stdout {proc.stdout!r}."
        )


def test_criterion3b_error_propagates_as_exception():
    """Criterion 3b (pass_to_pass, semantics).

    An awaited sender that completes with an error must still surface that
    error as an exception out of ``sync_wait`` — the fix must not swallow
    errors while flattening the stack. Holds before and after the fix.
    """
    with tempfile.TemporaryDirectory(prefix="stdexec-verify-") as wd:
        binary = _compile(PROG_ERROR, "error", wd)
        proc = _run(binary, "error")
        assert proc.returncode == 0 and "caught=boom" in proc.stdout, (
            f"an error-completing awaited sender must propagate as an exception "
            f"out of sync_wait; expected 'caught=boom', got exit {proc.returncode}, "
            f"stdout {proc.stdout!r}."
        )


def test_criterion4_existing_task_suite_still_passes():
    """Criterion 4 (pass_to_pass, existing suite).

    The project's own Catch2 ``[types][task]`` cases (scheduler affinity,
    stopped propagation, allocator handling, awaiting just/just_error/
    just_stopped) must still pass after the agent's edit. ``test-setup.sh``
    has already (re)built ``test.stdexec`` against the patched headers; here
    we locate that binary and run only the ``[task]`` tag.
    """
    candidates = glob.glob(f"{BUILD}/**/test.stdexec", recursive=True)
    candidates = [c for c in candidates if os.access(c, os.X_OK)]
    assert candidates, (
        f"could not find an executable test.stdexec under {BUILD}; the "
        f"pre-configured test tree should have been (re)built by test-setup.sh."
    )
    binary = candidates[0]
    try:
        proc = subprocess.run(
            [binary, "[task]"],
            capture_output=True,
            text=True,
            timeout=RUN_TIMEOUT,
            cwd=BUILD,
            check=False,
        )
    except subprocess.TimeoutExpired:
        pytest.fail(f"existing [task] suite exceeded {RUN_TIMEOUT}s")
    assert proc.returncode == 0, (
        f"the existing [types][task] Catch2 cases regressed after the fix "
        f"(exit {proc.returncode}).\n"
        f"stdout (tail): {proc.stdout[-2000:]}\nstderr (tail): {proc.stderr[-800:]}"
    )
