#!/usr/bin/env bash
# test-setup.sh — sourced before the verifier runs.
#
# stdexec is a header-only C++20 library; the agent's fix edits headers under
# /repo/stdexec/include. There is nothing to "rebuild" for the library itself —
# consumers just recompile against the patched headers. This script does two
# things:
#   1. Confirms the patched headers still parse / configure cleanly, by running
#      an incremental reconfigure+build of the pre-configured test tree. Because
#      the library is header-only, only translation units that include the
#      touched headers recompile, so this is fast.
#   2. Leaves the build tree ready so the verifier can compile its own standalone
#      programs against /repo/stdexec/include and (optionally) run the project's
#      own task tests.
#
# Runs offline. All dependencies (Catch2, rapids-cmake) were fetched into
# /repo/stdexec/build/_deps at image-build time; no network is used here.
set -euo pipefail

REPO=/repo/stdexec
BUILD="${REPO}/build"

cd "${REPO}"

echo "test-setup: incremental reconfigure + build of the test tree..."
# The build dir was configured at image-build time with
# -DSTDEXEC_BUILD_TESTS=ON and the CPM deps are warm under build/_deps, so this
# reconfigure needs no network. Rebuild the task-focused test target; the
# header-only edit only recompiles the TUs that include the changed headers.
if [ -d "${BUILD}" ]; then
  # Reconfigure is cheap and picks up nothing new for a header-only edit, but
  # keeps CMake's view of the tree consistent. Build the full test target so
  # the verifier can run the project's own task cases if it chooses to.
  cmake --build "${BUILD}" --target test.stdexec > /tmp/test-setup-build.log 2>&1 || {
    echo "test-setup: test.stdexec build failed; tail of log:" >&2
    tail -120 /tmp/test-setup-build.log >&2
    exit 1
  }
else
  echo "test-setup: ${BUILD} missing — reconfiguring from scratch (offline)..." >&2
  cmake -S "${REPO}" -B "${BUILD}" -DCMAKE_BUILD_TYPE=Release -DSTDEXEC_BUILD_TESTS=ON \
    > /tmp/test-setup-configure.log 2>&1 || {
      echo "test-setup: configure failed; tail of log:" >&2
      tail -120 /tmp/test-setup-configure.log >&2
      exit 1
    }
  cmake --build "${BUILD}" --target test.stdexec > /tmp/test-setup-build.log 2>&1 || {
    echo "test-setup: test.stdexec build failed; tail of log:" >&2
    tail -120 /tmp/test-setup-build.log >&2
    exit 1
  }
fi

# Sanity: the patched headers must at least parse as a standalone compile unit.
# This catches a syntax error in the agent's edit before the verifier's own
# programs try to use them.
echo "test-setup: header syntax sanity compile..."
SANITY_SRC=$(mktemp /tmp/stdexec-sanity-XXXX.cpp)
cat > "${SANITY_SRC}" <<'CPP'
#include <exec/task.hpp>
#include <stdexec/execution.hpp>
namespace ex = std::execution;
ex::task<int> __sanity() { co_return co_await ex::just(1); }
int main() { return 0; }
CPP
if ! g++-12 -std=c++20 -DSTDEXEC_NAMESPACE=std::execution \
      -I"${REPO}/include" "${SANITY_SRC}" -o /tmp/stdexec-sanity \
      > /tmp/test-setup-sanity.log 2>&1; then
  echo "test-setup: patched headers failed to compile a standalone program:" >&2
  tail -120 /tmp/test-setup-sanity.log >&2
  rm -f "${SANITY_SRC}"
  exit 1
fi
rm -f "${SANITY_SRC}"

echo "test-setup: ready."
