// External-package (embeddeddolt_test) behavioral tests over the exported
// EmbeddedDoltStore. Every assertion goes through pre-existing, stable store
// methods — CreateIssue, AddDependency / AddDependencyWithOptions, CloseIssue,
// ReopenIssue, RemoveDependency, GetReadyWork, IsBlockedBatch, RunInTransaction,
// and the BlockedRecomputer capability. Internal helpers touched by this change
// are deliberately never named, so any behaviourally-correct restructuring of
// the blocked-state propagation passes unchanged.
//
// The store runs the embedded Dolt engine in-process over cgo, so these tests
// need the cgo build and compile only under it.

//go:build cgo

package embeddeddolt_test

import (
	"context"
	"errors"
	"sort"
	"testing"

	"github.com/steveyegge/beads/internal/storage"
	"github.com/steveyegge/beads/internal/types"
	"github.com/steveyegge/beads/issueops"
)

// mkIssue creates one open, permanent task through the store.
func mkIssue(t *testing.T, ctx context.Context, te *testEnv, id string) {
	t.Helper()
	err := te.store.CreateIssue(ctx, &types.Issue{
		ID:        id,
		Title:     id,
		Status:    types.StatusOpen,
		Priority:  2,
		IssueType: types.TypeTask,
	}, "tester")
	if err != nil {
		t.Fatalf("create issue %s: %v", id, err)
	}
}

// addEdge adds a dependency edge through the normal store write path (cycle and
// hierarchy guards active).
func addEdge(t *testing.T, ctx context.Context, te *testEnv, issueID, dependsOnID string, depType types.DependencyType) {
	t.Helper()
	err := te.store.AddDependency(ctx, &types.Dependency{
		IssueID:     issueID,
		DependsOnID: dependsOnID,
		Type:        depType,
	}, "tester")
	if err != nil {
		t.Fatalf("add dep %s -> %s (%s): %v", issueID, dependsOnID, depType, err)
	}
}

// addEdgeSkippingCycleCheck adds an edge that deliberately closes a loop — the
// only way to build the "epic blocks on its own children" shape, since the epic
// already depends on children it is then re-parented beneath. The transaction
// surface is the one that honours SkipCycleCheck; the store-level call builds
// its own options and does not.
func addEdgeSkippingCycleCheck(t *testing.T, ctx context.Context, te *testEnv, issueID, dependsOnID string, depType types.DependencyType) {
	t.Helper()
	err := te.store.RunInTransaction(ctx, "test: seed close-gate edge", func(tx storage.Transaction) error {
		return tx.AddDependencyWithOptions(ctx,
			&types.Dependency{IssueID: issueID, DependsOnID: dependsOnID, Type: depType},
			"tester", storage.DependencyAddOptions{SkipCycleCheck: true})
	})
	if err != nil {
		t.Fatalf("add dep (skip cycle) %s -> %s (%s): %v", issueID, dependsOnID, depType, err)
	}
}

// readySet returns the set of issue IDs the store reports as ready-to-work.
func readySet(t *testing.T, ctx context.Context, te *testEnv) map[string]bool {
	t.Helper()
	ready, err := te.store.GetReadyWork(ctx, types.WorkFilter{Status: types.StatusOpen})
	if err != nil {
		t.Fatalf("GetReadyWork: %v", err)
	}
	set := map[string]bool{}
	for _, issue := range ready {
		set[issue.ID] = true
	}
	return set
}

// blockedFlags returns the stored is-blocked projection for the given ids.
func blockedFlags(t *testing.T, ctx context.Context, te *testEnv, ids ...string) map[string]bool {
	t.Helper()
	got, err := te.store.IsBlockedBatch(ctx, ids)
	if err != nil {
		t.Fatalf("IsBlockedBatch: %v", err)
	}
	return got
}

// seedCloseGate builds the regression shape: epic P that blocks on its own two
// children C1,C2 (so P cannot close until they finish), with C1,C2 parented
// under P. The blocks edges go in before the hierarchy exists; the parent-child
// edges close the gate. Returns the ids. Leaves the working set committed.
func seedCloseGate(t *testing.T, ctx context.Context, te *testEnv, p, c1, c2 string) {
	t.Helper()
	mkIssue(t, ctx, te, p)
	mkIssue(t, ctx, te, c1)
	mkIssue(t, ctx, te, c2)
	addEdge(t, ctx, te, p, c1, types.DepBlocks)
	addEdge(t, ctx, te, p, c2, types.DepBlocks)
	addEdgeSkippingCycleCheck(t, ctx, te, c1, p, types.DepParentChild)
	addEdgeSkippingCycleCheck(t, ctx, te, c2, p, types.DepParentChild)
}

// recomputeAllBlocked runs a full repair of the is-blocked projection and
// returns how many rows it had to correct. The full repair refuses a dirty
// working set, so commit the staged writes first (matching the store's own
// recompute precondition).
func recomputeAllBlocked(t *testing.T, ctx context.Context, te *testEnv) int {
	t.Helper()
	if err := te.store.Commit(ctx, "seed consistent graph"); err != nil {
		t.Fatalf("commit before recompute: %v", err)
	}
	rc, ok := storage.UnwrapStore(te.store).(storage.BlockedRecomputer)
	if !ok {
		t.Fatalf("store does not expose BlockedRecomputer")
	}
	changed, err := rc.RecomputeAllBlocked(ctx)
	if err != nil {
		t.Fatalf("RecomputeAllBlocked: %v", err)
	}
	return changed
}

// TestReadyChildrenUnderCloseGate: an epic that blocks only on items inside its
// own subtree must not darken those children. Its children stay workable and the
// epic itself is the only thing held back. This is the reported regression — the
// whole subtree under such an epic went dark and never recovered.
func TestReadyChildrenUnderCloseGate(t *testing.T) {
	te := newTestEnv(t, "cg")
	ctx := t.Context()

	seedCloseGate(t, ctx, te, "cg-p", "cg-c1", "cg-c2")

	ready := readySet(t, ctx, te)
	for _, child := range []string{"cg-c1", "cg-c2"} {
		if !ready[child] {
			t.Errorf("%s missing from ready work: the children of a close-gate epic must stay workable", child)
		}
	}
	if ready["cg-p"] {
		t.Error("cg-p is ready, but it genuinely blocks on two open children")
	}

	flags := blockedFlags(t, ctx, te, "cg-p", "cg-c1", "cg-c2")
	if !flags["cg-p"] {
		t.Error("cg-p should report blocked: it depends on two open children")
	}
	if flags["cg-c1"] || flags["cg-c2"] {
		t.Errorf("close-gate children must not be blocked: cg-c1=%v cg-c2=%v", flags["cg-c1"], flags["cg-c2"])
	}
}

// TestReadyGrandchildUnderCloseGate: the close gate can sit over a grandchild,
// not just a direct child. P blocks on G, and G lives two parent-child levels
// below P (under child C). Nothing under P — including the grandchild G whose
// completion would free P — may be darkened. This rejects a narrow fix that only
// recognises the flat "parent blocks its own direct children" shape, and forces
// the membership decision to span more than one hierarchy level.
func TestReadyGrandchildUnderCloseGate(t *testing.T) {
	te := newTestEnv(t, "gc")
	ctx := t.Context()

	for _, id := range []string{"gc-p", "gc-c", "gc-c2", "gc-g"} {
		mkIssue(t, ctx, te, id)
	}
	// Gate goes in while P and G are unrelated.
	addEdge(t, ctx, te, "gc-p", "gc-g", types.DepBlocks)
	addEdge(t, ctx, te, "gc-c", "gc-p", types.DepParentChild)
	addEdge(t, ctx, te, "gc-c2", "gc-p", types.DepParentChild)
	// The edge that pulls G into P's subtree (under C) closes the gate; it must
	// go in skipping the cycle guard, since P already blocks on G.
	addEdgeSkippingCycleCheck(t, ctx, te, "gc-g", "gc-c", types.DepParentChild)

	flags := blockedFlags(t, ctx, te, "gc-p", "gc-c", "gc-c2", "gc-g")
	if !flags["gc-p"] {
		t.Error("gc-p should report blocked: it still depends on an open grandchild")
	}
	for _, id := range []string{"gc-c", "gc-c2", "gc-g"} {
		if flags[id] {
			t.Errorf("%s is under gc-p's own subtree and must not be darkened by the close gate", id)
		}
	}

	ready := readySet(t, ctx, te)
	for _, id := range []string{"gc-c", "gc-c2", "gc-g"} {
		if !ready[id] {
			t.Errorf("%s missing from ready work: everything under a close-gate epic must stay workable, including the grandchild that frees it", id)
		}
	}
}

// TestExogenousBlockednessStillPropagates: a parent blocked by something OUTSIDE
// its own subtree must still cascade that block down to its children. This is the
// counter-case that rules out the blunt "never propagate down parent-child edges"
// non-fix — such children are legitimately blocked and must not surface as ready.
func TestExogenousBlockednessStillPropagates(t *testing.T) {
	te := newTestEnv(t, "exo")
	ctx := t.Context()

	for _, id := range []string{"exo-p", "exo-c1", "exo-c2", "exo-x"} {
		mkIssue(t, ctx, te, id)
	}
	// P is blocked by X, which lives outside P's subtree.
	addEdge(t, ctx, te, "exo-p", "exo-x", types.DepBlocks)
	// C1, C2 are children of P.
	addEdge(t, ctx, te, "exo-c1", "exo-p", types.DepParentChild)
	addEdge(t, ctx, te, "exo-c2", "exo-p", types.DepParentChild)

	flags := blockedFlags(t, ctx, te, "exo-x", "exo-p", "exo-c1", "exo-c2")
	if flags["exo-x"] {
		t.Error("exo-x is open and unblocked; it must not report blocked")
	}
	if !flags["exo-p"] {
		t.Error("exo-p is blocked by the external exo-x and must report blocked")
	}
	if !flags["exo-c1"] || !flags["exo-c2"] {
		t.Errorf("children of an externally-blocked parent must inherit the block: exo-c1=%v exo-c2=%v", flags["exo-c1"], flags["exo-c2"])
	}

	ready := readySet(t, ctx, te)
	for _, id := range []string{"exo-c1", "exo-c2"} {
		if ready[id] {
			t.Errorf("%s is ready, but its parent is blocked by an external item", id)
		}
	}
}

// TestExogenousBlockednessPropagatesThroughNestedCloseGate: a close-gate epic
// that is itself blocked from ABOVE by something outside the whole subtree must
// still darken its own children. The shape stacks the two cases that the flat
// tests cover separately. Q is blocked by external X. P is a child of Q and is
// itself a close-gate epic (P blocks on its own child C). Looking only at P's
// own reason rows, P blocks inside its own subtree, so a fix that recognises
// only the flat "parent blocks its own child" shape keeps C bright — but P is
// under an epic still gated by X, so the external block reaches all the way
// down and C is genuinely blocked. This gates the blocked-from-above behaviour
// at nested depth: a fix correct on the flat exogenous case and the flat
// close-gate case but wrong on their composition is rejected here.
func TestExogenousBlockednessPropagatesThroughNestedCloseGate(t *testing.T) {
	te := newTestEnv(t, "nx")
	ctx := t.Context()

	for _, id := range []string{"nx-x", "nx-q", "nx-p", "nx-c"} {
		mkIssue(t, ctx, te, id)
	}
	// Q is blocked by X, which lives outside the Q/P/C subtree.
	addEdge(t, ctx, te, "nx-q", "nx-x", types.DepBlocks)
	// The close gate on P goes in while P and C are unrelated: P blocks on C.
	addEdge(t, ctx, te, "nx-p", "nx-c", types.DepBlocks)
	// P is a child of Q (no cycle: Q blocks only on X).
	addEdge(t, ctx, te, "nx-p", "nx-q", types.DepParentChild)
	// C is a child of P; this closes the gate (P already blocks on C), so it
	// must skip the cycle guard.
	addEdgeSkippingCycleCheck(t, ctx, te, "nx-c", "nx-p", types.DepParentChild)

	flags := blockedFlags(t, ctx, te, "nx-x", "nx-q", "nx-p", "nx-c")
	if flags["nx-x"] {
		t.Error("nx-x is open and unblocked; it must not report blocked")
	}
	if !flags["nx-q"] {
		t.Error("nx-q should report blocked: it depends on the external nx-x")
	}
	if !flags["nx-p"] {
		t.Error("nx-p should report blocked: its parent nx-q is blocked from outside the subtree, so the external block reaches P")
	}
	if !flags["nx-c"] {
		t.Error("nx-c should report blocked: the external block above its epic propagates all the way down; it is not merely gated by its own in-subtree epic")
	}

	ready := readySet(t, ctx, te)
	if ready["nx-c"] {
		t.Error("nx-c is ready, but the epic above it is blocked by an external item, so the block reaches C")
	}
}

// TestIncrementalAgreesWithFullRepair: the per-edit (incremental) recompute and
// the whole-graph full repair must agree. We build the close-gate shape through
// the incremental write path, snapshot the is-blocked projection, run a full
// repair, and snapshot again: the two must be identical and the repair must have
// corrected nothing. This holds whatever the correct blocked values are, so it
// catches a partial fix that mends one recompute path but leaves the other
// diverging (oscillation between the two).
func TestIncrementalAgreesWithFullRepair(t *testing.T) {
	te := newTestEnv(t, "ls")
	ctx := t.Context()

	seedCloseGate(t, ctx, te, "ls-p", "ls-c1", "ls-c2")
	ids := []string{"ls-p", "ls-c1", "ls-c2"}

	incremental := blockedFlags(t, ctx, te, ids...)

	if changed := recomputeAllBlocked(t, ctx, te); changed != 0 {
		t.Errorf("full repair corrected %d rows over an incrementally-maintained graph; the two recompute paths disagree", changed)
	}

	fullRepair := blockedFlags(t, ctx, te, ids...)
	if !sameFlags(incremental, fullRepair) {
		t.Errorf("incremental vs full-repair is_blocked disagree: incremental=%v full-repair=%v", incremental, fullRepair)
	}
}

// TestDependencyHierarchyRefusalUnchanged: the dependency-add guard that refuses
// a blocking edge between an item and its own ancestor/descendant is unrelated to
// the ready-work fix and must stay in place. A fix that loosens or removes this
// guard instead of correcting the propagation is wrong. We assert the refusal by
// its typed error, not its wording — the message is incidental and may read
// differently across versions.
func TestDependencyHierarchyRefusalUnchanged(t *testing.T) {
	te := newTestEnv(t, "hc")
	ctx := t.Context()

	mkIssue(t, ctx, te, "hc-p")
	mkIssue(t, ctx, te, "hc-c")
	// hc-c is a child of hc-p.
	addEdge(t, ctx, te, "hc-c", "hc-p", types.DepParentChild)

	// Attempting a blocks edge from the ancestor onto its own descendant must be
	// refused with a hierarchy conflict.
	err := te.store.AddDependency(ctx, &types.Dependency{
		IssueID:     "hc-p",
		DependsOnID: "hc-c",
		Type:        types.DepBlocks,
	}, "tester")
	if err == nil {
		t.Fatal("blocks edge from an ancestor onto its own descendant was accepted; the hierarchy refusal is gone")
	}
	var conflict *issueops.DependencyHierarchyConflictError
	if !errors.As(err, &conflict) {
		t.Fatalf("expected a DependencyHierarchyConflictError, got %T: %v", err, err)
	}
	if conflict.BlockerIsAncestor {
		t.Errorf("blocker hc-c is a descendant of hc-p, so BlockerIsAncestor must be false, got true")
	}

	// A blocking edge between unrelated items is still accepted — the guard is
	// specific to the ancestry relationship, not a blanket block.
	mkIssue(t, ctx, te, "hc-free")
	addEdge(t, ctx, te, "hc-p", "hc-free", types.DepBlocks)
}

func sameFlags(a, b map[string]bool) bool {
	if len(a) != len(b) {
		return false
	}
	keys := make([]string, 0, len(a))
	for k := range a {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	for _, k := range keys {
		if a[k] != b[k] {
			return false
		}
	}
	return true
}
