## Task

we're getting reports that `bd ready` is going dark for entire epics. it's the common setup where an epic can't close until its children are done, so it carries blocking edges onto its own child items. once that's in place the children all come back as blocked and never show up as ready work. the whole subtree under that epic looks stuck even though nothing outside it is actually holding the children up, and it doesn't recover on its own. the items just stay dark.

we used to be able to see those children as ready; now `bd ready` returns empty for the whole epic. dig into the ready-work logic and fix it so the children that are legitimately ready surface again.

one case to watch: an item that's genuinely blocked by something outside its own subtree still needs to report as blocked. the fix isn't to stop blocking children.
