## Task

Resolvers can unmarshal an input object out of the request context, but the
unmarshaler is picked from the Go type of the destination the caller passes in.
Inputs that share a Go type cannot be told apart that way, and every input bound
to `map[string]interface{}` shares one, so a resolver that asks for one of them
can quietly get another input's fields instead. Resolvers need a way to say which
input they mean.

The library is published, so code that already calls `BuildUnmarshalerMap`,
`WithUnmarshalerMap` or `UnmarshalInputFromContext` has to keep compiling and
working. Generated code is committed in this repository, so it has to be
regenerated whenever the generator's output changes, and both the root module
and `_examples` must still build. There is no network access; the Go module
cache holds the dependencies of the root module and the `_examples` module.

## User stories / requirements

- In a resolver, an input unmarshaled by its GraphQL name into its Go type or a pointer to it keeps its own fields, even when other inputs share that Go type or requests overlap. A null input gives the zero value. Unknown names get an error naming them; use outside a request gets an error.
- Generated code has a typed helper for each input object that, used in a resolver on a raw input object, returns that input's own Go value, so inputs that share a Go type each keep their own fields. Used outside a request, it returns an error.
- With the option that makes input unmarshalers return pointers turned on, the generated code builds, the typed helpers work, and unmarshaling by name fills either the input's Go type or a pointer to it. A null input gives the zero value, never a nil pointer.
- When the generated code uses function syntax instead of methods for the execution context, a resolver can unmarshal an input by name without a panic, getting that input's fields back, or the zero value for a null input.
