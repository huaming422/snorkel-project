# Sourced once before any check runs, the tests/verify files and the stories alike.
#
# Inherits the image's Go toolchain (Go 1.26.9) and the module caches for both
# modules (the root module and _examples), downloaded at the base commit in the
# Dockerfile. The checks run `go build`, `go test` and `go generate` across these
# modules; some packages need cgo.
#
# Setup here is minimal, since everything heavy lives in the Dockerfile: it only
# exports the environment, so later Go commands behave the same way every time
# and stay offline.

set -euo pipefail

cd /repo/gqlgen

export GOFLAGS="-mod=mod"
export CGO_ENABLED="1"
export GOTOOLCHAIN="local"
export GOPROXY="${GOPROXY:-off}"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
mkdir -p "$GOCACHE" "$GOMODCACHE"
