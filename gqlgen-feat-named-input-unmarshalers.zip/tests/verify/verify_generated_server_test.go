// Type-keyed input unmarshaling from inside a resolver of a generated server.
//
// Applications already call graphql.UnmarshalInputFromContext from their
// resolvers, picking the input by the Go type of the value they pass in. Those
// resolvers have to keep working after the generator changes, so this drives
// the call the way an application does: one request through the generated
// singlefile server, the call made inside a resolver, with a target whose Go
// type belongs to exactly one input object (InnerInput). A target type that no
// input uses must still come back as an error.
//
// The file is copied into codegen/testserver/singlefile and compiled together
// with that package's own tests, so every top-level name it adds carries a
// file-unique vgs prefix.
package singlefile

import (
	"context"
	"testing"

	"github.com/99designs/gqlgen/client"
	"github.com/99designs/gqlgen/graphql"
	"github.com/99designs/gqlgen/graphql/handler"
	"github.com/99designs/gqlgen/graphql/handler/transport"
)

// vgsNotAnInput is a Go type that no input object in the schema maps to.
type vgsNotAnInput struct {
	ID int
}

// vgsUnmarshalInResolver sends one query to a fresh generated server and, from
// inside the resolver, unmarshals raw into target with the type-keyed call. It
// returns that call's error.
func vgsUnmarshalInResolver(t *testing.T, raw, target any) error {
	t.Helper()

	var callErr error
	ran := false
	resolvers := &Stub{}
	resolvers.QueryResolver.DefaultScalar = func(ctx context.Context, arg string) (string, error) {
		ran = true
		callErr = graphql.UnmarshalInputFromContext(ctx, raw, target)
		return arg, nil
	}

	srv := handler.New(NewExecutableSchema(Config{Resolvers: resolvers}))
	srv.AddTransport(transport.POST{})

	var resp struct{ DefaultScalar string }
	if err := client.New(srv).Post(`query { defaultScalar(arg: "hi") }`, &resp); err != nil {
		t.Fatalf("query failed: %v", err)
	}
	if !ran {
		t.Fatal("the resolver never ran")
	}
	return callErr
}

func TestTypeKeyedUnmarshalInResolverReturnsTheInput(t *testing.T) {
	var got InnerInput
	if err := vgsUnmarshalInResolver(t, map[string]any{"id": 7}, &got); err != nil {
		t.Fatalf("unmarshaling into InnerInput returned an error: %v", err)
	}
	if got.ID != 7 {
		t.Fatalf("got %+v, want ID 7", got)
	}
}

func TestTypeKeyedUnmarshalInResolverRejectsATypeNoInputUses(t *testing.T) {
	var got vgsNotAnInput
	err := vgsUnmarshalInResolver(t, map[string]any{"id": 7}, &got)
	if err == nil {
		t.Fatalf("unmarshaling into a type no input uses returned no error (got %+v)", got)
	}
	if got.ID != 0 {
		t.Fatalf("the target was filled despite the error: %+v", got)
	}
}
