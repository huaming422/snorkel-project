#!/usr/bin/env bash
# Whole-tree compilation gate.
#
# Generated code is committed in this repository, and every generated server
# compiles against the runtime package. This gate builds both Go modules in the
# checkout, so a change that leaves committed generated code calling something
# the runtime no longer provides, or that does not compile itself, fails here.
# It names nothing a solution adds, and it holds on an unmodified checkout and
# on any correct solution.
#
# Modules in this checkout:
#   * the root module (github.com/99designs/gqlgen): the runtime package, the
#     generator and its templates, and the generated test servers and fixtures;
#   * the _examples module, which replaces the root module with the local copy
#     (`replace => ../`), so building it compiles the examples against the
#     runtime in this checkout.
set -euo pipefail

export GOFLAGS="${GOFLAGS:--mod=mod}"
export CGO_ENABLED="${CGO_ENABLED:-1}"
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"
export GOPROXY="${GOPROXY:-off}"

echo "== building root module (github.com/99designs/gqlgen) =="
cd /repo/gqlgen
go build ./...

echo "== building _examples module (replace => ../) =="
cd /repo/gqlgen/_examples
go build ./...

echo "== build gate passed =="
