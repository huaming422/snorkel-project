## Task

When a plan's checks come back failed or canceled (a check that timed out, or one
someone stopped partway), the Plan Detail page offers a "Submit anyway" confirmation.
Clicking it has no effect: the issue stays stuck in draft instead of moving forward.
Operators who reach for "Submit anyway" expect it to actually submit the plan, the way
the page's offer implies.

Separately, the check-status summary on Plan Detail over-counts: a single check that
failed with an error shows up as two errors in the counts and badges instead of one.

Both are reproducible on Plan Detail. Dig in and sort them out.
