#!/usr/bin/env bash
#
# test-setup.sh — sourced by the verifier harness BEFORE the tests run.
#
# The image already baked the full dependency closure at the base commit: the Go
# module + build caches are warm under /opt/cache, and the frontend's node_modules
# plus the pnpm content-addressed store are materialised. So this script only has
# to (1) make the toolchains visible even if the harness scrubbed PATH, (2) force
# every toolchain into offline mode so a cache miss fails fast instead of hanging
# on a dead network, and (3) defensively re-materialise node_modules if an agent's
# `git clean -fdx` erased it.
#
# Sourced (not exec'd) so the environment we export sticks for the verifier
# subprocess.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/bytebase}"
export REPO_DIR
cd "$REPO_DIR"

# --- Go toolchain: visible + offline ---------------------------------------
# The image exports these, but a freshly-spawned shell that did not inherit the
# image ENV still needs them. GOPROXY=off makes `go test` use only the warmed
# module cache; GOFLAGS=-mod=mod keeps builds off a (frozen) vendor dir.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac
export GOTOOLCHAIN=local
export GOFLAGS=-mod=mod
export GOPROXY=off
export CGO_ENABLED=1

# --- Node/pnpm toolchain: visible + offline --------------------------------
# node and pnpm were installed under /usr/local/bin; re-assert PATH defensively.
# `--offline` (store replay only) is set for the pnpm fallback below so a cache
# miss errors immediately rather than reaching for the network the agent phase
# does not have.
case ":$PATH:" in
    *":/usr/local/bin:"*) ;;
    *) export PATH=/usr/local/bin:$PATH ;;
esac

# Defensive re-install: node_modules is baked at build time, but an agent's
# working-tree scrub could remove it. Replay from the warm store, offline-first;
# the harness/verifier phase still has the gateway allowlist, so an identical
# retry without --offline is the single sanctioned fallback (one resolve attempt
# per the [sync] lint).
if ! [ -x frontend/node_modules/.bin/vitest ]; then
    echo "test-setup.sh: frontend node_modules missing; replaying from the pnpm store." >&2
    ( cd frontend && pnpm install --frozen-lockfile --ignore-scripts --offline ) \
        || ( cd frontend && pnpm install --frozen-lockfile --ignore-scripts )
fi

echo "test-setup.sh: ready. go=$(go version 2>/dev/null | awk '{print $3}') node=$(node --version 2>/dev/null) pnpm=$(pnpm --version 2>/dev/null)"
