// @vitest-environment node
import { create } from "@bufbuild/protobuf";
import { describe, expect, test } from "vitest";
import {
  getFilteredResultGroups,
  getPlanCheckSummary,
  getPlanCheckSummaryWithFallback,
  planCheckRunListForSpec,
} from "@/lib/plan/check";
import {
  type Plan_Spec,
  PlanCheckRun_ResultSchema,
  PlanCheckRun_Status,
  PlanCheckRunSchema,
} from "@/types/proto-es/v1/plan_service_pb";
import type { Plan } from "@/types/proto-es/v1/plan_service_pb";
import type { Project } from "@/types/proto-es/v1/project_service_pb";
import { Advice_Level } from "@/types/proto-es/v1/sql_service_pb";
import { getSubmitReviewAdvance } from "@/routes/project/plan-detail/components/lifecycle/advanceState";
import { buildChangesSummary } from "@/routes/project/plan-detail/utils/phaseSummary";

describe("plan check summary counts an incomplete run once", () => {
  // A plan has at most one check run. A run that both ended in a
  // failed/canceled status AND carries an error result is one failure, not two
  // — both the run-list path and the count-map fallback must report it once.
  test("a failed or canceled run with an error result is one error", () => {
    for (const status of [
      PlanCheckRun_Status.FAILED,
      PlanCheckRun_Status.CANCELED,
    ]) {
      const run = create(PlanCheckRunSchema, {
        status,
        results: [
          create(PlanCheckRun_ResultSchema, { status: Advice_Level.ERROR }),
        ],
      });
      const statusName = PlanCheckRun_Status[status];

      expect(getPlanCheckSummary([run]).error).toBe(1);
      expect(
        getPlanCheckSummaryWithFallback([], { [statusName]: 1, ERROR: 1 }).error
      ).toBe(1);
      expect(
        getPlanCheckSummaryWithFallback([], { [statusName]: 1 }).error
      ).toBe(1);

      // A run that ended incomplete with no error result of its own still
      // counts as exactly one error — the run-level signal is its only error.
      const resultlessRun = create(PlanCheckRunSchema, { status });
      expect(getPlanCheckSummary([resultlessRun]).error).toBe(1);
    }
  });
});

describe("result-group display surfaces incomplete runs without duplication", () => {
  // A run that already carries an error result renders that result alone — no
  // extra synthetic "run failed" group duplicating it. One run with one error
  // result must produce exactly one group.
  test("a failed run with an error result is not duplicated into a synthetic group", () => {
    const groups = getFilteredResultGroups({
      includeRunFailure: true,
      planCheckRuns: [
        create(PlanCheckRunSchema, {
          name: "failed-run",
          status: PlanCheckRun_Status.FAILED,
          results: [
            create(PlanCheckRun_ResultSchema, {
              status: Advice_Level.ERROR,
              content: "statement advise failed",
            }),
          ],
        }),
      ],
    });

    expect(groups).toHaveLength(1);
    expect(groups[0]?.results).toHaveLength(1);
    expect(groups[0]?.results[0]?.content).toBe("statement advise failed");
  });

  // A canceled run with no error result of its own still surfaces, as a single
  // synthetic group carrying the run's own canceled message. Its text is
  // read-through from the run, independent of how the display strings are
  // plumbed through.
  test("a resultless canceled run surfaces as its own group", () => {
    const groups = getFilteredResultGroups({
      includeRunFailure: true,
      planCheckRuns: [
        create(PlanCheckRunSchema, {
          name: "canceled-run",
          status: PlanCheckRun_Status.CANCELED,
          error: "Canceled by user",
        }),
      ],
    });

    expect(groups).toHaveLength(1);
    expect(groups[0]?.results[0]?.content).toBe("Canceled by user");
    expect(groups[0]?.results[0]?.status).toBe(Advice_Level.ERROR);
  });
});

describe("a resultless canceled run stays visible for its spec", () => {
  const makeSpec = (targets: string[]): Plan_Spec =>
    ({
      config: { case: "changeDatabaseConfig", value: { targets } },
    }) as unknown as Plan_Spec;

  // planCheckRunListForSpec keeps a resultless RUNNING/FAILED run attached to a
  // spec so the UI can show it; a canceled run with no results must be kept the
  // same way rather than vanishing from the spec's check list.
  test("a canceled resultless run is retained for the spec", () => {
    const spec = makeSpec(["instances/i1/databases/db1"]);
    const runs = [
      create(PlanCheckRunSchema, {
        name: "canceled-run",
        status: PlanCheckRun_Status.CANCELED,
      }),
    ];

    const kept = planCheckRunListForSpec(runs, spec);

    expect(kept).toHaveLength(1);
    expect(kept[0]?.status).toBe(PlanCheckRun_Status.CANCELED);
  });
});

describe("the plan-detail change summary counts an incomplete run once", () => {
  const templates: Record<string, string> = {
    "common.and": "and",
    "plan.summary.n-changes": "{{n}} changes",
    "plan.summary.n-database-groups": "{{n}} database groups",
    "plan.summary.n-databases": "{{n}} databases",
    "plan.summary.n-error": "{{n}} error",
    "plan.summary.n-passed": "{{n}} passed",
    "plan.summary.n-warning": "{{n}} warning",
  };
  const t = (key: string, options?: Record<string, unknown>) =>
    Object.entries(options ?? {}).reduce(
      (text, [name, value]) => text.replaceAll(`{{${name}}}`, String(value)),
      templates[key] ?? key
    );

  // The plan-detail summary reads a pre-aggregated status-count map. A single
  // run that both errored and ended FAILED must read as one error in the
  // rendered summary, not two.
  test("an ERROR + FAILED run renders as a single error", () => {
    const plan = {
      planCheckRunStatusCount: { ERROR: 1, FAILED: 1 },
      specs: [
        {
          config: {
            case: "changeDatabaseConfig",
            value: { targets: ["instances/i1/databases/db1"] },
          },
        },
      ],
    } as unknown as Plan;

    expect(buildChangesSummary(plan, t)).toContain("1 error");
    expect(buildChangesSummary(plan, t)).not.toContain("2 error");
  });
});

describe("a canceled run is submittable on a non-enforcing project", () => {
  const t = (key: string) => key;

  const makePlan = (cases: string[], statusCount = {}): Plan =>
    ({
      planCheckRunStatusCount: statusCount,
      specs: cases.map((caseName) => ({
        config: { case: caseName, value: {} },
      })),
    }) as unknown as Plan;

  const project = (
    overrides: Partial<
      Pick<Project, "enforceSqlReview" | "forceIssueLabels">
    > = {}
  ) =>
    ({
      enforceSqlReview: false,
      forceIssueLabels: false,
      ...overrides,
    }) as Project;

  const submitArgs = (
    overrides: Partial<Parameters<typeof getSubmitReviewAdvance>[0]> = {}
  ) => ({
    emptySpecCount: 0,
    isEditing: false,
    plan: makePlan(["changeDatabaseConfig"]),
    project: project(),
    selectedLabelCount: 1,
    t,
    ...overrides,
  });

  // When the only run was canceled on a project that does not enforce SQL
  // review, the reader is offered the deliberate "submit anyway" override
  // rather than being permanently blocked.
  test("the override is offered for a canceled-only plan", () => {
    const advance = getSubmitReviewAdvance(
      submitArgs({
        plan: makePlan(["changeDatabaseConfig"], { CANCELED: 1 }),
      })
    );

    expect(advance.blockers.map((b) => b.id)).not.toContain("checks-failed");
    expect(advance.decision).toEqual({
      body: "issue.checks-warning-hint",
      headline: "plan.lifecycle.gate-checks-failed",
      verb: "plan.submit-review-anyway",
    });
  });
});
