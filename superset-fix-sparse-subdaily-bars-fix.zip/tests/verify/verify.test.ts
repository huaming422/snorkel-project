/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
import {
  ChartProps,
  ChartDataResponseResult,
  Column,
  SqlaFormData,
} from '@superset-ui/core';
import { GenericDataType } from '@apache-superset/core/common';
import { supersetTheme } from '@apache-superset/core/theme';
import * as echarts from 'echarts';
import type { EChartsCoreOption, XAxisComponentOption } from 'echarts';
import transformProps from '../../../src/Timeseries/transformProps';
import mixedTransformProps from '../../../src/MixedTimeseries/transformProps';
import { DEFAULT_FORM_DATA } from '../../../src/Timeseries/constants';
import { DEFAULT_FORM_DATA as MIXED_DEFAULT_FORM_DATA } from '../../../src/MixedTimeseries/types';
import type { EchartsMixedTimeseriesProps } from '../../../src/MixedTimeseries/types';
import { EchartsTimeseriesSeriesType } from '../../../src/Timeseries/types';
import { EchartsTimeseriesChartProps } from '../../../src/types';

const HOUR_MS = 3_600_000;
const FIFTEEN_MIN_MS = 15 * 60 * 1000;
const DAY_MS = 24 * HOUR_MS;

// A bar may be a bit narrower or a bit wider than its bucket (gaps, rounding,
// grouping), but it must stay about one bucket wide: neither a sliver nor
// spread over the buckets next to it. The bucket is measured on the rendered chart, see renderBars.
const MIN_BUCKET_RATIO = 0.25;
const MAX_BUCKET_RATIO = 1.75;

// jsdom has no canvas, so give ECharts a fixed text-width estimate for label
// and legend layout. Every patch is rendered with the same estimate.
(
  echarts as unknown as {
    setPlatformAPI: (api: {
      measureText: (text: string) => { width: number };
    }) => void;
  }
).setPlatformAPI({
  measureText: (text: string) => ({ width: String(text).length * 7 }),
});

const DEFAULT_DATASOURCE_COLUMNS: Column[] = [
  {
    column_name: 'count',
    is_dttm: false,
    type_generic: GenericDataType.Numeric,
  },
  {
    column_name: '__timestamp',
    is_dttm: true,
    type_generic: GenericDataType.Temporal,
  },
];

const BASE_FORM_DATA: SqlaFormData = {
  ...DEFAULT_FORM_DATA,
  colorScheme: 'bnbColors',
  datasource: '3__table',
  granularity_sqla: '__timestamp',
  time_grain_sqla: 'PT1H',
  metric: ['count'],
  groupby: [],
  viz_type: 'echarts_timeseries_bar',
  seriesType: EchartsTimeseriesSeriesType.Bar,
  orientation: 'vertical',
};

// Two populated hours (01:00 and 23:00) out of a day.
const SPARSE_HOURS = [
  Date.UTC(2024, 0, 1, 1, 0, 0),
  Date.UTC(2024, 0, 1, 23, 0, 0),
];
const sparseRows = (timestamps: number[] = SPARSE_HOURS) =>
  timestamps.map(__timestamp => ({ count: 1, __timestamp }));

function buildOptions(
  width: number,
  data: Record<string, unknown>[],
  overrides: Partial<ChartDataResponseResult> = {},
  formDataOverrides: Partial<SqlaFormData> = {},
  height = 400,
  datasourceColumns: Column[] = DEFAULT_DATASOURCE_COLUMNS,
) {
  const chartProps = new ChartProps({
    width,
    height,
    queriesData: [
      {
        data,
        colnames: ['count', '__timestamp'],
        coltypes: [GenericDataType.Numeric, GenericDataType.Temporal],
        ...overrides,
      },
    ],
    formData: { ...BASE_FORM_DATA, ...formDataOverrides },
    theme: supersetTheme,
    datasource: { columns: datasourceColumns },
  });

  return transformProps(chartProps as EchartsTimeseriesChartProps)
    .echartOptions;
}

type RenderedBars = {
  // rendered thickness of each bar along the time axis, in px
  barPx: number[];
  // px one grain spans when the axis' own time extent is laid over the plot
  // area the option reserves (chart size minus the option's grid padding)
  bucketPx: number;
};

function gridSide(grid: unknown, side: 'left' | 'right' | 'top' | 'bottom') {
  const box = (Array.isArray(grid) ? grid[0] : grid) as Record<string, unknown>;
  const value = box?.[side];
  if (typeof value !== 'number') {
    throw new Error(
      `expected a numeric grid.${side} in the chart option, got: ${JSON.stringify(value)}`,
    );
  }
  return value;
}

// Renders the option with ECharts (SVG, server side) and reads back the bar
// geometry ECharts actually lays out, so any way of sizing the bars counts.
function renderBars(
  option: EChartsCoreOption,
  width: number,
  height: number,
  grainMs: number,
): RenderedBars {
  const chart = echarts.init(null as unknown as HTMLElement, null, {
    renderer: 'svg',
    ssr: true,
    width,
    height,
  });
  try {
    chart.setOption(option);
    const model = (chart as any).getModel();
    const barPx: number[] = [];
    let bucketPx: number | undefined;
    model.getSeries().forEach((seriesModel: any) => {
      if (seriesModel.subType !== 'bar') return;
      const axis = seriesModel.getBaseAxis();
      expect(axis.type).toBe('time');
      const [extentMin, extentMax] = axis.scale.getExtent();
      const isVertical = axis.dim === 'y';
      // The plot area the option reserves; a grid given in other units
      // (percentages) falls back to the rect ECharts laid out.
      let plotPx: number;
      try {
        plotPx = isVertical
          ? height -
            gridSide(option.grid, 'top') -
            gridSide(option.grid, 'bottom')
          : width -
            gridSide(option.grid, 'left') -
            gridSide(option.grid, 'right');
      } catch {
        const rect = axis.grid.getRect();
        plotPx = isVertical ? rect.height : rect.width;
      }
      bucketPx = (grainMs / (extentMax - extentMin)) * plotPx;
      const data = seriesModel.getData();
      for (let i = 0; i < data.count(); i += 1) {
        const layout = data.getItemLayout(i);
        if (layout) {
          barPx.push(Math.abs(isVertical ? layout.height : layout.width));
        }
      }
    });
    if (bucketPx === undefined || !barPx.length) {
      throw new Error('expected at least one rendered bar on a time axis');
    }
    return { barPx, bucketPx };
  } finally {
    chart.dispose();
  }
}

function expectBarsFitTheirBucket({ barPx, bucketPx }: RenderedBars) {
  barPx.forEach(px => {
    expect(Number.isFinite(px)).toBe(true);
    expect(px).toBeGreaterThanOrEqual(bucketPx * MIN_BUCKET_RATIO);
    expect(px).toBeLessThanOrEqual(bucketPx * MAX_BUCKET_RATIO);
  });
}

// Validates the option shape so a missing xAxis fails loudly instead of
// passing a `.toBe('category')` check by accident.
function xAxisType(xAxis: unknown): unknown {
  if (
    typeof xAxis !== 'object' ||
    xAxis === null ||
    Array.isArray(xAxis) ||
    !('type' in xAxis)
  ) {
    throw new Error(
      `expected a single xAxis option object with a "type" property, got: ${JSON.stringify(xAxis)}`,
    );
  }
  return (xAxis as XAxisComponentOption).type;
}

test('two populated hours out of a day: each bar stays about one hour wide', () => {
  const option = buildOptions(800, sparseRows());
  expectBarsFitTheirBucket(renderBars(option, 800, 400, HOUR_MS));
});

test('a single populated hour: the bar stays about one hour wide on the axis ECharts draws around it', () => {
  const option = buildOptions(800, sparseRows([Date.UTC(2024, 0, 1, 13)]));
  expectBarsFitTheirBucket(renderBars(option, 800, 400, HOUR_MS));
});

test('bar width follows the chart size: narrow and wide charts both keep the bar about one hour wide', () => {
  [300, 2400].forEach(width => {
    const option = buildOptions(width, sparseRows());
    expectBarsFitTheirBucket(renderBars(option, width, 400, HOUR_MS));
  });
});

test.each([
  ['PT15M', FIFTEEN_MIN_MS],
  ['PT30M', 30 * 60 * 1000],
  ['PT5M', 5 * 60 * 1000],
])('a %s grain sizes the bar to that grain', (grain, grainMs) => {
  const option = buildOptions(
    800,
    sparseRows(),
    {},
    { time_grain_sqla: grain },
  );
  expectBarsFitTheirBucket(renderBars(option, 800, 400, grainMs));
});

test('a dashboard time grain override sizes the bar to the grain the buckets really have', () => {
  // The chart itself is daily; a dashboard filter turns it hourly.
  const option = buildOptions(
    800,
    sparseRows(),
    {},
    { time_grain_sqla: 'P1D', extraFormData: { time_grain_sqla: 'PT1H' } },
  );
  expectBarsFitTheirBucket(renderBars(option, 800, 400, HOUR_MS));
});

test('horizontal orientation: the bar is sized along the vertical time axis', () => {
  // Wide and short, so sizing against the width instead of the height gives
  // a bar several hours thick.
  const option = buildOptions(
    3000,
    sparseRows(),
    {},
    { orientation: 'horizontal' },
    400,
  );
  expectBarsFitTheirBucket(renderBars(option, 3000, 400, HOUR_MS));
});

test('a left legend on a narrow chart: the bar is sized to the plot area that is left', () => {
  const width = 250;
  const option = buildOptions(width, sparseRows(), {}, {
    showLegend: true,
    legendOrientation: 'left',
    groupby: ['count'],
  });
  // The legend has to take real room, or this case proves nothing.
  const plotPx =
    width - gridSide(option.grid, 'left') - gridSide(option.grid, 'right');
  expect(plotPx).toBeLessThan(width / 2);
  expectBarsFitTheirBucket(renderBars(option, width, 400, HOUR_MS));
});

test('a right legend on a narrow chart: the bar is sized to the plot area that is left', () => {
  const width = 250;
  const option = buildOptions(width, sparseRows(), {}, {
    showLegend: true,
    legendOrientation: 'right',
    groupby: ['count'],
  });
  const plotPx =
    width - gridSide(option.grid, 'left') - gridSide(option.grid, 'right');
  expect(plotPx).toBeLessThan(width / 2);
  expectBarsFitTheirBucket(renderBars(option, width, 400, HOUR_MS));
});

test('a fully populated hourly day still renders bars about one bucket wide', () => {
  const allHours = Array.from({ length: 24 }, (_, hour) =>
    Date.UTC(2024, 0, 1, hour),
  );
  const option = buildOptions(800, sparseRows(allHours));
  expectBarsFitTheirBucket(renderBars(option, 800, 400, HOUR_MS));
});

test('a fully populated daily month still renders bars about one day wide', () => {
  const allDays = Array.from({ length: 30 }, (_, day) =>
    Date.UTC(2024, 0, 1 + day),
  );
  const option = buildOptions(
    800,
    sparseRows(allDays),
    {},
    { time_grain_sqla: 'P1D' },
  );
  expectBarsFitTheirBucket(renderBars(option, 800, 400, DAY_MS));
});

test('a bar chart on a non-time x-axis still renders bars with a finite, bounded width', () => {
  const option = buildOptions(
    800,
    [
      { count: 1, price: 10 },
      { count: 3, price: 20 },
    ],
    {
      colnames: ['count', 'price'],
      coltypes: [GenericDataType.Numeric, GenericDataType.Numeric],
    },
    { x_axis: 'price' },
    400,
    [
      {
        column_name: 'price',
        is_dttm: false,
        type_generic: GenericDataType.Numeric,
      },
    ],
  );
  expect(xAxisType(option.xAxis)).toBe('category');
  const chart = echarts.init(null as unknown as HTMLElement, null, {
    renderer: 'svg',
    ssr: true,
    width: 800,
    height: 400,
  });
  try {
    chart.setOption(option);
    const seriesModel = (chart as any)
      .getModel()
      .getSeries()
      .find((s: any) => s.subType === 'bar');
    const data = seriesModel.getData();
    for (let i = 0; i < data.count(); i += 1) {
      const { width } = data.getItemLayout(i);
      expect(Number.isFinite(width)).toBe(true);
      expect(width).toBeGreaterThan(0);
      expect(width).toBeLessThanOrEqual(100);
    }
  } finally {
    chart.dispose();
  }
});

describe('x-axis type when the response does not mark the time column temporal', () => {
  const data = sparseRows();

  test('type list shorter than the column names (temporal entry missing)', () => {
    const { xAxis } = buildOptions(800, data, {
      coltypes: [GenericDataType.Numeric],
    });
    expect(xAxisType(xAxis)).toBe('time');
  });

  test("type list holding raw database type names (e.g. 'TIMESTAMP')", () => {
    const { xAxis } = buildOptions(800, data, {
      coltypes: ['BIGINT', 'TIMESTAMP'] as unknown as GenericDataType[],
    });
    expect(xAxisType(xAxis)).toBe('time');
  });

  test('a datetime column stored as epoch milliseconds, typed BIGINT in the response', () => {
    const { xAxis } = buildOptions(
      800,
      SPARSE_HOURS.map(created_ms => ({ count: 1, created_ms })),
      {
        colnames: ['count', 'created_ms'],
        coltypes: ['BIGINT', 'BIGINT'] as unknown as GenericDataType[],
      },
      { x_axis: 'created_ms', granularity_sqla: undefined },
      400,
      [
        {
          column_name: 'count',
          is_dttm: false,
          type_generic: GenericDataType.Numeric,
        },
        { column_name: 'created_ms', is_dttm: true },
      ],
    );
    expect(xAxisType(xAxis)).toBe('time');
  });

  test('a chart whose x-axis is set to a dataset datetime column', () => {
    const { xAxis } = buildOptions(
      800,
      SPARSE_HOURS.map(event_ts => ({ count: 1, event_ts })),
      {
        colnames: ['count', 'event_ts'],
        coltypes: ['BIGINT', 'TIMESTAMP'] as unknown as GenericDataType[],
      },
      { x_axis: 'event_ts', granularity_sqla: undefined },
      400,
      [
        {
          column_name: 'count',
          is_dttm: false,
          type_generic: GenericDataType.Numeric,
        },
        {
          column_name: 'event_ts',
          is_dttm: true,
          type_generic: GenericDataType.Temporal,
        },
      ],
    );
    expect(xAxisType(xAxis)).toBe('time');
  });

  // The dataset also has a datetime column, and a dashboard filter supplies
  // a time grain, but this chart's x-axis is a plain number column.
  const priceColumns: Column[] = [
    {
      column_name: 'price',
      is_dttm: false,
      type_generic: GenericDataType.Numeric,
    },
    {
      column_name: 'order_date',
      is_dttm: true,
      type_generic: GenericDataType.Temporal,
    },
  ];

  test('a numeric x-axis stays a category axis under a dashboard time grain', () => {
    const { xAxis } = buildOptions(
      800,
      [
        { count: 1, price: 10 },
        { count: 1, price: 20 },
      ],
      {
        colnames: ['count', 'price'],
        coltypes: ['BIGINT'] as unknown as GenericDataType[],
      },
      {
        x_axis: 'price',
        granularity_sqla: 'order_date',
        extraFormData: { time_grain_sqla: 'PT1H' },
      },
      400,
      priceColumns,
    );
    expect(xAxisType(xAxis)).toBe('category');
  });

  test('a numeric x-axis with large, epoch-sized values stays a category axis', () => {
    const { xAxis } = buildOptions(
      800,
      SPARSE_HOURS.map(order_id => ({ count: 1, order_id })),
      {
        colnames: ['count', 'order_id'],
        coltypes: ['BIGINT', 'BIGINT'] as unknown as GenericDataType[],
      },
      { x_axis: 'order_id', granularity_sqla: 'order_date' },
      400,
      [
        {
          column_name: 'order_id',
          is_dttm: false,
          type_generic: GenericDataType.Numeric,
        },
        {
          column_name: 'order_date',
          is_dttm: true,
          type_generic: GenericDataType.Temporal,
        },
      ],
    );
    expect(xAxisType(xAxis)).toBe('category');
  });

  test('a custom SQL x-axis does not take the type of the time column', () => {
    const { xAxis } = buildOptions(
      800,
      [
        { count: 1, double_price: 10 },
        { count: 1, double_price: 20 },
      ],
      {
        colnames: ['count', 'double_price'],
        coltypes: [GenericDataType.Numeric],
      },
      {
        x_axis: {
          label: 'double_price',
          sqlExpression: 'price * 2',
          expressionType: 'SQL',
        } as unknown as string,
        granularity_sqla: 'order_date',
        extraFormData: { time_grain_sqla: 'PT1H' },
      },
      400,
      priceColumns,
    );
    expect(xAxisType(xAxis)).toBe('category');
  });
});

describe('mixed time-series chart', () => {
  // Query A is a line, query B is the bar.
  function buildMixedOptions(
    width: number,
    queryAColtypes: unknown[] = [
      GenericDataType.Numeric,
      GenericDataType.Temporal,
    ],
    timestamps: number[] = SPARSE_HOURS,
    formDataOverrides: Record<string, unknown> = {},
    lineTimestamps: number[] = timestamps,
  ) {
    const queryAData = {
      data: lineTimestamps.map(__timestamp => ({ __timestamp, lineMetric: 1 })),
      colnames: ['lineMetric', '__timestamp'],
      coltypes: queryAColtypes,
      label_map: { lineMetric: ['lineMetric'] },
    } as unknown as ChartDataResponseResult;
    const queryBData = {
      data: timestamps.map(__timestamp => ({ __timestamp, barMetric: 1 })),
      colnames: ['__timestamp', 'barMetric'],
      coltypes: [GenericDataType.Temporal, GenericDataType.Numeric],
      label_map: { barMetric: ['barMetric'] },
    } as unknown as ChartDataResponseResult;

    const chartProps = new ChartProps({
      width,
      height: 400,
      queriesData: [queryAData, queryBData],
      formData: {
        ...MIXED_DEFAULT_FORM_DATA,
        colorScheme: 'bnbColors',
        datasource: '3__table',
        viz_type: 'mixed_timeseries',
        x_axis: '__timestamp',
        time_grain_sqla: 'PT1H',
        metrics: ['lineMetric'],
        metricsB: ['barMetric'],
        groupby: [],
        groupbyB: [],
        seriesType: EchartsTimeseriesSeriesType.Line,
        seriesTypeB: EchartsTimeseriesSeriesType.Bar,
        stack: null,
        stackB: null,
        ...formDataOverrides,
      } as unknown as SqlaFormData,
      theme: supersetTheme,
      datasource: { columns: DEFAULT_DATASOURCE_COLUMNS },
    });

    return mixedTransformProps(
      chartProps as unknown as EchartsMixedTimeseriesProps,
    ).echartOptions;
  }

  test('the bar stays about one hour wide on narrow and wide charts', () => {
    [300, 800].forEach(width => {
      expectBarsFitTheirBucket(
        renderBars(buildMixedOptions(width), width, 400, HOUR_MS),
      );
    });
  });

  test('a sparse bar next to a line that fills the day stays about one hour wide', () => {
    const allHours = Array.from({ length: 24 }, (_, hour) =>
      Date.UTC(2024, 0, 1, hour),
    );
    const option = buildMixedOptions(
      800,
      undefined,
      [Date.UTC(2024, 0, 1, 8), Date.UTC(2024, 0, 1, 16)],
      {},
      allHours,
    );
    expectBarsFitTheirBucket(renderBars(option, 800, 400, HOUR_MS));
  });

  test('a single populated hour stays about one hour wide', () => {
    const option = buildMixedOptions(800, undefined, [Date.UTC(2024, 0, 1, 13)]);
    expectBarsFitTheirBucket(renderBars(option, 800, 400, HOUR_MS));
  });

  test('a 15-minute grain sizes the bar to 15 minutes', () => {
    const option = buildMixedOptions(800, undefined, SPARSE_HOURS, {
      time_grain_sqla: 'PT15M',
    });
    expectBarsFitTheirBucket(renderBars(option, 800, 400, FIFTEEN_MIN_MS));
  });

  test('a dashboard time grain override sizes the bar to the grain the buckets really have', () => {
    const option = buildMixedOptions(800, undefined, SPARSE_HOURS, {
      time_grain_sqla: 'P1D',
      extraFormData: { time_grain_sqla: 'PT1H' },
    });
    expectBarsFitTheirBucket(renderBars(option, 800, 400, HOUR_MS));
  });

  test('a left legend on a narrow chart: the bar is sized to the plot area that is left', () => {
    const width = 250;
    const option = buildMixedOptions(width, undefined, SPARSE_HOURS, {
      showLegend: true,
      legendOrientation: 'left',
    });
    const plotPx =
      width - gridSide(option.grid, 'left') - gridSide(option.grid, 'right');
    expect(plotPx).toBeLessThan(width / 2);
    expectBarsFitTheirBucket(renderBars(option, width, 400, HOUR_MS));
  });

  test('x-axis is a time axis when the first response omits the temporal type entry', () => {
    const { xAxis } = buildMixedOptions(800, [GenericDataType.Numeric]);
    expect(xAxisType(xAxis)).toBe('time');
  });

  test.each([
    [['BIGINT', 'TIMESTAMP']],
    [['BIGINT', 'STRING']],
  ])('x-axis is a time axis when the first response uses raw database type names (%j)', coltypes => {
    const { xAxis } = buildMixedOptions(800, coltypes);
    expect(xAxisType(xAxis)).toBe('time');
  });
});
