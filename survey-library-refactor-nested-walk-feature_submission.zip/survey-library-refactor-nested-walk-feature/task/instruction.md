## Task

We want to consolidate how container questions walk the elements nested inside
them into one shared traversal, instead of each container type carrying its own
copy of that logic.

Today the data verification pass and the incorrect-value cleanup already reach
matrix cells and dynamic-panel items. Once the walk is shared, they should reach
the questions inside choice panels (the panels attached to a choice of a
checkbox, radiogroup, or dropdown) and inside custom and composite questions in
the same way.

Keep this to how container questions reach their nested values: stay in the core
question models and leave the public API surface as it is.

## User stories / requirements

- When data is loaded with setData, it reports bad values held by the questions inside a select question's choice panels, and clearIncorrectValues(true) removes them so the survey's data comes back clean. This holds whether or not the choice that owns the panel is currently selected.
- setData reports bad values held inside the content of a custom question and inside the content panel of a composite question, and clearIncorrectValues(true) removes them so the data comes back clean.
- Completing the survey clears the values held by questions inside a choice panel, the same way it clears an ordinary typed answer.
