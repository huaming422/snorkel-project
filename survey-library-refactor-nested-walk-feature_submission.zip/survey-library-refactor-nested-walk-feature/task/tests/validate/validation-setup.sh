#!/usr/bin/env bash
# validation-setup.sh — environment bootstrap for the validation story runs.
# The image baked the full survey-core dependency closure (incl. vitest) at the
# base commit via `npm ci`, so the normal path is a no-op. Idempotent: the
# install guard only does work if an agent removed node_modules. Offline-first
# against the image bake, with a logged online fallback.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/survey-library}"
cd "$REPO_DIR/packages/survey-core"

# Cut the network path by default so a cache miss fails fast instead of reaching
# a registry.
export npm_config_offline=true

node --version
npm --version

# Dependencies: offline-first against the image bake, logged online fallback.
if [ -d node_modules/.bin ] && [ -x node_modules/.bin/vitest ]; then
    echo "[offline-first] deps already present from image bake"
elif npm ci --offline --prefer-offline > /tmp/validation-setup-install.log 2>&1; then
    echo "[offline-first] deps satisfied from image cache"
elif { unset npm_config_offline; npm ci >> /tmp/validation-setup-install.log 2>&1; }; then
    echo "[validation-setup] deps installed online (image bake was stale)"
else
    tail -40 /tmp/validation-setup-install.log >&2; exit 1
fi

export PATH="$REPO_DIR/packages/survey-core/node_modules/.bin:$PATH"

# Loud smoke guard: the vitest binary and the package's own config must be
# reachable, or every story would fail opaquely.
npx vitest --version
test -f vitest.config.ts

echo "[validation-setup] ready: $(pwd) (node=$(node --version), npm=$(npm --version))"
