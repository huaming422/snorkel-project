// @ts-nocheck
//
// Regression guard: consolidating how container questions traverse their nested
// elements must not change the existing, observable behavior of the containers
// that already worked — matrix cells, dynamic-panel items, multiple-text
// editors, root-key path addressing, the per-call fresh issue array, and the
// matrix total row staying out of the value-cleaning path. Every assertion here
// is true at the base commit and must remain true afterward; it catches a change
// that regresses an already-correct container while wiring up the newly-reached
// ones.
//
// Everything is driven through the public SurveyModel API (setData + the
// returned issue list, clearIncorrectValues(true) + data). No internal
// traversal/helper symbol is referenced. Imports are the pre-existing modules
// the sibling tests already use.

import { describe, expect, test } from "vitest";
import { SurveyModel } from "../src/survey";

// The consumer-visible part of an issue, sorted by path for a stable compare.
function shortSorted(issues) {
  return issues
    .map((i) => ({ type: i.type, path: i.path, value: i.value }))
    .sort((a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : 0));
}

describe("nested traversal regression guard (existing containers unchanged)", () => {
  test("a matrix-dropdown cell reports an invalid choice at its row.col path", () => {
    const survey = new SurveyModel({
      elements: [
        {
          type: "matrixdropdown",
          name: "matrix",
          rows: ["r1"],
          columns: [{ name: "c", cellType: "dropdown", choices: ["a"] }],
        },
      ],
    });
    expect(shortSorted(survey.setData({ matrix: { r1: { c: "z" } } }))).toEqual([
      { type: "invalidChoiceValue", path: "matrix.r1.c", value: "z" },
    ]);
  });

  test("a dynamic matrix cell and a dynamic panel item address from the survey root", () => {
    const survey = new SurveyModel({
      elements: [
        {
          type: "matrixdynamic",
          name: "matrix",
          columns: [{ name: "col", cellType: "dropdown", choices: ["a"] }],
        },
        {
          type: "paneldynamic",
          name: "panel",
          templateElements: [{ type: "dropdown", name: "q", choices: ["a"] }],
        },
      ],
    });
    const issues = survey.setData({
      matrix: [{ col: "z" }],
      panel: [{ q: "a" }, { q: "z" }],
    });
    expect(shortSorted(issues)).toEqual([
      { type: "invalidChoiceValue", path: "matrix[0].col", value: "z" },
      { type: "invalidChoiceValue", path: "panel[1].q", value: "z" },
    ]);
  });

  test("a detail-panel question of a dynamic matrix is reached", () => {
    const survey = new SurveyModel({
      elements: [
        {
          type: "matrixdynamic",
          name: "matrix",
          columns: [{ name: "c", cellType: "text" }],
          detailPanelMode: "underRow",
          detailElements: [{ type: "dropdown", name: "detail", choices: ["a"] }],
        },
      ],
    });
    expect(
      shortSorted(survey.setData({ matrix: [{ c: "x" }, { c: "y", detail: "z" }] }))
    ).toEqual([{ type: "invalidChoiceValue", path: "matrix[1].detail", value: "z" }]);
  });

  test("a multiple-text item is reached and an unknown item is flagged", () => {
    const survey = new SurveyModel({
      elements: [
        { type: "multipletext", name: "q", items: [{ name: "i1" }] },
      ],
    });
    expect(shortSorted(survey.setData({ q: { i1: "a", zz: "x" } }))).toEqual([
      { type: "unknownProperty", path: "q.zz", value: "x" },
    ]);
  });

  test("an unknown key inside a row does not hide a malformed row or an unknown row name", () => {
    const survey = new SurveyModel({
      elements: [
        {
          type: "matrixdropdown",
          name: "q",
          rows: ["r1", "r2"],
          columns: [{ name: "c", cellType: "text" }],
        },
      ],
    });
    expect(
      shortSorted(survey.setData({ q: { r1: { c: 1, zzz: 2 }, r2: "oops", zz: { c: 3 } } }))
    ).toEqual([
      // shortSorted() orders by path string: "q.r1.zzz" < "q.r2" < "q.zz".
      { type: "unknownProperty", path: "q.r1.zzz", value: 2 },
      { type: "invalidValueType", path: "q.r2", value: "oops" },
      { type: "unknownProperty", path: "q.zz", value: { c: 3 } },
    ]);
  });

  test("a fully valid response gives an empty array and setData returns a fresh array each call", () => {
    const survey = new SurveyModel({
      elements: [
        { type: "dropdown", name: "q1", choices: ["a"] },
        { type: "matrixdynamic", name: "m", columns: [{ name: "c", cellType: "text" }] },
      ],
    });
    const first = survey.setData({ q1: "a", m: [{ c: "x" }] });
    expect(first).toEqual([]);
    const second = survey.setData({ q1: "a", m: [{ c: "x" }] });
    expect(second).toEqual([]);
    expect(second).not.toBe(first);
  });

  test("the matrix total row is not a value holder: clearIncorrectValues(true) leaves a valid grid untouched", () => {
    const survey = new SurveyModel({
      elements: [
        {
          type: "matrixdynamic",
          name: "m",
          columns: [{ name: "c", cellType: "text", totalType: "count" }],
        },
      ],
    });
    survey.setData({ m: [{ c: "x" }] });
    survey.clearIncorrectValues(true);
    // The total row is computed and written back under its own derived key, so
    // survey.data carries more than just the grid; the point of this guard is
    // that the grid value itself is a valid holder that cleaning leaves intact,
    // and that the computed total is never treated as an incorrect value to be
    // stripped. Assert the grid survives untouched, and that re-feeding the full
    // data (total key included) reports nothing incorrect.
    expect(survey.data.m).toEqual([{ c: "x" }]);
    expect(survey.setData(survey.data)).toEqual([]);
  });
});
