// @ts-nocheck
import { describe, expect, it } from "vitest";
import { SurveyModel } from "../../src/survey";
import { ComponentCollection } from "../../src/question_custom";
import { getTestCases } from "./validationParams";

// Canonical JSON with recursively sorted object keys — makes the serialized
// form independent of property insertion order (which is not part of the
// behavior under test). Arrays keep their element order.
function canon(v) {
  if (Array.isArray(v)) return "[" + v.map(canon).join(",") + "]";
  if (v && typeof v === "object") {
    return "{" + Object.keys(v).sort().map(k => JSON.stringify(k) + ":" + canon(v[k])).join(",") + "}";
  }
  return JSON.stringify(v);
}

describe("choice_panel_cleared_on_complete", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", ({ inputs, expected }) => {
    const survey = new SurveyModel(JSON.parse(inputs.survey_json));

    // Apply clearInvisibleValues if set
    if (inputs.clear_invisible_values !== undefined && inputs.clear_invisible_values !== null) {
      survey.clearInvisibleValues = inputs.clear_invisible_values;
    }

    // Put a value into the panel's question based on set_via
    if (inputs.set_via === "data") {
      survey.data = JSON.parse(inputs.initial_data_json);
    } else if (inputs.set_via === "typed") {
      survey.setValue("q", JSON.parse(inputs.first_value_json));
      (<any>survey.getQuestionByName("q")).choices[0].panel.getQuestionByName("inner").value = inputs.inner_value;
      survey.setValue("q", JSON.parse(inputs.final_value_json));
    }

    // Complete the survey
    survey.doComplete();

    // Assert final data matches expected
    expect(canon(survey.data)).toBe(expected.final_data_json);
  });
});
