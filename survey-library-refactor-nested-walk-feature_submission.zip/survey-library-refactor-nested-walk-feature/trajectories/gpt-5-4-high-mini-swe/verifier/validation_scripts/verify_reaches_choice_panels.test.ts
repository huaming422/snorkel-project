// @ts-nocheck
import { describe, expect, it } from "vitest";
import { SurveyModel } from "../../src/survey";
import { ComponentCollection } from "../../src/question_custom";
import { getTestCases } from "./validationParams";

// Canonical JSON with recursively sorted object keys — makes the serialized
// form independent of property insertion order (which is not part of the
// behavior under test). Arrays keep their element order.
function canon(v) {
  if (Array.isArray(v)) return "[" + v.map(canon).join(",") + "]";
  if (v && typeof v === "object") {
    return "{" + Object.keys(v).sort().map(k => JSON.stringify(k) + ":" + canon(v[k])).join(",") + "}";
  }
  return JSON.stringify(v);
}

describe("verify_reaches_choice_panels", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", ({ inputs, expected }) => {
    const survey = new SurveyModel(JSON.parse(inputs.survey_json));

    const issues = survey.setData(JSON.parse(inputs.data_json));
    const reported = canon(
      issues.map(i => ({ type: i.type, path: i.path, value: i.value }))
            .sort((a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : 0))
    );

    expect(reported).toBe(expected.reported_issues_sorted_json);

    survey.clearIncorrectValues(true);
    expect(canon(survey.data)).toBe(expected.cleaned_data_json);

    const issuesAfterClear = survey.setData(survey.data);
    expect(issuesAfterClear.length).toBe(expected.issues_after_clear_count);
  });
});
