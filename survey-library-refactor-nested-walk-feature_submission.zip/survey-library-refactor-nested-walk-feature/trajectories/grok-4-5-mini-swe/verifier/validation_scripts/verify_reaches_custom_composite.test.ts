// @ts-nocheck
import { describe, expect, it } from "vitest";
import { SurveyModel } from "../../src/survey";
import { ComponentCollection } from "../../src/question_custom";
import { getTestCases } from "./validationParams";

// Canonical JSON with recursively sorted object keys — makes the serialized
// form independent of property insertion order (which is not part of the
// behavior under test). Arrays keep their element order.
function canon(v) {
  if (Array.isArray(v)) return "[" + v.map(canon).join(",") + "]";
  if (v && typeof v === "object") {
    return "{" + Object.keys(v).sort().map(k => JSON.stringify(k) + ":" + canon(v[k])).join(",") + "}";
  }
  return JSON.stringify(v);
}

describe("verify_reaches_custom_composite", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", ({ inputs, expected }) => {
    // Register components before building the survey
    try {
      ComponentCollection.Instance.add({ name: "cleancustom", questionJSON: { type: "dropdown", choices: ["a"] } });
      ComponentCollection.Instance.add({ name: "cleancomposite", elementsJSON: [{ type: "dropdown", name: "inner", choices: ["a"] }] });

      const survey = new SurveyModel(JSON.parse(inputs.survey_json));

      // Call setData and get issue count
      const issues = survey.setData(JSON.parse(inputs.data_json));
      const reportedCount = issues.length;

      // Assert reported issue count matches expected
      expect(reportedCount).toBe(expected.reported_issue_count);

      // Clear incorrect values and read data
      survey.clearIncorrectValues(true);
      const cleanedData = canon(survey.data);

      // Assert cleaned data matches expected
      expect(cleanedData).toBe(expected.cleaned_data_json);

      // Call setData again and take length
      const issuesAfterClear = survey.setData(survey.data);
      expect(issuesAfterClear.length).toBe(expected.issues_after_clear_count);
    } finally {
      ComponentCollection.Instance.clear();
    }
  });
});
