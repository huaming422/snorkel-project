/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

// Behavioral checks for the Run/Stop control, driven only through each
// component's existing props:
//   - SQL Lab  RunQueryActionButton: queryState prop + runQuery/stopQuery spies,
//     rendered with the repo's custom render helper.
//   - Explore  RunQueryButton:       loading prop + onQuery/onStop spies.
//
// Behavior checked: a press that is still held when the button switches
// between Run and Stop does nothing when it is released, whatever happened in
// between. A press that starts and ends on the same action, a fresh press
// after the switch, and a screen reader or programmatic click (detail 0, no
// preceding press) still perform the action the button shows.

// @ts-nocheck
import configureStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { Menu } from '@superset-ui/core/components/Menu';

import { act, render, fireEvent, screen } from 'spec/helpers/testing-library';
import { initialState, defaultQueryEditor } from 'src/SqlLab/fixtures';
import RunQueryActionButton from 'src/SqlLab/components/RunQueryActionButton';
import { RunQueryButton } from 'src/explore/components/RunQueryButton';

// --- Native DOM event synthesis -------------------------------------------
// JSDOM has no real PointerEvent and does not synthesize the browser's native
// button activation (Enter-on-keydown / Space-on-keyup) or the compatibility
// MouseEvent that follows a touch/pen release. These helpers reproduce those
// native sequences so the checks see what a real browser delivers. Key events
// carry the key, code and keyCode a real keyboard reports.

/** Dispatch pointer metadata even when JSDOM does not implement PointerEvent. */
const pointerEvent = (
  type: string,
  target: Element,
  pointerId = 1,
  pointerType = 'mouse',
) =>
  fireEvent(
    target,
    Object.assign(
      new MouseEvent(type, { bubbles: true, cancelable: true, detail: 1 }),
      { pointerId, pointerType },
    ),
  );

/** A compatibility click after touch/pen: a MouseEvent with no pointer identity. */
const mouseClick = (target: Element) =>
  fireEvent(
    target,
    new MouseEvent('click', { bubbles: true, cancelable: true, detail: 1 }),
  );

const KEYS = {
  Enter: { key: 'Enter', code: 'Enter', keyCode: 13 },
  ' ': { key: ' ', code: 'Space', keyCode: 32 },
  Escape: { key: 'Escape', code: 'Escape', keyCode: 27 },
};

/** A native button fires its click on each Enter keydown unless prevented. */
const keyDown = (target: HTMLElement, key: string, repeat = false) => {
  if (fireEvent.keyDown(target, { ...KEYS[key], repeat }) && key === 'Enter') {
    fireEvent.click(target, { detail: 0 });
  }
};

/** A native button fires its click when Space is released unless prevented. */
const keyUp = (target: HTMLElement, key: string) => {
  if (fireEvent.keyUp(target, KEYS[key]) && key === ' ') {
    fireEvent.click(target, { detail: 0 });
  }
};

const flushTimers = () =>
  act(() => new Promise(resolve => setTimeout(resolve, 0)));

// --------------------------------------------------------------------------
// SQL Lab stack
// --------------------------------------------------------------------------

const middlewares = [thunk];
const mockStore = configureStore(middlewares);

const sqlLabBaseProps = {
  queryEditorId: defaultQueryEditor.id,
  dbId: 1,
  selectedText: null,
  overlayCreateAsMenu: null,
};

const ctasMenu = <Menu items={[{ key: 'table', label: 'CREATE TABLE AS' }]} />;

const renderSqlLab = (startState = 'running', overlayCreateAsMenu = null) => {
  const runQuery = jest.fn();
  const stopQuery = jest.fn();
  const store = mockStore(initialState);
  const element = (queryState: string) => (
    <RunQueryActionButton
      {...sqlLabBaseProps}
      overlayCreateAsMenu={overlayCreateAsMenu}
      queryState={queryState}
      runQuery={runQuery}
      stopQuery={stopQuery}
    />
  );
  const utils = render(element(startState), { useRedux: true, store });
  const switchTo = (queryState: string) => utils.rerender(element(queryState));
  return { ...utils, runQuery, stopQuery, switchTo };
};

describe('RunQueryActionButton (SQL Lab) gesture handling', () => {
  // A pointer press begun on Stop, still held when the query finishes and the
  // button switches to Run, neither runs nor stops on release.
  test('pointer press begun on Stop does not run after completion', () => {
    const { getByRole, getByText, runQuery, stopQuery, switchTo } =
      renderSqlLab('running');
    const button = getByRole('button');
    expect(getByText('Stop')).toBeInTheDocument();

    pointerEvent('pointerdown', button);
    fireEvent.mouseDown(button);
    switchTo('success');
    // The release lands on the same live button element.
    expect(getByRole('button')).toBe(button);
    pointerEvent('pointerup', button);
    fireEvent.mouseUp(button);
    pointerEvent('click', button);

    expect(runQuery).not.toHaveBeenCalled();
    expect(stopQuery).not.toHaveBeenCalled();
  });

  // Mirror case: a press begun on Run, still held when a query starts and the
  // button switches to Stop, neither stops nor runs on release.
  test('pointer press begun on Run does not stop after the query starts', () => {
    const { getByRole, runQuery, stopQuery, switchTo } = renderSqlLab('running');
    switchTo('success');
    const button = getByRole('button');

    pointerEvent('pointerdown', button);
    switchTo('running');
    pointerEvent('click', button);

    expect(runQuery).not.toHaveBeenCalled();
    expect(stopQuery).not.toHaveBeenCalled();
  });

  // A touch release arrives as a compatibility MouseEvent (a click with no
  // pointerId, positive detail). It belongs to the touch press begun on Stop,
  // so it does nothing after the switch.
  test('touch compatibility click begun on Stop does not run after completion', async () => {
    const { getByRole, runQuery, stopQuery, switchTo } = renderSqlLab('running');
    const button = getByRole('button');

    pointerEvent('pointerdown', button, 7, 'touch');
    switchTo('success');
    pointerEvent('pointerup', button, 7, 'touch');
    pointerEvent('lostpointercapture', button, 7, 'touch');
    await flushTimers();
    mouseClick(button);

    expect(runQuery).not.toHaveBeenCalled();
    expect(stopQuery).not.toHaveBeenCalled();

    // That press is used up; a later pointer click runs the shown action.
    pointerEvent('click', button, 7, 'touch');
    expect(runQuery).toHaveBeenCalledTimes(1);
  });

  // Enter activates a native button on keydown and repeats while held. A held
  // Enter begun on Stop stops once and does not run after the query completes.
  test('held Enter begun on Stop does not run after completion', () => {
    const { getByRole, runQuery, stopQuery, switchTo } = renderSqlLab('running');
    const button = getByRole('button');

    keyDown(button, 'Enter');
    expect(stopQuery).toHaveBeenCalledTimes(1);
    switchTo('success');
    keyDown(button, 'Enter', true);
    keyDown(button, 'Enter', true);
    keyUp(button, 'Enter');

    expect(runQuery).not.toHaveBeenCalled();
    expect(stopQuery).toHaveBeenCalledTimes(1);

    // A fresh Enter after completion runs normally.
    keyDown(button, 'Enter');
    keyUp(button, 'Enter');
    expect(runQuery).toHaveBeenCalledTimes(1);
  });

  // Space activates a native button on keyup. A held Space begun on Stop does
  // not run after the query completes.
  test('held Space begun on Stop does not run after completion', () => {
    const { getByRole, runQuery, stopQuery, switchTo } = renderSqlLab('running');
    const button = getByRole('button');

    keyDown(button, ' ');
    switchTo('success');
    keyDown(button, ' ', true);
    keyUp(button, ' ');

    expect(runQuery).not.toHaveBeenCalled();
    expect(stopQuery).not.toHaveBeenCalled();

    // A fresh Space after completion runs normally.
    keyDown(button, ' ');
    keyUp(button, ' ');
    expect(runQuery).toHaveBeenCalledTimes(1);
    expect(stopQuery).not.toHaveBeenCalled();
  });

  // Escape pressed during a held Space begun on Stop: the release still does
  // nothing, and a later screen reader click runs the shown action.
  test('Space press begun on Stop with Escape before release does not run, a later screen reader click does', () => {
    const { getByRole, runQuery, stopQuery, switchTo } = renderSqlLab('running');
    const button = getByRole('button');

    keyDown(button, ' ');
    switchTo('success');
    keyDown(button, 'Escape');
    keyUp(button, ' ');

    expect(runQuery).not.toHaveBeenCalled();
    expect(stopQuery).not.toHaveBeenCalled();

    fireEvent.click(button, { detail: 0 });
    expect(runQuery).toHaveBeenCalledTimes(1);
    expect(stopQuery).not.toHaveBeenCalled();
  });

  // Focus can leave the button while the mouse is held (the page moves focus
  // when a query finishes, for example). The release still lands on the
  // button and must not run.
  test('focus leaving during a pointer press begun on Stop does not run after completion', () => {
    const { getByRole, runQuery, stopQuery, switchTo } = renderSqlLab('running');
    const button = getByRole('button');

    pointerEvent('pointerdown', button);
    fireEvent.blur(button);
    switchTo('success');
    pointerEvent('pointerup', button);
    pointerEvent('click', button);

    expect(runQuery).not.toHaveBeenCalled();
    expect(stopQuery).not.toHaveBeenCalled();
  });

  // A press released off the button never produces a click. It must not stop
  // a later screen reader click from running the shown action.
  test('a pointer press released off the button does not block a later screen reader click', async () => {
    const { getByRole, runQuery, stopQuery, switchTo } = renderSqlLab('running');
    const button = getByRole('button');

    pointerEvent('pointerdown', button);
    switchTo('success');
    pointerEvent('pointerup', document.body);
    await flushTimers();
    fireEvent.click(button, { detail: 0 });

    expect(runQuery).toHaveBeenCalledTimes(1);
    expect(stopQuery).not.toHaveBeenCalled();
  });

  // The split Run button shown when CTAS/CVAS is allowed behaves the same.
  test('pointer press begun on Stop does not run after completion with the CTAS/CVAS menu', () => {
    const { getAllByRole, runQuery, stopQuery, switchTo } = renderSqlLab(
      'running',
      ctasMenu,
    );
    const mainButton = getAllByRole('button')[0];

    pointerEvent('pointerdown', mainButton);
    switchTo('success');
    pointerEvent('pointerup', mainButton);
    pointerEvent('click', mainButton);

    expect(runQuery).not.toHaveBeenCalled();
    expect(stopQuery).not.toHaveBeenCalled();
  });

  // A screen reader or programmatic activation arrives as a detail-0 click
  // with no preceding press. It performs the action the button shows.
  test('a detail-0 click with no prior press runs the shown action', () => {
    const { getByRole, runQuery, stopQuery, switchTo } = renderSqlLab('running');
    switchTo('success');
    const button = getByRole('button');

    fireEvent.click(button, { detail: 0 });

    expect(runQuery).toHaveBeenCalledTimes(1);
    expect(stopQuery).not.toHaveBeenCalled();
  });

  // An ordinary press and release with no switch in between performs the
  // shown action, both ways.
  test('a normal click on Run runs, and on Stop stops', () => {
    const run = renderSqlLab('success');
    const runButton = run.getByRole('button');
    pointerEvent('pointerdown', runButton);
    pointerEvent('pointerup', runButton);
    pointerEvent('click', runButton);
    expect(run.runQuery).toHaveBeenCalledTimes(1);
    expect(run.stopQuery).not.toHaveBeenCalled();
    run.unmount();

    const stop = renderSqlLab('running');
    const stopButton = stop.getByRole('button');
    pointerEvent('pointerdown', stopButton);
    pointerEvent('pointerup', stopButton);
    pointerEvent('click', stopButton);
    expect(stop.stopQuery).toHaveBeenCalledTimes(1);
    expect(stop.runQuery).not.toHaveBeenCalled();
  });

  // Space pressed and released with no switch in between performs the shown
  // action, both ways.
  test('a Space press on Run runs, and on Stop stops', () => {
    const run = renderSqlLab('success');
    const runButton = run.getByRole('button');
    keyDown(runButton, ' ');
    keyUp(runButton, ' ');
    expect(run.runQuery).toHaveBeenCalledTimes(1);
    expect(run.stopQuery).not.toHaveBeenCalled();
    run.unmount();

    const stop = renderSqlLab('running');
    const stopButton = stop.getByRole('button');
    keyDown(stopButton, ' ');
    keyUp(stopButton, ' ');
    expect(stop.stopQuery).toHaveBeenCalledTimes(1);
    expect(stop.runQuery).not.toHaveBeenCalled();
  });

  // The main part of the split Run button shown when CTAS/CVAS is allowed
  // runs and stops on a normal click or Space press, like the plain button.
  test('the split Run button with the CTAS/CVAS menu runs, and stops, on a normal click or Space press', () => {
    const run = renderSqlLab('success', ctasMenu);
    const runButton = run.getAllByRole('button')[0];
    expect(runButton).toHaveTextContent('Run');
    pointerEvent('pointerdown', runButton);
    pointerEvent('pointerup', runButton);
    pointerEvent('click', runButton);
    expect(run.runQuery).toHaveBeenCalledTimes(1);
    keyDown(runButton, ' ');
    keyUp(runButton, ' ');
    expect(run.runQuery).toHaveBeenCalledTimes(2);
    expect(run.stopQuery).not.toHaveBeenCalled();
    run.unmount();

    const stop = renderSqlLab('running', ctasMenu);
    const stopButton = stop.getAllByRole('button')[0];
    expect(stopButton).toHaveTextContent('Stop');
    pointerEvent('pointerdown', stopButton);
    pointerEvent('pointerup', stopButton);
    pointerEvent('click', stopButton);
    expect(stop.stopQuery).toHaveBeenCalledTimes(1);
    keyDown(stopButton, ' ');
    keyUp(stopButton, ' ');
    expect(stop.stopQuery).toHaveBeenCalledTimes(2);
    expect(stop.runQuery).not.toHaveBeenCalled();
  });
});

// --------------------------------------------------------------------------
// Explore (chart builder) stack
// --------------------------------------------------------------------------

const exploreProps = (overrides: Record<string, any> = {}) => ({
  loading: false,
  onQuery: jest.fn(),
  onStop: jest.fn(),
  errorMessage: null,
  isNewChart: false,
  canStopQuery: true,
  chartIsStale: true,
  ...overrides,
});

const renderExplore = (startLoading = true) => {
  const props = exploreProps({ loading: startLoading });
  const utils = render(<RunQueryButton {...props} />);
  const finishQuery = () =>
    utils.rerender(<RunQueryButton {...props} loading={false} />);
  const startQuery = () =>
    utils.rerender(<RunQueryButton {...props} loading />);
  return { ...utils, ...props, finishQuery, startQuery };
};

describe('RunQueryButton (Explore) gesture handling', () => {
  // A pointer press begun on Stop, still held when the chart query finishes
  // and the button switches to Update chart, does nothing on release.
  test('pointer press begun on Stop does not update the chart after completion', () => {
    const { onQuery, onStop, finishQuery } = renderExplore(true);
    const button = screen.getByRole('button', { name: /Stop/ });

    pointerEvent('pointerdown', button);
    fireEvent.mouseDown(button);
    finishQuery();
    // The release lands on the same live button element.
    expect(screen.getByRole('button')).toBe(button);
    pointerEvent('pointerup', button);
    fireEvent.mouseUp(button);
    pointerEvent('click', button);

    expect(onQuery).not.toHaveBeenCalled();
    expect(onStop).not.toHaveBeenCalled();

    // A fresh press after completion updates the chart normally.
    pointerEvent('pointerdown', button);
    pointerEvent('click', button);
    expect(onQuery).toHaveBeenCalledTimes(1);
  });

  // Mirror case: a press begun on Update chart, still held when a query
  // starts and the button switches to Stop, neither stops nor starts another
  // chart query on release.
  test('pointer press begun on Update chart does not rebuild after the query starts', () => {
    const { onQuery, onStop, startQuery } = renderExplore(false);
    const button = screen.getByRole('button', { name: 'Update chart' });

    pointerEvent('pointerdown', button);
    fireEvent.mouseDown(button);
    startQuery();
    pointerEvent('pointerup', button);
    fireEvent.mouseUp(button);
    pointerEvent('click', button);

    expect(onQuery).not.toHaveBeenCalled();
    expect(onStop).not.toHaveBeenCalled();
  });

  // Touch compatibility MouseEvent on the Explore button.
  test('touch compatibility click begun on Stop does not update after completion', async () => {
    const { onQuery, onStop, finishQuery } = renderExplore(true);
    const button = screen.getByRole('button');

    pointerEvent('pointerdown', button, 7, 'touch');
    finishQuery();
    pointerEvent('pointerup', button, 7, 'touch');
    pointerEvent('lostpointercapture', button, 7, 'touch');
    await flushTimers();
    mouseClick(button);

    expect(onQuery).not.toHaveBeenCalled();
    expect(onStop).not.toHaveBeenCalled();

    pointerEvent('click', button, 7, 'touch');
    expect(onQuery).toHaveBeenCalledTimes(1);
  });

  // Held Enter (activates on keydown, repeats) and held Space (activates on
  // keyup) begun on Stop.
  test('held Enter begun on Stop does not update after completion', () => {
    const { onQuery, onStop, finishQuery } = renderExplore(true);
    const button = screen.getByRole('button', { name: /Stop/ });

    keyDown(button, 'Enter');
    expect(onStop).toHaveBeenCalledTimes(1);
    finishQuery();
    keyDown(button, 'Enter', true);
    keyUp(button, 'Enter');

    expect(onQuery).not.toHaveBeenCalled();
    expect(onStop).toHaveBeenCalledTimes(1);

    keyDown(button, 'Enter');
    keyUp(button, 'Enter');
    expect(onQuery).toHaveBeenCalledTimes(1);
  });

  test('held Space begun on Stop does not update after completion', () => {
    const { onQuery, onStop, finishQuery } = renderExplore(true);
    const button = screen.getByRole('button', { name: /Stop/ });

    keyDown(button, ' ');
    finishQuery();
    keyDown(button, ' ', true);
    keyUp(button, ' ');

    expect(onQuery).not.toHaveBeenCalled();
    expect(onStop).not.toHaveBeenCalled();

    // A fresh Space after completion updates the chart normally.
    keyDown(button, ' ');
    keyUp(button, ' ');
    expect(onQuery).toHaveBeenCalledTimes(1);
    expect(onStop).not.toHaveBeenCalled();
  });

  // Escape pressed during a held Space begun on Stop: the release still does
  // nothing, and a later screen reader click updates the chart.
  test('Space press begun on Stop with Escape before release does not update, a later screen reader click does', () => {
    const { onQuery, onStop, finishQuery } = renderExplore(true);
    const button = screen.getByRole('button');

    keyDown(button, ' ');
    finishQuery();
    keyDown(button, 'Escape');
    keyUp(button, ' ');

    expect(onQuery).not.toHaveBeenCalled();
    expect(onStop).not.toHaveBeenCalled();

    fireEvent.click(button, { detail: 0 });
    expect(onQuery).toHaveBeenCalledTimes(1);
    expect(onStop).not.toHaveBeenCalled();
  });

  // Focus leaving the button during a held pointer press begun on Stop.
  test('focus leaving during a pointer press begun on Stop does not update after completion', () => {
    const { onQuery, onStop, finishQuery } = renderExplore(true);
    const button = screen.getByRole('button');

    pointerEvent('pointerdown', button);
    fireEvent.blur(button);
    finishQuery();
    pointerEvent('pointerup', button);
    pointerEvent('click', button);

    expect(onQuery).not.toHaveBeenCalled();
    expect(onStop).not.toHaveBeenCalled();
  });

  // A press released off the button must not stop a later screen reader click
  // from updating the chart.
  test('a pointer press released off the button does not block a later screen reader click', async () => {
    const { onQuery, onStop, finishQuery } = renderExplore(true);
    const button = screen.getByRole('button');

    pointerEvent('pointerdown', button);
    finishQuery();
    pointerEvent('pointerup', document.body);
    await flushTimers();
    fireEvent.click(button, { detail: 0 });

    expect(onQuery).toHaveBeenCalledTimes(1);
    expect(onStop).not.toHaveBeenCalled();
  });

  // Detail-0 screen reader click with no prior press performs the shown action.
  test('a detail-0 click with no prior press updates the chart', () => {
    const { onQuery, onStop, finishQuery } = renderExplore(true);
    finishQuery();
    const button = screen.getByRole('button', { name: 'Update chart' });

    fireEvent.click(button, { detail: 0 });

    expect(onQuery).toHaveBeenCalledTimes(1);
    expect(onStop).not.toHaveBeenCalled();
  });

  // Ordinary press and release with no switch in between, both ways.
  test('a normal click on Update chart runs, and on Stop stops', () => {
    const run = renderExplore(false);
    const runButton = screen.getByRole('button', { name: 'Update chart' });
    pointerEvent('pointerdown', runButton);
    pointerEvent('pointerup', runButton);
    pointerEvent('click', runButton);
    expect(run.onQuery).toHaveBeenCalledTimes(1);
    expect(run.onStop).not.toHaveBeenCalled();

    run.unmount();

    const stop = renderExplore(true);
    const stopButton = screen.getByRole('button', { name: /Stop/ });
    pointerEvent('pointerdown', stopButton);
    pointerEvent('pointerup', stopButton);
    pointerEvent('click', stopButton);
    expect(stop.onStop).toHaveBeenCalledTimes(1);
    expect(stop.onQuery).not.toHaveBeenCalled();
  });

  // Space pressed and released with no switch in between, both ways.
  test('a Space press on Update chart runs, and on Stop stops', () => {
    const run = renderExplore(false);
    const runButton = screen.getByRole('button', { name: 'Update chart' });
    keyDown(runButton, ' ');
    keyUp(runButton, ' ');
    expect(run.onQuery).toHaveBeenCalledTimes(1);
    expect(run.onStop).not.toHaveBeenCalled();

    run.unmount();

    const stop = renderExplore(true);
    const stopButton = screen.getByRole('button', { name: /Stop/ });
    keyDown(stopButton, ' ');
    keyUp(stopButton, ' ');
    expect(stop.onStop).toHaveBeenCalledTimes(1);
    expect(stop.onQuery).not.toHaveBeenCalled();
  });
});
