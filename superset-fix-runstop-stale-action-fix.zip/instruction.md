## Task

The Run/Stop button in SQL Lab and the Update chart/Stop button in Explore can do the opposite of what the user pressed. If a query finishes while someone is holding down Stop, the button switches to Run under them, and letting go starts a new query. It goes the other way too: a press that started on Run can end as a Stop if a query starts in the meantime. Mouse, touch and keyboard users all run into it, including people holding Enter or Space, and so does SQL Lab's split Run button when CTAS/CVAS is available. It depends on timing, so it's hard to reproduce by hand.

If the button switches while a press is still held, that press shouldn't do anything else, either when it's released or from a held key repeating. The user can press again once they see the new label. Normal clicks and key presses, and screen reader or programmatic clicks, should keep doing what the button shows, even right after an earlier press was let go off the button.
