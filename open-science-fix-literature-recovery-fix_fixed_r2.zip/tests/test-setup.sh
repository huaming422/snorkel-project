#!/usr/bin/env bash
# Environment bootstrap for the verifier. Sourced (not exec'd) so env vars
# set here stay live for the verifier subprocess. The image already holds the
# dependencies, so in the common case this script does nothing; it only
# repairs or installs what the verifier needs when that is missing.
# It never exits non-zero: a failed repair is logged and the run continues.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/open-science}"
export REPO_DIR
cd "$REPO_DIR"

# js.py reads verify.toml via tomllib (Python 3.11+) or tomli (3.10). The
# Ubuntu 22.04 base image ships 3.10 with neither, so verify.toml could be
# silently dropped and the runner fall back to its default. Install tomli
# defensively, at an exact pin. (The verifier venv under VERIFIER_PYTHON is
# Python 3.12 and already has tomllib; this only guards a system-python3
# reader.)
_install_tomli() { python3 -m pip install --quiet "tomli==2.2.1" "$@"; }
if ! python3 -c "import tomllib" >/dev/null 2>&1 && \
   ! python3 -c "import tomli"   >/dev/null 2>&1; then
    _install_tomli >/dev/null 2>&1 \
        || _install_tomli --break-system-packages >/dev/null 2>&1 \
        || true
fi

# The dependency tree is baked into the image at the base commit. vitest must
# be resolvable from node_modules; a miss means a corrupt image. Reinstall
# offline-first (cache is warm from the build), fall back to online only if
# the offline install cannot satisfy the lockfile.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/; reinstalling." >&2
    if ! npm ci --prefer-offline --no-audit --no-fund >/tmp/test-setup-npm.log 2>&1; then
        echo "test-setup.sh: offline npm ci failed; retrying with network." >&2
        npm ci --no-audit --no-fund >>/tmp/test-setup-npm.log 2>&1 \
            || { tail -80 /tmp/test-setup-npm.log >&2;                  echo "test-setup.sh: npm ci failed; the verifier will report the missing modules." >&2; }
    fi
fi

# The suite's pretest step generates the Prisma client; the main-process
# catalog tests import `@prisma/client` against a real migrated SQLite db,
# so the generated client must be present. check-prisma-client.mjs regenerates
# it if it is stale or missing. Run it now so a cold client does not surface
# as a confusing import error mid-suite.
if [ -f scripts/check-prisma-client.mjs ]; then
    node scripts/check-prisma-client.mjs >/tmp/test-setup-prisma.log 2>&1 \
        || { echo "test-setup.sh: prisma client check failed:" >&2; \
             tail -80 /tmp/test-setup-prisma.log >&2; \
             npx prisma generate >>/tmp/test-setup-prisma.log 2>&1 \
                 || { tail -80 /tmp/test-setup-prisma.log >&2;                       echo "test-setup.sh: prisma generate failed; continuing." >&2; }; }
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR node=$(node --version 2>/dev/null) vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
