import { describe, expect, it, vi } from 'vitest';
import { z } from 'zod';
import { Agent } from '../src/agent';
import { ModelBehaviorError } from '../src/errors';
import type { ModelResponse } from '../src/model';
import { Runner } from '../src/run';
import { tool, hostedMcpTool } from '../src/tool';
import type * as protocol from '../src/types/protocol';
import { Usage } from '../src/usage';
import { FakeModel, fakeModelMessage } from './stubs';
import { RunState } from '../src/runState';

// Build a single scripted model turn. Mirrors the helper the package's own
// suites use so the scripted calls look exactly like provider output.
function response(output: protocol.ModelItem[]): ModelResponse {
  return { output, usage: new Usage() };
}

function functionCall(
  callId: string,
  name: string,
  args: Record<string, unknown>,
): protocol.FunctionCallItem {
  return {
    type: 'function_call',
    callId,
    name,
    status: 'completed',
    arguments: JSON.stringify(args),
  };
}

function hostedMcpApproval(
  approvalRequestId: string,
  toolName: string,
  args: Record<string, unknown>,
): protocol.HostedToolCallItem {
  return {
    type: 'hosted_tool_call',
    name: 'mcp_approval_request',
    providerData: {
      type: 'mcp_approval_request',
      id: approvalRequestId,
      name: toolName,
      arguments: JSON.stringify(args),
    },
  } as protocol.HostedToolCallItem;
}

// The behavior under test is observed only through the public run()/RunState
// surface: whether a tool body executes, with which arguments, and whether the
// run proceeds as if a decision were inherited. Nothing here reaches into how a
// solution records which invocation a per-call decision belongs to — any
// binding that keeps a decision tied to the call it was made for satisfies
// these.
describe('tool approval and committed-result binding by invocation', () => {
  // A tool is approved once at a given call ID; on resume the model reuses that
  // same call ID for a DIFFERENT invocation (changed arguments). The
  // differently-argued invocation must not run on the first one's approval. A
  // correct run may re-ask for approval (surfacing a fresh interruption) or
  // refuse outright, but it must never silently execute the changed call.
  // without asking — which this test forbids.
  it('does not run an approved tool again when a different invocation reuses the approved call id', async () => {
    const execute = vi.fn(async ({ value }: { value: string }) => value);
    const approvalTool = tool({
      name: 'approval_tool',
      description: 'Requires per-call approval before running.',
      parameters: z.object({ value: z.string() }),
      needsApproval: true,
      execute,
    });
    const siblingExecute = vi.fn(async () => 'sibling');
    const siblingTool = tool({
      name: 'sibling_tool',
      description: 'Accompanies the reused invocation in the same turn.',
      parameters: z.object({}),
      execute: siblingExecute,
    });
    const callId = 'reused-approved-call';
    const model = new FakeModel([
      response([functionCall(callId, approvalTool.name, { value: 'safe' })]),
      response([
        functionCall(callId, approvalTool.name, { value: 'changed' }),
        functionCall('sibling-call', siblingTool.name, {}),
      ]),
      response([fakeModelMessage('done')]),
    ]);
    const agent = new Agent({
      name: 'ChangedArgumentsAgent',
      model,
      tools: [approvalTool, siblingTool],
    });
    const runner = new Runner();

    const interrupted = await runner.run(agent, 'start');
    expect(interrupted.interruptions).toHaveLength(1);
    interrupted.state.approve(interrupted.interruptions[0]);

    const outcome = await runner.run(agent, interrupted.state).then(
      (result) => ({ ok: true as const, result }),
      (error) => ({ ok: false as const, error }),
    );

    const executedValues = execute.mock.calls.map((call) => call[0]?.value);
    expect(executedValues).not.toContain('changed');
    expect(executedValues.filter((value) => value === 'safe')).toHaveLength(1);
    if (outcome.ok) {
      expect(outcome.result.interruptions.length).toBeGreaterThan(0);
    } else {
      expect(outcome.error).toBeInstanceOf(ModelBehaviorError);
    }
  });

  it('reuses a committed result for an exact replay of the same invocation', async () => {
    const execute = vi.fn(async (_args: { first: number; second: number }) => {
      return 'committed';
    });
    const approvalTool = tool({
      name: 'replay_tool',
      description: 'Requires approval; its committed result is replayable.',
      parameters: z.object({ first: z.number(), second: z.number() }),
      needsApproval: true,
      execute,
    });
    const callId = 'exact-replay-call';
    const model = new FakeModel([
      response([
        functionCall(callId, approvalTool.name, { first: 1, second: 2 }),
      ]),
      response([
        functionCall(callId, approvalTool.name, { second: 2, first: 1 }),
      ]),
      response([fakeModelMessage('done')]),
    ]);
    const agent = new Agent({
      name: 'ExactReplayAgent',
      model,
      tools: [approvalTool],
    });
    const runner = new Runner();

    const interrupted = await runner.run(agent, 'start');
    expect(interrupted.interruptions).toHaveLength(1);
    interrupted.state.approve(interrupted.interruptions[0]);
    const result = await runner.run(agent, interrupted.state);

    expect(result.finalOutput).toBe('done');
    expect(execute).toHaveBeenCalledTimes(1);
  });

  it('runs an ordinary approved invocation exactly once on resume', async () => {
    const execute = vi.fn(async ({ value }: { value: string }) => value);
    const approvalTool = tool({
      name: 'single_approval_tool',
      description: 'Requires approval before running once.',
      parameters: z.object({ value: z.string() }),
      needsApproval: true,
      execute,
    });
    const model = new FakeModel([
      response([
        functionCall('single-call', approvalTool.name, { value: 'ok' }),
      ]),
      response([fakeModelMessage('done')]),
    ]);
    const agent = new Agent({
      name: 'SingleApprovalAgent',
      model,
      tools: [approvalTool],
    });
    const runner = new Runner();

    const interrupted = await runner.run(agent, 'start');
    expect(interrupted.interruptions).toHaveLength(1);
    interrupted.state.approve(interrupted.interruptions[0]);
    const result = await runner.run(agent, interrupted.state);

    expect(result.finalOutput).toBe('done');
    expect(execute).toHaveBeenCalledTimes(1);
    expect(execute.mock.calls[0][0]).toEqual({ value: 'ok' });
  });

  it('preserves approval binding after a RunState serialization round trip', async () => {
    const execute = vi.fn(async ({ value }: { value: string }) => value);
    const approvalTool = tool({
      name: 'serialized_approval_tool',
      description: 'Requires approval before running.',
      parameters: z.object({ value: z.string() }),
      needsApproval: true,
      execute,
    });

    const callId = 'serialized-reused-call';
    const model = new FakeModel([
      response([
        functionCall(callId, approvalTool.name, { value: 'safe' }),
      ]),
      response([
        functionCall(callId, approvalTool.name, { value: 'changed' }),
      ]),
      response([fakeModelMessage('done')]),
    ]);

    const agent = new Agent({
      name: 'SerializedApprovalAgent',
      model,
      tools: [approvalTool],
    });
    const runner = new Runner();

    const interrupted = await runner.run(agent, 'start');
    expect(interrupted.interruptions).toHaveLength(1);
    interrupted.state.approve(interrupted.interruptions[0]);

    const restoredState = RunState.fromString(interrupted.state.toString());

    const outcome = await runner.run(agent, restoredState).then(
      (result) => ({ ok: true as const, result }),
      (error) => ({ ok: false as const, error }),
    );

    const executedValues = execute.mock.calls.map((call) => call[0]?.value);

    expect(executedValues).not.toContain('changed');

    if (outcome.ok) {
      expect(outcome.result.interruptions.length).toBeGreaterThan(0);
    } else {
      expect(outcome.error).toBeInstanceOf(ModelBehaviorError);
    }
  });

  it('does not inherit hosted MCP approval for a changed invocation', async () => {
    const hostedMcp = hostedMcpTool({
      serverLabel: 'approval-test-server',
      requireApproval: 'always',
    });

    const approvalRequestId = 'reused-hosted-mcp-approval';

    const model = new FakeModel([
      response([
        hostedMcpApproval(approvalRequestId, 'remote_lookup', {
          query: 'safe',
        }),
      ]),
      response([
        hostedMcpApproval(approvalRequestId, 'remote_lookup', {
          query: 'changed',
        }),
      ]),
      response([fakeModelMessage('done')]),
    ]);

    const agent = new Agent({
      name: 'HostedMcpChangedInvocationAgent',
      model,
      tools: [hostedMcp],
    });

    const runner = new Runner();

    const interrupted = await runner.run(agent, 'start');
    expect(interrupted.interruptions).toHaveLength(1);
    interrupted.state.approve(interrupted.interruptions[0]);

    const outcome = await runner.run(agent, interrupted.state).then(
      (result) => ({ ok: true as const, result }),
      (error) => ({ ok: false as const, error }),
    );

    if (outcome.ok) {
      expect(outcome.result.interruptions.length).toBeGreaterThan(0);
      expect(outcome.result.finalOutput).not.toBe('done');
    } else {
      expect(outcome.error).toBeInstanceOf(ModelBehaviorError);
    }
  });
});
