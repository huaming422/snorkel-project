## Task

`uplc` can be told which Plutus language version a script targets, but not which Cardano protocol era it runs under. The ledger changes how some builtins are costed from one era to the next, so a script evaluated with the right language version can still come back with a different execution budget than it really has on chain.

`uplc` itself needs a way to run a program at an explicit protocol major version, for all three Plutus languages, both with its built-in default costs and with a ledger cost vector the caller supplies, as language-only evaluation allows today. Add this next to what is there: the language-only entry points keep their signatures, and their results stay the same with the default costs and with any cost vector no longer than today's. The crate and its existing tests still have to build and pass.

The era rules. Chang is protocol major version 9 and Van Rossem is 11. PlutusV3 runs only from Chang on, so the pre-Chang rule concerns PlutusV1 and PlutusV2. When a supplied cost vector is read, before Chang `multiplyInteger`'s CPU cost grows with the sum of the two argument sizes rather than their product, and from Van Rossem on `divideInteger` and `modInteger` no longer charge a flat CPU cost when the first argument is the smaller one: they apply their usual size model with the larger argument size first and the smaller second. Whichever costs are used, from Van Rossem on, for every language, a string's memory size is its UTF-8 length in bytes divided by four and rounded up, so 0 for the empty string, instead of its character count. The PlutusV3 cost vector under Van Rossem is longer than today's: it keeps every existing entry where it is and appends entries for builtins this repo cannot run yet.

## User stories / requirements

- With a supplied cost vector, evaluating under an explicit protocol major version reads it by that era's rules for every Plutus language, so the same program and vector can cost differently before Chang, after it and from Van Rossem on, while a protocol whose rules match today's gives exactly the language-only result.
- Under Van Rossem, a PlutusV3 cost vector longer than today's still costs every builtin whose entries it carries, while a vector that stops short of a builtin's entries leaves it at the unavailable cost, so running it fails.
- From Van Rossem on, every Plutus language sizes strings by the Van Rossem rule in every builtin whose cost depends on a string's size, with the default costs or a supplied vector, while earlier protocols and language-only evaluation keep counting characters.
