"""Build and regression checks for the `uplc` crate.

Three checks run here: the `uplc` crate must still compile; the crate's
existing unit, integration and doc tests must still pass; and every
language-only evaluation entry point of `Program` keeps its signature and its
results. All three drive pre-existing interfaces only and name no new symbol.

Runs under VERIFIER_PYTHON (no repository imports) and shells out to cargo.
The cargo toolchain and a warm offline target dir come from the image and
tests/test-setup.sh.
"""

from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path

import pytest

REPO_DIR = Path(f"/repo/{os.environ.get('REPO_NAME', 'aiken')}")

# Offline: the image holds the full dependency closure and test-setup.sh warmed
# the target dir. A cache miss should fail fast rather than hang without a network.
_CARGO_ENV = {**os.environ, "CARGO_NET_OFFLINE": "true"}


def _run_cargo(*args: str, timeout: int = 600) -> subprocess.CompletedProcess:
    cmd = ["cargo", *args]
    return subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=timeout,
        cwd=str(REPO_DIR),
        env=_CARGO_ENV,
        check=False,
    )


_RESULT_LINE = re.compile(
    r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed",
    re.MULTILINE,
)


def test_uplc_crate_still_compiles() -> None:
    """`cargo check -p uplc` must succeed."""
    proc = _run_cargo("check", "-p", "uplc", "--offline", timeout=600)
    assert proc.returncode == 0, (
        "`cargo check -p uplc` failed: the uplc crate no longer compiles.\n"
        f"--- last stdout ---\n{proc.stdout[-2000:]}\n"
        f"--- last stderr ---\n{proc.stderr[-3000:]}"
    )


# The crate's pre-existing test targets: its unit tests, the three integration
# test files that ship with it, and its doc tests. Named explicitly so that test
# files added by the change itself are not counted as existing tests.
_EXISTING_TEST_RUNS = (
    ("--lib", "--test", "conformance", "--test", "integ_tests", "--test", "pretty_tests"),
    ("--doc",),
)


def test_uplc_existing_tests_pass() -> None:
    """The crate's existing unit, integration and doc tests must still pass."""
    for targets in _EXISTING_TEST_RUNS:
        label = "cargo test -p uplc " + " ".join(targets)
        proc = _run_cargo("test", "-p", "uplc", *targets, "--offline", timeout=720)
        summaries = _RESULT_LINE.findall(proc.stdout + "\n" + proc.stderr)

        assert proc.returncode == 0, (
            f"`{label}` exited with {proc.returncode}: an existing test failed "
            "or a test target did not build.\n"
            f"--- last stdout ---\n{proc.stdout[-2000:]}\n"
            f"--- last stderr ---\n{proc.stderr[-3000:]}"
        )
        assert summaries, (
            f"expected 'test result: ...' summary lines from `{label}`, got none; "
            "a test target may not have built.\n"
            f"--- stdout ---\n{proc.stdout[-2000:]}"
        )
        total_passed = sum(int(p) for _, p, _ in summaries)
        total_failed = sum(int(f) for _, _, f in summaries)
        assert total_failed == 0, (
            f"{total_failed} existing uplc test(s) failed in `{label}`.\n"
            f"--- last stdout ---\n{proc.stdout[-2000:]}"
        )
        assert total_passed > 0, (
            f"expected at least one test to pass in `{label}`; saw zero.\n"
            f"--- last stdout ---\n{proc.stdout[-2000:]}"
        )


# Every language-only evaluation entry point of `Program`, with its base-commit
# signature and its base-commit result on four programs (string and integer
# builtins), under the default costs and today's cost-vector lengths.
_LANGUAGE_ONLY_TEST = r'''// Language-only evaluation entry points: their signatures and their results
// must match the base commit's.
use num_bigint::BigInt;
use uplc::ast::{Constant, DeBruijn, NamedDeBruijn, Program, Term};
use uplc::builtins::DefaultFunction as F;
use uplc::machine::cost_model::ExBudget;
use uplc::machine::eval_result::EvalResult;
use uplc::Language;

fn prog(f: F, args: Vec<Constant>) -> Program<NamedDeBruijn> {
    let mut t = Term::Builtin(f);
    for a in args {
        t = Term::Apply { function: t.into(), argument: Term::Constant(a.into()).into() };
    }
    Program { version: (1, 1, 0), term: t }
}

fn int(s: &str) -> Constant {
    Constant::Integer(s.parse::<BigInt>().unwrap())
}

fn programs() -> Vec<(&'static str, Program<NamedDeBruijn>)> {
    let s = "a\u{20ac}\u{20ac}\u{20ac}".to_string();
    vec![
        ("append", prog(F::AppendString, vec![Constant::String(String::new()), Constant::String(s.clone())])),
        ("encode", prog(F::EncodeUtf8, vec![Constant::String(s)])),
        ("divide", prog(F::DivideInteger, vec![int("3"), int("1606938044258990275541962092341162602522202993782792835301376")])),
        ("multiply", prog(F::MultiplyInteger, vec![int("18446744073709551616"), int("340282366920938463463374607431768211456")])),
    ]
}

#[test]
fn language_only_entry_points_unchanged() {
    // Signatures, checked at compile time.
    let named_eval: fn(Program<NamedDeBruijn>, ExBudget) -> EvalResult = Program::<NamedDeBruijn>::eval;
    let named_eval_version: fn(Program<NamedDeBruijn>, ExBudget, &Language) -> EvalResult =
        Program::<NamedDeBruijn>::eval_version;
    let named_eval_as: fn(Program<NamedDeBruijn>, &Language, &[i64], Option<&ExBudget>) -> EvalResult =
        Program::<NamedDeBruijn>::eval_as;
    let named_eval_debug: fn(Program<NamedDeBruijn>, ExBudget, &Language) -> EvalResult =
        Program::<NamedDeBruijn>::eval_debug;
    let debruijn_eval: fn(&Program<DeBruijn>, ExBudget) -> EvalResult = Program::<DeBruijn>::eval;
    let debruijn_eval_version: fn(Program<DeBruijn>, ExBudget, &Language) -> EvalResult =
        Program::<DeBruijn>::eval_version;

    let langs = [("v1", Language::PlutusV1, 166), ("v2", Language::PlutusV2, 175), ("v3", Language::PlutusV3, 297)];
    let mut got: Vec<String> = Vec::new();
    let mut push = |label: String, r: EvalResult| {
        let c = r.cost();
        got.push(format!("{label} {} {} {}", r.result().is_ok(), c.mem, c.cpu));
    };
    for (name, p) in programs() {
        push(format!("{name} eval"), named_eval(p.clone(), ExBudget::default()));
        let db: Program<DeBruijn> = p.clone().into();
        push(format!("{name} debruijn_eval"), debruijn_eval(&db, ExBudget::default()));
        for (ln, l, n) in langs.iter() {
            let costs: Vec<i64> = (0..*n as i64).collect();
            push(format!("{name} eval_version {ln}"), named_eval_version(p.clone(), ExBudget::default(), l));
            push(format!("{name} eval_as {ln}"), named_eval_as(p.clone(), l, &costs, None));
            push(format!("{name} eval_debug {ln}"), named_eval_debug(p.clone(), ExBudget::default(), l));
            push(format!("{name} debruijn_eval_version {ln}"), debruijn_eval_version(db.clone(), ExBudget::default(), l));
        }
    }
    if std::env::var("PRINT_EXPECTED").is_ok() {
        for g in &got {
            println!("EXP {g}");
        }
        return;
    }
    let expected: Vec<String> = EXPECTED.lines().map(|l| l.trim().to_string()).filter(|l| !l.is_empty()).collect();
    assert_eq!(got, expected, "a language-only entry point's result changed");
}

const EXPECTED: &str = r#"
append eval true 608 320928
append debruijn_eval true 608 320928
append eval_version v1 true 608 320928
append eval_as v1 true 184 168
append eval_debug v1 true 608 320928
append debruijn_eval_version v1 true 608 320928
append eval_version v2 true 608 320928
append eval_as v2 true 184 168
append eval_debug v2 true 608 320928
append debruijn_eval_version v2 true 608 320928
append eval_version v3 true 608 320928
append eval_as v3 true 184 168
append eval_debug v3 true 608 320928
append debruijn_eval_version v3 true 608 320928
encode eval true 412 220784
encode debruijn_eval true 412 220784
encode eval_version v1 true 412 220784
encode eval_as v1 true 379 365
encode eval_debug v1 true 412 220784
encode debruijn_eval_version v1 true 412 220784
encode eval_version v2 true 412 220784
encode eval_as v2 true 379 365
encode eval_debug v2 true 412 220784
encode debruijn_eval_version v2 true 412 220784
encode eval_version v3 true 412 220784
encode eval_as v3 true 404 390
encode eval_debug v3 true 412 220784
encode debruijn_eval_version v3 true 412 220784
divide eval true 601 165948
divide debruijn_eval true 601 165948
divide eval_version v1 true 601 165948
divide eval_as v1 true 3044 173
divide eval_debug v1 true 601 165948
divide debruijn_eval_version v1 true 601 165948
divide eval_version v2 true 601 165948
divide eval_as v2 true 3044 173
divide eval_debug v2 true 601 165948
divide debruijn_eval_version v2 true 601 165948
divide eval_version v3 true 601 165948
divide eval_as v3 true 3609 173
divide eval_debug v3 true 601 165948
divide debruijn_eval_version v3 true 601 165948
multiply eval true 605 173648
multiply debruijn_eval true 605 173648
multiply eval_version v1 true 605 173648
multiply eval_as v1 true 837 935
multiply eval_debug v1 true 605 173648
multiply debruijn_eval_version v1 true 605 173648
multiply eval_version v2 true 605 173648
multiply eval_as v2 true 837 935
multiply eval_debug v2 true 605 173648
multiply debruijn_eval_version v2 true 605 173648
multiply eval_version v3 true 605 173648
multiply eval_as v3 true 891 998
multiply eval_debug v3 true 605 173648
multiply debruijn_eval_version v3 true 605 173648
"#;
'''

_LANGUAGE_ONLY_TEST_FILE = "zz_verify_language_only_entry_points"


def test_language_only_entry_points_unchanged() -> None:
    """Language-only entry points keep their signatures and their results."""
    path = REPO_DIR / "crates" / "uplc" / "tests" / f"{_LANGUAGE_ONLY_TEST_FILE}.rs"
    path.write_text(_LANGUAGE_ONLY_TEST)
    try:
        proc = _run_cargo(
            "test", "-p", "uplc", "--test", _LANGUAGE_ONLY_TEST_FILE, "--offline", timeout=720
        )
    finally:
        path.unlink(missing_ok=True)
    assert proc.returncode == 0, (
        "a language-only evaluation entry point changed its signature or its "
        "result.\n"
        f"--- last stdout ---\n{proc.stdout[-3000:]}\n"
        f"--- last stderr ---\n{proc.stderr[-3000:]}"
    )
    assert "test result: ok. 1 passed" in proc.stdout, proc.stdout[-2000:]


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v", "--tb=short"]))
