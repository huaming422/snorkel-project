## Task

our zen chat panel reserves a strip along the bottom of the central editor for itself, so the moment it's open a note or PDF loses that much height off the bottom. we'd rather it float over the content than push it up.

so let's make the zen panel a floating thing people can move around, with one magnetic home at the bottom-center, that remembers where someone parked it.

keep it inside the central editor area, and keep it working in every locale we ship. this is an addition to the zen mode we already have, not a rewrite.

a couple of things are out of scope here: the docked panel overlapping obsidian's status bar, and the floating panel swallowing clicks meant for the content underneath it. leave both of those alone.

## User stories / requirements

- When the zen chat is open over a note or PDF, it floats on top of the content instead of shrinking it, so the content keeps its full height. The chat's own surfaces stay opaque enough to read against whatever sits behind them.
- A user can drag the panel to reposition it over the editor, and it never leaves the central editor area. It stays fully inside even when the panel grows or the editor area shrinks while it's being moved.
- Letting go of the panel near its bottom-center home snaps it back home. Releasing it anywhere else leaves it exactly where it was dropped.
- Next time the user opens the chat it comes back to where they left it, in the same relative spot, even if the window or the sidebars were resized in between.
- The panel can be moved with the keyboard, not just a pointer, and there's a quick way to send it straight back to its home spot.
- While the panel is being dragged, a hint marks its home spot by tracing the panel's own silhouette: just the composer when the history is closed, and a raised step over the narrower history drawer when it is open.
