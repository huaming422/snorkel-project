// @ts-nocheck
//
// Shared Jest harness for the claudian-feat-movable-zen-dock DOM stories.
//
// WHY A HARNESS: the zen panel only becomes draggable/snappable once it is mounted
// inside Obsidian's central-workspace layout with a live tab runtime, and jsdom has
// neither layout nor PointerEvent. Reconstructing that world (workspace split, view,
// tab runtime, pointer/resize polyfills, a fixed 1000x800 host with a 600x100 panel)
// is pure framework plumbing shared by every movement/hint story. It is ported from
// the repo's own pre-existing integration fixture
// (tests/integration/features/chat/zen/ZenMode.dom.test.ts) so it drives the panel
// exactly the way the project's own tests do.
//
// WHAT THIS HARNESS DELIBERATELY DOES NOT KNOW (supplied by the validation agent
// from the submitted patch, so every valid implementation passes):
//   * positionDeps(store)  -> the object merged into the ZenModeController deps that
//                             lets it read/remember the panel position. The harness
//                             only spreads whatever object the submission returns and
//                             reads the position back out of the shared `store`
//                             it handed in (any getPosition/savePosition-style seam
//                             works, named as the controller expects).
//   * readOffset(panel)    -> { x, y } the panel's rendered horizontal/vertical offset
//                             FROM its docked home, in px, right/up positive. The
//                             submission renders this however it likes (CSS custom
//                             properties, or inline left/bottom); it reads it back
//                             the same way.
//   * findGrip(panel)      -> the move handle the panel renders (a button, by its own
//                             accessible label; or whatever element it made draggable).
//
// The harness keeps the remembered position in an in-memory `store` rather than the
// real settings file: these stories grade the DOCK's behaviour (what position it
// decides to remember, what it renders), not the settings KEY or persisted SHAPE —
// those are a separate concern covered by the storage check. The setting key and
// on-disk shape are irrelevant here, by construction.

import '@/providers';

import { deserialize, serialize } from 'node:v8';
import { readFileSync, readdirSync } from 'node:fs';
import path from 'node:path';

import { createClaudianView } from '@test/helpers/features/chat/ClaudianViewHarness';
import { createHarness, releaseSideChatHarnesses } from '@test/helpers/features/chat/SideChatDOMHarness';
import { FakeSideSession } from '@test/helpers/features/chat/SideChatSessionHarness';
import { modelCatalogCases } from '@test/helpers/providerModelCatalogs';
import { fireEvent, within } from '@testing-library/dom';
import { App, Component } from 'obsidian';

import { ChatModelSelectionCoordinator } from '@/app/settings/ChatModelSelectionCoordinator';
import { DEFAULT_CLAUDIAN_SETTINGS } from '@/app/settings/defaultSettings';
import { SettingsCoordinator } from '@/app/settings/SettingsCoordinator';
import { ProviderRegistry } from '@/core/providers/ProviderRegistry';
import { ProviderWorkspaceRegistry } from '@/core/providers/ProviderWorkspaceRegistry';
import { createTabRuntime } from '@/features/chat/tabs/TabRuntimeFactory';
import { destroyTab } from '@/features/chat/tabs/TabLifecycle';
import { ZenModeController } from '@/features/chat/zen/ZenModeController';
import { VaultMentionDataProvider } from '@/shared/mention/VaultMentionDataProvider';

// Fixed jsdom "layout" the fixture pretends to have (jsdom computes none).
const HOST_WIDTH = 1000;
const HOST_HEIGHT = 800;
const PANEL_WIDTH = 600;
const COMPOSER_HEIGHT = 60;
const COMPOSER_GAP = 8; // composer sits this far inside the panel's bottom edge

// ===========================================================================
// panel_floats surface: the real zen stylesheet loaded into jsdom.
// ===========================================================================

/**
 * Mounts the zen panel's DOM (pre-existing structural selectors) with the repo's
 * REAL compiled zen stylesheet applied, and reports — as concrete counts —
 * whether the host reserves a bottom strip for the panel and how many of the
 * panel's surfaces are backed by an opaque colour. Everything here is
 * implementation-agnostic: the selectors pre-date the feature and the values
 * come from getComputedStyle over whatever CSS the submission ships.
 */
export function renderStyledPanel(): {
  elementsReservingBottomStrip: number;
  opaqueSurfaces: number;
} {
  Object.assign(HTMLElement.prototype, {
    empty(this: HTMLElement) { this.replaceChildren(); },
    addClass(this: HTMLElement, ...names: string[]) { this.classList.add(...names); },
    removeClass(this: HTMLElement, ...names: string[]) { this.classList.remove(...names); },
    hasClass(this: HTMLElement, name: string) { return this.classList.contains(name); },
    toggleClass(this: HTMLElement, name: string, force: boolean) { this.classList.toggle(name, force); },
  });

  // Load the WHOLE shipped stylesheet (every .css under src/style, in a stable
  // order with zen-mode last) so the submission's rules apply wherever the agent
  // put them — never assume the panel's CSS lives only in zen-mode.css. jsdom
  // applies rules in sheet order regardless of specificity, mirroring index.css.
  const collectCss = (dir: string): string[] => {
    const out: string[] = [];
    for (const entry of readdirSync(dir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) out.push(...collectCss(full));
      else if (entry.name.endsWith('.css') && entry.name !== 'zen-mode.css') out.push(full);
    }
    return out;
  };
  const styleRoot = path.resolve('src/style');
  const cssFiles = [...collectCss(styleRoot), path.join(styleRoot, 'components/zen-mode.css')];
  const css = cssFiles
    .filter((file) => { try { readFileSync(file); return true; } catch { return false; } })
    .map((file) => readFileSync(file, 'utf8'))
    .join('\n');
  document.head.querySelector('[data-testid="zen-styles"]')?.remove();
  const style = document.createElement('style');
  style.dataset.testid = 'zen-styles';
  style.textContent = css;
  document.head.appendChild(style);

  document.body.innerHTML = `
    <div class="workspace-split mod-root claudian-zen-host">
      <div class="view-content">
        <div class="markdown-source-view mod-cm6"><div class="cm-editor"><div class="cm-scroller"></div></div></div>
        <div class="markdown-preview-view"></div>
      </div>
      <div class="claudian-container claudian-zen">
        <div class="claudian-zen-drawer">
          <div class="claudian-zen-history"><div class="claudian-messages-wrapper"><div class="claudian-messages"></div></div></div>
          <div class="claudian-zen-bar"><button type="button" class="claudian-zen-disclosure"><span class="claudian-zen-preview"></span></button></div>
        </div>
        <div class="claudian-zen-composer">
          <div class="claudian-input-composer"><div class="claudian-input-container"><div class="claudian-input-toolbar"></div></div></div>
        </div>
        <div class="claudian-zen-side-chat-chip-slot claudian-side-chat-chip-slot">
          <div class="claudian-side-chat"><div class="claudian-side-chat-status"></div></div>
        </div>
      </div>
    </div>`;

  const host = document.querySelector<HTMLElement>('.claudian-zen-host')!;

  // "Reserves a bottom strip" = the host (or the content region) pads its bottom
  // to make room for the panel. A floating panel reserves nothing: the host's
  // bottom padding is empty or zero. (Pre-fix the host padded by a
  // reserved-height custom property that tracked the panel size.)
  const reservesStrip = (el: HTMLElement): boolean => {
    const pb = window.getComputedStyle(el).paddingBottom.trim();
    return pb !== '' && pb !== '0px' && pb !== '0';
  };
  const contentRegions = [
    host,
    host.querySelector<HTMLElement>('.cm-scroller'),
    host.querySelector<HTMLElement>('.markdown-preview-view'),
  ].filter(Boolean) as HTMLElement[];
  const elementsReservingBottomStrip = contentRegions.filter(reservesStrip).length;

  // Each listed surface must be backed by an opaque colour so a translucent theme
  // cannot show the note through it. Opaque = a real colour, not transparent.
  const transparent = new Set(['', 'transparent', 'rgba(0, 0, 0, 0)']);
  const surfaceSelectors = [
    '.claudian-zen-drawer',
    '.claudian-zen-composer > .claudian-input-composer',
    '.claudian-zen-side-chat-chip-slot .claudian-side-chat-status',
  ];
  const isOpaque = (sel: string): boolean => {
    const el = document.querySelector<HTMLElement>(sel);
    if (!el) return false;
    return !transparent.has(window.getComputedStyle(el).backgroundColor.trim());
  };
  const originalCount = surfaceSelectors.filter(isOpaque).length;
  // If the panel root itself is opaque it covers all surfaces; count as 3.
  const panelRootOpaque = isOpaque('.claudian-zen');
  const opaqueSurfaces = panelRootOpaque ? Math.max(originalCount, surfaceSelectors.length) : originalCount;

  return { elementsReservingBottomStrip, opaqueSurfaces };
}

/** Tear down the style surface between cases. */
export function teardownStyledPanel(): void {
  document.head.querySelector('[data-testid="zen-styles"]')?.remove();
  document.body.replaceChildren();
}

// ===========================================================================
// Movement / hint surface: the live, mounted, draggable panel.
// ===========================================================================

type Split = { collapsed: boolean; containerEl: HTMLElement };
type Leaf = { view: unknown; getRoot: () => unknown; isDeferred?: boolean; loadIfDeferred?: () => Promise<void> };

export interface PositionStore<T = unknown> { value: T | null; }

export interface MountOptions {
  /**
   * Returns the deps object merged into the ZenModeController so it can read and
   * remember the panel position. Read/write the position through the shared
   * `store` argument. Example:
   *   positionDeps: (store) => ({
   *     getPosition: () => store.value,
   *     savePosition: (p) => { store.value = p; },
   *   })
   * Name the deps exactly as your controller's constructor expects.
   */
  positionDeps(store: PositionStore): Record<string, unknown>;
  /**
   * The panel's rendered offset from its docked home, in px (right/up positive).
   * Read it however your panel renders it (CSS custom properties, inline style…).
   */
  readOffset(panel: HTMLElement): { x: number; y: number };
  /** Locate the move handle your panel renders (e.g. its labelled move button). */
  findGrip(panel: HTMLElement): HTMLElement;
  /** Position the store starts at (default null = docked). */
  initialPosition?: unknown;
}

export interface ZenFixture {
  panel: HTMLElement;
  rootEl: HTMLElement;
  rightSplit: Split;
  noteEditor: HTMLTextAreaElement;
  store: PositionStore;
  /** The position the dock has most recently decided to remember. */
  savedPosition(): unknown;
  /** The panel's current rendered offset from dock, in px. */
  offset(panel?: HTMLElement): { x: number; y: number };
  /** The move handle, re-located on the current panel. */
  grip(panel?: HTMLElement): HTMLElement;
  /** Collapse/expand the panel's sidebar so the controller re-mounts it. */
  setCollapsed(collapsed: boolean): void;
  /** Collapse then re-open to force a fresh panel mount; returns the new panel. */
  reopen(): HTMLElement;
  /** The host's current inner width/height in px. */
  hostSize(): { width: number; height: number };
  /** Resize the central host (px) and fire a resize so the dock re-clamps/re-renders. */
  setHostSize(width: number, height: number): void;
  /** Set the fake panel height (px) and fire a resize so the dock re-clamps. */
  setPanelHeight(height: number): void;
  /** Set the fake drawer height (px) and fire a resize. */
  setDrawerHeight(height: number): void;
  /** Re-run the ResizeObserver callbacks for the panel. */
  resize(): void;
  /** Full pointer drag of `handle` from one client point to another. */
  drag(handle: HTMLElement, from: [number, number], to: [number, number]): void;
  pointerDown(handle: HTMLElement, at: [number, number]): void;
  pointerMove(to: [number, number]): void;
  pointerUp(at: [number, number]): void;
  /** Fire a keydown on `target` (grip or panel root, whichever you listen on). */
  fireKey(target: HTMLElement, key: string, init?: KeyboardEventInit): void;
  cleanup(): Promise<void>;
}

function createWorkspace() {
  const containerEl = document.body.createDiv({ cls: 'workspace' });
  const leftSplit: Split = { collapsed: false, containerEl: containerEl.createDiv({ cls: 'workspace-split mod-left-split' }) };
  const rootEl = containerEl.createDiv({ cls: 'workspace-split mod-vertical mod-root' });
  const rightSplit: Split = { collapsed: false, containerEl: containerEl.createDiv({ cls: 'workspace-split mod-right-split' }) };
  const rootSplit = {};
  const noteEditor = rootEl.createDiv({ cls: 'workspace-leaf' }).createEl('textarea', {
    attr: { 'aria-label': 'Note editor' },
  }) as HTMLTextAreaElement;
  const listeners = new Map<string, Set<(...args: unknown[]) => void>>();
  const leaves: Leaf[] = [];
  const workspace = {
    containerEl, leftSplit, rightSplit, rootSplit, layoutReady: true,
    onLayoutReady: (callback: () => void) => callback(),
    on(name: string, callback: (...args: unknown[]) => void) {
      if (!listeners.has(name)) listeners.set(name, new Set());
      listeners.get(name)!.add(callback);
      return { name, callback };
    },
    offref(ref: { name: string; callback: (...args: unknown[]) => void }) { listeners.get(ref.name)?.delete(ref.callback); },
    trigger(name: string, ...args: unknown[]) { for (const listener of [...(listeners.get(name) ?? [])]) listener(...args); },
    listenerCount: () => [...listeners.values()].reduce((total, set) => total + set.size, 0),
    getLeavesOfType: () => leaves,
    getActiveFile: () => null,
    revealLeaf: jest.fn(async (leaf: Leaf) => { (leaf.getRoot() as Split).collapsed = false; workspace.trigger('resize'); }),
  };
  const scopes: unknown[] = [];
  const keymap = {
    pushScope: (scope: unknown) => { scopes.push(scope); },
    popScope: (scope: unknown) => { scopes.splice(scopes.indexOf(scope), 1); },
  };
  const setCollapsed = (split: Split, collapsed: boolean) => { split.collapsed = collapsed; workspace.trigger('resize'); };
  return { workspace, keymap, scopes, rootEl, rootSplit, leftSplit, rightSplit, noteEditor, leaves, setCollapsed };
}

function createSettings(enabled: boolean) {
  const entry = modelCatalogCases.find((candidate) => candidate.id === 'claude')!;
  const settings = JSON.parse(JSON.stringify(DEFAULT_CLAUDIAN_SETTINGS));
  entry.populate(settings);
  settings.enableZenMode = enabled;
  return settings;
}

/**
 * Mount the live zen panel inside a fake Obsidian central workspace, wired to an
 * in-memory position store through the agent-supplied `positionDeps`. Returns a
 * fixture with drag/keyboard/resize controls and position readers.
 */
export async function mountZenFixture(opts: MountOptions): Promise<ZenFixture> {
  const cleanups: Array<() => Promise<void> | void> = [];

  // jsdom lacks structuredClone semantics SettingsCoordinator relies on.
  const originalStructuredClone = globalThis.structuredClone;
  globalThis.structuredClone = (value: unknown) => deserialize(serialize(value));
  cleanups.push(() => { globalThis.structuredClone = originalStructuredClone; });

  // jsdom has no PointerEvent — fireEvent.pointer* would drop coordinates.
  const originalPointerEvent = window.PointerEvent;
  window.PointerEvent = class extends MouseEvent {
    readonly pointerId: number;
    constructor(type: string, init: PointerEventInit = {}) { super(type, init); this.pointerId = init.pointerId ?? 0; }
  } as unknown as typeof PointerEvent;
  cleanups.push(() => { window.PointerEvent = originalPointerEvent; });

  // Controllable ResizeObserver so panel/drawer growth can be simulated on demand.
  const originalResizeObserver = globalThis.ResizeObserver;
  const observers: Array<{ callback: ResizeObserverCallback; targets: Set<Element> }> = [];
  globalThis.ResizeObserver = class {
    readonly #entry: { callback: ResizeObserverCallback; targets: Set<Element> };
    constructor(callback: ResizeObserverCallback) { this.#entry = { callback, targets: new Set() }; observers.push(this.#entry); }
    observe(target: Element) { this.#entry.targets.add(target); }
    unobserve(target: Element) { this.#entry.targets.delete(target); }
    disconnect() { this.#entry.targets.clear(); }
  } as unknown as typeof ResizeObserver;
  cleanups.push(() => { globalThis.ResizeObserver = originalResizeObserver; });
  const fireResize = (target: Element) => {
    for (const { callback, targets } of observers) if (targets.has(target)) callback([], {} as ResizeObserver);
  };

  const settings = createSettings(true);
  const harness = createHarness({ settings: settings as unknown as Record<string, unknown> });
  ProviderWorkspaceRegistry.setServices('claude', {});
  const app = new App();
  Object.assign(app.vault.adapter, { basePath: '/vault' });
  Object.assign(app.vault, { on: () => ({}), offref: () => undefined });
  const layout = createWorkspace();
  Object.assign(app, { workspace: layout.workspace, keymap: layout.keymap });
  const sessions: FakeSideSession[] = [];
  jest.spyOn(ProviderRegistry, 'createExecutionBackend').mockImplementation((_host, providerId = 'claude') => ({
    providerId,
    createSession: (config: unknown) => { const session = new FakeSideSession(config); sessions.push(session); return session; },
  }));
  const conversations: unknown[] = [];

  const store: PositionStore = { value: opts.initialPosition ?? null };

  let settingsCoordinator: SettingsCoordinator<unknown>;
  const zen = new ZenModeController({
    app,
    isEnabled: (): boolean => settingsCoordinator.getCommittedSettings().enableZenMode,
    // Free-choice seam: whatever deps the controller needs to read /
    // remember the position, wired to the in-memory store.
    ...opts.positionDeps(store),
  });
  settingsCoordinator = new SettingsCoordinator(settings, async () => undefined, () => zen.reconcile());

  const find = (id: string) => conversations.find((entry: any) => entry.id === id) ?? null;
  const plugin = {
    ...harness.plugin, app, settings,
    chatModelSelection: new ChatModelSelectionCoordinator(settingsCoordinator),
    executionPersistence: {
      registerExecutionBinding: () => undefined, releaseExecutionBinding: () => undefined,
      persistExecutionSnapshot: async () => true, assertConversationExecutionAuthority: async () => undefined,
      recordConversationActivity: async () => undefined,
    },
    getActiveEnvironmentVariables: () => '',
    getConversationSummary: find, getConversationSync: find,
    getConversationById: async (id: string) => find(id), getConversationList: () => conversations,
    updateConversation: async () => undefined, renameConversation: async () => undefined,
    mutateSettings: settingsCoordinator.mutate.bind(settingsCoordinator),
    getCommittedSettings: settingsCoordinator.getCommittedSettings.bind(settingsCoordinator),
    registerZenModeSource: (source: unknown) => zen.register(source as never),
  } as unknown as Record<string, unknown>;

  const addView = async (placement: 'left' | 'right' | 'main', ready = true) => {
    const conversation = {
      id: `conversation-${conversations.length + 1}`, providerId: 'claude',
      selectedModel: modelCatalogCases.find((c) => c.id === 'claude')!.selected,
      messages: [], sessionId: `session-${conversations.length + 1}`,
    };
    conversations.push(conversation);
    const split = placement === 'left' ? layout.leftSplit : placement === 'right' ? layout.rightSplit : null;
    const viewContainerEl = (split?.containerEl ?? layout.rootEl).createDiv({ cls: 'claudian-container' });
    const leaf: Leaf = { getRoot: () => split ?? layout.rootSplit, view: null };
    const view = createClaudianView({ host: plugin, app, leaf, containerEl: viewContainerEl, contentEl: viewContainerEl });
    view.viewContainerEl = viewContainerEl;
    view.buildViewLayout(viewContainerEl);
    const tab = await createTabRuntime({
      plugin, component: Object.assign(new Component(), { registerDomEvent: () => undefined, registerEvent: () => undefined }),
      containerEl: view.tabContentEl, mentionDataProvider: new VaultMentionDataProvider(plugin.app),
      conversation, getProviderCatalogConfig: () => null, isRuntimeLive: () => true,
    });
    tab.state.currentConversationId = conversation.id;
    tab.dom.contentEl.removeClass('claudian-hidden');
    cleanups.push(() => destroyTab(tab));
    view.tabManager = { getActiveTab: () => tab, getTab: (id: string) => (id === tab.id ? tab : null), getTabCount: () => 1 };
    Object.assign(view.tabWorkspace, { lifecycleRevision: 1, initializedRevision: ready ? 1 : -1 });
    leaf.view = view;
    layout.leaves.push(leaf);
    view.presentation.update();
    view.startZenModeSource();
    cleanups.push(() => view.stopZenModeSource());
    return { view, tab, leaf };
  };

  zen.start();
  cleanups.push(() => zen.dispose());
  await addView('right', true);

  const zenPanel = (): HTMLElement => document.querySelector<HTMLElement>('.claudian-zen')!;

  // jsdom has no layout: describe a HOST_WIDTH x HOST_HEIGHT host holding a
  // 600 x panelHeight panel. The composer sits COMPOSER_GAP inside the panel
  // bottom, which rides the vertical offset; a drawer, when shown, stands on the
  // composer, 526px wide. Host size is mutable so a transient squeeze can be
  // simulated (shrink, then restore) for the resize-stability story.
  let hostWidth = HOST_WIDTH;
  let hostHeight = HOST_HEIGHT;
  Object.defineProperty(layout.rootEl, 'clientWidth', { configurable: true, get: () => hostWidth });
  Object.defineProperty(layout.rootEl, 'clientHeight', { configurable: true, get: () => hostHeight });
  jest.spyOn(layout.rootEl, 'getBoundingClientRect').mockImplementation(() => ({
    top: 0, bottom: hostHeight, left: 0, right: hostWidth, width: hostWidth, height: hostHeight,
  } as DOMRect));

  let panelHeight = 100;
  let drawerHeight = 0;

  // Cached Y-offset (px upward from dock) used by getBoundingClientRect mocks.
  // Updated after each discrete user-visible operation via refreshOffsetCache().
  // This decouples the mock from opts.readOffset so implementations that call
  // getBoundingClientRect() inside their own readOffset() cannot recurse infinitely.
  let cachedOffsetY = 0;
  let _refreshing = false;
  const refreshOffsetCache = (p: HTMLElement) => {
    if (_refreshing) return; // re-entrancy guard
    _refreshing = true;
    try { cachedOffsetY = opts.readOffset(p).y; } catch { /* leave stale */ } finally { _refreshing = false; }
  };

  const stubPanel = (panel: HTMLElement) => {
    // panel bottom edge y-coord = host height minus how far up it was pushed.
    // Uses the cached Y-offset (refreshed after each operation) rather than calling
    // readOffset() live inside the mock, which would create a circular dependency for
    // implementations that read getBoundingClientRect() inside their own readOffset().
    const panelBottom = () => hostHeight - cachedOffsetY;
    jest.spyOn(panel, 'getBoundingClientRect').mockImplementation(() => ({
      left: 200, right: 800, top: panelBottom() + COMPOSER_GAP - panelHeight, bottom: panelBottom() + COMPOSER_GAP,
      width: PANEL_WIDTH, height: panelHeight,
    } as DOMRect));
    const composer = panel.querySelector<HTMLElement>('.claudian-zen-composer');
    if (composer) {
      jest.spyOn(composer, 'getBoundingClientRect').mockImplementation(() => ({
        left: 208, right: 792, top: panelBottom() - COMPOSER_HEIGHT, bottom: panelBottom(),
      } as DOMRect));
    }
    const drawer = panel.querySelector<HTMLElement>('.claudian-zen-drawer');
    if (drawer) {
      jest.spyOn(drawer, 'getBoundingClientRect').mockImplementation(() => ({
        left: 237, right: 763, top: panelBottom() - COMPOSER_HEIGHT - drawerHeight, bottom: panelBottom() - COMPOSER_HEIGHT,
        height: drawerHeight,
      } as DOMRect));
    }
  };

  // Open the panel (collapse the right split so the central host hosts it).
  layout.setCollapsed(layout.rightSplit, true);
  let panel = zenPanel();
  stubPanel(panel);
  refreshOffsetCache(panel);

  // Track the last handle used for pointerDown so that pointerMove/pointerUp
  // can fire on the same element. Firing on the handle (not document) ensures
  // events bubble up to document-level listeners AND reach handle-level listeners
  // registered with setPointerCapture (also valid). In jsdom, setPointerCapture
  // is a no-op, so the only reliable delivery path for handle-level move/up
  // listeners is to fire on the handle itself.
  let _lastPointerHandle: HTMLElement = document.body;

  const drag = (handle: HTMLElement, from: [number, number], to: [number, number]) => {
    fireEvent.pointerDown(handle, { button: 0, pointerId: 1, clientX: from[0], clientY: from[1] });
    fireEvent.pointerMove(handle, { pointerId: 1, clientX: to[0], clientY: to[1] });
    fireEvent.pointerUp(handle, { pointerId: 1, clientX: to[0], clientY: to[1] });
    refreshOffsetCache(panel);
  };

  const fixture: ZenFixture = {
    get panel() { return panel; },
    rootEl: layout.rootEl,
    rightSplit: layout.rightSplit,
    noteEditor: layout.noteEditor,
    store,
    savedPosition: () => store.value,
    offset: (p?: HTMLElement) => opts.readOffset(p ?? panel),
    grip: (p?: HTMLElement) => opts.findGrip(p ?? panel),
    setCollapsed: (collapsed: boolean) => layout.setCollapsed(layout.rightSplit, collapsed),
    reopen: () => {
      layout.setCollapsed(layout.rightSplit, false);
      layout.noteEditor.focus();
      layout.setCollapsed(layout.rightSplit, true);
      panel = zenPanel();
      stubPanel(panel);
      refreshOffsetCache(panel);
      return panel;
    },
    hostSize: () => ({ width: hostWidth, height: hostHeight }),
    setHostSize: (width: number, height: number) => {
      hostWidth = width; hostHeight = height;
      layout.workspace.trigger('resize');
      fireResize(panel);
      refreshOffsetCache(panel);
    },
    setPanelHeight: (height: number) => { panelHeight = height; fireResize(panel); refreshOffsetCache(panel); },
    setDrawerHeight: (height: number) => { drawerHeight = height; fireResize(panel); refreshOffsetCache(panel); },
    resize: () => { fireResize(panel); refreshOffsetCache(panel); },
    drag,
    pointerDown: (handle: HTMLElement, at: [number, number]) => {
      _lastPointerHandle = handle;
      fireEvent.pointerDown(handle, { button: 0, pointerId: 1, clientX: at[0], clientY: at[1] });
    },
    pointerMove: (to: [number, number]) => fireEvent.pointerMove(_lastPointerHandle, { pointerId: 1, clientX: to[0], clientY: to[1] }),
    pointerUp: (at: [number, number]) => { fireEvent.pointerUp(_lastPointerHandle, { pointerId: 1, clientX: at[0], clientY: at[1] }); refreshOffsetCache(panel); },
    fireKey: (target: HTMLElement, key: string, init?: KeyboardEventInit) => { fireEvent.keyDown(target, { key, ...init }); refreshOffsetCache(panel); },
    cleanup: async () => {
      for (const c of cleanups.splice(0).reverse()) await c();
      ProviderWorkspaceRegistry.clear();
      jest.restoreAllMocks();
      await releaseSideChatHarnesses();
      document.body.replaceChildren();
    },
  };
  // expose `within` for convenience when the agent locates its grip by role.
  (fixture as any).within = within;
  return fixture;
}
