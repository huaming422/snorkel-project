// @ts-nocheck
//
// Locale coverage check: every shipped locale must carry the new chat.zen key
// that the zen-dock feature adds.
//
// STRATEGY (implementation-agnostic):
//   1. Load en.json and discover the set of keys under chat.zen.
//   2. Compute the NEW keys by removing the pre-fix chat.zen key set
//      (stable fact: en.json at base commit 26f66bca had 13 keys under chat.zen —
//      see PRE_FIX_ZEN_KEYS below; only a key added by the feature implementation
//      will appear as "new").
//   3. Assert that every other shipped locale file also carries those new keys
//      with a non-empty string value.
//
// The test never hard-codes the new key name: it discovers it from en.json, so
// any implementation that adds a differently-named key (while still being the
// one key that enables the move handle's accessible label) will also pass.

import { readFileSync, readdirSync } from 'node:fs';
import path from 'node:path';

// The chat.zen keys that existed at the task's base commit (26f66bca).
// ALL 13 keys from en.json at base commit — verified by running the Docker
// image against the unpatched repo: docker run --rm claudian-feat-movable-zen-dock:latest
// cat /repo/claudian/src/i18n/locales/en.json | jq '.chat.zen | keys'
const PRE_FIX_ZEN_KEYS = new Set([
  'regionLabel', 'showHistory', 'working', 'thinking', 'interrupted',
  'workedFor', 'workedForResult', 'actionRequired', 'error',
  'toolRunning', 'toolCompleted', 'toolFailed', 'toolBlocked',
]);

// Locale files we ship (relative names only; the path is derived below).
const SHIPPED_LOCALES = ['de', 'en', 'es', 'fr', 'ja', 'ko', 'pt', 'ru', 'zh-CN', 'zh-TW'];

function localesDir(): string {
  // Resolve from the repo root: src/i18n/locales/
  return path.resolve('src/i18n/locales');
}

function readLocale(locale: string): Record<string, unknown> {
  const file = path.join(localesDir(), `${locale}.json`);
  return JSON.parse(readFileSync(file, 'utf8')) as Record<string, unknown>;
}

function zenKeys(locale: Record<string, unknown>): Record<string, unknown> {
  const chat = locale.chat as Record<string, unknown> | undefined;
  const zen = chat?.zen as Record<string, unknown> | undefined;
  return zen ?? {};
}

describe('zen-dock i18n coverage', () => {
  let newZenKeys: string[];

  beforeAll(() => {
    const en = readLocale('en');
    const allZenKeys = Object.keys(zenKeys(en));
    newZenKeys = allZenKeys.filter((k) => !PRE_FIX_ZEN_KEYS.has(k));
  });

  it('en.json introduces at least one new chat.zen key beyond the pre-fix set', () => {
    expect(newZenKeys.length).toBeGreaterThanOrEqual(1);
  });

  for (const locale of SHIPPED_LOCALES) {
    it(`${locale}.json carries every new chat.zen key with a non-empty string value`, () => {
      const data = readLocale(locale);
      const zen = zenKeys(data);
      for (const key of newZenKeys) {
        expect(typeof zen[key]).toBe('string');
        expect((zen[key] as string).length).toBeGreaterThan(0);
      }
    });
  }
});
