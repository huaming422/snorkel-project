// @ts-nocheck
//
// Behavioral check: a stored zen-panel position is normalized on load.
//
// Contract (stated in the task, enforced across the whole change — NOT a
// solution-chosen shape):
//   - a freshly-defaulted settings object is "docked" (the panel sits at its
//     home); whatever value the implementation stores to mean "docked" is the
//     docked sentinel,
//   - a stored blob that carries NO position loads as docked,
//   - a stored blob whose position is MALFORMED (not the shape the
//     implementation persists — a string coordinate, a NaN, a half-filled
//     object, a non-object, an array, a bare number) is repaired on load back
//     to the docked sentinel rather than passed through verbatim.
//
// This test NEVER names the implementation's setting key, its persisted shape, or the
// literal docked value. It:
//   * tests THROUGH the pre-existing, stable `ClaudianSettingsStorage.load()`
//     interface with a mocked `VaultFileAdapter` (this method is only EXTENDED by
//     the change, not introduced by it),
//   * DISCOVERS the new position key by diffing the loaded default settings against
//     the frozen pre-fix key set (a stable fact: the settings shape at the base
//     commit 26f66bca),
//   * DISCOVERS the docked sentinel by observing what a default load produces,
// and checks each malformed value against THAT key's own default, so every
// valid persistence design (a single `{x,y}|null`, a normalized vector,
// separate x/y keys, …) passes as long as the normalize-on-load contract holds.
//
// Valid-position round-tripping and resize stability depend on the implementation's
// choice of encoding and are exercised behaviorally by the DOM stories (which run
// the submitted dock code), so this static check deliberately does not pin a
// concrete non-docked value.

import {
  ClaudianSettingsStorage,
} from '@/app/settings/ClaudianSettingsStorage';
import { DEFAULT_CLAUDIAN_SETTINGS } from '@test/helpers/defaultSettings';
import type { VaultFileAdapter } from '@/core/storage/VaultFileAdapter';

// Installation-key side effects are irrelevant here; keep them deterministic.
jest.mock('@/core/device/InstallationKey', () => ({
  ...jest.requireActual('@/core/device/InstallationKey'),
  getInstallationKey: () => 'host-verify',
  getLegacyDeviceSettingsKey: () => null,
}));

// The settings keys that already existed at the task's base commit. The new
// position key is whatever the loaded defaults carry that is NOT in this set —
// discovered, never hardcoded. (Stable fact: src/app/settings/defaultSettings.ts
// at 26f66bca.)
const PRE_FIX_SETTING_KEYS = new Set<string>([
  'userName', 'permissionMode', 'model', 'effortLevel', 'serviceTier',
  'enableAutoTitleGeneration', 'titleGenerationLocale', 'titleGenerationModel',
  'excludedTags', 'mediaFolder', 'systemPrompt', 'sharedEnvironmentVariables',
  'envSnippets', 'customContextLimits', 'keyboardNavigation',
  'requireCommandOrControlEnterToSend', 'locale', 'providerConfigs',
  'settingsProvider', 'lastSelectedChatModel', 'savedProviderModel',
  'savedProviderEffort', 'savedProviderServiceTier', 'savedProviderPermissionMode',
  'pendingProviderSessionInvalidations', 'enableAutoScroll', 'showMessageTimestamps',
  'deferMathRenderingDuringStreaming', 'expandFileEditsByDefault', 'chatViewPlacement',
  'enableZenMode', 'enableDualPane', 'dualPaneSide', 'restoreTabsOnStartup',
  'skillsSynced', 'sessionManagerOrganization', 'sessionManagerSort',
  'sessionAutoArchiveAfter', 'pinnedLinkedContentPaths', 'hiddenCommands',
]);

function makeAdapter(): jest.Mocked<VaultFileAdapter> {
  return {
    exists: jest.fn().mockResolvedValue(false),
    read: jest.fn().mockResolvedValue('{}'),
    write: jest.fn().mockResolvedValue(undefined),
    delete: jest.fn().mockResolvedValue(undefined),
  } as unknown as jest.Mocked<VaultFileAdapter>;
}

function newStorage(adapter: VaultFileAdapter): ClaudianSettingsStorage {
  return new ClaudianSettingsStorage(adapter, DEFAULT_CLAUDIAN_SETTINGS);
}

/** Load a stored blob (or the no-file default when `stored` is undefined). */
async function loadWith(stored?: unknown) {
  const adapter = makeAdapter();
  if (stored === undefined) {
    adapter.exists.mockResolvedValue(false);
  } else {
    adapter.exists.mockResolvedValue(true);
    adapter.read.mockResolvedValue(JSON.stringify(stored));
  }
  const loaded = await newStorage(adapter).load();
  return { loaded, adapter };
}

describe('zen panel position normalizes on load', () => {
  // Discover the new position key from the loaded defaults.
  let positionKey: string;
  let dockedDefault: unknown;

  beforeAll(async () => {
    const { loaded } = await loadWith();
    const newKeys = Object.keys(loaded).filter(k => !PRE_FIX_SETTING_KEYS.has(k));
    expect(newKeys.length).toBeGreaterThanOrEqual(1);
    // Prefer a key whose name references the panel/zen/position if several are
    // new; otherwise take the single new key.
    positionKey =
      newKeys.find(k => /zen|position|dock|panel|offset/i.test(k)) ?? newKeys[0];
    dockedDefault = loaded[positionKey];
  });

  it('exposes a discovered docked position setting on the defaults', () => {
    expect(positionKey).toBeTruthy();
    // The docked default must be a defined, serializable sentinel (null or an
    // object), not undefined — the panel needs a defined "home" marker.
    expect(dockedDefault === null || typeof dockedDefault === 'object').toBe(true);
  });

  it('loads a stored-but-absent position as docked', async () => {
    // A persisted settings blob that predates the feature (no position field).
    const { loaded } = await loadWith({ enableZenMode: true });
    expect(loaded[positionKey]).toEqual(dockedDefault);
  });

  it('repairs malformed stored positions back to docked', async () => {
    // Every value here is garbage under EVERY reasonable persisted shape — an
    // object `{x,y}`, a 2-tuple array, OR two separate numeric coordinates — so
    // normalizing it back to the docked sentinel is contract, not a shape pin.
    // (A bare number `42` is deliberately NOT used: it is a legitimate single
    // coordinate for a separate-keys design, so it is not universally malformed.
    // A 2-element array is likewise a legitimate vector encoding and is omitted.)
    const malformedValues: unknown[] = [
      { x: '1', y: 0.5 },          // object/array/number all reject a string coord
      { x: 0.5, y: Number.NaN },   // NaN coordinate (serializes to null)
      { x: 0.5 },                  // half-filled object
      'bottom-center',             // a string is not any coordinate shape
    ];
    for (const bad of malformedValues) {
      const { loaded } = await loadWith({ [positionKey]: bad });
      expect(loaded[positionKey]).toEqual(dockedDefault);
    }
  });
});
