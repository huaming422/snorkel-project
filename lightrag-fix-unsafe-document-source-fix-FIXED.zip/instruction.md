## Task

our document endpoints don't agree on what a document's source name is allowed to contain, and it's biting us in two ways.

a source name is more than a label. it's how we spot duplicates, and it gets stamped onto each entity and each relation we pull out of the document. file upload already turns away names with control characters in them. pasting text in doesn't check anything, whether it's one text or a list of them. so someone can send a source with a stray vertical tab or a null in it, we accept it without complaint, and the document only falls over later when the graph refuses to store that name. a file that's already sitting in the input folder can get through the same way when the folder is scanned.

the scan has a worse version of this. when a file in the input folder has a name that isn't valid utf-8, python hands it to us with a lone surrogate in it. we write a warning about that file, and after that the status endpoints can no longer turn their own output into json. fetching the processing status or the scan status then answers with a 500 for everybody, and the scan itself dies partway through, so the files after the bad one never get picked up.

what i'd like is for all three ways in to agree, and for a bad name to be turned away at the door instead of getting as far as storage:

- refuse any source name that contains a control character (tab and newline included), the delete character, the code points U+FFFE or U+FFFF, or an unpaired surrogate. anything else that works today keeps working exactly as it does now, whatever other characters the name has.
- pasted text, one or a list: refuse the request with an ordinary client error. in a list, one bad name anywhere in it is enough to refuse the whole request.
- upload: keeps answering 400 for a bad name, now for everything in that list above.
- refuse means refuse. don't clean the name up and take it under a different name, because that would change which document it is.
- scan: pass over that file and warn about it. the other files in the same scan still get ingested, the passed-over file stays exactly where it is in the input folder (not moved, renamed or deleted), and we shouldn't check it against existing documents or register anything for it. the warning has to be plain readable text that names the file without repeating raw undecodable characters, so the status endpoints keep answering normally.
- documents that already have a bad source stored need to keep showing up in listings and stay deletable.

this is about the http endpoints and the scan, not the python-level insert call.
