"""Behavioral checks for document source names at the three entry points.

A document's source name is stamped onto every entity and relation extracted
from it, and it doubles as the document's identity and duplicate key. Some code
points can never be stored by the graph backend, and a lone surrogate (what a
file name that is not valid UTF-8 turns into) also breaks JSON rendering of the
status endpoints. The three ways a document can enter (file upload, pasted text
and the input-directory scan) have to agree on what a source may contain, and
turn a bad one away before it reaches storage.

Every assertion drives an existing, stable interface and observes behavior only.
It never imports a helper a fix introduces and never asserts a solution-chosen
name, message string or counter key.

  * HTTP entry points (text, texts, upload) and the status and listing reads are
    driven through ``create_document_routes(rag, doc_manager, api_key=...)`` and
    a FastAPI ``TestClient``, the public router factory the server mounts.
  * The scan is driven through the real ``run_scanning_process`` loop over a
    temporary input directory, with a real scan job record, so the scan status
    endpoint is read the way an operator reads it.
  * The read-side normalizer is the existing ``normalize_file_path`` helper,
    called directly, and the document listing is read through its endpoint.

A lone surrogate cannot travel in an HTTP JSON body (httpx refuses to encode it),
so it is covered on the scan only. Rejections of pasted text are checked as a
client validation error (400 or 422); upload keeps its 400. Wording, helper
names, counter keys and the shape of any predicate are left to the solution.
"""

from __future__ import annotations

import asyncio
import importlib
import json
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

# Importing the router module resolves the server config, which parses sys.argv
# and would choke on pytest's own flags. Same guard the repo's own
# document_routes tests use.
_original_argv = sys.argv[:]
sys.argv = [sys.argv[0]]
_dr = importlib.import_module("lightrag.api.routers.document_routes")
_shared_storage = importlib.import_module("lightrag.kg.shared_storage")
sys.argv = _original_argv

from lightrag.base import DocProcessingStatus, DocStatus, SourceAbsent  # noqa: E402
from lightrag.constants import PARSED_DIR_NAME  # noqa: E402

create_document_routes = _dr.create_document_routes
run_scanning_process = _dr.run_scanning_process
normalize_file_path = _dr.normalize_file_path
DocumentManager = _dr.DocumentManager

API_KEY = "test-key"
HEADERS = {"X-API-Key": API_KEY}
CLIENT_ERRORS = (400, 422)

# ---------------------------------------------------------------------------
# Unsafe / safe source corpora.
# ---------------------------------------------------------------------------

# Unsafe sources that can travel in an HTTP JSON body (every unsafe code point
# except a lone surrogate, which httpx refuses to UTF-8-encode).
HTTP_UNSAFE = [
    pytest.param("a\x00b.txt", id="nul-U+0000"),
    pytest.param("a\x0bb.txt", id="vtab-U+000B"),
    pytest.param("a\x1fb.txt", id="unit-sep-U+001F"),
    pytest.param("a\tb.txt", id="tab-U+0009"),
    pytest.param("a\nb.txt", id="newline-U+000A"),
    pytest.param("a\rb.txt", id="carriage-return-U+000D"),
    pytest.param("a\x7fb.txt", id="del-U+007F"),
    pytest.param("a\ufffeb.txt", id="noncharacter-U+FFFE"),
    pytest.param("a\uffffb.txt", id="noncharacter-U+FFFF"),
]

# Ordinary names that every entry point accepts today and must keep accepting.
SAFE_SOURCES = [
    pytest.param("report.pdf", id="ascii"),
    pytest.param("报告 2026.docx", id="cjk-spaces"),
    pytest.param("a-b_c.d.txt", id="punctuation"),
    pytest.param("emoji \U0001f600.md", id="emoji"),
    pytest.param("spaces are fine.txt", id="spaces"),
]

# Sources that only the pasted-text path takes (an upload name cannot hold a path
# separator), and that people really send: links, relative paths, labels with a
# colon. They were accepted before and must stay accepted.
TEXT_ONLY_SAFE_SOURCES = [
    pytest.param("https://example.com/page.html", id="url"),
    pytest.param("docs/guide/report.pdf", id="relative-path"),
    pytest.param("notes: draft 2.txt", id="colon-in-name"),
    pytest.param("C:report.pdf", id="drive-colon"),
    pytest.param("a\\b.txt", id="backslash"),
]

# Full unsafe set for the read-side checks (includes the lone surrogate, which
# never goes over HTTP).
ALL_UNSAFE_VALUES = [
    "a\x00b.txt",
    "a\x0bb.txt",
    "a\x1fb.txt",
    "a\tb.txt",
    "a\nb.txt",
    "a\rb.txt",
    "a\x7fb.txt",
    "a\ud800b.txt",  # lone surrogate
    "a\ufffeb.txt",
    "a\uffffb.txt",
]

# Unsafe names a directory scan can meet. The surrogate name is the one a file
# name that is not valid UTF-8 turns into.
SCAN_UNSAFE = [
    pytest.param("scan\x0bsource.txt", id="vtab-U+000B"),
    pytest.param("scan\tsource.txt", id="tab-U+0009"),
    pytest.param("scan\x7fsource.txt", id="del-U+007F"),
    pytest.param("scan\ufffesource.txt", id="noncharacter-U+FFFE"),
]


# ---------------------------------------------------------------------------
# Test doubles + fixtures (test infrastructure, not implementation discovery).
# ---------------------------------------------------------------------------


class _AcceptingDocStatus:
    """Nothing is a duplicate: a safe source therefore reaches the accept path
    and an unsafe one can only be stopped by the guard under test."""

    async def get_doc_by_file_basename(self, _basename):
        return None


def _make_http_rag(workspace, doc_status=None):
    async def _noop(*_a, **_k):
        return None

    return SimpleNamespace(
        doc_status=doc_status or _AcceptingDocStatus(),
        workspace=workspace,
        max_pending_documents=0,
        apipeline_enqueue_documents=_noop,
        apipeline_process_enqueue_documents=_noop,
        addon_params={},
    )


def _make_client(rag, doc_manager):
    router = create_document_routes(rag, doc_manager, api_key=API_KEY)
    app = FastAPI()
    app.include_router(router)
    app.state.background_tasks = set()
    return TestClient(app)


def _drain_background_tasks(client, timeout=15.0):
    """Wait for the router's managed background tasks to finish before the test
    client closes. The server's lifespan does this on shutdown; a bare router
    under a test client has no lifespan, so a task still running when the client
    closes can stall its cancellation. Pending tasks left after the timeout are
    reported as a test failure instead of being left to hang the run."""
    tasks = [t for t in client.app.state.background_tasks if not t.done()]
    if not tasks:
        return

    async def _wait():
        _done, pending = await asyncio.wait(tasks, timeout=timeout)
        return [t.get_name() for t in pending]

    pending = client.portal.call(_wait)
    assert not pending, f"background work still running after {timeout}s: {pending}"


def _fresh_workspace(prefix):
    workspace = f"{prefix}-{uuid4().hex[:8]}"
    _shared_storage.initialize_share_data()
    asyncio.new_event_loop().run_until_complete(
        _shared_storage.initialize_pipeline_status(workspace=workspace)
    )
    return workspace


@pytest.fixture
def http_client():
    """A TestClient over the real router with a temp input dir and initialised
    shared storage (the accept path reserves a pipeline slot)."""
    workspace = _fresh_workspace("verify")
    tmp = Path(tempfile.mkdtemp())
    rag = _make_http_rag(workspace)
    doc_manager = DocumentManager(str(tmp))
    with _make_client(rag, doc_manager) as client:
        yield client
        _drain_background_tasks(client)


# --- scan doubles ----------------------------------------------------------


class _RecordingDocStatus:
    """Records every identity lookup and resolves them all to "absent", so a
    file that is skipped can only have been skipped by the guard under test and
    we can assert the rejected name was never looked up."""

    def __init__(self):
        self.lookups: list[str] = []

    async def resolve_doc_source_strict(self, canonical_source_key):
        self.lookups.append(canonical_source_key)
        return SourceAbsent()

    async def get_full_docs_by_ids(self, _doc_ids, *, strict=False):
        return {}

    async def get_doc_by_file_basename(self, _basename):
        return None


class _ScanRag:
    def __init__(self, workspace):
        self.workspace = workspace
        self.doc_status = _RecordingDocStatus()
        self.full_docs = SimpleNamespace(
            get_by_id=self._missing,
            get_by_id_strict=self._missing,
            supports_strict_point_reads=True,
        )
        self.max_pending_documents = 0
        self.addon_params = {}

    async def _missing(self, _doc_id):
        return None

    async def arollback_failed_custom_chunk_patches(self, **_kwargs):
        return {"rolled_back": [], "failed": []}

    async def apipeline_process_enqueue_documents(self):
        return None

    async def apipeline_enqueue_documents(self, *_a, **_k):
        return None


SCAN_TRACK_ID = "verify-track"
SCAN_OWNER = "verify-owner"


async def _run_scan(filenames):
    """Run one real scan over ``filenames`` in a fresh temp input dir, recording
    into a real scan job so the scan status endpoint can be read afterwards.

    Returns (rag, doc_manager, tmp_path, enqueued_basenames). Skips the test only
    when the filesystem itself cannot hold a file name, never on an error raised
    by the code under test.
    """
    _shared_storage.initialize_share_data()
    workspace = f"scan-{uuid4().hex[:8]}"
    rag = _ScanRag(workspace)
    await _shared_storage.initialize_pipeline_status(workspace=workspace)
    tmp = Path(tempfile.mkdtemp())
    doc_manager = DocumentManager(str(tmp))
    for name in filenames:
        try:
            (doc_manager.input_dir / name).write_text("body", encoding="utf-8")
        except (OSError, UnicodeEncodeError) as exc:
            pytest.skip(f"filesystem cannot hold the file name {name!r}: {exc}")

    store = _shared_storage.get_scan_job_store(workspace)
    created = store.create(SCAN_TRACK_ID, SCAN_OWNER)
    assert created.outcome.name == "ACCEPTED", created

    enqueued: list[str] = []
    original = _dr.pipeline_enqueue_scan_batch

    async def _capture_batch(_rag, candidates, _track_id=None):
        enqueued.extend(candidate.path.name for candidate in candidates)
        return len(candidates)

    _dr.pipeline_enqueue_scan_batch = _capture_batch
    try:
        await run_scanning_process(
            rag, doc_manager, SCAN_TRACK_ID, job_owner_token=SCAN_OWNER
        )
    finally:
        _dr.pipeline_enqueue_scan_batch = original
    return rag, doc_manager, tmp, enqueued


async def _pipeline_history(workspace):
    status = await _shared_storage.get_namespace_data(
        "pipeline_status", workspace=workspace
    )
    return list(status.get("history_messages", []))


def _read_status_endpoints(rag, doc_manager):
    """Fetch both status endpoints the way an operator does."""
    with _make_client(rag, doc_manager) as client:
        pipeline = client.get("/documents/pipeline_status", headers=HEADERS)
        scan = client.get(f"/documents/scan/status/{SCAN_TRACK_ID}", headers=HEADERS)
        _drain_background_tasks(client)
    return pipeline, scan


# ---------------------------------------------------------------------------
# Pasted text: one source, and a list of sources
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("value", HTTP_UNSAFE)
def test_text_ingress_rejects_unsafe_sources(http_client, value):
    """POST /documents/text with an unsafe file_source is turned away with a
    client validation error, not accepted and forwarded to storage."""
    resp = http_client.post(
        "/documents/text", headers=HEADERS, json={"text": "hello", "file_source": value}
    )
    assert resp.status_code in CLIENT_ERRORS, resp.text


@pytest.mark.parametrize("value", SAFE_SOURCES + TEXT_ONLY_SAFE_SOURCES)
def test_text_ingress_accepts_safe_sources(http_client, value):
    """An ordinary source (ASCII, CJK, spaces, dots, emoji, a link, a relative
    path, a colon) is still accepted."""
    resp = http_client.post(
        "/documents/text", headers=HEADERS, json={"text": "hello", "file_source": value}
    )
    assert resp.status_code == 200, resp.text


@pytest.mark.parametrize("position", [0, 1, 2], ids=["first", "middle", "last"])
@pytest.mark.parametrize(
    "bad",
    [
        pytest.param("bad\x0b.txt", id="vtab"),
        pytest.param("bad\ufffe.txt", id="noncharacter"),
    ],
)
def test_texts_list_rejects_offender_in_any_position(http_client, position, bad):
    """POST /documents/texts turns away a file_sources list holding an offender
    anywhere in it, not just the first element."""
    sources = ["ok.txt", "fine.txt", "also-ok.txt"]
    sources[position] = bad
    resp = http_client.post(
        "/documents/texts",
        headers=HEADERS,
        json={"texts": ["a", "b", "c"], "file_sources": sources},
    )
    assert resp.status_code in CLIENT_ERRORS, resp.text


def test_texts_list_accepts_all_safe(http_client):
    """A list of only safe sources is still accepted."""
    resp = http_client.post(
        "/documents/texts",
        headers=HEADERS,
        json={
            "texts": ["a", "b", "c"],
            "file_sources": ["ok.txt", "https://example.com/x.html", "docs/a.pdf"],
        },
    )
    assert resp.status_code == 200, resp.text


# ---------------------------------------------------------------------------
# Upload keeps its 400 and extends it to the new characters
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "value",
    [
        pytest.param("a\ufffeb.txt", id="noncharacter-U+FFFE"),
        pytest.param("a\uffffb.txt", id="noncharacter-U+FFFF"),
    ],
)
def test_upload_rejects_unsafe_filenames(http_client, value):
    """POST /documents/upload answers 400 for an unsafe filename, now extended to
    the non-characters.

    The ASCII control and DEL cases cannot be exercised over the multipart
    surface: httpx percent-encodes a control character in a filename header
    (``a\\x0bb.txt`` becomes ``a%0Bb.txt``) before it reaches the handler. The
    non-characters travel intact, and were accepted before."""
    resp = http_client.post(
        "/documents/upload",
        headers=HEADERS,
        files={"file": (value, b"body", "text/plain")},
    )
    assert resp.status_code == 400, resp.text


UPLOAD_SAFE = [
    pytest.param("report.pdf", id="ascii"),
    pytest.param("报告 2026.docx", id="cjk-spaces"),
    pytest.param("spaces are fine.txt", id="spaces"),
]


@pytest.mark.parametrize("value", UPLOAD_SAFE)
def test_upload_accepts_safe_filenames(http_client, value):
    """Previously accepted filenames are unaffected."""
    resp = http_client.post(
        "/documents/upload",
        headers=HEADERS,
        files={"file": (value, b"body", "text/plain")},
    )
    assert resp.status_code == 200, resp.text


# ---------------------------------------------------------------------------
# Scan: skip the file, keep it, keep scanning, never look it up
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("unsafe", SCAN_UNSAFE)
def test_scan_skips_unsafe_basename_and_keeps_it_on_disk(unsafe):
    """A scanned file whose basename holds an unsafe character is NOT enqueued;
    a safe neighbour in the same scan IS; the unsafe file stays in the input
    directory (not archived, renamed or deleted)."""

    async def _run():
        rag, _dm, tmp, enqueued = await _run_scan([unsafe, "clean.txt"])
        assert enqueued == ["clean.txt"]
        assert (tmp / unsafe).exists()
        parsed_dir = tmp / PARSED_DIR_NAME
        archived = (
            [p.name for p in parsed_dir.iterdir()] if parsed_dir.exists() else []
        )
        assert archived == []

    asyncio.run(_run())


@pytest.mark.parametrize("unsafe", SCAN_UNSAFE)
def test_scan_rejects_before_identity_resolution(unsafe):
    """The refusal is scoped to the unsafe file and happens before document
    identity resolution: no doc_status lookup for the rejected name, while the
    clean name IS resolved."""

    async def _run():
        rag, _dm, _tmp, _enqueued = await _run_scan([unsafe, "clean.txt"])
        assert rag.doc_status.lookups == ["clean.txt"]

    asyncio.run(_run())


@pytest.mark.parametrize("unsafe", SCAN_UNSAFE)
def test_scan_status_endpoints_answer_after_an_unsafe_name(unsafe):
    """After a scan met an unsafe name, both status endpoints still answer 200
    and the scan job record says the scan finished."""

    async def _run():
        rag, dm, _tmp, _enqueued = await _run_scan([unsafe, "clean.txt"])
        return _read_status_endpoints(rag, dm)

    pipeline, scan = asyncio.run(_run())
    assert pipeline.status_code == 200, pipeline.text
    assert scan.status_code == 200, scan.text
    assert scan.json()["status"] in ("running", "completed"), scan.text


# ---------------------------------------------------------------------------
# A lone surrogate (a file name that is not valid UTF-8)
# ---------------------------------------------------------------------------


def test_scan_of_surrogate_name_does_not_crash_and_stays_renderable():
    """A lone surrogate is the one unsafe character that makes JSON rendering
    raise (``json.dumps(..., ensure_ascii=False).encode('utf-8')`` is how
    Starlette renders the status endpoints).

    Behavioral contract, format-free:
      * the surrogate-named file is skipped WITHOUT aborting the scan: its clean
        neighbour is still enqueued, and the file stays in the input directory;
      * whatever the scan recorded stays JSON-renderable the way Starlette
        renders it (no UnicodeEncodeError);
      * both status endpoints answer 200, and neither repeats the raw name.

    How the message names the code point (``U+DCFF``, ``\\udcff``, an
    ``ascii()`` escape) is a free choice and is not asserted. The test skips only
    when the filesystem cannot create the file at all; an error raised by the
    scan itself fails the test."""
    surrogate = "scan\udcffsource.txt"

    async def _run():
        rag, dm, tmp, enqueued = await _run_scan([surrogate, "clean.txt"])

        assert enqueued == ["clean.txt"]
        assert (tmp / surrogate).exists()

        history = await _pipeline_history(rag.workspace)
        json.dumps(history, ensure_ascii=False).encode("utf-8")

        pipeline, scan = _read_status_endpoints(rag, dm)
        assert pipeline.status_code == 200, pipeline.text
        assert scan.status_code == 200, scan.text
        assert surrogate not in pipeline.text
        assert surrogate not in scan.text
        assert "\udcff" not in pipeline.text and "\udcff" not in scan.text

    asyncio.run(_run())


# ---------------------------------------------------------------------------
# Already-stored bad sources stay readable and listable
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("value", ALL_UNSAFE_VALUES)
def test_read_path_normalizer_stays_nonraising(value):
    """The shared read-side normalizer must stay non-raising for an already
    stored bad value: normalizing returns a str rather than raising."""
    result = normalize_file_path(value)
    assert isinstance(result, str)


class _ListingDocStatus:
    """A doc_status store that already holds one row with a bad source."""

    def __init__(self, stored_source):
        self._source = stored_source

    async def get_docs_paginated(self, **_kwargs):
        doc = DocProcessingStatus(
            content_summary="stored before the rule existed",
            content_length=10,
            file_path=self._source,
            status=DocStatus.PROCESSED,
            created_at="2026-08-01T00:00:00+00:00",
            updated_at="2026-08-01T00:00:00+00:00",
            track_id="t-1",
        )
        return [("doc-1", doc)], 1

    async def get_all_status_counts(self):
        return {"processed": 1}


@pytest.mark.parametrize(
    "stored",
    [
        pytest.param("old\x0bname.txt", id="vtab"),
        pytest.param("old\ufffename.txt", id="noncharacter"),
    ],
)
def test_document_listing_survives_an_already_stored_bad_source(stored):
    """A row whose stored source already holds a bad character is still listed:
    the listing answers 200 and returns the row."""
    workspace = _fresh_workspace("listing")
    rag = _make_http_rag(workspace, doc_status=_ListingDocStatus(stored))
    doc_manager = DocumentManager(tempfile.mkdtemp())
    with _make_client(rag, doc_manager) as client:
        resp = client.post(
            "/documents/paginated",
            headers=HEADERS,
            json={"page": 1, "page_size": 10},
        )
        _drain_background_tasks(client)
    assert resp.status_code == 200, resp.text
    assert [doc["id"] for doc in resp.json()["documents"]] == ["doc-1"]
