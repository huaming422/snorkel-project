"""Behavioural verifier for clone extras crossing the vapor/virtual-DOM slot
boundary.

The acceptance signal is a TypeScript spec
(`verify_slot_fallthrough.spec.ts`, shipped alongside this file) that mounts a
virtual-DOM "as-child" wrapper over slot content from both a virtual-DOM parent
and a vapor parent and asserts, through the live DOM, that the cloned extras
(attribute, class, style, listener) land identically in both cases. The spec
only runs under the repo's own test toolchain: it needs the jsdom environment,
the `toHaveBeenWarned` matcher, and the package aliases that the repo's vitest
project wires up via `scripts/setup-vitest.ts`.

A second check runs the repo's existing runtime-vapor and runtime-core specs,
at their base-commit content, so ordinary vapor rendering, component
fallthrough and the rest of the interop keep behaving as they did.

So this module is a thin driver. It runs under the isolated verifier
interpreter (stdlib + pytest only, no repository imports), drops the spec into
the repo's interop test directory, invokes the repo's vitest, parses the JSON
reports, and asserts every test passed. Every file it places or swaps is put
back in a `finally`, so the working tree is left as it was.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

REPO_DIR = Path(os.environ.get("REPO_DIR", "/repo/core"))

# The repo's interop specs live here; the project that runs them
# (`unit-jsdom`) includes `packages/.../runtime-vapor/**/*.spec.ts` with the
# jsdom environment and `scripts/setup-vitest.ts` loaded. The spec ships next
# to this file (the generator copies verify/ siblings into /tests/verify/).
SPEC_NAME = "verify_slot_fallthrough.spec.ts"
SPEC_SRC = Path(__file__).parent / SPEC_NAME
SPEC_DEST_DIR = REPO_DIR / "packages" / "runtime-vapor" / "__tests__"

# Scope vitest to the single spec, under the jsdom project that supplies the
# setup file. `--reporter=json` with `--outputFile` writes a machine-readable
# report outside the repo tree so it can never leak into a diff.
VITEST_PROJECT = "unit-jsdom"

# verify.toml's outer budget is 2400s; the three children together stay under it.
VITEST_TIMEOUT_SEC = 600
REGRESSION_TIMEOUT_SEC = {"unit-jsdom": 1200, "unit": 300}

# Existing specs for the packages the interop spans. runtime-vapor specs run
# under `unit-jsdom`, runtime-core specs under `unit` (see vite.config.ts).
# All of runtime-vapor runs, except the gc specs (they need `--expose-gc`, their
# own project) and the e2e and bench directories (they need a browser).
REGRESSION_DIRS = (
    "packages/runtime-vapor/__tests__",
    "packages/runtime-core/__tests__",
)
# The suite is large and a loaded host can push a test past vitest's 5s
# default or starve a worker, so the run is capped at two workers (as the
# image's VITEST_MAX_THREADS intends), gets a longer per-test timeout, and a
# failing test is retried twice: only a failure that repeats counts.
REGRESSION_ARGS = ("--maxWorkers=2", "--testTimeout=30000", "--retry=2")
# From runtime-core, only the specs for vnode cloning, slots, attrs
# fallthrough and the app API the interop plugs into. Its timer-driven specs
# (Suspense, async components) race real timeouts and fail now and then on an
# untouched checkout, so they are not used here.
RUNTIME_CORE_SPECS = frozenset(
    {
        "packages/runtime-core/__tests__/apiCreateApp.spec.ts",
        "packages/runtime-core/__tests__/componentSlots.spec.ts",
        "packages/runtime-core/__tests__/rendererAttrsFallthrough.spec.ts",
        "packages/runtime-core/__tests__/vnode.spec.ts",
        "packages/runtime-core/__tests__/helpers/createSlots.spec.ts",
        "packages/runtime-core/__tests__/helpers/renderSlot.spec.ts",
    }
)
# Written by the image build: the commit the task starts from.
BASE_REF_FILE = Path("/var/lib/devcontainer_base_ref")


def _run(cmd: list[str], timeout: int) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=timeout,
        cwd=str(REPO_DIR),
        check=False,
    )


def _git(*args: str) -> str:
    proc = _run(["git", *args], timeout=120)
    assert proc.returncode == 0, (
        f"git {' '.join(args)} failed (exit {proc.returncode}):\n{proc.stderr}"
    )
    return proc.stdout


def _run_vitest(
    files: list[str],
    project: str,
    report_path: Path,
    timeout: int,
    extra: tuple[str, ...] = (),
) -> dict[str, object]:
    """Run the repo's vitest on `files` and return the parsed JSON report."""
    cmd = ["pnpm", "exec", "vitest", "run", *files, "--project", project, *extra]
    cmd += ["--reporter=json", f"--outputFile={report_path}"]
    proc = _run(cmd, timeout=timeout)

    parsed: dict[str, object] | None = None
    if report_path.is_file():
        try:
            parsed = json.loads(report_path.read_text())
        except (json.JSONDecodeError, OSError):
            parsed = None

    # Fallback: some vitest builds still emit the JSON document on stdout.
    if parsed is None:
        try:
            parsed = json.loads(proc.stdout)
        except json.JSONDecodeError:
            parsed = None

    shown = cmd if len(files) <= 3 else [*cmd[:4], f"<{len(files)} files>", *cmd[4 + len(files):]]
    assert isinstance(parsed, dict), (
        f"could not obtain a vitest JSON report (exit {proc.returncode}).\n"
        f"--- command ---\n{' '.join(shown)}\n"
        f"--- stdout (tail) ---\n{proc.stdout[-3000:]}\n"
        f"--- stderr (tail) ---\n{proc.stderr[-3000:]}"
    )
    parsed["_returncode"] = proc.returncode
    parsed["_stdout_tail"] = proc.stdout[-4000:]
    parsed["_stderr_tail"] = proc.stderr[-4000:]
    return parsed


@pytest.fixture(scope="session")
def vitest_report() -> dict[str, object]:
    """Place the spec, run the repo's vitest once, return the parsed report."""
    assert SPEC_SRC.is_file(), (
        f"behavioural spec {SPEC_SRC} is missing; it must ship next to "
        f"verify.py so the driver can place it into the repo test tree."
    )
    assert SPEC_DEST_DIR.is_dir(), (
        f"expected the interop test directory at {SPEC_DEST_DIR}; the repo "
        f"layout changed or REPO_DIR ({REPO_DIR}) is wrong."
    )

    dest = SPEC_DEST_DIR / SPEC_NAME
    report_path = Path(__file__).parent / "_vitest_report.json"
    try:
        shutil.copy(SPEC_SRC, dest)
        # Run through the repo's local vitest binary so the vite-plus config,
        # jsdom environment, setup file, and package aliases all load. Target
        # the spec by path and scope to the single jsdom project.
        return _run_vitest(
            [str(dest.relative_to(REPO_DIR))],
            VITEST_PROJECT,
            report_path,
            VITEST_TIMEOUT_SEC,
        )
    finally:
        dest.unlink(missing_ok=True)
        report_path.unlink(missing_ok=True)


@pytest.fixture(scope="session")
def regression_report() -> dict[str, object]:
    """Run the existing runtime specs as they were at the base commit.

    The spec files (and their helpers and snapshots) under REGRESSION_DIRS are
    checked out at the base commit for the run, so edits to them do not
    change what is checked. Spec files added since then are not run. Afterwards
    every path is restored to HEAD, which holds the change being graded.
    """
    assert BASE_REF_FILE.is_file(), (
        f"{BASE_REF_FILE} is missing; the image records the starting commit "
        f"there and the existing specs are checked out from it."
    )
    base = BASE_REF_FILE.read_text().strip()
    dirs = list(REGRESSION_DIRS)

    base_paths = _git("ls-tree", "-r", "--name-only", base, "--", *dirs).split()
    head_paths = set(_git("ls-tree", "-r", "--name-only", "HEAD", "--", *dirs).split())
    runs = {
        "unit-jsdom": [
            p
            for p in base_paths
            if p.startswith(REGRESSION_DIRS[0] + "/")
            and p.endswith(".spec.ts")
            and "/e2e/" not in p
            and "/bench/" not in p
            and not p.endswith("gc.spec.ts")
        ],
        "unit": [p for p in base_paths if p in RUNTIME_CORE_SPECS],
    }
    assert all(runs.values()), f"no existing spec files found under {dirs} at {base}"

    report_path = Path(__file__).parent / "_vitest_regression.json"
    merged: dict[str, object] = {
        "_files": [p for files in runs.values() for p in files],
        "testResults": [],
        "numTotalTests": 0,
        "numFailedTests": 0,
        "_stdout_tail": "",
        "_stderr_tail": "",
    }
    try:
        _git("checkout", base, "--", *dirs)
        # one project at a time, so the two suites do not compete for workers
        for project, files in runs.items():
            report = _run_vitest(
                files,
                project,
                report_path,
                REGRESSION_TIMEOUT_SEC[project],
                REGRESSION_ARGS,
            )
            report_path.unlink(missing_ok=True)
            merged["testResults"] += report.get("testResults", []) or []
            for key in ("numTotalTests", "numFailedTests"):
                merged[key] += int(report.get(key, 0) or 0)
            for key in ("_stdout_tail", "_stderr_tail"):
                merged[key] += f"[{project}]\n{report.get(key, '')}\n"
        return merged
    finally:
        _run(["git", "checkout", "HEAD", "--", *dirs], timeout=120)
        # paths that exist at the base commit but not in the graded change
        for p in set(base_paths) - head_paths:
            (REPO_DIR / p).unlink(missing_ok=True)
        _run(["git", "reset", "-q", "--", *dirs], timeout=120)
        report_path.unlink(missing_ok=True)


def _assertions(report: dict[str, object]) -> list[dict[str, object]]:
    """Flatten per-test results from the vitest JSON report."""
    out: list[dict[str, object]] = []
    for suite in report.get("testResults", []) or []:
        for a in suite.get("assertionResults", []) or []:
            out.append(a)
    return out


def test_spec_collected_and_ran(vitest_report: dict[str, object]) -> None:
    """The spec was discovered and produced test results.

    A zero-test run means the project filter matched nothing (the setup file
    never loaded) or the spec failed to collect. Either way the signal is
    invalid and must not be read as success.
    """
    num_total = int(vitest_report.get("numTotalTests", 0) or 0)
    assert num_total > 0, (
        "vitest collected zero tests from the behavioural spec. The spec was "
        "not discovered by the jsdom project, or it failed to load.\n"
        f"--- stdout (tail) ---\n{vitest_report.get('_stdout_tail', '')}\n"
        f"--- stderr (tail) ---\n{vitest_report.get('_stderr_tail', '')}"
    )


def test_all_behaviours_pass(vitest_report: dict[str, object]) -> None:
    """Every behavioural case in the spec passes.

    The spec checks the vapor-parent render against the virtual-DOM-parent
    render for the same clone, so a failure here means the extras diverge
    across the boundary (missing attribute, missing listener, missing/wrong
    class or style), or one of the boundary cases (multi-root content, a
    Teleport root, a forwarding component, scoped slot props, plain vapor
    slots) renders or warns differently from what the spec expects.
    """
    num_total = int(vitest_report.get("numTotalTests", 0) or 0)
    num_failed = int(vitest_report.get("numFailedTests", 0) or 0)
    num_passed = int(vitest_report.get("numPassedTests", 0) or 0)

    if num_failed:
        failed = [
            a.get("fullName") or a.get("title") or "<unnamed>"
            for a in _assertions(vitest_report)
            if a.get("status") != "passed"
        ]
        detail = "\n".join(f"  - {name}" for name in failed)
        pytest.fail(
            f"{num_failed}/{num_total} behavioural case(s) failed "
            f"(passed={num_passed}):\n{detail}\n"
            f"--- stdout (tail) ---\n{vitest_report.get('_stdout_tail', '')}\n"
            f"--- stderr (tail) ---\n{vitest_report.get('_stderr_tail', '')}"
        )

    assert num_passed == num_total, (
        f"expected all {num_total} cases to pass, got {num_passed}."
    )


def test_existing_runtime_specs_still_pass(
    regression_report: dict[str, object],
) -> None:
    """The repo's existing runtime-vapor and runtime-core specs all pass.

    A failure means behaviour those specs already pinned (component
    fallthrough, slots, interop, Transition/KeepAlive/Teleport, vnode cloning)
    changed, or a spec file no longer loads.
    """
    files = regression_report.get("_files", [])
    suites = regression_report.get("testResults", []) or []
    num_total = int(regression_report.get("numTotalTests", 0) or 0)
    num_failed = int(regression_report.get("numFailedTests", 0) or 0)

    broken = [
        str(s.get("name", "")).replace(f"{REPO_DIR}/", "")
        for s in suites
        if s.get("status") != "passed" and not s.get("assertionResults")
    ]
    failed = [
        a.get("fullName") or a.get("title") or "<unnamed>"
        for a in _assertions(regression_report)
        if a.get("status") == "failed"
    ]
    if broken or failed:
        detail = "\n".join(
            [f"  - {name} (did not load)" for name in broken]
            + [f"  - {name}" for name in failed[:40]]
        )
        more = f"\n  ... and {len(failed) - 40} more" if len(failed) > 40 else ""
        pytest.fail(
            f"{num_failed}/{num_total} existing runtime test(s) failed, "
            f"{len(broken)} spec file(s) did not load:\n{detail}{more}\n"
            f"--- stderr (tail) ---\n{regression_report.get('_stderr_tail', '')}"
        )

    reported = {str(s.get("name", "")).replace(f"{REPO_DIR}/", "") for s in suites}
    missing = [f for f in files if f not in reported]
    assert not missing and num_total > 0, (
        f"expected results for {len(files)} existing spec files, vitest "
        f"reported {len(reported)} file(s) and {num_total} test(s). "
        f"No results for: {', '.join(missing[:20])}"
        f"{' ...' if len(missing) > 20 else ''}\n"
        f"--- stdout (tail) ---\n{regression_report.get('_stdout_tail', '')}\n"
        f"--- stderr (tail) ---\n{regression_report.get('_stderr_tail', '')}"
    )
    print(f"existing runtime specs: {len(files)} files, {num_total} tests, none failed")


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v", *sys.argv[1:]]))
