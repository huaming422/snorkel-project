## Task

The "as-child" pattern breaks in apps that mix vapor and virtual-DOM components, when the slot content comes from a vapor parent.

The wrapper is a virtual-DOM component with `inheritAttrs: false`. It takes the first non-comment vnode from `slots.default()` and returns a `cloneVNode` of it with its own attrs merged in, so an attribute, class or click listener passed to the wrapper ends up on whatever the consumer put in the slot. Reka UI's `Slot` works this way. If the parent rendering the wrapper is a virtual-DOM component, that works. If the parent is a vapor component with the same template, the element renders without the attribute or the class and clicking it does nothing.

A vapor parent should produce the same DOM as a virtual-DOM parent here, and stay in step when the wrapper's attrs or the slot content change after mount.

One case can't match. Vapor slot content reaches the wrapper as one block, so when it has more than one root node, or a Teleport as its root, there is no single element to take the extras. Apply none of them in that case and give the usual "Extraneous non-props attributes" dev warning, as a component with that kind of root does.

Fix it in the framework, not in the wrapper, and keep the public API as it is. Don't weaken existing tests; they should keep passing. Snapshot tests that record the compiler's output may be updated if your change alters it. Vapor slots that are never cloned shouldn't behave any differently.
