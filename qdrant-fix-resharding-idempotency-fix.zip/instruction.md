## Task

We run Qdrant as a multi-peer cluster, and our chaos tests (which restart peers at
random) keep leaving collections out of sync after resharding. If a peer restarts
while a shard is being added or removed, or shortly after, it comes back with the
wrong shard set. It might be missing a shard the other peers have, hold an extra
shard nobody else has, or have a persisted shard count that doesn't match the
shards it actually holds.

The peer never recovers from this on its own, and the collection can't be
resharded again after that. Resharding with no restarts works fine.

Find out why a restart leaves the peer out of sync and fix it so the peer ends up
matching the rest of the cluster. A normal resharding with no restart should keep
working the way it does today. Don't change the API, the wire format, or the config.
