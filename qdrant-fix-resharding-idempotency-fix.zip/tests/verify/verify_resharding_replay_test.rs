//! Resharding steps re-applied after a peer restart.
//!
//! Each scenario puts a collection on disk in the state a peer can be in
//! when it restarts partway through a resharding step (resharding state
//! written or cleared, persisted shard count not yet matching), reloads the
//! collection the way a restarting peer does, applies the same resharding
//! step again, and checks that the peer ends up with the same shard count and
//! shard set as a peer that applied the step once with no restart.
//!
//! Everything goes through public `Collection` methods:
//!   * Entry points: `Collection::start/finish/abort_resharding`,
//!     `commit_read_hashring`, `commit_write_hashring`, `new` and `load`.
//!   * Restart states are written to `config.json` and
//!     `resharding_state.json`, the collection's existing on-disk files.
//!   * Observations: `Collection::state().config.params.shard_number` (the
//!     persisted shard count) and `Collection::get_local_shards()` (the
//!     shard id set).
//!   * Helpers: `new_collection` and `reload_collection`, defined below.

use std::num::NonZeroU32;
use std::path::Path;
use std::sync::Arc;

use async_trait::async_trait;
use collection::collection::{Collection, RequestShardTransfer};
use collection::config::{CollectionConfigInternal, CollectionParams, WalConfig};
use collection::operations::cluster_ops::ReshardingDirection;
use collection::operations::types::CollectionResult;
use collection::operations::vector_params_builder::VectorParamsBuilder;
use collection::optimizers_builder::OptimizersConfig;
use collection::shards::channel_service::ChannelService;
use collection::shards::collection_shard_distribution::CollectionShardDistribution;
use collection::shards::replica_set::replica_set_state::ReplicaState;
use collection::shards::replica_set::{AbortShardTransfer, ChangePeerFromState};
use collection::shards::resharding::{ReshardKey, ReshardState, ReshardingStage};
use collection::shards::shard::{PeerId, ShardId};
use collection::shards::transfer::{
    ShardTransfer, ShardTransferConsensus, ShardTransferKey, ShardTransferMethod,
};
use collection::shards::CollectionId;
use common::budget::ResourceBudget;
use segment::types::Distance;
use tempfile::Builder;
use uuid::Uuid;

// ---------------------------------------------------------------------------
// Stub implementations
// ---------------------------------------------------------------------------

const REST_PORT: u16 = 6333;

const TEST_OPTIMIZERS_CONFIG: OptimizersConfig = OptimizersConfig {
    deleted_threshold: 0.9,
    vacuum_min_vector_number: 1000,
    default_segment_number: 2,
    max_segment_size: None,
    #[expect(deprecated)]
    memmap_threshold: None,
    indexing_threshold: Some(50_000),
    flush_interval_sec: 30,
    max_optimization_threads: Some(2),
    prevent_unoptimized: None,
};

/// Minimal no-op consensus stub for the `Box<dyn ShardTransferConsensus>`
/// argument of `Collection::start_resharding`. A single-peer collection does
/// not need any of these calls to do real work.
struct NopConsensus;

#[async_trait]
impl ShardTransferConsensus for NopConsensus {
    fn this_peer_id(&self) -> PeerId {
        0
    }
    fn peers(&self) -> Vec<PeerId> {
        vec![0]
    }
    fn consensus_commit_term(&self) -> (u64, u64) {
        (0, 0)
    }
    fn recovered_switch_to_partial(
        &self,
        _transfer_config: &ShardTransfer,
        _collection_id: CollectionId,
    ) -> CollectionResult<()> {
        Ok(())
    }
    async fn start_shard_transfer(
        &self,
        _transfer_config: ShardTransfer,
        _collection_id: CollectionId,
    ) -> CollectionResult<()> {
        Ok(())
    }
    async fn restart_shard_transfer(
        &self,
        _transfer_config: ShardTransfer,
        _collection_id: CollectionId,
        _default_method: ShardTransferMethod,
    ) -> CollectionResult<()> {
        Ok(())
    }
    async fn abort_shard_transfer(
        &self,
        _transfer: ShardTransferKey,
        _collection_id: CollectionId,
        _reason: &str,
    ) -> CollectionResult<()> {
        Ok(())
    }
    async fn set_shard_replica_set_state(
        &self,
        _peer_id: Option<PeerId>,
        _collection_id: CollectionId,
        _shard_id: ShardId,
        _state: ReplicaState,
        _from_state: Option<ReplicaState>,
    ) -> CollectionResult<()> {
        Ok(())
    }
    async fn commit_read_hashring(
        &self,
        _collection_id: CollectionId,
        _reshard_key: ReshardKey,
    ) -> CollectionResult<()> {
        Ok(())
    }
    async fn commit_write_hashring(
        &self,
        _collection_id: CollectionId,
        _reshard_key: ReshardKey,
    ) -> CollectionResult<()> {
        Ok(())
    }
}

fn nop_consensus() -> Box<NopConsensus> {
    Box::new(NopConsensus)
}

fn dummy_on_replica_failure() -> ChangePeerFromState {
    Arc::new(move |_peer_id, _shard_id, _from_state| {})
}

fn dummy_request_shard_transfer() -> RequestShardTransfer {
    Arc::new(move |_transfer| {})
}

fn dummy_abort_shard_transfer() -> AbortShardTransfer {
    Arc::new(|_transfer, _reason| {})
}

fn collection_config(shard_number: u32) -> CollectionConfigInternal {
    CollectionConfigInternal {
        params: CollectionParams {
            vectors: VectorParamsBuilder::new(4, Distance::Dot).build().into(),
            shard_number: NonZeroU32::new(shard_number).unwrap(),
            ..CollectionParams::empty()
        },
        optimizer_config: TEST_OPTIMIZERS_CONFIG.clone(),
        wal_config: WalConfig {
            wal_capacity_mb: 1,
            wal_segments_ahead: 0,
            wal_retain_closed: 1,
        },
        hnsw_config: Default::default(),
        quantization_config: Default::default(),
        strict_mode_config: Default::default(),
        uuid: None,
        metadata: None,
    }
}

/// Create a fresh collection with `shard_number` shards, all local + Active.
async fn new_collection(path: &Path, shard_number: u32) -> Collection {
    let snapshots = path.join("snapshots");
    std::fs::create_dir_all(&snapshots).unwrap();
    let config = collection_config(shard_number);
    let collection = Collection::new(
        "test".to_string(),
        0,
        path,
        &snapshots,
        &config,
        Default::default(),
        CollectionShardDistribution::all_local(Some(config.params.shard_number.into()), 0),
        None,
        ChannelService::new(REST_PORT, false, None, None),
        dummy_on_replica_failure(),
        dummy_request_shard_transfer(),
        dummy_abort_shard_transfer(),
        None,
        None,
        ResourceBudget::default(),
        None,
    )
    .await
    .expect("Collection::new should succeed");

    for shard_id in collection.get_local_shards().await {
        collection
            .set_shard_replica_state(shard_id, 0, ReplicaState::Active, None)
            .await
            .expect("set_shard_replica_state should succeed");
    }
    collection
}

/// Reload collection from disk — identical to what a node does on restart.
async fn reload_collection(path: &Path) -> Collection {
    let snapshots = path.join("snapshots");
    Collection::load(
        "test".to_string(),
        0,
        path,
        &snapshots,
        Default::default(),
        ChannelService::new(REST_PORT, false, None, None),
        dummy_on_replica_failure(),
        dummy_request_shard_transfer(),
        dummy_abort_shard_transfer(),
        None,
        None,
        ResourceBudget::default(),
        None,
    )
    .await
}

/// Observe the persisted shard count via the public State snapshot.
async fn persisted_shard_count(c: &Collection) -> u32 {
    c.state().await.config.params.shard_number.get()
}

/// Sorted shard ID set via the public `get_local_shards` method.
async fn sorted_shard_ids(c: &Collection) -> Vec<ShardId> {
    let mut ids = c.get_local_shards().await;
    ids.sort_unstable();
    ids
}

fn up_key(shard_id: u32) -> ReshardKey {
    ReshardKey {
        uuid: Uuid::new_v4(),
        direction: ReshardingDirection::Up,
        peer_id: 0,
        shard_id,
        shard_key: None,
    }
}

fn down_key(shard_id: u32) -> ReshardKey {
    ReshardKey {
        uuid: Uuid::new_v4(),
        direction: ReshardingDirection::Down,
        peer_id: 0,
        shard_id,
        shard_key: None,
    }
}

// ---------------------------------------------------------------------------
// Restart-state helpers
//
// These write the collection's existing on-disk files with plain
// `serde_json` to put a collection in the state a peer is left in when it
// restarts partway through a resharding step.
// ---------------------------------------------------------------------------

/// Path of `config.json` relative to the collection root.
const COLLECTION_CONFIG_FILE: &str = "config.json";
/// Path of `resharding_state.json` relative to the collection root.
const RESHARDING_STATE_FILE: &str = "resharding_state.json";

/// Overwrite `config.json` on disk so that `params.shard_number` equals
/// `n`, as if the peer stopped before the new shard count was saved.
fn corrupt_config_shard_number(collection_path: &Path, n: u32) {
    let config_path = collection_path.join(COLLECTION_CONFIG_FILE);
    let raw = std::fs::read_to_string(&config_path)
        .expect("config.json must exist at collection_path");
    let mut v: serde_json::Value = serde_json::from_str(&raw).expect("config.json valid JSON");
    v["params"]["shard_number"] = serde_json::json!(n);
    std::fs::write(&config_path, serde_json::to_string_pretty(&v).unwrap())
        .expect("write corrupted config.json");
}

/// Write `resharding_state.json` to Some(state) for the given key, as if the
/// peer stopped right after the resharding state was saved.
fn inject_resharding_state(collection_path: &Path, key: &ReshardKey, stage: ReshardingStage) {
    let state = ReshardState {
        uuid: key.uuid,
        peer_id: key.peer_id,
        shard_id: key.shard_id,
        shard_key: key.shard_key.clone(),
        direction: key.direction,
        stage,
    };
    let state_path = collection_path.join(RESHARDING_STATE_FILE);
    let json = serde_json::to_string_pretty(&Some::<ReshardState>(state))
        .expect("serialize ReshardState");
    std::fs::write(state_path, json).expect("write resharding_state.json");
}

/// Clear `resharding_state.json` to None, as if the peer stopped after the
/// resharding state was cleared but before the shard set and shard count
/// were brought in line.
fn clear_resharding_state(collection_path: &Path) {
    let state_path = collection_path.join(RESHARDING_STATE_FILE);
    std::fs::write(state_path, "null").expect("write null resharding_state.json");
}

// ---------------------------------------------------------------------------
// FAIL-TO-PASS tests (3 f2p)
// ---------------------------------------------------------------------------

/// Restart during a scale-up start: the resharding state for the new shard
/// is saved, but the persisted shard count still holds the old value.
///
/// After the restart and a second apply of the same start, the peer must
/// hold the new shard and report the raised shard count, the same as a peer
/// that applied the start once.
#[tokio::test(flavor = "multi_thread")]
async fn start_replay_reconverges() {
    let dir = Builder::new().prefix("start_replay").tempdir().unwrap();
    // Adding shard 1 to a 1-shard collection gives a shard count of 2.
    let key = up_key(1);

    // ── Step 1: full first apply (reference state) ──
    let c1 = new_collection(dir.path(), 1).await;
    c1.start_resharding(key.clone(), nop_consensus(), async {}, async {})
        .await
        .expect("first-time start_resharding must succeed");
    // After a successful start: shard_number=2, shard_set contains shard 1.
    let count_after_one = persisted_shard_count(&c1).await;
    let shards_after_one = sorted_shard_ids(&c1).await;
    assert_eq!(count_after_one, 2, "precondition: start raised count to 2");
    c1.stop_gracefully().await;
    drop(c1);

    // ── Step 2: restart state ──
    // The resharding state from the first apply stays on disk; the saved
    // shard count goes back to 1.
    corrupt_config_shard_number(dir.path(), 1);

    // ── Step 3: reload (peer restart) + second apply ──
    let c2 = reload_collection(dir.path()).await;
    // Loading may already repair the count, so both values are accepted here.
    let count_after_reload = persisted_shard_count(&c2).await;
    assert!(
        count_after_reload == 1 || count_after_reload == 2,
        "after restart: shard_number must be the saved value (1) or the repaired value (2), \
         got {count_after_reload}",
    );
    c2.start_resharding(key.clone(), nop_consensus(), async {}, async {})
        .await
        .expect("applying the same start_resharding again after a restart must not error");

    // ── Step 4: assert convergence ──
    let count_after_replay = persisted_shard_count(&c2).await;
    let shards_after_replay = sorted_shard_ids(&c2).await;

    assert_eq!(
        count_after_replay, count_after_one,
        "persisted shard_number after restart and second start must equal the \
         single-apply value ({count_after_one})",
    );
    assert_eq!(
        shards_after_replay, shards_after_one,
        "shard ID set after restart and second start must equal the single-apply set \
         ({shards_after_one:?})",
    );

    c2.stop_gracefully().await;
}

/// Restart during a scale-down finish: the resharding state is already
/// cleared, but shard 2 is still on disk and the persisted shard count is
/// still 3.
///
/// After the restart and a second apply of the same finish, the peer must no
/// longer hold shard 2 and must report a shard count of 2, the same as a peer
/// that applied the finish once.
#[tokio::test(flavor = "multi_thread")]
async fn finish_replay_reconverges() {
    let dir = Builder::new().prefix("finish_replay").tempdir().unwrap();
    // Scale-down: remove shard_id=2 from a 3-shard collection.
    let key_down = down_key(2);

    // ── Step 1: reference state — what a single clean apply produces ──
    // Run start, commit_read, commit_write and finish on a clean collection
    // in its own dir to get the expected end state.
    let c_ref = new_collection(dir.path().join("ref").as_path(), 3).await;
    c_ref
        .start_resharding(key_down.clone(), nop_consensus(), async {}, async {})
        .await
        .expect("ref: start scale-down");
    c_ref
        .commit_read_hashring(&key_down)
        .await
        .expect("ref: commit_read_hashring");
    c_ref
        .commit_write_hashring(&key_down)
        .await
        .expect("ref: commit_write_hashring");
    c_ref
        .finish_resharding(key_down.clone())
        .await
        .expect("ref: finish_resharding must succeed on clean collection");
    let count_after_one = persisted_shard_count(&c_ref).await;
    let shards_after_one = sorted_shard_ids(&c_ref).await;
    // After finish: shard_number=2, shard_set is {0,1}.
    assert_eq!(count_after_one, 2, "precondition: finish reduced count to 2");
    c_ref.stop_gracefully().await;
    drop(c_ref);

    // ── Step 2: build the restart state on a separate collection dir ──
    // On disk: resharding_state=None, shard_number=3, shard 2 EXISTS.
    let coll_path = dir.path().join("crash");
    std::fs::create_dir_all(&coll_path).unwrap();
    let snapshots = coll_path.join("snapshots");
    std::fs::create_dir_all(&snapshots).unwrap();

    // Create a 3-shard collection and drive it to the WriteHashRingCommitted
    // stage, but NOT call finish_resharding.
    let c1 = new_collection(&coll_path, 3).await;
    c1.start_resharding(key_down.clone(), nop_consensus(), async {}, async {})
        .await
        .expect("start scale-down");
    c1.commit_read_hashring(&key_down)
        .await
        .expect("commit_read_hashring");
    c1.commit_write_hashring(&key_down)
        .await
        .expect("commit_write_hashring");
    // Clear resharding_state.json on disk. Shard 2 is still on disk and
    // shard_number is still 3.
    c1.stop_gracefully().await;
    drop(c1);
    clear_resharding_state(&coll_path);

    // ── Step 3: reload (peer restart) ──
    let c2 = reload_collection(&coll_path).await;
    assert_eq!(
        persisted_shard_count(&c2).await,
        3,
        "after restart: shard_number must still be 3 (the value saved before finish)",
    );
    assert!(
        sorted_shard_ids(&c2).await.contains(&2),
        "after restart: shard 2 must still be loaded",
    );

    // ── Step 4: apply finish_resharding again ──
    c2.finish_resharding(key_down.clone())
        .await
        .expect("applying the same finish_resharding again after a restart must not error");

    // ── Step 5: assert convergence ──
    let count_after_replay = persisted_shard_count(&c2).await;
    let shards_after_replay = sorted_shard_ids(&c2).await;

    assert_eq!(
        count_after_replay, count_after_one,
        "persisted shard_number after restart and second finish must equal the \
         single-apply value ({count_after_one})",
    );
    assert_eq!(
        shards_after_replay, shards_after_one,
        "shard ID set after restart and second finish must equal the single-apply set \
         ({shards_after_one:?})",
    );

    c2.stop_gracefully().await;
}

/// Restart during a scale-up abort: the resharding state is already cleared,
/// but the new shard 2 is still on disk and the persisted shard count is
/// still 3.
///
/// After the restart and a second apply of the same abort, the peer must no
/// longer hold shard 2 and must report a shard count of 2, the same as a peer
/// that applied the abort once.
#[tokio::test(flavor = "multi_thread")]
async fn abort_replay_reconverges() {
    let dir = Builder::new().prefix("abort_replay").tempdir().unwrap();
    // Abort a scale-up of shard_id=2 on a 2-shard collection.
    let key = up_key(2);

    // ── Step 1: reference state — what a single clean apply produces ──
    let c_ref = new_collection(dir.path().join("ref").as_path(), 2).await;
    c_ref
        .start_resharding(key.clone(), nop_consensus(), async {}, async {})
        .await
        .expect("ref: start scale-up");
    c_ref
        .abort_resharding(key.clone(), false)
        .await
        .expect("ref: abort_resharding must succeed");
    let count_after_one = persisted_shard_count(&c_ref).await;
    let shards_after_one = sorted_shard_ids(&c_ref).await;
    // After abort-up: shard_number=2, shard_set is {0,1}.
    assert_eq!(count_after_one, 2, "precondition: abort restored count to 2");
    c_ref.stop_gracefully().await;
    drop(c_ref);

    // ── Step 2: build the restart state on a separate collection dir ──
    // On disk: resharding_state=None, shard_number=3, shard 2 EXISTS.
    let coll_path = dir.path().join("crash");
    std::fs::create_dir_all(&coll_path).unwrap();
    let snapshots = coll_path.join("snapshots");
    std::fs::create_dir_all(&snapshots).unwrap();

    let c1 = new_collection(&coll_path, 2).await;
    c1.start_resharding(key.clone(), nop_consensus(), async {}, async {})
        .await
        .expect("start scale-up");
    // After start: shard_number=3, shard 2 on disk, resharding_state=Some.
    assert_eq!(
        persisted_shard_count(&c1).await,
        3,
        "precondition: start raised count to 3",
    );
    // Clear resharding_state.json on disk. Shard 2 is still on disk and
    // shard_number is still 3.
    c1.stop_gracefully().await;
    drop(c1);
    clear_resharding_state(&coll_path);

    // ── Step 3: reload (peer restart) ──
    let c2 = reload_collection(&coll_path).await;
    assert_eq!(
        persisted_shard_count(&c2).await,
        3,
        "after restart: shard_number must still be 3 (the value saved before abort)",
    );
    assert!(
        sorted_shard_ids(&c2).await.contains(&2),
        "after restart: shard 2 must still be loaded",
    );

    // ── Step 4: apply abort_resharding again ──
    c2.abort_resharding(key.clone(), false)
        .await
        .expect("applying the same abort_resharding again after a restart must not error");

    // ── Step 5: assert convergence ──
    let count_after_replay = persisted_shard_count(&c2).await;
    let shards_after_replay = sorted_shard_ids(&c2).await;

    assert_eq!(
        count_after_replay, count_after_one,
        "persisted shard_number after restart and second abort must equal the \
         single-apply value ({count_after_one})",
    );
    assert_eq!(
        shards_after_replay, shards_after_one,
        "shard ID set after restart and second abort must equal the single-apply set \
         ({shards_after_one:?})",
    );

    c2.stop_gracefully().await;
}

// ---------------------------------------------------------------------------
// PASS-TO-PASS tests (3 p2p): full apply, restart, apply again
//
// The step was fully applied before the restart, so the shard count is
// already correct. Applying the same step again must leave the shard count
// and the shard set unchanged.
// ---------------------------------------------------------------------------

/// Full apply, restart, then the same `start_resharding` again: the shard
/// count must stay at 2 and the shard set must not change.
#[tokio::test(flavor = "multi_thread")]
async fn start_replay_idempotent() {
    let dir = Builder::new().prefix("start_idem").tempdir().unwrap();
    let key = up_key(1);

    // ── Step 1: full first apply ──
    let c1 = new_collection(dir.path(), 1).await;
    c1.start_resharding(key.clone(), nop_consensus(), async {}, async {})
        .await
        .expect("first start_resharding must succeed");
    let count_after_one = persisted_shard_count(&c1).await;
    let shards_after_one = sorted_shard_ids(&c1).await;
    assert_eq!(count_after_one, 2, "precondition: shard_number=2 after start");
    c1.stop_gracefully().await;
    drop(c1);

    // ── Step 2: reload, shard_number stays 2 on disk ──
    let c2 = reload_collection(dir.path()).await;
    assert_eq!(
        persisted_shard_count(&c2).await,
        2,
        "precondition: shard_number=2 persisted correctly after full apply",
    );

    // ── Step 3: apply the same start again (count already correct) ──
    c2.start_resharding(key.clone(), nop_consensus(), async {}, async {})
        .await
        .expect("applying the same start_resharding again after a restart must not error");

    // ── Step 4: assert no drift ──
    let count_after_replay = persisted_shard_count(&c2).await;
    let shards_after_replay = sorted_shard_ids(&c2).await;

    assert_eq!(
        count_after_replay, count_after_one,
        "shard_number must stay at {count_after_one} when the same start is applied again",
    );
    assert_eq!(
        shards_after_replay, shards_after_one,
        "shard ID set must not change when the same start is applied again",
    );

    c2.stop_gracefully().await;
}

/// Full apply, restart, then the same `finish_resharding` again: the shard
/// count must stay at 2 and the shard set must not change.
#[tokio::test(flavor = "multi_thread")]
async fn finish_replay_idempotent() {
    let dir = Builder::new().prefix("finish_idem").tempdir().unwrap();
    let key_down = down_key(2);

    // ── Step 1: full apply (3-shard collection → finish scale-down) ──
    let c1 = new_collection(dir.path(), 3).await;
    c1.start_resharding(key_down.clone(), nop_consensus(), async {}, async {})
        .await
        .expect("start scale-down");
    c1.commit_read_hashring(&key_down)
        .await
        .expect("commit_read_hashring");
    c1.commit_write_hashring(&key_down)
        .await
        .expect("commit_write_hashring");
    c1.finish_resharding(key_down.clone())
        .await
        .expect("finish_resharding must succeed on clean collection");
    let count_after_one = persisted_shard_count(&c1).await;
    let shards_after_one = sorted_shard_ids(&c1).await;
    assert_eq!(count_after_one, 2, "precondition: shard_number=2 after finish");
    c1.stop_gracefully().await;
    drop(c1);

    // ── Step 2: reload, shard_number stays 2 ──
    let c2 = reload_collection(dir.path()).await;
    assert_eq!(
        persisted_shard_count(&c2).await,
        2,
        "precondition: shard_number=2 persisted correctly after full finish",
    );

    // ── Step 3: apply the same finish again (shard 2 already gone) ──
    c2.finish_resharding(key_down.clone())
        .await
        .expect("applying the same finish_resharding again after a restart must not error");

    // ── Step 4: assert no drift ──
    let count_after_replay = persisted_shard_count(&c2).await;
    let shards_after_replay = sorted_shard_ids(&c2).await;

    assert_eq!(
        count_after_replay, count_after_one,
        "shard_number must stay at {count_after_one} when the same finish is applied again",
    );
    assert_eq!(
        shards_after_replay, shards_after_one,
        "shard ID set must not change when the same finish is applied again",
    );

    c2.stop_gracefully().await;
}

/// Full apply, restart, then the same `abort_resharding` again: the shard
/// count must stay at 2 and the shard set must not change.
#[tokio::test(flavor = "multi_thread")]
async fn abort_replay_idempotent() {
    let dir = Builder::new().prefix("abort_idem").tempdir().unwrap();
    let key = up_key(2);

    // ── Step 1: full apply (start + abort on a 2-shard collection) ──
    let c1 = new_collection(dir.path(), 2).await;
    c1.start_resharding(key.clone(), nop_consensus(), async {}, async {})
        .await
        .expect("start scale-up");
    c1.abort_resharding(key.clone(), false)
        .await
        .expect("abort_resharding must succeed");
    let count_after_one = persisted_shard_count(&c1).await;
    let shards_after_one = sorted_shard_ids(&c1).await;
    assert_eq!(count_after_one, 2, "precondition: shard_number=2 after abort");
    c1.stop_gracefully().await;
    drop(c1);

    // ── Step 2: reload, shard_number stays 2 ──
    let c2 = reload_collection(dir.path()).await;
    assert_eq!(
        persisted_shard_count(&c2).await,
        2,
        "precondition: shard_number=2 persisted correctly after full abort",
    );

    // ── Step 3: apply the same abort again (shard 2 already gone) ──
    c2.abort_resharding(key.clone(), false)
        .await
        .expect("applying the same abort_resharding again after a restart must not error");

    // ── Step 4: assert no drift ──
    let count_after_replay = persisted_shard_count(&c2).await;
    let shards_after_replay = sorted_shard_ids(&c2).await;

    assert_eq!(
        count_after_replay, count_after_one,
        "shard_number must stay at {count_after_one} when the same abort is applied again",
    );
    assert_eq!(
        shards_after_replay, shards_after_one,
        "shard ID set must not change when the same abort is applied again",
    );

    c2.stop_gracefully().await;
}

// ---------------------------------------------------------------------------
// PASS-TO-PASS test (1 p2p)
// ---------------------------------------------------------------------------

/// Happy path: a first-time start on a fresh collection registers the new
/// shard, raises the persisted count, and records the resharding state.
#[tokio::test(flavor = "multi_thread")]
async fn first_apply_still_registers() {
    let dir = Builder::new().prefix("first_apply").tempdir().unwrap();
    let key = up_key(1);

    let c = new_collection(dir.path(), 1).await;
    assert_eq!(
        persisted_shard_count(&c).await,
        1,
        "precondition: fresh 1-shard collection has shard_number=1",
    );

    c.start_resharding(key.clone(), nop_consensus(), async {}, async {})
        .await
        .expect("first-time start_resharding on a clean collection must succeed");

    let count = persisted_shard_count(&c).await;
    let shards = sorted_shard_ids(&c).await;

    assert_eq!(
        count, 2,
        "a first-time scale-up start must increase shard_number to 2",
    );
    assert!(
        shards.contains(&1),
        "a first-time start must register the new shard id in the shard set, got: {shards:?}",
    );
    assert!(
        c.resharding_state().await.is_some(),
        "a first-time start must record resharding state",
    );

    c.stop_gracefully().await;
}
