#!/usr/bin/env bash
# Test-setup for qdrant-fix-resharding-idempotency.
#
# The verifier is a `cargo test` integration test injected into
# `lib/collection/tests/` and run against the pre-existing public `collection`
# crate API. The image already bakes the full workspace dependency closure and
# pre-warms `cargo build --locked --tests` at the base commit (Dockerfile block
# 7), so compiling the injected integration test only recompiles that test plus
# the `collection` crate's test target — no network needed. Nothing to install,
# no services to start, no data to seed.
set -euo pipefail

echo "[test-setup] Rust:        $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo:       $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace:   /repo/qdrant"
echo "[test-setup] Collection crate present: $(test -f /repo/qdrant/lib/collection/Cargo.toml && echo yes || echo no)"
echo "[test-setup] Setup complete."
