#!/usr/bin/env bash
# Runs the missing-plugin deferral scenario through mise's own end-to-end harness
# (e2e/run_test) against the freshly built mise binary.
#
# Covers: when the backing plugin is absent, resolution is deferred for literal,
# prefix, and ref selectors so the request stays discoverable (listing reports the
# selector with installed=false and emits no spurious not-in-lockfile warning);
# once the plugin exists, the deferred request passes the locked check before any
# unlocked resolution. The scenario body (test_lockfile_missing_plugin) is shipped
# alongside this file and parses the listing with jq (baked into the image).
#
# The harness puts "$CARGO_TARGET_DIR/debug" first on PATH, so the built mise is
# the one under test. Guarded with :- so an outer override always wins.
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"

exec bash /repo/mise/e2e/run_test /tests/verify/test_lockfile_missing_plugin
