#!/usr/bin/env bash
# Runs the candidate-selection scenario through mise's own end-to-end harness
# (e2e/run_test) against the freshly built mise binary.
#
# Covers how a binding whose recorded backend is unavailable/disabled/mismatched
# is treated during candidate selection: it must not block a valid binding in the
# same file, must not be adopted as a fallback, and must not mask a genuine
# ambiguity between two valid bindings. The scenario body
# (test_lockfile_candidate_errors) is shipped alongside this file.
#
# The harness puts "$CARGO_TARGET_DIR/debug" first on PATH, so the built mise is
# the one under test. Guarded with :- so an outer override always wins.
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"

exec bash /repo/mise/e2e/run_test /tests/verify/test_lockfile_candidate_errors
