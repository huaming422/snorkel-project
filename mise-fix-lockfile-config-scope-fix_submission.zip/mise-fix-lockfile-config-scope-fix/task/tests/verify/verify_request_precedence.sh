#!/usr/bin/env bash
# Runs the config-scoped lockfile precedence scenario through mise's own
# end-to-end harness (e2e/run_test) against the freshly built mise binary.
#
# The harness builds an isolated HOME, symlinks the offline `dummy` asdf plugin,
# and sources the scenario body (test_lockfile_request_precedence, shipped
# alongside this file) under its shell assertion helpers. The harness exits
# non-zero on the first failed assertion, which this wrapper propagates.
#
# CARGO_TARGET_DIR is where the image caches the build; the harness puts
# "$CARGO_TARGET_DIR/debug" first on PATH, so the built mise is the one under
# test. Guarded with :- so an outer override always wins.
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"

exec bash /repo/mise/e2e/run_test /tests/verify/test_lockfile_request_precedence
