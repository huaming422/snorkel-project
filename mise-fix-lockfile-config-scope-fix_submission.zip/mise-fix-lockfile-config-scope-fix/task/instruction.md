## Task

We're getting a bogus error out of `mise which`. When a project pins a tool to a floating version like `latest`, asking which binary that resolves to fails with a complaint that the lockfile holds multiple conflicting resolutions for that tool and version, even though ordinary resolution settles on a version without trouble.

It happens when the same tool is pinned the same way in both the project config and the global config, and each has its own lockfile that recorded a different resolved version. From inside the project the lookup should land on the version the project's own config and lockfile select, the same one plain non-locked resolution returns, instead of merging the two configs' independent pins and calling them ambiguous.

The same resolution path backs exec and the locked-mode checks, so keep those consistent: no spurious ambiguity or missing-entry errors for tools that resolve cleanly. This is strictly a resolution bug; lockfile formats, writing, migration, and shared-monorepo merge rules should stay as they are.

Track down why the runtime lookup conflates the two configs' pins and fix it.
