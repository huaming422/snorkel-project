# A project that mise knows about but has never genuinely resolved has no recorded
# result for its computed tool version. Prune must then keep every installation of
# that computed tool (it cannot tell which one is in use) while still pruning
# unrelated versions, and must not fail. The no-record state is reached without
# assuming where (or whether) the fix stores records: the versions are installed
# by explicit argument (no in-project resolve, so nothing is recorded), and the
# config is brought to mise's attention only by an inspection command, which by
# contract never records.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project/child elsewhere
echo '[vars]
v = "1.0.0"' >project/mise.toml
echo '[tools]
dummy = "{{vars.v}}"
tiny = "2.0.0"' >project/child/mise.toml

# Install the versions directly, never resolving the project's tools, so no
# genuine in-project resolution happens and nothing is recorded for the project.
assert "mise install dummy@1.0.0 dummy@3.0.0 tiny@2.0.0 tiny@3.0.0"

# Make mise aware of the project the only way that is guaranteed not to record:
# an inspection of it from inside the project.
assert "mise -C project/child ls --prunable --json >/dev/null"

# With no record for the computed tool, every dummy is kept; the non-templated
# tiny resolves normally, so the version the project uses (2.0.0) is kept and the
# unrelated 3.0.0 is prunable.
assert "mise -C elsewhere ls --prunable --json >prunable.json"
assert "jq -e 'has(\"dummy\") | not' prunable.json"
assert "jq -e '[.tiny[].version] == [\"3.0.0\"]' prunable.json"

# Prune must not fail for such a project.
assert "mise -C elsewhere prune --dry-run"
SCENARIO
