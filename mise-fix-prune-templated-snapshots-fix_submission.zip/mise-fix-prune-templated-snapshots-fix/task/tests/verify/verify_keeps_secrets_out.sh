# A credential carried in a tool's install_env must never be written in the clear
# to whatever on-disk record the fix keeps; prune instead keeps every installation
# of such a tool.
#
# The search looks only where the fix keeps its resolution record — a sibling of
# the state directory, or alongside the catalog under installs/.mise — and never
# the tool payloads, the compatibility links, or the pre-existing identity
# catalog. That exclusion matters: the test backend copies the whole process
# environment (install_env included) into its own installation directory under
# installs/, and the pre-existing catalog stores a digest of install_env; neither
# is the fix's record, and both predate it. Scanning by content tolerates any
# record shape — one file per config, a single index, or a sibling state
# directory.
#
# That a tool carrying options is kept in full rather than deleted (the same
# conservative rule that protects any unstorable option, secret or not) is also
# asserted here and, for a plain templated option, in verify_templated_options.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project elsewhere
echo '[tools]
dummy = { version = "{{env.PRUNE_VERSION}}", install_env = { API_TOKEN = "{{env.SECRET}}" } }' >project/mise.toml
assert "PRUNE_VERSION=1.0.0 SECRET=hunter2-s3cret mise -C project install"
assert "mise install dummy@3.0.0"

# Search only the fix's resolution record, by content. Neither the secret value
# nor the install_env key name may appear there in the clear.
record_grep() {
  {
    find "$MISE_STATE_DIR" -type f -print0 2>/dev/null
    find "$MISE_DATA_DIR/installs/.mise" -type f \
      -not -path '*/identities/*' -not -path '*/selections/*' \
      -not -path '*/names/*' -not -path '*/ambiguous/*' \
      -not -path '*/locks/*' -print0 2>/dev/null
  } | xargs -0r grep -IlF "$1" 2>/dev/null || true
}
export -f record_grep
for leak in hunter2-s3cret API_TOKEN; do
  assert_empty "record_grep '$leak'"
done

# A tool whose options cannot be stored is never recorded, so prune keeps every
# installation of it rather than deleting one.
assert "mise -C elsewhere ls --prunable --json >prunable.json"
assert "jq -e 'has(\"dummy\") | not' prunable.json"
SCENARIO
