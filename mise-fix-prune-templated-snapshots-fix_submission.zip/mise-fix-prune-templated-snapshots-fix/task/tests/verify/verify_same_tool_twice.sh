# A project that resolves one tool at two computed versions keeps both, while an
# unrelated version of the same tool is still prunable. Expressed purely through
# what prune reports, so it holds regardless of how the two versions are recorded.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project/child elsewhere
echo '[vars]
a = "1.0.0"
b = "2.0.0"' >project/mise.toml
echo '[tools]
dummy = ["{{vars.a}}", "{{vars.b}}"]' >project/child/mise.toml
assert "mise -C project/child install"
assert "mise install dummy@3.0.0"

# Both computed versions (1.0.0 and 2.0.0) are kept; only 3.0.0 is prunable.
assert "mise -C elsewhere ls --prunable --json >prunable.json"
assert "jq -e '[.dummy[].version] == [\"3.0.0\"]' prunable.json"
SCENARIO
