# Shared helper for the shell verifiers. Not matched by the verify*.sh glob, so
# it is copied alongside the tests but never run as a graded test itself.
#
# Each verifier describes one end-to-end scenario on stdin and calls
# run_scenario. We reuse the repository's own end-to-end launcher, which builds
# a throwaway HOME with its own data/state/config/cache directories, runs the
# body under a clean environment, and tears everything down afterward. The
# launcher wires up the "dummy" test backend but not the "tiny" one, so the body
# is prefixed with a line that links "tiny" in too (the data dir and repo root
# are both exported by the launcher at that point). The scenario body therefore
# starts from a pristine, isolated install and drives only the real mise CLI.

set -uo pipefail

# Locate the repository root (it holds e2e/run_test). During grading the working
# directory is the checked-out repo; fall back to the conventional mount path.
if [[ -f "$PWD/e2e/run_test" ]]; then
  HARNESS_ROOT="$PWD"
elif [[ -n "${REPO_NAME:-}" && -f "/repo/$REPO_NAME/e2e/run_test" ]]; then
  HARNESS_ROOT="/repo/$REPO_NAME"
elif [[ -f "/repo/mise/e2e/run_test" ]]; then
  HARNESS_ROOT="/repo/mise"
else
  echo "verifier harness: could not locate e2e/run_test from $PWD" >&2
  exit 2
fi

# Read a scenario body from stdin, run it inside one isolated environment, and
# propagate its pass/fail exit code as this verifier's result.
run_scenario() {
  local body script rc
  body="$(cat)"
  script="$(mktemp "${TMPDIR:-/tmp}/scenario.XXXXXX")"
  {
    printf '#!/usr/bin/env bash\n'
    # Close the one setup gap versus the stock launcher: make the second test
    # backend available in the isolated install before the body runs.
    printf 'ln -sf "$ROOT/test/data/plugins/tiny" "$MISE_DATA_DIR/plugins/tiny"\n'
    printf '%s\n' "$body"
  } >"$script"

  bash "$HARNESS_ROOT/e2e/run_test" "$script"
  rc=$?
  rm -f "$script"
  return "$rc"
}
