# A child config that overrides one of a parent's computed tools supplies that
# tool only where the child applies. Deleting the child ends that directory's
# recorded context, so the child's version is no longer kept on the child's behalf
# — but the parent's own computed tool keeps being honored.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project/child elsewhere
echo '[vars]
d = "1.0.0"
t = "2.0.0"
[tools]
dummy = "{{vars.d}}"
tiny = "{{vars.t}}"' >project/mise.toml
echo '[tools]
tiny = "3.0.0"' >project/child/mise.toml
assert "mise -C project install"
assert "mise -C project/child install"
assert "mise install dummy@3.0.0"

# The child overrides tiny to a literal 3.0.0, so in the child tiny is not the
# parent's computed tool; from a third dir only the unrelated dummy 3.0.0 is
# prunable and tiny is not reported at all.
assert "mise -C elsewhere ls --prunable --json >prunable.json"
assert "jq -e '[.dummy[].version] == [\"3.0.0\"] and (has(\"tiny\") | not)' prunable.json"

# Deleting the child retires its context; now the parent's computed tiny (2.0.0)
# governs and the unused tiny 3.0.0 becomes prunable.
rm project/child/mise.toml
assert "mise -C elsewhere ls --prunable --json >prunable.json"
assert "jq -e '[.dummy[].version] == [\"3.0.0\"] and [.tiny[].version] == [\"3.0.0\"]' prunable.json"
SCENARIO
