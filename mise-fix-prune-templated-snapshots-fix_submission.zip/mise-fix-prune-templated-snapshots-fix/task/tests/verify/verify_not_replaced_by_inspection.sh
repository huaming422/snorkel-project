# Only a command that genuinely uses a project's tools may update its recorded
# result. Inspecting the project (prune, ls --prunable) or resolving only part of
# it (an argument that replaces the computed tool) runs from the ambient
# environment and must not overwrite the complete result the project recorded; a
# real prune from inside the project still honors that record. A later genuine
# resolve does update it.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project elsewhere
echo '[tools]
dummy = "{{env.PRUNE_VERSION}}"' >project/mise.toml
assert "PRUNE_VERSION=1.0.0 mise -C project install"
assert "mise install dummy@3.0.0"

# Inspecting from inside the project with a different ambient value must not
# replace the recorded 1.0.0: only 3.0.0 is prunable.
assert "PRUNE_VERSION=2.0.0 mise -C project ls --prunable --json >prunable.json"
assert "jq -e '[.dummy[].version] == [\"3.0.0\"]' prunable.json"
assert "PRUNE_VERSION=2.0.0 mise -C project prune --dry-run"

# An argument replacing the computed tool resolves less than the whole config and
# cannot vouch for it.
assert "PRUNE_VERSION=2.0.0 mise -C project exec dummy@3.0.0 -- true"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
assert "jq -e '[.dummy[].version] == [\"3.0.0\"]' prunable.json"

# A real prune from inside the project (which also rebuilds shims afterwards)
# keeps the recorded version and still does not replace the record: afterwards
# the in-use 1.0.0 survives on disk and nothing dummy is reported prunable.
assert "PRUNE_VERSION=2.0.0 mise -C project prune --yes"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
assert "jq -e 'has(\"dummy\") | not' prunable.json"
assert "ls $MISE_DATA_DIR/installs/dummy/1.0.0 >/dev/null"
SCENARIO
