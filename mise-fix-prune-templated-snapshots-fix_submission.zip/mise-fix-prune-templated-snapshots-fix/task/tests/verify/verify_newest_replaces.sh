# One recorded result per (config, context). Re-using a project with different
# inputs replaces the earlier result for that context, so a version it stopped
# using becomes prunable. A different MISE_ENV is a separate context with its own
# result, so its version is kept independently.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project elsewhere
echo '[tools]
dummy = "{{env.PRUNE_VERSION}}"' >project/mise.toml
assert "PRUNE_VERSION=1.0.0 mise -C project install"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
assert "jq -e 'has(\"dummy\") | not' prunable.json"

# Same context, new input: the new result replaces the old, so 1.0.0 is prunable.
assert "PRUNE_VERSION=2.0.0 mise -C project install"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
assert "jq -e '[.dummy[].version] == [\"1.0.0\"]' prunable.json"

# A different environment is a different context with its own result: 1.0.0 is
# kept again because it is in use under MISE_ENV=prod.
assert "MISE_ENV=prod PRUNE_VERSION=1.0.0 mise -C project install"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
assert "jq -e 'has(\"dummy\") | not' prunable.json"
SCENARIO
