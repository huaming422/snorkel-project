# A config whose bytes change between being loaded and being recorded (here a
# template that appends to its own file while it evaluates) records nothing: the
# resolved requests came from text the file no longer has. Prune then keeps every
# installation of its computed tools. A config that does not mutate itself records
# normally.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project elsewhere
cat >project/mise.toml <<'EOT'
[vars]
v = "1.0.0"
touch = "{{ exec(command='echo \"# edited\" >> ' ~ config_root ~ '/mise.toml') }}"

[tools]
dummy = "{{vars.v}}"
EOT
assert "mise -C project install"
assert "mise install dummy@3.0.0"

# The self-mutating config recorded nothing, so every dummy is kept.
assert "mise -C elsewhere ls --prunable --json >prunable.json"
assert "jq -e 'has(\"dummy\") | not' prunable.json"

# A config that does not mutate itself records normally. Use a separate tool
# (tiny) so its recording is observable independently of the mutating project's
# keep-every-dummy: tiny's in-use version is kept and the unrelated one is prunable.
mkdir -p stable
cat >stable/mise.toml <<'EOT'
[vars]
v = "2.0.0"

[tools]
tiny = "{{vars.v}}"
EOT
assert "mise -C stable install"
assert "mise install tiny@3.0.0"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
assert "jq -e '[.tiny[].version] == [\"3.0.0\"]' prunable.json"
SCENARIO
