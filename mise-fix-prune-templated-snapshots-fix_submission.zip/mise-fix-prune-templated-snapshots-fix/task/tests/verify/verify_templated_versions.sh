# A project whose tool version is computed (from vars/env) under the identity
# install layout: a prune run from an unrelated directory must keep the version
# the project actually uses, report an unused version as prunable, treat a parent
# edit as "unknown, keep everything" until the project is used again, and let a
# fresh use retire the version the project stopped using.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project/child elsewhere
echo '[vars]
tool_version = "1.0.0"' >project/mise.toml
echo '[tools]
dummy = "{{vars.tool_version}}"' >project/child/mise.toml
assert "mise -C project/child install"
assert "mise install dummy@3.0.0"

for directory in project/child elsewhere; do
  assert "mise -C '$directory' ls --prunable --json >prunable.json"
  assert "jq -e '[.dummy[].version] == [\"3.0.0\"]' prunable.json"
  assert_contains "mise -C '$directory' prune --dry-run 2>&1" "dummy@3.0.0"
  assert_not_contains "mise -C '$directory' prune --dry-run 2>&1" "dummy@1.0.0"
done

# Editing the parent makes what was recorded no longer trustworthy: until the
# project is used again, every dummy is kept rather than trusting the old value.
echo '[vars]
tool_version = "2.0.0"' >project/mise.toml
assert "mise -C elsewhere ls --prunable --json >prunable.json"
assert "jq -e 'has(\"dummy\") | not' prunable.json"

# Using the project again replaces the old record outright, so the version it no
# longer uses becomes prunable.
assert "mise -C project/child install"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
assert "jq -e '[.dummy[].version] | sort == [\"1.0.0\", \"3.0.0\"]' prunable.json"
SCENARIO
