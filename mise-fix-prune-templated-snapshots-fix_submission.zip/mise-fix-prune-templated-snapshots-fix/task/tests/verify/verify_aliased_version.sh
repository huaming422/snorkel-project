# A project version alias maps a requested spec to a concrete version when the
# project resolves its computed tool. Prune rebuilds the request without the
# project's aliases, so retention must have recorded both the requested spec and
# the version it settled on; otherwise prune could not keep the installed version.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project elsewhere
cat >project/mise.toml <<'EOT'
[tool_alias.dummy.versions]
project-release = "1.0.0"

[tools]
dummy = "{{env.PRUNE_VERSION}}"
EOT
assert "PRUNE_VERSION=project-release mise -C project install"
assert "mise install dummy@3.0.0"
assert "ls $MISE_DATA_DIR/installs/dummy/1.0.0"

# From a third directory the alias is not in scope, yet the settled 1.0.0 is kept
# and only the unrelated 3.0.0 is prunable.
assert "mise -C elsewhere ls --prunable --json >prunable.json"
assert "jq -e '[.dummy[].version] == [\"3.0.0\"]' prunable.json"
SCENARIO
