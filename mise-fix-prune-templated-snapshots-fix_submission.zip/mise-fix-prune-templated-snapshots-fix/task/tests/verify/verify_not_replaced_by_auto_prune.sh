# The deferred cleanup that runs at the start of nearly every command builds the
# current directory's toolset. That is not a use of the project, so it must not
# record a result from whatever environment the command happens to run in, nor
# stand in for the command's own resolution. A command that does genuinely resolve
# the project's tools still records.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project other elsewhere
echo '[tools]
dummy = "{{env.PRUNE_VERSION}}"' >project/mise.toml
assert "PRUNE_VERSION=1.0.0 mise -C project install"
assert "mise install dummy@3.0.0"

# Arrange a deferred removal that is due, so the next command triggers cleanup.
echo '[tools]
tiny = "1"' >other/mise.toml
assert "mise -C other install tiny@1.0.0"
assert "mise -C other upgrade tiny"
jq '.entries[].remove_after = 0' "$MISE_STATE_DIR/tool-purgatory.json" >purgatory.json
mv purgatory.json "$MISE_STATE_DIR/tool-purgatory.json"

# `version` resolves no toolset itself; only the cleanup does. The cleanup must
# not record the project from this command's ambient PRUNE_VERSION=2.0.0.
assert "PRUNE_VERSION=2.0.0 mise -C project version"
assert_fail "test -f '$MISE_STATE_DIR/tool-purgatory.json'"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
assert "jq -e '[.dummy[].version] == [\"3.0.0\"]' prunable.json"

# When the command itself resolves the project's tools, that is a genuine use and
# it records: now the 2.0.0 render is kept and the old 1.0.0 becomes prunable.
assert "mise -C other uninstall tiny --all"
assert "mise -C other install tiny@1.0.0"
assert "mise -C other upgrade tiny"
jq '.entries[].remove_after = 0' "$MISE_STATE_DIR/tool-purgatory.json" >purgatory.json
mv purgatory.json "$MISE_STATE_DIR/tool-purgatory.json"
assert "PRUNE_VERSION=2.0.0 mise -C project ls >/dev/null"
assert_fail "test -f '$MISE_STATE_DIR/tool-purgatory.json'"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
assert "jq -e '[.dummy[].version] | sort == [\"1.0.0\", \"3.0.0\"]' prunable.json"
SCENARIO
