# One context going stale must not be masked by another that is current. When a
# loaded config of a context changed, every installation of that config's computed
# tools is kept — the stale context's versions might still be needed — until the
# project is used again.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project/child elsewhere
echo '[vars]
v = "1.0.0"
[tools]
dummy = "{{vars.v}}"' >project/mise.toml
echo '[vars]
v = "2.0.0"' >project/child/mise.toml
assert "mise -C project install"
assert "mise -C project/child install"
assert "mise install dummy@3.0.0"

# Both contexts recorded; only the unrelated 3.0.0 is prunable.
assert "mise -C elsewhere ls --prunable --json >prunable.json"
assert "jq -e '[.dummy[].version] == [\"3.0.0\"]' prunable.json"

# Touch a config of one context: it is now stale, so keep every dummy.
echo '# touched' >>project/child/mise.toml
assert "mise -C elsewhere ls --prunable --json >prunable.json"
assert "jq -e 'has(\"dummy\") | not' prunable.json"

# Using the project again refreshes it; the unrelated 3.0.0 is prunable once more.
assert "mise -C project/child install"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
assert "jq -e '[.dummy[].version] == [\"3.0.0\"]' prunable.json"
SCENARIO
