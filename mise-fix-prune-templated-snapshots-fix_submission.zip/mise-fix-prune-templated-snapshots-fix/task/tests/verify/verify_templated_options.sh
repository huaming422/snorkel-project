# A template in a tool's options makes the tool computed even when its version is
# a literal, so prune must not render it from the prune directory. Because such a
# tool carries backend options, it is not recorded, and prune keeps every
# installation of it rather than deleting one.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project/child elsewhere
echo '[vars]
o = "x"' >project/mise.toml
echo '[tools]
tiny = { version = "2.0.0", note = "{{vars.o}}" }' >project/child/mise.toml
assert "mise -C project/child install"
assert "mise install tiny@3.0.0"

# Every tiny is kept (the tool has options), so nothing tiny is prunable.
assert "mise -C elsewhere ls --prunable --json >prunable.json"
assert "jq -e 'has(\"tiny\") | not' prunable.json"
SCENARIO
