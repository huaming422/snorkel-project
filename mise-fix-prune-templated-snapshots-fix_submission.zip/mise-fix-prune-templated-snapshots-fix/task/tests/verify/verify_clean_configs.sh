# `mise prune --configs` removes recorded resolutions for configs that no longer
# exist, and for contexts that loaded a config file that is now gone, while
# leaving other configs' records intact. This distinction has no ls --prunable
# delta, so the only observable is the on-disk record: each project is given a
# distinctive rendered version that acts as a marker, and the record is searched
# by content.
#
# The search looks only where the fix keeps its resolution record — a sibling of
# the state directory, or alongside the catalog under installs/.mise — and never
# the tool payloads, the compatibility links, or the pre-existing identity
# catalog (identities / selections / names / ambiguous / locks), all of which
# predate the fix and legitimately carry rendered versions. This tolerates any
# record shape (per-config files, a single index, or a sibling state directory)
# and fails on an unfixed mise, which keeps no such record at all.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p gone keep/child elsewhere

# One distinctive rendered version per (config, context) under test. `keep/child`
# loads both keep/child/mise.toml and keep/mise.toml, and overrides the version.
echo '[tools]
dummy = "{{env.MARK}}"' >gone/mise.toml
echo '[tools]
dummy = "{{env.MARK}}"' >keep/mise.toml
echo '[tools]
dummy = "{{env.MARK}}"' >keep/child/mise.toml

assert "MARK=6.1.0 mise -C gone install"
assert "MARK=6.2.0 mise -C keep install"
assert "MARK=6.3.0 mise -C keep/child install"

# Search only the fix's resolution record, by content.
record_grep() {
  {
    find "$MISE_STATE_DIR" -type f -print0 2>/dev/null
    find "$MISE_DATA_DIR/installs/.mise" -type f \
      -not -path '*/identities/*' -not -path '*/selections/*' \
      -not -path '*/names/*' -not -path '*/ambiguous/*' \
      -not -path '*/locks/*' -print0 2>/dev/null
  } | xargs -0r grep -IlF "$1" 2>/dev/null || true
}
export -f record_grep

# All three markers are recorded to begin with.
assert_not_empty "record_grep 6.1.0"
assert_not_empty "record_grep 6.2.0"
assert_not_empty "record_grep 6.3.0"

# Remove the gone config entirely, and the child config file that the keep/child
# context loaded.
rm -r gone
rm keep/child/mise.toml

assert "mise -C elsewhere prune --configs"

# The gone config's record and the removed-child context's record are cleaned up;
# the surviving keep config's record is left intact.
assert_empty "record_grep 6.1.0"
assert_empty "record_grep 6.3.0"
assert_not_empty "record_grep 6.2.0"
SCENARIO
