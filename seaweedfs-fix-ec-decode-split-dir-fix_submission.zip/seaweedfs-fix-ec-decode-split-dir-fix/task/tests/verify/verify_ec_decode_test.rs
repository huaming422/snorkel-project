//! Behavioural verifier for decoding an erasure-coded volume back to a
//! normal volume on a volume server that keeps data and index files on
//! separate disks.
//!
//! The whole verifier drives two PRE-EXISTING, stable public interfaces of
//! the `seaweed_volume` crate — it never names or imports any symbol the fix
//! introduces, so it accepts any internal helper layout:
//!
//!   * `VolumeGrpcService` (public struct, public `state` field) implementing
//!     the generated `VolumeServer` gRPC trait. The decode entry point is
//!     `volume_ec_shards_to_volume`; shards are produced with
//!     `volume_ec_shards_generate`. Both signatures are unchanged by the fix.
//!   * The public `Store` API (`add_location` with separate data/index dirs,
//!     `add_volume`, `find_volume_mut`, `mount_ec_shard`, `unmount_ec_shards`,
//!     `mount_volume`, `read_volume_needle`, `write_volume_needle`) plus the
//!     `Volume`/`EcVolume` accessors used to build fixtures and read results.
//!
//! Each fixture builds a real split-disk store in a temp directory, writes a
//! few needles, encodes them, deletes the source data/index files (leaving
//! only shards + sealed index + deletion journal, as a decode target has),
//! and places the sealed index/journal where the shard-copy step would. The
//! assertions observe only decode behaviour: the call's result, the published
//! files, and what the re-mounted decoded volume reads back and accepts.

use std::sync::{Arc, RwLock};

use tempfile::TempDir;
use tonic::Request;

use seaweed_volume::config::{MinFreeSpace, ReadMode};
use seaweed_volume::pb::volume_server_pb;
use seaweed_volume::pb::volume_server_pb::volume_server_server::VolumeServer;
use seaweed_volume::security::{Guard, SigningKey};
use seaweed_volume::server::grpc_server::VolumeGrpcService;
use seaweed_volume::server::volume_server::{RuntimeMetricsConfig, VolumeServerState};
use seaweed_volume::storage::needle::needle::Needle;
use seaweed_volume::storage::needle_map::NeedleMapKind;
use seaweed_volume::storage::store::Store;
use seaweed_volume::storage::types::{Cookie, DiskType, NeedleId, VolumeId, NEEDLE_ID_SIZE};
use seaweed_volume::storage::volume::VolumeSpec;

const VID: VolumeId = VolumeId(1);
const SHARD_COUNT: u8 = 14;

/// The body stored for needle `id`, used to build fixtures and to check that a
/// live needle read back from the decoded volume is byte-for-byte intact.
fn needle_body(id: u64) -> Vec<u8> {
    format!("split idx decode needle {id}").into_bytes()
}

/// Wrap a `Store` in a minimal server state built entirely from the public
/// constructor surface. The guard is created with no whitelist and no signing
/// key, so write security is inactive and in-process admin calls are allowed
/// without peer info — this mirrors the public `http_integration` test setup.
fn state_from_store(store: Store) -> Arc<VolumeServerState> {
    let guard = Guard::new(&[], SigningKey(vec![]), 0, SigningKey(vec![]), 0);
    Arc::new(VolumeServerState {
        store: RwLock::new(store),
        guard: RwLock::new(guard),
        is_stopping: RwLock::new(false),
        maintenance: std::sync::atomic::AtomicBool::new(false),
        state_version: std::sync::atomic::AtomicU32::new(0),
        concurrent_upload_limit: 0,
        concurrent_download_limit: 0,
        inflight_upload_data_timeout: std::time::Duration::from_secs(60),
        inflight_download_data_timeout: std::time::Duration::from_secs(60),
        inflight_upload_bytes: std::sync::atomic::AtomicI64::new(0),
        inflight_download_bytes: std::sync::atomic::AtomicI64::new(0),
        upload_notify: tokio::sync::Notify::new(),
        download_notify: tokio::sync::Notify::new(),
        data_center: String::new(),
        rack: String::new(),
        file_size_limit_bytes: 0,
        maintenance_byte_per_second: 0,
        is_heartbeating: std::sync::atomic::AtomicBool::new(true),
        has_master: false,
        pre_stop_seconds: 0,
        volume_state_notify: tokio::sync::Notify::new(),
        write_queue: std::sync::OnceLock::new(),
        read_mode: ReadMode::Local,
        allow_untrusted_remote_endpoints: false,
        master_url: String::new(),
        master_urls: Vec::new(),
        seed_master_set: std::collections::HashSet::new(),
        current_master_url: tokio::sync::RwLock::new(String::new()),
        self_url: String::new(),
        http_client: reqwest::Client::new(),
        outgoing_http_scheme: "http".to_string(),
        outgoing_grpc_tls: None,
        metrics_runtime: std::sync::RwLock::new(RuntimeMetricsConfig::default()),
        metrics_notify: tokio::sync::Notify::new(),
        fix_jpg_orientation: false,
        has_slow_read: false,
        read_buffer_size_bytes: 1024 * 1024,
        security_file: String::new(),
        cli_white_list: vec![],
        state_file_path: String::new(),
    })
}

/// Build a split-disk decode target.
///
/// Writes needles 1..=3 to a volume on a store whose data dir and index dir
/// differ, encodes them, then removes the source data/index files so only the
/// shards and sealed index/journal remain. The sealed index is placed in the
/// index dir (where the copy step leaves it) unless `sealed_index_beside_data`
/// keeps it next to the shards. `journal` ids are written as a deletion
/// journal into the index dir, where the copy step appends collected journals.
///
/// Returns the service, the temp dir (kept alive by the caller), and the data
/// and index dir paths.
async fn make_split_decode_target(
    journal: &[u64],
    sealed_index_beside_data: bool,
) -> (VolumeGrpcService, TempDir, String, String) {
    let tmp = TempDir::new().unwrap();
    let data = tmp.path().join("data").to_str().unwrap().to_string();
    let idx = tmp.path().join("idx").to_str().unwrap().to_string();
    std::fs::create_dir_all(&data).unwrap();
    std::fs::create_dir_all(&idx).unwrap();

    let mut store = Store::new(NeedleMapKind::InMemory);
    store
        .add_location(
            &data,
            &idx,
            10,
            DiskType::HardDrive,
            MinFreeSpace::Percent(0.0),
            Vec::new(),
        )
        .unwrap();
    store
        .add_volume(VID, DiskType::HardDrive, &VolumeSpec::default())
        .unwrap();

    {
        let (_, volume) = store.find_volume_mut(VID).unwrap();
        for id in 1..=3u64 {
            let body = needle_body(id);
            let mut needle = Needle {
                id: NeedleId(id),
                cookie: Cookie(id as u32),
                data_size: body.len() as u32,
                data: body,
                ..Needle::default()
            };
            volume.write_needle(&mut needle, true, false).unwrap();
        }
        volume.sync_to_disk().unwrap();
    }

    let service = VolumeGrpcService {
        state: state_from_store(store),
    };
    service
        .volume_ec_shards_generate(Request::new(
            volume_server_pb::VolumeEcShardsGenerateRequest {
                volume_id: VID.0,
                collection: String::new(),
            },
        ))
        .await
        .unwrap();

    // Turn the encoded volume into a pure decode target: drop the source
    // data/index files so only shards + sealed index/journal remain, and put
    // the sealed index and the deletion journal where the copy step leaves
    // them on a split layout.
    let mut store = service.state.store.write().unwrap();
    store.unmount_volume(VID).unwrap();
    std::fs::remove_file(format!("{data}/1.dat")).unwrap();
    std::fs::remove_file(format!("{idx}/1.idx")).unwrap();
    let sealed_index_dir = if sealed_index_beside_data {
        data.clone()
    } else {
        std::fs::rename(format!("{data}/1.ecx"), format!("{idx}/1.ecx")).unwrap();
        idx.clone()
    };
    let mut journal_bytes = Vec::new();
    for id in journal {
        let mut buf = [0u8; NEEDLE_ID_SIZE];
        NeedleId(*id).to_bytes(&mut buf);
        journal_bytes.extend_from_slice(&buf);
    }
    std::fs::write(format!("{idx}/1.ecj"), journal_bytes).unwrap();

    for shard_id in 0..SHARD_COUNT {
        store.mount_ec_shard(VID, "", shard_id, "").unwrap();
    }
    assert_eq!(
        store.find_ec_volume(VID).unwrap().ecx_actual_dir(),
        sealed_index_dir,
        "fixture precondition: the mounted volume reads its sealed index from {sealed_index_dir}"
    );
    drop(store);

    (service, tmp, data, idx)
}

/// Build a decode request for volume 1.
fn decode_request() -> Request<volume_server_pb::VolumeEcShardsToVolumeRequest> {
    Request::new(volume_server_pb::VolumeEcShardsToVolumeRequest {
        volume_id: VID.0,
        collection: String::new(),
        ..Default::default()
    })
}

/// Mount the decoded normal volume and assert its observable contents: that it
/// is NOT forced read-only (no index row may point past the end of the decoded
/// data file), that exactly the expected number of needles are live, that
/// every `live` needle reads back intact, that every `deleted` needle reads as
/// absent, and that the volume accepts a fresh write/read afterwards.
///
/// The live-needle count is checked as `file_count - deleted_count` rather than
/// pinning the raw (file_count, deleted_count) pair: whether an interior
/// deleted needle is kept as a tombstoned row (counted as garbage) or dropped
/// outright is an internal accounting choice the contract does not fix, and
/// both leave the same set of needles live. A tail-deleted needle that was cut
/// from the data is still proven gone by the data-file-size and read-absent
/// assertions at each call site.
fn assert_decoded_volume(service: &VolumeGrpcService, live: &[u64], deleted: &[u64]) {
    let mut store = service.state.store.write().unwrap();
    let all_shards: Vec<u8> = (0..SHARD_COUNT).collect();
    store.unmount_ec_shards(VID, &all_shards);
    store.mount_volume(VID, "", DiskType::HardDrive).unwrap();

    let (_, v) = store.find_volume(VID).unwrap();
    assert_eq!(
        v.file_count() - v.deleted_count(),
        live.len() as i64,
        "decoded volume should report exactly {} live needle(s)",
        live.len()
    );
    assert!(
        !v.is_no_write_or_delete(),
        "decoded volume must stay writable: no index row may point past the end of the data file"
    );

    for &id in live {
        let mut n = Needle {
            id: NeedleId(id),
            ..Needle::default()
        };
        store
            .read_volume_needle(VID, &mut n)
            .unwrap_or_else(|e| panic!("live needle {id} should read back: {e:?}"));
        assert_eq!(n.data, needle_body(id), "live needle {id} body intact");
    }
    for &id in deleted {
        let mut n = Needle {
            id: NeedleId(id),
            ..Needle::default()
        };
        assert!(
            store.read_volume_needle(VID, &mut n).is_err(),
            "needle {id} was deleted after encoding and must stay deleted"
        );
    }

    let body = b"written after decode".to_vec();
    let mut n = Needle {
        id: NeedleId(4),
        cookie: Cookie(4),
        data_size: body.len() as u32,
        data: body.clone(),
        ..Needle::default()
    };
    store
        .write_volume_needle(VID, &mut n, true)
        .expect("decoded volume should accept a fresh write");
    let mut n = Needle {
        id: NeedleId(4),
        ..Needle::default()
    };
    store.read_volume_needle(VID, &mut n).unwrap();
    assert_eq!(n.data, body, "freshly written needle reads back");
}

/// Split layout, sealed index on the index disk, no deletions: the decode
/// succeeds and the re-mounted normal volume reads back every live needle and
/// stays writable.
///
/// Before the fix this fails with a file-not-found error while building the
/// regular index, after the decoded data file has already been published.
///
/// The test observes only that decode returns Ok and that the re-mounted
/// volume behaves correctly — it does NOT assert which directory the rebuilt
/// regular index lands in. The mount resolves the index from either the data
/// or the index directory, so pinning a location would reject an equally valid
/// fix that publishes it on the index disk.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn split_dir_decode_succeeds() {
    let (service, _tmp, _data, _idx) = make_split_decode_target(&[], false).await;

    service
        .volume_ec_shards_to_volume(decode_request())
        .await
        .expect("decode on a split data/index layout should succeed");

    assert_decoded_volume(&service, &[1, 2, 3], &[]);
}

/// A volume whose every needle was deleted after encoding is reported as
/// having no live entries (so the caller purges the shards) and leaves no
/// decoded data file behind, instead of decoding as a full volume.
///
/// Before the fix the deletion journal is never applied, so the volume decodes
/// as if still full.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn all_deleted_reports_empty() {
    let (service, _tmp, data, _idx) = make_split_decode_target(&[1, 2, 3], false).await;

    let err = service
        .volume_ec_shards_to_volume(decode_request())
        .await
        .expect_err("a fully-deleted volume must not decode as a populated volume");
    // The outcome is the pre-existing no-live-entries signal (the handler
    // already carries this exact wording on its empty-volume branch; base.md
    // states the volume should "come back reporting no live entries"). Assert
    // the behaviour — an error carrying that signal — not a specific gRPC
    // status code the contract never names.
    assert!(
        err.message().contains("no live entries"),
        "a fully-deleted volume should report no live entries, got {err:?}"
    );
    assert!(
        !std::path::Path::new(&format!("{data}/1.dat")).exists(),
        "no decoded data file may be left behind when the volume has no live entries"
    );
}

/// Needles deleted after encoding do not reappear: both an interior deleted
/// needle and a tail-deleted needle read as absent from the decoded volume,
/// the live needle still reads back, and the mount is NOT forced read-only
/// (the known failure mode where a tail needle's index row points past the end
/// of the decoded data). The volume stays writable.
///
/// Before the fix the tail-deleted needle is copied into the decoded data and
/// reappears as live (or the mount is forced read-only).
///
/// The test does not assert the decoded data file's exact byte length: whether
/// a fix reclaims the deleted-tail bytes (cutting the data) or keeps them and
/// tombstones the row within end-of-file is an internal choice — both must
/// leave the needle unreadable and the volume writable, which is what we check.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn tail_deleted_not_resurrected() {
    // Needle 1 is interior; needle 3 is the tail. Both are journaled deleted.
    let (service, _tmp, _data, _idx) = make_split_decode_target(&[1, 3], false).await;

    service
        .volume_ec_shards_to_volume(decode_request())
        .await
        .expect("decode with tail/interior deletions should succeed");

    // Needle 2 is the only live needle; needles 1 and 3 were deleted.
    assert_decoded_volume(&service, &[2], &[1, 3]);
}

/// The sealed index can sit beside the shards while the collected deletion
/// journal lands in the index dir, so decode must honour deletions read from
/// the index-dir journal even then. A tail needle recorded there reads as
/// absent from the decoded volume; the other needles read back live.
///
/// Before the fix the index-dir journal is ignored, so the deleted tail needle
/// reappears.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn index_dir_journal_honored_with_sealed_index_beside_data() {
    let (service, _tmp, _data, _idx) = make_split_decode_target(&[3], true).await;

    service
        .volume_ec_shards_to_volume(decode_request())
        .await
        .expect("decode should succeed with the sealed index beside the shards");

    assert_decoded_volume(&service, &[1, 2], &[3]);
}
