## Task

hey, decoding an erasure-coded volume back into a normal one blows up on any
box where we keep the data and index files on separate disks. the `ec.decode`
dies partway through with a "No such file or directory" and leaves a
half-written decoded volume behind that someone has to go clean up by hand. on
single-disk boxes the exact same decode works fine.

two more things wrong with the same decode while you're in there: a volume where
we deleted every entry after encoding still decodes as if it were full (it
should come back reporting no live entries so we can purge the shards), and
individual needles we deleted after encoding show up alive again in the decoded
volume. can you dig in and sort all this out?
