## Task

Plan Detail gets plan checks that end FAILED and CANCELED wrong, and it shows in a few places.

On a project that doesn't enforce SQL review, a failed check gets the "Some checks were not successful" prompt when you press Ready for Review. Confirming with "Submit anyway" doesn't submit anything. A "Failed" toast says `ConnectError: [failed_precondition] Plan checks did not pass`, and the issue is still a draft. A project that does enforce SQL review refuses that submission too, and that part is right.

A canceled check, one somebody stopped before it finished, doesn't count at all. The Checks section says "No checks", the summary line leaves it out, and Ready for Review submits straight away with no prompt, then fails with the same toast. With SQL review enforced, the page doesn't list it under "Some task checks didn't pass." the way it lists a failed check, so the toast is the first sign of trouble.

Timed-out checks get counted twice. For a single one, the Checks section and the summary line both show 2 errors, and the checks drawer lists it twice, once as "Failed" and once as "Plan check run timed out".

Track these down and fix them.
