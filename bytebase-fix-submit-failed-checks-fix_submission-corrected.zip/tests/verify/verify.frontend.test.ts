// @vitest-environment node
import { create } from "@bufbuild/protobuf";
import { describe, expect, test } from "vitest";
import {
  getFilteredResultGroups,
  getPlanCheckSummary,
  getPlanCheckSummaryWithFallback,
} from "@/lib/plan/check";
import {
  type Plan,
  PlanCheckRun_ResultSchema,
  PlanCheckRun_Status,
  PlanCheckRunSchema,
} from "@/types/proto-es/v1/plan_service_pb";
import type { Project } from "@/types/proto-es/v1/project_service_pb";
import { Advice_Level } from "@/types/proto-es/v1/sql_service_pb";
import { getSubmitReviewAdvance } from "@/routes/project/plan-detail/components/lifecycle/advanceState";
import { buildChangesSummary } from "@/routes/project/plan-detail/utils/phaseSummary";

// The run shapes the server stores for a plan's single check run. A timed-out
// run is FAILED with one ERROR result, a run the executor gave up on is FAILED
// with only an error message, and a canceled run has no results at all.
const timedOutRun = () =>
  create(PlanCheckRunSchema, {
    name: "timed-out-run",
    results: [
      create(PlanCheckRun_ResultSchema, {
        content: "The plan check run was abandoned.",
        status: Advice_Level.ERROR,
        title: "Plan check run timed out",
      }),
    ],
    status: PlanCheckRun_Status.FAILED,
  });
const executorFailedRun = () =>
  create(PlanCheckRunSchema, {
    error: "plan not found",
    name: "executor-failed-run",
    status: PlanCheckRun_Status.FAILED,
  });
const canceledRun = (error = "") =>
  create(PlanCheckRunSchema, {
    error,
    name: "canceled-run",
    status: PlanCheckRun_Status.CANCELED,
  });

describe("check counts", () => {
  test("a timed-out check counts as one error", () => {
    expect(getPlanCheckSummary([timedOutRun()]).error).toBe(1);
    expect(
      getPlanCheckSummaryWithFallback([], { ERROR: 1, FAILED: 1 }).error
    ).toBe(1);
  });

  test("a check that failed without results counts as one error", () => {
    expect(getPlanCheckSummary([executorFailedRun()]).error).toBe(1);
    expect(getPlanCheckSummaryWithFallback([], { FAILED: 1 }).error).toBe(1);
  });

  test("a canceled check counts as one error", () => {
    expect(getPlanCheckSummary([canceledRun("context canceled")]).error).toBe(1);
    expect(getPlanCheckSummary([canceledRun()]).error).toBe(1);
    expect(getPlanCheckSummaryWithFallback([], { CANCELED: 1 }).error).toBe(1);
  });

  // A finished run checked against several databases reports one ERROR
  // result per failing statement, and each of them is its own error.
  test("every error result of a finished check still counts", () => {
    const done = create(PlanCheckRunSchema, {
      results: [
        create(PlanCheckRun_ResultSchema, { status: Advice_Level.ERROR }),
        create(PlanCheckRun_ResultSchema, { status: Advice_Level.ERROR }),
        create(PlanCheckRun_ResultSchema, { status: Advice_Level.WARNING }),
        create(PlanCheckRun_ResultSchema, { status: Advice_Level.SUCCESS }),
      ],
      status: PlanCheckRun_Status.DONE,
    });
    expect(getPlanCheckSummary([done])).toMatchObject({
      error: 2,
      success: 1,
      warning: 1,
    });
    expect(
      getPlanCheckSummaryWithFallback([], {
        DONE: 1,
        ERROR: 3,
        SUCCESS: 2,
        WARNING: 1,
      })
    ).toMatchObject({ error: 3, success: 2, warning: 1 });
  });
});

describe("checks drawer entries", () => {
  const groupsFor = (run: ReturnType<typeof timedOutRun>) =>
    getFilteredResultGroups({
      includeRunFailure: true,
      planCheckRuns: [run],
      runFailureContent: "Failed",
      runFailureTitle: "Failed",
    });

  test("a timed-out check is listed once", () => {
    const groups = groupsFor(timedOutRun());
    expect(groups).toHaveLength(1);
    expect(groups[0]?.results).toHaveLength(1);
    expect(groups[0]?.results[0]?.title).toBe("Plan check run timed out");
  });

  test("a check that failed without results is listed with its message", () => {
    const groups = groupsFor(executorFailedRun());
    expect(groups).toHaveLength(1);
    expect(groups[0]?.results[0]?.status).toBe(Advice_Level.ERROR);
    expect(groups[0]?.results[0]?.content).toBe("plan not found");
  });

  test("a canceled check is listed", () => {
    const withMessage = groupsFor(canceledRun("context canceled"));
    expect(withMessage).toHaveLength(1);
    expect(withMessage[0]?.results[0]?.status).toBe(Advice_Level.ERROR);
    expect(withMessage[0]?.results[0]?.content).toBe("context canceled");

    const bare = groupsFor(canceledRun());
    expect(bare).toHaveLength(1);
    expect(bare[0]?.results[0]?.status).toBe(Advice_Level.ERROR);
  });
});

describe("Plan Detail change summary", () => {
  const templates: Record<string, string> = {
    "common.and": "and",
    "plan.summary.n-changes": "{{n}} changes",
    "plan.summary.n-database-groups": "{{n}} database groups",
    "plan.summary.n-databases": "{{n}} databases",
    "plan.summary.n-error": "{{n}} error",
    "plan.summary.n-passed": "{{n}} passed",
    "plan.summary.n-warning": "{{n}} warning",
  };
  const t = (key: string, options?: Record<string, unknown>) =>
    Object.entries(options ?? {}).reduce(
      (text, [name, value]) => text.replaceAll(`{{${name}}}`, String(value)),
      templates[key] ?? key
    );
  const planWith = (planCheckRunStatusCount: Record<string, number>) =>
    ({
      planCheckRunStatusCount,
      specs: [
        {
          config: {
            case: "changeDatabaseConfig",
            value: { targets: ["instances/i1/databases/db1"] },
          },
        },
      ],
    }) as unknown as Plan;

  test("a timed-out check reads as one error", () => {
    const summary = buildChangesSummary(planWith({ ERROR: 1, FAILED: 1 }), t);
    expect(summary).toContain("1 error");
    expect(summary).not.toContain("2 error");
  });

  test("a canceled check reads as one error", () => {
    expect(buildChangesSummary(planWith({ CANCELED: 1 }), t)).toContain(
      "1 error"
    );
  });
});

describe("submitting a plan for review", () => {
  const t = (key: string) => key;
  const advanceFor = (
    planCheckRunStatusCount: Record<string, number>,
    enforceSqlReview: boolean
  ) =>
    getSubmitReviewAdvance({
      emptySpecCount: 0,
      isEditing: false,
      plan: {
        planCheckRunStatusCount,
        specs: [{ config: { case: "changeDatabaseConfig", value: {} } }],
      } as unknown as Plan,
      project: { enforceSqlReview, forceIssueLabels: false } as Project,
      selectedLabelCount: 1,
      t,
    });
  const override = {
    body: "issue.checks-warning-hint",
    headline: "plan.lifecycle.gate-checks-failed",
    verb: "plan.submit-review-anyway",
  };

  test("a canceled check gets the Submit anyway offer", () => {
    const advance = advanceFor({ CANCELED: 1 }, false);
    expect(advance.blockers.map((b) => b.id)).not.toContain("checks-failed");
    expect(advance.decision).toEqual(override);
  });

  test("a timed-out check gets the Submit anyway offer", () => {
    const advance = advanceFor({ ERROR: 1, FAILED: 1 }, false);
    expect(advance.blockers.map((b) => b.id)).not.toContain("checks-failed");
    expect(advance.decision).toEqual(override);
  });

  test("a canceled check is blocked before submit where SQL review is enforced", () => {
    const advance = advanceFor({ CANCELED: 1 }, true);
    expect(advance.blockers.map((b) => b.id)).toContain("checks-failed");
    expect(advance.decision).toBeUndefined();
  });

  test("a failed check is blocked before submit where SQL review is enforced", () => {
    const advance = advanceFor({ FAILED: 1 }, true);
    expect(advance.blockers.map((b) => b.id)).toContain("checks-failed");
    expect(advance.decision).toBeUndefined();
  });
});
