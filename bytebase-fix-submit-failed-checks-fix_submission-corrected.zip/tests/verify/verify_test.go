package review

import (
	"errors"
	"testing"

	storepb "github.com/bytebase/bytebase/backend/generated-go/store"
	"github.com/bytebase/bytebase/backend/store"
)

// Exercises the plan-check-run gate the submission workflow applies before an
// issue may leave draft. The gate is a pure function of the project setting, the
// plan's approval-input version, and the run's status/results, so the cases
// below construct those three values directly and touch no datastore.
//
// Each case names a run state and whether SQL review is enforced on the project,
// and asserts whether the gate admits the submission. A rejection must carry the
// failed-precondition code so the caller leaves the issue in draft.
func TestZZSubmitGatePlanCheckRunStates(t *testing.T) {
	const planVersion int64 = 7

	adviseError := []*storepb.PlanCheckRunResult_Result{
		{
			Status: storepb.Advice_ERROR,
			Type:   storepb.PlanCheckType_PLAN_CHECK_TYPE_STATEMENT_ADVISE,
		},
	}
	timeoutError := []*storepb.PlanCheckRunResult_Result{
		{Status: storepb.Advice_ERROR, Title: "Plan check run timed out"},
	}

	cases := []struct {
		name     string
		nilRun   bool
		status   store.PlanCheckRunStatus
		results  []*storepb.PlanCheckRunResult_Result
		enforce  bool
		stale    bool
		wantPass bool
	}{
		// A canceled or failed run on a project that doesn't enforce SQL review
		// is an incomplete signal the reader may acknowledge and submit past.
		{name: "canceled run accepted without enforcement", status: store.PlanCheckRunStatusCanceled, wantPass: true},
		{name: "failed executor accepted without enforcement", status: store.PlanCheckRunStatusFailed, wantPass: true},
		{name: "failed timeout accepted without enforcement", status: store.PlanCheckRunStatusFailed, results: timeoutError, wantPass: true},

		// The same incomplete run stays blocked while enforcement is on.
		{name: "canceled run blocked with enforcement", status: store.PlanCheckRunStatusCanceled, enforce: true},
		{name: "failed executor blocked with enforcement", status: store.PlanCheckRunStatusFailed, enforce: true},
		{name: "failed timeout blocked with enforcement", status: store.PlanCheckRunStatusFailed, results: timeoutError, enforce: true},

		// A completed run with a statement-advise error mirrors the same
		// enforcement policy: acknowledgeable off, blocked on.
		{name: "done advise error accepted without enforcement", status: store.PlanCheckRunStatusDone, results: adviseError, wantPass: true},
		{name: "done advise error blocked with enforcement", status: store.PlanCheckRunStatusDone, results: adviseError, enforce: true},

		// States that aren't a terminal verdict stay blocked regardless of
		// enforcement: a run that never happened, one whose inputs changed under
		// it, and ones still in flight.
		{name: "missing run blocked", nilRun: true},
		{name: "stale failed run blocked", status: store.PlanCheckRunStatusFailed, stale: true},
		{name: "stale failed run blocked with enforcement", status: store.PlanCheckRunStatusFailed, stale: true, enforce: true},
		{name: "available run blocked", status: store.PlanCheckRunStatusAvailable},
		{name: "running run blocked", status: store.PlanCheckRunStatusRunning},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			project := &store.ProjectMessage{
				Setting: &storepb.Project{EnforceSqlReview: tc.enforce},
			}
			plan := &store.PlanMessage{
				Config: &storepb.PlanConfig{ApprovalInputVersion: planVersion},
			}

			var run *store.PlanCheckRunMessage
			if !tc.nilRun {
				version := planVersion
				if tc.stale {
					version--
				}
				run = &store.PlanCheckRunMessage{
					Status: tc.status,
					Result: &storepb.PlanCheckRunResult{
						ApprovalInputVersion: version,
						Results:              tc.results,
					},
				}
			}

			err := validatePlanCheckRun(project, plan, run)

			if tc.wantPass {
				if err != nil {
					t.Fatalf("expected submission to be admitted, got %v", err)
				}
				return
			}

			if err == nil {
				t.Fatal("expected submission to be rejected, got nil")
			}
			var workflowErr *Error
			if !errors.As(err, &workflowErr) {
				t.Fatalf("expected a typed review error, got %T: %v", err, err)
			}
			if workflowErr.Code != ErrorFailedPrecondition {
				t.Fatalf("expected failed-precondition code, got %v", workflowErr.Code)
			}
		})
	}
}
