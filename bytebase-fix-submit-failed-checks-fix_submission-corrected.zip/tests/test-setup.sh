#!/usr/bin/env bash
#
# test-setup.sh: sourced by the test harness before the tests run.
#
# The image already holds the whole dependency closure of the pinned checkout. The
# Go module and build caches are warm under /opt/cache, and the frontend's
# node_modules plus the pnpm content-addressed store are in place. That leaves three
# jobs here. It makes the toolchains visible even if the harness scrubbed PATH. It
# puts every toolchain into offline mode, so a cache miss fails fast instead of
# hanging on a dead network. And it puts node_modules back from the store if a
# `git clean -fdx` in the working tree erased it.
#
# Sourced (not exec'd) so the environment exported here sticks for the test
# subprocesses.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/bytebase}"
export REPO_DIR
cd "$REPO_DIR"

# --- Go toolchain: visible + offline ---------------------------------------
# The image exports these, but a freshly-spawned shell that didn't inherit the
# image ENV still needs them. GOPROXY=off makes `go test` use only the warmed
# module cache; GOFLAGS=-mod=mod keeps builds off a (frozen) vendor dir.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac
export GOTOOLCHAIN=local
export GOFLAGS=-mod=mod
export GOPROXY=off
export CGO_ENABLED=1

# --- Node/pnpm toolchain: visible + offline --------------------------------
# node and pnpm were installed under /usr/local/bin; re-assert PATH defensively.
# `--offline` (store replay only) is set for the pnpm fallback below so a cache
# miss errors immediately rather than waiting on a network the container doesn't
# have.
case ":$PATH:" in
    *":/usr/local/bin:"*) ;;
    *) export PATH=/usr/local/bin:$PATH ;;
esac

# Defensive re-install: node_modules is baked at build time, but a working-tree
# scrub could remove it. Replay from the warm store, offline first; the test
# phase still reaches the gateway allowlist, so one retry without --offline is
# the only fallback. A failed install is logged and the run goes on, so the
# frontend tests report it instead of the sourcing shell exiting here.
if ! [ -x frontend/node_modules/.bin/vitest ]; then
    echo "test-setup.sh: frontend node_modules missing; replaying from the pnpm store." >&2
    if ! ( cd frontend && pnpm install --frozen-lockfile --ignore-scripts --offline ) \
        && ! ( cd frontend && pnpm install --frozen-lockfile --ignore-scripts ); then
        echo "test-setup.sh: pnpm install failed; the frontend tests will report it." >&2
    fi
fi

echo "test-setup.sh: ready. go=$(go version 2>/dev/null | awk '{print $3}') node=$(node --version 2>/dev/null) pnpm=$(pnpm --version 2>/dev/null)"
