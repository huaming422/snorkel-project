"""Behavioral checks for strict ("required") memory-read enforcement.

Every assertion keys on OBSERVABLE BEHAVIOR through pre-existing, stable
interfaces, never on the name of any newly introduced symbol or helper:

  * backend reads:  ``OpenVikingMemoryManager.get_context`` / ``.aget_context`` /
                    ``.search``, ``Mem0Manager.get_context``,
                    ``HonchoMemoryManager.get_context``
  * prompt assembly: ``deerflow.agents.lead_agent.prompt._get_memory_context``
  * injection path:  ``DynamicContextMiddleware.before_agent`` / ``.abefore_agent``

The distinguishing property of a "required-read" failure is defined
behaviorally, with zero dependence on its concrete class name or on any
particular policy-resolution helper:

    A required-read failure is an exception that (a) is a subclass of the
    backend-neutral ``MemoryManagerError`` boundary, AND (b) propagates out of
    ``_get_memory_context`` even when the call-site config carries NO legacy
    ``failure_policy.read == "fail_closed"`` flag -- whereas a plain
    ``MemoryManagerError`` is swallowed (returns "") under that same config.

That pair of facts is exactly what separates the new strict-read behavior
from the pre-existing legacy behavior, and it holds for any valid fix
regardless of how the fix names its error subtype, its helper methods, or how
it decomposes the policy resolver.
"""

from __future__ import annotations

import asyncio
import copy
import socket
import threading
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path
from types import SimpleNamespace
from typing import Any
from unittest import mock

import pytest

# ---------------------------------------------------------------------------
# Import isolation: mirror the backend test suite's conftest guard.
#
# Production code has a known import cycle through ``deerflow.subagents``:
#   subagents.__init__ -> .executor -> agents.thread_state -> agents.__init__
#     -> lead_agent.agent -> subagent_limit_middleware -> subagents.executor
# The suite breaks it by pre-registering a stand-in for the executor module
# BEFORE any code under test triggers the import. This file runs outside the
# suite's directory, so the same stand-in is installed here. ``setdefault``
# keeps a real module if one is already loaded.
# ---------------------------------------------------------------------------
import sys  # noqa: E402
from unittest.mock import MagicMock  # noqa: E402

_executor_stub = MagicMock()
_executor_stub.SubagentExecutor = MagicMock
_executor_stub.SubagentResult = MagicMock
_executor_stub.SubagentStatus = MagicMock
_executor_stub.MAX_CONCURRENT_SUBAGENTS = 3
_executor_stub.get_background_task_result = MagicMock()
sys.modules.setdefault("deerflow.subagents.executor", _executor_stub)

from deerflow.agents.lead_agent import prompt as prompt_module  # noqa: E402
from deerflow.agents.memory import (  # noqa: E402
    MemoryManager,
    MemoryManagerError,
    reset_memory_manager,
)
from deerflow.agents.memory.manager import _scan_backends  # noqa: E402
from deerflow.agents.memory.backends.honcho.client import HonchoRequestError  # noqa: E402
from deerflow.agents.memory.backends.honcho.honcho_manager import HonchoMemoryManager  # noqa: E402
from deerflow.agents.memory.backends.mem0.client import Mem0APIError  # noqa: E402
from deerflow.agents.memory.backends.mem0.mem0_manager import Mem0Manager  # noqa: E402
from deerflow.agents.memory.backends.openviking.openviking_manager import (  # noqa: E402
    OpenVikingMemoryManager,
)
from deerflow.agents.middlewares.dynamic_context_middleware import (  # noqa: E402
    DynamicContextMiddleware,
)
from deerflow.config.memory_config import MemoryConfig  # noqa: E402
from langchain_core.documents import Document  # noqa: E402
from langchain_core.messages import HumanMessage  # noqa: E402
from pydantic import PrivateAttr  # noqa: E402

pytestmark = pytest.mark.filterwarnings("ignore::DeprecationWarning")


@pytest.fixture(autouse=True)
def _isolate_memory_singleton():
    """Keep the process-global manager + backend registry cache clean per test."""
    reset_memory_manager()
    yield
    reset_memory_manager()


# ===========================================================================
# Shared behavioral predicate: "is this a required-read failure?"
#
# A required-read failure is a MemoryManagerError SUBTYPE that the prompt call
# site propagates even with an EMPTY call-site config (no legacy fail_closed).
# A plain MemoryManagerError under the same empty config is swallowed. This
# predicate is what makes every assertion name-independent.
# ===========================================================================
def _app_config(backend_config: dict[str, Any]) -> SimpleNamespace:
    return SimpleNamespace(
        memory=SimpleNamespace(
            enabled=True,
            injection_enabled=True,
            backend_config=backend_config,
        )
    )


def _exception_chain(exc: BaseException) -> list[BaseException]:
    """Walk the full exception chain following BOTH explicit (``raise ... from``)
    and implicit (re-raise inside ``except``) links. Keeping both means we never
    force a fix to use explicit ``from exc`` chaining: a valid fix that re-raises
    a wrapped error inside an ``except`` block (implicit ``__context__``) is
    treated identically to one that writes ``raise X from exc``."""
    seen: set[int] = set()
    out: list[BaseException] = []
    cur: BaseException | None = exc
    while cur is not None and id(cur) not in seen:
        seen.add(id(cur))
        out.append(cur)
        cur = cur.__cause__ or cur.__context__
    return out


def assert_underlying_cause(exc: BaseException, cause_type: type[BaseException] | None = None) -> None:
    """Assert the surfaced error preserves its origin in the exception chain,
    without pinning whether the fix chains explicitly (``__cause__``) or
    implicitly (``__context__``)."""
    chain = _exception_chain(exc)[1:]  # exclude the surfaced error itself
    if cause_type is None:
        assert chain, "the surfaced error must preserve an underlying cause in its chain"
    else:
        assert any(isinstance(c, cause_type) for c in chain), (
            f"expected a {cause_type.__name__} somewhere in the exception chain, got "
            f"{[type(c).__name__ for c in chain]}"
        )


def assert_propagates_as_required_read(error_type: type[BaseException], monkeypatch) -> None:
    """A required-read failure propagates through the prompt call site even
    with an EMPTY call-site config (no legacy ``fail_closed`` flag)."""
    assert issubclass(error_type, MemoryManagerError), (
        "a required-read failure must share the MemoryManagerError boundary"
    )

    def _boom(*_a, **_k):
        raise error_type("required read failed")

    manager = SimpleNamespace(get_context=_boom)
    monkeypatch.setattr("deerflow.agents.memory.get_memory_manager", lambda: manager)

    with pytest.raises(MemoryManagerError):
        prompt_module._get_memory_context(
            "research",
            app_config=_app_config({}),
            user_id="user-1",
        )


# ===========================================================================
# OpenViking test doubles (mirror the backend suite's own fakes so retrieval is
# observable and offline). The "unreachable URL" cases deliberately use the
# REAL langchain-openviking integration against a refused socket.
# ===========================================================================
_ACTOR_PEER: ContextVar[str | None] = ContextVar("verify_actor_peer", default=None)


@contextmanager
def _use_actor_peer(peer_id: str | None):
    token = _ACTOR_PEER.set(peer_id)
    try:
        yield
    finally:
        _ACTOR_PEER.reset(token)


class _CommitPolicy:
    def __init__(self, *, mode: str, pending_token_threshold: int = 8_000):
        self.mode = mode
        self.pending_token_threshold = pending_token_threshold


class _PartialWriteError(RuntimeError):
    def __init__(self, consumed: int, *, commit_pending: bool = False) -> None:
        super().__init__("partial")
        self.input_messages_consumed = consumed
        self.commit_pending = commit_pending


class _Client:
    supports_request_actor_peer = True

    def __init__(self, **kwargs: Any):
        self.kwargs = kwargs
        self.closed = False
        self.healthy = True

    def health(self) -> bool:
        return self.healthy

    def close(self) -> None:
        self.closed = True


class _Recorder:
    def __init__(self, *, commit_policy, url, api_key, timeout, extra_headers) -> None:
        self.commit_policy = commit_policy
        self.connection = {"url": url, "api_key": api_key, "timeout": timeout, "extra_headers": extra_headers}
        self._client = _Client(**self.connection)
        self.closed = False

    @property
    def client(self) -> _Client:
        return self._client

    def close(self) -> None:
        self.closed = True
        self._client.close()


class _Retriever:
    def __init__(self, *, client: _Client, **kwargs: Any):
        self.client = client
        self.kwargs = kwargs
        self.limit = kwargs["limit"]
        self.filter = None
        self.session_id = kwargs.get("session_id")
        self.target_uri = kwargs.get("target_uri", "")
        self.calls: list[dict[str, Any]] = []

    def __copy__(self) -> "_Retriever":
        copied = type(self)(client=self.client, **self.kwargs)
        copied.calls = self.calls
        copied.limit = self.limit
        copied.filter = copy.deepcopy(self.filter)
        copied.session_id = self.session_id
        copied.target_uri = copy.deepcopy(self.target_uri)
        return copied

    def invoke(self, query: str) -> list[Document]:
        self.calls.append({"query": query, "actor_peer": _ACTOR_PEER.get()})
        return [Document(page_content="Prefers concise answers.", metadata={})]


_OFFICIAL_INTEGRATION = {
    "OpenVikingCommitPolicy": _CommitPolicy,
    "OpenVikingPartialWriteError": _PartialWriteError,
    "OpenVikingRetriever": _Retriever,
    "OpenVikingSessionRecorder": _Recorder,
    "use_actor_peer": _use_actor_peer,
}


@pytest.fixture
def official_integration(monkeypatch: pytest.MonkeyPatch) -> None:
    import deerflow.agents.memory.backends.openviking.openviking_manager as module

    monkeypatch.setattr(module, "_load_official_integration", lambda: dict(_OFFICIAL_INTEGRATION))


def _ov_backend_config(tmp_path: Path, **overrides: Any) -> dict[str, Any]:
    config: dict[str, Any] = {
        "base_url": "http://openviking:1933",
        "storage_path": str(tmp_path),
        "owner_user_id": "alice",
        "startup_policy": "warn",
        "retrieval": {
            "top_k": 4,
            "max_injection_chars": 1_000,
            "injection_query": "profile preferences and prior decisions",
        },
    }
    config.update(overrides)
    return config


def _ov_manager(tmp_path: Path, monkeypatch: pytest.MonkeyPatch, **overrides: Any) -> OpenVikingMemoryManager:
    monkeypatch.setenv("OPENVIKING_API_KEY", "user-key")
    return OpenVikingMemoryManager.from_config(_ov_backend_config(tmp_path, **overrides))


@pytest.fixture
def unreachable_openviking_url():
    # A bound-but-not-listening socket yields a fast connection refusal.
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as reserved:
        reserved.bind(("127.0.0.1", 0))
        host, port = reserved.getsockname()
        yield f"http://{host}:{port}"


# ===========================================================================
# Criterion 1: OpenViking unreachable read -> strict raises required-read
# error with a cause; fail-open returns "".
# ===========================================================================
def test_openviking_unreachable_strict_read_surfaces_required_read_error(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, unreachable_openviking_url: str
) -> None:
    manager = _ov_manager(
        tmp_path, monkeypatch,
        base_url=unreachable_openviking_url, timeout_seconds=0.1,
        failure_policy={"read": "raise"},
    )
    with pytest.raises(MemoryManagerError) as exc_info:
        manager.get_context("alice", agent_name="research")
    assert_underlying_cause(exc_info.value)
    # Behavioral identity: this failure propagates through the prompt call site
    # even without a legacy fail_closed flag.
    assert_propagates_as_required_read(type(exc_info.value), monkeypatch)


@pytest.mark.asyncio
async def test_openviking_unreachable_async_read_honors_strict_policy(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, unreachable_openviking_url: str
) -> None:
    manager = _ov_manager(
        tmp_path, monkeypatch,
        base_url=unreachable_openviking_url, timeout_seconds=0.1,
        failure_policy={"read": "raise"},
    )
    with pytest.raises(MemoryManagerError) as exc_info:
        await manager.aget_context("alice", agent_name="research")
    assert_underlying_cause(exc_info.value)


def test_openviking_unreachable_fail_open_read_returns_empty(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, unreachable_openviking_url: str
) -> None:
    manager = _ov_manager(
        tmp_path, monkeypatch,
        base_url=unreachable_openviking_url, timeout_seconds=0.1,
        failure_policy={"read": "fail_open"},
    )
    assert manager.get_context("alice", agent_name="research") == ""


@pytest.mark.asyncio
async def test_openviking_unreachable_fail_open_async_read_returns_empty(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, unreachable_openviking_url: str
) -> None:
    manager = _ov_manager(
        tmp_path, monkeypatch,
        base_url=unreachable_openviking_url, timeout_seconds=0.1,
        failure_policy={"read": "fail_open"},
    )
    assert await manager.aget_context("alice", agent_name="research") == ""


# ===========================================================================
# Criterion 2: mem0 + honcho strict reads raise a required-read error on
# backend failure; fail-open swallows and returns the fallback ("").
# ===========================================================================
def _mem0_manager(backend_config: dict | None, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("MEM0_API_KEY", "test-key")
    mgr = Mem0Manager(backend_config=backend_config or {}, mode="middleware")

    class _FakeMem0Client:
        def __init__(self) -> None:
            self.error: Exception | None = None
            self.list_results: list[dict] = []

        def list_memories(self, **_kw):
            if self.error is not None:
                raise self.error
            return self.list_results

        def close(self):
            pass

    fake = _FakeMem0Client()
    mgr._client = fake
    return mgr, fake


def test_mem0_strict_read_surfaces_required_read_error(monkeypatch: pytest.MonkeyPatch) -> None:
    mgr, fake = _mem0_manager({"failure_policy": {"read": "fail_closed"}}, monkeypatch)
    fake.error = Mem0APIError("down")
    with pytest.raises(MemoryManagerError) as exc_info:
        mgr.get_context("u1")
    assert_propagates_as_required_read(type(exc_info.value), monkeypatch)


def test_mem0_fail_open_read_returns_empty(monkeypatch: pytest.MonkeyPatch) -> None:
    mgr, fake = _mem0_manager({"failure_policy": {"read": "fail_open"}}, monkeypatch)
    fake.error = Mem0APIError("down")
    assert mgr.get_context("u1") == ""


def _honcho_manager(monkeypatch: pytest.MonkeyPatch, **backend_config):
    mgr = HonchoMemoryManager.from_config({"base_url": "http://honcho.test", **backend_config})

    class _FakeHonchoClient:
        def __init__(self) -> None:
            self.raise_on: str | None = None
            self.representation_text = "likes concise answers"
            self.raise_exc_cls: type[BaseException] = HonchoRequestError

        def _maybe_raise(self, name):
            if self.raise_on == name:
                raise self.raise_exc_cls(name)

        def working_representation(self, ws, pid, *, max_conclusions=25):
            self._maybe_raise("representation")
            return self.representation_text

        def close(self):
            pass

    fake = _FakeHonchoClient()
    mgr._client = fake
    return mgr, fake


def test_honcho_strict_read_surfaces_required_read_error(monkeypatch: pytest.MonkeyPatch) -> None:
    mgr, fake = _honcho_manager(monkeypatch, failure_policy={"read": "fail_closed"})
    fake.raise_on = "representation"
    with pytest.raises(MemoryManagerError) as exc_info:
        mgr.get_context("u1")
    assert_propagates_as_required_read(type(exc_info.value), monkeypatch)


def test_honcho_fail_open_read_returns_empty(monkeypatch: pytest.MonkeyPatch) -> None:
    mgr, fake = _honcho_manager(monkeypatch, failure_policy={"read": "fail_open"})
    fake.raise_on = "representation"
    assert mgr.get_context("u1") == ""


# ===========================================================================
# Criterion 3: OpenViking scope mismatch (owner/user) under strict policy
# surfaces as a required-read error whose cause is the scope MemoryManagerError;
# the retriever is never invoked.
# ===========================================================================
def test_openviking_strict_scope_mismatch_required_read_error_without_retrieval(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, official_integration: None
) -> None:
    manager = _ov_manager(tmp_path, monkeypatch, failure_policy={"read": "raise"})
    monkeypatch.setattr("deerflow.agents.memory.get_memory_manager", lambda: manager)
    monkeypatch.setattr(
        "deerflow.agents.middlewares.dynamic_context_middleware.resolve_runtime_user_id",
        lambda runtime: "bob",
    )
    middleware = DynamicContextMiddleware()
    state = {"messages": [HumanMessage("answer this", id="message-1")]}

    with pytest.raises(MemoryManagerError) as inject_err:
        middleware.before_agent(state, None)
    with pytest.raises(MemoryManagerError) as search_err:
        manager.search("preferences", user_id="bob", agent_name="research")

    for error in (inject_err.value, search_err.value):
        # The scope-mismatch diagnostic must survive in the surfaced error or
        # anywhere in its chain -- whether the fix rewraps the scope error
        # (``from exc``) or raises the required-read subtype directly carrying
        # the same message.
        assert any("owner_user_id 'alice'" in str(link) for link in _exception_chain(error))
    # Scope resolution fails before any retrieval attempt.
    assert manager._retriever.calls == []
    # And the failure is a required-read failure (propagates through the call site).
    assert_propagates_as_required_read(type(inject_err.value), monkeypatch)


# ===========================================================================
# Criterion 4: prompt-assembly triad. (a) required-read -> propagates;
# (b) ordinary MemoryManagerError, no fail_closed -> ""; (c) legacy
# MemoryManagerError + failure_policy.read == "fail_closed" -> propagates.
# ===========================================================================
def _throwing_manager(exc: BaseException) -> SimpleNamespace:
    def _boom(*_a, **_k):
        raise exc

    return SimpleNamespace(get_context=_boom)


def _captured_required_read_type(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> type[BaseException]:
    """Obtain the concrete required-read error class from a real strict read,
    without ever naming it: the deterministic, offline scope-mismatch path under
    the 'raise' policy must surface a required-read failure (owner is 'alice',
    the read is for 'bob')."""
    import deerflow.agents.memory.backends.openviking.openviking_manager as module

    monkeypatch.setattr(module, "_load_official_integration", lambda: dict(_OFFICIAL_INTEGRATION))
    manager = _ov_manager(tmp_path, monkeypatch, failure_policy={"read": "raise"})
    try:
        manager.get_context("bob", agent_name="research")
    except MemoryManagerError as exc:
        return type(exc)
    raise AssertionError("strict scope mismatch did not raise")


def test_prompt_propagates_required_read_error_without_backend_config(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    required_type = _captured_required_read_type(tmp_path, monkeypatch)
    manager = _throwing_manager(required_type("down"))
    monkeypatch.setattr("deerflow.agents.memory.get_memory_manager", lambda: manager)

    with pytest.raises(MemoryManagerError, match="down"):
        prompt_module._get_memory_context("research", app_config=_app_config({}), user_id="user-1")


def test_prompt_swallows_ordinary_manager_error_without_fail_closed(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manager = _throwing_manager(MemoryManagerError("down"))
    monkeypatch.setattr("deerflow.agents.memory.get_memory_manager", lambda: manager)

    assert prompt_module._get_memory_context("research", app_config=_app_config({}), user_id="user-1") == ""


def test_prompt_preserves_legacy_fail_closed_manager_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manager = _throwing_manager(MemoryManagerError("down"))
    monkeypatch.setattr("deerflow.agents.memory.get_memory_manager", lambda: manager)

    with pytest.raises(MemoryManagerError, match="down"):
        prompt_module._get_memory_context(
            "research",
            app_config=_app_config({"failure_policy": {"read": "fail_closed"}}),
            user_id="user-1",
        )


# ===========================================================================
# Criterion 5: injection timeout honors read policy. Strict -> abort by
# raising required-read error whose cause is the TimeoutError; fail-open ->
# degrade (returns None).
# ===========================================================================
def _ov_middleware(read_policy: str, monkeypatch: pytest.MonkeyPatch) -> DynamicContextMiddleware:
    monkeypatch.setenv("OPENVIKING_API_KEY", "test-key")
    return DynamicContextMiddleware(
        app_config=SimpleNamespace(
            memory=MemoryConfig(
                manager_class="openviking",
                backend_config={"owner_user_id": "alice", "failure_policy": {"read": read_policy}},
            )
        )
    )


@pytest.mark.asyncio
async def test_injection_timeout_strict_policy_aborts_turn(monkeypatch: pytest.MonkeyPatch) -> None:
    await asyncio.to_thread(_scan_backends)
    mw = _ov_middleware("raise", monkeypatch)
    started, release, finished = threading.Event(), threading.Event(), threading.Event()

    def blocking_inject(state, runtime=None):
        started.set()
        release.wait(timeout=2)
        finished.set()

    try:
        with (
            mock.patch.object(mw, "_inject", blocking_inject),
            mock.patch("deerflow.agents.middlewares.dynamic_context_middleware._INJECT_TIMEOUT_SECONDS", 0.01),
        ):
            state = {"messages": [HumanMessage(content="Hello", id="msg-1")]}
            with pytest.raises(MemoryManagerError) as exc_info:
                await mw.abefore_agent(state, SimpleNamespace(context={}))
        assert_underlying_cause(exc_info.value, TimeoutError)
        assert started.is_set()
    finally:
        release.set()
        assert await asyncio.to_thread(finished.wait, 1)


@pytest.mark.asyncio
async def test_injection_timeout_fail_open_policy_degrades(monkeypatch: pytest.MonkeyPatch) -> None:
    await asyncio.to_thread(_scan_backends)
    mw = _ov_middleware("fail_open", monkeypatch)
    release, finished = threading.Event(), threading.Event()

    def blocking_inject(state, runtime=None):
        try:
            release.wait(timeout=2)
        finally:
            finished.set()

    try:
        with (
            mock.patch.object(mw, "_inject", blocking_inject),
            mock.patch("deerflow.agents.middlewares.dynamic_context_middleware._INJECT_TIMEOUT_SECONDS", 0.01),
        ):
            state = {"messages": [HumanMessage(content="Hello", id="msg-1")]}
            assert await mw.abefore_agent(state, SimpleNamespace(context={})) is None
    finally:
        release.set()
        assert await asyncio.to_thread(finished.wait, 1)


# ===========================================================================
# Criterion 6: the timeout handler does not wait on a saturated executor and
# does not submit a new executor job after the deadline.
# ===========================================================================
@pytest.mark.asyncio
@pytest.mark.parametrize("read_policy", ["raise", "fail_open"])
@pytest.mark.parametrize("already_saturated", [False, True], ids=["read_occupies_worker", "pool_already_full"])
async def test_timeout_does_not_wait_for_saturated_executor(
    monkeypatch: pytest.MonkeyPatch, read_policy: str, already_saturated: bool
) -> None:
    await asyncio.to_thread(_scan_backends)
    mw = _ov_middleware(read_policy, monkeypatch)
    entered, release, finished = threading.Event(), threading.Event(), threading.Event()
    executor = ThreadPoolExecutor(max_workers=1)
    loop = asyncio.get_running_loop()

    def occupy_worker(*_args):
        entered.set()
        release.wait(timeout=2)
        finished.set()

    try:
        with mock.patch.object(loop, "_default_executor", executor):
            if already_saturated:
                executor.submit(occupy_worker)
                while not entered.is_set():
                    await asyncio.sleep(0)
            with (
                mock.patch.object(mw, "_inject", side_effect=occupy_worker) as inject,
                mock.patch("deerflow.agents.middlewares.dynamic_context_middleware._INJECT_TIMEOUT_SECONDS", 0.01),
            ):
                call = mw.abefore_agent({"messages": [HumanMessage(content="hi", id="m1")]}, SimpleNamespace(context={}))
                if read_policy == "raise":
                    with pytest.raises(MemoryManagerError) as exc_info:
                        await asyncio.wait_for(call, 0.25)
                    assert_underlying_cause(exc_info.value, TimeoutError)
                else:
                    assert await asyncio.wait_for(call, 0.25) is None
                # Request resolved before its worker finished; no post-deadline re-submit.
                assert not finished.is_set()
                assert inject.call_count == (0 if already_saturated else 1)
    finally:
        release.set()
        await asyncio.to_thread(executor.shutdown, wait=True, cancel_futures=True)


# ===========================================================================
# Criterion 7: at the injection deadline the read policy must be resolved
# robustly. Two behaviors, both asserted WITHOUT pinning any resolver function
# or asserting whether/how discovery runs — so any valid fix passes, whether it
# resolves policy eagerly at construction, lazily per call, via a module-level
# function, via a cached boolean that still tracks the current config, or by
# backends raising directly:
#
#   (a) When the configured policy cannot be resolved at all (e.g. the
#       manager_class does not resolve to a backend), the timeout must FAIL
#       CLOSED — every valid fix must treat an unknown policy as fatal. (We use
#       an unresolvable manager_class rather than a backend whose default is
#       fail-open, so the assertion keys on "policy genuinely unresolved", not
#       on a particular deferred-resolution mechanism.)
#   (b) When memory or injection is DISABLED, no read happens, so the turn
#       degrades (returns None) regardless of policy — and injection is never
#       attempted.
# ===========================================================================
@pytest.mark.asyncio
async def test_timeout_fails_closed_when_policy_unresolvable(monkeypatch: pytest.MonkeyPatch) -> None:
    """A configured-but-unresolvable read policy that hits the injection
    deadline must fail closed with the TimeoutError preserved as the cause."""
    monkeypatch.delenv("OPENVIKING_API_KEY", raising=False)
    mw = DynamicContextMiddleware(
        app_config=SimpleNamespace(
            memory=MemoryConfig(manager_class="missing.backend:Manager", backend_config={})
        )
    )
    started, release, finished = threading.Event(), threading.Event(), threading.Event()

    def blocking_inject(state, runtime=None):
        started.set()
        try:
            release.wait(timeout=2)
        finally:
            finished.set()

    try:
        with (
            mock.patch.object(mw, "_inject", blocking_inject),
            mock.patch("deerflow.agents.middlewares.dynamic_context_middleware._INJECT_TIMEOUT_SECONDS", 0.01),
        ):
            with pytest.raises(MemoryManagerError) as exc_info:
                await mw.abefore_agent(
                    {"messages": [HumanMessage(content="hi", id="m1")]}, SimpleNamespace(context={})
                )
        assert_underlying_cause(exc_info.value, TimeoutError)
    finally:
        release.set()
        assert await asyncio.to_thread(finished.wait, 1)


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "disabled_field", ["enabled", "injection_enabled"],
    ids=["memory_disabled_degrades", "injection_disabled_degrades"],
)
async def test_timeout_with_disabled_memory_degrades_without_injection(
    monkeypatch: pytest.MonkeyPatch, disabled_field
) -> None:
    """A disabled memory / injection system needs no policy lookup: even with a
    saturated single-worker pool it degrades (returns None) and never attempts
    injection. No mechanism is pinned — we only assert the observable outcome."""
    monkeypatch.setenv("OPENVIKING_API_KEY", "test-key")
    cfg = MemoryConfig(manager_class="openviking")
    setattr(cfg, disabled_field, False)
    mw = DynamicContextMiddleware(app_config=SimpleNamespace(memory=cfg))
    executor = ThreadPoolExecutor(max_workers=1)
    release = threading.Event()
    try:
        with (
            mock.patch.object(asyncio.get_running_loop(), "_default_executor", executor),
            mock.patch.object(mw, "_inject") as inject,
            mock.patch("deerflow.agents.middlewares.dynamic_context_middleware._INJECT_TIMEOUT_SECONDS", 0.01),
        ):
            executor.submit(release.wait, 2)  # saturate the single worker
            assert await asyncio.wait_for(mw.abefore_agent({}, SimpleNamespace(context={})), 0.25) is None
            inject.assert_not_called()
    finally:
        release.set()
        await asyncio.to_thread(executor.shutdown, wait=True, cancel_futures=True)


# ===========================================================================
# Criterion 8: legacy third-party backends (no policy override) keep
# prompt-level semantics at the timeout: fail_closed -> fatal; fail_open /
# absent / malformed -> non-fatal (degrade).
# ===========================================================================
class _LegacyBackend(MemoryManager):
    """Third-party backend that inherits the default (legacy) policy resolver."""

    _release: threading.Event = PrivateAttr(default_factory=threading.Event)
    _finished: threading.Event = PrivateAttr(default_factory=threading.Event)

    @classmethod
    def from_config(cls, backend_config, *, mode="middleware", **host_hooks):
        return cls(backend_config=backend_config, mode=mode)

    def add(self, thread_id, messages, **kwargs):
        pass

    def get_context(self, user_id, **kwargs):
        try:
            self._release.wait(timeout=2)
            return "Late memory context"
        finally:
            self._finished.set()


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("read_config", "fatal"),
    [
        pytest.param({"failure_policy": {"read": "fail_closed"}}, True, id="legacy_fail_closed_fatal"),
        pytest.param({"failure_policy": {"read": "fail_open"}}, False, id="legacy_fail_open_degrades"),
        pytest.param({}, False, id="absent_policy_degrades"),
        pytest.param({"failure_policy": "fail_closed"}, False, id="malformed_policy_degrades"),
    ],
)
async def test_legacy_backend_timeout_preserves_read_policy(read_config: dict, fatal: bool) -> None:
    cfg = MemoryConfig(manager_class=f"{__name__}:_LegacyBackend", backend_config=read_config)
    backend = _LegacyBackend.from_config(cfg.backend_config)
    mw = DynamicContextMiddleware(app_config=SimpleNamespace(memory=cfg))
    executor = ThreadPoolExecutor(max_workers=1)
    try:
        with (
            mock.patch.object(asyncio.get_running_loop(), "_default_executor", executor),
            mock.patch("deerflow.agents.memory.get_memory_manager", return_value=backend),
            mock.patch("deerflow.agents.middlewares.dynamic_context_middleware._INJECT_TIMEOUT_SECONDS", 0.01),
        ):
            call = mw.abefore_agent({"messages": [HumanMessage(content="hi", id="m1")]}, SimpleNamespace(context={}))
            if fatal:
                with pytest.raises(MemoryManagerError) as exc_info:
                    await asyncio.wait_for(call, 0.25)
                assert_underlying_cause(exc_info.value, TimeoutError)
            else:
                assert await asyncio.wait_for(call, 0.25) is None
            assert not backend._finished.is_set()
    finally:
        backend._release.set()
        await asyncio.to_thread(executor.shutdown, wait=True, cancel_futures=True)
    assert backend._finished.is_set()


# ===========================================================================
# Criterion 9 (pass_to_pass): fail-open reads stay non-fatal and existing
# non-strict behavior is unchanged. Representative pre-existing behaviors that
# must keep working regardless of the strict-read change.
# ===========================================================================
def test_regression_mem0_fail_open_default_swallows(monkeypatch: pytest.MonkeyPatch) -> None:
    mgr, fake = _mem0_manager({}, monkeypatch)  # default read policy is fail-open
    fake.error = Mem0APIError("transient")
    assert mgr.get_context("u1") == ""


def test_regression_honcho_fail_open_default_swallows(monkeypatch: pytest.MonkeyPatch) -> None:
    mgr, fake = _honcho_manager(monkeypatch)  # default read_fail_closed is False
    fake.raise_on = "representation"
    assert mgr.get_context("u1") == ""


def test_regression_prompt_returns_empty_when_memory_disabled(monkeypatch: pytest.MonkeyPatch) -> None:
    disabled = SimpleNamespace(memory=SimpleNamespace(enabled=False, injection_enabled=False, backend_config={}))
    assert prompt_module._get_memory_context("research", app_config=disabled, user_id="user-1") == ""
