#!/usr/bin/env bash
# test-setup.sh — environment bootstrap for the verifier.
#
# The deer-flow backend is a uv workspace. Its full dependency closure
# (including the `dev` group that ships pytest + pytest-asyncio) is already
# baked into /opt/venv at image build time (Dockerfile block 10), so the
# verifier runs the focused pytest modules offline with no install step.
#
# Sourced (not exec'd) by the harbor runner so env vars set here stay live
# for the verifier subprocess.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/deer-flow}"
export REPO_DIR

# The backend pytest invocation (see repo Makefile `test` target) runs from
# the backend/ dir with PYTHONPATH=. and uv's project environment.
export BACKEND_DIR="${REPO_DIR}/backend"
export PYTHONPATH="${BACKEND_DIR}"
export PYTHONIOENCODING=utf-8
export PYTHONUTF8=1

# verify.toml drives the actual pytest invocation. tomllib ships with the
# verifier's Python 3.11+ (/opt/tooling/venv), so no tomli shim is needed.

# Sanity check: the project venv must be present and synced from the baked
# lockfile. Offline-first — the venv is already complete from the build; this
# is a no-op resync that only touches the network if the build venv drifted.
cd "$BACKEND_DIR"
if ! /opt/venv/bin/python -c "import pytest, pytest_asyncio" >/dev/null 2>&1; then
    echo "test-setup.sh: project venv missing pytest; resyncing from lockfile." >&2
    # Offline-first: the lockfile is frozen and the store was warmed at build
    # time, so the offline resync should satisfy from cache. Fall back to a
    # logged online sync only if the build-time store drifted.
    uv sync --frozen --offline --group dev > /tmp/test-setup-sync.log 2>&1 \
        || uv sync --frozen --group dev >> /tmp/test-setup-sync.log 2>&1 \
        || { tail -50 /tmp/test-setup-sync.log >&2; exit 1; }
fi
