//! A host CLI that embeds aube (tests/verify/host/verify_host.rs, built by
//! tests/test-setup.sh) installs a project whose root postinstall calls back
//! into the package manager the way packages do, `"$npm_execpath" run reached`.
//! The host has a `run` of its own and hands every other command line to
//! aube's CLI. The `reached` script records the program that ran it, which has
//! to be the host binary running aube's CLI.
//!
//! When the host leaves npm_execpath unset, the postinstall has nothing to
//! call and records that instead.

use std::path::{Path, PathBuf};
use std::process::Command;

fn host_bin() -> PathBuf {
    std::env::var_os("VERIFY_HOST_BIN")
        .map(PathBuf::from)
        .unwrap_or_else(|| {
            let target = std::env::var_os("CARGO_TARGET_DIR")
                .map(PathBuf::from)
                .unwrap_or_else(|| PathBuf::from("/repo/aube/target"));
            target.join("debug/examples/verify_host")
        })
}

/// Run by the postinstall: records its environment and its npm_execpath.
const RECORD_JS: &str = r#"const fs = require("fs");
const dir = process.env.VERIFY_HOST_LOG;
fs.writeFileSync(dir + "/script_env.json", JSON.stringify(process.env));
fs.writeFileSync(dir + "/execpath", process.env.npm_execpath || "");
"#;

/// The `reached` script: records the program that ran it.
const REACHED_JS: &str = r#"// Records the program that ran this script: the nearest ancestor process
// that isn't a shell.
const fs = require("fs");
const path = require("path");
const shells = ["sh", "dash", "bash"];
function parentOf(pid) {
  const stat = fs.readFileSync("/proc/" + pid + "/stat", "utf8");
  return Number(stat.slice(stat.lastIndexOf(")") + 2).split(" ")[1]);
}
let pid = process.ppid;
let exe = "";
for (let i = 0; i < 16 && pid > 1; i++) {
  exe = fs.readlinkSync("/proc/" + pid + "/exe");
  if (!shells.includes(path.basename(exe))) break;
  pid = parentOf(pid);
}
fs.writeFileSync(process.env.VERIFY_HOST_LOG + "/reached", exe);
"#;

/// The postinstall runs `"$npm_execpath" run reached` when an npm_execpath is
/// set, and records that it had none otherwise.
const POSTINSTALL: &str = "node record.js && if [ -n \"$npm_execpath\" ]; then \"$npm_execpath\" run reached; \
                           else : > \"$VERIFY_HOST_LOG/unset\"; fi; true";

fn write_project(project: &Path) {
    std::fs::create_dir_all(project).unwrap();
    std::fs::write(project.join("record.js"), RECORD_JS).unwrap();
    std::fs::write(project.join("reached.js"), REACHED_JS).unwrap();
    let manifest = serde_json::json!({
        "name": "reentry-probe",
        "version": "1.0.0",
        "private": true,
        "scripts": { "postinstall": POSTINSTALL, "reached": "node reached.js" }
    });
    std::fs::write(
        project.join("package.json"),
        serde_json::to_vec_pretty(&manifest).unwrap(),
    )
    .unwrap();
}

fn read(path: &Path) -> Option<String> {
    std::fs::read_to_string(path).ok()
}

#[test]
fn embedded_callback_is_answered_by_aube_through_the_host() {
    let host = host_bin();
    assert!(
        host.is_file(),
        "the test host {host:?} wasn't built; /tmp/verify-host-build.log ends with:\n{}",
        read(Path::new("/tmp/verify-host-build.log"))
            .map(|log| log.lines().rev().take(15).collect::<Vec<_>>().into_iter().rev().collect::<Vec<_>>().join("\n"))
            .unwrap_or_default()
    );

    let root = tempfile::tempdir().unwrap();
    let project = root.path().join("project");
    let log = root.path().join("log");
    let home = root.path().join("home");
    std::fs::create_dir_all(&log).unwrap();
    std::fs::create_dir_all(&home).unwrap();
    write_project(&project);

    let out = Command::new(&host)
        .arg("__verify_install")
        .arg(&project)
        .current_dir(&project)
        .env("VERIFY_HOST_LOG", &log)
        .env("HOME", &home)
        .env("XDG_CACHE_HOME", home.join("cache"))
        .env("XDG_DATA_HOME", home.join("data"))
        .env_remove("npm_execpath")
        .output()
        .unwrap();
    assert!(
        out.status.success(),
        "the install through the host failed ({}):\n{}",
        out.status,
        String::from_utf8_lossy(&out.stderr)
    );

    if log.join("unset").exists() {
        return;
    }
    let execpath = read(&log.join("execpath")).unwrap_or_default();
    if let Some(words) = read(&log.join("host_own_run")) {
        panic!(
            "the postinstall's \"$npm_execpath\" run reached (npm_execpath={execpath:?}) landed in \
             the host's own command line as `{words}`"
        );
    }
    let ran_by = read(&log.join("reached")).unwrap_or_else(|| {
        panic!(
            "the postinstall's \"$npm_execpath\" run reached (npm_execpath={execpath:?}) never ran \
             the reached script"
        )
    });
    let host_real = std::fs::canonicalize(&host).unwrap();
    assert_eq!(
        Path::new(&ran_by),
        host_real.as_path(),
        "the reached script was run by {ran_by:?}, not by aube in the host {host_real:?} \
         (npm_execpath={execpath:?})"
    );
}
