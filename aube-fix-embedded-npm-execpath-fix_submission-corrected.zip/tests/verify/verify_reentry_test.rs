//! A host CLI that embeds aube (tests/verify/host/verify_host.rs, built by
//! tests/test-setup.sh) installs a project, offline. Its install scripts call
//! back into the package manager the way packages do, with no guard:
//! `"$npm_execpath" run reached`. The host handles its own `run` and passes any
//! other command line to aube's CLI. The `reached` script records the program
//! that ran it, which has to be the host binary running aube's CLI.
//!
//! One case puts the call in the project's own postinstall, the other in the
//! postinstall of a registry dependency, as a package with prebuilt binaries
//! does when it checks its download.

use std::path::{Path, PathBuf};
use std::process::Command;

fn host_bin() -> PathBuf {
    std::env::var_os("VERIFY_HOST_BIN")
        .map(PathBuf::from)
        .unwrap_or_else(|| {
            let target = std::env::var_os("CARGO_TARGET_DIR")
                .map(PathBuf::from)
                .unwrap_or_else(|| PathBuf::from("/repo/aube/target"));
            target.join("debug/examples/verify_host")
        })
}

/// Writes the npm_execpath it was handed to the path given as its argument.
const RECORD_JS: &str = r#"require("fs").writeFileSync(process.argv[2], process.env.npm_execpath || "");
"#;

/// Writes the program that ran it, the nearest ancestor process that isn't a
/// shell, to the path given as its argument.
const REACHED_JS: &str = r#"const fs = require("fs");
const path = require("path");
const shells = ["sh", "dash", "bash"];
function parentOf(pid) {
  const stat = fs.readFileSync("/proc/" + pid + "/stat", "utf8");
  return Number(stat.slice(stat.lastIndexOf(")") + 2).split(" ")[1]);
}
let pid = process.ppid;
let exe = "";
for (let i = 0; i < 16 && pid > 1; i++) {
  exe = fs.readlinkSync("/proc/" + pid + "/exe");
  if (!shells.includes(path.basename(exe))) break;
  pid = parentOf(pid);
}
fs.writeFileSync(process.argv[2], exe);
"#;

/// The scripts of one package: a postinstall that records its npm_execpath and
/// then runs `"$npm_execpath" run reached`, and the `reached` script.
fn scripts(log: &Path, kind: &str) -> serde_json::Value {
    let l = log.display();
    serde_json::json!({
        "postinstall": format!("node {l}/record.js {l}/{kind}_execpath && \"$npm_execpath\" run reached"),
        "reached": format!("node {l}/reached.js {l}/{kind}_reached")
    })
}

struct Probe {
    _root: tempfile::TempDir,
    project: PathBuf,
    log: PathBuf,
    home: PathBuf,
    cache: PathBuf,
    store: PathBuf,
}

fn probe() -> Probe {
    let root = tempfile::tempdir().unwrap();
    let path = |p: &str| root.path().join(p);
    let probe = Probe {
        project: path("project"),
        log: path("log"),
        home: path("home"),
        cache: path("host-cache"),
        store: path("host-store"),
        _root: root,
    };
    for dir in [&probe.project, &probe.log, &probe.home] {
        std::fs::create_dir_all(dir).unwrap();
    }
    std::fs::write(probe.log.join("record.js"), RECORD_JS).unwrap();
    std::fs::write(probe.log.join("reached.js"), REACHED_JS).unwrap();
    probe
}

fn read(path: &Path) -> Option<String> {
    std::fs::read_to_string(path).ok()
}

/// Files named `name` anywhere below `dir`, symlinked folders skipped.
fn find(dir: &Path, name: &str, out: &mut Vec<PathBuf>) {
    let Ok(entries) = std::fs::read_dir(dir) else { return };
    for entry in entries.flatten() {
        let path = entry.path();
        let is_link = path.symlink_metadata().map(|m| m.file_type().is_symlink()).unwrap_or(true);
        if path.is_dir() && !is_link {
            find(&path, name, out);
        } else if path.file_name().and_then(|n| n.to_str()) == Some(name) {
            out.push(path);
        }
    }
}

/// Installs the probe's project through the host and checks that the `kind`
/// script's call was answered by aube in the host.
fn install_and_check(probe: &Probe, kind: &str, script: &str) {
    let host = host_bin();
    assert!(
        host.is_file(),
        "the test host {host:?} wasn't built; /tmp/verify-host-build.log ends with:\n{}",
        read(Path::new("/tmp/verify-host-build.log"))
            .map(|log| {
                let lines: Vec<&str> = log.lines().collect();
                lines[lines.len().saturating_sub(15)..].join("\n")
            })
            .unwrap_or_default()
    );
    let out = Command::new(&host)
        .arg("__verify_install")
        .arg(&probe.project)
        .arg(&probe.cache)
        .arg(&probe.store)
        .current_dir(&probe.project)
        .env("HOME", &probe.home)
        .env("XDG_CACHE_HOME", probe.home.join("cache"))
        .env("XDG_DATA_HOME", probe.home.join("data"))
        .env_remove("npm_execpath")
        .output()
        .unwrap();
    let execpath = read(&probe.log.join(format!("{kind}_execpath")));
    let mut own_run = Vec::new();
    find(&probe.project, "host_own_run", &mut own_run);
    if let Some(at) = own_run.first() {
        panic!(
            "the {script}'s \"$npm_execpath\" run reached (npm_execpath={execpath:?}) landed in the \
             host's own command line as `{}`",
            read(at).unwrap_or_default()
        );
    }
    let stderr_tail = String::from_utf8_lossy(&out.stderr)
        .lines()
        .rev()
        .take(12)
        .collect::<Vec<_>>()
        .into_iter()
        .rev()
        .collect::<Vec<_>>()
        .join("\n");
    let ran_by = read(&probe.log.join(format!("{kind}_reached"))).unwrap_or_else(|| {
        panic!(
            "the {script}'s \"$npm_execpath\" run reached (npm_execpath={execpath:?}) never ran \
             the reached script; the install through the host ended with {}, stderr:\n{stderr_tail}",
            out.status
        )
    });
    assert!(
        out.status.success(),
        "the install through the host failed ({}) after the reached script ran:\n{stderr_tail}",
        out.status
    );
    let host_real = std::fs::canonicalize(&host).unwrap();
    assert_eq!(
        Path::new(&ran_by),
        host_real.as_path(),
        "the {script}'s reached script was run by {ran_by:?}, not by aube in the host {host_real:?} \
         (npm_execpath={execpath:?})"
    );
}

/// Seed a registry package `cached-only@1.0.0` with these `scripts`
/// into a cache and store, the way the repository's embed tests seed theirs,
/// so an offline install can fetch it and run its script.
fn seed_package_with_scripts(cache_dir: &Path, store_dir: &Path, scripts: serde_json::Value) {
    let packument_cache_dir = cache_dir.join("packuments-v1");
    let full_packument_cache_dir = cache_dir.join("packuments-full-v1");
    std::fs::create_dir_all(&packument_cache_dir).unwrap();
    std::fs::create_dir_all(&full_packument_cache_dir).unwrap();
    let package = tempfile::tempdir().unwrap();
    let manifest = serde_json::json!({
        "name": "cached-only",
        "version": "1.0.0",
        "scripts": scripts.clone()
    });
    std::fs::write(
        package.path().join("package.json"),
        serde_json::to_vec(&manifest).unwrap(),
    )
    .unwrap();

    let store = aube_store::Store::with_dirs(store_dir.join("v1/files"), cache_dir.to_path_buf());
    let index = store.import_directory(package.path()).unwrap();
    store
        .save_index("cached-only", "1.0.0", None, &index)
        .unwrap();

    let packument: aube_registry::Packument = serde_json::from_value(serde_json::json!({
        "name": "cached-only",
        "dist-tags": { "latest": "1.0.0" },
        "versions": {
            "1.0.0": {
                "name": "cached-only",
                "version": "1.0.0",
                "scripts": scripts.clone(),
                "dist": {
                    "tarball": "https://registry.npmjs.org/cached-only/-/cached-only-1.0.0.tgz"
                }
            }
        }
    }))
    .unwrap();
    let client = aube_registry::client::RegistryClient::new("https://registry.npmjs.org/");
    client.seed_packument_cache(
        "cached-only",
        &packument_cache_dir,
        &packument,
        None,
        None,
        true,
    );
    client.seed_full_packument_cache(
        "cached-only",
        &full_packument_cache_dir,
        &packument,
        None,
        None,
        true,
    );
}

#[test]
fn embedded_root_callback_is_answered_by_aube_through_the_host() {
    let probe = probe();
    let manifest = serde_json::json!({
        "name": "reentry-probe",
        "version": "1.0.0",
        "private": true,
        "scripts": scripts(&probe.log, "root")
    });
    std::fs::write(
        probe.project.join("package.json"),
        serde_json::to_vec_pretty(&manifest).unwrap(),
    )
    .unwrap();
    install_and_check(&probe, "root", "project's postinstall");
}

#[test]
fn embedded_dependency_callback_is_answered_by_aube_through_the_host() {
    let probe = probe();
    seed_package_with_scripts(&probe.cache, &probe.store, scripts(&probe.log, "dep"));
    std::fs::write(
        probe.project.join("package.json"),
        "{\"name\":\"reentry-probe\",\"version\":\"1.0.0\",\"private\":true,\
         \"dependencies\":{\"cached-only\":\"1.0.0\"}}\n",
    )
    .unwrap();
    std::fs::write(
        probe.project.join("pnpm-workspace.yaml"),
        "allowBuilds:\n  cached-only: true\n",
    )
    .unwrap();
    install_and_check(&probe, "dep", "cached-only dependency's postinstall");
}
