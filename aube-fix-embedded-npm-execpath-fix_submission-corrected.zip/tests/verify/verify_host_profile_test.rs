//! A host profile written the way hosts write one today: a static `Host` with
//! these fields named and nothing else. It still has to build, and to register
//! through the embed facade.

use aube::embed::Host;

static HOST_PROFILE: Host = Host {
    name: "testhost",
    display_name: "Test Host",
    vendor: None,
    version: "1.0.0",
    user_agent: "testhost/1.0.0",
    self_names: &["testhost"],
    compatible_names: &["pnpm"],
    lockfile_basename: "testhost-lock.yaml",
    workspace_yaml: None,
    manifest_namespace: "testhost",
    env_prefix: None,
    config_env_prefix: None,
    cache_namespace: "testhost",
    data_namespace: "testhost",
    canonical_lockfile_always_wins: true,
    runtime_switching: false,
    self_engines_check: false,
    self_update_enabled: false,
};

#[test]
fn host_profile_written_as_today_builds_and_registers() {
    aube::embed::initialize(&HOST_PROFILE, Vec::new());
    assert_eq!(aube::embed::host().name, "testhost");
}
