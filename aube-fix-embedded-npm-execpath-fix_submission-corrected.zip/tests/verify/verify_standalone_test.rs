//! Standalone aube: the profile registered is aube's own, as the aube binary
//! registers it on every run. The root lifecycle script and a dependency's
//! postinstall each record the `npm_execpath` they're handed, which has to be
//! set and name a program their shell can run. A third case installs with the
//! aube binary itself, and a postinstall's `"$npm_execpath" run reached` has to
//! be answered by aube: the `reached` script records the program that runs it.
//!
//! The profile is registered once per process, so these cases run in a test
//! binary of their own.

use aube::embed::{AddToProjectOptions, InstallControl, InstallOptions};
use std::path::{Path, PathBuf};
use std::process::Command;

const MARKER_NAME: &str = "execpath.marker";
const RESOLVED_NAME: &str = "execpath.resolved";

fn initialize_aube() {
    aube::embed::initialize(
        &aube::embed::AUBE,
        vec![("minimumReleaseAge".to_string(), "0".to_string())],
    );
}

/// A lifecycle script that writes `npm_execpath=<value>` to `<dir>execpath.marker`
/// and, when the value is set and names a program the shell can run, that
/// program's path to `<dir>execpath.resolved`. `dir` is empty for the script's
/// own working directory, or an absolute directory ending in `/`.
fn probe_script(dir: &str) -> String {
    format!(
        "node -e \"require('fs').writeFileSync('{dir}{MARKER_NAME}', 'npm_execpath=' + (process.env.npm_execpath || ''))\" \
         && if [ -n \"$npm_execpath\" ]; then p=$(command -v \"$npm_execpath\") && [ -x \"$p\" ] \
         && printf '%s' \"$p\" > '{dir}{RESOLVED_NAME}'; fi; true"
    )
}

/// A pnpm workspace with an `app` member and a `library` member, plus a root
/// `package.json` whose `pnpm:devPreinstall` script is the probe. Adding
/// `library@workspace:*` to the app runs that root script in the workspace root.
fn workspace_with_root_probe() -> (tempfile::TempDir, PathBuf) {
    let workspace = tempfile::tempdir().unwrap();
    let app = workspace.path().join("packages/app");
    let library = workspace.path().join("packages/library");
    std::fs::create_dir_all(&app).unwrap();
    std::fs::create_dir_all(&library).unwrap();
    let manifest = serde_json::json!({
        "private": true,
        "scripts": { "pnpm:devPreinstall": probe_script("") }
    });
    std::fs::write(
        workspace.path().join("package.json"),
        serde_json::to_vec(&manifest).unwrap(),
    )
    .unwrap();
    std::fs::write(
        workspace.path().join("pnpm-workspace.yaml"),
        "packages:\n  - packages/*\n",
    )
    .unwrap();
    std::fs::write(app.join("package.json"), "{\"name\":\"app\"}\n").unwrap();
    std::fs::write(
        library.join("package.json"),
        "{\"name\":\"library\",\"version\":\"1.0.0\"}\n",
    )
    .unwrap();
    (workspace, app)
}

/// Seed a registry package `cached-only@1.0.0` whose `postinstall` is `script`
/// into a cache and store, the way the repository's embed tests seed theirs,
/// so an offline install can fetch it and run its script.
fn seed_package_with_postinstall(cache_dir: &Path, store_dir: &Path, script: &str) {
    let packument_cache_dir = cache_dir.join("packuments-v1");
    let full_packument_cache_dir = cache_dir.join("packuments-full-v1");
    std::fs::create_dir_all(&packument_cache_dir).unwrap();
    std::fs::create_dir_all(&full_packument_cache_dir).unwrap();
    let package = tempfile::tempdir().unwrap();
    let manifest = serde_json::json!({
        "name": "cached-only",
        "version": "1.0.0",
        "scripts": { "postinstall": script }
    });
    std::fs::write(
        package.path().join("package.json"),
        serde_json::to_vec(&manifest).unwrap(),
    )
    .unwrap();

    let store = aube_store::Store::with_dirs(store_dir.join("v1/files"), cache_dir.to_path_buf());
    let index = store.import_directory(package.path()).unwrap();
    store
        .save_index("cached-only", "1.0.0", None, &index)
        .unwrap();

    let packument: aube_registry::Packument = serde_json::from_value(serde_json::json!({
        "name": "cached-only",
        "dist-tags": { "latest": "1.0.0" },
        "versions": {
            "1.0.0": {
                "name": "cached-only",
                "version": "1.0.0",
                "scripts": { "postinstall": script },
                "dist": {
                    "tarball": "https://registry.npmjs.org/cached-only/-/cached-only-1.0.0.tgz"
                }
            }
        }
    }))
    .unwrap();
    let client = aube_registry::client::RegistryClient::new("https://registry.npmjs.org/");
    client.seed_packument_cache(
        "cached-only",
        &packument_cache_dir,
        &packument,
        None,
        None,
        true,
    );
    client.seed_full_packument_cache(
        "cached-only",
        &full_packument_cache_dir,
        &packument,
        None,
        None,
        true,
    );
}

/// The `npm_execpath=<value>` a probe recorded; an unset variable records "".
fn recorded_execpath(marker: &Path) -> String {
    let contents = std::fs::read_to_string(marker).unwrap_or_else(|e| {
        panic!("the lifecycle script did not record a marker at {marker:?}: {e}")
    });
    contents
        .strip_prefix("npm_execpath=")
        .unwrap_or(&contents)
        .trim_end()
        .to_string()
}

/// What the probe in `dir` saw: an `npm_execpath` is set, and the script's
/// shell can run the program it names.
fn assert_handed_a_runnable_execpath(dir: &Path, script: &str) {
    let recorded = recorded_execpath(&dir.join(MARKER_NAME));
    assert!(
        !recorded.is_empty(),
        "standalone, the {script} was handed no npm_execpath"
    );
    let resolved = std::fs::read_to_string(dir.join(RESOLVED_NAME)).unwrap_or_default();
    assert!(
        !resolved.trim().is_empty(),
        "standalone, the {script} was handed npm_execpath={recorded:?}, which its shell can't run"
    );
}

#[tokio::test]
async fn standalone_root_lifecycle_script_is_handed_a_runnable_execpath() {
    initialize_aube();
    let (workspace, app) = workspace_with_root_probe();

    aube::embed::add(
        &app,
        &["library@workspace:*".to_string()],
        AddToProjectOptions {
            offline: true,
            control: InstallControl::silent(),
            ..Default::default()
        },
    )
    .await
    .unwrap();

    assert_handed_a_runnable_execpath(workspace.path(), "root pnpm:devPreinstall script");
}

#[tokio::test]
async fn standalone_dependency_postinstall_is_handed_a_runnable_execpath() {
    initialize_aube();
    let project = tempfile::tempdir().unwrap();
    let dir = format!("{}/", project.path().display());
    let cache = project.path().join("cache");
    let store = project.path().join("store");
    seed_package_with_postinstall(&cache, &store, &probe_script(&dir));
    std::fs::write(
        project.path().join("package.json"),
        "{\"dependencies\":{\"cached-only\":\"1.0.0\"}}\n",
    )
    .unwrap();
    std::fs::write(
        project.path().join("pnpm-workspace.yaml"),
        "allowBuilds:\n  cached-only: true\n",
    )
    .unwrap();

    let mut options = InstallOptions::new(project.path());
    options.network_mode = aube::embed::NetworkMode::Offline;
    options.control = InstallControl::silent();
    aube::embed::install_with_overrides(
        options,
        aube::embed::EmbedderInstallOverrides {
            use_global_virtual_store: Some(false),
            cache_dir: Some(cache),
            store_dir: Some(store),
        },
    )
    .await
    .unwrap();

    assert_handed_a_runnable_execpath(project.path(), "postinstall script of the cached-only dependency");
}

/// Run by the postinstall: records its npm_execpath.
const RECORD_JS: &str = r#"const fs = require("fs");
const dir = process.env.VERIFY_HOST_LOG;
fs.writeFileSync(dir + "/script_env.json", JSON.stringify(process.env));
fs.writeFileSync(dir + "/execpath", process.env.npm_execpath || "");
"#;

/// The `reached` script: records the program that ran it.
const REACHED_JS: &str = r#"// Records the program that ran this script: the nearest ancestor process
// that isn't a shell.
const fs = require("fs");
const path = require("path");
const shells = ["sh", "dash", "bash"];
function parentOf(pid) {
  const stat = fs.readFileSync("/proc/" + pid + "/stat", "utf8");
  return Number(stat.slice(stat.lastIndexOf(")") + 2).split(" ")[1]);
}
let pid = process.ppid;
let exe = "";
for (let i = 0; i < 16 && pid > 1; i++) {
  exe = fs.readlinkSync("/proc/" + pid + "/exe");
  if (!shells.includes(path.basename(exe))) break;
  pid = parentOf(pid);
}
fs.writeFileSync(process.env.VERIFY_HOST_LOG + "/reached", exe);
"#;

/// The postinstall runs `"$npm_execpath" run reached` when an npm_execpath is
/// set, and records that it had none otherwise.
const POSTINSTALL: &str = "node record.js && if [ -n \"$npm_execpath\" ]; then \"$npm_execpath\" run reached; \
                           else : > \"$VERIFY_HOST_LOG/unset\"; fi; true";

fn write_callback_project(project: &Path) {
    std::fs::create_dir_all(project).unwrap();
    std::fs::write(project.join("record.js"), RECORD_JS).unwrap();
    std::fs::write(project.join("reached.js"), REACHED_JS).unwrap();
    let manifest = serde_json::json!({
        "name": "callback-probe",
        "version": "1.0.0",
        "private": true,
        "scripts": { "postinstall": POSTINSTALL, "reached": "node reached.js" }
    });
    std::fs::write(
        project.join("package.json"),
        serde_json::to_vec_pretty(&manifest).unwrap(),
    )
    .unwrap();
}

#[test]
fn standalone_callback_is_answered_by_aube() {
    let root = tempfile::tempdir().unwrap();
    let project = root.path().join("project");
    let log = root.path().join("log");
    let home = root.path().join("home");
    std::fs::create_dir_all(&log).unwrap();
    std::fs::create_dir_all(&home).unwrap();
    write_callback_project(&project);

    let aube = env!("CARGO_BIN_EXE_aube");
    let out = Command::new(aube)
        .args(["install", "--offline"])
        .current_dir(&project)
        .env("VERIFY_HOST_LOG", &log)
        .env("HOME", &home)
        .env("XDG_CACHE_HOME", home.join("cache"))
        .env("XDG_DATA_HOME", home.join("data"))
        .env_remove("npm_execpath")
        .output()
        .unwrap();
    assert!(
        out.status.success(),
        "aube install failed ({}):\n{}",
        out.status,
        String::from_utf8_lossy(&out.stderr)
    );
    assert!(
        !log.join("unset").exists(),
        "standalone, the postinstall was handed no npm_execpath"
    );
    let execpath = std::fs::read_to_string(log.join("execpath")).unwrap_or_default();
    let ran_by = std::fs::read_to_string(log.join("reached")).unwrap_or_else(|_| {
        panic!(
            "standalone, the postinstall's \"$npm_execpath\" run reached \
             (npm_execpath={execpath:?}) never ran the reached script"
        )
    });
    let aube_real = std::fs::canonicalize(aube).unwrap();
    assert_eq!(
        Path::new(&ran_by),
        aube_real.as_path(),
        "standalone, the reached script was run by {ran_by:?}, not by aube ({aube_real:?}) \
         (npm_execpath={execpath:?})"
    );
}
