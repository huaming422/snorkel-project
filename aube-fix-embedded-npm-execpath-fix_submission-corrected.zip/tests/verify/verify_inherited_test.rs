//! A host embeds aube, and an `npm_execpath` is already in this process's
//! environment, as it is when the host itself was started from another
//! package manager's script. The root lifecycle script records what it's
//! handed; the value is held against the host executable and against the
//! inherited one.
//!
//! The host profile is registered once per process, so this case runs in a
//! test binary of its own.

use aube::embed::{AddToProjectOptions, Host, InstallControl};
use std::path::{Path, PathBuf};

/// A host called "testhost", with every field the repository's own embed tests
/// set. A field the profile gains later takes aube's own value.
static FOREIGN_HOST: Host = Host {
    name: "testhost",
    display_name: "Test Host",
    vendor: None,
    version: "1.0.0",
    user_agent: "testhost/1.0.0",
    self_names: &["testhost"],
    compatible_names: &["pnpm"],
    lockfile_basename: "testhost-lock.yaml",
    workspace_yaml: None,
    manifest_namespace: "testhost",
    env_prefix: None,
    config_env_prefix: None,
    cache_namespace: "testhost",
    data_namespace: "testhost",
    canonical_lockfile_always_wins: true,
    runtime_switching: false,
    self_engines_check: false,
    self_update_enabled: false,
    ..aube::embed::AUBE
};

const MARKER_NAME: &str = "execpath.marker";
const RESOLVED_NAME: &str = "execpath.resolved";

fn initialize_host() {
    aube::embed::initialize(
        &FOREIGN_HOST,
        vec![("minimumReleaseAge".to_string(), "0".to_string())],
    );
}

/// A lifecycle script that writes `npm_execpath=<value>` to `<dir>execpath.marker`
/// and, when the value is set and names a program the shell can run, that
/// program's path to `<dir>execpath.resolved`. `dir` is empty for the script's
/// own working directory, or an absolute directory ending in `/`.
fn probe_script(dir: &str) -> String {
    format!(
        "node -e \"require('fs').writeFileSync('{dir}{MARKER_NAME}', 'npm_execpath=' + (process.env.npm_execpath || ''))\" \
         && if [ -n \"$npm_execpath\" ]; then p=$(command -v \"$npm_execpath\") && [ -x \"$p\" ] \
         && printf '%s' \"$p\" > '{dir}{RESOLVED_NAME}'; fi; true"
    )
}

/// A pnpm workspace with an `app` member and a `library` member, plus a root
/// `package.json` whose `pnpm:devPreinstall` script is the probe. Adding
/// `library@workspace:*` to the app runs that root script in the workspace root.
fn workspace_with_root_probe() -> (tempfile::TempDir, PathBuf) {
    let workspace = tempfile::tempdir().unwrap();
    let app = workspace.path().join("packages/app");
    let library = workspace.path().join("packages/library");
    std::fs::create_dir_all(&app).unwrap();
    std::fs::create_dir_all(&library).unwrap();
    let manifest = serde_json::json!({
        "private": true,
        "scripts": { "pnpm:devPreinstall": probe_script("") }
    });
    std::fs::write(
        workspace.path().join("package.json"),
        serde_json::to_vec(&manifest).unwrap(),
    )
    .unwrap();
    std::fs::write(
        workspace.path().join("pnpm-workspace.yaml"),
        "packages:\n  - packages/*\n",
    )
    .unwrap();
    std::fs::write(app.join("package.json"), "{\"name\":\"app\"}\n").unwrap();
    std::fs::write(
        library.join("package.json"),
        "{\"name\":\"library\",\"version\":\"1.0.0\"}\n",
    )
    .unwrap();
    (workspace, app)
}

/// The `npm_execpath=<value>` a probe recorded; an unset variable records "".
fn recorded_execpath(marker: &Path) -> String {
    let contents = std::fs::read_to_string(marker).unwrap_or_else(|e| {
        panic!("the lifecycle script did not record a marker at {marker:?}: {e}")
    });
    contents
        .strip_prefix("npm_execpath=")
        .unwrap_or(&contents)
        .trim_end()
        .to_string()
}

/// What the probe in `dir` saw, held against the host executable: not its path,
/// and when set, a program the script can run that isn't the host executable
/// under another name (a symlink, another spelling of the path, a hard link).
fn assert_not_the_host(dir: &Path, script: &str) -> String {
    let recorded = recorded_execpath(&dir.join(MARKER_NAME));
    let host_exe = std::env::current_exe().expect("the test process has a current_exe");
    let host = host_exe.to_string_lossy().into_owned();
    assert_ne!(
        recorded, host,
        "embedded, the {script} was handed the host executable ({host:?}) as npm_execpath"
    );
    if recorded.is_empty() {
        return recorded;
    }
    let resolved = std::fs::read_to_string(dir.join(RESOLVED_NAME)).unwrap_or_default();
    assert!(
        !resolved.trim().is_empty(),
        "embedded, the {script} was handed npm_execpath={recorded:?}, which its shell can't run"
    );
    let resolved = std::fs::canonicalize(resolved.trim()).unwrap();
    let host_real = std::fs::canonicalize(&host_exe).unwrap();
    assert_ne!(
        resolved, host_real,
        "embedded, the {script} was handed npm_execpath={recorded:?}, which is the host executable"
    );
    #[cfg(unix)]
    {
        use std::os::unix::fs::MetadataExt;
        let (named, host_meta) = (
            std::fs::metadata(&resolved).unwrap(),
            std::fs::metadata(&host_real).unwrap(),
        );
        assert!(
            !(named.dev() == host_meta.dev() && named.ino() == host_meta.ino()),
            "embedded, the {script} was handed npm_execpath={recorded:?}, a hard link to the host executable"
        );
    }
    recorded
}

/// The `npm_execpath` an outer package manager would have exported.
const INHERITED_EXECPATH: &str = "/outer-package-manager/bin/not-aube-execpath";

#[tokio::test]
async fn embedded_lifecycle_script_is_not_handed_an_inherited_execpath() {
    initialize_host();
    // SAFETY: the only test in this binary, set before anything is spawned.
    unsafe { std::env::set_var("npm_execpath", INHERITED_EXECPATH) };
    let (workspace, app) = workspace_with_root_probe();

    aube::embed::add(
        &app,
        &["library@workspace:*".to_string()],
        AddToProjectOptions {
            offline: true,
            control: InstallControl::silent(),
            ..Default::default()
        },
    )
    .await
    .unwrap();

    let recorded = recorded_execpath(&workspace.path().join(MARKER_NAME));
    assert_ne!(
        recorded, INHERITED_EXECPATH,
        "the root pnpm:devPreinstall script was handed the npm_execpath aube inherited \
         from an outer package manager"
    );
    assert_not_the_host(workspace.path(), "root pnpm:devPreinstall script");
}
