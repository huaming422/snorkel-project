//! A host CLI that embeds aube, for verify_reentry_test.rs. tests/test-setup.sh
//! builds it as an example of the aube crate from the tree under test.
//!
//! Like a version manager that links aube in, it handles its own commands and
//! passes any other command line to aube's CLI:
//!
//!   verify_host __verify_install <dir> <cache> <store>
//!                                  installs <dir> through aube::embed, offline,
//!                                  with its own cache and store
//!   verify_host run <name>         its own `run`, which knows no tasks
//!   anything else                  aube::cli_main with the host profile
//!
//! Its own commands are those two, called under its own program name.

use std::path::{Path, PathBuf};

static HOST: aube::embed::Host = aube::embed::Host {
    name: "testhost",
    display_name: "Test Host",
    vendor: None,
    version: "1.0.0",
    user_agent: "testhost/1.0.0",
    self_names: &["testhost"],
    compatible_names: &["pnpm"],
    lockfile_basename: "testhost-lock.yaml",
    workspace_yaml: None,
    manifest_namespace: "testhost",
    env_prefix: None,
    config_env_prefix: None,
    cache_namespace: "testhost",
    data_namespace: "testhost",
    canonical_lockfile_always_wins: true,
    runtime_switching: false,
    self_engines_check: false,
    self_update_enabled: false,
    ..aube::embed::AUBE
};

fn install(dir: &str, cache: &str, store: &str) -> i32 {
    aube::embed::initialize(
        &HOST,
        vec![("minimumReleaseAge".to_string(), "0".to_string())],
    );
    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .expect("a tokio runtime for the install");
    let mut options = aube::embed::InstallOptions::new(dir);
    options.network_mode = aube::embed::NetworkMode::Offline;
    options.control = aube::embed::InstallControl::silent();
    let overrides = aube::embed::EmbedderInstallOverrides {
        use_global_virtual_store: Some(false),
        cache_dir: Some(PathBuf::from(cache)),
        store_dir: Some(PathBuf::from(store)),
    };
    match runtime.block_on(aube::embed::install_with_overrides(options, overrides)) {
        Ok(()) => 0,
        Err(err) => {
            eprintln!("testhost: install failed: {err:?}");
            1
        }
    }
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let own_name = args
        .first()
        .and_then(|arg0| Path::new(arg0).file_stem())
        .and_then(|stem| stem.to_str())
        == Some("verify_host");
    let arg = |i: usize| args.get(i).map(String::as_str).unwrap_or("");

    if own_name && arg(1) == "__verify_install" {
        std::process::exit(install(arg(2), arg(3), arg(4)));
    }
    if own_name && arg(1) == "run" {
        // The host's own `run`: it records the call where it was made and fails.
        let _ = std::fs::write("host_own_run", args[1..].join(" "));
        eprintln!("testhost: no task named {:?}", arg(2));
        std::process::exit(1);
    }
    std::process::exit(aube::cli_main(&HOST));
}
