//! A host CLI that embeds aube, for verify_reentry_test.rs. tests/test-setup.sh
//! builds it as an example of the aube crate from the tree under test.
//!
//! Like a version manager that links aube in, it has commands of its own and
//! hands every other command line to aube's CLI:
//!
//!   verify_host __verify_install <dir>   installs <dir> through aube::embed
//!   verify_host run <name>               its own `run`, which knows no tasks
//!   anything else                        aube::cli_main with the host profile
//!
//! A call counts as the host's own `run` only when it comes in under the
//! host's own program name and with the environment the lifecycle script had
//! (recorded by the script in $VERIFY_HOST_LOG/script_env.json). A different
//! program name, or a variable the caller added, marks the call as aube's.

use std::collections::BTreeMap;
use std::path::{Path, PathBuf};

static HOST: aube::embed::Host = aube::embed::Host {
    name: "testhost",
    display_name: "Test Host",
    vendor: None,
    version: "1.0.0",
    user_agent: "testhost/1.0.0",
    self_names: &["testhost"],
    compatible_names: &["pnpm"],
    lockfile_basename: "testhost-lock.yaml",
    workspace_yaml: None,
    manifest_namespace: "testhost",
    env_prefix: None,
    config_env_prefix: None,
    cache_namespace: "testhost",
    data_namespace: "testhost",
    canonical_lockfile_always_wins: true,
    runtime_switching: false,
    self_engines_check: false,
    self_update_enabled: false,
    ..aube::embed::AUBE
};

/// Variables a shell or `exec` can change on its own.
const SHELL_NOISE: &[&str] = &["PWD", "OLDPWD", "SHLVL", "_"];

fn log_dir() -> Option<PathBuf> {
    std::env::var_os("VERIFY_HOST_LOG").map(PathBuf::from)
}

/// True when this process has a variable the lifecycle script didn't have, or
/// one with another value.
fn caller_added_variables(log: &Path) -> bool {
    let Ok(text) = std::fs::read_to_string(log.join("script_env.json")) else {
        return false;
    };
    let Ok(script_env) = serde_json::from_str::<BTreeMap<String, String>>(&text) else {
        return false;
    };
    std::env::vars().any(|(key, value)| {
        !SHELL_NOISE.contains(&key.as_str()) && script_env.get(&key) != Some(&value)
    })
}

fn install(dir: &str) -> i32 {
    aube::embed::initialize(
        &HOST,
        vec![("minimumReleaseAge".to_string(), "0".to_string())],
    );
    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .expect("a tokio runtime for the install");
    let mut options = aube::embed::InstallOptions::new(dir);
    options.network_mode = aube::embed::NetworkMode::Offline;
    options.control = aube::embed::InstallControl::silent();
    match runtime.block_on(aube::embed::install(options)) {
        Ok(()) => 0,
        Err(err) => {
            eprintln!("testhost: install failed: {err:?}");
            1
        }
    }
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let own_name = args
        .first()
        .and_then(|arg0| Path::new(arg0).file_stem())
        .and_then(|stem| stem.to_str())
        == Some("verify_host");
    let first = args.get(1).map(String::as_str);

    if own_name && first == Some("__verify_install") {
        std::process::exit(install(args.get(2).map(String::as_str).unwrap_or(".")));
    }
    if own_name && first == Some("run") {
        let log = log_dir();
        let aube_call = log.as_deref().is_some_and(caller_added_variables);
        if !aube_call {
            if let Some(log) = log {
                let _ = std::fs::write(log.join("host_own_run"), args[1..].join(" "));
            }
            eprintln!("testhost: no task named {:?}", args.get(2).map(String::as_str).unwrap_or(""));
            std::process::exit(1);
        }
    }
    std::process::exit(aube::cli_main(&HOST));
}
