//! A host embeds aube and installs through the public embed facade. Every
//! lifecycle script in these cases records the `npm_execpath` it's handed and,
//! when that's set, the program its shell resolves the name to. The values are
//! held against this test process's own executable, which is the host here.
//!
//! The host profile is registered once per process, so these cases run in a
//! test binary of their own.

use aube::embed::{AddToProjectOptions, Host, InstallControl, InstallOptions};
use std::path::{Path, PathBuf};

/// A host called "testhost", with every field the repository's own embed tests
/// set. A field the profile gains later takes aube's own value.
static FOREIGN_HOST: Host = Host {
    name: "testhost",
    display_name: "Test Host",
    vendor: None,
    version: "1.0.0",
    user_agent: "testhost/1.0.0",
    self_names: &["testhost"],
    compatible_names: &["pnpm"],
    lockfile_basename: "testhost-lock.yaml",
    workspace_yaml: None,
    manifest_namespace: "testhost",
    env_prefix: None,
    config_env_prefix: None,
    cache_namespace: "testhost",
    data_namespace: "testhost",
    canonical_lockfile_always_wins: true,
    runtime_switching: false,
    self_engines_check: false,
    self_update_enabled: false,
    ..aube::embed::AUBE
};

const MARKER_NAME: &str = "execpath.marker";
const RESOLVED_NAME: &str = "execpath.resolved";

fn initialize_host() {
    aube::embed::initialize(
        &FOREIGN_HOST,
        vec![("minimumReleaseAge".to_string(), "0".to_string())],
    );
}

/// A lifecycle script that writes `npm_execpath=<value>` to `<dir>execpath.marker`
/// and, when the value is set and names a program the shell can run, that
/// program's path to `<dir>execpath.resolved`. `dir` is empty for the script's
/// own working directory, or an absolute directory ending in `/`.
fn probe_script(dir: &str) -> String {
    format!(
        "node -e \"require('fs').writeFileSync('{dir}{MARKER_NAME}', 'npm_execpath=' + (process.env.npm_execpath || ''))\" \
         && if [ -n \"$npm_execpath\" ]; then p=$(command -v \"$npm_execpath\") && [ -x \"$p\" ] \
         && printf '%s' \"$p\" > '{dir}{RESOLVED_NAME}'; fi; true"
    )
}

/// A pnpm workspace with an `app` member and a `library` member, plus a root
/// `package.json` whose `pnpm:devPreinstall` script is the probe. Adding
/// `library@workspace:*` to the app runs that root script in the workspace root.
fn workspace_with_root_probe() -> (tempfile::TempDir, PathBuf) {
    let workspace = tempfile::tempdir().unwrap();
    let app = workspace.path().join("packages/app");
    let library = workspace.path().join("packages/library");
    std::fs::create_dir_all(&app).unwrap();
    std::fs::create_dir_all(&library).unwrap();
    let manifest = serde_json::json!({
        "private": true,
        "scripts": { "pnpm:devPreinstall": probe_script("") }
    });
    std::fs::write(
        workspace.path().join("package.json"),
        serde_json::to_vec(&manifest).unwrap(),
    )
    .unwrap();
    std::fs::write(
        workspace.path().join("pnpm-workspace.yaml"),
        "packages:\n  - packages/*\n",
    )
    .unwrap();
    std::fs::write(app.join("package.json"), "{\"name\":\"app\"}\n").unwrap();
    std::fs::write(
        library.join("package.json"),
        "{\"name\":\"library\",\"version\":\"1.0.0\"}\n",
    )
    .unwrap();
    (workspace, app)
}

/// Seed a registry package `cached-only@1.0.0` whose `postinstall` is `script`
/// into a cache and store, the way the repository's embed tests seed theirs,
/// so an offline install can fetch it and run its script.
fn seed_package_with_postinstall(cache_dir: &Path, store_dir: &Path, script: &str) {
    let packument_cache_dir = cache_dir.join("packuments-v1");
    let full_packument_cache_dir = cache_dir.join("packuments-full-v1");
    std::fs::create_dir_all(&packument_cache_dir).unwrap();
    std::fs::create_dir_all(&full_packument_cache_dir).unwrap();
    let package = tempfile::tempdir().unwrap();
    let manifest = serde_json::json!({
        "name": "cached-only",
        "version": "1.0.0",
        "scripts": { "postinstall": script }
    });
    std::fs::write(
        package.path().join("package.json"),
        serde_json::to_vec(&manifest).unwrap(),
    )
    .unwrap();

    let store = aube_store::Store::with_dirs(store_dir.join("v1/files"), cache_dir.to_path_buf());
    let index = store.import_directory(package.path()).unwrap();
    store
        .save_index("cached-only", "1.0.0", None, &index)
        .unwrap();

    let packument: aube_registry::Packument = serde_json::from_value(serde_json::json!({
        "name": "cached-only",
        "dist-tags": { "latest": "1.0.0" },
        "versions": {
            "1.0.0": {
                "name": "cached-only",
                "version": "1.0.0",
                "scripts": { "postinstall": script },
                "dist": {
                    "tarball": "https://registry.npmjs.org/cached-only/-/cached-only-1.0.0.tgz"
                }
            }
        }
    }))
    .unwrap();
    let client = aube_registry::client::RegistryClient::new("https://registry.npmjs.org/");
    client.seed_packument_cache(
        "cached-only",
        &packument_cache_dir,
        &packument,
        None,
        None,
        true,
    );
    client.seed_full_packument_cache(
        "cached-only",
        &full_packument_cache_dir,
        &packument,
        None,
        None,
        true,
    );
}

/// The `npm_execpath=<value>` a probe recorded; an unset variable records "".
fn recorded_execpath(marker: &Path) -> String {
    let contents = std::fs::read_to_string(marker).unwrap_or_else(|e| {
        panic!("the lifecycle script did not record a marker at {marker:?}: {e}")
    });
    contents
        .strip_prefix("npm_execpath=")
        .unwrap_or(&contents)
        .trim_end()
        .to_string()
}

/// What the probe in `dir` saw, held against the host executable: not its
/// path, and when set, a program the script's shell can run. Whether running
/// it reaches aube is verify_reentry_test.rs.
fn assert_not_the_host(dir: &Path, script: &str) -> String {
    let recorded = recorded_execpath(&dir.join(MARKER_NAME));
    let host = std::env::current_exe()
        .expect("the test process has a current_exe")
        .to_string_lossy()
        .into_owned();
    assert_ne!(
        recorded, host,
        "embedded, the {script} was handed the host executable ({host:?}) as npm_execpath"
    );
    if recorded.is_empty() {
        return recorded;
    }
    let resolved = std::fs::read_to_string(dir.join(RESOLVED_NAME)).unwrap_or_default();
    assert!(
        !resolved.trim().is_empty(),
        "embedded, the {script} was handed npm_execpath={recorded:?}, which its shell can't run"
    );
    recorded
}

#[tokio::test]
async fn embedded_root_lifecycle_script_is_not_handed_the_host_executable() {
    initialize_host();
    let (workspace, app) = workspace_with_root_probe();

    aube::embed::add(
        &app,
        &["library@workspace:*".to_string()],
        AddToProjectOptions {
            offline: true,
            control: InstallControl::silent(),
            ..Default::default()
        },
    )
    .await
    .unwrap();

    assert_not_the_host(workspace.path(), "root pnpm:devPreinstall script");
}

#[tokio::test]
async fn embedded_dependency_postinstall_is_not_handed_the_host_executable() {
    initialize_host();
    let project = tempfile::tempdir().unwrap();
    let dir = format!("{}/", project.path().display());
    let host_cache = project.path().join("host-cache");
    let host_store = project.path().join("host-store");
    seed_package_with_postinstall(&host_cache, &host_store, &probe_script(&dir));
    std::fs::write(
        project.path().join("package.json"),
        "{\"dependencies\":{\"cached-only\":\"1.0.0\"}}\n",
    )
    .unwrap();
    std::fs::write(
        project.path().join("pnpm-workspace.yaml"),
        "allowBuilds:\n  cached-only: true\n",
    )
    .unwrap();

    let mut options = InstallOptions::new(project.path());
    options.network_mode = aube::embed::NetworkMode::Offline;
    options.control = InstallControl::silent();
    aube::embed::install_with_overrides(
        options,
        aube::embed::EmbedderInstallOverrides {
            use_global_virtual_store: Some(false),
            cache_dir: Some(host_cache),
            store_dir: Some(host_store),
        },
    )
    .await
    .unwrap();

    assert_not_the_host(project.path(), "postinstall script of the cached-only dependency");
}
