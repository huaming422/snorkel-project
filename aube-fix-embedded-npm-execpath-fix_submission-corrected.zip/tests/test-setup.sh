#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# aube is a Rust workspace; the image baked the full dependency closure
# (cargo fetch --locked + cargo build --locked --tests). This step brings that
# closure online offline-first. When neither fetch works it logs the cause and
# carries on, so the verifier's own cargo build reports it.
cd /repo/aube

# Cut the network for cargo so a cache miss fails loudly instead of reaching a
# registry (this script is also sourced offline, under `--network none`).
export CARGO_NET_OFFLINE=true

# Dependencies: offline-first against the image bake, logged online fallback.
if cargo fetch --locked --offline > /tmp/test-setup-fetch.log 2>&1; then
    echo "[offline-first] cargo deps satisfied from image"
elif CARGO_NET_OFFLINE=false cargo fetch --locked >> /tmp/test-setup-fetch.log 2>&1; then
    echo "[test-setup] cargo deps fetched online (image bake was stale)"
else
    tail -40 /tmp/test-setup-fetch.log >&2
    echo "[test-setup] cargo fetch failed; the verifier's cargo build will report why" >&2
fi

# The host CLI that verify_reentry_test.rs installs through: an example of the
# aube crate (tests/verify/host/verify_host.rs), built from the tree under test
# on the warm target dir and then taken out of the tree again. A host that
# doesn't build is logged; the test then reports the log.
VERIFY_HOST_BIN="${CARGO_TARGET_DIR:-/repo/aube/target}/debug/examples/verify_host"
export VERIFY_HOST_BIN
rm -f "$VERIFY_HOST_BIN"
if [ -f /tests/verify/host/verify_host.rs ]; then
    mkdir -p crates/aube/examples
    cp /tests/verify/host/verify_host.rs crates/aube/examples/verify_host.rs
    if cargo build --offline -p aube --example verify_host > /tmp/verify-host-build.log 2>&1; then
        echo "[test-setup] built the test host at $VERIFY_HOST_BIN"
    else
        echo "[test-setup] the test host didn't build; see /tmp/verify-host-build.log" >&2
    fi
    rm -f crates/aube/examples/verify_host.rs
    rmdir crates/aube/examples 2>/dev/null || true
fi

# No services to start and no data to seed: the behavior under test is produced
# by aube's embedding facade and the aube binary when they run a lifecycle script.
# No assertion logic here; that lives in the verifier.
