## Task

Host CLIs that link aube in as a library, the way mise does, can't install packages whose install scripts ask whichever package manager is installing them to run another script, like a package with prebuilt binaries running `${npm_execpath} run verify-build` on its download. When a host drives the install, that step fails, the error it prints comes from the host's own CLI rather than from aube, and the install never completes. Fetching is fine either way, and the aube binary on its own installs those packages without trouble.

Those hosts set up the embed the usual way, and we need these installs to work in them.
