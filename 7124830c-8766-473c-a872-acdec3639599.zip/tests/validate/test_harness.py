"""Framework plumbing for the cocoindex-code stateless-client validation stories.

The harness drives the daemon's public interfaces — the ones this change leaves
in place — and observes behaviour across them:

  * daemon lifecycle launchers ``start_daemon()`` / ``stop_daemon()``
    (``cocoindex_code.client``) — present and unchanged by the migration;
  * the socket / PID path helpers ``daemon_socket_path()`` /
    ``daemon_pid_path()`` (``cocoindex_code.daemon``);
  * the msgspec wire-protocol structs + ``encode_request`` / ``decode_response``
    (``cocoindex_code.protocol``) — the stable IPC contract that must not
    change;
  * the ``ccc`` command-line entry point, driven as a subprocess;
  * the on-disk project-settings writer ``save_project_settings`` with
    ``ProjectSettings`` / ``LanguageOverride`` (``cocoindex_code.settings``) —
    this is exactly how a user edits ``.cocoindex_code/settings.yml``.

It works entirely through those public surfaces — the wire protocol, the CLI,
and the lifecycle launchers — and does not reach into the client, connection, or
settings-reload internals. The daemon always runs as its own subprocess, so the
embedding model and every connection cross the real process boundary; talking to
it at the wire protocol and the CLI is enough to observe the
one-request-per-connection behaviour and the live settings pickup.

Each probe starts a fresh daemon in an isolated, short ``COCOINDEX_CODE_DIR``
(the AF_UNIX socket path has a ~108-byte limit), indexes a tiny throwaway
project, returns a concrete observable dict, and tears the daemon down in a
``finally`` block.
"""

from __future__ import annotations

import os
import shutil
import sys
import time
import uuid
import subprocess
from contextlib import contextmanager
from multiprocessing.connection import Client
from pathlib import Path
from typing import Any, Iterator

# The daemon subprocess loads the embedding model baked into the image; keep it
# offline so a cache miss fails loudly instead of reaching for the network.
_OFFLINE_ENV = {
    "HF_HOME": os.environ.get("HF_HOME", "/opt/hf-cache"),
    "HF_HUB_OFFLINE": "1",
    "TRANSFORMERS_OFFLINE": "1",
}

# AF_UNIX on Linux/macOS, AF_PIPE on Windows. Mirrors the daemon's own choice
# without importing its private helper (the value is platform-derived, not a
# solution choice).
_CONN_FAMILY = "AF_PIPE" if sys.platform == "win32" else "AF_UNIX"

# ---------------------------------------------------------------------------
# Daemon lifecycle
# ---------------------------------------------------------------------------
@contextmanager
def isolated_daemon() -> Iterator[Path]:
    """Start a daemon in a private, short COCOINDEX_CODE_DIR and tear it down.

    Yields the base directory (the daemon's home); the socket and PID files live
    directly under it. On exit the daemon is stopped and the directory removed,
    and the prior COCOINDEX_CODE_DIR value is restored.
    """
    from cocoindex_code.client import start_daemon, stop_daemon
    from cocoindex_code.settings import default_user_settings, save_user_settings

    base = Path("/tmp") / f"ccv_{uuid.uuid4().hex[:8]}"
    base.mkdir(parents=True, exist_ok=True)
    prev = os.environ.get("COCOINDEX_CODE_DIR")
    os.environ["COCOINDEX_CODE_DIR"] = str(base)
    for key, value in _OFFLINE_ENV.items():
        os.environ.setdefault(key, value)

    try:
        # The daemon reads user settings (embedder config) on startup.
        save_user_settings(default_user_settings())
        start_daemon()
        _wait_until_reachable(deadline_sec=60.0)
        yield base
    finally:
        try:
            stop_daemon()
        except Exception:
            pass
        if prev is None:
            os.environ.pop("COCOINDEX_CODE_DIR", None)
        else:
            os.environ["COCOINDEX_CODE_DIR"] = prev
        shutil.rmtree(base, ignore_errors=True)


def _wait_until_reachable(deadline_sec: float) -> None:
    """Block until the daemon answers a handshake, or raise on timeout."""
    from cocoindex_code.daemon import daemon_socket_path

    deadline = time.monotonic() + deadline_sec
    last_err: Exception | None = None
    while time.monotonic() < deadline:
        if os.path.exists(daemon_socket_path()):
            try:
                conn = Client(daemon_socket_path(), family=_CONN_FAMILY)
                try:
                    resp = _handshake(conn)
                    if getattr(resp, "ok", False):
                        return
                finally:
                    conn.close()
            except Exception as exc:  # socket exists but not accepting yet
                last_err = exc
        time.sleep(0.2)
    raise RuntimeError(f"daemon did not become reachable in {deadline_sec}s: {last_err}")


# ---------------------------------------------------------------------------
# Wire-protocol helpers (stable IPC contract)
# ---------------------------------------------------------------------------
def _assert_protocol_shapes() -> None:
    """Check stable wire tags and required response keys, not struct field order."""
    from cocoindex_code import protocol
    import msgspec

    request_samples = [
        (protocol.HandshakeRequest(version="v"), "handshake", {"version": "v"}),
        (protocol.IndexRequest(project_root="/p"), "index", {"project_root": "/p"}),
        (protocol.SearchRequest(project_root="/p", query="q", languages=["python"], paths=["main.py"], limit=3, offset=1), "search", {"project_root": "/p", "query": "q", "languages": ["python"], "paths": ["main.py"], "limit": 3, "offset": 1}),
        (protocol.ProjectStatusRequest(project_root="/p"), "project_status", {"project_root": "/p"}),
        (protocol.DaemonStatusRequest(), "daemon_status", {}),
        (protocol.RemoveProjectRequest(project_root="/p"), "remove_project", {"project_root": "/p"}),
        (protocol.StopRequest(), "stop", {}),
    ]
    for sample, tag, required in request_samples:
        wire = msgspec.msgpack.decode(protocol.encode_request(sample))
        assert wire.get("type") == tag, (tag, wire)
        assert all(wire.get(key) == value for key, value in required.items()), wire
        assert type(protocol.decode_request(protocol.encode_request(sample))) is type(sample)

    response_samples = [
        (protocol.HandshakeResponse(ok=True, daemon_version="v"), "handshake", {"ok", "daemon_version", "global_settings_mtime_us"}),
        (protocol.IndexResponse(success=True, message="done"), "index", None),
        (protocol.IndexProgressUpdate(progress=protocol.IndexingProgress(1, 2, 3, 4, 5, 6)), "index_progress", None),
        (protocol.IndexWaitingNotice(), "index_waiting", None),
        (protocol.SearchResponse(success=True, results=[protocol.SearchResult("/p/main.py", "python", "content", 1, 2, 0.5)], total_returned=1, offset=0, message="done"), "search", None),
        (protocol.DaemonStatusResponse(version="v", uptime_seconds=0.0, projects=[]), "daemon_status", {"version", "uptime_seconds", "projects"}),
        (protocol.ProjectStatusResponse(indexing=False, total_chunks=0, total_files=0, languages={}), "project_status", {"indexing", "total_chunks", "total_files", "languages", "progress", "index_exists"}),
        (protocol.RemoveProjectResponse(ok=True), "remove_project", None),
        (protocol.StopResponse(ok=True), "stop", None),
        (protocol.ErrorResponse(message="error"), "error", None),
    ]
    for sample, tag, fields in response_samples:
        wire = msgspec.msgpack.decode(protocol.encode_response(sample))
        assert wire.get("type") == tag, (tag, wire)
        if fields is not None:
            assert set(wire) == fields | {"type"}, (tag, wire)
        assert type(protocol.decode_response(protocol.encode_response(sample))) is type(sample)


def _open_connection():
    """Open a raw connection to the running daemon's socket."""
    _assert_protocol_shapes()
    from cocoindex_code.daemon import daemon_socket_path

    return Client(daemon_socket_path(), family=_CONN_FAMILY)


def _handshake(conn) -> Any:
    """Perform the version handshake on *conn* and return the response."""
    from cocoindex_code._version import __version__
    from cocoindex_code.protocol import HandshakeRequest, decode_response, encode_request

    conn.send_bytes(encode_request(HandshakeRequest(version=__version__)))
    return decode_response(conn.recv_bytes())


def _recv_final(conn) -> Any:
    """Read responses off *conn*, skipping streaming frames, return the terminal one."""
    from cocoindex_code.protocol import decode_response

    while True:
        resp = decode_response(conn.recv_bytes())
        # Skip the intermediate streaming frames an index run emits; the terminal
        # frame (IndexResponse / SearchResponse / etc.) is what callers want.
        if type(resp).__name__ in ("IndexProgressUpdate", "IndexWaitingNotice"):
            continue
        return resp


def _send_on_fresh_connection(req) -> Any:
    """Open a connection, handshake, send one request, read the terminal response, close."""
    from cocoindex_code.protocol import encode_request

    conn = _open_connection()
    try:
        _handshake(conn)
        conn.send_bytes(encode_request(req))
        return _recv_final(conn)
    finally:
        conn.close()


def _wire_index(project_root: str) -> None:
    """Drive a full index run over its own connection and wait for completion."""
    from cocoindex_code.protocol import IndexRequest

    resp = _send_on_fresh_connection(IndexRequest(project_root=project_root))
    if type(resp).__name__ != "IndexResponse" or not getattr(resp, "success", False):
        raise RuntimeError(f"index did not succeed: {resp!r}")


def _wire_status(project_root: str) -> Any:
    """Fetch a ProjectStatusResponse over its own connection."""
    from cocoindex_code.protocol import ProjectStatusRequest

    return _send_on_fresh_connection(ProjectStatusRequest(project_root=project_root))


# ---------------------------------------------------------------------------
# Project scaffolding (throwaway codebases to index)
# ---------------------------------------------------------------------------
def _make_project(files: dict[str, str]) -> Path:
    """Create a tiny indexable project with *files* and default project settings.

    Writing project settings also creates the ``.cocoindex_code/`` marker the CLI
    uses to resolve the project root.
    """
    from cocoindex_code.settings import default_project_settings, save_project_settings

    root = Path("/tmp") / f"ccp_{uuid.uuid4().hex[:8]}"
    root.mkdir(parents=True, exist_ok=True)
    for rel, content in files.items():
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content)
    save_project_settings(root, default_project_settings())
    return root


# ---------------------------------------------------------------------------
# Story 1: per_request_connection (wire level)
# ---------------------------------------------------------------------------
def probe_connection_reuse(request_kind: str) -> dict:
    """Observe how the daemon treats a second request on the SAME connection.

    Opens one connection, handshakes, sends a single ``request_kind`` request and
    reads its response; then — WITHOUT reconnecting — sends a second request and
    tries to read a reply. Finally opens a fresh connection and confirms a
    request succeeds there.

    Returns concrete observables:
      * ``first_response``    — the type name of the response to the first request
      * ``second_same_conn``  — ``"closed"`` if the second request on the same
                                connection yields no response (connection gone),
                                ``"served"`` if a second response comes back
      * ``fresh_response``    — the type name of the response over a brand-new
                                connection
    """
    from cocoindex_code.protocol import (
        DaemonStatusRequest,
        ProjectStatusRequest,
        encode_request,
    )

    with isolated_daemon():
        root = _make_project({"main.py": "def greet():\n    return 'hello'\n"})
        try:
            _wire_index(str(root))

            if request_kind == "daemon_status":
                req = DaemonStatusRequest()
            elif request_kind == "project_status":
                req = ProjectStatusRequest(project_root=str(root))
            else:
                raise ValueError(f"unknown request_kind: {request_kind}")

            conn = _open_connection()
            try:
                _handshake(conn)
                conn.send_bytes(encode_request(req))
                first = _recv_final(conn)

                # Second request on the SAME connection — must not be served
                # under the per-request model.
                second_same_conn = "served"
                try:
                    conn.send_bytes(encode_request(req))
                    _recv_final(conn)
                    second_same_conn = "served"
                except (EOFError, OSError, BrokenPipeError):
                    second_same_conn = "closed"
            finally:
                conn.close()

            fresh = _send_on_fresh_connection(req)

            # A request sent before the handshake must be rejected.
            bare = _open_connection()
            try:
                bare.send_bytes(encode_request(req))
                try:
                    bare_reply = _recv_final(bare)
                    bare_request = "rejected" if type(bare_reply).__name__ == "ErrorResponse" else "served"
                except (EOFError, OSError):
                    bare_request = "rejected"
            finally:
                bare.close()

            return {
                "first_response": type(first).__name__,
                "second_same_conn": second_same_conn,
                "fresh_response": type(fresh).__name__,
                "bare_request": bare_request,
            }
        finally:
            shutil.rmtree(root, ignore_errors=True)


# ---------------------------------------------------------------------------
# Story 2: live_settings_pickup (wire level, same running daemon)
# ---------------------------------------------------------------------------
def probe_live_settings(extension: str, override_lang: str) -> dict:
    """Index, edit project settings on disk, re-index the SAME daemon, observe.

    1. Index a project that contains one ``.py`` file plus one ``extra.<extension>``
       file whose extension is NOT in the default include set (so it is ignored).
    2. Record the baseline file count and language set.
    3. Edit ``.cocoindex_code/settings.yml`` to include ``**/*.<extension>``, and —
       when *override_lang* is given — add a language override mapping that
       extension to *override_lang*.
    4. Re-index against the SAME running daemon (no restart).

    Returns concrete observables:
      * ``indexed_delta``     — how many more files are indexed after the edit
      * ``new_file_language`` — the language label the newly-included file picked
                                up (the single new key in the languages dict), or
                                ``"none"`` if no new file was indexed
    """
    from cocoindex_code.settings import (
        LanguageOverride,
        load_project_settings,
        save_project_settings,
    )

    with isolated_daemon():
        root = _make_project(
            {
                "main.py": "def greet():\n    return 'hello world'\n",
                f"extra.{extension}": "alpha beta gamma delta epsilon payload\n",
            }
        )
        try:
            _wire_index(str(root))
            before = _wire_status(str(root))
            before_files = int(before.total_files)
            before_langs = set(before.languages.keys())

            # Edit the on-disk project settings the way a user would.
            settings = load_project_settings(root)
            if f"**/*.{extension}" not in settings.include_patterns:
                settings.include_patterns.append(f"**/*.{extension}")
            if override_lang and override_lang != "none":
                settings.language_overrides.append(
                    LanguageOverride(ext=extension, lang=override_lang)
                )
            save_project_settings(root, settings)

            # Re-index the SAME daemon process.
            _wire_index(str(root))
            after = _wire_status(str(root))
            after_files = int(after.total_files)
            after_langs = set(after.languages.keys())

            new_keys = sorted(after_langs - before_langs)
            new_file_language = new_keys[0] if new_keys else "none"

            return {
                "indexed_delta": after_files - before_files,
                "new_file_language": new_file_language,
            }
        finally:
            shutil.rmtree(root, ignore_errors=True)


# ---------------------------------------------------------------------------
# Story: live_gitignore_pickup (wire level, same running daemon)
# ---------------------------------------------------------------------------
def probe_live_gitignore(direction: str) -> dict:
    """Edit a project's ignore rules on disk and re-index the SAME daemon.

    The project holds two indexable ``.py`` files; one of them (``notes.py``)
    is toggled in and out of the project's ``.gitignore`` between two index runs
    against a single running daemon:

      * ``direction == "unignore"`` — ``notes.py`` starts ignored (one file
        indexed), then the ignore rule is removed, so the next run should pick
        it up.
      * ``direction == "ignore"`` — nothing is ignored at first (both files
        indexed), then ``notes.py`` is added to ``.gitignore``, so the next run
        should drop it.

    Returns a concrete observable:
      * ``indexed_delta`` — how many more (``+``) or fewer (``-``) files the
        daemon indexes after the ignore-rule edit than before it. A non-zero
        delta means the running daemon re-read the project's ignore rules fresh
        on the next index run; ``0`` means the edited ignore rules were ignored
        (a stale daemon would need a restart).
    """
    with isolated_daemon():
        root = _make_project(
            {
                "main.py": "def greet():\n    return 'hello world'\n",
                "notes.py": "def hidden():\n    return 'alpha beta gamma payload'\n",
            }
        )
        try:
            gitignore = root / ".gitignore"
            if direction == "unignore":
                gitignore.write_text("notes.py\n")
            elif direction == "ignore":
                gitignore.write_text("# nothing ignored yet\n")
            else:
                raise ValueError(f"unknown direction: {direction}")

            _wire_index(str(root))
            before_files = int(_wire_status(str(root)).total_files)

            # Edit the on-disk ignore rules the way a user would.
            if direction == "unignore":
                gitignore.write_text("# notes.py is no longer ignored\n")
            else:
                gitignore.write_text("notes.py\n")

            # Re-index the SAME daemon process.
            _wire_index(str(root))
            after_files = int(_wire_status(str(root)).total_files)

            return {"indexed_delta": after_files - before_files}
        finally:
            shutil.rmtree(root, ignore_errors=True)


# ---------------------------------------------------------------------------
# Story 3: cli_roundtrip_unchanged (subprocess CLI)
# ---------------------------------------------------------------------------
def probe_cli_roundtrip(query: str) -> dict:
    """Run ``ccc index`` then ``ccc search <query>`` as subprocesses.

    The daemon is auto-started by the CLI itself (and stopped on teardown).

    Returns concrete observables:
      * ``result_basenames`` — sorted list of file basenames appearing in the
                               search results
      * ``result_count``     — number of result lines returned
    """
    with isolated_daemon():
        root = _make_project(
            {
                "main.py": (
                    "def compute_fibonacci(n):\n"
                    "    a, b = 0, 1\n"
                    "    for _ in range(n):\n"
                    "        a, b = b, a + b\n"
                    "    return a\n"
                ),
                "util.py": (
                    "def normalize_whitespace(text):\n"
                    "    return ' '.join(text.split())\n"
                ),
            }
        )
        try:
            _run_ccc(["index"], cwd=root)
            status = _run_ccc(["status"], cwd=root)
            out = _run_ccc(["search", query, "--limit", "10"], cwd=root)

            basenames = set()
            count = 0
            for line in out.splitlines():
                line = line.strip()
                if line.startswith("File:"):
                    count += 1
                    # "File: /abs/path/main.py:1-5 [python]"
                    locator = line[len("File:"):].strip().split(" ")[0]
                    path_part = locator.rsplit(":", 1)[0] if ":" in locator else locator
                    basenames.add(Path(path_part).name)
            return {
                "result_basenames": sorted(basenames),
                "result_count": count,
                "status_has_index": "Index stats:" in status and "Files:" in status,
            }
        finally:
            shutil.rmtree(root, ignore_errors=True)


def _run_ccc(args: list[str], cwd: Path) -> str:
    """Invoke the ``ccc`` CLI as a subprocess under the current interpreter."""
    env = {**os.environ}
    for key, value in _OFFLINE_ENV.items():
        env.setdefault(key, value)
    proc = subprocess.run(
        [sys.executable, "-m", "cocoindex_code.cli", *args],
        cwd=str(cwd),
        env=env,
        capture_output=True,
        text=True,
        timeout=240,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            f"ccc {' '.join(args)} failed (rc={proc.returncode})\n"
            f"STDOUT:\n{proc.stdout}\nSTDERR:\n{proc.stderr}"
        )
    return proc.stdout


# ---------------------------------------------------------------------------
# Story 4: clean_shutdown (lifecycle files + restart)
# ---------------------------------------------------------------------------
def probe_clean_shutdown(stop_via: str) -> dict:
    """Start a daemon, stop it, and inspect the lifecycle files + restart.

    *stop_via* selects the stop mechanism:
      * ``"wire"``   — send a StopRequest over the wire protocol
      * ``"helper"`` — call the stable ``stop_daemon()`` launcher

    Returns concrete observables:
      * ``socket_after_stop`` — ``"absent"`` / ``"present"``
      * ``pid_after_stop``    — ``"absent"`` / ``"present"``
      * ``fresh_daemon``      — the handshake response type name of a brand-new
                               daemon started afterward (``"none"`` if it never
                               came up)
    """
    from cocoindex_code.client import start_daemon, stop_daemon
    from cocoindex_code.daemon import daemon_pid_path, daemon_socket_path
    from cocoindex_code.protocol import StopRequest
    from cocoindex_code.settings import default_user_settings, save_user_settings

    base = Path("/tmp") / f"ccs_{uuid.uuid4().hex[:8]}"
    base.mkdir(parents=True, exist_ok=True)
    prev = os.environ.get("COCOINDEX_CODE_DIR")
    os.environ["COCOINDEX_CODE_DIR"] = str(base)
    for key, value in _OFFLINE_ENV.items():
        os.environ.setdefault(key, value)

    original_pid: int | None = None
    try:
        save_user_settings(default_user_settings())
        start_daemon()
        _wait_until_reachable(deadline_sec=60.0)
        original_pid = int(daemon_pid_path().read_text().strip())

        if stop_via == "wire":
            _send_on_fresh_connection(StopRequest())
        elif stop_via == "helper":
            stop_daemon()
        else:
            raise ValueError(f"unknown stop_via: {stop_via}")

        # Wait for the original process, not just its removable path names.
        deadline = time.monotonic() + 15.0
        while time.monotonic() < deadline:
            if (not _process_alive(original_pid) and
                    not os.path.exists(daemon_socket_path()) and
                    not daemon_pid_path().exists()):
                break
            time.sleep(0.2)

        socket_after = "present" if os.path.exists(daemon_socket_path()) else "absent"
        pid_after = "present" if daemon_pid_path().exists() else "absent"
        process_after = "alive" if _process_alive(original_pid) else "exited"

        # A fresh daemon can be started afterwards.
        fresh = "none"
        try:
            start_daemon()
            _wait_until_reachable(deadline_sec=60.0)
            resp = _send_on_fresh_connection_handshake_only()
            fresh = type(resp).__name__
        finally:
            try:
                stop_daemon()
            except Exception:
                pass

        return {
            "socket_after_stop": socket_after,
            "pid_after_stop": pid_after,
            "process_after_stop": process_after,
            "fresh_daemon": fresh,
        }
    finally:
        if original_pid is not None and _process_alive(original_pid):
            try:
                os.kill(original_pid, 15)
            except ProcessLookupError:
                pass
        try:
            stop_daemon()
        except Exception:
            pass
        if prev is None:
            os.environ.pop("COCOINDEX_CODE_DIR", None)
        else:
            os.environ["COCOINDEX_CODE_DIR"] = prev
        shutil.rmtree(base, ignore_errors=True)


def _process_alive(pid: int) -> bool:
    """Treat a reaped or zombie process as exited without sending a signal."""
    try:
        if sys.platform == "linux":
            state = Path(f"/proc/{pid}/stat").read_text().split(") ", 1)[1][0]
            return state not in ("Z", "X")
        os.kill(pid, 0)
        return True
    except (FileNotFoundError, ProcessLookupError):
        return False


def _send_on_fresh_connection_handshake_only() -> Any:
    """Open a fresh connection, handshake, return the handshake response, close."""
    conn = _open_connection()
    try:
        return _handshake(conn)
    finally:
        conn.close()
