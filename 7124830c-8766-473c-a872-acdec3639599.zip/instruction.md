## Task

Please migrate the `ccc` CLI and its background indexing daemon to a connection per operation. Today they can exchange multiple requests over one persistent connection; the new interaction should be stateless. This work also includes live project configuration and dependable daemon shutdown.

Keep the public `ccc` experience intact for indexing, search, and status. The wire message types and request and response formats must remain compatible. In particular, `HandshakeResponse`, `DaemonStatusResponse`, and `ProjectStatusResponse` retain their names and shapes.

## User stories / requirements

- For every client operation, open a connection and complete the version handshake before sending one request and reading its response. The daemon closes that connection after serving the request. A later operation opens another connection and succeeds independently.
- If someone changes a project's indexing settings, their next re-index on the running daemon uses those settings without a restart.
- Changes to a project's ignore rules affect the next re-index on that daemon. Ignoring a file removes it from the index; removing that rule lets the file return.
- A user can index a codebase and search it with the usual `ccc` commands, and the search still returns relevant results.
- A stop request causes the daemon to exit promptly and clear its socket and PID file. Starting a new daemon afterward succeeds.
