## Task

we're getting reports from Element X users that messages sometimes land out of order in a chat, and it always seems to cluster around a message that failed to send. the failed one gets the error marker, but anything they typed after it still goes out and shows up ahead of it on the other side, so the thread reads backwards for the receiver, like a reply landing before the message it answers. and the failed one then just never sends on its own, no retry, nothing, even though whatever went wrong looked momentary rather than final. it's intermittent and lines up with flaky-connection moments: the server hiccups for a second and we seem to write that send off for good, while messages a moment later go through fine.

there's a related thing too: after restarting the app, an image that actually failed to upload still shows as mid-send, spinner and all, instead of surfacing as failed.

dig into the client send path and fix it so messages stay in order when a send fails and a failed send actually surfaces and behaves the way it should. this is all client-side send-queue and error-handling; no server or protocol changes.
