#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier runs (set -euo pipefail inherited).
# This task's agent phase is offline (agent_offline=true); the image baked the full
# dependency closure at the base commit (cargo fetch --locked + cargo test --no-run
# for the workspace with the `testing` feature). The verifier compiles and runs a
# Rust integration test against that warm cache, so there is nothing to install here
# — only bring the toolchain/cache online offline-first and fail fast on a cache miss
# rather than reaching for crates.io.
cd /repo/matrix-rust-sdk

# Force cargo to resolve everything from the warmed CARGO_HOME; a miss must fail loud,
# not silently hit the network. The smoke gate sources this inside `docker run
# --network none`, so this MUST succeed with no connectivity.
export CARGO_NET_OFFLINE=true

# Dependencies: offline-first against the image bake, logged online fallback.
# `cargo fetch --locked` is a no-op when the registry/git cache is warm (the image
# ran it at build time); if the bake were ever stale, retry online.
if cargo fetch --locked --offline > /tmp/test-setup-fetch.log 2>&1; then
    echo "[offline-first] cargo deps satisfied from image cache"
elif cargo fetch --locked >> /tmp/test-setup-fetch.log 2>&1; then
    echo "[test-setup] cargo deps fetched online (image bake was stale)"
else
    tail -40 /tmp/test-setup-fetch.log >&2; exit 1
fi

# No services to start and no data to seed: the send-queue tests drive an in-process
# MatrixMockServer (wiremock) that the verifier test spins up itself. No assertion
# logic belongs here.
