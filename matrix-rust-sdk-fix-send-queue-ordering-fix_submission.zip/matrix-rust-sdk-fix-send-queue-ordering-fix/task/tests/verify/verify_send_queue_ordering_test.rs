//! Behavioral verifier for the per-room send-queue ordering + error-classification
//! behavior. Self-contained integration test copied into
//! `crates/matrix-sdk/tests/` by the rust runner.
//!
//! WHY THIS SHAPE (decoupling rationale):
//!
//! Everything here drives the PRE-EXISTING public send-queue API under the
//! `testing` feature — the same surface the crate's own send-queue integration
//! suite uses:
//!   * `Room::send_queue()` / `RoomSendQueue::{send, send_attachment, subscribe,
//!     set_enabled, is_enabled}`
//!   * `SendHandle::abort`
//!   * `Client::send_queue().subscribe()` watch stream of `RoomSendQueueUpdate`
//!   * `LocalEcho` / `LocalEchoContent::Event { send_error, .. }`
//!   * `MatrixMockServer` (test_utils::mocks) to drive server responses.
//!
//! No internal symbol the fix might restructure is referenced: the next-request
//! selection, the status-code classifier, the wakeup-notifier, and the local-echo
//! error-propagation are all observed through the update stream and the reloaded
//! local echoes, never named. The triggering status codes (413 unrecoverable,
//! 520 transient) are injected at the HTTP layer via the mock server, so the
//! classification is exercised end-to-end rather than through any private fn.
//!
//! The `assert_update!` matcher below is a local copy over public update types
//! (the repo's own copy is file-local to the stock suite and not exported); it
//! only pattern-matches on the public `RoomSendQueueUpdate` / `LocalEcho` shapes.

#![cfg(not(target_family = "wasm"))]
// The crate's own lib sets this; an integration-test binary is its own crate, so
// it must re-declare it or deep async-future layout computation overflows.
#![recursion_limit = "256"]

use std::{ops::Not as _, time::Duration};

use assert_matches2::{assert_let, assert_matches};
use matrix_sdk::{
    attachment::{AttachmentConfig, AttachmentInfo, BaseImageInfo},
    send_queue::{
        LocalEcho, LocalEchoContent, RoomSendQueue, RoomSendQueueUpdate, SendHandle,
        SendQueueUpdate,
    },
    test_utils::mocks::MatrixMockServer,
};
use matrix_sdk_test::async_test;
use ruma::{
    event_id,
    events::{
        AnyMessageLikeEventContent,
        room::{
            MediaSource,
            message::{MessageType, RoomMessageEventContent},
        },
    },
    mxc_uri, room_id, uint,
};
use serde_json::json;
use tokio::time::timeout;
use wiremock::ResponseTemplate;

// A matcher over a stream of `RoomSendQueueUpdate`s, mirroring the public update
// shapes. Only the arms the cases below use are needed; each matches public
// variants exclusively.
macro_rules! assert_update {
    // Next update is a local echo for an event. Returns (txn, send_handle, room_message).
    (($global_watch:ident, $watch:ident) => local echo event) => {{
        assert_let!(
            Ok(Ok(RoomSendQueueUpdate::NewLocalEvent(LocalEcho {
                content: LocalEchoContent::Event {
                    serialized_event,
                    send_handle,
                    send_error: None,
                },
                transaction_id: txn,
            }))) = timeout(Duration::from_secs(2), $watch.recv()).await
        );
        assert_matches!(
            $global_watch.recv().await,
            Ok(SendQueueUpdate { update: RoomSendQueueUpdate::NewLocalEvent(_), .. })
        );

        let content = serialized_event.deserialize().unwrap();
        assert_let!(AnyMessageLikeEventContent::RoomMessage(room_message) = content);

        (txn, send_handle, room_message)
    }};

    // Next update is a local echo for a message with content $body. Returns (txn, send_handle).
    (($global_watch:ident, $watch:ident) => local echo { body = $body:expr }) => {{
        let (txn, send_handle, room_message) =
            assert_update!(($global_watch, $watch) => local echo event);
        assert_eq!(room_message.body(), $body);
        (txn, send_handle)
    }};

    // Next update is a media-upload notification carrying the final file source.
    (($global_watch:ident, $watch:ident) => uploaded { related_to = $related_to:expr }) => {{
        assert_let!(
            Ok(Ok(RoomSendQueueUpdate::MediaUpload { related_to, file, .. })) =
                timeout(Duration::from_secs(5), $watch.recv()).await
        );
        assert_eq!(related_to, $related_to);
        assert_let!(Some(MediaSource::Plain(_)) = file);
    }};

    // Next update is an edit (replaced content) for the given txn.
    (($global_watch:ident, $watch:ident) => edit local echo { txn = $transaction_id:expr }) => {{
        assert_let!(
            Ok(Ok(RoomSendQueueUpdate::ReplacedLocalEvent { transaction_id: txn, .. })) =
                timeout(Duration::from_secs(5), $watch.recv()).await
        );
        assert_matches!(
            $global_watch.recv().await,
            Ok(SendQueueUpdate { update: RoomSendQueueUpdate::ReplacedLocalEvent { .. }, .. })
        );
        assert_eq!(txn, $transaction_id);
    }};

    // Next update is a sent event, with optional txn / event_id assertions.
    (($global_watch:ident, $watch:ident) => sent { $(txn=$txn:expr,)? $(event_id=$event_id:expr)? }) => {
        assert_let!(
            Ok(Ok(RoomSendQueueUpdate::SentEvent { event_id: _event_id, transaction_id: _txn })) =
                timeout(Duration::from_secs(5), $watch.recv()).await
        );
        assert_matches!(
            $global_watch.recv().await,
            Ok(SendQueueUpdate { update: RoomSendQueueUpdate::SentEvent { .. }, .. })
        );
        $(assert_eq!(_event_id, $event_id);)?
        $(assert_eq!(_txn, $txn);)?
    };

    // Next update is a send error, with optional recoverable / txn assertions. Returns the error.
    (($global_watch:ident, $watch:ident) => error { $(recoverable=$recoverable:expr,)? $(txn=$txn:expr)? }) => {{
        assert_let!(
            Ok(Ok(RoomSendQueueUpdate::SendError {
                transaction_id: _txn,
                error,
                is_recoverable: _is_recoverable,
            })) = timeout(Duration::from_secs(10), $watch.recv()).await
        );
        assert_matches!(
            $global_watch.recv().await,
            Ok(SendQueueUpdate { update: RoomSendQueueUpdate::SendError { .. }, .. })
        );
        $(assert_eq!(_txn, $txn);)?
        $(assert_eq!(_is_recoverable, $recoverable);)?
        error
    }};

    // Next update is a cancelled local echo for the given txn.
    (($global_watch:ident, $watch:ident) => cancelled { txn = $txn:expr }) => {{
        assert_let!(
            Ok(Ok(RoomSendQueueUpdate::CancelledLocalEvent { transaction_id: txn })) =
                timeout(Duration::from_secs(10), $watch.recv()).await
        );
        assert_matches!(
            $global_watch.recv().await,
            Ok(SendQueueUpdate { update: RoomSendQueueUpdate::CancelledLocalEvent { .. }, .. })
        );
        assert_eq!(txn, $txn);
    }};
}

/// REGRESSION GUARD (passes on both the unfixed and fixed code): a queue with no
/// stuck request still sends its messages in the order they were queued. The fix
/// must not disturb ordinary, non-stuck sending.
#[async_test]
async fn test_preserved_non_wedged_queue_sends_in_order() {
    let mock = MatrixMockServer::new().await;

    let room_id = room_id!("!a:b.c");
    let client = mock.client_builder().build().await;
    let room = mock.sync_joined_room(&client, room_id).await;

    client.send_queue().set_enabled(true).await;

    let q = room.send_queue();
    let mut global_watch = client.send_queue().subscribe();
    let (local_echoes, mut watch) = q.subscribe().await.unwrap();
    assert!(local_echoes.is_empty());

    mock.mock_room_state_encryption().plain().mount().await;
    // Both sends succeed; the second mock is matched after the first by wiremock
    // ordering of equal-priority mounts, so the two events are sent in queue order.
    mock.mock_room_send().ok(event_id!("$1")).mock_once().mount().await;
    mock.mock_room_send().ok(event_id!("$2")).mock_once().mount().await;

    q.send(RoomMessageEventContent::text_plain("first").into()).await.unwrap();
    q.send(RoomMessageEventContent::text_plain("second").into()).await.unwrap();

    let (txn1, _) = assert_update!((global_watch, watch) => local echo { body = "first" });
    let (txn2, _) = assert_update!((global_watch, watch) => local echo { body = "second" });

    // Sent in queue order: first-queued is sent first.
    assert_update!((global_watch, watch) => sent { txn = txn1, });
    assert_update!((global_watch, watch) => sent { txn = txn2, });
}

/// Queue a small image attachment (no thumbnail). Returns (handle, filename).
async fn queue_attachment(q: &RoomSendQueue) -> (SendHandle, &'static str) {
    let filename = "surprise.jpeg.exe";
    let content_type = mime::IMAGE_JPEG;
    let data = b"hello world".to_vec();
    let config = AttachmentConfig::new().info(AttachmentInfo::Image(BaseImageInfo {
        height: Some(uint!(13)),
        width: Some(uint!(37)),
        size: Some(uint!(42)),
        ..Default::default()
    }));
    let handle = q
        .send_attachment(filename, content_type, data, config)
        .await
        .expect("queuing the attachment works");
    (handle, filename)
}

/// Assert that no further send-queue update arrives within `millis` — i.e. the
/// queue is quiescent (blocked), nothing queued behind the stuck head is being
/// sent or erroring.
async fn assert_quiescent(
    watch: &mut tokio::sync::broadcast::Receiver<RoomSendQueueUpdate>,
    millis: u64,
) {
    match timeout(Duration::from_millis(millis), watch.recv()).await {
        Err(_) => { /* timed out: no update, as required */ }
        Ok(update) => {
            panic!(
                "expected the queue to make no progress while the head is stuck, \
                 but observed an update: {update:?}"
            );
        }
    }
}

/// A stuck request at the head of a room's queue blocks the requests queued
/// behind it in the same room (head-of-line blocking): nothing queued later is
/// sent while the head stays stuck.
#[async_test]
async fn test_hol_blocking_wedged_head_blocks_followers() {
    let mock = MatrixMockServer::new().await;

    let room_id = room_id!("!a:b.c");
    let client = mock.client_builder().build().await;
    let room = mock.sync_joined_room(&client, room_id).await;

    client.send_queue().set_enabled(true).await;

    let q = room.send_queue();
    let mut global_watch = client.send_queue().subscribe();
    let (local_echoes, mut watch) = q.subscribe().await.unwrap();
    assert!(local_echoes.is_empty());

    mock.mock_room_state_encryption().plain().mount().await;

    // Only the FAIL mock for the first message is mounted. The second message's
    // success mock is deliberately NOT mounted, so if the queue wrongly sent it
    // past the stuck head it would hit an unmocked endpoint and surface loudly.
    mock.mock_room_send().error_too_large().mock_once().mount().await;

    // Queue two messages, A then B.
    let _handle_a =
        q.send(RoomMessageEventContent::text_plain("i'm too big for ya").into()).await.unwrap();
    q.send(RoomMessageEventContent::text_plain("aloha").into()).await.unwrap();

    let (txn_a, _) =
        assert_update!((global_watch, watch) => local echo { body = "i'm too big for ya" });
    let (_txn_b, _) = assert_update!((global_watch, watch) => local echo { body = "aloha" });

    // A fails unrecoverably and gets stuck; the room queue disables itself.
    assert_update!((global_watch, watch) => error { recoverable = false, txn = txn_a });
    assert!(q.is_enabled().not());

    // Re-enable and give the background task ample opportunity to pick a request.
    q.set_enabled(true);

    // B must NOT be sent while A is stuck at the head: the queue stays quiescent.
    assert_quiescent(&mut watch, 1500).await;
    assert!(watch.is_empty());
}

/// Once the stuck head is removed (abort), the queue resumes in order: the
/// removal wakes the sending task and the next request is then sent.
#[async_test]
async fn test_queue_resumes_after_wedged_head_is_aborted() {
    let mock = MatrixMockServer::new().await;

    let room_id = room_id!("!a:b.c");
    let client = mock.client_builder().build().await;
    let room = mock.sync_joined_room(&client, room_id).await;

    client.send_queue().set_enabled(true).await;

    let q = room.send_queue();
    let mut global_watch = client.send_queue().subscribe();
    let (local_echoes, mut watch) = q.subscribe().await.unwrap();
    assert!(local_echoes.is_empty());

    mock.mock_room_state_encryption().plain().mount().await;
    mock.mock_room_send().error_too_large().mock_once().mount().await;

    let handle_a =
        q.send(RoomMessageEventContent::text_plain("i'm too big for ya").into()).await.unwrap();
    q.send(RoomMessageEventContent::text_plain("aloha").into()).await.unwrap();

    let (txn_a, _) =
        assert_update!((global_watch, watch) => local echo { body = "i'm too big for ya" });
    let (txn_b, _) = assert_update!((global_watch, watch) => local echo { body = "aloha" });

    assert_update!((global_watch, watch) => error { recoverable = false, txn = txn_a });
    assert!(q.is_enabled().not());

    // Re-enable with the stuck head A still at the front. Nothing may be sent while
    // it stays there. B's success mock is deliberately NOT mounted yet, so if the
    // queue wrongly skipped past the stuck head to send B it would hit an unmocked
    // endpoint and surface loudly, breaking quiescence.
    q.set_enabled(true);
    assert_quiescent(&mut watch, 1500).await;

    // Now mount B's success mock and remove the stuck head. Removing it must wake
    // the sending task so the queue resumes and B — unblocked only now — is sent.
    mock.mock_room_send().ok(event_id!("$42")).mock_once().mount().await;
    assert!(handle_a.abort().await.unwrap());
    assert_update!((global_watch, watch) => cancelled { txn = txn_a });
    assert_update!((global_watch, watch) => sent { txn = txn_b, event_id = event_id!("$42") });
}

/// Head-of-line blocking is unconditional across priority classes: a stuck
/// high-priority request still blocks a lower-priority request queued behind it.
///
/// Reproduces the promoted-media-event scenario: a media upload (queued at the
/// default/low priority) succeeds and the media *event* is then re-queued at
/// high priority; the media event's own send then fails unrecoverably and gets
/// stuck at the head. A plain text message queued behind it (low priority) must
/// NOT overtake it. This rejects any scheme that only blocks within a single
/// priority class.
#[async_test]
async fn test_hol_blocking_holds_across_priority_classes() {
    let mock = MatrixMockServer::new().await;

    let room_id = room_id!("!a:b.c");
    let client = mock.client_builder().build().await;
    let room = mock.sync_joined_room(&client, room_id).await;

    client.send_queue().set_enabled(true).await;

    let q = room.send_queue();
    let mut global_watch = client.send_queue().subscribe();
    let (local_echoes, mut watch) = q.subscribe().await.unwrap();
    assert!(local_echoes.is_empty());

    mock.mock_authenticated_media_config().ok_default().mount().await;
    mock.mock_room_state_encryption().plain().mount().await;

    // The media upload itself succeeds, so the media event gets re-queued (at high
    // priority) and is then attempted as a room send...
    mock.mock_upload().ok(mxc_uri!("mxc://sdk.rs/media")).mock_once().mount().await;
    // ...where it fails unrecoverably and gets stuck at the head of the queue. The
    // text message's success mock is deliberately NOT mounted.
    mock.mock_room_send().error_too_large().mock_once().mount().await;

    // Queue the media first, then a plain text message behind it.
    let (_handle, filename) = queue_attachment(&q).await;
    q.send(RoomMessageEventContent::text_plain("behind the media").into()).await.unwrap();

    // Local echoes: media event, then the text behind it.
    let (media_txn, _send_handle, content) =
        assert_update!((global_watch, watch) => local echo event);
    assert_let!(MessageType::Image(img) = content.msgtype);
    assert_eq!(img.body, filename);
    let (_text_txn, _) = assert_update!((global_watch, watch) => local echo { body = "behind the media" });

    // The upload succeeds and the media event is finalized (edited with the mxc),
    // then re-queued at high priority and attempted as a send.
    assert_update!((global_watch, watch) => uploaded { related_to = media_txn });
    assert_update!((global_watch, watch) => edit local echo { txn = media_txn });

    // The high-priority media event's send fails unrecoverably: it is now the
    // stuck head.
    assert_update!((global_watch, watch) => error { recoverable = false, txn = media_txn });
    assert!(q.is_enabled().not());

    // Re-enable and let the task run. The low-priority text must NOT overtake the
    // stuck high-priority media event: the queue stays quiescent.
    q.set_enabled(true);
    assert_quiescent(&mut watch, 1500).await;
    assert!(watch.is_empty());
}

/// An HTTP 520 response is treated as a transient/recoverable error (kept in the
/// queue and retried), not a permanent one that gets stuck forever.
#[async_test]
async fn test_http_520_is_recoverable_and_retried_in_order() {
    let mock = MatrixMockServer::new().await;

    let room_id = room_id!("!a:b.c");
    let client = mock.client_builder().build().await;
    let room = mock.sync_joined_room(&client, room_id).await;

    client.send_queue().set_enabled(true).await;

    let q = room.send_queue();
    let mut global_watch = client.send_queue().subscribe();
    let (local_echoes, mut watch) = q.subscribe().await.unwrap();
    assert!(local_echoes.is_empty());

    mock.mock_room_state_encryption().plain().mount().await;

    // Respond to the send with a 520 (non-standard proxy "unknown error"). Mounted
    // at default priority with no call cap, so it answers every in-request retry.
    mock.mock_room_send()
        .respond_with(ResponseTemplate::new(520).set_body_json(json!({})))
        .mount()
        .await;

    q.send(RoomMessageEventContent::text_plain("momentary blip").into()).await.unwrap();
    let (txn, _) = assert_update!((global_watch, watch) => local echo { body = "momentary blip" });

    // The 520 must be surfaced as RECOVERABLE (transient): the queue disables
    // itself but keeps the request, rather than marking it permanently stuck.
    let error = assert_update!((global_watch, watch) => error { recoverable = true, txn = txn });
    let api_error = error.as_client_api_error().expect("a client API error");
    assert_eq!(api_error.status_code, 520);
    assert!(q.is_enabled().not());

    // The request stays in the queue; on re-enable it retries and is sent, in
    // order. The success mock is mounted at a higher priority so it wins once the
    // queue is resumed.
    mock.mock_room_send().ok(event_id!("$1")).mock_once().with_priority(1).mount().await;
    q.set_enabled(true);
    assert_update!((global_watch, watch) => sent { txn = txn, event_id = event_id!("$1") });
}

/// A stuck media upload's send error is reflected on the media event's local
/// echo after reloading local echoes, instead of the echo claiming the media is
/// still being sent.
#[async_test]
async fn test_wedged_media_upload_error_surfaces_on_local_echo() {
    let mock = MatrixMockServer::new().await;

    let room_id = room_id!("!a:b.c");
    let client = mock.client_builder().build().await;
    let room = mock.sync_joined_room(&client, room_id).await;

    client.send_queue().set_enabled(true).await;

    let q = room.send_queue();
    let mut global_watch = client.send_queue().subscribe();
    let (local_echoes, mut watch) = q.subscribe().await.unwrap();
    assert!(local_echoes.is_empty());

    mock.mock_authenticated_media_config().ok_default().mount().await;
    mock.mock_room_state_encryption().plain().mount().await;

    // The upload fails unrecoverably (too large, 413), getting stuck.
    mock.mock_upload().error_too_large().mock_once().mount().await;

    let (_handle, filename) = queue_attachment(&q).await;

    let (event_txn, _send_handle, content) =
        assert_update!((global_watch, watch) => local echo event);
    assert_let!(MessageType::Image(img) = content.msgtype);
    assert_eq!(img.body, filename);

    // Although the failure happens on the file-upload request, it must be reported
    // against the media *event*.
    let error = assert_update!((global_watch, watch) => error { recoverable = false, txn = event_txn });
    assert_eq!(error.as_client_api_error().expect("a client API error").status_code, 413);
    assert!(q.is_enabled().not());

    // Reloading the local echoes (as a restarting client would) must show the
    // media event carrying the upload's send error — not as still being sent.
    let (local_echoes, _watch) = q.subscribe().await.unwrap();
    assert_eq!(local_echoes.len(), 1);
    assert_let!(LocalEchoContent::Event { send_error, .. } = &local_echoes[0].content);
    assert!(send_error.is_some());
}
