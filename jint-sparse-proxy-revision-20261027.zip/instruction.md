## Task

Please sort out Jint’s array performance and compatibility problems. Repeated `for...in` loops, reads of empty positions and `in` checks still allocate megabytes after warmup. We need these workloads down to kilobytes without a slowdown. Cover packed arrays, arrays with gaps, and large sparse arrays with only a few hundred values. Repeated enumeration of those sparse arrays needs to be practical too.

We’re also seeing incorrect key lists and inherited reads when applications customize an array’s prototype chain, including with proxies. Fix those compatibility issues as part of this work. Indexed access, `Reflect.get` and array methods should behave like JavaScript, including when user code changes the array or throws during an operation.

Please preserve normal key order and property behavior across edits and nested loops. Existing elements, accessors and revoked proxies should keep their usual JavaScript behavior. The optimizations must not change what the script observes.
