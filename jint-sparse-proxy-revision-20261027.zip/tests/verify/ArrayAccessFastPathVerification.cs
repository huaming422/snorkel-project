namespace Jint.Tests.Runtime;

/// <summary>
/// Independent verification of the two array access patterns: enumerating an array with
/// <c>for (k in arr)</c>, and reading / membership-testing absent (hole) indices. Both must stay
/// allocation-light once the engine is warm, while preserving every observable enumeration and
/// read semantic. Everything is exercised through the stable public <c>Jint.Engine.Evaluate</c>
/// surface — no engine internals are referenced, so any correct implementation passes regardless of
/// how it proves the receiver/chain is clean or how it names its helpers.
///
/// The allocation bounds reuse the repository's own deterministic technique
/// (<c>GC.GetAllocatedBytesForCurrentThread()</c> around a warm prepared evaluation, under
/// <c>#if NET</c>) seen in <c>SlotLocationCacheTests</c>. The workloads mirror the per-operation
/// cost that the clean cases ("a kilobyte or two") should never exceed: pre-fix these allocate
/// megabytes per evaluation, so the generous sub-200 KB bound separates a real fix from an
/// unchanged tree by two to three orders of magnitude while leaving ample headroom for any correct
/// implementation.
/// </summary>
public class ArrayAccessFastPathVerification
{
    private static string EvalString(string source) => new Engine().Evaluate(source).AsString();

    private static double EvalNumber(string source) => new Engine().Evaluate(source).AsNumber();

    // -----------------------------------------------------------------------------------------
    // Performance contract — allocation-bounded. A warm evaluation that repeats the access pattern
    // many times must allocate far below the bound. These fail hard on an unchanged tree
    // (megabytes) and on any "fix" that leaves either surface materializing per operation.
    // -----------------------------------------------------------------------------------------

#if NET
    [Fact]
    public void ForInOverDenseArrayStaysAllocationLight()
    {
        var engine = new Engine();
        engine.Execute("var denseArr = []; for (var i = 0; i < 1000; i++) { denseArr[i] = i; }");
        var prepared = Engine.PrepareScript("""
            function f() {
                var s = 0;
                for (var i = 0; i < 200; i++) {
                    for (var k in denseArr) { s++; }
                }
                return s;
            }
            f();
            """);

        // the enumeration must actually run (and visit every dense index) — a degenerate "skip it"
        // fix cannot pass the allocation bound by doing nothing.
        Assert.Equal(200000, engine.Evaluate(prepared).AsNumber());
        for (var e = 0; e < 5; e++) { engine.Evaluate(prepared); }

        var before = GC.GetAllocatedBytesForCurrentThread();
        engine.Evaluate(prepared);
        var perEvaluation = GC.GetAllocatedBytesForCurrentThread() - before;

        Assert.True(
            perEvaluation < 200_000,
            $"for-in over a warm dense array should not allocate per enumeration; allocated {perEvaluation} bytes across 200 enumerations of a 1000-element array");
    }

    [Fact]
    public void ForInOverHoleyArrayStaysAllocationLight()
    {
        var engine = new Engine();
        engine.Execute("var holeyArr = []; for (var i = 0; i < 1000; i += 4) { holeyArr[i] = i; }");
        var prepared = Engine.PrepareScript("""
            function f() {
                var s = 0;
                for (var i = 0; i < 200; i++) {
                    for (var k in holeyArr) { s++; }
                }
                return s;
            }
            f();
            """);

        // 250 present indices (every 4th of 1000), 200 enumerations — holes skipped, no key-list blowup.
        Assert.Equal(50000, engine.Evaluate(prepared).AsNumber());
        for (var e = 0; e < 5; e++) { engine.Evaluate(prepared); }

        var before = GC.GetAllocatedBytesForCurrentThread();
        engine.Evaluate(prepared);
        var perEvaluation = GC.GetAllocatedBytesForCurrentThread() - before;

        Assert.True(
            perEvaluation < 200_000,
            $"for-in over a warm holey array should not allocate per enumeration; allocated {perEvaluation} bytes across 200 enumerations");
    }

    [Fact]
    public void HoleReadTraversalStaysAllocationLight()
    {
        var engine = new Engine();
        engine.Execute("""
            var dense = [];
            var holey = [];
            for (var i = 0; i < 8000; i++) { dense[i] = i; }
            for (var i = 0; i < 8000; i += 4) { holey[i] = i; }
            holey[7999] = 7999;
            """);
        var prepared = Engine.PrepareScript("""
            function f() {
                var s = 0;
                for (var n = 0; n < 20; n++) {
                    for (var i = 0; i < 8000; i++) { s += holey[i] | 0; }
                }
                return s;
            }
            f();
            """);

        // reading a hole yields undefined (|0 => 0); present values sum to a fixed total each pass.
        // Asserting the exact sum also pins that hole reads return the correct value, not garbage.
        Assert.Equal(160079980, engine.Evaluate(prepared).AsNumber());
        for (var e = 0; e < 5; e++) { engine.Evaluate(prepared); }

        var before = GC.GetAllocatedBytesForCurrentThread();
        engine.Evaluate(prepared);
        var perEvaluation = GC.GetAllocatedBytesForCurrentThread() - before;

        Assert.True(
            perEvaluation < 200_000,
            $"reading holes on a warm holey array should not allocate per read; allocated {perEvaluation} bytes across 160,000 index reads");
    }

    [Fact]
    public void InOperatorOverHoleyArrayStaysAllocationLight()
    {
        var engine = new Engine();
        engine.Execute("""
            var holey = [];
            for (var i = 0; i < 8000; i += 4) { holey[i] = i; }
            holey[7999] = 7999;
            """);
        var prepared = Engine.PrepareScript("""
            function f() {
                var s = 0;
                for (var n = 0; n < 20; n++) {
                    for (var i = 0; i < 8000; i++) { if (i in holey) { s++; } }
                }
                return s;
            }
            f();
            """);

        // 2001 present indices (0,4,..,7996 plus 7999) over 20 passes — the `in` probe must not
        // walk/allocate for the 75% that are holes.
        Assert.Equal(40020, engine.Evaluate(prepared).AsNumber());
        for (var e = 0; e < 5; e++) { engine.Evaluate(prepared); }

        var before = GC.GetAllocatedBytesForCurrentThread();
        engine.Evaluate(prepared);
        var perEvaluation = GC.GetAllocatedBytesForCurrentThread() - before;

        Assert.True(
            perEvaluation < 200_000,
            $"`index in arr` over a warm holey array should not allocate per probe; allocated {perEvaluation} bytes across 160,000 membership tests");
    }
#endif

    // -----------------------------------------------------------------------------------------
    // Correctness — the fast path must stay off wherever it is not provably safe. These assert
    // concrete key sequences / values through Engine.Evaluate. The inherited-prototype-index cases
    // fail on an unchanged tree (a real pre-existing enumeration bug the change also repairs); the
    // rest guard against a fast path that engages when it must not (shadowed holes, custom chains,
    // exotic descriptors) or that breaks snapshot/mutation semantics.
    // -----------------------------------------------------------------------------------------

    [Fact]
    public void ForInEnumeratesInheritedEnumerableArrayPrototypeIndex()
    {
        // Array.prototype is itself array-backed; a script-placed index on it is an own enumerable
        // key of the chain. for-in must enumerate the inherited '5' after the own indices, and the
        // own '1' must shadow the inherited '1'. (Fails on the unchanged tree.)
        var result = EvalString("""
            Array.prototype[5] = 'inherited';
            Array.prototype[1] = 'shadowed';
            var arr = [10, 20];
            var out = [];
            for (var k in arr) { out.push(k); }
            out.join(',');
            """);

        Assert.Equal("0,1,5", result);
    }

    [Fact]
    public void ForInEnumeratesEnumerablePropertyOnObjectPrototype()
    {
        var result = EvalString("""
            Object.prototype.zzz = 1;
            var arr = [10, 20];
            var out = [];
            for (var k in arr) { out.push(k); }
            out.join(',');
            """);

        Assert.Equal("0,1,zzz", result);
    }

    [Fact]
    public void HoleReadWalksChainWhenPrototypeGainsIndex()
    {
        // The pristine-prototype shortcut must disengage the instant Array.prototype / Object.prototype
        // gains an index property: hole reads and `in` then observe the inherited values.
        var result = EvalString("""
            var a = [1, , 3];
            var before = [a[1], 1 in a, a[10], 10 in a];
            Array.prototype[1] = 'ap';
            Object.prototype[10] = 'op';
            var after = [a[1], 1 in a, a[10], 10 in a];
            JSON.stringify([before, after]);
            """);

        Assert.Equal("[[null,false,null,false],[\"ap\",true,\"op\",true]]", result);
    }

    [Fact]
    public void HoleReadHonorsOwnIndexGetter()
    {
        // an exotic own accessor descriptor clears the fast-access invariant on the instance.
        var result = EvalString("""
            var a = [1, 2, 3];
            Object.defineProperty(a, '5', { get: function () { return 'got'; } });
            [a[5], 5 in a, a[7] === undefined].join(',');
            """);

        Assert.Equal("got,true,true", result);
    }

    [Fact]
    public void HoleReadWalksCustomPrototypeChain()
    {
        var result = EvalString("""
            var proto = { 1: 'inherited' };
            var a = [0];
            a.length = 3;
            Object.setPrototypeOf(a, proto);
            [a[1], 1 in a, a[2] === undefined, 2 in a].join(',');
            """);

        Assert.Equal("inherited,true,true,false", result);
    }

    [Fact]
    public void ForInOverDenseArrayYieldsAscendingStringIndices()
    {
        var result = EvalString("""
            var arr = [10, 20, 30, 40];
            var out = [];
            for (var k in arr) { out.push(typeof k + ':' + k); }
            out.join(',');
            """);

        Assert.Equal("string:0,string:1,string:2,string:3", result);
    }

    [Fact]
    public void ForInOverHoleyArraySkipsHoles()
    {
        var result = EvalString("""
            var arr = [];
            arr[0] = 'a'; arr[3] = 'b'; arr[7] = 'c';
            var out = [];
            for (var k in arr) { out.push(k); }
            out.join(',');
            """);

        Assert.Equal("0,3,7", result);
    }

    [Fact]
    public void ForInOverEmptyArrayWithLargeLengthYieldsNothing()
    {
        var result = EvalNumber("""
            var arr = [];
            arr.length = 100000;
            var n = 0;
            for (var k in arr) { n++; }
            n;
            """);

        Assert.Equal(0, result);
    }

    [Fact]
    public void ForInDeleteDuringIterationSkipsNotYetVisitedIndex()
    {
        var result = EvalString("""
            var arr = [10, 20, 30, 40];
            var out = [];
            for (var k in arr) { out.push(k); if (k === '0') { delete arr[2]; } }
            out.join(',');
            """);

        Assert.Equal("0,1,3", result);
    }

    [Fact]
    public void ForInPushDuringIterationDoesNotVisitNewIndex()
    {
        var result = EvalString("""
            var arr = [10, 20];
            var out = [];
            for (var k in arr) { out.push(k); arr.push(99); }
            out.join(',');
            """);

        Assert.Equal("0,1", result);
    }

    [Fact]
    public void ForInLengthTruncationDuringIterationSkipsRemovedIndices()
    {
        var result = EvalString("""
            var arr = [10, 20, 30, 40, 50];
            var out = [];
            for (var k in arr) { out.push(k); if (k === '1') { arr.length = 3; } }
            out.join(',');
            """);

        Assert.Equal("0,1,2", result);
    }

    [Fact]
    public void ForInNonEnumerableIndexIsSkipped()
    {
        var result = EvalString("""
            var arr = [10, 20, 30];
            Object.defineProperty(arr, '1', { value: 20, enumerable: false });
            var out = [];
            for (var k in arr) { out.push(k); }
            out.join(',');
            """);

        Assert.Equal("0,2", result);
    }

    [Fact]
    public void ForInDefinePropertyMidLoopHonorsNewEnumerability()
    {
        var result = EvalString("""
            var arr = [10, 20, 30, 40];
            var out = [];
            for (var k in arr) {
                out.push(k);
                if (k === '0') { Object.defineProperty(arr, '2', { value: 30, enumerable: false }); }
            }
            out.join(',');
            """);

        Assert.Equal("0,1,3", result);
    }

    [Fact]
    public void ForInSparseConversionMidLoopKeepsEnumeratingOriginalIndices()
    {
        var result = EvalString("""
            var arr = [10, 20, 30, 40];
            var out = [];
            for (var k in arr) { out.push(k); if (k === '1') { arr[50000000] = 1; } }
            out.join(',');
            """);

        Assert.Equal("0,1,2,3", result);
    }

    [Fact]
    public void NestedForInOverSameArrayDoNotShareState()
    {
        var result = EvalString("""
            var arr = [1, 2, 3];
            var pairs = [];
            for (var k in arr) { for (var j in arr) { pairs.push(k + j); } }
            pairs.join(',');
            """);

        Assert.Equal("00,01,02,10,11,12,20,21,22", result);
    }

    [Fact]
    public void ForInBreakThenReuseResetsPooledIterator()
    {
        var result = EvalString("""
            var arr = [1, 2, 3, 4];
            var rounds = [];
            for (var r = 0; r < 3; r++) {
                var got = [];
                for (var k in arr) { got.push(k); if (k === '1') break; }
                rounds.push(got.join(''));
            }
            rounds.join(',');
            """);

        Assert.Equal("01,01,01", result);
    }

    [Fact]
    public void InterleavedGeneratorsOverSameArrayDoNotShareState()
    {
        var result = EvalString("""
            var arr = [7, 8, 9];
            function* keys(a) { for (var k in a) { yield k; } }
            var g1 = keys(arr), g2 = keys(arr);
            var seq = [];
            seq.push(g1.next().value);
            seq.push(g2.next().value);
            seq.push(g1.next().value);
            seq.push(g2.next().value);
            seq.push(g1.next().value);
            seq.push(g2.next().value);
            seq.push(g1.next().done);
            seq.join(',');
            """);

        Assert.Equal("0,0,1,1,2,2,true", result);
    }

    [Fact]
    public void ForInOverSubclassInstanceYieldsIndices()
    {
        var result = EvalString("""
            class A extends Array {}
            var a = new A();
            a[0] = 'x'; a[1] = 'y';
            var out = [];
            for (var k in a) { out.push(k); }
            out.join(',');
            """);

        Assert.Equal("0,1", result);
    }

    [Fact]
    public void WarmEnumerationsObserveLaterArrayAndPrototypeChanges()
    {
        var result = EvalString("""
            var a = [10, 20, 30];
            function keys() { var r = []; for (var k in a) r.push(k); return r.join(','); }
            for (var n = 0; n < 8; n++) keys();
            delete a[1]; a[4] = 40;
            var changed = keys();
            Array.prototype[5] = 50;
            var inherited = keys();
            delete Array.prototype[5];
            a.length = 1;
            [changed, inherited, keys()].join('|');
            """);
        Assert.Equal("0,2,4|0,2,4,5|0", result);
    }

    [Fact]
    public void NamedAndSymbolPropertiesDoNotHideEnumerableKeys()
    {
        var result = EvalString("""
            var a = [10, , 30];
            a.extra = 'own'; a[Symbol('hidden')] = 1;
            Object.defineProperty(a, 'secret', { value: 2, enumerable: false });
            Object.defineProperty(Array.prototype, '2', { value: 99, enumerable: true, writable: true });
            var r = []; for (var k in a) r.push(k);
            r.join(',');
            """);
        Assert.Equal("0,2,extra", result);
    }

    [Fact]
    public void InheritedGetterUsesReceiverAndMembershipDoesNotInvokeIt()
    {
        var result = EvalString("""
            var calls = 0;
            var proto = Object.create(Array.prototype);
            Object.defineProperty(proto, '1', { get: function () { calls++; return this.marker; } });
            var a = [0, , 2]; a.marker = 'array'; Object.setPrototypeOf(a, proto);
            var present = 1 in a;
            var afterHas = calls;
            var read = a[1];
            var reflected = Reflect.get(a, '1', { marker: 'receiver' });
            [present, afterHas, read, reflected, calls].join(',');
            """);
        Assert.Equal("true,0,array,receiver,2", result);
    }

    [Fact]
    public void NumericAndStringPropertyKeysKeepTheirMeaning()
    {
        var result = EvalString("""
            var a = ['zero']; a['-0'] = 'minus'; a['01'] = 'leading'; a['1.5'] = 'fraction';
            [Reflect.get(a, -0), Reflect.get(a, '-0'), a['01'], a[1.5], 0 in a, '01' in a].join(',');
            """);
        Assert.Equal("zero,minus,leading,fraction,true,true", result);
    }

    [Fact]
    public void ProxyPrototypeStillProvidesKeysAndIndexedValues()
    {
        var result = EvalString("""
            var ownKeysCalls = 0, hasCalls = 0;
            var proto = new Proxy({ 1: 'inherited', extra: 'named' }, {
                ownKeys: function (t) { ownKeysCalls++; return Reflect.ownKeys(t); },
                has: function (t, k) { hasCalls++; return Reflect.has(t, k); }
            });
            var a = [10]; a.length = 3; Object.setPrototypeOf(a, proto);
            var r = []; for (var k in a) r.push(k);
            var value = a[1]; var present = 1 in a;
            [r.join(','), value, present, ownKeysCalls > 0, hasCalls > 0].join('|');
            """);
        Assert.Equal("0,1,extra|inherited|true|true|true", result);
    }
#if NET
    [Fact]
    public void WidelySeparatedSparseIndicesStayAllocationLight()
    {
        var engine = new Engine();
        engine.Execute("var sparse = []; for (var i = 249; i >= 0; i--) sparse[1000000 + i * 100003] = i;");
        var script = Engine.PrepareScript("function sparseCount() { var count = 0; for (var n = 0; n < 200; n++) for (var k in sparse) count++; return count; } sparseCount();");
        Assert.Equal(50000, engine.Evaluate(script).AsNumber());
        for (var n = 0; n < 5; n++) engine.Evaluate(script);
        var before = GC.GetAllocatedBytesForCurrentThread();
        Assert.Equal(50000, engine.Evaluate(script).AsNumber());
        var allocated = GC.GetAllocatedBytesForCurrentThread() - before;
        Assert.True(allocated < 200_000, $"Sparse enumeration allocated {allocated} bytes");
    }
#endif

    [Fact]
    public void SparseKeysStayOrderedAfterSameCountReplacementAndDescriptorChange()
    {
        Assert.Equal("3,1000000,4000000000|3,2000000,4000000000|2000000,4000000000|2000000,4000000000,extra|2000000", EvalString("""
            var a = []; a[4000000000] = 4; a[3] = 3; a[1000000] = 1;
            function keys() { var r=[]; for(var k in a) r.push(k); return r.join(','); }
            for(var i=0;i<5;i++) keys();
            var r=[keys()]; delete a[1000000]; a[2000000]=2; r.push(keys());
            Object.defineProperty(a,'3',{enumerable:false}); r.push(keys());
            a.extra=1; r.push(keys()); delete a.extra; a.length=3000000; r.push(keys());
            r.join('|');
            """));
    }

    [Fact]
    public void NestedSparseEnumerationsKeepIndependentSnapshots()
    {
        Assert.Equal("1|1,3000000|3000000|1,2000000,3000000", EvalString("""
            var a=[]; a[3000000]=3; a[1]=1; a[1000000]=2;
            function all() { var r=[]; for(var k in a) r.push(k); return r.join(','); }
            all(); var outer=[], inner;
            for(var k in a) {
                outer.push(k);
                if(k==='1') { delete a[1000000]; inner=all(); }
            }
            a[2000000]=2;
            [outer[0],inner,outer.slice(1).join(','),all()].join('|');
            """));
    }

    [Fact]
    public void SparsePrototypeKeysAndNonEnumerableShadowingRemainCorrect()
    {
        Assert.Equal("1000000,4000000000,7,extra", EvalString("""
            var p={7:'inherited',1000000:'shadowed',extra:'name'};
            var a=[]; a[4000000000]=4; a[1000000]=1;
            Object.defineProperty(a,'8',{value:8,enumerable:false}); p[8]='hidden';
            Object.setPrototypeOf(a,p);
            var r=[]; for(var k in a) r.push(k); r.join(',');
            """));
    }

    [Fact]
    public void ProxyGetForArrayHoleUsesOriginalAndReflectReceivers()
    {
        Assert.Equal("array,reflect,virtual,own|1:array,1:reflect,9:array", EvalString("""
            var log=[];
            var p=new Proxy({1:'target'}, {get:function(t,k,r){ log.push(k+':'+r.marker); return k==='9'?'virtual':r.marker; }});
            var a=['own']; a.marker='array'; Object.setPrototypeOf(a,p);
            var values=[a[1],Reflect.get(a,'1',{marker:'reflect'}),a[9],a[0]];
            values.join(',')+'|'+log.join(',');
            """));
    }

    [Fact]
    public void ProxyReadDoesNotInvokeHasAndHasDoesNotInvokeGet()
    {
        Assert.Equal("42,false|get:2,has:2", EvalString("""
            var log=[]; var p=new Proxy({}, {
                get:function(t,k,r){log.push('get:'+k);return 42;},
                has:function(t,k){log.push('has:'+k);return false;}
            });
            var a=[]; Object.setPrototypeOf(a,p);
            var v=a[2], h=2 in a;
            [v,h].join(',')+'|'+log.join(',');
            """));
    }

    [Fact]
    public void ArrayMapObservesProxyHasThenGetWithArrayReceiver()
    {
        Assert.Equal("10,41,|get:constructor:array,has:1,get:1:array,has:2|1,2", EvalString("""
            var log=[], visited=[];
            var p=new Proxy({}, {
                has:function(t,k){log.push('has:'+k);return k==='1';},
                get:function(t,k,r){log.push('get:'+k+':'+r.marker);return k==='constructor'?undefined:40;}
            });
            var a=[10,,]; a.length=3; a.marker='array'; Object.setPrototypeOf(a,p);
            var r=Array.prototype.map.call(a,function(v,i){visited.push(i+1);return v+i;});
            r.join(',')+'|'+log.join(',')+'|'+visited.join(',');
            """));
    }

    [Fact]
    public void ProxyTrapMutationAndExceptionAreNotSuppressed()
    {
        Assert.Equal("first,own,boom|1,2", EvalString("""
            var log=[]; var a=[];
            Object.setPrototypeOf(a,new Proxy({}, {get:function(t,k,r){
                log.push(k); if(k==='2') throw new Error('boom');
                Object.defineProperty(r,'1',{value:'own',writable:true,configurable:true}); return 'first';
            }}));
            var first=a[1], second=a[1], error;
            try{a[2];}catch(e){error=e.message;}
            [first,second,error].join(',')+'|'+log.join(',');
            """));
    }

    [Fact]
    public void RevokedProxyPrototypeThrowsOnlyForInheritedAccess()
    {
        Assert.Equal("before,true,true,own", EvalString("""
            var p=Proxy.revocable({}, {get:function(){return 'before';}});
            var a=['own']; Object.setPrototypeOf(a,p.proxy);
            var before=a[1]; p.revoke(); var read=false,has=false;
            try{a[1];}catch(e){read=e instanceof TypeError;}
            try{1 in a;}catch(e){has=e instanceof TypeError;}
            [before,read,has,a[0]].join(',');
            """));
    }

}
