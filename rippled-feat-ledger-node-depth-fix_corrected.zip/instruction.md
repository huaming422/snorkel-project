## Task

ledger data replies between peers carry full node IDs, and on a busy sync path that adds up to a lot of bytes. i'd like a new peer protocol version with a compact per-node reference, used whenever both ends of a connection speak it, and older peers see no change. this is what i'd expect from relaying once it's in:

```
compact ledger data relayed to an older peer   -> the same full node IDs it gets asking us directly
compact ledger data relayed to a newer peer    -> passed on as it came
a relayed message mixing both forms            -> nothing forwarded
```
