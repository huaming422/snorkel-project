// Overlay unit tests for the negotiated, compact per-node reference used when
// peers exchange ledger tree data.
//
// The suite observes behaviour exclusively through pre-existing, stable
// interfaces:
//
//   * `negotiateProtocolVersion` / `makeProtocol`: the free functions that
//     decide which peer-protocol version two nodes agree on.
//   * `PeerImp::onMessage(TMGetLedger)`: the public reply path, driven through
//     the JobQueue and drained with `rendezvous()`, with the outgoing reply
//     captured by overriding `send()`.
//   * `PeerImp::onMessage(TMLedgerData)`: the public relay path, which runs
//     inline and forwards to the peer named by the request cookie, and the
//     acquisition path that hands a reply with no cookie to the ledger or
//     transaction set being fetched.
//
// The tests never name the compact wire fields. They only read the legacy
// `nodeid` field that exists in every version of the protobuf, and they get
// compact nodes by harvesting them from a real reply rather than building them
// field by field. A node that does not carry the full 33-byte identifier in
// `nodeid` is in the compact form, whatever the implementation called it. One
// relay case changes a harvested leaf before relaying it: its data is given a
// type byte no tree node uses, or, when the leaf's compact reference is a
// single integer field, that field is set past the deepest level of a tree.
// The older peer it goes to then gets either nothing or the full ids of a
// direct reply.

#include <test/jtx/Env.h>

#include <xrpld/app/ledger/InboundLedger.h>
#include <xrpld/app/ledger/InboundLedgers.h>
#include <xrpld/app/ledger/InboundTransactions.h>
#include <xrpld/app/ledger/LedgerMaster.h>
#include <xrpld/app/main/Application.h>
#include <xrpld/overlay/Compression.h>
#include <xrpld/overlay/Message.h>
#include <xrpld/overlay/Peer.h>
#include <xrpld/overlay/detail/OverlayImpl.h>
#include <xrpld/overlay/detail/PeerImp.h>
#include <xrpld/overlay/detail/ProtocolVersion.h>

#include <xrpl/basics/base_uint.h>
#include <xrpl/basics/make_SSLContext.h>
#include <xrpl/config/Constants.h>
#include <xrpl/core/JobQueue.h>
#include <xrpl/beast/net/IPEndpoint.h>
#include <xrpl/beast/unit_test/suite.h>
#include <xrpl/protocol/KeyType.h>
#include <xrpl/protocol/PublicKey.h>
#include <xrpl/protocol/Indexes.h>
#include <xrpl/protocol/SecretKey.h>
#include <xrpl/protocol/Serializer.h>
#include <xrpl/shamap/SHAMap.h>
#include <xrpl/shamap/SHAMapItem.h>
#include <xrpl/shamap/SHAMapNodeID.h>
#include <xrpl/shamap/SHAMapTreeNode.h>

#include <boost/asio/ip/address.hpp>
#include <boost/beast/core/tcp_stream.hpp>
#include <boost/beast/ssl/ssl_stream.hpp>

#include <google/protobuf/descriptor.h>
#include <google/protobuf/message.h>

#include <xrpl.pb.h>

#include <algorithm>
#include <cstdint>
#include <exception>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace xrpl::test {

using namespace jtx;

class LedgerNodeDepth_test : public beast::unit_test::Suite
{
    using middle_type = boost::beast::tcp_stream;
    using stream_type = boost::beast::ssl_stream<middle_type>;
    using socket_type = boost::asio::ip::tcp::socket;
    using shared_context = std::shared_ptr<boost::asio::ssl::context>;

    // A peer whose outgoing messages are captured instead of being written to a
    // socket, so a test can inspect exactly what this peer would have sent.
    class PeerTest : public PeerImp
    {
    public:
        PeerTest(
            Application& app,
            std::shared_ptr<PeerFinder::Slot> const& slot,
            http_request_type&& request,
            PublicKey const& publicKey,
            ProtocolVersion protocol,
            Resource::Consumer consumer,
            std::unique_ptr<LedgerNodeDepth_test::stream_type>&& streamPtr,
            OverlayImpl& overlay)
            : PeerImp(
                  app,
                  nextId_++,
                  slot,
                  std::move(request),
                  publicKey,
                  protocol,
                  consumer,
                  std::move(streamPtr),
                  overlay)
        {
        }

        ~PeerTest() override = default;

        void
        run() override
        {
        }

        void
        send(std::shared_ptr<Message> const& m) override
        {
            lastSentMessage_ = m;
        }

        std::shared_ptr<Message>
        getLastSentMessage() const
        {
            return lastSentMessage_;
        }

        void
        clearLastSentMessage()
        {
            lastSentMessage_.reset();
        }

        static void
        resetId()
        {
            nextId_ = 0;
        }

    private:
        inline static Peer::id_t nextId_ = 0;
        std::shared_ptr<Message> lastSentMessage_;
    };

    shared_context context_{makeSslContext("")};

    // Each peer needs a distinct remote endpoint: the slot table rejects a
    // duplicate remote address (returning a null slot), so sharing one address
    // across several peers would hand the peer constructor a null slot. A
    // per-call counter varies the remote address so every peer in a test gets
    // its own slot.
    int nextRemote_ = 2;

    std::shared_ptr<PeerTest>
    createPeer(jtx::Env& env, ProtocolVersion protocol)
    {
        auto& overlay = dynamic_cast<OverlayImpl&>(env.app().getOverlay());
        boost::beast::http::request<boost::beast::http::dynamic_body> request;
        auto streamPtr =
            std::make_unique<stream_type>(socket_type(env.app().getIOContext()), *context_);

        int const octet = nextRemote_++;
        beast::IP::Endpoint const local(boost::asio::ip::make_address("172.1.1.1"), 51235);
        beast::IP::Endpoint const remote(
            boost::asio::ip::make_address("172.1.1." + std::to_string(octet)), 51235);

        PublicKey const key(std::get<0>(randomKeyPair(KeyType::Ed25519)));
        auto consumer = overlay.resourceManager().newInboundEndpoint(remote);
        auto [slot, _] = overlay.peerFinder().newInboundSlot(local, remote);

        auto peer = std::make_shared<PeerTest>(
            env.app(),
            slot,
            std::move(request),
            key,
            protocol,
            consumer,
            std::move(streamPtr),
            overlay);

        overlay.addActive(peer);
        return peer;
    }

    // Build a ledger with enough account-state entries to form a multi-node
    // SHAMap and close it, so a TMGetLedger reply for its account-state tree
    // exercises real inner and leaf tree nodes.
    static void
    seedLedger(jtx::Env& env)
    {
        env.fund(
            XRP(100000),
            "alice",
            "bob",
            "carol",
            "dave",
            "erin",
            "frank",
            "grace",
            "heidi");
        env.close();
    }

    // Request the account-state tree of the most-recently-closed ledger,
    // starting from the root node and pulling a fat subtree, and return the
    // captured reply parsed out of the peer's outgoing message. Selecting the
    // ledger by the `ltCLOSED` type rather than by hash avoids any dependency
    // on ledger-history population and always targets the ledger `seedLedger`
    // just closed.
    static std::optional<protocol::TMLedgerData>
    requestAccountStateReply(jtx::Env& env, std::shared_ptr<PeerTest> const& peer)
    {
        peer->clearLastSentMessage();

        auto getLedger = std::make_shared<protocol::TMGetLedger>();
        getLedger->set_itype(protocol::liAS_NODE);
        getLedger->set_ltype(protocol::ltCLOSED);
        // Pull several levels so the reply contains both inner and leaf nodes.
        getLedger->set_querydepth(3);
        // Root of the tree: depth 0.
        getLedger->add_nodeids(SHAMapNodeID().getRawString());

        peer->onMessage(getLedger);
        // The reply is produced on a JobQueue worker; wait for it to finish.
        env.app().getJobQueue().rendezvous();

        auto const sent = peer->getLastSentMessage();
        if (!sent)
            return std::nullopt;

        auto const& buffer = sent->getBuffer(compression::Compressed::Off);
        if (buffer.size() <= 6)
            return std::nullopt;

        protocol::TMLedgerData reply;
        // Skip the 6-byte framing header (4 bytes size + 2 bytes type).
        if (!reply.ParseFromArray(buffer.data() + 6, buffer.size() - 6))
            return std::nullopt;
        return reply;
    }

    // The legacy reference: the full serialized node id, 32 bytes of path plus
    // one depth byte.
    static bool
    hasFullNodeId(protocol::TMLedgerNode const& n)
    {
        return n.has_nodeid() && n.nodeid().size() == 33;
    }

    static bool
    everyNodeHasNodeId(protocol::TMLedgerData const& data)
    {
        if (data.nodes_size() <= 0)
            return false;
        for (auto const& n : data.nodes())
            if (!hasFullNodeId(n))
                return false;
        return true;
    }

    static bool
    noNodeHasNodeId(protocol::TMLedgerData const& data)
    {
        if (data.nodes_size() <= 0)
            return false;
        for (auto const& n : data.nodes())
            if (hasFullNodeId(n))
                return false;
        return true;
    }

    // Multiset of nodedata blobs, order-independent.
    static std::vector<std::string>
    nodeDataMultiset(protocol::TMLedgerData const& data)
    {
        std::vector<std::string> out;
        out.reserve(data.nodes_size());
        for (auto const& n : data.nodes())
            out.push_back(n.nodedata());
        std::sort(out.begin(), out.end());
        return out;
    }

    // Multiset of (nodedata, nodeid) pairs, order-independent: identity of a
    // fully legacy-encoded reply.
    static std::vector<std::pair<std::string, std::string>>
    legacyRefMultiset(protocol::TMLedgerData const& data)
    {
        std::vector<std::pair<std::string, std::string>> out;
        out.reserve(data.nodes_size());
        for (auto const& n : data.nodes())
            out.emplace_back(n.nodedata(), n.has_nodeid() ? n.nodeid() : std::string{});
        std::sort(out.begin(), out.end());
        return out;
    }

    static std::optional<protocol::TMLedgerData>
    parseReply(std::shared_ptr<Message> const& sent)
    {
        if (!sent)
            return std::nullopt;
        auto const& buffer = sent->getBuffer(compression::Compressed::Off);
        if (buffer.size() <= 6)
            return std::nullopt;
        protocol::TMLedgerData reply;
        if (!reply.ParseFromArray(buffer.data() + 6, buffer.size() - 6))
            return std::nullopt;
        return reply;
    }

    void
    testProtocolNegotiation()
    {
        testcase("protocol negotiation advertises the new version");

        // The newest supported peer-protocol version is now agreed when a peer
        // offers it.
        BEAST_EXPECT(negotiateProtocolVersion("XRPL/2.3") == makeProtocol(2, 3));
        BEAST_EXPECT(
            negotiateProtocolVersion("XRPL/2.1, XRPL/2.2, XRPL/2.3") == makeProtocol(2, 3));
        BEAST_EXPECT(
            negotiateProtocolVersion("RTXP/1.2, XRPL/2.3, XRPL/2.4, XRPL/999.999") ==
            makeProtocol(2, 3));

        // Older peers keep negotiating their highest shared version unchanged.
        BEAST_EXPECT(negotiateProtocolVersion("XRPL/2.2") == makeProtocol(2, 2));
        BEAST_EXPECT(negotiateProtocolVersion("XRPL/2.1") == makeProtocol(2, 1));
        BEAST_EXPECT(negotiateProtocolVersion("XRPL/999.999, WebSocket/1.0") == std::nullopt);
    }

    void
    testEmitEncoding()
    {
        testcase("reply uses compact reference only for a capable peer");

        Env env(*this);
        PeerTest::resetId();

        seedLedger(env);

        auto capablePeer = createPeer(env, makeProtocol(2, 3));
        auto legacyPeer = createPeer(env, makeProtocol(2, 2));

        auto capableReply = requestAccountStateReply(env, capablePeer);
        auto legacyReply = requestAccountStateReply(env, legacyPeer);

        BEAST_EXPECT(capableReply.has_value());
        BEAST_EXPECT(legacyReply.has_value());
        if (!capableReply || !legacyReply)
            return;

        BEAST_EXPECT(capableReply->nodes_size() > 0);
        BEAST_EXPECT(legacyReply->nodes_size() > 0);

        // A capable peer never receives the full legacy node identifier; a
        // legacy peer always does.
        BEAST_EXPECT(noNodeHasNodeId(*capableReply));
        BEAST_EXPECT(everyNodeHasNodeId(*legacyReply));

        // The two replies carry the same underlying node data for the same
        // request: only the per-node reference encoding differs.
        BEAST_EXPECT(nodeDataMultiset(*capableReply) == nodeDataMultiset(*legacyReply));

        // The whole point of the capable encoding is a smaller per-node
        // reference on the wire. With identical node data, the only thing that
        // can move the byte count is the reference, so the capable reply must
        // serialize strictly smaller than the legacy one. This observes the
        // size-reduction contract directly without naming any compact field or
        // pinning its encoding.
        BEAST_EXPECT(capableReply->ByteSizeLong() < legacyReply->ByteSizeLong());
    }

    void
    testRelayDowngradeToLegacyPeer()
    {
        testcase("relaying compact data to an older peer rewrites it to legacy");

        Env env(*this);
        PeerTest::resetId();

        seedLedger(env);

        auto capablePeer = createPeer(env, makeProtocol(2, 3));
        auto legacyPeer = createPeer(env, makeProtocol(2, 2));
        auto relayingPeer = createPeer(env, makeProtocol(2, 3));

        auto capableReply = requestAccountStateReply(env, capablePeer);
        auto legacyReply = requestAccountStateReply(env, legacyPeer);
        BEAST_EXPECT(capableReply.has_value());
        BEAST_EXPECT(legacyReply.has_value());
        if (!capableReply || !legacyReply)
            return;

        // Precondition: the harvested reply is genuinely in the compact form.
        BEAST_EXPECT(noNodeHasNodeId(*capableReply));
        if (!noNodeHasNodeId(*capableReply))
            return;

        // Relay the compact reply toward the older (legacy) peer.
        auto relay = std::make_shared<protocol::TMLedgerData>(*capableReply);
        relay->set_requestcookie(legacyPeer->id());

        legacyPeer->clearLastSentMessage();
        relayingPeer->onMessage(relay);

        auto relayed = parseReply(legacyPeer->getLastSentMessage());
        BEAST_EXPECT(relayed.has_value());
        if (!relayed)
            return;

        // The older peer receives a fully legacy-encoded message...
        BEAST_EXPECT(everyNodeHasNodeId(*relayed));
        BEAST_EXPECT(relayed->nodes_size() == capableReply->nodes_size());
        BEAST_EXPECT(!relayed->has_requestcookie());

        // ...and the reconstructed node identifiers match exactly what a direct
        // legacy reply for the same request would contain.
        BEAST_EXPECT(legacyRefMultiset(*relayed) == legacyRefMultiset(*legacyReply));
    }

    void
    testRelayToCapablePeerUnchanged()
    {
        testcase("relaying compact data to a capable peer leaves it compact");

        Env env(*this);
        PeerTest::resetId();

        seedLedger(env);

        auto capablePeer = createPeer(env, makeProtocol(2, 3));
        auto targetPeer = createPeer(env, makeProtocol(2, 3));
        auto relayingPeer = createPeer(env, makeProtocol(2, 3));

        auto capableReply = requestAccountStateReply(env, capablePeer);
        BEAST_EXPECT(capableReply.has_value());
        if (!capableReply)
            return;

        BEAST_EXPECT(noNodeHasNodeId(*capableReply));
        if (!noNodeHasNodeId(*capableReply))
            return;

        auto relay = std::make_shared<protocol::TMLedgerData>(*capableReply);
        relay->set_requestcookie(targetPeer->id());

        targetPeer->clearLastSentMessage();
        relayingPeer->onMessage(relay);

        auto relayed = parseReply(targetPeer->getLastSentMessage());
        BEAST_EXPECT(relayed.has_value());
        if (!relayed)
            return;

        // No downgrade: the capable target keeps the compact references.
        BEAST_EXPECT(noNodeHasNodeId(*relayed));
        BEAST_EXPECT(nodeDataMultiset(*relayed) == nodeDataMultiset(*capableReply));
        BEAST_EXPECT(!relayed->has_requestcookie());
    }

    // Relays a message holding one full-id node and one compact node, in the
    // given order, toward a peer speaking `target`. A well-formed message in
    // the target's own form goes first through the same relaying peer, so a
    // quiet target afterwards is down to the mixed message itself.
    struct MixedRelay
    {
        bool usable = false;
        bool controlForwarded = false;
        bool mixedForwarded = false;
    };

    MixedRelay
    relayMixed(ProtocolVersion target, bool compactFirst)
    {
        MixedRelay result;

        Env env(*this);
        PeerTest::resetId();

        seedLedger(env);

        auto capablePeer = createPeer(env, makeProtocol(2, 3));
        auto legacyEmitPeer = createPeer(env, makeProtocol(2, 2));
        auto targetPeer = createPeer(env, target);
        auto relayingPeer = createPeer(env, makeProtocol(2, 3));

        auto capableReply = requestAccountStateReply(env, capablePeer);
        auto legacyReply = requestAccountStateReply(env, legacyEmitPeer);
        if (!capableReply || !legacyReply || !noNodeHasNodeId(*capableReply) ||
            !everyNodeHasNodeId(*legacyReply))
            return result;
        result.usable = true;

        auto const targetIsLegacy = target < makeProtocol(2, 3);
        auto control =
            std::make_shared<protocol::TMLedgerData>(targetIsLegacy ? *legacyReply : *capableReply);
        control->set_requestcookie(targetPeer->id());
        targetPeer->clearLastSentMessage();
        relayingPeer->onMessage(control);
        result.controlForwarded = targetPeer->getLastSentMessage() != nullptr;

        auto mixed = std::make_shared<protocol::TMLedgerData>(*legacyReply);
        mixed->clear_nodes();
        if (compactFirst)
        {
            *mixed->add_nodes() = capableReply->nodes(0);
            *mixed->add_nodes() = legacyReply->nodes(0);
        }
        else
        {
            *mixed->add_nodes() = legacyReply->nodes(0);
            *mixed->add_nodes() = capableReply->nodes(0);
        }
        mixed->set_requestcookie(targetPeer->id());

        targetPeer->clearLastSentMessage();
        relayingPeer->onMessage(mixed);
        result.mixedForwarded = targetPeer->getLastSentMessage() != nullptr;
        return result;
    }

    void
    testRelayMixedModeRejected()
    {
        testcase("relaying a message that mixes reference formats is rejected");

        struct Case
        {
            ProtocolVersion target;
            bool compactFirst;
            char const* name;
        };
        Case const cases[] = {
            {makeProtocol(2, 2), false, "2.2 target, full-id node first"},
            {makeProtocol(2, 2), true, "2.2 target, compact node first"},
            {makeProtocol(2, 3), false, "2.3 target, full-id node first"},
            {makeProtocol(2, 3), true, "2.3 target, compact node first"},
        };

        for (auto const& c : cases)
        {
            auto const r = relayMixed(c.target, c.compactFirst);
            BEAST_EXPECTS(r.usable, c.name);
            if (!r.usable)
                continue;
            BEAST_EXPECTS(r.controlForwarded, c.name);
            BEAST_EXPECTS(!r.mixedForwarded, c.name);
        }
    }

    // The tree node a TMLedgerNode's data holds, or null when the bytes don't
    // parse as one.
    static SHAMapTreeNodePtr
    treeNodeOf(protocol::TMLedgerNode const& n)
    {
        try
        {
            return SHAMapTreeNode::makeFromWire(makeSlice(n.nodedata()));
        }
        catch (std::exception const&)
        {
            return {};
        }
    }

    // The one field besides the node data that is set on a compact leaf, when
    // that field holds a single integer.
    static google::protobuf::FieldDescriptor const*
    numericReference(protocol::TMLedgerNode const& n)
    {
        using google::protobuf::FieldDescriptor;
        std::vector<FieldDescriptor const*> fields;
        n.GetReflection()->ListFields(n, &fields);
        FieldDescriptor const* found = nullptr;
        for (auto const* f : fields)
        {
            if (f->name() == "nodedata")
                continue;
            if (found || f->is_repeated())
                return nullptr;
            found = f;
        }
        if (!found)
            return nullptr;
        switch (found->cpp_type())
        {
            case FieldDescriptor::CPPTYPE_INT32:
            case FieldDescriptor::CPPTYPE_INT64:
            case FieldDescriptor::CPPTYPE_UINT32:
            case FieldDescriptor::CPPTYPE_UINT64:
                return found;
            default:
                return nullptr;
        }
    }

    // Replaces the leaf's data with its own bytes under a type byte no tree
    // node uses.
    static bool
    unparseableData(protocol::TMLedgerNode& n)
    {
        std::string data = n.nodedata();
        data.back() = '\x7f';
        n.set_nodedata(data);
        return treeNodeOf(n) == nullptr;
    }

    // Sets the leaf's numeric reference far below the deepest level a ledger
    // tree has. Returns false when the leaf carries no such number.
    static bool
    impossiblePosition(protocol::TMLedgerNode& n)
    {
        using google::protobuf::FieldDescriptor;
        auto const* f = numericReference(n);
        if (!f)
            return false;
        auto const* r = n.GetReflection();
        std::uint32_t const value = SHAMap::kLeafDepth * 16;
        switch (f->cpp_type())
        {
            case FieldDescriptor::CPPTYPE_INT32:
                r->SetInt32(&n, f, static_cast<std::int32_t>(value));
                break;
            case FieldDescriptor::CPPTYPE_INT64:
                r->SetInt64(&n, f, value);
                break;
            case FieldDescriptor::CPPTYPE_UINT32:
                r->SetUInt32(&n, f, value);
                break;
            default:
                r->SetUInt64(&n, f, value);
                break;
        }
        return true;
    }

    // Relays toward a 2.2 peer, through one relaying peer, the compact reply a
    // 2.3 peer got and then the same reply with its first leaf changed by
    // `damage`. `damagedAsDirect` is set when what reached the 2.2 peer holds
    // the same (node data, full node id) pairs as the 2.2 peer's own direct
    // reply, with the changed leaf's data in place of the original.
    struct DamagedRelay
    {
        bool usable = false;
        bool applies = false;
        bool controlForwarded = false;
        bool damagedForwarded = false;
        bool damagedAsDirect = false;
    };

    template <class Damage>
    DamagedRelay
    relayDamagedLeaf(Damage const& damage)
    {
        DamagedRelay result;

        Env env(*this);
        PeerTest::resetId();

        seedLedger(env);

        auto capablePeer = createPeer(env, makeProtocol(2, 3));
        auto legacyPeer = createPeer(env, makeProtocol(2, 2));
        auto relayingPeer = createPeer(env, makeProtocol(2, 3));

        auto capableReply = requestAccountStateReply(env, capablePeer);
        auto legacyReply = requestAccountStateReply(env, legacyPeer);
        if (!capableReply || !legacyReply || !noNodeHasNodeId(*capableReply) ||
            !everyNodeHasNodeId(*legacyReply))
            return result;

        int leaf = -1;
        for (int i = 0; i < capableReply->nodes_size() && leaf < 0; ++i)
        {
            auto const node = treeNodeOf(capableReply->nodes(i));
            if (node && node->isLeaf())
                leaf = i;
        }
        if (leaf < 0)
            return result;
        std::string const original = capableReply->nodes(leaf).nodedata();

        int legacyLeaf = -1;
        for (int i = 0; i < legacyReply->nodes_size() && legacyLeaf < 0; ++i)
        {
            if (legacyReply->nodes(i).nodedata() == original)
                legacyLeaf = i;
        }
        if (legacyLeaf < 0)
            return result;
        result.usable = true;

        auto damaged = std::make_shared<protocol::TMLedgerData>(*capableReply);
        result.applies = damage(*damaged->mutable_nodes(leaf));
        if (!result.applies)
            return result;
        damaged->set_requestcookie(legacyPeer->id());

        auto direct = *legacyReply;
        direct.mutable_nodes(legacyLeaf)->set_nodedata(damaged->nodes(leaf).nodedata());

        auto control = std::make_shared<protocol::TMLedgerData>(*capableReply);
        control->set_requestcookie(legacyPeer->id());
        legacyPeer->clearLastSentMessage();
        relayingPeer->onMessage(control);
        result.controlForwarded = legacyPeer->getLastSentMessage() != nullptr;

        legacyPeer->clearLastSentMessage();
        relayingPeer->onMessage(damaged);
        auto const relayed = parseReply(legacyPeer->getLastSentMessage());
        result.damagedForwarded = legacyPeer->getLastSentMessage() != nullptr;
        result.damagedAsDirect = relayed && everyNodeHasNodeId(*relayed) &&
            legacyRefMultiset(*relayed) == legacyRefMultiset(direct);
        return result;
    }

    // What reaches the 2.2 peer is either nothing or the full ids it would
    // get by asking directly.
    void
    expectDroppedOrAsDirect(DamagedRelay const& r, char const* name)
    {
        BEAST_EXPECTS(r.controlForwarded, name);
        BEAST_EXPECTS(!r.damagedForwarded || r.damagedAsDirect, name);
    }

    void
    testRelayDropsUnrebuildableNode()
    {
        testcase("relaying a spoiled compact leaf to an older peer");

        auto const data = relayDamagedLeaf(unparseableData);
        BEAST_EXPECTS(data.usable && data.applies, "leaf data that doesn't parse");
        if (data.usable && data.applies)
            expectDroppedOrAsDirect(data, "leaf data that doesn't parse");

        // Only a leaf whose compact reference is one integer can be given a
        // position no tree has.
        auto const position = relayDamagedLeaf(impossiblePosition);
        BEAST_EXPECTS(position.usable, "leaf position past the deepest level");
        if (position.usable && position.applies)
            expectDroppedOrAsDirect(position, "leaf position past the deepest level");
    }

    // An Env with its own in-memory node store. Every jtx Env opens the store
    // named "main" by default and they all share it, so a node that should
    // fetch a ledger would otherwise find it already stored.
    static std::unique_ptr<Config>
    ownNodeStore(std::string const& name)
    {
        auto cfg = envconfig();
        cfg->overwrite(Sections::kNodeDatabase, Keys::kPath, name);
        return cfg;
    }

    static std::optional<protocol::TMGetLedger>
    parseRequest(std::shared_ptr<Message> const& sent)
    {
        if (!sent)
            return std::nullopt;
        auto const& buffer = sent->getBuffer(compression::Compressed::Off);
        if (buffer.size() <= 6)
            return std::nullopt;
        int const type = (static_cast<int>(buffer[4]) << 8) | static_cast<int>(buffer[5]);
        if (type != protocol::mtGET_LEDGER)
            return std::nullopt;
        protocol::TMGetLedger request;
        if (!request.ParseFromArray(buffer.data() + 6, buffer.size() - 6))
            return std::nullopt;
        return request;
    }

    // What one fetch saw: how many tree-node replies went over, and whether
    // each one was in the form the connection should use.
    struct SyncLog
    {
        int treeReplies = 0;
        bool allCompact = true;
        bool allLegacy = true;
    };

    // Run a fetch between two nodes. `server` is how the serving node sees the
    // fetching one and `client` is how the fetching node sees the server. The
    // first request is `request`; after each reply is handed over, the next
    // request is whatever the fetching node sent back, until `done` holds or
    // the fetching node stops asking.
    template <class Done>
    static SyncLog
    runSync(
        Env& serverEnv,
        std::shared_ptr<PeerTest> const& server,
        Env& clientEnv,
        std::shared_ptr<PeerTest> const& client,
        protocol::TMGetLedger request,
        Done const& done)
    {
        SyncLog log;
        for (int round = 0; round < 64 && !done(); ++round)
        {
            server->clearLastSentMessage();
            server->onMessage(std::make_shared<protocol::TMGetLedger>(request));
            serverEnv.app().getJobQueue().rendezvous();

            auto reply = parseReply(server->getLastSentMessage());
            if (!reply)
                break;

            if (reply->type() != protocol::liBASE)
            {
                ++log.treeReplies;
                log.allCompact = log.allCompact && noNodeHasNodeId(*reply);
                log.allLegacy = log.allLegacy && everyNodeHasNodeId(*reply);
            }

            client->clearLastSentMessage();
            client->onMessage(std::make_shared<protocol::TMLedgerData>(*reply));
            clientEnv.app().getJobQueue().rendezvous();

            auto next = parseRequest(client->getLastSentMessage());
            if (!next)
                break;
            request = *next;
        }
        return log;
    }

    void
    syncLedger(ProtocolVersion protocol, std::string const& store)
    {
        Env serverEnv(*this);
        Env clientEnv(*this, ownNodeStore(store));
        PeerTest::resetId();

        seedLedger(serverEnv);
        auto const ledger = serverEnv.closed();
        auto const hash = ledger->header().hash;

        auto server = createPeer(serverEnv, protocol);
        auto client = createPeer(clientEnv, protocol);

        clientEnv.app().getInboundLedgers().acquire(
            hash, ledger->header().seq, InboundLedger::Reason::GENERIC);
        clientEnv.app().getJobQueue().rendezvous();

        auto const inbound = clientEnv.app().getInboundLedgers().find(hash);
        BEAST_EXPECT(inbound != nullptr);
        if (!inbound)
            return;
        BEAST_EXPECT(!inbound->isComplete());

        protocol::TMGetLedger request;
        request.set_itype(protocol::liBASE);
        request.set_ledgerhash(hash.begin(), hash.size());

        auto const log = runSync(
            serverEnv, server, clientEnv, client, request, [&] { return inbound->isComplete(); });

        BEAST_EXPECT(log.treeReplies > 0);
        if (protocol >= makeProtocol(2, 3))
            BEAST_EXPECT(log.allCompact);
        else
            BEAST_EXPECT(log.allLegacy);

        BEAST_EXPECT(!inbound->isFailed());
        if (!BEAST_EXPECT(inbound->isComplete()))
            return;
        auto const fetched = inbound->getLedger();
        BEAST_EXPECT(fetched != nullptr);
        if (!fetched)
            return;
        BEAST_EXPECT(fetched->header().hash == hash);
        BEAST_EXPECT(fetched->exists(keylet::account(Account("heidi").id())));
    }

    void
    testSyncLedgerFromCompactReplies()
    {
        testcase("a ledger is fetched from compact replies");

        syncLedger(makeProtocol(2, 3), "ledger_node_depth_ledger_new");
        syncLedger(makeProtocol(2, 2), "ledger_node_depth_ledger_old");
    }

    void
    syncTxSet(ProtocolVersion protocol, std::string const& store)
    {
        Env serverEnv(*this);
        Env clientEnv(*this, ownNodeStore(store));
        PeerTest::resetId();

        seedLedger(serverEnv);

        // A candidate set holding the transactions the ledger just took in.
        auto set =
            std::make_shared<SHAMap>(SHAMapType::TRANSACTION, serverEnv.app().getNodeFamily());
        int count = 0;
        for (auto const& item : serverEnv.closed()->txs)
        {
            Serializer s;
            item.first->add(s);
            set->addItem(
                SHAMapNodeType::TnTransactionNm,
                makeShamapitem(item.first->getTransactionID(), s.slice()));
            ++count;
        }
        BEAST_EXPECT(count >= 8);
        set = set->snapShot(false);
        auto const setHash = set->getHash().asUInt256();
        serverEnv.app().getInboundTransactions().giveSet(setHash, set, false);

        auto server = createPeer(serverEnv, protocol);
        auto client = createPeer(clientEnv, protocol);

        auto& inbound = clientEnv.app().getInboundTransactions();
        BEAST_EXPECT(inbound.getSet(setHash, true) == nullptr);
        clientEnv.app().getJobQueue().rendezvous();

        protocol::TMGetLedger request;
        request.set_itype(protocol::liTS_CANDIDATE);
        request.set_ledgerhash(setHash.begin(), setHash.size());
        request.set_querydepth(3);
        request.add_nodeids(SHAMapNodeID().getRawString());

        auto const log = runSync(serverEnv, server, clientEnv, client, request, [&] {
            return inbound.getSet(setHash, false) != nullptr;
        });

        BEAST_EXPECT(log.treeReplies > 0);
        if (protocol >= makeProtocol(2, 3))
            BEAST_EXPECT(log.allCompact);
        else
            BEAST_EXPECT(log.allLegacy);

        auto const fetched = inbound.getSet(setHash, false);
        BEAST_EXPECT(fetched != nullptr);
        if (!fetched)
            return;
        BEAST_EXPECT(fetched->getHash().asUInt256() == setHash);
        int fetchedCount = 0;
        for (auto const& item : *fetched)
        {
            (void)item;
            ++fetchedCount;
        }
        BEAST_EXPECT(fetchedCount == count);
    }

    void
    testSyncTxSetFromCompactReplies()
    {
        testcase("a transaction set is fetched from compact replies");

        syncTxSet(makeProtocol(2, 3), "ledger_node_depth_txset_new");
        syncTxSet(makeProtocol(2, 2), "ledger_node_depth_txset_old");
    }

    // Account-state data for a ledger the receiving node isn't fetching is
    // still kept in its fetch pack, so a later fetch can use it. The reply goes
    // in through the fetching side's PeerImp::onMessage with no request cookie,
    // the same way a late reply reaches it after a fetch has moved on.
    void
    keepStaleReply(ProtocolVersion protocol, std::string const& store)
    {
        Env serverEnv(*this);
        Env clientEnv(*this, ownNodeStore(store));
        PeerTest::resetId();

        seedLedger(serverEnv);

        auto const asker = createPeer(serverEnv, protocol);
        auto const reply = requestAccountStateReply(serverEnv, asker);
        if (!BEAST_EXPECT(reply.has_value()) || !BEAST_EXPECT(reply->nodes_size() > 1))
            return;
        bool const v23 = protocol == makeProtocol(2, 3);
        BEAST_EXPECT(v23 ? noNodeHasNodeId(*reply) : everyNodeHasNodeId(*reply));

        std::vector<uint256> hashes;
        for (auto const& n : reply->nodes())
        {
            auto const node = SHAMapTreeNode::makeFromWire(makeSlice(n.nodedata()));
            if (!BEAST_EXPECT(node))
                return;
            hashes.push_back(node->getHash().asUInt256());
        }

        auto const server = createPeer(clientEnv, protocol);
        auto data = std::make_shared<protocol::TMLedgerData>(*reply);
        data->clear_requestcookie();
        server->onMessage(data);
        clientEnv.app().getJobQueue().rendezvous();

        std::size_t kept = 0;
        for (auto const& h : hashes)
        {
            if (clientEnv.app().getLedgerMaster().getFetchPack(h))
                ++kept;
        }
        BEAST_EXPECT(kept == hashes.size());
    }

    void
    testStaleReplyKeptInFetchPack()
    {
        testcase("account-state data for a ledger nobody is fetching is kept");

        keepStaleReply(makeProtocol(2, 3), "ledger_node_depth_stale_new");
        keepStaleReply(makeProtocol(2, 2), "ledger_node_depth_stale_old");
    }

public:
    void
    run() override
    {
        testProtocolNegotiation();
        testEmitEncoding();
        testRelayDowngradeToLegacyPeer();
        testRelayToCapablePeerUnchanged();
        testRelayMixedModeRejected();
        testRelayDropsUnrebuildableNode();
        testSyncLedgerFromCompactReplies();
        testSyncTxSetFromCompactReplies();
        testStaleReplyKeptInFetchPack();
    }
};

BEAST_DEFINE_TESTSUITE(LedgerNodeDepth, overlay, xrpl);

}  // namespace xrpl::test
