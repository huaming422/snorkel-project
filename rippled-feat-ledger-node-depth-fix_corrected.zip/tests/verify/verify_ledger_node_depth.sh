#!/usr/bin/env bash
# Native beast-suite verifier for rippled-feat-ledger-node-depth.
#
# The behavioural reward is a beast unit-test suite compiled into the `xrpld`
# test binary. The suite source lives beside this script; we copy it into the
# repo's overlay test tree so the CMake `GLOB_RECURSE src/test/*.cpp` picks it
# up, then let the already-run test-setup.sh incremental build (invoked by
# test.sh before this verifier) have compiled it into `xrpld`. We only run the
# suite here and propagate its exit code.
#
# Exit 0  => every BEAST_EXPECT in the suite passed.
# Exit !0 => a check failed, the suite did not link, or the binary is missing.
#
# This script runs from the repo root (REPO_NAME resolved by the harness). It is
# deliberately a thin runner: all the compilation happens in test-setup.sh so
# the heavy ninja rebuild is shared with any other native verifier and counted
# once against the setup budget.
set -uo pipefail

REPO_DIR="/repo/${REPO_NAME:-rippled}"
SUITE_SRC_NAME="LedgerNodeDepth_test.cpp"
SUITE_DEST_DIR="${REPO_DIR}/src/test/overlay"
SUITE_PATTERN="LedgerNodeDepth"

# Resolve the directory holding this script (that is where the suite source and
# verify.toml are staged, i.e. /tests/verify).
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

BIN="${REPO_DIR}/build/xrpld"

echo "[verify] repo dir:    ${REPO_DIR}"
echo "[verify] suite source: ${SCRIPT_DIR}/${SUITE_SRC_NAME}"
echo "[verify] binary:      ${BIN}"

if [ ! -f "${SCRIPT_DIR}/${SUITE_SRC_NAME}" ]; then
    echo "[verify] FATAL: suite source not found next to verifier" >&2
    exit 1
fi

# Ensure the suite source is present in the repo tree. test-setup.sh copies it
# before the incremental build; copy again defensively (idempotent) in case this
# verifier is run standalone. If the file is newly placed here the binary must
# have been (re)built by test-setup.sh already: we do not rebuild in the
# verifier to keep the grade step fast and deterministic.
mkdir -p "${SUITE_DEST_DIR}"
cp -f "${SCRIPT_DIR}/${SUITE_SRC_NAME}" "${SUITE_DEST_DIR}/${SUITE_SRC_NAME}"

if [ ! -x "${BIN}" ]; then
    echo "[verify] FATAL: xrpld binary missing or not executable at ${BIN}" >&2
    echo "[verify] test-setup.sh must build xrpld (with the suite) before the verifier runs." >&2
    exit 1
fi

# Run the beast suite. The framework's own guard (`anyMissing`) returns a
# non-zero exit code when the `--unittest` filter matches no existing suite, so
# a suite that failed to compile/link into the binary is a hard FAIL rather than
# a silent false pass: we do not need a separate presence probe. Any failing
# BEAST_EXPECT in the suite also yields a non-zero exit.
echo "[verify] running beast suite '${SUITE_PATTERN}'..."
"${BIN}" --unittest="${SUITE_PATTERN}" 2>&1 | tee /tmp/ldn_suite.log
rc="${PIPESTATUS[0]}"

echo "[verify] suite exit code: ${rc}"
if [ "${rc}" -ne 0 ]; then
    echo "[verify] ---- suite output (tail) ----" >&2
    tail -80 /tmp/ldn_suite.log >&2 || true
fi
exit "${rc}"
