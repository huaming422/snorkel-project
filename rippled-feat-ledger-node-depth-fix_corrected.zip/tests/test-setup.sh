#!/usr/bin/env bash
# test-setup.sh — sourced before the verifier runs.
#
# Performs the incremental rebuild of the `xrpld` beast test binary after the
# agent's edits. The image pre-built xrpld at /repo/rippled/build/xrpld with the
# Conan dependency graph already compiled into ~/.conan2, so this incremental
# rebuild re-links only the translation units the agent touched (plus any
# generated protobuf sources when the .proto changed) and completes far faster
# than the cold image build.
#
# Runs offline: everything needed to configure and build is baked into the
# image. No network fetch here.
set -euo pipefail

cd /repo/rippled

JOBS="$(nproc)"; if [ "$JOBS" -gt 32 ]; then JOBS=32; fi

# The Conan-provided build-context tools (protoc, grpc_cpp_plugin, ...) shipped
# with a Nix-store ELF interpreter that does not exist on Ubuntu. The image
# already symlinked each referenced Nix interpreter to the system loader; re-apply
# idempotently in case the agent regenerated the Conan cache (harmless if the
# links already exist).
if [ -d /root/.conan2/p ]; then
    SYS_INTERP="$(readelf -l /bin/ls | sed -n 's/.*program interpreter: \(.*\)\]/\1/p')"
    for f in $(find /root/.conan2/p -path '*/p/bin/*' -type f 2>/dev/null); do
        case "$(od -An -tx1 -N4 "$f" | tr -d ' ')" in 7f454c46) ;; *) continue;; esac
        NIX_INTERP="$(readelf -l "$f" | sed -n 's/.*program interpreter: \(.*\)\]/\1/p')"
        case "$NIX_INTERP" in /nix/*) mkdir -p "$(dirname "$NIX_INTERP")"; ln -sf "$SYS_INTERP" "$NIX_INTERP";; esac
    done
fi

# Stage the behavioural beast suite into the overlay test tree so the CMake
# `GLOB_RECURSE src/test/*.cpp` picks it up. The verifier source ships beside
# the verifier script under /tests/verify/. This keeps the suite out of the
# agent-visible repo during the agent phase (it is injected only at grade time)
# while compiling it into the same `xrpld` binary the beast framework runs.
SUITE_SRC="/tests/verify/LedgerNodeDepth_test.cpp"
SUITE_DEST="src/test/overlay/LedgerNodeDepth_test.cpp"
STAGED_NEW=0
if [ -f "$SUITE_SRC" ]; then
    if [ ! -f "$SUITE_DEST" ] || ! cmp -s "$SUITE_SRC" "$SUITE_DEST"; then
        echo "test-setup: staging behavioural suite into ${SUITE_DEST}"
        mkdir -p "$(dirname "$SUITE_DEST")"
        cp -f "$SUITE_SRC" "$SUITE_DEST"
        STAGED_NEW=1
    fi
else
    echo "test-setup: WARNING: verifier suite ${SUITE_SRC} not found" >&2
fi

# Reconfigure when the build dir is missing (belt-and-suspenders; the image
# leaves it populated) OR when we just added the suite file. The test-source
# glob is evaluated at configure time without CONFIGURE_DEPENDS, so a freshly
# added `src/test/*.cpp` is only compiled in after a reconfigure. The agent may
# also have edited the .proto, CMakeLists, or source — `cmake --build` picks up
# the dependency graph either way once configured.
if [ ! -f build/CMakeCache.txt ] || [ "$STAGED_NEW" -eq 1 ]; then
    echo "test-setup: running cmake configure (re-globbing test sources)..."
    cmake -S . -B build -G Ninja \
        -DCMAKE_TOOLCHAIN_FILE=/repo/rippled/build/generators/conan_toolchain.cmake \
        -DCMAKE_BUILD_TYPE=Release -Dxrpld=ON -Dtests=ON \
        > /tmp/cmake-configure.log 2>&1 || { tail -80 /tmp/cmake-configure.log; exit 1; }
fi

echo "test-setup: incremental rebuild of xrpld (jobs=${JOBS})..."
cmake --build build --target xrpld --parallel "${JOBS}" \
    > /tmp/xrpld-build.log 2>&1 || { tail -120 /tmp/xrpld-build.log; exit 1; }

# Sanity-check the binary exists and runs. A fatal compile error would have
# killed the build above; this confirms the link succeeded and the unit-test
# entry point is present.
if [ ! -x build/xrpld ]; then
    echo "test-setup: build/xrpld missing or non-executable" >&2
    exit 1
fi
build/xrpld --unittest=NONEXISTENT_SUITE_SANITY >/dev/null 2>&1 || true
echo "test-setup: ready (build/xrpld present)."
