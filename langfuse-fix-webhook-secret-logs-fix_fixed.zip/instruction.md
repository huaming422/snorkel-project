## Task

we have two problems with outbound webhook deliveries, and they show up together on the same deliveries.

the first is a credential leak. some customers deliver to signed callback links of the kind cloud integration platforms hand out, where a shared secret is part of the URL itself. whenever such a delivery fails, that secret is printed in plain text into the worker's logs and saved on the failed delivery's error record, so anybody with access to logs, traces or the database can pick up a working secret. addresses a destination redirects us on to are no different. nor is there a single culprit: the URL is written out directly in places, and it also rides along inside error objects that our generic failure handling turns into log lines and stored text afterwards, so fixing one spot leaves the rest open.

limit that fix to what we write down. the outgoing request must still use the complete URL as configured, since the receiver checks that secret to know it's us. at the same time a failure record still needs to be useful: which destination it was, recognisable from the URL, and the reason it failed.

the second problem is that these deliveries now and then give up with a connect timeout within the first fraction of a second, nowhere near the request timeout we set, even though the destination is healthy. track down the cause and fix it for webhooks. the rest of our outbound traffic, model provider calls and integrations, should go on connecting exactly as it does now.
