// @ts-nocheck
//
// Behavioral verifier for the redaction contract AT THE WORKER EGRESS BOUNDARY,
// not in isolation. It exercises the pre-existing worker symbol
//   rethrowIfOutboundValidationFailure  (worker/src/features/analyticsIntegrationEgress)
// together with the pre-existing shared RedirectValidationError, exactly the way
// a failed outbound send is classified and re-reported before the queue's
// generic `failed` handler logs the whole error and persists its `failedReason`.
//
// This mirrors the worker's offline analytics SSRF-pinning harness: prisma, the
// worker env, and encryption are mocked; the shared logger is replaced; no
// network, no datastore. The gating assertions ride pre-existing symbols only —
// no new helper symbol is imported or required.
//
// Behavior under test: for a credentialed and signed redirect target, every
// serializable surface of the source error and of the rethrown error is free of
// the secrets while still carrying the blocked host and the failure reason. The
// source error is produced by the real shared fetchWithSecureRedirects, with
// only the global `fetch` it ends in stubbed, so it is the error a refused
// redirect really raises.

import { afterEach, describe, expect, it, vi } from "vitest";

// The worker env module reads process.env and would otherwise pull the full
// zod-validated worker schema; the egress classifier under test never reads it,
// so a minimal stub keeps the import offline and deterministic.
vi.mock("../env", () => ({
  env: {
    LANGFUSE_MIGRATION_V4_WRITE_MODE: "legacy",
  },
  v4WritesToLegacyTables: () => true,
  v4WritesToEventsTable: () => false,
}));

// The classifier never touches prisma, but sibling modules in the barrel can
// construct a client at import; stub it so the import graph stays datastore-free.
vi.mock("@langfuse/shared/src/db", () => ({
  prisma: {},
}));

// Replace ONLY the shared logger (the classifier calls logger.error); keep every
// other shared export — the real RedirectValidationError, OutboundUrlValidationError,
// redactUrlCredentials, etc. — intact via importOriginal.
vi.mock("@langfuse/shared/src/server", async (importOriginal) => {
  const actual =
    await importOriginal<typeof import("@langfuse/shared/src/server")>();
  return {
    ...actual,
    logger: { info: vi.fn(), warn: vi.fn(), error: vi.fn(), debug: vi.fn() },
  };
});

// Imported after mocks are registered.
import {
  RedirectValidationError,
  OutboundUrlValidationError,
  fetchWithSecureRedirects,
} from "@langfuse/shared/src/server";
import { isUnrecoverableError } from "../errors/UnrecoverableError";
import { rethrowIfOutboundValidationFailure } from "../features/analyticsIntegrationEgress";

const QUERY_SECRET = "super-secret-sig";
const TOKEN_SECRET = "meta-secret-token";
const USERINFO_SECRET = "hunter2";
const BLOCKED_HOST = "169.254.169.254";
const KEPT_PATH = "/latest";
const BLOCK_REASON = "Blocked IP address detected: 169.254.169.254";

// Everything a structured logger or tracer can pull off a thrown error: its
// enumerable own fields (winston copies those into the JSON log line), its
// message, its stack, and the same again for each `cause` a chain-walking
// reporter follows.
function serializableSurface(error: unknown): string {
  const parts: string[] = [];
  let current: any = error;
  for (let depth = 0; depth < 6 && current; depth++) {
    parts.push(JSON.stringify({ ...current }));
    if (typeof current.message === "string") parts.push(current.message);
    if (typeof current.stack === "string") parts.push(current.stack);
    current = current.cause;
  }
  return parts.join("\n");
}

// A delivery to a signed URL that the destination redirects to a blocked
// address. The rejected redirect target carries userinfo credentials and two
// query-string secrets; the caller's URL validator refuses it.
async function refusedRedirect(): Promise<unknown> {
  vi.stubGlobal(
    "fetch",
    vi.fn(
      async () =>
        new Response(null, {
          status: 302,
          headers: {
            Location: `http://exporter:${USERINFO_SECRET}@${BLOCKED_HOST}${KEPT_PATH}?token=${TOKEN_SECRET}&sig=${QUERY_SECRET}`,
          },
        }),
    ),
  );
  try {
    await fetchWithSecureRedirects(
      "https://host.example/hook/path?code=func-secret-code",
      { method: "POST", body: "{}" },
      {
        maxRedirects: 5,
        redirectValidation: {
          validateUrl: async () => {
            throw new OutboundUrlValidationError("blocked-ip", BLOCK_REASON);
          },
          whitelist: { hosts: [], ips: [], ip_ranges: [] },
          logContext: "Webhook outbound send",
        },
      },
    );
  } catch (error) {
    return error;
  }
  return undefined;
}

// The same refusal as undici surfaces a connect-time failure: a generic
// "fetch failed" TypeError whose enumerable `cause` is the real error.
async function wrappedRefusedRedirect(): Promise<unknown> {
  return Object.assign(new TypeError("fetch failed"), {
    cause: await refusedRedirect(),
  });
}

const SECRETS = [USERINFO_SECRET, QUERY_SECRET, TOKEN_SECRET, "func-secret-code"];

function expectNoSecret(text: string) {
  for (const secret of SECRETS) expect(text).not.toContain(secret);
}

function captureRethrow(error: unknown): unknown {
  try {
    rethrowIfOutboundValidationFailure(error, {
      logSubject: "Webhook outbound send",
      jobSubject: "Webhook delivery",
    });
  } catch (caught) {
    return caught;
  }
  return undefined;
}

describe("worker egress — terminal outbound failure reporting", () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it("raises a redirect validation error for the refused redirect", async () => {
    expect(await refusedRedirect()).toBeInstanceOf(RedirectValidationError);
  });

  it.each([
    ["as raised", refusedRedirect],
    ["wrapped in a fetch failure", wrappedRefusedRedirect],
  ])("strips the secrets from the rethrown message while keeping the host and reason (%s)", async (_label, make) => {
    const thrown = captureRethrow(await make());

    expect(isUnrecoverableError(thrown)).toBe(true);
    const message = (thrown as Error).message;
    expectNoSecret(message);
    // Host + path survive so the operator can identify the destination.
    expect(message).toContain(BLOCKED_HOST);
    expect(message).toContain(KEPT_PATH);
    // The diagnostic reason must survive redaction.
    expect(message).toContain(BLOCK_REASON);
  });

  // The source error is logged directly before any re-report runs, so both the
  // source object and the rethrown object are inspected.
  it("keeps the secrets off every serializable surface of the source and rethrown error", async () => {
    const source = await wrappedRefusedRedirect();
    expectNoSecret(serializableSurface(source));

    const thrown = captureRethrow(source);
    // The generic `failed` handler passes the whole error to the logger.
    const surface = serializableSurface(thrown);
    expectNoSecret(surface);
    expect(surface).not.toContain("exporter:hunter2@169.254.169.254");
    // The failure reason is still on that surface.
    expect(surface).toContain(BLOCK_REASON);
  });

  // A credential-free validation error still rethrows as terminal with its
  // reason intact.
  it("leaves a credential-free block message intact and still terminal", () => {
    let thrown: unknown;
    try {
      rethrowIfOutboundValidationFailure(
        new OutboundUrlValidationError(
          "blocked-ip",
          "Blocked IP address detected: 127.0.0.1",
        ),
        { logSubject: "Webhook outbound send", jobSubject: "Webhook delivery" },
      );
    } catch (caught) {
      thrown = caught;
    }
    expect(isUnrecoverableError(thrown)).toBe(true);
    expect((thrown as Error).message).toContain(
      "Blocked IP address detected: 127.0.0.1",
    );
  });
});
