// @ts-nocheck
//
// Behavioral checks at the worker's webhook-delivery boundary. They drive the
// pre-existing worker entry point `executeWebhook` (worker/src/queues/webhooks)
// over a delivery to a signed URL that answers 500, with prisma, the worker
// env, encryption, the automation repository reads and the shared logger
// mocked. The shared `fetchWithSecureRedirects` runs for real; only the global
// `fetch` it ends in is stubbed, so the request init it builds, including the
// pooled agent the request is sent through, is observable.
//
// What is checked:
//   - the signed secret appears on no logger call and in no stored error, while
//     the destination host stays visible in the logs;
//   - the request is made to the full, unmodified URL;
//   - the agent the webhook request is sent through does not abandon a
//     per-address connection attempt at the runtime's 250 ms default;
//   - an ordinary outbound caller in the same process still gets the runtime's
//     default connection-attempt window.
//
// The root `@langfuse/shared` barrel is mocked with the few runtime symbols
// webhooks.ts takes from it, because its built entry fails to initialise under
// this harness; `@langfuse/shared/src/server` is kept real via importOriginal.

import net from "node:net";
import { beforeEach, describe, expect, it, vi } from "vitest";

// The delivery URL under test: a signed callback whose shared secret rides the
// query string, shaped like a cloud iPaaS signed callback URL.
const DELIVERY_URL = "https://host.example/hook/path?sig=super-secret-sig";
const SECRET = "super-secret-sig";
const DEST_HOST = "host.example";

// Node 24's per-address connection-attempt default with happy-eyeballs address
// selection on.
const NODE_DEFAULT_ATTEMPT_TIMEOUT_MS = 250;

// All captured spies/fns live in a hoisted record so the hoisted vi.mock
// factories below may reference them safely (vitest lifts vi.mock above imports).
const h = vi.hoisted(() => {
  const logger = {
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
    debug: vi.fn(),
  };
  const executionUpdate = vi.fn(async () => undefined);
  const triggerUpdate = vi.fn(async () => undefined);
  const deliveryUrl = "https://host.example/hook/path?sig=super-secret-sig";
  // Delegates to the real shared implementation (wired in the mock below).
  const fetchWithSecureRedirects = vi.fn();
  // The network call the real implementation ends in.
  const globalFetch = vi.fn(
    async () => new Response('{"error":"nope"}', { status: 500 }),
  );
  return {
    logger,
    executionUpdate,
    triggerUpdate,
    fetchWithSecureRedirects,
    globalFetch,
    deliveryUrl,
  };
});

// Root `@langfuse/shared` barrel: its dist is broken under this harness, so we
// supply only the runtime symbols webhooks.ts imports from it. Type-only imports
// (AutomationDomain, ActionDomainWithSecrets) are erased and need nothing here.
vi.mock("@langfuse/shared", () => {
  class InternalServerError extends Error {
    constructor(message: string) {
      super(message);
      this.name = "InternalServerError";
    }
  }
  class LangfuseNotFoundError extends Error {
    constructor(message: string) {
      super(message);
      this.name = "LangfuseNotFoundError";
    }
  }
  return {
    InternalServerError,
    LangfuseNotFoundError,
    ActionExecutionStatus: {
      COMPLETED: "COMPLETED",
      ERROR: "ERROR",
      PENDING: "PENDING",
      CANCELLED: "CANCELLED",
    },
    JobConfigState: { ACTIVE: "ACTIVE", INACTIVE: "INACTIVE" },
    WebhookDefaultHeaders: {},
    PromptWebhookOutboundSchema: {
      safeParse: (data: unknown) => ({ success: true, data }),
    },
    // The delivery under test is a WEBHOOK action; the guard just needs to agree.
    isWebhookAction: (action: { type?: string }) => action?.type === "WEBHOOK",
    isSlackActionConfig: () => false,
    isGitHubDispatchAction: () => false,
  };
});

// Backoff collapsed to a single attempt so the delivery path runs once and
// deterministically; the real retry policy is irrelevant to what we assert.
vi.mock("exponential-backoff", () => ({
  backOff: vi.fn(async (fn: () => Promise<unknown>) => fn()),
}));

// Encryption and the monitor barrel are import-time heavy (the monitor barrel is
// broken under this harness too) and unrelated to the contract; stub them.
vi.mock("@langfuse/shared/encryption", () => ({
  decrypt: vi.fn(() => "signing-secret"),
  createSignatureHeader: vi.fn(() => "t=1,v1=sig"),
}));

vi.mock("@langfuse/shared/monitors/server", () => ({
  MonitorWebhookQueueEventSchema: {
    safeParse: vi.fn((payload: unknown) => ({ success: true, data: payload })),
  },
  buildMonitorAlertSlackMessage: vi.fn(),
}));

// The slack message builder transitively pulls broken modules at import; the
// WEBHOOK delivery path never invokes it, so a stub keeps the import graph clean.
vi.mock("../features/slack/slackMessageBuilder", () => ({
  SlackMessageBuilder: class {},
}));

// Prisma: capture the ERROR-row write so we can inspect the stored error text.
vi.mock("@langfuse/shared/src/db", () => ({
  prisma: {
    $transaction: vi.fn(async (cb: any) =>
      cb({
        automationExecution: { update: h.executionUpdate },
        trigger: { update: h.triggerUpdate },
      }),
    ),
    automationExecution: { update: vi.fn(async () => undefined) },
  },
  Prisma: {},
}));

// Worker env: only the two fields the delivery path reads.
vi.mock("../env", () => ({
  env: {
    LANGFUSE_WEBHOOK_TIMEOUT_MS: 10_000,
    LANGFUSE_WEBHOOK_MAX_REDIRECTS: 5,
  },
}));

// Logger spies + the handful of repository reads the delivery path makes; every
// other shared/server export (buildWebhookOutboundPayload's schema, constants,
// etc.) stays intact via importOriginal — the same seam the egress suite uses.
vi.mock("@langfuse/shared/src/server", async (importOriginal) => {
  const actual =
    await importOriginal<typeof import("@langfuse/shared/src/server")>();
  h.fetchWithSecureRedirects.mockImplementation((...args: unknown[]) =>
    (actual.fetchWithSecureRedirects as any)(...args),
  );
  return {
    ...actual,
    logger: h.logger,
    fetchWithSecureRedirects: h.fetchWithSecureRedirects,
    whitelistFromEnv: vi.fn(() => ({ hosts: [], ips: [], ip_ranges: [] })),
    validateWebhookURL: vi.fn(async () => undefined),
    buildWebhookRequestHeaders: vi.fn(() => ({
      headers: { "content-type": "application/json" },
      sensitiveHeaderNames: [],
    })),
    getConsecutiveAutomationFailures: vi.fn(async () => 0),
    getAutomationById: vi.fn(async () => ({
      id: "automation-1",
      name: "Test Automation",
      trigger: { id: "trigger-1" },
      action: { id: "action-1", type: "WEBHOOK" },
    })),
    getActionByIdWithSecrets: vi.fn(async () => ({
      id: "action-1",
      type: "WEBHOOK",
      config: {
        type: "WEBHOOK",
        url: "https://host.example/hook/path?sig=super-secret-sig",
        requestHeaders: {},
        displayHeaders: {},
        secretKey: "enc",
        displaySecretKey: "sec***",
        apiVersion: { prompt: "v1", "project-notification": "v1" },
      },
    })),
    ProjectNotificationWebhookQueueEventSchema: {
      safeParse: vi.fn((payload: unknown) => ({ success: true, data: payload })),
    },
    redis: undefined,
  };
});

// Imported after mocks are registered.
import { addSecureOutboundConnectionValidation } from "@langfuse/shared/src/server";
import { executeWebhook } from "../queues/webhooks";

// A project-notification delivery (no auto-disable branch) with the signed URL
// baked into the action config above. skipValidation is intentionally OMITTED so
// the redirect-validation branch — where the fix threads its per-address attempt
// window — actually runs.
function deliveryInput() {
  return {
    projectId: "project-1",
    automationId: "automation-1",
    executionId: "execution-1",
    payload: {
      type: "project-notification",
      apiVersion: "v1",
      event: {
        eventType: "blob-export-failed",
        severity: "ALERT",
        projectId: "project-1",
        projectName: "Test Project",
        resourceId: "resource-1",
        resourceName: "bucket-1",
        message: "Blob storage export failed.",
      },
    },
  };
}

// Every string a structured logger could emit across all its calls, walked
// depth-first through strings, errors (name/message/stack/cause), arrays, and
// plain objects — the same surface winston copies into a JSON log line.
function allLoggedText(): string {
  const parts: string[] = [];
  const visit = (value: unknown, depth: number): void => {
    if (value == null || depth > 6) return;
    if (
      typeof value === "string" ||
      typeof value === "number" ||
      typeof value === "boolean"
    ) {
      parts.push(String(value));
      return;
    }
    if (value instanceof Error) {
      parts.push(value.name, value.message, String(value.stack ?? ""));
      visit((value as Error & { cause?: unknown }).cause, depth + 1);
      return;
    }
    if (Array.isArray(value)) {
      value.forEach((entry) => visit(entry, depth + 1));
      return;
    }
    if (typeof value === "object") {
      Object.values(value as Record<string, unknown>).forEach((entry) =>
        visit(entry, depth + 1),
      );
    }
  };
  for (const level of [
    h.logger.info,
    h.logger.warn,
    h.logger.error,
    h.logger.debug,
  ]) {
    level.mock.calls.forEach((call) => call.forEach((arg) => visit(arg, 0)));
  }
  return parts.join("\n");
}

// The per-address connection-attempt window an agent will actually apply, in
// ms, resolved the way undici resolves it for each connection: top-level
// `autoSelectFamily` / `autoSelectFamilyAttemptTimeout` options apply when
// `autoSelectFamily` is a boolean, the agent's `connect` options override them,
// and anything left unset falls back to the runtime default. Infinity means
// happy-eyeballs address selection is off, so no per-address window applies.
// undici keeps an Agent's construction options under its `options` symbol.
function effectiveAttemptWindowMs(dispatcher: unknown): number {
  const sym = Object.getOwnPropertySymbols(dispatcher ?? {}).find(
    (s) => s.description === "options",
  );
  const opts = (sym ? (dispatcher as any)[sym] : undefined) ?? {};
  let autoSelect: unknown = undefined;
  let attempt: unknown = undefined;
  if (typeof opts.autoSelectFamily === "boolean") {
    autoSelect = opts.autoSelectFamily;
    attempt = opts.autoSelectFamilyAttemptTimeout;
  }
  const connect = opts.connect;
  if (connect && typeof connect === "object") {
    if ("autoSelectFamily" in connect) autoSelect = connect.autoSelectFamily;
    if ("autoSelectFamilyAttemptTimeout" in connect) {
      attempt = connect.autoSelectFamilyAttemptTimeout;
    }
  }
  if (autoSelect === undefined) autoSelect = net.getDefaultAutoSelectFamily();
  if (autoSelect === false) return Infinity;
  return typeof attempt === "number"
    ? attempt
    : net.getDefaultAutoSelectFamilyAttemptTimeout();
}

describe("worker webhook delivery — redaction + wire + timeout contract", () => {
  beforeEach(() => {
    h.logger.info.mockClear();
    h.logger.warn.mockClear();
    h.logger.error.mockClear();
    h.logger.debug.mockClear();
    h.fetchWithSecureRedirects.mockClear();
    h.executionUpdate.mockClear();
    h.globalFetch.mockClear();
    vi.stubGlobal("fetch", h.globalFetch);
  });

  it("keeps the signed secret out of every log and stored error", async () => {
    await executeWebhook(deliveryInput());

    const logged = allLoggedText();
    expect(logged).not.toContain(SECRET);

    // The failed delivery wrote an error row.
    expect(h.executionUpdate).toHaveBeenCalled();
    const storedError = String(
      h.executionUpdate.mock.calls[0]?.[0]?.data?.error ?? "",
    );
    expect(storedError).not.toContain(SECRET);

    // The destination host is still visible in the logs.
    expect(logged).toContain(DEST_HOST);
  });

  it("sends the full unmodified URL on the wire", async () => {
    await executeWebhook(deliveryInput());

    expect(h.globalFetch).toHaveBeenCalled();
    const wireUrl = String(h.globalFetch.mock.calls[0]?.[0]);
    expect(wireUrl).toBe(DELIVERY_URL);
    expect(wireUrl).toContain(SECRET);
  });

  it("sends the webhook through an agent that outlasts the default per-address attempt window", async () => {
    await executeWebhook(deliveryInput());

    expect(h.globalFetch).toHaveBeenCalled();
    const dispatcher = (h.globalFetch.mock.calls[0]?.[1] as any)?.dispatcher;
    expect(dispatcher).toBeDefined();
    expect(effectiveAttemptWindowMs(dispatcher)).toBeGreaterThan(
      NODE_DEFAULT_ATTEMPT_TIMEOUT_MS,
    );
  });

  it("leaves an ordinary outbound caller on the runtime's default window", async () => {
    await executeWebhook(deliveryInput());

    const ordinary = (
      addSecureOutboundConnectionValidation(
        {},
        {
          whitelist: { hosts: [], ips: [], ip_ranges: [] },
          logContext: "LLM connection",
        },
      ) as { dispatcher?: unknown }
    ).dispatcher;
    expect(ordinary).toBeDefined();
    expect(net.getDefaultAutoSelectFamilyAttemptTimeout()).toBe(
      NODE_DEFAULT_ATTEMPT_TIMEOUT_MS,
    );
    expect(effectiveAttemptWindowMs(ordinary)).toBe(
      NODE_DEFAULT_ATTEMPT_TIMEOUT_MS,
    );
  });
});
