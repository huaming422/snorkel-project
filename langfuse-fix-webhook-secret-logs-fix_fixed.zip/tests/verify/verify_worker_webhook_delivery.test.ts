// @ts-nocheck
//
// Behavioral checks at the worker's webhook-delivery boundary. They drive the
// pre-existing worker entry point `executeWebhook` (worker/src/queues/webhooks)
// over deliveries to a signed URL, with prisma, the worker env, encryption and
// the automation repository reads mocked. The shared `fetchWithSecureRedirects`
// runs for real; only the global `fetch` it ends in is stubbed, so the request
// init it builds, including the pooled agent the request is sent through, is
// observable. The shared logger is the real one with its methods recorded, so
// lines written inside the shared outbound layer are seen as well.
//
// What is checked:
//   - for a delivery that answers 500, one that is aborted at the request
//     timeout and one that follows a redirect, the URL's secrets appear on no
//     logger call and in no stored error, while the logs and the stored error
//     still name the destination host and the reason;
//   - the request is made to the full, unmodified URL;
//   - the agent the webhook request is sent through keeps a per-address
//     connection attempt open past the operating system's first SYN
//     retransmit at about one second, also when a GitHub dispatch delivery
//     was sent first in the same process;
//   - an analytics exporter's request in the same process still gets the
//     runtime's default connection-attempt window.
//
// The root `@langfuse/shared` barrel is mocked with the few runtime symbols
// webhooks.ts takes from it, because its built entry fails to initialise under
// this harness; `@langfuse/shared/src/server` is kept real via importOriginal.

import { EventEmitter } from "node:events";
import net from "node:net";
import tls from "node:tls";
import { beforeEach, describe, expect, it, vi } from "vitest";

// The delivery URL under test: a signed callback whose shared secrets ride the
// query string under more than one name.
const DELIVERY_URL =
  "https://host.example/hook/path?api-version=2016-06-01&sig=super-secret-sig&code=func-secret-code";
const SECRETS = ["super-secret-sig", "func-secret-code"];
const DEST_HOST = "host.example";

// Node 24's per-address connection-attempt default with happy-eyeballs address
// selection on.
const NODE_DEFAULT_ATTEMPT_TIMEOUT_MS = 250;
// Linux sends the first SYN retransmit about one second after a lost SYN.
const FIRST_SYN_RETRANSMIT_MS = 1_000;

// All captured spies/fns live in a hoisted record so the hoisted vi.mock
// factories below may reference them safely (vitest lifts vi.mock above imports).
const h = vi.hoisted(() => {
  const executionUpdate = vi.fn(async () => undefined);
  const triggerUpdate = vi.fn(async () => undefined);
  const deliveryUrl =
    "https://host.example/hook/path?api-version=2016-06-01&sig=super-secret-sig&code=func-secret-code";
  // The network call the real implementation ends in.
  const globalFetch = vi.fn(
    async () => new Response('{"error":"nope"}', { status: 500 }),
  );
  return {
    logSpies: {} as Record<string, any>,
    executionUpdate,
    triggerUpdate,
    globalFetch,
    deliveryUrl,
    // Which action the automation under test carries.
    actionType: "WEBHOOK" as "WEBHOOK" | "GITHUB_DISPATCH",
  };
});

// Root `@langfuse/shared` barrel: its dist is broken under this harness, so we
// supply only the runtime symbols webhooks.ts imports from it. Type-only imports
// (AutomationDomain, ActionDomainWithSecrets) are erased and need nothing here.
vi.mock("@langfuse/shared", () => {
  class InternalServerError extends Error {
    constructor(message: string) {
      super(message);
      this.name = "InternalServerError";
    }
  }
  class LangfuseNotFoundError extends Error {
    constructor(message: string) {
      super(message);
      this.name = "LangfuseNotFoundError";
    }
  }
  return {
    InternalServerError,
    LangfuseNotFoundError,
    ActionExecutionStatus: {
      COMPLETED: "COMPLETED",
      ERROR: "ERROR",
      PENDING: "PENDING",
      CANCELLED: "CANCELLED",
    },
    JobConfigState: { ACTIVE: "ACTIVE", INACTIVE: "INACTIVE" },
    WebhookDefaultHeaders: {},
    PromptWebhookOutboundSchema: {
      safeParse: (data: unknown) => ({ success: true, data }),
    },
    isWebhookAction: (action: { type?: string }) => action?.type === "WEBHOOK",
    isSlackActionConfig: () => false,
    isGitHubDispatchAction: (action: { type?: string }) =>
      action?.type === "GITHUB_DISPATCH",
  };
});

// Backoff collapsed to a single attempt so the delivery path runs once and
// deterministically; the real retry policy is irrelevant to what we assert.
vi.mock("exponential-backoff", () => ({
  backOff: vi.fn(async (fn: () => Promise<unknown>) => fn()),
}));

// Encryption and the monitor barrel are import-time heavy (the monitor barrel is
// broken under this harness too) and unrelated to the contract; stub them.
vi.mock("@langfuse/shared/encryption", () => ({
  decrypt: vi.fn(() => "signing-secret"),
  createSignatureHeader: vi.fn(() => "t=1,v1=sig"),
}));

vi.mock("@langfuse/shared/monitors/server", () => ({
  MonitorWebhookQueueEventSchema: {
    safeParse: vi.fn((payload: unknown) => ({ success: true, data: payload })),
  },
  buildMonitorAlertSlackMessage: vi.fn(),
}));

// The slack message builder transitively pulls broken modules at import; the
// delivery paths under test never invoke it, so a stub keeps the import graph
// clean.
vi.mock("../features/slack/slackMessageBuilder", () => ({
  SlackMessageBuilder: class {},
}));

// Prisma: capture the ERROR-row write so we can inspect the stored error text.
vi.mock("@langfuse/shared/src/db", () => ({
  prisma: {
    $transaction: vi.fn(async (cb: any) =>
      cb({
        automationExecution: { update: h.executionUpdate },
        trigger: { update: h.triggerUpdate },
      }),
    ),
    automationExecution: { update: vi.fn(async () => undefined) },
  },
  Prisma: {},
}));

// Worker env: only the fields the delivery and analytics paths read.
vi.mock("../env", () => ({
  env: {
    LANGFUSE_WEBHOOK_TIMEOUT_MS: 10_000,
    LANGFUSE_WEBHOOK_MAX_REDIRECTS: 5,
  },
}));

// The real shared logger with its methods recorded and silenced, plus the
// handful of repository reads the delivery path makes; every other shared/server
// export stays intact via importOriginal.
vi.mock("@langfuse/shared/src/server", async (importOriginal) => {
  const actual =
    await importOriginal<typeof import("@langfuse/shared/src/server")>();
  for (const level of ["info", "warn", "error", "debug"]) {
    h.logSpies[level] = vi
      .spyOn(actual.logger, level as any)
      .mockImplementation(() => actual.logger as any);
  }
  const actionConfigs = {
    WEBHOOK: {
      id: "action-1",
      type: "WEBHOOK",
      config: {
        type: "WEBHOOK",
        url: h.deliveryUrl,
        requestHeaders: {},
        displayHeaders: {},
        secretKey: "enc",
        displaySecretKey: "sec***",
        apiVersion: { prompt: "v1", "project-notification": "v1" },
      },
    },
    GITHUB_DISPATCH: {
      id: "action-2",
      type: "GITHUB_DISPATCH",
      config: {
        type: "GITHUB_DISPATCH",
        url: "https://api.github.example/repos/org/repo/dispatches",
        eventType: "langfuse-event",
        githubToken: "enc",
        displayGitHubToken: "ghp***",
      },
    },
  };
  return {
    ...actual,
    whitelistFromEnv: vi.fn(() => ({ hosts: [], ips: [], ip_ranges: [] })),
    validateWebhookURL: vi.fn(async () => undefined),
    buildWebhookRequestHeaders: vi.fn(() => ({
      headers: { "content-type": "application/json" },
      sensitiveHeaderNames: [],
    })),
    getConsecutiveAutomationFailures: vi.fn(async () => 0),
    getAutomationById: vi.fn(async () => ({
      id: "automation-1",
      name: "Test Automation",
      trigger: { id: "trigger-1" },
      action: {
        id: actionConfigs[h.actionType].id,
        type: h.actionType,
      },
    })),
    getActionByIdWithSecrets: vi.fn(async () => actionConfigs[h.actionType]),
    ProjectNotificationWebhookQueueEventSchema: {
      safeParse: vi.fn((payload: unknown) => ({ success: true, data: payload })),
    },
    redis: undefined,
  };
});

// Imported after mocks are registered.
import { fetchWithSecureRedirects } from "@langfuse/shared/src/server";
import { buildAnalyticsRedirectOptions } from "../features/analyticsIntegrationEgress";
import { executeWebhook } from "../queues/webhooks";

// A project-notification delivery (no auto-disable branch). skipValidation is
// omitted, so the delivery runs with the redirect and connect-time validation
// it has in production.
function deliveryInput() {
  return {
    projectId: "project-1",
    automationId: "automation-1",
    executionId: "execution-1",
    payload: {
      type: "project-notification",
      apiVersion: "v1",
      event: {
        eventType: "blob-export-failed",
        severity: "ALERT",
        projectId: "project-1",
        projectName: "Test Project",
        resourceId: "resource-1",
        resourceName: "bucket-1",
        message: "Blob storage export failed.",
      },
    },
  };
}

async function deliver(actionType: "WEBHOOK" | "GITHUB_DISPATCH" = "WEBHOOK") {
  h.actionType = actionType;
  try {
    await executeWebhook(deliveryInput());
  } catch {
    // Some failures are rethrown to the queue; what was logged and stored is
    // what is inspected.
  }
}

// Every string a structured logger could emit across all its calls, walked
// depth-first through strings, errors (name/message/stack/fields/cause), arrays,
// and plain objects — the same surface winston copies into a JSON log line.
function allLoggedText(): string {
  const parts: string[] = [];
  const visit = (value: unknown, depth: number): void => {
    if (value == null || depth > 6) return;
    if (
      typeof value === "string" ||
      typeof value === "number" ||
      typeof value === "boolean"
    ) {
      parts.push(String(value));
      return;
    }
    if (value instanceof Error) {
      parts.push(value.name, value.message, String(value.stack ?? ""));
      visit({ ...value }, depth + 1);
      visit((value as Error & { cause?: unknown }).cause, depth + 1);
      return;
    }
    if (Array.isArray(value)) {
      value.forEach((entry) => visit(entry, depth + 1));
      return;
    }
    if (typeof value === "object") {
      Object.values(value as Record<string, unknown>).forEach((entry) =>
        visit(entry, depth + 1),
      );
    }
  };
  for (const spy of Object.values(h.logSpies)) {
    spy.mock.calls.forEach((call) => call.forEach((arg) => visit(arg, 0)));
  }
  return parts.join("\n");
}

function storedErrors(): string {
  return h.executionUpdate.mock.calls
    .map((call) => String(call?.[0]?.data?.error ?? ""))
    .join("\n");
}

function expectNoSecret(text: string, extra: string[] = []) {
  for (const secret of [...SECRETS, ...extra]) {
    expect(text).not.toContain(secret);
  }
}

function lastDispatcher(): unknown {
  const calls = h.globalFetch.mock.calls;
  return (calls[calls.length - 1]?.[1] as any)?.dispatcher;
}

// The per-address connection-attempt window an agent will actually apply, in
// ms. undici keeps an Agent's construction options under its `options` symbol.
// When `connect` is a function, undici uses it as the connector as it is, so
// that function is invoked once with the system socket constructors swapped
// for recorders and the socket options it passes are read. Otherwise the
// window is resolved the way undici builds its own connector: top-level
// `autoSelectFamily` / `autoSelectFamilyAttemptTimeout` apply when
// `autoSelectFamily` is a boolean, the agent's `connect` options override them,
// and anything left unset falls back to the runtime default. Infinity means
// happy-eyeballs address selection is off, so no per-address window applies.
async function effectiveAttemptWindowMs(dispatcher: unknown): Promise<number> {
  const sym = Object.getOwnPropertySymbols(dispatcher ?? {}).find(
    (s) => s.description === "options",
  );
  const opts = (sym ? (dispatcher as any)[sym] : undefined) ?? {};
  if (typeof opts.connect === "function") {
    return resolveWindow(await socketOptionsFromConnector(opts.connect));
  }
  let socketOptions: Record<string, unknown> = {};
  if (typeof opts.autoSelectFamily === "boolean") {
    socketOptions = {
      autoSelectFamily: opts.autoSelectFamily,
      autoSelectFamilyAttemptTimeout: opts.autoSelectFamilyAttemptTimeout,
    };
  }
  const connect = opts.connect;
  if (connect && typeof connect === "object") {
    if ("autoSelectFamily" in connect) {
      socketOptions.autoSelectFamily = connect.autoSelectFamily;
    }
    if ("autoSelectFamilyAttemptTimeout" in connect) {
      socketOptions.autoSelectFamilyAttemptTimeout =
        connect.autoSelectFamilyAttemptTimeout;
    }
  }
  return resolveWindow(socketOptions);
}

function resolveWindow(socketOptions: Record<string, unknown>): number {
  const autoSelect =
    typeof socketOptions.autoSelectFamily === "boolean"
      ? socketOptions.autoSelectFamily
      : net.getDefaultAutoSelectFamily();
  if (autoSelect === false) return Infinity;
  return typeof socketOptions.autoSelectFamilyAttemptTimeout === "number"
    ? socketOptions.autoSelectFamilyAttemptTimeout
    : net.getDefaultAutoSelectFamilyAttemptTimeout();
}

// Calls a connector once for an https origin and records the options it hands
// to net.connect / tls.connect. The recorded socket fails right away, so no
// connection is attempted.
async function socketOptionsFromConnector(
  connector: (...args: unknown[]) => unknown,
): Promise<Record<string, unknown>> {
  let recorded: Record<string, unknown> | undefined;
  const socket: any = new EventEmitter();
  for (const method of ["setNoDelay", "setKeepAlive", "setTimeout", "ref", "unref", "destroy"]) {
    socket[method] = () => socket;
  }
  const record = (options: unknown) => {
    recorded = (options as Record<string, unknown>) ?? {};
    queueMicrotask(() => socket.emit("error", new Error("recorded")));
    return socket;
  };
  const netSpy = vi.spyOn(net, "connect").mockImplementation(record as any);
  const tlsSpy = vi.spyOn(tls, "connect").mockImplementation(record as any);
  try {
    await new Promise<void>((resolve) => {
      const timer = setTimeout(resolve, 500);
      try {
        connector(
          {
            hostname: "host.example",
            host: "host.example",
            protocol: "https:",
            port: "443",
            servername: "host.example",
          },
          () => {
            clearTimeout(timer);
            resolve();
          },
        );
      } catch {
        clearTimeout(timer);
        resolve();
      }
    });
  } finally {
    netSpy.mockRestore();
    tlsSpy.mockRestore();
  }
  return recorded ?? {};
}

beforeEach(() => {
  for (const spy of Object.values(h.logSpies)) spy.mockClear();
  h.executionUpdate.mockClear();
  h.globalFetch.mockClear();
  vi.stubGlobal("fetch", h.globalFetch);
});

// Runs first in this file, so the GitHub dispatch delivery is the first
// outbound send of the process.
describe("webhook connection attempt window after another delivery kind", () => {
  it("keeps the webhook's window when a GitHub dispatch delivery was sent first", async () => {
    await deliver("GITHUB_DISPATCH");
    expect(h.globalFetch).toHaveBeenCalledTimes(1);

    await deliver("WEBHOOK");
    expect(h.globalFetch).toHaveBeenCalledTimes(2);
    expect(String(h.globalFetch.mock.calls[1]?.[0])).toBe(DELIVERY_URL);
    expect(await effectiveAttemptWindowMs(lastDispatcher())).toBeGreaterThan(
      FIRST_SYN_RETRANSMIT_MS,
    );
  });
});

describe("worker webhook delivery — redaction + wire + timeout contract", () => {
  it("keeps the secrets out of every log and stored error for a 500 answer", async () => {
    await deliver();

    const logged = allLoggedText();
    expectNoSecret(logged);
    expect(logged).toContain(DEST_HOST);

    // The failed delivery wrote an error row that still says where and why.
    expect(h.executionUpdate).toHaveBeenCalled();
    const stored = storedErrors();
    expectNoSecret(stored);
    expect(stored).toContain(DEST_HOST);
    expect(stored).toContain("500");
  });

  it("keeps the secrets out of every log and stored error for a delivery aborted at the request timeout", async () => {
    h.globalFetch.mockImplementationOnce(async () => {
      throw new DOMException("This operation was aborted", "AbortError");
    });
    await deliver();

    const logged = allLoggedText();
    expectNoSecret(logged);
    expect(logged).toContain(DEST_HOST);

    expect(h.executionUpdate).toHaveBeenCalled();
    const stored = storedErrors();
    expectNoSecret(stored);
    expect(stored).toContain(DEST_HOST);
    expect(stored).toMatch(/time ?out|timed out|abort/i);
  });

  it("keeps the secrets of the URL and of its redirect target out of the logs", async () => {
    const target = "https://host.example/hook/next?token=redirect-secret-token";
    h.globalFetch
      .mockImplementationOnce(
        async () =>
          new Response(null, { status: 302, headers: { Location: target } }),
      )
      .mockImplementationOnce(async () => new Response("ok", { status: 200 }));
    await deliver();

    expect(h.globalFetch).toHaveBeenCalledTimes(2);
    expect(String(h.globalFetch.mock.calls[1]?.[0])).toBe(target);
    const logged = allLoggedText();
    expectNoSecret(logged, ["redirect-secret-token"]);
    expect(logged).toContain(DEST_HOST);
  });

  it("sends the full unmodified URL on the wire", async () => {
    await deliver();

    expect(h.globalFetch).toHaveBeenCalled();
    const wireUrl = String(h.globalFetch.mock.calls[0]?.[0]);
    expect(wireUrl).toBe(DELIVERY_URL);
  });

  it("sends the webhook through an agent whose per-address attempt outlasts the first SYN retransmit", async () => {
    await deliver();

    expect(h.globalFetch).toHaveBeenCalled();
    const dispatcher = lastDispatcher();
    expect(dispatcher).toBeDefined();
    expect(await effectiveAttemptWindowMs(dispatcher)).toBeGreaterThan(
      FIRST_SYN_RETRANSMIT_MS,
    );
  });

  it("leaves an analytics exporter's request on the runtime's default window", async () => {
    await deliver();

    h.globalFetch.mockClear();
    await fetchWithSecureRedirects(
      "https://api.mixpanel.example/import",
      { method: "POST", body: "[]" },
      buildAnalyticsRedirectOptions("Mixpanel integration"),
    );

    expect(h.globalFetch).toHaveBeenCalledTimes(1);
    const dispatcher = lastDispatcher();
    expect(dispatcher).toBeDefined();
    expect(net.getDefaultAutoSelectFamilyAttemptTimeout()).toBe(
      NODE_DEFAULT_ATTEMPT_TIMEOUT_MS,
    );
    expect(await effectiveAttemptWindowMs(dispatcher)).toBe(
      NODE_DEFAULT_ATTEMPT_TIMEOUT_MS,
    );
  });
});
