// @ts-nocheck
//
// Behavioral checks for what the shared outbound layer puts on logged and
// thrown errors when a destination URL carries a secret. They drive the
// pre-existing redirect error classes (RedirectValidationError,
// MaxRedirectsExceededError, CircularRedirectError) and the pre-existing
// fetchWithSecureRedirects entry point, and inspect every serializable surface
// of the resulting error: .message, .stack, enumerable fields and
// JSON.stringify output, down the `cause` chain.
//
// The checks assert that the secret-bearing parts of a URL (query string,
// fragment, userinfo) are absent and that the destination's host and path
// remain readable. They import no symbol beyond those pre-existing exports and
// do not pin an exact redacted rendering.
//
// The URLs, secrets and host/path substrings below are fixtures chosen here.

import { afterEach, describe, expect, it, vi } from "vitest";
import {
  CircularRedirectError,
  MaxRedirectsExceededError,
  RedirectValidationError,
  fetchWithSecureRedirects,
} from "./fetch";

// Fixture secrets. Shaped like a real signed-callback URL (Azure Logic Apps /
// Power Platform SAS: `sig=` in the query) plus userinfo credentials and a
// fragment secret. None of these may survive onto any serializable surface.
const QUERY_SECRET = "super-secret-sig";
const USERINFO_SECRET = "hunter2";
const FRAGMENT_SECRET = "frag-secret";

const SIGNED_URL =
  "https://exporter:hunter2@host.example/hook/path?api-version=2016-06-01&sig=super-secret-sig#frag-secret";

// What an operator must still be able to read: the host (which server) and the
// path (which endpoint on it). The scheme is not required, since whether the
// readable form keeps a leading `https://` is a formatting choice.
const KEPT_HOST = "host.example";
const KEPT_PATH = "/hook/path";

// Every surface a structured logger / tracer / JSON persistence layer can pull
// off a thrown error: enumerable own fields (winston copies these into the log
// line), the message, the stack, and the JSON serialization — repeated down the
// `cause` chain a chain-walking reporter follows.
function serializableSurface(error: unknown): string {
  const parts: string[] = [];
  let current: any = error;
  for (let depth = 0; depth < 6 && current; depth++) {
    parts.push(JSON.stringify(current));
    parts.push(JSON.stringify({ ...current }));
    if (typeof current.message === "string") parts.push(current.message);
    if (typeof current.stack === "string") parts.push(current.stack);
    current = current.cause;
  }
  return parts.join("\n");
}

function assertNoSecretAnywhere(error: Error) {
  const surface = serializableSurface(error);
  expect(error.message).not.toContain(QUERY_SECRET);
  expect(error.message).not.toContain(USERINFO_SECRET);
  expect(error.stack ?? "").not.toContain(QUERY_SECRET);
  expect(error.stack ?? "").not.toContain(USERINFO_SECRET);
  expect(surface).not.toContain(QUERY_SECRET);
  expect(surface).not.toContain(USERINFO_SECRET);
  expect(surface).not.toContain(FRAGMENT_SECRET);
  expect(surface).not.toContain("exporter:hunter2@");
}

function assertDiagnosticSurvives(error: Error) {
  expect(error.message).toContain(KEPT_HOST);
  expect(error.message).toContain(KEPT_PATH);
}

describe("RedirectValidationError redaction", () => {
  it("keeps a signed/credentialed redirect target out of every serializable surface", () => {
    const err = new RedirectValidationError(
      "Blocked IP address detected: 169.254.169.254",
      SIGNED_URL,
      0,
      new Error("blocked-ip"),
    );
    assertNoSecretAnywhere(err);
    assertDiagnosticSurvives(err);
    expect(err.message).toContain("Blocked IP address detected");
    expect(err.redirectUrl).not.toContain(QUERY_SECRET);
    expect(err.redirectUrl).not.toContain(USERINFO_SECRET);
    expect(err.redirectUrl).toContain(KEPT_HOST);
    expect(err.redirectUrl).toContain(KEPT_PATH);
  });

  // A redirect target on a non-http scheme still shows which host it pointed at.
  it("keeps the host of a non-special-scheme redirect target", () => {
    const err = new RedirectValidationError(
      "Blocked IP address detected: 169.254.169.254",
      "gopher://169.254.169.254/x?sig=super-secret-sig",
      0,
      new Error("blocked-ip"),
    );
    assertNoSecretAnywhere(err);
    expect(err.message).toContain("169.254.169.254");
    expect(err.redirectUrl).toContain("169.254.169.254");
  });

  // A credential-free redirect target stays readable: host and path are shown.
  it("leaves a credential-free redirect target readable (no over-redaction)", () => {
    const err = new RedirectValidationError(
      "Blocked IP address detected: 10.0.0.1",
      "https://webhook.example.com/clean/path",
      0,
      new Error("blocked-ip"),
    );
    expect(err.message).toContain("webhook.example.com");
    expect(err.message).toContain("/clean/path");
    expect(err.redirectUrl).toContain("webhook.example.com");
    expect(err.redirectUrl).toContain("/clean/path");
  });
});

describe("MaxRedirectsExceededError redaction", () => {
  it("keeps signed/credentialed chain entries out of every serializable surface", () => {
    const err = new MaxRedirectsExceededError(5, [SIGNED_URL, SIGNED_URL]);
    assertNoSecretAnywhere(err);
    assertDiagnosticSurvives(err);
    for (const entry of err.redirectChain) {
      expect(entry).not.toContain(QUERY_SECRET);
      expect(entry).not.toContain(USERINFO_SECRET);
    }
    expect(err.redirectChain.join(" ")).toContain(KEPT_HOST);
    expect(err.redirectChain.join(" ")).toContain(KEPT_PATH);
  });
});

describe("CircularRedirectError redaction", () => {
  it("keeps signed/credentialed chain entries out of every serializable surface", () => {
    const err = new CircularRedirectError([SIGNED_URL, SIGNED_URL, SIGNED_URL]);
    assertNoSecretAnywhere(err);
    for (const entry of err.redirectChain) {
      expect(entry).not.toContain(QUERY_SECRET);
      expect(entry).not.toContain(USERINFO_SECRET);
    }
    expect(err.redirectChain.join(" ")).toContain(KEPT_HOST);
    expect(err.redirectChain.join(" ")).toContain(KEPT_PATH);
  });
});

describe("unresolvable redirect target", () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  // A signed delivery URL answers with a redirect whose Location header cannot
  // be resolved and itself carries a secret. The delivery fails; the error it
  // fails with names neither secret while still showing the destination host.
  it("keeps both secrets out of the error raised for an unresolvable Location", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(
        async () =>
          new Response(null, {
            status: 302,
            headers: {
              Location: "https://[bad-host/cb?sig=redirect-secret-sig#frag-secret",
            },
          }),
      ),
    );

    let caught: unknown;
    try {
      await fetchWithSecureRedirects(
        "https://host.example/hook/path?sig=super-secret-sig",
        { method: "POST", body: "{}" },
        {
          maxRedirects: 5,
          redirectValidation: {
            validateUrl: async () => undefined,
            whitelist: { hosts: [], ips: [], ip_ranges: [] },
            logContext: "Outbound URL",
          },
        },
      );
    } catch (error) {
      caught = error;
    }

    expect(caught).toBeInstanceOf(Error);
    const surface = serializableSurface(caught);
    expect(surface).not.toContain(QUERY_SECRET);
    expect(surface).not.toContain("redirect-secret-sig");
    expect(surface).not.toContain(FRAGMENT_SECRET);
    expect((caught as Error).message).toContain(KEPT_HOST);
  });
});
