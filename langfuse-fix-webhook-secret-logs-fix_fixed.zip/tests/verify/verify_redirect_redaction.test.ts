// @ts-nocheck
//
// Behavioral checks for what the shared outbound layer writes down when a
// destination URL carries a secret. Every check drives the pre-existing
// fetchWithSecureRedirects entry point with only the global `fetch` it ends in
// stubbed, so each error comes from the place the shared fetch really raises
// it, and every line it logs goes through the shared logger it really uses.
//
// For each failure the checks inspect every serializable surface of the raised
// error (.message, .stack, enumerable fields and JSON.stringify output, down
// the `cause` chain) and every argument of every logger call. The
// secret-bearing parts of a URL (query values, fragment, userinfo) must be
// absent there, while the destination's host and path stay readable. No exact
// redacted rendering is pinned.
//
// The URLs, secrets and host/path substrings below are fixtures chosen here.
// The secrets sit under several query names, as signed callback links from
// different platforms use different ones.

import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  CircularRedirectError,
  MaxRedirectsExceededError,
  RedirectValidationError,
  fetchWithSecureRedirects,
} from "./fetch";
import { logger } from "../logger";

// The delivery URL: userinfo credentials, a query secret and a fragment secret.
const INITIAL_URL =
  "https://exporter:hunter2@host.example/hook/path?api-version=2016-06-01&code=func-secret-code#frag-secret";
const INITIAL_SECRETS = ["hunter2", "func-secret-code", "frag-secret"];

// What an operator must still be able to read: the host (which server) and the
// path (which endpoint on it). Whether a leading `https://` is kept is a
// formatting choice and is not asserted.
const KEPT_HOST = "host.example";
const KEPT_PATH = "/hook/path";

const BLOCK_REASON = "Blocked IP address detected: 169.254.169.254";
const WHITELIST = { hosts: [], ips: [], ip_ranges: [] };

const LEVELS = ["info", "warn", "error", "debug"] as const;
let logSpies: Record<string, ReturnType<typeof vi.spyOn>> = {};

beforeEach(() => {
  logSpies = {};
  for (const level of LEVELS) {
    logSpies[level] = vi
      .spyOn(logger, level)
      .mockImplementation(() => logger as any);
  }
});

afterEach(() => {
  for (const spy of Object.values(logSpies)) spy.mockRestore();
  vi.unstubAllGlobals();
});

// Every string any logger call carried, walked through strings, errors
// (name/message/stack/fields/cause), arrays and plain objects.
function allLoggedText(): string {
  const parts: string[] = [];
  const visit = (value: unknown, depth: number): void => {
    if (value == null || depth > 6) return;
    if (["string", "number", "boolean"].includes(typeof value)) {
      parts.push(String(value));
      return;
    }
    if (value instanceof Error) {
      parts.push(value.name, value.message, String(value.stack ?? ""));
      visit({ ...value }, depth + 1);
      visit((value as any).cause, depth + 1);
      return;
    }
    if (Array.isArray(value)) {
      value.forEach((entry) => visit(entry, depth + 1));
      return;
    }
    if (typeof value === "object") {
      Object.values(value as Record<string, unknown>).forEach((entry) =>
        visit(entry, depth + 1),
      );
    }
  };
  for (const spy of Object.values(logSpies)) {
    spy.mock.calls.forEach((call) => call.forEach((arg) => visit(arg, 0)));
  }
  return parts.join("\n");
}

// Every surface a structured logger, tracer or JSON persistence layer can pull
// off a thrown error, repeated down the `cause` chain.
function serializableSurface(error: unknown): string {
  const parts: string[] = [];
  let current: any = error;
  for (let depth = 0; depth < 6 && current; depth++) {
    parts.push(JSON.stringify(current));
    parts.push(JSON.stringify({ ...current }));
    if (typeof current.message === "string") parts.push(current.message);
    if (typeof current.stack === "string") parts.push(current.stack);
    current = current.cause;
  }
  return parts.join("\n");
}

function expectNoneOf(text: string, secrets: string[]) {
  for (const secret of secrets) expect(text).not.toContain(secret);
}

// Runs one delivery through the real shared fetch. `responses` are returned by
// the stubbed network call in order; `blockRedirects` makes the caller's URL
// validator refuse every redirect target with BLOCK_REASON.
async function drive(
  responses: Array<() => Response>,
  { maxRedirects = 5, blockRedirects = false } = {},
) {
  const wire = vi.fn(async () => {
    const next = responses.shift();
    if (!next) throw new Error("unexpected extra request");
    return next();
  });
  vi.stubGlobal("fetch", wire);
  let caught: unknown;
  let result: unknown;
  try {
    result = await fetchWithSecureRedirects(
      INITIAL_URL,
      { method: "POST", body: "{}" },
      {
        maxRedirects,
        redirectValidation: {
          validateUrl: async () => {
            if (blockRedirects) throw new Error(BLOCK_REASON);
          },
          whitelist: WHITELIST,
          logContext: "Outbound URL",
        },
      },
    );
  } catch (error) {
    caught = error;
  }
  return { caught, result, wire };
}

const redirectTo = (location: string) => () =>
  new Response(null, { status: 302, headers: { Location: location } });

describe("redirect target refused by the URL validator", () => {
  const TARGET =
    "https://admin:s3cr3tpass@host.example/hook/next?token=redirect-secret-token&X-Amz-Signature=amz-secret-sig#next-frag";
  const TARGET_SECRETS = [
    "s3cr3tpass",
    "redirect-secret-token",
    "amz-secret-sig",
    "next-frag",
  ];

  it("keeps every secret off the raised error and the log lines", async () => {
    const { caught } = await drive([redirectTo(TARGET)], {
      blockRedirects: true,
    });

    expect(caught).toBeInstanceOf(RedirectValidationError);
    const err = caught as RedirectValidationError;
    const secrets = [...INITIAL_SECRETS, ...TARGET_SECRETS];
    expectNoneOf(serializableSurface(err), secrets);
    expectNoneOf(String(err.redirectUrl), secrets);
    expectNoneOf(allLoggedText(), secrets);

    // Destination and reason stay readable.
    expect(err.message).toContain(KEPT_HOST);
    expect(err.message).toContain("/hook/next");
    expect(err.message).toContain(BLOCK_REASON);
    expect(String(err.redirectUrl)).toContain(KEPT_HOST);
    expect(allLoggedText()).toContain(KEPT_HOST);
  });

  it("keeps the host of a refused non-http redirect target", async () => {
    const { caught } = await drive(
      [redirectTo("gopher://169.254.169.254/x?sig=gopher-secret-sig")],
      { blockRedirects: true },
    );

    expect(caught).toBeInstanceOf(RedirectValidationError);
    const err = caught as RedirectValidationError;
    expectNoneOf(serializableSurface(err), [
      "gopher-secret-sig",
      ...INITIAL_SECRETS,
    ]);
    expect(err.message).toContain("169.254.169.254");
    expect(String(err.redirectUrl)).toContain("169.254.169.254");
  });

  it("leaves a credential-free redirect target readable", async () => {
    const { caught } = await drive(
      [redirectTo("https://webhook.example.com/clean/path")],
      { blockRedirects: true },
    );

    expect(caught).toBeInstanceOf(RedirectValidationError);
    const err = caught as RedirectValidationError;
    expect(err.message).toContain("webhook.example.com");
    expect(err.message).toContain("/clean/path");
    expect(String(err.redirectUrl)).toContain("webhook.example.com");
    expect(String(err.redirectUrl)).toContain("/clean/path");
  });
});

describe("redirect chain too long", () => {
  it("keeps every hop's secret off the raised error and the log lines", async () => {
    const hop = (n: number) =>
      `https://host.example/hook/hop${n}?token=hop-secret-${n}`;
    const { caught } = await drive(
      [redirectTo(hop(1)), redirectTo(hop(2)), redirectTo(hop(3))],
      { maxRedirects: 2 },
    );

    expect(caught).toBeInstanceOf(MaxRedirectsExceededError);
    const err = caught as MaxRedirectsExceededError;
    const secrets = [...INITIAL_SECRETS, "hop-secret-"];
    expectNoneOf(serializableSurface(err), secrets);
    expectNoneOf(err.redirectChain.join(" "), secrets);
    expectNoneOf(allLoggedText(), secrets);

    expect(err.message).toContain(KEPT_HOST);
    expect(err.message).toContain(KEPT_PATH);
    expect(err.redirectChain.join(" ")).toContain("/hook/hop1");
  });
});

describe("circular redirect", () => {
  it("keeps every secret in the loop off the raised error and the log lines", async () => {
    const { caught } = await drive([
      redirectTo("https://host.example/hook/b?token=loop-secret-token"),
      redirectTo(INITIAL_URL),
    ]);

    expect(caught).toBeInstanceOf(CircularRedirectError);
    const err = caught as CircularRedirectError;
    const secrets = [...INITIAL_SECRETS, "loop-secret-token"];
    expectNoneOf(serializableSurface(err), secrets);
    expectNoneOf(err.redirectChain.join(" "), secrets);
    expectNoneOf(allLoggedText(), secrets);

    expect(err.message).toContain(KEPT_HOST);
    expect(err.redirectChain.join(" ")).toContain(KEPT_PATH);
  });
});

describe("malformed redirect response", () => {
  // The Location header cannot be resolved and carries a secret of its own.
  it("keeps both secrets out of the error raised for an unresolvable Location", async () => {
    const { caught } = await drive([
      redirectTo("https://[bad-host/cb?sig=redirect-secret-sig#bad-frag"),
    ]);

    expect(caught).toBeInstanceOf(Error);
    const secrets = [...INITIAL_SECRETS, "redirect-secret-sig", "bad-frag"];
    expectNoneOf(serializableSurface(caught), secrets);
    expectNoneOf(allLoggedText(), secrets);
    expect((caught as Error).message).toContain(KEPT_HOST);
  });

  it("keeps the secret out of the error raised for a redirect without a Location", async () => {
    const { caught } = await drive([() => new Response(null, { status: 302 })]);

    expect(caught).toBeInstanceOf(Error);
    expectNoneOf(serializableSurface(caught), INITIAL_SECRETS);
    expectNoneOf(allLoggedText(), INITIAL_SECRETS);
    expect((caught as Error).message).toContain(KEPT_HOST);
  });
});

describe("followed redirect", () => {
  it("logs no secret while the requests themselves carry the full URLs", async () => {
    const target = "https://host.example/hook/final?sig=final-secret-sig";
    const { caught, result, wire } = await drive([
      redirectTo(target),
      () => new Response("ok", { status: 200 }),
    ]);

    expect(caught).toBeUndefined();
    expect((result as any).response.status).toBe(200);
    expectNoneOf(allLoggedText(), [...INITIAL_SECRETS, "final-secret-sig"]);

    // The outgoing requests are not redacted.
    expect(String(wire.mock.calls[0]?.[0])).toBe(INITIAL_URL);
    expect(String(wire.mock.calls[1]?.[0])).toBe(target);
  });
});
