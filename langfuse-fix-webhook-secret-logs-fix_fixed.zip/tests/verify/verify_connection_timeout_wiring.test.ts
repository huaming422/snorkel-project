// @ts-nocheck
//
// Behavioral checks on the shared outbound layer's pooled HTTP agents. They use
// the pre-existing exported entry point `addSecureOutboundConnectionValidation`,
// whose returned `.dispatcher` is the pooled agent a request is sent through,
// and read the connection options that agent was built with.
//
// An ordinary outbound caller (one that passes only a whitelist and a log
// context, as the LLM and integration callers do) must keep the runtime's
// default per-address connection-attempt behaviour.

import net from "node:net";
import { describe, expect, it } from "vitest";
import { addSecureOutboundConnectionValidation } from "./connection";

const WHITELIST = { hosts: [], ips: [], ip_ranges: [] };
const LOG_CONTEXT = "Outbound URL";

function dispatcherFor(validationOptions: object) {
  const result = addSecureOutboundConnectionValidation({}, validationOptions) as {
    dispatcher?: unknown;
  };
  return result.dispatcher;
}

// The per-address connection-attempt window an agent will actually apply, in
// ms, resolved the way undici resolves it for each connection: top-level
// `autoSelectFamily` / `autoSelectFamilyAttemptTimeout` options apply when
// `autoSelectFamily` is a boolean, the agent's `connect` options override them,
// and anything left unset falls back to the runtime default. Infinity means
// happy-eyeballs address selection is off, so no per-address window applies.
// undici keeps an Agent's construction options under its `options` symbol.
function effectiveAttemptWindowMs(dispatcher: unknown): number {
  const sym = Object.getOwnPropertySymbols(dispatcher ?? {}).find(
    (s) => s.description === "options",
  );
  const opts = (sym ? (dispatcher as any)[sym] : undefined) ?? {};
  let autoSelect: unknown = undefined;
  let attempt: unknown = undefined;
  if (typeof opts.autoSelectFamily === "boolean") {
    autoSelect = opts.autoSelectFamily;
    attempt = opts.autoSelectFamilyAttemptTimeout;
  }
  const connect = opts.connect;
  if (connect && typeof connect === "object") {
    if ("autoSelectFamily" in connect) autoSelect = connect.autoSelectFamily;
    if ("autoSelectFamilyAttemptTimeout" in connect) {
      attempt = connect.autoSelectFamilyAttemptTimeout;
    }
  }
  if (autoSelect === undefined) autoSelect = net.getDefaultAutoSelectFamily();
  if (autoSelect === false) return Infinity;
  return typeof attempt === "number"
    ? attempt
    : net.getDefaultAutoSelectFamilyAttemptTimeout();
}

describe("outbound connection pool", () => {
  it("returns the same pooled dispatcher for identical options", () => {
    const first = dispatcherFor({ whitelist: WHITELIST, logContext: LOG_CONTEXT });
    const second = dispatcherFor({ whitelist: WHITELIST, logContext: LOG_CONTEXT });
    expect(first).toBeDefined();
    expect(second).toBe(first);
  });

  it("keeps the runtime's default connection-attempt window for an ordinary caller", () => {
    const dispatcher = dispatcherFor({
      whitelist: WHITELIST,
      logContext: "LLM connection",
    });
    expect(dispatcher).toBeDefined();
    // Node 24's default with happy-eyeballs selection on is 250 ms per address.
    expect(net.getDefaultAutoSelectFamilyAttemptTimeout()).toBe(250);
    expect(effectiveAttemptWindowMs(dispatcher)).toBe(250);
  });
});
