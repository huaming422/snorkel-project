// @ts-nocheck
//
// Behavioral checks on the pooled HTTP agents of the shared outbound layer for
// an ordinary caller. A model provider call is driven through the pre-existing
// createSecureLlmFetch entry point with only the global `fetch` it ends in
// stubbed, and the agent that request is sent through is read for the
// per-address connection-attempt window it will apply. That caller must keep
// the runtime's default behaviour.

import { EventEmitter } from "node:events";
import net from "node:net";
import tls from "node:tls";
import { afterEach, describe, expect, it, vi } from "vitest";
import { addSecureOutboundConnectionValidation } from "./connection";
import { createSecureLlmFetch } from "../llm/secureLlmFetch";

const WHITELIST = { hosts: [], ips: [], ip_ranges: [] };
const LOG_CONTEXT = "Outbound URL";

// Node 24's default with happy-eyeballs selection on is 250 ms per address.
const NODE_DEFAULT_ATTEMPT_TIMEOUT_MS = 250;

function dispatcherFor(validationOptions: object) {
  const result = addSecureOutboundConnectionValidation({}, validationOptions) as {
    dispatcher?: unknown;
  };
  return result.dispatcher;
}

// The per-address connection-attempt window an agent will actually apply, in
// ms. undici keeps an Agent's construction options under its `options` symbol.
// When `connect` is a function, undici uses it as the connector as it is, so
// that function is invoked once with the system socket constructors swapped
// for recorders and the socket options it passes are read. Otherwise the
// window is resolved the way undici builds its own connector: top-level
// `autoSelectFamily` / `autoSelectFamilyAttemptTimeout` apply when
// `autoSelectFamily` is a boolean, the agent's `connect` options override them,
// and anything left unset falls back to the runtime default. Infinity means
// happy-eyeballs address selection is off, so no per-address window applies.
async function effectiveAttemptWindowMs(dispatcher: unknown): Promise<number> {
  const sym = Object.getOwnPropertySymbols(dispatcher ?? {}).find(
    (s) => s.description === "options",
  );
  const opts = (sym ? (dispatcher as any)[sym] : undefined) ?? {};
  if (typeof opts.connect === "function") {
    return resolveWindow(await socketOptionsFromConnector(opts.connect));
  }
  let socketOptions: Record<string, unknown> = {};
  if (typeof opts.autoSelectFamily === "boolean") {
    socketOptions = {
      autoSelectFamily: opts.autoSelectFamily,
      autoSelectFamilyAttemptTimeout: opts.autoSelectFamilyAttemptTimeout,
    };
  }
  const connect = opts.connect;
  if (connect && typeof connect === "object") {
    if ("autoSelectFamily" in connect) {
      socketOptions.autoSelectFamily = connect.autoSelectFamily;
    }
    if ("autoSelectFamilyAttemptTimeout" in connect) {
      socketOptions.autoSelectFamilyAttemptTimeout =
        connect.autoSelectFamilyAttemptTimeout;
    }
  }
  return resolveWindow(socketOptions);
}

function resolveWindow(socketOptions: Record<string, unknown>): number {
  const autoSelect =
    typeof socketOptions.autoSelectFamily === "boolean"
      ? socketOptions.autoSelectFamily
      : net.getDefaultAutoSelectFamily();
  if (autoSelect === false) return Infinity;
  return typeof socketOptions.autoSelectFamilyAttemptTimeout === "number"
    ? socketOptions.autoSelectFamilyAttemptTimeout
    : net.getDefaultAutoSelectFamilyAttemptTimeout();
}

// Calls a connector once for an https origin and records the options it hands
// to net.connect / tls.connect. The recorded socket fails right away, so no
// connection is attempted.
async function socketOptionsFromConnector(
  connector: (...args: unknown[]) => unknown,
): Promise<Record<string, unknown>> {
  let recorded: Record<string, unknown> | undefined;
  const socket: any = new EventEmitter();
  for (const method of ["setNoDelay", "setKeepAlive", "setTimeout", "ref", "unref", "destroy"]) {
    socket[method] = () => socket;
  }
  const record = (options: unknown) => {
    recorded = (options as Record<string, unknown>) ?? {};
    queueMicrotask(() => socket.emit("error", new Error("recorded")));
    return socket;
  };
  const netSpy = vi.spyOn(net, "connect").mockImplementation(record as any);
  const tlsSpy = vi.spyOn(tls, "connect").mockImplementation(record as any);
  try {
    await new Promise<void>((resolve) => {
      const timer = setTimeout(resolve, 500);
      try {
        connector(
          {
            hostname: "host.example",
            host: "host.example",
            protocol: "https:",
            port: "443",
            servername: "host.example",
          },
          () => {
            clearTimeout(timer);
            resolve();
          },
        );
      } catch {
        clearTimeout(timer);
        resolve();
      }
    });
  } finally {
    netSpy.mockRestore();
    tlsSpy.mockRestore();
  }
  return recorded ?? {};
}

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("outbound connection pool", () => {
  it("returns the same pooled dispatcher for identical options", () => {
    const first = dispatcherFor({ whitelist: WHITELIST, logContext: LOG_CONTEXT });
    const second = dispatcherFor({ whitelist: WHITELIST, logContext: LOG_CONTEXT });
    expect(first).toBeDefined();
    expect(second).toBe(first);
  });

  it("keeps the runtime's default connection-attempt window for a model provider call", async () => {
    const wire = vi.fn(async () => new Response("{}", { status: 200 }));
    vi.stubGlobal("fetch", wire);

    // A public IP literal, so the provider URL check needs no DNS.
    const llmFetch = createSecureLlmFetch({ logContext: "LLM connection" });
    await llmFetch("https://8.8.8.8/v1/chat/completions", {
      method: "POST",
      body: "{}",
    });

    expect(wire).toHaveBeenCalled();
    const dispatcher = (wire.mock.calls[0]?.[1] as any)?.dispatcher;
    expect(dispatcher).toBeDefined();
    expect(net.getDefaultAutoSelectFamilyAttemptTimeout()).toBe(
      NODE_DEFAULT_ATTEMPT_TIMEOUT_MS,
    );
    expect(await effectiveAttemptWindowMs(dispatcher)).toBe(
      NODE_DEFAULT_ATTEMPT_TIMEOUT_MS,
    );
  });
});
