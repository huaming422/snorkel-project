## Task

We hit a nasty one in production. Someone posted a document through the API with
a weird control-ish character in its source name, and that one document took
graph writes down for the whole instance on the default in-memory backend.
Writes stopped working entirely and nothing would persist until we restarted,
not just that one doc. We've also seen similar names arrive through the
input-directory scan, and once one lands, reading the processing-status and
scan-status endpoints starts failing with 500s for everyone. Uploading a file
already refuses these names; the pasted-text and scan paths let them through, so
the ways a document can enter don't agree with each other.

Can you get the ingress paths on the same page and refuse a source the graph
can't store before it reaches storage or the status endpoints? This is about
what we accept at the door, not how the backends store their data, and not the
library-level insert path that bypasses the API. Documents that already slipped
a bad source in need to stay listable and deletable.
