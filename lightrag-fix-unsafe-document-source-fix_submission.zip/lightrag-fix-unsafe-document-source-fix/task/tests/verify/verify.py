"""Behavioral verifier for lightrag-fix-unsafe-document-source.

The task: a document "source" is stamped verbatim onto every entity/relation
``file_path`` and doubles as the document's identity / dedup key / doc_id seed.
Some code points (ASCII control chars, DEL, surrogates, U+FFFE/U+FFFF) cannot be
stored by the GraphML backend; one such source poisons every later graph write
on the in-memory backend, and a lone-surrogate scanned basename formatted raw
into status history crashes Starlette's ``JSONResponse`` (ensure_ascii=False) so
every later status read 500s. Three ingress paths (upload / pasted-text / scan)
disagreed about what a source may contain; the fix makes them agree and refuses
an unsafe source at the door — while keeping the read/display path non-raising
so already-stored bad rows stay listable and deletable.

Design: every assertion drives a PRE-EXISTING, stable interface and observes
behavior only — it never imports a helper the fix introduces and never asserts a
solution-chosen name, message string, status-code path the contract leaves free,
or internal symbol. Specifically:

  * HTTP ingress (text / texts / upload) and the status read endpoint are driven
    through ``create_document_routes(rag, doc_manager, api_key=...)`` + a FastAPI
    ``TestClient`` — the public router factory the server itself mounts.
  * The scan path is driven through the real ``run_scanning_process`` loop over a
    temp input directory, with ``pipeline_enqueue_scan_batch`` captured to observe
    what was handed off (the same seam the upstream test uses).
  * The read-path normalizer is the pre-existing ``normalize_file_path`` helper,
    called directly — the contract fixes that it must stay non-raising.

The lone surrogate is covered ONLY on the scan path (see the surrogate status
test). It cannot traverse an HTTP JSON body (httpx refuses to UTF-8-encode it),
and at the pasted-text request-model layer Pydantic's native string validation
ALREADY rejects it before the fix — so the fix introduces no observable
accept/reject change there, only a message-wording change the contract leaves
free. Asserting that wording would pin a solution choice, so this suite does not.

Only the observable contract is asserted: 422 (text/texts reject), 400 (upload
reject), safe sources accepted, unsafe scanned file skipped + left on disk + its
neighbour still enqueued, no identity lookup for the rejected name, the status
read survives a surrogate name and still surfaces the offending code point (in
any renderable form — the format is not pinned), and the read normalizer returns
a str. Error wording, helper names, the counter key, and the predicate's return
shape are all left free.
"""

from __future__ import annotations

import asyncio
import importlib
import json
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

# Importing the router module resolves the server config, which parses sys.argv
# and would choke on pytest's own flags. Same guard the repo's own
# document_routes tests use.
_original_argv = sys.argv[:]
sys.argv = [sys.argv[0]]
_dr = importlib.import_module("lightrag.api.routers.document_routes")
_shared_storage = importlib.import_module("lightrag.kg.shared_storage")
sys.argv = _original_argv

from lightrag.base import SourceAbsent  # noqa: E402  (pre-existing public type)
from lightrag.constants import PARSED_DIR_NAME  # noqa: E402

create_document_routes = _dr.create_document_routes
run_scanning_process = _dr.run_scanning_process
normalize_file_path = _dr.normalize_file_path
DocumentManager = _dr.DocumentManager

API_KEY = "test-key"
HEADERS = {"X-API-Key": API_KEY}

# ---------------------------------------------------------------------------
# Unsafe / safe source corpora (stable facts: these code points are the ones
# GraphML cannot store; the safe set is ordinary filenames).
# ---------------------------------------------------------------------------

# Unsafe sources that CAN traverse an HTTP JSON body (everything except a lone
# surrogate, which httpx refuses to UTF-8-encode).
HTTP_UNSAFE = [
    pytest.param("a\x00b.txt", id="nul-U+0000"),
    pytest.param("a\x0bb.txt", id="vtab-U+000B"),
    pytest.param("a\x1fb.txt", id="unit-sep-U+001F"),
    pytest.param("a\tb.txt", id="tab-U+0009"),
    pytest.param("a\nb.txt", id="newline-U+000A"),
    pytest.param("a\x7fb.txt", id="del-U+007F"),
    pytest.param("a￾b.txt", id="noncharacter-U+FFFE"),
    pytest.param("a￿b.txt", id="noncharacter-U+FFFF"),
]

SAFE_SOURCES = [
    pytest.param("report.pdf", id="ascii"),
    pytest.param("报告 2026.docx", id="cjk-spaces"),
    pytest.param("a-b_c.d.txt", id="punctuation"),
    pytest.param("emoji \U0001f600.md", id="emoji"),
    pytest.param("spaces are fine.txt", id="spaces"),
]

# Full unsafe set for the read-path / request-model checks (includes the lone
# surrogate, which never goes over HTTP).
ALL_UNSAFE_VALUES = [
    "a\x00b.txt",
    "a\x0bb.txt",
    "a\x1fb.txt",
    "a\tb.txt",
    "a\nb.txt",
    "a\x7fb.txt",
    "a\ud800b.txt",  # lone surrogate
    "a￾b.txt",
    "a￿b.txt",
]


# ---------------------------------------------------------------------------
# Test doubles + fixtures (test infrastructure, not implementation discovery).
# ---------------------------------------------------------------------------


class _AcceptingDocStatus:
    """Nothing is a duplicate: a safe source therefore reaches the accept path
    and an unsafe one can only be stopped by the guard under test."""

    async def get_doc_by_file_basename(self, _basename):
        return None


def _make_http_rag(workspace):
    async def _noop(*_a, **_k):
        return None

    return SimpleNamespace(
        doc_status=_AcceptingDocStatus(),
        workspace=workspace,
        max_pending_documents=0,
        apipeline_enqueue_documents=_noop,
        apipeline_process_enqueue_documents=_noop,
        addon_params={},
    )


def _make_client(rag, doc_manager):
    router = create_document_routes(rag, doc_manager, api_key=API_KEY)
    app = FastAPI()
    app.include_router(router)
    app.state.background_tasks = set()
    return TestClient(app)


@pytest.fixture
def http_client():
    """A TestClient over the real router with a temp input dir and initialised
    shared storage (the accept path reserves a pipeline slot)."""
    workspace = f"verify-{uuid4().hex[:8]}"
    _shared_storage.initialize_share_data()
    asyncio.new_event_loop().run_until_complete(
        _shared_storage.initialize_pipeline_status(workspace=workspace)
    )
    tmp = Path(tempfile.mkdtemp())
    rag = _make_http_rag(workspace)
    doc_manager = DocumentManager(str(tmp))
    with _make_client(rag, doc_manager) as client:
        yield client


# --- scan doubles ----------------------------------------------------------


class _RecordingDocStatus:
    """Records every identity lookup and resolves them all to "absent", so a
    file that is skipped can only have been skipped by the guard under test and
    we can assert the rejected name was never looked up."""

    def __init__(self):
        self.lookups: list[str] = []

    async def resolve_doc_source_strict(self, canonical_source_key):
        self.lookups.append(canonical_source_key)
        return SourceAbsent()

    async def get_full_docs_by_ids(self, _doc_ids, *, strict=False):
        return {}

    async def get_doc_by_file_basename(self, _basename):
        return None


class _ScanRag:
    def __init__(self, workspace):
        self.workspace = workspace
        self.doc_status = _RecordingDocStatus()
        self.full_docs = SimpleNamespace(
            get_by_id=self._missing,
            get_by_id_strict=self._missing,
            supports_strict_point_reads=True,
        )
        self.max_pending_documents = 0
        self.addon_params = {}

    async def _missing(self, _doc_id):
        return None

    async def arollback_failed_custom_chunk_patches(self, **_kwargs):
        return {"rolled_back": [], "failed": []}

    async def apipeline_process_enqueue_documents(self):
        return None

    async def apipeline_enqueue_documents(self, *_a, **_k):
        return None


async def _run_scan(filenames):
    """Run one real scan over ``filenames`` in a fresh temp input dir.

    Returns (rag, doc_manager, tmp_path, enqueued_basenames).
    """
    _shared_storage.initialize_share_data()
    workspace = f"scan-{uuid4().hex[:8]}"
    rag = _ScanRag(workspace)
    await _shared_storage.initialize_pipeline_status(workspace=workspace)
    tmp = Path(tempfile.mkdtemp())
    doc_manager = DocumentManager(str(tmp))
    for name in filenames:
        (doc_manager.input_dir / name).write_text("body", encoding="utf-8")

    enqueued: list[str] = []
    original = _dr.pipeline_enqueue_scan_batch

    async def _capture_batch(_rag, candidates, _track_id=None):
        enqueued.extend(candidate.path.name for candidate in candidates)
        return len(candidates)

    _dr.pipeline_enqueue_scan_batch = _capture_batch
    try:
        await run_scanning_process(rag, doc_manager, "verify-track")
    finally:
        _dr.pipeline_enqueue_scan_batch = original
    return rag, doc_manager, tmp, enqueued


async def _pipeline_history(workspace):
    status = await _shared_storage.get_namespace_data(
        "pipeline_status", workspace=workspace
    )
    return list(status.get("history_messages", []))


# ---------------------------------------------------------------------------
# criterion: text_ingress_rejects_unsafe
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("value", HTTP_UNSAFE)
def test_text_ingress_rejects_unsafe_sources(http_client, value):
    """POST /documents/text with an unsafe file_source is rejected (4xx),
    not accepted and forwarded to storage.  The precise code (400, 422, …)
    is implementation-specific; the contract is rejection before storage."""
    resp = http_client.post(
        "/documents/text", headers=HEADERS, json={"text": "hello", "file_source": value}
    )
    assert 400 <= resp.status_code < 500, resp.text


@pytest.mark.parametrize("value", SAFE_SOURCES)
def test_text_ingress_accepts_safe_sources(http_client, value):
    """An ordinary source (ASCII, CJK, spaces, dots, emoji) is still accepted."""
    resp = http_client.post(
        "/documents/text", headers=HEADERS, json={"text": "hello", "file_source": value}
    )
    assert resp.status_code == 200, resp.text


# ---------------------------------------------------------------------------
# criterion: texts_list_any_position
# ---------------------------------------------------------------------------


def test_texts_list_rejects_offender_in_any_position(http_client):
    """POST /documents/texts rejects (4xx) a file_sources list holding an
    offender anywhere, not just the first element.  The precise code is
    implementation-specific; the contract is rejection before storage."""
    resp = http_client.post(
        "/documents/texts",
        headers=HEADERS,
        json={
            "texts": ["a", "b", "c"],
            "file_sources": ["ok.txt", "bad\x0b.txt", "also-ok.txt"],
        },
    )
    assert 400 <= resp.status_code < 500, resp.text


def test_texts_list_accepts_all_safe(http_client):
    """A list of only safe sources is still accepted."""
    resp = http_client.post(
        "/documents/texts",
        headers=HEADERS,
        json={"texts": ["a", "b"], "file_sources": ["ok.txt", "fine.txt"]},
    )
    assert resp.status_code == 200, resp.text


# ---------------------------------------------------------------------------
# criterion: upload_contract_preserved
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "value",
    [
        pytest.param("a￾b.txt", id="noncharacter-U+FFFE"),
        pytest.param("a￿b.txt", id="noncharacter-U+FFFF"),
    ],
)
def test_upload_rejects_unsafe_filenames(http_client, value):
    """POST /documents/upload keeps its 400 contract for unsafe filenames, now
    extended to the superset characters (non-characters) that the fix adds.

    Note: the pre-existing ASCII control / DEL rejection cannot be exercised over
    the HTTP multipart surface — httpx percent-encodes a control char in a
    filename header (``a\\x0bb.txt`` -> ``a%0Bb.txt``) before it reaches the
    handler, so it never arrives raw. The non-characters are the fix's genuinely
    new, HTTP-transmittable additions to the rule (accepted before, 400 after)."""
    resp = http_client.post(
        "/documents/upload",
        headers=HEADERS,
        files={"file": (value, b"body", "text/plain")},
    )
    assert resp.status_code == 400, resp.text


@pytest.mark.parametrize(
    "value",
    [
        pytest.param("report.pdf", id="ascii"),
        pytest.param("报告 2026.docx", id="cjk-spaces"),
        pytest.param("spaces are fine.txt", id="spaces"),
    ],
)
def test_upload_accepts_safe_filenames(http_client, value):
    """Previously-accepted filenames are unaffected (the new rule is a strict
    superset of the old upload check)."""
    resp = http_client.post(
        "/documents/upload",
        headers=HEADERS,
        files={"file": (value, b"body", "text/plain")},
    )
    assert resp.status_code == 200, resp.text


# ---------------------------------------------------------------------------
# criterion: scan_skips_unsafe
# ---------------------------------------------------------------------------


def test_scan_skips_unsafe_basename_and_keeps_it_on_disk():
    """A scanned file whose basename holds an unsafe character is NOT enqueued;
    a safe neighbour in the same scan IS; the unsafe file stays in the input
    directory (not archived / renamed / deleted)."""
    unsafe = "scan\x0bsource.txt"

    async def _run():
        rag, _dm, tmp, enqueued = await _run_scan([unsafe, "clean.txt"])
        assert enqueued == ["clean.txt"]
        assert (tmp / unsafe).exists()
        parsed_dir = tmp / PARSED_DIR_NAME
        archived = (
            [p.name for p in parsed_dir.iterdir()] if parsed_dir.exists() else []
        )
        assert archived == []

    asyncio.run(_run())


# ---------------------------------------------------------------------------
# criterion: scan_rejects_before_identity
# ---------------------------------------------------------------------------


def test_scan_rejects_before_identity_resolution():
    """The refusal is scoped to the unsafe file and happens before document
    identity resolution: no doc_status lookup for the rejected name, while the
    clean name IS resolved."""
    unsafe = "scan\x0bsource.txt"

    async def _run():
        rag, _dm, _tmp, _enqueued = await _run_scan([unsafe, "clean.txt"])
        assert rag.doc_status.lookups == ["clean.txt"]

    asyncio.run(_run())


# ---------------------------------------------------------------------------
# criterion: status_endpoints_survive_surrogate
# ---------------------------------------------------------------------------


def test_scan_of_surrogate_name_does_not_crash_and_stays_renderable():
    """A lone surrogate is the one unsafe character that makes JSON rendering
    raise (``json.dumps(..., ensure_ascii=False).encode('utf-8')`` is how
    Starlette renders ``/documents/pipeline_status`` and ``/documents/scan/status``).

    Behavioral contract, format-free:
      * the surrogate-named file is skipped WITHOUT aborting the scan — its clean
        neighbour is still enqueued (before the fix, the surrogate name crashes
        the scan outright, so the clean neighbour is lost too);
      * whatever the scan recorded stays JSON-renderable the way Starlette
        renders it (no UnicodeEncodeError), so the status endpoint still answers
        200 instead of 500;
      * the raw surrogate is not interpolated verbatim into the response (which
        is exactly what would reintroduce the encode crash downstream).

    What the operator-facing message looks like — whether it names the code point
    as ``U+DCFF``, ``\\udcff``, a decimal ordinal, or an ``ascii()``/``repr()``
    escape — is a free solution choice and is deliberately NOT asserted."""
    surrogate = "scan\udcffsource.txt"

    async def _run():
        rag, _dm, tmp, enqueued = await _run_scan([surrogate, "clean.txt"])

        # Surrogate skipped, clean neighbour survives (pre-fix: scan aborts, []).
        assert enqueued == ["clean.txt"]
        assert (tmp / surrogate).exists()

        # Recorded history renders the way Starlette renders a status response.
        history = await _pipeline_history(rag.workspace)
        json.dumps(history, ensure_ascii=False).encode("utf-8")

        # The real status endpoint answers (no 500) and never echoes the raw name.
        with _make_client(rag, _dm) as client:
            resp = client.get("/documents/pipeline_status", headers=HEADERS)
            assert resp.status_code == 200, resp.text
            assert surrogate not in resp.text

    try:
        asyncio.run(_run())
    except (OSError, UnicodeEncodeError) as exc:  # pragma: no cover
        pytest.skip(f"filesystem rejects non-UTF-8 filenames: {exc}")


# ---------------------------------------------------------------------------
# criterion: read_path_stays_nonraising (pass_to_pass)
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("value", ALL_UNSAFE_VALUES)
def test_read_path_normalizer_stays_nonraising(value):
    """The shared read/display normalizer must stay non-raising for an
    already-stored bad value so existing listings and deletes keep working:
    normalizing returns a str rather than raising."""
    result = normalize_file_path(value)
    assert isinstance(result, str)
