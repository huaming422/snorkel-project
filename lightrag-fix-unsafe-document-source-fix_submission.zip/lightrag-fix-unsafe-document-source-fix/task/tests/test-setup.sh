#!/bin/bash
# Setup for the lightrag-fix-unsafe-document-source verifier.
#
# The image bakes the full dependency closure at the base commit into
# /opt/venv (block 7), with the uv cache warm. The agent phase is offline
# (agent_offline = true), so everything the verifier needs to import the
# router and drive it through a FastAPI TestClient is already present. This
# script re-syncs offline-first (the agent may have edited pyproject.toml /
# uv.lock) and exports the repo name for the harness. No lazy network install.

set -euo pipefail

REPO_DIR="/repo/LightRAG"
cd "$REPO_DIR"

# Offline-first: the closure is baked, so --offline must succeed. Fall back to
# a logged online sync only if the agent added a dependency the bake lacks
# (the smoke gate's offline fold runs this with the network cut and will flag
# any real fetch).
export VIRTUAL_ENV=/opt/venv UV_PROJECT_ENVIRONMENT=/opt/venv
if ! uv sync --frozen --all-extras --extra test --offline > /tmp/test-setup-py.log 2>&1; then
    echo "offline uv sync failed; retrying online" >&2
    tail -20 /tmp/test-setup-py.log >&2 || true
    uv sync --frozen --all-extras --extra test > /tmp/test-setup-py.log 2>&1 \
        || { tail -40 /tmp/test-setup-py.log >&2; exit 1; }
fi

export REPO_NAME=LightRAG
