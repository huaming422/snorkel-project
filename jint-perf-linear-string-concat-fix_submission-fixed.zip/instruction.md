We run user scripts through Jint in a .NET app, and some of them build a big string in a loop with plain `+`.
Something like `result = result + piece` gets slower and hungrier for memory much faster than the input grows.
At a few thousand pieces it already crawls, and with bigger inputs the script just sits there eating memory.
The same loop written with `+=` is fast.
Putting each new piece in front (`result = piece + result`) or adding two pieces per statement (`result = result + a + b`) is as slow as the plain append.

This needs fixing inside Jint, since we don't control the scripts.
Building a string with `+` in a loop should cost time and memory roughly in line with how long the string ends up, for all of the forms above.
The strings themselves can't change.
Length, indexing, comparisons, string methods and using the result as a Map, Set or object key all have to give the same answers as today.
Reading characters from a string built this way afterwards shouldn't be slower than it is now.
Loops that run a few hundred thousand times have to finish without crashing the process.
`+=` should keep working as it does, and going over the maximum string length should still throw `RangeError: Invalid string length`.
