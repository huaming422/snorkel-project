#!/usr/bin/env bash
# Runs the string-accumulation behavioral checks.
#
# The verify files are delivered flat into /tests/verify/ (the project file and
# the test source). This script assembles them into a scratch project directory
# outside the repo tree, then runs `dotnet test` against the repo's public Jint
# library. The scratch dir holds only these two files, so the SDK's default
# source glob picks up exactly the test source and nothing else.
#
# Offline: the three test packages and their transitive closure were restored
# into the NuGet cache at image build time (the repo's own test project pulls
# the same versions), and the Jint library was Release-built, so restore and
# build are cache hits with no network.
#
# Exit code is the suite result: 0 when every check passes, non-zero otherwise.
set -euo pipefail

export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1

VERIFY_DIR="/tests/verify"
PROJECT_DIR="$(mktemp -d /tmp/verify-concat.XXXXXX)"
trap 'rm -rf "$PROJECT_DIR"' EXIT

cp "$VERIFY_DIR/VerifyConcat.csproj" "$PROJECT_DIR/VerifyConcat.csproj"
cp "$VERIFY_DIR/StringConcatVerify.cs" "$PROJECT_DIR/StringConcatVerify.cs"

dotnet test "$PROJECT_DIR/VerifyConcat.csproj" \
    -c Release --nologo \
    2>&1 | tee /tmp/verify-concat.log
