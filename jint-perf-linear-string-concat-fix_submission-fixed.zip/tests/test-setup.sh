#!/usr/bin/env bash
# No services to start and no data to seed. The image already cloned the repo at
# the base commit, restored the NuGet closure for Jint + Jint.Tests across the
# Linux TFMs, and did a Release build, so the solving agent's build and the
# grade-time verifier run offline. This script only reports the toolchain and
# confirms the NuGet cache is warm.
set -euo pipefail

echo "[test-setup] .NET SDK:       $(dotnet --version 2>&1 | head -1)"
echo "[test-setup] Repo root:      /repo/jint"
echo "[test-setup] NuGet cache:    ${NUGET_PACKAGES:-/root/.nuget/packages}"

# Warm-cache sanity: the restore ran at image build time, so the packages dir
# must already be populated. Fail loudly if it is empty (the offline build would
# otherwise fail later with a confusing restore error).
pkg_dir="${NUGET_PACKAGES:-/root/.nuget/packages}"
if [ ! -d "$pkg_dir" ] || [ -z "$(ls -A "$pkg_dir" 2>/dev/null)" ]; then
    echo "[test-setup] ERROR: NuGet cache at $pkg_dir is empty; the image did not bake the dependency closure." >&2
    exit 1
fi

echo "[test-setup] Setup complete."
