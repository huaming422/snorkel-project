## Task

operators are setting up image-verification deny rules exactly the way the configuration reference lays them out, but images that should be blocked are getting pulled anyway. the pattern we keep seeing: a rule correctly blocks an image when it's written one way, then fails to catch the same image written a different but equivalent way. the rule is present, it catches one spelling of the reference, and it lets another spelling through that points at the very same image.

the deeper problem is that the decision about whether an image is allowed and the decision about which image actually gets pulled don't agree on what a given reference points to. that disagreement is where the wrong images slip through a deny.

references that no rule covers should keep being allowed, same as today.

figure out why the deny rules are being evaded and fix it.
