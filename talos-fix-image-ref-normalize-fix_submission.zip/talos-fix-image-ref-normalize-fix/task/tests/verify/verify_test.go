// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.

// Exercises the image-verification decision through the pre-existing exported
// entry point verify.ImageSignature only: it seeds ImageVerificationRule
// resources into an in-memory COSI state and asserts the deny / allow outcome
// for each spelling of a reference. It never imports the fix's helpers or
// reads source, so every structurally-different-but-correct normalization
// passes equally. External test package (verify_test); all identifiers are
// uniquely prefixed so this file composes with any sibling test files the
// solution ships.
package verify_test

import (
	"context"
	"errors"
	"testing"

	"github.com/containerd/containerd/v2/core/remotes"
	"github.com/cosi-project/runtime/pkg/state"
	"github.com/cosi-project/runtime/pkg/state/impl/inmem"
	"github.com/cosi-project/runtime/pkg/state/impl/namespaced"
	ocispec "github.com/opencontainers/image-spec/specs-go/v1"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.uber.org/zap"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"

	"github.com/siderolabs/talos/internal/pkg/containers/image/verify"
	"github.com/siderolabs/talos/pkg/machinery/resources/security"
)

// vrefSeedDenyRules installs two deny rules written the way the configuration
// reference documents them: one against an explicit third-party registry and
// one against Docker Hub via the `docker.io/library/<name>` spelling. The
// resources are the stable public COSI type; the matcher is never referenced
// directly.
func vrefSeedDenyRules(ctx context.Context, t *testing.T) state.State {
	t.Helper()

	st := state.WrapCore(namespaced.NewState(inmem.Build))

	for id, pattern := range map[string]string{
		"0000": "registry.k8s.io/*",
		"0001": "docker.io/library/busybox*",
	} {
		rule := security.NewImageVerificationRule(id)
		rule.TypedSpec().ImagePattern = pattern
		rule.TypedSpec().Deny = true

		require.NoError(t, st.Create(ctx, rule))
	}

	return st
}

// A deny rule must block the image it names no matter which interchangeable
// spelling of the reference is presented. Docker Hub alone has several: a bare
// name, the `docker.io` domain, the legacy `index.docker.io` domain, and the
// implicit `library/` namespace all point at the very image a
// `docker.io/library/<name>` deny rule was written for, so none may slip past
// it.
//
// Pre-fix the match key is canonicalized to `index.docker.io/...` while the
// rule is written for `docker.io`, so the Docker Hub spellings are NOT denied
// and these subtests fail. The fix folds every spelling onto one canonical key.
func TestImageSignatureDeniesEquivalentSpellings(t *testing.T) {
	ctx := t.Context()
	st := vrefSeedDenyRules(ctx, t)

	for _, tc := range []struct {
		name     string
		imageRef string
	}{
		{"explicit registry", "registry.k8s.io/pause:3.9"},
		{"docker hub canonical spelling", "docker.io/library/busybox:1.36"},
		{"bare docker hub name", "busybox:1.36"},
		{"legacy docker hub domain", "index.docker.io/library/busybox:1.36"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			resp, err := verify.ImageSignature(ctx, zap.NewNop(), st, nil, nil, tc.imageRef)

			require.Error(t, err, "reference %q is covered by a deny rule and must be denied", tc.imageRef)
			assert.Equal(t, codes.PermissionDenied, status.Code(err),
				"reference %q must be denied with PermissionDenied, got response %v", tc.imageRef, resp)
		})
	}
}

// Tightening the deny path must not start blocking images that were previously
// allowed: a reference no rule covers stays allowed by default, and the
// normalization introduces no spurious matches (a rule's registry must not be
// matched against a repository path, so a tag that happens to look like a
// registry is never part of the match). Passes on both the pre-fix and fixed
// trees; it guards the over-correction where a solution blanket-denies
// anything Docker-Hub-shaped.
func TestImageSignatureDoesNotOverblock(t *testing.T) {
	ctx := t.Context()
	st := vrefSeedDenyRules(ctx, t)

	for _, tc := range []struct {
		name     string
		imageRef string
	}{
		{"unrelated registry", "quay.io/some/image:v1.0.0"},
		{"another unrelated registry", "ghcr.io/siderolabs/kubelet:v1.34.1"},
		{"registry-like tag is not matched", "quay.io/registry.k8s.io:latest"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			resp, err := verify.ImageSignature(ctx, zap.NewNop(), st, nil, nil, tc.imageRef)

			require.NoError(t, err, "reference %q matches no rule and must be allowed", tc.imageRef)
			require.NotNil(t, resp)
			assert.False(t, resp.Verified, "an unmatched reference is allowed by default, not marked verified")
			assert.Equal(t, "no matched rule", resp.Message,
				"reference %q matches no rule, so the default-allow message must be returned", tc.imageRef)
		})
	}
}

// Repository-case guard.
//
// A registry DOMAIN is a DNS name and case-insensitive, but a repository PATH
// is case-sensitive: an uppercase repository component is simply not a valid
// image reference, so it must be rejected as invalid rather than folded into a
// matchable key. This guards the tempting over-correction of lower-casing the
// whole reference to make spellings line up — that would turn `Pause` into
// `pause`, match the `registry.k8s.io/*` deny rule, and wrongly deny a
// reference that should have been rejected as malformed. Passes on both the
// pre-fix tree (the match path's parser already rejects the uppercase path)
// and the fixed tree.
func TestImageSignatureRejectsUppercaseRepository(t *testing.T) {
	ctx := t.Context()
	st := vrefSeedDenyRules(ctx, t)

	resp, err := verify.ImageSignature(ctx, zap.NewNop(), st, nil, nil, "registry.k8s.io/Pause:3.9")

	require.Error(t, err, "an uppercase repository path is not a valid reference and must be rejected, got response %v", resp)
	assert.Equal(t, codes.InvalidArgument, status.Code(err),
		"a malformed reference must be rejected as invalid, not matched against a deny rule")
}

// vrefRecordingResolver records the exact reference string ImageSignature hands
// to the resolver — the spelling the image would actually be pulled and fetched
// under — and then short-circuits, so no network is touched. ImageSignature
// reaches the resolver only once a rule has matched and the rule is neither a
// deny nor a skip; the recorded string is the pull target the match decision
// was just made about.
type vrefRecordingResolver struct{ refs *[]string }

func (r vrefRecordingResolver) Resolve(ctx context.Context, ref string) (string, ocispec.Descriptor, error) {
	*r.refs = append(*r.refs, ref)

	return "", ocispec.Descriptor{}, errors.New("vref: resolve short-circuited after recording the pull target")
}

func (r vrefRecordingResolver) Fetcher(ctx context.Context, ref string) (remotes.Fetcher, error) {
	return nil, errors.New("vref: fetcher unused")
}

func (r vrefRecordingResolver) Pusher(ctx context.Context, ref string) (remotes.Pusher, error) {
	return nil, errors.New("vref: pusher unused")
}

// vrefSeedVerifyRule installs one signature-requiring rule against Docker Hub.
// A reference that matches it is neither allowed outright nor denied: the
// decision continues to the resolve/pull step, which is where the pull target
// is observable.
func vrefSeedVerifyRule(ctx context.Context, t *testing.T) state.State {
	t.Helper()

	st := state.WrapCore(namespaced.NewState(inmem.Build))

	rule := security.NewImageVerificationRule("0000")
	rule.TypedSpec().ImagePattern = "docker.io/library/busybox*"
	rule.TypedSpec().PublicKeyVerifier = &security.ImagePublicKeyVerifierSpec{Certificate: "unused"}

	require.NoError(t, st.Create(ctx, rule))

	return st
}

// The allow/deny decision and the image that actually gets pulled must agree on
// what a reference points to. It is not enough for every spelling of an image
// to reach the same allow/deny verdict: the spelling the decision is made about
// and the spelling handed on to be pulled must be the same one, or a rule can
// be satisfied against one image while a different image is fetched.
//
// This drives ImageSignature with a rule that requires a signature (so the
// decision runs past the match and into the resolve/pull step) and records the
// reference handed to the resolver for several interchangeable spellings of one
// Docker Hub image. Every spelling names the same image, so every pull target
// must be identical.
//
// Pre-fix the match path and the resolve path interpret the reference
// differently, so the targets diverge; a fix that only reconciles the match key
// but leaves the pull path on the original spelling diverges too. Only a
// solution that drives the match and the pull from one shared interpretation
// makes every spelling converge on the same target.
func TestImageSignatureMatchAndPullTargetAgree(t *testing.T) {
	ctx := t.Context()
	st := vrefSeedVerifyRule(ctx, t)

	spellings := []string{
		"docker.io/library/busybox:1.36",
		"busybox:1.36",
		"index.docker.io/library/busybox:1.36",
	}

	pullTargets := make([]string, 0, len(spellings))

	for _, ref := range spellings {
		var captured []string

		resolver := vrefRecordingResolver{refs: &captured}

		_, _ = verify.ImageSignature(ctx, zap.NewNop(), st, resolver, nil, ref)

		require.Lenf(t, captured, 1,
			"reference %q matches the signature-requiring rule, so the decision must continue to the resolve/pull step exactly once; got %d resolve calls",
			ref, len(captured))

		pullTargets = append(pullTargets, captured[0])
	}

	for i := 1; i < len(pullTargets); i++ {
		assert.Equalf(t, pullTargets[0], pullTargets[i],
			"the spellings %q and %q name the same image, so the pull target must be identical; the allow/deny decision and the pull target must agree on which image a reference points to (got %q vs %q)",
			spellings[0], spellings[i], pullTargets[0], pullTargets[i])
	}
}
