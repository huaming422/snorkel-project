#!/usr/bin/env bash
# All Go dependencies are baked into the image at the base commit (offline
# agent phase); the verify package is pure Go and compiles from the warm
# module + build cache with no network. Nothing to install at verifier time.
set -euo pipefail
echo "[test-setup] no-op for talos-fix-image-ref-normalize"
