#!/usr/bin/env bash
# No services to start and no data to seed: the image holds the cargo registry
# and a warm target dir, and the tests in tests/verify are Rust integration
# tests that compile against the checkout.
# Nothing is fetched here, because everything those tests need is already in
# the image.
set -euo pipefail

echo "[test-setup] Rust version:   $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:  $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root: /repo/rspack"
echo "[test-setup] Setup complete."
