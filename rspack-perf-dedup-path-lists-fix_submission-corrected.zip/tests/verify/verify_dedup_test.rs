//! Exercises the file, context and missing path lists of a factorization through
//! `rspack_core`'s public surface:
//!
//!   * `FactorizeInfo::new(diagnostics, related_dep_ids, file_dependencies,
//!     context_dependencies, missing_dependencies)`, which takes three
//!     `InternedPathSet`s.
//!   * `FactorizeInfo::{file_dependencies, context_dependencies,
//!     missing_dependencies}`, each of which returns `&[InternedPath]`.
//!   * `FactorizeInfo::{is_success, diagnostics, related_dep_ids, owner_dep_id}`.
//!   * `rspack_cacheable::{to_bytes, from_bytes}` with a `&()` context, the
//!     persistent cache's round trip.
//!
//! Two kinds of check read what the lists cost. Pointer identity of the slice an
//! accessor returns says whether two factorizations share one element buffer, and
//! this binary's own counting allocator says how many bytes stay allocated. Each
//! test uses path strings of its own, because equal content in another test could
//! keep a list alive.

use std::{
  alloc::{GlobalAlloc, Layout, System},
  sync::{
    Mutex,
    atomic::{AtomicBool, AtomicIsize, AtomicUsize, Ordering},
    mpsc,
  },
  thread,
  time::Duration,
};

use rspack_cacheable::{from_bytes, to_bytes};
use rspack_core::{DependencyId, FactorizeInfo};
use rspack_paths::{InternedPath, InternedPathSet};

struct CountingAllocator;

static LIVE_BYTES: AtomicIsize = AtomicIsize::new(0);

// SAFETY: Every call goes straight to `System`; the counter is only arithmetic.
unsafe impl GlobalAlloc for CountingAllocator {
  unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
    let pointer = unsafe { System.alloc(layout) };
    if !pointer.is_null() {
      LIVE_BYTES.fetch_add(layout.size() as isize, Ordering::Relaxed);
    }
    pointer
  }

  unsafe fn dealloc(&self, pointer: *mut u8, layout: Layout) {
    unsafe { System.dealloc(pointer, layout) };
    LIVE_BYTES.fetch_sub(layout.size() as isize, Ordering::Relaxed);
  }

  unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
    let pointer = unsafe { System.alloc_zeroed(layout) };
    if !pointer.is_null() {
      LIVE_BYTES.fetch_add(layout.size() as isize, Ordering::Relaxed);
    }
    pointer
  }

  unsafe fn realloc(&self, pointer: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    let moved = unsafe { System.realloc(pointer, layout, new_size) };
    if !moved.is_null() {
      LIVE_BYTES.fetch_add(
        new_size as isize - layout.size() as isize,
        Ordering::Relaxed,
      );
    }
    moved
  }
}

#[global_allocator]
static ALLOCATOR: CountingAllocator = CountingAllocator;

fn live_bytes() -> isize {
  LIVE_BYTES.load(Ordering::Relaxed)
}

/// The rounds of the threaded tests take seconds. A lock taken twice on one thread
/// would hang them for good, so each runs under a limit and fails with a message.
const THREADED_TEST_LIMIT_SECS: f64 = 240.0;

fn within_limit(name: &'static str, test: impl FnOnce() + Send + 'static) {
  let multiplier = std::env::var("TIMEOUT_MULTIPLIER")
    .ok()
    .and_then(|value| value.parse::<f64>().ok())
    .unwrap_or(1.0)
    .max(1.0);
  let limit = Duration::from_secs_f64(THREADED_TEST_LIMIT_SECS * multiplier);
  let (done, finished) = mpsc::channel();
  let runner = thread::spawn(move || {
    test();
    let _ = done.send(());
  });
  match finished.recv_timeout(limit) {
    Ok(()) => runner.join().expect("the test body returned"),
    Err(mpsc::RecvTimeoutError::Timeout) => {
      panic!("{name} didn't finish within {limit:?}; a thread is stuck")
    }
    Err(mpsc::RecvTimeoutError::Disconnected) => {
      if let Err(cause) = runner.join() {
        std::panic::resume_unwind(cause);
      }
    }
  }
}

/// Holds threads back until all of them arrive, then lets them go within a few
/// instructions of each other, closer than a blocking barrier can.
struct Gate {
  parties: usize,
  arrived: AtomicUsize,
  opened: AtomicUsize,
  broken: AtomicBool,
}

impl Gate {
  fn new(parties: usize) -> Self {
    Self {
      parties,
      arrived: AtomicUsize::new(0),
      opened: AtomicUsize::new(0),
      broken: AtomicBool::new(false),
    }
  }

  fn wait(&self) -> bool {
    let opened = self.opened.load(Ordering::Acquire);
    if self.arrived.fetch_add(1, Ordering::AcqRel) + 1 == self.parties {
      self.arrived.store(0, Ordering::Release);
      self.opened.store(opened + 1, Ordering::Release);
      return true;
    }
    let mut spins = 0u32;
    while self.opened.load(Ordering::Acquire) == opened {
      if self.broken.load(Ordering::Relaxed) {
        return false;
      }
      spins = spins.wrapping_add(1);
      if spins % 4096 == 0 {
        thread::yield_now();
      } else {
        std::hint::spin_loop();
      }
    }
    true
  }
}

/// Opens the gate for good if a thread panics, so the others don't wait forever.
struct BreakOnPanic<'a>(&'a Gate);

impl Drop for BreakOnPanic<'_> {
  fn drop(&mut self) {
    if thread::panicking() {
      self.0.broken.store(true, Ordering::Relaxed);
    }
  }
}

fn thread_count() -> usize {
  thread::available_parallelism()
    .map(|count| count.get())
    .unwrap_or(2)
    .clamp(2, 4)
}

/// In every round each thread builds what `build` returns, all wait, and then they
/// drop it at the same moment. The next round starts when every drop is done.
fn drop_together<T>(threads: usize, rounds: usize, build: impl Fn(usize) -> T + Sync) {
  let gate = Gate::new(threads);
  thread::scope(|scope| {
    for _ in 0..threads {
      scope.spawn(|| {
        let _guard = BreakOnPanic(&gate);
        for round in 0..rounds {
          let value = build(round);
          if !gate.wait() {
            return;
          }
          drop(value);
          if !gate.wait() {
            return;
          }
        }
      });
    }
  });
}

/// Builds a path set from string literals, inserting in the given order. Two clones
/// of one set iterate identically.
fn path_set(paths: &[&str]) -> InternedPathSet {
  let mut set = InternedPathSet::default();
  for path in paths {
    set.insert(InternedPath::from(*path));
  }
  set
}

/// `count` paths under `folder`.
fn numbered_set(folder: &str, count: usize) -> InternedPathSet {
  let mut set = InternedPathSet::default();
  for index in 0..count {
    set.insert(InternedPath::from(format!("{folder}/{index}.js").as_str()));
  }
  set
}

/// A single related-dependency id: `new` requires at least one.
fn deps() -> Vec<DependencyId> {
  vec![DependencyId::from(1u32)]
}

fn info(
  file: InternedPathSet,
  context: InternedPathSet,
  missing: InternedPathSet,
) -> FactorizeInfo {
  FactorizeInfo::new(Vec::new(), deps(), file, context, missing)
}

fn file_info(file: InternedPathSet) -> FactorizeInfo {
  info(file, InternedPathSet::default(), InternedPathSet::default())
}

/// Whether two accessor slices are views into the same element buffer.
fn same_buffer(a: &[InternedPath], b: &[InternedPath]) -> bool {
  std::ptr::eq(a.as_ptr(), b.as_ptr())
}

fn as_set(list: &[InternedPath]) -> InternedPathSet {
  list.iter().cloned().collect()
}

#[test]
fn equal_file_lists_share_allocation() {
  let set = numbered_set("/share/file", 8);
  let a = file_info(set.clone());
  let b = file_info(set);

  assert_eq!(a.file_dependencies().len(), 8);
  assert_eq!(b.file_dependencies().len(), 8);
  assert!(
    same_buffer(a.file_dependencies(), b.file_dependencies()),
    "two factorizations with identical file path lists must share one backing buffer; \
     distinct pointers mean each kept its own copy",
  );
}

#[test]
fn context_and_missing_lists_share() {
  let context = numbered_set("/share/ctx", 8);
  let missing = numbered_set("/share/miss", 9);
  let a = info(InternedPathSet::default(), context.clone(), missing.clone());
  let b = info(InternedPathSet::default(), context, missing);

  assert!(
    same_buffer(a.context_dependencies(), b.context_dependencies()),
    "equal context dependency lists must share one backing buffer",
  );
  assert!(
    same_buffer(a.missing_dependencies(), b.missing_dependencies()),
    "equal missing dependency lists must share one backing buffer",
  );
}

#[test]
fn long_lists_share_too() {
  for count in [64, 512, 4096] {
    let file = numbered_set(&format!("/long/file{count}"), count);
    let context = numbered_set(&format!("/long/ctx{count}"), count);
    let missing = numbered_set(&format!("/long/miss{count}"), count);
    let a = info(file.clone(), context.clone(), missing.clone());
    let b = info(file, context, missing);
    assert!(
      same_buffer(a.file_dependencies(), b.file_dependencies()),
      "file lists of {count} paths must share",
    );
    assert!(
      same_buffer(a.context_dependencies(), b.context_dependencies()),
      "context lists of {count} paths must share",
    );
    assert!(
      same_buffer(a.missing_dependencies(), b.missing_dependencies()),
      "missing lists of {count} paths must share",
    );
  }
}

#[test]
fn different_file_lists_are_distinct() {
  let base = numbered_set("/distinct/base", 8);
  let mut other_last = base.clone();
  other_last.insert(InternedPath::from("/distinct/one-more.js"));

  let mut swapped_a = numbered_set("/distinct/swap", 7);
  let mut swapped_b = swapped_a.clone();
  swapped_a.insert(InternedPath::from("/distinct/swap/left.js"));
  swapped_b.insert(InternedPath::from("/distinct/swap/right.js"));

  let pairs = [
    (base, other_last),
    (swapped_a, swapped_b),
    (
      numbered_set("/distinct/first", 8),
      numbered_set("/distinct/second", 8),
    ),
  ];
  for (left, right) in pairs {
    let a = file_info(left.clone());
    let b = file_info(right.clone());
    assert!(
      !same_buffer(a.file_dependencies(), b.file_dependencies()),
      "file path lists with different contents must not share a buffer",
    );
    assert_eq!(as_set(a.file_dependencies()), left);
    assert_eq!(as_set(b.file_dependencies()), right);
  }
}

#[test]
fn drop_then_recreate_reshares() {
  let content = numbered_set("/reclaim", 8);
  let first = file_info(content.clone());
  assert_eq!(first.file_dependencies().len(), 8);
  drop(first);

  let second = file_info(content.clone());
  let third = file_info(content);
  assert!(
    same_buffer(second.file_dependencies(), third.file_dependencies()),
    "re-created equal lists must re-share one buffer after the previous list's last \
     handle dropped",
  );
}

#[test]
fn a_dropped_user_leaves_the_others_shared() {
  let content = numbered_set("/others", 8);
  let keeper = file_info(content.clone());

  let passing = file_info(content.clone());
  drop(passing);
  let after_a_drop = file_info(content.clone());
  assert!(
    same_buffer(keeper.file_dependencies(), after_a_drop.file_dependencies()),
    "a new equal list must keep sharing with a live one after another user dropped",
  );
  drop(after_a_drop);

  let copy = keeper.clone();
  assert!(
    same_buffer(keeper.file_dependencies(), copy.file_dependencies()),
    "a clone must share the buffer of what it was cloned from",
  );
  drop(copy);
  let after_a_clone = file_info(content);
  assert!(
    same_buffer(
      keeper.file_dependencies(),
      after_a_clone.file_dependencies()
    ),
    "a new equal list must keep sharing with a live one after a clone of it dropped",
  );
}

#[test]
fn accessor_contents_preserved() {
  let file = path_set(&["/keep/file/a", "/keep/file/b"]);
  let context = path_set(&["/keep/ctx/a"]);
  let missing = path_set(&["/keep/miss/a", "/keep/miss/b", "/keep/miss/c"]);
  let info = FactorizeInfo::new(
    Vec::new(),
    vec![DependencyId::from(7u32), DependencyId::from(9u32)],
    file.clone(),
    context.clone(),
    missing.clone(),
  );

  assert_eq!(as_set(info.file_dependencies()), file);
  assert_eq!(as_set(info.context_dependencies()), context);
  assert_eq!(as_set(info.missing_dependencies()), missing);

  assert!(
    info.is_success(),
    "no diagnostics means a successful factorization"
  );
  assert!(info.diagnostics().is_empty());
  assert_eq!(
    info.related_dep_ids(),
    &[DependencyId::from(7u32), DependencyId::from(9u32)]
  );
  assert_eq!(info.owner_dep_id(), DependencyId::from(7u32));
}

#[test]
fn cacheable_roundtrip_preserves_contents() {
  let file = path_set(&["/cache/file/a", "/cache/file/b"]);
  let context = path_set(&["/cache/ctx/a", "/cache/ctx/b"]);
  let missing = path_set(&["/cache/miss/a"]);
  let original = info(file.clone(), context.clone(), missing.clone());

  let bytes = to_bytes(&original, &()).expect("factorization info should serialize");
  let restored: FactorizeInfo =
    from_bytes(&bytes, &()).expect("factorization info should deserialize");

  assert_eq!(as_set(restored.file_dependencies()), file);
  assert_eq!(as_set(restored.context_dependencies()), context);
  assert_eq!(as_set(restored.missing_dependencies()), missing);
}

#[test]
fn lists_restored_from_the_cache_share_again() {
  let file = numbered_set("/restored/file", 8);
  let context = numbered_set("/restored/ctx", 8);
  let missing = numbered_set("/restored/miss", 8);
  let original = info(file, context, missing);
  let bytes = to_bytes(&original, &()).expect("factorization info should serialize");

  let first: FactorizeInfo = from_bytes(&bytes, &()).expect("should deserialize");
  assert!(
    same_buffer(first.file_dependencies(), original.file_dependencies()),
    "a restored file list must share with an equal list that's alive",
  );
  assert!(
    same_buffer(
      first.context_dependencies(),
      original.context_dependencies()
    ),
    "a restored context list must share with an equal list that's alive",
  );
  assert!(
    same_buffer(
      first.missing_dependencies(),
      original.missing_dependencies()
    ),
    "a restored missing list must share with an equal list that's alive",
  );

  drop(original);
  let second: FactorizeInfo = from_bytes(&bytes, &()).expect("should deserialize");
  assert!(
    same_buffer(first.file_dependencies(), second.file_dependencies()),
    "two restored equal lists must share",
  );
}

#[test]
fn equal_lists_cost_about_one_copy() {
  const USERS: usize = 2_000;
  const PATHS: usize = 256;
  let file = numbered_set("/cost/file", PATHS);
  let context = numbered_set("/cost/ctx", PATHS);
  let missing = numbered_set("/cost/miss", PATHS);
  let mut kept = Vec::with_capacity(USERS);

  let before = live_bytes();
  for _ in 0..USERS {
    kept.push(info(file.clone(), context.clone(), missing.clone()));
  }
  let cost = live_bytes() - before;
  eprintln!("MEASURE cost {cost} of {} private", USERS * 3 * PATHS * 8);

  let private_copies = (USERS * 3 * PATHS * std::mem::size_of::<InternedPath>()) as isize;
  assert!(
    cost < private_copies / 4,
    "{USERS} factorizations with equal lists hold {cost} bytes; one list per factorization \
     would be {private_copies} bytes",
  );
  assert_eq!(kept.len(), USERS);
}

#[test]
fn released_lists_give_their_memory_back() {
  const WARM_UP: usize = 20_000;
  const MEASURED: usize = 400_000;
  const ALLOWED_PER_LIST: isize = 24;
  let shared = numbered_set("/released/shared", 15);
  let one_list = |index: usize| {
    let mut set = shared.clone();
    set.insert(InternedPath::from(
      format!("/released/own/{index}.js").as_str(),
    ));
    drop(file_info(set));
  };

  (0..WARM_UP).for_each(one_list);
  let before = live_bytes();
  (WARM_UP..WARM_UP + MEASURED).for_each(one_list);
  let per_list = (live_bytes() - before) / MEASURED as isize;
  eprintln!("MEASURE per_list {per_list}");

  assert!(
    per_list < ALLOWED_PER_LIST,
    "{per_list} bytes stayed allocated for each of {MEASURED} lists whose last user is gone",
  );
}

/// How low the allocated bytes get while single lists come and go. A table that's swept now
/// and then reaches this right after a sweep, so the figure doesn't depend on when the last
/// sweep ran.
fn settled_bytes(shared: &InternedPathSet, pass: &str) -> isize {
  let mut lowest = isize::MAX;
  for index in 0..100_000 {
    let mut set = shared.clone();
    set.insert(InternedPath::from(
      format!("/settled/{pass}/{index}.js").as_str(),
    ));
    drop(file_info(set));
    lowest = lowest.min(live_bytes());
  }
  lowest
}

#[test]
fn lists_dropped_at_the_same_moment_give_their_memory_back() {
  const MEASURED: usize = 1_000_000;
  const ALLOWED_TOTAL: isize = 16 * 1024;
  within_limit(
    "lists_dropped_at_the_same_moment_give_their_memory_back",
    || {
      let shared = numbered_set("/together/shared", 7);
      let build = |round: usize| {
        let mut set = shared.clone();
        set.insert(InternedPath::from(
          format!("/together/own/{round}.js").as_str(),
        ));
        file_info(set)
      };

      let before = settled_bytes(&shared, "before");
      drop_together(2, MEASURED, &build);
      let growth = settled_bytes(&shared, "after") - before;
      eprintln!("MEASURE together {growth}");

      assert!(
        growth < ALLOWED_TOTAL,
        "{growth} bytes stayed allocated after {MEASURED} lists were dropped by two threads at \
       the same moment",
      );
    },
  );
}

#[test]
fn factorizations_on_other_threads_share() {
  const ROUNDS: usize = 20_000;
  within_limit("factorizations_on_other_threads_share", || {
    let threads = thread_count();
    let shared = numbered_set("/threads/shared", 7);
    let gate = Gate::new(threads);
    let starts: Vec<AtomicUsize> = (0..threads).map(|_| AtomicUsize::new(0)).collect();
    let apart = AtomicUsize::new(0);
    thread::scope(|scope| {
      for slot in &starts {
        let (shared, gate, starts, apart) = (&shared, &gate, &starts, &apart);
        scope.spawn(move || {
          let _guard = BreakOnPanic(gate);
          for round in 0..ROUNDS {
            let mut set = shared.clone();
            set.insert(InternedPath::from(
              format!("/threads/own/{round}.js").as_str(),
            ));
            if !gate.wait() {
              return;
            }
            let list = file_info(set);
            slot.store(
              list.file_dependencies().as_ptr() as usize,
              Ordering::Release,
            );
            if !gate.wait() {
              return;
            }
            let first = starts[0].load(Ordering::Acquire);
            if starts
              .iter()
              .any(|other| other.load(Ordering::Acquire) != first)
            {
              apart.fetch_add(1, Ordering::Relaxed);
            }
            if !gate.wait() {
              return;
            }
            drop(list);
          }
        });
      }
    });
    assert_eq!(
      apart.load(Ordering::Relaxed),
      0,
      "equal lists built at the same moment on {threads} threads must share one buffer",
    );
  });
}

#[test]
fn a_live_list_stays_shared_while_others_come_and_go() {
  const ROUNDS: usize = 400_000;
  within_limit("a_live_list_stays_shared_while_others_come_and_go", || {
    let threads = thread_count();
    let contents: Vec<InternedPathSet> = (0..4)
      .map(|index| numbered_set(&format!("/churn/{index}"), 8))
      .collect();
    let apart = Mutex::new(0usize);
    thread::scope(|scope| {
      for thread_index in 0..threads {
        let (contents, apart) = (&contents, &apart);
        scope.spawn(move || {
          let mut seen_apart = 0usize;
          for round in 0..ROUNDS {
            let set = &contents[(round + thread_index) % contents.len()];
            let held = file_info(set.clone());
            let next = file_info(set.clone());
            if !same_buffer(held.file_dependencies(), next.file_dependencies()) {
              seen_apart += 1;
            }
          }
          *apart.lock().expect("no thread panics with this lock") += seen_apart;
        });
      }
    });
    let apart = *apart.lock().expect("no thread panics with this lock");
    assert_eq!(
      apart, 0,
      "{apart} times a new list didn't share with an equal list its own thread still held",
    );
  });
}
