//! Interned paths are freed when their last handle goes. This binary reads the
//! interner's own count, `InternSliceStorage::len`, through the public kind that
//! `InternedPath` is stored under.

use std::{
  sync::{
    atomic::{AtomicBool, AtomicUsize, Ordering},
    mpsc,
  },
  thread,
  time::Duration,
};

use rspack_intern::SliceInternable;
use rspack_paths::{InternedPath, PreHashedPath};

fn interned_paths() -> usize {
  <PreHashedPath as SliceInternable>::storage().len()
}

/// The rounds take seconds. A lock taken twice on one thread would hang them for
/// good, so each test runs under a limit and fails with a message.
const LIMIT_SECS: f64 = 240.0;

fn within_limit(name: &'static str, test: impl FnOnce() + Send + 'static) {
  let multiplier = std::env::var("TIMEOUT_MULTIPLIER")
    .ok()
    .and_then(|value| value.parse::<f64>().ok())
    .unwrap_or(1.0)
    .max(1.0);
  let limit = Duration::from_secs_f64(LIMIT_SECS * multiplier);
  let (done, finished) = mpsc::channel();
  let runner = thread::spawn(move || {
    test();
    let _ = done.send(());
  });
  match finished.recv_timeout(limit) {
    Ok(()) => runner.join().expect("the test body returned"),
    Err(mpsc::RecvTimeoutError::Timeout) => {
      panic!("{name} didn't finish within {limit:?}; a thread is stuck")
    }
    Err(mpsc::RecvTimeoutError::Disconnected) => {
      if let Err(cause) = runner.join() {
        std::panic::resume_unwind(cause);
      }
    }
  }
}

/// Holds threads back until all of them arrive, then lets them go within a few
/// instructions of each other, closer than a blocking barrier can.
struct Gate {
  parties: usize,
  arrived: AtomicUsize,
  opened: AtomicUsize,
  broken: AtomicBool,
}

impl Gate {
  fn new(parties: usize) -> Self {
    Self {
      parties,
      arrived: AtomicUsize::new(0),
      opened: AtomicUsize::new(0),
      broken: AtomicBool::new(false),
    }
  }

  fn wait(&self) -> bool {
    let opened = self.opened.load(Ordering::Acquire);
    if self.arrived.fetch_add(1, Ordering::AcqRel) + 1 == self.parties {
      self.arrived.store(0, Ordering::Release);
      self.opened.store(opened + 1, Ordering::Release);
      return true;
    }
    let mut spins = 0u32;
    while self.opened.load(Ordering::Acquire) == opened {
      if self.broken.load(Ordering::Relaxed) {
        return false;
      }
      spins = spins.wrapping_add(1);
      if spins % 4096 == 0 {
        thread::yield_now();
      } else {
        std::hint::spin_loop();
      }
    }
    true
  }
}

/// Opens the gate for good if a thread panics, so the others don't wait forever.
struct BreakOnPanic<'a>(&'a Gate);

impl Drop for BreakOnPanic<'_> {
  fn drop(&mut self) {
    if thread::panicking() {
      self.0.broken.store(true, Ordering::Relaxed);
    }
  }
}

#[test]
fn a_path_released_by_one_thread_leaves_the_interner() {
  let before = interned_paths();
  let path = InternedPath::from("/interned/alone.js");
  assert_eq!(interned_paths(), before + 1);
  let copy = path.clone();
  drop(path);
  assert_eq!(interned_paths(), before + 1, "a handle is still alive");
  drop(copy);
  assert_eq!(interned_paths(), before);
}

#[test]
fn equal_paths_stay_one_entry_while_a_handle_lives() {
  let before = interned_paths();
  let held = InternedPath::from("/interned/held.js");
  for _ in 0..1_000 {
    let again = InternedPath::from("/interned/held.js");
    assert_eq!(again, held, "equal paths compare by pointer");
    drop(again);
    assert_eq!(interned_paths(), before + 1);
  }
  drop(held);
  assert_eq!(interned_paths(), before);
}

#[test]
fn equal_paths_stay_equal_while_others_come_and_go() {
  const ROUNDS: usize = 400_000;
  within_limit("equal_paths_stay_equal_while_others_come_and_go", || {
    let apart = AtomicUsize::new(0);
    thread::scope(|scope| {
      for thread_index in 0..4 {
        let apart = &apart;
        scope.spawn(move || {
          for round in 0..ROUNDS {
            let name = format!("/interned/churn/{}.js", (round + thread_index) % 4);
            let held = InternedPath::from(name.as_str());
            let next = InternedPath::from(name.as_str());
            if held != next {
              apart.fetch_add(1, Ordering::Relaxed);
            }
          }
        });
      }
    });
    let apart = apart.load(Ordering::Relaxed);
    assert_eq!(
      apart, 0,
      "{apart} times a path didn't equal the same path its own thread still held",
    );
  });
}

#[test]
fn paths_dropped_at_the_same_moment_leave_the_interner() {
  const ROUNDS: usize = 300_000;
  within_limit(
    "paths_dropped_at_the_same_moment_leave_the_interner",
    || {
      let before = interned_paths();
      let gate = Gate::new(2);
      thread::scope(|scope| {
        for _ in 0..2 {
          scope.spawn(|| {
            let _guard = BreakOnPanic(&gate);
            for round in 0..ROUNDS {
              let path = InternedPath::from(format!("/interned/together/{round}.js").as_str());
              if !gate.wait() {
                return;
              }
              drop(path);
              if !gate.wait() {
                return;
              }
            }
          });
        }
      });
      let left = interned_paths() - before;
      assert_eq!(
        left, 0,
        "{left} of {ROUNDS} paths are still interned although every handle is gone",
      );
    },
  );
}
