## Task

Operators with big projects keep telling us rspack's peak RSS sits several hundred MB above what a production build should need. Small projects don't show it, it grows with the size of the project, and a build restored from the persistent cache is just as bad.

On a full client and server build, interned path handles sit near the top of our memory census, about 240 MiB too many, and most of them repeat what the resolver already recorded for other dependencies, in either compiler. After busy parallel stretches the process also keeps a few interned paths nobody uses anymore.

Please track both down and get that memory back. Build output can't change, and rspack_core's public API stays as it is.
