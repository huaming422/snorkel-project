## Task

Fresh laptop, fresh clone of one of our projects, then `bd bootstrap` to get the issue database in place. The command said the database was already there and returned a zero status, yet nothing had been created on disk and every `bd` command after it failed. The workspace config points its sync remote at the git-hosted repository where the team keeps this data, which may matter here.

Please find out why bootstrap claims success while setting up nothing and fix it. Bootstrap should get a database in place whenever it legitimately can, and when it cannot it should fail with a non-zero status and say what went wrong, rather than leaving me with a success message and no database.
