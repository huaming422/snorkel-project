// In-package behavioral verifier for the bootstrap remote-probe fix.
//
// This file defines its own TestMain, which makes the runner stash every other
// *_test.go in the package before building. That keeps the build free of the
// package's cgo-tagged, Dolt-server-backed fixtures (they register a
// server-start hook in a sibling TestMain), so these tests compile and run
// against a freshly provisioned, server-less workspace. Everything this file
// needs is inlined below.
//
// Decoupling contract (why this file names no symbol the fix introduces):
// a single undefined identifier fails the WHOLE Go file to compile, so if any
// one assertion reached for a fix-invented name (a plan "blocked" field, the
// plan→exit helper, the routing helper, the probe seam, the plan marshaller),
// the entire file would fail to build against every tree that structured the
// fix differently — including the equally-valid alternatives the task contract
// blesses (any single-owner routing helper name, any blocked/exit signalling
// mechanism, any fall-through structuring). Those would then score zero on all
// criteria for a purely structural reason. To avoid that, every behavior here
// is driven through interfaces that exist UNCHANGED on the unmodified tree —
// detectBootstrapAction and its pre-existing plan fields (Action, Reason,
// SyncRemote, HasExisting, BackupDir), printBootstrapPlan, and the bootstrap
// command's own RunE + exitCodeFromError. The file therefore COMPILES on both
// the unmodified tree and any fixed tree; on the unmodified tree it runs and
// the criteria FAIL because the behavior is wrong (forge remotes rejected, the
// false success tick), and on a correct fixed tree they PASS. That behavioral
// flip is the fail-to-pass.
//
// The probe is driven offline three ways, never over the network:
//   - real local bare repositories (a repo that carries refs/dolt/data vs. one
//     that does not vs. a path that is not a repo at all), for the cases whose
//     fixture URL is a local path;
//   - a `git` shim on PATH that answers only `ls-remote` (and execs the real
//     git for everything else), for the cases whose fixture URL must name a real
//     forge host so the git+ routing and credential redaction are exercised.

package main

import (
	"bytes"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"testing"

	"github.com/steveyegge/beads/internal/config"
	"github.com/steveyegge/beads/internal/configfile"
)

// ----------------------------------------------------------------------------
// TestMain: minimal, server-free isolation.
// ----------------------------------------------------------------------------

func TestMain(m *testing.M) {
	os.Exit(verifyMainInner(m))
}

func verifyMainInner(m *testing.M) int {
	tmp, err := os.MkdirTemp("", "beads-verify-*")
	if err != nil {
		panic(err)
	}
	defer func() { _ = os.RemoveAll(tmp) }()

	// Isolate config/home discovery from the repo's tracked .beads/config.yaml
	// and from the invoking shell, mirroring the package's own TestMain but
	// without starting any Dolt server (none of these tests need one).
	_ = os.Setenv("HOME", tmp)
	_ = os.Setenv("USERPROFILE", tmp)
	_ = os.Setenv("APPDATA", filepath.Join(tmp, "AppData", "Roaming"))
	_ = os.Setenv("XDG_CONFIG_HOME", filepath.Join(tmp, "xdg-config"))
	_ = os.Setenv("BEADS_TEST_IGNORE_REPO_CONFIG", "1")
	_ = os.Setenv("BEADS_TEST_MODE", "1")
	// Keep any telemetry side effects out of the isolated HOME.
	_ = os.Setenv("BD_DISABLE_METRICS", "1")
	_ = os.Setenv("BD_DISABLE_EVENT_FLUSH", "1")
	_ = os.Unsetenv("BEADS_DIR")

	config.ResetForTesting()
	enableTestModeGlobals()

	return m.Run()
}

// ----------------------------------------------------------------------------
// Inlined helpers (siblings are stashed, so no collisions).
// ----------------------------------------------------------------------------

// stdioMutex serializes os.Stdout / os.Stderr redirection.
var stdioMutex sync.Mutex

// snapshotBootstrapEnv saves, clears, and (via t.Cleanup) restores every
// BD_/BEADS_-prefixed env var so stray bootstrap settings cannot leak between
// subtests. Registered via t.Cleanup (not a returned defer) so it runs after
// any later t.Setenv cleanups, which is what the package's own helper relies on.
func snapshotBootstrapEnv(t *testing.T) {
	t.Helper()
	saved := make(map[string]string)
	for _, env := range os.Environ() {
		if strings.HasPrefix(env, "BD_") || strings.HasPrefix(env, "BEADS_") {
			parts := strings.SplitN(env, "=", 2)
			key := parts[0]
			saved[key] = os.Getenv(key)
			_ = os.Unsetenv(key)
		}
	}
	// Re-assert the suite-wide isolation flags the snapshot just wiped.
	_ = os.Setenv("BEADS_TEST_IGNORE_REPO_CONFIG", "1")
	_ = os.Setenv("BEADS_TEST_MODE", "1")
	t.Cleanup(func() {
		for _, env := range os.Environ() {
			if strings.HasPrefix(env, "BD_") || strings.HasPrefix(env, "BEADS_") {
				parts := strings.SplitN(env, "=", 2)
				_ = os.Unsetenv(parts[0])
			}
		}
		for key, val := range saved {
			_ = os.Setenv(key, val)
		}
	})
}

// newWorkspace builds a .beads workspace whose config carries the given
// sync.remote (pass "" for none) and chdirs into its parent (so git-origin
// auto-detect cannot climb into a real repo above the temp dir). Returns the
// .beads path.
func newWorkspace(t *testing.T, remote string) string {
	t.Helper()
	snapshotBootstrapEnv(t)

	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}
	configureWorkspace(t, beadsDir, remote)

	oldWd, _ := os.Getwd()
	t.Cleanup(func() { _ = os.Chdir(oldWd) })
	if err := os.Chdir(tmpDir); err != nil {
		t.Fatal(err)
	}
	return beadsDir
}

// configureWorkspace writes .beads/config.yaml and initializes the config
// subsystem so resolveSyncRemote() reads it back. A non-empty remote is written
// as sync.remote; an empty remote still writes a harmless key so config.yaml
// exists (FindBeadsDir treats config.yaml as a project-file marker).
func configureWorkspace(t *testing.T, beadsDir, remote string) {
	t.Helper()
	body := "log.level: info\n"
	if remote != "" {
		body = "sync.remote: " + remote + "\n"
	}
	if err := os.WriteFile(filepath.Join(beadsDir, "config.yaml"), []byte(body), 0o644); err != nil {
		t.Fatalf("write config.yaml: %v", err)
	}
	config.ResetForTesting()
	t.Setenv("BEADS_DIR", beadsDir)
	t.Setenv("BEADS_TEST_IGNORE_REPO_CONFIG", "1")
	if err := config.Initialize(); err != nil {
		t.Fatalf("config.Initialize: %v", err)
	}
	t.Cleanup(config.ResetForTesting)
}

// runGit runs git in dir (cwd if empty) and fails the test on error.
func runGit(t *testing.T, dir string, args ...string) {
	t.Helper()
	cmd := exec.Command("git", args...)
	if dir != "" {
		cmd.Dir = dir
	}
	cmd.Env = append(os.Environ(), "GIT_TERMINAL_PROMPT=0", "GIT_CONFIG_NOSYSTEM=1")
	if out, err := cmd.CombinedOutput(); err != nil {
		t.Fatalf("git %v: %v\n%s", args, err, out)
	}
}

// makeBareRepoWithDataRef creates a local bare git repo and, when withData is
// true, pushes a commit to refs/dolt/data so a real `git ls-remote` probe finds
// it. Returns the bare repo path (which ends in ".git", so the planner routes
// it through the forge/probe path). No shim: the probe runs against this real
// local repo offline.
func makeBareRepoWithDataRef(t *testing.T, withData bool) string {
	t.Helper()
	root := t.TempDir()
	bare := filepath.Join(root, "remote.git")
	runGit(t, "", "init", "--bare", "-q", bare)
	if !withData {
		return bare
	}
	work := filepath.Join(root, "work")
	if err := os.MkdirAll(work, 0o750); err != nil {
		t.Fatal(err)
	}
	runGit(t, work, "init", "-q")
	runGit(t, work, "config", "user.email", "verify@test.local")
	runGit(t, work, "config", "user.name", "verify")
	runGit(t, work, "config", "commit.gpgsign", "false")
	if err := os.WriteFile(filepath.Join(work, "seed"), []byte("x\n"), 0o644); err != nil {
		t.Fatal(err)
	}
	runGit(t, work, "add", "-A")
	runGit(t, work, "commit", "-q", "-m", "seed")
	runGit(t, work, "push", "-q", bare, "HEAD:refs/dolt/data")
	return bare
}

// installFakeGit puts a `git` shim first on PATH for the duration of the test.
// The shim answers only `git ls-remote <url> refs/dolt/data` — recording the url
// to a log and replying per mode ("data" → one ref line + exit 0, "nodata" →
// empty + exit 0, "error" → a fatal line on stderr + exit 128) — and execs the
// real git for every other invocation. It lets a probe against a real-forge URL
// be answered deterministically offline, so the git+ routing and credential
// redaction on those URLs can be exercised without the network. Returns the
// probe-log path.
func installFakeGit(t *testing.T, mode string) string {
	t.Helper()
	realGit, err := exec.LookPath("git")
	if err != nil {
		t.Fatalf("real git not found on PATH: %v", err)
	}
	bin := t.TempDir()
	probeLog := filepath.Join(bin, "probe.log")
	script := "#!/bin/sh\n" +
		"if [ \"$1\" = \"ls-remote\" ]; then\n" +
		"  printf '%s\\n' \"$2\" >> \"" + probeLog + "\"\n" +
		"  case \"" + mode + "\" in\n" +
		"    data) printf '%s\\trefs/dolt/data\\n' 0000000000000000000000000000000000000000; exit 0;;\n" +
		"    nodata) exit 0;;\n" +
		"    error) echo 'fatal: could not read from remote repository' 1>&2; exit 128;;\n" +
		"  esac\n" +
		"fi\n" +
		"exec \"" + realGit + "\" \"$@\"\n"
	if err := os.WriteFile(filepath.Join(bin, "git"), []byte(script), 0o755); err != nil {
		t.Fatalf("write fake git: %v", err)
	}
	t.Setenv("PATH", bin+string(os.PathListSeparator)+os.Getenv("PATH"))
	return probeLog
}

// probeCount returns how many times the fake-git shim was asked to probe.
func probeCount(t *testing.T, logPath string) int {
	t.Helper()
	data, err := os.ReadFile(logPath)
	if err != nil {
		return 0 // never created → never probed
	}
	trimmed := strings.TrimSpace(string(data))
	if trimmed == "" {
		return 0
	}
	return len(strings.Split(trimmed, "\n"))
}

// captureStdout / captureStderr mirror the package's pure-Go helpers.
func captureStdout(t *testing.T, fn func()) string {
	t.Helper()
	stdioMutex.Lock()
	defer stdioMutex.Unlock()

	old := os.Stdout
	r, w, _ := os.Pipe()
	done := make(chan string, 1)
	go func() {
		var buf bytes.Buffer
		_, _ = buf.ReadFrom(r)
		done <- buf.String()
	}()
	os.Stdout = w
	fn()
	_ = w.Close()
	os.Stdout = old
	out := <-done
	_ = r.Close()
	return out
}

func captureStderr(t *testing.T, fn func()) string {
	t.Helper()
	stdioMutex.Lock()
	defer stdioMutex.Unlock()

	old := os.Stderr
	r, w, _ := os.Pipe()
	var buf bytes.Buffer
	done := make(chan struct{})
	go func() {
		_, _ = io.Copy(&buf, r)
		close(done)
	}()
	os.Stderr = w
	fn()
	_ = w.Close()
	os.Stderr = old
	<-done
	_ = r.Close()
	return buf.String()
}

// captureStderrUnlocked is captureStderr for a caller that already holds
// stdioMutex (nesting the locking variant inside captureStdout would deadlock).
func captureStderrUnlocked(t *testing.T, fn func()) string {
	t.Helper()
	old := os.Stderr
	r, w, _ := os.Pipe()
	var buf bytes.Buffer
	done := make(chan struct{})
	go func() {
		_, _ = io.Copy(&buf, r)
		close(done)
	}()
	os.Stderr = w
	fn()
	_ = w.Close()
	os.Stderr = old
	<-done
	_ = r.Close()
	return buf.String()
}

// boolStr renders a bool for cobra's Flags().Set.
func boolStr(b bool) string {
	if b {
		return "true"
	}
	return "false"
}

// driveBootstrap runs the bootstrap command's own RunE in-process against the
// current workspace and returns its captured stdout, its captured stderr, and
// the error it returned. The command's exit status is encoded in that error
// (main() turns it into os.Exit via exitCodeFromError), so a caller tests the
// user-visible exit behavior by inspecting the returned error with
// exitCodeFromError — the same pre-existing seam the package's own command
// tests use. Both streams are captured because a solution may explain a
// declined run from the plan printer, from the command's error handler, or
// through the error it hands back for main to print; the tests below accept
// any of those, so they need the whole command surface in one call.
func driveBootstrap(t *testing.T, dryRun, jsonOut bool) (string, string, error) {
	t.Helper()
	set := func(name, val string) {
		if err := bootstrapCmd.Flags().Set(name, val); err != nil {
			t.Fatalf("set --%s: %v", name, err)
		}
	}
	set("dry-run", boolStr(dryRun))
	set("yes", "false")
	set("non-interactive", "true")

	oldJSON := jsonOutput
	jsonOutput = jsonOut
	// Neutralize the shared-server metadata reconciliation for this in-process
	// run: it walks the workspace parent for an authoritative metadata.json, a
	// concern orthogonal to the probe/exit behavior under test. This is a
	// pre-existing injectable package var (not a fix symbol), stubbed to a no-op
	// so the command reaches detectBootstrapAction with the loaded config intact.
	oldResolve := resolveBootstrapAuthoritativeMetadata
	resolveBootstrapAuthoritativeMetadata = func(string, bool) (*configfile.Config, string, error) {
		return nil, "", nil
	}
	t.Cleanup(func() {
		jsonOutput = oldJSON
		resolveBootstrapAuthoritativeMetadata = oldResolve
		_ = bootstrapCmd.Flags().Set("dry-run", "false")
		_ = bootstrapCmd.Flags().Set("non-interactive", "false")
	})
	t.Setenv("BD_NON_INTERACTIVE", "1")

	var runErr error
	var stderr string
	stdout := captureStdout(t, func() {
		stderr = captureStderrUnlocked(t, func() {
			runErr = bootstrapCmd.RunE(bootstrapCmd, []string{})
		})
	})
	return stdout, stderr, runErr
}

// explainedFailure reports whether a declined run told the user why, through
// any of the surfaces main() shows: text on stderr, or an error carrying a
// message (an exit-code-only error carries none; its message is expected on
// stderr instead).
func explainedFailure(stderr string, err error) bool {
	if strings.TrimSpace(stderr) != "" {
		return true
	}
	if err == nil {
		return false
	}
	_, isExit := exitCodeFromError(err)
	return !isExit
}

// sameLocalRemote reports whether got names the same local repository as the
// bare fixture path want. A local path is already a form git can clone, so the
// router may leave it byte-identical; a solution that spells the same path as a
// file:// or git+file:// URL is cloning the same repository and is accepted too.
func sameLocalRemote(got, want string) bool {
	for _, prefix := range []string{"git+file://", "file://"} {
		got = strings.TrimPrefix(got, prefix)
	}
	return got == want || got == filepath.ToSlash(want)
}

// makeExistingEmbeddedDB lays down an embedded Dolt database marker under
// beadsDir so detectBootstrapAction classifies the workspace as "a database
// already exists" (the positive control for the success-tick / exit-zero path).
func makeExistingEmbeddedDB(t *testing.T, beadsDir string) {
	t.Helper()
	doltMarker := filepath.Join(beadsDir, "embeddeddolt", "beads", ".dolt")
	if err := os.MkdirAll(doltMarker, 0o750); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(doltMarker, "config.json"), []byte("{}\n"), 0o644); err != nil {
		t.Fatal(err)
	}
}

// forgeForms enumerates the shapes a git-forge sync.remote arrives in, with the
// git+ clone URL the router must produce for each. Every entry is a value bd
// itself writes (init-from-origin, `bd dolt remote add`, hand-edited config).
var forgeForms = []struct {
	name      string
	remote    string
	wantClone string
}{
	{"raw https with .git", "https://github.com/org/repo.git", "git+https://github.com/org/repo.git"},
	{"raw https without .git", "https://github.com/org/repo", "git+https://github.com/org/repo"},
	{"scp style", "git@github.com:org/repo.git", "git+ssh://git@github.com/org/repo.git"},
	{"ssh scheme", "ssh://git@github.com/org/repo.git", "git+ssh://git@github.com/org/repo.git"},
	{"already git+https", "git+https://github.com/org/repo.git", "git+https://github.com/org/repo.git"},
	{"git+ssh without user", "git+ssh://github.com/org/repo.git", "git+ssh://github.com/org/repo.git"},
	{"gitlab", "https://gitlab.com/group/repo.git", "git+https://gitlab.com/group/repo.git"},
}

// ----------------------------------------------------------------------------
// Criterion 1 — a sync.remote that carries refs/dolt/data yields a clone plan,
// not a rejection. Driven through the REAL probe against local bare repos.
// On the unmodified tree the .git URL is rejected (action "none"); a fixed tree
// probes it and routes to action "sync" (or "init" when the repo has no data yet).
// ----------------------------------------------------------------------------

func TestProbeRoutesNotRejects_RealRemote(t *testing.T) {
	t.Run("data present yields a sync plan", func(t *testing.T) {
		bare := makeBareRepoWithDataRef(t, true)
		beadsDir := newWorkspace(t, bare)

		plan := detectBootstrapAction(beadsDir, configfile.DefaultConfig())

		if plan.Action != "sync" {
			t.Fatalf("action = %q, want %q (remote carries refs/dolt/data)", plan.Action, "sync")
		}
		// The plan must clone the repository the probe confirmed. A local path
		// is already a form git can clone, so byte-identical is fine, and so is
		// the same path spelled as a file:// or git+file:// URL.
		if !sameLocalRemote(plan.SyncRemote, bare) {
			t.Errorf("SyncRemote = %q, want %q (the probed remote, or its file URL form)", plan.SyncRemote, bare)
		}
	})

	t.Run("no data falls through to init and records the remote", func(t *testing.T) {
		bare := makeBareRepoWithDataRef(t, false)
		beadsDir := newWorkspace(t, bare)

		plan := detectBootstrapAction(beadsDir, configfile.DefaultConfig())

		if plan.Action != "init" {
			t.Fatalf("action = %q, want %q (no data yet: provision locally)", plan.Action, "init")
		}
		if !sameLocalRemote(plan.SyncRemote, bare) {
			t.Errorf("SyncRemote = %q, want %q (recorded so the fresh db gets wired to it)", plan.SyncRemote, bare)
		}
	})
}

// ----------------------------------------------------------------------------
// Criterion 2 — the clone URL a forge remote contributes is the git+ form,
// never the raw http(s) form. Driven through detectBootstrapAction with the
// shim answering the probe, so the git+ transform is observed on the plan's
// pre-existing SyncRemote field (no routing-helper name is referenced).
// ----------------------------------------------------------------------------

func TestCloneURLIsGitPlus(t *testing.T) {
	for _, tc := range forgeForms {
		t.Run(tc.name, func(t *testing.T) {
			installFakeGit(t, "data")
			beadsDir := newWorkspace(t, tc.remote)

			plan := detectBootstrapAction(beadsDir, configfile.DefaultConfig())

			if plan.Action != "sync" {
				t.Fatalf("action = %q, want %q", plan.Action, "sync")
			}
			if plan.SyncRemote != tc.wantClone {
				t.Errorf("SyncRemote = %q, want %q", plan.SyncRemote, tc.wantClone)
			}
			if !strings.HasPrefix(plan.SyncRemote, "git+") {
				t.Errorf("SyncRemote = %q lacks the git+ prefix; a recognized forge URL must never reach the clone raw", plan.SyncRemote)
			}
		})
	}
}

// ----------------------------------------------------------------------------
// Criterion 3 — when bootstrap declines and confirms no database, the command
// exits non-zero (the false-success fix); an existing-database plan and a
// --dry-run of the same blocked scenario still exit zero. Driven through the
// command's RunE and read with the pre-existing exitCodeFromError seam.
// ----------------------------------------------------------------------------

func TestBlockedExitsNonZero(t *testing.T) {
	t.Run("blocked run exits non-zero", func(t *testing.T) {
		// A forge-shaped sync.remote whose probe cannot be answered, and no
		// local recovery source, is the blocked state. A non-existent local
		// ".git" path makes the real `git ls-remote` fail offline.
		missing := filepath.Join(t.TempDir(), "missing.git")
		newWorkspace(t, missing)

		_, _, err := driveBootstrap(t, false, false)

		code, ok := exitCodeFromError(err)
		if err == nil || !ok || code == 0 {
			t.Fatalf("bootstrap outcome err = %v (code %d, isExit %v), want a non-zero exit", err, code, ok)
		}
	})

	t.Run("existing database exits zero", func(t *testing.T) {
		beadsDir := newWorkspace(t, "")
		makeExistingEmbeddedDB(t, beadsDir)

		_, _, err := driveBootstrap(t, false, false)

		if err != nil {
			t.Fatalf("outcome err = %v, want nil (an existing database is success)", err)
		}
	})

	t.Run("dry-run of a blocked scenario exits zero", func(t *testing.T) {
		missing := filepath.Join(t.TempDir(), "missing.git")
		newWorkspace(t, missing)

		_, _, err := driveBootstrap(t, true, false)

		if err != nil {
			t.Fatalf("dry-run outcome err = %v, want nil (a preview must never abort a script)", err)
		}
	})
}

// ----------------------------------------------------------------------------
// Criterion 4 — a blocked run never prints the "✓ Database already exists"
// success line; that tick is reserved for a plan that actually found a database.
// The blocked case is driven through the whole command (RunE), so a solution
// may explain the refusal from the plan printer, from the command's error
// handler, or through the returned error — only the absence of the tick on
// stdout and the presence of some explanation are asserted.
// ----------------------------------------------------------------------------

func TestNoFalseSuccessTick(t *testing.T) {
	t.Run("blocked run prints no success tick and explains itself", func(t *testing.T) {
		missing := filepath.Join(t.TempDir(), "missing.git")
		newWorkspace(t, missing)

		stdout, stderr, err := driveBootstrap(t, false, false)

		// The contract: a run that set up nothing must never print the
		// "database already exists" success line. The tick string is a stable
		// pre-existing one (the unmodified tree prints it), so asserting its
		// ABSENCE flips from failing to passing without pinning any new,
		// solution-chosen wording.
		if strings.Contains(stdout, "✓") || strings.Contains(stdout, "already exists") {
			t.Errorf("declined bootstrap printed a success line to stdout: %q", stdout)
		}
		// It must instead explain itself somewhere a human sees it. The exact
		// diagnostic wording and the surface it goes to (stderr from the plan
		// printer or the error handler, or a message in the returned error that
		// main prints) are the solution's to choose, so only presence is asserted.
		if !explainedFailure(stderr, err) {
			t.Errorf("declined bootstrap said nothing about why no database was set up (stdout %q, stderr %q, err %v)", stdout, stderr, err)
		}
	})

	t.Run("existing-database plan prints the success tick", func(t *testing.T) {
		beadsDir := newWorkspace(t, "")
		makeExistingEmbeddedDB(t, beadsDir)

		plan := detectBootstrapAction(beadsDir, configfile.DefaultConfig())

		stdout := captureStdout(t, func() { printBootstrapPlan(plan) })
		if !strings.Contains(stdout, "✓") || !strings.Contains(stdout, "already exists") {
			t.Errorf("existing-db plan stdout = %q, want the success tick", stdout)
		}
	})
}

// ----------------------------------------------------------------------------
// Criterion 5 — a probe that returns no-data, or errors (UNKNOWN), still falls
// through to local recovery (backup restore, then fresh init), and an init'd
// workspace records the routed remote. Driven through the real probe against
// local bare repos / a missing path — no seam.
// ----------------------------------------------------------------------------

func TestProbeFailureAllowsLocalRecovery(t *testing.T) {
	writeBackup := func(t *testing.T, beadsDir string) string {
		backupDir := filepath.Join(beadsDir, "backup")
		if err := os.MkdirAll(backupDir, 0o750); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(filepath.Join(backupDir, "issues.jsonl"), []byte(`{"id":"bd-1"}`+"\n"), 0o644); err != nil {
			t.Fatal(err)
		}
		return backupDir
	}

	t.Run("no-data probe, nothing local, inits and records the remote", func(t *testing.T) {
		bare := makeBareRepoWithDataRef(t, false)
		beadsDir := newWorkspace(t, bare)

		plan := detectBootstrapAction(beadsDir, configfile.DefaultConfig())

		if plan.Action != "init" {
			t.Fatalf("action = %q, want %q", plan.Action, "init")
		}
		if !sameLocalRemote(plan.SyncRemote, bare) {
			t.Errorf("SyncRemote = %q, want %q (recorded so the fresh db is wired to it)", plan.SyncRemote, bare)
		}
	})

	t.Run("no-data probe falls through to backup restore", func(t *testing.T) {
		bare := makeBareRepoWithDataRef(t, false)
		beadsDir := newWorkspace(t, bare)
		backupDir := writeBackup(t, beadsDir)

		plan := detectBootstrapAction(beadsDir, configfile.DefaultConfig())

		if plan.Action != "restore" {
			t.Fatalf("action = %q, want %q (backup must be found past the probe)", plan.Action, "restore")
		}
		if plan.BackupDir != backupDir {
			t.Errorf("BackupDir = %q, want %q", plan.BackupDir, backupDir)
		}
	})

	t.Run("probe error still restores from a local backup", func(t *testing.T) {
		missing := filepath.Join(t.TempDir(), "missing.git")
		beadsDir := newWorkspace(t, missing)
		backupDir := writeBackup(t, beadsDir)

		plan := detectBootstrapAction(beadsDir, configfile.DefaultConfig())

		if plan.Action != "restore" {
			t.Fatalf("action = %q, want %q (a probe error must not deny local recovery)", plan.Action, "restore")
		}
		if plan.BackupDir != backupDir {
			t.Errorf("BackupDir = %q, want %q", plan.BackupDir, backupDir)
		}
	})
}

// ----------------------------------------------------------------------------
// Criterion 6 — the routing decision: a forge remote is probed (and transformed
// to git+), while a non-forge remote — a user-configured Dolt remotesapi
// endpoint (GH#3339) or a Dolt-native scheme — is trusted byte-identical and is
// never probed. Observed through detectBootstrapAction plus the shim's probe log,
// so no routing-helper name is referenced.
// ----------------------------------------------------------------------------

func TestForgeRoutingDecision(t *testing.T) {
	t.Run("forge remote is probed and routed to sync", func(t *testing.T) {
		probeLog := installFakeGit(t, "data")
		beadsDir := newWorkspace(t, "https://github.com/org/repo.git")

		plan := detectBootstrapAction(beadsDir, configfile.DefaultConfig())

		if plan.Action != "sync" {
			t.Fatalf("action = %q, want %q", plan.Action, "sync")
		}
		if n := probeCount(t, probeLog); n < 1 {
			t.Errorf("forge remote was probed %d times, want at least once", n)
		}
	})

	passthrough := []struct {
		name   string
		remote string
	}{
		{"remotesapi endpoint", "http://myserver:7007/mydb"},
		{"dolthub scheme", "dolthub://myorg/mydb"},
		{"s3 scheme", "s3://bucket/path"},
	}
	for _, tc := range passthrough {
		t.Run(tc.name+" is trusted as-is and never probed", func(t *testing.T) {
			probeLog := installFakeGit(t, "data")
			beadsDir := newWorkspace(t, tc.remote)

			plan := detectBootstrapAction(beadsDir, configfile.DefaultConfig())

			if plan.Action != "sync" {
				t.Fatalf("action = %q, want %q (non-forge remote trusted as-is)", plan.Action, "sync")
			}
			if plan.SyncRemote != tc.remote {
				t.Errorf("SyncRemote = %q, want %q unchanged", plan.SyncRemote, tc.remote)
			}
			if n := probeCount(t, probeLog); n != 0 {
				t.Errorf("non-forge remote was probed %d times, want 0", n)
			}
		})
	}
}

// ----------------------------------------------------------------------------
// Criterion 7 — credentials are stripped from every surface a remote URL reaches
// a human or a log: the declined diagnostic on stderr, and `bd bootstrap --json`
// on stdout. Observed through printBootstrapPlan and the command's --json output
// — no redactor or marshaller name is referenced, and the plan's internal
// credential storage (a solution-choice) is not inspected.
// ----------------------------------------------------------------------------

func TestRedactsCredentials(t *testing.T) {
	const token = "ghp_SUPERSECRETTOKEN123"

	t.Run("declined diagnostic drops the token but keeps host/path", func(t *testing.T) {
		installFakeGit(t, "error")
		remote := "https://x-access-token:" + token + "@github.com/org/repo.git"
		newWorkspace(t, remote)

		// Drive the whole command: the declined diagnostic may come from the
		// plan printer, the error handler, or the returned error, and every one
		// of those surfaces must be token-free while still naming the remote.
		stdout, stderr, err := driveBootstrap(t, false, false)
		surfaces := stdout + "\n" + stderr
		if err != nil {
			surfaces += "\n" + err.Error()
		}
		if strings.Contains(surfaces, token) {
			t.Errorf("declined diagnostic leaks the token:\n%s", surfaces)
		}
		if !strings.Contains(surfaces, "github.com/org/repo") {
			t.Errorf("declined diagnostic = %q, want the host/path to survive redaction", surfaces)
		}
	})

	t.Run("--json output redacts the remote", func(t *testing.T) {
		installFakeGit(t, "data")
		remote := "https://x-access-token:" + token + "@github.com/org/repo.git"
		newWorkspace(t, remote)

		// Assert only the observable contract — the serialized `--json` surface
		// (stdout, which CI logs and agent transcripts capture) must not carry
		// the token, while the host/path survive so the output stays useful. How
		// the in-memory plan stores the credential it clones with is an internal
		// representation choice the contract leaves open, so it is not inspected.
		stdout, _, err := driveBootstrap(t, true, true)
		if err != nil {
			t.Fatalf("bootstrap --dry-run --json err = %v, want nil", err)
		}
		if strings.Contains(stdout, token) {
			t.Errorf("bootstrap --json leaks the token:\n%s", stdout)
		}
		if !strings.Contains(stdout, "github.com/org/repo") {
			t.Errorf("bootstrap --json dropped the host/path:\n%s", stdout)
		}
	})
}
