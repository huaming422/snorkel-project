#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
cd /repo/open-science

# No reinstall on the normal path. The image already baked the full, built
# dependency tree at the base commit WITH install scripts run (the native
# Electron deps, the generated Prisma client, the applied patch-package
# patches). The verifier imports the settings sources (*.ts) directly and lets
# the test runner transform them in-process; it needs the runner binary present,
# nothing more. Re-running `npm ci` here would wipe node_modules and re-trigger
# the package's postinstall chain (native-dep rebuilds, client codegen) with the
# network cut — that hangs until the container budget is exhausted and no
# verifier ever runs. So the normal path is a no-op: assert the runner is there.
if [ -x node_modules/.bin/vitest ]; then
    echo "[test-setup] baked dependency tree present (runner found); skipping install"
else
    # Defensive only: the baked tree is somehow absent/corrupt. Restore it
    # WITHOUT lifecycle scripts so the postinstall chain cannot stall offline,
    # offline-first against the image cache with a logged online fallback.
    echo "[test-setup] runner binary missing — restoring deps (scripts skipped)" >&2
    if npm ci --prefer-offline --ignore-scripts > /tmp/test-setup-install.log 2>&1; then
        echo "[test-setup] node deps restored from image cache (scripts skipped)"
    elif npm ci --ignore-scripts >> /tmp/test-setup-install.log 2>&1; then
        echo "[test-setup] node deps restored online (image bake was stale)"
    else
        tail -40 /tmp/test-setup-install.log >&2; exit 1
    fi
    [ -x node_modules/.bin/vitest ] || { echo "[test-setup] vitest still missing after restore" >&2; exit 1; }
fi

# No services and no seed data: the deterministic-error replay behaviour is
# exercised entirely in-process through the provider bridges' injectable fetch,
# with loopback HTTP servers the verifier stands up itself. No assertion logic here.
