// @ts-nocheck
//
// Behaviour is exercised only through pre-existing, stable exported
// classes in src/main/settings/, constructed with an injected fetch spy
// and a loopback client:
//   - AnthropicProviderBridge          (./anthropic-provider-bridge)
//   - OpenAiProviderBridge             (./openai-provider-bridge)
//   - ResponsesBridge                  (./responses-bridge)
//   - NativeResponsesCompatibilityProxy(./native-responses-compatibility)
//   - BackendRoutePlanner              (./backend-route-planner)
// No module that a fix might add is imported here.
//
// The load-bearing invariant throughout is the injected fetch spy's call
// count: an identical already-failed request must not reach upstream a
// second time, and a still-retryable status must reach upstream every
// time. The client-visible status is asserted only as a behavioural
// envelope (the client still sees a client-error status), never pinned to
// a specific code or required to differ from the upstream status — a
// transparent cache-and-replay that surfaces the same status and a
// terminalize-to-a-different-4xx design are both accepted.

import { afterEach, describe, expect, it, vi } from 'vitest'

// The runner copies this file into src/main/settings/ (see verify.toml
// test_parent), so these relative imports resolve against the settings
// source tree exactly as the repo's own sibling tests do.
import {
  AnthropicProviderBridge,
  type AnthropicProviderBridgeTarget
} from './anthropic-provider-bridge'
import { OpenAiProviderBridge, type OpenAiProviderBridgeTarget } from './openai-provider-bridge'
import { ResponsesBridge } from './responses-bridge'
import { NativeResponsesCompatibilityProxy } from './native-responses-compatibility'
import {
  BackendRoutePlanner,
  type BackendRouteProviderPort
} from './backend-route-planner'
import { opencodeTransportProviderId } from '../agent-framework/opencode'
import { SETTINGS_FILE_VERSION } from '../../shared/settings'

// --- shared cleanup --------------------------------------------------------

const bridges: Array<{ close: () => Promise<void> }> = []

afterEach(async () => {
  await Promise.all(bridges.splice(0).map((bridge) => bridge.close().catch(() => undefined)))
})

// --- client-status envelope ------------------------------------------------

// The contract is "stop pounding the upstream for errors that can't change,
// and still surface the failure to the client." The observable requirement
// is that upstream is hit once for an identical doomed request (asserted via
// the injected-fetch call count) and that the client still sees a client-
// error status. It says nothing about rewriting the status code or exposing
// the original status through a side channel, so we assert only the 4xx
// envelope: a transparent same-status replay (what proxies/HTTP caches do)
// and a terminalize-to-a-different-4xx design both satisfy it.
const expectClientError = (status: number): void => {
  expect(status).toBeGreaterThanOrEqual(400)
  expect(status).toBeLessThan(500)
}

// --- Anthropic-style bridge (wire path #1) ---------------------------------

const anthropicTarget: AnthropicProviderBridgeTarget = {
  id: 'provider/model-a',
  baseUrl: 'https://provider.example.test',
  key: 'wrong-key',
  model: 'model-a'
}

const sendAnthropic = (
  baseUrl: string,
  token: string,
  extraHeaders: Record<string, string> = {}
): Promise<Response> =>
  fetch(`${baseUrl}/v1/messages`, {
    method: 'POST',
    headers: {
      authorization: `Bearer ${token}`,
      'content-type': 'application/json',
      ...extraHeaders
    },
    body: JSON.stringify({ model: 'ignored', messages: [{ role: 'user', content: 'hello' }] })
  })

describe('deterministic error replay', () => {
  it('suppresses a duplicate identical upstream request (anthropic bridge)', async () => {
    const fetchImpl = vi.fn(async () =>
      Response.json(
        { error: { type: 'authentication_error', message: 'Incorrect API key provided' } },
        { status: 401 }
      )
    )
    const bridge = new AnthropicProviderBridge([anthropicTarget], anthropicTarget.id, fetchImpl)
    bridges.push(bridge)
    const connection = await bridge.start()

    const first = await sendAnthropic(connection.baseUrl, connection.token)
    const second = await sendAnthropic(connection.baseUrl, connection.token)

    // Invariant: the already-failed request is not re-issued upstream.
    expect(fetchImpl).toHaveBeenCalledOnce()
    // Client still sees a client-error status both times (same or rewritten).
    expectClientError(first.status)
    expectClientError(second.status)
  })

  it('replays the preserved error body on the duplicate request (anthropic bridge)', async () => {
    const fetchImpl = vi.fn(async () =>
      Response.json(
        { error: { type: 'authentication_error', message: 'Incorrect API key provided' } },
        { status: 403 }
      )
    )
    const bridge = new AnthropicProviderBridge([anthropicTarget], anthropicTarget.id, fetchImpl)
    bridges.push(bridge)
    const connection = await bridge.start()

    await sendAnthropic(connection.baseUrl, connection.token)
    const replay = await sendAnthropic(connection.baseUrl, connection.token)

    expect(fetchImpl).toHaveBeenCalledOnce()
    expectClientError(replay.status)
    await expect(replay.json()).resolves.toMatchObject({
      error: { message: 'Incorrect API key provided' }
    })
  })

  it('re-hits upstream when an upstream-visible request header changes', async () => {
    // Upstream distinguishes requests by a forwarded header; the cache key
    // must include that header so the second (different) request is not
    // served from the first one's terminal result.
    const fetchImpl = vi.fn(async (_url, init) => {
      const headers = new Headers(init?.headers)
      return headers.get('anthropic-beta') === 'invalid-beta'
        ? Response.json({ error: { message: 'Invalid beta' } }, { status: 400 })
        : Response.json({ content: [], model: 'model-a' })
    })
    const bridge = new AnthropicProviderBridge([anthropicTarget], anthropicTarget.id, fetchImpl)
    bridges.push(bridge)
    const connection = await bridge.start()

    const failed = await sendAnthropic(connection.baseUrl, connection.token, {
      'anthropic-beta': 'invalid-beta'
    })
    const changed = await sendAnthropic(connection.baseUrl, connection.token)

    // The first (bad-beta) request is a deterministic 400 upstream error.
    expect(failed.status).toBeGreaterThanOrEqual(400)
    expect(failed.status).toBeLessThan(500)
    // A different upstream-visible header must reach upstream, not replay.
    expect(fetchImpl).toHaveBeenCalledTimes(2)
    expect(changed.status).toBe(200)
  })

  it('does not re-hit upstream for an oversized deterministic error body', async () => {
    // A deterministic error whose declared body is larger than any sane
    // in-memory payload must still be de-duplicated: upstream is hit once and
    // the client sees a client-error status on both the first response and
    // the replay. (Whether the body is bounded/rewritten is a quality choice
    // left to the rubric, not pinned here.)
    const fetchImpl = vi.fn(
      async () =>
        new Response('oversized-error-body', {
          status: 401,
          headers: {
            'content-encoding': 'gzip',
            'content-length': String(256 * 1024 + 1),
            'content-type': 'text/event-stream'
          }
        })
    )
    const bridge = new AnthropicProviderBridge([anthropicTarget], anthropicTarget.id, fetchImpl)
    bridges.push(bridge)
    const connection = await bridge.start()

    const first = await sendAnthropic(connection.baseUrl, connection.token)
    const replay = await sendAnthropic(connection.baseUrl, connection.token)

    expectClientError(first.status)
    expectClientError(replay.status)
    expect(fetchImpl).toHaveBeenCalledOnce()
  })

  it('does not suppress a retryable status (429) — every identical request reaches upstream', async () => {
    const fetchImpl = vi.fn(async () =>
      Response.json({ error: { message: 'slow down' } }, { status: 429 })
    )
    const bridge = new AnthropicProviderBridge([anthropicTarget], anthropicTarget.id, fetchImpl)
    bridges.push(bridge)
    const connection = await bridge.start()

    const first = await sendAnthropic(connection.baseUrl, connection.token)
    const second = await sendAnthropic(connection.baseUrl, connection.token)

    // A transient status must keep reaching upstream and keep its real code.
    expect(fetchImpl).toHaveBeenCalledTimes(2)
    expect(first.status).toBe(429)
    expect(second.status).toBe(429)
  })

  it('does not suppress a server-side status (503) — every identical request reaches upstream', async () => {
    const fetchImpl = vi.fn(async () =>
      Response.json({ error: { message: 'unavailable' } }, { status: 503 })
    )
    const bridge = new AnthropicProviderBridge([anthropicTarget], anthropicTarget.id, fetchImpl)
    bridges.push(bridge)
    const connection = await bridge.start()

    const first = await sendAnthropic(connection.baseUrl, connection.token)
    const second = await sendAnthropic(connection.baseUrl, connection.token)

    expect(fetchImpl).toHaveBeenCalledTimes(2)
    expect(first.status).toBe(503)
    expect(second.status).toBe(503)
  })

  it('forwards a successful response unchanged and does not cache it (anthropic bridge)', async () => {
    // pass-through: 2xx must flow verbatim, and a second identical success
    // must still reach upstream (it was never an error to be cached).
    const fetchImpl = vi.fn(async () =>
      Response.json({ content: [{ type: 'text', text: 'ok' }], model: 'model-a' }, { status: 200 })
    )
    const bridge = new AnthropicProviderBridge([anthropicTarget], anthropicTarget.id, fetchImpl)
    bridges.push(bridge)
    const connection = await bridge.start()

    const first = await sendAnthropic(connection.baseUrl, connection.token)
    const second = await sendAnthropic(connection.baseUrl, connection.token)

    expect(first.status).toBe(200)
    expect(second.status).toBe(200)
    await expect(first.json()).resolves.toMatchObject({ model: 'model-a' })
    expect(fetchImpl).toHaveBeenCalledTimes(2)
  })

  // --- OpenAI/Chat bridge (wire path #2, OpenCode runtime) -----------------

  const openAiTarget: OpenAiProviderBridgeTarget = {
    id: 'provider/model-a',
    wire: 'chat-completions',
    endpoint: 'https://provider.example.test/v1/chat/completions',
    key: 'wrong-key',
    model: 'model-a'
  }

  const sendOpenAi = (baseUrl: string, token: string): Promise<Response> =>
    fetch(`${baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: {
        authorization: `Bearer ${token}`,
        'content-type': 'application/json'
      },
      body: JSON.stringify({ model: 'ignored', messages: [{ role: 'user', content: 'hello' }] })
    })

  it('suppresses a duplicate identical upstream request (openai/chat bridge)', async () => {
    const fetchImpl = vi.fn(async () =>
      Response.json(
        { error: { type: 'authentication_error', message: 'Incorrect API key provided' } },
        { status: 401 }
      )
    )
    const bridge = new OpenAiProviderBridge([openAiTarget], openAiTarget.id, fetchImpl)
    bridges.push(bridge)
    const connection = await bridge.start()

    const first = await sendOpenAi(connection.baseUrl, connection.token)
    const second = await sendOpenAi(connection.baseUrl, connection.token)

    // The suppression policy must apply to the OpenCode (chat) wire too.
    expect(fetchImpl).toHaveBeenCalledOnce()
    expectClientError(first.status)
    expectClientError(second.status)
  })

  it('does not suppress a retryable status (openai/chat bridge)', async () => {
    const fetchImpl = vi.fn(async () =>
      Response.json({ error: { message: 'slow down' } }, { status: 429 })
    )
    const bridge = new OpenAiProviderBridge([openAiTarget], openAiTarget.id, fetchImpl)
    bridges.push(bridge)
    const connection = await bridge.start()

    const first = await sendOpenAi(connection.baseUrl, connection.token)
    const second = await sendOpenAi(connection.baseUrl, connection.token)

    expect(fetchImpl).toHaveBeenCalledTimes(2)
    expect(first.status).toBe(429)
    expect(second.status).toBe(429)
  })

  // --- Responses bridge (wire path #3) -------------------------------------

  const sendResponses = (baseUrl: string, token: string): Promise<Response> =>
    fetch(`${baseUrl}/responses`, {
      method: 'POST',
      headers: {
        authorization: `Bearer ${token}`,
        'content-type': 'application/json'
      },
      body: JSON.stringify({ model: 'ignored', input: 'hello', stream: true })
    })

  it('terminalizes and replays a deterministic error (responses bridge)', async () => {
    const upstreamFetch = vi.fn(async () =>
      Response.json(
        { error: { type: 'authentication_error', message: 'Incorrect API key provided' } },
        { status: 401 }
      )
    )
    const bridge = new ResponsesBridge(
      { baseUrl: 'https://vendor.example/v1', key: 'wrong-key', model: 'model-a' },
      upstreamFetch
    )
    bridges.push(bridge)
    const connection = await bridge.start()

    const first = await sendResponses(connection.baseUrl, connection.token)
    const second = await sendResponses(connection.baseUrl, connection.token)

    // Same invariant on the independent second wire path.
    expect(upstreamFetch).toHaveBeenCalledOnce()
    expectClientError(first.status)
    expectClientError(second.status)
  })

  it('does not suppress a retryable status (responses bridge)', async () => {
    const upstreamFetch = vi.fn(async () =>
      Response.json({ error: { message: 'slow down' } }, { status: 429 })
    )
    const bridge = new ResponsesBridge(
      { baseUrl: 'https://vendor.example/v1', key: 'a-key', model: 'model-a' },
      upstreamFetch
    )
    bridges.push(bridge)
    const connection = await bridge.start()

    const first = await sendResponses(connection.baseUrl, connection.token)
    const second = await sendResponses(connection.baseUrl, connection.token)

    expect(upstreamFetch).toHaveBeenCalledTimes(2)
    // A transient status keeps reaching upstream and keeps its real code.
    expect(first.status).toBe(429)
    expect(second.status).toBe(429)
  })

  // --- native Responses compatibility proxy (wire path #4, Codex native) ---

  const sendNative = (baseUrl: string, token: string): Promise<Response> =>
    fetch(`${baseUrl}/responses`, {
      method: 'POST',
      headers: {
        authorization: `Bearer ${token}`,
        'content-type': 'application/json'
      },
      body: JSON.stringify({ model: 'ignored', input: 'hello', stream: false })
    })

  it('suppresses a duplicate identical upstream request (native responses proxy)', async () => {
    const fetchImpl = vi.fn(async () =>
      Response.json(
        { error: { type: 'authentication_error', message: 'Incorrect API key provided' } },
        { status: 401 }
      )
    )
    const proxy = new NativeResponsesCompatibilityProxy(
      { baseUrl: 'https://vendor.example/v1', key: 'wrong-key', model: 'model-a' },
      fetchImpl
    )
    bridges.push(proxy)
    const connection = await proxy.start()

    const first = await sendNative(connection.baseUrl, connection.token)
    const second = await sendNative(connection.baseUrl, connection.token)

    // The suppression policy must apply to the Codex native-Responses wire too.
    expect(fetchImpl).toHaveBeenCalledOnce()
    expectClientError(first.status)
    expectClientError(second.status)
  })

  it('does not suppress a retryable status (native responses proxy)', async () => {
    const fetchImpl = vi.fn(async () =>
      Response.json({ error: { message: 'slow down' } }, { status: 429 })
    )
    const proxy = new NativeResponsesCompatibilityProxy(
      { baseUrl: 'https://vendor.example/v1', key: 'a-key', model: 'model-a' },
      fetchImpl
    )
    bridges.push(proxy)
    const connection = await proxy.start()

    const first = await sendNative(connection.baseUrl, connection.token)
    const second = await sendNative(connection.baseUrl, connection.token)

    expect(fetchImpl).toHaveBeenCalledTimes(2)
    expect(first.status).toBe(429)
    expect(second.status).toBe(429)
  })
})

// --- Planner routing (pre-existing stable public methods) ------------------

const makeStoredProvider = (overrides = {}) => ({
  id: 'provider-a',
  type: 'custom',
  name: 'Provider A',
  apiEndpoints: ['anthropic', 'openai', 'responses'],
  baseUrl: 'https://provider-a.example/v1',
  model: 'model-a',
  keyRef: 'provider-a-key-ref',
  ...overrides
})

const makeSettings = (provider = makeStoredProvider()) => ({
  version: SETTINGS_FILE_VERSION,
  providers: [provider],
  activeProviderId: provider.id,
  activeModel: provider.model,
  agentFrameworkId: 'codex',
  reasoningEffort: 'high'
})

const makeTarget = (provider, overrides = {}) => {
  const { provider: providerOverrides, ...targetOverrides } = overrides
  return {
    providerId: provider.id,
    providerType: provider.type,
    effectiveModel: provider.model,
    apiEndpoints: provider.apiEndpoints ?? ['anthropic'],
    provider: {
      type: provider.type,
      baseUrl: provider.baseUrl,
      openaiBaseUrl: provider.baseUrl,
      model: provider.model,
      key: 'plain-provider-key',
      apiEndpoints: provider.apiEndpoints,
      ...providerOverrides
    },
    reasoningEffortProfile: {
      supported: true,
      slots: ['low', 'medium', 'high', 'xhigh', 'max']
    },
    frameworkCompatible: true,
    modelBridgeSupported: true,
    needsChatResponsesBridge: false,
    needsNativeResponsesCompatibility: false,
    ...targetOverrides
  }
}

const makePlanner = (): BackendRoutePlanner => {
  const providers: BackendRouteProviderPort = {
    resolveRuntimeTarget: vi.fn(),
    resolveRuntimeModelCatalog: vi.fn(() => [])
  }
  return new BackendRoutePlanner({ providers })
}

describe('routing', () => {
  it.each([
    ['claude-code', 'claude-anthropic'],
    ['opencode', 'opencode-openai'],
    ['codex', 'codex-native-responses']
  ] as const)(
    'routes a single custom %s provider through the loopback transport',
    (frameworkId, kind) => {
      const provider = makeStoredProvider(
        frameworkId === 'opencode' ? { apiEndpoints: ['openai'] } : {}
      )
      const target = makeTarget(
        provider,
        frameworkId === 'opencode' ? { apiEndpoints: ['openai'] } : {}
      )

      const plan = makePlanner().planBackend({
        settings: makeSettings(provider),
        frameworkId,
        target,
        effortIntent: 'high',
        conversationSkillImportEnabled: true
      })

      // The lone custom provider must not be sent direct — otherwise the
      // suppression policy in the loopback transports never applies to it.
      expect(plan.transport.kind).toBe(kind)
    }
  )

  it('keeps Codex subscription authentication on its direct transport', () => {
    const provider = makeStoredProvider({
      id: 'builtin-codex-subscription',
      type: 'codex-isolated',
      codexAuthMode: 'isolated',
      keyRef: undefined
    })

    const plan = makePlanner().planBackend({
      settings: makeSettings(provider),
      frameworkId: 'codex',
      target: makeTarget(provider),
      effortIntent: 'high',
      conversationSkillImportEnabled: true
    })

    expect(plan.transport).toEqual({ kind: 'direct' })
  })

  it('projects an explicit bridge target on a single-provider Claude model change', () => {
    const provider = makeStoredProvider({ model: 'model-a' })
    const target = makeTarget(provider, {
      effectiveModel: 'model-b',
      provider: { model: 'model-b' }
    })

    const change = makePlanner().projectModelChange({
      settings: makeSettings(provider),
      frameworkId: 'claude-code',
      target,
      effortIntent: 'high'
    })

    // A single-provider model change must carry a concrete, non-empty
    // bridge target so the switched session routes through the transport.
    expect(change.sessionModel).toBe('model-b')
    expect(typeof change.anthropicBridgeTargetId).toBe('string')
    expect(change.anthropicBridgeTargetId.length).toBeGreaterThan(0)
  })

  it('projects an explicit transport target on a single-provider OpenCode model change', () => {
    const provider = makeStoredProvider({ model: 'model-a', apiEndpoints: ['openai'] })
    const target = makeTarget(provider, {
      effectiveModel: 'model-b',
      apiEndpoints: ['openai'],
      provider: { model: 'model-b', apiEndpoints: ['openai'] }
    })
    const agentProviderId = opencodeTransportProviderId(provider.id, 'model-b')

    const change = makePlanner().projectModelChange({
      settings: makeSettings(provider),
      frameworkId: 'opencode',
      target,
      effortIntent: 'high'
    })

    expect(change.sessionModel).toBe(`${agentProviderId}/model-b`)
    expect(typeof change.providerTransportTargetId).toBe('string')
    expect(change.providerTransportTargetId.length).toBeGreaterThan(0)
  })
})
