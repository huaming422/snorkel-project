## Task

we're seeing the app hammer upstream providers with requests that have no chance of succeeding. when a provider request comes back with a client-side error that won't change on a retry (a bad api key, a permission or quota rejection, an unsupported request), the app re-sends the exact same already-failed request upstream over and over instead of surfacing the failure once.

it happens no matter which coding-agent runtime is driving. a single dead-on-arrival request gets amplified into a burst of identical upstream calls: operators have seen one failed call repeated several times, and one runtime fire off eight-plus identical calls within a few seconds.

this used to behave reasonably. now these doomed requests get fanned out at the provider, burning quota and spamming provider-side rate limits and logs.

dig into why identical, already-failed requests keep getting re-sent and make the app stop pounding the upstream for errors that can't change. genuinely transient failures should still retry like they do now. the runtimes are third-party, so their retry behavior isn't ours to touch; the fix needs to live in the app.
