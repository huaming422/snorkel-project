#!/usr/bin/env bash
# Container setup for verifiers. Sourced (not exec'd) so exported
# PATH/VIRTUAL_ENV persist into the verifier process. The image pre-runs
# `uv sync` into /opt/venv with the full dependency tree plus the `dev` group
# (pytest, pytest-asyncio), so on a normal trial this is a fast no-op.
set -u

REPO=/repo/opensre
cd "$REPO" || { echo "test-setup: $REPO missing" >&2; return 1 2>/dev/null || exit 1; }

export PATH="/usr/local/bin:$PATH"   # uv

# Keep the task's own uv offline at grade time: the dependency closure is baked
# into the image, so a cache miss should fail fast instead of hitting the (cut)
# network. Scope the switch to this script so harbor's own `uv tool install`
# during trial prep (run earlier, with the network up) is unaffected.
export UV_OFFLINE=1

# Verify/refresh the venv from the baked cache (offline). --frozen pins to
# uv.lock; the image already synced, so this resolves against /opt/venv without
# downloads.
export VIRTUAL_ENV=/opt/venv UV_PROJECT_ENVIRONMENT=/opt/venv
uv sync --frozen --all-extras --group dev --offline 2>&1 | tail -3 || true

if [ -d "/opt/venv" ]; then
    export VIRTUAL_ENV=/opt/venv
    export PATH="/opt/venv/bin:$PATH"
fi

# Sanity: the pre-existing modules the new feature wires into must import
# cleanly before any verifier runs.
python -c "import config.local_settings; import core.tool; import tools.registry; import surfaces.cli.app" \
    && echo "test-setup: opensre importable" \
    || echo "test-setup: WARNING opensre import failed" >&2
