#!/usr/bin/env bash
# Validation environment for opensre-feat-runbook-investigations.
#
# The task image already bakes the repo's full dependency closure into the
# repo venv at /opt/venv (Dockerfile step 7: `uv sync --frozen --all-extras
# --group dev`), so there is NOTHING to install here — this script only
# activates that venv, pins the working dir, and loudly smoke-imports the
# PRE-EXISTING seams every story drives through. If any of those imports fail,
# the environment is broken and we fail fast rather than letting every story
# error opaquely at collection.
#
# Everything runs OFFLINE: no story opens a socket (pure selector; fake source
# injected by monkeypatch; CliRunner against a tmp home). We export UV_OFFLINE=1
# as a belt-and-suspenders guard so any stray resolve attempt fails loudly
# instead of reaching the network.

set -euo pipefail

export UV_OFFLINE=1

REPO=/repo/opensre
VENV=/opt/venv

if [ ! -x "${VENV}/bin/python" ]; then
    echo "FATAL: expected repo venv at ${VENV} (baked by the image); not found." >&2
    exit 1
fi

# shellcheck disable=SC1091
. "${VENV}/bin/activate"
cd "${REPO}"

# Smoke-import the pre-existing interfaces the stories bind to (NOT any
# solution-chosen symbol — those are discovered per story). A failure here means
# the image or venv is broken.
python - <<'PY'
import sys
sys.path.insert(0, "/repo/opensre")

# Pre-existing tool registry (chat-surface discovery seam).
from tools.registry import get_registered_tool_map
tool_map = get_registered_tool_map("chat")
assert isinstance(tool_map, dict) and tool_map, "chat tool registry is empty/broken"

# Pre-existing Click CLI app (operator-surface seam) + its test runner.
from surfaces.cli.app import cli  # noqa: F401
from click.testing import CliRunner  # noqa: F401

# Pre-existing agent tool-context type + local-settings store (story seams).
from core.tool import AgentToolContext  # noqa: F401
from config import local_settings  # noqa: F401
assert hasattr(local_settings, "paths"), "config.local_settings.paths missing"

print("opensre runbook-investigation validation env OK")
PY
