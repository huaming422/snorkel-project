"""Test harness for opensre-feat-runbook-investigations validation stories.

The runbook-investigation capability is entirely NEW in this task — every
domain type, the selector function, the guidance-tool function, and the
source-injection seam are names the solving agent chose. So this harness
hardcodes NONE of them. It provides only:

  * accessors onto PRE-EXISTING interfaces (the tool registry, the Click CLI
    app, the agent tool-context type, the local-settings store), and
  * generic, name-agnostic plumbing (a recording fake source, a source-config
    stand-in, monkeypatch installers that default to the reference attribute
    names but accept overrides).

Each story's procedure instructs the validation agent to DISCOVER the solution's
own symbols by reading the applied patch under /repo/opensre, construct the
solution's value types, and drive the behavior through these helpers. The
harness never imports a new (solution-chosen) symbol at module load, so a valid
alternative that renames internals never fails at collection.

Usage from a validation script::

    import sys
    sys.path.insert(0, "/tests/validate")
    import test_harness as th
"""

from __future__ import annotations

import importlib
import sys
from typing import Any, Callable, Iterable

# The opensre top-level packages live at the repository root. This is the image
# layout (a stable fact), not a solution-chosen path.
REPO = "/repo/opensre"


def _ensure_repo_on_path() -> None:
    if REPO not in sys.path:
        sys.path.insert(0, REPO)


# --------------------------------------------------------------------------- #
# Pre-existing interface: the chat tool registry
# --------------------------------------------------------------------------- #
def get_runbook_chat_tools() -> list[Any]:
    """Return every chat-surface tool whose registration name names runbooks.

    Discovery through the PRE-EXISTING ``tools.registry.get_registered_tool_map``
    interface, by the ``runbook`` domain noun. No pre-existing chat tool carries
    ``runbook`` in its registration name, so a match is the new capability
    regardless of what the solver named the function or module.
    """
    _ensure_repo_on_path()
    from tools.registry import get_registered_tool_map

    tool_map = get_registered_tool_map("chat")
    return [tool for name, tool in tool_map.items() if "runbook" in name.lower()]


def get_runbook_guidance_tool() -> Any:
    """Return the single runbook-guidance chat tool (read-only, context-aware).

    When several tools match the domain noun, prefer the one that satisfies the
    advisory contract (read-only + accepts runtime context + evidence mapper).
    Raises AssertionError if none is discoverable — that is itself a failure the
    stories surface.
    """
    matches = get_runbook_chat_tools()
    assert matches, (
        "No runbook-guidance tool is discoverable on the 'chat' surface. The "
        "capability must be registered as a chat tool."
    )

    def _read_only(tool: Any) -> bool:
        lvl = getattr(tool, "side_effect_level", None)
        return getattr(lvl, "value", lvl) == "read_only"

    preferred = [
        t
        for t in matches
        if _read_only(t)
        and getattr(t, "accepts_runtime_context", False) is True
        and getattr(t, "evidence_mapper", None) is not None
    ]
    return (preferred or matches)[0]


def runbook_tool_callable() -> Callable[..., Any]:
    """Return the guidance tool's underlying callable (``RegisteredTool.run``)."""
    return get_runbook_guidance_tool().run


def runbook_tool_module() -> Any:
    """Import and return the module that defines the guidance tool.

    Located via the PRE-EXISTING ``RegisteredTool.origin_module`` field, so the
    source-injection seam is reached without hardcoding the solution's module
    path. This is the module whose source-loading callables stories monkeypatch.
    """
    _ensure_repo_on_path()
    tool = get_runbook_guidance_tool()
    module_path = getattr(tool, "origin_module", "") or ""
    assert module_path, (
        "The registered runbook tool does not expose its origin module; cannot "
        "locate the source-injection seam."
    )
    return importlib.import_module(module_path)


def import_from(module_path: str, *names: str) -> Any:
    """Import ``names`` from ``module_path`` (discovered by the agent).

    Convenience for a story that has read the patch and knows the solution's
    module + symbol names. Returns a single object for one name, else a tuple.
    """
    _ensure_repo_on_path()
    module = importlib.import_module(module_path)
    objs = tuple(getattr(module, n) for n in names)
    return objs[0] if len(objs) == 1 else objs


# --------------------------------------------------------------------------- #
# Pre-existing interface: the agent tool-context type
# --------------------------------------------------------------------------- #
def make_agent_context(**resolved_integrations: Any) -> Any:
    """Build an ``AgentToolContext`` (pre-existing ``core.tool`` type).

    Defaults to marking GitHub connected, which is what the guidance tool needs
    to consider its configured sources available. Pass explicit integrations to
    override, e.g. ``make_agent_context()`` for the default or
    ``make_agent_context(github={"connection_verified": True})``.
    """
    _ensure_repo_on_path()
    from core.tool import AgentToolContext

    integrations = resolved_integrations or {"github": {"connection_verified": True}}
    return AgentToolContext(resolved_integrations=integrations)


# --------------------------------------------------------------------------- #
# Pre-existing interface: the Click CLI app + local-settings isolation
# --------------------------------------------------------------------------- #
def cli_app() -> Any:
    """Return the pre-existing Click CLI group (``surfaces.cli.app.cli``)."""
    _ensure_repo_on_path()
    from surfaces.cli.app import cli

    return cli


def cli_runner() -> Any:
    """Return a Click ``CliRunner``."""
    from click.testing import CliRunner

    return CliRunner()


def isolate_home(monkeypatch: Any, tmp_path: Any) -> None:
    """Point the local-settings home dir at ``tmp_path`` for CLI isolation.

    Uses the PRE-EXISTING ``config.local_settings.paths.OPENSRE_HOME_DIR``
    override so no real ``~/.opensre`` is touched and each case starts empty.
    """
    _ensure_repo_on_path()
    from config import local_settings

    monkeypatch.setattr(local_settings.paths, "OPENSRE_HOME_DIR", tmp_path)


# --------------------------------------------------------------------------- #
# Generic, name-agnostic plumbing
# --------------------------------------------------------------------------- #
class RecordingFakeSource:
    """A fake runbook source that mirrors the discovered ``RunbookSource``
    Protocol (``verify`` / ``resolve_reference`` / ``fetch_catalog`` /
    ``fetch_document``) and records what the tool asked it to fetch.

    The return values are the SOLUTION's value types, which the story constructs
    (after discovering them from the patch) and passes in here. The fake only
    stores and returns them, so this class stays agnostic to those type names.

    If the submitted solution names a Protocol method differently, subclass this
    and override that method — the recording attributes stay the same.

    Parameters
    ----------
    provider:        value of the ``provider`` attribute the resolver keys on.
    catalog:         object returned by ``fetch_catalog`` (the solution's
                     RunbookCatalog), or None to raise (source has no catalog).
    accepted_url:    the one URL ``resolve_reference`` accepts; any other URL
                     returns None (untrusted).
    reference:       object returned by ``resolve_reference`` for ``accepted_url``
                     (the solution's RunbookReference).
    document:        object returned by ``fetch_document`` (the solution's
                     RunbookDocument).
    document_error:  if set, ``fetch_document`` raises it (retrieval failure).
    catalog_error:   if set, ``fetch_catalog`` raises it.
    """

    def __init__(
        self,
        *,
        provider: str = "github",
        catalog: Any | None = None,
        accepted_url: str = "",
        reference: Any | None = None,
        document: Any | None = None,
        document_error: BaseException | None = None,
        catalog_error: BaseException | None = None,
    ) -> None:
        self.provider = provider
        self.catalog = catalog
        self.accepted_url = accepted_url
        self.reference = reference
        self.document = document
        self.document_error = document_error
        self.catalog_error = catalog_error
        # Recording state the stories assert on.
        self.fetched_reference: Any | None = None
        self.fetch_document_calls = 0
        self.fetch_catalog_calls = 0
        self.resolve_calls: list[str] = []

    def verify(self) -> tuple[bool, str]:
        return True, "ok"

    def resolve_reference(self, url: str) -> Any | None:
        self.resolve_calls.append(url)
        if url != self.accepted_url:
            return None
        return self.reference

    def fetch_catalog(self) -> Any:
        self.fetch_catalog_calls += 1
        if self.catalog_error is not None:
            raise self.catalog_error
        if self.catalog is None:
            raise RuntimeError("catalog unavailable")
        return self.catalog

    def fetch_document(self, reference: Any) -> Any:
        self.fetch_document_calls += 1
        if self.document_error is not None:
            raise self.document_error
        self.fetched_reference = reference
        assert self.document is not None, "RecordingFakeSource has no document to return"
        return self.document


def install_sources(
    monkeypatch: Any,
    module: Any,
    configs: Iterable[Any],
    resolver: Callable[[Any], Any | None],
    *,
    load_attr: str = "load_runbook_sources",
    resolve_attr: str = "resolve_runbook_source",
) -> None:
    """Inject fake sources into the guidance tool's module.

    Replaces the tool module's source-loading callable (returns ``configs``) and
    its resolver (maps each config to a fake source via ``resolver``). The
    attribute names default to the reference names; if the submitted solution
    names them differently, discover the names from the tool module and pass
    ``load_attr`` / ``resolve_attr`` overrides.

    ``resolver`` receives a config and returns a fake source (or None to mark it
    unavailable). The tool passes resolved integrations as a second arg to the
    real resolver; this installer ignores that arg so the resolver signature
    stays simple (``resolver(config)``).
    """
    cfg_tuple = tuple(configs)
    monkeypatch.setattr(module, load_attr, lambda: cfg_tuple)
    monkeypatch.setattr(
        module, resolve_attr, lambda config, _integrations=None: resolver(config)
    )


def result_text(result: Any) -> str:
    """A broad searchable string of an entire tool result, for absence checks
    (e.g. asserting a leaked secret is nowhere in the result)."""
    return str(result)
