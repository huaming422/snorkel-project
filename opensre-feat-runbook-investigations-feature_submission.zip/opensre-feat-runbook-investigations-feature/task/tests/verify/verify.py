"""Behavioral verifier for opensre-feat-runbook-investigations.

Two concerns, both tested through pre-existing stable interfaces:

1. pass_to_pass regression floor — the pre-existing CLI app and the system
   tool registry still import and build. A valid solution only ADDS a
   capability; it must not break the Click app or the registry walk. This
   holds on the unfixed tree (feature absent, surfaces intact) and on every
   valid fix.

2. fail_to_pass discoverability + advisory posture — the new runbook-guidance
   capability is reachable on the agent's ``chat`` surface as a discoverable,
   read-only tool. The tool is located by the ``runbook`` domain noun in its
   registration name (the operator/agent-facing term used throughout the
   task's instructions), never by a pinned implementation symbol, so any
   faithful naming is accepted. Read-only is the one contract-anchored posture
   (loading a runbook never changes system state); how run context is threaded
   and how a load becomes citeable evidence are solver design choices, not
   pinned here. These tests fail before the capability is implemented (no such
   tool is registered) and pass once it is.

3. fail_to_pass shell parity — the same runbook-source capability is reachable
   from the interactive shell. base.md states the capability is reachable from
   the shell as well as the CLI; this test locates a runbook slash command in
   the pre-existing merged shell command registry by the ``runbook`` domain
   noun, so any faithful naming is accepted. It fails before the capability is
   wired into the shell and passes once it is.

The precedence / trust-boundary / CLI-lifecycle behavior lives in the
validation stories, not here. This verifier is the backward-compatibility
floor plus discoverability, advisory read-only posture, and shell parity.

Runs under the repository's own interpreter (/opt/venv) via the
``[pytest] command`` override in verify.toml, because it imports repo code.
"""

from __future__ import annotations

import sys

# The opensre top-level packages (surfaces, tools, core, config, ...) live at
# the repository root. Make them importable regardless of the pytest CWD.
REPO = "/repo/opensre"
if REPO not in sys.path:
    sys.path.insert(0, REPO)

import pytest  # noqa: E402


# --------------------------------------------------------------------------- #
# pass_to_pass: pre-existing surfaces keep working (regression floor)
# --------------------------------------------------------------------------- #
def test_cli_app_still_imports_and_responds_to_help() -> None:
    """The pre-existing Click CLI app imports and ``--help`` exits cleanly.

    Backward-compatibility guard: adding the new capability must not break the
    existing CLI entrypoint. Agnostic to whether the feature exists.
    """
    from click.testing import CliRunner

    from surfaces.cli.app import cli

    result = CliRunner().invoke(cli, ["--help"])
    assert result.exit_code == 0, (
        "`cli --help` must exit 0; the pre-existing CLI app must keep working. "
        f"exit_code={result.exit_code}\noutput:\n{result.output}"
    )


def test_chat_tool_registry_still_builds() -> None:
    """The system tool registry still builds the ``chat`` surface map.

    A broken registration (import error in a tool module, malformed metadata)
    would make this raise. Holds before the change and on every valid fix.
    """
    from tools.registry import get_registered_tool_map

    tool_map = get_registered_tool_map("chat")
    assert isinstance(tool_map, dict)
    assert tool_map, "The chat tool registry must expose at least the pre-existing tools."


# --------------------------------------------------------------------------- #
# fail_to_pass: the runbook-guidance capability is discoverable on chat
# --------------------------------------------------------------------------- #
def _runbook_chat_tools():
    """Return the chat-surface tools whose registration name names runbooks.

    Discovery by the domain noun (``runbook``), which the task's instructions
    use for the capability — not by any pinned implementation symbol. No
    pre-existing chat tool carries ``runbook`` in its registration name, so a
    match is the new capability regardless of what the solver named it.
    """
    from tools.registry import get_registered_tool_map

    tool_map = get_registered_tool_map("chat")
    return [tool for name, tool in tool_map.items() if "runbook" in name.lower()]


def test_runbook_guidance_tool_is_discoverable_on_chat() -> None:
    """A runbook-guidance tool is registered and discoverable on ``chat``."""
    matches = _runbook_chat_tools()
    assert matches, (
        "Expected a runbook-guidance tool discoverable on the 'chat' surface "
        "(its registration name should name runbooks). None was found — the "
        "capability must be registered as a chat tool, not merely defined."
    )


def test_runbook_guidance_tool_has_read_only_advisory_contract() -> None:
    """The runbook-guidance tool is read-only (advisory): loading never mutates.

    The one contract-anchored posture here is read-only — "loading a runbook
    should only inform the investigation; it never changes any system state."
    That maps to a read-only side-effect level on the registered tool.

    How the tool is handed run context and how a loaded runbook becomes citeable
    evidence are design choices the solver makes (a tool may read its trusted
    sources directly rather than from per-run context, and evidence recording is
    judged at the design level); neither is pinned here.

    Asserted on whichever tool the discovery step found.
    """
    matches = _runbook_chat_tools()
    assert matches, "No runbook-guidance chat tool to inspect (see discoverability test)."

    # If more than one tool matched the domain noun, require at least one that is
    # read-only — that is the advisory guidance tool. The side-effect level may
    # be an enum or a bare string depending on the implementation; normalize both
    # to the "read_only" value.
    def _is_read_only(tool) -> bool:
        lvl = getattr(tool, "side_effect_level", None)
        return getattr(lvl, "value", lvl) == "read_only"

    good = [t for t in matches if _is_read_only(t)]
    assert good, (
        "The runbook-guidance chat tool must be read-only "
        "(side_effect_level == 'read_only'): loading a runbook is advisory and "
        "never changes any system state. Found runbook tool(s) that are not "
        "read-only: "
        + ", ".join(
            f"{getattr(t, 'name', '?')}(read_only={_is_read_only(t)})"
            for t in matches
        )
    )


# --------------------------------------------------------------------------- #
# fail_to_pass: the capability is reachable from the interactive shell too
# --------------------------------------------------------------------------- #
def test_runbook_capability_reachable_from_interactive_shell() -> None:
    """A runbook slash command is registered in the interactive-shell registry.

    base.md requires the same source-management capability to be reachable from
    the interactive shell, not only the CLI. The shell exposes its commands
    through a merged slash-command registry keyed by command name; a faithful
    solution registers a runbook command there. Discovery is by the ``runbook``
    domain noun in the command name, never by a pinned symbol, so any faithful
    naming is accepted. No pre-existing shell command carries ``runbook`` in its
    name, so a match is the new capability. Fails before shell parity is wired
    and passes once it is.
    """
    from surfaces.interactive_shell.command_registry import SLASH_COMMANDS

    runbook_commands = [name for name in SLASH_COMMANDS if "runbook" in name.lower()]
    assert runbook_commands, (
        "Expected a runbook slash command registered in the interactive-shell "
        "command registry (its name should name runbooks). None was found — the "
        "capability must be reachable from the interactive shell as well as the "
        f"CLI. Registered commands: {sorted(SLASH_COMMANDS)}"
    )


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q"]))
