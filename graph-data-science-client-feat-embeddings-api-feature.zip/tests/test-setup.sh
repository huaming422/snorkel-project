#!/usr/bin/env bash
# Container setup for the tests. Sourced (not exec'd) so exported
# PATH/VIRTUAL_ENV persist into the test process. The image pre-bakes the
# full dependency closure into /opt/venv via `uv sync --frozen` at build time,
# so on a normal trial the sync below is a fast offline no-op (resolution
# against the existing venv, no downloads).
set -u

REPO=/repo/graph-data-science-client
cd "$REPO" || { echo "test-setup: $REPO missing" >&2; return 1 2>/dev/null || exit 1; }

export PATH="/usr/local/bin:$PATH"            # uv
export VIRTUAL_ENV=/opt/venv UV_PROJECT_ENVIRONMENT=/opt/venv

# Build/verify the venv. Offline-first: the closure is already baked, so the
# frozen offline sync succeeds without network. The online retry is the logged
# fallback for an unexpectedly cold cache (counts as one resolve under [sync]).
if UV_OFFLINE=1 uv sync --frozen --all-extras --group test > /tmp/test-setup-sync.log 2>&1; then
    echo "test-setup: deps satisfied offline"
else
    echo "test-setup: offline sync incomplete, retrying online" >&2
    # The test network only reaches the judge host, so this retry usually fails.
    # Returning an error here would end the whole run before any result is
    # written; carry on with the venv the image already has.
    uv sync --frozen --all-extras --group test > /tmp/test-setup-sync.log 2>&1 \
        || { tail -40 /tmp/test-setup-sync.log >&2; echo "test-setup: uv sync failed; continuing with the existing /opt/venv" >&2; }
fi

# Make the repo venv interpreter the default python/pytest the tests invoke,
# so `import graphdatascience...` resolves to the editable repo install.
export PATH="/opt/venv/bin:$PATH"

# Sanity: the modules under test must import cleanly before any test runs.
python -c "import graphdatascience.session.aura_graph_data_science; import graphdatascience.procedure_surface.arrow.node_property_endpoints" \
    && echo "test-setup: graphdatascience importable" \
    || echo "test-setup: WARNING graphdatascience import failed" >&2
