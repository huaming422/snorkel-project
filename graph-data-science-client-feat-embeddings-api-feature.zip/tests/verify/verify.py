"""Existing session endpoint families keep working after the change.

These are regression checks: they pass on the starting code and must keep
passing once the new embeddings surface is added. Each one reaches a family
that already existed on the session, drives it offline through the shared
``JobClient`` seam (the same way the rest of this task's checks do), and
confirms the job it sends and the result it returns are unchanged.

Runs under the repo's own interpreter (/opt/venv); see verify.toml.
"""

from __future__ import annotations

from unittest import mock

import pandas as pd
import pytest

from graphdatascience.arrow_client.authenticated_flight_client import AuthenticatedArrowClient
from graphdatascience.session import AuraGraphDataScience
from graphdatascience.session.session_lifecycle_manager import Noop

SEAM = "graphdatascience.arrow_client.v2.job_client.JobClient"
SUMMARY = {
    "computeMillis": 11,
    "preProcessingMillis": 12,
    "configuration": {},
    "nodeCount": 3,
}


@pytest.fixture
def session_and_seam():
    arrow_client = mock.Mock(spec=AuthenticatedArrowClient)
    session = AuraGraphDataScience(
        arrow_client,
        db_query_runner=None,
        session_lifecycle_manager=Noop(),
        show_progress=False,
    )
    graph = mock.Mock()
    graph.name.return_value = "g"
    with (
        mock.patch(SEAM + ".run_job", return_value="job-1") as run_job,
        mock.patch(SEAM + ".run_job_and_wait", return_value="job-1") as run_job_and_wait,
        mock.patch(SEAM + ".stream_results", return_value=pd.DataFrame()),
        mock.patch(SEAM + ".get_summary", return_value=dict(SUMMARY)),
    ):
        yield session, graph, run_job, run_job_and_wait


def _dispatched(run_job, run_job_and_wait):
    call = (run_job if run_job.called else run_job_and_wait).call_args
    return call.args[1], call.args[2]


def test_fastrp_stream_still_dispatches_its_job(session_and_seam):
    session, graph, run_job, run_job_and_wait = session_and_seam
    session.fast_rp.stream(graph, embedding_dimension=8)
    action, payload = _dispatched(run_job, run_job_and_wait)
    assert action == "v2/embeddings.fastrp"
    assert payload["graphName"] == "g"
    assert payload["embeddingDimension"] == 8


def test_fastrp_stats_still_returns_its_summary(session_and_seam):
    session, graph, _run_job, _run_job_and_wait = session_and_seam
    result = session.fast_rp.stats(graph, embedding_dimension=8)
    assert result.compute_millis == 11
    assert result.pre_processing_millis == 12
    assert result.node_count == 3


def test_hashgnn_stream_still_dispatches_its_job(session_and_seam):
    session, graph, run_job, run_job_and_wait = session_and_seam
    session.hash_gnn.stream(graph, iterations=2, embedding_density=4)
    action, payload = _dispatched(run_job, run_job_and_wait)
    assert action == "v2/embeddings.hashgnn"
    assert payload["graphName"] == "g"


def test_wcc_stream_still_dispatches_its_job(session_and_seam):
    session, graph, run_job, run_job_and_wait = session_and_seam
    session.wcc.stream(graph)
    action, payload = _dispatched(run_job, run_job_and_wait)
    assert action == "v2/community.wcc"
    assert payload["graphName"] == "g"


def test_existing_session_families_are_still_reachable():
    session = AuraGraphDataScience(
        mock.Mock(spec=AuthenticatedArrowClient),
        db_query_runner=None,
        session_lifecycle_manager=Noop(),
        show_progress=False,
    )
    for name in ("fast_rp", "graph_sage", "hash_gnn", "node2vec", "fast_path", "model", "wcc", "page_rank"):
        assert getattr(session, name) is not None, name
