#!/usr/bin/env bash
# Validation environment for the embeddings-api stories.
#
# The library under test is a pure Python client package already installed
# editable into the repo venv /opt/venv at image build time (the closure is
# baked offline via `uv sync --frozen`). Every story drives the library fully
# offline: it constructs the session with a mocked Arrow client and patches the
# backend job seam, so NO live Neo4j/GDS backend and NO network are needed.
#
# This script just makes that repo venv the active interpreter (so the stories'
# `import graphdatascience...` resolves to the editable install) and fails fast
# if the package is not importable.

set -euo pipefail

REPO=/repo/graph-data-science-client
cd "$REPO"

export PATH="/usr/local/bin:$PATH"            # uv
export VIRTUAL_ENV=/opt/venv UV_PROJECT_ENVIRONMENT=/opt/venv

# Rebuild/verify the repo venv. Offline-first: the dependency closure is already
# baked, so the frozen offline sync is a fast no-op. The online retry is the
# logged fallback for an unexpectedly cold cache.
if UV_OFFLINE=1 uv sync --frozen --all-extras --group test > /tmp/validation-setup-sync.log 2>&1; then
    echo "validation-setup: deps satisfied offline"
else
    echo "validation-setup: offline sync incomplete, retrying online" >&2
    # The test network only reaches the judge host, so this retry usually fails.
    # This script is sourced, so exiting would end the whole run before any
    # result is written; carry on with the venv the image already has.
    uv sync --frozen --all-extras --group test > /tmp/validation-setup-sync.log 2>&1 \
        || { tail -40 /tmp/validation-setup-sync.log >&2; echo "validation-setup: uv sync failed; continuing with the existing /opt/venv" >&2; }
fi

# Make the repo venv interpreter the default python the stories invoke.
export PATH="/opt/venv/bin:$PATH"

# Loud smoke guard: the pre-existing session + backend-seam modules the stories
# build on must import cleanly before any story runs. (These modules exist at
# the starting commit; the embeddings surface added by the implementation is
# reached as an attribute of the constructed session, never imported here.)
python - <<'PY'
import pandas
from unittest import mock
from graphdatascience.session import AuraGraphDataScience
from graphdatascience.session.session_lifecycle_manager import Noop
from graphdatascience.arrow_client.authenticated_flight_client import AuthenticatedArrowClient
from graphdatascience.arrow_client.v2.job_client import JobClient
print("validation-setup: graphdatascience session + backend seam importable")
PY
