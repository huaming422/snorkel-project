## Task

The server now has node-embedding procedures for training a model, for encoding with an encoder that needs no training, and for predicting with a model trained earlier. The Python client's session can't reach any of them yet. Add them to the session as a preview, built the same way as the endpoint families the session already has.

## User stories / requirements

- Someone can encode embeddings for a graph in stream, mutate or write mode, picking which node properties feed the encoder. They either describe the encoder inline or give the name of one they trained earlier. Each run goes to the server for that graph, and mutate hands back a summary of the run.
- Someone can train a model on a graph from an encoder, a decoder and a name to save it under, either starting it as a job or waiting for the result. Later they predict embeddings for a graph by naming that model and the input node properties, in stream, mutate or write mode.
- Encoder or decoder settings that contradict each other or make no sense, like a ratio above 1, are refused as soon as they're given, before anything reaches the server. Sensible settings are accepted and the run goes ahead.
- Since this is a preview, reaching any of the three should warn the caller that it's early and may still change.
