"""Behavioral + structural checks for once-task crash recovery and completion.

Background — the failure these tests pin down:

A one-shot ("once") scheduled task is launched and parked in ``running`` until
an in-process completion hook finalizes it. When the backend bounces right as a
run finishes, that hook is lost and recovery must reconstruct the parent's
final state from the task's latest committed run. The original recovery blindly
forced every stuck once task to ``cancelled`` — so a run that actually finished
``success`` came back ``cancelled``. Three observable contracts follow from the
fix and are asserted below through stable, pre-existing repository and service
interfaces (never through any helper the solution introduces):

  * Recovery derives the parent's terminal state from the latest run outcome
    (success -> completed, failed -> failed, interrupted -> cancelled,
    skipped -> cancelled), propagating that run's own error.
  * A still-active occurrence (queued/launching/running) is left untouched.
  * "Latest" is the most recently *admitted* occurrence, not the one with the
    largest caller clock: under reversed/equal timestamps the newer admission
    still wins.
  * A late straggler occurrence cannot overwrite a newer parent result, and a
    proven launch is counted exactly once even across a lost launch-bookkeeping
    window.
  * Normal completion still finalizes a once task, and recurring (cron) parents
    are never forced terminal by recovery.
  * The new persistence columns stay internal (absent from read-back dicts) and
    the migration tree keeps a single head.

The tests drive real repositories against file-backed SQLite so the ORM and the
partial-unique indexes are enforced exactly as in production. Assertions check
observable invariants (parent status / last_error / run_count via the public
read-backs) rather than any internal mechanism, so any correct fix passes
regardless of how it records occurrence order or launch accounting.

This file is collected outside the backend test tree, so the repo's own
conftest is not in scope; the setup block below reproduces only the import
plumbing that conftest would otherwise provide (sys.path + one circular-import
guard), mirroring the backend's own unit-test harness.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from unittest.mock import MagicMock

# --- Import plumbing (replaces the backend conftest, which is out of scope) ---
_REPO_NAME = os.environ.get("REPO_NAME", "deer-flow")
_BACKEND = Path(f"/repo/{_REPO_NAME}/backend")
for _p in (str(_BACKEND), str(_BACKEND / "scripts")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

# Break the subagents circular import exactly as the backend's own conftest
# does, so importing the scheduler service in isolation cannot deadlock on it.
if "deerflow.subagents.executor" not in sys.modules:
    _executor_mock = MagicMock()
    _executor_mock.SubagentExecutor = MagicMock
    _executor_mock.SubagentResult = MagicMock
    _executor_mock.SubagentStatus = MagicMock
    _executor_mock.MAX_CONCURRENT_SUBAGENTS = 3
    _executor_mock.get_background_task_result = MagicMock()
    sys.modules["deerflow.subagents.executor"] = _executor_mock

from datetime import UTC, datetime, timedelta  # noqa: E402
from unittest.mock import patch  # noqa: E402

import pytest  # noqa: E402
from sqlalchemy import update  # noqa: E402

from app.scheduler.service import ScheduledTaskService  # noqa: E402
from deerflow.config.database_config import DatabaseConfig  # noqa: E402
from deerflow.persistence.engine import (  # noqa: E402
    close_engine,
    get_session_factory,
    init_engine_from_config,
)
from deerflow.persistence.scheduled_task_runs import ScheduledTaskRunRepository  # noqa: E402
from deerflow.persistence.scheduled_task_runs.model import ScheduledTaskRunRow  # noqa: E402
from deerflow.persistence.scheduled_tasks import ScheduledTaskRepository  # noqa: E402
from deerflow.persistence.scheduled_tasks.model import ScheduledTaskRow  # noqa: E402
from deerflow.runtime.runs.manager import RunRecord  # noqa: E402
from deerflow.runtime.runs.schemas import DisconnectMode, RunStatus  # noqa: E402

_NOW = datetime(2026, 7, 15, 12, 0, 0, tzinfo=UTC)
_RECOVERY_ERROR = "interrupted: gateway restarted"


# ---------------------------------------------------------------------------
# Setup helpers (mirror the behaviour the repo's own scheduler tests rely on)
# ---------------------------------------------------------------------------


async def _init_db(tmp_path) -> tuple[ScheduledTaskRepository, ScheduledTaskRunRepository]:
    """Bring up a fresh file-backed SQLite database and return both repos."""
    await init_engine_from_config(DatabaseConfig(backend="sqlite", sqlite_dir=str(tmp_path)))
    sf = get_session_factory()
    assert sf is not None
    return ScheduledTaskRepository(sf), ScheduledTaskRunRepository(sf)


async def _create_once_task(task_repo: ScheduledTaskRepository, *, task_id: str = "task-once-1") -> dict:
    return await task_repo.create(
        task_id=task_id,
        user_id="user-1",
        thread_id=None,
        context_mode="fresh_thread_per_run",
        assistant_id=None,
        title="Once Task",
        prompt="do it",
        schedule_type="once",
        schedule_spec={"run_at": "2026-07-15T12:00:00Z"},
        timezone="UTC",
        next_run_at=None,
    )


async def _create_cron_task(task_repo: ScheduledTaskRepository, *, task_id: str = "task-cron-1") -> dict:
    return await task_repo.create(
        task_id=task_id,
        user_id="user-1",
        thread_id=None,
        context_mode="fresh_thread_per_run",
        assistant_id=None,
        title="Cron Task",
        prompt="do it daily",
        schedule_type="cron",
        schedule_spec={"cron": "0 9 * * *"},
        timezone="UTC",
        next_run_at=_NOW + timedelta(hours=1),
    )


async def _create_run(
    run_repo: ScheduledTaskRunRepository,
    *,
    run_id: str,
    task_id: str = "task-once-1",
    status: str = "running",
    error: str | None = None,
    thread_id: str = "thread-1",
    created_at: datetime | None = None,
    scheduled_for: datetime | None = None,
) -> dict:
    """Insert one ``scheduled_task_runs`` row through the real repository."""
    now = created_at or _NOW
    row = await run_repo.create(
        run_record_id=run_id,
        task_id=task_id,
        thread_id=thread_id,
        scheduled_for=scheduled_for or now,
        trigger="scheduled",
        status=status,
    )
    sf = get_session_factory()
    assert sf is not None
    values: dict = {}
    if created_at is not None:
        values["created_at"] = created_at
    if error is not None:
        values["error"] = error
    if values:
        async with sf() as session:
            await session.execute(update(ScheduledTaskRunRow).where(ScheduledTaskRunRow.id == run_id).values(**values))
            await session.commit()
    return row


async def _set_task_running(task_id: str) -> None:
    """Park a task in ``running`` with no lease, simulating post-launch state."""
    sf = get_session_factory()
    assert sf is not None
    async with sf() as session:
        await session.execute(
            update(ScheduledTaskRow)
            .where(ScheduledTaskRow.id == task_id)
            .values(status="running", lease_owner=None, lease_expires_at=None, updated_at=_NOW)
        )
        await session.commit()


async def _get_task(task_repo: ScheduledTaskRepository, task_id: str) -> dict | None:
    return await task_repo.get_internal(task_id)


def _service(task_repo: ScheduledTaskRepository, run_repo: ScheduledTaskRunRepository) -> ScheduledTaskService:
    return ScheduledTaskService(
        task_repo=task_repo,
        task_run_repo=run_repo,
        launch_run=lambda **_kwargs: None,
        poll_interval_seconds=5,
        lease_seconds=120,
        max_concurrent_runs=3,
    )


def _completion_record(*, run_id: str, task_id: str, task_run_id: str, status, error: str | None = None, thread_id: str = "thread-1") -> RunRecord:
    return RunRecord(
        run_id=run_id,
        thread_id=thread_id,
        assistant_id=None,
        status=status,
        on_disconnect=DisconnectMode.continue_,
        metadata={"scheduled_task_id": task_id, "scheduled_task_run_id": task_run_id},
        user_id="user-1",
        error=error,
    )


# ---------------------------------------------------------------------------
# Criterion 1: recovery finalizes from the committed run outcome
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("run_status", "run_error", "expected_status", "expected_error"),
    [
        ("success", None, "completed", None),
        ("failed", "boom", "failed", "boom"),
        ("interrupted", "user cancelled", "cancelled", "user cancelled"),
        ("skipped", None, "cancelled", None),
    ],
)
async def test_recovery_finalizes_parent_from_run_outcome(tmp_path, run_status, run_error, expected_status, expected_error):
    """A crash after the run committed its outcome: recovery must mirror it.

    Before the fix every stuck once task was forced to ``cancelled`` with the
    generic recovery message, so success/failed outcomes and the run's own
    error were lost.
    """
    task_repo, run_repo = await _init_db(tmp_path)
    try:
        await _create_once_task(task_repo, task_id="task-outcome")
        await _set_task_running("task-outcome")
        await _create_run(run_repo, run_id="run-outcome", task_id="task-outcome", status=run_status, error=run_error)

        count = await task_repo.cancel_stuck_once_tasks(error=_RECOVERY_ERROR)
        assert count == 1

        task = await _get_task(task_repo, "task-outcome")
        assert task is not None
        assert task["status"] == expected_status
        assert task["last_error"] == expected_error
    finally:
        await close_engine()


# ---------------------------------------------------------------------------
# Criterion 2: an active occurrence is left untouched
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("active_status", ["queued", "launching", "running"])
async def test_recovery_leaves_active_occurrence_untouched(tmp_path, active_status):
    """A task whose latest occurrence is still live must not be forced terminal.

    Before the fix recovery cancelled it regardless; a genuinely running task
    would be killed mid-flight.
    """
    task_repo, run_repo = await _init_db(tmp_path)
    try:
        await _create_once_task(task_repo, task_id="task-active")
        await _set_task_running("task-active")
        await _create_run(run_repo, run_id="run-active", task_id="task-active", status=active_status)

        count = await task_repo.cancel_stuck_once_tasks(error=_RECOVERY_ERROR)
        assert count == 0

        task = await _get_task(task_repo, "task-active")
        assert task is not None
        assert task["status"] == "running"
    finally:
        await close_engine()


# ---------------------------------------------------------------------------
# Criterion 3: recovery orders by admission, not by caller clock
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("recovery_method", ["cancel_stuck_once_tasks", "reconcile_stuck_once_tasks"])
@pytest.mark.parametrize("older_clock_ahead_seconds", [30, 0], ids=["reversed-timestamps", "equal-timestamps"])
async def test_recovery_uses_admission_order_despite_clock_skew(tmp_path, recovery_method, older_clock_ahead_seconds):
    """The most recently admitted occurrence wins even when its clock is behind.

    The first-admitted occurrence is stamped with a clock that is equal to or
    ahead of the second. A timestamp-ordered recovery would pick the older
    ``skipped`` run (-> cancelled); the correct, admission-ordered recovery
    picks the newer ``success`` (-> completed). The blanket pre-fix recovery
    also lands on cancelled, so ``completed`` is reached only by a fix that
    tracks durable admission order.
    """
    task_repo, run_repo = await _init_db(tmp_path)
    try:
        await _create_once_task(task_repo)
        await _set_task_running("task-once-1")

        # Only the worker's clock changes; occurrences are admitted in order.
        with patch("deerflow.persistence.scheduled_task_runs.sql.datetime") as clock:
            clock.now.return_value = _NOW + timedelta(seconds=older_clock_ahead_seconds)
            older = await run_repo.create(
                run_record_id="ffffffff-ffff-4fff-8fff-ffffffffffff",
                task_id="task-once-1",
                thread_id="thread-old",
                scheduled_for=clock.now.return_value,
                trigger="manual",
                status="skipped",
            )
            clock.now.return_value = _NOW
            newer = await run_repo.create(
                run_record_id="00000000-0000-4000-8000-000000000000",
                task_id="task-once-1",
                thread_id="thread-new",
                scheduled_for=clock.now.return_value,
                trigger="manual",
                status="success",
            )
        # The older admission carries the larger (or equal) caller clock and a
        # descending UUID, so only admission order can break the tie correctly.
        assert older["created_at"] >= newer["created_at"]

        kwargs: dict = {"error": "interrupted: recovery"}
        if recovery_method == "reconcile_stuck_once_tasks":
            kwargs["now"] = _NOW + timedelta(minutes=1)
        count = await getattr(task_repo, recovery_method)(**kwargs)
        assert count == 1

        task = await _get_task(task_repo, "task-once-1")
        assert task is not None
        assert task["status"] == "completed"
        assert task["last_error"] is None
    finally:
        await close_engine()


# ---------------------------------------------------------------------------
# Criterion 4: a late straggler cannot overwrite a newer parent result
# ---------------------------------------------------------------------------


async def test_late_older_completion_does_not_overwrite_newer_result(tmp_path):
    """After a newer occurrence has projected its result, an older one arriving
    late through the completion path must not replace it.

    Before the fix the completion path re-derived the parent status from
    whichever occurrence completed last, so the stale ``failed`` straggler
    clobbered the newer ``success``.
    """
    task_repo, run_repo = await _init_db(tmp_path)
    try:
        await _create_once_task(task_repo, task_id="task-stale")
        await _set_task_running("task-stale")
        # Admitted first (older), then second (newer). Both terminal so the
        # single-active-occurrence index is not tripped during setup.
        await _create_run(run_repo, run_id="occ-old", task_id="task-stale", status="success", thread_id="thread-old")
        await _create_run(run_repo, run_id="occ-new", task_id="task-stale", status="success", thread_id="thread-new")

        service = _service(task_repo, run_repo)
        # The newer occurrence completes successfully and owns the parent result.
        await service.handle_run_completion(
            _completion_record(run_id="run-new", task_id="task-stale", task_run_id="occ-new", status=RunStatus.success, thread_id="thread-new")
        )
        projected = await _get_task(task_repo, "task-stale")
        assert projected is not None
        assert projected["status"] == "completed"
        assert projected["last_error"] is None

        # The older straggler now fails late; it must be fenced out so the
        # newer success survives (status and error both unchanged).
        await service.handle_run_completion(
            _completion_record(run_id="run-old", task_id="task-stale", task_run_id="occ-old", status=RunStatus.error, error="stale failure", thread_id="thread-old")
        )

        task = await _get_task(task_repo, "task-stale")
        assert task is not None
        assert task["status"] == "completed"
        assert task["last_error"] is None
    finally:
        await close_engine()


# ---------------------------------------------------------------------------
# Criterion 5: a proven launch is counted exactly once
# ---------------------------------------------------------------------------


async def test_launch_counted_exactly_once_across_completion_and_relaunch(tmp_path):
    """A single launch counts once, even when launch bookkeeping was lost to a
    crash and completion is what recovers the count, and even if a duplicate
    completion or a late launch-bookkeeping write arrives afterwards.

    Before the fix the completion path never recovered the count for a launch
    whose bookkeeping transaction was lost, so ``run_count`` stayed at 0.
    """
    task_repo, run_repo = await _init_db(tmp_path)
    try:
        await _create_once_task(task_repo, task_id="task-count")
        # An occurrence that was claimed/launching when the process crashed.
        await run_repo.create(
            run_record_id="occ-count",
            task_id="task-count",
            thread_id="thread-count",
            scheduled_for=_NOW,
            trigger="scheduled",
            status="queued",
        )
        claimed = await run_repo.claim_queued_run(
            "occ-count",
            lease_owner="launcher",
            now=_NOW,
            lease_seconds=120,
            global_max_concurrent_runs=3,
        )
        assert claimed is not None
        await _set_task_running("task-count")

        service = _service(task_repo, run_repo)
        record = _completion_record(run_id="run-count", task_id="task-count", task_run_id="occ-count", status=RunStatus.success, thread_id="thread-count")

        await service.handle_run_completion(record)
        task = await _get_task(task_repo, "task-count")
        assert task is not None
        assert task["run_count"] == 1

        # A duplicate delivery of the same completion must not count again.
        await service.handle_run_completion(record)
        assert (await _get_task(task_repo, "task-count"))["run_count"] == 1

        # A late launch-bookkeeping write for the same run must not count again.
        await task_repo.update_after_launch(
            "task-count",
            status="running",
            next_run_at=None,
            last_run_at=_NOW,
            last_run_id="run-count",
            last_thread_id="thread-count",
            last_error=None,
            increment_run_count=True,
            protect_terminal=True,
        )
        assert (await _get_task(task_repo, "task-count"))["run_count"] == 1
    finally:
        await close_engine()


# ---------------------------------------------------------------------------
# Criterion 6 (structural): new fields stay internal; migration has one head
# ---------------------------------------------------------------------------


async def test_new_persistence_fields_absent_from_read_backs(tmp_path):
    """The new occurrence/task columns are internal and must not surface in the
    dict responses callers read."""
    task_repo, run_repo = await _init_db(tmp_path)
    try:
        await _create_once_task(task_repo, task_id="task-internal")
        await _create_run(run_repo, run_id="occ-internal", task_id="task-internal", status="running")

        task = await _get_task(task_repo, "task-internal")
        assert task is not None
        occurrences = await run_repo.list_by_task("task-internal")
        assert occurrences

        internal_names = {"occurrence_seq", "launch_accounted", "last_occurrence_seq"}
        assert internal_names.isdisjoint(task.keys())
        for occurrence in occurrences:
            assert internal_names.isdisjoint(occurrence.keys())
    finally:
        await close_engine()


def test_migration_tree_has_single_head():
    """The migration history exposes exactly one head revision.

    ``_get_head_revision`` raises if the tree has branched into multiple heads,
    so a successful call asserts the single-head invariant without pinning any
    specific revision id (which is the solution's own choice).
    """
    from deerflow.persistence.bootstrap import _get_head_revision

    head = _get_head_revision()
    assert isinstance(head, str) and head


# ---------------------------------------------------------------------------
# Criterion 7: preserved behaviour (normal completion + cron through recovery)
# ---------------------------------------------------------------------------


async def test_normal_once_completion_still_finalizes(tmp_path):
    """A plain successful completion still drives a once task to ``completed``."""
    task_repo, run_repo = await _init_db(tmp_path)
    try:
        await _create_once_task(task_repo, task_id="task-happy")
        await _set_task_running("task-happy")
        await _create_run(run_repo, run_id="run-happy", task_id="task-happy", status="running")

        service = _service(task_repo, run_repo)
        await service.handle_run_completion(
            _completion_record(run_id="run-happy", task_id="task-happy", task_run_id="run-happy", status=RunStatus.success)
        )

        task = await _get_task(task_repo, "task-happy")
        assert task is not None
        assert task["status"] == "completed"
        assert task["last_error"] is None
    finally:
        await close_engine()


async def test_recovery_does_not_terminate_cron_parent(tmp_path):
    """Recovery must only consume once tasks; a recurring parent keeps running."""
    task_repo, run_repo = await _init_db(tmp_path)
    try:
        await _create_cron_task(task_repo, task_id="task-cron")
        sf = get_session_factory()
        assert sf is not None
        async with sf() as session:
            await session.execute(
                update(ScheduledTaskRow)
                .where(ScheduledTaskRow.id == "task-cron")
                .values(status="running", lease_owner=None, lease_expires_at=None)
            )
            await session.commit()

        count = await task_repo.cancel_stuck_once_tasks(error=_RECOVERY_ERROR)
        assert count == 0

        task = await _get_task(task_repo, "task-cron")
        assert task is not None
        assert task["status"] == "running"
    finally:
        await close_engine()
