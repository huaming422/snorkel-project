#!/bin/bash
# Setup for the deer-flow-fix-once-task-recovery verifier.
#
# This bug reproduces DETERMINISTICALLY in-process on the default file-backed
# SQLite backend used by the backend's own persistence tests: the crash window
# between the occurrence write and the parent write, the occurrence-ordering
# race, and the stale-overwrite race are all observable through the stable
# ScheduledTaskRepository / ScheduledTaskRunRepository methods on SQLite. No
# PostgreSQL, running gateway, or worker is required.
#
# The image already bakes a fully-resolved project environment at /opt/venv
# (uv sync --frozen --group dev at the base commit), and the backend's own
# packages are installed there as editable workspace members. A solver editing
# files under backend/packages/harness or backend/app changes code in place,
# so that baked environment imports the edited sources with no re-sync. Grade
# time has no network and the build reset the writable uv cache, so re-running
# uv sync here would try (and fail) to rebuild those workspace members from an
# empty cache; we deliberately do not sync. The verifier runs pytest with the
# baked interpreter directly (see verify.toml).

set -euo pipefail

export REPO_NAME=deer-flow
REPO_DIR="/repo/${REPO_NAME}"
VENV_PYTHON="/opt/venv/bin/python"

# Loud guard: the baked environment must exist and still import the persistence
# stack the verifier depends on. If this fails the image is broken, so fail the
# setup rather than letting pytest emit a confusing collection error later.
if [ ! -x "${VENV_PYTHON}" ]; then
    echo "test-setup: baked project interpreter ${VENV_PYTHON} is missing" >&2
    exit 1
fi
if ! PYTHONPATH="${REPO_DIR}/backend" "${VENV_PYTHON}" - <<'PY'
import aiosqlite  # noqa: F401  (async SQLite driver the file-backed tests use)
import sqlalchemy  # noqa: F401
import deerflow.persistence.engine  # noqa: F401  (editable workspace member)
PY
then
    echo "test-setup: baked environment cannot import the persistence stack" >&2
    exit 1
fi
