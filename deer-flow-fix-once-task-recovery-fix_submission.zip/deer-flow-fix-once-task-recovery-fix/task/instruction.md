## Task

some of our one-shot ("once") scheduled tasks come back with the wrong final
state after the backend bounces. one that actually ran and finished successfully
sometimes shows up afterwards as cancelled. it's intermittent and lines up with
the service going down and recovering right as a run finishes.

two more things show up in the same situations: a once task sometimes settles on
an older result that disagrees with what most recently happened, as if a late
straggler overwrote the real outcome, and the recorded number of times a task
has run can come out wrong around these same restart and retry moments.

when the service recovers a once task that was mid-flight, its final reported
state needs to match what that task's latest run actually did: a success stays a
success, a genuine failure stays a failure, an interruption settles as
cancelled. a stale late result must never replace a newer, real one. tasks still
genuinely running at recovery time should be left alone rather than forced
terminal, and recurring (non-once) tasks keep behaving as today.

it reproduces deterministically in-process against the default file-backed
sqlite persistence the backend's own tests use, so no postgres, gateway, or
workers are involved, and the backend package's dev environment is managed by
uv. dig in, find the root cause, and fix it.
