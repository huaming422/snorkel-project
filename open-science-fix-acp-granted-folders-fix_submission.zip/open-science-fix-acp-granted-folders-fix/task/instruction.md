## Task

a user granted the agent access to a folder outside the current
project, and the session shows it as read/write, but when the agent
actually tries to read or write a file in that folder it fails saying
the path is outside the active workspace. file references into that
same granted folder resolve fine, so it's just the agent's native file
read/write that gets rejected. the agent should be able to read and
write inside a folder the user granted it access to, matching the
access level that was granted. this is a behavior fix inside the
existing feature: nothing new needs persisting, no settings or storage
changes, no migration. dig into why native file access doesn't honor
the grant and fix it.
