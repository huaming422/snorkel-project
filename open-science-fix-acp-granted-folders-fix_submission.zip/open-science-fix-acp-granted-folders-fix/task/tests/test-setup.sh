#!/usr/bin/env bash
# Environment bootstrap for the verifier.
#
# The ACP main-process code under src/main/** is executed directly by vitest's
# transform (tests import TypeScript source, e.g. ./runtime.test-utils) — there
# is no dist/ build step to regenerate. verify.toml is parsed by the verifier
# tooling interpreter (/opt/tooling venv, Python 3.12, which ships tomllib), so
# no toml shim is installed here.
#
# Sourced (not exec'd) by the harbor runner so env vars set here stay live for
# the verifier subprocess.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/open-science}"
export REPO_DIR
cd "$REPO_DIR"

# Sanity check: vitest must be resolvable from the workspace root. The base
# image already ran `npm ci` with a warm cache, so a missing binary points at a
# corrupted node_modules — reinstall offline-first from the committed lockfile
# (the agent phase is network-isolated), with a logged online fallback.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/." \
         "Reinstalling from the committed lockfile." >&2
    npm ci --offline > /tmp/deps-node.log 2>&1 \
        || npm ci > /tmp/deps-node.log 2>&1 \
        || { tail -50 /tmp/deps-node.log >&2; exit 1; }
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR node=$(node --version 2>/dev/null || echo unknown) vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
