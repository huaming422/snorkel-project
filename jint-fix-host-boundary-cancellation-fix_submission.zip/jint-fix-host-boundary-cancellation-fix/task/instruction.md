## Task

we embed Jint to run user-supplied scripts and lean on an execution timeout or a cancellation token to stop anything that runs away. that safety net has gotten unreliable: when a script spends its time inside the C# callbacks we hand to it (functions we register, properties and methods on objects we expose to it), a cancelled token or an expired timeout no longer takes effect promptly. a loop that keeps calling into our host code runs well past the point it should have stopped, often all the way to the end. it used to cut off almost immediately. enforcement went lax after a past performance change to how those limits get checked.

dig in and restore prompt enforcement for scripts whose time goes into host calls. scripts that never touch host code shouldn't get any slower, and the timeout and token shouldn't reach past a live run: reading the engine's wrapped objects from plain C# once a run has finished, or while paused in the debugger, must not start tripping them.
