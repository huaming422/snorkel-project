// Behavioral checks for prompt time/cancellation enforcement when a script's
// time is spent inside host (CLR) callbacks. Every assertion drives the
// pre-existing public Jint.Engine / Jint.Options / TypeReference API; nothing
// here references any internal engine symbol, so the checks are robust to how a
// solution structures the fix (helper name, placement, inlined predicate).
//
// Two groups:
//   fail_to_pass  — a token cancelled from inside a loop of host calls must
//                   abort within about one host call, on every interop lane.
//   pass_to_pass  — enforcement is scoped to a live run: host-side reads of a
//                   wrapped object after a run, or while the run is parked at a
//                   debugger pause, must not trip an expired limit.

using System;
using System.Collections.Generic;
using System.Threading;
using Jint;
using Jint.Native;
using Jint.Runtime;
using Jint.Runtime.Debugger;
using Jint.Runtime.Interop;
using Xunit;

namespace Jint.Verify;

public class HostBoundaryConstraintTests
{
    // Cancelling from inside the 3rd host call makes the assertion deterministic:
    // the check at that call's return must abort the loop before a 4th call
    // starts. Without a boundary re-check the loop keeps running until the
    // statement-count countdown happens to fire, dozens of calls later, so the
    // call counter would read far more than 3 (usually the full 40).
    private static void AssertCancelledDuringThirdHostCall(
        Func<CancellationTokenSource, Engine, Func<int>> setup, string script)
    {
        using var cts = new CancellationTokenSource();
        var engine = new Engine(cfg => cfg.CancellationToken(cts.Token));
        var hostCallCount = setup(cts, engine);

        Assert.Throws<ExecutionCanceledException>(() => engine.Execute(script));
        Assert.Equal(3, hostCallCount());
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowHostDelegateCalls()
    {
        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            var calls = 0;
            engine.SetValue("work", new Action(() => { if (++calls == 3) { cts.Cancel(); } }));
            return () => calls;
        }, "for (var i = 0; i < 40; i++) { work(); }");
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowHostDelegateCallsInFunctionLocalTightLoop()
    {
        // the function-local loop shape arms the interpreter's tight for-body lane
        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            var calls = 0;
            engine.SetValue("work", new Action(() => { if (++calls == 3) { cts.Cancel(); } }));
            return () => calls;
        }, "function f() { for (var i = 0; i < 40; i++) { work(); } } f();");
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowClrMethodCalls()
    {
        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            var probe = new HostBoundaryProbe();
            probe.OnAccess = () => { if (probe.Accesses == 3) { cts.Cancel(); } };
            engine.SetValue("probe", probe);
            return () => probe.Accesses;
        }, "for (var i = 0; i < 40; i++) { probe.method(); }");
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowClrPropertyReads()
    {
        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            var probe = new HostBoundaryProbe();
            probe.OnAccess = () => { if (probe.Accesses == 3) { cts.Cancel(); } };
            engine.SetValue("probe", probe);
            return () => probe.Accesses;
        }, "for (var i = 0; i < 40; i++) { var x = probe.value; }");
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowClrPropertyWrites()
    {
        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            var probe = new HostBoundaryProbe();
            probe.OnAccess = () => { if (probe.Accesses == 3) { cts.Cancel(); } };
            engine.SetValue("probe", probe);
            return () => probe.Accesses;
        }, "for (var i = 0; i < 40; i++) { probe.value = i; }");
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowClrConstructorCalls()
    {
        try
        {
            AssertCancelledDuringThirdHostCall((cts, engine) =>
            {
                CtorProbe.Constructions = 0;
                CtorProbe.OnConstruct = () => { if (CtorProbe.Constructions == 3) { cts.Cancel(); } };
                engine.SetValue("Probe", TypeReference.CreateTypeReference<CtorProbe>(engine));
                return () => CtorProbe.Constructions;
            }, "for (var i = 0; i < 40; i++) { new Probe(); }");
        }
        finally
        {
            CtorProbe.OnConstruct = static () => { };
        }
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowDictionaryReads()
    {
        // wrapped IDictionary<string, T> reads take a different lane than reflected
        // members; that lane must observe the boundary too
        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            var dictionary = new SlowDictionary { { "someKey", 42 } };
            dictionary.OnAccess = () => { if (dictionary.Accesses == 3) { cts.Cancel(); } };
            engine.SetValue("cfg", dictionary);
            return () => dictionary.Accesses;
        }, "for (var i = 0; i < 40; i++) { var v = cfg.someKey; }");
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowDictionaryWrites()
    {
        // the wrapped IDictionary<string, T> write lane takes a different path than
        // the read lane above; a token cancelled from inside a write must abort the
        // loop before a fourth write starts
        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            var dictionary = new SlowDictionary();
            dictionary.OnAccess = () => { if (dictionary.Accesses == 3) { cts.Cancel(); } };
            engine.SetValue("cfg", dictionary);
            return () => dictionary.Accesses;
        }, "for (var i = 0; i < 40; i++) { cfg.someKey = i; }");
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowEnumerableIterations()
    {
        // for-of over a wrapped IEnumerable drives the host IEnumerator.MoveNext directly
        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            var enumerable = new SlowEnumerable();
            enumerable.OnMoveNext = () => { if (enumerable.MoveNextCalls == 3) { cts.Cancel(); } };
            engine.SetValue("items", enumerable);
            return () => enumerable.MoveNextCalls;
        }, "for (const x of items) { }");
    }

    [Fact]
    public void CancellationDuringLoneHostCallIsObservedAtItsReturn()
    {
        // isolates the post-return check: no further host call or statement-count
        // countdown follows, so only the check at the first call's own return can
        // observe the cancellation
        using var cts = new CancellationTokenSource();
        var engine = new Engine(cfg => cfg.CancellationToken(cts.Token));

        var calls = 0;
        engine.SetValue("work", new Action(() => { calls++; cts.Cancel(); }));

        Assert.Throws<ExecutionCanceledException>(() => engine.Execute("work(); work();"));
        Assert.Equal(1, calls);
    }

    [Fact]
    public void HostSideAccessToWrappedObjectDoesNotObserveCancellationAfterExecution()
    {
        // constraint state is only meaningful inside an Execute/Invoke window;
        // cancelling the token during normal teardown must not make later C#-side
        // reads of a wrapped object throw
        using var cts = new CancellationTokenSource();
        var engine = new Engine(cfg => cfg.CancellationToken(cts.Token));
        var probe = new HostBoundaryProbe();
        engine.SetValue("probe", probe);
        engine.Execute("probe.value;");

        cts.Cancel();

        var wrapper = engine.GetValue("probe").AsObject();
        Assert.Equal(42, wrapper.Get("value").AsNumber());
    }

    [Fact]
    public void HostSideAccessToWrappedObjectDoesNotObserveExpiredTimeoutAfterExecution()
    {
        // the time limit keeps counting while the engine is idle; an expired timer
        // must not make later C#-side reads throw
        var engine = new Engine(cfg => cfg.TimeoutInterval(TimeSpan.FromMilliseconds(50)));
        var probe = new HostBoundaryProbe();
        engine.SetValue("probe", probe);
        engine.Execute("probe.value;");

        Thread.Sleep(200);

        var wrapper = engine.GetValue("probe").AsObject();
        Assert.Equal(42, wrapper.Get("value").AsNumber());
    }

    [Fact]
    public void WrappedObjectReadWhilePausedInDebuggerDoesNotObserveExpiredTimeout()
    {
        // While execution is suspended at a debugger pause, a watch expression or
        // the embedder's own inspection code reads wrapped objects from C#. The
        // time limit keeps counting across that pause, but a read taken while the
        // run is parked at the break must not trip the lapsed limit — there is no
        // live run to abort. A debugger statement parks us at the break; the read
        // happens from inside the pause, after the limit has already lapsed.
        var engine = new Engine(cfg => cfg
            .TimeoutInterval(TimeSpan.FromMilliseconds(50))
            .DebugMode()
            .DebuggerStatementHandling(DebuggerStatementHandling.Script));

        var probe = new HostBoundaryProbe();
        engine.SetValue("probe", probe);

        double? readWhilePaused = null;
        Exception thrownWhilePaused = null;
        engine.Debugger.Break += (sender, info) =>
        {
            // parked at the debugger statement — let the limit lapse the way a
            // developer stepping through would, then read a wrapped member as a
            // watch expression would
            Thread.Sleep(200);
            try
            {
                readWhilePaused = engine.GetValue("probe").AsObject().Get("value").AsNumber();
            }
            catch (Exception ex)
            {
                thrownWhilePaused = ex;
            }

            return StepMode.None;
        };

        try
        {
            engine.Execute("debugger;");
        }
        catch (TimeoutException)
        {
            // the run resuming past the lapsed limit may abort — that is the live
            // run observing the limit and is not what this check is about
        }

        Assert.Null(thrownWhilePaused);
        Assert.Equal(42, readWhilePaused);
    }

    [Fact]
    public void WrappedObjectReadWhilePausedInDebuggerDoesNotObserveCancellation()
    {
        // Same guarantee for cancellation: a token cancelled while parked at a
        // debugger pause must not make a watch-style read of a wrapped object
        // throw. The suspended run is not advancing, so there is nothing to abort.
        using var cts = new CancellationTokenSource();
        var engine = new Engine(cfg => cfg
            .CancellationToken(cts.Token)
            .DebugMode()
            .DebuggerStatementHandling(DebuggerStatementHandling.Script));

        var probe = new HostBoundaryProbe();
        engine.SetValue("probe", probe);

        double? readWhilePaused = null;
        Exception thrownWhilePaused = null;
        engine.Debugger.Break += (sender, info) =>
        {
            cts.Cancel();
            try
            {
                readWhilePaused = engine.GetValue("probe").AsObject().Get("value").AsNumber();
            }
            catch (Exception ex)
            {
                thrownWhilePaused = ex;
            }

            return StepMode.None;
        };

        try
        {
            engine.Execute("debugger;");
        }
        catch (ExecutionCanceledException)
        {
            // the run resuming past the cancellation may abort — that is the live
            // run observing the token and is not what this check is about
        }

        Assert.Null(thrownWhilePaused);
        Assert.Equal(42, readWhilePaused);
    }

    private sealed class HostBoundaryProbe
    {
        public int Accesses;
        public Action OnAccess = static () => { };

        public int Value
        {
            get
            {
                Accesses++;
                OnAccess();
                return 42;
            }
            set
            {
                Accesses++;
                OnAccess();
            }
        }

        public int Method()
        {
            Accesses++;
            OnAccess();
            return 42;
        }
    }

    private sealed class CtorProbe
    {
        public static int Constructions;
        public static Action OnConstruct = static () => { };

        public CtorProbe()
        {
            Constructions++;
            OnConstruct();
        }
    }

    private sealed class SlowDictionary : IDictionary<string, object>
    {
        private readonly Dictionary<string, object> _inner = new();

        public int Accesses;
        public Action OnAccess = static () => { };

        public object this[string key]
        {
            get
            {
                Accesses++;
                OnAccess();
                return _inner[key];
            }
            set
            {
                Accesses++;
                OnAccess();
                _inner[key] = value;
            }
        }

        public bool TryGetValue(string key, out object value)
        {
            Accesses++;
            OnAccess();
            return _inner.TryGetValue(key, out value);
        }

        public ICollection<string> Keys => _inner.Keys;
        public ICollection<object> Values => _inner.Values;
        public int Count => _inner.Count;
        public bool IsReadOnly => false;

        public void Add(string key, object value) => _inner.Add(key, value);
        public bool ContainsKey(string key) => _inner.ContainsKey(key);
        public bool Remove(string key) => _inner.Remove(key);
        public void Add(KeyValuePair<string, object> item) => _inner.Add(item.Key, item.Value);
        public void Clear() => _inner.Clear();
        public bool Contains(KeyValuePair<string, object> item) => _inner.ContainsKey(item.Key);
        public void CopyTo(KeyValuePair<string, object>[] array, int arrayIndex) => ((IDictionary<string, object>) _inner).CopyTo(array, arrayIndex);
        public bool Remove(KeyValuePair<string, object> item) => _inner.Remove(item.Key);
        public IEnumerator<KeyValuePair<string, object>> GetEnumerator() => _inner.GetEnumerator();
        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator() => _inner.GetEnumerator();
    }

    private sealed class SlowEnumerable : System.Collections.IEnumerable
    {
        public int MoveNextCalls;
        public Action OnMoveNext = static () => { };

        public System.Collections.IEnumerator GetEnumerator() => new Enumerator(this);

        private sealed class Enumerator : System.Collections.IEnumerator
        {
            private readonly SlowEnumerable _owner;
            private int _index;

            public Enumerator(SlowEnumerable owner)
            {
                _owner = owner;
            }

            public object Current => _index;

            public bool MoveNext()
            {
                _owner.MoveNextCalls++;
                _owner.OnMoveNext();
                return _index++ < 40;
            }

            public void Reset()
            {
            }
        }
    }
}
