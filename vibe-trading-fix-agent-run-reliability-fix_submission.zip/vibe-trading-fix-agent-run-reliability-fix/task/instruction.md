## Task

our vibe-trading agent keeps falling over on the recurring "update the trading trend/plan report" job. it's the frustrating kind of failure: the run has already pulled the right market data and all but finished the report, then it blows up or stalls right at the finish line instead of delivering.

a few flavors we keep seeing:

- a report that's correct and backed by the data the run actually fetched gets rejected anyway, and the run gives up without ever updating the file.
- a run "finishes" by handing back unreadable markup instead of an actual report. or it dies on a single momentary provider hiccup right after the deliverable was already written.
- a run just freezes for tens of minutes with no activity at all and has to be killed by hand.

dig into why these otherwise-correct runs fail or stall and make the loop deliver reliably. keep the checks that stop the agent from reporting a price it never actually verified: those should stay exactly as strict as they are today.
