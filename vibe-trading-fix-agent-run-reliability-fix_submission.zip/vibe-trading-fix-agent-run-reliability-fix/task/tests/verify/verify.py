"""Behavioral checks for the agent run-reliability repairs.

Every test drives a pre-existing, stable public surface of the agent package:

  * ``GroundingLedger.validate_final_answer`` (the answer-grounding gate),
  * ``AgentLoop(...).run(...)`` (the ReAct loop's result dict + trace),
  * ``ChatLLM.stream_chat`` (the streaming provider wrapper),

plus one module-level reader in ``src.agent.loop`` that mirrors the package's
own ``_tool_timeout_seconds`` reader. No implementation-private helper is
imported by name, so the checks are agnostic to how each repair is built
(regex vs string split, daemon thread vs asyncio vs signal, counter vs loop,
etc.).

Runner note: this file is executed by ``uv run --no-sync pytest`` with the
working directory at the repository root, so the project interpreter already
resolves ``src.*``. The ``agent`` source root is also added to ``sys.path``
defensively, and the runtime home is redirected to a throwaway directory so
the suite never resolves against a developer's real state (the same isolation
the repository's own test conftest installs).
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, Callable

import pytest

# --------------------------------------------------------------------------- #
# Import bootstrap + runtime-root isolation (installed before importing any
# package module, because a few module-level constants bind the home-derived
# paths at import time).
# --------------------------------------------------------------------------- #
_AGENT_SRC_ROOT = Path.cwd() / "agent"
if _AGENT_SRC_ROOT.is_dir() and str(_AGENT_SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(_AGENT_SRC_ROOT))

_SANDBOX_HOME = Path(tempfile.mkdtemp(prefix="vt-verify-home-")).resolve()
os.environ.pop("VIBE_TRADING_HOME", None)
os.environ["HOME"] = str(_SANDBOX_HOME)
os.environ["USERPROFILE"] = str(_SANDBOX_HOME)
(_SANDBOX_HOME / ".vibe-trading").mkdir(parents=True, exist_ok=True)


# --------------------------------------------------------------------------- #
# Grounding gate: evidence setup and tolerant helpers.
# --------------------------------------------------------------------------- #
def _ledger_with_day_evidence():
    """Return a ledger whose identity is locked and whose only evidence is a
    single observed trading day (close 21.5) written as a run-dir OHLC CSV.

    This mirrors the project's own run-dir-CSV grounding idiom: the identity is
    locked by a ``search_symbol`` result and the price evidence is a per-symbol
    CSV the run wrote under ``data/raw`` — exactly how the product grounds a
    report whose prices came from the file-based data path.
    """
    from src.agent.grounding import GroundingLedger

    tmp = Path(tempfile.mkdtemp(prefix="vt-ground-"))
    raw = tmp / "data" / "raw"
    raw.mkdir(parents=True)
    (raw / "INTC_US.csv").write_text(
        "Date,Open,High,Low,Close,Adj Close,Volume\n"
        "2026-08-10,21.0,21.8,20.9,21.5,21.5,1000000\n",
        encoding="utf-8",
    )
    ledger = GroundingLedger(run_dir=tmp, user_message="请更新 INTC.US 的趋势报告")
    ledger.ingest_tool_result(
        tool_name="search_symbol",
        arguments={"query": "INTC"},
        result=json.dumps(
            {
                "ok": True,
                "source": "symbol_search",
                "data": {
                    "query": "INTC",
                    "count": 1,
                    "candidates": [
                        {
                            "symbol": "INTC.US",
                            "name": "Intel",
                            "market": "us",
                            "type": "equity",
                            "exchange": "NMS",
                            "source": "yahoo",
                        }
                    ],
                    "sources": {"yahoo": "ok"},
                },
            },
            ensure_ascii=False,
        ),
        call_id="lock1",
        success=True,
    )
    return ledger


def _single_row_report(date_cell: str, close: str = "21.5") -> str:
    """A grounded one-row close report whose date column uses ``date_cell``."""
    return (
        "INTC.US（yahoo，USD）数据来源：yahoo\n\n"
        "| 日期 | 收盘 |\n"
        "|---|---:|\n"
        f"| {date_cell} | {close} |\n"
    )


def test_grounding_annotated_date_matches_evidence() -> None:
    """A report-style date cell carrying a weekday/intraday/ISO annotation must
    line up with the evidence row for that trading day, so a correct,
    evidence-backed price in that row is accepted.

    The bare year-less day and the plain full-ISO day are the already-handled
    baseline and must stay accepted (no regression); the annotated forms are
    the ones that must newly line up with the evidence day.
    """
    # Baseline forms the gate already accepted — must remain valid.
    for baseline in ("08-10", "2026-08-10"):
        result = _ledger_with_day_evidence().validate_final_answer(
            _single_row_report(baseline)
        )
        assert result.valid is True, (baseline, result.issues)

    # Annotated day cells: a weekday/intraday marker or an ISO date carrying one.
    # The correct, observed close for the day must still be accepted.
    annotated_forms = [
        "2026-08-10(一)",   # full ISO + CJK weekday marker
        "2026-08-10盘中",    # full ISO + intraday session marker
        "08-10 周一",        # year-less + spaced CJK weekday
        "08-10周一盘中",      # year-less + weekday + intraday, no parens
        "08-10(Mon)",       # year-less + Latin weekday marker
    ]
    for cell in annotated_forms:
        result = _ledger_with_day_evidence().validate_final_answer(
            _single_row_report(cell)
        )
        assert result.valid is True, (cell, result.issues)


def test_grounding_safety_checks_preserved() -> None:
    """The numeric-claim safety invariant survives the false-rejection fix: a
    fabricated price (even in an annotated-date row), a price for a symbol no
    tool call handled, and a draft missing currency/source are all still
    rejected. This invariant holds regardless of how the date-matching
    behavior is implemented.

    The fix is exercised by the first assertion: a *correct*, evidence-backed
    price in an annotated-date row must be *accepted* — the baseline rejects
    it as ``numeric_claim_unavailable`` because the unpatched matcher cannot
    resolve ``2026-08-10(一)`` against the ``2026-08-10`` evidence row.
    """
    # A correct, observed close in an annotated-date row must be accepted.
    # Without the oracle patch, _timestamp_matches_claim_date cannot match a
    # full-ISO annotated date cell ("2026-08-10(一)") to the "2026-08-10"
    # evidence row; the price is rejected as numeric_claim_unavailable.
    # With the oracle patch the prefix-based matcher resolves the date and
    # accepts the correct close. This assertion fails on unpatched code.
    correct_annotated = _ledger_with_day_evidence().validate_final_answer(
        _single_row_report("2026-08-10(一)", close="21.5")
    )
    assert correct_annotated.valid is True, (
        "correct observed price in annotated full-ISO date row must be accepted: "
        + repr(correct_annotated.issues)
    )

    # A fabricated close in an annotated-date row is still a conflict: masking
    # the date must not stop the price from being checked.
    fabricated = _ledger_with_day_evidence().validate_final_answer(
        _single_row_report("08-10(一)", close="99.99")
    )
    assert fabricated.valid is False
    assert any(i["code"] == "numeric_claim_conflict" for i in fabricated.issues), (
        fabricated.issues
    )

    # A price attached to a symbol the session never handled cannot be grounded.
    unsourced = _ledger_with_day_evidence().validate_final_answer(
        "ZZZ.US（yahoo，USD）在 2026-08-10 的已观测收盘价为 100.0。"
    )
    assert unsourced.valid is False, unsourced.issues

    # A draft that omits currency/source provenance is still rejected.
    missing_provenance = _ledger_with_day_evidence().validate_final_answer(
        "INTC.US 在 2026-08-10 的收盘价为 21.5。"
    )
    assert missing_provenance.valid is False, missing_provenance.issues


# --------------------------------------------------------------------------- #
# ReAct loop: scripted-LLM drivers through the public AgentLoop surface.
# --------------------------------------------------------------------------- #
class _StreamChunk:
    """Minimal LangChain message-chunk stand-in for the streaming path."""

    def __init__(self, content: str) -> None:
        self.content = content
        self.tool_calls: list[dict[str, Any]] = []
        self.additional_kwargs: dict[str, Any] = {}
        self.response_metadata = {"finish_reason": "stop"}
        self.usage_metadata = None

    def __add__(self, other: "_StreamChunk") -> "_StreamChunk":
        return _StreamChunk(f"{self.content}{other.content}")


class _ScriptedStreamingLLM:
    """Yield one scripted content string per stream() call (ChatLLM backend)."""

    def __init__(self, responses: list[str]) -> None:
        self._responses = list(responses)

    def bind_tools(self, tools: list[dict[str, Any]]) -> "_ScriptedStreamingLLM":
        return self

    def stream(self, messages: list[dict[str, Any]], config: dict[str, Any] | None = None):
        yield _StreamChunk(self._responses.pop(0))


def _real_chat_llm(backend: _ScriptedStreamingLLM):
    """Wrap a scripted backend in the real ChatLLM so the genuine streaming +
    tool-call-markup parsing path runs (the loop calls stream_chat for real)."""
    from src.providers.chat import ChatLLM

    client = ChatLLM.__new__(ChatLLM)
    client.model_name = "deepseek-v4-pro"
    client._llm = backend
    return client


class _ImmediateHeartbeatTimer:
    """Fire one heartbeat immediately instead of waiting on a real timer."""

    def __init__(self, tool_name: str, interval: float, emit: Callable) -> None:
        self._tool_name = tool_name
        self._emit = emit

    def __enter__(self) -> "_ImmediateHeartbeatTimer":
        self._emit({"tool": self._tool_name, "elapsed_s": 0.01})
        return self

    def __exit__(self, *exc: Any) -> None:
        return None


def _run_degraded(result: dict, run_dir: Path) -> bool:
    """Tolerant read of the degraded signal: the result key OR a degraded
    marker on the trace end event (mechanism-agnostic across spellings that
    still make a fallback distinguishable from a real delivery)."""
    if result.get("degraded") is True:
        return True
    trace = run_dir / "trace.jsonl"
    if trace.exists():
        for line in trace.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
            except ValueError:
                continue
            if entry.get("type") == "end" and entry.get("degraded") is True:
                return True
    return False


def test_loop_withholds_tool_call_markup_and_marks_degraded(monkeypatch) -> None:
    """On the forced-text final iteration, a response that is tool-call / DSML
    markup as prose (a garbled fullwidth-bar form a structured parser does not
    turn into a tool call) must NOT be released verbatim. With no iteration
    budget left, the run completes with a neutral, markup-free fallback and is
    marked degraded.
    """
    import src.agent.loop as loop_module
    from src.agent.loop import AgentLoop
    from src.agent.tools import ToolRegistry
    from src.memory.persistent import PersistentMemory

    monkeypatch.setattr(loop_module, "HeartbeatTimer", _ImmediateHeartbeatTimer)

    # Tool-call markup emitted as prose on the forced-text turn. The leading
    # prose + truncated fullwidth-bar block keeps it as assistant *content*
    # (a pure block would be executed as a tool call, not released as an answer).
    markup = (
        "Final answer: <｜｜DSML｜｜tool_calls> "
        '<｜｜DSML｜｜invoke name="trading_quote"> (my full response here)'
    )
    tmp = Path(tempfile.mkdtemp(prefix="vt-loop-dsml-"))
    events: list[tuple[str, dict[str, Any]]] = []
    agent = AgentLoop(
        registry=ToolRegistry(),
        llm=_real_chat_llm(_ScriptedStreamingLLM([markup])),
        event_callback=lambda event_type, payload: events.append((event_type, payload)),
        max_iterations=1,
        persistent_memory=PersistentMemory(memory_dir=tmp / "memory"),
    )
    run_dir = tmp / "run"
    agent.memory.run_dir = str(run_dir)

    result = agent.run("update the trading trend report")

    assert result["status"] == "success"
    # The raw markup must never be the delivered answer.
    assert "<" not in result.get("content", ""), result.get("content")
    # The released fallback is distinguishable from a real delivery.
    assert _run_degraded(result, run_dir), result


class _StubLLMResponse:
    """Stand-in for ChatLLM's response object (no text, no tool calls)."""

    def __init__(self, content: str = "") -> None:
        self.content = content
        self.tool_calls: list[Any] = []
        self.reasoning_content: str | None = None
        self.has_tool_calls = False
        self.usage_metadata = None


class _OneEmptyThenFinalLLM:
    """Return an empty completion first, then a plain final answer.

    Accepts ``timeout`` and ``idle_timeout_s`` because the loop passes them;
    a stub lacking them would raise TypeError when the loop forwards them.
    """

    def __init__(self) -> None:
        self.calls = 0

    def stream_chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[Any] | None = None,
        on_text_chunk: Callable[[str], None] | None = None,
        on_reasoning_chunk: Callable[[str], None] | None = None,
        timeout: Any | None = None,
        idle_timeout_s: Any | None = None,
        should_cancel: Callable[[], bool] | None = None,
    ) -> _StubLLMResponse:
        self.calls += 1
        if self.calls == 1:
            return _StubLLMResponse("")
        return _StubLLMResponse("报告已更新完成，请查收。")

    def chat(self, messages: list[dict[str, Any]], **_: Any) -> _StubLLMResponse:
        return _StubLLMResponse()


class _AlwaysEmptyLLM:
    """Always return an empty completion."""

    def __init__(self) -> None:
        self.calls = 0

    def stream_chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[Any] | None = None,
        on_text_chunk: Callable[[str], None] | None = None,
        on_reasoning_chunk: Callable[[str], None] | None = None,
        timeout: Any | None = None,
        idle_timeout_s: Any | None = None,
        should_cancel: Callable[[], bool] | None = None,
    ) -> _StubLLMResponse:
        self.calls += 1
        return _StubLLMResponse("")

    def chat(self, messages: list[dict[str, Any]], **_: Any) -> _StubLLMResponse:
        return _StubLLMResponse()


def _build_loop(llm: Any, max_iter: int):
    from src.agent.loop import AgentLoop
    from src.memory.persistent import PersistentMemory
    from src.tools import build_registry

    pm = PersistentMemory()
    agent = AgentLoop(
        registry=build_registry(persistent_memory=pm, include_shell_tools=False),
        llm=llm,
        event_callback=None,
        max_iterations=max_iter,
        persistent_memory=pm,
    )
    run_dir = Path(tempfile.mkdtemp(prefix="vt-loop-empty-")) / "run"
    run_dir.mkdir(parents=True, exist_ok=True)
    agent.memory.run_dir = str(run_dir)
    return agent


def test_loop_single_empty_retries_double_empty_fails() -> None:
    """One transient empty completion is retried (the run still delivers); a
    second consecutive empty fails the run with the ``empty_model_response``
    reason naming the second iteration.
    """
    one_empty = _OneEmptyThenFinalLLM()
    recovered = _build_loop(one_empty, max_iter=3).run(user_message="跟我打个招呼")
    assert recovered["status"] == "success"
    assert one_empty.calls == 2, one_empty.calls

    always_empty = _AlwaysEmptyLLM()
    failed = _build_loop(always_empty, max_iter=3).run(user_message="跟我打个招呼")
    assert failed["status"] == "failed"
    assert failed["reason"].startswith("empty_model_response"), failed["reason"]
    assert "iteration 2" in failed["reason"], failed["reason"]
    assert always_empty.calls == 2, always_empty.calls


# --------------------------------------------------------------------------- #
# Streaming provider wrapper: idle-timeout behavior through ChatLLM.stream_chat.
# --------------------------------------------------------------------------- #
class _ProviderFakeChunk:
    def __init__(self, *, content: str = "", finish_reason: str = "stop") -> None:
        self.content = content
        self.tool_calls: list[dict[str, Any]] = []
        self.additional_kwargs: dict[str, Any] = {}
        self.response_metadata = {"finish_reason": finish_reason}
        self.usage_metadata = None

    def __add__(self, other: "_ProviderFakeChunk") -> "_ProviderFakeChunk":
        return _ProviderFakeChunk(
            content=f"{self.content}{other.content}",
            finish_reason=other.response_metadata.get("finish_reason", "stop"),
        )


class _StallingStreamingLLM:
    """Yield one chunk, then go silent past the idle budget before the next."""

    def bind_tools(self, tools: list[dict[str, Any]]) -> "_StallingStreamingLLM":
        return self

    def stream(self, messages: list[dict[str, Any]], config: dict[str, Any] | None = None):
        yield _ProviderFakeChunk(content="partial ")
        time.sleep(0.6)
        yield _ProviderFakeChunk(content="late")


class _FlowingStreamingLLM:
    """Yield chunks steadily, each well within the idle budget."""

    def bind_tools(self, tools: list[dict[str, Any]]) -> "_FlowingStreamingLLM":
        return self

    def stream(self, messages: list[dict[str, Any]], config: dict[str, Any] | None = None):
        for piece in ("a", "b", "c"):
            time.sleep(0.05)
            yield _ProviderFakeChunk(content=piece)


def test_stream_idle_timeout_aborts_and_flow_ok() -> None:
    """``stream_chat`` bounds a silently stalled stream: no delta within the
    idle budget raises a retryable ``ProviderStreamError``; a stream whose
    deltas keep arriving completes and returns the concatenated content.
    """
    from src.providers.chat import ProviderStreamError

    with pytest.raises(ProviderStreamError) as excinfo:
        _real_chat_llm(_StallingStreamingLLM()).stream_chat(
            [{"role": "user", "content": "hi"}],
            idle_timeout_s=0.2,
        )
    assert excinfo.value.retryable is True

    flowing = _real_chat_llm(_FlowingStreamingLLM()).stream_chat(
        [{"role": "user", "content": "hi"}],
        idle_timeout_s=0.2,
    )
    assert flowing.content == "abc"


# --------------------------------------------------------------------------- #
# Configurable per-call LLM timeout reader (mirrors _tool_timeout_seconds).
# --------------------------------------------------------------------------- #
def test_llm_timeout_config_default_and_override(monkeypatch) -> None:
    """The loop exposes a per-call LLM timeout reader: a positive default, a
    honored module-level override, and the positive default again once the
    override is removed.
    """
    import src.agent.loop as loop_module

    reader = getattr(loop_module, "_llm_timeout_seconds", None)
    assert callable(reader), "expected a module-level LLM timeout reader in src.agent.loop"

    assert reader() > 0

    monkeypatch.setattr(loop_module, "LLM_TIMEOUT_SECONDS", 42.0, raising=False)
    assert reader() == 42.0

    monkeypatch.delattr(loop_module, "LLM_TIMEOUT_SECONDS", raising=False)
    assert reader() > 0
