#!/usr/bin/env bash
# test-setup.sh — runs once before the verifier (sourced, not exec'd).
#
# The agent-reliability code under test lives in the root vibe-trading project
# (agent/src/...), imported in tests as `src.agent.*` / `src.providers.*` /
# `src.config.*` with `pythonpath = ["agent"]` (pyproject [tool.pytest]).
# The dependency closure is already baked into /opt/venv at the base commit
# (Dockerfile step 10); this step re-syncs it so the agent's edits are live,
# then fails fast on a broken import before the verifier runs a confusing
# pytest stack. uv runs offline against the warm cache; --frozen keeps the
# baked lockfile.

set -euo pipefail

export REPO_NAME=vibe-trading

cd /repo/vibe-trading
# Offline sync against the warm cache baked at the base commit (step 10). The
# agent phase runs with no network, so offline is the path that matters; --frozen
# keeps the baked lockfile. Sync the `dev` optional-dependency group: the test
# runner (`pytest`) ships there, and a plain `uv sync` prunes anything outside the
# resolved set — which would delete the baked pytest and make
# `uv run --no-sync pytest` fail to spawn. `--extra dev` (not `--all-extras`)
# because one broker-provider extra pins a dependency with no wheel for this
# image's interpreter; step 10's bake resolves to exactly this dev set for the
# same reason. A cold cache fails loudly here rather than mid-pytest.
uv sync --frozen --offline --extra dev --quiet 2>&1 | tail -5

# Smoke import — surface a broken environment here, not mid-pytest. Only
# pre-existing, stable public symbols are imported so this step never couples
# to the solution's new helper names. The agent package lives under the project's
# `agent/` source root, which pyproject exposes to the test runner via
# `pythonpath = ["agent"]`; a bare interpreter does not read that key, so the
# smoke guard puts the same root on sys.path first (the verifier itself does the
# equivalent in-process).
uv run --no-sync python - <<'PY'
import sys
sys.path.insert(0, "agent")
from src.agent.grounding import GroundingLedger
from src.agent.loop import AgentLoop
from src.providers.chat import ChatLLM
print("vibe-trading agent imports OK")
PY
