"""Checks on the executable entries `aube install` writes for a
dependency's command-line program.

Every check drives the `aube install` CLI against the repo's committed
offline registry and then looks at what lands in the project's
`node_modules/.bin/`: the kind of entry, the module-resolution path it
exports, and, for one check, what a program launched through that entry
can actually load.

The base package tree is the repo's own bin-shim fixture: a project that
depends on `loose-envify@1.4.0`, which ships a CLI (`loose-envify`) and
depends on `js-tokens`. Every package is served from the committed
Verdaccio storage with no uplinks, so the whole run is offline.

The environment mirrors the repo's own bats harness
(`test/test_helper/common_setup.bash`): a throwaway HOME / XDG / TMPDIR
per project, `CI` unset, the update notifier off, colour off, and an
`.npmrc` pointing at the local registry.
"""

from __future__ import annotations

import os
import shutil
import socket
import subprocess
import tempfile
import time
from pathlib import Path

import pytest


# ---------------------------------------------------------------------------
# Locations. REPO_DIR is exported by tests/test-setup.sh (defaults to the
# in-image clone) and is where the freshly built `aube` binary lives on
# PATH. The committed offline registry ships inside that same clone.
# ---------------------------------------------------------------------------
REPO_DIR = Path(os.environ.get("REPO_DIR", "/repo/aube"))
REGISTRY_CONFIG = REPO_DIR / "test" / "registry" / "config.yaml"
VERDACCIO_PORT = int(os.environ.get("VERDACCIO_PORT", "4873"))
REGISTRY_URL = f"http://localhost:{VERDACCIO_PORT}"

# The bin-shim fixture, copied verbatim from the repo's own
# `_setup_bin_fixture`: a project depending on a package that ships a CLI
# and depends on another package (js-tokens).
FIXTURE_PACKAGE_JSON = (
    '{\n'
    '  "name": "aube-test-bin-shims",\n'
    '  "version": "1.0.0",\n'
    '  "dependencies": { "loose-envify": "1.4.0" }\n'
    '}\n'
)
BIN_NAME = "loose-envify"

# Same project plus a second dependency that brings in a package of its own
# (`@pnpm.e2e/pkg-with-1-dep` depends on `@pnpm.e2e/dep-of-pkg-with-1-dep`).
# Neither `js-tokens` nor `@pnpm.e2e/dep-of-pkg-with-1-dep` is a direct
# dependency of the project, so both are installed only indirectly.
INDIRECT_FIXTURE_PACKAGE_JSON = (
    '{\n'
    '  "name": "aube-test-bin-indirect-deps",\n'
    '  "version": "1.0.0",\n'
    '  "dependencies": {\n'
    '    "loose-envify": "1.4.0",\n'
    '    "@pnpm.e2e/pkg-with-1-dep": "100.0.0"\n'
    '  }\n'
    '}\n'
)
INDIRECT_PACKAGES = {
    "js-tokens": "js-tokens@4.0.0",
    "@pnpm.e2e/dep-of-pkg-with-1-dep": "@pnpm.e2e/dep-of-pkg-with-1-dep@",
}

# Program body used in place of loose-envify's own cli.js. Like `astro check`
# looking for typescript, or eslint looking for a plugin, it looks each
# package named on its command line up from the project it is run in and
# loads that package's manifest.
PROJECT_LOOKUP_CLI = """#!/usr/bin/env node
'use strict'
const project = process.cwd()
for (const name of process.argv.slice(2)) {
  const manifest = require.resolve(name + '/package.json', { paths: [project] })
  const pkg = require(manifest)
  console.log('loaded ' + pkg.name + '@' + pkg.version)
}
"""


# ---------------------------------------------------------------------------
# Registry lifecycle — start the committed Verdaccio once for the whole
# test session, tear it down at the end. Serves only from the committed
# storage dir (no uplinks), so this needs no network.
# ---------------------------------------------------------------------------
def _registry_up() -> bool:
    # Probe with curl (same mechanism test-setup.sh uses for its readiness
    # wait) rather than urllib. On a cold Modal VM Verdaccio's first HTTP
    # response can take several seconds; a short per-probe urllib timeout
    # rejects a registry that is in fact up, so every probe fails and the
    # fixture deadlines out even though the server is in fact ready.
    #
    # NOTE: use -s (silent) WITHOUT -f. test-setup.sh uses `curl -s` and
    # considers any HTTP response a success — this matches. The Verdaccio
    # wrapper config sets `web: enable: false`, so the root URL returns a
    # non-2xx status code; -f would make curl exit non-zero on those codes
    # and _registry_up() would always return False even when Verdaccio is up.
    curl = shutil.which("curl")
    if curl is None:
        return False
    try:
        result = subprocess.run(
            [curl, "-s", "--max-time", "5", f"{REGISTRY_URL}/"],
            capture_output=True,
            timeout=10,
        )
        return result.returncode == 0
    except Exception:
        return False


def _port_in_use(port: int) -> bool:
    """Return True if something is already bound to the port (even if not yet serving HTTP)."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        return s.connect_ex(("127.0.0.1", port)) == 0


@pytest.fixture(scope="session")
def registry():
    """Boot the offline Verdaccio registry for the session.

    test-setup.sh pre-starts Verdaccio (with allowRoot: true) before pytest
    runs so the Node.js JIT warm-up happens outside pytest's per-test timeout.
    This fixture detects an already-running registry (HTTP or port-bound) and
    reuses it; it only launches its own instance as a fallback for standalone
    runs.
    """
    if _registry_up():
        # Already HTTP-responsive (test-setup.sh started it and it is warm).
        yield REGISTRY_URL
        return

    # Port bound but not yet HTTP-responsive — test-setup.sh started verdaccio
    # and it is still initialising.  Wait up to 120 s for it to become ready
    # (matches test-setup.sh's own readiness wait; Node JIT warmup on Modal's
    # infrastructure can exceed 30 s after the port first binds).
    if _port_in_use(VERDACCIO_PORT):
        deadline = time.time() + 120
        while time.time() < deadline:
            if _registry_up():
                break
            time.sleep(0.5)
        else:
            raise RuntimeError(
                f"Verdaccio port {VERDACCIO_PORT} is bound but registry "
                f"did not become HTTP-responsive within 120 s"
            )
        yield REGISTRY_URL
        return

    # Fallback: launch our own instance (standalone / local dev runs).
    verdaccio = shutil.which("verdaccio")
    assert verdaccio, "verdaccio not found on PATH (image build problem)"
    assert REGISTRY_CONFIG.exists(), f"registry config missing: {REGISTRY_CONFIG}"

    log_path = Path("/tmp/verdaccio-startup.log")
    log_fh = log_path.open("w")
    proc = subprocess.Popen(
        [verdaccio, "--config", str(REGISTRY_CONFIG), "--listen", str(VERDACCIO_PORT)],
        stdout=log_fh,
        stderr=log_fh,
    )
    try:
        deadline = time.time() + 120
        while time.time() < deadline:
            rc = proc.poll()
            if rc is not None:
                log_fh.flush()
                raise RuntimeError(
                    f"Verdaccio exited early (returncode={rc}). "
                    f"Log: {log_path.read_text()[-2000:]}"
                )
            if _registry_up():
                break
            time.sleep(0.5)
        else:
            log_fh.flush()
            raise RuntimeError(
                f"Verdaccio did not come up on {REGISTRY_URL} within 120 s. "
                f"Log: {log_path.read_text()[-2000:]}"
            )
        yield REGISTRY_URL
    finally:
        log_fh.close()
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()


# ---------------------------------------------------------------------------
# Project scaffolding + install driver.
# ---------------------------------------------------------------------------
def _make_project(
    tmp_path: Path, npmrc_extra: str = "", package_json: str = FIXTURE_PACKAGE_JSON
) -> Path:
    """Write a fixture project (the bin-shim fixture by default) into an
    isolated project dir."""
    proj = tmp_path / "proj"
    proj.mkdir()
    (proj / "package.json").write_text(package_json)
    npmrc = f"registry={REGISTRY_URL}\n"
    if npmrc_extra:
        npmrc += npmrc_extra if npmrc_extra.endswith("\n") else npmrc_extra + "\n"
    (proj / ".npmrc").write_text(npmrc)
    return proj


def _isolated_env(home: Path) -> dict:
    """Env that isolates HOME/XDG/TMPDIR and quiets the CLI, mirroring the
    repo's bats `_common_setup`. Keeps PATH (so the freshly built `aube`
    resolves) but points every store/cache/config at the throwaway HOME."""
    env = dict(os.environ)
    home.mkdir(parents=True, exist_ok=True)
    cache = home / ".cache"
    config = home / ".config"
    data = home / ".local" / "share"
    state = home / ".local" / "state"
    tmp = home / "tmp"
    for d in (cache, config, data, state, tmp):
        d.mkdir(parents=True, exist_ok=True)
    env.update(
        {
            "HOME": str(home),
            "XDG_CACHE_HOME": str(cache),
            "XDG_CONFIG_HOME": str(config),
            "XDG_DATA_HOME": str(data),
            "XDG_STATE_HOME": str(state),
            "TMPDIR": str(tmp),
            "AUBE_NO_UPDATE_CHECK": "1",
            "NO_COLOR": "1",
            "AUBE_TEST_REGISTRY": REGISTRY_URL,
        }
    )
    # "Local dev" install semantics: no frozen-lockfile, no stray log knobs.
    for k in ("CI", "AUBE_LOG", "AUBE_DEBUG", "AUBE_TRACE"):
        env.pop(k, None)
    return env


def _aube_install(proj: Path, home: Path, *extra_args: str) -> None:
    """Run `aube install` inside the project; fail loudly on error."""
    aube = shutil.which("aube")
    assert aube, "aube not found on PATH (test-setup.sh should have built it)"
    proc = subprocess.run(
        [aube, "install", *extra_args],
        cwd=str(proj),
        env=_isolated_env(home),
        capture_output=True,
        text=True,
        timeout=180,
    )
    assert proc.returncode == 0, (
        f"`aube install {' '.join(extra_args)}` failed (exit {proc.returncode})\n"
        f"stdout:\n{proc.stdout}\nstderr:\n{proc.stderr}"
    )


def _bin_entry(proj: Path) -> Path:
    return proj / "node_modules" / ".bin" / BIN_NAME


def _node_path_lines(entry: Path) -> list[str]:
    """Return every line of the entry that sets NODE_PATH (shim bodies are
    text; a symlink read would raise, which the callers guard against)."""
    text = entry.read_text()
    return [ln for ln in text.splitlines() if "NODE_PATH" in ln]


def _node_path_value(lines: list[str]) -> str | None:
    """Extract the value assigned to NODE_PATH from the shim's export line.

    The POSIX shim writes `export NODE_PATH="<value>"`. Pull the quoted
    value out so the caller can inspect its colon-separated members without
    depending on the exact ordering or surrounding quoting style."""
    for ln in lines:
        if "NODE_PATH=" not in ln:
            continue
        _, _, rhs = ln.partition("NODE_PATH=")
        rhs = rhs.strip()
        if len(rhs) >= 2 and rhs[0] in "\"'" and rhs[-1] == rhs[0]:
            return rhs[1:-1]
        return rhs
    return None


# ---------------------------------------------------------------------------
# Criterion 1 (fail_to_pass): default isolated entry is an executable
# shell shim, not a symlink.
# ---------------------------------------------------------------------------
def test_shim_is_executable_shim_not_symlink(registry, tmp_path):
    proj = _make_project(tmp_path)
    _aube_install(proj, tmp_path / "home")

    entry = _bin_entry(proj)
    assert entry.exists(), f"{entry} was not created"
    # Not a symlink — only a real wrapper file can carry runtime config.
    assert not entry.is_symlink(), (
        "default isolated .bin entry is a symlink; it must be a shell shim "
        "so it can export module-resolution config"
    )
    first_line = entry.read_text().splitlines()[0]
    assert first_line.startswith("#!/bin/sh"), (
        f"shim must start with a POSIX sh shebang, got: {first_line!r}"
    )
    assert os.access(entry, os.X_OK), "shim must be executable"


# ---------------------------------------------------------------------------
# Criterion 2 (fail_to_pass): under the default isolated layout the entry
# exports a module-resolution path that includes the bin's own top-level
# `node_modules` (`$basedir/..`, the value the extendNodePath docs give).
# Extra members and their order are left open; what the CLI can load at
# runtime is checked by test_cli_loads_indirect_packages_from_project.
# ---------------------------------------------------------------------------
def test_shim_exports_top_level_node_path(registry, tmp_path):
    proj = _make_project(tmp_path)
    _aube_install(proj, tmp_path / "home")

    entry = _bin_entry(proj)
    assert entry.exists() and not entry.is_symlink(), (
        "expected an executable shim to inspect NODE_PATH on"
    )
    lines = _node_path_lines(entry)
    assert lines, "shim exports no NODE_PATH at all (default must set it)"
    # Split the exported value into its colon-separated members instead of
    # byte-matching one string, so order and extra members don't matter.
    value = _node_path_value(lines)
    assert value is not None, (
        "could not read a NODE_PATH assignment value from the shim; "
        f"found NODE_PATH line(s):\n" + "\n".join(lines)
    )
    members = [m for m in value.split(":") if m]
    top_entry = '$basedir/..'
    assert top_entry in members, (
        "shim NODE_PATH must cover the top-level modules dir "
        f"({top_entry!r}); parsed members: {members}"
    )


# ---------------------------------------------------------------------------
# Criterion 3 (pass_to_pass): under the hoisted layout the entry stays a
# plain symlink — the contextual default flips only for isolated.
# ---------------------------------------------------------------------------
def test_hoisted_linker_keeps_symlink(registry, tmp_path):
    proj = _make_project(tmp_path)
    _aube_install(proj, tmp_path / "home", "--node-linker=hoisted")

    entry = _bin_entry(proj)
    assert entry.exists(), f"{entry} was not created under the hoisted linker"
    assert entry.is_symlink(), (
        "under the hoisted layout the .bin entry must remain a plain "
        "symlink"
    )


# ---------------------------------------------------------------------------
# Criterion 4 (pass_to_pass): an explicit preferSymlinkedExecutables=true
# still yields a symlink even under the default isolated layout.
# ---------------------------------------------------------------------------
def test_explicit_symlink_override_respected(registry, tmp_path):
    proj = _make_project(tmp_path, npmrc_extra="preferSymlinkedExecutables=true")
    _aube_install(proj, tmp_path / "home")

    entry = _bin_entry(proj)
    assert entry.exists(), f"{entry} was not created"
    assert entry.is_symlink(), (
        "an explicit preferSymlinkedExecutables=true must produce a symlink "
        "even under the isolated layout (explicit setting overrides the "
        "contextual default)"
    )


# ---------------------------------------------------------------------------
# Criterion 5 (pass_to_pass): with extendNodePath=false the installed entry
# exports no resolution path. Either kind of entry is fine here: a symlink
# exports nothing by construction, and a shell shim must not set NODE_PATH.
# ---------------------------------------------------------------------------
def test_extend_node_path_false_suppresses(registry, tmp_path):
    proj = _make_project(tmp_path, npmrc_extra="extendNodePath=false")
    _aube_install(proj, tmp_path / "home")

    entry = _bin_entry(proj)
    assert entry.exists(), f"{entry} was not created"
    if entry.is_symlink():
        # A symlink cannot export environment variables, so the
        # "no resolution path" invariant holds trivially.
        return
    lines = _node_path_lines(entry)
    assert lines == [], (
        "extendNodePath=false must suppress the resolution-path export "
        "entirely, but the entry still sets it:\n" + "\n".join(lines)
    )


# ---------------------------------------------------------------------------
# Criterion 6 (fail_to_pass): a dependency's CLI, run straight from
# `node_modules/.bin/` in the project with default settings, can load
# packages that are in the install but not declared by the project: one its
# own package depends on (js-tokens) and one another dependency brought in
# (@pnpm.e2e/dep-of-pkg-with-1-dep). The program looks them up from the
# project, the way `astro check` looks for typescript.
# ---------------------------------------------------------------------------
def test_cli_loads_indirect_packages_from_project(registry, tmp_path):
    proj = _make_project(tmp_path, package_json=INDIRECT_FIXTURE_PACKAGE_JSON)
    home = tmp_path / "home"
    _aube_install(proj, home)

    entry = _bin_entry(proj)
    assert entry.exists(), f"{entry} was not created"
    for name in INDIRECT_PACKAGES:
        assert not (proj / "node_modules" / name).exists(), (
            f"{name} is linked at the project's top level, so this project "
            "no longer has an indirect-only package to load"
        )

    # Swap the installed program's body for the project-lookup program.
    # Replace the file rather than writing through it so the package store
    # behind it is left alone.
    program = Path(os.path.realpath(proj / "node_modules" / BIN_NAME / "cli.js"))
    assert program.is_file(), f"installed {BIN_NAME} program missing: {program}"
    program.unlink()
    program.write_text(PROJECT_LOOKUP_CLI)
    program.chmod(0o755)

    env = _isolated_env(home)
    env.pop("NODE_PATH", None)
    proc = subprocess.run(
        [str(entry), *INDIRECT_PACKAGES],
        cwd=str(proj),
        env=env,
        capture_output=True,
        text=True,
        timeout=60,
    )
    assert proc.returncode == 0, (
        f"{entry.name} could not load an installed package "
        f"(exit {proc.returncode})\nstdout:\n{proc.stdout}\nstderr:\n{proc.stderr}"
    )
    for name, expected in INDIRECT_PACKAGES.items():
        assert f"loaded {expected}" in proc.stdout, (
            f"{entry.name} did not load {name}\nstdout:\n{proc.stdout}"
        )
