"""Runs a dependency's command-line program from the project's
`node_modules/.bin/` after `aube install` and checks what it can load.

Every check drives the `aube install` CLI against the repo's committed
offline registry, then runs the installed `loose-envify` entry from the
project directory with its program body swapped for a small one that looks
packages up from the project, the way `astro check` looks for typescript.

Packages come from the committed Verdaccio storage with no uplinks, so the
whole run is offline. The environment mirrors the repo's own bats harness
(`test/test_helper/common_setup.bash`): a throwaway HOME / XDG / TMPDIR per
project, `CI` unset, the update notifier off, colour off, and an `.npmrc`
pointing at the local registry.
"""

from __future__ import annotations

import json
import os
import shutil
import socket
import subprocess
import time
from pathlib import Path

import pytest


# ---------------------------------------------------------------------------
# Locations. REPO_DIR is exported by tests/test-setup.sh (defaults to the
# in-image clone) and is where the freshly built `aube` binary lives on
# PATH. The committed offline registry ships inside that same clone.
# ---------------------------------------------------------------------------
REPO_DIR = Path(os.environ.get("REPO_DIR", "/repo/aube"))
REGISTRY_CONFIG = REPO_DIR / "test" / "registry" / "config.yaml"
VERDACCIO_PORT = int(os.environ.get("VERDACCIO_PORT", "4873"))
REGISTRY_URL = f"http://localhost:{VERDACCIO_PORT}"

BIN_NAME = "loose-envify"

# The project declares three packages:
# - loose-envify@1.4.0 ships the `loose-envify` CLI and depends on js-tokens;
# - @pnpm.e2e/pkg-with-1-dep depends on @pnpm.e2e/dep-of-pkg-with-1-dep;
# - @pnpm.e2e/abc-parent-with-missing-peers depends on @pnpm.e2e/abc, whose
#   peers (@pnpm.e2e/peer-a, -b, -c) nothing provides, so aube installs
#   them itself.
# js-tokens, @pnpm.e2e/dep-of-pkg-with-1-dep and @pnpm.e2e/peer-a are in the
# install but are not in the project's package.json.
FIXTURE_PACKAGE_JSON = (
    '{\n'
    '  "name": "aube-test-bin-undeclared-deps",\n'
    '  "version": "1.0.0",\n'
    '  "dependencies": {\n'
    '    "loose-envify": "1.4.0",\n'
    '    "@pnpm.e2e/pkg-with-1-dep": "100.0.0",\n'
    '    "@pnpm.e2e/abc-parent-with-missing-peers": "1.0.0"\n'
    '  }\n'
    '}\n'
)
AUTO_INSTALLED_PEER = "@pnpm.e2e/peer-a"
CLI_OWN_DEPENDENCY = "js-tokens"
OTHER_DEPENDENCYS_DEPENDENCY = "@pnpm.e2e/dep-of-pkg-with-1-dep"
UNDECLARED_PACKAGES = (
    AUTO_INSTALLED_PEER,
    CLI_OWN_DEPENDENCY,
    OTHER_DEPENDENCYS_DEPENDENCY,
)

# Program body used in place of loose-envify's own cli.js. It reports the
# NODE_PATH it was started with, then looks each package named on its
# command line up from the directory it is run in and loads that package's
# manifest.
PROJECT_LOOKUP_CLI = """#!/usr/bin/env node
'use strict'
const project = process.cwd()
console.log('NODE_PATH=' + (process.env.NODE_PATH || ''))
for (const name of process.argv.slice(2)) {
  const manifest = require.resolve(name + '/package.json', { paths: [project] })
  const pkg = require(manifest)
  console.log('loaded ' + pkg.name + '@' + pkg.version)
}
"""


# ---------------------------------------------------------------------------
# Registry lifecycle: start the committed Verdaccio once for the whole
# test session, tear it down at the end. Serves only from the committed
# storage dir (no uplinks), so this needs no network.
# ---------------------------------------------------------------------------
def _registry_up() -> bool:
    # Probe with curl (same mechanism test-setup.sh uses for its readiness
    # wait) rather than urllib. On a cold Modal VM Verdaccio's first HTTP
    # response can take several seconds; a short per-probe urllib timeout
    # rejects a registry that is in fact up, so every probe fails and the
    # fixture deadlines out even though the server is in fact ready.
    #
    # NOTE: use -s (silent) WITHOUT -f. test-setup.sh uses `curl -s` and
    # considers any HTTP response a success, and this matches it. The Verdaccio
    # wrapper config sets `web: enable: false`, so the root URL returns a
    # non-2xx status code; -f would make curl exit non-zero on those codes
    # and _registry_up() would always return False even when Verdaccio is up.
    curl = shutil.which("curl")
    if curl is None:
        return False
    try:
        result = subprocess.run(
            [curl, "-s", "--max-time", "5", f"{REGISTRY_URL}/"],
            capture_output=True,
            timeout=10,
        )
        return result.returncode == 0
    except Exception:
        return False


def _port_in_use(port: int) -> bool:
    """Return True if something is already bound to the port (even if not yet serving HTTP)."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        return s.connect_ex(("127.0.0.1", port)) == 0


@pytest.fixture(scope="session")
def registry():
    """Boot the offline Verdaccio registry for the session.

    test-setup.sh pre-starts Verdaccio (with allowRoot: true) before pytest
    runs so the Node.js JIT warm-up happens outside pytest's per-test timeout.
    This fixture detects an already-running registry (HTTP or port-bound) and
    reuses it; it only launches its own instance as a fallback for standalone
    runs.
    """
    if _registry_up():
        # Already HTTP-responsive (test-setup.sh started it and it is warm).
        yield REGISTRY_URL
        return

    # Port bound but not yet HTTP-responsive: test-setup.sh started verdaccio
    # and it is still initialising.  Wait up to 120 s for it to become ready
    # (matches test-setup.sh's own readiness wait; Node JIT warmup on Modal's
    # infrastructure can exceed 30 s after the port first binds).
    if _port_in_use(VERDACCIO_PORT):
        deadline = time.time() + 120
        while time.time() < deadline:
            if _registry_up():
                break
            time.sleep(0.5)
        else:
            raise RuntimeError(
                f"Verdaccio port {VERDACCIO_PORT} is bound but registry "
                f"did not become HTTP-responsive within 120 s"
            )
        yield REGISTRY_URL
        return

    # Fallback: launch our own instance (standalone / local dev runs).
    verdaccio = shutil.which("verdaccio")
    assert verdaccio, "verdaccio not found on PATH (image build problem)"
    assert REGISTRY_CONFIG.exists(), f"registry config missing: {REGISTRY_CONFIG}"

    log_path = Path("/tmp/verdaccio-startup.log")
    log_fh = log_path.open("w")
    proc = subprocess.Popen(
        [verdaccio, "--config", str(REGISTRY_CONFIG), "--listen", str(VERDACCIO_PORT)],
        stdout=log_fh,
        stderr=log_fh,
    )
    try:
        deadline = time.time() + 120
        while time.time() < deadline:
            rc = proc.poll()
            if rc is not None:
                log_fh.flush()
                raise RuntimeError(
                    f"Verdaccio exited early (returncode={rc}). "
                    f"Log: {log_path.read_text()[-2000:]}"
                )
            if _registry_up():
                break
            time.sleep(0.5)
        else:
            log_fh.flush()
            raise RuntimeError(
                f"Verdaccio did not come up on {REGISTRY_URL} within 120 s. "
                f"Log: {log_path.read_text()[-2000:]}"
            )
        yield REGISTRY_URL
    finally:
        log_fh.close()
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()


# ---------------------------------------------------------------------------
# Project scaffolding, install driver and CLI runner.
# ---------------------------------------------------------------------------
def _make_project(root: Path, npmrc_extra: str = "") -> Path:
    """Write the fixture project into an isolated project dir."""
    proj = root / "proj"
    proj.mkdir()
    (proj / "package.json").write_text(FIXTURE_PACKAGE_JSON)
    npmrc = f"registry={REGISTRY_URL}\n"
    if npmrc_extra:
        npmrc += npmrc_extra if npmrc_extra.endswith("\n") else npmrc_extra + "\n"
    (proj / ".npmrc").write_text(npmrc)
    return proj


def _isolated_env(home: Path) -> dict:
    """Env that isolates HOME/XDG/TMPDIR and quiets the CLI, mirroring the
    repo's bats `_common_setup`. Keeps PATH (so the freshly built `aube`
    and `node` resolve) but points every store/cache/config at the
    throwaway HOME. NODE_PATH is dropped so only what the installed entry
    sets reaches the program."""
    env = dict(os.environ)
    home.mkdir(parents=True, exist_ok=True)
    cache = home / ".cache"
    config = home / ".config"
    data = home / ".local" / "share"
    state = home / ".local" / "state"
    tmp = home / "tmp"
    for d in (cache, config, data, state, tmp):
        d.mkdir(parents=True, exist_ok=True)
    env.update(
        {
            "HOME": str(home),
            "XDG_CACHE_HOME": str(cache),
            "XDG_CONFIG_HOME": str(config),
            "XDG_DATA_HOME": str(data),
            "XDG_STATE_HOME": str(state),
            "TMPDIR": str(tmp),
            "AUBE_NO_UPDATE_CHECK": "1",
            "NO_COLOR": "1",
            "AUBE_TEST_REGISTRY": REGISTRY_URL,
        }
    )
    # "Local dev" install semantics: no frozen-lockfile, no stray log knobs.
    for k in ("CI", "AUBE_LOG", "AUBE_DEBUG", "AUBE_TRACE", "NODE_PATH"):
        env.pop(k, None)
    return env


def _aube_install(proj: Path, home: Path, *extra_args: str) -> None:
    """Run `aube install` inside the project; fail loudly on error."""
    aube = shutil.which("aube")
    assert aube, "aube not found on PATH (test-setup.sh should have built it)"
    proc = subprocess.run(
        [aube, "install", *extra_args],
        cwd=str(proj),
        env=_isolated_env(home),
        capture_output=True,
        text=True,
        timeout=180,
    )
    assert proc.returncode == 0, (
        f"`aube install {' '.join(extra_args)}` failed (exit {proc.returncode})\n"
        f"stdout:\n{proc.stdout}\nstderr:\n{proc.stderr}"
    )


def _bin_entry(proj: Path) -> Path:
    return proj / "node_modules" / ".bin" / BIN_NAME


def _swap_in_lookup_program(proj: Path) -> None:
    """Replace the installed loose-envify program with PROJECT_LOOKUP_CLI.
    The file is unlinked first so the package store behind it is left
    alone."""
    program = Path(os.path.realpath(proj / "node_modules" / BIN_NAME / "cli.js"))
    assert program.is_file(), f"installed {BIN_NAME} program missing: {program}"
    program.unlink()
    program.write_text(PROJECT_LOOKUP_CLI)
    program.chmod(0o755)


def _install_and_swap(root: Path, *extra_args: str, npmrc_extra: str = ""):
    proj = _make_project(root, npmrc_extra=npmrc_extra)
    home = root / "home"
    _aube_install(proj, home, *extra_args)
    assert _bin_entry(proj).exists(), f"{_bin_entry(proj)} was not created"
    _swap_in_lookup_program(proj)
    return proj, home


def _run_cli(proj: Path, home: Path, *names: str) -> subprocess.CompletedProcess:
    entry = _bin_entry(proj)
    return subprocess.run(
        [str(entry), *names],
        cwd=str(proj),
        env=_isolated_env(home),
        capture_output=True,
        text=True,
        timeout=60,
    )


def _assert_cli_loads(proj: Path, home: Path, name: str) -> None:
    proc = _run_cli(proj, home, name)
    assert proc.returncode == 0 and f"loaded {name}@" in proc.stdout, (
        f"node_modules/.bin/{BIN_NAME}, run from the project, could not load "
        f"{name}, which is in the install (exit {proc.returncode})\n"
        f"stdout:\n{proc.stdout}\nstderr:\n{proc.stderr}"
    )


@pytest.fixture(scope="module")
def default_install(registry, tmp_path_factory):
    """One install of the fixture project with default settings."""
    return _install_and_swap(tmp_path_factory.mktemp("default"))


# ---------------------------------------------------------------------------
# Default install: a dependency's CLI, run from node_modules/.bin/ in the
# project, loads packages that are in the install but not declared by the
# project, looked up from the project.
# ---------------------------------------------------------------------------
def test_cli_loads_auto_installed_peer(default_install):
    proj, home = default_install
    _assert_cli_loads(proj, home, AUTO_INSTALLED_PEER)


def test_cli_loads_its_own_dependency(default_install):
    proj, home = default_install
    _assert_cli_loads(proj, home, CLI_OWN_DEPENDENCY)


def test_cli_loads_another_dependencys_dependency(default_install):
    proj, home = default_install
    _assert_cli_loads(proj, home, OTHER_DEPENDENCYS_DEPENDENCY)


# ---------------------------------------------------------------------------
# Default install: the project's own code, run with plain `node` from the
# project directory, still cannot load packages it does not declare (aube's
# strict isolated layout, see docs/guide.md and test/hoist.bats).
# ---------------------------------------------------------------------------
def test_project_code_cannot_load_undeclared_packages(default_install):
    proj, home = default_install
    script = (
        "const out = {};"
        "for (const name of JSON.parse(process.argv[1])) {"
        "  try { require.resolve(name + '/package.json', { paths: [process.cwd()] });"
        "        out[name] = 'found' } catch (e) { out[name] = 'missing' }"
        "}"
        "console.log(JSON.stringify(out))"
    )
    node = shutil.which("node")
    assert node, "node not found on PATH"
    proc = subprocess.run(
        [node, "-e", script, json.dumps(list(UNDECLARED_PACKAGES))],
        cwd=str(proj),
        env=_isolated_env(home),
        capture_output=True,
        text=True,
        timeout=60,
    )
    assert proc.returncode == 0, f"node failed:\n{proc.stderr}"
    found = [n for n, v in json.loads(proc.stdout).items() if v != "missing"]
    assert not found, (
        "plain `node` in the project resolves packages the project does not "
        f"declare: {found}"
    )


# ---------------------------------------------------------------------------
# Hoisted install: the same CLI run loads the same packages.
# ---------------------------------------------------------------------------
def test_hoisted_install_cli_loads_undeclared_packages(registry, tmp_path):
    proj, home = _install_and_swap(tmp_path, "--node-linker=hoisted")
    for name in UNDECLARED_PACKAGES:
        _assert_cli_loads(proj, home, name)


# ---------------------------------------------------------------------------
# preferSymlinkedExecutables=true set in .npmrc: the .bin entry is a symlink.
# ---------------------------------------------------------------------------
def test_explicit_prefer_symlinked_executables_gives_symlink(registry, tmp_path):
    proj = _make_project(tmp_path, npmrc_extra="preferSymlinkedExecutables=true")
    _aube_install(proj, tmp_path / "home")

    entry = _bin_entry(proj)
    assert entry.exists(), f"{entry} was not created"
    assert entry.is_symlink(), (
        "with preferSymlinkedExecutables=true in .npmrc the .bin entry is "
        "not a symlink"
    )


# ---------------------------------------------------------------------------
# extendNodePath=false set in .npmrc: the CLI starts with no NODE_PATH.
# ---------------------------------------------------------------------------
def test_extend_node_path_false_sets_no_node_path(registry, tmp_path):
    proj, home = _install_and_swap(tmp_path, npmrc_extra="extendNodePath=false")
    proc = _run_cli(proj, home)
    assert proc.returncode == 0, (
        f"{BIN_NAME} did not run (exit {proc.returncode})\n"
        f"stdout:\n{proc.stdout}\nstderr:\n{proc.stderr}"
    )
    first = proc.stdout.splitlines()[0] if proc.stdout else ""
    assert first == "NODE_PATH=", (
        "with extendNodePath=false in .npmrc the CLI still starts with "
        f"{first!r}"
    )
