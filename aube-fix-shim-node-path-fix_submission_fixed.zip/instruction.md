## Task

Some CLIs that come with a project's dependencies fail when they're run from `node_modules/.bin` after `aube install`. The same project installed with pnpm works.

The report we have is an Astro project with `@astrojs/check`. On Linux, with default aube settings, `./node_modules/.bin/astro check` stops with:

```
To continue, Astro requires the following dependency to be installed: typescript.
```

typescript is in the install. aube auto-installed it as a peer, it just isn't in the project's package.json.

Make these CLIs work after an aube install the way they do under pnpm.
