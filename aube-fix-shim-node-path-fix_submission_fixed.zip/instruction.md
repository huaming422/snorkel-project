## Task

`./node_modules/.bin/astro check` fails in an Astro project that uses `@astrojs/check` once its dependencies are installed with `aube install` (Linux, default aube settings):

```
To continue, Astro requires the following dependency to be installed: typescript.
```

typescript was installed. Nothing in the project's package.json asks for it, aube added it because it's a missing peer. Install the same project with pnpm and the command runs fine.

CLIs from a project's dependencies, started from `node_modules/.bin`, should work after an aube install like they do after a pnpm install.
