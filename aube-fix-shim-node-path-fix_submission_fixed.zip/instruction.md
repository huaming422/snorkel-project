## Task

After `aube install` on Linux with default settings, `./node_modules/.bin/astro check` in a project that uses `@astrojs/check` exits with:

```
To continue, Astro requires the following dependency to be installed: typescript.
```

typescript is in the install. The project's package.json doesn't list it. aube put it there as a missing peer. Install the same project with pnpm and the command works.

A dependency's CLI started from `node_modules/.bin` should work after an aube install the same way it does after a pnpm install.
