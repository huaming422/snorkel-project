## Task

Several packages in an aube workspace depend on the same library but pin
different versions. Running `aube install --node-linker=hoisted` leaves an
unexpectedly large install and plugins in the applications stop working
correctly. The apps should work with those declared versions without unnecessary
disk usage.
