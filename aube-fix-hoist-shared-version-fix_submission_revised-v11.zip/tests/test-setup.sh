#!/usr/bin/env bash
# Pre-build the aube-linker crate's test target so the verifier's `cargo test
# --test <name>` skips the cold compile. The verifier integration test is hosted
# in crates/aube-linker and drives the public HoistedPlacements::from_graph API.
set -euo pipefail

cd /repo/aube

# Grade time is offline; the image baked the full dependency closure at the base
# commit (Dockerfile block 7). Build offline-first and fall back to an online
# fetch only if something is unexpectedly missing (logged, not silenced).
export CARGO_INCREMENTAL=1

if ! CARGO_NET_OFFLINE=true cargo build -p aube-linker --tests --locked --offline; then
    echo "offline pre-warm failed; retrying with network" >&2
    cargo fetch --locked
    cargo build -p aube-linker --tests --locked
fi

ls -la "${CARGO_TARGET_DIR:-/opt/cache/cargo-target}/debug/deps" | head -n 20 || true
