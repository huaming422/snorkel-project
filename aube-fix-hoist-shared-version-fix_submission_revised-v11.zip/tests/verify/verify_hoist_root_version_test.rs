//! Behavioural checks for hoisted-layout shared-version placement.
//!
//! These drive the PRE-EXISTING, stable public entry point
//! `aube_linker::HoistedPlacements::from_graph(root, graph,
//! modules_dir_name, HoistingLimits)` and assert only on the observable
//! placement map it returns (`package_dir` / `all_package_dirs`). Nothing
//! here names an internal planner function, data structure, or counter, so
//! any layout planner that produces the correct placements passes
//! regardless of how it is built.
//!
//! `from_graph` records a placement only for a candidate directory that
//! already exists on disk (it is designed to reconstruct the layout of an
//! already-linked tree without touching disk). So every test first
//! pre-creates each candidate `node_modules/<name>` directory in a
//! tempdir, exactly as the crate's existing `from_graph_*` tests do, then
//! inspects which version landed at the shared workspace-root slot versus
//! which nested under an importer.
//!
//! The `dep` / `pkg` constructors below rebuild the same in-memory graph
//! shapes the crate's in-source tests use, from the public
//! `DirectDep` / `LockedPackage` fields (the in-source helpers are private
//! to that module and not reachable from an integration test).

use aube_linker::{HoistedPlacements, HoistingLimits};
use aube_lockfile::{DepType, DirectDep, LocalSource, LockedPackage, LockfileGraph};
use std::fs;
use std::path::{Path, PathBuf};

fn dep(name: &str, dep_path: &str) -> DirectDep {
    DirectDep {
        name: name.into(),
        dep_path: dep_path.into(),
        dep_type: DepType::Production,
        specifier: None,
    }
}

fn pkg(name: &str, version: &str, deps: &[(&str, &str)]) -> LockedPackage {
    LockedPackage {
        name: name.into(),
        version: version.into(),
        dep_path: format!("{name}@{version}"),
        dependencies: deps
            .iter()
            .map(|(dep_name, tail)| ((*dep_name).into(), (*tail).into()))
            .collect(),
        ..Default::default()
    }
}

/// Pre-create each candidate `node_modules/<name>` directory relative to
/// the workspace root so `from_graph` will record its placement.
fn precreate(root: &Path, rel_dirs: &[&str]) {
    for rel in rel_dirs {
        fs::create_dir_all(root.join(rel)).unwrap();
    }
}

/// The single shared workspace-root `node_modules/<name>` directory.
fn root_slot(root: &Path, name: &str) -> PathBuf {
    root.join("node_modules").join(name)
}

/// When two workspace packages disagree on the version of a shared
/// package, the version used by more of the workspace (counting distinct
/// dependents and peer-dependents) occupies the single top-level slot, and
/// the less-used version nests inside the importer that wants it.
///
/// One version has a direct consumer and a resolved peer consumer; the other
/// has just one direct consumer. Run both numeric-version orderings.
#[test]
fn more_used_version_wins_shared_root_slot() {
    // Peer demand, not the numerically or lexically larger version, decides.
    for (minority, majority) in [("19.2.3", "19.2.6"), ("19.2.6", "19.2.3")] {
        let minority_path = format!("react@{minority}");
        let majority_path = format!("react@{majority}");
        let root = tempfile::tempdir().unwrap();
        let rp = root.path();

        let zustand_dep_path = format!("zustand@5.0.11(react@{majority})");
        let mut graph = LockfileGraph::default();
        graph
            .importers
            .insert("packages/mobile".into(), vec![dep("react", &minority_path)]);
        graph.importers.insert(
            "packages/web".into(),
            vec![
                dep("react", &majority_path),
                dep("zustand", &zustand_dep_path),
            ],
        );
        graph
            .packages
            .insert(minority_path.clone(), pkg("react", minority, &[]));
        graph
            .packages
            .insert(majority_path.clone(), pkg("react", majority, &[]));
        let mut zustand = pkg("zustand", "5.0.11", &[("react", majority)]);
        zustand.dep_path = zustand_dep_path.clone();
        zustand
            .peer_dependencies
            .insert("react".into(), ">=18.0.0".into());
        graph.packages.insert(zustand_dep_path.clone(), zustand);

        precreate(
            rp,
            &[
                "node_modules/react",
                "node_modules/zustand",
                "packages/mobile/node_modules/react",
                "packages/web/node_modules/react",
            ],
        );

        let placements =
            HoistedPlacements::from_graph(rp, &graph, "node_modules", HoistingLimits::None)
                .unwrap();

        assert_eq!(
            placements.package_dir(&majority_path),
            Some(root_slot(rp, "react").as_path()),
            "the version used by more of the workspace must hold the shared root slot"
        );
        assert_eq!(
            placements.package_dir(&minority_path),
            Some(rp.join("packages/mobile/node_modules/react").as_path()),
            "the less-used version must nest inside the importer that wants it"
        );
        assert_eq!(
            placements.package_dir(&zustand_dep_path),
            Some(root_slot(rp, "zustand").as_path())
        );
    }
}

/// The preferred version is selected even when it is only reachable
/// through a dependency discovered later in the walk. A direct dependency
/// on the less-used version must not permanently claim the shared slot
/// before the more-used (transitive) version is found; the planner must
/// still terminate for every input.
///
/// `shared@2.0.0` is needed transitively by two consumers (two distinct
/// users); `shared@1.0.0` is a direct dependency of one importer. The
/// shared slot must hold `shared@2.0.0`, and `shared@1.0.0` must nest in
/// the importer that declares it.
#[test]
fn preferred_transitive_version_wins_over_earlier_direct_conflict() {
    // A queue that ranks only discovered requests must not pass by name order.
    for consumers in [
        ["consumer-a", "consumer-b"],
        ["z-consumer-a", "z-consumer-b"],
    ] {
        let root = tempfile::tempdir().unwrap();
        let rp = root.path();

        let mut graph = LockfileGraph::default();
        graph
            .importers
            .insert("packages/first".into(), vec![dep("shared", "shared@1.0.0")]);
        graph.importers.insert(
            "packages/second".into(),
            vec![
                dep(consumers[0], &format!("{}@1.0.0", consumers[0])),
                dep(consumers[1], &format!("{}@1.0.0", consumers[1])),
            ],
        );
        graph
            .packages
            .insert("shared@1.0.0".into(), pkg("shared", "1.0.0", &[]));
        graph
            .packages
            .insert("shared@2.0.0".into(), pkg("shared", "2.0.0", &[]));
        for consumer in consumers {
            graph.packages.insert(
                format!("{consumer}@1.0.0"),
                pkg(consumer, "1.0.0", &[("shared", "2.0.0")]),
            );
        }

        precreate(
            rp,
            &[
                "node_modules/shared",
                &format!("node_modules/{}", consumers[0]),
                &format!("node_modules/{}", consumers[1]),
                "packages/first/node_modules/shared",
                // Nesting sites the less-preferred layout would use.
                &format!("node_modules/{}/node_modules/shared", consumers[0]),
                &format!("node_modules/{}/node_modules/shared", consumers[1]),
            ],
        );

        let placements =
            HoistedPlacements::from_graph(rp, &graph, "node_modules", HoistingLimits::None)
                .unwrap();

        assert_eq!(
            placements.package_dir("shared@2.0.0"),
            Some(root_slot(rp, "shared").as_path()),
            "the more-used transitive version must claim the shared root slot"
        );
        assert_eq!(
            placements.package_dir("shared@1.0.0"),
            Some(rp.join("packages/first/node_modules/shared").as_path()),
            "the earlier direct conflict must nest once the preferred version is found"
        );
    }
}

/// A version pinned by an explicit top-level (workspace-root) dependency
/// holds the shared slot even when another version is used by more of the
/// workspace. The top-level declaration is an intentional, stronger signal
/// than raw usage counts.
///
/// The root project directly depends on `react@19.2.3`; a second importer
/// plus its transitive consumer use `react@19.2.6` (more usage). The
/// shared slot must still hold the root-declared `react@19.2.3`.
#[test]
fn explicit_top_level_dependency_keeps_shared_slot() {
    let root = tempfile::tempdir().unwrap();
    let rp = root.path();

    let mut graph = LockfileGraph::default();
    graph
        .importers
        .insert(".".into(), vec![dep("react", "react@19.2.3")]);
    graph.importers.insert(
        "packages/web".into(),
        vec![
            dep("react", "react@19.2.6"),
            dep("consumer", "consumer@1.0.0"),
        ],
    );
    graph
        .packages
        .insert("react@19.2.3".into(), pkg("react", "19.2.3", &[]));
    graph
        .packages
        .insert("react@19.2.6".into(), pkg("react", "19.2.6", &[]));
    graph.packages.insert(
        "consumer@1.0.0".into(),
        pkg("consumer", "1.0.0", &[("react", "19.2.6")]),
    );

    precreate(
        rp,
        &[
            "node_modules/react",
            "node_modules/consumer",
            "packages/web/node_modules/react",
            "node_modules/consumer/node_modules/react",
        ],
    );

    let placements =
        HoistedPlacements::from_graph(rp, &graph, "node_modules", HoistingLimits::None).unwrap();

    assert_eq!(
        placements.package_dir("react@19.2.3"),
        Some(root_slot(rp, "react").as_path()),
        "an explicit top-level dependency must win the shared slot over usage counts"
    );
    let nested = placements.all_package_dirs("react@19.2.6");
    assert_eq!(
        nested.len(),
        2,
        "both conflicting consumers need their version"
    );
    assert!(nested.contains(&rp.join("packages/web/node_modules/react")));
    assert!(nested.contains(&rp.join("node_modules/consumer/node_modules/react")));
}

/// When every workspace package agrees on the same version of a shared
/// package, that one copy stays deduplicated at the shared root slot — the
/// planner must not force private nested copies when there is no conflict.
#[test]
fn agreed_shared_version_stays_deduplicated_at_root() {
    let root = tempfile::tempdir().unwrap();
    let rp = root.path();

    let mut graph = LockfileGraph::default();
    graph
        .importers
        .insert("packages/app".into(), vec![dep("shared", "shared@1.0.0")]);
    graph
        .importers
        .insert("packages/lib".into(), vec![dep("shared", "shared@1.0.0")]);
    graph
        .packages
        .insert("shared@1.0.0".into(), pkg("shared", "1.0.0", &[]));

    precreate(
        rp,
        &[
            "node_modules/shared",
            "packages/app/node_modules/shared",
            "packages/lib/node_modules/shared",
        ],
    );

    let placements =
        HoistedPlacements::from_graph(rp, &graph, "node_modules", HoistingLimits::None).unwrap();

    assert_eq!(
        placements.package_dir("shared@1.0.0"),
        Some(root_slot(rp, "shared").as_path())
    );
    assert_eq!(
        placements.all_package_dirs("shared@1.0.0").len(),
        1,
        "an agreed shared version must be a single shared copy, not duplicated"
    );
}

/// A non-root direct `link:` candidate is ineligible for the shared slot, even
/// when it is the version most of the workspace references. A `link:` entry
/// is a live symlink into another workspace directory, not a store package
/// that can own the top-level slot, so selection must skip it and give the
/// slot to an eligible registry version used by fewer packages.
///
/// Three importers reference `shared` through `link:../shared`; one
/// importer references the registry `shared@2.0.0`. The shared slot must
/// hold `shared@2.0.0` — picking the more-referenced `link:` candidate
/// would be wrong. A link declared by the root itself is already at its
/// correct location and is not the case exercised here.
#[test]
fn linked_candidate_never_wins_shared_slot() {
    let root = tempfile::tempdir().unwrap();
    let rp = root.path();

    let link_dep_path = "shared@link:../shared";
    let mut graph = LockfileGraph::default();
    graph
        .importers
        .insert("packages/a".into(), vec![dep("shared", "shared@2.0.0")]);
    for importer in ["packages/b", "packages/c", "packages/d"] {
        graph
            .importers
            .insert(importer.into(), vec![dep("shared", link_dep_path)]);
    }
    graph
        .packages
        .insert("shared@2.0.0".into(), pkg("shared", "2.0.0", &[]));
    let mut linked = pkg("shared", "0.0.0", &[]);
    linked.dep_path = link_dep_path.into();
    linked.local_source = Some(LocalSource::Link(PathBuf::from("packages/shared")));
    graph.packages.insert(link_dep_path.into(), linked);

    precreate(
        rp,
        &[
            "node_modules/shared",
            "packages/a/node_modules/shared",
            "packages/b/node_modules/shared",
            "packages/c/node_modules/shared",
            "packages/d/node_modules/shared",
        ],
    );

    let placements =
        HoistedPlacements::from_graph(rp, &graph, "node_modules", HoistingLimits::None).unwrap();

    assert_eq!(
        placements.package_dir("shared@2.0.0"),
        Some(root_slot(rp, "shared").as_path()),
        "the eligible registry version must win the shared slot over a more-referenced link: candidate"
    );
    let linked_sites = placements.all_package_dirs(link_dep_path);
    assert_eq!(
        linked_sites.len(),
        3,
        "each direct link must remain available"
    );
    for importer in ["packages/b", "packages/c", "packages/d"] {
        assert!(linked_sites.contains(&rp.join(importer).join("node_modules/shared")));
    }
}

/// The shared-slot selection applies only to the fully-hoisting layout.
/// Under a per-workspace hoisting limit, a shared package stays local to
/// each importer and is NOT promoted to the top-level slot, exactly as
/// before — the selection logic must stay scoped to the full-hoist mode.
#[test]
fn per_workspace_hoisting_limit_is_unaffected() {
    let root = tempfile::tempdir().unwrap();
    let rp = root.path();

    let mut graph = LockfileGraph::default();
    graph
        .importers
        .insert("packages/app".into(), vec![dep("shared", "shared@1.0.0")]);
    graph
        .importers
        .insert("packages/lib".into(), vec![dep("shared", "shared@1.0.0")]);
    graph
        .packages
        .insert("shared@1.0.0".into(), pkg("shared", "1.0.0", &[]));

    precreate(
        rp,
        &[
            "node_modules/shared",
            "packages/app/node_modules/shared",
            "packages/lib/node_modules/shared",
        ],
    );

    let placements =
        HoistedPlacements::from_graph(rp, &graph, "node_modules", HoistingLimits::Workspaces)
            .unwrap();

    let sites = placements.all_package_dirs("shared@1.0.0");
    assert_eq!(
        sites.len(),
        2,
        "under a per-workspace limit each importer keeps its own copy"
    );
    assert!(
        sites.contains(&rp.join("packages/app/node_modules/shared"))
            && sites.contains(&rp.join("packages/lib/node_modules/shared")),
        "the shared package must stay importer-local, not hoisted to the root slot"
    );
}

/// Reaching the same consumer through many importers must not multiply its
/// vote. Two distinct transitive consumers outweigh one widely reached one.
#[test]
fn repeated_paths_do_not_multiply_consumer_demand() {
    let root = tempfile::tempdir().unwrap();
    let rp = root.path();
    let mut graph = LockfileGraph::default();
    for importer in ["packages/a", "packages/b", "packages/c"] {
        graph
            .importers
            .insert(importer.into(), vec![dep("common", "common@1.0.0")]);
    }
    graph.importers.insert(
        "packages/d".into(),
        vec![
            dep("z-left", "z-left@1.0.0"),
            dep("z-right", "z-right@1.0.0"),
        ],
    );
    graph.packages.insert(
        "common@1.0.0".into(),
        pkg("common", "1.0.0", &[("shared", "2.0.0")]),
    );
    for name in ["z-left", "z-right"] {
        graph.packages.insert(
            format!("{name}@1.0.0"),
            pkg(name, "1.0.0", &[("shared", "1.0.0")]),
        );
    }
    for version in ["1.0.0", "2.0.0"] {
        graph
            .packages
            .insert(format!("shared@{version}"), pkg("shared", version, &[]));
    }
    precreate(
        rp,
        &[
            "node_modules/common",
            "node_modules/z-left",
            "node_modules/z-right",
            "node_modules/shared",
            "node_modules/common/node_modules/shared",
            "node_modules/z-left/node_modules/shared",
            "node_modules/z-right/node_modules/shared",
        ],
    );
    let placements =
        HoistedPlacements::from_graph(rp, &graph, "node_modules", HoistingLimits::None).unwrap();
    assert_eq!(
        placements.package_dir("shared@1.0.0"),
        Some(root_slot(rp, "shared").as_path())
    );
    assert_eq!(placements.all_package_dirs("shared@1.0.0").len(), 1);
    assert_eq!(
        placements.package_dir("shared@2.0.0"),
        Some(rp.join("node_modules/common/node_modules/shared").as_path())
    );
}

/// Both preferred versions are behind less-preferred parents. There is no
/// single required winner here, but the planner must make progress and keep
/// every requested version. The graph itself is acyclic.
#[test]
fn mutually_blocked_preferences_finish_without_dropping_packages() {
    let (send, receive) = std::sync::mpsc::channel();
    std::thread::spawn(move || {
        let root = tempfile::tempdir().unwrap();
        let rp = root.path();
        let mut graph = LockfileGraph::default();
        graph.importers.insert(
            "packages/app".into(),
            vec![dep("a", "a@1.0.0"), dep("b", "b@1.0.0")],
        );
        for (name, version, deps) in [
            ("a", "1.0.0", vec![("b", "2.0.0"), ("c", "1.0.0")]),
            ("b", "1.0.0", vec![("a", "2.0.0"), ("d", "1.0.0")]),
            ("c", "1.0.0", vec![("b", "2.0.0")]),
            ("d", "1.0.0", vec![("a", "2.0.0")]),
            ("a", "2.0.0", vec![]),
            ("b", "2.0.0", vec![]),
        ] {
            graph
                .packages
                .insert(format!("{name}@{version}"), pkg(name, version, &deps));
        }
        // Accommodate either tie/progress order, including nested placements.
        fn candidates(nm: &Path, depth: usize) {
            if depth == 0 {
                return;
            }
            for name in ["a", "b", "c", "d"] {
                let dir = nm.join(name);
                fs::create_dir_all(&dir).unwrap();
                candidates(&dir.join("node_modules"), depth - 1);
            }
        }
        candidates(&rp.join("node_modules"), 4);
        candidates(&rp.join("packages/app/node_modules"), 4);
        let placements =
            HoistedPlacements::from_graph(rp, &graph, "node_modules", HoistingLimits::None)
                .unwrap();
        for dep_path in graph.packages.keys() {
            assert!(
                !placements.all_package_dirs(dep_path).is_empty(),
                "missing {dep_path}"
            );
        }
        send.send(()).unwrap();
    });
    receive
        .recv_timeout(std::time::Duration::from_secs(30))
        .expect("planning must finish even when preferred versions block one another");
}

// These cases install real packages through the public workspace linker. Node
// compares the exported objects, so matching version strings or a plausible
// placement map cannot hide a second singleton instance.
mod peer_identity {
    use super::*;
    use aube_linker::{LinkStrategy, Linker, NodeLinker};
    use aube_store::{PackageIndex, Store};
    use std::collections::BTreeMap;
    use std::io::Write;
    use std::process::{Command, Stdio};

    fn add(graph: &mut LockfileGraph, name: &str, version: &str, deps: &[(&str, &str)]) {
        let package = pkg(name, version, deps);
        graph.packages.insert(package.dep_path.clone(), package);
    }

    fn plugin(graph: &mut LockfileGraph, name: &str, peers: &[(&str, &str)]) -> String {
        let suffix = peers
            .iter()
            .map(|(name, version)| format!("({name}@{version})"))
            .collect::<String>();
        let path = format!("{name}@1.0.0{suffix}");
        let mut package = pkg(name, "1.0.0", peers);
        package.dep_path = path.clone();
        for (peer, _) in peers {
            package.peer_dependencies.insert((*peer).into(), "*".into());
        }
        graph.packages.insert(path.clone(), package);
        path
    }

    fn install_and_check(root: &Path, graph: &LockfileGraph) -> HoistedPlacements {
        let store = Store::with_dirs(root.join("store/files"), root.join("cache"));
        let mut indices = BTreeMap::new();
        for (path, package) in &graph.packages {
            let mut source = format!(
                "exports.id = {}; exports.peers = {{}};\n",
                serde_json::to_string(path).unwrap()
            );
            for peer in package
                .peer_dependencies
                .keys()
                .filter(|name| package.dependencies.contains_key(*name))
            {
                let quoted = serde_json::to_string(peer).unwrap();
                source.push_str(&format!("exports.peers[{quoted}] = require({quoted});\n"));
            }
            let index: PackageIndex = [(
                "index.js".into(),
                store.import_bytes(source.as_bytes(), false).unwrap(),
            )]
            .into_iter()
            .collect();
            indices.insert(path.clone(), index);
        }
        let linker = Linker::new(&store, LinkStrategy::Copy).with_node_linker(NodeLinker::Hoisted);
        let stats = linker
            .link_workspace(root, graph, &indices, &BTreeMap::new())
            .unwrap();
        let placements = stats.hoisted_placements.unwrap();
        let reconstructed =
            HoistedPlacements::from_graph(root, graph, "node_modules", HoistingLimits::None)
                .unwrap();
        let actual: BTreeMap<_, _> = placements
            .iter()
            .map(|(key, path)| (path.to_path_buf(), key.to_string()))
            .collect();
        assert_eq!(
            actual.len(),
            placements.iter().count(),
            "two versions cannot occupy one directory"
        );
        let restored: BTreeMap<_, _> = reconstructed
            .iter()
            .map(|(key, path)| (path.to_path_buf(), key.to_string()))
            .collect();
        assert_eq!(
            actual, restored,
            "rebuild must find the installed peer layout"
        );

        let packages: BTreeMap<_, _> = graph
            .packages
            .iter()
            .map(|(key, package)| {
                let deps: BTreeMap<_, _> = package
                    .dependencies
                    .iter()
                    .map(|(name, tail)| (name, format!("{name}@{tail}")))
                    .collect();
                let peers: Vec<_> = package
                    .peer_dependencies
                    .keys()
                    .filter(|name| package.dependencies.contains_key(*name))
                    .collect();
                (key, serde_json::json!({"deps": deps, "peers": peers}))
            })
            .collect();
        let importers: Vec<_> = graph
            .importers
            .iter()
            .map(|(path, deps)| {
                let deps: BTreeMap<_, _> =
                    deps.iter().map(|dep| (&dep.name, &dep.dep_path)).collect();
                serde_json::json!({"dir": root.join(path), "deps": deps})
            })
            .collect();
        let payload =
            serde_json::json!({"packages": packages, "importers": importers, "placements": actual});
        let script = r#"
const assert = require('node:assert/strict');
const {createRequire} = require('node:module');
const path = require('node:path');
const input = JSON.parse(require('node:fs').readFileSync(0, 'utf8'));
function edge(request, name, expected) {
    const value = request(name);
    assert.equal(value.id, expected, `wrong version resolving ${name}`);
    for (const peer of input.packages[expected].peers) {
        assert.strictEqual(value.peers[peer], request(peer),
            `${expected} loads a different ${peer} instance than its consumer`);
    }
}
for (const importer of input.importers) {
    const request = createRequire(path.join(importer.dir, 'entry.js'));
    for (const [name, target] of Object.entries(importer.deps)) edge(request, name, target);
}
for (const [directory, target] of Object.entries(input.placements)) {
    const entry = path.join(directory, 'index.js');
    assert.equal(require(entry).id, target);
    const request = createRequire(entry);
    for (const [name, dependency] of Object.entries(input.packages[target].deps)) {
        edge(request, name, dependency);
    }
}
"#;
        let mut child = Command::new("node")
            .args(["-e", script])
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
            .expect("task image provides Node");
        child
            .stdin
            .take()
            .unwrap()
            .write_all(payload.to_string().as_bytes())
            .unwrap();
        let output = child.wait_with_output().unwrap();
        assert!(
            output.status.success(),
            "Node peer identity check failed:\n{}",
            String::from_utf8_lossy(&output.stderr)
        );
        placements
    }

    #[test]
    fn identical_peer_versions_in_separate_apps_keep_separate_plugin_instances() {
        for plugin_first in [false, true] {
            let root = tempfile::tempdir().unwrap();
            let mut graph = LockfileGraph::default();
            add(&mut graph, "react", "18.0.0", &[]);
            add(&mut graph, "react", "19.0.0", &[]);
            let plugin = plugin(&mut graph, "adapter", &[("react", "19.0.0")]);
            graph
                .importers
                .insert(".".into(), vec![dep("react", "react@18.0.0")]);
            for app in ["packages/a", "packages/b"] {
                let mut deps = vec![dep("react", "react@19.0.0"), dep("adapter", &plugin)];
                if plugin_first {
                    deps.reverse();
                }
                graph.importers.insert(app.into(), deps);
            }
            let placements = install_and_check(root.path(), &graph);
            assert_eq!(placements.all_package_dirs("react@19.0.0").len(), 2);
            assert_eq!(placements.all_package_dirs(&plugin).len(), 2);
        }
    }

    #[test]
    fn transitive_plugins_share_their_host_packages_peer_instance() {
        let root = tempfile::tempdir().unwrap();
        let mut graph = LockfileGraph::default();
        add(&mut graph, "react", "18.0.0", &[]);
        add(&mut graph, "react", "19.0.0", &[]);
        let adapter = plugin(&mut graph, "adapter", &[("react", "19.0.0")]);
        let nested = plugin(&mut graph, "extension", &[("react", "19.0.0")]);
        graph
            .packages
            .get_mut(&adapter)
            .unwrap()
            .dependencies
            .insert(
                "extension".into(),
                nested.strip_prefix("extension@").unwrap().into(),
            );
        add(
            &mut graph,
            "host",
            "1.0.0",
            &[
                ("adapter", adapter.strip_prefix("adapter@").unwrap()),
                ("react", "19.0.0"),
            ],
        );
        graph
            .importers
            .insert(".".into(), vec![dep("react", "react@18.0.0")]);
        for app in ["packages/a", "packages/b"] {
            graph
                .importers
                .insert(app.into(), vec![dep("host", "host@1.0.0")]);
        }
        let placements = install_and_check(root.path(), &graph);
        for target in ["host@1.0.0", "react@19.0.0", &adapter, &nested] {
            assert_eq!(
                placements.all_package_dirs(target).len(),
                1,
                "compatible consumers should share {target}"
            );
        }
    }

    #[test]
    fn all_resolved_peers_constrain_plugin_sharing() {
        let root = tempfile::tempdir().unwrap();
        let mut graph = LockfileGraph::default();
        for name in ["react", "@tools/runtime"] {
            for version in ["1.0.0", "2.0.0"] {
                add(&mut graph, name, version, &[]);
            }
        }
        graph.importers.insert(
            ".".into(),
            vec![
                dep("react", "react@1.0.0"),
                dep("@tools/runtime", "@tools/runtime@1.0.0"),
            ],
        );
        for (app, react, runtime) in [
            ("a", "2.0.0", "1.0.0"),
            ("b", "1.0.0", "2.0.0"),
            ("c", "1.0.0", "1.0.0"),
        ] {
            let target = plugin(
                &mut graph,
                "adapter",
                &[("react", react), ("@tools/runtime", runtime)],
            );
            graph.importers.insert(
                format!("packages/{app}"),
                vec![
                    dep("adapter", &target),
                    dep("react", &format!("react@{react}")),
                    dep("@tools/runtime", &format!("@tools/runtime@{runtime}")),
                ],
            );
        }
        let placements = install_and_check(root.path(), &graph);
        for path in graph.packages.keys() {
            assert_eq!(
                placements.all_package_dirs(path).len(),
                1,
                "no unnecessary copy of {path}"
            );
        }
    }

    #[test]
    fn compatible_peer_contexts_still_share_one_root_installation() {
        let root = tempfile::tempdir().unwrap();
        let mut graph = LockfileGraph::default();
        add(&mut graph, "react", "19.0.0", &[]);
        let adapter = plugin(&mut graph, "adapter", &[("react", "19.0.0")]);
        for app in ["packages/a", "packages/b", "packages/c"] {
            graph.importers.insert(
                app.into(),
                vec![dep("adapter", &adapter), dep("react", "react@19.0.0")],
            );
        }
        let placements = install_and_check(root.path(), &graph);
        assert_eq!(
            placements.all_package_dirs(&adapter),
            &[root_slot(root.path(), "adapter")]
        );
        assert_eq!(
            placements.all_package_dirs("react@19.0.0"),
            &[root_slot(root.path(), "react")]
        );
    }

    #[test]
    fn unresolved_optional_peers_do_not_create_phantom_packages() {
        let root = tempfile::tempdir().unwrap();
        let mut graph = LockfileGraph::default();
        let adapter = plugin(&mut graph, "adapter", &[]);
        let package = graph.packages.get_mut(&adapter).unwrap();
        package.peer_dependencies.insert("react".into(), "*".into());
        package.peer_dependencies_meta.insert(
            "react".into(),
            aube_lockfile::PeerDepMeta { optional: true },
        );
        for app in ["packages/a", "packages/b"] {
            graph
                .importers
                .insert(app.into(), vec![dep("adapter", &adapter)]);
        }
        let placements = install_and_check(root.path(), &graph);
        assert_eq!(placements.iter().count(), 1);
    }

    #[test]
    fn peer_provider_cycles_finish_and_share_compatible_instances() {
        let (send, receive) = std::sync::mpsc::channel();
        std::thread::spawn(move || {
            let root = tempfile::tempdir().unwrap();
            let mut graph = LockfileGraph::default();
            add(&mut graph, "left", "1.0.0", &[("right", "1.0.0")]);
            add(&mut graph, "right", "1.0.0", &[("left", "1.0.0")]);
            graph
                .packages
                .get_mut("left@1.0.0")
                .unwrap()
                .peer_dependencies
                .insert("right".into(), "*".into());
            graph
                .packages
                .get_mut("right@1.0.0")
                .unwrap()
                .peer_dependencies
                .insert("left".into(), "*".into());
            for app in ["packages/a", "packages/b"] {
                graph.importers.insert(
                    app.into(),
                    vec![dep("left", "left@1.0.0"), dep("right", "right@1.0.0")],
                );
            }
            let placements = install_and_check(root.path(), &graph);
            assert_eq!(placements.iter().count(), 2);
            send.send(()).unwrap();
        });
        receive
            .recv_timeout(std::time::Duration::from_secs(30))
            .expect("peer cycles must finish");
    }
}
