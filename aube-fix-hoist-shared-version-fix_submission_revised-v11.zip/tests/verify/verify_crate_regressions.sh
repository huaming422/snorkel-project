#!/usr/bin/env bash
#
# No-regression guard for the shared-version placement work.
#
# The linker crate's own in-source unit suite covers the placement
# invariants a shared-slot change must not break: link-placement, genuine
# version-conflict nesting, symlink repointing after a version bump, and the
# non-fully-hoisting modes. Keeping it green proves a shared-slot change did
# not trade a correct winner for a regression elsewhere in the planner.
#
# We run `--lib` (in-source unit tests only), NOT the full `cargo test`,
# on purpose: the behavioural test file is copied into
# `crates/aube-linker/tests/` and removed again by its own runner, and the
# two checks run concurrently, so a full `cargo test -p aube-linker` could
# race on compiling that transient integration file. `--lib` ignores
# `tests/` entirely, so the two checks never collide.
#
# The image pre-builds `aube-linker --tests`, so a warm run is well under a
# second; the generous verify.toml timeout covers a cold CI host. The
# runner cwd is {repo_dir} (/repo/aube). Grade time is offline, so the
# cargo invocation is pinned to the local registry.
#
# Exit codes:
#   0 — the crate's in-source unit suite passes
#   non-zero — propagates the cargo failure

set -euo pipefail

cd /repo/aube

CARGO_NET_OFFLINE=true cargo test -p aube-linker --lib --offline
