## Task

our agents that keep their conversation history in the OpenAI Conversations
store have started misbehaving on multi-turn runs. this used to work fine. the
first turn of a brand new conversation is still ok, but as soon as there's been
at least one assistant reply, continuing that same conversation makes the model
produce garbled or wrong answers, and the conversation state the server reports
back drifts away from what we show the user.

it only happens with the Conversations-backed sessions. conversations that have
only ever had user turns are fine, and our plain in-memory sessions are fine
too. it smells like something about how we feed the earlier turns back into the
model when we resume an existing conversation.

can you track it down and fix it? one thing to keep in mind: the stored history
itself still needs to read back correctly, since our UI renders from it and we
let people delete individual items out of it.
