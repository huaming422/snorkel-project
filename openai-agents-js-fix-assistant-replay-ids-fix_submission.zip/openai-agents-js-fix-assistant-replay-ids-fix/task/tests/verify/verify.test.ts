// @ts-nocheck
//
// These checks exercise the model-input composition path through two
// pre-existing, stable interfaces, so the behaviour is observed without
// naming any symbol the change might introduce:
//
//   - `prepareInputItemsWithSession`
//     (packages/agents-core/src/runner/sessionPersistence.ts) is the
//     internal function the runner uses to build each turn's model input
//     from stored history plus the new turn. agents-core's own tests import
//     it by relative source path; we do the same. It takes a `Session` and
//     an optional `sessionInputCallback`, and returns both the items sent to
//     the model (`preparedInput`) and the delta the session persists
//     (`sessionItems`).
//   - `OpenAIConversationsSession` (packages/agents-openai) is the real
//     Conversations-backed session. We pass a genuine instance as the
//     session so whatever model-input rewrite mechanism it exposes is the
//     one being exercised. We never call that mechanism by name; we only
//     assert on the observable `preparedInput` / `sessionItems`. A plain
//     `MemorySession` covers the session that does not rewrite history.
//
// Each session's stored history is supplied by overriding `getItems()` with
// a fixed list, so no network or API-conversion path is involved. A lone
// function_call with no matching result would be pruned as an orphan, so the
// tool scenarios seed a function_call together with its function_call_result.

import { describe, it, expect, vi } from 'vitest';
import { prepareInputItemsWithSession } from '../../agents-core/src/runner/sessionPersistence';
import { OpenAIConversationsSession } from '../src/memory/openaiConversationsSession';
import { MemorySession } from '@openai/agents-core';

function conversationsClient() {
  // Minimal client surface so constructing the session never reaches the
  // network. getItems() is overridden per test, so list/create/delete are
  // only placeholders here.
  return {
    conversations: {
      items: { list: vi.fn(), create: vi.fn(), delete: vi.fn() },
      create: vi.fn(),
      delete: vi.fn(),
    },
  };
}

function conversationsSession(history) {
  const session = new OpenAIConversationsSession({
    client: conversationsClient(),
    conversationId: 'conv-test',
  });
  session.getItems = async () => history;
  return session;
}

describe('verify', () => {
  // The items a run sends to the model are the rewritten history (assistant
  // replay metadata removed), while the delta the session persists for the
  // turn is only the new input. No-callback path.
  it('core_model_input_rewrite', async () => {
    const userHistory = {
      id: 'conv-user',
      type: 'message',
      role: 'user',
      content: 'user history',
      providerData: { server: 'metadata' },
    };
    const assistantHistory = {
      id: 'conv-assistant',
      type: 'message',
      role: 'assistant',
      status: 'completed',
      content: [{ type: 'output_text', text: 'assistant history' }],
      providerData: { server: 'metadata' },
    };
    const functionCall = {
      id: 'conv-call',
      type: 'function_call',
      name: 'lookup',
      callId: 'call-history',
      arguments: '{}',
      status: 'completed',
    };
    const functionCallResult = {
      id: 'conv-output',
      type: 'function_call_result',
      name: 'lookup',
      callId: 'call-history',
      output: 'ok',
      status: 'completed',
    };
    const session = conversationsSession([
      userHistory,
      assistantHistory,
      functionCall,
      functionCallResult,
    ]);

    const result = await prepareInputItemsWithSession('new', session);

    // Assistant item comes back without id/providerData; every other history
    // item is unchanged; the new input is appended.
    expect(result.preparedInput).toEqual([
      userHistory,
      {
        type: 'message',
        role: 'assistant',
        status: 'completed',
        content: [{ type: 'output_text', text: 'assistant history' }],
      },
      functionCall,
      functionCallResult,
      { type: 'message', role: 'user', content: 'new' },
    ]);
    // Only the new turn is persisted; stored history is neither mutated nor
    // re-persisted.
    expect(result.sessionItems).toEqual([
      { type: 'message', role: 'user', content: 'new' },
    ]);
  });

  // When a session input callback returns a combined list in which it has
  // itself already removed the same assistant replay metadata, that history
  // item is still recognised as the stored item (matched via its rewritten
  // identity) and is not persisted again. The persisted delta is the new
  // items only.
  it('callback_dedup_matching', async () => {
    const assistantHistory = {
      id: 'conv-assistant',
      type: 'message',
      role: 'assistant',
      status: 'completed',
      content: [{ type: 'output_text', text: 'assistant history' }],
      providerData: { server: 'metadata' },
    };
    const newItem = { type: 'message', role: 'user', content: 'new' };
    const session = conversationsSession([assistantHistory]);

    const result = await prepareInputItemsWithSession(
      [newItem],
      session,
      (history, newItems) => {
        // Callback strips the same replay metadata the session would strip
        // for model input, then returns history + new input combined.
        const {
          id: _id,
          providerData: _providerData,
          provider_data: _providerDataSnake,
          ...historyCopy
        } = history[0];
        return [historyCopy, { ...newItems[0] }];
      },
    );

    expect(result.preparedInput).toEqual([
      {
        type: 'message',
        role: 'assistant',
        status: 'completed',
        content: [{ type: 'output_text', text: 'assistant history' }],
      },
      newItem,
    ]);
    // The stripped history item is matched to stored history, so only the new
    // item is persisted.
    expect(result.sessionItems).toEqual([newItem]);
  });

  // The rewrite is scoped to the items that collide with server-managed
  // history (assistant messages). User-message ids and tool call / tool
  // output ids survive the model-input path intact.
  it('tool_user_ids_preserved', async () => {
    const userHistory = {
      id: 'conv-user',
      type: 'message',
      role: 'user',
      content: 'user history',
      providerData: { server: 'metadata' },
    };
    const assistantHistory = {
      id: 'conv-assistant',
      type: 'message',
      role: 'assistant',
      status: 'completed',
      content: [{ type: 'output_text', text: 'assistant history' }],
      providerData: { server: 'metadata' },
    };
    const functionCall = {
      id: 'conv-call',
      type: 'function_call',
      name: 'lookup',
      callId: 'call-1',
      arguments: '{}',
      status: 'completed',
    };
    const functionCallResult = {
      id: 'conv-output',
      type: 'function_call_result',
      name: 'lookup',
      callId: 'call-1',
      output: 'ok',
      status: 'completed',
    };
    const session = conversationsSession([
      userHistory,
      assistantHistory,
      functionCall,
      functionCallResult,
    ]);

    const result = await prepareInputItemsWithSession('new', session);
    const [preparedUser, preparedAssistant, preparedCall, preparedResult] =
      result.preparedInput;

    // User id and providerData preserved.
    expect(preparedUser).toEqual(userHistory);
    // Assistant id removed.
    expect(preparedAssistant.id).toBeUndefined();
    expect(preparedAssistant.providerData).toBeUndefined();
    expect(preparedAssistant.role).toBe('assistant');
    // Tool call / tool output ids and linkage preserved.
    expect(preparedCall).toEqual(functionCall);
    expect(preparedResult).toEqual(functionCallResult);
  });

  // OpenAIConversationsSession's model-input rewrite removes replay metadata
  // (id, providerData, provider_data) from assistant messages only and
  // returns user messages and function-call items unchanged. Driven through
  // the composition path so both camelCase and snake-case provider metadata
  // on the assistant item are observed to disappear.
  it('openai_assistant_only_strip', async () => {
    const userHistory = {
      id: 'conv-user',
      type: 'message',
      role: 'user',
      content: 'user history',
      providerData: { server: 'metadata' },
    };
    const assistantHistory = {
      id: 'conv-assistant',
      type: 'message',
      role: 'assistant',
      status: 'completed',
      content: [{ type: 'output_text', text: 'assistant history' }],
      providerData: { server: 'camel' },
      provider_data: { server: 'snake' },
    };
    const functionCall = {
      id: 'conv-call',
      type: 'function_call',
      name: 'lookup',
      callId: 'call-1',
      arguments: '{}',
      status: 'completed',
    };
    const functionCallResult = {
      id: 'conv-output',
      type: 'function_call_result',
      name: 'lookup',
      callId: 'call-1',
      output: 'ok',
      status: 'completed',
    };
    const session = conversationsSession([
      userHistory,
      assistantHistory,
      functionCall,
      functionCallResult,
    ]);

    const result = await prepareInputItemsWithSession('new', session);
    const [preparedUser, preparedAssistant, preparedCall, preparedResult] =
      result.preparedInput;

    expect(preparedUser).toEqual(userHistory);
    expect(preparedAssistant).toEqual({
      type: 'message',
      role: 'assistant',
      status: 'completed',
      content: [{ type: 'output_text', text: 'assistant history' }],
    });
    expect(preparedCall).toEqual(functionCall);
    expect(preparedResult).toEqual(functionCallResult);
  });

  // A session that does not opt into model-input rewriting replays its stored
  // history verbatim into the model input. MemorySession keeps its stored
  // items (with ids) and they appear unchanged, followed by the new input.
  it('regular_session_passthrough', async () => {
    const session = new MemorySession('sess-1');
    const assistantHistory = {
      id: 'h1',
      type: 'message',
      role: 'assistant',
      status: 'completed',
      content: [{ type: 'output_text', text: 'x' }],
      providerData: { server: 'metadata' },
    };
    const userHistory = {
      id: 'h2',
      type: 'message',
      role: 'user',
      content: 'u',
      providerData: { server: 'metadata' },
    };
    await session.addItems([assistantHistory, userHistory]);

    const result = await prepareInputItemsWithSession('new', session);

    expect(result.preparedInput).toEqual([
      assistantHistory,
      userHistory,
      { type: 'message', role: 'user', content: 'new' },
    ]);
  });

  // The read path stays intact: OpenAIConversationsSession.getItems() returns
  // stored items with their ids (and provider metadata) preserved, so UI
  // rendering and per-item deletion keep working. The model-input rewrite is a
  // separate concern and must not leak into what the session exposes for
  // reading. A fixed `conversationsList` world drives getItems() directly.
  it('persist_shape_unchanged', async () => {
    const storedUser = {
      id: 'conv-user',
      type: 'message',
      role: 'user',
      content: [{ type: 'input_text', text: 'user history' }],
    };
    const storedAssistant = {
      id: 'conv-assistant',
      type: 'message',
      role: 'assistant',
      status: 'completed',
      content: [{ type: 'output_text', text: 'assistant history' }],
    };
    const listFn = vi.fn(() => ({
      async *[Symbol.asyncIterator]() {
        yield storedUser;
        yield storedAssistant;
      },
    }));
    const client = {
      conversations: {
        items: { list: listFn, create: vi.fn(), delete: vi.fn() },
        create: vi.fn(),
        delete: vi.fn(),
      },
    };
    const session = new OpenAIConversationsSession({
      client,
      conversationId: 'conv-test',
    });

    const items = await session.getItems();
    const readUser = items.find((item) => item.role === 'user');
    const readAssistant = items.find((item) => item.role === 'assistant');

    // The read path preserves ids for every role, including assistant, so
    // deletion / rendering workflows that key off ids keep working.
    expect(readUser.id).toBe('conv-user');
    expect(readAssistant.id).toBe('conv-assistant');
  });
});
