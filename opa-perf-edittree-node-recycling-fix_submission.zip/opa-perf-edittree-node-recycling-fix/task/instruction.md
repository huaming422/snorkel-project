## Task

we're seeing OPA's `json.patch` builtin (and the related `json.remove` / `json.filter`) throw off a ton of heap garbage on churn-heavy workloads. anything that pushes long sequences of add / remove / replace operations through these builtins, like tools that repeatedly mutate Rego AST or data documents in place, spikes memory use and allocation counts well past what the work actually needs, and the GC pressure that comes with it is bad enough to hurt us on the biggest churn workloads.

can you dig into this built-in path and bring the allocation and memory cost down on those churn-heavy workloads? the results of the JSON builtins have to come out exactly the same; this is purely about cutting memory and allocation overhead, not about changing any behavior. raw CPU time doesn't need to improve, so if wall-clock stays flat that's fine.
