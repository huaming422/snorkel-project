# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# Exports a deterministic, offline Go environment. The toolchain, module cache
# and build cache are baked into the image; nothing is fetched here.
cd /repo/opa

# Offline switches right after cd so a cache miss fails fast rather than
# reaching for a proxy.
export GOFLAGS="-mod=mod"
export GOPROXY="off"
export GOTOOLCHAIN="local"
export CGO_ENABLED="1"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
mkdir -p "$GOCACHE" "$GOMODCACHE"

# Dependencies: offline-first against the image bake.
if GOPROXY=off go mod download > /tmp/test-setup-godl.log 2>&1; then
    echo "[offline-first] go modules satisfied from image cache"
else
    tail -40 /tmp/test-setup-godl.log >&2; exit 1
fi
