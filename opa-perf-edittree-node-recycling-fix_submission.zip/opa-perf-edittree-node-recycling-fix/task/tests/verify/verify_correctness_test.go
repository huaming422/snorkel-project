// Copyright 2026 The OPA Authors.  All rights reserved.
// Use of this source code is governed by an Apache2
// license that can be found in the LICENSE file.

// Output-equivalence gate for the JSON built-in path.
//
// This file is injected into v1/topdown/ at grade time and compiles as part of
// `package topdown`, driving the unexported built-in entry points
// builtinJSONPatch / builtinJSONRemove / builtinJSONFilter directly — all
// pre-existing, stable, same-package interfaces. It asserts that each built-in
// still produces byte-identical results across the full operation and type
// matrix (add / remove / replace / move / copy / test over objects, arrays,
// sets, nested paths, and churn chains). The memory optimization must change no
// observable output; any reclamation bug that corrupts a shared/borrowed value
// or recycles a live structure surfaces here as a wrong result.
//
// This verifier is deliberately self-contained — it embeds its own expected
// values rather than re-running the repository's own correctness suite. The Go
// runner leaves the package's existing *_test.go files in place at grade time
// and test.sh does not restore them, so a suite that merely re-ran repo-resident
// tests could be weakened by edits to those files; embedding the expectations
// here keeps the gate independent of the working tree's test code.
//
// All identifiers carry a `vrfCorrect` prefix so this file composes cleanly with
// the package's own test files. Expected values are parsed with ast.MustParseTerm
// and compared with Value.Compare, mirroring the package's established pattern.

package topdown

import (
	"context"
	"testing"

	"github.com/open-policy-agent/opa/v1/ast"
)

// vrfCorrectEval runs a built-in over the given operands and returns the term it
// yields through iter (or nil if the built-in yields nothing, e.g. json.remove
// reducing to no result).
func vrfCorrectEval(t *testing.T, fn func(BuiltinContext, []*ast.Term, func(*ast.Term) error) error, operands []*ast.Term) *ast.Term {
	t.Helper()
	var got *ast.Term
	iter := func(res *ast.Term) error {
		got = res
		return nil
	}
	if err := fn(BuiltinContext{Context: context.Background()}, operands, iter); err != nil {
		t.Fatalf("built-in returned error: %v", err)
	}
	return got
}

func vrfCorrectCheck(t *testing.T, note string, got *ast.Term, wantJSON string) {
	t.Helper()
	if got == nil {
		t.Fatalf("%s: built-in yielded no result", note)
	}
	want := ast.MustParseTerm(wantJSON)
	if got.Value.Compare(want.Value) != 0 {
		t.Fatalf("%s: wrong result\n got:  %v\n want: %v", note, got, want)
	}
}

// TestVerifyJSONPatchEquivalence drives json.patch across the full op/type
// matrix and checks byte-identical output.
func TestVerifyJSONPatchEquivalence(t *testing.T) {
	cases := []struct {
		note    string
		source  string
		patches string
		want    string
	}{
		{"add scalar", `{"a": 2}`, `[{"op": "add", "path": "/b", "value": 3}]`, `{"a": 2, "b": 3}`},
		{"remove scalar", `{"a": true, "b": 1}`, `[{"op": "remove", "path": "/a"}]`, `{"b": 1}`},
		{"replace scalar", `{"a": true}`, `[{"op": "replace", "path": "/a", "value": 3}]`, `{"a": 3}`},
		{"move", `{"a": true}`, `[{"op": "move", "path": "/b", "from": "/a"}]`, `{"b": true}`},
		{"copy", `{"a": true}`, `[{"op": "copy", "path": "/b", "from": "/a"}]`, `{"a": true, "b": true}`},
		{"test keeps value", `{"a": 2}`, `[{"op": "test", "path": "/a", "value": 2}]`, `{"a": 2}`},
		{
			"add then remove nested composite round-trips",
			`{}`,
			`[{"op": "add", "path": "/k", "value": {"inner": [1, 2]}}, {"op": "remove", "path": "/k"}]`,
			`{}`,
		},
		{
			"add-remove chain x3",
			`{"a": true}`,
			`[{"op": "add", "path": "/a", "value": 3}, {"op": "remove", "path": "/a"},
			  {"op": "add", "path": "/a", "value": 3}, {"op": "remove", "path": "/a"},
			  {"op": "add", "path": "/a", "value": 3}, {"op": "remove", "path": "/a"}]`,
			`{}`,
		},
		{
			"add-move-remove chain x2",
			`{"a": true}`,
			`[{"op": "add", "path": "/a", "value": 3}, {"op": "move", "path": "/b", "from": "/a"}, {"op": "remove", "path": "/b"},
			  {"op": "add", "path": "/a", "value": 3}, {"op": "move", "path": "/b", "from": "/a"}, {"op": "remove", "path": "/b"}]`,
			`{}`,
		},
		{
			"nested object edits",
			`{"outer": {"a": 1, "b": 2}}`,
			`[{"op": "add", "path": "/outer/c", "value": 3}, {"op": "remove", "path": "/outer/a"}, {"op": "replace", "path": "/outer/b", "value": 9}]`,
			`{"outer": {"b": 9, "c": 3}}`,
		},
		{
			"array element replace and append",
			`{"xs": [0, 1, 2]}`,
			`[{"op": "replace", "path": "/xs/1", "value": 11}, {"op": "add", "path": "/xs/-", "value": 3}]`,
			`{"xs": [0, 11, 2, 3]}`,
		},
		{
			"composite replace with nested composite",
			`{"k": {"old": [1]}}`,
			`[{"op": "replace", "path": "/k", "value": {"new": {"deep": [9, 8]}}}]`,
			`{"k": {"new": {"deep": [9, 8]}}}`,
		},
		// The cases below exercise reclamation on composite subtrees nested more
		// than two levels deep, where the deleted/replaced/moved node is NOT the
		// whole document: a live sibling, ancestor, or source value must survive
		// unchanged. A solution that reclaims too eagerly — recycling a subtree
		// that is still reachable, or walking up/across into a sibling branch —
		// corrupts one of these survivors and produces a wrong result here,
		// rather than only on the shallow single-node cases above.
		{
			"deep inner remove keeps siblings live",
			`{}`,
			`[{"op": "add", "path": "/a", "value": {"b": {"c": {"d": [1, 2, 3]}}, "sib": {"x": 9}}},
			  {"op": "remove", "path": "/a/b/c"}]`,
			`{"a": {"b": {}, "sib": {"x": 9}}}`,
		},
		{
			"deep replace with live sibling",
			`{"root": {"keep": {"deep": [7, 8]}, "target": {"old": {"q": [1]}}}}`,
			`[{"op": "replace", "path": "/root/target", "value": {"new": {"r": [2, 3]}}}]`,
			`{"root": {"keep": {"deep": [7, 8]}, "target": {"new": {"r": [2, 3]}}}}`,
		},
		{
			"multi-level churn chain x3 keeps sibling",
			`{"keep": {"a": {"b": [1]}}}`,
			`[{"op": "add", "path": "/churn", "value": {"l1": {"l2": {"l3": [9]}}}}, {"op": "remove", "path": "/churn"},
			  {"op": "add", "path": "/churn", "value": {"l1": {"l2": {"l3": [9]}}}}, {"op": "remove", "path": "/churn"},
			  {"op": "add", "path": "/churn", "value": {"l1": {"l2": {"l3": [9]}}}}, {"op": "remove", "path": "/churn"}]`,
			`{"keep": {"a": {"b": [1]}}}`,
		},
		{
			"deep move leaves source branch intact",
			`{"src": {"deep": {"inner": [1, 2]}}, "dst": {}}`,
			`[{"op": "move", "path": "/dst/moved", "from": "/src/deep"}]`,
			`{"src": {}, "dst": {"moved": {"inner": [1, 2]}}}`,
		},
		{
			"deep copy keeps source live",
			`{"src": {"deep": {"inner": [1, 2]}}}`,
			`[{"op": "copy", "path": "/dst", "from": "/src/deep"}]`,
			`{"src": {"deep": {"inner": [1, 2]}}, "dst": {"inner": [1, 2]}}`,
		},
		{
			"nested array-of-objects element replace and remove",
			`{}`,
			`[{"op": "add", "path": "/m", "value": {"items": [{"id": 1, "t": [0]}, {"id": 2, "t": [1, 2]}]}},
			  {"op": "replace", "path": "/m/items/0", "value": {"id": 9, "t": [7, 8, 9]}},
			  {"op": "remove", "path": "/m/items/1"}]`,
			`{"m": {"items": [{"id": 9, "t": [7, 8, 9]}]}}`,
		},
	}

	for _, tc := range cases {
		t.Run(tc.note, func(t *testing.T) {
			source := ast.MustParseTerm(tc.source)
			patches := ast.MustParseTerm(tc.patches)
			operands := []*ast.Term{source, patches}
			got := vrfCorrectEval(t, builtinJSONPatch, operands)
			vrfCorrectCheck(t, tc.note, got, tc.want)

			// Borrowed-value guard: the source term must be unchanged after the
			// built-in runs. If a solution recycled a borrowed/shared sub-term,
			// the original source value would be mutated.
			if source.Value.Compare(ast.MustParseTerm(tc.source).Value) != 0 {
				t.Fatalf("%s: source term was mutated by the built-in (borrowed value corrupted)", tc.note)
			}
		})
	}
}

// TestVerifyJSONRemoveEquivalence drives json.remove over object/array/nested
// paths and checks byte-identical output.
func TestVerifyJSONRemoveEquivalence(t *testing.T) {
	cases := []struct {
		note   string
		source string
		paths  string
		want   string
	}{
		{"remove one key", `{"a": 1, "b": 2}`, `["a"]`, `{"b": 2}`},
		{"remove nested key", `{"a": {"x": 1, "y": 2}}`, `["a/x"]`, `{"a": {"y": 2}}`},
		{"remove multiple", `{"a": 1, "b": 2, "c": 3}`, `["a", "c"]`, `{"b": 2}`},
		{"remove deep composite", `{"a": {"b": {"c": [1, 2]}}}`, `["a/b"]`, `{"a": {}}`},
	}
	for _, tc := range cases {
		t.Run(tc.note, func(t *testing.T) {
			source := ast.MustParseTerm(tc.source)
			paths := ast.MustParseTerm(tc.paths)
			operands := []*ast.Term{source, paths}
			got := vrfCorrectEval(t, builtinJSONRemove, operands)
			vrfCorrectCheck(t, tc.note, got, tc.want)
			if source.Value.Compare(ast.MustParseTerm(tc.source).Value) != 0 {
				t.Fatalf("%s: source term was mutated by the built-in (borrowed value corrupted)", tc.note)
			}
		})
	}
}

// TestVerifyJSONFilterEquivalence drives json.filter over object/nested paths
// and checks byte-identical output.
func TestVerifyJSONFilterEquivalence(t *testing.T) {
	cases := []struct {
		note   string
		source string
		paths  string
		want   string
	}{
		{"keep one key", `{"a": 1, "b": 2}`, `["a"]`, `{"a": 1}`},
		{"keep nested path", `{"a": {"x": 1, "y": 2}, "b": 3}`, `["a/x"]`, `{"a": {"x": 1}}`},
		{"keep multiple", `{"a": 1, "b": 2, "c": 3}`, `["a", "c"]`, `{"a": 1, "c": 3}`},
		{"shared prefix", `{"a": {"b": 1, "c": 2, "d": 3}}`, `["a/b", "a/c"]`, `{"a": {"b": 1, "c": 2}}`},
	}
	for _, tc := range cases {
		t.Run(tc.note, func(t *testing.T) {
			source := ast.MustParseTerm(tc.source)
			paths := ast.MustParseTerm(tc.paths)
			operands := []*ast.Term{source, paths}
			got := vrfCorrectEval(t, builtinJSONFilter, operands)
			vrfCorrectCheck(t, tc.note, got, tc.want)
			if source.Value.Compare(ast.MustParseTerm(tc.source).Value) != 0 {
				t.Fatalf("%s: source term was mutated by the built-in (borrowed value corrupted)", tc.note)
			}
		})
	}
}
