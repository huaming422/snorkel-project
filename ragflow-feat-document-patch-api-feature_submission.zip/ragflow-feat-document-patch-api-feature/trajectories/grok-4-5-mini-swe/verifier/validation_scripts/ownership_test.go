package service

import (
	"testing"

	"ragflow/internal/dao"
	"ragflow/internal/entity"
)

func TestOwnershipValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			db := setupServiceTestDB(t)
			pushServiceDB(t, db)

			ownerTenant := tc.Inputs["owner_tenant"].(string)
			actorTenant := tc.Inputs["actor_tenant"].(string)
			docName := tc.Inputs["doc_name"].(string)
			attemptedName := tc.Inputs["attempted_name"].(string)

			// Seed a dataset owned by ownerTenant
			kbID := "kb-ownership-1"
			insertTestKB(t, kbID, ownerTenant, 1, 0, 0)

			// Create the document directly with the given name and suffix
			suffix := ".pdf"
			doc := &entity.Document{
				ID:           "doc-ownership-1",
				KbID:         kbID,
				ParserID:     "naive",
				ParserConfig: entity.JSONMap{},
				TokenNum:     0,
				ChunkNum:     0,
				Name:         sptr(docName),
				Suffix:       suffix,
				Type:         "doc",
				SourceType:   "local",
				CreatedBy:    ownerTenant,
				Status:       sptr("1"),
				Run:          sptr(string(entity.TaskStatusDone)),
			}
			if err := dao.DB.Create(doc).Error; err != nil {
				t.Fatalf("insert doc: %v", err)
			}

			// Construct the service offline
			svc := &DocumentService{
				documentDAO:      dao.NewDocumentDAO(),
				kbDAO:            dao.NewKnowledgebaseDAO(),
				taskDAO:          dao.NewTaskDAO(),
				file2DocumentDAO: dao.NewFile2DocumentDAO(),
				fileDAO:          dao.NewFileDAO(),
				docEngine:        nil,
				metadataSvc:      nil,
			}

			// Invoke the update as actorTenant
			_, err := svc.UpdateDatasetDocument(actorTenant, kbID, "doc-ownership-1", &DatasetDocumentUpdateRequest{
				HasName: true,
				Name:    sptr(attemptedName),
			})

			outcome := tc.Expected["outcome"].(string)
			finalDocName := tc.Expected["final_doc_name"].(string)

			if outcome == "rejected" {
				if err == nil {
					t.Errorf("expected a non-nil error for rejected case, got nil")
				}
			} else {
				if err != nil {
					t.Errorf("expected nil error for accepted case, got: %v", err)
				}
			}

			// Reload the document and check its name
			reloaded, err2 := dao.NewDocumentDAO().GetByID("doc-ownership-1")
			if err2 != nil {
				t.Fatalf("failed to reload document: %v", err2)
			}
			if reloaded.Name == nil {
				t.Fatal("document Name should not be nil")
			}
			if *reloaded.Name != finalDocName {
				t.Errorf("final_doc_name: expected %q, got %q", finalDocName, *reloaded.Name)
			}
		})
	}
}
