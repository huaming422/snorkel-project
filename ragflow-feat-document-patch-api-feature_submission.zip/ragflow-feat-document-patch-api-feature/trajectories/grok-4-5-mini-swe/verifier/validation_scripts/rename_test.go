package service

import (
	"testing"

	"ragflow/internal/dao"
	"ragflow/internal/entity"
)

func TestRenameValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			db := setupServiceTestDB(t)
			pushServiceDB(t, db)

			docName := tc.Inputs["doc_name"].(string)
			newName := tc.Inputs["new_name"].(string)
			otherName := tc.Inputs["other_name"].(string)

			kbID := "kb-rename-1"
			insertTestKB(t, kbID, "tenant-1", 1, 0, 0)

			// Derive the suffix from the doc name (e.g., "old.pdf" -> ".pdf")
			suffix := ""
			for i := len(docName) - 1; i >= 0; i-- {
				if docName[i] == '.' {
					suffix = docName[i:]
					break
				}
			}

			// Create the target document doc-1 with the given name
			doc := &entity.Document{
				ID:           "doc-rename-1",
				KbID:         kbID,
				ParserID:     "naive",
				ParserConfig: entity.JSONMap{},
				TokenNum:     0,
				ChunkNum:     0,
				Name:         sptr(docName),
				Suffix:       suffix,
				Type:         "doc",
				SourceType:   "local",
				CreatedBy:    "tenant-1",
				Status:       sptr("1"),
				Run:          sptr(string(entity.TaskStatusDone)),
			}
			if err := dao.DB.Create(doc).Error; err != nil {
				t.Fatalf("insert doc: %v", err)
			}

			// Create linked file row file-1 with nil location
			insertTestFile(t, "file-rename-1", kbID, docName, nil)

			// Create the link between file and document
			insertTestFile2Document(t, "f2d-rename-1", "file-rename-1", "doc-rename-1")

			// When other_name is not empty, create a second document in the same dataset
			if otherName != "" {
				otherSuffix := ""
				for i := len(otherName) - 1; i >= 0; i-- {
					if otherName[i] == '.' {
						otherSuffix = otherName[i:]
						break
					}
				}
				otherDoc := &entity.Document{
					ID:           "doc-rename-2",
					KbID:         kbID,
					ParserID:     "naive",
					ParserConfig: entity.JSONMap{},
					TokenNum:     0,
					ChunkNum:     0,
					Name:         sptr(otherName),
					Suffix:       otherSuffix,
					Type:         "doc",
					SourceType:   "local",
					CreatedBy:    "tenant-1",
					Status:       sptr("1"),
				}
				if err := dao.DB.Create(otherDoc).Error; err != nil {
					t.Fatalf("insert other doc: %v", err)
				}
			}

			// Construct the service offline
			svc := &DocumentService{
				documentDAO:      dao.NewDocumentDAO(),
				kbDAO:            dao.NewKnowledgebaseDAO(),
				taskDAO:          dao.NewTaskDAO(),
				file2DocumentDAO: dao.NewFile2DocumentDAO(),
				fileDAO:          dao.NewFileDAO(),
				docEngine:        nil,
				metadataSvc:      nil,
			}

			// Invoke the update as owner tenant-1
			_, err := svc.UpdateDatasetDocument("tenant-1", kbID, "doc-rename-1", &DatasetDocumentUpdateRequest{
				HasName: true,
				Name:    sptr(newName),
			})

			outcome := tc.Expected["outcome"].(string)
			documentName := tc.Expected["document_name"].(string)
			fileName := tc.Expected["file_name"].(string)

			if outcome == "rejected" {
				if err == nil {
					t.Errorf("expected non-nil error for rejected case")
				}
			} else {
				if err != nil {
					t.Errorf("expected nil error for accepted case, got: %v", err)
				}
			}

			// Reload doc-1 and check its name (unconditional)
			reloadedDoc, err2 := dao.NewDocumentDAO().GetByID("doc-rename-1")
			if err2 != nil {
				t.Fatalf("failed to reload document: %v", err2)
			}
			if reloadedDoc.Name == nil {
				t.Fatal("document Name should not be nil")
			}
			if *reloadedDoc.Name != documentName {
				t.Errorf("document_name: expected %q, got %q", documentName, *reloadedDoc.Name)
			}

			// Reload file-1 and check its name (unconditional)
			reloadedFile, err3 := dao.NewFileDAO().GetByID("file-rename-1")
			if err3 != nil {
				t.Fatalf("failed to reload file: %v", err3)
			}
			if reloadedFile.Name != fileName {
				t.Errorf("file_name: expected %q, got %q", fileName, reloadedFile.Name)
			}
		})
	}
}
