package service

import (
	"testing"

	"ragflow/internal/dao"
	"ragflow/internal/entity"
)

func TestParserConfigMergeValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			db := setupServiceTestDB(t)
			pushServiceDB(t, db)

			initialConfig := tc.Inputs["initial_config"].(map[string]interface{})
			sentConfig := tc.Inputs["sent_config"].(map[string]interface{})

			kbID := "kb-pcmerge-1"
			insertTestKB(t, kbID, "tenant-1", 1, 0, 0)

			// Create document doc-1 with the initial parser config
			doc := &entity.Document{
				ID:           "doc-pcmerge-1",
				KbID:         kbID,
				ParserID:     "naive",
				ParserConfig: entity.JSONMap(initialConfig),
				TokenNum:     0,
				ChunkNum:     0,
				Name:         sptr("doc.txt"),
				Suffix:       ".txt",
				Type:         "doc",
				SourceType:   "local",
				CreatedBy:    "tenant-1",
				Status:       sptr("1"),
				Run:          sptr(string(entity.TaskStatusDone)),
			}
			if err := dao.DB.Create(doc).Error; err != nil {
				t.Fatalf("insert doc: %v", err)
			}

			// Construct the service offline
			svc := &DocumentService{
				documentDAO:      dao.NewDocumentDAO(),
				kbDAO:            dao.NewKnowledgebaseDAO(),
				taskDAO:          dao.NewTaskDAO(),
				file2DocumentDAO: dao.NewFile2DocumentDAO(),
				fileDAO:          dao.NewFileDAO(),
				docEngine:        nil,
				metadataSvc:      nil,
			}

			// Invoke the update with ONLY parser_config present
			_, err := svc.UpdateDatasetDocument("tenant-1", kbID, "doc-pcmerge-1", &DatasetDocumentUpdateRequest{
				HasParserConfig: true,
				ParserConfig:    sentConfig,
			})
			if err != nil {
				t.Fatalf("update failed: %v", err)
			}

			// Reload doc-1 and read its ParserConfig
			reloadedDoc, errDoc := dao.NewDocumentDAO().GetByID("doc-pcmerge-1")
			if errDoc != nil {
				t.Fatalf("failed to reload document: %v", errDoc)
			}

			mergedConfig := map[string]interface{}(reloadedDoc.ParserConfig)

			// Assert chunk_token_num (unconditional - always present per spec)
			expChunkTokenNum := tc.Expected["chunk_token_num"].(float64)
			val, ok := mergedConfig["chunk_token_num"]
			if !ok {
				t.Errorf("chunk_token_num key missing from merged config")
			} else {
				var actualFloat float64
				switch v := val.(type) {
				case float64:
					actualFloat = v
				case int64:
					actualFloat = float64(v)
				case int:
					actualFloat = float64(v)
				default:
					t.Fatalf("chunk_token_num has unexpected type %T: %v", val, val)
				}
				if actualFloat != expChunkTokenNum {
					t.Errorf("chunk_token_num: expected %v, got %v", expChunkTokenNum, actualFloat)
				}
			}

			// Assert raptor_state (always present per spec)
			expRaptorState := tc.Expected["raptor_state"].(string)
			_, hasRaptor := mergedConfig["raptor"]
			if expRaptorState == "absent" {
				if hasRaptor {
					t.Errorf("raptor key should be absent from merged config, but found it: %v", mergedConfig)
				}
			} else if expRaptorState == "present" {
				if !hasRaptor {
					t.Errorf("raptor key should be present in merged config, but not found: %v", mergedConfig)
				}
			}

			// Assert extra_key / extra_val (skip only when value is "__skip__")
			expExtraKey := tc.Expected["extra_key"].(string)
			expExtraVal := tc.Expected["extra_val"].(string)
			if expExtraKey != "__skip__" {
				val2, ok2 := mergedConfig[expExtraKey]
				if !ok2 {
					t.Errorf("extra_key %q missing from merged config", expExtraKey)
				} else {
					strVal, ok3 := val2.(string)
					if !ok3 {
						t.Errorf("extra_val for key %q should be string, got %T: %v", expExtraKey, val2, val2)
					} else if strVal != expExtraVal {
						t.Errorf("extra_val: expected %q, got %q", expExtraVal, strVal)
					}
				}
			}
		})
	}
}
