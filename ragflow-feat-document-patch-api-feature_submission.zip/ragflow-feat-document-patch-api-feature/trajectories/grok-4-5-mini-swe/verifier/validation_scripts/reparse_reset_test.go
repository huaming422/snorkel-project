package service

import (
	"testing"

	"ragflow/internal/dao"
	"ragflow/internal/entity"
)

func TestReparseResetValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			db := setupServiceTestDB(t)
			pushServiceDB(t, db)

			docToken := int64(tc.Inputs["doc_token"].(float64))
			docChunk := int64(tc.Inputs["doc_chunk"].(float64))
			scenario := tc.Inputs["scenario"].(string)

			kbID := "kb-reparse-1"
			// Seed KB with same token/chunk as the document
			insertTestKB(t, kbID, "tenant-1", 1, docToken, docChunk)

			// Create a fully processed document doc-1
			doc := &entity.Document{
				ID:           "doc-reparse-1",
				KbID:         kbID,
				ParserID:     "naive",
				ParserConfig: entity.JSONMap{},
				TokenNum:     docToken,
				ChunkNum:     docChunk,
				Progress:     1,
				Name:         sptr("doc.txt"),
				Suffix:       ".txt",
				Type:         "doc",
				SourceType:   "local",
				CreatedBy:    "tenant-1",
				Status:       sptr("1"),
				Run:          sptr(string(entity.TaskStatusDone)),
			}
			if err := dao.DB.Create(doc).Error; err != nil {
				t.Fatalf("insert doc: %v", err)
			}

			// Construct the service offline
			svc := &DocumentService{
				documentDAO:      dao.NewDocumentDAO(),
				kbDAO:            dao.NewKnowledgebaseDAO(),
				taskDAO:          dao.NewTaskDAO(),
				file2DocumentDAO: dao.NewFile2DocumentDAO(),
				fileDAO:          dao.NewFileDAO(),
				docEngine:        nil,
				metadataSvc:      nil,
			}

			// Build the request based on scenario
			buildReq := func() *DatasetDocumentUpdateRequest {
				switch scenario {
				case "chunk_method":
					chunkMethod := tc.Inputs["chunk_method"].(string)
					return &DatasetDocumentUpdateRequest{
						HasChunkMethod: true,
						ChunkMethod:    sptr(chunkMethod),
					}
				case "parser_id":
					parserID := tc.Inputs["parser_id"].(string)
					return &DatasetDocumentUpdateRequest{
						HasParserID: true,
						ParserID:    sptr(parserID),
					}
				case "precedence":
					pipelineID := tc.Inputs["pipeline_id"].(string)
					chunkMethod := tc.Inputs["chunk_method"].(string)
					return &DatasetDocumentUpdateRequest{
						HasPipelineID:  true,
						PipelineID:     sptr(pipelineID),
						HasChunkMethod: true,
						ChunkMethod:    sptr(chunkMethod),
					}
				case "idempotent":
					chunkMethod := tc.Inputs["chunk_method"].(string)
					return &DatasetDocumentUpdateRequest{
						HasChunkMethod: true,
						ChunkMethod:    sptr(chunkMethod),
					}
				default:
					t.Fatalf("unknown scenario: %s", scenario)
					return nil
				}
			}

			// First invocation
			req := buildReq()
			_, err := svc.UpdateDatasetDocument("tenant-1", kbID, "doc-reparse-1", req)
			if err != nil {
				t.Fatalf("first update failed for scenario %s: %v", scenario, err)
			}

			// Second invocation for idempotent scenario
			if scenario == "idempotent" {
				req2 := buildReq()
				_, err2 := svc.UpdateDatasetDocument("tenant-1", kbID, "doc-reparse-1", req2)
				if err2 != nil {
					t.Fatalf("second update failed for idempotent scenario: %v", err2)
				}
			}

			// Reload doc-1 and KB
			reloadedDoc, errDoc := dao.NewDocumentDAO().GetByID("doc-reparse-1")
			if errDoc != nil {
				t.Fatalf("failed to reload document: %v", errDoc)
			}

			reloadedKB, errKB := dao.NewKnowledgebaseDAO().GetByID(kbID)
			if errKB != nil {
				t.Fatalf("failed to reload KB: %v", errKB)
			}

			// Assert expected values, skipping "__skip__"
			expDocParserID := tc.Expected["doc_parser_id"].(string)
			if expDocParserID != "__skip__" {
				if reloadedDoc.ParserID != expDocParserID {
					t.Errorf("doc_parser_id: expected %q, got %q", expDocParserID, reloadedDoc.ParserID)
				}
			}

			expDocPipelineID := tc.Expected["doc_pipeline_id"].(string)
			if expDocPipelineID != "__skip__" {
				if reloadedDoc.PipelineID == nil {
					t.Errorf("doc PipelineID should not be nil, expected %q", expDocPipelineID)
				} else if *reloadedDoc.PipelineID != expDocPipelineID {
					t.Errorf("doc_pipeline_id: expected %q, got %q", expDocPipelineID, *reloadedDoc.PipelineID)
				}
			}

			expDocRun := tc.Expected["doc_run"].(string)
			if expDocRun != "__skip__" {
				if reloadedDoc.Run == nil {
					t.Errorf("doc Run should not be nil, expected %q", expDocRun)
				} else if *reloadedDoc.Run != expDocRun {
					t.Errorf("doc_run: expected %q, got %q", expDocRun, *reloadedDoc.Run)
				}
			}

			expDocTokenNum := int64(tc.Expected["doc_token_num"].(float64))
			if reloadedDoc.TokenNum != expDocTokenNum {
				t.Errorf("doc_token_num: expected %d, got %d", expDocTokenNum, reloadedDoc.TokenNum)
			}

			expDocChunkNum := int64(tc.Expected["doc_chunk_num"].(float64))
			if reloadedDoc.ChunkNum != expDocChunkNum {
				t.Errorf("doc_chunk_num: expected %d, got %d", expDocChunkNum, reloadedDoc.ChunkNum)
			}

			expKBTokenNum := int64(tc.Expected["kb_token_num"].(float64))
			if reloadedKB.TokenNum != expKBTokenNum {
				t.Errorf("kb_token_num: expected %d, got %d", expKBTokenNum, reloadedKB.TokenNum)
			}

			expKBChunkNum := int64(tc.Expected["kb_chunk_num"].(float64))
			if reloadedKB.ChunkNum != expKBChunkNum {
				t.Errorf("kb_chunk_num: expected %d, got %d", expKBChunkNum, reloadedKB.ChunkNum)
			}
		})
	}
}
