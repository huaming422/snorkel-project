package service

import (
	"testing"

	"ragflow/internal/dao"
	"ragflow/internal/entity"
)

func TestCounterGuardValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			db := setupServiceTestDB(t)
			pushServiceDB(t, db)

			kbToken := int64(tc.Inputs["kb_token"].(float64))
			kbChunk := int64(tc.Inputs["kb_chunk"].(float64))
			docToken := int64(tc.Inputs["doc_token"].(float64))
			docChunk := int64(tc.Inputs["doc_chunk"].(float64))
			docType := tc.Inputs["doc_type"].(string)
			scenario := tc.Inputs["scenario"].(string)

			kbID := "kb-counter-1"
			insertTestKB(t, kbID, "tenant-1", 1, kbToken, kbChunk)

			// Create the document with the specified counts
			docTypeVal := "doc"
			if docType == "visual" {
				docTypeVal = "visual"
			}
			doc := &entity.Document{
				ID:           "doc-counter-1",
				KbID:         kbID,
				ParserID:     "naive",
				ParserConfig: entity.JSONMap{},
				TokenNum:     docToken,
				ChunkNum:     docChunk,
				Progress:     0,
				Name:         sptr("test.txt"),
				Suffix:       ".txt",
				Type:         docTypeVal,
				SourceType:   "local",
				CreatedBy:    "tenant-1",
				Status:       sptr("1"),
				Run:          sptr(string(entity.TaskStatusDone)),
			}
			if err := dao.DB.Create(doc).Error; err != nil {
				t.Fatalf("insert doc: %v", err)
			}

			// Construct the service offline
			svc := &DocumentService{
				documentDAO:      dao.NewDocumentDAO(),
				kbDAO:            dao.NewKnowledgebaseDAO(),
				taskDAO:          dao.NewTaskDAO(),
				file2DocumentDAO: dao.NewFile2DocumentDAO(),
				fileDAO:          dao.NewFileDAO(),
				docEngine:        nil,
				metadataSvc:      nil,
			}

			// Build the request based on the scenario
			var req *DatasetDocumentUpdateRequest
			switch scenario {
			case "counter":
				chunkCount := int64(tc.Inputs["chunk_count"].(float64))
				req = &DatasetDocumentUpdateRequest{
					HasChunkCount: true,
					ChunkCount:    &chunkCount,
				}
			case "token_counter":
				tokenCount := int64(tc.Inputs["token_count"].(float64))
				req = &DatasetDocumentUpdateRequest{
					HasTokenCount: true,
					TokenCount:    &tokenCount,
				}
			case "progress":
				progress := tc.Inputs["progress"].(float64)
				req = &DatasetDocumentUpdateRequest{
					HasProgress: true,
					Progress:    &progress,
				}
			case "visual_parser":
				parserID := tc.Inputs["parser_id"].(string)
				req = &DatasetDocumentUpdateRequest{
					HasParserID: true,
					ParserID:    sptr(parserID),
				}
			case "meta":
				metaFields := tc.Inputs["meta_fields"].(map[string]interface{})
				req = &DatasetDocumentUpdateRequest{
					HasMetaFields: true,
					MetaFields:    metaFields,
				}
			default:
				t.Fatalf("unknown scenario: %s", scenario)
			}

			_, err := svc.UpdateDatasetDocument("tenant-1", kbID, "doc-counter-1", req)

			outcome := tc.Expected["outcome"].(string)
			if outcome == "rejected" {
				if err == nil {
					t.Errorf("expected non-nil error for rejected case, scenario=%s", scenario)
				}
			} else {
				if err != nil {
					t.Errorf("expected nil error for accepted case, scenario=%s, got: %v", scenario, err)
				}
			}

			// For token_counter cases: reload and assert TokenNum is unchanged
			if scenario == "token_counter" {
				reloaded, err2 := dao.NewDocumentDAO().GetByID("doc-counter-1")
				if err2 != nil {
					t.Fatalf("failed to reload document: %v", err2)
				}
				if reloaded.TokenNum != docToken {
					t.Errorf("token_num should still be seeded value %d, got %d", docToken, reloaded.TokenNum)
				}
			}

			// For progress cases: reload and assert Progress is still zero
			if scenario == "progress" {
				reloaded, err2 := dao.NewDocumentDAO().GetByID("doc-counter-1")
				if err2 != nil {
					t.Fatalf("failed to reload document: %v", err2)
				}
				if reloaded.Progress != float64(0) {
					t.Errorf("progress should still be 0 (seeded value), got %v", reloaded.Progress)
				}
			}
		})
	}
}
