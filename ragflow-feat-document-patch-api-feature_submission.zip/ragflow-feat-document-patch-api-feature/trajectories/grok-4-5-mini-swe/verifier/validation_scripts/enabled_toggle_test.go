package service

import (
	"testing"

	"ragflow/internal/dao"
	"ragflow/internal/entity"
)

func TestEnabledToggleValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			db := setupServiceTestDB(t)
			pushServiceDB(t, db)

			initialStatus := tc.Inputs["initial_status"].(string)
			enabled := int(tc.Inputs["enabled"].(float64))

			kbID := "kb-enabled-1"
			insertTestKB(t, kbID, "tenant-1", 1, 0, 0)

			// Create document doc-1 with the given initial status
			doc := &entity.Document{
				ID:           "doc-enabled-1",
				KbID:         kbID,
				ParserID:     "naive",
				ParserConfig: entity.JSONMap{},
				TokenNum:     0,
				ChunkNum:     0,
				Name:         sptr("doc.txt"),
				Suffix:       ".txt",
				Type:         "doc",
				SourceType:   "local",
				CreatedBy:    "tenant-1",
				Status:       sptr(initialStatus),
				Run:          sptr(string(entity.TaskStatusDone)),
			}
			if err := dao.DB.Create(doc).Error; err != nil {
				t.Fatalf("insert doc: %v", err)
			}

			// Construct the service offline
			svc := &DocumentService{
				documentDAO:      dao.NewDocumentDAO(),
				kbDAO:            dao.NewKnowledgebaseDAO(),
				taskDAO:          dao.NewTaskDAO(),
				file2DocumentDAO: dao.NewFile2DocumentDAO(),
				fileDAO:          dao.NewFileDAO(),
				docEngine:        nil,
				metadataSvc:      nil,
			}

			// Invoke the update with enabled present
			_, err := svc.UpdateDatasetDocument("tenant-1", kbID, "doc-enabled-1", &DatasetDocumentUpdateRequest{
				HasEnabled: true,
				Enabled:    &enabled,
			})

			outcome := tc.Expected["outcome"].(string)
			expDocStatus := tc.Expected["doc_status"].(string)

			if outcome == "rejected" {
				if err == nil {
					t.Errorf("expected non-nil error for rejected case")
				}
			} else {
				if err != nil {
					t.Errorf("expected nil error for accepted case, got: %v", err)
				}
			}

			// Reload doc-1 and assert its status (unconditional)
			reloadedDoc, errDoc := dao.NewDocumentDAO().GetByID("doc-enabled-1")
			if errDoc != nil {
				t.Fatalf("failed to reload document: %v", errDoc)
			}
			if reloadedDoc.Status == nil {
				t.Fatal("document Status should not be nil")
			}
			if *reloadedDoc.Status != expDocStatus {
				t.Errorf("doc_status: expected %q, got %q", expDocStatus, *reloadedDoc.Status)
			}
		})
	}
}
