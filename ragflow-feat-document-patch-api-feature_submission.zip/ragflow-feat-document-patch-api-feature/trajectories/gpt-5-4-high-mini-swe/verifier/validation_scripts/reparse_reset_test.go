package service

import (
	"fmt"
	"testing"

	"ragflow/internal/dao"
	"ragflow/internal/entity"
)

func TestReparseResetValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			db := setupServiceTestDB(t)
			pushServiceDB(t, db)

			scenario := tc.Inputs["scenario"].(string)
			docToken := int64(tc.Inputs["doc_token"].(float64))
			docChunk := int64(tc.Inputs["doc_chunk"].(float64))

			// Seed KB with same token/chunk totals as the document
			insertTestKB(t, "kb-1", "tenant-1", 1, docToken, docChunk)

			// Seed fully processed document
			doc := &entity.Document{
				ID:           "doc-1",
				KbID:         "kb-1",
				ParserID:     "naive",
				ParserConfig: entity.JSONMap{},
				TokenNum:     docToken,
				ChunkNum:     docChunk,
				Progress:     1,
				Run:          sptr(string(entity.TaskStatusDone)),
				Name:         sptr("doc.pdf"),
				Suffix:       ".pdf",
				Type:         "pdf",
				CreatedBy:    "tenant-1",
				Status:       sptr("1"),
			}
			if err := dao.DB.Create(doc).Error; err != nil {
				t.Fatalf("failed to create doc: %v", err)
			}

			svc := testDocumentService(t)

			runReparseResetScenarioV2(t, svc, scenario, tc.Inputs)

			reloadedDoc, dbErr := dao.NewDocumentDAO().GetByID("doc-1")
			if dbErr != nil {
				t.Fatalf("failed to reload document: %v", dbErr)
			}

			reloadedKB, kbErr := dao.NewKnowledgebaseDAO().GetByID("kb-1")
			if kbErr != nil {
				t.Fatalf("failed to reload KB: %v", kbErr)
			}

			// EXPECTED: doc_parser_id
			expParserID := tc.Expected["doc_parser_id"].(string)
			if expParserID != "__skip__" {
				if reloadedDoc.ParserID != expParserID {
					t.Fatalf("doc_parser_id: expected %q, got %q", expParserID, reloadedDoc.ParserID)
				}
			}

			// EXPECTED: doc_pipeline_id
			expPipelineID := tc.Expected["doc_pipeline_id"].(string)
			if expPipelineID != "__skip__" {
				actualPipelineID := ""
				if reloadedDoc.PipelineID != nil {
					actualPipelineID = *reloadedDoc.PipelineID
				}
				if actualPipelineID != expPipelineID {
					t.Fatalf("doc_pipeline_id: expected %q, got %q", expPipelineID, actualPipelineID)
				}
			}

			// EXPECTED: doc_run
			expRun := tc.Expected["doc_run"].(string)
			if expRun != "__skip__" {
				actualRun := ""
				if reloadedDoc.Run != nil {
					actualRun = *reloadedDoc.Run
				}
				if actualRun != expRun {
					t.Fatalf("doc_run: expected %q, got %q", expRun, actualRun)
				}
			}

			// EXPECTED: doc_token_num
			expTokenNum := int64(tc.Expected["doc_token_num"].(float64))
			if reloadedDoc.TokenNum != expTokenNum {
				t.Fatalf("doc_token_num: expected %d, got %d", expTokenNum, reloadedDoc.TokenNum)
			}

			// EXPECTED: doc_chunk_num
			expChunkNum := int64(tc.Expected["doc_chunk_num"].(float64))
			if reloadedDoc.ChunkNum != expChunkNum {
				t.Fatalf("doc_chunk_num: expected %d, got %d", expChunkNum, reloadedDoc.ChunkNum)
			}

			// EXPECTED: kb_token_num
			expKBTokenNum := int64(tc.Expected["kb_token_num"].(float64))
			if reloadedKB.TokenNum != expKBTokenNum {
				t.Fatalf("kb_token_num: expected %d, got %d", expKBTokenNum, reloadedKB.TokenNum)
			}

			// EXPECTED: kb_chunk_num
			expKBChunkNum := int64(tc.Expected["kb_chunk_num"].(float64))
			if reloadedKB.ChunkNum != expKBChunkNum {
				t.Fatalf("kb_chunk_num: expected %d, got %d", expKBChunkNum, reloadedKB.ChunkNum)
			}
		})
	}
}

func runReparseResetScenarioV2(t *testing.T, svc *DocumentService, scenario string, inputs map[string]interface{}) {
	t.Helper()
	switch scenario {
	case "chunk_method":
		chunkMethod := inputs["chunk_method"].(string)
		reqBody := fmt.Sprintf(`{"chunk_method": %q}`, chunkMethod)
		req := mustPatchDocumentRequest(t, reqBody)
		_, _, err := svc.PatchDocument("kb-1", "doc-1", "tenant-1", req)
		if err != nil {
			t.Fatalf("PatchDocument failed: %v", err)
		}
	case "parser_id":
		parserID := inputs["parser_id"].(string)
		reqBody := fmt.Sprintf(`{"parser_id": %q}`, parserID)
		req := mustPatchDocumentRequest(t, reqBody)
		_, _, err := svc.PatchDocument("kb-1", "doc-1", "tenant-1", req)
		if err != nil {
			t.Fatalf("PatchDocument failed: %v", err)
		}
	case "precedence":
		pipelineID := inputs["pipeline_id"].(string)
		chunkMethod := inputs["chunk_method"].(string)
		reqBody := fmt.Sprintf(`{"pipeline_id": %q, "chunk_method": %q}`, pipelineID, chunkMethod)
		req := mustPatchDocumentRequest(t, reqBody)
		_, _, err := svc.PatchDocument("kb-1", "doc-1", "tenant-1", req)
		if err != nil {
			t.Fatalf("PatchDocument failed: %v", err)
		}
	case "idempotent":
		chunkMethod := inputs["chunk_method"].(string)
		reqBody := fmt.Sprintf(`{"chunk_method": %q}`, chunkMethod)
		// First call
		req1 := mustPatchDocumentRequest(t, reqBody)
		_, _, err1 := svc.PatchDocument("kb-1", "doc-1", "tenant-1", req1)
		if err1 != nil {
			t.Fatalf("first idempotent call failed: %v", err1)
		}
		// Second call (same update)
		req2 := mustPatchDocumentRequest(t, reqBody)
		_, _, err2 := svc.PatchDocument("kb-1", "doc-1", "tenant-1", req2)
		if err2 != nil {
			t.Fatalf("second idempotent call failed: %v", err2)
		}
	default:
		t.Fatalf("unknown scenario: %s", scenario)
	}
}
