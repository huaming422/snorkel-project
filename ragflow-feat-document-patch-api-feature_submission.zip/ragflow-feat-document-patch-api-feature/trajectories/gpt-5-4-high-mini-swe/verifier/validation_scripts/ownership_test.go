package service

import (
	"fmt"
	"path/filepath"
	"testing"

	"ragflow/internal/dao"
	"ragflow/internal/entity"
)

func TestOwnershipValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			db := setupServiceTestDB(t)
			pushServiceDB(t, db)

			ownerTenant := tc.Inputs["owner_tenant"].(string)
			actorTenant := tc.Inputs["actor_tenant"].(string)
			docName := tc.Inputs["doc_name"].(string)
			attemptedName := tc.Inputs["attempted_name"].(string)
			expectedOutcome := tc.Expected["outcome"].(string)
			expectedDocName := tc.Expected["final_doc_name"].(string)

			suffix := filepath.Ext(docName)

			insertTestKB(t, "kb-1", ownerTenant, 1, 0, 0)

			doc := &entity.Document{
				ID:           "doc-1",
				KbID:         "kb-1",
				ParserID:     "naive",
				ParserConfig: entity.JSONMap{},
				Name:         sptr(docName),
				Suffix:       suffix,
				Type:         "pdf",
				CreatedBy:    ownerTenant,
				Status:       sptr("1"),
			}
			if err := dao.DB.Create(doc).Error; err != nil {
				t.Fatalf("failed to create doc: %v", err)
			}

			svc := testDocumentService(t)
			reqBody := fmt.Sprintf(`{"name": %q}`, attemptedName)
			req := mustPatchDocumentRequest(t, reqBody)

			_, _, err := svc.PatchDocument("kb-1", "doc-1", actorTenant, req)

			if expectedOutcome == "rejected" {
				if err == nil {
					t.Fatalf("expected rejected outcome (non-nil error), but got nil error")
				}
			} else {
				if err != nil {
					t.Fatalf("expected accepted outcome (nil error), but got error: %v", err)
				}
			}

			reloaded, dbErr := dao.NewDocumentDAO().GetByID("doc-1")
			if dbErr != nil {
				t.Fatalf("failed to reload document: %v", dbErr)
			}
			actualName := ""
			if reloaded.Name != nil {
				actualName = *reloaded.Name
			}
			if actualName != expectedDocName {
				t.Fatalf("final_doc_name: expected %q, got %q", expectedDocName, actualName)
			}
		})
	}
}
