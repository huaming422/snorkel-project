package service

import (
	"fmt"
	"testing"

	"ragflow/internal/dao"
	"ragflow/internal/entity"
)

func TestEnabledToggleValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			db := setupServiceTestDB(t)
			pushServiceDB(t, db)

			initialStatus := tc.Inputs["initial_status"].(string)
			enabledVal := int(tc.Inputs["enabled"].(float64))
			expectedOutcome := tc.Expected["outcome"].(string)
			expectedDocStatus := tc.Expected["doc_status"].(string)

			insertTestKB(t, "kb-1", "tenant-1", 1, 0, 0)

			doc := &entity.Document{
				ID:           "doc-1",
				KbID:         "kb-1",
				ParserID:     "naive",
				ParserConfig: entity.JSONMap{},
				Name:         sptr("doc.pdf"),
				Suffix:       ".pdf",
				Type:         "pdf",
				CreatedBy:    "tenant-1",
				Status:       sptr(initialStatus),
			}
			if err := dao.DB.Create(doc).Error; err != nil {
				t.Fatalf("failed to create doc: %v", err)
			}

			svc := testDocumentService(t)
			reqBody := fmt.Sprintf(`{"enabled": %d}`, enabledVal)
			req := mustPatchDocumentRequest(t, reqBody)

			_, _, err := svc.PatchDocument("kb-1", "doc-1", "tenant-1", req)

			if expectedOutcome == "accepted" {
				if err != nil {
					t.Fatalf("expected accepted outcome (nil error), but got error: %v", err)
				}
			} else {
				if err == nil {
					t.Fatalf("expected rejected outcome (non-nil error), but got nil error")
				}
			}

			reloaded, dbErr := dao.NewDocumentDAO().GetByID("doc-1")
			if dbErr != nil {
				t.Fatalf("failed to reload document: %v", dbErr)
			}

			actualStatus := ""
			if reloaded.Status != nil {
				actualStatus = *reloaded.Status
			}
			if actualStatus != expectedDocStatus {
				t.Fatalf("doc_status: expected %q, got %q", expectedDocStatus, actualStatus)
			}
		})
	}
}
