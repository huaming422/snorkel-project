package service

import (
	"encoding/json"
	"fmt"
	"testing"

	"ragflow/internal/dao"
	"ragflow/internal/entity"
)

func TestParserConfigMergeValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			db := setupServiceTestDB(t)
			pushServiceDB(t, db)

			initialConfig := tc.Inputs["initial_config"].(map[string]interface{})
			sentConfig := tc.Inputs["sent_config"].(map[string]interface{})

			insertTestKB(t, "kb-1", "tenant-1", 1, 0, 0)

			doc := &entity.Document{
				ID:           "doc-1",
				KbID:         "kb-1",
				ParserID:     "naive",
				ParserConfig: entity.JSONMap(initialConfig),
				Name:         sptr("doc.pdf"),
				Suffix:       ".pdf",
				Type:         "pdf",
				CreatedBy:    "tenant-1",
				Status:       sptr("1"),
			}
			if err := dao.DB.Create(doc).Error; err != nil {
				t.Fatalf("failed to create doc: %v", err)
			}

			svc := testDocumentService(t)

			sentConfigJSON, err := json.Marshal(sentConfig)
			if err != nil {
				t.Fatalf("failed to marshal sent_config: %v", err)
			}
			reqBody := fmt.Sprintf(`{"parser_config": %s}`, string(sentConfigJSON))
			req := mustPatchDocumentRequest(t, reqBody)

			_, _, err = svc.PatchDocument("kb-1", "doc-1", "tenant-1", req)
			if err != nil {
				t.Fatalf("PatchDocument failed: %v", err)
			}

			reloaded, dbErr := dao.NewDocumentDAO().GetByID("doc-1")
			if dbErr != nil {
				t.Fatalf("failed to reload document: %v", dbErr)
			}

			mergedConfig := map[string]interface{}(reloaded.ParserConfig)

			// EXPECTED: chunk_token_num
			expChunkTokenNum := tc.Expected["chunk_token_num"].(float64)
			actualChunkTokenNumRaw, ok := mergedConfig["chunk_token_num"]
			if !ok {
				t.Fatalf("chunk_token_num key missing from merged config")
			}
			var actualFloat float64
			switch v := actualChunkTokenNumRaw.(type) {
			case float64:
				actualFloat = v
			case int64:
				actualFloat = float64(v)
			case int:
				actualFloat = float64(v)
			default:
				t.Fatalf("chunk_token_num has unexpected type %T: %v", actualChunkTokenNumRaw, actualChunkTokenNumRaw)
			}
			if actualFloat != expChunkTokenNum {
				t.Fatalf("chunk_token_num: expected %v, got %v", expChunkTokenNum, actualFloat)
			}

			// EXPECTED: raptor_state
			expRaptorState := tc.Expected["raptor_state"].(string)
			_, hasRaptor := mergedConfig["raptor"]
			if expRaptorState == "absent" {
				if hasRaptor {
					t.Fatalf("raptor key should be absent from merged config, but it's present: %v", mergedConfig["raptor"])
				}
			} else if expRaptorState == "present" {
				if !hasRaptor {
					t.Fatalf("raptor key should be present in merged config, but it's absent")
				}
			}

			// EXPECTED: extra_key / extra_val
			expExtraKey := tc.Expected["extra_key"].(string)
			expExtraVal := tc.Expected["extra_val"].(string)
			if expExtraKey != "__skip__" {
				actualVal, hasKey := mergedConfig[expExtraKey]
				if !hasKey {
					t.Fatalf("extra_key %q missing from merged config", expExtraKey)
				}
				actualValStr, isStr := actualVal.(string)
				if !isStr {
					t.Fatalf("extra_key %q value should be string, got %T: %v", expExtraKey, actualVal, actualVal)
				}
				if actualValStr != expExtraVal {
					t.Fatalf("extra_val for key %q: expected %q, got %q", expExtraKey, expExtraVal, actualValStr)
				}
			}
		})
	}
}
