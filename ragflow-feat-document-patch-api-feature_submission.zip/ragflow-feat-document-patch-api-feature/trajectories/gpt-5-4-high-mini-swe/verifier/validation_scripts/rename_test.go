package service

import (
	"fmt"
	"path/filepath"
	"testing"

	"ragflow/internal/dao"
	"ragflow/internal/entity"
)

func TestRenameValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			db := setupServiceTestDB(t)
			pushServiceDB(t, db)

			docName := tc.Inputs["doc_name"].(string)
			newName := tc.Inputs["new_name"].(string)
			otherName := tc.Inputs["other_name"].(string)
			expectedOutcome := tc.Expected["outcome"].(string)
			expectedDocName := tc.Expected["document_name"].(string)
			expectedFileName := tc.Expected["file_name"].(string)

			suffix := filepath.Ext(docName)

			insertTestKB(t, "kb-1", "tenant-1", 1, 0, 0)

			// Create target document doc-1
			doc := &entity.Document{
				ID:           "doc-1",
				KbID:         "kb-1",
				ParserID:     "naive",
				ParserConfig: entity.JSONMap{},
				Name:         sptr(docName),
				Suffix:       suffix,
				Type:         "pdf",
				CreatedBy:    "tenant-1",
				Status:       sptr("1"),
			}
			if err := dao.DB.Create(doc).Error; err != nil {
				t.Fatalf("failed to create doc: %v", err)
			}

			// Create linked file file-1
			insertTestFile(t, "file-1", "kb-1", docName, nil)

			// Link file to document
			insertTestFile2Document(t, "f2d-1", "file-1", "doc-1")

			// If other_name is set, create a second document (for collision test)
			if otherName != "" {
				otherSuffix := filepath.Ext(otherName)
				otherDoc := &entity.Document{
					ID:           "doc-2",
					KbID:         "kb-1",
					ParserID:     "naive",
					ParserConfig: entity.JSONMap{},
					Name:         sptr(otherName),
					Suffix:       otherSuffix,
					Type:         "pdf",
					CreatedBy:    "tenant-1",
					Status:       sptr("1"),
				}
				if err := dao.DB.Create(otherDoc).Error; err != nil {
					t.Fatalf("failed to create other doc: %v", err)
				}
			}

			svc := testDocumentService(t)
			reqBody := fmt.Sprintf(`{"name": %q}`, newName)
			req := mustPatchDocumentRequest(t, reqBody)

			_, _, err := svc.PatchDocument("kb-1", "doc-1", "tenant-1", req)

			if expectedOutcome == "accepted" {
				if err != nil {
					t.Fatalf("expected accepted outcome (nil error), but got error: %v", err)
				}
			} else {
				if err == nil {
					t.Fatalf("expected rejected outcome (non-nil error), but got nil error")
				}
			}

			// Reload doc-1 and assert document name
			reloadedDoc, dbErr := dao.NewDocumentDAO().GetByID("doc-1")
			if dbErr != nil {
				t.Fatalf("failed to reload document: %v", dbErr)
			}
			actualDocName := ""
			if reloadedDoc.Name != nil {
				actualDocName = *reloadedDoc.Name
			}
			if actualDocName != expectedDocName {
				t.Fatalf("document_name: expected %q, got %q", expectedDocName, actualDocName)
			}

			// Reload file-1 and assert file name
			reloadedFile, fileErr := dao.NewFileDAO().GetByID("file-1")
			if fileErr != nil {
				t.Fatalf("failed to reload file: %v", fileErr)
			}
			if reloadedFile.Name != expectedFileName {
				t.Fatalf("file_name: expected %q, got %q", expectedFileName, reloadedFile.Name)
			}
		})
	}
}
