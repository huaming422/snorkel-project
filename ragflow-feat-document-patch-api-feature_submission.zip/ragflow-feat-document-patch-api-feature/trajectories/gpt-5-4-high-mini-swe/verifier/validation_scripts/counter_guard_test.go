package service

import (
	"encoding/json"
	"fmt"
	"testing"

	"ragflow/internal/dao"
	"ragflow/internal/entity"
	"ragflow/internal/utility"
)

func TestCounterGuardValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			db := setupServiceTestDB(t)
			pushServiceDB(t, db)

			kbToken := int64(tc.Inputs["kb_token"].(float64))
			kbChunk := int64(tc.Inputs["kb_chunk"].(float64))
			docToken := int64(tc.Inputs["doc_token"].(float64))
			docChunk := int64(tc.Inputs["doc_chunk"].(float64))
			docType := tc.Inputs["doc_type"].(string)
			scenario := tc.Inputs["scenario"].(string)
			expectedOutcome := tc.Expected["outcome"].(string)

			insertTestKB(t, "kb-1", "tenant-1", 1, kbToken, kbChunk)

			docEntityType := "pdf"
			if docType == "visual" {
				docEntityType = string(utility.FileTypeVISUAL)
			}

			doc := &entity.Document{
				ID:           "doc-1",
				KbID:         "kb-1",
				ParserID:     "naive",
				ParserConfig: entity.JSONMap{},
				TokenNum:     docToken,
				ChunkNum:     docChunk,
				Type:         docEntityType,
				CreatedBy:    "tenant-1",
				Name:         sptr("test.pdf"),
				Suffix:       ".pdf",
				Status:       sptr("1"),
			}
			if err := dao.DB.Create(doc).Error; err != nil {
				t.Fatalf("failed to create doc: %v", err)
			}

			svc := testDocumentService(t)

			var req *PatchDocumentRequest
			switch scenario {
			case "counter":
				chunkCount := int64(tc.Inputs["chunk_count"].(float64))
				reqBody := fmt.Sprintf(`{"chunk_count": %d}`, chunkCount)
				req = mustPatchDocumentRequest(t, reqBody)
			case "token_counter":
				tokenCount := int64(tc.Inputs["token_count"].(float64))
				reqBody := fmt.Sprintf(`{"token_count": %d}`, tokenCount)
				req = mustPatchDocumentRequest(t, reqBody)
			case "progress":
				progress := tc.Inputs["progress"].(float64)
				reqBody := fmt.Sprintf(`{"progress": %v}`, progress)
				req = mustPatchDocumentRequest(t, reqBody)
			case "visual_parser":
				parserID := tc.Inputs["parser_id"].(string)
				reqBody := fmt.Sprintf(`{"parser_id": %q}`, parserID)
				req = mustPatchDocumentRequest(t, reqBody)
			case "meta":
				metaFields := tc.Inputs["meta_fields"].(map[string]interface{})
				metaJSON, err := json.Marshal(metaFields)
				if err != nil {
					t.Fatalf("failed to marshal meta_fields: %v", err)
				}
				reqBody := fmt.Sprintf(`{"meta_fields": %s}`, string(metaJSON))
				req = mustPatchDocumentRequest(t, reqBody)
			default:
				t.Fatalf("unknown scenario: %s", scenario)
			}

			_, _, err := svc.PatchDocument("kb-1", "doc-1", "tenant-1", req)

			if expectedOutcome == "rejected" {
				if err == nil {
					t.Fatalf("expected rejected outcome (non-nil error), but got nil error")
				}
			} else {
				if err != nil {
					t.Fatalf("expected accepted outcome (nil error), but got error: %v", err)
				}
			}

			// For token_counter case: assert stored TokenNum unchanged
			if scenario == "token_counter" {
				reloaded, dbErr := dao.NewDocumentDAO().GetByID("doc-1")
				if dbErr != nil {
					t.Fatalf("failed to reload document: %v", dbErr)
				}
				if reloaded.TokenNum != docToken {
					t.Fatalf("token_num should remain %d (system-maintained), got %d", docToken, reloaded.TokenNum)
				}
			}

			// For progress case: assert stored Progress unchanged (seeded at 0)
			if scenario == "progress" {
				reloaded, dbErr := dao.NewDocumentDAO().GetByID("doc-1")
				if dbErr != nil {
					t.Fatalf("failed to reload document: %v", dbErr)
				}
				if reloaded.Progress != float64(0) {
					t.Fatalf("progress should remain 0 (seeded value), got %v", reloaded.Progress)
				}
			}
		})
	}
}
