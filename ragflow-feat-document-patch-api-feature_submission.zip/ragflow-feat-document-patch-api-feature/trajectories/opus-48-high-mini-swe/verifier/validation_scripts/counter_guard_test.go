package service

import (
	"testing"

	"ragflow/internal/dao"
	"ragflow/internal/entity"
)

func TestCounterGuard(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			db := setupServiceTestDB(t)
			pushServiceDB(t, db)

			kbToken := int64(tc.Inputs["kb_token"].(float64))
			kbChunk := int64(tc.Inputs["kb_chunk"].(float64))
			docToken := int64(tc.Inputs["doc_token"].(float64))
			docChunk := int64(tc.Inputs["doc_chunk"].(float64))
			docType := tc.Inputs["doc_type"].(string)
			scenario := tc.Inputs["scenario"].(string)

			// Seed KB: insertTestKB(t, id, tenantID, docNum, tokenNum, chunkNum)
			insertTestKB(t, "kb-cg-1", "tenant-1", 1, kbToken, kbChunk)

			// Create document
			docTypeVal := "doc"
			if docType == "visual" {
				docTypeVal = "visual"
			}
			doc := &entity.Document{
				ID:           "doc-cg-1",
				KbID:         "kb-cg-1",
				ParserID:     "naive",
				ParserConfig: entity.JSONMap{},
				TokenNum:     docToken,
				ChunkNum:     docChunk,
				Progress:     0,
				Name:         sptr("test.txt"),
				Suffix:       ".txt",
				Type:         docTypeVal,
				SourceType:   "local",
				CreatedBy:    "tenant-1",
				Status:       sptr("1"),
				Run:          sptr(string(entity.TaskStatusDone)),
			}
			if err := dao.DB.Create(doc).Error; err != nil {
				t.Fatalf("failed to create document: %v", err)
			}

			// Construct service offline
			s := &DocumentService{
				documentDAO:      dao.NewDocumentDAO(),
				kbDAO:            dao.NewKnowledgebaseDAO(),
				taskDAO:          dao.NewTaskDAO(),
				file2DocumentDAO: dao.NewFile2DocumentDAO(),
				docEngine:        nil,
				metadataSvc:      nil,
			}

			// Build fields based on scenario
			var fields map[string]interface{}
			switch scenario {
			case "counter":
				chunkCount := int64(tc.Inputs["chunk_count"].(float64))
				fields = map[string]interface{}{
					"chunk_count": float64(chunkCount),
				}
			case "token_counter":
				tokenCount := int64(tc.Inputs["token_count"].(float64))
				fields = map[string]interface{}{
					"token_count": float64(tokenCount),
				}
			case "progress":
				progress := tc.Inputs["progress"].(float64)
				fields = map[string]interface{}{
					"progress": progress,
				}
			case "visual_parser":
				parserID := tc.Inputs["parser_id"].(string)
				fields = map[string]interface{}{
					"parser_id": parserID,
				}
			case "meta":
				metaFields := tc.Inputs["meta_fields"].(map[string]interface{})
				fields = map[string]interface{}{
					"meta_fields": metaFields,
				}
			}

			_, err := s.PatchDocument("kb-cg-1", "doc-cg-1", "tenant-1", fields)

			outcome := tc.Expected["outcome"].(string)
			if outcome == "rejected" {
				if err == nil {
					t.Errorf("expected non-nil error for rejected outcome, got nil")
				}
			} else {
				if err != nil {
					t.Errorf("expected nil error for accepted outcome, got: %v", err)
				}
			}

			// For token_counter case, assert TokenNum unchanged
			reloaded, err2 := dao.NewDocumentDAO().GetByID("doc-cg-1")
			if err2 != nil {
				t.Fatalf("failed to reload document: %v", err2)
			}

			if scenario == "token_counter" {
				if reloaded.TokenNum != docToken {
					t.Errorf("token_num should be unchanged: expected %d got %d", docToken, reloaded.TokenNum)
				}
			}

			// For progress case, assert Progress unchanged (still zero)
			if scenario == "progress" {
				if reloaded.Progress != float64(0) {
					t.Errorf("progress should be unchanged: expected 0 got %v", reloaded.Progress)
				}
			}
		})
	}
}
