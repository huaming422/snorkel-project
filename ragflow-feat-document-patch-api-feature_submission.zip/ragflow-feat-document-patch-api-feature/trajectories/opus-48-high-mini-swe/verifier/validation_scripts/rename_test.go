package service

import (
	"path/filepath"
	"testing"

	"ragflow/internal/dao"
	"ragflow/internal/entity"
)

func TestRename(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			db := setupServiceTestDB(t)
			pushServiceDB(t, db)

			docName := tc.Inputs["doc_name"].(string)
			newName := tc.Inputs["new_name"].(string)
			otherName := tc.Inputs["other_name"].(string)

			// Seed KB owned by tenant-1
			insertTestKB(t, "kb-ren-1", "tenant-1", 1, 0, 0)

			// Extract suffix from docName
			suffix := filepath.Ext(docName)
			if suffix == "" {
				suffix = ".txt"
			}

			// Create target document doc-1
			doc := &entity.Document{
				ID:           "doc-ren-1",
				KbID:         "kb-ren-1",
				ParserID:     "naive",
				ParserConfig: entity.JSONMap{},
				Name:         sptr(docName),
				Suffix:       suffix,
				Type:         "doc",
				SourceType:   "local",
				CreatedBy:    "tenant-1",
				Status:       sptr("1"),
				Run:          sptr(string(entity.TaskStatusDone)),
			}
			if err := dao.DB.Create(doc).Error; err != nil {
				t.Fatalf("failed to create document: %v", err)
			}

			// Create linked file row file-1
			loc := "location/" + docName
			insertTestFile(t, "file-ren-1", "kb-ren-1", docName, &loc)

			// Create file->document link
			insertTestFile2Document(t, "f2d-ren-1", "file-ren-1", "doc-ren-1")

			// If other_name is not empty, create a second document for collision
			if otherName != "" {
				otherSuffix := filepath.Ext(otherName)
				if otherSuffix == "" {
					otherSuffix = ".txt"
				}
				doc2 := &entity.Document{
					ID:           "doc-ren-2",
					KbID:         "kb-ren-1",
					ParserID:     "naive",
					ParserConfig: entity.JSONMap{},
					Name:         sptr(otherName),
					Suffix:       otherSuffix,
					Type:         "doc",
					SourceType:   "local",
					CreatedBy:    "tenant-1",
					Status:       sptr("1"),
					Run:          sptr(string(entity.TaskStatusDone)),
				}
				if err := dao.DB.Create(doc2).Error; err != nil {
					t.Fatalf("failed to create second document: %v", err)
				}
			}

			// Construct service offline
			s := &DocumentService{
				documentDAO:      dao.NewDocumentDAO(),
				kbDAO:            dao.NewKnowledgebaseDAO(),
				taskDAO:          dao.NewTaskDAO(),
				file2DocumentDAO: dao.NewFile2DocumentDAO(),
				docEngine:        nil,
				metadataSvc:      nil,
			}

			// Invoke update
			_, err := s.PatchDocument("kb-ren-1", "doc-ren-1", "tenant-1", map[string]interface{}{
				"name": newName,
			})

			outcome := tc.Expected["outcome"].(string)
			expectedDocName := tc.Expected["document_name"].(string)
			expectedFileName := tc.Expected["file_name"].(string)

			if outcome == "accepted" {
				if err != nil {
					t.Errorf("expected nil error for accepted outcome, got: %v", err)
				}
			} else {
				if err == nil {
					t.Errorf("expected non-nil error for rejected outcome, got nil")
				}
			}

			// Reload doc-1 and assert document_name
			reloadedDoc, err2 := dao.NewDocumentDAO().GetByID("doc-ren-1")
			if err2 != nil {
				t.Fatalf("failed to reload document: %v", err2)
			}
			if reloadedDoc.Name == nil {
				t.Fatal("document name should not be nil")
			}
			if *reloadedDoc.Name != expectedDocName {
				t.Errorf("document_name mismatch: expected %s got %s", expectedDocName, *reloadedDoc.Name)
			}

			// Reload file-1 and assert file_name
			reloadedFile, err3 := dao.NewFileDAO().GetByID("file-ren-1")
			if err3 != nil {
				t.Fatalf("failed to reload file: %v", err3)
			}
			if reloadedFile.Name != expectedFileName {
				t.Errorf("file_name mismatch: expected %s got %s", expectedFileName, reloadedFile.Name)
			}
		})
	}
}
