package service

import (
	"testing"

	"ragflow/internal/dao"
	"ragflow/internal/entity"
)

func TestParserConfigMerge(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			db := setupServiceTestDB(t)
			pushServiceDB(t, db)

			initialConfig := tc.Inputs["initial_config"].(map[string]interface{})
			sentConfig := tc.Inputs["sent_config"].(map[string]interface{})

			// Seed KB owned by tenant-1
			insertTestKB(t, "kb-pcm-1", "tenant-1", 1, 0, 0)

			// Create document with stored ParserConfig
			doc := &entity.Document{
				ID:           "doc-pcm-1",
				KbID:         "kb-pcm-1",
				ParserID:     "naive",
				ParserConfig: entity.JSONMap(initialConfig),
				Name:         sptr("test.txt"),
				Suffix:       ".txt",
				Type:         "doc",
				SourceType:   "local",
				CreatedBy:    "tenant-1",
				Status:       sptr("1"),
				Run:          sptr(string(entity.TaskStatusDone)),
			}
			if err := dao.DB.Create(doc).Error; err != nil {
				t.Fatalf("failed to create document: %v", err)
			}

			// Construct service offline
			s := &DocumentService{
				documentDAO:      dao.NewDocumentDAO(),
				kbDAO:            dao.NewKnowledgebaseDAO(),
				taskDAO:          dao.NewTaskDAO(),
				file2DocumentDAO: dao.NewFile2DocumentDAO(),
				docEngine:        nil,
				metadataSvc:      nil,
			}

			// Invoke update with ONLY parser_config present
			_, err := s.PatchDocument("kb-pcm-1", "doc-pcm-1", "tenant-1", map[string]interface{}{
				"parser_config": sentConfig,
			})
			if err != nil {
				t.Fatalf("parser_config update should succeed, got: %v", err)
			}

			// Reload doc and read ParserConfig
			reloadedDoc, err2 := dao.NewDocumentDAO().GetByID("doc-pcm-1")
			if err2 != nil {
				t.Fatalf("failed to reload document: %v", err2)
			}
			mergedCfg := map[string]interface{}(reloadedDoc.ParserConfig)

			// Assert chunk_token_num
			expectedChunkTokenNum := tc.Expected["chunk_token_num"].(float64)
			actualChunkTokenNum, ok := mergedCfg["chunk_token_num"]
			if !ok {
				t.Errorf("chunk_token_num should exist in merged config")
			} else if actualChunkTokenNum != expectedChunkTokenNum {
				t.Errorf("chunk_token_num mismatch: expected %v got %v", expectedChunkTokenNum, actualChunkTokenNum)
			}

			// Assert raptor_state
			raptorState := tc.Expected["raptor_state"].(string)
			_, hasRaptor := mergedCfg["raptor"]
			if raptorState == "absent" {
				if hasRaptor {
					t.Errorf("raptor key should be absent from merged config, but found it")
				}
			} else {
				if !hasRaptor {
					t.Errorf("raptor key should be present in merged config, but not found")
				}
			}

			// Assert extra_key / extra_val (skip if "__skip__")
			extraKey := tc.Expected["extra_key"].(string)
			extraVal := tc.Expected["extra_val"].(string)
			if extraKey != "__skip__" {
				actualVal, exists := mergedCfg[extraKey]
				if !exists {
					t.Errorf("extra_key %s should exist in merged config", extraKey)
				} else if actualVal != extraVal {
					t.Errorf("extra_val mismatch for key %s: expected %s got %v", extraKey, extraVal, actualVal)
				}
			}
		})
	}
}
