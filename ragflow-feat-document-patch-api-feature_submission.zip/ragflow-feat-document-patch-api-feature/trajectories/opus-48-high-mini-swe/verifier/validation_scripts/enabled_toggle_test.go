package service

import (
	"testing"

	"ragflow/internal/dao"
	"ragflow/internal/entity"
)

func TestEnabledToggle(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			db := setupServiceTestDB(t)
			pushServiceDB(t, db)

			initialStatus := tc.Inputs["initial_status"].(string)
			enabled := int(tc.Inputs["enabled"].(float64))

			// Seed KB owned by tenant-1
			insertTestKB(t, "kb-et-1", "tenant-1", 1, 0, 0)

			// Create document with stored Status
			doc := &entity.Document{
				ID:           "doc-et-1",
				KbID:         "kb-et-1",
				ParserID:     "naive",
				ParserConfig: entity.JSONMap{},
				Name:         sptr("test.txt"),
				Suffix:       ".txt",
				Type:         "doc",
				SourceType:   "local",
				CreatedBy:    "tenant-1",
				Status:       sptr(initialStatus),
				Run:          sptr(string(entity.TaskStatusDone)),
			}
			if err := dao.DB.Create(doc).Error; err != nil {
				t.Fatalf("failed to create document: %v", err)
			}

			// Construct service offline
			s := &DocumentService{
				documentDAO:      dao.NewDocumentDAO(),
				kbDAO:            dao.NewKnowledgebaseDAO(),
				taskDAO:          dao.NewTaskDAO(),
				file2DocumentDAO: dao.NewFile2DocumentDAO(),
				docEngine:        nil,
				metadataSvc:      nil,
			}

			// Invoke update with enabled field
			_, err := s.PatchDocument("kb-et-1", "doc-et-1", "tenant-1", map[string]interface{}{
				"enabled": float64(enabled),
			})

			outcome := tc.Expected["outcome"].(string)
			expectedDocStatus := tc.Expected["doc_status"].(string)

			if outcome == "accepted" {
				if err != nil {
					t.Errorf("expected nil error for accepted outcome, got: %v", err)
				}
			} else {
				if err == nil {
					t.Errorf("expected non-nil error for rejected outcome, got nil")
				}
			}

			// Reload doc and assert doc_status
			reloadedDoc, err2 := dao.NewDocumentDAO().GetByID("doc-et-1")
			if err2 != nil {
				t.Fatalf("failed to reload document: %v", err2)
			}
			if reloadedDoc.Status == nil {
				t.Fatal("document status should not be nil")
			}
			if *reloadedDoc.Status != expectedDocStatus {
				t.Errorf("doc_status mismatch: expected %s got %s", expectedDocStatus, *reloadedDoc.Status)
			}
		})
	}
}
