package service

import (
	"testing"

	"ragflow/internal/dao"
	"ragflow/internal/entity"
)

func TestOwnership(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			db := setupServiceTestDB(t)
			pushServiceDB(t, db)

			ownerTenant := tc.Inputs["owner_tenant"].(string)
			docName := tc.Inputs["doc_name"].(string)
			actorTenant := tc.Inputs["actor_tenant"].(string)
			attemptedName := tc.Inputs["attempted_name"].(string)

			// Seed KB owned by owner_tenant
			insertTestKB(t, "kb-own-1", ownerTenant, 1, 0, 0)

			// Extract suffix from docName
			suffix := ".pdf"
			for i := len(docName) - 1; i >= 0; i-- {
				if docName[i] == '.' {
					suffix = docName[i:]
					break
				}
			}

			// Create document with known name and matching suffix
			doc := &entity.Document{
				ID:           "doc-own-1",
				KbID:         "kb-own-1",
				ParserID:     "naive",
				ParserConfig: entity.JSONMap{},
				Name:         sptr(docName),
				Suffix:       suffix,
				Type:         "doc",
				SourceType:   "local",
				CreatedBy:    ownerTenant,
				Status:       sptr("1"),
				Run:          sptr(string(entity.TaskStatusDone)),
			}
			if err := dao.DB.Create(doc).Error; err != nil {
				t.Fatalf("failed to create document: %v", err)
			}

			// Construct service offline
			s := &DocumentService{
				documentDAO:      dao.NewDocumentDAO(),
				kbDAO:            dao.NewKnowledgebaseDAO(),
				taskDAO:          dao.NewTaskDAO(),
				file2DocumentDAO: dao.NewFile2DocumentDAO(),
				docEngine:        nil,
				metadataSvc:      nil,
			}

			// Invoke update as actor_tenant
			_, err := s.PatchDocument("kb-own-1", "doc-own-1", actorTenant, map[string]interface{}{
				"name": attemptedName,
			})

			outcome := tc.Expected["outcome"].(string)
			finalDocName := tc.Expected["final_doc_name"].(string)

			if outcome == "rejected" {
				if err == nil {
					t.Errorf("expected non-nil error for rejected outcome, got nil")
				}
			} else {
				if err != nil {
					t.Errorf("expected nil error for accepted outcome, got: %v", err)
				}
			}

			// Reload and assert final doc name
			reloaded, err2 := dao.NewDocumentDAO().GetByID("doc-own-1")
			if err2 != nil {
				t.Fatalf("failed to reload document: %v", err2)
			}
			if reloaded.Name == nil {
				t.Fatal("document name should not be nil")
			}
			if *reloaded.Name != finalDocName {
				t.Errorf("final_doc_name mismatch: expected %s got %s", finalDocName, *reloaded.Name)
			}
		})
	}
}
