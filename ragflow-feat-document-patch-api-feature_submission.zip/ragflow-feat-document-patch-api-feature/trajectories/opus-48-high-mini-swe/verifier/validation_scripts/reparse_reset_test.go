package service

import (
	"testing"

	"ragflow/internal/dao"
	"ragflow/internal/entity"
)

func TestReparseReset(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			db := setupServiceTestDB(t)
			pushServiceDB(t, db)

			docToken := int64(tc.Inputs["doc_token"].(float64))
			docChunk := int64(tc.Inputs["doc_chunk"].(float64))
			scenario := tc.Inputs["scenario"].(string)

			// Seed KB with matching token/chunk counts so a correct single decrement lands at zero
			// insertTestKB(t, id, tenantID, docNum, tokenNum, chunkNum)
			insertTestKB(t, "kb-rp-1", "tenant-1", 1, docToken, docChunk)

			// Create a fully processed document
			doc := &entity.Document{
				ID:           "doc-rp-1",
				KbID:         "kb-rp-1",
				ParserID:     "naive",
				ParserConfig: entity.JSONMap{},
				TokenNum:     docToken,
				ChunkNum:     docChunk,
				Progress:     1,
				Name:         sptr("test.txt"),
				Suffix:       ".txt",
				Type:         "doc",
				SourceType:   "local",
				CreatedBy:    "tenant-1",
				Status:       sptr("1"),
				Run:          sptr(string(entity.TaskStatusDone)),
			}
			if err := dao.DB.Create(doc).Error; err != nil {
				t.Fatalf("failed to create document: %v", err)
			}

			// Construct service offline
			s := &DocumentService{
				documentDAO:      dao.NewDocumentDAO(),
				kbDAO:            dao.NewKnowledgebaseDAO(),
				taskDAO:          dao.NewTaskDAO(),
				file2DocumentDAO: dao.NewFile2DocumentDAO(),
				docEngine:        nil,
				metadataSvc:      nil,
			}

			// Build fields based on scenario and invoke
			switch scenario {
			case "chunk_method":
				chunkMethod := tc.Inputs["chunk_method"].(string)
				_, err := s.PatchDocument("kb-rp-1", "doc-rp-1", "tenant-1", map[string]interface{}{
					"chunk_method": chunkMethod,
				})
				if err != nil {
					t.Errorf("chunk_method update should succeed, got: %v", err)
				}

			case "parser_id":
				parserID := tc.Inputs["parser_id"].(string)
				_, err := s.PatchDocument("kb-rp-1", "doc-rp-1", "tenant-1", map[string]interface{}{
					"parser_id": parserID,
				})
				if err != nil {
					t.Errorf("parser_id update should succeed, got: %v", err)
				}

			case "precedence":
				pipelineID := tc.Inputs["pipeline_id"].(string)
				chunkMethod := tc.Inputs["chunk_method"].(string)
				_, err := s.PatchDocument("kb-rp-1", "doc-rp-1", "tenant-1", map[string]interface{}{
					"pipeline_id":  pipelineID,
					"chunk_method": chunkMethod,
				})
				if err != nil {
					t.Errorf("precedence update should succeed, got: %v", err)
				}

			case "idempotent":
				chunkMethod := tc.Inputs["chunk_method"].(string)
				_, err := s.PatchDocument("kb-rp-1", "doc-rp-1", "tenant-1", map[string]interface{}{
					"chunk_method": chunkMethod,
				})
				if err != nil {
					t.Errorf("first idempotent update should succeed, got: %v", err)
				}
				// Second invocation — simulating a repeated reset
				_, err2 := s.PatchDocument("kb-rp-1", "doc-rp-1", "tenant-1", map[string]interface{}{
					"chunk_method": chunkMethod,
				})
				if err2 != nil {
					t.Errorf("second idempotent update should succeed, got: %v", err2)
				}
			}

			// Reload doc and KB
			reloadedDoc, err := dao.NewDocumentDAO().GetByID("doc-rp-1")
			if err != nil {
				t.Fatalf("failed to reload document: %v", err)
			}
			reloadedKB, err := dao.NewKnowledgebaseDAO().GetByID("kb-rp-1")
			if err != nil {
				t.Fatalf("failed to reload KB: %v", err)
			}

			// Assert doc_parser_id (skip "__skip__")
			docParserID := tc.Expected["doc_parser_id"].(string)
			if docParserID != "__skip__" {
				if reloadedDoc.ParserID != docParserID {
					t.Errorf("doc_parser_id mismatch: expected %s got %s", docParserID, reloadedDoc.ParserID)
				}
			}

			// Assert doc_pipeline_id (skip "__skip__")
			docPipelineID := tc.Expected["doc_pipeline_id"].(string)
			if docPipelineID != "__skip__" {
				if reloadedDoc.PipelineID == nil {
					t.Errorf("doc_pipeline_id should not be nil, expected %s", docPipelineID)
				} else if *reloadedDoc.PipelineID != docPipelineID {
					t.Errorf("doc_pipeline_id mismatch: expected %s got %s", docPipelineID, *reloadedDoc.PipelineID)
				}
			}

			// Assert doc_run (skip "__skip__")
			docRun := tc.Expected["doc_run"].(string)
			if docRun != "__skip__" {
				if reloadedDoc.Run == nil {
					t.Errorf("doc_run should not be nil, expected %s", docRun)
				} else if *reloadedDoc.Run != docRun {
					t.Errorf("doc_run mismatch: expected %s got %s", docRun, *reloadedDoc.Run)
				}
			}

			// Assert doc_token_num
			expectedDocToken := int64(tc.Expected["doc_token_num"].(float64))
			if reloadedDoc.TokenNum != expectedDocToken {
				t.Errorf("doc_token_num mismatch: expected %d got %d", expectedDocToken, reloadedDoc.TokenNum)
			}

			// Assert doc_chunk_num
			expectedDocChunk := int64(tc.Expected["doc_chunk_num"].(float64))
			if reloadedDoc.ChunkNum != expectedDocChunk {
				t.Errorf("doc_chunk_num mismatch: expected %d got %d", expectedDocChunk, reloadedDoc.ChunkNum)
			}

			// Assert kb_token_num
			expectedKBToken := int64(tc.Expected["kb_token_num"].(float64))
			if reloadedKB.TokenNum != expectedKBToken {
				t.Errorf("kb_token_num mismatch: expected %d got %d", expectedKBToken, reloadedKB.TokenNum)
			}

			// Assert kb_chunk_num
			expectedKBChunk := int64(tc.Expected["kb_chunk_num"].(float64))
			if reloadedKB.ChunkNum != expectedKBChunk {
				t.Errorf("kb_chunk_num mismatch: expected %d got %d", expectedKBChunk, reloadedKB.ChunkNum)
			}
		})
	}
}
