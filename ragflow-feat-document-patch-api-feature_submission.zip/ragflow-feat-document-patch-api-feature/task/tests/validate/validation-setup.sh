#!/usr/bin/env bash
#
# Validation environment setup for the document partial-update feature task.
#
# Runs after tests/test-setup.sh (which already cd'd into /repo/ragflow,
# exported the CGO env, warmed the Go module cache offline-first, and confirmed
# the prebuilt tokenizer static lib is present). This script re-asserts the
# Go toolchain + CGO knobs the go-test validation driver needs on a cold shell
# and defensively recovers the module/build caches if the agent wiped them.
#
# The stories drive internal/service against an in-memory pure-Go SQLite DB
# with a nil document engine and nil metadata service — no external services,
# no data seeding here (each story builds its own fixtures via the package's
# pre-existing test helpers).
#
# This script must be IDEMPOTENT — it may be sourced multiple times.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/ragflow}"
cd "$REPO_DIR"

# Offline switches (mirror the image ENV; belt-and-suspenders for a fresh shell).
export GOFLAGS="${GOFLAGS:--mod=mod}"
export GOPROXY="${GOPROXY:-off}"
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"

# CGO env — internal/service transitively links the prebuilt rag_tokenizer
# static lib + the office_oxide FFI lib, so these must be present at test-build
# time. They mirror the image's ENV block exactly.
export CGO_ENABLED="${CGO_ENABLED:-1}"
export CGO_CFLAGS="${CGO_CFLAGS:--I/root/.office_oxide/include/office_oxide_c}"
export CGO_LDFLAGS="${CGO_LDFLAGS:--L/root/.office_oxide/lib -loffice_oxide -Wl,-rpath,/root/.office_oxide/lib}"
export LD_LIBRARY_PATH="${LD_LIBRARY_PATH:-/usr/lib64:/root/.office_oxide/lib}"
export GOCACHE="${GOCACHE:-/root/.cache/go-build}"
export GOMODCACHE="${GOMODCACHE:-/root/go/pkg/mod}"

mkdir -p "$GOCACHE" "$GOMODCACHE"

# Make `go` reachable even if the harness scrubbed PATH.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

# Confirm the prebuilt CGO static lib survived into the workspace; the service
# package cannot link without it. Fail loudly here rather than deep in a story's
# go-test output.
if [[ ! -f internal/cpp/cmake-build-release/librag_tokenizer_c_api.a ]]; then
    echo "validation-setup.sh: FATAL: prebuilt librag_tokenizer_c_api.a missing" >&2
    exit 1
fi

# Belt-and-suspenders module fetch. Offline-first against the warm image cache
# (GOPROXY=off, exported above, forbids any network fetch); a logged online
# retry only runs if the offline pass somehow misses a module.
if ! GOPROXY=off go mod download > /tmp/validation-setup-gomod.log 2>&1; then
    echo "validation-setup.sh: offline 'go mod download' incomplete; retrying online" >&2
    GOPROXY="${GOPROXY_ONLINE:-https://proxy.golang.org,direct}" \
        go mod download >> /tmp/validation-setup-gomod.log 2>&1 || true
fi

# Loud smoke guard: the service package must compile with the baked CGO chain
# before any story runs, so a toolchain/link breakage surfaces here rather than
# as an opaque per-story build error.
if ! go build ./internal/service/ > /tmp/validation-setup-build.log 2>&1; then
    echo "validation-setup.sh: FATAL: internal/service failed to build" >&2
    tail -40 /tmp/validation-setup-build.log >&2
    exit 1
fi

echo "validation-setup.sh: ready (CGO_ENABLED=$CGO_ENABLED, GOTOOLCHAIN=$GOTOOLCHAIN)"
