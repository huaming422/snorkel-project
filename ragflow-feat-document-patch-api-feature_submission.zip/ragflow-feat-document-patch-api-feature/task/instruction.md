## Task

We want the Go backend to support editing a document that's already in a dataset. A Python implementation exists elsewhere in the product, but there's no Go counterpart: callers can create and read documents but can't change one.

Add a PATCH endpoint, `PATCH /api/v1/datasets/:dataset_id/documents/:document_id`, that applies a partial update to a single document. The body carries any subset of these fields: `name`, `chunk_method`, `parser_id`, `parser_config`, `pipeline_id`, `meta_fields`, `enabled`, and the system-maintained `chunk_count`, `token_count`, `progress`. Only the fields present get touched; anything omitted stays as it was. The subtlety that matters: a field present but set to a zero or empty value (`0`, `""`, `false`) is a real update and must be applied, not mistaken for an omission, so the code must know which keys the caller actually sent rather than rely on a plain struct decode. On success, return the updated document as JSON in the shape the rest of the document API returns.

The repo is at `/repo/ragflow` and you're working offline. The module cache, build dependencies, and CGO environment are already set up, so `go build ./internal/...` compiles.

## User stories / requirements

- Requests are authenticated, and a caller may only edit documents in a dataset they own. When someone who doesn't own the target dataset tries to update one of its documents, the request is refused and the document is left exactly as it was.
- The chunk, token, and progress counts are system-maintained: the value already held, or zero, is accepted, any other differing value refused. A document type that can't take a requested chunking method is refused rather than re-chunked. Each metadata value must be a scalar or a list of scalars; a nested-object value is refused.
- Renaming a document validates the new name before anything changes: it can't be empty, can't exceed the allowed length, can't change the file's extension, and can't collide with another document's name in the same dataset. A valid rename updates both the document and the underlying file it points at, so the two stay in sync.
- Changing how a document is chunked or parsed re-queues it for processing: its parse progress resets and its derived counts clear. When a request carries several of these plan fields at once, only the highest-precedence one takes effect, with pipeline winning over parser and parser over chunking method.
- Updating a document's parser configuration combines the supplied settings with the configuration it already has: unrelated existing settings are kept and new ones added. The RAPTOR block is the exception; being tied to the current chunking setup, it is cleared when the sent configuration omits it and kept when the sent configuration includes it.
- Enabling or disabling a document updates its status to match, so a document switched off reads as disabled and one switched back on reads as enabled.
