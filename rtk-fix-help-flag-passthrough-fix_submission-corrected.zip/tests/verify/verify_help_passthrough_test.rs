//! Behavioral checks that asking a wrapped tool for its own help through rtk
//! shows the tool's help, exercised end to end through the compiled `rtk`
//! binary, never by importing internal functions.
//!
//! The binary is driven the way a user's shell drives it: `rtk <tool> <args>`
//! spawned directly (no shell), with its tracking database and tee spool
//! redirected into this test's scratch directory by `common::rtk_command`.
//! Each case compares rtk's answer with what the native tool answers in the
//! same isolated environment.
//!
//! rtk's own usage is recognisable by its `Usage: rtk` line. A help page is
//! matched on the tool's own first and last substantial lines and on its
//! length, so a page from another subcommand doesn't match, and neither does a
//! one-line summary or the top of a page that was cut short. GNU tools print
//! the name they were started under, so a path in front of the tool's name is
//! taken off on both sides first: a wrapper may start the tool by full path or
//! by bare name.
//!
//! Tools the image doesn't carry are skipped. `cargo` is the toolchain and git
//! is installed, so both are always there.

mod common;

use std::path::{Path, PathBuf};
use std::process::Command;

/// First directory on PATH that holds an executable named `tool`, or `None`.
fn on_path(tool: &str) -> Option<PathBuf> {
    let paths = std::env::var_os("PATH")?;
    std::env::split_paths(&paths)
        .map(|d| d.join(tool))
        .find(|p| p.is_file())
}

/// The first line long enough to identify the page, such as `Compile a local
/// package` or `usage: git log`.
fn first_substantial_line(text: &str) -> &str {
    text.lines()
        .map(str::trim_end)
        .find(|l| l.trim().len() > 8)
        .unwrap_or("")
}

/// The last line long enough to identify the page.
fn last_substantial_line(text: &str) -> &str {
    text.lines()
        .map(str::trim_end)
        .rev()
        .find(|l| l.trim().len() > 8)
        .unwrap_or("")
}

/// `text` with every path that ends in `/tool`, such as `/usr/bin/ls` or
/// `./ls`, cut down to `tool`. A URL that ends in the tool's name is left alone.
fn bare_program_name(text: &str, tool: &str) -> String {
    let needle = format!("/{tool}");
    let mut out = String::with_capacity(text.len());
    let mut rest = text;
    while let Some(i) = rest.find(&needle) {
        let after = &rest[i + needle.len()..];
        let ends_name = after
            .chars()
            .next()
            .is_none_or(|c| !(c.is_alphanumeric() || matches!(c, '-' | '_' | '.' | '/')));
        let head = &rest[..i];
        let start = head
            .rfind(|c: char| c.is_whitespace() || "'\"`(<[=".contains(c))
            .map_or(0, |p| p + 1);
        let dir = &head[start..];
        let is_path = dir.is_empty() || dir.starts_with('/') || dir.starts_with('.');
        if ends_name && is_path {
            out.push_str(&head[..start]);
            out.push_str(tool);
        } else {
            out.push_str(&rest[..i + needle.len()]);
        }
        rest = after;
    }
    out.push_str(rest);
    out
}

/// rtk names the program from argv[0]; its own usage block starts `Usage: rtk`.
fn is_rtk_usage(text: &str) -> bool {
    text.contains("Usage: rtk")
}

struct Output {
    text: String,
    code: i32,
}

/// Run `cmd args`, folding stdout then stderr into one string. `LC_ALL=C` and a
/// pinned width keep a translated or terminal-sensitive page comparable on both
/// sides.
fn finish(mut cmd: Command, args: &[&str], label: &str) -> Output {
    let out = cmd
        .args(args)
        .env("LC_ALL", "C")
        .env("MANWIDTH", "80")
        .env("COLUMNS", "80")
        .output()
        .unwrap_or_else(|e| panic!("spawn {label}: {e}"));
    let mut text = String::from_utf8_lossy(&out.stdout).into_owned();
    text.push_str(&String::from_utf8_lossy(&out.stderr));
    Output {
        text,
        code: out.status.code().unwrap_or(-1),
    }
}

/// The native tool, in the same isolated environment an rtk child gets.
fn run_native(program: &Path, args: &[&str]) -> Output {
    let label = program.display().to_string();
    finish(common::native_command(&label), args, &label)
}

/// rtk, isolated to this test's scratch directory.
fn run_rtk(args: &[&str]) -> Output {
    finish(common::rtk_command(), args, "rtk")
}

fn head(text: &str) -> &str {
    let mut end = text.len().min(400);
    while !text.is_char_boundary(end) {
        end -= 1;
    }
    &text[..end]
}

/// `mine` is `tool`'s own help page for `what`: not rtk's usage, the tool's exit
/// code, the tool's first and last substantial lines, and at least half its
/// length. Both sides go through [`bare_program_name`] first.
fn assert_tools_page(tool: &str, what: &str, mine: &Output, native: &Output) {
    assert!(
        !is_rtk_usage(&mine.text),
        "rtk {what} answered with rtk's own usage:\n{}",
        head(&mine.text)
    );
    assert_eq!(mine.code, native.code, "rtk {what} exit code drifted from the tool's");
    let mine_text = bare_program_name(&mine.text, tool);
    let native_text = bare_program_name(&native.text, tool);
    for (which, anchor) in [
        ("first", first_substantial_line(&native_text)),
        ("last", last_substantial_line(&native_text)),
    ] {
        assert!(
            !anchor.is_empty() && mine_text.contains(anchor),
            "rtk {what} does not contain the tool's own {which} line {anchor:?}; got {} bytes:\n{}",
            mine_text.len(),
            head(&mine_text)
        );
    }
    assert!(
        mine_text.len() * 2 >= native_text.len(),
        "rtk {what} returned {} bytes of the tool's {}; the help page was filtered away",
        mine_text.len(),
        native_text.len()
    );
}

/// A wrapped tool's own help reaches the tool in full.
///
/// cargo is asked for help with `--help`, with `-h` and through its `help`
/// subcommand, on several subcommands and on cargo itself. Each answer has to
/// be cargo's own page, whole. git is asked the same ways in a scratch repo.
#[test]
fn a_wrapped_tools_own_help_reaches_the_tool() {
    let cargo = on_path("cargo").expect("cargo is the toolchain and must be on PATH");
    for args in [
        vec!["build", "--help"],
        vec!["build", "-h"],
        vec!["check", "--help"],
        vec!["test", "--help"],
        vec!["--help"],
        vec!["help", "build"],
    ] {
        let mut rtk_args = vec!["cargo"];
        rtk_args.extend(&args);
        let mine = run_rtk(&rtk_args);
        let native = run_native(&cargo, &args);
        assert_tools_page("cargo", &format!("cargo {}", args.join(" ")), &mine, &native);
    }

    let Some(git) = on_path("git") else {
        return;
    };
    let repo = common::temp_git_repo();
    let in_repo = |program: Option<&Path>, args: &[&str]| -> Output {
        let mut cmd = match program {
            Some(p) => {
                let mut c = Command::new(p);
                common::isolate_git(&mut c);
                c
            }
            None => {
                let mut c = common::rtk_command();
                c.arg("git");
                c
            }
        };
        cmd.current_dir(repo.path());
        finish(cmd, args, "git")
    };

    // `-h` is answered by git itself with a usage summary, the same text in
    // every environment.
    for args in [vec!["log", "-h"], vec!["status", "-h"], vec!["--help"]] {
        let mine = in_repo(None, &args);
        let native = in_repo(Some(&git), &args);
        assert_tools_page("git", &format!("git {}", args.join(" ")), &mine, &native);
    }

    // `log --help` and `help log` open the manual. The minimized image carries
    // no manpages, so git answers with a short notice whose wording depends on
    // the environment; what holds everywhere is git's exit code and an answer
    // at least half the size of git's own.
    for args in [vec!["log", "--help"], vec!["help", "log"]] {
        let what = format!("git {}", args.join(" "));
        let mine = in_repo(None, &args);
        let native = in_repo(Some(&git), &args);
        assert!(
            !is_rtk_usage(&mine.text),
            "rtk {what} answered with rtk's own usage:\n{}",
            head(&mine.text)
        );
        assert_eq!(mine.code, native.code, "rtk {what} exit code drifted from git's");
        assert!(
            mine.text.len() * 2 >= native.text.len(),
            "rtk {what} returned {} bytes of git's {}; git's answer was filtered away",
            mine.text.len(),
            native.text.len()
        );
    }
}

/// Every wrapped tool the image carries gets its own help.
///
/// grep, ls, find, wc and curl each go through a different rtk filter. Each
/// one asked for `--help` (and curl for `-h` as well) answers with the tool's
/// own page, whole.
#[cfg(unix)]
#[test]
fn each_wrapped_tool_in_the_image_shows_its_own_help() {
    for (tool, args) in [
        ("grep", vec!["--help"]),
        ("ls", vec!["--help"]),
        ("find", vec!["--help"]),
        ("wc", vec!["--help"]),
        ("curl", vec!["--help"]),
        ("curl", vec!["-h"]),
    ] {
        let Some(native_path) = on_path(tool) else {
            eprintln!("skipped: {tool} not installed");
            continue;
        };
        let mut rtk_args = vec![tool];
        rtk_args.extend(&args);
        let mine = run_rtk(&rtk_args);
        let native = run_native(&native_path, &args);
        assert_tools_page(tool, &format!("{tool} {}", args.join(" ")), &mine, &native);
    }
}

/// `-h` keeps its non-help meaning for tools that spell something else with
/// it.
///
/// For grep, `-h` is `--no-filename`: the output is grep's matches, byte for
/// byte, with the filename dropped. For `ls`, `-h` is a human-readable size:
/// rtk's answer is the same compact listing `rtk ls` gives for the directory,
/// whose two files are a few bytes each. For `tree` it is a listing that
/// names both files and isn't tree's raw `-h` output.
#[cfg(unix)]
#[test]
fn dash_h_keeps_its_non_help_meaning() {
    if let Some(grep) = on_path("grep") {
        let dir = tempfile::tempdir().expect("tempdir");
        let a = dir.path().join("a.txt");
        let b = dir.path().join("b.txt");
        std::fs::write(&a, "alpha\nbeta\n").expect("write a");
        std::fs::write(&b, "alpha\ngamma\n").expect("write b");
        let (a, b) = (
            a.to_string_lossy().into_owned(),
            b.to_string_lossy().into_owned(),
        );

        for flags in [
            vec!["-h", "alpha", &a, &b],
            vec!["alpha", "-h", &a, &b],
            vec!["-h", "-n", "alpha", &a, &b],
        ] {
            let mine = run_rtk(&[&["grep"], flags.as_slice()].concat());
            let native = run_native(&grep, &flags);
            assert!(
                !is_rtk_usage(&mine.text),
                "rtk grep {} answered with rtk's usage instead of searching",
                flags.join(" ")
            );
            assert_eq!(
                mine.text,
                native.text,
                "rtk grep {} diverged from grep (-h is --no-filename there)",
                flags.join(" ")
            );
            assert_eq!(mine.code, native.code, "exit code for grep {}", flags.join(" "));
        }
    } else {
        eprintln!("skipped: grep not installed");
    }

    let dir = tempfile::tempdir().expect("tempdir");
    std::fs::write(dir.path().join("one.txt"), "x\n").expect("write");
    std::fs::write(dir.path().join("two.txt"), "y\n").expect("write");
    let path = dir.path().to_string_lossy().into_owned();
    for tool in ["ls", "tree"] {
        let Some(native) = on_path(tool) else {
            continue;
        };
        let mine = run_rtk(&[tool, "-h", &path]);
        let raw = run_native(&native, &["-h", &path]);
        assert!(
            !is_rtk_usage(&mine.text),
            "rtk {tool} -h answered with rtk's usage instead of a listing"
        );
        assert!(
            mine.text.contains("one.txt") && mine.text.contains("two.txt"),
            "rtk {tool} -h doesn't list the directory:\n{}",
            head(&mine.text)
        );
        assert_ne!(
            mine.text, raw.text,
            "rtk {tool} -h printed the tool's raw output instead of rtk's compact listing"
        );
        if tool == "ls" {
            let plain = run_rtk(&["ls", &path]);
            assert_eq!(
                mine.text, plain.text,
                "rtk ls -h on files of a few bytes isn't the compact listing rtk ls gives"
            );
            assert_eq!(mine.code, plain.code, "exit code for rtk ls -h");
        }
    }
}

/// A flag that carries a value is not a usage request.
///
/// When a caller's value happens to spell a help token, the tool still
/// searches for it. `grep -e --help FILE` searches for the literal `--help`;
/// `grep -- --version FILE` searches for `--version`. On a small file rtk
/// prints grep's own lines, byte for byte.
#[cfg(unix)]
#[test]
fn a_caller_value_that_spells_a_help_token_is_not_a_request() {
    let Some(grep) = on_path("grep") else {
        eprintln!("skipped: grep not installed");
        return;
    };
    let dir = tempfile::tempdir().expect("tempdir");
    let file = dir.path().join("flags.txt");
    std::fs::write(&file, "use --help for usage\nplain\nuse --version here\n").expect("write");
    let f = file.to_string_lossy().into_owned();

    for args in [
        vec!["-e", "--help", &f],
        vec!["--", "--version", &f],
        vec!["-F", "--", "--help", &f],
    ] {
        let mine = run_rtk(&[&["grep"], args.as_slice()].concat());
        let native = run_native(&grep, &args);
        assert!(
            !is_rtk_usage(&mine.text),
            "rtk grep {} answered with rtk's usage instead of searching for the value",
            args.join(" ")
        );
        assert_eq!(
            mine.text,
            native.text,
            "rtk grep {} searched differently from grep",
            args.join(" ")
        );
        assert_eq!(mine.code, native.code, "exit code for grep {}", args.join(" "));
    }
}

/// A tool that forwards past `--` has the region after it read again.
///
/// `cargo test -- --help` sends `--help` to the compiled test binary, and the
/// binary's usage (libtest's) comes through rtk in full; so does `-h` there,
/// and the same request after a cargo option. `grep -- --help` searches for
/// the literal text. The cargo cases run in a throwaway no-dependency crate so
/// the build is cheap and offline.
#[test]
fn a_forwarding_tool_rescans_past_the_double_dash() {
    if let Some(grep) = on_path("grep") {
        let dir = tempfile::tempdir().expect("tempdir");
        let file = dir.path().join("hay.txt");
        std::fs::write(&file, "a --help b\nc\n").expect("write");
        let f = file.to_string_lossy().into_owned();
        let mine = run_rtk(&["grep", "--", "--help", &f]);
        let native = run_native(&grep, &["--", "--help", &f]);
        assert!(
            !is_rtk_usage(&mine.text),
            "rtk grep -- --help answered with rtk's usage instead of searching"
        );
        assert_eq!(
            mine.text, native.text,
            "rtk grep -- --help diverged from grep's search for the literal text"
        );
    }

    let Some(cargo) = on_path("cargo") else {
        eprintln!("skipped: cargo not on PATH");
        return;
    };
    let dir = tempfile::tempdir().expect("tempdir");
    std::fs::write(
        dir.path().join("Cargo.toml"),
        "[package]\nname = \"probe\"\nversion = \"0.0.0\"\nedition = \"2021\"\n\n[lib]\npath = \"lib.rs\"\n",
    )
    .expect("write Cargo.toml");
    std::fs::write(dir.path().join("lib.rs"), "#[test]\nfn noop() {}\n").expect("write lib.rs");

    for args in [
        vec!["test", "--", "--help"],
        vec!["test", "--", "-h"],
        vec!["test", "--lib", "--", "--help"],
    ] {
        let what = format!("cargo {}", args.join(" "));
        let native = {
            let mut c = common::native_command(&cargo.display().to_string());
            c.current_dir(dir.path());
            finish(c, &args, "cargo")
        };
        // With no toolchain able to build an offline no-dep crate here there is
        // nothing to compare against, so the case is skipped.
        if !native.text.contains("--test-threads") {
            eprintln!(
                "skipped: native `{what}` did not yield libtest usage:\n{}",
                head(&native.text)
            );
            continue;
        }

        let mine = {
            let mut c = common::rtk_command();
            c.current_dir(dir.path()).arg("cargo");
            finish(c, &args, "rtk")
        };
        assert!(
            !is_rtk_usage(&mine.text),
            "rtk {what} answered with rtk's own usage:\n{}",
            head(&mine.text)
        );
        assert!(
            mine.text.contains("--test-threads") && mine.text.contains("--include-ignored"),
            "rtk {what} did not show libtest's usage; got {} bytes:\n{}",
            mine.text.len(),
            head(&mine.text)
        );
        assert_eq!(mine.code, native.code, "rtk {what} exit code drifted from cargo's");
    }
}

/// rtk's own commands and `rtk help <wrapper>` still render rtk's usage.
///
/// rtk's own commands, and `rtk help` with a wrapper's name, answer with rtk's
/// usage and exit 0. A parse error also prints a `Usage: rtk` line, but it
/// starts with `error:` and exits non-zero, so it isn't the help page.
#[test]
fn rtks_own_commands_keep_their_help() {
    for args in [
        vec!["--help"],
        vec!["-h"],
        vec!["init", "--help"],
        vec!["gain", "--help"],
        vec!["help", "grep"],
        vec!["help", "cargo"],
    ] {
        let out = run_rtk(&args);
        assert!(
            is_rtk_usage(&out.text) && !out.text.contains("error:") && out.code == 0,
            "rtk {} should render rtk's own usage and exit 0, got exit {}:\n{}",
            args.join(" "),
            out.code,
            head(&out.text)
        );
    }
}
