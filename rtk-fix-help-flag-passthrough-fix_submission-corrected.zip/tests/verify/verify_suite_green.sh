#!/usr/bin/env bash
# Regression gate: the project's own full test command must stay green.
#
# This runs the suite the repository runs in CI, offline against the build
# closure baked into the image, with a small set of tests filtered out by name
# for reasons unrelated to whether the change is correct:
#
#   * Two under hooks::init::pi assert plugin-revision allowlist / shared-
#     extension state that the minimized offline image does not carry; the
#     task's environment excludes them regardless of any change.
#
#   * Two unit tests in src/lib.rs pin the PREVIOUS argument-handling behavior
#     that this change updates on purpose: test_ctest_help_and_version_passthrough_args
#     expects a wrapped tool's own --help/--version to stay literal arguments
#     (the point of this change is that they reach the tool instead), and
#     test_meta_commands_reject_bad_flags expects every composite command to
#     reject an unknown flag (two of them become argument-forwarding commands
#     here). A correct change supersedes both; keeping them in the gate would
#     punish the very behavior the change is meant to deliver. The behavioral
#     checks in verify_help_passthrough_test.rs assert the new behavior directly,
#     so dropping these two does not loosen what is being proven.
#
# Exit 0 only if every other test passes. Any compile error or test failure
# propagates a non-zero exit, which the shell runner reports as a failed check.
set -uo pipefail

# The runner starts us in the repo root; be explicit so a future change to that
# contract does not silently run the suite in the wrong tree.
cd "${REPO_DIR:-$PWD}" || {
    echo "verify_suite_green: could not enter repo root" >&2
    exit 1
}

export CARGO_NET_OFFLINE=true

# `--skip` matches test names by substring and is applied to every test binary
# the suite builds, so naming each method is enough to exclude exactly them.
cargo test --all --locked --offline -- \
    --skip hooks::init::pi::tests::test_all_git_pi_plugin_revisions_are_allowlisted \
    --skip hooks::init::pi::tests::test_global_uninstall_detects_shared_pi_omp_extension \
    --skip tests::test_ctest_help_and_version_passthrough_args \
    --skip tests::test_meta_commands_reject_bad_flags
status=$?

if [ "$status" -ne 0 ]; then
    echo "verify_suite_green: suite is not green (cargo test exited $status)" >&2
    exit "$status"
fi
echo "verify_suite_green: suite green (excluded env-gated + superseded-behavior tests)"
