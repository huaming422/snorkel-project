#!/usr/bin/env bash
# Sourced by tests/test.sh before the checks run (set -euo pipefail inherited).
# rtk is a Rust/cargo repo. The image holds the full dependency and build
# closure of its lockfile (cargo fetch --locked && cargo build --locked --tests),
# so this phase runs offline: a cache miss fails fast instead of reaching for a registry.
cd /repo/rtk

# Offline switch: here and not as an image ENV, since an image-wide cargo
# offline setting would also reach every other tool installed into the image.
export CARGO_NET_OFFLINE=true

# Dependencies: offline-first against the image bake, logged online fallback.
# This file is sourced, so it never exits: a tree whose dependencies can't be
# resolved goes on to the checks, and cargo's own build error fails them.
if cargo fetch --locked --offline > /tmp/test-setup-fetch.log 2>&1; then
    echo "[offline-first] cargo deps satisfied from image"
elif cargo fetch --locked >> /tmp/test-setup-fetch.log 2>&1; then
    echo "[test-setup] cargo deps fetched online (image bake was stale)"
else
    echo "[test-setup] cargo deps could not be resolved; the checks will report it" >&2
    tail -40 /tmp/test-setup-fetch.log >&2
fi

# No services to seed and no extra packages beyond the canonical /opt/tooling
# venv. The checks build and drive the rtk binary themselves.
