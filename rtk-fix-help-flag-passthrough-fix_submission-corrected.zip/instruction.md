## Task

Our hook sends `cargo`, `git` and `grep` through rtk now, and since then people can't get help from those tools. Nobody signed up for that. `rtk cargo check --help` prints rtk's usage for its cargo check wrapper, not the page cargo would print. `rtk cargo check -h`, `rtk cargo help check` and `rtk git log -h` do the same. `--help` on grep, ls, find, wc and curl gets rtk's usage too.

When the request does get through, the answer goes missing. `rtk cargo test -- --help` prints nothing at all and exits 0, where cargo prints the test binary's options.

For grep and ls, `-h` isn't a help flag: grep leaves the file names off its matches and ls shows sizes in human units. Through rtk, `rtk grep -h needle` over a few files and `rtk ls -h` print rtk's usage as well. `rtk ls -lh` works fine, and `rtk ls -h` should give the same compact listing plain `rtk ls` gives. `rtk grep -- --help` over a file searches for the literal text, which is right.

rtk's own help is fine. `rtk --help`, `rtk gain --help` and `rtk help grep` show rtk's usage and need to keep doing that.

Every help request for a tool rtk wraps should come back as that tool's help, the whole page.
