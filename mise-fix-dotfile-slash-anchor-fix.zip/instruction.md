## Task

I'm tracking a config directory with mise dotfiles history, and the entry's
include and exclude filters behave differently when I start a pattern with `/`.
For example, `exclude = ["/cache"]` still saves the top-level `cache` directory,
while `include = ["/rules/*.md"]` saves none of the matching files. Removing
the initial slash makes those filters work. Mise reports no error, so the saved
history quietly differs from what the config asks for.

Please make a leading slash anchor an entry filter to the tracked directory's
root, as it would in a `.gitignore`. A rooted `*` should stay within one path
component, and a bare `/` should continue to match no files. Filters without
that anchor must keep their current behavior. The global `[history] exclude`
setting uses absolute paths; preserve that meaning.

Also keep older history checkpoints safe to roll back to. If an older checkpoint
could not have captured a file that a rooted include selects now, rolling back
to it must leave that live file in place. Checkpoints whose coverage is still
known should remain usable.
