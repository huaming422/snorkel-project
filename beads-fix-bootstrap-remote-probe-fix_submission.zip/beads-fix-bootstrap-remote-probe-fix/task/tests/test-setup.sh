#!/usr/bin/env bash
# All dependencies for building and testing cmd/bd (Go 1.26.10, the real git
# binary, and the warm module + build caches at the base commit) are baked into
# the image. The behavioral verifier drives the git ls-remote probe against
# local bare repositories, so nothing is fetched at verifier or agent time.
set -euo pipefail
echo "[test-setup] no-op for beads-fix-bootstrap-remote-probe"
