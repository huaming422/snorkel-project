// Pass-to-pass guard for the bootstrap remote-probe task.
//
// This is the non-regression half of the reward. It must compile and pass on
// BOTH the pre-fix tree and any correct post-fix tree, so it:
//   - names NO symbol the fix introduces (no Blocked field, no plan→exit helper,
//     no routing/redaction helpers, no probe seam variable, no MarshalJSON);
//   - drives only detectBootstrapAction behaviors that are stable across the
//     change — an existing database, a backup restore, and a fresh init — none
//     of which the fix alters.
//
// Like the fail-to-pass file it defines its own TestMain, which makes the runner
// stash every sibling *_test.go (including the fail-to-pass file and the
// package's cgo/server fixtures) before building. So this file is compiled and
// run on its own, against the package source alone. On the pre-fix tree the
// fail-to-pass file would not even compile, but it is stashed out of this build,
// so this guard still builds and passes — which is exactly the "existing suite
// still green / repo still builds" contract, exercised at the stable seam
// instead of by running the whole server-backed suite (which needs cgo + a live
// Dolt server the task container does not run).
//
// NOTE: this file must be the ONLY verify*_test.go that defines verifyMainInner.
// verify_test.go defines its own; the runner never builds the two together.

package main

import (
	"os"
	"path/filepath"
	"testing"

	"github.com/steveyegge/beads/internal/config"
	"github.com/steveyegge/beads/internal/configfile"
)

func TestMain(m *testing.M) {
	os.Exit(verifyP2PMainInner(m))
}

func verifyP2PMainInner(m *testing.M) int {
	tmp, err := os.MkdirTemp("", "beads-verify-p2p-*")
	if err != nil {
		panic(err)
	}
	defer func() { _ = os.RemoveAll(tmp) }()

	_ = os.Setenv("HOME", tmp)
	_ = os.Setenv("USERPROFILE", tmp)
	_ = os.Setenv("APPDATA", filepath.Join(tmp, "AppData", "Roaming"))
	_ = os.Setenv("XDG_CONFIG_HOME", filepath.Join(tmp, "xdg-config"))
	_ = os.Setenv("BEADS_TEST_IGNORE_REPO_CONFIG", "1")
	_ = os.Setenv("BEADS_TEST_MODE", "1")
	_ = os.Setenv("BD_DISABLE_METRICS", "1")
	_ = os.Setenv("BD_DISABLE_EVENT_FLUSH", "1")
	_ = os.Unsetenv("BEADS_DIR")

	config.ResetForTesting()
	enableTestModeGlobals()

	return m.Run()
}

// clearBootstrapServerEnv zeroes the server/shared-server detection vars so the
// embedded-mode detection path is exercised deterministically (mirrors what the
// package's own stable bootstrap tests do before each case).
func clearBootstrapServerEnv(t *testing.T) {
	t.Helper()
	for _, k := range []string{
		"BEADS_DOLT_DATA_DIR",
		"BEADS_DOLT_SHARED_SERVER",
		"BEADS_DOLT_SERVER_DATABASE",
		"BEADS_DOLT_SERVER_HOST",
		"BEADS_DOLT_SERVER_PORT",
	} {
		t.Setenv(k, "")
	}
}

// chdirInto moves into dir for the duration of the test so detectBootstrapAction
// cannot climb into a real git repo above the temp workspace.
func chdirInto(t *testing.T, dir string) {
	t.Helper()
	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = os.Chdir(oldWd) })
	if err := os.Chdir(dir); err != nil {
		t.Fatal(err)
	}
}

// TestExistingDatabaseStaysNone: an embedded database already on disk is
// "nothing to do" — action "none" with HasExisting true — on both trees.
func TestExistingDatabaseStaysNone(t *testing.T) {
	clearBootstrapServerEnv(t)
	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	embeddedDir := filepath.Join(beadsDir, "embeddeddolt", "beads")
	if err := os.MkdirAll(embeddedDir, 0o750); err != nil {
		t.Fatal(err)
	}
	chdirInto(t, tmpDir)

	plan := detectBootstrapAction(beadsDir, configfile.DefaultConfig())

	if plan.Action != "none" {
		t.Errorf("action = %q, want %q", plan.Action, "none")
	}
	if !plan.HasExisting {
		t.Error("HasExisting = false, want true for an existing database")
	}
}

// TestBackupRestoreUnchanged: a non-empty backup JSONL yields a restore plan.
// The fix carries plan fields into this branch but must not change the action
// or the backup dir it selects.
func TestBackupRestoreUnchanged(t *testing.T) {
	clearBootstrapServerEnv(t)
	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	backupDir := filepath.Join(beadsDir, "backup")
	if err := os.MkdirAll(backupDir, 0o750); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(backupDir, "issues.jsonl"), []byte("{}"), 0o644); err != nil {
		t.Fatal(err)
	}
	chdirInto(t, tmpDir)

	plan := detectBootstrapAction(beadsDir, configfile.DefaultConfig())

	if plan.Action != "restore" {
		t.Errorf("action = %q, want %q", plan.Action, "restore")
	}
	if plan.BackupDir != backupDir {
		t.Errorf("BackupDir = %q, want %q", plan.BackupDir, backupDir)
	}
}

// TestFreshInitUnchanged: an empty workspace with no remote, no backup, and no
// git-tracked JSONL yields a fresh init plan on both trees.
func TestFreshInitUnchanged(t *testing.T) {
	clearBootstrapServerEnv(t)
	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}
	chdirInto(t, tmpDir)

	plan := detectBootstrapAction(beadsDir, configfile.DefaultConfig())

	if plan.Action != "init" {
		t.Errorf("action = %q, want %q", plan.Action, "init")
	}
}
