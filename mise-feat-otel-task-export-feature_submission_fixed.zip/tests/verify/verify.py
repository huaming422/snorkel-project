"""Build and baseline checks for mise-feat-otel-task-export.

The full workspace, including the `mise` crate, builds `--locked` under the
pinned toolchain with the committed lockfile, its test binaries compile, and
the existing settings tests still pass.

This works through the *build/test interface* only. It never imports or names
any module, type, or function added to the crate, so the code may be structured
and named however it likes. It asserts two facts:

  1. `cargo build --locked --tests --workspace` succeeds — the dependency closure
     resolves against the committed lockfile and the whole workspace (mise
     included) compiles offline, test binaries and all.
  2. The pre-existing `config::settings` unit tests still pass. These include the
     repository's own checks on settings.toml (for example that it stays
     sorted), which any new setting has to respect. We run this one fast module
     by name rather than the entire suite (the full suite would not fit in the
     time budget).

This guards against regressions: a change that breaks the build, the lockfile
or the existing settings tests fails here.

Both steps compile the large `mise` crate. If the kernel kills a rustc process
for running out of memory (SIGKILL) part-way through, the step is retried once
with a single build job inside the same time budget, so a memory spike in the
sandbox is not reported as a broken build.
"""

import os
import subprocess
import time

RUST_DIR = os.environ.get("MISE_REPO_DIR", "/repo/mise")

# cargo lives under /opt/cargo/bin in the image; ensure it is on PATH regardless
# of the shell this runs under. Pin the baked toolchain + target dir.
_ENV = {
    **os.environ,
    "PATH": "/opt/cargo/bin:" + os.environ.get("PATH", ""),
    "CARGO_TARGET_DIR": os.environ.get("CARGO_TARGET_DIR", "/opt/cache/cargo-target"),
}

# Below this many seconds left there is no point starting a single-job retry.
_MIN_RETRY_SECS = 60


def _tail(proc, n=3000):
    return (proc.stdout[-n:] + "\n" + proc.stderr[-n:]).strip()


def _killed_by_oom(proc):
    """cargo reports a rustc that the kernel killed as `(signal: 9, SIGKILL: kill)`."""
    out = proc.stdout + proc.stderr
    return "SIGKILL" in out or "signal: 9" in out


def _cargo(args, budget):
    """Run `cargo <args>` within `budget` seconds.

    If a compiler process was SIGKILLed, retry once with `--jobs 1` for whatever
    time is left. Artifacts already built are reused, so the retry only redoes
    the crates that were cut off.
    """
    deadline = time.monotonic() + budget
    cmd = ["cargo", *args]
    proc = subprocess.run(
        cmd, cwd=RUST_DIR, env=_ENV, capture_output=True, text=True, timeout=budget
    )
    remaining = deadline - time.monotonic()
    if proc.returncode != 0 and _killed_by_oom(proc) and remaining > _MIN_RETRY_SECS:
        # `--jobs` must sit before any `--` that hands arguments to the test binary.
        retry = ["cargo", args[0], "--jobs", "1", *args[1:]]
        proc = subprocess.run(
            retry, cwd=RUST_DIR, env=_ENV, capture_output=True, text=True,
            timeout=remaining,
        )
    return proc


def test_workspace_builds_locked():
    """`cargo build --locked --tests --workspace` returns 0 (offline closure)."""
    assert os.path.isdir(RUST_DIR), f"repo workspace missing at {RUST_DIR}"

    proc = _cargo(["build", "--locked", "--tests", "--workspace"], budget=1100)
    assert proc.returncode == 0, (
        "cargo build --locked --tests --workspace failed "
        f"(exit {proc.returncode}). The workspace (mise crate included) must "
        "compile offline against the committed lockfile, test binaries and "
        "all.\n\n" + _tail(proc)
    )


def test_baseline_behaviour_not_regressed():
    """The pre-existing `config::settings` unit tests still pass.

    `config::settings` is a long-standing module with fast, self-contained unit
    tests. Running it by path shows the existing settings behaviour still holds,
    without the cost of the whole suite. If modules were reorganised so that
    this exact filter matches nothing, cargo exits 0 having run zero tests,
    which is still a non-failure: this guards against regressions and does not
    require a particular module layout."""
    proc = _cargo(
        ["test", "--locked", "--bin", "mise", "config::settings", "--",
         "--test-threads", "1"],
        budget=400,
    )
    assert proc.returncode == 0, (
        "pre-existing baseline tests regressed "
        f"(exit {proc.returncode}).\n\n" + _tail(proc)
    )
