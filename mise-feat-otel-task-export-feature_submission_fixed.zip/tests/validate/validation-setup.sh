#!/usr/bin/env bash
# Validation setup for mise-feat-otel-task-export.
#
# Sourced (not exec'd) before the stories run, so exported env vars persist for
# the story tests.
#
# The stories are black-box: they run the compiled `mise` binary against a local
# stdlib-python OTLP/HTTP receiver (stood up inside the harness) and assert on the
# telemetry that arrives. So all this setup must do is:
#   1. Pin the repo's Rust toolchain ahead of any stray PATH version.
#   2. Restore the committed lockfile so `--locked` is satisfiable.
#   3. Build the `mise` binary the stories drive, into the shared target dir.
#   4. End with a loud smoke guard that exits non-zero if the binary or the
#      stdlib python3 the receiver needs is missing, so a broken environment
#      stops here instead of every story failing quietly.
#
# It deliberately does NOT write the fixture `mise.toml` (the harness writes a
# fresh one per run in a throwaway workdir) and does NOT configure any of the
# feature's opt-ins or telemetry env vars: those names are chosen by the code
# under test, so each story reads them from the source and passes them to
# run_mise(...).

set -u

REPO_DIR="${MISE_REPO_DIR:-/repo/mise}"
# Toolchain first on PATH (pin ahead of any stray cargo/rustc), stdlib python next.
export PATH="/opt/cargo/bin:${PATH}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
# The stories find the binary here; export so the harness resolves the same build.
export MISE_REPO_DIR="$REPO_DIR"

mkdir -p /logs/verifier 2>/dev/null || true

cd "$REPO_DIR" || { echo "[setup] FATAL: repo dir $REPO_DIR missing"; return 1 2>/dev/null || exit 1; }

# ── 1. Toolchain sanity (loud, non-fatal here; the smoke guard is the gate) ───
echo "=== Rust toolchain ==="
cargo --version || echo "[setup] WARNING: cargo not on PATH"
rustc --version || echo "[setup] WARNING: rustc not on PATH"
echo "[setup] python3: $(python3 --version 2>&1 || echo MISSING)"

# ── 2. Restore the committed lockfile so --locked builds are satisfiable ───────
# The image baked a generated-lockfile baseline commit; the working tree may have
# a modified Cargo.lock. Restore it to the committed state before building --locked.
echo "=== Restoring Cargo.lock to the committed baseline ==="
git checkout -- Cargo.lock 2>/dev/null \
    && echo "[setup] Cargo.lock restored" \
    || echo "[setup] note: could not restore Cargo.lock (may be clean already)"

# ── 3. Build the mise binary the stories drive ────────────────────────────────
# Prefer --locked (offline, reproducible). If the change legitimately needs
# lockfile entries that the restored lockfile lacks, --locked fails; fall back to
# a plain build so a valid implementation is still exercised. Either way the
# binary must exist for the smoke guard to pass.
echo "=== Building mise binary ==="
if cargo build --locked --bin mise >/tmp/mise_build.log 2>&1; then
    echo "[setup] mise built (--locked)"
elif cargo build --bin mise >/tmp/mise_build.log 2>&1; then
    echo "[setup] mise built (relocked)"
else
    echo "[setup] WARNING: mise build failed:"; tail -60 /tmp/mise_build.log 2>/dev/null || true
fi
cp /tmp/mise_build.log /logs/verifier/mise_build.log 2>/dev/null || true

MISE_BIN="${CARGO_TARGET_DIR}/debug/mise"
export MISE_BIN

# ── 4. Loud smoke guard: a broken environment stops here ──────────────────────
echo "=== Smoke guard ==="
rc=0
if [ ! -x "$MISE_BIN" ]; then
    echo "[setup] FATAL: mise binary not found at $MISE_BIN"; rc=1
elif ! "$MISE_BIN" --version >/tmp/mise_version.log 2>&1; then
    echo "[setup] FATAL: mise --version failed:"; tail -20 /tmp/mise_version.log 2>/dev/null || true; rc=1
else
    echo "[setup] mise OK: $(cat /tmp/mise_version.log 2>/dev/null | head -1)"
fi
if ! python3 -c "import http.server, json, threading, socketserver" 2>/tmp/py_smoke.log; then
    echo "[setup] FATAL: stdlib python3 (http.server/json) unavailable:"; tail -20 /tmp/py_smoke.log 2>/dev/null || true; rc=1
else
    echo "[setup] python3 stdlib OTLP-receiver modules OK"
fi

if [ "$rc" -ne 0 ]; then
    echo "=== Validation setup FAILED (see messages above) ==="
    return "$rc" 2>/dev/null || exit "$rc"
fi

echo "=== Validation setup complete ==="
return 0 2>/dev/null || true
