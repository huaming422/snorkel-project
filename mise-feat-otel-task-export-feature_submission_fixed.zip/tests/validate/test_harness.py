"""Validation harness for mise-feat-otel-task-export.

Black-box, implementation-agnostic test infrastructure. The stories drive
mise's OpenTelemetry export for `mise run` through ONE interface: the
OTLP/HTTP wire. They run the compiled `mise` binary against a tiny local
OTLP/HTTP receiver this harness stands up, and inspect only what arrives on
the wire.

    mise run <tasks>   ──OTLP/HTTP──▶   OtlpCollector (stdlib http.server)
        │                                      │
        └─ [ mise's OTLP export, however it is built ]
                                               ▼
                               spans / log records parsed from the OTLP
                               *spec's* own wire shape (JSON or protobuf)

The harness NEVER references a mise-internal symbol, module, file, setting
id, env-var name, attribute key, or span-name string chosen by the
implementation. Everything it parses is OTLP-protocol-owned (`resourceSpans`,
`scopeSpans`, `spanId`, `parentSpanId`, `traceId`, `status.code`,
`attributes[].key/.value`, `resourceLogs`, `scopeLogs`, `logRecords`,
`body.stringValue`) — the stable shape of the OpenTelemetry wire format that
any correct exporter emits. The fixture `mise.toml` it writes is a pure test
fixture (harness-owned): the implementation never reads the harness's copy.

How a story enables the feature and names its spans/attributes is the
implementation's own choice. A story therefore DISCOVERS those from the
source under test (which setting/env var turns trace export on, which turns
log export on, how a span's role and a task's exit code are recorded) and
passes the enabling env vars to `run_mise(..., env=...)`. This harness only
ever sets the OTel-spec-standard `OTEL_EXPORTER_OTLP_ENDPOINT` itself.

Pure Python standard library — no third-party imports (runs under the repo's
system `python3`, like the repo's own e2e tests and OTLP receiver).
"""

from __future__ import annotations

import json
import os
import shutil
import struct
import subprocess
import socket
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# ── Minimal proto3 wire decoder (stdlib only) ────────────────────────────────
# OTLP's default HTTP encoding is protobuf (application/x-protobuf). The spec's
# JSON encoding (http/json) is OPTIONAL. To read span/log CONTENT regardless of
# which encoding the implementation chose, the collector parses JSON first and
# falls back to this tiny proto3 reader. It decodes only the handful of fields
# the stories need (ids, names, attributes, status, bodies) — everything it
# reads is OTLP-protocol-owned, never an implementation-chosen symbol.
def _parse_varint(data: bytes, pos: int):
    """Parse a varint from data at pos. Returns (value, new_pos)."""
    result, shift = 0, 0
    while pos < len(data):
        b = data[pos]
        pos += 1
        result |= (b & 0x7F) << shift
        if not (b & 0x80):
            return result, pos
        shift += 7
    raise ValueError("truncated varint")


def _parse_proto_fields(data: bytes):
    """Parse proto3 wire fields from data.
    Returns list of (field_num, wire_type, raw_value_bytes).
    wire_type 0=varint, 1=64-bit, 2=LEN, 5=32-bit.
    """
    fields = []
    pos = 0
    while pos < len(data):
        tag, pos = _parse_varint(data, pos)
        field_num = tag >> 3
        wire_type = tag & 0x7
        if wire_type == 0:  # varint
            val, pos = _parse_varint(data, pos)
            fields.append((field_num, 0, struct.pack("<Q", val)))
        elif wire_type == 1:  # 64-bit
            fields.append((field_num, 1, data[pos:pos + 8]))
            pos += 8
        elif wire_type == 2:  # length-delimited
            length, pos = _parse_varint(data, pos)
            fields.append((field_num, 2, data[pos:pos + length]))
            pos += length
        elif wire_type == 5:  # 32-bit
            fields.append((field_num, 5, data[pos:pos + 4]))
            pos += 4
        else:  # unknown wire type, stop
            break
    return fields


def _proto_string(raw: bytes) -> str:
    try:
        return raw.decode("utf-8")
    except Exception:
        return raw.hex()


def _proto_varint(raw: bytes) -> int:
    val, _ = _parse_varint(raw, 0)
    return val


def _proto_any_value(data: bytes):
    """Decode proto3 AnyValue oneof."""
    for field_num, wire_type, raw in _parse_proto_fields(data):
        if field_num == 1 and wire_type == 2:  # string_value
            return _proto_string(raw)
        elif field_num == 2 and wire_type == 0:  # bool_value
            return bool(_proto_varint(raw))
        elif field_num == 3 and wire_type == 0:  # int_value
            v, _ = _parse_varint(raw, 0)
            return v
        elif field_num == 4 and wire_type == 1:  # double_value
            return struct.unpack("<d", raw)[0]
        elif field_num == 7 and wire_type == 2:  # bytes_value
            return raw.hex()
    return None


def _proto_kv(data: bytes):
    """Decode proto3 KeyValue -> (key, value)."""
    key, val = "", None
    for field_num, wire_type, raw in _parse_proto_fields(data):
        if field_num == 1 and wire_type == 2:
            key = _proto_string(raw)
        elif field_num == 2 and wire_type == 2:
            val = _proto_any_value(raw)
    return key, val


def _proto_status_code(data: bytes) -> int:
    """Decode proto3 Status.code (field 3, varint). Returns 0/1/2."""
    for field_num, wire_type, raw in _parse_proto_fields(data):
        if field_num == 3 and wire_type == 0:
            return _proto_varint(raw)
    return 0


# ── Locating the compiled mise binary (built by validation-setup.sh) ─────────
# The e2e convention (e2e/helpers.sh resolve_mise_bin): honour an explicit
# override, else the cargo target dir's debug build, else the repo target, else
# whatever `mise` is on PATH. The binary's directory is placed FIRST on PATH for
# every run so a task that itself shells out to `mise run ...` (a nested run)
# uses the very same build.
_REPO_DIR = os.environ.get("MISE_REPO_DIR", "/repo/mise")


def resolve_mise_bin() -> str:
    explicit = os.environ.get("MISE_BIN") or os.environ.get("MISE_E2E_BIN")
    if explicit and os.access(explicit, os.X_OK):
        return explicit
    target = os.environ.get("CARGO_TARGET_DIR", f"{_REPO_DIR}/target")
    cand = os.path.join(target, "debug", "mise")
    if os.access(cand, os.X_OK):
        return cand
    cand = os.path.join(_REPO_DIR, "target", "debug", "mise")
    if os.access(cand, os.X_OK):
        return cand
    found = shutil.which("mise")
    if found:
        return found
    raise FileNotFoundError(
        "could not locate a compiled `mise` binary; validation-setup.sh should "
        "have built it (set MISE_BIN to override)"
    )


# ── The fixture task file (harness-owned; the implementation never reads it) ──
# A few trivial tasks that print known lines, one that nests a `mise run`, one
# that prints two stdout lines and a stderr line, and fail-fast pairs (a task
# that fails fast + a long-running sibling mise must stop). `slow`/`slow2` sleep
# far longer than the failing task so they are guaranteed to still be running
# when the failure triggers fail-fast cancellation. `multi` builds its stderr
# text from a shell variable so the literal `multi-err` never appears in the
# command line mise echoes to stderr before running the task.
FIXTURE_MISE_TOML = """\
[tasks.a]
run = "echo from-a"
[tasks.b]
run = "echo from-b; mise run inner"
[tasks.inner]
run = "echo from-inner"
[tasks.multi]
run = "echo multi-out-1; echo multi-out-2; e=err; echo multi-$e >&2"
[tasks.all]
depends = ["a", "b"]
[tasks.fail]
run = "sleep 1; exit 3"
[tasks.slow]
run = "sleep 30"
[tasks."fail-fast"]
depends = ["fail", "slow"]
[tasks.fail7]
run = "sleep 1; exit 7"
[tasks.slow2]
run = "sleep 30"
[tasks."fail-fast2"]
depends = ["fail7", "slow2"]
"""


# ── OTLP/HTTP receiver (stdlib only) ─────────────────────────────────────────
class _Handler(BaseHTTPRequestHandler):
    def do_POST(self):  # noqa: N802 (http.server API)
        length = int(self.headers.get("Content-Length", 0) or 0)
        body = self.rfile.read(length) if length else b""
        # OTLP/HTTP posts each signal to a path ending in the signal name,
        # e.g. .../v1/traces or .../v1/logs .
        signal = self.path.rsplit("/", 1)[-1]
        self.server._record(  # type: ignore[attr-defined]
            signal, self.headers.get("Content-Type", ""), body
        )
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", "2")
        self.end_headers()
        self.wfile.write(b"{}")

    def log_message(self, *_args):  # silence the default stderr logging
        pass


def _attr_value(v: dict):
    """Decode one OTLP AnyValue (JSON form) to a native Python value."""
    if "stringValue" in v:
        return v["stringValue"]
    if "intValue" in v:
        # protobuf JSON encodes int64 as a string
        try:
            return int(v["intValue"])
        except (TypeError, ValueError):
            return v["intValue"]
    if "boolValue" in v:
        return bool(v["boolValue"])
    if "doubleValue" in v:
        return float(v["doubleValue"])
    for val in v.values():
        return val
    return None


def _status_code(span: dict) -> int:
    """OTLP status code as an int: 0=UNSET, 1=OK, 2=ERROR.

    Robust to both the integer and the proto-JSON string enum encodings.
    """
    raw = (span.get("status") or {}).get("code", 0)
    if isinstance(raw, str):
        return {
            "STATUS_CODE_UNSET": 0,
            "STATUS_CODE_OK": 1,
            "STATUS_CODE_ERROR": 2,
        }.get(raw, 0)
    try:
        return int(raw)
    except (TypeError, ValueError):
        return 0


_ROOT_PARENTS = {"", "0000000000000000", "00000000000000000000000000000000"}


class _V6Server(ThreadingHTTPServer):
    address_family = socket.AF_INET6


def _bind(server_cls, host: str, port: int, attempts: int = 40):
    """Bind an HTTP server, retrying a busy fixed port for up to ~20 s.

    A free port (0) never collides. A fixed port can still be held briefly by
    a receiver an earlier run has not finished closing, so wait it out before
    giving up with an error that names the port.
    """
    for attempt in range(attempts):
        try:
            return server_cls((host, port), _Handler)
        except OSError as err:
            if not port:
                raise
            if attempt == attempts - 1:
                raise OSError(f"{host}:{port} is still in use: {err}") from err
            time.sleep(0.5)
    raise OSError(f"could not bind {host}:{port}")


class OtlpCollector:
    """A local OTLP/HTTP receiver. Use as a context manager:

        with OtlpCollector() as col:
            run_mise("all", col, env={...})
            spans = col.spans()

    `endpoint` is the base URL to hand mise via OTEL_EXPORTER_OTLP_ENDPOINT
    (run_mise does this for you). All accessors below read ONLY OTLP-spec
    fields, so they work regardless of how the implementation is structured.
    """

    def __init__(self, port: int = 0):
        # port=0 picks a free port. A story that needs to watch the OTLP/HTTP
        # spec's default local address passes port=4318 explicitly; that fixed
        # port is also bound on ::1 (when the host has IPv6) because a client
        # may resolve `localhost` to either address.
        self._lock = threading.Lock()
        self._requests: list[dict] = []
        self._server = _bind(ThreadingHTTPServer, "127.0.0.1", port)
        self._servers = [self._server]
        if port:
            try:
                self._servers.append(_bind(_V6Server, "::1", port, attempts=1))
            except OSError:
                pass  # no IPv6 loopback here; 127.0.0.1 alone is enough
        self._threads = []
        for server in self._servers:
            server._record = self._record  # type: ignore[attr-defined]
            t = threading.Thread(target=server.serve_forever, daemon=True)
            t.start()
            self._threads.append(t)

    # -- lifecycle ------------------------------------------------------------
    def __enter__(self) -> "OtlpCollector":
        return self

    def __exit__(self, *_exc) -> None:
        self.stop()

    def stop(self) -> None:
        for server in self._servers:
            try:
                server.shutdown()
                server.server_close()
            except Exception:
                pass

    def _record(self, signal: str, content_type: str, body: bytes) -> None:
        with self._lock:
            self._requests.append(
                {"signal": signal, "content_type": content_type, "body": body}
            )

    @property
    def endpoint(self) -> str:
        host, port = self._server.server_address[:2]
        return f"http://127.0.0.1:{port}"

    def reset(self) -> None:
        with self._lock:
            self._requests = []

    # -- raw request inspection ----------------------------------------------
    def _bodies(self, signal: str) -> list[bytes]:
        with self._lock:
            return [r["body"] for r in self._requests if r["signal"] == signal]

    def content_types(self, signal: str = "traces") -> list[str]:
        """Content-Type header(s) the receiver saw for a signal's export
        requests, in arrival order (e.g. 'application/x-protobuf' or
        'application/json')."""
        with self._lock:
            return [r["content_type"] for r in self._requests if r["signal"] == signal]

    def request_count(self, signal: str) -> int:
        return len(self._bodies(signal))

    # -- parsed spans (JSON + protobuf) --------------------------------------
    def spans(self) -> list[dict]:
        """Every exported span, flattened, as plain dicts with OTLP-spec fields:
        {name, span_id, parent_span_id, trace_id, status_code, attributes}.

        `attributes` is a {key: value} dict of decoded AnyValues. Both the JSON
        (application/json) and the protobuf (application/x-protobuf) OTLP wire
        encodings are parsed, so trace assertions work no matter which protocol
        the implementation exports with.
        """
        out: list[dict] = []
        for body in self._bodies("traces"):
            # Try JSON first.
            try:
                doc = json.loads(body.decode("utf-8"))
                for rs in doc.get("resourceSpans", []):
                    for ss in rs.get("scopeSpans", []):
                        for s in ss.get("spans", []):
                            attrs = {
                                kv.get("key"): _attr_value(kv.get("value", {}))
                                for kv in s.get("attributes", [])
                            }
                            out.append(
                                {
                                    "name": s.get("name"),
                                    "span_id": s.get("spanId"),
                                    "parent_span_id": s.get("parentSpanId") or "",
                                    "trace_id": s.get("traceId"),
                                    "status_code": _status_code(s),
                                    "attributes": attrs,
                                }
                            )
                continue
            except (ValueError, UnicodeDecodeError):
                pass
            # Fall back to protobuf (ExportTraceServiceRequest: field 1 =
            # ResourceSpans; ResourceSpans field 2 = ScopeSpans; ScopeSpans
            # field 2 = Span).
            try:
                for f1, wt1, rs_data in _parse_proto_fields(body):
                    if f1 != 1 or wt1 != 2:  # ResourceSpans
                        continue
                    for f2, wt2, ss_data in _parse_proto_fields(rs_data):
                        if f2 != 2 or wt2 != 2:  # ScopeSpans
                            continue
                        for f3, wt3, span_data in _parse_proto_fields(ss_data):
                            if f3 != 2 or wt3 != 2:  # Span
                                continue
                            name, trace_id, span_id, parent_span_id = "", "", "", ""
                            attrs, status_code = {}, 0
                            for fn, ft, fv in _parse_proto_fields(span_data):
                                if fn == 1 and ft == 2:  # trace_id bytes
                                    trace_id = fv.hex()
                                elif fn == 2 and ft == 2:  # span_id bytes
                                    span_id = fv.hex()
                                elif fn == 4 and ft == 2:  # parent_span_id bytes
                                    parent_span_id = fv.hex() if fv else ""
                                elif fn == 5 and ft == 2:  # name string
                                    name = _proto_string(fv)
                                elif fn == 9 and ft == 2:  # attributes KeyValue
                                    k, v = _proto_kv(fv)
                                    if k:
                                        attrs[k] = v
                                elif fn == 15 and ft == 2:  # status Status
                                    status_code = _proto_status_code(fv)
                            out.append(
                                {
                                    "name": name,
                                    "span_id": span_id,
                                    "parent_span_id": parent_span_id,
                                    "trace_id": trace_id,
                                    "status_code": status_code,
                                    "attributes": attrs,
                                }
                            )
            except Exception:
                pass
        return out

    def log_records(self) -> list[dict]:
        """Every exported log record: {body, span_id, trace_id, attributes}.

        Parses both the JSON and the protobuf OTLP wire encodings.
        """
        out: list[dict] = []
        for body in self._bodies("logs"):
            # Try JSON first.
            try:
                doc = json.loads(body.decode("utf-8"))
                for rl in doc.get("resourceLogs", []):
                    for sl in rl.get("scopeLogs", []):
                        for rec in sl.get("logRecords", []):
                            attrs = {
                                kv.get("key"): _attr_value(kv.get("value", {}))
                                for kv in rec.get("attributes", [])
                            }
                            out.append(
                                {
                                    "body": (rec.get("body") or {}).get("stringValue"),
                                    "span_id": rec.get("spanId") or "",
                                    "trace_id": rec.get("traceId"),
                                    "attributes": attrs,
                                }
                            )
                continue
            except (ValueError, UnicodeDecodeError):
                pass
            # Fall back to protobuf (ExportLogsServiceRequest: field 1 =
            # ResourceLogs; ResourceLogs field 2 = ScopeLogs; ScopeLogs
            # field 2 = LogRecord).
            try:
                for f1, wt1, rl_data in _parse_proto_fields(body):
                    if f1 != 1 or wt1 != 2:  # ResourceLogs
                        continue
                    for f2, wt2, sl_data in _parse_proto_fields(rl_data):
                        if f2 != 2 or wt2 != 2:  # ScopeLogs
                            continue
                        for f3, wt3, rec_data in _parse_proto_fields(sl_data):
                            if f3 != 2 or wt3 != 2:  # LogRecord
                                continue
                            body_str, span_id, trace_id = None, "", ""
                            attrs = {}
                            for fn, ft, fv in _parse_proto_fields(rec_data):
                                if fn == 5 and ft == 2:  # body AnyValue
                                    body_val = _proto_any_value(fv)
                                    if isinstance(body_val, str):
                                        body_str = body_val
                                elif fn == 6 and ft == 2:  # attributes KeyValue
                                    k, v = _proto_kv(fv)
                                    if k:
                                        attrs[k] = v
                                elif fn == 9 and ft == 2:  # trace_id bytes
                                    trace_id = fv.hex()
                                elif fn == 10 and ft == 2:  # span_id bytes
                                    span_id = fv.hex() if fv else ""
                            out.append(
                                {
                                    "body": body_str,
                                    "span_id": span_id,
                                    "trace_id": trace_id,
                                    "attributes": attrs,
                                }
                            )
            except Exception:
                pass
        return out

    # -- span-tree helpers (OTLP-structure only; no implementation knowledge) --
    def trace_ids(self) -> set:
        return {s["trace_id"] for s in self.spans() if s.get("trace_id")}

    def root_spans(self) -> list[dict]:
        """Spans with no parent (the top of a trace)."""
        return [s for s in self.spans() if s["parent_span_id"] in _ROOT_PARENTS]

    def children_of(self, span_id: str) -> list[dict]:
        return [s for s in self.spans() if s["parent_span_id"] == span_id]

    def span_by_id(self, span_id: str) -> dict | None:
        for s in self.spans():
            if s["span_id"] == span_id:
                return s
        return None

    def span_depths(self) -> dict:
        """Map span_id -> depth below its root (root = 0). Spans whose parent is
        absent from the export are treated as roots."""
        spans = self.spans()
        by_id = {s["span_id"]: s for s in spans}
        depths: dict = {}

        def depth(sid: str, seen: set) -> int:
            if sid in depths:
                return depths[sid]
            s = by_id.get(sid)
            if s is None:
                return 0
            pid = s["parent_span_id"]
            if pid in _ROOT_PARENTS or pid not in by_id or sid in seen:
                depths[sid] = 0
                return 0
            d = depth(pid, seen | {sid}) + 1
            depths[sid] = d
            return d

        for s in spans:
            depth(s["span_id"], set())
        return depths

    def max_span_depth(self) -> int:
        d = self.span_depths()
        return max(d.values()) if d else 0


# ── Running mise against the collector ───────────────────────────────────────
def _isolated_env(workdir: str, home: str, collector: OtlpCollector,
                  overrides: dict | None) -> dict:
    mise_bin = resolve_mise_bin()
    bin_dir = os.path.dirname(os.path.abspath(mise_bin))
    base_path = os.environ.get("PATH", "/usr/local/bin:/usr/bin:/bin")
    env = {
        # debug mise first so a nested `mise run` resolves to the same build
        "PATH": f"{bin_dir}:{base_path}",
        "HOME": home,
        "MISE_DATA_DIR": os.path.join(home, ".local/share/mise"),
        "MISE_CONFIG_DIR": os.path.join(home, ".config/mise"),
        "MISE_CACHE_DIR": os.path.join(home, ".cache/mise"),
        "MISE_STATE_DIR": os.path.join(home, ".local/state/mise"),
        "MISE_TMP_DIR": os.path.join(home, "tmp"),
        # run non-interactively and trust the fixture config
        "MISE_YES": "1",
        "MISE_TRUSTED_CONFIG_PATHS": workdir,
        "MISE_EXPERIMENTAL": "1",
        "MISE_HISTORY_NOTIFY": "0",
        "MISE_USE_VERSIONS_HOST": "0",
        "LANG": os.environ.get("LANG", "C.UTF-8"),
        "RUST_BACKTRACE": os.environ.get("RUST_BACKTRACE", "1"),
        # OTel-spec-standard endpoint (stable; NOT an implementation choice)
        "OTEL_EXPORTER_OTLP_ENDPOINT": collector.endpoint,
    }
    for d in ("MISE_DATA_DIR", "MISE_CONFIG_DIR", "MISE_CACHE_DIR",
              "MISE_STATE_DIR", "MISE_TMP_DIR"):
        os.makedirs(env[d], exist_ok=True)
    if overrides:
        for k, v in overrides.items():
            if v is None:
                # None removes the variable, e.g. to leave the endpoint unset.
                env.pop(str(k), None)
            else:
                env[str(k)] = str(v)
    return env


def run_mise(tasks, collector: OtlpCollector, env: dict | None = None,
             timeout: float = 90.0):
    """Run `mise run <tasks>` in a fresh isolated workdir against `collector`.

    `tasks` is a task name or list of names (e.g. "all" or ["a", "b"]).

    When you pass a LIST of names, each one is a separate top-level task
    invocation: the names are joined on the mise CLI's own multi-task separator
    `:::` (stable repo syntax — `mise run a ::: b`; see `mise run --help`). This
    matters because `mise run a b` means "run task `a` with argument `b`", NOT
    "run tasks a and b" — so to launch two top-level tasks you MUST separate them
    with `:::`. The harness does that for you, so a list reliably yields one
    top-level task span per name. (A single string / single-element list is just
    `mise run <name>` with no separator.)

    `env` carries whatever extra environment the STORY discovered it must set to
    enable the feature (the trace- and/or log-export opt-ins) plus any
    OTel-standard knob it wants (e.g. OTEL_EXPORTER_OTLP_PROTOCOL).
    The collector's endpoint is wired in for you; a value of None removes that
    variable instead (`{"OTEL_EXPORTER_OTLP_ENDPOINT": None}` leaves no endpoint
    configured).

    Returns a CompletedProcess (inspect `.returncode`, `.stdout`, `.stderr`).
    The isolated workdir/home are removed afterwards; all exported telemetry is
    already captured in the collector.
    """
    if isinstance(tasks, str):
        tasks = [tasks]
    # Interleave multiple top-level tasks with mise's `:::` separator so each name
    # is its own invocation (see docstring). One task => no separator.
    run_args: list[str] = []
    for i, name in enumerate(tasks):
        if i:
            run_args.append(":::")
        run_args.append(str(name))
    workdir = tempfile.mkdtemp(prefix="mise-otel-wd-")
    home = tempfile.mkdtemp(prefix="mise-otel-home-")
    try:
        with open(os.path.join(workdir, "mise.toml"), "w", encoding="utf-8") as fh:
            fh.write(FIXTURE_MISE_TOML)
        full_env = _isolated_env(workdir, home, collector, env)
        proc = subprocess.run(
            [resolve_mise_bin(), "run", *run_args],
            cwd=workdir,
            env=full_env,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return proc
    finally:
        shutil.rmtree(workdir, ignore_errors=True)
        shutil.rmtree(home, ignore_errors=True)
