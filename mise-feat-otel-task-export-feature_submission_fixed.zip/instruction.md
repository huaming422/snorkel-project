## Task

`mise run` should be able to report to an OpenTelemetry collector: a trace of the run and its tasks, and, as a separate option, the lines tasks print on stdout and stderr as log records. Give each option a mise setting that can also be set from an environment variable, and let users enable one without the other. Name them however you like.

The transport is OTLP over HTTP. The collector address comes from `OTEL_EXPORTER_OTLP_ENDPOINT` or the per-signal `OTEL_EXPORTER_OTLP_TRACES_ENDPOINT` and `OTEL_EXPORTER_OTLP_LOGS_ENDPOINT`, extra request headers from `OTEL_EXPORTER_OTLP_HEADERS`, and the encoding from `OTEL_EXPORTER_OTLP_PROTOCOL`: `http/protobuf` unless it's set to `http/json`, with any value it doesn't recognise treated as `http/protobuf`.

The sandbox is offline, and anything the build needs is already in the image.

## User stories / requirements

- Nothing is exported until its switch is on. An OTLP endpoint by itself does nothing, traces enabled with no endpoint send nothing to any address, and task output only goes out as logs with log export enabled. Turning either switch on doesn't change what tasks print or the run's exit status.
- With trace export on, each `mise run` arrives as one trace whose root span is the run itself. The setup work before any task starts, such as installing tools, is recorded under that root, and so is a span for every task.
- If a task's command runs `mise run` again, that nested run is part of the caller's trace rather than a separate one, and its spans hang off the span of the task that launched it.
- If one task exits non-zero and mise kills the siblings still running, only the task that exited non-zero gets error status in the trace, with its exit code on the span. The killed siblings show as cancelled, not failed, and the run's root span ends in error.
- Log export sends each stdout or stderr line a task prints as a single log record, never zero and never two. With traces also on, the record points at the span of the task that printed the line, which for output from a nested `mise run` is the nested task and not its caller.
