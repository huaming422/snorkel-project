## Task

People who run `mise run` in CI and on their own machines want those runs to show up in the same OpenTelemetry backend as the rest of their toolchain. Add OpenTelemetry export to `mise run`: traces for the run and its tasks, plus the tasks' stdout and stderr as log records behind a separate switch. Both switches are off by default.

Export goes over OTLP/HTTP and is configured the usual way, through the standard `OTEL_*` environment variables. There's no network access while you work, but the cargo cache already has everything this needs.

## User stories / requirements

- With an OTLP endpoint configured but trace export left off, running tasks sends nothing to it, and turning trace export on with no endpoint configured sends nothing either. Task output is exported only when the separate log-export switch is on, so no log records leave the machine while only traces are flowing. In all of these runs the tasks' output still prints and `mise run` succeeds as usual.
- With trace export on, a single `mise run` produces one trace: a root span for the whole run, a span covering the tool setup and install phase, and one span per task, each parented under the run span. Spans are sent in the OTLP/HTTP default protobuf encoding, and an unrecognised `OTEL_EXPORTER_OTLP_PROTOCOL` value falls back to that default instead of stopping export.
- When a task's command runs another `mise run`, the nested run joins the same trace as the outer one instead of starting its own, and its span sits under the task that launched it.
- When one task fails and mise stops the others, the task that actually failed is recorded as an error carrying its process exit code, while a sibling that mise stopped is recorded as succeeded but cancelled rather than failed. The run as a whole is recorded as an error.
- With log export on, every line a task prints is exported exactly once as a log record tied to the task that printed it. A line printed by a task inside a nested `mise run` belongs to that nested task, not to the outer task whose output it passes through. The lines still print as they do with log export off.
