## Task

Add OpenTelemetry export to `mise run`, so a run in CI or on someone's laptop can be followed in whatever collector they already use. Two things can be exported: traces for the run and its tasks, and the tasks' stdout and stderr as log records. Each gets its own mise setting with an environment override, and either one works without the other. Pick whatever names fit.

Export is OTLP over HTTP and is configured through the standard `OTEL_EXPORTER_OTLP_*` variables, including the per-signal `OTEL_EXPORTER_OTLP_TRACES_ENDPOINT` and `OTEL_EXPORTER_OTLP_LOGS_ENDPOINT`. `OTEL_EXPORTER_OTLP_PROTOCOL` selects `http/protobuf` (the default) or `http/json`, and an unrecognised value falls back to protobuf.

You'll be offline, but the local cargo registry already holds what you'll need.

## User stories / requirements

- Neither kind of export happens until someone turns it on. A configured OTLP endpoint isn't enough by itself, and turning traces on with no endpoint sends nothing anywhere. Task output goes out as logs only when log export is on. None of this changes what tasks print or whether the run succeeds.
- Each `mise run` with trace export on shows up as a single trace. Its root span covers the whole run and has one child span for the tool setup and install step and one child span for each task.
- A task that calls `mise run` itself doesn't start a second trace. The inner run's spans land in the outer run's trace, below the span of the task that called it.
- When a task fails and mise stops the tasks still running beside it, only the failed task's span is marked as an error, and it records the process exit code. Tasks that mise stopped are marked as cancelled instead of failed. The root span of the run is an error.
- With log export on, every line a task writes to stdout or stderr becomes exactly one log record, tied to that task's span when traces are on too. Lines printed inside a nested `mise run` belong to the inner task, not the one that called it. Exported lines still print as usual.
