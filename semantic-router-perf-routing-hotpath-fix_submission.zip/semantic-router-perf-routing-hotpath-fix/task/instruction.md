## Task

Standalone serving mode has stopped scaling under load. From around 32 concurrent clients its throughput tops out roughly 5 to 10% below envoy mode on the same core budget, and handing it more cores barely lifts the ceiling. It used to keep pace with envoy mode for a given number of cores under concurrency, and now it no longer does.

Dig into why it stops scaling with cores once load ramps up, and fix it so standalone mode scales properly and matches or beats envoy mode at 32 to 64 concurrent clients on the same core budget. This is purely a throughput problem. Behavior and output must stay identical to today: no new functionality, no new config, same results on the same inputs.
