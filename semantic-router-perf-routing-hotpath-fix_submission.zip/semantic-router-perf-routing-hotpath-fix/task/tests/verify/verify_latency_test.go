// Behavioral checks for the per-model latency history read path, exercised
// only through the package's pre-existing exported API
// (ResetTTFT/ResetTPOT, UpdateTTFT/UpdateTPOT, GetTTFTPercentile/
// GetTPOTPercentile). These assertions observe allocation counts and returned
// values; they say nothing about how the history is stored, so any structure
// that keeps the last MaxTTFTHistorySize observations and answers percentiles
// from them satisfies them.
package latency_test

import (
	"math"
	"math/rand/v2"
	"slices"
	"sort"
	"testing"

	latency "github.com/vllm-project/semantic-router/src/semantic-router/pkg/latency"
)

// sinks keep the measured calls from being optimised away.
var (
	sinkFloat float64
	sinkBool  bool
)

// sameFloats compares two slices treating any NaN as equal to any NaN, so the
// expected and observed percentiles agree on the ordering of non-finite inputs.
func sameFloats(a, b float64) bool {
	return a == b || (math.IsNaN(a) && math.IsNaN(b))
}

// expectedPercentile reads the pct percentile from an ascending slice with the
// linear interpolation the package has always used: index = pct*(n-1), lerp
// between the two neighbouring samples. Recomputed here independently so the
// check does not lean on any package-internal helper.
func expectedPercentile(sorted []float64, pct float64) float64 {
	n := len(sorted)
	if n == 0 {
		return 0
	}
	index := pct * float64(n-1)
	lower := int(index)
	upper := lower + 1
	if upper >= n {
		return sorted[n-1]
	}
	weight := index - float64(lower)
	return sorted[lower]*(1-weight) + sorted[upper]*weight
}

// warmFullWindow drives more than MaxTTFTHistorySize positive observations into
// both caches for model, so the sliding window is full, and returns the ordered
// last-MaxTTFTHistorySize values for expected-value computation.
func warmFullWindow(model string, seed1, seed2 uint64) []float64 {
	latency.ResetTTFT()
	latency.ResetTPOT()
	rng := rand.New(rand.NewPCG(seed1, seed2))
	var history []float64
	for i := 0; i < 2*latency.MaxTTFTHistorySize+17; i++ {
		value := 0.05 + rng.Float64()
		history = append(history, value)
		latency.UpdateTTFT(model, value)
		latency.UpdateTPOT(model, value)
	}
	last := slices.Clone(history[len(history)-latency.MaxTTFTHistorySize:])
	sort.Float64s(last)
	return last
}

// After the window is full, reading a percentile must not allocate. The earlier
// read path copied the whole window and sorted the copy under the lock on every
// call; a maintained-order structure answers in place with zero allocations.
//
// Allocation counts measured in the built image (see Phase 7 self-test):
//
//	previous implementation: GetTTFTPercentile ~3 allocs/op (make+copy+sort)
//	current reference example: 0 allocs/op
//
// so "== 0" is the robust post-change bound.
func TestLatencyPercentileReadDoesNotAllocate(t *testing.T) {
	const model = "m-alloc"
	warmFullWindow(model, 1, 2)

	// Prime once so any first-call lazy state is already settled.
	sinkFloat, sinkBool = latency.GetTTFTPercentile(model, 95)
	sinkFloat, sinkBool = latency.GetTPOTPercentile(model, 95)

	if allocs := testing.AllocsPerRun(100, func() {
		sinkFloat, sinkBool = latency.GetTTFTPercentile(model, 95)
	}); allocs != 0 {
		t.Errorf("GetTTFTPercentile allocates %v times per call, want 0", allocs)
	}
	if allocs := testing.AllocsPerRun(100, func() {
		sinkFloat, sinkBool = latency.GetTPOTPercentile(model, 95)
	}); allocs != 0 {
		t.Errorf("GetTPOTPercentile allocates %v times per call, want 0", allocs)
	}
}

// Percentile values are preserved exactly. For a deterministic stream of more
// than 2*MaxTTFTHistorySize observations (including some non-finite values to
// pin ordering), every percentile equals the one computed from a freshly sorted
// copy of the last MaxTTFTHistorySize observations. This blocks a "faster but
// numerically different" change and pins the last-N sliding-window semantics.
func TestLatencyPercentileEqualsSortedWindow(t *testing.T) {
	const model = "m-values"
	latency.ResetTTFT()
	latency.ResetTPOT()

	rng := rand.New(rand.NewPCG(3, 4))
	var history []float64
	for i := 0; i < 2*latency.MaxTTFTHistorySize+41; i++ {
		value := 0.05 + rng.Float64()
		switch rng.IntN(50) {
		case 0:
			value = math.NaN()
		case 1:
			value = math.Inf(1)
		}
		// UpdateTTFT/UpdateTPOT record any value that is not <= 0; the values
		// generated here (positive, NaN, +Inf) are all recorded, so the
		// expected history mirrors them without a skip rule.
		history = append(history, value)
		latency.UpdateTTFT(model, value)
		latency.UpdateTPOT(model, value)
	}

	last := slices.Clone(history[len(history)-latency.MaxTTFTHistorySize:])
	sort.Float64s(last)

	for _, percentile := range []int{1, 10, 20, 50, 80, 95, 100} {
		want := expectedPercentile(last, float64(percentile)/100)

		got, ok := latency.GetTTFTPercentile(model, percentile)
		if !ok || !sameFloats(got, want) {
			t.Errorf("GetTTFTPercentile p%d = %v (ok=%v), want %v", percentile, got, ok, want)
		}
		got, ok = latency.GetTPOTPercentile(model, percentile)
		if !ok || !sameFloats(got, want) {
			t.Errorf("GetTPOTPercentile p%d = %v (ok=%v), want %v", percentile, got, ok, want)
		}
	}
}
