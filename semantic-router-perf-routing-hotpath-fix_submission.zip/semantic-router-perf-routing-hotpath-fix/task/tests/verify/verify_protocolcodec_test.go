// Behavioral check for the per-request exact-field JSON validation path,
// exercised only through the package's pre-existing exported API
// (NewBuiltinEngine, (*Engine).DecodeRequest) under the default policy. The
// assertion observes an allocation count, so it says nothing about how a fix
// avoids rebuilding each wire type's field map on every call: any per-type
// memoization (a sync.Map, a guarded plain map, a per-type sync.Once, or an
// equivalent) that stops recomputing the map from reflection on each request
// satisfies it.
package protocolcodec_test

import (
	"testing"

	"github.com/vllm-project/semantic-router/src/semantic-router/pkg/llmprotocol"
	protocolcodec "github.com/vllm-project/semantic-router/src/semantic-router/pkg/protocolcodec"
)

// sinks keep the measured calls from being optimised away.
var (
	sinkRequest  llmprotocol.Request
	sinkEnvelope llmprotocol.Envelope
)

// maxDecodeRequestAllocs bounds the allocations one DecodeRequest call may make
// on the request path for a fixed, valid OpenAI-chat body under the default
// policy (which rejects unknown fields, so the exact-field validation path runs
// on every request).
//
// Decoding still parses the body and builds the neutral request, so the bound is
// a large constant rather than zero. The earlier code additionally rebuilt each
// visited wire type's JSON field map from reflection on every call, so its count
// sits well above this bound; memoizing the field map per type removes that
// per-request reflection work.
//
// Allocation counts measured in the built image (see Phase 7 self-test):
//
//	previous implementation: DecodeRequest ~222 allocs/op (field map rebuilt per call)
//	current reference example: ~153 allocs/op (field map memoized per type)
//
// K is set strictly between the two measured counts.
const maxDecodeRequestAllocs = 190

// A fixed, valid OpenAI-chat request body. Under the default policy the engine
// rejects unknown fields, so decoding this body drives the exact-field JSON
// validation path (and therefore the per-type field-map lookup) on every call.
var openAIChatBody = []byte(`{"model":"gpt-4","messages":[{"role":"user","content":"hello world"}],"temperature":0.7,"max_tokens":128}`)

// Decoding a request on the hot path stays within a bounded, request-independent
// allocation budget: the per-type JSON field map is not rebuilt from reflection
// on every call.
func TestDecodeRequestStaysWithinAllocationBudget(t *testing.T) {
	engine := protocolcodec.NewBuiltinEngine()

	// Prime once outside the measured region so any first-call per-type state
	// (e.g. a populated field-map cache) is already settled.
	var err error
	sinkRequest, sinkEnvelope, _, err = engine.DecodeRequest(llmprotocol.OpenAIChatV1, openAIChatBody)
	if err != nil {
		t.Fatalf("DecodeRequest: %v", err)
	}

	allocs := testing.AllocsPerRun(100, func() {
		sinkRequest, sinkEnvelope, _, _ = engine.DecodeRequest(llmprotocol.OpenAIChatV1, openAIChatBody)
	})
	if allocs > maxDecodeRequestAllocs {
		t.Errorf("DecodeRequest allocates %v times per call, want <= %d", allocs, maxDecodeRequestAllocs)
	}
}

// Decoding behavior is preserved: a valid OpenAI-chat body decodes without error
// into the expected model and message, and a body carrying an unknown top-level
// field is still rejected under the default policy. This guards against a "fewer
// allocations but different behavior" change to the validation path.
func TestDecodeRequestBehaviorPreserved(t *testing.T) {
	engine := protocolcodec.NewBuiltinEngine()

	request, _, _, err := engine.DecodeRequest(llmprotocol.OpenAIChatV1, openAIChatBody)
	if err != nil {
		t.Fatalf("DecodeRequest(valid body) error: %v", err)
	}
	if request.Model != "gpt-4" {
		t.Errorf("decoded model = %q, want %q", request.Model, "gpt-4")
	}
	if len(request.Messages) != 1 {
		t.Fatalf("decoded %d messages, want 1", len(request.Messages))
	}

	unknownFieldBody := []byte(`{"model":"gpt-4","messages":[{"role":"user","content":"hi"}],"not_a_real_field":true}`)
	if _, _, _, err := engine.DecodeRequest(llmprotocol.OpenAIChatV1, unknownFieldBody); err == nil {
		t.Error("DecodeRequest(body with unknown field) = nil error, want an error under the default reject policy")
	}
}
