// Behavioral checks for provider-operation resolution, exercised only through
// the package's pre-existing exported API (BuiltIn, (*Registry).ResolveOperation,
// (*Registry).ResolveOperationPath, (*Registry).Provider). The assertions
// observe allocation counts and returned paths/errors, so any resolution that
// reads the catalog without a per-call deep copy, under whatever internal view,
// satisfies them.
package catalog_test

import (
	"testing"

	modelcatalog "github.com/vllm-project/semantic-router/src/semantic-router/pkg/catalog"
)

var sinkResolved modelcatalog.ResolvedOperation

// maxResolveOperationAllocs bounds the allocations one ResolveOperation call may
// make on the request path.
//
// Resolution still builds a small ResolvedOperation and does a little string
// work, so the bound is a low constant rather than zero. The earlier code
// additionally made a full defensive copy of the matched provider on every call
// (its string/slice/map collections plus every per-model nested collection), so
// its count scales with catalog size and sits far above this bound.
//
// Allocation counts measured in the built image (see Phase 7 self-test):
//
//	previous implementation: ResolveOperation ~14 allocs/op (provider deep copy)
//	current reference example: ~1 alloc/op
//
// K is set strictly between the two measured counts.
const maxResolveOperationAllocs = 5

// Resolving a provider operation on the request path stays within a small,
// catalog-size-independent allocation budget.
func TestResolveOperationStaysWithinAllocationBudget(t *testing.T) {
	registry, err := modelcatalog.BuiltIn()
	if err != nil {
		t.Fatalf("BuiltIn: %v", err)
	}

	// Prime once outside the measured region.
	sinkResolved, _ = registry.ResolveOperation("openai", "openai/responses@1", "create", "/v1")

	allocs := testing.AllocsPerRun(100, func() {
		sinkResolved, _ = registry.ResolveOperation("openai", "openai/responses@1", "create", "/v1")
	})
	if allocs > maxResolveOperationAllocs {
		t.Errorf("ResolveOperation allocates %v times per call, want <= %d", allocs, maxResolveOperationAllocs)
	}
}

// Resolution results and error cases are preserved. The happy-path tuples and
// their expected paths come from the catalog's own pre-existing resolution
// tests; the error cases exercise the unknown-provider, unknown-protocol and
// unsupported-operation branches.
func TestResolveOperationBehaviorPreserved(t *testing.T) {
	registry, err := modelcatalog.BuiltIn()
	if err != nil {
		t.Fatalf("BuiltIn: %v", err)
	}

	resolved := []struct {
		name                   string
		provider               string
		protocol               string
		operation              string
		basePath               string
		wantPath               string
		wantUseAPIVersionQuery bool
	}{
		{"OpenAI Responses", "openai", "openai/responses@1", "create", "/v1", "/v1/responses", false},
		{"custom API root", "openai", "openai/chat-completions@1", "create", "/v1beta/openai", "/v1beta/openai/chat/completions", false},
		{"Anthropic inventory", "anthropic", "", "list_models", "", "/v1/models", false},
		{"Azure default Chat", "azure-openai", "", "create", "/openai/deployments/astra-prod", "/openai/deployments/astra-prod/chat/completions", true},
		{"Azure Responses", "azure-openai", "openai/responses@1", "create", "/openai/deployments/astra-prod", "/openai/v1/responses", false},
	}
	for _, tc := range resolved {
		t.Run(tc.name, func(t *testing.T) {
			got, err := registry.ResolveOperation(tc.provider, tc.protocol, tc.operation, tc.basePath)
			if err != nil {
				t.Fatalf("ResolveOperation(%q,%q,%q,%q) error: %v",
					tc.provider, tc.protocol, tc.operation, tc.basePath, err)
			}
			if got.Path != tc.wantPath {
				t.Errorf("path = %q, want %q", got.Path, tc.wantPath)
			}
			if got.UseAPIVersionQuery != tc.wantUseAPIVersionQuery {
				t.Errorf("UseAPIVersionQuery = %t, want %t", got.UseAPIVersionQuery, tc.wantUseAPIVersionQuery)
			}
			// ResolveOperationPath is the thin wrapper over ResolveOperation.
			path, err := registry.ResolveOperationPath(tc.provider, tc.protocol, tc.operation, tc.basePath)
			if err != nil || path != tc.wantPath {
				t.Errorf("ResolveOperationPath = %q (err %v), want %q", path, err, tc.wantPath)
			}
		})
	}

	errorCases := []struct {
		name      string
		provider  string
		protocol  string
		operation string
		basePath  string
	}{
		{"unknown provider", "no-such-provider", "", "create", ""},
		{"unknown protocol", "openai", "anthropic/messages@1", "create", ""},
		{"unsupported operation", "openai", "", "delete_model", ""},
		{"operation off provider", "azure-openai", "", "list_models", ""},
	}
	for _, tc := range errorCases {
		t.Run(tc.name, func(t *testing.T) {
			if _, err := registry.ResolveOperationPath(tc.provider, tc.protocol, tc.operation, tc.basePath); err == nil {
				t.Errorf("ResolveOperationPath(%q,%q,%q,%q) = nil error, want an error",
					tc.provider, tc.protocol, tc.operation, tc.basePath)
			}
		})
	}
}

// Provider(id) still returns a deep, caller-mutation-safe copy: mutating the
// collections of one returned value must not affect a later call. The
// request-path resolution dropping its copy must not weaken this guarantee for
// the general accessor.
func TestProviderReturnsMutationSafeCopy(t *testing.T) {
	registry, err := modelcatalog.BuiltIn()
	if err != nil {
		t.Fatalf("BuiltIn: %v", err)
	}

	first, ok := registry.Provider("openai")
	if !ok {
		t.Fatal("Provider(openai) not found")
	}
	if len(first.Protocols) == 0 && len(first.SupportedOperations) == 0 && first.DefaultHeaders == nil {
		t.Skip("openai provider exposes no mutable collection to probe")
	}

	wantProtocols := append([]string(nil), first.Protocols...)
	wantSupported := append([]string(nil), first.SupportedOperations...)

	// Mutate every collection the caller can reach on the returned copy.
	for i := range first.Protocols {
		first.Protocols[i] = "mutated"
	}
	for i := range first.SupportedOperations {
		first.SupportedOperations[i] = "mutated"
	}
	for k := range first.DefaultHeaders {
		first.DefaultHeaders[k] = "mutated"
	}
	for k := range first.PathOverrides {
		first.PathOverrides[k] = "mutated"
	}

	second, ok := registry.Provider("openai")
	if !ok {
		t.Fatal("second Provider(openai) not found")
	}
	for i, want := range wantProtocols {
		if second.Protocols[i] != want {
			t.Errorf("Protocols[%d] = %q after mutating an earlier copy, want %q", i, second.Protocols[i], want)
		}
	}
	for i, want := range wantSupported {
		if second.SupportedOperations[i] != want {
			t.Errorf("SupportedOperations[%d] = %q after mutating an earlier copy, want %q", i, second.SupportedOperations[i], want)
		}
	}
}
