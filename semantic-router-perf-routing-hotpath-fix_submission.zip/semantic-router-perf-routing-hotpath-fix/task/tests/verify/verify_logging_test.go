// Behavioral checks for the event logging helpers, exercised only through the
// package's pre-existing exported API (ComponentEvent, LogEvent, WarnEvent,
// DebugEvent) and zap's public test observer. The assertions observe allocation
// counts, emitted fields, levels, messages and sampler keep/drop counts, so any
// helper that consults the logger's level/sampler decision before building and
// encoding fields satisfies them.
package logging_test

import (
	"testing"
	"time"

	logging "github.com/vllm-project/semantic-router/src/semantic-router/pkg/observability/logging"
	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
	"go.uber.org/zap/zaptest/observer"
)

// observeGlobal routes the global logger to an in-memory observer behind a
// sampler that keeps the first two entries of each message within a long tick
// and drops the rest, mirroring the shape of the production sampler. It returns
// the observed-log handle and restores the previous global logger on cleanup.
func observeGlobal(t *testing.T) *observer.ObservedLogs {
	t.Helper()
	core, logs := observer.New(zapcore.InfoLevel)
	sampled := zapcore.NewSamplerWithOptions(core, time.Hour, 2, 0)
	restore := zap.ReplaceGlobals(zap.New(sampled))
	t.Cleanup(restore)
	return logs
}

// A message the sampler drops must cost no allocation: once a message is primed
// past the sampler, further events for it build and encode nothing. The earlier
// helper assembled the field list and attached it to the logger before the
// sampler dropped the entry, allocating on every call.
//
// Allocation counts measured in the built image (see Phase 7 self-test):
//
//	previous implementation: ComponentEvent ~4 allocs/op for a dropped entry
//	current reference example: 0 allocs/op
//
// so "== 0" is the robust post-change bound.
func TestDroppedEventDoesNotAllocate(t *testing.T) {
	observeGlobal(t)
	fields := map[string]interface{}{"path": "/v1/chat/completions", "response_code": 200}

	// Prime the message past the sampler's keep count so every measured call
	// is a dropped entry.
	logging.ComponentEvent("gateway", "access", fields)
	logging.ComponentEvent("gateway", "access", fields)

	if allocs := testing.AllocsPerRun(100, func() {
		logging.ComponentEvent("gateway", "access", fields)
	}); allocs != 0 {
		t.Errorf("a dropped event allocates %v times, want 0", allocs)
	}
}

// Field content and precedence are preserved: ComponentEvent adds the event name
// and component when the caller omits them, the caller's own event/component
// values win when supplied, LogEvent adds only the event name, and the entry is
// written at Info level with the event name as its message.
func TestComponentEventFieldsAndPrecedence(t *testing.T) {
	logs := observeGlobal(t)

	logging.ComponentEvent("gateway", "access", map[string]interface{}{"response_code": 200, "path": "/v1/models"})
	logging.ComponentEvent("gateway", "custom", map[string]interface{}{"event": "own", "component": "own-component"})
	logging.LogEvent("plain", map[string]interface{}{"n": int64(3)})

	entries := logs.All()
	if len(entries) != 3 {
		t.Fatalf("got %d entries, want 3", len(entries))
	}
	want := []map[string]interface{}{
		{"response_code": int64(200), "path": "/v1/models", "event": "access", "component": "gateway"},
		{"event": "own", "component": "own-component"},
		{"n": int64(3), "event": "plain"},
	}
	for i, entry := range entries {
		got := entry.ContextMap()
		if len(got) != len(want[i]) {
			t.Errorf("entry %d fields = %v, want %v", i, got, want[i])
			continue
		}
		for key, value := range want[i] {
			if got[key] != value {
				t.Errorf("entry %d field %s = %v, want %v", i, key, got[key], value)
			}
		}
	}
	if entries[0].Message != "access" || entries[0].Level != zapcore.InfoLevel {
		t.Errorf("entry 0 = %s %q, want info \"access\"", entries[0].Level, entries[0].Message)
	}
}

// Sampler keep/drop decisions are preserved and happen independent of field
// construction: the first two of a repeated message pass and the rest drop, a
// warn event passes the same way, and a debug event at Info level is dropped.
func TestSamplerDecisionsPreserved(t *testing.T) {
	logs := observeGlobal(t)

	for i := 0; i < 5; i++ {
		logging.ComponentEvent("gateway", "access", map[string]interface{}{"i": i})
		logging.WarnEvent("warned", nil)
	}
	logging.DebugEvent("disabled", map[string]interface{}{"i": 1})

	if got := logs.FilterMessage("access").Len(); got != 2 {
		t.Errorf("access entries = %d, want 2", got)
	}
	if got := logs.FilterMessage("warned").Len(); got != 2 {
		t.Errorf("warned entries = %d, want 2", got)
	}
	if got := logs.FilterMessage("disabled").Len(); got != 0 {
		t.Errorf("debug entries = %d, want 0", got)
	}
}
