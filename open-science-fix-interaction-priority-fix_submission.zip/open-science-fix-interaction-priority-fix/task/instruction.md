## Task

Getting reports of lost permission prompts after a restart. Say someone has a
couple of sessions open and one of them is parked waiting on a permission (or a
plan approval) when they quit. After relaunching, the moment they answer a
*different* session's question, the parked session drops its "waiting for you"
marker in the sidebar, and the tool it was blocked on is stuck with no way to
approve or deny it. It doesn't recover on its own; only another restart
brings the prompt back. Can you dig into what's clobbering that waiting state
and fix it?
