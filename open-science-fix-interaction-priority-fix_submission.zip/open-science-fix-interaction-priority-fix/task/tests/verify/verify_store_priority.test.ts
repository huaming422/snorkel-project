import { beforeEach, describe, expect, it, vi } from 'vitest'

import type { ActivePlanProjection } from '../../../shared/session-plan/contract'
import type { PersistedChatSession } from '../../../shared/session-persistence'
import {
  createInitialSessionState,
  toPersistedSession,
  useSessionStore
} from './session-store'

// A pending plan-approval projection, shaped exactly like the one the store
// consumes through setActivePlanProjection. Only durable fields matter here.
const pendingPlan = (artifactVersionId: string): ActivePlanProjection => ({
  artifactId: `artifact-${artifactVersionId}`,
  artifactVersionId,
  artifactChecksum: 'a'.repeat(64),
  revision: 1,
  approval: 'pending',
  lifecycle: 'awaiting_approval',
  requiresExplicitContinuation: false,
  document: {
    schema_version: 1,
    task_summary: `Plan ${artifactVersionId}`,
    phases: [
      {
        name: 'Analysis',
        delegations: [
          {
            name: 'Primary agent',
            steps: [{ title: `Step ${artifactVersionId}`, description: 'Do the work.' }]
          }
        ]
      }
    ],
    desired_outputs: [],
    feasibility: { confidence: 'high', rationale: 'Inputs are available.' }
  },
  stepStatuses: {},
  stepStates: { Step: { status: 'not_started' } },
  counts: { phases: 1, delegations: 1, steps: 1, completed: 0, inProgress: 0 }
})

const statusOf = (sessionId: string): string | undefined =>
  useSessionStore.getState().sessions.find((session) => session.id === sessionId)?.status

describe('interaction-priority store projections', () => {
  beforeEach(() => {
    vi.useFakeTimers()
    vi.setSystemTime(new Date('2026-07-04T08:00:00.000Z'))
    useSessionStore.setState(createInitialSessionState())
  })

  // Permission outranks a simultaneously-pending plan approval, and clearing
  // the permission then reveals the still-pending plan. Observed purely via status.
  it('shows the permission ahead of a pending plan, then reveals the plan once it clears', () => {
    useSessionStore.getState().appendUserMessage({
      sessionId: 'session-1',
      content: 'Run the workflow',
      cwd: '/workspace',
      projectId: 'project-1'
    })
    useSessionStore.getState().setActivePlanProjection('session-1', pendingPlan('version-1'))
    expect(statusOf('session-1')).toBe('waiting-plan-approval')

    useSessionStore.getState().setPermissionPending('session-1')
    expect(statusOf('session-1')).toBe('waiting-permission')

    useSessionStore.getState().clearPermissionPending('session-1')
    expect(statusOf('session-1')).toBe('waiting-plan-approval')
  })

  // Settled-plan arm: when the plan has settled while the permission was up,
  // clearing the permission drops the session to idle rather than back to waiting.
  it('returns to idle when the permission clears after its plan already settled', () => {
    useSessionStore.getState().hydrateSessions([
      {
        id: 'session-1',
        projectId: 'project-1',
        title: 'Plan approval',
        cwd: '/workspace',
        status: 'waiting-plan-approval',
        runtimeContext: {
          version: 1,
          revision: 1,
          plan: {
            artifactId: 'plan-1',
            artifactVersionId: 'plan-version-1',
            artifactChecksum: 'a'.repeat(64),
            approval: 'pending',
            stepStatuses: {}
          }
        },
        messages: [],
        createdAt: 1,
        updatedAt: 2
      }
    ])
    useSessionStore.getState().setPermissionPending('session-1')
    const source = useSessionStore.getState().sessions[0]
    expect(source.status).toBe('waiting-permission')

    // A durable projection arrives with the plan approved (settled) while the
    // permission is still outstanding; the permission must stay in front.
    useSessionStore.getState().applyDurableSessionProjection({
      source,
      session: {
        ...toPersistedSession(source),
        status: 'idle',
        runtimeContext: {
          version: 1,
          revision: 2,
          plan: {
            artifactId: 'plan-1',
            artifactVersionId: 'plan-version-1',
            artifactChecksum: 'a'.repeat(64),
            approval: 'approved',
            stepStatuses: {}
          }
        },
        updatedAt: source.updatedAt + 10
      }
    })
    expect(statusOf('session-1')).toBe('waiting-permission')

    useSessionStore.getState().clearPermissionPending('session-1')
    expect(statusOf('session-1')).toBe('idle')
  })

  // The transient waiting view is rebuilt from durable facts on restore, but
  // is never written back into persisted storage. Restore a session carrying both
  // a durable permission and a durable question, assert the waiting status is
  // reconstructed, then confirm the round-trip to persisted form drops any
  // transient interaction bookkeeping and that clearing the permission falls back
  // to the still-pending question (not to idle).
  it('reconstructs the waiting view on restore without persisting transient facts', () => {
    const restored: PersistedChatSession = {
      id: 'session-restored',
      projectId: 'project-1',
      title: 'Restored interactions',
      cwd: '/workspace',
      status: 'waiting-permission',
      runtimeContext: {
        version: 1,
        revision: 1,
        permission: {
          state: 'pending',
          request: {
            requestId: 'permission-restored',
            sessionId: 'session-restored',
            toolCallId: 'permission-tool',
            title: 'Run npm test',
            options: [{ optionId: 'allow-once', name: 'Allow once', kind: 'allow_once' }]
          },
          originatingPromptMessageId: 'prompt-1',
          fingerprint: 'a'.repeat(64),
          createdAt: 1
        }
      },
      messages: [
        {
          id: 'prompt-1',
          role: 'user',
          content: 'Run the workflow',
          status: 'complete',
          eventIds: [],
          createdAt: 1,
          updatedAt: 1
        }
      ],
      activities: [
        {
          id: 'ask-tool',
          kind: 'tool',
          title: 'Choose an approach',
          status: 'in_progress',
          eventIds: [],
          sortIndex: 1,
          elicitation: {
            message: 'Choose an approach',
            fields: [{ id: 'question_0', label: 'Approach', kind: 'text' }],
            state: 'pending',
            durable: { kind: 'agent-user-choice', requestId: 'choice-restored' }
          },
          createdAt: 1,
          updatedAt: 1
        }
      ],
      createdAt: 1,
      updatedAt: 2
    }

    useSessionStore.getState().hydrateSessions([restored])

    // Permission outranks the question: the reconstructed status is the permission.
    expect(statusOf('session-restored')).toBe('waiting-permission')

    // The transient bookkeeping must not leak into persisted storage.
    const persisted = toPersistedSession(useSessionStore.getState().sessions[0])
    expect(persisted).not.toHaveProperty('interactionState')

    // Clearing the (settled) permission must fall back to the restored question,
    // proving the question fact survived and was independently tracked.
    useSessionStore.getState().clearPermissionPending('session-restored', { authority: 'settled' })
    expect(statusOf('session-restored')).toBe('waiting-for-user')
  })
})
