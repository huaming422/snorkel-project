import type { AcpPermissionRequest, AcpStateSnapshot } from '../../../../shared/acp'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import { createInitialSessionState, useSessionStore } from '../../stores/session-store'
import { respondToWorkspaceElicitation } from './workspace-elicitation-runtime'
import {
  resetWorkspaceRuntimeEventOwnerForTests,
  syncWorkspaceElicitationState,
  syncWorkspacePermissionState
} from './workspace-runtime-event-owner'

const createSnapshot = (sessionIds: string[] = []): AcpStateSnapshot => ({
  status: 'connected',
  cwd: '/workspace/project',
  sessionIds,
  events: [],
  pendingPermissions: [],
  permissionProfiles: {},
  permissionGrants: {},
  contextUsageBySession: {},
  promptInFlight: false,
  promptInFlightSessionIds: []
})

const elicitationRequest = {
  requestId: 'choice-1',
  sessionId: 'session-choice-1',
  toolCallId: 'tool-choice-1',
  message: 'Choose an approach',
  fields: [{ id: 'question_0', label: 'Approach', kind: 'text' as const }],
  durable: { kind: 'agent-user-choice' as const, requestId: 'choice-1' }
}

const statusOf = (sessionId: string): string | undefined =>
  useSessionStore.getState().sessions.find((session) => session.id === sessionId)?.status

describe('interaction-priority runtime reconciliation', () => {
  beforeEach(() => {
    resetWorkspaceRuntimeEventOwnerForTests()
    useSessionStore.setState(createInitialSessionState())
    useSessionStore.getState().appendUserMessage({
      sessionId: 'session-choice-1',
      content: 'Build something',
      cwd: '/workspace/project',
      projectId: 'project-1',
      agentFrameworkId: 'opencode',
      agentBackendId: 'opencode:provider-1'
    })
    useSessionStore.getState().finishRun('session-choice-1')
  })

  afterEach(() => {
    vi.unstubAllGlobals()
  })

  // The headline reproduction. One session holds a restored durable
  // permission; a second session holds a durable question. Answering the second
  // session's question must not strip the first session's waiting-permission state,
  // and its pending permission authority must remain intact.
  it('keeps a restored permission waiting after another session answers its question', async () => {
    const permissionRequest: AcpPermissionRequest = {
      requestId: 'permission-restored',
      sessionId: 'session-permission-1',
      toolCallId: 'tool-permission-1',
      title: 'Run npm test',
      options: [{ optionId: 'allow-once', name: 'Allow once', kind: 'allow_once' }],
      durable: true
    }
    useSessionStore.getState().appendUserMessage({
      sessionId: permissionRequest.sessionId,
      content: 'Run the verification',
      cwd: '/workspace/project',
      projectId: 'project-1'
    })
    useSessionStore.getState().finishRun(permissionRequest.sessionId)
    useSessionStore.setState((state) => ({
      sessions: state.sessions.map((session) =>
        session.id === permissionRequest.sessionId
          ? {
              ...session,
              status: 'waiting-permission',
              runtimeContext: {
                version: 1,
                revision: 1,
                permission: {
                  state: 'pending',
                  request: permissionRequest,
                  originatingPromptMessageId: session.messages[0].id,
                  fingerprint: 'a'.repeat(64),
                  createdAt: 1
                }
              }
            }
          : session
      )
    }))
    syncWorkspacePermissionState([permissionRequest])
    useSessionStore.getState().setElicitationPending('session-choice-1', true)

    await respondToWorkspaceElicitation(
      {
        state: createSnapshot(['session-choice-1']),
        resumeSession: vi.fn(),
        respondToElicitation: vi.fn().mockResolvedValue(createSnapshot(['session-choice-1']))
      },
      {
        requestId: 'choice-1',
        action: 'accept',
        answers: [{ fieldId: 'question_0', value: 'Minimal' }],
        request: {
          requestId: 'choice-1',
          sessionId: 'session-choice-1',
          toolCallId: 'tool-choice-1',
          message: 'Choose an approach',
          fields: [{ id: 'question_0', label: 'Approach', kind: 'text' }],
          durable: { kind: 'agent-user-choice', requestId: 'choice-1' }
        }
      }
    )

    const parked = useSessionStore
      .getState()
      .sessions.find((session) => session.id === permissionRequest.sessionId)
    expect(parked?.status).toBe('waiting-permission')
    expect(parked?.runtimeContext?.permission?.state).toBe('pending')
  })

  // Same-session fallback. A session carries both a pending permission and a
  // durable question; answering the question (with a snapshot that still carries
  // the permission) must leave the session waiting on the permission, not running.
  it('falls back to a pending permission in the same session after its question is answered', async () => {
    const permissionRequest: AcpPermissionRequest = {
      requestId: 'permission-live',
      sessionId: 'session-choice-1',
      toolCallId: 'tool-permission-live',
      title: 'Run npm test',
      options: [{ optionId: 'allow-once', name: 'Allow once', kind: 'allow_once' }]
    }
    syncWorkspacePermissionState([permissionRequest])
    syncWorkspaceElicitationState([elicitationRequest])
    const continued = {
      ...createSnapshot(['session-choice-1']),
      pendingPermissions: [permissionRequest],
      pendingElicitations: []
    }

    await respondToWorkspaceElicitation(
      {
        state: {
          ...createSnapshot(['session-choice-1']),
          pendingPermissions: [permissionRequest],
          pendingElicitations: [elicitationRequest]
        },
        resumeSession: vi.fn(),
        respondToElicitation: vi.fn().mockResolvedValue(continued)
      },
      {
        requestId: elicitationRequest.requestId,
        action: 'accept',
        answers: [{ fieldId: 'question_0', value: 'Minimal' }],
        request: elicitationRequest
      }
    )

    expect(statusOf('session-choice-1')).toBe('waiting-permission')
  })

  // An already-answered question is not re-armed when a permission later
  // becomes pending in the same session; once both settle the session is idle with
  // neither interaction still pending. Observed via status plus the absence of any
  // lingering pending permission in runtimeContext.
  it('does not re-arm an answered question when a permission later becomes pending', () => {
    const request = {
      requestId: 'choice-1',
      sessionId: 'session-choice-1',
      toolCallId: 'tool-choice-1',
      message: 'Choose an approach',
      fields: [{ id: 'question_0', label: 'Approach', kind: 'text' as const }],
      durable: { kind: 'agent-user-choice' as const, requestId: 'choice-1' }
    }
    useSessionStore.setState((state) => ({
      sessions: state.sessions.map((session) =>
        session.id === request.sessionId
          ? {
              ...session,
              status: 'waiting-for-user',
              activities: [
                {
                  id: request.toolCallId,
                  kind: 'tool',
                  title: 'Waiting for an answer',
                  status: 'in_progress',
                  sortIndex: 1,
                  eventIds: [],
                  elicitation: {
                    message: request.message,
                    fields: request.fields,
                    state: 'pending',
                    durable: request.durable
                  },
                  createdAt: Date.now(),
                  updatedAt: Date.now()
                }
              ]
            }
          : session
      )
    }))

    syncWorkspaceElicitationState([request])
    useSessionStore.getState().setElicitationPending(request.sessionId, false)
    useSessionStore.getState().setPermissionPending(request.sessionId)
    syncWorkspaceElicitationState([])
    useSessionStore.getState().clearPermissionPending(request.sessionId)

    const settled = useSessionStore
      .getState()
      .sessions.find((session) => session.id === request.sessionId)
    expect(settled?.status).toBe('idle')
    expect(settled?.runtimeContext?.permission?.state).not.toBe('pending')
  })
})
