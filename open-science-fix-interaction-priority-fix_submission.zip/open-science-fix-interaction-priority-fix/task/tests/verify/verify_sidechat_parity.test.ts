// @vitest-environment jsdom
import { act, createElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, describe, expect, it, vi } from 'vitest'

import type { ChatSession, SessionStatus } from '@/stores/session-store'

import type { ComposerDoc } from './composer/composer-doc'
import {
  useWorkspaceConversationController,
  type WorkspaceConversationController,
  type WorkspaceConversationControllerOptions
} from './workspace-conversation-controller'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true

const textDoc = (text: string): ComposerDoc => ({ nodes: [{ type: 'text', text }] })

const session = (overrides: Partial<ChatSession> = {}): ChatSession => ({
  id: 'session-a',
  projectId: 'project-a',
  title: 'Session A',
  cwd: '/workspace/project-a',
  status: 'idle',
  messages: [
    {
      id: 'message-user-a',
      role: 'user',
      content: 'First main prompt',
      status: 'complete',
      eventIds: [],
      createdAt: 1,
      updatedAt: 1
    }
  ],
  createdAt: 1,
  updatedAt: 1,
  ...overrides
})

const options = (
  overrides: Partial<WorkspaceConversationControllerOptions> = {}
): WorkspaceConversationControllerOptions => {
  const doc = textDoc('hello')
  return {
    activeSession: session(),
    projectId: 'project-a',
    currentDraftKey: 'session-a',
    isPersistenceReady: true,
    supportsImageInput: true,
    permissionProfile: 'full',
    isReviewing: false,
    promptInFlightSessionIds: [],
    sendPreparationInFlightSessionIds: [],
    newConversationAutoReviewEnabled: false,
    newConversationEnabledComputeHosts: [],
    composer: {
      view: { doc, attachments: [], transfers: [] },
      actions: { setError: vi.fn() },
      lifecycle: {
        captureSend: vi.fn(() => ({
          draftKey: 'session-a',
          version: 1,
          doc,
          attachments: []
        })),
        clearDraft: vi.fn(),
        restoreFailedSend: vi.fn()
      }
    },
    session: {
      view: { deletingIds: new Set(), specialist: { barrierInFlight: false } },
      actions: {
        beginReconfigureRetry: vi.fn(() => true),
        resetNewConversationSpecialist: vi.fn(),
        confirmDelete: vi.fn()
      },
      lifecycle: {
        canStartSend: vi.fn(() => true),
        captureSendIntent: vi.fn(() => ({
          draftSpecialistId: undefined,
          hasPendingSwitch: false,
          pendingSpecialistId: undefined
        })),
        prepareSpecialistSend: vi.fn(() => Promise.resolve(true)),
        isBarrierInFlight: vi.fn(() => false)
      }
    },
    runtime: {
      sendMessage: vi.fn(() => Promise.resolve({ sessionId: 'session-a', messageId: 'message-a' })),
      resendEditedMessage: vi.fn(() => Promise.resolve(true)),
      cancelRun: vi.fn(() => Promise.resolve()),
      resumeInterruptedSession: vi.fn(() => Promise.resolve())
    },
    sideChatOpen: false,
    setAutoReviewEnabled: vi.fn(),
    setEnabledComputeHosts: vi.fn(),
    resetNewConversationSettings: vi.fn(),
    syncComputeHosts: vi.fn(() => Promise.resolve()),
    abortFixLoop: vi.fn(() => Promise.resolve()),
    getSession: (sessionId) => (sessionId === 'session-a' ? session() : undefined),
    ...overrides
  }
}

type Hook = {
  result: { current: WorkspaceConversationController }
  rerender: (next: WorkspaceConversationControllerOptions) => void
  unmount: () => void
}

const renderController = (initial: WorkspaceConversationControllerOptions): Hook => {
  let current = initial
  const container = document.createElement('div')
  const root: Root = createRoot(container)
  const result = { current: undefined as unknown as WorkspaceConversationController }
  const Harness = (): null => {
    result.current = useWorkspaceConversationController(current)
    return null
  }
  const render = (): void => act(() => root.render(createElement(Harness)))
  render()
  return {
    result,
    rerender: (next): void => {
      current = next
      render()
    },
    unmount: (): void => act(() => root.unmount())
  }
}

const mounted: Hook[] = []

afterEach(() => {
  for (const hook of mounted.splice(0)) hook.unmount()
  vi.restoreAllMocks()
})

describe('interaction-priority side-chat parity', () => {
  // A session awaiting plan approval blocks a new side chat exactly as a
  // pending permission or question already does. Parity is asserted across all
  // three waiting statuses so a fix that only special-cases two of them is caught.
  it.each(['waiting-for-user', 'waiting-permission', 'waiting-plan-approval'] as const)(
    'does not start a side chat while the main session is %s',
    (status: SessionStatus) => {
      const input = options({
        activeSession: session({ status }),
        sideChat: { start: vi.fn(async () => true) }
      })
      const hook = renderController(input)
      mounted.push(hook)

      act(() => hook.result.current.actions.sideChat.start())

      expect(input.sideChat?.start).not.toHaveBeenCalled()
      expect(input.composer.lifecycle.clearDraft).not.toHaveBeenCalled()
    }
  )

  // Sanity anchor: an idle session with the same non-empty draft DOES start a side
  // chat, proving the block above is specific to the waiting statuses rather than a
  // blanket refusal that would pass vacuously.
  it('starts a side chat for an idle session with a non-empty draft', async () => {
    const input = options({ sideChat: { start: vi.fn(async () => true) } })
    const hook = renderController(input)
    mounted.push(hook)

    act(() => hook.result.current.actions.sideChat.start())
    await vi.waitFor(() => expect(input.sideChat?.start).toHaveBeenCalledWith('hello'))
  })
})
