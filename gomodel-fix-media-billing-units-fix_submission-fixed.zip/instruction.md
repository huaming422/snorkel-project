## Task

Finance can't get the media rows in our usage log to match what the providers bill us.
It's image generations and edits, plus audio transcriptions and translations.
Chat and the other text endpoints reconcile fine.
Depending on the provider and the response, a media call gets costed too high, too low, or not at all.

Whatever usage the provider reports is what we were billed for.
If a media response comes back with token counts, the cost is those tokens and nothing on top.
A per_image or per-second price only applies when the response has no token counts.

A transcription or translation on a per-second model still has to be charged when the provider sends no usage.
Use the length of the audio the client uploaded, and make sure WAV and MP3 uploads work.

The ai-model-list catalog we load already publishes output_image_per_mtok for image models, separate from output_per_mtok.
Image generation and edit calls should price generated image tokens at that rate, while chat on the same model stays on output_per_mtok.

When a call can't be fully priced, say output tokens came back with no rate or the upload can't be measured, don't make up an amount.
Leave a note in costs_calculation_caveat saying what was missing, so the row doesn't read as a cheap or free call.
