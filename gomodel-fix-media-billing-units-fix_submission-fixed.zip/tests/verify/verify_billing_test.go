// Behavioral checks for media usage/cost accounting.
//
// These tests drive the server services (audioService, imageService, and the
// chat handler) end to end with the package's own mock provider and capturing
// usage logger, then read the *usage.UsageEntry those services hand to the
// logger. They look at two things only: the recorded dollar amount (with a
// float tolerance) and whether the row carries a cost-calculation note. Field
// names, note wording and internal helpers are not part of the contract.
//
// Pricing comes in two ways. Most tests build a core.ModelPricing from the
// rate fields that already exist at the base commit. The image-output-rate
// tests decode a model catalog document through modeldata.Parse and
// modeldata.Resolve instead, because output_image_per_mtok is a key the
// upstream ai-model-list catalog publishes and the gateway reads by default.
//
// Uploads carry a realistic filename and part Content-Type, so the container
// can be identified from the bytes, the extension or the declared type.

package server

import (
	"bytes"
	"fmt"
	"mime/multipart"
	"net/http"
	"net/http/httptest"
	"net/textproto"
	"strings"
	"testing"

	"github.com/labstack/echo/v5"

	"github.com/enterpilot/gomodel/internal/core"
	"github.com/enterpilot/gomodel/internal/modeldata"
	"github.com/enterpilot/gomodel/internal/usage"
)

// costTol is the absolute tolerance for recorded-dollar comparisons. The
// amounts under test differ between correct and incorrect accounting by far
// more than this, so the bound only absorbs float rounding.
const costTol = 1e-6

// newAudioMock builds an audio provider whose transcription and translation
// both return body, supporting model for routing.
func newAudioMock(model, body string) *audioMockProvider {
	resp := &core.AudioResponse{ContentType: "application/json", Data: []byte(body)}
	return &audioMockProvider{
		mockProvider:      &mockProvider{supportedModels: []string{model}},
		transcriptionResp: resp,
		translationResp:   resp,
	}
}

// newAudioUpload builds a multipart speech-to-text request carrying audio under
// the given endpoint. It omits transcription-only form fields so the same
// builder works for both the transcription and translation endpoints.
func newAudioUpload(endpoint, model, filename, contentType string, audio []byte) (*echo.Context, *httptest.ResponseRecorder) {
	var buf bytes.Buffer
	w := multipart.NewWriter(&buf)
	_ = w.WriteField("model", model)
	h := make(textproto.MIMEHeader)
	h.Set("Content-Disposition", fmt.Sprintf(`form-data; name="file"; filename=%q`, filename))
	h.Set("Content-Type", contentType)
	part, _ := w.CreatePart(h)
	_, _ = part.Write(audio)
	_ = w.Close()

	req := httptest.NewRequest(http.MethodPost, endpoint, &buf)
	req.Header.Set("Content-Type", w.FormDataContentType())
	rec := httptest.NewRecorder()
	return echo.New().NewContext(req, rec), rec
}

// audioUpload is one uploaded speech-to-text file.
type audioUpload struct {
	filename    string
	contentType string
	data        []byte
}

func wavUpload(seconds float64) audioUpload {
	return audioUpload{"speech.wav", "audio/wav", wavBytes(24000, 1, 16, seconds)}
}

// mp3Bytes builds a constant-bitrate MPEG-1 Layer III stream of n frames at
// 128 kbps and 48 kHz with no padding. Each frame is 384 bytes and plays for
// 1152/48000 = 0.024s, so frame counting and bitrate-over-size give the same
// duration. Only the frame headers carry data, the payload is zero.
func mp3Bytes(frames int) []byte {
	const frameSize = 384
	out := make([]byte, 0, frames*frameSize)
	for i := 0; i < frames; i++ {
		frame := make([]byte, frameSize)
		copy(frame, []byte{0xFF, 0xFB, 0x94, 0xC0})
		out = append(out, frame...)
	}
	return out
}

// captureAudio runs one speech-to-text call and returns the recorded entry.
// translation selects the translation endpoint/method.
func captureAudio(t *testing.T, translation bool, model, body string, upload audioUpload, pricing *core.ModelPricing) *usage.UsageEntry {
	t.Helper()
	var captured *usage.UsageEntry
	logger := &capturingUsageLogger{config: usage.Config{Enabled: true}, captured: &captured}
	svc := &audioService{
		provider:        newAudioMock(model, body),
		usageLogger:     logger,
		pricingResolver: &mockPricingResolver{pricing: pricing},
	}

	endpoint := "/v1/audio/transcriptions"
	call := svc.CreateTranscription
	if translation {
		endpoint = "/v1/audio/translations"
		call = svc.CreateTranslation
	}
	c, rec := newAudioUpload(endpoint, model, upload.filename, upload.contentType, upload.data)

	if err := call(c); err != nil {
		t.Fatalf("audio call returned error: %v", err)
	}
	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200 (body: %s)", rec.Code, rec.Body.String())
	}
	if captured == nil {
		t.Fatal("expected a usage entry to be written")
	}
	return captured
}

// captureImageEdit runs one image-edit call and returns the recorded entry.
// resp is the provider's image response; model routes the request.
func captureImageEdit(t *testing.T, model string, resp *core.ImageGenerationResponse, pricing *core.ModelPricing) *usage.UsageEntry {
	t.Helper()
	var captured *usage.UsageEntry
	logger := &capturingUsageLogger{config: usage.Config{Enabled: true}, captured: &captured}
	mock := newImageEditMock()
	mock.supportedModels = []string{model}
	mock.imageResp = resp
	svc := &imageService{
		provider:        mock,
		usageLogger:     logger,
		pricingResolver: &mockPricingResolver{pricing: pricing},
	}
	c, rec := newImageEditRequest(t, [][2]string{{"model", model}, {"prompt", "x"}}, catPNG)

	if err := svc.CreateImageEdit(c); err != nil {
		t.Fatalf("CreateImageEdit returned error: %v", err)
	}
	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200 (body: %s)", rec.Code, rec.Body.String())
	}
	if captured == nil {
		t.Fatal("expected a usage entry to be written")
	}
	return captured
}

// captureChat runs one chat completion through the handler and returns the
// recorded entry.
func captureChat(t *testing.T, model string, u core.Usage, pricing *core.ModelPricing) *usage.UsageEntry {
	t.Helper()
	var captured *usage.UsageEntry
	logger := &capturingUsageLogger{config: usage.Config{Enabled: true}, captured: &captured}
	mock := &mockProvider{
		supportedModels: []string{model},
		response: &core.ChatResponse{
			ID:      "chatcmpl-verify",
			Object:  "chat.completion",
			Created: 1234567890,
			Model:   model,
			Choices: []core.Choice{{
				Index:        0,
				Message:      core.ResponseMessage{Role: "assistant", Content: "ok"},
				FinishReason: "stop",
			}},
			Usage: u,
		},
	}
	handler := NewHandler(mock, nil, logger, &mockPricingResolver{pricing: pricing})

	body := fmt.Sprintf(`{"model": %q, "messages": [{"role": "user", "content": "hi"}]}`, model)
	req := httptest.NewRequest(http.MethodPost, "/v1/chat/completions", strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	if err := handler.ChatCompletion(echo.New().NewContext(req, rec)); err != nil {
		t.Fatalf("ChatCompletion returned error: %v", err)
	}
	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200 (body: %s)", rec.Code, rec.Body.String())
	}
	if captured == nil {
		t.Fatal("expected a usage entry to be written")
	}
	return captured
}

// catalogPricing decodes a one-model catalog document the same way the
// gateway reads models.json and returns the pricing it resolves for model.
func catalogPricing(t *testing.T, model, pricingJSON string) *core.ModelPricing {
	t.Helper()
	doc := fmt.Sprintf(`{"version":1,"models":{%q:{"display_name":"verify","modes":["image_generation"],"pricing":%s}}}`, model, pricingJSON)
	list, err := modeldata.Parse([]byte(doc))
	if err != nil {
		t.Fatalf("parse catalog: %v", err)
	}
	meta := modeldata.Resolve(list, "openai", model)
	if meta == nil || meta.Pricing == nil {
		t.Fatalf("catalog did not resolve pricing for %s", model)
	}
	return meta.Pricing
}

// fmtCost renders a recorded cost for failure messages.
func fmtCost(c *float64) string {
	if c == nil {
		return "unset"
	}
	return fmt.Sprintf("%.9f", *c)
}

func assertCostNear(t *testing.T, label string, got *float64, want float64) {
	t.Helper()
	if got == nil {
		t.Fatalf("%s: recorded cost is unset, want %.6f", label, want)
	}
	if diff := *got - want; diff > costTol || diff < -costTol {
		t.Fatalf("%s: recorded cost = %.9f, want %.9f (±%g)", label, *got, want, costTol)
	}
}

// TestVerifyAudioDurationBilled: a speech-to-text response that reports no usage
// is costed from the duration of the uploaded audio, for both endpoints and for
// WAV and MP3 uploads. cost = seconds × per-second input rate. Both uploads are
// exactly 3s long, so fractional seconds and whole-second rounding agree.
func TestVerifyAudioDurationBilled(t *testing.T) {
	const perSecond float64 = 0.01
	pricing := &core.ModelPricing{PerSecondInput: new(perSecond)}

	for _, tc := range []struct {
		name        string
		translation bool
		upload      audioUpload
		seconds     float64
	}{
		{"transcription_wav", false, wavUpload(3), 3},
		{"translation_wav", true, wavUpload(3), 3},
		{"transcription_mp3", false, audioUpload{"speech.mp3", "audio/mpeg", mp3Bytes(125)}, 3},
	} {
		t.Run(tc.name, func(t *testing.T) {
			entry := captureAudio(t, tc.translation, "gpt-4o-transcribe", `{"text":"hi"}`, tc.upload, pricing)
			assertCostNear(t, tc.name, entry.TotalCost, tc.seconds*perSecond)
		})
	}
}

// TestVerifyAudioNotDoubleCharged: a transcription response that reports token
// usage and a seconds field is charged on its tokens only. With an input-token
// rate and a per-second rate both configured, the recorded cost is the token
// cost alone.
func TestVerifyAudioNotDoubleCharged(t *testing.T) {
	const inputTokens = 1_000_000
	const inputPerMtok = 2.5 // token cost 2.5
	const perSecond = 0.01   // 9s would add 0.09 on top
	body := fmt.Sprintf(`{"text":"hi","usage":{"input_tokens":%d,"seconds":9}}`, inputTokens)
	pricing := &core.ModelPricing{
		InputPerMtok:   new(inputPerMtok),
		PerSecondInput: new(perSecond),
	}

	entry := captureAudio(t, false, "gpt-4o-transcribe", body, wavUpload(3), pricing)
	assertCostNear(t, "audio tokens only", entry.TotalCost, float64(inputTokens)*inputPerMtok/1_000_000)
}

// TestVerifyAudioUnmeasurableFlagged: a transcription that reports no usage,
// with an upload whose duration cannot be measured, carries a non-empty
// cost-calculation note and no positive cost. The upload has an Ogg signature
// followed by bytes that are not a valid stream.
func TestVerifyAudioUnmeasurableFlagged(t *testing.T) {
	pricing := &core.ModelPricing{PerSecondInput: new(0.01)}
	upload := audioUpload{"speech.ogg", "audio/ogg", []byte("OggS\x00\x02unsupported-container-bytes")}

	entry := captureAudio(t, false, "gpt-4o-transcribe", `{"text":"hi"}`, upload, pricing)
	if entry.CostsCalculationCaveat == "" {
		t.Fatalf("expected a non-empty cost-calculation note for an unmeasurable upload, got empty (cost=%s)", fmtCost(entry.TotalCost))
	}
	if entry.TotalCost != nil && *entry.TotalCost > costTol {
		t.Fatalf("unmeasurable upload should not record a positive cost, got %.9f", *entry.TotalCost)
	}
}

// TestVerifyImageNotDoubleCharged: an image response that reports output tokens
// on a model that also has a flat per-image rate is charged on its tokens only.
func TestVerifyImageNotDoubleCharged(t *testing.T) {
	const inputTokens = 50
	const outputTokens = 1000
	const inputPerMtok = 5.0
	const outputPerMtok = 40.0
	const perImage = 0.167 // would add on top if both applied
	resp := &core.ImageGenerationResponse{
		Data:  []core.ImageData{{B64JSON: "aGk="}},
		Usage: &core.ImageUsage{InputTokens: inputTokens, OutputTokens: outputTokens, TotalTokens: inputTokens + outputTokens},
	}
	pricing := &core.ModelPricing{
		InputPerMtok:  new(inputPerMtok),
		OutputPerMtok: new(outputPerMtok),
		PerImage:      new(perImage),
	}

	entry := captureImageEdit(t, "gpt-image-1", resp, pricing)
	want := float64(inputTokens)*inputPerMtok/1_000_000 + float64(outputTokens)*outputPerMtok/1_000_000
	assertCostNear(t, "image tokens only", entry.TotalCost, want)
}

// TestVerifyImageOutputRateFromCatalog: a catalog entry that publishes
// output_image_per_mtok next to output_per_mtok prices generated image tokens
// on the image endpoints at the image rate.
func TestVerifyImageOutputRateFromCatalog(t *testing.T) {
	const inputTokens = 50
	const outputTokens = 1000
	pricing := catalogPricing(t, "verify-image-model",
		`{"currency":"USD","input_per_mtok":5,"output_per_mtok":10,"output_image_per_mtok":40}`)
	resp := &core.ImageGenerationResponse{
		Data:  []core.ImageData{{B64JSON: "aGk="}},
		Usage: &core.ImageUsage{InputTokens: inputTokens, OutputTokens: outputTokens, TotalTokens: inputTokens + outputTokens},
	}

	entry := captureImageEdit(t, "verify-image-model", resp, pricing)
	assertCostNear(t, "image output at image rate", entry.TotalCost, inputTokens*5.0/1_000_000+outputTokens*40.0/1_000_000)
}

// TestVerifyImageUnpricedOutputFlagged: an image response that reports output
// tokens, on a model with an input-token rate and a per-image rate but no rate
// for output tokens, carries a non-empty cost-calculation note.
func TestVerifyImageUnpricedOutputFlagged(t *testing.T) {
	resp := &core.ImageGenerationResponse{
		Data:  []core.ImageData{{B64JSON: "aGk="}},
		Usage: &core.ImageUsage{InputTokens: 50, OutputTokens: 1000, TotalTokens: 1050},
	}
	pricing := &core.ModelPricing{
		InputPerMtok: new(5.0),
		PerImage:     new(0.04),
	}

	entry := captureImageEdit(t, "gpt-image-1", resp, pricing)
	if entry.CostsCalculationCaveat == "" {
		t.Fatalf("expected a non-empty cost-calculation note when output tokens have no rate, got empty (cost=%s)", fmtCost(entry.TotalCost))
	}
}

// Unchanged behavior: the cases below price the same before and after the
// media accounting change.

// TestVerifyDalleStillBilledPerImage: a per-image model that reports no token
// usage costs count × per-image. Two returned images record twice the rate.
func TestVerifyDalleStillBilledPerImage(t *testing.T) {
	const perImage = 0.04
	resp := &core.ImageGenerationResponse{
		Data: []core.ImageData{{B64JSON: "aGk="}, {B64JSON: "aGk="}},
	}
	pricing := &core.ModelPricing{PerImage: new(perImage)}

	entry := captureImageEdit(t, "dall-e-2", resp, pricing)
	assertCostNear(t, "dall-e per-image", entry.TotalCost, 2*perImage)
}

// TestVerifyAudioTokenBilledUnchanged: a transcription that reports token usage
// and no seconds, priced only by an input-token rate, costs the token amount.
func TestVerifyAudioTokenBilledUnchanged(t *testing.T) {
	const inputTokens = 1_000_000
	const inputPerMtok = 2.5
	body := fmt.Sprintf(`{"text":"hi","usage":{"input_tokens":%d}}`, inputTokens)
	pricing := &core.ModelPricing{InputPerMtok: new(inputPerMtok)}

	entry := captureAudio(t, false, "gpt-4o-transcribe", body, wavUpload(3), pricing)
	assertCostNear(t, "audio token billed", entry.TotalCost, float64(inputTokens)*inputPerMtok/1_000_000)
}

// TestVerifyChatKeepsTextOutputRate: a chat completion on a catalog entry that
// also publishes output_image_per_mtok prices its completion tokens at
// output_per_mtok.
func TestVerifyChatKeepsTextOutputRate(t *testing.T) {
	pricing := catalogPricing(t, "verify-image-model",
		`{"currency":"USD","input_per_mtok":5,"output_per_mtok":10,"output_image_per_mtok":40}`)

	entry := captureChat(t, "verify-image-model", core.Usage{PromptTokens: 50, CompletionTokens: 1000, TotalTokens: 1050}, pricing)
	assertCostNear(t, "chat text output", entry.TotalCost, 50*5.0/1_000_000+1000*10.0/1_000_000)
}
