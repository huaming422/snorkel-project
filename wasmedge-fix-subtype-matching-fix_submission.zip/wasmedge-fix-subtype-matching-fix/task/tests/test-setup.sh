#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier runs (set -euo pipefail inherited).
#
# The agent may have edited C++ sources (the type matcher, instance headers, the
# validator, the executor engine, the AOT compiler path). The verifier links the
# freshly built libwasmedge shared library, so we must rebuild the in-image
# build/ tree against the agent's current working copy. The image already
# configured build/ with WASMEDGE_BUILD_TESTS=ON and baked the full toolchain
# (LLVM/LLD 18, gtest/gmock, boost, etc.), so this rebuild is incremental and
# needs no network.
cd /repo/WasmEdge

# Keep the C/C++ toolchain offline-first: everything needed is already baked in
# the image; never reach for a registry during grading.
export CMAKE_BUILD_PARALLEL_LEVEL="${CMAKE_BUILD_PARALLEL_LEVEL:-4}"

# Incremental rebuild of the shared library the verifier links against. The
# image's configured build/ is reused; only the agent's changed translation
# units recompile. If (and only if) the configured tree is somehow missing,
# re-configure once from the baked LLVM package — still fully offline.
if [ ! -f build/CMakeCache.txt ]; then
    echo "[test-setup] build/ not configured; configuring from baked toolchain"
    cmake -S . -B build -DCMAKE_BUILD_TYPE=Release \
        -DWASMEDGE_BUILD_TESTS=ON \
        -DLLVM_DIR=/usr/lib/llvm-18/lib/cmake/llvm \
        > /tmp/test-setup-configure.log 2>&1 \
        || { echo "[test-setup] configure failed"; tail -80 /tmp/test-setup-configure.log >&2; exit 1; }
fi

echo "[test-setup] rebuilding libwasmedge against the current working tree"
if cmake --build build --target wasmedge_shared > /tmp/test-setup-build.log 2>&1; then
    echo "[test-setup] libwasmedge rebuilt from working tree"
else
    # Fall back to building the default target set if the shared-lib target name
    # differs in this checkout; still offline (no -target filters network).
    echo "[test-setup] wasmedge_shared target unavailable; building default targets"
    cmake --build build >> /tmp/test-setup-build.log 2>&1 \
        || { echo "[test-setup] build failed"; tail -120 /tmp/test-setup-build.log >&2; exit 1; }
fi

# The unit/regression binaries dlopen the freshly built shared library; the
# image already exports LD_LIBRARY_PATH=/repo/WasmEdge/build/lib/api, re-assert
# it here so a sourced subshell inherits it even if the environment was reset.
export LD_LIBRARY_PATH="/repo/WasmEdge/build/lib/api:${LD_LIBRARY_PATH:-}"

# No services to start and no data to seed: the type-matching behavior is
# exercised entirely in-process by the verifier's gtest cases driving the VM
# embedder API. Assertion logic lives in the verifier, not here.
echo "[test-setup] ready"
