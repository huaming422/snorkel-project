"""Behavioral verifier orchestrator for wasmedge-fix-subtype-matching.

This file runs under VERIFIER_PYTHON (/opt/tooling/venv) and imports no
repository Python (WasmEdge has no Python test harness). It drives a small C++
gtest binary that exercises the fix THROUGH the pre-existing, stable embedder VM
API, so it never names an internal matcher symbol or any data model the fix
introduces. The three pytest tests below each map to one behavioral criterion.

Build strategy (offline, repo-faithful): the gtest source is injected as an
in-tree CMake target in the repository's own test tree, so it compiles with the
repository's exact flags and links against the same `wasmedgeVM` target the
repo's regression tests use. Building that target recompiles whatever
translation units the agent's fix changed, so the verifier always links the
agent's current code. The image already configured `build/` with
WASMEDGE_BUILD_TESTS=ON and baked the full toolchain, so configure + build run
with no network.

A build failure (e.g. the agent's edit does not compile) surfaces as a pytest
error on all three tests, i.e. score 0 — which is the correct outcome for a
broken fix, not an infrastructure invalidation.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

REPO = Path(os.environ.get("REPO_DIR", "/repo/WasmEdge"))
BUILD = REPO / "build"
LLVM_DIR = "/usr/lib/llvm-18/lib/cmake/llvm"

# Where this orchestrator and its sibling C++ source are shipped at grade time.
VERIFY_DIR = Path(__file__).resolve().parent
GTEST_SRC = VERIFY_DIR / "verify_subtype_match.cpp"

# In-repo injection points.
TEST_SUBDIR = REPO / "test" / "executor"
INJECTED_SRC = TEST_SUBDIR / "verify_subtype_match.cpp"
CMAKELISTS = TEST_SUBDIR / "CMakeLists.txt"
TARGET = "wasmedgeSubtypeMatchVerify"
BINARY = BUILD / "test" / "executor" / TARGET
GTEST_JSON = Path("/tmp/subtype_match_gtest.json")
BUILD_LOG = Path("/tmp/subtype_match_build.log")

MARKER = "# >>> subtype-match regression target"
CMAKE_BLOCK = f"""
{MARKER} (auto-generated; do not edit)
wasmedge_add_executable({TARGET}
  verify_subtype_match.cpp
)
target_link_libraries({TARGET}
  PRIVATE
  ${{GTEST_BOTH_LIBRARIES}}
  wasmedgeVM
)
# <<< subtype-match regression target
"""

# gtest full name -> criterion (pytest test function) name.
CASES = {
    "SubtypeMatch.TagImportMatchesBothWays": "tag_import_matches_both_ways",
    "SubtypeMatch.ReExportedImportsMatch": "reexported_imports_match",
    "SubtypeMatch.HostFuncMatchesItsDefinedType": "hostfunc_matches_defined_type",
}


def _run(cmd: list[str], log, cwd: Path | None = None) -> int:
    log.write(f"\n$ {' '.join(cmd)}\n")
    log.flush()
    proc = subprocess.run(
        cmd,
        cwd=str(cwd) if cwd else None,
        stdout=log,
        stderr=subprocess.STDOUT,
        text=True,
        check=False,
    )
    return proc.returncode


def _parallelism() -> str:
    return os.environ.get("CMAKE_BUILD_PARALLEL_LEVEL", str(os.cpu_count() or 4))


@pytest.fixture(scope="session")
def gtest_results() -> dict[str, bool]:
    """Inject the in-tree target, build it offline, run it, parse per-test pass/fail.

    Returns a map of gtest full-name -> passed(bool). Raises on genuine
    infrastructure problems (missing source, no build dir and reconfigure
    impossible). A *compile* failure of the agent's code is reported as every
    behavioral case failing, not as an exception, so a non-compiling fix scores
    zero rather than invalidating the trial.
    """
    assert GTEST_SRC.is_file(), f"missing shipped gtest source: {GTEST_SRC}"
    assert REPO.is_dir(), f"repo not found: {REPO}"

    env_path = os.environ.get("LD_LIBRARY_PATH", "")
    os.environ["LD_LIBRARY_PATH"] = f"{BUILD / 'lib' / 'api'}:{env_path}"

    with BUILD_LOG.open("w") as log:
        # 1. Inject the C++ source and register the target (idempotent).
        shutil.copyfile(GTEST_SRC, INJECTED_SRC)
        cml = CMAKELISTS.read_text()
        if MARKER not in cml:
            CMAKELISTS.write_text(cml.rstrip() + "\n" + CMAKE_BLOCK)

        # 2. Configure (offline: _deps were populated when the image configured
        #    build/ with WASMEDGE_BUILD_TESTS=ON; a rerun is incremental).
        rc = _run(
            [
                "cmake", "-S", str(REPO), "-B", str(BUILD),
                "-DCMAKE_BUILD_TYPE=Release",
                "-DWASMEDGE_BUILD_TESTS=ON",
                f"-DLLVM_DIR={LLVM_DIR}",
            ],
            log,
        )
        if rc != 0:
            pytest.fail(
                f"cmake configure failed (rc={rc}); see {BUILD_LOG}:\n"
                + _tail(BUILD_LOG),
                pytrace=False,
            )

        # 3. Build the verifier target. This recompiles any translation unit the
        #    agent's fix touched (via the wasmedgeVM dependency) and links our
        #    test. A compile error here means the agent's code is broken: we do
        #    NOT raise — we record every case as failed so the fix scores 0.
        build_rc = _run(
            ["cmake", "--build", str(BUILD), "--target", TARGET,
             "--parallel", _parallelism()],
            log,
        )

    if build_rc != 0 or not BINARY.is_file():
        print(f"[verify] build failed (rc={build_rc}); treating all cases as failed")
        print(_tail(BUILD_LOG))
        return {full: False for full in CASES}

    # 4. Run the binary once; parse gtest JSON for per-test outcomes.
    if GTEST_JSON.exists():
        GTEST_JSON.unlink()
    run_proc = subprocess.run(
        [str(BINARY), f"--gtest_output=json:{GTEST_JSON}"],
        capture_output=True,
        text=True,
        check=False,
    )
    print(run_proc.stdout[-4000:])
    if run_proc.stderr:
        print(run_proc.stderr[-2000:])

    if not GTEST_JSON.exists():
        pytest.fail(
            f"gtest binary produced no JSON output (rc={run_proc.returncode}):\n"
            + run_proc.stdout[-2000:],
            pytrace=False,
        )

    data = json.loads(GTEST_JSON.read_text())
    results: dict[str, bool] = {full: False for full in CASES}
    for suite in data.get("testsuites", []):
        sname = suite.get("name", "")
        for tc in suite.get("testsuite", []):
            full = f"{sname}.{tc.get('name', '')}"
            if full in results:
                # gtest marks a passing case with no "failures" array.
                results[full] = not tc.get("failures")
    return results


def _tail(path: Path, n: int = 120) -> str:
    try:
        lines = path.read_text(errors="replace").splitlines()
    except OSError:
        return ""
    return "\n".join(lines[-n:])


def test_tag_import_matches_both_ways(gtest_results):
    """Tag imports are invariant: a strict super-type import is rejected at link
    time (IncompatibleImportType) and an equivalent-type import links."""
    assert gtest_results["SubtypeMatch.TagImportMatchesBothWays"], (
        "tag import matching is wrong: a super-type import must fail to link and "
        "an equivalent-type import must link (see /tmp/subtype_match_build.log "
        "and the captured gtest output)"
    )


def test_reexported_imports_match(gtest_results):
    """Re-exported globals/tables/tags are matched by their defining module's
    types, so each of the three valid importers links."""
    assert gtest_results["SubtypeMatch.ReExportedImportsMatch"], (
        "re-exported global/table/tag imports must link using the defining "
        "module's types"
    )


def test_hostfunc_matches_defined_type(gtest_results):
    """A host function placed in a table matches its own defined final func type
    for call_indirect / ref.test, and not a non-final sub type."""
    assert gtest_results["SubtypeMatch.HostFuncMatchesItsDefinedType"], (
        "a host function used indirectly must match its defined final func type "
        "(call_f/test_f succeed; call_g traps IndirectCallTypeMismatch; test_g "
        "returns 0)"
    )
