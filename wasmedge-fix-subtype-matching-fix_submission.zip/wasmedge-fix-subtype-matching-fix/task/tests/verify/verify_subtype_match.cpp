// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: Copyright The WasmEdge Authors
//
// Behavioral verifier for the WebAssembly subtyping-match fix.
//
// Every assertion here runs THROUGH the pre-existing, stable embedder VM API
// (construct a VM, register/load modules, validate, instantiate, execute) and
// the pre-existing stable ErrCode values. It names no internal matcher symbol,
// no helper the fix introduces, and no private data model, so any correct fix
// passes regardless of how it is structured (visited-set vs pair heap,
// per-instance provenance accessor vs threaded parameter, union-find vs stored
// equivalence index, shared helper vs inlined logic, any symbol names).
//
// The only embedded constants are:
//   * fixed Wasm byte arrays — deterministic encodings of fixed (module ...)
//     sources, implementation-independent spec-level scenarios; the comment
//     above each array is its WAT source.
//   * two pre-existing ErrCode enum values (IncompatibleImportType,
//     IndirectCallTypeMismatch) that are the stable observable link/trap
//     outcomes.
//
// The GC and typed-function-references proposals are enabled by the default
// Configure, so every scenario runs out of the box.

#include "common/spdlog.h"
#include "common/types.h"
#include "vm/vm.h"

#include <array>
#include <cstdint>
#include <gtest/gtest.h>
#include <memory>

namespace {

using namespace WasmEdge;

/// Host function that does nothing.
class Nop : public Runtime::HostFunction<Nop> {
public:
  Expect<void> body(const Runtime::CallingFrame &) { return {}; }
};

// clang-format off

/// Binary Wasm module: exports a tag whose type has a super type.
///
/// (module
///   (type $super (sub (func)))
///   (type $sub (sub $super (func)))
///   (tag (export "t") (type $sub)))
std::array<WasmEdge::Byte, 34> TagSubTypeExportWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x0c, 0x02, 0x50,
    0x00, 0x60, 0x00, 0x00, 0x50, 0x01, 0x00, 0x60, 0x00, 0x00, 0x0d, 0x03,
    0x01, 0x00, 0x01, 0x07, 0x05, 0x01, 0x01, 0x74, 0x04, 0x00};

/// Binary Wasm module: imports the tag with its super type.
///
/// (module
///   (type $super (sub (func)))
///   (import "M" "t" (tag (type $super))))
std::array<WasmEdge::Byte, 26> TagSuperTypeImportWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x06, 0x01, 0x50,
    0x00, 0x60, 0x00, 0x00, 0x02, 0x08, 0x01, 0x01, 0x4d, 0x01, 0x74, 0x04,
    0x00, 0x00};

/// Binary Wasm module: imports the tag with an equivalent type.
///
/// (module
///   (type $super (sub (func)))
///   (type $sub (sub $super (func)))
///   (import "M" "t" (tag (type $sub))))
std::array<WasmEdge::Byte, 32> TagSubTypeImportWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x0c, 0x02, 0x50,
    0x00, 0x60, 0x00, 0x00, 0x50, 0x01, 0x00, 0x60, 0x00, 0x00, 0x02, 0x08,
    0x01, 0x01, 0x4d, 0x01, 0x74, 0x04, 0x00, 0x01};

/// Binary Wasm module: defines and exports a global, a table, and a tag.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (global (export "g") (ref null $s) (ref.null $s))
///   (table (export "t") 1 (ref null $s))
///   (tag (export "e") (type $ft)))
std::array<WasmEdge::Byte, 55> ReExportDefineWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x09, 0x02, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x04, 0x05, 0x01, 0x63, 0x00,
    0x00, 0x01, 0x0d, 0x03, 0x01, 0x00, 0x01, 0x06, 0x07, 0x01, 0x63, 0x00,
    0x00, 0xd0, 0x00, 0x0b, 0x07, 0x0d, 0x03, 0x01, 0x67, 0x03, 0x00, 0x01,
    0x74, 0x01, 0x00, 0x01, 0x65, 0x04, 0x00};

/// Binary Wasm module: re-exports them with its type indices shifted by one.
///
/// (module
///   (type $f (func))
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (import "A" "g" (global (ref null $s)))
///   (import "A" "t" (table 1 (ref null $s)))
///   (import "A" "e" (tag (type $ft)))
///   (export "g" (global 0))
///   (export "t" (table 0))
///   (export "e" (tag 0)))
std::array<WasmEdge::Byte, 64> ReExportForwardWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x0c, 0x03, 0x60,
    0x00, 0x00, 0x5f, 0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x02, 0x19,
    0x03, 0x01, 0x41, 0x01, 0x67, 0x03, 0x63, 0x01, 0x00, 0x01, 0x41, 0x01,
    0x74, 0x01, 0x63, 0x01, 0x00, 0x01, 0x01, 0x41, 0x01, 0x65, 0x04, 0x00,
    0x02, 0x07, 0x0d, 0x03, 0x01, 0x67, 0x03, 0x00, 0x01, 0x74, 0x01, 0x00,
    0x01, 0x65, 0x04, 0x00};

/// Binary Wasm module: imports the re-exported global.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (import "B" "g" (global (ref null $s))))
std::array<WasmEdge::Byte, 30> ReExportGlobalImportWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x09, 0x02, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x02, 0x09, 0x01, 0x01, 0x42,
    0x01, 0x67, 0x03, 0x63, 0x00, 0x00};

/// Binary Wasm module: imports the re-exported table.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (import "B" "t" (table 1 (ref null $s))))
std::array<WasmEdge::Byte, 31> ReExportTableImportWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x09, 0x02, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x02, 0x0a, 0x01, 0x01, 0x42,
    0x01, 0x74, 0x01, 0x63, 0x00, 0x00, 0x01};

/// Binary Wasm module: imports the re-exported tag.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (import "B" "e" (tag (type $ft))))
std::array<WasmEdge::Byte, 29> ReExportTagImportWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x09, 0x02, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x02, 0x08, 0x01, 0x01, 0x42,
    0x01, 0x65, 0x04, 0x00, 0x01};

/// Binary Wasm module: calls and tests the function in its table.
///
/// (module
///   (type $f (func))
///   (type $g (sub (func)))
///   (table (export "tab") 1 funcref)
///   (func (export "call_f") (call_indirect (type $f) (i32.const 0)))
///   (func (export "call_g") (call_indirect (type $g) (i32.const 0)))
///   (func (export "test_f") (result i32)
///     (ref.test (ref $f) (table.get 0 (i32.const 0))))
///   (func (export "test_g") (result i32)
///     (ref.test (ref $g) (table.get 0 (i32.const 0)))))
std::array<WasmEdge::Byte, 120> HostFuncTableWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x0d, 0x03, 0x60,
    0x00, 0x00, 0x50, 0x00, 0x60, 0x00, 0x00, 0x60, 0x00, 0x01, 0x7f, 0x03,
    0x05, 0x04, 0x00, 0x00, 0x02, 0x02, 0x04, 0x04, 0x01, 0x70, 0x00, 0x01,
    0x07, 0x2b, 0x05, 0x03, 0x74, 0x61, 0x62, 0x01, 0x00, 0x06, 0x63, 0x61,
    0x6c, 0x6c, 0x5f, 0x66, 0x00, 0x00, 0x06, 0x63, 0x61, 0x6c, 0x6c, 0x5f,
    0x67, 0x00, 0x01, 0x06, 0x74, 0x65, 0x73, 0x74, 0x5f, 0x66, 0x00, 0x02,
    0x06, 0x74, 0x65, 0x73, 0x74, 0x5f, 0x67, 0x00, 0x03, 0x0a, 0x25, 0x04,
    0x07, 0x00, 0x41, 0x00, 0x11, 0x00, 0x00, 0x0b, 0x07, 0x00, 0x41, 0x00,
    0x11, 0x01, 0x00, 0x0b, 0x09, 0x00, 0x41, 0x00, 0x25, 0x00, 0xfb, 0x14,
    0x00, 0x0b, 0x09, 0x00, 0x41, 0x00, 0x25, 0x00, 0xfb, 0x14, 0x01, 0x0b};
// clang-format on

/// Tag imports are invariant: the import type must correspond exactly to the
/// exported tag. An import declaring a strict super type must be rejected at
/// link time; an equivalent type must link.
TEST(SubtypeMatch, TagImportMatchesBothWays) {
  // --- Part 1: the import declares the super type (must not link) ---
  {
    Configure Conf;
    VM::VM VM(Conf);
    ASSERT_TRUE(VM.registerModule("M", TagSubTypeExportWasm));
    ASSERT_TRUE(VM.loadWasm(TagSuperTypeImportWasm));
    ASSERT_TRUE(VM.validate());
    auto Res = VM.instantiate();
    ASSERT_FALSE(Res);
    EXPECT_EQ(Res.error(), ErrCode::Value::IncompatibleImportType);
  }

  // --- Part 2: the import declares an equivalent type (links) ---
  {
    Configure Conf;
    VM::VM VM(Conf);
    ASSERT_TRUE(VM.registerModule("M", TagSubTypeExportWasm));
    ASSERT_TRUE(VM.loadWasm(TagSubTypeImportWasm));
    ASSERT_TRUE(VM.validate());
    EXPECT_TRUE(VM.instantiate());
  }
}

/// Re-exported globals, tables, and tags must be matched using the types of
/// their DEFINING module, not the re-exporting module's local indices. Each of
/// the three valid importers must validate and instantiate.
TEST(SubtypeMatch, ReExportedImportsMatch) {
  for (auto Wasm : {Span<const Byte>(ReExportGlobalImportWasm),
                    Span<const Byte>(ReExportTableImportWasm),
                    Span<const Byte>(ReExportTagImportWasm)}) {
    Configure Conf;
    VM::VM VM(Conf);
    ASSERT_TRUE(VM.registerModule("A", ReExportDefineWasm));
    ASSERT_TRUE(VM.registerModule("B", ReExportForwardWasm));
    ASSERT_TRUE(VM.loadWasm(Wasm));
    ASSERT_TRUE(VM.validate());
    EXPECT_TRUE(VM.instantiate());
  }
}

/// A host function out of any module is typed as the final `(func)`: it matches
/// the final type `$f` (call_indirect succeeds, ref.test returns 1) but not the
/// non-final sub type `$g` (call_indirect traps, ref.test returns 0).
TEST(SubtypeMatch, HostFuncMatchesItsDefinedType) {
  Runtime::Instance::FunctionInstance HostFunc(std::make_unique<Nop>());
  Configure Conf;
  VM::VM VM(Conf);
  ASSERT_TRUE(VM.loadWasm(HostFuncTableWasm));
  ASSERT_TRUE(VM.validate());
  ASSERT_TRUE(VM.instantiate());
  auto *TabInst = VM.getActiveModule()->findTableExports("tab");
  ASSERT_NE(TabInst, nullptr);
  ASSERT_TRUE(TabInst->setRefAddr(0, RefVariant(&HostFunc)));

  EXPECT_TRUE(VM.execute("call_f"));
  auto CallRes = VM.execute("call_g");
  ASSERT_FALSE(CallRes);
  EXPECT_EQ(CallRes.error(), ErrCode::Value::IndirectCallTypeMismatch);

  auto TestRes = VM.execute("test_f");
  ASSERT_TRUE(TestRes);
  ASSERT_EQ(TestRes->size(), 1U);
  EXPECT_EQ(TestRes->at(0).first.get<uint32_t>(), 1U);
  TestRes = VM.execute("test_g");
  ASSERT_TRUE(TestRes);
  ASSERT_EQ(TestRes->size(), 1U);
  EXPECT_EQ(TestRes->at(0).first.get<uint32_t>(), 0U);
}

} // namespace

GTEST_API_ int main(int argc, char **argv) {
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
