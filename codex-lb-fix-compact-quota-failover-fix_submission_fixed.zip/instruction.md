## Task

Long conversations are getting stuck at compaction. A conversation has been chaining its responses through one upstream account, that account runs into its usage limits, and the next `POST /backend-api/codex/responses/compact` for the conversation comes back as a 429 or a 503 saying no accounts are available instead of a compacted history. Retrying hits the same exhausted account every time, so the client can't shrink its history until that account's limit resets.

We need these compactions to go through on one of the healthy accounts. A compacted history built from only part of the conversation, or from items only the exhausted account can read, is worse than the error, though.
