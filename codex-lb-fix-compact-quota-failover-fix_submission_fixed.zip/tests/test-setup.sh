#!/usr/bin/env bash
# Container setup for the verifier phase. This file is `source`d (not exec'd)
# by the harbor runner, so any exported PATH / VIRTUAL_ENV here persists into
# the verifier subprocess.
#
# The behavioral verifier (verify/verify.py) imports the codex-lb application
# itself (FastAPI app, DB models, proxy service), so it MUST run under the
# project's own virtualenv — NOT the isolated /opt/tooling verifier venv. The
# image built the project into /opt/venv at the base commit
# (UV_PROJECT_ENVIRONMENT=/opt/venv, groups: all-extras + dev, with pytest /
# pytest-timeout), with the uv cache/store warm, so on a normal trial the
# sync below is a fast offline no-op and nothing downloads.
set -u

REPO="${REPO_DIR:-/repo/codex-lb}"
export REPO_DIR="$REPO"
cd "$REPO" || { echo "test-setup: $REPO missing" >&2; return 1 2>/dev/null || exit 1; }

export PATH="/usr/local/bin:$PATH"   # repo uv
export VIRTUAL_ENV=/opt/venv UV_PROJECT_ENVIRONMENT=/opt/venv

# Offline-first: resolve against the warm cache / existing /opt/venv with no
# index traffic. The agent phase ran no-network and the full dependency
# closure (base commit + the fix's imports, all already present at base) is
# baked, so --offline --frozen is a near-instant no-op. Fall back to a logged
# online sync only if something is genuinely missing (network is available in
# the verifier phase).
export UV_NO_CACHE=0
if ! uv sync --frozen --offline > /tmp/verify-sync.log 2>&1; then
    echo "test-setup: offline sync incomplete; retrying online" >&2
    uv sync --frozen > /tmp/verify-sync.log 2>&1 \
        || { tail -40 /tmp/verify-sync.log >&2; echo "test-setup: WARNING uv sync failed" >&2; }
fi
tail -3 /tmp/verify-sync.log 2>/dev/null || true

# Make the project venv the default python/pytest the verifier invokes so
# `import app...` resolves to the repo install with its full dependency tree.
if [ -d "/opt/venv/bin" ]; then
    export PATH="/opt/venv/bin:$PATH"
fi

# Sanity: the module under test must import cleanly before any verifier runs —
# a broken import here is a clearer signal than a confusing collection error
# later. (app.main is intentionally NOT imported: it builds the full FastAPI
# app at module scope and needs the test env that conftest sets up per-run.)
python -c "import app.modules.proxy._service.compact" \
    && echo "test-setup: codex-lb compact module importable (venv=/opt/venv)" \
    || echo "test-setup: WARNING codex-lb import failed (verifier env may still resolve it)" >&2
