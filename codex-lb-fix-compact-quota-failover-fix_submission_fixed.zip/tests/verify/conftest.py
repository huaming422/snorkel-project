"""Verifier conftest — make the repository's own integration-test harness
available to this out-of-tree verify file.

The behavioral tests in ``verify.py`` drive the service exactly the way the
repository's own ``tests/integration/`` suite does: through the FastAPI app
over an ASGI transport, with the per-test SQLite schema reset and the ambient
background schedulers / leader election no-op'd. All of that plumbing already
lives in the repo's ``tests/conftest.py`` (fixtures ``async_client``,
``app_instance``, the autouse DB-reset and scheduler-disable fixtures, the
session-scoped engine disposal, the encryption-key temp file, etc.).

``run_verify`` invokes pytest on ``/tests/verify/verify.py`` with the working
directory set to the repo root (``/repo/codex-lb``). Because this file sits
outside the repo's ``tests/`` package, pytest would not otherwise collect the
repo conftest. We register it as a plugin so every fixture the integration
tests rely on is present here with identical semantics — no fixture is
re-implemented, so there is no drift from the suite the maintainers maintain.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path


def _repo_root() -> Path:
    env = os.environ.get("REPO_DIR")
    if env and (Path(env) / "tests" / "conftest.py").exists():
        return Path(env)
    for base in (Path("/repo/codex-lb"), Path.cwd()):
        if (base / "tests" / "conftest.py").exists():
            return base
    # Walk up from cwd as a last resort.
    for parent in [Path.cwd(), *Path.cwd().parents]:
        if (parent / "tests" / "conftest.py").exists():
            return parent
    raise RuntimeError("could not locate the repository's tests/conftest.py")


# Load the repository's integration-test fixtures as a pytest plugin. The repo
# is pip-installed (``app`` / ``config`` packages) and ``tests`` is a package
# with an ``__init__``, so the dotted plugin name resolves on the project venv
# once the repo root is importable.
_ROOT = _repo_root()
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))
pytest_plugins = ["tests.conftest"]
