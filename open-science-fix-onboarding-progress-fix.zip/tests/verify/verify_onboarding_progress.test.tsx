// @vitest-environment jsdom
// @ts-nocheck
//
// Drives the real first-run setup wizard through its rendered DOM and the
// existing settings store actions. Assertions read observable surfaces only:
// which section is mounted, whether Continue is enabled, the requests the
// store's save action received, whether the switch and install actions ran,
// and the alert text. The host inspection uses the real runEnvironmentCheck
// with injected probes, as the shipped step tests do.
import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { fireEvent } from '@testing-library/react'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { execFileSync } from 'node:child_process'
import { readFileSync } from 'node:fs'

import { runEnvironmentCheck } from '../../../../main/settings/environment-check'
import type { AgentFrameworkId, EnvironmentCheckResult } from '../../../../shared/settings'
import { i18next } from '@/i18n'
import { useSettingsStore } from '@/stores/settings-store'
import { OnboardingWizard } from './OnboardingWizard'
import {
  clickButton,
  fillRequiredProviderFields,
  findButton,
  readyClaudeState,
  resetOnboardingStores,
  selectOption,
  stubWindowApi
} from './onboarding-test-utils'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true

let container: HTMLDivElement
let root: Root

beforeEach(() => {
  resetOnboardingStores()
  stubWindowApi()
  container = document.createElement('div')
  document.body.appendChild(container)
  root = createRoot(container)
})

afterEach(async () => {
  act(() => root.unmount())
  container.remove()
  document.body.innerHTML = ''
  delete (window as unknown as { api?: unknown }).api
  await i18next.changeLanguage('en')
})

const renderWizard = async (): Promise<void> => {
  await act(async () => root.render(<OnboardingWizard />))
}

const section = (label: string): Element | null =>
  container.querySelector(`section[aria-label="${label}"]`)

const alertText = (): string => container.querySelector('[role="alert"]')?.textContent ?? ''

const goToProvider = async (): Promise<void> => {
  readyClaudeState()
  await renderWizard()
  await clickButton(/^continue$/i)
  await clickButton(/^continue$/i)
  await clickButton(/^continue$/i)
  expect(section('Configure model')).not.toBeNull()
  await fillRequiredProviderFields(container)
}

const typeApiKey = async (value: string): Promise<void> => {
  await act(async () => {
    fireEvent.change(container.querySelector('#provider-key')!, { target: { value } })
  })
}

// A host inspection where the selected framework has no runtime and the
// installer sources are unreachable. Uses the real runEnvironmentCheck with
// injected host and network probes (no real host access); setAgentFramework
// and checkEnvironment re-run that check for whichever framework is selected.
const configureUnavailableRegistries = async (
  failure?: 'storage' | 'system' | 'no-runtime' | 'selected-installed',
  alternative: AgentFrameworkId = 'opencode',
  selected: AgentFrameworkId = 'claude-code'
): Promise<void> => {
  const selectedInstalled = failure === 'selected-installed'
  const frameworks = [
    { id: selected, label: selected, runtime: { found: selectedInstalled } },
    { id: alternative, label: alternative, runtime: { found: failure !== 'no-runtime' } }
  ]
  const probeRegistry = vi.fn().mockRejectedValue(new Error('Installation source unreachable'))
  const inspect = (agentFrameworkId: AgentFrameworkId): Promise<EnvironmentCheckResult> =>
    runEnvironmentCheck({
      storageRoot: '/fixture/data',
      agentFrameworkId,
      frameworks,
      encryptionAvailable: true,
      deps: {
        platform: 'darwin',
        architecture: 'arm64',
        verifyStorage: async () => {
          if (failure === 'storage') throw new Error('Permission denied')
        },
        resolveManagedPlatform: () => {
          if (failure === 'system') throw new Error('Unsupported system')
          return { key: 'darwin-arm64' }
        },
        findPython: async () => undefined,
        detectAvx2: () => true,
        probeRegistry,
        now: () => 1
      }
    })
  const environmentCheck = await inspect(selected)
  if (!selectedInstalled) {
    expect(probeRegistry).toHaveBeenCalledTimes(2)
    expect(environmentCheck).toMatchObject({ ready: false, canAutoInstall: false })
    expect(environmentCheck.checks.find((check) => check.id === 'install-network')?.status).toBe(
      'failed'
    )
  }
  if (failure !== 'no-runtime') {
    expect(
      environmentCheck.checks.find((check) => check.label === `${alternative} runtime`)?.status
    ).toBe('passed')
  }
  useSettingsStore.setState({
    agentFrameworkId: selected,
    environmentCheck,
    agentFrameworks: frameworks.map(({ id, label }) => ({
      id,
      displayName: label,
      supportsSkills: true
    })),
    preflight: {
      claudeReady:
        (alternative === 'claude-code' && failure !== 'no-runtime') ||
        (selected === 'claude-code' && selectedInstalled),
      opencodeReady:
        (alternative === 'opencode' && failure !== 'no-runtime') ||
        (selected === 'opencode' && selectedInstalled),
      codexReady: alternative === 'codex' && failure !== 'no-runtime',
      codebuddyReady: alternative === 'codebuddy' && failure !== 'no-runtime',
      agentFrameworkId: selected,
      agentReady: selectedInstalled,
      activeProviderReady: false
    },
    setAgentFramework: vi.fn(async (agentFrameworkId: AgentFrameworkId) => {
      useSettingsStore.setState({ agentFrameworkId })
    }),
    checkEnvironment: vi.fn(async () => {
      const result = await inspect(useSettingsStore.getState().agentFrameworkId)
      useSettingsStore.setState({ environmentCheck: result })
      return result
    })
  })
}

// Opens the provider step for a Codex agent whose display name is not the
// framework id, so the incompatibility message must carry the name it is given.
const openProviderForCodex = async (displayName: string): Promise<void> => {
  await goToProvider()
  await clickButton(/^back$/i)
  await act(async () => {
    const state = useSettingsStore.getState()
    useSettingsStore.setState({
      agentFrameworkId: 'codex',
      agentFrameworks: [
        { id: 'codex', displayName, supportedApiTypes: ['responses'], supportsSkills: true }
      ],
      preflight: { ...state.preflight, agentFrameworkId: 'codex', agentReady: true, codexReady: true },
      environmentCheck: { ...state.environmentCheck!, agentFrameworkId: 'codex' }
    })
  })
  await clickButton(/^continue$/i)
  expect(section('Configure model')).not.toBeNull()
}

const escapeRegExp = (text: string): string => text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
const fillPlaceholders = (text: string, name: string): string =>
  text.replace(/{{\s*[\w.-]+\s*}}/g, name)

// Catalog keys that already existed before this change, per language (from the repository's base
// commit), so a translation that only reuses an older message can be told apart from a new one.
const baseCatalogKeys = (language: string): Set<string> => {
  const baseRef = readFileSync('/var/lib/devcontainer_base_ref', 'utf8').trim()
  const json = execFileSync('git', ['show', `${baseRef}:src/shared/i18n/locales/${language}.json`], {
    encoding: 'utf8',
    maxBuffer: 64 * 1024 * 1024
  })
  const keys = new Set<string>()
  const collect = (node: unknown): void => {
    if (!node || typeof node !== 'object') return
    for (const [key, value] of Object.entries(node)) {
      if (typeof value === 'string') keys.add(key)
      else collect(value)
    }
  }
  collect(JSON.parse(json))
  return keys
}

// Translation catalogs are keyed by the English source text (src/renderer/src/i18n/index.ts), so
// the entries behind an English message are the ones whose keys render to parts of that message.
// Longest keys first, without overlaps.
const catalogEntriesWithin = (
  language: string,
  english: string,
  name: string
): Array<[string, string]> => {
  const namespaces = [i18next.options.ns ?? []].flat()
  const candidates: Array<[string, string]> = []
  for (const namespace of namespaces) {
    const bundle = i18next.getResourceBundle(language, namespace) ?? {}
    for (const [key, value] of Object.entries(bundle)) {
      const rendered = fillPlaceholders(key, name)
      if (typeof value === 'string' && rendered.length >= 12 && english.includes(rendered)) {
        candidates.push([key, value])
      }
    }
  }
  candidates.sort((a, b) => b[0].length - a[0].length)
  const taken: Array<[number, number]> = []
  return candidates.filter(([key]) => {
    const rendered = fillPlaceholders(key, name)
    const start = english.indexOf(rendered)
    const end = start + rendered.length
    if (taken.some(([s, e]) => start < e && end > s)) return false
    taken.push([start, end])
    return true
  })
}

const contentWords = (text: string, name: string): string[] =>
  text
    .replaceAll(name, ' ')
    .toLowerCase()
    .split(/[^a-z']+/)
    .filter((word) => word.length >= 4)

describe('Onboarding setup-progress behaviors', () => {
  // With the selected framework's runtime missing and installers unreachable,
  // the wizard switches to the installed alternative, re-runs the check for it,
  // and opens Continue.
  it.each(['claude-code', 'codex', 'codebuddy'] as const)(
    'checks the installed %s alternative before continuing',
    async (alternative) => {
      await configureUnavailableRegistries(
        undefined,
        alternative,
        alternative === 'claude-code' ? 'opencode' : 'claude-code'
      )
      await renderWizard()
      expect(useSettingsStore.getState().setAgentFramework).toHaveBeenCalledWith(alternative)
      expect(useSettingsStore.getState().environmentCheck).toMatchObject({
        ready: true,
        agentFrameworkId: alternative
      })
      expect(findButton(/^continue$/i)?.disabled).toBe(false)
    }
  )

  // An installed Codex adapter below the version the app supports is not usable.
  it('does not select an unsupported Codex adapter as an installed alternative', async () => {
    await configureUnavailableRegistries(undefined, 'codex')
    useSettingsStore.setState({ codex: { version: '0.0.1' } })
    await renderWizard()
    expect(useSettingsStore.getState().setAgentFramework).not.toHaveBeenCalled()
    expect(findButton(/^continue$/i)?.disabled).toBe(true)
  })

  // The check is often still running when the wizard opens; the switch happens once it lands.
  it('switches once a check that was still running when the wizard opened comes back', async () => {
    await configureUnavailableRegistries()
    const stuck = useSettingsStore.getState().environmentCheck
    useSettingsStore.setState({ environmentCheck: undefined, isCheckingEnvironment: true })
    await renderWizard()
    expect(useSettingsStore.getState().setAgentFramework).not.toHaveBeenCalled()
    await act(async () => {
      useSettingsStore.setState({ environmentCheck: stuck, isCheckingEnvironment: false })
    })
    expect(useSettingsStore.getState().setAgentFramework).toHaveBeenCalledWith('opencode')
    expect(findButton(/^continue$/i)?.disabled).toBe(false)
  })

  // An installed Codex adapter at a version the app supports is usable.
  it('selects an installed Codex adapter whose version is supported', async () => {
    await configureUnavailableRegistries(undefined, 'codex')
    useSettingsStore.setState({ codex: { version: '2.0.0' } })
    await renderWizard()
    expect(useSettingsStore.getState().setAgentFramework).toHaveBeenCalledWith('codex')
    expect(findButton(/^continue$/i)?.disabled).toBe(false)
  })

  // A starting agent that is installed is kept, even when another one is installed too.
  it('keeps an installed starting agent when another agent is also installed', async () => {
    await configureUnavailableRegistries('selected-installed')
    await renderWizard()
    expect(useSettingsStore.getState().setAgentFramework).not.toHaveBeenCalled()
    expect(useSettingsStore.getState().agentFrameworkId).toBe('claude-code')
  })

  // Continue stays disabled until the check for the newly selected framework
  // resolves, and the switch is not repeated after Back.
  it('waits for the selected alternative check and preserves the selection on Back', async () => {
    await configureUnavailableRegistries()
    const inspect = useSettingsStore.getState().checkEnvironment
    const pending = Promise.withResolvers<void>()
    useSettingsStore.setState({
      checkEnvironment: vi.fn(async () => {
        await pending.promise
        return inspect()
      })
    })
    await renderWizard()
    expect(useSettingsStore.getState().agentFrameworkId).toBe('opencode')
    expect(findButton(/^continue$/i)?.disabled).toBe(true)
    await act(async () => pending.resolve())
    expect(findButton(/^continue$/i)?.disabled).toBe(false)
    await clickButton(/^continue$/i)
    await clickButton(/^back$/i)
    expect(useSettingsStore.getState().setAgentFramework).toHaveBeenCalledOnce()
  })

  // The installed alternative is used as it is; no install runs.
  it('allows setup with an installed alternative when installation sources are unreachable', async () => {
    await configureUnavailableRegistries()
    await renderWizard()

    expect(section('Prepare environment')).not.toBeNull()
    expect(findButton(/^continue$/i)?.disabled).toBe(false)
    await clickButton(/^continue$/i)
    expect(section('Choose data location')).not.toBeNull()
    await clickButton(/^continue$/i)
    expect(useSettingsStore.getState().setAgentFramework).toHaveBeenCalledWith('opencode')
    expect(useSettingsStore.getState().installOpencode).not.toHaveBeenCalled()
    expect(useSettingsStore.getState().installClaude).not.toHaveBeenCalled()
  })

  // A failed system or storage check, or no installed agent at all, keeps the
  // step blocked and leaves the selected agent as it was.
  it.each(['storage', 'system', 'no-runtime'] as const)(
    'keeps setup blocked when the remaining requirement is %s',
    async (failure) => {
      await configureUnavailableRegistries(failure)
      await renderWizard()
      expect(findButton(/^continue$/i)?.disabled).toBe(true)
      expect(useSettingsStore.getState().setAgentFramework).not.toHaveBeenCalled()
      expect(useSettingsStore.getState().agentFrameworkId).toBe('claude-code')
      await clickButton(/^continue$/i)
      expect(section('Prepare environment')).not.toBeNull()
    }
  )

  // A provider test resolving after two Backs does not move the user; setup
  // does not finish.
  it('preserves the current location step when a provider test succeeds after Back', async () => {
    const pending =
      Promise.withResolvers<
        Awaited<ReturnType<ReturnType<typeof useSettingsStore.getState>['saveAndActivateProvider']>>
      >()
    const save = vi.fn().mockReturnValue(pending.promise)
    useSettingsStore.setState({ saveAndActivateProvider: save })
    await goToProvider()
    await clickButton(/test & continue/i)
    expect(save).toHaveBeenCalledOnce()
    await clickButton(/^back$/i)
    await clickButton(/^back$/i)
    expect(section('Choose data location')).not.toBeNull()

    await act(async () => {
      pending.resolve({ providerId: 'saved-1', validation: { ok: true, category: 'ok' } })
    })

    expect.soft(section('Choose data location')).not.toBeNull()
    expect.soft(section('Notebook runtime (optional)')).toBeNull()
    expect(useSettingsStore.getState().completeOnboarding).not.toHaveBeenCalled()
  })

  // Testing an already-saved provider again sends the same request plus the
  // saved id.
  it('updates the saved provider identity after returning from Notebook', async () => {
    const save = vi.fn().mockResolvedValue({
      providerId: 'saved-1',
      validation: { ok: true, category: 'ok' }
    })
    useSettingsStore.setState({ saveAndActivateProvider: save })
    await goToProvider()
    await clickButton(/test & continue/i)
    expect(section('Notebook runtime (optional)')).not.toBeNull()
    expect(save.mock.calls[0][0].id).toBeUndefined()
    await clickButton(/^back$/i)
    await clickButton(/test & continue/i)

    expect(save).toHaveBeenCalledTimes(2)
    expect(save.mock.calls[1][0]).toMatchObject({ ...save.mock.calls[0][0], id: 'saved-1' })
    expect(section('Notebook runtime (optional)')).not.toBeNull()
  })

  // A provider page opened again after Back and Continue is not moved by the
  // earlier test, and its next test updates the provider that test saved.
  it('keeps a remounted provider page open when its previous test completes', async () => {
    const pending = Promise.withResolvers<{
      providerId: string
      validation: { ok: true; category: 'ok' }
    }>()
    const save = vi
      .fn()
      .mockReturnValueOnce(pending.promise)
      .mockResolvedValue({
        providerId: 'saved-1',
        validation: { ok: true, category: 'ok' }
      })
    useSettingsStore.setState({ saveAndActivateProvider: save })
    await goToProvider()
    await clickButton(/test & continue/i)
    await clickButton(/^back$/i)
    await clickButton(/^continue$/i)
    await act(async () => {
      pending.resolve({ providerId: 'saved-1', validation: { ok: true, category: 'ok' } })
    })
    expect(section('Configure model')).not.toBeNull()
    await clickButton(/test & continue/i)
    expect(save.mock.calls[1][0]).toMatchObject({ id: 'saved-1', requireExisting: true })
    expect(section('Notebook runtime (optional)')).not.toBeNull()
  })

  // After a failed test the saved provider is still the one updated, even with
  // edited connection fields.
  it('reuses the committed identity after failed validation and edited connection fields', async () => {
    const save = vi.fn().mockResolvedValue({
      providerId: 'saved-1',
      validation: { ok: false, category: 'network' }
    })
    useSettingsStore.setState({ saveAndActivateProvider: save })
    await goToProvider()
    await clickButton(/test & continue/i)
    expect(section('Configure model')).not.toBeNull()
    await act(async () => {
      fireEvent.change(container.querySelector('#provider-base-url')!, {
        target: { value: 'https://replacement.example' }
      })
    })
    await clickButton(/test & continue/i)
    expect(save.mock.calls[1][0]).toMatchObject({
      id: 'saved-1',
      requireExisting: true,
      baseUrl: 'https://replacement.example'
    })
  })

  // Changing the provider type starts a new provider, even after switching back.
  it('starts a new identity after changing provider kind and returning to custom', async () => {
    await goToProvider()
    await clickButton(/test & continue/i)
    await clickButton(/^back$/i)
    await selectOption('Provider type', 'Anthropic')
    expect(container.querySelector('[aria-label="Provider type"]')?.textContent).toContain(
      'Anthropic'
    )
    await selectOption('Provider type', 'Custom Gateway')
    await fillRequiredProviderFields(container)
    await clickButton(/test & continue/i)
    const save = vi.mocked(useSettingsStore.getState().saveAndActivateProvider)
    expect(save).toHaveBeenCalledTimes(2)
    expect(save.mock.calls[1][0].id).toBeUndefined()
  })

  // Official vendors: testing a saved one again updates it; switching to
  // another vendor starts a new provider.
  it('updates a saved official provider and starts a new one for another vendor', async () => {
    const save = vi
      .fn()
      .mockResolvedValueOnce({ providerId: 'vendor-1', validation: { ok: true, category: 'ok' } })
      .mockResolvedValueOnce({ providerId: 'vendor-1', validation: { ok: true, category: 'ok' } })
      .mockResolvedValue({ providerId: 'vendor-2', validation: { ok: true, category: 'ok' } })
    useSettingsStore.setState({ saveAndActivateProvider: save })
    readyClaudeState()
    await renderWizard()
    await clickButton(/^continue$/i)
    await clickButton(/^continue$/i)
    await clickButton(/^continue$/i)
    await selectOption('Provider type', 'Anthropic')
    await typeApiKey('sk-anthropic')
    await clickButton(/test & continue/i)
    expect(section('Notebook runtime (optional)')).not.toBeNull()
    expect(save.mock.calls[0][0]).toMatchObject({ type: 'official', vendorId: 'anthropic' })
    expect(save.mock.calls[0][0].id).toBeUndefined()

    await clickButton(/^back$/i)
    await clickButton(/test & continue/i)
    expect(save.mock.calls[1][0]).toMatchObject({
      type: 'official',
      vendorId: 'anthropic',
      id: 'vendor-1',
      requireExisting: true
    })

    await clickButton(/^back$/i)
    await selectOption('Provider type', 'DeepSeek')
    await typeApiKey('sk-deepseek')
    await clickButton(/test & continue/i)
    expect(save).toHaveBeenCalledTimes(3)
    expect(save.mock.calls[2][0]).toMatchObject({ type: 'official', vendorId: 'deepseek' })
    expect(save.mock.calls[2][0].id).toBeUndefined()

    await clickButton(/^back$/i)
    await selectOption('Provider type', 'Anthropic')
    await typeApiKey('sk-anthropic')
    await clickButton(/test & continue/i)
    expect(save).toHaveBeenCalledTimes(4)
    expect(save.mock.calls[3][0]).toMatchObject({ type: 'official', vendorId: 'anthropic' })
    expect(save.mock.calls[3][0].id).toBeUndefined()
  })

  // A save that completes after the provider type changed does not attach its
  // id to the new draft.
  it('does not attach a late saved identity to a new provider draft', async () => {
    const pending = Promise.withResolvers<{
      providerId: string
      validation: { ok: true; category: 'ok' }
    }>()
    const save = vi
      .fn()
      .mockReturnValueOnce(pending.promise)
      .mockResolvedValue({
        providerId: 'saved-2',
        validation: { ok: true, category: 'ok' }
      })
    useSettingsStore.setState({ saveAndActivateProvider: save })
    await goToProvider()
    await clickButton(/test & continue/i)
    await clickButton(/^back$/i)
    await clickButton(/^continue$/i)
    await selectOption('Provider type', 'Anthropic')
    expect(container.querySelector('[aria-label="Provider type"]')?.textContent).toContain(
      'Anthropic'
    )
    await selectOption('Provider type', 'Custom Gateway')
    await fillRequiredProviderFields(container)
    await act(async () => {
      pending.resolve({ providerId: 'saved-1', validation: { ok: true, category: 'ok' } })
    })
    expect(section('Configure model')).not.toBeNull()
    await clickButton(/test & continue/i)
    expect(save.mock.calls[1][0].id).toBeUndefined()
  })

  // A saved provider deleted in the meantime: the update must not recreate it,
  // the error is shown, and only the user's next test creates a new one. The
  // desktop app delivers main-process errors with Electron's IPC prefix.
  it.each([
    'Provider no longer exists.',
    "Error invoking remote method 'settings:upsert-provider': Error: Provider no longer exists."
  ])('requires the saved entity to exist and starts a new one only on an explicit retry (%s)', async (message) => {
    const save = vi
      .fn()
      .mockResolvedValueOnce({ providerId: 'saved-1', validation: { ok: true, category: 'ok' } })
      .mockRejectedValueOnce(new Error(message))
      .mockResolvedValueOnce({ providerId: 'saved-2', validation: { ok: true, category: 'ok' } })
    useSettingsStore.setState({ saveAndActivateProvider: save })
    await goToProvider()
    await clickButton(/test & continue/i)
    await clickButton(/^back$/i)
    await clickButton(/test & continue/i)
    expect(save.mock.calls[1][0]).toMatchObject({ id: 'saved-1', requireExisting: true })
    expect(section('Configure model')).not.toBeNull()
    expect(alertText().trim().length).toBeGreaterThan(0)
    expect(save).toHaveBeenCalledTimes(2)
    await clickButton(/test & continue/i)
    expect(save).toHaveBeenCalledTimes(3)
    expect(save.mock.calls[2][0].id).toBeUndefined()
  })

  // Any other save error leaves the saved provider as the one to update.
  it('keeps the saved identity after a save error other than a missing provider', async () => {
    const save = vi
      .fn()
      .mockResolvedValueOnce({ providerId: 'saved-1', validation: { ok: true, category: 'ok' } })
      .mockRejectedValueOnce(new Error('Could not reach the settings service.'))
      .mockResolvedValue({ providerId: 'saved-1', validation: { ok: true, category: 'ok' } })
    useSettingsStore.setState({ saveAndActivateProvider: save })
    await goToProvider()
    await clickButton(/test & continue/i)
    await clickButton(/^back$/i)
    await clickButton(/test & continue/i)
    expect(section('Configure model')).not.toBeNull()
    await clickButton(/test & continue/i)
    expect(save).toHaveBeenCalledTimes(3)
    expect(save.mock.calls[2][0]).toMatchObject({ id: 'saved-1', requireExisting: true })
  })

  // The English guidance names the agent it was given.
  it('names the selected agent in the English incompatible-provider guidance', async () => {
    await openProviderForCodex('Codex Nightly')
    await clickButton(/test & continue/i)
    expect(useSettingsStore.getState().saveAndActivateProvider).not.toHaveBeenCalled()
    expect(alertText()).toContain('Codex Nightly')
  })

  // Every shipped language shows its own translation of that guidance, with the
  // agent's name filled in. The guidance may come from one catalog entry or several.
  it.each(['de', 'es', 'fr', 'ja', 'ko', 'ru', 'zh-Hans', 'zh-Hant'])(
    'localizes the incompatible-provider guidance in %s',
    async (language) => {
      const name = 'Codex Nightly'
      await openProviderForCodex(name)
      await clickButton(/test & continue/i)
      const english = alertText()
      expect(english).toContain(name)

      await act(async () => i18next.changeLanguage(language))
      const testLabel = i18next.t('Test & continue')
      await clickButton(new RegExp(`^${escapeRegExp(testLabel)}$`, 'i'))

      expect(useSettingsStore.getState().saveAndActivateProvider).not.toHaveBeenCalled()
      const localized = alertText()
      expect(localized).toContain(name)
      expect(localized).not.toBe(english)

      // The entries behind the English text cover it, and each one's translation is shown.
      const entries = catalogEntriesWithin(language, english, name)
      const covered = entries.reduce((total, [key]) => total + fillPlaceholders(key, name).length, 0)
      expect(covered).toBeGreaterThanOrEqual(english.length * 0.8)
      for (const [, value] of entries) expect(localized).toContain(fillPlaceholders(value, name))
      // The guidance is its own message, not a string the app already had for something else.
      const existing = baseCatalogKeys(language)
      expect(entries.some(([key]) => !existing.has(key))).toBe(true)

      // A translation is not the English sentence with small edits.
      const englishWords = new Set(contentWords(english, name))
      const shared = [...englishWords].filter((word) => contentWords(localized, name).includes(word))
      expect(shared.length).toBeLessThan(englishWords.size / 2)
    }
  )

  // A current successful test advances to the notebook step, and setup
  // completes only on an explicit Finish.
  it('advances on a current successful test and finishes only on explicit Finish', async () => {
    await goToProvider()
    await clickButton(/test & continue/i)
    expect(section('Notebook runtime (optional)')).not.toBeNull()
    expect(useSettingsStore.getState().completeOnboarding).not.toHaveBeenCalled()
    await clickButton(/^finish$/i)
    expect(useSettingsStore.getState().completeOnboarding).toHaveBeenCalledOnce()
  })
})
