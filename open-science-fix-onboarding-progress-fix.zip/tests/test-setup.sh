#!/usr/bin/env bash
# test-setup.sh: environment bootstrap for the test run.
#
# The onboarding renderer source is consumed directly by vitest through the
# `@` → src/renderer/src alias (see vitest.config.ts); there is no built
# `dist/` to regenerate, so source edits under
# src/renderer/src/pages/onboarding/ are live immediately. This script only
# makes sure the Python TOML reader and the vitest binary are present.
#
# Sourced (not exec'd) by the test runner so env vars set here stay live
# for the test subprocess.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/open-science}"
export REPO_DIR
cd "$REPO_DIR"

# The test runner reads verify.toml via tomllib (Python 3.11+) or tomli
# (<=3.10). The Ubuntu 22.04 base image ships Python 3.10 with neither, so
# without tomli the verify.toml is silently dropped and the runner falls back
# to its default runner, which fails because this repo uses vitest. Install it
# defensively, from the local cache first.
if ! python3 -c "import tomllib" 2>/dev/null && ! python3 -c "import tomli" 2>/dev/null; then
    python3 -m pip install --no-index --find-links /opt/cache/pip "tomli==2.2.1" \
        || python3 -m pip install "tomli==2.2.1" \
        || python3 -m pip install --break-system-packages "tomli==2.2.1" \
        || true
fi

# Sanity check: vitest must be resolvable from the repo root. A failure here
# points at a corrupted node_modules from the image build; bail loudly now
# rather than surfacing a confusing "vitest: not found" mid-run. The image
# already holds the full dependency closure, so a reinstall here is a
# last-resort repair, not the norm.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/; " \
         "the baked image closure looks corrupt. Reinstalling from the warm cache." >&2
    npm ci --offline --prefer-offline --no-audit --no-fund \
        || npm ci --no-audit --no-fund
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR node=$(node --version 2>/dev/null || echo unknown) vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
