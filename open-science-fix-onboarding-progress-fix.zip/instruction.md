## Task

On "Prepare environment", Continue never enables when the wizard's starting agent is missing and its download sources are unreachable, even when the system and storage checks both pass and some other agent the app can run is installed. The wizard should switch to that installed agent itself and enable Continue once the check for it passes, without installing anything. An agent the app can't use doesn't count, for example a Codex adapter older than the app requires. If the system or storage check fails, or nothing usable is installed, the step remains blocked on the agent the user already had.

On "Configure model", a provider test that finishes after the user went Back can still push them forward to the notebook step. They should stay where they are, including when they've already come back to the provider step, and setup shouldn't finish.

If the user goes back after a provider is saved and tests again, they get a second copy of it. Testing again should update the saved one, also after a failed test, a save error or edited connection details. A different provider type or vendor means a new provider: after the switch, testing never updates a provider saved under the earlier choice, even if the user switches back later. If the saved provider was deleted in the meantime, testing again should say so and keep the user on the step rather than quietly recreating it; their next test then creates a new one.

The message saying a provider can't be used with the chosen agent is always in English. It should be translated into every language the app ships, with the agent's name in it.
