"""Behavioral checks for first-turn replay-base resolution in the chat gateway.

The chat gateway resolves a "replay base" — the checkpoint a rerun forks from —
whenever a turn is regenerated or edited-and-rerun. On a thread whose only turn
is its first, a reminder middleware re-keys the first user message mid-run: the
injected reminder takes the original ``{id}`` and the real user message is moved
to ``{id}__user``. Every checkpoint written before that node ran therefore holds
the same prompt under an id the "by message id" lookup cannot match, and the
lookup can anchor on a mid-run snapshot that still owns an interrupted node's
pending writes. Resuming there replays those writes and re-adds the very prompt
the rerun was meant to replace.

These tests drive the four pre-existing, stable surfaces where that decision is
observable:

  * ``find_checkpoint_before_message_chronologically`` and
    ``find_checkpoint_before_message`` in ``app.gateway.checkpoint_lineage``
    (the two replay-base lookups), and
  * ``_prepare_regenerate_payload`` and ``_prepare_edit_regenerate_payload`` in
    ``app.gateway.routers.thread_runs`` (the two "prepare" functions the HTTP
    endpoints delegate to).

They assert only on the public outputs of those surfaces — the resolved
checkpoint id and the replayed message id. The in-memory checkpoint-history
harness below is reconstructed locally so the checks do not depend on the repo's
own test module. Mid-run checkpoints expose scheduled work through both the
``next`` and ``tasks`` attributes a real snapshot carries, so a predicate that
inspects either one behaves identically; a checkpoint the thread came to rest at
exposes neither as truthy, and a degraded read path that cannot derive scheduled
work exposes neither attribute at all.
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

# ---------------------------------------------------------------------------
# Import bootstrap
#
# verify.py lives outside the repository tree, so it must put the backend
# package root on sys.path the way the backend test suite's conftest.py does,
# and pre-register the same stand-in for ``deerflow.subagents.executor``. That
# module participates in a production import cycle
# (deerflow.subagents.__init__ -> .executor -> deerflow.agents.thread_state
#  -> deerflow.agents.__init__ -> lead_agent.agent -> subagent_limit_middleware
#  -> deerflow.subagents.executor); injecting a stand-in before any gateway
# module is imported lets ``from .executor import ...`` resolve immediately.
# ---------------------------------------------------------------------------

_BACKEND_ROOT = Path("/repo/deer-flow/backend")
if str(_BACKEND_ROOT) not in sys.path:
    sys.path.insert(0, str(_BACKEND_ROOT))

if "deerflow.subagents.executor" not in sys.modules:
    _executor_stub = MagicMock()
    _executor_stub.SubagentExecutor = MagicMock
    _executor_stub.SubagentResult = MagicMock
    _executor_stub.SubagentStatus = MagicMock
    _executor_stub.MAX_CONCURRENT_SUBAGENTS = 3
    _executor_stub.get_background_task_result = MagicMock()
    sys.modules["deerflow.subagents.executor"] = _executor_stub

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage  # noqa: E402

from app.gateway.checkpoint_lineage import (  # noqa: E402
    CheckpointParentMissingError,
    find_checkpoint_before_message,
    find_checkpoint_before_message_chronologically,
)
from deerflow.utils.messages import ORIGINAL_USER_CONTENT_KEY  # noqa: E402

THREAD_ID = "thread-1"

# "__user" is the suffix the reminder middleware gives the real user message
# when it re-keys the first turn. It is spelled as a plain data literal here
# because these checks exercise the behavior through the public lookup/prepare
# surfaces rather than importing any helper that knows the convention.
_SWAP_SUFFIX = "__user"


# ---------------------------------------------------------------------------
# Snapshot / history helpers (lineage-lookup surfaces)
# ---------------------------------------------------------------------------


def _pending(names: tuple[str, ...]) -> tuple[object, ...]:
    """Build a ``tasks`` tuple mirroring a ``next`` tuple of node names.

    A real snapshot exposes scheduled graph work through both ``next`` (node
    names) and ``tasks`` (task objects). Mirroring both keeps the fixture
    faithful and keeps the checks agnostic to which attribute a settled-state
    predicate happens to inspect.
    """
    return tuple(SimpleNamespace(name=name, interrupts=()) for name in names)


def _snapshot(
    checkpoint_id: str,
    messages: list[object],
    *,
    next_tasks: tuple[str, ...] = (),
    parent_id: str | None = None,
):
    parent_config = None
    if parent_id is not None:
        parent_config = {
            "configurable": {
                "thread_id": THREAD_ID,
                "checkpoint_ns": "",
                "checkpoint_id": parent_id,
            }
        }
    return SimpleNamespace(
        values={"messages": messages},
        config={
            "configurable": {
                "thread_id": THREAD_ID,
                "checkpoint_ns": "",
                "checkpoint_id": checkpoint_id,
                "checkpoint_map": None,
            }
        },
        metadata={},
        parent_config=parent_config,
        next=next_tasks,
        tasks=_pending(next_tasks),
    )


class _Accessor:
    """Minimal checkpoint accessor over a fixed snapshot list, keyed by id."""

    def __init__(self, snapshots: list[object]) -> None:
        self.snapshots = snapshots

    async def aget(self, config):
        checkpoint_id = config.get("configurable", {}).get("checkpoint_id")
        return next(
            (item for item in self.snapshots if item.config["configurable"]["checkpoint_id"] == checkpoint_id),
            SimpleNamespace(values={}, config={}, metadata=None, parent_config=None, next=(), tasks=()),
        )


def _first_turn_lineage() -> list[object]:
    """Newest-first history of a thread still on its first turn.

    ``ckpt-empty`` is the state the thread came to rest at before the turn ran.
    ``ckpt-input`` / ``ckpt-mid`` / ``ckpt-after-inject`` are mid-run snapshots
    that still carry scheduled work; ``ckpt-mid`` additionally holds the prompt
    under its pre-swap id. ``ckpt-head`` is the finished turn.
    """
    system = SystemMessage(id="h1", content="<system-reminder>date</system-reminder>")
    swapped_human = HumanMessage(id=f"h1{_SWAP_SUFFIX}", content="question")
    raw_human = HumanMessage(id="h1", content="question")
    ai = AIMessage(id="ai-1", content="answer")
    return [
        _snapshot("ckpt-head", [system, swapped_human, ai], parent_id="ckpt-after-inject"),
        _snapshot(
            "ckpt-after-inject",
            [system, swapped_human],
            next_tasks=("LoopDetectionMiddleware.before_agent",),
            parent_id="ckpt-mid",
        ),
        _snapshot(
            "ckpt-mid",
            [raw_human],
            next_tasks=("DynamicContextMiddleware.before_agent",),
            parent_id="ckpt-input",
        ),
        _snapshot("ckpt-input", [], next_tasks=("__start__",), parent_id="ckpt-empty"),
        _snapshot("ckpt-empty", [], parent_id=None),
    ]


def test_chronological_scan_skips_checkpoints_with_pending_tasks():
    """C3 (fail_to_pass): the chronological fallback forks from the rest state.

    The target prompt lives under its post-swap id, so the scan must walk past
    every mid-run snapshot that still carries scheduled work and anchor on the
    checkpoint the thread came to rest at.
    """
    history = _first_turn_lineage()

    base, found = find_checkpoint_before_message_chronologically(history, f"h1{_SWAP_SUFFIX}")

    assert found is True
    assert base is not None
    assert base.config["configurable"]["checkpoint_id"] == "ckpt-empty"


def test_lineage_walk_skips_checkpoints_with_pending_tasks():
    """C3 (fail_to_pass): the parent-lineage walk forks from the rest state too."""
    history = _first_turn_lineage()
    accessor = _Accessor(history)

    base = asyncio.run(find_checkpoint_before_message(accessor, history[0], f"h1{_SWAP_SUFFIX}", max_depth=10))

    assert base.config["configurable"]["checkpoint_id"] == "ckpt-empty"


def test_chronological_scan_is_permissive_without_task_info():
    """C4 (fail_to_pass): the degraded read path still selects a base.

    A read path that cannot derive scheduled work reports none. "No evidence of
    scheduled work" must be treated as a resting state (absence of evidence is
    permissive), so a base is still chosen rather than nothing.
    """
    human = HumanMessage(id="h1", content="question")
    history = [
        SimpleNamespace(
            values={"messages": [human]},
            config={"configurable": {"thread_id": THREAD_ID, "checkpoint_ns": "", "checkpoint_id": "ckpt-head"}},
            metadata={},
        ),
        SimpleNamespace(
            values={"messages": []},
            config={"configurable": {"thread_id": THREAD_ID, "checkpoint_ns": "", "checkpoint_id": "ckpt-base"}},
            metadata={},
        ),
    ]

    base, found = find_checkpoint_before_message_chronologically(history, "h1")

    assert found is True
    assert base is not None
    assert base.config["configurable"]["checkpoint_id"] == "ckpt-base"


def test_lineage_walk_fails_closed_without_settled_ancestor():
    """C6 (fail_to_pass): fail closed instead of forking a mid-run snapshot.

    When the only ancestor still carries scheduled work and no resting ancestor
    exists, the walk must surface the missing-parent error, not silently return
    the mid-run snapshot.
    """
    swapped_human = HumanMessage(id=f"h1{_SWAP_SUFFIX}", content="question")
    raw_human = HumanMessage(id="h1", content="question")
    ai = AIMessage(id="ai-1", content="answer")
    history = [
        _snapshot("ckpt-head", [swapped_human, ai], parent_id="ckpt-mid"),
        _snapshot(
            "ckpt-mid",
            [raw_human],
            next_tasks=("DynamicContextMiddleware.before_agent",),
            parent_id=None,
        ),
    ]
    accessor = _Accessor(history)

    with pytest.raises(CheckpointParentMissingError):
        asyncio.run(find_checkpoint_before_message(accessor, history[0], f"h1{_SWAP_SUFFIX}", max_depth=10))


def test_later_turn_resolves_previous_settled_tail():
    """C5 (pass_to_pass): a later turn still resolves to the prior run's tail.

    The already-working multi-turn path must keep resolving to the previous
    run's resting checkpoint; the first-turn rule must not over-skip it.
    """
    human1 = HumanMessage(id="h1", content="first")
    ai1 = AIMessage(id="ai-1", content="first answer")
    human2 = HumanMessage(id="h2", content="second")
    ai2 = AIMessage(id="ai-2", content="second answer")
    history = [
        _snapshot("ckpt-turn2-head", [human1, ai1, human2, ai2]),
        _snapshot("ckpt-turn1-tail", [human1, ai1]),
    ]

    base, found = find_checkpoint_before_message_chronologically(history, "h2")

    assert found is True
    assert base is not None
    assert base.config["configurable"]["checkpoint_id"] == "ckpt-turn1-tail"


# ---------------------------------------------------------------------------
# Prepare-function harness (regenerate / edit-regenerate surfaces)
# ---------------------------------------------------------------------------


def _raw_checkpoint(
    checkpoint_id: str,
    messages: list[object],
    *,
    metadata: dict | None = None,
    goal: dict | None = None,
    next_tasks: tuple[str, ...] = (),
    parent_id: str | None = None,
):
    channel_values: dict[str, object] = {"messages": messages}
    if goal is not None:
        channel_values["goal"] = goal
    parent_config = None
    if parent_id is not None:
        parent_config = {
            "configurable": {
                "thread_id": THREAD_ID,
                "checkpoint_ns": "",
                "checkpoint_id": parent_id,
            }
        }
    return SimpleNamespace(
        config={
            "configurable": {
                "thread_id": THREAD_ID,
                "checkpoint_ns": "",
                "checkpoint_id": checkpoint_id,
                "checkpoint_map": None,
            }
        },
        checkpoint={"channel_values": channel_values},
        metadata=metadata or {},
        parent_config=parent_config,
        next=next_tasks,
        tasks=_pending(next_tasks),
    )


class _FakeCheckpointer:
    def __init__(self, history, *, latest=None):
        self.history = history
        self.latest = latest
        self.alist_limits: list[int | None] = []

    async def aget_tuple(self, config):
        checkpoint_id = config.get("configurable", {}).get("checkpoint_id")
        if checkpoint_id:
            return next(
                (item for item in self.history if item.config["configurable"]["checkpoint_id"] == checkpoint_id),
                None,
            )
        return self.latest or (self.history[0] if self.history else None)

    async def alist(self, config, limit=200):
        self.alist_limits.append(limit)
        for item in self.history[:limit]:
            yield item


class _FakeAccessor:
    def __init__(self, checkpointer: _FakeCheckpointer):
        self.checkpointer = checkpointer

    @staticmethod
    def _from_raw(checkpoint):
        return SimpleNamespace(
            values=dict(checkpoint.checkpoint.get("channel_values", {})),
            config=checkpoint.config,
            metadata=checkpoint.metadata,
            parent_config=getattr(checkpoint, "parent_config", None),
            next=getattr(checkpoint, "next", ()),
            tasks=getattr(checkpoint, "tasks", ()),
        )

    async def aget(self, config):
        raw = await self.checkpointer.aget_tuple(config)
        if raw is None:
            return SimpleNamespace(values={}, config={}, metadata={}, next=(), tasks=())
        return self._from_raw(raw)

    async def ahistory(self, config, *, limit=None):
        self.checkpointer.alist_limits.append(limit)
        history = [self._from_raw(item) for item in self.checkpointer.history]
        return history[:limit] if limit is not None else history


class _FakeEventStore:
    def __init__(self, rows):
        self.rows = rows

    async def list_messages(self, thread_id, *, limit=50, before_seq=None, after_seq=None):
        return self.rows[-limit:]


class _FakeRunManager:
    def __init__(self, records):
        self.records = records

    async def list_by_thread(self, thread_id, *, user_id=None, limit=100):
        return self.records[:limit]

    async def get(self, run_id, *, user_id=None):
        return next((record for record in self.records if record.run_id == run_id), None)


def _request(checkpointer, event_store, *, run_manager=None, user_id="user-1"):
    from app.gateway.auth_disabled import AUTH_SOURCE_SESSION

    return SimpleNamespace(
        app=SimpleNamespace(
            state=SimpleNamespace(
                checkpointer=checkpointer,
                run_event_store=event_store,
                run_manager=run_manager or _FakeRunManager([]),
            )
        ),
        state=SimpleNamespace(user=SimpleNamespace(id=user_id), auth_source=AUTH_SOURCE_SESSION),
    )


@pytest.fixture(autouse=True)
def _patch_checkpoint_accessor(monkeypatch):
    """Route the gateway's accessor builders at the in-memory checkpointer.

    The real builders construct a datastore-backed accessor; the prepare
    functions only need something with ``aget``/``ahistory`` over the history
    on ``request.app.state.checkpointer``.
    """
    from app.gateway.routers import thread_runs

    def build_accessor(request, *, thread_id, assistant_id=None, checkpoint_id=None):
        config = {"configurable": {"thread_id": thread_id, "checkpoint_ns": ""}}
        if checkpoint_id is not None:
            config["configurable"]["checkpoint_id"] = checkpoint_id
        return _FakeAccessor(request.app.state.checkpointer), config

    async def build_thread_accessor(request, *, thread_id, checkpoint_id=None):
        return build_accessor(request, thread_id=thread_id, checkpoint_id=checkpoint_id)

    monkeypatch.setattr(thread_runs, "build_checkpoint_state_accessor", build_accessor)
    monkeypatch.setattr(thread_runs, "build_thread_checkpoint_state_accessor", build_thread_accessor)


def _answer_run_fixtures(ai_id: str = "ai-1", content: str = "answer v1"):
    from deerflow.runtime import RunStatus

    event_store = _FakeEventStore(
        [
            {
                "run_id": "run-old",
                "event_type": "llm.ai.response",
                "category": "message",
                "content": {"id": ai_id, "type": "ai", "content": content},
                "metadata": {"caller": "lead_agent"},
            }
        ]
    )
    run_manager = _FakeRunManager(
        [SimpleNamespace(run_id="run-old", status=RunStatus.success, metadata={}, last_ai_message=content)]
    )
    return event_store, run_manager


def _first_turn_checkpointer(human_id: str = "human-1") -> _FakeCheckpointer:
    """First-turn history whose user message id was swapped mid-run.

    ``ckpt-empty`` is the resting state; ``ckpt-input`` / ``ckpt-mid`` /
    ``ckpt-after-inject`` carry scheduled work; ``ckpt-mid`` still holds the
    prompt under its pre-swap id and owns the injection node's pending writes.
    The swapped id is ``{human_id}__user``; the resting/pre-injection states
    hold the prompt under the bare ``{human_id}``.
    """
    system = SystemMessage(id=human_id, content="<system-reminder>date</system-reminder>")
    swapped_human = HumanMessage(id=f"{human_id}{_SWAP_SUFFIX}", content="original question")
    raw_human = HumanMessage(id=human_id, content="original question")
    ai = AIMessage(id="ai-1", content="answer v1")
    return _FakeCheckpointer(
        [
            _raw_checkpoint("ckpt-head", [system, swapped_human, ai], parent_id="ckpt-after-inject"),
            _raw_checkpoint(
                "ckpt-after-inject",
                [system, swapped_human],
                next_tasks=("LoopDetectionMiddleware.before_agent",),
                parent_id="ckpt-mid",
            ),
            _raw_checkpoint(
                "ckpt-mid",
                [raw_human],
                next_tasks=("DynamicContextMiddleware.before_agent",),
                parent_id="ckpt-input",
            ),
            _raw_checkpoint("ckpt-input", [], next_tasks=("__start__",), parent_id="ckpt-empty"),
            _raw_checkpoint("ckpt-empty", [], parent_id=None),
        ]
    )


def test_prepare_edit_regenerate_skips_mid_run_base_on_first_turn():
    """C1 (fail_to_pass): first-turn edit-and-rerun forks from the rest state.

    ``ckpt-mid`` still holds the original prompt (under its pre-swap id) and
    owns the injection node's pending writes, so forking from it would re-add
    the prompt the edit replaces. The resolved base must be ``ckpt-empty``.
    """
    from app.gateway.routers import thread_runs

    event_store, run_manager = _answer_run_fixtures()

    response = asyncio.run(
        thread_runs._prepare_edit_regenerate_payload(
            THREAD_ID,
            f"human-1{_SWAP_SUFFIX}",
            "edited question",
            _request(_first_turn_checkpointer(), event_store, run_manager=run_manager),
        )
    )

    assert response.checkpoint["checkpoint_id"] == "ckpt-empty"
    assert response.metadata["regenerate_checkpoint_id"] == "ckpt-empty"


def test_prepare_regenerate_replays_pre_swap_user_message_id():
    """C2 (fail_to_pass): first-turn regenerate forks from the rest state and
    replays the user message under its pre-swap id.

    The resolved base must be ``ckpt-empty``, and because that base predates the
    reminder injection the replayed user message must re-enter under the id the
    client originally sent (``human-1``), not the swapped ``human-1__user`` id,
    or the reminder block is dropped on replay.
    """
    from app.gateway.routers import thread_runs

    event_store, run_manager = _answer_run_fixtures()

    response = asyncio.run(
        thread_runs._prepare_regenerate_payload(
            THREAD_ID,
            "ai-1",
            _request(_first_turn_checkpointer(), event_store, run_manager=run_manager),
        )
    )

    assert response.checkpoint["checkpoint_id"] == "ckpt-empty"
    assert response.input["messages"][0]["id"] == "human-1"


def test_pre_swap_id_restore_is_applied_only_to_injected_ids():
    """C7 (fail_to_pass): the pre-swap restore is suffix-selective.

    The restore must strip the swap suffix from an injected ``{id}__user`` user
    message so the replay feeds the graph the id the client originally sent, and
    must leave an ordinary (never-swapped) id untouched. Both branches run
    through the same regenerate path:

      * injected head (``human-7__user``) -> replayed as the bare ``human-7``,
      * ordinary head (``human-7`` with no suffix) -> replayed unchanged.
    """
    from app.gateway.routers import thread_runs

    event_store, run_manager = _answer_run_fixtures()

    injected = asyncio.run(
        thread_runs._prepare_regenerate_payload(
            THREAD_ID,
            "ai-1",
            _request(_first_turn_checkpointer("human-7"), event_store, run_manager=run_manager),
        )
    )
    assert injected.input["messages"][0]["id"] == "human-7"

    ordinary_human = HumanMessage(
        id="human-7",
        content="/data-analysis analyze data.csv",
        additional_kwargs={ORIGINAL_USER_CONTENT_KEY: "/data-analysis analyze data.csv"},
    )
    ordinary_ai = AIMessage(id="ai-1", content="answer v1")
    ordinary_checkpointer = _FakeCheckpointer(
        [
            _raw_checkpoint("ckpt-ai", [ordinary_human, ordinary_ai]),
            _raw_checkpoint("ckpt-base", []),
        ]
    )
    ordinary = asyncio.run(
        thread_runs._prepare_regenerate_payload(
            THREAD_ID,
            "ai-1",
            _request(ordinary_checkpointer, event_store, run_manager=run_manager),
        )
    )
    assert ordinary.checkpoint["checkpoint_id"] == "ckpt-base"
    assert ordinary.input["messages"][0]["id"] == "human-7"
