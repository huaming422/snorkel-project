#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
#
# The image baked the backend dependency closure for this repository at the base
# commit into /opt/venv (Dockerfile block 10), installing the project and its
# workspace member as EDITABLE. Editable installs resolve imports from the live
# source tree, so a patched working tree is picked up with no re-sync. This step
# therefore VERIFIES the baked environment instead of rebuilding it: with the
# network cut, an offline rebuild of the editable member cannot run, because its
# build backend is not present in the runtime package cache.

VENV_PY=/opt/venv/bin/python
BACKEND=/repo/deer-flow/backend

cd "$BACKEND"

# Loud preflight: every module the verifier imports must load under the baked
# interpreter before any check runs. This mirrors the verifier's own import
# bootstrap — the backend source root goes on sys.path, and a stand-in is
# registered for the executor module that otherwise closes an import cycle.
# It warns rather than fails so a transient import quirk lands in the log and
# a genuine break still surfaces as a normal collection error under pytest,
# instead of masking the whole run as a single setup exception.
if "$VENV_PY" - <<'PY'
import sys
from unittest.mock import MagicMock

sys.path.insert(0, "/repo/deer-flow/backend")

stub = MagicMock()
stub.SubagentExecutor = MagicMock
stub.SubagentResult = MagicMock
stub.SubagentStatus = MagicMock
stub.MAX_CONCURRENT_SUBAGENTS = 3
stub.get_background_task_result = MagicMock()
sys.modules["deerflow.subagents.executor"] = stub

import app.gateway.checkpoint_lineage  # noqa: F401
import app.gateway.routers.thread_runs  # noqa: F401
import deerflow.utils.messages  # noqa: F401
print("[test-setup] backend modules import cleanly under /opt/venv")
PY
then
    :
else
    echo "[test-setup] WARNING backend import preflight failed (see above)" >&2
fi

# No services and no data seeding: the behavior under test is exercised as pure
# functions over in-memory histories. No assertion logic here.
