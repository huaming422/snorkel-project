## Task

In a chat thread whose only turn is the first one, editing that message and
rerunning it doesn't take: the assistant answers the original question, not the
edited one, even though the message bubble shows the edited text. Reload the
thread and the edit is gone entirely, with the original prompt back in its place.

Editing the latest turn of a longer conversation (more than one turn) works
fine, which is what makes this look like a front-end glitch. Plain regenerate,
rerunning a turn without editing it, misbehaves the same way on a first turn.

Dig into why the first-turn edit-and-rerun and regenerate replay the wrong thing
and fix it.
