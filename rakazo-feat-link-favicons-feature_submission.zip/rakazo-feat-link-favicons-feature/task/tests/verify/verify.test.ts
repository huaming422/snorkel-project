// @vitest-environment node
// @ts-nocheck
//
// Design-token stylesheet sync guard (pass-to-pass).
//
// The project renders its CSS stylesheet from the TypeScript colour palette,
// so the two must stay byte-for-byte consistent — any drift means the
// stylesheet was hand-edited or left stale after a palette change. This guard
// asserts that invariant holds for whatever palette the submission ships,
// without constraining the palette's contents in any way: it never requires,
// counts, or names any particular token. A solution that adds a token, reuses
// an existing one, or adds none at all passes equally, as long as the on-disk
// stylesheet is exactly what the palette renders.
//
// The favicon feature itself is verified behaviorally by the validation stories
// (resolver/endpoint/render surfaces) and the privacy rubric; this file carries
// only the framework-mandated token/stylesheet-sync regression guard.
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import { darkTokens, lightTokens, renderTokensCss } from "./index.js";

describe("design-token stylesheet", () => {
  it("keeps the generated stylesheet in sync with the palette", () => {
    const onDisk = readFileSync(fileURLToPath(new URL("./tokens.css", import.meta.url)), "utf8");
    expect(onDisk).toBe(renderTokensCss());
  });

  it("defines the same colour entries in both themes", () => {
    // A long-standing structural invariant of the palette, independent of this
    // feature: the two themes carry identical token sets (only their values
    // differ). This holds before and after the change for any correct palette.
    expect(new Set(Object.keys(darkTokens))).toEqual(new Set(Object.keys(lightTokens)));
  });
});
