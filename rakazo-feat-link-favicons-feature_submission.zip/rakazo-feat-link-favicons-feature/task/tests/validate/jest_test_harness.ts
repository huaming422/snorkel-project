// @ts-nocheck
//
// Shared validation harness. The driver copies this file next to every
// generated story test, so each test imports its primitives with
//   import { ... } from "./jest_test_harness";
//
// Everything here is framework plumbing or self-contained test fixtures:
// a loopback web server that stands in for every external site, byte
// fixtures for the image formats, hostname-resolution seams, and a tiny
// React mount helper. NOTHING here imports or names any symbol introduced
// by the change under test — the story procedures tell you which exported
// factory / context / endpoint to wire these primitives into, and you
// discover those names from the submitted patch.

import { createServer } from "node:http";

// ---------------------------------------------------------------------------
// Loopback origin server + an injectable fetch seam
// ---------------------------------------------------------------------------
//
// One local HTTP listener answers for every pretend site. The fetch seam
// rewrites each outgoing request to the listener and carries the pretend
// host in a header, so a safety check that resolves host names still sees
// the public-looking test hostnames while the bytes come from loopback.
//
//   const site = await startOriginServer();
//   site.set("example.test/", site.html('<link rel="icon" href="/i.png">'));
//   site.set("example.test/i.png", site.image(validPng()));
//   // ... construct the resolver with `site.fetch` as its fetch seam ...
//   site.hits        // ordered list of "<host><path>" the resolver asked for
//   await site.close();

export type Reply = {
  status?: number;
  headers?: Record<string, string>;
  body?: Uint8Array | string;
};
type Route = Reply | ((request: import("node:http").IncomingMessage) => Reply | Promise<Reply>);

export async function startOriginServer() {
  const routes = new Map<string, Route>();
  const hits: string[] = [];

  const server = createServer(async (request, response) => {
    const key = `${request.headers["x-test-host"]}${request.url}`;
    hits.push(key);
    const route = routes.get(key);
    const reply = typeof route === "function" ? await route(request) : route;
    response.writeHead(reply ? (reply.status ?? 200) : 404, reply?.headers ?? {});
    response.end(reply?.body ?? "");
  });
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const port = (server.address() as import("node:net").AddressInfo).port;

  // A fetch-shaped seam. Rewrites the request to the loopback listener and
  // forwards the intended host in a header; strips any undici dispatcher the
  // caller attached (loopback needs none).
  const fetchSeam: typeof fetch = async (input, init) => {
    const url = new URL(String(input));
    const headers = { ...Object.fromEntries(new Headers(init?.headers)), "x-test-host": url.host };
    const { dispatcher: _dispatcher, ...rest } = (init ?? {}) as RequestInit & {
      dispatcher?: unknown;
    };
    // Pass the caller's init through unchanged (it controls redirect handling —
    // the fetch layer under test follows redirects itself and asks for them
    // one at a time). Only the target and the host header are rewritten.
    return fetch(`http://127.0.0.1:${port}${url.pathname}${url.search}`, {
      ...(rest as object),
      headers,
    });
  };

  return {
    fetch: fetchSeam,
    hits,
    set(key: string, route: Route) {
      routes.set(key, route);
    },
    reset() {
      routes.clear();
      hits.length = 0;
    },
    html(head: string): Reply {
      return {
        headers: { "content-type": "text/html; charset=utf-8" },
        body: `<!doctype html><html><head>${head}</head><body>hi</body></html>`,
      };
    },
    image(body: Uint8Array, type = "image/png"): Reply {
      return { headers: { "content-type": type }, body };
    },
    async close() {
      await new Promise<void>((resolve) => server.close(() => resolve()));
    },
  };
}

// A route that blocks every connection until it is released — useful for
// holding fetch slots to observe concurrency limits. Register `route` for one
// or more keys, let the server accumulate as many held connections as the
// caller fires, then call `release()` to resolve ALL of them at once (and any
// that arrive after a release are resolved by the next release call). `held`
// reports how many connections are currently blocked. Works for a single held
// connection or many — each `route()` invocation queues its own resolver, so
// pointing several origins at the same `route` holds several slots in parallel.
export function blockingRoute(reply: Reply = { status: 404 }) {
  const pending: Array<() => void> = [];
  const route = () =>
    new Promise<Reply>((resolve) => {
      pending.push(() => resolve(reply));
    });
  return {
    route,
    get held() {
      return pending.length;
    },
    release() {
      const waiters = pending.splice(0, pending.length);
      for (const resolve of waiters) resolve();
    },
  };
}

// ---------------------------------------------------------------------------
// Hostname-resolution seams
// ---------------------------------------------------------------------------

// Every host looks like an ordinary public address.
export const publicResolveHostname = async () => [{ address: "203.0.113.10", family: 4 }];

// Map specific hosts to specific addresses (anything unlisted looks public).
// Pass IPv6 literals to exercise the v6 side of a safety check.
export function resolvingTo(addresses: Record<string, string>) {
  return async (hostname: string) => {
    const address = addresses[hostname] ?? "203.0.113.10";
    return [{ address, family: address.includes(":") ? 6 : 4 }];
  };
}

// ---------------------------------------------------------------------------
// Image byte fixtures (valid-format bytes built without the decoder)
// ---------------------------------------------------------------------------

// A real PNG of the given size, solid dark pixels. Built with the project's
// own image library (a pre-existing dependency) — the same way the codebase's
// tests build raster fixtures — so these are genuine PNG bytes, not a
// hand-rolled approximation.
// The image library lives only in the package whose stories build/decode raster
// fixtures. The render stories in other packages import this file for its
// React/HTTP helpers and never call the fixture builders below, but the bundler
// analyzes every import in the module graph at transform time — a *literal*
// `import("sharp")` is statically resolved and errors in a package that does not
// depend on it, before any test runs. Building the specifier at runtime keeps it
// opaque to static analysis, so it is resolved by the runtime only if a builder
// is actually called (in the one package that does depend on it).
const imageLibrary = ["sh", "arp"].join("");
async function loadImageLibrary() {
  return (await import(/* @vite-ignore */ imageLibrary)).default;
}

export async function png(width: number, height: number): Promise<Uint8Array> {
  const sharp = await loadImageLibrary();
  return sharp({
    create: { width, height, channels: 4, background: { r: 20, g: 20, b: 20, alpha: 1 } },
  })
    .png()
    .toBuffer();
}

export async function onePixelPng(): Promise<Uint8Array> {
  return png(1, 1);
}

// Rewrite a PNG's declared IHDR dimensions without re-encoding the pixels —
// so the bytes claim a size they do not hold (an oversize/over-pixel lie).
export function pngWithDeclaredSize(source: Uint8Array, width: number, height: number): Uint8Array {
  const copy = Uint8Array.from(source);
  const view = new DataView(copy.buffer);
  view.setUint32(16, width);
  view.setUint32(20, height);
  return copy;
}

// A single ICO bitmap entry (BMP, bottom-up) of the given bit depth, filled
// RED except the top-left pixel which the transparency mask hides. Mirrors the
// legacy icon-container entry layout the decoder must read.
const RED: [number, number, number] = [200, 30, 20];
export function bmpEntry(
  width: number,
  height: number,
  bitCount: 1 | 4 | 8 | 24 | 32 = 32,
  options: { alpha?: number; mask?: boolean } = {},
): Uint8Array {
  const paletteSize = bitCount <= 8 ? 2 ** bitCount : 0;
  const colorStride = Math.ceil((width * bitCount) / 32) * 4;
  const maskStride = Math.ceil(width / 32) * 4;
  const withMask = options.mask ?? true;
  const image = new Uint8Array(
    40 + paletteSize * 4 + colorStride * height + (withMask ? maskStride * height : 0),
  );
  const view = new DataView(image.buffer);
  view.setUint32(0, 40, true);
  view.setInt32(4, width, true);
  view.setInt32(8, height * 2, true);
  view.setUint16(12, 1, true);
  view.setUint16(14, bitCount, true);
  if (paletteSize) image.set([RED[2], RED[1], RED[0], 0], 40 + 4);
  const colorStart = 40 + paletteSize * 4;
  for (let row = 0; row < height; row += 1) {
    for (let x = 0; x < width; x += 1) {
      const at = colorStart + row * colorStride;
      if (bitCount >= 24) {
        const pixel = at + x * (bitCount / 8);
        image.set([RED[2], RED[1], RED[0]], pixel);
        if (bitCount === 32) image[pixel + 3] = options.alpha ?? 255;
      } else {
        const bit = x * bitCount;
        image[at + (bit >> 3)] |= 1 << (8 - bitCount - (bit & 7));
      }
    }
  }
  if (withMask) image[colorStart + colorStride * height + (height - 1) * maskStride] |= 0x80;
  return image;
}

// Pack bitmap entries into an ICO container.
export function ico(images: Uint8Array[]): Uint8Array {
  const header = new Uint8Array(6 + images.length * 16);
  const view = new DataView(header.buffer);
  view.setUint16(2, 1, true);
  view.setUint16(4, images.length, true);
  let offset = header.length;
  images.forEach((image, index) => {
    const entry = 6 + index * 16;
    view.setUint32(entry + 8, image.length, true);
    view.setUint32(entry + 12, offset, true);
    offset += image.length;
  });
  return concat(header, ...images);
}

// ---------------------------------------------------------------------------
// React mount helper (web component rendering under jsdom)
// ---------------------------------------------------------------------------
//
// The story test file must carry `// @vitest-environment jsdom` for this.
//
//   const view = await mountReact(<Provider value={ctx}><ChatMarkdown .../></Provider>);
//   view.container.querySelectorAll("a");
//   await view.rerender(<...next tree...>);
//   await view.cleanup();

export async function mountReact(node: unknown) {
  const { act } = await import("react");
  const { createRoot } = await import("react-dom/client");
  (globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
  const container = document.createElement("div");
  document.body.appendChild(container);
  const root = createRoot(container);
  await act(async () => {
    root.render(node as never);
  });
  return {
    container,
    async rerender(next: unknown) {
      await act(async () => {
        root.render(next as never);
      });
    },
    async act(fn: () => void | Promise<void>) {
      await act(async () => {
        await fn();
      });
    },
    async cleanup() {
      await act(async () => {
        root.unmount();
      });
      container.remove();
    },
  };
}

// A reference to the REAL timer, captured at module-load time — before any test
// body can install fake timers. `flush()` schedules on this real timer, so it
// still drains the event loop even when a story has called
// `vi.useFakeTimers({ toFake: ["setTimeout"] })`. (If `flush()` used the global
// `setTimeout`, a story that faked it would make `flush()` hang forever: the
// faked timer never fires unless the test advances it, and `flush()` is exactly
// the helper you reach for to settle promises without advancing component
// timers.) Capturing here keeps `flush()` safe to call in any timer mode.
const realSetTimeout: typeof setTimeout =
  typeof globalThis.setTimeout === "function" ? globalThis.setTimeout.bind(globalThis) : setTimeout;

// Let queued microtasks / promise callbacks drain. Safe under fake timers.
export async function flush(): Promise<void> {
  await new Promise((resolve) => realSetTimeout(resolve, 0));
}

// ---------------------------------------------------------------------------
// internals
// ---------------------------------------------------------------------------

function concat(...parts: Uint8Array[]): Uint8Array {
  const total = parts.reduce((sum, part) => sum + part.length, 0);
  const out = new Uint8Array(total);
  let at = 0;
  for (const part of parts) {
    out.set(part, at);
    at += part.length;
  }
  return out;
}
