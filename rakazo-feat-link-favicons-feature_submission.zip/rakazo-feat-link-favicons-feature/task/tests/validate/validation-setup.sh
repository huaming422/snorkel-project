#!/usr/bin/env bash
# validation-setup.sh — environment bootstrap for the validation story scripts.
# Idempotent. Sourced/exec'd before the jest(vitest) driver runs each story.
#
# The Dockerfile already ran `pnpm install --frozen-lockfile` at the pinned
# base commit with the pnpm store warm, so the full dependency closure (sharp's
# native binding, jsdom, react-dom, undici, vitest, @orpc/server) is present
# offline. The chat-ui / adapters / contracts / api packages export directly
# from their TypeScript src — there is NO dist build step — and vitest loads
# them through vite at the repo root, so nothing needs compiling here. The
# steps below are guards that only do work if an agent removed node_modules or
# the sharp binding; they are offline-first with a logged online fallback.

set -e

REPO_DIR="${REPO_DIR:-/repo/rakazo}"
cd "$REPO_DIR"

# Sanity: the toolchain is reachable.
node --version
pnpm --version
npx vitest --version

# The stories never touch a real network, DB, or service: the server story
# drives the oRPC router with a stubbed resolver dependency; the resolver
# stories inject a loopback `fetch` seam and a fake host resolver; the render
# stories mount React into jsdom with an in-memory icon-lookup function. Export
# the offline switches up front so a stray developer .env cannot pull a story
# onto the network (pin-test-env.ts also enforces this inside the suite).
export VERIFY_PROVIDERS=""
export LOG_LEVEL="off"
unset DATABASE_URL REALTIME_DATABASE_URL || true

# 1. Workspace deps. Offline-first against the warm store; fall back to an
#    online frozen install only if the offline path fails, and log loudly.
if [ ! -d "node_modules/.pnpm" ]; then
    echo "[validation-setup] node_modules missing — installing from warm store (offline, frozen)..."
    if ! pnpm install --frozen-lockfile --offline > /tmp/validation-setup-install.log 2>&1; then
        echo "[validation-setup] offline install failed; retrying with network (logged fallback)..." >&2
        tail -20 /tmp/validation-setup-install.log >&2 || true
        pnpm install --frozen-lockfile > /tmp/validation-setup-install-online.log 2>&1 \
            || { tail -40 /tmp/validation-setup-install-online.log >&2; return 1 2>/dev/null || exit 1; }
    fi
fi

# 2. sharp native binding. The resolver stories build PNG/ICO byte fixtures and
#    decode re-encoded icons through sharp; its platform binary must exist.
#    Rebuild only if an agent's reinstall erased it. Offline-first (the store
#    already holds the prebuilt binary for this platform), online fallback
#    logged.
if ! node -e "require('sharp')" > /tmp/validation-setup-sharp.log 2>&1; then
    echo "[validation-setup] sharp binding missing — rebuilding..." >&2
    tail -10 /tmp/validation-setup-sharp.log >&2 || true
    if ! pnpm --filter @rakazo/adapters rebuild sharp > /tmp/validation-setup-sharp-rebuild.log 2>&1; then
        tail -20 /tmp/validation-setup-sharp-rebuild.log >&2 || true
    fi
fi

# 3. No per-package build: chat-ui, adapters, contracts, and the api app all
#    export their TypeScript src directly and vitest resolves them through vite
#    at the repo root. A loud smoke guard that the workspace graph resolves —
#    if this import fails, deps are broken and every story would fail opaquely.
if ! node -e "require.resolve('vitest')" > /tmp/validation-setup-smoke.log 2>&1; then
    echo "[validation-setup] FATAL: vitest not resolvable — workspace deps broken" >&2
    tail -20 /tmp/validation-setup-smoke.log >&2 || true
    return 1 2>/dev/null || exit 1
fi

# Make node_modules/.bin available (vitest, tsc).
export PATH="$REPO_DIR/node_modules/.bin:$PATH"

echo "[validation-setup] ready: $REPO_DIR (node=$(node --version), pnpm=$(pnpm --version))"
