## Task

We want links in chat to show the favicon of the site they point at, right before the link text, the way a browser's address bar does. It should work everywhere chat renders (the web app, the desktop app, and mobile) and for links in both the assistant's replies and the messages people type.

One constraint shapes the whole feature: a user's device must never reveal which sites a conversation links to. The client must not fetch the linked site itself, and it must not call any third-party favicon or icon service. The only place it may get an icon is the Rakazo API, which does the outbound fetching and hands back a ready-to-display image. So the work spans a server operation for resolving icons, the shared chat-markdown renderer, and the link labels themselves.

Keep this scoped to external website (http/https) links. Everything else chat renders today (other links, inline images, tables, the streaming cursor) should look and behave the same. Match the repository's existing patterns and typing; type-checking, linting, and the test suite should pass.

## User stories / requirements

- A signed-in caller asks for a website origin and gets back either a displayable icon or a clear "no usable icon" answer; an unauthenticated request is refused before any icon work happens. The resolving work is handed only the origin that was asked for.
- When the server already has as much icon fetching in flight as it allows, a new request is told to try again shortly, not handed a wrong "no icon" and not left waiting indefinitely.
- The server decides an image's real type from its bytes, not a declared content type, and accepts the common raster icon formats. A one-pixel tracking image, an oversized image, a non-raster image such as a vector, or a malformed file all resolve to "no icon" rather than erroring. Accepted icons become one small, consistent raster.
- A site whose icon is the legacy multi-image icon-container format resolves to its best and largest image, and a malformed file of that kind resolves to "no icon" without throwing.
- Repeated asks for the same origin reuse a remembered answer, distinguishing a site that has an icon from one that does not, and that memory stays bounded, evicting the least-recently-used entries. Several simultaneous asks for one origin share a single underlying lookup.
- Outbound fetching goes through the codebase's existing protection against unsafe or internal destinations, sends no credentials to the remote site, and is bounded to a capped number of redirects and only the ordinary web ports. It reads the home page for a declared icon and falls back to the root-level icon.
- When a link's text is just the URL, its label shows the host then the path with an over-long path trimmed, while the host is never shortened or altered and stays in plain ASCII, and invisible formatting characters are stripped. An author's own link text is shown verbatim.
- The icon in front of a link is decorative, so assistive technology skips it and reads only the link text, and while an icon is loading or a site has none a neutral generic website placeholder shows in its place. A right-to-left label or host cannot visually rearrange the surrounding line.
- No icon is requested for a reply that is still streaming in; lookups happen only once content settles. Links that are not website navigations (email, phone, in-app or relative, image-wrapping, or unsafe links) keep their current look and get no icon.
- The client remembers answers for the session: a site with no icon keeps the placeholder without being re-asked for a while, and a "try again shortly" response is retried a few times while the link is on screen. Pointing the app at a different API must not reuse answers cached under the old one.
- Everyday chat-markdown that sits alongside web links keeps rendering the way it always has: an email link stays a plain link with no site icon, an inline image still appears as an image, and a table still renders as a table, whether the reply is still streaming or has settled.
