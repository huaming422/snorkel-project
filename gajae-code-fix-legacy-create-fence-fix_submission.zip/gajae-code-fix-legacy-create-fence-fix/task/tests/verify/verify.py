"""Behavioral verifier for the SDK broker's post-upgrade session-create admission.

The code under test is TypeScript exercised by the repository's own Bun test
runner, so this verifier is a thin pytest wrapper: it shells out to `bun test`
on a companion spec and maps each spec test to one pytest case. The verifier
itself imports nothing from the repository, so it runs under the shared
`VERIFIER_PYTHON` interpreter with default pytest discovery (no `[pytest]
command` override needed in verify.toml).

Each criterion is run as its own `bun test ... -t "<criterion>"` invocation so a
failure is attributed to exactly one behavior and the four behaviors stay
independent. A run counts as a pass only when bun exits cleanly AND reports at
least one passing test AND zero failing tests — guarding against the case where
a name filter silently matches nothing.

The companion spec drives behavior through the broker's public
`Broker.handleRequest` admission entry point (plus the public `LifecycleLedger`
surface to seed ledger rows); it never imports an implementation-internal
predicate, option name, or module helper. See `legacy_create_fence.spec.ts`.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
from pathlib import Path

import pytest

REPO_DIR = Path(os.environ.get("REPO_DIR", "/repo/gajae-code"))
PACKAGE_DIR = REPO_DIR / "packages" / "coding-agent"

# The spec ships next to this file and is copied into the package test tree at
# run time so its `../src/sdk/broker/...` relative imports resolve and the
# package-local bun preload (packages/coding-agent/bunfig.toml) is applied.
SPEC_SOURCE = Path(__file__).resolve().parent / "legacy_create_fence.spec.ts"
SPEC_DEST = PACKAGE_DIR / "test" / "_verify_legacy_create_fence.spec.ts"
# Path passed to `bun test`, relative to PACKAGE_DIR (the invocation cwd).
SPEC_REL = SPEC_DEST.relative_to(PACKAGE_DIR)

BUN_BIN = os.environ.get("BUN_BIN", "bun")

# Each bun invocation is a single focused test; the outer verify.toml timeout
# (1200s) bounds the whole file. Give each run a generous ceiling that still
# leaves room for all four plus a cold start.
PER_CRITERION_TIMEOUT_SEC = 180

# bun test writes its run summary (" N pass", " M fail") to stderr; match either
# stream defensively.
_PASS_RE = re.compile(r"(\d+)\s+pass\b")
_FAIL_RE = re.compile(r"(\d+)\s+fail\b")


@pytest.fixture(scope="session", autouse=True)
def _install_spec() -> object:
    """Copy the spec into the package test tree for the session, then remove it."""
    if not SPEC_SOURCE.exists():
        pytest.fail(f"verifier spec not found at {SPEC_SOURCE}")
    if not PACKAGE_DIR.is_dir():
        pytest.fail(
            f"coding-agent package not found at {PACKAGE_DIR}; expected the repo "
            f"checkout at {REPO_DIR} (set REPO_DIR to override)."
        )
    SPEC_DEST.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(SPEC_SOURCE, SPEC_DEST)
    try:
        yield
    finally:
        SPEC_DEST.unlink(missing_ok=True)


def _run_criterion(name: str) -> None:
    """Run the single spec test whose title is `name` and assert it passed."""
    try:
        proc = subprocess.run(
            [BUN_BIN, "test", str(SPEC_REL), "-t", name],
            capture_output=True,
            text=True,
            timeout=PER_CRITERION_TIMEOUT_SEC,
            cwd=str(PACKAGE_DIR),
            env=os.environ.copy(),
            check=False,
        )
    except FileNotFoundError:
        pytest.fail(
            f"`{BUN_BIN}` not found on PATH. The grade image bakes Bun under "
            f"/opt/bun/bin; ensure it is on PATH or set BUN_BIN."
        )
    except subprocess.TimeoutExpired:
        pytest.fail(f"`bun test -t {name}` timed out after {PER_CRITERION_TIMEOUT_SEC}s")

    combined = f"{proc.stdout}\n{proc.stderr}"
    pass_match = _PASS_RE.search(combined)
    fail_match = _FAIL_RE.search(combined)
    num_pass = int(pass_match.group(1)) if pass_match else 0
    num_fail = int(fail_match.group(1)) if fail_match else 0

    tail = (
        f"--- exit {proc.returncode} ---\n"
        f"--- stdout (tail) ---\n{proc.stdout[-3000:]}\n"
        f"--- stderr (tail) ---\n{proc.stderr[-3000:]}"
    )

    assert num_pass >= 1, (
        f"`bun test -t {name}` ran no passing test for {name!r} (pass={num_pass}, "
        f"fail={num_fail}). A zero-match name filter or a collection error looks "
        f"like this.\n{tail}"
    )
    assert num_fail == 0 and proc.returncode == 0, (
        f"`bun test -t {name}` reported {num_fail} failing test(s) "
        f"(pass={num_pass}, exit={proc.returncode}) for behavior {name!r}.\n{tail}"
    )


def test_fresh_create_past_terminal_legacy() -> None:
    """A fresh session.create is admitted past only-completed legacy rows."""
    _run_criterion("fresh_create_past_terminal_legacy")


def test_nonterminal_legacy_still_fences() -> None:
    """Live / recovered-uncertain legacy rows keep fencing a fresh create."""
    _run_criterion("nonterminal_legacy_still_fences")


def test_relaxation_is_create_only() -> None:
    """A non-create operation keeps the full legacy fence over completed rows."""
    _run_criterion("relaxation_is_create_only")


def test_exact_key_reuse_still_conflicts() -> None:
    """Reusing a terminal legacy create's key is still an exact-key conflict."""
    _run_criterion("exact_key_reuse_still_conflicts")
