// Behavioral spec for the in-process SDK broker's admission of a fresh
// session create after an upgrade that left pre-index ledger rows behind.
//
// Everything is driven through the broker's single public admission entry
// point, `Broker.handleRequest(operation, input, idempotencyKey)`, and the
// pre-existing public `LifecycleLedger` surface used to seed row state. No
// implementation-internal predicate, option name, or module helper is
// imported or asserted by name — only the observable admission outcome and
// whether a launch was attempted.
//
// How admitted vs. fenced is told apart: a lifecycle command resolver is
// injected that points at a non-existent binary and increments a counter each
// time the broker tries to launch. "Got past the admission fence" == the
// resolver ran (the attempt then fails with `spawn_failed`); "fenced" == the
// resolver never ran and an `idempotency_conflict` came back instead. This
// separates admission from launch without needing a real child process.
//
// Each test is self-contained (its own temp agent dir and broker) and uses
// its criterion key as the test title so the runner can select it by name.
//
// This file is copied into the package test tree at grade time so the
// relative imports below resolve; it is not part of the repository's own
// committed suite.

import { expect, it } from "bun:test";
import * as fs from "node:fs/promises";
import path from "node:path";

import { Broker } from "../src/sdk/broker/broker";
import { deriveLegacyIdentity } from "../src/sdk/broker/identity";
import { setLifecycleCommandResolverForTest } from "../src/sdk/broker/lifecycle";
import { LifecycleLedger } from "../src/sdk/broker/lifecycle-ledger";

const AMBIGUOUS_TARGET_CONFLICT = {
	ok: false,
	error: { code: "idempotency_conflict", message: "legacy lifecycle request has an ambiguous target" },
} as const;

const REUSED_KEY_CONFLICT = {
	ok: false,
	error: { code: "idempotency_conflict", message: "idempotency key was used with a different request" },
} as const;

async function makeAgentDir(prefix: string): Promise<{ root: string; agentDir: string }> {
	const root = await fs.mkdtemp(path.join(process.env.TMPDIR ?? "/tmp", prefix));
	return { root, agentDir: path.join(root, "agent") };
}

// Seed a completed (terminal) pre-index legacy row: a row written by an older
// build carries no operation/key index, so its operationKey is undefined.
async function seedTerminalLegacyRow(
	ledger: LifecycleLedger,
	identity: string,
	state: "terminal_ok" | "terminal_error",
): Promise<void> {
	await ledger.begin(identity, `legacy-request-${identity}`);
	await ledger.transition(identity, state, {
		response:
			state === "terminal_ok"
				? { ok: true, result: { sessionId: identity } }
				: { ok: false, error: { code: "fixture_error", message: "legacy operation completed" } },
	});
	expect(ledger.get(identity)?.operationKey).toBeUndefined();
}

interface BrokerHandle {
	broker: Broker;
	launchAttempts: () => number;
}

async function startBrokerWithCountingResolver(agentDir: string, missingBinaryDir: string): Promise<BrokerHandle> {
	const broker = new Broker({ agentDir });
	let launchAttempts = 0;
	setLifecycleCommandResolverForTest(broker, () => {
		launchAttempts += 1;
		return { file: path.join(missingBinaryDir, "missing-gjc"), args: [] };
	});
	await broker.start();
	return { broker, launchAttempts: () => launchAttempts };
}

it("fresh_create_past_terminal_legacy", async () => {
	const { root, agentDir } = await makeAgentDir("gjc-fence-fresh-");
	const ledger = await new LifecycleLedger(agentDir).open();
	await seedTerminalLegacyRow(ledger, "legacy-terminal-ok", "terminal_ok");
	await seedTerminalLegacyRow(ledger, "legacy-terminal-error", "terminal_error");

	const handle = await startBrokerWithCountingResolver(agentDir, root);
	try {
		// A brand-new create whose key matches no existing row must be admitted
		// past the completed legacy rows and reach launch (which then fails to
		// spawn the missing binary). Before the fix the completed legacy rows
		// fence it as an "ambiguous target" and the resolver never runs.
		await expect(
			handle.broker.handleRequest("session.create", { cwd: root }, "fresh-after-upgrade"),
		).resolves.toMatchObject({ ok: false, error: { code: "spawn_failed" } });
		expect(handle.launchAttempts()).toBe(1);
	} finally {
		setLifecycleCommandResolverForTest(handle.broker, undefined);
		await handle.broker.stop();
		await fs.rm(root, { recursive: true, force: true });
	}
});

it("nonterminal_legacy_still_fences", async () => {
	const { root, agentDir } = await makeAgentDir("gjc-fence-live-");
	const ledger = await new LifecycleLedger(agentDir).open();
	await seedTerminalLegacyRow(ledger, "legacy-terminal-ok", "terminal_ok");

	let handle = await startBrokerWithCountingResolver(agentDir, root);
	let broker = handle.broker;
	try {
		// The fix is present only if a fresh create gets past the completed
		// legacy row and launches.
		await expect(
			broker.handleRequest("session.create", { cwd: root }, "fresh-after-upgrade"),
		).resolves.toMatchObject({ ok: false, error: { code: "spawn_failed" } });
		expect(handle.launchAttempts()).toBe(1);

		// A legacy row that is NOT completed could still name an in-flight
		// session, so it must keep fencing every fresh create. Walk it through
		// its live states and assert the fence holds and nothing launches.
		const liveIdentity = "legacy-in-flight";
		await broker.ledger.begin(liveIdentity, "legacy-request-in-flight");

		// "Fenced" means the request was rejected without a new launch. Snapshot
		// the current attempt count and assert it is unchanged across the call so
		// the check stays valid after the broker restart below (a fresh broker
		// starts a fresh counter at zero).
		const assertFenced = async (key: string): Promise<void> => {
			const before = handle.launchAttempts();
			await expect(broker.handleRequest("session.create", { cwd: root }, key)).resolves.toEqual(
				AMBIGUOUS_TARGET_CONFLICT,
			);
			expect(handle.launchAttempts()).toBe(before);
		};

		await assertFenced("fresh-with-accepted-legacy");
		await broker.ledger.transition(liveIdentity, "effect_started");
		await assertFenced("fresh-with-effect-started-legacy");
		await broker.ledger.transition(liveIdentity, "awaiting_ready");
		await assertFenced("fresh-with-awaiting-ready-legacy");

		// Restarting the broker over an in-flight legacy row recovers it to
		// terminal_uncertain (still operationKey-less); an uncertain row is not
		// safe to step past, so the fence must still hold.
		setLifecycleCommandResolverForTest(broker, undefined);
		await broker.stop();
		handle = await startBrokerWithCountingResolver(agentDir, root);
		broker = handle.broker;
		expect(broker.ledger.get(liveIdentity)?.state).toBe("terminal_uncertain");
		expect(broker.ledger.get(liveIdentity)?.operationKey).toBeUndefined();
		await assertFenced("fresh-with-recovered-uncertain-legacy");
	} finally {
		setLifecycleCommandResolverForTest(broker, undefined);
		await broker.stop();
		await fs.rm(root, { recursive: true, force: true });
	}
});

it("relaxation_is_create_only", async () => {
	const { root, agentDir } = await makeAgentDir("gjc-fence-create-only-");
	const ledger = await new LifecycleLedger(agentDir).open();
	await seedTerminalLegacyRow(ledger, "legacy-terminal-ok", "terminal_ok");

	const handle = await startBrokerWithCountingResolver(agentDir, root);
	const broker = handle.broker;
	try {
		// A non-create operation must keep the full legacy fence even when the
		// only legacy row present is completed: stepping past terminal rows is a
		// create-only relaxation. A fresh-keyed delete against the completed
		// legacy row is rejected as an ambiguous target.
		await expect(
			broker.handleRequest(
				"session.delete",
				{ sessionId: "unrelated-session", sessionPath: path.join(root, "missing.json") },
				"fresh-delete-after-upgrade",
			),
		).resolves.toEqual(AMBIGUOUS_TARGET_CONFLICT);
		expect(handle.launchAttempts()).toBe(0);

		// Same completed-legacy world, but a fresh create is admitted and
		// launches — proving the relaxation applies to create specifically.
		await expect(
			broker.handleRequest("session.create", { cwd: root }, "fresh-create-after-upgrade"),
		).resolves.toMatchObject({ ok: false, error: { code: "spawn_failed" } });
		expect(handle.launchAttempts()).toBe(1);
	} finally {
		setLifecycleCommandResolverForTest(broker, undefined);
		await broker.stop();
		await fs.rm(root, { recursive: true, force: true });
	}
});

it("exact_key_reuse_still_conflicts", async () => {
	const { root, agentDir } = await makeAgentDir("gjc-fence-exact-key-");
	const ledger = await new LifecycleLedger(agentDir).open();

	// A completed legacy create whose identity is derived from a specific
	// caller key. A later create reusing that same key derives the same
	// identity and must still be caught by the exact-key conflict path — the
	// ambiguous-target relaxation must not open exact-key reuse.
	const reusedKey = "reused-terminal-create-key";
	const reusedIdentity = await deriveLegacyIdentity(agentDir, "session.create", reusedKey);
	await seedTerminalLegacyRow(ledger, reusedIdentity, "terminal_error");

	const handle = await startBrokerWithCountingResolver(agentDir, root);
	const broker = handle.broker;
	try {
		await expect(broker.handleRequest("session.create", { cwd: root }, reusedKey)).resolves.toEqual(
			REUSED_KEY_CONFLICT,
		);
		expect(handle.launchAttempts()).toBe(0);
	} finally {
		setLifecycleCommandResolverForTest(broker, undefined);
		await broker.stop();
		await fs.rm(root, { recursive: true, force: true });
	}
});
