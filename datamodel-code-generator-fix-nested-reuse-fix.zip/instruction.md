## Task

Generating models from an existing Python module works as expected when the generator reuses a type defined at module scope: the generated model refers to that same type. The problem appears when a reused field type is defined inside a class, whether it is an inner model, enum, or dataclass. The output declares another local type, so its runtime identity differs from the original and instances no longer round trip correctly.

Investigate and repair nested type reuse. Preserve working references to types exported at module scope, including nested types with such an export. This issue is limited to reuse; generating all types afresh should behave as before.
