//! Behavioral verifier for bun.lock output on workspace projects.
//!
//! Tests through the crate's PUBLIC API only, exactly like a downstream
//! consumer: build a `LockfileGraph` for a two-package monorepo, serialize
//! it with [`write_lockfile_as`] in bun format, then read it back with
//! [`parse_lockfile`]. No private helpers are referenced, so the checks hold
//! for any internal strategy that emits the workspace entries.
//!
//! Fixture: a root project with two workspace packages, `storefront` at
//! `packages/storefront` depending on `ui-kit` at `packages/ui-kit` via
//! `workspace:*`, plus a registry dependency `is-number` on `storefront`.
//! The project is described by two graphs: the one the bun reader produces
//! for a lockfile bun wrote, where both workspace packages are listed as
//! local links, and the one a fresh install resolves, where they are not
//! listed among the packages at all. The names/paths are distinct from any
//! used in the repo's own tests so a hard-coded ident string cannot satisfy
//! the checks.
//!
//! bun records a workspace-to-workspace dependency in the depending
//! package's `workspaces` block and lists every workspace package in
//! `packages` as `["<name>@workspace:<rel-path>"]`; the reader resolves the
//! dependency through that `packages` entry. The round-trip checks therefore
//! assert the dependency on the depending workspace as a reader sees it,
//! and accept either a bare `[ident]` entry or one that also carries meta.

use std::collections::BTreeMap;
use std::path::{Path, PathBuf};

use aube_lockfile::{
    DepType, DirectDep, LocalSource, LockedPackage, LockfileGraph, LockfileKind, parse_lockfile,
    write_lockfile_as,
};
use tempfile::TempDir;

const IS_NUMBER_INTEGRITY: &str = "sha512-41Cifkg6e8TylSpdtTpeLVMqvSBEVzTttHvERD741+pnZ8ANv0004MRL43QKPDlK9cGvNp6NZWZUBlbGXYxxng==";

/// Write the root + workspace `package.json` files into `dir` and return the
/// root manifest. The on-disk manifests are required because the bun writer
/// reads each non-root workspace's `package.json` from disk when building
/// the lockfile.
fn write_manifests(dir: &Path) -> aube_manifest::PackageJson {
    std::fs::write(
        dir.join("package.json"),
        r#"{"name":"storefront-monorepo","version":"1.0.0","workspaces":["packages/*"]}"#,
    )
    .unwrap();
    std::fs::create_dir_all(dir.join("packages/storefront")).unwrap();
    std::fs::create_dir_all(dir.join("packages/ui-kit")).unwrap();
    std::fs::write(
        dir.join("packages/storefront/package.json"),
        r#"{"name":"storefront","version":"0.1.0","dependencies":{"is-number":"^7.0.0","ui-kit":"workspace:*"}}"#,
    )
    .unwrap();
    std::fs::write(
        dir.join("packages/ui-kit/package.json"),
        r#"{"name":"ui-kit","version":"0.1.0"}"#,
    )
    .unwrap();
    aube_manifest::PackageJson::from_path(&dir.join("package.json")).unwrap()
}

fn is_number() -> LockedPackage {
    LockedPackage {
        name: "is-number".to_string(),
        version: "7.0.0".to_string(),
        dep_path: "is-number@7.0.0".to_string(),
        integrity: Some(IS_NUMBER_INTEGRITY.to_string()),
        ..Default::default()
    }
}

fn is_number_direct() -> DirectDep {
    DirectDep {
        name: "is-number".to_string(),
        dep_path: "is-number@7.0.0".to_string(),
        dep_type: DepType::Production,
        specifier: Some("^7.0.0".to_string()),
    }
}

/// The graph the bun reader builds from a bun.lock that bun wrote for this
/// project: both workspace packages are listed as local links.
fn fixture(dir: &Path) -> (LockfileGraph, aube_manifest::PackageJson) {
    let manifest = write_manifests(dir);

    let mut packages: BTreeMap<String, LockedPackage> = BTreeMap::new();
    packages.insert(
        "storefront@workspace:packages/storefront".to_string(),
        LockedPackage {
            name: "storefront".to_string(),
            version: "workspace:packages/storefront".to_string(),
            dep_path: "storefront@workspace:packages/storefront".to_string(),
            local_source: Some(LocalSource::Link(PathBuf::from("packages/storefront"))),
            dependencies: [
                ("is-number".to_string(), "is-number@7.0.0".to_string()),
                (
                    "ui-kit".to_string(),
                    "ui-kit@workspace:packages/ui-kit".to_string(),
                ),
            ]
            .into(),
            declared_dependencies: [
                ("is-number".to_string(), "^7.0.0".to_string()),
                ("ui-kit".to_string(), "workspace:*".to_string()),
            ]
            .into(),
            ..Default::default()
        },
    );
    packages.insert(
        "ui-kit@workspace:packages/ui-kit".to_string(),
        LockedPackage {
            name: "ui-kit".to_string(),
            version: "workspace:packages/ui-kit".to_string(),
            dep_path: "ui-kit@workspace:packages/ui-kit".to_string(),
            local_source: Some(LocalSource::Link(PathBuf::from("packages/ui-kit"))),
            ..Default::default()
        },
    );
    packages.insert("is-number@7.0.0".to_string(), is_number());

    let mut importers: BTreeMap<String, Vec<DirectDep>> = BTreeMap::new();
    importers.insert(".".to_string(), vec![]);
    importers.insert(
        "packages/storefront".to_string(),
        vec![
            is_number_direct(),
            DirectDep {
                name: "ui-kit".to_string(),
                dep_path: "ui-kit@workspace:packages/ui-kit".to_string(),
                dep_type: DepType::Production,
                specifier: Some("workspace:*".to_string()),
            },
        ],
    );
    importers.insert("packages/ui-kit".to_string(), vec![]);

    let graph = LockfileGraph {
        importers,
        packages,
        ..Default::default()
    };
    (graph, manifest)
}

/// The graph a fresh install resolves for the same project: the
/// `workspace:*` dependency is recorded on the `storefront` workspace, and
/// neither workspace package is listed among the graph's packages.
fn fresh_fixture(dir: &Path) -> (LockfileGraph, aube_manifest::PackageJson) {
    let manifest = write_manifests(dir);

    let mut packages: BTreeMap<String, LockedPackage> = BTreeMap::new();
    packages.insert("is-number@7.0.0".to_string(), is_number());

    let mut importers: BTreeMap<String, Vec<DirectDep>> = BTreeMap::new();
    importers.insert(".".to_string(), vec![]);
    importers.insert(
        "packages/storefront".to_string(),
        vec![
            is_number_direct(),
            DirectDep {
                name: "ui-kit".to_string(),
                dep_path: "ui-kit@0.1.0".to_string(),
                dep_type: DepType::Production,
                specifier: Some("workspace:*".to_string()),
            },
        ],
    );
    importers.insert("packages/ui-kit".to_string(), vec![]);

    let graph = LockfileGraph {
        importers,
        packages,
        ..Default::default()
    };
    (graph, manifest)
}

/// Write `graph` as bun.lock, read it back, and return the parsed graph
/// together with the raw text that was written.
fn round_trip_graph(
    dir: &Path,
    graph: &LockfileGraph,
    manifest: &aube_manifest::PackageJson,
) -> (LockfileGraph, String) {
    let lock_path = write_lockfile_as(dir, graph, manifest, LockfileKind::Bun).unwrap();
    let raw = std::fs::read_to_string(&lock_path).unwrap();
    let parsed = parse_lockfile(dir, manifest).unwrap();
    (parsed, raw)
}

fn round_trip(dir: &Path) -> (LockfileGraph, String) {
    let (graph, manifest) = fixture(dir);
    round_trip_graph(dir, &graph, &manifest)
}

/// Locate a parsed package by its declared name, independent of the map key
/// the parser chose for it.
fn find_pkg<'a>(graph: &'a LockfileGraph, name: &str, raw: &str) -> &'a LockedPackage {
    graph
        .packages
        .values()
        .find(|p| p.name == name)
        .unwrap_or_else(|| {
            panic!(
                "package `{name}` missing from parsed lockfile graph; \
                 present packages: {:?}\nwritten bun.lock:\n{raw}",
                graph.packages.values().map(|p| &p.name).collect::<Vec<_>>()
            )
        })
}

/// Look up `dep` among the direct dependencies the parsed graph records for
/// the workspace at `importer`.
fn importer_dep<'a>(
    graph: &'a LockfileGraph,
    importer: &str,
    dep: &str,
    raw: &str,
) -> Option<&'a DirectDep> {
    graph
        .importers
        .get(importer)
        .unwrap_or_else(|| {
            panic!(
                "workspace `{importer}` missing from parsed lockfile; importers: {:?}\n\
                 written bun.lock:\n{raw}",
                graph.importers.keys().collect::<Vec<_>>()
            )
        })
        .iter()
        .find(|d| d.name == dep)
}

/// The written bun.lock must list each workspace package by its
/// `name@workspace:<rel-path>` ident, as bun does.
#[test]
fn emits_workspace_packages_into_lockfile() {
    let project = TempDir::new().unwrap();
    let dir = project.path();
    let (graph, manifest) = fixture(dir);

    let lock_path = write_lockfile_as(dir, &graph, &manifest, LockfileKind::Bun).unwrap();
    let raw = std::fs::read_to_string(&lock_path).unwrap();

    assert!(
        raw.contains("storefront@workspace:packages/storefront"),
        "written bun.lock omits the `storefront` workspace package:\n{raw}"
    );
    assert!(
        raw.contains("ui-kit@workspace:packages/ui-kit"),
        "written bun.lock omits the `ui-kit` workspace package:\n{raw}"
    );
}

/// After a write then read, both workspace packages come back as local links
/// and `storefront` still depends on the `ui-kit` workspace package.
#[test]
fn preserves_workspace_to_workspace_edge_on_round_trip() {
    let project = TempDir::new().unwrap();
    let (parsed, raw) = round_trip(project.path());

    let storefront = find_pkg(&parsed, "storefront", &raw);
    let ui_kit = find_pkg(&parsed, "ui-kit", &raw);

    assert!(
        matches!(storefront.local_source, Some(LocalSource::Link(_))),
        "`storefront` should round-trip as a workspace link, got {:?}\n{raw}",
        storefront.local_source
    );
    assert!(
        matches!(ui_kit.local_source, Some(LocalSource::Link(_))),
        "`ui-kit` should round-trip as a workspace link, got {:?}\n{raw}",
        ui_kit.local_source
    );

    let edge = importer_dep(&parsed, "packages/storefront", "ui-kit", &raw).unwrap_or_else(|| {
        panic!(
            "the storefront -> ui-kit workspace dependency was lost on the write/read \
             round trip; storefront's dependencies: {:?}\nwritten bun.lock:\n{raw}",
            parsed.importers.get("packages/storefront")
        )
    });
    assert_eq!(
        edge.dep_path, ui_kit.dep_path,
        "storefront's `ui-kit` dependency resolves to {:?}, not the ui-kit workspace \
         package ({:?})\n{raw}",
        edge.dep_path, ui_kit.dep_path
    );
    assert_eq!(edge.dep_type, DepType::Production);
}

/// The registry dependency that sits next to the workspace entries keeps its
/// version and integrity, and `storefront` still resolves to it after a
/// write then read.
#[test]
fn registry_dependency_of_a_workspace_survives_round_trip() {
    let project = TempDir::new().unwrap();
    let (parsed, raw) = round_trip(project.path());

    let is_number = find_pkg(&parsed, "is-number", &raw);
    assert_eq!(is_number.version, "7.0.0", "{raw}");
    assert!(
        is_number.local_source.is_none(),
        "`is-number` should stay a registry package, got {:?}\n{raw}",
        is_number.local_source
    );
    assert_eq!(
        is_number.integrity.as_deref(),
        Some(IS_NUMBER_INTEGRITY),
        "`is-number` integrity changed on the round trip\n{raw}"
    );

    let edge = importer_dep(&parsed, "packages/storefront", "is-number", &raw).unwrap_or_else(
        || {
            panic!(
                "storefront's `is-number` dependency was lost on the round trip\n{raw}"
            )
        },
    );
    assert_eq!(edge.dep_path, is_number.dep_path, "{raw}");
}

/// A freshly resolved graph does not list workspace packages among its
/// packages. The written bun.lock still has to list both of them, and the
/// storefront -> ui-kit dependency has to survive a write then read.
#[test]
fn fresh_install_graph_lists_workspace_packages() {
    let project = TempDir::new().unwrap();
    let dir = project.path();
    let (graph, manifest) = fresh_fixture(dir);
    let (parsed, raw) = round_trip_graph(dir, &graph, &manifest);

    assert!(
        raw.contains("\"storefront@workspace:"),
        "written bun.lock omits the `storefront` workspace package:\n{raw}"
    );
    assert!(
        raw.contains("\"ui-kit@workspace:"),
        "written bun.lock omits the `ui-kit` workspace package:\n{raw}"
    );

    let storefront = find_pkg(&parsed, "storefront", &raw);
    let ui_kit = find_pkg(&parsed, "ui-kit", &raw);
    assert!(
        matches!(storefront.local_source, Some(LocalSource::Link(_))),
        "`storefront` should read back as a workspace link, got {:?}\n{raw}",
        storefront.local_source
    );
    assert!(
        matches!(ui_kit.local_source, Some(LocalSource::Link(_))),
        "`ui-kit` should read back as a workspace link, got {:?}\n{raw}",
        ui_kit.local_source
    );

    let edge = importer_dep(&parsed, "packages/storefront", "ui-kit", &raw).unwrap_or_else(|| {
        panic!(
            "the storefront -> ui-kit workspace dependency was lost on the write/read \
             round trip; storefront's dependencies: {:?}\nwritten bun.lock:\n{raw}",
            parsed.importers.get("packages/storefront")
        )
    });
    assert_eq!(edge.dep_path, ui_kit.dep_path, "{raw}");

    let is_number = find_pkg(&parsed, "is-number", &raw);
    assert_eq!(
        is_number.integrity.as_deref(),
        Some(IS_NUMBER_INTEGRITY),
        "{raw}"
    );
}
