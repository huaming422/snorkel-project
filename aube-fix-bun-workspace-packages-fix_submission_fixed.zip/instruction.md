## Task

The `bun.lock` aube writes for a project with workspaces is missing the project's own workspace packages. It loses data as well: if one workspace package depends on another through `workspace:*`, that dependency is gone once aube reads the lockfile back. aube's `bun.lock` is meant to match what bun writes for the same project. Can you find out why and fix it?
