#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
#
# This task's discriminating behavior — a canceled query over an SSH tunnel must
# actually STOP on the database server — is only observable against a real
# PostgreSQL. The server is baked into the image (image/Dockerfile block 5); this
# script starts it offline and makes it reachable at 127.0.0.1:5432 with a known
# superuser, which is the stable coordinate the verifier dials as the tunnel's
# forward target. No assertion logic lives here.
#
# Stable connection facts the verifier relies on:
#   host=127.0.0.1  port=5432  user=postgres  password=root-password
#
# Must run under `docker run --network none`: a local cluster start and loopback
# connections need no network, and the Go offline switches below keep a cache
# miss from reaching for a proxy.

cd /repo/bytebase

# Go: fail fast on a cache miss instead of hitting a dead network. The image
# baked the full module + build closure at the base commit.
export GOFLAGS=-mod=mod
export GOPROXY=off

# --- Start the baked PostgreSQL cluster (offline) -----------------------------
# Ubuntu's postgresql package initializes one cluster (e.g. 14/main). Discover it
# rather than hardcoding the major version.
PG_LINE="$(pg_lsclusters -h | head -n1)"
PG_VER="$(echo "${PG_LINE}" | awk '{print $1}')"
PG_CLUSTER="$(echo "${PG_LINE}" | awk '{print $2}')"
if [ -z "${PG_VER}" ] || [ -z "${PG_CLUSTER}" ]; then
    echo "[test-setup] no PostgreSQL cluster found (expected one baked into the image)" >&2
    exit 1
fi
echo "[test-setup] using PostgreSQL cluster ${PG_VER}/${PG_CLUSTER}"

PGBIN="/usr/lib/postgresql/${PG_VER}/bin"
PGDATA="/etc/postgresql/${PG_VER}/${PG_CLUSTER}"

# Listen on loopback, standard port; allow password auth over TCP from localhost
# so a connection dialed at 127.0.0.1:5432 (what the tunnel forwards to) can log
# in with a password. The local unix socket keeps peer auth, which lets the
# postgres OS user set the password below without one.
HBA="${PGDATA}/pg_hba.conf"
if ! grep -q '127.0.0.1/32 .*scram-sha-256\|127.0.0.1/32 .*md5' "${HBA}" 2>/dev/null; then
    {
        echo "host all all 127.0.0.1/32 scram-sha-256"
        echo "host all all ::1/128 scram-sha-256"
    } >> "${HBA}"
fi

# Start (idempotent: skip if already online from a prior source of this script).
if ! pg_lsclusters -h | awk '{print $4}' | grep -q '^online$'; then
    pg_ctlcluster "${PG_VER}" "${PG_CLUSTER}" start > /tmp/pg-start.log 2>&1 || {
        echo "[test-setup] failed to start PostgreSQL:" >&2; cat /tmp/pg-start.log >&2; exit 1
    }
fi

# Wait until it accepts connections on 127.0.0.1:5432.
for i in $(seq 1 60); do
    if "${PGBIN}/pg_isready" -h 127.0.0.1 -p 5432 > /dev/null 2>&1; then
        break
    fi
    sleep 0.5
    if [ "${i}" -eq 60 ]; then
        echo "[test-setup] PostgreSQL did not become ready on 127.0.0.1:5432" >&2
        cat /tmp/pg-start.log >&2 2>/dev/null || true
        exit 1
    fi
done

# Ensure the postgres superuser has the password the verifier expects. Run as the
# postgres OS user over the local socket (peer auth), so no password is needed here.
su -s /bin/bash postgres -c "psql -v ON_ERROR_STOP=1 -c \"ALTER USER postgres WITH PASSWORD 'root-password';\"" \
    > /tmp/pg-passwd.log 2>&1 || {
    echo "[test-setup] failed to set postgres password:" >&2; cat /tmp/pg-passwd.log >&2; exit 1
}

echo "[test-setup] PostgreSQL ready at 127.0.0.1:5432 (user=postgres)"
