## Task

ran into something annoying with one of our instances that sits behind an SSH tunnel. if I fire off a query and then cancel it (drop the request, hit Cancel in SQL Editor, doesn't matter) the query just keeps chugging on the database. the request that kicked it off hangs there blocked until the thing finishes on its own. same deal when a query runs past the workspace maximum query time: it's supposed to get stopped, but it just keeps going.

instances we connect to directly cancel fine, it's only the ones reached over an SSH tunnel that behave like this.

can you dig into why cancel and timeout don't actually stop the query for tunneled instances and fix it?
