//go:build cgo

// Behavioral checks that a "preview" invocation of the bd CLI
// (`create --dry-run`, `migrate --inspect`) leaves the on-disk store
// byte-for-byte unchanged while still producing its normal output.
//
// Everything here drives the real `bd` binary as a subprocess (the stable,
// user-facing interface) and reads state back afterward through the
// pre-existing embeddeddolt.OpenSQL surface plus the cached version file.
// No command-setup internals are referenced by name, so any end-to-end fix
// that makes a preview non-mutating is accepted regardless of structure.
//
// The misbehavior only surfaces when the store has pending maintenance work
// to do on open: a recorded schema cursor that sits behind the binary, or a
// cached version marker that makes the tool believe it was last used by an
// older build. These helpers manufacture that pending state and then compare
// a before/after snapshot across the preview run.

package main

import (
	"encoding/json"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"

	"github.com/steveyegge/beads/internal/storage/embeddeddolt"
	"github.com/steveyegge/beads/internal/storage/schema"
)

// previewStoreSnapshot is the "did anything write to this database?" tripwire
// compared across a command run: the applied schema cursor, the version-control
// HEAD, and the issue row count. A preview must not move any of them.
type previewStoreSnapshot struct {
	schemaVersion int
	head          string
	issueCount    int
}

func readPreviewStoreSnapshot(t *testing.T, beadsDir, database string) previewStoreSnapshot {
	t.Helper()
	db, cleanup, err := embeddeddolt.OpenSQL(
		t.Context(),
		filepath.Join(beadsDir, "embeddeddolt"),
		database,
		"main",
	)
	if err != nil {
		t.Fatalf("OpenSQL(%s): %v", database, err)
	}
	defer func() {
		if err := cleanup(); err != nil {
			t.Errorf("cleanup OpenSQL(%s): %v", database, err)
		}
	}()

	var got previewStoreSnapshot
	if err := db.QueryRowContext(t.Context(),
		"SELECT COALESCE(MAX(version), 0) FROM schema_migrations").Scan(&got.schemaVersion); err != nil {
		t.Fatalf("read schema cursor (%s): %v", database, err)
	}
	if err := db.QueryRowContext(t.Context(), "SELECT HASHOF('HEAD')").Scan(&got.head); err != nil {
		t.Fatalf("read HEAD (%s): %v", database, err)
	}
	if err := db.QueryRowContext(t.Context(), "SELECT COUNT(*) FROM issues").Scan(&got.issueCount); err != nil {
		t.Fatalf("read issue count (%s): %v", database, err)
	}
	return got
}

// regressPreviewSchemaCursor rolls the recorded migration cursor back one
// version WITHOUT touching the physical schema. The most recent migration is
// idempotent, so a writable open reapplies it, restores the cursor, and
// commits a new HEAD — which is exactly what makes the cursor a usable
// tripwire. Keeping the physical schema intact lets a non-mutating open still
// read and validate against the older recorded version.
func regressPreviewSchemaCursor(t *testing.T, beadsDir, database string) {
	t.Helper()
	db, cleanup, err := embeddeddolt.OpenSQL(
		t.Context(),
		filepath.Join(beadsDir, "embeddeddolt"),
		database,
		"main",
	)
	if err != nil {
		t.Fatalf("OpenSQL for regression fixture (%s): %v", database, err)
	}
	if _, err := db.ExecContext(t.Context(),
		"DELETE FROM schema_migrations WHERE version = ?", schema.LatestVersion()); err != nil {
		_ = cleanup()
		t.Fatalf("regress schema cursor (%s): %v", database, err)
	}
	if _, err := db.ExecContext(t.Context(),
		"CALL DOLT_COMMIT('-am', 'test: regress schema cursor before preview')"); err != nil {
		_ = cleanup()
		t.Fatalf("commit regressed schema cursor (%s): %v", database, err)
	}
	if err := cleanup(); err != nil {
		t.Fatalf("cleanup regression fixture (%s): %v", database, err)
	}
}

// seedOldVersionMarker makes the tool believe it was last used by an older
// build, which triggers the version-bump maintenance path on the next open.
func seedOldVersionMarker(t *testing.T, beadsDir string) {
	t.Helper()
	if err := os.WriteFile(filepath.Join(beadsDir, localVersionFile), []byte("0.9.0\n"), 0o600); err != nil {
		t.Fatalf("write old version marker: %v", err)
	}
}

func readVersionMarker(t *testing.T, beadsDir string) (string, bool) {
	t.Helper()
	raw, err := os.ReadFile(filepath.Join(beadsDir, localVersionFile))
	if err != nil {
		if os.IsNotExist(err) {
			return "", false
		}
		t.Fatalf("read version marker: %v", err)
	}
	return strings.TrimSpace(string(raw)), true
}

func assertSnapshotUnchanged(t *testing.T, what string, before, after previewStoreSnapshot) {
	t.Helper()
	if after.schemaVersion != before.schemaVersion {
		t.Errorf("%s: schema cursor changed during preview: before=%d after=%d", what, before.schemaVersion, after.schemaVersion)
	}
	if after.head != before.head {
		t.Errorf("%s: version-control HEAD changed during preview: before=%s after=%s", what, before.head, after.head)
	}
	if after.issueCount != before.issueCount {
		t.Errorf("%s: issue count changed during preview: before=%d after=%d", what, before.issueCount, after.issueCount)
	}
}

// TestPreviewCreateDryRunImmutable: `create --dry-run` against a workspace with
// pending maintenance work (a behind schema cursor and an old version marker)
// must leave the schema cursor, HEAD, issue count, and the cached version
// marker all unchanged, and still emit its dry-run JSON.
func TestPreviewCreateDryRunImmutable(t *testing.T) {
	bd := buildEmbeddedBD(t)
	dir, beadsDir, _ := bdInit(t, bd, "--prefix", "dnm")
	bdCreate(t, bd, dir, "Existing issue")

	regressPreviewSchemaCursor(t, beadsDir, "dnm")
	seedOldVersionMarker(t, beadsDir)

	latest := schema.LatestVersion()
	before := readPreviewStoreSnapshot(t, beadsDir, "dnm")
	if before.schemaVersion >= latest {
		t.Fatalf("fixture did not leave the schema cursor behind: cursor=%d latest=%d", before.schemaVersion, latest)
	}
	beforeMarker, _ := readVersionMarker(t, beadsDir)

	cmd := exec.Command(bd, "create", "--dry-run", "Preview only", "--json")
	cmd.Dir = dir
	cmd.Env = bdEnv(dir)
	stdout, stderr, err := runCommandBuffers(t, cmd)
	if err != nil {
		t.Fatalf("bd create --dry-run failed: %v\nstdout:\n%s\nstderr:\n%s", err, stdout.String(), stderr.String())
	}

	// Preview must still do its job: emit a parseable dry-run payload.
	s := stdout.String()
	start := strings.Index(s, "{")
	if start < 0 {
		t.Fatalf("dry-run emitted no JSON object:\nstdout:\n%s", s)
	}
	var payload map[string]any
	if err := json.Unmarshal([]byte(s[start:]), &payload); err != nil {
		t.Fatalf("dry-run JSON did not parse: %v\nstdout:\n%s", err, s)
	}

	after := readPreviewStoreSnapshot(t, beadsDir, "dnm")
	assertSnapshotUnchanged(t, "create --dry-run", before, after)

	afterMarker, present := readVersionMarker(t, beadsDir)
	if !present {
		t.Errorf("create --dry-run removed the cached version marker")
	} else if afterMarker != beforeMarker {
		t.Errorf("create --dry-run rewrote the cached version marker: before=%q after=%q", beforeMarker, afterMarker)
	}
}

// TestPreviewMigrateInspectImmutable: `migrate --inspect` against the same kind
// of pending-work workspace must leave the store unchanged and still print its
// inspection report.
func TestPreviewMigrateInspectImmutable(t *testing.T) {
	bd := buildEmbeddedBD(t)
	dir, beadsDir, _ := bdInit(t, bd, "--prefix", "mig")
	bdCreate(t, bd, dir, "Existing issue")

	regressPreviewSchemaCursor(t, beadsDir, "mig")
	seedOldVersionMarker(t, beadsDir)

	latest := schema.LatestVersion()
	before := readPreviewStoreSnapshot(t, beadsDir, "mig")
	if before.schemaVersion >= latest {
		t.Fatalf("fixture did not leave the schema cursor behind: cursor=%d latest=%d", before.schemaVersion, latest)
	}
	beforeMarker, _ := readVersionMarker(t, beadsDir)

	cmd := exec.Command(bd, "migrate", "--inspect")
	cmd.Dir = dir
	cmd.Env = bdEnv(dir)
	stdout, stderr, err := runCommandBuffers(t, cmd)
	if err != nil {
		t.Fatalf("bd migrate --inspect failed: %v\nstdout:\n%s\nstderr:\n%s", err, stdout.String(), stderr.String())
	}
	if len(strings.TrimSpace(stdout.String())) == 0 {
		t.Fatalf("migrate --inspect produced no report output")
	}

	after := readPreviewStoreSnapshot(t, beadsDir, "mig")
	assertSnapshotUnchanged(t, "migrate --inspect", before, after)

	afterMarker, present := readVersionMarker(t, beadsDir)
	if !present {
		t.Errorf("migrate --inspect removed the cached version marker")
	} else if afterMarker != beforeMarker {
		t.Errorf("migrate --inspect rewrote the cached version marker: before=%q after=%q", beforeMarker, afterMarker)
	}
}

// TestPreviewExplicitTargetBeatsInheritedDir: when an explicit target directory
// is given on the command line, it must win over a directory inherited from the
// environment — including during a preview — and the targeted directory must
// not be mutated by the preview.
//
// Targeting is observed through a parent lookup: the parent issue exists only
// in the explicitly-named directory. If the explicit target is consulted the
// lookup resolves and the dry-run succeeds; if the inherited directory were
// consulted instead the parent would be missing and the command would fail.
func TestPreviewExplicitTargetBeatsInheritedDir(t *testing.T) {
	bd := buildEmbeddedBD(t)
	targetDir, targetBeadsDir, _ := bdInit(t, bd, "--prefix", "xtgt")
	parent := bdCreate(t, bd, targetDir, "Parent in the explicit target")
	if parent.ID == "" {
		t.Fatal("parent issue has no ID")
	}

	callerDir, callerBeadsDir, _ := bdInit(t, bd, "--prefix", "xsrc")

	// Pending work goes in the explicitly-named target: only a mutating open of
	// that directory would restore its cursor and advance its HEAD.
	regressPreviewSchemaCursor(t, targetBeadsDir, "xtgt")
	seedOldVersionMarker(t, targetBeadsDir)

	latest := schema.LatestVersion()
	targetBefore := readPreviewStoreSnapshot(t, targetBeadsDir, "xtgt")
	if targetBefore.schemaVersion >= latest {
		t.Fatalf("fixture did not leave the target schema cursor behind: cursor=%d latest=%d", targetBefore.schemaVersion, latest)
	}
	callerBefore := readPreviewStoreSnapshot(t, callerBeadsDir, "xsrc")

	cmd := exec.Command(bd, "-C", targetDir, "create", "--dry-run",
		"--parent", parent.ID, "Preview child", "--json")
	cmd.Dir = callerDir
	cmd.Env = append(bdEnv(callerDir), "BEADS_DIR="+callerBeadsDir)
	stdout, stderr, err := runCommandBuffers(t, cmd)
	if err != nil {
		t.Fatalf("bd -C <target> create --dry-run --parent failed (explicit target not consulted?): %v\nstdout:\n%s\nstderr:\n%s",
			err, stdout.String(), stderr.String())
	}

	targetAfter := readPreviewStoreSnapshot(t, targetBeadsDir, "xtgt")
	assertSnapshotUnchanged(t, "explicit-target preview (target)", targetBefore, targetAfter)

	callerAfter := readPreviewStoreSnapshot(t, callerBeadsDir, "xsrc")
	assertSnapshotUnchanged(t, "explicit-target preview (inherited dir)", callerBefore, callerAfter)
}

// TestPreviewCrossRepoTargetImmutable covers the second store a preview can
// reach: `create --dry-run --parent <id> --repo <other>` resolves the parent
// against a DIFFERENT repo named only as a lookup target. That foreign repo
// must not be mutated by the preview either — a fix that only makes the
// command's own store non-mutating still leaves this path writing to a
// repository the user merely pointed at. The tripwire (pending schema work)
// goes in the target repo; a pending version bump is also arranged in the
// caller repo so both the caller's pre-command open and the cross-repo lookup
// exercise their maintenance paths.
func TestPreviewCrossRepoTargetImmutable(t *testing.T) {
	bd := buildEmbeddedBD(t)
	targetDir, targetBeadsDir, _ := bdInit(t, bd, "--prefix", "crt")
	parent := bdCreate(t, bd, targetDir, "Parent in the cross-repo target")
	if parent.ID == "" {
		t.Fatal("parent issue has no ID")
	}

	callerDir, callerBeadsDir, _ := bdInit(t, bd, "--prefix", "crs")
	bdCreate(t, bd, callerDir, "Caller issue")

	// Tripwire in the target: only a mutating open of that repo restores its
	// cursor and advances its HEAD.
	regressPreviewSchemaCursor(t, targetBeadsDir, "crt")
	// Force the version-bump path in the caller repo too.
	seedOldVersionMarker(t, callerBeadsDir)

	latest := schema.LatestVersion()
	targetBefore := readPreviewStoreSnapshot(t, targetBeadsDir, "crt")
	if targetBefore.schemaVersion >= latest {
		t.Fatalf("fixture did not leave the target schema cursor behind: cursor=%d latest=%d", targetBefore.schemaVersion, latest)
	}
	callerBefore := readPreviewStoreSnapshot(t, callerBeadsDir, "crs")

	cmd := exec.Command(bd, "create", "--dry-run",
		"--parent", parent.ID, "--repo", targetDir, "Preview child", "--json")
	cmd.Dir = callerDir
	cmd.Env = bdEnv(callerDir)
	stdout, stderr, err := runCommandBuffers(t, cmd)
	if err != nil {
		t.Fatalf("bd create --dry-run --parent --repo failed: %v\nstdout:\n%s\nstderr:\n%s", err, stdout.String(), stderr.String())
	}

	targetAfter := readPreviewStoreSnapshot(t, targetBeadsDir, "crt")
	assertSnapshotUnchanged(t, "cross-repo preview (target)", targetBefore, targetAfter)

	callerAfter := readPreviewStoreSnapshot(t, callerBeadsDir, "crs")
	assertSnapshotUnchanged(t, "cross-repo preview (caller)", callerBefore, callerAfter)
}

// TestPreviewStillFunctional guards against an over-aggressive fix that turns a
// preview into a no-op or an error: on an ordinary workspace both previews must
// exit cleanly and produce their normal output.
func TestPreviewStillFunctional(t *testing.T) {
	bd := buildEmbeddedBD(t)
	dir, _, _ := bdInit(t, bd, "--prefix", "fun")
	bdCreate(t, bd, dir, "Existing issue")

	create := exec.Command(bd, "create", "--dry-run", "Preview only", "--json")
	create.Dir = dir
	create.Env = bdEnv(dir)
	cStdout, cStderr, err := runCommandBuffers(t, create)
	if err != nil {
		t.Fatalf("bd create --dry-run failed on a clean workspace: %v\nstdout:\n%s\nstderr:\n%s", err, cStdout.String(), cStderr.String())
	}
	s := cStdout.String()
	start := strings.Index(s, "{")
	if start < 0 {
		t.Fatalf("create --dry-run emitted no JSON object:\nstdout:\n%s", s)
	}
	var payload map[string]any
	if err := json.Unmarshal([]byte(s[start:]), &payload); err != nil {
		t.Fatalf("create --dry-run JSON did not parse: %v\nstdout:\n%s", err, s)
	}

	inspect := exec.Command(bd, "migrate", "--inspect")
	inspect.Dir = dir
	inspect.Env = bdEnv(dir)
	iStdout, iStderr, err := runCommandBuffers(t, inspect)
	if err != nil {
		t.Fatalf("bd migrate --inspect failed on a clean workspace: %v\nstdout:\n%s\nstderr:\n%s", err, iStdout.String(), iStderr.String())
	}
	if len(strings.TrimSpace(iStdout.String())) == 0 {
		t.Fatalf("migrate --inspect produced no report output on a clean workspace")
	}
}

// TestNonPreviewCreateMutates is the negative control: a real (non-preview)
// create on the same kind of workspace DOES change the store, proving the
// snapshot machinery actually detects mutations and the immutability
// assertions above are not vacuous.
func TestNonPreviewCreateMutates(t *testing.T) {
	bd := buildEmbeddedBD(t)
	dir, beadsDir, _ := bdInit(t, bd, "--prefix", "ctl")
	bdCreate(t, bd, dir, "First issue")

	before := readPreviewStoreSnapshot(t, beadsDir, "ctl")

	bdCreate(t, bd, dir, "Second issue")

	after := readPreviewStoreSnapshot(t, beadsDir, "ctl")
	if after.issueCount <= before.issueCount && after.head == before.head {
		t.Fatalf("a real create did not change the store: before=%+v after=%+v", before, after)
	}
}
