# Sourced by the verifier runner before tests execute; exports the deterministic
# Go build environment (toolchain + module cache come from the image).
#
# beads links the embedded Dolt storage engine through cgo (CGO_ENABLED=1) and
# builds go-mysql-server with the `gms_pure_go` tag so its regex support uses the
# Go stdlib instead of the ICU C library. Every `go build`/`go test` in this repo
# must carry that tag or compilation fails on a missing `unicode/uregex.h`.

set -euo pipefail

cd /repo/beads

export CGO_ENABLED="1"
export GOTOOLCHAIN="local"
# `-mod=mod` allows on-the-fly resolution of any test dependency not in the
# pre-downloaded module set; `-tags=gms_pure_go` is mandatory (see above).
export GOFLAGS="-mod=mod -tags=gms_pure_go"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
mkdir -p "$GOCACHE" "$GOMODCACHE"
