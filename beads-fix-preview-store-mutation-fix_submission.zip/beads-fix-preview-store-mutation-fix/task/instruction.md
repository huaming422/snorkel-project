## Task

`bd create --dry-run` and `bd migrate --inspect` are supposed to be previews: show what the command would do, touch nothing on disk. But after running one of them against a real workspace, the store sometimes comes back modified. New commits show up in the history, the schema gets quietly migrated, and a cached version marker gets rewritten. This used to work fine; a preview left the workspace alone.

Dig in and make the preview/dry-run/inspect commands genuinely non-mutating again, so that running one against a real workspace leaves it byte-for-byte unchanged. They should still do their job, reading the store and reporting what would happen; they just must not write anything back.
