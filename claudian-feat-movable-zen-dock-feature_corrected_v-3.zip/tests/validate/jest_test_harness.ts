// @ts-nocheck
//
// Shared Jest harness for the claudian-feat-movable-zen-dock DOM stories.
//
// WHY A HARNESS: the zen panel only becomes draggable/snappable once it is mounted
// inside Obsidian's central-workspace layout with a live tab runtime, and jsdom has
// neither layout nor PointerEvent. Reconstructing that world (workspace split, view,
// tab runtime, pointer/resize/frame polyfills, a fixed 1000x800 host with a 600x100 panel)
// is pure framework plumbing shared by every movement/hint story. It is ported from
// the repo's own pre-existing integration fixture
// (tests/integration/features/chat/zen/ZenMode.dom.test.ts) so it drives the panel
// exactly the way the project's own tests do.
//
// WHAT THIS HARNESS DELIBERATELY DOES NOT KNOW (supplied by each story script
// from the submitted patch, so every valid implementation passes):
//   * positionDeps(store)  -> the object merged into the ZenModeController deps that
//                             lets it read/remember the panel position. The harness
//                             only spreads whatever object the submission returns and
//                             reads the position back out of the shared `store`
//                             it handed in (any getPosition/savePosition-style seam
//                             works, named as the controller expects).
//   * readBox(panel)       -> { left, top } the panel's rendered top-left corner in px,
//                             relative to the central host's top-left, worked out
//                             from however the submission places it (CSS custom
//                             properties, inline left/top/bottom, a transform) with the
//                             same values the submission itself uses here. The harness
//                             derives the panel's mocked layout box, the offset from
//                             the bottom-center home and the "fully inside" check from
//                             it, so every design is measured in its own frame.
//   * findGrip(panel)      -> the move handle the panel renders (a button, by its own
//                             accessible label; or whatever element it made draggable).
//
// The harness keeps the remembered position in an in-memory `store` rather than the
// real settings file: these stories grade the DOCK's behaviour (what position it
// decides to remember, what it renders), not the settings KEY or persisted SHAPE.
// Those are a separate concern covered by the storage check. The setting key and
// on-disk shape are irrelevant here, by construction.

import '@/providers';

import { deserialize, serialize } from 'node:v8';
import { readFileSync, readdirSync } from 'node:fs';
import path from 'node:path';

import { createClaudianView } from '@test/helpers/features/chat/ClaudianViewHarness';
import { createHarness, releaseSideChatHarnesses } from '@test/helpers/features/chat/SideChatDOMHarness';
import { FakeSideSession } from '@test/helpers/features/chat/SideChatSessionHarness';
import { modelCatalogCases } from '@test/helpers/providerModelCatalogs';
import { fireEvent, within } from '@testing-library/dom';
import { App, Component } from 'obsidian';

import { ChatModelSelectionCoordinator } from '@/app/settings/ChatModelSelectionCoordinator';
import { DEFAULT_CLAUDIAN_SETTINGS } from '@/app/settings/defaultSettings';
import { SettingsCoordinator } from '@/app/settings/SettingsCoordinator';
import { ProviderRegistry } from '@/core/providers/ProviderRegistry';
import { ProviderWorkspaceRegistry } from '@/core/providers/ProviderWorkspaceRegistry';
import { createTabRuntime } from '@/features/chat/tabs/TabRuntimeFactory';
import { destroyTab } from '@/features/chat/tabs/TabLifecycle';
import { ZenModeController } from '@/features/chat/zen/ZenModeController';
import { setLocale } from '@/i18n/i18n';
import { VaultMentionDataProvider } from '@/shared/mention/VaultMentionDataProvider';

// Fixed jsdom "layout" the fixture pretends to have (jsdom computes none).
const HOST_WIDTH = 1000;
const HOST_HEIGHT = 800;
const PANEL_WIDTH = 600;
const COMPOSER_HEIGHT = 60;
const COMPOSER_GAP = 8; // composer sits this far inside the panel's bottom edge

// ===========================================================================
// panel_floats surface: the real zen stylesheet loaded into jsdom.
// ===========================================================================

/**
 * Mounts the zen panel's DOM (pre-existing structural selectors) with the repo's
 * REAL compiled zen stylesheet applied, and reports as concrete counts
 * whether the host reserves a bottom strip for the panel and how many of the
 * panel's surfaces are backed by an opaque colour. Everything here is
 * implementation-agnostic: the selectors pre-date the feature and the values
 * come from getComputedStyle over whatever CSS the submission ships.
 */
function shippedCss(): string {
  // Every .css under src/style, in a stable order with zen-mode last, so the
  // submission's rules apply wherever they live.
  const collectCss = (dir: string): string[] => {
    const out: string[] = [];
    for (const entry of readdirSync(dir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) out.push(...collectCss(full));
      else if (entry.name.endsWith('.css') && entry.name !== 'zen-mode.css') out.push(full);
    }
    return out;
  };
  const styleRoot = path.resolve('src/style');
  const cssFiles = [...collectCss(styleRoot), path.join(styleRoot, 'components/zen-mode.css')];
  return cssFiles
    .filter((file) => { try { readFileSync(file); return true; } catch { return false; } })
    .map((file) => readFileSync(file, 'utf8'))
    .join('\n');
}

function installCss(testId: string): void {
  document.head.querySelector(`[data-testid="${testId}"]`)?.remove();
  const style = document.createElement('style');
  style.dataset.testid = testId;
  style.textContent = shippedCss();
  document.head.appendChild(style);
}

/**
 * The background a stylesheet declares for `el` (last matching top-level rule in
 * sheet order wins, `background` or `background-color`). jsdom drops a
 * `background: var(...)` shorthand from computed style, so the declared text is
 * read instead of getComputedStyle.
 */
function declaredBackground(el: Element): string | null {
  let value: string | null = null;
  for (const sheet of Array.from(document.styleSheets)) {
    let rules: CSSRuleList;
    try { rules = sheet.cssRules; } catch { continue; }
    for (const rule of Array.from(rules)) {
      const selector = (rule as CSSStyleRule).selectorText;
      if (!selector) continue;
      let matches = false;
      try { matches = el.matches(selector); } catch { matches = false; }
      if (!matches) continue;
      const body = rule.cssText.slice(rule.cssText.indexOf('{') + 1);
      for (const m of body.matchAll(/(?:^|[;\s{])background(?:-color)?\s*:\s*([^;}]+)/g)) value = m[1].trim();
    }
  }
  return value;
}

function isOpaqueDeclaration(value: string | null): boolean {
  if (!value) return false;
  const v = value.replace(/!important/i, '').trim().toLowerCase();
  if (['transparent', 'none', 'initial', 'unset', 'inherit', 'revert'].includes(v)) return false;
  if (/^rgba\([^)]*,\s*0(\.0+)?\s*\)$/.test(v) || /^hsla\([^)]*,\s*0(\.0+)?\s*\)$/.test(v)) return false;
  if (/\/\s*0(\.0+)?\s*\)$/.test(v)) return false;
  return true;
}

export function renderStyledPanel(): {
  elementsReservingBottomStrip: number;
  opaqueSurfaces: number;
} {
  Object.assign(HTMLElement.prototype, {
    empty(this: HTMLElement) { this.replaceChildren(); },
    addClass(this: HTMLElement, ...names: string[]) { this.classList.add(...names); },
    removeClass(this: HTMLElement, ...names: string[]) { this.classList.remove(...names); },
    hasClass(this: HTMLElement, name: string) { return this.classList.contains(name); },
    toggleClass(this: HTMLElement, name: string, force: boolean) { this.classList.toggle(name, force); },
  });

  // Load the WHOLE shipped stylesheet so the submission's rules apply wherever
  // they live, never only zen-mode.css.
  installCss('zen-styles');

  document.body.innerHTML = `
    <div class="workspace-split mod-root claudian-zen-host">
      <div class="view-content">
        <div class="markdown-source-view mod-cm6"><div class="cm-editor"><div class="cm-scroller"></div></div></div>
        <div class="markdown-preview-view"></div>
      </div>
      <div class="claudian-container claudian-zen">
        <div class="claudian-zen-drawer">
          <div class="claudian-zen-history"><div class="claudian-messages-wrapper"><div class="claudian-messages"></div></div></div>
          <div class="claudian-zen-bar"><button type="button" class="claudian-zen-disclosure"><span class="claudian-zen-preview"></span></button></div>
        </div>
        <div class="claudian-zen-composer">
          <div class="claudian-input-composer"><div class="claudian-input-container"><div class="claudian-input-wrapper"><div class="claudian-input-toolbar"></div></div></div></div>
        </div>
        <div class="claudian-zen-side-chat-chip-slot claudian-side-chat-chip-slot">
          <div class="claudian-side-chat"><div class="claudian-side-chat-status"></div></div>
        </div>
      </div>
    </div>`;

  const host = document.querySelector<HTMLElement>('.claudian-zen-host')!;

  // "Reserves a bottom strip" = the host (or the content region) pads its bottom
  // to make room for the panel. A floating panel reserves nothing: the host's
  // bottom padding is empty or zero.
  const reservesStrip = (el: HTMLElement): boolean => {
    const pb = window.getComputedStyle(el).paddingBottom.trim();
    return pb !== '' && pb !== '0px' && pb !== '0';
  };
  const contentRegions = [
    host,
    host.querySelector<HTMLElement>('.cm-scroller'),
    host.querySelector<HTMLElement>('.markdown-preview-view'),
  ].filter(Boolean) as HTMLElement[];
  const elementsReservingBottomStrip = contentRegions.filter(reservesStrip).length;

  // Each listed surface is opaque when the stylesheet gives it, an element it sits
  // on inside the panel, or the box inside it a real background (any colour, theme
  // variable or image, not transparent/none or a zero-alpha colour), under both the
  // light and the dark theme.
  const surfaceSelectors = [
    '.claudian-zen-drawer',
    '.claudian-zen-composer > .claudian-input-composer',
    '.claudian-zen-side-chat-chip-slot .claudian-side-chat-status',
  ];
  const panelEl = document.querySelector<HTMLElement>('.claudian-zen')!;
  const isOpaqueIn = (sel: string): boolean => {
    const surface = document.querySelector<HTMLElement>(sel);
    if (!surface) return false;
    const candidates: HTMLElement[] = [...Array.from(surface.querySelectorAll<HTMLElement>('*'))];
    for (let el: HTMLElement | null = surface; el && el !== panelEl; el = el.parentElement) candidates.push(el);
    candidates.push(panelEl);
    return candidates.some((el) => isOpaqueDeclaration(declaredBackground(el)));
  };
  const countFor = (theme: string): number => {
    document.body.classList.remove('theme-light', 'theme-dark');
    document.body.classList.add(theme);
    return surfaceSelectors.filter(isOpaqueIn).length;
  };
  const opaqueSurfaces = Math.min(countFor('theme-light'), countFor('theme-dark'));
  document.body.classList.remove('theme-light', 'theme-dark');

  return { elementsReservingBottomStrip, opaqueSurfaces };
}

/** Tear down the style surface between cases. */
export function teardownStyledPanel(): void {
  document.head.querySelector('[data-testid="zen-styles"]')?.remove();
  document.body.replaceChildren();
}

// ===========================================================================
// Movement / hint surface: the live, mounted, draggable panel.
// ===========================================================================

type Split = { collapsed: boolean; containerEl: HTMLElement };
type Leaf = { view: unknown; getRoot: () => unknown; isDeferred?: boolean; loadIfDeferred?: () => Promise<void> };

// ===========================================================================
// Locale surface: the strings a submission adds under chat.zen, per locale.
// ===========================================================================

// The chat.zen keys en.json already had at the base commit.
const BASE_ZEN_KEYS = new Set([
  'regionLabel', 'showHistory', 'working', 'thinking', 'interrupted',
  'workedFor', 'workedForResult', 'actionRequired', 'error',
  'toolRunning', 'toolCompleted', 'toolFailed', 'toolBlocked',
]);

/** The chat.zen strings in `locale`'s file whose keys the submission added, by key. */
export function addedZenStrings(locale: string): Record<string, string> {
  const file = path.resolve('src/i18n/locales', `${locale}.json`);
  const zen = (JSON.parse(readFileSync(file, 'utf8')).chat?.zen ?? {}) as Record<string, unknown>;
  const added: Record<string, string> = {};
  for (const [key, value] of Object.entries(zen)) {
    if (!BASE_ZEN_KEYS.has(key) && typeof value === 'string') added[key] = value;
  }
  return added;
}

/**
 * Every text an element offers assistive tech: aria-label, aria-description,
 * title, the text of elements named by aria-labelledby / aria-describedby, and
 * its own trimmed text content. Empty values are left out.
 */
export function accessibleTexts(el: Element): string[] {
  const texts = [el.getAttribute('aria-label'), el.getAttribute('aria-description'), el.getAttribute('title')];
  for (const attr of ['aria-labelledby', 'aria-describedby']) {
    for (const id of (el.getAttribute(attr) ?? '').split(/\s+/).filter(Boolean)) {
      texts.push(el.ownerDocument.getElementById(id)?.textContent ?? null);
    }
  }
  texts.push(el.textContent);
  return texts.map((s) => (s ?? '').trim()).filter((s) => s.length > 0);
}

export interface PositionStore<T = unknown> { value: T | null; }

export interface MountOptions {
  /**
   * Returns the deps object merged into the ZenModeController so it can read and
   * remember the panel position. Read/write the position through the shared
   * `store` argument. Example:
   *   positionDeps: (store) => ({
   *     getPosition: () => store.value,
   *     savePosition: (p) => { store.value = p; },
   *   })
   * Name the deps exactly as your controller's constructor expects.
   */
  positionDeps(store: PositionStore): Record<string, unknown>;
  /**
   * The panel's rendered top-left corner in px, relative to the central host's
   * top-left (`fixture.rootEl`), worked out from however your panel places itself
   * (CSS custom properties, inline left/top/bottom, a transform), using the same
   * values your code uses in this environment. The host is `hostSize()` and the
   * panel is 600 wide and `panelHeight` tall.
   */
  readBox(panel: HTMLElement, env: { hostWidth: number; hostHeight: number; panelWidth: number; panelHeight: number }): { left: number; top: number };
  /** Locate the move handle your panel renders (e.g. its labelled move button). */
  findGrip(panel: HTMLElement): HTMLElement;
  /** Position the store starts at (default null = docked). */
  initialPosition?: unknown;
  /** Give the conversation earlier messages so the panel shows its history drawer. */
  withHistory?: boolean;
  /** Plugin display language for this mount (default 'en'); reset to 'en' on cleanup. */
  locale?: string;
}

export interface ZenFixture {
  panel: HTMLElement;
  rootEl: HTMLElement;
  rightSplit: Split;
  noteEditor: HTMLTextAreaElement;
  store: PositionStore;
  /** The position the dock has most recently decided to remember. */
  savedPosition(): unknown;
  /**
   * The panel's rendered offset from its bottom-center home, in px: x is how far
   * its centre sits right of the host's centre, y how far its bottom edge sits above
   * where it rests when docked (up positive). Computed by the harness from readBox.
   */
  offset(panel?: HTMLElement): { x: number; y: number };
  /** The panel's rendered box { left, top, right, bottom } in host px. */
  box(): { left: number; top: number; right: number; bottom: number };
  /** True when the whole panel box lies inside the host. */
  inside(): boolean;
  /** Open or close the history drawer through the panel's own disclosure control. */
  setHistoryExpanded(expanded: boolean): void;
  /** The move handle, re-located on the current panel. */
  grip(panel?: HTMLElement): HTMLElement;
  /** Collapse/expand the panel's sidebar so the controller re-mounts it. */
  setCollapsed(collapsed: boolean): void;
  /** Collapse then re-open to force a fresh panel mount; returns the new panel. */
  reopen(): HTMLElement;
  /** The host's current inner width/height in px. */
  hostSize(): { width: number; height: number };
  /** Resize the central host (px) and fire a resize so the dock re-clamps/re-renders. */
  setHostSize(width: number, height: number): void;
  /** Set the fake panel height (px) and fire a resize so the dock re-clamps. */
  setPanelHeight(height: number): void;
  /** Set the fake height (px) of the drawer's visible content and fire a resize. */
  setDrawerHeight(height: number): void;
  /** Re-run the ResizeObserver callbacks for the panel. */
  resize(): void;
  /** Full pointer drag of `handle` from one client point to another. */
  drag(handle: HTMLElement, from: [number, number], to: [number, number]): void;
  pointerDown(handle: HTMLElement, at: [number, number]): void;
  pointerMove(to: [number, number]): void;
  pointerUp(at: [number, number]): void;
  /** Fire a keydown on `target` (grip or panel root, whichever you listen on). */
  fireKey(target: HTMLElement, key: string, init?: KeyboardEventInit): void;
  cleanup(): Promise<void>;
}

function createWorkspace() {
  const containerEl = document.body.createDiv({ cls: 'workspace' });
  const leftSplit: Split = { collapsed: false, containerEl: containerEl.createDiv({ cls: 'workspace-split mod-left-split' }) };
  const rootEl = containerEl.createDiv({ cls: 'workspace-split mod-vertical mod-root' });
  const rightSplit: Split = { collapsed: false, containerEl: containerEl.createDiv({ cls: 'workspace-split mod-right-split' }) };
  const rootSplit = {};
  const noteEditor = rootEl.createDiv({ cls: 'workspace-leaf' }).createEl('textarea', {
    attr: { 'aria-label': 'Note editor' },
  }) as HTMLTextAreaElement;
  const listeners = new Map<string, Set<(...args: unknown[]) => void>>();
  const leaves: Leaf[] = [];
  const workspace = {
    containerEl, leftSplit, rightSplit, rootSplit, layoutReady: true,
    onLayoutReady: (callback: () => void) => callback(),
    on(name: string, callback: (...args: unknown[]) => void) {
      if (!listeners.has(name)) listeners.set(name, new Set());
      listeners.get(name)!.add(callback);
      return { name, callback };
    },
    offref(ref: { name: string; callback: (...args: unknown[]) => void }) { listeners.get(ref.name)?.delete(ref.callback); },
    trigger(name: string, ...args: unknown[]) { for (const listener of [...(listeners.get(name) ?? [])]) listener(...args); },
    listenerCount: () => [...listeners.values()].reduce((total, set) => total + set.size, 0),
    getLeavesOfType: () => leaves,
    getActiveFile: () => null,
    revealLeaf: jest.fn(async (leaf: Leaf) => { (leaf.getRoot() as Split).collapsed = false; workspace.trigger('resize'); }),
  };
  const scopes: unknown[] = [];
  const keymap = {
    pushScope: (scope: unknown) => { scopes.push(scope); },
    popScope: (scope: unknown) => { scopes.splice(scopes.indexOf(scope), 1); },
  };
  const setCollapsed = (split: Split, collapsed: boolean) => { split.collapsed = collapsed; workspace.trigger('resize'); };
  return { workspace, keymap, scopes, rootEl, rootSplit, leftSplit, rightSplit, noteEditor, leaves, setCollapsed };
}

function createSettings(enabled: boolean) {
  const entry = modelCatalogCases.find((candidate) => candidate.id === 'claude')!;
  const settings = JSON.parse(JSON.stringify(DEFAULT_CLAUDIAN_SETTINGS));
  entry.populate(settings);
  settings.enableZenMode = enabled;
  return settings;
}

/**
 * Mount the live zen panel inside a fake Obsidian central workspace, wired to an
 * in-memory position store through the script-supplied `positionDeps`. Returns a
 * fixture with drag/keyboard/resize controls and position readers.
 */
export async function mountZenFixture(opts: MountOptions): Promise<ZenFixture> {
  const cleanups: Array<() => Promise<void> | void> = [];

  if (opts.locale) {
    setLocale(opts.locale as any);
    cleanups.push(() => { setLocale('en'); });
  }

  // jsdom lacks structuredClone semantics SettingsCoordinator relies on.
  const originalStructuredClone = globalThis.structuredClone;
  globalThis.structuredClone = (value: unknown) => deserialize(serialize(value));
  cleanups.push(() => { globalThis.structuredClone = originalStructuredClone; });

  // jsdom has no PointerEvent, fireEvent.pointer* would drop coordinates.
  const originalPointerEvent = window.PointerEvent;
  window.PointerEvent = class extends MouseEvent {
    readonly pointerId: number;
    constructor(type: string, init: PointerEventInit = {}) { super(type, init); this.pointerId = init.pointerId ?? 0; }
  } as unknown as typeof PointerEvent;
  cleanups.push(() => { window.PointerEvent = originalPointerEvent; });

  // jsdom has no pointer capture; browsers do, so give elements the no-op API.
  const proto = Element.prototype as any;
  const hadCapture = typeof proto.setPointerCapture === 'function';
  if (!hadCapture) {
    proto.setPointerCapture = function () { /* no-op */ };
    proto.releasePointerCapture = function () { /* no-op */ };
    proto.hasPointerCapture = function () { return false; };
    cleanups.push(() => { delete proto.setPointerCapture; delete proto.releasePointerCapture; delete proto.hasPointerCapture; });
  }

  // Animation frames: queued and run between user actions (see settle()), the way a
  // browser paints before the next pointer or key event arrives.
  const frameQueue: Array<FrameRequestCallback | null> = [];
  const originalRaf = window.requestAnimationFrame;
  const originalCaf = window.cancelAnimationFrame;
  window.requestAnimationFrame = ((cb: FrameRequestCallback) => { frameQueue.push(cb); return frameQueue.length; }) as typeof window.requestAnimationFrame;
  window.cancelAnimationFrame = ((id: number) => { if (id > 0 && id <= frameQueue.length) frameQueue[id - 1] = null; }) as typeof window.cancelAnimationFrame;
  cleanups.push(() => { window.requestAnimationFrame = originalRaf; window.cancelAnimationFrame = originalCaf; });

  // Controllable ResizeObserver so panel/drawer growth can be simulated on demand.
  // Like a real one, it also delivers one notification after observe() starts.
  const originalResizeObserver = globalThis.ResizeObserver;
  const observers: Array<{ callback: ResizeObserverCallback; targets: Set<Element>; pending: boolean }> = [];
  globalThis.ResizeObserver = class {
    readonly #entry: { callback: ResizeObserverCallback; targets: Set<Element>; pending: boolean };
    constructor(callback: ResizeObserverCallback) { this.#entry = { callback, targets: new Set(), pending: false }; observers.push(this.#entry); }
    observe(target: Element) { this.#entry.targets.add(target); this.#entry.pending = true; }
    unobserve(target: Element) { this.#entry.targets.delete(target); }
    disconnect() { this.#entry.targets.clear(); this.#entry.pending = false; }
  } as unknown as typeof ResizeObserver;
  cleanups.push(() => { globalThis.ResizeObserver = originalResizeObserver; });
  const fireResize = (target: Element) => {
    for (const entry of observers) if (entry.targets.has(target)) { entry.pending = false; entry.callback([], {} as ResizeObserver); }
  };
  // Deliver initial observer notifications and run queued frames until quiet.
  const settle = () => {
    for (let round = 0; round < 10; round += 1) {
      let ran = false;
      for (const entry of observers) {
        if (entry.pending && entry.targets.size > 0) { entry.pending = false; ran = true; entry.callback([], {} as ResizeObserver); }
      }
      const frames = frameQueue.splice(0);
      for (const cb of frames) if (cb) { ran = true; cb(performance.now()); }
      if (!ran) break;
    }
  };

  // The real stylesheet, so CSS custom properties the panel reads (insets, padding)
  // resolve the way they do in the app.
  installCss('zen-fixture-styles');
  cleanups.push(() => { document.head.querySelector('[data-testid="zen-fixture-styles"]')?.remove(); });

  const settings = createSettings(true);
  const harness = createHarness({ settings: settings as unknown as Record<string, unknown> });
  ProviderWorkspaceRegistry.setServices('claude', {});
  const app = new App();
  Object.assign(app.vault.adapter, { basePath: '/vault' });
  Object.assign(app.vault, { on: () => ({}), offref: () => undefined });
  const layout = createWorkspace();
  Object.assign(app, { workspace: layout.workspace, keymap: layout.keymap });
  const sessions: FakeSideSession[] = [];
  jest.spyOn(ProviderRegistry, 'createExecutionBackend').mockImplementation((_host, providerId = 'claude') => ({
    providerId,
    createSession: (config: unknown) => { const session = new FakeSideSession(config); sessions.push(session); return session; },
  }));
  const conversations: unknown[] = [];

  const store: PositionStore = { value: opts.initialPosition ?? null };

  let settingsCoordinator: SettingsCoordinator<unknown>;
  const zen = new ZenModeController({
    app,
    isEnabled: (): boolean => settingsCoordinator.getCommittedSettings().enableZenMode,
    // Free-choice seam: whatever deps the controller needs to read /
    // remember the position, wired to the in-memory store.
    ...opts.positionDeps(store),
  });
  settingsCoordinator = new SettingsCoordinator(settings, async () => undefined, () => zen.reconcile());

  const find = (id: string) => conversations.find((entry: any) => entry.id === id) ?? null;
  const plugin = {
    ...harness.plugin, app, settings,
    chatModelSelection: new ChatModelSelectionCoordinator(settingsCoordinator),
    executionPersistence: {
      registerExecutionBinding: () => undefined, releaseExecutionBinding: () => undefined,
      persistExecutionSnapshot: async () => true, assertConversationExecutionAuthority: async () => undefined,
      recordConversationActivity: async () => undefined,
    },
    getActiveEnvironmentVariables: () => '',
    getConversationSummary: find, getConversationSync: find,
    getConversationById: async (id: string) => find(id), getConversationList: () => conversations,
    updateConversation: async () => undefined, renameConversation: async () => undefined,
    mutateSettings: settingsCoordinator.mutate.bind(settingsCoordinator),
    getCommittedSettings: settingsCoordinator.getCommittedSettings.bind(settingsCoordinator),
    registerZenModeSource: (source: unknown) => zen.register(source as never),
  } as unknown as Record<string, unknown>;

  const addView = async (placement: 'left' | 'right' | 'main', ready = true) => {
    const conversation = {
      id: `conversation-${conversations.length + 1}`, providerId: 'claude',
      selectedModel: modelCatalogCases.find((c) => c.id === 'claude')!.selected,
      messages: [], sessionId: `session-${conversations.length + 1}`,
    };
    conversations.push(conversation);
    const split = placement === 'left' ? layout.leftSplit : placement === 'right' ? layout.rightSplit : null;
    const viewContainerEl = (split?.containerEl ?? layout.rootEl).createDiv({ cls: 'claudian-container' });
    const leaf: Leaf = { getRoot: () => split ?? layout.rootSplit, view: null };
    const view = createClaudianView({ host: plugin, app, leaf, containerEl: viewContainerEl, contentEl: viewContainerEl });
    view.viewContainerEl = viewContainerEl;
    view.buildViewLayout(viewContainerEl);
    const tab = await createTabRuntime({
      plugin, component: Object.assign(new Component(), { registerDomEvent: () => undefined, registerEvent: () => undefined }),
      containerEl: view.tabContentEl, mentionDataProvider: new VaultMentionDataProvider(plugin.app),
      conversation, getProviderCatalogConfig: () => null, isRuntimeLive: () => true,
    });
    tab.state.currentConversationId = conversation.id;
    if (opts.withHistory) {
      tab.state.messages = [
        { id: 'u1', role: 'user', content: 'Earlier question', timestamp: 1 },
        { id: 'a1', role: 'assistant', content: 'Earlier answer', timestamp: 2 },
      ];
    }
    tab.dom.contentEl.removeClass('claudian-hidden');
    cleanups.push(() => destroyTab(tab));
    view.tabManager = { getActiveTab: () => tab, getTab: (id: string) => (id === tab.id ? tab : null), getTabCount: () => 1 };
    Object.assign(view.tabWorkspace, { lifecycleRevision: 1, initializedRevision: ready ? 1 : -1 });
    leaf.view = view;
    layout.leaves.push(leaf);
    view.presentation.update();
    view.startZenModeSource();
    cleanups.push(() => view.stopZenModeSource());
    return { view, tab, leaf };
  };

  zen.start();
  cleanups.push(() => zen.dispose());
  await addView('right', true);

  const zenPanel = (): HTMLElement => document.querySelector<HTMLElement>('.claudian-zen')!;

  // jsdom has no layout: describe a HOST_WIDTH x HOST_HEIGHT host holding a
  // 600 x panelHeight panel. The composer sits COMPOSER_GAP inside the panel
  // bottom, which rides the vertical offset; a drawer, when shown, stands on the
  // composer, 526px wide. Host size is mutable so a transient squeeze can be
  // simulated (shrink, then restore) for the resize-stability story.
  let hostWidth = HOST_WIDTH;
  let hostHeight = HOST_HEIGHT;
  Object.defineProperty(layout.rootEl, 'clientWidth', { configurable: true, get: () => hostWidth });
  Object.defineProperty(layout.rootEl, 'clientHeight', { configurable: true, get: () => hostHeight });
  jest.spyOn(layout.rootEl, 'getBoundingClientRect').mockImplementation(() => ({
    top: 0, bottom: hostHeight, left: 0, right: hostWidth, width: hostWidth, height: hostHeight,
  } as DOMRect));

  let panelHeight = 100;
  let drawerHeight = 0;

  // The panel's rendered box, read through the submission's own readBox and cached
  // after each discrete operation, so the layout mocks below follow wherever the
  // submission actually put the panel (no recursion when readBox itself measures).
  let cachedBox = { left: (HOST_WIDTH - PANEL_WIDTH) / 2, top: HOST_HEIGHT - panelHeight };
  let _refreshing = false;
  const env = () => ({ hostWidth, hostHeight, panelWidth: PANEL_WIDTH, panelHeight });
  const refreshBoxCache = (p: HTMLElement) => {
    if (_refreshing) return;
    _refreshing = true;
    try {
      const b = opts.readBox(p, env());
      if (Number.isFinite(b?.left) && Number.isFinite(b?.top)) cachedBox = { left: b.left, top: b.top };
    } catch { /* leave stale */ } finally { _refreshing = false; }
  };
  const drawerShown = (p: HTMLElement) => {
    const drawer = p.querySelector<HTMLElement>('.claudian-zen-drawer');
    return !!drawer && !drawer.classList.contains('claudian-hidden') && drawer.style.display !== 'none';
  };

  const stubPanel = (p: HTMLElement) => {
    // Panel: 600 wide, panelHeight tall, at the cached box. Composer: COMPOSER_HEIGHT
    // tall, COMPOSER_GAP inside the panel's bottom and sides. Drawer: stands on the
    // composer, 526 wide, drawerHeight tall while it is shown, zero otherwise.
    const rect = (left: number, top: number, width: number, height: number) => ({
      left, top, right: left + width, bottom: top + height, width, height, x: left, y: top, toJSON: () => ({}),
    } as DOMRect);
    // Like a browser, the boxes reflect the panel's current placement whenever they
    // are read (the re-entrancy guard serves the cached box to a readBox that measures).
    const live = () => { refreshBoxCache(p); return cachedBox; };
    jest.spyOn(p, 'getBoundingClientRect').mockImplementation(() => { const b = live(); return rect(b.left, b.top, PANEL_WIDTH, panelHeight); });
    const composerTop = () => live().top + panelHeight - COMPOSER_GAP - COMPOSER_HEIGHT;
    const composer = p.querySelector<HTMLElement>('.claudian-zen-composer');
    if (composer) {
      jest.spyOn(composer, 'getBoundingClientRect').mockImplementation(() =>
        rect(live().left + COMPOSER_GAP, composerTop(), PANEL_WIDTH - 2 * COMPOSER_GAP, COMPOSER_HEIGHT));
    }
    const drawer = p.querySelector<HTMLElement>('.claudian-zen-drawer');
    if (drawer) {
      jest.spyOn(drawer, 'getBoundingClientRect').mockImplementation(() => {
        const h = drawerShown(p) ? drawerHeight : 0;
        return rect(live().left + 37, composerTop() - h, 526, h);
      });
    }
  };

  // Open the panel (collapse the right split so the central host hosts it).
  layout.setCollapsed(layout.rightSplit, true);
  let panel = zenPanel();
  stubPanel(panel);
  settle(); refreshBoxCache(panel);

  // Track the last handle used for pointerDown so that pointerMove/pointerUp
  // can fire on the same element. Firing on the handle (not document) ensures
  // events bubble up to document-level listeners AND reach handle-level listeners
  // registered with setPointerCapture (also valid). In jsdom, setPointerCapture
  // is a no-op, so the only reliable delivery path for handle-level move/up
  // listeners is to fire on the handle itself.
  let _lastPointerHandle: HTMLElement = document.body;

  const drag = (handle: HTMLElement, from: [number, number], to: [number, number]) => {
    fireEvent.pointerDown(handle, { button: 0, pointerId: 1, clientX: from[0], clientY: from[1] });
    settle();
    fireEvent.pointerMove(handle, { pointerId: 1, clientX: to[0], clientY: to[1] });
    settle();
    fireEvent.pointerUp(handle, { pointerId: 1, clientX: to[0], clientY: to[1] });
    settle(); refreshBoxCache(panel);
  };

  // Captured once the panel is docked: how far above the host's bottom edge the
  // docked panel's bottom edge rests (the submission's own inset).
  let dockGap = 0;
  const currentBox = () => {
    refreshBoxCache(panel);
    return { left: cachedBox.left, top: cachedBox.top, right: cachedBox.left + PANEL_WIDTH, bottom: cachedBox.top + panelHeight };
  };

  const fixture: ZenFixture = {
    get panel() { return panel; },
    rootEl: layout.rootEl,
    rightSplit: layout.rightSplit,
    noteEditor: layout.noteEditor,
    store,
    savedPosition: () => store.value,
    offset: (p?: HTMLElement) => {
      if (p && p !== panel) refreshBoxCache(p);
      const b = currentBox();
      return {
        x: Math.round((b.left + b.right) / 2 - hostWidth / 2),
        y: Math.round(hostHeight - dockGap - b.bottom),
      };
    },
    box: () => currentBox(),
    inside: () => {
      const b = currentBox();
      return b.left >= -0.5 && b.top >= -0.5 && b.right <= hostWidth + 0.5 && b.bottom <= hostHeight + 0.5;
    },
    setHistoryExpanded: (expanded: boolean) => {
      const disclosure = panel.querySelector<HTMLElement>('.claudian-zen-disclosure');
      if (disclosure && (disclosure.getAttribute('aria-expanded') === 'true') !== expanded) fireEvent.click(disclosure);
      fireResize(panel);
      settle(); refreshBoxCache(panel);
    },
    grip: (p?: HTMLElement) => opts.findGrip(p ?? panel),
    setCollapsed: (collapsed: boolean) => layout.setCollapsed(layout.rightSplit, collapsed),
    reopen: () => {
      layout.setCollapsed(layout.rightSplit, false);
      layout.noteEditor.focus();
      layout.setCollapsed(layout.rightSplit, true);
      panel = zenPanel();
      stubPanel(panel);
      settle(); refreshBoxCache(panel);
      return panel;
    },
    hostSize: () => ({ width: hostWidth, height: hostHeight }),
    setHostSize: (width: number, height: number) => {
      hostWidth = width; hostHeight = height;
      layout.workspace.trigger('resize');
      fireResize(layout.rootEl);
      fireResize(panel);
      settle(); refreshBoxCache(panel);
    },
    setPanelHeight: (height: number) => { panelHeight = height; fireResize(panel); settle(); refreshBoxCache(panel); },
    setDrawerHeight: (height: number) => { drawerHeight = height; fireResize(panel); settle(); refreshBoxCache(panel); },
    resize: () => { fireResize(panel); settle(); refreshBoxCache(panel); },
    drag,
    pointerDown: (handle: HTMLElement, at: [number, number]) => {
      _lastPointerHandle = handle;
      fireEvent.pointerDown(handle, { button: 0, pointerId: 1, clientX: at[0], clientY: at[1] });
      settle(); refreshBoxCache(panel);
    },
    pointerMove: (to: [number, number]) => { fireEvent.pointerMove(_lastPointerHandle, { pointerId: 1, clientX: to[0], clientY: to[1] }); settle(); refreshBoxCache(panel); },
    pointerUp: (at: [number, number]) => { fireEvent.pointerUp(_lastPointerHandle, { pointerId: 1, clientX: at[0], clientY: at[1] }); settle(); refreshBoxCache(panel); },
    fireKey: (target: HTMLElement, key: string, init?: KeyboardEventInit) => { fireEvent.keyDown(target, { key, ...init }); settle(); refreshBoxCache(panel); },
    cleanup: async () => {
      for (const c of cleanups.splice(0).reverse()) await c();
      ProviderWorkspaceRegistry.clear();
      jest.restoreAllMocks();
      await releaseSideChatHarnesses();
      document.body.replaceChildren();
    },
  };
  dockGap = Math.round(hostHeight - currentBox().bottom);
  // expose `within` for convenience when a script locates its grip by role.
  (fixture as any).within = within;
  return fixture;
}
