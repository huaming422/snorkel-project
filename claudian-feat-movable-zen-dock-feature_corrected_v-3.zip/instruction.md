## Task

When zen mode is on, the chat claims a band along the bottom of the central editor, and whatever document is open gets shorter by that amount. Let's have the chat float above the document instead, and let people pick it up and put it somewhere else. Bottom-center of the editor is its one magnetic resting place, and it should return to wherever a person last left it.

Keep that spot in the plugin's settings. When nothing usable is saved there, the panel just starts out docked. A saved spot that's missing a coordinate, or has one that isn't a usable number, counts as nothing usable. Any new controls need text in all ten languages the plugin supports, and this extends today's zen mode rather than starting over.

Not part of this: a docked panel sitting on top of Obsidian's status bar, and a floating panel stealing clicks from the document beneath it. The direction the composer's menus open in and any reduced-motion handling are also up to you.

## User stories / requirements

- Zen chat over a document leaves the document at its full height, with the panel on top. The history drawer, the composer and the side-chat chip are solid in light and dark themes alike, so the document never shows through them.
- A person can drag the panel around above the editor, yet every edge of it stays within the central editor area, including when the panel gets taller or the editor gets narrower partway through a drag.
- Let go near the bottom-center resting place and the panel snaps into it. Let go anywhere else and it remains right where it was released.
- Reopening the chat puts the panel back at the same proportional position, even after the window or sidebars got bigger or smaller. A brief squeeze of the editor that's later undone doesn't cost the panel its place.
- Keys can nudge the panel step by step as well, and one key returns it straight to its resting place.
- During a drag, a marker at the resting place outlines the panel's own shape: only the composer when there's no history above it, and the composer plus the narrower history drawer rising from it while the history is expanded.
- The control people use to move the panel is labelled in the language they've picked for the plugin.
