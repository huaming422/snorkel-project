"""Checks for `element.dataset` name conversion in Jint.Browser.

The repository is C#, so this pytest file injects one NUnit test file into
the browser test project, runs `dotnet test` once in Release with host-contract
verification on, parses the TRX, and maps each C# test's outcome onto one
pytest test.

Everything runs through the JavaScript surface a page author sees:
`element.dataset` reads, writes and deletes, `Object.keys`, `'key' in dataset`,
`getAttribute`/`hasAttribute`, and the thrown `DOMException` name and code.
The repository's own binding suites (staleness, pin, host contract) run in the
same `dotnet test` call.
"""

from __future__ import annotations

import functools
import os
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

REPO = Path(f"/repo/{os.environ.get('REPO_NAME', 'jint')}")
TEST_PROJECT_DIR = REPO / "Jint.Tests.Browser"
TEST_PROJECT = TEST_PROJECT_DIR / "Jint.Tests.Browser.csproj"
INJECTED_TEST = TEST_PROJECT_DIR / "DatasetNameConversionVerifyTests.cs"
TRX_PATH = Path("/tmp/dataset_verify_results.trx")

# One target framework keeps the run inside the wall-clock budget; net10.0 is
# the toolchain the repo's global.json pins. Release is required because the
# host-contract verifiers only arm outside DEBUG.
TARGET_FRAMEWORK = "net10.0"

# The focused test file. It uses the project's own DomTestFixture (same
# assembly, so its internals are reachable) and drives JavaScript against the
# engine exactly as the existing binding tests do.
INJECTED_SOURCE = r'''// Checks for element.dataset, run as page script through the engine.
// Each case reads results back with getAttribute, hasAttribute, the
// attribute list, Object.keys or for..in, never through C# types.
namespace Jint.Tests.Browser;

public sealed class DatasetNameConversionVerifyTests
{
    private static DomTestFixture New() => DomTestFixture.Create("<div id='x'></div>");

    private static string Script(string body) =>
        "(function(){ var e = document.getElementById('x'); " + body + " })()";

    private const string AttributeNames =
        "return Array.prototype.map.call(e.attributes, function (a) { return a.name; }).sort().join(',');";

    [Test]
    public void ReadsCamelCaseKey()
    {
        using var fx = New();
        fx.Evaluate(Script(
            "e.setAttribute('data-max-length', '7'); e.setAttribute('data-max-row-count', '12'); "
            + "e.setAttribute('data-a-1', 'one');"));
        fx.Text(Script("return e.dataset.maxLength;")).Should().Be("7");
        fx.Text(Script("return e.dataset.maxRowCount;")).Should().Be("12");
        fx.Text(Script("return e.dataset['a-1'];")).Should().Be("one");

        // The dashed spelling is not one of the map's names.
        fx.Bool(Script("return e.dataset['max-length'] === undefined;")).Should().BeTrue();
        fx.Bool(Script("return 'max-length' in e.dataset;")).Should().BeFalse();
        fx.Bool(Script("return 'maxRowCount' in e.dataset;")).Should().BeTrue();

        // The same names through the descriptor, own-property and entries routes.
        fx.Text(Script("return Object.getOwnPropertyDescriptor(e.dataset, 'maxRowCount').value;")).Should().Be("12");
        fx.Bool(Script("return Object.getOwnPropertyDescriptor(e.dataset, 'max-row-count') === undefined;")).Should().BeTrue();
        fx.Text(Script("return String(e.dataset.hasOwnProperty('maxLength')) + ',' + String(e.dataset.hasOwnProperty('max-length'));"))
            .Should().Be("true,false");
        fx.Text(Script("return Object.entries(e.dataset).map(function (p) { return p[0] + '=' + p[1]; }).sort().join(',');"))
            .Should().Be("a-1=one,maxLength=7,maxRowCount=12");
    }

    [Test]
    public void WritesCamelCaseKey()
    {
        using var fx = New();
        fx.Evaluate(Script("e.dataset.userId = 'u-42';"));
        fx.Text(Script("return e.getAttribute('data-user-id');")).Should().Be("u-42");
        fx.Evaluate(Script("e.dataset.userId = 'u-43';"));
        fx.Text(Script("return e.getAttribute('data-user-id');")).Should().Be("u-43");
        fx.Text(Script("return e.dataset.userId;")).Should().Be("u-43");

        fx.Evaluate(Script("e.dataset.userIdHashValue = 'h';"));
        fx.Text(Script("return e.getAttribute('data-user-id-hash-value');")).Should().Be("h");

        // A hyphen that is not followed by a lowercase ASCII letter is kept.
        fx.Evaluate(Script("e.dataset['a-1'] = 'x'; e.dataset['b-C'] = 'y';"));
        fx.Text(Script("return e.getAttribute('data-a-1') + '|' + e.getAttribute('data-b--c');")).Should().Be("x|y");
        fx.Text(Script(AttributeNames)).Should().Be("data-a-1,data-b--c,data-user-id,data-user-id-hash-value,id");
    }

    [Test]
    public void DeleteRemovesBackingAttribute()
    {
        using var fx = New();
        fx.Evaluate(Script(
            "e.setAttribute('data-user-id', 'u-1'); e.setAttribute('data-row-max-count', '3'); "
            + "e.setAttribute('data-foo', 'a');"));
        fx.Evaluate(Script("delete e.dataset.userId; delete e.dataset.rowMaxCount;"));

        fx.Bool(Script("return e.hasAttribute('data-user-id');")).Should().BeFalse();
        fx.Bool(Script("return e.hasAttribute('data-row-max-count');")).Should().BeFalse();
        fx.Bool(Script("return e.dataset.userId === undefined;")).Should().BeTrue();
        fx.Bool(Script("return 'userId' in e.dataset;")).Should().BeFalse();
        fx.Text(Script("return Object.keys(e.dataset).join(',');")).Should().Be("foo");
        fx.Text(Script(AttributeNames)).Should().Be("data-foo,id");

        fx.Evaluate(Script("delete e.dataset.foo;"));
        fx.Bool(Script("return e.hasAttribute('data-foo');")).Should().BeFalse();
        fx.Text(Script(AttributeNames)).Should().Be("id");
    }

    [Test]
    public void EnumeratesConvertedKeys()
    {
        using var fx = New();
        fx.Evaluate(Script(
            "e.setAttribute('data-foo', 'a'); e.setAttribute('data-max-length', '7'); "
            + "e.setAttribute('data-max-row-count', '9'); e.setAttribute('data-x--y', 'z'); "
            + "e.setAttribute('data-a-1', 'b'); e.setAttributeNS(null, 'data-Upper', 'u');"));
        const string expected = "a-1,foo,maxLength,maxRowCount,x-Y";
        fx.Text(Script("return Object.keys(e.dataset).sort().join(',');")).Should().Be(expected);
        fx.Text(Script("var k = []; for (var n in e.dataset) { k.push(n); } return k.sort().join(',');")).Should().Be(expected);
    }

    [TestCase("my-key")]
    [TestCase("a-b")]
    [TestCase("aB-cd")]
    [TestCase("-x")]
    public void RefusesHyphenLowercaseWithSyntaxError(string property)
    {
        using var fx = New();
        fx.Text(Script(
            "try { e.dataset['" + property + "'] = 'v'; return 'no throw'; } "
            + "catch (err) { return err.name + '/' + err.code; }"))
            .Should().Be("SyntaxError/12");
        fx.Text(Script(AttributeNames)).Should().Be("id");
    }

    // Property names in JavaScript escape form.
    [TestCase("bad name")]
    [TestCase("bad/name")]
    [TestCase("bad>name")]
    [TestCase("bad=name")]
    [TestCase("bad\\u0000name")]
    [TestCase("bad\\tname")]
    [TestCase("bad\\nname")]
    [TestCase("bad\\fname")]
    [TestCase("bad\\rname")]
    public void RefusesInvalidNameWithInvalidCharacterError(string property)
    {
        using var fx = New();
        fx.Text(Script(
            "try { e.dataset['" + property + "'] = 'v'; return 'no throw'; } "
            + "catch (err) { return err.name + '/' + err.code; }"))
            .Should().Be("InvalidCharacterError/5");
        fx.Text(Script(AttributeNames)).Should().Be("id");
    }

    // Names whose data-* form is a legal attribute name by the DOM's rule. The
    // write either lands or throws an InvalidCharacterError the script can catch.
    [TestCase("bad\\\"name", "data-bad\\\"name")]
    [TestCase("bad<name", "data-bad<name")]
    [TestCase("bad\\u00a0name", "data-bad\\u00a0name")]
    [TestCase("bad\\u000bname", "data-bad\\u000bname")]
    public void UnusualNamesLandOrThrowCatchably(string property, string attribute)
    {
        using var fx = New();
        fx.Text(Script(
            "try { e.dataset['" + property + "'] = 'v'; "
            + "return 'set:' + e.getAttribute('" + attribute + "'); } "
            + "catch (err) { return err.name + '/' + err.code; }"))
            .Should().BeOneOf("set:v", "InvalidCharacterError/5");
    }
}
'''

# Repository suites run in the same call: the generated-binding staleness
# check, the version pin, and the binding surface under host-contract
# verification.
CONTRACT_CLASSES = (
    "DomBindingsStalenessTests",
    "DomBindingsPinTests",
    "DomBindingTests",
)

TRX_NS = {"t": "http://microsoft.com/schemas/VisualStudio/TeamTest/2010"}

BEHAVIOR_CLASS = "DatasetNameConversionVerifyTests"


class Outcome:
    """One recorded C# test result."""

    def __init__(self, class_name: str, method: str, display: str, passed: bool) -> None:
        self.class_name = class_name  # short class name (last dotted segment)
        self.method = method          # bare method name, no arg tuple
        self.display = display        # full display name incl. arg tuple
        self.passed = passed


class DotnetRun:
    """Outcome of the single `dotnet test` invocation."""

    def __init__(self, returncode: int, outcomes: list[Outcome], log: str) -> None:
        self.returncode = returncode
        self.outcomes = outcomes
        self.log = log


def _short_class(fq: str) -> str:
    # className is like "Jint.Tests.Browser.DomBindingTests" -> "DomBindingTests".
    return fq.rsplit(".", 1)[-1] if fq else ""


def _restore_base_tests() -> None:
    """Put the browser test project back to the starting commit's version.

    The binding suites below run as written at the starting commit.
    """
    base_ref = Path("/var/lib/devcontainer_base_ref").read_text().strip()
    subprocess.run(
        ["git", "checkout", base_ref, "--", "Jint.Tests.Browser"],
        cwd=str(REPO), check=True, capture_output=True, text=True,
    )


@functools.lru_cache(maxsize=1)
def _run_dotnet() -> DotnetRun:
    _restore_base_tests()
    INJECTED_TEST.write_text(INJECTED_SOURCE)
    if TRX_PATH.exists():
        TRX_PATH.unlink()

    test_filter = "|".join(
        f"FullyQualifiedName~Jint.Tests.Browser.{name}"
        for name in (BEHAVIOR_CLASS, *CONTRACT_CLASSES)
    )

    env = {
        **os.environ,
        "JINT_HOST_CONTRACT_VERIFICATION": "1",
        "DOTNET_CLI_TELEMETRY_OPTOUT": "1",
        "DOTNET_NOLOGO": "1",
        "NUGET_PACKAGES": os.environ.get("NUGET_PACKAGES", "/root/.nuget/packages"),
    }

    cmd = [
        "dotnet", "test", str(TEST_PROJECT),
        "-c", "Release",
        "-f", TARGET_FRAMEWORK,
        "--no-restore",
        "--filter", test_filter,
        "--logger", f"trx;LogFileName={TRX_PATH.name}",
        "--results-directory", str(TRX_PATH.parent),
    ]

    proc = subprocess.run(
        cmd, cwd=str(REPO), env=env,
        capture_output=True, text=True, timeout=1500, check=False,
    )
    log = (proc.stdout or "")[-6000:] + "\n--- stderr ---\n" + (proc.stderr or "")[-4000:]

    outcomes: list[Outcome] = []
    if TRX_PATH.exists():
        root = ET.parse(str(TRX_PATH)).getroot()
        # Map testId -> className via the TestDefinitions section; UnitTestResult
        # display names do not carry the class, but their testId links to a
        # UnitTest whose <TestMethod className=.../> does.
        class_by_id: dict[str, str] = {}
        for ut in root.findall(".//t:TestDefinitions/t:UnitTest", TRX_NS):
            tid = ut.get("id", "")
            tm = ut.find("t:TestMethod", TRX_NS)
            if tid and tm is not None:
                class_by_id[tid] = _short_class(tm.get("className", ""))
        for r in root.findall(".//t:Results/t:UnitTestResult", TRX_NS):
            display = r.get("testName", "")
            method = display.split("(", 1)[0]
            cls = class_by_id.get(r.get("testId", ""), "")
            outcomes.append(Outcome(cls, method, display, r.get("outcome", "") == "Passed"))

    return DotnetRun(proc.returncode, outcomes, log)


def _assert_method(run: DotnetRun, method: str) -> None:
    """Assert every behavioral C# test case for `method` ran and passed.

    NUnit's TRX display name is the bare method name, plus an argument tuple in
    parentheses for each `[TestCase(...)]` row. Scope to the injected behavioral
    class so no same-named case elsewhere can satisfy it.
    """
    matched = [o for o in run.outcomes if o.class_name == BEHAVIOR_CLASS and o.method == method]
    assert matched, (
        f"no result recorded for C# test '{method}'. "
        f"The project likely failed to build or the test was not run.\n"
        f"dotnet exit={run.returncode}\n{run.log}"
    )
    failed = [o.display for o in matched if not o.passed]
    assert not failed, f"C# test(s) failed: {failed}\n{run.log}"


# --- one pytest test per C# test ------------------------------------------

def test_read_camel():
    _assert_method(_run_dotnet(), "ReadsCamelCaseKey")


def test_write_camel():
    _assert_method(_run_dotnet(), "WritesCamelCaseKey")


def test_delete_removes_attribute():
    _assert_method(_run_dotnet(), "DeleteRemovesBackingAttribute")


def test_enumerate_camel():
    _assert_method(_run_dotnet(), "EnumeratesConvertedKeys")


def test_refuse_syntax_error():
    _assert_method(_run_dotnet(), "RefusesHyphenLowercaseWithSyntaxError")


def test_refuse_invalid_char():
    _assert_method(_run_dotnet(), "RefusesInvalidNameWithInvalidCharacterError")


def test_unusual_names_stay_catchable():
    _assert_method(_run_dotnet(), "UnusualNamesLandOrThrowCatchably")


def test_preserve_binding_contract():
    """The pre-existing binding suites stay green under host-contract checks.

    Runs the generated-binding staleness check, the version pin, and the full
    binding surface with host-contract verification armed. Only those three
    suites are read here, never the dataset cases above.
    """
    run = _run_dotnet()
    assert run.outcomes, (
        "no TRX results were produced; the test project did not build or run.\n"
        f"dotnet exit={run.returncode}\n{run.log}"
    )
    for suite in CONTRACT_CLASSES:
        suite_results = [o for o in run.outcomes if o.class_name == suite]
        assert suite_results, (
            f"the pre-existing suite '{suite}' produced no results; it did not "
            f"run (filter miss or build failure).\n{run.log}"
        )
        failed = [o.display for o in suite_results if not o.passed]
        assert not failed, f"binding-contract regressions in {suite}: {failed}\n{run.log}"
