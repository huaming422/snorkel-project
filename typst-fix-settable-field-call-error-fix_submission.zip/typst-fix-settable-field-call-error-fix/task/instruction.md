## Task

if you call an element's settable field with parentheses, say `heading.numbering(1)` or `block.stroke(..)` instead of just reading `heading.numbering`, the compiler complains that the function doesn't contain that field. it's misleading: the field is real, it's a set-rule parameter you read under `context`, you just used call syntax where it isn't allowed. the message makes it sound like you got the field name wrong.

the compiler already handles other call-it-like-a-method mistakes well: it tells you plainly that you can't call that thing that way and points you at the right way to get the value. this case should land in the same place, making clear the field isn't something you call and showing how to read it instead.

leave the cases that already report sensibly alone: dictionaries, named arguments, genuinely missing fields, and plain field access under `context`. only the misleading message should change.
