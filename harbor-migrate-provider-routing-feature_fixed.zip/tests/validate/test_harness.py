"""Sandbox stand-in for driving installed-agent adapters the way a Harbor trial does.

A trial runs ``agent.setup`` and ``agent.run`` inside
``environment.scoped_exec_env(agent.extra_env)``, and every real ``exec`` merges
its env through ``BaseEnvironment._merge_env`` (persistent env < per-exec env <
scoped env). The stand-in below records what that real merge produces for each
``exec`` call, together with the command text, so a check sees what the
sandboxed CLI actually receives. Its tables list the variable names each adapter
reads, as values to seed, and where the CLI receives each one; it
knows nothing about how an adapter resolves them.

Typical use::

    from test_harness import make_mock_env, run_in_trial, received_under
    from harbor.agents.installed.pi import Pi

    env = make_mock_env()
    agent = Pi(logs_dir=tmp_path, model_name="anthropic/claude-3-5-sonnet",
               extra_env={"ANTHROPIC_API_KEY": "run-key"})
    run_in_trial(agent, env)
    assert received_under(env, "run-key", ("ANTHROPIC_API_KEY",), exact=True)
"""

from __future__ import annotations

import asyncio
import contextvars
import importlib
import os
import re
import tempfile
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, patch

from harbor.environments.base import BaseEnvironment


def make_exec_result(
    return_code: int = 0, stdout: str = "", stderr: str = ""
) -> AsyncMock:
    """A stand-in for an ExecResult: whatever attributes callers read back."""
    result = AsyncMock()
    result.return_code = return_code
    result.stdout = stdout
    result.stderr = stderr
    return result


def make_mock_env(
    return_code: int = 0, stdout: str = "", stderr: str = ""
) -> AsyncMock:
    """Build a sandbox stand-in for one trial.

    ``exec`` succeeds, yields to the event loop as a real exec does, and
    appends ``(command, env)`` to ``env.delivered``, where ``env`` is the real
    ``BaseEnvironment._merge_env`` result. ``upload_file`` copies nothing but
    keeps its calls, which ``uploaded`` reads. Any other
    coroutine an adapter calls resolves to a benign AsyncMock. ``default_user``
    is None, as on a real environment the task sets no user for.
    """
    env = AsyncMock()
    env.default_user = None
    env._persistent_env = {}
    env._exec_env_overlays = contextvars.ContextVar(
        f"exec_env_overlays_{id(env)}", default=()
    )
    env.delivered = []
    result = make_exec_result(return_code, stdout, stderr)

    async def _exec(*args: Any, **kwargs: Any) -> AsyncMock:
        merged = BaseEnvironment._merge_env(env, kwargs.get("env")) or {}
        command = kwargs.get("command", args[0] if args else "")
        env.delivered.append((str(command), dict(merged)))
        await asyncio.sleep(0)
        # DeerFlow reads its workdir and user ids back, as a sandbox prints them
        if "pwd -P && id -u && id -g" in str(command):
            return make_exec_result(return_code, "/app\n0\n0\n", stderr)
        return result

    env.exec.side_effect = _exec
    env.upload_file.return_value = None
    return env


def make_ctx() -> AsyncMock:
    """A minimal stand-in for the AgentContext an adapter's ``run()`` receives."""
    ctx = AsyncMock()
    ctx.metadata = None  # AgentContext's default, which some adapters extend
    return ctx


async def _run_scoped(
    agent: Any, env: Any, instruction: str, setup: bool = False
) -> None:
    with BaseEnvironment.scoped_exec_env(env, agent.extra_env):
        if setup:
            await agent.setup(env)
        await agent.run(instruction, env, make_ctx())


def run_in_trial(
    agent: Any, env: Any, instruction: str = "Fix the bug", setup: bool = False
) -> None:
    """Run ``agent.run`` once, with the agent's per-run env overlaid as a trial does.

    With ``setup=True``, ``agent.setup`` (which installs the CLI) runs first under
    the same overlay, as a trial sets the agent up before running it.
    """
    asyncio.run(_run_scoped(agent, env, instruction, setup))


def run_in_trials_concurrently(
    pairs: list[tuple[Any, Any]], instruction: str = "Fix the bug", setup: bool = False
) -> None:
    """Run several ``(agent, env)`` trials at once in one event loop, as a job does.

    With ``setup=True`` each trial runs ``agent.setup`` first, as in ``run_in_trial``.
    """

    async def _all() -> None:
        await asyncio.gather(*(_run_scoped(a, e, instruction, setup) for a, e in pairs))

    asyncio.run(_all())


def launch_sees(mock_env: Any, launch: str, name: str, value: str) -> bool:
    """Whether the process that the ``launch`` command text starts sees ``name`` as ``value``.

    Reads the first ``exec`` call whose command contains ``launch``. It counts when
    that call's env holds the value, or when its command assigns it before
    ``launch`` (``NAME=value`` or ``export NAME=value``, quoted or not), as the
    value itself or as ``$OTHER`` / ``${OTHER}`` for a name that call's env holds
    it under. Raises AssertionError if no call runs ``launch``.
    """
    for command, env in mock_env.delivered:
        if launch in command:
            break
    else:
        raise AssertionError(f"no exec call runs {launch!r}")
    if env.get(name) == value:
        return True
    before = command[: command.index(launch)]
    pattern = rf"(?<![\w$]){re.escape(name)}=(['\"]?)([^\s;&|'\"]*)\1(?=[\s;&|]|$)"
    for match in re.finditer(pattern, before):
        ref = re.fullmatch(r"\$\{?(\w+)\}?", match.group(2))
        if match.group(2) == value or (
            ref is not None and env.get(ref.group(1)) == value
        ):
            return True
    return False


def first_exec_env_with(mock_env: Any, *keys: str) -> dict[str, Any]:
    """The env of the first ``exec`` call that received every one of ``keys``.

    Raises AssertionError if no call did.
    """
    for _, env in mock_env.delivered:
        if all(k in env for k in keys):
            return dict(env)
    raise AssertionError(
        f"no exec call received all of {keys!r}; "
        f"recorded {len(mock_env.delivered)} exec call(s)"
    )


def forwarded_values(mock_env: Any) -> list[str]:
    """Every string value the sandbox received in any ``exec`` env, in call order.

    Name-agnostic: adapters expose one credential under different names, and
    some wrap it (``NAME=provider=<value>``).
    """
    return [
        value
        for _, env in mock_env.delivered
        for value in env.values()
        if isinstance(value, str)
    ]


def commands_of(mock_env: Any) -> list[str]:
    """The command text of every ``exec`` call, in call order."""
    return [command for command, _ in mock_env.delivered]


def received_under(
    mock_env: Any,
    value: str,
    names: tuple[str | tuple[str, ...], ...],
    in_command: bool = False,
    exact: bool = False,
) -> bool:
    """Whether ``value`` reached the sandbox under every env name in ``names``,
    and in some command when ``in_command``.

    An entry of ``names`` that is a tuple is a set of alternatives, any one of
    which counts. By default an env value may wrap ``value``
    (``provider=<value>``); with ``exact`` it must equal it.
    """
    envs = [env for _, env in mock_env.delivered]
    for entry in names:
        alternatives = (entry,) if isinstance(entry, str) else entry
        if not any(
            env.get(name) == value if exact else value in str(env.get(name, ""))
            for name in alternatives
            for env in envs
        ):
            return False
    return not in_command or any(value in c for c in commands_of(mock_env))


def reaches_sandbox(mock_env: Any, value: str) -> bool:
    """Whether ``value`` appears in any env value or command the sandbox received."""
    return any(value in v for v in forwarded_values(mock_env)) or any(
        value in c for c in commands_of(mock_env)
    )


_ANTHROPIC = "anthropic/claude-3-5-sonnet"
_OPENAI = "openai/gpt-4o"

# fmt: off
# Every adapter that reads a model credential itself (AcpAgent and KimiCode read
# none), with each model and credential variable it reads, where a standing value
# reaches the CLI. An adapter has a row for each provider whose set of key names
# differs from its other providers'. Devin reads its key and DeerFlow its working
# folder while they install, so they need setup=True. Each row ends with where the CLI receives a
# standing key: the env names the CLI receives it under, and whether a command
# is the only thing that carries it. Copilot CLI reads any of its three token
# names, so any one of them counts.
_ADAPTERS = [
    ("aider", "Aider", _ANTHROPIC, "ANTHROPIC_API_KEY", ("AIDER_API_KEY",), False),
    ("aider", "Aider", _OPENAI, "OPENAI_API_KEY", ("AIDER_API_KEY",), False),
    ("antigravity_cli", "AntigravityCli", _ANTHROPIC, "GEMINI_API_KEY", ("GEMINI_API_KEY",), False),
    ("antigravity_cli", "AntigravityCli", _ANTHROPIC, "GOOGLE_API_KEY", ("GOOGLE_API_KEY",), False),
    ("antigravity_sdk", "AntigravitySDK", _ANTHROPIC, "GEMINI_API_KEY", ("GEMINI_API_KEY",), False),
    ("claude_code", "ClaudeCode", _ANTHROPIC, "ANTHROPIC_API_KEY", ("ANTHROPIC_API_KEY",), False),
    ("claude_code", "ClaudeCode", _ANTHROPIC, "ANTHROPIC_AUTH_TOKEN", ("ANTHROPIC_API_KEY",), False),
    ("claude_code", "ClaudeCode", _ANTHROPIC, "CLAUDE_CODE_OAUTH_TOKEN", ("CLAUDE_CODE_OAUTH_TOKEN",), False),
    ("cline.cline", "ClineCli", "anthropic:claude-3-5-sonnet", "ANTHROPIC_API_KEY", ("API_KEY",), False),
    ("cline.cline", "ClineCli", "openai:gpt-4o", "OPENAI_API_KEY", ("API_KEY",), False),
    ("cline.cline", "ClineCli", "cline:test-model", "CLINE_API_KEY", ("API_KEY",), False),
    ("cline.cline", "ClineCli", "gemini:test-model", "GEMINI_API_KEY", ("API_KEY",), False),
    ("cline.cline", "ClineCli", "google:test-model", "GOOGLE_API_KEY", ("API_KEY",), False),
    ("cline.cline", "ClineCli", "openrouter:test-model", "OPENROUTER_API_KEY", ("API_KEY",), False),
    ("cline.cline", "ClineCli", "xai:test-model", "XAI_API_KEY", ("API_KEY",), False),
    ("codex", "Codex", _ANTHROPIC, "OPENAI_API_KEY", ("OPENAI_API_KEY",), False),
    ("copilot_cli", "CopilotCli", _ANTHROPIC, "COPILOT_GITHUB_TOKEN", (("COPILOT_GITHUB_TOKEN", "GH_TOKEN", "GITHUB_TOKEN"),), False),
    ("copilot_cli", "CopilotCli", _ANTHROPIC, "GH_TOKEN", (("COPILOT_GITHUB_TOKEN", "GH_TOKEN", "GITHUB_TOKEN"),), False),
    ("copilot_cli", "CopilotCli", _ANTHROPIC, "GITHUB_TOKEN", (("COPILOT_GITHUB_TOKEN", "GH_TOKEN", "GITHUB_TOKEN"),), False),
    ("cursor_cli", "CursorCli", _ANTHROPIC, "CURSOR_API_KEY", ("CURSOR_API_KEY",), False),
    ("deerflow", "DeerFlow", _ANTHROPIC, "ANTHROPIC_API_KEY", ("ANTHROPIC_API_KEY",), False),
    ("deerflow", "DeerFlow", _ANTHROPIC, "DEEPSEEK_API_KEY", ("DEEPSEEK_API_KEY",), False),
    ("deerflow", "DeerFlow", _ANTHROPIC, "GEMINI_API_KEY", ("GEMINI_API_KEY",), False),
    ("deerflow", "DeerFlow", _ANTHROPIC, "OPENAI_API_KEY", ("OPENAI_API_KEY",), False),
    ("deerflow", "DeerFlow", _ANTHROPIC, "OPENROUTER_API_KEY", ("OPENROUTER_API_KEY",), False),
    ("devin", "Devin", _ANTHROPIC, "WINDSURF_API_KEY", ("WINDSURF_API_KEY",), False),
    ("eve", "Eve", _ANTHROPIC, "OPENAI_API_KEY", ("OPENAI_API_KEY",), False),
    ("gemini_cli", "GeminiCli", "google/gemini-2.5-flash", "GEMINI_API_KEY", ("GEMINI_API_KEY",), False),
    ("gemini_cli", "GeminiCli", "google/gemini-2.5-flash", "GOOGLE_API_KEY", ("GOOGLE_API_KEY",), False),
    ("goose", "Goose", _ANTHROPIC, "ANTHROPIC_API_KEY", ("ANTHROPIC_API_KEY",), False),
    ("goose", "Goose", _OPENAI, "OPENAI_API_KEY", ("OPENAI_API_KEY",), False),
    ("goose", "Goose", "gemini/test-model", "GEMINI_API_KEY", ("GOOGLE_API_KEY",), False),
    ("goose", "Goose", "gemini/test-model", "GOOGLE_API_KEY", ("GOOGLE_API_KEY",), False),
    ("goose", "Goose", "tetrate/test-model", "TETRATE_API_KEY", ("TETRATE_API_KEY",), False),
    ("grok_build", "GrokBuild", "xai/grok-4", "XAI_API_KEY", ("XAI_API_KEY",), False),
    ("grok_build", "GrokBuild", _ANTHROPIC, "ANTHROPIC_API_KEY", ("ANTHROPIC_API_KEY",), False),
    ("grok_build", "GrokBuild", _OPENAI, "OPENAI_API_KEY", ("OPENAI_API_KEY",), False),
    ("grok_build", "GrokBuild", "openrouter/test-model", "OPENROUTER_API_KEY", ("OPENROUTER_API_KEY",), False),
    ("hermes", "Hermes", _ANTHROPIC, "ANTHROPIC_API_KEY", ("ANTHROPIC_API_KEY",), False),
    ("hermes", "Hermes", _ANTHROPIC, "ANTHROPIC_TOKEN", ("ANTHROPIC_TOKEN",), False),
    ("hermes", "Hermes", _ANTHROPIC, "OPENROUTER_API_KEY", ("OPENROUTER_API_KEY",), False),
    ("hermes", "Hermes", _OPENAI, "OPENAI_API_KEY", ("OPENAI_API_KEY",), False),
    ("hermes", "Hermes", _OPENAI, "OPENROUTER_API_KEY", ("OPENROUTER_API_KEY",), False),
    ("hermes", "Hermes", "ai21/test-model", "OPENROUTER_API_KEY", ("OPENROUTER_API_KEY",), False),
    ("hermes", "Hermes", "kimi/test-model", "KIMI_API_KEY", ("KIMI_API_KEY",), False),
    ("hermes", "Hermes", "kimi/test-model", "OPENROUTER_API_KEY", ("OPENROUTER_API_KEY",), False),
    ("hermes", "Hermes", "minimax/test-model", "MINIMAX_API_KEY", ("MINIMAX_API_KEY",), False),
    ("hermes", "Hermes", "minimax/test-model", "OPENROUTER_API_KEY", ("OPENROUTER_API_KEY",), False),
    ("hermes", "Hermes", "minimax-cn/test-model", "MINIMAX_CN_API_KEY", ("MINIMAX_CN_API_KEY",), False),
    ("hermes", "Hermes", "minimax-cn/test-model", "OPENROUTER_API_KEY", ("OPENROUTER_API_KEY",), False),
    ("hermes", "Hermes", "zai/test-model", "GLM_API_KEY", ("GLM_API_KEY",), False),
    ("hermes", "Hermes", "zai/test-model", "OPENROUTER_API_KEY", ("OPENROUTER_API_KEY",), False),
    ("hermes", "Hermes", "zai/test-model", "ZAI_API_KEY", ("ZAI_API_KEY",), False),
    ("hermes", "Hermes", "zai/test-model", "Z_AI_API_KEY", ("Z_AI_API_KEY",), False),
    ("kimi_cli", "KimiCli", "moonshot/kimi-k2", "MOONSHOT_API_KEY", ("HARBOR_KIMI_API_KEY", "MOONSHOT_API_KEY"), False),
    ("kimi_cli", "KimiCli", "anthropic/test-model", "ANTHROPIC_API_KEY", ("ANTHROPIC_API_KEY", "HARBOR_KIMI_API_KEY"), False),
    ("kimi_cli", "KimiCli", "gemini/test-model", "GEMINI_API_KEY", ("GEMINI_API_KEY", "HARBOR_KIMI_API_KEY"), False),
    ("kimi_cli", "KimiCli", "gemini/test-model", "GOOGLE_API_KEY", ("GOOGLE_API_KEY", "HARBOR_KIMI_API_KEY"), False),
    ("kimi_cli", "KimiCli", "kimi/test-model", "KIMI_API_KEY", ("HARBOR_KIMI_API_KEY", "KIMI_API_KEY"), False),
    ("kimi_cli", "KimiCli", "kimi/test-model", "MOONSHOT_API_KEY", ("HARBOR_KIMI_API_KEY", "MOONSHOT_API_KEY"), False),
    ("kimi_cli", "KimiCli", "openai/test-model", "OPENAI_API_KEY", ("HARBOR_KIMI_API_KEY", "OPENAI_API_KEY"), False),
    ("kimi_cli", "KimiCli", "openrouter/test-model", "OPENROUTER_API_KEY", ("HARBOR_KIMI_API_KEY", "OPENROUTER_API_KEY"), False),
    ("langgraph", "LangGraph", _ANTHROPIC, "ANTHROPIC_API_KEY", ("ANTHROPIC_API_KEY",), False),
    ("langgraph", "LangGraph", _ANTHROPIC, "BASETEN_API_KEY", ("BASETEN_API_KEY",), False),
    ("langgraph", "LangGraph", _ANTHROPIC, "FIREWORKS_API_KEY", ("FIREWORKS_API_KEY",), False),
    ("langgraph", "LangGraph", _ANTHROPIC, "GOOGLE_API_KEY", ("GOOGLE_API_KEY",), False),
    ("langgraph", "LangGraph", _ANTHROPIC, "GROQ_API_KEY", ("GROQ_API_KEY",), False),
    ("langgraph", "LangGraph", _ANTHROPIC, "NVIDIA_API_KEY", ("NVIDIA_API_KEY",), False),
    ("langgraph", "LangGraph", _ANTHROPIC, "OLLAMA_API_KEY", ("OLLAMA_API_KEY",), False),
    ("langgraph", "LangGraph", _ANTHROPIC, "OPENAI_API_KEY", ("OPENAI_API_KEY",), False),
    ("langgraph", "LangGraph", _ANTHROPIC, "OPENROUTER_API_KEY", ("OPENROUTER_API_KEY",), False),
    ("langgraph", "LangGraph", _ANTHROPIC, "XAI_API_KEY", ("XAI_API_KEY",), False),
    ("mimo", "MiMo", _ANTHROPIC, "ANTHROPIC_API_KEY", ("ANTHROPIC_API_KEY",), False),
    ("mimo", "MiMo", _OPENAI, "OPENAI_API_KEY", ("OPENAI_API_KEY",), False),
    ("mimo", "MiMo", "azure/test-model", "AZURE_API_KEY", ("AZURE_API_KEY",), False),
    ("mimo", "MiMo", "deepseek/test-model", "DEEPSEEK_API_KEY", ("DEEPSEEK_API_KEY",), False),
    ("mimo", "MiMo", "github-copilot/test-model", "GITHUB_TOKEN", ("GITHUB_TOKEN",), False),
    ("mimo", "MiMo", "google/test-model", "GEMINI_API_KEY", ("GEMINI_API_KEY",), False),
    ("mimo", "MiMo", "google/test-model", "GOOGLE_API_KEY", ("GOOGLE_API_KEY",), False),
    ("mimo", "MiMo", "google/test-model", "GOOGLE_GENERATIVE_AI_API_KEY", ("GOOGLE_GENERATIVE_AI_API_KEY",), False),
    ("mimo", "MiMo", "groq/test-model", "GROQ_API_KEY", ("GROQ_API_KEY",), False),
    ("mimo", "MiMo", "huggingface/test-model", "HF_TOKEN", ("HF_TOKEN",), False),
    ("mimo", "MiMo", "llama/test-model", "LLAMA_API_KEY", ("LLAMA_API_KEY",), False),
    ("mimo", "MiMo", "mistral/test-model", "MISTRAL_API_KEY", ("MISTRAL_API_KEY",), False),
    ("mimo", "MiMo", "opencode/test-model", "OPENCODE_API_KEY", ("OPENCODE_API_KEY",), False),
    ("mimo", "MiMo", "openrouter/test-model", "OPENROUTER_API_KEY", ("OPENROUTER_API_KEY",), False),
    ("mimo", "MiMo", "xai/test-model", "XAI_API_KEY", ("XAI_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", _ANTHROPIC, "ANTHROPIC_API_KEY", ("ANTHROPIC_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", _ANTHROPIC, "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", _OPENAI, "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", _OPENAI, "OPENAI_API_KEY", ("OPENAI_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "ai21/test-model", "AI21_API_KEY", ("AI21_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "ai21/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "aleph_alpha/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "baseten/test-model", "BASETEN_API_KEY", ("BASETEN_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "baseten/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "cerebras/test-model", "CEREBRAS_API_KEY", ("CEREBRAS_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "cerebras/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "cloudflare/test-model", "CLOUDFLARE_API_KEY", ("CLOUDFLARE_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "cloudflare/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "codestral/test-model", "CODESTRAL_API_KEY", ("CODESTRAL_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "codestral/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "cohere/test-model", "COHERE_API_KEY", ("COHERE_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "cohere/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "dashscope/test-model", "DASHSCOPE_API_KEY", ("DASHSCOPE_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "dashscope/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "datarobot/test-model", "DATAROBOT_API_TOKEN", ("DATAROBOT_API_TOKEN",), False),
    ("mini_swe_agent", "MiniSweAgent", "datarobot/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "deepinfra/test-model", "DEEPINFRA_API_KEY", ("DEEPINFRA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "deepinfra/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "deepseek/test-model", "DEEPSEEK_API_KEY", ("DEEPSEEK_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "deepseek/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "featherless_ai/test-model", "FEATHERLESS_AI_API_KEY", ("FEATHERLESS_AI_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "featherless_ai/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "fireworks_ai/test-model", "FIREWORKS_AI_API_KEY", ("FIREWORKS_AI_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "fireworks_ai/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "gemini/test-model", "GEMINI_API_KEY", ("GEMINI_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "gemini/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "groq/test-model", "GROQ_API_KEY", ("GROQ_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "groq/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "huggingface/test-model", "HUGGINGFACE_API_KEY", ("HUGGINGFACE_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "huggingface/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "infinity/test-model", "INFINITY_API_KEY", ("INFINITY_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "infinity/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "mistral/test-model", "MISTRAL_API_KEY", ("MISTRAL_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "mistral/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "moonshot/test-model", "MOONSHOT_API_KEY", ("MOONSHOT_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "moonshot/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "nebius/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "nebius/test-model", "NEBIUS_API_KEY", ("NEBIUS_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "nlp_cloud/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "nlp_cloud/test-model", "NLP_CLOUD_API_KEY", ("NLP_CLOUD_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "novita/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "novita/test-model", "NOVITA_API_KEY", ("NOVITA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "nvidia_nim/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "nvidia_nim/test-model", "NVIDIA_NIM_API_KEY", ("NVIDIA_NIM_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "openrouter/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "openrouter/test-model", "OPENROUTER_API_KEY", ("OPENROUTER_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "perplexity/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "perplexity/test-model", "PERPLEXITYAI_API_KEY", ("PERPLEXITYAI_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "replicate/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "replicate/test-model", "REPLICATE_API_KEY", ("REPLICATE_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "together_ai/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "together_ai/test-model", "TOGETHERAI_API_KEY", ("TOGETHERAI_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "vercel_ai_gateway/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "vercel_ai_gateway/test-model", "VERCEL_AI_GATEWAY_API_KEY", ("VERCEL_AI_GATEWAY_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "volcengine/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "volcengine/test-model", "VOLCENGINE_API_KEY", ("VOLCENGINE_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "voyage/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "voyage/test-model", "VOYAGE_API_KEY", ("VOYAGE_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "xai/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "xai/test-model", "XAI_API_KEY", ("XAI_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "zai/test-model", "MSWEA_API_KEY", ("MSWEA_API_KEY",), False),
    ("mini_swe_agent", "MiniSweAgent", "zai/test-model", "ZAI_API_KEY", ("ZAI_API_KEY",), False),
    ("nemo_agent", "NemoAgent", "meta/llama-3.1-70b-instruct", "NVIDIA_API_KEY", ("NVIDIA_API_KEY",), False),
    ("openclaw", "OpenClaw", _ANTHROPIC, "ANTHROPIC_API_KEY", ("ANTHROPIC_API_KEY",), False),
    ("openclaw", "OpenClaw", _OPENAI, "OPENAI_API_KEY", ("OPENAI_API_KEY",), False),
    ("openclaw", "OpenClaw", "nvidia/test-model", "NVIDIA_API_KEY", ("NVIDIA_API_KEY",), False),
    ("opencode", "OpenCode", _ANTHROPIC, "ANTHROPIC_API_KEY", ("ANTHROPIC_API_KEY",), False),
    ("opencode", "OpenCode", _OPENAI, "OPENAI_API_KEY", ("OPENAI_API_KEY",), False),
    ("opencode", "OpenCode", "azure/test-model", "AZURE_API_KEY", ("AZURE_API_KEY",), False),
    ("opencode", "OpenCode", "deepseek/test-model", "DEEPSEEK_API_KEY", ("DEEPSEEK_API_KEY",), False),
    ("opencode", "OpenCode", "github-copilot/test-model", "GITHUB_TOKEN", ("GITHUB_TOKEN",), False),
    ("opencode", "OpenCode", "google/test-model", "GEMINI_API_KEY", ("GEMINI_API_KEY",), False),
    ("opencode", "OpenCode", "google/test-model", "GOOGLE_API_KEY", ("GOOGLE_API_KEY",), False),
    ("opencode", "OpenCode", "google/test-model", "GOOGLE_GENERATIVE_AI_API_KEY", ("GOOGLE_GENERATIVE_AI_API_KEY",), False),
    ("opencode", "OpenCode", "groq/test-model", "GROQ_API_KEY", ("GROQ_API_KEY",), False),
    ("opencode", "OpenCode", "huggingface/test-model", "HF_TOKEN", ("HF_TOKEN",), False),
    ("opencode", "OpenCode", "llama/test-model", "LLAMA_API_KEY", ("LLAMA_API_KEY",), False),
    ("opencode", "OpenCode", "mistral/test-model", "MISTRAL_API_KEY", ("MISTRAL_API_KEY",), False),
    ("opencode", "OpenCode", "opencode/test-model", "OPENCODE_API_KEY", ("OPENCODE_API_KEY",), False),
    ("opencode", "OpenCode", "openrouter/test-model", "OPENROUTER_API_KEY", ("OPENROUTER_API_KEY",), False),
    ("opencode", "OpenCode", "xai/test-model", "XAI_API_KEY", ("XAI_API_KEY",), False),
    ("openhands", "OpenHands", _ANTHROPIC, "ANTHROPIC_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", _ANTHROPIC, "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", _OPENAI, "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", _OPENAI, "OPENAI_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "ai21/test-model", "AI21_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "ai21/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "aleph_alpha/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "baseten/test-model", "BASETEN_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "baseten/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "cerebras/test-model", "CEREBRAS_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "cerebras/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "cloudflare/test-model", "CLOUDFLARE_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "cloudflare/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "codestral/test-model", "CODESTRAL_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "codestral/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "cohere/test-model", "COHERE_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "cohere/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "dashscope/test-model", "DASHSCOPE_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "dashscope/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "datarobot/test-model", "DATAROBOT_API_TOKEN", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "datarobot/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "deepinfra/test-model", "DEEPINFRA_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "deepinfra/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "deepseek/test-model", "DEEPSEEK_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "deepseek/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "featherless_ai/test-model", "FEATHERLESS_AI_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "featherless_ai/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "fireworks_ai/test-model", "FIREWORKS_AI_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "fireworks_ai/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "gemini/test-model", "GEMINI_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "gemini/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "groq/test-model", "GROQ_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "groq/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "huggingface/test-model", "HUGGINGFACE_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "huggingface/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "infinity/test-model", "INFINITY_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "infinity/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "mistral/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "mistral/test-model", "MISTRAL_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "moonshot/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "moonshot/test-model", "MOONSHOT_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "nebius/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "nebius/test-model", "NEBIUS_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "nlp_cloud/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "nlp_cloud/test-model", "NLP_CLOUD_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "novita/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "novita/test-model", "NOVITA_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "nvidia_nim/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "nvidia_nim/test-model", "NVIDIA_NIM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "openrouter/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "openrouter/test-model", "OPENROUTER_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "perplexity/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "perplexity/test-model", "PERPLEXITYAI_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "replicate/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "replicate/test-model", "REPLICATE_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "together_ai/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "together_ai/test-model", "TOGETHERAI_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "vercel_ai_gateway/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "vercel_ai_gateway/test-model", "VERCEL_AI_GATEWAY_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "volcengine/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "volcengine/test-model", "VOLCENGINE_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "voyage/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "voyage/test-model", "VOYAGE_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "xai/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "xai/test-model", "XAI_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "zai/test-model", "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("openhands", "OpenHands", "zai/test-model", "ZAI_API_KEY", ("LLM_API_KEY",), False),
    ("openhands_sdk", "OpenHandsSDK", _ANTHROPIC, "LLM_API_KEY", ("LLM_API_KEY",), False),
    ("pi", "Pi", _ANTHROPIC, "ANTHROPIC_API_KEY", ("ANTHROPIC_API_KEY",), False),
    ("pi", "Pi", _ANTHROPIC, "ANTHROPIC_OAUTH_TOKEN", ("ANTHROPIC_OAUTH_TOKEN",), False),
    ("pi", "Pi", _OPENAI, "OPENAI_API_KEY", ("OPENAI_API_KEY",), False),
    ("pi", "Pi", "github-copilot/test-model", "GITHUB_TOKEN", ("GITHUB_TOKEN",), False),
    ("pi", "Pi", "google/test-model", "GEMINI_API_KEY", ("GEMINI_API_KEY",), False),
    ("pi", "Pi", "google/test-model", "GOOGLE_API_KEY", ("GOOGLE_API_KEY",), False),
    ("pi", "Pi", "google/test-model", "GOOGLE_GENERATIVE_AI_API_KEY", ("GOOGLE_GENERATIVE_AI_API_KEY",), False),
    ("pi", "Pi", "groq/test-model", "GROQ_API_KEY", ("GROQ_API_KEY",), False),
    ("pi", "Pi", "huggingface/test-model", "HF_TOKEN", ("HF_TOKEN",), False),
    ("pi", "Pi", "mistral/test-model", "MISTRAL_API_KEY", ("MISTRAL_API_KEY",), False),
    ("pi", "Pi", "openrouter/test-model", "OPENROUTER_API_KEY", ("OPENROUTER_API_KEY",), False),
    ("pi", "Pi", "xai/test-model", "XAI_API_KEY", ("XAI_API_KEY",), False),
    ("qwen_code", "QwenCode", _ANTHROPIC, "OPENAI_API_KEY", ("OPENAI_API_KEY",), False),
    ("rovodev_cli", "RovodevCli", _ANTHROPIC, "ROVODEV_USER_API_TOKEN", ("ROVODEV_USER_API_TOKEN",), False),
    ("swe_agent", "SweAgent", _ANTHROPIC, "ANTHROPIC_API_KEY", ("ANTHROPIC_API_KEY",), False),
    ("swe_agent", "SweAgent", _OPENAI, "OPENAI_API_KEY", ("OPENAI_API_KEY",), False),
    ("swe_agent", "SweAgent", "ai21/test-model", "AI21_API_KEY", ("AI21_API_KEY",), False),
    ("swe_agent", "SweAgent", "azure/test-model", "AZURE_API_KEY", ("AZURE_API_KEY",), False),
    ("swe_agent", "SweAgent", "baseten/test-model", "BASETEN_API_KEY", ("BASETEN_API_KEY",), False),
    ("swe_agent", "SweAgent", "cerebras/test-model", "CEREBRAS_API_KEY", ("CEREBRAS_API_KEY",), False),
    ("swe_agent", "SweAgent", "cloudflare/test-model", "CLOUDFLARE_API_KEY", ("CLOUDFLARE_API_KEY",), False),
    ("swe_agent", "SweAgent", "codestral/test-model", "CODESTRAL_API_KEY", ("CODESTRAL_API_KEY",), False),
    ("swe_agent", "SweAgent", "cohere/test-model", "COHERE_API_KEY", ("COHERE_API_KEY",), False),
    ("swe_agent", "SweAgent", "dashscope/test-model", "DASHSCOPE_API_KEY", ("DASHSCOPE_API_KEY",), False),
    ("swe_agent", "SweAgent", "datarobot/test-model", "DATAROBOT_API_TOKEN", ("DATAROBOT_API_TOKEN",), False),
    ("swe_agent", "SweAgent", "deepinfra/test-model", "DEEPINFRA_API_KEY", ("DEEPINFRA_API_KEY",), False),
    ("swe_agent", "SweAgent", "deepseek/test-model", "DEEPSEEK_API_KEY", ("DEEPSEEK_API_KEY",), False),
    ("swe_agent", "SweAgent", "featherless_ai/test-model", "FEATHERLESS_AI_API_KEY", ("FEATHERLESS_AI_API_KEY",), False),
    ("swe_agent", "SweAgent", "fireworks_ai/test-model", "FIREWORKS_AI_API_KEY", ("FIREWORKS_AI_API_KEY",), False),
    ("swe_agent", "SweAgent", "gemini/test-model", "GEMINI_API_KEY", ("GEMINI_API_KEY",), False),
    ("swe_agent", "SweAgent", "groq/test-model", "GROQ_API_KEY", ("GROQ_API_KEY",), False),
    ("swe_agent", "SweAgent", "huggingface/test-model", "HUGGINGFACE_API_KEY", ("HUGGINGFACE_API_KEY",), False),
    ("swe_agent", "SweAgent", "infinity/test-model", "INFINITY_API_KEY", ("INFINITY_API_KEY",), False),
    ("swe_agent", "SweAgent", "mistral/test-model", "MISTRAL_API_KEY", ("MISTRAL_API_KEY",), False),
    ("swe_agent", "SweAgent", "moonshot/test-model", "MOONSHOT_API_KEY", ("MOONSHOT_API_KEY",), False),
    ("swe_agent", "SweAgent", "nebius/test-model", "NEBIUS_API_KEY", ("NEBIUS_API_KEY",), False),
    ("swe_agent", "SweAgent", "nlp_cloud/test-model", "NLP_CLOUD_API_KEY", ("NLP_CLOUD_API_KEY",), False),
    ("swe_agent", "SweAgent", "novita/test-model", "NOVITA_API_KEY", ("NOVITA_API_KEY",), False),
    ("swe_agent", "SweAgent", "nvidia_nim/test-model", "NVIDIA_NIM_API_KEY", ("NVIDIA_NIM_API_KEY",), False),
    ("swe_agent", "SweAgent", "openrouter/test-model", "OPENROUTER_API_KEY", ("OPENROUTER_API_KEY",), False),
    ("swe_agent", "SweAgent", "perplexity/test-model", "PERPLEXITYAI_API_KEY", ("PERPLEXITYAI_API_KEY",), False),
    ("swe_agent", "SweAgent", "replicate/test-model", "REPLICATE_API_KEY", ("REPLICATE_API_KEY",), False),
    ("swe_agent", "SweAgent", "together/test-model", "TOGETHER_API_KEY", ("TOGETHER_API_KEY",), False),
    ("swe_agent", "SweAgent", "together_ai/test-model", "TOGETHERAI_API_KEY", ("TOGETHERAI_API_KEY",), False),
    ("swe_agent", "SweAgent", "together_ai/test-model", "TOGETHER_API_KEY", ("TOGETHER_API_KEY",), False),
    ("swe_agent", "SweAgent", "vercel_ai_gateway/test-model", "VERCEL_AI_GATEWAY_API_KEY", ("VERCEL_AI_GATEWAY_API_KEY",), False),
    ("swe_agent", "SweAgent", "volcengine/test-model", "VOLCENGINE_API_KEY", ("VOLCENGINE_API_KEY",), False),
    ("swe_agent", "SweAgent", "voyage/test-model", "VOYAGE_API_KEY", ("VOYAGE_API_KEY",), False),
    ("swe_agent", "SweAgent", "xai/test-model", "XAI_API_KEY", ("XAI_API_KEY",), False),
    ("swe_agent", "SweAgent", "zai/test-model", "ZAI_API_KEY", ("ZAI_API_KEY",), False),
    ("trae_agent", "TraeAgent", _ANTHROPIC, "ANTHROPIC_API_KEY", ("ANTHROPIC_API_KEY",), False),
    ("trae_agent", "TraeAgent", _OPENAI, "OPENAI_API_KEY", ("OPENAI_API_KEY",), False),
    ("trae_agent", "TraeAgent", "azure/test-model", "AZURE_API_KEY", ("AZURE_API_KEY",), False),
    ("trae_agent", "TraeAgent", "doubao/test-model", "DOUBAO_API_KEY", ("DOUBAO_API_KEY",), False),
    ("trae_agent", "TraeAgent", "gemini/test-model", "GEMINI_API_KEY", ("GOOGLE_API_KEY",), False),
    ("trae_agent", "TraeAgent", "gemini/test-model", "GOOGLE_API_KEY", ("GOOGLE_API_KEY",), False),
    ("trae_agent", "TraeAgent", "ollama/test-model", "OLLAMA_API_KEY", ("OLLAMA_API_KEY",), False),
    ("trae_agent", "TraeAgent", "openrouter/test-model", "OPENROUTER_API_KEY", ("OPENROUTER_API_KEY",), False),
    ("vibe", "Vibe", "mistral/devstral-medium", "MISTRAL_API_KEY", ("MISTRAL_API_KEY",), False),
]
# Adapters that take their key only from the run's own values: a standing key
# alone does not launch them, so where the key goes is read from a per-run drive.
_PER_RUN_ONLY = [
    ("cortex_code", "CortexCode", _ANTHROPIC, "SNOWFLAKE_PAT", ("SNOWFLAKE_PAT",), False),
]
# Other values an adapter needs set alongside its key.
_EXTRA = {
    "RovodevCli": {"ROVODEV_USER_EMAIL": "dev@example.test"},
    "CortexCode": {"SNOWFLAKE_ACCOUNT": "acct", "SNOWFLAKE_USER": "user"},
}
# Keys the CLI receives only on a routing setting (Claude Code on Bedrock,
# Gemini CLI on Vertex AI), with that setting as the row's own extra values.
# Kept by hand: the scan seeds a key alone, so it never turns these routes on.
_ROUTED = [
    ("claude_code", "ClaudeCode", _ANTHROPIC, "AWS_BEARER_TOKEN_BEDROCK", ("AWS_BEARER_TOKEN_BEDROCK",), False, {}),
    ("claude_code", "ClaudeCode", _ANTHROPIC, "AWS_ACCESS_KEY_ID", ("AWS_ACCESS_KEY_ID",), False, {"CLAUDE_CODE_USE_BEDROCK": "1"}),
    ("claude_code", "ClaudeCode", _ANTHROPIC, "AWS_SECRET_ACCESS_KEY", ("AWS_SECRET_ACCESS_KEY",), False, {"CLAUDE_CODE_USE_BEDROCK": "1"}),
    ("claude_code", "ClaudeCode", _ANTHROPIC, "AWS_SESSION_TOKEN", ("AWS_SESSION_TOKEN",), False, {"CLAUDE_CODE_USE_BEDROCK": "1"}),
    ("gemini_cli", "GeminiCli", "google/gemini-2.5-flash", "GOOGLE_APPLICATION_CREDENTIALS", ("GOOGLE_APPLICATION_CREDENTIALS",), False, {"GOOGLE_GENAI_USE_VERTEXAI": "true", "GOOGLE_CLOUD_PROJECT": "vertex-project"}),
    ("gemini_cli", "GeminiCli", "google/gemini-2.5-flash", "GOOGLE_CLOUD_PROJECT", ("GOOGLE_CLOUD_PROJECT",), False, {"GOOGLE_GENAI_USE_VERTEXAI": "true"}),
]
# Settings that pick a credential file the adapter uploads to the sandbox: a
# path, or a flag (ending with the file's place under the home folder) that
# picks the default file.
_CREDENTIAL_FILES = [
    ("codex", "Codex", _ANTHROPIC, "CODEX_AUTH_JSON_PATH", None),
    ("codex", "Codex", _ANTHROPIC, "CODEX_FORCE_AUTH_JSON", ".codex/auth.json"),
    ("gemini_cli", "GeminiCli", "google/gemini-2.5-flash", "GEMINI_OAUTH_CREDS_PATH", None),
    ("gemini_cli", "GeminiCli", "google/gemini-2.5-flash", "GEMINI_FORCE_OAUTH", ".gemini/oauth_creds.json"),
    ("antigravity_cli", "AntigravityCli", _ANTHROPIC, "AGY_AUTH_JSON_PATH", None),
    ("antigravity_cli", "AntigravityCli", _ANTHROPIC, "AGY_FORCE_AUTH_JSON", ".gemini/antigravity-cli/antigravity-oauth-token"),
]
# Every adapter, model, credential variable and endpoint variable where the
# adapter passes a configured endpoint on to the CLI. Each row ends with where
# the CLI receives a standing endpoint, as above (empty where no env name
# carries it).
_ENDPOINT_ADAPTERS = [
    ("aider", "Aider", _ANTHROPIC, "ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", (), False),
    ("aider", "Aider", _OPENAI, "OPENAI_API_KEY", "OPENAI_API_BASE", (), False),
    ("aider", "Aider", _OPENAI, "OPENAI_API_KEY", "OPENAI_BASE_URL", (), False),
    ("claude_code", "ClaudeCode", _ANTHROPIC, "ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", ("ANTHROPIC_BASE_URL",), False),
    ("codex", "Codex", _ANTHROPIC, "OPENAI_API_KEY", "OPENAI_API_BASE", (), False),
    ("codex", "Codex", _ANTHROPIC, "OPENAI_API_KEY", "OPENAI_BASE_URL", ("OPENAI_BASE_URL",), False),
    ("eve", "Eve", _ANTHROPIC, "OPENAI_API_KEY", "OPENAI_BASE_URL", ("OPENAI_BASE_URL",), False),
    ("gemini_cli", "GeminiCli", "google/gemini-2.5-flash", "GEMINI_API_KEY", "GOOGLE_BASE_URL", (), False),
    ("gemini_cli", "GeminiCli", "google/gemini-2.5-flash", "GEMINI_API_KEY", "GOOGLE_GEMINI_BASE_URL", (), False),
    ("goose", "Goose", _ANTHROPIC, "ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", (), False),
    ("goose", "Goose", _OPENAI, "OPENAI_API_KEY", "OPENAI_API_BASE", (), False),
    ("goose", "Goose", _OPENAI, "OPENAI_API_KEY", "OPENAI_BASE_URL", (), False),
    ("goose", "Goose", "gemini/test-model", "GEMINI_API_KEY", "GOOGLE_BASE_URL", (), False),
    ("hermes", "Hermes", _OPENAI, "OPENAI_API_KEY", "OPENAI_BASE_URL", ("OPENAI_BASE_URL",), False),
    ("mimo", "MiMo", _ANTHROPIC, "ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", (), True),
    ("mimo", "MiMo", _OPENAI, "OPENAI_API_KEY", "OPENAI_API_BASE", (), False),
    ("mimo", "MiMo", _OPENAI, "OPENAI_API_KEY", "OPENAI_BASE_URL", ("OPENAI_BASE_URL",), False),
    ("mimo", "MiMo", "azure/test-model", "AZURE_API_KEY", "AZURE_API_BASE", (), False),
    ("mimo", "MiMo", "azure/test-model", "AZURE_API_KEY", "AZURE_BASE_URL", (), True),
    ("mimo", "MiMo", "deepseek/test-model", "DEEPSEEK_API_KEY", "DEEPSEEK_BASE_URL", (), True),
    ("mimo", "MiMo", "doubao/test-model", "DOUBAO_API_KEY", "DOUBAO_BASE_URL", (), True),
    ("mimo", "MiMo", "gemini/test-model", "GEMINI_API_KEY", "GOOGLE_BASE_URL", (), False),
    ("mimo", "MiMo", "groq/test-model", "GROQ_API_KEY", "GROQ_BASE_URL", (), True),
    ("mimo", "MiMo", "kimi/test-model", "KIMI_API_KEY", "KIMI_BASE_URL", (), True),
    ("mimo", "MiMo", "mistral/test-model", "MISTRAL_API_KEY", "MISTRAL_BASE_URL", (), True),
    ("mimo", "MiMo", "nvidia/test-model", "NVIDIA_API_KEY", "NVIDIA_BASE_URL", (), True),
    ("mimo", "MiMo", "ollama/test-model", "OLLAMA_API_KEY", "OLLAMA_API_BASE", (), False),
    ("mimo", "MiMo", "ollama/test-model", "OLLAMA_API_KEY", "OLLAMA_BASE_URL", (), True),
    ("mimo", "MiMo", "openrouter/test-model", "OPENROUTER_API_KEY", "OPENROUTER_BASE_URL", (), True),
    ("mimo", "MiMo", "xai/test-model", "XAI_API_KEY", "XAI_BASE_URL", (), True),
    ("mini_swe_agent", "MiniSweAgent", _ANTHROPIC, "ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", (), False),
    ("mini_swe_agent", "MiniSweAgent", _ANTHROPIC, "ANTHROPIC_API_KEY", "OPENAI_API_BASE", ("OPENAI_API_BASE", "OPENAI_BASE_URL"), False),
    ("mini_swe_agent", "MiniSweAgent", _ANTHROPIC, "ANTHROPIC_API_KEY", "OPENAI_BASE_URL", ("OPENAI_API_BASE", "OPENAI_BASE_URL"), False),
    ("mini_swe_agent", "MiniSweAgent", _OPENAI, "MSWEA_API_KEY", "OPENAI_API_BASE", ("OPENAI_API_BASE", "OPENAI_BASE_URL"), False),
    ("mini_swe_agent", "MiniSweAgent", _OPENAI, "MSWEA_API_KEY", "OPENAI_BASE_URL", ("OPENAI_API_BASE", "OPENAI_BASE_URL"), False),
    ("mini_swe_agent", "MiniSweAgent", "deepseek/test-model", "DEEPSEEK_API_KEY", "DEEPSEEK_BASE_URL", (), False),
    ("mini_swe_agent", "MiniSweAgent", "deepseek/test-model", "DEEPSEEK_API_KEY", "OPENAI_API_BASE", ("OPENAI_API_BASE", "OPENAI_BASE_URL"), False),
    ("mini_swe_agent", "MiniSweAgent", "deepseek/test-model", "DEEPSEEK_API_KEY", "OPENAI_BASE_URL", ("OPENAI_API_BASE", "OPENAI_BASE_URL"), False),
    ("mini_swe_agent", "MiniSweAgent", "dynamo/test-model", "MSWEA_API_KEY", "DYNAMO_BASE_URL", (), False),
    ("mini_swe_agent", "MiniSweAgent", "dynamo/test-model", "MSWEA_API_KEY", "OPENAI_API_BASE", ("OPENAI_API_BASE", "OPENAI_BASE_URL"), False),
    ("mini_swe_agent", "MiniSweAgent", "dynamo/test-model", "MSWEA_API_KEY", "OPENAI_BASE_URL", ("OPENAI_API_BASE", "OPENAI_BASE_URL"), False),
    ("mini_swe_agent", "MiniSweAgent", "gemini/test-model", "GEMINI_API_KEY", "GOOGLE_BASE_URL", (), False),
    ("mini_swe_agent", "MiniSweAgent", "gemini/test-model", "GEMINI_API_KEY", "OPENAI_API_BASE", ("OPENAI_API_BASE", "OPENAI_BASE_URL"), False),
    ("mini_swe_agent", "MiniSweAgent", "gemini/test-model", "GEMINI_API_KEY", "OPENAI_BASE_URL", ("OPENAI_API_BASE", "OPENAI_BASE_URL"), False),
    ("mini_swe_agent", "MiniSweAgent", "groq/test-model", "GROQ_API_KEY", "GROQ_BASE_URL", (), False),
    ("mini_swe_agent", "MiniSweAgent", "groq/test-model", "GROQ_API_KEY", "OPENAI_API_BASE", ("OPENAI_API_BASE", "OPENAI_BASE_URL"), False),
    ("mini_swe_agent", "MiniSweAgent", "groq/test-model", "GROQ_API_KEY", "OPENAI_BASE_URL", ("OPENAI_API_BASE", "OPENAI_BASE_URL"), False),
    ("mini_swe_agent", "MiniSweAgent", "litellm/test-model", "MSWEA_API_KEY", "LITELLM_BASE_URL", (), False),
    ("mini_swe_agent", "MiniSweAgent", "litellm/test-model", "MSWEA_API_KEY", "OPENAI_API_BASE", ("OPENAI_API_BASE", "OPENAI_BASE_URL"), False),
    ("mini_swe_agent", "MiniSweAgent", "litellm/test-model", "MSWEA_API_KEY", "OPENAI_BASE_URL", ("OPENAI_API_BASE", "OPENAI_BASE_URL"), False),
    ("mini_swe_agent", "MiniSweAgent", "mistral/test-model", "MISTRAL_API_KEY", "MISTRAL_BASE_URL", (), False),
    ("mini_swe_agent", "MiniSweAgent", "mistral/test-model", "MISTRAL_API_KEY", "OPENAI_API_BASE", ("OPENAI_API_BASE", "OPENAI_BASE_URL"), False),
    ("mini_swe_agent", "MiniSweAgent", "mistral/test-model", "MISTRAL_API_KEY", "OPENAI_BASE_URL", ("OPENAI_API_BASE", "OPENAI_BASE_URL"), False),
    ("mini_swe_agent", "MiniSweAgent", "nvidia/test-model", "MSWEA_API_KEY", "NVIDIA_BASE_URL", (), False),
    ("mini_swe_agent", "MiniSweAgent", "nvidia/test-model", "MSWEA_API_KEY", "OPENAI_API_BASE", ("OPENAI_API_BASE", "OPENAI_BASE_URL"), False),
    ("mini_swe_agent", "MiniSweAgent", "nvidia/test-model", "MSWEA_API_KEY", "OPENAI_BASE_URL", ("OPENAI_API_BASE", "OPENAI_BASE_URL"), False),
    ("mini_swe_agent", "MiniSweAgent", "ollama/test-model", "MSWEA_API_KEY", "OLLAMA_API_BASE", (), False),
    ("mini_swe_agent", "MiniSweAgent", "ollama/test-model", "MSWEA_API_KEY", "OLLAMA_BASE_URL", (), False),
    ("mini_swe_agent", "MiniSweAgent", "ollama/test-model", "MSWEA_API_KEY", "OPENAI_API_BASE", ("OPENAI_API_BASE", "OPENAI_BASE_URL"), False),
    ("mini_swe_agent", "MiniSweAgent", "ollama/test-model", "MSWEA_API_KEY", "OPENAI_BASE_URL", ("OPENAI_API_BASE", "OPENAI_BASE_URL"), False),
    ("mini_swe_agent", "MiniSweAgent", "openrouter/test-model", "MSWEA_API_KEY", "OPENAI_API_BASE", ("OPENAI_API_BASE", "OPENAI_BASE_URL"), False),
    ("mini_swe_agent", "MiniSweAgent", "openrouter/test-model", "MSWEA_API_KEY", "OPENAI_BASE_URL", ("OPENAI_API_BASE", "OPENAI_BASE_URL"), False),
    ("mini_swe_agent", "MiniSweAgent", "openrouter/test-model", "MSWEA_API_KEY", "OPENROUTER_BASE_URL", (), False),
    ("mini_swe_agent", "MiniSweAgent", "xai/test-model", "MSWEA_API_KEY", "OPENAI_API_BASE", ("OPENAI_API_BASE", "OPENAI_BASE_URL"), False),
    ("mini_swe_agent", "MiniSweAgent", "xai/test-model", "MSWEA_API_KEY", "OPENAI_BASE_URL", ("OPENAI_API_BASE", "OPENAI_BASE_URL"), False),
    ("mini_swe_agent", "MiniSweAgent", "xai/test-model", "MSWEA_API_KEY", "XAI_BASE_URL", (), False),
    ("nemo_agent", "NemoAgent", "meta/llama-3.1-70b-instruct", "NVIDIA_API_KEY", "NVIDIA_BASE_URL", ("NVIDIA_BASE_URL",), False),
    ("openclaw", "OpenClaw", _ANTHROPIC, "ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", ("ANTHROPIC_BASE_URL",), False),
    ("openclaw", "OpenClaw", _OPENAI, "OPENAI_API_KEY", "OPENAI_BASE_URL", ("OPENAI_BASE_URL",), False),
    ("openclaw", "OpenClaw", "nvidia/test-model", "NVIDIA_API_KEY", "NVIDIA_BASE_URL", ("NVIDIA_BASE_URL",), False),
    ("opencode", "OpenCode", _ANTHROPIC, "ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", ("ANTHROPIC_BASE_URL",), False),
    ("opencode", "OpenCode", _OPENAI, "OPENAI_API_KEY", "OPENAI_API_BASE", (), False),
    ("opencode", "OpenCode", _OPENAI, "OPENAI_API_KEY", "OPENAI_BASE_URL", ("OPENAI_BASE_URL",), False),
    ("opencode", "OpenCode", "azure/test-model", "AZURE_API_KEY", "AZURE_API_BASE", (), False),
    ("opencode", "OpenCode", "azure/test-model", "AZURE_API_KEY", "AZURE_BASE_URL", (), False),
    ("opencode", "OpenCode", "deepseek/test-model", "DEEPSEEK_API_KEY", "DEEPSEEK_BASE_URL", (), False),
    ("opencode", "OpenCode", "doubao/test-model", "DOUBAO_API_KEY", "DOUBAO_BASE_URL", (), False),
    ("opencode", "OpenCode", "gemini/test-model", "GEMINI_API_KEY", "GOOGLE_BASE_URL", (), False),
    ("opencode", "OpenCode", "groq/test-model", "GROQ_API_KEY", "GROQ_BASE_URL", (), False),
    ("opencode", "OpenCode", "kimi/test-model", "KIMI_API_KEY", "KIMI_BASE_URL", (), False),
    ("opencode", "OpenCode", "mistral/test-model", "MISTRAL_API_KEY", "MISTRAL_BASE_URL", (), False),
    ("opencode", "OpenCode", "nvidia/test-model", "NVIDIA_API_KEY", "NVIDIA_BASE_URL", (), False),
    ("opencode", "OpenCode", "ollama/test-model", "OLLAMA_API_KEY", "OLLAMA_API_BASE", (), False),
    ("opencode", "OpenCode", "ollama/test-model", "OLLAMA_API_KEY", "OLLAMA_BASE_URL", (), False),
    ("opencode", "OpenCode", "openrouter/test-model", "OPENROUTER_API_KEY", "OPENROUTER_BASE_URL", (), False),
    ("opencode", "OpenCode", "xai/test-model", "XAI_API_KEY", "XAI_BASE_URL", (), False),
    ("openhands", "OpenHands", _ANTHROPIC, "ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", (), False),
    ("openhands", "OpenHands", _ANTHROPIC, "ANTHROPIC_API_KEY", "AZURE_API_BASE", (), False),
    ("openhands", "OpenHands", _ANTHROPIC, "ANTHROPIC_API_KEY", "HOSTED_VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", _ANTHROPIC, "ANTHROPIC_API_KEY", "LLM_BASE_URL", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", _ANTHROPIC, "ANTHROPIC_API_KEY", "OPENAI_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", _ANTHROPIC, "ANTHROPIC_API_KEY", "VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", _OPENAI, "LLM_API_KEY", "AZURE_API_BASE", (), False),
    ("openhands", "OpenHands", _OPENAI, "LLM_API_KEY", "HOSTED_VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", _OPENAI, "LLM_API_KEY", "LLM_BASE_URL", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", _OPENAI, "LLM_API_KEY", "OPENAI_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", _OPENAI, "LLM_API_KEY", "OPENAI_BASE_URL", (), False),
    ("openhands", "OpenHands", _OPENAI, "LLM_API_KEY", "VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "ai21/test-model", "AI21_API_KEY", "AZURE_API_BASE", (), False),
    ("openhands", "OpenHands", "ai21/test-model", "AI21_API_KEY", "HOSTED_VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "ai21/test-model", "AI21_API_KEY", "LLM_BASE_URL", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "ai21/test-model", "AI21_API_KEY", "OPENAI_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "ai21/test-model", "AI21_API_KEY", "VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "deepseek/test-model", "DEEPSEEK_API_KEY", "AZURE_API_BASE", (), False),
    ("openhands", "OpenHands", "deepseek/test-model", "DEEPSEEK_API_KEY", "DEEPSEEK_BASE_URL", (), False),
    ("openhands", "OpenHands", "deepseek/test-model", "DEEPSEEK_API_KEY", "HOSTED_VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "deepseek/test-model", "DEEPSEEK_API_KEY", "LLM_BASE_URL", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "deepseek/test-model", "DEEPSEEK_API_KEY", "OPENAI_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "deepseek/test-model", "DEEPSEEK_API_KEY", "VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "dynamo/test-model", "LLM_API_KEY", "AZURE_API_BASE", (), False),
    ("openhands", "OpenHands", "dynamo/test-model", "LLM_API_KEY", "DYNAMO_BASE_URL", (), False),
    ("openhands", "OpenHands", "dynamo/test-model", "LLM_API_KEY", "HOSTED_VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "dynamo/test-model", "LLM_API_KEY", "LLM_BASE_URL", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "dynamo/test-model", "LLM_API_KEY", "OPENAI_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "dynamo/test-model", "LLM_API_KEY", "VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "gemini/test-model", "GEMINI_API_KEY", "AZURE_API_BASE", (), False),
    ("openhands", "OpenHands", "gemini/test-model", "GEMINI_API_KEY", "GOOGLE_BASE_URL", (), False),
    ("openhands", "OpenHands", "gemini/test-model", "GEMINI_API_KEY", "HOSTED_VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "gemini/test-model", "GEMINI_API_KEY", "LLM_BASE_URL", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "gemini/test-model", "GEMINI_API_KEY", "OPENAI_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "gemini/test-model", "GEMINI_API_KEY", "VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "groq/test-model", "GROQ_API_KEY", "AZURE_API_BASE", (), False),
    ("openhands", "OpenHands", "groq/test-model", "GROQ_API_KEY", "GROQ_BASE_URL", (), False),
    ("openhands", "OpenHands", "groq/test-model", "GROQ_API_KEY", "HOSTED_VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "groq/test-model", "GROQ_API_KEY", "LLM_BASE_URL", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "groq/test-model", "GROQ_API_KEY", "OPENAI_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "groq/test-model", "GROQ_API_KEY", "VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "litellm/test-model", "LLM_API_KEY", "AZURE_API_BASE", (), False),
    ("openhands", "OpenHands", "litellm/test-model", "LLM_API_KEY", "HOSTED_VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "litellm/test-model", "LLM_API_KEY", "LITELLM_BASE_URL", (), False),
    ("openhands", "OpenHands", "litellm/test-model", "LLM_API_KEY", "LLM_BASE_URL", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "litellm/test-model", "LLM_API_KEY", "OPENAI_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "litellm/test-model", "LLM_API_KEY", "VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "mistral/test-model", "LLM_API_KEY", "AZURE_API_BASE", (), False),
    ("openhands", "OpenHands", "mistral/test-model", "LLM_API_KEY", "HOSTED_VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "mistral/test-model", "LLM_API_KEY", "LLM_BASE_URL", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "mistral/test-model", "LLM_API_KEY", "MISTRAL_BASE_URL", (), False),
    ("openhands", "OpenHands", "mistral/test-model", "LLM_API_KEY", "OPENAI_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "mistral/test-model", "LLM_API_KEY", "VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "nvidia/test-model", "LLM_API_KEY", "AZURE_API_BASE", (), False),
    ("openhands", "OpenHands", "nvidia/test-model", "LLM_API_KEY", "HOSTED_VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "nvidia/test-model", "LLM_API_KEY", "LLM_BASE_URL", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "nvidia/test-model", "LLM_API_KEY", "NVIDIA_BASE_URL", (), False),
    ("openhands", "OpenHands", "nvidia/test-model", "LLM_API_KEY", "OPENAI_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "nvidia/test-model", "LLM_API_KEY", "VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "ollama/test-model", "LLM_API_KEY", "AZURE_API_BASE", (), False),
    ("openhands", "OpenHands", "ollama/test-model", "LLM_API_KEY", "HOSTED_VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "ollama/test-model", "LLM_API_KEY", "LLM_BASE_URL", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "ollama/test-model", "LLM_API_KEY", "OLLAMA_API_BASE", (), False),
    ("openhands", "OpenHands", "ollama/test-model", "LLM_API_KEY", "OLLAMA_BASE_URL", (), False),
    ("openhands", "OpenHands", "ollama/test-model", "LLM_API_KEY", "OPENAI_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "ollama/test-model", "LLM_API_KEY", "VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "openrouter/test-model", "LLM_API_KEY", "AZURE_API_BASE", (), False),
    ("openhands", "OpenHands", "openrouter/test-model", "LLM_API_KEY", "HOSTED_VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "openrouter/test-model", "LLM_API_KEY", "LLM_BASE_URL", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "openrouter/test-model", "LLM_API_KEY", "OPENAI_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "openrouter/test-model", "LLM_API_KEY", "OPENROUTER_BASE_URL", (), False),
    ("openhands", "OpenHands", "openrouter/test-model", "LLM_API_KEY", "VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "xai/test-model", "LLM_API_KEY", "AZURE_API_BASE", (), False),
    ("openhands", "OpenHands", "xai/test-model", "LLM_API_KEY", "HOSTED_VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "xai/test-model", "LLM_API_KEY", "LLM_BASE_URL", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "xai/test-model", "LLM_API_KEY", "OPENAI_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "xai/test-model", "LLM_API_KEY", "VLLM_API_BASE", ("LLM_BASE_URL",), False),
    ("openhands", "OpenHands", "xai/test-model", "LLM_API_KEY", "XAI_BASE_URL", (), False),
    ("openhands_sdk", "OpenHandsSDK", _ANTHROPIC, "LLM_API_KEY", "LLM_BASE_URL", ("LLM_BASE_URL",), False),
    ("pi", "Pi", _ANTHROPIC, "ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", ("ANTHROPIC_BASE_URL",), False),
    ("pi", "Pi", _OPENAI, "OPENAI_API_KEY", "OPENAI_API_BASE", (), False),
    ("pi", "Pi", _OPENAI, "OPENAI_API_KEY", "OPENAI_BASE_URL", ("OPENAI_BASE_URL",), False),
    ("pi", "Pi", "azure/test-model", "AZURE_API_KEY", "AZURE_API_BASE", (), False),
    ("pi", "Pi", "azure/test-model", "AZURE_API_KEY", "AZURE_BASE_URL", (), False),
    ("pi", "Pi", "deepseek/test-model", "DEEPSEEK_API_KEY", "DEEPSEEK_BASE_URL", (), False),
    ("pi", "Pi", "doubao/test-model", "DOUBAO_API_KEY", "DOUBAO_BASE_URL", (), False),
    ("pi", "Pi", "gemini/test-model", "GEMINI_API_KEY", "GOOGLE_BASE_URL", (), False),
    ("pi", "Pi", "groq/test-model", "GROQ_API_KEY", "GROQ_BASE_URL", (), False),
    ("pi", "Pi", "kimi/test-model", "KIMI_API_KEY", "KIMI_BASE_URL", (), False),
    ("pi", "Pi", "mistral/test-model", "MISTRAL_API_KEY", "MISTRAL_BASE_URL", (), False),
    ("pi", "Pi", "nvidia/test-model", "NVIDIA_API_KEY", "NVIDIA_BASE_URL", (), False),
    ("pi", "Pi", "ollama/test-model", "OLLAMA_API_KEY", "OLLAMA_API_BASE", (), False),
    ("pi", "Pi", "ollama/test-model", "OLLAMA_API_KEY", "OLLAMA_BASE_URL", (), False),
    ("pi", "Pi", "openrouter/test-model", "OPENROUTER_API_KEY", "OPENROUTER_BASE_URL", (), False),
    ("pi", "Pi", "xai/test-model", "XAI_API_KEY", "XAI_BASE_URL", (), False),
    ("qwen_code", "QwenCode", _ANTHROPIC, "OPENAI_API_KEY", "OPENAI_API_BASE", (), False),
    ("qwen_code", "QwenCode", _ANTHROPIC, "OPENAI_API_KEY", "OPENAI_BASE_URL", ("OPENAI_BASE_URL",), False),
    ("swe_agent", "SweAgent", _ANTHROPIC, "ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", (), False),
    ("swe_agent", "SweAgent", _OPENAI, "OPENAI_API_KEY", "OPENAI_API_BASE", (), False),
    ("swe_agent", "SweAgent", _OPENAI, "OPENAI_API_KEY", "OPENAI_BASE_URL", ("OPENAI_BASE_URL",), False),
    ("swe_agent", "SweAgent", "azure/test-model", "AZURE_API_KEY", "AZURE_API_BASE", ("AZURE_API_BASE",), False),
    ("swe_agent", "SweAgent", "azure/test-model", "AZURE_API_KEY", "AZURE_BASE_URL", (), False),
    ("swe_agent", "SweAgent", "deepseek/test-model", "DEEPSEEK_API_KEY", "DEEPSEEK_BASE_URL", (), False),
    ("swe_agent", "SweAgent", "doubao/test-model", "DOUBAO_API_KEY", "DOUBAO_BASE_URL", (), False),
    ("swe_agent", "SweAgent", "gemini/test-model", "GEMINI_API_KEY", "GOOGLE_BASE_URL", (), False),
    ("swe_agent", "SweAgent", "groq/test-model", "GROQ_API_KEY", "GROQ_BASE_URL", (), False),
    ("swe_agent", "SweAgent", "kimi/test-model", "KIMI_API_KEY", "KIMI_BASE_URL", (), False),
    ("swe_agent", "SweAgent", "mistral/test-model", "MISTRAL_API_KEY", "MISTRAL_BASE_URL", (), False),
    ("swe_agent", "SweAgent", "nvidia/test-model", "NVIDIA_API_KEY", "NVIDIA_BASE_URL", (), False),
    ("swe_agent", "SweAgent", "ollama/test-model", "OLLAMA_API_KEY", "OLLAMA_API_BASE", ("OLLAMA_API_BASE",), False),
    ("swe_agent", "SweAgent", "ollama/test-model", "OLLAMA_API_KEY", "OLLAMA_BASE_URL", (), False),
    ("swe_agent", "SweAgent", "openrouter/test-model", "OPENROUTER_API_KEY", "OPENROUTER_BASE_URL", (), False),
    ("swe_agent", "SweAgent", "xai/test-model", "XAI_API_KEY", "XAI_BASE_URL", (), False),
    ("trae_agent", "TraeAgent", _ANTHROPIC, "ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", ("ANTHROPIC_BASE_URL",), False),
    ("trae_agent", "TraeAgent", _OPENAI, "OPENAI_API_KEY", "OPENAI_API_BASE", (), False),
    ("trae_agent", "TraeAgent", _OPENAI, "OPENAI_API_KEY", "OPENAI_BASE_URL", ("OPENAI_BASE_URL",), False),
    ("trae_agent", "TraeAgent", "azure/test-model", "AZURE_API_KEY", "AZURE_API_BASE", (), False),
    ("trae_agent", "TraeAgent", "azure/test-model", "AZURE_API_KEY", "AZURE_BASE_URL", ("AZURE_BASE_URL",), False),
    ("trae_agent", "TraeAgent", "doubao/test-model", "DOUBAO_API_KEY", "DOUBAO_BASE_URL", ("DOUBAO_BASE_URL",), False),
    ("trae_agent", "TraeAgent", "gemini/test-model", "GEMINI_API_KEY", "GOOGLE_BASE_URL", ("GOOGLE_BASE_URL",), False),
    ("trae_agent", "TraeAgent", "ollama/test-model", "OLLAMA_API_KEY", "OLLAMA_API_BASE", (), False),
    ("trae_agent", "TraeAgent", "ollama/test-model", "OLLAMA_API_KEY", "OLLAMA_BASE_URL", (), False),
    ("trae_agent", "TraeAgent", "openrouter/test-model", "OPENROUTER_API_KEY", "OPENROUTER_BASE_URL", ("OPENROUTER_BASE_URL",), False),
    ("vibe", "Vibe", "mistral/devstral-medium", "MISTRAL_API_KEY", "VIBE_API_BASE", (), True),
]
# fmt: on


# Adapters that run a user's project folder, with the argument naming it and a
# minimal folder: Eve's app on the OpenAI SDK, LangGraph's config file.
_PROJECTS = {
    "Eve": (
        "path",
        {
            "package.json": '{"dependencies": {"@ai-sdk/openai": "1"}}',
            "agent.ts": "",
            "instructions.md": "",
        },
    ),
    "LangGraph": ("project_path", {"langgraph.json": "{}"}),
}


def _load(module: str, name: str) -> Any:
    cls = getattr(importlib.import_module(f"harbor.agents.installed.{module}"), name)
    if name not in _PROJECTS:
        return cls
    arg, files = _PROJECTS[name]
    folder = Path(tempfile.mkdtemp())
    for file, text in files.items():
        (folder / file).write_text(text)

    def make(*args: Any, **kwargs: Any) -> Any:
        return cls(*args, **{arg: folder, **kwargs})

    make.__name__ = name
    return make


def installed_adapters(
    include_per_run_only: bool = False,
) -> list[tuple[Any, str, str, tuple[str, ...], bool, dict[str, str]]]:
    """``(cls, model_name, credential_var, received_as, in_command, extra_values)`` for each adapter checked across the board.

    ``cls`` builds the adapter (with a project folder, for those in ``_PROJECTS``);
    ``credential_var`` is a variable the adapter reads its key from for that model;
    ``received_as`` and ``in_command`` are where the CLI receives that key today:
    its env names, and whether a command is its only carrier (see
    ``received_under``); ``extra_values`` are other variables it needs set
    alongside the key. With
    ``include_per_run_only``, also the adapters that take their key only from the
    run's own values. Imported on call, so a broken adapter module fails only the
    checks using it.
    """
    rows = [
        (*r, _EXTRA.get(r[1], {}))
        for r in _ADAPTERS + (_PER_RUN_ONLY if include_per_run_only else [])
    ]
    return [
        (_load(module, name), model, var, names, cmd, dict(extra))
        for module, name, model, var, names, cmd, extra in rows + _ROUTED
    ]


def endpoint_adapters() -> list[tuple[Any, str, str, str, tuple[str, ...], bool]]:
    """``(cls, model_name, credential_var, endpoint_var, received_as, in_command)`` for each adapter that passes a configured endpoint on.

    ``received_as`` and ``in_command`` are where the CLI receives a standing
    endpoint today: its env names (empty where none carries it), and whether a
    command is its only carrier.
    """
    return [
        (_load(module, name), model, key, endpoint, names, cmd)
        for module, name, model, key, endpoint, names, cmd in _ENDPOINT_ADAPTERS
    ]


def credential_files() -> list[tuple[Any, str, str, str | None]]:
    """``(cls, model_name, var, default)`` for each setting that picks a credential file the adapter uploads.

    ``var`` holds the file's path, or, where ``default`` is set, is a flag that
    picks the file at ``default`` under the home folder.
    """
    return [
        (_load(module, name), model, var, default)
        for module, name, model, var, default in _CREDENTIAL_FILES
    ]


def drive_credential_file(
    cls: Any,
    model: str,
    var: str,
    default: str | None,
    folder: Path,
    run_value: str,
    ambient_value: str,
) -> tuple[Any, Path | None, Path | None, BaseException | None]:
    """Run one ``credential_files()`` setting with real files under ``folder``, setup included.

    ``run_value`` and ``ambient_value`` are a story's inputs: ``""`` is a blank
    per-run value and ``"__skip__"`` leaves that channel unset; any other value
    sets the channel to a file of its own (for a flag, ``"1"`` with the default
    file in place). Returns ``(env, run_file, ambient_file, error)``: the file
    each channel points at (None where unset or blank; the same file for a
    flag) and what the run raised, if anything.
    """
    folder.mkdir()
    home = folder / "home"

    def put(tag: str) -> tuple[Path, str]:
        file = home / default if default else folder / f"{tag}.json"
        file.parent.mkdir(parents=True, exist_ok=True)
        file.write_text("{}")
        return file, "1" if default else str(file)

    run_file, run_setting = (
        put("run") if run_value not in ("", "__skip__") else (None, "")
    )
    ambient_file, ambient_setting = (
        put("ambient") if ambient_value != "__skip__" else (None, None)
    )
    if default and run_file and ambient_file:
        ambient_file = run_file  # a flag picks one file for both channels
    env = make_mock_env()
    error = None
    with patch.dict(os.environ, {"HOME": str(home)}, clear=False):
        for name in provider_vars():
            os.environ.pop(name, None)
        if ambient_setting is not None:
            os.environ[var] = ambient_setting
        extra_env = {} if run_value == "__skip__" else {var: run_setting}
        try:
            run_in_trial(
                cls(logs_dir=folder, model_name=model, extra_env=extra_env),
                env,
                setup=True,
            )
        except Exception as e:  # noqa: BLE001
            error = e
    return env, run_file, ambient_file, error


def uploaded(mock_env: Any, path: str) -> bool:
    """Whether the adapter uploaded the file at ``path`` (compared resolved) to the sandbox."""
    return any(
        Path(c.args[0] if c.args else c.kwargs["source_path"]).resolve()
        == Path(path).resolve()
        for c in mock_env.upload_file.call_args_list
    )


def crashed(error: BaseException | None) -> bool:
    """Whether ``error`` is a crash rather than a refusal: a lookup, attribute,
    type or name error, including one setup wrapped as the cause of its own.
    ``None`` (the run raised nothing) is not a crash."""
    return error is not None and isinstance(
        error.__cause__ or error, (LookupError, AttributeError, TypeError, NameError)
    )


def provider_vars() -> list[str]:
    """Every credential, endpoint and extra variable the tables above name.

    Pop these before seeding a drive, so a value this process already
    holds for another provider cannot change which variable an adapter picks.
    """
    names = {r[3] for r in _ADAPTERS + _PER_RUN_ONLY + _ROUTED + _CREDENTIAL_FILES}
    names |= {r[4] for r in _ENDPOINT_ADAPTERS}
    names |= {
        k for extra in [*_EXTRA.values(), *(r[6] for r in _ROUTED)] for k in extra
    }
    return sorted(names)
