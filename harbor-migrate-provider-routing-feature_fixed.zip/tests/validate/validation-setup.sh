#!/usr/bin/env bash
# validation-setup.sh — runs once before the story scripts run.
# Ensures harbor's uv-managed venv exists and the harbor.agents package is
# importable, so the stories can `import harbor.agents.installed.*` and drive
# each adapter's setup() and run() directly. Mirrors tests/test-setup.sh: same
# repo, same package manager, same editable install. Safe to re-run.

set -euo pipefail

REPO=/repo/harbor
cd "$REPO"

export PATH="/usr/local/bin:/root/.local/bin:$PATH"   # uv / uvx
export UV_CACHE_DIR=/opt/uv-cache

# The image pre-ran `uv sync --frozen` against the base commit, so this is
# normally a fast no-op. --frozen pins to uv.lock; the default (dev) group
# brings pytest, which the pytest-driver stories run under.
# Offline-first against the image bake, with a logged online fallback.
if uv sync --frozen --offline > /tmp/validation-setup.log 2>&1; then
    echo "[offline-first] uv sync satisfied from image"
elif uv sync --frozen >> /tmp/validation-setup.log 2>&1; then
    echo "[validation-setup] deps installed online (image bake was stale)"
else
    tail -60 /tmp/validation-setup.log >&2
    exit 1
fi

# Expose harbor's venv interpreter on PATH so `python`/`pytest` resolve to the
# editable install with the full dependency tree.
if [ -d "$REPO/.venv" ]; then
    export VIRTUAL_ENV="$REPO/.venv"
    export PATH="$REPO/.venv/bin:$PATH"
fi

# Smoke-import the subsystem the stories drive, so a broken env shows in the
# log before any story runs. test_harness's tables import every adapter module
# the stories construct.
python - "${BASH_SOURCE[0]%/*}" <<'PY'
import sys

sys.path.insert(0, sys.argv[1])
import harbor.agents.base  # noqa: F401,E402
import harbor.agents.installed.base  # noqa: F401,E402
import test_harness  # noqa: E402

rows = test_harness.installed_adapters(include_per_run_only=True)
test_harness.endpoint_adapters()

# The project-folder adapters build from the table; any other comes back as its class.
import tempfile  # noqa: E402
from pathlib import Path  # noqa: E402
from harbor.agents.installed.pi import Pi  # noqa: E402

built = {cls.__name__ for cls, *_ in rows if cls.__name__ in ("Eve", "LangGraph")}
assert built == {"Eve", "LangGraph"}, built
for cls, *_ in rows:
    if cls.__name__ in built:
        cls(logs_dir=Path(tempfile.mkdtemp()), model_name="openai/gpt-4o")
assert test_harness._load("pi", "Pi") is Pi

# received_under, both ways: a wrapped value counts unless exact; a missing name or command fails; one of a tuple counts.
env = test_harness.make_mock_env()
env.delivered.append(("write cfg k-1", {"A": "p=k-1", "B": "k-1"}))
assert test_harness.received_under(env, "k-1", ("A", "B"), in_command=True)
assert test_harness.received_under(env, "k-1", ("B",), exact=True)
assert not test_harness.received_under(env, "k-1", ("A",), exact=True)
assert not test_harness.received_under(env, "k-1", ("C",))
assert test_harness.received_under(env, "k-1", (("C", "B"),), exact=True)
assert not test_harness.received_under(env, "k-1", (("C", "D"),))
assert not test_harness.received_under(test_harness.make_mock_env(), "k-1", (), in_command=True)

# launch_sees, both ways: the launch env or an assignment before the launch counts, by value or by $NAME it holds.
def sees(command, env_dict):
    e = test_harness.make_mock_env()
    e.delivered.append((command, env_dict))
    return test_harness.launch_sees(e, "run-x", "A", "u")
assert sees("go; run-x", {"A": "u"}) and sees("export A='u'; run-x", {}) and sees("A=u run-x", {})
assert sees('export A="$B"; run-x', {"B": "u"}) and sees("export A=${B}; run-x", {"B": "u"})
assert not sees('export A="$C"; run-x', {"B": "u"}) and not sees("run-x; export A=u", {})
assert not sees("export A=u/v2; run-x", {}) and not sees("export XA=u; run-x", {})
try:
    sees("go", {"A": "u"})
    raise SystemExit("launch_sees accepted a drive with no launch")
except AssertionError:
    pass
# uploaded and crashed, both ways: an upload of that file counts, by any spelling of its path; a crash is a lookup, attribute, type or name error, wrapped or not.
import asyncio, os, tempfile  # noqa: E401,E402
d = tempfile.mkdtemp()
f = os.path.join(d, "c.json")
e = test_harness.make_mock_env()
asyncio.run(e.upload_file(f, "/remote/c.json"))
assert test_harness.uploaded(e, f) and test_harness.uploaded(e, os.path.join(d, ".", "c.json"))
assert not test_harness.uploaded(e, os.path.join(d, "other.json")) and not test_harness.uploaded(test_harness.make_mock_env(), f)
asyncio.run(e.upload_file(source_path=os.path.join(d, "k.json"), target_path="/r"))
assert test_harness.uploaded(e, os.path.join(d, "k.json"))
wrapped = RuntimeError("Agent install failed")
wrapped.__cause__ = KeyError("K")
assert test_harness.crashed(KeyError("K")) and test_harness.crashed(AttributeError()) and test_harness.crashed(wrapped)
assert not test_harness.crashed(ValueError("K is required")) and not test_harness.crashed(RuntimeError("no token"))
assert not test_harness.crashed(type("MissingCredentialError", (Exception,), {})("K"))
assert len(test_harness.credential_files()) == 6

# drive_credential_file, both ways: a run's own file wins and a blank one stays blank; an adapter that reads only os.environ shows.
from pathlib import Path  # noqa: E402
class Fake:  # uploads the file its setting picks: the run's value first, then os.environ
    ambient_only = False
    def __init__(self, logs_dir, model_name, extra_env):
        self.extra_env = extra_env
    async def setup(self, environment):
        pass
    async def run(self, instruction, environment, context):
        v = os.environ.get("X") if self.ambient_only or "X" not in self.extra_env else self.extra_env["X"]
        if v:
            await environment.upload_file(str(Path.home() / ".f/x") if v == "1" else v, "/r")
class AmbientOnly(Fake):
    ambient_only = True
drive = test_harness.drive_credential_file
for default in (None, ".f/x"):
    e, r, a, err = drive(Fake, "m", "X", default, Path(tempfile.mkdtemp()) / "d", "run", "amb")
    assert err is None and test_harness.uploaded(e, str(r)) and (a == r or not test_harness.uploaded(e, str(a)))
    e, r, a, err = drive(Fake, "m", "X", default, Path(tempfile.mkdtemp()) / "d", "", "amb")
    assert r is None and not test_harness.uploaded(e, str(a))
    e, r, a, err = drive(AmbientOnly, "m", "X", default, Path(tempfile.mkdtemp()) / "d", "run", "__skip__")
    assert a is None and not test_harness.uploaded(e, str(r))
print("harbor agents import OK")
PY
