#!/usr/bin/env bash
# test-setup.sh — sourced (not executed) by tests/test.sh before the checks
# run, under test.sh's `set -euo pipefail`. The image baked harbor's full
# locked dependency closure (incl. the dev group: pytest + pytest-asyncio) at
# the base commit, so this step is offline-first: it must succeed with the
# network cut (it also runs inside `docker run --network none`).
#
# The script brings harbor's uv-managed virtualenv (.venv) online and puts it
# on PATH, so `import harbor...` resolves to the editable repo install.
set -u

REPO=/repo/harbor
cd "$REPO" || { echo "test-setup: $REPO missing" >&2; return 1 2>/dev/null || exit 1; }

export PATH="/usr/local/bin:$PATH"   # uv / uvx

# Fail fast on a cache miss instead of reaching for PyPI on a dead network.
# Scoped to this task's uv only, never image-wide ENV: other tools in this
# image are installed with `uv tool install` while the network is still up.
export UV_OFFLINE=1
export UV_CACHE_DIR=/opt/uv-cache

# Dependencies: offline-first against the image bake, logged online fallback.
if uv sync --frozen --offline > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] uv sync satisfied from image"
elif UV_OFFLINE=0 uv sync --frozen >> /tmp/test-setup-install.log 2>&1; then
    echo "[test-setup] deps installed online (image bake was stale)"
else
    tail -60 /tmp/test-setup-install.log >&2
    return 1 2>/dev/null || exit 1
fi

# Make harbor's venv interpreter the default python/pytest so `import harbor...` resolves to the editable repo install with all deps.
if [ -d "$REPO/.venv" ]; then
    export VIRTUAL_ENV="$REPO/.venv"
    export PATH="$REPO/.venv/bin:$PATH"
fi

# Sanity: the subsystem under test must import cleanly.
python -c "import harbor.agents.base; import harbor.agents.installed.base" \
    && echo "test-setup: harbor agents importable" \
    || echo "test-setup: WARNING harbor import failed" >&2
