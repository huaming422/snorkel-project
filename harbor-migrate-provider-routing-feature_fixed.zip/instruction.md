## Task

Most installed-agent adapters carry their own copy of the logic that works out the model credentials and endpoint before the agent CLI launches, and those copies have drifted apart. With several agents, a key meant for one run is ignored.

I'd like every installed agent to work out and forward these values the same way. How you get there is up to you.

## User stories / requirements

- A credential set for one run is the one the agent uses, even when the ambient environment carries the same variable. Where that per-run value is empty, it stays empty instead of giving way to the ambient one, and the agent does not crash on it.
- A credential set for one run applies to that run alone, even where several runs share a single Harbor process.
- An endpoint set for the model, with the run or in the ambient environment, reaches the model unchanged and ahead of any endpoint the agent would otherwise supply itself. Where the run and the ambient environment both name one, the run's endpoint is the one used.
- When Claude Code is set to use Bedrock, or Gemini CLI to use Vertex AI or a Google login, the agent reports no provider for the model. Without such a setting, a Claude model on Claude Code still reports Anthropic and a Gemini model on Gemini CLI reports Google.
- SWE-agent on a self-hosted vLLM model, named with the hosted_vllm/ prefix, hands the model its key and offers the configured endpoint under OPENAI_BASE_URL and under OPENAI_API_BASE, no matter which of the two carried it in.
- Where an adapter already supports a provider and that provider's credential is present, the credential still reaches the model the way that adapter sends it today. This holds across the installed agents.
