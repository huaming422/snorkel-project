## Task

Most installed-agent adapters carry their own copy of the logic that works out the model credentials and endpoint before the agent CLI launches, and those copies have drifted apart. With several agents, a key set for a single run is ignored.

Please move the provider detection the adapters have copied from each other into one shared place they use instead. How the shared place is built is up to you.

## User stories / requirements

- When a credential is supplied for a single run, the agent uses that value even if the same variable is also set in the ambient environment. A per-run value left blank stays blank rather than falling back to the ambient one, and an agent that cannot run without it says so instead of crashing.
- A credential supplied for a single run applies to that run only, even when several runs share one Harbor process.
- When a model endpoint is configured explicitly, for the run or in the ambient environment, the agent passes that endpoint through to the model exactly as given, in preference to any built-in default. An endpoint configured for the run wins over a different value present in the ambient environment.
- When Claude Code is set to use Bedrock, or Gemini CLI to use Vertex AI or a Google login, the agent reports no provider for the model. Without such a setting, a Claude model on Claude Code still reports Anthropic and a Gemini model on Gemini CLI reports Google.
- When SWE-agent runs a self-hosted vLLM model (a hosted_vllm/ model name), it forwards its key and makes the configured endpoint available to the model under both OPENAI_BASE_URL and OPENAI_API_BASE, whichever of the two it was set with.
- For a provider the adapter already supports, with that provider's credential available, the agent still forwards the credential to the model the way it does today, across the installed adapters.
