#!/usr/bin/env bash
# Behavioral verifier for acados-fix-regularization-symmetry.
#
# The behavioral checks live entirely in the compiled C++ unit test
# `test_reg_symmetry.cpp` (tag [reg_symmetry]), which drives objective scaling
# and the convexify, glm, mirror and project regularizer configs on small fixed
# control blocks and compares the results with expected values. Every CHECK
# passing gives exit 0; any failing CHECK gives exit != 0.
#
# This script ships the test file into the repo's own test tree, registers it in
# the unit_tests build, rebuilds incrementally against the image's warmed build/,
# runs the tagged subset, and propagates Catch2's exit code. It is idempotent:
# re-running against an already-registered tree is a no-op registration.
#
# cwd at invocation is the repo dir (/repo/acados); the shell runner sets that.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(pwd)"
BUILD_DIR="${REPO_DIR}/build"
TEST_SRC_NAME="test_reg_symmetry.cpp"
TEST_DST="${REPO_DIR}/test/ocp_nlp/${TEST_SRC_NAME}"
CMAKELISTS="${REPO_DIR}/test/CMakeLists.txt"
REGISTER_LINE='    ${CMAKE_CURRENT_SOURCE_DIR}/ocp_nlp/test_reg_symmetry.cpp'

echo "[verify] repo=${REPO_DIR} build=${BUILD_DIR}"

# 0. Sanity: the warmed build tree and the test list must exist.
if [[ ! -d "${BUILD_DIR}" ]]; then
    echo "[verify] FATAL: expected pre-configured build dir at ${BUILD_DIR}" >&2
    exit 2
fi
if [[ ! -f "${CMAKELISTS}" ]]; then
    echo "[verify] FATAL: ${CMAKELISTS} not found" >&2
    exit 2
fi

# 1. Stage the test source into the repo's own test tree (overwrite to stay
#    current if a previous run copied an older copy).
cp -f "${SCRIPT_DIR}/${TEST_SRC_NAME}" "${TEST_DST}"
echo "[verify] staged ${TEST_SRC_NAME} -> ${TEST_DST}"

# 2. Register the test in TEST_OCP_NLP_SRC, idempotently, immediately after the
#    last existing entry (test_wind_turbine.cpp). The CMake rerun trigger fires
#    on the modified CMakeLists.txt during the build step below.
if grep -qF "ocp_nlp/${TEST_SRC_NAME}" "${CMAKELISTS}"; then
    echo "[verify] test already registered in CMakeLists.txt"
else
    python3 - "$CMAKELISTS" "$REGISTER_LINE" <<'PY'
import sys
path, reg_line = sys.argv[1], sys.argv[2]
anchor = "${CMAKE_CURRENT_SOURCE_DIR}/ocp_nlp/test_wind_turbine.cpp"
with open(path, "r") as f:
    lines = f.readlines()
out, inserted = [], False
for line in lines:
    out.append(line)
    if (not inserted) and anchor in line:
        out.append(reg_line + "\n")
        inserted = True
if not inserted:
    sys.stderr.write("[verify] FATAL: could not find registration anchor in CMakeLists.txt\n")
    sys.exit(3)
with open(path, "w") as f:
    f.writelines(out)
print("[verify] registered test in TEST_OCP_NLP_SRC")
PY
fi

# 3. Rebuild the unit_tests target. CMake re-globs/reconfigures automatically
#    because CMakeLists.txt is newer than the cache. Build loudly; on failure
#    surface the tail and fail the verifier.
echo "[verify] building unit_tests ..."
BUILD_LOG="$(mktemp)"
if ! cmake --build "${BUILD_DIR}" --target unit_tests > "${BUILD_LOG}" 2>&1; then
    echo "[verify] FATAL: unit_tests build failed; tail:" >&2
    tail -120 "${BUILD_LOG}" >&2
    exit 2
fi
echo "[verify] build ok"

UNIT_TESTS_BIN="${BUILD_DIR}/test/unit_tests"
if [[ ! -x "${UNIT_TESTS_BIN}" ]]; then
    echo "[verify] FATAL: unit_tests binary not found at ${UNIT_TESTS_BIN}" >&2
    exit 2
fi

# 4. Run only the [reg_symmetry] subset. Catch2 exits 0 iff every assertion in
#    every matched test passes; non-zero on any failure (or zero matches, which
#    we guard against explicitly below). Propagate that code verbatim.
echo "[verify] running unit_tests \"[reg_symmetry]\" ..."
set +e
"${UNIT_TESTS_BIN}" "[reg_symmetry]"
RC=$?
set -e
echo "[verify] unit_tests exit code: ${RC}"

# Guard: a zero exit with zero matched tests would be a false pass. Catch2's
# --list-test-names-only prints one bare test name per matching case with no
# header/footer, so a line count is an exact match count.
N_TESTS="$("${UNIT_TESTS_BIN}" "[reg_symmetry]" --list-test-names-only 2>/dev/null | grep -c . || true)"
echo "[verify] matched test cases: ${N_TESTS}"
if [[ "${N_TESTS}" -lt 8 ]]; then
    echo "[verify] FATAL: expected 8 [reg_symmetry] test cases, found ${N_TESTS}" >&2
    exit 2
fi

exit "${RC}"
