/*
 * Copyright (c) The acados authors.
 *
 * This file is part of acados.
 *
 * The 2-Clause BSD License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.;
 */

// Behavioral checks for stage Hessian regularization and objective scaling.
//
// Each case builds a small 2x2 control block in the lower triangle of a stage
// Hessian, sets the strict upper entry to a value that does not match it, runs
// one public path, and compares the result with the value implied by the
// lower triangle:
//
//   1. Objective scaling (ocp_nlp_qpscaling, OBJECTIVE_GERSHGORIN): the
//      objective factor for a fixed cap.
//
//   2. The CONVEXIFY regularizer config: the regularized control block, for
//      an indefinite input and for an already positive-definite one.
//
//   3. The GLM, MIRROR and PROJECT regularizer configs: the regularized block.

#include <algorithm>
#include <cmath>
#include <cstdlib>

#include "acados/utils/math.h"
#include "acados/utils/types.h"

#include "acados/ocp_qp/ocp_qp_common.h"
#include "acados/ocp_nlp/ocp_nlp_qpscaling.h"

#include "acados/ocp_nlp/ocp_nlp_reg_common.h"
#include "acados/ocp_nlp/ocp_nlp_reg_convexify.h"
#include "acados/ocp_nlp/ocp_nlp_reg_glm.h"
#include "acados/ocp_nlp/ocp_nlp_reg_mirror.h"
#include "acados/ocp_nlp/ocp_nlp_reg_project.h"

#include "blasfeo_d_aux.h"
#include "blasfeo_d_aux_ext_dep.h"

#include "catch/include/catch.hpp"


namespace
{

// Control block [[1, -2], [-2, 1]] given by its lower triangle, with an
// unrelated value in the strict upper entry. Its Gershgorin max-abs eigenvalue
// estimate is 1 + 2 = 3; taking the upper entry instead would give 1 + 50.
constexpr double kDiag = 1.0;
constexpr double kLowerOffDiag = -2.0;
constexpr double kUpperEntry = 50.0;

constexpr double kSymMaxAbsEig = 3.0;
constexpr double kWrongMaxAbsEig = 51.0;

}  // namespace


// Cap 10 sits above the block's estimate (3), so the objective factor must
// stay at 1.
TEST_CASE("objective scaling leaves the block unscaled under the cap", "[reg_symmetry]")
{
    const int N = 0;  // single stage

    // QP dimensions: one stage, a 2x2 control block (nu=2), no states/bounds.
    void *dims_mem = std::malloc(ocp_qp_dims_calculate_size(N));
    ocp_qp_dims *qp_dim = ocp_qp_dims_assign(N, dims_mem);
    int nx = 0, nu = 2, nbx = 0, nbu = 0, ng = 0, ns = 0;
    ocp_qp_dims_set(NULL, qp_dim, 0, "nx", &nx);
    ocp_qp_dims_set(NULL, qp_dim, 0, "nu", &nu);
    ocp_qp_dims_set(NULL, qp_dim, 0, "nbx", &nbx);
    ocp_qp_dims_set(NULL, qp_dim, 0, "nbu", &nbu);
    ocp_qp_dims_set(NULL, qp_dim, 0, "ng", &ng);
    ocp_qp_dims_set(NULL, qp_dim, 0, "ns", &ns);

    void *in_mem = std::calloc(1, ocp_qp_in_calculate_size(qp_dim));
    ocp_qp_in *qp_in = ocp_qp_in_assign(qp_dim, in_mem);
    void *out_mem = std::calloc(1, ocp_qp_out_calculate_size(qp_dim));
    ocp_qp_out *qp_out = ocp_qp_out_assign(qp_dim, out_mem);

    blasfeo_dgese(nu + nx, nu + nx, 0.0, &qp_in->RSQrq[0], 0, 0);
    BLASFEO_DMATEL(&qp_in->RSQrq[0], 0, 0) = kDiag;
    BLASFEO_DMATEL(&qp_in->RSQrq[0], 1, 0) = kLowerOffDiag;
    BLASFEO_DMATEL(&qp_in->RSQrq[0], 1, 1) = kDiag;
    BLASFEO_DMATEL(&qp_in->RSQrq[0], 0, 1) = kUpperEntry;

    // A non-trivial cost gradient so the objective-scaling heuristic is driven
    // purely by the eigenvalue cap, not by its small-gradient floor.
    blasfeo_dvecse(nu + nx, 0.0, &qp_in->rqz[0], 0);
    BLASFEO_DVECEL(&qp_in->rqz[0], 0) = 1.0;

    // qpscaling configured for Gershgorin objective scaling.
    void *qs_dims_mem = std::malloc(ocp_nlp_qpscaling_dims_calculate_size(N));
    ocp_nlp_qpscaling_dims *qs_dims = ocp_nlp_qpscaling_dims_assign(N, qs_dims_mem);

    void *qs_opts_mem = std::malloc(ocp_nlp_qpscaling_opts_calculate_size());
    void *qs_opts = ocp_nlp_qpscaling_opts_assign(qs_opts_mem);
    ocp_nlp_qpscaling_opts_initialize_default(qs_dims, qs_opts);
    qpscaling_scale_objective_type scale_obj = OBJECTIVE_GERSHGORIN;
    ocp_nlp_qpscaling_opts_set(qs_opts, "scale_objective", &scale_obj);
    double ub_max_abs_eig = 10.0;
    ocp_nlp_qpscaling_opts_set(qs_opts, "ub_max_abs_eig", &ub_max_abs_eig);
    // Small gradient-norm floor so it never raises the factor above what the
    // eigenvalue cap selects for this data.
    double lb_grad = 1e-8;
    ocp_nlp_qpscaling_opts_set(qs_opts, "lb_norm_inf_grad_obj", &lb_grad);

    void *qs_mem_mem = std::malloc(
        ocp_nlp_qpscaling_memory_calculate_size(qs_dims, qs_opts, qp_dim));
    void *qs_mem = ocp_nlp_qpscaling_memory_assign(qs_dims, qs_opts, qp_dim, qs_mem_mem);

    ocp_nlp_qpscaling_precompute(qs_dims, qs_opts, qs_mem, qp_in, qp_out);
    ocp_nlp_qpscaling_scale_qp(qs_dims, qs_opts, qs_mem, qp_in);

    double obj_factor = -1.0;
    ocp_nlp_qpscaling_memory_get(qs_dims, qs_mem, "obj", 0, &obj_factor);

    const double expected_correct = 1.0;                 // estimate 3 < cap 10
    const double expected_wrong = ub_max_abs_eig / kWrongMaxAbsEig;

    INFO("obj_factor=" << obj_factor
         << " correct=" << expected_correct << " wrong=" << expected_wrong);
    CHECK(obj_factor == Approx(expected_correct).margin(1e-9));
    CHECK(obj_factor > 0.5);

    std::free(qs_mem_mem);
    std::free(qs_opts_mem);
    std::free(qs_dims_mem);
    std::free(out_mem);
    std::free(in_mem);
    std::free(dims_mem);
}


// A symmetric, well-conditioned block whose estimate (2.5) is under the cap
// must be left unscaled.
TEST_CASE("objective scaling leaves a symmetric Hessian unscaled", "[reg_symmetry]")
{
    const int N = 0;

    void *dims_mem = std::malloc(ocp_qp_dims_calculate_size(N));
    ocp_qp_dims *qp_dim = ocp_qp_dims_assign(N, dims_mem);
    int nx = 0, nu = 2, nbx = 0, nbu = 0, ng = 0, ns = 0;
    ocp_qp_dims_set(NULL, qp_dim, 0, "nx", &nx);
    ocp_qp_dims_set(NULL, qp_dim, 0, "nu", &nu);
    ocp_qp_dims_set(NULL, qp_dim, 0, "nbx", &nbx);
    ocp_qp_dims_set(NULL, qp_dim, 0, "nbu", &nbu);
    ocp_qp_dims_set(NULL, qp_dim, 0, "ng", &ng);
    ocp_qp_dims_set(NULL, qp_dim, 0, "ns", &ns);

    void *in_mem = std::calloc(1, ocp_qp_in_calculate_size(qp_dim));
    ocp_qp_in *qp_in = ocp_qp_in_assign(qp_dim, in_mem);
    void *out_mem = std::calloc(1, ocp_qp_out_calculate_size(qp_dim));
    ocp_qp_out *qp_out = ocp_qp_out_assign(qp_dim, out_mem);

    // Symmetric positive-definite [[2, 0.5], [0.5, 2]]; Gershgorin max-abs
    // estimate 2 + 0.5 = 2.5, which is under the cap.
    blasfeo_dgese(nu + nx, nu + nx, 0.0, &qp_in->RSQrq[0], 0, 0);
    BLASFEO_DMATEL(&qp_in->RSQrq[0], 0, 0) = 2.0;
    BLASFEO_DMATEL(&qp_in->RSQrq[0], 1, 0) = 0.5;
    BLASFEO_DMATEL(&qp_in->RSQrq[0], 1, 1) = 2.0;
    BLASFEO_DMATEL(&qp_in->RSQrq[0], 0, 1) = 0.5;  // consistent with lower

    blasfeo_dvecse(nu + nx, 0.0, &qp_in->rqz[0], 0);
    BLASFEO_DVECEL(&qp_in->rqz[0], 0) = 1.0;

    void *qs_dims_mem = std::malloc(ocp_nlp_qpscaling_dims_calculate_size(N));
    ocp_nlp_qpscaling_dims *qs_dims = ocp_nlp_qpscaling_dims_assign(N, qs_dims_mem);

    void *qs_opts_mem = std::malloc(ocp_nlp_qpscaling_opts_calculate_size());
    void *qs_opts = ocp_nlp_qpscaling_opts_assign(qs_opts_mem);
    ocp_nlp_qpscaling_opts_initialize_default(qs_dims, qs_opts);
    qpscaling_scale_objective_type scale_obj = OBJECTIVE_GERSHGORIN;
    ocp_nlp_qpscaling_opts_set(qs_opts, "scale_objective", &scale_obj);
    double ub_max_abs_eig = 10.0;
    ocp_nlp_qpscaling_opts_set(qs_opts, "ub_max_abs_eig", &ub_max_abs_eig);
    double lb_grad = 1e-8;
    ocp_nlp_qpscaling_opts_set(qs_opts, "lb_norm_inf_grad_obj", &lb_grad);

    void *qs_mem_mem = std::malloc(
        ocp_nlp_qpscaling_memory_calculate_size(qs_dims, qs_opts, qp_dim));
    void *qs_mem = ocp_nlp_qpscaling_memory_assign(qs_dims, qs_opts, qp_dim, qs_mem_mem);

    ocp_nlp_qpscaling_precompute(qs_dims, qs_opts, qs_mem, qp_in, qp_out);
    ocp_nlp_qpscaling_scale_qp(qs_dims, qs_opts, qs_mem, qp_in);

    double obj_factor = -1.0;
    ocp_nlp_qpscaling_memory_get(qs_dims, qs_mem, "obj", 0, &obj_factor);

    INFO("obj_factor=" << obj_factor);
    CHECK(obj_factor == Approx(1.0).margin(1e-9));

    std::free(qs_mem_mem);
    std::free(qs_opts_mem);
    std::free(qs_dims_mem);
    std::free(out_mem);
    std::free(in_mem);
    std::free(dims_mem);
}


// Cap 2 sits below the block's estimate (3), so the objective factor must be
// exactly 2/3.
TEST_CASE("objective scaling factor is the cap over the block estimate", "[reg_symmetry]")
{
    const int N = 0;

    void *dims_mem = std::malloc(ocp_qp_dims_calculate_size(N));
    ocp_qp_dims *qp_dim = ocp_qp_dims_assign(N, dims_mem);
    int nx = 0, nu = 2, nbx = 0, nbu = 0, ng = 0, ns = 0;
    ocp_qp_dims_set(NULL, qp_dim, 0, "nx", &nx);
    ocp_qp_dims_set(NULL, qp_dim, 0, "nu", &nu);
    ocp_qp_dims_set(NULL, qp_dim, 0, "nbx", &nbx);
    ocp_qp_dims_set(NULL, qp_dim, 0, "nbu", &nbu);
    ocp_qp_dims_set(NULL, qp_dim, 0, "ng", &ng);
    ocp_qp_dims_set(NULL, qp_dim, 0, "ns", &ns);

    void *in_mem = std::calloc(1, ocp_qp_in_calculate_size(qp_dim));
    ocp_qp_in *qp_in = ocp_qp_in_assign(qp_dim, in_mem);
    void *out_mem = std::calloc(1, ocp_qp_out_calculate_size(qp_dim));
    ocp_qp_out *qp_out = ocp_qp_out_assign(qp_dim, out_mem);

    blasfeo_dgese(nu + nx, nu + nx, 0.0, &qp_in->RSQrq[0], 0, 0);
    BLASFEO_DMATEL(&qp_in->RSQrq[0], 0, 0) = kDiag;
    BLASFEO_DMATEL(&qp_in->RSQrq[0], 1, 0) = kLowerOffDiag;
    BLASFEO_DMATEL(&qp_in->RSQrq[0], 1, 1) = kDiag;
    BLASFEO_DMATEL(&qp_in->RSQrq[0], 0, 1) = kUpperEntry;

    blasfeo_dvecse(nu + nx, 0.0, &qp_in->rqz[0], 0);
    BLASFEO_DVECEL(&qp_in->rqz[0], 0) = 1.0;

    void *qs_dims_mem = std::malloc(ocp_nlp_qpscaling_dims_calculate_size(N));
    ocp_nlp_qpscaling_dims *qs_dims = ocp_nlp_qpscaling_dims_assign(N, qs_dims_mem);

    void *qs_opts_mem = std::malloc(ocp_nlp_qpscaling_opts_calculate_size());
    void *qs_opts = ocp_nlp_qpscaling_opts_assign(qs_opts_mem);
    ocp_nlp_qpscaling_opts_initialize_default(qs_dims, qs_opts);
    qpscaling_scale_objective_type scale_obj = OBJECTIVE_GERSHGORIN;
    ocp_nlp_qpscaling_opts_set(qs_opts, "scale_objective", &scale_obj);
    double ub_max_abs_eig = 2.0;
    ocp_nlp_qpscaling_opts_set(qs_opts, "ub_max_abs_eig", &ub_max_abs_eig);
    double lb_grad = 1e-8;
    ocp_nlp_qpscaling_opts_set(qs_opts, "lb_norm_inf_grad_obj", &lb_grad);

    void *qs_mem_mem = std::malloc(
        ocp_nlp_qpscaling_memory_calculate_size(qs_dims, qs_opts, qp_dim));
    void *qs_mem = ocp_nlp_qpscaling_memory_assign(qs_dims, qs_opts, qp_dim, qs_mem_mem);

    ocp_nlp_qpscaling_precompute(qs_dims, qs_opts, qs_mem, qp_in, qp_out);
    ocp_nlp_qpscaling_scale_qp(qs_dims, qs_opts, qs_mem, qp_in);

    double obj_factor = -1.0;
    ocp_nlp_qpscaling_memory_get(qs_dims, qs_mem, "obj", 0, &obj_factor);

    const double expected_correct = ub_max_abs_eig / kSymMaxAbsEig;   // 2/3
    const double expected_wrong = ub_max_abs_eig / kWrongMaxAbsEig;

    INFO("obj_factor=" << obj_factor
         << " correct=" << expected_correct << " wrong=" << expected_wrong);
    CHECK(obj_factor == Approx(expected_correct).margin(1e-9));

    std::free(qs_mem_mem);
    std::free(qs_opts_mem);
    std::free(qs_dims_mem);
    std::free(out_mem);
    std::free(in_mem);
    std::free(dims_mem);
}


// CONVEXIFY on one stage with nu = 2, nx = 1 and B = [1, 1]. The terminal
// cost sets q, and the stage control block becomes I + q * [[1, 1], [1, 1]].
// q = -0.75 gives eigenvalues 1 and -0.5, which CONVEXIFY projects with
// epsilon 1e-4. q = 0.5 gives eigenvalues 2 and 1, which need no change.
namespace
{

class ConvexifyFixture
{
 public:
    explicit ConvexifyFixture(double terminal_q)
    {
        config_memory_ = std::malloc(ocp_nlp_reg_config_calculate_size());
        config_ = static_cast<ocp_nlp_reg_config *>(ocp_nlp_reg_config_assign(config_memory_));
        ocp_nlp_reg_convexify_config_initialize_default(config_);

        constexpr int N = 1;
        dims_memory_ = std::malloc(config_->dims_calculate_size(N));
        dims_ = config_->dims_assign(N, dims_memory_);
        dims_->nx[0] = 1;
        dims_->nx[1] = 1;
        dims_->nu[0] = 2;
        dims_->nu[1] = 0;

        opts_memory_ = std::malloc(config_->opts_calculate_size());
        opts_ = config_->opts_assign(opts_memory_);
        config_->opts_initialize_default(config_, dims_, opts_);

        memory_memory_ = std::malloc(config_->memory_calculate_size(config_, dims_, opts_));
        memory_ = config_->memory_assign(config_, dims_, opts_, memory_memory_);

        blasfeo_allocate_dmat(4, 3, &RSQrq_[0]);
        blasfeo_allocate_dmat(2, 1, &RSQrq_[1]);
        blasfeo_allocate_dmat(4, 1, &BAbt_[0]);
        blasfeo_allocate_dvec(3, &rq_[0]);
        blasfeo_allocate_dvec(1, &rq_[1]);
        blasfeo_allocate_dvec(1, &b_[0]);

        blasfeo_dgese(4, 3, 0.0, &RSQrq_[0], 0, 0);
        blasfeo_dgese(2, 1, 0.0, &RSQrq_[1], 0, 0);
        blasfeo_dgese(4, 1, 0.0, &BAbt_[0], 0, 0);
        blasfeo_dvecse(3, 0.0, &rq_[0], 0);
        blasfeo_dvecse(1, 0.0, &rq_[1], 0);
        blasfeo_dvecse(1, 0.0, &b_[0], 0);

        const double delta = static_cast<ocp_nlp_reg_convexify_opts *>(opts_)->delta;
        BLASFEO_DMATEL(&RSQrq_[0], 0, 0) = 1.0;
        BLASFEO_DMATEL(&RSQrq_[0], 1, 1) = 1.0;
        BLASFEO_DMATEL(&RSQrq_[0], 2, 2) = 1.0;
        BLASFEO_DMATEL(&RSQrq_[1], 0, 0) = delta + terminal_q;
        BLASFEO_DMATEL(&BAbt_[0], 0, 0) = 1.0;
        BLASFEO_DMATEL(&BAbt_[0], 1, 0) = 1.0;

        config_->memory_set_RSQrq_ptr(dims_, RSQrq_, memory_);
        config_->memory_set_rq_ptr(dims_, rq_, memory_);
        config_->memory_set_BAbt_ptr(dims_, BAbt_, memory_);
        config_->memory_set_b_ptr(dims_, b_, memory_);
    }

    ~ConvexifyFixture()
    {
        blasfeo_free_dvec(&b_[0]);
        blasfeo_free_dvec(&rq_[1]);
        blasfeo_free_dvec(&rq_[0]);
        blasfeo_free_dmat(&BAbt_[0]);
        blasfeo_free_dmat(&RSQrq_[1]);
        blasfeo_free_dmat(&RSQrq_[0]);
        std::free(memory_memory_);
        std::free(opts_memory_);
        std::free(dims_memory_);
        std::free(config_memory_);
    }

    void regularize() { config_->regularize(config_, dims_, opts_, memory_); }

    void regularize_lhs() { config_->regularize_lhs(config_, dims_, opts_, memory_); }

    void regularize_rhs() { config_->regularize_rhs(config_, dims_, opts_, memory_); }

    void check_control_hessian(const char *phase, double diag, double off_diag) const
    {
        const double r00 = BLASFEO_DMATEL(&RSQrq_[0], 0, 0);
        const double r10 = BLASFEO_DMATEL(&RSQrq_[0], 1, 0);
        const double r11 = BLASFEO_DMATEL(&RSQrq_[0], 1, 1);

        INFO(phase << " r00=" << r00 << " r10=" << r10 << " r11=" << r11);
        CHECK(r00 == Approx(diag).margin(1e-9));
        CHECK(r10 == Approx(off_diag).margin(1e-9));
        CHECK(r11 == Approx(diag).margin(1e-9));
    }

 private:
    void *config_memory_;
    void *dims_memory_;
    void *opts_memory_;
    void *memory_memory_;
    ocp_nlp_reg_config *config_;
    ocp_nlp_reg_dims *dims_;
    void *opts_;
    void *memory_;
    struct blasfeo_dmat RSQrq_[2];
    struct blasfeo_dmat BAbt_[1];
    struct blasfeo_dvec rq_[2];
    struct blasfeo_dvec b_[1];
};

}  // namespace


TEST_CASE("convexify regularizes an indefinite control Hessian", "[reg_symmetry]")
{
    ConvexifyFixture fixture(-0.75);
    const double eps = 1e-4;
    const double diag = 0.5 * (1.0 + eps);
    const double off_diag = 0.5 * (eps - 1.0);

    SECTION("full regularization")
    {
        fixture.regularize();
        fixture.check_control_hessian("after regularize", diag, off_diag);
    }

    SECTION("split regularization")
    {
        fixture.regularize_lhs();
        fixture.check_control_hessian("after regularize_lhs", diag, off_diag);
        fixture.regularize_rhs();
        fixture.check_control_hessian("after regularize_rhs", diag, off_diag);
    }
}


TEST_CASE("convexify leaves a positive-definite control Hessian unchanged", "[reg_symmetry]")
{
    ConvexifyFixture fixture(0.5);

    SECTION("full regularization")
    {
        fixture.regularize();
        fixture.check_control_hessian("after regularize", 1.5, 0.5);
    }

    SECTION("split regularization")
    {
        fixture.regularize_lhs();
        fixture.check_control_hessian("after regularize_lhs", 1.5, 0.5);
        fixture.regularize_rhs();
        fixture.check_control_hessian("after regularize_rhs", 1.5, 0.5);
    }
}


namespace
{

class StageRegularizerFixture
{
 public:
    explicit StageRegularizerFixture(void (*initialize_default)(ocp_nlp_reg_config *))
    {
        config_memory_ = std::malloc(ocp_nlp_reg_config_calculate_size());
        config_ = static_cast<ocp_nlp_reg_config *>(ocp_nlp_reg_config_assign(config_memory_));
        initialize_default(config_);

        constexpr int N = 0;
        dims_memory_ = std::calloc(1, config_->dims_calculate_size(N));
        dims_ = config_->dims_assign(N, dims_memory_);
        dims_->nx[0] = 0;
        dims_->nu[0] = 2;

        opts_memory_ = std::malloc(config_->opts_calculate_size());
        opts_ = config_->opts_assign(opts_memory_);
        config_->opts_initialize_default(config_, dims_, opts_);

        memory_memory_ = std::malloc(config_->memory_calculate_size(config_, dims_, opts_));
        memory_ = config_->memory_assign(config_, dims_, opts_, memory_memory_);

        blasfeo_allocate_dmat(3, 2, &RSQrq_[0]);
        blasfeo_allocate_dvec(2, &rq_[0]);
        blasfeo_dgese(3, 2, 0.0, &RSQrq_[0], 0, 0);
        blasfeo_dvecse(2, 0.0, &rq_[0], 0);

        BLASFEO_DMATEL(&RSQrq_[0], 0, 0) = 1.0;
        BLASFEO_DMATEL(&RSQrq_[0], 1, 0) = -3.0;
        BLASFEO_DMATEL(&RSQrq_[0], 1, 1) = 5.0;
        BLASFEO_DMATEL(&RSQrq_[0], 0, 1) = 0.0;

        config_->memory_set_RSQrq_ptr(dims_, RSQrq_, memory_);
        config_->memory_set_rq_ptr(dims_, rq_, memory_);
    }

    ~StageRegularizerFixture()
    {
        blasfeo_free_dvec(&rq_[0]);
        blasfeo_free_dmat(&RSQrq_[0]);
        std::free(memory_memory_);
        std::free(opts_memory_);
        std::free(dims_memory_);
        std::free(config_memory_);
    }

    void regularize() { config_->regularize(config_, dims_, opts_, memory_); }

    double r00() const { return BLASFEO_DMATEL(&RSQrq_[0], 0, 0); }
    double r10() const { return BLASFEO_DMATEL(&RSQrq_[0], 1, 0); }
    double r11() const { return BLASFEO_DMATEL(&RSQrq_[0], 1, 1); }

 private:
    void *config_memory_;
    void *dims_memory_;
    void *opts_memory_;
    void *memory_memory_;
    ocp_nlp_reg_config *config_;
    ocp_nlp_reg_dims *dims_;
    void *opts_;
    void *memory_;
    struct blasfeo_dmat RSQrq_[1];
    struct blasfeo_dvec rq_[1];
};

const double kStageEigHigh = 3.0 + std::sqrt(13.0);
const double kStageEigLow = 3.0 - std::sqrt(13.0);

}  // namespace


TEST_CASE("glm regularizes an indefinite stage Hessian", "[reg_symmetry]")
{
    StageRegularizerFixture fixture(&ocp_nlp_reg_glm_config_initialize_default);
    fixture.regularize();

    const double r00 = fixture.r00();
    const double r10 = fixture.r10();
    const double r11 = fixture.r11();

    INFO("r00=" << r00 << " r10=" << r10 << " r11=" << r11);
    CHECK(std::isfinite(r00));
    CHECK(std::isfinite(r10));
    CHECK(std::isfinite(r11));
    CHECK(r10 == Approx(-3.0).margin(1e-12));
    CHECK(r00 > 0.0);
    CHECK(r11 > 0.0);
    CHECK(r00 * r11 - r10 * r10 > 0.0);
}


TEST_CASE("mirror regularizes an indefinite stage Hessian", "[reg_symmetry]")
{
    StageRegularizerFixture fixture(&ocp_nlp_reg_mirror_config_initialize_default);
    fixture.regularize();

    const double r00 = fixture.r00();
    const double r10 = fixture.r10();
    const double r11 = fixture.r11();

    INFO("r00=" << r00 << " r10=" << r10 << " r11=" << r11);
    CHECK(r00 + r11 == Approx(kStageEigHigh - kStageEigLow).margin(1e-9));
    CHECK(r00 * r11 - r10 * r10 == Approx(-kStageEigHigh * kStageEigLow).margin(1e-9));
}


TEST_CASE("project regularizes an indefinite stage Hessian", "[reg_symmetry]")
{
    StageRegularizerFixture fixture(&ocp_nlp_reg_project_config_initialize_default);
    fixture.regularize();

    const double epsilon = 1e-4;
    const double r00 = fixture.r00();
    const double r10 = fixture.r10();
    const double r11 = fixture.r11();

    INFO("r00=" << r00 << " r10=" << r10 << " r11=" << r11);
    CHECK(r00 + r11 == Approx(kStageEigHigh + epsilon).margin(1e-9));
    CHECK(r00 * r11 - r10 * r10 == Approx(kStageEigHigh * epsilon).margin(1e-9));
}
