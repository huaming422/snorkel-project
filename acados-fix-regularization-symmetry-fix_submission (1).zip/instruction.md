## Task

We run an SQP-RTI controller with CONVEXIFY regularization, and on some problems the QP after regularization is still indefinite, so the solve diverges or stalls. It only shows up on certain data. Separately, objective scaling has been picking scaling factors that don't make sense for some of our QPs, which may or may not be related. Can you dig into both and fix whatever is behind them?
