## Task

a user says openlogi feels like it's grinding on busywork. every snapshot the background agent publishes rebuilds the whole list of device cards, and that fires constantly: just clicking out of the app and back sets one off. profiling a single rebuild shows it reading every connected device's art back off disk from scratch, even when nothing changed, and these rebuilds fail to hold the frame budget. it's bad for some device kinds and barely there for others.

two back-to-back rebuilds with nothing changed between them shouldn't both pay to read the same art off disk. dig into where that repeated work happens and get rid of it.

the display has to come out identical: every card and detail header shows the same art it does today, for every device kind. don't touch the on-disk art file formats or the device-registry schema, and don't change which art a device ends up with.

two cases still have to hold. a device whose art hasn't finished downloading has to start showing it once the download lands, including a partly-succeeded one, without a restart. and clearing the locally downloaded art has to drop the cards to the silhouette (or bundled art) right away, a refresh bringing the real art back.
