package weed_server

// Behavioral checks for the aggregated metadata-subscribe loop, driven entirely
// through its in-package end-to-end harness (newSubscribeHarness, startAggregator,
// subscribeAggregated, reportPeersAt, appendAggregated, waitForEvents,
// waitForFlushedFiles, tsAt) and the pre-existing filer.FilerStore interface.
//
// The behavior under test is the persisted-log disk pass cadence: a subscriber
// whose start position sits past the end of the local persisted log must not
// re-list the system log directory on every wake, yet it must still deliver its
// backlog the moment peer progress admits it, and a held on-disk entry must
// still be re-read and released when the flush watermark reaches it. Work is
// observed by wrapping the store in a counting shim that tallies listings on the
// system log dir, and delivery is observed on the subscriber's own stream.
//
// No symbol introduced by the change is referenced: any shape that produces the
// same observable cadence and delivery passes.

import (
	"context"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"github.com/seaweedfs/seaweedfs/weed/filer"
	"github.com/seaweedfs/seaweedfs/weed/util"
)

// vrfCountingStore wraps a filer.FilerStore and counts directory listings that
// target the system log dir — the repeated work a parked subscriber performs
// when it re-runs the persisted-log pass. Every other store call passes through
// unchanged, so the loop behaves exactly as with the real store.
type vrfCountingStore struct {
	filer.FilerStore
	logLists *atomic.Int64
}

func (s *vrfCountingStore) ListDirectoryPrefixedEntries(ctx context.Context, dirPath util.FullPath, startFileName string, includeStartFile bool, limit int64, prefix string, eachEntryFunc filer.ListEachEntryFunc) (lastFileName string, err error) {
	if strings.HasPrefix(string(dirPath), filer.SystemLogDir) {
		s.logLists.Add(1)
	}
	return s.FilerStore.ListDirectoryPrefixedEntries(ctx, dirPath, startFileName, includeStartFile, limit, prefix, eachEntryFunc)
}

// TestVerify_AggregatedNoPersistedRescanAfterStart parks a subscriber past the
// end of the persisted log with the peers' watermarks stuck at the old tail, and
// asserts two things: the persisted-log listing rate stays small instead of
// climbing with time (the idle subscriber is not burning the disk pass on every
// wake), and once peer progress advances through the held ring entries the
// previously-parked subscriber promptly delivers that backlog — from the ring,
// without another listing storm. A loop that re-lists on every wake fails the
// rate bound; a fix that merely throttles or that stops delivering fails the
// delivery tail.
func TestVerify_AggregatedNoPersistedRescanAfterStart(t *testing.T) {
	h := newSubscribeHarness(t)

	lists := &atomic.Int64{}
	h.f.SetStore(&vrfCountingStore{FilerStore: h.f.GetStore(), logLists: lists})

	// Persisted log ends at T1: one flushed window, nothing after.
	h.append(h.tsAt(0, 0))
	h.append(h.tsAt(0, 1))
	h.f.LocalMetaLogBuffer.ForceFlush()
	waitForFlushedFiles(t, h, h.tsAt(0, 1))

	// Client cursor sits just past the last persisted entry.
	cursor := h.tsAt(0, 1) + int64(time.Millisecond)

	ma := h.startAggregator()

	// Aggregated ring holds only much newer entries (peer events).
	recent := time.Now().UnixNano()
	h.appendAggregated(recent)
	h.appendAggregated(recent + int64(time.Millisecond))

	// Peers' watermarks are stuck at the old log tail: nothing new is admitted.
	reportPeersAt(ma, h.tsAt(0, 1), h.tsAt(0, 1))

	r := h.subscribeAggregated(cursor)

	// Warm up: the first pass plus the cursor-move re-read after the gap
	// machinery re-arms the cursor are legitimate.
	time.Sleep(150 * time.Millisecond)

	before := lists.Load()
	time.Sleep(500 * time.Millisecond)
	rate := float64(lists.Load()-before) / 0.5
	if rate > 4 {
		t.Fatalf("%.1f persisted-log listings per second while parked; the disk pass re-ran on every wake", rate)
	}

	// Peer progress through the held entries releases the read: the held events
	// are delivered without another persisted-log pass.
	lists.Store(0)
	reportPeersAt(ma, recent+int64(time.Millisecond), h.tsAt(0, 1))
	waitForEvents(t, r, []int64{recent, recent + int64(time.Millisecond)}, 3*time.Second)
	if got := lists.Load(); got > 4 {
		t.Fatalf("%d listings while draining held entries; delivery should come from the ring", got)
	}
}

// TestVerify_AggregatedDiskHoldReleasesOnFlush pins that each hold parks on its
// own watermark. A persisted-log read is held by what the peers have FLUSHED,
// and peers advance their DELIVERY watermark on every event they stream. A loop
// that treats delivery progress as a reason to re-read the disk would re-list a
// day of log files per delivery advance and re-park on the same entry; a loop
// that skips the disk pass outright while a hold is pending would never deliver
// the held entry at all. The held on-disk entry must sit quiet under
// delivery-only progress and arrive exactly when the flush watermark reaches it.
func TestVerify_AggregatedDiskHoldReleasesOnFlush(t *testing.T) {
	h := newSubscribeHarness(t)
	prevRetry := unflushedGapRetryInterval
	unflushedGapRetryInterval = 500 * time.Millisecond
	t.Cleanup(func() { unflushedGapRetryInterval = prevRetry })

	// Recent enough that the settled horizon does not take the hold over.
	onDisk := time.Now().Add(-30 * time.Second).UnixNano()
	h.append(onDisk)
	h.f.LocalMetaLogBuffer.ForceFlush()
	waitForFlushedFiles(t, h, onDisk)

	ma := h.startAggregator()
	// Flushed below the entry on disk, delivered well past it: only the disk
	// pass is held.
	reportPeersAt(ma, time.Now().UnixNano(), onDisk-int64(time.Second))
	r := h.subscribeAggregated(onDisk - int64(5*time.Second))
	assertNoEventsFor(t, r, 200*time.Millisecond)

	holdsBefore := heldReads("disk")
	start := time.Now()
	for deadline := start.Add(time.Second); time.Now().Before(deadline); {
		reportPeersAt(ma, time.Now().UnixNano(), 0)
		time.Sleep(2 * time.Millisecond)
	}
	holds, elapsed := heldReads("disk")-holdsBefore, time.Since(start)

	t.Logf("%v of delivery-only progress produced %d disk holds", elapsed, holds)
	if maxHolds := int(elapsed/unflushedGapRetryInterval) + 2; holds > maxHolds {
		t.Fatalf("held on disk %d times in %v, want at most %d: delivery progress cannot release a flush hold",
			holds, elapsed, maxHolds)
	}

	// The flush watermark reaching the entry is what delivers it.
	reportPeersAt(ma, 0, onDisk)
	waitForEvents(t, r, []int64{onDisk}, 3*time.Second)
}

// TestVerify_NormalStreamingBacklogThenLiveExactlyOnce confirms a subscriber
// whose start position is within the persisted log still receives every
// historical and live event, in order, exactly once. Timestamps are 1ms-adjacent
// across every boundary — window to window on disk, and disk to retained memory —
// so a cursor error of even one entry at any handoff shows up as a hole or a
// duplicate. A fix that gates the disk pass too aggressively would drop or
// reorder backlog here.
func TestVerify_NormalStreamingBacklogThenLiveExactlyOnce(t *testing.T) {
	h := newSubscribeHarness(t)

	ts := func(i int) int64 { return h.base + int64(i)*int64(time.Millisecond) }

	var want []int64
	n := 0
	for w := 0; w < 3; w++ {
		for i := 0; i < 3; i++ {
			want = append(want, ts(n))
			h.append(ts(n))
			n++
		}
		h.f.LocalMetaLogBuffer.ForceFlush() // adjacent-timestamp window boundary on disk
	}
	// A retained, unflushed tail starting 1ms after the flushed content ends.
	for i := 0; i < 3; i++ {
		want = append(want, ts(n))
		h.append(ts(n))
		n++
	}

	r := h.subscribe(0, nil)
	waitForEvents(t, r, want, 5*time.Second)

	// Live tail on top.
	live := []int64{ts(n), ts(n + 1)}
	for _, l := range live {
		h.append(l)
	}
	waitForEvents(t, r, append(append([]int64(nil), want...), live...), 5*time.Second)
}
