#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier runs (inherits set -euo pipefail).
# No assertion logic here — only make the baked Go dependency closure usable
# with the network cut, and confirm the changed package compiles.
cd /repo/seaweedfs

# Offline switches FIRST so a cache miss fails fast instead of hanging on a dead
# network (the smoke gate sources this inside `docker run --network none`).
export GOFLAGS=-mod=mod
export GOPROXY=off
export GOTOOLCHAIN=local
export CGO_ENABLED=0

# Module closure was baked at the base commit (image step 7: go mod download).
# Offline-first against that bake, with a logged online fallback for the case
# where the bake was stale. Check the exit status directly (no `| tail`, which
# would mask it and skip the fallback).
if GOPROXY=off go mod download > /tmp/test-setup-godl.log 2>&1; then
    echo "[offline-first] go module closure satisfied from image bake"
elif GOPROXY=https://proxy.golang.org,direct go mod download >> /tmp/test-setup-godl.log 2>&1; then
    echo "[test-setup] go modules downloaded online (image bake was stale)"
else
    tail -40 /tmp/test-setup-godl.log >&2; exit 1
fi

# Warm-compile the changed package's tests so the verifier's first run is fast
# and any offline build gap surfaces here, not mid-grade. Compile-only.
if go test -count=1 -run '^$' ./weed/server/ > /tmp/test-setup-build.log 2>&1; then
    echo "[test-setup] weed/server test binary compiles offline"
else
    tail -60 /tmp/test-setup-build.log >&2; exit 1
fi
