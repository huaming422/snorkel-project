## Task

we're getting reports that `mise ls-remote <tool>` lists versions that then fail to install with "No matching asset found". `mise latest <tool>` can pick the same broken versions. this affects tools backed by GitHub, GitLab, and Forgejo, and the releases are published releases, not drafts or pre-releases.

for example, a repository has an older release with downloads and a newer release with no attached downloads. with the tool's usual configuration, `ls-remote` should include the older version and leave out the newer one, and `latest` should return the older version.

users also configure tools with their own download URLs, including URLs for individual platforms. if those URLs provide a download for the newer version, it should appear in `ls-remote` and be returned by `latest` too. both configurations should give the expected results when used one after the other, in either order.

the version list should be the same on every OS and CPU architecture. a release with downloads for another platform should still appear in the list.
