#!/usr/bin/env bash
# Prepare the container for the behavioral (e2e) verifier.
#
# The image already carries the full compiled closure: block 7 of the
# Dockerfile ran `cargo build --locked --tests --workspace` and
# `cargo build --locked --bin mise` at the task base commit, with the whole
# workspace dependency closure fetched (`cargo fetch --locked`) into
# $CARGO_HOME. So for the OFFLINE agent phase there is nothing to download —
# this script only confirms the `mise` debug binary the e2e harness drives is
# present and rebuilds it from cache if a solution touched the sources.
#
# The e2e harness (e2e/run_test) expects the binary at
# "${CARGO_TARGET_DIR:-$ROOT/target}/debug/mise"; CARGO_TARGET_DIR is set to
# /opt/cache/cargo-target in the image.
set -euo pipefail

cd /repo/mise

# Rebuild the CLI using the dependencies cached in the image.
# Keep dependency versions locked and limit concurrent build jobs.
# Report build failures directly without attempting network downloads.
if ! cargo build --locked --offline --bin mise --jobs 1 \
    > /tmp/mise-setup-build.log 2>&1; then
    echo "Offline mise build failed:" >&2
    cat /tmp/mise-setup-build.log >&2
    exit 1
fi

# Sanity: the binary exists where the e2e harness looks for it.
BIN="${CARGO_TARGET_DIR:-/repo/mise/target}/debug/mise"
if [[ ! -x "$BIN" ]]; then
    echo "expected mise binary not found at $BIN" >&2
    exit 1
fi
"$BIN" --version
