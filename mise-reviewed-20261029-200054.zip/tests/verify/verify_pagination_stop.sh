#!/usr/bin/env bash
#
# Check version discovery across paginated GitHub and Forgejo releases.
# A newer release without downloads appears before an older release
# with a download. Only the older release is listed and resolved.
#
# Each forge uses separate temporary directories, cache, and local server.

set -uo pipefail

if [[ $# -eq 0 ]]; then
    SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
    SCRIPT_PATH="$SCRIPT_DIR/$(basename -- "${BASH_SOURCE[0]}")"

    STATUS=0
    for forge in github forgejo; do
        bash "$SCRIPT_PATH" "$forge" || STATUS=1
    done
    exit "$STATUS"
fi

[[ $# -eq 1 ]] || {
    echo "FAIL: expected one forge name" >&2
    exit 1
}

FORGE="$1"
case "$FORGE" in
    github|forgejo) ;;
    *)
        echo "FAIL: unsupported forge: $FORGE" >&2
        exit 1
        ;;
esac

MISE_BIN=""
for cand in \
    "${MISE_E2E_BIN:-}" \
    "${CARGO_TARGET_DIR:-/opt/cache/cargo-target}/debug/mise" \
    "/repo/mise/target/debug/mise" \
    "$(command -v mise 2>/dev/null || true)"; do
    if [[ -n "$cand" && -x "$cand" ]]; then
        MISE_BIN="$cand"
        break
    fi
done

[[ -n "$MISE_BIN" ]] || {
    echo "FAIL: could not locate a built mise binary" >&2
    exit 1
}

MISE_BIN="$(
    python3 -c 'import os, sys; print(os.path.abspath(sys.argv[1]))' "$MISE_BIN"
)" || exit 1

echo "checking $FORGE pagination with mise binary: $MISE_BIN" >&2

WORK="$(mktemp -d "${TMPDIR:-/tmp}/mise-verify-page.XXXXXX")" || exit 1

cleanup() {
    if [[ -n "${SERVER_PID:-}" ]]; then
        kill "$SERVER_PID" 2>/dev/null || true
        wait "$SERVER_PID" 2>/dev/null || true
    fi
    rm -rf "$WORK" 2>/dev/null || true
}
trap cleanup EXIT

fail() {
    echo "FAIL [$FORGE]: $*" >&2
    exit 1
}

export HOME="$WORK/home"
export MISE_DATA_DIR="$HOME/.local/share/mise"
export MISE_CACHE_DIR="$HOME/.cache/mise"
export MISE_CONFIG_DIR="$HOME/.config/mise"
export MISE_STATE_DIR="$HOME/.local/state/mise"
export MISE_SYSTEM_DIR="$WORK/etc/mise"
export MISE_TMP_DIR="$WORK/tmp"

WORKDIR="$WORK/workdir"
mkdir -p \
    "$HOME" \
    "$MISE_DATA_DIR" \
    "$MISE_CACHE_DIR" \
    "$MISE_CONFIG_DIR" \
    "$MISE_STATE_DIR" \
    "$MISE_SYSTEM_DIR" \
    "$MISE_TMP_DIR" \
    "$WORKDIR" || fail "could not create temporary directories"

export MISE_YES=1
export MISE_EXPERIMENTAL=1
export MISE_USE_VERSIONS_HOST=0
export MISE_USE_VERSIONS_HOST_TRACK=0

unset MISE_GITHUB_TOKEN GITHUB_TOKEN MISE_LIST_ALL_VERSIONS \
    2>/dev/null || true

cd "$WORKDIR" || fail "could not enter temporary working directory"

PORT_FILE="$WORK/port"

case "$(uname -m)" in
    x86_64|amd64)
        FIXTURE_ASSET_ARCH="x86_64"
        ;;
    aarch64|arm64)
        FIXTURE_ASSET_ARCH="aarch64"
        ;;
    *)
        fail "unsupported fixture architecture: $(uname -m)"
        ;;
esac

python3 - "$PORT_FILE" "$FORGE" "$FIXTURE_ASSET_ARCH" <<'PY' &
import http.server
import json
import socketserver
import sys
from urllib.parse import parse_qs, urlsplit

port_file = sys.argv[1]
forge = sys.argv[2]
asset_arch = sys.argv[3]

WITHOUT_DOWNLOAD = {
    "id": 3,
    "tag_name": "v3.0.0",
    "draft": False,
    "prerelease": False,
    "created_at": "2026-03-01T00:00:00Z",
    "published_at": "2026-03-01T00:00:00Z",
    "assets": [],
}

WITH_DOWNLOAD = {
    "id": 2,
    "tag_name": "v2.0.0",
    "draft": False,
    "prerelease": False,
    "created_at": "2026-02-01T00:00:00Z",
    "published_at": "2026-02-01T00:00:00Z",
    "assets": [
        {
            "id": 2,
            "name": f"tool-{asset_arch}-unknown-linux-gnu.tar.gz",
            "uuid": "asset-2",
            "browser_download_url": "https://example.invalid/tool.tar.gz",
            "url": "https://example.invalid/api/assets/2",
        }
    ],
}

RELEASES_PATH = {
    "github": "/repos/acme/tool/releases",
    "forgejo": "/api/v1/repos/acme/tool/releases",
}[forge]


class Handler(http.server.BaseHTTPRequestHandler):
    def reply(self, payload, link=None):
        body = json.dumps(payload).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        if link is not None:
            self.send_header("Link", link)
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urlsplit(self.path)
        page = parse_qs(parsed.query).get("page", ["1"])[0]

        if parsed.path == RELEASES_PATH + "/latest":
            self.reply(WITHOUT_DOWNLOAD)
            return

        if parsed.path != RELEASES_PATH:
            self.send_response(404)
            self.end_headers()
            return

        if page == "1":
            size_key = "limit" if forge == "forgejo" else "per_page"
            next_url = (
                f"http://127.0.0.1:{self.server.server_address[1]}"
                f"{RELEASES_PATH}?{size_key}=100&page=2"
            )
            self.reply(
                [WITHOUT_DOWNLOAD],
                link=f'<{next_url}>; rel="next"',
            )
        elif page == "2":
            self.reply([WITH_DOWNLOAD])
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, *args):
        pass


socketserver.TCPServer.allow_reuse_address = True
with socketserver.TCPServer(("127.0.0.1", 0), Handler) as httpd:
    with open(port_file, "w") as handle:
        handle.write(str(httpd.server_address[1]))
    httpd.serve_forever()
PY

SERVER_PID=$!

for _ in $(seq 1 60); do
    [[ -s "$PORT_FILE" ]] && break
    kill -0 "$SERVER_PID" 2>/dev/null \
        || fail "local API server exited before reporting its port"
    sleep 0.5
done

PORT="$(cat "$PORT_FILE" 2>/dev/null || true)"
[[ -n "$PORT" ]] || fail "local API server did not report a port"

case "$FORGE" in
    github) API_URL="http://127.0.0.1:$PORT" ;;
    forgejo) API_URL="http://127.0.0.1:$PORT/api/v1" ;;
esac

TOOL="$FORGE:acme/tool[api_url=$API_URL]"

LIST_OUT="$("$MISE_BIN" ls-remote --no-versions-host "$TOOL")" \
    || fail "mise ls-remote exited non-zero"

echo "[$FORGE] ls-remote:" >&2
echo "$LIST_OUT" >&2

grep -Fxq "2.0.0" <<<"$LIST_OUT" \
    || fail "release 2.0.0 from the second page is missing from ls-remote"

if grep -Fxq "3.0.0" <<<"$LIST_OUT"; then
    fail "release 3.0.0 is still listed by ls-remote"
fi

LATEST_OUT="$("$MISE_BIN" latest "$TOOL")" \
    || fail "mise latest exited non-zero"

echo "[$FORGE] latest: '$LATEST_OUT'" >&2

[[ "$LATEST_OUT" == "2.0.0" ]] \
    || fail "mise latest returned '$LATEST_OUT'; expected 2.0.0"

echo "PASS [$FORGE]: ls-remote lists 2.0.0 from the second page, omits 3.0.0, and latest returns 2.0.0" >&2
exit 0