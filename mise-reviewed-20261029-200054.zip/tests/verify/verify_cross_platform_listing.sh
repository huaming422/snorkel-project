#!/usr/bin/env bash
#
# Check availability of releases with downloads for different platforms.
# Separate repositories provide Linux downloads for the running CPU and
# macOS downloads for the other CPU. Both remain listed and resolve through latest.
#
# Each forge uses separate temporary directories, cache, and local server.

set -uo pipefail

if [[ $# -eq 0 ]]; then
    SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
    SCRIPT_PATH="$SCRIPT_DIR/$(basename -- "${BASH_SOURCE[0]}")"

    STATUS=0
    for forge in github forgejo gitlab; do
        bash "$SCRIPT_PATH" "$forge" || STATUS=1
    done
    exit "$STATUS"
fi

[[ $# -eq 1 ]] || {
    echo "FAIL: expected one forge name" >&2
    exit 1
}

FORGE="$1"
case "$FORGE" in
    github|forgejo|gitlab) ;;
    *)
        echo "FAIL: unsupported forge: $FORGE" >&2
        exit 1
        ;;
esac

MISE_BIN=""
for cand in \
    "${MISE_E2E_BIN:-}" \
    "${CARGO_TARGET_DIR:-/opt/cache/cargo-target}/debug/mise" \
    "/repo/mise/target/debug/mise" \
    "$(command -v mise 2>/dev/null || true)"; do
    if [[ -n "$cand" && -x "$cand" ]]; then
        MISE_BIN="$cand"
        break
    fi
done

[[ -n "$MISE_BIN" ]] || {
    echo "FAIL: could not locate a built mise binary" >&2
    exit 1
}

MISE_BIN="$(
    python3 -c 'import os, sys; print(os.path.abspath(sys.argv[1]))' "$MISE_BIN"
)" || exit 1

echo "checking $FORGE platform availability with mise binary: $MISE_BIN" >&2

WORK="$(mktemp -d "${TMPDIR:-/tmp}/mise-verify-xplat.XXXXXX")" || exit 1

cleanup() {
    if [[ -n "${SERVER_PID:-}" ]]; then
        kill "$SERVER_PID" 2>/dev/null || true
        wait "$SERVER_PID" 2>/dev/null || true
    fi
    rm -rf "$WORK" 2>/dev/null || true
}
trap cleanup EXIT

fail() {
    echo "FAIL [$FORGE, ${REPO:-setup}]: $*" >&2
    exit 1
}

export HOME="$WORK/home"
export MISE_DATA_DIR="$HOME/.local/share/mise"
export MISE_CACHE_DIR="$HOME/.cache/mise"
export MISE_CONFIG_DIR="$HOME/.config/mise"
export MISE_STATE_DIR="$HOME/.local/state/mise"
export MISE_SYSTEM_DIR="$WORK/etc/mise"
export MISE_TMP_DIR="$WORK/tmp"

WORKDIR="$WORK/workdir"
mkdir -p \
    "$HOME" \
    "$MISE_DATA_DIR" \
    "$MISE_CACHE_DIR" \
    "$MISE_CONFIG_DIR" \
    "$MISE_STATE_DIR" \
    "$MISE_SYSTEM_DIR" \
    "$MISE_TMP_DIR" \
    "$WORKDIR" || fail "could not create temporary directories"

export MISE_YES=1
export MISE_EXPERIMENTAL=1
export MISE_USE_VERSIONS_HOST=0
export MISE_USE_VERSIONS_HOST_TRACK=0

unset MISE_GITHUB_TOKEN GITHUB_TOKEN MISE_LIST_ALL_VERSIONS \
    2>/dev/null || true

cd "$WORKDIR" || fail "could not enter temporary working directory"

PORT_FILE="$WORK/port"

case "$(uname -m)" in
    x86_64|amd64)
        FIXTURE_NATIVE_ARCH="x86_64"
        FIXTURE_OTHER_ARCH="aarch64"
        ;;
    aarch64|arm64)
        FIXTURE_NATIVE_ARCH="aarch64"
        FIXTURE_OTHER_ARCH="x86_64"
        ;;
    *)
        fail "unsupported fixture architecture: $(uname -m)"
        ;;
esac

python3 - "$PORT_FILE" "$FORGE" \
    "$FIXTURE_NATIVE_ARCH" "$FIXTURE_OTHER_ARCH" <<'PY' &
import http.server
import json
import socketserver
import sys
from urllib.parse import unquote, urlsplit

port_file = sys.argv[1]
forge = sys.argv[2]
native_asset_arch = sys.argv[3]
foreign_asset_arch = sys.argv[4]


def make_release(major, name):
    tag = f"v{major}.0.0"
    timestamp = f"2026-{major:02d}-01T00:00:00Z"
    download_url = f"https://example.invalid/{tag}/{name}"

    if forge == "gitlab":
        return {
            "tag_name": tag,
            "description": "",
            "released_at": timestamp,
            "assets": {
                "sources": [
                    {
                        "format": "tar.gz",
                        "url": f"https://example.invalid/source/{tag}.tar.gz",
                    }
                ],
                "links": [
                    {
                        "id": major,
                        "name": name,
                        "url": download_url,
                        "direct_asset_url": download_url,
                        "link_type": "other",
                    }
                ],
            },
        }

    return {
        "id": major,
        "tag_name": tag,
        "draft": False,
        "prerelease": False,
        "created_at": timestamp,
        "published_at": timestamp,
        "assets": [
            {
                "id": major,
                "name": name,
                "uuid": f"asset-{major}",
                "browser_download_url": download_url,
                "url": f"https://example.invalid/api/assets/{major}",
            }
        ],
    }


RELEASES = {
    "acme/macos-only": make_release(
        4, f"tool-{foreign_asset_arch}-apple-darwin.tar.gz"
    ),
    "acme/linux-only": make_release(
        5, f"tool-{native_asset_arch}-unknown-linux-gnu.tar.gz"
    ),
}

API_PREFIX = {
    "github": "",
    "forgejo": "/api/v1",
    "gitlab": "/api/v4",
}[forge]


class Handler(http.server.BaseHTTPRequestHandler):
    def reply(self, payload):
        body = json.dumps(payload).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = unquote(urlsplit(self.path).path)

        for repo, release in RELEASES.items():
            if forge == "gitlab":
                endpoint = f"{API_PREFIX}/projects/{repo}/releases"
            else:
                endpoint = f"{API_PREFIX}/repos/{repo}/releases"

            if path == endpoint:
                self.reply([release])
                return

            if forge != "gitlab" and path == endpoint + "/latest":
                self.reply(release)
                return

        self.send_response(404)
        self.end_headers()

    def log_message(self, *args):
        pass


socketserver.TCPServer.allow_reuse_address = True
with socketserver.TCPServer(("127.0.0.1", 0), Handler) as httpd:
    with open(port_file, "w") as handle:
        handle.write(str(httpd.server_address[1]))
    httpd.serve_forever()
PY

SERVER_PID=$!

for _ in $(seq 1 60); do
    [[ -s "$PORT_FILE" ]] && break
    kill -0 "$SERVER_PID" 2>/dev/null \
        || fail "local API server exited before reporting its port"
    sleep 0.5
done

PORT="$(cat "$PORT_FILE" 2>/dev/null || true)"
[[ -n "$PORT" ]] || fail "local API server did not report a port"

case "$FORGE" in
    github) API_URL="http://127.0.0.1:$PORT" ;;
    forgejo) API_URL="http://127.0.0.1:$PORT/api/v1" ;;
    gitlab) API_URL="http://127.0.0.1:$PORT/api/v4" ;;
esac

for PLATFORM_CASE in macos-only linux-only; do
    REPO="acme/$PLATFORM_CASE"
    TOOL="$FORGE:$REPO[api_url=$API_URL]"

    case "$PLATFORM_CASE" in
        macos-only) EXPECTED_VERSION="4.0.0" ;;
        linux-only) EXPECTED_VERSION="5.0.0" ;;
    esac

    LIST_OUT="$("$MISE_BIN" ls-remote --no-versions-host "$TOOL")" \
        || fail "mise ls-remote exited non-zero"

    echo "[$FORGE, $REPO] ls-remote:" >&2
    echo "$LIST_OUT" >&2

    grep -Fxq "$EXPECTED_VERSION" <<<"$LIST_OUT" \
        || fail "release $EXPECTED_VERSION is missing from ls-remote"

    LATEST_OUT="$("$MISE_BIN" latest "$TOOL")" \
        || fail "mise latest exited non-zero"

    echo "[$FORGE, $REPO] latest: '$LATEST_OUT'" >&2

    [[ "$LATEST_OUT" == "$EXPECTED_VERSION" ]] \
        || fail "mise latest returned '$LATEST_OUT'; expected $EXPECTED_VERSION"
done

echo "PASS [$FORGE]: native Linux and foreign macOS releases remain listed and resolvable" >&2
exit 0
