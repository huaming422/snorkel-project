#!/usr/bin/env bash
#
# Check version availability with and without configured direct download URLs.
# Releases without attached downloads remain available when direct URLs
# are configured. Removing those URLs restores the ordinary version list.
#
# Queries for each scenario share a cache directory and keep the other
# tool options unchanged. Both configuration orders are exercised.
#
# GitHub and Forgejo also serve an older release on a second page.
# Each forge uses separate temporary directories and a local server.

set -uo pipefail

if [[ $# -eq 0 ]]; then
    SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
    SCRIPT_PATH="$SCRIPT_DIR/$(basename -- "${BASH_SOURCE[0]}")"

    STATUS=0
    for forge in github forgejo gitlab; do
        bash "$SCRIPT_PATH" "$forge" || STATUS=1
    done
    exit "$STATUS"
fi

[[ $# -eq 1 ]] || {
    echo "FAIL: expected one forge name" >&2
    exit 1
}

FORGE="$1"
case "$FORGE" in
    github|forgejo|gitlab) ;;
    *)
        echo "FAIL: unsupported forge: $FORGE" >&2
        exit 1
        ;;
esac

MISE_BIN=""
for cand in \
    "${MISE_E2E_BIN:-}" \
    "${CARGO_TARGET_DIR:-/opt/cache/cargo-target}/debug/mise" \
    "/repo/mise/target/debug/mise" \
    "$(command -v mise 2>/dev/null || true)"; do
    if [[ -n "$cand" && -x "$cand" ]]; then
        MISE_BIN="$cand"
        break
    fi
done

[[ -n "$MISE_BIN" ]] || {
    echo "FAIL: could not locate a built mise binary" >&2
    exit 1
}

MISE_BIN="$(
    python3 -c 'import os, sys; print(os.path.abspath(sys.argv[1]))' "$MISE_BIN"
)" || exit 1

echo "checking $FORGE direct URLs with mise binary: $MISE_BIN" >&2

WORK="$(mktemp -d "${TMPDIR:-/tmp}/mise-verify-direct.XXXXXX")" || exit 1

cleanup() {
    if [[ -n "${SERVER_PID:-}" ]]; then
        kill "$SERVER_PID" 2>/dev/null || true
        wait "$SERVER_PID" 2>/dev/null || true
    fi
    rm -rf "$WORK" 2>/dev/null || true
}
trap cleanup EXIT

fail() {
    echo "FAIL [$FORGE, ${SCENARIO:-setup}]: $*" >&2
    exit 1
}

export HOME="$WORK/home"
export MISE_DATA_DIR="$HOME/.local/share/mise"
export MISE_CACHE_DIR="$HOME/.cache/mise"
export MISE_CONFIG_DIR="$HOME/.config/mise"
export MISE_STATE_DIR="$HOME/.local/state/mise"
export MISE_SYSTEM_DIR="$WORK/etc/mise"
export MISE_TMP_DIR="$WORK/tmp"

WORKDIR="$WORK/workdir"
mkdir -p \
    "$HOME" \
    "$MISE_DATA_DIR" \
    "$MISE_CACHE_DIR" \
    "$MISE_CONFIG_DIR" \
    "$MISE_STATE_DIR" \
    "$MISE_SYSTEM_DIR" \
    "$MISE_TMP_DIR" \
    "$WORKDIR" || fail "could not create temporary directories"

export MISE_YES=1
export MISE_EXPERIMENTAL=1
export MISE_USE_VERSIONS_HOST=0
export MISE_USE_VERSIONS_HOST_TRACK=0
export MISE_TRUSTED_CONFIG_PATHS="$WORKDIR"

unset MISE_GITHUB_TOKEN GITHUB_TOKEN MISE_LIST_ALL_VERSIONS \
    2>/dev/null || true

cd "$WORKDIR" || fail "could not enter temporary working directory"

PORT_FILE="$WORK/port"

case "$(uname -m)" in
    x86_64|amd64)
        FIXTURE_ASSET_ARCH="x86_64"
        FIXTURE_NATIVE_ARCH="x64"
        FIXTURE_OTHER_ARCH="arm64"
        ;;
    aarch64|arm64)
        FIXTURE_ASSET_ARCH="aarch64"
        FIXTURE_NATIVE_ARCH="arm64"
        FIXTURE_OTHER_ARCH="x64"
        ;;
    *)
        fail "unsupported fixture architecture: $(uname -m)"
        ;;
esac

python3 - "$PORT_FILE" "$FORGE" "$FIXTURE_ASSET_ARCH" <<'PY' &
import http.server
import json
import socketserver
import sys
from urllib.parse import parse_qs, unquote, urlsplit

port_file = sys.argv[1]
forge = sys.argv[2]
asset_arch = sys.argv[3]


def make_release(major, has_download):
    tag = f"v{major}.0.0"
    timestamp = f"2026-{major:02d}-01T00:00:00Z"
    name = f"tool-{asset_arch}-unknown-linux-gnu.tar.gz"
    download_url = f"https://example.invalid/{tag}/{name}"

    if forge == "gitlab":
        links = []
        if has_download:
            links.append(
                {
                    "id": major,
                    "name": name,
                    "url": download_url,
                    "direct_asset_url": download_url,
                    "link_type": "other",
                }
            )

        return {
            "tag_name": tag,
            "description": "",
            "released_at": timestamp,
            "assets": {
                "sources": [
                    {
                        "format": "tar.gz",
                        "url": f"https://example.invalid/source/{tag}.tar.gz",
                    }
                ],
                "links": links,
            },
        }

    assets = []
    if has_download:
        assets.append(
            {
                "id": major,
                "name": name,
                "uuid": f"asset-{major}",
                "browser_download_url": download_url,
                "url": f"https://example.invalid/api/assets/{major}",
            }
        )

    return {
        "id": major,
        "tag_name": tag,
        "draft": False,
        "prerelease": False,
        "created_at": timestamp,
        "published_at": timestamp,
        "assets": assets,
    }


WITH_DOWNLOAD = make_release(2, True)
WITHOUT_DOWNLOAD = make_release(3, False)

REPOSITORIES = {
    f"acme/{order}-{prerelease}"
    for order in ("plain-first", "direct-first")
    for prerelease in ("false", "true")
}
REPOSITORIES.add("acme/paged-direct-first")

API_PREFIX = {
    "github": "",
    "forgejo": "/api/v1",
    "gitlab": "/api/v4",
}[forge]


class Handler(http.server.BaseHTTPRequestHandler):
    def reply(self, payload, link=None):
        body = json.dumps(payload).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        if link is not None:
            self.send_header("Link", link)
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urlsplit(self.path)
        path = unquote(parsed.path)
        page = parse_qs(parsed.query).get("page", ["1"])[0]

        for repo in REPOSITORIES:
            if forge == "gitlab":
                endpoint = f"{API_PREFIX}/projects/{repo}/releases"
            else:
                endpoint = f"{API_PREFIX}/repos/{repo}/releases"

            if forge != "gitlab" and path == endpoint + "/latest":
                self.reply(WITHOUT_DOWNLOAD)
                return

            if path != endpoint:
                continue

            if repo != "acme/paged-direct-first":
                self.reply([WITHOUT_DOWNLOAD, WITH_DOWNLOAD])
                return

            if page == "1":
                size_key = "limit" if forge == "forgejo" else "per_page"
                next_url = (
                    f"http://127.0.0.1:{self.server.server_address[1]}"
                    f"{endpoint}?{size_key}=100&page=2"
                )
                self.reply(
                    [WITHOUT_DOWNLOAD],
                    link=f'<{next_url}>; rel="next"',
                )
            elif page == "2":
                self.reply([WITH_DOWNLOAD])
            else:
                self.send_response(404)
                self.end_headers()
            return

        self.send_response(404)
        self.end_headers()

    def log_message(self, *args):
        pass


socketserver.TCPServer.allow_reuse_address = True
with socketserver.TCPServer(("127.0.0.1", 0), Handler) as httpd:
    with open(port_file, "w") as handle:
        handle.write(str(httpd.server_address[1]))
    httpd.serve_forever()
PY

SERVER_PID=$!

for _ in $(seq 1 60); do
    [[ -s "$PORT_FILE" ]] && break
    kill -0 "$SERVER_PID" 2>/dev/null \
        || fail "local API server exited before reporting its port"
    sleep 0.5
done

PORT="$(cat "$PORT_FILE" 2>/dev/null || true)"
[[ -n "$PORT" ]] || fail "local API server did not report a port"

case "$FORGE" in
    github) API_URL="http://127.0.0.1:$PORT" ;;
    forgejo) API_URL="http://127.0.0.1:$PORT/api/v1" ;;
    gitlab) API_URL="http://127.0.0.1:$PORT/api/v4" ;;
esac

write_config() {
    local DIRECT="$1"
    local PLATFORM="${2:-all}"

    cat > "$WORKDIR/mise.toml" <<EOF
[tools."$TOOL"]
version = "latest"
api_url = "$API_URL"
prerelease = $PRERELEASE
EOF

    [[ $? -eq 0 ]] || fail "could not write tool configuration"

    if [[ "$DIRECT" == true ]]; then
        if [[ "$PLATFORM" == all ]]; then
            cat >> "$WORKDIR/mise.toml" <<EOF

[tools."$TOOL".platforms]
linux-${FIXTURE_NATIVE_ARCH} = { url = "https://example.invalid/tool-linux-${FIXTURE_NATIVE_ARCH}.tar.gz" }
linux-${FIXTURE_OTHER_ARCH} = { url = "https://example.invalid/tool-linux-${FIXTURE_OTHER_ARCH}.tar.gz" }
macos-${FIXTURE_NATIVE_ARCH} = { url = "https://example.invalid/tool-macos-${FIXTURE_NATIVE_ARCH}.tar.gz" }
macos-${FIXTURE_OTHER_ARCH} = { url = "https://example.invalid/tool-macos-${FIXTURE_OTHER_ARCH}.tar.gz" }
EOF

            [[ $? -eq 0 ]] || fail "could not write direct download URLs"
        else
            case "$PLATFORM" in
                "linux-${FIXTURE_NATIVE_ARCH}"|"macos-${FIXTURE_OTHER_ARCH}") ;;
                *) fail "unsupported single-platform fixture: $PLATFORM" ;;
            esac

            cat >> "$WORKDIR/mise.toml" <<EOF

[tools."$TOOL".platforms]
$PLATFORM = { url = "https://example.invalid/tool-$PLATFORM.tar.gz" }
EOF

            [[ $? -eq 0 ]] || fail "could not write the direct download URL"
        fi
    fi

    return 0
}

check_availability() {
    local DIRECT="$1"
    local REQUIRE_OLDER="$2"
    local LIST_OUT LATEST_OUT EXPECTED_LATEST

    LIST_OUT="$("$MISE_BIN" ls-remote --no-versions-host "$TOOL")" \
        || fail "mise ls-remote exited non-zero"

    echo "[$FORGE, $SCENARIO, direct=$DIRECT] ls-remote:" >&2
    echo "$LIST_OUT" >&2

    if [[ "$REQUIRE_OLDER" == true ]]; then
        grep -Fxq "2.0.0" <<<"$LIST_OUT" \
            || fail "release 2.0.0 is missing from ls-remote"
    fi

    if [[ "$DIRECT" == true ]]; then
        grep -Fxq "3.0.0" <<<"$LIST_OUT" \
            || fail "release 3.0.0 is missing with direct URLs configured"
        EXPECTED_LATEST="3.0.0"
    else
        if grep -Fxq "3.0.0" <<<"$LIST_OUT"; then
            fail "release 3.0.0 is listed without direct URLs configured"
        fi
        EXPECTED_LATEST="2.0.0"
    fi

    LATEST_OUT="$("$MISE_BIN" latest "$TOOL")" \
        || fail "mise latest exited non-zero"

    echo "[$FORGE, $SCENARIO, direct=$DIRECT] latest: '$LATEST_OUT'" >&2

    [[ "$LATEST_OUT" == "$EXPECTED_LATEST" ]] \
        || fail "mise latest returned '$LATEST_OUT'; expected $EXPECTED_LATEST"
}

for PRERELEASE in false true; do
    for ORDER in plain-first direct-first; do
        TOOL="$FORGE:acme/$ORDER-$PRERELEASE"
        SCENARIO="$ORDER prerelease=$PRERELEASE"

        if [[ "$ORDER" == plain-first ]]; then
            STATES=(false true false)
        else
            STATES=(true false true)
        fi

        for DIRECT in "${STATES[@]}"; do
            write_config "$DIRECT"
            check_availability "$DIRECT" true
        done
    done
done

# A URL for one platform keeps the release available on every host.
for PLATFORM in "linux-${FIXTURE_NATIVE_ARCH}" "macos-${FIXTURE_OTHER_ARCH}"; do
    TOOL="$FORGE:acme/plain-first-false"
    PRERELEASE=false
    SCENARIO="single-platform URL=$PLATFORM prerelease=false"

    write_config true "$PLATFORM"
    check_availability true true

    write_config false
    check_availability false true
done

if [[ "$FORGE" != gitlab ]]; then
    TOOL="$FORGE:acme/paged-direct-first"
    PRERELEASE=true
    SCENARIO="paginated direct-first prerelease=true"

    for DIRECT in true false true; do
        write_config "$DIRECT"

        if [[ "$DIRECT" == true ]]; then
            check_availability "$DIRECT" false
        else
            check_availability "$DIRECT" true
        fi
    done
fi

echo "PASS [$FORGE]: version availability follows the configured direct URLs across repeated queries" >&2
exit 0