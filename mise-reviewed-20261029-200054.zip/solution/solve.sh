#!/bin/bash
set -euo pipefail
if ! command -v git >/dev/null 2>&1; then
    echo "Git is required and must be installed in the task image." >&2
    exit 1
fi
cd /repo/${REPO_NAME:?REPO_NAME must be set}
git apply /solution/oracle.patch
echo "Fix applied via oracle.patch"
