mod common;
mod validation_params;

use common::EditorHarness;
use crossterm::event::{Event, KeyCode, KeyEvent, KeyModifiers};
use red::{
    editor::{Action, SearchDirection},
    notification::Severity,
};
use validation_params::get_validation_test_cases;

#[tokio::test]
async fn search_wrap_moves_and_warns() {
    let cases = get_validation_test_cases();

    for tc in &cases {
        let content = tc.inputs["content"].as_str().unwrap();
        let start_x = tc.inputs["start_x"].as_u64().unwrap() as usize;
        let start_y = tc.inputs["start_y"].as_u64().unwrap() as usize;
        let search_kind = tc.inputs["search_kind"].as_str().unwrap();

        let expected_cursor_x = tc.expected["cursor_x"].as_u64().unwrap() as usize;
        let expected_cursor_y = tc.expected["cursor_y"].as_u64().unwrap() as usize;
        let expected_severity = tc.expected["severity"].as_str().unwrap();

        let mut harness = EditorHarness::with_content(content);
        harness
            .execute_action(Action::SetCursor(start_x, start_y))
            .await
            .unwrap();

        match search_kind {
            "word_forward" => {
                harness
                    .execute_action(Action::SearchWordUnderCursor)
                    .await
                    .unwrap();
            }
            "previous_after_word" => {
                harness
                    .execute_action(Action::SearchWordUnderCursor)
                    .await
                    .unwrap();
                harness
                    .execute_action(Action::FindPrevious)
                    .await
                    .unwrap();
            }
            "commit_forward" => {
                let pattern = tc.inputs["pattern"].as_str().unwrap();
                harness
                    .execute_action(Action::EnterSearch(SearchDirection::Forward))
                    .await
                    .unwrap();
                for ch in pattern.chars() {
                    harness
                        .execute_event(Event::Key(KeyEvent::new(
                            KeyCode::Char(ch),
                            KeyModifiers::NONE,
                        )))
                        .await
                        .unwrap();
                }
                harness
                    .execute_event(Event::Key(KeyEvent::new(
                        KeyCode::Enter,
                        KeyModifiers::NONE,
                    )))
                    .await
                    .unwrap();
            }
            other => panic!("unknown search_kind: {other}"),
        }

        let (cx, cy) = harness.cursor_position();
        assert_eq!(
            (cx, cy),
            (expected_cursor_x, expected_cursor_y),
            "case {}: cursor should move to the wrapped match, expected ({}, {}), got ({}, {})",
            tc.name,
            expected_cursor_x,
            expected_cursor_y,
            cx,
            cy
        );

        let notification = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .expect(&format!(
                "case {}: expected a notification record after wrapping search",
                tc.name
            ));

        let expected_sev = match expected_severity {
            "Warning" => Severity::Warning,
            "Info" => Severity::Info,
            "Error" => Severity::Error,
            other => panic!("unknown severity: {other}"),
        };
        assert_eq!(
            notification.severity,
            expected_sev,
            "case {}: expected severity {:?}, got {:?}",
            tc.name,
            expected_sev,
            notification.severity
        );
    }
}
