mod common;
mod validation_params;

use common::EditorHarness;
use red::{
    editor::Action,
    notification::{AttentionPolicy, Severity},
};
use validation_params::get_validation_test_cases;

#[tokio::test]
async fn context_lookup_empty_warns() {
    let cases = get_validation_test_cases();

    for tc in &cases {
        let content = tc.inputs["content"].as_str().unwrap();
        let action_name = tc.inputs["action"].as_str().unwrap();

        let expected_severity = tc.expected["severity"].as_str().unwrap();
        let expected_attention = tc.expected["attention"].as_str().unwrap();

        let mut harness = EditorHarness::with_content(content);

        let before_contents = harness.buffer_contents();

        let action = match action_name {
            "go_to_definition" => Action::GoToDefinition,
            "show_line_diagnostics" => Action::ShowLineDiagnostics,
            "next_inline_comment" => Action::NextInlineComment,
            "show_inline_comment" => Action::ShowInlineComment,
            other => panic!("unknown action: {other}"),
        };

        harness.execute_action(action).await.unwrap();

        let after_contents = harness.buffer_contents();
        assert_eq!(
            after_contents,
            before_contents,
            "case {}: buffer should not be modified by empty context lookup",
            tc.name
        );

        let notification = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .expect(&format!(
                "case {}: expected a notification record after empty context lookup {:?}",
                tc.name, action_name
            ));

        let expected_sev = match expected_severity {
            "Warning" => Severity::Warning,
            "Info" => Severity::Info,
            "Error" => Severity::Error,
            other => panic!("unknown severity: {other}"),
        };
        assert_eq!(
            notification.severity,
            expected_sev,
            "case {}: expected severity {:?}, got {:?}",
            tc.name,
            expected_sev,
            notification.severity
        );

        let expected_att = match expected_attention {
            "Quiet" => AttentionPolicy::Quiet,
            "IfMissed" => AttentionPolicy::IfMissed,
            "RequiresAcknowledgment" => AttentionPolicy::RequiresAcknowledgment,
            other => panic!("unknown attention policy: {other}"),
        };
        assert_eq!(
            notification.attention,
            expected_att,
            "case {}: expected attention {:?}, got {:?}",
            tc.name,
            expected_att,
            notification.attention
        );
    }
}
