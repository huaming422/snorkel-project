mod common;
mod validation_params;

use common::EditorHarness;
use crossterm::event::{Event, KeyCode, KeyEvent, KeyModifiers};
use red::{
    buffer::Buffer,
    config::Config,
    editor::{Action, SearchDirection},
    notification::Severity,
};
use validation_params::get_validation_test_cases;

fn default_key_config() -> Config {
    toml::from_str(include_str!("../default_config.toml")).unwrap()
}

async fn type_normal_keys(harness: &mut EditorHarness, keys: &str) {
    for key in keys.chars() {
        harness
            .execute_event(Event::Key(KeyEvent::new(
                KeyCode::Char(key),
                KeyModifiers::NONE,
            )))
            .await
            .unwrap();
    }
}

#[tokio::test]
async fn successful_commands_no_spurious_warning() {
    let cases = get_validation_test_cases();

    for tc in &cases {
        let content = tc.inputs["content"].as_str().unwrap();
        let start_x = tc.inputs["start_x"].as_u64().unwrap() as usize;
        let start_y = tc.inputs["start_y"].as_u64().unwrap() as usize;
        let trigger = tc.inputs["trigger"].as_str().unwrap();

        // EXPECTED: no_warning — must always be asserted unconditionally.
        let _no_warning = tc.expected["no_warning"].as_bool().unwrap();

        let config = default_key_config();
        let mut harness =
            EditorHarness::with_config(Buffer::new(None, content.to_string()), config);

        harness
            .execute_action(Action::SetCursor(start_x, start_y))
            .await
            .unwrap();

        match trigger {
            "commit_found" => {
                let pattern = tc.inputs["pattern"].as_str().unwrap();
                harness
                    .execute_action(Action::EnterSearch(SearchDirection::Forward))
                    .await
                    .unwrap();
                for ch in pattern.chars() {
                    harness
                        .execute_event(Event::Key(KeyEvent::new(
                            KeyCode::Char(ch),
                            KeyModifiers::NONE,
                        )))
                        .await
                        .unwrap();
                }
                harness
                    .execute_event(Event::Key(KeyEvent::new(
                        KeyCode::Enter,
                        KeyModifiers::NONE,
                    )))
                    .await
                    .unwrap();
            }
            "operator_found" => {
                let keys = tc.inputs["keys"].as_str().unwrap();
                type_normal_keys(&mut harness, keys).await;
            }
            other => panic!("unknown trigger: {other}"),
        }

        // EXPECTED: no_warning — either there are no notification records at all,
        // OR the most recent record's severity is NOT Severity::Warning.
        // A Warning-severity notification here is the failure mode the test guards against.
        let latest_severity = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .map(|n| n.severity);

        assert!(
            latest_severity != Some(Severity::Warning),
            "case {}: successful command should NOT emit a Warning notification, but got {:?}",
            tc.name,
            latest_severity
        );
    }
}
