mod common;
mod validation_params;

use common::EditorHarness;
use crossterm::event::{Event, KeyCode, KeyEvent, KeyModifiers};
use red::{
    buffer::Buffer,
    config::Config,
    editor::Action,
    notification::Severity,
};
use validation_params::get_validation_test_cases;

fn default_key_config() -> Config {
    toml::from_str(include_str!("../default_config.toml")).unwrap()
}

async fn type_normal_keys(harness: &mut EditorHarness, keys: &str) {
    for key in keys.chars() {
        harness
            .execute_event(Event::Key(KeyEvent::new(
                KeyCode::Char(key),
                KeyModifiers::NONE,
            )))
            .await
            .unwrap();
    }
}

#[tokio::test]
async fn operator_missing_target_no_edit_warns() {
    let cases = get_validation_test_cases();

    for tc in &cases {
        let content = tc.inputs["content"].as_str().unwrap();
        let keys = tc.inputs["keys"].as_str().unwrap();

        let expected_buffer = tc.expected["buffer"].as_str().unwrap();
        let expected_cursor_x = tc.expected["cursor_x"].as_u64().unwrap() as usize;
        let expected_cursor_y = tc.expected["cursor_y"].as_u64().unwrap() as usize;
        let expected_severity = tc.expected["severity"].as_str().unwrap();

        let config = default_key_config();
        let mut harness = EditorHarness::with_config(Buffer::new(None, content.to_string()), config);

        type_normal_keys(&mut harness, keys).await;

        let actual_buffer = harness.buffer_contents();
        assert_eq!(
            actual_buffer,
            expected_buffer,
            "case {}: buffer should be unedited, expected {:?}, got {:?}",
            tc.name,
            expected_buffer,
            actual_buffer
        );

        let (cx, cy) = harness.cursor_position();
        assert_eq!(
            (cx, cy),
            (expected_cursor_x, expected_cursor_y),
            "case {}: cursor should not move, expected ({}, {}), got ({}, {})",
            tc.name,
            expected_cursor_x,
            expected_cursor_y,
            cx,
            cy
        );

        let notification = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .expect(&format!(
                "case {}: expected a notification record after missing-target operator",
                tc.name
            ));

        let expected_sev = match expected_severity {
            "Warning" => Severity::Warning,
            "Info" => Severity::Info,
            "Error" => Severity::Error,
            other => panic!("unknown severity: {other}"),
        };
        assert_eq!(
            notification.severity,
            expected_sev,
            "case {}: expected severity {:?}, got {:?}",
            tc.name,
            expected_sev,
            notification.severity
        );

        assert!(
            !harness.is_waiting_for_key_sequence(),
            "case {}: editor should not be waiting for another key after failed operator/motion",
            tc.name
        );
    }
}
