mod common;
mod validation_params;

use common::EditorHarness;
use red::{
    editor::Action,
    notification::Severity,
};
use validation_params::get_validation_test_cases;

#[tokio::test]
async fn navigation_boundaries_warn() {
    let cases = get_validation_test_cases();

    for tc in &cases {
        let content = tc.inputs["content"].as_str().unwrap();
        let action_name = tc.inputs["action"].as_str().unwrap();

        let expected_severity = tc.expected["severity"].as_str().unwrap();

        let mut harness = EditorHarness::with_content(content);

        let action = match action_name {
            "jump_back" => Action::JumpBack,
            "undo" => Action::Undo,
            "redo" => Action::Redo,
            "window_left" => Action::MoveWindowLeft,
            other => panic!("unknown action: {other}"),
        };

        harness.execute_action(action).await.unwrap();

        let notification = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .expect(&format!(
                "case {}: expected a notification record after boundary action {:?}",
                tc.name, action_name
            ));

        let expected_sev = match expected_severity {
            "Warning" => Severity::Warning,
            "Info" => Severity::Info,
            "Error" => Severity::Error,
            other => panic!("unknown severity: {other}"),
        };
        assert_eq!(
            notification.severity,
            expected_sev,
            "case {}: expected severity {:?}, got {:?}",
            tc.name,
            expected_sev,
            notification.severity
        );
    }
}
