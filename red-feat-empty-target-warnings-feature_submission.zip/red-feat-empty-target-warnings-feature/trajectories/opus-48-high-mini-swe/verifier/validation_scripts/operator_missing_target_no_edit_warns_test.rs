mod common;
mod validation_params;

use common::EditorHarness;
use crossterm::event::{Event, KeyCode, KeyEvent, KeyModifiers};
use red::{
    buffer::Buffer,
    config::Config,
    notification::Severity,
};
use validation_params::get_validation_test_cases;

fn default_key_config() -> Config {
    toml::from_str(include_str!("../default_config.toml")).unwrap()
}

async fn type_normal_keys(harness: &mut EditorHarness, keys: &str) {
    for key in keys.chars() {
        harness
            .execute_event(Event::Key(KeyEvent::new(
                KeyCode::Char(key),
                KeyModifiers::NONE,
            )))
            .await
            .unwrap();
    }
}

#[tokio::test]
async fn test_operator_missing_target_no_edit_warns() {
    let cases = get_validation_test_cases();
    for tc in &cases {
        let content = tc.inputs["content"].as_str().unwrap();
        let keys = tc.inputs["keys"].as_str().unwrap();

        let config = default_key_config();
        let mut harness = EditorHarness::with_config(
            Buffer::new(None, content.to_string()),
            config,
        );

        // Type the key sequence
        type_normal_keys(&mut harness, keys).await;

        let expected_buffer = tc.expected["buffer"].as_str().unwrap();
        let expected_cursor_x = tc.expected["cursor_x"].as_u64().unwrap() as usize;
        let expected_cursor_y = tc.expected["cursor_y"].as_u64().unwrap() as usize;
        let expected_severity = tc.expected["severity"].as_str().unwrap();

        // 1. Buffer is unchanged
        let actual_buffer = harness.buffer_contents();
        assert_eq!(
            actual_buffer, expected_buffer,
            "case {}: buffer mismatch: expected {:?}, got {:?}",
            tc.name, expected_buffer, actual_buffer
        );

        // 2. Cursor did not move
        let (cx, cy) = harness.cursor_position();
        assert_eq!(
            (cx, cy),
            (expected_cursor_x, expected_cursor_y),
            "case {}: cursor mismatch: expected ({}, {}), got ({}, {})",
            tc.name,
            expected_cursor_x,
            expected_cursor_y,
            cx,
            cy
        );

        // 3. Latest notification has Warning severity
        let notification = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .unwrap_or_else(|| panic!("case {}: expected a notification record, got none", tc.name));

        let actual_severity = match notification.severity {
            Severity::Warning => "Warning",
            Severity::Info => "Info",
            Severity::Error => "Error",
            Severity::Success => "Success",
        };

        assert_eq!(
            actual_severity, expected_severity,
            "case {}: severity mismatch: expected {:?}, got {:?}",
            tc.name, expected_severity, actual_severity
        );

        // Also confirm editor is not waiting for more keys
        assert!(
            !harness.is_waiting_for_key_sequence(),
            "case {}: editor should not be waiting for a key sequence after failed operator/motion",
            tc.name
        );
    }
}
