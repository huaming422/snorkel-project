mod common;
mod validation_params;

use common::EditorHarness;
use red::{
    editor::Action,
    notification::Severity,
};
use validation_params::get_validation_test_cases;

#[tokio::test]
async fn test_navigation_boundaries_warn() {
    let cases = get_validation_test_cases();
    for tc in &cases {
        let content = tc.inputs["content"].as_str().unwrap();
        let action_name = tc.inputs["action"].as_str().unwrap();

        let mut harness = EditorHarness::with_content(content);

        // Map the action name to Action variant
        let action = match action_name {
            "jump_back" => Action::JumpBack,
            "undo" => Action::Undo,
            "redo" => Action::Redo,
            "window_left" => Action::MoveWindowLeft,
            other => panic!("Unknown action: {}", other),
        };

        harness.execute_action(action).await.unwrap();

        let expected_severity = tc.expected["severity"].as_str().unwrap();

        // Latest notification should have Warning severity
        let notification = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .unwrap_or_else(|| panic!("case {}: expected a notification record, got none", tc.name));

        let actual_severity = match notification.severity {
            Severity::Warning => "Warning",
            Severity::Info => "Info",
            Severity::Error => "Error",
            Severity::Success => "Success",
        };

        assert_eq!(
            actual_severity, expected_severity,
            "case {}: severity mismatch: expected {:?}, got {:?}",
            tc.name, expected_severity, actual_severity
        );
    }
}
