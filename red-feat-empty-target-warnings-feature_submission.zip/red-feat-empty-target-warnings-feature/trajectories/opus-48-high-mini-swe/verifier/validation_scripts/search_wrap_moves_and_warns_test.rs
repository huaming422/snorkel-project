mod common;
mod validation_params;

use common::EditorHarness;
use crossterm::event::{Event, KeyCode, KeyEvent, KeyModifiers};
use red::{
    editor::{Action, SearchDirection},
    notification::Severity,
};
use validation_params::get_validation_test_cases;

async fn type_normal_keys(harness: &mut EditorHarness, keys: &str) {
    for key in keys.chars() {
        harness
            .execute_event(Event::Key(KeyEvent::new(
                KeyCode::Char(key),
                KeyModifiers::NONE,
            )))
            .await
            .unwrap();
    }
}

#[tokio::test]
async fn test_search_wrap_moves_and_warns() {
    let cases = get_validation_test_cases();
    for tc in &cases {
        let content = tc.inputs["content"].as_str().unwrap();
        let start_x = tc.inputs["start_x"].as_u64().unwrap() as usize;
        let start_y = tc.inputs["start_y"].as_u64().unwrap() as usize;
        let search_kind = tc.inputs["search_kind"].as_str().unwrap();

        let mut harness = EditorHarness::with_content(content);

        // Place cursor at start position
        harness
            .execute_action(Action::SetCursor(start_x, start_y))
            .await
            .unwrap();

        match search_kind {
            "word_forward" => {
                // Search forward for the word under the cursor (wraps)
                harness
                    .execute_action(Action::SearchWordUnderCursor)
                    .await
                    .unwrap();
            }
            "previous_after_word" => {
                // First, search forward to establish pattern and land on earlier occurrence
                harness
                    .execute_action(Action::SearchWordUnderCursor)
                    .await
                    .unwrap();
                // Then search backward from the earlier occurrence (wraps past top)
                harness
                    .execute_action(Action::FindPrevious)
                    .await
                    .unwrap();
            }
            "commit_forward" => {
                let pattern = tc.inputs["pattern"].as_str().unwrap();
                // Enter search mode
                harness
                    .execute_action(Action::EnterSearch(SearchDirection::Forward))
                    .await
                    .unwrap();
                // Type the pattern
                type_normal_keys(&mut harness, pattern).await;
                // Commit with Enter
                harness
                    .execute_event(Event::Key(KeyEvent::new(
                        KeyCode::Enter,
                        KeyModifiers::NONE,
                    )))
                    .await
                    .unwrap();
            }
            other => panic!("Unknown search_kind: {}", other),
        }

        let expected_cursor_x = tc.expected["cursor_x"].as_u64().unwrap() as usize;
        let expected_cursor_y = tc.expected["cursor_y"].as_u64().unwrap() as usize;
        let expected_severity = tc.expected["severity"].as_str().unwrap();

        // 1. Cursor MOVED to the wrapped match
        let (cx, cy) = harness.cursor_position();
        assert_eq!(
            (cx, cy),
            (expected_cursor_x, expected_cursor_y),
            "case {}: cursor mismatch: expected ({}, {}), got ({}, {})",
            tc.name,
            expected_cursor_x,
            expected_cursor_y,
            cx,
            cy
        );

        // 2. Most recent notification has Warning severity (wrap notice)
        let notification = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .unwrap_or_else(|| panic!("case {}: expected a notification record, got none", tc.name));

        let actual_severity = match notification.severity {
            Severity::Warning => "Warning",
            Severity::Info => "Info",
            Severity::Error => "Error",
            Severity::Success => "Success",
        };

        assert_eq!(
            actual_severity, expected_severity,
            "case {}: severity mismatch: expected {:?}, got {:?}",
            tc.name, expected_severity, actual_severity
        );
    }
}
