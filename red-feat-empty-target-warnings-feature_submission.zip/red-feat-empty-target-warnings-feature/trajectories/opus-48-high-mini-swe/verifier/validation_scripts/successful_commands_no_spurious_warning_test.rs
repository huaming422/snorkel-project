mod common;
mod validation_params;

use common::EditorHarness;
use crossterm::event::{Event, KeyCode, KeyEvent, KeyModifiers};
use red::{
    buffer::Buffer,
    config::Config,
    editor::{Action, SearchDirection},
    notification::Severity,
};
use validation_params::get_validation_test_cases;

fn default_key_config() -> Config {
    toml::from_str(include_str!("../default_config.toml")).unwrap()
}

async fn type_normal_keys(harness: &mut EditorHarness, keys: &str) {
    for key in keys.chars() {
        harness
            .execute_event(Event::Key(KeyEvent::new(
                KeyCode::Char(key),
                KeyModifiers::NONE,
            )))
            .await
            .unwrap();
    }
}

#[tokio::test]
async fn test_successful_commands_no_spurious_warning() {
    let cases = get_validation_test_cases();
    for tc in &cases {
        let content = tc.inputs["content"].as_str().unwrap();
        let start_x = tc.inputs["start_x"].as_u64().unwrap() as usize;
        let start_y = tc.inputs["start_y"].as_u64().unwrap() as usize;
        let trigger = tc.inputs["trigger"].as_str().unwrap();

        let expected_no_warning = tc.expected["no_warning"].as_bool().unwrap();

        let config = default_key_config();
        let mut harness = EditorHarness::with_config(
            Buffer::new(None, content.to_string()),
            config,
        );

        // Place cursor at start position
        harness
            .execute_action(Action::SetCursor(start_x, start_y))
            .await
            .unwrap();

        match trigger {
            "commit_found" => {
                let pattern = tc.inputs["pattern"].as_str().unwrap();
                // Enter search mode
                harness
                    .execute_action(Action::EnterSearch(SearchDirection::Forward))
                    .await
                    .unwrap();
                // Type the pattern
                type_normal_keys(&mut harness, pattern).await;
                // Commit with Enter
                harness
                    .execute_event(Event::Key(KeyEvent::new(
                        KeyCode::Enter,
                        KeyModifiers::NONE,
                    )))
                    .await
                    .unwrap();
            }
            "operator_found" => {
                let keys = tc.inputs["keys"].as_str().unwrap();
                type_normal_keys(&mut harness, keys).await;
            }
            other => panic!("Unknown trigger: {}", other),
        }

        // Check no warning was emitted
        // Either no notifications at all, or the most recent is NOT Warning severity
        let has_warning = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .map(|n| matches!(n.severity, Severity::Warning))
            .unwrap_or(false);

        if expected_no_warning {
            assert!(
                !has_warning,
                "case {}: unexpected Warning notification was emitted on a successful command",
                tc.name
            );
        }
    }
}
