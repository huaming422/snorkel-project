mod common;
mod validation_params;

use common::EditorHarness;
use red::{
    editor::Action,
    notification::{AttentionPolicy, Severity},
};
use validation_params::get_validation_test_cases;

#[tokio::test]
async fn test_context_lookup_empty_warns() {
    let cases = get_validation_test_cases();
    for tc in &cases {
        let content = tc.inputs["content"].as_str().unwrap();
        let action_name = tc.inputs["action"].as_str().unwrap();

        let mut harness = EditorHarness::with_content(content);

        // Record buffer contents before the action
        let before_contents = harness.buffer_contents();

        // Map the action name to Action variant
        let action = match action_name {
            "go_to_definition" => Action::GoToDefinition,
            "show_line_diagnostics" => Action::ShowLineDiagnostics,
            "next_inline_comment" => Action::NextInlineComment,
            "show_inline_comment" => Action::ShowInlineComment,
            other => panic!("Unknown action: {}", other),
        };

        harness.execute_action(action).await.unwrap();

        let expected_severity = tc.expected["severity"].as_str().unwrap();
        let expected_attention = tc.expected["attention"].as_str().unwrap();

        // 1. A notification record exists with Warning severity
        let notification = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .unwrap_or_else(|| panic!("case {}: expected a notification record, got none", tc.name));

        let actual_severity = match notification.severity {
            Severity::Warning => "Warning",
            Severity::Info => "Info",
            Severity::Error => "Error",
            Severity::Success => "Success",
        };

        assert_eq!(
            actual_severity, expected_severity,
            "case {}: severity mismatch: expected {:?}, got {:?}",
            tc.name, expected_severity, actual_severity
        );

        // 2. That record's attention matches expected
        let actual_attention = match notification.attention {
            AttentionPolicy::Quiet => "Quiet",
            AttentionPolicy::IfMissed => "IfMissed",
            AttentionPolicy::RequiresAcknowledgment => "RequiresAcknowledgment",
        };

        assert_eq!(
            actual_attention, expected_attention,
            "case {}: attention mismatch: expected {:?}, got {:?}",
            tc.name, expected_attention, actual_attention
        );

        // Also confirm no side effect on buffer
        let after_contents = harness.buffer_contents();
        assert_eq!(
            after_contents, before_contents,
            "case {}: buffer was modified by context lookup",
            tc.name
        );
    }
}
