mod common;

use common::EditorHarness;
use red::{
    editor::Action,
    notification::{AttentionPolicy, Severity},
};

#[tokio::test]
async fn context_lookup_empty_warns() {
    // Case 1: go_to_definition — no LSP results (scratch buffer, no file path)
    {
        let mut harness = EditorHarness::with_content("alpha");
        let before = harness.buffer_contents();

        harness
            .execute_action(Action::GoToDefinition)
            .await
            .unwrap();

        // No side effect on buffer
        assert_eq!(
            harness.buffer_contents(),
            before,
            "go_to_definition: buffer should be unchanged"
        );

        let record = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .expect("go_to_definition: expected a notification record");
        assert_eq!(
            record.severity,
            Severity::Warning,
            "go_to_definition: expected Warning severity, got {:?}",
            record.severity
        );
        assert_eq!(
            record.attention,
            AttentionPolicy::Quiet,
            "go_to_definition: expected Quiet attention, got {:?}",
            record.attention
        );
    }

    // Case 2: show_line_diagnostics — no diagnostics
    {
        let mut harness = EditorHarness::with_content("alpha");
        let before = harness.buffer_contents();

        harness
            .execute_action(Action::ShowLineDiagnostics)
            .await
            .unwrap();

        // No side effect on buffer
        assert_eq!(
            harness.buffer_contents(),
            before,
            "show_line_diagnostics: buffer should be unchanged"
        );

        let record = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .expect("show_line_diagnostics: expected a notification record");
        assert_eq!(
            record.severity,
            Severity::Warning,
            "show_line_diagnostics: expected Warning severity, got {:?}",
            record.severity
        );
        assert_eq!(
            record.attention,
            AttentionPolicy::Quiet,
            "show_line_diagnostics: expected Quiet attention, got {:?}",
            record.attention
        );
    }

    // Case 3: next_inline_comment — no comments in buffer
    {
        let mut harness = EditorHarness::with_content("no comments\n");
        let before = harness.buffer_contents();

        harness
            .execute_action(Action::NextInlineComment)
            .await
            .unwrap();

        // No side effect on buffer
        assert_eq!(
            harness.buffer_contents(),
            before,
            "next_inline_comment: buffer should be unchanged"
        );

        let record = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .expect("next_inline_comment: expected a notification record");
        assert_eq!(
            record.severity,
            Severity::Warning,
            "next_inline_comment: expected Warning severity, got {:?}",
            record.severity
        );
        assert_eq!(
            record.attention,
            AttentionPolicy::Quiet,
            "next_inline_comment: expected Quiet attention, got {:?}",
            record.attention
        );
    }

    // Case 4: show_inline_comment — no comment at cursor
    {
        let mut harness = EditorHarness::with_content("no comments\n");
        let before = harness.buffer_contents();

        harness
            .execute_action(Action::ShowInlineComment)
            .await
            .unwrap();

        // No side effect on buffer
        assert_eq!(
            harness.buffer_contents(),
            before,
            "show_inline_comment: buffer should be unchanged"
        );

        let record = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .expect("show_inline_comment: expected a notification record");
        assert_eq!(
            record.severity,
            Severity::Warning,
            "show_inline_comment: expected Warning severity, got {:?}",
            record.severity
        );
        assert_eq!(
            record.attention,
            AttentionPolicy::Quiet,
            "show_inline_comment: expected Quiet attention, got {:?}",
            record.attention
        );
    }
}
