mod common;

use common::EditorHarness;
use crossterm::event::{Event, KeyCode, KeyEvent, KeyModifiers};
use red::{
    editor::{Action, SearchDirection},
    notification::Severity,
};

async fn type_keys(harness: &mut EditorHarness, keys: &str) {
    for key in keys.chars() {
        harness
            .execute_event(Event::Key(KeyEvent::new(
                KeyCode::Char(key),
                KeyModifiers::NONE,
            )))
            .await
            .unwrap();
    }
}

#[tokio::test]
async fn search_dead_end_warns() {
    // Case 1: repeat_no_pattern — no search entered yet, repeat search warns
    // inputs = { content = "alpha beta", start_x = 0, start_y = 0, trigger = "repeat_no_pattern", pattern = "" }
    // expected = { cursor_x = 0, cursor_y = 0, severity = "Warning" }
    {
        let mut harness = EditorHarness::with_content("alpha beta");
        harness
            .execute_action(Action::SetCursor(0, 0))
            .await
            .unwrap();

        // Repeat search with no prior pattern — should warn
        harness.execute_action(Action::RepeatSearch).await.unwrap();

        let (cx, cy) = harness.cursor_position();
        assert_eq!(
            (cx, cy),
            (0, 0),
            "repeat_no_pattern: cursor should stay at (0,0), got ({},{})",
            cx,
            cy
        );

        let record = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .expect("repeat_no_pattern: expected a notification record");
        assert_eq!(
            record.severity,
            Severity::Warning,
            "repeat_no_pattern: expected Warning severity, got {:?}",
            record.severity
        );
    }

    // Case 2: commit_missing — search for absent pattern warns, cursor stays put
    // inputs = { content = "alpha\nbeta", start_x = 0, start_y = 1, trigger = "commit_missing", pattern = "missing" }
    // expected = { cursor_x = 0, cursor_y = 1, severity = "Warning" }
    {
        let mut harness = EditorHarness::with_content("alpha\nbeta");
        // Cursor starts on row 1 per the spec
        harness
            .execute_action(Action::SetCursor(0, 1))
            .await
            .unwrap();

        // Enter search mode
        harness
            .execute_action(Action::EnterSearch(SearchDirection::Forward))
            .await
            .unwrap();

        // Type the pattern "missing" (not in buffer)
        type_keys(&mut harness, "missing").await;

        // Commit with Enter
        harness
            .execute_event(Event::Key(KeyEvent::new(
                KeyCode::Enter,
                KeyModifiers::NONE,
            )))
            .await
            .unwrap();

        let (cx, cy) = harness.cursor_position();
        assert_eq!(
            (cx, cy),
            (0, 1),
            "commit_missing: cursor should stay at (0,1), got ({},{})",
            cx,
            cy
        );

        let record = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .expect("commit_missing: expected a notification record");
        assert_eq!(
            record.severity,
            Severity::Warning,
            "commit_missing: expected Warning severity, got {:?}",
            record.severity
        );
    }
}
