mod common;

use common::EditorHarness;
use crossterm::event::{Event, KeyCode, KeyEvent, KeyModifiers};
use red::{
    editor::{Action, SearchDirection},
    notification::Severity,
};

async fn type_keys(harness: &mut EditorHarness, keys: &str) {
    for key in keys.chars() {
        harness
            .execute_event(Event::Key(KeyEvent::new(
                KeyCode::Char(key),
                KeyModifiers::NONE,
            )))
            .await
            .unwrap();
    }
}

#[tokio::test]
async fn search_wrap_moves_and_warns() {
    // Case 1: word_forward — search for word from the second occurrence, wraps to first
    // inputs = { content = "alpha beta alpha", start_x = 11, start_y = 0, search_kind = "word_forward" }
    // expected = { cursor_x = 0, cursor_y = 0, severity = "Warning" }
    // "alpha beta alpha" — start at second "alpha" (col 11), forward search wraps to col 0
    {
        let content = "alpha beta alpha";
        let mut harness = EditorHarness::with_content(content);
        harness
            .execute_action(Action::SetCursor(11, 0))
            .await
            .unwrap();

        harness
            .execute_action(Action::SearchWordUnderCursor)
            .await
            .unwrap();

        let (cx, cy) = harness.cursor_position();
        assert_eq!(
            (cx, cy),
            (0, 0),
            "word_forward: cursor should move to (0,0), got ({},{})",
            cx,
            cy
        );

        let record = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .expect("word_forward: expected a notification record");
        assert_eq!(
            record.severity,
            Severity::Warning,
            "word_forward: expected Warning severity on wrap, got {:?}",
            record.severity
        );
    }

    // Case 2: previous_after_word — search backward from first occurrence wraps to second
    // inputs = { content = "alpha beta alpha", start_x = 11, start_y = 0, search_kind = "previous_after_word" }
    // expected = { cursor_x = 11, cursor_y = 0, severity = "Warning" }
    // "alpha beta alpha" — start at second "alpha" (col 11),
    // first SearchWordUnderCursor wraps to col 0 (first "alpha"), then FindPrevious wraps to col 11
    {
        let content = "alpha beta alpha";
        let mut harness = EditorHarness::with_content(content);
        harness
            .execute_action(Action::SetCursor(11, 0))
            .await
            .unwrap();

        // Establish search pattern and land on first "alpha" via wrap
        harness
            .execute_action(Action::SearchWordUnderCursor)
            .await
            .unwrap();

        // Intermediate check: after SearchWordUnderCursor from col 11,
        // cursor should be at (0, 0) — the first "alpha"
        let (ix, iy) = harness.cursor_position();
        assert_eq!(
            (ix, iy),
            (0, 0),
            "previous_after_word setup: after SearchWordUnderCursor cursor should be at (0,0), got ({},{})",
            ix,
            iy
        );

        // FindPrevious from (0, 0) wraps past top to second occurrence at (11, 0)
        harness
            .execute_action(Action::FindPrevious)
            .await
            .unwrap();

        let (cx, cy) = harness.cursor_position();
        assert_eq!(
            (cx, cy),
            (11, 0),
            "previous_after_word: cursor should move to (11,0), got ({},{})",
            cx,
            cy
        );

        let record = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .expect("previous_after_word: expected a notification record");
        assert_eq!(
            record.severity,
            Severity::Warning,
            "previous_after_word: expected Warning severity on wrap, got {:?}",
            record.severity
        );
    }

    // Case 3: commit_forward — committed forward search for "beta" from col 11 wraps to "beta" at col 6
    // inputs = { content = "alpha beta alpha", start_x = 11, start_y = 0, search_kind = "commit_forward", pattern = "beta" }
    // expected = { cursor_x = 6, cursor_y = 0, severity = "Warning" }
    // "alpha beta alpha" — start at col 11 (after "beta"), forward search for "beta" wraps past BOTTOM to col 6
    {
        let content = "alpha beta alpha";
        let mut harness = EditorHarness::with_content(content);
        harness
            .execute_action(Action::SetCursor(11, 0))
            .await
            .unwrap();

        // Enter search mode
        harness
            .execute_action(Action::EnterSearch(SearchDirection::Forward))
            .await
            .unwrap();

        // Type the pattern "beta" (exists at col 6, before cursor at col 11)
        type_keys(&mut harness, "beta").await;

        // Commit with Enter
        harness
            .execute_event(Event::Key(KeyEvent::new(
                KeyCode::Enter,
                KeyModifiers::NONE,
            )))
            .await
            .unwrap();

        let (cx, cy) = harness.cursor_position();
        assert_eq!(
            (cx, cy),
            (6, 0),
            "commit_forward: cursor should move to (6,0), got ({},{})",
            cx,
            cy
        );

        let record = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .expect("commit_forward: expected a notification record");
        assert_eq!(
            record.severity,
            Severity::Warning,
            "commit_forward: expected Warning severity on wrap, got {:?}",
            record.severity
        );
    }
}
