mod common;

use common::EditorHarness;
use crossterm::event::{Event, KeyCode, KeyEvent, KeyModifiers};
use red::{
    buffer::Buffer,
    config::Config,
    editor::{Action, SearchDirection},
    notification::Severity,
};

fn default_key_config() -> Config {
    toml::from_str(include_str!("../default_config.toml")).unwrap()
}

async fn type_normal_keys(harness: &mut EditorHarness, keys: &str) {
    for key in keys.chars() {
        harness
            .execute_event(Event::Key(KeyEvent::new(
                KeyCode::Char(key),
                KeyModifiers::NONE,
            )))
            .await
            .unwrap();
    }
}

#[tokio::test]
async fn successful_commands_no_spurious_warning() {
    // Case 1: commit_found — search that finds a match without wrapping must not warn
    {
        let content = "alpha beta alpha";
        let mut harness = EditorHarness::with_content(content);
        harness
            .execute_action(Action::SetCursor(0, 0))
            .await
            .unwrap();

        // Enter search mode
        harness
            .execute_action(Action::EnterSearch(SearchDirection::Forward))
            .await
            .unwrap();

        // Type "beta" (exists at col 6, directly after cursor at 0 — no wrap needed)
        for key in "beta".chars() {
            harness
                .execute_event(Event::Key(KeyEvent::new(
                    KeyCode::Char(key),
                    KeyModifiers::NONE,
                )))
                .await
                .unwrap();
        }

        // Commit with Enter
        harness
            .execute_event(Event::Key(KeyEvent::new(
                KeyCode::Enter,
                KeyModifiers::NONE,
            )))
            .await
            .unwrap();

        // No Warning should have been emitted (either no record, or last record is not Warning)
        let no_warning = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .map(|record| record.severity != Severity::Warning)
            .unwrap_or(true);
        assert!(
            no_warning,
            "commit_found: successful search should not emit a Warning notification"
        );
    }

    // Case 2: operator_found — d% with present delimiter must not warn
    {
        let content = "alpha (beta) gamma";
        let mut harness = EditorHarness::with_config(
            Buffer::new(None, content.to_string()),
            default_key_config(),
        );
        harness
            .execute_action(Action::SetCursor(0, 0))
            .await
            .unwrap();

        type_normal_keys(&mut harness, "d%").await;

        // No Warning should have been emitted
        let no_warning = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .map(|record| record.severity != Severity::Warning)
            .unwrap_or(true);
        assert!(
            no_warning,
            "operator_found: successful d% should not emit a Warning notification"
        );
    }
}
