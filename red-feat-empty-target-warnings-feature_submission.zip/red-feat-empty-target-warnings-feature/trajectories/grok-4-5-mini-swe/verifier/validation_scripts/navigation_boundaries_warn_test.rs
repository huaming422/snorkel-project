mod common;

use common::EditorHarness;
use red::{
    editor::Action,
    notification::Severity,
};

#[tokio::test]
async fn navigation_boundaries_warn() {
    // Case 1: jump_back — already at start of jump list
    {
        let mut harness = EditorHarness::with_content("one\ntwo");
        harness.execute_action(Action::JumpBack).await.unwrap();

        let record = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .expect("jump_back: expected a notification record");
        assert_eq!(
            record.severity,
            Severity::Warning,
            "jump_back: expected Warning severity, got {:?}",
            record.severity
        );
    }

    // Case 2: undo — already at oldest change
    {
        let mut harness = EditorHarness::with_content("Hello World");
        harness.execute_action(Action::Undo).await.unwrap();

        let record = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .expect("undo: expected a notification record");
        assert_eq!(
            record.severity,
            Severity::Warning,
            "undo: expected Warning severity, got {:?}",
            record.severity
        );
    }

    // Case 3: redo — already at newest change
    {
        let mut harness = EditorHarness::with_content("Hello World");
        harness.execute_action(Action::Redo).await.unwrap();

        let record = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .expect("redo: expected a notification record");
        assert_eq!(
            record.severity,
            Severity::Warning,
            "redo: expected Warning severity, got {:?}",
            record.severity
        );
    }

    // Case 4: window_left — only one window, none to the left
    {
        let mut harness = EditorHarness::with_content("abcdef");
        harness
            .execute_action(Action::MoveWindowLeft)
            .await
            .unwrap();

        let record = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .expect("window_left: expected a notification record");
        assert_eq!(
            record.severity,
            Severity::Warning,
            "window_left: expected Warning severity, got {:?}",
            record.severity
        );
    }
}
