mod common;

use common::EditorHarness;
use crossterm::event::{Event, KeyCode, KeyEvent, KeyModifiers};
use red::{
    buffer::Buffer,
    config::Config,
    editor::Action,
    notification::Severity,
};

fn default_key_config() -> Config {
    toml::from_str(include_str!("../default_config.toml")).unwrap()
}

async fn type_normal_keys(harness: &mut EditorHarness, keys: &str) {
    for key in keys.chars() {
        harness
            .execute_event(Event::Key(KeyEvent::new(
                KeyCode::Char(key),
                KeyModifiers::NONE,
            )))
            .await
            .unwrap();
    }
}

#[tokio::test]
async fn operator_missing_target_no_edit_warns() {
    let cases: &[(&str, &str, usize, usize)] = &[
        // (content, keys, expected_cursor_x, expected_cursor_y)
        ("alpha beta", "%", 0, 0),
        ("alpha beta", "d%", 0, 0),
        ("alpha beta", "dt.", 0, 0),
        ("alpha beta", "f.", 0, 0),
    ];

    for &(content, keys, expected_x, expected_y) in cases {
        let mut harness = EditorHarness::with_config(
            Buffer::new(None, content.to_string()),
            default_key_config(),
        );

        type_normal_keys(&mut harness, keys).await;

        // 1. Buffer is unedited
        let actual_buffer = harness.buffer_contents();
        assert_eq!(
            actual_buffer, content,
            "keys={:?}: buffer should be unedited, got {:?}",
            keys, actual_buffer
        );

        // 2. Cursor did not move
        let (cx, cy) = harness.cursor_position();
        assert_eq!(
            (cx, cy),
            (expected_x, expected_y),
            "keys={:?}: cursor should stay at ({},{}), got ({},{})",
            keys,
            expected_x,
            expected_y,
            cx,
            cy
        );

        // 3. Severity is Warning
        let record = harness
            .editor
            .notifications()
            .records()
            .next_back()
            .expect(&format!(
                "keys={:?}: expected a notification record",
                keys
            ));
        assert_eq!(
            record.severity,
            Severity::Warning,
            "keys={:?}: expected Warning severity, got {:?}",
            keys,
            record.severity
        );

        // 4. Not waiting for more keys after a failed operator/motion
        assert!(
            !harness.is_waiting_for_key_sequence(),
            "keys={:?}: editor should not be waiting for more keys",
            keys
        );
    }
}
