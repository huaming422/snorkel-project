## Task

Red's feedback for commands that it accepts but then can't actually carry out, because there's nothing there to act on, is all over the place right now. Some of these cases quietly do nothing; others print an ordinary informational message, so the user never gets a consistent signal that the command just ran into a dead end.

Let's make all of these "nothing to do here" outcomes give the same kind of brief, non-intrusive warning instead, so the feedback reads the same no matter which command hit it. The commands themselves should keep behaving exactly as they do today; the only thing that changes is the feedback for the empty outcome.

## User stories / requirements

- When the user repeats a search without having entered a pattern yet, or searches for text that isn't anywhere in the buffer, Red shows a brief warning and leaves the cursor where it is, rather than silently doing nothing.
- When a search runs off the top or bottom of the buffer and wraps around to a match on the other side, Red still jumps the cursor to that match and also shows a brief notice that the search wrapped past the edge. The wrap still moves the cursor; only the notice is added.
- When the user runs an operator over a motion that matches nothing, such as delete-through an absent match or delete-to a character that doesn't appear, or runs the bare motion with no target, Red leaves the text and cursor untouched and shows a brief warning, with no partial edit and without waiting for more keys.
- When the user steps past either end of the jump list, undoes or redoes past the ends of the edit history, or tries to move to a window that isn't there, Red shows the same kind of brief warning, keeping whatever boundary wording it already uses.
- When the user asks for a definition, line diagnostics, or an inline comment and there's nothing to show, Red shows a brief warning instead of silently doing nothing or opening an empty view.
- When a search, operator, or motion succeeds (finds a match, moves the cursor, edits the buffer), Red does NOT emit a warning. The new warnings fire only on genuinely empty outcomes. Commands keep behaving exactly as they do today when there is a target.
