// Behavioral verifier: plugin_empty_result_warns + git_hunk_empty_result_warns
//
// Breadth coverage of the plugin-script stack. When a plugin flow resolves to
// an EMPTY final result, the plugin must surface the "nothing to act on"
// outcome as a brief warning through the host's pre-existing `PrintWarning`
// action — not as a plain `Print`, and not by opening an empty view. Two
// distinct plugin hook families are covered:
//   * the LSP flows in `plugins/lsp_symbols.hk` (document symbols, references),
//     whose results arrive by host-resolved request, and
//   * the Git hunk flow in `plugins/git.hk`, whose result is assembled from a
//     subprocess diff and a cursor/selection lookup (an empty hunk under the
//     cursor on a stage/unstage/reset action).
//
// Both drive the real `.hk` scripts through the public plugin `Runtime` +
// `ACTION_DISPATCHER` interfaces (the same surface the repo's own
// `src/plugin/runtime.rs` tests use), and assert the host contract
// `PluginRequest::Action(Action::PrintWarning(_))` — the sole warning primitive
// a plugin can call (established by the prior host-warning work). The specific
// message strings are the plugin's pre-existing user-facing text; only the
// action changes from `Print` to `PrintWarning`.

use red::config::PluginPermissions;
use red::editor::{Action, PluginRequest, ACTION_DISPATCHER};
use red::plugin::Runtime;
use serde_json::{json, Value};
use std::collections::HashMap;
use std::process::Command;
use std::time::{Duration, Instant};

// Load `plugins/lsp_symbols.hk` into a fresh runtime and satisfy its initial
// config handshake, reconstructed from public APIs (the repo's own equivalent
// test helper is `#[cfg(test)]`-private and therefore unreachable from an
// injected integration test). The path is relative to the crate root, where
// `cargo test` runs.
async fn load_lsp_symbols(runtime: &mut Runtime) {
    runtime
        .load_plugin(
            "lsp_symbols",
            include_str!("../plugins/lsp_symbols.hk"),
        )
        .await
        .expect("lsp_symbols plugin should load");

    // The plugin asks the host for its config on load; answer it.
    let config_request_id = match ACTION_DISPATCHER.recv_request() {
        PluginRequest::GetConfig { request_id, .. } => request_id,
        // `PluginRequest` / `Action` do not derive `Debug` in this repo, so the
        // repo's own runtime tests panic with a plain literal (no `{:?}`).
        _ => panic!("expected GetConfig on plugin load"),
    };
    runtime
        .resolve_request(
            config_request_id,
            json!({
                "value": {
                    "lsp_symbols": {
                        "icons": { "enabled": true, "overrides": {} }
                    }
                }
            }),
        )
        .await
        .expect("config resolve should succeed");
}

// An empty document-symbols payload (count == 0), mirroring the plugin's
// expected result shape: `{ "ok": true, "symbols": [] }`.
fn empty_symbol_payload() -> Value {
    json!({ "ok": true, "symbols": [] })
}

// An empty references payload (count == 0).
fn empty_reference_payload() -> Value {
    json!({
        "ok": true,
        "file": "src/main.rs",
        "position": { "line": 0, "character": 0 },
        "references": []
    })
}

// The dispatcher is a process-global static shared across the test binary, so
// clear any residue before each scenario (the repo's own runtime tests do the
// same via a `drain_requests` helper).
fn drain_requests() {
    while ACTION_DISPATCHER.try_recv_request().is_some() {}
}

// Drain any requests we don't care about and return the first
// `Action(PrintWarning(_))` message, failing if some other action is surfaced
// or no warning appears.
fn expect_print_warning(context: &str) -> String {
    loop {
        match ACTION_DISPATCHER.recv_request() {
            PluginRequest::Action(Action::PrintWarning(message)) => return message,
            PluginRequest::Action(Action::Print(message)) => panic!(
                "{context}: empty result surfaced as a plain Print(\"{message}\") \
                 instead of a warning"
            ),
            // `Action` has no `Debug` impl in this repo, so don't `{:?}` it.
            PluginRequest::Action(_) => {
                panic!("{context}: unexpected action on empty result")
            }
            // Bookkeeping requests (e.g. picker close) are fine to skip past.
            PluginRequest::ClosePicker { .. } => continue,
            // `PluginRequest` has no `Debug` impl either — panic with a literal.
            _ => panic!("{context}: expected a host action"),
        }
    }
}

#[tokio::test]
async fn plugin_empty_result_warns() {
    // ---- Document symbols: empty final result -> PrintWarning ----
    {
        drain_requests();
        let mut runtime = Runtime::new();
        load_lsp_symbols(&mut runtime).await;

        runtime
            .execute_command("LspDocumentSymbols")
            .await
            .expect("LspDocumentSymbols should dispatch");

        let request_id = match ACTION_DISPATCHER.recv_request() {
            PluginRequest::DocumentSymbols { request_id, .. } => request_id,
            _ => panic!("expected a DocumentSymbols request"),
        };
        runtime
            .resolve_request(request_id, empty_symbol_payload())
            .await
            .expect("document-symbols resolve should succeed");

        // The behavior under test is that the empty result is surfaced as a
        // `PrintWarning` action rather than a plain `Print` (enforced inside
        // `expect_print_warning`). The specific wording is the plugin's own
        // pre-existing, implementation-chosen text and is intentionally NOT
        // asserted here — the host contract is the warning action, not the string.
        let _message = expect_print_warning("document symbols");
    }

    // ---- References: empty final result -> PrintWarning ----
    {
        drain_requests();
        let mut runtime = Runtime::new();
        load_lsp_symbols(&mut runtime).await;

        runtime
            .execute_command("LspReferences")
            .await
            .expect("LspReferences should dispatch");

        // The references flow opens a loading picker, then issues the request.
        let _picker = match ACTION_DISPATCHER.recv_request() {
            PluginRequest::OpenCallbackPicker { handle, .. } => handle,
            _ => panic!("expected the references loading picker"),
        };
        let request_id = match ACTION_DISPATCHER.recv_request() {
            PluginRequest::References { request_id, .. } => request_id,
            _ => panic!("expected a References request"),
        };
        runtime
            .resolve_request(request_id, empty_reference_payload())
            .await
            .expect("references resolve should succeed");

        // On an empty result the flow closes the loading picker and warns;
        // expect_print_warning skips the ClosePicker bookkeeping request and
        // enforces that the surfaced action is `PrintWarning`, not `Print`. As
        // above, the pre-existing message text is implementation-chosen and not
        // asserted — the warning action is the host contract.
        let _message = expect_print_warning("references");
    }
}

// Pump any ready subprocess events back into the plugin as `process:<id>`
// notifications, the same relay the repo's own git runtime tests perform. The
// Git hunk flow spawns `git diff` and resumes on its stdout/exit events.
async fn pump_process_events(runtime: &mut Runtime) {
    for event in runtime.poll_process_events() {
        if let Some(process_id) = event
            .get("process_id")
            .and_then(Value::as_str)
            .map(str::to_string)
        {
            runtime
                .notify(&format!("process:{process_id}"), event)
                .await
                .expect("process event relay should succeed");
        }
    }
}

// Load `plugins/git.hk` and satisfy its three-request load handshake (cwd,
// full config, editor info), rooted at a real git worktree so the plugin's
// `git diff` subprocess can run. Returns nothing; leaves the runtime ready to
// accept hunk commands.
async fn load_git_plugin(runtime: &mut Runtime, root: &std::path::Path) {
    runtime
        .load_plugin("git", include_str!("../plugins/git.hk"))
        .await
        .expect("git plugin should load");

    let mut cwd_id = None;
    let mut config_id = None;
    let mut info_id = None;
    for _ in 0..3 {
        match ACTION_DISPATCHER.recv_request() {
            PluginRequest::GetConfig { request_id, key } if key.as_deref() == Some("cwd") => {
                cwd_id = Some(request_id);
            }
            PluginRequest::GetConfig {
                request_id,
                key: None,
            } => config_id = Some(request_id),
            PluginRequest::EditorInfo(request_id) => info_id = Some(request_id),
            // `PluginRequest` does not derive `Debug` in this repo.
            _ => panic!("unexpected plugin request during git load"),
        }
    }
    runtime
        .resolve_request(
            cwd_id.expect("git plugin should request cwd"),
            json!({ "value": root.display().to_string() }),
        )
        .await
        .expect("cwd resolve should succeed");
    runtime
        .resolve_request(
            config_id.expect("git plugin should request config"),
            json!({ "value": { "executable": "red", "plugin_config": {} } }),
        )
        .await
        .expect("config resolve should succeed");
    runtime
        .resolve_request(
            info_id.expect("git plugin should request editor info"),
            json!({
                "theme": {
                    "style": { "fg": null, "bg": null, "bold": false, "italic": false },
                    "ui_style": {
                        "muted": { "fg": null, "bg": null, "bold": false, "italic": false },
                        "popup_title": { "fg": null, "bg": null, "bold": false, "italic": false }
                    },
                    "colors": {}
                }
            }),
        )
        .await
        .expect("editor info resolve should succeed");
}

#[tokio::test]
async fn git_hunk_empty_result_warns() {
    drain_requests();

    // A committed file with no working-tree changes: a stage/unstage/reset hunk
    // action over it finds no hunk under the cursor — the empty-result branch
    // the fix must surface as a warning. tempdir + a real `git` repo mirrors
    // the repo's own git runtime tests.
    let repository = tempfile::tempdir().expect("tempdir");
    let root = repository.path();
    let file = root.join("tracked.txt");
    assert!(Command::new("git")
        .args(["init", "-q"])
        .current_dir(root)
        .status()
        .expect("git init")
        .success());
    let original = (1..=30)
        .map(|line| format!("line {line}\n"))
        .collect::<String>();
    std::fs::write(&file, &original).expect("write tracked file");
    assert!(Command::new("git")
        .args(["add", "tracked.txt"])
        .current_dir(root)
        .status()
        .expect("git add")
        .success());
    assert!(Command::new("git")
        .args([
            "-c",
            "user.name=Red Verifier",
            "-c",
            "user.email=red@example.test",
            "commit",
            "-qm",
            "initial",
        ])
        .current_dir(root)
        .status()
        .expect("git commit")
        .success());

    let mut runtime = Runtime::new_with_permissions(HashMap::from([(
        "git".to_string(),
        PluginPermissions {
            process: vec!["git".to_string()],
        },
    )]));
    load_git_plugin(&mut runtime, root).await;

    // Drive a hunk stage on the unchanged file. The flow runs
    // GetWindows -> `git diff` subprocess -> GetSelection -> GetCursorPosition,
    // then finds no hunk under the cursor and surfaces the empty outcome.
    runtime
        .execute_command("GitHunkStage")
        .await
        .expect("GitHunkStage should dispatch");

    let deadline = Instant::now() + Duration::from_secs(10);
    let outcome = loop {
        pump_process_events(&mut runtime).await;
        let mut outcome = None;
        while let Some(request) = ACTION_DISPATCHER.try_recv_request() {
            match request {
                PluginRequest::GetWindows { request_id } => {
                    runtime
                        .resolve_request(
                            request_id,
                            json!({
                                "windows": [{
                                    "buffer_path": file.display().to_string(),
                                    "buffer_index": 7,
                                    "active": true
                                }]
                            }),
                        )
                        .await
                        .expect("windows resolve");
                }
                PluginRequest::GetSelection { request_id } => {
                    runtime
                        .resolve_request(request_id, Value::Null)
                        .await
                        .expect("selection resolve");
                }
                PluginRequest::GetBufferText { request_id, .. } => {
                    runtime
                        .resolve_request(request_id, json!({ "text": original.clone() }))
                        .await
                        .expect("buffer text resolve");
                }
                PluginRequest::GetCursorPosition { request_id } => {
                    runtime
                        .resolve_request(request_id, json!({ "x": 0, "y": 0 }))
                        .await
                        .expect("cursor resolve");
                }
                // The empty-hunk outcome must surface through PrintWarning, not
                // a plain Print. The message text is the plugin's pre-existing,
                // implementation-chosen wording and is intentionally not asserted.
                PluginRequest::Action(Action::PrintWarning(_message)) => {
                    outcome = Some(Ok(()));
                }
                PluginRequest::Action(Action::Print(message)) => {
                    outcome = Some(Err(format!(
                        "empty hunk surfaced as a plain Print(\"{message}\") instead of a warning"
                    )));
                }
                _ => {}
            }
        }
        if let Some(outcome) = outcome {
            break outcome;
        }
        assert!(
            Instant::now() < deadline,
            "hunk action did not complete in time"
        );
        tokio::time::sleep(Duration::from_millis(10)).await;
    };

    if let Err(error) = outcome {
        panic!("git hunk empty result: {error}");
    }
}
