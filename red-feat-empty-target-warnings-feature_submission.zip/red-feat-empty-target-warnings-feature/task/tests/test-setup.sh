#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
#
# red is a single-crate Rust project. Its full dependency closure was baked into
# the image at the base commit (image Dockerfile blocks 5 and 7: `cargo fetch
# --locked` + `cargo build --locked --tests`), so this script only has to bring
# that closure online for the verifier's `cargo test` and fail fast on a cache
# miss. There are no services to start and no data to seed — the editor is
# exercised entirely in-process through the `red` crate's public test API.

cd /repo/red

# Force cargo offline so a cache miss fails fast here instead of reaching for
# crates.io. The smoke gate's offline fold sources this script inside
# `docker run --network none`; everything below must succeed with no network.
export CARGO_NET_OFFLINE=true

# Dependencies: offline-first against the image bake, logged online fallback.
if cargo fetch --locked --offline > /tmp/test-setup-fetch.log 2>&1; then
    echo "[offline-first] cargo deps satisfied from image"
elif CARGO_NET_OFFLINE=false cargo fetch --locked >> /tmp/test-setup-fetch.log 2>&1; then
    echo "[test-setup] cargo deps fetched online (image bake was stale)"
else
    echo "[test-setup] cargo fetch failed:" >&2
    tail -40 /tmp/test-setup-fetch.log >&2
    exit 1
fi

# Setup probe: compile the crate + test harness from the warm target cache so a
# cache miss surfaces now rather than mid-grade. Offline; no assertion logic.
if cargo build --locked --tests --offline > /tmp/test-setup-build.log 2>&1; then
    echo "[offline-first] test build satisfied from image cache"
else
    echo "[test-setup] offline test build failed:" >&2
    tail -60 /tmp/test-setup-build.log >&2
    exit 1
fi
