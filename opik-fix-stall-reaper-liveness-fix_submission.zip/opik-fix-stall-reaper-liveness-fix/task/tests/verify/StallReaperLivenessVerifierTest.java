package com.comet.opik.domain;

import com.comet.opik.api.ErrorInfo;
import com.comet.opik.api.ExperimentItem;
import com.comet.opik.api.ExperimentScore;
import com.comet.opik.api.ExperimentType;
import com.comet.opik.api.ExperimentUpdate;
import com.comet.opik.api.FeedbackScoreAverage;
import com.comet.opik.api.Optimization;
import com.comet.opik.api.OptimizationStatus;
import com.comet.opik.api.OptimizationStudioConfig;
import com.comet.opik.api.OptimizationUpdate;
import com.comet.opik.api.Trace;
import com.comet.opik.api.resources.utils.ClientSupportUtils;
import com.comet.opik.api.resources.utils.TestUtils;
import com.comet.opik.api.resources.utils.WireMockUtils;
import com.comet.opik.api.resources.utils.resources.ExperimentResourceClient;
import com.comet.opik.api.resources.utils.resources.OptimizationResourceClient;
import com.comet.opik.api.resources.utils.resources.TraceResourceClient;
import com.comet.opik.extensions.DropwizardAppExtensionProvider;
import com.comet.opik.extensions.RegisterApp;
import com.comet.opik.podam.PodamFactoryUtils;
import com.comet.opik.utils.ClickHouseDateTimeFormat;
import com.comet.opik.utils.JsonUtils;
import com.google.inject.Injector;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.redisson.api.RedissonReactiveClient;
import ru.vyarus.dropwizard.guice.test.ClientSupport;
import ru.vyarus.dropwizard.guice.test.jupiter.ext.TestDropwizardAppExtension;
import uk.co.jemos.podam.api.PodamFactory;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

import static com.comet.opik.api.resources.utils.AuthTestUtils.mockTargetWorkspace;
import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;

/**
 * Behavioural verifier for opik-fix-stall-reaper-liveness.
 *
 * <p>The reported symptoms are: optimization "studio" runs that spin forever (a
 * healthy, still-progressing run gets marked failed, or a genuinely dead one is
 * never marked failed), and runs that vanish — a run that exists returns
 * not-found from the API. This class reproduces both through the backend's stable
 * public surface and asserts the corrected behaviour.
 *
 * <p>Everything is driven through pre-existing interfaces so any correct fix
 * passes and only a broken reaper / run-fetch fails:
 * <ul>
 *   <li>the optimization / experiment / trace HTTP resource clients
 *       (create / upsert / get / find / update);</li>
 *   <li>the reconcile entry point on the Guice-injected {@code OptimizationService}
 *       — the same method the scheduled job calls, invoked directly so each case
 *       is deterministic instead of waiting on wall-clock;</li>
 *   <li>the worker's cancellation channel in Redis, read through the injected
 *       {@code RedissonReactiveClient}.</li>
 * </ul>
 *
 * <p>The only raw-ClickHouse writes are timestamps the HTTP API stamps
 * server-side (a backdated run start, an old trial row) and a raw
 * {@code experiment_scores} JSON string the typed API cannot express — the state
 * older or foreign writers can leave in the column. No assertion inspects a
 * reference-solution query, SQL identifier, or private symbol.
 *
 * <p>The reconcile method takes two synthetic timeouts per case:
 * {@link #IMMEDIATE a zero timeout} makes any run of that status eligible, and
 * {@link #NEVER a 7-day timeout} makes nothing eligible, so a case targets
 * exactly the transition it names without sleeping.
 */
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@ExtendWith(DropwizardAppExtensionProvider.class)
class StallReaperLivenessVerifierTest {

    private static final Duration IMMEDIATE = Duration.ZERO;
    private static final Duration NEVER = Duration.ofDays(7);
    private static final Duration LOOKBACK_MARGIN = Duration.ofDays(7);
    private static final int BATCH_SIZE = 100;

    private static final String API_KEY = UUID.randomUUID().toString();
    private static final String WORKSPACE_ID = UUID.randomUUID().toString();
    private static final String TEST_WORKSPACE_NAME = "workspace" + RandomStringUtils.secure().nextAlphanumeric(36);
    private static final String USER = "user-" + RandomStringUtils.secure().nextAlphanumeric(36);

    private static final String ANALYTICS_DB = "opik";

    private final WireMockUtils.WireMockRuntime wireMock;

    @RegisterApp
    private final TestDropwizardAppExtension APP;

    {
        wireMock = WireMockUtils.startWireMock();
        NativeServiceAppExtensionShim.runMigrations();
        APP = NativeServiceAppExtensionShim.newAppExtension(wireMock.runtimeInfo());
    }

    private final PodamFactory podamFactory = PodamFactoryUtils.newPodamFactory();

    private OptimizationResourceClient optimizationResourceClient;
    private ExperimentResourceClient experimentResourceClient;
    private TraceResourceClient traceResourceClient;
    private OptimizationService optimizationService;
    private Injector injector;

    @BeforeAll
    void beforeAll(ClientSupport client, OptimizationService optimizationService, Injector injector) {
        var baseURI = TestUtils.getBaseUrl(client);
        ClientSupportUtils.config(client);

        this.optimizationResourceClient = new OptimizationResourceClient(client, baseURI, podamFactory);
        this.experimentResourceClient = new ExperimentResourceClient(client, baseURI, podamFactory);
        this.traceResourceClient = new TraceResourceClient(client, baseURI);
        this.optimizationService = optimizationService;
        this.injector = injector;

        mockTargetWorkspace(wireMock.server(), API_KEY, TEST_WORKSPACE_NAME, WORKSPACE_ID, USER);
    }

    // ================================================================
    // Symptom 1 — progress-aware liveness (eternal spinner, both directions)
    // ================================================================

    @Test
    @DisplayName("crit_progress_liveness: a stale-row run with recent trial progress survives; without it, it is reaped")
    void progressAwareLiveness() {
        // Same stale row timestamp (1h old, far past the 5-minute timeout) in both halves; the ONLY
        // difference is whether a trial experiment was created inside the window. A timeout-only fix
        // cannot keep the first run alive.
        var alive = seedBackdatedRunningStudioRun(Duration.ofHours(1));
        createTrialExperiment(alive);

        var dead = seedBackdatedRunningStudioRun(Duration.ofHours(1));

        reconcile(NEVER, Duration.ofMinutes(5), BATCH_SIZE);

        assertThat(statusOf(alive)).isEqualTo(OptimizationStatus.RUNNING);
        assertThat(statusOf(dead)).isEqualTo(OptimizationStatus.ERROR);
    }

    @Test
    @DisplayName("crit_progress_liveness: item-level progress within a long single trial keeps a run alive")
    void progressFromItemWithinLongTrial() {
        var id = seedBackdatedRunningStudioRun(Duration.ofHours(1));
        // The trial experiment row is itself old (backdated an hour), but items keep arriving as dataset
        // items are evaluated — the long-single-trial shape. Only item-level progress can keep this alive.
        var experimentId = createBackdatedTrialExperiment(id, Duration.ofHours(1));
        createExperimentItem(experimentId, true);

        reconcile(NEVER, Duration.ofMinutes(5), BATCH_SIZE);

        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.RUNNING);
    }

    @Test
    @DisplayName("crit_progress_liveness: progress correlates per-run — a healthy run's trial does not save a stale one")
    void progressDoesNotLeakAcrossRuns() {
        var stale = seedBackdatedRunningStudioRun(Duration.ofHours(1));
        var healthy = seedBackdatedRunningStudioRun(Duration.ofHours(1));
        createTrialExperiment(healthy);

        reconcile(NEVER, Duration.ofMinutes(5), BATCH_SIZE);

        assertThat(statusOf(stale)).isEqualTo(OptimizationStatus.ERROR);
        assertThat(statusOf(healthy)).isEqualTo(OptimizationStatus.RUNNING);
    }

    @Test
    @DisplayName("crit_progress_liveness: a stale INITIALIZED run with trial progress is not killed (failed callback != dead)")
    void initializedRunWithProgressSurvives() {
        var id = seedBackdatedInitializedStudioRun(Duration.ofHours(1));
        createTrialExperiment(id);

        // An INITIALIZED run with trial rows means a mark_running callback was lost while the worker did
        // real work — not a run that failed to start. The progress veto must cover INITIALIZED too.
        reconcile(IMMEDIATE, NEVER, BATCH_SIZE);

        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.INITIALIZED);
    }

    @Test
    @DisplayName("crit_progress_liveness: a stale INITIALIZED run with no progress is still reaped")
    void initializedRunWithoutProgressIsReaped() {
        var id = seedBackdatedInitializedStudioRun(Duration.ofHours(1));

        reconcile(IMMEDIATE, IMMEDIATE, BATCH_SIZE);

        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.ERROR);
    }

    @Test
    @DisplayName("crit_liveness_clock_not_restamped: updating an old trial does not refresh liveness; run still reaped")
    void updatingOldTrialDoesNotRefreshLiveness() {
        // The run's own row must read as stale (backdated 1h) so it is a reap candidate under the 5m
        // running timeout; otherwise a fresh-row run is never scanned and the "still reaped" claim is
        // vacuous. Its only possible rescue is recent trial progress — which the old (then renamed)
        // trial must not supply.
        var id = seedBackdatedRunningStudioRun(Duration.ofHours(1));
        var experimentId = createBackdatedTrialExperiment(id, Duration.ofHours(1));

        // Renaming the (old) trial must not re-stamp its created_at into the window — created_at is the
        // liveness clock and must be carried forward on update, not re-defaulted. A regression here would
        // keep every dead run alive until the hard ceiling.
        experimentResourceClient.updateExperiment(experimentId,
                ExperimentUpdate.builder().name("renamed-after-the-window").build(),
                API_KEY, TEST_WORKSPACE_NAME, 204);

        reconcile(NEVER, Duration.ofMinutes(5), BATCH_SIZE);

        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.ERROR);
    }

    // ================================================================
    // Hard ceiling — independent of progress
    // ================================================================

    @Test
    @DisplayName("crit_hard_ceiling: a RUNNING run past the ceiling is reaped despite fresh progress, citing the ceiling")
    void runningRunPastHardCeilingIsReaped() {
        var id = seedStudioRun(OptimizationStatus.RUNNING);
        createTrialExperiment(id);
        // Started well in the past, but the row was written a moment ago — the state a metadata PATCH /
        // re-upsert leaves. Fresh progress AND a fresh row timestamp, so no progress-based or
        // row-timestamp-based rule can reap this: only a ceiling measured from the run's creation can.
        // The backdate exceeds any ceiling a correct fix could be running with here — the per-call ceiling
        // passed below for a design that takes one, or the creation-measured ceiling a design that reads it
        // from configuration enforces (the test harness supplies a bounded configured ceiling). A design
        // that measures the ceiling from the row's last-updated timestamp instead, or has no ceiling at
        // all, cannot reap this run — which is exactly the discrimination.
        backdateRunStart(id, Duration.ofHours(72));

        // initializedTimeout=NEVER and runningTimeout=5m with fresh progress present means the progress
        // veto neutralises the 5m timeout, so the ONLY path to ERROR is the hard ceiling firing against
        // the long-past start. Status alone proves the ceiling wins over the progress veto — no need to pin
        // the (solution-chosen) wording of the failure message to prove the cause.
        reconcile(NEVER, Duration.ofMinutes(5), Duration.ofHours(1), BATCH_SIZE);

        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.ERROR);
    }

    @Test
    @DisplayName("crit_hard_ceiling: an INITIALIZED run past the ceiling is reaped despite progress, not 'failed to start'")
    void initializedRunPastHardCeilingIsReaped() {
        var id = seedStudioRun(OptimizationStatus.INITIALIZED);
        createTrialExperiment(id);
        // See runningRunPastHardCeilingIsReaped: the backdate exceeds any ceiling a correct fix runs with
        // here (the per-call ceiling below, or a bounded creation-measured ceiling read from configuration),
        // while a row-timestamp-measured or ceiling-less design cannot reap it.
        backdateRunStart(id, Duration.ofHours(72));

        // Both timeouts NEVER, so neither the initialized branch nor the running-progress branch can reap
        // this; with fresh progress AND a fresh row timestamp, only the ceiling against the long-past
        // start can. Status alone proves the ceiling branch wins over the INITIALIZED branch.
        reconcile(NEVER, NEVER, Duration.ofHours(1), BATCH_SIZE);

        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.ERROR);
    }

    // ================================================================
    // created_at semantics across the upsert
    // ================================================================

    @Test
    @DisplayName("crit_created_at_preserved: a plain re-upsert preserves the run's creation time")
    void reUpsertPreservesCreatedAt() {
        var optimization = optimizationResourceClient.createPartialOptimization()
                .studioConfig(studioConfig())
                .errorInfo(null)
                .build();
        var id = optimizationResourceClient.upsert(optimization, API_KEY, TEST_WORKSPACE_NAME);
        var createdAt = optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200).createdAt();

        optimizationResourceClient.upsert(optimization.toBuilder().id(id).build(), API_KEY, TEST_WORKSPACE_NAME);

        // Without carrying created_at over the full-row replace, the column DEFAULT re-stamps it every
        // write — which both lies about run start and lets the ceiling drift forward forever.
        assertThat(optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200).createdAt())
                .isEqualTo(createdAt);
    }

    @Test
    @DisplayName("crit_restart_resets_created_at: restarting a terminal run resets created_at and clears the old failure")
    void restartFromTerminalStatusResetsCreatedAtAndErrorInfo() {
        var id = seedStudioRun(OptimizationStatus.RUNNING);
        reconcile(NEVER, IMMEDIATE, BATCH_SIZE);
        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.ERROR);
        var reaped = optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200);
        assertThat(reaped.errorInfo()).isNotNull();
        // The first attempt started well beyond any ceiling configured below.
        backdateRunStart(id, Duration.ofHours(48));

        // Reusing the id with a non-terminal status is a RESTART (SDK job redelivery). Same datasetName
        // and name on purpose so dedup merges onto the same row; createdAt/lastUpdatedAt left null to
        // model what the SDK actually sends.
        optimizationResourceClient.upsert(optimizationResourceClient.createPartialOptimization()
                .id(id)
                .datasetName(reaped.datasetName())
                .name(reaped.name())
                .status(OptimizationStatus.RUNNING)
                .studioConfig(studioConfig())
                .errorInfo(null)
                .createdAt(null)
                .lastUpdatedAt(null)
                .build(), API_KEY, TEST_WORKSPACE_NAME);

        var restarted = optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200);
        // Inheriting the first attempt's 48h-old clock would put the restart past the ceiling immediately;
        // it must start fresh.
        assertThat(restarted.createdAt()).isAfter(Instant.now().minus(Duration.ofHours(1)));
        assertThat(restarted.errorInfo()).isNull();

        // And with a 24h ceiling the freshly-restarted run is not reaped.
        reconcile(NEVER, NEVER, Duration.ofHours(24), BATCH_SIZE);
        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.RUNNING);
    }

    // ================================================================
    // Structured failure reporting + supersede / cancel semantics
    // ================================================================

    @Test
    @DisplayName("crit_structured_error_info: a reaped run carries structured error_info, not only a log line")
    void reapedRunCarriesStructuredErrorInfo() {
        var id = seedStudioRun(OptimizationStatus.RUNNING);
        // The seed leaves errorInfo null, so everything below is the reaper's own write.
        assertThat(optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200).errorInfo()).isNull();

        reconcile(NEVER, IMMEDIATE, BATCH_SIZE);

        var reaped = optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200);
        assertThat(reaped.status()).isEqualTo(OptimizationStatus.ERROR);
        // The contract is that the platform records a STRUCTURED failure the UI can render
        // (error_info.message is what the UI prefers over a studio-log line) — not merely flipping the
        // status. The provable, non-coupling assertion is "a populated error_info with a human-readable
        // message": the exact type token, message wording, and traceback text are the solving author's
        // choice, so pinning any of them would reject a valid fix that phrases them differently. The
        // seed verified error_info was null beforehand, so a non-null populated message here can only be
        // the reaper's own structured write.
        assertThat(reaped.errorInfo()).isNotNull();
        assertThat(reaped.errorInfo().message()).isNotBlank();
    }

    @Test
    @DisplayName("crit_system_failure_superseded: a worker mark_running after a wrongful reap restores the run and clears it")
    void workerReportSupersedesPlatformDetectedFailure() {
        var id = seedStudioRun(OptimizationStatus.INITIALIZED);

        // Queue-depth case: a submission behind a full queue looks identical to one whose worker never
        // started, and is reaped on the initialized branch.
        reconcile(IMMEDIATE, IMMEDIATE, BATCH_SIZE);
        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.ERROR);

        // The worker then dequeues it and calls mark_running. The platform's guess must yield.
        transition(id, OptimizationStatus.RUNNING);

        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.RUNNING);
        // The recorded reason described a failure that did not happen; nothing else clears it.
        assertThat(optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200).errorInfo()).isNull();

        transition(id, OptimizationStatus.COMPLETED);
        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.COMPLETED);
    }

    @Test
    @DisplayName("crit_worker_failure_not_superseded: a worker-reported failure is not overwritten by a later report")
    void workerReportedFailureIsNotSuperseded() {
        var id = seedStudioRun(OptimizationStatus.RUNNING);

        // A failure the WORKER reported is a real outcome, not the platform's guess, so it keeps winning.
        optimizationResourceClient.update(id, OptimizationUpdate.builder()
                .status(OptimizationStatus.ERROR)
                .errorInfo(ErrorInfo.builder()
                        .exceptionType("ValueError")
                        .message("the optimizer raised")
                        .traceback("Traceback (most recent call last): ...")
                        .build())
                .build(), API_KEY, TEST_WORKSPACE_NAME, 204);

        transition(id, OptimizationStatus.RUNNING);

        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.ERROR);
    }

    @Test
    @DisplayName("crit_worker_failure_not_superseded: a user cancellation is not overwritten by a later worker report")
    void cancellationIsNotSuperseded() {
        var id = seedStudioRun(OptimizationStatus.RUNNING);
        transition(id, OptimizationStatus.CANCELLED);

        // CANCELLED is the user's decision and outranks anything the worker says afterwards.
        transition(id, OptimizationStatus.RUNNING);

        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.CANCELLED);
    }

    @Test
    @DisplayName("crit_reaped_run_cancellable: a wrongly reaped run can still be cancelled and fires the Redis signal")
    void systemDetectedFailureRemainsCancellable() {
        var id = seedStudioRun(OptimizationStatus.RUNNING);
        reconcile(NEVER, IMMEDIATE, BATCH_SIZE);
        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.ERROR);

        // The reap may have been wrong and the worker may still be burning budget, so Cancel must be
        // accepted for this terminal status rather than rejected with the usual 409.
        transition(id, OptimizationStatus.CANCELLED);
        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.CANCELLED);

        // The status flip alone is not enough: opik:cancel:<id> is the worker's only cancellation
        // channel. Accepting the request while skipping the signal would flip the UI and let the
        // subprocess spend the full budget.
        assertThat(injector.getInstance(RedissonReactiveClient.class)
                .getBucket("opik:cancel:" + id).isExists().block()).isTrue();
    }

    @Test
    @DisplayName("crit_reaped_run_cancellable: a worker-reported failure stays uncancellable (409)")
    void workerReportedFailureIsNotCancellable() {
        var id = seedStudioRun(OptimizationStatus.RUNNING);
        optimizationResourceClient.update(id, OptimizationUpdate.builder()
                .status(OptimizationStatus.ERROR)
                .errorInfo(ErrorInfo.builder()
                        .exceptionType("ValueError")
                        .message("the optimizer raised")
                        .traceback("Traceback (most recent call last): ...")
                        .build())
                .build(), API_KEY, TEST_WORKSPACE_NAME, 204);

        // A failure the worker reported is a real outcome — there is nothing left to stop, so the
        // pre-existing 409 must still apply.
        optimizationResourceClient.update(id, OptimizationUpdate.builder()
                .status(OptimizationStatus.CANCELLED).build(), API_KEY, TEST_WORKSPACE_NAME, 409);

        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.ERROR);
    }

    // ================================================================
    // Symptom 2 — runs that vanish / 404 (NaN & overflow on the fetch path)
    // ================================================================

    @Test
    @DisplayName("crit_nan_duration_survives: a run whose only trial item references an unfinished trace is still returned")
    void runWithUnfinishedTraceItemIsStillReturned() {
        var optimization = optimizationResourceClient.createPartialOptimization().build();
        var id = optimizationResourceClient.create(optimization, API_KEY, TEST_WORKSPACE_NAME);

        // An item referencing a still-unfinished trace is what a worker killed mid-trial leaves behind:
        // the duration quantile over zero finished traces used to produce NaN, which the row mapper
        // cannot read, so the whole run silently vanished from getById AND find.
        createTrialWithUnfinishedTraceItem(id);

        var fetched = optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200);
        assertThat(fetched.id()).isEqualTo(id);
        assertThat(fetched.numTrials()).isEqualTo(1L);
        // Duration aggregates are simply absent, not a cause of a dropped row.
        assertThat(fetched.bestDuration()).isNull();
        assertThat(fetched.baselineDuration()).isNull();

        // The list path shares the mapper, so assert the run stays on it too.
        var page = optimizationResourceClient.find(API_KEY, TEST_WORKSPACE_NAME, 1, 100, null, null, null, 200);
        assertThat(page.content()).extracting(Optimization::id).contains(id);
    }

    @Test
    @DisplayName("crit_nonfinite_score_excluded: a trial carrying a raw NaN experiment score is returned, that score excluded")
    void runWithNonFiniteScoreIsReturnedScoreExcluded() {
        var optimization = optimizationResourceClient.createPartialOptimization().build();
        var id = optimizationResourceClient.create(optimization, API_KEY, TEST_WORKSPACE_NAME);

        // A string-typed "NaN" is valid JSON but casts to a Float64 nan that, unguarded, propagates into
        // the aggregates and makes the row unmappable — the same 404 as the duration case. It cannot be
        // seeded through the typed API (ExperimentScore.value is a BigDecimal), hence the raw insert.
        insertTrialWithRawScores(id,
                "[{\"name\":\"finite_metric\",\"value\":0.75},{\"name\":\"nan_metric\",\"value\":\"NaN\"}]");

        var fetched = optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200);
        assertThat(fetched.id()).isEqualTo(id);
        assertThat(fetched.numTrials()).isEqualTo(1L);
        // The non-finite entry is excluded; the finite one remains.
        assertThat(fetched.experimentScores())
                .extracting(FeedbackScoreAverage::name)
                .containsExactly("finite_metric");
    }

    @Test
    @DisplayName("crit_overflow_aggregate_absent: finite scores summing to +Inf still return the run, overflowed aggregate null")
    void runWithOverflowingAggregateIsReturned() {
        var objectiveName = "accuracy";
        var optimization = optimizationResourceClient.createPartialOptimization()
                .objectiveName(objectiveName)
                .build();
        var id = optimizationResourceClient.create(optimization, API_KEY, TEST_WORKSPACE_NAME);

        // Two trials in one candidate, each a finite 1e308 — accepted by any input-side finite filter but
        // summing to +Inf in the derived aggregate. Unguarded, the mapper's BigDecimal conversion throws,
        // the driver swallows it, and the row disappears: the 404 reopened by arithmetic, not by input.
        var candidateId = UUID.randomUUID().toString();
        var metadata = JsonUtils.getJsonNodeFromString(
                JsonUtils.writeValueAsString(Map.of("candidate_id", candidateId)));
        var hugeButFinite = new BigDecimal("1e308");

        var trialIds = Stream.of(1, 2)
                .map(ignored -> experimentResourceClient.create(experimentResourceClient
                        .createPartialExperiment()
                        .optimizationId(id)
                        .type(ExperimentType.TRIAL)
                        .metadata(metadata)
                        .experimentScores(List.of(ExperimentScore.builder()
                                .name(objectiveName)
                                .value(hugeButFinite)
                                .build()))
                        .build(), API_KEY, TEST_WORKSPACE_NAME))
                .toList();

        var traceStart = Instant.now().minusSeconds(30);
        trialIds.forEach(trialId -> linkItemWithTrace(trialId, traceStart, traceStart.plusMillis(1_000)));

        await().atMost(10, TimeUnit.SECONDS)
                .pollInterval(1, TimeUnit.SECONDS)
                .untilAsserted(() -> {
                    var actual = optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200);
                    // The run must still be reachable — the whole point of the guard.
                    assertThat(actual.id()).isEqualTo(id);
                    // An overflowed aggregate is reported absent rather than as a bogus number.
                    assertThat(actual.bestObjectiveScore()).isNull();
                    assertThat(actual.baselineObjectiveScore()).isNull();
                    // Durations are unaffected by the overflow and must still be computed.
                    assertThat(actual.bestDuration()).isNotNull();
                });
    }

    // ================================================================
    // Reconcile drivers
    // ================================================================

    private long reconcile(Duration initializedTimeout, Duration runningTimeout, int batchSize) {
        return reconcile(initializedTimeout, runningTimeout, NEVER, batchSize);
    }

    // Default candidate-scan multiplier supplied only when the resolved reconcile
    // method declares a SECOND int parameter (a query-tuning knob some designs add
    // alongside batchSize). Any positive value in the config bound [1, 1000] works;
    // this is never asserted on — it only has to let the call execute.
    private static final int DEFAULT_CANDIDATE_SCAN_FACTOR = 10;

    /**
     * Dispatch reconcile through reflection, binding arguments by PARAMETER TYPE
     * rather than by a fixed arity, so this verifier accepts any contract-satisfying
     * signature: the pre-fix 4-arg shape, the minimal 5-arg widening that adds only
     * {@code runningHardTimeout}, the 6-arg shape that also adds a scan-tuning int,
     * and anything in between. The only requirement is the method's own
     * documented interface — reconcile a stalled-run scan parameterised by the
     * initialized/running/hard timeouts, a lookback window, and a batch size — not
     * any particular parameter list the implementer chose.
     *
     * <p>Binding rule (every known shape lists Durations first, then ints):
     * <ul>
     *   <li>Durations, in order: {@code initializedTimeout}, {@code runningTimeout},
     *       then {@code runningHardTimeout} ONLY when the method declares a 4th
     *       Duration (the hard-ceiling param a widened signature introduces),
     *       then {@code lookbackMargin}.</li>
     *   <li>ints, in order: {@code batchSize}, then {@link #DEFAULT_CANDIDATE_SCAN_FACTOR}
     *       ONLY when the method declares a 2nd int.</li>
     * </ul>
     * A design that omits the hard ceiling from the signature (passing it some other
     * way, or deriving it) still has its hard-ceiling behaviour exercised through the
     * same seeded scenarios — the dispatcher simply does not feed the value positionally.
     *
     * <p>We resolve the method through the {@link OptimizationService} interface
     * (and its supertypes) to avoid proxy-wrapping issues: the interface is always
     * present regardless of whether Guice wraps the implementation in a CGLIB or
     * JDK-proxy layer.
     */
    @SuppressWarnings("unchecked")
    private long reconcile(Duration initializedTimeout, Duration runningTimeout, Duration runningHardTimeout,
            int batchSize) {
        Method method = findReconcileMethod();
        Object[] args = bindReconcileArgs(method, initializedTimeout, runningTimeout, runningHardTimeout, batchSize);
        try {
            Long transitioned = ((reactor.core.publisher.Mono<Long>) method.invoke(optimizationService, args)).block();
            assertThat(transitioned).isNotNull();
            return transitioned;
        } catch (java.lang.reflect.InvocationTargetException | IllegalAccessException e) {
            throw new RuntimeException("reconcileStalledStudioOptimizations invocation failed", e);
        }
    }

    /**
     * Build the positional argument array for {@code method} by walking its declared
     * parameter types in order and pulling from the Duration queue or the int queue
     * as each slot requires. See {@link #reconcile(Duration, Duration, Duration, int)}
     * for the binding rule.
     */
    private Object[] bindReconcileArgs(Method method, Duration initializedTimeout, Duration runningTimeout,
            Duration runningHardTimeout, int batchSize) {
        Class<?>[] types = method.getParameterTypes();
        long durationParams = java.util.Arrays.stream(types).filter(t -> t == Duration.class).count();
        long intParams = java.util.Arrays.stream(types).filter(t -> t == int.class || t == Integer.class).count();
        if (durationParams < 3 || intParams < 1) {
            throw new RuntimeException(
                    "reconcileStalledStudioOptimizations has an unexpected signature " + method
                            + " (need >= 3 Duration params and >= 1 int param to drive the reaper scan)");
        }

        // Durations to feed, in order. Include the hard ceiling only when the method
        // has room for it (>= 4 Duration params); otherwise it is exercised via seeding.
        java.util.Deque<Duration> durations = new java.util.ArrayDeque<>();
        durations.add(initializedTimeout);
        durations.add(runningTimeout);
        if (durationParams >= 4) {
            durations.add(runningHardTimeout);
        }
        durations.add(LOOKBACK_MARGIN);

        // ints to feed, in order: batchSize, then the optional scan-factor knob.
        java.util.Deque<Integer> ints = new java.util.ArrayDeque<>();
        ints.add(batchSize);
        if (intParams >= 2) {
            ints.add(DEFAULT_CANDIDATE_SCAN_FACTOR);
        }

        Object[] args = new Object[types.length];
        for (int i = 0; i < types.length; i++) {
            Class<?> t = types[i];
            if (t == Duration.class) {
                args[i] = durations.poll();
            } else if (t == int.class || t == Integer.class) {
                args[i] = ints.poll();
            } else {
                throw new RuntimeException(
                        "reconcileStalledStudioOptimizations param " + i + " has unsupported type " + t
                                + " in " + method);
            }
        }
        if (durations.peek() != null || ints.peek() != null) {
            throw new RuntimeException(
                    "reconcileStalledStudioOptimizations signature " + method
                            + " does not consume all required reaper-scan arguments");
        }
        return args;
    }

    /**
     * Walk the {@link OptimizationService} interface hierarchy and return the reconcile
     * method, selecting the widest signature present (highest parameter count, >= 4).
     * A pre-fix tree declares only the 4-arg form; a solved tree declares whatever
     * widened form the implementer chose. Selecting by max arity means the dispatcher
     * binds against the real (widened) signature rather than a stale overload.
     */
    private static Method findReconcileMethod() {
        java.util.Deque<Class<?>> queue = new java.util.ArrayDeque<>();
        queue.add(OptimizationService.class);
        java.util.Set<Class<?>> visited = new java.util.HashSet<>();
        Method best = null;
        while (!queue.isEmpty()) {
            Class<?> c = queue.poll();
            if (!visited.add(c)) continue;
            for (Method m : c.getDeclaredMethods()) {
                if (!"reconcileStalledStudioOptimizations".equals(m.getName())) continue;
                if (m.getParameterCount() < 4) continue;
                if (best == null || m.getParameterCount() > best.getParameterCount()) {
                    best = m;
                }
            }
            for (Class<?> iface : c.getInterfaces()) queue.add(iface);
        }
        if (best != null) return best;
        throw new RuntimeException(
                "reconcileStalledStudioOptimizations (arity >= 4) not found in OptimizationService hierarchy");
    }

    // ================================================================
    // Seed helpers — HTTP API where possible, raw ClickHouse only for
    // server-stamped timestamps and raw-JSON columns.
    // ================================================================

    private UUID seedStudioRun(OptimizationStatus status) {
        var id = seedRun(OptimizationStatus.INITIALIZED, studioConfig());
        switch (status) {
            case INITIALIZED -> {
            }
            case RUNNING -> transition(id, OptimizationStatus.RUNNING);
            case COMPLETED, CANCELLED, ERROR -> {
                transition(id, OptimizationStatus.RUNNING);
                transition(id, status);
            }
        }
        return id;
    }

    private UUID seedRun(OptimizationStatus status, OptimizationStudioConfig studioConfig) {
        var optimization = optimizationResourceClient.createPartialOptimization()
                .status(status)
                .studioConfig(studioConfig)
                // createPartialOptimization leaves Podam's random ErrorInfo in place; clear it so every
                // "the reaper wrote an ErrorInfo" assertion reflects the reaper, not the fixture.
                .errorInfo(null)
                .build();
        return optimizationResourceClient.upsert(optimization, API_KEY, TEST_WORKSPACE_NAME);
    }

    /**
     * Seeds a RUNNING studio run whose latest row version's {@code last_updated_at} is backdated by
     * {@code age}, so the row timestamp alone reads as stale. The update endpoint always stamps now and
     * the create path forces INITIALIZED, so the run is upserted twice with the same id: the create
     * (backdated a minute further) and a RUNNING re-upsert whose backdated timestamp stays the newest
     * version for dedup.
     */
    private UUID seedBackdatedRunningStudioRun(Duration age) {
        var optimization = optimizationResourceClient.createPartialOptimization()
                .studioConfig(studioConfig())
                .errorInfo(null)
                .lastUpdatedAt(Instant.now().minus(age).minus(Duration.ofMinutes(1)))
                .build();
        var id = optimizationResourceClient.upsert(optimization, API_KEY, TEST_WORKSPACE_NAME);
        optimizationResourceClient.upsert(optimization.toBuilder()
                .id(id)
                .status(OptimizationStatus.RUNNING)
                .lastUpdatedAt(Instant.now().minus(age))
                .build(), API_KEY, TEST_WORKSPACE_NAME);

        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.RUNNING);
        return id;
    }

    private UUID seedBackdatedInitializedStudioRun(Duration age) {
        var optimization = optimizationResourceClient.createPartialOptimization()
                .studioConfig(studioConfig())
                .errorInfo(null)
                .lastUpdatedAt(Instant.now().minus(age))
                .build();
        var id = optimizationResourceClient.upsert(optimization, API_KEY, TEST_WORKSPACE_NAME);

        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.INITIALIZED);
        return id;
    }

    /**
     * Clones the run's latest row version with a backdated {@code created_at} and a fresh
     * {@code last_updated_at} — "started long ago, but something wrote the row a moment ago", the shape
     * the hard ceiling is meant to catch. Neither timestamp is settable through the API, so the row is
     * cloned inside ClickHouse; the new version carries the newest {@code last_updated_at} so it wins
     * dedup while the backdated {@code created_at} supplies the start.
     */
    private void backdateRunStart(UUID id, Duration startedAgo) {
        var startedAt = ClickHouseDateTimeFormat.formatNanos(Instant.now().minus(startedAgo));
        var sql = ("INSERT INTO %s.optimizations (id, dataset_id, name, workspace_id, project_id, "
                + "objective_name, status, metadata, studio_config, error_info, created_by, last_updated_by, "
                + "created_at, last_updated_at) "
                + "SELECT id, dataset_id, name, workspace_id, project_id, objective_name, status, metadata, "
                + "studio_config, error_info, created_by, last_updated_by, "
                + "toDateTime64('%s', 9, 'UTC'), now64(6) "
                + "FROM %s.optimizations WHERE id = '%s' AND workspace_id = '%s' "
                + "ORDER BY last_updated_at DESC LIMIT 1")
                .formatted(ANALYTICS_DB, startedAt, ANALYTICS_DB, id, WORKSPACE_ID);
        try (var connection = NativeServiceAppExtensionShim.newClickHouseConnection();
                var statement = connection.createStatement()) {
            statement.executeUpdate(sql);
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to backdate run start", e);
        }
    }

    /** Creates a trial experiment linked to the run — the progress signal the liveness check reads. */
    private UUID createTrialExperiment(UUID optimizationId) {
        var experiment = experimentResourceClient.createPartialExperiment()
                .optimizationId(optimizationId)
                .build();
        return experimentResourceClient.create(experiment, API_KEY, TEST_WORKSPACE_NAME);
    }

    /**
     * Inserts a trial experiment row straight into ClickHouse with a backdated {@code created_at}. The
     * API always stamps {@code created_at} server-side and the probe reads the table without FINAL, so a
     * single raw row is the only way to seed an "old trial" deterministically without sleeping the suite.
     */
    private UUID createBackdatedTrialExperiment(UUID optimizationId, Duration age) {
        var experiment = experimentResourceClient.createPartialExperiment()
                .optimizationId(optimizationId)
                .build();
        var createdAt = ClickHouseDateTimeFormat.formatNanos(Instant.now().minus(age));
        try (var connection = NativeServiceAppExtensionShim.newClickHouseConnection();
                var statement = connection.prepareStatement(
                        ("INSERT INTO %s.experiments (workspace_id, dataset_id, id, name, optimization_id, "
                                + "created_at, last_updated_at, created_by, last_updated_by) "
                                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)").formatted(ANALYTICS_DB))) {
            statement.setString(1, WORKSPACE_ID);
            statement.setString(2, experiment.datasetId().toString());
            statement.setString(3, experiment.id().toString());
            statement.setString(4, experiment.name());
            statement.setString(5, optimizationId.toString());
            statement.setString(6, createdAt);
            statement.setString(7, createdAt);
            statement.setString(8, USER);
            statement.setString(9, USER);
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to seed backdated trial experiment", e);
        }
        return experiment.id();
    }

    /**
     * Appends one experiment item to a trial — the per-dataset-item progress signal within a trial. The
     * trace is created first, matching the worker (trace before item). A null {@code endTime} leaves the
     * trace unfinished, so it contributes no duration.
     */
    private void createExperimentItem(UUID experimentId, boolean traceFinished) {
        var traceBuilder = podamFactory.manufacturePojo(Trace.class).toBuilder()
                .feedbackScores(null)
                .usage(null);
        if (!traceFinished) {
            traceBuilder.endTime(null).duration(null);
        }
        var traceId = traceResourceClient.createTrace(traceBuilder.build(), API_KEY, TEST_WORKSPACE_NAME);
        var item = podamFactory.manufacturePojo(ExperimentItem.class).toBuilder()
                .experimentId(experimentId)
                .traceId(traceId)
                .feedbackScores(null)
                .build();
        experimentResourceClient.createExperimentItem(Set.of(item), API_KEY, TEST_WORKSPACE_NAME);
    }

    /**
     * Links a trial with one experiment item whose trace is still unfinished (no end time, so no
     * duration) — the state a worker killed mid-trial leaves behind. The regression this guards: the
     * duration quantile over zero finished traces produced NaN, the mapper could not read it, and the
     * whole run vanished from getById and find.
     */
    private void createTrialWithUnfinishedTraceItem(UUID optimizationId) {
        var experiment = experimentResourceClient.createPartialExperiment()
                .optimizationId(optimizationId)
                .type(ExperimentType.TRIAL)
                .build();
        var experimentId = experimentResourceClient.create(experiment, API_KEY, TEST_WORKSPACE_NAME);

        var trace = podamFactory.manufacturePojo(Trace.class).toBuilder()
                .endTime(null)
                .duration(null)
                .feedbackScores(null)
                .usage(null)
                .build();
        traceResourceClient.createTrace(trace, API_KEY, TEST_WORKSPACE_NAME);

        var item = podamFactory.manufacturePojo(ExperimentItem.class).toBuilder()
                .experimentId(experimentId)
                .traceId(trace.id())
                .feedbackScores(null)
                .build();
        experimentResourceClient.createExperimentItem(Set.of(item), API_KEY, TEST_WORKSPACE_NAME);
    }

    /**
     * Appends one experiment item backed by a real trace spanning {@code [startTime, endTime]}. A null
     * {@code endTime} leaves the trace unfinished, contributing no duration.
     */
    private void linkItemWithTrace(UUID experimentId, Instant startTime, Instant endTime) {
        var trace = podamFactory.manufacturePojo(Trace.class).toBuilder()
                .startTime(startTime)
                .endTime(endTime)
                .duration(null)
                .feedbackScores(null)
                .usage(null)
                .build();
        traceResourceClient.createTrace(trace, API_KEY, TEST_WORKSPACE_NAME);

        var item = podamFactory.manufacturePojo(ExperimentItem.class).toBuilder()
                .experimentId(experimentId)
                .traceId(trace.id())
                .feedbackScores(null)
                .build();
        experimentResourceClient.createExperimentItem(Set.of(item), API_KEY, TEST_WORKSPACE_NAME);
    }

    /**
     * Inserts a trial experiment row straight into ClickHouse with a raw {@code experiment_scores} JSON
     * string. The typed API cannot produce every shape the column can hold ({@code ExperimentScore.value}
     * is a BigDecimal, so "NaN" is rejected at deserialization), but the fetch path must survive whatever
     * raw JSON an older or foreign writer already stored.
     */
    private void insertTrialWithRawScores(UUID optimizationId, String experimentScoresJson) {
        var experiment = experimentResourceClient.createPartialExperiment().build();
        try (var connection = NativeServiceAppExtensionShim.newClickHouseConnection();
                var statement = connection.prepareStatement(
                        ("INSERT INTO %s.experiments (workspace_id, dataset_id, id, name, optimization_id, "
                                + "experiment_scores, created_by, last_updated_by) "
                                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)").formatted(ANALYTICS_DB))) {
            statement.setString(1, WORKSPACE_ID);
            statement.setString(2, experiment.datasetId().toString());
            statement.setString(3, experiment.id().toString());
            statement.setString(4, experiment.name());
            statement.setString(5, optimizationId.toString());
            statement.setString(6, experimentScoresJson);
            statement.setString(7, USER);
            statement.setString(8, USER);
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to seed trial experiment with raw scores", e);
        }
    }

    private void transition(UUID id, OptimizationStatus status) {
        optimizationResourceClient.update(id, OptimizationUpdate.builder().status(status).build(),
                API_KEY, TEST_WORKSPACE_NAME, 204);
    }

    private OptimizationStatus statusOf(UUID id) {
        return optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200).status();
    }

    private OptimizationStudioConfig studioConfig() {
        // opikApiKey is @JsonIgnore and populated server-side, so we omit it.
        return podamFactory.manufacturePojo(OptimizationStudioConfig.class).toBuilder()
                .opikApiKey(null)
                .build();
    }
}
