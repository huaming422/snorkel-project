#!/usr/bin/env bash
#
# Behavioural verifier for opik-fix-stall-reaper-liveness (shell runner).
#
# ssb_lib has no Maven/JUnit runner, so this shell script IS the verifier:
# it injects a single JUnit 5 integration-test class (plus its native-service
# boot shim) into the opik-backend test tree and runs it with Maven against
# the natively-baked MySQL + ClickHouse + Redis that tests/test-setup.sh has
# already started (test.sh sources test-setup.sh before this runner). The
# script's exit code is the entire behavioural signal: 0 => every graded test
# passed, non-zero => at least one failed (run_aggregate.py maps that to
# correctness 1.0 / 0.0).
#
# The injected test drives the reported symptoms through pre-existing, stable
# interfaces — the optimization/experiment/trace HTTP resource clients, the
# reconcile entry point, and the run's own bare re-read — and never references
# a reference-solution SQL identifier or private symbol, so every accepted
# fix passes and only a genuinely broken reaper / run-fetch fails.
set -euo pipefail

log() { printf '[verify] %s\n' "$*"; }

# Repo layout (baked by image/Dockerfile): clone at /repo/opik, backend module
# at apps/opik-backend. The shell runner sets cwd to /repo/opik.
REPO_ROOT="/repo/${REPO_NAME:-opik}"
BACKEND_DIR="${REPO_ROOT}/apps/opik-backend"

# Verifier assets are staged alongside this script under /tests/verify/.
VERIFY_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# The injected class declares `package com.comet.opik.domain;` (same package as
# the existing integration tests, so it can inject Guice beans and reuse the
# resource-client helpers). Inject into the matching test dir.
TEST_PKG_DIR="${BACKEND_DIR}/src/test/java/com/comet/opik/domain"

TEST_CLASS="StallReaperLivenessVerifierTest"
SHIM_CLASS="NativeServiceAppExtensionShim"

# Baked pre-fix test files that call PRODUCTION signatures the fix changes.
# `mvn test` compiles the WHOLE src/test tree, not just the -Dtest= target, so
# these stale files break test-compile even in a correctly solved tree — the
# fix widens reconcileStalledStudioOptimizations (4-arg -> 6-arg) and
# OptimizationDAO.update (2-arg -> 3-arg), which these three files still call
# the old way. The upstream change rewrites all three itself, so moving the
# stale copies aside is faithful to the real change, not a shortcut. They are
# restored by the cleanup trap, and the neutralization is signature-agnostic:
# it runs identically for a solved tree and for an unsolved one. On an
# unsolved tree the injected class itself still fails to compile (it calls the
# new 6-arg signature, absent there), so correctness stays 0.
STALE_TESTS=(
    "${BACKEND_DIR}/src/test/java/com/comet/opik/api/resources/v1/jobs/OptimizationStalledReaperJobTest.java"
    "${BACKEND_DIR}/src/test/java/com/comet/opik/domain/OptimizationServiceUpdateLockTest.java"
    "${BACKEND_DIR}/src/test/java/com/comet/opik/domain/OptimizationStalledReaperServiceTest.java"
)

INJECTED=()
MOVED=()
CONFIG_PATCHED=""
MVN_LOG="$(mktemp)"
cleanup() {
    rm -f "$MVN_LOG"
    for f in "${INJECTED[@]:-}"; do
        [ -n "$f" ] && rm -f "$f"
    done
    # Restore every stale file we moved aside, so the repo is left pristine.
    for f in "${MOVED[@]:-}"; do
        [ -n "$f" ] && [ -f "${f}.sbbak" ] && mv -f "${f}.sbbak" "$f"
    done
    # Restore the test config if we patched it.
    [ -n "${CONFIG_PATCHED:-}" ] && [ -f "${CONFIG_PATCHED}.sbbak" ] \
        && mv -f "${CONFIG_PATCHED}.sbbak" "$CONFIG_PATCHED"
}
trap cleanup EXIT

if [ ! -d "$BACKEND_DIR" ]; then
    log "ERROR: backend module not found at $BACKEND_DIR"
    exit 2
fi

mkdir -p "$TEST_PKG_DIR"
for src in "${TEST_CLASS}.java" "${SHIM_CLASS}.java"; do
    if [ ! -f "${VERIFY_DIR}/${src}" ]; then
        log "ERROR: verifier source ${src} missing from ${VERIFY_DIR}"
        exit 2
    fi
    cp "${VERIFY_DIR}/${src}" "${TEST_PKG_DIR}/${src}"
    INJECTED+=("${TEST_PKG_DIR}/${src}")
    log "injected ${src} -> ${TEST_PKG_DIR}"
done

# Move the stale pre-fix test files aside so test-compile sees only the fix's
# new signatures plus our injected class. Restored by the cleanup trap.
for f in "${STALE_TESTS[@]}"; do
    if [ -f "$f" ]; then
        mv -f "$f" "${f}.sbbak"
        MOVED+=("$f")
        log "neutralized stale test $(basename "$f")"
    fi
done

# The solved reaper config record is bean-validated at application boot (the
# `optimizationStalledReaper` field on the top-level config carries
# `@Valid @NotNull`, so its own field constraints fire even though the reaper
# runs disabled in tests). Two of its required fields have no value in the
# baked test config, which predates them, so the app would fail to start with a
# "may not be null" validation error on every run of a correctly solved tree.
# Add them to the reaper block of the test config before the app boots. This is
# test-infra setup, faithful to the upstream change's own test-config hunk, not
# a behavioural hint: both values only satisfy boot validation (any run that
# depends on a timeout passes its own explicit value straight to the reconcile
# entry point, never reading these). Restored by the cleanup trap.
#   * runningHardTimeout — a Duration >= runningTimeout (26h here) and <= 30d.
#   * candidateScanFactor — an int in [1, 1000].
CONFIG_TEST_YML="${BACKEND_DIR}/src/test/resources/config-test.yml"
if [ -f "$CONFIG_TEST_YML" ]; then
    if ! grep -qE '^\s*runningHardTimeout:' "$CONFIG_TEST_YML"; then
        cp "$CONFIG_TEST_YML" "${CONFIG_TEST_YML}.sbbak"
        CONFIG_PATCHED="$CONFIG_TEST_YML"
        # Insert both keys immediately under the block header, at the block's
        # 2-space indentation, so the edit is independent of which other keys
        # the block happens to contain.
        awk '
            { print }
            /^optimizationStalledReaper:[[:space:]]*$/ {
                print "  runningHardTimeout: 48h"
                print "  candidateScanFactor: 10"
            }
        ' "${CONFIG_TEST_YML}.sbbak" > "$CONFIG_TEST_YML"
        log "added runningHardTimeout + candidateScanFactor to test config for boot validation"
    else
        log "test config already carries runningHardTimeout; leaving it untouched"
    fi
else
    log "WARNING: ${CONFIG_TEST_YML} not found; proceeding without config injection"
fi

cd "$BACKEND_DIR"

# Ignore reports baked into the image or left by the solver. Only reports from
# this verifier run may decide whether an offline failure was a test outcome.
rm -rf target/surefire-reports

# Run only the graded class. No `clean` — the image pre-warms test-compile, so
# reusing target/ keeps the run well inside the 1100s budget. No
# `-Dmaven.test.failure.ignore` — a failing graded test MUST make mvn exit
# non-zero so the shell runner records the failure. `-o` (offline) first for
# speed/determinism; fall back to online only if offline resolution fails
# (allow_internet = true), never masking a genuine test failure.
MVN_ARGS=(-B -Dsurefire.failIfNoSpecifiedTests=true -Dtest="${TEST_CLASS}" test)

log "running: mvn -o ${MVN_ARGS[*]}"
set +e
mvn -o "${MVN_ARGS[@]}" >"$MVN_LOG" 2>&1
rc=$?
set -e
cat "$MVN_LOG"

if [ "$rc" -ne 0 ]; then
    # A killed Maven process is an environment-capacity failure. Retrying it
    # online only repeats the OOM and obscures the useful exit code.
    if [ "$rc" -eq 137 ]; then
        log "ERROR: Maven was killed with exit 137; check the sandbox memory allocation" >&2
    # Distinguish a real test failure from an offline dependency-resolution
    # miss. Put the concise Surefire summary on stderr so the shell runner's
    # recorded failure identifies the actual failing check.
    elif ls target/surefire-reports/TEST-*.xml >/dev/null 2>&1; then
        log "tests executed; mvn exit ${rc} reflects test outcome"
        grep -hE 'Tests run:.*Failures:|<<< (FAILURE|ERROR)!' \
            target/surefire-reports/*.txt 2>/dev/null | head -20 >&2 || true
    else
        log "no surefire reports after offline run (likely dependency gap) — retrying online"
        : >"$MVN_LOG"
        set +e
        mvn "${MVN_ARGS[@]}" >"$MVN_LOG" 2>&1
        rc=$?
        set -e
        cat "$MVN_LOG"
        if [ "$rc" -eq 137 ]; then
            log "ERROR: Maven was killed with exit 137; check the sandbox memory allocation" >&2
        elif [ "$rc" -ne 0 ] && ls target/surefire-reports/TEST-*.xml >/dev/null 2>&1; then
            grep -hE 'Tests run:.*Failures:|<<< (FAILURE|ERROR)!' \
                target/surefire-reports/*.txt 2>/dev/null | head -20 >&2 || true
        fi
    fi
fi

log "verifier exit ${rc}"
exit "$rc"
