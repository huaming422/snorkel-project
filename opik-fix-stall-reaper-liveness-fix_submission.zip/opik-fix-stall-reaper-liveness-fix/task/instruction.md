## Task

our optimization "studio" runs are misbehaving in two ways and users keep filing reports.

the run status in the UI gets stuck on an eternal spinner. some runs that are still actively working get marked failed after a few hours even though they're clearly progressing, while others that genuinely died never get marked failed and just spin forever. both directions are wrong.

separately, runs disappear: one that definitely exists will vanish from the list, or opening it returns not-found, even though nothing removed it.

dig into the backend (`apps/opik-backend`) and fix both. a run that's actively progressing should stay alive, a stalled one should get reliably marked failed with a clear reason, and a run should never drop out of the API.

you're at a fixed commit with an offline build: dependencies are installed and there's no network. an automated integration test boots the backend against real databases and drives these scenarios through the public API and service layer, so the fix has to hold up through those interfaces, not just move code around.
