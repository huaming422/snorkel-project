## Task

We're getting intermittent failures opening SSH sessions to our older v1 devices. For every new session the server reaches back out through the persistent link the device already holds and opens a fresh connection over it. Most of the time that works fine, but every so often the client hangs for about three minutes and then dies with a handshake EOF. It's gotten noticeably more common since we moved the gateway onto smaller, lower-CPU boxes, and the CI job that exercises v1 connections now goes red at random with the same hang.

There's a second, related complaint: when a device is online but never finishes bringing up its side of one of these connections, the caller hangs until some long timeout instead of quickly giving up and reporting the device as unreachable.

Dig into what's actually going wrong and fix it, so that connecting to v1 devices stops intermittently hanging and failing, and a device that never answers fails fast as unreachable instead of stalling the caller.
