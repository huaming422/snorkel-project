// Black-box behavioral verifier for the reverse dialer's connection-matching.
//
// Every test drives the package only through its exported surface
// (NewDialer / Dial / Close / Done / ConnHandler) and the JSON control
// protocol an agent speaks over the control connection. No unexported symbol
// is named and no source is grepped, so any faithful reimplementation — a
// different container for per-dial state, a different place to close a late
// connection, renamed or non-English identifiers — is accepted as long as the
// observable behavior holds. Everything runs under -race.
//
// Test taxonomy (see verify.toml and task.toml [[test_criteria]]):
//   TestVerifyWaitingDialSurvivesAStaleFailure  fail_to_pass (failure routing)
//   TestVerifyCloseReturnsWithNoDoneReceiver     fail_to_pass (non-blocking Close)
//   TestVerifyDialReportsItsOwnPickupFailure     pass_to_pass guard
//   TestVerifyEachConcurrentDialGetsItsOwnConn   pass_to_pass guard
//   TestVerifyAbandonedDialBackIsClosed          pass_to_pass guard

package revdial_test

import (
	"bufio"
	"context"
	"encoding/json"
	"errors"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/gorilla/websocket"
	"github.com/shellhub-io/shellhub/pkg/clock"
	"github.com/shellhub-io/shellhub/pkg/revdial"
	"github.com/shellhub-io/shellhub/pkg/wsconnadapter"
	log "github.com/sirupsen/logrus"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

const (
	verifyConnPath    = "/ssh/revdial"
	verifyControlPath = "/control"
)

// verifyControlMessage mirrors the wire shape of the control protocol the
// server and agent already exchange (command, connPath, err). It is the public
// contract between the two sides, unchanged by any valid fix.
type verifyControlMessage struct {
	Command  string `json:"command,omitempty"`
	ConnPath string `json:"connPath,omitempty"`
	Err      string `json:"err,omitempty"`
}

// verifyAgent stands in for the device: it reads conn-ready announcements off
// the control connection, dials websockets back into ConnHandler, and can
// report pickup failures.
type verifyAgent struct {
	t     *testing.T
	ctl   net.Conn
	wsURL string
	ready chan string
}

// verifyControl builds the control transport for a dialer. Two shapes are used:
// a real websocket (realistic timing for the concurrent-delivery guard) and a
// net.Pipe (deterministic ordering for the stale-failure and abandon tests).
type verifyControl func(t *testing.T, mux *http.ServeMux, wsURL string) (serverConn net.Conn, agentConn net.Conn)

func verifyWebsocketControl(t *testing.T, mux *http.ServeMux, wsURL string) (net.Conn, net.Conn) {
	t.Helper()

	accepted := make(chan net.Conn, 1)

	mux.HandleFunc(verifyControlPath, func(w http.ResponseWriter, r *http.Request) {
		conn, err := (&websocket.Upgrader{}).Upgrade(w, r, nil)
		if err != nil {
			t.Errorf("the control connection could not be upgraded: %v", err)

			return
		}

		accepted <- wsconnadapter.New(conn)
	})

	peer, _, err := websocket.DefaultDialer.DialContext(t.Context(), wsURL+verifyControlPath, nil) //nolint:bodyclose // gorilla/websocket documents that the handshake response body need not be closed.
	require.NoError(t, err)

	return <-accepted, wsconnadapter.New(peer)
}

func verifyPipeControl(*testing.T, *http.ServeMux, string) (net.Conn, net.Conn) {
	return net.Pipe()
}

func verifyNewDialer(t *testing.T) (*revdial.Dialer, *verifyAgent) {
	t.Helper()

	return verifyNewDialerOver(t, verifyWebsocketControl)
}

func verifyNewDialerOver(t *testing.T, ctl verifyControl) (*revdial.Dialer, *verifyAgent) {
	t.Helper()

	mux := http.NewServeMux()
	mux.Handle(verifyConnPath, revdial.ConnHandler(websocket.Upgrader{}))

	srv := httptest.NewServer(mux)
	t.Cleanup(srv.Close)

	wsURL := "ws" + strings.TrimPrefix(srv.URL, "http")

	serverCtl, agentCtl := ctl(t, mux, wsURL)

	t.Cleanup(func() {
		_ = serverCtl.Close()
		_ = agentCtl.Close()
	})

	logger := log.New()
	logger.SetOutput(io.Discard)

	d := revdial.NewDialer(log.NewEntry(logger), serverCtl, verifyConnPath, clock.New())
	// Close on a detached goroutine, never on the cleanup (test) goroutine: an
	// unfixed Close can block indefinitely (it waits for a receiver on Done()
	// that these guards never provide). A blocking cleanup would stall the whole
	// test binary to the runner timeout and make these guards register as an
	// infra error rather than the clean pass they are. A leaked blocked
	// goroutine does not hold up process exit; the fixed Close returns at once.
	t.Cleanup(func() { go func() { _ = d.Close() }() })

	a := &verifyAgent{
		t:     t,
		ctl:   agentCtl,
		wsURL: wsURL,
		ready: make(chan string, 1024),
	}

	go a.readControl()

	return d, a
}

func (a *verifyAgent) readControl() {
	reader := bufio.NewReader(a.ctl)

	for {
		line, err := reader.ReadBytes('\n')
		if err != nil {
			return
		}

		var msg verifyControlMessage
		if err := json.Unmarshal(line, &msg); err != nil {
			return
		}

		if msg.Command == "conn-ready" {
			a.ready <- msg.ConnPath
		}
	}
}

func (a *verifyAgent) awaitConnReady() (string, bool) {
	select {
	case path := <-a.ready:
		return path, true
	case <-time.After(5 * time.Second):
		return "", assert.Fail(a.t, "the server never announced a connection to pick up")
	}
}

func (a *verifyAgent) dialBack(ctx context.Context, path string) (net.Conn, bool) {
	conn, _, err := websocket.DefaultDialer.DialContext(ctx, a.wsURL+path, nil) //nolint:bodyclose // gorilla/websocket documents that the handshake response body need not be closed.
	if err != nil {
		a.t.Errorf("the agent could not dial back %s: %v", path, err)

		return nil, false
	}

	adapter := wsconnadapter.New(conn)
	a.t.Cleanup(func() { _ = adapter.Close() })

	return adapter, true
}

func (a *verifyAgent) failPickup(path string, reason string) bool {
	line, err := json.Marshal(verifyControlMessage{Command: "pickup-failed", ConnPath: path, Err: reason})
	if err == nil {
		_, err = a.ctl.Write(append(line, '\n'))
	}

	if err != nil {
		a.t.Errorf("the agent could not report a failed pick-up: %v", err)

		return false
	}

	return true
}

func verifyDialWithin(t *testing.T, d *revdial.Dialer, timeout time.Duration) (net.Conn, error) {
	t.Helper()

	ctx, cancel := context.WithTimeout(t.Context(), timeout)
	defer cancel()

	return d.Dial(ctx)
}

// TestVerifyWaitingDialSurvivesAStaleFailure (fail_to_pass): a pickup failure
// reported for a dial that has already given up must be routed to that dial
// only. A second dial that is still waiting must not be knocked over by the
// stale failure — it must go on to receive its own dialled-back connection.
// Over a deterministic pipe transport this fails when a single failure path is
// shared across every pending dial, and passes once each dial owns its delivery.
func TestVerifyWaitingDialSurvivesAStaleFailure(t *testing.T) {
	t.Parallel()

	d, a := verifyNewDialerOver(t, verifyPipeControl)

	gaveUp, cancel := context.WithCancel(t.Context())

	abandoned := make(chan error, 1)
	go func() {
		_, err := d.Dial(gaveUp)
		abandoned <- err
	}()

	stalePath, ok := a.awaitConnReady()
	require.True(t, ok)

	cancel()
	require.ErrorIs(t, <-abandoned, context.Canceled)

	agentDone := make(chan struct{})
	go func() {
		defer close(agentDone)

		path, ok := a.awaitConnReady()
		if !ok || !a.failPickup(stalePath, "stale") {
			return
		}

		a.dialBack(t.Context(), path)
	}()

	conn, err := verifyDialWithin(t, d, 5*time.Second)
	<-agentDone

	require.NoError(t, err, "a failure for a dial that gave up must not fail the one still waiting")
	require.NotNil(t, conn)
	_ = conn.Close()
}

// TestVerifyCloseReturnsWithNoDoneReceiver (fail_to_pass): Close must return
// even when nothing is receiving on Done(), and Done() must be observably
// closed afterward. A Close that first sends on the done channel blocks forever
// when no one is watching; this test's timeout fires in that case.
func TestVerifyCloseReturnsWithNoDoneReceiver(t *testing.T) {
	t.Parallel()

	serverCtl, agentCtl := net.Pipe()
	t.Cleanup(func() { _ = agentCtl.Close() })

	logger := log.New()
	logger.SetOutput(io.Discard)

	d := revdial.NewDialer(log.NewEntry(logger), serverCtl, verifyConnPath, clock.New())

	closed := make(chan struct{})
	go func() {
		_ = d.Close()
		close(closed)
	}()

	select {
	case <-closed:
	case <-time.After(5 * time.Second):
		require.FailNow(t, "Close must return even when nothing is receiving on Done")
	}

	select {
	case <-d.Done():
	default:
		require.FailNow(t, "Done must be closed once Close returned")
	}
}

// TestVerifyDialReportsItsOwnPickupFailure (pass_to_pass guard): the fix must
// still surface a genuine pickup failure for the dial it belongs to. Guards
// against a change that routes failures nowhere to dodge the mis-routing test.
func TestVerifyDialReportsItsOwnPickupFailure(t *testing.T) {
	t.Parallel()

	d, a := verifyNewDialer(t)

	go func() {
		if path, ok := a.awaitConnReady(); ok {
			a.failPickup(path, "the agent could not reach the server")
		}
	}()

	conn, err := verifyDialWithin(t, d, 5*time.Second)

	require.ErrorContains(t, err, "the agent could not reach the server")
	assert.Nil(t, conn)
}

// TestVerifyEachConcurrentDialGetsItsOwnConn (pass_to_pass guard): every one of
// many concurrent dials must end up holding a distinct dialled-back connection;
// no two dials may be handed the same one. Held at a modest, race-detector-safe
// concurrency so it is a stable correctness guard rather than a timing probe.
func TestVerifyEachConcurrentDialGetsItsOwnConn(t *testing.T) {
	t.Parallel()

	d, a := verifyNewDialer(t)

	const dials = 16

	go func() {
		for range dials {
			path, ok := a.awaitConnReady()
			if !ok {
				return
			}

			conn, ok := a.dialBack(t.Context(), path)
			if !ok {
				return
			}

			go func() {
				_, _ = conn.Write([]byte(path))
			}()
		}
	}()

	var wg sync.WaitGroup

	received := make(chan string, dials)
	failures := make(chan error, dials)

	for range dials {
		wg.Go(func() {
			conn, err := verifyDialWithin(t, d, 10*time.Second)
			if err != nil {
				failures <- err

				return
			}

			defer func() { _ = conn.Close() }()

			if err := conn.SetReadDeadline(time.Now().Add(10 * time.Second)); err != nil { //nolint:forbidigo // a deadline needs the wall clock
				failures <- err

				return
			}

			buf := make([]byte, 256)
			n, err := conn.Read(buf)
			if err != nil {
				failures <- err

				return
			}

			received <- string(buf[:n])
		})
	}

	wg.Wait()
	close(failures)
	close(received)

	for err := range failures {
		require.NoError(t, err, "every dial must get a connection or its own error")
	}

	paths := make(map[string]bool)
	for path := range received {
		assert.False(t, paths[path], "two dials received the same connection: %s", path)
		paths[path] = true
	}

	assert.Len(t, paths, dials, "every dial must end up holding a distinct connection")
}

// TestVerifyAbandonedDialBackIsClosed (pass_to_pass guard): a connection the
// agent dials back after its dial was cancelled must be closed, not left
// hanging open. A read on that late connection must therefore fail with a
// non-timeout error. Guards against a fix that regresses the late-connection leak.
func TestVerifyAbandonedDialBackIsClosed(t *testing.T) {
	t.Parallel()

	d, a := verifyNewDialer(t)

	ctx, cancel := context.WithCancel(t.Context())

	dialed := make(chan error, 1)
	go func() {
		_, err := d.Dial(ctx)
		dialed <- err
	}()

	path, ok := a.awaitConnReady()
	require.True(t, ok)

	cancel()

	select {
	case err := <-dialed:
		require.ErrorIs(t, err, context.Canceled)
	case <-time.After(5 * time.Second):
		require.FailNow(t, "a cancelled dial must return")
	}

	late, ok := a.dialBack(t.Context(), path)
	require.True(t, ok)

	require.NoError(t, late.SetReadDeadline(time.Now().Add(5*time.Second))) //nolint:forbidigo // a deadline needs the wall clock

	_, err := late.Read(make([]byte, 1))

	require.Error(t, err)

	if netErr, ok := errors.AsType[net.Error](err); ok {
		assert.False(t, netErr.Timeout(), "a connection nobody claims must be closed, not left hanging")
	}
}
