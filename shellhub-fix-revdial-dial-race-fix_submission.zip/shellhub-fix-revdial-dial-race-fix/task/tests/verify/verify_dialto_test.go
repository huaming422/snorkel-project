// Black-box behavioral verifier for the SSH tunnel dialer's give-up bound.
//
// This test drives the dialer only through its exported surface
// (NewManager / NewKey / the Manager.Connections store / the Dialer struct's
// exported Manager field / DialTo / ErrUnreachable / ErrNoConnection /
// SSHOpenTarget). It is an external `package dialer_test`, so it compiles
// against the package without seeing any unexported field. That is deliberate:
// a valid fix may bound the wait with a named constant, a literal, a struct
// field, or any configurable knob — the test must accept them all, so it reads
// none of them and instead waits out the real default bound and asserts the
// observable outcome.
//
// A device that holds a v1 tunnel but never dials a stream back must make
// DialTo give up and report the device as present-but-unreachable
// (ErrUnreachable), NOT as holding no tunnel (ErrNoConnection), and NOT by
// hanging the caller for whatever later deadline its context carries. On
// unfixed code DialTo blocks indefinitely here; on fixed code it returns at the
// bound. Runs under -race.
//
// Test taxonomy (see verify.toml and task.toml [[test_criteria]]):
//   TestVerifyDialToGivesUpOnADeviceThatNeverAnswers  fail_to_pass (bounded ErrUnreachable)

package dialer_test

import (
	"io"
	"net"
	"testing"
	"time"

	"github.com/shellhub-io/shellhub/pkg/clock"
	"github.com/shellhub-io/shellhub/pkg/revdial"
	dialer "github.com/shellhub-io/shellhub/server/ssh/pkg/dialer"
	log "github.com/sirupsen/logrus"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// verifyDialDeadline bounds how long the test waits for DialTo to give up. It
// must sit comfortably above the implementation's own default give-up bound so
// that any reasonable fixed implementation returns in time, while an unfixed
// one — which never returns — trips the deadline and fails the test. The
// shipped reference bounds at ~30s; this is set to 3x that so a fix that picks
// a somewhat larger bound, or runs on a loaded box under the race detector
// (which inflates wall-clock), still returns within the window. An unfixed
// DialTo never returns regardless, so the wide margin cannot admit base.
const verifyDialDeadline = 90 * time.Second

func TestVerifyDialToGivesUpOnADeviceThatNeverAnswers(t *testing.T) {
	// A control pipe whose agent side is drained but never dials a stream back:
	// the device is present (the tunnel exists) but the exchange never completes.
	serverCtl, agentCtl := net.Pipe()
	go func() { _, _ = io.Copy(io.Discard, agentCtl) }()

	logger := log.New()
	logger.SetOutput(io.Discard)

	tunnel := revdial.NewDialer(log.NewEntry(logger), serverCtl, "/ssh/revdial", clock.New())

	manager := dialer.NewManager(clock.New())
	manager.Connections.Store(dialer.NewKey("tenant", "device"), tunnel)

	d := &dialer.Dialer{Manager: manager}

	type outcome struct {
		conn net.Conn
		err  error
	}

	// Call DialTo with a context that never cancels on its own, so the only
	// thing that can end the call is the implementation's internal give-up
	// bound. A caller-side deadline here would let a fix "pass" by inheriting
	// the caller's timeout instead of bounding the wait itself.
	done := make(chan outcome, 1)
	go func() {
		conn, err := d.DialTo(t.Context(), "tenant", "device", dialer.SSHOpenTarget{SessionID: "session"})
		done <- outcome{conn: conn, err: err}
	}()

	select {
	case r := <-done:
		// Close only on this branch: it is reached solely when DialTo returns,
		// i.e. on an implementation that bounds the wait. Closing the tunnel is
		// then safe. On the deadline branch below we deliberately skip all
		// teardown — an unfixed tunnel's Close can itself block — and let the
		// short-lived test process reclaim the leaked goroutines on exit. No
		// t.Cleanup is registered for the same reason.
		_ = tunnel.Close()
		_ = serverCtl.Close()
		_ = agentCtl.Close()

		require.ErrorIs(t, r.err, dialer.ErrUnreachable,
			"a device that holds a tunnel but never answers must be reported unreachable")
		require.NotErrorIs(t, r.err, dialer.ErrNoConnection,
			"the device is present; it must not be reported as holding no tunnel")
		assert.Nil(t, r.conn)
	case <-time.After(verifyDialDeadline):
		require.FailNow(t, "DialTo must give up on a device that never dials a stream back, not hang the caller")
	}
}
