#!/usr/bin/env bash
# Sourced by the Staff-Bench verifier runner before tests execute.
#
# The image bakes the full dependency closure for BOTH Go modules exercised by
# this task — the root module `github.com/shellhub-io/shellhub` (pkg/revdial)
# and the nested `.../server` module (server/ssh/pkg/dialer) — at the base
# commit, with GOMODCACHE already populated. This script just re-exports the Go
# environment and does an offline-first `go mod download` per module so the
# verifier can compile and run `go test -race` without touching the network.
#
# The agent phase is offline (task.toml [environment] agent_offline = true); the
# verifier phase has network, so the online fallback below is a safety net only
# and should normally be a no-op on the warm cache.

set -euo pipefail

cd /repo/shellhub

# Inherit the image's Go cache locations (set in the image ENV:
# GOMODCACHE=/opt/cache/go, GOCACHE=/opt/cache/go-build). Only provide
# defaults if the environment was reset; never relocate off the warm caches.
export GOFLAGS="-mod=mod"
export CGO_ENABLED="1"
export GOTOOLCHAIN="local"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"
mkdir -p "$GOMODCACHE" "$GOCACHE"

# Offline-first module resolution for each module. The closure is baked, so the
# offline pass (GOPROXY=off) succeeds on the warm cache. If it ever misses
# (cache drift), fall back to an online download and say so loudly in the log.
for mod in . server; do
    (
        cd "/repo/shellhub/$mod"
        if ! GOPROXY=off GOFLAGS=-mod=mod go mod download 2>/tmp/gomod_"${mod//\//_}".log; then
            echo "[test-setup] WARN: offline 'go mod download' missed for module '$mod'; falling back to network" >&2
            cat /tmp/gomod_"${mod//\//_}".log >&2 || true
            go mod download
        fi
    )
done

echo "[test-setup] Go environment ready (root + server modules, offline-first)"
