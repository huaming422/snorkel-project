#!/usr/bin/env bash
# test-setup.sh — environment bootstrap for the verifier.
# Sourced (not exec'd) by the harbor verifier runner so env vars and
# anything else stay alive for vitest.
#
# Idempotent. The Dockerfile already installs the pnpm dependency closure
# at the base commit (`pnpm install --frozen-lockfile`, store warm under
# /opt/cache/pnpm-dev); we re-run it as a guard only if an agent erased
# node_modules. The verifier here is mock-based (mocked prisma/rpc/fetch),
# so no database, server, or display is needed.

set -e

REPO_DIR="${REPO_DIR:-/repo/rakazo}"
cd "$REPO_DIR"

node --version
pnpm --version

# Reinstall workspace deps only if an agent erased them. Offline-first
# against the warm store; fall back to an online install (logged) if the
# offline store is missing a needed package.
if [ ! -d "node_modules/.pnpm" ]; then
    echo "[test-setup] node_modules missing; reinstalling..."
    if pnpm install --frozen-lockfile --offline 2>&1 | tail -15; then
        echo "[test-setup] offline install ok"
    else
        echo "[test-setup] offline install failed; retrying online (network fallback)..."
        pnpm install --frozen-lockfile 2>&1 | tail -15
    fi
fi

# Generate the Prisma client if an agent erased it. The mock-based tests
# import from @rakazo/db, whose generated client must exist for the module
# to resolve. No database connection is made.
if [ -d "packages/db" ] && [ ! -d "node_modules/.prisma/client" ] \
   && [ ! -d "node_modules/@prisma/client" ]; then
    echo "[test-setup] generating prisma client..."
    pnpm --filter @rakazo/db exec prisma generate 2>&1 | tail -10 || true
fi

# Make workspace binaries available on PATH.
export PATH="$REPO_DIR/node_modules/.bin:$PATH"

# Rebuild the shared contracts package IF it declares a build script, so that a
# submission which publishes its shared settings definitions through a built
# `dist/` entry (rather than shipping native JS in `src/`) has that dist present
# before the verifier loads the module the way the packaged desktop app would.
# A submission that ships native JS directly has no build script here, so this
# is a no-op for it. Never fails the run: a missing/failing build just leaves the
# module to be judged as the submission left it.
if [ -f "packages/contracts/package.json" ] \
   && node -e 'process.exit(require("./packages/contracts/package.json").scripts && require("./packages/contracts/package.json").scripts.build ? 0 : 1)' 2>/dev/null; then
    echo "[test-setup] building @rakazo/contracts (dist entry present in its package manifest)..."
    pnpm --filter @rakazo/contracts run build 2>&1 | tail -10 || \
        echo "[test-setup] contracts build reported an error; continuing (submission judged as-is)"
fi

echo "[test-setup] ready: $REPO_DIR (node=$(node --version), pnpm=$(pnpm --version))"
