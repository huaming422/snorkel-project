// Dedicated vitest config for the host-settings SURFACE validation story.
//
// It provides exactly what rendering apps/web's React surface needs — the
// lingui macro transform, React/JSX, a jsdom DOM, and workspace (@rakazo/*)
// module resolution via the "development" export condition — WITHOUT loading
// apps/web/vite.config.ts. The app's own vite config carries server/proxy
// concerns a submission may legitimately edit (and may import workspace values
// into at config-load time); loading it to run a render test would couple this
// story to those unrelated edits. This config reuses the same plugins (and the
// same plugin order) the app config uses, so the surface transforms and renders
// identically.
import path from "node:path";
import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";
import babel from "@rolldown/plugin-babel";
import { lingui } from "@lingui/vite-plugin";

const webRoot = path.resolve(__dirname);

export default defineConfig({
  root: webRoot,
  plugins: [
    react(),
    babel({ plugins: ["@lingui/babel-plugin-lingui-macro"] }),
    lingui(),
  ],
  resolve: {
    conditions: ["development", "browser", "import", "module", "default"],
  },
  test: {
    environment: "jsdom",
    include: ["src/__validation__/**/*.test.{ts,tsx}"],
    testTimeout: 60_000,
    hookTimeout: 60_000,
  },
});
