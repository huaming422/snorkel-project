// @ts-nocheck
//
// Deterministic verifier for the shared host-settings definitions contract:
// the desktop app must read its shared settings definitions (the settings-page
// address and the in-scope-operation predicate) from ONE shared place that both
// the desktop app and its local server read from, and that shared place must
// load correctly in the desktop app's OWN packaged runtime — native Node with
// no TypeScript loader.
//
// Why this is a verifier and not left to a validation story:
//   The packaged desktop main process is compiled by plain `tsc` (apps/desktop
//   builds `dist/main.js`; there is no bundler) and runs under native Node with
//   NO TypeScript loader. A shared definition that only exists as TypeScript
//   source therefore cannot be loaded by the packaged app, even though it loads
//   fine under the dev/test tooling. That failure is deterministic and does not
//   depend on any submission-chosen name, so it is pinned HERE rather than
//   delegated to an LLM-authored probe that could vary the decisive runtime
//   flag.
//
// Delivery-mechanism-agnostic. The contract requires only "one shared place both
// the desktop app and its local server read from that loads correctly when
// packaged". It does NOT mandate a particular delivery: a submission may ship
// the shared definitions as
//   (a) a runtime value-import of `@rakazo/contracts` (or a subpath) that
//       resolves to native JS / a built `dist/` entry, OR
//   (b) a plain data file (JSON, …) living in a shared workspace package that
//       the desktop code reads at runtime (readFileSync / require / JSON import),
//       which is also copied into the desktop build output alongside the compiled
//       main process (the same static-copy pattern the repo already uses for
//       ui-tokens / tokens.css), OR
//   (c) a relative-path value-import of a native `.js` module that physically
//       lives in (or re-exports, through a native-JS-only chain, a module that
//       lives in) a shared workspace `packages/` directory — e.g. a desktop file
//       `import { … } from "../../../packages/contracts/src/<name>.js"`, or a
//       thin desktop-local `.js` shim that `export … from` that shared native
//       module. This is the same shared definition, reached by relative path
//       instead of the package export map.
// All three load under native Node with no TypeScript loader; a TypeScript-only
// barrel re-export does not. This verifier discovers whichever mechanism the
// submission actually realizes and judges it the way the packaged app would load
// it.
//
// Note on relative `.js` specifiers: this repo is NodeNext, so an ordinary
// TypeScript import is written with a `.js` specifier that resolves to a `.ts`
// file on disk (e.g. `import … from "./main.js"` for `main.ts`). Mechanism (c)
// therefore requires the specifier to resolve to a REAL native `.js`/`.mjs`/`.cjs`
// file that exists on disk — which excludes every ordinary `.ts`-source import
// while capturing a genuine native-JS shared module. A `.js` specifier whose only
// on-disk target is a `.ts` file is not a native-JS mechanism and is skipped here;
// if such a file is reached as a shared-contract module, the native probe rejects
// it in step 3.
//
// What it does, name-independently:
//   1. VALUE-IMPORT mechanism: reads every non-test source file under
//      apps/desktop/src and finds each RUNTIME value-import (not `import type`)
//      whose module specifier is `@rakazo/contracts` or a subpath of it.
//   2. DATA-FILE mechanism: in the same files, finds each shared data file the
//      desktop code reads at runtime — a `*.json` path literal that appears in a
//      read context (readFileSync / readFile / require / `with { type: "json" }`)
//      and resolves to an existing file inside a shared workspace `packages/`
//      directory (i.e. a definition shared with the server, not a desktop-local
//      asset).
//   2b. RELATIVE-NATIVE-JS mechanism: in the same files, finds each RUNTIME
//      value-import whose relative specifier resolves to a real native
//      `.js`/`.mjs`/`.cjs` file on disk that either lives under a shared
//      workspace `packages/` directory, or reaches one through a native-JS-only
//      re-export chain (a desktop-local `.js` shim re-exporting the packages
//      module).
//   3. Spawns a fresh native Node process (`--no-experimental-strip-types`, the
//      packaged app's condition: no TypeScript loader) that loads/reads each
//      discovered mechanism, mirroring how the packaged desktop process loads it.
//   4. Requires that the desktop app reaches its shared settings definitions
//      through at least one mechanism, that EVERY runtime value-import of the
//      shared contract loads natively (a TS-only barrel fails here), and that at
//      least one natively-loadable mechanism exposes the settings-page address
//      plus a working in-scope / out-of-scope operation predicate.
//
// The flag `--no-experimental-strip-types` is fixed here and cannot be altered:
// it is the packaged app's reality (no TS loader). A shared contract shipped
// only as TypeScript (re-exported through a TS-only barrel) fails step 3
// deterministically; one shipped as native JS, a built dist entry, or a plain
// data file passes. tests/test-setup.sh rebuilds @rakazo/contracts first so a
// submission that publishes its shared module through a built `dist/` entry is
// loaded the way the packaged app would load it.

import { describe, expect, it } from "vitest";
import { execFileSync } from "node:child_process";
import { existsSync, readdirSync, readFileSync, statSync } from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

// The js runner copies this file into apps/desktop/src/, so import.meta.url
// points there and the desktop package root is one level up. Fall back to
// repo-root/apps/desktop (config_dir is the repo root).
function locateDesktopDir(): string {
  const here = path.dirname(fileURLToPath(import.meta.url));
  const upOne = path.resolve(here, "..");
  if (existsSync(path.join(upOne, "package.json"))) return upOne;
  const fromRoot = path.resolve(process.cwd(), "apps/desktop");
  if (existsSync(path.join(fromRoot, "package.json"))) return fromRoot;
  return upOne;
}

const DESKTOP_DIR = locateDesktopDir();
const SRC_DIR = path.join(DESKTOP_DIR, "src");
const CONTRACTS_SPEC = /^@rakazo\/contracts(?:\/[^"']+)?$/;

function stripComments(s: string): string {
  // Remove block comments, then line comments (keeping `://` in URLs intact).
  return s.replace(/\/\*[\s\S]*?\*\//g, "").replace(/(^|[^:])\/\/[^\n]*/g, "$1");
}

function walkSource(dir: string): string[] {
  const out: string[] = [];
  for (const entry of readdirSync(dir)) {
    if (["node_modules", "dist", "__validation__", "__verification__"].includes(entry)) continue;
    const full = path.join(dir, entry);
    const st = statSync(full);
    if (st.isDirectory()) out.push(...walkSource(full));
    else if (/\.(ts|cts|mts)$/.test(entry) && !/\.(test|spec)\./.test(entry)) out.push(full);
  }
  return out;
}

// Statement-aware: the clause between `import` and `from` may not span another
// `import`, so each match is a single import statement. We keep only RUNTIME
// value imports — `import type ...` and `import { type A, type B }` are erased
// by the compiler and never reach the packaged runtime.
const IMPORT_RE = /\bimport\b((?:(?!\bimport\b)[\s\S])*?)\bfrom\s*["']([^"']+)["']/g;

// A read of a shared data file: a readFileSync / readFile / require / JSON import
// somewhere in the file, plus `*.json` path literals we resolve against the
// file's own location. A literal that resolves to an existing file inside a
// shared workspace `packages/` directory is a definition shared with the server.
const READ_API_RE = /\b(?:readFileSync|readFile|createReadStream|require)\s*\(|with\s*\{\s*type\s*:\s*["']json["']\s*\}/;
const JSON_LITERAL_RE = /["']([^"']+\.json)["']/g;

// A relative module specifier naming a native JS file (.js / .mjs / .cjs). Used to
// recognize mechanism (c): a value-import whose relative specifier resolves to a
// REAL native JS module on disk. In this NodeNext repo an ordinary TypeScript
// import is written `./foo.js` for `foo.ts`; that `.js` path does not exist on
// disk, so requiring the resolved target to exist as a native JS file excludes
// every ordinary TS-source import and keeps only genuine native-JS modules.
const NATIVE_JS_SPEC_RE = /^\.{1,2}\/.*\.(?:js|mjs|cjs)$/;
// `export ... from "..."` / `import ... from "..."` specifiers inside a native JS
// module, used to follow a native-JS-only re-export chain toward packages/.
const JS_REEXPORT_RE = /\bfrom\s*["']([^"']+)["']/g;

function underPackages(absPath: string): boolean {
  return absPath.split(path.sep).includes("packages");
}

function isNativeJsFile(absPath: string): boolean {
  return /\.(?:js|mjs|cjs)$/.test(absPath) && existsSync(absPath) && statSync(absPath).isFile();
}

// Resolve a relative specifier against the importing file's directory. Returns the
// absolute path only if it names a native JS file that exists on disk.
function resolveNativeJs(fromFile: string, spec: string): string | null {
  if (!NATIVE_JS_SPEC_RE.test(spec)) return null;
  const resolved = path.resolve(path.dirname(fromFile), spec);
  return isNativeJsFile(resolved) ? resolved : null;
}

// Does this native JS module live under packages/, or reach a packages/ native JS
// module through a chain of native-JS re-exports? A desktop-local `.js` shim that
// `export ... from "../../../packages/.../x.js"` counts; a `.js` module that only
// re-exports a `.ts` target (or nothing shared) does not. (The native probe is the
// final arbiter of loadability; this only decides whether the module is a *shared*
// contract worth probing.)
function reachesPackagesNativeJs(absFile: string, seen = new Set<string>()): boolean {
  if (seen.has(absFile)) return false;
  seen.add(absFile);
  if (underPackages(absFile)) return true;
  let text: string;
  try {
    text = stripComments(readFileSync(absFile, "utf8"));
  } catch {
    return false;
  }
  let m: RegExpExecArray | null;
  JS_REEXPORT_RE.lastIndex = 0;
  while ((m = JS_REEXPORT_RE.exec(text)) !== null) {
    const next = resolveNativeJs(absFile, m[1]);
    if (next && reachesPackagesNativeJs(next, seen)) return true;
  }
  return false;
}

function discoverMechanisms(): {
  specifiers: Map<string, string[]>;
  dataFiles: Map<string, string[]>; // absolute json path -> desktop files that read it
  nativeJs: Map<string, string[]>; // absolute native-js path -> desktop files that import it
} {
  const specToFiles = new Map<string, Set<string>>();
  const jsonToFiles = new Map<string, Set<string>>();
  const jsToFiles = new Map<string, Set<string>>();

  for (const file of walkSource(SRC_DIR)) {
    const text = stripComments(readFileSync(file, "utf8"));
    const rel = path.relative(DESKTOP_DIR, file);

    // (a) runtime value-imports of the shared contract package, and
    // (c) runtime value-imports whose relative specifier resolves to a native JS
    //     module that reaches a shared packages/ native-JS module.
    let m: RegExpExecArray | null;
    IMPORT_RE.lastIndex = 0;
    while ((m = IMPORT_RE.exec(text)) !== null) {
      const clause = m[1];
      const spec = m[2];
      const head = clause.replace(/^\s+/, "");
      if (/^type\b/.test(head)) continue; // `import type { ... } from`
      const braced = clause.match(/\{([\s\S]*)\}/);
      if (braced) {
        const members = braced[1].split(",").map((x) => x.trim()).filter(Boolean);
        if (members.length > 0 && members.every((x) => /^type\s/.test(x))) continue; // all type members
      }
      if (CONTRACTS_SPEC.test(spec)) {
        if (!specToFiles.has(spec)) specToFiles.set(spec, new Set());
        specToFiles.get(spec)!.add(rel);
        continue;
      }
      // (c) relative value-import of a native JS module reaching packages/.
      const resolvedJs = resolveNativeJs(file, spec);
      if (resolvedJs && reachesPackagesNativeJs(resolvedJs)) {
        if (!jsToFiles.has(resolvedJs)) jsToFiles.set(resolvedJs, new Set());
        jsToFiles.get(resolvedJs)!.add(rel);
      }
    }

    // (b) runtime reads of a shared data file living in a workspace package
    if (READ_API_RE.test(text)) {
      let j: RegExpExecArray | null;
      JSON_LITERAL_RE.lastIndex = 0;
      while ((j = JSON_LITERAL_RE.exec(text)) !== null) {
        const literal = j[1];
        // Resolve the literal relative to the file that references it. A shared
        // definition resolves to an existing file inside a `packages/` dir; a
        // desktop-local / dist-only basename does not resolve in the source tree.
        const resolved = path.resolve(path.dirname(file), literal);
        if (existsSync(resolved) && underPackages(resolved)) {
          if (!jsonToFiles.has(resolved)) jsonToFiles.set(resolved, new Set());
          jsonToFiles.get(resolved)!.add(rel);
        }
      }
    }
  }

  const specifiers = new Map<string, string[]>();
  for (const [spec, files] of specToFiles) specifiers.set(spec, [...files].sort());
  const dataFiles = new Map<string, string[]>();
  for (const [p, files] of jsonToFiles) dataFiles.set(p, [...files].sort());
  const nativeJs = new Map<string, string[]>();
  for (const [p, files] of jsToFiles) nativeJs.set(p, [...files].sort());
  return { specifiers, dataFiles, nativeJs };
}

type ProbeResult =
  | { loaded: true; pathConst: boolean; predicateOk: boolean; surface: string[] }
  | { loaded: false; errCode: string; errText: string };

// A pristine child env: no NODE_OPTIONS / VITEST_* so the child does not inherit
// vitest's TypeScript-aware loader. This is the packaged runtime.
function pristineEnv(): Record<string, string> {
  const env: Record<string, string> = {};
  for (const [k, v] of Object.entries(process.env)) {
    if (k === "NODE_OPTIONS" || k.startsWith("VITEST")) continue;
    if (v !== undefined) env[k] = v;
  }
  return env;
}

function runProbe(probe: string): ProbeResult {
  try {
    const out = execFileSync(
      process.execPath,
      ["--no-experimental-strip-types", "--input-type=module", "-e", probe],
      { cwd: DESKTOP_DIR, env: pristineEnv(), stdio: "pipe" },
    ).toString();
    const parsed = JSON.parse(out);
    return {
      loaded: true,
      pathConst: parsed.pathConst,
      predicateOk: parsed.predicateOk,
      surface: parsed.surface,
    };
  } catch (e: any) {
    const errText = (e?.stderr?.toString?.() ?? String(e)).split("\n").slice(0, 6).join("\n");
    const errCode = (errText.match(/ERR_[A-Z_]+/) ?? ["<none>"])[0];
    return { loaded: false, errCode, errText };
  }
}

// The in-scope / out-of-scope check, shared by both mechanisms and run inside the
// native child. We derive the in-scope operation from the module/file's OWN
// exported operation allowlist when one is present (so the probe tracks the
// submission's chosen operations, not a hardcoded sentinel), and fall back to the
// common model/settings operations otherwise (e.g. a submission that exposes a
// predicate function but keeps its allowlist private). An out-of-scope operation
// is drawn from pre-existing general application operations guaranteed not to be
// in any settings allowlist.
//
// `collect(src)` returns { strs, fns, arrays } where:
//   strs   = all non-empty string values reachable in the surface
//   fns    = exported functions (predicate candidates; data files have none)
//   arrays = arrays of non-empty strings (operation-allowlist candidates)
const PROBE_COMMON = `
const FOREIGN = ["bots/list", "admin/users", "spaces/list"];
const FALLBACK_INSCOPE = ["me", "health", "models/list", "integrationSetup/get"];
function collect(src) {
  const strs = [], fns = [], arrays = [];
  const seen = new Set();
  function visit(v, depth) {
    if (v == null || depth > 3) return;
    if (typeof v === "string") { if (v.length > 0) strs.push(v); return; }
    if (typeof v === "function") { fns.push(v); return; }
    if (Array.isArray(v)) {
      if (v.length > 0 && v.every((x) => typeof x === "string" && x.length > 0)) arrays.push(v);
      for (const x of v) visit(x, depth + 1);
      return;
    }
    if (typeof v === "object") {
      if (seen.has(v)) return; seen.add(v);
      for (const k of Object.keys(v)) { try { visit(v[k], depth + 1); } catch {} }
    }
  }
  visit(src, 0);
  return { strs, fns, arrays };
}
function pathConstOf(strs) { return strs.some((v) => v.startsWith("/")); }
function foreignNotIn(allow) {
  for (const g of FOREIGN) if (!allow.includes(g)) return g;
  return "zzz/" + Math.random().toString(36).slice(2);
}
// Membership predicate: an allowlist array that accepts an in-scope op (its own
// first entry) while excluding a general op. Name-independent, derived from the
// submission's own allowlist.
function predicateFromArrays(arrays) {
  for (const allow of arrays) {
    const inOp = allow[0];
    const foreign = foreignNotIn(allow);
    if (allow.includes(inOp) && !allow.includes(foreign)) return true;
  }
  return false;
}
// Function predicate (value-import modules): find a fn that ACCEPTS an in-scope
// settings op (under whatever prefix/path form the module's constants imply) and
// REJECTS an out-of-scope one. In-scope candidates prefer the module's own
// exported allowlist, then fall back to common settings ops.
function predicateFromFns(fns, strs, arrays) {
  const inScope = [...arrays.flatMap((a) => a), ...FALLBACK_INSCOPE];
  const prefixes = ["", ...strs];
  const forms = (op) => {
    const o = new Set([op, "/" + op, op.replace(/\\//g, "."), op.replace(/\\./g, "/")]);
    for (const p of prefixes) o.add(p + "/" + op);
    return [...o];
  };
  for (const f of fns) {
    for (const op of inScope) {
      for (const form of forms(op)) {
        let good = false;
        try { good = f(form) === true; } catch {}
        if (!good) continue;
        const base = form.slice(0, form.length - op.length);
        let allRejected = true;
        for (const g of FOREIGN) {
          let r;
          try { r = f(base + g); } catch { r = "ERR"; }
          if (r === true) { allRejected = false; break; }
        }
        if (allRejected) return true;
      }
    }
  }
  return false;
}
function surfaceOf(src) {
  if (src && typeof src === "object" && !Array.isArray(src)) return Object.keys(src);
  return [];
}
`;

function probeNativeImport(spec: string): ProbeResult {
  const probe = [
    `import * as m from ${JSON.stringify(spec)};`,
    PROBE_COMMON,
    `const { strs, fns, arrays } = collect(m);`,
    `const pathConst = pathConstOf(strs);`,
    `const predicateOk = predicateFromFns(fns, strs, arrays) || predicateFromArrays(arrays);`,
    `process.stdout.write(JSON.stringify({ pathConst, predicateOk, surface: Object.keys(m) }));`,
  ].join("\n");
  return runProbe(probe);
}

// (c) probe: dynamically import the native JS module by file URL in the packaged
// runtime (no TypeScript loader). A module that re-exports a `.ts` target (or any
// module not loadable without a TS loader) throws here — a fair failure.
function probeNativeJsImport(jsPath: string): ProbeResult {
  const probe = [
    `import * as m from ${JSON.stringify(pathToFileURL(jsPath).href)};`,
    PROBE_COMMON,
    `const { strs, fns, arrays } = collect(m);`,
    `const pathConst = pathConstOf(strs);`,
    `const predicateOk = predicateFromFns(fns, strs, arrays) || predicateFromArrays(arrays);`,
    `process.stdout.write(JSON.stringify({ pathConst, predicateOk, surface: Object.keys(m) }));`,
  ].join("\n");
  return runProbe(probe);
}

function probeNativeData(jsonPath: string): ProbeResult {
  const probe = [
    `import { readFileSync } from "node:fs";`,
    `const d = JSON.parse(readFileSync(${JSON.stringify(jsonPath)}, "utf8"));`,
    PROBE_COMMON,
    `const { strs, fns, arrays } = collect(d);`,
    `const pathConst = pathConstOf(strs);`,
    `const predicateOk = predicateFromArrays(arrays) || predicateFromFns(fns, strs, arrays);`,
    `process.stdout.write(JSON.stringify({ pathConst, predicateOk, surface: surfaceOf(d) }));`,
  ].join("\n");
  return runProbe(probe);
}

const { specifiers, dataFiles, nativeJs } = discoverMechanisms();
const probedSpecs = new Map<string, ProbeResult>();
for (const spec of specifiers.keys()) probedSpecs.set(spec, probeNativeImport(spec));
const probedData = new Map<string, ProbeResult>();
for (const p of dataFiles.keys()) probedData.set(p, probeNativeData(p));
const probedNativeJs = new Map<string, ProbeResult>();
for (const p of nativeJs.keys()) probedNativeJs.set(p, probeNativeJsImport(p));

function rel(abs: string): string {
  const r = path.relative(DESKTOP_DIR, abs);
  return r.startsWith("..") ? abs : r;
}

describe("shared host-settings definitions load in the packaged desktop runtime", () => {
  it("the desktop app reaches its shared settings definitions through a shared mechanism (value-import, shared data file, or relative native-JS import)", () => {
    const specWhere = [...specifiers.entries()].map(([s, fs]) => `${s} (in ${fs.join(", ")})`);
    const dataWhere = [...dataFiles.entries()].map(([p, fs]) => `${rel(p)} (read by ${fs.join(", ")})`);
    const jsWhere = [...nativeJs.entries()].map(([p, fs]) => `${rel(p)} (imported by ${fs.join(", ")})`);
    expect(
      specifiers.size + dataFiles.size + nativeJs.size,
      "No non-test file under apps/desktop/src reaches a shared host-settings definition at runtime. " +
        "The packaged desktop app must read its shared settings definitions from ONE shared place both it " +
        "and its local server read — either a RUNTIME value-import of @rakazo/contracts (or a subpath), a " +
        "runtime read (readFileSync / require / JSON import) of a data file living in a shared workspace " +
        "packages/ directory, or a RUNTIME value-import whose relative specifier resolves to a native " +
        ".js/.mjs/.cjs module that reaches a shared packages/ directory. Discovered value-imports: " +
        JSON.stringify(specWhere) + "; discovered shared data files: " + JSON.stringify(dataWhere) +
        "; discovered relative native-JS imports: " + JSON.stringify(jsWhere),
    ).toBeGreaterThan(0);
  });

  it("every shared-contract module the desktop app value-imports at runtime loads under native Node with no TypeScript loader", () => {
    const failures: string[] = [];
    for (const [spec, files] of specifiers) {
      const r = probedSpecs.get(spec)!;
      if (!r.loaded) {
        failures.push(
          `  ${spec} (imported by ${files.join(", ")}) failed to load with ` +
            `--no-experimental-strip-types [${r.errCode}]:\n` +
            r.errText.split("\n").map((l) => "    " + l).join("\n"),
        );
      }
    }
    for (const [p, files] of nativeJs) {
      const r = probedNativeJs.get(p)!;
      if (!r.loaded) {
        failures.push(
          `  ${rel(p)} (relative-imported by ${files.join(", ")}) failed to load with ` +
            `--no-experimental-strip-types [${r.errCode}]:\n` +
            r.errText.split("\n").map((l) => "    " + l).join("\n"),
        );
      }
    }
    expect(
      failures.length,
      "A shared-contract module the packaged desktop app value-imports at runtime does NOT load under native " +
        "Node with the TypeScript loader disabled (the packaged app has no TS loader). This happens when the " +
        "shared definitions are shipped only as TypeScript (e.g. re-exported through a TS-only barrel) with no " +
        "native JS / built dist entry for the subpath the desktop code imports. A submission that instead ships " +
        "the definitions as native JS, a built dist entry, or a shared data file does not hit this. Offending " +
        "modules:\n" + failures.join("\n"),
    ).toBe(0);
  });

  it("the shared settings definitions expose the settings-page address and an in-scope operation predicate natively", () => {
    const loaded: Array<{ label: string; r: Extract<ProbeResult, { loaded: true }> }> = [];
    const diag: string[] = [];
    for (const [spec] of specifiers) {
      const r = probedSpecs.get(spec)!;
      if (r.loaded) loaded.push({ label: `import ${spec}`, r });
      diag.push(
        r.loaded
          ? `  import ${spec}: pathConst=${r.pathConst} predicate=${r.predicateOk} surface=${JSON.stringify(r.surface)}`
          : `  import ${spec}: did not load [${r.errCode}]`,
      );
    }
    for (const [p] of dataFiles) {
      const r = probedData.get(p)!;
      if (r.loaded) loaded.push({ label: `data ${rel(p)}`, r });
      diag.push(
        r.loaded
          ? `  data ${rel(p)}: pathConst=${r.pathConst} predicate=${r.predicateOk} surface=${JSON.stringify(r.surface)}`
          : `  data ${rel(p)}: did not read [${r.errCode}]`,
      );
    }
    for (const [p] of nativeJs) {
      const r = probedNativeJs.get(p)!;
      if (r.loaded) loaded.push({ label: `native-js ${rel(p)}`, r });
      diag.push(
        r.loaded
          ? `  native-js ${rel(p)}: pathConst=${r.pathConst} predicate=${r.predicateOk} surface=${JSON.stringify(r.surface)}`
          : `  native-js ${rel(p)}: did not load [${r.errCode}]`,
      );
    }
    const withSurface = loaded.filter(({ r }) => r.pathConst && r.predicateOk);
    expect(
      withSurface.length,
      "No natively-loadable shared mechanism exposes BOTH a settings-page address (a string value beginning " +
        "with '/') AND an in-scope-operation predicate (a predicate function that accepts an in-scope settings " +
        "operation while rejecting an out-of-scope one, or an operation allowlist that includes a settings " +
        "operation while excluding a general application operation). The shared settings definitions (page " +
        "address + in-scope-operation predicate) must live in the shared place the packaged desktop app loads. " +
        "Per-mechanism findings:\n" + diag.join("\n"),
    ).toBeGreaterThan(0);
  });
});
