## Task

Once a desktop user finishes setup, there's currently no way for them to go back and change their model settings or server integrations from the desktop app itself, and there's no way at all to do it while signed out. The in-app server menu doesn't surface any of this today. We want to give the desktop host a way to reach those settings directly from the app, including when nobody is signed in.

This has to stay host-only. The desktop machine runs its own local copy of the server, and only that host should be able to open this door. An ordinary signed-in browser session, or anyone coming in through the regular web app, must not be able to reach these settings this way. Treat that as the crux of the work: the host path is for the host and nothing else.

The authenticated settings experience on web and mobile is out of scope; leave it as it is today. This is purely additive and centered on the desktop host.

## User stories / requirements

- The desktop host reaches these settings by presenting a secret it has been configured with. A request that doesn't carry that secret, including one backed only by an ordinary signed-in browser session, is refused access to these settings.
- When the host is authorized, the settings apply to the deployment's owner account, which the server determines on its own; it ignores any account or workspace the caller names. If there is no owner account yet, the request is turned away instead of proceeding.
- Only the settings operations needed to manage models and server integrations are reachable through the host path. Other application operations stay off-limits through this path, even for an authorized host.
- For these settings, the desktop app talks only to its own local server, and only for the operations it is allowed to perform. It does not attach ordinary browser credentials to those requests, and it does not follow the request off to any other location.
- The settings surface's definitions, covering which operations it offers and the address it lives at, are kept in one shared place that both the desktop app and its local server read from. That shared place loads correctly when the desktop app runs as a packaged application, not only under the development tooling.
- From the desktop app, the host can open a settings surface without being signed in, and that surface lets the host manage its models and its server integrations. The surface opens on the dedicated host settings address rather than through the ordinary signed-in web flow.
- The host can open the settings surface from within the desktop app itself, not only by browsing to its address. An in-app entry, a dedicated settings window or a menu entry that opens one, takes the host to the shared host settings address and lets that surface work once it is shown.
