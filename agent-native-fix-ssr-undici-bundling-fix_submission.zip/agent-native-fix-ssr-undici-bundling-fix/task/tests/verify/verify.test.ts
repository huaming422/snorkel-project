// @ts-nocheck
//
// Behavioral verifier. Drives the pre-existing, stable exported seam
// `copyInstalledExternalSsrPackages(serverDir, projectCwd)` exactly the way
// the package's own build.spec.ts "copyInstalledExternalSsrPackages" block
// does: build a hermetic temp project whose node_modules holds a synthetic
// install of the Node-only dispatcher package, drop an emitted server chunk
// that references it one specific way, run the post-build copy step, and
// assert which packages landed next to the function.
//
// Observable contract asserted here (never the detection mechanism):
//   - a chunk whose reference uses a template-literal (backtick) specifier
//     must cause the package to be copied into the function directory;
//   - a chunk whose reference uses an ordinary straight-quote specifier must
//     still cause it to be copied (no regression);
//   - a chunk with no reference at all must not cause it to be copied.
//
// Assertions use concrete observable data: the copied package's manifest
// existing on disk, and copy-count membership (>= 1 / 0) — never an exact
// total-count equality, which would be brittle to equally-valid fixes that
// also adjust the external-package set.

import fs from "fs";
import path from "path";

import { afterEach, describe, expect, it } from "vitest";

import { copyInstalledExternalSsrPackages } from "./build.js";

const RUNTIME_DISPATCHER_PACKAGE = "undici";

const tempDirs: string[] = [];

afterEach(() => {
  for (const directory of tempDirs.splice(0)) {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

// Build a hermetic project: a temp root with a synthetic node_modules install
// of the dispatcher package, plus an empty server bundle directory with the
// generated function manifest. Returns both paths. Mirrors build.spec.ts.
function makeProject(): { root: string; serverDir: string } {
  const root = fs.mkdtempSync(
    path.join(process.cwd(), ".tmp-ssr-copy-verify-"),
  );
  tempDirs.push(root);

  const installedPackageDir = path.join(
    root,
    "node_modules",
    RUNTIME_DISPATCHER_PACKAGE,
  );
  fs.mkdirSync(installedPackageDir, { recursive: true });
  fs.writeFileSync(
    path.join(installedPackageDir, "package.json"),
    JSON.stringify({ name: RUNTIME_DISPATCHER_PACKAGE, version: "7.28.0" }),
  );

  const serverDir = path.join(root, "server");
  fs.mkdirSync(serverDir, { recursive: true });
  fs.writeFileSync(
    path.join(serverDir, "package.json"),
    JSON.stringify({ name: "traced-node-modules", dependencies: {} }),
  );

  return { root, serverDir };
}

function writeChunk(serverDir: string, source: string): void {
  fs.writeFileSync(path.join(serverDir, "chunk.mjs"), source);
}

function dispatcherManifestCopied(serverDir: string): boolean {
  return fs.existsSync(
    path.join(
      serverDir,
      "node_modules",
      RUNTIME_DISPATCHER_PACKAGE,
      "package.json",
    ),
  );
}

describe("deployed serverless bundle copies the Node-only dispatcher package", () => {
  // FAIL-TO-PASS (basic_functionality).
  // The emitted server chunk references the dispatcher package only through a
  // template-literal (backtick) import specifier — the form the opaque,
  // browser-safe import leaves behind. The post-build copy step must still
  // recognize it and ship the package next to the function. Pre-fix this is
  // missed and nothing is copied; post-fix the package lands.
  it("copies the dispatcher when the only reference is a template-literal specifier", () => {
    const { root, serverDir } = makeProject();
    writeChunk(
      serverDir,
      "const react = require(`react`);\n" +
        "export { Link } from \"react-router\";\n" +
        "export * from \"@tanstack/react-query\";\n" +
        "await import(`undici`);\n" +
        "export { react };",
    );

    const copiedCount = copyInstalledExternalSsrPackages(serverDir, root);

    expect(
      dispatcherManifestCopied(serverDir),
      "expected the dispatcher package to be copied into the function directory when the chunk references it via a backtick/template-literal specifier, but its package.json was not found there",
    ).toBe(true);
    expect(
      copiedCount,
      "expected the post-build copy step to report copying at least one package for the backtick-specifier chunk",
    ).toBeGreaterThanOrEqual(1);
  });

  // PASS-TO-PASS (regression guard).
  // An ordinary straight-quote import specifier for the dispatcher package
  // must keep being detected and copied. Passes both pre- and post-fix; guards
  // against a fix that broadens one delimiter form while dropping another.
  it("copies the dispatcher when referenced via a straight-quote specifier", () => {
    const { root, serverDir } = makeProject();
    writeChunk(
      serverDir,
      "const react = require(`react`);\n" +
        "export { Link } from \"react-router\";\n" +
        "const dispatcherSpecifier = \"undici\";\n" +
        "await import(dispatcherSpecifier);\n" +
        "export { react };",
    );

    const copiedCount = copyInstalledExternalSsrPackages(serverDir, root);

    expect(
      dispatcherManifestCopied(serverDir),
      "expected the dispatcher package to still be copied into the function directory when referenced via an ordinary straight-quote specifier (regression guard)",
    ).toBe(true);
    expect(
      copiedCount,
      "expected the post-build copy step to report copying at least one package for the straight-quote-specifier chunk",
    ).toBeGreaterThanOrEqual(1);
  });

  // PASS-TO-PASS (over-correction guard).
  // A chunk that never references the dispatcher package at all must NOT cause
  // it to be copied. Passes both pre- and post-fix; rejects the shortcut of
  // unconditionally always copying the package regardless of references.
  it("does not copy the dispatcher when the chunk has no reference to it", () => {
    const { root, serverDir } = makeProject();
    writeChunk(
      serverDir,
      "const react = require(`react`);\n" +
        "export { Link } from \"react-router\";\n" +
        "export * from \"@tanstack/react-query\";\n" +
        "export { react };",
    );

    copyInstalledExternalSsrPackages(serverDir, root);

    expect(
      dispatcherManifestCopied(serverDir),
      "expected the dispatcher package NOT to be copied into the function directory when the chunk never references it (over-correction guard against unconditionally copying)",
    ).toBe(false);
  });
});
