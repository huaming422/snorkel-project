#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
# Brings the baked dependency closure online offline-first and makes sure the
# vitest runner for the core package is usable.

cd /repo/agent-native

# Keep every resolver offline-first so a cache miss fails fast instead of
# silently reaching a registry (the smoke gate sources this with --network none).
export npm_config_offline=true

# pnpm ≥ 9 refuses to remove node_modules without a TTY when CI is not set,
# even for an --offline install that only needs to reorganise the existing bake.
# Modal sandboxes and the smoke gate's --network-none container have no TTY,
# so we declare the CI flag here rather than setting it system-wide in the image.
export CI=true

# Dependencies: offline-first against the image bake, logged online fallback.
if pnpm install --offline --frozen-lockfile --ignore-scripts > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] deps satisfied from image"
elif pnpm install --frozen-lockfile --ignore-scripts >> /tmp/test-setup-install.log 2>&1; then
    echo "[test-setup] deps installed online (image bake was stale)"
else
    tail -40 /tmp/test-setup-install.log >&2; exit 1
fi

# The core package's test runner is vitest; the verifier drives it through
# verify.toml. Confirm the binary resolves so a corrupt node_modules fails
# here with a clear message instead of deep inside the runner.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/ — image bake is corrupt." >&2
    exit 1
fi

echo "test-setup.sh: ready. vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
