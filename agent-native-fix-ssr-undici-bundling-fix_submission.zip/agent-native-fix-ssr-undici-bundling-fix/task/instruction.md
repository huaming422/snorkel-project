## Task

self-hosted Clips deployments that point at their own public, S3-compatible storage can't play back recordings anymore. the player errors out the moment it tries to pull the media. it only shows up on deployed edge/serverless builds of the template; local dev is fine and the default storage path is fine, and this used to work. dig into why and fix it.
