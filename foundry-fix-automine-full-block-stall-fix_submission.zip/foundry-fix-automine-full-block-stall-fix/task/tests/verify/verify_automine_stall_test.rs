//! Integration tests for automine block production under a gas-capped burst.
//!
//! These drive an in-process node through its public `spawn()` / provider
//! surface only — the same surface a user script hits. They are written
//! entirely in terms of observable behavior (receipts landing, pool
//! draining, block numbers advancing), so they do not depend on how the
//! node decides whether to produce another block.
//!
//! Three scenarios:
//!
//!   1. `burst_exceeding_one_block_fully_drains_under_automine` — a
//!      same-sender burst larger than one block's gas budget is queued, then
//!      automine is switched on. Every transaction must receive a receipt,
//!      the sender nonce must advance by the full count, and the pool must
//!      drain to empty — with no external prod. A node that stalls seals a
//!      single block and then idles with the surplus stuck in the pool, so
//!      the receipts never arrive and this times out.
//!
//!   2. `never_includable_tx_does_not_spin_empty_blocks` — a pool holding
//!      only a transaction whose own declared gas exceeds the block budget
//!      (so it can never be included) must not drive the chain into a run of
//!      empty blocks once mining is active.
//!
//!   3. `burst_fitting_one_block_mines_in_one_block` — a burst that fits a
//!      single block, under automine, still seals in exactly one block with
//!      every receipt present and no spurious empty blocks.
//!
//! The file is a standalone integration-test binary, so it can only reach
//! the `anvil` crate's public API plus its (dev-)dependencies.

use alloy_network::{Network, TransactionBuilder};
use alloy_primitives::{Address, TxHash, U256};
use alloy_provider::Provider;
use alloy_rpc_types::TransactionRequest;
use alloy_serde::WithOtherFields;
use anvil::{NodeConfig, spawn};
use std::time::{Duration, Instant};

/// A plain value transfer costs 21_000 gas.
const TRANSFER_GAS: u64 = 21_000;

/// Build a funded value-transfer request with an explicit nonce and gas limit.
fn transfer(from: Address, to: Address, nonce: u64, gas_limit: u64) -> WithOtherFields<TransactionRequest> {
    let tx = TransactionRequest::default()
        .with_from(from)
        .with_to(to)
        .with_value(U256::from(1))
        .with_nonce(nonce)
        .with_gas_limit(gas_limit);
    WithOtherFields::new(tx)
}

/// Poll `get_transaction_receipt` for every hash until all are present or the
/// deadline passes. Returns how many receipts landed. Polling (rather than a
/// single pending-transaction future) keeps the wait robust to how the node
/// schedules follow-up blocks.
async fn wait_for_receipts<N: Network, P: Provider<N>>(provider: &P, hashes: &[TxHash], timeout: Duration) -> usize {
    let deadline = Instant::now() + timeout;
    loop {
        let mut landed = 0usize;
        for h in hashes {
            if provider.get_transaction_receipt(*h).await.ok().flatten().is_some() {
                landed += 1;
            }
        }
        if landed == hashes.len() {
            return landed;
        }
        if Instant::now() >= deadline {
            return landed;
        }
        tokio::time::sleep(Duration::from_millis(100)).await;
    }
}

/// A burst exceeding one block's gas budget is fully mined across follow-up
/// blocks under automine, with no external prod — every receipt lands, the
/// nonce advances by the full count, and the pool drains to empty.
#[tokio::test(flavor = "multi_thread")]
async fn burst_exceeding_one_block_fully_drains_under_automine() {
    // Block budget with room for exactly three transfers; a five-transfer
    // burst therefore cannot fit in a single block.
    let (api, handle) = spawn(NodeConfig::test().with_gas_limit(Some(3 * TRANSFER_GAS))).await;
    let provider = handle.http_provider();
    let accounts = handle.dev_wallets().collect::<Vec<_>>();
    let from = accounts[0].address();
    let to = accounts[1].address();

    // Queue the whole burst while mining is paused so it is selected as one
    // ready set the moment automine is switched on.
    api.anvil_set_auto_mine(false).await.unwrap();

    const BURST: u64 = 5;
    let mut hashes = Vec::new();
    for nonce in 0..BURST {
        let pending = provider
            .send_transaction(transfer(from, to, nonce, TRANSFER_GAS))
            .await
            .unwrap();
        hashes.push(*pending.tx_hash());
    }

    // Turn automine on: the miner selects all five ready txs, only three fit
    // the first block, and the remaining two must be mined in follow-up
    // blocks without any further prod.
    api.anvil_set_auto_mine(true).await.unwrap();

    let landed = wait_for_receipts(&provider, &hashes, Duration::from_secs(20)).await;
    assert_eq!(
        landed, BURST as usize,
        "only {landed}/{BURST} transactions were mined: a burst larger than one block's gas \
         budget left its surplus stuck in the pool with the node idle. Every queued transaction \
         must be mined across follow-up blocks under automine with no external prod."
    );

    let nonce = provider.get_transaction_count(from).await.unwrap();
    assert_eq!(nonce, BURST, "sender nonce advanced to {nonce}, expected {BURST} (all txs mined)");

    let pending = api.txpool_status().await.unwrap().pending;
    assert_eq!(pending, 0, "pool still holds {pending} pending tx(s); it must drain to empty");
}

/// A pool holding only a transaction that can never be included must not grow
/// the chain with a run of empty blocks once mining is active.
#[tokio::test(flavor = "multi_thread")]
async fn never_includable_tx_does_not_spin_empty_blocks() {
    // Admit the transaction under the default (ample) block budget — a tx
    // whose declared gas exceeds the block budget is rejected at pool entry,
    // so it has to be accepted first and the budget shrunk afterwards.
    let (api, handle) = spawn(NodeConfig::test()).await;
    let provider = handle.http_provider();
    let accounts = handle.dev_wallets().collect::<Vec<_>>();
    let from = accounts[0].address();
    let to = accounts[1].address();

    api.anvil_set_auto_mine(false).await.unwrap();

    // One transfer whose own declared gas limit is far larger than the budget
    // we are about to impose, so no block can ever include it.
    let big_gas = 2_000_000u64;
    let pending = provider.send_transaction(transfer(from, to, 0, big_gas)).await.unwrap();
    let stuck = *pending.tx_hash();

    // Shrink the block budget below the transaction's declared gas: it is now
    // permanently un-includable but still sits ready in the pool.
    assert!(
        api.evm_set_block_gas_limit(U256::from(TRANSFER_GAS)).unwrap(),
        "evm_setBlockGasLimit should report success"
    );

    let start = provider.get_block_number().await.unwrap();

    // Switch mining on and let the node make its single attempt at the stuck
    // tx. A correct node seals at most the one block it tries the tx in, then
    // parks; a node that re-mines unconditionally spins empty blocks for as
    // long as the tx stays ready. Give it a settle window, then sample the
    // chain height twice far enough apart that a spinning node is unmistakable.
    api.anvil_set_auto_mine(true).await.unwrap();
    tokio::time::sleep(Duration::from_millis(2_000)).await;
    let mid = provider.get_block_number().await.unwrap();
    tokio::time::sleep(Duration::from_millis(2_000)).await;
    let end = provider.get_block_number().await.unwrap();

    assert_eq!(
        end, mid,
        "the chain is still advancing ({mid} -> {end}) with nothing mineable in the pool: the \
         node is spinning empty blocks for a transaction that can never be included."
    );
    assert!(
        mid - start <= 1,
        "the chain climbed by {} blocks ({start} -> {mid}) for a single never-includable \
         transaction; at most one block should be attempted before the node parks.",
        mid - start
    );

    // The un-includable tx is still pending and un-mined, as it must be.
    assert!(
        provider.get_transaction_receipt(stuck).await.unwrap().is_none(),
        "a transaction that exceeds the block gas budget must not receive a receipt"
    );
    let pending_count = api.txpool_status().await.unwrap().pending;
    assert_eq!(pending_count, 1, "the never-includable tx should remain pending, saw {pending_count}");
}

/// A burst that fits one block still mines in exactly one block under
/// automine — every receipt lands, the pool drains, and no spurious empty
/// blocks are produced.
#[tokio::test(flavor = "multi_thread")]
async fn burst_fitting_one_block_mines_in_one_block() {
    // Budget with room for three transfers; a two-transfer burst fits.
    let (api, handle) = spawn(NodeConfig::test().with_gas_limit(Some(3 * TRANSFER_GAS))).await;
    let provider = handle.http_provider();
    let accounts = handle.dev_wallets().collect::<Vec<_>>();
    let from = accounts[0].address();
    let to = accounts[1].address();

    api.anvil_set_auto_mine(false).await.unwrap();

    const BURST: u64 = 2;
    let mut hashes = Vec::new();
    for nonce in 0..BURST {
        let pending = provider
            .send_transaction(transfer(from, to, nonce, TRANSFER_GAS))
            .await
            .unwrap();
        hashes.push(*pending.tx_hash());
    }

    let start = provider.get_block_number().await.unwrap();
    api.anvil_set_auto_mine(true).await.unwrap();

    let landed = wait_for_receipts(&provider, &hashes, Duration::from_secs(10)).await;
    assert_eq!(landed, BURST as usize, "a burst that fits one block must fully mine; saw {landed}/{BURST}");

    let pending = api.txpool_status().await.unwrap().pending;
    assert_eq!(pending, 0, "pool should be empty after a single block, saw {pending} pending");

    // Let any stray follow-up mining settle, then confirm the chain advanced
    // by exactly one block — no spurious empties.
    tokio::time::sleep(Duration::from_millis(1_000)).await;
    let end = provider.get_block_number().await.unwrap();
    assert_eq!(
        end - start,
        1,
        "a one-block burst advanced the chain by {} blocks ({start} -> {end}); it must seal in \
         exactly one block with no spurious empty blocks.",
        end - start
    );
}
