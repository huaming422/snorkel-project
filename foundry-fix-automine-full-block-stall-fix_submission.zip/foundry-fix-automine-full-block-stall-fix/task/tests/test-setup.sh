#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier runs (set -euo pipefail inherited).
# The image already baked the full dependency closure at the base commit and
# pre-warmed the `anvil` library and integration-test build caches, so nothing
# is fetched here. Fail fast on any cache miss instead of reaching for a dead
# network.
cd /repo/foundry

# Offline switch: a cache miss must fail immediately, not hang on a registry.
# Put it here (never image-wide ENV) so only the task's own cargo sees it.
export CARGO_NET_OFFLINE=true

# Pin the C/C++ build-script flags to the exact values the image warm compiled the
# native `-sys` crates under (set image-wide, both empty). The `cc` crate fingerprints
# every native build script on CFLAGS/CXXFLAGS; if the container injects either
# variable, cargo reports "the env variable CFLAGS changed", rebuilds the whole C/C++
# closure, and that rebuild drags in a crate whose build script fetches from the network
# — which is offline here, so the build aborts. Re-forcing the warm's values right before
# the suite keeps the fingerprint stable and the pre-warmed cache valid.
export CFLAGS=
export CXXFLAGS=

echo "[test-setup] Rust version:   $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:  $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root: /repo/foundry"

# Deps are satisfied entirely from the image bake; confirm the lockfile resolves
# offline so a stale bake surfaces here rather than mid-verifier.
if cargo fetch --locked --offline > /tmp/test-setup-fetch.log 2>&1; then
    echo "[offline-first] cargo deps satisfied from image"
else
    tail -40 /tmp/test-setup-fetch.log >&2
    echo "[test-setup] cargo fetch could not resolve offline — image bake is stale" >&2
    exit 1
fi

echo "[test-setup] Setup complete."
