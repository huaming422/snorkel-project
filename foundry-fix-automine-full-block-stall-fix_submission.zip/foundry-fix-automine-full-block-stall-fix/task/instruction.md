## Task

When we fire a burst of transactions at a local anvil node with automine on, some of them just never get mined: their receipts never come back. The node mines one block and then sits idle with the leftover transactions still sitting in the pool. It only happens when the burst is big enough that not everything fits in one block; smaller bursts that fit in a single block are fine. A script that sends a batch back-to-back and waits on all the receipts just hangs forever. Can you dig into why the node stalls like this and get it mining the leftovers?
