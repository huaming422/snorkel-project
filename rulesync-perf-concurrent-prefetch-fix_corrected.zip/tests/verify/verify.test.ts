// @ts-nocheck
//
// Checks for `rulesync install` with many GitHub-hosted sources, run through the
// public `resolveAndFetchSources` entry point on a real temporary project.
//
// GitHub is played by a stand-in for `fetch`, the call Octokit makes for every
// API request, so the repo's real `GitHubClient` and any code around it run
// unchanged on top of it. The stand-in serves each repository from an
// in-memory file list, waits a set time per request, and records every
// request with when it started and ended. Curated files and the lockfile are
// read back from disk.
//
// Expected files, lockfiles, log lines and request counts are what install
// produces today for the same configs.

import { createHash, randomUUID } from "node:crypto";
import { mkdir, readdir, readFile, rm, stat, writeFile } from "node:fs/promises";
import { join, relative } from "node:path";

import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { createMockLogger } from "../test-utils/mock-logger.js";
import { setupTestDirectory } from "../test-utils/test-directories.js";
import { resolveAndFetchSources } from "./sources.js";

// Every `fetch` made while this file runs goes to the current case's stand-in,
// including a copy of `fetch` that a module saved when it loaded.
const network = vi.hoisted(() => {
  const state = { handler: undefined };
  globalThis.fetch = (input, init) => {
    if (!state.handler) {
      return Promise.reject(new TypeError("fetch failed: no stand-in GitHub for this case"));
    }
    return state.handler(input, init);
  };
  return state;
});

// git-transport sources run the git CLI; these cases answer its calls directly.
vi.mock("./git-client.js", () => ({
  GitClientError: class GitClientError extends Error {
    constructor(message: string, cause?: unknown) {
      super(message);
      this.name = "GitClientError";
      this.cause = cause;
    }
  },
  validateGitUrl: vi.fn(),
  validateRef: vi.fn(),
  checkGitAvailable: vi.fn(),
  resetGitCheck: vi.fn(),
  resolveDefaultRef: vi.fn(),
  resolveRefToSha: vi.fn(),
  fetchSkillFiles: vi.fn(),
}));

// ---------------------------------------------------------------------------
// Stand-in GitHub
// ---------------------------------------------------------------------------

type RepoFile = { content: string; executable?: boolean };

const sha1 = (text: string) => createHash("sha1").update(text).digest("hex");

const jsonResponse = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" },
  });

class StandInGitHub {
  readonly repos = new Map();
  readonly requests = [];
  inFlight = 0;
  maxInFlight = 0;
  latency = () => 0;
  failure = () => undefined;
  private readonly salt = randomUUID();

  /**
   * Add a repository, or push a new commit to it with these files. Commit and
   * folder SHAs follow from what they hold, as in git, and each case's
   * stand-in salts them, so no two cases ever share one.
   */
  addRepo(fullName: string, files: Record<string, string | RepoFile>, defaultBranch = "main") {
    const [owner, name] = fullName.split("/");
    const repo = this.repos.get(fullName) ?? { owner, name, defaultBranch, commits: [] };
    repo.defaultBranch = defaultBranch;
    const fileMap = new Map(
      Object.entries(files)
        .map(([path, file]) => [path, typeof file === "string" ? { content: file } : file])
        .toSorted(([a], [b]) => a.localeCompare(b)),
    );
    const commit = {
      sha: sha1(`${this.salt}\n${fullName}\n${JSON.stringify([...fileMap])}\n${repo.commits.length}`),
      files: fileMap,
      folders: new Map<string, string>(),
    };
    const folderPaths = new Set([""]);
    for (const path of fileMap.keys()) {
      const parts = path.split("/");
      for (let depth = 1; depth < parts.length; depth += 1) {
        folderPaths.add(parts.slice(0, depth).join("/"));
      }
    }
    // Deepest first, so a folder's SHA can take in its subfolders' SHAs.
    const depthOf = (folder: string) => (folder === "" ? 0 : folder.split("/").length);
    for (const folder of [...folderPaths].toSorted((a, b) => depthOf(b) - depthOf(a))) {
      const children = this.treeEntries(commit, folder, false).map(({ path, mode, sha }) => [
        path,
        mode,
        sha,
      ]);
      commit.folders.set(folder, sha1(`${this.salt}\ntree\n${JSON.stringify(children)}`));
    }
    repo.commits.push(commit);
    this.repos.set(fullName, repo);
  }

  /** A folder's entries as the trees API lists them, with paths relative to it. */
  private treeEntries(commit, folder: string, recursive: boolean) {
    const prefix = folder === "" ? "" : `${folder}/`;
    const entries = [];
    for (const [path, sha] of commit.folders) {
      if (path === "" || !path.startsWith(prefix)) continue;
      const relativePath = path.slice(prefix.length);
      if (recursive || !relativePath.includes("/")) {
        entries.push({ path: relativePath, mode: "040000", type: "tree", sha });
      }
    }
    for (const [path, file] of commit.files) {
      if (!path.startsWith(prefix)) continue;
      const relativePath = path.slice(prefix.length);
      if (recursive || !relativePath.includes("/")) {
        entries.push({
          path: relativePath,
          mode: file.executable ? "100755" : "100644",
          type: "blob",
          sha: sha1(file.content),
          size: Buffer.byteLength(file.content),
        });
      }
    }
    return entries.toSorted((a, b) => a.path.localeCompare(b.path));
  }

  /** The commit and folder a trees request names: a branch, a commit SHA or a folder SHA. */
  private findTree(repo, ref: string | undefined) {
    if (ref === undefined) return undefined;
    if (ref === repo.defaultBranch) return { commit: repo.commits.at(-1), folder: "" };
    for (const commit of repo.commits) {
      if (commit.sha === ref) return { commit, folder: "" };
      for (const [folder, sha] of commit.folders) {
        if (sha === ref) return { commit, folder };
      }
    }
    return undefined;
  }

  /** The SHA of a repository's newest commit. */
  shaOf(fullName: string): string {
    return this.repos.get(fullName).commits.at(-1).sha;
  }

  /** A file at the repository's newest commit. */
  file(fullName: string, path: string): RepoFile {
    const file = this.repos.get(fullName)?.commits.at(-1).files.get(path);
    if (!file) throw new Error(`stand-in has no ${fullName}:${path}`);
    return file;
  }

  readonly handle = async (input, init = {}) => {
    // fetch takes a URL string, a URL or a Request, with headers as a plain object or Headers.
    const isRequest = typeof Request !== "undefined" && input instanceof Request;
    const url = new URL(isRequest ? input.url : String(input));
    const [root, owner, name, ...rest] = url.pathname.split("/").filter(Boolean);
    const headers = new Headers(isRequest ? input.headers : undefined);
    new Headers(init.headers ?? {}).forEach((value, key) => headers.set(key, value));
    const accept = headers.get("accept") ?? "";
    let kind = "other";
    let path = "";
    let ref = url.searchParams.get("ref") ?? undefined;
    if (url.hostname === "raw.githubusercontent.com") {
      // A file's download_url: /<owner>/<repo>/<sha>/<path>
      const [rawOwner, rawName, rawRef, ...rawPath] = url.pathname.split("/").filter(Boolean);
      return this.track({
        repo: `${rawOwner}/${rawName}`,
        kind: "file",
        path: rawPath.map(decodeURIComponent).join("/"),
        ref: decodeURIComponent(rawRef),
      });
    }
    if (root === "repos" && rest.length === 0) {
      kind = "repo";
    } else if (root === "repos" && rest[0] === "commits") {
      kind = "commit";
      ref = decodeURIComponent(rest.slice(1).join("/"));
    } else if (root === "repos" && rest[0] === "contents") {
      kind = accept.includes("raw") ? "file" : "list";
      path = rest.slice(1).map(decodeURIComponent).join("/");
    } else if (root === "repos" && rest[0] === "git" && rest[1] === "trees") {
      kind = "tree";
      ref = decodeURIComponent(rest.slice(2).join("/"));
    }
    const recursive = kind === "tree" && url.searchParams.has("recursive");
    return this.track({ repo: `${owner}/${name}`, kind, path, ref, recursive });
  };

  private async track(request): Promise<Response> {
    const start = performance.now();
    this.inFlight += 1;
    this.maxInFlight = Math.max(this.maxInFlight, this.inFlight);
    let response: Response;
    try {
      await new Promise((resolve) => setTimeout(resolve, this.latency(request)));
      response = this.answer(request);
    } finally {
      this.inFlight -= 1;
    }
    this.requests.push({ ...request, start, end: performance.now(), status: response.status });
    return response;
  }

  private answer(request): Response {
    const repo = this.repos.get(request.repo);
    const tree = request.kind === "tree" && repo ? this.findTree(repo, request.ref) : undefined;
    if (tree) request.path = tree.folder;
    // A contents request for a file is a file read, whether it asks for raw text or JSON.
    if (request.kind === "list" && repo) {
      const listed =
        request.ref === undefined || request.ref === repo.defaultBranch
          ? repo.commits.at(-1)
          : repo.commits.find(({ sha }) => sha === request.ref);
      if (listed?.files.has(request.path)) {
        request.kind = "file";
        request.json = true;
      }
    }
    const failure = this.failure(request);
    if (failure) return jsonResponse(failure.status, { message: failure.message });
    if (!repo) return jsonResponse(404, { message: "Not Found" });
    if (request.kind === "tree") {
      if (!tree) return jsonResponse(404, { message: "Not Found" });
      return jsonResponse(200, {
        sha: tree.commit.folders.get(tree.folder),
        truncated: false,
        tree: this.treeEntries(tree.commit, tree.folder, request.recursive),
      });
    }
    if (request.kind === "repo") {
      return jsonResponse(200, {
        name: repo.name,
        full_name: request.repo,
        default_branch: repo.defaultBranch,
        private: false,
      });
    }
    // A branch name or no ref means the newest commit; a SHA means that commit.
    const commit =
      request.ref === undefined || request.ref === repo.defaultBranch
        ? repo.commits.at(-1)
        : repo.commits.find(({ sha }) => sha === request.ref);
    if (!commit) {
      return request.kind === "commit"
        ? jsonResponse(422, { message: `No commit found for SHA: ${request.ref}` })
        : jsonResponse(404, { message: "No commit found for the ref" });
    }
    switch (request.kind) {
      case "commit":
        return jsonResponse(200, { sha: commit.sha });
      case "file": {
        const file = commit.files.get(request.path);
        if (!file) return jsonResponse(404, { message: "Not Found" });
        if (request.json) {
          // A file asked for as JSON comes back with its content in base64, as on GitHub.
          return jsonResponse(200, {
            ...this.fileEntry(request, commit, request.path, file),
            encoding: "base64",
            content: Buffer.from(file.content).toString("base64"),
          });
        }
        return new Response(file.content, {
          status: 200,
          headers: { "content-type": "text/plain; charset=utf-8" },
        });
      }
      case "list": {
        const single = commit.files.get(request.path);
        if (single) return jsonResponse(200, this.fileEntry(request, commit, request.path, single));
        const prefix = request.path === "" ? "" : `${request.path}/`;
        const children = new Map();
        for (const [path, file] of commit.files) {
          if (!path.startsWith(prefix)) continue;
          const [first, ...deeper] = path.slice(prefix.length).split("/");
          if (deeper.length === 0) {
            children.set(first, this.fileEntry(request, commit, `${prefix}${first}`, file));
          } else if (!children.has(first)) {
            children.set(first, {
              name: first,
              path: `${prefix}${first}`,
              sha: commit.folders.get(`${prefix}${first}`),
              size: 0,
              type: "dir",
              download_url: null,
            });
          }
        }
        if (children.size === 0) return jsonResponse(404, { message: "Not Found" });
        return jsonResponse(
          200,
          [...children].toSorted(([a], [b]) => a.localeCompare(b)).map(([, entry]) => entry),
        );
      }
      default:
        return jsonResponse(404, { message: "Not Found" });
    }
  }

  private fileEntry(request, commit, path: string, file: RepoFile) {
    return {
      name: path.split("/").at(-1),
      path,
      sha: sha1(file.content),
      size: Buffer.byteLength(file.content),
      type: "file",
      download_url: `https://raw.githubusercontent.com/${request.repo}/${commit.sha}/${path}`,
    };
  }
}

// ---------------------------------------------------------------------------
// Running an install and reading what it left behind
// ---------------------------------------------------------------------------

let testDir: string;
let cleanup: () => Promise<void>;
let github: StandInGitHub;

beforeEach(async () => {
  ({ testDir, cleanup } = await setupTestDirectory());
  vi.spyOn(process, "cwd").mockReturnValue(testDir);
  // No token, as for most installs.
  vi.stubEnv("GITHUB_TOKEN", undefined);
  vi.stubEnv("GH_TOKEN", undefined);
  github = new StandInGitHub();
  network.handler = github.handle;
});

afterEach(async () => {
  await settle();
  network.handler = undefined;
  vi.unstubAllEnvs();
  vi.restoreAllMocks();
  await cleanup();
});

/** Wait until no request is open and none has started for a moment. */
async function settle(): Promise<void> {
  const deadline = performance.now() + 10_000;
  let seen = -1;
  while (performance.now() < deadline) {
    await new Promise((resolve) => setTimeout(resolve, 60));
    if (github.inFlight === 0 && github.requests.length === seen) return;
    seen = github.requests.length;
  }
}

async function readCurated(): Promise<Record<string, RepoFile & { executable: boolean }>> {
  const root = join(testDir, ".rulesync");
  const out = {};
  const walk = async (dir: string) => {
    let entries = [];
    try {
      entries = await readdir(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      const full = join(dir, entry.name);
      if (entry.isDirectory()) {
        await walk(full);
      } else {
        const relativePath = relative(root, full).split("\\").join("/");
        if (!relativePath.includes(".curated/")) continue;
        out[relativePath] = {
          content: await readFile(full, "utf8"),
          executable: ((await stat(full)).mode & 0o111) !== 0,
        };
      }
    }
  };
  await walk(root);
  return out;
}

/** rulesync.lock as data, with every resolvedAt timestamp masked; null when there is none. */
async function readLock() {
  let text: string;
  try {
    text = await readFile(join(testDir, "rulesync.lock"), "utf8");
  } catch {
    return null;
  }
  const mask = (value) => {
    if (Array.isArray(value)) return value.map(mask);
    if (value === null || typeof value !== "object") return value;
    return Object.fromEntries(
      Object.entries(value).map(([key, inner]) => [key, key === "resolvedAt" ? "<time>" : mask(inner)]),
    );
  };
  return mask(JSON.parse(text));
}

async function install(sources, options = {}) {
  const logger = createMockLogger();
  const firstRequest = github.requests.length;
  github.maxInFlight = 0;
  const started = performance.now();
  const result = await resolveAndFetchSources({ logger, sources, projectRoot: testDir, options });
  const elapsedMs = performance.now() - started;
  await settle();
  const requests = github.requests.slice(firstRequest);
  return {
    result,
    elapsedMs,
    requests,
    maxInFlight: github.maxInFlight,
    files: await readCurated(),
    lock: await readLock(),
    warnings: logger.warn.mock.calls.map(([message]) => String(message)),
    errors: logger.error.mock.calls.map(([message]) => String(message)),
    // Lines outside the errors that suggest using a token, however they're worded.
    tips: [...logger.info.mock.calls, ...logger.warn.mock.calls]
      .map(([message]) => String(message))
      .filter((message) => /\btoken\b|GITHUB_TOKEN|GH_TOKEN/i.test(message)),
  };
}

/**
 * How long a config takes to install when GitHub answers at once, measured in
 * a scratch project with its own stand-in. The timed cases add this to their
 * limit, so only the time spent waiting on GitHub has to halve.
 */
async function installTimeWithoutWaiting(addRepos: (stand: StandInGitHub) => void, sources) {
  const saved = { github, testDir };
  const scratch = await setupTestDirectory();
  try {
    github = new StandInGitHub();
    addRepos(github);
    network.handler = github.handle;
    testDir = scratch.testDir;
    vi.spyOn(process, "cwd").mockReturnValue(testDir);
    const observed = await install(sources);
    expectNoFailedSources(observed, "the same config with no waiting");
    return observed.elapsedMs;
  } finally {
    github = saved.github;
    testDir = saved.testDir;
    network.handler = github.handle;
    vi.spyOn(process, "cwd").mockReturnValue(testDir);
    await scratch.cleanup();
  }
}

/** The curated files expected on disk: curated path -> [repository, path in it]. */
function curatedCopies(copies: Record<string, [string, string]>) {
  return Object.fromEntries(
    Object.entries(copies).map(([curatedPath, [repo, path]]) => {
      const file = github.file(repo, path);
      return [curatedPath, { content: file.content, executable: file.executable === true }];
    }),
  );
}

const requestList = (requests) =>
  requests.map(({ kind, repo, path }) => `${kind} ${repo} ${path}`.trim()).toSorted();

function expectNoFailedSources(observed, label: string) {
  expect(
    observed.result.failedSourceCount,
    `${label}: failed sources (errors: ${observed.errors.join(" | ") || "none"})`,
  ).toBe(0);
}

/**
 * Compare rulesync.lock with the one install writes today, as data: the same
 * entries and values, and the sources in the same order. <sha:owner/repo> is
 * that repository's newest commit.
 */
function expectLockfile(observed, template: string, label: string) {
  const expected = JSON.parse(
    template.replace(/<sha:([^>]+)>/g, (_, repo) => github.shaOf(repo)),
  );
  expect(observed.lock, `${label}: rulesync.lock written`).not.toBeNull();
  const actual = observed.lock;
  expect(actual, `${label}: rulesync.lock`).toEqual(expected);
  expect(Object.keys(actual.sources ?? {}), `${label}: order of sources in rulesync.lock`).toEqual(
    Object.keys(expected.sources),
  );
}

/**
 * Each expected warning [name, source] appears once (a line naming both and
 * saying it was skipped as a duplicate), and no other duplicate is reported.
 * Other warnings are left alone.
 */
function expectDuplicateWarnings(observed, expected: Array<[string, string]>, label: string) {
  for (const [skillOrRule, source] of expected) {
    const lines = observed.warnings.filter(
      (line) => mentions(line, skillOrRule) && mentions(line, source) && /duplicate|already/i.test(line),
    );
    expect(lines, `${label}: warnings about "${skillOrRule}" from ${source}`).toHaveLength(1);
  }
  const duplicateLines = observed.warnings.filter((line) => /duplicate|already/i.test(line));
  expect(duplicateLines, `${label}: warnings about duplicates`).toHaveLength(expected.length);
}

/** Whether a log line names this source, skill or rule (not just a longer name starting with it). */
function mentions(line: string, name: string): boolean {
  const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return new RegExp(`(^|[^\\w./:-])${escaped}(?![\\w/-])`).test(line);
}

/** The error lines that name a source: exactly one per failing source, none for the others. */
function expectFailureReports(observed, failing: Record<string, RegExp>, healthy: string[], label: string) {
  for (const [source, reason] of Object.entries(failing)) {
    const lines = observed.errors.filter((line) => mentions(line, source));
    expect(lines, `${label}: error lines naming ${source}`).toHaveLength(1);
    expect(lines[0], `${label}: the reason given for ${source}`).toMatch(reason);
  }
  for (const source of healthy) {
    expect(
      observed.errors.filter((line) => mentions(line, source)),
      `${label}: error lines naming ${source}, which installs`,
    ).toEqual([]);
  }
}

function expectNoMoreRequestsThan(observed, todayCount: number, label: string) {
  expect(
    observed.requests.length,
    `${label}: GitHub requests sent (today: ${todayCount}): ${requestList(observed.requests).join(", ")}`,
  ).toBeLessThanOrEqual(todayCount);
}

const skillFile = (name: string, body = `# ${name}\n`) => ({ [`skills/${name}/SKILL.md`]: body });

/** Twelve repositories, each with one skill and one rule. */
function addDozenTeamRepos(stand: StandInGitHub) {
  for (let index = 0; index < 12; index += 1) {
    stand.addRepo(`team-${index}/assets`, {
      ...skillFile(`skill-${index}`),
      [`rules/rule-${index}.md`]: `rule ${index}\n`,
    });
  }
}

/** Waiting on GitHub has to halve; the time the install takes with no waiting is added on top. */
function expectFasterThanHalf(observed, todayWaitMs: number, noWaitMs: number) {
  const limitMs = todayWaitMs / 2 + noWaitMs;
  expect(
    observed.elapsedMs,
    `install time in ms (limit ${Math.round(limitMs)}: half of today's ${todayWaitMs} ms of waiting, plus ${Math.round(noWaitMs)} ms for the same install with no waiting)`,
  ).toBeLessThan(limitMs);
}

const OPEN_REQUEST_LIMIT = 10;

// A case can wait on many slow requests, so none relies on the runner's default timeout.
vi.setConfig({ testTimeout: 120_000 });

/** Three sources that each offer a skill and a rule named like the others'. */
function addThreeOverlappingSources() {
  github.addRepo("org/alpha", {
    ...skillFile("shared", "# shared from alpha\n"),
    "skills/shared/scripts/run.sh": { content: "#!/bin/sh\necho alpha\n", executable: true },
    ...skillFile("alpha-only"),
    "rules/shared-rule.md": "alpha shared rule\n",
    "rules/alpha-rule.md": "alpha rule\n",
  });
  github.addRepo("org/bravo", {
    ...skillFile("shared", "# shared from bravo\n"),
    ...skillFile("bravo-only"),
    "skills/bravo-only/references/notes.md": "bravo notes\n",
    "rules/shared-rule.md": "bravo shared rule\n",
    "rules/bravo-rule.md": "bravo rule\n",
  });
  github.addRepo("org/charlie", {
    ...skillFile("shared", "# shared from charlie\n"),
    ...skillFile("charlie-only"),
    "skills/charlie-only/nested/deep/file.md": "charlie deep\n",
    "rules/shared-rule.md": "charlie shared rule\n",
    "rules/charlie-rule.md": "charlie rule\n",
  });
  // alpha answers slowest and charlie fastest.
  const latency = { "org/alpha": 40, "org/bravo": 20, "org/charlie": 1 };
  github.latency = ({ repo }) => latency[repo];
}

const THREE_OVERLAPPING_SOURCES = [
  { source: "org/alpha", skills: ["*"], rules: ["*"] },
  { source: "org/bravo", skills: ["*"], rules: ["*"] },
  { source: "org/charlie", skills: ["*"], rules: ["*"] },
];

describe("rulesync install with many GitHub sources", () => {
  it("installs the same files, lockfile and duplicate warnings when later sources answer first", async () => {
    addThreeOverlappingSources();

    const observed = await install(THREE_OVERLAPPING_SOURCES);

    expect(observed.result, `install result (errors: ${observed.errors.join(" | ") || "none"})`).toEqual({
      fetchedSkillCount: 4,
      fetchedRuleCount: 4,
      sourcesProcessed: 3,
      failedSourceCount: 0,
    });
    expect(observed.files, "curated files on disk").toEqual(
      curatedCopies({
        "skills/.curated/shared/SKILL.md": ["org/alpha", "skills/shared/SKILL.md"],
        "skills/.curated/shared/scripts/run.sh": ["org/alpha", "skills/shared/scripts/run.sh"],
        "skills/.curated/alpha-only/SKILL.md": ["org/alpha", "skills/alpha-only/SKILL.md"],
        "skills/.curated/bravo-only/SKILL.md": ["org/bravo", "skills/bravo-only/SKILL.md"],
        "skills/.curated/bravo-only/references/notes.md": [
          "org/bravo",
          "skills/bravo-only/references/notes.md",
        ],
        "skills/.curated/charlie-only/SKILL.md": ["org/charlie", "skills/charlie-only/SKILL.md"],
        "skills/.curated/charlie-only/nested/deep/file.md": [
          "org/charlie",
          "skills/charlie-only/nested/deep/file.md",
        ],
        "rules/.curated/shared-rule.md": ["org/alpha", "rules/shared-rule.md"],
        "rules/.curated/alpha-rule.md": ["org/alpha", "rules/alpha-rule.md"],
        "rules/.curated/bravo-rule.md": ["org/bravo", "rules/bravo-rule.md"],
        "rules/.curated/charlie-rule.md": ["org/charlie", "rules/charlie-rule.md"],
      }),
    );
    expectLockfile(observed, LOCK_THREE_SOURCES, "three sources offering the same names");
    expectDuplicateWarnings(
      observed,
      [
        ["shared", "org/bravo"],
        ["shared-rule", "org/bravo"],
        ["shared", "org/charlie"],
        ["shared-rule", "org/charlie"],
      ],
      "three sources offering the same names",
    );
    expect(observed.errors, "errors").toEqual([]);
  });

  it("sends no more requests than today when several sources offer the same names", async () => {
    addThreeOverlappingSources();

    const observed = await install(THREE_OVERLAPPING_SOURCES);

    expectNoFailedSources(observed, "three sources offering the same names");
    expectNoMoreRequestsThan(observed, 34, "three sources offering the same names");
  });

  it("installs a dozen sources in less than half the time it takes today", async () => {
    const latencyMs = 100;
    const sources = Array.from({ length: 12 }, (_, index) => ({
      source: `team-${index}/assets`,
      skills: ["*"],
      rules: ["*"],
    }));
    const noWaitMs = await installTimeWithoutWaiting(addDozenTeamRepos, sources);
    addDozenTeamRepos(github);
    github.latency = () => latencyMs;

    const observed = await install(sources);

    expectNoFailedSources(observed, "a dozen one-skill sources");
    expect(Object.keys(observed.files).length, "curated files on disk").toBe(24);
    // Today this config takes 84 requests at 100 ms each, 8.4 s of waiting.
    expectFasterThanHalf(observed, 84 * latencyMs, noWaitMs);
    expectNoMoreRequestsThan(observed, 84, "a dozen one-skill sources");
  });

  it("never has more than ten GitHub requests open at once", async () => {
    for (let index = 0; index < 12; index += 1) {
      const files = {};
      for (const name of ["first", "second"]) {
        files[`skills/${name}-${index}/SKILL.md`] = `# ${name} ${index}\n`;
        for (let page = 0; page < 8; page += 1) {
          files[`skills/${name}-${index}/docs/page-${page}.md`] = `${name} ${index} page ${page}\n`;
          files[`skills/${name}-${index}/docs/more/extra-${page}.md`] =
            `${name} ${index} extra ${page}\n`;
        }
      }
      for (let rule = 0; rule < 4; rule += 1) {
        files[`rules/rule-${index}-${rule}.md`] = `rule ${index} ${rule}\n`;
      }
      github.addRepo(`org/many-${index}`, files);
    }
    let tick = 0;
    github.latency = () => 2 + ((tick += 7) % 9);

    const observed = await install(
      Array.from({ length: 12 }, (_, index) => ({
        source: `org/many-${index}`,
        skills: ["*"],
        rules: ["*"],
      })),
    );

    expect(observed.result, `install result (errors: ${observed.errors.join(" | ") || "none"})`).toEqual({
      fetchedSkillCount: 24,
      fetchedRuleCount: 48,
      sourcesProcessed: 12,
      failedSourceCount: 0,
    });
    expect(Object.keys(observed.files).length, "curated files on disk").toBe(456);
    expect(observed.maxInFlight, "most GitHub requests open at the same time").toBeLessThanOrEqual(
      OPEN_REQUEST_LIMIT,
    );
    expectNoMoreRequestsThan(observed, 588, "twelve sources with many files");
  });

  it("installs the same files and lockfile with no more requests than today when one source picks a few names and a later one offers the same names", async () => {
    const catalog = {};
    for (const name of ["one", "two", "three", "four", "five", "six"]) {
      Object.assign(catalog, skillFile(name), { [`skills/${name}/notes.md`]: `${name} notes\n` });
    }
    for (const name of ["r1", "r2", "r3", "r4"]) {
      catalog[`rules/${name}.md`] = `${name}\n`;
    }
    github.addRepo("org/catalog", catalog);
    github.addRepo("org/other", {
      ...skillFile("two", "# two from other\n"),
      ...skillFile("seven"),
      "rules/r3.md": "other r3\n",
    });

    const observed = await install([
      { source: "org/catalog", skills: ["two", "five"], rules: ["r3"] },
      { source: "org/other", skills: ["*"], rules: ["*"] },
    ]);

    expectNoFailedSources(observed, "a source selecting names, then one losing two");
    expect(observed.files, "curated files on disk").toEqual(
      curatedCopies({
        "skills/.curated/two/SKILL.md": ["org/catalog", "skills/two/SKILL.md"],
        "skills/.curated/two/notes.md": ["org/catalog", "skills/two/notes.md"],
        "skills/.curated/five/SKILL.md": ["org/catalog", "skills/five/SKILL.md"],
        "skills/.curated/five/notes.md": ["org/catalog", "skills/five/notes.md"],
        "skills/.curated/seven/SKILL.md": ["org/other", "skills/seven/SKILL.md"],
        "rules/.curated/r3.md": ["org/catalog", "rules/r3.md"],
      }),
    );
    expectLockfile(observed, LOCK_PICKED_NAMES, "a source selecting names, then one losing two");
    expectNoMoreRequestsThan(observed, 18, "a source selecting names, then one losing two");
  });

  it("installs the same files and lockfile with no more requests than today after a git source that takes names by list or by wildcard", async () => {
    const { resolveDefaultRef, fetchSkillFiles } = await import("./git-client.js");
    vi.mocked(resolveDefaultRef).mockResolvedValue({ ref: "main", sha: "a".repeat(40) });
    vi.mocked(fetchSkillFiles).mockImplementation(async ({ skillsPath }) =>
      skillsPath === "rules"
        ? [{ relativePath: "team-rule.md", content: "# team rule from git\n", size: 21 }]
        : [{ relativePath: "shared/SKILL.md", content: "# shared from git\n", size: 18 }],
    );
    github.addRepo("org/repo", {
      ...skillFile("shared", "# shared from github\n"),
      ...skillFile("github-only"),
      "rules/team-rule.md": "github team rule\n",
      "rules/github-rule.md": "github rule\n",
    });

    const byName = await install([
      {
        source: "https://example.com/team/assets.git",
        transport: "git",
        skills: ["shared"],
        rules: ["team-rule"],
      },
      { source: "org/repo", skills: ["*"], rules: ["*"] },
    ]);

    expectNoFailedSources(byName, "after a git source selecting names");
    expect(byName.files, "curated files on disk").toEqual({
      "skills/.curated/shared/SKILL.md": { content: "# shared from git\n", executable: false },
      "rules/.curated/team-rule.md": { content: "# team rule from git\n", executable: false },
      ...curatedCopies({
        "skills/.curated/github-only/SKILL.md": ["org/repo", "skills/github-only/SKILL.md"],
        "rules/.curated/github-rule.md": ["org/repo", "rules/github-rule.md"],
      }),
    });
    expectLockfile(byName, LOCK_GIT_BY_NAME, "after a git source selecting names");
    expectNoMoreRequestsThan(byName, 7, "after a git source selecting names");

    await rm(join(testDir, ".rulesync"), { recursive: true, force: true });
    await rm(join(testDir, "rulesync.lock"), { force: true });
    vi.mocked(fetchSkillFiles).mockResolvedValue([
      { relativePath: "shared/SKILL.md", content: "# shared from git\n", size: 18 },
    ]);

    const byWildcard = await install([
      { source: "https://example.com/team/skills.git", transport: "git" },
      { source: "org/repo" },
    ]);

    expectNoFailedSources(byWildcard, "after a git source taking every skill");
    expect(byWildcard.files, "curated files on disk").toEqual({
      "skills/.curated/shared/SKILL.md": { content: "# shared from git\n", executable: false },
      "skills/.curated/github-only/SKILL.md": { content: "# github-only\n", executable: false },
    });
    expectLockfile(byWildcard, LOCK_GIT_WILDCARD, "after a git source taking every skill");
    expectNoMoreRequestsThan(byWildcard, 5, "after a git source taking every skill");
  });

  it("installs the same files and lockfile when a GitHub source is declared before a git source offering the same names", async () => {
    const { resolveDefaultRef, fetchSkillFiles } = await import("./git-client.js");
    vi.mocked(resolveDefaultRef).mockResolvedValue({ ref: "main", sha: "c".repeat(40) });
    vi.mocked(fetchSkillFiles).mockImplementation(async ({ skillsPath }) =>
      skillsPath === "rules"
        ? [{ relativePath: "team-rule.md", content: "# team rule from git\n", size: 21 }]
        : [
            { relativePath: "shared/SKILL.md", content: "# shared from git\n", size: 18 },
            { relativePath: "git-only/SKILL.md", content: "# git only\n", size: 11 },
          ],
    );
    github.addRepo("org/first", {
      ...skillFile("shared", "# shared from github\n"),
      ...skillFile("github-only"),
      "rules/team-rule.md": "github team rule\n",
      "rules/github-rule.md": "github rule\n",
    });

    const observed = await install([
      { source: "org/first", skills: ["*"], rules: ["*"] },
      {
        source: "https://example.com/team/assets.git",
        transport: "git",
        skills: ["*"],
        rules: ["team-rule"],
      },
    ]);

    expectNoFailedSources(observed, "a GitHub source before a git source");
    expect(observed.files, "curated files on disk").toEqual({
      ...curatedCopies({
        "skills/.curated/shared/SKILL.md": ["org/first", "skills/shared/SKILL.md"],
        "skills/.curated/github-only/SKILL.md": ["org/first", "skills/github-only/SKILL.md"],
        "rules/.curated/team-rule.md": ["org/first", "rules/team-rule.md"],
        "rules/.curated/github-rule.md": ["org/first", "rules/github-rule.md"],
      }),
      "skills/.curated/git-only/SKILL.md": { content: "# git only\n", executable: false },
    });
    expectDuplicateWarnings(
      observed,
      [
        ["shared", "https://example.com/team/assets.git"],
        ["team-rule", "https://example.com/team/assets.git"],
      ],
      "a GitHub source before a git source",
    );
    expectLockfile(observed, LOCK_GITHUB_THEN_GIT, "a GitHub source before a git source");
    expectNoMoreRequestsThan(observed, 10, "a GitHub source before a git source");
  });

  it("sends no requests when the same config is installed again with nothing changed", async () => {
    github.addRepo("org/alpha", { ...skillFile("a1"), ...skillFile("a2"), "rules/ra.md": "ra\n" });
    github.addRepo("org/bravo", { ...skillFile("b1"), "rules/rb.md": "rb\n" });
    github.addRepo("org/charlie", { ...skillFile("c1") });
    const sources = [
      { source: "org/alpha", skills: ["*"], rules: ["*"] },
      { source: "org/bravo", skills: ["*"], rules: ["*"] },
      { source: "org/charlie" },
    ];

    const first = await install(sources);
    expectNoMoreRequestsThan(first, 21, "first install");
    const second = await install(sources);

    expectNoFailedSources(second, "repeat install");
    expect(second.files, "curated files after the repeat install").toEqual(first.files);
    expect(second.lock, "rulesync.lock after the repeat install").toEqual(first.lock);
    expectNoMoreRequestsThan(second, 0, "repeat install");
  });

  it("sends no more requests than today for --update, --frozen into an empty checkout, and rules-only sources", async () => {
    github.addRepo("org/alpha", { ...skillFile("a1"), "rules/ra.md": "ra\n" });
    github.addRepo("org/bravo", { ...skillFile("b1") });
    github.addRepo("org/rules-only", { "rules/style.md": "style\n", "rules/tests.md": "tests\n" });
    const sources = [
      { source: "org/alpha", skills: ["*"], rules: ["*"] },
      { source: "org/bravo" },
      { source: "org/rules-only", rules: ["style"] },
    ];

    const first = await install(sources);
    expectNoFailedSources(first, "first install");
    expectNoMoreRequestsThan(first, 16, "first install");

    github.addRepo("org/bravo", { ...skillFile("b1"), ...skillFile("b2") });
    const update = await install(sources, { updateSources: true });
    expectNoFailedSources(update, "--update");
    expect(
      update.files["skills/.curated/b2/SKILL.md"]?.content,
      "--update: the skill added by the new commit",
    ).toBe("# b2\n");
    expectNoMoreRequestsThan(update, 18, "--update");

    const lockBefore = update.lock;
    await rm(join(testDir, ".rulesync"), { recursive: true, force: true });
    const frozen = await install(sources, { frozen: true });
    expectNoFailedSources(frozen, "--frozen into an empty checkout");
    expect(frozen.files, "curated files after --frozen").toEqual(update.files);
    expect(frozen.lock, "rulesync.lock after --frozen").toEqual(lockBefore);
    expectNoMoreRequestsThan(frozen, 12, "--frozen into an empty checkout");
  });

  it("installs the same files and lockfile with no more requests than today with a local skill and rule, a root-level skill, a pinned ref and a path", async () => {
    // Install takes a project's own skills from <project>/skills
    // (getLocalSkillDirNames(projectRoot) in sources.ts) and its own rules from
    // .rulesync/rules.
    await mkdir(join(testDir, "skills", "mine"), { recursive: true });
    await writeFile(join(testDir, "skills", "mine", "SKILL.md"), "# my own\n");
    await mkdir(join(testDir, ".rulesync", "rules"), { recursive: true });
    await writeFile(join(testDir, ".rulesync", "rules", "house.md"), "house rule\n");
    github.addRepo("org/alpha", {
      ...skillFile("mine", "# mine from alpha\n"),
      ...skillFile("theirs"),
      "rules/house.md": "remote house\n",
      "rules/extra.md": "extra\n",
    });
    github.addRepo("org/flat", {
      "kit/SKILL.md": "# kit\n",
      "kit/helper.sh": { content: "#!/bin/sh\necho kit\n", executable: true },
      "kit/README.md": "kit readme\n",
    });
    github.addRepo(
      "org/packs",
      { "packs/x/SKILL.md": "# x\n", "packs/y/SKILL.md": "# y\n" },
      "trunk",
    );
    github.addRepo("org/later", {
      ...skillFile("kit-skill", "# kit from later\n"),
      ...skillFile("x", "# x from later\n"),
      ...skillFile("mine", "# mine from later\n"),
      ...skillFile("later-only"),
    });

    const observed = await install([
      { source: "org/alpha", skills: ["*"], rules: ["*"] },
      { source: "org/flat", path: "kit", skills: ["kit-skill"] },
      { source: "org/packs", path: "packs", ref: "trunk" },
      { source: "https://github.com/org/later" },
    ]);

    expectNoFailedSources(observed, "local skill and rule, root-level skill, ref and path");
    expect(observed.files, "curated files on disk").toEqual(
      curatedCopies({
        "skills/.curated/theirs/SKILL.md": ["org/alpha", "skills/theirs/SKILL.md"],
        "rules/.curated/extra.md": ["org/alpha", "rules/extra.md"],
        "skills/.curated/kit-skill/SKILL.md": ["org/flat", "kit/SKILL.md"],
        "skills/.curated/kit-skill/helper.sh": ["org/flat", "kit/helper.sh"],
        "skills/.curated/kit-skill/README.md": ["org/flat", "kit/README.md"],
        "skills/.curated/x/SKILL.md": ["org/packs", "packs/x/SKILL.md"],
        "skills/.curated/y/SKILL.md": ["org/packs", "packs/y/SKILL.md"],
        "skills/.curated/later-only/SKILL.md": ["org/later", "skills/later-only/SKILL.md"],
      }),
    );
    expect(
      await readFile(join(testDir, "skills", "mine", "SKILL.md"), "utf8"),
      "the project's own skill",
    ).toBe("# my own\n");
    expectLockfile(observed, LOCK_MIXED, "local skill and rule, root-level skill, ref and path");
    expectNoMoreRequestsThan(observed, 25, "local skill and rule, root-level skill, ref and path");
  });

  it("reports a refused download once with its hint and still installs the other sources", async () => {
    github.addRepo("org/alpha", { ...skillFile("a1") });
    github.addRepo("org/bravo", { ...skillFile("b1") });
    github.addRepo("org/charlie", { ...skillFile("c1") });
    github.failure = ({ repo, kind }) =>
      repo === "org/bravo" && kind === "file"
        ? { status: 403, message: "Resource not accessible" }
        : undefined;

    const observed = await install([
      { source: "org/alpha" },
      { source: "org/bravo" },
      { source: "org/charlie" },
    ]);

    expect(observed.result, `install result (errors: ${observed.errors.join(" | ") || "none"})`).toEqual({
      fetchedSkillCount: 2,
      fetchedRuleCount: 0,
      sourcesProcessed: 3,
      failedSourceCount: 1,
    });
    expectFailureReports(
      observed,
      { "org/bravo": /forbidden|403|not accessible|denied|permission/i },
      ["org/alpha", "org/charlie"],
      "a refused download",
    );
    // The refusal comes with the hint to use a token, given once.
    expect(observed.tips.length, "lines that suggest a token").toBeGreaterThan(0);
    expect(new Set(observed.tips).size, `token hints, each given once: ${observed.tips.join(" | ")}`).toBe(
      observed.tips.length,
    );
    expect(observed.files, "curated files on disk").toEqual(
      curatedCopies({
        "skills/.curated/a1/SKILL.md": ["org/alpha", "skills/a1/SKILL.md"],
        "skills/.curated/c1/SKILL.md": ["org/charlie", "skills/c1/SKILL.md"],
      }),
    );
  });

  it("reports a GitLab source as unsupported and still installs the GitHub source after it", async () => {
    github.addRepo("org/repo", { ...skillFile("shared") });

    const observed = await install([{ source: "gitlab:org/repo" }, { source: "org/repo" }]);

    expect(observed.result.failedSourceCount, `failed sources (errors: ${observed.errors.join(" | ")})`).toBe(1);
    expectFailureReports(
      observed,
      { "gitlab:org/repo": /gitlab.*support|support.*gitlab/i },
      ["org/repo"],
      "a GitLab source",
    );
    expect(observed.files, "curated files on disk").toEqual(
      curatedCopies({ "skills/.curated/shared/SKILL.md": ["org/repo", "skills/shared/SKILL.md"] }),
    );
  });

  it("reports every source once and stays within ten open requests when a listing fails in each", async () => {
    for (let index = 0; index < 12; index += 1) {
      github.addRepo(`org/repo-${index}`, {
        ...skillFile(`bad-${index}`),
        ...skillFile(`good-${index}`),
      });
    }
    // Every read under the bad skill fails, however it is reached.
    github.failure = ({ kind, path }) =>
      (kind === "list" || kind === "file" || kind === "tree") && path.startsWith("skills/bad-")
        ? { status: 500, message: "Server Error" }
        : undefined;
    github.latency = ({ path }) => (path.startsWith("skills/good-") ? 15 : 3);

    const observed = await install(
      Array.from({ length: 12 }, (_, index) => ({ source: `org/repo-${index}` })),
    );

    expect(observed.result.failedSourceCount, `failed sources (errors: ${observed.errors.join(" | ")})`).toBe(12);
    expectFailureReports(
      observed,
      Object.fromEntries(
        Array.from({ length: 12 }, (_, index) => [`org/repo-${index}`, /server error|500/i]),
      ),
      [],
      "a failed read in every source",
    );
    expect(observed.files, "curated files on disk").toEqual({});
    expect(observed.maxInFlight, "most GitHub requests open at the same time").toBeLessThanOrEqual(
      OPEN_REQUEST_LIMIT,
    );
  });

  it("installs the same files and lockfile with no more requests than today when git sources sit before and after two GitHub sources offering the same names", async () => {
    const { resolveDefaultRef, fetchSkillFiles } = await import("./git-client.js");
    vi.mocked(resolveDefaultRef).mockImplementation(async (url) => ({
      ref: "main",
      sha: url.includes("assets") ? "d".repeat(40) : "e".repeat(40),
    }));
    vi.mocked(fetchSkillFiles).mockImplementation(async ({ url, skillsPath }) => {
      if (url.includes("assets")) {
        return skillsPath === "rules"
          ? [{ relativePath: "team-rule.md", content: "# team rule from git\n", size: 21 }]
          : [{ relativePath: "shared/SKILL.md", content: "# shared from git\n", size: 18 }];
      }
      return [
        { relativePath: "late/SKILL.md", content: "# late from git\n", size: 16 },
        { relativePath: "git-only/SKILL.md", content: "# git only\n", size: 11 },
      ];
    });
    for (const name of ["first", "second"]) {
      github.addRepo(`org/${name}`, {
        ...skillFile("shared", `# shared from ${name}\n`),
        ...skillFile(`${name}-only`),
        "rules/team-rule.md": `${name} team rule\n`,
        [`rules/${name}-rule.md`]: `${name} rule\n`,
        ...(name === "second" ? skillFile("late", "# late from second\n") : {}),
      });
    }

    const observed = await install([
      {
        source: "https://example.com/team/assets.git",
        transport: "git",
        skills: ["shared"],
        rules: ["team-rule"],
      },
      { source: "org/first", skills: ["*"], rules: ["*"] },
      { source: "org/second", skills: ["*"], rules: ["*"] },
      { source: "https://example.com/team/extra.git", transport: "git" },
    ]);

    expectNoFailedSources(observed, "git sources around two GitHub sources");
    expect(observed.files, "curated files on disk").toEqual({
      "skills/.curated/shared/SKILL.md": { content: "# shared from git\n", executable: false },
      "rules/.curated/team-rule.md": { content: "# team rule from git\n", executable: false },
      "skills/.curated/git-only/SKILL.md": { content: "# git only\n", executable: false },
      ...curatedCopies({
        "skills/.curated/first-only/SKILL.md": ["org/first", "skills/first-only/SKILL.md"],
        "rules/.curated/first-rule.md": ["org/first", "rules/first-rule.md"],
        "skills/.curated/second-only/SKILL.md": ["org/second", "skills/second-only/SKILL.md"],
        "skills/.curated/late/SKILL.md": ["org/second", "skills/late/SKILL.md"],
        "rules/.curated/second-rule.md": ["org/second", "rules/second-rule.md"],
      }),
    });
    expectDuplicateWarnings(
      observed,
      [
        ["shared", "org/first"],
        ["team-rule", "org/first"],
        ["shared", "org/second"],
        ["team-rule", "org/second"],
        ["late", "https://example.com/team/extra.git"],
      ],
      "git sources around two GitHub sources",
    );
    expectLockfile(observed, LOCK_GIT_AROUND_GITHUB, "git sources around two GitHub sources");
    expectNoMoreRequestsThan(observed, 16, "git sources around two GitHub sources");
  });

  it("installs a dozen GitHub sources mixed with git sources in less than half the time it takes today", async () => {
    const { resolveDefaultRef, fetchSkillFiles } = await import("./git-client.js");
    vi.mocked(resolveDefaultRef).mockResolvedValue({ ref: "main", sha: "f".repeat(40) });
    vi.mocked(fetchSkillFiles).mockImplementation(async ({ url, skillsPath }) => {
      if (url.includes("first")) {
        return skillsPath === "rules"
          ? [{ relativePath: "rule-5.md", content: "rule 5 from git\n", size: 16 }]
          : [
              { relativePath: "skill-3/SKILL.md", content: "# skill 3 from git\n", size: 19 },
              { relativePath: "git-a/SKILL.md", content: "# git a\n", size: 8 },
            ];
      }
      return [{ relativePath: "git-b/SKILL.md", content: "# git b\n", size: 8 }];
    });
    const latencyMs = 100;
    const github12 = Array.from({ length: 12 }, (_, index) => ({
      source: `team-${index}/assets`,
      skills: ["*"],
      rules: ["*"],
    }));
    const sources = [
      {
        source: "https://example.com/team/first.git",
        transport: "git",
        skills: ["skill-3", "git-a"],
        rules: ["rule-5"],
      },
      ...github12.slice(0, 6),
      { source: "https://example.com/team/middle.git", transport: "git", skills: ["git-b"] },
      ...github12.slice(6),
    ];
    const noWaitMs = await installTimeWithoutWaiting(addDozenTeamRepos, sources);
    addDozenTeamRepos(github);
    github.latency = () => latencyMs;

    const observed = await install(sources);

    expectNoFailedSources(observed, "a dozen GitHub sources and two git sources");
    expect(Object.keys(observed.files).length, "curated files on disk").toBe(26);
    expect(observed.files["skills/.curated/skill-3/SKILL.md"]?.content).toBe("# skill 3 from git\n");
    expect(observed.files["rules/.curated/rule-5.md"]?.content).toBe("rule 5 from git\n");
    // Today this config takes 81 GitHub requests at 100 ms each, 8.1 s of waiting.
    expectFasterThanHalf(observed, 81 * latencyMs, noWaitMs);
    expectNoMoreRequestsThan(observed, 81, "a dozen GitHub sources and two git sources");
  });
});

// rulesync.lock as install writes it today for each config, with resolvedAt masked.
// <sha:owner/repo> stands for that repository's newest commit in the case.

const LOCK_THREE_SOURCES = `{
  "lockfileVersion": 1,
  "sources": {
    "org/alpha": {
      "requestedRef": "main",
      "resolvedRef": "<sha:org/alpha>",
      "resolvedAt": "<time>",
      "skills": {
        "alpha-only": {
          "integrity": "sha256-4ad6d55daf3fea514a8948d7ffe2556d6931c64c1a2d624f2eeb9fe00a73d49a"
        },
        "shared": {
          "integrity": "sha256-f543d839cfe1fc2a302b2e9732a29293b572d316dc5694cebe4454b8a8b9c0f5"
        }
      },
      "skillSelection": [
        "*"
      ],
      "skillsPath": "skills",
      "rules": {
        "alpha-rule": {
          "integrity": "sha256-a3a7077f610549a5d081102406f1a87f5219af1ad7e6c3512d9ae829eaddfd79"
        },
        "shared-rule": {
          "integrity": "sha256-367f37b2f3ecb36919b7836e94836d47eaae6d2de6362415ea6d46df5f44b017"
        }
      },
      "ruleSelection": [
        "*"
      ],
      "rulesPath": "rules",
      "resolvedRuleNames": [
        "alpha-rule",
        "shared-rule"
      ]
    },
    "org/bravo": {
      "requestedRef": "main",
      "resolvedRef": "<sha:org/bravo>",
      "resolvedAt": "<time>",
      "skills": {
        "bravo-only": {
          "integrity": "sha256-9d8cc9908eeaac8c8f1007b293b315a44865bb2652eb8c258805473cc1c0bcc7"
        }
      },
      "skillSelection": [
        "*"
      ],
      "skillsPath": "skills",
      "rules": {
        "bravo-rule": {
          "integrity": "sha256-a8e5ef386c84ad1f529f9d356366965324e79cf6a2f965e480818cddc9379aa9"
        }
      },
      "ruleSelection": [
        "*"
      ],
      "rulesPath": "rules",
      "resolvedRuleNames": [
        "bravo-rule",
        "shared-rule"
      ]
    },
    "org/charlie": {
      "requestedRef": "main",
      "resolvedRef": "<sha:org/charlie>",
      "resolvedAt": "<time>",
      "skills": {
        "charlie-only": {
          "integrity": "sha256-b2b1c814cfce85caeb0b44286c656fc36d94e1da84d59e62c8cc92ac2997afd9"
        }
      },
      "skillSelection": [
        "*"
      ],
      "skillsPath": "skills",
      "rules": {
        "charlie-rule": {
          "integrity": "sha256-50fcd97ffb596129aa20e685011153912ecf18f985b0f8b108c45e6b158c6f62"
        }
      },
      "ruleSelection": [
        "*"
      ],
      "rulesPath": "rules",
      "resolvedRuleNames": [
        "charlie-rule",
        "shared-rule"
      ]
    }
  }
}
`;

const LOCK_PICKED_NAMES = `{
  "lockfileVersion": 1,
  "sources": {
    "org/catalog": {
      "requestedRef": "main",
      "resolvedRef": "<sha:org/catalog>",
      "resolvedAt": "<time>",
      "skills": {
        "five": {
          "integrity": "sha256-edd2345c81bb3fa22ac6f858e191ce5bec13c13b46e42f0bda3268203d33f59b"
        },
        "two": {
          "integrity": "sha256-41540c8ebd79ec82c31d7aefcb9ed78fd9c060dbd91cd7f9dfbbf77b3ad6d0c4"
        }
      },
      "skillSelection": [
        "five",
        "two"
      ],
      "skillsPath": "skills",
      "rules": {
        "r3": {
          "integrity": "sha256-09d2a941dca1835faf706e706a83452109b31abd2fb5bf3cee74f57b1bbc6406"
        }
      },
      "ruleSelection": [
        "r3"
      ],
      "rulesPath": "rules",
      "resolvedRuleNames": [
        "r3"
      ]
    },
    "org/other": {
      "requestedRef": "main",
      "resolvedRef": "<sha:org/other>",
      "resolvedAt": "<time>",
      "skills": {
        "seven": {
          "integrity": "sha256-b095fde43a68417a5cca219cbc151b6b8f2eb5e9aea6fb587b094374ab92377b"
        }
      },
      "skillSelection": [
        "*"
      ],
      "skillsPath": "skills",
      "rules": {},
      "ruleSelection": [
        "*"
      ],
      "rulesPath": "rules",
      "resolvedRuleNames": [
        "r3"
      ]
    }
  }
}
`;

const LOCK_GIT_BY_NAME = `{
  "lockfileVersion": 1,
  "sources": {
    "https://example.com/team/assets": {
      "requestedRef": "main",
      "resolvedRef": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
      "resolvedAt": "<time>",
      "skills": {
        "shared": {
          "integrity": "sha256-007ccff9a269ee703075d4fbfb7f93151bd9f8878ae7c969b861c32032370769"
        }
      },
      "skillSelection": [
        "shared"
      ],
      "skillsPath": "skills",
      "rules": {
        "team-rule": {
          "integrity": "sha256-bf7833edce1870240abc8c849d98d4dbeeb77c59c325ef17b34e522e56966f8e"
        }
      },
      "ruleSelection": [
        "team-rule"
      ],
      "rulesPath": "rules",
      "resolvedRuleNames": [
        "team-rule"
      ]
    },
    "org/repo": {
      "requestedRef": "main",
      "resolvedRef": "<sha:org/repo>",
      "resolvedAt": "<time>",
      "skills": {
        "github-only": {
          "integrity": "sha256-d2902e7867db9856be351032bd9401b0daca5947b9da7eeccaac2105a56179f1"
        }
      },
      "skillSelection": [
        "*"
      ],
      "skillsPath": "skills",
      "rules": {
        "github-rule": {
          "integrity": "sha256-a21464697618be49b3da895b18586e61a1b310b422e9aef659a999c7c16a50fc"
        }
      },
      "ruleSelection": [
        "*"
      ],
      "rulesPath": "rules",
      "resolvedRuleNames": [
        "github-rule",
        "team-rule"
      ]
    }
  }
}
`;

const LOCK_GIT_WILDCARD = `{
  "lockfileVersion": 1,
  "sources": {
    "https://example.com/team/skills": {
      "requestedRef": "main",
      "resolvedRef": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
      "resolvedAt": "<time>",
      "skills": {
        "shared": {
          "integrity": "sha256-007ccff9a269ee703075d4fbfb7f93151bd9f8878ae7c969b861c32032370769"
        }
      },
      "skillSelection": [
        "*"
      ],
      "skillsPath": "skills"
    },
    "org/repo": {
      "requestedRef": "main",
      "resolvedRef": "<sha:org/repo>",
      "resolvedAt": "<time>",
      "skills": {
        "github-only": {
          "integrity": "sha256-d2902e7867db9856be351032bd9401b0daca5947b9da7eeccaac2105a56179f1"
        }
      },
      "skillSelection": [
        "*"
      ],
      "skillsPath": "skills"
    }
  }
}
`;

const LOCK_GITHUB_THEN_GIT = `{
  "lockfileVersion": 1,
  "sources": {
    "org/first": {
      "requestedRef": "main",
      "resolvedRef": "<sha:org/first>",
      "resolvedAt": "<time>",
      "skills": {
        "github-only": {
          "integrity": "sha256-d2902e7867db9856be351032bd9401b0daca5947b9da7eeccaac2105a56179f1"
        },
        "shared": {
          "integrity": "sha256-fbe4900997536a6c7bffa85d44193d4d8488127db5f6c21a3b77dd60cec9a5a5"
        }
      },
      "skillSelection": [
        "*"
      ],
      "skillsPath": "skills",
      "rules": {
        "github-rule": {
          "integrity": "sha256-a21464697618be49b3da895b18586e61a1b310b422e9aef659a999c7c16a50fc"
        },
        "team-rule": {
          "integrity": "sha256-b2719925b4fbaf292e8b44c533c00958985c0b6e04375f3f71f4d8e8cff39667"
        }
      },
      "ruleSelection": [
        "*"
      ],
      "rulesPath": "rules",
      "resolvedRuleNames": [
        "github-rule",
        "team-rule"
      ]
    },
    "https://example.com/team/assets": {
      "requestedRef": "main",
      "resolvedRef": "cccccccccccccccccccccccccccccccccccccccc",
      "resolvedAt": "<time>",
      "skills": {
        "git-only": {
          "integrity": "sha256-67765897aaa71b86025d83a00e6f5a45386e117ea2ef6f4725e63458ca67b34f"
        }
      },
      "skillSelection": [
        "*"
      ],
      "skillsPath": "skills",
      "rules": {},
      "ruleSelection": [
        "team-rule"
      ],
      "rulesPath": "rules",
      "resolvedRuleNames": [
        "team-rule"
      ]
    }
  }
}
`;

const LOCK_MIXED = `{
  "lockfileVersion": 1,
  "sources": {
    "org/alpha": {
      "requestedRef": "main",
      "resolvedRef": "<sha:org/alpha>",
      "resolvedAt": "<time>",
      "skills": {
        "theirs": {
          "integrity": "sha256-3b8dfbfbe0784471f38e7a9ccf79edbcfdcb486f13f2cb03f75260d49a4213f9"
        }
      },
      "skillSelection": [
        "*"
      ],
      "skillsPath": "skills",
      "rules": {
        "extra": {
          "integrity": "sha256-65110ea3b8b62b0c09742c368bf1527f0978b06dff7a1371ef7b4c98e244d91a"
        }
      },
      "ruleSelection": [
        "*"
      ],
      "rulesPath": "rules",
      "resolvedRuleNames": [
        "extra",
        "house"
      ]
    },
    "org/flat": {
      "requestedRef": "main",
      "resolvedRef": "<sha:org/flat>",
      "resolvedAt": "<time>",
      "skills": {
        "kit-skill": {
          "integrity": "sha256-f39433ede19c389ad8f17ef2e32ff6319003c6b8d67bd46e92367217b4acec78"
        }
      },
      "skillSelection": [
        "kit-skill"
      ],
      "skillsPath": "kit"
    },
    "org/packs": {
      "requestedRef": "trunk",
      "resolvedRef": "<sha:org/packs>",
      "resolvedAt": "<time>",
      "skills": {
        "x": {
          "integrity": "sha256-0d022cafe798b002f6e36006899ae0418a209846c8e81ef478775b99ddc75eef"
        },
        "y": {
          "integrity": "sha256-d13e4540103209c4e6f202745b54ba14a350616f04af69f50c6f874479915281"
        }
      },
      "skillSelection": [
        "*"
      ],
      "skillsPath": "packs"
    },
    "org/later": {
      "requestedRef": "main",
      "resolvedRef": "<sha:org/later>",
      "resolvedAt": "<time>",
      "skills": {
        "later-only": {
          "integrity": "sha256-777cd80c66da3a8ec3eb5bde0943b36ddce911c4221067b2d34e23992c623b92"
        }
      },
      "skillSelection": [
        "*"
      ],
      "skillsPath": "skills"
    }
  }
}
`;

const LOCK_GIT_AROUND_GITHUB = `{
  "lockfileVersion": 1,
  "sources": {
    "https://example.com/team/assets": {
      "requestedRef": "main",
      "resolvedRef": "dddddddddddddddddddddddddddddddddddddddd",
      "resolvedAt": "<time>",
      "skills": {
        "shared": {
          "integrity": "sha256-007ccff9a269ee703075d4fbfb7f93151bd9f8878ae7c969b861c32032370769"
        }
      },
      "skillSelection": [
        "shared"
      ],
      "skillsPath": "skills",
      "rules": {
        "team-rule": {
          "integrity": "sha256-bf7833edce1870240abc8c849d98d4dbeeb77c59c325ef17b34e522e56966f8e"
        }
      },
      "ruleSelection": [
        "team-rule"
      ],
      "rulesPath": "rules",
      "resolvedRuleNames": [
        "team-rule"
      ]
    },
    "org/first": {
      "requestedRef": "main",
      "resolvedRef": "<sha:org/first>",
      "resolvedAt": "<time>",
      "skills": {
        "first-only": {
          "integrity": "sha256-e22312c053c9eeb04ae0494a01019f41cfa20158bf7a1d6131360b280cbf4a50"
        }
      },
      "skillSelection": [
        "*"
      ],
      "skillsPath": "skills",
      "rules": {
        "first-rule": {
          "integrity": "sha256-82fa764f228ab9b6ed6f6aa97d52b1ccd4dc1036617ad71d11953d6b5b620286"
        }
      },
      "ruleSelection": [
        "*"
      ],
      "rulesPath": "rules",
      "resolvedRuleNames": [
        "first-rule",
        "team-rule"
      ]
    },
    "org/second": {
      "requestedRef": "main",
      "resolvedRef": "<sha:org/second>",
      "resolvedAt": "<time>",
      "skills": {
        "late": {
          "integrity": "sha256-93b00339621009ce6c54d855ab7912b688856f29c24d4019be03e9546e0fd479"
        },
        "second-only": {
          "integrity": "sha256-f1c11039672c5fd996ba902b208b908ded70e0264d4151ee9d7926e65fafe91c"
        }
      },
      "skillSelection": [
        "*"
      ],
      "skillsPath": "skills",
      "rules": {
        "second-rule": {
          "integrity": "sha256-5c63be7ef407bd2e83ac402b2068c07877b9a39131a021cf49a83a98b4c0dd2d"
        }
      },
      "ruleSelection": [
        "*"
      ],
      "rulesPath": "rules",
      "resolvedRuleNames": [
        "second-rule",
        "team-rule"
      ]
    },
    "https://example.com/team/extra": {
      "requestedRef": "main",
      "resolvedRef": "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
      "resolvedAt": "<time>",
      "skills": {
        "git-only": {
          "integrity": "sha256-67765897aaa71b86025d83a00e6f5a45386e117ea2ef6f4725e63458ca67b34f"
        }
      },
      "skillSelection": [
        "*"
      ],
      "skillsPath": "skills"
    }
  }
}
`;
