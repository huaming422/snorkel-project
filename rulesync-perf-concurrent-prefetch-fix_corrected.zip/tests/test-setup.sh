#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
# Brings the baked pnpm dependency closure online and makes node_modules/.bin
# available for vitest. No assertion logic here.
cd /repo/rulesync

# Fail fast on a cache miss instead of reaching for a registry.
export npm_config_offline=true

node --version
pnpm --version

# Dependencies: offline-first against the image bake, logged online fallback.
if pnpm install --offline --frozen-lockfile --ignore-scripts > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] deps satisfied from image"
elif pnpm install --frozen-lockfile --ignore-scripts >> /tmp/test-setup-install.log 2>&1; then
    echo "[test-setup] deps installed online (image bake was stale)"
else
    tail -60 /tmp/test-setup-install.log >&2
    exit 1
fi

# Make pnpm bin and node_modules/.bin available to vitest.
export PATH="/repo/rulesync/node_modules/.bin:$PATH"

echo "[test-setup] ready: /repo/rulesync (node=$(node --version), pnpm=$(pnpm --version))"
