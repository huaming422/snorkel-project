## Task

`rulesync install` is slow for configs that pull from many GitHub repositories. One of ours lists a dozen and takes about a minute, nearly all of it spent waiting on GitHub. Some of these configs also mix in a few plain git sources. With a dozen GitHub sources, install should take less than half as long as it does now.

Apart from taking less time, an install should behave exactly as it does today. Most of us run it without a GitHub token, so it also can't burn extra API quota or hammer GitHub.
