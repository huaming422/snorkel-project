#!/usr/bin/env bash
# Environment bootstrap for the verifier. Sourced (not exec'd) so env vars
# stay alive for cargo. Idempotent. The image already carries the full
# dependency closure (cargo registry warm in /opt/cargo, workspace compiled
# in /opt/cache/cargo-target at the base commit), so this script performs NO
# network installs — the verifier's extra integration-test binary builds
# against already-vendored crates.

set -e

REPO_DIR="${REPO_DIR:-/repo/specta}"
cd "$REPO_DIR"

echo "[test-setup] rustc: $(rustc --version)"
echo "[test-setup] cargo: $(cargo --version)"

# Confirm the dependency closure is present offline. This is a no-op against the
# warm registry cache baked into the image; it never reaches the network.
# Offline-first with a logged online fallback (network is up in the verifier
# phase, but the warm cache means the fallback should never fire).
if ! cargo fetch --offline >/dev/null 2>&1; then
    echo "[test-setup] WARNING: offline cargo fetch missed the warm cache; falling back to online fetch" >&2
    cargo fetch
fi

echo "[test-setup] dependency closure present; ready for cargo test."
