//! Compiles and runs the public API regression fixture in the pinned crate.
//! The outer test reports fixture compilation errors under a stable test name.

use std::{fs, process::Command};

const FIXTURE: &str = r####"
//! Exercises bounded derives through public type definitions and exported datatypes.
#![allow(dead_code)]
#![allow(clippy::multiple_bound_locations)]

use specta::Type;
use specta::datatype::{DataType, Fields, Generic, NamedReferenceType, Reference};
use std::collections::HashMap;

pub trait Trait {}
pub trait Trait2 {}

// A separate trait with the same name as specta's Type trait.
pub mod other {
    pub trait Type {}
}

// The bounded wrapper at the heart of the reproduction.
#[derive(Type)]
#[specta(collect = false)]
pub struct Wrapper<T: Trait>(T);

// The minimal reproduction from the issue: a bounded wrapper used as a field in
// a struct carrying the same bound.
#[derive(Type)]
#[specta(collect = false)]
pub struct A<T: Trait> {
    a: Wrapper<T>,
}

// Nested bounded wrapper behind a built-in collection.
#[derive(Type)]
#[specta(collect = false)]
pub struct Nested<T: Trait> {
    list: Vec<Wrapper<T>>,
}

// Direct uses of the bounded parameter through standard field types.
#[derive(Type)]
#[specta(collect = false)]
pub struct DirectFields<'a, T: Trait> {
    items: Vec<T>,
    borrowed: &'a T,
    optional: Option<T>,
    array: [T; 2],
    pair: (T, T),
    slice: &'a [T],
}

// `where` clause form of the same bound.
#[derive(Type)]
#[specta(collect = false)]
pub struct WhereBound<T>
where
    T: Trait,
{
    a: Wrapper<T>,
}

// A bounded parameter behind a reference, with a lifetime alongside it.
#[derive(Type)]
#[specta(collect = false)]
pub struct WithLifetime<'a, T: Trait> {
    a: &'a Wrapper<T>,
}

// Const parameter alongside a bounded parameter.
#[derive(Type)]
#[specta(collect = false)]
pub struct WithConst<const N: usize, T: Trait> {
    a: Wrapper<T>,
    b: [u8; N],
}

// Repeated/recursive use of the same generic definition.
#[derive(Type)]
#[specta(collect = false)]
pub struct Recursive<T: Trait> {
    a: Wrapper<T>,
    children: Vec<Recursive<T>>,
}

// Two distinct bounded parameters instantiated with two DISTINCT concrete types
// must keep distinct generic placeholders in the produced definition.
#[derive(Type)]
#[specta(collect = false)]
pub struct GenericMap<K: Trait, V: Trait> {
    map: HashMap<K, V>,
}

// --- lifetime bounds on generic parameters ---
// Lifetime predicates that coexist with generic parameters.
#[derive(Type)]
#[specta(collect = false)]
pub struct LifetimeOutlives<'a, T>
where
    'a: 'static,
{
    a: &'a T,
}

#[derive(Type)]
#[specta(collect = false)]
pub struct ParamOutlivesLifetime<'a, T>
where
    T: 'a,
{
    a: &'a T,
}

#[derive(Type)]
#[specta(collect = false)]
pub struct InlineLifetimeBound<'a, T: 'a> {
    a: &'a T,
}

#[derive(Type)]
#[specta(collect = false)]
pub struct LifetimeAndTraitBound<'a, T: Trait + 'a> {
    a: &'a Wrapper<T>,
}

// A `where` predicate with both lifetime and trait bounds.
#[derive(Type)]
#[specta(collect = false)]
pub struct MixedWhere<'a, T>
where
    T: 'a + Trait,
{
    a: &'a Wrapper<T>,
}

#[derive(Type)]
#[specta(collect = false)]
pub struct MixedWhereTwo<'a, T>
where
    T: 'a + Trait + Trait2,
{
    a: &'a Wrapper<T>,
}

// --- `#[specta(bound = "...")]` combined with a field requiring that bound ---
#[derive(Type)]
#[specta(collect = false)]
pub struct Wrapper2<T: Trait, U>(T, U);

#[derive(Type)]
#[specta(bound = "T: Trait + Type", collect = false)]
pub struct CustomBoundNested<T: Trait> {
    a: Wrapper2<T, T>,
}

// --- a `macro!`-typed field mentioning a generic parameter ---
macro_rules! ty_of {
    ($t:ty) => {
        $t
    };
}

#[derive(Type)]
#[specta(collect = false)]
pub struct MacroTypedField<T> {
    a: ty_of!(T),
}

// --- a user trait literally named `Type` as the parameter bound ---
#[derive(Type)]
#[specta(collect = false)]
pub struct Wrapper3<T: other::Type>(T);

#[derive(Type)]
#[specta(collect = false)]
pub struct UsesWrapper3<T: other::Type> {
    a: Wrapper3<T>,
}

// Concrete type that satisfies every user trait above.
#[derive(Type)]
#[specta(collect = false)]
pub struct Impl;

impl Trait for Impl {}
impl Trait2 for Impl {}
impl other::Type for Impl {}

// A second distinct concrete type, for multi-parameter distinctness.
#[derive(Type)]
#[specta(collect = false)]
pub struct OtherImpl;

impl Trait for OtherImpl {}

// --- datatype inspection helpers ---

fn field_ty<'a>(ty: &'a DataType, name: &str) -> &'a DataType {
    let DataType::Struct(s) = ty else {
        panic!("expected struct, got {ty:?}");
    };
    let Fields::Named(named) = &s.fields else {
        panic!("expected named fields, got {s:?}");
    };
    named
        .fields
        .iter()
        .find(|(field, _)| field == name)
        .and_then(|(_, field)| field.ty.as_ref())
        .unwrap_or_else(|| panic!("missing field {name:?}"))
}

fn generic_name(ty: &DataType) -> Option<&Generic> {
    match ty {
        DataType::Generic(generic) => Some(generic),
        _ => None,
    }
}

fn named_generics(ty: &DataType) -> Option<&Vec<(Generic, DataType)>> {
    let DataType::Reference(Reference::Named(reference)) = ty else {
        return None;
    };
    let NamedReferenceType::Reference { generics, .. } = &reference.inner else {
        return None;
    };
    Some(generics)
}

/// Passthrough containers like `Vec`/`HashMap` are wrapped in an inline
/// reference; unwrap it to inspect the underlying datatype.
fn unwrap_inline(ty: &DataType) -> &DataType {
    if let DataType::Reference(Reference::Named(reference)) = ty
        && let NamedReferenceType::Inline { dt, .. } = &reference.inner
    {
        return dt;
    }
    ty
}

fn find_exported<'a>(types: &'a specta::Types, name: &str) -> &'a DataType {
    types
        .into_sorted_iter()
        .find(|ndt| ndt.name == name)
        .and_then(|ndt| ndt.ty.as_ref())
        .unwrap_or_else(|| panic!("{name} not exported"))
}

fn contains_generic(ty: &DataType) -> bool {
    match ty {
        DataType::Generic(_) => true,
        DataType::List(list) => contains_generic(&list.ty),
        DataType::Map(map) => contains_generic(map.key_ty()) || contains_generic(map.value_ty()),
        DataType::Nullable(inner) => contains_generic(inner),
        DataType::Tuple(tuple) => tuple.elements.iter().any(contains_generic),
        DataType::Intersection(types) => types.iter().any(contains_generic),
        DataType::Struct(s) => match &s.fields {
            Fields::Unit => false,
            Fields::Unnamed(unnamed) => unnamed
                .fields
                .iter()
                .filter_map(|f| f.ty.as_ref())
                .any(contains_generic),
            Fields::Named(named) => named
                .fields
                .iter()
                .filter_map(|(_, f)| f.ty.as_ref())
                .any(contains_generic),
        },
        DataType::Enum(e) => e.variants.iter().any(|(_, variant)| match &variant.fields {
            Fields::Unit => false,
            Fields::Unnamed(unnamed) => unnamed
                .fields
                .iter()
                .filter_map(|f| f.ty.as_ref())
                .any(contains_generic),
            Fields::Named(named) => named
                .fields
                .iter()
                .filter_map(|(_, f)| f.ty.as_ref())
                .any(contains_generic),
        }),
        DataType::Reference(Reference::Named(reference)) => match &reference.inner {
            NamedReferenceType::Inline { dt, .. } => contains_generic(dt),
            NamedReferenceType::Reference { generics, .. } => {
                generics.iter().any(|(_, ty)| contains_generic(ty))
            }
            NamedReferenceType::Recursive(_) => false,
        },
        DataType::Primitive(_) | DataType::Reference(Reference::Opaque(_)) => false,
    }
}

fn contains_generic_named(ty: &DataType, name: &str) -> bool {
    match ty {
        DataType::Generic(generic) => generic.name().as_ref() == name,
        DataType::List(list) => contains_generic_named(&list.ty, name),
        DataType::Map(map) => contains_generic_named(map.key_ty(), name) || contains_generic_named(map.value_ty(), name),
        DataType::Nullable(inner) => contains_generic_named(inner, name),
        DataType::Tuple(tuple) => tuple.elements.iter().any(|ty| contains_generic_named(ty, name)),
        DataType::Intersection(types) => types.iter().any(|ty| contains_generic_named(ty, name)),
        DataType::Struct(s) => match &s.fields {
            Fields::Unit => false,
            Fields::Unnamed(fields) => fields.fields.iter().filter_map(|f| f.ty.as_ref()).any(|ty| contains_generic_named(ty, name)),
            Fields::Named(fields) => fields.fields.iter().filter_map(|(_, f)| f.ty.as_ref()).any(|ty| contains_generic_named(ty, name)),
        },
        DataType::Enum(e) => e.variants.iter().any(|(_, variant)| match &variant.fields {
            Fields::Unit => false,
            Fields::Unnamed(fields) => fields.fields.iter().filter_map(|f| f.ty.as_ref()).any(|ty| contains_generic_named(ty, name)),
            Fields::Named(fields) => fields.fields.iter().filter_map(|(_, f)| f.ty.as_ref()).any(|ty| contains_generic_named(ty, name)),
        }),
        DataType::Reference(Reference::Named(reference)) => match &reference.inner {
            NamedReferenceType::Inline { dt, .. } => contains_generic_named(dt, name),
            NamedReferenceType::Reference { generics, .. } => generics.iter().any(|(_, ty)| contains_generic_named(ty, name)),
            NamedReferenceType::Recursive(_) => false,
        },
        DataType::Primitive(_) | DataType::Reference(Reference::Opaque(_)) => false,
    }
}

// The bounded forms must derive and resolve their definitions.
#[test]
fn minimal_repro_and_related_shapes_compile() {
    // Minimal reproduction.
    let mut types = specta::Types::default();
    let _ = A::<Impl>::definition(&mut types);

    // `where`-clause form.
    let mut types = specta::Types::default();
    let _ = WhereBound::<Impl>::definition(&mut types);

    // Reference + lifetime alongside, const alongside.
    let mut types = specta::Types::default();
    let _ = WithLifetime::<'_, Impl>::definition(&mut types);
    let _ = WithConst::<4, Impl>::definition(&mut types);

    // Lifetime-bound predicates, including `where 'a: 'static`.
    let mut types = specta::Types::default();
    let _ = LifetimeOutlives::<'_, Impl>::definition(&mut types);
    let _ = ParamOutlivesLifetime::<'_, Impl>::definition(&mut types);
    let _ = InlineLifetimeBound::<'_, Impl>::definition(&mut types);
    let _ = LifetimeAndTraitBound::<'_, Impl>::definition(&mut types);

    // `where` predicates with lifetime and trait bounds.
    let mut types = specta::Types::default();
    let _ = MixedWhere::<'_, Impl>::definition(&mut types);
    let _ = MixedWhereTwo::<'_, Impl>::definition(&mut types);

    // `#[specta(bound = "...")]` override combined with a bounded field.
    let mut types = specta::Types::default();
    let _ = CustomBoundNested::<Impl>::definition(&mut types);

    // A user trait named `Type` as the bound.
    let mut types = specta::Types::default();
    let _ = UsesWrapper3::<Impl>::definition(&mut types);
}

// --- bounded-parameter field stays generic ---
#[test]
fn bounded_field_declaration_stays_generic() {
    let mut types = specta::Types::default();
    let concrete = A::<Impl>::definition(&mut types);

    // The exported declaration must describe the field generically: `a`
    // references `Wrapper` with a single generic argument named `T`, not the
    // concrete `Impl`.
    let a = find_exported(&types, "A");
    let field = field_ty(a, "a");
    let generics = named_generics(field).expect("`a` should reference Wrapper");
    assert_eq!(generics.len(), 1, "expected exactly one generic argument");
    assert_eq!(
        generic_name(&generics[0].1).map(Generic::name),
        Some(&"T".into()),
        "bounded field argument was baked to a concrete type instead of staying generic"
    );

    // `Wrapper` itself is still registered as a named export.
    let wrapper = types
        .into_sorted_iter()
        .find(|ndt| ndt.name == "Wrapper")
        .expect("Wrapper declaration should be registered");
    assert!(wrapper.ty.is_some());

    // The concrete instantiation returned by `definition` is fully resolved.
    assert!(
        !contains_generic(&concrete),
        "concrete instantiation leaked a Generic node: {concrete:?}"
    );
}

#[test]
fn bounded_variations_keep_exported_parameter_generic() {
    macro_rules! check {
        ($ty:ty, $export:literal) => {{
            let mut types = specta::Types::default();
            let _ = <$ty>::definition(&mut types);
            let field = field_ty(find_exported(&types, $export), "a");
            assert!(contains_generic_named(field, "T"), "{} field lost T: {field:?}", $export);
        }};
    }
    check!(WhereBound<Impl>, "WhereBound");
    check!(WithLifetime<'_, Impl>, "WithLifetime");
    check!(WithConst<4, Impl>, "WithConst");
    check!(LifetimeAndTraitBound<'_, Impl>, "LifetimeAndTraitBound");
    check!(MixedWhere<'_, Impl>, "MixedWhere");
    check!(MixedWhereTwo<'_, Impl>, "MixedWhereTwo");
    check!(CustomBoundNested<Impl>, "CustomBoundNested");
    check!(UsesWrapper3<Impl>, "UsesWrapper3");
}

#[test]
fn direct_container_fields_keep_exported_parameter_generic() {
    let mut types = specta::Types::default();
    let concrete = DirectFields::<'_, Impl>::definition(&mut types);
    let declaration = find_exported(&types, "DirectFields");
    for name in ["items", "borrowed", "optional", "array", "pair", "slice"] {
        let field = field_ty(declaration, name);
        assert!(contains_generic_named(field, "T"), "{name} lost T: {field:?}");
    }
    assert!(!contains_generic(&concrete), "concrete definition contains a generic: {concrete:?}");
}

// --- nested collection element stays generic ---
#[test]
fn nested_collection_element_is_generic() {
    let mut types = specta::Types::default();
    let _ = Nested::<Impl>::definition(&mut types);

    let nested = find_exported(&types, "Nested");
    let list = unwrap_inline(field_ty(nested, "list"));
    let DataType::List(list) = list else {
        panic!("expected list, got {list:?}");
    };
    // The element `Wrapper<T>` keeps `T` generic.
    let generics = named_generics(&list.ty).expect("`list` element should reference Wrapper");
    assert_eq!(generics.len(), 1);
    assert_eq!(
        generic_name(&generics[0].1).map(Generic::name),
        Some(&"T".into()),
        "collection element baked a concrete type instead of staying generic"
    );
}

// --- recursive and multi-parameter declarations ---
#[test]
fn recursive_and_multi_parameter_definitions_stay_generic() {
    // Recursive<T>: the `children: Vec<Recursive<T>>` element bottoms out in a
    // reference back to Recursive carrying generic argument `T`.
    let mut types = specta::Types::default();
    let _ = Recursive::<Impl>::definition(&mut types);
    let recursive = find_exported(&types, "Recursive");
    let children = unwrap_inline(field_ty(recursive, "children"));
    let DataType::List(list) = children else {
        panic!("expected list, got {children:?}");
    };
    let generics = named_generics(&list.ty).expect("`children` should reference Recursive");
    assert_eq!(generics.len(), 1);
    assert_eq!(
        generic_name(&generics[0].1).map(Generic::name),
        Some(&"T".into())
    );

    // GenericMap<K, V> instantiated with two DISTINCT concrete types keeps K and
    // V as distinct placeholders in the produced definition.
    let mut types = specta::Types::default();
    let _ = GenericMap::<Impl, OtherImpl>::definition(&mut types);
    let map = find_exported(&types, "GenericMap");
    let field = unwrap_inline(field_ty(map, "map"));
    let DataType::Map(map_ty) = field else {
        panic!("expected map, got {field:?}");
    };
    assert_eq!(
        generic_name(map_ty.key_ty()).map(|g| g.name().to_string()),
        Some("K".to_string())
    );
    assert_eq!(
        generic_name(map_ty.value_ty()).map(|g| g.name().to_string()),
        Some("V".to_string())
    );
}

// --- extra coverage: an opaque macro-typed field must not bake a concrete type ---
#[test]
fn macro_typed_field_is_not_baked() {
    let mut types = specta::Types::default();
    let _ = MacroTypedField::<Impl>::definition(&mut types);

    let ty = find_exported(&types, "MacroTypedField");
    assert!(
        matches!(field_ty(ty, "a"), DataType::Generic(_)),
        "a `macro!`-typed field baked the first instantiation's concrete type: {:?}",
        field_ty(ty, "a")
    );
}

"####;

#[test]
fn bounded_generic_contract() {
    let manifest = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("Cargo.toml");
    let fixture = manifest.parent().expect("crate directory").join("tests/verify_bound_contract_inner.rs");
    let target = std::env::temp_dir().join(format!("specta_bound_target_{}", std::process::id()));
    fs::write(&fixture, FIXTURE).expect("write fixture tests");
    let output = Command::new("cargo")
        .args(["test", "--offline", "--manifest-path"])
        .arg(&manifest)
        .args(["--features", "derive", "--test", "verify_bound_contract_inner", "--", "--test-threads=1"])
        .env("CARGO_TARGET_DIR", &target)
        .output()
        .expect("run fixture cargo test");
    let stdout = String::from_utf8_lossy(&output.stdout);
    let stderr = String::from_utf8_lossy(&output.stderr);
    fs::remove_file(&fixture).expect("remove fixture test");
    let _ = fs::remove_dir_all(&target);
    assert!(output.status.success(), "fixture failed:\n{stdout}\n{stderr}");
}
