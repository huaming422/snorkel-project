## Task

I'm seeing `#[derive(Type)]` fail on a generic struct whose field is another type with the same trait bound. The compiler says the parameter lacks the bound, even though the enclosing struct declares it. For example, put a bounded wrapper inside a second struct with that bound: both derives fail, while removing the bounds lets them compile.

Please fix the bounded case. When a caller instantiates it with a concrete type, the exported declaration should still describe its type parameter generically, and the concrete definition should resolve. The same generic behavior should hold across ordinary ways of writing the bound and field type, including a reference or collection field and a lifetime alongside the parameter. The related bounded examples with a const parameter, combined lifetime and trait bounds, `#[specta(bound = "...")]`, and a user trait named `Type` should work too. Repeated and recursive uses should retain the parameter's identity; two different bounded parameters instantiated with different concrete types should remain distinct.

Two known cases can wait: different bounded parameters instantiated with the *same* concrete type may collapse to one generic in the output, and a field type requiring its type parameter to outlive `'static` is unsupported. A lifetime predicate such as `where 'a: 'static` is a separate case.

The environment is offline; use the repository and dependencies already available here.
