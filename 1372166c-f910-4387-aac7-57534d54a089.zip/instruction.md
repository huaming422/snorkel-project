## Task

`#[derive(Type)]` currently rejects a bounded generic struct when a field uses that parameter in another type with the same trait requirement. The compiler reports that the parameter does not meet the trait bound, although the enclosing struct declares it. A small reproduction is a bounded wrapper used as a field of a second, similarly bounded struct; removing the bounds lets both derives compile.

The derive should compile for this bounded shape. Exported type definitions should expose their declared generic parameters while definitions requested for concrete instantiations still resolve. The same behavior should hold across ordinary variations in how the bound and field type are written, including references, collections, and lifetimes. Existing forms with a const parameter, combined lifetime and trait bounds, an explicit `#[specta(bound = "...")]`, or a user trait named `Type` must keep working. Repeated or recursive uses of a generic type and distinct bounded parameters instantiated with distinct concrete types must retain their separate generic identities.

The two documented edge cases remain outside this repair.

Work within the available repository and vendored dependencies in this offline environment.
