## Task

I can derive `Type` for a bounded wrapper, but deriving it for a struct that holds that wrapper fails. The compiler reports that the type parameter does not meet the wrapper's trait bound, although the outer struct declares that bound. If I remove the bounds, the same arrangement compiles.

Please repair this bounded derive case. A concrete instantiation needs to resolve, while its exported declaration still describes the parameter as generic. I also need this to work when the bound is in a `where` clause, when the parameter occurs directly or through a wrapper in a reference or collection, and when a lifetime appears beside it. The fix should also handle a const parameter, combined lifetime and trait bounds, `#[specta(bound = "...")]`, and a user trait named `Type`. If a definition uses its parameter more than once or refers to itself, the exported uses should still refer to that parameter. Two bounded parameters instantiated with different concrete types should keep their separate identities.

There are two existing limits to leave for later: separate bounded parameters given the same concrete type can appear as one generic in the output; a field type that requires its type parameter to outlive `'static` is unsupported. The latter does not cover a lifetime predicate such as `where 'a: 'static`.

This environment has no network access, so please work with the code and dependencies already present.
