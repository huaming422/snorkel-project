// Behavioral checks for linear `+` string accumulation in the Jint interpreter.
//
// Every check drives JavaScript source through the pre-existing public API
// (`new Engine()`, `engine.Evaluate(...)`, `Engine.PrepareScript(...)`,
// `JsValue.AsString()/.AsNumber()/.AsBoolean()/.ToString()`) and the public
// BCL allocation counter `GC.GetAllocatedBytesForCurrentThread()`. Nothing here
// names any internal string representation, threshold constant, method, or file
// the fix introduces: the two properties asserted are (1) that building a string
// with `+` in a loop grows total allocation in step with the input rather than
// with its square, and (2) that the produced string is byte-for-byte the flat
// string for every way a script can observe it. Any valid interpreter-internal
// design that keeps those two properties passes.
//
// Parallelism is disabled so the per-thread allocation counter reads only the
// work of the method under test.

using System;
using System.Linq;
using Jint;
using Xunit;

namespace StringConcatVerify;

// The allocation measurements read a per-thread counter, so the whole suite is
// pinned to a single non-parallel collection: methods run one at a time and no
// sibling test's work lands between a before/after reading.
[CollectionDefinition("string-concat-serial", DisableParallelization = true)]
public class StringConcatSerialCollection { }

[Collection("string-concat-serial")]
public class StringConcatenationLinearityTests
{
    // Matches the fixture the upstream scenarios build on: a fixed 10-character
    // piece appended repeatedly.
    private const string ChunkSetup = "var chunk = '0123456789';";

    private static Engine NewEngine()
    {
        var engine = new Engine();
        engine.Execute(ChunkSetup);
        return engine;
    }

    // ---- Allocation growth (linear, not quadratic) ------------------------
    //
    // Measures allocated bytes around a loop that accumulates with `+`, at two
    // iteration counts one doubling apart. Linear building roughly doubles the
    // allocation across the doubling (ratio ~2) and stays in the low hundreds of
    // KB; copying the whole accumulator every iteration quadruples it (ratio ~4)
    // and reaches hundreds of MB at 8000 pieces. The two bounds below sit far
    // from both outcomes: the 16 MB ceiling is ~40x under the quadratic shape's
    // footprint at this size, and the 3.0 ratio is comfortably clear of 2 (pass)
    // and 4 (fail), so neither assertion is fragile to allocation noise.

    private static long AllocatedBytesAccumulating(string body, int iterations)
    {
        var engine = NewEngine();
        var script = Engine.PrepareScript(
            $"(function (n) {{ var s = ''; for (var i = 0; i < n; i++) {{ {body}; }} return s.length; }})(n)");

        // Warm the handler tree and call-site caches so the measurement covers
        // the loop and not the one-off cost of first reaching it.
        engine.SetValue("n", 16);
        engine.Evaluate(script);

        engine.SetValue("n", iterations);
        GC.Collect();
        var before = GC.GetAllocatedBytesForCurrentThread();
        engine.Evaluate(script);
        var after = GC.GetAllocatedBytesForCurrentThread();

        return after - before;
    }

    private static void AssertLinearGrowth(string body)
    {
        var small = AllocatedBytesAccumulating(body, 4_000);
        var large = AllocatedBytesAccumulating(body, 8_000);

        Assert.True(
            large < 16L * 1024 * 1024,
            $"accumulating with `{body}` allocated {large} bytes at 8000 iterations; " +
            "a value that grows with the input stays far below 16 MB here");
        Assert.True(
            (double) large / small < 3.0,
            $"accumulating with `{body}` allocated {large} bytes at 8000 vs {small} at 4000 " +
            $"(ratio {(double) large / small:F2}); linear growth is ~2x across a doubling, quadratic ~4x");
    }

    [Fact]
    public void AppendAccumulationScalesLinearly()
    {
        AssertLinearGrowth("s = s + chunk");
    }

    [Fact]
    public void PrependAccumulationScalesLinearly()
    {
        AssertLinearGrowth("s = chunk + s");
    }

    [Fact]
    public void ChainAccumulationScalesLinearly()
    {
        // `s = s + chunk + chunk` is evaluated as one flattened multi-operand
        // concatenation, a separate path from the two-operand `+`. A change that
        // makes only the two-operand form cheap leaves this quadratic.
        AssertLinearGrowth("s = s + chunk + chunk");
    }

    // ---- Byte-for-byte correctness of an accumulated string ---------------

    [Theory]
    [InlineData("s.length", "2000")]
    [InlineData("s.charCodeAt(0)", "48")]
    [InlineData("s.charCodeAt(1999)", "57")]
    [InlineData("s.charAt(11)", "1")]
    [InlineData("s[12]", "2")]
    [InlineData("s.indexOf('789012')", "7")]
    [InlineData("s.lastIndexOf('0123')", "1990")]
    [InlineData("s.slice(5, 15)", "5678901234")]
    [InlineData("s.substring(0, 4)", "0123")]
    [InlineData("s.startsWith('01234')", "true")]
    [InlineData("s.endsWith('56789')", "true")]
    [InlineData("s.includes('456')", "true")]
    [InlineData("s.split('0').length", "201")]
    [InlineData("s.toUpperCase().length", "2000")]
    [InlineData("JSON.stringify(s).length", "2002")]
    [InlineData("(s === s + '')", "true")]
    [InlineData("`${s}`.length", "2000")]
    [InlineData("(+s.slice(0, 3))", "12")]
    [InlineData("s.replace('012', 'zzz').slice(0, 5)", "zzz34")]
    [InlineData("[...s].length", "2000")]
    [InlineData("s.match(/9(0)/)[1]", "0")]
    [InlineData("(s == s.valueOf())", "true")]
    public void EveryStringOperationSeesTheFlatValue(string expression, string expected)
    {
        var engine = NewEngine();
        engine.Execute("var s = ''; for (var i = 0; i < 200; i++) { s = s + chunk; }");

        Assert.Equal(expected, engine.Evaluate(expression).ToString());
    }

    [Fact]
    public void SharedOperandDoublingFlattensToTheWholeValue()
    {
        // `s = s + s` references the same value twice, so the result is a shared
        // structure rather than a tree; it must flatten to the whole doubled
        // value, not one copy per distinct node.
        var engine = NewEngine();
        var value = engine.Evaluate("var s = chunk; for (var i = 0; i < 8; i++) { s = s + s; } s;").AsString();

        Assert.Equal(string.Concat(Enumerable.Repeat("0123456789", 256)), value);
    }

    [Theory]
    [InlineData("'a' + 'b'", "ab")]
    [InlineData("'a' + 'b' + 'c'", "abc")]
    public void ShortConcatenationsStayCorrect(string expression, string expected)
    {
        Assert.Equal(expected, NewEngine().Evaluate(expression).AsString());
    }

    // ---- Operand order --------------------------------------------------

    [Fact]
    public void AppendAndPrependPreserveOperandOrder()
    {
        // The piece changes every iteration, so a swapped operand shows up as a
        // reordered result even though the length is unchanged.
        var engine = NewEngine();

        var appended = engine
            .Evaluate("(function () { var s = ''; for (var i = 0; i < 400; i++) { s = s + ('[' + i + ']'); } return s; })()")
            .AsString();
        var prepended = engine
            .Evaluate("(function () { var s = ''; for (var i = 0; i < 400; i++) { s = ('[' + i + ']') + s; } return s; })()")
            .AsString();

        var pieces = Enumerable.Range(0, 400).Select(i => "[" + i + "]").ToArray();
        Assert.Equal(string.Concat(pieces), appended);
        Assert.Equal(string.Concat(Enumerable.Reverse(pieces)), prepended);
    }

    // ---- Immutability against later mutation of an operand ---------------

    [Fact]
    public void ResultIsUnaffectedByLaterMutationOfOperand()
    {
        // `a[0]` is a still-growable accumulator; `b` is a `+` result built from
        // it. A later append to `a[0]` must not change `b`. A representation that
        // aliased the growable buffer instead of snapshotting it would fail.
        var engine = NewEngine();
        engine.Execute("var a = ['']; a[0] += chunk.repeat(60); a[0] += chunk.repeat(60);");
        engine.Execute("var b = a[0] + '!';");
        engine.Execute("a[0] += 'MUTATED';");

        Assert.Equal(1201, engine.Evaluate("b.length").AsNumber());
        Assert.Equal(-1, engine.Evaluate("b.indexOf('MUTATED')").AsNumber());
        Assert.True(engine.Evaluate("b === chunk.repeat(120) + '!'").AsBoolean());
        Assert.Equal(1207, engine.Evaluate("a[0].length").AsNumber());
    }

    // ---- Content-based equality / hashing as a collection key ------------

    [Fact]
    public void AccumulatedStringWorksAsACollectionKey()
    {
        // `deferred` is built with `+`, `flat` with `+=` and then forced to a
        // distinct flat representation. The two hold identical characters, so
        // they must be interchangeable as Map/Set/object keys — which only holds
        // if the accumulated value hashes and compares by content.
        var engine = NewEngine();
        engine.Execute(
            "var deferred = ''; for (var i = 0; i < 60; i++) { deferred = deferred + chunk; }" +
            "var flat = ''; for (var i = 0; i < 60; i++) { flat += chunk; }" +
            "flat = flat.slice(0);");

        Assert.Equal(1, engine.Evaluate("new Map([[deferred, 1]]).get(flat)").AsNumber());
        Assert.Equal(1, engine.Evaluate("new Map([[flat, 1]]).get(deferred)").AsNumber());
        Assert.True(engine.Evaluate("new Set([deferred]).has(flat)").AsBoolean());
        Assert.Equal(1, engine.Evaluate("new Set([deferred, flat]).size").AsNumber());
        Assert.Equal(7, engine.Evaluate("var o = {}; o[deferred] = 7; o[flat]").AsNumber());
        Assert.Equal(600, engine.Evaluate("Object.keys(o)[0].length").AsNumber());
    }

    // ---- Deep accumulation does not overflow the stack -------------------

    [Theory]
    [InlineData("s = s + 'ab'")]
    [InlineData("s = 'ab' + s")]
    public void DeepAccumulationStaysRobust(string body)
    {
        // Hundreds of thousands of `+` operations build a very deep, unbalanced
        // structure; reading its characters must not place a stack frame per
        // node. Both leanings are covered (append leans one way, prepend the
        // other). A representation whose flatten recurses overflows here.
        var engine = NewEngine();
        engine.Execute($"var s = ''; for (var i = 0; i < 200000; i++) {{ {body}; }}");

        Assert.Equal(400000, engine.Evaluate("s.length").AsNumber());
        Assert.Equal('a', engine.Evaluate("s.charCodeAt(0)").AsNumber());
        Assert.Equal('b', engine.Evaluate("s.charCodeAt(399999)").AsNumber());
        Assert.True(engine.Evaluate("s === 'ab'.repeat(200000)").AsBoolean());
    }

    // ---- Maximum string length limit still enforced ----------------------

    [Fact]
    public void MaximumStringLengthLimitStillRaisesRangeError()
    {
        // Repeated doubling reaches the engine's maximum string length through a
        // handful of operations and no characters, so the limit check has to fire
        // on the summed lengths before any over-long string is built. Each
        // over-limit expression must raise a catchable RangeError.
        var engine = NewEngine();
        engine.Execute("var s = 'x'; for (var i = 0; i < 28; i++) { s = s + s; }");

        Assert.Equal(268_435_456, engine.Evaluate("s.length").AsNumber());
        Assert.Equal(268_435_457, engine.Evaluate("(s + 'y').length").AsNumber());

        Assert.Equal("RangeError: Invalid string length", Caught(engine, "s + s"));
        Assert.Equal("RangeError: Invalid string length", Caught(engine, "s + s + s"));
        Assert.Equal("RangeError: Invalid string length", Caught(engine, "'y' + s + s"));
    }

    private static string Caught(Engine engine, string expression)
    {
        return engine
            .Evaluate($"(function () {{ try {{ {expression}; return 'no-throw'; }} catch (e) {{ return e.name + ': ' + e.message; }} }})()")
            .AsString();
    }

    // ---- Compound assignment is left untouched ---------------------------

    [Fact]
    public void CompoundAssignmentStillAccumulatesCorrectly()
    {
        // The `+=` path is already linear and must keep producing the same
        // result after the `+` change. This holds both before and after a
        // correct fix; it guards against a change that regresses `+=`.
        var engine = NewEngine();
        var value = engine
            .Evaluate("(function () { var s = ''; for (var i = 0; i < 1000; i++) { s += chunk; } return s; })()")
            .AsString();

        Assert.Equal(10000, value.Length);
        Assert.Equal(string.Concat(Enumerable.Repeat("0123456789", 1000)), value);
    }
}
