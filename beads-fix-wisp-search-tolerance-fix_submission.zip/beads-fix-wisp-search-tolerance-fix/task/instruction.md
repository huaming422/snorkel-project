## Task

our tracker keeps two kinds of issues side by side: durable ones and short-lived
ephemeral ones, and you can list and search across both.

we've got a data-correctness problem on the ephemeral side. on databases that
definitely hold ephemeral issues, a search or list quietly comes back with too
few of them, sometimes none, and reports success with no error. the records are
there, the results just omit them, nothing signals a problem. it kicks in when
the backing store for those issues is degraded, some piece the search leans on
missing or damaged: rather than surfacing that the store is broken, the search
acts as if there are no such issues and returns empty.

one case is legitimate. a database created before ephemeral issues existed has no
storage for them at all, and searching one of those correctly returns empty. the
problem is a broken store reading the same way as a legitimately empty one.

track down why a damaged store reads as empty and fix it so a search tells
"nothing here" apart from "store is broken".
