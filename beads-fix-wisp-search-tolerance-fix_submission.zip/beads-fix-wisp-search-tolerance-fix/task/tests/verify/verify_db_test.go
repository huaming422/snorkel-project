// Behavioral verifier — domain/db search stack.
//
// Driven through the pre-existing EXPORTED constructor + method
// db.NewIssueSQLRepository(runner).SearchAcrossIssuesAndWisps. The Runner it
// takes is satisfied directly by a go-sqlmock *sql.DB (ExecContext /
// QueryContext / QueryRowContext), so there is no real database, no cgo, and
// no Dolt. This file lives in the EXTERNAL test package `db_test`: it uses only
// the stable public surface, never the implementation's unexported helpers, and does
// not collide with the package's own in-package test files.
//
// Same contract as the classic stack — a broken wisp-adjacent table must
// surface as an error, a genuinely absent wisp plane must still tolerate to
// empty — asserted here so the two stacks are proven to answer a degraded store
// identically. A fix applied to only one stack leaves this file (or its
// issueops sibling) failing. Covers BOTH tolerated call sites in this stack:
// the ephemeral branch and the union-hydrate branch.
package db_test

import (
	"context"
	"database/sql"
	"errors"
	"testing"

	sqlmock "github.com/DATA-DOG/go-sqlmock"
	mysql "github.com/go-sql-driver/mysql"

	"github.com/steveyegge/beads/internal/storage/domain/db"
	"github.com/steveyegge/beads/internal/types"
)

func missingTable(table string) error {
	return &mysql.MySQLError{Number: 1146, Message: "table not found: " + table}
}

func ephemeralFilter() types.IssueFilter {
	on := true
	return types.IssueFilter{Ephemeral: &on}
}

func newMockDB(t *testing.T) (*sql.DB, sqlmock.Sqlmock) {
	t.Helper()
	sqldb, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New: %v", err)
	}
	t.Cleanup(func() { _ = sqldb.Close() })
	return sqldb, mock
}

// TestSearchEphemeralBrokenPlaneErrors — f2p (broken_wisp_plane_errors,
// broken_leases_errors) on the domain stack. Mirrors the issueops ephemeral
// guard: a table the wisp query reads but the wisp plane does not own
// (wisp_labels, leases) must propagate as an error, not read as "no wisps".
//
// Ephemeral query order: the wisps search query (raises the missing-table
// error). On the fix, that error propagates immediately — the presence probe
// and issues leg are never reached, so this case does not assert
// ExpectationsWereMet.
func TestSearchEphemeralBrokenPlaneErrors(t *testing.T) {
	for _, missing := range []string{"wisp_labels", "leases"} {
		t.Run(missing, func(t *testing.T) {
			sqldb, mock := newMockDB(t)
			gone := missingTable(missing)
			mock.ExpectQuery("FROM wisps").WillReturnError(gone)
			// Buggy-path priming: the swallowing fall-through probes wisp
			// presence then searches issues. Priming both makes the unfixed
			// behavior a clean (0 rows, nil) rather than an unexpected-query
			// error that could look like a pass.
			mock.ExpectQuery("SELECT 1 FROM wisps").WillReturnError(missingTable("wisps"))
			mock.ExpectQuery("FROM issues").WillReturnRows(sqlmock.NewRows([]string{"id"}))

			repo := db.NewIssueSQLRepository(sqldb)
			page, err := repo.SearchAcrossIssuesAndWisps(context.Background(), "", ephemeralFilter())
			if err == nil {
				t.Fatalf("search succeeded with a broken %s table, returning %d rows (want error)", missing, len(page.Items))
			}
			if !errors.Is(err, gone) {
				t.Fatalf("error is not the missing-%s driver failure (want errors.Is match): %v", missing, err)
			}
		})
	}
}

// TestSearchEphemeralPreMigrationEmpty — p2p (premigration_wisps_empty,
// missing_wisp_dependencies_invisible) on the domain stack. A pre-migration
// database has no wisp plane; missing `wisps` / `wisp_dependencies` must still
// search to an empty, error-free result. Fails an over-tightening to "never
// tolerate a missing table".
//
// Query order: wisps search raises table-not-exist (tolerated → empty) →
// presence probe reports the wisps table absent → issues leg returns no rows.
func TestSearchEphemeralPreMigrationEmpty(t *testing.T) {
	for _, table := range []string{"wisps", "wisp_dependencies"} {
		t.Run(table, func(t *testing.T) {
			sqldb, mock := newMockDB(t)
			mock.ExpectQuery("FROM wisps").WillReturnError(missingTable(table))
			mock.ExpectQuery("SELECT 1 FROM wisps").WillReturnError(missingTable("wisps"))
			mock.ExpectQuery("FROM issues").WillReturnRows(sqlmock.NewRows([]string{"id"}))

			repo := db.NewIssueSQLRepository(sqldb)
			page, err := repo.SearchAcrossIssuesAndWisps(context.Background(), "", ephemeralFilter())
			if err != nil {
				t.Fatalf("search errored on a database with no wisp plane (missing %s): %v", table, err)
			}
			if len(page.Items) != 0 {
				t.Fatalf("got %d rows, want 0 (missing %s)", len(page.Items), table)
			}
			if err := mock.ExpectationsWereMet(); err != nil {
				t.Fatalf("unmet sql expectations (missing %s): %v", table, err)
			}
		})
	}
}

// TestSearchEphemeralUnrelatedErrorPropagates — p2p
// (unrelated_error_propagates) on the domain stack. A non-table-not-exist
// failure on the wisps query must still propagate; the tolerance is not a
// blanket catch.
func TestSearchEphemeralUnrelatedErrorPropagates(t *testing.T) {
	sqldb, mock := newMockDB(t)
	boom := errors.New("connection refused")
	mock.ExpectQuery("FROM wisps").WillReturnError(boom)

	repo := db.NewIssueSQLRepository(sqldb)
	_, err := repo.SearchAcrossIssuesAndWisps(context.Background(), "", ephemeralFilter())
	if !errors.Is(err, boom) {
		t.Fatalf("search did not propagate a non-table-not-exist wisps failure: %v", err)
	}
}

// TestSearchUnionHydrateBrokenPlaneErrors — f2p. Covers the SECOND tolerated
// call site in this stack: the non-ephemeral union path's wisp hydration. The
// union has already produced wisp IDs, so a missing table during wisp
// hydration is a genuinely broken store, not an absent plane — it must error
// rather than silently drop the hydrated wisps from the merged page.
//
// The missing table modeled here is `leases`: the wisp-hydration fetch query
// reads it through the LEFT JOIN the wisp FROM clause carries, so a
// table-not-exist naming `leases` is exactly what that query would raise, and
// `leases` is outside the optional set so it must propagate.
//
// Query order (non-ephemeral, wisps present): presence probe reports the wisps
// table present → the UNION ALL query returns one wisp-tagged id → issue-leg
// hydration is skipped (no issue ids) → wisp-leg hydration queries the wisps
// table (with its lease join) and raises the missing-table error.
func TestSearchUnionHydrateBrokenPlaneErrors(t *testing.T) {
	sqldb, mock := newMockDB(t)
	gone := missingTable("leases")
	mock.ExpectQuery("SELECT 1 FROM wisps").WillReturnRows(sqlmock.NewRows([]string{"1"}).AddRow(1))
	mock.ExpectQuery("UNION ALL").WillReturnRows(sqlmock.NewRows([]string{"id", "src"}).AddRow("w-1", "w"))
	mock.ExpectQuery("FROM wisps").WillReturnError(gone)

	repo := db.NewIssueSQLRepository(sqldb)
	_, err := repo.SearchAcrossIssuesAndWisps(context.Background(), "", types.IssueFilter{})
	if !errors.Is(err, gone) {
		t.Fatalf("union search hid a broken wisp plane during hydration (want errors.Is match on missing leases): %v", err)
	}
}
