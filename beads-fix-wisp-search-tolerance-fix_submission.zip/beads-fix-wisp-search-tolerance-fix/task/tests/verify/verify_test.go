// Behavioral verifier — classic issueops search stack.
//
// Driven entirely through the pre-existing EXPORTED entrypoints
// issueops.SearchIssuesInTx / SearchIssueIDsInTx. The DBTX parameter they
// take is satisfied directly by a go-sqlmock *sql.DB (ExecContext /
// QueryContext / QueryRowContext), so no real database, no cgo, and no Dolt
// are involved. This file lives in the EXTERNAL test package `issueops_test`
// on purpose: it exercises only the stable public surface, it cannot touch
// the implementation's unexported helpers, and it will not collide with the package's
// own in-package test helpers (beginMockTx, missingTableError, ...).
//
// The contract under test: a wisp search whose query hits a table the wisp
// plane does not legitimately own (wisp_labels via hydration, leases via the
// LEFT JOIN) MUST surface an error instead of silently reporting an empty or
// short result. A database that genuinely never had a wisp plane (missing
// `wisps` / `wisp_dependencies` — a pre-migration shape) MUST still search to
// an empty ephemeral result with no error. Every must-error assertion uses
// errors.Is against the primed driver sentinel, never a message substring:
// the SQL text itself names the joined tables, so a substring check would
// pass vacuously on any error echoing the query.
package issueops_test

import (
	"context"
	"database/sql"
	"errors"
	"testing"

	sqlmock "github.com/DATA-DOG/go-sqlmock"
	mysql "github.com/go-sql-driver/mysql"

	"github.com/steveyegge/beads/internal/storage/issueops"
	"github.com/steveyegge/beads/internal/types"
)

func boolPtr(b bool) *bool { return &b }

// tableNotFound builds the driver's table-not-exist error (MySQL 1146,
// ER_NO_SUCH_TABLE) for a named table. The code under test classifies a
// missing table by this driver error, so this is the real signal a degraded
// store raises — not a fabricated one.
func tableNotFound(table string) error {
	return &mysql.MySQLError{Number: 1146, Message: "table not found: " + table}
}

func newMockDB(t *testing.T) (*sql.DB, sqlmock.Sqlmock) {
	t.Helper()
	db, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New: %v", err)
	}
	t.Cleanup(func() { _ = db.Close() })
	return db, mock
}

// searchEntryPoint wraps each exported search entrypoint behind a uniform
// (rowCount, error) shape so every behavioral case runs against BOTH the full
// SearchIssuesInTx projection and the id-only SearchIssueIDsInTx projection.
type searchEntryPoint struct {
	name string
	run  func(context.Context, issueops.DBTX, string, types.IssueFilter) (int, error)
}

var searchEntryPoints = []searchEntryPoint{
	{
		name: "SearchIssuesInTx",
		run: func(ctx context.Context, tx issueops.DBTX, q string, f types.IssueFilter) (int, error) {
			out, err := issueops.SearchIssuesInTx(ctx, tx, q, f)
			return len(out), err
		},
	},
	{
		name: "SearchIssueIDsInTx",
		run: func(ctx context.Context, tx issueops.DBTX, q string, f types.IssueFilter) (int, error) {
			out, err := issueops.SearchIssueIDsInTx(ctx, tx, q, f)
			return len(out), err
		},
	},
}

// TestWispSearchEphemeralBrokenPlaneErrors — f2p (broken_wisp_plane_errors,
// broken_leases_errors). The ephemeral branch runs the wisps query as its only
// query, so its table-not-exist check is the last word the caller hears. A
// table the wisp query reads but the wisp plane does not own — `wisp_labels`
// during hydration, `leases` through the LEFT JOIN — must propagate as an
// error rather than being answered as "there are no wisps".
//
// Base behavior: the blanket tolerance swallows the error, the issues leg
// returns no rows, and the caller gets (0 rows, nil) — a false-empty success.
// Fixed behavior: the error is raised immediately and the issues leg is never
// reached (so no ExpectationsWereMet() here — the fix legitimately leaves the
// primed issues query unconsumed).
func TestWispSearchEphemeralBrokenPlaneErrors(t *testing.T) {
	for _, missing := range []string{"wisp_labels", "leases"} {
		for _, ep := range searchEntryPoints {
			t.Run(missing+"/"+ep.name, func(t *testing.T) {
				db, mock := newMockDB(t)
				gone := tableNotFound(missing)
				mock.ExpectQuery("FROM wisps").WillReturnError(gone)
				// Only the tolerating (buggy) path reaches the issues plane.
				// Priming it makes the unfixed behavior a clean "0 rows, nil"
				// rather than an unexpected-query error that could read as a
				// pass for the wrong reason.
				mock.ExpectQuery("FROM issues").WillReturnRows(sqlmock.NewRows([]string{"id"}))

				n, err := ep.run(context.Background(), db, "", types.IssueFilter{Ephemeral: boolPtr(true)})
				if err == nil {
					t.Fatalf("search succeeded with a broken %s table, returning %d rows (want error)", missing, n)
				}
				if !errors.Is(err, gone) {
					t.Fatalf("error is not the missing-%s driver failure (want errors.Is match): %v", missing, err)
				}
			})
		}
	}
}

// TestWispSearchEphemeralPreMigrationEmpty — p2p (premigration_wisps_empty,
// missing_wisp_dependencies_invisible). The control the tightened guard must
// keep: a pre-migration database has no wisp plane at all, and a search of it
// really does match no wisps. Missing `wisps` or `wisp_dependencies` must
// still tolerate to an empty, error-free result. An over-tightening to "never
// tolerate a missing table" passes every must-error case above and fails here.
func TestWispSearchEphemeralPreMigrationEmpty(t *testing.T) {
	for _, table := range []string{"wisps", "wisp_dependencies"} {
		for _, ep := range searchEntryPoints {
			t.Run(table+"/"+ep.name, func(t *testing.T) {
				db, mock := newMockDB(t)
				mock.ExpectQuery("FROM wisps").WillReturnError(tableNotFound(table))
				mock.ExpectQuery("FROM issues").WillReturnRows(sqlmock.NewRows([]string{"id"}))

				n, err := ep.run(context.Background(), db, "", types.IssueFilter{Ephemeral: boolPtr(true)})
				if err != nil {
					t.Fatalf("search errored on a database with no wisp plane (missing %s): %v", table, err)
				}
				if n != 0 {
					t.Fatalf("got %d rows, want 0 (missing %s)", n, table)
				}
				if err := mock.ExpectationsWereMet(); err != nil {
					t.Fatalf("unmet sql expectations (missing %s): %v", table, err)
				}
			})
		}
	}
}

// TestWispSearchEphemeralUnrelatedErrorPropagates — p2p
// (unrelated_error_propagates). The tolerance must not be a blanket catch in
// either direction: a non-table-not-exist failure on the wisps query (e.g. a
// dropped connection) must still propagate. Guards against a fix that widens
// the catch to "swallow any wisps-query error".
func TestWispSearchEphemeralUnrelatedErrorPropagates(t *testing.T) {
	for _, ep := range searchEntryPoints {
		t.Run(ep.name, func(t *testing.T) {
			db, mock := newMockDB(t)
			boom := errors.New("connection refused")
			mock.ExpectQuery("FROM wisps").WillReturnError(boom)

			_, err := ep.run(context.Background(), db, "", types.IssueFilter{Ephemeral: boolPtr(true)})
			if !errors.Is(err, boom) {
				t.Fatalf("search did not propagate a non-table-not-exist wisps failure: %v", err)
			}
		})
	}
}

// TestWispSearchMergeBrokenPlaneErrors — f2p. Covers the SECOND tolerated call
// site in this stack: the non-ephemeral merge branch. There the issues leg has
// already succeeded, so a swallowed wisp failure is not re-raised by anything
// downstream and the caller silently gets a short list. Query order for the
// merge branch: issues leg, then the wisp-presence probe (non-empty here, so
// the merge proceeds), then the wisps leg which raises the missing-table error.
func TestWispSearchMergeBrokenPlaneErrors(t *testing.T) {
	db, mock := newMockDB(t)
	gone := tableNotFound("wisp_labels")
	mock.ExpectQuery("FROM issues").WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow("bd-1"))
	mock.ExpectQuery("SELECT 1 FROM wisps").WillReturnRows(sqlmock.NewRows([]string{"1"}).AddRow(1))
	mock.ExpectQuery("FROM wisps").WillReturnError(gone)

	_, err := issueops.SearchIssueIDsInTx(context.Background(), db, "", types.IssueFilter{})
	if !errors.Is(err, gone) {
		t.Fatalf("merged search hid a broken wisp plane (want errors.Is match on missing wisp_labels): %v", err)
	}
}
