#!/usr/bin/env bash
# All dependencies (go-sqlmock, go-sql-driver/mysql, the full module closure at
# the base commit) are baked into the image and the go build/module caches are
# warm. The verifier is a pure-Go sqlmock test — no cgo, no Dolt, no services.
# Nothing to install or start at verifier time.
set -euo pipefail
echo "[test-setup] no-op for beads-fix-wisp-search-tolerance"
