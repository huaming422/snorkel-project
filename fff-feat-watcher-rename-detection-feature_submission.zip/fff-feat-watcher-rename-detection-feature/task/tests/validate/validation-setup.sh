#!/usr/bin/env bash
# validation-setup.sh — environment bootstrap for the validation agent's
# cargo-test story scripts. `source`d by test.sh AFTER tests/test-setup.sh and
# BEFORE the validation orchestrator dispatches the agent. Idempotent.
#
# This task has no services to start and no data to seed: the image bakes the
# full dependency closure at the task base commit (cargo fetch --locked + a
# complete `--no-default-features --features zlob --workspace` test build), so
# the two cargo-test stories build the solution's patched crate against the
# warm, offline cargo cache. This script only hardens that environment — it is
# sourced, so it must never `exit`/`set -e` (that would abort the parent).

# Keep cargo offline: the validation phase opens the network only to the model
# gateway, never to crates.io. The baked closure makes a rebuild a cache hit;
# failing fast here beats hanging on a network that is not there for deps.
export CARGO_NET_OFFLINE=true

# The `zlob` feature the stories enable is a Zig-compiled C glob library whose
# build.rs invokes `zig build`; the image symlinks zig to /usr/local/bin, but
# make sure it is reachable even if the agent reshaped PATH.
if ! command -v zig >/dev/null 2>&1; then
    if [ -x /usr/local/bin/zig ]; then
        export PATH="/usr/local/bin:${PATH}"
    elif [ -x /opt/zig/zig ]; then
        export PATH="/opt/zig:${PATH}"
    fi
fi

echo "[validation-setup] Rust:   $(rustc --version 2>&1 | head -1)"
echo "[validation-setup] Cargo:  $(cargo --version 2>&1 | head -1)"
if command -v zig >/dev/null 2>&1; then
    echo "[validation-setup] Zig:    $(zig version 2>&1 | head -1)"
else
    echo "[validation-setup] WARNING: zig not found on PATH; --features zlob will fail to build" >&2
fi
echo "[validation-setup] Workspace root:   /repo/fff"
echo "[validation-setup] cargo_package:    crates/fff-core (package fff-search)"
echo "[validation-setup] CARGO_NET_OFFLINE=${CARGO_NET_OFFLINE}"
echo "[validation-setup] ready."
