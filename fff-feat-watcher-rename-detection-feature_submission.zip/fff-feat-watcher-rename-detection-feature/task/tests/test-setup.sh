#!/usr/bin/env bash
# No services to start, no data to seed. The image bakes the full dependency
# closure at the task base commit (cargo fetch --locked + a complete
# `--no-default-features --features zlob --workspace --exclude fff-nvim
# --exclude fff-python --tests` build), so every crate the focused tests need
# is already in the warm cargo cache and the agent phase builds offline.
set -euo pipefail

# Fail fast on a cache miss instead of reaching for a network that the agent
# phase does not have (and that the verifier phase only opens to the model
# gateway). The closure above makes this a no-op in practice.
export CARGO_NET_OFFLINE=true

echo "[test-setup] Rust version:    $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:   $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Zig version:     $(zig version 2>&1 | head -1)"
echo "[test-setup] Workspace root:  /repo/fff"
echo "[test-setup] CARGO_NET_OFFLINE=${CARGO_NET_OFFLINE}"
echo "[test-setup] Setup complete."
