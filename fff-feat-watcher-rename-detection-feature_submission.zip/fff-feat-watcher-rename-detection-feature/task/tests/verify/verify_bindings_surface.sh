#!/usr/bin/env bash
#
# Structural verifier for criterion `bindings_surface`.
#
# The move capability must be observable through EVERY script binding, not just
# Rust: Python, Node, and Bun must expose the move kind and the source path, and
# the shared TypeScript event-kind union must include the move kind. The task
# image bakes only the Rust + C toolchain (no maturin / node / bun runtime), so
# this is a decode-path / surface check on the binding sources rather than a
# live per-binding run (see the criterion re-route note in task.toml).
#
# Every assertion is NAME-AGNOSTIC: the agent is free to choose the move-kind
# label, the source field name, and the accessor name (Alternative 5). We check
# that each surface GREW the right shape, never that it grew a specific name:
#
#   * each TypeScript `WatchEventKind` union gained a kind beyond the four
#     pre-existing ones (created / modified / removed / rescan);
#   * each TypeScript `WatchEvent` interface gained a new optional field
#     (the source, only present on a move);
#   * the Python watch-event class gained a third read getter beyond
#     path + kind;
#   * each of the Node and Bun batch decoders references a watch-batch C
#     accessor beyond the three pre-existing ones (count / get_path /
#     get_kind) — the only mechanism by which these decoders, which hold no
#     struct-layout knowledge, can surface a per-entry source.
#
# ALL binding surfaces must pass: a solution that implements the move in only
# some of the bindings is a rejected approach. Fails loud, listing every
# surface that did not grow.

set -euo pipefail

REPO_DIR="$(pwd)"
fail() { printf '[bindings] FAIL: %s\n' "$*" >&2; exit 1; }
log()  { printf '[bindings] %s\n' "$*" >&2; }

need_file() { [ -f "$1" ] || fail "expected binding source not found: $1"; }

SHARED_API="packages/shared/fff-api.ts"
NODE_API="packages/fff-node/src/fff-api.ts"
BUN_API="packages/fff-bun/src/fff-api.ts"
PY_TYPES="crates/fff-python/src/types.rs"
NODE_FFI="packages/fff-node/src/ffi.ts"
BUN_FFI="packages/fff-bun/src/ffi.ts"

for f in "$SHARED_API" "$NODE_API" "$BUN_API" "$PY_TYPES" "$NODE_FFI" "$BUN_FFI"; do
    need_file "$f"
done

# --- helper: number of string literals in the WatchEventKind union ------------
union_literal_count() {
    # The union `export type WatchEventKind = "..." | "..." ;` may be written on
    # a single line or wrapped across several lines (prettier). Capture the whole
    # declaration from `type WatchEventKind =` through the terminating `;`, then
    # count the double-quoted string literals across the entire block.
    local f="$1"
    awk '/type WatchEventKind[[:space:]]*=/{p=1} p{print} p&&/;/{exit}' "$f" \
        | grep -oE '"[^"]+"' | wc -l | tr -d ' '
}

# --- helper: does the TS event type carry a source field for a move? ----------
event_type_carries_source() {
    # base.md only requires that "the TypeScript event type must represent" the
    # move; it does NOT mandate the interface-with-optional shape. Accept either
    # idiomatic TS representation, name-agnostically:
    #
    #   (a) an `export interface WatchEvent { ... }` block that grew a new
    #       OPTIONAL property (the source, present only on a move), OR
    #   (b) a tagged union `type WatchEvent = A | B ...` whose move variant
    #       carries a source property beyond the pre-existing path + kind.
    #
    # In both cases the shape we look for is the same: a string/path-typed
    # property whose name is neither `path` nor `kind` (the two baseline fields).
    # We do not look for any specific source-field name.
    local f="$1"

    # (a) interface WatchEvent with a new optional property.
    if awk '/export interface WatchEvent[[:space:]]*\{/{p=1} p{print} p&&/^\}/{exit}' "$f" \
        | grep -qE '[A-Za-z_][A-Za-z0-9_]*\?[[:space:]]*:'; then
        return 0
    fi

    # (b) union type `type WatchEvent = A | B ...` (single-line OR multi-line)
    #     whose move variant carries a source-like property beyond the baseline
    #     path + kind fields.
    #
    #   Single-line: `export type WatchEvent = BaseWatchEvent | MovedWatchEvent;`
    #     — `=` and `|` are on the same line in the single-line awk extraction.
    #   Multi-line (prettier): each member on its own line with a leading `|`:
    #     `export type WatchEvent =`
    #     `  | { path: string; kind: ...; }`
    #     `  | { path: string; kind: "moved"; oldPath: string; };`
    #     — the `=` and `|` are on separate lines, so the single-line awk exits
    #     at the first inner `;` before seeing any `|`. Detect via the leading-`|`
    #     pattern (`^\s*|`) which multi-line unions use for object-literal members.
    local has_watchevent_union=false
    # single-line union: = and | on the same awk-extracted line
    if awk '/type WatchEvent[[:space:]]*=/{p=1} p{print} p&&/;/{exit}' "$f" \
        | grep -qE '=[^;]*\|'; then
        has_watchevent_union=true
    # multi-line union: type WatchEvent = exists AND file has `  | {` member lines
    elif grep -qE 'type WatchEvent[[:space:]]*=' "$f" && \
         grep -qE '^\s*\|\s*\{' "$f"; then
        has_watchevent_union=true
    fi
    if $has_watchevent_union; then
        # A required-or-optional property typed string/PathBuf, excluding the two
        # baseline fields (path, kind). Case-insensitive on the type keyword.
        if grep -oiE '[A-Za-z_][A-Za-z0-9_]*\??[[:space:]]*:[[:space:]]*(string|pathbuf)' "$f" \
            | grep -vqiE '^(path|kind)\??[[:space:]]*:'; then
            return 0
        fi
    fi
    return 1
}

# --- helper: count read getters in the Python WatchEvent pyclass --------------
py_watchevent_getter_count() {
    # Block = `pub struct WatchEvent { ... }`; count #[pyo3(get)] inside it.
    awk '/pub struct WatchEvent[[:space:]]*\{/{p=1} p{print} p&&/^\}/{exit}' "$PY_TYPES" \
        | grep -cE 'pyo3\(get\)' || true
}

# --- helper: count distinct fff_watch_events_* accessors referenced -----------
distinct_watch_accessors() {
    local f="$1"
    grep -oE 'fff_watch_events_[A-Za-z0-9_]+' "$f" | sort -u | wc -l | tr -d ' '
}

errors=0
note_fail() { log "  - $1"; errors=$((errors + 1)); }

# 1. TypeScript unions grew a new kind (pre-fix 4 literals) ---------------------
for f in "$SHARED_API" "$NODE_API" "$BUN_API"; do
    n="$(union_literal_count "$f")"
    if [ "$n" -ge 5 ]; then
        log "ok: $f WatchEventKind union has $n kinds (grew beyond 4)"
    else
        note_fail "$f: WatchEventKind union has $n kinds; expected a new move kind (>=5)"
    fi
done

# 2. TypeScript WatchEvent type grew a source field for a move -----------------
#    Accepts either an interface-with-optional or a tagged union whose move
#    variant carries the source (base.md only asks the event type to
#    "represent" the move; the TS shape is the agent's choice).
for f in "$SHARED_API" "$NODE_API" "$BUN_API"; do
    if event_type_carries_source "$f"; then
        log "ok: $f WatchEvent type exposes a move source field"
    else
        note_fail "$f: WatchEvent type has no source field for a move"
    fi
done

# 3. Python watch-event class grew a third read getter (pre-fix 2) -------------
pg="$(py_watchevent_getter_count)"
if [ "${pg:-0}" -ge 3 ]; then
    log "ok: Python WatchEvent exposes $pg read getters (grew beyond path+kind)"
else
    note_fail "$PY_TYPES: Python WatchEvent exposes ${pg:-0} getters; expected a source getter (>=3)"
fi

# 4. Node + Bun decoders reference a new watch-batch accessor (pre-fix 3) ------
for f in "$NODE_FFI" "$BUN_FFI"; do
    n="$(distinct_watch_accessors "$f")"
    if [ "$n" -ge 4 ]; then
        log "ok: $f references $n distinct watch accessors (reads a per-entry source)"
    else
        note_fail "$f: references $n distinct watch accessors; expected a source accessor (>=4)"
    fi
done

if [ "$errors" -gt 0 ]; then
    fail "$errors binding surface(s) did not expose the move kind + source"
fi

log "PASS: move kind + source observable across Python, Node, Bun, and the TS union"
