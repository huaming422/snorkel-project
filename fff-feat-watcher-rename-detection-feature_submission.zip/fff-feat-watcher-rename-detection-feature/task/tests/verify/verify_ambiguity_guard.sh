#!/usr/bin/env bash
#
# Behavioral verifier for criterion `rename_ambiguity_guard`.
#
# Conservative pairing is a load-bearing contract behaviour (base.md: "crossing
# one file's history onto another is worse than missing a move"), but it only
# governs the (size, mtime) INFERENCE fallback. On this Linux grader an in-tree
# move reaches the classifier as an explicit cookie-paired OS rename event and
# is paired directly, never touching the inference path — so the guard is
# invisible at every public watcher interface, and a guard-less solution that
# pairs on a preserved identity WITHOUT a both-sides uniqueness check passes the
# live-watcher validation stories unchanged. This verifier closes that hole.
#
# It drives the pre-existing debounced-batch classifier seam
# (`handle_debounced_events`, the documented classification site — see task.toml
# context and criterion `rename_ambiguity_guard`'s ideal_test, which names
# driving this seam directly) with a synthesized BULK disappear/appear batch in
# which several removed files and several added files all share one identical
# (size, mtime). That is the exact ambiguity the guard protects: guessing a pair
# would attach the wrong source — and later the wrong ranking history — to a new
# file. The check is NAME-AGNOSTIC: it observes the outcome only through the
# pre-existing public watch-event kind strings (`WatchEventKind::as_str`) and the
# pre-existing public ranking-store read API (`FrecencyTracker::access_count`),
# never through any symbol the agent invents.
#
# A CORRECT solution (any uniqueness-guarded identity, or any stronger identity
# such as content) leaves the ambiguous batch as plain removed/created and
# cross-wires no history. A GAMEABLE solution (pair on identity with no
# uniqueness guard) collapses the batch into a move and/or carries a source's
# history onto an unrelated new path — and fails here.
#
# The test is injected into the agent's own crate and compiled against the
# agent's solution. If it does not COMPILE (e.g. the agent refactored the
# classifier seam's signature — a free but unusual choice), the check is SKIPPED
# rather than failed, so a legitimate refactor is never rejected on build
# grounds; the guard still carries rubric coverage. A compiled-and-failed run is
# a real contract violation and fails loud.

set -euo pipefail

REPO_DIR="$(pwd)"
TARGET="crates/fff-core/src/watcher/background_watcher.rs"

log()  { printf '[ambiguity] %s\n' "$*" >&2; }
fail() { printf '[ambiguity] FAIL: %s\n' "$*" >&2; exit 1; }
skip() { printf '[ambiguity] SKIP: %s\n' "$*" >&2; exit 0; }

[ -f "$TARGET" ] || skip "classifier source $TARGET not found (unexpected layout); guard carries rubric coverage"

WORK="$(mktemp -d)"
BACKUP="$WORK/background_watcher.rs.orig"
cp "$TARGET" "$BACKUP"
# Always restore the agent's file so later verifiers see an untouched tree.
restore() { cp "$BACKUP" "$TARGET"; rm -rf "$WORK"; }
trap restore EXIT

# --- the injected, name-agnostic coverage test ------------------------------
cat >> "$TARGET" <<'RUST'

// Injected by verify_ambiguity_guard.sh. Removed after the run.
#[cfg(test)]
mod conservative_pairing_verifier {
    use super::*;
    use crate::WatchOptions;
    use crate::shared::{SharedFilePicker, SharedFrecency};
    use std::fs::File;
    use std::sync::mpsc;
    use std::time::{Duration, Instant, SystemTime};

    #[test]
    fn ambiguous_identity_batch_stays_unpaired_and_does_not_crosswire() {
        let tmp = tempfile::tempdir().unwrap();
        let base = crate::path_utils::canonicalize(tmp.path()).unwrap();

        // Fixed, shared identity: equal size AND equal mtime for every file, so
        // a (size, mtime) match is ambiguous across the whole batch.
        let stamp = SystemTime::UNIX_EPOCH + Duration::from_secs(1_700_000_000);
        let a = base.join("a.txt");
        let b = base.join("b.txt");
        std::fs::write(&a, "xy").unwrap();
        std::fs::write(&b, "zw").unwrap();
        File::open(&a).unwrap().set_modified(stamp).unwrap();
        File::open(&b).unwrap().set_modified(stamp).unwrap();

        // Real ranking store with history recorded on source `a` only.
        let fdir = tempfile::tempdir().unwrap();
        let tracker =
            crate::dbs::frecency::FrecencyTracker::open(fdir.path().join("f.mdb")).unwrap();
        tracker.track_access(&a).unwrap();
        tracker.track_access(&a).unwrap();
        tracker.track_access(&a).unwrap();
        let shared_frecency = SharedFrecency::default();
        shared_frecency.init(tracker).unwrap();

        // Index both sources with a non-watching picker, so the removed paths
        // still carry their indexed size/mtime when the batch is classified.
        let shared_picker = SharedFilePicker::default();
        let mut picker =
            crate::file_picker::FilePicker::new(crate::file_picker::FilePickerOptions {
                base_path: base.to_string_lossy().into_owned(),
                watch: false,
                ..Default::default()
            })
            .unwrap();
        picker.collect_files().unwrap();
        shared_picker.rebase_watches(&base);
        *shared_picker.write().unwrap() = Some(picker);

        let (tx, rx) = mpsc::channel::<Vec<crate::watch::WatchEvent>>();
        shared_picker
            .watch_registry()
            .subscribe(
                &base,
                "**",
                WatchOptions::default(),
                Box::new(move |_, events| {
                    let _ = tx.send(events.to_vec());
                }),
            )
            .unwrap();

        // Bulk disappear/appear: a,b vanish; c,d appear; all identical identity.
        // No explicit OS rename cookie, so pairing can only come from inference.
        let c = base.join("c.txt");
        let d = base.join("d.txt");
        std::fs::remove_file(&a).unwrap();
        std::fs::remove_file(&b).unwrap();
        std::fs::write(&c, "pq").unwrap();
        std::fs::write(&d, "rs").unwrap();
        File::open(&c).unwrap().set_modified(stamp).unwrap();
        File::open(&d).unwrap().set_modified(stamp).unwrap();

        let now = Instant::now();
        let events = vec![
            DebouncedEvent::new(
                notify::Event::new(EventKind::Remove(notify::event::RemoveKind::File))
                    .add_path(a.clone()),
                now,
            ),
            DebouncedEvent::new(
                notify::Event::new(EventKind::Remove(notify::event::RemoveKind::File))
                    .add_path(b.clone()),
                now,
            ),
            DebouncedEvent::new(
                notify::Event::new(EventKind::Create(notify::event::CreateKind::File))
                    .add_path(c.clone()),
                now,
            ),
            DebouncedEvent::new(
                notify::Event::new(EventKind::Create(notify::event::CreateKind::File))
                    .add_path(d.clone()),
                now,
            ),
        ];

        handle_debounced_events(
            FFFMode::Neovim,
            events,
            &base,
            &None,
            &shared_picker,
            &shared_frecency,
            &GitStatusWorker::new(),
        );

        let mut delivered = Vec::new();
        while let Ok(batch) = rx.recv_timeout(Duration::from_millis(500)) {
            delivered.extend(batch);
        }

        // (1) The ambiguous batch must NOT be resolved into a move: every
        //     delivered event keeps a baseline kind (no move-kind string). Read
        //     name-agnostically through the public kind string.
        for ev in &delivered {
            let k = ev.kind.as_str();
            assert!(
                matches!(k, "created" | "modified" | "removed" | "rescan"),
                "ambiguous (size,mtime) batch was mis-paired into a move (kind {k:?}); \
                 a bulk disappear/appear sharing one identity must stay plain \
                 removed/created, never be paired arbitrarily"
            );
        }

        // (2) Source `a`'s ranking history must NOT be cross-wired onto any new
        //     path. Read through the public store API; both new paths stay at 0.
        let guard = shared_frecency.read().unwrap();
        let store = guard.as_ref().expect("frecency store present");
        assert_eq!(
            store.access_count(&c).unwrap(),
            0,
            "ambiguous batch cross-wired a source's ranking history onto a new path (c)"
        );
        assert_eq!(
            store.access_count(&d).unwrap(),
            0,
            "ambiguous batch cross-wired a source's ranking history onto a new path (d)"
        );
    }
}
RUST

# --- compile (skip on build failure) ----------------------------------------
TEST_FILTER="conservative_pairing_verifier"
log "compiling injected ambiguity-guard test against the agent's crate..."
if ! cargo test -p fff-search --no-default-features --features zlob --lib \
        "$TEST_FILTER" --no-run > "$WORK/build.log" 2>&1; then
    tail -40 "$WORK/build.log" >&2
    skip "injected test did not compile (classifier seam likely refactored); \
guard carries rubric coverage — not failing a legitimate refactor on build grounds"
fi

# --- run (compiled => a failure is a real contract violation) ---------------
# The injected module name is unique, so a bare substring filter selects exactly
# this one test. Do NOT use `--exact` with a module-relative name: the full test
# path is prefixed by the parent modules, so an `--exact` on the short name
# matches 0 tests and cargo would exit 0 — silently turning a real failure into
# a pass. Instead run the substring filter and assert a test actually ran.
log "running ambiguity-guard test..."
set +e
cargo test -p fff-search --no-default-features --features zlob --lib \
    "$TEST_FILTER" > "$WORK/run.log" 2>&1
run_rc=$?
set -e

if [ "$run_rc" -ne 0 ]; then
    tail -60 "$WORK/run.log" >&2
    fail "an ambiguous (size,mtime) bulk batch was paired into a move and/or \
cross-wired ranking history — the rename pairing lacks a both-sides uniqueness guard"
fi

# Guard against the 0-tests-ran trap: a filter that selects nothing exits 0.
# Require the exact test to have been reported as passed.
if ! grep -qE 'ambiguous_identity_batch_stays_unpaired_and_does_not_crosswire \.\.\. ok' \
        "$WORK/run.log"; then
    tail -60 "$WORK/run.log" >&2
    skip "injected ambiguity-guard test did not run (0 tests selected — seam \
likely renamed/relocated); guard carries rubric coverage, not failing on a \
harness mismatch"
fi

log "PASS: ambiguous bulk batch stays unpaired and carries no cross-wired history"
