#!/usr/bin/env bash
#
# Structural verifier for criterion `c_abi_append_only`.
#
# Confirms the C ABI event batch grew by APPEND ONLY and that a renamed
# entry's source path is reachable through a C accessor that reports NULL for
# non-rename entries — WITHOUT pinning any identifier the solving agent is free
# to choose (the accessor name, the new field name, the exact grown size) and
# WITHOUT merely re-running the agent's own in-crate layout test.
#
# What is asserted (all three independently):
#   1. Compile-time, against the agent's own published header
#      `crates/fff-c/include/fff.h`:
#        * the batch's pre-existing members stay put — the first pointer field
#          at offset 0 and the u32 count at offset 8 (the frozen prefix every
#          downstream decoder relies on);
#        * the per-event struct is still exactly 16 bytes;
#        * the per-event `path` stays at offset 0;
#        * the batch struct GREW beyond its old 16 bytes (it now carries the
#          source). `>= 24` on a 64-bit target = at least one appended pointer;
#          a richer append-only layout (more fields) also passes.
#      A field inserted before `count`, a widened event struct, or a batch that
#      did not grow all fail this compile.
#   2. A new batch accessor exists: a `fff_watch_events_*` entry point beyond
#      the three pre-existing ones (count / get_path / get_kind), discovered by
#      name from the header, returning a C string for a (batch, index) pair.
#   3. Runtime (best-effort, see note): drive a plain file creation through the
#      live C watch API and confirm the discovered accessor returns NULL for
#      that non-rename entry. This exercises the "null for non-renames" half of
#      the contract deterministically (a brand-new file is always a creation,
#      never a move). The non-null-for-a-real-rename half is guaranteed
#      structurally by (1)+(2) and graded behaviorally by the Rust validation
#      stories; forcing a live rename inside a C harness would add flakiness
#      without adding signal, so if the watcher delivers no batch within the
#      wait window this step is skipped rather than failed (the watcher's
#      delivery timing is not what this criterion grades).
#
# Runs from the repo dir (/repo/fff). Fails loud on any structural violation.

set -euo pipefail

REPO_DIR="$(pwd)"
HEADER="crates/fff-c/include/fff.h"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

log() { printf '[c-abi] %s\n' "$*" >&2; }
fail() { printf '[c-abi] FAIL: %s\n' "$*" >&2; exit 1; }

[ -f "$HEADER" ] || fail "published C header not found at $HEADER"

# ---------------------------------------------------------------------------
# 1. Build the C library (cdylib) so the probe can link against the real ABI.
#    Match the feature set the image pre-warms (--no-default-features
#    --features zlob) to hit the warm cargo cache.
# ---------------------------------------------------------------------------
log "building fff-c cdylib (warm cache expected)..."
if ! cargo build -p fff-c --no-default-features --features zlob \
        > "$WORK/cargo.log" 2>&1; then
    tail -80 "$WORK/cargo.log" >&2
    fail "cargo build -p fff-c failed"
fi

TARGET_ROOT="${CARGO_TARGET_DIR:-$REPO_DIR/target}"
LIBDIR=""
for cand in "$TARGET_ROOT/debug" "$REPO_DIR/target/debug"; do
    if ls "$cand"/libfff_c.* >/dev/null 2>&1; then LIBDIR="$cand"; break; fi
done
[ -n "$LIBDIR" ] || fail "libfff_c not found under $TARGET_ROOT/debug"
log "linking against $LIBDIR"

# ---------------------------------------------------------------------------
# 2. Discover the new source accessor from the header, name-agnostically:
#    any `fff_watch_events_*` function that is NOT one of the three
#    pre-existing accessors. The agent is free to name it anything.
# ---------------------------------------------------------------------------
ACCESSOR="$(grep -oE 'fff_watch_events_[A-Za-z0-9_]+' "$HEADER" \
    | sort -u \
    | grep -vE '^fff_watch_events_(count|get_path|get_kind)$' \
    | head -n1 || true)"
[ -n "$ACCESSOR" ] || fail "no new fff_watch_events_* source accessor found in $HEADER \
(the renamed entry's source must be reachable through a C accessor)"
log "discovered source accessor: $ACCESSOR"

# ---------------------------------------------------------------------------
# 3. Compile-time layout assertions, independent of the agent's layout test.
# ---------------------------------------------------------------------------
cat > "$WORK/layout.c" <<C_EOF
#include <fff.h>
#include <stddef.h>

/* Frozen prefix: the pre-existing batch fields must not move. */
_Static_assert(offsetof(struct FffWatchEventBatch, events) == 0,
               "batch.events must stay at offset 0");
_Static_assert(offsetof(struct FffWatchEventBatch, count) == 8,
               "batch.count must stay at offset 8");

/* Per-event struct is frozen at 16 bytes with path first. */
_Static_assert(sizeof(struct FffWatchEvent) == 16,
               "FffWatchEvent must stay 16 bytes");
_Static_assert(offsetof(struct FffWatchEvent, path) == 0,
               "event.path must stay at offset 0");

/* Append-only growth: the batch must have grown to carry the source. */
_Static_assert(sizeof(struct FffWatchEventBatch) >= 24,
               "batch must grow (append-only) to carry per-entry source");

int main(void) { return 0; }
C_EOF

log "compiling independent layout assertions..."
if ! clang -std=c11 -I crates/fff-c/include "$WORK/layout.c" \
        -o "$WORK/layout" > "$WORK/layout_cc.log" 2>&1; then
    tail -60 "$WORK/layout_cc.log" >&2
    fail "C ABI layout assertions did not hold (see offsets/sizes above)"
fi
log "layout assertions passed (events@0, count@8, event==16B, batch grew)"

# ---------------------------------------------------------------------------
# 4. Runtime exercise: a plain file creation must report NULL source through
#    the discovered accessor. Best-effort on watcher delivery (see header note).
# ---------------------------------------------------------------------------
cat > "$WORK/probe.c" <<C_EOF
#define _DEFAULT_SOURCE
#define _BSD_SOURCE
#include <fff.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static int saw_event = 0;
static int source_leak = 0; /* a non-rename entry reported a non-NULL source */

static void on_batch(uint64_t watch_id, struct FffWatchEventBatch *batch, void *ud) {
    (void)watch_id; (void)ud;
    for (uint32_t i = 0; i < batch->count; i++) {
        const char *p = fff_watch_events_get_path(batch, i);
        if (!p || !strstr(p, "created_probe.txt")) continue;
        saw_event = 1;
        /* This entry is a brand-new file creation, never a move:
           the source accessor must report NULL for it. */
        const char *src = ${ACCESSOR}(batch, i);
        if (src != NULL) source_leak = 1;
    }
    fff_free_watch_events(batch);
}

/* Bring up a watched picker and subscribe. Returns a picker handle on success,
   or NULL on a transient setup failure (the live watch backend can lose a
   startup race and report !success). The caller retries; exhausting retries is
   an infra SKIP, never a contract failure. */
static void *bring_up_watch(void) {
    char tmpl[] = "/tmp/fff-cabi-XXXXXX";
    char *dir = mkdtemp(tmpl);
    if (!dir) { fprintf(stderr, "mkdtemp failed\n"); return NULL; }

    struct FffResult *cr = fff_create_instance_with(&(struct FffCreateOptions){
        .version = FFF_CREATE_OPTIONS_VERSION, .base_path = dir,
        .enable_mmap_cache = false, .enable_content_indexing = false, .watch = true,
    });
    if (!cr->success) { fprintf(stderr, "create failed (transient)\n"); fff_free_result(cr); return NULL; }
    void *picker = cr->handle; fff_free_result(cr);

    struct FffResult *r = fff_wait_for_scan(picker, 10000); fff_free_result(r);
    r = fff_wait_for_watcher(picker, 10000); fff_free_result(r);
    usleep(300 * 1000);

    r = fff_set_watch_callback(picker, on_batch, NULL);
    if (!r->success) { fprintf(stderr, "set_watch_callback failed (transient)\n"); fff_free_result(r); fff_destroy(picker); return NULL; }
    fff_free_result(r);
    r = fff_watch(picker, NULL, NULL);
    if (!r->success) { fprintf(stderr, "fff_watch failed (transient)\n"); fff_free_result(r); fff_destroy(picker); return NULL; }
    fff_free_result(r);

    /* Emit the probe file into this picker's own base dir. */
    char path[512];
    snprintf(path, sizeof(path), "%s/created_probe.txt", dir);
    FILE *f = fopen(path, "w");
    if (!f) { fprintf(stderr, "fopen failed (transient)\n"); fff_destroy(picker); return NULL; }
    fputs("hello\n", f); fclose(f);
    return picker;
}

int main(void) {
    /* The watch backend's startup is racy; retry the bring-up a few times so a
       transient !success does not masquerade as a contract failure. */
    void *picker = NULL;
    for (int attempt = 0; attempt < 5 && !picker; attempt++) {
        if (attempt) usleep(500 * 1000);
        picker = bring_up_watch();
    }
    if (!picker) {
        fprintf(stderr, "note: watch backend did not start after retries; skipping runtime null-source check\n");
        return 2; /* infra SKIP — not a contract violation */
    }

    for (int i = 0; i < 100 && !saw_event; i++) usleep(100 * 1000);

    fff_destroy(picker); /* quiescence barrier */

    if (source_leak) { fprintf(stderr, "FAIL: non-rename entry reported a non-NULL source\n"); return 1; }
    if (!saw_event) { fprintf(stderr, "note: watcher delivered no batch in time; skipping runtime null-source check\n"); return 2; }
    fprintf(stderr, "runtime null-source check passed\n");
    return 0;
}
C_EOF

log "compiling + linking runtime probe (accessor: $ACCESSOR)..."
if ! clang -std=c11 -I crates/fff-c/include "$WORK/probe.c" \
        -L "$LIBDIR" -lfff_c -lpthread -ldl -lm \
        -o "$WORK/probe" > "$WORK/probe_cc.log" 2>&1; then
    tail -60 "$WORK/probe_cc.log" >&2
    fail "could not compile/link the C runtime probe against the published accessor"
fi

log "running runtime probe..."
# Probe exit codes are meaningful and must NOT be collapsed:
#   0 — a non-rename entry was observed and its source read back NULL (pass);
#   1 — a non-rename entry reported a NON-NULL source: a real contract
#       violation (fail loud);
#   2 — the live watch backend did not start, or delivered no batch within the
#       wait window: a transient SETUP/infra outcome, never a contract
#       violation. The null-source half is graded best-effort (see header); the
#       non-null-for-a-real-rename half is covered structurally by (1)+(2) above
#       and behaviorally by the Rust stories, so a skipped runtime probe loses
#       no signal. Treating a startup race as a hard failure would make a
#       correct solution flaky, so a code-2 skip is logged and the verifier
#       still PASSes.
set +e
LD_LIBRARY_PATH="$LIBDIR" "$WORK/probe"
probe_rc=$?
set -e
case "$probe_rc" in
    0) log "runtime null-source check passed" ;;
    2) log "runtime null-source check SKIPPED (watch backend transient; structural + Rust-story coverage stands)" ;;
    *) fail "runtime probe reported a source for a non-rename entry (exit $probe_rc)" ;;
esac

log "PASS: C ABI append-only discipline holds"
