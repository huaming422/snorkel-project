## Task

Our file finder keeps a live, watched index and reports each filesystem change to subscribers as an event with a path and a kind.

It has no notion of a file moving: a rename shows up as the old path removed and the new path created, unlinked. So a caller watching the old path never learns where it went, and the path-keyed ranking history that orders results is lost the moment the file moves.

Teach it to understand moves. When a disappearance and an appearance in one batch are really one file moving, recognise and surface it as a single move event rather than two unrelated changes, and carry the path's ranking history across the rename.

Be careful: large event batches are ordinary (bulk checkouts, directory operations, temp-file writes), and mislabeling an unrelated pair, or crossing one file's history onto another, is worse than missing a move. You decide what identifies the same file, when a pairing is unambiguous, and how edge-of-tree moves behave.

The move must surface everywhere the watch API does, across Rust, the C ABI, Python, Node, and Bun, and the TypeScript event type must represent it. Node and Bun decode the C batch at fixed offsets, so its layout is frozen: extend it, but shift nothing already there.

Build and test with the repository's usual commands.

## User stories / requirements

- When a known file is moved to a new name inside the watched tree, the watcher recognises it and reports one move naming both paths, not a vanish-and-reappear pair. A subscriber watching only where the file left still hears the move; a move leaving the tree stays a plain removal exposing no out-of-tree path.
- When a file is renamed, the access-ranking history it built up follows it to the new name, so a file just worked in does not drop to the bottom of results. The history is copied, not moved: the new path inherits the full ranking while the original keeps its own intact.
