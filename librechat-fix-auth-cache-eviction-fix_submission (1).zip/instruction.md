## Task

Security flagged a hole in password resets on OpenID deployments that run with the authenticated-user request cache on. A user resets their password through account recovery, or an admin runs the reset-password script, the reset comes back as done, and an access token issued before it still gets accepted for a few seconds. With the cache off the old token dies on the spot, and the window is worst when Redis is flaky.

By the time a reset reports back, from the recovery flow or the script, tokens from before it have to be dead, whatever state the cache is in.
