function mockPinnedModule(name) {
  globalThis.__verifierModules = globalThis.__verifierModules ?? new Map();
  if (!globalThis.__verifierModules.has(name)) {
    globalThis.__verifierModules.set(name, jest.requireActual(name));
  }
  return globalThis.__verifierModules.get(name);
}

jest.mock('mongoose', () => mockPinnedModule('mongoose'));
jest.mock('@librechat/api', () => mockPinnedModule('@librechat/api'));
jest.mock('@librechat/data-schemas', () => mockPinnedModule('@librechat/data-schemas'));
jest.mock('librechat-data-provider', () => mockPinnedModule('librechat-data-provider'));

const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const { AUTH_USER_DOC_BY_ID_PREFIX, CacheKeys } = require('librechat-data-provider');
const { createMethods, createModels } = require('@librechat/data-schemas');
const {
  cacheConfig,
  buildAuthUserDocCacheKey,
  getCachedAuthUserDoc,
  setCachedAuthUserDoc,
  isTokenIssuedBeforeCredentialChange,
} = require('@librechat/api');

const mockGetLogStores = jest.fn();
const mockPrompts = { email: '', password: '' };
jest.mock('~/cache/getLogStores', () => mockGetLogStores);
jest.mock('~/cache', () => ({ getLogStores: mockGetLogStores, logViolation: jest.fn() }));
jest.mock('readline', () => ({
  createInterface: () => ({
    question: (_query, answer) => answer(mockPrompts.email),
    close: () => undefined,
  }),
}));
jest.mock('../../../config/helpers', () => ({
  askSilentQuestion: async () => mockPrompts.password,
}));
jest.mock('../../../config/connect', () => async () => undefined);

const ISSUER = 'https://issuer.example.com';
const NEW_PASSWORD = 'correct-horse-battery-staple';
const PROMPT_THRESHOLD_MS = 1500;
const WAIT_THRESHOLD_MS = 2000;
const WRONGTYPE = 'WRONGTYPE Operation against a key holding the wrong kind of value';
const READONLY = "READONLY You can't write against a read only replica.";

function isIndexKey(key) {
  return key.startsWith(`${AUTH_USER_DOC_BY_ID_PREFIX}:`);
}

function makeStore() {
  const entries = new Map();
  const store = {
    entries,
    mode: 'healthy',
    async get(key) {
      if (store.mode === 'index-read-fails' && isIndexKey(key)) {
        throw new Error(WRONGTYPE);
      }
      const entry = entries.get(key);
      if (!entry) {
        return undefined;
      }
      if (Date.now() > entry.expiresAt) {
        entries.delete(key);
        return undefined;
      }
      return JSON.parse(entry.value);
    },
    async set(key, value, ttl) {
      if (store.mode === 'read-only') {
        throw new Error(READONLY);
      }
      entries.set(key, { value: JSON.stringify(value), expiresAt: Date.now() + (ttl ?? 60_000) });
      return true;
    },
    async delete(key) {
      if (store.mode === 'read-only') {
        throw new Error(READONLY);
      }
      return entries.delete(key);
    },
  };
  return store;
}

function oldToken() {
  return { iat: Math.floor(Date.now() / 1000) - 60 };
}

function staleTokenRejected(token, cachedUser) {
  return cachedUser === undefined || isTokenIssuedBeforeCredentialChange(token, cachedUser);
}

let mongoServer;
let models;
let methods;
let authStore;
let exitSink;
const fallbackStore = makeStore();
const originalExit = process.exit;
const ORIGINAL_CACHE_MODE = process.env.AUTH_USER_CACHE_MODE;
const ORIGINAL_USE_REDIS = cacheConfig.USE_REDIS;

beforeAll(async () => {
  cacheConfig.USE_REDIS = true;
  mongoServer = await MongoMemoryServer.create();
  await mongoose.connect(mongoServer.getUri());
  models = createModels(mongoose);
  methods = createMethods(mongoose, { getCache: (key) => mockGetLogStores(key) });
  mockGetLogStores.mockImplementation((key) =>
    key === CacheKeys.AUTH_USER_DOC ? authStore : fallbackStore,
  );
  process.exit = jest.fn((code) => {
    exitSink?.(code);
  });
});

afterAll(async () => {
  cacheConfig.USE_REDIS = ORIGINAL_USE_REDIS;
  process.exit = originalExit;
  await mongoose.disconnect();
  await mongoServer.stop();
});

beforeEach(async () => {
  process.env.AUTH_USER_CACHE_MODE = 'on';
  authStore = makeStore();
  await mongoose.connection.dropDatabase();
});

afterEach(() => {
  exitSink = undefined;
  if (ORIGINAL_CACHE_MODE === undefined) {
    delete process.env.AUTH_USER_CACHE_MODE;
  } else {
    process.env.AUTH_USER_CACHE_MODE = ORIGINAL_CACHE_MODE;
  }
});

async function createSignedInUser(email, subject) {
  const created = await methods.createUser(
    { email, name: 'Reset Target', provider: 'openid', openidId: subject, openidIssuer: ISSUER },
    undefined,
    true,
    true,
  );
  const userId = String(created._id);
  await methods.createSession(userId);
  await models.Passkey.create({
    user: userId,
    credentialId: `credential-${subject}`,
    publicKey: Buffer.from('public-key'),
    counter: 0,
    name: 'Laptop',
  });
  const user = await methods.findUser({ openidId: subject });
  const cacheKey = buildAuthUserDocCacheKey({ strategy: 'openid-jwt', subject, issuer: ISSUER });
  await setCachedAuthUserDoc(authStore, cacheKey, user);
  return { userId, email, cacheKey };
}

async function credentialsRemaining(userId) {
  const [sessions, passkeys] = await Promise.all([
    models.Session.countDocuments({ user: userId }),
    models.Passkey.countDocuments({ user: userId }),
  ]);
  return sessions + passkeys;
}

function watchRevocation(userId) {
  const watch = { revokedAt: undefined };
  const timer = setInterval(async () => {
    if (watch.revokedAt !== undefined) {
      return;
    }
    if ((await credentialsRemaining(userId)) === 0 && watch.revokedAt === undefined) {
      watch.revokedAt = Date.now();
    }
  }, 25);
  watch.stop = () => clearInterval(timer);
  return watch;
}

function runCliReset({ email, userId }) {
  mockPrompts.email = email;
  mockPrompts.password = NEW_PASSWORD;
  const watch = watchRevocation(userId);
  const startedAt = Date.now();
  return new Promise((resolve) => {
    exitSink = (code) => {
      exitSink = undefined;
      watch.stop();
      resolve({ code, startedAt, exitedAt: Date.now(), revokedAt: watch.revokedAt });
    };
    jest.isolateModules(() => {
      require('../../../config/reset-password');
    });
  });
}

describe('password reset through the administrator CLI with the authenticated-user cache on', () => {
  test('a reset against a healthy cache exits at once and the old token stops authorizing', async () => {
    const target = await createSignedInUser('target@example.com', 'subject-target');
    const token = oldToken();
    expect(staleTokenRejected(token, await getCachedAuthUserDoc(authStore, target.cacheKey))).toBe(
      false,
    );

    const { code, startedAt, exitedAt } = await runCliReset(target);

    expect(code).toBe(0);
    expect(exitedAt - startedAt).toBeLessThan(PROMPT_THRESHOLD_MS);
    expect(staleTokenRejected(token, await getCachedAuthUserDoc(authStore, target.cacheKey))).toBe(
      true,
    );
    expect(await credentialsRemaining(target.userId)).toBe(0);
  }, 20_000);

  test.each([
    ['the cache index cannot be read', 'index-read-fails'],
    ['the cache rejects every write and delete', 'read-only'],
  ])(
    'a reset completed while %s leaves no pre-reset token authorizing',
    async (_label, mode) => {
      const target = await createSignedInUser('target@example.com', 'subject-target');
      const token = oldToken();
      expect(
        staleTokenRejected(token, await getCachedAuthUserDoc(authStore, target.cacheKey)),
      ).toBe(false);
      authStore.mode = mode;

      const { code, startedAt, exitedAt, revokedAt } = await runCliReset(target);

      expect(code).toBe(0);
      expect(
        staleTokenRejected(token, await getCachedAuthUserDoc(authStore, target.cacheKey)),
      ).toBe(true);
      expect(await credentialsRemaining(target.userId)).toBe(0);
      if (exitedAt - startedAt >= WAIT_THRESHOLD_MS) {
        expect(revokedAt - startedAt).toBeLessThan(PROMPT_THRESHOLD_MS);
      }
    },
    20_000,
  );
});
