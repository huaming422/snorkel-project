import mongoose from 'mongoose';
import { MongoMemoryServer } from 'mongodb-memory-server';
import { AUTH_USER_DOC_BY_ID_PREFIX } from 'librechat-data-provider';
import type * as t from '~/types';
import { createUserMethods } from './user';
import userSchema from '~/schema/user';
import balanceSchema from '~/schema/balance';

const INDEXED_KEYS = ['auth-cache-key-a', 'auth-cache-key-b'];
const PROMPT_THRESHOLD_MS = 1500;
const WRONGTYPE = 'WRONGTYPE Operation against a key holding the wrong kind of value';

function makeCache(indexFor: (key: string) => string[]) {
  return {
    get: jest.fn(async (key: string) => indexFor(key)),
    set: jest.fn().mockResolvedValue(true),
    delete: jest.fn().mockResolvedValue(true),
  };
}

async function timed(fn: () => Promise<unknown>): Promise<number> {
  const start = Date.now();
  await fn();
  return Date.now() - start;
}

let mongoServer: MongoMemoryServer;
let User: mongoose.Model<t.IUser>;
const ORIGINAL_CACHE_MODE = process.env.AUTH_USER_CACHE_MODE;

function restoreCacheMode() {
  if (ORIGINAL_CACHE_MODE === undefined) {
    delete process.env.AUTH_USER_CACHE_MODE;
  } else {
    process.env.AUTH_USER_CACHE_MODE = ORIGINAL_CACHE_MODE;
  }
}

beforeAll(async () => {
  mongoServer = await MongoMemoryServer.create();
  await mongoose.connect(mongoServer.getUri());
  User = mongoose.models.User || mongoose.model<t.IUser>('User', userSchema);
  if (!mongoose.models.Balance) {
    mongoose.model('Balance', balanceSchema);
  }
});

afterAll(async () => {
  await mongoose.disconnect();
  await mongoServer.stop();
});

beforeEach(async () => {
  process.env.AUTH_USER_CACHE_MODE = 'on';
  await mongoose.connection.dropDatabase();
});

afterEach(() => {
  restoreCacheMode();
});

describe('user updates with the authenticated-user cache on', () => {
  test("updating one user never deletes another user's cached entries", async () => {
    const otherIndexKey = `${AUTH_USER_DOC_BY_ID_PREFIX}:other-user`;
    const cache = makeCache((key) => (key === otherIndexKey ? ['other-doc'] : [...INDEXED_KEYS]));
    const methods = createUserMethods(mongoose, { getCache: () => cache });

    const user = await User.create({
      name: 'Target',
      email: 'target@example.com',
      provider: 'openid',
    });
    await methods.updateUser(user._id.toString(), { credentialsChangedAt: new Date() });

    const deleted = cache.delete.mock.calls.map((call: unknown[]) => call[0]);
    expect(deleted).toContain(INDEXED_KEYS[0]);
    expect(deleted).not.toContain(otherIndexKey);
    expect(deleted).not.toContain('other-doc');
  });

  test('an ordinary update neither waits nor fails when the cache is degraded', async () => {
    const cache = makeCache(() => {
      throw new Error(WRONGTYPE);
    });
    const methods = createUserMethods(mongoose, { getCache: () => cache });

    const user = await User.create({
      name: 'Original',
      email: 'best-effort@example.com',
      provider: 'openid',
    });
    let updated: Awaited<ReturnType<typeof methods.updateUser>>;
    const elapsed = await timed(async () => {
      updated = await methods.updateUser(user._id.toString(), { name: 'Renamed' });
    });

    expect(updated?.name).toBe('Renamed');
    expect(elapsed).toBeLessThan(PROMPT_THRESHOLD_MS);
  }, 20_000);
});
