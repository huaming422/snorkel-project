const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const { AUTH_USER_DOC_BY_ID_PREFIX, CacheKeys } = require('librechat-data-provider');
const {
  cacheConfig,
  buildAuthUserDocCacheKey,
  getCachedAuthUserDoc,
  setCachedAuthUserDoc,
  isTokenIssuedBeforeCredentialChange,
} = require('@librechat/api');

const mockGetLogStores = jest.fn();
jest.mock('~/cache/getLogStores', () => mockGetLogStores);
jest.mock('~/cache', () => ({ getLogStores: mockGetLogStores, logViolation: jest.fn() }));
jest.mock('~/models', () => {
  const mongooseInstance = require('mongoose');
  const { createMethods } = require('@librechat/data-schemas');
  return createMethods(mongooseInstance, { getCache: (key) => mockGetLogStores(key) });
});
jest.mock('~/server/services/Config', () => ({ getAppConfig: jest.fn(async () => ({})) }));
jest.mock('~/server/utils', () => ({ sendEmail: jest.fn() }));
jest.mock('~/server/services/GraphTokenService', () => ({ getGraphApiToken: jest.fn() }));
jest.mock('~/server/services/RefreshTokenBridge', () => ({ getRefreshTokenBridge: jest.fn() }));
jest.mock('~/server/services/OpenIDRefreshRecovery', () => ({
  recoverOpenIDRefreshBridge: jest.fn(),
  refreshOpenIDUser: jest.fn(),
  sendOpenIDAuthResponse: jest.fn(),
}));
jest.mock('~/server/services/OpenIDRefreshFlight', () => ({
  assertOpenIDRefreshFlightDeliveryAvailable: jest.fn(),
  assertOpenIDRefreshSessionGenerationAvailable: jest.fn(),
  claimOpenIDRefreshFlightDelivery: jest.fn(),
  releaseOpenIDRefreshFlightDelivery: jest.fn(),
}));

const ISSUER = 'https://issuer.example.com';
const NEW_PASSWORD = 'correct-horse-battery-staple';
const PROMPT_THRESHOLD_MS = 1500;
const WAIT_THRESHOLD_MS = 2000;
const WRONGTYPE = 'WRONGTYPE Operation against a key holding the wrong kind of value';
const READONLY = "READONLY You can't write against a read only replica.";

function isIndexKey(key) {
  return key.startsWith(`${AUTH_USER_DOC_BY_ID_PREFIX}:`);
}

function makeStore() {
  const entries = new Map();
  const store = {
    entries,
    mode: 'healthy',
    async get(key) {
      if (store.mode === 'index-read-fails' && isIndexKey(key)) {
        throw new Error(WRONGTYPE);
      }
      const entry = entries.get(key);
      if (!entry) {
        return undefined;
      }
      if (Date.now() > entry.expiresAt) {
        entries.delete(key);
        return undefined;
      }
      return JSON.parse(entry.value);
    },
    async set(key, value, ttl) {
      if (store.mode === 'read-only') {
        throw new Error(READONLY);
      }
      if (store.mode === 'index-write-fails' && isIndexKey(key)) {
        throw new Error(READONLY);
      }
      entries.set(key, { value: JSON.stringify(value), expiresAt: Date.now() + (ttl ?? 60_000) });
      return true;
    },
    async delete(key) {
      if (store.mode === 'read-only') {
        throw new Error(READONLY);
      }
      return entries.delete(key);
    },
  };
  return store;
}

function makeResponse() {
  const res = {
    respondedAt: undefined,
    status: jest.fn(() => {
      res.respondedAt = res.respondedAt ?? Date.now();
      return res;
    }),
    json: jest.fn(() => res),
  };
  return res;
}

function oldToken() {
  return { iat: Math.floor(Date.now() / 1000) - 60 };
}

function staleTokenRejected(token, cachedUser) {
  return cachedUser === undefined || isTokenIssuedBeforeCredentialChange(token, cachedUser);
}

let mongoServer;
let models;
let methods;
let AuthService;
let resetPasswordController;
let authStore;
const fallbackStore = makeStore();
const ORIGINAL_CACHE_MODE = process.env.AUTH_USER_CACHE_MODE;
const ORIGINAL_USE_REDIS = cacheConfig.USE_REDIS;

beforeAll(async () => {
  cacheConfig.USE_REDIS = true;
  mongoServer = await MongoMemoryServer.create();
  await mongoose.connect(mongoServer.getUri());
  models = require('~/db/models');
  methods = require('~/models');
  mockGetLogStores.mockImplementation((key) =>
    key === CacheKeys.AUTH_USER_DOC ? authStore : fallbackStore,
  );
  AuthService = require('~/server/services/AuthService');
  ({ resetPasswordController } = require('~/server/controllers/AuthController'));
});

afterAll(async () => {
  cacheConfig.USE_REDIS = ORIGINAL_USE_REDIS;
  await mongoose.disconnect();
  await mongoServer.stop();
});

beforeEach(async () => {
  process.env.AUTH_USER_CACHE_MODE = 'on';
  authStore = makeStore();
  await mongoose.connection.dropDatabase();
});

afterEach(() => {
  if (ORIGINAL_CACHE_MODE === undefined) {
    delete process.env.AUTH_USER_CACHE_MODE;
  } else {
    process.env.AUTH_USER_CACHE_MODE = ORIGINAL_CACHE_MODE;
  }
});

async function createSignedInUser(email, subject) {
  const created = await methods.createUser(
    { email, name: 'Reset Target', provider: 'openid', openidId: subject, openidIssuer: ISSUER },
    undefined,
    true,
    true,
  );
  const userId = String(created._id);
  await methods.createSession(userId);
  await models.Passkey.create({
    user: userId,
    credentialId: `credential-${subject}`,
    publicKey: Buffer.from('public-key'),
    counter: 0,
    name: 'Laptop',
  });
  const user = await methods.findUser({ openidId: subject });
  const cacheKey = buildAuthUserDocCacheKey({ strategy: 'openid-jwt', subject, issuer: ISSUER });
  await setCachedAuthUserDoc(authStore, cacheKey, user);
  return { userId, email, cacheKey };
}

async function mintResetToken(email) {
  const result = await AuthService.requestPasswordReset({ body: { email }, ip: '127.0.0.1' });
  const match = /token=([^&]+)&userId=([^&]+)/.exec(String(result.link));
  if (!match) {
    throw new Error(`no reset link issued: ${JSON.stringify(result)}`);
  }
  return { token: match[1], userId: match[2] };
}

async function credentialsRemaining(userId) {
  const [sessions, passkeys] = await Promise.all([
    models.Session.countDocuments({ user: userId }),
    models.Passkey.countDocuments({ user: userId }),
  ]);
  return sessions + passkeys;
}

function watchRevocation(userId) {
  const watch = { revokedAt: undefined };
  const timer = setInterval(async () => {
    if (watch.revokedAt !== undefined) {
      return;
    }
    if ((await credentialsRemaining(userId)) === 0 && watch.revokedAt === undefined) {
      watch.revokedAt = Date.now();
    }
  }, 25);
  watch.stop = () => clearInterval(timer);
  return watch;
}

async function runReset({ token, userId }) {
  const res = makeResponse();
  const watch = watchRevocation(userId);
  const startedAt = Date.now();
  try {
    await resetPasswordController({ body: { userId, token, password: NEW_PASSWORD } }, res);
  } finally {
    watch.stop();
  }
  return { res, startedAt, revokedAt: watch.revokedAt, respondedAt: res.respondedAt };
}

describe('password reset through the web controller with the authenticated-user cache on', () => {
  test('a reset against a healthy cache is confirmed at once and the old token stops authorizing', async () => {
    const target = await createSignedInUser('target@example.com', 'subject-target');
    const other = await createSignedInUser('other@example.com', 'subject-other');
    const token = oldToken();
    expect(staleTokenRejected(token, await getCachedAuthUserDoc(authStore, target.cacheKey))).toBe(
      false,
    );

    const { res, startedAt, respondedAt } = await runReset(await mintResetToken(target.email));

    expect(res.status).toHaveBeenCalledWith(200);
    expect(respondedAt - startedAt).toBeLessThan(PROMPT_THRESHOLD_MS);
    expect(staleTokenRejected(token, await getCachedAuthUserDoc(authStore, target.cacheKey))).toBe(
      true,
    );
    expect(await credentialsRemaining(target.userId)).toBe(0);
    expect(await getCachedAuthUserDoc(authStore, other.cacheKey)).toMatchObject({
      email: other.email,
    });
    expect(await authStore.get(`${AUTH_USER_DOC_BY_ID_PREFIX}:${other.userId}`)).toEqual([
      other.cacheKey,
    ]);
    expect(await credentialsRemaining(other.userId)).toBe(2);
  }, 20_000);

  test.each([
    ['the cache index cannot be read', 'index-read-fails'],
    ['the cache rejects every write and delete', 'read-only'],
  ])(
    'a reset confirmed while %s leaves no pre-reset token authorizing',
    async (_label, mode) => {
      const target = await createSignedInUser('target@example.com', 'subject-target');
      const token = oldToken();
      expect(
        staleTokenRejected(token, await getCachedAuthUserDoc(authStore, target.cacheKey)),
      ).toBe(false);
      const reset = await mintResetToken(target.email);
      authStore.mode = mode;

      const { startedAt, revokedAt, respondedAt } = await runReset(reset);

      expect(
        staleTokenRejected(token, await getCachedAuthUserDoc(authStore, target.cacheKey)),
      ).toBe(true);
      expect(await credentialsRemaining(target.userId)).toBe(0);
      if (respondedAt - startedAt >= WAIT_THRESHOLD_MS) {
        expect(revokedAt - startedAt).toBeLessThan(PROMPT_THRESHOLD_MS);
      }
    },
    20_000,
  );

  test('a cached document whose index entry could not be written does not outlive a reset', async () => {
    authStore.mode = 'index-write-fails';
    const target = await createSignedInUser('target@example.com', 'subject-target');
    authStore.mode = 'healthy';
    const token = oldToken();

    await runReset(await mintResetToken(target.email));

    expect(staleTokenRejected(token, await getCachedAuthUserDoc(authStore, target.cacheKey))).toBe(
      true,
    );
  }, 20_000);

  test('a rejected reset neither revokes credentials nor waits', async () => {
    const target = await createSignedInUser('target@example.com', 'subject-target');
    authStore.mode = 'read-only';

    const { res, startedAt, respondedAt } = await runReset({
      token: 'not-the-token',
      userId: target.userId,
    });

    expect(res.status).toHaveBeenCalledWith(400);
    expect(respondedAt - startedAt).toBeLessThan(PROMPT_THRESHOLD_MS);
    expect(await credentialsRemaining(target.userId)).toBe(2);
  });
});
