#!/usr/bin/env bash
# test-setup.sh — environment bootstrap for the verifier.
#
# LibreChat is an npm-workspaces monorepo. The verifier imports from three
# built workspace packages — librechat-data-provider, @librechat/data-schemas,
# and @librechat/api — whose `dist/` dirs are produced by `tsc`. The image
# build already ran `npm ci` and built all three at bake time, and the
# ~122MB mongodb-memory-server binary is prewarmed. Here we only rebuild the
# packages the agent may have edited so their `dist/` reflects the submission;
# turbo/tsc incremental output makes this a near no-op when nothing changed.
#
# Sourced (not exec'd) by the harbor runner so any env vars set here stay live
# for the verifier subprocess.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/LibreChat}"
export REPO_DIR
cd "$REPO_DIR"

# The agent phase is offline; the verifier phase has limited (gateway-only)
# network. Everything the verifier needs to build/run the focused tests is
# already baked into node_modules at image time. Make npm fail fast instead of
# hanging against a network it cannot reach for package installs.
export npm_config_audit=false
export npm_config_fund=false

# mongodb-memory-server binary handoff. The image prebakes the ~200MB mongod
# binary at bake time by calling MongoBinary.getPath({}) from the repo root, which
# lands it under node_modules/.cache/mongodb-memory-server/mongod-<arch>-ubuntu-<ver>.
# But the barrier verifier runs from packages/data-schemas, where MMS recomputes
# its download dir and resolves to ~/.cache/mongodb-binaries/ instead — missing the
# prebaked copy, it would fall back to downloading from fastdl.mongodb.org, which
# fails under the cut network. Point MMS straight at the prebaked binary so every
# MongoMemoryServer.create() reuses it with no download. The filename is
# arch-specific (x86_64 on Modal, arm64 locally), so glob rather than hardcode.
MONGOMS_PREBAKED_BINARY="$(ls "$REPO_DIR"/node_modules/.cache/mongodb-memory-server/mongod-* 2>/dev/null | head -n1 || true)"
if [ -n "$MONGOMS_PREBAKED_BINARY" ] && [ -x "$MONGOMS_PREBAKED_BINARY" ]; then
    export MONGOMS_SYSTEM_BINARY="$MONGOMS_PREBAKED_BINARY"
    echo "test-setup.sh: MONGOMS_SYSTEM_BINARY=$MONGOMS_SYSTEM_BINARY"
else
    echo "test-setup.sh: prebaked mongod binary not found under" \
         "$REPO_DIR/node_modules/.cache/mongodb-memory-server/ — MMS tests will try" \
         "to download and fail offline. The image build is likely corrupt." >&2
    exit 1
fi

# Verifier-runner note: the harbor runner shells out to run_verify.py +
# runners/js.py through $VERIFIER_PYTHON — the isolated /opt/tooling/venv
# interpreter baked by the image (Python 3.12), which has `tomllib` in its
# standard library. verify.toml parsing therefore needs no `tomli` shim here;
# test-setup.sh must never reach the package index for it.

# Sanity: jest must be resolvable from the workspace root. A failure here points
# at a corrupt node_modules — bail loudly rather than emit a confusing
# "jest: not found" later. We do NOT attempt a network reinstall (offline).
if ! [ -x node_modules/.bin/jest ]; then
    echo "test-setup.sh: jest binary missing from node_modules/.bin/." \
         "The image build is corrupt (node_modules not baked)." >&2
    exit 1
fi

# Rebuild the three workspace packages the verifier imports so dist/ reflects
# any source changes the agent made. tsc/turbo incremental builds make this a
# few seconds when nothing changed and only do real work on edited packages.
# These must resolve entirely from the prebaked node_modules (offline).
echo "test-setup.sh: rebuilding workspace packages (data-provider, data-schemas, api)..."
npm run build:data-provider
npm run build:data-schemas
npm run build:api

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR node=$(node --version) jest=$(node_modules/.bin/jest --version 2>/dev/null || echo unknown)"
