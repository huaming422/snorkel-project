// Parquet scans with filter pushdown: row groups whose statistics prove that
// every row matches the predicate must skip per-row predicate evaluation,
// page index pruning must keep working for the row groups that need it, and
// query results stay the same.
//
// This file is compiled as an integration test against the public `datafusion`
// API. It observes the scan through pre-existing metrics
// (`predicate_cache_inner_records`, `row_groups_pruned_statistics`), through
// the rows the scan returns, and through the SQL path.
//
// Most fixtures are one Int32 column `a` with a filter `a >= 3`, written as
// row groups of three rows and data pages of two rows:
//   [1, 2, 3]  not fully matched (1 and 2 fail the filter)
//   [4, 5, 6]  fully matched (row-group minimum is 4)
//   [7, 1, 2]  not fully matched

use arrow::array::{ArrayRef, AsArray, Int32Array};
use arrow::datatypes::Int32Type;
use arrow::record_batch::RecordBatch;
use datafusion::physical_plan::{collect, displayable, ExecutionPlan};
use datafusion::physical_plan::metrics::{MetricValue, MetricsSet};
use datafusion::prelude::{
    col, lit, Expr, ParquetReadOptions, SessionContext,
};
use datafusion::test_util::parquet::{ParquetScanOptions, TestParquetFile};
use parquet::file::metadata::ParquetMetaDataReader;
use parquet::file::properties::{EnabledStatistics, WriterProperties};
use std::sync::Arc;
use tempfile::TempDir;

// ---------------------------------------------------------------------------
// Fixture helpers
// ---------------------------------------------------------------------------

/// Writer properties that force multiple small data pages (so page-index work
/// is measurable) and page-level statistics (so page pruning has something to
/// evaluate). `max_rg` controls row-group splitting within the single batch.
fn props(max_rg: usize) -> WriterProperties {
    WriterProperties::builder()
        .set_max_row_group_row_count(Some(max_rg))
        .set_statistics_enabled(EnabledStatistics::Page)
        .set_data_page_row_count_limit(2)
        .set_write_batch_size(2)
        .build()
}

/// Build a one-column (`a: Int32`) parquet file from `values`, splitting into
/// row groups of at most `max_rg` rows.
fn write_single_col(dir: &TempDir, name: &str, values: &[i32], max_rg: usize) -> TestParquetFile {
    let a: ArrayRef = Arc::new(Int32Array::from(values.to_vec()));
    let batch = RecordBatch::try_from_iter(vec![("a", a)]).unwrap();
    TestParquetFile::try_new(dir.path().join(name), props(max_rg), vec![batch]).unwrap()
}

/// Build a two-column (`a`, `b`: Int32) parquet file; `b[i] == a[i]`.
fn write_two_col(dir: &TempDir, name: &str, values: &[i32], max_rg: usize) -> TestParquetFile {
    let a: ArrayRef = Arc::new(Int32Array::from(values.to_vec()));
    let b: ArrayRef = Arc::new(Int32Array::from(values.to_vec()));
    let batch = RecordBatch::try_from_iter(vec![("a", a), ("b", b)]).unwrap();
    TestParquetFile::try_new(dir.path().join(name), props(max_rg), vec![batch]).unwrap()
}

/// Rewrite the page index of a single-column file so that the first data page
/// of row group `rg` reports `new_max` as its maximum instead of `old_max`.
/// The data and the row-group statistics are left untouched, so the file's
/// rows and its row-group min/max stay the same; only a reader that consults
/// the page index sees the changed value.
fn rewrite_first_page_max(file: &TestParquetFile, rg: usize, old_max: i32, new_max: i32) {
    let path = file.path();
    let metadata = ParquetMetaDataReader::new()
        .parse_and_finish(&std::fs::File::open(path).unwrap())
        .unwrap();
    let chunk = metadata.row_group(rg).column(0);
    let start = chunk.column_index_offset().expect("column index written") as usize;
    let len = chunk.column_index_length().expect("column index written") as usize;

    // An INT32 page maximum is stored as a length-prefixed (4) little-endian
    // binary value inside the column index.
    let mut old = vec![4u8];
    old.extend_from_slice(&old_max.to_le_bytes());
    let mut new = vec![4u8];
    new.extend_from_slice(&new_max.to_le_bytes());

    let mut bytes = std::fs::read(path).unwrap();
    let region = &mut bytes[start..start + len];
    let hits: Vec<usize> = region
        .windows(old.len())
        .enumerate()
        .filter(|(_, w)| *w == old.as_slice())
        .map(|(i, _)| i)
        .collect();
    assert_eq!(
        hits.len(),
        1,
        "expected exactly one page maximum of {old_max} in the column index of row group {rg}"
    );
    region[hits[0]..hits[0] + new.len()].copy_from_slice(&new);
    std::fs::write(path, bytes).unwrap();
}

fn scan_opts(pushdown: bool, page_index: bool) -> ParquetScanOptions {
    ParquetScanOptions {
        pushdown_filters: pushdown,
        reorder_filters: false,
        enable_page_index: page_index,
    }
}

/// Run a physical scan of `file` with `filter`, returning the collected rows and
/// the parquet node's metrics. Mirrors `tests/parquet/filter_pushdown.rs`.
async fn scan_with_metrics(
    file: &TestParquetFile,
    filter: &Expr,
    opts: ParquetScanOptions,
) -> (Vec<RecordBatch>, MetricsSet) {
    let ctx = SessionContext::new_with_config(opts.config());
    let exec = file.create_scan(&ctx, Some(filter.clone())).await.unwrap();
    let result = collect(exec.clone(), ctx.task_ctx()).await.unwrap();
    let metrics = TestParquetFile::parquet_metrics(&exec).expect("found parquet metrics");
    (result, metrics)
}

/// `fully_matched()` count for a `PruningMetrics` metric.
fn pruning_fully_matched(metrics: &MetricsSet, name: &str) -> usize {
    match metrics.sum_by_name(name) {
        Some(MetricValue::PruningMetrics { pruning_metrics, .. }) => pruning_metrics.fully_matched(),
        Some(other) => panic!("metric '{name}' is not a PruningMetrics: {other:?}"),
        None => panic!("metric '{name}' not found in\n\n{metrics:#?}"),
    }
}

/// `usize` value of a `Gauge` metric (pre-existing metrics like
/// `predicate_cache_inner_records` are stored as gauges, not counts).
fn gauge_value(metrics: &MetricsSet, name: &str) -> usize {
    match metrics.sum_by_name(name) {
        Some(MetricValue::Gauge { gauge, .. }) => gauge.value() as usize,
        Some(other) => panic!("metric '{name}' is not a Gauge: {other:?}"),
        None => panic!("metric '{name}' not found in\n\n{metrics:#?}"),
    }
}

/// Flatten column `col_idx` of a batch list into a `Vec<i32>` (no nulls).
fn column_i32(batches: &[RecordBatch], col_idx: usize) -> Vec<i32> {
    let mut out = Vec::new();
    for b in batches {
        let a = b.column(col_idx).as_primitive::<Int32Type>();
        for i in 0..a.len() {
            out.push(a.value(i));
        }
    }
    out
}

fn sorted(mut v: Vec<i32>) -> Vec<i32> {
    v.sort();
    v
}

/// Register `file` as `table` in a context configured with `opts`, run `sql`,
/// and return column 0 of the result as a `Vec<i32>` (in the query's row order).
async fn sql_col0(file: &TestParquetFile, table: &str, sql: &str, opts: ParquetScanOptions) -> Vec<i32> {
    let ctx = SessionContext::new_with_config(opts.config());
    let path = file.path().to_str().unwrap().to_string();
    ctx.register_parquet(table, &path, ParquetReadOptions::default())
        .await
        .unwrap();
    let df = ctx.sql(sql).await.unwrap();
    let batches = df.collect().await.unwrap();
    column_i32(&batches, 0)
}

// ---------------------------------------------------------------------------
// Per-row predicate evaluation is skipped for a fully matched row group, even
// when the same file holds a row group that still needs filtering.
//
// `predicate_cache_inner_records` counts the rows that went through predicate
// evaluation. On the mixed file [1,2,3] + [4,5,6] it reads 6 when both groups
// are evaluated. Skipping the fully matched group leaves it below 6: 3 when the
// metric is shared across the whole file, 0 when each part of the scan reports
// its own value and the last one written covers the skipped group. Skipping the
// predicate only when every group of the file is fully matched leaves it at 6.
// The control file proves the metric is live.
// ---------------------------------------------------------------------------
#[tokio::test]
async fn row_filter_skipped_for_fully_matched_row_group() {
    let dir = TempDir::new_in(".").unwrap();
    let opts = scan_opts(true, true);
    let filter = col("a").gt_eq(lit(3));

    // Control: one row group [1,2,3], not fully matched.
    let control = write_single_col(&dir, "rf_control.parquet", &[1, 2, 3], 1024);
    let (c_rows, c_metrics) = scan_with_metrics(&control, &filter, opts).await;
    let control_cache = gauge_value(&c_metrics, "predicate_cache_inner_records");
    assert!(
        control_cache > 0,
        "predicate evaluation is not visible on the control file: \
         predicate_cache_inner_records==0. Metrics:\n{c_metrics:#?}"
    );
    assert_eq!(sorted(column_i32(&c_rows, 0)), vec![3]);

    // Mixed file: [1,2,3] needs filtering, [4,5,6] is fully matched.
    let mixed = write_single_col(&dir, "rf_mixed.parquet", &[1, 2, 3, 4, 5, 6], 3);
    let (m_rows, m_metrics) = scan_with_metrics(&mixed, &filter, opts).await;
    let mixed_cache = gauge_value(&m_metrics, "predicate_cache_inner_records");
    assert!(
        mixed_cache < 6,
        "the fully matched row group [4,5,6] still had the predicate evaluated \
         row by row (predicate_cache_inner_records={mixed_cache}, expected < 6). \
         Metrics:\n{m_metrics:#?}"
    );
    assert_eq!(sorted(column_i32(&m_rows, 0)), vec![3, 4, 5, 6]);
}

// ---------------------------------------------------------------------------
// Page index pruning still runs for a row group that needs filtering when the
// same file also holds a fully matched row group.
//
// File: [2,3,4] (not fully matched, pages [2,3] [4]) then [4,5,6] (fully
// matched). The page index of the first group is rewritten so that its first
// page claims a maximum of 2, which `a >= 3` rules out. The rows and the
// row-group statistics are unchanged, so the rewrite is visible only to a scan
// that consults the page index for that group: it drops page [2,3], and the
// scan returns [4, 4, 5, 6]. A scan that stops using the page index for this
// file returns [3, 4, 4, 5, 6].
// ---------------------------------------------------------------------------
#[tokio::test]
async fn page_index_still_used_beside_fully_matched_row_group() {
    let dir = TempDir::new_in(".").unwrap();
    let filter = col("a").gt_eq(lit(3));
    let opts = scan_opts(true, true);

    let file = write_single_col(&dir, "pi_mixed.parquet", &[2, 3, 4, 4, 5, 6], 3);
    rewrite_first_page_max(&file, 0, 3, 2);
    let (rows, metrics) = scan_with_metrics(&file, &filter, opts).await;
    let got = sorted(column_i32(&rows, 0));
    assert_eq!(
        got,
        vec![4, 4, 5, 6],
        "the page index was not used for the row group [2,3,4], which is not \
         fully matched, in a file that also holds a fully matched row group. \
         Metrics:\n{metrics:#?}"
    );
}

// ---------------------------------------------------------------------------
// Query results are the same with and without pushdown, and match the
// expected rows, for several predicates over a file with one fully matched
// row group.
// ---------------------------------------------------------------------------
#[tokio::test]
async fn results_identical_with_and_without_pushdown() {
    let dir = TempDir::new_in(".").unwrap();
    let file = write_single_col(&dir, "results.parquet", &[1, 2, 3, 4, 5, 6, 7, 1, 2], 3);

    let cases: Vec<(Expr, Vec<i32>)> = vec![
        (col("a").gt_eq(lit(3)), vec![3, 4, 5, 6, 7]),
        (col("a").gt(lit(4)), vec![5, 6, 7]),
        (col("a").lt(lit(3)), vec![1, 1, 2, 2]),
        (col("a").eq(lit(2)), vec![2, 2]),
    ];

    for (filter, expected) in cases {
        let (rows_pd, _m1) = scan_with_metrics(&file, &filter, scan_opts(true, true)).await;
        let (rows_no, _m2) = scan_with_metrics(&file, &filter, scan_opts(false, false)).await;
        let got_pd = sorted(column_i32(&rows_pd, 0));
        let got_no = sorted(column_i32(&rows_no, 0));
        assert_eq!(got_pd, expected, "pushdown result mismatch for {filter:?}");
        assert_eq!(
            got_pd, got_no,
            "pushdown vs no-pushdown results diverged for {filter:?}"
        );
    }
}

// ---------------------------------------------------------------------------
// A LIMIT holds across the whole scan when a fully matched row group sits
// between row groups that need filtering, both when the limit is handed to the
// scan itself and when it sits on top of a sort.
// ---------------------------------------------------------------------------
#[tokio::test]
async fn global_limit_enforced_across_split_scan() {
    let dir = TempDir::new_in(".").unwrap();
    let file = write_single_col(&dir, "limit.parquet", &[1, 2, 3, 4, 5, 6, 7, 1, 2], 3);

    let got = sql_col0(
        &file,
        "t_limit",
        "SELECT a FROM t_limit WHERE a >= 3 LIMIT 4",
        scan_opts(true, true),
    )
    .await;
    assert_eq!(got.len(), 4, "LIMIT 4 returned {got:?}");
    assert!(
        got.iter().all(|v| *v >= 3),
        "LIMIT 4 returned rows that fail the filter: {got:?}"
    );

    let got = sql_col0(
        &file,
        "t_limit",
        "SELECT a FROM t_limit WHERE a >= 3 ORDER BY a LIMIT 4",
        scan_opts(true, true),
    )
    .await;
    assert_eq!(
        got,
        vec![3, 4, 5, 6],
        "ORDER BY a LIMIT 4 over a file with a fully matched row group returned the wrong rows"
    );
}

// ---------------------------------------------------------------------------
// A scan that reads row groups last to first keeps doing so when some of the
// row groups are fully matched.
//
// The file is sorted on `a` and declared `WITH ORDER (a ASC)`, so
// `ORDER BY a DESC` plans a reversed Parquet scan. Row groups [1,2,3] (needs
// filtering), [4,5,6] and [7,8,9] (both fully matched) must come out of the
// scan as [7,8,9], [4,5,6], [3]: the order of the row groups is reversed, the
// order of rows inside a group is not.
// ---------------------------------------------------------------------------
fn find_parquet_scan(plan: &Arc<dyn ExecutionPlan>) -> Option<Arc<dyn ExecutionPlan>> {
    if plan.name() == "DataSourceExec" {
        return Some(Arc::clone(plan));
    }
    plan.children().into_iter().find_map(find_parquet_scan)
}

#[tokio::test]
async fn reverse_order_preserved_across_split_scan() {
    let dir = TempDir::new_in(".").unwrap();
    let file = write_single_col(&dir, "reverse.parquet", &[1, 2, 3, 4, 5, 6, 7, 8, 9], 3);
    let config = scan_opts(true, true)
        .config()
        .set_bool("datafusion.optimizer.enable_sort_pushdown", true);
    let ctx = SessionContext::new_with_config(config);
    ctx.sql(&format!(
        "CREATE EXTERNAL TABLE t_rev (a INT) STORED AS PARQUET LOCATION '{}' WITH ORDER (a ASC)",
        file.path().to_str().unwrap()
    ))
    .await
    .unwrap();

    let sql = "SELECT a FROM t_rev WHERE a >= 3 ORDER BY a DESC";
    let got = column_i32(&ctx.sql(sql).await.unwrap().collect().await.unwrap(), 0);
    assert_eq!(
        got,
        vec![9, 8, 7, 6, 5, 4, 3],
        "descending query did not return rows in descending order"
    );

    let plan = ctx.sql(sql).await.unwrap().create_physical_plan().await.unwrap();
    let scan = find_parquet_scan(&plan).expect("plan has a Parquet scan");
    let shown = displayable(scan.as_ref()).one_line().to_string();
    assert!(
        shown.contains("reverse_row_groups=true"),
        "expected a reversed Parquet scan for this query, got: {shown}"
    );
    let scanned = column_i32(&collect(scan, ctx.task_ctx()).await.unwrap(), 0);
    assert_eq!(
        scanned,
        vec![7, 8, 9, 4, 5, 6, 3],
        "the reversed scan did not emit row groups last to first"
    );
}

// ---------------------------------------------------------------------------
// A predicate over two columns does not panic and returns the right rows.
// ---------------------------------------------------------------------------
#[tokio::test]
async fn multi_column_page_predicate_does_not_panic() {
    let dir = TempDir::new_in(".").unwrap();
    let file = write_two_col(&dir, "multicol.parquet", &[1, 2, 3, 4, 5, 6, 7, 1, 2], 3);
    let got = sql_col0(
        &file,
        "t_mc",
        "SELECT a FROM t_mc WHERE a >= 3 AND b >= 3 ORDER BY a",
        scan_opts(true, true),
    )
    .await;
    assert_eq!(
        got,
        vec![3, 4, 5, 6, 7],
        "multi-column predicate scan returned wrong rows (or the scan panicked)"
    );
}

// ---------------------------------------------------------------------------
// Row-group statistics still report exactly one fully matched row group.
// ---------------------------------------------------------------------------
#[tokio::test]
async fn fully_matched_detection_still_works() {
    let dir = TempDir::new_in(".").unwrap();
    let file = write_single_col(&dir, "detect.parquet", &[1, 2, 3, 4, 5, 6, 7, 1, 2], 3);
    let filter = col("a").gt_eq(lit(3));
    let (_rows, metrics) = scan_with_metrics(&file, &filter, scan_opts(true, true)).await;
    let fully_matched = pruning_fully_matched(&metrics, "row_groups_pruned_statistics");
    assert_eq!(
        fully_matched, 1,
        "row_groups_pruned_statistics.fully_matched()={fully_matched}, expected 1. \
         Metrics:\n{metrics:#?}"
    );
}
