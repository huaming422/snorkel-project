#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# Rust / cargo task: the image baked the crate registry at the base commit via
# `cargo fetch --locked`, so dependency resolution must be satisfiable fully
# offline. Force cargo offline right away so a cache miss fails fast here (and
# in the smoke gate's `docker run --network none` offline fold) instead of
# silently reaching crates.io.
cd /repo/datafusion

export CARGO_NET_OFFLINE=true

# Dependency closure: offline-first against the image bake, logged online
# fallback. `cargo fetch --locked` is a no-op when the registry cache is warm.
if cargo fetch --locked > /tmp/test-setup-fetch.log 2>&1; then
    echo "[offline-first] cargo registry satisfied from image"
elif cargo fetch >> /tmp/test-setup-fetch.log 2>&1; then
    echo "[test-setup] cargo deps fetched online (image bake was stale)"
else
    tail -40 /tmp/test-setup-fetch.log >&2; exit 1
fi

# No services to start and no data to seed: the verifier builds and runs focused
# cargo tests in-process against in-memory parquet fixtures. Assertion logic
# lives in the verifier, not here.
