## Task

Filtered scans of Parquet tables with filter pushdown enabled have become about twice as slow as they should be, and the extra time does not go down as the filter keeps more of the rows. Bring the scan time back down. Callers depend on the results as they are now: the same rows, the same order from ordered scans, and a LIMIT that still caps the whole result.
