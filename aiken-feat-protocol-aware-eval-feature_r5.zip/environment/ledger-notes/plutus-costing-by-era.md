# Plutus costing by ledger era

Notes on how execution budgets change across Cardano protocol versions.
"Protocol" below always means the protocol major version. Anything these notes
do not list is the same in every era.

## Eras

| Era        | First protocol |
|------------|----------------|
| Chang      | 9              |
| Van Rossem | 11             |

PlutusV1 and PlutusV2 run in every era. PlutusV3 runs from Chang on. A protocol
after Van Rossem follows the Van Rossem rules until a later era says otherwise.

## Reading a cost vector

A ledger cost vector is a flat list of integers, the parameters of each
builtin's cost functions. The parameters keep their names and positions from
era to era; what changes is the function they feed. In the formulas, `x` and
`y` are the sizes of the first and second arguments, and `intercept`, `slope`
and `constant` are the builtin's own parameters for that cost.

These rules describe how the ledger reads a cost vector.

### multiplyInteger, CPU

- Before Chang: `intercept + slope * (x + y)`
- From Chang on: `intercept + slope * x * y`

### divideInteger and modInteger, CPU

Each language has its own size model for these builtins, and that model does
not change.

- Before Van Rossem: `constant` when `x < y`, otherwise the size model at
  `(x, y)`
- From Van Rossem on: the size model at `(max(x, y), min(x, y))`, with no
  constant

### modInteger and remainderInteger, memory, PlutusV1 and PlutusV2

- Before Van Rossem: `intercept + slope * max(minimum, x - y)`
- From Van Rossem on: `intercept + slope * y`

## The PlutusV3 vector under Van Rossem

The vector grows from 297 entries to 350. Every existing entry stays at its
position and the new ones follow, for builtins newer than the ones in today's
vector. A reader takes the entries it knows and ignores any that follow them,
so a later era can append more. A PlutusV3 vector always has at least its first
251 entries.

## Size of a string

A string's memory size is a property of the value, not of a cost parameter.

- Before Van Rossem: its number of Unicode characters
- From Van Rossem on: its UTF-8 length in bytes divided by 4, rounded up, so 0
  for the empty string
