## Task

`uplc` can be told which Plutus language version a script targets, but not which Cardano protocol era it runs under. The ledger changes how some builtins are costed from one era to the next, so a script evaluated with the right language version can still come back with a different execution budget than it really has on chain.

`uplc` itself needs a way to run a program at an explicit protocol major version, for all three Plutus languages, with its built-in default costs or with a ledger cost vector the caller supplies. The ledger's costing rules for each era are written up in `/opt/ledger-notes/plutus-costing-by-era.md`, and that file is the source for every era boundary and every number; nothing in this repo carries them. Language-only evaluation stays as it is, phase-two transaction evaluation included: same signatures, and same results with the default costs and with any cost vector no longer than today's. The crate's existing tests keep passing.

## User stories / requirements

- With a supplied cost vector, evaluating at an explicit protocol major version follows that era's costing for every Plutus language, so the same program and vector can cost differently before Chang, after it and from Van Rossem on, while a protocol whose rules match today's gives exactly the language-only result.
- Under Van Rossem, a PlutusV3 cost vector of any length from today's up still costs every builtin whose entries it carries, while a vector that stops short of a builtin's entries leaves it at the unavailable cost, so running it fails.
- From Van Rossem on, strings are sized by that era's rule in every builtin whose cost depends on a string's size, for every Plutus language and with either kind of costs, while earlier protocols and language-only evaluation keep today's sizing.
