"""Build and regression checks for the `uplc` crate.

Three checks run here: the `uplc` crate must still compile; the crate's
existing unit, integration and doc tests must still pass; and language-only
evaluation, phase-two transaction evaluation included, keeps its signatures and
its results. All three drive pre-existing interfaces only and name no new
symbol.

Runs under VERIFIER_PYTHON (no repository imports) and shells out to cargo.
The cargo toolchain and a warm offline target dir come from the image and
tests/test-setup.sh.
"""

from __future__ import annotations

import os
import re
import subprocess
from contextlib import contextmanager
from pathlib import Path

import pytest

REPO_DIR = Path(f"/repo/{os.environ.get('REPO_NAME', 'aiken')}")

# Offline: the image holds the full dependency closure and test-setup.sh warmed
# the target dir. A cache miss should fail fast rather than hang without a network.
_CARGO_ENV = {**os.environ, "CARGO_NET_OFFLINE": "true"}


def _run_cargo(*args: str, timeout: int = 600) -> subprocess.CompletedProcess:
    cmd = ["cargo", *args]
    return subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=timeout,
        cwd=str(REPO_DIR),
        env=_CARGO_ENV,
        check=False,
    )


_RESULT_LINE = re.compile(
    r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed",
    re.MULTILINE,
)


def test_uplc_crate_still_compiles() -> None:
    """`cargo check -p uplc` must succeed."""
    proc = _run_cargo("check", "-p", "uplc", "--offline", timeout=600)
    assert proc.returncode == 0, (
        "`cargo check -p uplc` failed: the uplc crate no longer compiles.\n"
        f"--- last stdout ---\n{proc.stdout[-2000:]}\n"
        f"--- last stderr ---\n{proc.stderr[-3000:]}"
    )


# The crate's pre-existing test targets: its unit tests, the three integration
# test files that ship with it, and its doc tests. Named explicitly so that test
# files added by the change itself are not counted as existing tests.
_EXISTING_TEST_RUNS = (
    ("--lib", "--test", "conformance", "--test", "integ_tests", "--test", "pretty_tests"),
    ("--doc",),
)

# Run from their base-commit copies, so the existing tests are the ones graded.
_EXISTING_TEST_PATHS = (
    "crates/uplc/tests/conformance.rs",
    "crates/uplc/tests/integ_tests.rs",
    "crates/uplc/tests/pretty_tests.rs",
    "crates/uplc/test_data",
)

_BASE_UNIT_TESTS = """
ast::tests::integer_bigint_negative
builder::tests::unwrap_bool_or_extra_args
builder::tests::unwrap_bool_or_false
builder::tests::unwrap_bool_or_invalid_constr_hi
builder::tests::unwrap_bool_or_true
builder::tests::unwrap_pair_or
builder::tests::unwrap_pair_or_not_enough_args_0
builder::tests::unwrap_pair_or_not_enough_args_1
builder::tests::unwrap_pair_or_too_many_args
builder::tests::unwrap_tail_or_0_elems
builder::tests::unwrap_tail_or_1_elem
builder::tests::unwrap_tail_or_2_elems
builder::tests::unwrap_void_or_happy
builder::tests::unwrap_void_or_too_many_args
builder::tests::unwrap_void_or_wrong_constr
flat::tests::flat_decode_integer
flat::tests::flat_decode_list_list_integer
flat::tests::flat_decode_pair_pair_integer_bool_integer
flat::tests::flat_encode_integer
flat::tests::flat_encode_list_list_integer
flat::tests::flat_encode_pair_pair_integer_bool_integer
flat::tests::unflat_string_escape
flat::tests::uplc_parser_string_escape
machine::cost_model::tests::assert_default_cost_model_v1_mainnet_2024_09_29
machine::cost_model::tests::assert_default_cost_model_v2_mainnet_2024_09_29
machine::cost_model::tests::assert_default_cost_model_v3_preprod_2024_11_22
machine::eval_result::tests::eval_result_failed::err_error_outofexerror_exbudget_default_language_plutusv1_false_expects_true
machine::eval_result::tests::eval_result_failed::err_error_outofexerror_exbudget_default_language_plutusv2_false_expects_true
machine::eval_result::tests::eval_result_failed::err_error_outofexerror_exbudget_default_language_plutusv3_false_expects_true
machine::eval_result::tests::eval_result_failed::ok_term_bool_false_plutusv1_false_expects_false
machine::eval_result::tests::eval_result_failed::ok_term_bool_false_plutusv2_false_expects_false
machine::eval_result::tests::eval_result_failed::ok_term_bool_false_plutusv3_false_expects_true
machine::eval_result::tests::eval_result_failed::ok_term_bool_false_plutusv3_true_expects_true
machine::eval_result::tests::eval_result_failed::ok_term_bool_true_plutusv1_false_expects_false
machine::eval_result::tests::eval_result_failed::ok_term_bool_true_plutusv2_false_expects_false
machine::eval_result::tests::eval_result_failed::ok_term_bool_true_plutusv3_false_expects_true
machine::eval_result::tests::eval_result_failed::ok_term_bool_true_plutusv3_true_expects_false
machine::eval_result::tests::eval_result_failed::ok_term_error_plutusv1_false_expects_true
machine::eval_result::tests::eval_result_failed::ok_term_error_plutusv2_false_expects_true
machine::eval_result::tests::eval_result_failed::ok_term_error_plutusv3_false_expects_true
machine::eval_result::tests::eval_result_failed::ok_term_integer_42_into_plutusv1_false_expects_false
machine::eval_result::tests::eval_result_failed::ok_term_integer_42_into_plutusv2_false_expects_false
machine::eval_result::tests::eval_result_failed::ok_term_integer_42_into_plutusv3_false_expects_true
machine::eval_result::tests::eval_result_failed::ok_term_unit_plutusv1_false_expects_false
machine::eval_result::tests::eval_result_failed::ok_term_unit_plutusv2_false_expects_false
machine::eval_result::tests::eval_result_failed::ok_term_unit_plutusv3_false_expects_false
machine::eval_result::tests::eval_result_failed::ok_term_var_x_lambda_x_try_into_unwrap_plutusv1_false_expects_false
machine::eval_result::tests::eval_result_failed::ok_term_var_x_lambda_x_try_into_unwrap_plutusv2_false_expects_false
machine::eval_result::tests::eval_result_failed::ok_term_var_x_lambda_x_try_into_unwrap_plutusv3_false_expects_true
machine::runtime::tests::any_range
machine::runtime::tests::compact_tag_mid_range
machine::runtime::tests::compact_tag_range
machine::runtime::tests::to_any_tag
machine::runtime::tests::to_compact_tag
machine::runtime::tests::to_compact_tag_mid
machine::tests::add_big_ints
machine::tests::bls_g1_add_associative
machine::tests::bls_g2_add_associative
machine::tests::case_constr_case_0
machine::tests::case_constr_case_1
machine::tests::divide_integer
machine::value::tests::integer_log2_oracle
machine::value::tests::to_ex_mem_bigint
optimize::interner::tests::fresh_shadowing_binders_get_distinct_uniques
optimize::shrinker::tests::builtin_force_reduce_if_builtin
optimize::shrinker::tests::builtin_force_reduce_list_builtins
optimize::shrinker::tests::builtin_force_reduce_pair_builtins
optimize::shrinker::tests::case_constr_apply_test_1
optimize::shrinker::tests::case_constr_apply_test_2
optimize::shrinker::tests::curry_reducer_test_1
optimize::shrinker::tests::curry_reducer_test_2
optimize::shrinker::tests::curry_reducer_test_3
optimize::shrinker::tests::curry_reducer_test_4
optimize::shrinker::tests::identity_reduce_0_occurrence
optimize::shrinker::tests::identity_reduce_no_inline
optimize::shrinker::tests::identity_reduce_no_inline_2
optimize::shrinker::tests::identity_reduce_param
optimize::shrinker::tests::identity_reduce_usage
optimize::shrinker::tests::inline_reduce_0_occurrence
optimize::shrinker::tests::inline_reduce_delay_sha
optimize::shrinker::tests::inline_reduce_if_then_else_else
optimize::shrinker::tests::inline_reduce_if_then_else_then
optimize::shrinker::tests::lambda_reduce_builtin
optimize::shrinker::tests::lambda_reduce_constant
optimize::shrinker::tests::lambda_reduce_force_delay_error_lam
optimize::shrinker::tests::lambda_reduce_var
optimize::shrinker::tests::wrap_data_reduce_i_data
optimize::shrinker::tests::wrap_data_reduce_un_i_data
parser::tests::parse_apply
parser::tests::parse_big_negative_int
parser::tests::parse_builtin_add_integer
parser::tests::parse_builtin_add_integer_curried
parser::tests::parse_builtin_append_bytestring
parser::tests::parse_builtin_cons_bytestring
parser::tests::parse_builtin_divide_integer
parser::tests::parse_builtin_equals_bytestring
parser::tests::parse_builtin_equals_integer
parser::tests::parse_builtin_index_bytestring
parser::tests::parse_builtin_length_of_bytestring
parser::tests::parse_builtin_less_than_bytestring
parser::tests::parse_builtin_less_than_equals_bytestring
parser::tests::parse_builtin_less_than_equals_integer
parser::tests::parse_builtin_less_than_integer
parser::tests::parse_builtin_mod_integer
parser::tests::parse_builtin_multiply_integer
parser::tests::parse_builtin_quotient_integer
parser::tests::parse_builtin_remainder_integer
parser::tests::parse_builtin_slice_bytestring
parser::tests::parse_builtin_subtract_integer
parser::tests::parse_delay_lambda
parser::tests::parse_error
parser::tests::parse_formatted
parser::tests::parse_lambda
parser::tests::parse_list_bools
parser::tests::parse_list_bytestrings
parser::tests::parse_list_empty
parser::tests::parse_list_list_integers
parser::tests::parse_list_mixed_types
parser::tests::parse_list_multiline
parser::tests::parse_list_singleton_unit
parser::tests::parse_list_type_mismatch
parser::tests::parse_pair_bool_pair_integer_bytestring
parser::tests::parse_pair_multiline
parser::tests::parse_pair_string_list_integer
parser::tests::parse_pair_unit_unit
pretty::tests::format_pair_bool_pair_integer_bytestring
tx::script_context::tests::script_context_certificates
tx::script_context::tests::script_context_mint
tx::script_context::tests::script_context_propose_all_but_pparams
tx::script_context::tests::script_context_propose_pparams_no_cost_models
tx::script_context::tests::script_context_simple_send
tx::script_context::tests::script_context_voting
tx::script_context::tests::script_context_withdraw
tx::tests::eval_extraneous_redeemer
tx::tests::eval_missing_redeemer
tx::tests::test_eval_0
tx::tests::test_eval_1
tx::tests::test_eval_2
tx::tests::test_eval_3
tx::tests::test_eval_4
tx::tests::test_eval_5
tx::tests::test_eval_6
tx::tests::test_eval_7
tx::tests::test_eval_8
""".split()


def _git(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run(["git", *args], capture_output=True, cwd=str(REPO_DIR), check=False)


@contextmanager
def _base_copies_of_existing_tests():
    base = Path("/var/lib/devcontainer_base_ref").read_text().strip()
    changed = _git("diff", "--name-only", base, "--", *_EXISTING_TEST_PATHS).stdout.decode().split("\n")
    saved: dict[Path, bytes | None] = {}
    for rel in filter(None, changed):
        path = REPO_DIR / rel
        saved[path] = path.read_bytes() if path.exists() else None
        shown = _git("show", f"{base}:{rel}")
        if shown.returncode == 0:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(shown.stdout)
        else:
            path.unlink(missing_ok=True)
    try:
        yield
    finally:
        for path, content in saved.items():
            if content is None:
                path.unlink(missing_ok=True)
            else:
                path.write_bytes(content)


def test_uplc_existing_tests_pass() -> None:
    """The crate's existing unit, integration and doc tests must still pass."""
    with _base_copies_of_existing_tests():
        for targets in _EXISTING_TEST_RUNS:
            label = "cargo test -p uplc " + " ".join(targets)
            proc = _run_cargo("test", "-p", "uplc", *targets, "--offline", timeout=720)
            summaries = _RESULT_LINE.findall(proc.stdout + "\n" + proc.stderr)

            assert proc.returncode == 0, (
                f"`{label}` exited with {proc.returncode}: an existing test failed "
                "or a test target did not build.\n"
                f"--- last stdout ---\n{proc.stdout[-2000:]}\n"
                f"--- last stderr ---\n{proc.stderr[-3000:]}"
            )
            assert summaries, (
                f"expected 'test result: ...' summary lines from `{label}`, got none; "
                "a test target may not have built.\n"
                f"--- stdout ---\n{proc.stdout[-2000:]}"
            )
            total_passed = sum(int(p) for _, p, _ in summaries)
            total_failed = sum(int(f) for _, _, f in summaries)
            assert total_failed == 0, (
                f"{total_failed} existing uplc test(s) failed in `{label}`.\n"
                f"--- last stdout ---\n{proc.stdout[-2000:]}"
            )
            assert total_passed > 0, (
                f"expected at least one test to pass in `{label}`; saw zero.\n"
                f"--- last stdout ---\n{proc.stdout[-2000:]}"
            )

    listed = _run_cargo("test", "-p", "uplc", "--lib", "--offline", "--", "--list", timeout=720)
    present = {line[: -len(": test")] for line in listed.stdout.splitlines() if line.endswith(": test")}
    missing = sorted(set(_BASE_UNIT_TESTS) - present)
    assert not missing, f"existing unit tests are gone: {missing}"


# Language-only evaluation against the base commit, all in one test target:
# every language-only `Program` entry point and the four phase-two entry points,
# with their signatures (compile time) and their results. The programs and
# transactions use string and integer builtins whose cost depends on the era,
# with the default costs, today's cost-vector lengths and shorter PlutusV3
# vectors.
_LANGUAGE_ONLY_TEST = r'''use std::collections::HashMap;

use num_bigint::BigInt;
use pallas_addresses::ScriptHash;
use pallas_codec::utils::Bytes;
use pallas_primitives::{
    Fragment,
    conway::{self, CostModels, MintedTx, Redeemer, TransactionInput, TransactionOutput},
};
use pallas_traverse::{Era, MultiEraTx};
use uplc::Language;
use uplc::ast::{Constant, DeBruijn, NamedDeBruijn, Program, Term};
use uplc::builtins::DefaultFunction as F;
use uplc::machine::cost_model::ExBudget;
use uplc::machine::eval_result::EvalResult;
use uplc::tx::{
    self, DataLookupTable, ResolvedInput, SlotConfig, error::Error, eval::eval_redeemer,
    eval_phase_two, eval_phase_two_raw, eval_phase_two_with_override, script_context::PlutusScript,
};

fn prog(f: F, args: Vec<Constant>) -> Program<NamedDeBruijn> {
    let mut t = Term::Builtin(f);
    for a in args {
        t = Term::Apply { function: t.into(), argument: Term::Constant(a.into()).into() };
    }
    Program { version: (1, 1, 0), term: t }
}

fn int(s: &str) -> Constant {
    Constant::Integer(s.parse::<BigInt>().unwrap())
}

fn programs() -> Vec<(&'static str, Program<NamedDeBruijn>)> {
    let s = "a\u{20ac}\u{20ac}\u{20ac}".to_string();
    let big = "1606938044258990275541962092341162602522202993782792835301376";
    vec![
        ("append", prog(F::AppendString, vec![Constant::String(String::new()), Constant::String(s.clone())])),
        ("equals", prog(F::EqualsString, vec![Constant::String(s.clone()), Constant::String(s.clone())])),
        ("encode", prog(F::EncodeUtf8, vec![Constant::String(s.clone())])),
        ("decode", prog(F::DecodeUtf8, vec![Constant::ByteString(s.into_bytes())])),
        ("divide", prog(F::DivideInteger, vec![int("3"), int(big)])),
        ("quotient", prog(F::QuotientInteger, vec![int("3"), int(big)])),
        ("mod", prog(F::ModInteger, vec![int("3"), int(big)])),
        ("mod_larger_first", prog(F::ModInteger, vec![int(big), int("3")])),
        ("remainder", prog(F::RemainderInteger, vec![int("3"), int(big)])),
        ("remainder_larger_first", prog(F::RemainderInteger, vec![int(big), int("3")])),
        ("multiply", prog(F::MultiplyInteger, vec![int("18446744073709551616"), int("340282366920938463463374607431768211456")])),
    ]
}

fn row(label: String, r: &EvalResult) -> String {
    let c = r.cost();
    match r.result() {
        Ok(_) => format!("{label} ok {} {}", c.mem, c.cpu),
        Err(_) => format!("{label} err"),
    }
}

fn program_rows(got: &mut Vec<String>) {
    let named_eval: fn(Program<NamedDeBruijn>, ExBudget) -> EvalResult = Program::<NamedDeBruijn>::eval;
    let named_eval_version: fn(Program<NamedDeBruijn>, ExBudget, &Language) -> EvalResult =
        Program::<NamedDeBruijn>::eval_version;
    let named_eval_as: fn(Program<NamedDeBruijn>, &Language, &[i64], Option<&ExBudget>) -> EvalResult =
        Program::<NamedDeBruijn>::eval_as;
    let named_eval_debug: fn(Program<NamedDeBruijn>, ExBudget, &Language) -> EvalResult =
        Program::<NamedDeBruijn>::eval_debug;
    let debruijn_eval: fn(&Program<DeBruijn>, ExBudget) -> EvalResult = Program::<DeBruijn>::eval;
    let debruijn_eval_version: fn(Program<DeBruijn>, ExBudget, &Language) -> EvalResult =
        Program::<DeBruijn>::eval_version;

    let langs = [("v1", Language::PlutusV1, 166), ("v2", Language::PlutusV2, 175), ("v3", Language::PlutusV3, 297)];
    for (name, p) in programs() {
        got.push(row(format!("{name} eval"), &named_eval(p.clone(), ExBudget::default())));
        let db: Program<DeBruijn> = p.clone().into();
        got.push(row(format!("{name} debruijn_eval"), &debruijn_eval(&db, ExBudget::default())));
        for (ln, l, n) in langs.iter() {
            let costs: Vec<i64> = (0..*n as i64).collect();
            got.push(row(format!("{name} eval_version {ln}"), &named_eval_version(p.clone(), ExBudget::default(), l)));
            got.push(row(format!("{name} eval_as {ln}"), &named_eval_as(p.clone(), l, &costs, None)));
            got.push(row(format!("{name} eval_debug {ln}"), &named_eval_debug(p.clone(), ExBudget::default(), l)));
            got.push(row(format!("{name} debruijn_eval_version {ln}"), &debruijn_eval_version(db.clone(), ExBudget::default(), l)));
        }
    }

    // PlutusV3 vectors shorter than today's.
    let bytes = |v: Vec<u8>| Constant::ByteString(v);
    let mut short = programs();
    short.push(("and", prog(F::AndByteString, vec![Constant::Bool(true), bytes(vec![0xff, 0x0f]), bytes(vec![0x0f, 0xff])])));
    short.push(("ripemd", prog(F::Ripemd_160, vec![bytes(vec![0xff, 0x0f])])));
    short.push(("add", prog(F::AddInteger, vec![int("1"), int("2")])));
    for n in [296, 270, 251] {
        let costs: Vec<i64> = (0..n).collect();
        for (name, p) in short.iter() {
            got.push(row(format!("{name} eval_as v3 short {n}"), &p.clone().eval_as(&Language::PlutusV3, &costs, None)));
        }
    }
}

const SLOT: SlotConfig = SlotConfig { zero_time: 1660003200000, zero_slot: 0, slot_length: 1000 };

struct Fixture {
    label: &'static str,
    tx: &'static str,
    inputs: &'static str,
    outputs: &'static str,
    hash: &'static str,
    script: PlutusScript,
    costs: Vec<(&'static str, Option<CostModels>)>,
}

fn utxos(f: &Fixture) -> Vec<ResolvedInput> {
    let inputs = Vec::<TransactionInput>::decode_fragment(&hex::decode(f.inputs).unwrap()).unwrap();
    let outputs = Vec::<TransactionOutput>::decode_fragment(&hex::decode(f.outputs).unwrap()).unwrap();
    inputs.into_iter().zip(outputs).map(|(input, output)| ResolvedInput { input, output }).collect()
}

fn phase_two_rows(got: &mut Vec<String>) {
    let f_phase_two: fn(&MintedTx, &[ResolvedInput], Option<&CostModels>, Option<&ExBudget>, &SlotConfig, bool, fn(&Redeemer) -> ()) -> Result<Vec<(Redeemer, EvalResult)>, Error> = eval_phase_two;
    let f_override: fn(&MintedTx, &[ResolvedInput], Option<&CostModels>, Option<&ExBudget>, &SlotConfig, HashMap<ScriptHash, PlutusScript>, bool, fn(&Redeemer) -> ()) -> Result<Vec<(Redeemer, EvalResult)>, Error> = eval_phase_two_with_override;
    let f_raw: fn(&[u8], &[(Vec<u8>, Vec<u8>)], Option<&[u8]>, (u64, u64), (u64, u64, u32), bool, fn(&Redeemer) -> ()) -> Result<Vec<(Vec<u8>, EvalResult)>, Error> = eval_phase_two_raw;
    let f_redeemer: fn(&MintedTx, &[ResolvedInput], &SlotConfig, &Redeemer, &DataLookupTable, Option<&CostModels>, &ExBudget) -> Result<(Redeemer, EvalResult), Error> = eval_redeemer;

    let script = |h: &str| Bytes::from(hex::decode(h).unwrap());
    let v1 = |n: i64| Some(CostModels { plutus_v1: Some((0..n).collect()), plutus_v2: None, plutus_v3: None });
    let v2 = |n: i64| Some(CostModels { plutus_v1: None, plutus_v2: Some((0..n).collect()), plutus_v3: None });
    let v3 = |n: i64| Some(CostModels { plutus_v1: None, plutus_v2: None, plutus_v3: Some((0..n).collect()) });
    let fixtures = [
        Fixture { label: "v1", tx: TX_V1, inputs: INPUTS_V1, outputs: OUTPUTS_V1, hash: HASH_V1, script: PlutusScript::V1(conway::PlutusScript::<1>(script(SCRIPT_V1_V2))), costs: vec![("vector", v1(166)), ("default", None)] },
        Fixture { label: "v2", tx: TX_V2, inputs: INPUTS_V2, outputs: OUTPUTS_V2, hash: HASH_V2, script: PlutusScript::V2(conway::PlutusScript::<2>(script(SCRIPT_V1_V2))), costs: vec![("vector", v2(175)), ("default", None)] },
        Fixture { label: "v3", tx: TX_V3, inputs: INPUTS_V2, outputs: OUTPUTS_V2, hash: HASH_V3, script: PlutusScript::V3(conway::PlutusScript::<3>(script(SCRIPT_V3))), costs: vec![("vector", v3(297)), ("default", None)] },
        Fixture { label: "v3 bitwise", tx: TX_V3B, inputs: INPUTS_V2, outputs: OUTPUTS_V2, hash: HASH_V3B, script: PlutusScript::V3(conway::PlutusScript::<3>(script(SCRIPT_V3B))), costs: vec![("vector", v3(297)), ("short 296", v3(296)), ("short 270", v3(270))] },
    ];

    for f in fixtures {
        let tx_bytes = hex::decode(f.tx).unwrap();
        let multi = MultiEraTx::decode_for_era(Era::Conway, &tx_bytes).unwrap();
        let MultiEraTx::Conway(tx) = multi else { panic!("not a Conway transaction") };
        let utxos = utxos(&f);
        let budget = ExBudget::default();
        let hash: ScriptHash = f.hash.parse().unwrap();

        let raw_utxos: Vec<(Vec<u8>, Vec<u8>)> = utxos
            .iter()
            .map(|u| (u.input.encode_fragment().unwrap(), u.output.encode_fragment().unwrap()))
            .collect();

        for (kind, models) in f.costs.iter() {
            let costs = models.as_ref();
            let raw = costs.map(|c| c.encode_fragment().unwrap());
            let label = |entry: &str| format!("phase_two {entry} {} {kind}", f.label);
            let mut collect = |entry: &str, out: Result<Vec<(Redeemer, EvalResult)>, Error>| match out {
                Ok(rs) => {
                    for (redeemer, r) in rs {
                        got.push(format!("{} units {} {}", row(label(entry), &r), redeemer.ex_units.mem, redeemer.ex_units.steps));
                    }
                }
                Err(_) => got.push(format!("{} err", label(entry))),
            };

            collect("eval_phase_two", f_phase_two(&tx, &utxos, costs, Some(&budget), &SLOT, false, |_| ()));
            collect("eval_phase_two_with_override", f_override(&tx, &utxos, costs, Some(&budget), &SLOT, HashMap::new(), false, |_| ()));
            let replaced = HashMap::from([(hash, f.script.clone())]);
            collect("eval_phase_two_with_override replaced", f_override(&tx, &utxos, costs, Some(&budget), &SLOT, replaced, false, |_| ()));

            let table = DataLookupTable::from_transaction(&tx, &utxos);
            let rs = tx.transaction_witness_set.redeemer.as_ref().unwrap();
            for (key, data, ex_units) in tx::iter_redeemers(rs) {
                let redeemer = Redeemer { tag: key.tag, index: key.index, data: data.clone(), ex_units };
                collect("eval_redeemer", f_redeemer(&tx, &utxos, &SLOT, &redeemer, &table, costs, &budget).map(|one| vec![one]));
            }

            let raw_budget = (budget.cpu as u64, budget.mem as u64);
            let raw_slot = (SLOT.zero_time, SLOT.zero_slot, SLOT.slot_length);
            match f_raw(&tx_bytes, &raw_utxos, raw.as_deref(), raw_budget, raw_slot, false, |_| ()) {
                Ok(rs) => {
                    for (_, r) in rs {
                        got.push(row(label("eval_phase_two_raw"), &r));
                    }
                }
                Err(_) => got.push(format!("{} err", label("eval_phase_two_raw"))),
            }
        }
    }
}

#[test]
fn language_only_evaluation_unchanged() {
    let mut got: Vec<String> = Vec::new();
    program_rows(&mut got);
    phase_two_rows(&mut got);
    if std::env::var("PRINT_EXPECTED").is_ok() {
        for g in &got {
            println!("EXP {g}");
        }
        return;
    }
    let expected: Vec<String> = EXPECTED.lines().map(|l| l.trim().to_string()).filter(|l| !l.is_empty()).collect();
    for (g, e) in got.iter().zip(expected.iter()) {
        assert_eq!(g, e, "a language-only result changed");
    }
    assert_eq!(got.len(), expected.len(), "unexpected number of results");
}

const TX_V1: &str = "84a800818258206c732139de33e916342707de2aebef2252c781640326ff37b86ec99d97f1ba8d01018282581d60b6c8794e9a7a26599440a4d0fd79cd07644d15917ff13694f1f67235821a000f41f0a1581c574c7ff40d45ecce80579ca4b54d9be20c43e4304fed47f7bafe8e8da1400a82581d60b6c8794e9a7a26599440a4d0fd79cd07644d15917ff13694f1f672351b00000001af006ac1021a00050c0309a1581c574c7ff40d45ecce80579ca4b54d9be20c43e4304fed47f7bafe8e8da1400a0b5820eb3b868ec2b33dffaf5d5481703ed00870333812b96e0f75ae89fd150b4744300d818258206c732139de33e916342707de2aebef2252c781640326ff37b86ec99d97f1ba8d011082581d60b6c8794e9a7a26599440a4d0fd79cd07644d15917ff13694f1f672351b00000001af0d26af111a00079205a3008182582031ae74f8058527afb305d7495b10a99422d9337fc199e1f28044f2c477a0f94658405a2dd70be89483bd6291a018c6ca91328dad37e092fdeab2eea14685004878da5f1e5962f35d771498bf54e79be3dcf922ea93b46a1356960dcf0bfd80a91b0b0381588658840100002233332222498cdcb2490049010a61e282ace282ace282ac00337069003241010101010101010101010101010101010101010101010101010101004066e1920064820202020202020202020202020202020202020202020202020202020080cdc124101010101010101010008904040404040404040404040404040404040400410581840100d87980821a000a01a61a0b3b82b2f5f6";
const HASH_V1: &str = "574c7ff40d45ecce80579ca4b54d9be20c43e4304fed47f7bafe8e8d";
const TX_V2: &str = "84a80081825820975c17a4fed0051be622328efa548e206657d2b65a19224bf6ff8132571e6a5002018282581d60b6c8794e9a7a26599440a4d0fd79cd07644d15917ff13694f1f67235821a000f41f0a1581ca9f0a3bb675d793477b629160f73d9cddc4a225a03f454dc4f033503a1400a82581d60b6c8794e9a7a26599440a4d0fd79cd07644d15917ff13694f1f672351a0084192f021a00053b6109a1581ca9f0a3bb675d793477b629160f73d9cddc4a225a03f454dc4f033503a1400a0b5820b4f96b0acec8beff2adededa8ba317bcac92174f0f65ccefe569b9a6aac7375a0d818258206c732139de33e916342707de2aebef2252c781640326ff37b86ec99d97f1ba8d011082581d60b6c8794e9a7a26599440a4d0fd79cd07644d15917ff13694f1f672351b00000001af0cdfa2111a0007d912a3008182582031ae74f8058527afb305d7495b10a99422d9337fc199e1f28044f2c477a0f9465840b8b97b7c3b4e19ecfc2fcd9884ee53a35887ee6e4d36901b9ecbac3fe032d7e8a4358305afa573a86396e378255651ed03501906e9def450e588d4bb36f42a050581840100d87980821a000b68081a0cf3a5bf0681588658840100002233332222498cdcb2490049010a61e282ace282ace282ac00337069003241010101010101010101010101010101010101010101010101010101004066e1920064820202020202020202020202020202020202020202020202020202020080cdc12410101010101010101000890404040404040404040404040404040404040041f5f6";
const HASH_V2: &str = "a9f0a3bb675d793477b629160f73d9cddc4a225a03f454dc4f033503";
const TX_V3: &str = "84a80081825820975c17a4fed0051be622328efa548e206657d2b65a19224bf6ff8132571e6a5002018282581d60b6c8794e9a7a26599440a4d0fd79cd07644d15917ff13694f1f67235821a000f41f0a1581c7f9fd727a29de85cb814bab3e0cefa54ab6601d8bae89356db83c199a1400a82581d60b6c8794e9a7a26599440a4d0fd79cd07644d15917ff13694f1f672351a0084192f021a00053b6109a1581c7f9fd727a29de85cb814bab3e0cefa54ab6601d8bae89356db83c199a1400a0b5820b4f96b0acec8beff2adededa8ba317bcac92174f0f65ccefe569b9a6aac7375a0d818258206c732139de33e916342707de2aebef2252c781640326ff37b86ec99d97f1ba8d011082581d60b6c8794e9a7a26599440a4d0fd79cd07644d15917ff13694f1f672351b00000001af0cdfa2111a0007d912a3008182582031ae74f8058527afb305d7495b10a99422d9337fc199e1f28044f2c477a0f9465840b8b97b7c3b4e19ecfc2fcd9884ee53a35887ee6e4d36901b9ecbac3fe032d7e8a4358305afa573a86396e378255651ed03501906e9def450e588d4bb36f42a050581840100d87980821a000b68081a0cf3a5bf078158865884010100233332222498cdcb24810049010a61e282ace282ace282ac00337069003241010101010101010101010101010101010101010101010101010101004066e1920064820202020202020202020202020202020202020202020202020202020080cdc12410101010101010101000890404040404040404040404040404040404040041f5f6";
const HASH_V3: &str = "7f9fd727a29de85cb814bab3e0cefa54ab6601d8bae89356db83c199";
const TX_V3B: &str = "84a80081825820975c17a4fed0051be622328efa548e206657d2b65a19224bf6ff8132571e6a5002018282581d60b6c8794e9a7a26599440a4d0fd79cd07644d15917ff13694f1f67235821a000f41f0a1581c49c0afa8acbbbec8bb9c2ecd2398c6f28a894704ef541d556e218476a1400a82581d60b6c8794e9a7a26599440a4d0fd79cd07644d15917ff13694f1f672351a0084192f021a00053b6109a1581c49c0afa8acbbbec8bb9c2ecd2398c6f28a894704ef541d556e218476a1400a0b5820b4f96b0acec8beff2adededa8ba317bcac92174f0f65ccefe569b9a6aac7375a0d818258206c732139de33e916342707de2aebef2252c781640326ff37b86ec99d97f1ba8d011082581d60b6c8794e9a7a26599440a4d0fd79cd07644d15917ff13694f1f672351b00000001af0cdfa2111a0007d912a3008182582031ae74f8058527afb305d7495b10a99422d9337fc199e1f28044f2c477a0f9465840b8b97b7c3b4e19ecfc2fcd9884ee53a35887ee6e4d36901b9ecbac3fe032d7e8a4358305afa573a86396e378255651ed03501906e9def450e588d4bb36f42a050581840100d87980821a000b68081a0cf3a5bf0781581857010100232498ccde5a51488102ff0f004881020fff0001f5f6";
const HASH_V3B: &str = "49c0afa8acbbbec8bb9c2ecd2398c6f28a894704ef541d556e218476";
const INPUTS_V1: &str = "84825820b16778c9cf065d9efeefe37ec269b4fc5107ecdbd0dd6bf3274b224165c2edd9008258206c732139de33e916342707de2aebef2252c781640326ff37b86ec99d97f1ba8d01825820975c17a4fed0051be622328efa548e206657d2b65a19224bf6ff8132571e6a500282582018f86700660fc88d0370a8f95ea58f75507e6b27a18a17925ad3b1777eb0d77600";
const OUTPUTS_V1: &str = "8482581d60b6c8794e9a7a26599440a4d0fd79cd07644d15917ff13694f1f67235821a000f8548a1581c15be994a64bdb79dde7fe080d8e7ff81b33a9e4860e9ee0d857a8e85a144576177610182581d60b6c8794e9a7a26599440a4d0fd79cd07644d15917ff13694f1f672351b00000001af14b8b482581d60b6c8794e9a7a26599440a4d0fd79cd07644d15917ff13694f1f672351a0098968082581d60b6c8794e9a7a26599440a4d0fd79cd07644d15917ff13694f1f672351a00acd8c6";
const INPUTS_V2: &str = "84825820b16778c9cf065d9efeefe37ec269b4fc5107ecdbd0dd6bf3274b224165c2edd9008258206c732139de33e916342707de2aebef2252c781640326ff37b86ec99d97f1ba8d01825820975c17a4fed0051be622328efa548e206657d2b65a19224bf6ff8132571e6a500282582018f86700660fc88d0370a8f95ea58f75507e6b27a18a17925ad3b1777eb0d77600";
const OUTPUTS_V2: &str = "8482581d60b6c8794e9a7a26599440a4d0fd79cd07644d15917ff13694f1f67235821a000f8548a1581c15be994a64bdb79dde7fe080d8e7ff81b33a9e4860e9ee0d857a8e85a144576177610182581d60b6c8794e9a7a26599440a4d0fd79cd07644d15917ff13694f1f672351b00000001af14b8b482581d60b6c8794e9a7a26599440a4d0fd79cd07644d15917ff13694f1f672351a0098968082581d60b6c8794e9a7a26599440a4d0fd79cd07644d15917ff13694f1f672351a00acd8c6";
const SCRIPT_V1_V2: &str = "58840100002233332222498cdcb2490049010a61e282ace282ace282ac00337069003241010101010101010101010101010101010101010101010101010101004066e1920064820202020202020202020202020202020202020202020202020202020080cdc12410101010101010101000890404040404040404040404040404040404040041";
const SCRIPT_V3: &str = "5884010100233332222498cdcb24810049010a61e282ace282ace282ac00337069003241010101010101010101010101010101010101010101010101010101004066e1920064820202020202020202020202020202020202020202020202020202020080cdc12410101010101010101000890404040404040404040404040404040404040041";
const SCRIPT_V3B: &str = "57010100232498ccde5a51488102ff0f004881020fff0001";

const EXPECTED: &str = r#"
append eval ok 608 320928
append debruijn_eval ok 608 320928
append eval_version v1 ok 608 320928
append eval_as v1 ok 184 168
append eval_debug v1 ok 608 320928
append debruijn_eval_version v1 ok 608 320928
append eval_version v2 ok 608 320928
append eval_as v2 ok 184 168
append eval_debug v2 ok 608 320928
append debruijn_eval_version v2 ok 608 320928
append eval_version v3 ok 608 320928
append eval_as v3 ok 184 168
append eval_debug v3 ok 608 320928
append debruijn_eval_version v3 ok 608 320928
equals eval ok 601 323476
equals debruijn_eval ok 601 323476
equals eval_version v1 ok 601 323476
equals eval_as v1 ok 202 478
equals eval_debug v1 ok 601 323476
equals debruijn_eval_version v1 ok 601 323476
equals eval_version v2 ok 601 323476
equals eval_as v2 ok 202 478
equals eval_debug v2 ok 601 323476
equals debruijn_eval_version v2 ok 601 323476
equals eval_version v3 ok 601 323476
equals eval_as v3 ok 207 503
equals eval_debug v3 ok 601 323476
equals debruijn_eval_version v3 ok 601 323476
encode eval ok 412 220784
encode debruijn_eval ok 412 220784
encode eval_version v1 ok 412 220784
encode eval_as v1 ok 379 365
encode eval_debug v1 ok 412 220784
encode debruijn_eval_version v1 ok 412 220784
encode eval_version v2 ok 412 220784
encode eval_as v2 ok 379 365
encode eval_debug v2 ok 412 220784
encode debruijn_eval_version v2 ok 412 220784
encode eval_version v3 ok 412 220784
encode eval_as v3 ok 404 390
encode eval_debug v3 ok 412 220784
encode debruijn_eval_version v3 ok 412 220784
decode eval ok 408 140827
decode debruijn_eval ok 408 140827
decode eval_version v1 ok 408 140827
decode eval_as v1 ok 233 223
decode eval_debug v1 ok 408 140827
decode debruijn_eval_version v1 ok 408 140827
decode eval_version v2 ok 408 140827
decode eval_as v2 ok 233 223
decode eval_debug v2 ok 408 140827
decode debruijn_eval_version v2 ok 408 140827
decode eval_version v3 ok 408 140827
decode eval_as v3 ok 233 223
decode eval_debug v3 ok 408 140827
decode debruijn_eval_version v3 ok 408 140827
divide eval ok 601 165948
divide debruijn_eval ok 601 165948
divide eval_version v1 ok 601 165948
divide eval_as v1 ok 3044 173
divide eval_debug v1 ok 601 165948
divide debruijn_eval_version v1 ok 601 165948
divide eval_version v2 ok 601 165948
divide eval_as v2 ok 3044 173
divide eval_debug v2 ok 601 165948
divide debruijn_eval_version v2 ok 601 165948
divide eval_version v3 ok 601 165948
divide eval_as v3 ok 3609 173
divide eval_debug v3 ok 601 165948
divide debruijn_eval_version v3 ok 601 165948
quotient eval ok 601 165948
quotient debruijn_eval ok 601 165948
quotient eval_version v1 ok 601 165948
quotient eval_as v1 ok 16004 245
quotient eval_debug v1 ok 601 165948
quotient debruijn_eval_version v1 ok 601 165948
quotient eval_version v2 ok 601 165948
quotient eval_as v2 ok 16004 245
quotient eval_debug v2 ok 601 165948
quotient debruijn_eval_version v2 ok 601 165948
quotient eval_version v3 ok 601 165948
quotient eval_as v3 ok 19728 254
quotient eval_debug v3 ok 601 165948
quotient debruijn_eval_version v3 ok 601 165948
mod eval ok 604 165948
mod debruijn_eval ok 604 165948
mod eval_version v1 ok 604 165948
mod eval_as v1 ok 13124 233
mod eval_debug v1 ok 604 165948
mod debruijn_eval_version v1 ok 604 165948
mod eval_version v2 ok 604 165948
mod eval_as v2 ok 13124 233
mod eval_debug v2 ok 604 165948
mod debruijn_eval_version v2 ok 604 165948
mod eval_version v3 ok 604 165948
mod eval_as v3 ok 744 238
mod eval_debug v3 ok 604 165948
mod debruijn_eval_version v3 ok 604 165948
mod_larger_first eval ok 601 219680
mod_larger_first debruijn_eval ok 601 219680
mod_larger_first eval_version v1 ok 601 219680
mod_larger_first eval_as v1 ok 13124 678
mod_larger_first eval_debug v1 ok 601 219680
mod_larger_first debruijn_eval_version v1 ok 601 219680
mod_larger_first eval_version v2 ok 601 219680
mod_larger_first eval_as v2 ok 13124 678
mod_larger_first eval_debug v2 ok 601 219680
mod_larger_first debruijn_eval_version v2 ok 601 219680
mod_larger_first eval_version v3 ok 601 219680
mod_larger_first eval_as v3 ok 375 3340
mod_larger_first eval_debug v3 ok 601 219680
mod_larger_first debruijn_eval_version v3 ok 601 219680
remainder eval ok 604 165948
remainder debruijn_eval ok 604 165948
remainder eval_version v1 ok 604 165948
remainder eval_as v1 ok 17552 251
remainder eval_debug v1 ok 604 165948
remainder debruijn_eval_version v1 ok 604 165948
remainder eval_version v2 ok 604 165948
remainder eval_as v2 ok 17552 251
remainder eval_debug v2 ok 604 165948
remainder debruijn_eval_version v2 ok 604 165948
remainder eval_version v3 ok 604 165948
remainder eval_as v3 ok 879 265
remainder eval_debug v3 ok 604 165948
remainder debruijn_eval_version v3 ok 604 165948
remainder_larger_first eval ok 601 219680
remainder_larger_first debruijn_eval ok 601 219680
remainder_larger_first eval_version v1 ok 601 219680
remainder_larger_first eval_as v1 ok 17552 768
remainder_larger_first eval_debug v1 ok 601 219680
remainder_larger_first debruijn_eval_version v1 ok 601 219680
remainder_larger_first eval_version v2 ok 601 219680
remainder_larger_first eval_as v2 ok 17552 768
remainder_larger_first eval_debug v2 ok 601 219680
remainder_larger_first debruijn_eval_version v2 ok 601 219680
remainder_larger_first eval_version v3 ok 601 219680
remainder_larger_first eval_as v3 ok 429 4069
remainder_larger_first eval_debug v3 ok 601 219680
remainder_larger_first debruijn_eval_version v3 ok 601 219680
multiply eval ok 605 173648
multiply debruijn_eval ok 605 173648
multiply eval_version v1 ok 605 173648
multiply eval_as v1 ok 837 935
multiply eval_debug v1 ok 605 173648
multiply debruijn_eval_version v1 ok 605 173648
multiply eval_version v2 ok 605 173648
multiply eval_as v2 ok 837 935
multiply eval_debug v2 ok 605 173648
multiply debruijn_eval_version v2 ok 605 173648
multiply eval_version v3 ok 605 173648
multiply eval_as v3 ok 891 998
multiply eval_debug v3 ok 605 173648
multiply debruijn_eval_version v3 ok 605 173648
append eval_as v3 short 296 ok 184 168
equals eval_as v3 short 296 ok 207 503
encode eval_as v3 short 296 ok 404 390
decode eval_as v3 short 296 ok 233 223
divide eval_as v3 short 296 ok 3609 173
quotient eval_as v3 short 296 ok 19728 254
mod eval_as v3 short 296 ok 744 238
mod_larger_first eval_as v3 short 296 ok 375 3340
remainder eval_as v3 short 296 ok 879 265
remainder_larger_first eval_as v3 short 296 ok 429 4069
multiply eval_as v3 short 296 ok 891 998
and eval_as v3 short 296 err
ripemd eval_as v3 short 296 err
add eval_as v3 short 296 ok 135 125
append eval_as v3 short 270 ok 184 168
equals eval_as v3 short 270 ok 207 503
encode eval_as v3 short 270 ok 404 390
decode eval_as v3 short 270 ok 233 223
divide eval_as v3 short 270 ok 3609 173
quotient eval_as v3 short 270 ok 19728 254
mod eval_as v3 short 270 ok 744 238
mod_larger_first eval_as v3 short 270 ok 375 3340
remainder eval_as v3 short 270 ok 879 265
remainder_larger_first eval_as v3 short 270 ok 429 4069
multiply eval_as v3 short 270 ok 891 998
and eval_as v3 short 270 err
ripemd eval_as v3 short 270 err
add eval_as v3 short 270 ok 135 125
append eval_as v3 short 251 ok 184 168
equals eval_as v3 short 251 ok 207 503
encode eval_as v3 short 251 ok 404 390
decode eval_as v3 short 251 ok 233 223
divide eval_as v3 short 251 ok 3609 173
quotient eval_as v3 short 251 ok 19728 254
mod eval_as v3 short 251 ok 744 238
mod_larger_first eval_as v3 short 251 ok 375 3340
remainder eval_as v3 short 251 ok 879 265
remainder_larger_first eval_as v3 short 251 ok 429 4069
multiply eval_as v3 short 251 ok 891 998
and eval_as v3 short 251 err
ripemd eval_as v3 short 251 err
add eval_as v3 short 251 ok 135 125
phase_two eval_phase_two v1 vector ok 17441 1749 units 17441 1749
phase_two eval_phase_two_with_override v1 vector ok 17441 1749 units 17441 1749
phase_two eval_phase_two_with_override replaced v1 vector ok 17441 1749 units 17441 1749
phase_two eval_redeemer v1 vector ok 17441 1749 units 17441 1749
phase_two eval_phase_two_raw v1 vector ok 17441 1749
phase_two eval_phase_two v1 default ok 3618 1066172 units 3618 1066172
phase_two eval_phase_two_with_override v1 default ok 3618 1066172 units 3618 1066172
phase_two eval_phase_two_with_override replaced v1 default ok 3618 1066172 units 3618 1066172
phase_two eval_redeemer v1 default ok 3618 1066172 units 3618 1066172
phase_two eval_phase_two_raw v1 default ok 3618 1066172
phase_two eval_phase_two v2 vector ok 17441 1749 units 17441 1749
phase_two eval_phase_two_with_override v2 vector ok 17441 1749 units 17441 1749
phase_two eval_phase_two_with_override replaced v2 vector ok 17441 1749 units 17441 1749
phase_two eval_redeemer v2 vector ok 17441 1749 units 17441 1749
phase_two eval_phase_two_raw v2 vector ok 17441 1749
phase_two eval_phase_two v2 default ok 3618 1066172 units 3618 1066172
phase_two eval_phase_two_with_override v2 default ok 3618 1066172 units 3618 1066172
phase_two eval_phase_two_with_override replaced v2 default ok 3618 1066172 units 3618 1066172
phase_two eval_redeemer v2 default ok 3618 1066172 units 3618 1066172
phase_two eval_phase_two_raw v2 default ok 3618 1066172
phase_two eval_phase_two v3 vector ok 5612 1752 units 5612 1752
phase_two eval_phase_two_with_override v3 vector ok 5612 1752 units 5612 1752
phase_two eval_phase_two_with_override replaced v3 vector ok 5612 1752 units 5612 1752
phase_two eval_redeemer v3 vector ok 5612 1752 units 5612 1752
phase_two eval_phase_two_raw v3 vector ok 5612 1752
phase_two eval_phase_two v3 default ok 3318 1018172 units 3318 1018172
phase_two eval_phase_two_with_override v3 default ok 3318 1018172 units 3318 1018172
phase_two eval_phase_two_with_override replaced v3 default ok 3318 1018172 units 3318 1018172
phase_two eval_redeemer v3 default ok 3318 1018172 units 3318 1018172
phase_two eval_phase_two_raw v3 default ok 3318 1018172
phase_two eval_phase_two v3 bitwise vector ok 815 1048 units 815 1048
phase_two eval_phase_two_with_override v3 bitwise vector ok 815 1048 units 815 1048
phase_two eval_phase_two_with_override replaced v3 bitwise vector ok 815 1048 units 815 1048
phase_two eval_redeemer v3 bitwise vector ok 815 1048 units 815 1048
phase_two eval_phase_two_raw v3 bitwise vector ok 815 1048
phase_two eval_phase_two v3 bitwise short 296 err
phase_two eval_phase_two_with_override v3 bitwise short 296 err
phase_two eval_phase_two_with_override replaced v3 bitwise short 296 err
phase_two eval_redeemer v3 bitwise short 296 err
phase_two eval_phase_two_raw v3 bitwise short 296 err
phase_two eval_phase_two v3 bitwise short 270 err
phase_two eval_phase_two_with_override v3 bitwise short 270 err
phase_two eval_phase_two_with_override replaced v3 bitwise short 270 err
phase_two eval_redeemer v3 bitwise short 270 err
phase_two eval_phase_two_raw v3 bitwise short 270 err
"#;
'''

_LANGUAGE_ONLY_TEST_FILE = "zz_verify_language_only_evaluation"


def test_language_only_evaluation_unchanged() -> None:
    """Language-only entry points keep their signatures and their results."""
    path = REPO_DIR / "crates" / "uplc" / "tests" / f"{_LANGUAGE_ONLY_TEST_FILE}.rs"
    path.write_text(_LANGUAGE_ONLY_TEST)
    try:
        proc = _run_cargo(
            "test", "-p", "uplc", "--test", _LANGUAGE_ONLY_TEST_FILE, "--offline", timeout=720
        )
    finally:
        path.unlink(missing_ok=True)
    assert proc.returncode == 0, (
        "a language-only entry point changed its signature or its result.\n"
        f"--- last stdout ---\n{proc.stdout[-3000:]}\n"
        f"--- last stderr ---\n{proc.stderr[-3000:]}"
    )
    assert "test result: ok. 1 passed" in proc.stdout, proc.stdout[-2000:]


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v", "--tb=short"]))
