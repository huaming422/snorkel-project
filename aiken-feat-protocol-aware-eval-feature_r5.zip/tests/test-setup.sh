#!/usr/bin/env bash
# test-setup.sh: runs before the checks in tests/verify, on the tree under
# test. The image already holds the full dependency closure (cargo registry/git
# cache under /opt/cargo, plus a `cargo build --locked --tests` of the
# workspace at the base commit), so cargo runs offline.
set -euo pipefail

cd /repo/aiken

# Force cargo offline: every crate the workspace needs is already in the
# registry/git cache under CARGO_HOME (/opt/cargo). A cache miss should fail
# fast rather than hang without a network.
export CARGO_NET_OFFLINE=true

# Warm the build of the uplc crate. Changes compile incrementally against the
# populated target dir (/opt/cache/cargo-target), so only changed crates are
# rebuilt. `--no-run` builds the uplc test binaries without running them, so
# the later `cargo test` calls start from a warm build.
echo "test-setup: building uplc test binary (offline, incremental)..."
cargo test --locked --offline -p uplc --no-run

echo "test-setup: ready."
