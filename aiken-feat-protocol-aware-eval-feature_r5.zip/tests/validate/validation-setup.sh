#!/usr/bin/env bash
# validation-setup.sh: prepares the container for the cargo tests defined in
# validation_spec.toml. Runs on the tree under test, before those tests.
#
# The image already holds the full dependency closure (cargo registry/git cache
# under CARGO_HOME, plus an offline build of the workspace at the base commit
# in the shared target dir). So this runs offline and only (a) pins the
# toolchain, (b) warms the uplc test build, and (c) checks that an integration
# test of the uplc crate builds and runs before any of them does.
set -euo pipefail

cd /repo/aiken

# Force offline: every crate is already cached under CARGO_HOME. A cache miss
# should fail fast rather than hang without a network.
export CARGO_NET_OFFLINE=true

# Pin the toolchain ahead of any stray cargo/rustc on PATH. The repo pins
# 1.94.1; honor the repo's rust-toolchain file if present, else force the pin.
if [ -f rust-toolchain.toml ] || [ -f rust-toolchain ]; then
  echo "validation-setup: using repo-pinned toolchain"
else
  export RUSTUP_TOOLCHAIN=1.94.1
  echo "validation-setup: forcing toolchain 1.94.1"
fi

cargo --version
rustc --version

# Warm the uplc test build so the first `cargo test --test <file>` starts
# from a warm target. `--no-run` builds the test binaries without
# running them; changes compile incrementally against the populated target dir.
echo "validation-setup: building uplc test binary (offline, incremental)..."
if ! cargo test --locked --offline -p uplc --no-run > /tmp/val-setup-build.log 2>&1; then
  echo "validation-setup: FAILED to build uplc test binary — the crate does not compile."
  tail -120 /tmp/val-setup-build.log
  exit 1
fi

# Smoke guard: a trivial integration test must compile and run against the
# crate's public API. If it fails, setup stops with the build log instead of
# letting every test fail for an unrelated reason.
SMOKE_DIR=crates/uplc/tests
SMOKE_FILE="$SMOKE_DIR/_validation_setup_smoke_test.rs"
cleanup() { rm -f "$SMOKE_FILE"; }
trap cleanup EXIT
cat > "$SMOKE_FILE" <<'RS'
use num_bigint::BigInt;
use uplc::ast::{Constant, NamedDeBruijn, Program, Term};
use uplc::builtins::DefaultFunction;
use uplc::machine::cost_model::ExBudget;
use uplc::Language;

#[test]
fn validation_setup_smoke() {
    let program = Program::<NamedDeBruijn> {
        version: (1, 1, 0),
        term: Term::Apply {
            function: Term::Apply {
                function: Term::Builtin(DefaultFunction::AddInteger).into(),
                argument: Term::Constant(Constant::Integer(BigInt::from(1)).into()).into(),
            }
            .into(),
            argument: Term::Constant(Constant::Integer(BigInt::from(2)).into()).into(),
        },
    };
    let result = program.eval_version(ExBudget::default(), &Language::PlutusV3);
    let _ = result.cost();
    assert!(result.result().is_ok());
}
RS

echo "validation-setup: running integration-test smoke guard..."
if ! cargo test --offline -p uplc --test _validation_setup_smoke_test \
    -- --test-threads=1 > /tmp/val-setup-smoke.log 2>&1; then
  echo "validation-setup: SMOKE GUARD FAILED — uplc integration tests do not build/run."
  tail -120 /tmp/val-setup-smoke.log
  exit 1
fi

echo "validation-setup: ready."
