## Task

One of our projects has `_.python.venv = { path = ".venv", create = true }` in its mise config, so mise makes the virtualenv itself, and a couple of `[deps.*]` providers install into it. When mise makes the venv from scratch, those providers are meant to run again.

They don't if the venv comes back in a different mise process. Delete `.venv`, then open a new shell so activation rebuilds it, or run `mise env`. Every provider on it still claims there's nothing to do. For pip, `mise deps install pip --explain` says `Status: fresh`, nothing gets installed, and the first import from the empty venv fails with `ModuleNotFoundError`. When the `mise deps` run that needs the venv is also the one that makes it, the providers do run.

We often have two providers on the same venv, and running one of them with `--only` doesn't cover the other. Each one needs its own run against the new venv before it's up to date.

Nothing else about freshness should move. A provider still runs again after a change to a source it declares or to its install command, or after one of its outputs goes missing. A `.venv` that mise never made isn't stale just because it exists.

Track down the cause and get it fixed.
