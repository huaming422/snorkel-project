#!/usr/bin/env bash
# Sourced by tests/test.sh before every check runs (set -euo pipefail comes
# from there). The checks drive the compiled `mise` CLI through the repo's e2e
# harness, so this rebuilds `mise` from the working tree as it stands.
cd /repo/mise

# Build offline: the image holds the whole dependency closure and a warm target
# cache (Dockerfile blocks 5 and 7), so a cargo build here resolves from the
# cache. A cache miss then fails at once instead of reaching for crates.io.
export CARGO_NET_OFFLINE=true

MISE_BIN="${CARGO_TARGET_DIR:-/repo/mise/target}/debug/mise"

# Rebuild the `mise` binary so the e2e harness finds a current one at
# $CARGO_TARGET_DIR/debug/mise. Offline first, with a logged online try in case
# the image cache is out of date.
if cargo build --locked --bin mise > /tmp/test-setup-build.log 2>&1; then
    echo "[offline-first] mise built from image-warmed cache"
elif CARGO_NET_OFFLINE=false cargo build --locked --bin mise >> /tmp/test-setup-build.log 2>&1; then
    echo "[test-setup] mise built after online fetch (image cache was stale)"
else
    # The tree doesn't build. Remove the binary the image built, so no check
    # runs an older mise, and let every check report the missing binary.
    echo "[test-setup] mise did not build; the last lines of the build log:" >&2
    tail -60 /tmp/test-setup-build.log >&2
    rm -f "$MISE_BIN"
fi

if [ ! -x "$MISE_BIN" ]; then
    echo "[test-setup] no mise binary at $MISE_BIN" >&2
fi

# No services to start and no data to seed: each scenario makes a stdlib venv
# with the system python3 and uses `touch` as its install command, and the e2e
# harness gives every scenario its own HOME and state directory.
