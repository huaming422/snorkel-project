"""Checks for deps freshness around a virtualenv that mise creates.

Every check drives the built `mise` binary. Each scenario is a short bash
script run through the repository's own e2e harness (`e2e/run_test`), which
gives each run its own HOME and state directory, puts
`$CARGO_TARGET_DIR/debug/mise` first on PATH and sets the experimental flag
the `deps` command needs. `MISE_E2E_INSIDE_DOCKER=1` keeps the harness in this
container.

Every `mise ...` line of a scenario is its own process. The scripts read exit
codes and the two strings `mise deps` prints today, `Installed: <id>` and
`up to date`. `mise deps install <id> --explain` exits non-zero for a provider
that needs to run, and zero for one that doesn't.
"""

from __future__ import annotations

import os
import subprocess
import tempfile
from pathlib import Path

import pytest

REPO_DIR = Path(f"/repo/{os.environ.get('REPO_NAME', 'mise')}")
RUN_TEST = REPO_DIR / "e2e" / "run_test"


def _scaled(seconds: int) -> int:
    """A time limit scaled by TIMEOUT_MULTIPLIER, never below the figure given."""
    try:
        factor = float(os.environ.get("TIMEOUT_MULTIPLIER") or 1)
    except ValueError:
        factor = 1.0
    return int(seconds * max(1.0, factor))


def _run_e2e(script_body: str, *, timeout: int = 300) -> subprocess.CompletedProcess:
    """Run one bash scenario through the repo's e2e harness.

    The harness sources `e2e/assert.sh` (`assert_contains`, `assert_fail`,
    `assert_succeed`, `assert`, `assert_directory_exists`, ...) and runs the
    script in a fresh isolated environment. Exit 0 means every assertion in
    the script held.
    """
    assert RUN_TEST.exists(), f"e2e harness not found at {RUN_TEST}"

    env = dict(os.environ)
    # Run the scenario in this container, not in a nested docker image.
    env["MISE_E2E_INSIDE_DOCKER"] = "1"
    # The harness finds the binary through ${CARGO_TARGET_DIR}; the image sets
    # it, and this is the image's value.
    env.setdefault("CARGO_TARGET_DIR", "/opt/cache/cargo-target")

    with tempfile.NamedTemporaryFile(
        "w", suffix="", prefix="verify_deps_", delete=False
    ) as fh:
        fh.write(script_body)
        script_path = fh.name
    try:
        return subprocess.run(
            ["bash", str(RUN_TEST), script_path],
            capture_output=True,
            text=True,
            timeout=_scaled(timeout),
            cwd=str(REPO_DIR),
            env=env,
            check=False,
        )
    finally:
        try:
            os.unlink(script_path)
        except OSError:
            pass


def _assert_e2e_passed(proc: subprocess.CompletedProcess, *, hint: str) -> None:
    assert proc.returncode == 0, (
        f"{hint}\n"
        f"e2e scenario exited with {proc.returncode}.\n"
        f"--- last stdout ---\n{proc.stdout[-3000:]}\n"
        f"--- last stderr ---\n{proc.stderr[-3000:]}"
    )


# --------------------------------------------------------------------------- #
# A venv that a later process makes again
# --------------------------------------------------------------------------- #

_CROSS_PROCESS_STALE = r"""#!/usr/bin/env bash
# mise creates .venv, and one deps provider installs into it and lists it as
# its output. The provider has a name of its own, so no built-in provider
# answers for it. A second provider has nothing to do with the venv.
cat >requirements.txt <<'EOF2'
six
EOF2
cat >other.txt <<'EOF2'
one
EOF2
cat >mise.toml <<'EOF2'
[settings]
python.venv_stdlib = true

[env]
_.python.venv = { path = ".venv", create = true }

[deps.venvdep]
sources = ["requirements.txt"]
outputs = [".venv"]
run = "touch .venv/installed"

[deps.other]
sources = ["other.txt"]
outputs = ["built.txt"]
run = "touch built.txt"
EOF2

# The first run creates the venv and installs both; the second has nothing to do.
assert_contains "mise deps 2>&1" "Installed: venvdep"
assert "test -f built.txt"
assert_contains "mise deps 2>&1" "up to date"

# The venv is deleted, and a plain `mise env` makes a new one.
rm -rf .venv
mise env >/dev/null
assert_directory_exists .venv
assert_fail "mise deps install venvdep --explain 2>&1"
assert_succeed "mise deps install other --explain 2>&1"

# Once the provider has run against the new venv, it's settled again, and the
# provider that doesn't use the venv didn't run.
mise deps >deps_run.txt 2>&1
assert_contains "cat deps_run.txt" "Installed: venvdep"
assert_not_contains "cat deps_run.txt" "Installed: other"
assert "test -f .venv/installed"
assert_contains "mise deps 2>&1" "up to date"
assert_succeed "mise deps install venvdep --explain 2>&1"

# A second time, with the venv made by the command shell activation runs at
# every prompt.
rm -rf .venv
mise hook-env -s bash >/dev/null
assert_directory_exists .venv
assert_fail "mise deps install venvdep --explain 2>&1"
assert_succeed "mise deps install other --explain 2>&1"
mise deps >deps_run.txt 2>&1
assert_contains "cat deps_run.txt" "Installed: venvdep"
assert_not_contains "cat deps_run.txt" "Installed: other"
assert "test -f .venv/installed"
assert_contains "mise deps 2>&1" "up to date"
"""


def test_cross_process_stale() -> None:
    """A venv made again by `mise env`, and then by `mise hook-env`, leaves its
    provider needing a run in the next process, until that provider runs, and
    a provider that doesn't use the venv stays up to date."""
    proc = _run_e2e(_CROSS_PROCESS_STALE)
    _assert_e2e_passed(
        proc,
        hint=(
            "After a separate `mise env` or `mise hook-env` made a new .venv, "
            "a later process didn't report the provider over it as needing a "
            "run, the provider didn't settle after it ran, or the provider "
            "that doesn't use the venv needed a run too."
        ),
    )


# --------------------------------------------------------------------------- #
# Two providers on one venv
# --------------------------------------------------------------------------- #

_SHARED_VENV_INDEPENDENT_CLEAR = r"""#!/usr/bin/env bash
# Two providers install into the same venv that mise creates, and a third one
# has nothing to do with the venv.
cat >requirements.txt <<'EOF2'
six
EOF2
cat >other.txt <<'EOF2'
one
EOF2
cat >mise.toml <<'EOF2'
[settings]
python.venv_stdlib = true

[env]
_.python.venv = { path = ".venv", create = true }

[deps.pip]
run = "touch .venv/installed"

[deps.extra]
sources = ["requirements.txt"]
outputs = [".venv"]
run = "touch .venv/extra"

[deps.other]
sources = ["other.txt"]
outputs = ["built.txt"]
run = "touch built.txt"
EOF2

assert_contains "mise deps 2>&1" "Installed: pip"
assert "test -f built.txt"
assert_contains "mise deps 2>&1" "up to date"

# A separate process makes a new venv.
rm -rf .venv
mise env >/dev/null
assert_directory_exists .venv
assert_succeed "mise deps install other --explain 2>&1"

# Only `pip` runs. It installs and is then up to date.
assert_contains "mise deps --only pip 2>&1" "Installed: pip"
assert "test -f .venv/installed"
assert_contains "mise deps --only pip 2>&1" "up to date"

# `extra` hasn't run against the new venv yet, so it still needs a run.
assert_fail "mise deps install extra --explain 2>&1"

# Running `extra` settles it, and then nothing is left to do, `other`
# included.
assert_contains "mise deps --only extra 2>&1" "Installed: extra"
assert "test -f .venv/extra"
mise deps >deps_run.txt 2>&1
assert_contains "cat deps_run.txt" "up to date"
assert_not_contains "cat deps_run.txt" "Installed: other"
"""


def test_shared_venv_independent_clear() -> None:
    """With two providers on one remade venv, running one of them leaves the
    other needing a run until it runs itself."""
    proc = _run_e2e(_SHARED_VENV_INDEPENDENT_CLEAR)
    _assert_e2e_passed(
        proc,
        hint=(
            "After `mise deps --only pip` ran against the new .venv, `extra`, "
            "which hadn't run yet, was reported as up to date."
        ),
    )


# --------------------------------------------------------------------------- #
# Ordinary freshness
# --------------------------------------------------------------------------- #

_NO_FRESHNESS_REGRESSION = r"""#!/usr/bin/env bash
# A provider with a source file and an output file, and no venv.
cat >requirements.txt <<'EOF2'
six
EOF2
cat >mise.toml <<'EOF2'
[deps.extra]
sources = ["requirements.txt"]
outputs = ["built.txt"]
run = "touch built.txt"
EOF2

# The first run installs; a second run with nothing changed is up to date.
assert_contains "mise deps 2>&1" "Installed: extra"
assert_contains "mise deps 2>&1" "up to date"

# An edit to a declared source makes the provider run again.
echo "seven" >>requirements.txt
assert_contains "mise deps 2>&1" "Installed: extra"
assert_contains "mise deps 2>&1" "up to date"

# A new install command makes the provider run again.
cat >mise.toml <<'EOF2'
[deps.extra]
sources = ["requirements.txt"]
outputs = ["built.txt"]
run = "touch built.txt && echo rebuilt"
EOF2
assert_contains "mise deps 2>&1" "Installed: extra"
assert_contains "mise deps 2>&1" "up to date"

# A missing output makes the provider run again.
rm -f built.txt
assert_contains "mise deps 2>&1" "Installed: extra"
assert_contains "mise deps 2>&1" "up to date"

# A .venv that was already a plain directory, with no `_.python.venv`
# directive anywhere, is up to date for a provider that lists it as output.
mkdir -p nonmise/.venv
cd nonmise
cat >mise.toml <<'EOF2'
[deps.local]
outputs = [".venv"]
run = "touch .venv/built"
EOF2
assert_contains "mise deps 2>&1" "up to date"
assert_succeed "mise deps install local --explain 2>&1"
"""


def test_no_freshness_regression() -> None:
    """A provider still runs again on a source edit, a new install command and
    a missing output, is up to date when nothing changed, and a .venv that
    mise didn't create is up to date."""
    proc = _run_e2e(_NO_FRESHNESS_REGRESSION)
    _assert_e2e_passed(
        proc,
        hint=(
            "A source edit, a new install command or a missing output didn't "
            "make the provider run again, an unchanged provider wasn't up to "
            "date, or a .venv that mise didn't create needed a run."
        ),
    )


# --------------------------------------------------------------------------- #
# A venv in another project
# --------------------------------------------------------------------------- #

_OTHER_PROJECT_VENV = r"""#!/usr/bin/env bash
# One project lets mise create its .venv. A second project, next to the first,
# keeps a .venv of its own that mise never created, and its provider runs once.
# That .venv is then made again outside mise, and later the first project's
# .venv is made again by mise.
work="$PWD"
cat >requirements.txt <<'EOF2'
six
EOF2
cat >mise.toml <<'EOF2'
[settings]
python.venv_stdlib = true

[env]
_.python.venv = { path = ".venv", create = true }

[deps.venvdep]
sources = ["requirements.txt"]
outputs = [".venv"]
run = "touch .venv/installed"
EOF2
assert_contains "mise deps 2>&1" "Installed: venvdep"

mkdir -p "$HOME/other/.venv"
cd "$HOME/other"
cat >local.txt <<'EOF2'
one
EOF2
cat >mise.toml <<'EOF2'
[deps.local]
sources = ["local.txt"]
outputs = [".venv"]
run = "touch .venv/built"
EOF2
assert_contains "mise deps 2>&1" "Installed: local"
assert_contains "mise deps 2>&1" "up to date"

# The second project deletes its .venv and makes it again itself, without mise.
# Its provider is still up to date.
rm -rf .venv
python3 -m venv .venv
assert_directory_exists .venv
assert_succeed "mise deps install local --explain 2>&1"
mise deps >deps_run.txt 2>&1
assert_contains "cat deps_run.txt" "up to date"
assert_not_contains "cat deps_run.txt" "Installed: local"

# A later `mise env` makes the first project's .venv again.
cd "$work"
rm -rf .venv
mise env >/dev/null
assert_directory_exists .venv

# The second project's provider is still up to date.
cd "$HOME/other"
assert_succeed "mise deps install local --explain 2>&1"
mise deps >deps_run.txt 2>&1
assert_contains "cat deps_run.txt" "up to date"
assert_not_contains "cat deps_run.txt" "Installed: local"
"""


def test_other_project_venv_not_stale() -> None:
    """A provider over a .venv that mise didn't create, in a second project,
    runs once and stays up to date after that .venv is made again outside mise
    and after mise made the first project's .venv again."""
    proc = _run_e2e(_OTHER_PROJECT_VENV)
    _assert_e2e_passed(
        proc,
        hint=(
            "A provider over a .venv that mise never created, in a second "
            "project, needed a run again after that .venv was made again "
            "outside mise or after mise made another project's venv."
        ),
    )


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v", "--tb=short"]))
