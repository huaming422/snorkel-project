// Checks for the admin maintenance task-state files on disk.
//
// Every check looks at what ends up in <dataDir>/tasks/, the folder operators
// see growing, and reads back the per-task .pb files left there. A restart is
// modelled the way startup does it: a fresh queue on the same folder calls
// LoadTasksFromPersistence, which re-queues pending, assigned and in-progress
// files as pending. The checks only go through entry points that already exist
// before any change: NewConfigPersistence, SaveTaskState, LoadTaskState and
// CleanupCompletedTasks on the persistence side, and NewMaintenanceQueue,
// SetPersistence, LoadTasksFromPersistence, AddTask, RegisterWorker,
// GetNextTask, GetTasks, CancelPendingTasksByType, NewMaintenanceManager,
// GetQueue, CancelTask, Start and Stop on the queue and manager side. Package
// constants are not referenced, so moving or renaming them does not affect
// the build.
package dash

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/seaweedfs/seaweedfs/weed/admin/maintenance"
)

// vfyTasksDir is the on-disk folder, under the admin data dir, that holds one
// .pb file per persisted task.
const vfyTasksDir = "tasks"

// vfyRetentionCap is the existing cap on finished-task files kept on disk
// ("only keep last 10 completed tasks").
const vfyRetentionCap = 10

// vfyCountTaskStateFiles returns the number of regular .pb files under
// <dir>/tasks. A missing folder counts as zero.
func vfyCountTaskStateFiles(t *testing.T, dir string) int {
	t.Helper()
	entries, err := os.ReadDir(filepath.Join(dir, vfyTasksDir))
	if os.IsNotExist(err) {
		return 0
	}
	if err != nil {
		t.Fatalf("read tasks dir: %v", err)
	}
	count := 0
	for _, entry := range entries {
		if !entry.IsDir() && filepath.Ext(entry.Name()) == ".pb" {
			count++
		}
	}
	return count
}

// vfyTaskFileExists reports whether <dir>/tasks/<id>.pb is on disk.
func vfyTaskFileExists(t *testing.T, dir, id string) bool {
	t.Helper()
	_, err := os.Stat(filepath.Join(dir, vfyTasksDir, id+".pb"))
	if err == nil {
		return true
	}
	if !os.IsNotExist(err) {
		t.Fatalf("stat task file %s: %v", id, err)
	}
	return false
}

// vfySeedTerminalTasks writes n finished task files with the given status,
// one minute apart, oldest first, and returns the ID of the newest one.
func vfySeedTerminalTasks(t *testing.T, cp *ConfigPersistence, prefix string, n int, status func(i int) maintenance.MaintenanceTaskStatus) string {
	t.Helper()
	base := time.Now().Add(-time.Hour)
	newest := ""
	for i := 0; i < n; i++ {
		finishedAt := base.Add(time.Duration(i) * time.Minute)
		id := fmt.Sprintf("%s_%02d", prefix, i)
		if err := cp.SaveTaskState(&maintenance.MaintenanceTask{
			ID:          id,
			Type:        "erasure_coding",
			Status:      status(i),
			CompletedAt: &finishedAt,
		}); err != nil {
			t.Fatalf("seed task %s: %v", id, err)
		}
		newest = id
	}
	return newest
}

// vfyRestart loads <dir>/tasks into a fresh queue, as startup does, and
// returns the status of every task that came back into the queue.
func vfyRestart(t *testing.T, dir string) map[string]maintenance.MaintenanceTaskStatus {
	t.Helper()
	queue := maintenance.NewMaintenanceQueue(nil)
	queue.SetPersistence(NewConfigPersistence(dir))
	if err := queue.LoadTasksFromPersistence(); err != nil {
		t.Fatalf("load tasks on restart: %v", err)
	}
	restored := make(map[string]maintenance.MaintenanceTaskStatus)
	for _, task := range queue.GetTasks("", "", 0) {
		restored[task.ID] = task.Status
	}
	return restored
}

// vfyFailingDeletes is a task store whose deletes always fail. Saves and
// loads go to the real files underneath.
type vfyFailingDeletes struct {
	*ConfigPersistence
}

var errVfyDeleteFailed = errors.New("delete refused by test store")

func (f *vfyFailingDeletes) DeleteTaskState(string) error { return errVfyDeleteFailed }

func (f *vfyFailingDeletes) DeleteAllTaskStates() error { return errVfyDeleteFailed }

// TestVerifyCancelScanCycleNoFileLeak covers the scan cycle, which cancels
// every pending task of a type and then re-detects. Cancelled is a terminal
// state, and terminal tasks keep no file on disk, so repeated add-then-cancel
// rounds must leave the tasks folder empty.
func TestVerifyCancelScanCycleNoFileLeak(t *testing.T) {
	dir := t.TempDir()
	cp := NewConfigPersistence(dir)

	queue := maintenance.NewMaintenanceQueue(nil)
	queue.SetPersistence(cp)

	const cycles = 3
	for cycle := 0; cycle < cycles; cycle++ {
		queue.AddTask(&maintenance.MaintenanceTask{
			ID:       fmt.Sprintf("scan_cycle_%d", cycle),
			Type:     "erasure_coding",
			VolumeID: uint32(cycle + 1),
			Server:   "server1",
		})
		if cancelled := queue.CancelPendingTasksByType("erasure_coding"); cancelled != 1 {
			t.Fatalf("cycle %d: cancelled %d pending tasks, want 1", cycle, cancelled)
		}
	}

	if n := vfyCountTaskStateFiles(t, dir); n != 0 {
		t.Errorf("%d task files on disk after %d add+cancel cycles, want 0 "+
			"(a cancelled task is finished and should not keep a file)", n, cycles)
	}
}

// TestVerifyManualCancelRemovesFile covers cancelling one pending task through
// the manager while another task is queued. The cancelled task's file has to
// go away with it, otherwise the next startup re-queues it as pending.
func TestVerifyManualCancelRemovesFile(t *testing.T) {
	dir := t.TempDir()
	cp := NewConfigPersistence(dir)

	manager := maintenance.NewMaintenanceManager(nil, nil, nil)
	queue := manager.GetQueue()
	queue.SetPersistence(cp)

	queue.AddTask(&maintenance.MaintenanceTask{
		ID:       "manual_cancel_1",
		Type:     "vacuum",
		VolumeID: 7,
		Server:   "server1",
	})
	queue.AddTask(&maintenance.MaintenanceTask{
		ID:       "manual_cancel_neighbour",
		Type:     "vacuum",
		VolumeID: 8,
		Server:   "server1",
	})
	if !vfyTaskFileExists(t, dir, "manual_cancel_1") {
		t.Fatalf("no file for the pending task right after AddTask")
	}

	if err := manager.CancelTask("manual_cancel_1"); err != nil {
		t.Fatalf("CancelTask on a pending task returned error: %v", err)
	}
	if vfyTaskFileExists(t, dir, "manual_cancel_1") {
		t.Errorf("the task cancelled through the manager still has a file on disk, want none " +
			"(a file left behind is read back on restart)")
	}
	if status, back := vfyRestart(t, dir)["manual_cancel_1"]; back {
		t.Errorf("the task cancelled through the manager came back after a restart with status %q", status)
	}
}

// TestVerifyCancelWithFailedDeleteStaysCancelled covers both cancel paths when
// the task store refuses to delete files. Whatever is left on disk must not
// bring either cancelled task back into the queue after a restart.
func TestVerifyCancelWithFailedDeleteStaysCancelled(t *testing.T) {
	dir := t.TempDir()
	store := &vfyFailingDeletes{ConfigPersistence: NewConfigPersistence(dir)}

	manager := maintenance.NewMaintenanceManager(nil, nil, nil)
	queue := manager.GetQueue()
	queue.SetPersistence(store)

	queue.AddTask(&maintenance.MaintenanceTask{
		ID:       "faildel_scan",
		Type:     "erasure_coding",
		VolumeID: 1,
		Server:   "server1",
	})
	queue.AddTask(&maintenance.MaintenanceTask{
		ID:       "faildel_manual",
		Type:     "vacuum",
		VolumeID: 2,
		Server:   "server1",
	})

	if cancelled := queue.CancelPendingTasksByType("erasure_coding"); cancelled != 1 {
		t.Fatalf("cancelled %d pending tasks, want 1", cancelled)
	}
	if err := manager.CancelTask("faildel_manual"); err != nil {
		t.Fatalf("CancelTask on a pending task returned error: %v", err)
	}

	restored := vfyRestart(t, dir)
	for _, id := range []string{"faildel_scan", "faildel_manual"} {
		if status, back := restored[id]; back {
			t.Errorf("cancelled task %s came back after a restart with status %q "+
				"(its file could not be deleted, and what was left still reads as live)", id, status)
		}
	}
}

// TestVerifyRunningManagerTrimsCancelledFiles covers cancelled-task files that
// show up on disk while the manager is already running. Its periodic cleanup
// (driven by cleanup_interval_seconds) has to bring them down to the same cap
// that completed and failed task files get, with nothing called by hand.
func TestVerifyRunningManagerTrimsCancelledFiles(t *testing.T) {
	// The cleanup loop may still be finishing a pass after Stop returns, so the
	// folder is removed best-effort instead of through t.TempDir.
	dir, err := os.MkdirTemp("", "vfy-cancelled-retention-")
	if err != nil {
		t.Fatalf("create temp dir: %v", err)
	}
	defer os.RemoveAll(dir)
	cp := NewConfigPersistence(dir)

	cfg := maintenance.DefaultMaintenanceConfig()
	cfg.CleanupIntervalSeconds = 1
	cfg.ScanIntervalSeconds = 3600 // no admin client here, so keep scans from firing
	manager := maintenance.NewMaintenanceManager(nil, cfg, nil)
	manager.GetQueue().SetPersistence(cp)
	if err := manager.Start(); err != nil {
		t.Fatalf("start maintenance manager: %v", err)
	}
	defer manager.Stop()

	// Written after Start, so only work done on the cleanup schedule can
	// remove them.
	const extra = 5
	vfySeedTerminalTasks(t, cp, "late_cancelled", vfyRetentionCap+extra, func(int) maintenance.MaintenanceTaskStatus {
		return maintenance.TaskStatusCancelled
	})

	deadline := time.Now().Add(15 * time.Second)
	n := vfyCountTaskStateFiles(t, dir)
	for n > vfyRetentionCap && time.Now().Before(deadline) {
		time.Sleep(100 * time.Millisecond)
		n = vfyCountTaskStateFiles(t, dir)
	}
	if n > vfyRetentionCap {
		t.Errorf("%d cancelled task files still on disk after the running manager's cleanup ticks, want at most %d "+
			"(cancelled files fall under the same cap as completed and failed ones)", n, vfyRetentionCap)
	}
}

// vfyCheckSurvivors requires each listed task to still have a file with the
// given status, and to be back in the queue as pending after a restart.
func vfyCheckSurvivors(t *testing.T, dir string, cp *ConfigPersistence, want map[string]maintenance.MaintenanceTaskStatus) {
	t.Helper()
	for id, status := range want {
		task, err := cp.LoadTaskState(id)
		if err != nil {
			t.Errorf("task %s was not cancelled but its file is gone: %v", id, err)
			continue
		}
		if task.Status != status {
			t.Errorf("task %s persisted with status %q, want %q", id, task.Status, status)
		}
	}
	restored := vfyRestart(t, dir)
	for id := range want {
		if status, back := restored[id]; !back {
			t.Errorf("task %s was not cancelled but is missing from the queue after a restart", id)
		} else if status != maintenance.TaskStatusPending {
			t.Errorf("task %s came back after a restart with status %q, want %q",
				id, status, maintenance.TaskStatusPending)
		}
	}
}

// TestVerifyCancelLeavesOtherTasksAlone covers the tasks that are not being
// cancelled. A scan-cycle cancel only touches pending tasks of its type, so an
// assigned task of that type and a pending task of another type keep their
// files. A single-task cancel through the manager only touches that task, so
// another pending task of the same type keeps its file. After a restart all
// of them are back in the queue.
func TestVerifyCancelLeavesOtherTasksAlone(t *testing.T) {
	// Scan-cycle cancel.
	scanDir := t.TempDir()
	scanCP := NewConfigPersistence(scanDir)
	queue := maintenance.NewMaintenanceQueue(nil)
	queue.SetPersistence(scanCP)

	queue.AddTask(&maintenance.MaintenanceTask{
		ID:       "keep_assigned",
		Type:     "erasure_coding",
		VolumeID: 1,
		Server:   "server1",
	})
	capabilities := []maintenance.MaintenanceTaskType{"erasure_coding"}
	queue.RegisterWorker(&maintenance.MaintenanceWorker{
		ID:            "worker1",
		Address:       "worker1:8080",
		Capabilities:  capabilities,
		MaxConcurrent: 1,
	})
	if got := queue.GetNextTask("worker1", capabilities); got == nil || got.ID != "keep_assigned" {
		t.Fatalf("GetNextTask did not hand out keep_assigned: %v", got)
	}
	queue.AddTask(&maintenance.MaintenanceTask{
		ID:       "drop_scan_pending",
		Type:     "erasure_coding",
		VolumeID: 2,
		Server:   "server1",
	})
	queue.AddTask(&maintenance.MaintenanceTask{
		ID:       "keep_other_type",
		Type:     "vacuum",
		VolumeID: 3,
		Server:   "server1",
	})
	if n := vfyCountTaskStateFiles(t, scanDir); n != 3 {
		t.Fatalf("%d task files after queueing three tasks, want 3 (each live task is persisted)", n)
	}
	if cancelled := queue.CancelPendingTasksByType("erasure_coding"); cancelled != 1 {
		t.Fatalf("scan-cycle cancel hit %d pending tasks, want 1", cancelled)
	}
	vfyCheckSurvivors(t, scanDir, scanCP, map[string]maintenance.MaintenanceTaskStatus{
		"keep_assigned":   maintenance.TaskStatusAssigned,
		"keep_other_type": maintenance.TaskStatusPending,
	})

	// Single-task cancel through the manager.
	manualDir := t.TempDir()
	manualCP := NewConfigPersistence(manualDir)
	manager := maintenance.NewMaintenanceManager(nil, nil, nil)
	manager.GetQueue().SetPersistence(manualCP)

	manager.GetQueue().AddTask(&maintenance.MaintenanceTask{
		ID:       "drop_manual_pending",
		Type:     "vacuum",
		VolumeID: 4,
		Server:   "server1",
	})
	manager.GetQueue().AddTask(&maintenance.MaintenanceTask{
		ID:       "keep_same_type",
		Type:     "vacuum",
		VolumeID: 5,
		Server:   "server1",
	})
	if err := manager.CancelTask("drop_manual_pending"); err != nil {
		t.Fatalf("CancelTask on a pending task returned error: %v", err)
	}
	vfyCheckSurvivors(t, manualDir, manualCP, map[string]maintenance.MaintenanceTaskStatus{
		"keep_same_type": maintenance.TaskStatusPending,
	})
}

// TestVerifyCompletedFailedPersistenceIntact covers the existing cap on
// completed and failed task files. Retention keeps at most the cap, keeps at
// least one file, and keeps the most recently finished task.
func TestVerifyCompletedFailedPersistenceIntact(t *testing.T) {
	dir := t.TempDir()
	cp := NewConfigPersistence(dir)

	const extra = 5
	newestID := vfySeedTerminalTasks(t, cp, "finished", vfyRetentionCap+extra, func(i int) maintenance.MaintenanceTaskStatus {
		if i%2 == 0 {
			return maintenance.TaskStatusCompleted
		}
		return maintenance.TaskStatusFailed
	})
	if n := vfyCountTaskStateFiles(t, dir); n != vfyRetentionCap+extra {
		t.Fatalf("%d task files after seeding, want %d", n, vfyRetentionCap+extra)
	}

	if err := cp.CleanupCompletedTasks(); err != nil {
		t.Fatalf("CleanupCompletedTasks: %v", err)
	}

	n := vfyCountTaskStateFiles(t, dir)
	if n > vfyRetentionCap {
		t.Errorf("%d completed/failed task files remain after retention, want at most %d", n, vfyRetentionCap)
	}
	if n == 0 {
		t.Errorf("retention removed every completed/failed task file, want the most recent ones kept up to the cap")
	}
	if _, err := cp.LoadTaskState(newestID); err != nil {
		t.Errorf("the most recently finished task %q should be kept by retention, but loading it failed: %v", newestID, err)
	}
}
