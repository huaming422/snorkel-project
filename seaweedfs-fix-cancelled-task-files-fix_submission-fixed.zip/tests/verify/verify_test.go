// Checks for the admin maintenance task-state files on disk.
//
// Every check looks at what ends up in <dataDir>/tasks/, the folder operators
// see growing, counting the per-task .pb files left there. The checks only go
// through entry points that already exist before any change:
// NewConfigPersistence, SaveTaskState, LoadTaskState and CleanupCompletedTasks
// on the persistence side, and NewMaintenanceQueue, SetPersistence, AddTask,
// CancelPendingTasksByType, NewMaintenanceManager, GetQueue, CancelTask, Start
// and Stop on the queue and manager side. Package constants are not referenced,
// so moving or renaming them does not affect the build.
package dash

import (
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/seaweedfs/seaweedfs/weed/admin/maintenance"
)

// vfyTasksDir is the on-disk folder, under the admin data dir, that holds one
// .pb file per persisted task.
const vfyTasksDir = "tasks"

// vfyRetentionCap is the existing cap on finished-task files kept on disk
// ("only keep last 10 completed tasks").
const vfyRetentionCap = 10

// vfyCountTaskStateFiles returns the number of regular .pb files under
// <dir>/tasks. A missing folder counts as zero.
func vfyCountTaskStateFiles(t *testing.T, dir string) int {
	t.Helper()
	entries, err := os.ReadDir(filepath.Join(dir, vfyTasksDir))
	if os.IsNotExist(err) {
		return 0
	}
	if err != nil {
		t.Fatalf("read tasks dir: %v", err)
	}
	count := 0
	for _, entry := range entries {
		if !entry.IsDir() && filepath.Ext(entry.Name()) == ".pb" {
			count++
		}
	}
	return count
}

// vfySeedTerminalTasks writes n finished task files with the given status,
// one minute apart, oldest first, and returns the ID of the newest one.
func vfySeedTerminalTasks(t *testing.T, dir string, cp *ConfigPersistence, prefix string, n int, status func(i int) maintenance.MaintenanceTaskStatus) string {
	t.Helper()
	base := time.Now().Add(-time.Hour)
	newest := ""
	for i := 0; i < n; i++ {
		finishedAt := base.Add(time.Duration(i) * time.Minute)
		id := fmt.Sprintf("%s_%02d", prefix, i)
		if err := cp.SaveTaskState(&maintenance.MaintenanceTask{
			ID:          id,
			Type:        "erasure_coding",
			Status:      status(i),
			CompletedAt: &finishedAt,
		}); err != nil {
			t.Fatalf("seed task %s: %v", id, err)
		}
		newest = id
	}
	if got := vfyCountTaskStateFiles(t, dir); got != n {
		t.Fatalf("%d task files after seeding, want %d", got, n)
	}
	return newest
}

// TestVerifyCancelScanCycleNoFileLeak covers the scan cycle, which cancels
// every pending task of a type and then re-detects. Cancelled is a terminal
// state, and terminal tasks keep no file on disk, so repeated add-then-cancel
// rounds must leave the tasks folder empty.
func TestVerifyCancelScanCycleNoFileLeak(t *testing.T) {
	dir := t.TempDir()
	cp := NewConfigPersistence(dir)

	queue := maintenance.NewMaintenanceQueue(nil)
	queue.SetPersistence(cp)

	const cycles = 3
	for cycle := 0; cycle < cycles; cycle++ {
		queue.AddTask(&maintenance.MaintenanceTask{
			ID:       fmt.Sprintf("scan_cycle_%d", cycle),
			Type:     "erasure_coding",
			VolumeID: uint32(cycle + 1),
			Server:   "server1",
		})
		if cancelled := queue.CancelPendingTasksByType("erasure_coding"); cancelled != 1 {
			t.Fatalf("cycle %d: cancelled %d pending tasks, want 1", cycle, cancelled)
		}
	}

	if n := vfyCountTaskStateFiles(t, dir); n != 0 {
		t.Errorf("%d task files on disk after %d add+cancel cycles, want 0 "+
			"(a cancelled task is finished and should not keep a file)", n, cycles)
	}
}

// TestVerifyManualCancelRemovesFile covers cancelling one pending task through
// the manager. Its file has to go away with it, otherwise the next startup
// re-queues the cancelled task as pending.
func TestVerifyManualCancelRemovesFile(t *testing.T) {
	dir := t.TempDir()
	cp := NewConfigPersistence(dir)

	manager := maintenance.NewMaintenanceManager(nil, nil, cp)
	queue := manager.GetQueue()
	queue.SetPersistence(cp)

	queue.AddTask(&maintenance.MaintenanceTask{
		ID:       "manual_cancel_1",
		Type:     "vacuum",
		VolumeID: 7,
		Server:   "server1",
	})
	if n := vfyCountTaskStateFiles(t, dir); n != 1 {
		t.Fatalf("%d task files after adding one pending task, want 1", n)
	}

	if err := manager.CancelTask("manual_cancel_1"); err != nil {
		t.Fatalf("CancelTask on a pending task returned error: %v", err)
	}
	if n := vfyCountTaskStateFiles(t, dir); n != 0 {
		t.Errorf("%d task files on disk after cancelling through the manager, want 0 "+
			"(a file left behind brings the task back as pending on restart)", n)
	}
}

// TestVerifyRunningManagerTrimsCancelledFiles covers cancelled-task files that
// are already on disk. While the manager is running, its periodic cleanup
// (driven by cleanup_interval_seconds) has to bring them down to the same cap
// that completed and failed task files get, with nothing called by hand.
func TestVerifyRunningManagerTrimsCancelledFiles(t *testing.T) {
	// The cleanup loop may still be finishing a pass after Stop returns, so the
	// folder is removed best-effort instead of through t.TempDir.
	dir, err := os.MkdirTemp("", "vfy-cancelled-retention-")
	if err != nil {
		t.Fatalf("create temp dir: %v", err)
	}
	defer os.RemoveAll(dir)
	cp := NewConfigPersistence(dir)

	const extra = 5
	vfySeedTerminalTasks(t, dir, cp, "old_cancelled", vfyRetentionCap+extra, func(int) maintenance.MaintenanceTaskStatus {
		return maintenance.TaskStatusCancelled
	})

	cfg := maintenance.DefaultMaintenanceConfig()
	cfg.CleanupIntervalSeconds = 1
	cfg.ScanIntervalSeconds = 3600 // no admin client here, so keep scans from firing
	manager := maintenance.NewMaintenanceManager(nil, cfg, nil)
	manager.GetQueue().SetPersistence(cp)
	if err := manager.Start(); err != nil {
		t.Fatalf("start maintenance manager: %v", err)
	}
	defer manager.Stop()

	deadline := time.Now().Add(15 * time.Second)
	n := vfyCountTaskStateFiles(t, dir)
	for n > vfyRetentionCap && time.Now().Before(deadline) {
		time.Sleep(100 * time.Millisecond)
		n = vfyCountTaskStateFiles(t, dir)
	}
	if n > vfyRetentionCap {
		t.Errorf("%d cancelled task files still on disk after the running manager's cleanup ticks, want at most %d "+
			"(cancelled files fall under the same cap as completed and failed ones)", n, vfyRetentionCap)
	}
}

// TestVerifyLivePendingTaskPersisted covers the other tasks in the folder.
// Cancelling one type must remove only that type's files. A task that is still
// pending keeps its file, and the file still says pending, so it survives a
// restart.
func TestVerifyLivePendingTaskPersisted(t *testing.T) {
	dir := t.TempDir()
	cp := NewConfigPersistence(dir)

	queue := maintenance.NewMaintenanceQueue(nil)
	queue.SetPersistence(cp)

	queue.AddTask(&maintenance.MaintenanceTask{
		ID:       "live_cancelled",
		Type:     "erasure_coding",
		VolumeID: 1,
		Server:   "server1",
	})
	queue.AddTask(&maintenance.MaintenanceTask{
		ID:       "live_survivor",
		Type:     "vacuum",
		VolumeID: 2,
		Server:   "server1",
	})
	if n := vfyCountTaskStateFiles(t, dir); n != 2 {
		t.Fatalf("%d task files after adding two pending tasks, want 2 "+
			"(each pending task is persisted)", n)
	}

	if cancelled := queue.CancelPendingTasksByType("erasure_coding"); cancelled != 1 {
		t.Fatalf("cancelled %d pending tasks of the first type, want 1", cancelled)
	}

	survivor, err := cp.LoadTaskState("live_survivor")
	if err != nil {
		t.Fatalf("the still-pending task's file should survive cancelling an unrelated task, "+
			"but loading it failed: %v", err)
	}
	if survivor.Status != maintenance.TaskStatusPending {
		t.Errorf("surviving task persisted with status %q, want %q",
			survivor.Status, maintenance.TaskStatusPending)
	}
}

// TestVerifyCompletedFailedPersistenceIntact covers the existing cap on
// completed and failed task files. Retention keeps at most the cap, keeps at
// least one file, and keeps the most recently finished task.
func TestVerifyCompletedFailedPersistenceIntact(t *testing.T) {
	dir := t.TempDir()
	cp := NewConfigPersistence(dir)

	const extra = 5
	newestID := vfySeedTerminalTasks(t, dir, cp, "finished", vfyRetentionCap+extra, func(i int) maintenance.MaintenanceTaskStatus {
		if i%2 == 0 {
			return maintenance.TaskStatusCompleted
		}
		return maintenance.TaskStatusFailed
	})

	if err := cp.CleanupCompletedTasks(); err != nil {
		t.Fatalf("CleanupCompletedTasks: %v", err)
	}

	n := vfyCountTaskStateFiles(t, dir)
	if n > vfyRetentionCap {
		t.Errorf("%d completed/failed task files remain after retention, want at most %d", n, vfyRetentionCap)
	}
	if n == 0 {
		t.Errorf("retention removed every completed/failed task file, want the most recent ones kept up to the cap")
	}
	if _, err := cp.LoadTaskState(newestID); err != nil {
		t.Errorf("the most recently finished task %q should be kept by retention, but loading it failed: %v", newestID, err)
	}
}
