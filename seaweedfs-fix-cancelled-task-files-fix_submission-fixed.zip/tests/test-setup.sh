#!/usr/bin/env bash
# Everything the verifier packages need is already in the image:
#   - Go 1.26.6 toolchain at /usr/local/go (GOTOOLCHAIN=local)
#   - a warm module cache (`go mod download` ran at build time)
#   - test binaries for weed/admin/dash and weed/admin/maintenance were built
#     once at build time, so their build cache is hot
#   - CGO_ENABLED=0, since the admin maintenance packages need no cgo
# The solve phase runs offline and nothing here reaches the network.
# The script stays as a no-op because test.sh always sources it.
set -euo pipefail
echo "[test-setup] no-op for seaweedfs-fix-cancelled-task-files (deps baked into image)"
