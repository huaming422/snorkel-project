## Task

Our SeaweedFS admin server has maintenance enabled, and the tasks folder in its data dir gets bigger the longer the server stays up.
Routine scan cycles leave a few thousand new .pb files in there per day, which will run the volume out of inodes before long.
Restarting clears most of them, but the count starts going up again right away.
Cancelling one pending task through the maintenance manager has a related problem.
That task's file is left behind, so the next restart puts it back in the queue as pending.
Find out where the files come from and fix both issues.
A cancelled task should stay cancelled across a restart even if its file can't be removed.
Any cancelled-task files that still end up in the folder while the server is up should be trimmed by the periodic maintenance cleanup, the one that runs every cleanup_interval_seconds.
Trim them with the limit that already exists for completed and failed task files, which keeps the 10 most recent.
