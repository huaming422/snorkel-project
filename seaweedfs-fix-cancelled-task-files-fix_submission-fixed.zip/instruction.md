## Task

Our SeaweedFS admin server runs with maintenance turned on, and the tasks folder under its data dir keeps growing for as long as the server is up.
Normal scan cycles add a few thousand .pb files there every day, and at that rate the disk will hit its inode limit.
A restart brings the count back down, then it starts climbing again.
There's a related bug when a single pending task is cancelled through the maintenance manager.
Its file stays on disk, so after the next restart that task is back in the queue as pending.
Please track down why the files pile up and fix both problems.
Cancelled-task files that are already sitting in the folder should also get trimmed while the server is running, under the same cap that completed and failed task files already get.
