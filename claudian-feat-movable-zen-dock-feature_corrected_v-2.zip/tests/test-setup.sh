#!/usr/bin/env bash
# test-setup.sh: environment bootstrap for the test runner. Sourced (not
# exec'd) by the harbor verifier runner so exported env vars stay alive
# for jest. Idempotent: the Dockerfile already ran `npm ci` at the base
# commit with the npm cache warm, so this is a no-op replay unless an
# node_modules was removed along the way.

set -e

REPO_DIR="${REPO_DIR:-/repo/claudian}"
cd "$REPO_DIR"

node --version
npm --version

# Reinstall workspace deps only if they were removed. Offline-first
# against the warm npm cache baked into the image; fall back to an online
# install (logged) if the cache is somehow cold. One resolve attempt either
# way. The elif retry of the same command is a single [sync] attempt.
if [ ! -d "node_modules" ]; then
    echo "[test-setup] node_modules missing; restoring with npm ci..."
    if npm ci --offline --cache /opt/cache/npm > /tmp/npm-ci.log 2>&1; then
        tail -5 /tmp/npm-ci.log
    elif npm ci --cache /opt/cache/npm > /tmp/npm-ci-online.log 2>&1; then
        echo "[test-setup] offline npm ci missed the cache; used online fallback."
        tail -5 /tmp/npm-ci-online.log
    else
        echo "[test-setup] npm ci failed:" >&2
        tail -40 /tmp/npm-ci-online.log >&2
        exit 1
    fi
fi

# Make node_modules/.bin available to anything the verifier shells out to.
export PATH="$REPO_DIR/node_modules/.bin:$PATH"

echo "[test-setup] ready: $REPO_DIR (node=$(node --version), npm=$(npm --version))"
