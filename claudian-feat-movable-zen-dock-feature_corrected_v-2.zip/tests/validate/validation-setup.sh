#!/usr/bin/env bash
# validation-setup.sh: prepares the environment for the jest DOM stories.
#
# The stories run the same ts-jest + jsdom suite as the storage check, so they need
# the repo's node_modules present and the project's own jest wrapper reachable. This
# extends test-setup.sh (which restores node_modules offline-first against the warm
# npm cache baked into the image) and then loudly checks that jest actually runs, a
# silent-skip here would let every story "pass" vacuously.
set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/claudian}"

# Inherit node_modules restoration + PATH export from the shared test setup.
if [ -f /tests/test-setup.sh ]; then
    # shellcheck disable=SC1091
    source /tests/test-setup.sh
fi

cd "$REPO_DIR"

# Loud preflight guard: the toolchain the stories depend on must be present and the
# jest wrapper must start. Fail now with a clear message rather than letting the
# stories mis-report as skips.
node --version
npm --version

if [ ! -d "$REPO_DIR/node_modules" ]; then
    echo "[validation-setup] FATAL: node_modules missing after test-setup.sh" >&2
    exit 1
fi

for module in jest ts-jest jest-environment-jsdom @testing-library/dom; do
    if [ ! -e "$REPO_DIR/node_modules/$module" ]; then
        echo "[validation-setup] FATAL: required dev dependency '$module' is not installed" >&2
        exit 1
    fi
done

# The stories drive the panel through scripts/run-jest.js; confirm it can boot jest.
if ! node scripts/run-jest.js --version > /tmp/validation-jest-version.log 2>&1; then
    echo "[validation-setup] FATAL: 'node scripts/run-jest.js --version' failed:" >&2
    cat /tmp/validation-jest-version.log >&2
    exit 1
fi

echo "[validation-setup] claudian zen validation env ready (jest $(cat /tmp/validation-jest-version.log | tail -1))"
