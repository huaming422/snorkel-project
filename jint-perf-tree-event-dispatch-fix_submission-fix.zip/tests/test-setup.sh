#!/usr/bin/env bash
# Verifier-phase setup. The .NET SDK (10.0.403, the rolled-forward 10.0.x), the full NuGet restore closure
# for Jint.Tests, and a warm Release build of Jint + Jint.Tests (net10.0) are all
# baked into the image at the base commit, so this is offline-first: a restore
# against the warm global-packages folder is a no-op, and the build only
# recompiles what the agent's edits touched.
set -euo pipefail

cd /repo/jint

export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1

# Offline-first restore: satisfied entirely from the image's baked NuGet
# global-packages folder (~/.nuget/packages). `--no-cache` keeps it from hitting
# the network for an HTTP cache refresh. A logged online fallback only matters if
# the agent added a package reference (not expected — the fix touches source only).
{ dotnet restore Jint.Tests/Jint.Tests.csproj --no-cache -p:NuGetAudit=false \
    > /tmp/restore.log 2>&1 && echo "[offline-first] dotnet restore satisfied from image"; } \
  || { echo "[fallback] online dotnet restore"; dotnet restore Jint.Tests/Jint.Tests.csproj -p:NuGetAudit=false; }

# Compile Jint + Jint.Tests with the agent's changes applied. Incremental against
# the warm cache; fail closed so a broken build surfaces here, not mid-verify.
dotnet build Jint.Tests/Jint.Tests.csproj -c Release -f net10.0 --no-restore
