#!/usr/bin/env bash
# Behavioral verifier for jint-perf-tree-event-dispatch.
#
# The verifier is one NUnit fixture (TreeDispatchVerifier) that lives in the
# Jint.Tests project — the only assembly on Jint's InternalsVisibleTo list, so
# the only one that can reach the internal JsEventTarget seams the dispatch is
# driven through. verify/ is staged whole alongside this script, so the test
# file sits next to it; copy it into the test tree, build, and run only that
# fixture. The copy is removed on exit whether the run passes or fails.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="/repo/jint"
DEST_DIR="${REPO_DIR}/Jint.Tests/Runtime/WebApi"
DEST="${DEST_DIR}/TreeDispatchVerifier.cs"

cleanup() { rm -f "${DEST}"; }
trap cleanup EXIT

cp "${SCRIPT_DIR}/TreeDispatchVerifier.cs" "${DEST}"

cd "${REPO_DIR}"

# Packages are restored and the project is built by tests/test-setup.sh before
# this runs; --no-restore keeps the offline-baked restore and lets dotnet test
# compile the freshly-copied fixture incrementally.
dotnet test Jint.Tests/Jint.Tests.csproj \
  -c Release \
  -f net10.0 \
  --no-restore \
  --filter "FullyQualifiedName~TreeDispatchVerifier"
