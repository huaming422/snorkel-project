## Task

We've had reports that DOM event dispatch in WebApi Events gets pathologically slow on deep host trees. Each node in the host's DOM-like structure acts as an event target. A single dispatch from a moderately deep node appears to read tree structure roughly in proportion to the square of its depth. It should scale linearly with depth.

A separate report concerns malformed hosts whose ancestry loops. The event path follows `GetParent`; root lookup follows `TreeParent`; retargeting can also follow `ShadowHost` links through successive shadow trees. Any of these walks can fail to terminate if a host makes a target its own ancestor. Related targets can be supplied by the embedder even though script cannot set one on the event types currently exposed by WebApi Events.

Fix both problems in the Events dispatch path: make one dispatch linear in tree depth and refuse non-terminating host ancestry promptly with a clear error. The error must reach the embedder even if the dispatching script wraps the call in `try/catch`. Preserve the cheap path for ordinary targets that do not participate in a tree.

Measure the cost by counting reads of host tree structure during one dispatch, rather than timing it. Rework the internals as needed, but keep the public API and dispatch behavior intact: listener ordering, target retargeting across shadow boundaries, `composedPath()`, and closed-subtree hiding.
