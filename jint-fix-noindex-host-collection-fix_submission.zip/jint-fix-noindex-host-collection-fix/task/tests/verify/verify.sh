#!/usr/bin/env bash
#
# Behavioral verifier for jint-fix-noindex-host-collection.
#
# Drops a self-contained xUnit class into the pre-existing embedder-view test
# project (Jint.Tests.PublicInterface - the suite with no internals access) and
# runs it with `dotnet test`. Every assertion drives the public embedding API
# only: `new Engine(...)`, `SetValue(...)`, `Evaluate(...)`. No engine internal
# is referenced, so any fix that produces the specified script-level answers
# passes regardless of how it is decomposed.
#
# The project reference pulls the (candidate-edited) library source, so this
# recompiles the library and the suite before running. Everything needed is
# baked into the image (NuGet closure under /opt/nuget/packages, the net10.0
# assets warmed), so this installs nothing and restores from the warm cache.
#
# Exit codes:
#   0 - every case passed
#   non-zero - a case failed, the build failed, or the filter matched no cases

set -euo pipefail

REPO_DIR="/repo/jint"
PROJECT_DIR="${REPO_DIR}/Jint.Tests.PublicInterface"
PROJECT="${PROJECT_DIR}/Jint.Tests.PublicInterface.csproj"
VERIFY_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TEST_CLASS="VerifyHostCountedCollection"
SRC="${VERIFY_DIR}/${TEST_CLASS}.cs"
LOG="/tmp/verify-dotnet.log"

# dotnet / NuGet: point at the warm offline cache and stay quiet.
export NUGET_PACKAGES="${NUGET_PACKAGES:-/opt/nuget/packages}"
export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1

# The SDK-style project globs *.cs, so copying the class in makes it compile.
cp "${SRC}" "${PROJECT_DIR}/${TEST_CLASS}.cs"

cd "${REPO_DIR}"

set +e
dotnet test "${PROJECT}" \
    -c Release -f net10.0 \
    --no-restore \
    --filter "FullyQualifiedName~${TEST_CLASS}" \
    > "${LOG}" 2>&1
status=$?
set -e

echo "===== dotnet test output (tail) ====="
tail -n 60 "${LOG}"
echo "====================================="

if [ "${status}" -ne 0 ]; then
    echo "verify: dotnet test exited ${status}" >&2
    exit "${status}"
fi

# A filter that matches no cases, or a run that executes nothing, exits 0 in
# dotnet test - which would be a silent false pass. Require positive evidence
# that cases actually ran: a VSTest summary line with a non-zero Total.
if grep -qiE "No test (matches|is available|source files)" "${LOG}"; then
    echo "verify: filter matched no cases - ${TEST_CLASS} did not run" >&2
    exit 1
fi

total="$(grep -oiE "Total:[[:space:]]*[0-9]+" "${LOG}" | tail -n1 | grep -oE "[0-9]+" || true)"
if [ -z "${total}" ] || [ "${total}" -eq 0 ]; then
    echo "verify: no cases executed (Total=${total:-unknown}) - treating as failure" >&2
    exit 1
fi

echo "verify: ${total} cases executed, all passed"
exit 0
