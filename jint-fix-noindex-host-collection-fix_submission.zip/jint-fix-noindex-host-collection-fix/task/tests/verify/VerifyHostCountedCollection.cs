#nullable enable

using System.Collections;
using Jint;
using Jint.Runtime;

namespace Jint.Tests.PublicInterface;

/// <summary>
/// Pins the behaviour of <c>Array.prototype</c> generics, spread, <c>for..of</c>, <c>Array.from</c>
/// and array destructuring when an embedder hands the engine a host CLR collection that reports a
/// <c>Count</c> but exposes no integer index - a <see cref="Queue{T}"/>, <see cref="Stack{T}"/>,
/// <see cref="LinkedList{T}"/>, <see cref="SortedSet{T}"/>, a <see cref="HashSet{T}"/>, or an
/// embedder's own non-generic <see cref="System.Collections.ICollection"/>.
///
/// <para>
/// Each shape is array-like (it has a <c>Count</c>, so the wrapper carries <c>Array.prototype</c>
/// and a live <c>length</c>) yet has no element at any index. The index-reading generics must honour
/// <c>length</c> and read <see langword="undefined"/> at each slot, while every iterating form keeps
/// yielding the real elements through the wrapper's iterator. Nothing a script does over one of these
/// may surface to the host as anything other than a <see cref="JavaScriptException"/>.
/// </para>
///
/// <para>
/// A <see cref="List{T}"/> keeps the indexable behaviour as a contrast, and an
/// <see cref="System.Collections.ICollection"/> that adds an integer indexer (without being an
/// <c>IList</c>) must surface its elements through that indexer.
/// </para>
/// </summary>
public class VerifyHostCountedCollection
{
    public static TheoryData<string> CountedButNotIndexed => new TheoryData<string>
    {
        nameof(Queue<int>),
        nameof(Stack<int>),
        nameof(LinkedList<int>),
        nameof(SortedSet<int>),
        nameof(HashSet<int>),
        nameof(BareCountedCollection),
    };

    private static object MakeCollection(string kind) => kind switch
    {
        // a Stack enumerates most-recently-pushed first, so seed it reversed to iterate 1, 2, 3
        nameof(Queue<int>) => new Queue<int>(new[] { 1, 2, 3 }),
        nameof(Stack<int>) => new Stack<int>(new[] { 3, 2, 1 }),
        nameof(LinkedList<int>) => new LinkedList<int>(new[] { 1, 2, 3 }),
        nameof(SortedSet<int>) => new SortedSet<int> { 1, 2, 3 },
        nameof(BareCountedCollection) => new BareCountedCollection(),
        _ => new HashSet<int> { 1, 2, 3 },
    };

    private static Engine MakeEngine(object host, Action<Options>? configure = null)
    {
        var engine = new Engine(options => configure?.Invoke(options));
        engine.SetValue("host", host);
        return engine;
    }

    [Theory]
    [MemberData(nameof(CountedButNotIndexed))]
    public void LengthIsHonouredButIndexReadsFindNothing(string kind)
    {
        var engine = MakeEngine(MakeCollection(kind));

        engine.Evaluate("host.length").Should().Be(3);
        engine.Evaluate("Object.getPrototypeOf(host) === Array.prototype").Should().BeTrue();

        // there is no element at any index, so the generics see only the gaps
        engine.Evaluate("host[0]").Should().BeUndefined();
        engine.Evaluate("'0' in host").Should().BeFalse();
        engine.Evaluate("Array.prototype.join.call(host, '-')").Should().Be("--");
        engine.Evaluate("Array.prototype.map.call(host, function (x) { return x; }).join('-')").Should().Be("--");
        engine.Evaluate("Array.prototype.slice.call(host).length").Should().Be(3);
        engine.Evaluate("Array.prototype.filter.call(host, function () { return true; }).length").Should().Be(0);
        engine.Evaluate("Array.prototype.indexOf.call(host, 2)").Should().Be(-1);
        engine.Evaluate("Array.prototype.includes.call(host, 2)").Should().BeFalse();
        engine.Evaluate("""
            var visited = 0;
            Array.prototype.forEach.call(host, function () { visited++; });
            visited;
            """).Should().Be(0);
    }

    [Theory]
    [MemberData(nameof(CountedButNotIndexed))]
    public void EveryIteratingFormYieldsTheRealElements(string kind)
    {
        var engine = MakeEngine(MakeCollection(kind));

        engine.Evaluate("[...host].join('-')").Should().Be("1-2-3");
        engine.Evaluate("Array.from(host).join('-')").Should().Be("1-2-3");
        engine.Evaluate("(function () { var r = []; for (var x of host) { r.push(x); } return r.join('-'); })()")
            .Should().Be("1-2-3");
    }

    [Theory]
    [MemberData(nameof(CountedButNotIndexed))]
    public void DestructuringAgreesWithSpread(string kind)
    {
        var engine = MakeEngine(MakeCollection(kind));

        engine.Evaluate("(function () { var [...r] = host; return r.join('-'); })()").Should().Be("1-2-3");
        engine.Evaluate("(function () { var [first] = host; return first; })()").Should().Be(1);
        engine.Evaluate("(function () { var [, second] = host; return second; })()").Should().Be(2);
    }

    [Theory]
    [MemberData(nameof(CountedButNotIndexed))]
    public void NothingSurfacesExceptAJavaScriptException(string kind)
    {
        // whatever the answer for each operation is, reads and writes alike must stay inside the engine:
        // the only exception a script may raise to the host is a JavaScriptException
        string[] scripts =
        [
            "Array.prototype.join.call(host, '-')",
            "Array.prototype.map.call(host, function (x) { return x; })",
            "Array.prototype.filter.call(host, function () { return true; })",
            "Array.prototype.forEach.call(host, function () { })",
            "Array.prototype.indexOf.call(host, 2)",
            "Array.prototype.lastIndexOf.call(host, 2)",
            "Array.prototype.includes.call(host, 2)",
            "Array.prototype.slice.call(host)",
            "Array.prototype.every.call(host, function () { return true; })",
            "Array.prototype.some.call(host, function () { return true; })",
            "Array.prototype.reduce.call(host, function (a, b) { return a + b; }, 0)",
            "Array.prototype.flat.call(host)",
            "Array.prototype.toString.call(host)",
            "[...host]",
            "Array.from(host)",
            "(function () { var [...r] = host; return r; })()",
            "Math.max.apply(null, host)",
            "JSON.stringify(host)",
            "try { Array.prototype.sort.call(host); } catch (e) { }",
            "try { Array.prototype.reverse.call(host); } catch (e) { }",
            "try { Array.prototype.push.call(host, 4); } catch (e) { }",
            "try { Array.prototype.pop.call(host); } catch (e) { }",
            "try { Array.prototype.fill.call(host, 0); } catch (e) { }",
            "try { Array.prototype.splice.call(host, 0, 1); } catch (e) { }",
        ];

        foreach (var script in scripts)
        {
            var engine = MakeEngine(MakeCollection(kind));
            try
            {
                engine.Evaluate(script);
            }
            catch (JavaScriptException)
            {
                // a script-level error is a legitimate answer; a CLR exception is the defect
            }
            catch (Exception exception)
            {
                Assert.Fail($"'{script}' leaked a {exception.GetType().FullName} for a {kind}");
            }
        }
    }

    [Theory]
    [MemberData(nameof(CountedButNotIndexed))]
    public void GrowingRaisesACatchableTypeError(string kind)
    {
        var engine = MakeEngine(MakeCollection(kind));

        // push writes "length", which forwards to a read-only count: an ordinary JavaScript refusal
        engine.Evaluate("""
            try {
                Array.prototype.push.call(host, 4);
                'no throw';
            } catch (e) {
                e instanceof TypeError ? 'TypeError' : 'other: ' + e;
            }
            """).Should().Be("TypeError");

        var throwsToHost = () => engine.Evaluate("Array.prototype.push.call(host, 4)");
        throwsToHost.Should().Throw<JavaScriptException>();
    }

    [Theory]
    [MemberData(nameof(CountedButNotIndexed))]
    public void OrderMutatingGenericsAreNoOps(string kind)
    {
        var engine = MakeEngine(MakeCollection(kind));

        engine.Evaluate("Array.prototype.sort.call(host) === host").Should().BeTrue();
        engine.Evaluate("Array.prototype.reverse.call(host) === host").Should().BeTrue();
        engine.Evaluate("[...host].join('-')").Should().Be("1-2-3");
    }

    [Fact]
    public void AnIntegerIndexerDecidesWhetherElementsAreFound()
    {
        // the same non-generic collection shape, now with an integer indexer that is not an IList:
        // it takes the identical lane, and the generics must find every element through that indexer
        var engine = MakeEngine(new IndexedCountedCollection());

        engine.Evaluate("host.length").Should().Be(3);
        engine.Evaluate("host[0]").Should().Be(1);
        engine.Evaluate("Array.prototype.join.call(host, '-')").Should().Be("1-2-3");
        engine.Evaluate("Array.prototype.indexOf.call(host, 2)").Should().Be(1);
        engine.Evaluate("Array.prototype.filter.call(host, function (x) { return x > 1; }).join('-')").Should().Be("2-3");
        engine.Evaluate("(function () { var [...r] = host; return r.join('-'); })()").Should().Be("1-2-3");
    }

    [Fact]
    public void AnIndexableListStaysUnchanged()
    {
        var engine = MakeEngine(new List<int> { 1, 2, 3 });

        engine.Evaluate("host.length").Should().Be(3);
        engine.Evaluate("host[0]").Should().Be(1);
        engine.Evaluate("'0' in host").Should().BeTrue();
        engine.Evaluate("Array.prototype.join.call(host, '-')").Should().Be("1-2-3");
        engine.Evaluate("Array.prototype.indexOf.call(host, 2)").Should().Be(1);
        engine.Evaluate("Array.prototype.map.call(host, function (x) { return x * 2; }).join('-')").Should().Be("2-4-6");
        engine.Evaluate("(function () { var [...r] = host; return r.join('-'); })()").Should().Be("1-2-3");
    }

    [Theory]
    [MemberData(nameof(CountedButNotIndexed))]
    public void ConversionModesChangeNothing(string kind)
    {
        foreach (var configure in new Action<Options>[]
                 {
                     o => o.Interop.ArrayConversion = ArrayConversionMode.LiveView,
                     o => o.Interop.EnumerableConversion = EnumerableConversionMode.Snapshot,
                 })
        {
            var engine = MakeEngine(MakeCollection(kind), configure);

            engine.Evaluate("host.length").Should().Be(3);
            engine.Evaluate("Array.prototype.join.call(host, '-')").Should().Be("--");
            engine.Evaluate("[...host].join('-')").Should().Be("1-2-3");
        }
    }

    /// <summary>
    /// An embedder collection reachable through the non-generic <see cref="System.Collections.ICollection"/>
    /// alone: a count and an enumerator, no index of any kind.
    /// </summary>
    private sealed class BareCountedCollection : ICollection
    {
        private readonly int[] _items = [1, 2, 3];

        public int Count => _items.Length;

        public bool IsSynchronized => false;

        public object SyncRoot => this;

        public void CopyTo(Array array, int index) => _items.CopyTo(array, index);

        public IEnumerator GetEnumerator() => _items.GetEnumerator();
    }

    /// <summary>
    /// The same shape with an integer indexer that is deliberately not an <see cref="IList"/>; the members
    /// exist only to be reached by reflection.
    /// </summary>
    private sealed class IndexedCountedCollection : ICollection
    {
        private readonly int[] _items = [1, 2, 3];

        public int Count => _items.Length;

        public bool IsSynchronized => false;

        public object SyncRoot => this;

        public int this[int index] => _items[index];

        public void CopyTo(Array array, int index) => _items.CopyTo(array, index);

        public IEnumerator GetEnumerator() => _items.GetEnumerator();
    }
}
