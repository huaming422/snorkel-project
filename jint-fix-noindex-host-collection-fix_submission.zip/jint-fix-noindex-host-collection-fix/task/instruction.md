## Task

embedders hand us plain .NET collections and expect to drive them from script like arrays, and mostly that works. but for some collection shapes it blows up: a script running array operations over the handed-in object dies with a raw .NET exception that escapes the engine entirely. our host-side try/catch never sees it, and a script-level try/catch never sees it either, so the whole evaluation just falls over.

list-backed collections are fine, it's the other shapes that break. it first came in as a couple of specific collection types but it looks broader than those. dig in and make these collections behave sensibly under array operations.
