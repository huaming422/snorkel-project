"""Behavioral checks for upstream-WebSocket transport-liveness classification.

These tests drive the two pre-existing upstream-WebSocket adapter classes
(``WebsocketsUpstreamWebSocket`` for the direct ``websockets`` path and
``CodexUpstreamWebSocket`` for the routed ``aiohttp`` path) in-process with
fake transports. No network, no services, no running proxy.

The subject behaviour: after a connectivity transition a socket can go
half-open — the transport is dead but neither a read nor a write ever raises.
A transport-level liveness watchdog (ping/pong) surfaces that as a
locally-initiated keepalive-timeout close on the direct path and as a stored
``ServerTimeoutError`` ("No PONG received after ...") on the routed path. Any
correct implementation must normalise all three surfacings — a receive that
returns ERROR, a later receive that returns CLOSED carrying the stored
timeout, and a send that fails while the timeout is stored — to a single
account-neutral transport code, AND must refuse to apply that neutral
classification to a peer-initiated close that merely carries the same code
and reason text.

The concrete string value of the neutral code is an implementation choice, so
it is never hardcoded here: it is discovered at runtime from the adapter's own
output and then checked for consistency (same code across every path) and
distinctness (a peer-initiated marker is NOT classified as neutral).
"""

from __future__ import annotations

from typing import Any, cast

import aiohttp
import pytest
from websockets.exceptions import ConnectionClosedError
from websockets.frames import Close

import app.core.clients.proxy_websocket as proxy_websocket_module
from app.core.clients.codex import CodexWebSocketResult
from app.core.clients.proxy_websocket import (
    CodexUpstreamWebSocket,
    UpstreamWebSocketTransportError,
    WebsocketsUpstreamWebSocket,
    connect_responses_websocket,
)
from app.core.config.settings import get_settings
from app.core.upstream_proxy import ResolvedProxyEndpoint, ResolvedUpstreamRoute

_KEEPALIVE_REASON = "keepalive ping timeout"
_HEARTBEAT_MESSAGE = "No PONG received after 60.0 seconds"


class _FakeDirectConnection:
    """Minimal ``websockets`` connection whose ``recv`` raises a close error."""

    def __init__(self, exc: BaseException) -> None:
        self._exc = exc

    async def recv(self) -> object:
        raise self._exc


class _FakeAiohttpWebSocket:
    """Minimal ``aiohttp`` websocket exposing the surface the adapter uses."""

    def __init__(
        self,
        *,
        receive_message: aiohttp.WSMessage | None = None,
        send_exc: BaseException | None = None,
        stored_exc: BaseException | None = None,
    ) -> None:
        self._receive_message = receive_message
        self._send_exc = send_exc
        self._stored_exc = stored_exc
        self.close_code: int | None = None

    async def receive(self) -> aiohttp.WSMessage:
        assert self._receive_message is not None
        return self._receive_message

    async def send_str(self, data: str) -> None:
        del data
        if self._send_exc is not None:
            raise self._send_exc

    async def send_bytes(self, data: bytes) -> None:
        del data
        if self._send_exc is not None:
            raise self._send_exc

    def exception(self) -> BaseException | None:
        return self._stored_exc

    async def close(self, *, code: int = 1000, message: bytes = b"") -> None:
        del message
        self.close_code = code


def _direct_adapter(exc: BaseException) -> WebsocketsUpstreamWebSocket:
    return WebsocketsUpstreamWebSocket(cast(Any, _FakeDirectConnection(exc)))


async def _classify_direct_local_keepalive() -> str | None:
    """Direct path: locally-initiated 1011 keepalive-timeout close."""
    exc = ConnectionClosedError(None, Close(1011, _KEEPALIVE_REASON))
    message = await _direct_adapter(exc).receive()
    assert message.kind == "error"
    return message.error_code


async def _classify_routed_immediate_timeout() -> str | None:
    """Routed path: heartbeat timeout delivered as an immediate ERROR frame."""
    ws = _FakeAiohttpWebSocket(
        receive_message=aiohttp.WSMessage(
            aiohttp.WSMsgType.ERROR,
            aiohttp.ServerTimeoutError(_HEARTBEAT_MESSAGE),
            None,
        ),
    )
    message = await CodexUpstreamWebSocket(ws).receive()
    assert message.kind == "error"
    return message.error_code


@pytest.mark.asyncio
async def test_direct_adapter_classifies_local_keepalive_timeout() -> None:
    """A locally-sent keepalive-timeout close is a classified transport error.

    The watchdog's own close must surface as ``kind == "error"`` carrying a
    distinct, non-absent account-neutral code — not an unclassified failure
    that relay owners would silently map to their stream-incomplete contract.
    """
    local_code = await _classify_direct_local_keepalive()
    routed_code = await _classify_routed_immediate_timeout()

    assert local_code is not None
    # Both adapters must resolve their liveness surfacing to one shared code.
    assert local_code == routed_code


@pytest.mark.asyncio
async def test_direct_adapter_rejects_peer_keepalive_marker() -> None:
    """A peer-initiated close carrying the same code+reason is NOT neutral.

    Provenance boundary: the identical 1011 / "keepalive ping timeout" close
    can legitimately arrive from the peer (received-then-sent). That is an
    ordinary account-affecting failure, so the neutral liveness code must NOT
    be applied — the relay-boundary code is absent. An implementation that
    keys on the reason text without send-first ordering fails here.
    """
    exc = ConnectionClosedError(
        Close(1011, _KEEPALIVE_REASON),
        Close(1011, _KEEPALIVE_REASON),
        True,
    )
    message = await _direct_adapter(exc).receive()

    assert message.kind == "error"
    assert message.error_code is None


@pytest.mark.asyncio
async def test_routed_adapter_classifies_immediate_heartbeat_timeout() -> None:
    """A heartbeat ``ServerTimeoutError`` delivered as ERROR is classified."""
    routed_code = await _classify_routed_immediate_timeout()

    assert routed_code is not None


@pytest.mark.asyncio
async def test_routed_adapter_classifies_stored_heartbeat_timeout() -> None:
    """A heartbeat timeout stored between receives still classifies.

    When the watchdog fires with no live waiter, aiohttp stores the timeout
    and the next ``receive`` returns CLOSED. The adapter must consult the
    stored exception and classify it identically to the immediate case,
    rather than reporting an ordinary clean close.
    """
    stored = aiohttp.ServerTimeoutError(_HEARTBEAT_MESSAGE)
    ws = _FakeAiohttpWebSocket(
        receive_message=aiohttp.WSMessage(aiohttp.WSMsgType.CLOSED, None, None),
        stored_exc=stored,
    )
    message = await CodexUpstreamWebSocket(ws).receive()
    routed_code = await _classify_routed_immediate_timeout()

    assert message.kind == "error"
    assert message.error_code is not None
    assert message.error_code == routed_code


@pytest.mark.asyncio
@pytest.mark.parametrize("payload", ["request", b"request"], ids=["text", "bytes"])
async def test_routed_adapter_send_carries_liveness_code(payload: str | bytes) -> None:
    """A send that fails while a heartbeat timeout is stored carries the code.

    A liveness failure detected during a send must classify identically to one
    detected during a receive: the raised transport error carries the same
    neutral code, so the sending path and the reading path agree.
    """
    stored = aiohttp.ServerTimeoutError(_HEARTBEAT_MESSAGE)
    ws = _FakeAiohttpWebSocket(
        send_exc=RuntimeError("Cannot write to closing transport"),
        stored_exc=stored,
    )
    adapter = CodexUpstreamWebSocket(ws)
    routed_code = await _classify_routed_immediate_timeout()

    with pytest.raises(UpstreamWebSocketTransportError) as exc_info:
        if isinstance(payload, str):
            await adapter.send_text(payload)
        else:
            await adapter.send_bytes(payload)

    assert exc_info.value.error_code is not None
    assert exc_info.value.error_code == routed_code


@pytest.mark.asyncio
async def test_liveness_code_is_unified_and_distinct_from_peer_marker() -> None:
    """One neutral code spans both adapters; the peer marker is excluded.

    This pins the full contract without naming the implementation's string:
    the direct local watchdog close, the routed immediate timeout, the routed
    stored timeout, and the send-time timeout all resolve to one non-absent
    code, while a peer-initiated close carrying the same marker resolves to an
    absent (ordinary) code.
    """
    local_code = await _classify_direct_local_keepalive()
    routed_code = await _classify_routed_immediate_timeout()

    peer_exc = ConnectionClosedError(
        Close(1011, _KEEPALIVE_REASON),
        Close(1011, _KEEPALIVE_REASON),
        True,
    )
    peer_message = await _direct_adapter(peer_exc).receive()

    assert local_code is not None
    assert routed_code is not None
    assert local_code == routed_code
    assert peer_message.error_code is None
    assert local_code != peer_message.error_code


def _responses_route() -> ResolvedUpstreamRoute:
    """A minimal resolved route so the Responses connect takes the routed path."""
    return ResolvedUpstreamRoute(
        mode="account_bound",
        pool_id="pool_1",
        endpoint=ResolvedProxyEndpoint("ep_1", "http", "proxy.test", 8080),
    )


class _CaptureRoutedCodexClient:
    """Routed opener that records the kwargs the connect path hands it.

    Mirrors the real ``CodexClient.open_ws_with_route_metadata`` surface the
    Responses connect prefers. It performs no I/O: it only captures the
    heartbeat watchdog argument and returns a fake upstream websocket so the
    adapter can be constructed.
    """

    def __init__(self) -> None:
        self.kwargs: dict[str, Any] = {}

    async def open_ws_with_route_metadata(
        self, url: str, *, route: ResolvedUpstreamRoute, **kwargs: Any
    ) -> CodexWebSocketResult:
        del url
        self.kwargs = kwargs
        return CodexWebSocketResult(
            websocket=_FakeAiohttpWebSocket(),
            context=None,
            route=route,
            fallback_used=False,
        )

    async def close(self) -> None:
        return None


@pytest.mark.asyncio
async def test_responses_routed_connect_enables_heartbeat_watchdog() -> None:
    """The routed Responses connect must arm the aiohttp heartbeat watchdog.

    Classifying a liveness timeout is inert if the watchdog that produces it is
    never turned on. Driving the real connect path for the Responses policy, the
    opener must receive a non-absent ``heartbeat`` so a black-holed route is
    detected instead of stalling for hours. The value must reuse the existing
    downstream idle-timeout setting rather than introduce a new knob.
    """
    client = _CaptureRoutedCodexClient()

    await connect_responses_websocket(
        {"user-agent": "codex"},
        "access",
        "chatgpt_account",
        base_url="https://chatgpt.test/backend-api",
        route=_responses_route(),
        codex_client=cast(Any, client),
    )

    idle_timeout = get_settings().proxy_downstream_websocket_idle_timeout_seconds
    assert client.kwargs.get("heartbeat") is not None
    assert client.kwargs["heartbeat"] == idle_timeout


@pytest.mark.asyncio
async def test_responses_direct_connect_enables_ping_timeout_watchdog(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The direct Responses connect must arm the websockets ping/pong watchdog.

    With no resolved route the Responses connect uses the direct ``websockets``
    client. That client only detects a half-open socket when a ``ping_timeout``
    is supplied, so the policy must pass a non-absent value equal to the reused
    downstream idle-timeout setting. A patch that only classifies the timeout,
    or that arms only the routed path, leaves this absent and fails here.
    """
    captured: dict[str, Any] = {}

    async def fake_websocket_connect(url: str, **kwargs: Any) -> Any:
        del url
        captured.update(kwargs)
        return object()

    monkeypatch.setattr(proxy_websocket_module, "websocket_connect", fake_websocket_connect)

    await connect_responses_websocket(
        {"user-agent": "codex"},
        "access",
        "chatgpt_account",
        base_url="https://chatgpt.test/backend-api",
        route=None,
        allow_direct_egress=True,
    )

    idle_timeout = get_settings().proxy_downstream_websocket_idle_timeout_seconds
    assert captured.get("ping_timeout") is not None
    assert captured["ping_timeout"] == idle_timeout


@pytest.mark.asyncio
async def test_account_neutral_predicate_recognizes_liveness_code() -> None:
    """If the module exposes a neutrality predicate, it accepts the code.

    This is a light pass-to-pass consistency check, guarded so an
    implementation that does not expose this exact helper name is not
    penalised: the discovered neutral code is recognised as account-neutral,
    and an unrelated failure code is not.
    """
    predicate = getattr(
        proxy_websocket_module, "is_account_neutral_websocket_error_code", None
    )
    if not callable(predicate):
        pytest.skip("module does not expose a public neutrality predicate")

    routed_code = await _classify_routed_immediate_timeout()
    assert routed_code is not None
    assert predicate(routed_code) is True
    assert predicate("upstream_unavailable") is False
