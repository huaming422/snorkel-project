#!/usr/bin/env bash
# test-setup.sh — sourced (not executed) before the verifier runs.
#
# The verifier drives the pre-existing upstream-WebSocket adapter classes
# (WebsocketsUpstreamWebSocket / CodexUpstreamWebSocket in
# app.core.clients.proxy_websocket) in-process with fake transports. No
# network, no services, no running proxy. It only needs the repo package and
# its dependency closure importable under the repo venv (/opt/venv), which the
# image already baked at the base commit — so this is normally an offline no-op.
#
# Offline-first with a logged online fallback: the agent phase runs with no
# network, but the verifier phase may have network, so if the baked env is
# somehow stale we retry online rather than fail.
set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/codex-lb}"
export REPO_DIR
cd "$REPO_DIR"

export UV_OFFLINE=1

LOG=/tmp/test-setup-install.log
if uv sync --frozen --offline > "$LOG" 2>&1; then
    echo "test-setup.sh: dependency closure satisfied offline from the image."
elif UV_OFFLINE=0 uv sync --frozen >> "$LOG" 2>&1; then
    echo "test-setup.sh: deps installed online (image bake was stale)."
else
    echo "test-setup.sh: dependency bring-up failed; last 40 log lines:" >&2
    tail -40 "$LOG" >&2
    exit 1
fi

# Fail fast if the module under test and its transport deps cannot be imported.
uv run --no-sync python -c "import aiohttp, websockets; from app.core.clients.proxy_websocket import WebsocketsUpstreamWebSocket, CodexUpstreamWebSocket, UpstreamWebSocketTransportError"

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR"
