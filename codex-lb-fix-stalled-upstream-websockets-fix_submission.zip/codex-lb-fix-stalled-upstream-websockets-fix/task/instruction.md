## Task

We're getting operator reports that conversations relayed through the proxy to the upstream Responses API intermittently freeze and never come back on their own. It tracks with the host's network changing underneath a live session (a laptop moving between networks, a VPN connecting or dropping), not with load, request volume, or any particular prompt. Once a conversation is stuck it stays stuck, and the only workaround we've found is restarting the proxy process; sessions started after the restart behave normally until the next connectivity change. Other request types and freshly-started conversations are unaffected by the event.

The trouble is somewhere in the upstream WebSocket relay path for Responses traffic. Dig into the cause and fix it; a correct fix shouldn't need any new configuration. Add a test that reproduces the freeze and shows the corrected behaviour.
