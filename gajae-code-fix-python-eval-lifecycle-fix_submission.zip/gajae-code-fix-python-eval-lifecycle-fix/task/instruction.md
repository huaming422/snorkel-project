## Task

The Python evaluation engine is flaky under cancellation, timeout, and
shutdown. It's nondeterministic enough that the red-team rerun suite no longer
passes reliably when you loop it with `--rerun-each`.

When a caller cancels a run or it times out, background or descendant
processes the cell spawned can outlive it instead of getting cleaned up.
Cancelling a run while its kernel is still coming up can leave the engine in a
state that corrupts the next caller's run. And shutting the engine down
between runs can return before the in-flight work has settled.

Dig into the Python-eval lifecycle under `packages/coding-agent/src/eval/py/` and the file-lock helper it uses, and make cancellation, timeout, and shutdown deterministic and clean. <!-- lint: allow -->
Cleanup must stay bounded, with no hangs and no busy-waiting, and the focused
rerun suite should pass run after run. Leave the engine's public surface
unchanged: the exported function signatures, the runner protocol, and
unrelated packages.

This work is offline. Everything needed to build and run the focused Bun test
suite is in the image, and `python3` and Bun are on PATH.
