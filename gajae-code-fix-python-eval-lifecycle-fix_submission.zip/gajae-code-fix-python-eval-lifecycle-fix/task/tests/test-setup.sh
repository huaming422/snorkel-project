#!/usr/bin/env bash
# test-setup.sh — verifier-phase bootstrap for gajae-code-fix-python-eval-lifecycle.
#
# Sourced (not exec'd) by the harbor runner so env vars set here stay live for
# the verifier subprocess. The verifier runs the Bun lifecycle suite against the
# agent's source; everything it needs is already baked into the image at build
# time (Bun at /opt/bun/bin, a system python3, and the repo's full bun
# dependency closure installed at the base commit). This script therefore does
# NO network installs — the smoke gate's offline fold sources it with the
# network cut and must succeed. It only exports paths and fails loudly if a
# baked prerequisite is missing (which would mean a corrupt image, not a
# recoverable condition).

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/gajae-code}"
export REPO_DIR
cd "$REPO_DIR"

# Bun is the package manager and test runner for this repo; it was installed to
# /opt/bun during the image build. Make sure it is on PATH for the verifier.
export BUN_INSTALL="${BUN_INSTALL:-/opt/bun}"
export PATH="/opt/bun/bin:${PATH}"

if ! command -v bun >/dev/null 2>&1; then
    echo "test-setup.sh: bun not found on PATH (expected /opt/bun/bin/bun). " \
         "The image build is corrupt." >&2
    exit 1
fi

# The eval kernel spawns a stdlib-only python3 runner; it must be present.
if ! command -v python3 >/dev/null 2>&1; then
    echo "test-setup.sh: python3 not found. The image build is corrupt." >&2
    exit 1
fi

# The bun dependency closure is baked into the clone at build time. A missing
# node_modules means a corrupt image — bail loudly rather than silently falling
# back to an online install (there is no network in the agent/offline fold).
if [ ! -d "$REPO_DIR/node_modules" ]; then
    echo "test-setup.sh: node_modules missing under $REPO_DIR. " \
         "The image build is corrupt (dependency closure was not baked)." >&2
    exit 1
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR bun=$(bun --version 2>/dev/null || echo unknown) python3=$(python3 --version 2>/dev/null || echo unknown)"
