// @ts-nocheck
//
// Behavioural coverage for how a ChatGPT-subscription Codex session reports
// and requests its usable context window. Four independent interfaces are
// exercised, each through its own pre-existing stable seam:
//
//   1. ProviderRuntimeProjectionOwner.resolveRuntimeTarget +
//      the Codex framework's prepareModelConfig — the projected provider
//      carries the selected model's published window, and the launch config
//      requests it (model_context_window + auto-compaction limit).
//   2. The same pair with a model the catalogue does not know — no window
//      override is projected and neither launch-config key is emitted.
//   3. AcpContextUsagePolicy.resolve — the window surfaced to the usage UI
//      is suppressed for a Codex backend (whose native per-turn usage is
//      authoritative) but kept for the non-Codex backends.
//   4. AcpModelChangeWorkflow.apply — a mid-session switch to a different
//      native capacity reconnects the backend; an equal-capacity switch is
//      applied live.
//
// Every assertion is on observable output (the projected window, the launch
// config JSON, the resolved selectedWindow, and which collaborators the
// workflow invokes); none inspects an internal expression or helper name.

import type { ActiveSession, ClientConnection, SessionConfigOption } from '@agentclientprotocol/sdk'
import { describe, expect, it, vi } from 'vitest'

import type { SessionPermissionProfileState } from '../../shared/permission-profiles'
import type { AgentModelChangeTarget } from '../agent-framework'
import { claudeCodeFramework, getAgentFramework, opencodeFramework } from '../agent-framework'
import type {
  AcpBackendGenerationOwner,
  AcpBackendGenerationView
} from './backend-generation-owner'
import type { AcpConnectionResourceOwner } from './connection-resource-owner'
import { AcpContextUsagePolicy } from './context-usage-policy'
import type { ContextUsageTracker } from './context-usage-tracker'
import { AcpModelChangeWorkflow } from './model-change-workflow'
import type { AcpSessionConfigurator } from './session-configurator'
import { AcpSessionRegistry } from './session-registry'
import { ProviderRuntimeProjectionOwner } from '../settings/provider-runtime-projection'
import type { StoredProvider } from '../settings/types'

const codexFramework = getAgentFramework('codex')

// Published OpenAI windows are stable catalogue facts (@aipoch/providers). They
// are reproduced here only as the expected end-to-end values; the projection
// reads them from the catalogue, the test never writes them into any input.
const PUBLISHED_WINDOW = {
  'gpt-5.4': 1_050_000,
  'gpt-5.4-mini': 400_000
} as const

const launchConfig = (provider: unknown): Record<string, unknown> => {
  const config = codexFramework.prepareModelConfig(provider as never, {
    storageRoot: '/data',
    executablePath: '/runtime/codex-acp'
  })
  return JSON.parse(config.env?.CODEX_CONFIG ?? '{}')
}

// --- Interface 1 + 2: runtime projection -> Codex launch config ------------

describe('Codex subscription context window projection', () => {
  // A stored subscription provider under each `type` value the subscription
  // path can take: the OpenAI-vendor `official` entry and the two
  // `codex-*` entries. None carries a credential, so no secure-storage host
  // is required to project it.
  const subscriptionProvider = (
    type: 'official' | 'codex-isolated' | 'codex-shared'
  ): StoredProvider => ({
    id: type,
    type,
    name: 'OpenAI',
    ...(type === 'official' ? { vendorId: 'openai' as const } : {})
  })

  it.each(['official', 'codex-isolated', 'codex-shared'] as const)(
    'requests the selected model published window and its auto-compaction limit for %s',
    (type) => {
      const owner = new ProviderRuntimeProjectionOwner()
      const provider = subscriptionProvider(type)
      const before = structuredClone(provider)

      for (const model of ['gpt-5.4', 'gpt-5.4-mini'] as const) {
        const window = PUBLISHED_WINDOW[model]
        const target = owner.resolveRuntimeTarget(
          provider,
          { kind: 'required', model },
          codexFramework
        )
        // The projected target carries the requested model (an input echo)...
        expect(target.provider.model).toBe(model)
        // ...and — whichever layer resolves the window — the prepared launch
        // config requests exactly that published window and a derived
        // auto-compaction limit. The requested window must be exact; the
        // auto-compaction limit is a positive capacity that stays within the
        // requested window (the exact fraction a session reserves is a design
        // choice, not pinned here). The launch config is the user-facing
        // output; where the window is resolved (the projection owner, the
        // Codex framework, or a helper) is left free.
        const parsed = launchConfig(target.provider)
        expect(parsed).toMatchObject({
          model,
          model_context_window: window
        })
        const autoCompactLimit = parsed.model_auto_compact_token_limit
        expect(typeof autoCompactLimit).toBe('number')
        expect(Number.isInteger(autoCompactLimit)).toBe(true)
        expect(autoCompactLimit).toBeGreaterThan(0)
        expect(autoCompactLimit).toBeLessThanOrEqual(window)
      }
      // Projection is read-only on the stored provider.
      expect(provider).toEqual(before)
    }
  )

  // The `official` OpenAI-vendor path resolves its window from its own vendor
  // branch and defaults an absent selection to a real catalogue model, so
  // "unknown / account-default" is only meaningful for the credential-free
  // `codex-*` subscription `type` values (where no vendor default applies).
  it.each(['codex-isolated', 'codex-shared'] as const)(
    'leaves the native default in place for an unknown %s model',
    (type) => {
      const owner = new ProviderRuntimeProjectionOwner()
      const provider = subscriptionProvider(type)

      for (const model of [undefined, 'unpublished-model']) {
        const resolved = owner.resolveProvider(provider, model)
        // For a model the catalogue does not publish, neither override key is
        // emitted, so codex-acp keeps its own native default rather than a
        // fabricated ceiling. The absence in the launch config is the
        // user-facing output; the resolution layer is left free.
        const parsed = launchConfig(resolved)
        expect(parsed).not.toHaveProperty('model_context_window')
        expect(parsed).not.toHaveProperty('model_auto_compact_token_limit')
      }
    }
  )
})

// --- Interface 3: usage policy selectedWindow ------------------------------

const policyBackend = (
  overrides: Partial<AcpBackendGenerationView> = {}
): AcpBackendGenerationView => ({
  framework: opencodeFramework,
  session: { model: 'requested/model', modelRequired: false },
  prompt: { systemPromptAppends: [] },
  context: { model: 'tokenizer/model', window: 128_000, supportsImageInput: false },
  adapter: { nativeMcpEnabled: true, bridgeMcpAliasesEnabled: false },
  ...overrides
})

const resolvePolicy = (backend: AcpBackendGenerationView) =>
  new AcpContextUsagePolicy({
    backend: () => backend,
    appliedModel: () => 'confirmed/model',
    systemPromptAppends: () => [],
    tooling: () => ({ artifacts: false, notebook: false, skillImport: false })
  }).resolve('session-1')

describe('Codex usage-window reporting policy', () => {
  it('does not surface the requested window for a Codex backend', () => {
    const resolved = resolvePolicy(
      policyBackend({
        framework: codexFramework,
        modelRoute: 'codex-responses',
        context: { model: 'gpt-5.4', window: 1_050_000, supportsImageInput: true }
      })
    )
    // Codex carries its own effective capacity in its usage updates; the
    // requested ceiling must not stand in for it in the UI/preflight path.
    expect(resolved.selectedWindow).toBeUndefined()
  })

  it.each(['claude-code', 'opencode'] as const)(
    'surfaces the provider window for a %s backend',
    (frameworkId) => {
      const resolved = resolvePolicy(policyBackend({ framework: getAgentFramework(frameworkId) }))
      // Non-Codex frameworks have no native per-turn capacity of their own, so
      // the provider-derived window remains authoritative.
      expect(resolved.selectedWindow).toBe(128_000)
    }
  )
})

// --- Interface 4: model-change workflow reconnect vs live apply ------------

const permissionProfile: SessionPermissionProfileState = {
  selectedProfile: 'ask',
  effectiveProfile: 'ask',
  currentModeId: 'default',
  availableModeIds: ['default'],
  fullAccessAvailable: false
}

const modelOption = (currentValue = 'model-a'): SessionConfigOption =>
  ({
    type: 'select',
    id: 'model',
    name: 'Model',
    category: 'model',
    currentValue,
    options: ['model-a', 'model-b', 'model-c'].map((value) => ({ value, name: value }))
  }) as SessionConfigOption

const target = (
  model: string,
  overrides: Partial<AgentModelChangeTarget> = {}
): AgentModelChangeTarget => ({
  frameworkId: 'claude-code',
  providerId: 'provider-a',
  backendId: 'claude-code:provider',
  route: 'claude-anthropic',
  model,
  sessionModel: model,
  sessionModelRequired: false,
  reasoningEffort: 'default',
  supportsImageInput: false,
  ...overrides
})

const createHarness = (backendOverrides: Partial<AcpBackendGenerationView> = {}) => {
  let busy = false
  let connected = true
  let providerReconnectPending = false
  let replayableImageHistory = true
  let backend: AcpBackendGenerationView = {
    framework: claudeCodeFramework,
    providerId: 'provider-a',
    backendId: 'claude-code:provider',
    modelRoute: 'claude-anthropic',
    session: { model: 'model-a', modelRequired: false },
    prompt: { systemPromptAppends: [] },
    context: { model: 'model-a', supportsImageInput: false },
    adapter: { nativeMcpEnabled: true, bridgeMcpAliasesEnabled: false },
    ...backendOverrides
  }
  let options = [modelOption()]
  const request = vi.fn(async (_method: unknown, params: unknown) => {
    const value = (params as { value: string }).value
    options = [modelOption(value)]
    return { configOptions: options }
  })
  const connection = { agent: { request } } as unknown as ClientConnection
  const session = {
    sessionId: 'provider-session',
    newSessionResponse: { configOptions: options },
    dispose: vi.fn()
  } as unknown as ActiveSession
  const registry = new AcpSessionRegistry()
  const reserved = registry.reserve({ sessionIds: ['app-session', session.sessionId] })
  if (reserved.collision) throw reserved.collision
  const entry = registry.publish(reserved.reservation, 'app-session', {
    session,
    cwd: '/workspace',
    projectId: 'project-a',
    frameworkId: 'claude-code',
    backendId: backend.backendId,
    permissionProfile,
    appliedModel: 'model-a',
    configOptions: options
  })
  reserved.reservation.release()
  const updateAggregateModel = vi.spyOn(entry.aggregate, 'updateModel')

  const updateModel = vi.fn((next: AgentModelChangeTarget) => {
    backend = {
      ...backend,
      providerId: next.providerId,
      backendId: next.backendId,
      modelRoute: next.route,
      session: {
        ...backend.session,
        model: next.sessionModel,
        modelRequired: next.sessionModelRequired,
        ...(next.reasoningEffort === 'default' ? {} : { effort: next.reasoningEffort })
      },
      context: {
        model: next.model,
        ...(next.contextWindow ? { window: next.contextWindow } : {}),
        supportsImageInput: next.supportsImageInput
      }
    }
    return backend
  })
  const updateReasoningEffort = vi.fn((effort: 'default' | 'low' | 'medium' | 'high' | 'max') => {
    backend = {
      ...backend,
      session: {
        ...backend.session,
        ...(effort === 'default' ? {} : { effort })
      }
    }
    return backend
  })
  const backendGeneration = {
    get current() {
      return backend
    },
    updateModel,
    updateReasoningEffort
  } as Pick<AcpBackendGenerationOwner, 'current' | 'updateModel' | 'updateReasoningEffort'>

  const setProviderTransportTarget = vi.fn(() => true)
  const setMessagesBridgeTarget = vi.fn(() => true)
  const setBridgeReasoningEffort = vi.fn()
  const connectionResources = {
    epoch: 1,
    get connection() {
      return connected ? connection : undefined
    },
    get isShuttingDown() {
      return false
    },
    get messagesBridgeAvailable() {
      return false
    },
    get providerTransportAvailable() {
      return false
    },
    assertCurrentConnection: vi.fn(),
    setProviderTransportTarget,
    setMessagesBridgeTarget,
    setBridgeModelTarget: vi.fn(() => true),
    setBridgeReasoningEffort
  } as Pick<
    AcpConnectionResourceOwner,
    | 'epoch'
    | 'connection'
    | 'isShuttingDown'
    | 'messagesBridgeAvailable'
    | 'providerTransportAvailable'
    | 'assertCurrentConnection'
    | 'setProviderTransportTarget'
    | 'setMessagesBridgeTarget'
    | 'setBridgeModelTarget'
    | 'setBridgeReasoningEffort'
  >

  const applyLiveEffort = vi.fn(async () => ({ reconnectRequired: false }))
  const clearContext = vi.fn()
  const beginContext = vi.fn()
  const emitState = vi.fn()
  const requestReconnect = vi.fn(async () => undefined)
  const recoverFailedReconnect = vi.fn()
  const reportReconnectFailure = vi.fn()
  const workflow = new AcpModelChangeWorkflow({
    backendGeneration,
    connectionResources,
    registry,
    configurator: { applyLiveEffort } as Pick<AcpSessionConfigurator, 'applyLiveEffort'>,
    contextUsage: {
      clear: clearContext,
      beginSession: beginContext
    } as Pick<ContextUsageTracker, 'clear' | 'beginSession'>,
    currentStatus: () => (connected ? 'connected' : 'closed'),
    providerReconnectPending: () => providerReconnectPending,
    isGenerationBusy: () => busy,
    contextEstimateInput: () => ({ frameworkId: 'claude-code', model: backend.context.model }),
    hasReplayableImageHistory: vi.fn(async () => replayableImageHistory),
    emitState,
    requestReconnect,
    recoverFailedReconnect,
    reportReconnectFailure,
    diagnosticContext: () => ({})
  })

  return {
    workflow,
    request,
    requestReconnect,
    updateModel,
    clearContext,
    beginContext,
    setBusy: (value: boolean) => {
      busy = value
    },
    setConnected: (value: boolean) => {
      connected = value
    },
    setProviderReconnectPending: (value: boolean) => {
      providerReconnectPending = value
    }
  }
}

describe('Codex model-change capacity handling', () => {
  it.each(['codex-responses', 'codex-responses-compatibility', 'codex-bridge'] as const)(
    'reconnects %s before applying a different native capacity',
    async (route) => {
      for (const [previous, next] of [
        [1_050_000, 400_000],
        [400_000, 1_050_000],
        [undefined, 1_050_000],
        [1_050_000, undefined]
      ]) {
        for (const model of ['model-a', 'model-b']) {
          const harness = createHarness({
            framework: codexFramework,
            modelRoute: route,
            context: { model: 'model-a', window: previous, supportsImageInput: false }
          })
          await expect(
            harness.workflow.apply(
              target(model, { frameworkId: 'codex', route, contextWindow: next })
            )
          ).resolves.toBe(true)
          // The startup-only override cannot change live; the backend must
          // reconnect rather than apply the switch in place.
          expect(harness.requestReconnect).toHaveBeenCalledOnce()
          expect(harness.request).not.toHaveBeenCalled()
          expect(harness.updateModel).not.toHaveBeenCalled()
          expect(harness.clearContext).not.toHaveBeenCalled()
        }
      }
    }
  )

  it('applies a live Codex switch when the native capacity is unchanged', async () => {
    const harness = createHarness({
      framework: codexFramework,
      modelRoute: 'codex-responses',
      context: { model: 'model-a', window: 1_050_000, supportsImageInput: false }
    })
    await expect(
      harness.workflow.apply(
        target('model-b', {
          frameworkId: 'codex',
          route: 'codex-responses',
          contextWindow: 1_050_000
        })
      )
    ).resolves.toBe(true)
    // Equal capacity is safe to apply in place: no reconnect, the model is
    // switched live and the context tracker re-begins on the new model.
    expect(harness.requestReconnect).not.toHaveBeenCalled()
    expect(harness.updateModel).toHaveBeenCalledOnce()
    expect(harness.clearContext).toHaveBeenCalledOnce()
    expect(harness.beginContext).toHaveBeenCalledWith(
      'app-session',
      expect.objectContaining({ model: 'model-b' })
    )
  })
})
