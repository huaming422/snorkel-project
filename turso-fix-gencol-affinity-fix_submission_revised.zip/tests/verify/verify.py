"""Behavioral verifier for turso-fix-gencol-affinity.

The whole task is behavioral: every symptom is a wrong / crashing / spuriously
matching SQL result that is observable through the `tursodb` CLI. This verifier
therefore drives the pre-existing, stable `tursodb` binary (package turso_cli,
bin ``tursodb``) over author-owned in-memory SQL scenarios and asserts on the
pipe-separated rows / error text / exit status it prints — the exact SQL-in /
rows-out surface the repo's own ``testing/sqltests`` suite drives.

Why the CLI, and only the CLI
-----------------------------
The single interface under test is the SQL engine's observable behavior. We
build the `tursodb` binary from the repository under test and then only
subprocess it; we never import a repository Rust symbol, never read repository
source, and never run any in-repo test harness (a harness lives in the repo
tree and could be edited by a submission, so only the compiled engine binary —
the thing actually being graded — is kept in the loop). The scenarios are
authored HERE, not read from the repo's own test files, so they cannot be
satisfied by editing a checked-in test.

The scenarios assert pure SQL behavior that any correct implementation must
produce (comparison truth values, index/base-row agreement, a resolved tag
string, triggers not firing on type-mismatched string input, rowid keeping its
integer comparison). They name no engine-internal symbol, no module, no file —
every alternative implementation that produces the right SQL answers passes.

Interpreter note: this file subprocesses a binary and parses text only, so it
runs under the shared VERIFIER_PYTHON with no project venv.

Criterion routing (see task.toml [[test_criteria]]):
  C1 fail_to_pass  comparison affinity over a TEXT column + index agreement
  C2 fail_to_pass  union_tag(...) in a SELECT resolves to the tag, no crash
  C3 fail_to_pass  NEW/OLD trigger-row columns carry no affinity, except a
                   rowid / rowid-alias which keeps integer comparison
  C4 fail_to_pass  comparison type rules hold on non-DML paths
                   (index population/maintenance, integrity_check, hash join,
                   RETURNING)
  C5 pass_to_pass  pre-existing generated-column and trigger behavior still
                   works (guards over-correction)
"""

from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Repository + build
# ---------------------------------------------------------------------------

REPO_DIR = Path(f"/repo/{os.environ.get('REPO_NAME', 'turso')}")

# Generous ceiling for the one-time build. The image pre-builds the whole
# workspace at the base commit, so this is a warm incremental compile of the
# cli crate plus a link; the ceiling only absorbs an unexpectedly cold cache.
BUILD_TIMEOUT_S = 1500

# Per-scenario CLI ceiling. Each scenario is a few in-memory statements.
QUERY_TIMEOUT_S = 60


def _target_dir() -> Path:
    env = os.environ.get("CARGO_TARGET_DIR")
    return Path(env) if env else (REPO_DIR / "target")


@pytest.fixture(scope="session")
def tursodb() -> str:
    """Build the `tursodb` binary from the repo under test and return its path.

    Uses the same debug profile the image warmed, so dependency crates are
    cache hits and only the cli crate + binary link compile. No network is
    required; --locked keeps the dependency set pinned to the lockfile.
    """
    if not REPO_DIR.exists():
        pytest.fail(f"repository not found at {REPO_DIR}")

    cargo = shutil.which("cargo") or "cargo"
    proc = subprocess.run(
        [cargo, "build", "--locked", "-p", "turso_cli", "--bin", "tursodb"],
        cwd=str(REPO_DIR),
        capture_output=True,
        text=True,
        timeout=BUILD_TIMEOUT_S,
        check=False,
    )
    if proc.returncode != 0:
        pytest.fail(
            "building tursodb failed (exit "
            f"{proc.returncode}):\n{proc.stdout[-2000:]}\n{proc.stderr[-2000:]}"
        )

    binary = _target_dir() / "debug" / "tursodb"
    if not binary.exists():
        pytest.fail(f"tursodb binary not found at {binary} after build")
    return str(binary)


# ---------------------------------------------------------------------------
# CLI driver — mirrors testing/sqltests/src/backends/cli.rs invocation,
# error-detection, and parse_list_output row parsing exactly.
# ---------------------------------------------------------------------------

# The experimental surface the repo's own cli backend passes. We pass the same
# set so custom types / generated columns / etc. are enabled for every scenario.
EXPERIMENTAL_FLAGS = [
    "--experimental-views",
    "--experimental-custom-types",
    "--experimental-attach",
    "--experimental-index-method",
    "--experimental-generated-columns",
    "--experimental-vacuum",
]


class SqlResult:
    """Outcome of running one SQL script through tursodb."""

    def __init__(self, rows: list[list[str]], error: str | None, raw: str):
        self.rows = rows
        self.error = error  # None on success; combined error text otherwise
        self.raw = raw

    @property
    def is_error(self) -> bool:
        return self.error is not None


def _parse_list_output(stdout: str) -> list[list[str]]:
    """Port of parse_list_output: one row per line, cells split on '|', an
    empty line is a single empty cell (a single NULL column).

    The repo parser iterates Rust's str::lines(), which consumes a single
    trailing newline and yields no trailing empty element while preserving
    genuine interior empty lines. Python's str.splitlines() has the identical
    behavior for this (newline-delimited, ASCII) output, so it is the faithful
    equivalent — and, unlike split('\\n'), it stays correct when the final row
    is itself a NULL (empty) line."""
    return [([""] if line == "" else line.split("|")) for line in stdout.splitlines()]


def run_sql(tursodb: str, script: str) -> SqlResult:
    """Run a SQL script against a fresh in-memory database and return rows or
    an error, using the same error-detection union as the repo's cli backend:
    error iff stderr mentions error, or stdout carries an error marker, or the
    process exits non-zero.
    """
    proc = subprocess.run(
        [tursodb, ":memory:", "-q", "-m", "list", *EXPERIMENTAL_FLAGS],
        input=script,
        capture_output=True,
        text=True,
        timeout=QUERY_TIMEOUT_S,
        cwd=str(REPO_DIR),
        check=False,
    )
    stdout, stderr = proc.stdout, proc.stderr
    has_stderr_error = stderr != "" and ("Error" in stderr or "error" in stderr)
    has_stdout_error = ("× " in stdout) or ("error:" in stdout) or ("Error:" in stdout)
    combined = (stdout + "\n" + stderr).strip()

    if has_stderr_error or has_stdout_error or proc.returncode != 0:
        return SqlResult(rows=[], error=combined, raw=combined)
    return SqlResult(rows=_parse_list_output(stdout), error=None, raw=stdout)


def rows_of(tursodb: str, script: str) -> list[list[str]]:
    """Run a script expecting success; fail loudly on an unexpected error."""
    res = run_sql(tursodb, script)
    assert not res.is_error, f"expected rows, engine reported an error:\n{res.error}"
    return res.rows


def _fmt(rows: list[list[str]]) -> list[str]:
    return ["|".join(r) for r in rows]


# ---------------------------------------------------------------------------
# C1 — comparison affinity over a TEXT column, and index agreement.
# Expected blocks lifted verbatim from testing/sqltests/tests/gencol.sqltest.
# ---------------------------------------------------------------------------


def test_c1_comparison_affinity_text_integer(tursodb):
    # TEXT column => text comparison: '10' > '5' is false (lexicographic).
    rows = rows_of(
        tursodb,
        """
        CREATE TABLE t1(a TEXT, b INTEGER AS (a > 5));
        INSERT INTO t1(a) VALUES('10'), ('3'), ('7');
        SELECT a, b FROM t1;
        """,
    )
    assert _fmt(rows) == ["10|0", "3|0", "7|1"], _fmt(rows)


def test_c1_comparison_affinity_equals(tursodb):
    rows = rows_of(
        tursodb,
        """
        CREATE TABLE t1(a TEXT, b INTEGER AS (a = 10));
        INSERT INTO t1(a) VALUES('10'), ('5');
        SELECT a, b FROM t1;
        """,
    )
    assert _fmt(rows) == ["10|1", "5|0"], _fmt(rows)


def test_c1_comparison_affinity_null(tursodb):
    rows = rows_of(
        tursodb,
        """
        CREATE TABLE t1(a TEXT, b INTEGER AS (a > 5));
        INSERT INTO t1(a) VALUES(NULL), ('10');
        SELECT a, b FROM t1;
        """,
    )
    assert _fmt(rows) == ["|", "10|0"], _fmt(rows)


def test_c1_comparison_affinity_negative(tursodb):
    rows = rows_of(
        tursodb,
        """
        CREATE TABLE t1(a TEXT, b INTEGER AS (a > -5));
        INSERT INTO t1(a) VALUES('-3'), ('-7'), ('0');
        SELECT a, b FROM t1;
        """,
    )
    assert _fmt(rows) == ["-3|0", "-7|1", "0|1"], _fmt(rows)


def test_c1_comparison_affinity_real(tursodb):
    rows = rows_of(
        tursodb,
        """
        CREATE TABLE t1(a TEXT, b INTEGER AS (a > 5.5));
        INSERT INTO t1(a) VALUES('6'), ('5'), ('5.5');
        SELECT a, b FROM t1;
        """,
    )
    assert _fmt(rows) == ["6|1", "5|0", "5.5|0"], _fmt(rows)


def test_c1_index_on_gencol_agrees_with_base_rows(tursodb):
    # An index built on the generated column must select the same rows the
    # base-table comparison selects: the row with a='0' has (a >= 10) false.
    rows = rows_of(
        tursodb,
        """
        CREATE TABLE t(a TEXT, g INT GENERATED ALWAYS AS (a >= 10) VIRTUAL);
        INSERT INTO t(a) VALUES('0');
        CREATE INDEX idx_g ON t(g);
        SELECT 'g1', a, g FROM t INDEXED BY idx_g WHERE g=1;
        SELECT 'g0', a, g FROM t INDEXED BY idx_g WHERE g=0;
        """,
    )
    assert _fmt(rows) == ["g0|0|0"], _fmt(rows)


# ---------------------------------------------------------------------------
# C2 — union_tag(...) inside a SELECT resolves to the tag instead of crashing.
# ---------------------------------------------------------------------------


def test_c2_union_tag_select_resolves(tursodb):
    rows = rows_of(
        tursodb,
        """
        CREATE TYPE number AS UNION(i INT, f REAL);
        CREATE TABLE tagged(
            id INT,
            val number,
            tag TEXT GENERATED ALWAYS AS (union_tag(val)) VIRTUAL
        ) STRICT;
        INSERT INTO tagged(id, val) VALUES (1, union_value('i', 42));
        INSERT INTO tagged(id, val) VALUES (2, union_value('f', 3.5));
        SELECT id, tag FROM tagged ORDER BY id;
        """,
    )
    assert _fmt(rows) == ["1|i", "2|f"], _fmt(rows)


# ---------------------------------------------------------------------------
# C3 — NEW/OLD trigger-row columns carry no affinity (so a WHEN / body
# comparison does not coerce string input into a numeric match), except a
# rowid or rowid-alias which keeps integer comparison.
# ---------------------------------------------------------------------------


def test_c3_new_columns_have_no_affinity(tursodb):
    rows = rows_of(
        tursodb,
        """
        CREATE TABLE t(a TEXT);
        CREATE TABLE log(msg);

        CREATE TRIGGER tr_when AFTER INSERT ON t WHEN NEW.a = 5
          BEGIN INSERT INTO log VALUES('when_fired'); END;

        CREATE TRIGGER tr_where AFTER INSERT ON t
          BEGIN INSERT INTO log SELECT 'body_where_fired' WHERE NEW.a = 5; END;

        CREATE TRIGGER tr_having AFTER INSERT ON t
          BEGIN
            INSERT INTO log SELECT 'body_having_fired'
            FROM (SELECT 1 AS x) GROUP BY x HAVING NEW.a = 5;
          END;

        INSERT INTO t VALUES('5');

        SELECT 'where_match', count(*) FROM t WHERE a = 5
        UNION ALL
        SELECT 'when_fired', count(*) FROM log WHERE msg = 'when_fired'
        UNION ALL
        SELECT 'body_where_fired', count(*) FROM log WHERE msg = 'body_where_fired'
        UNION ALL
        SELECT 'body_having_fired', count(*) FROM log WHERE msg = 'body_having_fired';
        """,
    )
    assert _fmt(rows) == [
        "where_match|1",
        "when_fired|0",
        "body_where_fired|0",
        "body_having_fired|0",
    ], _fmt(rows)


def test_c3_old_columns_have_no_affinity(tursodb):
    rows = rows_of(
        tursodb,
        """
        CREATE TABLE t(a TEXT);
        CREATE TABLE log(msg);
        INSERT INTO t VALUES('5');

        CREATE TRIGGER tr_when AFTER UPDATE ON t WHEN OLD.a = 5
          BEGIN INSERT INTO log VALUES('when_fired'); END;

        CREATE TRIGGER tr_where AFTER UPDATE ON t
          BEGIN INSERT INTO log SELECT 'body_where_fired' WHERE OLD.a = 5; END;

        CREATE TRIGGER tr_having AFTER UPDATE ON t
          BEGIN
            INSERT INTO log SELECT 'body_having_fired'
            FROM (SELECT 1 AS x) GROUP BY x HAVING OLD.a = 5;
          END;

        UPDATE t SET a = a;

        SELECT 'where_match', count(*) FROM t WHERE a = 5
        UNION ALL
        SELECT 'when_fired', count(*) FROM log WHERE msg = 'when_fired'
        UNION ALL
        SELECT 'body_where_fired', count(*) FROM log WHERE msg = 'body_where_fired'
        UNION ALL
        SELECT 'body_having_fired', count(*) FROM log WHERE msg = 'body_having_fired';
        """,
    )
    assert _fmt(rows) == [
        "where_match|1",
        "when_fired|0",
        "body_where_fired|0",
        "body_having_fired|0",
    ], _fmt(rows)


def test_c3_trigger_generated_text_no_match(tursodb):
    # NEW.g / OLD.g reference a TEXT generated column; a `= 0` guard must not
    # coerce and fire across INSERT/UPDATE/DELETE. No trigger fires => EMPTY.
    rows = rows_of(
        tursodb,
        """
        CREATE TABLE t(a TEXT, g TEXT AS (a > 5) VIRTUAL);
        CREATE TABLE log(ev TEXT, val TEXT);

        CREATE TRIGGER bi BEFORE INSERT ON t WHEN NEW.g = 0 BEGIN INSERT INTO log VALUES('BI:new', NEW.g || ':' || typeof(NEW.g)); END;
        CREATE TRIGGER ai AFTER INSERT ON t WHEN NEW.g = 0 BEGIN INSERT INTO log VALUES('AI:new', NEW.g || ':' || typeof(NEW.g)); END;
        INSERT INTO t(a) VALUES('10');

        CREATE TRIGGER bu_old BEFORE UPDATE ON t WHEN OLD.g = 0 BEGIN INSERT INTO log VALUES('BU:old', OLD.g || ':' || typeof(OLD.g)); END;
        CREATE TRIGGER bu_new BEFORE UPDATE ON t WHEN NEW.g = 0 BEGIN INSERT INTO log VALUES('BU:new', NEW.g || ':' || typeof(NEW.g)); END;
        CREATE TRIGGER au_old AFTER UPDATE ON t WHEN OLD.g = 0 BEGIN INSERT INTO log VALUES('AU:old', OLD.g || ':' || typeof(OLD.g)); END;
        CREATE TRIGGER au_new AFTER UPDATE ON t WHEN NEW.g = 0 BEGIN INSERT INTO log VALUES('AU:new', NEW.g || ':' || typeof(NEW.g)); END;
        UPDATE t SET a='10';

        CREATE TRIGGER bd BEFORE DELETE ON t WHEN OLD.g = 0 BEGIN INSERT INTO log VALUES('BD:old', OLD.g || ':' || typeof(OLD.g)); END;
        CREATE TRIGGER ad AFTER DELETE ON t WHEN OLD.g = 0 BEGIN INSERT INTO log VALUES('AD:old', OLD.g || ':' || typeof(OLD.g)); END;
        DELETE FROM t;

        SELECT COALESCE(group_concat(ev || '=' || val, ','), 'EMPTY') FROM log;
        """,
    )
    assert _fmt(rows) == ["EMPTY"], _fmt(rows)


def test_c3_rowid_alias_keeps_integer_affinity(tursodb):
    # INTEGER PRIMARY KEY is a rowid alias: NEW.id = '1' coerces and fires.
    rows = rows_of(
        tursodb,
        """
        CREATE TABLE t12(id INTEGER PRIMARY KEY, v);
        CREATE TABLE log12(msg);
        CREATE TRIGGER tr12 AFTER INSERT ON t12 WHEN NEW.id = '1'
          BEGIN
            INSERT INTO log12 VALUES('fired');
          END;
        INSERT INTO t12 VALUES(1, 'x');
        SELECT * FROM log12;
        """,
    )
    assert _fmt(rows) == ["fired"], _fmt(rows)


def test_c3_rowid_keeps_integer_affinity(tursodb):
    rows = rows_of(
        tursodb,
        """
        CREATE TABLE t12(id);
        CREATE TABLE log12(msg);
        CREATE TRIGGER tr12 AFTER INSERT ON t12 WHEN NEW.rowid = '1'
          BEGIN
            INSERT INTO log12 VALUES('fired');
          END;
        INSERT INTO t12 VALUES('x');
        SELECT * FROM log12;
        """,
    )
    assert _fmt(rows) == ["fired"], _fmt(rows)


# ---------------------------------------------------------------------------
# C4 — the comparison type rules hold on non-DML-INSERT paths: index
# population/maintenance, PRAGMA integrity_check, hash join, and RETURNING.
# ---------------------------------------------------------------------------


def test_c4_update_not_null_constraint_fires(tursodb):
    # g becomes NULL when a='10'; the NOT NULL constraint must fire on UPDATE.
    res = run_sql(
        tursodb,
        """
        CREATE TABLE t(a TEXT, g AS (CASE WHEN a=10 THEN NULL ELSE 1 END) NOT NULL);
        INSERT INTO t(a) VALUES('x');
        UPDATE t SET a='10';
        """,
    )
    assert res.is_error, f"expected a NOT NULL constraint error, got rows: {res.raw}"
    assert "NOT NULL constraint failed: t.g" in res.raw, res.raw


def test_c4_integrity_check_not_null(tursodb):
    rows = rows_of(
        tursodb,
        """
        CREATE TABLE t(
            a TEXT,
            b INT GENERATED ALWAYS AS (CASE WHEN a < 40 THEN 1 END) VIRTUAL NOT NULL
        );
        INSERT INTO t(a) VALUES('10');
        SELECT a, b, typeof(b), a < 40 FROM t;
        PRAGMA integrity_check;
        """,
    )
    assert _fmt(rows) == ["10|1|integer|1", "ok"], _fmt(rows)


def test_c4_integrity_check_index(tursodb):
    rows = rows_of(
        tursodb,
        """
        CREATE TABLE t(a TEXT, g INT GENERATED ALWAYS AS (a < 2) VIRTUAL);
        CREATE INDEX i ON t(g);
        INSERT INTO t(a) VALUES('10');
        SELECT a, g, typeof(g) FROM t;
        PRAGMA integrity_check;
        """,
    )
    assert _fmt(rows) == ["10|1|integer", "ok"], _fmt(rows)


def test_c4_hash_join_payload(tursodb):
    rows = rows_of(
        tursodb,
        """
        CREATE TABLE b(k INT, a TEXT, g INT GENERATED ALWAYS AS (a = 5) VIRTUAL);
        CREATE TABLE p(k INT);
        INSERT INTO b VALUES(1, '5');
        INSERT INTO p VALUES(1);
        SELECT 'plain', g FROM b;
        SELECT 'hash', b.g FROM b FULL OUTER JOIN p ON b.k = p.k;
        """,
    )
    assert _fmt(rows) == ["plain|1", "hash|1"], _fmt(rows)


def test_c4_delete_index_maintenance(tursodb):
    rows = rows_of(
        tursodb,
        """
        CREATE TABLE t(a TEXT, v AS (a = 10) VIRTUAL);
        CREATE INDEX i ON t(v);
        INSERT INTO t(a) VALUES('10');
        DELETE FROM t;
        SELECT count(*) FROM t;
        PRAGMA integrity_check;
        """,
    )
    assert _fmt(rows) == ["0", "ok"], _fmt(rows)


def test_c4_update_returning_not_null(tursodb):
    rows = rows_of(
        tursodb,
        """
        CREATE TABLE t(a TEXT, g INT AS (CASE WHEN a=10 THEN 1 END) VIRTUAL NOT NULL);
        INSERT INTO t(a) VALUES('10');
        UPDATE t SET a='10' RETURNING a, g, typeof(g);
        """,
    )
    assert _fmt(rows) == ["10|1|integer"], _fmt(rows)


def test_c4_indexed_update_returning(tursodb):
    rows = rows_of(
        tursodb,
        """
        CREATE TABLE t(a TEXT, g INT AS (a = 10) VIRTUAL);
        INSERT INTO t(a) VALUES('10'), ('5');
        CREATE INDEX idx_g ON t(g);
        UPDATE t INDEXED BY idx_g SET a='11' WHERE g=1 RETURNING a, g, typeof(g);
        SELECT 'all', a, g FROM t ORDER BY a;
        PRAGMA integrity_check;
        """,
    )
    assert _fmt(rows) == ["11|0|integer", "all|11|0", "all|5|0", "ok"], _fmt(rows)


def test_c4_indexed_delete_returning(tursodb):
    rows = rows_of(
        tursodb,
        """
        CREATE TABLE t(a TEXT, g INT AS (a = 10) VIRTUAL);
        INSERT INTO t(a) VALUES('10'), ('5');
        CREATE INDEX idx_g ON t(g);
        DELETE FROM t INDEXED BY idx_g WHERE g=0 RETURNING a, g, typeof(g);
        SELECT 'left', a, g FROM t;
        PRAGMA integrity_check;
        """,
    )
    assert _fmt(rows) == ["5|0|integer", "left|10|1", "ok"], _fmt(rows)


def test_c4_insert_returning_index_integrity(tursodb):
    rows = rows_of(
        tursodb,
        """
        CREATE TABLE t(a TEXT, g INT AS (a = 10) VIRTUAL);
        CREATE INDEX idx_g ON t(g);
        INSERT INTO t(a) VALUES('10'), ('5') RETURNING a, g, typeof(g);
        SELECT 'idx1', a, g FROM t INDEXED BY idx_g WHERE g=1;
        SELECT 'idx0', a, g FROM t INDEXED BY idx_g WHERE g=0;
        PRAGMA integrity_check;
        """,
    )
    assert _fmt(rows) == [
        "10|1|integer",
        "5|0|integer",
        "idx1|10|1",
        "idx0|5|0",
        "ok",
    ], _fmt(rows)


# ---------------------------------------------------------------------------
# C5 — pass_to_pass: pre-existing generated-column and trigger behavior keeps
# working, so an over-correction that breaks the ordinary paths is rejected.
# Expected blocks lifted verbatim from the repo's existing (unskipped) cases.
# ---------------------------------------------------------------------------


def test_c5_gencol_virtual_basic(tursodb):
    rows = rows_of(
        tursodb,
        """
        CREATE TABLE t1(a INTEGER, b AS (a*2));
        INSERT INTO t1(a) VALUES(5);
        SELECT a, b FROM t1;
        """,
    )
    assert _fmt(rows) == ["5|10"], _fmt(rows)


def test_c5_gencol_virtual_select_star(tursodb):
    rows = rows_of(
        tursodb,
        """
        CREATE TABLE t1(x, y AS (x+1), z);
        INSERT INTO t1(x, z) VALUES(10, 30);
        SELECT * FROM t1;
        """,
    )
    assert _fmt(rows) == ["10|11|30"], _fmt(rows)


def test_c5_gencol_expression_concat(tursodb):
    rows = rows_of(
        tursodb,
        """
        CREATE TABLE t1(first TEXT, last TEXT, full AS (first || ' ' || last));
        INSERT INTO t1(first, last) VALUES('John', 'Doe');
        SELECT full FROM t1;
        """,
    )
    assert _fmt(rows) == ["John Doe"], _fmt(rows)


def test_c5_gencol_multiple_virtual(tursodb):
    rows = rows_of(
        tursodb,
        """
        CREATE TABLE t1(a INTEGER, b AS (a*2), c AS (a*3), d AS (a*4));
        INSERT INTO t1(a) VALUES(5);
        SELECT b, c, d FROM t1;
        """,
    )
    assert _fmt(rows) == ["10|15|20"], _fmt(rows)


def test_c5_trigger_numeric_affinity_still_applies(tursodb):
    # A declared REAL column still applies its column affinity in a trigger
    # row: inserting integer 42 is observed as real. This is the ordinary
    # (non NEW/OLD-of-generated) path that must keep working.
    rows = rows_of(
        tursodb,
        """
        CREATE TABLE t(a REAL);
        CREATE TABLE log(msg);
        CREATE TRIGGER tr BEFORE INSERT ON t BEGIN
            INSERT INTO log VALUES(typeof(NEW.a));
        END;
        INSERT INTO t VALUES(42);
        SELECT * FROM log;
        """,
    )
    assert _fmt(rows) == ["real"], _fmt(rows)
