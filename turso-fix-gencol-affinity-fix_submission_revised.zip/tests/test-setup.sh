#!/usr/bin/env bash
# Test-setup for turso-fix-gencol-affinity.
#
# The behavioral verifier drives the `tursodb` CLI (package turso_cli, bin
# `tursodb`) over in-memory SQL scenarios. The image builds the whole turso
# workspace at the base commit (cargo build --workspace --lib --tests), so
# building the `tursodb` binary here is a warm incremental compile of the cli
# crate plus a link. Doing it in setup keeps the build cost off the per-file
# pytest clock and exercises it under the offline fold. No services, no data
# seeding, no network.
#
# Offline-first: deps are already vendored in the image's cargo cache, so
# --locked builds with CARGO_NET_OFFLINE. If (only in an online context) a
# crate is somehow missing, the retry drops the offline switch.

set -euo pipefail

REPO_NAME="${REPO_NAME:-turso}"
REPO_DIR="/repo/${REPO_NAME}"

echo "[test-setup] Rust version:   $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:  $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Repo root:      ${REPO_DIR}"

cd "${REPO_DIR}"

echo "[test-setup] Building tursodb (turso_cli)..."
if CARGO_NET_OFFLINE=true cargo build --locked -p turso_cli --bin tursodb \
      > /tmp/tursodb-build.log 2>&1; then
    echo "[test-setup] tursodb built (offline)."
else
    echo "[test-setup] offline build failed; retrying with network."
    tail -40 /tmp/tursodb-build.log || true
    cargo build --locked -p turso_cli --bin tursodb \
      > /tmp/tursodb-build.log 2>&1 || { tail -80 /tmp/tursodb-build.log; exit 1; }
    echo "[test-setup] tursodb built (online fallback)."
fi

TARGET_DIR="${CARGO_TARGET_DIR:-${REPO_DIR}/target}"
if [ ! -x "${TARGET_DIR}/debug/tursodb" ]; then
    echo "[test-setup] ERROR: tursodb binary not found at ${TARGET_DIR}/debug/tursodb" >&2
    exit 1
fi

echo "[test-setup] Setup complete."
