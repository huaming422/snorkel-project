## Task

Fix incorrect results from virtual generated columns and trigger comparisons.
For a table with `a TEXT` and `b INTEGER AS (a > 5)`, inserting `'10'`,
`'3'`, and `'7'` should produce `b` values of `0`, `0`, and `1`. Queries
currently return incorrect values, and indexes on generated columns can
disagree with the base rows. Selecting a virtual generated column defined
as `union_tag(val)` also crashes instead of returning the union tag name.

Generated-column values must remain consistent when building and maintaining
indexes, checking NOT NULL constraints and database integrity, reading joined
rows, and returning rows from INSERT, UPDATE, and DELETE. Preserve existing
generated-column behavior and normal storage conversions.

Trigger comparisons have a different expectation: ordinary `NEW` and `OLD`
column references must not apply the source column's comparison affinity.
For a TEXT column containing `'5'`, `NEW.a = 5` and `OLD.a = 5` must be false
in WHEN guards and in the trigger body's WHERE and HAVING clauses, even
though `a = 5` matches the stored table row. This also applies to TEXT
generated columns across INSERT, UPDATE, and DELETE triggers. Rowid and
INTEGER PRIMARY KEY aliases retain integer comparison affinity, so a rowid
of `1` must still match `'1'` in a trigger comparison.

Investigate and fix these behaviors across the affected execution paths.
