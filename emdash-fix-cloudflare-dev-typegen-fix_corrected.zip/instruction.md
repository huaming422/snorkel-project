## Task

Our generated content types go stale during local development on Cloudflare. With `astro dev` and the `@astrojs/cloudflare` adapter, a collection or field that someone adds in the admin once the dev server is running never reaches the types file emdash generates at the project root. That file keeps describing the schema as it was at startup until the dev server is restarted, and after a restart it is correct again, so nothing is lost. Sites on the Node adapter with SQLite do not have this problem.

What we expect once this is fixed:

- On the Cloudflare adapter, adding a collection, adding a field or removing a field through the admin, including the collections and fields its import tools create, updates the generated types file while the dev server keeps running.
- Sites on the Node adapter with SQLite keep updating the file the way they do today, including when the dev server is started with `NODE_ENV=test`.
- How the browser reaches the dev server makes no difference. If the admin is used through a forwarded port, so the address in the browser is not the one the server listens on, the file still updates.
- A dev server whose schema nobody is editing stays quiet: nothing calls into the app or regenerates types in the background, so the dev server log shows only the requests people make.
- Existing sites pick this up by upgrading emdash, with no changes to their Astro or Wrangler configuration.
