#!/usr/bin/env bash
# Re-run the core package's existing unit suites for the schema registry and
# the Astro integration, middleware and routes, using the test files as they
# stand at the base commit, against the working tree's sources.
#
# Left out: the "dev typegen hook" block in tests/unit/schema/registry.test.ts and
# that file's import of the module holding the base commit's internal
# registration function. They describe one particular wiring rather than
# behavior a site can observe, and the import would fail the whole file for a
# fix that moves or removes that module. Both are cut from the base copy before
# the run; every other test in the file runs.
set -uo pipefail

REPO_DIR="${REPO_DIR:-/repo/emdash}"
cd "$REPO_DIR" || exit 1
BASE_REF="$(tr -d '[:space:]' < /var/lib/devcontainer_base_ref)"
SUITES=(packages/core/tests/unit/schema packages/core/tests/unit/astro)

# Put the base versions of the suite files in place, remembering the working
# copies so they can be restored afterwards.
SAVE="$(mktemp -d)"
for d in "${SUITES[@]}"; do
	mkdir -p "$SAVE/$d"
	[ -d "$d" ] && cp -a "$d/." "$SAVE/$d/"
	rm -rf "$d"
	git checkout -q "$BASE_REF" -- "$d"
done

node - packages/core/tests/unit/schema/registry.test.ts <<'NODE'
const fs = require("node:fs");
const path = process.argv[2];
let text = fs.readFileSync(path, "utf8");
text = text.replace(/^import \{[^}]*\} from "\.\.\/\.\.\/\.\.\/src\/astro\/dev-typegen\.js";\n/m, "");
const start = text.indexOf('\tdescribe("dev typegen hook"');
if (start >= 0) {
	let i = text.indexOf("{", start);
	for (let depth = 0; i < text.length; i++) {
		if (text[i] === "{") depth++;
		else if (text[i] === "}" && --depth === 0) break;
	}
	let end = text.indexOf(");", i) + 2;
	if (text[end] === "\n") end++;
	text = text.slice(0, start) + text.slice(end);
}
if (text.includes("setDevTypegenRefresh") || text.includes("astro/dev-typegen")) {
	console.error("could not cut the dev typegen hook block from " + path);
	process.exit(2);
}
fs.writeFileSync(path, text);
NODE
cut_rc=$?

cd packages/core || exit 1
if [ "$cut_rc" -eq 0 ]; then
	NODE_ENV=test npx vitest run tests/unit/schema tests/unit/astro --reporter=dot
	rc=$?
else
	rc=$cut_rc
fi
cd "$REPO_DIR" || exit 1

for d in "${SUITES[@]}"; do
	rm -rf "$d"
	mkdir -p "$d"
	cp -a "$SAVE/$d/." "$d/"
done
rm -rf "$SAVE"
exit $rc
