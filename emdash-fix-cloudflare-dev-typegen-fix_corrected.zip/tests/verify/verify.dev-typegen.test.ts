import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { spawn, type ChildProcess } from "node:child_process";
import { appendFileSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import http from "node:http";
import { createServer } from "node:net";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";

// The runner copies this file into a scratch directory at the repository root
// and runs vitest there, so the repository is the parent of the working
// directory. The checks drive the repository's own example sites under e2e/
// with a real `astro dev`: e2e/fixture-cloudflare runs on the Cloudflare
// adapter (workerd, local D1 and R2), e2e/fixture on the Node adapter with
// SQLite. The setup script builds the workspace packages those sites install
// and restores their configuration to the base commit before this file runs.
const SCRATCH = process.cwd();
const REPO = resolve(SCRATCH, "..");
const CLOUDFLARE_SITE = join(REPO, "e2e/fixture-cloudflare");
const NODE_SITE = join(REPO, "e2e/fixture");
const TYPES_FILE = "emdash-env.d.ts";
const ENCRYPTION_KEY = "emdash_enc_v1_AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
const LOG_DIR = "/logs/verifier";

// Upper bounds for outcomes that the checks wait on. The file is polled until it
// shows the expected schema or the bound passes.
const STARTUP_LIMIT_MS = 300_000;
const REFRESH_LIMIT_MS = 30_000;
// After the client's own requests in a quiet window, the client stays silent
// for this long while the dev server log is watched. An idle dev server logs
// nothing however long it is watched, so the length only bounds how slow a
// background repeat can be and still be noticed. Only the first window, which
// follows startup, allows one stray line.
const FIRST_IDLE_MS = 5_000;
const LATER_IDLE_MS = 20_000;

// One request line in the dev server output, e.g.
//   [201] POST /_emdash/api/schema/collections 132ms
//   [200] /_emdash/admin 5055ms
const REQUEST_LINE = /\[(\d{3})\] (?:(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS) )?(\/\S*) \d+ms/g;

function buildProblem(): string | null {
	if (existsSync(join(SCRATCH, "build-failed"))) {
		return "the workspace packages did not build from the working tree (see workspace_build.log)";
	}
	return null;
}

function freePort(): Promise<number> {
	return new Promise((ok, fail) => {
		const srv = createServer();
		srv.once("error", fail);
		srv.listen(0, "127.0.0.1", () => {
			const address = srv.address();
			const port = typeof address === "object" && address ? address.port : 0;
			srv.close(() => ok(port));
		});
	});
}

interface Reply {
	status: number;
	body: string;
	json: any;
}

class DevSite {
	readonly dir: string;
	readonly env: Record<string, string>;
	port = 0;
	token = "";
	output = "";
	failure: string | null = null;
	private proc: ChildProcess | undefined;
	private dataDir = "";
	// Every request this file made that got a response, as "METHOD /path".
	private issued: string[] = [];
	// Milliseconds each wait on the generated file took (-1: never satisfied).
	waits: number[] = [];

	constructor(dir: string, env: Record<string, string> = {}) {
		this.dir = dir;
		this.env = env;
	}

	get typesPath(): string {
		return join(this.dir, TYPES_FILE);
	}

	types(): string {
		return existsSync(this.typesPath) ? readFileSync(this.typesPath, "utf8") : "";
	}

	async start(): Promise<void> {
		const problem = buildProblem();
		if (problem) {
			this.failure = problem;
			return;
		}
		this.port = await freePort();
		this.dataDir = mkdtempSync(join(tmpdir(), "emdash-site-"));
		rmSync(join(this.dir, ".wrangler"), { recursive: true, force: true });
		rmSync(this.typesPath, { force: true });
		const astro = join(this.dir, "node_modules/.bin/astro");
		// The dev server gets a plain shell environment: the test runner's own
		// markers (VITEST, NODE_ENV=test, ...) would otherwise reach Astro and Vite.
		const base: Record<string, string> = {};
		for (const [k, v] of Object.entries(process.env)) {
			if (v === undefined || /^(VITEST|TEST$|NODE_ENV$|NODE_OPTIONS$|MODE$)/.test(k)) continue;
			base[k] = v;
		}
		this.proc = spawn(astro, ["dev", "--port", String(this.port), "--host", "127.0.0.1"], {
			cwd: this.dir,
			detached: true,
			stdio: ["ignore", "pipe", "pipe"],
			env: {
				...base,
				ASTRO_TELEMETRY_DISABLED: "1",
				ASTRO_DEV_BACKGROUND: "1",
				EMDASH_TEST_DB: `file:${join(this.dataDir, "site.db")}`,
				EMDASH_ENCRYPTION_KEY: ENCRYPTION_KEY,
				...this.env,
			},
		});
		const keep = (chunk: Buffer) => {
			this.output += chunk.toString();
		};
		this.proc.stdout?.on("data", keep);
		this.proc.stderr?.on("data", keep);
		let exited = false;
		this.proc.once("exit", () => {
			exited = true;
		});

		// Ready once the setup status route answers 2xx; the first requests can
		// fail while the dev server is still preparing its dependencies.
		const deadline = Date.now() + STARTUP_LIMIT_MS;
		let ready = false;
		while (!ready && Date.now() < deadline && !exited) {
			try {
				const reply = await this.request("GET", "/_emdash/api/setup/status");
				ready = reply.status >= 200 && reply.status < 300;
			} catch {}
			if (!ready) await new Promise((r) => setTimeout(r, 500));
		}
		if (!ready) {
			this.failure = `dev server did not become ready; output tail:\n${this.output.slice(-3000)}`;
			return;
		}
		const bypass = await this.request("GET", "/_emdash/api/setup/dev-bypass?token=1");
		this.token = bypass.json?.data?.token ?? "";
		if (!this.token) {
			this.failure = `dev sign-in failed (${bypass.status}): ${bypass.body.slice(0, 300)}`;
		}
	}

	async stop(): Promise<void> {
		// Keep the dev server output and the wait times next to the results.
		try {
			mkdirSync(LOG_DIR, { recursive: true });
			const name = `${this.dir.split("/").pop()}${this.env.NODE_ENV ? `-${this.env.NODE_ENV}` : ""}`;
			writeFileSync(join(LOG_DIR, `devserver-${name}.log`), this.output);
			appendFileSync(join(LOG_DIR, "devserver-waits.txt"), `${name}: ${this.waits.join(", ")}\n`);
		} catch {}
		const proc = this.proc;
		if (!proc || proc.exitCode !== null) return;
		const gone = new Promise((r) => proc.once("exit", r));
		try {
			process.kill(-proc.pid!, "SIGTERM");
		} catch {}
		await Promise.race([gone, new Promise((r) => setTimeout(r, 10_000))]);
		try {
			process.kill(-proc.pid!, "SIGKILL");
		} catch {}
	}

	// A request to the dev server. `hostHeader` sets the address the client
	// believes it is talking to, as a browser behind a forwarded port would.
	request(
		method: string,
		path: string,
		body?: unknown,
		hostHeader?: string,
		accept = "application/json",
	): Promise<Reply> {
		const payload = body === undefined ? undefined : JSON.stringify(body);
		const host = hostHeader ?? `127.0.0.1:${this.port}`;
		const headers: Record<string, string> = {
			host,
			accept,
			origin: `http://${host}`,
			"x-emdash-request": "1",
		};
		if (this.token) headers.authorization = `Bearer ${this.token}`;
		if (payload !== undefined) {
			headers["content-type"] = "application/json";
			headers["content-length"] = String(Buffer.byteLength(payload));
		}
		return new Promise((ok, fail) => {
			const req = http.request(
				{ host: "127.0.0.1", port: this.port, path, method, headers, timeout: 180_000 },
				(res) => {
					let text = "";
					res.setEncoding("utf8");
					res.on("data", (d) => (text += d));
					res.on("end", () => {
						this.issued.push(`${method} ${path.split("?")[0]}`);
						let json: any = null;
						try {
							json = JSON.parse(text);
						} catch {}
						ok({ status: res.statusCode ?? 0, body: text, json });
					});
				},
			);
			req.on("timeout", () => req.destroy(new Error(`${method} ${path} timed out`)));
			req.on("error", fail);
			if (payload !== undefined) req.write(payload);
			req.end();
		});
	}

	async schemaChange(method: string, path: string, body?: unknown, hostHeader?: string) {
		const reply = await this.request(method, path, body, hostHeader);
		expect(reply.status, `${method} ${path} answered ${reply.status}: ${reply.body.slice(0, 300)}`).toBeLessThan(300);
		return reply;
	}

	// Wait until the generated file satisfies `check`, or the limit passes.
	async typesUntil(check: (text: string) => boolean, limitMs = REFRESH_LIMIT_MS): Promise<boolean> {
		const start = Date.now();
		const deadline = start + limitMs;
		while (Date.now() < deadline) {
			if (check(this.types())) {
				this.waits.push(Date.now() - start);
				return true;
			}
			await new Promise((r) => setTimeout(r, 50));
		}
		this.waits.push(-1);
		return check(this.types());
	}

	// Requests the dev server logged, as "METHOD /path", in order.
	loggedRequests(): string[] {
		const lines: string[] = [];
		for (const m of this.output.matchAll(REQUEST_LINE)) lines.push(`${m[2] ?? "GET"} ${m[3]!.split("?")[0]}`);
		return lines;
	}

	issuedCount(): number {
		return this.issued.length;
	}

	// Run `steps` (page loads and content edits, never a schema edit), then make
	// no request for `idleMs`, and report what else reached the app: lines logged
	// while the steps ran and lines logged during the silence. Each step's own
	// request line is awaited in the output before the silence starts, so the
	// comparison never races the log.
	async trafficWhile(
		steps: Array<() => Promise<Reply>>,
		idleMs: number,
	): Promise<{ duringSteps: string[]; duringIdle: string[] }> {
		const before = this.loggedRequests().length;
		const issuedBefore = this.issuedCount();
		for (const step of steps) {
			const reply = await step();
			expect(reply.status, `a request answered ${reply.status}: ${reply.body.slice(0, 200)}`).toBeLessThan(500);
		}
		const mine = this.issued.slice(issuedBefore);
		const deadline = Date.now() + 10_000;
		const missing = (window: string[]) => {
			const left = [...window];
			return mine.some((r) => {
				const at = left.indexOf(r);
				if (at < 0) return true;
				left.splice(at, 1);
				return false;
			});
		};
		let window = this.loggedRequests().slice(before);
		while (Date.now() < deadline && missing(window)) {
			await new Promise((r) => setTimeout(r, 100));
			window = this.loggedRequests().slice(before);
		}
		const duringSteps = [...window];
		for (const r of mine) {
			const at = duringSteps.indexOf(r);
			if (at >= 0) duringSteps.splice(at, 1);
		}
		const idleStart = this.loggedRequests().length;
		await new Promise((r) => setTimeout(r, idleMs));
		const duringIdle = this.loggedRequests().slice(idleStart);
		return { duringSteps, duringIdle };
	}
}

const collectionsKey = (slug: string) => new RegExp(`\\b${slug}\\s*:`);

function editingSuite(label: string, site: () => DevSite, prefix: string, extras: { mcp?: boolean } = {}) {
	const col = `${prefix}_notes`;
	const viaForward = `${prefix}_routes`;
	const forwardedPort = { port: 0 };

	it(`${label}: the types file is written for the schema the site starts with`, async () => {
		const s = site();
		expect(s.failure, s.failure ?? "").toBeNull();
		const ok = await s.typesUntil((t) => /interface Post\b/.test(t), 60_000);
		expect(ok, `the generated file never described the seeded collections:\n${s.types().slice(0, 400)}`).toBe(true);
	});

	it(`${label}: opening the admin, viewing a page and writing posts cause no other traffic`, async () => {
		const s = site();
		expect(s.failure, s.failure ?? "").toBeNull();
		const { duringSteps, duringIdle } = await s.trafficWhile(
			[
				() => s.request("GET", "/_emdash/admin", undefined, undefined, "text/html"),
				() => s.request("POST", "/_emdash/api/content/posts", { data: { title: `Quiet ${prefix} one` } }),
				() => s.request("GET", "/", undefined, undefined, "text/html"),
				() => s.request("POST", "/_emdash/api/content/posts", { data: { title: `Quiet ${prefix} two` } }),
				() => s.request("GET", "/_emdash/api/content/posts?limit=5"),
			],
			FIRST_IDLE_MS,
		);
		const others = [...duringSteps, ...duringIdle];
		expect(
			others.length,
			`requests the client did not make reached the app while nothing changed: ${others.join(", ")}`,
		).toBeLessThanOrEqual(1);
	});

	it(`${label}: a collection added through the admin shows up without a restart`, async () => {
		const s = site();
		expect(s.failure, s.failure ?? "").toBeNull();
		await s.schemaChange("POST", "/_emdash/api/schema/collections", {
			slug: col,
			label: "Harbor Notes",
			labelSingular: "Harbor Note",
		});
		const ok = await s.typesUntil((t) => collectionsKey(col).test(t));
		expect(ok, `the generated file does not list ${col}`).toBe(true);
	});

	it(`${label}: fields added to and removed from a collection show up without a restart`, async () => {
		const s = site();
		expect(s.failure, s.failure ?? "").toBeNull();
		await s.schemaChange("POST", `/_emdash/api/schema/collections/${col}/fields`, {
			slug: "tide_level",
			label: "Tide level",
			type: "number",
		});
		expect(await s.typesUntil((t) => /\btide_level\??:/.test(t)), "added field tide_level is missing").toBe(true);
		await s.schemaChange("POST", `/_emdash/api/schema/collections/${col}/fields`, {
			slug: "berth_code",
			label: "Berth code",
			type: "string",
		});
		expect(await s.typesUntil((t) => /\bberth_code\??:/.test(t)), "added field berth_code is missing").toBe(true);
		await s.schemaChange("DELETE", `/_emdash/api/schema/collections/${col}/fields/tide_level`);
		expect(
			await s.typesUntil((t) => !/\btide_level\??:/.test(t) && /\bberth_code\??:/.test(t)),
			"removed field tide_level is still in the generated file",
		).toBe(true);
	});

	it(`${label}: a change made through a forwarded port shows up the same way`, async () => {
		const s = site();
		expect(s.failure, s.failure ?? "").toBeNull();
		// The client addresses a port nothing listens on, as a browser does when
		// a container or tunnel forwards it to the dev server's own port.
		forwardedPort.port = await freePort();
		const host = `localhost:${forwardedPort.port}`;
		await s.schemaChange(
			"POST",
			"/_emdash/api/schema/collections",
			{ slug: viaForward, label: "Ferry Routes", labelSingular: "Ferry Route" },
			host,
		);
		expect(await s.typesUntil((t) => collectionsKey(viaForward).test(t)), `the generated file does not list ${viaForward}`).toBe(true);
		await s.schemaChange(
			"POST",
			`/_emdash/api/schema/collections/${viaForward}/fields`,
			{ slug: "crossing_minutes", label: "Crossing minutes", type: "number" },
			host,
		);
		expect(await s.typesUntil((t) => /\bcrossing_minutes\??:/.test(t)), "field added through the forwarded port is missing").toBe(true);
	});

	it(`${label}: collections and fields created by the admin's WordPress import show up without a restart`, async () => {
		const s = site();
		expect(s.failure, s.failure ?? "").toBeNull();
		await s.schemaChange("POST", "/_emdash/api/import/wordpress/prepare", {
			postTypes: [
				{
					name: "wp_event",
					collection: `${prefix}_events`,
					fields: [{ slug: "venue_name", label: "Venue", type: "string", required: false }],
				},
			],
		});
		expect(
			await s.typesUntil((t) => collectionsKey(`${prefix}_events`).test(t) && /\bvenue_name\??:/.test(t)),
			`the generated file does not show the imported ${prefix}_events collection and its field`,
		).toBe(true);
	});

	it(`${label}: deleting a relation through the admin removes the reference field bound to it`, async () => {
		const s = site();
		expect(s.failure, s.failure ?? "").toBeNull();
		const relation = `${prefix}_moorings`;
		const created = await s.schemaChange("POST", "/_emdash/api/relations", {
			slug: relation,
			parentCollection: col,
			childCollection: "posts",
			parentLabel: "Moorings",
			childLabel: "Mooring notes",
		});
		const id = created.json?.data?.relation?.id ?? created.json?.data?.id;
		expect(typeof id, `relation create answered ${created.body.slice(0, 300)}`).toBe("string");
		await s.schemaChange("POST", `/_emdash/api/schema/collections/${col}/fields`, {
			slug: "mooring_post",
			label: "Mooring post",
			type: "reference",
			validation: { relation, relationSide: "parent", targetCollection: "posts" },
		});
		expect(await s.typesUntil((t) => /\bmooring_post\??:/.test(t)), "reference field mooring_post is missing").toBe(true);
		await s.schemaChange("DELETE", `/_emdash/api/relations/${id}`);
		expect(
			await s.typesUntil((t) => !/\bmooring_post\??:/.test(t)),
			"the reference field removed with its relation is still in the generated file",
		).toBe(true);
	});

	if (extras.mcp) {
		it(`${label}: a collection created with the MCP tools shows up without a restart`, async () => {
			const s = site();
			expect(s.failure, s.failure ?? "").toBeNull();
			const reply = await s.request(
				"POST",
				"/_emdash/api/mcp",
				{
					jsonrpc: "2.0",
					id: 1,
					method: "tools/call",
					params: { name: "schema_create_collection", arguments: { slug: `${prefix}_tools`, label: "Tool Made" } },
				},
				undefined,
				"application/json, text/event-stream",
			);
			expect(reply.status, reply.body.slice(0, 300)).toBe(200);
			expect(reply.body.includes(`${prefix}_tools`), reply.body.slice(0, 300)).toBe(true);
			expect(await s.typesUntil((t) => collectionsKey(`${prefix}_tools`).test(t)), "MCP-created collection is missing").toBe(true);
		});
	}

	it(`${label}: after the edits, viewing pages and writing posts cause no other traffic`, async () => {
		const s = site();
		expect(s.failure, s.failure ?? "").toBeNull();
		const { duringSteps, duringIdle } = await s.trafficWhile(
			[
				() => s.request("GET", "/text-alignment", undefined, undefined, "text/html"),
				() => s.request("POST", "/_emdash/api/content/posts", { data: { title: `Quiet ${prefix} three` } }),
				() => s.request("GET", "/image-variants", undefined, undefined, "text/html"),
				() => s.request("POST", "/_emdash/api/content/posts", { data: { title: `Quiet ${prefix} four` } }),
				() => s.request("GET", "/posts/does-not-exist", undefined, undefined, "text/html"),
				() => s.request("GET", "/fr/posts/does-not-exist", undefined, undefined, "text/html"),
			],
			LATER_IDLE_MS,
		);
		expect(
			duringSteps.length,
			`requests the client did not make reached the app while pages were viewed and posts written: ${duringSteps.join(", ")}`,
		).toBeLessThanOrEqual(1);
		expect(
			duringIdle,
			`requests reached the app while the client made none: ${duringIdle.join(", ")}`,
		).toEqual([]);
	});
}

describe("astro dev with the Cloudflare adapter", () => {
	const site = new DevSite(CLOUDFLARE_SITE);
	beforeAll(() => site.start(), STARTUP_LIMIT_MS + 60_000);
	afterAll(() => site.stop(), 30_000);
	editingSuite("cloudflare", () => site, "cf");
});

describe("astro dev with the Node adapter and SQLite", () => {
	const site = new DevSite(NODE_SITE);
	beforeAll(() => site.start(), STARTUP_LIMIT_MS + 60_000);
	afterAll(() => site.stop(), 30_000);
	editingSuite("node", () => site, "nd", { mcp: true });
});

describe("astro dev with the Node adapter under NODE_ENV=test", () => {
	const site = new DevSite(NODE_SITE, { NODE_ENV: "test" });
	beforeAll(() => site.start(), STARTUP_LIMIT_MS + 60_000);
	afterAll(() => site.stop(), 30_000);
	editingSuite("node, NODE_ENV=test", () => site, "nt", { mcp: true });
});
