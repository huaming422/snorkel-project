#!/usr/bin/env bash
# Environment bootstrap for the TypeScript checks.
#
# Sourced (not exec'd) by the harbor runner, so env vars set here stay live for
# the test subprocess.
#
# The image carries the full dependency closure installed offline at the base
# commit (pnpm store warm, node_modules installed with --frozen-lockfile). The
# checks run the repository's example sites under e2e/ with `astro dev`, and
# those sites load the workspace packages from their built output, so this
# script builds those packages from the working tree. Nothing is fetched.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/emdash}"
export REPO_DIR
cd "$REPO_DIR"

# Fail fast on any accidental network reach during the run instead of retrying
# against the (offline) network.
export npm_config_offline=true

# Shared run infrastructure runs under the canonical /opt/tooling venv.
export VERIFIER_PYTHON="${VERIFIER_PYTHON:-/opt/tooling/venv/bin/python}"

# Sanity check: the core package's vitest binary must be resolvable. A failure
# here points at a corrupted node_modules — bail now rather than surfacing a
# confusing "vitest: command not found" later. Offline-first: reinstall only
# falls back to the warm store, which the image already holds.
if ! [ -x node_modules/.bin/vitest ] && ! [ -x packages/core/node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing; reinstalling from the warm store." >&2
    pnpm install --frozen-lockfile --offline
fi

# Stage the scratch package the checks run from. It borrows the labeler app's
# installed modules (which include vitest) by symlink and ships a tiny vitest
# config that selects the copied test file. The runner copies the test file
# into this directory and runs vitest with it as the working directory.
SCRATCH="$REPO_DIR/.verify-dtg"
BORROW_MODULES="$REPO_DIR/apps/labeler/node_modules"
if ! [ -d "$BORROW_MODULES" ]; then
    echo "test-setup.sh: expected module closure missing at $BORROW_MODULES" >&2
    exit 1
fi
mkdir -p "$SCRATCH"
ln -sfn "$BORROW_MODULES" "$SCRATCH/node_modules"
cat > "$SCRATCH/vitest.config.ts" <<'VITEST'
import { defineConfig } from "vitest/config";

export default defineConfig({
	test: { include: ["verify*.test.ts"], watch: false, fileParallelism: false },
});
VITEST

# The example sites are run exactly as they stand at the base commit: a site
# owner upgrades the package and changes no configuration.
BASE_REF="$(tr -d '[:space:]' < /var/lib/devcontainer_base_ref)"
git checkout -q "$BASE_REF" -- e2e/fixture e2e/fixture-cloudflare e2e/fixtures
git clean -fdq -- e2e/fixture e2e/fixture-cloudflare e2e/fixtures

# Build the workspace packages the two sites depend on, from the working tree.
# The installed dependency tree is the image's own; pnpm's pre-run freshness
# check compares file times and would refuse to run after any checkout, so it
# is turned off. A build failure is recorded for the checks to report instead
# of aborting here.
mkdir -p /logs/verifier
rm -f "$SCRATCH/build-failed"
if ! NODE_OPTIONS=--max-old-space-size=4096 pnpm --config.verify-deps-before-run=false run \
        --filter "emdash-e2e-fixture..." --filter "emdash-e2e-fixture-cloudflare..." build \
        > /logs/verifier/workspace_build.log 2>&1; then
    echo "test-setup.sh: workspace build failed; see /logs/verifier/workspace_build.log" >&2
    : > "$SCRATCH/build-failed"
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR node=$(node --version 2>/dev/null || echo unknown)"
