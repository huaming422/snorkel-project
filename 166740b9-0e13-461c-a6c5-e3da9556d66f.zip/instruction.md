## Task

Calling an element's settable field with parentheses under `context`, such as `#context heading.numbering(1)` or `#context block.stroke(..)`, currently says the function does not contain that field. The field is real, so the error sends users looking for a spelling mistake instead of explaining the invalid call. Please make this diagnostic consistent with other field calls that cannot be used as methods, with guidance that fits the field's value.

The same call outside `context` should also stop claiming the field is missing. Keep dictionary and named-argument diagnostics, genuinely missing fields, and valid contextual field access working as they do now.
