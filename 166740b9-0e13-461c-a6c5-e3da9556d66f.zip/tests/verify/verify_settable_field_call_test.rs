//! Behavioral verifier for the "settable field called like a method" diagnostic
//! fix (typst bug: calling `heading.numbering(..)` etc.).
//!
//! WHAT THIS TESTS THROUGH — the typst compiler DIAGNOSTIC interface, a
//! pre-existing, stable public API:
//!   * `typst::compile::<PagedDocument>(&dyn World)` returns
//!     `Warned<SourceResult<_>>`; it runs the eval/scripting stage internally,
//!     so every field-call resolution diagnostic (both the evaluation errors and
//!     the contextual/paged ones) surfaces here. On error the
//!     `SourceDiagnostic`s carry `.message` and `.hints` (each hint a
//!     `Spanned<EcoString>`). We compile a small `.typ` snippet and assert on
//!     the TEXT of the emitted message + hints (substring / semantic match).
//!
//! We deliberately drive everything through the single public `compile` entry
//! point rather than calling `typst_eval::eval` directly: `eval`'s signature has
//! drifted across releases (an added `&Routines` parameter), whereas `compile`
//! is the stable facade a compiler embedder uses, and it reports the identical
//! eval-stage diagnostics.
//!
//! Assertions inspect the compiler's user-visible diagnostic text. The
//! implementation may choose its own internal structure.
//!
//! This test builds its OWN minimal `World` (the repo's `tests/src/world.rs`
//! `TestWorld` is private to a `harness = false` target and not importable);
//! it reuses only the public `typst` facade + `typst-assets` / `typst-dev-assets`
//! fonts, exactly as a user embedding the compiler would.

use std::path::PathBuf;

use typst::diag::{FileError, FileResult, SourceDiagnostic, SourceResult, Warned};
use typst::foundations::{Bytes, Datetime, Duration};
use typst::syntax::{FileId, Source};
use typst::text::{Font, FontBook};
use typst::utils::LazyHash;
use typst::{Features, Library, LibraryExt, World};
use typst_layout::PagedDocument;

// ─────────────────────────────── Minimal World ──────────────────────────────

/// A self-contained compiler world: one in-memory main source file, the full
/// standard library (all features), and the bundled test fonts. No file system,
/// no packages — the snippets under test need none.
struct VerifyWorld {
    main: Source,
    library: LazyHash<Library>,
    book: LazyHash<FontBook>,
    fonts: Vec<Font>,
}

impl VerifyWorld {
    fn new(text: &str) -> Self {
        let fonts: Vec<Font> = typst_assets::fonts()
            .chain(typst_dev_assets::fonts())
            .flat_map(|data| Font::iter(Bytes::new(data)))
            .collect();
        Self {
            main: Source::detached(text),
            library: LazyHash::new(Library::builder().with_features(Features::all()).build()),
            book: LazyHash::new(FontBook::from_fonts(&fonts)),
            fonts,
        }
    }
}

impl World for VerifyWorld {
    fn library(&self) -> &LazyHash<Library> {
        &self.library
    }

    fn book(&self) -> &LazyHash<FontBook> {
        &self.book
    }

    fn main(&self) -> FileId {
        self.main.id()
    }

    fn source(&self, id: FileId) -> FileResult<Source> {
        if id == self.main.id() {
            Ok(self.main.clone())
        } else {
            // Unreachable: the snippets reference no other files. Return a plain
            // NotFound without touching deprecated VirtualPath accessors.
            Err(FileError::NotFound(PathBuf::new()))
        }
    }

    fn file(&self, id: FileId) -> FileResult<Bytes> {
        if id == self.main.id() {
            Ok(Bytes::from_string(self.main.text().to_string()))
        } else {
            Err(FileError::NotFound(PathBuf::new()))
        }
    }

    fn font(&self, index: usize) -> Option<Font> {
        self.fonts.get(index).cloned()
    }

    fn today(&self, _offset: Option<Duration>) -> Option<Datetime> {
        Datetime::from_ymd(1970, 1, 1)
    }
}

// ─────────────────────────────── Diagnostics ────────────────────────────────

/// What a compile produced: the error messages and hint texts, flattened for
/// substring assertions. `ok` is true when compilation succeeded with no fatal
/// errors.
struct Diagnostics {
    ok: bool,
    messages: Vec<String>,
    hints: Vec<String>,
}

impl Diagnostics {
    fn from_result<T>(result: &SourceResult<T>) -> Self {
        match result {
            Ok(_) => Diagnostics { ok: true, messages: vec![], hints: vec![] },
            Err(diags) => Self::from_diags(diags),
        }
    }

    fn from_diags(diags: &[SourceDiagnostic]) -> Self {
        let mut messages = Vec::new();
        let mut hints = Vec::new();
        for d in diags {
            messages.push(d.message.to_string());
            for h in &d.hints {
                hints.push(h.v.to_string());
            }
        }
        Diagnostics { ok: false, messages, hints }
    }

    fn any_message_contains(&self, needle: &str) -> bool {
        self.messages.iter().any(|m| m.contains(needle))
    }

    fn any_hint_contains(&self, needle: &str) -> bool {
        self.hints.iter().any(|h| h.contains(needle))
    }

    fn render(&self) -> String {
        format!(
            "ok={}\n  messages={:#?}\n  hints={:#?}",
            self.ok, self.messages, self.hints
        )
    }
}

/// Full compile through the public facade (`typst::compile::<PagedDocument>`).
/// `compile` runs the eval/scripting stage internally, so field-call resolution
/// diagnostics — whether they arise at pure evaluation (`#heading.numbering(1)`
/// with no `context`) or only under the contextual/paged layout path — all
/// surface here. Using the one stable entry point keeps the verifier robust to
/// `typst_eval::eval`'s cross-release signature drift.
fn compile_diagnostics(snippet: &str) -> Diagnostics {
    let world = VerifyWorld::new(snippet);
    let Warned { output, .. } = typst::compile::<PagedDocument>(&world);
    Diagnostics::from_result(&output)
}

// ──────────────────────────────── Criterion 1 ───────────────────────────────
// Calling a settable element field like a
// method under `context` no longer claims the function "does not contain field";
// it reports that the field is not a valid method.

#[test]
fn bad_error_improved_contextual_func_field() {
    let diag = compile_diagnostics(
        "#set heading(numbering: (..n) => none)\n#context heading.numbering(1)\n",
    );

    assert!(
        diag.any_message_contains("is not a valid method for"),
        "expected the diagnostic to report that the called field is not a valid \
         method (the compiler's standard disallowed-field-call message family), \
         got:\n{}",
        diag.render()
    );
    assert!(
        !diag.any_message_contains("does not contain field"),
        "the missing-field message \"...does not contain field...\" must no \
         longer be emitted for a settable element field called like a method, \
         got:\n{}",
        diag.render()
    );
}

// ──────────────────────────────── Criterion 2 ───────────────────────────────
// When the settable field holds a FUNCTION,
// the hint points the user to wrap the field access in parentheses to call it.

#[test]
fn func_field_hint_wrap_in_parentheses() {
    let diag = compile_diagnostics(
        "#set heading(numbering: (..n) => none)\n#context heading.numbering(1)\n",
    );

    assert!(
        !diag.ok,
        "calling the settable field as a method must still be an error, got:\n{}",
        diag.render()
    );
    // Semantic match: the actionable guidance is to wrap the field access in
    // parentheses. We assert the stable phrase + the parenthesization cue, not
    // the exact full sentence, so reworded-but-equivalent hints still pass.
    assert!(
        diag.any_hint_contains("wrap the field access in parentheses"),
        "expected a hint telling the user to wrap the field access in \
         parentheses to call the stored function, got:\n{}",
        diag.render()
    );
    assert!(
        diag.any_hint_contains("(heading.numbering)"),
        "expected the wrap-in-parentheses hint to show the corrected form \
         `(heading.numbering)(..)`, got:\n{}",
        diag.render()
    );
}

// ──────────────────────────────── Criterion 3 ───────────────────────────────
// When the settable field holds a
// NON-function value, the hint instead points the user to remove the arguments
// and just read the field.

#[test]
fn nonfunc_field_hint_remove_arguments() {
    let diag = compile_diagnostics(
        "#set heading(numbering: \"1.\")\n#context heading.numbering(1)\n",
    );

    assert!(
        diag.any_message_contains("is not a valid method for"),
        "a non-function settable field called like a method must also report the \
         not-a-valid-method diagnostic, got:\n{}",
        diag.render()
    );
    assert!(
        diag.any_hint_contains("remove the function arguments"),
        "expected a hint telling the user to remove the function arguments and \
         access the field directly, got:\n{}",
        diag.render()
    );
    assert!(
        diag.any_hint_contains("heading.numbering"),
        "expected the remove-arguments hint to show the corrected field access \
         `heading.numbering`, got:\n{}",
        diag.render()
    );
    // The func-value hint and the non-func-value hint are DISTINCT: a non-func
    // field must NOT be told to "wrap ... in parentheses" to call it.
    assert!(
        !diag.any_hint_contains("wrap the field access in parentheses"),
        "a non-function field must not receive the call-the-stored-function \
         (wrap-in-parentheses) hint, got:\n{}",
        diag.render()
    );
}

#[test]
fn block_stroke_settable_field_call_uses_invalid_method_error() {
    let diag = compile_diagnostics("#set block(stroke: red)\n#context block.stroke(1)\n");
    assert!(diag.any_message_contains("is not a valid method for"), "{}", diag.render());
    assert!(diag.any_hint_contains("remove the function arguments"), "{}", diag.render());
    assert!(!diag.any_message_contains("does not contain field"), "{}", diag.render());
}

#[test]
fn block_stroke_without_context_does_not_claim_field_is_missing() {
    let diag = compile_diagnostics("#set block(stroke: red)\n#block.stroke(1)\n");
    assert!(!diag.ok, "{}", diag.render());
    assert!(diag.any_message_contains("can only be used when context is known")
        || diag.any_message_contains("is not a valid method for"), "{}", diag.render());
    assert!(!diag.any_message_contains("does not contain field"), "{}", diag.render());
}

// ──────────────────────────────── Criterion 4 ───────────────────────────────
// The same call WITHOUT `context` must
// identify the missing context or the invalid method call, not a missing field.

#[test]
fn no_context_does_not_claim_field_is_missing() {
    let diag = compile_diagnostics(
        "#set heading(numbering: (..n) => none)\n#heading.numbering(1)\n",
    );

    assert!(
        !diag.ok && (diag.any_message_contains("can only be used when context is known")
            || diag.any_message_contains("is not a valid method for")),
        "without `context`, the call must fail with a context error or the \
         standard invalid-method diagnostic, got:\n{}",
        diag.render()
    );
    assert!(
        !diag.any_message_contains("does not contain field"),
        "the misleading \"does not contain field\" message must not be emitted \
         for the no-context case, got:\n{}",
        diag.render()
    );
}

// ──────────────────────────────── Criterion 5 ───────────────────────────────
// Contextual field access and existing error behavior must hold
// for valid and invalid calls alike.
//   (a) valid contextual PARENTHESIZED field access still evaluates to the
//       stored function's result — `(heading.numbering)(1, 2)` == arguments(1,2).
//   (b) the pre-existing disallowed-field-call diagnostics for dictionaries and
//       named-argument fields are UNCHANGED (scope guard: the fix must not
//       disturb the cases that already report sensibly).

#[test]
fn contextual_parenthesized_field_access_still_works() {
    // Uses the library's `assert.eq`: if the parenthesized call does not yield
    // `arguments(1, 2)`, eval fails with an assertion error (ok == false).
    let diag = compile_diagnostics(
        "#set heading(numbering: (..n) => n)\n\
         #context assert.eq((heading.numbering)(1, 2), arguments(1, 2))\n",
    );

    assert!(
        diag.ok,
        "valid contextual parenthesized field access `(heading.numbering)(1, 2)` \
         must still evaluate to `arguments(1, 2)` — the fix must not break \
         legitimate contextual field reads, got:\n{}",
        diag.render()
    );
}

#[test]
fn preexisting_dict_field_call_error_unchanged() {
    // A dictionary key called as a method: the compiler already reports this
    // sensibly and the fix must leave it alone.
    let diag = compile_diagnostics("#(non-func: 1).non-func()\n");

    assert!(
        diag.any_message_contains("cannot directly call dictionary keys as functions"),
        "the pre-existing dictionary disallowed-field-call error must be \
         unchanged, got:\n{}",
        diag.render()
    );
    assert!(diag.any_hint_contains("to access the `non-func` key, remove the function arguments"), "{}", diag.render());
    assert!(diag.any_hint_contains("dictionary keys cannot be used with method syntax"), "{}", diag.render());
}

#[test]
fn preexisting_named_argument_field_call_error_unchanged() {
    // A named-argument field called as a method: likewise pre-existing and must
    // stay unchanged.
    let diag = compile_diagnostics("#arguments(non-func: 1).non-func()\n");

    assert!(
        diag.any_message_contains("cannot directly call named argument fields as functions"),
        "the pre-existing named-argument disallowed-field-call error must be \
         unchanged, got:\n{}",
        diag.render()
    );
    assert!(diag.any_hint_contains("to access the `non-func` argument, remove the function arguments"), "{}", diag.render());
    assert!(diag.any_hint_contains("named arguments cannot be used with method syntax"), "{}", diag.render());
}

#[test]
fn preexisting_length_field_call_error_unchanged() {
    let diag = compile_diagnostics("#(1pt).abs()\n");
    assert!(diag.any_message_contains("is not a valid method for"), "{}", diag.render());
    assert!(diag.any_hint_contains("remove the function arguments"), "{}", diag.render());
}

#[test]
fn genuinely_missing_element_field_error_unchanged() {
    for snippet in ["#context heading.nonexistent(1)\n", "#heading.nonexistent(1)\n"] {
        let diag = compile_diagnostics(snippet);
        assert!(diag.any_message_contains("does not contain field"),
            "an unknown element-function field must still report a missing field, got:\n{}",
            diag.render());
    }
}
