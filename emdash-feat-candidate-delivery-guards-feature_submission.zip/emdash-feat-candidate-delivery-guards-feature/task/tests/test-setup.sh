#!/usr/bin/env bash
# Sourced (not exec'd) by the verifier runner so env vars stay alive for vitest.
# Idempotent. The bot's unit tier (`vitest run --config vitest.config.ts`,
# tests/unit/**) is pure Node: the lib modules are plain TypeScript imported
# directly (vitest/esbuild transpiles on the fly), with no dist build, no
# Workers pool, and no network. The image baked the dependency closure at the
# base commit, so the install below is an offline no-op on the built task; the
# online fallback only matters when an agent wiped node_modules.

set -e

REPO_DIR="${REPO_DIR:-/repo/emdash}"
BOT_DIR="${BOT_DIR:-$REPO_DIR/infra/emdash-bot}"
cd "$REPO_DIR"

node --version
pnpm --version

# Install workspace deps if missing. Offline-first against the warm pnpm store
# baked into the image; fall back to a logged online install only if that fails
# (e.g. an agent reinstall left the store inconsistent).
if [ ! -d "node_modules/.pnpm" ]; then
	echo "[test-setup] pnpm install (offline, frozen)..."
	if ! pnpm install --frozen-lockfile --offline > /tmp/test-setup-install.log 2>&1; then
		echo "[test-setup] offline install failed; retrying online..." >&2
		pnpm install --frozen-lockfile > /tmp/test-setup-install.log 2>&1 || {
			tail -40 /tmp/test-setup-install.log >&2
			exit 1
		}
	fi
	tail -5 /tmp/test-setup-install.log || true
fi

# Make the workspace bin dir available (vitest, tsc).
export PATH="$REPO_DIR/node_modules/.bin:$BOT_DIR/node_modules/.bin:$PATH"

echo "[test-setup] ready: $BOT_DIR (node=$(node --version), pnpm=$(pnpm --version))"
