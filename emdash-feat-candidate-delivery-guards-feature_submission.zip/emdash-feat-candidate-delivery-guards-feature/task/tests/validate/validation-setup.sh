#!/usr/bin/env bash
# Environment bootstrap for the validation story scripts. Idempotent, offline.
#
# The three guards under test live in the bot's library source at
# infra/emdash-bot/.flue/lib/*.ts and are exercised by the bot's pure-vitest
# unit tier (vitest.config.ts, include tests/unit/**/*.test.ts). vitest
# transpiles the .ts sources on the fly, so there is NO build/dist step to keep
# fresh — the stories import the library source directly and always see the
# agent's current edits. This script only guarantees the toolchain is reachable
# and the workspace deps are installed.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/emdash}"
BOT_DIR="$REPO_DIR/infra/emdash-bot"
cd "$REPO_DIR"

# Sanity: Node + pnpm + vitest are reachable (loud failure if the image drifted).
node --version
pnpm --version

# Re-install workspace deps only if a prior agent step wiped node_modules.
# The image baked `pnpm install --frozen-lockfile` at the pinned commit with a
# warm offline store under /opt/cache/pnpm-dev, so this is a no-op on a clean
# container and an offline restore otherwise.
if [ ! -d "$REPO_DIR/node_modules/.pnpm" ]; then
    echo "[validation-setup] node_modules missing; restoring pnpm deps offline..."
    pnpm install --frozen-lockfile --ignore-scripts --offline 2>&1 | tail -10
fi

# vitest must resolve from the bot package. Loud guard: if it does not, the
# stories cannot run and silence would read as "all cases passed".
cd "$BOT_DIR"
npx vitest --version

echo "[validation-setup] ready: $BOT_DIR (node=$(node --version), pnpm=$(pnpm --version))"
