// @ts-nocheck
//
// Fail-to-pass guard for the scoped push-gating behavior, driven through the
// pre-existing stable entry point `gateGithubRequest` (unchanged public name,
// documented null-allowed / reason-string-rejected contract). This defends the
// third trust guard at the verifier layer so correctness does not rest solely
// on the validation stories: a receive-pack push is allowed ONLY to the issue's
// own artifacts branch, and the decision is made from the real receive-pack
// command ref rather than ref-shaped text elsewhere in the body.
//
// These assertions are false on the pre-fix tree (which also allowed the bot
// fix branch and matched any `refs/...` substring anywhere in the payload) and
// true on any implementation satisfying the contract. Rejection WORDING is a
// solution choice, so we assert only the behavior (rejected => a non-empty
// reason string; allowed => null), never the exact phrasing.

import { describe, expect, test } from "vitest";

import { gateGithubRequest } from "../../.flue/lib/github-proxy.js";

const OWNER = "emdash-cms";
const REPO = "emdash";
const RECEIVE_PACK = "https://github.com/emdash-cms/emdash.git/git-receive-pack";

// A receive-pack command line begins with two object ids (old, new). Git object
// ids are 40-hex shas, so we frame every command with real 40-hex oids (matching
// the validation spec's push-gate cases) rather than placeholder tokens: the
// contract never requires accepting malformed oids, so a parser that validates
// oid shape must still pass these.
const OLD_OID = "0".repeat(40);
const NEW_OID = "1".repeat(40);

// pkt-line frame: 4-hex length prefix (counting the 4 header bytes) + payload;
// `<NUL>` marks the capability separator and becomes a single NUL byte before
// framing (mirrors the repo's own github-proxy.test.ts).
function pktLine(inner: string): string {
	const line = inner.replaceAll("<NUL>", String.fromCharCode(0));
	return `${(line.length + 4).toString(16).padStart(4, "0")}${line}`;
}

function receivePack(commandLine: string, issueNumber?: number) {
	const url = new URL(RECEIVE_PACK);
	const request = new Request(url, {
		method: "POST",
		body: `${pktLine(commandLine)}0000PACKpayload`,
	});
	return gateGithubRequest(request, url, OWNER, REPO, issueNumber);
}

describe("scoped push gating (fail-to-pass)", () => {
	test("allows a push that targets exactly the issue's artifacts branch", async () => {
		await expect(
			receivePack(`${OLD_OID} ${NEW_OID} refs/heads/bot/artifacts-123<NUL> report-status\n`, 123),
		).resolves.toBeNull();
	});

	test("rejects a non-artifacts branch, including the bot fix branch", async () => {
		const fixBranch = await receivePack(
			`${OLD_OID} ${NEW_OID} refs/heads/bot/fix-123<NUL> report-status\n`,
			123,
		);
		expect(typeof fixBranch).toBe("string");
		expect((fixBranch as string).length).toBeGreaterThan(0);

		const unrelated = await receivePack(
			`${OLD_OID} ${NEW_OID} refs/heads/main<NUL> report-status\n`,
			123,
		);
		expect(typeof unrelated).toBe("string");
		expect((unrelated as string).length).toBeGreaterThan(0);
	});

	test("decides from the real command ref, not a smuggled capability-section ref", async () => {
		// The command targets a disallowed ref; an allowed-looking ref string is
		// placed AFTER the NUL separator (capability section). A match-anywhere
		// parser would allow this; a command-ref parser rejects it.
		const smuggled = await receivePack(
			`${OLD_OID} ${NEW_OID} refs/meta/evil<NUL> refs/heads/bot/artifacts-123\n`,
			123,
		);
		expect(typeof smuggled).toBe("string");
		expect((smuggled as string).length).toBeGreaterThan(0);
	});

	test("rejects a receive-pack with no issue scope at all", async () => {
		const noScope = await receivePack(
			`${OLD_OID} ${NEW_OID} refs/heads/bot/artifacts-123<NUL> report-status\n`,
		);
		expect(typeof noScope).toBe("string");
		expect((noScope as string).length).toBeGreaterThan(0);
	});
});
