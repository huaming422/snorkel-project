## Task

We want to add three trust guards to the bot's candidate-delivery path, so a sandboxed agent's output can be published safely and verifiably. They're independent of each other.

The first is safe publication: writing a candidate's verified file changes to its branch through the hosting provider's git data API, in a way we can actually trust.

The second is trustworthy verification results: the record of which checks passed, that a candidate gets published against, has to be something we can rely on.

The third is scoped push gating: the authenticated git proxy should let a sandboxed agent push only to the artifacts branch that belongs to its own issue.

Design the interfaces yourself. All three live in the bot's TypeScript library code and have to be implementable and testable offline, with no Cloudflare Workers runtime, no network, and no live GitHub. Match the public-interface contracts implied by the existing proxy code and the requirements above.

## User stories / requirements

- Publishing a candidate's verified file changes points the branch at a new commit holding exactly that content, confirmed afterward. If the branch moved to anything but this run's own earlier commit, the publish refuses rather than overwriting. Retrying the same run returns the commit it already made instead of a second one or a failure.
- Before a candidate is published, its passing-check record can be trusted: only the latest result per named check counts, a check's command cannot change quietly between runs, and a result tied to an out-of-date candidate is rejected. A command shaped to hide a failing exit code behind a success is rejected.
- A sandboxed agent pushing through the authenticated git proxy is allowed only when the push targets its own issue's designated artifacts branch, judged from the ref the push command actually targets. A push aimed at any other branch is refused, even when an allowed-looking ref string appears elsewhere in the request.
