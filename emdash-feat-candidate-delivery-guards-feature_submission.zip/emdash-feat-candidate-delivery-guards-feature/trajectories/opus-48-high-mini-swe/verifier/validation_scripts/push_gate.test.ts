// @ts-nocheck
import { describe, it, expect, vi } from "vitest";

import { gateGithubRequest } from "../../../.flue/lib/github-proxy.js";

import { getTestCases } from "./validationParams";

describe("push_gate", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    const OWNER = "emdash-cms";
    const REPO = "emdash";

    const pktLine = (s: string) =>
      `${(s.length + 4).toString(16).padStart(4, "0")}${s}`;

    // Replace <NUL> sentinel with actual NUL byte
    const commandLine = inputs["command_line"].replaceAll("<NUL>", String.fromCharCode(0));
    const body = `${pktLine(commandLine)}0000PACKpayload`;

    const urlStr = `https://github.com/${OWNER}/${REPO}.git/git-receive-pack`;
    const url = new URL(urlStr);
    const request = new Request(urlStr, { method: "POST", body });

    // Pass issueNumber or omit if null
    const issueNumberRaw = inputs["issue_number"];
    let result: string | null;
    if (issueNumberRaw === null || issueNumberRaw === "__null__") {
      result = await gateGithubRequest(request, url, OWNER, REPO);
    } else {
      result = await gateGithubRequest(request, url, OWNER, REPO, Number(issueNumberRaw));
    }

    if (expected["outcome"] === "allowed") {
      expect(result).toBeNull();
    } else {
      // "rejected" => non-empty reason string
      expect(result).toBeTruthy();
      expect(typeof result).toBe("string");
    }

    if (expected["reason_contains"] !== "__skip__") {
      expect((result as string).toLowerCase()).toContain(
        expected["reason_contains"].toLowerCase()
      );
    }
  });
});
