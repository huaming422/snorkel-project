// @ts-nocheck
import { describe, it, expect, vi } from "vitest";

import { publishVerifiedChanges } from "../../../.flue/lib/publish.js";

import { getTestCases } from "./validationParams";

describe("publish_candidate", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    const BRANCH = "bot/artifacts-7";
    const FILE_PATH = "src/app.ts";
    const FILE_CONTENT = "export const app = true;\n";
    const BASE_TREE = "base-tree-sha-fixed";
    const BLOB_SHA = "blob-sha-fixed-0000000000000000000000";

    // Map sentinel null values (JSON delivers real null; TOML sentinels are strings)
    const liveBeforeRaw = inputs["live_before"];
    const expectedPreviousRaw = inputs["expected_previous"];
    const createdCommit = inputs["created_commit"];
    const createdTree = inputs["created_tree"];
    const snapshotTree = inputs["snapshot_tree"];
    const postWriteHeadRaw = inputs["post_write_head"];
    const headMarker = inputs["head_marker"];
    const runId = inputs["run_id"];

    const liveBefore =
      liveBeforeRaw === "__null__" ? null : liveBeforeRaw === undefined ? null : liveBeforeRaw;
    const baseSha =
      expectedPreviousRaw === "__null__"
        ? null
        : expectedPreviousRaw === undefined
        ? null
        : expectedPreviousRaw;

    // Determine post-write head:
    // "__skip__" or equal to created_commit => use created_commit (happy path: ref lands on our commit)
    // otherwise use the given value (interloper scenario: ref did not land on our commit)
    let postWriteHead: string | null;
    if (
      postWriteHeadRaw === "__skip__" ||
      postWriteHeadRaw === createdCommit ||
      postWriteHeadRaw === "__null__" ||
      postWriteHeadRaw === null
    ) {
      postWriteHead = createdCommit === "__skip__" ? null : createdCommit;
    } else {
      postWriteHead = postWriteHeadRaw;
    }

    // Content maps for readTree mock responses.
    // matchingTree: the readTree result that confirms our changes were stored correctly.
    // mismatchingTree: a readTree result that signals content divergence.
    // IMPORTANT: matchingTree must use exactly FILE_PATH and FILE_CONTENT so that
    // sameContent(request.changes, matchingTree) === null (i.e. no mismatch).
    const matchingTree = new Map([[FILE_PATH, FILE_CONTENT]]);
    const mismatchingTree = new Map([[FILE_PATH, "different content -- diverged"]]);

    // Whether the post-write tree content read should show a mismatch.
    // This happens when the server-built tree (createdTree) differs from the
    // verified snapshot tree (snapshotTree): the real implementation confirms
    // by reading the committed tree content back via readTree and comparing to
    // what was requested. When they diverge, we make readTree return mismatching
    // content so the confirmation fails.
    const treesDiverged =
      createdTree !== "__skip__" &&
      snapshotTree !== "__skip__" &&
      createdTree !== null &&
      snapshotTree !== null &&
      createdTree !== snapshotTree;

    // Build the fake GitDataApi with vi.fn() mocks.
    // Method names must match the GitDataApi interface in publish.ts exactly:
    //   getRefSha, getCommit, createBlob, createTree, createCommit, updateRef, readTree
    const getRefSha = vi.fn();
    const getCommit = vi.fn();
    const createBlob = vi.fn();
    const createTree = vi.fn();
    const createCommit = vi.fn();
    const updateRef = vi.fn();
    const readTree = vi.fn();

    // getRefSha sequencing (real code path in publishVerifiedChanges):
    //   Call 1 (line ~161): initial branch-head read -> liveBefore
    //   Call 2 (line ~202): post-write confirmation read -> postWriteHead
    //   (A second getRefSha call only happens when updateRef CAS fails at line ~191,
    //    but since updateRef always returns true in these tests, call 2 is always
    //    the post-write confirmation.)
    getRefSha.mockResolvedValueOnce(liveBefore);    // call 1: initial read
    getRefSha.mockResolvedValueOnce(postWriteHead); // call 2: post-write confirmation

    // getCommit + readTree: called inside isOwnCommit() when liveBefore !== null.
    // The real isOwnCommit logic (publish.ts) checks:
    //   1. commit.parents[0] === request.baseSha  (parent must match our base)
    //   2. sameContent(request.changes, readTree(candidateSha)) === null  (content match)
    // NOTE: head_marker='this_run' in the procedure refers to a commit-message-based
    // detection shape described in the spec; however, the actual publish.ts implementation
    // uses content+parent matching (not message-based). So 'this_run' means we seed
    // a commit whose parent matches baseSha AND whose tree content matches our changes.
    if (headMarker === "this_run") {
      // Idempotent re-run: the branch already points at a commit we produced.
      // isOwnCommit must return true, so:
      //   - parents[0] must === request.baseSha (which is baseSha, possibly null)
      //   - readTree must return content matching our changes
      //
      // When baseSha is null (expected_previous='__null__'), we use [null] explicitly
      // so that commit.parents[0] === null === request.baseSha passes the check.
      const parentForIdempotency: (string | null)[] = [baseSha]; // [null] when baseSha=null
      getCommit.mockResolvedValue({
        sha: liveBefore,
        tree: BASE_TREE,
        parents: parentForIdempotency,
        message: "any prior commit message -- detection uses content+parent, not message",
      });
      // readTree for isOwnCommit: must return content that matches our request changes
      // (FILE_PATH -> FILE_CONTENT) so sameContent returns null (no mismatch).
      readTree.mockResolvedValueOnce(matchingTree);
    } else if (headMarker === "none") {
      // Stale head: the branch points at someone else's commit.
      // isOwnCommit must return false, which it will because parents[0] !== baseSha.
      // readTree is NOT called in isOwnCommit when the parent check fails, so we
      // do not add a readTree.mockResolvedValueOnce here; that would queue a phantom
      // call that never runs and could interfere with the post-write readTree slot.
      getCommit.mockResolvedValue({
        sha: liveBefore,
        tree: BASE_TREE,
        parents: ["some-unrelated-sha-that-does-not-match-base"],
        message: "someone else's commit",
      });
      // No readTree.mockResolvedValueOnce here -- isOwnCommit returns false at the
      // parent check without reading the tree.
    } else {
      // "__skip__": liveBefore is null so isOwnCommit is never called (the guard
      // `currentSha !== null` short-circuits it). getCommit won't be called either.
      getCommit.mockResolvedValue({
        sha: "irrelevant",
        tree: BASE_TREE,
        parents: ["irrelevant-parent"],
        message: "irrelevant",
      });
      // No readTree.mockResolvedValueOnce: no idempotency check runs when liveBefore=null.
    }

    // createBlob: resolves to a fixed blob sha regardless of content
    createBlob.mockResolvedValue({ sha: BLOB_SHA });

    // createTree: resolves to the created_tree sha from inputs
    if (createdTree !== "__skip__" && createdTree !== null) {
      createTree.mockResolvedValue({ sha: createdTree });
    } else {
      createTree.mockResolvedValue({ sha: "tree-placeholder" });
    }

    // createCommit: resolves to the created_commit sha from inputs
    if (createdCommit !== "__skip__" && createdCommit !== null) {
      createCommit.mockResolvedValue({
        sha: createdCommit,
        tree: createdTree !== "__skip__" && createdTree !== null ? createdTree : "tree-placeholder",
        parents: [baseSha],
        message: "publish commit",
      });
    } else {
      createCommit.mockResolvedValue({
        sha: "commit-placeholder",
        tree: "tree-placeholder",
        parents: [baseSha],
        message: "publish commit",
      });
    }

    // updateRef: always returns true (CAS success) in these test cases.
    // A false return would trigger the CAS-loss recovery path (getRefSha call at line ~191),
    // but none of our cases model a CAS loss -- the interloper case models a successful
    // write whose post-write read-back finds the wrong commit.
    updateRef.mockResolvedValue(true);

    // readTree for post-write confirmation (called after CAS succeeds, line ~205):
    // The real code calls readTree(commit.sha) and compares the result to request.changes.
    // When treesDiverged=true the server built a different tree, so we make readTree
    // return mismatching content so the confirmation throws PublishVerificationError.
    // When treesDiverged=false (or not relevant) we return matching content.
    //
    // For treesDiverged=true: use only mockResolvedValue (no preceding mockResolvedValueOnce)
    // so the FIRST readTree call (the post-write confirmation) gets the mismatching content.
    // (For the headMarker='this_run' idempotency case the One-shot above was consumed first,
    //  and for headMarker='__skip__'/'none' no one-shot was queued.)
    if (treesDiverged) {
      readTree.mockResolvedValue(mismatchingTree);
    } else {
      readTree.mockResolvedValue(matchingTree);
    }

    const fakeApi = {
      getRefSha,
      getCommit,
      createBlob,
      createTree,
      createCommit,
      updateRef,
      readTree,
    };

    const request = {
      branch: BRANCH,
      baseSha,
      changes: [{ path: FILE_PATH, content: FILE_CONTENT, mode: "100644" }],
      message: "publish: apply verified changes",
    };

    // Execute the real publishVerifiedChanges function
    let result: any = null;
    let thrownError: any = null;
    let threw = false;

    try {
      result = await publishVerifiedChanges(fakeApi, request);
    } catch (err) {
      threw = true;
      thrownError = err;
    }

    // === EXPECTED: outcome ===
    // "resolves" => publish succeeded (no throw, result is a success object)
    // "throws"   => publish refused (threw, OR returned a failure result)
    if (expected["outcome"] === "resolves") {
      if (threw) {
        throw new Error(
          `Expected publish to resolve but it threw: ${thrownError?.message}`
        );
      }
      expect(result).toBeTruthy();
      // If the result uses a discriminated union { ok: false }, it must not be a failure
      if (result && typeof result === "object" && "ok" in result) {
        expect(result.ok).not.toBe(false);
      }

      // === EXPECTED: result_commit_sha ===
      if (expected["result_commit_sha"] !== "__skip__") {
        expect(result.commitSha).toBe(expected["result_commit_sha"]);
      }
    } else {
      // "throws": publish must refuse
      const refused =
        threw ||
        (result !== null &&
          result !== undefined &&
          typeof result === "object" &&
          ("ok" in result ? result.ok === false : false));

      if (!refused) {
        throw new Error(
          `Expected publish to refuse but it resolved with: ${JSON.stringify(result)}`
        );
      }

      // === EXPECTED: error_contains ===
      if (expected["error_contains"] !== "__skip__") {
        const msg = thrownError?.message ?? result?.reason ?? "";
        expect(msg.toLowerCase()).toContain(
          expected["error_contains"].toLowerCase()
        );
      }
    }

    // === EXPECTED: blob_created ===
    // "yes" => createBlob was called at least once; "no" => never called
    if (expected["blob_created"] !== "__skip__") {
      if (expected["blob_created"] === "yes") {
        expect(createBlob.mock.calls.length).toBeGreaterThanOrEqual(1);
      } else {
        expect(createBlob.mock.calls.length).toBe(0);
      }
    }

    // === EXPECTED: commit_created ===
    // "yes" => createCommit was called at least once; "no" => never called
    if (expected["commit_created"] !== "__skip__") {
      if (expected["commit_created"] === "yes") {
        expect(createCommit.mock.calls.length).toBeGreaterThanOrEqual(1);
      } else {
        expect(createCommit.mock.calls.length).toBe(0);
      }
    }
  });
});
