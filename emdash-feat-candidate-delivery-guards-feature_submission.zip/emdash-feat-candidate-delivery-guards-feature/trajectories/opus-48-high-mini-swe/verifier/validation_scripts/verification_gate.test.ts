// @ts-nocheck
import { describe, it, expect, vi } from "vitest";

import {
  trustedPassingChecks,
  detectExitMasking,
  UntrustworthyResultError,
} from "../../../.flue/lib/verification.js";

import { getTestCases } from "./validationParams";

describe("verification_gate", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    const mode = inputs["mode"];

    if (mode === "select") {
      const rawRecords = inputs["records"]; // array of {name, command, exit_code, tree_sha}
      const currentTree = inputs["current_tree"]; // string or null/__null__

      // input.candidateSha:
      // - When current_tree is present (not null/absent), use it as the candidateSha
      //   (so that records with a different tree_sha are flagged as stale)
      // - When current_tree is absent/null, derive from the first record's tree_sha
      //   (all records should share it; the stale check doesn't apply in this case)
      let candidateSha: string;
      if (
        currentTree !== null &&
        currentTree !== "__null__" &&
        currentTree !== undefined
      ) {
        candidateSha = currentTree;
      } else {
        // Fall back to first record's tree_sha so candidateSha check doesn't reject them
        candidateSha =
          rawRecords.length > 0 ? rawRecords[0].tree_sha : "default-tree";
      }

      // Build contracts: use first occurrence per name as the pinned command
      // (the pinned, trusted command before any later drift)
      const seenNames = new Map();
      for (const rec of rawRecords) {
        if (!seenNames.has(rec.name)) {
          seenNames.set(rec.name, rec.command);
        }
      }
      const contracts = [...seenNames.entries()].map(([name, command]) => ({
        name,
        command,
      }));

      // Build results: map neutral keys to actual CheckResult property names
      // Actual shape: name, command, exitCode, candidateSha, sequence
      const results = rawRecords.map((rec, idx) => ({
        name: rec.name,
        command: rec.command,
        exitCode: rec.exit_code,
        candidateSha: rec.tree_sha,
        sequence: idx + 1, // monotonically increasing by insertion order
      }));

      const verificationInput = {
        candidateSha,
        contracts,
        results,
      };

      if (expected["outcome"] === "returns") {
        let passingChecks: any[];
        try {
          passingChecks = trustedPassingChecks(verificationInput);
        } catch (err) {
          throw new Error(
            `Expected trustedPassingChecks to return but it threw: ${err?.message}`
          );
        }
        expect(Array.isArray(passingChecks)).toBe(true);

        if (expected["passing_count"] !== "__skip__") {
          expect(passingChecks.length).toBe(expected["passing_count"]);
        }
      } else {
        // "throws" - the call must refuse the input
        let refused = false;
        let refusalMessage = "";
        try {
          const result = trustedPassingChecks(verificationInput);
          // If it returned a value indicating refusal (e.g. discriminated union)
          if (result && typeof result === "object" && "ok" in result && !result.ok) {
            refused = true;
            refusalMessage = result.reason ?? "";
          }
          // A null/undefined result with "throws" outcome means acceptance — don't flag
        } catch (err) {
          refused = true;
          refusalMessage = err?.message ?? String(err);
        }

        expect(refused).toBe(true);

        if (expected["error_contains"] !== "__skip__") {
          expect(refusalMessage.toLowerCase()).toContain(
            expected["error_contains"].toLowerCase()
          );
        }
      }
    } else if (mode === "assert_command") {
      const command = inputs["command"];

      if (expected["outcome"] === "returns") {
        // Should not throw and should signal acceptance (detectExitMasking returns null)
        let refusalReason: string | null = null;
        try {
          const result = detectExitMasking(command);
          // detectExitMasking returns null for clean commands, string for masked ones
          if (result !== null && result !== undefined && result !== "") {
            refusalReason = result;
          }
        } catch (err) {
          throw new Error(
            `Expected detectExitMasking to accept "${command}" but it threw: ${err?.message}`
          );
        }
        // Must not have refused
        expect(refusalReason).toBeNull();
      } else {
        // "throws" - the command should be rejected
        let refused = false;
        let refusalMessage = "";
        try {
          const result = detectExitMasking(command);
          // detectExitMasking returns a reason string (non-null) when it detects masking
          if (result !== null && result !== undefined && result !== "") {
            refused = true;
            refusalMessage = result;
          }
        } catch (err) {
          refused = true;
          refusalMessage = err?.message ?? String(err);
        }

        expect(refused).toBe(true);

        if (expected["error_contains"] !== "__skip__") {
          expect(refusalMessage.toLowerCase()).toContain(
            expected["error_contains"].toLowerCase()
          );
        }
      }
    }
  });
});
