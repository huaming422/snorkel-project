// @ts-nocheck
import { describe, it, expect } from "vitest";

import { gateGithubRequest } from "../../../.flue/lib/github-proxy.js";

import { getTestCases } from "./validationParams";

const OWNER = "emdash-cms";
const REPO = "emdash";

function pktLine(payload: string): string {
  return `${(payload.length + 4).toString(16).padStart(4, "0")}${payload}`;
}

describe("push_gate", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    // inputs["command_line"] uses "<NUL>" as a sentinel for the NUL byte.
    // Replace the literal "<NUL>" token with a single NUL byte before framing.
    const commandLineRaw = inputs["command_line"] as string;
    const line = commandLineRaw.replaceAll("<NUL>", String.fromCharCode(0));

    // Build a pkt-line framed body: length-prefixed command line + flush + PACK
    const body = `${pktLine(line)}0000PACKpayload`;

    const url = `https://github.com/${OWNER}/${REPO}.git/git-receive-pack`;
    const urlObj = new URL(url);

    const request = new Request(url, {
      method: "POST",
      body,
    });

    // inputs["issue_number"]: pass as number when not "__null__"; omit entirely when "__null__"
    const issueNumberRaw = inputs["issue_number"];
    const issueNumber =
      issueNumberRaw === "__null__" ? undefined : (issueNumberRaw as number);

    const result = await gateGithubRequest(request, urlObj, OWNER, REPO, issueNumber);

    // Assert EXPECTED: outcome
    // "allowed" => gate resolves to null
    // "rejected" => gate resolves to a non-empty reason string
    if (expected["outcome"] === "allowed") {
      expect(result, `Expected gate to allow (null) but got reason: ${result}`).toBeNull();
    } else {
      // "rejected"
      expect(
        typeof result === "string" && result.length > 0,
        `Expected gate to reject but got: ${JSON.stringify(result)}`
      ).toBe(true);
    }

    // Assert EXPECTED: reason_contains
    if (expected["reason_contains"] !== "__skip__") {
      const needle = expected["reason_contains"].toLowerCase();
      expect((result ?? "").toLowerCase()).toContain(needle);
    }
  });
});
