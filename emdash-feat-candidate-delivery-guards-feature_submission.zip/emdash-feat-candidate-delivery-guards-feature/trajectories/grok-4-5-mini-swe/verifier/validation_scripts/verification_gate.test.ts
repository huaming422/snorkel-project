// @ts-nocheck
import { describe, it, expect } from "vitest";

import {
  assertTrustedCheckCommand,
  recordCheckResult,
  gateOnPassingChecks,
  emptyVerificationLedger,
} from "../../../.flue/lib/verification-checks.js";

import { getTestCases } from "./validationParams";

describe("verification_gate", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    const mode = inputs["mode"];

    if (mode === "assert_command") {
      // Call assertTrustedCheckCommand with inputs["command"]
      const command = inputs["command"];
      let result: any;
      let threw = false;
      let thrownError: any;
      try {
        result = assertTrustedCheckCommand(command);
      } catch (err) {
        threw = true;
        thrownError = err;
      }

      // Determine acceptance/refusal.
      // "returns" means accepted: does not throw and ok is true.
      // "throws" means refused: throws OR returns {ok: false}.
      const accepted = !threw && result?.ok === true;
      const refused = threw || result?.ok === false;

      const errorMessage = threw
        ? (thrownError instanceof Error ? thrownError.message : String(thrownError))
        : (result?.reason ?? "");

      // Assert EXPECTED: outcome
      if (expected["outcome"] === "returns") {
        expect(accepted, `Expected command to be accepted but got: ${errorMessage}`).toBe(true);
      } else {
        // "throws"
        expect(refused, `Expected command to be refused but it was accepted`).toBe(true);
      }

      // Assert EXPECTED: error_contains
      if (expected["error_contains"] !== "__skip__") {
        const needle = expected["error_contains"].toLowerCase();
        expect(errorMessage.toLowerCase()).toContain(needle);
      }

      // Assert EXPECTED: passing_count
      // All assert_command cases have passing_count="__skip__", so this is a no-op
      // for those cases. Do NOT add a vacuous assertion here — simply skip when
      // passing_count is "__skip__".
      if (expected["passing_count"] !== "__skip__") {
        // passing_count is not meaningful in assert_command mode; this branch
        // should not be reached given current test data, but assert 0 if it ever is.
        expect(0).toBe(expected["passing_count"]);
      }

    } else if (mode === "select") {
      // Build records using CheckResult property names.
      // Neutral keys: name, command, exit_code, tree_sha
      // Actual names: name, command, exitCode, candidateFingerprint
      const records = inputs["records"] as Array<{
        name: string;
        command: string;
        exit_code: number;
        tree_sha: string;
      }>;

      const currentTreeRaw = inputs["current_tree"];
      // "__null__" means absent (no current candidate tree sha provided)
      // "__skip__" also treated as absent
      const currentTree =
        currentTreeRaw === "__null__" || currentTreeRaw === "__skip__"
          ? null
          : currentTreeRaw;

      // Build ledger by recording each result in order.
      // Each record's tree_sha is used as the candidateFingerprint both in the
      // record object and as the currentCandidateFingerprint argument to recordCheckResult
      // (records must match the current candidate at time of recording).
      let ledger = emptyVerificationLedger();
      let recordingFailed = false;
      let recordingError = "";

      for (const record of records) {
        const fp = record.tree_sha;
        const checkResult = {
          name: record.name,
          command: record.command,
          exitCode: record.exit_code,
          candidateFingerprint: fp,
        };
        let recordResult: any;
        let threw = false;
        let thrownError: any;
        try {
          recordResult = recordCheckResult(ledger, checkResult, fp);
        } catch (err) {
          threw = true;
          thrownError = err;
          recordingFailed = true;
          recordingError = thrownError instanceof Error ? thrownError.message : String(thrownError);
          break;
        }

        if (!recordResult.ok) {
          recordingFailed = true;
          recordingError = recordResult.reason;
          break;
        }
        ledger = recordResult.ledger;
      }

      // Determine gating fingerprint.
      // If currentTree is provided, use it; otherwise use the tree_sha of the first record.
      const gateFp = currentTree ?? (records.length > 0 ? records[0].tree_sha : "");

      // All unique check names across the records drive the required-names list.
      const requiredNames = [...new Set(records.map((r) => r.name))];

      let gateResult: any;
      let gateFailed = false;
      let gateError = "";

      if (!recordingFailed) {
        if (requiredNames.length > 0) {
          try {
            gateResult = gateOnPassingChecks(ledger, requiredNames, gateFp);
            if (!gateResult.ok) {
              gateFailed = true;
              gateError = gateResult.reason;
            }
          } catch (err) {
            gateFailed = true;
            gateError = err instanceof Error ? err.message : String(err);
          }
        } else {
          // Empty records: gate with a placeholder to trigger the "no checks" rejection.
          try {
            gateResult = gateOnPassingChecks(ledger, ["__placeholder__"], gateFp);
            if (!gateResult.ok) {
              gateFailed = true;
              gateError = gateResult.reason;
            }
          } catch (err) {
            gateFailed = true;
            gateError = err instanceof Error ? err.message : String(err);
          }
        }
      }

      const overallFailed = recordingFailed || gateFailed;
      const overallErrorMessage = recordingFailed ? recordingError : gateError;

      // Assert EXPECTED: outcome
      if (expected["outcome"] === "returns") {
        expect(
          !overallFailed,
          `Expected selection to succeed but got: ${overallErrorMessage}`
        ).toBe(true);
      } else {
        // "throws"
        expect(
          overallFailed,
          `Expected selection to refuse but it succeeded`
        ).toBe(true);
      }

      // Assert EXPECTED: error_contains
      if (expected["error_contains"] !== "__skip__") {
        const needle = expected["error_contains"].toLowerCase();
        expect(overallErrorMessage.toLowerCase()).toContain(needle);
      }

      // Assert EXPECTED: passing_count
      // Assert unconditionally when not "__skip__", regardless of which step failed.
      // When the overall operation succeeded, passing_count is the number of passing
      // records returned by gateOnPassingChecks. When it failed, the count is 0.
      if (expected["passing_count"] !== "__skip__") {
        const passingCount = (!overallFailed && gateResult?.ok) ? gateResult.passed.length : 0;
        expect(passingCount).toBe(expected["passing_count"]);
      }
    }
  });
});
