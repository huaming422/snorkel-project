// @ts-nocheck
import { describe, it, expect, vi } from "vitest";

import { publishCandidate } from "../../../.flue/lib/publish-candidate.js";

import { getTestCases } from "./validationParams";

describe("publish_candidate", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    const TARGET_REF = "refs/heads/bot/artifacts-7";
    const FIXED_BLOB_SHA = "blob-fixed-sha";
    const FIXED_BASE_TREE = "base-tree-fixed-sha";

    // Resolve sentinel "__null__" to null
    const liveBeforeRaw = inputs["live_before"];
    const liveBefore = liveBeforeRaw === "__null__" ? null : liveBeforeRaw;

    const expectedPreviousRaw = inputs["expected_previous"];
    const expectedPrevious = expectedPreviousRaw === "__null__" ? null : expectedPreviousRaw;

    const createdCommit = inputs["created_commit"]; // may be "__skip__"
    const createdTree = inputs["created_tree"]; // may be "__skip__"
    const snapshotTree = inputs["snapshot_tree"]; // may be "__skip__"
    const postWriteHeadRaw = inputs["post_write_head"]; // may be "__skip__"
    const runId = inputs["run_id"];
    const headMarker = inputs["head_marker"];

    // Determine what the post-write getRef call (2nd call under normal publish) returns.
    // Per the procedure:
    //   - when post_write_head is "__skip__" or equals created_commit → return created_commit
    //   - when post_write_head is a different sha (e.g. "interloper-sha") → return that sha
    // For case 4 (post_write_head='interloper-sha', created_commit='commit-eee'):
    //   finalGetRefResult = 'interloper-sha', which triggers the post-write confirm refusal.
    const finalGetRefResult =
      postWriteHeadRaw === "__skip__" || postWriteHeadRaw === createdCommit
        ? createdCommit
        : postWriteHeadRaw;

    // Build the fake GitDataClient with vi.fn() methods.
    //
    // getRef call sequence:
    //   Call 1: current live head (tip check)  → liveBefore
    //   Call 2: post-write confirm OR partial-retry confirm → finalGetRefResult
    //   Call 3+: fallback for any extra calls (e.g. partial-retry where tip===expectedBaseSha)
    //            → also finalGetRefResult so confirms are consistent
    //
    // Using mockResolvedValue for the fallback ensures any additional getRef calls
    // (e.g. in the partial-retry path) resolve consistently rather than returning undefined.
    const getRef = vi.fn();
    getRef.mockResolvedValueOnce(liveBefore);      // call 1: tip check
    getRef.mockResolvedValueOnce(finalGetRefResult); // call 2: post-write / partial-retry confirm
    getRef.mockResolvedValue(finalGetRefResult);   // call 3+: fallback for any further calls

    // getCommit returns { treeSha } used to get the base tree from the parent commit.
    // The implementation only uses treeSha (not message), so we return a fixed base tree.
    const getCommit = vi.fn().mockResolvedValue({
      treeSha: FIXED_BASE_TREE,
    });

    const createBlob = vi.fn().mockResolvedValue(FIXED_BLOB_SHA);
    const createTree = vi.fn().mockResolvedValue(createdTree === "__skip__" ? "tree-unused" : createdTree);
    const createCommit = vi.fn().mockResolvedValue(createdCommit === "__skip__" ? "commit-unused" : createdCommit);
    const updateRef = vi.fn().mockResolvedValue(undefined);

    const client = {
      getRef,
      getCommit,
      createBlob,
      createTree,
      createCommit,
      updateRef,
    };

    // Determine alreadyPublishedSha for idempotent retry.
    // head_marker = "this_run" means the branch tip IS this run's already-published commit.
    // In that case, pass liveBefore as alreadyPublishedSha so the implementation recognises
    // the tip as "already done" and returns it without re-committing.
    const alreadyPublishedSha = headMarker === "this_run" ? liveBefore : undefined;

    // Call publishCandidate with the mapped inputs.
    let result: any;
    let threw = false;
    let thrownError: any;
    try {
      result = await publishCandidate({
        client,
        ref: TARGET_REF,
        files: [
          {
            path: "src/app.ts",
            content: "// app content",
            mode: "100644",
          },
        ],
        message: "chore: publish candidate",
        expectedBaseSha: expectedPrevious,
        alreadyPublishedSha,
      });
    } catch (err) {
      threw = true;
      thrownError = err;
    }

    // Determine success/failure
    const succeeded = !threw && result?.ok === true;
    const failed = threw || result?.ok === false;

    // Get error message for failure cases
    const errorMessage = threw
      ? (thrownError instanceof Error ? thrownError.message : String(thrownError))
      : (result?.reason ?? "");

    // Assert EXPECTED: outcome
    if (expected["outcome"] === "resolves") {
      expect(succeeded, `Expected publish to succeed but got: ${errorMessage}`).toBe(true);
    } else {
      // "throws" - publish should refuse (throw or return ok:false)
      expect(failed, `Expected publish to refuse but it succeeded with: ${JSON.stringify(result)}`).toBe(true);
    }

    // Assert EXPECTED: error_contains
    if (expected["error_contains"] !== "__skip__") {
      const needle = expected["error_contains"].toLowerCase();
      expect(errorMessage.toLowerCase()).toContain(needle);
    }

    // Assert EXPECTED: result_commit_sha
    if (expected["result_commit_sha"] !== "__skip__") {
      expect(result?.commitSha).toBe(expected["result_commit_sha"]);
    }

    // Assert EXPECTED: blob_created
    if (expected["blob_created"] !== "__skip__") {
      if (expected["blob_created"] === "yes") {
        expect(createBlob).toHaveBeenCalled();
      } else {
        expect(createBlob).not.toHaveBeenCalled();
      }
    }

    // Assert EXPECTED: commit_created
    if (expected["commit_created"] !== "__skip__") {
      if (expected["commit_created"] === "yes") {
        expect(createCommit).toHaveBeenCalled();
      } else {
        expect(createCommit).not.toHaveBeenCalled();
      }
    }
  });
});
