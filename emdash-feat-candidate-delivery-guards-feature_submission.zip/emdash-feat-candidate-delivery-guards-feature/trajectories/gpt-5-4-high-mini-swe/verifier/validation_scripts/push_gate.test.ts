// @ts-nocheck
import { describe, it, expect } from "vitest";

import { gateGithubRequest } from "../../../.flue/lib/github-proxy.js";

import { getTestCases } from "./validationParams";

const OWNER = "emdash-cms";
const REPO = "emdash";

function pktLine(payload: string): string {
  return `${(payload.length + 4).toString(16).padStart(4, "0")}${payload}`;
}

describe("push_gate", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    // Build the pkt-line body from inputs["command_line"].
    // The sentinel "<NUL>" is replaced with the actual NUL byte (\0).
    const rawCommandLine = inputs["command_line"].replace(/<NUL>/g, "\0");

    // Build pkt-line body: pkt-line header + command_line + flush (0000) + PACK payload
    const body = `${pktLine(rawCommandLine)}0000PACKpayload`;

    const url = `https://github.com/${OWNER}/${REPO}.git/git-receive-pack`;
    const request = new Request(url, {
      method: "POST",
      body: body,
    });

    // Determine issue_number argument.
    // When inputs["issue_number"] is "__null__", omit the issue-scope argument entirely.
    const issueNumber = inputs["issue_number"];

    let result: string | null;
    if (issueNumber === "__null__" || issueNumber === null) {
      result = await gateGithubRequest(request, new URL(url), OWNER, REPO);
    } else {
      result = await gateGithubRequest(request, new URL(url), OWNER, REPO, issueNumber);
    }

    // EXPECTED: outcome
    if (expected["outcome"] === "allowed") {
      expect(result).toBeNull();
    } else {
      // "rejected"
      expect(result).not.toBeNull();
      expect(typeof result).toBe("string");
      expect(result!.length).toBeGreaterThan(0);
    }

    // EXPECTED: reason_contains
    if (expected["reason_contains"] !== "__skip__") {
      expect(result!.toLowerCase()).toContain(expected["reason_contains"].toLowerCase());
    }
  });
});
