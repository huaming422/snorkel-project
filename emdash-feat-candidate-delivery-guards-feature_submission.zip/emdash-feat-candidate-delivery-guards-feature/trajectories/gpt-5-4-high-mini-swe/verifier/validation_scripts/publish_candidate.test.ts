// @ts-nocheck
import { describe, it, expect, vi } from "vitest";

import { publishVerifiedCandidate } from "../../../.flue/lib/candidate-publisher.js";

import { getTestCases } from "./validationParams";

describe("publish_candidate", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    // The run trailer embedded in commit messages, as per the implementation.
    const RUN_TRAILER = "EmDash-Run";
    const runId = inputs["run_id"];

    // Resolve sentinel strings to real values.
    const liveBefore = inputs["live_before"] === "__null__" ? null : inputs["live_before"];
    const expectedPrevious = inputs["expected_previous"] === "__null__" ? null : inputs["expected_previous"];

    // For skipped sentinels, use placeholder values so the mock resolves something sensible.
    const createdCommit = inputs["created_commit"] === "__skip__" ? "commit-placeholder" : inputs["created_commit"];
    const createdTree = inputs["created_tree"] === "__skip__" ? "tree-placeholder" : inputs["created_tree"];

    // The post-write getBranchHead value.
    // When "__skip__", the branch read-back should see the newly created commit.
    // When a different sha, model a branch whose ref did not land on this run's commit.
    const postWriteHead =
      inputs["post_write_head"] === "__skip__"
        ? createdCommit
        : inputs["post_write_head"];

    // The file we are publishing.
    const FILE_CONTENT = "console.log('hello');";
    const FILE_PATH = "src/app.ts";

    // Build the commit message for the live head, based on head_marker.
    // createPublishCommitMessage produces:
    //   `${commitMessage.trimEnd()}\n\n${RUN_TRAILER}: ${runId}\n...`
    let headCommitMessage: string;
    if (inputs["head_marker"] === "this_run") {
      headCommitMessage = `Publish candidate files\n\n${RUN_TRAILER}: ${runId}\nEmDash-Repo: emdash-cms/emdash\nEmDash-Branch: bot/artifacts-7\nEmDash-Base: null`;
    } else if (inputs["head_marker"] === "none") {
      headCommitMessage = "Some unrelated commit message (no run marker here)";
    } else {
      // "__skip__" — live-head commit is not consulted in that case
      headCommitMessage = "placeholder - not consulted";
    }

    // Whether the created_tree diverges from snapshot_tree.
    // If they differ, the post-write readTree returns mismatching content
    // so the implementation's tree-equality check fails.
    const treesDiffer =
      inputs["created_tree"] !== "__skip__" &&
      inputs["snapshot_tree"] !== "__skip__" &&
      inputs["created_tree"] !== inputs["snapshot_tree"];

    // The matching content for the expected tree (just src/app.ts).
    const matchingTree = new Map([
      [FILE_PATH, { path: FILE_PATH, content: FILE_CONTENT, mode: "100644" }],
    ]);
    const mismatchingTree = new Map([
      [FILE_PATH, { path: FILE_PATH, content: "WRONG CONTENT DOES NOT MATCH", mode: "100644" }],
    ]);

    // -----------------------------------------------------------------------
    // getBranchHead — use vi.fn().mockResolvedValueOnce chains so each
    // test case gets its own independent sequential one-shot resolutions.
    //
    // Call sequence (based on the implementation):
    //   Call 1: the initial head check (before any write) → liveBefore
    //   Call 2: confirmPublishedContent read-back
    //     - For "this_run" (idempotent): confirms the already-published sha → liveBefore
    //     - For normal write path: confirms the newly created commit → postWriteHead
    //     - For stale head: throws before confirmPublishedContent is reached; only 1 call.
    // -----------------------------------------------------------------------
    let getBranchHeadMock: ReturnType<typeof vi.fn>;

    if (inputs["head_marker"] === "this_run") {
      // Idempotent path: two getBranchHead calls, both return liveBefore.
      getBranchHeadMock = vi.fn()
        .mockResolvedValueOnce(liveBefore)     // call 1: current head
        .mockResolvedValueOnce(liveBefore);    // call 2: confirmPublishedContent for already-published sha
    } else if (inputs["head_marker"] === "none") {
      // Stale head path: getBranchHead is called once (then throws — no confirmPublishedContent).
      getBranchHeadMock = vi.fn()
        .mockResolvedValueOnce(liveBefore);    // call 1: current head (stale)
    } else {
      // Normal path ("__skip__"): live_before is null (or any other value), publish proceeds.
      // Call 1: initial head → liveBefore
      // Call 2: confirmPublishedContent → postWriteHead
      getBranchHeadMock = vi.fn()
        .mockResolvedValueOnce(liveBefore)     // call 1: current head
        .mockResolvedValueOnce(postWriteHead); // call 2: post-write read-back
    }

    // getCommit: returns an object with a treeSha and the appropriate message.
    // - For the live head (liveBefore): use headCommitMessage.
    // - For any other sha (e.g. newly created commit during confirmPublishedContent): return createdTree.
    // Note: when parentCommitSha is non-null, resolveBaseTreeSha calls getCommit(parentCommitSha).
    //   In that case (case 1: expectedPrevious="expected-sha"), commitSha !== liveBefore,
    //   so the else branch fires and returns treeSha: createdTree (= "tree-placeholder").
    const getCommitMock = vi.fn().mockImplementation(async (commitSha: string) => {
      if (commitSha === liveBefore) {
        return {
          sha: commitSha,
          message: headCommitMessage,
          treeSha: createdTree, // for "this_run" path, readTree of this sha will be called
          parentCommitShas: [],
        };
      } else {
        // Called for parent commit resolution or for newly created commit in confirmPublishedContent.
        return {
          sha: commitSha,
          message: `Publish candidate files\n\n${RUN_TRAILER}: ${runId}\nEmDash-Repo: emdash-cms/emdash\nEmDash-Branch: bot/artifacts-7\nEmDash-Base: null`,
          treeSha: createdTree,
          parentCommitShas: [],
        };
      }
    });

    // readTree: used in buildExpectedTree (when parentCommitSha is non-null, for the base tree)
    // and in confirmPublishedContent (for the committed tree to compare against expected).
    //
    // - When called with createdTree sha: return matching or mismatching tree based on treesDiffer.
    //   This exercises the post-write content confirmation.
    // - Any other sha (e.g. base tree from parent commit): return empty map (no base files).
    const readTreeMock = vi.fn().mockImplementation(async (treeSha: string) => {
      if (treeSha === createdTree) {
        // For the idempotent case, createdTree = "tree-placeholder" and the existing commit's
        // treeSha is also "tree-placeholder", so this returns matching content — correct.
        return treesDiffer ? mismatchingTree : matchingTree;
      }
      // Any other tree sha (e.g., base tree from parent commit): return empty map.
      return new Map();
    });

    // writeTree: resolves to createdTree.
    // BLOB_CREATED MAPPING: CandidateGitDataStore has no separate createBlob method.
    // writeTree is the single step that materialises file content into the git object store.
    // blob_created='yes' means writeTree was called at least once;
    // blob_created='no' means writeTree was never called.
    const writeTreeMock = vi.fn().mockResolvedValue(createdTree);
    const createCommitMock = vi.fn().mockResolvedValue(createdCommit);
    const updateBranchMock = vi.fn().mockResolvedValue(undefined);

    const fakeGit = {
      getBranchHead: getBranchHeadMock,
      getCommit: getCommitMock,
      readTree: readTreeMock,
      writeTree: writeTreeMock,
      createCommit: createCommitMock,
      updateBranch: updateBranchMock,
    };

    // Build the publish arguments.
    // expectedPrevious maps to parentCommitSha.
    const publishArgs = {
      git: fakeGit,
      owner: "emdash-cms",
      repo: "emdash",
      branch: "bot/artifacts-7",
      runId: runId,
      parentCommitSha: expectedPrevious,
      files: [
        {
          path: FILE_PATH,
          content: FILE_CONTENT,
          mode: "100644",
        },
      ],
      commitMessage: "Publish candidate files",
    };

    // Execute and capture result.
    let result: any = null;
    let threwOrFailed = false;
    let failureMessage = "";

    try {
      result = await publishVerifiedCandidate(publishArgs);
      // Check for a failure discriminant result.
      if (
        result !== null &&
        result !== undefined &&
        (result.ok === false || result.published === false || result.status === "failed")
      ) {
        threwOrFailed = true;
        failureMessage = result.reason ?? result.message ?? "failure result";
      }
    } catch (err: any) {
      threwOrFailed = true;
      failureMessage = err?.message ?? String(err);
    }

    // EXPECTED: outcome
    if (expected["outcome"] === "resolves") {
      expect(threwOrFailed, `Expected success but got failure: ${failureMessage}`).toBe(false);
      expect(result, "Expected a non-null result on success").not.toBeNull();
    } else {
      // "throws"
      expect(threwOrFailed, `Expected refusal but publish succeeded with: ${JSON.stringify(result)}`).toBe(true);
    }

    // EXPECTED: error_contains
    if (expected["error_contains"] !== "__skip__") {
      expect(failureMessage.toLowerCase()).toContain(expected["error_contains"].toLowerCase());
    }

    // EXPECTED: result_commit_sha
    if (expected["result_commit_sha"] !== "__skip__") {
      expect(result?.commitSha).toBe(expected["result_commit_sha"]);
    }

    // EXPECTED: blob_created
    // The CandidateGitDataStore interface has no separate createBlob method.
    // writeTree is the single operation that materialises file content into the git object store.
    // blob_created='yes' → writeTree was called at least once (content was materialised).
    // blob_created='no'  → writeTree was never called (publish refused before writing).
    if (expected["blob_created"] !== "__skip__") {
      if (expected["blob_created"] === "yes") {
        expect(writeTreeMock, "Expected writeTree (blob creation) to have been called").toHaveBeenCalled();
      } else {
        expect(writeTreeMock, "Expected writeTree (blob creation) NOT to have been called").not.toHaveBeenCalled();
      }
    }

    // EXPECTED: commit_created
    if (expected["commit_created"] !== "__skip__") {
      if (expected["commit_created"] === "yes") {
        expect(createCommitMock, "Expected createCommit to have been called").toHaveBeenCalled();
      } else {
        expect(createCommitMock, "Expected createCommit NOT to have been called").not.toHaveBeenCalled();
      }
    }
  });
});
