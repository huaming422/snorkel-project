// @ts-nocheck
import { describe, it, expect } from "vitest";

import {
  collectTrustedPassingChecks,
  recordVerificationResult,
  type VerificationJournal,
  type VerificationResultRecord,
} from "../../../.flue/lib/verification-record.js";

import { getTestCases } from "./validationParams";

describe("verification_gate", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    const mode = inputs["mode"];

    let threwOrFailed = false;
    let failureMessage = "";
    let passingCount: number | null = null;

    if (mode === "select") {
      // Build records from inputs["records"], mapping neutral keys to discovered property names:
      //   name       -> checkName
      //   command    -> command (array: split by whitespace for single-string commands)
      //   exit_code  -> exitCode
      //   tree_sha   -> candidateId
      const rawRecords = inputs["records"];

      // Build a journal by adding records one at a time via recordVerificationResult.
      // This exercises both the command-safety check and the command-change detection.
      let journal: VerificationJournal = { results: [] };
      let seqNum = 1;

      try {
        for (const raw of rawRecords) {
          const commandArr: string[] = typeof raw["command"] === "string"
            ? raw["command"].split(" ").filter((s: string) => s.length > 0)
            : raw["command"];

          const record: VerificationResultRecord = {
            sequence: seqNum++,
            candidateId: raw["tree_sha"],
            checkName: raw["name"],
            command: commandArr,
            exitCode: raw["exit_code"],
            ranAt: new Date(Date.UTC(2026, 10, 1, 0, 0, seqNum)).toISOString(),
          };

          journal = recordVerificationResult(journal, record);
        }

        // Now call collectTrustedPassingChecks with the current_tree as candidateId.
        const currentTree = inputs["current_tree"];
        // When current_tree is absent (__null__), we still need to pass something.
        // If __null__, use the tree_sha from the latest record (if any), or an empty string.
        // Actually the procedure says "when inputs["current_tree"] is not absent, also pass it".
        // __null__ means absent (null sentinel) -> don't pass? But the function requires a string.
        // Looking at the test cases: when current_tree=__null__, records all share the same tree_sha.
        // We pass the tree_sha from the records as the candidateId.

        let candidateId: string;
        if (currentTree === "__null__" || currentTree === null || currentTree === undefined) {
          // Use the tree_sha from the records (they should all be the same for passing cases).
          candidateId = rawRecords.length > 0 ? rawRecords[rawRecords.length - 1]["tree_sha"] : "";
        } else {
          candidateId = currentTree;
        }

        const result = collectTrustedPassingChecks(journal, candidateId);
        passingCount = result.length;
      } catch (err: any) {
        threwOrFailed = true;
        failureMessage = err?.message ?? String(err);
      }
    } else if (mode === "assert_command") {
      // Call the single-command assertion by creating a minimal record with that command.
      // The procedure says "call the single-command assertion function with inputs["command"]".
      // assertCommandDoesNotHideFailure is not directly exported, so we exercise it via
      // recordVerificationResult which calls it internally.
      const commandStr = inputs["command"];
      const commandArr: string[] = typeof commandStr === "string"
        ? commandStr.split(" ").filter((s: string) => s.length > 0)
        : commandStr;

      try {
        const record: VerificationResultRecord = {
          sequence: 1,
          candidateId: "cand-test",
          checkName: "test-check",
          command: commandArr,
          exitCode: 0,
          ranAt: "2026-11-01T00:00:00.000Z",
        };
        recordVerificationResult({ results: [] }, record);
        // If no throw, accepted
      } catch (err: any) {
        threwOrFailed = true;
        failureMessage = err?.message ?? String(err);
      }
    }

    // EXPECTED: outcome
    if (expected["outcome"] === "returns") {
      expect(threwOrFailed, `Expected success but got: ${failureMessage}`).toBe(false);
    } else {
      // "throws"
      expect(threwOrFailed, `Expected refusal but the call succeeded`).toBe(true);
    }

    // EXPECTED: error_contains
    if (expected["error_contains"] !== "__skip__") {
      expect(failureMessage.toLowerCase()).toContain(expected["error_contains"].toLowerCase());
    }

    // EXPECTED: passing_count
    if (expected["passing_count"] !== "__skip__") {
      expect(passingCount).toBe(expected["passing_count"]);
    }
  });
});
