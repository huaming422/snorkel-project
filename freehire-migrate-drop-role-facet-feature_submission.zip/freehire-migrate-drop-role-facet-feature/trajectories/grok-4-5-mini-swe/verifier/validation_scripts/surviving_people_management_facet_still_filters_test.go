package handler

import (
	"sort"
	"strings"
	"testing"
)

// groupContainsAttrPMF reports whether any fragment in the group starts with the
// given attribute name. Defined separately to avoid redeclaration conflicts since
// both test files are in the same package during testing.
func groupContainsAttrPMF(g []string, attr string) bool {
	prefix := attr + " "
	for _, frag := range g {
		if strings.HasPrefix(frag, prefix) || frag == attr {
			return true
		}
	}
	return false
}

// countGroupsWithAttrPMF returns how many groups hold at least one fragment for
// the given attribute.
func countGroupsWithAttrPMF(groups [][]string, attr string) int {
	count := 0
	for _, g := range groups {
		if groupContainsAttrPMF(g, attr) {
			count++
		}
	}
	return count
}

func TestSurvivingPeopleManagementFacetStillFilters(t *testing.T) {
	for _, tc := range GetValidationTestCases(t) {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			query := tc.Inputs["query"].(string)

			// Read expected values.
			wantRoleTypeGroups := int(tc.Expected["role_type_filter_group_count"].(float64))

			var wantIgnored []string
			for _, v := range tc.Expected["ignored_param_names"].([]interface{}) {
				wantIgnored = append(wantIgnored, v.(string))
			}
			sort.Strings(wantIgnored)

			// Drive the real handler via the in-memory harness.
			fake := &fakeFacetCounter{}
			app := facetsApp(fake)

			status, body := doGet(t, app, "/jobs/facets?"+query)
			if status != 200 {
				t.Fatalf("status = %d, want 200", status)
			}

			// Inspect the filter groups the handler built.
			groups, _ := fake.got.Filter.([][]string)

			// EXPECTED: number of groups holding a role_type-attribute fragment == role_type_filter_group_count.
			gotRoleTypeGroups := countGroupsWithAttrPMF(groups, "role_type")
			if gotRoleTypeGroups != wantRoleTypeGroups {
				t.Errorf("role_type_filter_group_count = %d, want %d (groups: %#v)", gotRoleTypeGroups, wantRoleTypeGroups, groups)
			}

			// EXPECTED: sorted ignored param names match expected["ignored_param_names"].
			var gotIgnored []string
			if meta, ok := body["meta"].(map[string]any); ok {
				if ignored, ok := meta["ignored_params"].([]any); ok {
					for _, entry := range ignored {
						if m, ok := entry.(map[string]any); ok {
							if p, ok := m["param"].(string); ok {
								gotIgnored = append(gotIgnored, p)
							}
						}
					}
				}
			}
			sort.Strings(gotIgnored)

			if len(wantIgnored) != len(gotIgnored) {
				t.Errorf("ignored_param_names = %v, want %v", gotIgnored, wantIgnored)
			} else {
				for i := range wantIgnored {
					if gotIgnored[i] != wantIgnored[i] {
						t.Errorf("ignored_param_names[%d] = %q, want %q", i, gotIgnored[i], wantIgnored[i])
					}
				}
			}
		})
	}
}
