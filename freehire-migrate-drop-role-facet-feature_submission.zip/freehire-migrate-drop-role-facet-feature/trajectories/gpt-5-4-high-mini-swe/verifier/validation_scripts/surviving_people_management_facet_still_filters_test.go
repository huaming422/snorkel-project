package handler

import (
	"sort"
	"strings"
	"testing"

	"github.com/strelov1/freehire/internal/search/search"
)

// countGroupsForAttrSurviving counts filter groups containing a fragment for the given attribute.
func countGroupsForAttrSurviving(groups [][]string, attr string) int {
	count := 0
	for _, g := range groups {
		for _, expr := range g {
			if strings.HasPrefix(expr, attr+" ") || strings.HasPrefix(expr, attr+"=") {
				count++
				break
			}
		}
	}
	return count
}

func TestSurvivingPeopleManagementFacetStillFilters(t *testing.T) {
	for _, tc := range GetValidationTestCases(t) {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			query := tc.Inputs["query"].(string)

			// Read expected values
			wantRoleTypeGroupCount := int(tc.Expected["role_type_filter_group_count"].(float64))

			var wantIgnoredNames []string
			for _, v := range tc.Expected["ignored_param_names"].([]interface{}) {
				wantIgnoredNames = append(wantIgnoredNames, v.(string))
			}
			sort.Strings(wantIgnoredNames)

			// Drive the harness
			fake := &fakeFacetCounter{res: search.FacetResult{}}
			app := facetsApp(fake)
			_, body := doGet(t, app, "/jobs/facets?"+query)

			// Inspect the filter the handler built
			groups, _ := fake.got.Filter.([][]string)

			// EXPECTED: role_type filter groups (people-management filter, should still work)
			gotRoleTypeGroupCount := countGroupsForAttrSurviving(groups, "role_type")
			if gotRoleTypeGroupCount != wantRoleTypeGroupCount {
				t.Errorf("role_type filter group count = %d, want %d (groups: %#v)", gotRoleTypeGroupCount, wantRoleTypeGroupCount, groups)
			}

			// EXPECTED: ignored param names from meta.ignored_params (people-management never ignored)
			meta, _ := body["meta"].(map[string]any)
			var gotIgnoredNames []string
			if meta != nil {
				ignoredArr, _ := meta["ignored_params"].([]any)
				for _, entry := range ignoredArr {
					obj, _ := entry.(map[string]any)
					if obj != nil {
						if paramName, ok := obj["param"].(string); ok {
							gotIgnoredNames = append(gotIgnoredNames, paramName)
						}
					}
				}
			}
			sort.Strings(gotIgnoredNames)

			// Compare ignored param names — people-management params should never be ignored
			if len(gotIgnoredNames) != len(wantIgnoredNames) {
				t.Errorf("ignored_param_names = %v, want %v", gotIgnoredNames, wantIgnoredNames)
			} else {
				for i := range wantIgnoredNames {
					if gotIgnoredNames[i] != wantIgnoredNames[i] {
						t.Errorf("ignored_param_names[%d] = %q, want %q; full got=%v want=%v",
							i, gotIgnoredNames[i], wantIgnoredNames[i], gotIgnoredNames, wantIgnoredNames)
					}
				}
			}
		})
	}
}
