package handler

import (
	"sort"
	"strings"
	"testing"

	"github.com/strelov1/freehire/internal/search/search"
)

// countGroupsForAttrRetired counts how many filter groups contain at least one expression
// referencing the given index attribute (e.g. "roles", "regions").
func countGroupsForAttrRetired(groups [][]string, attr string) int {
	count := 0
	for _, g := range groups {
		for _, expr := range g {
			// Expressions look like: attr = "val" or attr != "val" or attr IS EMPTY
			if strings.HasPrefix(expr, attr+" ") || strings.HasPrefix(expr, attr+"=") {
				count++
				break
			}
		}
	}
	return count
}

func TestRetiredRoleParamReportedAsIgnored(t *testing.T) {
	for _, tc := range GetValidationTestCases(t) {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			query := tc.Inputs["query"].(string)

			// Read expected values
			wantRoleGroupCount := int(tc.Expected["role_filter_group_count"].(float64))
			wantRegionGroupCount := int(tc.Expected["live_region_filter_group_count"].(float64))

			var wantIgnoredNames []string
			for _, v := range tc.Expected["ignored_param_names"].([]interface{}) {
				wantIgnoredNames = append(wantIgnoredNames, v.(string))
			}
			sort.Strings(wantIgnoredNames)

			// Drive the harness
			fake := &fakeFacetCounter{res: search.FacetResult{}}
			app := facetsApp(fake)
			_, body := doGet(t, app, "/jobs/facets?"+query)

			// Inspect the filter the handler built
			groups, _ := fake.got.Filter.([][]string)

			// EXPECTED: role filter groups (should be zero — retired filter constrains nothing)
			gotRoleGroupCount := countGroupsForAttrRetired(groups, "roles")
			if gotRoleGroupCount != wantRoleGroupCount {
				t.Errorf("role filter group count = %d, want %d (groups: %#v)", gotRoleGroupCount, wantRoleGroupCount, groups)
			}

			// EXPECTED: regions filter groups (live filter, should still work)
			gotRegionGroupCount := countGroupsForAttrRetired(groups, "regions")
			if gotRegionGroupCount != wantRegionGroupCount {
				t.Errorf("region filter group count = %d, want %d (groups: %#v)", gotRegionGroupCount, wantRegionGroupCount, groups)
			}

			// EXPECTED: ignored param names from meta.ignored_params
			meta, _ := body["meta"].(map[string]any)
			var gotIgnoredNames []string
			if meta != nil {
				ignoredArr, _ := meta["ignored_params"].([]any)
				for _, entry := range ignoredArr {
					obj, _ := entry.(map[string]any)
					if obj != nil {
						if paramName, ok := obj["param"].(string); ok {
							gotIgnoredNames = append(gotIgnoredNames, paramName)
						}
					}
				}
			}
			sort.Strings(gotIgnoredNames)

			// Compare ignored param names
			if len(gotIgnoredNames) != len(wantIgnoredNames) {
				t.Errorf("ignored_param_names = %v, want %v", gotIgnoredNames, wantIgnoredNames)
			} else {
				for i := range wantIgnoredNames {
					if gotIgnoredNames[i] != wantIgnoredNames[i] {
						t.Errorf("ignored_param_names[%d] = %q, want %q; full got=%v want=%v",
							i, gotIgnoredNames[i], wantIgnoredNames[i], gotIgnoredNames, wantIgnoredNames)
					}
				}
			}
		})
	}
}
