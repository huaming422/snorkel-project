package handler

import (
	"sort"
	"strings"
	"testing"
)

func TestRetiredRoleParamReportedAsIgnored(t *testing.T) {
	for _, tc := range GetValidationTestCases(t) {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			query := tc.Inputs["query"].(string)

			// Expected values
			wantRoleGroups := int(tc.Expected["role_filter_group_count"].(float64))
			wantRegionGroups := int(tc.Expected["live_region_filter_group_count"].(float64))

			var wantIgnoredNames []string
			for _, v := range tc.Expected["ignored_param_names"].([]interface{}) {
				wantIgnoredNames = append(wantIgnoredNames, v.(string))
			}
			sort.Strings(wantIgnoredNames)

			// Drive the harness
			fake := &fakeFacetCounter{}
			app := facetsApp(fake)
			status, body := doGet(t, app, "/jobs/facets?"+query)

			if status != 200 {
				t.Fatalf("status = %d, want 200", status)
			}

			// Coerce the built filter into groups
			groups, _ := fake.got.Filter.([][]string)

			// Count filter groups that hold a fragment on the 'roles' attribute.
			// Fragments for the roles attribute look like: roles = "value" or roles != "value".
			roleGroupCount := 0
			for _, g := range groups {
				for _, frag := range g {
					if strings.HasPrefix(frag, "roles") {
						roleGroupCount++
						break
					}
				}
			}

			if roleGroupCount != wantRoleGroups {
				t.Errorf("role_filter_group_count = %d, want %d (filter: %#v)", roleGroupCount, wantRoleGroups, fake.got.Filter)
			}

			// Count filter groups that hold a fragment on the 'regions' attribute.
			regionGroupCount := 0
			for _, g := range groups {
				for _, frag := range g {
					if strings.HasPrefix(frag, "regions") {
						regionGroupCount++
						break
					}
				}
			}

			if regionGroupCount != wantRegionGroups {
				t.Errorf("live_region_filter_group_count = %d, want %d (filter: %#v)", regionGroupCount, wantRegionGroups, fake.got.Filter)
			}

			// Extract ignored param names from meta.ignored_params
			var gotIgnoredNames []string
			meta, _ := body["meta"].(map[string]any)
			if meta != nil {
				ignored, _ := meta["ignored_params"].([]any)
				for _, entry := range ignored {
					obj, _ := entry.(map[string]any)
					if param, ok := obj["param"].(string); ok {
						gotIgnoredNames = append(gotIgnoredNames, param)
					}
				}
			}
			sort.Strings(gotIgnoredNames)

			// Compare sorted slices
			if len(gotIgnoredNames) != len(wantIgnoredNames) {
				t.Errorf("ignored_param_names = %v, want %v", gotIgnoredNames, wantIgnoredNames)
			} else {
				for i := range wantIgnoredNames {
					if gotIgnoredNames[i] != wantIgnoredNames[i] {
						t.Errorf("ignored_param_names[%d] = %q, want %q", i, gotIgnoredNames[i], wantIgnoredNames[i])
					}
				}
			}
		})
	}
}
