## Task

Right now the only way the layer catches a reset-vs-wait execution hazard is if you turn on synchronization validation. The case: a command buffer waits on an event with `vkCmdWaitEvents`, then resets that same event at a pipeline stage that isn't guaranteed to execute after the wait. The reset can race ahead of the wait's execution dependency, a flat spec violation, and every program deserves to hear about it rather than opting in. Synchronization validation also carries memory-access tracking this rule has no use for.

We want this promoted to an always-on core validation check, surfaced as an ordinary VUID. It needs to emit the Vulkan spec VUIDs VUID-vkCmdResetEvent-event-03834, VUID-vkCmdResetEvent-event-03835, VUID-vkCmdResetEvent2-event-03831, and VUID-vkCmdResetEvent2-event-03832, picking the one that matches the reset command form and the command that did the waiting.

The ordering analysis is the real work: whether a reset is safe depends on how the stages a wait makes available carry forward through the rest of the recorded commands, not just the stage named at the reset site. Make that call without reaching into synchronization validation's access-tracking machinery.

## User stories / requirements

- A program that sets an event, waits on it, then resets it at a pipeline stage that isn't guaranteed to run after the stages the wait made available: the layer reports a reset-vs-wait execution-dependency violation with the matching reset-event VUID. The same program with the reset correctly ordered after the wait draws no report.
- When the reset's stage is ordered after the wait only indirectly, through a later barrier's execution dependency or through an all-covering meta pipeline stage rather than a direct stage match, the layer recognizes the ordering as sufficient and stays silent.
- The layer still relates a wait and a reset that are recorded in different command buffers, with the wait in a secondary buffer and the reset in the primary that executes it. An unsafe split across that boundary is reported; a correctly ordered one is not.
- When the program uses the synchronization2 command forms, the violation is reported with the synchronization2 reset-event VUID rather than the original core-1.0 one.
