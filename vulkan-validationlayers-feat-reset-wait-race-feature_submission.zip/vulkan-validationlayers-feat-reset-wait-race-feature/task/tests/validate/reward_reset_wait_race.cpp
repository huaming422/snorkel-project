/*
 * Copyright (c) 2015-2026 The Khronos Group Inc.
 * Copyright (c) 2015-2026 Valve Corporation
 * Copyright (c) 2015-2026 LunarG, Inc.
 * Copyright (c) 2015-2026 Google, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 */

// Reward harness (shipped by the Staff-Bench reward stack, NOT by the solving
// agent). These Layer Validation Test programs record set/wait/reset command
// sequences against the mock ICD and assert, via the ErrorMonitor fixture,
// exactly which reset-vs-wait VUID is (or is not) emitted by core validation.
// The four VUID strings are the spec-defined acceptance contract. The test
// programs are pure test fixtures: they observe behavior only through the
// stable Vulkan command-recording API and the debug-messenger surface, never
// through any layer-internal symbol an implementation is free to name.
//
// Fixtures are deliberately uniquely named (RewardResetWaitRace*) so this
// translation unit never collides with the repo's own event.cpp /
// event_positive.cpp fixtures or test names. The sync2 reset path is driven
// with vk::CmdResetEvent2 directly because the CommandBuffer::ResetEvent2
// convenience wrapper does not exist at the task's base commit.

#include "../framework/layer_validation_tests.h"

class RewardResetWaitRaceNegative : public SyncObjectTest {};
class RewardResetWaitRacePositive : public SyncObjectTest {};

// ---------------------------------------------------------------------------
// Story: reset_after_wait_unsafe_flagged
// ---------------------------------------------------------------------------

// Unsafe: wait makes COMPUTE available, reset at TRANSFER is not guaranteed to
// run after it -> core validation must flag the race (core-1.0 form, last wait
// was vkCmdWaitEvents).
TEST_F(RewardResetWaitRaceNegative, UnsafeResetFlagged) {
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    monitor_.SetDesiredError("VUID-vkCmdResetEvent-event-03834");
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_TRANSFER_BIT);
    monitor_.VerifyFound();
    m_command_buffer.End();
}

// Core-1.0 reset (vkCmdResetEvent) after a synchronization2 wait
// (vkCmdWaitEvents2): the core form must still be selected, but because the last
// wait was the sync2 form the VUID is -03835, not -03834. Guards the
// (reset-v1 x wait2) branch of the one-of-four selection.
TEST_F(RewardResetWaitRaceNegative, CoreResetAfterWait2SelectsVuid03835) {
    SetTargetApiVersion(VK_API_VERSION_1_3);
    AddRequiredFeature(vkt::Feature::synchronization2);
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    VkMemoryBarrier2 barrier = vku::InitStructHelper();
    barrier.srcStageMask = VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT;
    barrier.dstStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;

    m_command_buffer.Begin();
    m_command_buffer.SetEvent2(event, barrier);
    m_command_buffer.WaitEvent2(event, barrier);
    monitor_.SetDesiredError("VUID-vkCmdResetEvent-event-03835");
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_TRANSFER_BIT);
    monitor_.VerifyFound();
    m_command_buffer.End();
}

// Safe counterpart: reset at exactly the stage the wait made available ->
// nothing must be emitted (guards against an over-eager "always flag" impl).
TEST_F(RewardResetWaitRacePositive, SafeResetSilent) {
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    m_command_buffer.End();
}

// ---------------------------------------------------------------------------
// Story: reset_after_wait_chained_safe
// ---------------------------------------------------------------------------

// Safe via forward chaining: the reset stage (COLOR_ATTACHMENT_OUTPUT) is
// reachable from the wait's COMPUTE dst only through a chain of later barriers
// (COMPUTE->TRANSFER, then TRANSFER->COLOR). A correct closure recognizes this
// and stays silent; a literal-bitmask impl false-positives here.
TEST_F(RewardResetWaitRacePositive, ChainedBarrierSafe) {
    SetTargetApiVersion(VK_API_VERSION_1_3);
    AddRequiredFeature(vkt::Feature::synchronization2);
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    VkMemoryBarrier2 wait_barrier = vku::InitStructHelper();
    wait_barrier.srcStageMask = VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT;
    wait_barrier.dstStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;

    VkMemoryBarrier2 transfer_barrier = vku::InitStructHelper();
    transfer_barrier.srcStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;
    transfer_barrier.dstStageMask = VK_PIPELINE_STAGE_2_TRANSFER_BIT;

    VkMemoryBarrier2 color_barrier = vku::InitStructHelper();
    color_barrier.srcStageMask = VK_PIPELINE_STAGE_2_TRANSFER_BIT;
    color_barrier.dstStageMask = VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT;

    m_command_buffer.Begin();
    m_command_buffer.SetEvent2(event, wait_barrier);
    m_command_buffer.WaitEvent2(event, wait_barrier);
    m_command_buffer.Barrier(transfer_barrier);
    m_command_buffer.Barrier(color_barrier);
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT);
    m_command_buffer.End();
}

// Independent barriers in one dependency do NOT chain: barrier[0] carries
// COMPUTE->TRANSFER and barrier[1] carries VERTEX->COLOR; they are applied
// independently, so the reset at COLOR is still unsafe and must be flagged.
TEST_F(RewardResetWaitRaceNegative, IndependentBarriersDoNotChain) {
    SetTargetApiVersion(VK_API_VERSION_1_3);
    AddRequiredFeature(vkt::Feature::synchronization2);
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    VkMemoryBarrier2 barrier = vku::InitStructHelper();
    barrier.srcStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;
    barrier.dstStageMask = VK_PIPELINE_STAGE_2_TRANSFER_BIT;

    VkMemoryBarrier2 barrier2 = vku::InitStructHelper();
    barrier2.srcStageMask = VK_PIPELINE_STAGE_2_VERTEX_SHADER_BIT;
    barrier2.dstStageMask = VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT;

    const VkMemoryBarrier2 barriers[2] = {barrier, barrier2};

    VkDependencyInfo dep_info = vku::InitStructHelper();
    dep_info.memoryBarrierCount = 2;
    dep_info.pMemoryBarriers = barriers;

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    m_command_buffer.Barrier(dep_info);
    monitor_.SetDesiredError("VUID-vkCmdResetEvent-event-03834");
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT);
    monitor_.VerifyFound();
    m_command_buffer.End();
}

// ---------------------------------------------------------------------------
// Story: reset_after_wait_secondary
// ---------------------------------------------------------------------------

// The wait lives in a secondary command buffer; the primary sets the event,
// executes the secondary, then resets at a racing stage. The relationship must
// survive the vkCmdExecuteCommands boundary and be flagged.
TEST_F(RewardResetWaitRaceNegative, SecondaryWaitRaceFlagged) {
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    vkt::CommandBuffer secondary(*m_device, m_command_pool, VK_COMMAND_BUFFER_LEVEL_SECONDARY);
    secondary.Begin();
    secondary.WaitEvent(event, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    secondary.End();

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    m_command_buffer.ExecuteCommands(secondary);
    monitor_.SetDesiredError("VUID-vkCmdResetEvent-event-03834");
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_TRANSFER_BIT);
    monitor_.VerifyFound();
    m_command_buffer.End();
}

// Safe across the boundary: a secondary supplies the chaining barrier that
// makes the reset stage reachable, so nothing is emitted.
TEST_F(RewardResetWaitRacePositive, SecondaryBarrierSafe) {
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    vkt::CommandBuffer secondary(*m_device, m_command_pool, VK_COMMAND_BUFFER_LEVEL_SECONDARY);
    secondary.Begin();
    vk::CmdPipelineBarrier(secondary, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, 0, 0, nullptr, 0,
                           nullptr, 0, nullptr);
    secondary.End();

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    m_command_buffer.ExecuteCommands(secondary);
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_TRANSFER_BIT);
    m_command_buffer.End();
}

// ---------------------------------------------------------------------------
// Story: reset_after_wait2_selects_sync2_vuid
// ---------------------------------------------------------------------------

// sync2 reset (vkCmdResetEvent2) after a core-1.0 wait (vkCmdWaitEvents):
// must select the sync2 VUID -03831, not the core-1.0 -03834/-03835.
TEST_F(RewardResetWaitRaceNegative, Sync2ResetSelectsVuid03831) {
    SetTargetApiVersion(VK_API_VERSION_1_3);
    AddRequiredFeature(vkt::Feature::synchronization2);
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    monitor_.SetDesiredError("VUID-vkCmdResetEvent2-event-03831");
    vk::CmdResetEvent2(m_command_buffer, event, VK_PIPELINE_STAGE_2_TRANSFER_BIT);
    monitor_.VerifyFound();
    m_command_buffer.End();
}

// sync2 reset (vkCmdResetEvent2) after a sync2 wait (vkCmdWaitEvents2):
// must select the sync2 VUID -03832.
TEST_F(RewardResetWaitRaceNegative, Sync2ResetSelectsVuid03832) {
    SetTargetApiVersion(VK_API_VERSION_1_3);
    AddRequiredFeature(vkt::Feature::synchronization2);
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    VkMemoryBarrier2 barrier = vku::InitStructHelper();
    barrier.srcStageMask = VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT;
    barrier.dstStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;

    m_command_buffer.Begin();
    m_command_buffer.SetEvent2(event, barrier);
    m_command_buffer.WaitEvent2(event, barrier);
    monitor_.SetDesiredError("VUID-vkCmdResetEvent2-event-03832");
    vk::CmdResetEvent2(m_command_buffer, event, VK_PIPELINE_STAGE_2_TRANSFER_BIT);
    monitor_.VerifyFound();
    m_command_buffer.End();
}
