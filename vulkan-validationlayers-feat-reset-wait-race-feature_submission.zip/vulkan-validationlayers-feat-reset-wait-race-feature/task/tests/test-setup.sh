#!/usr/bin/env bash
# test-setup.sh — sourced before the verifier runs (verifier phase, network up).
#
# Performs the incremental rebuild after the agent's edits. The image
# pre-configured and pre-built the Release tree at /repo/Vulkan-ValidationLayers/build
# (BUILD_TESTS=ON, UPDATE_DEPS=ON), so this incremental rebuild relinks only the
# translation units the agent touched plus the validation layer and the
# vk_layer_validation_tests binary, and completes well within the verifier budget
# even for a handful of edited layers/*.cpp files.
set -euo pipefail

cd /repo/Vulkan-ValidationLayers

# Incremental rebuild of the validation layer and the Layer Validation Tests.
# CMake recomputes the dependency graph against the warm build tree and rebuilds
# only what changed, then relinks. No network is required: all third-party
# dependencies (loader/profiles sources, tracy, gtest, etc.) were fetched and
# built into ./external and ./build at image-build time.
echo "test-setup: incremental rebuild of validation layer + tests..."
cmake --build build > /tmp/test-setup-build.log 2>&1 || {
    echo "test-setup: build failed; tail of /tmp/test-setup-build.log:" >&2
    tail -120 /tmp/test-setup-build.log >&2
    exit 1
}

# Sanity check: the validation layer and the test binary must exist after the
# rebuild. (Target name LAYER_NAME="VkLayer_khronos_validation"; the test
# executable is vk_layer_validation_tests.)
if [ -z "$(find build/layers -maxdepth 1 -name 'libVkLayer_khronos_validation.so' 2>/dev/null)" ]; then
    echo "test-setup: built validation layer missing from build/layers" >&2
    exit 1
fi
if [ ! -x build/tests/vk_layer_validation_tests ]; then
    echo "test-setup: vk_layer_validation_tests missing or non-executable" >&2
    exit 1
fi

echo "test-setup: ready."
