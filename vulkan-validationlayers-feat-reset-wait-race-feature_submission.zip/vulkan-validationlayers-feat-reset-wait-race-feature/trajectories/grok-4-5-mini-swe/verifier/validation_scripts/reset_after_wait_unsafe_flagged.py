import subprocess
import re


def test_reset_after_wait_unsafe_flagged(inputs, expected):
    """Drive the Layer Validation Test binary and assert on gtest summary."""
    proc = subprocess.run(
        ["build/tests/vk_layer_validation_tests",
         "--gtest_filter=" + inputs["gtest_filter"]],
        capture_output=True, text=True, timeout=300,
    )
    out = proc.stdout + proc.stderr
    m_pass = re.search(r"\[  PASSED  \] (\d+) test", out)
    m_fail = re.search(r"\[  FAILED  \] (\d+) test", out)
    gtest_passed = int(m_pass.group(1)) if m_pass else 0
    gtest_failed = int(m_fail.group(1)) if m_fail else 0
    returncode = proc.returncode

    assert gtest_passed == expected["gtest_passed"], (
        f"gtest_passed: expected {expected['gtest_passed']}, got {gtest_passed}\n"
        f"filter={inputs['gtest_filter']}\noutput={out}"
    )
    assert gtest_failed == expected["gtest_failed"], (
        f"gtest_failed: expected {expected['gtest_failed']}, got {gtest_failed}\n"
        f"filter={inputs['gtest_filter']}\noutput={out}"
    )
    assert returncode == expected["returncode"], (
        f"returncode: expected {expected['returncode']}, got {returncode}\n"
        f"filter={inputs['gtest_filter']}\noutput={out}"
    )
