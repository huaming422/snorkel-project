#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (inherits set -euo pipefail).
# Must run with the network cut. The image already holds the full Rust
# dependency closure for the repository as checked in (registry plus a warm
# target/ for the mise binary and the workspace test binaries), so nothing
# here reaches a registry.
cd /repo/mise

# Rust stays offline: resolve only from the warm cargo cache the image built.
export CARGO_NET_OFFLINE=true

# Offline-first build of the mise binary the e2e scenarios drive, with a logged
# online fallback that should never be needed, since the image holds the closure.
# A rebuild after an edit starts from the warm target/ cache.
# CARGO_TARGET_DIR=/opt/cache/cargo-target (set in the image ENV), so the binary
# lands at /opt/cache/cargo-target/debug/mise. When the tree doesn't build, this
# removes the old binary and logs the error, so every scenario fails on the
# missing binary instead of testing a stale one. This file is sourced, so it
# never exits.
if cargo build --locked --offline > /tmp/test-setup-build.log 2>&1; then
    echo "[offline-first] mise binary built from warm cargo cache"
elif cargo build --locked >> /tmp/test-setup-build.log 2>&1; then
    echo "[test-setup] mise binary built online (image bake was stale)"
else
    rm -f /opt/cache/cargo-target/debug/mise
    echo "[test-setup] mise did not build; the scenarios will fail" >&2
    grep -m5 -A8 '^error' /tmp/test-setup-build.log >&2 || tail -60 /tmp/test-setup-build.log >&2
fi

# The e2e harness (e2e/run_test) expects the binary at target/debug relative to
# the repo root; CARGO_TARGET_DIR relocates it. Make the conventional path point
# at the real build output so the scenarios that invoke e2e/run_test find it.
if [ ! -e target/debug/mise ]; then
    mkdir -p target
    ln -sfn /opt/cache/cargo-target/debug target/debug
fi

# The `tiny` tool backend is an offline fixture that ships in the clone at
# test/data/plugins/tiny (the rtx-tiny mock, versions 1.0.0 to 3.1.0). The
# stock e2e/run_test links only `dummy` and `needs-dummy` into the isolated
# MISE_DATA_DIR/plugins, and several prune scenarios also use `tiny`, so
# tests/verify/_harness.sh links `tiny` into each isolated
# $MISE_DATA_DIR/plugins the same way. Nothing to install here, since the
# fixture is already on disk and is resolved by symlink, not from the registry
# (which would need GitHub).
for fixture in tiny dummy; do
    test -x "test/data/plugins/$fixture/bin/list-all" \
        || echo "[test-setup] missing offline $fixture fixture" >&2
done

echo "[test-setup] ready: offline mise binary + dummy/tiny fixtures present"
