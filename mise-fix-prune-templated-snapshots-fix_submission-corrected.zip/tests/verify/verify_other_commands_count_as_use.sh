# Running a project through exec, x, run, env or the shell hook counts as using
# it, the same as install and ls. Each round puts the project on 2.0.0 with
# install, then runs one command with PRUNE_VERSION=1.0.0: 1.0.0 is what it uses
# now, so 2.0.0 is the version reported.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project elsewhere
cat >project/mise.toml <<'EOT'
[tools]
dummy = "{{env.PRUNE_VERSION}}"

[tasks.noop]
run = "true"
EOT
assert "PRUNE_VERSION=1.0.0 mise -C project install"

for use in "exec -- true" "x -- true" "run noop" "env" "hook-env -s bash"; do
  assert "PRUNE_VERSION=2.0.0 mise -C project install"
  assert "mise -C elsewhere ls --prunable --json >prunable.json"
  expect_prunable dummy '["1.0.0"]'

  assert "PRUNE_VERSION=1.0.0 mise -C project $use >/dev/null"
  assert "mise -C elsewhere ls --prunable --json >prunable.json"
  expect_prunable dummy '["2.0.0"]'
done
SCENARIO
