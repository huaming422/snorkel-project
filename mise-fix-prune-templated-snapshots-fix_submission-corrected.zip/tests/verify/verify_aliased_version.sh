# The project maps its own alias to a version, and its computed tool asks for
# the alias. From another directory the alias isn't in scope, yet the version
# the project installed stays and only the unrelated one is reported.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project elsewhere
cat >project/mise.toml <<'EOT'
[tool_alias.dummy.versions]
project-release = "1.0.0"

[tools]
dummy = "{{env.PRUNE_VERSION}}"
EOT
assert "PRUNE_VERSION=project-release mise -C project install"
assert "mise install dummy@3.0.0"
assert "ls $MISE_DATA_DIR/installs/dummy/1.0.0"

# From a third directory only the unrelated 3.0.0 is reported.
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '["3.0.0"]'
SCENARIO
