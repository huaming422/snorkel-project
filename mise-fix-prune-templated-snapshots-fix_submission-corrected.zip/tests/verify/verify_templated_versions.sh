# A project whose tool version comes from a parent's vars, under the identity
# install layout. Prune from an unrelated directory keeps the version the
# project uses and reports an unused one. After the parent changes, prune can't
# know what the project needs, so it keeps every dummy until the project is used
# again, and that use makes the version it dropped prunable.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project/child elsewhere
echo '[vars]
tool_version = "1.0.0"' >project/mise.toml
echo '[tools]
dummy = "{{vars.tool_version}}"' >project/child/mise.toml
assert "mise -C project/child install"
assert "mise install dummy@3.0.0"

for directory in project/child elsewhere; do
  assert "mise -C '$directory' ls --prunable --json >prunable.json"
  expect_prunable dummy '["3.0.0"]'
  assert_contains "mise -C '$directory' prune --dry-run 2>&1" "dummy@3.0.0"
  assert_not_contains "mise -C '$directory' prune --dry-run 2>&1" "dummy@1.0.0"
done

# The parent changed after the last use, so every dummy is kept.
echo '[vars]
tool_version = "2.0.0"' >project/mise.toml
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '[]'

# Using the project again makes the version it no longer uses prunable.
assert "mise -C project/child install"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '["1.0.0","3.0.0"]'
SCENARIO
