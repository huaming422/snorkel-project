# The project is used from its root and from a child directory whose config
# changes a var, so each ends up with its own version. After the child's config
# changes, prune can't know what the child needs now, so every dummy is kept
# until the child is used again, even though the root's use is still current.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project/child elsewhere
echo '[vars]
v = "1.0.0"
[tools]
dummy = "{{vars.v}}"' >project/mise.toml
echo '[vars]
v = "2.0.0"' >project/child/mise.toml
assert "mise -C project install"
assert "mise -C project/child install"
assert "mise install dummy@3.0.0"

# Both uses are current; only the unrelated 3.0.0 is reported.
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '["3.0.0"]'

# Change the child's config: every dummy is kept.
echo '# touched' >>project/child/mise.toml
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '[]'

# Using the child again: the unrelated 3.0.0 is reported again.
assert "mise -C project/child install"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '["3.0.0"]'
SCENARIO
