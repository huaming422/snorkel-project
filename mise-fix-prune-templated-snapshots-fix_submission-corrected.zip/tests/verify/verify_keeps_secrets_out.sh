# A credential in a tool's install_env, or in its backend options under any name
# or nesting, isn't written to disk anywhere new, and prune never reports the
# version the project uses. The unrelated version may be reported or kept.
#
# The search covers every file under the test home except the places that held
# these values before any change. Those are the projects' mise.toml files, the
# installed tools themselves, and the install catalog's identities, selections,
# names, ambiguous and locks records, which store option values. The dummy
# backend copies its whole environment, install_env included, into each
# installation.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project other elsewhere
echo '[tools]
dummy = { version = "{{env.PRUNE_VERSION}}", install_env = { API_TOKEN = "{{env.SECRET}}" } }' >project/mise.toml
assert "PRUNE_VERSION=1.0.0 SECRET=hunter2-s3cret mise -C project install"
cat >other/mise.toml <<'EOT'
[tools]
tiny = { version = "{{env.PRUNE_VERSION}}", headers = { Authorization = "Bearer s3cret-header-value" }, api_key = "k3y-value" }
EOT
assert "PRUNE_VERSION=2.0.0 mise -C other install"
assert "mise install dummy@3.0.0 tiny@3.0.0"

secret_grep() {
  {
    find "$HOME" -type f \
      -not -path "$HOME/workdir/*/mise.toml" \
      -not -path "$MISE_DATA_DIR/installs/*" -print0 2>/dev/null
    find "$MISE_DATA_DIR/installs/.mise" -type f \
      -not -path '*/identities/*' -not -path '*/selections/*' \
      -not -path '*/names/*' -not -path '*/ambiguous/*' \
      -not -path '*/locks/*' -print0 2>/dev/null
  } | xargs -0r grep -alF "$1" 2>/dev/null || true
}
export -f secret_grep
for leak in hunter2-s3cret API_TOKEN s3cret-header-value k3y-value; do
  assert_empty "secret_grep '$leak'"
done

# The versions the projects use are never reported; the unrelated ones may be.
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable_within dummy '["3.0.0"]'
expect_prunable_within tiny '["3.0.0"]'
SCENARIO
