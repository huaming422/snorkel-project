# A credential in a tool's install_env, or in its backend options under any name
# or nesting, isn't written to disk anywhere new, and prune never reports the
# version the project uses. The unrelated version may be reported or kept.
#
# The search covers every file under the test home except the exact files that
# hold these values before any change. Those are the projects' mise.toml files
# and the env file the dummy backend writes into each installation, a copy of its
# whole environment. For backend options they also include each installation's
# receipt and its identity and selection records in the catalog.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project other plainname plainenv elsewhere
echo '[tools]
dummy = { version = "{{env.PRUNE_VERSION}}", install_env = { API_TOKEN = "{{env.SECRET}}" } }' >project/mise.toml
assert "PRUNE_VERSION=1.0.0 SECRET=hunter2-s3cret mise -C project install"
cat >other/mise.toml <<'EOT'
[tools]
tiny = { version = "{{env.PRUNE_VERSION}}", headers = { Authorization = "Bearer s3cret-header-value" }, api_key = "k3y-value" }
EOT
assert "PRUNE_VERSION=2.0.0 mise -C other install"

# The same kinds of value under names that don't look secret, each on a tool
# with nothing else that would keep it out of a record.
echo '[tools]
tiny = { version = "{{env.PRUNE_VERSION}}", note = "{{env.SECRET}}" }' >plainname/mise.toml
assert "PRUNE_VERSION=1.0.0 SECRET=t3mplated-option-value mise -C plainname install"
echo '[tools]
dummy = { version = "{{env.PRUNE_VERSION}}", install_env = { PLAIN_VALUE = "pl4in-env-value" } }' >plainenv/mise.toml
assert "PRUNE_VERSION=2.0.0 mise -C plainenv install"
assert "mise install dummy@3.0.0 tiny@3.0.0"

# Lists the files under the test home that hold $1, leaving out the projects'
# mise.toml files and any path that matches the extended regex $2.
secret_grep() {
  find "$HOME" -type f -not -path "$HOME/workdir/*/mise.toml" -print0 2>/dev/null |
    xargs -0r grep -alF "$1" 2>/dev/null | grep -Ev "$2" || true
}
export -f secret_grep

for leak in hunter2-s3cret API_TOKEN pl4in-env-value PLAIN_VALUE; do
  assert_empty "secret_grep '$leak' '/installs/[^/]+/env$'"
done

# An installation's receipt, identity record and selection are named after its
# hash, the last part of its directory name.
hashes="$(ls "$MISE_DATA_DIR/installs" | sed -nE 's/^[a-z]+-([a-z2-7]{8})$/\1/p' | paste -sd '|')"
known="/installs/[^/]+/\.mise-install\.toml$|/installs/\.mise/(selections|identities/[^/]+)/($hashes)[a-z2-7]*\.toml$"
for leak in s3cret-header-value k3y-value t3mplated-option-value; do
  assert_empty "secret_grep '$leak' '$known'"
done

# The versions the projects use are never reported; the unrelated ones may be.
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable_within dummy '["3.0.0"]'
expect_prunable_within tiny '["3.0.0"]'
SCENARIO
