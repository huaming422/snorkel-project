# A config that appends to its own file each time mise reads it has changed
# since the last use by the time prune runs, so prune keeps every installation
# of its computed tool. A config that doesn't change itself is handled normally.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project elsewhere
cat >project/mise.toml <<'EOT'
[vars]
v = "1.0.0"
touch = "{{ exec(command='echo \"# edited\" >> ' ~ config_root ~ '/mise.toml') }}"

[tools]
dummy = "{{vars.v}}"
EOT
assert "mise -C project install"
assert "mise install dummy@3.0.0"

# The config changed after mise read it, so every dummy is kept.
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '[]'

# A config that doesn't change itself, with its own tool (tiny) so the check
# doesn't depend on the dummy case: its in-use version is kept and the
# unrelated one is reported.
mkdir -p stable
cat >stable/mise.toml <<'EOT'
[vars]
v = "2.0.0"

[tools]
tiny = "{{vars.v}}"
EOT
assert "mise -C stable install"
assert "mise install tiny@3.0.0"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable tiny '["3.0.0"]'
SCENARIO
