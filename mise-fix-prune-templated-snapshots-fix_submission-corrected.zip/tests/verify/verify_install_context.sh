# What a project's computed version renders to can depend on inputs a prune run
# from another directory can't see: a variable set on the command line,
# --no-env, or an env file named in settings. Prune keeps the versions the
# projects actually ended up with.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p noenv/child envfile/child elsewhere
echo '[env]
PRUNE_VERSION = "1.0.0"' >noenv/mise.toml
echo '[tools]
dummy = "{{env.PRUNE_VERSION}}"' >noenv/child/mise.toml
echo '[settings]
env_file = ".env"
[env]
PRUNE_VERSION = "1.0.0"' >envfile/mise.toml
echo 'PRUNE_VERSION=2.0.0' >envfile/.env
echo '[tools]
dummy = "{{env.PRUNE_VERSION}}"' >envfile/child/mise.toml

assert "mise install dummy@3.0.0"
# --no-env means the parent [env] is ignored, so the command-line value wins (5.0.0).
assert "PRUNE_VERSION=5.0.0 mise --no-env -C noenv/child install"
# The env file overrides the inline [env], so this renders to 2.0.0.
assert "mise -C envfile/child install"
assert "mise install dummy@4.0.0"

# From a third directory neither input is visible, yet both versions the
# projects use are kept and only the unused ones are reported.
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '["3.0.0","4.0.0"]'

# The prune run's own shell doesn't count either, even when it names another
# installed version.
assert "PRUNE_VERSION=4.0.0 mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '["3.0.0","4.0.0"]'
SCENARIO
