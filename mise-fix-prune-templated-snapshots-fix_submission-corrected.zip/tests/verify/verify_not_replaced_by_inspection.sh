# Only using a project changes what prune keeps for it. Looking at it with prune
# or ls --prunable, or running exec with an explicit version of its computed
# tool, happens with whatever value the shell has and changes nothing. That
# includes a real prune from inside the project.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project elsewhere
echo '[tools]
dummy = "{{env.PRUNE_VERSION}}"' >project/mise.toml
assert "PRUNE_VERSION=1.0.0 mise -C project install"
assert "mise install dummy@3.0.0"

# Looking from inside the project with a different value in the shell: only
# 3.0.0 is reported.
assert "PRUNE_VERSION=2.0.0 mise -C project ls --prunable --json >prunable.json"
expect_prunable dummy '["3.0.0"]'
assert "PRUNE_VERSION=2.0.0 mise -C project prune --dry-run"

# An exec that names its own version of the computed tool isn't a use of the
# project's version.
assert "PRUNE_VERSION=2.0.0 mise -C project exec dummy@3.0.0 -- true"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '["3.0.0"]'

# A real prune from inside the project (which also rebuilds shims afterwards)
# keeps the in-use 1.0.0 on disk, and nothing dummy is reported afterwards.
assert "PRUNE_VERSION=2.0.0 mise -C project prune --yes"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '[]'
assert "ls $MISE_DATA_DIR/installs/dummy/1.0.0 >/dev/null"
SCENARIO
