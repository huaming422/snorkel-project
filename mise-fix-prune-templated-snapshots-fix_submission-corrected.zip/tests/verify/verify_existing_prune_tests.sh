# The repository's own prune e2e tests, taken from the commit the work started
# from, keep passing: prune and ls --prunable still behave the way they describe
# on the default layout and on the identity layout. The list holds the prune
# tests that run without network access; the others fetch plugins from GitHub.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_repo_tests \
  test_prune_dry_run_explains \
  test_prune_miserc_ignored_config_paths \
  test_prune_running_process \
  test_prune_shared_installs \
  test_prune_tracked_config_dev_null \
  test_prune_tracked_config_trust
