# The deferred cleanup that runs at the start of nearly every command isn't a
# use of the project it happens to run in. A command that loads the project's
# tools itself is, even when that cleanup ran first in the same command.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project other elsewhere
echo '[tools]
dummy = "{{env.PRUNE_VERSION}}"' >project/mise.toml
assert "PRUNE_VERSION=1.0.0 mise -C project install"
assert "mise install dummy@3.0.0"

# Arrange a deferred removal that's due, so the next command triggers cleanup.
echo '[tools]
tiny = "1"' >other/mise.toml
assert "mise -C other install tiny@1.0.0"
assert "mise -C other upgrade tiny"
jq '.entries[].remove_after = 0' "$MISE_STATE_DIR/tool-purgatory.json" >purgatory.json
mv purgatory.json "$MISE_STATE_DIR/tool-purgatory.json"

# `version` loads no tools itself; only the cleanup runs. The ambient
# PRUNE_VERSION=2.0.0 must not change what prune keeps for the project.
assert "PRUNE_VERSION=2.0.0 mise -C project version"
assert_fail "test -f '$MISE_STATE_DIR/tool-purgatory.json'"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '["3.0.0"]'

# `ls` loads the project's tools itself, so this is a use: the 2.0.0 render is
# kept and the old 1.0.0 becomes prunable.
assert "mise -C other uninstall tiny --all"
assert "mise -C other install tiny@1.0.0"
assert "mise -C other upgrade tiny"
jq '.entries[].remove_after = 0' "$MISE_STATE_DIR/tool-purgatory.json" >purgatory.json
mv purgatory.json "$MISE_STATE_DIR/tool-purgatory.json"
assert "PRUNE_VERSION=2.0.0 mise -C project ls >/dev/null"
assert_fail "test -f '$MISE_STATE_DIR/tool-purgatory.json'"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '["1.0.0","3.0.0"]'

# The same with `install`: the project goes back to 1.0.0 in a command whose
# cleanup ran first, so 1.0.0 stays and only the unrelated 3.0.0 is reported
# (2.0.0 was never installed).
assert "mise -C other uninstall tiny --all"
assert "mise -C other install tiny@1.0.0"
assert "mise -C other upgrade tiny"
jq '.entries[].remove_after = 0' "$MISE_STATE_DIR/tool-purgatory.json" >purgatory.json
mv purgatory.json "$MISE_STATE_DIR/tool-purgatory.json"
assert "PRUNE_VERSION=1.0.0 mise -C project install"
assert_fail "test -f '$MISE_STATE_DIR/tool-purgatory.json'"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '["3.0.0"]'
SCENARIO
