# mise upgrade --prune in another project retires the old version at once, unless
# a project still needs it. It goes by the same rules as prune: the version a
# templated project last used stays, a version that project dropped goes, and a
# project whose config changed since its last use keeps every version.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project other
echo '[tools]
dummy = "{{env.PRUNE_VERSION}}"' >project/mise.toml
echo '[tools]
dummy = "1"' >other/mise.toml
assert "PRUNE_VERSION=1.0.0 mise -C project install"

# The templated project still uses 1.0.0, so the upgrade keeps it.
assert "mise -C other upgrade dummy --prune"
assert "ls $MISE_DATA_DIR/installs/dummy/1.1.0"
assert "ls $MISE_DATA_DIR/installs/dummy/1.0.0"

# The templated project moves to 2.0.0, so the next upgrade retires 1.0.0.
assert "PRUNE_VERSION=2.0.0 mise -C project install"
assert "mise -C other uninstall dummy@1.1.0"
assert "mise -C other upgrade dummy --prune"
assert "ls $MISE_DATA_DIR/installs/dummy/1.1.0"
assert_fail "ls $MISE_DATA_DIR/installs/dummy/1.0.0"

# The project's config changes, so mise can't know what it needs: 1.0.0 stays.
echo '# touched' >>project/mise.toml
assert "mise install dummy@1.0.0"
assert "mise -C other uninstall dummy@1.1.0"
assert "mise -C other upgrade dummy --prune"
assert "ls $MISE_DATA_DIR/installs/dummy/1.1.0"
assert "ls $MISE_DATA_DIR/installs/dummy/1.0.0"
SCENARIO
