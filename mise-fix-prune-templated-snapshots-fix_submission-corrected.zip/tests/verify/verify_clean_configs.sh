# `mise prune --configs` forgets what mise learned about configs that are gone:
# a removed project, and a child config whose directory used its parent's
# config. When either file comes back later with the same text, mise treats it
# as a project nobody has used yet, so every installation of its computed tool
# is kept until it's used again.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p gone keep/child elsewhere
echo '[tools]
dummy = "{{env.MARK}}"' >gone/mise.toml
echo '[tools]
tiny = "{{env.MARK}}"' >keep/mise.toml
echo '[tools]
tiny = "{{env.MARK}}"' >keep/child/mise.toml
cp gone/mise.toml gone.toml
cp keep/child/mise.toml child.toml

assert "MARK=1.0.0 mise -C gone install"
assert "MARK=1.0.0 mise -C keep install"
assert "MARK=2.0.0 mise -C keep/child install"
assert "mise install dummy@3.0.0 tiny@3.0.0"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '["3.0.0"]'
expect_prunable tiny '["3.0.0"]'

# Remove the gone project and the child config, then forget them.
rm -r gone
rm keep/child/mise.toml
assert "mise -C elsewhere prune --configs"

# The gone project comes back unchanged, and mise looks at it without using it.
# Now mise knows nothing about it, so every dummy is kept. tiny 2.0.0 was only
# used by the child, which is still gone.
mkdir gone
cp gone.toml gone/mise.toml
assert "MARK=1.0.0 mise -C gone ls --prunable --json >/dev/null"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '[]'
expect_prunable tiny '["2.0.0","3.0.0"]'

# The child config comes back unchanged too: every tiny is kept until it's used.
cp child.toml keep/child/mise.toml
assert "MARK=2.0.0 mise -C keep/child ls --prunable --json >/dev/null"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable tiny '[]'
SCENARIO
