# A child config overrides one of the parent's computed tools with a literal
# version, and both directories are used. Prune from elsewhere keeps the
# parent's versions and the child's tiny. Once the child config is deleted,
# nothing uses the child's tiny any more and it's reported, while the parent's
# own computed tools stay.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project/child elsewhere
echo '[vars]
d = "1.0.0"
t = "2.0.0"
[tools]
dummy = "{{vars.d}}"
tiny = "{{vars.t}}"' >project/mise.toml
echo '[tools]
tiny = "3.0.0"' >project/child/mise.toml
assert "mise -C project install"
assert "mise -C project/child install"
assert "mise install dummy@3.0.0"

# The child overrides tiny with a literal 3.0.0, so in the child tiny isn't the
# parent's computed tool. From a third dir only the unrelated dummy 3.0.0 is
# reported, and no tiny is.
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '["3.0.0"]'
expect_prunable tiny '[]'

# Deleting the child retires its context; now the parent's computed tiny (2.0.0)
# governs and the unused tiny 3.0.0 becomes prunable.
rm project/child/mise.toml
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '["3.0.0"]'
expect_prunable tiny '["3.0.0"]'
SCENARIO
