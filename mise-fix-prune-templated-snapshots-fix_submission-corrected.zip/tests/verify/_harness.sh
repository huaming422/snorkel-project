# Shared helper for the shell verifiers. Not matched by the verify*.sh glob, so
# it's copied alongside the tests but never run as a test of its own.
#
# Most verifiers describe one end-to-end scenario on stdin and call
# run_scenario; two call run_repo_tests instead. Both reuse the repository's own
# end-to-end launcher. It builds a throwaway HOME with its own data, state,
# config and cache directories. It runs the body under a clean environment and
# tears everything down afterward. The launcher wires up the "dummy" test
# backend but not the "tiny" one, so a line at the top of the body links "tiny"
# in too. The launcher has exported the data dir and repo root by then. The
# prefix also defines the small checks the scenarios share. Each scenario starts
# from a pristine, isolated install and drives only the real mise CLI.

set -uo pipefail

# Locate the repository root (it holds e2e/run_test). The tests run from the
# checked-out repo; fall back to the conventional mount path.
if [[ -f "$PWD/e2e/run_test" ]]; then
  HARNESS_ROOT="$PWD"
elif [[ -n "${REPO_NAME:-}" && -f "/repo/$REPO_NAME/e2e/run_test" ]]; then
  HARNESS_ROOT="/repo/$REPO_NAME"
elif [[ -f "/repo/mise/e2e/run_test" ]]; then
  HARNESS_ROOT="/repo/mise"
else
  echo "verifier harness: could not locate e2e/run_test from $PWD" >&2
  exit 2
fi

# Read a scenario body from stdin, run it inside one isolated environment, and
# propagate its pass/fail exit code as this verifier's result. On a failure the
# failed assertion is printed first, then the whole log, so the start of stderr
# names what went wrong.
run_scenario() {
  local body script log rc
  body="$(cat)"
  script="$(mktemp "${TMPDIR:-/tmp}/scenario.XXXXXX")"
  log="$(mktemp "${TMPDIR:-/tmp}/scenario-log.XXXXXX")"
  {
    printf '#!/usr/bin/env bash\n'
    # Close the one setup gap versus the stock launcher: make the second test
    # backend available in the isolated install before the body runs.
    printf 'ln -sf "$ROOT/test/data/plugins/tiny" "$MISE_DATA_DIR/plugins/tiny"\n'
    cat <<'HELPERS'
# The versions of one tool in prunable.json, sorted, as a JSON array.
prunable_of() {
  jq -c --arg tool "$1" '[.[$tool][]?.version] | sort' prunable.json
}
# Fail unless ls --prunable reported exactly these versions of the tool.
expect_prunable() {
  local got
  got="$(prunable_of "$1")" || fail "prunable.json is not valid JSON"
  [[ $got == "$2" ]] || fail "prunable $1 versions: expected $2, got $got"
  ok "prunable $1 versions are $2"
}
# Fail unless every version ls --prunable reported for the tool is in this set.
expect_prunable_within() {
  local got
  got="$(prunable_of "$1")" || fail "prunable.json is not valid JSON"
  jq -en --argjson got "$got" --argjson allowed "$2" '($got - $allowed) == []' >/dev/null ||
    fail "prunable $1 versions: expected only versions from $2, got $got"
  ok "prunable $1 versions $got are within $2"
}
HELPERS
    printf '%s\n' "$body"
  } >"$script"

  bash "$HARNESS_ROOT/e2e/run_test" "$script" >"$log" 2>&1
  rc=$?
  if [[ $rc -ne 0 ]]; then
    grep -m2 -e 'E2E assertion failed' -e '^ERROR' "$log" >&2
    cat "$log" >&2
  else
    cat "$log"
  fi
  rm -f "$script" "$log"
  return "$rc"
}

# Run some of the repository's own e2e tests, as the commit the work started
# from has them, through the stock launcher. Each test gets its own isolated
# environment. Failures are listed first, then each failing test's log.
run_repo_tests() {
  local base dir name failed=() rc=0
  base="$(cat /var/lib/devcontainer_base_ref 2>/dev/null || echo HEAD)"
  dir="$(mktemp -d "${TMPDIR:-/tmp}/repo-e2e.XXXXXX")"
  for name in "$@"; do
    if ! git -C "$HARNESS_ROOT" -c safe.directory='*' show "$base:e2e/cli/$name" >"$dir/$name"; then
      failed+=("$name (not found at $base)")
      continue
    fi
    if bash "$HARNESS_ROOT/e2e/run_test" "$dir/$name" >"$dir/$name.log" 2>&1; then
      echo "passed: $name"
    else
      failed+=("$name")
    fi
  done
  if [[ ${#failed[@]} -gt 0 ]]; then
    echo "repository e2e tests failed: ${failed[*]}" >&2
    for name in "${failed[@]}"; do
      [[ -f "$dir/$name.log" ]] || continue
      echo "--- $name" >&2
      grep -m2 -e 'E2E assertion failed' -e '^ERROR' "$dir/$name.log" >&2
      tail -40 "$dir/$name.log" >&2
    done
    rc=1
  fi
  rm -rf "$dir"
  return "$rc"
}
