# The repository's own identity-layout e2e tests, taken from the commit the work
# started from, keep passing: installing, migrating and removing installations
# still behave the way they describe. The list holds the install-layout tests
# that run without network access; the others fetch plugins from GitHub.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_repo_tests \
  test_install_layout \
  test_install_layout_collision \
  test_install_layout_concurrent \
  test_install_layout_doctor \
  test_install_layout_legacy \
  test_install_layout_migrate_interrupted \
  test_install_layout_store \
  test_install_layout_uninstall \
  test_install_layout_variants
