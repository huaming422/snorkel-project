# Using a project again with a different value makes the version it dropped
# prunable. A use under another MISE_ENV is a separate use with its own version.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project elsewhere
echo '[tools]
dummy = "{{env.PRUNE_VERSION}}"' >project/mise.toml
assert "PRUNE_VERSION=1.0.0 mise -C project install"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '[]'

# Same MISE_ENV, new value: 1.0.0 is no longer used and is reported.
assert "PRUNE_VERSION=2.0.0 mise -C project install"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '["1.0.0"]'

# The project is now used under MISE_ENV=prod with 1.0.0, and the default
# environment still uses 2.0.0, so neither is reported.
assert "MISE_ENV=prod PRUNE_VERSION=1.0.0 mise -C project install"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '[]'
SCENARIO
