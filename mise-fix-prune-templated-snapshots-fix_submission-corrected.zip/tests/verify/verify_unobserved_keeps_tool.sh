# Nobody has used the project since its versions were installed: they were
# installed by explicit argument, and mise only learns of the project through an
# ls --prunable run inside it. Prune can't know which dummy the project needs,
# so it keeps every one, still reports the unrelated tiny, and doesn't fail. The
# second case is a project whose version comes from the shell, looked at the
# same way; a prune run from a shell that sets the variable to another installed
# version still keeps every dummy.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project/child elsewhere
echo '[vars]
v = "1.0.0"' >project/mise.toml
echo '[tools]
dummy = "{{vars.v}}"
tiny = "2.0.0"' >project/child/mise.toml

# Install the versions directly, without using the project.
assert "mise install dummy@1.0.0 dummy@3.0.0 tiny@2.0.0 tiny@3.0.0"

# Let mise learn about the project by looking at it, not using it.
assert "mise -C project/child ls --prunable --json >/dev/null"

# Every dummy is kept. tiny is a literal, so the project's 2.0.0 is kept and the
# unrelated 3.0.0 is reported.
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '[]'
expect_prunable tiny '["3.0.0"]'

# Prune must not fail for such a project.
assert "mise -C elsewhere prune --dry-run"
SCENARIO
[[ $? -eq 0 ]] || exit 1

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project elsewhere
echo '[tools]
dummy = "{{env.PRUNE_VERSION}}"' >project/mise.toml
assert "mise install dummy@1.0.0 dummy@3.0.0"
assert "PRUNE_VERSION=1.0.0 mise -C project ls --prunable --json >/dev/null"

# Whatever PRUNE_VERSION the prune run's own shell has, every dummy is kept.
assert "PRUNE_VERSION=3.0.0 mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '[]'
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '[]'
SCENARIO
