# A computed version that renders to `system` installs nothing, and one limited
# to another OS is never resolved here. Prune from another directory doesn't
# fail on either, and unrelated versions are still reported.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p system/child other_os/child elsewhere
echo '[vars]
v = "system"' >system/mise.toml
echo '[tools]
dummy = "{{vars.v}}"' >system/child/mise.toml
assert "mise -C system/child install"

echo '[vars]
t = "2.0.0"' >other_os/mise.toml
echo '[tools]
tiny = { version = "{{vars.t}}", os = ["windows"] }
dummy = "1.0.0"' >other_os/child/mise.toml
assert "mise -C other_os/child install"
assert "mise install dummy@3.0.0"

# Prune succeeds and still reports the genuinely-unused dummy 3.0.0 as prunable.
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '["3.0.0"]'
assert "mise -C elsewhere prune --dry-run"
SCENARIO
