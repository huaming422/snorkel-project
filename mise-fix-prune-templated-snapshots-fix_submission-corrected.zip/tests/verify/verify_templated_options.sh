# A template in a tool's options makes the tool computed even when its version is
# a literal, and the option's value comes from a parent config that a prune run
# elsewhere doesn't load. Prune from another directory succeeds and never reports
# the version the project installed; the unrelated version may be reported as
# prunable or kept.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project/child elsewhere
echo '[vars]
o = "x"' >project/mise.toml
echo '[tools]
tiny = { version = "2.0.0", note = "{{vars.o}}" }' >project/child/mise.toml
assert "mise -C project/child install"
assert "mise install tiny@3.0.0"

# The project's tiny 2.0.0 is never reported; 3.0.0 may be.
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable_within tiny '["3.0.0"]'
SCENARIO
