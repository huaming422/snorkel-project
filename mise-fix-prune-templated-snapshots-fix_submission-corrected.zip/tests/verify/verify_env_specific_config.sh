# The version comes from an env-specific config: mise.prod.toml sets the var only
# when MISE_ENV=prod. Both uses are kept from another directory, whatever
# MISE_ENV the prune run has. Editing the env-specific file means mise can't know
# what that use needs now, until the project is used again under prod.
source "$(dirname "${BASH_SOURCE[0]}")/_harness.sh"

run_scenario <<'SCENARIO'
export MISE_EXPERIMENTAL=1
export MISE_INSTALL_LAYOUT=identity

mkdir -p project elsewhere
cat >project/mise.toml <<'EOT'
[vars]
v = "1.0.0"

[tools]
dummy = "{{vars.v}}"
EOT
echo '[vars]
v = "2.0.0"' >project/mise.prod.toml

assert "mise -C project install"
assert "MISE_ENV=prod mise -C project install"
assert "ls $MISE_DATA_DIR/installs/dummy/1.0.0"
assert "ls $MISE_DATA_DIR/installs/dummy/2.0.0"
assert "mise install dummy@3.0.0"

assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '["3.0.0"]'
assert "MISE_ENV=prod mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '["3.0.0"]'

# The env-specific file changes: every dummy is kept until the next use under prod.
echo '[vars]
v = "3.0.0"' >project/mise.prod.toml
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '[]'

# That use now ends up with 3.0.0, so 2.0.0 is the one reported.
assert "MISE_ENV=prod mise -C project install"
assert "mise -C elsewhere ls --prunable --json >prunable.json"
expect_prunable dummy '["2.0.0"]'
SCENARIO
