## Task

Since we switched to the identity install layout, which is still experimental (`MISE_EXPERIMENTAL=1`, `MISE_INSTALL_LAYOUT=identity`), `mise prune` and `mise ls --prunable` can't be trusted with projects that set a tool version through a template. Some of ours keep the version in a parent config's `[vars]` and the child says `node = "{{vars.node_version}}"`. Others get it from the shell, from a `[settings] env_file`, from `MISE_ENV`, or from running mise there with `--no-env`.

Run prune from any other directory and one of two things happens. It errors out on the template, or it fills the template in with whatever values that shell happens to have. In the second case it lists the version the project actually runs as prunable, and prune deletes it. The same thing breaks `mise upgrade`, since it checks what other projects still use before it retires an old version.

Here's what we need with that layout on:

- Whatever a project ended up with the last time someone used it stays installed, no matter what the shell running prune has set. Installed versions nothing uses still get pruned. If someone uses the project again with a different value, the one it dropped becomes prunable.
- A project that gets used under two `MISE_ENV` values, or from a subdirectory that adds its own config, keeps what each of those uses ended up with.
- Running mise in the project counts as using it when the command loads the project's tools, the way install or ls do. These don't count: `prune`, `ls --prunable`, the cleanup some commands do on startup, and an `exec` that names its own version of the tool.
- When mise can't know what a project uses, prune leaves every installed version of that tool alone until the project is used again. That covers a project nobody has used since we upgraded mise, and one whose config files, its own or a parent's, changed after mise last read them for a use.
- A tool's `install_env` or options can carry a token, so nothing from them ends up on disk anywhere new. If that means mise can't tell which of that tool's versions a project uses, keep them all.
- `mise prune --configs` forgets what mise learned about configs that are gone. If one comes back later, it counts as a project nobody has used yet.
- None of this makes prune fail, and other tools still get pruned as usual.
