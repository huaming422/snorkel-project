// Copyright 2026 The InfiniFlow Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// This verifier gates the OceanBase-family routing fix in Retrieval().
//
// The reference patch changes internal/service/nlp/retrieval.go line 170 from:
//
//	useOceanBase := false   // pre-fix: routing never enters the OceanBase branch
//
// to a recognition check using the new OceanBase-family predicate (e.g.
// engine.IsOceanBaseFamily(s.docEngine.GetType()) or the equivalent global
// seam engine.IsOceanBaseFamily(engine.GetEngineType())).
//
// Both seams are production-equivalent: NewRetrievalService is always called
// with engine.Get(), so s.docEngine.GetType() == engine.GetEngineType() always
// holds at runtime. The test initialises both to "oceanbase" so either seam
// evaluates correctly.
//
// Discriminating contract (the observable behavioral consequence):
//   - For an OceanBase/SeekDB engine, Retrieval() must NOT invoke KNNScores.
//     KNNScores is an ES-specific API; calling it for an OceanBase engine is
//     the pre-fix symptom (useOceanBase=false → falls through to the ES path).
//   - For a non-family engine (elasticsearch), Retrieval() SHOULD invoke
//     KNNScores when the engine is online.
//
// The test uses a spy docEngine that records whether KNNScores was called.
// A solver that keeps useOceanBase=false (nop or partial fix) will route
// through the ES path and trigger the KNNScores spy, failing the assertion.
// A solver that adds the routing fix will skip KNNScores for OceanBase/SeekDB.
//
// The spy engine's Search() returns a single chunk without a "doc_id" field,
// which causes PruneDeletedChunks to exit early (no DB round-trip), keeping
// the test self-contained with no live database.

package nlp

import (
	"context"
	"testing"

	"ragflow/internal/dao"
	"ragflow/internal/engine"
	enginetypes "ragflow/internal/engine/types"

	"gorm.io/gorm"
)

// rerankSpyEngine is a spy DocEngine for the retrieval rerank verifier.
// It records whether KNNScores was called and returns a single canned chunk.
// All methods not relevant to this test are no-ops.
//
// Unique type name avoids collision with memNavEngine (datasetnav_test.go),
// which compiles into the same package in the same test binary.
type rerankSpyEngine struct {
	engineTypeName  string
	knnScoresCalled bool
	// chunk returned by Search(); no "doc_id" key → PruneDeletedChunks early-exits
	searchChunks []map[string]interface{}
}

func (e *rerankSpyEngine) GetType() string { return e.engineTypeName }

// Search returns the pre-configured chunks as a non-empty result so Retrieval()
// does not short-circuit before reaching the reranking logic.
func (e *rerankSpyEngine) Search(_ context.Context, req *enginetypes.SearchRequest) (*enginetypes.SearchResult, error) {
	chunks := e.searchChunks
	if chunks == nil {
		chunks = []map[string]interface{}{}
	}
	return &enginetypes.SearchResult{
		Chunks: chunks,
		Total:  int64(len(chunks)),
	}, nil
}

// KNNScores is the spy method. A call here means the ES path was taken.
func (e *rerankSpyEngine) KNNScores(_ context.Context, _ []map[string]interface{}, _ []float64, _ int) (map[string]interface{}, error) {
	e.knnScoresCalled = true
	return nil, nil
}

// GetScores returns nil (used by the ES path after KNNScores).
func (e *rerankSpyEngine) GetScores(_ map[string]interface{}) map[string]float64 { return nil }

// GetChunkIDs returns IDs for all chunks (used by Search result processing).
func (e *rerankSpyEngine) GetChunkIDs(chunks []map[string]interface{}) []string {
	ids := make([]string, len(chunks))
	for i := range chunks {
		ids[i] = "rerankspy-chunk-" + string(rune('0'+i))
	}
	return ids
}

// GetFields returns nil (field map is built from chunks directly in Search()).
func (e *rerankSpyEngine) GetFields(_ []map[string]interface{}, _ []string) map[string]map[string]interface{} {
	// Return a minimal field map so the IDs/Field zip in Search() does not panic.
	m := make(map[string]map[string]interface{}, len(e.searchChunks))
	for i, c := range e.searchChunks {
		id := "rerankspy-chunk-" + string(rune('0'+i))
		m[id] = c
	}
	return m
}

// No-op stubs for the remaining DocEngine interface methods.
func (e *rerankSpyEngine) CreateChunkStore(context.Context, string, string, int, string) error {
	return nil
}
func (e *rerankSpyEngine) InsertChunks(_ context.Context, _ []map[string]interface{}, _, _ string) ([]string, error) {
	return nil, nil
}
func (e *rerankSpyEngine) UpdateChunks(context.Context, map[string]interface{}, map[string]interface{}, string, string) error {
	return nil
}
func (e *rerankSpyEngine) DeleteChunks(context.Context, map[string]interface{}, string, string) (int64, error) {
	return 0, nil
}
func (e *rerankSpyEngine) GetChunk(context.Context, string, string, []string) (interface{}, error) {
	return nil, nil
}
func (e *rerankSpyEngine) DropChunkStore(context.Context, string, string) error { return nil }
func (e *rerankSpyEngine) ChunkStoreExists(context.Context, string, string) (bool, error) {
	return true, nil
}
func (e *rerankSpyEngine) CreateMetadataStore(context.Context, string) error { return nil }
func (e *rerankSpyEngine) InsertMetadata(_ context.Context, _ []map[string]interface{}, _ string) ([]string, error) {
	return nil, nil
}
func (e *rerankSpyEngine) UpdateMetadata(context.Context, string, string, map[string]interface{}, string) error {
	return nil
}
func (e *rerankSpyEngine) DeleteMetadata(context.Context, map[string]interface{}, string) (int64, error) {
	return 0, nil
}
func (e *rerankSpyEngine) DeleteMetadataKeys(context.Context, string, string, []string, string) error {
	return nil
}
func (e *rerankSpyEngine) DropMetadataStore(context.Context, string) error { return nil }
func (e *rerankSpyEngine) MetadataStoreExists(context.Context, string) (bool, error) {
	return true, nil
}
func (e *rerankSpyEngine) SearchMetadata(_ context.Context, _ *enginetypes.SearchMetadataRequest) (*enginetypes.SearchMetadataResult, error) {
	return nil, nil
}
func (e *rerankSpyEngine) IndexDocument(context.Context, string, string, interface{}) error {
	return nil
}
func (e *rerankSpyEngine) DeleteDocument(context.Context, string, string) error { return nil }
func (e *rerankSpyEngine) BulkIndex(context.Context, string, []interface{}) (interface{}, error) {
	return nil, nil
}
func (e *rerankSpyEngine) GetAggregation([]map[string]interface{}, string) []map[string]interface{} {
	return nil
}
func (e *rerankSpyEngine) GetHighlight([]map[string]interface{}, []string, string) map[string]string {
	return nil
}
func (e *rerankSpyEngine) RunSQL(context.Context, string, string, []string, string) ([]map[string]interface{}, error) {
	return nil, nil
}
func (e *rerankSpyEngine) Ping(context.Context) error  { return nil }
func (e *rerankSpyEngine) Close() error                { return nil }
func (e *rerankSpyEngine) SupportsPageRank() bool      { return false }
func (e *rerankSpyEngine) FilterDocIdsByMetaPushdown(_ context.Context, _ *gorm.DB, _ []string, _ []map[string]interface{}, _ string) []string {
	return nil
}

// TestVerifyOceanBaseRetrievalRerank asserts that Retrieval() uses the
// OceanBase-family routing path (and therefore skips the ES-specific
// KNNScores call) when the configured engine reports itself as "oceanbase".
//
// Pre-fix (useOceanBase=false): Retrieval() falls through to the ES path and
// invokes KNNScores — the spy records the call and the assertion fails.
//
// Post-fix (useOceanBase=engine.IsOceanBaseFamily(s.docEngine.GetType())):
// Retrieval() enters the OceanBase branch directly and never calls KNNScores
// — the assertion passes.
//
// The spy engine's Search() returns one chunk without a "doc_id" field,
// causing PruneDeletedChunks to exit early without touching the database.
// NewDocumentDAO() provides a non-nil dao (required by PruneDeletedChunks's
// nil guard) but its DB is never accessed on the early-exit path.
func TestVerifyOceanBaseRetrievalRerank(t *testing.T) {
	ctx := context.Background()

	// Ensure the global QueryBuilder is initialized before calling Retrieval().
	// Retrieval.Search() calls GetQueryBuilder().Question() for keyword parsing
	// when EmbeddingModel is nil; without initialization it panics on nil.
	// InitQueryBuilder uses sync.Once so the call is a no-op if already done.
	// An empty wordnet dir is accepted (synonym lookups simply return nothing).
	_ = InitQueryBuilder("")

	// Set the global engine type to "oceanbase" so that both valid recognition
	// seams work correctly:
	//   • instance seam: engine.IsOceanBaseFamily(s.docEngine.GetType())
	//   • global seam:   engine.IsOceanBaseFamily(engine.GetEngineType())
	// In production the two are always identical (RetrievalService is always
	// constructed with engine.Get(), so s.docEngine.GetType()==engine.GetEngineType()).
	// The spy test sets only the instance; without this call a global-seam agent
	// would see GetEngineType()=="" and incorrectly fall through to the ES path.
	// SetEngineType is a reward-stack seam written by test-setup.sh; it is not
	// part of the product and never called in production.
	engine.SetEngineType("oceanbase")
	t.Cleanup(func() { engine.SetEngineType("") })

	// The chunk has a q_3_vec field (vector dimension 3, matching the query
	// vector below). No "doc_id" key → PruneDeletedChunks exits early, no DB call.
	chunk := map[string]interface{}{
		"content_ltks": "oceanbase test chunk",
		"q_3_vec":      []float64{0.1, 0.2, 0.3},
	}

	spy := &rerankSpyEngine{
		engineTypeName: "oceanbase",
		searchChunks:   []map[string]interface{}{chunk},
	}

	svc := NewRetrievalService(spy, dao.NewDocumentDAO())

	// Use a keyword-only request (EmbeddingModel=nil) so Search() succeeds
	// without an embedding service. The routing decision (useOceanBase) is made
	// AFTER Search() returns, so this is sufficient to exercise it.
	one := 1
	thresh := 0.0  // disable similarity threshold so chunk is not filtered out
	vsw := 0.5
	agg := false
	rankFea := map[string]float64{}
	req := &RetrievalRequest{
		Question:               "test oceanbase routing",
		TenantIDs:              []string{"t1"},
		KbIDs:                  []string{"kb1"},
		Page:                   1,
		PageSize:               1,
		Top:                    &one,
		SimilarityThreshold:    &thresh,
		VectorSimilarityWeight: &vsw,
		RankFeature:            &rankFea,
		Aggs:                   &agg,
		// EmbeddingModel intentionally nil → keyword-only search, no embedding call
	}

	_, err := svc.Retrieval(ctx, req)
	if err != nil {
		t.Fatalf("Retrieval() returned unexpected error: %v\n"+
			"Expected clean execution for an oceanbase engine with no DB calls needed.", err)
	}

	// KEY ASSERTION: KNNScores must NOT be called for an OceanBase-family engine.
	// KNNScores is an ES-specific API (second-pass KNN query).  For OceanBase,
	// the correct patch routes to the OceanBase branch (which calls RerankStandard
	// directly) and never reaches the ES path where KNNScores lives.
	//
	// Both of the following production-equivalent seams are accepted:
	//   useOceanBase := engine.IsOceanBaseFamily(s.docEngine.GetType())  // instance
	//   useOceanBase := engine.IsOceanBaseFamily(engine.GetEngineType()) // global
	// The test sets both the spy instance and the global engine type (via
	// engine.SetEngineType above) so that either seam evaluates to true.
	//
	// If this assertion fails, Retrieval() fell through to the ES path and called
	// KNNScores — the OceanBase family-recognition predicate was not applied at all.
	if spy.knnScoresCalled {
		t.Errorf("KNNScores was called for an \"oceanbase\" engine.\n"+
			"For an OceanBase-family engine, Retrieval() must use the OceanBase\n"+
			"reranking path (RerankStandard with the stored vector column), not the\n"+
			"ES-specific KNNScores path.\n"+
			"Ensure retrieval.go detects the engine family — e.g.:\n"+
			"  useOceanBase := engine.IsOceanBaseFamily(s.docEngine.GetType())\n"+
			"  useOceanBase := engine.IsOceanBaseFamily(engine.GetEngineType())\n"+
			"rather than the pre-fix constant: useOceanBase := false")
	}
}
