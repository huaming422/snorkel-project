// Copyright 2026 The InfiniFlow Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// This verifier gates the SQL-driven chat path wiring for SeekDB.
// The patch extends buildSQLPrompts (internal/service/chat_pipeline.go)
// to handle "seekdb" with the same OceanBase SQL system prompt it uses for
// "oceanbase".  A solver that defines IsOceanBaseFamily but does not wire it
// into buildSQLPrompts (or forgets to add "seekdb" to the switch case) will
// produce the wrong system prompt and fail this test.

package service

import (
	"testing"
)

// TestVerifySeekDBChatPathWiring asserts that a "seekdb" engine is routed to
// the OceanBase SQL prompt in buildSQLPrompts, not the ES/unknown default.
// - correct wiring: "seekdb" maps to oceanbaseSQLSysPrompt → PASS
// - nop / partial solver: "seekdb" falls through to ES default → FAIL
func TestVerifySeekDBChatPathWiring(t *testing.T) {
	fieldMap := map[string]interface{}{
		"chunk_data": nil,
		"kb_id":      nil,
	}

	seekdbSys, _, _ := buildSQLPrompts("seekdb", "ragflow_doc_t1", "show me the data", fieldMap)
	oceanbaseSys, _, _ := buildSQLPrompts("oceanbase", "ragflow_doc_t1", "show me the data", fieldMap)
	esSys, _, _ := buildSQLPrompts("elasticsearch", "ragflow_doc_t1", "show me the data", fieldMap)

	// seekdb and oceanbase must use the same system prompt (both are SQL/JSON
	// engines over the MySQL wire, not the flat-column ES schema).
	if seekdbSys != oceanbaseSys {
		t.Errorf("buildSQLPrompts(\"seekdb\") system prompt does not match oceanbase prompt.\n"+
			"seekdb prompt starts with:    %q\n"+
			"oceanbase prompt starts with: %q\n"+
			"Ensure seekdb is handled in the same switch case as oceanbase in buildSQLPrompts.",
			seekdbChatTruncate(seekdbSys, 120), seekdbChatTruncate(oceanbaseSys, 120))
	}

	// The seekdb prompt must differ from the ES default (guard against a
	// solver that accidentally routes seekdb to the wrong branch).
	if seekdbSys == esSys {
		t.Errorf("buildSQLPrompts(\"seekdb\") returned the ES/default system prompt — seekdb must be handled separately from elasticsearch.")
	}
}

// seekdbChatTruncate caps a string at maxLen for error messages.
// Named with a file-unique prefix to avoid colliding with the package-level
// truncate helper in skill_indexer.go.
func seekdbChatTruncate(s string, maxLen int) string {
	if len(s) <= maxLen {
		return s
	}
	return s[:maxLen] + "…"
}
