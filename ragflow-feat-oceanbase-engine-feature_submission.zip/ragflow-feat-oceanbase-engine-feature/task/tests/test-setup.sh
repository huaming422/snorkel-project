#!/usr/bin/env bash
#
# Sourced (not exec'd, so exported env sticks) before the Go verifier runs. The
# image already baked the full Go module closure at the base commit and compiled
# the touched packages under CGO_ENABLED=0 (internal/common/libm_purego.go is the
# non-cgo math fallback, so no native static libraries are needed). This script
# only makes the environment robust against an agent's edits and a freshly
# spawned shell that didn't inherit the image ENV. It is offline-first: every
# step below works with no network; nothing here fetches.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/ragflow}"
cd "$REPO_DIR"

# The OceanBase/SeekDB engine, config, and service tests are pure go-sqlmock
# unit tests that compile without CGO. Force CGO off so the purego math fallback
# is selected and no office_oxide / rag_tokenizer static libs are required.
export CGO_ENABLED=0

# Pin the toolchain to the baked one even if the harness scrubs PATH, and never
# let `go` try to download a different toolchain (no network in the agent phase).
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac
export GOTOOLCHAIN=local
export GOFLAGS="${GOFLAGS:-} -mod=mod"

# Inject a reward-stack test seam into the engine package so the retrieval
# verifier can set the global engine type alongside the spy instance. This
# allows agents that route via engine.GetEngineType() (global seam) to pass
# the routing test even though the test constructs only a spy DocEngine
# (instance seam). In production the two seams are always identical because
# NewRetrievalService is always called with engine.Get().
#
# The file is written here rather than baked into the image so it:
# (a) appears AFTER the agent has applied their patch (no source conflict),
# (b) is cleaned up automatically when the container exits, and
# (c) never shows up as a hint in the agent's file tree.
SEAM_FILE="${REPO_DIR}/internal/engine/engine_reward_seam.go"
cat > "$SEAM_FILE" <<'GOEOF'
// engine_reward_seam.go — reward-stack test helper; not part of the product.
// Provides an exported setter for the package-level engineType variable so
// the retrieval verifier can initialise both the instance seam (spy.GetType)
// and the global seam (GetEngineType) to the same value, matching the
// invariant that always holds in production.
package engine

// SetEngineType sets the global engine-type string. Exported for the
// Staff-Bench reward stack only; never called by production code.
func SetEngineType(t string) { engineType = t }
GOEOF

# Warm the build cache for the packages the reward stack targets, so the graded
# `go test` run doesn't pay a cold compile. We use `go build`, NOT `go vet`:
# this base commit carries a PRE-EXISTING vet nit in an unrelated test file
# (internal/service/nlp/synonym_test.go copies a sync/atomic value), and `go vet`
# compiles _test.go files, so a vet warm-up would spuriously log that nit. The
# module closure is already present; `|| true` keeps a partial agent tree from
# aborting setup (the verifier reports the real compile status).
CGO_ENABLED=0 go build \
    ./internal/engine \
    ./internal/engine/oceanbase \
    ./internal/server/config \
    ./internal/service \
    ./internal/service/chunk \
    ./internal/service/nlp \
    ./internal/service/document \
    >/dev/null 2>&1 || true

echo "test-setup.sh: ready (CGO_ENABLED=$CGO_ENABLED, GOTOOLCHAIN=$GOTOOLCHAIN)"
