## Task

We want to run OceanBase and its SeekDB variant through the Go runtime. The runtime picks a document engine from config, but there's no implementation for either, so anyone deploying on OceanBase or SeekDB is stuck on the Python path. Add a document engine for them that slots into the same engine selection as the rest — selected by the usual document-engine config value, the same place `elasticsearch` and `infinity` are chosen, using `oceanbase` and `seekdb` as the selector values.

Both speak the MySQL-compatible wire protocol, so talk to them through the MySQL driver the runtime already uses rather than a separate SDK. Treat this as a port of the existing Python OceanBase/SeekDB connector: it has to stay compatible with databases that connector already created, so current deployments move onto the Go runtime as-is. Leave the Python connector in place as the reference, and wire the new engine into the SQL-driven chat path too so a deployment that selects it gets a working runtime.

You're working offline with no live OceanBase or SeekDB to hit; everything the build needs is in the image. Mock the SQL layer in tests, and have any test that wants a real server skip cleanly when none is configured.

## User stories / requirements

- When a deployment configures OceanBase or SeekDB, selecting it as the document engine (or OceanBase as the main database), the runtime resolves a usable connection over the MySQL-compatible wire protocol, reusing the same credential and connection settings the MySQL configuration already uses. No separate connection configuration shape is introduced for these engines.
- An OceanBase or SeekDB database that the reference Python connector created is reusable by the Go engine with no migration: the Go engine produces and reads back the same physical table names, column definitions, index names, and array, JSON, and vector value encodings. Data written by one side is seen correctly by the other.
- Once OceanBase or SeekDB is selected, every part of the runtime that consumes a document engine recognizes it, so retrieval, memory, and document metadata operations and chunk vector population all run against it, not just the point where the engine is constructed.
- On a SeekDB version new enough to support it, a write waits for the database's index refresh before returning, so freshly written data is immediately searchable. On OceanBase, and on SeekDB versions that do not support it, the write returns without waiting.
- When chunk vectors are populated for an OceanBase or SeekDB-backed dataset, the engine fetches the vectors with an explicit lookup rather than expecting them inline in prior results, so downstream retrieval sees populated vectors instead of empty ones.
