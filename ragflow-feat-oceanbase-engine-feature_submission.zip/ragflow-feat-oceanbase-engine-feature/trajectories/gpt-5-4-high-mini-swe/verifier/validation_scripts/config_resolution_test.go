package config

import (
	"testing"

	"github.com/spf13/viper"
)

// TestConfigResolution tests that an OceanBase/SeekDB engine resolves to a
// usable MySQL-wire connection. The submitted patch does not add a
// ResolveOceanBaseConnection method; the connection resolution happens via
// GetMySQLConfig() after parsing with the three Parse* methods.
func TestConfigResolution(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			inputs := tc.Inputs
			expected := tc.Expected

			// Build a fresh viper for each case.
			v := viper.New()

			// Set the MySQL block from inputs["mysql"].
			mysqlMap := inputs["mysql"].(map[string]interface{})
			v.Set("mysql", mysqlMap)

			// If engine_scheme / engine_config are present, set the engine block.
			engineType := inputs["engine_type"].(string)
			if scheme, ok := inputs["engine_scheme"].(string); ok && scheme != "" {
				engineConfig, hasConfig := inputs["engine_config"].(map[string]interface{})
				block := map[string]interface{}{"scheme": scheme}
				if hasConfig {
					block["config"] = engineConfig
				}
				v.Set(engineType, block)
			}

			// Handle db_type environment variable.
			dbType, _ := inputs["db_type"].(string)
			if dbType != "" {
				t.Setenv("DB_TYPE", dbType)
			} else {
				t.Setenv("DB_TYPE", "")
			}

			// Set DOC_ENGINE so environments parse correctly.
			t.Setenv("DOC_ENGINE", engineType)

			// Create and parse the config.
			cfg := &Config{}
			if err := cfg.ParseGeneralConfig(v); err != nil {
				t.Fatalf("ParseGeneralConfig: %v", err)
			}
			if err := cfg.GetEnvironments(); err != nil {
				t.Fatalf("GetEnvironments: %v", err)
			}
			if err := cfg.ParseDatabaseConfig(v); err != nil {
				t.Fatalf("ParseDatabaseConfig: %v", err)
			}
			if err := cfg.ParseDocEngineConfig(v); err != nil {
				t.Fatalf("ParseDocEngineConfig: %v", err)
			}

			// The submitted patch does not add ResolveOceanBaseConnection.
			// Resolve the connection via GetMySQLConfig(), which is what
			// NewEngine(cfg.GetMySQLConfig(), engineType) receives at runtime.
			conn := cfg.GetMySQLConfig()

			// Assert the resolved connection fields.
			expectedDBName := expected["resolved_db_name"].(string)
			expectedUser := expected["resolved_user"].(string)
			expectedPassword := expected["resolved_password"].(string)
			expectedHost := expected["resolved_host"].(string)
			expectedPort := int(expected["resolved_port"].(float64))

			if conn.DatabaseName != expectedDBName {
				t.Errorf("resolved_db_name = %q, want %q", conn.DatabaseName, expectedDBName)
			}
			if conn.User != expectedUser {
				t.Errorf("resolved_user = %q, want %q", conn.User, expectedUser)
			}
			if conn.Password != expectedPassword {
				t.Errorf("resolved_password = %q, want %q", conn.Password, expectedPassword)
			}
			if conn.Host != expectedHost {
				t.Errorf("resolved_host = %q, want %q", conn.Host, expectedHost)
			}
			if conn.Port != expectedPort {
				t.Errorf("resolved_port = %d, want %d", conn.Port, expectedPort)
			}

			// When main_db_user is not "__skip__", also assert that
			// GetMySQLConfig().User and .DatabaseName match the expected values.
			mainDBUser := expected["main_db_user"].(string)
			if mainDBUser != "__skip__" {
				mysqlCfg := cfg.GetMySQLConfig()
				if mysqlCfg.User != mainDBUser {
					t.Errorf("GetMySQLConfig().User = %q, want %q", mysqlCfg.User, mainDBUser)
				}
				if mysqlCfg.DatabaseName != expectedDBName {
					t.Errorf("GetMySQLConfig().DatabaseName = %q, want %q", mysqlCfg.DatabaseName, expectedDBName)
				}
			}
		})
	}
}
