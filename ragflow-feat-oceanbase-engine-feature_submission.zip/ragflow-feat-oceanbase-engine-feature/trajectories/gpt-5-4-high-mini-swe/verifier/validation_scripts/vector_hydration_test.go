package chunk

import (
	"reflect"
	"testing"

	"ragflow/internal/engine/types"
)

// TestVectorHydration tests that FetchChunkVectors performs an explicit lookup
// for OceanBase/SeekDB engines and skips it for Infinity (vectors inline).
//
// REUSES mockVectorFetcher and bg from the existing vector_test.go.
// All top-level symbols here are prefixed with "vh" to avoid collisions.
func TestVectorHydration(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			inputs := tc.Inputs
			expected := tc.Expected

			engineType := inputs["engine_type"].(string)
			expectedSearch := expected["expected_search"].(string)
			expectedVectorRaw := expected["expected_vector"].([]interface{})

			// Build expected vector as []float64.
			expectedVector := make([]float64, len(expectedVectorRaw))
			for i, v := range expectedVectorRaw {
				expectedVector[i] = v.(float64)
			}

			// Build the mock fetcher.
			mock := &mockVectorFetcher{engineType: engineType}

			// When the engine should perform an explicit search, seed the result.
			if expectedSearch == "searched" {
				vectorRaw := inputs["vector"].([]interface{})
				// Seed the search result for index "ragflow_t1".
				mock.searchResults = map[string]*types.SearchResult{
					"ragflow_t1": {
						Chunks: []map[string]interface{}{
							{
								"id":     "c1",
								"q_3_vec": vectorRaw,
							},
						},
					},
				}
			}

			// Call FetchChunkVectors.
			result := FetchChunkVectors(bg, mock, []string{"c1"}, []string{"t1"}, []string{"kb1"}, 3)

			// EXPECTED: expected_search
			if expectedSearch == "searched" {
				if len(mock.searchCalled) == 0 {
					t.Errorf("expected explicit vector search to be performed, but searchCalled is empty")
				} else if mock.searchCalled[0] != "ragflow_t1" {
					t.Errorf("searchCalled[0] = %q, want %q", mock.searchCalled[0], "ragflow_t1")
				}
			} else {
				// skipped
				if len(mock.searchCalled) > 0 {
					t.Errorf("expected no vector search to be performed, but searchCalled = %v", mock.searchCalled)
				}
			}

			// EXPECTED: expected_vector
			gotVector := result["c1"]
			if !reflect.DeepEqual(gotVector, expectedVector) {
				t.Errorf("result[\"c1\"] = %v, want %v", gotVector, expectedVector)
			}
		})
	}
}
