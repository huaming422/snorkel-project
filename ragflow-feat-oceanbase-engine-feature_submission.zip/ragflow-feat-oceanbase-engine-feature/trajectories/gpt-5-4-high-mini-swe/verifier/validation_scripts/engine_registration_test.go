package engine_test

import (
	"testing"

	"ragflow/internal/engine"
)

// regStandinForTest is a minimal DocEngine implementation for testing engine registration.
// The name is prefixed to avoid collision across files.
type regStandinForTest struct {
	engine.DocEngine // embedded interface – satisfies all other methods; never called here
	name             string
}

func (s regStandinForTest) GetType() string { return s.name }

// TestEngineRegistration verifies that:
// 1. DocEngine.GetType() returns the configured engine name.
// 2. The OceanBase/SeekDB family is recognised via the EngineOceanBase and
//    EngineSeekDB constants (the patch does not export an IsOceanBaseFamily
//    function; family membership is expressed through switch statements in
//    global.go using those constants).
func TestEngineRegistration(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			inputs := tc.Inputs
			expected := tc.Expected

			engineName := inputs["engine_name"].(string)
			expectedResolvedType := expected["expected_resolved_type"].(string)
			expectedFamily := expected["expected_family"].(string)

			// Build the stand-in engine.
			standin := regStandinForTest{name: engineName}

			// EXPECTED: GetType() returns the engine name unchanged.
			gotType := standin.GetType()
			if gotType != expectedResolvedType {
				t.Errorf("GetType() = %q, want %q", gotType, expectedResolvedType)
			}

			// EXPECTED: engine family classification.
			// The submitted patch adds EngineOceanBase and EngineSeekDB constants
			// but no IsOceanBaseFamily function. Family membership is tested by
			// comparing the engine name against those constants.
			et := engine.EngineType(engineName)
			isFamily := et == engine.EngineOceanBase || et == engine.EngineSeekDB

			if expectedFamily == "oceanbase-family" {
				if !isFamily {
					t.Errorf("engine %q not recognised as oceanbase-family (EngineOceanBase=%q, EngineSeekDB=%q)",
						engineName, engine.EngineOceanBase, engine.EngineSeekDB)
				}
			} else {
				// expectedFamily == "other"
				if isFamily {
					t.Errorf("engine %q incorrectly recognised as oceanbase-family, want other",
						engineName)
				}
			}
		})
	}
}
