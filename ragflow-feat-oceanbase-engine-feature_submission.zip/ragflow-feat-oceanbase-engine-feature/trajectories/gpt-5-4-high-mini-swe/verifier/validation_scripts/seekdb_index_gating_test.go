package oceanbase

import (
	"context"
	"fmt"
	"testing"

	"github.com/DATA-DOG/go-sqlmock"
)

// TestSeekDBIndexGating tests that:
// - A SeekDB engine with a version AT OR ABOVE the minimum threshold issues the
//   index-refresh command after a write.
// - A SeekDB engine BELOW the threshold does not issue the refresh command.
// - An OceanBase engine never issues the SeekDB-style refresh command.
func TestSeekDBIndexGating(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			inputs := tc.Inputs
			expected := tc.Expected

			engineType := inputs["engine_type"].(string)
			versionScenario := inputs["version_scenario"].(string)
			expectedRefresh := expected["expected_refresh"].(string)

			// Choose a concrete version string based on the scenario.
			// seekDBVersionRE = `(?i)seekdb\D*(\d+)\.(\d+)\.(\d+)`
			// supportsSeekDBRefresh: minimum version is SeekDB 4.3.0.
			var versionStr string
			switch versionScenario {
			case "new_enough":
				// SeekDB at or above the threshold (4.3.0 → enabled).
				versionStr = "SeekDB 4.3.0"
			case "too_old":
				// SeekDB below the threshold (4.2.9 → not enabled).
				versionStr = "SeekDB 4.2.9"
			case "not_applicable":
				// OceanBase doesn't use SeekDB refresh; use a version string
				// that doesn't match seekDBVersionRE.
				versionStr = "OceanBase 4.3.0"
			default:
				t.Fatalf("unknown version_scenario: %q", versionScenario)
			}

			// Build sqlmock DB with exact query matcher.
			db, mock, err := sqlmock.New(sqlmock.QueryMatcherOption(sqlmock.QueryMatcherEqual))
			if err != nil {
				t.Fatalf("sqlmock.New: %v", err)
			}
			defer db.Close()

			// Construct the engine via the unexported newEngineWithDB.
			e := newEngineWithDB(db, engineType, versionStr)

			// Use a table name that passes validIdentifier (no dashes).
			tn := "ragflow_test_table"

			if expectedRefresh == "refreshes" {
				// The refresh command should be issued.
				// Template: "ALTER TABLE %s REFRESH"
				refreshStmt := fmt.Sprintf(oceanBaseRefreshStmtTemplate, tn)
				mock.ExpectExec(refreshStmt).WillReturnResult(sqlmock.NewResult(0, 0))
			}
			// When no-refresh, register NO exec expectations –
			// sqlmock fails on any unexpected command.

			ctx := context.Background()
			err = e.afterWriteRefresh(ctx, tn)

			if err != nil {
				t.Errorf("afterWriteRefresh returned error: %v", err)
			}
			if mockErr := mock.ExpectationsWereMet(); mockErr != nil {
				if expectedRefresh == "refreshes" {
					t.Errorf("refresh command was not issued: %v", mockErr)
				} else {
					t.Errorf("unexpected SQL issued (expected no-refresh): %v", mockErr)
				}
			}
		})
	}
}
