package oceanbase

import (
	"context"
	"testing"

	"github.com/DATA-DOG/go-sqlmock"
)

// TestCompatContract exercises the compat-contract story:
// - metadata_write: UpdateMetadata targets the correct physical table and JSON-encodes the value.
// - reject_identifier: UpdateMetadata rejects a tenant with an unsafe identifier (backtick).
// - chunk_vector_encode: normalizeDocumentForTable encodes float vector as compact JSON bracket string.
// - preserve_invalid_json: DeleteMetadataKeys with invalid stored JSON returns error (preserves row).
// - pushdown_safe / pushdown_unsafe: buildMetadataFilterExpression accepts/rejects ops.
func TestCompatContract(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			inputs := tc.Inputs
			expected := tc.Expected

			probe := inputs["probe"].(string)
			expectedOutcome := expected["expected_outcome"].(string)

			switch probe {
			case "metadata_write":
				compatMetadataWrite(t, inputs, expected, expectedOutcome)
			case "reject_identifier":
				compatRejectIdentifier(t, inputs, expected, expectedOutcome)
			case "chunk_vector_encode":
				compatChunkVectorEncode(t, inputs, expected, expectedOutcome)
			case "preserve_invalid_json":
				compatPreserveInvalidJSON(t, inputs, expected, expectedOutcome)
			case "pushdown_safe":
				compatPushdownSafe(t, inputs, expected, expectedOutcome)
			case "pushdown_unsafe":
				compatPushdownUnsafe(t, inputs, expected, expectedOutcome)
			default:
				t.Fatalf("unknown probe: %q", probe)
			}
		})
	}
}

// compatAddIndexExpectations adds sqlmock expectations for all ensureIndex calls
// that ensureTable makes when processing chunk column specs (with enableFulltext=true).
// The chunk column spec has these HasIndex columns (in schema order):
//   kb_id, doc_id, available_int, knowledge_graph_kwd, entity_type_kwd, removed_kwd
// And these FullText columns (in schema order):
//   title_tks, title_sm_tks, content_with_weight, content_ltks, content_sm_ltks,
//   important_tks, question_tks
// The loop in ensureTable processes columns in slice order, checking HasIndex then FullText
// for each column. Returns all indexes as "already exists" to avoid CREATE INDEX execs.
func compatAddIndexExpectations(mock sqlmock.Sqlmock) {
	// The loop processes chunkColumns in order and for each column checks HasIndex
	// then FullText. The sequence of information_schema.statistics queries is:
	// kb_id(HasIndex), doc_id(HasIndex), title_tks(FullText), title_sm_tks(FullText),
	// content_with_weight(FullText), content_ltks(FullText), content_sm_ltks(FullText),
	// important_tks(FullText), question_tks(FullText),
	// available_int(HasIndex), knowledge_graph_kwd(HasIndex),
	// entity_type_kwd(HasIndex), removed_kwd(HasIndex) = 13 calls.
	for i := 0; i < 13; i++ {
		mock.ExpectQuery("information_schema.statistics").
			WillReturnRows(sqlmock.NewRows([]string{"1"}).AddRow(1))
	}
}

func compatMetadataWrite(t *testing.T, inputs, expected map[string]interface{}, expectedOutcome string) {
	t.Helper()
	tenant := inputs["tenant"].(string)
	expectedTable := expected["expected_table"].(string)

	db, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New: %v", err)
	}
	defer db.Close()

	e := newEngineWithDB(db, "oceanbase", "OceanBase 4.3.0")

	// UpdateMetadata sequence:
	// 1. loadMetaFields: SELECT meta_fields FROM {table} WHERE id=... AND kb_id=...
	// 2. upsertRows → ensureTable:
	//    a. tableExists: SELECT 1 FROM information_schema.tables WHERE ...
	//    b. 13 × indexExists: SELECT 1 FROM information_schema.statistics WHERE ...
	//       (6 HasIndex + 7 FullText columns from chunkColumns, which ensureTable uses
	//        because upsertRows hardcodes metadata=false)
	// 3. INSERT INTO {table} (...) VALUES (...) ON DUPLICATE KEY UPDATE ...
	// 4. afterWriteRefresh: noop for oceanbase

	// Step 1: loadMetaFields returns empty (no existing row).
	mock.ExpectQuery("SELECT meta_fields FROM " + expectedTable).
		WillReturnRows(sqlmock.NewRows([]string{"meta_fields"}))

	// Step 2a: tableExists returns 1 (table exists, skip CREATE TABLE).
	mock.ExpectQuery("information_schema.tables").
		WillReturnRows(sqlmock.NewRows([]string{"1"}).AddRow(1))

	// Step 2b: 13 × indexExists returns 1 (all indexes exist, skip CREATE INDEX).
	compatAddIndexExpectations(mock)

	// Step 3: INSERT INTO the expected table.
	mock.ExpectExec("INSERT INTO " + expectedTable).
		WillReturnResult(sqlmock.NewResult(1, 1))

	ctx := context.Background()
	err = e.UpdateMetadata(ctx, "doc-1", "kb-1", map[string]interface{}{"author": "Alice"}, tenant)

	if expectedOutcome == "accepted" {
		if err != nil {
			t.Errorf("UpdateMetadata returned error (expected accepted): %v", err)
		}
		if mockErr := mock.ExpectationsWereMet(); mockErr != nil {
			t.Errorf("sqlmock expectations not met (table %q not targeted): %v", expectedTable, mockErr)
		}
	} else {
		if err == nil {
			t.Errorf("UpdateMetadata should have returned error (expected rejected)")
		}
	}
}

func compatRejectIdentifier(t *testing.T, inputs, expected map[string]interface{}, expectedOutcome string) {
	t.Helper()
	tenant := inputs["tenant"].(string) // e.g. "tenant`injected"

	db, _, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New: %v", err)
	}
	defer db.Close()

	e := newEngineWithDB(db, "oceanbase", "OceanBase 4.3.0")

	ctx := context.Background()
	err = e.UpdateMetadata(ctx, "doc-1", "kb-1", map[string]interface{}{"x": "y"}, tenant)

	if expectedOutcome == "rejected" {
		if err == nil {
			t.Errorf("UpdateMetadata should return error for unsafe tenant identifier %q", tenant)
		}
	} else {
		if err != nil {
			t.Errorf("UpdateMetadata returned unexpected error: %v", err)
		}
	}
}

func compatChunkVectorEncode(t *testing.T, inputs, expected map[string]interface{}, expectedOutcome string) {
	t.Helper()
	expectedEncodedVector := expected["expected_encoded_vector"].(string)

	// Get the float vector from inputs.
	rawVector := inputs["vector"].([]interface{})
	vec := make([]float64, len(rawVector))
	for i, v := range rawVector {
		vec[i] = v.(float64)
	}

	// Drive normalizeDocumentForTable directly with a row containing the vector key.
	// The vector field "q_3_vec" matches vectorColumnRE so it's encoded via vectorLiteral.
	vecName := "q_3_vec"
	_, specMap := tableSpecs("ragflow_t1", false)

	doc := map[string]interface{}{
		"id":    "c1",
		vecName: vec,
	}

	norm := normalizeDocumentForTable(doc, specMap, true)
	encoded, ok := norm[vecName]
	if !ok {
		// vectorLiteral may not put the key in norm if the vector is empty; check directly.
		encodedDirect := vectorLiteral(vec)
		if expectedOutcome == "accepted" {
			if encodedDirect != expectedEncodedVector {
				t.Errorf("vectorLiteral(%v) = %q, want %q", vec, encodedDirect, expectedEncodedVector)
			}
		}
		return
	}

	encodedStr, ok := encoded.(string)
	if !ok {
		t.Fatalf("encoded vector is not string: %T %v", encoded, encoded)
	}

	if expectedOutcome == "accepted" {
		if encodedStr != expectedEncodedVector {
			t.Errorf("encoded vector = %q, want %q", encodedStr, expectedEncodedVector)
		}
	}
}

func compatPreserveInvalidJSON(t *testing.T, inputs, expected map[string]interface{}, expectedOutcome string) {
	t.Helper()
	tenant := inputs["tenant"].(string)

	db, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New: %v", err)
	}
	defer db.Close()

	e := newEngineWithDB(db, "oceanbase", "OceanBase 4.3.0")
	tn := metadataTableName(tenant)

	ctx := context.Background()

	// loadMetaFields returns a row with invalid JSON "{" for meta_fields.
	// The SELECT uses the table name directly (no identifier validation).
	mock.ExpectQuery("SELECT meta_fields FROM " + tn).
		WillReturnRows(sqlmock.NewRows([]string{"meta_fields"}).AddRow([]byte("{")))

	err = e.DeleteMetadataKeys(ctx, "doc-1", "kb-1", []string{"author"}, tenant)

	if expectedOutcome == "rejected" {
		if err == nil {
			t.Errorf("DeleteMetadataKeys should return error for invalid JSON meta_fields")
		}
	} else {
		if err != nil {
			t.Errorf("DeleteMetadataKeys returned unexpected error: %v", err)
		}
	}
}

func compatPushdownSafe(t *testing.T, inputs, expected map[string]interface{}, expectedOutcome string) {
	t.Helper()
	op := inputs["op"].(string)

	// The engine's pushdown decision is tested via buildMetadataFilterExpression.
	// "accepted" = the function returns a non-empty expression for this op.
	// "rejected" = the function returns an empty string.
	conds := map[string]interface{}{
		"conditions": []interface{}{
			map[string]interface{}{
				"name":                "author",
				"comparison_operator": op,
				"value":               "Alice",
			},
		},
		"logical_operator": "AND",
	}

	expr := buildMetadataFilterExpression(conds)

	if expectedOutcome == "accepted" {
		if expr == "" {
			t.Errorf("buildMetadataFilterExpression returned empty for op=%q, want non-empty (accepted)", op)
		}
	} else {
		if expr != "" {
			t.Errorf("buildMetadataFilterExpression returned non-empty for op=%q, want empty (rejected)", op)
		}
	}
}

func compatPushdownUnsafe(t *testing.T, inputs, expected map[string]interface{}, expectedOutcome string) {
	t.Helper()
	op := inputs["op"].(string)

	conds := map[string]interface{}{
		"conditions": []interface{}{
			map[string]interface{}{
				"name":                "author",
				"comparison_operator": op,
				"value":               "Alice",
			},
		},
		"logical_operator": "AND",
	}

	expr := buildMetadataFilterExpression(conds)

	if expectedOutcome == "rejected" {
		if expr != "" {
			t.Errorf("buildMetadataFilterExpression returned non-empty for op=%q, want empty (rejected)", op)
		}
	} else {
		if expr == "" {
			t.Errorf("buildMetadataFilterExpression returned empty for op=%q, want non-empty (accepted)", op)
		}
	}
}
