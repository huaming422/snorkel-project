// Whitebox test for package oceanbase — seekdb index gating.
// All top-level identifiers are prefixed with "idxgate" to avoid collision
// with the compat_contract_test.go file compiled into the same package.
package oceanbase

import (
	"context"
	"errors"
	"testing"

	"github.com/DATA-DOG/go-sqlmock"
)

func TestSeekdbIndexGating(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			inputs := tc.Inputs
			expected := tc.Expected

			engineType, _ := inputs["engine_type"].(string)
			versionScenario, _ := inputs["version_scenario"].(string)
			expectedRefresh, _ := expected["expected_refresh"].(string)

			// Unset any env override so detectWaitSupport uses the probe SQL.
			t.Setenv("SEEKDB_WAIT_FOR_REFRESH", "")

			db, mock, err := sqlmock.New()
			if err != nil {
				t.Fatalf("sqlmock.New: %v", err)
			}
			defer db.Close()

			e := &oceanbaseEngine{
				db:               db,
				dbName:           "test",
				engineName:       engineType,
				tableExistsCache: map[string]bool{},
				vectorColCache:   map[string]bool{},
			}

			ctx := context.Background()

			// Step 1: Run the version-detection step (detectWaitSupport).
			// Configure sqlmock based on the version scenario.
			switch versionScenario {
			case "new_enough":
				// Detection probe succeeds → supportsWait = true.
				mock.ExpectExec("CALL dbms_vector\\.refresh_index_cache").
					WillReturnResult(sqlmock.NewResult(0, 0))
			case "too_old":
				// Detection probe fails → supportsWait = false.
				mock.ExpectExec("CALL dbms_vector\\.refresh_index_cache").
					WillReturnError(errors.New("seekdb: operation not supported"))
			case "not_applicable":
				// OceanBase engine: detectWaitSupport returns false immediately
				// (no SQL is issued). No expectations registered.
			default:
				t.Fatalf("unknown version_scenario: %q", versionScenario)
			}

			// Run the detection step to set supportsWait on the engine.
			e.supportsWait = e.detectWaitSupport(ctx)

			// Step 2: Set up expectations for the refresh step, then invoke it.
			if expectedRefresh == "refreshes" {
				// The refresh command MUST be issued.
				mock.ExpectExec("CALL dbms_vector\\.refresh_index_cache").
					WillReturnResult(sqlmock.NewResult(0, 0))
			}
			// For "no-refresh": no expectations — sqlmock fails on unexpected SQL.

			e.waitForRefresh(ctx)

			// Assert all sqlmock expectations were met.
			if err := mock.ExpectationsWereMet(); err != nil {
				if expectedRefresh == "refreshes" {
					t.Errorf("expected index-refresh command to be issued but mock not satisfied: %v", err)
				} else {
					t.Errorf("unexpected SQL issued (no-refresh expected): %v", err)
				}
			}
		})
	}
}
