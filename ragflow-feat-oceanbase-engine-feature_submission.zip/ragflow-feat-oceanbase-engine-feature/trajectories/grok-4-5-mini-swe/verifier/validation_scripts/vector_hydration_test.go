// Whitebox test for package chunk — vector hydration.
// Top-level helpers prefixed with "vh" as instructed.
// REUSES existing mockVectorFetcher and bg from vector_test.go.
package chunk

import (
	"testing"

	"ragflow/internal/engine/types"
)

func TestVectorHydration(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			inputs := tc.Inputs
			expected := tc.Expected

			engineType, _ := inputs["engine_type"].(string)
			rawVector, _ := inputs["vector"].([]interface{})
			expectedSearch, _ := expected["expected_search"].(string)
			rawExpectedVector, _ := expected["expected_vector"].([]interface{})

			// Convert expected_vector to []float64.
			expectedVector := make([]float64, len(rawExpectedVector))
			for i, v := range rawExpectedVector {
				expectedVector[i], _ = v.(float64)
			}

			// Convert inputs["vector"] to []interface{} for the chunk.
			// The procedure says: "q_3_vec: <inputs['vector'] as []interface{}>".
			var vecAsInterface []interface{}
			for _, v := range rawVector {
				vecAsInterface = append(vecAsInterface, v)
			}

			// Build the mockVectorFetcher.
			mock := &mockVectorFetcher{engineType: engineType}

			// Seed searchResults for engines that should search.
			if expectedSearch == "searched" {
				mock.searchResults = map[string]*types.SearchResult{
					"ragflow_t1": {
						Chunks: []map[string]interface{}{
							{"id": "c1", "q_3_vec": vecAsInterface},
						},
					},
				}
			}

			result := FetchChunkVectors(bg, mock, []string{"c1"}, []string{"t1"}, []string{"kb1"}, 3)

			// EXPECTED: expected_search
			if expectedSearch == "searched" {
				if len(mock.searchCalled) == 0 {
					t.Errorf("expected Search to be called (searched), but searchCalled is empty")
				} else if mock.searchCalled[0] != "ragflow_t1" {
					t.Errorf("expected search on 'ragflow_t1', got %v", mock.searchCalled)
				}
			} else { // "skipped"
				if len(mock.searchCalled) > 0 {
					t.Errorf("expected no Search call (skipped), but searchCalled = %v", mock.searchCalled)
				}
			}

			// EXPECTED: expected_vector — result["c1"] matches expected_vector
			gotVector, ok := result["c1"]
			if !ok {
				t.Fatalf("result['c1'] not found in FetchChunkVectors output")
			}
			if len(gotVector) != len(expectedVector) {
				t.Fatalf("result['c1'] length: got %d, want %d", len(gotVector), len(expectedVector))
			}
			for i := range expectedVector {
				if gotVector[i] != expectedVector[i] {
					t.Errorf("result['c1'][%d]: got %v, want %v", i, gotVector[i], expectedVector[i])
				}
			}
		})
	}
}
