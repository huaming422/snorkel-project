package config

import (
	"strings"
	"testing"

	"github.com/spf13/viper"
)

// TestConfigResolution validates that OceanBase/SeekDB engine configs resolve
// to the correct MySQL-wire connection settings.
func TestConfigResolution(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			inputs := tc.Inputs
			expected := tc.Expected

			// Set DB_TYPE env BEFORE calling Parse* methods, as the suggestion
			// requires the database-type selection path to be exercised.
			dbType, _ := inputs["db_type"].(string)
			if dbType != "" {
				t.Setenv("DB_TYPE", dbType)
			} else {
				t.Setenv("DB_TYPE", "")
			}

			v := viper.New()

			// Set general.database = "mysql" so ParseDatabaseConfig works.
			v.Set("general.database", "mysql")

			// Set MySQL config as a full map so v.Sub("mysql") works correctly.
			mysqlRaw, _ := inputs["mysql"].(map[string]interface{})
			if mysqlRaw != nil {
				mysqlMap := map[string]interface{}{}
				for k, val := range mysqlRaw {
					mysqlMap[k] = val
				}
				v.Set("mysql", mysqlMap)
			}

			// Set engine config as a full nested map so v.Sub(engineType).Sub("config") works.
			engineType, _ := inputs["engine_type"].(string)
			engineScheme, _ := inputs["engine_scheme"].(string)
			engineConfig, _ := inputs["engine_config"].(map[string]interface{})

			if engineType != "" && engineScheme != "" {
				engineMap := map[string]interface{}{
					"scheme": engineScheme,
				}
				if engineConfig != nil {
					cfgMap := map[string]interface{}{}
					for k, val := range engineConfig {
						cfgMap[k] = val
					}
					engineMap["config"] = cfgMap
				}
				v.Set(engineType, engineMap)
			}

			cfg := &Config{}

			if err := cfg.ParseGeneralConfig(v); err != nil {
				t.Fatalf("ParseGeneralConfig: %v", err)
			}
			if err := cfg.ParseDatabaseConfig(v); err != nil {
				t.Fatalf("ParseDatabaseConfig: %v", err)
			}
			if err := cfg.ParseDocEngineConfig(v); err != nil {
				t.Fatalf("ParseDocEngineConfig: %v", err)
			}

			// Resolve the connection using the OceanBaseConfig and MySQLConfig.
			// The patch adds GetOceanBaseConfig() / GetSeekDBConfig() which return
			// OceanBaseConfig{Scheme, Config{DBName, User, Password, Host, Port}}.
			// resolveConn logic (mirrored from the patch's resolveConn function):
			//   - if Scheme == "mysql" (case-insensitive), inherit MySQL credentials
			//   - otherwise use engine's own config
			//   - db_name always from engine config
			var engineCfg OceanBaseConfig
			switch strings.ToLower(engineType) {
			case "seekdb":
				engineCfg = cfg.GetSeekDBConfig()
			case "oceanbase":
				engineCfg = cfg.GetOceanBaseConfig()
			default:
				t.Fatalf("unknown engine_type: %s", engineType)
			}

			mysqlCfg := cfg.GetMySQLConfig()

			var resolvedHost, resolvedUser, resolvedPassword, resolvedDbName string
			var resolvedPort int

			if strings.EqualFold(engineCfg.Scheme, "mysql") {
				// Inherit MySQL block's credentials (as resolveConn does).
				resolvedHost = mysqlCfg.Host
				resolvedPort = mysqlCfg.Port
				resolvedUser = mysqlCfg.User
				resolvedPassword = mysqlCfg.Password
			} else {
				// Use engine's explicit config block (as resolveConn does).
				resolvedHost = engineCfg.Config.Host
				resolvedPort = engineCfg.Config.Port
				resolvedUser = engineCfg.Config.User
				resolvedPassword = engineCfg.Config.Password
			}
			// db_name always comes from the engine's config block.
			resolvedDbName = engineCfg.Config.DBName

			// EXPECTED: resolved_db_name
			expectedDbName, _ := expected["resolved_db_name"].(string)
			if resolvedDbName != expectedDbName {
				t.Errorf("resolved_db_name: got %q, want %q", resolvedDbName, expectedDbName)
			}
			// EXPECTED: resolved_user
			expectedUser, _ := expected["resolved_user"].(string)
			if resolvedUser != expectedUser {
				t.Errorf("resolved_user: got %q, want %q", resolvedUser, expectedUser)
			}
			// EXPECTED: resolved_password
			expectedPassword, _ := expected["resolved_password"].(string)
			if resolvedPassword != expectedPassword {
				t.Errorf("resolved_password: got %q, want %q", resolvedPassword, expectedPassword)
			}
			// EXPECTED: resolved_host
			expectedHost, _ := expected["resolved_host"].(string)
			if resolvedHost != expectedHost {
				t.Errorf("resolved_host: got %q, want %q", resolvedHost, expectedHost)
			}
			// EXPECTED: resolved_port
			expectedPort := int(expected["resolved_port"].(float64))
			if resolvedPort != expectedPort {
				t.Errorf("resolved_port: got %d, want %d", resolvedPort, expectedPort)
			}

			// EXPECTED: main_db_user (when not "__skip__")
			mainDBUser, _ := expected["main_db_user"].(string)
			if mainDBUser != "__skip__" {
				// When the engine is configured as the main database, the
				// OceanBase config should be mapped onto the MySQL-wire config
				// so GetMySQLConfig() returns the engine's credentials.
				gotUser := cfg.GetMySQLConfig().User
				gotDbName := cfg.GetMySQLConfig().DatabaseName
				if gotUser != mainDBUser {
					t.Errorf("main_db_user: GetMySQLConfig().User = %q, want %q", gotUser, mainDBUser)
				}
				if gotDbName != expectedDbName {
					t.Errorf("main_db_name: GetMySQLConfig().DatabaseName = %q, want %q", gotDbName, expectedDbName)
				}
			}
		})
	}
}
