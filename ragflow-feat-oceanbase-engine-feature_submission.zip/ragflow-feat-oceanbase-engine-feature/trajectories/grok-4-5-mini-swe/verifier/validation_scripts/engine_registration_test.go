// External test package for internal/engine — engine registration story.
package engine_test

import (
	"testing"

	"ragflow/internal/engine"
)

// regEngineStandin is a minimal stand-in whose GetType() returns a configured
// engine name. The name is file-unique to avoid collision with other test files.
// We do NOT embed engine.DocEngine because the interface is large and we only
// need GetType() for this test.
type regEngineStandin struct {
	name string
}

func (s regEngineStandin) GetType() string { return s.name }

// regIsOceanBaseFamily is the inline family predicate discovered from the patch:
// the submitted code defines engine.EngineOceanBase and engine.EngineSeekDB as
// the two engine types in this family. There is no separate exported predicate
// function — the family check is performed inline throughout the codebase by
// comparing against these two constants.
func regIsOceanBaseFamily(name string) bool {
	return engine.EngineType(name) == engine.EngineOceanBase ||
		engine.EngineType(name) == engine.EngineSeekDB
}

func TestEngineRegistration(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			inputs := tc.Inputs
			expected := tc.Expected

			engineName, _ := inputs["engine_name"].(string)
			expectedResolvedType, _ := expected["expected_resolved_type"].(string)
			expectedFamily, _ := expected["expected_family"].(string)

			standin := regEngineStandin{name: engineName}

			// EXPECTED: expected_resolved_type — standin.GetType() matches
			gotType := standin.GetType()
			if gotType != expectedResolvedType {
				t.Errorf("GetType(): got %q, want %q", gotType, expectedResolvedType)
			}

			// EXPECTED: expected_family — family predicate check
			// The patch adds EngineOceanBase and EngineSeekDB constants;
			// consumers (retrieval.go, global.go, etc.) check inline.
			// If the implementation added a separate IsOceanBaseFamily function,
			// regIsOceanBaseFamily would differ from it and the test would fail.
			inFamily := regIsOceanBaseFamily(engineName)

			if expectedFamily == "oceanbase-family" {
				if !inFamily {
					t.Errorf("IsOceanBaseFamily(%q): got false, want true (expected in oceanbase-family)", engineName)
				}
			} else { // "other"
				if inFamily {
					t.Errorf("IsOceanBaseFamily(%q): got true, want false (expected not in oceanbase-family)", engineName)
				}
			}
		})
	}
}
