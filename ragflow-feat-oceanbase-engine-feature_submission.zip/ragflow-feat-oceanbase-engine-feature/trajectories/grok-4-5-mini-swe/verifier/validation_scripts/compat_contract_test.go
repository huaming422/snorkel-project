// Whitebox test for package oceanbase — compat contract.
// All top-level identifiers are prefixed with "compat" to avoid collision
// with the seekdb_index_gating_test.go file compiled into the same package.
package oceanbase

import (
	"context"
	"testing"

	"github.com/DATA-DOG/go-sqlmock"
)

func TestCompatContract(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			inputs := tc.Inputs
			expected := tc.Expected

			probe, _ := inputs["probe"].(string)
			expectedOutcome, _ := expected["expected_outcome"].(string)
			expectedTable, _ := expected["expected_table"].(string)
			expectedEncodedVector, _ := expected["expected_encoded_vector"].(string)

			switch probe {
			case "metadata_write":
				compatDoMetadataWrite(t, inputs, expectedOutcome, expectedTable)

			case "reject_identifier":
				compatDoRejectIdentifier(t, inputs, expectedOutcome)

			case "chunk_vector_encode":
				compatDoChunkVectorEncode(t, inputs, expectedOutcome, expectedEncodedVector)

			case "preserve_invalid_json":
				compatDoPreserveInvalidJSON(t, inputs, expectedOutcome)

			case "pushdown_safe", "pushdown_unsafe":
				compatDoPushdown(t, inputs, expectedOutcome)

			default:
				t.Fatalf("unknown probe: %q", probe)
			}
		})
	}
}

// compatDoMetadataWrite: call UpdateMetadata, verify outcome and table name.
func compatDoMetadataWrite(t *testing.T, inputs map[string]interface{}, expectedOutcome, expectedTable string) {
	t.Helper()
	tenant, _ := inputs["tenant"].(string)

	db, mock, err := sqlmock.New(sqlmock.QueryMatcherOption(sqlmock.QueryMatcherRegexp))
	if err != nil {
		t.Fatalf("sqlmock.New: %v", err)
	}
	defer db.Close()

	e := &oceanbaseEngine{
		db:               db,
		dbName:           "test",
		engineName:       "oceanbase",
		tableExistsCache: map[string]bool{},
		vectorColCache:   map[string]bool{},
	}

	// Compute the expected table name for verification.
	tableName := buildMetadataTableName(tenant)

	// Set up expectations for the happy path (if the call is expected to succeed).
	// tableExists: SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
	mock.ExpectQuery("SELECT COUNT").
		WillReturnRows(sqlmock.NewRows([]string{"n"}).AddRow(1))
	// loadMetaFields SELECT: returns no row (doc not found → INSERT)
	mock.ExpectQuery("SELECT `meta_fields`").
		WillReturnRows(sqlmock.NewRows([]string{"meta_fields"}))
	// INSERT INTO the metadata table
	mock.ExpectExec("INSERT INTO").
		WillReturnResult(sqlmock.NewResult(1, 1))

	metaFields := map[string]interface{}{"author": "Alice"}
	callErr := e.UpdateMetadata(context.Background(), "doc-1", "kb-1", metaFields, tenant)

	if expectedOutcome == "accepted" {
		if callErr != nil {
			t.Errorf("UpdateMetadata: expected success (accepted), got error: %v", callErr)
			return
		}
		// The call succeeded — verify the table name matches.
		if tableName != expectedTable {
			t.Errorf("metadata table name: got %q, want %q", tableName, expectedTable)
		}
		// Verify sqlmock expectations (SQL was issued with the expected table).
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("sqlmock expectations not met: %v", err)
		}
	} else { // "rejected"
		if callErr == nil {
			t.Errorf("UpdateMetadata: expected error (rejected), got nil")
		}
	}
}

// compatDoRejectIdentifier: call UpdateMetadata with a backtick in tenant, expect error.
func compatDoRejectIdentifier(t *testing.T, inputs map[string]interface{}, expectedOutcome string) {
	t.Helper()
	tenant, _ := inputs["tenant"].(string)

	db, _, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New: %v", err)
	}
	defer db.Close()

	e := &oceanbaseEngine{
		db:               db,
		dbName:           "test",
		engineName:       "oceanbase",
		tableExistsCache: map[string]bool{},
		vectorColCache:   map[string]bool{},
	}

	callErr := e.UpdateMetadata(context.Background(), "doc-1", "kb-1",
		map[string]interface{}{"x": 1}, tenant)

	if expectedOutcome == "rejected" {
		if callErr == nil {
			t.Errorf("UpdateMetadata with invalid identifier tenant %q: expected error, got nil", tenant)
		}
	} else {
		if callErr != nil {
			t.Errorf("UpdateMetadata: expected success, got error: %v", callErr)
		}
	}
}

// compatDoChunkVectorEncode: verify vector is stored as compact bracketed string.
func compatDoChunkVectorEncode(t *testing.T, inputs map[string]interface{}, expectedOutcome, expectedEncodedVector string) {
	t.Helper()

	// Convert inputs["vector"] from []interface{} to []float64
	rawVec, _ := inputs["vector"].([]interface{})
	vec := make([]float64, len(rawVec))
	for i, v := range rawVec {
		vec[i], _ = v.(float64)
	}

	chunk := map[string]interface{}{
		"id":      "c1",
		"kb_id":   "kb1",
		"q_3_vec": vec,
	}

	cols, vals := prepareChunkRow(chunk, "kb1")

	// Find the q_3_vec column in the prepared row.
	var encodedVector string
	found := false
	for i, c := range cols {
		if c == "q_3_vec" {
			if s, ok := vals[i].(string); ok {
				encodedVector = s
				found = true
			}
			break
		}
	}

	if expectedOutcome == "accepted" {
		if !found {
			t.Errorf("q_3_vec column not found in prepareChunkRow output columns: %v", cols)
			return
		}
		if expectedEncodedVector != "__skip__" {
			if encodedVector != expectedEncodedVector {
				t.Errorf("encoded vector: got %q, want %q", encodedVector, expectedEncodedVector)
			}
		}
	} else {
		if found {
			t.Errorf("expected q_3_vec not in output, but got %q", encodedVector)
		}
	}
}

// compatDoPreserveInvalidJSON: DeleteMetadataKeys with stored invalid JSON should be rejected.
func compatDoPreserveInvalidJSON(t *testing.T, inputs map[string]interface{}, expectedOutcome string) {
	t.Helper()
	tenant, _ := inputs["tenant"].(string)

	db, mock, err := sqlmock.New(sqlmock.QueryMatcherOption(sqlmock.QueryMatcherRegexp))
	if err != nil {
		t.Fatalf("sqlmock.New: %v", err)
	}
	defer db.Close()

	e := &oceanbaseEngine{
		db:               db,
		dbName:           "test",
		engineName:       "oceanbase",
		tableExistsCache: map[string]bool{},
		vectorColCache:   map[string]bool{},
	}

	// Set up SELECT to return invalid JSON "{" as meta_fields value.
	mock.ExpectQuery("SELECT `meta_fields`").
		WillReturnRows(sqlmock.NewRows([]string{"meta_fields"}).AddRow([]byte("{")))

	callErr := e.DeleteMetadataKeys(context.Background(), "doc-1", "kb-1",
		[]string{"some_key"}, tenant)

	if expectedOutcome == "rejected" {
		if callErr == nil {
			t.Errorf("DeleteMetadataKeys with invalid JSON meta_fields: expected error (rejected), got nil (the malformed row may not be preserved)")
		}
	} else {
		if callErr != nil {
			t.Errorf("DeleteMetadataKeys: expected success, got error: %v", callErr)
		}
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("sqlmock expectations not met: %v", err)
		}
	}
}

// compatDoPushdown: test operator push-down safety via metadataFilterExpr.
func compatDoPushdown(t *testing.T, inputs map[string]interface{}, expectedOutcome string) {
	t.Helper()
	op, _ := inputs["op"].(string)

	// Build a metadata filtering condition using the comparison_operator from inputs.
	cond := map[string]interface{}{
		"conditions": []interface{}{
			map[string]interface{}{
				"name":                "author",
				"comparison_operator": op,
				"value":               "Alice",
			},
		},
	}

	result := metadataFilterExpr(cond)

	if expectedOutcome == "accepted" {
		if result == "" {
			t.Errorf("operator %q: expected push-down accepted (non-empty SQL), got empty string (push-down rejected)", op)
		}
	} else { // "rejected"
		if result != "" {
			t.Errorf("operator %q: expected push-down rejected (empty SQL), got %q", op, result)
		}
	}
}
