package oceanbase

import (
	"context"
	"testing"

	"github.com/DATA-DOG/go-sqlmock"
)

// compatCtx is the context used in compat-contract tests.
var compatCtx = context.Background()

// compatNewEngine builds an oceanbaseEngine over a sqlmock DB.
// File-unique prefix "compat" to avoid collision with seekdb-gating story.
func compatNewEngine(t *testing.T, engineType string) (*oceanbaseEngine, sqlmock.Sqlmock) {
	t.Helper()
	db, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New: %v", err)
	}
	t.Cleanup(func() { db.Close() })
	return &oceanbaseEngine{db: db, engineType: engineType}, mock
}

// TestCompatContract exercises the compat-contract behavioral cases.
func TestCompatContract(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			inputs := tc.Inputs
			expected := tc.Expected

			probe, _ := inputs["probe"].(string)

			expectedOutcome, _ := expected["expected_outcome"].(string)
			expectedTable, _ := expected["expected_table"].(string)
			expectedEncodedVector, _ := expected["expected_encoded_vector"].(string)

			switch probe {
			case "metadata_write":
				compatTestMetadataWrite(t, inputs, expectedOutcome, expectedTable)
			case "reject_identifier":
				compatTestRejectIdentifier(t, inputs, expectedOutcome)
			case "chunk_vector_encode":
				compatTestChunkVectorEncode(t, inputs, expectedOutcome, expectedEncodedVector)
			case "preserve_invalid_json":
				compatTestPreserveInvalidJSON(t, inputs, expectedOutcome)
			case "pushdown_safe":
				compatTestPushdownSafe(t, inputs, expectedOutcome)
			case "pushdown_unsafe":
				compatTestPushdownUnsafe(t, inputs, expectedOutcome)
			default:
				t.Fatalf("unknown probe: %q", probe)
			}
		})
	}
}

// compatTestMetadataWrite calls UpdateMetadata and checks the call succeeds and
// targets the expected physical table with compact JSON encoding.
func compatTestMetadataWrite(t *testing.T, inputs map[string]interface{}, expectedOutcome, expectedTable string) {
	t.Helper()
	tenant, _ := inputs["tenant"].(string)

	// Verify the physical table name (pure computation).
	gotTable := buildMetadataTableName(tenant)
	if expectedTable != "__skip__" && gotTable != expectedTable {
		t.Errorf("metadata table name: got %q, want %q", gotTable, expectedTable)
	}

	e, mock := compatNewEngine(t, "oceanbase")

	// Set up mock expectations for the happy path.
	// tableExists query returns true (table exists).
	mock.ExpectQuery("SELECT 1 FROM information_schema.tables").
		WithArgs(gotTable).
		WillReturnRows(sqlmock.NewRows([]string{"1"}).AddRow(1))
	// loadMetaFields returns no existing record (new document).
	mock.ExpectQuery("SELECT meta_fields FROM").
		WithArgs("doc-1", "kb-1").
		WillReturnRows(sqlmock.NewRows([]string{"meta_fields"}))
	// INSERT with compact JSON encoding.
	mock.ExpectExec("INSERT INTO").
		WithArgs("doc-1", "kb-1", `{"author":"Alice"}`).
		WillReturnResult(sqlmock.NewResult(1, 1))

	err := e.UpdateMetadata(compatCtx, "doc-1", "kb-1", map[string]interface{}{"author": "Alice"}, tenant)

	if expectedOutcome == "accepted" {
		if err != nil {
			t.Errorf("UpdateMetadata: expected success (accepted), got error: %v", err)
			return
		}
		if metErr := mock.ExpectationsWereMet(); metErr != nil {
			t.Errorf("sqlmock expectations not met (table=%q, JSON encoding may be wrong): %v", gotTable, metErr)
		}
	} else {
		if err == nil {
			t.Errorf("UpdateMetadata: expected rejection, but call succeeded")
		}
	}
}

// compatTestRejectIdentifier verifies that a tenant name with a backtick is rejected.
func compatTestRejectIdentifier(t *testing.T, inputs map[string]interface{}, expectedOutcome string) {
	t.Helper()
	tenant, _ := inputs["tenant"].(string)

	e, _ := compatNewEngine(t, "oceanbase")

	err := e.UpdateMetadata(compatCtx, "doc-1", "kb-1", map[string]interface{}{"author": "Alice"}, tenant)

	if expectedOutcome == "rejected" {
		if err == nil {
			t.Errorf("UpdateMetadata with tenant %q: expected rejection (error), but call succeeded", tenant)
		}
	} else {
		if err != nil {
			t.Errorf("UpdateMetadata with tenant %q: expected accepted, got error: %v", tenant, err)
		}
	}
}

// compatTestChunkVectorEncode verifies that a float vector stored through
// prepareChunkRow is encoded as the compact bracketed string the Python connector
// expects.
func compatTestChunkVectorEncode(t *testing.T, inputs map[string]interface{}, expectedOutcome, expectedEncodedVector string) {
	t.Helper()

	// Build vector from inputs.
	rawVec, _ := inputs["vector"].([]interface{})
	vec := make([]float64, len(rawVec))
	for i, v := range rawVec {
		vec[i] = v.(float64)
	}

	chunk := map[string]interface{}{
		"id":      "c1",
		"kb_id":   "kb-1",
		"q_3_vec": vec,
	}
	cols, vals := prepareChunkRow(chunk, "kb-1")

	// Find the q_3_vec column value.
	var encoded string
	for i, c := range cols {
		if c == "q_3_vec" {
			encoded, _ = vals[i].(string)
			break
		}
	}

	if expectedEncodedVector != "__skip__" {
		if encoded != expectedEncodedVector {
			t.Errorf("encoded vector: got %q, want %q", encoded, expectedEncodedVector)
		}
	}
	if expectedOutcome == "accepted" && encoded == "" {
		t.Errorf("vector encoding: expected non-empty result (accepted), got empty")
	}
}

// compatTestPreserveInvalidJSON verifies that DeleteMetadataKeys rejects a row
// with invalid JSON in meta_fields (single byte "{"), preserving the malformed
// legacy row rather than overwriting it.
func compatTestPreserveInvalidJSON(t *testing.T, inputs map[string]interface{}, expectedOutcome string) {
	t.Helper()
	tenant, _ := inputs["tenant"].(string)
	if tenant == "" {
		tenant = "tenant-1"
	}

	e, mock := compatNewEngine(t, "oceanbase")

	// loadMetaFields SELECT returns a row with invalid JSON "{".
	mock.ExpectQuery("SELECT meta_fields FROM").
		WithArgs("doc-1", "kb-1").
		WillReturnRows(sqlmock.NewRows([]string{"meta_fields"}).AddRow([]byte("{")))

	err := e.DeleteMetadataKeys(compatCtx, "doc-1", "kb-1", []string{"author"}, tenant)

	if expectedOutcome == "rejected" {
		if err == nil {
			t.Errorf("DeleteMetadataKeys with invalid JSON meta_fields: expected rejection, but call returned nil (success)")
		}
		// Verify no unexpected writes were issued beyond the expected SELECT.
		if metErr := mock.ExpectationsWereMet(); metErr != nil {
			t.Errorf("sqlmock: unexpected SQL after invalid JSON: %v", metErr)
		}
	} else {
		if err != nil {
			t.Errorf("DeleteMetadataKeys: expected accepted, got error: %v", err)
		}
	}
}

// compatTestPushdownSafe verifies that a condition with a safe operator is
// accepted for pushdown into JSON SQL. FilterDocIdsByMetaPushdown returns non-nil
// when pushdown is performed (accepted), nil when rejected (in-memory fallback).
func compatTestPushdownSafe(t *testing.T, inputs map[string]interface{}, expectedOutcome string) {
	t.Helper()
	op, _ := inputs["op"].(string)

	e, _ := compatNewEngine(t, "oceanbase")

	conditions := []map[string]interface{}{
		{"key": "author", "op": op, "value": []interface{}{"Alice"}},
	}

	result := e.FilterDocIdsByMetaPushdown(compatCtx, nil, []string{"kb-1"}, conditions, "AND")

	if expectedOutcome == "accepted" {
		if result == nil {
			t.Errorf("pushdown_safe (op=%q): FilterDocIdsByMetaPushdown returned nil (not pushed down), expected non-nil (accepted)", op)
		}
	} else {
		if result != nil {
			t.Errorf("pushdown_safe (op=%q): expected nil (rejected), got %v", op, result)
		}
	}
}

// compatTestPushdownUnsafe verifies that a condition with a negated/unsafe
// operator is rejected for pushdown. FilterDocIdsByMetaPushdown must return nil
// so the engine declines to emit an unsound predicate.
func compatTestPushdownUnsafe(t *testing.T, inputs map[string]interface{}, expectedOutcome string) {
	t.Helper()
	op, _ := inputs["op"].(string)

	e, _ := compatNewEngine(t, "oceanbase")

	conditions := []map[string]interface{}{
		{"key": "author", "op": op, "value": []interface{}{"Alice"}},
	}

	result := e.FilterDocIdsByMetaPushdown(compatCtx, nil, []string{"kb-1"}, conditions, "AND")

	if expectedOutcome == "rejected" {
		if result != nil {
			t.Errorf("pushdown_unsafe (op=%q): FilterDocIdsByMetaPushdown returned non-nil (pushed down), expected nil (rejected)", op)
		}
	} else {
		if result == nil {
			t.Errorf("pushdown_unsafe (op=%q): expected non-nil (accepted), got nil (rejected)", op)
		}
	}
}
