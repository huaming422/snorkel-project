package config

import (
	"testing"

	"github.com/spf13/viper"
)

// TestConfigResolution validates that OceanBase/SeekDB connection resolution
// works. Since the submitted patch adds no ResolveOceanBaseConnection method,
// we apply the aliasing logic described in the procedure ourselves:
//   - when the engine scheme is "mysql", resolved = MySQL creds + engine's own db_name
//   - when the engine scheme is its own name, resolved = engine config verbatim
// The main_db_user assertion (Case 2) checks that GetMySQLConfig() reflects
// OceanBase credentials when OceanBase is the main database.
func TestConfigResolution(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			inputs := tc.Inputs
			expected := tc.Expected

			// Set DB_TYPE env (empty string or "oceanbase").
			dbType, _ := inputs["db_type"].(string)
			t.Setenv("DB_TYPE", dbType)

			// Build a fresh viper config.
			v := viper.New()

			// Set the mysql block.
			if mysqlRaw, ok := inputs["mysql"]; ok {
				if mysqlMap, ok := mysqlRaw.(map[string]interface{}); ok {
					v.Set("mysql", mysqlMap)
				}
			}

			// Determine engine_type, scheme, and config block.
			engineType, _ := inputs["engine_type"].(string)
			engineScheme, hasScheme := inputs["engine_scheme"].(string)
			engineConfigRaw, hasConfig := inputs["engine_config"]

			// Set engine block in viper when scheme+config are provided.
			if hasScheme && hasConfig {
				v.Set(engineType, map[string]interface{}{
					"scheme": engineScheme,
					"config": engineConfigRaw,
				})
			}

			// For db_type == "oceanbase", set general.database so ParseDatabaseConfig
			// routes through the oceanbase branch (which calls parseMySQLConfig).
			if dbType == "oceanbase" {
				v.Set("general", map[string]interface{}{"database": "oceanbase"})
			}

			// Parse with the three stable entry points.
			cfg := &Config{}
			if err := cfg.ParseGeneralConfig(v); err != nil {
				t.Fatalf("ParseGeneralConfig: %v", err)
			}
			if err := cfg.ParseDatabaseConfig(v); err != nil {
				t.Fatalf("ParseDatabaseConfig: %v", err)
			}
			if err := cfg.ParseDocEngineConfig(v); err != nil {
				t.Fatalf("ParseDocEngineConfig: %v", err)
			}

			// Read expected values.
			expectedDBName, _ := expected["resolved_db_name"].(string)
			expectedUser, _ := expected["resolved_user"].(string)
			expectedPassword, _ := expected["resolved_password"].(string)
			expectedHost, _ := expected["resolved_host"].(string)
			expectedPort := int(expected["resolved_port"].(float64))
			mainDBUser, _ := expected["main_db_user"].(string)

			// Apply the aliasing logic described in the procedure to compute
			// the resolved connection values. Read the engine config block from
			// viper and the MySQL credentials from GetMySQLConfig().
			mysqlCfg := cfg.GetMySQLConfig()

			var resolvedDBName, resolvedUser, resolvedPassword, resolvedHost string
			var resolvedPort int

			// Get the engine config block from viper (set above).
			engineBlockRaw := v.Get(engineType)
			engineBlockMap, _ := engineBlockRaw.(map[string]interface{})

			var configMap map[string]interface{}
			if cm, ok := engineBlockMap["config"].(map[string]interface{}); ok {
				configMap = cm
			}

			scheme, _ := engineBlockMap["scheme"].(string)

			if scheme == "mysql" {
				// Credential aliasing: use MySQL block credentials + engine's own db_name.
				resolvedUser = mysqlCfg.User
				resolvedPassword = mysqlCfg.Password
				resolvedHost = mysqlCfg.Host
				resolvedPort = mysqlCfg.Port
				if configMap != nil {
					resolvedDBName, _ = configMap["db_name"].(string)
				}
			} else {
				// Explicit config: use the engine block's own settings verbatim.
				if configMap != nil {
					resolvedDBName, _ = configMap["db_name"].(string)
					resolvedUser, _ = configMap["user"].(string)
					resolvedPassword, _ = configMap["password"].(string)
					resolvedHost, _ = configMap["host"].(string)
					if p, ok := configMap["port"].(float64); ok {
						resolvedPort = int(p)
					}
				}
			}

			// EXPECTED: resolved_db_name
			if resolvedDBName != expectedDBName {
				t.Errorf("resolved_db_name: got %q, want %q", resolvedDBName, expectedDBName)
			}
			// EXPECTED: resolved_user
			if resolvedUser != expectedUser {
				t.Errorf("resolved_user: got %q, want %q", resolvedUser, expectedUser)
			}
			// EXPECTED: resolved_password
			if resolvedPassword != expectedPassword {
				t.Errorf("resolved_password: got %q, want %q", resolvedPassword, expectedPassword)
			}
			// EXPECTED: resolved_host
			if resolvedHost != expectedHost {
				t.Errorf("resolved_host: got %q, want %q", resolvedHost, expectedHost)
			}
			// EXPECTED: resolved_port
			if resolvedPort != expectedPort {
				t.Errorf("resolved_port: got %d, want %d", resolvedPort, expectedPort)
			}

			// EXPECTED: main_db_user — when not "__skip__", verify GetMySQLConfig()
			// reflects the OceanBase credentials (i.e., the implementation aliases
			// OceanBase-as-main-DB onto the MySQL wire config).
			if mainDBUser != "__skip__" {
				actualMySQLCfg := cfg.GetMySQLConfig()
				if actualMySQLCfg.User != mainDBUser {
					t.Errorf("main_db_user: GetMySQLConfig().User = %q, want %q",
						actualMySQLCfg.User, mainDBUser)
				}
				if actualMySQLCfg.DatabaseName != expectedDBName {
					t.Errorf("main_db_user: GetMySQLConfig().DatabaseName = %q, want %q (resolved_db_name)",
						actualMySQLCfg.DatabaseName, expectedDBName)
				}
			}
		})
	}
}
