package chunk

import (
	"reflect"
	"testing"

	"ragflow/internal/engine/types"
)

// TestVectorHydration verifies that FetchChunkVectors performs an explicit
// lookup for OceanBase-backed engines (not skipping), while Infinity still skips.
//
// Uses the pre-existing mockVectorFetcher and bg from vector_test.go.
// Prefixes helpers with "vh" to avoid collisions.
func TestVectorHydration(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			inputs := tc.Inputs
			expected := tc.Expected

			engineType, _ := inputs["engine_type"].(string)
			expectedSearch, _ := expected["expected_search"].(string)

			// Build expected vector from expected["expected_vector"]
			rawExpVec, _ := expected["expected_vector"].([]interface{})
			expectedVec := make([]float64, len(rawExpVec))
			for i, v := range rawExpVec {
				expectedVec[i] = v.(float64)
			}

			// Build the mock.
			mock := &mockVectorFetcher{engineType: engineType}

			// If this engine should search, seed the mock results.
			if expectedSearch == "searched" {
				// Build the input vector from inputs["vector"]
				rawVec, _ := inputs["vector"].([]interface{})
				vecForChunk := make([]interface{}, len(rawVec))
				for i, v := range rawVec {
					vecForChunk[i] = v.(float64)
				}

				mock.searchResults = map[string]*types.SearchResult{
					"ragflow_t1": {
						Chunks: []map[string]interface{}{
							{
								"id":      "c1",
								"q_3_vec": vecForChunk,
							},
						},
					},
				}
			}

			result := FetchChunkVectors(bg, mock, []string{"c1"}, []string{"t1"}, []string{"kb1"}, 3)

			// EXPECTED: expected_search
			if expectedSearch == "searched" {
				if !reflect.DeepEqual(mock.searchCalled, []string{"ragflow_t1"}) {
					t.Errorf("expected_search: searchCalled = %v, want [\"ragflow_t1\"]", mock.searchCalled)
				}
			} else {
				// "skipped"
				if len(mock.searchCalled) != 0 {
					t.Errorf("expected_search: searchCalled = %v, want empty (skipped)", mock.searchCalled)
				}
			}

			// EXPECTED: expected_vector
			got, ok := result["c1"]
			if !ok {
				t.Fatalf("result[\"c1\"] not found; result = %v", result)
			}
			if !reflect.DeepEqual(got, expectedVec) {
				t.Errorf("expected_vector: result[\"c1\"] = %v, want %v", got, expectedVec)
			}
		})
	}
}
