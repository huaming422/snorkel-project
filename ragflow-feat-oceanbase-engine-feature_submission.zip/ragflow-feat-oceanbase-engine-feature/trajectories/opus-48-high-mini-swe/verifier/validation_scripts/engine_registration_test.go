package engine_test

import (
	"testing"

	"ragflow/internal/engine"
)

// erStandin is a minimal stand-in for DocEngine that returns a configurable
// type name. Other methods are never called. File-unique name "er" to avoid
// collision with other stories that also target the engine package.
type erStandin struct {
	engine.DocEngine // embedded interface — satisfies other methods; never called here
	name             string
}

func (s erStandin) GetType() string { return s.name }

// erIsOceanBaseFamily returns whether engineName belongs to the OceanBase/SeekDB
// family. The submitted patch adds no IsOceanBaseFamily-equivalent exported
// predicate (the detection is inline in switch cases in global.go and the
// service layer). Since no such function exists, this helper returns false for
// all inputs, causing expected_family == "oceanbase-family" cases to fail,
// which correctly flags the missing exported predicate.
func erIsOceanBaseFamily(name string) bool {
	// If engine.IsOceanBaseFamily existed, we would call it here:
	//   return engine.IsOceanBaseFamily(name)
	// It does not, so return false to surface the missing feature.
	return false
}

// TestEngineRegistration verifies that the OceanBase/SeekDB family predicate
// correctly identifies engines in-family vs. out-of-family, and that GetType()
// returns the correct engine type string.
func TestEngineRegistration(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			inputs := tc.Inputs
			expected := tc.Expected

			engineName, _ := inputs["engine_name"].(string)
			expectedResolvedType, _ := expected["expected_resolved_type"].(string)
			expectedFamily, _ := expected["expected_family"].(string)

			standin := erStandin{name: engineName}

			// EXPECTED: expected_resolved_type — standin.GetType() == expected["expected_resolved_type"]
			if got := standin.GetType(); got != expectedResolvedType {
				t.Errorf("GetType(): got %q, want %q", got, expectedResolvedType)
			}

			// EXPECTED: expected_family — the family predicate result.
			// erIsOceanBaseFamily returns false because no exported predicate exists
			// in the submitted patch. The oceanbase/seekdb cases will therefore fail,
			// correctly flagging the missing feature.
			inFamily := erIsOceanBaseFamily(engineName)

			if expectedFamily == "oceanbase-family" {
				if !inFamily {
					t.Errorf("IsOceanBaseFamily(%q) = false, want true (oceanbase-family); "+
						"the submitted patch does not export an IsOceanBaseFamily predicate", engineName)
				}
			} else {
				// expectedFamily == "other"
				if inFamily {
					t.Errorf("IsOceanBaseFamily(%q) = true, want false (other)", engineName)
				}
			}
		})
	}
}
