package oceanbase

import (
	"context"
	"testing"

	"github.com/DATA-DOG/go-sqlmock"
)

// idxgateCtx is the context used in seekdb-index-gating tests.
var idxgateCtx = context.Background()

// idxgateNewEngine builds an oceanbaseEngine over a sqlmock DB with the given
// engine type. File-unique prefix "idxgate" to avoid collision with compat_contract.
func idxgateNewEngine(t *testing.T, engineType string) (*oceanbaseEngine, sqlmock.Sqlmock) {
	t.Helper()
	db, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New: %v", err)
	}
	t.Cleanup(func() { db.Close() })
	e := &oceanbaseEngine{
		db:         db,
		engineType: engineType,
		isSeekDB:   engineType == "seekdb",
	}
	return e, mock
}

// TestSeekdbIndexGating verifies that:
//   - A SeekDB engine with a version comment containing "seekdb" (new enough)
//     enables refresh and issues the refresh command on write.
//   - A SeekDB engine with a version comment NOT containing "seekdb" (too old)
//     disables refresh and issues no refresh command.
//   - An OceanBase engine never issues a refresh command.
func TestSeekdbIndexGating(t *testing.T) {
	// Ensure OB_SUPPORTS_REFRESH override is not set (it would bypass version detection).
	t.Setenv("OB_SUPPORTS_REFRESH", "")

	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			inputs := tc.Inputs
			expected := tc.Expected

			engineType, _ := inputs["engine_type"].(string)
			versionScenario, _ := inputs["version_scenario"].(string)
			expectedRefresh, _ := expected["expected_refresh"].(string)

			e, mock := idxgateNewEngine(t, engineType)

			// Step (a): run the version-detection step to set supportsRefresh.
			// The submitted code checks @@version_comment for the string "seekdb"
			// (case-insensitive). We drive it with a sqlmock-returned version string.
			switch versionScenario {
			case "new_enough":
				// SeekDB at or above threshold: version comment contains "seekdb".
				// The code: strings.Contains(strings.ToLower(comment), "seekdb")
				mock.ExpectQuery(`SELECT @@version_comment`).
					WillReturnRows(sqlmock.NewRows([]string{"@@version_comment"}).
						AddRow("SeekDB-server 2.0.1"))
				e.supportsRefresh = e.detectRefreshSupport(idxgateCtx)
			case "too_old":
				// SeekDB below threshold: version comment does NOT contain "seekdb".
				mock.ExpectQuery(`SELECT @@version_comment`).
					WillReturnRows(sqlmock.NewRows([]string{"@@version_comment"}).
						AddRow("MySQL 5.7.32"))
				e.supportsRefresh = e.detectRefreshSupport(idxgateCtx)
			case "not_applicable":
				// OceanBase: version detection does not apply (isSeekDB=false in production).
				// Drive the same decision step with a non-seekdb version to confirm
				// refresh is left disabled.
				mock.ExpectQuery(`SELECT @@version_comment`).
					WillReturnRows(sqlmock.NewRows([]string{"@@version_comment"}).
						AddRow("OceanBase 4.3.0"))
				e.supportsRefresh = e.detectRefreshSupport(idxgateCtx)
			}

			// Step (b): set up mock for refresh step and invoke waitRefresh.
			tableName := "ragflow_t1"
			if expectedRefresh == "refreshes" {
				// The code issues: CALL dbms_vector.refresh_index('tableName')
				mock.ExpectExec(`dbms_vector.refresh_index`).
					WillReturnResult(sqlmock.NewResult(0, 0))
			}
			// For "no-refresh", register NO exec expectation —
			// sqlmock reports an error if any unexpected command is issued.

			e.waitRefresh(idxgateCtx, tableName)

			if metErr := mock.ExpectationsWereMet(); metErr != nil {
				if expectedRefresh == "refreshes" {
					t.Errorf("expected refresh command was not issued: %v", metErr)
				} else {
					t.Errorf("unexpected SQL was issued (no-refresh expected): %v", metErr)
				}
			}
		})
	}
}
