//! Behavioral verifier for `dalfox-fix-selflink-encoded-scheme`.
//!
//! Drives the PUBLIC, reference-change-UNCHANGED reflection entry point
//! `dalfox::scanning::check_reflection::check_reflection_with_response` against a
//! local axum mock and asserts on its decision: the function injects the EXACT
//! payload in one HTTP request, classifies the reflection, runs the safe-context
//! suppression gate chain, and returns `Some(ReflectionKind)` when the
//! reflection is reported or `None` when it is suppressed. This is the one
//! interface at which the behavior under test (suppress-vs-report of a
//! reflection trapped in a URL value) is directly observable, with no built-in
//! payload substitution and no DOM re-verification in the path.
//!
//! DECOUPLING (why this cannot couple to the reference change's factoring):
//!   * It imports ONLY pre-existing public API —
//!     `check_reflection_with_response`, `ReflectionKind`, `Location`, `Param`,
//!     `parse_target`, `ScanArgs`. It never names any of the private reflection
//!     helpers the reference change adds or edits (they are private to the
//!     reflection module and invisible to a `tests/` integration crate anyway).
//!     Any behaviorally-correct change — partition, per-occurrence check,
//!     byte-level classify, inlined or extracted, however it renames things —
//!     passes identically, because the assertions observe only the
//!     reported/suppressed decision.
//!   * Each case injects ONE reference payload through the stable public
//!     signature; the returned decision is a pure function of the mock's
//!     reflection shape. The payloads are the issue-#1153 residual repro shapes
//!     the reference change itself verified.
//!   * Assertions use `is_none()` (suppressed) / `is_some()` (reported), never a
//!     private field or a compile-time shape, so behavior before vs after the
//!     change is told apart purely by BEHAVIOR.
//!
//! The four cases map 1:1 to the four behavioral `[[test_criteria]]`:
//!   1. (suppress) encoded scheme reflected percent-encoded in a self-link
//!      query is NOT reported (the residual FP). Before: reported. After:
//!      suppressed.
//!   2. (keep) encoded scheme at the href VALUE START is still reported
//!      (executable; guards against over-suppression).
//!   3. (keep) a raw break-out char / tag reflected LITERALLY in a URL
//!      attribute is still reported (guards against a false-negative regression).
//!   4. (keep) ordinary unescaped HTML-body reflection is still reported
//!      (the change did not broadly disable detection).

use std::collections::HashMap;
use std::net::{Ipv4Addr, SocketAddr};
use std::time::Duration;

use axum::{
    Router,
    extract::Query,
    response::{Html, IntoResponse},
    routing::get,
};

use dalfox::cmd::scan::ScanArgs;
use dalfox::parameter_analysis::{Location, Param};
use dalfox::scanning::check_reflection::{ReflectionKind, check_reflection_with_response};
use dalfox::target_parser::parse_target;

// ===========================================================================
// Mock handlers — one reflection shape per behavioral case
// ===========================================================================

/// Case 1 (FP): reflect the injected param PERCENT-ENCODED inside the query of
/// both a canonical `<link>` and an `<a>` self-link. The decoded payload is an
/// entity-encoded, keyword-DOUBLED `javascript:` WAF mutation whose HTML-decoded
/// form carries a `"`, but that `"` only ever appears as `%22` here — never
/// literally — so the reflection is inert. Models the reference repro
/// (`<link rel="canonical" href="/About.aspx?any={enc}">…`).
async fn self_link_encoded(Query(p): Query<HashMap<String, String>>) -> impl IntoResponse {
    let any = p.get("any").cloned().unwrap_or_default();
    let enc = urlencoding::encode(&any);
    Html(format!(
        r#"<!DOCTYPE html><html><head><title>About</title>
<link rel="canonical" href="/About.aspx?any={enc}"></head>
<body><a href="/About.aspx?any={enc}">home</a></body></html>"#
    ))
}

/// Case 2 (recall guard): reflect the injected param VERBATIM at the START of an
/// `href` value. An entity-encoded scheme here decodes to an executable
/// `javascript:` URL in the browser, so it must stay reported.
async fn href_value_start(Query(p): Query<HashMap<String, String>>) -> impl IntoResponse {
    let any = p.get("any").cloned().unwrap_or_default();
    Html(format!(
        r#"<!DOCTYPE html><html><body><a href="{any}">go</a></body></html>"#
    ))
}

/// Case 3 (recall guard): reflect the injected param LITERALLY inside a quoted
/// `href` value. A raw break-out character (a real `"` / a `"><img …>` tag) can
/// close the attribute and open a tag, so it must stay reported.
async fn href_literal_breakout(Query(p): Query<HashMap<String, String>>) -> impl IntoResponse {
    let any = p.get("any").cloned().unwrap_or_default();
    Html(format!(
        r#"<!DOCTYPE html><html><body><a href="/p?x={any}">x</a></body></html>"#
    ))
}

/// Case 4 (ordinary detection): reflect the injected param VERBATIM in HTML body
/// text with no escaping — a textbook reflected-XSS context.
async fn body_raw(Query(p): Query<HashMap<String, String>>) -> impl IntoResponse {
    let any = p.get("any").cloned().unwrap_or_default();
    Html(format!(
        r#"<!DOCTYPE html><html><body><p>You searched for: {any}</p></body></html>"#
    ))
}

// ===========================================================================
// Server
// ===========================================================================

async fn start_test_server() -> SocketAddr {
    let app = Router::new()
        .route("/self-link-encoded", get(self_link_encoded))
        .route("/href-value-start", get(href_value_start))
        .route("/href-literal", get(href_literal_breakout))
        .route("/body-raw", get(body_raw));

    let listener = tokio::net::TcpListener::bind((Ipv4Addr::LOCALHOST, 0))
        .await
        .expect("bind listener");
    let addr = listener.local_addr().unwrap();

    tokio::spawn(async move {
        axum::serve(listener, app)
            .with_graceful_shutdown(async {
                tokio::time::sleep(Duration::from_secs(300)).await;
            })
            .await
            .ok();
    });

    tokio::time::sleep(Duration::from_millis(50)).await;
    addr
}

// ===========================================================================
// Reflection driver
// ===========================================================================

/// A query `Param` named `any`, seeded with the same value that appears in the
/// target URL query. Field roster transcribed verbatim from the repo's own
/// `src/scanning/check_reflection/tests.rs::make_param()` (adjusted only for the
/// param name/value, which are harness-owned fixture inputs).
fn make_param() -> Param {
    Param {
        name: "any".to_string(),
        value: "test".to_string(),
        location: Location::Query,
        injection_context: None,
        valid_specials: None,
        invalid_specials: None,
        pre_encoding: None,
        pre_encoding_pipeline: None,
        wire_name: None,
        form_action_url: None,
        form_origin_url: None,
        framework_sink: None,
        escaped_specials: None,
        js_breakout: None,
    }
}

/// Full `ScanArgs`, transcribed verbatim from the repo's own
/// `src/scanning/check_reflection/tests.rs::default_scan_args()` so the field
/// roster is guaranteed to match the struct at this commit. `skip_xss_scanning`
/// stays `false` (otherwise the entry point returns `None` before injecting);
/// everything else is irrelevant to a single `check_reflection_with_response`
/// call (no mining, discovery, worker pool, or encoder path is reached).
fn default_scan_args() -> ScanArgs {
    ScanArgs {
        insecure: Some(true),
        detect_outdated_libs: false,
        input_type: "auto".to_string(),
        format: "json".to_string(),
        targets: vec![],
        param: vec![],
        data: None,
        headers: vec![],
        cookies: vec![],
        method: "GET".to_string(),
        user_agent: None,
        cookie_from_raw: None,
        include_url: vec![],
        exclude_url: vec![],
        ignore_param: vec![],
        out_of_scope: vec![],
        out_of_scope_file: None,
        mining_dict_word: None,
        skip_mining: false,
        skip_mining_dict: false,
        skip_mining_dom: false,
        only_discovery: false,
        skip_discovery: false,
        skip_reflection_header: false,
        skip_reflection_cookie: false,
        skip_reflection_path: false,
        timeout: 10,
        scan_timeout: 0,
        delay: 0,
        proxy: None,
        follow_redirects: false,
        ignore_return: vec![],
        output: None,
        include_request: false,
        include_response: false,
        include_all: false,
        no_color: false,
        silence: true,
        dry_run: false,
        stream_findings: false,
        poc_type: "plain".to_string(),
        limit: None,
        limit_result_type: "all".to_string(),
        only_poc: vec![],
        workers: 10,
        max_concurrent_targets: 10,
        max_targets_per_host: 100,
        encoders: vec!["url".to_string(), "html".to_string(), "base64".to_string()],
        custom_blind_xss_payload: None,
        blind_callback_url: None,
        oob: Default::default(),
        custom_payload: None,
        only_custom_payload: false,
        inject_marker: None,
        custom_alert_value: "1".to_string(),
        custom_alert_type: "none".to_string(),
        skip_xss_scanning: false,
        max_payloads_per_param: 0,
        deep_scan: false,
        sxss: false,
        sxss_url: None,
        sxss_method: "GET".to_string(),
        sxss_retries: 3,
        skip_ast_analysis: false,
        analyze_external_js: false,
        hpp: false,
        waf_bypass: "auto".to_string(),
        skip_waf_probe: false,
        force_waf: None,
        waf_evasion: false,
        rate_limit: 0,
        retries: 0,
        retry_delay: 1000,
        waf_min_confidence: 0.0,
        remote_payloads: vec![],
        remote_wordlists: vec![],
    }
}

/// Start the mock, inject `payload` at the `any` query param of `path`, run the
/// public reflection check, and return its decision: `Some(kind)` when the
/// reflection is reported, `None` when it is suppressed.
async fn reflect(path: &str, payload: &str) -> Option<ReflectionKind> {
    let addr = start_test_server().await;
    let url = format!("http://{}:{}{}?any=test", addr.ip(), addr.port(), path);
    let target = parse_target(&url).expect("valid target");
    let param = make_param();
    let args = default_scan_args();

    let (kind, _body) =
        check_reflection_with_response(None, &target, &param, payload, &args).await;
    kind
}

// Reference payloads — the issue-#1153 residual repro shapes the reference
// change itself verified (see provenance.md: every literal is stable-fact).
//
// Entity-encoded, keyword-obfuscated `javasscriptcript:a["b"]` — a keyword-
// doubling WAF-evasion mutation of a `javascript:` scheme (named verbatim in the
// reference change's own doc comment: "`javasscriptcript:top["al"+"\ert"](1)`").
// Its HTML-decoded form carries a raw `"`, but here it only ever appears
// percent-encoded.
//
// WHY the doubled mutation and not the literal `javascript:a["b"]`: a payload
// whose decoded form starts with a *real* `javascript:` is intercepted by an
// EARLIER suppression gate (the dangerous-scheme-inert gate) in BOTH the pre-fix
// and post-fix code, which masks the trapping-gate change at the public
// interface (gate-chain masking — the reference change's test warns of exactly
// this and therefore drives the private helper directly). The keyword-DOUBLED
// mutation does not literally start with `javascript:`, so that earlier gate
// does not recognize it; only the trapping gate this change fixes decides it, so
// the behavior is observable through `check_reflection_with_response`.
const ENCODED_SCHEME_WITH_QUOTE: &str =
    "&#x6a;&#x61;&#x76;&#x61;&#x73;&#x73;&#x63;&#x72;&#x69;&#x70;&#x74;&#x63;&#x72;&#x69;&#x70;&#x74;&#x3a;&#x61;&#x5b;&#x22;&#x62;&#x22;&#x5d;";
// A SECOND, structurally-different residual-FP shape for the same suppress case,
// so passing cannot be bought by special-casing the exact bytes of the first
// payload. Every axis differs from `ENCODED_SCHEME_WITH_QUOTE`:
//   * DECIMAL numeric entities (`&#NN;`) rather than HEX (`&#xNN;`);
//   * a `vbscript:` keyword-doubled mutation (`vbscriptcript:`) rather than a
//     `javascript:` one — a different dangerous scheme family;
//   * a SINGLE-quote (`'`) break-out character rather than a double quote.
// It shares only the behavioral property under test: its HTML-decoded form
// (`vbscriptcript:a['b']`) carries a raw break-out byte, but that byte only ever
// appears percent-encoded in the link's query, so the reflection is inert. Like
// the first payload, the doubled keyword does not literally start with a
// dangerous scheme, so the earlier dangerous-scheme-inert gate does not claim
// it; only the trapping gate this change fixes decides it — observable through
// `check_reflection_with_response`.
const ENCODED_SCHEME_WITH_QUOTE_ALT: &str =
    "&#118;&#98;&#115;&#99;&#114;&#105;&#112;&#116;&#99;&#114;&#105;&#112;&#116;&#58;&#97;&#91;&#39;&#98;&#39;&#93;";
// Entity-encoded `javascript:alert(1)` — decodes to an executable scheme.
const ENCODED_SCHEME_EXECUTABLE: &str =
    "&#x6a;&#x61;&#x76;&#x61;&#x73;&#x63;&#x72;&#x69;&#x70;&#x74;&#x3a;&#x61;&#x6c;&#x65;&#x72;&#x74;&#x28;&#x31;&#x29;";
// Raw tag break-out reflected literally.
const LITERAL_TAG_BREAKOUT: &str = "\"><img src=x onerror=alert(1)>";
// Ordinary reflected-XSS vector for an unescaped HTML body context.
const ORDINARY_HTML_PAYLOAD: &str = "<img src=x onerror=alert(1)>";

// ===========================================================================
// Behavioral cases
// ===========================================================================

/// Criterion 1 (suppress): an entity-encoded, keyword-doubled dangerous-scheme
/// WAF mutation whose decoded form carries a raw break-out character, reflected
/// percent-encoded inside a self-/canonical-link query, must NOT be reported.
/// The break-out char is inert (only ever appears percent-encoded), so reporting
/// it is a false positive. Before the change: reported (`Some`). After the
/// change: suppressed (`None`).
///
/// Two structurally-different residual-FP shapes are asserted (see the payload
/// constants): the behavior under test is literal-vs-encoded reflection, not a
/// single fixed byte sequence, so a fix that merely special-cases one payload's
/// exact bytes fails the other. A genuine literal-vs-encoded distinction
/// suppresses both.
#[tokio::test]
async fn encoded_scheme_in_self_link_query_is_not_reported() {
    let kind = reflect("/self-link-encoded", ENCODED_SCHEME_WITH_QUOTE).await;
    assert!(
        kind.is_none(),
        "encoded keyword-doubled javascript: mutation (hex entities, double-quote \
         break-out) reflected percent-encoded in a self-link query is inert and must \
         be suppressed, but it was reported as {kind:?}"
    );

    let kind_alt = reflect("/self-link-encoded", ENCODED_SCHEME_WITH_QUOTE_ALT).await;
    assert!(
        kind_alt.is_none(),
        "a structurally-different encoded keyword-doubled vbscript: mutation (decimal \
         entities, single-quote break-out) reflected percent-encoded in a self-link \
         query is equally inert and must be suppressed, but it was reported as \
         {kind_alt:?}"
    );
}

/// Criterion 2 (keep): an entity-encoded scheme reflected at the href
/// VALUE START decodes to an executable `javascript:` URL and must stay
/// reported. Guards against an over-suppressing "blanket URL-attribute" change.
#[tokio::test]
async fn encoded_scheme_at_href_value_start_is_reported() {
    let kind = reflect("/href-value-start", ENCODED_SCHEME_EXECUTABLE).await;
    assert!(
        kind.is_some(),
        "encoded scheme at the href value start is executable and must stay reported, \
         but it was suppressed"
    );
}

/// Criterion 3 (keep): a raw break-out character reflected LITERALLY in
/// a quoted URL attribute can close the attribute / open a tag and must stay
/// reported. Guards against a false-negative regression.
#[tokio::test]
async fn literal_breakout_in_url_attribute_is_reported() {
    let kind = reflect("/href-literal", LITERAL_TAG_BREAKOUT).await;
    assert!(
        kind.is_some(),
        "a literally-reflected tag break-out in a URL attribute must stay reported, \
         but it was suppressed"
    );
}

/// Criterion 4 (keep): ordinary unescaped reflection in HTML body
/// context must still be reported — the change did not broadly disable detection.
#[tokio::test]
async fn ordinary_html_body_reflection_is_reported() {
    let kind = reflect("/body-raw", ORDINARY_HTML_PAYLOAD).await;
    assert!(
        kind.is_some(),
        "ordinary unescaped HTML-body reflection must still be reported, \
         but it was suppressed"
    );
}
