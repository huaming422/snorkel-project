#!/usr/bin/env bash
# Pre-warm the dalfox test build so the behavioral verifier doesn't pay the
# full cold compile. The bug + fix live entirely in the dalfox crate
# (src/scanning/check_reflection.rs), and the verifier drives the public scan
# entry point (dalfox::cmd::scan::run_scan) from an injected integration test
# under tests/, so the lib + its dev-dependencies (axum, tokio, serde_json)
# and the existing test targets need to be compiled, not a fresh download.
#
# Offline-first: the image baked the full dependency closure at the base commit
# with the cargo registry/cache warm, so `--locked --offline` must succeed with
# no network. The verifier phase runs with network available, so if for any
# reason a dependency is missing we fall back to an online fetch and log it
# loudly rather than failing silently.
set -euo pipefail

cd /repo/dalfox

# Compile the dalfox lib + all test targets (including dev-deps) without
# running anything. The verifier injects its own test file under tests/ and
# reuses this warm target/.
if ! cargo test --locked --offline --no-run > /tmp/dalfox_test_setup.log 2>&1; then
    echo "[test-setup] offline build failed; retrying with network (logging fallback)" >&2
    tail -n 80 /tmp/dalfox_test_setup.log >&2 || true
    cargo fetch --locked
    cargo test --locked --no-run
fi

ls -la "${CARGO_TARGET_DIR:-/opt/cache/cargo-target}/debug/" | head -n 5
