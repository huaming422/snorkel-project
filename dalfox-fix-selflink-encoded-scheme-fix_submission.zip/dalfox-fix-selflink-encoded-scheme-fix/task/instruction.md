## Task

operators running scans against real apps keep flagging the same complaint: dalfox marks a parameter as a reflected `[R]` finding, they open the hit to confirm it, and the reflection turns out to be dead — nothing fires, nothing is actually injectable. it's noise dressed up as a finding.

the shape that keeps surfacing is a self-referential link. the scanned page echoes the request parameter back into the query string of a url-valued attribute — a canonical or self link along the lines of `<link rel="canonical" href="/page?...">` or `<a href="/page?...">` that carries the parameter through in its `href`. hand-triage on those says plainly: not exploitable. but dalfox still calls them `[R]`.

this bites hardest on asp.net-style targets and gets worse with waf-evasion payloads on; operators wade through piles of these phantoms and quietly stop trusting the output.

dig in and figure out why this particular reflection is inert while look-alike reflections genuinely aren't. kill the false positive, but don't buy it back as a false negative: real exploitable reflections of a similar shape still need to fire, and ordinary reflected-xss detection has to keep behaving exactly as it does now. keep it surgical, leave the public surface and the existing tests intact.
