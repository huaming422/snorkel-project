## Task

operators are reporting that some `bd` settings just don't stick. `bd` keeps per-workspace configuration in a git-tracked file, `.beads/config.yaml`, and a few of those settings are addressed with dotted keys, like `sync.remote` (the sync remote URL) and `dolt.host`.

the symptom: after `bd` records a value for one of these dotted keys, reading the same key back returns nothing, as if it had never been set, and commands that rely on that value behave as though it is unset. it's worst in a brand-new or freshly initialized workspace, where `.beads/config.yaml` starts out empty or comments only, and once a file lands in the bad state it stays broken. unsetting one of these keys is no better: the command reports success, but the setting is still in effect, so a sync remote you asked `bd` to forget keeps getting used.

dig into the configuration read / write / unset path and fix it. don't reshape or reformat parts of `.beads/config.yaml` you weren't asked to touch, since the file is git-tracked and may be shared with other tools.
