#!/usr/bin/env bash
# All required deps are baked into the image at build time (§1.5 dependency
# closure): Go 1.26.10, libicu-dev, build-essential, the warmed Go module +
# build cache under /opt/cache, and the full test tree compiled at the base
# commit. The fix adds only Go stdlib imports (crypto/sha256, encoding/hex,
# slices, net/url), with no new module and no go.mod/go.sum change, so there is
# nothing to install at verifier time. Kept as an explicit no-op so the
# offline fold (gate Check 3) has a script to source with the network cut.
set -euo pipefail
echo "[test-setup] no-op for beads-fix-github-push-dedup (deps baked into image)"
