"""Behavioral verifiers for the catalog regenerated-value contract.

These checks run under the shared verifier interpreter (``VERIFIER_PYTHON`` /
``/opt/tooling/venv``). That interpreter is deliberately stdlib-only for catalog
purposes — it has no YAML/jsonschema — so this module never imports repository
Python. Instead it drives the real toolchain the same way a maintainer would:

  * it copies the checked-out tree into a scratch workspace,
  * mutates sources or the embedded payload there,
  * re-runs the catalog generator with the repo's own Python, and
  * exercises Go behavior with ``go test`` on exported, pre-existing interfaces
    (``catalog.BuiltIn().Digest()``, ``(*EffectiveRegistry).Digest()``, and the
    dashboard contract test).

Why a Python orchestrator instead of a plain injected ``*_test.go``: both
fail_to_pass properties are *derivation* properties — a value is correct only if
it MOVES when its upstream source changes. Proving "it moves" requires editing a
source and rebuilding/regenerating, which a single compiled Go test cannot do to
its own package. The orchestration (copy, edit, regenerate, run) is the test.

No check keys on any name the fix is free to choose. The three coordinated moves
in the reference change are reached only through:
  * the exported ``BuiltIn``/``Digest``/``Compile`` surface and the embedded
    payload constant the generator has always emitted (Check A),
  * the package's own dashboard contract test, run after a real source edit
    (Check B),
  * the generated public projection's per-asset verification field (Check C).
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

# ── Repository layout (grade-time container) ────────────────────────────────
# The runner exports REPO_NAME; the checkout lives at /repo/<REPO_NAME>.
REPO_NAME = os.environ.get("REPO_NAME", "semantic-router")
REPO_DIR = Path(f"/repo/{REPO_NAME}")

# Paths inside the tree (and inside every scratch copy of it).
GO_MODULE = Path("src/semantic-router")
CATALOG_PKG = GO_MODULE / "pkg" / "catalog"
EMBED_GO = CATALOG_PKG / "zz_generated_catalog.go"
PUBLIC_JSON = Path("website/static/model-catalog/catalog.json")
GENERATOR = Path("tools/catalog/generate_model_catalog.py")
DASHBOARD_MODULE = Path("dashboard/backend")

# A value that appears exactly once inside the embedded catalog payload literal,
# as a display label. Editing it changes catalog content without touching counts
# or schema identity, so it is a safe probe for "does the digest follow the
# payload?".
PAYLOAD_PROBE_FROM = '"display_name": "MMLU-Pro"'
PAYLOAD_PROBE_TO = '"display_name": "MMLU-Proxy"'

# One source file whose top-level sequence contributes evaluation records. The
# first entry is removed to prove the dashboard counts follow the sources.
EVAL_SOURCE = Path("config/catalog/resources/evaluations/single/ai21.yaml")

# Per-step ceilings. The whole run is bounded by verify.toml [pytest].timeout
# (and the outer [verifier].timeout_sec); these inner limits only catch a single
# hung step. A cold CGO compile of the dashboard module is the one slow step and
# is prewarmed in the image, so the warm path is far under these.
GO_TIMEOUT = 300
GEN_TIMEOUT = 180
COPY_IGNORE_DIRS = {".git", "node_modules", ".venv-agent", ".venv"}
COPY_IGNORE_STATIC = {"img", "videos"}
COPY_IGNORE_SUFFIX = (".pdf", ".mp4", ".webm", ".mov")


# ── Workspace helpers ───────────────────────────────────────────────────────
def _copy_ignore(dirpath, names):
    """Skip heavy media and VCS/venv trees; keep everything the build reads."""
    skip = set()
    base = os.path.basename(dirpath)
    for name in names:
        if name in COPY_IGNORE_DIRS:
            skip.add(name)
        elif base == "static" and name in COPY_IGNORE_STATIC:
            skip.add(name)
        elif name.lower().endswith(COPY_IGNORE_SUFFIX):
            skip.add(name)
    return skip


def _fresh_workspace() -> Path:
    """Copy the checkout into a scratch dir and return its root."""
    assert REPO_DIR.is_dir(), f"repository checkout not found at {REPO_DIR}"
    dst = Path(tempfile.mkdtemp(prefix="catalog-verify-"))
    workspace = dst / REPO_NAME
    shutil.copytree(REPO_DIR, workspace, ignore=_copy_ignore, symlinks=True)
    return workspace


def _catalog_python() -> str:
    """A Python that can import the catalog generator's third-party deps.

    The shared verifier interpreter cannot (no YAML/jsonschema). The image bakes
    an offline environment beside the checkout for exactly this; fall back to a
    system interpreter that happens to have the deps.
    """
    candidates = [
        str(REPO_DIR / ".venv-agent" / "bin" / "python"),
        str(REPO_DIR / ".venv" / "bin" / "python"),
        shutil.which("python3") or "python3",
    ]
    for candidate in candidates:
        if not candidate or not (candidate == "python3" or Path(candidate).exists()):
            continue
        try:
            probe = subprocess.run(
                [candidate, "-c", "import yaml, jsonschema"],
                capture_output=True,
                timeout=60,
            )
        except (OSError, subprocess.SubprocessError):
            continue
        if probe.returncode == 0:
            return candidate
    raise RuntimeError(
        "no interpreter with the catalog generator's dependencies "
        "(PyYAML + jsonschema) was found; the image is expected to bake one "
        "beside the checkout"
    )


def _regenerate(workspace: Path) -> None:
    """Run the catalog generator in place over a scratch workspace."""
    proc = subprocess.run(
        [_catalog_python(), str(workspace / GENERATOR)],
        cwd=str(workspace),
        capture_output=True,
        text=True,
        timeout=GEN_TIMEOUT,
    )
    assert proc.returncode == 0, (
        "catalog regeneration failed (exit "
        f"{proc.returncode}):\n{proc.stdout[-1500:]}\n{proc.stderr[-1500:]}"
    )


def _run_go_test(module_dir: Path, package: str, test_re: str, timeout: int = GO_TIMEOUT):
    """Run one Go test by name; return (proc, {test_name: 'pass'|'fail'|'skip'}).

    Deps are prewarmed in the image, so the subprocess is pinned offline and
    writable-module to stay hermetic.
    """
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "GOPROXY": "off",
        "CGO_ENABLED": "1",
        "GOTOOLCHAIN": "local",
    }
    cmd = [
        "go", "test", "-json", "-count=1",
        f"-timeout={timeout}s", "-run", test_re, package,
    ]
    proc = subprocess.run(
        cmd,
        cwd=str(module_dir),
        capture_output=True,
        text=True,
        timeout=timeout + 60,
        env=env,
    )
    outcomes: dict[str, str] = {}
    for line in proc.stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        name = event.get("Test")
        action = event.get("Action")
        if name and action in ("pass", "fail", "skip"):
            outcomes[name] = action
    return proc, outcomes


def _diag(proc) -> str:
    return f"\n--- go stdout tail ---\n{proc.stdout[-2000:]}\n--- go stderr tail ---\n{proc.stderr[-2000:]}"


def _replace_once(path: Path, old: str, new: str) -> None:
    text = path.read_text()
    count = text.count(old)
    assert count == 1, f"expected exactly one occurrence of {old!r} in {path}, found {count}"
    path.write_text(text.replace(old, new, 1))


def _drop_first_sequence_entry(path: Path) -> int:
    """Remove the first top-level ``- `` YAML sequence entry via text ops.

    Pure text surgery keeps this runnable under the stdlib-only verifier
    interpreter. Returns the number of lines removed (asserted > 0).
    """
    lines = path.read_text().splitlines(keepends=True)
    start = next((i for i, ln in enumerate(lines) if ln.startswith("- ")), None)
    assert start is not None, f"no top-level sequence entry found in {path}"
    end = len(lines)
    for j in range(start + 1, len(lines)):
        if lines[j].startswith("- "):
            end = j
            break
    removed = end - start
    assert removed > 0
    path.write_text("".join(lines[:start] + lines[end:]))
    return removed


def _inventory(workspace: Path) -> dict[str, int]:
    doc = json.loads((workspace / PUBLIC_JSON).read_text())
    return {
        "models": len(doc["models"]),
        "providers": len(doc["providers"]),
        "evaluations": len(doc["evaluations"]),
    }


# ── Check A — the built-in catalog digest follows the published catalog ───────
# fail_to_pass. The documented contract is that the built-in digest equals the
# SHA-256 of the published public catalog document (website/.../catalog.json).
# To prove it is DERIVED (not frozen in the tree), edit one value in the catalog
# content — in both the embedded payload and the published JSON, identically, and
# WITHOUT regenerating (regeneration would also refresh a stored constant, so it
# would not separate the two cases). Then require BuiltIn().Digest() (and the compiled
# registry's Digest()) to equal sha256 of the edited published document. A tree
# that computes the digest at load tracks the edit and matches; a tree that
# serves a stored constant returns the pre-edit value and mismatches.
#
# This asserts only the observable invariant (Digest == sha256 of the public
# artifact) through the exported BuiltIn/Compile/Digest surface. It references no
# internal symbol and encodes no particular derivation formula, so every valid
# approach — helper, inline, or any naming/layout — is admitted equally.
DIGEST_PROBE_TEST = """// Generated by the catalog reward harness; not part of the repository.
package catalog

import "testing"

func TestStaffbenchDigestMatchesPublishedCatalog(t *testing.T) {
\tconst want = "{WANT_DIGEST}"

\tregistry, err := BuiltIn()
\tif err != nil {
\t\tt.Fatalf("BuiltIn() returned error: %v", err)
\t}
\tif got := registry.Digest(); got != want {
\t\tt.Fatalf("BuiltIn().Digest() = %s, but sha256(published catalog.json) = %s; "+
\t\t\t"the built-in digest does not track the published catalog content", got, want)
\t}

\teffective, err := registry.Compile(CompileInput{})
\tif err != nil {
\t\tt.Fatalf("Compile(CompileInput{}) returned error: %v", err)
\t}
\tif got := effective.Digest(); got != want {
\t\tt.Fatalf("compiled registry Digest() = %s, want %s", got, want)
\t}
}
"""


def test_builtin_digest_tracks_published_catalog():
    workspace = _fresh_workspace()
    try:
        # Edit the same unique value in both projections of the catalog content,
        # without regenerating. display_name is a free-form label, so schema
        # identity and record counts are untouched: BuiltIn() still parses, and
        # the two projections stay mutually consistent (the published document is
        # the embedded payload plus a trailing newline).
        _replace_once(workspace / EMBED_GO, PAYLOAD_PROBE_FROM, PAYLOAD_PROBE_TO)
        _replace_once(workspace / PUBLIC_JSON, PAYLOAD_PROBE_FROM, PAYLOAD_PROBE_TO)

        # Independently compute the contract reference: sha256 of the edited
        # published document, exactly as a downstream consumer would.
        published = (workspace / PUBLIC_JSON).read_bytes()
        want = "sha256:" + hashlib.sha256(published).hexdigest()

        probe = workspace / CATALOG_PKG / "zzz_staffbench_digest_test.go"
        probe.write_text(DIGEST_PROBE_TEST.replace("{WANT_DIGEST}", want))

        test_name = "TestStaffbenchDigestMatchesPublishedCatalog"
        proc, outcomes = _run_go_test(
            module_dir=workspace / GO_MODULE,
            package="./pkg/catalog",
            test_re=test_name,
        )
        assert test_name in outcomes, (
            "digest probe test did not run (build or discovery failure)" + _diag(proc)
        )
        assert outcomes[test_name] == "pass", (
            "the built-in catalog digest did not match the sha256 of the published "
            "catalog after an edit to the catalog content — it is being served from "
            "a stored value rather than derived at load" + _diag(proc)
        )
    finally:
        shutil.rmtree(workspace.parent, ignore_errors=True)


# ── Check B — dashboard counts follow the catalog sources ────────────────────
# fail_to_pass. The dashboard contract test must derive its expected
# model/provider/evaluation inventory from the catalog sources, so it tracks the
# catalog as sources change — and it must keep validating the full inventory, not
# a trivial non-empty floor. Two phases prove both halves of that contract, each
# over its own fresh workspace:
#
#   Phase 1 (tracks regeneration): remove one evaluation record from the sources,
#   regenerate, and require the dashboard test to still PASS. A test that derives
#   its expectation from the sources (or from the regenerated document) stays
#   green; a test pinning literal counts mismatches the now-smaller inventory and
#   fails. This phase alone, however, is also satisfied by a test that dropped the
#   inventory validation to a non-empty floor (`len > 0`): after the removal the
#   document is still non-empty, so the floor stays green.
#
#   Phase 2 (drift probe — rejects a dropped validation): remove one evaluation
#   record from the sources but do NOT regenerate, so the authored sources
#   (1529) and the committed generated document (1530) disagree by exactly one
#   record, then require the dashboard test to FAIL. A genuinely source-derived
#   test computes the smaller expectation from the sources and mismatches the
#   unchanged document — it fails as required. A test that pinned the stale
#   literal, or one that replaced the inventory check with a `len > 0` floor (as
#   a passing-but-worse trial did), never consults the sources, sees the
#   unchanged non-empty document, and stays green — so it is rejected here.
#
# Phase 2 deliberately leaves the generated catalog.json untouched (it drifts a
# source only), so the document still parses and normalizes exactly as shipped;
# the sole observable difference is the source-derived expectation, which is
# precisely the behavior under test.
def test_dashboard_counts_follow_sources():
    test_name = "TestGeneratedPublicModelCatalogSatisfiesDashboardContract"

    # Phase 1 — removing a source record and regenerating keeps the test green.
    workspace = _fresh_workspace()
    try:
        before = _inventory(workspace)

        _drop_first_sequence_entry(workspace / EVAL_SOURCE)
        _regenerate(workspace)

        after = _inventory(workspace)
        assert after["evaluations"] == before["evaluations"] - 1, (
            f"regeneration did not reflect the removed source record: "
            f"evaluations {before['evaluations']} -> {after['evaluations']}"
        )
        assert after["models"] == before["models"], "model count changed unexpectedly"
        assert after["providers"] == before["providers"], "provider count changed unexpectedly"

        proc, outcomes = _run_go_test(
            module_dir=workspace / DASHBOARD_MODULE,
            package="./handlers",
            test_re=test_name,
        )
        assert test_name in outcomes, (
            "the dashboard contract test did not run after the source edit — it "
            "must exist and exercise the regenerated inventory" + _diag(proc)
        )
        assert outcomes[test_name] == "pass", (
            "the dashboard contract test did not stay in sync after a source "
            "record was removed and the catalog regenerated — its expected counts "
            "are pinned to literals instead of derived from the catalog" + _diag(proc)
        )
    finally:
        shutil.rmtree(workspace.parent, ignore_errors=True)

    # Phase 2 — drift probe. Remove a source record WITHOUT regenerating so the
    # sources and the committed document disagree; the test must FAIL.
    drift = _fresh_workspace()
    try:
        baseline = _inventory(drift)
        _drop_first_sequence_entry(drift / EVAL_SOURCE)

        # The generated document is intentionally NOT regenerated: it still holds
        # the full inventory, so it parses and normalizes exactly as shipped.
        unchanged = _inventory(drift)
        assert unchanged == baseline, (
            "the drift probe must leave the generated catalog.json untouched; "
            f"inventory changed {baseline} -> {unchanged}"
        )

        proc, outcomes = _run_go_test(
            module_dir=drift / DASHBOARD_MODULE,
            package="./handlers",
            test_re=test_name,
        )
        assert test_name in outcomes, (
            "the dashboard contract test did not run during the drift probe — it "
            "must exist and exercise the inventory" + _diag(proc)
        )
        assert outcomes[test_name] == "fail", (
            "the dashboard contract test still PASSED when the authored sources "
            "and the generated catalog.json disagreed by one evaluation record "
            "(sources dropped one, the document was left unchanged). A test that "
            "genuinely derives its expected inventory from the sources would "
            "detect the mismatch and fail; this one did not — its inventory "
            "validation has been dropped to a non-empty floor or pinned to a "
            "stale literal rather than tracking the sources" + _diag(proc)
        )
    finally:
        shutil.rmtree(drift.parent, ignore_errors=True)


# ── Check D — regeneration must not bake the whole-catalog digest into Go ─────
# fail_to_pass. The reported symptom is that a mechanically-regenerated,
# checked-in value collides between branches. The whole-catalog digest (the
# sha256 of the published catalog document) is exactly such a value when it is
# emitted as a Go source literal: every catalog change regenerates it, so every
# open branch rewrites the same line and they conflict.
#
# A correct change makes that value exist only as something computed at load /
# request time, never stored in a committed artifact. To prove the stored form
# is gone, regenerate from clean sources and require that the digest of the
# regenerated catalog does NOT appear as a literal in any regenerated,
# non-test Go source of the catalog package. This is distinct from Check A:
# Check A proves the load path derives the value; this proves the generation
# path stopped persisting it. A change that derives at load but still lets the
# generator emit the stored literal leaves the collision in place and fails here.
#
# The probe keys on the VALUE (sha256 of the regenerated catalog), computed
# fresh — never on a symbol name or a formula — so any naming or layout is
# treated the same. Per-asset verification digests are different values and are
# unaffected (Check C guards that they remain).
def test_regenerated_catalog_has_no_stored_whole_catalog_digest():
    workspace = _fresh_workspace()
    try:
        _regenerate(workspace)
        whole_digest_hex = hashlib.sha256(
            (workspace / PUBLIC_JSON).read_bytes()
        ).hexdigest()

        pkg_dir = workspace / CATALOG_PKG
        offenders = []
        for go_file in sorted(pkg_dir.glob("*.go")):
            if go_file.name.endswith("_test.go"):
                continue
            if whole_digest_hex in go_file.read_text():
                offenders.append(go_file.name)

        assert not offenders, (
            "after regeneration, the digest of the whole published catalog is "
            "still present as a literal in committed Go sources "
            f"({', '.join(offenders)}). This is the mechanically-regenerated "
            "checked-in value that collides between branches; it must be derived "
            "at load/request time, not stored in a generated artifact."
        )
    finally:
        shutil.rmtree(workspace.parent, ignore_errors=True)


# ── Check C — per-asset verification digests survive regeneration ────────────
# pass_to_pass. Removing the whole-catalog stored digest must not take the
# legitimate per-asset verification hashing with it. Regenerate from clean
# sources and require the public projection to still carry a per-asset
# verification digest for models that declare an asset.
def test_per_asset_verification_digests_preserved():
    workspace = _fresh_workspace()
    try:
        _regenerate(workspace)
        doc = json.loads((workspace / PUBLIC_JSON).read_text())
        with_asset = [
            m for m in doc["models"]
            if isinstance(m.get("asset"), str) and m["asset"]
        ]
        assert with_asset, "no models declare an asset; cannot check asset-level hashing"
        hashed = [
            m for m in with_asset
            if isinstance(m.get("verification"), dict)
            and isinstance(m["verification"].get("asset_sha256"), str)
            and m["verification"]["asset_sha256"]
        ]
        assert len(hashed) == len(with_asset), (
            "the regenerated catalog is missing per-asset verification digests: "
            f"{len(hashed)}/{len(with_asset)} asset-bearing models carry asset_sha256 "
            "— asset-level hashing must remain intact"
        )
    finally:
        shutil.rmtree(workspace.parent, ignore_errors=True)
