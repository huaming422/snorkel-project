mod validation_params;
use validation_params::get_validation_test_cases;
mod val_harness;

#[test]
fn test_readonly_account_refuses_writable_cpi() {
    for tc in &get_validation_test_cases() {
        let load_mode = tc.inputs["load_mode"].as_str().unwrap();
        let result = val_harness::readonly_account_refuses_writable_cpi::run(load_mode);

        // EXPECTED: cpi_handle — "ok" means Ok; otherwise Err must render the variant
        let expected = tc.expected["cpi_handle"].as_str().unwrap();
        if expected == "ok" {
            assert!(result.is_ok(), "case {}: expected cpi handle ok, got {:?}", tc.name, result);
        } else {
            let err = result.expect_err(&format!("case {}: expected cpi handle refusal", tc.name));
            assert!(
                err.contains(expected),
                "case {}: expected error containing '{}', got '{}'",
                tc.name, expected, err
            );
        }
    }
}
