mod validation_params;
use validation_params::get_validation_test_cases;
mod val_harness;

#[test]
fn test_alias_mut_load_conflict() {
    for tc in &get_validation_test_cases() {
        let initial_value = tc.inputs["initial_value"].as_i64().unwrap() as u64;
        let first_hold = tc.inputs["first_hold"].as_str().unwrap();
        let (conflict, value_after_release) =
            val_harness::alias_mut_load_conflict::run(initial_value, first_hold);

        // EXPECTED: conflict — rendered error of the blocked mutable load
        let expected_conflict = tc.expected["conflict"].as_str().unwrap();
        assert!(
            conflict.contains(expected_conflict),
            "case {}: expected conflict containing '{}', got '{}'",
            tc.name, expected_conflict, conflict
        );

        // EXPECTED: value_after_release — counter read back after the borrow is dropped
        let expected_value = tc.expected["value_after_release"].as_i64().unwrap() as u64;
        assert_eq!(
            value_after_release, expected_value,
            "case {}: value_after_release mismatch", tc.name
        );
    }
}
