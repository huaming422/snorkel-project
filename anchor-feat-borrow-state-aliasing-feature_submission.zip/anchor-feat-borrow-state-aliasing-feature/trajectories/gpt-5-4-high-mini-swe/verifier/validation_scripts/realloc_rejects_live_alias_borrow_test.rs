mod validation_params;
use validation_params::get_validation_test_cases;
mod val_harness;

#[test]
fn test_realloc_rejects_live_alias_borrow() {
    for tc in &get_validation_test_cases() {
        let initial_len = tc.inputs["initial_len"].as_i64().unwrap() as usize;
        let new_space = tc.inputs["new_space"].as_i64().unwrap() as usize;
        let with_live_hold = tc.inputs["with_live_hold"].as_bool().unwrap();
        let (realloc_result, data_len_after) =
            val_harness::realloc_rejects_live_alias_borrow::run(
                initial_len, new_space, with_live_hold
            );

        // EXPECTED: realloc_result
        let expected_realloc = tc.expected["realloc_result"].as_str().unwrap();
        if expected_realloc == "ok" {
            assert!(realloc_result.is_ok(), "case {}: expected realloc ok, got {:?}", tc.name, realloc_result);
        } else {
            let err = realloc_result.expect_err(&format!("case {}: expected realloc refusal", tc.name));
            assert!(
                err.contains(expected_realloc),
                "case {}: expected error containing '{}', got '{}'",
                tc.name, expected_realloc, err
            );
        }

        // EXPECTED: data_len_after
        let expected_len = tc.expected["data_len_after"].as_i64().unwrap() as usize;
        assert_eq!(data_len_after, expected_len, "case {}: data_len_after mismatch", tc.name);
    }
}
