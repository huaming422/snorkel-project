mod validation_params;
use validation_params::get_validation_test_cases;
mod val_harness;

#[test]
fn test_nondata_accounts_alias_freely() {
    for tc in &get_validation_test_cases() {
        let account_kind = tc.inputs["account_kind"].as_str().unwrap();
        let result = val_harness::nondata_accounts_alias_freely::run(account_kind);

        // EXPECTED: outcome — "accepted" means Ok; otherwise Err must render the variant
        let expected_outcome = tc.expected["outcome"].as_str().unwrap();
        if expected_outcome == "accepted" {
            assert!(result.is_ok(), "case {}: expected accepted, got {:?}", tc.name, result);
        } else {
            let err = result.expect_err(&format!("case {}: expected refusal", tc.name));
            assert!(
                err.contains(expected_outcome),
                "case {}: expected error containing '{}', got '{}'",
                tc.name, expected_outcome, err
            );
        }
    }
}
