mod validation_params;
use validation_params::get_validation_test_cases;
mod val_harness;

#[test]
fn test_close_rejects_live_alias_borrow() {
    for tc in &get_validation_test_cases() {
        let vault_lamports = tc.inputs["vault_lamports"].as_i64().unwrap() as u64;
        let dest_lamports = tc.inputs["dest_lamports"].as_i64().unwrap() as u64;
        let hold_alias_borrow = tc.inputs["hold_alias_borrow"].as_bool().unwrap();
        let (close_result, vault_after, dest_after) =
            val_harness::close_rejects_live_alias_borrow::run(
                vault_lamports, dest_lamports, hold_alias_borrow
            );

        // EXPECTED: close_result
        let expected_close = tc.expected["close_result"].as_str().unwrap();
        if expected_close == "ok" {
            assert!(close_result.is_ok(), "case {}: expected close ok, got {:?}", tc.name, close_result);
        } else {
            let err = close_result.expect_err(&format!("case {}: expected close refusal", tc.name));
            assert!(
                err.contains(expected_close),
                "case {}: expected error containing '{}', got '{}'",
                tc.name, expected_close, err
            );
        }

        // EXPECTED: vault_lamports_after / dest_lamports_after
        let expected_vault = tc.expected["vault_lamports_after"].as_i64().unwrap() as u64;
        assert_eq!(vault_after, expected_vault, "case {}: vault_lamports_after mismatch", tc.name);
        let expected_dest = tc.expected["dest_lamports_after"].as_i64().unwrap() as u64;
        assert_eq!(dest_after, expected_dest, "case {}: dest_lamports_after mismatch", tc.name);
    }
}
