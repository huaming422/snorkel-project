mod validation_params;
use validation_params::get_validation_test_cases;
mod val_harness;

#[test]
fn test_rejected_mut_load_is_side_effect_free() {
    for tc in &get_validation_test_cases() {
        let capacity = tc.inputs["capacity"].as_i64().unwrap() as usize;
        let populated_len = tc.inputs["populated_len"].as_i64().unwrap() as u32;
        let with_live_readonly = tc.inputs["with_live_readonly"].as_bool().unwrap();
        let (load_mut_error, len_field_after, existing_hold_liveness) =
            val_harness::rejected_mut_load_is_side_effect_free::run(
                capacity, populated_len, with_live_readonly
            );

        // EXPECTED: load_mut_error — rendered error of the rejected load
        let expected_err = tc.expected["load_mut_error"].as_str().unwrap();
        assert!(
            load_mut_error.contains(expected_err),
            "case {}: expected load_mut error containing '{}', got '{}'",
            tc.name, expected_err, load_mut_error
        );

        // EXPECTED: len_field_after (skip if "__skip__")
        let len_after_val = &tc.expected["len_field_after"];
        if len_after_val.as_str() != Some("__skip__") {
            let expected_len = len_after_val.as_i64().unwrap() as u32;
            assert_eq!(
                len_field_after, expected_len,
                "case {}: len_field_after mismatch (rejected load must not rewrite bytes)", tc.name
            );
        }

        // EXPECTED: existing_hold_liveness (skip if "__skip__")
        let expected_borrow = tc.expected["existing_hold_liveness"].as_str().unwrap();
        if expected_borrow != "__skip__" {
            let rendered = existing_hold_liveness
                .expect(&format!("case {}: expected a live-borrow readback", tc.name));
            assert!(
                rendered.contains(expected_borrow),
                "case {}: expected existing_hold_liveness containing '{}', got '{}'",
                tc.name, expected_borrow, rendered
            );
        }
    }
}
