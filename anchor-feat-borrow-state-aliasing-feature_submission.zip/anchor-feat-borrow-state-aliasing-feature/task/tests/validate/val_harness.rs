//! In-memory account scaffolding for the lang-v2 account layer.
//!
//! Pure test plumbing: it builds stack-backed mock accounts, drives the
//! crate's public account wrappers and dispatch entry points, and returns
//! plain observable results (rendered errors, lamport / data-length readbacks)
//! for the caller to assert on. It holds no assertions of its own — the caller
//! owns every expected-value comparison.
//!
//! Every type here is a local test fixture; nothing in it is an implementation
//! symbol. All the account-layer calls go through pre-existing public API
//! (`anchor_lang::accounts::*`, `anchor_lang::prelude::BorshAccount`,
//! `anchor_lang::{realloc_account, run_handler, cursor::AccountCursor}`,
//! `anchor_lang::testing::*`), so the module compiles against the crate as it
//! stands and exercises whatever the account layer actually does.
#![allow(dead_code, unused_imports, unused_unsafe)]

use anchor_lang::{
    accounts::{Account, Slab, UncheckedAccount},
    cursor::AccountCursor,
    prelude::BorshAccount,
    realloc_account, run_handler,
    testing::{AccountBuffer, AccountRecord, SbfInputBuffer},
    AccountClose, Accounts, AnchorAccount, AnchorDeserialize, AnchorSerialize, Discriminator, Owner,
    TryAccounts,
};
use bytemuck::{Pod, Zeroable};
use core::mem::MaybeUninit;
use pinocchio::{account::AccountView, address::Address};
use solana_program_error::ProgramError;

/// Program id every fixture account is owned by, and the id the generated
/// accounts code checks against (see `#[accounts_program_id(ID)]`).
const PROGRAM_ID: [u8; 32] = [0x42; 32];
const ID: Address = Address::new_from_array(PROGRAM_ID);

fn render(e: ProgramError) -> String {
    format!("{e:?}")
}

// ---------------------------------------------------------------------------

pub mod alias_mut_load_conflict {
    use super::*;

    #[repr(C)]
    #[derive(Clone, Copy, Pod, Zeroable)]
    struct Counter {
        value: u64,
    }
    impl Owner for Counter {
        const OWNER: Address = Address::new_from_array(PROGRAM_ID);
    }
    impl Discriminator for Counter {
        const DISCRIMINATOR: &'static [u8] = &[0xAB, 0xCD, 0x12, 0x34, 0x56, 0x78, 0x90, 0xAB];
    }
    type Acct = Account<Counter>;

    fn setup(value: u64) -> AccountBuffer<256> {
        let buf = AccountBuffer::<256>::new();
        let data_len = 8 + core::mem::size_of::<Counter>();
        buf.init([0xAA; 32], PROGRAM_ID, data_len, false, true, false);
        let mut data = [0u8; 16];
        data[..8].copy_from_slice(Counter::DISCRIMINATOR);
        data[8..16].copy_from_slice(&value.to_le_bytes());
        buf.write_data(&data);
        buf
    }

    /// Takes two handles onto the same account; holds a live borrow through the
    /// first (`first_hold` = "readonly" load, or "raw" `try_borrow`), attempts
    /// a mutable load through the second while the first is live, then drops the
    /// first and loads mutably again.
    ///
    /// Returns `(rendered error from the blocked mutable load, value read back
    /// through the now-successful mutable load)`.
    pub fn run(initial_value: u64, first_hold: &str) -> (String, u64) {
        let buf = setup(initial_value);
        let view = unsafe { buf.view() };
        let alias = view;

        match first_hold {
            "readonly" => {
                let ro = Acct::load(view).unwrap();
                let blocked = unsafe { Acct::load_mut(alias) };
                let err = render(
                    blocked
                        .err()
                        .expect("mutable load must fail while a read-only load is live"),
                );
                drop(ro);
                let ok = unsafe { Acct::load_mut(alias) }.unwrap();
                (err, ok.value)
            }
            "raw" => {
                let guard = view.try_borrow().expect("raw borrow should succeed");
                let blocked = unsafe { Acct::load_mut(alias) };
                let err = render(
                    blocked
                        .err()
                        .expect("mutable load must fail while a raw borrow is live"),
                );
                drop(guard);
                let ok = unsafe { Acct::load_mut(alias) }.unwrap();
                (err, ok.value)
            }
            other => panic!("unknown first_hold value: {other}"),
        }
    }
}

// ---------------------------------------------------------------------------

pub mod nondata_accounts_alias_freely {
    use super::*;

    // Program id the generated accounts code checks against. Defined as a real
    // module item (not glob-imported) so the derive-generated descendant module
    // resolves `#[accounts_program_id(ID)]` unambiguously.
    const ID: Address = Address::new_from_array(PROGRAM_ID);

    #[repr(C)]
    #[derive(Clone, Copy, Pod, Zeroable)]
    struct Data {
        value: u64,
    }
    impl Owner for Data {
        const OWNER: Address = Address::new_from_array(PROGRAM_ID);
    }
    impl Discriminator for Data {
        const DISCRIMINATOR: &'static [u8] = &[0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x11, 0x22, 0x33];
    }

    // Two fields that resolve to the same account slot at dispatch. The
    // non-data wrappers hold no data borrow; the data wrappers each take one.
    #[derive(Accounts)]
    #[accounts_program_id(ID)]
    struct NondataAlias {
        #[account(mut)]
        a: UncheckedAccount,
        #[account(mut)]
        b: UncheckedAccount,
    }

    #[derive(Accounts)]
    #[accounts_program_id(ID)]
    struct DataAlias {
        #[account(mut)]
        a: Account<Data>,
        #[account(mut)]
        b: Account<Data>,
    }

    // Bytes before an account's data start in the serialized input layout.
    const RUNTIMEACCOUNT_HDR: usize = 88;

    fn nondata_records() -> [AccountRecord; 2] {
        [
            AccountRecord::NonDup {
                address: [0x11; 32],
                owner: [0xAA; 32],
                lamports: 1_000_000,
                is_signer: false,
                is_writable: true,
                executable: false,
                data_len: 0,
            },
            AccountRecord::Dup { index: 0 },
        ]
    }

    fn data_records() -> [AccountRecord; 2] {
        [
            AccountRecord::NonDup {
                address: [0x22; 32],
                owner: PROGRAM_ID,
                lamports: 1_000_000,
                is_signer: false,
                is_writable: true,
                executable: false,
                data_len: 8 + 8,
            },
            AccountRecord::Dup { index: 0 },
        ]
    }

    fn run_nondata() -> Result<(), ProgramError> {
        let mut sbf = SbfInputBuffer::build(&nondata_records());
        let mut lookup: Vec<MaybeUninit<AccountView>> =
            (0..256).map(|_| MaybeUninit::uninit()).collect();
        let lookup_ptr = lookup.as_mut_ptr() as *mut AccountView;
        let mut cursor = unsafe { AccountCursor::new(sbf.as_mut_ptr(), lookup_ptr) };
        let program_id = Address::new_from_array(PROGRAM_ID);
        run_handler::<NondataAlias, ()>(&program_id, &mut cursor, &[], 2, |_ctx, _args| Ok(()))
    }

    fn run_data() -> Result<(), ProgramError> {
        let mut sbf = SbfInputBuffer::build(&data_records());
        let data_offset = sbf.record_offsets[0] + RUNTIMEACCOUNT_HDR;
        let bytes = sbf.bytes_mut();
        bytes[data_offset..data_offset + 8].copy_from_slice(Data::DISCRIMINATOR);
        let mut lookup: Vec<MaybeUninit<AccountView>> =
            (0..256).map(|_| MaybeUninit::uninit()).collect();
        let lookup_ptr = lookup.as_mut_ptr() as *mut AccountView;
        let mut cursor = unsafe { AccountCursor::new(sbf.as_mut_ptr(), lookup_ptr) };
        let program_id = Address::new_from_array(PROGRAM_ID);
        run_handler::<DataAlias, ()>(&program_id, &mut cursor, &[], 2, |_ctx, _args| Ok(()))
    }

    /// Runs the chosen accounts struct through dispatch over an input whose
    /// second slot aliases the first. `account_kind` = "nondata" uses the
    /// non-data-wrapper struct; "data" uses the data-wrapper struct.
    ///
    /// Returns `Ok(())` if dispatch accepted the aliased accounts, or
    /// `Err(rendered error)` if it refused.
    pub fn run(account_kind: &str) -> Result<(), String> {
        let r = match account_kind {
            "nondata" => run_nondata(),
            "data" => run_data(),
            other => panic!("unknown account_kind: {other}"),
        };
        r.map_err(render)
    }
}

// ---------------------------------------------------------------------------

pub mod close_rejects_live_alias_borrow {
    use super::*;

    #[derive(AnchorDeserialize, AnchorSerialize, Default, Clone)]
    struct Vault {
        balance: u64,
    }
    impl Owner for Vault {
        const OWNER: Address = Address::new_from_array(PROGRAM_ID);
    }
    impl Discriminator for Vault {
        const DISCRIMINATOR: &'static [u8] = &[0xD3, 0x08, 0xE8, 0x2B, 0x02, 0x98, 0x75, 0x77];
    }

    fn setup_vault(lamports: u64) -> AccountBuffer<256> {
        let buf = AccountBuffer::<256>::new();
        buf.init([0x10; 32], PROGRAM_ID, 8 + 8, false, true, false);
        let mut data = [0u8; 16];
        data[..8].copy_from_slice(Vault::DISCRIMINATOR);
        buf.write_data(&data);
        buf.set_lamports(lamports);
        buf
    }

    fn setup_dest(lamports: u64) -> AccountBuffer<256> {
        let buf = AccountBuffer::<256>::new();
        buf.init([0x20; 32], PROGRAM_ID, 0, false, true, false);
        buf.set_lamports(lamports);
        buf
    }

    fn read_lamports(buf: &AccountBuffer<256>) -> u64 {
        unsafe { (*buf.raw()).lamports }
    }

    /// Loads the vault mutably and releases the borrow so the close path must
    /// re-acquire it. If `hold_alias_borrow`, holds a live raw borrow through a
    /// second handle while closing; otherwise closes with no live borrow.
    ///
    /// Returns `(close result, vault lamports after, dest lamports after)`.
    pub fn run(
        vault_lamports: u64,
        dest_lamports: u64,
        hold_alias_borrow: bool,
    ) -> (Result<(), String>, u64, u64) {
        let vault_buf = setup_vault(vault_lamports);
        let dest_buf = setup_dest(dest_lamports);

        let view = unsafe { vault_buf.view() };
        let alias = view;
        let dest_view = unsafe { dest_buf.view() };

        let mut vault = unsafe { BorshAccount::<Vault>::load_mut(view) }.unwrap();
        vault.release_borrow().unwrap();

        let result = if hold_alias_borrow {
            let _guard = alias
                .try_borrow()
                .expect("alias raw borrow should succeed");
            vault.close(dest_view)
        } else {
            vault.close(dest_view)
        };

        (
            result.map_err(render),
            read_lamports(&vault_buf),
            read_lamports(&dest_buf),
        )
    }
}

// ---------------------------------------------------------------------------

pub mod realloc_rejects_live_alias_borrow {
    use super::*;

    #[repr(C)]
    #[derive(Clone, Copy, Pod, Zeroable)]
    struct RData {
        value: u64,
    }
    impl Owner for RData {
        const OWNER: Address = Address::new_from_array(PROGRAM_ID);
    }
    impl Discriminator for RData {
        const DISCRIMINATOR: &'static [u8] = &[0xAA, 0xBB, 0xCC, 0xDD, 0x11, 0x22, 0x33, 0x44];
    }
    type Acct = Account<RData>;

    fn setup(initial_len: usize) -> AccountBuffer<1024> {
        let buf = AccountBuffer::<1024>::new();
        buf.init([0x33; 32], PROGRAM_ID, initial_len, false, true, false);
        let mut data = vec![0u8; initial_len];
        if data.len() >= 8 {
            data[..8].copy_from_slice(RData::DISCRIMINATOR);
        }
        buf.write_data(&data);
        buf.set_lamports(10_000_000_000);
        buf
    }

    /// If `with_live_hold`, holds a live mutable load through the first handle
    /// while resizing through a second handle; otherwise resizes with no live
    /// borrow. Returns `(realloc result, data length after)`.
    pub fn run(
        initial_len: usize,
        new_space: usize,
        with_live_hold: bool,
    ) -> (Result<(), String>, usize) {
        let buf = setup(initial_len);

        let payer = AccountBuffer::<256>::new();
        payer.init([0xCC; 32], PROGRAM_ID, 0, true, true, false);
        payer.set_lamports(10_000_000_000);

        let view = unsafe { buf.view() };
        let mut alias = view;
        let payer_view = unsafe { payer.view() };

        let result = if with_live_hold {
            let _acct = unsafe { Acct::load_mut(view) }.unwrap();
            realloc_account(&mut alias, new_space, &payer_view, false)
        } else {
            realloc_account(&mut alias, new_space, &payer_view, false)
        };

        let data_len_after = unsafe { (*buf.raw()).data_len as usize };
        (result.map_err(render), data_len_after)
    }
}

// ---------------------------------------------------------------------------

pub mod readonly_account_refuses_writable_cpi {
    use super::*;

    #[repr(C)]
    #[derive(Clone, Copy, Pod, Zeroable)]
    struct CData {
        value: u64,
    }
    impl Owner for CData {
        const OWNER: Address = Address::new_from_array(PROGRAM_ID);
    }
    impl Discriminator for CData {
        const DISCRIMINATOR: &'static [u8] = &[0xC9, 0x1A, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF];
    }
    type Acct = Account<CData>;

    fn setup() -> AccountBuffer<256> {
        let buf = AccountBuffer::<256>::new();
        let data_len = 8 + core::mem::size_of::<CData>();
        buf.init([0xAA; 32], PROGRAM_ID, data_len, false, true, false);
        let mut data = [0u8; 16];
        data[..8].copy_from_slice(CData::DISCRIMINATOR);
        buf.write_data(&data);
        buf
    }

    /// Loads the account read-only or mutably per `load_mode`, then asks it for
    /// a writable cross-program handle. Returns `Ok(())` if the handle was
    /// granted, or `Err(rendered error)` if refused.
    pub fn run(load_mode: &str) -> Result<(), String> {
        let buf = setup();
        let view = unsafe { buf.view() };

        let r = match load_mode {
            "readonly" => {
                let mut acct = Acct::load(view).expect("readonly load must succeed");
                acct.try_cpi_handle_mut().map(|_| ())
            }
            "mutable" => {
                let mut acct = unsafe { Acct::load_mut(view) }.expect("mutable load must succeed");
                acct.try_cpi_handle_mut().map(|_| ())
            }
            other => panic!("unknown load_mode: {other}"),
        };

        r.map_err(render)
    }
}

// ---------------------------------------------------------------------------

pub mod rejected_mut_load_is_side_effect_free {
    use super::*;

    #[repr(C)]
    #[derive(Clone, Copy, Pod, Zeroable)]
    struct Header {
        version: u64,
    }
    impl Owner for Header {
        const OWNER: Address = Address::new_from_array(PROGRAM_ID);
    }
    impl Discriminator for Header {
        const DISCRIMINATOR: &'static [u8] = &[0x55, 0x66, 0x77, 0x88, 0x99, 0xAA, 0xBB, 0xCC];
    }
    type Item = [u8; 8];
    type TheSlab = Slab<Header, Item>;

    // Layout: disc(8) | header | populated-length u32 | items.
    const HEADER_OFFSET: usize = 8;
    const LEN_OFFSET: usize = HEADER_OFFSET + core::mem::size_of::<Header>();
    const ITEMS_OFFSET: usize = LEN_OFFSET + 4;
    const ITEM_SIZE: usize = core::mem::size_of::<Item>();

    fn setup(capacity: usize, populated_len: u32) -> AccountBuffer<1024> {
        let buf = AccountBuffer::<1024>::new();
        let data_len = ITEMS_OFFSET + capacity * ITEM_SIZE;
        buf.init([0xAA; 32], PROGRAM_ID, data_len, false, true, false);
        let mut data = vec![0u8; data_len];
        data[..8].copy_from_slice(Header::DISCRIMINATOR);
        data[LEN_OFFSET..LEN_OFFSET + 4].copy_from_slice(&populated_len.to_le_bytes());
        buf.write_data(&data);
        buf
    }

    fn read_len(buf: &AccountBuffer<1024>) -> u32 {
        let data = buf.read_data();
        let mut b = [0u8; 4];
        b.copy_from_slice(&data[LEN_OFFSET..LEN_OFFSET + 4]);
        u32::from_le_bytes(b)
    }

    /// Attempts a mutable load that must be rejected (stored length exceeds
    /// capacity). If `with_live_readonly`, the rejected load goes through a
    /// second handle while a raw read borrow is live on the first, and a fresh
    /// account repeats the scenario to confirm the prior read borrow survived
    /// (a mutable re-borrow still fails, a shared re-borrow still succeeds).
    ///
    /// Returns `(rendered error from the rejected load, length field read back
    /// after the rejected load, Some(rendered error from the mutable re-borrow)
    /// when `with_live_readonly` else None)`.
    pub fn run(
        capacity: usize,
        populated_len: u32,
        with_live_readonly: bool,
    ) -> (String, u32, Option<String>) {
        let buf = setup(capacity, populated_len);
        let view = unsafe { buf.view() };

        let result = if with_live_readonly {
            let _guard = view.try_borrow().expect("raw shared borrow should succeed");
            let alias = view;
            unsafe { TheSlab::load_mut(alias) }
        } else {
            unsafe { TheSlab::load_mut(view) }
        };
        let load_err = render(result.err().expect("mutable load must fail"));
        let len_after = read_len(&buf);

        let existing = if with_live_readonly {
            let buf2 = setup(capacity, populated_len);
            let view2 = unsafe { buf2.view() };
            let _guard2 = view2.try_borrow().expect("fresh raw shared borrow");
            let alias2 = view2;
            let _rejected = unsafe { TheSlab::load_mut(alias2) };

            let mut check = view2;
            let bm = check.try_borrow_mut();
            let rendered = render(
                bm.err()
                    .expect("mutable re-borrow must fail while a read borrow is live"),
            );
            check
                .try_borrow()
                .expect("shared re-borrow should still succeed");
            Some(rendered)
        } else {
            None
        };

        (load_err, len_after, existing)
    }
}
