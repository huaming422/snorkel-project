## Task

we want to change how the account layer keeps two mutable handles to the same account from colliding. today that's blocked up front at instruction dispatch, using a duplicate-mutable table the accounts macro computes for the whole instruction. let's retire that whole-instruction table and have each account police its own borrows at the moment it lends out a reference, so a conflicting borrow of an aliased account is refused right there. accounts that lend out no typed data should be free to show up more than once in the same instruction.

keep this confined to how borrows of a lent-out account are policed: ownership and the usual content validation, closing, resizing, and init-if-needed should behave exactly as they do today. once each account enforces the rule itself, the per-account duplicate escape hatch on the accounts macro stops meaning anything, so drop it.

## User stories / requirements

- When the same data account is passed under two handles and one handle takes a mutable borrow of it, any further borrow of that account through the other handle is refused with a borrow-conflict error. Once the first borrow is dropped, the second borrow succeeds.
- When a signer, a system account, an unchecked account, or a program account is passed under two handles at once, both handles load without error.
- When an account is closed while a borrow of it is still live through another handle, the close is refused with a borrow-conflict error and the account's balance and contents are left untouched. With no live borrow, the close succeeds and the balance moves to the destination.
- When an account is resized while a borrow of it is still live through another handle, the resize is refused with a borrow-conflict error and the account's size is unchanged. With no live borrow, the resize succeeds.
- When an account was loaded as read-only, asking it for a writable handle to hand to a cross-program call is refused with a borrow-conflict error. An account loaded as mutable yields the writable handle.
- When a mutable load of an account is rejected because the account's contents fail validation, the account's bytes are left exactly as they were and any borrow already live on it stays live.
