#nullable enable

using Jint;

namespace Jint.Tests.PublicInterface;

// Observes the shipped engine surface only. These are the semantics a bounded-native-stack walk
// must leave untouched while it removes the per-link native descent: the ordinary shallow-input
// answers on both routes, the first-non-bound-target precedence of the is-constructor verdict, and
// the catchable TypeError a revoked proxy still produces during realm resolution. They involve no
// deep chain and so pass before and after; a change that de-recurses by dropping a check (e.g. the
// revoked-proxy throw) or by mangling the terminal-object precedence is caught here.

public class DeepChainSemantics
{
    [Test]
    public void AShallowBoundConstructorStillConstructs()
    {
        using var engine = new Engine();

        // new over a singly-bound constructor works and preserves the constructed shape.
        engine.Evaluate("""
            (function () {
                function Point(x) { this.x = x; }
                var Bound = Point.bind(null);
                var p = new Bound(7);
                return p instanceof Point && p.x === 7;
            })();
            """).AsBoolean().Should().BeTrue();

        // Reflect.construct through a bound constructor is usable the same way.
        engine.Evaluate("""
            (function () {
                function Point(x) { this.x = x; }
                var p = Reflect.construct(Point, [9], Point.bind(null));
                return p.x === 9;
            })();
            """).AsBoolean().Should().BeTrue();
    }

    [Test]
    public void TheIsConstructorVerdictComesFromTheFirstNonBoundTarget()
    {
        using var engine = new Engine();

        // A bound (and proxy-wrapped, and multiply-bound) chain answers the is-constructor question
        // with its innermost non-bound target's verdict: a constructor stays constructible, and an
        // arrow / generator stays non-constructible, no matter how many bound links sit above it.
        engine.Evaluate("""
            (function () {
                function chain(target) { return target.bind(null).bind(null).bind(null); }
                function constructs(f) {
                    try { Reflect.construct(function () {}, [], f); return true; } catch (e) { return false; }
                }
                return [
                    constructs(chain(function () {})),
                    constructs(chain(() => {})),
                    constructs(chain(new Proxy(function () {}, {}))),
                    constructs(chain(class {})),
                    constructs(chain(function* () {}))
                ].join();
            })();
            """).AsString().Should().Be("true,false,true,true,false");
    }

    [Test]
    public void AProxyOverAFunctionResolvesToItsTargetsRealm()
    {
        using var engine = new Engine();

        // A newTarget whose prototype must be defaulted takes it from the realm of the function the
        // chain terminates at — here the running realm via a shallow proxy-over-bound wrapper.
        engine.Evaluate("""
            (function () {
                var target = function () {};
                var newTarget = new Proxy(target, {}).bind(null);
                var o = Reflect.construct(function () {}, [], newTarget);
                return Object.getPrototypeOf(o) === Object.prototype;
            })();
            """).AsBoolean().Should().BeTrue();
    }

    [Test]
    public void ARevokedProxyOnTheRealmPathStillThrowsACatchableTypeError()
    {
        using var engine = new Engine();

        // Realm resolution over a chain that reaches a revoked proxy must still raise a catchable
        // TypeError; bound links above the revoked proxy do not hide it.
        engine.Evaluate("""
            (function () {
                var r = Proxy.revocable(function () {}, {});
                var newTarget = r.proxy.bind(null).bind(null);
                r.revoke();
                try {
                    Reflect.construct(function () {}, [], newTarget);
                    return 'no-throw';
                } catch (e) {
                    return e.name;
                }
            })();
            """).AsString().Should().Be("TypeError");
    }
}
