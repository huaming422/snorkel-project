#nullable enable

using Jint;

namespace Jint.Tests.PublicInterface;

// Observes the shipped engine surface only (Engine.Execute / Engine.Evaluate). A script grows a
// deeply nested linked structure out of repeatedly bound functions (and, for one case, proxies
// interleaved), then exercises the construct / is-constructor and realm-resolution routes over it.
// Everything runs on a dedicated thread with a deliberately small native stack so that a per-link
// native descent reproduces deterministically within a run's time budget rather than depending on
// the machine and the build.
//
// The observable split:
//   * DeepChainHostSafety  — routes a deep script-controlled chain reaches through the construct /
//     is-constructor and realm-resolution machinery. A per-link native descent on any of these
//     ends the whole test host (native "Stack overflow.", process gone); a bounded-native-stack
//     walk lets each route either answer or raise a catchable JavaScript error, and the thread
//     completes. The `dotnet test` process surviving to a clean exit is itself the signal.
//   * DeepChainSemantics (separate file) — ordinary shallow inputs and the revoked-proxy outcome,
//     which must read the same before and after.

public class DeepChainHostSafety
{
    // Far past the ~16,000 native frames a 1 MB stack held per link when each link was one frame,
    // and still cheap to build: growing a bind chain is linear, well under a second in Release.
    private const int ChainLength = 200000;

    // static readonly, not const: the script text is built by concatenating the int ChainLength into
    // a string, which is a runtime operation rather than a compile-time constant expression.
    private static readonly string BuildBoundChain =
        "var f = function () {}; for (var i = 0; i < " + ChainLength + "; i++) f = f.bind(null);";

    // A proxy and a bind in turn, so realm resolution walks both kinds of link. 100,000 iterations
    // is 200,000 links in all.
    private static readonly string BuildMixedChain =
        "var f = function () {}; for (var i = 0; i < " + (ChainLength / 2) + "; i++) f = new Proxy(f, {}).bind(null);";

    private const string StackExhausted = "RangeError:Maximum call stack size exceeded";

    [Test]
    public void ConstructingThroughADeepBoundChainAnswersOrRaisesCatchablyAndTheHostSurvives()
    {
        DedicatedThread.Run(() =>
        {
            using var engine = new Engine();
            engine.Execute(BuildBoundChain);

            // Interrogates the chain's is-constructor verdict without going on to call through it:
            // the terminal is a plain function, so the answer is a value, not an exhaustion error.
            Outcome(engine, "return typeof new Proxy(f, {});").Should().Be("function");

            // Uses the chain with `new`. The is-constructor verdict is read first (a walk, no
            // exhaustion), then construction forwards through every link, where the forwarding
            // path's own native-stack probe turns a genuine overflow into a catchable RangeError.
            Outcome(engine, "new f(); return 'constructed';").Should().Be(StackExhausted);

            engine.Evaluate("6 * 7").AsNumber().Should().Be(42);
        }, maxStackSize: 1024 * 1024);
    }

    [Test]
    public void ResolvingTheRealmThroughADeepChainAnswersOrRaisesCatchablyAndTheHostSurvives()
    {
        DedicatedThread.Run(() =>
        {
            using var engine = new Engine();
            engine.Execute(BuildBoundChain);

            // Reflect.construct with the chain as newTarget: the default prototype is taken from the
            // chain's realm, which resolves by walking to the terminal. No forwarding call happens,
            // so a correct walk yields a value.
            Outcome(
                engine,
                "return String(Object.getPrototypeOf(Reflect.construct(function () {}, [], f)) === Object.prototype);")
                .Should().Be("true");

            // An array whose constructor resolves through the chain drives the species path, which
            // consults the chain's realm the same way.
            Outcome(
                engine,
                "var a = []; a.constructor = f; return String(Array.isArray(a.map(function (x) { return x; })));")
                .Should().Be("true");

            engine.Evaluate("6 * 7").AsNumber().Should().Be(42);
        }, maxStackSize: 1024 * 1024);
    }

    [Test]
    public void ResolvingTheRealmThroughADeepMixedBoundAndProxyChainAnswersAndTheHostSurvives()
    {
        DedicatedThread.Run(() =>
        {
            using var engine = new Engine();
            engine.Execute(BuildMixedChain);

            // Realm resolution must walk bound links and proxy links alike without a native frame per
            // link. Reflect.construct over the mixed chain drives exactly that walk.
            Outcome(
                engine,
                "return String(Object.getPrototypeOf(Reflect.construct(function () {}, [], f)) === Object.prototype);")
                .Should().Be("true");

            engine.Evaluate("6 * 7").AsNumber().Should().Be(42);
        }, maxStackSize: 1024 * 1024);
    }

    private static string Outcome(Engine engine, string body)
    {
        return engine.Evaluate("""
            (function () {
                try {
            """ + body + """
                } catch (error) { return error.name + ':' + error.message; }
            })();
            """).AsString();
    }
}
