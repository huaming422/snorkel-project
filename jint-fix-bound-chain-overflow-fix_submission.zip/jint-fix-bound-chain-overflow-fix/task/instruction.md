## Task

we embed the engine to run untrusted, machine-generated scripts inside our host app, and every so often one of them takes down the whole process. it isn't a .NET exception we can catch. nothing bubbles up to our handler, the process is just gone. when we manage to grab a log before it dies, it shows `Stack overflow.` followed by thousands of repeated frames.

it's maddeningly flaky. the same script crashes on one machine or build and runs fine on another, and the same process can behave differently from one run to the next, so we've never pinned down a small reproduction. the one thing we've noticed is that the scripts that set it off tend to bind the same function over and over, or wrap things in proxies, before calling or constructing them.

a script running inside the engine should never be able to take the host down like this. a runaway script needs to fail with an error we can catch, not abort the whole process. dig in and fix it.
