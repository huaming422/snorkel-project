#!/usr/bin/env bash
# test-setup.sh — sourced by tests/test.sh before the verifier runs (inherits
# set -euo pipefail). It must run with the network cut: the image already baked
# Superset and its dependency closure (requirements/development.txt) into
# /repo/superset/.venv, so this script only brings that venv online offline-first
# and smoke-tests that a minimal Flask app boots.
#
# The dashboard reconciliation behaviour is exercised at the unit tier
# (in-memory SQLite, Pattern-1 minimal app) through DashboardDAO and at the
# integration/API tier; no Postgres/Redis or example data is needed here.

REPO=/repo/superset
cd "$REPO"

# uv is installed at a fixed location by the image (UV_INSTALL_DIR) and is NOT on
# PATH during the verifier phase, so call it by absolute path. Fall back to a
# PATH lookup only if that fixed location ever moves.
UV="/opt/tooling/uv/uv"
[ -x "$UV" ] || UV="$(command -v uv || true)"

# Fail a cache miss fast instead of reaching for PyPI on a dead network.
export UV_OFFLINE=1

# Dependencies: offline-first against the image bake, logged online fallback.
# The image created /repo/superset/.venv and installed development.txt into it;
# an offline sync/verify is a no-op when the bake is fresh.
if [ -x "$REPO/.venv/bin/python" ] && [ -n "$UV" ] \
   && "$UV" pip install --python "$REPO/.venv/bin/python" --offline \
        -r requirements/development.txt > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] superset deps satisfied from image"
else
    echo "[test-setup] offline install path failed; retrying online (image bake was stale)"
    unset UV_OFFLINE
    "$UV" venv --python /usr/local/bin/python3.11 "$REPO/.venv" >> /tmp/test-setup-install.log 2>&1 || true
    if ! "$UV" pip install --python "$REPO/.venv/bin/python" \
            -r requirements/development.txt >> /tmp/test-setup-install.log 2>&1; then
        tail -80 /tmp/test-setup-install.log >&2; exit 1
    fi
fi

# Route the repo test process at the baked venv. (Infrastructure stays on
# VERIFIER_PYTHON; verify.toml's [pytest] command targets this interpreter.)
export REPO_PYTHON="$REPO/.venv/bin/python"

# Smoke-test the import chain. Many Superset modules are app-context-bound, so
# building a minimal app + entering an app context is the canonical way to make
# model imports succeed (notes.md Pattern 1).
echo "[test-setup] bootstrapping minimal app + smoke-testing imports"
"$REPO_PYTHON" - <<'PY'
import sys
sys.path.insert(0, "/repo/superset")

from superset.app import SupersetApp
from superset.extensions import appbuilder
from superset.initialization import SupersetAppInitializer

app = SupersetApp(__name__)
app.config.from_object("superset.config")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///"
app.config["WTF_CSRF_ENABLED"] = False
app.config["TESTING"] = True
app.config["RATELIMIT_ENABLED"] = False
app.config["CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
app.config["DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
app.config["FILTER_STATE_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
app.config["EXPLORE_FORM_DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
app.config["GLOBAL_ASYNC_QUERIES_REDIS_CONFIG"] = None
app.config["TALISMAN_ENABLED"] = False
app.config["PREVENT_UNSAFE_DB_CONNECTIONS"] = False
appbuilder.baseviews = []
SupersetAppInitializer(app).init_app()
with app.app_context():
    from superset.daos.dashboard import DashboardDAO  # noqa: F401
    from superset.models.dashboard import Dashboard  # noqa: F401
    print("[test-setup] imports OK")
PY

echo "[test-setup] done"
