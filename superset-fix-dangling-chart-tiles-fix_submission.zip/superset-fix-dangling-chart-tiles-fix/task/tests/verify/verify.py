"""Behavioral verifier for superset-fix-dangling-chart-tiles.

Everything is exercised THROUGH three pre-existing, stable public interfaces —
never through any helper the fix introduces:

  * ``DashboardDAO.set_dash_metadata(dashboard, data)`` — the save/layout-write
    path that rebuilds ``dashboard.slices`` membership and ``position_json`` from
    the incoming payload on every save.
  * ``UpdateDashboardCommand(id, data).run()`` — the command the PUT endpoint
    drives; the layer directly beneath the REST resource.
  * ``DashboardDAO.copy_dashboard(original, data)`` — the duplicate path.

The behavior under test: a dashboard's layout JSON and its chart membership must
stay consistent after every save and every copy. A layout tile pointing at a
chart that no longer exists is reconciled (the tile is kept as an inert,
geometry-preserving slot that no longer names a missing chart); a tile whose
chart identifier cannot be parsed at all is rejected cleanly rather than
silently detaching the chart; a trashed-but-not-purged member still counts as
existing; duplicating a dashboard does not carry a broken reference into the
copy and fails closed when a tile names a live chart outside membership.

Design constraints honoured here (why the assertions are shaped as they are):

  * No internal helper, constant, or exception subclass the fix may introduce is
    imported or named. The names, placement, number of helpers, and the exact
    placeholder representation are all free for the implementer to choose, so the
    assertions check only observable facts: node type is no longer the live
    chart type, slot width/height survive, the missing chart id is gone from both
    the node and membership, a malformed save raises a validation-class error and
    leaves membership untouched, a copy's layout no longer names the absent id.
  * The user-facing placeholder text, the exception class name, and the error's
    field name are all implementation choices — never asserted.
  * HTTP-422-equivalent is asserted as "the command raises a
    ``DashboardInvalidError`` (or a subclass)", which is the stable framework
    contract the REST resource maps to 422; the concrete subclass is not named.

This file is injected outside the repo's ``tests/`` tree, so the repo's
``tests/unit_tests/conftest.py`` fixtures do not auto-load. The app bootstrap,
the in-memory-SQLite session, the feature-flag toggle, and the soft-delete
listener are therefore reconstructed here from the same public building blocks
the repo's own unit tier uses (SupersetApp + SupersetAppInitializer, an
in-memory engine patched onto ``superset.db.session``).
"""

from __future__ import annotations

import importlib
from datetime import datetime, timezone
from typing import Any, Iterator

import pytest


# --------------------------------------------------------------------------- #
# Minimal app bootstrap (Pattern 1): build a SupersetApp, point it at in-memory
# SQLite, initialise it, and keep an app context open for the whole session.
# This mirrors the repo unit tier's ``app`` + ``app_context`` fixtures using
# only public entry points.
# --------------------------------------------------------------------------- #
@pytest.fixture(scope="session")
def _app() -> Iterator[Any]:
    from superset.app import SupersetApp
    from superset.extensions import appbuilder
    from superset.initialization import SupersetAppInitializer

    app = SupersetApp(__name__)
    app.config.from_object("superset.config")
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite://"
    app.config["WTF_CSRF_ENABLED"] = False
    app.config["TESTING"] = True
    app.config["RATELIMIT_ENABLED"] = False
    app.config["PREVENT_UNSAFE_DB_CONNECTIONS"] = False
    app.config["CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["FILTER_STATE_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["EXPLORE_FORM_DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["GLOBAL_ASYNC_QUERIES_REDIS_CONFIG"] = None
    app.config["TALISMAN_ENABLED"] = False

    # Singleton appbuilder keeps views across re-inits; clear so init is clean.
    appbuilder.baseviews = []
    SupersetAppInitializer(app).init_app()

    with app.app_context():
        yield app


@pytest.fixture
def session(_app: Any, monkeypatch: pytest.MonkeyPatch) -> Iterator[Any]:
    """An in-memory SQLite session patched onto ``superset.db.session``.

    Replicates the repo unit tier's ``session`` fixture: a fresh engine per
    test, with the ORM-level ``db.session`` swapped for a plain SQLAlchemy
    session so model writes hit SQLite directly. Every module that reads
    ``superset.db.session`` (the DAO, the command, the security manager) is
    repointed at this one object.
    """
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker

    from superset import db as _db
    from superset import security_manager

    engine = create_engine("sqlite://")
    in_memory_session = sessionmaker(bind=engine)()
    # Flask calls ``db.session.remove()`` on teardown; make it a no-op here.
    in_memory_session.remove = lambda: None  # type: ignore[method-assign]

    # ``db`` is the SQLAlchemy extension instance; ``db.session`` is a settable
    # instance attribute (the repo's own unit tier patches the same target via
    # ``superset.db.session``). Point it — and the security manager's own handle,
    # used by access filters — at this one in-memory session.
    monkeypatch.setattr(_db, "session", in_memory_session, raising=False)
    monkeypatch.setattr(
        type(security_manager), "session", in_memory_session, raising=False
    )

    try:
        yield in_memory_session
    finally:
        in_memory_session.close()
        engine.dispose()


@pytest.fixture
def soft_delete_on(_app: Any) -> Iterator[None]:
    """Turn the ``SOFT_DELETE`` rollout flag on for the duration of a test.

    The global visibility filter that hides soft-deleted rows is gated on this
    flag; a trashed member is only observable-as-still-existing with it enabled.
    """
    from superset.extensions import feature_flag_manager

    original = feature_flag_manager.get_feature_flags

    def _patched() -> dict[str, bool]:
        return {**(feature_flag_manager._feature_flags or {}), "SOFT_DELETE": True}

    feature_flag_manager.get_feature_flags = _patched  # type: ignore[assignment]
    try:
        yield
    finally:
        feature_flag_manager.get_feature_flags = original  # type: ignore[assignment]


# --------------------------------------------------------------------------- #
# Small builders shared across tests. These construct ordinary repo model rows
# and plain layout-node dicts (a pre-existing, repo-owned shape), never anything
# the fix invents.
# --------------------------------------------------------------------------- #
def _chart_node(node_id: str, chart_id: Any, width: int, height: int) -> dict[str, Any]:
    """A ``CHART`` layout node — the repo's own persisted layout shape."""
    return {
        "type": "CHART",
        "id": node_id,
        "children": [],
        "meta": {"chartId": chart_id, "width": width, "height": height},
    }


def _seed_dataset(db_name: str, table_name: str) -> Any:
    from superset import db
    from superset.connectors.sqla.models import Database, SqlaTable

    dataset = SqlaTable(
        table_name=table_name,
        database=Database(database_name=db_name, sqlalchemy_uri="sqlite://"),
    )
    db.session.add(dataset)
    db.session.flush()
    return dataset


def _new_chart(name: str, dataset: Any, *, deleted: bool = False) -> Any:
    from superset.models.slice import Slice

    kwargs: dict[str, Any] = {
        "slice_name": name,
        "datasource_id": dataset.id,
        "datasource_type": "table",
    }
    if deleted:
        kwargs["deleted_at"] = datetime(2026, 1, 1, tzinfo=timezone.utc)
    return Slice(**kwargs)


def _create_all(session: Any) -> None:
    from superset.models.dashboard import Dashboard

    Dashboard.metadata.create_all(session.get_bind())


def _is_live_chart_tile(node: dict[str, Any]) -> bool:
    """A node that still renders as a live chart tile referencing a chart id.

    The fix repairs a dangling tile by changing it away from the live-chart
    representation; a still-live tile keeps ``type == "CHART"`` AND a chart id in
    its meta. We treat "still a live chart tile" as exactly that conjunction, so
    the check is agnostic to whatever inert type the repair picks.
    """
    if node.get("type") != "CHART":
        return False
    meta = node.get("meta")
    return isinstance(meta, dict) and meta.get("chartId") is not None


# --------------------------------------------------------------------------- #
# Criterion 1 — saving a dashboard whose layout references a since-deleted chart
# repairs only the dangling tile, preserves the slot, leaves valid tiles alone,
# and drops the missing chart from membership.
# --------------------------------------------------------------------------- #
def test_set_dash_metadata_repairs_dangling_tile_only(session: Any) -> None:
    from superset import db
    from superset.daos.dashboard import DashboardDAO
    from superset.models.dashboard import Dashboard
    from superset.utils import json as superset_json

    _create_all(session)
    dataset = _seed_dataset("dangle_db", "dangle_table")
    live = _new_chart("dangle_live", dataset)
    dashboard = Dashboard(dashboard_title="dangle_dash", slices=[live], published=True)
    db.session.add_all([live, dashboard])
    db.session.flush()
    db.session.expire(dashboard, ["slices"])

    absent_id = 987_654_321
    positions = {
        "CHART-live": _chart_node("CHART-live", live.id, 4, 50),
        "CHART-gone": _chart_node("CHART-gone", absent_id, 6, 30),
    }

    DashboardDAO.set_dash_metadata(dashboard, {"positions": positions})
    db.session.flush()
    db.session.expire(dashboard, ["position_json", "slices"])

    # Read the reconciliation from the PERSISTED layout (the stable artifact
    # every production consumer sees), not the caller's input dict — so a
    # correct rebind-and-persist implementation that never mutates the argument
    # in place is accepted, while a slot-dropping implementation still fails.
    saved = superset_json.loads(dashboard.position_json)
    member_ids = {chart.id for chart in dashboard.slices}

    # Valid tile untouched: still a live chart tile for the live chart.
    assert _is_live_chart_tile(saved["CHART-live"]), saved["CHART-live"]
    assert live.id in member_ids

    # Dangling tile repaired: no longer a live chart tile, slot geometry kept,
    # and the missing chart id is gone from both the node and membership.
    gone = saved["CHART-gone"]
    assert not _is_live_chart_tile(gone), gone
    assert gone.get("meta", {}).get("width") == 6
    assert gone.get("meta", {}).get("height") == 30
    assert gone.get("meta", {}).get("chartId") != absent_id
    assert absent_id not in member_ids
    # The slot itself survives (the layout is not silently shrunk).
    assert "CHART-gone" in saved


# --------------------------------------------------------------------------- #
# Criterion 2 — only absent charts are reconciled: an all-present layout is left
# unchanged (every tile stays a live chart tile); exactly one absent id repairs
# exactly one tile.
# --------------------------------------------------------------------------- #
def test_set_dash_metadata_leaves_all_present_layout_unchanged(session: Any) -> None:
    from superset import db
    from superset.daos.dashboard import DashboardDAO
    from superset.models.dashboard import Dashboard
    from superset.utils import json as superset_json

    _create_all(session)
    dataset = _seed_dataset("present_db", "present_table")
    chart_a = _new_chart("present_a", dataset)
    chart_b = _new_chart("present_b", dataset)
    dashboard = Dashboard(
        dashboard_title="present_dash", slices=[chart_a, chart_b], published=True
    )
    db.session.add_all([chart_a, chart_b, dashboard])
    db.session.flush()
    db.session.expire(dashboard, ["slices"])

    positions = {
        "CHART-a": _chart_node("CHART-a", chart_a.id, 4, 50),
        "CHART-b": _chart_node("CHART-b", chart_b.id, 3, 20),
    }

    DashboardDAO.set_dash_metadata(dashboard, {"positions": positions})
    db.session.flush()
    db.session.expire(dashboard, ["position_json", "slices"])

    # Nothing was repaired: both tiles remain live chart tiles in the persisted
    # layout, membership intact.
    saved = superset_json.loads(dashboard.position_json)
    assert _is_live_chart_tile(saved["CHART-a"]), saved["CHART-a"]
    assert _is_live_chart_tile(saved["CHART-b"]), saved["CHART-b"]
    assert {chart.id for chart in dashboard.slices} == {chart_a.id, chart_b.id}


def test_set_dash_metadata_repairs_exactly_the_absent_tile(session: Any) -> None:
    from superset import db
    from superset.daos.dashboard import DashboardDAO
    from superset.models.dashboard import Dashboard
    from superset.utils import json as superset_json

    _create_all(session)
    dataset = _seed_dataset("oneabsent_db", "oneabsent_table")
    present = _new_chart("oneabsent_present", dataset)
    dashboard = Dashboard(
        dashboard_title="oneabsent_dash", slices=[present], published=True
    )
    db.session.add_all([present, dashboard])
    db.session.flush()
    db.session.expire(dashboard, ["slices"])

    absent_id = 55_555_555
    positions = {
        "CHART-present": _chart_node("CHART-present", present.id, 4, 50),
        "CHART-absent": _chart_node("CHART-absent", absent_id, 7, 11),
    }

    DashboardDAO.set_dash_metadata(dashboard, {"positions": positions})
    db.session.flush()
    db.session.expire(dashboard, ["position_json", "slices"])

    # Exactly one tile reconciled in the persisted layout — the absent one.
    saved = superset_json.loads(dashboard.position_json)
    repaired = [
        key
        for key, node in saved.items()
        if isinstance(node, dict) and not _is_live_chart_tile(node)
    ]
    assert repaired == ["CHART-absent"], saved
    assert absent_id not in {chart.id for chart in dashboard.slices}


# --------------------------------------------------------------------------- #
# Criterion 3 — a soft-deleted (trashed, not purged) member still counts as
# existing: its tile is NOT repaired and it stays in membership, while a
# genuinely-absent reference in the same save IS repaired.
# --------------------------------------------------------------------------- #
def test_set_dash_metadata_preserves_soft_deleted_member(
    session: Any, soft_delete_on: None
) -> None:
    from superset import db
    from superset.daos.dashboard import DashboardDAO
    from superset.models.dashboard import Dashboard
    from superset.models.helpers import skip_visibility_filter
    from superset.models.slice import Slice
    from superset.utils import json as superset_json

    _create_all(session)
    dataset = _seed_dataset("soft_db", "soft_table")
    live = _new_chart("soft_live", dataset)
    trashed = _new_chart("soft_trashed", dataset, deleted=True)
    dashboard = Dashboard(
        dashboard_title="soft_dash", slices=[live, trashed], published=True
    )
    db.session.add_all([live, trashed, dashboard])
    db.session.flush()
    db.session.expire(dashboard, ["slices"])

    absent_id = 987_654_321
    positions = {
        "CHART-live": _chart_node("CHART-live", live.id, 4, 50),
        "CHART-trashed": _chart_node("CHART-trashed", trashed.id, 4, 50),
        "CHART-gone": _chart_node("CHART-gone", absent_id, 6, 30),
    }

    DashboardDAO.set_dash_metadata(dashboard, {"positions": positions})
    db.session.flush()
    db.session.expire(dashboard, ["position_json"])

    # The soft-deleted member keeps its live chart tile in the persisted layout;
    # it is never mistaken for a dangling reference and repaired away.
    saved = superset_json.loads(dashboard.position_json)
    assert _is_live_chart_tile(saved["CHART-trashed"]), saved["CHART-trashed"]
    # Membership read with the soft-delete visibility filter bypassed, since the
    # trashed row is otherwise hidden from the relationship load.
    with skip_visibility_filter(db.session, Slice):
        db.session.expire(dashboard, ["slices"])
        member_ids = {chart.id for chart in dashboard.slices}
    assert trashed.id in member_ids
    assert live.id in member_ids

    # The genuinely-absent reference is still repaired in the same save — so the
    # fix repairs absent references WITHOUT over-repairing the soft-deleted one.
    assert not _is_live_chart_tile(saved["CHART-gone"]), saved["CHART-gone"]
    assert absent_id not in member_ids


# --------------------------------------------------------------------------- #
# Criterion 4 — chart ids are coerced from numeric string forms but a
# boolean is never a chart id. Tested THROUGH set_dash_metadata behavior:
#   * a live member referenced as "<id>" survives (recognised as that
#     chart, kept as a live tile, stays in membership) — numeric forms coerce;
#   * a boolean chartId is NOT read as id 1; on the membership-rebuilding save
#     path a boolean is an unresolvable identifier, so the save is rejected
#     rather than detaching anything (a boolean must never slip through as id 1).
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("numeric_form", ["string"])
def test_set_dash_metadata_coerces_numeric_id_forms(
    session: Any, numeric_form: str
) -> None:
    from superset import db
    from superset.daos.dashboard import DashboardDAO
    from superset.models.dashboard import Dashboard

    _create_all(session)
    dataset = _seed_dataset(f"numeric_{numeric_form}_db", f"numeric_{numeric_form}_tbl")
    member = _new_chart(f"numeric_{numeric_form}_member", dataset)
    dashboard = Dashboard(
        dashboard_title=f"numeric_{numeric_form}", slices=[member], published=True
    )
    db.session.add_all([member, dashboard])
    db.session.flush()
    db.session.expire(dashboard, ["slices"])

    ref: Any = str(member.id) if numeric_form == "string" else float(member.id)
    positions = {"CHART-member": _chart_node("CHART-member", ref, 4, 50)}

    DashboardDAO.set_dash_metadata(dashboard, {"positions": positions})
    db.session.flush()

    # The numeric-form id is recognised as the real chart: tile stays live and
    # the member is NOT unlinked by the wholesale membership rebuild.
    assert _is_live_chart_tile(positions["CHART-member"]), positions["CHART-member"]
    assert member.id in {chart.id for chart in dashboard.slices}


def test_set_dash_metadata_never_reads_boolean_as_chart_id(session: Any) -> None:
    from superset import db
    from superset.commands.dashboard.exceptions import DashboardInvalidError
    from superset.daos.dashboard import DashboardDAO
    from superset.models.dashboard import Dashboard
    from superset.models.slice import Slice

    _create_all(session)
    dataset = _seed_dataset("bool_db", "bool_table")
    # Create a chart with id 1 so that, IF a boolean were misread as int 1, the
    # boolean tile would resolve to a real chart and the save would succeed —
    # making this test bite only when booleans are correctly excluded.
    chart_one = Slice(
        id=1,
        slice_name="bool_one",
        datasource_id=dataset.id,
        datasource_type="table",
    )
    member = _new_chart("bool_member", dataset)
    dashboard = Dashboard(dashboard_title="bool_dash", slices=[member], published=True)
    db.session.add_all([chart_one, member, dashboard])
    db.session.flush()
    db.session.expire(dashboard, ["slices"])
    member_id = member.id

    positions = {
        "CHART-member": _chart_node("CHART-member", member.id, 4, 50),
        "CHART-bool": _chart_node("CHART-bool", True, 4, 50),
    }

    # A boolean is not a usable chart id. On the membership-rebuilding save path,
    # an unresolvable id is rejected (cannot silently detach), not coerced to 1.
    with pytest.raises(DashboardInvalidError):
        DashboardDAO.set_dash_metadata(dashboard, {"positions": positions})

    # Membership is left untouched by the refusal.
    assert {chart.id for chart in dashboard.slices} == {member_id}


# --------------------------------------------------------------------------- #
# Criterion 5 — a non-dict / malformed layout payload is tolerated without
# crashing. Driven through UpdateDashboardCommand.run with a raw position_json
# whose value is valid JSON but not an object ("null", a scalar). The command's
# save path walks the dashboard's stored tabs against the incoming layout; when
# that incoming value is not a mapping, the walk must not blow up. A stored
# layout that actually declares a tab is seeded first, so the walk has tab keys
# to compare (an empty tab set would never reach the comparison and would hide
# the regression). The save must complete and persist the value unchanged.
# --------------------------------------------------------------------------- #
def _tabbed_layout() -> dict[str, Any]:
    """A minimal stored layout that declares exactly one tab.

    Only the tab-bearing shape matters here: a ROOT that holds a tab bar, a tab
    bar that holds one titled tab. This is the repo's own persisted layout
    shape, not anything the fix introduces.
    """
    return {
        "ROOT_ID": {"id": "ROOT_ID", "type": "ROOT", "children": ["TABS-1"]},
        "TABS-1": {"id": "TABS-1", "type": "TABS", "children": ["TAB-1"]},
        "TAB-1": {
            "id": "TAB-1",
            "type": "TAB",
            "children": [],
            "meta": {"text": "Tab one"},
        },
    }


@pytest.mark.parametrize("raw_layout", ["null", "5"])
def test_update_command_tolerates_non_dict_layout(
    session: Any, raw_layout: str
) -> None:
    from superset import db
    from superset.commands.dashboard.update import UpdateDashboardCommand
    from superset.models.dashboard import Dashboard
    from superset.utils import json as superset_json

    _create_all(session)
    dashboard = Dashboard(
        dashboard_title="nondict_dash",
        slices=[],
        published=True,
        position_json=superset_json.dumps(_tabbed_layout()),
    )
    db.session.add(dashboard)
    db.session.flush()

    command = UpdateDashboardCommand(dashboard.id, {"position_json": raw_layout})
    command._model = dashboard  # pre-resolve the model; validation tested elsewhere
    from unittest.mock import patch

    with patch.object(command, "validate"):
        # Must not raise on a non-dict layout even though a tab is stored.
        command.run()
    db.session.flush()

    # The non-dict layout was accepted and persisted as-is (not mangled into a
    # dict); the save path did not crash on the stored-tab comparison.
    assert superset_json.loads(dashboard.position_json) == superset_json.loads(
        raw_layout
    )


# --------------------------------------------------------------------------- #
# Criterion 6 — updating a dashboard via the command (the layer the PUT endpoint
# drives) reconciles a layout referencing an absent chart. The write path, not
# an isolated helper, performs reconciliation.
# --------------------------------------------------------------------------- #
def test_update_command_reconciles_absent_chart(session: Any) -> None:
    from superset import db
    from superset.commands.dashboard.update import UpdateDashboardCommand
    from superset.models.dashboard import Dashboard
    from superset.utils import json as superset_json

    _create_all(session)
    dataset = _seed_dataset("update_db", "update_table")
    live = _new_chart("update_live", dataset)
    dashboard = Dashboard(dashboard_title="update_dash", slices=[live], published=True)
    db.session.add_all([live, dashboard])
    db.session.flush()
    db.session.expire(dashboard, ["slices"])

    absent_id = 987_654_321
    positions = {
        "CHART-live": _chart_node("CHART-live", live.id, 4, 50),
        "CHART-gone": _chart_node("CHART-gone", absent_id, 6, 30),
    }
    payload = superset_json.dumps({"positions": positions})

    command = UpdateDashboardCommand(dashboard.id, {"json_metadata": payload})
    command._model = dashboard
    from unittest.mock import patch

    with patch.object(command, "validate"):
        command.run()
    db.session.flush()
    db.session.expire(dashboard, ["position_json", "slices"])

    saved = superset_json.loads(dashboard.position_json)
    # The write path reconciled: the absent tile is no longer a live chart tile
    # and the absent id is gone from persisted layout + membership.
    assert not _is_live_chart_tile(saved["CHART-gone"]), saved["CHART-gone"]
    assert _is_live_chart_tile(saved["CHART-live"]), saved["CHART-live"]
    member_ids = {chart.id for chart in dashboard.slices}
    assert absent_id not in member_ids
    assert live.id in member_ids


# --------------------------------------------------------------------------- #
# Criterion 7 — updating with a MALFORMED chart node is rejected (422-equivalent:
# a DashboardInvalidError / subclass) and membership is left unchanged (the chart
# is not silently detached).
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize(
    "bad_meta",
    [
        {"chartId": "CHART-bad", "width": 4, "height": 50},  # non-coercible string
        {"chartId": [1], "width": 4, "height": 50},  # non-scalar
        {"chartId": 1.25, "width": 4, "height": 50},  # fractional float
    ],
)
def test_update_command_rejects_malformed_node_without_detaching(
    session: Any, bad_meta: dict[str, Any]
) -> None:
    from superset import db
    from superset.commands.dashboard.exceptions import DashboardInvalidError
    from superset.commands.dashboard.update import UpdateDashboardCommand
    from superset.models.dashboard import Dashboard
    from superset.utils import json as superset_json

    _create_all(session)
    dataset = _seed_dataset("malformed_db", "malformed_table")
    member = _new_chart("malformed_member", dataset)
    dashboard = Dashboard(
        dashboard_title="malformed_dash", slices=[member], published=True
    )
    db.session.add_all([member, dashboard])
    # Commit the baseline membership. The command runs in a unit-of-work that
    # rolls back on error (its ``@transaction`` wrapper), so a committed
    # baseline is what "membership unchanged" must be measured against — an
    # uncommitted baseline would simply be discarded by the rollback and make
    # the post-rejection read meaningless.
    db.session.commit()
    member_id = member.id

    positions = {
        "CHART-ok": _chart_node("CHART-ok", member.id, 4, 50),
        "CHART-bad": {
            "type": "CHART",
            "id": "CHART-bad",
            "children": [],
            "meta": bad_meta,
        },
    }
    payload = superset_json.dumps({"positions": positions})

    command = UpdateDashboardCommand(dashboard.id, {"json_metadata": payload})
    command._model = dashboard
    from unittest.mock import patch

    with patch.object(command, "validate"):
        with pytest.raises(DashboardInvalidError):
            command.run()

    # The refusal did not touch membership — the chart was not detached. Read it
    # back from the committed state (the rollback reverted any partial work).
    db.session.expire(dashboard, ["slices"])
    assert {chart.id for chart in dashboard.slices} == {member_id}


# --------------------------------------------------------------------------- #
# Criterion 8 — duplicating a dashboard does not carry a dangling reference into
# the copy, and a layout naming a live non-member chart fails the copy closed
# (422-equivalent). Driven through DashboardDAO.copy_dashboard, patching the
# editor check + request global exactly as the repo's own copy unit test does.
# --------------------------------------------------------------------------- #
def test_copy_dashboard_reconciles_absent_reference(session: Any) -> None:
    from unittest.mock import patch

    from superset import db
    from superset.daos.dashboard import DashboardDAO
    from superset.models.dashboard import Dashboard
    from superset.utils import json as superset_json

    _create_all(session)
    dataset = _seed_dataset("copy_db", "copy_table")
    live = _new_chart("copy_live", dataset)
    source = Dashboard(dashboard_title="copy_source", slices=[live])
    db.session.add_all([live, source])
    db.session.flush()

    absent_id = 987_654_321
    positions = {
        "CHART-live": _chart_node("CHART-live", live.id, 4, 50),
        "CHART-gone": _chart_node("CHART-gone", absent_id, 6, 30),
    }
    source.position_json = superset_json.dumps(positions)
    db.session.flush()

    with (
        patch("superset.daos.dashboard.security_manager.is_editor", return_value=True),
        patch("superset.daos.dashboard.g") as mock_g,
    ):
        mock_g.user = None
        copied = DashboardDAO.copy_dashboard(
            source,
            {
                "dashboard_title": "copy_result",
                "json_metadata": superset_json.dumps({"positions": positions}),
                "duplicate_slices": True,
            },
        )

    copied_layout = copied.position
    # The copy's slot for the dangling reference is reconciled so it no longer
    # presents as a live chart tile: the slot survives but stops claiming a chart.
    # We gate via ``_is_live_chart_tile`` — a node is still a live chart tile iff
    # ``type == "CHART"`` AND ``meta.chartId`` is not None; anything else (a
    # non-CHART inert node, or a CHART node whose chart id has been cleared to
    # None) counts as non-live/repaired. This is the same gate the save path uses
    # and is agnostic to whatever inert shape the repair picks. The pre-fix copy
    # code leaves the slot as a live CHART node still carrying the absent chart id
    # (``_is_live_chart_tile`` → True), so a real fix is exactly what flips it off.
    gone_node = copied_layout.get("CHART-gone")
    assert gone_node is not None, copied_layout
    assert not _is_live_chart_tile(gone_node), gone_node
    # Slot geometry is preserved through the reconciliation.
    assert gone_node.get("meta", {}).get("width") == 6, gone_node
    assert gone_node.get("meta", {}).get("height") == 30, gone_node
    # The absent id does not appear in the copy's membership.
    copy_member_ids = {chart.id for chart in copied.slices}
    assert absent_id not in copy_member_ids
    # The live tile copies across as a live chart tile (remapped to a clone).
    live_node = copied_layout.get("CHART-live")
    assert live_node is not None, copied_layout
    assert _is_live_chart_tile(live_node), live_node


def test_copy_dashboard_fails_closed_on_live_non_member(session: Any) -> None:
    from unittest.mock import patch

    from superset import db
    from superset.commands.dashboard.exceptions import (
        DashboardCopyError,
        DashboardInvalidError,
    )
    from superset.daos.dashboard import DashboardDAO
    from superset.models.dashboard import Dashboard
    from superset.utils import json as superset_json

    _create_all(session)
    dataset = _seed_dataset("closed_db", "closed_table")
    member = _new_chart("closed_member", dataset)
    # A live chart that is NOT part of the source dashboard's membership.
    outsider = _new_chart("closed_outsider", dataset)
    source = Dashboard(dashboard_title="closed_source", slices=[member])
    db.session.add_all([member, outsider, source])
    db.session.flush()

    positions = {
        "CHART-member": _chart_node("CHART-member", member.id, 4, 50),
        "CHART-outsider": _chart_node("CHART-outsider", outsider.id, 6, 30),
    }
    source.position_json = superset_json.dumps(positions)
    db.session.flush()

    with (
        patch("superset.daos.dashboard.security_manager.is_editor", return_value=True),
        patch("superset.daos.dashboard.g") as mock_g,
    ):
        mock_g.user = None
        # A live chart outside membership is a closed-copy case (422-equivalent).
        with pytest.raises((DashboardInvalidError, DashboardCopyError)):
            DashboardDAO.copy_dashboard(
                source,
                {
                    "dashboard_title": "closed_result",
                    "json_metadata": superset_json.dumps({"positions": positions}),
                    "duplicate_slices": True,
                },
            )


# A guard so an import/bootstrap failure surfaces as a clear, single failure
# rather than erroring every test opaquely.
def test_public_interfaces_import() -> None:
    importlib.import_module("superset.daos.dashboard")
    importlib.import_module("superset.commands.dashboard.update")
    importlib.import_module("superset.commands.dashboard.exceptions")
    from superset.commands.dashboard.exceptions import DashboardInvalidError
    from superset.daos.dashboard import DashboardDAO

    assert hasattr(DashboardDAO, "set_dash_metadata")
    assert hasattr(DashboardDAO, "copy_dashboard")
    assert issubclass(DashboardInvalidError, Exception)
