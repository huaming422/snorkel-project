## Task

Deleting a chart leaves dead tiles behind on any dashboard that still had it on
the layout, and it gets worse from there. Once someone opens and re-saves one of
those dashboards, the saved layout and the dashboard's actual set of charts stop
agreeing: tiles point at charts that aren't members anymore, or member charts
drop off the layout. Duplicating an affected dashboard just copies the broken
references into the new one. Please dig in and fix it so a dashboard's layout and
its chart membership stay consistent across saves and copies. When a tile points
at a chart that no longer exists, keep that tile in place, same spot and size,
rather than pulling it out and letting the layout reflow to close the gap; the
spot stays but stops claiming the chart that's gone. Tell that case apart from a
tile whose chart reference is plain garbage that can't be read as a chart at all:
a save carrying such an unusable reference should be refused cleanly, not guessed
at, coerced, or quietly dropped from membership. Copying needs the same care: a
duplicate must not inherit broken references, and if the layout names a live chart
that isn't one of the dashboard's members, refuse the copy rather than adopting
that outsider. One more thing on the save side: a layout that
isn't an object at all, such as a null or a bare value rather than a map of
tiles, should be stored as-is rather than choked on.
