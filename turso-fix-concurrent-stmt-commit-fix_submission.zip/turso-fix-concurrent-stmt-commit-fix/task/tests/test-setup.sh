#!/usr/bin/env bash
# test-setup.sh — sourced by tests/test.sh before the verifier runs
# (set -euo pipefail inherited). The agent phase is offline; the image already
# baked the full dependency closure at the base commit (cargo fetch + a
# workspace lib/tests build), so everything here is offline-first.
set -euo pipefail

cd /repo/turso

# Fail fast on any accidental cache miss instead of hanging on a dead network
# during grading (the verifier phase only reaches the model gateway).
export CARGO_NET_OFFLINE=true

# rust-toolchain.toml at /repo/turso pins channel = "1.88.0"; rustup materializes
# it automatically on first cargo invocation. The image pre-fetched all crates
# and pre-built the workspace libs+tests, so this warm build is incremental.
export CARGO_INCREMENTAL=1

# Pre-warm the two test targets the verifier exercises so the verifier's own
# cargo invocation is a near no-op on a warm target/ (and only a few minutes
# cold). Compile-only (--no-run) keeps this fast; the verifier runs the tests.
#   - turso_core lib unit tests (mvcc::database::tests live here)
#   - core_tester integration_tests binary (statement_reset.rs lives here)
cargo test --locked --offline -p turso_core --lib --no-run
cargo test --locked --offline -p core_tester --test integration_tests --no-run
