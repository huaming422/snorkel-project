import type { AcpPermissionRequest, AcpStateSnapshot } from '../../../../shared/acp'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import { createInitialSessionState, useSessionStore } from '../../stores/session-store'
import { respondToWorkspaceElicitation } from './workspace-elicitation-runtime'
import {
  resetWorkspaceRuntimeEventOwnerForTests,
  syncWorkspaceElicitationState,
  syncWorkspacePermissionState
} from './workspace-runtime-event-owner'

const createSnapshot = (sessionIds: string[] = []): AcpStateSnapshot => ({
  status: 'connected',
  cwd: '/workspace/project',
  sessionIds,
  events: [],
  pendingPermissions: [],
  permissionProfiles: {},
  permissionGrants: {},
  contextUsageBySession: {},
  promptInFlight: false,
  promptInFlightSessionIds: []
})

const elicitationRequest = {
  requestId: 'choice-1',
  sessionId: 'session-choice-1',
  toolCallId: 'tool-choice-1',
  message: 'Choose an approach',
  fields: [{ id: 'question_0', label: 'Approach', kind: 'text' as const }],
  durable: { kind: 'agent-user-choice' as const, requestId: 'choice-1' }
}

const statusOf = (sessionId: string): string | undefined =>
  useSessionStore.getState().sessions.find((session) => session.id === sessionId)?.status

describe('interaction-priority runtime reconciliation', () => {
  beforeEach(() => {
    resetWorkspaceRuntimeEventOwnerForTests()
    useSessionStore.setState(createInitialSessionState())
    useSessionStore.getState().appendUserMessage({
      sessionId: 'session-choice-1',
      content: 'Build something',
      cwd: '/workspace/project',
      projectId: 'project-1',
      agentFrameworkId: 'opencode',
      agentBackendId: 'opencode:provider-1'
    })
    useSessionStore.getState().finishRun('session-choice-1')
  })

  afterEach(() => {
    vi.unstubAllGlobals()
  })

  // One session comes back from a restart waiting on a permission and another on a
  // question. Answering the question leaves the first session waiting on its
  // permission, which is still pending.
  it('keeps a restored permission waiting after another session answers its question', async () => {
    const permissionRequest: AcpPermissionRequest = {
      requestId: 'permission-restored',
      sessionId: 'session-permission-1',
      toolCallId: 'tool-permission-1',
      title: 'Run npm test',
      options: [{ optionId: 'allow-once', name: 'Allow once', kind: 'allow_once' }],
      durable: true
    }
    useSessionStore.getState().appendUserMessage({
      sessionId: permissionRequest.sessionId,
      content: 'Run the verification',
      cwd: '/workspace/project',
      projectId: 'project-1'
    })
    useSessionStore.getState().finishRun(permissionRequest.sessionId)
    useSessionStore.setState((state) => ({
      sessions: state.sessions.map((session) =>
        session.id === permissionRequest.sessionId
          ? {
              ...session,
              status: 'waiting-permission',
              runtimeContext: {
                version: 1,
                revision: 1,
                permission: {
                  state: 'pending',
                  request: permissionRequest,
                  originatingPromptMessageId: session.messages[0].id,
                  fingerprint: 'a'.repeat(64),
                  createdAt: 1
                }
              }
            }
          : session
      )
    }))
    syncWorkspacePermissionState([permissionRequest])
    useSessionStore.getState().setElicitationPending('session-choice-1', true)

    await respondToWorkspaceElicitation(
      {
        state: createSnapshot(['session-choice-1']),
        resumeSession: vi.fn(),
        respondToElicitation: vi.fn().mockResolvedValue(createSnapshot(['session-choice-1']))
      },
      {
        requestId: 'choice-1',
        action: 'accept',
        answers: [{ fieldId: 'question_0', value: 'Minimal' }],
        request: {
          requestId: 'choice-1',
          sessionId: 'session-choice-1',
          toolCallId: 'tool-choice-1',
          message: 'Choose an approach',
          fields: [{ id: 'question_0', label: 'Approach', kind: 'text' }],
          durable: { kind: 'agent-user-choice', requestId: 'choice-1' }
        }
      }
    )

    const parked = useSessionStore
      .getState()
      .sessions.find((session) => session.id === permissionRequest.sessionId)
    expect(parked?.status).toBe('waiting-permission')
    expect(parked?.runtimeContext?.permission?.state).toBe('pending')
  })

  // A session with both a permission and a question open is still waiting on the
  // permission after the question is answered.
  it('falls back to a pending permission in the same session after its question is answered', async () => {
    const permissionRequest: AcpPermissionRequest = {
      requestId: 'permission-live',
      sessionId: 'session-choice-1',
      toolCallId: 'tool-permission-live',
      title: 'Run npm test',
      options: [{ optionId: 'allow-once', name: 'Allow once', kind: 'allow_once' }]
    }
    syncWorkspacePermissionState([permissionRequest])
    syncWorkspaceElicitationState([elicitationRequest])
    const continued = {
      ...createSnapshot(['session-choice-1']),
      pendingPermissions: [permissionRequest],
      pendingElicitations: []
    }

    await respondToWorkspaceElicitation(
      {
        state: {
          ...createSnapshot(['session-choice-1']),
          pendingPermissions: [permissionRequest],
          pendingElicitations: [elicitationRequest]
        },
        resumeSession: vi.fn(),
        respondToElicitation: vi.fn().mockResolvedValue(continued)
      },
      {
        requestId: elicitationRequest.requestId,
        action: 'accept',
        answers: [{ fieldId: 'question_0', value: 'Minimal' }],
        request: elicitationRequest
      }
    )

    expect(statusOf('session-choice-1')).toBe('waiting-permission')
  })

  // A question answered before a permission arrives does not come back; once the
  // permission clears too, the session is idle with nothing pending.
  it('does not re-arm an answered question when a permission later becomes pending', () => {
    const request = {
      requestId: 'choice-1',
      sessionId: 'session-choice-1',
      toolCallId: 'tool-choice-1',
      message: 'Choose an approach',
      fields: [{ id: 'question_0', label: 'Approach', kind: 'text' as const }],
      durable: { kind: 'agent-user-choice' as const, requestId: 'choice-1' }
    }
    useSessionStore.setState((state) => ({
      sessions: state.sessions.map((session) =>
        session.id === request.sessionId
          ? {
              ...session,
              status: 'waiting-for-user',
              activities: [
                {
                  id: request.toolCallId,
                  kind: 'tool',
                  title: 'Waiting for an answer',
                  status: 'in_progress',
                  sortIndex: 1,
                  eventIds: [],
                  elicitation: {
                    message: request.message,
                    fields: request.fields,
                    state: 'pending',
                    durable: request.durable
                  },
                  createdAt: Date.now(),
                  updatedAt: Date.now()
                }
              ]
            }
          : session
      )
    }))

    syncWorkspaceElicitationState([request])
    useSessionStore.getState().setElicitationPending(request.sessionId, false)
    useSessionStore.getState().setPermissionPending(request.sessionId)
    syncWorkspaceElicitationState([])
    useSessionStore.getState().clearPermissionPending(request.sessionId)

    const settled = useSessionStore
      .getState()
      .sessions.find((session) => session.id === request.sessionId)
    expect(settled?.status).toBe('idle')
    expect(settled?.runtimeContext?.permission?.state).not.toBe('pending')
  })

  // A durable question that is still unanswered stays open while a permission sits in
  // front of it, even when a runtime sync no longer lists the question. Once the
  // permission goes away the session is back on the question.
  it('keeps an unanswered question behind a permission through a runtime sync', () => {
    const permissionRequest: AcpPermissionRequest = {
      requestId: 'permission-over-question',
      sessionId: 'session-choice-1',
      toolCallId: 'tool-permission-over-question',
      title: 'Run npm test',
      options: [{ optionId: 'allow-once', name: 'Allow once', kind: 'allow_once' }]
    }
    useSessionStore.setState((state) => ({
      sessions: state.sessions.map((session) =>
        session.id === elicitationRequest.sessionId
          ? {
              ...session,
              status: 'waiting-for-user',
              activities: [
                {
                  id: elicitationRequest.toolCallId,
                  kind: 'tool',
                  title: 'Waiting for an answer',
                  status: 'in_progress',
                  sortIndex: 1,
                  eventIds: [],
                  elicitation: {
                    message: elicitationRequest.message,
                    fields: elicitationRequest.fields,
                    state: 'pending',
                    durable: elicitationRequest.durable
                  },
                  createdAt: Date.now(),
                  updatedAt: Date.now()
                }
              ]
            }
          : session
      )
    }))

    syncWorkspaceElicitationState([elicitationRequest])
    syncWorkspacePermissionState([permissionRequest])
    expect(statusOf('session-choice-1')).toBe('waiting-permission')

    syncWorkspaceElicitationState([])
    expect(statusOf('session-choice-1')).toBe('waiting-permission')

    syncWorkspacePermissionState([])
    expect(statusOf('session-choice-1')).toBe('waiting-for-user')
  })
})
