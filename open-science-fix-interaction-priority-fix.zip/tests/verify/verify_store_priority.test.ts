import { beforeEach, describe, expect, it, vi } from 'vitest'

import type { ActivePlanProjection } from '../../../shared/session-plan/contract'
import type { PersistedChatSession } from '../../../shared/session-persistence'
import {
  createInitialSessionState,
  toPersistedSession,
  useSessionStore
} from './session-store'

// A plan waiting for approval, in the shape the store accepts.
const pendingPlan = (artifactVersionId: string): ActivePlanProjection => ({
  artifactId: `artifact-${artifactVersionId}`,
  artifactVersionId,
  artifactChecksum: 'a'.repeat(64),
  revision: 1,
  approval: 'pending',
  lifecycle: 'awaiting_approval',
  requiresExplicitContinuation: false,
  document: {
    schema_version: 1,
    task_summary: `Plan ${artifactVersionId}`,
    phases: [
      {
        name: 'Analysis',
        delegations: [
          {
            name: 'Primary agent',
            steps: [{ title: `Step ${artifactVersionId}`, description: 'Do the work.' }]
          }
        ]
      }
    ],
    desired_outputs: [],
    feasibility: { confidence: 'high', rationale: 'Inputs are available.' }
  },
  stepStatuses: {},
  stepStates: { Step: { status: 'not_started' } },
  counts: { phases: 1, delegations: 1, steps: 1, completed: 0, inProgress: 0 }
})

const statusOf = (sessionId: string): string | undefined =>
  useSessionStore.getState().sessions.find((session) => session.id === sessionId)?.status

const definedKeys = (record: object): string[] =>
  Object.entries(record)
    .filter(([, value]) => value !== undefined)
    .map(([key]) => key)
    .sort()

describe('interaction-priority store projections', () => {
  beforeEach(() => {
    vi.useFakeTimers()
    vi.setSystemTime(new Date('2026-07-04T08:00:00.000Z'))
    useSessionStore.setState(createInitialSessionState())
  })

  // A permission outranks a pending plan approval whichever arrived first, and
  // clearing the permission shows the plan approval again.
  it('shows the permission ahead of a pending plan in either arrival order, then reveals the plan once it clears', () => {
    useSessionStore.getState().appendUserMessage({
      sessionId: 'session-1',
      content: 'Run the workflow',
      cwd: '/workspace',
      projectId: 'project-1'
    })
    useSessionStore.getState().setActivePlanProjection('session-1', pendingPlan('version-1'))
    expect(statusOf('session-1')).toBe('waiting-plan-approval')

    useSessionStore.getState().setPermissionPending('session-1')
    expect(statusOf('session-1')).toBe('waiting-permission')

    useSessionStore.getState().clearPermissionPending('session-1')
    expect(statusOf('session-1')).toBe('waiting-plan-approval')

    // Same rule when the plan approval shows up after the permission.
    useSessionStore.getState().appendUserMessage({
      sessionId: 'session-2',
      content: 'Run the workflow',
      cwd: '/workspace',
      projectId: 'project-1'
    })
    useSessionStore.getState().setPermissionPending('session-2')
    expect(statusOf('session-2')).toBe('waiting-permission')
    useSessionStore.getState().setActivePlanProjection('session-2', pendingPlan('version-2'))
    expect(statusOf('session-2')).toBe('waiting-permission')
    useSessionStore.getState().clearPermissionPending('session-2')
    expect(statusOf('session-2')).toBe('waiting-plan-approval')
  })

  // A plan approved while a permission was in front stays settled, so clearing
  // the permission leaves the session idle.
  it('returns to idle when the permission clears after its plan already settled', () => {
    useSessionStore.getState().hydrateSessions([
      {
        id: 'session-1',
        projectId: 'project-1',
        title: 'Plan approval',
        cwd: '/workspace',
        status: 'waiting-plan-approval',
        runtimeContext: {
          version: 1,
          revision: 1,
          plan: {
            artifactId: 'plan-1',
            artifactVersionId: 'plan-version-1',
            artifactChecksum: 'a'.repeat(64),
            approval: 'pending',
            stepStatuses: {}
          }
        },
        messages: [],
        createdAt: 1,
        updatedAt: 2
      }
    ])
    useSessionStore.getState().setPermissionPending('session-1')
    const source = useSessionStore.getState().sessions[0]
    expect(source.status).toBe('waiting-permission')

    // A durable projection arrives with the plan approved (settled) while the
    // permission is still outstanding; the permission must stay in front.
    useSessionStore.getState().applyDurableSessionProjection({
      source,
      session: {
        ...toPersistedSession(source),
        status: 'idle',
        runtimeContext: {
          version: 1,
          revision: 2,
          plan: {
            artifactId: 'plan-1',
            artifactVersionId: 'plan-version-1',
            artifactChecksum: 'a'.repeat(64),
            approval: 'approved',
            stepStatuses: {}
          }
        },
        updatedAt: source.updatedAt + 10
      }
    })
    expect(statusOf('session-1')).toBe('waiting-permission')

    useSessionStore.getState().clearPermissionPending('session-1')
    expect(statusOf('session-1')).toBe('idle')
  })

  // A permission that arrives while a question is open goes in front of it.
  // Clearing the permission brings the question back, and answering the question
  // leaves the session idle.
  it('puts a later permission ahead of an open question and returns to the question after it clears', () => {
    useSessionStore.getState().appendUserMessage({
      sessionId: 'session-1',
      content: 'Run the workflow',
      cwd: '/workspace',
      projectId: 'project-1'
    })
    useSessionStore.getState().finishRun('session-1')
    expect(statusOf('session-1')).toBe('idle')

    useSessionStore.getState().setElicitationPending('session-1', true)
    expect(statusOf('session-1')).toBe('waiting-for-user')

    useSessionStore.getState().setPermissionPending('session-1')
    expect(statusOf('session-1')).toBe('waiting-permission')

    useSessionStore.getState().clearPermissionPending('session-1')
    expect(statusOf('session-1')).toBe('waiting-for-user')

    useSessionStore.getState().setElicitationPending('session-1', false)
    expect(statusOf('session-1')).toBe('idle')
  })

  // A question outranks a pending plan approval no matter which arrived first,
  // and answering it shows the plan approval that is still open.
  it('shows an open question ahead of a pending plan in either arrival order', () => {
    for (const sessionId of ['plan-first', 'question-first']) {
      useSessionStore.getState().appendUserMessage({
        sessionId,
        content: 'Run the workflow',
        cwd: '/workspace',
        projectId: 'project-1'
      })
      useSessionStore.getState().finishRun(sessionId)
    }

    useSessionStore.getState().setActivePlanProjection('plan-first', pendingPlan('version-a'))
    expect(statusOf('plan-first')).toBe('waiting-plan-approval')
    useSessionStore.getState().setElicitationPending('plan-first', true)
    expect(statusOf('plan-first')).toBe('waiting-for-user')
    useSessionStore.getState().setElicitationPending('plan-first', false)
    expect(statusOf('plan-first')).toBe('waiting-plan-approval')

    useSessionStore.getState().setElicitationPending('question-first', true)
    useSessionStore.getState().setActivePlanProjection('question-first', pendingPlan('version-b'))
    expect(statusOf('question-first')).toBe('waiting-for-user')
    useSessionStore.getState().setElicitationPending('question-first', false)
    expect(statusOf('question-first')).toBe('waiting-plan-approval')
  })

  // A restored session that was waiting on a permission and a question shows the
  // permission first and the question once the permission settles. Loading and
  // saving it again gives back only fields the saved record already had.
  it('restores a permission ahead of a question and saves back only the loaded fields', () => {
    const restored: PersistedChatSession = {
      id: 'session-restored',
      projectId: 'project-1',
      title: 'Restored interactions',
      cwd: '/workspace',
      status: 'waiting-permission',
      runtimeContext: {
        version: 1,
        revision: 1,
        permission: {
          state: 'pending',
          request: {
            requestId: 'permission-restored',
            sessionId: 'session-restored',
            toolCallId: 'permission-tool',
            title: 'Run npm test',
            options: [{ optionId: 'allow-once', name: 'Allow once', kind: 'allow_once' }]
          },
          originatingPromptMessageId: 'prompt-1',
          fingerprint: 'a'.repeat(64),
          createdAt: 1
        }
      },
      messages: [
        {
          id: 'prompt-1',
          role: 'user',
          content: 'Run the workflow',
          status: 'complete',
          eventIds: [],
          createdAt: 1,
          updatedAt: 1
        }
      ],
      activities: [
        {
          id: 'ask-tool',
          kind: 'tool',
          title: 'Choose an approach',
          status: 'in_progress',
          eventIds: [],
          sortIndex: 1,
          elicitation: {
            message: 'Choose an approach',
            fields: [{ id: 'question_0', label: 'Approach', kind: 'text' }],
            state: 'pending',
            durable: { kind: 'agent-user-choice', requestId: 'choice-restored' }
          },
          createdAt: 1,
          updatedAt: 1
        }
      ],
      createdAt: 1,
      updatedAt: 2
    }

    useSessionStore.getState().hydrateSessions([restored])

    // Permission outranks the question: the reconstructed status is the permission.
    expect(statusOf('session-restored')).toBe('waiting-permission')

    // Saving the restored session again adds nothing the saved record did not have.
    // permissionProfile and conversationGraph are filled in on load by the app already.
    const persisted = toPersistedSession(useSessionStore.getState().sessions[0])
    const allowedKeys = new Set([...definedKeys(restored), 'permissionProfile', 'conversationGraph'])
    expect(definedKeys(persisted).filter((key) => !allowedKeys.has(key))).toEqual([])
    expect(persisted.status).toBe('waiting-permission')
    expect(persisted.activities).toEqual(restored.activities)
    expect(persisted.messages).toEqual(restored.messages)

    // Settling the permission shows the restored question instead of going idle.
    useSessionStore.getState().clearPermissionPending('session-restored', { authority: 'settled' })
    expect(statusOf('session-restored')).toBe('waiting-for-user')
  })

  // A restored session waiting on a permission while its plan approval is still
  // pending shows the plan approval once the permission settles.
  it('reveals a restored pending plan approval after the restored permission settles', () => {
    useSessionStore.getState().hydrateSessions([
      {
        id: 'session-plan',
        projectId: 'project-1',
        title: 'Restored permission and plan',
        cwd: '/workspace',
        status: 'waiting-permission',
        runtimeContext: {
          version: 1,
          revision: 1,
          permission: {
            state: 'pending',
            request: {
              requestId: 'permission-plan',
              sessionId: 'session-plan',
              toolCallId: 'permission-tool',
              title: 'Run npm test',
              options: [{ optionId: 'allow-once', name: 'Allow once', kind: 'allow_once' }]
            },
            originatingPromptMessageId: 'prompt-1',
            fingerprint: 'b'.repeat(64),
            createdAt: 1
          },
          plan: {
            artifactId: 'plan-1',
            artifactVersionId: 'plan-version-1',
            artifactChecksum: 'a'.repeat(64),
            approval: 'pending',
            stepStatuses: {}
          }
        },
        messages: [
          {
            id: 'prompt-1',
            role: 'user',
            content: 'Run the workflow',
            status: 'complete',
            eventIds: [],
            createdAt: 1,
            updatedAt: 1
          }
        ],
        createdAt: 1,
        updatedAt: 2
      }
    ])
    expect(statusOf('session-plan')).toBe('waiting-permission')

    useSessionStore.getState().clearPermissionPending('session-plan', { authority: 'settled' })
    expect(statusOf('session-plan')).toBe('waiting-plan-approval')
  })
})
