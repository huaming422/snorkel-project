#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier runs (set -euo pipefail inherited).
# The image baked node_modules at the base commit (Dockerfile block 10, `npm ci`);
# this step brings them online offline-first and must succeed with the network cut.
cd /repo/open-science

# Fail fast on a cache miss instead of reaching for the registry (offline fold).
export npm_config_offline=true
export npm_config_update_notifier=false npm_config_fund=false npm_config_audit=false
export npm_config_cache=/opt/cache/npm

# Dependencies: offline-first against the image bake, logged online fallback.
# The two branches are the same resolve (npm ci) differing only by the offline
# switch — one dependency-resolving attempt per the [sync] lint.
if npm ci > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] node deps satisfied from image bake"
elif npm_config_offline=false npm ci >> /tmp/test-setup-install.log 2>&1; then
    echo "[test-setup] node deps installed online (image bake was stale)"
else
    tail -40 /tmp/test-setup-install.log >&2
    exit 1
fi

# vitest is a dev dependency installed by `npm ci`; confirm it resolves so the
# verifier's runner invocation does not fail opaquely.
node -e "require.resolve('vitest/package.json')" \
    || { echo "[test-setup] vitest is not resolvable after install" >&2; exit 1; }

# No assertion logic here, and no services to start — the renderer store and
# runtime-event modules under test are pure and run under jsdom via vitest.
