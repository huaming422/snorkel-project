## Task

The desktop app loses track of what a session is waiting on when more than one kind of prompt is involved. The worst case shows up after a relaunch. Two sessions come back, one held on a tool permission and the other on a question from the agent. Answering that question clears the first session's "waiting for you" badge in the sidebar, its tool stays blocked with the approve and deny buttons gone, and nothing short of another restart brings them back.

A session can be held by a tool permission, an agent question and a plan approval at the same time, in any order and across restarts. What should happen:

- The sidebar shows one waiting state per session, picked in this order: permission, then question, then plan approval. With none of them open, the session goes back to running or idle.
- Settling one prompt never wipes out another that is still open. Answer a question in a session that also has a pending permission and it stays on the permission. Resolve a permission and any question or plan approval still open in that session shows up again. A prompt that got answered or approved while something else was in front stays settled and does not come back.
- Whatever happens in one session leaves the other sessions' waiting states alone, including permissions restored at startup.
- After a relaunch, each restored session shows the right waiting state based on its saved permission, question and plan records, and resolving the top one reveals the next one still pending. Which prompt is in front is live state only: loading a saved session and saving it again without changes writes back the same fields it was loaded with.
- While the main conversation is waiting on a plan approval, starting a side chat is blocked, the same as for a pending permission or question.
