#!/usr/bin/env bash
# Environment bootstrap for the verifier.
#
# claudian is tested with ts-jest, which transforms TypeScript on the fly, so
# there is no dist/ build step: a src/ edit is visible to jest immediately. The
# image already ran `npm ci` at the base commit (offline agent phase), so the
# full dependency closure — including ts-jest and jest — is present. This
# script only re-asserts that closure and installs the TOML shim the harbor
# runner needs to read verify.toml.
#
# Sourced (not exec'd) by the harbor runner so env vars set here stay live for
# the verifier subprocess.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/claudian}"
export REPO_DIR
cd "$REPO_DIR"

# harbor's js runner reads verify.toml via tomllib (Python 3.11+) or tomli
# (<=3.10). The Ubuntu 22.04 base ships Python 3.10 with neither, so install
# tomli defensively. Without it, verify.toml is silently dropped and the runner
# falls back to its default invocation, which does not match this repo's jest
# setup. This step may use the network (the verifier phase has it); the agent
# phase does not and never runs this script.
if ! python3 -c "import tomllib" >/dev/null 2>&1 && \
   ! python3 -c "import tomli"   >/dev/null 2>&1; then
    python3 -m pip install --quiet "tomli==2.0.1" \
        || python3 -m pip install --break-system-packages --quiet "tomli==2.0.1" \
        || true
fi

# Sanity check: jest and ts-jest must be resolvable from the workspace. A
# failure here points at a corrupted node_modules — bailing now with a clear
# message beats a confusing "jest: not found" inside the runner. The reinstall
# is offline-first: npm ci reuses the warm cache baked into the image.
if ! [ -x node_modules/.bin/jest ] || ! [ -d node_modules/ts-jest ]; then
    echo "test-setup.sh: jest/ts-jest missing from node_modules. Re-running npm ci." >&2
    npm ci --prefer-offline --no-audit --cache /opt/cache/npm
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR jest=$(node_modules/.bin/jest --version 2>/dev/null || echo unknown)"
