// @ts-nocheck
import * as fs from 'node:fs';
import * as path from 'node:path';

import { testDate } from '@test/helpers/testClock';

import {
  parseGrokHistoryContent,
  resolveGrokPromptIndexAfterAssistant,
} from '@/providers/grok/history/GrokHistoryStore';

const compactCompleted = {
  method: 'x.ai/session/update',
  params: {
    sessionId: 'session-existing',
    update: {
      sessionUpdate: 'auto_compact_completed',
      tokens_before: 120000,
      tokens_after: 18000,
      elapsed_ms: 1200,
      summary_preview: null,
    },
    _meta: {
      eventId: 'compact-event',
      promptId: 'compact-prompt',
    },
  },
} as const;

describe('Grok compaction boundaries', () => {
  const time = testDate().getTime();
  const complete = compactCompleted.params.update;
  const user = { sessionUpdate: 'user_message_chunk', messageId: 'u1', content: { type: 'text', text: 'Question' } };
  const answer = { sessionUpdate: 'agent_message_chunk', messageId: 'a1', content: { type: 'text', text: 'Answer' } };
  const end = { sessionUpdate: 'turn_completed', prompt_id: 'p1', stop_reason: 'end_turn' };
  const history = (updates: Record<string, unknown>[]) => updates.map((update, index) => JSON.stringify({
    method: 'x.ai/session/update', timestamp: time + index, params: { sessionId: 'session-existing', update },
  })).join('\n');

  it('restores a standalone manual compact without inventing a user turn or rewind checkpoint', () => {
    const messages = parseGrokHistoryContent(history([user, answer, end, complete]), 'session-existing').messages;
    expect(messages).toHaveLength(3);
    expect(messages[2]).toMatchObject({ role: 'assistant', content: '', contentBlocks: [{ type: 'context_compacted' }], timestamp: time + 3 });
    expect(messages[2].assistantMessageId).toBeUndefined();
    expect(parseGrokHistoryContent(history([user, answer, end, complete]), 'session-existing', 'p1').messages).toHaveLength(2);
  });

  it('retains an automatic boundary between text blocks inside its turn', () => {
    const messages = parseGrokHistoryContent(history([user, answer, complete, answer, end]), 'session-existing').messages;
    expect(messages[1].contentBlocks).toEqual([
      { type: 'text', content: 'Answer' }, { type: 'context_compacted' }, { type: 'text', content: 'Answer' },
    ]);
  });

  it('drops a standalone boundary when rewinding before it without shifting prompt indexes', () => {
    const content = history([user, answer, end, complete,
      { sessionUpdate: 'rewind_marker', target_prompt_index: 1 },
      { ...user, messageId: 'u2' }, { ...answer, messageId: 'a2' }, { ...end, prompt_id: 'p2' },
    ]);
    expect(parseGrokHistoryContent(content, 'session-existing').messages.map(message => message.id)).toEqual(['u1', 'a1', 'u2', 'a2']);
    expect(resolveGrokPromptIndexAfterAssistant(content, 'session-existing', 'a2')).toBe(2);
  });

  it('keeps the prompts after a standalone compact at their native rewind positions', () => {
    // Native prompt indexes count u1 and u2 only, so a rewind to index 2 keeps both turns.
    const content = history([user, answer, end, complete,
      { ...user, messageId: 'u2' }, { ...answer, messageId: 'a2' }, { ...end, prompt_id: 'p2' },
      { sessionUpdate: 'rewind_marker', target_prompt_index: 2 },
    ]);
    const messages = parseGrokHistoryContent(content, 'session-existing').messages;
    expect(messages.filter(message => message.role === 'user').map(message => message.id)).toEqual(['u1', 'u2']);
    expect(messages.flatMap(message => message.contentBlocks ?? []).filter(block => block.type === 'context_compacted')).toHaveLength(1);
  });

  it.each(['auto_compact_started', 'auto_compact_failed', 'auto_compact_cancelled'])(
    'does not restore a success divider from %s', sessionUpdate => {
      const messages = parseGrokHistoryContent(history([user, { sessionUpdate }, answer, end]), 'session-existing').messages;
      expect(messages.flatMap(message => message.contentBlocks ?? []).some(block => block.type === 'context_compacted')).toBe(false);
    },
  );
});
