// @ts-nocheck
import { readFileSync } from 'node:fs';

import { capturedSelectionPrompt, capturedSelections } from '@test/helpers/capturedSelections';
import { testDate } from '@test/helpers/testClock';

const mockLoadGrokPromptIndexAfterAssistant = jest.fn();
const mockResolveGrokSessionDirectory = jest.fn();

jest.mock('@/providers/grok/history/GrokHistoryStore', () => ({
  ...jest.requireActual('@/providers/grok/history/GrokHistoryStore'),
  loadGrokPromptIndexAfterAssistant: (...args: unknown[]) => (
    mockLoadGrokPromptIndexAfterAssistant(...args)
  ),
}));
jest.mock('@/providers/grok/history/GrokHistoryPathResolver', () => ({
  ...jest.requireActual('@/providers/grok/history/GrokHistoryPathResolver'),
  resolveGrokSessionDirectory: (...args: unknown[]) => mockResolveGrokSessionDirectory(...args),
}));

import type {
  ProviderExecutionEvent,
  ProviderExecutionRequest,
  ProviderInteractionPort,
  ProviderSessionConfig,
} from '@/core/execution';
import {
  isRewindableExecutionSession,
  isSteerableExecutionSession,
} from '@/core/execution';
import type { ProviderHost } from '@/core/providers/ProviderHost';
import type {
  ACPLoadSessionRequest,
  ACPNewSessionRequest,
  ACPPromptRequest,
  ACPSessionModelState,
  ACPSessionNotification,
  ACPSetSessionModelRequest,
  ACPSetSessionModelResponse,
  ACPSetSessionModeRequest,
} from '@/providers/acp';
import {
  GrokExecutionBackend,
  type GrokExecutionNativeConnection,
  type GrokExecutionNativeCreateOptions,
  type GrokExecutionNativeFactory,
} from '@/providers/grok/execution/GrokExecutionBackend';
import type { GrokDiscoveredModel } from '@/providers/grok/models';
import {
  updateCurrentGrokCatalog,
  updateGrokProviderSettings,
} from '@/providers/grok/settings';

const compactCompleted = {
  method: 'x.ai/session/update',
  params: {
    sessionId: 'session-existing',
    update: {
      sessionUpdate: 'auto_compact_completed',
      tokens_before: 120000,
      tokens_after: 18000,
      elapsed_ms: 1200,
      summary_preview: null,
    },
    _meta: {
      eventId: 'compact-event',
      promptId: 'compact-prompt',
    },
  },
} as const;

function createGrokHost(model = 'grok-4'): ProviderHost {
  const host = { getResolvedProviderCliPath: async () => 'grok', settings: { model: `grok/${model}`, providerConfigs: { grok: { enabled: true, visibleModels: [model, "grok-3"] } } } } as unknown as ProviderHost;
  updateCurrentGrokCatalog(host.settings, { defaultModelId: model, fingerprint: 'fixture', refreshedAt: 1, models: [{ rawId: "grok-3", displayName: "Grok 3", supportsReasoning: false, reasoningEfforts: [] }, { rawId: model, displayName: model, supportsReasoning: true, reasoningEfforts: [] }] });
  return host;
}

const interactionPort: ProviderInteractionPort = {
  askUserQuestion: jest.fn(),
  dismissInteraction: jest.fn(),
  requestApproval: jest.fn(),
};

const sessionConfig: ProviderSessionConfig = {
  interactionPort,
  lifecycle: 'persistent',
  nativePersistence: 'enabled',
  resumeSeed: {
    providerSessionId: 'session-existing',
    providerState: { sessionDirectory: '/tmp/grok-session' },
  },
  vaultWorkingDirectory: '/tmp/vault',
};

function forkSessionConfig(): ProviderSessionConfig {
  return {
    ...sessionConfig,
    resumeSeed: {
      providerState: {
        forkSource: { resumeAt: 'assistant-source', sessionId: 'session-source' },
        forkSourceSessionDirectory: '/tmp/grok-source/session-source',
        futureState: { retained: true },
      },
    },
  };
}

function executionRequest(text = 'hello'): ProviderExecutionRequest {
  return {
    configuration: {
      permissionMode: 'normal',
      model: 'grok/grok-4',
      reasoning: 'high',
      systemInstructions: { kind: 'explicit', instructions: 'Be exact.' },
    },
    input: [{ text, type: 'text' }],
    signal: new AbortController().signal,
    toolPolicy: { kind: 'provider-default' },
  };
}

function grok45Request(reasoning: string): ProviderExecutionRequest {
  const request = executionRequest();
  return {
    ...request,
    configuration: {
      ...request.configuration,
      model: 'grok/grok-4.5',
      reasoning,
    },
  };
}

function createGrok45Host(): ProviderHost { return createGrokHost('grok-4.5'); }

function persistGrok45Catalog(
  host: ProviderHost,
  models: GrokDiscoveredModel[] = [{
    displayName: 'Grok 4.5',
    rawId: 'grok-4.5',
    reasoningMetadataResolved: true,
    reasoningEfforts: [
      { label: 'High', value: 'high' },
      { label: 'Medium', value: 'medium' },
      { label: 'Low', value: 'low' },
    ],
    supportsReasoning: true,
  }],
): void {
  updateCurrentGrokCatalog(host.settings, {
    defaultModelId: 'grok-4.5',
    fingerprint: 'catalog-fixture',
    models,
    refreshedAt: 1,
  });
}

function featurePermissionRequest(permissionMode: string): ProviderExecutionRequest {
  const base = executionRequest(permissionMode);
  return {
    ...base,
    configuration: {
      model: base.configuration.model,
      permissionMode,
      reasoning: base.configuration.reasoning,
      systemInstructions: base.configuration.systemInstructions,
    },
  };
}

async function collect(events: AsyncIterable<ProviderExecutionEvent>): Promise<ProviderExecutionEvent[]> {
  const collected: ProviderExecutionEvent[] = [];
  for await (const event of events) collected.push(event);
  return collected;
}

interface Deferred<T> {
  readonly promise: Promise<T>;
  reject(reason: unknown): void;
  resolve(value: T): void;
}

function createDeferred<T>(): Deferred<T> {
  let reject!: (reason: unknown) => void;
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((resolvePromise, rejectPromise) => {
    reject = rejectPromise;
    resolve = resolvePromise;
  });
  return { promise, reject, resolve };
}

async function drainMicrotasks(): Promise<void> {
  for (let index = 0; index < 10; index += 1) await Promise.resolve();
}

class FakeNativeConnection implements GrokExecutionNativeConnection {
  readonly loadRequests: ACPLoadSessionRequest[] = [];
  readonly modeRequests: ACPSetSessionModeRequest[] = [];
  readonly modelRequests: ACPSetSessionModelRequest[] = [];
  readonly newRequests: ACPNewSessionRequest[] = [];
  readonly promptRequests: ACPPromptRequest[] = [];
  cancelCalls = 0;
  forkCalls: unknown[] = [];
  initializeCalls = 0;
  interjectCalls: unknown[] = [];
  rewindCalls: unknown[] = [];
  shutdownCalls = 0;
  loadResponse: Awaited<ReturnType<GrokExecutionNativeConnection['loadSession']>> | null = null;
  loadImplementation: (
    request: ACPLoadSessionRequest,
  ) => ReturnType<GrokExecutionNativeConnection['loadSession']> = async request => (
    this.loadResponse ?? { sessionId: request.sessionId }
  );
  private notification: ((value: ACPSessionNotification, source: 'extension' | 'standard') => void)
    | null = null;
  private retainedNotification: ((
    value: ACPSessionNotification,
    source: 'extension' | 'standard',
  ) => void) | null = null;
  private permissionModeChanged: ((mode: 'normal' | 'yolo') => void) | null = null;
  private modelsChanged: ((models: ACPSessionModelState) => void) | null = null;
  private retainedModelsChanged: ((models: ACPSessionModelState) => void) | null = null;
  initializeImplementation: () => Promise<void> = async () => {};
  forkImplementation: (request: {
    newCwd: string;
    sourceSessionId: string;
  }) => Promise<{
    newCwd: string;
    newSessionId: string;
    parentSessionId: string;
  }> = async (request) => ({
    newCwd: request.newCwd,
    newSessionId: 'session-forked',
    parentSessionId: request.sourceSessionId,
  });
  private interjectionListener?: (value: { sessionId: string; interjectionId?: string }) => void;
  onInterjection(listener: (value: { sessionId: string; interjectionId?: string }) => void): () => void {
    this.interjectionListener = listener;
    return () => { this.interjectionListener = undefined; };
  }
  emitInterjection(index = -1): void {
    const request = this.interjectCalls.at(index) as { sessionId: string; interjectionId: string };
    this.interjectionListener?.(request);
  }
  interjectImplementation: () => Promise<void> = async () => {};
  modelImplementation: (
    request: ACPSetSessionModelRequest,
  ) => Promise<ACPSetSessionModelResponse> = async () => ({});
  promptImplementation: () => Promise<{ stopReason: string }> = async () => ({
    stopReason: 'end_turn',
  });
  shutdownImplementation: () => Promise<void> = async () => {};

  cancel(): void {
    this.cancelCalls += 1;
  }

  async initialize(): Promise<void> {
    this.initializeCalls += 1;
    await this.initializeImplementation();
  }

  isAlive(): boolean {
    return true;
  }

  async listCommands(): Promise<[]> {
    return [];
  }

  async fork(request: unknown): Promise<{
    newCwd: string;
    newSessionId: string;
    parentSessionId: string;
  }> {
    this.forkCalls.push(request);
    const source = request as { newCwd: string; sourceSessionId: string };
    return this.forkImplementation(source);
  }

  async interject(request: unknown): Promise<void> {
    this.interjectCalls.push(request);
    await this.interjectImplementation();
  }

  async loadSession(
    request: ACPLoadSessionRequest,
  ): ReturnType<GrokExecutionNativeConnection['loadSession']> {
    this.loadRequests.push(request);
    return this.loadImplementation(request);
  }

  async newSession(request: ACPNewSessionRequest): Promise<{ sessionId: string }> {
    this.newRequests.push(request);
    return { sessionId: 'session-new' };
  }

  onNotification(
    listener: (value: ACPSessionNotification, source: 'extension' | 'standard') => void,
  ): () => void {
    this.notification = listener;
    this.retainedNotification = listener;
    return () => { this.notification = null; };
  }

  onModelsChanged(listener: (models: ACPSessionModelState) => void): () => void {
    this.modelsChanged = listener;
    this.retainedModelsChanged = listener;
    return () => { this.modelsChanged = null; };
  }

  async prompt(request: ACPPromptRequest): Promise<{ stopReason: string }> {
    this.promptRequests.push(request);
    return this.promptImplementation();
  }

  async rewind(request: unknown): Promise<{
    cleanFiles: string[];
    conflicts: [];
    error: null;
    revertedFiles: string[];
    success: boolean;
  }> {
    this.rewindCalls.push(request);
    return {
      cleanFiles: ['note.md'],
      conflicts: [],
      error: null,
      revertedFiles: [],
      success: true,
    };
  }

  onModeChanged(listener: (mode: 'normal' | 'yolo') => void): () => void {
    this.permissionModeChanged = listener;
    return () => { this.permissionModeChanged = null; };
  }

  emitPermissionMode(mode: 'normal' | 'yolo'): void {
    this.permissionModeChanged?.(mode);
  }

  async setMode(request: ACPSetSessionModeRequest): Promise<void> {
    this.modeRequests.push(request);
  }

  async setModel(request: ACPSetSessionModelRequest): Promise<ACPSetSessionModelResponse> {
    this.modelRequests.push(request);
    return this.modelImplementation(request);
  }

  async shutdown(): Promise<void> {
    this.shutdownCalls += 1;
    await this.shutdownImplementation();
  }

  emit(
    update: Record<string, unknown>,
    source: 'extension' | 'standard' = 'standard',
    metadata?: Record<string, unknown>,
  ): void {
    this.notification?.({
      sessionId: 'session-existing',
      update,
      ...(metadata ? { _meta: metadata } : {}),
    } as unknown as ACPSessionNotification, source);
  }

  emitRetained(
    update: Record<string, unknown>,
    source: 'extension' | 'standard' = 'standard',
  ): void {
    this.retainedNotification?.({
      sessionId: 'session-existing',
      update,
    } as unknown as ACPSessionNotification, source);
  }

  emitModelsChanged(models: ACPSessionModelState): void {
    this.modelsChanged?.(models);
  }

  emitRetainedModelsChanged(models: ACPSessionModelState): void {
    this.retainedModelsChanged?.(models);
  }
}

describe('GrokExecutionBackend', () => {

  beforeEach(() => {
    jest.clearAllMocks();
    mockLoadGrokPromptIndexAfterAssistant.mockResolvedValue(3);
    mockResolveGrokSessionDirectory.mockImplementation(
      (_hint: unknown, sessionId: string | undefined) => (
        sessionId ? `/trusted/grok/sessions/${sessionId}` : null
      ),
    );
  });

  it.each([
    ['/compact', '/compact'],
    [' \t/CoMpAcT keep recent edits\nFocus on tests  ', '/compact keep recent edits\nFocus on tests'],
  ])('compacts with only explicit instructions from %j', async (text, command) => {
    const native = new FakeNativeConnection();
    const session = new GrokExecutionBackend(createGrokHost(), {
      nativeFactory: { create: () => native },
    }).createSession(sessionConfig);
    try {
      const events = await collect(session.execute({
        ...executionRequest(text),
        input: [{ type: 'text', text }, { type: 'image', image: {
          id: 'capture', name: 'capture.png', data: 'aW1hZ2U=',
          mediaType: 'image/png', size: 5, source: 'paste',
        } }],
        context: { ...capturedSelections, linkedContent: { path: 'note.md' },
          sessionReferences: [{ id: 'ref', title: 'Review', providerId: 'grok', updatedAt: 'updated', snapshotPath: '/tmp/ref.md' }],
        },
      }).events);
      expect(native.promptRequests).toEqual([{ sessionId: 'session-existing', prompt: [{ type: 'text', text: command }] }]);
      expect(events.at(-1)?.type).toBe('turn_completed');
    } finally { await session.dispose(); }
  });

  it('rejects compact without consuming history that still needs recovery', async () => {
    const native = new FakeNativeConnection();
    const session = new GrokExecutionBackend(createGrokHost(), {
      nativeFactory: { create: () => native },
    }).createSession({ ...sessionConfig, resumeSeed: undefined });
    const conversationHistory = [{ id: 'prior', role: 'user' as const, content: 'Remember prior context', timestamp: testDate().getTime() }];
    try {
      const events = await collect(session.execute({ ...executionRequest('/compact'), conversationHistory }).events);
      // The user sees an error; its wording isn't fixed.
      expect(events.at(-1)).toMatchObject({ type: 'execution_error', message: expect.any(String) });
      expect(native.promptRequests).toEqual([]);
      await collect(session.execute({ ...executionRequest('Continue'), conversationHistory }).events);
      expect(native.promptRequests[0].prompt).toEqual([{ type: 'text', text: expect.stringContaining('Remember prior context') }]);
    } finally { await session.dispose(); }
  });

  // Native SessionUpdate::AutoCompactCompleted is used by both manual and auto compaction.
  // Wire fields follow xai-grok-shell/src/extensions/notification.rs and session/compaction.rs.
  it.each(['auto_compact_completed', 'auto_compact_failed', 'auto_compact_cancelled'])(
    'maps native %s to a success divider only when completed', async sessionUpdate => {
      const native = new FakeNativeConnection();
      native.promptImplementation = async () => {
        const update = { ...compactCompleted.params.update, sessionUpdate };
        native.emit(update, 'extension', compactCompleted.params._meta);
        native.emit(update, 'standard', compactCompleted.params._meta);
        return { stopReason: 'end_turn' };
      };
      const session = new GrokExecutionBackend(createGrokHost(), {
        nativeFactory: { create: () => native },
      }).createSession(sessionConfig);
      try {
        const events = await collect(session.execute(executionRequest('/compact')).events);
        const completed = sessionUpdate === 'auto_compact_completed';
        expect(events.filter(event => event.type === 'context_compacted')).toHaveLength(completed ? 1 : 0);
        // A compaction that didn't complete may end the turn normally or as an error.
        expect(completed ? ['turn_completed'] : ['turn_completed', 'execution_error']).toContain(events.at(-1)?.type);
      } finally { await session.dispose(); }
    },
  );

  // The approval port denies, so prompted requests resolve to reject-once.

  it.each(['redirect', '/compact'])('steers literal text %j with its context and rewinds without creating an unrelated session', async text => {
    const native = new FakeNativeConnection();
    native.promptImplementation = () => new Promise(() => {});
    const session = new GrokExecutionBackend(
      createGrokHost(),
      {
        nativeFactory: { create: () => native },
        resolvePromptIndex: async () => 3,
      },
    ).createSession(sessionConfig);
    const run = session.execute(executionRequest());
    while (native.promptRequests.length === 0) await Promise.resolve();
    if (!isSteerableExecutionSession(session) || !isRewindableExecutionSession(session)) {
      throw new Error('Expected Grok execution capabilities.');
    }

    await expect(session.steer({
      ...executionRequest(text),
      input: [{ type: 'text', text }, { type: 'image', image: {
        id: 'capture', name: 'capture.png', data: 'aW1hZ2U=',
        mediaType: 'image/png', size: 5, source: 'paste',
      } }],
      context: capturedSelections,
    })).resolves.toBe(true);
    run.cancel();
    await collect(run.events);
    await expect(session.previewRewind('user-1', 'assistant-1')).resolves.toMatchObject({
      canRewind: true,
    });

    expect(native.interjectCalls).toHaveLength(1);
    expect(native.interjectCalls[0]).toMatchObject({
      content: [
        { type: 'text', text: `${text}\n\n${capturedSelectionPrompt}` },
        { type: 'image', data: 'aW1hZ2U=', mimeType: 'image/png' },
      ],
    });
    expect(native.rewindCalls).toHaveLength(1);
    expect(native.newRequests).toHaveLength(0);
  });

});
