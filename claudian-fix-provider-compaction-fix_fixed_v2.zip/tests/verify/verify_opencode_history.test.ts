// @ts-nocheck
import { mkdtempSync, rmSync } from 'node:fs';
import * as os from 'node:os';
import * as path from 'node:path';
import { DatabaseSync } from 'node:sqlite';

import { testDate } from '@test/helpers/testClock';

import type * as environmentModule from '@/core/process/env';
import type { ChatMessage } from '@/core/types';
import {
  loadOpencodeSessionMessages,
  loadOpencodeSessionModel,
  mapOpencodeMessages,
  mapOpencodeV2NativeMessages,
  OPENCODE_MESSAGE_ROW_SQL,
} from '@/providers/opencode/history/OpencodeHistoryStore';

// Exercise real SQLite subprocesses without discovering the runner's other Node installations.
jest.mock('@/core/process/env', () => ({
  ...jest.requireActual<typeof environmentModule>('@/core/process/env'),
  findNodeExecutables: () => [process.execPath],
}));

const DIVIDER = '<context compacted>';

// What the chat shows, in order: each text block (or a message's plain content) and each divider.
function visible(messages: ChatMessage[]): string[] {
  return messages.flatMap(message => (message.contentBlocks?.length
    ? message.contentBlocks.map(block => (block.type === 'context_compacted' ? DIVIDER
      : block.type === 'text' ? block.content : `<${block.type}>`))
    : [message.content])).filter(item => item !== '');
}

// A divider shown as a message of its own carries the stored record's time.
function expectDividerTime(messages: ChatMessage[], time: number): void {
  for (const message of messages) {
    if (message.contentBlocks?.length && message.contentBlocks.every(block => block.type === 'context_compacted')) {
      expect(message.timestamp).toBe(time);
    }
  }
}

describe('OpenCode compaction boundaries', () => {
  const created = testDate().getTime();
  it.each(['completed', 'running', 'failed'])('restores only completed V2 compaction (%s)', status => {
    const messages = mapOpencodeV2NativeMessages([
      { id: 'a1', type: 'assistant', time: { created }, content: [{ type: 'text', text: 'Before' }] },
      { id: 'compact', type: 'compaction', time: { created: created + 1 }, status, summary: 'Internal summary', recent: 'Internal context' },
      { id: 'a2', type: 'assistant', time: { created: created + 2 }, content: [{ type: 'text', text: 'After' }] },
    ]);
    expect(visible(messages)).toEqual(status === 'completed' ? ['Before', DIVIDER, 'After'] : ['Before', 'After']);
    expectDividerTime(messages, created + 1);
    expect(JSON.stringify(messages)).not.toContain('Internal');
  });

  it.each(['completed', 'running', 'failed'])('restores only successful V1 summaries (%s)', status => {
    const messages = mapOpencodeMessages([
      { info: { id: 'a1', role: 'assistant', time: { created } }, parts: [{ type: 'text', text: 'Before' }] },
      { info: { id: 'trigger', role: 'user', time: { created: created + 1 } }, parts: [{ type: 'compaction', auto: false }] },
      { info: { id: 'compact', role: 'assistant', summary: true,
        ...(status === 'failed' ? { error: { name: 'AbortedError' } } : {}),
        time: { created: created + 2, ...(status !== 'running' ? { completed: created + 3 } : {}) },
      }, parts: [{ type: 'text', text: 'Internal summary' }] },
      { info: { id: 'u2', role: 'user', time: { created: created + 4 } }, parts: [{ type: 'text', text: 'Continue' }] },
    ]);
    expect(messages.flatMap(message => message.contentBlocks ?? []).filter(block => block.type === 'context_compacted')).toHaveLength(status === 'completed' ? 1 : 0);
    expect(messages.some(message => message.id === 'trigger')).toBe(false);
    expect(JSON.stringify(messages)).not.toContain('Internal summary');
    expect(visible(messages)).toEqual(status === 'completed' ? ['Before', DIVIDER, 'Continue'] : ['Before', 'Continue']);
    expectDividerTime(messages, created + 2);
  });
});
