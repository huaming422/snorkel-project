## Task

We're seeing a group of Pods leak ClusterQueue quota, consuming more than it reserved. Each Pod in a group carries a role-hash annotation naming the role (PodSet) whose reserved quota it runs under, and Kueue removes a Pod's scheduling gate once the group is admitted. The trouble is that a Pod whose role-hash annotation points at a cheaper role than the Pod's actual resource requests still gets ungated and scheduled, so it runs under that cheaper role's reservation while asking for much more than the role was sized for.

Track down why an oversized Pod like that is allowed through on the group ungating path and fix it, so a Pod that doesn't fit the role its annotation names stays gated instead. The honest Pods of the group should ungate and run as they do now.

No need to touch how Workloads get admitted or how single Pods outside a group get ungated. This is a correctness and security problem, not a performance one.
