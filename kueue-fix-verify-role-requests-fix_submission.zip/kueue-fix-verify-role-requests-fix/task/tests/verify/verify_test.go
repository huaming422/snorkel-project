// Copyright 2026 The Kueue Authors.
// SPDX-License-Identifier: Apache-2.0

// Internal-package (pod) behavioral test for the pod-group ungating path.
//
// Every assertion is made THROUGH the pre-existing, stable entry point
// (*Pod).Run(ctx, c, wl, podSetsInfo, recorder, msg) — the ungating entry
// point whose signature is unchanged by the fix. Each test seeds a Workload
// and a group of gated Pods, calls Run, then observes only externally-visible
// state: the persisted scheduling-gate of each Pod (re-read from the client),
// the TYPE of each recorded event (Normal vs Warning), and the returned error.
//
// It deliberately does NOT name or import any helper the fix may introduce,
// does NOT read the Warning event's reason string or message (those are the
// solver's choice), and does NOT touch any opt-in toggle — so any restructuring
// that produces the same observable gate state, event type, and error at the
// Run boundary is accepted.
//
// Being in package pod lets the harness set the unexported group fields
// (isGroup, list) and call the unexported isGated helper to read persisted
// gate state the same way production code does.
package pod

import (
	"errors"
	"testing"

	corev1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/utils/ptr"
	"sigs.k8s.io/controller-runtime/pkg/client"

	kueue "sigs.k8s.io/kueue/apis/kueue/v1beta2"
	vrindexer "sigs.k8s.io/kueue/pkg/controller/core/indexer"
	"sigs.k8s.io/kueue/pkg/podset"
	utiltesting "sigs.k8s.io/kueue/pkg/util/testing"
	utiltestingapi "sigs.k8s.io/kueue/pkg/util/testing/v1beta2"
	testingpod "sigs.k8s.io/kueue/pkg/util/testingjobs/pod"
)

const vrRoleA = "role-a"

func vrRunInfo() []podset.PodSetInfo {
	return []podset.PodSetInfo{{Name: kueue.NewPodSetReference(vrRoleA)}}
}

// vrGatedPod builds a gated group Pod annotated with role-a requesting the given cpu.
func vrGatedPod(name, cpu string) corev1.Pod {
	return *testingpod.MakePod(name, metav1.NamespaceDefault).
		Image("", nil).
		Request(corev1.ResourceCPU, cpu).
		RoleHash(vrRoleA).
		KueueSchedulingGate().
		Obj()
}

// vrGatedGPUPod requests cpu plus a resource the role reserves none of.
func vrGatedGPUPod(name string) corev1.Pod {
	return *testingpod.MakePod(name, metav1.NamespaceDefault).
		Image("", nil).
		Request(corev1.ResourceCPU, "1").
		Request(corev1.ResourceName("nvidia.com/gpu"), "1").
		RoleHash(vrRoleA).
		KueueSchedulingGate().
		Obj()
}

// vrGatedLimitsPod sets an equal request+limit, for a role whose template carries only limits.
func vrGatedLimitsPod(name, cpu string) corev1.Pod {
	return *testingpod.MakePod(name, metav1.NamespaceDefault).
		Image("", nil).
		RequestAndLimit(corev1.ResourceCPU, cpu).
		RoleHash(vrRoleA).
		KueueSchedulingGate().
		Obj()
}

// vrGatedRuntimeClassPod carries RuntimeClass overhead so its effective request exceeds its bare request.
func vrGatedRuntimeClassPod(name string) corev1.Pod {
	p := vrGatedPod(name, "1")
	p.Spec.RuntimeClassName = ptr.To("kata")
	p.Spec.Overhead = corev1.ResourceList{corev1.ResourceCPU: resource.MustParse("500m")}
	return p
}

// vrGatedInitPod puts the oversized request on an init container.
func vrGatedInitPod(name, cpu string) corev1.Pod {
	p := testingpod.MakePod(name, metav1.NamespaceDefault).
		Image("", nil).
		Request(corev1.ResourceCPU, "1").
		RoleHash(vrRoleA).
		KueueSchedulingGate().
		Obj()
	p.Spec.InitContainers = []corev1.Container{{
		Name:  "init",
		Image: p.Spec.Containers[0].Image,
		Resources: corev1.ResourceRequirements{
			Requests: corev1.ResourceList{corev1.ResourceCPU: resource.MustParse(cpu)},
		},
	}}
	return *p
}

// vrGatedSidecarPod puts the oversized request on a restartable init (sidecar) container.
func vrGatedSidecarPod(name, cpu string) corev1.Pod {
	p := testingpod.MakePod(name, metav1.NamespaceDefault).
		Image("", nil).
		Request(corev1.ResourceCPU, "1").
		RoleHash(vrRoleA).
		KueueSchedulingGate().
		Obj()
	always := corev1.ContainerRestartPolicyAlways
	p.Spec.InitContainers = []corev1.Container{{
		Name:          "sidecar",
		Image:         p.Spec.Containers[0].Image,
		RestartPolicy: &always,
		Resources: corev1.ResourceRequirements{
			Requests: corev1.ResourceList{corev1.ResourceCPU: resource.MustParse(cpu)},
		},
	}}
	return *p
}

// vrGatedPodLevelPod puts the oversized request at the pod level.
func vrGatedPodLevelPod(name, cpu string) corev1.Pod {
	p := testingpod.MakePod(name, metav1.NamespaceDefault).
		Image("", nil).
		Request(corev1.ResourceCPU, "1").
		RoleHash(vrRoleA).
		KueueSchedulingGate().
		Obj()
	p.Spec.Resources = &corev1.ResourceRequirements{
		Requests: corev1.ResourceList{corev1.ResourceCPU: resource.MustParse(cpu)},
	}
	return *p
}

func vrWorkloadRequest(cpu string) *kueue.Workload {
	return utiltestingapi.MakeWorkload("wl", metav1.NamespaceDefault).
		PodSets(*utiltestingapi.MakePodSet(kueue.NewPodSetReference(vrRoleA), 2).
			Request(corev1.ResourceCPU, cpu).
			Obj()).
		Obj()
}

func vrWorkloadLimit(cpu string) *kueue.Workload {
	return utiltestingapi.MakeWorkload("wl", metav1.NamespaceDefault).
		PodSets(*utiltestingapi.MakePodSet(kueue.NewPodSetReference(vrRoleA), 2).
			Limit(corev1.ResourceCPU, cpu).
			Obj()).
		Obj()
}

func vrWorkloadNoRequests() *kueue.Workload {
	return utiltestingapi.MakeWorkload("wl", metav1.NamespaceDefault).
		PodSets(*utiltestingapi.MakePodSet(kueue.NewPodSetReference(vrRoleA), 2).Obj()).
		Obj()
}

func vrWorkloadRuntimeClass() *kueue.Workload {
	return utiltestingapi.MakeWorkload("wl", metav1.NamespaceDefault).
		PodSets(*utiltestingapi.MakePodSet(kueue.NewPodSetReference(vrRoleA), 2).
			Request(corev1.ResourceCPU, "1").
			RuntimeClass("kata").
			Obj()).
		Obj()
}

// vrOutcome captures only externally-observable state after a group Run:
// the persisted scheduling-gate of each Pod (keyed by name), per-Pod event
// type counts, and the returned error.
type vrOutcome struct {
	err      error
	gated    map[string]bool
	warnings map[string]int
	normals  map[string]int
}

// vrRunGroup drives (*Pod).Run on a group and re-reads the persisted state.
// initObjects seeds cluster objects AdjustResources reads (LimitRange,
// RuntimeClass); pass none when the role already carries explicit requests.
func vrRunGroup(t *testing.T, wl *kueue.Workload, pods []corev1.Pod, initObjects ...client.Object) vrOutcome {
	t.Helper()

	p := FromObject(&pods[0])
	p.isGroup = true
	p.list.Items = pods

	ctx, _ := utiltesting.ContextWithLog(t)
	clientBuilder := utiltesting.NewClientBuilder()
	if err := SetupIndexes(ctx, utiltesting.AsIndexer(clientBuilder)); err != nil {
		t.Fatalf("could not setup indexes: %v", err)
	}
	kClient := clientBuilder.
		WithIndex(&corev1.LimitRange{}, vrindexer.LimitRangeHasContainerOrPodType, vrindexer.IndexLimitRangeHasContainerOrPodType).
		WithObjects(initObjects...).
		WithLists(&corev1.PodList{Items: pods}).
		Build()
	recorder := &utiltesting.EventRecorder{}

	out := vrOutcome{
		gated:    map[string]bool{},
		warnings: map[string]int{},
		normals:  map[string]int{},
	}
	out.err = p.Run(ctx, kClient, wl, vrRunInfo(), recorder, "")

	for i := range pods {
		got := &corev1.Pod{}
		if err := kClient.Get(ctx, client.ObjectKeyFromObject(&pods[i]), got); err != nil {
			t.Fatalf("get pod %q after Run: %v", pods[i].Name, err)
		}
		out.gated[pods[i].Name] = isGated(got)
	}
	for _, ev := range recorder.RecordedEvents {
		switch ev.EventType {
		case corev1.EventTypeWarning:
			out.warnings[ev.Key.Name]++
		case corev1.EventTypeNormal:
			out.normals[ev.Key.Name]++
		}
	}
	return out
}

func vrAssertGated(t *testing.T, out vrOutcome, name string, want bool) {
	t.Helper()
	if got, ok := out.gated[name]; !ok {
		t.Errorf("pod %q not found after Run", name)
	} else if got != want {
		t.Errorf("pod %q still gated = %v, want %v", name, got, want)
	}
}

func vrAssertWarned(t *testing.T, out vrOutcome, name string) {
	t.Helper()
	if out.warnings[name] == 0 {
		t.Errorf("pod %q: want a Warning-type event, got none", name)
	}
}

func vrAssertNoWarning(t *testing.T, out vrOutcome, name string) {
	t.Helper()
	if out.warnings[name] != 0 {
		t.Errorf("pod %q: want no Warning-type event, got %d", name, out.warnings[name])
	}
}

// TestVerifyOversizedPodKeptGated covers the primary fail_to_pass criterion:
// a Pod whose role-hash annotation names a PodSet it does not fit is kept
// gated and warned, while its honest peers are ungated normally, and the
// oversized Pod neither fails the Workload nor is deleted.
//
// Rejecting worse solutions: asserting out.err == nil rejects an
// over-correction that fails/errors the group on an oversized Pod; re-reading
// the Pod (vrRunGroup would t.Fatalf on a missing Pod) rejects a solution
// that deletes/evicts it instead of leaving it gated.
func TestVerifyOversizedPodKeptGated(t *testing.T) {
	t.Run("forged_hash_requesting_more_cpu_keeps_only_that_pod_gated", func(t *testing.T) {
		out := vrRunGroup(t,
			vrWorkloadRequest("1"),
			[]corev1.Pod{vrGatedPod("p1", "1"), vrGatedPod("p2", "2")},
		)
		if out.err != nil {
			t.Fatalf("Run returned error for an oversized peer, want nil: %v", out.err)
		}
		vrAssertGated(t, out, "p1", false)
		vrAssertNoWarning(t, out, "p1")
		vrAssertGated(t, out, "p2", true)
		vrAssertWarned(t, out, "p2")
	})

	t.Run("pod_requesting_an_unreserved_resource_is_kept_gated", func(t *testing.T) {
		out := vrRunGroup(t,
			vrWorkloadRequest("1"),
			[]corev1.Pod{vrGatedGPUPod("p1")},
		)
		if out.err != nil {
			t.Fatalf("Run returned error for an oversized pod, want nil: %v", out.err)
		}
		vrAssertGated(t, out, "p1", true)
		vrAssertWarned(t, out, "p1")
	})
}

// TestVerifyEffectiveReservation covers the second fail_to_pass criterion:
// the fit check measures a Pod against the EFFECTIVE reservation (limits
// copied into requests, LimitRange DefaultRequest applied, RuntimeClass
// overhead added) and the Pod's EFFECTIVE requests (init, sidecar, and
// pod-level resources counted), not the raw template or main containers only.
//
// A fix comparing against the raw template fails the limits-only, LimitRange,
// and RuntimeClass fit cases; a fix summing only main-container requests fails
// the init/sidecar/pod-level cases.
func TestVerifyEffectiveReservation(t *testing.T) {
	t.Run("limits_only_role_fitting_pod_is_ungated", func(t *testing.T) {
		out := vrRunGroup(t, vrWorkloadLimit("1"), []corev1.Pod{vrGatedLimitsPod("p1", "1")})
		if out.err != nil {
			t.Fatalf("Run returned error, want nil: %v", out.err)
		}
		vrAssertGated(t, out, "p1", false)
		vrAssertNoWarning(t, out, "p1")
	})

	t.Run("limits_only_role_oversized_pod_is_kept_gated", func(t *testing.T) {
		out := vrRunGroup(t, vrWorkloadLimit("1"), []corev1.Pod{vrGatedLimitsPod("p1", "2")})
		if out.err != nil {
			t.Fatalf("Run returned error, want nil: %v", out.err)
		}
		vrAssertGated(t, out, "p1", true)
		vrAssertWarned(t, out, "p1")
	})

	t.Run("limitrange_default_request_fitting_pod_is_ungated", func(t *testing.T) {
		lr := utiltesting.MakeLimitRange("defaults", metav1.NamespaceDefault).
			WithValue("DefaultRequest", corev1.ResourceCPU, "1").
			Obj()
		out := vrRunGroup(t, vrWorkloadNoRequests(), []corev1.Pod{vrGatedPod("p1", "1")}, lr)
		if out.err != nil {
			t.Fatalf("Run returned error, want nil: %v", out.err)
		}
		vrAssertGated(t, out, "p1", false)
		vrAssertNoWarning(t, out, "p1")
	})

	t.Run("limitrange_default_request_oversized_pod_is_kept_gated", func(t *testing.T) {
		lr := utiltesting.MakeLimitRange("defaults", metav1.NamespaceDefault).
			WithValue("DefaultRequest", corev1.ResourceCPU, "1").
			Obj()
		out := vrRunGroup(t, vrWorkloadNoRequests(), []corev1.Pod{vrGatedPod("p1", "2")}, lr)
		if out.err != nil {
			t.Fatalf("Run returned error, want nil: %v", out.err)
		}
		vrAssertGated(t, out, "p1", true)
		vrAssertWarned(t, out, "p1")
	})

	t.Run("runtimeclass_overhead_fitting_pod_is_ungated", func(t *testing.T) {
		rc := utiltesting.MakeRuntimeClass("kata", "kata").
			PodOverhead(corev1.ResourceList{corev1.ResourceCPU: resource.MustParse("500m")}).
			Obj()
		out := vrRunGroup(t, vrWorkloadRuntimeClass(), []corev1.Pod{vrGatedRuntimeClassPod("p1")}, rc)
		if out.err != nil {
			t.Fatalf("Run returned error, want nil: %v", out.err)
		}
		vrAssertGated(t, out, "p1", false)
		vrAssertNoWarning(t, out, "p1")
	})

	t.Run("init_container_request_above_reservation_keeps_pod_gated", func(t *testing.T) {
		out := vrRunGroup(t, vrWorkloadRequest("1"), []corev1.Pod{vrGatedInitPod("p1", "2")})
		if out.err != nil {
			t.Fatalf("Run returned error, want nil: %v", out.err)
		}
		vrAssertGated(t, out, "p1", true)
		vrAssertWarned(t, out, "p1")
	})

	t.Run("sidecar_request_above_reservation_keeps_pod_gated", func(t *testing.T) {
		out := vrRunGroup(t, vrWorkloadRequest("1"), []corev1.Pod{vrGatedSidecarPod("p1", "2")})
		if out.err != nil {
			t.Fatalf("Run returned error, want nil: %v", out.err)
		}
		vrAssertGated(t, out, "p1", true)
		vrAssertWarned(t, out, "p1")
	})

	t.Run("pod_level_request_above_reservation_keeps_pod_gated", func(t *testing.T) {
		out := vrRunGroup(t, vrWorkloadRequest("1"), []corev1.Pod{vrGatedPodLevelPod("p1", "2")})
		if out.err != nil {
			t.Fatalf("Run returned error, want nil: %v", out.err)
		}
		vrAssertGated(t, out, "p1", true)
		vrAssertWarned(t, out, "p1")
	})
}

// TestVerifyHonestGroupUngated covers the pass_to_pass criterion that an
// honest group is ungated exactly as before the fix, and that the pre-existing
// single-Pod validation stays green. Guards against an over-correction that
// keeps fitting Pods gated.
func TestVerifyHonestGroupUngated(t *testing.T) {
	t.Run("every_pod_fitting_its_role_is_ungated_with_no_warnings", func(t *testing.T) {
		out := vrRunGroup(t,
			vrWorkloadRequest("1"),
			[]corev1.Pod{vrGatedPod("p1", "1"), vrGatedPod("p2", "1")},
		)
		if out.err != nil {
			t.Fatalf("Run returned error for an honest group, want nil: %v", out.err)
		}
		vrAssertGated(t, out, "p1", false)
		vrAssertGated(t, out, "p2", false)
		vrAssertNoWarning(t, out, "p1")
		vrAssertNoWarning(t, out, "p2")
		if out.normals["p1"] == 0 || out.normals["p2"] == 0 {
			t.Errorf("want a Normal event for each ungated pod, got p1=%d p2=%d", out.normals["p1"], out.normals["p2"])
		}
	})

	t.Run("single_pod_rejects_multiple_podset_infos", func(t *testing.T) {
		pods := []corev1.Pod{*testingpod.MakePod("test-pod", metav1.NamespaceDefault).Obj()}
		p := FromObject(&pods[0])

		ctx, _ := utiltesting.ContextWithLog(t)
		clientBuilder := utiltesting.NewClientBuilder()
		if err := SetupIndexes(ctx, utiltesting.AsIndexer(clientBuilder)); err != nil {
			t.Fatalf("could not setup indexes: %v", err)
		}
		kClient := clientBuilder.WithLists(&corev1.PodList{Items: pods}).Build()

		gotErr := p.Run(ctx, kClient,
			utiltestingapi.MakeWorkload("wl", metav1.NamespaceDefault).Obj(),
			make([]podset.PodSetInfo, 2), &utiltesting.EventRecorder{}, "")
		if !errors.Is(gotErr, podset.ErrInvalidPodsetInfo) {
			t.Errorf("want ErrInvalidPodsetInfo for a single pod given 2 pod-set infos, got %v", gotErr)
		}
	})
}

// TestVerifyUnknownRolePermanentError covers the pass_to_pass criterion that a
// role-hash naming a role with no PodSet in the Workload is a permanent error
// rather than a silent ungate. Distinguishes a fix that validates the role name
// from one that ignores unknown roles.
func TestVerifyUnknownRolePermanentError(t *testing.T) {
	unknown := *testingpod.MakePod("p1", metav1.NamespaceDefault).
		Image("", nil).
		Request(corev1.ResourceCPU, "1").
		RoleHash("role-unknown").
		KueueSchedulingGate().
		Obj()

	out := vrRunGroup(t, vrWorkloadRequest("1"), []corev1.Pod{unknown})

	if !errors.Is(out.err, podset.ErrInvalidPodsetInfo) {
		t.Errorf("want ErrInvalidPodsetInfo for an unknown role, got %v", out.err)
	}
	if !podset.IsPermanent(out.err) {
		t.Errorf("want a permanent error for an unknown role, got %v", out.err)
	}
	vrAssertGated(t, out, "p1", true)
}
