#!/usr/bin/env bash
# All dependencies (Go toolchain, module cache, prebuilt base unit-test tree)
# are baked into the image; nothing to install at verifier time.
set -euo pipefail
echo "[test-setup] no-op for kueue-fix-verify-role-requests"
