import sys
sys.path.insert(0, "/tests/validate")
from test_harness import run_sql, combined, output_lines


def test_expr_index_covering_projection(inputs, expected):
    sql = inputs["sql"]
    q = inputs["query"]
    run_full = sql + ("\n" + q + ";" if q else "")
    res = run_sql(run_full)

    if expected["unique_error"] != "__skip__":
        assert ("UNIQUE constraint failed" in combined(res)) == expected["unique_error"], combined(res)

    if expected["rows"] != "__skip__":
        want = [] if expected["rows"] == "" else expected["rows"].split("\n")
        assert output_lines(res) == want, combined(res)

    if expected["plan_contains"] != "__skip__":
        plan = run_sql(sql + "\nEXPLAIN QUERY PLAN " + q + ";")
        assert expected["plan_contains"] in combined(plan), combined(plan)
