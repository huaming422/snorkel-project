import sys
sys.path.insert(0, "/tests/validate")
from test_harness import run_sql, combined, output_lines


def test_expr_index_covering_projection(inputs, expected):
    sql = inputs["sql"]
    q = inputs["query"]

    # For the rows check, append ORDER BY 1 to make the result order deterministic.
    # A covering index scan may return rows in index order rather than insertion order;
    # ORDER BY 1 ensures we always compare in ascending value order, which matches
    # the expected values (3,7,11 and 30,70 are already in ascending order).
    q_ordered = (q + " ORDER BY 1") if q else q
    run_full_ordered = sql + ("\n" + q_ordered + ";") if q_ordered else sql
    res = run_sql(run_full_ordered)

    if expected["unique_error"] != "__skip__":
        assert ("UNIQUE constraint failed" in combined(res)) == expected["unique_error"], combined(res)

    if expected["rows"] != "__skip__":
        want = [] if expected["rows"] == "" else expected["rows"].split("\n")
        assert output_lines(res) == want, combined(res)

    if expected["plan_contains"] != "__skip__":
        # Use the original query (without ORDER BY) for the EXPLAIN QUERY PLAN check
        plan = run_sql(sql + "\nEXPLAIN QUERY PLAN " + q + ";")
        assert expected["plan_contains"] in combined(plan), combined(plan)
