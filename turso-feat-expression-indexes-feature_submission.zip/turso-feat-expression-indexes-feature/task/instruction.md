## Task

We want to support indexes on arbitrary expressions, not just bare columns. Right now `CREATE INDEX` only takes a list of column names; we'd like `CREATE INDEX idx ON t(a + b)` or `CREATE INDEX idx ON t(lower(name))` to work the way they do in SQLite (https://sqlite.org/expridx.html).

This reaches across the whole index pipeline in the SQL compiler (the `core` crate): an expression key needs a home in the schema model, index creation has to build and populate it, the write path has to keep it consistent as rows change, and the query planner has to recognise when a query's expression matches an indexed one. It's purely additive on top of the existing column and partial-index support (`CREATE INDEX ... WHERE ...`). Keep it SQLite-compatible end to end: a turso database is interchangeable with one SQLite or rusqlite created, and expression indexes should behave here the same way they do there.

## User stories / requirements

- With an index on an expression, a query whose WHERE clause tests that same expression is answered through the index instead of scanning the table, and returns the correct rows. This holds for equality and range comparisons alike, and EXPLAIN QUERY PLAN names that index as the one in use.
- A query that orders by the indexed expression, ascending or descending, is served directly from the expression index with no separate sorting step, and the rows come back in the correct order.
- A query that selects only the indexed expression is answered entirely from the index as a covering scan, without touching the table, and returns the correct values.
- An expression index stays correct as rows are inserted, updated, deleted, and upserted, so a query served by the index afterward reflects the current data. A UNIQUE expression index also rejects a second row whose computed key value collides with one already present.
- Ordinary indexes keyed on plain columns keep working exactly as before. A plain column index is still chosen by the planner for a matching lookup and returns the right rows, and a partial column index still enforces uniqueness only over the rows its WHERE clause selects — a duplicate among the rows the predicate covers is rejected, while a duplicate among the rows it excludes is allowed. None of this is disturbed by the expression-index work.
