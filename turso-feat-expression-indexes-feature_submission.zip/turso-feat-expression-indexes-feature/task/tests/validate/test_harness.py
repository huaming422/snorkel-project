"""Shared helpers for the turso-feat-expression-indexes validation stories.

Every story drives the repository's shipped SQL shell, the `tursodb` binary that
`validation-setup.sh` builds from the agent's edits. A story pipes a short SQL
script to the binary over stdin (the shell reads until EOF in non-interactive
mode), captures combined stdout+stderr, and asserts on:

  - the plain pipe-joined result rows (`-m list` prints one row per line,
    columns joined by `|`), and/or
  - the `EXPLAIN QUERY PLAN` detail text, whose `USING INDEX <name>` /
    `USING COVERING INDEX <name>` lines are the SQLite-compatible surface the
    task's contract names, and/or
  - a stable engine diagnostic such as `UNIQUE constraint failed`.

Nothing here encodes any symbol the solution introduces: the binary name, the
output mode, and the EXPLAIN phrasing are all pre-existing, repo-owned surfaces.
"""

from __future__ import annotations

import os
import subprocess

# The CLI binary built by validation-setup.sh. CARGO_TARGET_DIR is redirected to
# /opt/cache/cargo-target in the image, so the debug binary lands there rather
# than under the repo's own target/.
TURSODB = "/opt/cache/cargo-target/debug/tursodb"

# Per-invocation wall-clock ceiling. Each script is a handful of statements
# against an in-memory database — seconds in practice; 90s is slack for a slow
# Modal sandbox.
RUN_TIMEOUT_SEC = 90


def _env() -> dict[str, str]:
    env = {**os.environ}
    env.setdefault("CARGO_HOME", "/opt/cargo")
    env.setdefault("RUSTUP_HOME", "/opt/rustup")
    return env


def run_sql(script: str) -> subprocess.CompletedProcess:
    """Pipe ``script`` to a fresh in-memory ``tursodb`` and return the result.

    Runs with ``-m list`` (pipe-joined columns, one row per line) and ``-q``
    (no banner). ``--experimental-index-method`` mirrors the repository's own
    integration harness (``TempDatabase::new_with_rusqlite``), which opens its
    databases with both the index and index-method capabilities enabled;
    experimental indexing itself is on by default. The database argument
    ``:memory:`` keeps every statement in one session so a CREATE INDEX and the
    queries that follow share state.
    """
    cmd = [
        TURSODB,
        "-m",
        "list",
        "-q",
        "--experimental-index-method",
        ":memory:",
    ]
    return subprocess.run(
        cmd,
        input=script,
        capture_output=True,
        text=True,
        timeout=RUN_TIMEOUT_SEC,
        env=_env(),
        check=False,
    )


def combined(result: subprocess.CompletedProcess) -> str:
    """Return stdout and stderr concatenated (diagnostics go to stderr)."""
    return (result.stdout or "") + (result.stderr or "")


def output_lines(result: subprocess.CompletedProcess) -> list[str]:
    """Return non-empty stdout lines (the result rows) with whitespace trimmed."""
    return [ln.strip() for ln in (result.stdout or "").splitlines() if ln.strip()]
