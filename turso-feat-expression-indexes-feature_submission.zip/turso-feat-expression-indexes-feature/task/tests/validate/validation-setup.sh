#!/usr/bin/env bash
# Validation setup: runs after the agent applies its edits, before the stories.
# One job — build the `tursodb` CLI binary from the agent's edited source so the
# stories can drive real SQL through it.
#
# The image pre-built the workspace `--lib --tests` at the base commit but not
# the CLI binary, so this is the binary's first compile; it reuses the warm
# dependency cache and only compiles the workspace crates + the thin CLI, so it
# is a few minutes cold and seconds on re-run. Idempotent: re-running just
# rebuilds incrementally.
set -euo pipefail

REPO=/repo/turso

export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export RUSTUP_TOOLCHAIN="${RUSTUP_TOOLCHAIN:-1.88.0}"
export PATH="$CARGO_HOME/bin:$PATH"

TURSODB="$CARGO_TARGET_DIR/debug/tursodb"

echo "validation-setup: rustc=$(rustc --version 2>&1 | head -1)"
echo "validation-setup: cargo=$(cargo --version 2>&1 | head -1)"

# Build the CLI binary (package turso_cli, default-run tursodb) with the agent's
# edits applied. --locked keeps the dependency set identical to the baked cache
# (the agent phase has no network). Incremental against the warm target dir.
echo "validation-setup: building tursodb (incremental)..."
( cd "$REPO" && cargo build --locked -p turso_cli --bin tursodb 2>&1 | tail -8 )

test -x "$TURSODB" || {
    echo "ERROR: tursodb binary missing at $TURSODB after cargo build" >&2
    exit 1
}

# Loud smoke guard: if the binary cannot create and use an expression index at
# all, every story would fail with the same opaque error — surface it here with
# a clear message instead. This drives one expression index end to end (create,
# plan, read back) exactly as a story would. On an unsolved submission this
# guard is EXPECTED to trip, which is correct: the feature is absent, so the
# validation suite must not pass. On a correct build it prints the two markers.
# (An unsolved submission makes CREATE INDEX on an expression fail outright.)
echo "validation-setup: smoke-checking expression-index support..."
SMOKE_SQL='CREATE TABLE _s(a INT, b INT);
INSERT INTO _s VALUES (3, 4);
CREATE INDEX _s_expr ON _s(a + b);
EXPLAIN QUERY PLAN SELECT a, b FROM _s WHERE a + b = 7;
SELECT a, b FROM _s WHERE a + b = 7;'
SMOKE_OUT="$("$TURSODB" -m list -q --experimental-index-method :memory: <<EOF 2>&1 || true
$SMOKE_SQL
EOF
)"
echo "----- smoke output -----"
echo "$SMOKE_OUT"
echo "------------------------"
if ! grep -q "_s_expr" <<<"$SMOKE_OUT" || ! grep -q "^3|4$" <<<"$SMOKE_OUT"; then
    echo "validation-setup: WARNING — expression-index smoke did not show both the" >&2
    echo "  planner using _s_expr and the row 3|4. On a correct solution this must" >&2
    echo "  succeed; on an unsolved build this is expected and the stories will" >&2
    echo "  fail as designed." >&2
fi

echo "validation-setup: done. tursodb at $TURSODB ($("$TURSODB" --version 2>&1 | head -1))"
