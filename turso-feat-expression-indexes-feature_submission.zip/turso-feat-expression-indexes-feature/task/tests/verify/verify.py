"""Compile-gate verifier for turso-feat-expression-indexes.

The feature under test is observable only by running SQL against a built engine
(create an index on an expression, then watch the planner use it and the write
path keep it correct). That behavioral check lives entirely in the validation
suite, which drives the shipped `tursodb` CLI binary. This verifier is the
minimal companion the validation step assumes: a compile gate confirming the
agent's edits still produce a workspace whose integration-test crate builds, so
validation never wastes a binary build on a submission that cannot type-check.

It runs `cargo build -p core_tester --tests` in the repo. `core_tester` is the
repository's pre-existing integration-test package (its name is fixed in
`tests/Cargo.toml` at the base commit); building it with `--tests` compiles the
whole dependency graph it pulls in, including the `core` crate where the feature
lives. The gate is deliberately interface-agnostic:

  - it imports no module the solution introduces,
  - it greps for no new symbol, file, or helper the solution may invent,
  - it runs no `cargo test`, so it is insensitive to which test names exist.

An empty edit compiles (the gate passes, and only validation catches the absent
feature); an edit that breaks the build is caught here, cheaply, before
validation runs.
"""

from __future__ import annotations

import os
import subprocess
import textwrap


# Repository checkout inside the task container.
REPO_DIR = "/repo/turso"

# The repository's own integration-test package name — the stable `-p`
# build target. Present in tests/Cargo.toml at the base commit; the
# solution never renames it. Building it with --tests compiles the
# workspace crates it depends on (notably `core`).
PACKAGE = "core_tester"

# The image pre-builds the workspace `--lib --tests`, so the post-edit
# build is incremental: usually well under a minute, a few minutes if a
# deep crate was touched. 900s is generous headroom without risking the
# full reward stack's 20-minute budget.
BUILD_TIMEOUT_SEC = 900


def test_integration_crate_builds() -> None:
    """`cargo build -p core_tester --tests` must exit 0 after the agent's edits.

    On failure, surfaces the last 200 lines of stdout and stderr so the
    build break is visible in the verifier log without flooding downstream
    consumers.
    """
    cmd = ["cargo", "build", "-p", PACKAGE, "--tests", "--message-format=short"]

    env = {**os.environ}
    env.setdefault("CARGO_HOME", "/opt/cargo")
    env.setdefault("RUSTUP_HOME", "/opt/rustup")
    env.setdefault("CARGO_TARGET_DIR", "/opt/cache/cargo-target")
    env["PATH"] = f"{env['CARGO_HOME']}/bin:" + env.get("PATH", "")

    result = subprocess.run(
        cmd,
        cwd=REPO_DIR,
        capture_output=True,
        text=True,
        timeout=BUILD_TIMEOUT_SEC,
        env=env,
        check=False,
    )

    if result.returncode == 0:
        return

    def _tail(text: str, n: int = 200) -> str:
        return "\n".join(text.splitlines()[-n:])

    msg = textwrap.dedent(
        f"""\
        `cargo build -p {PACKAGE} --tests` failed (exit {result.returncode}).
        The agent's edits produced a workspace that no longer compiles.
        Common causes:
          - A new match arm missing after an enum was extended
          - A trait method missing on an extended impl
          - A type/borrow/lifetime mismatch in the new code
          - Broken Cargo feature gating

        --- cargo build stdout (last 200 lines) ---
        {_tail(result.stdout)}

        --- cargo build stderr (last 200 lines) ---
        {_tail(result.stderr)}
        """
    )
    raise AssertionError(msg)
