#!/usr/bin/env bash
# Verifier-side setup: runs before the reward verifier, with network available.
# The image already installed the Rust toolchain, warmed the cargo registry at
# the base commit, pre-fetched every workspace dependency, and pre-built the
# workspace --lib --tests, so the verifier's post-edit build is incremental.
# This script only re-exports the toolchain onto PATH (each grading phase starts
# a fresh shell, so Dockerfile ENV from RUN layers is not inherited) and
# sanity-checks that the toolchain is present.
set -euo pipefail

export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export PATH="$CARGO_HOME/bin:$PATH"

rustc --version >/dev/null 2>&1 || {
    echo "ERROR: rustc not found on PATH (CARGO_HOME=$CARGO_HOME)" >&2
    exit 1
}
cargo --version >/dev/null 2>&1 || {
    echo "ERROR: cargo not found on PATH" >&2
    exit 1
}

echo "test-setup: rustc=$(rustc --version), cargo=$(cargo --version | head -1)"
