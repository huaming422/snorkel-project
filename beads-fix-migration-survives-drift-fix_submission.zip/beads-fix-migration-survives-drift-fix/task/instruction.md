## Task

after the latest CLI upgrade we're getting reports that some users can't open their database anymore. every command fails the same way the moment it starts, before it does any actual work: a panic out of the storage engine that reads `invalid hash length`. it happens on every single start, so there's no way back in. the database just won't open, and there's no forward or backward upgrade path around it. worked fine before the upgrade.

it's not everyone. clean databases upgrade and open without trouble. the ones that break all seem to have some low-level inconsistency in how their history/comments data is encoded on disk. can you dig in and fix it so these databases open again?
