package schema

// Behavioral checks for the aux-table row-id re-key's handling of
// schema-encoding drift (gastownhall/beads#4380, dolthub/dolt#11131).
//
// These drive the pre-existing, signature-stable entry points
// (rekeyAuxRowIDs) against a hand-rolled DBConn backed by an in-memory
// database/sql driver that answers each statement by its SQL shape rather than
// a fixed call order. That tolerance matters: a correct re-key reads
// local_metadata in more than one shape (a COUNT probe, or a key/value SELECT),
// and this backing answers both from the same in-memory key/value store, so the
// checks hold against any behaviorally-correct implementation of the skip.
//
// They reference only package state that predates this work — rekeyAuxRowIDs,
// auxRekeyPassInitial and auxRekeyTables — never any helper or record key a
// particular implementation of the skip might introduce, so the design space
// (where the drift classifier lives, how the skip is recorded, how logging is
// routed) stays open.
//
// The backing also persists and rounds-trips every record write it does not
// model specifically, keyed by the record's own key column, from one global
// store shared across record tables. That is what lets a two-pass check assert
// the skip is RESUMABLE (a table skipped for drift on one pass is re-keyed by a
// later pass once the drift clears) without pinning where or under what key the
// skip was recorded: one valid fix records a comma-list under one local_metadata
// key, but a distinct per-table key, a separate dolt-ignored table, or keeping
// the in-progress sentinel set as the retry driver all round-trip the same way.

import (
	"context"
	"database/sql"
	"database/sql/driver"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"testing"
)

// ---------------------------------------------------------------------------
// In-memory DBConn backing
// ---------------------------------------------------------------------------

// vdHarness holds the simulated database state the re-key reads and writes. One
// instance backs one *sql.DB; a check tunes it, runs the re-key, and reads back
// the effects.
type vdHarness struct {
	// cursorExists is whether the ignored-migrations cursor table is present.
	cursorExists bool
	// currentVersion is the highest recorded ignored-migration version.
	currentVersion int
	// sentinelTablesPresent / sentinelColumnPresent answer the cursor-reality
	// probes so the cursor is believed as read (no clamp).
	sentinelTablesPresent bool
	sentinelColumnPresent bool
	// localMetaExists is whether the clone-local local_metadata table is present.
	localMetaExists bool
	// records is the fake's durable key/value storage, one map per record table:
	// local_metadata (where the reference solution, both passing frontier trials,
	// and the in-progress sentinel all live), plus any OTHER dolt-ignored table a skip
	// implementation might invent to record its drift skips. A write to a record
	// table persists here and a read rounds it back — keyed by the record's own
	// key/identifier column — so a two-pass check can observe that a skip was
	// recorded and later honored WITHOUT pinning which table or key column a fix
	// chose. Lazily created by h.store.
	records map[string]map[string]string
	// idColumns reports, per aux table, whether it still has its id column (so
	// the re-key proceeds to scan it).
	idColumns map[string]bool
	// scanErr injects the error a table's content SELECT returns — this is where
	// the storage-decode failure surfaces.
	scanErr map[string]error

	// selected / updated record which tables the re-key scanned and rewrote, so
	// a check can assert the effect without inspecting any private record.
	selected map[string]int
	updated  map[string]int
}

func vdNewHarness() *vdHarness {
	return &vdHarness{
		records:   map[string]map[string]string{},
		idColumns: map[string]bool{},
		scanErr:   map[string]error{},
		selected:  map[string]int{},
		updated:   map[string]int{},
	}
}

// store returns the key/value map backing one record table, creating it on
// first write. Reading an absent table returns a fresh empty map (the truthful
// answer for a never-written record).
func (h *vdHarness) store(table string) map[string]string {
	s := h.records[table]
	if s == nil {
		s = map[string]string{}
		h.records[table] = s
	}
	return s
}

// auxDataTables are the four tables the re-key rewrites. They are NOT record
// tables: a write to one is an id rewrite (counted in updated), and a read of
// one is a content scan (counted in selected), never a durable skip record.
var auxDataTables = map[string]bool{
	"events": true, "comments": true,
	"issue_snapshots": true, "compaction_snapshots": true,
}

// vdOpen wraps the harness in a *sql.DB whose every statement is answered from
// memory. A single connection keeps the shared state strictly serialized.
func vdOpen(h *vdHarness) *sql.DB {
	db := sql.OpenDB(vdConnector{h: h})
	db.SetMaxOpenConns(1)
	return db
}

type vdConnector struct{ h *vdHarness }

func (c vdConnector) Connect(context.Context) (driver.Conn, error) { return &vdConn{h: c.h}, nil }
func (c vdConnector) Driver() driver.Driver                        { return vdDriver{} }

type vdDriver struct{}

func (vdDriver) Open(string) (driver.Conn, error) { return nil, errors.New("vd: open via OpenDB") }

type vdConn struct{ h *vdHarness }

func (c *vdConn) Prepare(string) (driver.Stmt, error) { return nil, errors.New("vd: prepare unsupported") }
func (c *vdConn) Close() error                        { return nil }
func (c *vdConn) Begin() (driver.Tx, error)           { return nil, errors.New("vd: begin unsupported") }

func (c *vdConn) QueryContext(_ context.Context, q string, args []driver.NamedValue) (driver.Rows, error) {
	return c.h.query(q, args)
}

func (c *vdConn) ExecContext(_ context.Context, q string, args []driver.NamedValue) (driver.Result, error) {
	return c.h.exec(q, args)
}

type vdRows struct {
	cols []string
	rows [][]driver.Value
	pos  int
}

func (r *vdRows) Columns() []string { return r.cols }
func (r *vdRows) Close() error      { return nil }
func (r *vdRows) Next(dest []driver.Value) error {
	if r.pos >= len(r.rows) {
		return io.EOF
	}
	copy(dest, r.rows[r.pos])
	r.pos++
	return nil
}

type vdResult struct{}

func (vdResult) LastInsertId() (int64, error) { return 0, nil }
func (vdResult) RowsAffected() (int64, error) { return 0, nil }

var vdWS = regexp.MustCompile(`\s+`)

func vdNorm(s string) string {
	return strings.ToLower(vdWS.ReplaceAllString(strings.TrimSpace(s), " "))
}

func vdArgStr(args []driver.NamedValue, i int) string {
	if i < 0 || i >= len(args) {
		return ""
	}
	s, _ := args[i].Value.(string)
	return s
}

func vdBool(b bool) int64 {
	if b {
		return 1
	}
	return 0
}

func vdScalar(v driver.Value) (driver.Rows, error) {
	return &vdRows{cols: []string{"n"}, rows: [][]driver.Value{{v}}}, nil
}

var vdFromRe = regexp.MustCompile(`(?i)\bfrom\s+` + "`?" + `(\w+)` + "`?")

func vdTable(q string) string {
	if m := vdFromRe.FindStringSubmatch(q); len(m) > 1 {
		return m[1]
	}
	return ""
}

var vdUpdateRe = regexp.MustCompile(`(?i)^update\s+` + "`?" + `(\w+)` + "`?")

func vdUpdateTable(q string) string {
	if m := vdUpdateRe.FindStringSubmatch(strings.TrimSpace(q)); len(m) > 1 {
		return m[1]
	}
	return ""
}

// vdWriteRe extracts the target table of a record write, across every shape a
// skip record is written through: REPLACE/INSERT [IGNORE] INTO <t>, DELETE FROM
// <t>, UPDATE <t>, CREATE TABLE [IF NOT EXISTS] <t>. Extracting it uniformly is
// what keeps a write's store and the later read's store the same, whatever
// clone-local record table a fix chose.
var vdWriteRe = regexp.MustCompile(`(?i)^(?:replace\s+into|insert(?:\s+ignore)?\s+into|delete\s+from|update|create\s+table(?:\s+if\s+not\s+exists)?)\s+` + "`?" + `(\w+)` + "`?")

func vdWriteTable(q string) string {
	if m := vdWriteRe.FindStringSubmatch(strings.TrimSpace(q)); len(m) > 1 {
		return m[1]
	}
	return ""
}

func (h *vdHarness) query(raw string, args []driver.NamedValue) (driver.Rows, error) {
	q := vdNorm(raw)
	switch {
	// Existence of the local_metadata table (its name is a literal in the SQL).
	case strings.Contains(q, "from information_schema.tables") && strings.Contains(q, "'local_metadata'"):
		return vdScalar(vdBool(h.localMetaExists))

	// Existence of the migration cursor and the cursor-reality sentinel tables
	// (the table name is bound as a parameter).
	case strings.Contains(q, "from information_schema.tables") && strings.Contains(q, "table_name = ?"):
		name := vdArgStr(args, 0)
		if name == "ignored_schema_migrations" || name == "schema_migrations" {
			return vdScalar(vdBool(h.cursorExists))
		}
		return vdScalar(vdBool(h.sentinelTablesPresent))

	// Highest recorded migration version.
	case strings.Contains(q, "coalesce(max(version)"):
		return vdScalar(int64(h.currentVersion))

	// Column presence: the id column of an aux table, or a cursor-reality
	// sentinel column.
	case strings.Contains(q, "from information_schema.columns"):
		col := vdArgStr(args, 1)
		if col == "id" {
			return vdScalar(vdBool(h.idColumns[vdArgStr(args, 0)]))
		}
		return vdScalar(vdBool(h.sentinelColumnPresent))

	// Reading a clone-local record, in any shape a skip implementation might
	// use to re-admit the re-key: a COUNT probe or a key/value SELECT, matched
	// by `=`, `IN (...)`, or `LIKE`, over local_metadata or any other
	// dolt-ignored record table (anything that selects the `key` column). The
	// same global kv store answers all of them, so whichever representation a
	// fix wrote its skip under — a comma-list under one key, a per-table key
	// read back with LIKE, a kept in-flight sentinel, or a separate dolt-ignored
	// table — rounds-trips identically.
	case h.isRecordRead(q):
		store := h.store(vdTable(raw))
		matched := matchRecordKeys(store, q, args)
		if strings.Contains(q, "count(") {
			return vdScalar(int64(len(matched)))
		}
		rows := make([][]driver.Value, 0, len(matched))
		for _, k := range matched {
			rows = append(rows, []driver.Value{k, store[k]})
		}
		return &vdRows{cols: []string{"key", "value"}, rows: rows}, nil

	// Scanning an aux table's contents to re-key it: the storage-decode failure
	// surfaces here.
	case strings.HasPrefix(q, "select id,") && strings.Contains(q, " from "):
		table := vdTable(raw)
		h.selected[table]++
		if err := h.scanErr[table]; err != nil {
			return nil, err
		}
		return &vdRows{cols: vdSelectCols(raw), rows: nil}, nil
	}

	// Benign default so the design space stays open. A fix is free to record the
	// skip in its own structure — a different local_metadata key, a distinct
	// dolt-ignored table, a new column — and to read that structure back on the
	// path these checks drive. Any read this fake does not model specifically
	// answers "nothing there" (an empty result, or 0 for a COUNT), which is the
	// truthful answer for the fresh, never-skipped database these checks set up;
	// erroring instead would reject a valid record representation the task
	// explicitly allows, not catch a wrong one.
	if strings.Contains(q, "count(") {
		return vdScalar(int64(0))
	}
	return &vdRows{cols: []string{"c0"}, rows: nil}, nil
}

func vdSelectCols(raw string) []string {
	lq := strings.ToLower(raw)
	lo := strings.Index(lq, "select ")
	hi := strings.Index(lq, " from ")
	if lo < 0 || hi < 0 || hi <= lo {
		return []string{"c0"}
	}
	parts := strings.Split(raw[lo+len("select "):hi], ",")
	cols := make([]string, len(parts))
	for i := range parts {
		cols[i] = fmt.Sprintf("c%d", i)
	}
	return cols
}

func (h *vdHarness) exec(raw string, args []driver.NamedValue) (driver.Result, error) {
	q := vdNorm(raw)
	switch {
	case strings.HasPrefix(q, "create table if not exists local_metadata"):
		h.localMetaExists = true
		return vdResult{}, nil
	case strings.HasPrefix(q, "create table"):
		// A fix may create its own dolt-ignored record table; accept it so the
		// row writes that follow persist rather than failing a valid alternative.
		return vdResult{}, nil

	// An id rewrite of one of the four aux data tables — the observable effect
	// a check counts. Checked before the generic record writes so an UPDATE of a
	// data table is never mistaken for a record write.
	case strings.HasPrefix(q, "update ") && strings.Contains(q, "set id = ?"):
		h.updated[vdUpdateTable(raw)]++
		return vdResult{}, nil

	// Any write to a record table — local_metadata, a per-table keyed variant,
	// a kept in-flight sentinel, or a separate dolt-ignored record table —
	// persists in that table's store, keyed by the key/identifier
	// bound as the first argument. REPLACE/INSERT upserts; DELETE removes. This
	// is what makes the skip durable across the two passes a resumability check
	// runs, without the check knowing where the fix put it.
	case h.isRecordWrite(q, raw):
		store := h.store(vdWriteTable(raw))
		key := vdArgStr(args, 0)
		switch {
		case strings.HasPrefix(q, "delete "):
			for _, k := range matchRecordKeys(store, q, args) {
				delete(store, k)
			}
		default:
			v := "1"
			if len(args) > 1 {
				if s, ok := args[1].Value.(string); ok {
					v = s
				}
			}
			store[key] = v
		}
		return vdResult{}, nil
	}

	// Benign default, for the same reason the query path has one: a write this
	// fake does not model succeeds silently rather than failing a valid
	// alternative. No modeled effect of these checks depends on an unmodeled
	// write.
	return vdResult{}, nil
}

// isRecordRead reports whether a normalized query reads a clone-local record
// store rather than an aux data table's content. A record read names
// local_metadata, selects/counts a `key` column, or reads any non-data table
// that is not one of the modeled information_schema / cursor probes.
func (h *vdHarness) isRecordRead(q string) bool {
	if strings.Contains(q, "information_schema") || strings.Contains(q, "coalesce(max(version)") {
		return false
	}
	if strings.HasPrefix(q, "select id,") {
		return false // an aux-table content scan
	}
	if strings.Contains(q, "from local_metadata") || strings.Contains(q, "`key`") {
		return true
	}
	// A read of some other record table (a fix's own dolt-ignored table): any
	// SELECT whose FROM is not one of the four aux data tables.
	if strings.HasPrefix(q, "select ") {
		return !auxDataTables[vdTable(q)]
	}
	return false
}

// isRecordWrite reports whether a normalized write targets a record store (not
// an aux data table's id rewrite, which the caller handles first).
func (h *vdHarness) isRecordWrite(q, raw string) bool {
	switch {
	case strings.Contains(q, "local_metadata"):
		return true
	case strings.HasPrefix(q, "replace into "), strings.HasPrefix(q, "insert into "),
		strings.HasPrefix(q, "insert ignore into "):
		return !auxDataTables[vdTable(raw)]
	case strings.HasPrefix(q, "delete from "):
		return !auxDataTables[vdTable(raw)]
	case strings.HasPrefix(q, "update "):
		// An UPDATE that is not an id rewrite (handled earlier) and targets a
		// non-data table is a record update (e.g. upsert of a skip flag).
		return !auxDataTables[vdUpdateTable(raw)]
	}
	return false
}

// matchRecordKeys returns the keys present in store that a WHERE clause selects.
// It supports the three shapes the skip record is read back through: `key` = ?,
// `key` IN (?, ?, ...), and `key` LIKE ? (with a trailing %). A read with no
// bound key arguments (a bare COUNT(*) or full-table SELECT) returns every key.
func matchRecordKeys(store map[string]string, q string, args []driver.NamedValue) []string {
	var argStrs []string
	for _, a := range args {
		if s, ok := a.Value.(string); ok {
			argStrs = append(argStrs, s)
		}
	}
	var out []string
	switch {
	case strings.Contains(q, " like "):
		for _, a := range argStrs {
			prefix := strings.TrimRight(a, "%")
			for k := range store {
				if strings.HasPrefix(k, prefix) {
					out = append(out, k)
				}
			}
		}
	case len(argStrs) > 0:
		for _, a := range argStrs {
			if _, ok := store[a]; ok {
				out = append(out, a)
			}
		}
	default:
		for k := range store {
			out = append(out, k)
		}
	}
	sort.Strings(out)
	return dedupeStrings(out)
}

func dedupeStrings(in []string) []string {
	if len(in) < 2 {
		return in
	}
	out := in[:1]
	for _, s := range in[1:] {
		if s != out[len(out)-1] {
			out = append(out, s)
		}
	}
	return out
}

// ---------------------------------------------------------------------------
// Shared setup
// ---------------------------------------------------------------------------

// vdFreshPass returns a *sql.DB positioned so pass-initial's re-key runs over
// all four aux tables for the first time: the convergence marker is still
// pending, the clone has no recorded in-flight or skipped work, and only the
// events table still carries an id column, so it is the one table scanned. Its
// content scan returns scanErr. The other three report no id column and are
// left alone, so a check observes exactly what the re-key does with the one
// unreadable table.
func vdFreshPass(scanErr error) *sql.DB {
	h := vdNewHarness()
	h.cursorExists = true
	h.currentVersion = auxRekeyPassInitial.markerVersion - 1
	h.sentinelTablesPresent = true
	h.sentinelColumnPresent = true
	h.localMetaExists = true
	h.idColumns[auxRekeyTables[0].name] = true // events
	h.scanErr[auxRekeyTables[0].name] = scanErr
	return vdOpen(h)
}

// vdRunInitial drives the first-pass re-key: mainVersionBefore is one short of
// the shipped watershed so the pass is admitted.
func vdRunInitial(db *sql.DB) error {
	_, err := rekeyAuxRowIDs(context.Background(), db,
		auxRekeyPassInitial.shippedMainVersion-1, auxRekeyPassInitial)
	return err
}

// The storage-decode failure Dolt recovers per query and surfaces as a 1105.
var vdDriftErr = errors.New("Error 1105 (HY000): panic recovered: invalid hash length: 19")

// ---------------------------------------------------------------------------
// Checks
// ---------------------------------------------------------------------------

// TestVerifyDriftSurvivesMigration: a table whose storage cannot be decoded
// must not abort the whole re-key. The pass has to complete over the rest of
// the database instead of failing — failing is what left affected databases
// unopenable, since the pass re-runs on every open.
func TestVerifyDriftSurvivesMigration(t *testing.T) {
	db := vdFreshPass(vdDriftErr)
	defer db.Close()

	if err := vdRunInitial(db); err != nil {
		t.Fatalf("a storage-decode failure on one table must not abort the re-key, got: %v", err)
	}
}

// TestVerifyNonDriftAborts: the tolerance is narrow. An error that is not the
// storage-decode signature must still abort the pass, so a genuine migration
// fault is never silently swallowed.
func TestVerifyNonDriftAborts(t *testing.T) {
	db := vdFreshPass(errors.New("Error 1062 (23000): duplicate entry"))
	defer db.Close()

	if err := vdRunInitial(db); err == nil {
		t.Fatal("an ordinary (non storage-decode) failure must abort the re-key, got nil")
	}
}

// TestVerifyDriftToleranceBreadth pins the breadth of what counts as the
// storage-decode signature: the width of the reported value varies with the
// direction of the encoding flip and the engine's recovery wrapper is not
// always present, so all of those forms must be tolerated — while unrelated
// recovered panics and ordinary failures must still abort.
func TestVerifyDriftToleranceBreadth(t *testing.T) {
	cases := []struct {
		name       string
		errText    string
		wantSurvive bool
	}{
		{"recovered width 19", "Error 1105 (HY000): panic recovered: invalid hash length: 19", true},
		{"recovered width 1", "Error 1105 (HY000): panic recovered: invalid hash length: 1", true},
		{"unwrapped panic text", "panic: invalid hash length: 19", true},
		{"unrelated recovered panic", "Error 1105 (HY000): panic recovered: index out of range", false},
		{"ordinary sql error", "Error 1062 (23000): duplicate entry", false},
		{"lock wait timeout", "Error 1205 (HY000): lock wait timeout exceeded", false},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			db := vdFreshPass(errors.New(c.errText))
			defer db.Close()

			err := vdRunInitial(db)
			if c.wantSurvive && err != nil {
				t.Fatalf("%q carries the storage-decode signature and must be tolerated, got: %v", c.errText, err)
			}
			if !c.wantSurvive && err == nil {
				t.Fatalf("%q is not the storage-decode signature and must abort the pass, got nil", c.errText)
			}
		})
	}
}

// TestVerifyDriftSkipResumes drives the re-key across TWO passes on one clone
// and asserts the drift skip is RESUMABLE, not permanent: a table skipped
// because its storage could not be decoded on the first pass is re-keyed by a
// later pass once the storage reads cleanly again.
//
// This is the property that separates a correct fix from the naive fork fix the
// task is built to reject (classify the drift, skip the table, return nil — but
// keep NO durable record of the skip). The skip completes the pass, so the
// clone-local convergence marker is recorded in that same run, and the marker
// gate then bars the re-key from ever running again. Unless the fix kept a
// durable, clone-local record of what it skipped (and re-admits the re-key off
// that record), the skipped table keeps its pre-convergence, cross-clone-
// divergent ids forever. The naive no-record fix passes every single-pass check
// above yet fails here, because on the second pass nothing re-admits the re-key.
//
// It observes the skip purely through the harness's `selected` counter — did the
// second pass scan the previously-skipped table — so it says nothing about WHERE
// or under what key the skip was recorded. The backing persists every record a
// fix writes (a comma-list under one local_metadata key, a per-table key read
// back with LIKE, a kept in-flight sentinel, or a separate dolt-ignored table
// all round-trip identically), so every record representation the task
// permits re-admits the re-key here. It asserts resumability only, not the
// scoped-subset nuance: a fix that resumes by re-keying every aux table (rather
// than only the recorded one) still satisfies this check.
func TestVerifyDriftSkipResumes(t *testing.T) {
	events := auxRekeyTables[0].name

	// Pass 1: a fresh, marker-pending clone whose events table carries the
	// storage drift. A correct fix skips events, records the skip durably, and
	// completes the pass (which is what lets the convergence marker be recorded).
	h := vdNewHarness()
	h.cursorExists = true
	h.currentVersion = auxRekeyPassInitial.markerVersion - 1
	h.sentinelTablesPresent = true
	h.sentinelColumnPresent = true
	h.localMetaExists = true
	h.idColumns[events] = true
	h.scanErr[events] = vdDriftErr
	db := vdOpen(h)
	defer db.Close()

	if _, err := rekeyAuxRowIDs(context.Background(), db,
		auxRekeyPassInitial.shippedMainVersion-1, auxRekeyPassInitial); err != nil {
		t.Fatalf("pass 1: a storage-decode failure on events must not abort the re-key, got: %v", err)
	}
	if h.selected[events] == 0 {
		t.Fatalf("pass 1: events was never scanned, so the drift was never encountered — check the harness setup")
	}

	// Between the passes the lineage records the convergence marker (the skip
	// completed the pass) and the storage is repaired, so events now reads
	// cleanly. The marker alone would bar the re-key forever; only a durable
	// skip record can re-admit it.
	h.currentVersion = auxRekeyPassInitial.markerVersion
	delete(h.scanErr, events)
	h.selected = map[string]int{}
	h.updated = map[string]int{}

	// Pass 2: post-marker, past the shipped watershed — exactly the steady state
	// in which only a durable drift record can re-admit the re-key.
	if _, err := rekeyAuxRowIDs(context.Background(), db,
		auxRekeyPassInitial.shippedMainVersion, auxRekeyPassInitial); err != nil {
		t.Fatalf("pass 2: resuming the skipped re-key must not error, got: %v", err)
	}
	if h.selected[events] == 0 {
		t.Fatal("pass 2: the previously-skipped events table was never re-keyed after the marker was recorded — " +
			"the skip is permanent, not resumable. A correct fix keeps a durable clone-local record of the skip and " +
			"uses it to re-admit the re-key once the marker gate would otherwise bar it; the naive 'skip and return nil " +
			"without any durable record' fix fails here.")
	}
}

// TestVerifyPackageSuiteGreen guards against a partial change that compiles this
// one check but leaves the migration package's own suite broken. It builds and
// runs that suite in a child process, skipping checks named here (to avoid
// re-entering this one) and the tests that shell out to an external Dolt binary
// the environment does not provide.
func TestVerifyPackageSuiteGreen(t *testing.T) {
	if os.Getenv("VD_SUITE_INNER") == "1" {
		t.Skip("inner suite run")
	}
	root := vdModuleRoot(t)

	// First the whole module compiles: a change that renames or removes a symbol
	// but leaves a caller in another package behind fails here, not at runtime.
	build := exec.Command("go", "build", "./...")
	build.Dir = root
	build.Env = append(os.Environ(), "VD_SUITE_INNER=1")
	if out, err := build.CombinedOutput(); err != nil {
		t.Fatalf("the module does not build after the change:\n%s", out)
	}

	// Then the migration package's own suite runs. The tests that drive a real
	// Dolt CLI self-skip when no dolt binary is on PATH
	// (internal/testutil.RequireDoltBinary), so this stays green without one.
	// -skip avoids re-entering the TestVerify* checks in the child run.
	cmd := exec.Command("go", "test", "-count=1", "-skip", "^TestVerify", "./internal/storage/schema/")
	cmd.Dir = root
	cmd.Env = append(os.Environ(), "VD_SUITE_INNER=1")
	if out, err := cmd.CombinedOutput(); err != nil {
		t.Fatalf("migration package build/suite is not green after the change:\n%s", out)
	}
}

func vdModuleRoot(t *testing.T) string {
	t.Helper()
	dir, err := os.Getwd()
	if err != nil {
		t.Fatalf("getwd: %v", err)
	}
	for {
		if _, err := os.Stat(filepath.Join(dir, "go.mod")); err == nil {
			return dir
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			t.Fatalf("go.mod not found upward from %s", dir)
		}
		dir = parent
	}
}
