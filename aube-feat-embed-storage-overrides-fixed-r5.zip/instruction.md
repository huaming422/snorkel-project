## Task

Add `install_with_overrides` and `add_with_overrides` to `aube::embed` so embedding programs can choose storage for each call. Each entry point takes its existing counterpart's inputs plus a public override value with optional cache-directory, store-directory, and global-virtual-store fields.

## User stories / requirements

- A host can select the cache, store and global-virtual-store policy over ambient settings. Cache and store paths must be honored exactly, including non-UTF-8 paths. Disabling shared storage keeps installed files project-local; enabling it uses shared materialization. Later installs honor a different selected store even when the project is already installed.
- A host can add a dependency using its own storage choices. Both the manifest update and the install it triggers use those choices, including when adding to an already installed project with a different selected store.
- A stored file's recorded path survives serialization and deserialization without losing or changing any native path bytes, including paths that are not valid UTF-8.
- Overrides belong to one invocation. Concurrent and later install or add calls retain their own storage choices, and applying an override does not change process-wide or on-disk configuration.
- A host can leave any override field unset, alone or in combination with other overrides, and keep the ambient value for that field.
- Existing callers can continue to use plain install, plain add and the standalone CLI with their normal ambient storage and materialization behavior.
