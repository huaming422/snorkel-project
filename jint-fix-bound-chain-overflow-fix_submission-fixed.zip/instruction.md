## Task

We embed Jint in a host app that executes scripts written by a code generator we don't control.
Now and then one of those scripts kills our process outright.
Our exception handler never fires.
There's no .NET exception at all, the app is just gone.
The few logs we captured stop at `Stack overflow.`, with a single frame repeated thousands of times under it.

We can't reproduce it on demand.
The same script dies on some machines and builds but not others, and a single process may get through it once and crash on it later.
Every script we traced it to keeps calling bind on the result of the last bind, sometimes with a proxy wrapped around it in between, and then calls the result or uses it with new.

Scripts like those shouldn't be able to take the host process down.
Chains like that are valid JavaScript, so building one or passing it to other code should give the same results a short chain gives.
If calling through a chain needs more stack than there is, the usual catchable `Maximum call stack size exceeded` RangeError is fine.
