#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
# No assertions here. It only brings the package closure baked into the image
# online, so the verifier's `dotnet test` starts against a warm cache.
cd /repo/jint

# Offline switches so a cache miss fails fast instead of hanging on a dead feed.
# The image baked the full NuGet closure at the base commit into
# NUGET_PACKAGES=/root/.nuget/packages; restore reads that folder before any
# remote feed, so a complete bake needs no network.
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_NOLOGO=1 DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1
export NUGET_PACKAGES=/root/.nuget/packages

# Dependencies: offline-first against the image bake, logged online fallback.
# The verifier compiles the shipped library and the public-API suite; restore
# both so a later `dotnet build --no-restore` is a pure compile.
PUB=Jint.Tests.PublicInterface/Jint.Tests.PublicInterface.csproj
if dotnet restore "$PUB" > /tmp/test-setup-restore.log 2>&1; then
    echo "[offline-first] NuGet closure satisfied from image"
elif dotnet restore "$PUB" --force-evaluate >> /tmp/test-setup-restore.log 2>&1; then
    echo "[test-setup] NuGet restored online (image bake was stale)"
else
    tail -60 /tmp/test-setup-restore.log >&2; exit 1
fi
