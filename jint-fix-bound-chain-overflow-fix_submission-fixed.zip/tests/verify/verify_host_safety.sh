#!/usr/bin/env bash
# Host-survival route. Grows a deep script-controlled chain of repeatedly bound
# (and, for one case, proxy-interleaved) functions and drives it through the
# construct / is-constructor and realm-resolution machinery on a dedicated
# thread with a small native stack. A per-link native descent ends the whole
# test host (native "Stack overflow.", process gone) and this script exits
# nonzero; a bounded-native-stack walk lets each route answer or raise a
# catchable JavaScript error, the thread completes, and `dotnet test` exits 0.
# The surviving process reaching a clean exit is itself the signal.
set -euo pipefail
cd /repo/jint

# Offline switches so a cache miss fails fast rather than hanging on a dead
# feed; the image baked the full package closure at the base commit here.
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_NOLOGO=1 DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1
export NUGET_PACKAGES=/root/.nuget/packages

PROJ=Jint.Tests.PublicInterface

# Place both fixtures into the public-API suite so they compile against the
# shipped engine surface alone (this is the one suite without internals access).
# Both are copied by each script so the compile set is identical between the two
# invocations: whichever runs first compiles, the other reuses an up-to-date build.
cp -f /tests/verify/DeepChainHostSafety.cs "$PROJ/DeepChainHostSafety.cs"
cp -f /tests/verify/DeepChainSemantics.cs "$PROJ/DeepChainSemantics.cs"

exec dotnet test --project "$PROJ/$PROJ.csproj" -c Release -f net10.0 \
    --no-progress --filter "FullyQualifiedName~DeepChainHostSafety"
