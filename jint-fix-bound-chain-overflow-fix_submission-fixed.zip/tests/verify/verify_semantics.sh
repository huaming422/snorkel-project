#!/usr/bin/env bash
# Semantics route. Ordinary shallow inputs on both the construct and realm paths,
# the first-non-bound-target precedence of the is-constructor verdict, and the
# catchable TypeError a revoked proxy still produces during realm resolution.
# These involve no deep chain, so they answer the same before and after the fix;
# a change that de-recurses by dropping a check or mangling terminal-object
# precedence makes one of them read differently and this script exits nonzero.
set -euo pipefail
cd /repo/jint

# Offline switches so a cache miss fails fast rather than hanging on a dead
# feed; the image baked the full package closure at the base commit here.
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_NOLOGO=1 DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1
export NUGET_PACKAGES=/root/.nuget/packages

PROJ=Jint.Tests.PublicInterface

# Place both fixtures into the public-API suite so they compile against the
# shipped engine surface alone (this is the one suite without internals access).
# Both are copied by each script so the compile set is identical between the two
# invocations: whichever runs first compiles, the other reuses an up-to-date build.
cp -f /tests/verify/DeepChainHostSafety.cs "$PROJ/DeepChainHostSafety.cs"
cp -f /tests/verify/DeepChainSemantics.cs "$PROJ/DeepChainSemantics.cs"

exec dotnet test --project "$PROJ/$PROJ.csproj" -c Release -f net10.0 \
    --no-progress --filter "FullyQualifiedName~DeepChainSemantics"
