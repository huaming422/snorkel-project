#nullable enable

using Jint;

namespace Jint.Tests.PublicInterface;

// Uses the shipped engine surface only (Engine.Execute / Engine.Evaluate). A script grows a very
// long chain out of repeatedly bound functions (with proxies in between for one case), then asks
// the chain whether it can construct and which realm it belongs to. Everything runs on a dedicated
// thread with a small native stack, so a walk that spends one native frame per link overflows the
// same way on every machine and build instead of depending on what the JIT does.
//
// Two fixture classes:
//   * DeepChainHostSafety: deep chains. Each step either returns the value the language defines or
//     throws a JavaScript error that script can catch, and the thread finishes. A native
//     "Stack overflow." ends the whole test host, so `dotnet test` exits nonzero.
//   * DeepChainSemantics (separate file): short chains and the revoked-proxy case, which give the
//     same answers at the base commit and after the change.

public class DeepChainHostSafety
{
    // Far past the ~16,000 native frames a 1 MB stack held when each link cost one frame, and still
    // cheap to build: growing a bind chain is linear, well under a second in Release.
    private const int ChainLength = 200000;

    // static readonly, not const: the script text is built by concatenating the int ChainLength into
    // a string, which is a runtime operation rather than a compile-time constant expression.
    private static readonly string BuildBoundChain =
        "var f = function () {}; for (var i = 0; i < " + ChainLength + "; i++) f = f.bind(null);";

    // Same length, but the innermost target is an arrow function, so the whole chain is not a
    // constructor however many binds sit above it.
    private static readonly string BuildBoundArrowChain =
        "var g = () => {}; for (var i = 0; i < " + ChainLength + "; i++) g = g.bind(null);";

    // A proxy and a bind in turn, so realm resolution walks both kinds of link. 100,000 iterations
    // is 200,000 links in all.
    private static readonly string BuildMixedChain =
        "var f = function () {}; for (var i = 0; i < " + (ChainLength / 2) + "; i++) f = new Proxy(f, {}).bind(null);";

    [Test]
    public void ConstructingThroughADeepBoundChainAnswersOrRaisesCatchablyAndTheHostSurvives()
    {
        DedicatedThread.Run(() =>
        {
            using var engine = new Engine();
            engine.Execute(BuildBoundChain);
            engine.Execute(BuildBoundArrowChain);

            // These only ask whether the chain can construct. Nothing is called through it, so the
            // answer is a value, the same one a short chain gives.
            Outcome(engine, "return typeof new Proxy(f, {});").Should().Be("function");
            Outcome(engine, "Reflect.construct(function () {}, [], g); return 'constructed';").Should().StartWith("TypeError:");
            Outcome(engine, "new g(); return 'constructed';").Should().StartWith("TypeError:");

            // `new` runs construction down every link. Getting to the end is fine, and so is the
            // catchable RangeError the engine raises when the native stack runs low on the way.
            var constructed = Outcome(engine, "new f(); return 'constructed';");
            (constructed == "constructed" || constructed.StartsWith("RangeError:", StringComparison.Ordinal))
                .Should().BeTrue($"new over the deep chain should finish or throw a RangeError, but gave '{constructed}'");

            engine.Evaluate("6 * 7").AsNumber().Should().Be(42);
        }, maxStackSize: 1024 * 1024);
    }

    [Test]
    public void ResolvingTheRealmThroughADeepChainAnswersOrRaisesCatchablyAndTheHostSurvives()
    {
        DedicatedThread.Run(() =>
        {
            using var engine = new Engine();
            engine.Execute(BuildBoundChain);

            // Reflect.construct with the chain as newTarget: the default prototype is taken from the
            // chain's realm, which is found by going down to the innermost target. Nothing is called
            // through the chain, so this yields a value.
            Outcome(
                engine,
                "return String(Object.getPrototypeOf(Reflect.construct(function () {}, [], f)) === Object.prototype);")
                .Should().Be("true");

            // An array whose constructor is the chain drives the species path, which looks up the
            // chain's realm the same way.
            Outcome(
                engine,
                "var a = []; a.constructor = f; return String(Array.isArray(a.map(function (x) { return x; })));")
                .Should().Be("true");

            engine.Evaluate("6 * 7").AsNumber().Should().Be(42);
        }, maxStackSize: 1024 * 1024);
    }

    [Test]
    public void ResolvingTheRealmThroughADeepMixedBoundAndProxyChainAnswersAndTheHostSurvives()
    {
        DedicatedThread.Run(() =>
        {
            using var engine = new Engine();
            engine.Execute(BuildMixedChain);

            // Realm resolution has to get past bound links and proxy links alike without a native
            // frame per link. Reflect.construct over the mixed chain drives exactly that lookup.
            Outcome(
                engine,
                "return String(Object.getPrototypeOf(Reflect.construct(function () {}, [], f)) === Object.prototype);")
                .Should().Be("true");

            engine.Evaluate("6 * 7").AsNumber().Should().Be(42);
        }, maxStackSize: 1024 * 1024);
    }

    private static string Outcome(Engine engine, string body)
    {
        return engine.Evaluate("""
            (function () {
                try {
            """ + body + """
                } catch (error) { return error.name + ':' + error.message; }
            })();
            """).AsString();
    }
}
