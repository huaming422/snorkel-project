#nullable enable

using Jint;

namespace Jint.Tests.PublicInterface;

// Uses the shipped engine surface only. These are the answers that must not move when the per-link
// native descent goes away: short chains on both the construct and the realm route, the rule that
// the innermost non-bound target decides whether a bound chain can construct, and the catchable
// TypeError a revoked proxy still gives during realm resolution. None of them builds a deep chain,
// so they hold at the base commit too. A rewrite that drops a check on the way (the revoked-proxy
// throw, say) or answers from the wrong link changes one of these results.

public class DeepChainSemantics
{
    [Test]
    public void AShallowBoundConstructorStillConstructs()
    {
        using var engine = new Engine();

        // new over a singly-bound constructor works and preserves the constructed shape.
        engine.Evaluate("""
            (function () {
                function Point(x) { this.x = x; }
                var Bound = Point.bind(null);
                var p = new Bound(7);
                return p instanceof Point && p.x === 7;
            })();
            """).AsBoolean().Should().BeTrue();

        // Reflect.construct through a bound constructor is usable the same way.
        engine.Evaluate("""
            (function () {
                function Point(x) { this.x = x; }
                var p = Reflect.construct(Point, [9], Point.bind(null));
                return p.x === 9;
            })();
            """).AsBoolean().Should().BeTrue();
    }

    [Test]
    public void TheIsConstructorVerdictComesFromTheFirstNonBoundTarget()
    {
        using var engine = new Engine();

        // A bound (and proxy-wrapped, and multiply-bound) chain answers the is-constructor question
        // with its innermost non-bound target's verdict: a constructor stays constructible, and an
        // arrow / generator stays non-constructible, no matter how many bound links sit above it.
        engine.Evaluate("""
            (function () {
                function chain(target) { return target.bind(null).bind(null).bind(null); }
                function constructs(f) {
                    try { Reflect.construct(function () {}, [], f); return true; } catch (e) { return false; }
                }
                return [
                    constructs(chain(function () {})),
                    constructs(chain(() => {})),
                    constructs(chain(new Proxy(function () {}, {}))),
                    constructs(chain(class {})),
                    constructs(chain(function* () {}))
                ].join();
            })();
            """).AsString().Should().Be("true,false,true,true,false");
    }

    [Test]
    public void AProxyOverAFunctionResolvesToItsTargetsRealm()
    {
        using var engine = new Engine();

        // A newTarget whose prototype must be defaulted takes it from the realm of the function the
        // chain ends at, here the running realm reached through a shallow proxy-over-bound wrapper.
        engine.Evaluate("""
            (function () {
                var target = function () {};
                var newTarget = new Proxy(target, {}).bind(null);
                var o = Reflect.construct(function () {}, [], newTarget);
                return Object.getPrototypeOf(o) === Object.prototype;
            })();
            """).AsBoolean().Should().BeTrue();
    }

    [Test]
    public void ARevokedProxyOnTheRealmPathStillThrowsACatchableTypeError()
    {
        using var engine = new Engine();

        // Realm resolution over a chain that reaches a revoked proxy must still raise a catchable
        // TypeError; bound links above the revoked proxy do not hide it.
        engine.Evaluate("""
            (function () {
                var r = Proxy.revocable(function () {}, {});
                var newTarget = r.proxy.bind(null).bind(null);
                r.revoke();
                try {
                    Reflect.construct(function () {}, [], newTarget);
                    return 'no-throw';
                } catch (e) {
                    return e.name;
                }
            })();
            """).AsString().Should().Be("TypeError");
    }
}
