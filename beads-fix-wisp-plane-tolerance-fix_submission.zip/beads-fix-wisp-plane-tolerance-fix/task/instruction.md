## Task

Operators on some beads databases are reporting work totals that come back too low. The commands that summarize work (`bd count`, `bd count --by-<field>`, `bd ready`, and `bd search --counts`) leave the ephemeral wisp-plane items out of their numbers. They don't fail when this happens: they exit cleanly and print the understated total, so nothing signals anything was dropped.

It only reproduces on a database whose wisp plane is present but only partially set up, a drifted or partially-migrated clone where the wisp tables exist but one of the auxiliary tables they depend on is missing. On a clean database, and on a brand-new one with no wisp plane at all, the same commands come back correct.

Dig in and fix these read paths so the problem surfaces instead of being silently swallowed. The durable-issue side of these counts is already correct and needs to stay that way, and a fresh database that legitimately has no wisp plane yet should keep being treated as having no wisps to add rather than turned into an error.
