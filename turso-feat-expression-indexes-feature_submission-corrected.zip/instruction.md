## Task

`CREATE INDEX` accepts nothing but bare column names right now. A key such as `t(x * 2 + y)` or `t(upper(email))`, or even a column with its own `name COLLATE NOCASE`, fails with `cannot use expressions in CREATE INDEX`. A database file SQLite wrote with such an index won't open at all. Indexes on expressions should behave the way SQLite documents them (https://sqlite.org/expridx.html).

## User stories / requirements

- Filtering on an indexed expression, written as in the index, goes through that index and gives back the matching rows. Both `=` and range tests count, for arithmetic, function calls and `CAST`, and so do the leading keys of an index over several columns or expressions. EXPLAIN QUERY PLAN shows that index.
- Sorting by an indexed expression, `ASC` or `DESC`, with or without a filter on it, reads rows in index order. EXPLAIN QUERY PLAN shows that index and no `USE TEMP B-TREE FOR ORDER BY` step. NULL keys sort first, and an ORDER BY over an expression no index has still gets its sort step.
- When a query needs only indexed expressions, it reads the index alone. EXPLAIN QUERY PLAN shows the index on scans, column indexes too, as SQLite 3.50 and later do: `SCAN t USING COVERING INDEX i` if the table isn't read, else `SCAN t USING INDEX i`.
- INSERT, UPDATE, DELETE, upserts, OR REPLACE and OR IGNORE keep expression indexes in step, triggers included, and an UPDATE whose WHERE reads the index it changes hits every matching row. SQLite's `PRAGMA integrity_check` on the file reports ok. A UNIQUE one refuses a taken computed key; a partial one covers what its WHERE accepts.
- COLLATE on an index key, whether on a column (`name COLLATE NOCASE`) or an expression, behaves as SQLite's does. A NOCASE unique key treats `Alice` and `ALICE` as the same value for INSERT and upserts. An `ON CONFLICT` target matches it only if the collations agree, in any column order.
- CREATE INDEX turns down expressions SQLite won't index, like `random()`, a subquery, a parameter or another table's column, and takes deterministic functions such as `abs()`. SQLite reads, checks and enforces expression indexes we wrote, and we open, use and update ones SQLite wrote. Plain and partial column indexes work as before.
