"""Build check for turso-feat-expression-indexes.

Expression indexes only show when SQL runs against a built engine (create an
index on an expression, then watch the planner use it and the writes keep it
right), and the stories do that through the shipped `tursodb` shell. This file
checks the one thing they assume: the workspace, with the repository's own
integration-test crate, still compiles after the change.

It runs `cargo build -p core_tester --tests` in the repo. `core_tester` is the
repository's integration-test package (named in `tests/Cargo.toml`); building it
with `--tests` compiles everything it pulls in, the `core` crate included, and
the repository's own tests that build schema structs by hand. The check:

  - imports no module a solution adds,
  - greps for no new symbol, file or helper,
  - runs no `cargo test`, so it doesn't care which test names exist.

An unchanged tree builds, so this check alone passes it; a change that breaks
the build fails here.
"""

from __future__ import annotations

import os
import subprocess
import textwrap


# Repository checkout inside the task container.
REPO_DIR = "/repo/turso"

# The repository's integration-test package, the stable `-p` build target
# (tests/Cargo.toml). Building it with --tests compiles the workspace crates it
# depends on, notably `core`.
PACKAGE = "core_tester"

# The image built the workspace `--lib --tests` already, so this build is
# incremental: usually well under a minute, a few minutes when a deep crate
# changed. Scaled by TIMEOUT_MULTIPLIER on a slow host.
BUILD_TIMEOUT_SEC = 900


def _multiplier() -> float:
    try:
        return max(1.0, float(os.environ.get("TIMEOUT_MULTIPLIER", "1") or 1))
    except ValueError:
        return 1.0


def test_integration_crate_builds() -> None:
    """`cargo build -p core_tester --tests` exits 0 on the changed tree.

    On failure, shows the last 200 lines of stdout and stderr so the build
    break is visible in the log without flooding it.
    """
    cmd = ["cargo", "build", "-p", PACKAGE, "--tests", "--message-format=short"]

    env = {**os.environ}
    env.setdefault("CARGO_HOME", "/opt/cargo")
    env.setdefault("RUSTUP_HOME", "/opt/rustup")
    env.setdefault("CARGO_TARGET_DIR", "/opt/cache/cargo-target")
    env["PATH"] = f"{env['CARGO_HOME']}/bin:" + env.get("PATH", "")

    result = subprocess.run(
        cmd,
        cwd=REPO_DIR,
        capture_output=True,
        text=True,
        timeout=BUILD_TIMEOUT_SEC * _multiplier(),
        env=env,
        check=False,
    )

    if result.returncode == 0:
        return

    def _tail(text: str, n: int = 200) -> str:
        return "\n".join(text.splitlines()[-n:])

    msg = textwrap.dedent(
        f"""\
        `cargo build -p {PACKAGE} --tests` failed (exit {result.returncode}).
        The changed workspace no longer compiles.
        Common causes:
          - A new match arm missing after an enum was extended
          - A new struct field missing where a struct is built by hand
          - A type/borrow/lifetime mismatch in the new code
          - Broken Cargo feature gating

        --- cargo build stdout (last 200 lines) ---
        {_tail(result.stdout)}

        --- cargo build stderr (last 200 lines) ---
        {_tail(result.stderr)}
        """
    )
    raise AssertionError(msg)
