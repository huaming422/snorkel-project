#!/usr/bin/env bash
# Story setup: runs after the code changes are in place, before any story.
# Two jobs:
#   1. Build the `tursodb` CLI binary from the current sources. The image built
#      the workspace libs and tests at the pinned commit, so this recompiles only
#      the crates that changed and links the binary: a few minutes cold, seconds
#      on a re-run.
#   2. Make the scratch folder for the cases that share a database file with
#      SQLite.
# This file is sourced, so it never exits: a tree that doesn't build leaves no
# binary behind, every story then fails to run it, and test.sh carries on.

REPO=/repo/turso

export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export RUSTUP_TOOLCHAIN="${RUSTUP_TOOLCHAIN:-1.88.0}"
export PATH="$CARGO_HOME/bin:$PATH"

# Keep this path in step with TURSODB in test_harness.py.
TURSODB="$CARGO_TARGET_DIR/debug/tursodb"
SCRATCH=/tmp/expr_index_scratch

echo "validation-setup: rustc=$(rustc --version 2>&1 | head -1)"
echo "validation-setup: cargo=$(cargo --version 2>&1 | head -1)"

# --locked keeps the dependency set the one the image cached (no network here).
echo "validation-setup: building tursodb (incremental)..."
if ! ( cd "$REPO" && cargo build --locked -p turso_cli --bin tursodb > /tmp/validation_build.log 2>&1 ); then
    echo "ERROR: cargo build of tursodb failed; the stories will find no binary" >&2
    tail -80 /tmp/validation_build.log >&2
    rm -f "$TURSODB"
fi
if [ -x "$TURSODB" ]; then
    echo "validation-setup: tursodb built at $TURSODB ($("$TURSODB" --version 2>&1 | head -1))"
else
    echo "ERROR: tursodb binary missing at $TURSODB after cargo build" >&2
fi

rm -rf "$SCRATCH"
mkdir -p "$SCRATCH"

# If the binary can't run a trivial statement, every story fails with the same
# opaque error; say so here instead.
if [ -x "$TURSODB" ] && ! printf 'SELECT 1;\n' | "$TURSODB" -m list -q :memory: > /dev/null 2>&1; then
    echo "ERROR: tursodb could not run SELECT 1" >&2
fi

echo "validation-setup: done. binary=$TURSODB scratch=$SCRATCH"
