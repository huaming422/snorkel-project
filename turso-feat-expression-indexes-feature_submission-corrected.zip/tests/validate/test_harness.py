"""Shared helpers for the turso-feat-expression-indexes stories.

Every story drives the repository's own SQL shell, the `tursodb` binary that
`validation-setup.sh` builds from the current source. A case pipes a SQL script
to the binary over stdin and reads what a user of the shell sees: the result
rows, whether a statement was refused, and the `EXPLAIN QUERY PLAN` lines. Some
cases also share a database file with SQLite itself (python's `sqlite3`
module), in either direction, to check that the file stays interchangeable.

`observe(inputs)` runs one case and returns every value the stories compare:

    errored  True when any statement of inputs["sql"] was refused
    rows     the result rows printed by inputs["sql"], one string per row,
             columns joined by "|" and NULL printed as "NULL"
    index    the index EXPLAIN QUERY PLAN names for inputs["plan_table"] while
             it runs inputs["plan_query"] ("" when it names none)
    sorts    True when that plan has a separate sorting step
             ("USE TEMP B-TREE FOR ORDER BY")
    scan     the plan line for inputs["plan_table"] with the tree marks and
             any trailing "(...)" detail removed, e.g. "SCAN t USING INDEX i"
    sqlite   what SQLite prints for inputs["sqlite_after"] on the same file

Nothing here names anything a solution adds: the binary, its list output mode,
the plan text and SQLite's own `PRAGMA integrity_check` all exist already.
"""

from __future__ import annotations

import hashlib
import os
import re
import sqlite3
import subprocess

# The binary validation-setup.sh builds. CARGO_TARGET_DIR is /opt/cache/cargo-target
# in the image, so it lands there rather than under the repository's target/.
TURSODB = "/opt/cache/cargo-target/debug/tursodb"

# Database files for the cases that share a file with SQLite. validation-setup.sh
# makes this folder; each case starts from a fresh file in it.
SCRATCH = "/tmp/expr_index_scratch"


def _scaled(seconds: float) -> float:
    """Wall-clock limits grow with TIMEOUT_MULTIPLIER on a slow host."""
    try:
        multiplier = float(os.environ.get("TIMEOUT_MULTIPLIER", "1") or 1)
    except ValueError:
        multiplier = 1.0
    return seconds * max(1.0, multiplier)


def run_sql(script: str, db: str = ":memory:") -> subprocess.CompletedProcess:
    """Pipe ``script`` to tursodb in quiet list mode and return the finished process.

    ``db`` is ``:memory:`` (one in-memory session per call) or a file path. The
    shell runs every statement in order and goes on after a refused one, so a
    trailing SELECT still shows what the table holds.
    """
    cmd = [TURSODB, "-m", "list", "-q", "--experimental-index-method", db]
    return subprocess.run(
        cmd,
        input=script,
        capture_output=True,
        text=True,
        timeout=_scaled(90),
        env={**os.environ},
        check=False,
    )


# A refused statement prints a diagnostic block: a line that starts with one of
# these marks (or carries the box-drawing bar), then indented continuation lines.
_DIAG_PREFIXES = ("×", "Error:", "error:", "╭", "╮", "╰", "╯", "·", "help:")
_DIAG_BAR = "│"  # U+2502, not the ASCII "|" that joins data columns


def _split(result: subprocess.CompletedProcess) -> tuple[list[str], bool]:
    """Data lines of stdout with every diagnostic block removed, and whether any was seen."""
    out: list[str] = []
    in_diag = False
    seen = False
    for line in (result.stdout or "").splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith(_DIAG_PREFIXES) or _DIAG_BAR in stripped:
            in_diag = seen = True
            continue
        if in_diag and line != line.lstrip():
            continue
        in_diag = False
        out.append(stripped)
    return out, seen


def errored(result: subprocess.CompletedProcess) -> bool:
    """True when the shell refused a statement: a non-zero exit, or a diagnostic
    on either stream."""
    if result.returncode != 0:
        return True
    _, seen = _split(result)
    err = (result.stderr or "").strip()
    return seen or bool(err)


def rows(result: subprocess.CompletedProcess) -> list[str]:
    """The result rows, diagnostics removed, up to the first QUERY PLAN header."""
    lines, _ = _split(result)
    if "QUERY PLAN" in lines:
        lines = lines[: lines.index("QUERY PLAN")]
    return lines


def plan_lines(result: subprocess.CompletedProcess) -> list[str]:
    """The EXPLAIN QUERY PLAN detail lines after the last QUERY PLAN header, with the
    tree marks ("|--", "`--", "|  ") removed."""
    lines, _ = _split(result)
    if "QUERY PLAN" not in lines:
        return []
    start = len(lines) - lines[::-1].index("QUERY PLAN")
    return [re.sub(r"^[|`\- ]+", "", line).strip() for line in lines[start:]]


_ACCESS = re.compile(r"^(SCAN|SEARCH) (\S+)(?: AS \S+)?(?: USING (?:COVERING )?INDEX (\S+))?")


def index_used(lines: list[str], table: str) -> str:
    """The index the plan reads ``table`` through, or "" when it names none."""
    for line in lines:
        match = _ACCESS.match(line)
        if match and match.group(2) == table and match.group(3):
            return match.group(3)
    return ""


def scan_line(lines: list[str], table: str) -> str:
    """The plan line for ``table``, without a trailing "(...)" detail."""
    for line in lines:
        match = _ACCESS.match(line)
        if match and match.group(2) == table:
            return re.sub(r"\s*\(.*\)\s*$", "", line)
    return ""


def sorts(lines: list[str]) -> bool:
    """True when the plan has a separate sorting step for ORDER BY."""
    return any("USE TEMP B-TREE FOR ORDER BY" in line for line in lines)


def fresh_db(name: str) -> str:
    """A path under SCRATCH with no database file, journal or WAL left from earlier."""
    os.makedirs(SCRATCH, exist_ok=True)
    path = os.path.join(SCRATCH, re.sub(r"[^A-Za-z0-9_]", "_", name) + ".db")
    for suffix in ("", "-wal", "-shm", "-journal", "-log"):
        try:
            os.remove(path + suffix)
        except FileNotFoundError:
            pass
    return path


def sqlite_run(db: str, script: str) -> list[str]:
    """Run ``script`` with SQLite on the file ``db`` and return every row printed,
    columns joined by "|" and NULL as "NULL". An error comes back as one row
    "error: <message>", and the statements after it don't run."""
    out: list[str] = []
    con = sqlite3.connect(db, timeout=_scaled(30))
    try:
        for statement in [s.strip() for s in script.split(";") if s.strip()]:
            try:
                cursor = con.execute(statement)
                for row in cursor.fetchall():
                    out.append("|".join("NULL" if v is None else str(v) for v in row))
                con.commit()
            except sqlite3.Error as error:
                out.append(f"error: {error}")
                break
    finally:
        con.close()
    return out


def observe(inputs: dict) -> dict:
    """Run one case and return errored, rows, index, sorts, scan and sqlite.

    inputs["sql"]           SQL piped to tursodb
    inputs["plan_query"]    a query whose EXPLAIN QUERY PLAN is read after the
                            script ran ("" for none)
    inputs["plan_table"]    the table the plan values are about
    inputs["sqlite_before"] SQL SQLite runs on a fresh file first ("" for none)
    inputs["sqlite_after"]  SQL SQLite runs on that file after tursodb ("" for none)

    With either sqlite_* field set, the case runs on a fresh database file;
    otherwise it runs in memory. The plan query runs in the same tursodb session,
    after the script, so it sees the data the script left.
    """
    sql = inputs["sql"]
    plan_query = inputs.get("plan_query", "")
    table = inputs.get("plan_table", "t")
    before = inputs.get("sqlite_before", "")
    after = inputs.get("sqlite_after", "")
    on_file = bool(before or after)
    tag = hashlib.sha1((sql + before + after).encode()).hexdigest()[:12]
    db = fresh_db("case_" + tag) if on_file else ":memory:"
    if before:
        sqlite_run(db, before)
    script = sql if not plan_query else sql.rstrip() + "\nEXPLAIN QUERY PLAN " + plan_query + ";\n"
    result = run_sql(script, db)
    lines = plan_lines(result) if plan_query else []
    return {
        "errored": errored(result),
        "rows": rows(result),
        "index": index_used(lines, table),
        "sorts": sorts(lines),
        "scan": scan_line(lines, table),
        "sqlite": sqlite_run(db, after) if after else [],
    }
