#!/usr/bin/env bash
# Setup that runs before the build check, with network available.
# The image already installed the Rust toolchain, filled the cargo registry for
# the pinned commit, fetched every workspace dependency and built the workspace
# --lib --tests, so the next build is incremental.
# This script only puts the toolchain back on PATH (each step starts a fresh
# shell, so Dockerfile ENV from RUN layers isn't inherited) and checks that the
# toolchain is there.
set -euo pipefail

export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export PATH="$CARGO_HOME/bin:$PATH"

rustc --version >/dev/null 2>&1 || {
    echo "ERROR: rustc not found on PATH (CARGO_HOME=$CARGO_HOME)" >&2
    exit 1
}
cargo --version >/dev/null 2>&1 || {
    echo "ERROR: cargo not found on PATH" >&2
    exit 1
}

echo "test-setup: rustc=$(rustc --version), cargo=$(cargo --version | head -1)"
