import sys
import os
sys.path.insert(0, "/tests/validate")
from test_harness import new_world, write, run, combined, home_path


def test_lenient_skips(inputs, expected):
    """Test that unknown modes and relative targets warn+skip, missing sources error, etc."""
    scenario = inputs["scenario"]
    workdir, env = new_world()

    if scenario == "unknown_mode":
        # Valid good entry + bad entry with unknown mode "hardlink"
        write(workdir, "dotfiles/good", "good\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.good" = "dotfiles/good"\n'
              '"~/.unknownmode" = { source = "dotfiles/good", mode = "hardlink" }\n')
        bad_target = home_path(env, ".unknownmode")
        good_target = home_path(env, ".good")

    elif scenario == "relative_target":
        # Valid good entry + bad entry with relative target key
        write(workdir, "dotfiles/good", "good\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.good" = "dotfiles/good"\n'
              '"relative/path" = "dotfiles/good"\n')
        bad_target = os.path.join(workdir, "relative/path")
        good_target = home_path(env, ".good")

    elif scenario == "missing_source":
        # Valid good entry + bad entry with nonexistent source
        write(workdir, "dotfiles/good", "good\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.good" = "dotfiles/good"\n'
              '"~/.missing" = "dotfiles/does-not-exist"\n')
        bad_target = home_path(env, ".missing")
        good_target = home_path(env, ".good")

    elif scenario == "report_all":
        # TWO bad entries, no good entry
        write(workdir, "dotfiles/bad.tmpl", "{{ not_a_real_function() }}\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.missing" = "dotfiles/none"\n'
              '"~/.broken" = { source = "dotfiles/bad.tmpl", mode = "template" }\n')
        bad_target = None  # skip the bad_target check for this scenario
        good_target = None  # skip the good_target check for this scenario

    else:
        raise ValueError(f"Unknown scenario: {scenario}")

    # Run status first (always exits 0)
    status = run(["system", "status"], workdir, env)

    # Run install
    install = run(["system", "install"], workdir, env)
    out = combined(install)

    # EXPECTED: status always exits 0
    assert status.returncode == 0, (
        f"Expected status to exit 0, got {status.returncode}.\n"
        f"Output: {combined(status)}"
    )

    # EXPECTED: (install.returncode != 0) is (expected["install_exit"] == "nonzero")
    expected_nonzero = expected["install_exit"] == "nonzero"
    assert (install.returncode != 0) == expected_nonzero, (
        f"Expected install returncode {'!= 0' if expected_nonzero else '== 0'}, "
        f"got {install.returncode}.\nOutput: {out}"
    )

    # EXPECTED: when expected["bad_target"] != "__skip__", check bad target existence
    if expected["bad_target"] != "__skip__":
        bad_target_expected = expected["bad_target"] == "present"
        assert os.path.lexists(bad_target) == bad_target_expected, (
            f"Expected bad_target '{bad_target}' lexists == {bad_target_expected}, "
            f"got {os.path.lexists(bad_target)}"
        )

    # EXPECTED: when expected["good_target"] != "__skip__", check good target existence
    if expected["good_target"] != "__skip__":
        good_target_expected = expected["good_target"] == "present"
        assert os.path.lexists(good_target) == good_target_expected, (
            f"Expected good_target '{good_target}' lexists == {good_target_expected}, "
            f"got {os.path.lexists(good_target)}"
        )

    # EXPECTED: when expected["status_shows"] != "__skip__", check status output
    if expected["status_shows"] != "__skip__":
        status_out = combined(status)
        assert expected["status_shows"] in status_out, (
            f"Expected '{expected['status_shows']}' in status output.\n"
            f"Got: {repr(status_out)}"
        )

    # EXPECTED: when expected["report_all"] != "__skip__", both bad targets appear in install output
    if expected["report_all"] != "__skip__":
        assert "~/.missing" in out, (
            f"Expected '~/.missing' in install output.\nGot: {repr(out)}"
        )
        assert "~/.broken" in out, (
            f"Expected '~/.broken' in install output.\nGot: {repr(out)}"
        )
