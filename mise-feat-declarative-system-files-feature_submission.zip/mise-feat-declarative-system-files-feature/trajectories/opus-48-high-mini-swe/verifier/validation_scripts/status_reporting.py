import sys
import os
import json
sys.path.insert(0, "/tests/validate")
from test_harness import new_world, write, run, combined, home_path


def test_status_reporting(inputs, expected):
    """Test that mise system status reports the correct state for each scenario."""
    scenario = inputs["scenario"]
    workdir, env = new_world()

    if scenario == "applied":
        # default-mode file entry, installed so it's in desired state
        write(workdir, "dotfiles/gitconfig", "gitconfig content\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.gitconfig" = "dotfiles/gitconfig"\n')
        install_r = run(["system", "install"], workdir, env)
        assert install_r.returncode == 0, f"Install failed: {combined(install_r)}"

    elif scenario == "missing":
        # same entry but NOT installed (target absent)
        write(workdir, "dotfiles/gitconfig", "gitconfig content\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.gitconfig" = "dotfiles/gitconfig"\n')
        # Do NOT install

    elif scenario == "differs":
        # copy-mode file entry; install, then change source so target no longer matches
        write(workdir, "dotfiles/starship.toml", "starship config\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.config/starship.toml" = { source = "dotfiles/starship.toml", mode = "copy" }\n')
        install_r = run(["system", "install"], workdir, env)
        assert install_r.returncode == 0, f"Install failed: {combined(install_r)}"
        # Change source so target differs
        write(workdir, "dotfiles/starship.toml", "starship config v2\n")

    elif scenario == "source_missing":
        # entry whose source path does not exist
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.gitconfig" = "dotfiles/nonexistent"\n')
        # Do NOT install

    else:
        raise ValueError(f"Unknown scenario: {scenario}")

    # Run plain mise system status (always exits 0)
    status = run(["system", "status"], workdir, env)
    human = combined(status)

    # Run with drift-check flag (--missing exits non-zero when anything is out of state)
    check_run = run(["system", "status", "--missing"], workdir, env)

    # Run with machine-readable/JSON flag (-J or --json)
    json_run = run(["system", "status", "--json"], workdir, env)
    blob = json_run.stdout or ""

    # EXPECTED: expected["status_word"] is a substring of human output
    assert expected["status_word"] in human, (
        f"Expected status word '{expected['status_word']}' in status output.\n"
        f"Got: {repr(human)}"
    )

    # EXPECTED: (check_run.returncode != 0) is (expected["check_exit"] == "nonzero")
    expected_nonzero = expected["check_exit"] == "nonzero"
    assert (check_run.returncode != 0) == expected_nonzero, (
        f"Expected check_run returncode {'!= 0' if expected_nonzero else '== 0'}, "
        f"got {check_run.returncode}.\nOutput: {combined(check_run)}"
    )

    # EXPECTED: the JSON run's stdout parses as JSON
    try:
        parsed = json.loads(blob)
    except json.JSONDecodeError as e:
        assert False, (
            f"JSON run output did not parse as JSON: {e}\n"
            f"stdout: {repr(blob)}\nstderr: {repr(json_run.stderr)}"
        )

    # EXPECTED: when expected["json_word"] != "__skip__", expected["json_word"] is a
    #           substring of blob (raw JSON text)
    if expected["json_word"] != "__skip__":
        assert expected["json_word"] in blob, (
            f"Expected json_word '{expected['json_word']}' in JSON output.\n"
            f"Got: {repr(blob)}"
        )
