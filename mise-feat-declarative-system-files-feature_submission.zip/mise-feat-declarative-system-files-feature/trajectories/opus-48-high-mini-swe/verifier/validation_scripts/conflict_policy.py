import sys
import os
sys.path.insert(0, "/tests/validate")
from test_harness import new_world, write, run, combined, home_path


def test_conflict_policy(inputs, expected):
    """Test that conflicting pre-existing targets are handled correctly."""
    scenario = inputs["scenario"]
    workdir, env = new_world()

    if scenario == "file_blocks_symlink":
        # default-mode entry; before installing, create a real file at target
        write(workdir, "dotfiles/gitconfig", "gitconfig content\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.gitconfig" = "dotfiles/gitconfig"\n')
        target = home_path(env, ".gitconfig")
        os.makedirs(os.path.dirname(target), exist_ok=True)
        with open(target, "w") as f:
            f.write("precious\n")
        # First install must fail
        first_install = run(["system", "install"], workdir, env)
        # Check blocker survives
        if expected["blocker_survives"] != "__skip__":
            with open(target, "r") as f:
                content = f.read()
            assert content == expected["blocker_survives"], (
                f"Expected blocker content {repr(expected['blocker_survives'])}, "
                f"got {repr(content)}"
            )
        # Override install
        override_install = run(["system", "install", "--force"], workdir, env)
        assert override_install.returncode == 0, (
            f"Override install failed: {combined(override_install)}"
        )
        # Resolved: target is a symlink and reads "gitconfig content\n"
        with open(target, "r") as f:
            resolved_content = f.read()

    elif scenario == "file_blocks_dir":
        # symlink-each entry; before installing, create a real file at target dir path
        write(workdir, "dotfiles/bin/one", "one\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.local/mybin" = { source = "dotfiles/bin", mode = "symlink-each" }\n')
        target_dir = home_path(env, ".local/mybin")
        os.makedirs(os.path.dirname(target_dir), exist_ok=True)
        with open(target_dir, "w") as f:
            f.write("blocker\n")
        # First install must fail
        first_install = run(["system", "install"], workdir, env)
        # Check blocker survives
        if expected["blocker_survives"] != "__skip__":
            with open(target_dir, "r") as f:
                content = f.read()
            assert content == expected["blocker_survives"], (
                f"Expected blocker content {repr(expected['blocker_survives'])}, "
                f"got {repr(content)}"
            )
        # Override install
        override_install = run(["system", "install", "--force"], workdir, env)
        assert override_install.returncode == 0, (
            f"Override install failed: {combined(override_install)}"
        )
        # Resolved: reading ~/.local/mybin/one yields "one\n"
        target_one = home_path(env, ".local/mybin/one")
        with open(target_one, "r") as f:
            resolved_content = f.read()

    elif scenario == "copy_update_not_conflict":
        # copy entry; install; change source; install again (no --force needed)
        write(workdir, "dotfiles/starship.toml", "starship config\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.config/starship.toml" = { source = "dotfiles/starship.toml", mode = "copy" }\n')
        first_install = run(["system", "install"], workdir, env)
        # Change source
        write(workdir, "dotfiles/starship.toml", "starship v2\n")
        # Second install with no override flag (content update, not conflict)
        second_install = run(["system", "install"], workdir, env)
        assert second_install.returncode == 0, (
            f"Second install (content update) failed: {combined(second_install)}"
        )
        target = home_path(env, ".config/starship.toml")
        with open(target, "r") as f:
            resolved_content = f.read()

    else:
        raise ValueError(f"Unknown scenario: {scenario}")

    # EXPECTED: (first_install.returncode != 0) is (expected["first_exit"] == "nonzero")
    expected_nonzero = expected["first_exit"] == "nonzero"
    assert (first_install.returncode != 0) == expected_nonzero, (
        f"Expected first_install returncode {'!= 0' if expected_nonzero else '== 0'}, "
        f"got {first_install.returncode}.\nOutput: {combined(first_install)}"
    )

    # EXPECTED: when expected["blocker_survives"] != "__skip__", already checked above (inline)

    # EXPECTED: the resolved readback reads expected["resolved_content"]
    assert resolved_content == expected["resolved_content"], (
        f"Expected resolved content {repr(expected['resolved_content'])}, "
        f"got {repr(resolved_content)}"
    )
