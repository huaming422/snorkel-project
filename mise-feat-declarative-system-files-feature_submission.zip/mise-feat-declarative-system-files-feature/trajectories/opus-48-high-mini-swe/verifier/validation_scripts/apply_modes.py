import sys
import os
sys.path.insert(0, "/tests/validate")
from test_harness import new_world, write, run, combined, home_path


def test_apply_modes(inputs, expected):
    """Test that each mode applies correctly and is idempotent."""
    scenario = inputs["scenario"]
    workdir, env = new_world()

    install_results = []

    if scenario == "symlink_file":
        write(workdir, "dotfiles/gitconfig", "gitconfig content\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.gitconfig" = "dotfiles/gitconfig"\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)
        # primary is ~/.gitconfig -> symlink to dotfiles/gitconfig
        source_abs = os.path.join(workdir, "dotfiles/gitconfig")

    elif scenario == "copy_file":
        write(workdir, "dotfiles/starship.toml", "starship config\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.config/starship.toml" = { source = "dotfiles/starship.toml", mode = "copy" }\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)
        source_abs = os.path.join(workdir, "dotfiles/starship.toml")

    elif scenario == "template_file":
        write(workdir, "dotfiles/ssh.tmpl", "sum = {{ 1 + 1 }}\n", mode=0o600)
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.ssh/config" = { source = "dotfiles/ssh.tmpl", mode = "template" }\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)
        source_abs = os.path.join(workdir, "dotfiles/ssh.tmpl")

    elif scenario == "symlink_each_dir":
        write(workdir, "dotfiles/bin/one", "one\n")
        write(workdir, "dotfiles/bin/two", "two\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.local/mybin" = { source = "dotfiles/bin", mode = "symlink-each" }\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        # Create an unmanaged file in the target dir
        target_dir = home_path(env, ".local/mybin")
        unmanaged = os.path.join(target_dir, "unmanaged")
        with open(unmanaged, "w") as f:
            f.write("free\n")
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)
        # primary_rel is ".local/mybin/one" which is a symlink to dotfiles/bin/one
        source_abs = os.path.join(workdir, "dotfiles/bin/one")

    elif scenario == "symlink_dir":
        write(workdir, "dotfiles/nvim/init.lua", "init\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.config/nvim" = "dotfiles/nvim"\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)
        # primary is ~/.config/nvim -> symlink to dotfiles/nvim (dir)
        source_abs = os.path.join(workdir, "dotfiles/nvim")

    elif scenario == "copy_dir_additive":
        write(workdir, "dotfiles/bin/one", "one\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.local/copydir" = { source = "dotfiles/bin", mode = "copy" }\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        # Write unmanaged file into target
        target_dir = home_path(env, ".local/copydir")
        unmanaged = os.path.join(target_dir, "unmanaged")
        with open(unmanaged, "w") as f:
            f.write("keep me\n")
        # Change source
        write(workdir, "dotfiles/bin/one", "one v2\n")
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)
        # primary is the target dir itself (a real directory, not a symlink)
        source_abs = os.path.join(workdir, "dotfiles/bin")

    elif scenario == "empty_source_dir":
        # Create empty dir
        os.makedirs(os.path.join(workdir, "dotfiles/emptydir"), exist_ok=True)
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.local/emptydir" = { source = "dotfiles/emptydir", mode = "copy" }\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)
        source_abs = os.path.join(workdir, "dotfiles/emptydir")

    elif scenario == "template_perms_repair":
        write(workdir, "dotfiles/ssh.tmpl", "sum = {{ 1 + 1 }}\n", mode=0o644)
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.ssh/config" = { source = "dotfiles/ssh.tmpl", mode = "template" }\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        # chmod source to 0o600
        source_path = os.path.join(workdir, "dotfiles/ssh.tmpl")
        os.chmod(source_path, 0o600)
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)
        source_abs = os.path.join(workdir, "dotfiles/ssh.tmpl")

    elif scenario == "dangling_copy_repair":
        write(workdir, "dotfiles/starship.toml", "starship config\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.config/starship.toml" = { source = "dotfiles/starship.toml", mode = "copy" }\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        # Delete the target and replace with a dangling symlink
        target = home_path(env, ".config/starship.toml")
        os.remove(target)
        os.symlink("/nonexistent-source-xyz", target)
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)
        source_abs = os.path.join(workdir, "dotfiles/starship.toml")

    else:
        raise ValueError(f"Unknown scenario: {scenario}")

    # Resolve primary target path
    primary = home_path(env, expected["primary_rel"])

    # EXPECTED: every install run returned exit code 0
    for i, r in enumerate(install_results):
        assert r.returncode == 0, (
            f"Install run {i+1} failed with exit code {r.returncode}.\n"
            f"Output: {combined(r)}"
        )

    # EXPECTED: os.path.islink(primary) is (expected["primary_is_symlink"] == "yes")
    # and when it IS a symlink, os.path.realpath(primary) equals the real path of the source
    is_symlink_expected = expected["primary_is_symlink"] == "yes"
    assert os.path.islink(primary) == is_symlink_expected, (
        f"Expected islink({primary}) == {is_symlink_expected}, "
        f"got {os.path.islink(primary)}"
    )
    if is_symlink_expected:
        assert os.path.realpath(primary) == os.path.realpath(source_abs), (
            f"Symlink {primary} points to {os.path.realpath(primary)}, "
            f"expected {os.path.realpath(source_abs)}"
        )

    # EXPECTED: when expected["primary_is_dir"] != "__skip__", check isdir
    if expected["primary_is_dir"] != "__skip__":
        is_dir_expected = expected["primary_is_dir"] == "yes"
        assert os.path.isdir(primary) == is_dir_expected, (
            f"Expected isdir({primary}) == {is_dir_expected}, "
            f"got {os.path.isdir(primary)}"
        )

    # EXPECTED: when expected["primary_content"] != "__skip__", read file and compare
    if expected["primary_content"] != "__skip__":
        with open(primary, "r", encoding="utf-8") as f:
            content = f.read()
        assert content == expected["primary_content"], (
            f"Expected content {repr(expected['primary_content'])}, "
            f"got {repr(content)}"
        )

    # EXPECTED: when expected["perms"] != "__skip__", check octal permissions
    if expected["perms"] != "__skip__":
        mode_bits = os.stat(primary).st_mode & 0o777
        mode_octal = oct(mode_bits)
        expected_perms = expected["perms"]
        # Normalize: both sides to digits-only comparison
        assert mode_octal.lstrip("0o") == expected_perms.lstrip("0o"), (
            f"Expected permissions {expected_perms}, got {mode_octal} for {primary}"
        )

    # EXPECTED: when expected["extra_rel"] != "__skip__", check extra file content
    if expected["extra_rel"] != "__skip__":
        extra_path = home_path(env, expected["extra_rel"])
        with open(extra_path, "r", encoding="utf-8") as f:
            extra_content = f.read()
        assert extra_content == expected["extra_content"], (
            f"Expected extra content {repr(expected['extra_content'])}, "
            f"got {repr(extra_content)}"
        )
