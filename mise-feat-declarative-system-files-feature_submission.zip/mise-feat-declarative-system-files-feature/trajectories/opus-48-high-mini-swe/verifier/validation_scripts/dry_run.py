import sys
import os
sys.path.insert(0, "/tests/validate")
from test_harness import new_world, write, run, combined, home_path


def test_dry_run(inputs, expected):
    """Test that dry run previews without writing anything."""
    scenario = inputs["scenario"]
    workdir, env = new_world()

    if scenario == "no_write":
        write(workdir, "dotfiles/gitconfig", "gitconfig content\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.gitconfig" = "dotfiles/gitconfig"\n')
        target = home_path(env, ".gitconfig")
        marker = None

        # Run dry run
        dry_r = run(["system", "install", "--dry-run"], workdir, env)
        assert dry_r.returncode == 0, f"Dry run failed: {combined(dry_r)}"

        # EXPECTED: target does not exist after dry run
        target_after_dryrun_expected = expected["target_after_dryrun"] == "present"
        assert os.path.lexists(target) == target_after_dryrun_expected, (
            f"After dry run: expected target lexists == {target_after_dryrun_expected}, "
            f"got {os.path.lexists(target)}"
        )

        # side_effect is __skip__ for this scenario — no assertion needed but we must check the key
        if expected["side_effect"] != "__skip__":
            side_effect_expected = expected["side_effect"] == "present"
            assert os.path.exists(marker) == side_effect_expected, (
                f"After dry run: expected marker exists == {side_effect_expected}, "
                f"got {os.path.exists(marker) if marker else False}"
            )

        # Run real install
        if expected["target_after_real"] != "__skip__":
            real_r = run(["system", "install"], workdir, env)
            assert real_r.returncode == 0, f"Real install failed: {combined(real_r)}"
            target_after_real_expected = expected["target_after_real"] == "present"
            assert os.path.lexists(target) == target_after_real_expected, (
                f"After real install: expected target lexists == {target_after_real_expected}, "
                f"got {os.path.lexists(target)}"
            )

    elif scenario == "no_side_effects":
        # template that runs exec side effect
        write(workdir, "dotfiles/ex.tmpl",
              '{{ exec(command="touch ran-marker") }}\n')
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.local/exec-out" = { source = "dotfiles/ex.tmpl", mode = "template" }\n')
        target = home_path(env, ".local/exec-out")
        marker = os.path.join(workdir, "ran-marker")

        # Run dry run
        dry_r = run(["system", "install", "--dry-run"], workdir, env)
        assert dry_r.returncode == 0, f"Dry run failed: {combined(dry_r)}"

        # EXPECTED: target does not exist after dry run
        target_after_dryrun_expected = expected["target_after_dryrun"] == "present"
        assert os.path.lexists(target) == target_after_dryrun_expected, (
            f"After dry run: expected target lexists == {target_after_dryrun_expected}, "
            f"got {os.path.lexists(target)}"
        )

        # EXPECTED: side_effect marker does not exist after dry run
        if expected["side_effect"] != "__skip__":
            side_effect_expected = expected["side_effect"] == "present"
            assert os.path.exists(marker) == side_effect_expected, (
                f"After dry run: expected marker '{marker}' exists == {side_effect_expected}, "
                f"got {os.path.exists(marker)}"
            )

        # EXPECTED: after real install, target exists
        if expected["target_after_real"] != "__skip__":
            real_r = run(["system", "install"], workdir, env)
            assert real_r.returncode == 0, f"Real install failed: {combined(real_r)}"
            target_after_real_expected = expected["target_after_real"] == "present"
            assert os.path.lexists(target) == target_after_real_expected, (
                f"After real install: expected target lexists == {target_after_real_expected}, "
                f"got {os.path.lexists(target)}"
            )

    else:
        raise ValueError(f"Unknown scenario: {scenario}")
