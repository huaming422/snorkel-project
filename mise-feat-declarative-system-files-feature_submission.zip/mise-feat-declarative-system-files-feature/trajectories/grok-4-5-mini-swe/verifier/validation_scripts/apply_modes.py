import sys
import os

sys.path.insert(0, "/tests/validate")
from test_harness import new_world, write, run, combined, home_path


def test_apply_modes(inputs, expected):
    """Test each mode for system.files entries."""
    scenario = inputs["scenario"]
    workdir, env = new_world()

    install_results = []
    source_for_primary = None  # Will hold the source path used for the primary entry

    if scenario == "symlink_file":
        write(workdir, "dotfiles/gitconfig", "gitconfig content\n")
        source_for_primary = os.path.join(workdir, "dotfiles/gitconfig")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.gitconfig" = "dotfiles/gitconfig"\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)

    elif scenario == "copy_file":
        write(workdir, "dotfiles/starship.toml", "starship config\n")
        source_for_primary = os.path.join(workdir, "dotfiles/starship.toml")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.config/starship.toml" = { source = "dotfiles/starship.toml", mode = "copy" }\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)

    elif scenario == "template_file":
        write(workdir, "dotfiles/ssh.tmpl", "sum = {{ 1 + 1 }}\n", mode=0o600)
        source_for_primary = os.path.join(workdir, "dotfiles/ssh.tmpl")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.ssh/config" = { source = "dotfiles/ssh.tmpl", mode = "template" }\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)

    elif scenario == "symlink_each_dir":
        write(workdir, "dotfiles/bin/one", "one\n")
        write(workdir, "dotfiles/bin/two", "two\n")
        source_for_primary = os.path.join(workdir, "dotfiles/bin/one")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.local/mybin" = { source = "dotfiles/bin", mode = "symlink-each" }\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        # Create unmanaged file after first install
        unmanaged = home_path(env, ".local/mybin/unmanaged")
        os.makedirs(os.path.dirname(unmanaged), exist_ok=True)
        with open(unmanaged, "w") as f:
            f.write("free\n")
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)

    elif scenario == "symlink_dir":
        write(workdir, "dotfiles/nvim/init.lua", "init\n")
        source_for_primary = os.path.join(workdir, "dotfiles/nvim")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.config/nvim" = "dotfiles/nvim"\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)

    elif scenario == "copy_dir_additive":
        write(workdir, "dotfiles/bin/one", "one\n")
        source_for_primary = os.path.join(workdir, "dotfiles/bin/one")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.local/copydir" = { source = "dotfiles/bin", mode = "copy" }\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        # Write unmanaged file into target
        unmanaged = home_path(env, ".local/copydir/unmanaged")
        os.makedirs(os.path.dirname(unmanaged), exist_ok=True)
        with open(unmanaged, "w") as f:
            f.write("keep me\n")
        # Change source
        write(workdir, "dotfiles/bin/one", "one v2\n")
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)

    elif scenario == "empty_source_dir":
        source_dir = os.path.join(workdir, "dotfiles/emptydir")
        os.makedirs(source_dir, exist_ok=True)
        source_for_primary = source_dir
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.local/emptydir" = { source = "dotfiles/emptydir", mode = "copy" }\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)

    elif scenario == "template_perms_repair":
        write(workdir, "dotfiles/ssh.tmpl", "sum = {{ 1 + 1 }}\n", mode=0o644)
        source_for_primary = os.path.join(workdir, "dotfiles/ssh.tmpl")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.ssh/config" = { source = "dotfiles/ssh.tmpl", mode = "template" }\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        # Change source permissions to 0o600
        os.chmod(source_for_primary, 0o600)
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)

    elif scenario == "dangling_copy_repair":
        write(workdir, "dotfiles/starship.toml", "starship config\n")
        source_for_primary = os.path.join(workdir, "dotfiles/starship.toml")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.config/starship.toml" = { source = "dotfiles/starship.toml", mode = "copy" }\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        # Delete target and replace with dangling symlink
        target = home_path(env, ".config/starship.toml")
        os.remove(target)
        os.symlink("/nonexistent-source-xyz", target)
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)

    else:
        raise ValueError(f"Unknown scenario: {scenario}")

    # Resolve the primary target
    primary = home_path(env, expected["primary_rel"])

    # Assert every install run returned exit code 0
    for i, r in enumerate(install_results):
        assert r.returncode == 0, (
            f"Install run {i+1} failed (rc={r.returncode}) for scenario '{scenario}':\n{combined(r)}"
        )

    # Assert symlink status
    is_symlink = os.path.islink(primary)
    expect_symlink = (expected["primary_is_symlink"] == "yes")
    assert is_symlink == expect_symlink, (
        f"scenario '{scenario}': expected islink={expect_symlink}, got {is_symlink} for {primary}"
    )

    # When it IS a symlink, check the realpath matches the source
    if is_symlink:
        real_primary = os.path.realpath(primary)
        real_source = os.path.realpath(source_for_primary)
        assert real_primary == real_source, (
            f"scenario '{scenario}': symlink realpath mismatch: "
            f"got {real_primary}, expected {real_source}"
        )

    # Assert directory status if not __skip__
    if expected["primary_is_dir"] != "__skip__":
        is_dir = os.path.isdir(primary)
        expect_dir = (expected["primary_is_dir"] == "yes")
        assert is_dir == expect_dir, (
            f"scenario '{scenario}': expected isdir={expect_dir}, got {is_dir} for {primary}"
        )

    # Assert content if not __skip__
    if expected["primary_content"] != "__skip__":
        with open(primary, "r", encoding="utf-8") as f:
            content = f.read()
        assert content == expected["primary_content"], (
            f"scenario '{scenario}': content mismatch: "
            f"got {repr(content)}, expected {repr(expected['primary_content'])}"
        )

    # Assert permissions if not __skip__
    if expected["perms"] != "__skip__":
        actual_perms = os.stat(primary).st_mode & 0o777
        actual_perms_oct = oct(actual_perms)[2:]  # e.g. "600"
        assert actual_perms_oct == expected["perms"], (
            f"scenario '{scenario}': perms mismatch: "
            f"got {actual_perms_oct}, expected {expected['perms']}"
        )

    # Assert extra file if not __skip__
    if expected["extra_rel"] != "__skip__":
        extra_path = home_path(env, expected["extra_rel"])
        with open(extra_path, "r", encoding="utf-8") as f:
            extra_content = f.read()
        assert extra_content == expected["extra_content"], (
            f"scenario '{scenario}': extra content mismatch: "
            f"got {repr(extra_content)}, expected {repr(expected['extra_content'])}"
        )
