import sys
import json
import os

sys.path.insert(0, "/tests/validate")
from test_harness import new_world, write, run, combined, home_path


def test_status_reporting(inputs, expected):
    """Test status reporting for system.files entries."""
    scenario = inputs["scenario"]
    workdir, env = new_world()

    if scenario == "applied":
        write(workdir, "dotfiles/gitconfig", "gitconfig content\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.gitconfig" = "dotfiles/gitconfig"\n')
        install_r = run(["system", "install"], workdir, env)
        assert install_r.returncode == 0, f"install failed: {combined(install_r)}"

    elif scenario == "missing":
        write(workdir, "dotfiles/gitconfig", "gitconfig content\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.gitconfig" = "dotfiles/gitconfig"\n')
        # Do NOT install

    elif scenario == "differs":
        write(workdir, "dotfiles/starship.toml", "starship config\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.config/starship.toml" = { source = "dotfiles/starship.toml", mode = "copy" }\n')
        install_r = run(["system", "install"], workdir, env)
        assert install_r.returncode == 0, f"install failed: {combined(install_r)}"
        # Change source to make it differ
        write(workdir, "dotfiles/starship.toml", "changed content\n")

    elif scenario == "source_missing":
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.missing-target" = "dotfiles/does-not-exist"\n')
        # Do NOT install, source doesn't exist

    else:
        raise ValueError(f"Unknown scenario: {scenario}")

    # Run plain status (should always exit 0)
    status = run(["system", "status"], workdir, env)
    human = combined(status)

    # Run with drift-check flag (--missing)
    check_run = run(["system", "status", "--missing"], workdir, env)

    # Run with JSON flag (--json / -J)
    json_run = run(["system", "status", "--json"], workdir, env)
    blob = json_run.stdout or ""

    # EXPECTED: status_word is a substring of human
    assert expected["status_word"] in human, (
        f"scenario '{scenario}': '{expected['status_word']}' not found in status output:\n{human}"
    )

    # EXPECTED: (check_run.returncode != 0) is (expected["check_exit"] == "nonzero")
    expect_nonzero = (expected["check_exit"] == "nonzero")
    got_nonzero = (check_run.returncode != 0)
    assert got_nonzero == expect_nonzero, (
        f"scenario '{scenario}': check_exit mismatch: "
        f"expected nonzero={expect_nonzero}, got returncode={check_run.returncode}"
    )

    # EXPECTED: the JSON run's stdout parses as JSON
    try:
        json.loads(blob)
    except (json.JSONDecodeError, ValueError) as e:
        assert False, (
            f"scenario '{scenario}': JSON run stdout did not parse as JSON: {e}\n"
            f"stdout: {blob}\nstderr: {json_run.stderr}"
        )

    # EXPECTED: when json_word != "__skip__", it appears in blob
    if expected["json_word"] != "__skip__":
        assert expected["json_word"] in blob, (
            f"scenario '{scenario}': '{expected['json_word']}' not found in JSON output:\n{blob}"
        )
