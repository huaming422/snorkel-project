import sys
import os

sys.path.insert(0, "/tests/validate")
from test_harness import new_world, write, run, combined, home_path


def test_lenient_skips(inputs, expected):
    """Test lenient handling of unknown modes, relative targets, and missing sources."""
    scenario = inputs["scenario"]
    workdir, env = new_world()

    good_target = home_path(env, ".good")
    bad_target = None

    if scenario == "unknown_mode":
        # Good entry + bad entry with unknown mode "hardlink"
        write(workdir, "dotfiles/good", "good\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.good" = "dotfiles/good"\n'
              '"~/.unknownmode" = { source = "dotfiles/good", mode = "hardlink" }\n')
        bad_target = home_path(env, ".unknownmode")

    elif scenario == "relative_target":
        # Good entry + bad entry with relative target path
        write(workdir, "dotfiles/good", "good\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.good" = "dotfiles/good"\n'
              '"relative/path" = "dotfiles/good"\n')
        bad_target = os.path.join(workdir, "relative/path")

    elif scenario == "missing_source":
        # Good entry + bad entry with missing source
        write(workdir, "dotfiles/good", "good\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.good" = "dotfiles/good"\n'
              '"~/.missing" = "dotfiles/does-not-exist"\n')
        bad_target = home_path(env, ".missing")

    elif scenario == "report_all":
        # NO good entry; TWO bad entries
        write(workdir, "dotfiles/bad.tmpl", "{{ not_a_real_function() }}\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.missing" = "dotfiles/none"\n'
              '"~/.broken" = { source = "dotfiles/bad.tmpl", mode = "template" }\n')
        bad_target = None  # no single bad target, check both

    else:
        raise ValueError(f"Unknown scenario: {scenario}")

    # Run status (should always exit 0)
    status = run(["system", "status"], workdir, env)

    # Run install
    install = run(["system", "install"], workdir, env)
    out = combined(install)

    # EXPECTED: status always exits 0
    assert status.returncode == 0, (
        f"scenario '{scenario}': status should exit 0, got {status.returncode}:\n{combined(status)}"
    )

    # EXPECTED: (install.returncode != 0) is (expected["install_exit"] == "nonzero")
    expect_nonzero = (expected["install_exit"] == "nonzero")
    got_nonzero = (install.returncode != 0)
    assert got_nonzero == expect_nonzero, (
        f"scenario '{scenario}': install_exit mismatch: "
        f"expected nonzero={expect_nonzero}, got returncode={install.returncode}\n"
        f"Output: {out}"
    )

    # EXPECTED: bad_target presence check
    if expected["bad_target"] != "__skip__":
        bad_exists = os.path.lexists(bad_target)
        expect_present = (expected["bad_target"] == "present")
        assert bad_exists == expect_present, (
            f"scenario '{scenario}': bad_target existence mismatch: "
            f"expected present={expect_present}, got lexists={bad_exists} for {bad_target}"
        )

    # EXPECTED: good_target presence check
    if expected["good_target"] != "__skip__":
        good_exists = os.path.lexists(good_target)
        expect_present = (expected["good_target"] == "present")
        assert good_exists == expect_present, (
            f"scenario '{scenario}': good_target existence mismatch: "
            f"expected present={expect_present}, got lexists={good_exists} for {good_target}"
        )

    # EXPECTED: status_shows check
    if expected["status_shows"] != "__skip__":
        status_out = combined(status)
        assert expected["status_shows"] in status_out, (
            f"scenario '{scenario}': '{expected['status_shows']}' not found in status output:\n{status_out}"
        )

    # EXPECTED: report_all check
    if expected["report_all"] != "__skip__":
        # Both offending target identifiers must appear in install output
        assert "~/.missing" in out, (
            f"scenario '{scenario}': '~/.missing' not found in install output:\n{out}"
        )
        assert "~/.broken" in out, (
            f"scenario '{scenario}': '~/.broken' not found in install output:\n{out}"
        )
