import sys
import os

sys.path.insert(0, "/tests/validate")
from test_harness import new_world, write, run, combined, home_path


def test_dry_run(inputs, expected):
    """Test that dry run changes nothing on disk."""
    scenario = inputs["scenario"]
    workdir, env = new_world()

    if scenario == "no_write":
        write(workdir, "dotfiles/gitconfig", "gitconfig content\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.gitconfig" = "dotfiles/gitconfig"\n')
        target = home_path(env, ".gitconfig")
        marker = None  # not used

        # Run dry-run
        dry_run = run(["system", "install", "--dry-run"], workdir, env)
        # dry-run should exit 0 (preview succeeds)
        assert dry_run.returncode == 0, (
            f"scenario '{scenario}': dry-run failed:\n{combined(dry_run)}"
        )

    elif scenario == "no_side_effects":
        write(workdir, "dotfiles/ex.tmpl", '{{ exec(command="touch ran-marker") }}\n')
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.local/exec-out" = { source = "dotfiles/ex.tmpl", mode = "template" }\n')
        target = home_path(env, ".local/exec-out")
        marker = os.path.join(workdir, "ran-marker")

        # Run dry-run
        dry_run = run(["system", "install", "--dry-run"], workdir, env)
        # dry-run should exit 0
        assert dry_run.returncode == 0, (
            f"scenario '{scenario}': dry-run failed:\n{combined(dry_run)}"
        )

    else:
        raise ValueError(f"Unknown scenario: {scenario}")

    # EXPECTED: target_after_dryrun check (before any real install)
    target_exists_after_dryrun = os.path.lexists(target)
    expect_present = (expected["target_after_dryrun"] == "present")
    assert target_exists_after_dryrun == expect_present, (
        f"scenario '{scenario}': after dry-run, target existence mismatch: "
        f"expected present={expect_present}, got lexists={target_exists_after_dryrun}"
    )

    # EXPECTED: side_effect check (before any real install)
    if expected["side_effect"] != "__skip__":
        marker_exists = os.path.exists(marker)
        expect_marker_present = (expected["side_effect"] == "present")
        assert marker_exists == expect_marker_present, (
            f"scenario '{scenario}': after dry-run, marker existence mismatch: "
            f"expected present={expect_marker_present}, got exists={marker_exists}"
        )

    # EXPECTED: target_after_real check (after real install)
    if expected["target_after_real"] != "__skip__":
        real_run = run(["system", "install"], workdir, env)
        assert real_run.returncode == 0, (
            f"scenario '{scenario}': real install failed:\n{combined(real_run)}"
        )
        target_exists_after_real = os.path.lexists(target)
        expect_real_present = (expected["target_after_real"] == "present")
        assert target_exists_after_real == expect_real_present, (
            f"scenario '{scenario}': after real install, target existence mismatch: "
            f"expected present={expect_real_present}, got lexists={target_exists_after_real}"
        )
