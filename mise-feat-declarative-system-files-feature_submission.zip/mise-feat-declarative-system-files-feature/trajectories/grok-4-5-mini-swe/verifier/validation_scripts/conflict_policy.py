import sys
import os

sys.path.insert(0, "/tests/validate")
from test_harness import new_world, write, run, combined, home_path


def test_conflict_policy(inputs, expected):
    """Test conflict policy for system.files entries."""
    scenario = inputs["scenario"]
    workdir, env = new_world()

    if scenario == "file_blocks_symlink":
        write(workdir, "dotfiles/gitconfig", "gitconfig content\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.gitconfig" = "dotfiles/gitconfig"\n')
        # Create a real file at the target location BEFORE installing
        target = home_path(env, ".gitconfig")
        os.makedirs(os.path.dirname(target), exist_ok=True)
        with open(target, "w") as f:
            f.write("precious\n")

        # First install: should fail
        first_install = run(["system", "install"], workdir, env)

        # blocker_survives check
        if expected["blocker_survives"] != "__skip__":
            with open(target, "r") as f:
                content = f.read()
            assert content == expected["blocker_survives"], (
                f"scenario '{scenario}': blocker not preserved: "
                f"got {repr(content)}, expected {repr(expected['blocker_survives'])}"
            )

        # Override install: should succeed and the target should be a symlink
        override_install = run(["system", "install", "--force"], workdir, env)
        assert override_install.returncode == 0, (
            f"scenario '{scenario}': override install failed:\n{combined(override_install)}"
        )

        # Read resolved content
        with open(target, "r") as f:
            resolved_content = f.read()

    elif scenario == "file_blocks_dir":
        write(workdir, "dotfiles/bin/one", "one\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.local/mybin" = { source = "dotfiles/bin", mode = "symlink-each" }\n')
        # Create a real file at the target location
        target_dir = home_path(env, ".local/mybin")
        os.makedirs(os.path.dirname(target_dir), exist_ok=True)
        with open(target_dir, "w") as f:
            f.write("blocker\n")

        # First install: should fail
        first_install = run(["system", "install"], workdir, env)

        # blocker_survives check
        if expected["blocker_survives"] != "__skip__":
            with open(target_dir, "r") as f:
                content = f.read()
            assert content == expected["blocker_survives"], (
                f"scenario '{scenario}': blocker not preserved: "
                f"got {repr(content)}, expected {repr(expected['blocker_survives'])}"
            )

        # Override install: should succeed
        override_install = run(["system", "install", "--force"], workdir, env)
        assert override_install.returncode == 0, (
            f"scenario '{scenario}': override install failed:\n{combined(override_install)}"
        )

        # Read resolved content from .local/mybin/one
        resolved_target = home_path(env, ".local/mybin/one")
        with open(resolved_target, "r") as f:
            resolved_content = f.read()

    elif scenario == "copy_update_not_conflict":
        write(workdir, "dotfiles/starship.toml", "starship config\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.config/starship.toml" = { source = "dotfiles/starship.toml", mode = "copy" }\n')

        # First install (exit 0)
        first_install = run(["system", "install"], workdir, env)

        # Change source
        write(workdir, "dotfiles/starship.toml", "starship v2\n")

        # Second install WITHOUT override flag — should be a content update, not conflict
        second_install = run(["system", "install"], workdir, env)
        assert second_install.returncode == 0, (
            f"scenario '{scenario}': second install (content update) failed:\n{combined(second_install)}"
        )

        # Read resolved content
        target = home_path(env, ".config/starship.toml")
        with open(target, "r") as f:
            resolved_content = f.read()

    else:
        raise ValueError(f"Unknown scenario: {scenario}")

    # EXPECTED: (first_install.returncode != 0) is (expected["first_exit"] == "nonzero")
    expect_nonzero = (expected["first_exit"] == "nonzero")
    got_nonzero = (first_install.returncode != 0)
    assert got_nonzero == expect_nonzero, (
        f"scenario '{scenario}': first_exit mismatch: "
        f"expected nonzero={expect_nonzero}, got returncode={first_install.returncode}\n"
        f"Output: {combined(first_install)}"
    )

    # EXPECTED: resolved_content matches expected["resolved_content"]
    assert resolved_content == expected["resolved_content"], (
        f"scenario '{scenario}': resolved content mismatch: "
        f"got {repr(resolved_content)}, expected {repr(expected['resolved_content'])}"
    )
