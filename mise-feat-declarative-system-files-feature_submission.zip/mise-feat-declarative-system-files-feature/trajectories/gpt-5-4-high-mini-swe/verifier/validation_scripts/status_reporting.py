import sys
import os
import json

sys.path.insert(0, "/tests/validate")
from test_harness import new_world, write, run, combined, home_path


def test_status_reporting(inputs, expected):
    scenario = inputs["scenario"]
    workdir, env = new_world()

    if scenario == "applied":
        write(workdir, "dotfiles/gitconfig", "gitconfig content\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.gitconfig" = "dotfiles/gitconfig"\n')
        # Install first so it is in desired state
        inst = run(["system", "install"], workdir, env)
        assert inst.returncode == 0, f"install failed: {combined(inst)}"

    elif scenario == "missing":
        write(workdir, "dotfiles/gitconfig", "gitconfig content\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.gitconfig" = "dotfiles/gitconfig"\n')
        # Do NOT install — target absent

    elif scenario == "differs":
        write(workdir, "dotfiles/starship.toml", "starship config\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.config/starship.toml" = { source = "dotfiles/starship.toml", mode = "copy" }\n')
        # 1. Install so the target is materialized from the original source.
        inst = run(["system", "install"], workdir, env)
        assert inst.returncode == 0, f"install failed: {combined(inst)}"
        # 2. Mutate the source AFTER install so that the on-disk target no longer
        #    matches the source — this is the intentional drift that produces the
        #    "differs" state. status must be run AFTER this mutation so it observes
        #    the divergence between the installed target and the updated source.
        write(workdir, "dotfiles/starship.toml", "starship v2\n")
        # 3. status is run below (after this elif block) — ordering is correct.

    elif scenario == "source_missing":
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.gitconfig" = "dotfiles/does-not-exist"\n')
        # Do not install; source doesn't exist

    else:
        raise ValueError(f"Unknown scenario: {scenario}")

    # Run plain status (always exits 0).
    # For the "differs" scenario, this run happens AFTER the source mutation above,
    # so status sees the drift between the installed target and the changed source.
    status = run(["system", "status"], workdir, env)
    human = combined(status)

    # Run with drift-check flag (--missing exits non-zero when anything out of sync)
    check_run = run(["system", "status", "--missing"], workdir, env)

    # Run with JSON flag
    json_run = run(["system", "status", "--json"], workdir, env)
    blob = json_run.stdout or ""

    # EXPECTED: expected["status_word"] is a substring of human
    assert expected["status_word"] in human, (
        f"status_word {expected['status_word']!r} not in human output: {human!r}"
    )

    # EXPECTED: (check_run.returncode != 0) is (expected["check_exit"] == "nonzero")
    expected_nonzero = (expected["check_exit"] == "nonzero")
    assert (check_run.returncode != 0) == expected_nonzero, (
        f"check_run.returncode = {check_run.returncode}, "
        f"expected {'nonzero' if expected_nonzero else 'zero'}"
    )

    # EXPECTED: the JSON run's stdout parses as JSON
    try:
        json.loads(blob)
    except Exception as e:
        raise AssertionError(f"JSON run stdout did not parse as JSON: {blob!r}, error: {e}")

    # EXPECTED: when json_word != "__skip__", expected["json_word"] is a substring of blob
    if expected["json_word"] != "__skip__":
        assert expected["json_word"] in blob, (
            f"json_word {expected['json_word']!r} not in JSON output: {blob!r}"
        )
