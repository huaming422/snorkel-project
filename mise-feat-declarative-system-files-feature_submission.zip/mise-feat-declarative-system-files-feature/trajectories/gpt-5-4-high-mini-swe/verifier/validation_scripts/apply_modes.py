import sys
import os

sys.path.insert(0, "/tests/validate")
from test_harness import new_world, write, run, combined, home_path


def test_apply_modes(inputs, expected):
    scenario = inputs["scenario"]
    workdir, env = new_world()

    install_results = []

    if scenario == "symlink_file":
        write(workdir, "dotfiles/gitconfig", "gitconfig content\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.gitconfig" = "dotfiles/gitconfig"\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)
        # primary is ~/.gitconfig -> dotfiles/gitconfig
        # src_abs is ONLY used in the `if expected_is_symlink:` branch below.
        src_abs = os.path.join(workdir, "dotfiles/gitconfig")

    elif scenario == "copy_file":
        write(workdir, "dotfiles/starship.toml", "starship config\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.config/starship.toml" = { source = "dotfiles/starship.toml", mode = "copy" }\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)
        # copy mode is not a symlink; src_abs only used in symlink branch, harmless here.
        src_abs = os.path.join(workdir, "dotfiles/starship.toml")

    elif scenario == "template_file":
        write(workdir, "dotfiles/ssh.tmpl", "sum = {{ 1 + 1 }}\n", mode=0o600)
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.ssh/config" = { source = "dotfiles/ssh.tmpl", mode = "template" }\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)
        # template mode is not a symlink; src_abs only used in symlink branch, harmless here.
        src_abs = os.path.join(workdir, "dotfiles/ssh.tmpl")

    elif scenario == "symlink_each_dir":
        os.makedirs(os.path.join(workdir, "dotfiles/bin"), exist_ok=True)
        write(workdir, "dotfiles/bin/one", "one\n")
        write(workdir, "dotfiles/bin/two", "two\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.local/mybin" = { source = "dotfiles/bin", mode = "symlink-each" }\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        # After first install, create an unmanaged file
        unmanaged = home_path(env, ".local/mybin/unmanaged")
        os.makedirs(os.path.dirname(unmanaged), exist_ok=True)
        with open(unmanaged, "w") as f:
            f.write("free\n")
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)
        # primary_rel is ".local/mybin/one" which is a symlink to dotfiles/bin/one
        src_abs = os.path.join(workdir, "dotfiles/bin/one")

    elif scenario == "symlink_dir":
        os.makedirs(os.path.join(workdir, "dotfiles/nvim"), exist_ok=True)
        write(workdir, "dotfiles/nvim/init.lua", "init\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.config/nvim" = "dotfiles/nvim"\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)
        # primary is ~/.config/nvim -> dotfiles/nvim (the directory)
        src_abs = os.path.join(workdir, "dotfiles/nvim")

    elif scenario == "copy_dir_additive":
        os.makedirs(os.path.join(workdir, "dotfiles/bin"), exist_ok=True)
        write(workdir, "dotfiles/bin/one", "one\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.local/copydir" = { source = "dotfiles/bin", mode = "copy" }\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        # After first install, write an unmanaged file
        unmanaged = home_path(env, ".local/copydir/unmanaged")
        os.makedirs(os.path.dirname(unmanaged), exist_ok=True)
        with open(unmanaged, "w") as f:
            f.write("keep me\n")
        # Change the source
        write(workdir, "dotfiles/bin/one", "one v2\n")
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)
        # copy mode is not a symlink; src_abs only used in symlink branch, harmless here.
        src_abs = os.path.join(workdir, "dotfiles/bin/one")

    elif scenario == "empty_source_dir":
        os.makedirs(os.path.join(workdir, "dotfiles/emptydir"), exist_ok=True)
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.local/emptydir" = { source = "dotfiles/emptydir", mode = "copy" }\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)
        # primary is the target directory itself; not a symlink (copy mode)
        # src_abs only used in symlink branch, harmless here.
        src_abs = os.path.join(workdir, "dotfiles/emptydir")

    elif scenario == "template_perms_repair":
        write(workdir, "dotfiles/ssh.tmpl", "sum = {{ 1 + 1 }}\n", mode=0o644)
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.ssh/config" = { source = "dotfiles/ssh.tmpl", mode = "template" }\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        # Change source permissions to 0o600; nothing else changes
        src_path = os.path.join(workdir, "dotfiles/ssh.tmpl")
        os.chmod(src_path, 0o600)
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)
        # template mode produces a plain file (primary_is_symlink == "no"),
        # so src_abs is only ever referenced inside the `if expected_is_symlink:`
        # branch below — which will NOT fire for this scenario. Setting src_abs
        # here is harmless and only present for structural consistency.
        src_abs = src_path

    elif scenario == "dangling_copy_repair":
        write(workdir, "dotfiles/starship.toml", "starship config\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.config/starship.toml" = { source = "dotfiles/starship.toml", mode = "copy" }\n')
        r1 = run(["system", "install"], workdir, env)
        install_results.append(r1)
        # Delete the target and replace with a dangling symlink
        target = home_path(env, ".config/starship.toml")
        os.remove(target)
        os.symlink("/nonexistent-source-xyz", target)
        r2 = run(["system", "install"], workdir, env)
        install_results.append(r2)
        # copy mode is not a symlink; src_abs only used in symlink branch, harmless here.
        src_abs = os.path.join(workdir, "dotfiles/starship.toml")

    else:
        raise ValueError(f"Unknown scenario: {scenario}")

    # Assert: every install run must exit 0
    for i, r in enumerate(install_results):
        assert r.returncode == 0, f"install run {i+1} failed: {combined(r)}"

    # Resolve the primary target
    primary = home_path(env, expected["primary_rel"])

    # EXPECTED: os.path.islink(primary) is (expected["primary_is_symlink"] == "yes")
    expected_is_symlink = (expected["primary_is_symlink"] == "yes")
    assert os.path.islink(primary) == expected_is_symlink, (
        f"islink({primary}) = {os.path.islink(primary)}, expected {expected_is_symlink}"
    )
    # When it IS a symlink, realpath must equal the real path of the source.
    # src_abs is ONLY used here; template/copy scenarios never enter this branch.
    if expected_is_symlink:
        assert os.path.realpath(primary) == os.path.realpath(src_abs), (
            f"realpath({primary}) = {os.path.realpath(primary)}, "
            f"expected {os.path.realpath(src_abs)}"
        )

    # EXPECTED: when primary_is_dir != "__skip__", os.path.isdir(primary) == (expected == "yes")
    if expected["primary_is_dir"] != "__skip__":
        expected_is_dir = (expected["primary_is_dir"] == "yes")
        assert os.path.isdir(primary) == expected_is_dir, (
            f"isdir({primary}) = {os.path.isdir(primary)}, expected {expected_is_dir}"
        )

    # EXPECTED: when primary_content != "__skip__", reading primary yields expected content
    if expected["primary_content"] != "__skip__":
        with open(primary, "r") as f:
            content = f.read()
        assert content == expected["primary_content"], (
            f"content of {primary} = {content!r}, expected {expected['primary_content']!r}"
        )

    # EXPECTED: when perms != "__skip__", (os.stat(primary).st_mode & 0o777) formatted as
    # octal equals expected["perms"]. Use oct(...)[2:] to strip the '0o' prefix so the
    # result is e.g. "600", matching expected values like "600" (not "0o600").
    if expected["perms"] != "__skip__":
        mode_bits = os.stat(primary).st_mode & 0o777
        mode_octal = oct(mode_bits)[2:]  # strips '0o' prefix: 0o600 -> "600"
        assert mode_octal == expected["perms"], (
            f"mode of {primary} = {mode_octal}, expected {expected['perms']}"
        )

    # EXPECTED: when extra_rel != "__skip__", reading that path yields extra_content
    if expected["extra_rel"] != "__skip__":
        extra_path = home_path(env, expected["extra_rel"])
        with open(extra_path, "r") as f:
            extra_content = f.read()
        assert extra_content == expected["extra_content"], (
            f"extra_content of {extra_path} = {extra_content!r}, "
            f"expected {expected['extra_content']!r}"
        )
