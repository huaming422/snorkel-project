import sys
import os

sys.path.insert(0, "/tests/validate")
from test_harness import new_world, write, run, combined, home_path


def test_conflict_policy(inputs, expected):
    scenario = inputs["scenario"]
    workdir, env = new_world()

    if scenario == "file_blocks_symlink":
        write(workdir, "dotfiles/gitconfig", "gitconfig content\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.gitconfig" = "dotfiles/gitconfig"\n')
        # Create a real file at the target before installing
        target = home_path(env, ".gitconfig")
        os.makedirs(os.path.dirname(target), exist_ok=True)
        with open(target, "w") as f:
            f.write("precious\n")

        # First install must fail
        first_install = run(["system", "install"], workdir, env)

        # Blocker check: target still reads "precious\n"
        if expected["blocker_survives"] != "__skip__":
            with open(target, "r") as f:
                blocker_content = f.read()
        else:
            blocker_content = None

        # Override install
        override_install = run(["system", "install", "--force"], workdir, env)
        assert override_install.returncode == 0, (
            f"override install failed: {combined(override_install)}"
        )

        # Read resolved content (target is now a symlink — read following links)
        with open(target, "r") as f:
            resolved_content = f.read()

    elif scenario == "file_blocks_dir":
        os.makedirs(os.path.join(workdir, "dotfiles/bin"), exist_ok=True)
        write(workdir, "dotfiles/bin/one", "one\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.local/mybin" = { source = "dotfiles/bin", mode = "symlink-each" }\n')
        # Create a REAL file at the target before installing (blocks the directory)
        target_dir = home_path(env, ".local/mybin")
        os.makedirs(os.path.dirname(target_dir), exist_ok=True)
        with open(target_dir, "w") as f:
            f.write("blocker\n")

        # First install must fail
        first_install = run(["system", "install"], workdir, env)

        # Blocker check: target still reads "blocker\n"
        if expected["blocker_survives"] != "__skip__":
            with open(target_dir, "r") as f:
                blocker_content = f.read()
        else:
            blocker_content = None

        # Override install
        override_install = run(["system", "install", "--force"], workdir, env)
        assert override_install.returncode == 0, (
            f"override install failed: {combined(override_install)}"
        )

        # Resolved content: reading ~/.local/mybin/one
        resolved_target = home_path(env, ".local/mybin/one")
        with open(resolved_target, "r") as f:
            resolved_content = f.read()

    elif scenario == "copy_update_not_conflict":
        write(workdir, "dotfiles/starship.toml", "starship config\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.config/starship.toml" = { source = "dotfiles/starship.toml", mode = "copy" }\n')

        # First install (exit 0)
        first_install = run(["system", "install"], workdir, env)
        blocker_content = None  # no blocker in this scenario

        # Change source
        write(workdir, "dotfiles/starship.toml", "starship v2\n")

        # Second install with NO override flag — must exit 0 (content update, not conflict)
        second_install = run(["system", "install"], workdir, env)
        assert second_install.returncode == 0, (
            f"second install (copy update) failed: {combined(second_install)}"
        )

        # Resolved content after second install
        target = home_path(env, ".config/starship.toml")
        with open(target, "r") as f:
            resolved_content = f.read()

    else:
        raise ValueError(f"Unknown scenario: {scenario}")

    # EXPECTED: (first_install.returncode != 0) is (expected["first_exit"] == "nonzero")
    expected_first_nonzero = (expected["first_exit"] == "nonzero")
    assert (first_install.returncode != 0) == expected_first_nonzero, (
        f"first_install.returncode = {first_install.returncode}, "
        f"expected {'nonzero' if expected_first_nonzero else 'zero'}. "
        f"Output: {combined(first_install)}"
    )

    # EXPECTED: when blocker_survives != "__skip__", pre-existing target still reads that value
    if expected["blocker_survives"] != "__skip__":
        assert blocker_content == expected["blocker_survives"], (
            f"blocker_content = {blocker_content!r}, expected {expected['blocker_survives']!r}"
        )

    # EXPECTED: resolved_content reads expected["resolved_content"]
    assert resolved_content == expected["resolved_content"], (
        f"resolved_content = {resolved_content!r}, expected {expected['resolved_content']!r}"
    )
