import sys
import os

sys.path.insert(0, "/tests/validate")
from test_harness import new_world, write, run, combined, home_path


def test_lenient_skips(inputs, expected):
    scenario = inputs["scenario"]
    workdir, env = new_world()

    if scenario == "unknown_mode":
        # One valid entry + one bad entry (unknown mode)
        write(workdir, "dotfiles/good", "good\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.good" = "dotfiles/good"\n'
              '"~/.unknownmode" = { source = "dotfiles/good", mode = "hardlink" }\n')
        bad_target = home_path(env, ".unknownmode")
        good_target = home_path(env, ".good")

    elif scenario == "relative_target":
        # One valid entry + one bad entry (relative target key)
        write(workdir, "dotfiles/good", "good\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.good" = "dotfiles/good"\n'
              '"relative/path" = "dotfiles/good"\n')
        bad_target = os.path.join(workdir, "relative/path")
        good_target = home_path(env, ".good")

    elif scenario == "missing_source":
        # One valid entry + one bad entry (missing source)
        write(workdir, "dotfiles/good", "good\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.good" = "dotfiles/good"\n'
              '"~/.missing" = "dotfiles/does-not-exist"\n')
        bad_target = home_path(env, ".missing")
        good_target = home_path(env, ".good")

    elif scenario == "report_all":
        # NO good entry; TWO bad entries
        write(workdir, "dotfiles/bad.tmpl", "{{ not_a_real_function() }}\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.missing" = "dotfiles/none"\n'
              '"~/.broken" = { source = "dotfiles/bad.tmpl", mode = "template" }\n')
        bad_target = None  # not used directly; report_all checks both
        good_target = None  # no good entry

    else:
        raise ValueError(f"Unknown scenario: {scenario}")

    # Run status (expect exit 0 always)
    status = run(["system", "status"], workdir, env)

    # Run install
    install = run(["system", "install"], workdir, env)
    out = combined(install)

    # EXPECTED: status always exits 0
    assert status.returncode == 0, (
        f"status should exit 0 but got {status.returncode}: {combined(status)}"
    )

    # EXPECTED: (install.returncode != 0) is (expected["install_exit"] == "nonzero")
    expected_nonzero = (expected["install_exit"] == "nonzero")
    assert (install.returncode != 0) == expected_nonzero, (
        f"install.returncode = {install.returncode}, "
        f"expected {'nonzero' if expected_nonzero else 'zero'}. Output: {out}"
    )

    # EXPECTED: when bad_target != "__skip__", os.path.lexists(bad_target) == (expected == "present")
    if expected["bad_target"] != "__skip__":
        expected_bad_present = (expected["bad_target"] == "present")
        assert os.path.lexists(bad_target) == expected_bad_present, (
            f"bad_target {bad_target} exists = {os.path.lexists(bad_target)}, "
            f"expected {expected['bad_target']}"
        )

    # EXPECTED: when good_target != "__skip__", os.path.lexists(good_target) == (expected == "present")
    if expected["good_target"] != "__skip__":
        expected_good_present = (expected["good_target"] == "present")
        assert os.path.lexists(good_target) == expected_good_present, (
            f"good_target {good_target} exists = {os.path.lexists(good_target)}, "
            f"expected {expected['good_target']}"
        )

    # EXPECTED: when status_shows != "__skip__", it's a substring of combined(status)
    if expected["status_shows"] != "__skip__":
        status_out = combined(status)
        assert expected["status_shows"] in status_out, (
            f"status_shows {expected['status_shows']!r} not in status output: {status_out!r}"
        )

    # EXPECTED: when report_all != "__skip__", both "~/.missing" and "~/.broken" appear in out
    if expected["report_all"] != "__skip__":
        assert "~/.missing" in out, (
            f"'~/.missing' not found in install output: {out!r}"
        )
        assert "~/.broken" in out, (
            f"'~/.broken' not found in install output: {out!r}"
        )
