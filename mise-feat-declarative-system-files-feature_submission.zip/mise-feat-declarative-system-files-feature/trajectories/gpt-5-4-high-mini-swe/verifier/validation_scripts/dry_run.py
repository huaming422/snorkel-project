import sys
import os

sys.path.insert(0, "/tests/validate")
from test_harness import new_world, write, run, combined, home_path


def test_dry_run(inputs, expected):
    scenario = inputs["scenario"]
    workdir, env = new_world()

    if scenario == "no_write":
        write(workdir, "dotfiles/gitconfig", "gitconfig content\n")
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.gitconfig" = "dotfiles/gitconfig"\n')
        target = home_path(env, ".gitconfig")
        marker = None

        # Run dry run
        dry_run_result = run(["system", "install", "--dry-run"], workdir, env)
        # Dry run assertions happen right after dry run
        target_after_dryrun_exists = os.path.lexists(target)
        assert target_after_dryrun_exists == (expected["target_after_dryrun"] == "present"), (
            f"After dry run: target exists = {target_after_dryrun_exists}, "
            f"expected {expected['target_after_dryrun']}"
        )

        # side_effect is __skip__ for this scenario
        if expected["side_effect"] != "__skip__":
            assert os.path.exists(marker) == (expected["side_effect"] == "present"), (
                f"After dry run: marker exists = {os.path.exists(marker)}, "
                f"expected side_effect = {expected['side_effect']}"
            )

        # Now run the real install
        if expected["target_after_real"] != "__skip__":
            real_run = run(["system", "install"], workdir, env)
            assert real_run.returncode == 0, f"Real install failed: {combined(real_run)}"
            target_after_real_exists = os.path.lexists(target)
            assert target_after_real_exists == (expected["target_after_real"] == "present"), (
                f"After real install: target exists = {target_after_real_exists}, "
                f"expected {expected['target_after_real']}"
            )

    elif scenario == "no_side_effects":
        write(workdir, "dotfiles/ex.tmpl",
              '{{ exec(command="touch ran-marker") }}\n')
        write(workdir, "mise.toml",
              '[system.files]\n'
              '"~/.local/exec-out" = { source = "dotfiles/ex.tmpl", mode = "template" }\n')
        target = home_path(env, ".local/exec-out")
        marker = os.path.join(workdir, "ran-marker")

        # Run dry run
        dry_run_result = run(["system", "install", "--dry-run"], workdir, env)
        # Dry run assertions right after dry run, before real install
        target_after_dryrun_exists = os.path.lexists(target)
        assert target_after_dryrun_exists == (expected["target_after_dryrun"] == "present"), (
            f"After dry run: target exists = {target_after_dryrun_exists}, "
            f"expected {expected['target_after_dryrun']}"
        )

        if expected["side_effect"] != "__skip__":
            marker_exists = os.path.exists(marker)
            assert marker_exists == (expected["side_effect"] == "present"), (
                f"After dry run: marker exists = {marker_exists}, "
                f"expected side_effect = {expected['side_effect']}"
            )

        # Now run the real install
        if expected["target_after_real"] != "__skip__":
            real_run = run(["system", "install"], workdir, env)
            assert real_run.returncode == 0, f"Real install failed: {combined(real_run)}"
            target_after_real_exists = os.path.lexists(target)
            assert target_after_real_exists == (expected["target_after_real"] == "present"), (
                f"After real install: target exists = {target_after_real_exists}, "
                f"expected {expected['target_after_real']}"
            )

    else:
        raise ValueError(f"Unknown scenario: {scenario}")
