## Task

We embed the Pi agent, and Pi keeps a native branch tree for every conversation: any earlier prompt can have more than one continuation. We only ever render a single linear thread today, so there's no way to revisit an earlier prompt and take it in a different direction, or to move between the alternate continuations a prompt already has.

Let's add inline branch navigation, with no separate panel. Someone should be able to edit an earlier prompt to start an alternate continuation, and page between a prompt's sibling branches right in the transcript.

## User stories / requirements

- When someone edits an earlier prompt, that prompt's text loads into the composer and its continuation disappears from the transcript, but nothing is committed yet. Leaving the composer discards the preview and restores the conversation exactly as it was; only submitting creates the new branch.
- When a prompt has more than one continuation, paging between its sibling branches swaps the transcript to the selected branch and restores that branch's own conversation context and usage. Switching branches changes the conversation only; it never rewinds the files on disk.
- If switching branches ends in an uncertain state, such as a lost reply from the agent, the next message is held back rather than being sent on a branch that might be wrong. The conversation has to be reconciled first, and only once that resolves is sending allowed again.
- The main composer and the side composer each keep their own in-progress text; editing a branch in one never pulls content out of or into the other. If a send is rejected, the draft it came from is put back where it was.
- A prompt that has multiple continuations shows an unobtrusive marker and inline controls to move between branches, including which branch of how many is selected, all reachable with accessible labels. The very first prompt shows none of this, and neither do providers that have no native branches.
