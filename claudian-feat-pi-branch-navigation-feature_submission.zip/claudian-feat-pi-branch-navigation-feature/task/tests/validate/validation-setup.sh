#!/usr/bin/env bash
# validation-setup.sh — environment bootstrap for the validation-story driver.
# Sourced by the harbor runner so exported env vars / PATH persist into the Jest
# runs that follow.
#
# The image already ran `npm ci` from this commit's lockfile with the npm cache
# warmed at the base commit (image/Dockerfile), so in the normal case the
# dependency restore is a no-op. We re-guard it (an agent may have removed
# node_modules) and run it offline-first with a logged online fallback, then
# assert the Jest toolchain actually launches via the repo's own wrapper — a
# loud failure here beats a silent "0 tests ran" during grading.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/claudian}"
cd "$REPO_DIR"

node --version
npm --version

# Restore node_modules only if an agent removed it. Prefer the warm npm cache
# (offline); fall back to a networked install with a surfaced log.
if [ ! -d "node_modules" ] || [ ! -d "node_modules/.bin" ]; then
    echo "[validation-setup] node_modules missing — restoring with npm ci (offline-first)..."
    if npm ci --offline --cache /opt/cache/npm > /tmp/npm-ci-offline.log 2>&1; then
        tail -3 /tmp/npm-ci-offline.log
    else
        echo "[validation-setup] offline npm ci failed; retrying online:"
        tail -40 /tmp/npm-ci-offline.log || true
        npm ci --cache /opt/cache/npm > /tmp/npm-ci-online.log 2>&1 \
            || { tail -80 /tmp/npm-ci-online.log; exit 1; }
        tail -3 /tmp/npm-ci-online.log
    fi
fi

# Keep the lockfile pristine: the driver copies generated test files into
# tests/unit/__validation__/, which must not dirty tracked state in a way that
# trips the runner's cleanliness checks.
git update-index --assume-unchanged package-lock.json 2>/dev/null || true

# Make the repo's local bin available to the runner.
export PATH="$REPO_DIR/node_modules/.bin:$PATH"

# Loud smoke guard: the repo drives Jest through scripts/run-jest.js (it resolves
# the Jest 30 binary and supplies the Electron/localstorage flags). If that
# wrapper cannot even report a version, every story would silently "find no
# tests" — fail now, loudly, with the log surfaced.
echo "[validation-setup] verifying Jest launches via scripts/run-jest.js ..."
if node scripts/run-jest.js --version > /tmp/jest-smoke.log 2>&1; then
    echo "[validation-setup] jest version: $(tail -1 /tmp/jest-smoke.log)"
else
    echo "[validation-setup] FATAL: 'node scripts/run-jest.js --version' failed:"
    tail -60 /tmp/jest-smoke.log || true
    exit 1
fi

echo "[validation-setup] ready: $REPO_DIR (node=$(node --version), npm=$(npm --version))"
