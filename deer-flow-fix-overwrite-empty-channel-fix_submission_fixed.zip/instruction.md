## Task

Branches are broken. Branch a conversation off an earlier turn, run anything in the branch that uses a sandbox tool, and the run dies on an `Overwrite` object. The trace we have ends in `TypeError: 'Overwrite' object is not subscriptable`. We get the same error after setting a goal on a new conversation with `POST /api/threads/{id}/state` and then running it. It happens with `checkpoint_channel_mode` at both `full` and `delta`, and the parent conversation keeps working.

Someone got a branch past the error locally to see what else was wrong, and it ran inside the parent's sandbox. Files it wrote showed up in the parent's workspace, and the parent's sandbox was shut down when the branch's run ended. Branches used to work. Please fix this.
