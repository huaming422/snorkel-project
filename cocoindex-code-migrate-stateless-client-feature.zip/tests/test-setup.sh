#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# Must run with the network cut: the image (image/Dockerfile) baked the full
# dependency closure at the pre-fix commit into /opt/venv, and baked the
# embedding model sentence-transformers/all-MiniLM-L6-v2 into /opt/hf-cache.
cd /repo/cocoindex-code

# Fail fast on a cache miss instead of reaching for a registry.
export UV_OFFLINE=1
export VIRTUAL_ENV=/opt/venv UV_PROJECT_ENVIRONMENT=/opt/venv
# The grade run has no network; use the model baked into the image.
export HF_HOME=/opt/hf-cache HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1

# Dependencies: offline-first against the image bake, logged online fallback.
if uv sync --frozen --all-extras --group dev --offline > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] uv sync satisfied from image"
elif uv sync --frozen --all-extras --group dev >> /tmp/test-setup-install.log 2>&1; then
    echo "[test-setup] deps installed online (image bake was stale)"
else
    tail -60 /tmp/test-setup-install.log >&2; exit 1
fi

# No services to start and no data to seed: the daemon under test is launched
# per-test by the verifier/validation harness in an isolated COCOINDEX_CODE_DIR.
# No assertion logic here.
