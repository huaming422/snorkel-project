#!/usr/bin/env bash
# validation-setup.sh — runs once before the validation agent starts, after
# tests/test-setup.sh has synced deps. There is no long-lived service to start:
# each story launches its own daemon subprocess in an isolated COCOINDEX_CODE_DIR
# and tears it down. This script just pins the offline environment, makes the dep
# sync idempotent, and fails fast if the harness or the package can't import.

set -euo pipefail

REPO_DIR=/repo/cocoindex-code
cd "$REPO_DIR"

# The validation phase has no network: the image baked the dependency closure at
# the pre-fix commit into /opt/venv and the embedding model into /opt/hf-cache.
export UV_OFFLINE=1
export VIRTUAL_ENV=/opt/venv UV_PROJECT_ENVIRONMENT=/opt/venv
export HF_HOME=/opt/hf-cache HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1

# Idempotent dep sync against the image bake (fast no-op if test-setup.sh already
# synced). Offline-first, with a logged online fallback for a stale bake.
if uv sync --frozen --all-extras --group dev --offline > /tmp/validation-setup-install.log 2>&1; then
    echo "[validation-setup] uv sync satisfied from image bake"
elif uv sync --frozen --all-extras --group dev >> /tmp/validation-setup-install.log 2>&1; then
    echo "[validation-setup] deps installed online (image bake was stale)"
else
    echo "[validation-setup] uv sync failed:" >&2
    tail -60 /tmp/validation-setup-install.log >&2
    exit 1
fi

# Smoke-import the harness and the stable interfaces it drives, so a bad state
# surfaces here instead of mid-story. Run under the repository's own venv.
"/opt/venv/bin/python" - <<'PY'
import sys
sys.path.insert(0, "/tests/validate")
import test_harness  # noqa: F401
import cocoindex_code  # noqa: F401
from cocoindex_code.client import start_daemon, stop_daemon  # noqa: F401
from cocoindex_code.daemon import daemon_socket_path, daemon_pid_path  # noqa: F401
from cocoindex_code.protocol import (  # noqa: F401
    HandshakeRequest,
    IndexRequest,
    ProjectStatusRequest,
    StopRequest,
    encode_request,
    decode_response,
)
from cocoindex_code.settings import (  # noqa: F401
    LanguageOverride,
    ProjectSettings,
    save_project_settings,
    load_project_settings,
)
print("[validation-setup] test_harness + cocoindex_code imports OK")
PY

export REPO_NAME=cocoindex-code
