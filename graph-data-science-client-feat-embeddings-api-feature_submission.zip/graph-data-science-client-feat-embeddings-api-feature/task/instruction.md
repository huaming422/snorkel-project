## Task

We want to add a preview embeddings API to the client's session surface, so callers can work with node embeddings the same way they already reach the library's other endpoint families. Cover three capabilities: training an embedding model from a graph, encoding embeddings for a graph with a non-trainable encoder that skips training entirely, and predicting embeddings for a graph from a model trained earlier.

Reach all three from the session the way the existing families are reached, and keep them consistent with those families in how a caller picks an execution mode, hands over the target graph, and passes options. Encoding and predicting both work from input node properties already present on the target graph.

Treat the whole thing as a preview: when a caller reaches for it, make clear the surface is early and may still change.

## User stories / requirements

- A caller encodes node embeddings for a graph and can pick any of the usual execution modes, with the run dispatched to the backend over the target graph. The encoder is either supplied inline as a configuration or named from one trained earlier.
- A caller trains an embedding model from a graph by choosing an encoder and a decoder and giving the model a save name, then later predicts embeddings for a graph by referring to that trained model by name. Training and prediction are each offered across the usual execution modes.
- When a caller supplies a well-formed encoder or decoder configuration it is accepted and the run proceeds; when the settings are contradictory or nonsensical the configuration is refused up front, before any backend work begins.
