import warnings
import pandas as pd
from unittest import mock

from graphdatascience.session import AuraGraphDataScience
from graphdatascience.session.session_lifecycle_manager import Noop
from graphdatascience.arrow_client.authenticated_flight_client import AuthenticatedArrowClient


SEAM = "graphdatascience.arrow_client.v2.job_client.JobClient"
CANNED_SUMMARY = {
    "computeMillis": 1, "preProcessingMillis": 1, "configuration": {},
    "mutateMillis": 1, "writeMillis": 1, "nodePropertiesWritten": 0,
    "modelInfo": {"modelName": "my-model"},
    "trainMillis": 1,
}


def test_train_and_predict_backend_jobs(inputs, expected):
    """Test that train/predict dispatch correct backend jobs with correct payloads."""
    arrow_client = mock.Mock(spec=AuthenticatedArrowClient)
    session = AuraGraphDataScience(
        arrow_client,
        db_query_runner=None,
        session_lifecycle_manager=Noop(),
        show_progress=False,
    )

    graph = mock.Mock()
    graph.name.return_value = "g"

    capability = inputs["capability"]
    model_id = inputs["model_id"]

    with (
        mock.patch(SEAM + ".run_job", return_value="job-1") as run_job,
        mock.patch(SEAM + ".run_job_and_wait", return_value="job-1") as run_job_and_wait,
        mock.patch(SEAM + ".stream_results", return_value=pd.DataFrame()) as stream_results,
        mock.patch(SEAM + ".get_summary", return_value=dict(CANNED_SUMMARY)) as get_summary,
    ):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            if capability == "train":
                # Drive a train execution mode: pass graph, encoder, decoder,
                # model_name, and optional task config parameters.
                session.embeddings.train(
                    graph,
                    model_name=model_id,
                    encoder={"type": "GraphSAGE", "embedding_dimension": 16},
                    decoder={"type": "InnerProduct"},
                    feature_properties=["x"],
                    target_label="A",
                    target_property="y",
                )
            else:
                # "predict": reference the trained model by name
                session.embeddings.predict.stream(
                    graph,
                    model_name=model_id,
                    feature_properties=["x"],
                )

    # Recover action and payload from whichever seam was called
    call = (run_job if run_job.called else run_job_and_wait).call_args
    action = call.args[1]
    payload = call.args[2]

    # Compute observations
    observed_action = action
    observed_graph_name = payload["graphName"]

    # Count config mappings (dict values — encoder/decoder configs).
    # Base-config additions are strings/ints/lists, never mappings.
    observed_config_mappings = sum(1 for v in payload.values() if isinstance(v, dict))

    # Whether the caller-supplied model id is carried by value anywhere in the payload,
    # under whatever key the agent's design chose.
    observed_identifier_carried = any(
        isinstance(v, str) and v == model_id for v in payload.values()
    )

    observed_discriminator = "absent" if ("taskName" not in payload and "task_name" not in payload) else "present"

    # Assertions — use every key in expected
    assert observed_action == expected["action"], (
        f"Expected action {expected['action']!r}, got {observed_action!r}"
    )
    assert observed_graph_name == expected["graph_name"], (
        f"Expected graph_name {expected['graph_name']!r}, got {observed_graph_name!r}"
    )
    assert observed_config_mappings >= int(expected["min_config_mappings"]), (
        f"Expected at least {expected['min_config_mappings']} config mappings, got {observed_config_mappings}"
    )
    assert observed_identifier_carried == (expected["identifier_carried"] == "true"), (
        f"Expected identifier_carried {expected['identifier_carried']!r}, got {observed_identifier_carried!r}"
    )
    assert observed_discriminator == expected["task_discriminator"], (
        f"Expected task_discriminator {expected['task_discriminator']!r}, got {observed_discriminator!r}"
    )
