import warnings
import pandas as pd
from unittest import mock

from graphdatascience.session import AuraGraphDataScience
from graphdatascience.session.session_lifecycle_manager import Noop
from graphdatascience.arrow_client.authenticated_flight_client import AuthenticatedArrowClient


SEAM = "graphdatascience.arrow_client.v2.job_client.JobClient"
CANNED_SUMMARY = {
    "computeMillis": 1, "preProcessingMillis": 1, "configuration": {},
    "mutateMillis": 1, "writeMillis": 1, "nodePropertiesWritten": 0,
}


def test_encode_backend_job(inputs, expected):
    """Test that encoding dispatches the correct backend job with correct payload."""
    arrow_client = mock.Mock(spec=AuthenticatedArrowClient)
    session = AuraGraphDataScience(
        arrow_client,
        db_query_runner=None,
        session_lifecycle_manager=Noop(),
        show_progress=False,
    )

    graph = mock.Mock()
    graph.name.return_value = "g"

    encoder_mode = inputs["encoder_mode"]
    encoder_name_input = inputs["encoder_name"]

    with (
        mock.patch(SEAM + ".run_job", return_value="job-1") as run_job,
        mock.patch(SEAM + ".run_job_and_wait", return_value="job-1") as run_job_and_wait,
        mock.patch(SEAM + ".stream_results", return_value=pd.DataFrame()) as stream_results,
        mock.patch(SEAM + ".get_summary", return_value=dict(CANNED_SUMMARY)) as get_summary,
    ):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            if encoder_mode == "inline":
                # Use a non-trainable inline encoder config
                encoder = {"type": "FastRP", "embedding_dimension": 64}
                session.embeddings.encode.stream(
                    graph,
                    encoder=encoder,
                    feature_properties=["x"],
                )
            else:
                # "name" mode: pass the encoder name as a plain string
                session.embeddings.encode.stream(
                    graph,
                    encoder=encoder_name_input,
                    feature_properties=["x"],
                )

    # Recover action and payload from whichever seam was called
    call = (run_job if run_job.called else run_job_and_wait).call_args
    action = call.args[1]
    payload = call.args[2]

    # Compute observations
    observed_action = action
    observed_graph_name = payload["graphName"]
    observed_feature_properties = payload["featureProperties"]

    # Discover the encoder BY VALUE, not by key name.
    # For the "name" case the encoder is the plain string the caller supplied.
    # For the "inline" case it is the only mapping-valued entry in the payload.
    if encoder_mode == "name":
        wanted = encoder_name_input
        encoder_matches = [v for v in payload.values() if isinstance(v, str) and v == wanted]
        encoder_sent = encoder_matches[0] if encoder_matches else "__missing__"
    else:
        # inline: base-config additions are strings/ints/lists, never mappings,
        # so any dict-valued payload entry is the encoder configuration.
        encoder_matches = [v for v in payload.values() if isinstance(v, dict)]
        encoder_sent = encoder_matches[0] if encoder_matches else "__missing__"

    observed_encoder_form = "name" if isinstance(encoder_sent, str) else "mapping"
    # For the "inline" case, encoder_sent is a dict so we set observed_encoder_name
    # to "__skip__". For the "name" case, encoder_sent is the string name.
    # expected["encoder_name"] is also "__skip__" for inline, so unconditional
    # equality assertion works in both cases.
    observed_encoder_name = encoder_sent if isinstance(encoder_sent, str) else "__skip__"
    observed_discriminator = "absent" if ("taskName" not in payload and "task_name" not in payload) else "present"
    msgs = " ".join(str(w.message) for w in caught).lower()
    observed_preview_notice = "preview" if "preview" in msgs else "missing"

    # Assertions — use every key in expected
    assert observed_action == expected["action"], (
        f"Expected action {expected['action']!r}, got {observed_action!r}"
    )
    assert observed_graph_name == expected["graph_name"], (
        f"Expected graph_name {expected['graph_name']!r}, got {observed_graph_name!r}"
    )
    assert observed_feature_properties == expected["feature_properties"], (
        f"Expected feature_properties {expected['feature_properties']!r}, got {observed_feature_properties!r}"
    )
    assert observed_encoder_form == expected["encoder_form"], (
        f"Expected encoder_form {expected['encoder_form']!r}, got {observed_encoder_form!r}"
    )
    # For inline case both observed and expected are "__skip__" so unconditional equality holds.
    assert observed_encoder_name == expected["encoder_name"], (
        f"Expected encoder_name {expected['encoder_name']!r}, got {observed_encoder_name!r}"
    )
    assert observed_discriminator == expected["task_discriminator"], (
        f"Expected task_discriminator {expected['task_discriminator']!r}, got {observed_discriminator!r}"
    )
    assert observed_preview_notice == expected["preview_notice"], (
        f"Expected preview_notice {expected['preview_notice']!r}, got {observed_preview_notice!r}"
    )
