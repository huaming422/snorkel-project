import warnings
import pandas as pd
from unittest import mock

from graphdatascience.session import AuraGraphDataScience
from graphdatascience.session.session_lifecycle_manager import Noop
from graphdatascience.arrow_client.authenticated_flight_client import AuthenticatedArrowClient


SEAM = "graphdatascience.arrow_client.v2.job_client.JobClient"
CANNED_SUMMARY = {
    "computeMillis": 1, "preProcessingMillis": 1, "configuration": {},
    "mutateMillis": 1, "writeMillis": 1, "nodePropertiesWritten": 0,
    "modelInfo": {"modelName": "s"},
    "trainMillis": 1,
}


def test_embedding_config_constraints(inputs, expected):
    """Test that trainable encoder validation accepts well-formed configs and rejects invalid ones."""
    arrow_client = mock.Mock(spec=AuthenticatedArrowClient)
    session = AuraGraphDataScience(
        arrow_client,
        db_query_runner=None,
        session_lifecycle_manager=Noop(),
        show_progress=False,
    )

    graph = mock.Mock()
    graph.name.return_value = "g"

    variant = inputs["variant"]

    with (
        mock.patch(SEAM + ".run_job", return_value="job-1") as run_job,
        mock.patch(SEAM + ".run_job_and_wait", return_value="job-1") as run_job_and_wait,
        mock.patch(SEAM + ".stream_results", return_value=pd.DataFrame()) as stream_results,
        mock.patch(SEAM + ".get_summary", return_value=dict(CANNED_SUMMARY)) as get_summary,
    ):
        try:
            # Build encoder based on the variant and drive a train execution mode.
            # The validation module in the patch defines:
            #   _POSITIVE_INT_KEYS contains "dimension" (matched by "embedding_dimension")
            #   _DROPOUT_KEYS = {"dropout", "dropout_rate"}
            if variant == "well_formed":
                # Minimally valid trainable encoder: type specified, positive dimension.
                encoder = {"type": "GraphSAGE", "embedding_dimension": 16}
            elif variant == "contradictory_structure":
                # Same encoder but with a non-positive embedding_dimension (must be > 0).
                # The validator rejects integer values <= 0 for keys matching "dimension".
                encoder = {"type": "GraphSAGE", "embedding_dimension": -1}
            elif variant == "out_of_range_ratio":
                # Same well-formed encoder but with dropout set to 1.0.
                # The validator checks keys in _DROPOUT_KEYS = {"dropout", "dropout_rate"};
                # 'dropout' is the correct field name. The spec requires the allowed range
                # to be [0, 1) so 1.0 should be rejected.
                encoder = {"type": "GraphSAGE", "embedding_dimension": 16, "dropout": 1.0}
            else:
                raise ValueError(f"Unknown variant: {variant!r}")

            decoder = {"type": "InnerProduct"}

            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                session.embeddings.train(
                    graph,
                    model_name="s",
                    encoder=encoder,
                    decoder=decoder,
                    feature_properties=["x"],
                    target_label="A",
                    target_property="y",
                )
            observed_outcome = "accepted"
        except Exception:
            observed_outcome = "rejected"

    # Determine if backend was reached
    backend_reached = run_job.called or run_job_and_wait.called

    if observed_outcome == "accepted":
        call = (run_job if run_job.called else run_job_and_wait).call_args
        observed_backend_action = call.args[1]
    else:
        observed_backend_action = "__skip__"

    # Assertions — use every key in expected
    assert observed_outcome == expected["outcome"], (
        f"Expected outcome {expected['outcome']!r}, got {observed_outcome!r}"
    )
    # Assert backend_reached derived from expected["outcome"] (no separate expected key)
    assert backend_reached == (expected["outcome"] == "accepted"), (
        f"Expected backend_reached={expected['outcome'] == 'accepted'!r}, got {backend_reached!r}"
    )
    assert observed_backend_action == expected["backend_action"], (
        f"Expected backend_action {expected['backend_action']!r}, got {observed_backend_action!r}"
    )
