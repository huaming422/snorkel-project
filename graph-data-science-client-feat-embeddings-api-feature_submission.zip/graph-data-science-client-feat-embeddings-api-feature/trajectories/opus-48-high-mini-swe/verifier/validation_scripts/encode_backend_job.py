import sys
import warnings
import pandas as pd
from unittest import mock

from graphdatascience.session import AuraGraphDataScience
from graphdatascience.session.session_lifecycle_manager import Noop
from graphdatascience.arrow_client.authenticated_flight_client import AuthenticatedArrowClient
from graphdatascience.procedure_surface.api.node_embedding.embeddings_config import (
    HashGNNEncoderConfig,
)

SEAM = "graphdatascience.arrow_client.v2.job_client.JobClient"

# Stats summary that satisfies EmbeddingsStatsResult
STATS_SUMMARY = {
    "nodeCount": 10,
    "computeMillis": 1,
    "preProcessingMillis": 1,
    "configuration": {},
}


def test_encode_backend_job(inputs, expected):
    """inputs and expected are injected automatically — one call per test case."""
    arrow_client = mock.Mock(spec=AuthenticatedArrowClient)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        session = AuraGraphDataScience(
            arrow_client,
            db_query_runner=None,
            session_lifecycle_manager=Noop(),
            show_progress=False,
        )

    graph = mock.Mock()
    graph.name.return_value = "g"

    with (
        mock.patch(SEAM + ".run_job", return_value="job-1") as run_job,
        mock.patch(SEAM + ".run_job_and_wait", return_value="job-1") as run_job_and_wait,
        mock.patch(SEAM + ".stream_results", return_value=pd.DataFrame()) as stream_results,
        mock.patch(SEAM + ".get_summary", return_value=dict(STATS_SUMMARY)) as get_summary,
    ):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")

            if inputs["encoder_mode"] == "inline":
                # Build a non-trainable inline encoder configuration (HashGNN is non-trainable)
                encoder = HashGNNEncoderConfig(
                    iterations=2,
                    embedding_density=4,
                    feature_properties=["x"],
                )
                # Use stream() so run_job_and_wait is called (route that exposes action + payload)
                session.embeddings.encode.stream(graph, encoder)
            else:
                # Named encoder — pass the plain string
                encoder_name = inputs["encoder_name"]
                session.embeddings.encode.stream(graph, encoder_name)

    # Recover action and payload from the dispatched call
    # stream() calls run_job_and_wait; stats() also calls run_job_and_wait (via run_job_and_get_summary)
    call = (run_job if run_job.called else run_job_and_wait).call_args
    # Static method signature: run_job_and_wait(client, endpoint, config, show_progress)
    action = call.args[1]
    payload = call.args[2]

    observed_action = action
    observed_graph_name = payload["graphName"]

    # featureProperties is nested inside payload["encoder"] for inline mode (not at top level)
    encoder_value = payload.get("encoder")
    if isinstance(encoder_value, dict):
        # Inline encoder: featureProperties lives inside the encoder dict
        observed_feature_properties = encoder_value.get("featureProperties", [])
    else:
        # Named encoder (string): no featureProperties in payload
        observed_feature_properties = []

    # Discover the encoder form and name
    if inputs["encoder_mode"] == "name":
        # encoder_value is a plain string for named encoders
        encoder_sent = encoder_value if isinstance(encoder_value, str) else "__missing__"
        observed_encoder_form = "name"
        observed_encoder_name = encoder_sent
    else:
        # inline: the encoder is the structured config mapping (a dict under "encoder" key)
        observed_encoder_form = "mapping" if isinstance(encoder_value, dict) else "__missing__"
        observed_encoder_name = "__skip__"

    # Discriminator: check if taskName is present
    observed_discriminator = "absent" if ("taskName" not in payload and "task_name" not in payload) else "present"

    # Preview notice: warning was captured inside the inner caught block
    msgs = " ".join(str(w.message) for w in caught).lower()
    observed_preview_notice = "preview" if "preview" in msgs else "missing"

    assert observed_action == expected["action"], (
        f"Expected action {expected['action']!r}, got {observed_action!r}"
    )
    assert observed_graph_name == expected["graph_name"], (
        f"Expected graph_name {expected['graph_name']!r}, got {observed_graph_name!r}"
    )
    assert observed_feature_properties == expected["feature_properties"], (
        f"Expected feature_properties {expected['feature_properties']!r}, got {observed_feature_properties!r}"
    )
    assert observed_encoder_form == expected["encoder_form"], (
        f"Expected encoder_form {expected['encoder_form']!r}, got {observed_encoder_form!r}"
    )
    # encoder_name: for "name" case assert the actual name; for "inline" expected is "__skip__"
    if expected["encoder_name"] != "__skip__":
        assert observed_encoder_name == expected["encoder_name"], (
            f"Expected encoder_name {expected['encoder_name']!r}, got {observed_encoder_name!r}"
        )
    assert observed_discriminator == expected["task_discriminator"], (
        f"Expected task_discriminator {expected['task_discriminator']!r}, got {observed_discriminator!r}"
    )
    assert observed_preview_notice == expected["preview_notice"], (
        f"Expected preview_notice {expected['preview_notice']!r}, got {observed_preview_notice!r}"
    )
