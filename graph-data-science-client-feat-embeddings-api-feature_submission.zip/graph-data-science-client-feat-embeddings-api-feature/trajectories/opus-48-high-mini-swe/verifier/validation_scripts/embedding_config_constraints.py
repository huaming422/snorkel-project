import sys
import warnings
import pandas as pd
from unittest import mock

from graphdatascience.session import AuraGraphDataScience
from graphdatascience.session.session_lifecycle_manager import Noop
from graphdatascience.arrow_client.authenticated_flight_client import AuthenticatedArrowClient
from graphdatascience.procedure_surface.api.node_embedding.embeddings_config import (
    GraphSageEncoderConfig,
    DistMultDecoderConfig,
    EmbeddingConfigError,
)

SEAM = "graphdatascience.arrow_client.v2.job_client.JobClient"

# Train summary that satisfies EmbeddingsTrainResult
TRAIN_SUMMARY = {
    "modelInfo": {"name": "s"},
    "configuration": {},
    "trainMillis": 5,
}


def test_embedding_config_constraints(inputs, expected):
    """inputs and expected are injected automatically — one call per test case."""
    arrow_client = mock.Mock(spec=AuthenticatedArrowClient)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        session = AuraGraphDataScience(
            arrow_client,
            db_query_runner=None,
            session_lifecycle_manager=Noop(),
            show_progress=False,
        )

    graph = mock.Mock()
    graph.name.return_value = "g"

    variant = inputs["variant"]

    with (
        mock.patch(SEAM + ".run_job", return_value="job-1") as run_job,
        mock.patch(SEAM + ".run_job_and_wait", return_value="job-1") as run_job_and_wait,
        mock.patch(SEAM + ".stream_results", return_value=pd.DataFrame()) as stream_results,
        mock.patch(SEAM + ".get_summary", return_value=dict(TRAIN_SUMMARY)) as get_summary,
    ):
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")

                if variant == "well_formed":
                    # Minimally valid trainable encoder: positive embedding_dimension, non-empty feature_properties
                    encoder = GraphSageEncoderConfig(
                        feature_properties=["x"],
                        embedding_dimension=64,
                    )
                elif variant == "contradictory_structure":
                    # Empty feature_properties — structurally invalid (GraphSage requires at least one)
                    encoder = GraphSageEncoderConfig(
                        feature_properties=[],  # violates "requires at least one"
                        embedding_dimension=64,
                    )
                elif variant == "out_of_range_ratio":
                    # GraphSageEncoderConfig has no dropout/ratio field.
                    # Use embedding_dimension=0 (must be positive) as the out-of-range numeric proxy.
                    encoder = GraphSageEncoderConfig(
                        feature_properties=["x"],
                        embedding_dimension=0,  # non-positive — out of allowed range
                    )
                else:
                    raise ValueError(f"Unknown variant: {variant!r}")

                # Build a valid decoder
                decoder = DistMultDecoderConfig(relationship_type_dimension=4)

                # Drive train capability; session.embeddings.train is callable (__call__)
                session.embeddings.train(
                    graph,
                    "s",  # model_save_name
                    encoder,
                    decoder,
                )

            observed_outcome = "accepted"
        except Exception:
            observed_outcome = "rejected"

    # Determine whether the backend was reached
    backend_reached = run_job.called or run_job_and_wait.called

    if observed_outcome == "accepted":
        call = (run_job if run_job.called else run_job_and_wait).call_args
        # Static method signature: run_job_and_wait(client, endpoint, config, show_progress)
        observed_backend_action = call.args[1]
    else:
        observed_backend_action = "__skip__"

    assert observed_outcome == expected["outcome"], (
        f"Expected outcome {expected['outcome']!r} for variant {variant!r}, got {observed_outcome!r}"
    )

    if expected["outcome"] == "rejected":
        assert backend_reached is False, (
            f"Expected backend NOT to be reached for rejected case (variant={variant!r}), "
            f"but it was called"
        )
    else:
        assert backend_reached is True, (
            f"Expected backend to be reached for accepted case (variant={variant!r}), "
            f"but it was not called"
        )

    assert observed_backend_action == expected["backend_action"], (
        f"Expected backend_action {expected['backend_action']!r} for variant {variant!r}, "
        f"got {observed_backend_action!r}"
    )
