import sys
import warnings
import pandas as pd
from unittest import mock

from graphdatascience.session import AuraGraphDataScience
from graphdatascience.session.session_lifecycle_manager import Noop
from graphdatascience.arrow_client.authenticated_flight_client import AuthenticatedArrowClient
from graphdatascience.procedure_surface.api.node_embedding.embeddings_config import (
    GraphSageEncoderConfig,
    DistMultDecoderConfig,
)

SEAM = "graphdatascience.arrow_client.v2.job_client.JobClient"

# Train summary that satisfies EmbeddingsTrainResult
TRAIN_SUMMARY = {
    "modelInfo": {"name": "my-model"},
    "configuration": {},
    "trainMillis": 5,
}

# Stats summary that satisfies EmbeddingsStatsResult
STATS_SUMMARY = {
    "nodeCount": 10,
    "computeMillis": 1,
    "preProcessingMillis": 1,
    "configuration": {},
}


def test_train_and_predict_backend_jobs(inputs, expected):
    """inputs and expected are injected automatically — one call per test case."""
    arrow_client = mock.Mock(spec=AuthenticatedArrowClient)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        session = AuraGraphDataScience(
            arrow_client,
            db_query_runner=None,
            session_lifecycle_manager=Noop(),
            show_progress=False,
        )

    graph = mock.Mock()
    graph.name.return_value = "g"

    capability = inputs["capability"]
    model_id = inputs["model_id"]

    with (
        mock.patch(SEAM + ".run_job", return_value="job-1") as run_job,
        mock.patch(SEAM + ".run_job_and_wait", return_value="job-1") as run_job_and_wait,
        mock.patch(SEAM + ".stream_results", return_value=pd.DataFrame()) as stream_results,
        mock.patch(SEAM + ".get_summary", return_value=dict(TRAIN_SUMMARY if capability == "train" else STATS_SUMMARY)) as get_summary,
    ):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")

            if capability == "train":
                # Drive train with encoder + decoder + model_save_name
                # GraphSageEncoderConfig already carries feature_properties inside its to_dict()
                encoder = GraphSageEncoderConfig(feature_properties=["x"])
                decoder = DistMultDecoderConfig(relationship_type_dimension=4)
                # session.embeddings.train is EmbeddingsTrainArrowEndpoints, which is callable (__call__)
                session.embeddings.train(
                    graph,
                    model_id,  # model_save_name
                    encoder,
                    decoder,
                )
            else:
                # Drive predict with model_name (reference by name)
                # Use stream() so run_job_and_wait is called (route that exposes action + payload)
                session.embeddings.predict.stream(graph, model_id)

    # Recover action and payload from the dispatched call
    # Both train (via run_job_and_get_summary) and predict stream use run_job_and_wait
    # Static method signature: run_job_and_wait(client, endpoint, config, show_progress)
    call = (run_job if run_job.called else run_job_and_wait).call_args
    action = call.args[1]
    payload = call.args[2]

    observed_action = action
    observed_graph_name = payload["graphName"]

    # Count config mappings — any dict-valued payload entry is a config object (encoder, decoder, etc.)
    observed_config_mappings = sum(1 for v in payload.values() if isinstance(v, dict))

    # Check if the model id is carried by value anywhere in the payload (as a direct string value)
    wanted_id = model_id
    observed_identifier_carried = any(
        isinstance(v, str) and v == wanted_id for v in payload.values()
    )

    # Discriminator: check if taskName is present at top level
    observed_discriminator = "absent" if ("taskName" not in payload and "task_name" not in payload) else "present"

    assert observed_action == expected["action"], (
        f"Expected action {expected['action']!r}, got {observed_action!r}"
    )
    assert observed_graph_name == expected["graph_name"], (
        f"Expected graph_name {expected['graph_name']!r}, got {observed_graph_name!r}"
    )
    assert observed_config_mappings >= int(expected["min_config_mappings"]), (
        f"Expected at least {expected['min_config_mappings']} config mappings, got {observed_config_mappings}"
    )
    expected_id_carried = (expected["identifier_carried"] == "true")
    assert observed_identifier_carried == expected_id_carried, (
        f"Expected identifier_carried={expected_id_carried}, got {observed_identifier_carried} "
        f"(model_id={model_id!r}, payload values={[v for v in payload.values() if isinstance(v, str)]!r})"
    )
    assert observed_discriminator == expected["task_discriminator"], (
        f"Expected task_discriminator {expected['task_discriminator']!r}, got {observed_discriminator!r}"
    )
