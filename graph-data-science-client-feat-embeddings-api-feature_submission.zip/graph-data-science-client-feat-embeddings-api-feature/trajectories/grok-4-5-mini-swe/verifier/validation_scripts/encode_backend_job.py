import sys
sys.path.insert(0, "/tests/validate")

import pandas as pd
import warnings
from unittest import mock
from graphdatascience.session import AuraGraphDataScience
from graphdatascience.session.session_lifecycle_manager import Noop
from graphdatascience.arrow_client.authenticated_flight_client import AuthenticatedArrowClient
from graphdatascience.procedure_surface.api.node_embedding.config import FastRPConfig


SEAM = "graphdatascience.arrow_client.v2.job_client.JobClient"
CANNED_SUMMARY = {
    "computeMillis": 1, "preProcessingMillis": 1, "configuration": {},
    "mutateMillis": 1, "writeMillis": 1, "nodePropertiesWritten": 0,
}


def test_encode_backend_job(inputs, expected):
    """
    Test that the encode capability dispatches a backend job with the correct
    action string, graph name, feature properties, and encoder form.
    """
    arrow_client = mock.Mock(spec=AuthenticatedArrowClient)
    session = AuraGraphDataScience(
        arrow_client,
        db_query_runner=None,
        session_lifecycle_manager=Noop(),
        show_progress=False,
    )

    graph = mock.Mock()
    graph.name.return_value = "g"

    with (
        mock.patch(SEAM + ".run_job", return_value="job-1") as run_job,
        mock.patch(SEAM + ".run_job_and_wait", return_value="job-1") as run_job_and_wait,
        mock.patch(SEAM + ".stream_results", return_value=pd.DataFrame()) as stream_results,
        mock.patch(SEAM + ".get_summary", return_value=dict(CANNED_SUMMARY)) as get_summary,
    ):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            # Access embeddings property (issues a preview warning)
            encode_endpoints = session.embeddings.encode

            encoder_mode = inputs["encoder_mode"]
            if encoder_mode == "inline":
                # Inline non-trainable encoder configuration - FastRP is a non-trainable encoder
                # feature_properties is embedded inside the encoder config
                encoder = FastRPConfig(feature_properties=["x"], out_dim=8)
                encode_endpoints.compute(graph, encoder=encoder)
            else:
                # Named encoder (a trained model referenced by name)
                encoder_name = inputs["encoder_name"]
                encode_endpoints.compute(graph, encoder=encoder_name)

    # Recover action and payload
    call = (run_job if run_job.called else run_job_and_wait).call_args
    action = call.args[1]
    payload = call.args[2]

    observed_action = action
    observed_graph_name = payload["graphName"]

    # Per the spec, featureProperties should be at the TOP LEVEL of the payload
    # (fixed by the backend wire protocol). Use .get() so the test fails with
    # AssertionError if the implementation does not hoist it to the top level,
    # rather than crashing with KeyError.
    observed_feature_properties = payload.get("featureProperties")

    # Discover the encoder BY VALUE, not by key name (the key the agent's design
    # emits it under — "graphEncoder", "encoder", etc. — is not protocol-fixed).
    # For the "inline" case the encoder you built is the only mapping-valued entry
    # in the payload; for the "name" case it is the plain string you supplied.
    if inputs["encoder_mode"] == "name":
        wanted = inputs["encoder_name"]
        encoder_matches = [v for v in payload.values() if isinstance(v, str) and v == wanted]
        encoder_sent = encoder_matches[0] if encoder_matches else "__missing__"
    else:
        # inline: find the dict-valued payload entry
        encoder_matches = [v for v in payload.values() if isinstance(v, dict)]
        encoder_sent = encoder_matches[0] if encoder_matches else "__missing__"

    observed_encoder_form = "name" if isinstance(encoder_sent, str) else "mapping"
    # For the name case, encoder_sent is the plain name string.
    # For the inline case, it is a dict, so observed_encoder_name becomes "__skip__".
    observed_encoder_name = encoder_sent if isinstance(encoder_sent, str) else "__skip__"
    observed_discriminator = "absent" if ("taskName" not in payload and "task_name" not in payload) else "present"

    msgs = " ".join(str(w.message) for w in caught).lower()
    observed_preview_notice = "preview" if "preview" in msgs else "missing"

    assert observed_action == expected["action"], (
        f"Expected action {expected['action']!r}, got {observed_action!r}"
    )
    assert observed_graph_name == expected["graph_name"], (
        f"Expected graph_name {expected['graph_name']!r}, got {observed_graph_name!r}"
    )
    assert observed_feature_properties == expected["feature_properties"], (
        f"Expected feature_properties {expected['feature_properties']!r}, got {observed_feature_properties!r}"
    )
    assert observed_encoder_form == expected["encoder_form"], (
        f"Expected encoder_form {expected['encoder_form']!r}, got {observed_encoder_form!r}"
    )
    assert observed_encoder_name == expected["encoder_name"], (
        f"Expected encoder_name {expected['encoder_name']!r}, got {observed_encoder_name!r}"
    )
    assert observed_discriminator == expected["task_discriminator"], (
        f"Expected task_discriminator {expected['task_discriminator']!r}, got {observed_discriminator!r}"
    )
    assert observed_preview_notice == expected["preview_notice"], (
        f"Expected preview_notice {expected['preview_notice']!r}, got {observed_preview_notice!r}"
    )
