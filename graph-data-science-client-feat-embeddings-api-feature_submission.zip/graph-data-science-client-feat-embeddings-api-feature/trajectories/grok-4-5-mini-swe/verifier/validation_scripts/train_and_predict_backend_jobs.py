import sys
sys.path.insert(0, "/tests/validate")

import pandas as pd
import warnings
from unittest import mock
from graphdatascience.session import AuraGraphDataScience
from graphdatascience.session.session_lifecycle_manager import Noop
from graphdatascience.arrow_client.authenticated_flight_client import AuthenticatedArrowClient
from graphdatascience.procedure_surface.api.node_embedding.config import (
    GraphSAGEConfig,
    MLPClassifierConfig,
)


SEAM = "graphdatascience.arrow_client.v2.job_client.JobClient"

TRAIN_SUMMARY = {
    "modelInfo": {"modelName": "my-model"},
    "configuration": {},
    "trainMillis": 1,
}

CANNED_SUMMARY = {
    "computeMillis": 1, "preProcessingMillis": 1, "configuration": {},
    "mutateMillis": 1, "writeMillis": 1, "nodePropertiesWritten": 0,
}


def test_train_and_predict_backend_jobs(inputs, expected):
    """
    Test that the train and predict capabilities dispatch backend jobs with the
    correct action strings and carry the expected payload contents.
    """
    arrow_client = mock.Mock(spec=AuthenticatedArrowClient)
    session = AuraGraphDataScience(
        arrow_client,
        db_query_runner=None,
        session_lifecycle_manager=Noop(),
        show_progress=False,
    )

    graph = mock.Mock()
    graph.name.return_value = "g"

    capability = inputs["capability"]
    model_id = inputs["model_id"]

    # For train, get_summary must return something EmbeddingsTrainResult can parse
    summary = TRAIN_SUMMARY if capability == "train" else CANNED_SUMMARY

    with (
        mock.patch(SEAM + ".run_job", return_value="job-1") as run_job,
        mock.patch(SEAM + ".run_job_and_wait", return_value="job-1") as run_job_and_wait,
        mock.patch(SEAM + ".stream_results", return_value=pd.DataFrame()) as stream_results,
        mock.patch(SEAM + ".get_summary", return_value=dict(summary)) as get_summary,
    ):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            embeddings = session.embeddings

            if capability == "train":
                # Train an embedding model with an encoder and decoder
                encoder = GraphSAGEConfig(
                    target_type="N",
                    hidden_dims=[8],
                    num_neighbors=[10, 5],
                )
                decoder = MLPClassifierConfig(hidden_dims=[4])
                embeddings.train(
                    graph,
                    model_name=model_id,
                    encoder=encoder,
                    decoder=decoder,
                )
            elif capability == "predict":
                # Predict using a trained model referenced by name
                embeddings.predict.compute(
                    graph,
                    model_name=model_id,
                )

    # Recover action and payload from whichever seam was called
    call = (run_job if run_job.called else run_job_and_wait).call_args
    action = call.args[1]
    payload = call.args[2]

    observed_action = action
    observed_graph_name = payload["graphName"]

    # Count how many dict-valued entries are in payload (each is an encoder/decoder config)
    observed_config_mappings = sum(1 for v in payload.values() if isinstance(v, dict))

    # Whether the model id is carried by value anywhere in the payload
    wanted_id = model_id
    observed_identifier_carried = any(
        isinstance(v, str) and v == wanted_id for v in payload.values()
    )

    observed_discriminator = "absent" if ("taskName" not in payload and "task_name" not in payload) else "present"

    assert observed_action == expected["action"], (
        f"Expected action {expected['action']!r}, got {observed_action!r}"
    )
    assert observed_graph_name == expected["graph_name"], (
        f"Expected graph_name {expected['graph_name']!r}, got {observed_graph_name!r}"
    )
    assert observed_config_mappings >= int(expected["min_config_mappings"]), (
        f"Expected at least {expected['min_config_mappings']} config mappings, got {observed_config_mappings}"
    )
    assert observed_identifier_carried == (expected["identifier_carried"] == "true"), (
        f"Expected identifier_carried={expected['identifier_carried']}, got {observed_identifier_carried}"
    )
    assert observed_discriminator == expected["task_discriminator"], (
        f"Expected task_discriminator {expected['task_discriminator']!r}, got {observed_discriminator!r}"
    )
