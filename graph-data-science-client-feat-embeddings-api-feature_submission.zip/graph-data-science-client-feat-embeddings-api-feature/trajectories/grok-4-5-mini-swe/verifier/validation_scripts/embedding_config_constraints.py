import sys
sys.path.insert(0, "/tests/validate")

import pandas as pd
import warnings
from unittest import mock
from graphdatascience.session import AuraGraphDataScience
from graphdatascience.session.session_lifecycle_manager import Noop
from graphdatascience.arrow_client.authenticated_flight_client import AuthenticatedArrowClient
from graphdatascience.procedure_surface.api.node_embedding.config import (
    GraphSAGEConfig,
    MLPClassifierConfig,
)


SEAM = "graphdatascience.arrow_client.v2.job_client.JobClient"

TRAIN_SUMMARY = {
    "modelInfo": {"modelName": "s"},
    "configuration": {},
    "trainMillis": 1,
}


def test_embedding_config_constraints(inputs, expected):
    """
    Test that well-formed encoder configs are accepted and invalid ones are rejected
    before any backend call is made.
    """
    arrow_client = mock.Mock(spec=AuthenticatedArrowClient)
    session = AuraGraphDataScience(
        arrow_client,
        db_query_runner=None,
        session_lifecycle_manager=Noop(),
        show_progress=False,
    )

    graph = mock.Mock()
    graph.name.return_value = "g"

    variant = inputs["variant"]

    with (
        mock.patch(SEAM + ".run_job", return_value="job-1") as run_job,
        mock.patch(SEAM + ".run_job_and_wait", return_value="job-1") as run_job_and_wait,
        mock.patch(SEAM + ".stream_results", return_value=pd.DataFrame()),
        mock.patch(SEAM + ".get_summary", return_value=dict(TRAIN_SUMMARY)),
    ):
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                embeddings = session.embeddings

            if variant == "well_formed":
                # GraphSAGE with aligned depth: len(hidden_dims) + 1 == len(num_neighbors)
                # hidden_dims=[8] -> 1 layer, num_neighbors=[10, 5] -> 2 entries (1+1=2 ✓)
                encoder = GraphSAGEConfig(
                    target_type="N",
                    hidden_dims=[8],
                    num_neighbors=[10, 5],
                )
            elif variant == "contradictory_structure":
                # Misaligned depth: hidden_dims has 1 layer, num_neighbors has 3 entries
                # but rule requires len(hidden_dims) + 1 == len(num_neighbors)
                # hidden_dims=[8] -> 1 layer, num_neighbors=[10, 5, 2] -> 3 entries (but 1+1=2 ≠ 3)
                encoder = GraphSAGEConfig(
                    target_type="N",
                    hidden_dims=[8],
                    num_neighbors=[10, 5, 2],
                )
            elif variant == "out_of_range_ratio":
                # dropout set to 1.0, which is outside the allowed [0, 1) range
                encoder = GraphSAGEConfig(
                    target_type="N",
                    hidden_dims=[8],
                    num_neighbors=[10, 5],
                    dropout=1.0,
                )
            else:
                raise ValueError(f"Unknown variant: {variant!r}")

            decoder = MLPClassifierConfig(hidden_dims=[4])

            embeddings.train(
                graph,
                model_name="s",
                encoder=encoder,
                decoder=decoder,
            )

            observed_outcome = "accepted"
        except Exception:
            observed_outcome = "rejected"

    backend_reached = run_job.called or run_job_and_wait.called

    if observed_outcome == "accepted":
        call = (run_job if run_job.called else run_job_and_wait).call_args
        observed_backend_action = call.args[1]
    else:
        observed_backend_action = "__skip__"

    assert observed_outcome == expected["outcome"], (
        f"Expected outcome {expected['outcome']!r}, got {observed_outcome!r}"
    )

    if expected["outcome"] == "rejected":
        assert not backend_reached, (
            f"Expected backend NOT to be reached for rejected variant {variant!r}, "
            f"but run_job.called={run_job.called}, run_job_and_wait.called={run_job_and_wait.called}"
        )
    else:
        assert backend_reached, (
            f"Expected backend to be reached for accepted variant {variant!r}, but it was not"
        )

    assert observed_backend_action == expected["backend_action"], (
        f"Expected backend_action {expected['backend_action']!r}, got {observed_backend_action!r}"
    )
