#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# Must run with the network cut: the image baked the full Go dependency and
# build-cache closure at the base commit, so everything below resolves offline.
cd /repo/beads

# Cut Go to the baked caches so a miss fails fast instead of reaching a proxy.
export GOFLAGS=-mod=mod GOPROXY=off CGO_ENABLED=1

# Dependencies: offline-first against the image bake, logged online fallback.
if go mod download > /tmp/test-setup-godl.log 2>&1; then
    echo "[offline-first] go mod satisfied from image"
elif GOPROXY=https://proxy.golang.org go mod download >> /tmp/test-setup-godl.log 2>&1; then
    echo "[test-setup] go mod downloaded online (image bake was stale)"
else
    tail -40 /tmp/test-setup-godl.log >&2; exit 1
fi

# No services to start: the verifier exercises in-process Go tests (pure-Go
# storage/types/httpapi units and the CGO embedded-dolt backend, which runs a
# dolt database in-process from a temp dir). No assertion logic here.
