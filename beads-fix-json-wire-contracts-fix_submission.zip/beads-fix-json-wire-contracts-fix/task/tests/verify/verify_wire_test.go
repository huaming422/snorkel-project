// Pure-Go checks on the JSON wire contract that a client sees: metadata scalar
// typing, the revision token's wire spelling in the issue detail view, and the
// agreement between the generated Go request/response structs and the published
// OpenAPI document. Everything here runs through the packages' exported surface
// (storage.MetadataEditValue / storage.ApplyMetadataEdits, types.NewIssueDetails,
// the apigen structs, the embedded spec bytes) — no internal symbol is named.
package storage_test

import (
	"encoding/json"
	"reflect"
	"strconv"
	"testing"

	"gopkg.in/yaml.v3"

	"github.com/steveyegge/beads/internal/httpapi/apigen"
	"github.com/steveyegge/beads/internal/httpapi/spec"
	"github.com/steveyegge/beads/internal/storage"
	"github.com/steveyegge/beads/internal/types"
)

// A --set-metadata value is stored and echoed as JSON whose scalar type is
// inferred from the value's spelling: the canonical JSON scalars keep their
// type, while a spelling that is not valid JSON on its own stays a quoted
// string even when it scans as a float. The leading-zero / unary-plus / NaN /
// dotted rows are the ones a value-based (rather than spelling-based) reading
// would get wrong; the text rows protect the map[string]string round-trip.
func TestVerifyMetadataScalarTyping(t *testing.T) {
	cases := []struct {
		name  string
		input string
		want  string
	}{
		{"integer", "5", `5`},
		{"negative integer", "-2", `-2`},
		{"trailing zero float", "0.50", `0.50`},
		{"exponent", "1e3", `1e3`},
		{"zero", "0", `0`},
		{"true", "true", `true`},
		{"false", "false", `false`},
		{"null", "null", `null`},
		{"leading zero stays text", "05", `"05"`},
		{"unary plus stays text", "+5", `"+5"`},
		{"not-a-number stays text", "NaN", `"NaN"`},
		{"dotted triple stays text", "1.2.3", `"1.2.3"`},
		{"empty stays text", "", `""`},
		{"word stays text", "abc", `"abc"`},
		{"sentence stays text", "hello world", `"hello world"`},
	}
	for _, c := range cases {
		c := c
		t.Run(c.name, func(t *testing.T) {
			got := string(storage.MetadataEditValue(c.input))
			if got != c.want {
				t.Errorf("MetadataEditValue(%q) = %s, want %s", c.input, got, c.want)
			}
			if !json.Valid([]byte(got)) {
				t.Errorf("MetadataEditValue(%q) = %s, which is not valid JSON", c.input, got)
			}
		})
	}
}

// The inference must reach the merged blob every edit path writes, not just the
// single-value helper. A set of edits is applied over an existing blob and the
// resulting JSON is decoded back: canonical scalars arrive as numbers / bools /
// null, text arrives as a string, and pre-existing keys survive untouched.
func TestVerifyApplyMetadataEditsTyping(t *testing.T) {
	merged, err := storage.ApplyMetadataEdits(
		json.RawMessage(`{"existing":"yes"}`),
		[]string{"score=99", "ratio=0.5", "done=true", "cleared=null", "tier=gold"},
		nil,
	)
	if err != nil {
		t.Fatalf("ApplyMetadataEdits: %v", err)
	}
	var got map[string]any
	if err := json.Unmarshal(merged, &got); err != nil {
		t.Fatalf("unmarshal %s: %v", merged, err)
	}
	if got["score"] != float64(99) {
		t.Errorf("metadata[score] = %#v, want the JSON number 99", got["score"])
	}
	if got["ratio"] != 0.5 {
		t.Errorf("metadata[ratio] = %#v, want the JSON number 0.5", got["ratio"])
	}
	if got["done"] != true {
		t.Errorf("metadata[done] = %#v, want the JSON boolean true", got["done"])
	}
	if v, present := got["cleared"]; !present || v != nil {
		t.Errorf("metadata[cleared] = %#v (present=%v), want JSON null", v, present)
	}
	if got["tier"] != "gold" {
		t.Errorf("metadata[tier] = %#v, want %q", got["tier"], "gold")
	}
	if got["existing"] != "yes" {
		t.Errorf("metadata[existing] = %#v, want %q: pre-existing keys must survive", got["existing"], "yes")
	}
}

// The detail view publishes the row's optimistic-concurrency token under the
// `revision` key. On the wire it must be a JSON string holding the token's
// decimal spelling, because the token spans the full int64 range and a JSON
// number past 2^53 is silently rounded by a JavaScript consumer — which then
// echoes a corrupted guard and earns a spurious version conflict. A value past
// 2^53 is used so a number-typed projection would visibly lose precision.
func TestVerifyRevisionDetailsWireString(t *testing.T) {
	const rowVersion int64 = 9007199254740993 // 2^53 + 1
	issue := types.Issue{RowVersion: rowVersion}
	details := types.NewIssueDetails(issue)

	blob, err := json.Marshal(details)
	if err != nil {
		t.Fatalf("marshal issue details: %v", err)
	}
	var fields map[string]json.RawMessage
	if err := json.Unmarshal(blob, &fields); err != nil {
		t.Fatalf("unmarshal issue details %s: %v", blob, err)
	}
	raw, ok := fields["revision"]
	if !ok {
		t.Fatalf("issue details carry no `revision` member: %s", blob)
	}
	// A JSON string literal begins with a double quote; a JSON number does not.
	if len(raw) == 0 || raw[0] != '"' {
		t.Fatalf("`revision` = %s, want a JSON string (a number loses precision past 2^53)", raw)
	}
	var token string
	if err := json.Unmarshal(raw, &token); err != nil {
		t.Fatalf("`revision` %s does not decode as a JSON string: %v", raw, err)
	}
	if token != strconv.FormatInt(rowVersion, 10) {
		t.Errorf("`revision` = %q, want the decimal spelling %q", token, strconv.FormatInt(rowVersion, 10))
	}
}

// The generated Go structs and the published OpenAPI document must agree on the
// scalar type of every revision / expected-version / actual-version member, and
// that agreed type must be `string`. A Go int64 pairs with OpenAPI `integer`; a
// Go string pairs with OpenAPI `string`. This forbids both a change that lands
// in one surface but not the other (the drift a regenerate-the-spec step exists
// to prevent) and a surface that leaves these members as numbers on the wire.
func TestVerifyGeneratedSpecTypeAgreement(t *testing.T) {
	var doc map[string]any
	if err := yaml.Unmarshal(spec.OpenAPIV0(), &doc); err != nil {
		t.Fatalf("parse embedded OpenAPI document: %v", err)
	}

	// schema/prop name the OpenAPI member; goType/field name the generated Go
	// struct member it must agree with.
	checks := []struct {
		schema string
		prop   string
		goType reflect.Type
		field  string
	}{
		{"UpdateIssueResponse", "revision", reflect.TypeOf(apigen.UpdateIssueResponse{}), "Revision"},
		{"CloseIssueResponse", "revision", reflect.TypeOf(apigen.CloseIssueResponse{}), "Revision"},
		{"ReleaseIssueResponse", "revision", reflect.TypeOf(apigen.ReleaseIssueResponse{}), "Revision"},
		{"ReopenIssueResponse", "revision", reflect.TypeOf(apigen.ReopenIssueResponse{}), "Revision"},
		{"ApplyItemResult", "revision", reflect.TypeOf(apigen.ApplyItemResult{}), "Revision"},
		{"UpdateIssueRequest", "expected_version", reflect.TypeOf(apigen.UpdateIssueRequest{}), "ExpectedVersion"},
		{"CloseIssueRequest", "expected_version", reflect.TypeOf(apigen.CloseIssueRequest{}), "ExpectedVersion"},
		{"ReopenIssueRequest", "expected_version", reflect.TypeOf(apigen.ReopenIssueRequest{}), "ExpectedVersion"},
		{"DeleteIssuesRequest", "expected_version", reflect.TypeOf(apigen.DeleteIssuesRequest{}), "ExpectedVersion"},
		{"ApplyUpdateItem", "expected_version", reflect.TypeOf(apigen.ApplyUpdateItem{}), "ExpectedVersion"},
		{"ApplyCloseItem", "expected_version", reflect.TypeOf(apigen.ApplyCloseItem{}), "ExpectedVersion"},
		{"Problem", "expected_version", reflect.TypeOf(apigen.Problem{}), "ExpectedVersion"},
		{"Problem", "actual_version", reflect.TypeOf(apigen.Problem{}), "ActualVersion"},
	}

	for _, c := range checks {
		c := c
		t.Run(c.schema+"."+c.prop, func(t *testing.T) {
			goScalar := openAPIScalarFor(t, c.goType, c.field)
			specScalar := specPropertyType(t, doc, c.schema, c.prop)
			if goScalar != specScalar {
				t.Errorf("%s.%s: generated struct says %q, OpenAPI document says %q — the two have drifted",
					c.schema, c.prop, goScalar, specScalar)
			}
			if goScalar != "string" {
				t.Errorf("%s.%s: type is %q, want \"string\" — revision and expected_version must be JSON strings on the wire",
					c.schema, c.prop, goScalar)
			}
		})
	}
}

// openAPIScalarFor maps the Go field's kind onto the OpenAPI scalar it should be
// described by: an integer kind -> "integer", a string kind -> "string". A
// pointer field is followed to its element first.
func openAPIScalarFor(t *testing.T, st reflect.Type, field string) string {
	t.Helper()
	f, ok := st.FieldByName(field)
	if !ok {
		t.Fatalf("%s has no field %q", st.Name(), field)
	}
	ft := f.Type
	if ft.Kind() == reflect.Pointer {
		ft = ft.Elem()
	}
	switch ft.Kind() {
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64,
		reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
		return "integer"
	case reflect.String:
		return "string"
	default:
		t.Fatalf("%s.%s has kind %s, which is neither an integer nor a string wire scalar", st.Name(), field, ft.Kind())
		return ""
	}
}

// specPropertyType reads components.schemas.<schema>.properties.<prop>.type out
// of the parsed OpenAPI document.
func specPropertyType(t *testing.T, doc map[string]any, schema, prop string) string {
	t.Helper()
	components := childMap(t, doc, "components")
	schemas := childMap(t, components, "schemas")
	s := childMap(t, schemas, schema)
	props := childMap(t, s, "properties")
	p := childMap(t, props, prop)
	typ, ok := p["type"].(string)
	if !ok {
		t.Fatalf("components.schemas.%s.properties.%s has no string `type`", schema, prop)
	}
	return typ
}

func childMap(t *testing.T, parent map[string]any, key string) map[string]any {
	t.Helper()
	v, ok := parent[key]
	if !ok {
		t.Fatalf("missing key %q", key)
	}
	m, ok := v.(map[string]any)
	if !ok {
		t.Fatalf("key %q is %T, want a mapping", key, v)
	}
	return m
}
