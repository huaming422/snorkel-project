#!/usr/bin/env bash
# validation-setup.sh — runs once before the validation agent starts.
# Ensures harbor's uv-managed venv exists and the agent subsystem is
# importable, so the stories can `import harbor.agents.installed.*` and drive
# each adapter's run() directly. Mirrors tests/test-setup.sh: same repo, same
# package manager, same editable install. Safe to re-run.

set -euo pipefail

REPO=/repo/harbor
cd "$REPO"

export PATH="/usr/local/bin:/root/.local/bin:$PATH"   # uv / uvx
export UV_CACHE_DIR=/opt/uv-cache

# The image pre-ran `uv sync --frozen` against the base commit, so this is
# normally a fast no-op. --frozen pins to uv.lock; the default (dev) group
# brings pytest + pytest-asyncio, which the pytest-driver stories run under.
# Offline-first against the image bake, with a logged online fallback.
if uv sync --frozen --offline > /tmp/validation-setup.log 2>&1; then
    echo "[offline-first] uv sync satisfied from image"
elif uv sync --frozen >> /tmp/validation-setup.log 2>&1; then
    echo "[validation-setup] deps installed online (image bake was stale)"
else
    tail -60 /tmp/validation-setup.log >&2
    exit 1
fi

# Expose harbor's venv interpreter on PATH so `python`/`pytest` resolve to the
# editable install with the full dependency tree.
if [ -d "$REPO/.venv" ]; then
    export VIRTUAL_ENV="$REPO/.venv"
    export PATH="$REPO/.venv/bin:$PATH"
fi

# Smoke-import the subsystem the stories drive, to fail fast if the env is
# broken before any story runs.
python - <<'PY'
import harbor.agents.base  # noqa: F401
import harbor.agents.installed.base  # noqa: F401
import harbor.agents.installed.pi  # noqa: F401
import harbor.agents.installed.swe_agent  # noqa: F401
import harbor.agents.installed.goose  # noqa: F401
import harbor.agents.installed.claude_code  # noqa: F401
print("harbor agents import OK")
PY
