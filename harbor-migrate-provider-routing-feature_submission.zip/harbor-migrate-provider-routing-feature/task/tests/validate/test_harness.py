"""Framework-plumbing helpers for the provider-routing validation stories.

This harness contains NO knowledge of how any adapter resolves provider
credentials. It only (1) builds a mock sandbox environment whose ``exec``
coroutine records its call arguments, and (2) reads back the environment
mapping an adapter forwarded to a given ``exec`` call. The validation agent
writes the "construct the adapter and drive run()" step itself, against the
pre-existing public adapter classes it imports — the harness stays
implementation-agnostic.

Why this exists: every installed adapter forwards the model subprocess
environment as the ``env=`` keyword of ``environment.exec(...)`` (through the
pre-existing ``exec_as_agent`` -> ``_exec`` -> ``environment.exec`` plumbing).
The stable, observable contract is "what ended up in that ``env`` mapping",
and `exec_env_of(...)` reads exactly that off a recorded call.

Typical use in a story procedure::

    import asyncio
    from test_harness import make_mock_env, exec_env_of
    from harbor.agents.installed.pi import Pi

    env = make_mock_env()
    agent = Pi(logs_dir=str(tmp_path), model_name="anthropic/claude-3-5",
               extra_env={"ANTHROPIC_API_KEY": "run-key"})
    asyncio.run(agent.run("do the task", env, make_ctx()))
    forwarded = exec_env_of(env, -1)   # env mapping of the last exec call
    assert forwarded.get("ANTHROPIC_API_KEY") == "run-key"
"""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock


def make_exec_result(
    return_code: int = 0, stdout: str = "", stderr: str = ""
) -> AsyncMock:
    """A stand-in for an ExecResult: whatever attributes callers read back."""
    result = AsyncMock()
    result.return_code = return_code
    result.stdout = stdout
    result.stderr = stderr
    return result


def make_mock_env(
    return_code: int = 0, stdout: str = "", stderr: str = ""
) -> AsyncMock:
    """Build a mock sandbox environment for driving an adapter's ``run()``.

    ``exec`` is an AsyncMock that returns a successful ExecResult-like object
    and records every call (inspect ``env.exec.call_args_list``). ``upload_file``
    is stubbed to a no-op so adapters that stage files do not fail. Any other
    coroutine an adapter happens to call resolves to a benign AsyncMock.
    """
    env = AsyncMock()
    env.exec.return_value = make_exec_result(return_code, stdout, stderr)
    env.upload_file.return_value = None
    return env


def make_ctx() -> AsyncMock:
    """A minimal stand-in for the AgentContext an adapter's ``run()`` receives."""
    return AsyncMock()


def exec_calls(mock_env: Any) -> list[Any]:
    """All recorded ``exec`` calls, in order, for the given mock environment."""
    return list(mock_env.exec.call_args_list)


def exec_env_of(mock_env: Any, index: int) -> dict[str, Any]:
    """Return the ``env=`` mapping forwarded on the ``index``-th ``exec`` call.

    ``index`` is a normal Python list index into the recorded calls, so ``-1``
    is the last call and ``0`` is the first. Returns an empty dict if that call
    passed no ``env`` keyword. Raises IndexError if there is no such call (an
    adapter that never reached its launch ``exec`` is a real failure to surface,
    not something to paper over).
    """
    call = mock_env.exec.call_args_list[index]
    env = call.kwargs.get("env")
    return dict(env) if env else {}


def forwarded_values(mock_env: Any) -> list[str]:
    """Return every string value forwarded in any recorded ``exec`` call's env.

    Flattens the ``env`` mappings of all recorded ``exec`` calls into a single
    list of the string values they carried, in call order. This is deliberately
    name-agnostic: different adapters expose the same resolved credential under
    different variable names (and some wrap it, e.g. ``NAME=provider=<value>``),
    so a breadth check that cares only "did this value reach the subprocess at
    all" reads the values rather than guessing a key. Carries no provider
    knowledge.
    """
    values: list[str] = []
    for call in mock_env.exec.call_args_list:
        env = call.kwargs.get("env") or {}
        for value in env.values():
            if isinstance(value, str):
                values.append(value)
    return values


def first_exec_env_with(mock_env: Any, *keys: str) -> dict[str, Any]:
    """Return the ``env`` mapping of the first recorded ``exec`` call that
    carried every one of ``keys``.

    Useful when an adapter fires more than one ``exec`` (e.g. a separate
    skills-registration call, or a cleanup call in a ``finally``) and only the
    launch call carries the resolved provider environment. Raises AssertionError
    if no recorded call carried all of ``keys`` (so a missing credential is a
    real, visible failure rather than a silently-empty dict).
    """
    for call in mock_env.exec.call_args_list:
        env = call.kwargs.get("env") or {}
        if all(k in env for k in keys):
            return dict(env)
    raise AssertionError(
        f"no exec call forwarded all of {keys!r}; "
        f"recorded {len(mock_env.exec.call_args_list)} exec call(s)"
    )
