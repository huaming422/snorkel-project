## Task

Our installed-agent adapters each shell out to an external agent CLI, and before they do, each one works out which API key and endpoint environment variables the configured provider and model need, then reads those values. That resolution logic has been copied from adapter to adapter and drifted, so the adapters now disagree on how they find credentials. Several of them only consult the ambient process environment, so a value set for a single run gets silently dropped.

I'd like to pull all of this together. Every installed agent should resolve and forward its model credentials and endpoints through one shared, consistent path, instead of each adapter carrying its own copy of the detection. The shape of that path is yours to design; what matters is that there is one of it and every adapter goes through it.

The one cross-cutting behavior I want to even out while we are in here is how a per-run environment override is handled, so it works the same for every installed agent rather than only the ones that respect it today.

## User stories / requirements

- When a credential is supplied for a single run, the agent uses that value even if the same variable is also set in the ambient environment. A per-run value left intentionally blank stays blank rather than falling back to the ambient one.
- When a model endpoint is configured explicitly, the agent passes that endpoint through to the model exactly as given, in preference to any built-in default and in preference to a different value present in the ambient environment.
- When a model is configured to route through a deployment-specific path that has no single upstream provider behind it, the agent reports no guessed provider for that model.
- When a self-hosted, OpenAI-compatible model is configured, the agent forwards its key and makes the configured endpoint available to the model through the conventional OpenAI environment variables.
- For a provider the adapter already supports, with that provider's credential available, the agent still forwards the credential to the model the way it does today, across the installed adapters.
