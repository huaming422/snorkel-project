## Task

Our air-gapped boxes report zero tokens for any text we give them. They run the stock docker image, and ingestion goes through the Go services. Chunk sizes come from those counts, so a document that measures zero is never cut up and comes out as one huge chunk. There's no crash, and the logs don't mention it. Give the same image a network connection and the numbers come out right. Developers who work offline from a checkout get the same zeros.

If a box can't count at all, we don't hear about that either. The first sign is a document that didn't get split.

The boxes are offline for good, so counting must work without any network calls while the server runs. We need correct token counts in both places, and a box that can't count needs to say so.
