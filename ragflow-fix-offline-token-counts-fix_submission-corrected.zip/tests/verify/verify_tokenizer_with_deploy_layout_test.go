//
//  Copyright 2026 The InfiniFlow Authors. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

// These tests count tokens in a separate server-like process, the way an
// installed binary runs: a small program that starts the logger and the
// tokenizer the way cmd/ragflow_server.go does and then calls
// NumTokensFromString. It's built in a temporary copy of the packages it
// imports, and the copy is removed before the program runs, so the source
// paths the binary records don't exist any more, as with a binary built on
// another machine. The program sits at <install root>/bin/ragflow_server and
// runs with the install root as its working directory. The install root is
// /ragflow where this process can create it, and a temporary directory
// otherwise. While it runs, every copy of the cl100k table inside this
// checkout is moved aside, so the process sees only the files a case lays out
// for it. HTTP_PROXY and HTTPS_PROXY point at a local listener that records
// every connection and answers none.
//
// The install root is laid out from this checkout's container files: the
// steps of Dockerfile_base and Dockerfile that name the table, the lines this
// checkout adds to docker/entrypoint.sh that name it, and the variables it
// adds through those files, docker/.env, the docker compose files or the helm
// chart. /ragflow in any of them reads as the install root.

package tokenizer

import (
	"bytes"
	"crypto/sha1"
	"encoding/json"
	"fmt"
	"io"
	"io/fs"
	"net"
	"os"
	"os/exec"
	"path"
	"path/filepath"
	"regexp"
	"runtime"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

const verifyDeployTableURL = "https://openaipublic.blob.core.windows.net/encodings/cl100k_base.tiktoken"

// Exact cl100k_base counts, the same values Python's tiktoken gives.
var verifyDeployInputs = []struct {
	in   string
	want int
}{
	{"hello world", 2},
	{"hello, world!", 4},
	{"Hello 世界 🌍", 8},
	{"https://example.com/path?x=1", 9},
	{"人工智能正在改变世界，这是毫无疑问的事实。", 25},
	{"The quick brown fox jumps over the lazy dog.", 10},
}

const verifyDeployChildMain = `package main

import (
	"encoding/json"
	"fmt"
	"os"

	"ragflow/internal/common"
	"ragflow/internal/tokenizer"
)

func main() {
	_ = common.InitLogger("info", common.FileOutput{}, "ingestor_server")
	// The server stops on this error. Built without cgo, the analyzer always
	// returns one, so the program writes it and goes on.
	if err := tokenizer.Init(&tokenizer.PoolConfig{}); err != nil {
		fmt.Fprintln(os.Stderr, "tokenizer init:", err)
	}
	var inputs []string
	_ = json.Unmarshal([]byte(os.Getenv("VERIFY_DEPLOY_INPUTS")), &inputs)
	counts := make([]int, len(inputs))
	for i, s := range inputs {
		counts[i] = tokenizer.NumTokensFromString(s)
	}
	data, _ := json.Marshal(counts)
	_ = os.WriteFile(os.Getenv("VERIFY_DEPLOY_RESULT"), data, 0o644)
	common.SyncLog()
}
`

var verifyDeployBuild struct {
	sync.Once
	binary string
	table  []byte
	module string
	err    error
}

// verifyDeployModuleRoot walks up from the package directory to go.mod.
func verifyDeployModuleRoot() (string, error) {
	dir, err := os.Getwd()
	if err != nil {
		return "", err
	}
	for {
		if _, err := os.Stat(filepath.Join(dir, "go.mod")); err == nil {
			return dir, nil
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			return "", fmt.Errorf("no go.mod above the package directory")
		}
		dir = parent
	}
}

type verifyDeployPackage struct {
	Dir        string
	EmbedFiles []string
	Module     *struct{ Main bool }
}

// verifyDeployCopySources copies go.mod, go.sum and every package of this
// module that the program imports, with the files they embed, into dst.
func verifyDeployCopySources(goTool, module, dst string) error {
	cmd := exec.Command(goTool, "list", "-deps", "-json", "ragflow/internal/common", "ragflow/internal/tokenizer")
	cmd.Dir = module
	var stderr strings.Builder
	cmd.Stderr = &stderr
	listed, err := cmd.Output()
	if err != nil {
		return fmt.Errorf("go list failed: %v\n%s", err, stderr.String())
	}
	realModule, err := filepath.EvalSymlinks(module)
	if err != nil {
		realModule = module
	}
	copyFile := func(rel string) error {
		data, err := os.ReadFile(filepath.Join(module, rel))
		if err != nil {
			return err
		}
		target := filepath.Join(dst, rel)
		if err := os.MkdirAll(filepath.Dir(target), 0o755); err != nil {
			return err
		}
		return os.WriteFile(target, data, 0o644)
	}
	if err := copyFile("go.mod"); err != nil {
		return err
	}
	if err := copyFile("go.sum"); err != nil && !os.IsNotExist(err) {
		return err
	}
	dec := json.NewDecoder(bytes.NewReader(listed))
	for {
		var p verifyDeployPackage
		if err := dec.Decode(&p); err == io.EOF {
			break
		} else if err != nil {
			return fmt.Errorf("reading go list output: %v", err)
		}
		if p.Module == nil || !p.Module.Main {
			continue
		}
		dir := p.Dir
		if resolved, err := filepath.EvalSymlinks(dir); err == nil {
			dir = resolved
		}
		rel, err := filepath.Rel(realModule, dir)
		if err != nil || rel == ".." || strings.HasPrefix(rel, ".."+string(filepath.Separator)) {
			return fmt.Errorf("package directory %s is outside the module", p.Dir)
		}
		entries, err := os.ReadDir(p.Dir)
		if err != nil {
			return err
		}
		for _, e := range entries {
			if e.Type().IsRegular() {
				if err := copyFile(filepath.Join(rel, e.Name())); err != nil {
					return err
				}
			}
		}
		for _, f := range p.EmbedFiles {
			if err := copyFile(filepath.Join(rel, filepath.FromSlash(f))); err != nil {
				return err
			}
		}
	}
	return nil
}

// verifyDeployPrepare builds the program once and keeps the table's bytes,
// read from ragflow_deps/cl100k_base.tiktoken in this checkout.
func verifyDeployPrepare(t *testing.T) (binary string, table []byte) {
	t.Helper()
	verifyDeployBuild.Do(func() {
		b := &verifyDeployBuild
		b.module, b.err = verifyDeployModuleRoot()
		if b.err != nil {
			return
		}
		verifyDeployRestoreHidden(b.module)
		b.table, b.err = os.ReadFile(filepath.Join(b.module, "ragflow_deps", "cl100k_base.tiktoken"))
		if b.err != nil {
			return
		}
		goTool := filepath.Join(runtime.GOROOT(), "bin", "go")
		if _, err := os.Stat(goTool); err != nil {
			goTool = "go"
		}
		src, err := os.MkdirTemp("", "verifydeploysrc")
		if err != nil {
			b.err = err
			return
		}
		defer os.RemoveAll(src)
		if err := verifyDeployCopySources(goTool, b.module, src); err != nil {
			b.err = fmt.Errorf("copying the packages the program needs failed: %v", err)
			return
		}
		child := filepath.Join(src, "verifydeploychild")
		if err := os.MkdirAll(child, 0o755); err != nil {
			b.err = err
			return
		}
		if err := os.WriteFile(filepath.Join(child, "main.go"), []byte(verifyDeployChildMain), 0o644); err != nil {
			b.err = err
			return
		}
		out, err := os.MkdirTemp("", "verifydeploybin")
		if err != nil {
			b.err = err
			return
		}
		b.binary = filepath.Join(out, "ragflow_server")
		cmd := exec.Command(goTool, "build", "-o", b.binary, "./verifydeploychild")
		cmd.Dir = src
		if msg, err := cmd.CombinedOutput(); err != nil {
			b.err = fmt.Errorf("building the server-like program failed: %v\n%s", err, msg)
		}
	})
	if verifyDeployBuild.err != nil {
		t.Fatalf("%v", verifyDeployBuild.err)
	}
	return verifyDeployBuild.binary, verifyDeployBuild.table
}

const (
	verifyDeployHiddenSuffix = ".verify-hidden"
	verifyDeployFixedRoot    = "/ragflow"
)

func verifyDeployCacheName() string {
	return fmt.Sprintf("%x", sha1.Sum([]byte(verifyDeployTableURL)))
}

func verifyDeployIsTableName(name string) bool {
	return name == "cl100k_base.tiktoken" || name == verifyDeployCacheName()
}

// verifyDeployNamesTable says whether a line of a container file is about the
// table.
func verifyDeployNamesTable(s string) bool {
	return strings.Contains(s, ".tiktoken") || strings.Contains(s, verifyDeployCacheName())
}

// verifyDeployRestoreHidden puts back anything an interrupted run left aside.
func verifyDeployRestoreHidden(module string) {
	aside := verifyDeployFixedRoot + verifyDeployHiddenSuffix
	if _, err := os.Lstat(aside); err == nil {
		if _, err := os.Lstat(verifyDeployFixedRoot); os.IsNotExist(err) {
			_ = os.Rename(aside, verifyDeployFixedRoot)
		}
	}
	_ = filepath.WalkDir(module, func(p string, d fs.DirEntry, err error) error {
		if err != nil {
			return nil
		}
		if d.IsDir() && (d.Name() == ".git" || d.Name() == "node_modules" || d.Name() == "web") {
			return filepath.SkipDir
		}
		if !d.IsDir() && strings.HasSuffix(p, verifyDeployHiddenSuffix) && verifyDeployIsTableName(strings.TrimSuffix(d.Name(), verifyDeployHiddenSuffix)) {
			orig := strings.TrimSuffix(p, verifyDeployHiddenSuffix)
			if _, err := os.Stat(orig); os.IsNotExist(err) {
				_ = os.Rename(p, orig)
			}
		}
		return nil
	})
}

// verifyDeployHideTables moves every copy of the table inside the checkout
// aside until the test ends.
func verifyDeployHideTables(t *testing.T, module string) {
	t.Helper()
	var moved []string
	_ = filepath.WalkDir(module, func(p string, d fs.DirEntry, err error) error {
		if err != nil {
			return nil
		}
		if d.IsDir() && (d.Name() == ".git" || d.Name() == "node_modules" || d.Name() == "web") {
			return filepath.SkipDir
		}
		if !d.IsDir() && verifyDeployIsTableName(d.Name()) {
			if err := os.Rename(p, p+verifyDeployHiddenSuffix); err == nil {
				moved = append(moved, p)
			}
		}
		return nil
	})
	t.Cleanup(func() {
		for _, p := range moved {
			_ = os.Rename(p+verifyDeployHiddenSuffix, p)
		}
	})
}

var verifyDeployRootState struct {
	owned bool
	aside bool
}

// verifyDeployClaimRoot returns an empty install root: /ragflow when this
// process can create it, with anything already there moved aside until the
// test ends, and a temporary directory otherwise.
func verifyDeployClaimRoot(t *testing.T) string {
	t.Helper()
	s := &verifyDeployRootState
	aside := verifyDeployFixedRoot + verifyDeployHiddenSuffix
	if s.owned {
		if err := os.RemoveAll(verifyDeployFixedRoot); err != nil {
			t.Fatalf("clearing the install root: %v", err)
		}
		s.owned = false
	} else if _, err := os.Lstat(verifyDeployFixedRoot); err == nil {
		if err := os.Rename(verifyDeployFixedRoot, aside); err != nil {
			return t.TempDir()
		}
		s.aside = true
	}
	if err := os.Mkdir(verifyDeployFixedRoot, 0o755); err != nil {
		return t.TempDir()
	}
	s.owned = true
	t.Cleanup(func() {
		if s.owned {
			_ = os.RemoveAll(verifyDeployFixedRoot)
			s.owned = false
		}
		if s.aside {
			_ = os.Rename(aside, verifyDeployFixedRoot)
			s.aside = false
		}
	})
	return verifyDeployFixedRoot
}

// verifyDeployStartCommit names the commit this checkout started from.
func verifyDeployStartCommit() string {
	if data, err := os.ReadFile("/var/lib/devcontainer_base_ref"); err == nil && strings.TrimSpace(string(data)) != "" {
		return strings.TrimSpace(string(data))
	}
	return "HEAD"
}

func verifyDeployFileAtStart(module, file string) string {
	cmd := exec.Command("git", "show", verifyDeployStartCommit()+":"+file)
	cmd.Dir = module
	out, _ := cmd.Output()
	return string(out)
}

// verifyDeployDockerLines joins a Dockerfile's continued lines and drops its
// comment lines.
func verifyDeployDockerLines(text string) []string {
	var logical []string
	cur := ""
	for _, line := range strings.Split(strings.ReplaceAll(text, "\r\n", "\n"), "\n") {
		if strings.HasPrefix(strings.TrimSpace(line), "#") {
			continue
		}
		line = strings.TrimRight(line, " \t")
		if strings.HasSuffix(line, `\`) {
			cur += strings.TrimSuffix(line, `\`) + " "
			continue
		}
		logical = append(logical, strings.TrimSpace(cur+line))
		cur = ""
	}
	return append(logical, strings.TrimSpace(cur))
}

var verifyDeployShellSplit = regexp.MustCompile(`&&|;`)

// verifyDeployImageSteps returns the shell steps that put the table into the
// image and start the container with it: in Dockerfile_base and Dockerfile,
// the commands of a RUN that name the table and its mkdirs, and each COPY of
// the table; in docker/entrypoint.sh, the lines this checkout adds when one of
// them names the table.
func verifyDeployImageSteps(module string) []string {
	var steps []string
	for _, f := range []string{"Dockerfile_base", "Dockerfile"} {
		data, err := os.ReadFile(filepath.Join(module, f))
		if err != nil {
			continue
		}
		for _, l := range verifyDeployDockerLines(string(data)) {
			if !verifyDeployNamesTable(l) {
				continue
			}
			fields := strings.Fields(l)
			words := fields[1:]
			for len(words) > 0 && strings.HasPrefix(words[0], "--") {
				words = words[1:]
			}
			switch strings.ToUpper(fields[0]) {
			case "RUN":
				for _, part := range verifyDeployShellSplit.Split(strings.Join(words, " "), -1) {
					part = strings.TrimSpace(part)
					if verifyDeployNamesTable(part) || strings.HasPrefix(part, "mkdir ") {
						steps = append(steps, part)
					}
				}
			case "COPY", "ADD":
				if len(words) < 2 {
					continue
				}
				dest := words[len(words)-1]
				for _, s := range words[:len(words)-1] {
					if !verifyDeployNamesTable(s) {
						continue
					}
					target := dest
					if dest == "." || strings.HasSuffix(dest, "/") {
						target = path.Join(dest, path.Base(s))
					}
					steps = append(steps, "mkdir -p "+verifyDeployQuote(path.Dir(target))+" && cp /deps/cl100k_base.tiktoken "+verifyDeployQuote(target))
				}
			}
		}
	}
	if data, err := os.ReadFile(filepath.Join(module, "docker", "entrypoint.sh")); err == nil {
		had := map[string]int{}
		for _, l := range strings.Split(verifyDeployFileAtStart(module, "docker/entrypoint.sh"), "\n") {
			had[l]++
		}
		var added []string
		named := false
		for _, l := range strings.Split(string(data), "\n") {
			if had[l] > 0 {
				had[l]--
				continue
			}
			added = append(added, l)
			named = named || verifyDeployNamesTable(l)
		}
		if named {
			steps = append(steps, strings.Join(added, "\n"))
		}
	}
	return steps
}

type verifyDeployAssign struct {
	key  string
	word string // the value as a shell word, quotes included
}

var (
	verifyDeployShellAssign = regexp.MustCompile(`(?:^|[\s;&|(])(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)=("(?:[^"\\]|\\.)*"|'[^']*'|[^\s;&|)]*)`)
	verifyDeployEnvLine     = regexp.MustCompile(`^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)=(.*)$`)
	verifyDeployComposeList = regexp.MustCompile(`^-\s*["']?([A-Za-z_][A-Za-z0-9_]*)=(.*?)["']?$`)
	verifyDeployComposeMap  = regexp.MustCompile(`^["']?([A-Z_][A-Z0-9_]*)["']?:\s*(.*)$`)
	verifyDeployK8sName     = regexp.MustCompile(`^-\s*name:\s*["']?([A-Za-z_][A-Za-z0-9_]*)["']?\s*$`)
	verifyDeployK8sValue    = regexp.MustCompile(`^value:\s*(.*)$`)
	verifyDeployInstallPath = regexp.MustCompile(`(^|[:=\s,;"']|//)/ragflow($|[/:\s,;"'])`)
	verifyDeployAbsPath     = regexp.MustCompile(`(?:^|[\s"'=:])(/[^\s"':;]+)`)
)

// verifyDeployQuote makes a literal into a single-quoted shell word.
func verifyDeployQuote(s string) string {
	return "'" + strings.ReplaceAll(s, "'", `'\''`) + "'"
}

// verifyDeployWord keeps a quoted value as it is and puts an unquoted one in
// double quotes, so ${...} still expands.
func verifyDeployWord(v string) string {
	v = strings.TrimSpace(v)
	if len(v) >= 2 && (v[0] == '"' && v[len(v)-1] == '"' || v[0] == '\'' && v[len(v)-1] == '\'') {
		return v
	}
	if i := strings.Index(v, " #"); i >= 0 {
		v = strings.TrimSpace(v[:i])
	}
	r := strings.NewReplacer(`\`, `\\`, `"`, `\"`, "`", "\\`")
	return `"` + r.Replace(v) + `"`
}

// verifyDeployAssignments lists, in order, the variables a file sets.
func verifyDeployAssignments(name, text string) []verifyDeployAssign {
	var out []verifyDeployAssign
	lines := strings.Split(strings.ReplaceAll(text, "\r\n", "\n"), "\n")
	switch {
	case strings.HasPrefix(filepath.Base(name), "Dockerfile"):
		for _, l := range verifyDeployDockerLines(text) {
			fields := strings.Fields(l)
			if len(fields) < 2 || !strings.EqualFold(fields[0], "ENV") {
				continue
			}
			rest := strings.TrimSpace(l[len(fields[0]):])
			first := strings.Fields(rest)
			if strings.Contains(first[0], "=") {
				for _, m := range verifyDeployShellAssign.FindAllStringSubmatch(rest, -1) {
					out = append(out, verifyDeployAssign{m[1], m[2]})
				}
			} else {
				out = append(out, verifyDeployAssign{first[0], verifyDeployWord(strings.TrimSpace(rest[len(first[0]):]))})
			}
		}
	case filepath.Base(name) == ".env":
		for _, line := range lines {
			line = strings.TrimSpace(line)
			if m := verifyDeployEnvLine.FindStringSubmatch(line); m != nil {
				out = append(out, verifyDeployAssign{m[1], verifyDeployWord(m[2])})
			}
		}
	case strings.HasSuffix(name, ".yml") || strings.HasSuffix(name, ".yaml"):
		pending := ""
		for _, line := range lines {
			line = strings.TrimSpace(line)
			if line == "" || strings.HasPrefix(line, "#") {
				continue
			}
			if m := verifyDeployK8sValue.FindStringSubmatch(line); m != nil && pending != "" {
				out = append(out, verifyDeployAssign{pending, verifyDeployWord(m[1])})
				pending = ""
				continue
			}
			pending = ""
			if m := verifyDeployK8sName.FindStringSubmatch(line); m != nil {
				pending = m[1]
			} else if m := verifyDeployComposeList.FindStringSubmatch(line); m != nil {
				out = append(out, verifyDeployAssign{m[1], verifyDeployWord(m[2])})
			} else if m := verifyDeployComposeMap.FindStringSubmatch(line); m != nil {
				out = append(out, verifyDeployAssign{m[1], verifyDeployWord(m[2])})
			}
		}
	default:
		for _, line := range lines {
			if strings.HasPrefix(strings.TrimSpace(line), "#") {
				continue
			}
			for _, m := range verifyDeployShellAssign.FindAllStringSubmatch(line, -1) {
				out = append(out, verifyDeployAssign{m[1], m[2]})
			}
		}
	}
	return out
}

// verifyDeployAddedAssignments returns the assignments in this checkout's
// container files that its starting commit doesn't have, in the order the
// container applies them.
func verifyDeployAddedAssignments(module string) []verifyDeployAssign {
	files := []string{"Dockerfile_base", "Dockerfile", "docker/.env"}
	compose, _ := filepath.Glob(filepath.Join(module, "docker", "docker-compose*.y*ml"))
	sort.Strings(compose)
	chart, _ := filepath.Glob(filepath.Join(module, "helm", "templates", "*.y*ml"))
	sort.Strings(chart)
	compose = append(compose, filepath.Join(module, "helm", "values.yaml"))
	compose = append(compose, chart...)
	for _, c := range compose {
		rel, _ := filepath.Rel(module, c)
		files = append(files, filepath.ToSlash(rel))
	}
	files = append(files, "docker/entrypoint.sh")

	var added []verifyDeployAssign
	for _, f := range files {
		now, err := os.ReadFile(filepath.Join(module, filepath.FromSlash(f)))
		if err != nil {
			continue
		}
		had := map[verifyDeployAssign]int{}
		for _, a := range verifyDeployAssignments(f, verifyDeployFileAtStart(module, f)) {
			had[a]++
		}
		for _, a := range verifyDeployAssignments(f, string(now)) {
			if had[a] > 0 {
				had[a]--
				continue
			}
			added = append(added, a)
		}
	}
	return added
}

// verifyDeployMapRoot reads /ragflow in s as root.
func verifyDeployMapRoot(s, root string) string {
	repl := "${1}" + strings.ReplaceAll(root, "$", "$$") + "${2}"
	for i := 0; i < 2; i++ {
		s = verifyDeployInstallPath.ReplaceAllString(s, repl)
	}
	return s
}

// verifyDeployImageEnv evaluates the added assignments with bash in the
// install root and returns them as KEY=VALUE pairs.
func verifyDeployImageEnv(t *testing.T, module, root string) []string {
	t.Helper()
	added := verifyDeployAddedAssignments(module)
	if len(added) == 0 {
		return nil
	}
	var script strings.Builder
	var keys []string
	seen := map[string]bool{}
	for _, a := range added {
		script.WriteString("eval " + verifyDeployQuote("export "+a.key+"="+a.word) + " 2>/dev/null\n")
		if !seen[a.key] {
			seen[a.key] = true
			keys = append(keys, a.key)
		}
	}
	for _, k := range keys {
		script.WriteString(fmt.Sprintf("printf '%%s\\0' %s\n", verifyDeployQuote(k)+`="${`+k+`-}"`))
	}
	cmd := exec.Command("bash", "-c", script.String())
	cmd.Dir = root
	cmd.Env = []string{"PATH=" + os.Getenv("PATH"), "HOME=" + filepath.Join(root, "home"), "PWD=" + root}
	out, err := cmd.Output()
	if err != nil {
		t.Logf("evaluating the container's added variables: %v", err)
	}
	var env []string
	for _, kv := range strings.Split(string(out), "\x00") {
		key, value, ok := strings.Cut(kv, "=")
		if !ok {
			continue
		}
		switch strings.ToUpper(key) {
		case "HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY", "PATH", "VERIFY_DEPLOY_INPUTS", "VERIFY_DEPLOY_RESULT":
			continue
		}
		env = append(env, key+"="+verifyDeployMapRoot(value, root))
	}
	return env
}

// verifyDeployOutsidePaths lists the absolute paths outside the install root
// that the steps name, the places a step may have left a copy of the table.
func verifyDeployOutsidePaths(steps []string, root string) []string {
	var out []string
	for _, s := range steps {
		for _, m := range verifyDeployAbsPath.FindAllStringSubmatch(s, -1) {
			p := m[1]
			if p == verifyDeployFixedRoot || strings.HasPrefix(p, verifyDeployFixedRoot+"/") || p == root || strings.HasPrefix(p, root+"/") || p == "/deps" || strings.HasPrefix(p, "/deps/") {
				continue
			}
			out = append(out, p, filepath.Join(p, "cl100k_base.tiktoken"), filepath.Join(p, verifyDeployCacheName()))
		}
	}
	return out
}

// verifyDeployPlacedCopies returns the files under root, and at the given
// outside paths, that hold exactly the table.
func verifyDeployPlacedCopies(root string, outside []string, table []byte) []string {
	var found []string
	check := func(p string) {
		info, err := os.Lstat(p)
		if err != nil || !info.Mode().IsRegular() || info.Size() != int64(len(table)) {
			return
		}
		if data, err := os.ReadFile(p); err == nil && bytes.Equal(data, table) {
			found = append(found, p)
		}
	}
	_ = filepath.WalkDir(root, func(p string, d fs.DirEntry, err error) error {
		if err == nil && !d.IsDir() {
			check(p)
		}
		return nil
	})
	for _, p := range outside {
		check(p)
	}
	return found
}

// verifyDeployDamage leaves a copy of the table in the given unusable state.
func verifyDeployDamage(t *testing.T, p, state string, table []byte) {
	t.Helper()
	lineStart := len(table)/2 + bytes.IndexByte(table[len(table)/2:], '\n') + 1
	var content []byte
	switch state {
	case "garbage":
		content = []byte("this file holds no token table\n")
	case "truncated":
		content = table[:lineStart+3] // ends inside a token
	case "cut-between-lines":
		content = table[:lineStart]
	case "empty":
	case "directory":
		if err := os.Remove(p); err != nil {
			t.Fatalf("remove table: %v", err)
		}
		if err := os.Mkdir(p, 0o755); err != nil {
			t.Fatalf("mkdir in the table's place: %v", err)
		}
		return
	default:
		t.Fatalf("unknown table state %q", state)
	}
	if err := os.WriteFile(p, content, 0o644); err != nil {
		t.Fatalf("damage table: %v", err)
	}
}

// verifyDeployListener accepts connections on 127.0.0.1 and closes each one
// at once, counting them.
type verifyDeployListener struct {
	ln    net.Listener
	count atomic.Int64
}

func verifyDeployListen(t *testing.T) *verifyDeployListener {
	t.Helper()
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("listen: %v", err)
	}
	l := &verifyDeployListener{ln: ln}
	go func() {
		for {
			c, err := ln.Accept()
			if err != nil {
				return
			}
			l.count.Add(1)
			_ = c.Close()
		}
	}()
	t.Cleanup(func() { _ = ln.Close() })
	return l
}

type verifyDeployRun struct {
	counts   []int
	output   string
	exitErr  error
	requests int64
	dirs     []string
}

// verifyDeployStart lays out an install root and runs the program there.
// table says what the layout holds: "root" is the table where the container
// files put it, "cachedir" is the table only at <TIKTOKEN_CACHE_DIR>/<sha1 of
// its URL>, "none" is no table, and any other value is the table where the
// container files put it, damaged as verifyDeployDamage says. TIKTOKEN_CACHE_DIR
// for "cachedir" is set after the variables the container files add.
func verifyDeployStart(t *testing.T, table string) verifyDeployRun {
	t.Helper()
	binary, data := verifyDeployPrepare(t)
	module := verifyDeployBuild.module
	verifyDeployHideTables(t, module)

	root := verifyDeployClaimRoot(t)
	scratch := t.TempDir()
	for _, d := range []string{"bin", "tmp", "home"} {
		if err := os.MkdirAll(filepath.Join(root, d), 0o755); err != nil {
			t.Fatalf("mkdir: %v", err)
		}
	}
	exe := filepath.Join(root, "bin", "ragflow_server")
	bin, err := os.ReadFile(binary)
	if err != nil {
		t.Fatalf("read program: %v", err)
	}
	if err := os.WriteFile(exe, bin, 0o755); err != nil {
		t.Fatalf("copy program: %v", err)
	}

	proxy := verifyDeployListen(t)
	proxyURL := "http://" + proxy.ln.Addr().String()
	inputs := make([]string, len(verifyDeployInputs))
	for i, c := range verifyDeployInputs {
		inputs[i] = c.in
	}
	encoded, _ := json.Marshal(inputs)
	result := filepath.Join(scratch, "counts.json")

	var env []string
	for _, kv := range os.Environ() {
		key := strings.ToUpper(strings.SplitN(kv, "=", 2)[0])
		switch key {
		case "TIKTOKEN_CACHE_DIR", "DATA_GYM_CACHE_DIR", "HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY",
			"TMPDIR", "HOME", "XDG_CACHE_HOME", "RAG_PROJECT_BASE", "RAG_DEPLOY_BASE", "RAGFLOW_CONF_DIR", "REQUEST_METHOD":
			continue
		}
		env = append(env, kv)
	}
	env = append(env,
		"HTTP_PROXY="+proxyURL, "HTTPS_PROXY="+proxyURL, "http_proxy="+proxyURL, "https_proxy="+proxyURL,
		"NO_PROXY=", "no_proxy=",
		"TMPDIR="+filepath.Join(root, "tmp"), "HOME="+filepath.Join(root, "home"),
		"VERIFY_DEPLOY_INPUTS="+string(encoded), "VERIFY_DEPLOY_RESULT="+result,
	)
	env = append(env, verifyDeployImageEnv(t, module, root)...)

	steps := verifyDeployImageSteps(module)
	outside := verifyDeployOutsidePaths(steps, root)
	removeOutside := func() {
		for _, p := range outside {
			if verifyDeployIsTableName(filepath.Base(p)) {
				if info, err := os.Lstat(p); err == nil && !info.IsDir() {
					_ = os.Remove(p)
				}
			}
		}
	}
	removeOutside()
	t.Cleanup(removeOutside)

	deps := filepath.Join(scratch, "deps")
	if err := os.MkdirAll(deps, 0o755); err != nil {
		t.Fatalf("mkdir: %v", err)
	}
	holdsTable := table != "none" && table != "cachedir"
	if holdsTable {
		if err := os.WriteFile(filepath.Join(deps, "cl100k_base.tiktoken"), data, 0o644); err != nil {
			t.Fatalf("write table: %v", err)
		}
	}
	for _, step := range steps {
		s := strings.ReplaceAll(verifyDeployMapRoot(step, root), "/deps/", deps+"/")
		cmd := exec.Command("bash", "-c", s)
		cmd.Dir = root
		cmd.Env = env
		if out, err := cmd.CombinedOutput(); err != nil && holdsTable {
			t.Logf("container step %q: %v: %s", s, err, verifyDeployTail(string(out)))
		}
	}
	if holdsTable {
		copies := verifyDeployPlacedCopies(root, outside, data)
		if len(copies) == 0 {
			fallback := filepath.Join(root, verifyDeployCacheName())
			if err := os.WriteFile(fallback, data, 0o644); err != nil {
				t.Fatalf("write table: %v", err)
			}
			copies = []string{fallback}
		}
		if table != "root" {
			for _, p := range copies {
				verifyDeployDamage(t, p, table, data)
			}
		}
	}
	if table == "cachedir" {
		cacheDir := filepath.Join(scratch, "tiktoken-cache")
		if err := os.MkdirAll(cacheDir, 0o755); err != nil {
			t.Fatalf("mkdir: %v", err)
		}
		if err := os.WriteFile(filepath.Join(cacheDir, verifyDeployCacheName()), data, 0o644); err != nil {
			t.Fatalf("write table: %v", err)
		}
		env = append(env, "TIKTOKEN_CACHE_DIR="+cacheDir)
	}

	cmd := exec.Command(exe)
	cmd.Dir = root
	cmd.Env = env
	var out strings.Builder
	cmd.Stdout = &out
	cmd.Stderr = &out
	if err := cmd.Start(); err != nil {
		t.Fatalf("start program: %v", err)
	}
	done := make(chan error, 1)
	go func() { done <- cmd.Wait() }()
	run := verifyDeployRun{dirs: []string{root, scratch}}
	for _, d := range []string{root, scratch} {
		if resolved, err := filepath.EvalSymlinks(d); err == nil && resolved != d {
			run.dirs = append(run.dirs, resolved)
		}
	}
	select {
	case run.exitErr = <-done:
	case <-time.After(90 * time.Second):
		_ = cmd.Process.Kill()
		<-done
		t.Fatalf("the program didn't finish counting within 90s; output:\n%s", out.String())
	}
	run.output = out.String()
	run.requests = proxy.count.Load()
	if data, err := os.ReadFile(result); err == nil {
		_ = json.Unmarshal(data, &run.counts)
	}
	return run
}

func verifyDeployWrongCounts(run verifyDeployRun) []string {
	var wrong []string
	for i, c := range verifyDeployInputs {
		got := -1
		if i < len(run.counts) {
			got = run.counts[i]
		}
		if got != c.want {
			wrong = append(wrong, fmt.Sprintf("%q = %d, want %d", c.in, got, c.want))
		}
	}
	return wrong
}

func verifyDeployTail(s string) string {
	s = strings.TrimSpace(s)
	if len(s) > 300 {
		s = "..." + s[len(s)-300:]
	}
	if s == "" {
		return "(no output)"
	}
	return s
}

var verifyDeployDigits = regexp.MustCompile(`[0-9]+`)

// verifyDeployLines returns a run's output lines with its own directories
// and every number replaced, so two runs' lines can be compared.
func verifyDeployLines(run verifyDeployRun) map[string]bool {
	s := run.output
	dirs := append([]string(nil), run.dirs...)
	sort.Slice(dirs, func(i, j int) bool { return len(dirs[i]) > len(dirs[j]) })
	for _, d := range dirs {
		s = strings.ReplaceAll(s, d, "<dir>")
	}
	lines := map[string]bool{}
	for _, line := range strings.Split(s, "\n") {
		line = strings.TrimSpace(verifyDeployDigits.ReplaceAllString(line, "0"))
		if line != "" {
			lines[line] = true
		}
	}
	return lines
}

// verifyDeployCountingRun returns a run that counts right with a good table:
// the layout the container files make, or the cache directory when that one
// doesn't count.
func verifyDeployCountingRun(t *testing.T) (verifyDeployRun, bool) {
	t.Helper()
	for _, table := range []string{"root", "cachedir"} {
		r := verifyDeployStart(t, table)
		if r.exitErr == nil && len(verifyDeployWrongCounts(r)) == 0 {
			return r, true
		}
	}
	return verifyDeployRun{}, false
}

// verifyDeploySaidSo says whether a run that couldn't count differs from the
// counting run: a non-zero exit, or a line of output the counting run doesn't
// write.
func verifyDeploySaidSo(run, counting verifyDeployRun) bool {
	if run.exitErr != nil {
		return true
	}
	seen := verifyDeployLines(counting)
	for line := range verifyDeployLines(run) {
		if !seen[line] {
			return true
		}
	}
	return false
}

// The table is where the container files put it, the binary runs from
// <install root>/bin with the install root as working directory, and no cache
// variable is set beyond what the container files add.
func TestVerifyDeployInstallRootTable(t *testing.T) {
	run := verifyDeployStart(t, "root")
	if run.exitErr != nil {
		t.Fatalf("program exited with %v; output: %s", run.exitErr, verifyDeployTail(run.output))
	}
	if wrong := verifyDeployWrongCounts(run); len(wrong) > 0 {
		t.Errorf("%d of %d counts wrong, the first: %s; output: %s", len(wrong), len(verifyDeployInputs), wrong[0], verifyDeployTail(run.output))
	}
}

// No table anywhere the process can see. Right counts are accepted. Otherwise
// the run has to differ from a run that counts: a non-zero exit, or a line of
// output that run doesn't write.
func TestVerifyDeployMissingTableIsVisible(t *testing.T) {
	run := verifyDeployStart(t, "none")
	if len(verifyDeployWrongCounts(run)) == 0 && run.exitErr == nil {
		return
	}
	counting, ok := verifyDeployCountingRun(t)
	if !ok {
		t.Fatalf("with no table on disk the counts came back %v, and no layout with a good table counted right, so there's no run to hold this one against; output: %s", run.counts, verifyDeployTail(run.output))
	}
	if !verifyDeploySaidSo(run, counting) {
		t.Errorf("with no table on disk the counts came back %v and the process wrote nothing that a run with the table doesn't write too; output: %s", run.counts, verifyDeployTail(run.output))
	}
}

// The table is on disk where the container files put it but can't be used:
// not a table at all, cut off inside a line, empty, a directory in its place
// (reading it fails, whoever the process runs as), or cut off between two
// lines. Right counts are accepted, and otherwise the run has to differ from a
// run that counts. A table cut between lines still parses, so a process that
// counts something from it, no input coming back as zero, is accepted as well.
// No case may open a connection.
func TestVerifyDeployUnusableTableIsVisible(t *testing.T) {
	counting, ok := verifyDeployCountingRun(t)
	for _, state := range []string{"garbage", "truncated", "empty", "directory", "cut-between-lines"} {
		t.Run(state, func(t *testing.T) {
			run := verifyDeployStart(t, state)
			if run.requests != 0 {
				t.Errorf("%d connection(s) reached the proxy; output: %s", run.requests, verifyDeployTail(run.output))
			}
			if len(verifyDeployWrongCounts(run)) == 0 && run.exitErr == nil {
				return
			}
			if !ok {
				t.Fatalf("with an unusable table the counts came back %v, and no layout with a good table counted right, so there's no run to hold this one against; output: %s", run.counts, verifyDeployTail(run.output))
			}
			if verifyDeploySaidSo(run, counting) {
				return
			}
			if state == "cut-between-lines" && len(run.counts) == len(verifyDeployInputs) {
				zero := false
				for _, c := range run.counts {
					zero = zero || c == 0
				}
				if !zero {
					return
				}
			}
			t.Errorf("with an unusable table the counts came back %v and the process wrote nothing that a run with a good table doesn't write too; output: %s", run.counts, verifyDeployTail(run.output))
		})
	}
}

// None of these layouts may open a connection.
func TestVerifyDeployNoOutboundConnection(t *testing.T) {
	for _, table := range []string{"root", "cachedir", "none"} {
		t.Run(table, func(t *testing.T) {
			run := verifyDeployStart(t, table)
			if run.requests != 0 {
				t.Errorf("%d connection(s) reached the proxy; output: %s", run.requests, verifyDeployTail(run.output))
			}
		})
	}
}
