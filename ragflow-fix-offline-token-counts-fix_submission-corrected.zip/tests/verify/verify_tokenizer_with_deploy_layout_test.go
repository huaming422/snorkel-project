//
//  Copyright 2026 The InfiniFlow Authors. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

// These tests count tokens in a separate server-like process, the way an
// installed binary runs: a small program that starts the logger the way
// cmd/ragflow_server.go does and then calls NumTokensFromString. It's built
// in a temporary copy of the packages it imports, and the copy is removed
// before the program runs, so the source paths the binary records don't exist
// any more, as with a binary built on another machine. The program is copied
// to <install root>/bin/ragflow_server and started with the install root as
// its working directory. While it runs, every copy of the cl100k table inside
// this checkout is moved aside, so the process sees only the files a case lays
// out for it. HTTP_PROXY and HTTPS_PROXY point at a local listener that
// records every connection and answers none.
//
// The process also gets the variables this checkout adds to the container's
// environment through Dockerfile_base, Dockerfile, docker/.env, the docker
// compose files, the helm chart or docker/entrypoint.sh, with /ragflow read as
// the install root.

package tokenizer

import (
	"bytes"
	"crypto/sha1"
	"encoding/json"
	"fmt"
	"io"
	"io/fs"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

const verifyDeployTableURL = "https://openaipublic.blob.core.windows.net/encodings/cl100k_base.tiktoken"

// Exact cl100k_base counts, the same values Python's tiktoken gives.
var verifyDeployInputs = []struct {
	in   string
	want int
}{
	{"hello world", 2},
	{"hello, world!", 4},
	{"Hello 世界 🌍", 8},
	{"https://example.com/path?x=1", 9},
	{"人工智能正在改变世界，这是毫无疑问的事实。", 25},
	{"The quick brown fox jumps over the lazy dog.", 10},
}

const verifyDeployChildMain = `package main

import (
	"encoding/json"
	"os"

	"ragflow/internal/common"
	"ragflow/internal/tokenizer"
)

func main() {
	_ = common.InitLogger("info", common.FileOutput{}, "ingestor_server")
	var inputs []string
	_ = json.Unmarshal([]byte(os.Getenv("VERIFY_DEPLOY_INPUTS")), &inputs)
	counts := make([]int, len(inputs))
	for i, s := range inputs {
		counts[i] = tokenizer.NumTokensFromString(s)
	}
	data, _ := json.Marshal(counts)
	_ = os.WriteFile(os.Getenv("VERIFY_DEPLOY_RESULT"), data, 0o644)
	common.SyncLog()
}
`

var verifyDeployBuild struct {
	sync.Once
	binary string
	table  []byte
	module string
	err    error
}

// verifyDeployModuleRoot walks up from the package directory to go.mod.
func verifyDeployModuleRoot() (string, error) {
	dir, err := os.Getwd()
	if err != nil {
		return "", err
	}
	for {
		if _, err := os.Stat(filepath.Join(dir, "go.mod")); err == nil {
			return dir, nil
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			return "", fmt.Errorf("no go.mod above the package directory")
		}
		dir = parent
	}
}

type verifyDeployPackage struct {
	Dir        string
	EmbedFiles []string
	Module     *struct{ Main bool }
}

// verifyDeployCopySources copies go.mod, go.sum and every package of this
// module that the program imports, with the files they embed, into dst.
func verifyDeployCopySources(goTool, module, dst string) error {
	cmd := exec.Command(goTool, "list", "-deps", "-json", "ragflow/internal/common", "ragflow/internal/tokenizer")
	cmd.Dir = module
	var stderr strings.Builder
	cmd.Stderr = &stderr
	listed, err := cmd.Output()
	if err != nil {
		return fmt.Errorf("go list failed: %v\n%s", err, stderr.String())
	}
	realModule, err := filepath.EvalSymlinks(module)
	if err != nil {
		realModule = module
	}
	copyFile := func(rel string) error {
		data, err := os.ReadFile(filepath.Join(module, rel))
		if err != nil {
			return err
		}
		target := filepath.Join(dst, rel)
		if err := os.MkdirAll(filepath.Dir(target), 0o755); err != nil {
			return err
		}
		return os.WriteFile(target, data, 0o644)
	}
	if err := copyFile("go.mod"); err != nil {
		return err
	}
	if err := copyFile("go.sum"); err != nil && !os.IsNotExist(err) {
		return err
	}
	dec := json.NewDecoder(bytes.NewReader(listed))
	for {
		var p verifyDeployPackage
		if err := dec.Decode(&p); err == io.EOF {
			break
		} else if err != nil {
			return fmt.Errorf("reading go list output: %v", err)
		}
		if p.Module == nil || !p.Module.Main {
			continue
		}
		dir := p.Dir
		if resolved, err := filepath.EvalSymlinks(dir); err == nil {
			dir = resolved
		}
		rel, err := filepath.Rel(realModule, dir)
		if err != nil || rel == ".." || strings.HasPrefix(rel, ".."+string(filepath.Separator)) {
			return fmt.Errorf("package directory %s is outside the module", p.Dir)
		}
		entries, err := os.ReadDir(p.Dir)
		if err != nil {
			return err
		}
		for _, e := range entries {
			if e.Type().IsRegular() {
				if err := copyFile(filepath.Join(rel, e.Name())); err != nil {
					return err
				}
			}
		}
		for _, f := range p.EmbedFiles {
			if err := copyFile(filepath.Join(rel, filepath.FromSlash(f))); err != nil {
				return err
			}
		}
	}
	return nil
}

// verifyDeployPrepare builds the program once and keeps the table's bytes,
// read from ragflow_deps/cl100k_base.tiktoken in this checkout.
func verifyDeployPrepare(t *testing.T) (binary string, table []byte) {
	t.Helper()
	verifyDeployBuild.Do(func() {
		b := &verifyDeployBuild
		b.module, b.err = verifyDeployModuleRoot()
		if b.err != nil {
			return
		}
		verifyDeployRestoreHidden(b.module)
		b.table, b.err = os.ReadFile(filepath.Join(b.module, "ragflow_deps", "cl100k_base.tiktoken"))
		if b.err != nil {
			return
		}
		goTool := filepath.Join(runtime.GOROOT(), "bin", "go")
		if _, err := os.Stat(goTool); err != nil {
			goTool = "go"
		}
		src, err := os.MkdirTemp("", "verifydeploysrc")
		if err != nil {
			b.err = err
			return
		}
		defer os.RemoveAll(src)
		if err := verifyDeployCopySources(goTool, b.module, src); err != nil {
			b.err = fmt.Errorf("copying the packages the program needs failed: %v", err)
			return
		}
		child := filepath.Join(src, "verifydeploychild")
		if err := os.MkdirAll(child, 0o755); err != nil {
			b.err = err
			return
		}
		if err := os.WriteFile(filepath.Join(child, "main.go"), []byte(verifyDeployChildMain), 0o644); err != nil {
			b.err = err
			return
		}
		out, err := os.MkdirTemp("", "verifydeploybin")
		if err != nil {
			b.err = err
			return
		}
		b.binary = filepath.Join(out, "ragflow_server")
		cmd := exec.Command(goTool, "build", "-o", b.binary, "./verifydeploychild")
		cmd.Dir = src
		if msg, err := cmd.CombinedOutput(); err != nil {
			b.err = fmt.Errorf("building the server-like program failed: %v\n%s", err, msg)
		}
	})
	if verifyDeployBuild.err != nil {
		t.Fatalf("%v", verifyDeployBuild.err)
	}
	return verifyDeployBuild.binary, verifyDeployBuild.table
}

const verifyDeployHiddenSuffix = ".verify-hidden"

func verifyDeployIsTableName(name string) bool {
	return name == "cl100k_base.tiktoken" || name == fmt.Sprintf("%x", sha1.Sum([]byte(verifyDeployTableURL)))
}

// verifyDeployRestoreHidden puts back any copy an interrupted run left aside.
func verifyDeployRestoreHidden(module string) {
	_ = filepath.WalkDir(module, func(p string, d fs.DirEntry, err error) error {
		if err != nil {
			return nil
		}
		if d.IsDir() && (d.Name() == ".git" || d.Name() == "node_modules" || d.Name() == "web") {
			return filepath.SkipDir
		}
		if !d.IsDir() && strings.HasSuffix(p, verifyDeployHiddenSuffix) && verifyDeployIsTableName(strings.TrimSuffix(d.Name(), verifyDeployHiddenSuffix)) {
			orig := strings.TrimSuffix(p, verifyDeployHiddenSuffix)
			if _, err := os.Stat(orig); os.IsNotExist(err) {
				_ = os.Rename(p, orig)
			}
		}
		return nil
	})
}

// verifyDeployHideTables moves every copy of the table inside the checkout
// aside until the test ends.
func verifyDeployHideTables(t *testing.T, module string) {
	t.Helper()
	var moved []string
	_ = filepath.WalkDir(module, func(p string, d fs.DirEntry, err error) error {
		if err != nil {
			return nil
		}
		if d.IsDir() && (d.Name() == ".git" || d.Name() == "node_modules" || d.Name() == "web") {
			return filepath.SkipDir
		}
		if !d.IsDir() && verifyDeployIsTableName(d.Name()) {
			if err := os.Rename(p, p+verifyDeployHiddenSuffix); err == nil {
				moved = append(moved, p)
			}
		}
		return nil
	})
	t.Cleanup(func() {
		for _, p := range moved {
			_ = os.Rename(p+verifyDeployHiddenSuffix, p)
		}
	})
}

type verifyDeployAssign struct {
	key  string
	word string // the value as a shell word, quotes included
}

var (
	verifyDeployShellAssign = regexp.MustCompile(`(?:^|[\s;&|(])(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)=("(?:[^"\\]|\\.)*"|'[^']*'|[^\s;&|)]*)`)
	verifyDeployEnvLine     = regexp.MustCompile(`^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)=(.*)$`)
	verifyDeployComposeList = regexp.MustCompile(`^-\s*["']?([A-Za-z_][A-Za-z0-9_]*)=(.*?)["']?$`)
	verifyDeployComposeMap  = regexp.MustCompile(`^["']?([A-Z_][A-Z0-9_]*)["']?:\s*(.*)$`)
	verifyDeployK8sName     = regexp.MustCompile(`^-\s*name:\s*["']?([A-Za-z_][A-Za-z0-9_]*)["']?\s*$`)
	verifyDeployK8sValue    = regexp.MustCompile(`^value:\s*(.*)$`)
	verifyDeployInstallPath = regexp.MustCompile(`(^|[:=\s,;"']|//)/ragflow($|[/:\s,;"'])`)
)

// verifyDeployQuote makes a literal into a single-quoted shell word.
func verifyDeployQuote(s string) string {
	return "'" + strings.ReplaceAll(s, "'", `'\''`) + "'"
}

// verifyDeployWord keeps a quoted value as it is and puts an unquoted one in
// double quotes, so ${...} still expands.
func verifyDeployWord(v string) string {
	v = strings.TrimSpace(v)
	if len(v) >= 2 && (v[0] == '"' && v[len(v)-1] == '"' || v[0] == '\'' && v[len(v)-1] == '\'') {
		return v
	}
	if i := strings.Index(v, " #"); i >= 0 {
		v = strings.TrimSpace(v[:i])
	}
	r := strings.NewReplacer(`\`, `\\`, `"`, `\"`, "`", "\\`")
	return `"` + r.Replace(v) + `"`
}

// verifyDeployAssignments lists, in order, the variables a file sets.
func verifyDeployAssignments(name, text string) []verifyDeployAssign {
	var out []verifyDeployAssign
	lines := strings.Split(strings.ReplaceAll(text, "\r\n", "\n"), "\n")
	switch {
	case strings.HasPrefix(filepath.Base(name), "Dockerfile"):
		var logical []string
		cur := ""
		for _, line := range lines {
			if strings.HasPrefix(strings.TrimSpace(line), "#") {
				continue
			}
			line = strings.TrimRight(line, " \t")
			if strings.HasSuffix(line, `\`) {
				cur += strings.TrimSuffix(line, `\`) + " "
				continue
			}
			logical = append(logical, cur+line)
			cur = ""
		}
		logical = append(logical, cur)
		for _, l := range logical {
			l = strings.TrimSpace(l)
			fields := strings.Fields(l)
			if len(fields) < 2 || !strings.EqualFold(fields[0], "ENV") {
				continue
			}
			rest := strings.TrimSpace(l[len(fields[0]):])
			first := strings.Fields(rest)
			if len(first) == 0 {
				continue
			}
			if strings.Contains(first[0], "=") {
				for _, m := range verifyDeployShellAssign.FindAllStringSubmatch(rest, -1) {
					out = append(out, verifyDeployAssign{m[1], m[2]})
				}
			} else {
				out = append(out, verifyDeployAssign{first[0], verifyDeployWord(strings.TrimSpace(rest[len(first[0]):]))})
			}
		}
	case filepath.Base(name) == ".env":
		for _, line := range lines {
			line = strings.TrimSpace(line)
			if m := verifyDeployEnvLine.FindStringSubmatch(line); m != nil {
				out = append(out, verifyDeployAssign{m[1], verifyDeployWord(m[2])})
			}
		}
	case strings.HasSuffix(name, ".yml") || strings.HasSuffix(name, ".yaml"):
		pending := ""
		for _, line := range lines {
			line = strings.TrimSpace(line)
			if line == "" || strings.HasPrefix(line, "#") {
				continue
			}
			if m := verifyDeployK8sValue.FindStringSubmatch(line); m != nil && pending != "" {
				out = append(out, verifyDeployAssign{pending, verifyDeployWord(m[1])})
				pending = ""
				continue
			}
			pending = ""
			if m := verifyDeployK8sName.FindStringSubmatch(line); m != nil {
				pending = m[1]
			} else if m := verifyDeployComposeList.FindStringSubmatch(line); m != nil {
				out = append(out, verifyDeployAssign{m[1], verifyDeployWord(m[2])})
			} else if m := verifyDeployComposeMap.FindStringSubmatch(line); m != nil {
				out = append(out, verifyDeployAssign{m[1], verifyDeployWord(m[2])})
			}
		}
	default:
		for _, line := range lines {
			if strings.HasPrefix(strings.TrimSpace(line), "#") {
				continue
			}
			for _, m := range verifyDeployShellAssign.FindAllStringSubmatch(line, -1) {
				out = append(out, verifyDeployAssign{m[1], m[2]})
			}
		}
	}
	return out
}

// verifyDeployAddedAssignments returns the assignments in this checkout's
// container files that the starting commit (/var/lib/devcontainer_base_ref,
// or HEAD without it) doesn't have, in the order the container applies them.
func verifyDeployAddedAssignments(module string) []verifyDeployAssign {
	start := "HEAD"
	if data, err := os.ReadFile("/var/lib/devcontainer_base_ref"); err == nil && strings.TrimSpace(string(data)) != "" {
		start = strings.TrimSpace(string(data))
	}
	files := []string{"Dockerfile_base", "Dockerfile", "docker/.env"}
	compose, _ := filepath.Glob(filepath.Join(module, "docker", "docker-compose*.y*ml"))
	sort.Strings(compose)
	chart, _ := filepath.Glob(filepath.Join(module, "helm", "templates", "*.y*ml"))
	sort.Strings(chart)
	compose = append(compose, filepath.Join(module, "helm", "values.yaml"))
	compose = append(compose, chart...)
	for _, c := range compose {
		rel, _ := filepath.Rel(module, c)
		files = append(files, filepath.ToSlash(rel))
	}
	files = append(files, "docker/entrypoint.sh")

	var added []verifyDeployAssign
	for _, f := range files {
		now, err := os.ReadFile(filepath.Join(module, filepath.FromSlash(f)))
		if err != nil {
			continue
		}
		cmd := exec.Command("git", "show", start+":"+f)
		cmd.Dir = module
		before, _ := cmd.Output()
		had := map[verifyDeployAssign]int{}
		for _, a := range verifyDeployAssignments(f, string(before)) {
			had[a]++
		}
		for _, a := range verifyDeployAssignments(f, string(now)) {
			if had[a] > 0 {
				had[a]--
				continue
			}
			added = append(added, a)
		}
	}
	return added
}

// verifyDeployImageEnv evaluates the added assignments with bash in the
// install root and returns KEY=VALUE pairs with /ragflow read as root.
func verifyDeployImageEnv(t *testing.T, module, root string) []string {
	t.Helper()
	added := verifyDeployAddedAssignments(module)
	if len(added) == 0 {
		return nil
	}
	var script strings.Builder
	var keys []string
	seen := map[string]bool{}
	for _, a := range added {
		script.WriteString("eval " + verifyDeployQuote("export "+a.key+"="+a.word) + " 2>/dev/null\n")
		if !seen[a.key] {
			seen[a.key] = true
			keys = append(keys, a.key)
		}
	}
	for _, k := range keys {
		script.WriteString(fmt.Sprintf("printf '%%s\\0' %s\n", verifyDeployQuote(k)+`="${`+k+`-}"`))
	}
	cmd := exec.Command("bash", "-c", script.String())
	cmd.Dir = root
	cmd.Env = []string{"PATH=" + os.Getenv("PATH"), "HOME=" + filepath.Join(root, "home"), "PWD=" + root}
	out, err := cmd.Output()
	if err != nil {
		t.Logf("evaluating the container's added variables: %v", err)
	}
	rootRepl := strings.ReplaceAll(root, "$", "$$")
	var env []string
	for _, kv := range strings.Split(string(out), "\x00") {
		key, value, ok := strings.Cut(kv, "=")
		if !ok {
			continue
		}
		switch strings.ToUpper(key) {
		case "HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY", "PATH", "VERIFY_DEPLOY_INPUTS", "VERIFY_DEPLOY_RESULT":
			continue
		}
		for i := 0; i < 2; i++ {
			value = verifyDeployInstallPath.ReplaceAllString(value, "${1}"+rootRepl+"${2}")
		}
		env = append(env, key+"="+value)
	}
	return env
}

// verifyDeployListener accepts connections on 127.0.0.1 and closes each one
// at once, counting them.
type verifyDeployListener struct {
	ln    net.Listener
	count atomic.Int64
}

func verifyDeployListen(t *testing.T) *verifyDeployListener {
	t.Helper()
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("listen: %v", err)
	}
	l := &verifyDeployListener{ln: ln}
	go func() {
		for {
			c, err := ln.Accept()
			if err != nil {
				return
			}
			l.count.Add(1)
			_ = c.Close()
		}
	}()
	t.Cleanup(func() { _ = ln.Close() })
	return l
}

type verifyDeployRun struct {
	counts   []int
	output   string
	exitErr  error
	requests int64
	dirs     []string
}

// verifyDeployStart lays out an install root, puts the program in its bin/
// directory and runs it there. table places the table: "root" writes it to
// <root>/<sha1 of its URL> (where Dockerfile_base puts it in the image we
// ship), "cachedir" writes it to <TIKTOKEN_CACHE_DIR>/<sha1>, "none" leaves it
// out. The container's added variables apply to all three; TIKTOKEN_CACHE_DIR
// for "cachedir" is set after them.
func verifyDeployStart(t *testing.T, table string) verifyDeployRun {
	t.Helper()
	binary, data := verifyDeployPrepare(t)
	verifyDeployHideTables(t, verifyDeployBuild.module)

	root := t.TempDir()
	scratch := t.TempDir()
	for _, d := range []string{"bin", "tmp", "home"} {
		if err := os.MkdirAll(filepath.Join(root, d), 0o755); err != nil {
			t.Fatalf("mkdir: %v", err)
		}
	}
	exe := filepath.Join(root, "bin", "ragflow_server")
	bin, err := os.ReadFile(binary)
	if err != nil {
		t.Fatalf("read program: %v", err)
	}
	if err := os.WriteFile(exe, bin, 0o755); err != nil {
		t.Fatalf("copy program: %v", err)
	}

	cacheName := fmt.Sprintf("%x", sha1.Sum([]byte(verifyDeployTableURL)))
	cacheDir := ""
	switch table {
	case "root":
		if err := os.WriteFile(filepath.Join(root, cacheName), data, 0o644); err != nil {
			t.Fatalf("write table: %v", err)
		}
	case "cachedir":
		cacheDir = filepath.Join(scratch, "tiktoken-cache")
		if err := os.MkdirAll(cacheDir, 0o755); err != nil {
			t.Fatalf("mkdir: %v", err)
		}
		if err := os.WriteFile(filepath.Join(cacheDir, cacheName), data, 0o644); err != nil {
			t.Fatalf("write table: %v", err)
		}
	}

	proxy := verifyDeployListen(t)
	proxyURL := "http://" + proxy.ln.Addr().String()
	inputs := make([]string, len(verifyDeployInputs))
	for i, c := range verifyDeployInputs {
		inputs[i] = c.in
	}
	encoded, _ := json.Marshal(inputs)
	result := filepath.Join(scratch, "counts.json")

	var env []string
	for _, kv := range os.Environ() {
		key := strings.ToUpper(strings.SplitN(kv, "=", 2)[0])
		switch key {
		case "TIKTOKEN_CACHE_DIR", "DATA_GYM_CACHE_DIR", "HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY",
			"TMPDIR", "HOME", "XDG_CACHE_HOME", "RAG_PROJECT_BASE", "RAG_DEPLOY_BASE", "RAGFLOW_CONF_DIR", "REQUEST_METHOD":
			continue
		}
		env = append(env, kv)
	}
	env = append(env,
		"HTTP_PROXY="+proxyURL, "HTTPS_PROXY="+proxyURL, "http_proxy="+proxyURL, "https_proxy="+proxyURL,
		"NO_PROXY=", "no_proxy=",
		"TMPDIR="+filepath.Join(root, "tmp"), "HOME="+filepath.Join(root, "home"),
		"VERIFY_DEPLOY_INPUTS="+string(encoded), "VERIFY_DEPLOY_RESULT="+result,
	)
	env = append(env, verifyDeployImageEnv(t, verifyDeployBuild.module, root)...)
	if cacheDir != "" {
		env = append(env, "TIKTOKEN_CACHE_DIR="+cacheDir)
	}

	cmd := exec.Command(exe)
	cmd.Dir = root
	cmd.Env = env
	var out strings.Builder
	cmd.Stdout = &out
	cmd.Stderr = &out
	if err := cmd.Start(); err != nil {
		t.Fatalf("start program: %v", err)
	}
	done := make(chan error, 1)
	go func() { done <- cmd.Wait() }()
	run := verifyDeployRun{dirs: []string{root, scratch}}
	for _, d := range []string{root, scratch} {
		if resolved, err := filepath.EvalSymlinks(d); err == nil && resolved != d {
			run.dirs = append(run.dirs, resolved)
		}
	}
	select {
	case run.exitErr = <-done:
	case <-time.After(90 * time.Second):
		_ = cmd.Process.Kill()
		<-done
		t.Fatalf("the program didn't finish counting within 90s; output:\n%s", out.String())
	}
	run.output = out.String()
	run.requests = proxy.count.Load()
	if data, err := os.ReadFile(result); err == nil {
		_ = json.Unmarshal(data, &run.counts)
	}
	return run
}

func verifyDeployWrongCounts(run verifyDeployRun) []string {
	var wrong []string
	for i, c := range verifyDeployInputs {
		got := -1
		if i < len(run.counts) {
			got = run.counts[i]
		}
		if got != c.want {
			wrong = append(wrong, fmt.Sprintf("%q = %d, want %d", c.in, got, c.want))
		}
	}
	return wrong
}

func verifyDeployTail(s string) string {
	s = strings.TrimSpace(s)
	if len(s) > 300 {
		s = "..." + s[len(s)-300:]
	}
	if s == "" {
		return "(no output)"
	}
	return s
}

var verifyDeployDigits = regexp.MustCompile(`[0-9]+`)

// verifyDeployLines returns a run's output lines with its own directories
// and every number replaced, so two runs' lines can be compared.
func verifyDeployLines(run verifyDeployRun) map[string]bool {
	s := run.output
	dirs := append([]string(nil), run.dirs...)
	sort.Slice(dirs, func(i, j int) bool { return len(dirs[i]) > len(dirs[j]) })
	for _, d := range dirs {
		s = strings.ReplaceAll(s, d, "<dir>")
	}
	lines := map[string]bool{}
	for _, line := range strings.Split(s, "\n") {
		line = strings.TrimSpace(verifyDeployDigits.ReplaceAllString(line, "0"))
		if line != "" {
			lines[line] = true
		}
	}
	return lines
}

// The table sits in the install root under the sha1 of its URL, the binary
// runs from <install root>/bin with the install root as working directory,
// and no cache variable is set beyond what the container's files add.
func TestVerifyDeployInstallRootTable(t *testing.T) {
	run := verifyDeployStart(t, "root")
	if run.exitErr != nil {
		t.Fatalf("program exited with %v; output: %s", run.exitErr, verifyDeployTail(run.output))
	}
	if wrong := verifyDeployWrongCounts(run); len(wrong) > 0 {
		t.Errorf("%d of %d counts wrong, the first: %s; output: %s", len(wrong), len(verifyDeployInputs), wrong[0], verifyDeployTail(run.output))
	}
}

// TIKTOKEN_CACHE_DIR names a directory that holds the table under its sha1
// name, and the install root holds nothing.
func TestVerifyDeployConfiguredCacheDir(t *testing.T) {
	run := verifyDeployStart(t, "cachedir")
	if run.exitErr != nil {
		t.Fatalf("program exited with %v; output: %s", run.exitErr, verifyDeployTail(run.output))
	}
	if wrong := verifyDeployWrongCounts(run); len(wrong) > 0 {
		t.Errorf("%d of %d counts wrong, the first: %s; output: %s", len(wrong), len(verifyDeployInputs), wrong[0], verifyDeployTail(run.output))
	}
}

// No table anywhere the process can see. Right counts are accepted. Otherwise
// the run is held against a run with the table on disk ("root", or "cachedir"
// when "root" doesn't count right): a non-zero exit, or a line of output that
// the run with the table doesn't write, is accepted. Zeros with the same
// output as the run with the table aren't.
func TestVerifyDeployMissingTableIsVisible(t *testing.T) {
	run := verifyDeployStart(t, "none")
	if len(verifyDeployWrongCounts(run)) == 0 && run.exitErr == nil {
		return
	}
	var counted *verifyDeployRun
	for _, table := range []string{"root", "cachedir"} {
		r := verifyDeployStart(t, table)
		if r.exitErr == nil && len(verifyDeployWrongCounts(r)) == 0 {
			counted = &r
			break
		}
	}
	if counted == nil {
		t.Fatalf("with no table on disk the counts came back %v, and neither the install-root nor the cache-dir layout counted right, so there's no run with the table to hold this one against; output: %s", run.counts, verifyDeployTail(run.output))
	}
	if run.exitErr != nil {
		return
	}
	withTable := verifyDeployLines(*counted)
	for line := range verifyDeployLines(run) {
		if !withTable[line] {
			return
		}
	}
	t.Errorf("with no table on disk the counts came back %v and the process wrote nothing that a run with the table doesn't write too; output: %s", run.counts, verifyDeployTail(run.output))
}

// None of the three layouts may open a connection.
func TestVerifyDeployNoOutboundConnection(t *testing.T) {
	for _, table := range []string{"root", "cachedir", "none"} {
		t.Run(table, func(t *testing.T) {
			run := verifyDeployStart(t, table)
			if run.requests != 0 {
				t.Errorf("%d connection(s) reached the proxy; output: %s", run.requests, verifyDeployTail(run.output))
			}
		})
	}
}
