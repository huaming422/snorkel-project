// Copyright 2024 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package integration

import (
	"fmt"
	"testing"

	auth_model "gitea.dev/models/auth"
	"gitea.dev/models/organization"
	"gitea.dev/models/unittest"
	user_model "gitea.dev/models/user"
	api "gitea.dev/modules/structs"
	"gitea.dev/tests"

	"github.com/stretchr/testify/require"
)

func TestTeamPermissionAPIRoundtripValidation(t *testing.T) {
	defer tests.PrepareTestEnv(t)()

	user := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 1})
	session := loginUser(t, user.Name)
	token := getTokenForLoggedInUser(t, session, auth_model.AccessTokenScopeWriteOrganization)

	cases := GetValidationTestCases(t)
	for idx, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			kind := tc.Inputs["kind"].(string)
			permStr := tc.Inputs["permission"].(string)

			teamName := fmt.Sprintf("validteam%s%d", kind, idx)

			var payload api.CreateTeamOption
			payload.Name = teamName
			payload.IncludesAllRepositories = false

			switch kind {
			case "blanket":
				payload.Permission = api.RepoWritePermission(permStr)
				// no Units, no UnitsMap
			case "both":
				payload.Permission = api.RepoWritePermission(permStr)
				payload.Units = []string{"repo.code"}
				payload.UnitsMap = map[string]string{"repo.code": "read"}
			case "empty":
				// empty permission, no Units, no UnitsMap
				payload.Permission = api.RepoWritePermission(permStr)
			case "granular":
				// only UnitsMap, no Permission
				if rawMap, ok := tc.Inputs["units_map"]; ok {
					um := rawMap.(map[string]interface{})
					payload.UnitsMap = make(map[string]string)
					for k, v := range um {
						payload.UnitsMap[k] = v.(string)
					}
				}
			}

			req := NewRequestWithJSON(t, "POST", fmt.Sprintf("/api/v1/orgs/%s/teams", "org6"), payload).
				AddTokenAuth(token)
			resp := MakeRequest(t, req, NoExpectedStatus)

			// Determine status class
			var httpClass string
			if resp.Code >= 200 && resp.Code <= 299 {
				httpClass = "2xx"
			} else if resp.Code >= 400 && resp.Code <= 499 {
				httpClass = "4xx"
			} else {
				httpClass = fmt.Sprintf("%dxx", resp.Code/100)
			}

			expectedClass := tc.Expected["http_class"].(string)
			require.Equal(t, expectedClass, httpClass,
				"tc %s: http_class mismatch: expected %s got %s (status %d)", tc.Name, expectedClass, httpClass, resp.Code)

			// Only do further checks if 2xx
			if httpClass != "2xx" {
				return
			}

			// Decode the created team from the create response to get ID
			createdTeam := DecodeJSON(t, resp, &api.Team{})

			// Read it back via GET /api/v1/teams/{id}
			getReq := NewRequestf(t, "GET", "/api/v1/teams/%d", createdTeam.ID).AddTokenAuth(token)
			getResp := MakeRequest(t, getReq, NoExpectedStatus)
			apiTeam := DecodeJSON(t, getResp, &api.Team{})

			// Check permission
			expectedPerm := tc.Expected["permission"].(string)
			if expectedPerm != "__skip__" {
				require.Equal(t, expectedPerm, string(apiTeam.Permission),
					"tc %s: permission mismatch: expected %s got %s", tc.Name, expectedPerm, string(apiTeam.Permission))
			}

			// Check units_map_empty:
			// The spec says "assert len(apiTeam.UnitsMap) == 0 (the team carries no explicit per-unit rows)".
			// However, the implementation's GetUnitsMap() synthesizes a full per-unit map for blanket
			// write teams (no stored rows, but computed on the fly). So "no explicit per-unit rows" is
			// observed via the database: assert that no TeamUnit rows exist for this team.
			expectedEmpty := tc.Expected["units_map_empty"]
			if emptyBool, ok := expectedEmpty.(bool); ok && emptyBool {
				dbCount := unittest.GetCount(t, &organization.TeamUnit{TeamID: createdTeam.ID})
				require.Equal(t, 0, dbCount,
					"tc %s: units_map_empty expected no DB team_unit rows but got %d", tc.Name, dbCount)
			}

			// Check units_map_code
			umCode := tc.Expected["units_map_code"].(string)
			if umCode != "__skip__" {
				require.Equal(t, umCode, apiTeam.UnitsMap["repo.code"],
					"tc %s: units_map_code mismatch: expected %s got %s", tc.Name, umCode, apiTeam.UnitsMap["repo.code"])
			}

			// Check units_map_issues
			umIssues := tc.Expected["units_map_issues"].(string)
			if umIssues != "__skip__" {
				require.Equal(t, umIssues, apiTeam.UnitsMap["repo.issues"],
					"tc %s: units_map_issues mismatch: expected %s got %s", tc.Name, umIssues, apiTeam.UnitsMap["repo.issues"])
			}
		})
	}
}
