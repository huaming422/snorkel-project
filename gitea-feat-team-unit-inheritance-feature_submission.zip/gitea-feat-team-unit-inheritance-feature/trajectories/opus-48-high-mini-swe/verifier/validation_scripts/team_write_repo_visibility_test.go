// Copyright 2024 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package repo_test

import (
	"strings"
	"testing"

	"gitea.dev/models/db"
	issues_model "gitea.dev/models/issues"
	"gitea.dev/models/organization"
	perm_model "gitea.dev/models/perm"
	repo_model "gitea.dev/models/repo"
	"gitea.dev/models/unit"
	"gitea.dev/models/unittest"
	user_model "gitea.dev/models/user"
	"gitea.dev/modules/optional"

	"github.com/stretchr/testify/require"
)

func TestTeamWriteRepoVisibilityValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			require.NoError(t, unittest.PrepareTestDatabase())
			ctx := t.Context()

			// Clean baseline — no teams, so user 28's access comes only from what we insert.
			require.NoError(t, db.TruncateBeans(ctx,
				&organization.Team{}, &organization.TeamUser{},
				&organization.TeamRepo{}, &organization.TeamUnit{}))

			teamMode := tc.Inputs["team_mode"].(string)

			// Build the team according to inputs["team_mode"].
			// team is declared here so it is accessible in the issue_search branch.
			var team *organization.Team
			switch teamMode {
			case "blanket_write":
				team = &organization.Team{OrgID: 3, LowerName: "writers", AccessMode: perm_model.AccessModeWrite}
				require.NoError(t, db.Insert(ctx, team))
				require.NoError(t, db.Insert(ctx, &organization.TeamUser{OrgID: 3, TeamID: team.ID, UID: 28}))
				require.NoError(t, db.Insert(ctx, &organization.TeamRepo{OrgID: 3, TeamID: team.ID, RepoID: 3}))
			case "granular":
				team = &organization.Team{OrgID: 3, LowerName: "granular", AccessMode: perm_model.AccessModeNone}
				require.NoError(t, db.Insert(ctx, team))
				require.NoError(t, db.Insert(ctx, &organization.TeamUser{OrgID: 3, TeamID: team.ID, UID: 28}))
				require.NoError(t, db.Insert(ctx, &organization.TeamRepo{OrgID: 3, TeamID: team.ID, RepoID: 3}))
				require.NoError(t, db.Insert(ctx, &organization.TeamUnit{
					OrgID:      3,
					TeamID:     team.ID,
					Type:       unit.TypeCode,
					AccessMode: perm_model.AccessModeWrite,
				}))
			}

			check := "listing"
			if v, ok := tc.Inputs["check"]; ok {
				check = v.(string)
			}

			// Read all three expected keys upfront (RULES: every key must be used).
			visibleRepoName := tc.Expected["visible_repo_name"].(string)
			collaboratorStatus := tc.Expected["collaborator_status"].(string)
			issueRepoVisible := tc.Expected["issue_repo_visible"].(string)

			switch check {
			case "listing":
				var unitType unit.Type
				unitTypeStr, _ := tc.Inputs["unit_type"].(string)
				switch unitTypeStr {
				case "actions":
					unitType = unit.TypeActions
				case "projects":
					unitType = unit.TypeProjects
				default:
					unitType = unit.TypeCode
				}

				actor := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 28})
				repos, _, err := repo_model.SearchRepository(ctx, repo_model.SearchRepoOptions{
					Actor:       actor,
					OwnerID:     actor.ID,
					Private:     true,
					Collaborate: optional.Some(true),
					UnitType:    unitType,
					ListOptions: db.ListOptions{Page: 1, PageSize: 50},
				})
				require.NoError(t, err)

				// Collect lower-cased repo names into a set.
				repoNames := make(map[string]bool)
				for _, r := range repos {
					repoNames[strings.ToLower(r.Name)] = true
				}

				// EXPECTED: visible_repo_name
				if visibleRepoName != "__skip__" {
					if visibleRepoName != "" {
						require.True(t, repoNames[visibleRepoName],
							"tc %s: expected repo %s to be visible in listing, got repos: %v", tc.Name, visibleRepoName, repoNames)
					} else {
						// When visible_repo_name is "", repo3 must NOT be in the listing.
						require.False(t, repoNames["repo3"],
							"tc %s: expected repo3 to NOT be visible in listing, but it was present: %v", tc.Name, repoNames)
					}
				}
				// collaborator_status and issue_repo_visible are not applicable for listing check.
				// They are asserted as "__skip__" per the spec — no assertion needed.
				_ = collaboratorStatus
				_ = issueRepoVisible

			case "collaborator":
				repo := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 3})
				ok, err := repo_model.IsOwnerMemberCollaborator(ctx, repo, 28)
				require.NoError(t, err)

				var status string
				if ok {
					status = "member"
				} else {
					status = "none"
				}

				// EXPECTED: collaborator_status
				if collaboratorStatus != "__skip__" {
					require.Equal(t, collaboratorStatus, status,
						"tc %s: collaborator_status mismatch: expected %s got %s", tc.Name, collaboratorStatus, status)
				}
				// visible_repo_name and issue_repo_visible are not applicable for collaborator check.
				_ = visibleRepoName
				_ = issueRepoVisible

			case "issue_search":
				doer := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 28})
				owner := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 3}) // org3

				ids, _, err := issues_model.IssueIDs(ctx, &issues_model.IssuesOptions{
					Doer:  doer,
					Owner: owner,
					Team:  team,
				})
				require.NoError(t, err)

				// Collect RepoIDs from the returned issues.
				repoIDs := make(map[int64]bool)
				for _, id := range ids {
					issue := unittest.AssertExistsAndLoadBean(t, &issues_model.Issue{ID: id})
					repoIDs[issue.RepoID] = true
				}

				// EXPECTED: issue_repo_visible
				if issueRepoVisible != "__skip__" {
					if issueRepoVisible == "repo3" {
						require.True(t, repoIDs[3],
							"tc %s: expected repo id 3 to be visible in issue search, got repoIDs: %v", tc.Name, repoIDs)
					}
				}
				// visible_repo_name and collaborator_status are not applicable for issue_search check.
				_ = visibleRepoName
				_ = collaboratorStatus
			}
		})
	}
}
