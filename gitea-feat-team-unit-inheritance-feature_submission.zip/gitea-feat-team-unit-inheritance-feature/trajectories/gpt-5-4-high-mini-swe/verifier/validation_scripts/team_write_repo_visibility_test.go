// Copyright 2024 Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package repo_test

import (
	"strings"
	"testing"

	"gitea.dev/models/db"
	issues_model "gitea.dev/models/issues"
	"gitea.dev/models/organization"
	perm_model "gitea.dev/models/perm"
	repo_model "gitea.dev/models/repo"
	"gitea.dev/models/unit"
	"gitea.dev/models/unittest"
	user_model "gitea.dev/models/user"
	"gitea.dev/modules/optional"

	"github.com/stretchr/testify/require"
)

func TestTeamWriteRepoVisibilityValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			require.NoError(t, unittest.PrepareTestDatabase())
			ctx := t.Context()

			// Clean baseline: no teams, so the only access is from what we build.
			require.NoError(t, db.TruncateBeans(ctx,
				&organization.Team{}, &organization.TeamUser{},
				&organization.TeamRepo{}, &organization.TeamUnit{}))

			teamMode := tc.Inputs["team_mode"].(string)
			check := "listing"
			if v, ok := tc.Inputs["check"].(string); ok {
				check = v
			}

			// Build the team according to team_mode.
			var team *organization.Team
			switch teamMode {
			case "blanket_write":
				team = &organization.Team{
					OrgID:      3,
					LowerName:  "writers",
					Name:       "writers",
					AccessMode: perm_model.AccessModeWrite,
				}
				require.NoError(t, db.Insert(ctx, team))
				require.NoError(t, db.Insert(ctx, &organization.TeamUser{OrgID: 3, TeamID: team.ID, UID: 28}))
				require.NoError(t, db.Insert(ctx, &organization.TeamRepo{OrgID: 3, TeamID: team.ID, RepoID: 3}))

			case "granular":
				team = &organization.Team{
					OrgID:      3,
					LowerName:  "granularteam",
					Name:       "granularteam",
					AccessMode: perm_model.AccessModeNone,
				}
				require.NoError(t, db.Insert(ctx, team))
				require.NoError(t, db.Insert(ctx, &organization.TeamUnit{
					OrgID:      3,
					TeamID:     team.ID,
					Type:       unit.TypeCode,
					AccessMode: perm_model.AccessModeWrite,
				}))
				require.NoError(t, db.Insert(ctx, &organization.TeamUser{OrgID: 3, TeamID: team.ID, UID: 28}))
				require.NoError(t, db.Insert(ctx, &organization.TeamRepo{OrgID: 3, TeamID: team.ID, RepoID: 3}))
			}

			switch check {
			case "listing":
				unitTypeStr, _ := tc.Inputs["unit_type"].(string)
				var unitType unit.Type
				switch unitTypeStr {
				case "actions":
					unitType = unit.TypeActions
				case "projects":
					unitType = unit.TypeProjects
				default:
					unitType = unit.TypeActions
				}

				actor := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 28})
				repos, _, err := repo_model.SearchRepository(ctx, repo_model.SearchRepoOptions{
					Actor:       actor,
					OwnerID:     actor.ID,
					Private:     true,
					Collaborate: optional.Some(true),
					UnitType:    unitType,
					ListOptions: db.ListOptions{Page: 1, PageSize: 50},
				})
				require.NoError(t, err)

				// Collect lower-cased repo names
				nameSet := make(map[string]bool)
				for _, r := range repos {
					nameSet[strings.ToLower(r.Name)] = true
				}

				visibleRepoName := tc.Expected["visible_repo_name"].(string)
				if visibleRepoName != "" {
					require.True(t, nameSet[visibleRepoName],
						"expected repo %q to be visible in listing for unit_type=%s, team_mode=%s; got repos: %v",
						visibleRepoName, unitTypeStr, teamMode, nameSet)
				} else {
					require.False(t, nameSet["repo3"],
						"expected repo3 NOT to be visible in listing for unit_type=%s, team_mode=%s; but it was",
						unitTypeStr, teamMode)
				}

			case "collaborator":
				repo := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 3})
				ok, err := repo_model.IsOwnerMemberCollaborator(ctx, repo, 28)
				require.NoError(t, err)

				var status string
				if ok {
					status = "member"
				} else {
					status = "none"
				}

				collaboratorStatusExpected := tc.Expected["collaborator_status"].(string)
				if collaboratorStatusExpected != "__skip__" {
					require.Equal(t, collaboratorStatusExpected, status,
						"collaborator_status mismatch for team_mode=%s", teamMode)
				}

			case "issue_search":
				doer := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 28})
				owner := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 3}) // org3

				ids, _, err := issues_model.IssueIDs(ctx, &issues_model.IssuesOptions{
					Doer:  doer,
					Owner: owner,
					Team:  team,
				})
				require.NoError(t, err)

				repoIDs := make(map[int64]bool)
				for _, id := range ids {
					issue := unittest.AssertExistsAndLoadBean(t, &issues_model.Issue{ID: id})
					repoIDs[issue.RepoID] = true
				}

				issueRepoVisible := tc.Expected["issue_repo_visible"].(string)
				if issueRepoVisible != "__skip__" && issueRepoVisible == "repo3" {
					require.True(t, repoIDs[3],
						"expected repo3 (id=3) to be visible in issue_search for team_mode=%s; got repoIDs: %v",
						teamMode, repoIDs)
				}
			}
		})
	}
}
