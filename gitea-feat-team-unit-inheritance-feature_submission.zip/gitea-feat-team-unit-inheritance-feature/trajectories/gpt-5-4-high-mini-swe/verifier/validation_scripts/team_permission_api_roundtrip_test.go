// Copyright 2024 Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package integration

import (
	"fmt"
	"testing"

	auth_model "gitea.dev/models/auth"
	"gitea.dev/models/organization"
	"gitea.dev/models/unittest"
	user_model "gitea.dev/models/user"
	api "gitea.dev/modules/structs"
	"gitea.dev/tests"

	"github.com/stretchr/testify/require"
)

func TestTeamPermissionAPIRoundtripValidation(t *testing.T) {
	defer tests.PrepareTestEnv(t)()

	cases := GetValidationTestCases(t)

	user := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 1})
	session := loginUser(t, user.Name)
	token := getTokenForLoggedInUser(t, session, auth_model.AccessTokenScopeWriteOrganization)

	orgName := "org6"

	for i, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			kind := tc.Inputs["kind"].(string)

			// Build a unique team name per case
			teamName := fmt.Sprintf("validroundtrip-%d-%s", i, kind)

			var payload *api.CreateTeamOption

			switch kind {
			case "blanket":
				perm := tc.Inputs["permission"].(string)
				payload = &api.CreateTeamOption{
					Name:       teamName,
					Permission: api.RepoWritePermission(perm),
				}
			case "both":
				perm := tc.Inputs["permission"].(string)
				payload = &api.CreateTeamOption{
					Name:       teamName,
					Permission: api.RepoWritePermission(perm),
					Units:      []string{"repo.code"},
					UnitsMap:   map[string]string{"repo.code": "read"},
				}
			case "empty":
				payload = &api.CreateTeamOption{
					Name:       teamName,
					Permission: api.RepoWritePermission(""),
				}
			case "granular":
				unitsMapRaw := tc.Inputs["units_map"].(map[string]interface{})
				unitsMap := make(map[string]string)
				for k, v := range unitsMapRaw {
					unitsMap[k] = v.(string)
				}
				payload = &api.CreateTeamOption{
					Name:     teamName,
					UnitsMap: unitsMap,
				}
			}

			req := NewRequestWithJSON(t, "POST", fmt.Sprintf("/api/v1/orgs/%s/teams", orgName), payload).AddTokenAuth(token)
			resp := MakeRequest(t, req, NoExpectedStatus)

			// Determine HTTP class from response code
			httpClass := tc.Expected["http_class"].(string)
			var statusClass string
			switch {
			case resp.Code >= 200 && resp.Code <= 299:
				statusClass = "2xx"
			case resp.Code >= 400 && resp.Code <= 499:
				statusClass = "4xx"
			default:
				statusClass = fmt.Sprintf("%dxx", resp.Code/100)
			}
			require.Equal(t, httpClass, statusClass,
				"http_class mismatch for kind=%s, got HTTP status %d", kind, resp.Code)

			// For successful creates, decode the response and read back via GET
			if statusClass != "2xx" {
				return
			}

			createdTeam := DecodeJSON(t, resp, &api.Team{})

			// Read it back via GET /api/v1/teams/{id}
			getReq := NewRequestf(t, "GET", "/api/v1/teams/%d", createdTeam.ID).AddTokenAuth(token)
			getResp := MakeRequest(t, getReq, NoExpectedStatus)
			apiTeam := DecodeJSON(t, getResp, &api.Team{})

			// Assert permission — always assert if expected value is present; skip only if "__skip__"
			permExpected := tc.Expected["permission"].(string)
			if permExpected != "__skip__" {
				require.Equal(t, permExpected, string(apiTeam.Permission),
					"permission mismatch for kind=%s", kind)
			}

			// Assert units_map_empty — when true, assert that the team has no
			// explicit per-unit DB rows (the REST UnitsMap may be computed/non-empty
			// for blanket teams after the inheritance patch).
			unitsMapEmptyRaw := tc.Expected["units_map_empty"]
			if unitsMapEmptyBool, isBool := unitsMapEmptyRaw.(bool); isBool && unitsMapEmptyBool {
				unittest.AssertCount(t, &organization.TeamUnit{TeamID: createdTeam.ID}, 0)
			}

			// Assert units_map_code — always assert if expected value is present; skip only if "__skip__"
			unitsMapCodeExpected := tc.Expected["units_map_code"].(string)
			if unitsMapCodeExpected != "__skip__" {
				require.Equal(t, unitsMapCodeExpected, apiTeam.UnitsMap["repo.code"],
					"units_map_code mismatch for kind=%s", kind)
			}

			// Assert units_map_issues — always assert if expected value is present; skip only if "__skip__"
			unitsMapIssuesExpected := tc.Expected["units_map_issues"].(string)
			if unitsMapIssuesExpected != "__skip__" {
				require.Equal(t, unitsMapIssuesExpected, apiTeam.UnitsMap["repo.issues"],
					"units_map_issues mismatch for kind=%s", kind)
			}
		})
	}
}
