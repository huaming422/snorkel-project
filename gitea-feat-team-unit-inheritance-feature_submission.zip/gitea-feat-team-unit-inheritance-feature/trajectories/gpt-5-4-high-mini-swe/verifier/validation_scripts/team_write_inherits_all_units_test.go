// Copyright 2024 Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package access_test

import (
	"testing"

	"gitea.dev/models/db"
	"gitea.dev/models/organization"
	perm_model "gitea.dev/models/perm"
	"gitea.dev/models/perm/access"
	repo_model "gitea.dev/models/repo"
	"gitea.dev/models/unit"
	"gitea.dev/models/unittest"
	user_model "gitea.dev/models/user"

	"github.com/stretchr/testify/require"
)

func modeName(m perm_model.AccessMode) string {
	switch m {
	case perm_model.AccessModeRead:
		return "read"
	case perm_model.AccessModeWrite:
		return "write"
	case perm_model.AccessModeAdmin:
		return "admin"
	case perm_model.AccessModeOwner:
		return "owner"
	default:
		return "none"
	}
}

func TestTeamWriteInheritsAllUnitsValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			require.NoError(t, unittest.PrepareTestDatabase())
			ctx := t.Context()

			// Load the private org repo (repo3, owner org3) and user28.
			repo := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 3})
			user := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 28})

			// Clean baseline so the resolved modes come purely from the team we build.
			require.NoError(t, db.TruncateBeans(ctx,
				&organization.Team{}, &organization.TeamUser{},
				&organization.TeamRepo{}, &organization.TeamUnit{}))

			// Insert an external-tracker RepoUnit on repo 3 so it is present.
			require.NoError(t, db.Insert(ctx, &repo_model.RepoUnit{
				RepoID: 3,
				Type:   unit.TypeExternalTracker,
				Config: &repo_model.ExternalTrackerConfig{ExternalTrackerURL: "https://tracker.example.com/"},
			}))
			// Re-load the repo bean so its units are re-read.
			repo = unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 3})

			teamMode := tc.Inputs["team_mode"].(string)

			var team organization.Team
			switch teamMode {
			case "write":
				team = organization.Team{
					OrgID:      3,
					LowerName:  "writeteam",
					Name:       "writeteam",
					AccessMode: perm_model.AccessModeWrite,
				}
				require.NoError(t, db.Insert(ctx, &team))
				require.NoError(t, db.Insert(ctx, &organization.TeamUser{OrgID: 3, TeamID: team.ID, UID: user.ID}))
				require.NoError(t, db.Insert(ctx, &organization.TeamRepo{OrgID: 3, TeamID: team.ID, RepoID: repo.ID}))

			case "admin":
				team = organization.Team{
					OrgID:      3,
					LowerName:  "adminteam",
					Name:       "adminteam",
					AccessMode: perm_model.AccessModeAdmin,
				}
				require.NoError(t, db.Insert(ctx, &team))
				require.NoError(t, db.Insert(ctx, &organization.TeamUser{OrgID: 3, TeamID: team.ID, UID: user.ID}))
				require.NoError(t, db.Insert(ctx, &organization.TeamRepo{OrgID: 3, TeamID: team.ID, RepoID: repo.ID}))

			case "granular":
				team = organization.Team{
					OrgID:      3,
					LowerName:  "granularteam",
					Name:       "granularteam",
					AccessMode: perm_model.AccessModeNone,
				}
				require.NoError(t, db.Insert(ctx, &team))
				require.NoError(t, db.Insert(ctx, &organization.TeamUnit{
					OrgID:      3,
					TeamID:     team.ID,
					Type:       unit.TypeCode,
					AccessMode: perm_model.AccessModeWrite,
				}))
				require.NoError(t, db.Insert(ctx, &organization.TeamUser{OrgID: 3, TeamID: team.ID, UID: user.ID}))
				require.NoError(t, db.Insert(ctx, &organization.TeamRepo{OrgID: 3, TeamID: team.ID, RepoID: repo.ID}))
			}

			perm, err := access.GetIndividualUserRepoPermission(ctx, repo, user)
			require.NoError(t, err)

			codeAccess := modeName(perm.UnitAccessMode(unit.TypeCode))
			actionsAccess := modeName(perm.UnitAccessMode(unit.TypeActions))
			extTrackerAccess := modeName(perm.UnitAccessMode(unit.TypeExternalTracker))

			require.Equal(t, tc.Expected["code_access"].(string), codeAccess,
				"code_access mismatch for team_mode=%s", teamMode)
			require.Equal(t, tc.Expected["actions_access"].(string), actionsAccess,
				"actions_access mismatch for team_mode=%s", teamMode)
			require.Equal(t, tc.Expected["ext_tracker_access"].(string), extTrackerAccess,
				"ext_tracker_access mismatch for team_mode=%s", teamMode)
		})
	}
}
