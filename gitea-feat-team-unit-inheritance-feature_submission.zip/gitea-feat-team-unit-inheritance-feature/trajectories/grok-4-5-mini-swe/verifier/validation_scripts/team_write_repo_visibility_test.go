// Copyright 2024 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package repo_test

import (
	"strings"
	"testing"

	"gitea.dev/models/db"
	issues_model "gitea.dev/models/issues"
	"gitea.dev/models/organization"
	perm_model "gitea.dev/models/perm"
	repo_model "gitea.dev/models/repo"
	"gitea.dev/models/unit"
	"gitea.dev/models/unittest"
	user_model "gitea.dev/models/user"
	"gitea.dev/modules/optional"

	"github.com/stretchr/testify/require"
)

func TestTeamWriteRepoVisibilityValidation(t *testing.T) {
	for _, tc := range GetValidationTestCases(t) {
		t.Run(tc.Name, func(t *testing.T) {
			require.NoError(t, unittest.PrepareTestDatabase())
			ctx := t.Context()

			// Clean baseline - user 28 has NO individual access-table or collaboration rows.
			require.NoError(t, db.TruncateBeans(ctx,
				&organization.Team{}, &organization.TeamUser{},
				&organization.TeamRepo{}, &organization.TeamUnit{}))

			teamMode := tc.Inputs["team_mode"].(string)

			var team *organization.Team

			switch teamMode {
			case "blanket_write":
				team = &organization.Team{OrgID: 3, LowerName: "writers", Name: "writers", AccessMode: perm_model.AccessModeWrite}
				require.NoError(t, db.Insert(ctx, team))
				require.NoError(t, db.Insert(ctx, &organization.TeamUser{OrgID: 3, TeamID: team.ID, UID: 28}))
				require.NoError(t, db.Insert(ctx, &organization.TeamRepo{OrgID: 3, TeamID: team.ID, RepoID: 3}))

			case "granular":
				team = &organization.Team{OrgID: 3, LowerName: "granular", Name: "granular", AccessMode: perm_model.AccessModeNone}
				require.NoError(t, db.Insert(ctx, team))
				require.NoError(t, db.Insert(ctx, &organization.TeamUser{OrgID: 3, TeamID: team.ID, UID: 28}))
				require.NoError(t, db.Insert(ctx, &organization.TeamRepo{OrgID: 3, TeamID: team.ID, RepoID: 3}))
				// Only TypeCode at write
				require.NoError(t, db.Insert(ctx, &organization.TeamUnit{OrgID: 3, TeamID: team.ID, Type: unit.TypeCode, AccessMode: perm_model.AccessModeWrite}))
			}

			// Get check type (default to "listing")
			check := "listing"
			if checkVal, ok := tc.Inputs["check"]; ok {
				check = checkVal.(string)
			}

			// Read all expected values unconditionally
			expectedVisibleRepoName := tc.Expected["visible_repo_name"].(string)
			expectedCollaboratorStatus := tc.Expected["collaborator_status"].(string)
			expectedIssueRepoVisible := tc.Expected["issue_repo_visible"].(string)

			switch check {
			case "listing":
				// Determine unit type from inputs
				unitTypeStr := tc.Inputs["unit_type"].(string)
				var unitType unit.Type
				switch unitTypeStr {
				case "actions":
					unitType = unit.TypeActions
				case "projects":
					unitType = unit.TypeProjects
				default:
					unitType = unit.TypeCode
				}

				actor := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 28})
				repos, _, err := repo_model.SearchRepository(ctx, repo_model.SearchRepoOptions{
					Actor:       actor,
					OwnerID:     actor.ID,
					Private:     true,
					Collaborate: optional.Some(true),
					UnitType:    unitType,
					ListOptions: db.ListOptions{Page: 1, PageSize: 50},
				})
				require.NoError(t, err)

				// Collect lower-cased repo names
				repoNames := make(map[string]bool)
				for _, r := range repos {
					repoNames[strings.ToLower(r.Name)] = true
				}

				// Assert visible_repo_name
				if expectedVisibleRepoName != "__skip__" {
					if expectedVisibleRepoName != "" {
						require.True(t, repoNames[expectedVisibleRepoName],
							"case %s: expected repo %q in listing but got %v", tc.Name, expectedVisibleRepoName, repoNames)
					} else {
						require.False(t, repoNames["repo3"],
							"case %s: repo3 should NOT be in listing but was found in %v", tc.Name, repoNames)
					}
				}
				// collaborator_status and issue_repo_visible are __skip__ for listing cases — no-op
				_ = expectedCollaboratorStatus
				_ = expectedIssueRepoVisible

			case "collaborator":
				repo := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 3})
				ok, err := repo_model.IsOwnerMemberCollaborator(ctx, repo, 28)
				require.NoError(t, err)

				var collaboratorStatus string
				if ok {
					collaboratorStatus = "member"
				} else {
					collaboratorStatus = "none"
				}

				// Assert collaborator_status
				if expectedCollaboratorStatus != "__skip__" {
					require.Equal(t, expectedCollaboratorStatus, collaboratorStatus,
						"case %s: collaborator_status mismatch", tc.Name)
				}
				// visible_repo_name and issue_repo_visible are __skip__ for collaborator cases — no-op
				_ = expectedVisibleRepoName
				_ = expectedIssueRepoVisible

			case "issue_search":
				require.NotNil(t, team, "case %s: team must not be nil for issue_search check", tc.Name)

				doer := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 28})
				owner := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 3}) // org3

				ids, _, err := issues_model.IssueIDs(ctx, &issues_model.IssuesOptions{
					Doer:  doer,
					Owner: owner,
					Team:  team,
				})
				require.NoError(t, err)

				// Collect the set of RepoIDs
				repoIDs := make(map[int64]bool)
				for _, id := range ids {
					issue := unittest.AssertExistsAndLoadBean(t, &issues_model.Issue{ID: id})
					repoIDs[issue.RepoID] = true
				}

				// Assert issue_repo_visible
				if expectedIssueRepoVisible != "__skip__" {
					if expectedIssueRepoVisible == "repo3" {
						require.True(t, repoIDs[3],
							"case %s: expected repo id 3 in issue search results but got %v", tc.Name, repoIDs)
					}
				}
				// visible_repo_name and collaborator_status are __skip__ for issue_search cases — no-op
				_ = expectedVisibleRepoName
				_ = expectedCollaboratorStatus
			}
		})
	}
}
