// Copyright 2024 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package access_test

import (
	"testing"

	"gitea.dev/models/db"
	"gitea.dev/models/organization"
	perm_model "gitea.dev/models/perm"
	"gitea.dev/models/perm/access"
	repo_model "gitea.dev/models/repo"
	"gitea.dev/models/unit"
	"gitea.dev/models/unittest"
	user_model "gitea.dev/models/user"

	"github.com/stretchr/testify/require"
)

func modeName(m perm_model.AccessMode) string {
	switch m {
	case perm_model.AccessModeRead:
		return "read"
	case perm_model.AccessModeWrite:
		return "write"
	case perm_model.AccessModeAdmin:
		return "admin"
	case perm_model.AccessModeOwner:
		return "owner"
	default:
		return "none"
	}
}

func TestTeamWriteInheritsAllUnitsValidation(t *testing.T) {
	for _, tc := range GetValidationTestCases(t) {
		t.Run(tc.Name, func(t *testing.T) {
			require.NoError(t, unittest.PrepareTestDatabase())
			ctx := t.Context()

			// Private org repo (repo id 3, org 3); user28 is a plain member of org3.
			repo := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 3})
			user := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 28})

			// Clean baseline so the resolved modes come purely from the team we build.
			require.NoError(t, db.TruncateBeans(ctx,
				&organization.Team{}, &organization.TeamUser{},
				&organization.TeamRepo{}, &organization.TeamUnit{}))

			// In EVERY case, first insert an external-tracker RepoUnit on repo 3
			// and re-load the repo bean so its units are re-read.
			require.NoError(t, db.Insert(ctx, &repo_model.RepoUnit{
				RepoID: 3, Type: unit.TypeExternalTracker,
				Config: &repo_model.ExternalTrackerConfig{ExternalTrackerURL: "https://tracker.example.com/"},
			}))
			repo = unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 3})

			teamMode := tc.Inputs["team_mode"].(string)

			switch teamMode {
			case "write":
				team := &organization.Team{OrgID: 3, LowerName: "writers", Name: "writers", AccessMode: perm_model.AccessModeWrite}
				require.NoError(t, db.Insert(ctx, team))
				require.NoError(t, db.Insert(ctx, &organization.TeamUser{OrgID: 3, TeamID: team.ID, UID: 28}))
				require.NoError(t, db.Insert(ctx, &organization.TeamRepo{OrgID: 3, TeamID: team.ID, RepoID: 3}))

			case "admin":
				team := &organization.Team{OrgID: 3, LowerName: "admins", Name: "admins", AccessMode: perm_model.AccessModeAdmin}
				require.NoError(t, db.Insert(ctx, team))
				require.NoError(t, db.Insert(ctx, &organization.TeamUser{OrgID: 3, TeamID: team.ID, UID: 28}))
				require.NoError(t, db.Insert(ctx, &organization.TeamRepo{OrgID: 3, TeamID: team.ID, RepoID: 3}))

			case "granular":
				team := &organization.Team{OrgID: 3, LowerName: "granular", Name: "granular", AccessMode: perm_model.AccessModeNone}
				require.NoError(t, db.Insert(ctx, team))
				require.NoError(t, db.Insert(ctx, &organization.TeamUser{OrgID: 3, TeamID: team.ID, UID: 28}))
				require.NoError(t, db.Insert(ctx, &organization.TeamRepo{OrgID: 3, TeamID: team.ID, RepoID: 3}))
				// Only TypeCode at write; no row for actions, no row for external tracker
				require.NoError(t, db.Insert(ctx, &organization.TeamUnit{OrgID: 3, TeamID: team.ID, Type: unit.TypeCode, AccessMode: perm_model.AccessModeWrite}))
			}

			perm, err := access.GetIndividualUserRepoPermission(ctx, repo, user)
			require.NoError(t, err)

			codeAccess := modeName(perm.UnitAccessMode(unit.TypeCode))
			actionsAccess := modeName(perm.UnitAccessMode(unit.TypeActions))
			extTrackerAccess := modeName(perm.UnitAccessMode(unit.TypeExternalTracker))

			require.Equal(t, tc.Expected["code_access"].(string), codeAccess,
				"case %s: code_access mismatch", tc.Name)
			require.Equal(t, tc.Expected["actions_access"].(string), actionsAccess,
				"case %s: actions_access mismatch", tc.Name)
			require.Equal(t, tc.Expected["ext_tracker_access"].(string), extTrackerAccess,
				"case %s: ext_tracker_access mismatch", tc.Name)
		})
	}
}
