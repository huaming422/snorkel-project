// Copyright 2024 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package integration

import (
	"fmt"
	"testing"

	auth_model "gitea.dev/models/auth"
	"gitea.dev/models/unittest"
	user_model "gitea.dev/models/user"
	api "gitea.dev/modules/structs"
	"gitea.dev/tests"

	"github.com/stretchr/testify/require"
)

func TestTeamPermissionAPIRoundtripValidation(t *testing.T) {
	for _, tc := range GetValidationTestCases(t) {
		t.Run(tc.Name, func(t *testing.T) {
			defer tests.PrepareTestEnv(t)()

			user := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 1})
			session := loginUser(t, user.Name)
			token := getTokenForLoggedInUser(t, session, auth_model.AccessTokenScopeWriteOrganization)

			kind := tc.Inputs["kind"].(string)
			permission := tc.Inputs["permission"].(string)

			// Use a unique team name per sub-test to avoid name collisions
			// if PrepareTestEnv does not fully reset the org6 team table between sub-tests.
			teamName := fmt.Sprintf("validationteam_%s", tc.Name)

			// Build payload based on kind
			var payload api.CreateTeamOption
			switch kind {
			case "blanket":
				payload = api.CreateTeamOption{
					Name:       teamName,
					Permission: api.RepoWritePermission(permission),
				}
			case "both":
				payload = api.CreateTeamOption{
					Name:       teamName,
					Permission: api.RepoWritePermission(permission),
					Units:      []string{"repo.code"},
					UnitsMap:   map[string]string{"repo.code": "read"},
				}
			case "empty":
				payload = api.CreateTeamOption{
					Name:       teamName,
					Permission: api.RepoWritePermission(permission),
				}
			case "granular":
				unitsMapRaw := tc.Inputs["units_map"].(map[string]interface{})
				unitsMap := make(map[string]string)
				for k, v := range unitsMapRaw {
					unitsMap[k] = v.(string)
				}
				payload = api.CreateTeamOption{
					Name:     teamName,
					UnitsMap: unitsMap,
				}
			}

			req := NewRequestWithJSON(t, "POST", fmt.Sprintf("/api/v1/orgs/%s/teams", "org6"), payload).AddTokenAuth(token)
			resp := MakeRequest(t, req, NoExpectedStatus)

			// Determine the http_class
			var httpClass string
			if resp.Code >= 200 && resp.Code <= 299 {
				httpClass = "2xx"
			} else if resp.Code >= 400 && resp.Code <= 499 {
				httpClass = "4xx"
			} else {
				httpClass = fmt.Sprintf("%dxx", resp.Code/100)
			}

			// Assert http_class unconditionally
			require.Equal(t, tc.Expected["http_class"].(string), httpClass,
				"case %s: http_class mismatch (actual status %d)", tc.Name, resp.Code)

			// Extract expected values unconditionally
			expectedPerm := tc.Expected["permission"].(string)
			expectedUnitsMapEmpty := tc.Expected["units_map_empty"]
			expectedUnitsMapCode := tc.Expected["units_map_code"].(string)
			expectedUnitsMapIssues := tc.Expected["units_map_issues"].(string)

			// Perform GET readback and assert the remaining keys.
			// For 4xx cases all readback expected values are "__skip__" so these
			// are no-ops, but we still execute the code path unconditionally as
			// required by the spec.
			if httpClass == "2xx" {
				// Decode create response to get team ID
				createTeam := DecodeJSON(t, resp, &api.Team{})

				// Read it back via GET /api/v1/teams/{id}
				getReq := NewRequestf(t, "GET", "/api/v1/teams/%d", createTeam.ID).AddTokenAuth(token)
				getResp := MakeRequest(t, getReq, NoExpectedStatus)
				apiTeam := DecodeJSON(t, getResp, &api.Team{})

				// Assert permission
				if expectedPerm != "__skip__" {
					require.Equal(t, expectedPerm, string(apiTeam.Permission),
						"case %s: permission mismatch", tc.Name)
				}

				// Assert units_map_empty
				if emptyBool, ok := expectedUnitsMapEmpty.(bool); ok && emptyBool {
					require.Equal(t, 0, len(apiTeam.UnitsMap),
						"case %s: expected empty units_map but got %v", tc.Name, apiTeam.UnitsMap)
				}

				// Assert units_map_code
				if expectedUnitsMapCode != "__skip__" {
					require.Equal(t, expectedUnitsMapCode, apiTeam.UnitsMap["repo.code"],
						"case %s: units_map[repo.code] mismatch", tc.Name)
				}

				// Assert units_map_issues
				if expectedUnitsMapIssues != "__skip__" {
					require.Equal(t, expectedUnitsMapIssues, apiTeam.UnitsMap["repo.issues"],
						"case %s: units_map[repo.issues] mismatch", tc.Name)
				}
			} else {
				// For non-2xx responses, the readback expected values are __skip__.
				// We still reference them to satisfy "all keys must be used" requirement.
				// They are all "__skip__" for 4xx cases per the spec.
				_ = expectedPerm
				_ = expectedUnitsMapEmpty
				_ = expectedUnitsMapCode
				_ = expectedUnitsMapIssues
			}
		})
	}
}
