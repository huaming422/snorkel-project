## Task

Org owners want to give a team a single blanket permission over the organization's repositories, either write or admin, that reaches every repository unit the team has access to and keeps reaching new unit types we add to the product later, without anyone reopening the team to adjust it.

Admin teams already work like this: one choice and the team can reach everything. Write teams don't. Today a write team has to have each unit granted one at a time, and any unit we add afterward is left out until someone goes back and edits the team. We want a single write grant to carry across all units the same way, reaching each unit at the strongest level that unit actually supports — write for the normal units, and read for the few that only ever allow read (an external issue tracker, for instance). Admin stays exactly as it is.

Teams set up with explicit per-unit permissions should keep behaving exactly as they do today.

The work that matters is the backend permission resolution and the team REST API contract. Any template, localization, or frontend changes can follow from that, but they aren't the focus.

## User stories / requirements

- When a team is granted a single write team permission, its members can reach every repository unit at the strongest level that unit supports — write for the normal units, and read for a unit that only ever allows read (such as an external issue tracker) — including units that were never configured individually and unit types introduced after the team was set up. Granting admin as the team permission inherits administrator access across every unit the same way.
- Creating a team through the REST API with a single write or admin permission reads back that permission with a unit view consistent with the inheritance; creating one with explicit per-unit permissions reads those values back. Supplying both a per-unit permission map and a units list at once is rejected as a client error.
- A member of a write-permission team can see and reach that team's repositories, and their units, through the normal repository access and listing paths, with no per-unit entry configured for the team.
