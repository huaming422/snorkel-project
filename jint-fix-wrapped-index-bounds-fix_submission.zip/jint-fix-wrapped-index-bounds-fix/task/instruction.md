## Task

we hand ordinary host objects to scripts through the engine with CLR interop on and host writes allowed. one is a plain bounded collection: it reports how many items it holds and takes an integer position through its indexer.

trouble shows up when a script reads or writes a numeric index the collection has no slot for: a position past the end, or one that is not a real position at all, like a negative number or a string such as `"08"` or `"+3"`. the collection's own .NET exception escapes straight out of `engine.Evaluate(...)` / `engine.Execute(...)`. being a raw host exception rather than a script-level error, it dodges both a `try`/`catch` in the script and an embedder `catch` for the engine's script-error type, and the host call is torn down. existence checks do not even agree: ask whether such an index is present and it says yes, though reading it fails.

an unaddressable index should behave like any ordinary property that is simply not there, with no host exception leaking out. positions the collection really has still read and write through, named members still resolve, and host objects of other shapes that legitimately take such keys still accept them. dig in and fix it.
