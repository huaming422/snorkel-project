#!/usr/bin/env bash
# Sourced before the verifier runs. Everything the focused tests need is baked
# into the image at build time (network up): the .NET 10 SDK, the .NET 8 shared
# runtime the net8.0 test host needs, the full NuGet closure for
# Jint.Tests.PublicInterface at the base commit under /root/.nuget/packages, and
# a warmed net8.0 build. There is nothing to fetch at verifier time, so this
# stays a no-op (the agent phase is offline and the verifier phase reaches only
# the model gateway).
set -euo pipefail

export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1
export NUGET_PACKAGES="${NUGET_PACKAGES:-/root/.nuget/packages}"

# Sanity: the SDK and both shared runtimes must be present.
dotnet --version
dotnet --list-runtimes

echo "[test-setup] jint-fix-wrapped-index-bounds: toolchain ready (no-op)"
