#nullable enable

using System.Collections;
using System.Globalization;
using Jint.Native;
using Jint.Runtime;

namespace Jint.Tests.PublicInterface;

/// <summary>
/// Drives the public <c>Engine</c> surface only (<c>SetValue</c> / <c>Evaluate</c> / <c>Execute</c>) and
/// reads JavaScript-level results, so it never names any interop-internal type. A host shape with a count
/// and an integer indexer, and none of the three list interfaces that would give it an array-like view, is
/// wrapped plainly: every index-shaped key resolves the reflected indexer, which hands whatever index it
/// parsed out of the key straight to the collection. A position the collection has no slot for should read
/// as an ordinary absent property rather than letting the collection's own <see cref="ArgumentOutOfRangeException"/>
/// escape <c>Evaluate</c>/<c>Execute</c> — invisible to both a script <c>try</c>/<c>catch</c> and a host
/// <c>catch (JavaScriptException)</c>. The contrast cases pin that the bound is a bound, not a ban on
/// integer keys: in-range positions, named members, a <c>Dictionary&lt;int,string&gt;</c> add, and a
/// string-keyed indexer on an array-like target all keep working.
/// </summary>
public class WrappedCollectionIndexBoundsTests
{
    /// <summary>Keys naming a position a three-element window cannot address, in both spellings.</summary>
    public static IEnumerable<string> UnaddressableIndices => ["3", "'3'", "10", "-1", "'-1'", "'08'", "'+3'"];

    [TestCaseSource(nameof(UnaddressableIndices))]
    public void ReadingAnIndexTheCollectionCannotAddressAnswersUndefined(string key)
    {
        var engine = CreateEngine(out _);

        engine.Evaluate($"x[{key}]").Should().Be(JsValue.Undefined,
            "there is no element at {0}, so a hole reads undefined rather than raising the collection's own exception", key);
    }

    [TestCaseSource(nameof(UnaddressableIndices))]
    public void WritingAnIndexTheCollectionCannotAddressIsTheOrdinarySetRefusal(string key)
    {
        var engine = CreateEngine(out var window);

        engine.Execute($"x[{key}] = 9");
        engine.Evaluate($"Reflect.set(x, {key}, 9)").AsBoolean().Should().BeFalse();

        var thrown = Caught.Exception(() => engine.Execute($"'use strict'; x[{key}] = 9;"));
        thrown.Should().BeOfType<JavaScriptException>("a refused [[Set]] in strict mode is a TypeError");
        ((JavaScriptException) thrown!).Error.Get("name").AsString().Should().Be("TypeError");

        window.Should().Equal(new[] { 1, 2, 3 }, "nothing reached the collection");
    }

    [TestCaseSource(nameof(UnaddressableIndices))]
    public void EveryExistenceLaneAgreesThatSuchAnIndexIsAbsent(string key)
    {
        var engine = CreateEngine(out _);

        engine.Evaluate($"[({key} in x), x.hasOwnProperty({key}), x.propertyIsEnumerable({key}), Object.getOwnPropertyDescriptor(x, {key}) !== undefined].join(',')")
            .AsString().Should().Be("false,false,false,false",
                "{0} is not a position of the collection, so no lane may report it as one", key);
    }

    [TestCaseSource(nameof(UnaddressableIndices))]
    public void DeletingSuchAnIndexSucceedsWithoutTouchingTheCollection(string key)
    {
        var engine = CreateEngine(out var window);

        engine.Evaluate($"delete x[{key}]").AsBoolean().Should().BeTrue("OrdinaryDelete returns true for a property that is not there");
        window.Should().Equal(1, 2, 3);
    }

    /// <summary>
    /// The contrast that says the guard is a bound and not a ban on integer keys: every position the
    /// collection does have still reads and writes through its own indexer.
    /// </summary>
    [TestCase("0", 1d)]
    [TestCase("'0'", 1d)]
    [TestCase("2", 3d)]
    [TestCase("'2'", 3d)]
    public void APositionTheCollectionHasIsUnaffected(string key, double expected)
    {
        var engine = CreateEngine(out var window);

        engine.Evaluate($"x[{key}]").AsNumber().Should().Be(expected);
        engine.Evaluate($"{key} in x").AsBoolean().Should().BeTrue();
        engine.Evaluate($"x.hasOwnProperty({key})").AsBoolean().Should().BeTrue();

        engine.Execute($"x[{key}] = 9");
        window[int.Parse(key.Trim('\''), CultureInfo.InvariantCulture)].Should().Be(9);
    }

    /// <summary>Named CLR members of the same target keep resolving; only index-shaped keys are the view's.</summary>
    [Test]
    public void NamedMembersAreUnaffected()
    {
        var engine = CreateEngine(out _);

        engine.Evaluate("x.Count").AsNumber().Should().Be(3);
        engine.Evaluate("x.length").AsNumber().Should().Be(3);
        engine.Evaluate("Array.prototype.join.call(x, '-')").AsString().Should().Be("1-2-3");
    }

    /// <summary>
    /// The other half of the trade-off. A wrapper's indexer lane also serves a dictionary, where a key
    /// outside what it currently holds is a legitimate add and refusing it would be the bug. A dictionary is
    /// not array-like, which is what separates the two.
    /// </summary>
    [Test]
    public void AnIntegerKeyedDictionaryStillAdds()
    {
        var engine = new Engine(options =>
        {
            options.AllowClr();
            options.Interop.AllowWrite = true;
        });
        var dictionary = new Dictionary<int, string> { [1] = "one" };
        engine.SetValue("x", dictionary);

        engine.Execute("x[99] = 'ninety-nine'");

        dictionary.Should().ContainKey(99).WhoseValue.Should().Be("ninety-nine");
        engine.Evaluate("x[99]").AsString().Should().Be("ninety-nine");
        engine.Evaluate("x[1]").AsString().Should().Be("one");
    }

    /// <summary>
    /// A string-keyed indexer on an array-like target is not the collection's positions, and the check must
    /// read the resolved accessor's index parameter rather than guessing from the key, so it stays out of
    /// the way. <c>x["3"]</c> is the member named <c>3</c>, whatever the count happens to be.
    /// </summary>
    [Test]
    public void AStringKeyedIndexerOnAnArrayLikeTargetStillAnswers()
    {
        var engine = new Engine(options =>
        {
            options.AllowClr();
            options.Interop.AllowWrite = true;
        });
        engine.SetValue("x", new NamedValues { ["3"] = "the third", ["etag"] = "abc" });

        engine.Evaluate("x['3']").AsString().Should().Be("the third");
        engine.Evaluate("x['etag']").AsString().Should().Be("abc");
    }

    /// <summary>
    /// The bound is on positions the collection has no slot for, not on the collection's own exceptions. A
    /// position that <em>is</em> in range but whose indexer legitimately fails for its own reason — a backing
    /// store that faults, an invariant the element violates — is a real error, and the guard that answers an
    /// unaddressable index with undefined must not reach it: it classifies up front from the count and never
    /// runs the indexer for a position the count says is absent, so the only <c>ArgumentOutOfRangeException</c>
    /// it could ever see is one it chose not to raise. A reactive guard that instead catches the collection's
    /// range exception after the fact cannot tell this genuine fault apart from an out-of-range miss and
    /// swallows both to undefined — reporting a hole where the host raised a real failure.
    /// </summary>
    [Test]
    public void AGenuineExceptionFromAnInRangePositionIsNotSwallowedToUndefined()
    {
        var engine = new Engine(options =>
        {
            options.AllowClr();
            options.Interop.AllowWrite = true;
        });
        engine.SetValue("x", new FaultyWindow());

        // The positions either side of the fault are ordinary in-range reads, so the collection is genuinely
        // reached by index and the fault at 1 is a real one, not an addressing miss.
        engine.Evaluate("x[0]").AsNumber().Should().Be(10);
        engine.Evaluate("x[2]").AsNumber().Should().Be(30);

        var thrown = Caught.Exception(() => engine.Evaluate("x[1]"));
        thrown.Should().NotBeNull(
            "position 1 is within the count, so the indexer runs and its exception is a genuine host failure; " +
            "it must surface rather than be silently converted to undefined as an unaddressable position would be");
    }

    private static Engine CreateEngine(out Window window)
    {
        window = new Window(1, 2, 3);
        var engine = new Engine(options =>
        {
            options.AllowClr();
            options.Interop.AllowWrite = true;
        });
        engine.SetValue("x", window);
        return engine;
    }

    /// <summary>
    /// Bounded and indexed, and neither an <see cref="IList{T}"/>, an <see cref="IReadOnlyList{T}"/> nor a
    /// non-generic <see cref="IList"/> — so no array-like view is built for it and every part of that is
    /// load-bearing. <see cref="IReadOnlyCollection{T}"/> is what gives it a <c>Count</c>, and the declared
    /// indexer is what the reflected member lane resolves for an index-shaped key.
    /// </summary>
    public sealed class Window : IReadOnlyCollection<int>
    {
        private readonly List<int> _items;

        public Window(params int[] items) => _items = [.. items];

        public int this[int index] { get => _items[index]; set => _items[index] = value; }

        public int Count => _items.Count;

        public IEnumerator<int> GetEnumerator() => _items.GetEnumerator();

        IEnumerator IEnumerable.GetEnumerator() => _items.GetEnumerator();
    }

    /// <summary>
    /// The same bounded, integer-indexed shape as <see cref="Window"/>, except one in-range position's getter
    /// faults for its own reason rather than returning an element — a backing store that is briefly
    /// unavailable, an element that fails an invariant. <see cref="Count"/> says the position exists, so an
    /// up-front bound never classifies it as absent and the indexer is run; the exception it raises is a
    /// genuine host failure, not the collection reporting a missing slot.
    /// </summary>
    public sealed class FaultyWindow : IReadOnlyCollection<int>
    {
        private readonly int[] _items = [10, 20, 30];

        public int this[int index]
        {
            get => index == 1
                ? throw new ArgumentOutOfRangeException(nameof(index), "the backing store for this position faulted")
                : _items[index];
            set => _items[index] = value;
        }

        public int Count => _items.Length;

        public IEnumerator<int> GetEnumerator() => ((IEnumerable<int>) _items).GetEnumerator();

        IEnumerator IEnumerable.GetEnumerator() => _items.GetEnumerator();
    }

    /// <summary>
    /// An array-like target whose indexer is keyed by <see cref="string"/>, the shape a
    /// <c>NameValueCollection</c> has.
    /// </summary>
    public sealed class NamedValues : IReadOnlyCollection<string>
    {
        private readonly Dictionary<string, string> _values = new(StringComparer.Ordinal);

        public string this[string name]
        {
            get => _values.TryGetValue(name, out var value) ? value : string.Empty;
            set => _values[name] = value;
        }

        public int Count => _values.Count;

        public IEnumerator<string> GetEnumerator() => _values.Values.GetEnumerator();

        IEnumerator IEnumerable.GetEnumerator() => _values.Values.GetEnumerator();
    }
}
