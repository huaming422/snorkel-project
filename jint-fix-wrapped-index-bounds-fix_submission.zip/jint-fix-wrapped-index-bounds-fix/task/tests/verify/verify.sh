#!/usr/bin/env bash
# Behavioral verifier for jint-fix-wrapped-index-bounds.
#
# Drives the public Engine API through a new xUnit/NUnit fixture added to the
# already-present Jint.Tests.PublicInterface project (the public-API leg: it
# touches only Engine/Evaluate/Execute/SetValue, never any interop-internal
# symbol, so it cannot couple to where the guard lives). The fixture asserts
# the observable contract: an index a bounded, integer-indexed host collection
# has no slot for reads undefined, writes are the ordinary [[Set]] refusal,
# every existence lane agrees it is absent, delete returns true — and the
# contrast shapes (in-range positions, named members, an integer-keyed
# dictionary add, a string-keyed indexer on an array-like target) keep working.
#
# Runs with cwd = the repo root (/repo/jint). Exit 0 = every test passed,
# non-zero = at least one failed (or the solution does not compile).
#
# MUST target -f net8.0: the net10.0 leg of this project drives the public-API
# baseline machinery, which rebuilds every shipped framework including the
# Windows-only net472 facade and fails on Linux. net8.0 is the supported Linux
# leg; the image bakes the .NET 8 shared runtime on top of the SDK for it.
# --no-restore: the package closure is baked at build time and this phase is
# offline, so do not restore here.
set -uo pipefail

export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1
export NUGET_PACKAGES="${NUGET_PACKAGES:-/root/.nuget/packages}"

REPO_ROOT="$(pwd)"
PROJECT_DIR="${REPO_ROOT}/Jint.Tests.PublicInterface"
PROJECT="${PROJECT_DIR}/Jint.Tests.PublicInterface.csproj"
FIXTURE_SRC="$(dirname "$0")/WrappedCollectionIndexBoundsTests.cs"
FIXTURE_DST="${PROJECT_DIR}/WrappedCollectionIndexBoundsTests.cs"

if [ ! -f "$PROJECT" ]; then
  echo "FAIL: expected test project not found at $PROJECT"
  exit 1
fi
if [ ! -f "$FIXTURE_SRC" ]; then
  echo "FAIL: verifier fixture not found at $FIXTURE_SRC"
  exit 1
fi

# Place the fixture into the test project (SDK-style globbing compiles it) and
# remove it again on exit so the verifier leaves no trace in the working tree.
cp "$FIXTURE_SRC" "$FIXTURE_DST"
cleanup() { rm -f "$FIXTURE_DST"; }
trap cleanup EXIT

dotnet test "$PROJECT" \
  -f net8.0 -c Debug --no-restore --nologo \
  --filter "FullyQualifiedName~WrappedCollectionIndexBoundsTests"
status=$?

if [ "$status" -eq 0 ]; then
  echo "PASS: an unaddressable host-collection index behaves as an ordinary absent property across every lane"
else
  echo "FAIL: dotnet test exited $status"
fi
exit "$status"
