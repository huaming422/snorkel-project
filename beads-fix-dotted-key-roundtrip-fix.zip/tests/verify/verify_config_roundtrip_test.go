// Round-trip tests for dotted workspace config keys, driven entirely through
// the public config accessors. The contract under test is simple to state and
// was not held by either function alone: whatever SetYamlConfigInDir writes for
// a dotted key, GetStringFromDir must read back, and UnsetYamlConfig must be
// able to take back. The file on disk is git-tracked and may be shared with
// other tools, so a write must not reshape content it was not asked to change.
//
// External test package on purpose: it links only the exported surface
// (SetYamlConfigInDir, GetStringFromDir, UnsetYamlConfig) plus a real viper
// reader, so it is independent of how the package represents a dotted key
// internally.
package config_test

import (
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/spf13/viper"
	"github.com/steveyegge/beads/internal/config"
)

// seedFile writes the starting config.yaml. SetYamlConfigInDir edits an
// existing file and declines to create one, so even the "empty workspace" cases
// start from a zero-byte file.
func seedFile(t *testing.T, dir, body string) string {
	t.Helper()
	path := filepath.Join(dir, "config.yaml")
	if err := os.WriteFile(path, []byte(body), 0o600); err != nil {
		t.Fatalf("seed config.yaml: %v", err)
	}
	return path
}

// A value written for a dotted key must read back through the same accessors,
// starting from the common case of a brand-new, empty workspace file.
func TestDottedValueReadsBackAfterWrite(t *testing.T) {
	dir := t.TempDir()
	seedFile(t, dir, "")

	writes := map[string]string{
		"sync.remote": "file:///origin.git",
		"dolt.port":   "45678",
	}
	for key, value := range writes {
		if err := config.SetYamlConfigInDir(dir, key, value); err != nil {
			t.Fatalf("SetYamlConfigInDir(%q): %v", key, err)
		}
	}
	for key, want := range writes {
		if got := config.GetStringFromDir(dir, key); got != want {
			body, _ := os.ReadFile(filepath.Join(dir, "config.yaml")) //nolint:errcheck // diagnostic
			t.Errorf("GetStringFromDir(%q) = %q, want %q\nfile:\n%s", key, got, want, body)
		}
	}
}

// Writing into an empty or comment-only file must both read back AND keep the
// text that was already there. `bd init` writes a comment-only template, so a
// fresh workspace's first dotted write lands on exactly this shape, and dropping
// the comments is a committed diff the operator never asked for.
func TestDottedWriteIntoCommentOnlyFileKeepsComments(t *testing.T) {
	seed := "# Beads Configuration File\n" +
		"# This file configures default behavior for all bd commands in this repository\n" +
		"\n" +
		"# Issue prefix for this repository (used by bd init)\n" +
		"# issue-prefix: \"\"\n" +
		"\n" +
		"# Default actor for audit trails\n" +
		"# actor: \"\"\n"

	dir := t.TempDir()
	path := seedFile(t, dir, seed)

	// Two writes: the first lands on the comment-only file, the second on
	// whatever the first produced. Both must preserve the comments.
	if err := config.SetYamlConfigInDir(dir, "sync.remote", "file:///origin.git"); err != nil {
		t.Fatalf("set sync.remote: %v", err)
	}
	if err := config.SetYamlConfigInDir(dir, "dolt.port", "3307"); err != nil {
		t.Fatalf("set dolt.port: %v", err)
	}

	body, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read: %v", err)
	}
	text := string(body)
	for _, line := range strings.Split(strings.TrimRight(seed, "\n"), "\n") {
		if strings.TrimSpace(line) == "" {
			continue
		}
		if !strings.Contains(text, line) {
			t.Errorf("a line already in the file was dropped by a write: %q\ngot:\n%s", line, text)
		}
	}
	if got := config.GetStringFromDir(dir, "sync.remote"); got != "file:///origin.git" {
		t.Errorf("sync.remote reads back as %q\n%s", got, text)
	}
	if got := config.GetStringFromDir(dir, "dolt.port"); got != "3307" {
		t.Errorf("dolt.port reads back as %q\n%s", got, text)
	}
}

// Unsetting a dotted key must actually clear it, and it must stay visible in the
// file as a commented line — the documented "commented out, kept as a record"
// behavior, so a later reader still knows the key was once configured.
func TestUnsetClearsADottedKeyAndKeepsItAsDocumentation(t *testing.T) {
	dir := t.TempDir()
	path := seedFile(t, dir, "sync:\n    remote: \"file:///origin.git\"\n")

	// Confirm the precondition through the same reader the contract is about.
	if got := config.GetStringFromDir(dir, "sync.remote"); got != "file:///origin.git" {
		t.Fatalf("precondition: sync.remote reads back as %q, want it set", got)
	}

	t.Setenv("BEADS_DIR", dir)
	if err := config.UnsetYamlConfig("sync.remote"); err != nil {
		t.Fatalf("UnsetYamlConfig(sync.remote): %v", err)
	}

	body, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read: %v", err)
	}
	if got := config.GetStringFromDir(dir, "sync.remote"); got != "" {
		t.Errorf("sync.remote still reads back as %q after unset:\n%s", got, body)
	}
	// The disabled leaf remains visible without being an active YAML key.
	commented := false
	for _, line := range strings.Split(string(body), "\n") {
		if strings.HasPrefix(strings.TrimSpace(line), "# remote:") {
			commented = true
		}
	}
	if !commented {
		t.Errorf("unset did not leave a commented key:\n%s", body)
	}
}

// An unset must touch only the key it was asked about. A leaf name that repeats
// at a different depth, or a section name that repeats under a foreign parent,
// is a different key: cutting it (or leaving the target live while a bystander
// dies) is the over-match the anchoring has to prevent.
func TestUnsetDoesNotTouchNamesakesElsewhere(t *testing.T) {
	cases := []struct {
		name      string
		seed      string
		key       string
		survivors map[string]string
	}{
		{
			name:      "deeper key repeats the leaf name",
			seed:      "sync:\n    sub:\n        remote: keep\n    remote: target\n",
			key:       "sync.remote",
			survivors: map[string]string{"sync.sub.remote": "keep"},
		},
		{
			name:      "section name repeats under a foreign parent",
			seed:      "other:\n    sync:\n        remote: keep\nsync:\n    remote: target\n",
			key:       "sync.remote",
			survivors: map[string]string{"other.sync.remote": "keep"},
		},
		{
			name:      "target and namesake in the same file",
			seed:      "other:\n  dolt:\n    host: should-survive\ndolt:\n  host: kill-me\n",
			key:       "dolt.host",
			survivors: map[string]string{"other.dolt.host": "should-survive"},
		},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			dir := t.TempDir()
			path := seedFile(t, dir, tc.seed)
			if got := config.GetStringFromDir(dir, tc.key); got == "" {
				t.Fatalf("precondition: %s is not set in the fixture", tc.key)
			}

			t.Setenv("BEADS_DIR", dir)
			if err := config.UnsetYamlConfig(tc.key); err != nil {
				t.Fatalf("UnsetYamlConfig(%q): %v", tc.key, err)
			}

			body, err := os.ReadFile(path)
			if err != nil {
				t.Fatalf("read: %v", err)
			}
			if got := config.GetStringFromDir(dir, tc.key); got != "" {
				t.Errorf("%s still reads back as %q after unset:\n%s", tc.key, got, body)
			}
			for key, want := range tc.survivors {
				if got := config.GetStringFromDir(dir, key); got != want {
					t.Errorf("unset touched a key it was not asked about: %s = %q, want %q\n%s",
						key, got, want, body)
				}
			}
		})
	}
}

// Set, unset, set is one sequence and the round trip has to survive all of it.
func TestSetUnsetSetStaysReadable(t *testing.T) {
	cases := []struct {
		name string
		seed string
	}{
		{name: "section empties out", seed: "node_id: mini\n"},
		{name: "sibling keeps the section", seed: "sync:\n    branch: beads-sync\n"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			dir := t.TempDir()
			path := seedFile(t, dir, tc.seed)
			t.Setenv("BEADS_DIR", dir)

			if err := config.SetYamlConfigInDir(dir, "sync.remote", "file:///a.git"); err != nil {
				t.Fatalf("first set: %v", err)
			}
			if err := config.UnsetYamlConfig("sync.remote"); err != nil {
				t.Fatalf("unset: %v", err)
			}
			if got := config.GetStringFromDir(dir, "sync.remote"); got != "" {
				body, _ := os.ReadFile(path) //nolint:errcheck // diagnostic
				t.Fatalf("unset left sync.remote at %q:\n%s", got, body)
			}
			if err := config.SetYamlConfigInDir(dir, "sync.remote", "file:///b.git"); err != nil {
				t.Fatalf("second set: %v", err)
			}

			body, err := os.ReadFile(path)
			if err != nil {
				t.Fatalf("read: %v", err)
			}
			if got := config.GetStringFromDir(dir, "sync.remote"); got != "file:///b.git" {
				t.Errorf("sync.remote reads back as %q after set/unset/set:\n%s", got, body)
			}
			if tc.name == "sibling keeps the section" {
				if got := config.GetStringFromDir(dir, "sync.branch"); got != "beads-sync" {
					t.Errorf("a sibling key was lost: sync.branch = %q\n%s", got, body)
				}
			}
		})
	}
}

// An existing flat spelling must be updated so the new value reads back.
// Unrelated text and settings must survive, whether the implementation keeps
// that spelling or safely changes the requested key's representation.
func TestWriteUpdatesExistingFlatSpelling(t *testing.T) {
	dir := t.TempDir()
	path := seedFile(t, dir, "# managed by another writer\ndolt.host: 10.0.0.1\nnode_id: mini\n")

	if err := config.SetYamlConfigInDir(dir, "dolt.host", "127.0.0.1"); err != nil {
		t.Fatalf("set dolt.host: %v", err)
	}

	body, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read: %v", err)
	}
	text := string(body)
	if got := config.GetStringFromDir(dir, "dolt.host"); got != "127.0.0.1" {
		t.Errorf("dolt.host reads back as %q, want %q\n%s", got, "127.0.0.1", text)
	}
	if !strings.Contains(text, "# managed by another writer") {
		t.Errorf("an unrelated comment was disturbed:\n%s", text)
	}
	if got := config.GetStringFromDir(dir, "node_id"); got != "mini" {
		t.Errorf("an unrelated key was disturbed: node_id = %q\n%s", got, text)
	}
}

// When a file carries both the flat spelling and a nested mapping for the same
// key, the direct reader must agree with the merged-config reader (viper) about
// which value wins — the exact top-level key. Two readers disagreeing is the
// whole defect, so this both pins the winning value and cross-checks that a real
// viper read lands on the same answer.
func TestReaderPrefersExactFlatKeyLikeViper(t *testing.T) {
	dir := t.TempDir()
	path := seedFile(t, dir, "dolt.host: 127.0.0.1\ndolt:\n  host: 10.0.0.1\n")

	got := config.GetStringFromDir(dir, "dolt.host")
	if got != "127.0.0.1" {
		t.Errorf("GetStringFromDir(dolt.host) = %q, want the exact-flat-key value %q", got, "127.0.0.1")
	}

	v := viper.New()
	v.SetConfigFile(path)
	if err := v.ReadInConfig(); err != nil {
		t.Fatalf("viper ReadInConfig: %v", err)
	}
	if viperGot := v.GetString("dolt.host"); viperGot != got {
		t.Errorf("the two readers disagree: viper = %q, GetStringFromDir = %q", viperGot, got)
	}
}

// A scalar parent cannot acquire a child without replacing the parent value.
// The other shapes may either be edited safely or refused without a change.
func TestComplexShapesAreHandledWithoutDamage(t *testing.T) {
	type op struct {
		set bool // true = SetYamlConfigInDir, false = UnsetYamlConfig
	}
	cases := []struct {
		name string
		seed string
		key  string
		op   op
	}{
		{name: "set under a scalar parent", seed: "sync: enabled\nnode_id: mini\n", key: "sync.remote", op: op{set: true}},
		{name: "unset a flow-style mapping", seed: "sync: {remote: \"file:///origin.git\"}\nnode_id: mini\n", key: "sync.remote"},
		{name: "unset a literal block scalar", seed: "sync:\n    remote: |\n        line1\n        line2\nnode_id: mini\n", key: "sync.remote"},
		{name: "unset a folded block scalar", seed: "sync:\n    remote: >\n        line1\nnode_id: mini\n", key: "sync.remote"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			dir := t.TempDir()
			path := seedFile(t, dir, tc.seed)
			t.Setenv("BEADS_DIR", dir)

			var err error
			if tc.op.set {
				err = config.SetYamlConfigInDir(dir, tc.key, "file:///origin.git")
			} else {
				err = config.UnsetYamlConfig(tc.key)
			}
			body, readErr := os.ReadFile(path)
			if readErr != nil {
				t.Fatalf("read: %v", readErr)
			}
			if tc.op.set && err == nil {
				t.Fatalf("set replaced a scalar parent without an error:\n%s", body)
			}
			if err != nil {
				if string(body) != tc.seed {
					t.Errorf("a refused edit still changed the file:\ngot:\n%s\nwant:\n%s", body, tc.seed)
				}
				return
			}
			if got := config.GetStringFromDir(dir, tc.key); got != "" {
				t.Errorf("unset left %s readable as %q:\n%s", tc.key, got, body)
			}
			v := viper.New()
			v.SetConfigFile(path)
			if err := v.ReadInConfig(); err != nil {
				t.Errorf("successful unset left invalid YAML: %v\n%s", err, body)
			}
			if got := config.GetStringFromDir(dir, "node_id"); got != "mini" {
				t.Errorf("successful unset changed node_id to %q:\n%s", got, body)
			}
			if !strings.Contains(string(body), "sync:") {
				t.Errorf("unset removed the unrelated sync section:\n%s", body)
			}
		})
	}
}

// A single-segment key has no nesting to do and must keep round-tripping exactly
// as before: this is the shape most config keys have.
func TestUndottedKeysRoundTripUnchanged(t *testing.T) {
	dir := t.TempDir()
	seedFile(t, dir, "# seed\n")

	if err := config.SetYamlConfigInDir(dir, "node_id", "mini"); err != nil {
		t.Fatalf("set node_id: %v", err)
	}
	if got := config.GetStringFromDir(dir, "node_id"); got != "mini" {
		body, _ := os.ReadFile(filepath.Join(dir, "config.yaml")) //nolint:errcheck // diagnostic
		t.Fatalf("node_id reads back as %q, want %q\n%s", got, "mini", body)
	}
}

// Unsetting a key that was never set stays a successful no-op and leaves
// unrelated keys alone.
func TestUnsetOfAbsentKeyIsASuccessfulNoop(t *testing.T) {
	dir := t.TempDir()
	path := seedFile(t, dir, "dolt:\n    port: 3307\nnode_id: mini\n")

	t.Setenv("BEADS_DIR", dir)
	if err := config.UnsetYamlConfig("sync.remote"); err != nil {
		t.Fatalf("UnsetYamlConfig on a never-set key: %v", err)
	}
	body, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read: %v", err)
	}
	if got := config.GetStringFromDir(dir, "dolt.port"); got != "3307" {
		t.Errorf("a no-op unset changed dolt.port to %q:\n%s", got, body)
	}
	if got := config.GetStringFromDir(dir, "node_id"); got != "mini" {
		t.Errorf("a no-op unset changed node_id to %q:\n%s", got, body)
	}
}
