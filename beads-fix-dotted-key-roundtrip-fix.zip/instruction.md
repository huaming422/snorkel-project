## Task

Some per-workspace `bd` settings addressed by dotted keys do not persist reliably in `.beads/config.yaml`.

After `bd` records a value, reading the same setting can return nothing, and commands depending on it behave as though it is unset. Unsetting a setting can leave it in effect, so a removed sync remote may still be used.

Please repair the configuration paths so setting, reading, and unsetting these keys agree, including repeated set and unset operations. Preserve unrelated content in `.beads/config.yaml`; it is tracked by git and other tools may edit it.
