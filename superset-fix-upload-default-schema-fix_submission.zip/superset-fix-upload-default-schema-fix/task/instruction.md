## Task

uploading a CSV to a Postgres database breaks when the Schema field is left blank. it fails with `schema "undefined" does not exist`, and the uploads that do go through create a second dataset for a table that already has one. picking a schema explicitly works fine. this used to just apply the database's default schema when the field was left empty. can you dig in and get blank-schema uploads working again?
