"""Backend behavioral verifier for the blank-schema upload fix.

Covers (criterion keys mirrored in judge/rubric.json):
  - default_schema_resolved      : a no-schema upload resolves the DB default
                                   and that default reaches the write
  - explicit_schema_preserved    : an explicit schema is never overwritten
  - schema_normalization         : "" / whitespace / "undefined" reaching the
                                   request path end up as the resolved default;
                                   a real schema is preserved verbatim
  - allowlist_exact_match        : a USER-SUPPLIED schema matches the upload
                                   allow-list exactly (pre-existing invariant;
                                   case-variant siblings are NOT authorized)

Every test drives a PRE-EXISTING, stable interface:
  * superset.commands.database.uploaders.base.UploadCommand.run()
    (the public entry point; the resolved schema is observed where the command
    hands it to the reader — the value that is written to the dataset)
  * superset.databases.schemas.UploadPostSchema().load(..., partial=True)
  * superset.views.database.validators.schema_allows_file_upload(db, schema)

It imports NO symbol the fix invents (no _resolve_default_schema, no
normalize_schema, no engine_resolved kwarg). The core behavior — a blank schema
resolving to the database default — is asserted END TO END through run(), at the
point the command writes the schema, so the test is BLIND to WHERE the fix does
the normalization/resolution (marshmallow hook, __init__, validate(), or run())
and to HOW it threads any allow-list handling. Any implementation that makes
blank-schema uploads land on the database default again passes.

Scope note: these tests gate only the symptom base.md describes — a blank-schema
upload on a database with no non-empty upload allow-list that used to apply the
default. The allow-list is a documented red herring for the hard variant, so the
engine-resolved-default allow-list interaction and the resolution-failure
degrade behavior are senior nuances tracked informationally in the rubric, not
gated here (gating an unstated requirement would reject valid solutions).
"""

from __future__ import annotations

import io
import sys

import pytest
from werkzeug.datastructures import FileStorage

# The repo is editable-installed; keep the explicit path insert so the verifier
# imports superset.* even if invoked from outside the source root.
sys.path.insert(0, "/repo/superset")


# --------------------------------------------------------------------------- #
# App context: UploadCommand and the marshmallow schema need a live Superset
# application context (flask config + flask_babel lazy_gettext on the exception
# classes). Build the minimal app once per session, mirroring the repo's own
# unit-test harness (tests/unit_tests/conftest.py). The pytest runner executes
# this file by path, so the repo conftest is not auto-loaded — we provide the
# fixtures here.
# --------------------------------------------------------------------------- #
@pytest.fixture(scope="session")
def _superset_app():
    from superset.app import SupersetApp
    from superset.extensions import appbuilder
    from superset.initialization import SupersetAppInitializer

    app = SupersetApp(__name__)
    app.config.from_object("superset.config")
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite://"
    app.config["WTF_CSRF_ENABLED"] = False
    app.config["TESTING"] = True
    app.config["RATELIMIT_ENABLED"] = False
    app.config["CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["FILTER_STATE_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["EXPLORE_FORM_DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["GLOBAL_ASYNC_QUERIES_REDIS_CONFIG"] = None
    app.config["TALISMAN_ENABLED"] = False
    app.config["PREVENT_UNSAFE_DB_CONNECTIONS"] = False

    appbuilder.baseviews = []
    SupersetAppInitializer(app).init_app()
    return app


@pytest.fixture
def app_context(_superset_app):
    with _superset_app.app_context():
        yield


def _file(contents: bytes = b"col\n1\n") -> FileStorage:
    return FileStorage(stream=io.BytesIO(contents), filename="data.csv")


def _drive_run(mocker, *, schema, default_schema="public", default_catalog=None):
    """Drive UploadCommand.run() far enough to observe the schema the command
    hands to the reader — i.e. the schema written to the dataset.

    Everything run() touches after schema handling is stubbed, so the test is
    blind to WHERE the fix resolves the default (marshmallow hook, __init__,
    validate(), or run()) and only observes the resolved schema arriving at the
    write. The allow-list predicate is stubbed to permit the upload so this path
    isolates default resolution from allow-list semantics (which get their own
    test). Returns (reader, model).
    """
    from superset.commands.database.uploaders.base import UploadCommand

    model = mocker.MagicMock()
    model.db_engine_spec.supports_file_upload = True
    model.db_engine_spec.supports_schemas = True
    model.get_default_catalog.return_value = default_catalog
    # model.get_default_schema(catalog): Database.get_default_schema on the model
    # instance (superset/models/core.py) — one valid resolution path.
    model.get_default_schema.return_value = default_schema
    # model.db_engine_spec.get_default_schema(model, catalog): BaseEngineSpec
    # classmethod called on the instance (superset/db_engine_specs/base.py) —
    # another valid resolution path. Both are pre-existing stable interfaces.
    model.db_engine_spec.get_default_schema.return_value = default_schema
    # Echo the (table, schema) pair so the reader observes the resolved schema.
    model.db_engine_spec.normalize_table_name_for_upload.side_effect = (
        lambda table, schema: (table, schema)
    )
    mocker.patch(
        "superset.commands.database.uploaders.base.DatabaseDAO.find_by_id",
        return_value=model,
    )
    mocker.patch(
        "superset.commands.database.uploaders.base.schema_allows_file_upload",
        return_value=True,
    )
    mocker.patch.dict(
        "superset.commands.database.uploaders.base.current_app.config",
        {"UPLOAD_MAX_FILE_SIZE_BYTES": 1024},
    )
    db_mock = mocker.patch("superset.commands.database.uploaders.base.db")
    filter_by = db_mock.session.query.return_value.filter_by.return_value
    # No visible dataset over the target table...
    filter_by.one_or_none.return_value = None
    # ...and no legacy NULL-schema row either (a solution may look for one).
    filter_by.filter.return_value.all.return_value = []
    mocker.patch(
        "superset.daos.dataset.DatasetDAO.find_soft_deleted_logical_duplicate",
        return_value=None,
    )
    mocker.patch(
        "superset.commands.database.uploaders.base.SqlaTable",
        return_value=mocker.MagicMock(),
    )
    mocker.patch(
        "superset.commands.database.uploaders.base.get_user",
        return_value=None,
    )

    reader = mocker.MagicMock()
    command = UploadCommand(1, "t", _file(), schema, reader)
    command.run()
    return reader, model


def _written_schema(reader) -> object:
    """The schema the command wrote: reader.read(file, model, table, schema)."""
    return reader.read.call_args[0][3]


# --------------------------------------------------------------------------- #
# default_schema_resolved — a blank (omitted) schema resolves to the database
# default and THAT is what the write receives. Asserted end to end through run()
# so any resolution site passes; the pre-fix code writes None and fails.
# --------------------------------------------------------------------------- #
def test_blank_schema_resolves_to_database_default(app_context, mocker):
    reader, _ = _drive_run(mocker, schema=None, default_schema="public")

    assert _written_schema(reader) == "public"


# --------------------------------------------------------------------------- #
# default_schema_resolved (empty-string arm: a blank field, not an omitted one).
# --------------------------------------------------------------------------- #
def test_empty_string_schema_resolves_to_database_default(app_context, mocker):
    reader, _ = _drive_run(mocker, schema="", default_schema="public")

    assert _written_schema(reader) == "public"


# --------------------------------------------------------------------------- #
# explicit_schema_preserved — a real schema reaches the write unchanged and the
# default is never consulted. Asserted through run() so the site is irrelevant.
# --------------------------------------------------------------------------- #
def test_explicit_schema_is_preserved_and_default_not_consulted(app_context, mocker):
    reader, model = _drive_run(mocker, schema="other", default_schema="public")

    assert _written_schema(reader) == "other"
    model.get_default_schema.assert_not_called()


# --------------------------------------------------------------------------- #
# schema_normalization — asserted through the COMPOSED request path
# (upload-form load -> command run). The symptom's `"undefined"` is a non-empty
# string, so the command's own falsy "no schema" guard does NOT catch it; one
# valid design drops it in the request schema, another in the command before
# resolving. Driving load()+run() together makes the assertion blind to WHICH
# layer drops it, so any correct placement passes and a solution that leaves the
# server trusting a stringified-unset value (the pre-fix behavior) fails.
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize(
    "schema_in,expected",
    [
        # The literal the Postgres error names: a broken/old client serializes
        # an unselected field to the text "undefined". By the time the dataset
        # is written that must have been treated as "no schema" and the database
        # default resolved.
        ("undefined", "public"),
        # A genuinely-named schema must survive the request path unchanged — the
        # symptom is only about the blank/unset case; real schemas keep working
        # and the default is never consulted for them.
        ("myschema", "myschema"),
    ],
)
def test_request_path_treats_stringified_unset_as_no_schema(
    app_context, mocker, schema_in, expected
):
    from superset.databases.schemas import UploadPostSchema

    loaded = UploadPostSchema().load({"schema": schema_in}, partial=True)
    reader, model = _drive_run(
        mocker, schema=loaded.get("schema"), default_schema="public"
    )

    assert _written_schema(reader) == expected
    if expected != "public":
        model.get_default_schema.assert_not_called()


# --------------------------------------------------------------------------- #
# allowlist_exact_match — a USER-SUPPLIED schema matches the upload allow-list
# EXACTLY (2-arg, the stable pre-existing signature). This is a pre-existing
# invariant guard: a solution that case-folds user-supplied schemas would widen
# the allow-list (on case-sensitive engines PUBLIC and public are distinct
# physical schemas) and must not pass. Case-variant siblings are NOT authorized.
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize(
    "schema,allowed,expected",
    [
        ("public", {"public"}, True),
        ("PUBLIC", {"public"}, False),
        ("public", {"PUBLIC"}, False),
        ("other", {"public"}, False),
        (None, {"public"}, False),
    ],
)
def test_user_supplied_schema_matches_allowlist_exactly(
    app_context, mocker, schema, allowed, expected
):
    from superset.views.database.validators import schema_allows_file_upload

    database = mocker.MagicMock()
    database.allow_file_upload = True
    database.get_schema_access_for_file_upload.return_value = allowed

    assert schema_allows_file_upload(database, schema) is expected
