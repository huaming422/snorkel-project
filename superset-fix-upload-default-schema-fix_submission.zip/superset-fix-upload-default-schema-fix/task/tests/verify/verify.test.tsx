/**
 * Frontend behavioral verifier for the blank-schema upload fix.
 *
 * Criterion: frontend_omits_blank_schema — when a user submits the upload modal
 * without picking a schema, the submitted multipart body must OMIT the schema
 * entry entirely, rather than serialize an unset value into the literal string
 * "undefined". The same omission applies to other optional fields left unset
 * (checked here via Excel's sheet_name).
 *
 * The test drives the stable public surface only: it renders the
 * <UploadDataModal> component and inspects the request body the component
 * actually sends (intercepted via fetch-mock). It imports no internal helper
 * (no appendFormData, no NonNullFields) so any implementation that stops
 * sending blank fields passes.
 *
 * Self-contained: the runner copies just this file into the component
 * directory, so the mocks/props/fillForm helper from the repo's own
 * UploadDataModal.test.tsx are reproduced here.
 */
// @ts-nocheck
import fetchMock from 'fetch-mock';
import UploadDataModal from 'src/features/databases/UploadDataModel';
import {
  render,
  screen,
  waitFor,
  userEvent,
  fireEvent,
} from 'spec/helpers/testing-library';

const csvProps = {
  show: true,
  onHide: () => {},
  allowedExtensions: ['csv', 'tsv'],
  type: 'csv',
};

const excelProps = {
  show: true,
  onHide: () => {},
  allowedExtensions: ['xls', 'xlsx'],
  type: 'excel',
};

const setupMocks = () => {
  fetchMock.post('glob:*api/v1/database/1/upload/', {});
  fetchMock.post('glob:*api/v1/database/csv_metadata/', {});
  fetchMock.post('glob:*api/v1/database/excel_metadata/', {});
  fetchMock.post('glob:*api/v1/database/columnar_metadata/', {});
  fetchMock.post('glob:*api/v1/database/upload_metadata/', {});

  fetchMock.get(
    'glob:*api/v1/database/?q=(filters:!((col:allow_file_upload,opr:eq,value:!t)),page:0,page_size:100)',
    {
      result: [
        { id: 1, database_name: 'database1' },
        { id: 2, database_name: 'database2' },
      ],
    },
  );

  fetchMock.get('glob:*api/v1/database/*/catalogs/', { result: [] });

  fetchMock.get('glob:*api/v1/database/1/schemas/?q=(upload_allowed:!t)', {
    result: ['information_schema', 'public'],
  });

  fetchMock.get('glob:*api/v1/database/2/schemas/?q=(upload_allowed:!t)', {
    result: ['schema1', 'schema2'],
  });
};

jest.setTimeout(60000);

beforeEach(() => {
  setupMocks();
});

afterEach(() => {
  fetchMock.clearHistory().removeRoutes();
});

// eslint-disable-next-line no-restricted-globals -- scoped verifier suite
describe('UploadDataModal omits blank optional fields from submitted form data', () => {
  // Fill and submit the form. When omitSchema is true the schema combobox is
  // left untouched, reproducing a blank Schema field.
  const fillForm = async (
    fileName: string,
    mimeType = 'text/csv',
    { omitSchema = false } = {},
  ) => {
    const selectButton = screen.getByRole('button', { name: 'Select' });
    await userEvent.click(selectButton);

    const file = new File(['test'], fileName, { type: mimeType });
    const inputElement = screen.getByTestId('model-file-input');
    fireEvent.change(inputElement, { target: { files: [file] } });

    const selectDatabase = screen.getByRole('combobox', {
      name: /select a database/i,
    });
    await userEvent.click(selectDatabase);
    await waitFor(() => screen.getByText('database1'));
    await userEvent.click(screen.getByText('database1'));

    if (!omitSchema) {
      const schemaCombobox = screen.getByRole('combobox', { name: /schema/i });
      await userEvent.click(schemaCombobox);
      await waitFor(() => screen.getAllByText('public'));
      await userEvent.click(screen.getAllByText('public')[1]);
    }

    const inputTableName = screen.getByRole('textbox', {
      name: /table name/i,
    });
    await userEvent.type(inputTableName, 'table1');

    const uploadButton = screen.getByRole('button', { name: 'Upload' });
    await userEvent.click(uploadButton);

    await waitFor(
      () => fetchMock.callHistory.called('glob:*api/v1/database/1/upload/'),
      { timeout: 10000 },
    );
    return fetchMock.callHistory.calls('glob:*api/v1/database/1/upload/')[0];
  };

  test('CSV submission with the schema field left blank omits schema from the form data', async () => {
    render(<UploadDataModal {...csvProps} />, { useRedux: true });

    const { options } = await fillForm('test.csv', 'text/csv', {
      omitSchema: true,
    });
    const formData = options?.body as FormData;

    // The known-good fields still ride along...
    expect(formData.get('type')).toBe('csv');
    expect(formData.get('table_name')).toBe('table1');
    expect((formData.get('file') as File).name).toBe('test.csv');
    // ...but the unselected schema must be absent, not the string "undefined".
    expect(formData.has('schema')).toBe(false);
  }, 60000);

  test('Excel submission omits an unset optional field (sheet_name) from the form data', async () => {
    render(<UploadDataModal {...excelProps} />, { useRedux: true });

    const { options } = await fillForm('test.xls', 'text', { omitSchema: false });
    const formData = options?.body as FormData;

    expect(formData.get('type')).toBe('excel');
    expect(formData.get('table_name')).toBe('table1');
    expect(formData.get('schema')).toBe('public');
    // An optional field the user never touched must not be serialized at all.
    expect(formData.has('sheet_name')).toBe(false);
  }, 60000);
});
