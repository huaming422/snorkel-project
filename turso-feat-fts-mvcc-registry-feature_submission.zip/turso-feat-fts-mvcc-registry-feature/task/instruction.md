## Task

Time to make the experimental full-text-search index method a first-class citizen under MVCC. Today FTS and MVCC mode don't coexist, and we want an FTS index (created with `CREATE INDEX ... USING fts(col)` and queried with `fts_match(col, 'term')`) to work correctly when the database runs in MVCC mode (`PRAGMA journal_mode='mvcc'`, transactions opened with `BEGIN CONCURRENT`). The experimental index method is turned on at runtime through `DatabaseOpts::with_index_method(true)`.

Keep the work scoped to the FTS index method and how it stores its data in, and coordinates concurrency through, the MVCC transaction layer. The behaviors we care about are concurrent writers to the same index, snapshot-isolated reads, deletes, savepoint rollback, and `OPTIMIZE INDEX`, spelled out in the requirements below.

One hard constraint rides along with all of this: a database that already holds an FTS index created by an older build of the software has to stay usable when this version opens it.

## User stories / requirements

- When two concurrent transactions each insert a different row into the same FTS index, both commit successfully, and once both have committed every inserted row is findable through `fts_match`. While both are still open, neither transaction can see the other's uncommitted document.
- When a transaction sets a savepoint, writes to an FTS index, and then rolls back to that savepoint, the index changes made after the savepoint are discarded. A transaction that is holding an open or already-rolled-back savepoint does not block another transaction from concurrently writing to the same index.
- After a row is deleted, it stops matching full-text queries, both in the snapshot of the transaction that deleted it and in snapshots taken later, while every other row keeps matching as before.
- A transaction never observes another transaction's uncommitted FTS writes. When a document is committed by another transaction, a reader sees it only once it takes a new snapshot, not within a snapshot that predates the commit.
- Opening a database that holds an FTS index in an older, unsupported format succeeds, and the base table and unrelated operations keep working. Only reads or writes using the outdated index fail, with an error telling the user to rebuild it by dropping and recreating it. After rebuilding, search reflects the table's current contents.
- Running `OPTIMIZE INDEX` on an FTS index leaves the results returned by `fts_match` queries unchanged.
