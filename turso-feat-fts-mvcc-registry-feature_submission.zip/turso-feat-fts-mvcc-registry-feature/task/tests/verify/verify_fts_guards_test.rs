//! Baseline FTS capability guard for the FTS-under-MVCC redesign.
//!
//! The rust runner copies this file into `tests/tests/` and runs it as a
//! standalone integration-test binary (`cargo test --test
//! verify_fts_guards_test --manifest-path=tests/Cargo.toml`). Because
//! `core_tester` exposes `integration/common.rs` as a public library module
//! (see `tests/lib.rs`), this file drives the SAME pre-existing TempDatabase +
//! SQL interface that the repo's own FTS integration suite uses — WITHOUT
//! importing any internal symbol of the storage/engine layer (no
//! `turso_core::index_method::fts::*`, no module/type/field names from the
//! implementation). Everything is observed through `CREATE INDEX ... USING
//! fts`, `fts_match(...)`, and SQL on a `turso_core::Connection`.
//!
//! `basic_fts_roundtrip` checks the plain single-connection (non-MVCC) FTS
//! path: create an index, insert rows, and query them back. It is driven at
//! the non-MVCC level so it is fast and deterministic, and it is the regression
//! floor — the rewrite of the FTS storage/engine must not break the plain
//! single-connection path. The concurrent-writer, snapshot-isolation,
//! tombstone-delete, savepoint-rollback, OPTIMIZE, and legacy-format behaviours
//! run under MVCC and are exercised elsewhere.

use core_tester::common::{limbo_exec_rows, TempDatabase};
use rusqlite::types::Value;

/// Build a single-connection FTS-enabled database (experimental index method on),
/// no MVCC. Mirrors the repo's own plain-`#[test]` FTS-open idiom.
fn fts_db() -> TempDatabase {
    TempDatabase::builder()
        .with_opts(turso_core::DatabaseOpts::new().with_index_method(true))
        .build()
}

/// Collect the integer ids from a `SELECT id ...` result set.
fn ids(rows: Vec<Vec<Value>>) -> Vec<i64> {
    rows.into_iter()
        .map(|r| match r.into_iter().next() {
            Some(Value::Integer(i)) => i,
            other => panic!("expected an integer id in first column, got {other:?}"),
        })
        .collect()
}

#[test]
fn basic_fts_roundtrip() {
    let db = fts_db();
    let conn = db.connect_limbo();

    limbo_exec_rows(
        &conn,
        "CREATE TABLE docs (id INTEGER PRIMARY KEY, body TEXT)",
    );
    limbo_exec_rows(&conn, "CREATE INDEX docs_fts ON docs USING fts(body)");

    limbo_exec_rows(&conn, "INSERT INTO docs VALUES (1, 'the quick brown fox')");
    limbo_exec_rows(&conn, "INSERT INTO docs VALUES (2, 'lazy dogs sleep')");
    limbo_exec_rows(&conn, "INSERT INTO docs VALUES (3, 'a quick red fox')");

    // Term present in rows 1 and 3 only.
    let quick = ids(limbo_exec_rows(
        &conn,
        "SELECT id FROM docs WHERE fts_match(body, 'quick') ORDER BY id",
    ));
    assert_eq!(
        quick,
        vec![1, 3],
        "fts_match('quick') must return exactly the matching rows"
    );

    // Term present in row 2 only.
    let dogs = ids(limbo_exec_rows(
        &conn,
        "SELECT id FROM docs WHERE fts_match(body, 'dogs') ORDER BY id",
    ));
    assert_eq!(dogs, vec![2], "fts_match('dogs') must return only row 2");

    // Term present in no row.
    let none = ids(limbo_exec_rows(
        &conn,
        "SELECT id FROM docs WHERE fts_match(body, 'elephant') ORDER BY id",
    ));
    assert!(
        none.is_empty(),
        "fts_match for an absent term must return no rows, got {none:?}"
    );
}
