#!/usr/bin/env bash
# Structural verifier: the FTS-bearing crates still compile with the `fts`
# feature after the agent's change. This is the compile/consistency gate — the
# FTS module rewrite, the MVCC conflict-validation change, the storage Corrupt
# returns, and the VDBE finalisation must stay consistent across the workspace.
#
# Pure `cargo check` (no test run): compiles `turso_core` (the library that owns
# the index-method trait, the MVCC maps, the B-tree storage, and the VDBE) and
# `core_tester` (the integration-test crate's library) with the `fts` feature.
# Runs from the repo root so the workspace Cargo.lock governs resolution. The
# image pre-built the workspace with --all-features, so this is incremental.
set -euo pipefail

# Fresh Modal phase: re-export the toolchain baked by the image.
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export PATH="$CARGO_HOME/bin:$PATH"

# verify.toml [shell] sets cwd to the repo dir (/repo/turso), but be explicit.
cd /repo/turso

echo "verify_build: $(rustc --version), $(cargo --version | head -1)"

echo "verify_build: cargo check -p turso_core --features fts"
cargo check -p turso_core --features fts

echo "verify_build: cargo check -p core_tester --features fts"
cargo check -p core_tester --features fts

echo "verify_build: OK — FTS-enabled crates compile."
