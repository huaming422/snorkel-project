## Task

Some of the geometry fits give wrong results when they run inside a mixed-precision `torch.autocast` block. It shows up in the homography fits, the fundamental-matrix fits and RANSAC on point correspondences.

With ordinary float32 points, a fit called inside autocast comes back in a lower-precision dtype, and its values drift noticeably from the same call made outside the block. On GPU it's worse: some of these fits raise NotImplementedError under autocast instead of returning anything. Outside autocast the same fits are correct.

Callers shouldn't need to care whether they're inside autocast. A float32 fit should come back with the same dtype and exactly the same values either way. Two things work today and have to keep working: the homography and fundamental-matrix fits infer output shapes on meta tensors, and they trace with `torch.compile(fullgraph=True)`. The compiled trace also works on meta inputs for the homography fits and the 8-point fundamental fit.
