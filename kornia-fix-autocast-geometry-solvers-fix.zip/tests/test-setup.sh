#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (inherits set -euo pipefail).
# Pure-library task: no services to start, no data to seed. The only job here is to
# bring the repo's dependency closure online from the image bake, offline-first.
cd /repo/kornia

# Fail fast on a cache miss instead of silently reaching for a registry. uv can
# re-resolve a dynamic-versioned editable's build backend from PyPI once its index
# cache goes stale, so force offline for this grade-time step (the image already
# baked the full closure at the base commit via `uv sync --frozen --all-extras`).
export UV_OFFLINE=1

# Dependencies: offline-first against the image bake, logged online fallback.
# Check the exit status directly — never `| tail`, which would mask it and keep the
# fallback from ever firing.
if uv sync --frozen --all-extras > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] uv sync satisfied from image"
elif { unset UV_OFFLINE; uv sync --frozen --all-extras >> /tmp/test-setup-install.log 2>&1; }; then
    echo "[test-setup] deps installed online (image bake was stale)"
else
    tail -40 /tmp/test-setup-install.log >&2
    exit 1
fi
