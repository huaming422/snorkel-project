//! Behavioural checks for hoisted-layout shared-version placement.
//!
//! These drive the PRE-EXISTING, stable public entry point
//! `aube_linker::HoistedPlacements::from_graph(root, graph,
//! modules_dir_name, HoistingLimits)` and assert only on the observable
//! placement map it returns (`package_dir` / `all_package_dirs`). Nothing
//! here names an internal planner function, data structure, or counter, so
//! any layout planner that produces the correct placements passes
//! regardless of how it is built.
//!
//! `from_graph` records a placement only for a candidate directory that
//! already exists on disk (it is designed to reconstruct the layout of an
//! already-linked tree without touching disk). So every test first
//! pre-creates each candidate `node_modules/<name>` directory in a
//! tempdir, exactly as the crate's existing `from_graph_*` tests do, then
//! inspects which version landed at the shared workspace-root slot versus
//! which nested under an importer.
//!
//! The `dep` / `pkg` constructors below rebuild the same in-memory graph
//! shapes the crate's in-source tests use, from the public
//! `DirectDep` / `LockedPackage` fields (the in-source helpers are private
//! to that module and not reachable from an integration test).

use aube_linker::{HoistedPlacements, HoistingLimits};
use aube_lockfile::{DepType, DirectDep, LocalSource, LockedPackage, LockfileGraph};
use std::fs;
use std::path::{Path, PathBuf};

fn dep(name: &str, dep_path: &str) -> DirectDep {
    DirectDep {
        name: name.into(),
        dep_path: dep_path.into(),
        dep_type: DepType::Production,
        specifier: None,
    }
}

fn pkg(name: &str, version: &str, deps: &[(&str, &str)]) -> LockedPackage {
    LockedPackage {
        name: name.into(),
        version: version.into(),
        dep_path: format!("{name}@{version}"),
        dependencies: deps
            .iter()
            .map(|(dep_name, tail)| ((*dep_name).into(), (*tail).into()))
            .collect(),
        ..Default::default()
    }
}

/// Pre-create each candidate `node_modules/<name>` directory relative to
/// the workspace root so `from_graph` will record its placement.
fn precreate(root: &Path, rel_dirs: &[&str]) {
    for rel in rel_dirs {
        fs::create_dir_all(root.join(rel)).unwrap();
    }
}

/// The single shared workspace-root `node_modules/<name>` directory.
fn root_slot(root: &Path, name: &str) -> PathBuf {
    root.join("node_modules").join(name)
}

/// When two workspace packages disagree on the version of a shared
/// package, the version used by more of the workspace (counting distinct
/// dependents and peer-dependents) occupies the single top-level slot, and
/// the less-used version nests inside the importer that wants it.
///
/// Here `react@19.2.6` is used by one package directly plus a `zustand`
/// that peer-depends on it (two distinct users), while `react@19.2.3` is
/// used by one package. The shared slot must hold `react@19.2.6`.
#[test]
fn more_used_version_wins_shared_root_slot() {
    let root = tempfile::tempdir().unwrap();
    let rp = root.path();

    let zustand_dep_path = "zustand@5.0.11(react@19.2.6)";
    let mut graph = LockfileGraph::default();
    graph
        .importers
        .insert("packages/mobile".into(), vec![dep("react", "react@19.2.3")]);
    graph.importers.insert(
        "packages/web".into(),
        vec![
            dep("react", "react@19.2.6"),
            dep("zustand", zustand_dep_path),
        ],
    );
    graph
        .packages
        .insert("react@19.2.3".into(), pkg("react", "19.2.3", &[]));
    graph
        .packages
        .insert("react@19.2.6".into(), pkg("react", "19.2.6", &[]));
    let mut zustand = pkg("zustand", "5.0.11", &[("react", "19.2.6")]);
    zustand.dep_path = zustand_dep_path.into();
    zustand
        .peer_dependencies
        .insert("react".into(), ">=18.0.0".into());
    graph.packages.insert(zustand_dep_path.into(), zustand);

    precreate(
        rp,
        &[
            "node_modules/react",
            "node_modules/zustand",
            "packages/mobile/node_modules/react",
            "packages/web/node_modules/react",
        ],
    );

    let placements =
        HoistedPlacements::from_graph(rp, &graph, "node_modules", HoistingLimits::None).unwrap();

    assert_eq!(
        placements.package_dir("react@19.2.6"),
        Some(root_slot(rp, "react").as_path()),
        "the version used by more of the workspace must hold the shared root slot"
    );
    assert_eq!(
        placements.package_dir("react@19.2.3"),
        Some(rp.join("packages/mobile/node_modules/react").as_path()),
        "the less-used version must nest inside the importer that wants it"
    );
    assert_eq!(
        placements.package_dir("zustand@5.0.11(react@19.2.6)"),
        Some(root_slot(rp, "zustand").as_path())
    );
}

/// The preferred version is selected even when it is only reachable
/// through a dependency discovered later in the walk. A direct dependency
/// on the less-used version must not permanently claim the shared slot
/// before the more-used (transitive) version is found; the planner must
/// still terminate for every input.
///
/// `shared@2.0.0` is needed transitively by two consumers (two distinct
/// users); `shared@1.0.0` is a direct dependency of one importer. The
/// shared slot must hold `shared@2.0.0`, and `shared@1.0.0` must nest in
/// the importer that declares it.
#[test]
fn preferred_transitive_version_wins_over_earlier_direct_conflict() {
    let root = tempfile::tempdir().unwrap();
    let rp = root.path();

    let mut graph = LockfileGraph::default();
    graph
        .importers
        .insert("packages/first".into(), vec![dep("shared", "shared@1.0.0")]);
    graph.importers.insert(
        "packages/second".into(),
        vec![
            dep("consumer-a", "consumer-a@1.0.0"),
            dep("consumer-b", "consumer-b@1.0.0"),
        ],
    );
    graph
        .packages
        .insert("shared@1.0.0".into(), pkg("shared", "1.0.0", &[]));
    graph
        .packages
        .insert("shared@2.0.0".into(), pkg("shared", "2.0.0", &[]));
    for consumer in ["consumer-a", "consumer-b"] {
        graph.packages.insert(
            format!("{consumer}@1.0.0"),
            pkg(consumer, "1.0.0", &[("shared", "2.0.0")]),
        );
    }

    precreate(
        rp,
        &[
            "node_modules/shared",
            "node_modules/consumer-a",
            "node_modules/consumer-b",
            "packages/first/node_modules/shared",
            // Nesting sites the less-preferred layout would use.
            "node_modules/consumer-a/node_modules/shared",
            "node_modules/consumer-b/node_modules/shared",
        ],
    );

    let placements =
        HoistedPlacements::from_graph(rp, &graph, "node_modules", HoistingLimits::None).unwrap();

    assert_eq!(
        placements.package_dir("shared@2.0.0"),
        Some(root_slot(rp, "shared").as_path()),
        "the more-used transitive version must claim the shared root slot"
    );
    assert_eq!(
        placements.package_dir("shared@1.0.0"),
        Some(rp.join("packages/first/node_modules/shared").as_path()),
        "the earlier direct conflict must nest once the preferred version is found"
    );
}

/// A version pinned by an explicit top-level (workspace-root) dependency
/// holds the shared slot even when another version is used by more of the
/// workspace. The top-level declaration is an intentional, stronger signal
/// than raw usage counts.
///
/// The root project directly depends on `react@19.2.3`; a second importer
/// plus its transitive consumer use `react@19.2.6` (more usage). The
/// shared slot must still hold the root-declared `react@19.2.3`.
#[test]
fn explicit_top_level_dependency_keeps_shared_slot() {
    let root = tempfile::tempdir().unwrap();
    let rp = root.path();

    let mut graph = LockfileGraph::default();
    graph
        .importers
        .insert(".".into(), vec![dep("react", "react@19.2.3")]);
    graph.importers.insert(
        "packages/web".into(),
        vec![
            dep("react", "react@19.2.6"),
            dep("consumer", "consumer@1.0.0"),
        ],
    );
    graph
        .packages
        .insert("react@19.2.3".into(), pkg("react", "19.2.3", &[]));
    graph
        .packages
        .insert("react@19.2.6".into(), pkg("react", "19.2.6", &[]));
    graph.packages.insert(
        "consumer@1.0.0".into(),
        pkg("consumer", "1.0.0", &[("react", "19.2.6")]),
    );

    precreate(
        rp,
        &[
            "node_modules/react",
            "node_modules/consumer",
            "packages/web/node_modules/react",
            "node_modules/consumer/node_modules/react",
        ],
    );

    let placements =
        HoistedPlacements::from_graph(rp, &graph, "node_modules", HoistingLimits::None).unwrap();

    assert_eq!(
        placements.package_dir("react@19.2.3"),
        Some(root_slot(rp, "react").as_path()),
        "an explicit top-level dependency must win the shared slot over usage counts"
    );
    // The more-used version is shut out of the shared slot and nests.
    assert_ne!(
        placements.package_dir("react@19.2.6"),
        Some(root_slot(rp, "react").as_path()),
        "only one version may occupy the shared slot"
    );
}

/// When every workspace package agrees on the same version of a shared
/// package, that one copy stays deduplicated at the shared root slot — the
/// planner must not force private nested copies when there is no conflict.
#[test]
fn agreed_shared_version_stays_deduplicated_at_root() {
    let root = tempfile::tempdir().unwrap();
    let rp = root.path();

    let mut graph = LockfileGraph::default();
    graph
        .importers
        .insert("packages/app".into(), vec![dep("shared", "shared@1.0.0")]);
    graph
        .importers
        .insert("packages/lib".into(), vec![dep("shared", "shared@1.0.0")]);
    graph
        .packages
        .insert("shared@1.0.0".into(), pkg("shared", "1.0.0", &[]));

    precreate(
        rp,
        &[
            "node_modules/shared",
            "packages/app/node_modules/shared",
            "packages/lib/node_modules/shared",
        ],
    );

    let placements =
        HoistedPlacements::from_graph(rp, &graph, "node_modules", HoistingLimits::None).unwrap();

    assert_eq!(
        placements.package_dir("shared@1.0.0"),
        Some(root_slot(rp, "shared").as_path())
    );
    assert_eq!(
        placements.all_package_dirs("shared@1.0.0").len(),
        1,
        "an agreed shared version must be a single shared copy, not duplicated"
    );
}

/// A `link:` candidate is never eligible for the shared root slot, even
/// when it is the version most of the workspace references. A `link:` entry
/// is a live symlink into another workspace directory, not a store package
/// that can own the top-level slot, so selection must skip it and give the
/// slot to an eligible registry version used by fewer packages.
///
/// Three importers reference `shared` through `link:../shared`; one
/// importer references the registry `shared@2.0.0`. The shared slot must
/// hold `shared@2.0.0` — picking the more-referenced `link:` candidate
/// would be wrong.
#[test]
fn linked_candidate_never_wins_shared_slot() {
    let root = tempfile::tempdir().unwrap();
    let rp = root.path();

    let link_dep_path = "shared@link:../shared";
    let mut graph = LockfileGraph::default();
    graph
        .importers
        .insert("packages/a".into(), vec![dep("shared", "shared@2.0.0")]);
    for importer in ["packages/b", "packages/c", "packages/d"] {
        graph
            .importers
            .insert(importer.into(), vec![dep("shared", link_dep_path)]);
    }
    graph
        .packages
        .insert("shared@2.0.0".into(), pkg("shared", "2.0.0", &[]));
    let mut linked = pkg("shared", "0.0.0", &[]);
    linked.dep_path = link_dep_path.into();
    linked.local_source = Some(LocalSource::Link(PathBuf::from("packages/shared")));
    graph.packages.insert(link_dep_path.into(), linked);

    precreate(
        rp,
        &[
            "node_modules/shared",
            "packages/a/node_modules/shared",
            "packages/b/node_modules/shared",
            "packages/c/node_modules/shared",
            "packages/d/node_modules/shared",
        ],
    );

    let placements =
        HoistedPlacements::from_graph(rp, &graph, "node_modules", HoistingLimits::None).unwrap();

    assert_eq!(
        placements.package_dir("shared@2.0.0"),
        Some(root_slot(rp, "shared").as_path()),
        "the eligible registry version must win the shared slot over a more-referenced link: candidate"
    );
    assert_ne!(
        placements.package_dir(link_dep_path),
        Some(root_slot(rp, "shared").as_path()),
        "a link: candidate must never occupy the shared root slot"
    );
}

/// The shared-slot selection applies only to the fully-hoisting layout.
/// Under a per-workspace hoisting limit, a shared package stays local to
/// each importer and is NOT promoted to the top-level slot, exactly as
/// before — the selection logic must stay scoped to the full-hoist mode.
#[test]
fn per_workspace_hoisting_limit_is_unaffected() {
    let root = tempfile::tempdir().unwrap();
    let rp = root.path();

    let mut graph = LockfileGraph::default();
    graph
        .importers
        .insert("packages/app".into(), vec![dep("shared", "shared@1.0.0")]);
    graph
        .importers
        .insert("packages/lib".into(), vec![dep("shared", "shared@1.0.0")]);
    graph
        .packages
        .insert("shared@1.0.0".into(), pkg("shared", "1.0.0", &[]));

    precreate(
        rp,
        &[
            "node_modules/shared",
            "packages/app/node_modules/shared",
            "packages/lib/node_modules/shared",
        ],
    );

    let placements =
        HoistedPlacements::from_graph(rp, &graph, "node_modules", HoistingLimits::Workspaces)
            .unwrap();

    let sites = placements.all_package_dirs("shared@1.0.0");
    assert_eq!(
        sites.len(),
        2,
        "under a per-workspace limit each importer keeps its own copy"
    );
    assert!(
        sites.contains(&rp.join("packages/app/node_modules/shared"))
            && sites.contains(&rp.join("packages/lib/node_modules/shared")),
        "the shared package must stay importer-local, not hoisted to the root slot"
    );
}
