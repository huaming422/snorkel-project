import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import type { PrismaClient } from '@prisma/client'
import { afterEach, describe, expect, it } from 'vitest'

import {
  literatureCandidateInputSchema,
  type LiteratureCandidateInput
} from '../../shared/literature'
import { migrateApplicationDatabase } from '../database/migration-service'
import { createProjectDbClient } from '../projects/prisma-client'
import { LiteratureCatalog } from './catalog'

// Reference fixture persisted through the catalog's public command surface.
const candidate = (
  overrides: { doi?: string; title?: string } = {}
): LiteratureCandidateInput =>
  literatureCandidateInputSchema.parse({
    item: {
      itemType: 'journalArticle',
      title: overrides.title ?? 'Corrective Retrieval Augmented Generation',
      abstract: 'A retrieval evaluator improves retrieval-augmented generation.',
      issuedYear: 2024,
      creators: [
        { nameMode: 'person', givenName: 'Shi-Qi', familyName: 'Yan', creatorType: 'author' }
      ],
      identifiers: [
        { scheme: 'doi', value: overrides.doi ?? 'https://doi.org/10.1234/CRAG', isPrimary: true }
      ],
      typeFields: { volume: '1' }
    },
    source: {
      provider: 'crossref',
      externalId: '10.1234/crag',
      sourceUrl: 'https://example.test/paper',
      rawMetadata: { title: 'Corrective Retrieval Augmented Generation' }
    },
    origin: { kind: 'agent', projectId: 'project-1', sessionId: 'session-1' }
  })

describe('LiteratureCatalog lifecycle integrity', () => {
  let storageRoot: string | undefined
  let client: PrismaClient | undefined

  afterEach(async () => {
    await client?.$disconnect()
    if (storageRoot) await rm(storageRoot, { recursive: true, force: true })
  })

  // A real migrated SQLite database in a temp directory, driven only through the
  // catalog's command/query surface.
  const setup = async (): Promise<LiteratureCatalog> => {
    storageRoot = await mkdtemp(join(tmpdir(), 'open-science-literature-catalog-'))
    client = createProjectDbClient(storageRoot)
    await migrateApplicationDatabase(client)
    await client.project.create({ data: { id: 'project-1', name: 'Research' } })
    return new LiteratureCatalog(async () => client!)
  }

  // A lifecycle command that cannot apply to every reference it names must leave
  // the references it could have changed exactly as they were.
  it.each([
    ['deleted', 'missing'],
    ['active', 'missing'],
    ['deleted', 'alias'],
    ['active', 'alias']
  ] as const)(
    'rolls back an unavailable lifecycle batch when setting %s with a %s item',
    async (state, unavailable) => {
      const catalog = await setup()
      const item = await catalog.transact({ kind: 'create-item', item: candidate().item })
      let unavailableId = 'missing-item'
      if (unavailable === 'alias') {
        const alias = await catalog.transact({
          kind: 'create-item',
          item: candidate({ doi: '10.1234/alias', title: 'Alias' }).item
        })
        const reviewed = (await Promise.all([catalog.get(item.id), catalog.get(alias.id)])).map(
          (view) => view!
        )
        await catalog.transact({
          kind: 'merge-items',
          survivorId: item.id,
          duplicateIds: [alias.id],
          expectedMetadataRevision: reviewed[0].metadataRevision,
          expectedItems: reviewed.map(({ id, metadataRevision, updatedAt }) => ({
            id,
            metadataRevision,
            updatedAt
          })),
          item: reviewed[0].item
        })
        unavailableId = alias.id
      }
      if (state === 'active') {
        await catalog.transact({ kind: 'set-item-lifecycle', itemIds: [item.id], state: 'deleted' })
      }
      const before = await client!.literatureItem.findUniqueOrThrow({ where: { id: item.id } })
      await expect(
        catalog.transact({
          kind: 'set-item-lifecycle',
          itemIds: [item.id, unavailableId],
          state
        })
      ).rejects.toThrow()
      const after = await client!.literatureItem.findUniqueOrThrow({ where: { id: item.id } })
      expect(after.deletedAt).toEqual(before.deletedAt)
    }
  )

  // Project and collection navigation counts reflect only the references a user
  // would actually see, and a trashed reference's membership returns on restore.
  it.each(['project', 'collection'] as const)(
    'counts only visible references in %s navigation while preserving restore links',
    async (scope) => {
      const catalog = await setup()
      const item = await catalog.transact({ kind: 'create-item', item: candidate().item })
      const collection = await catalog.transact({ kind: 'create-collection', name: 'Reading' })
      await catalog.transact({
        kind: 'set-project-item',
        projectId: 'project-1',
        itemId: item.id,
        included: true,
        source: 'library'
      })
      await catalog.transact({
        kind: 'set-collection-item',
        collectionId: collection.id,
        itemId: item.id,
        included: true
      })
      for (const state of ['active', 'deleted', 'active'] as const) {
        await catalog.transact({ kind: 'set-item-lifecycle', itemIds: [item.id], state })
        const list = await catalog.search({
          scope: 'library',
          ...(scope === 'project' ? { projectId: 'project-1' } : { collectionId: collection.id })
        })
        expect(list.totalCount).toBe(state === 'deleted' ? 0 : 1)
        const navigation = await catalog.search({
          scope: scope === 'project' ? 'project-counts' : 'collections'
        })
        const row = navigation.entries.find((entry) =>
          scope === 'project'
            ? 'projectId' in entry && entry.projectId === 'project-1'
            : 'id' in entry && entry.id === collection.id
        )
        expect(row && 'itemCount' in row ? row.itemCount : 0).toBe(list.totalCount)
      }
    }
  )
})
