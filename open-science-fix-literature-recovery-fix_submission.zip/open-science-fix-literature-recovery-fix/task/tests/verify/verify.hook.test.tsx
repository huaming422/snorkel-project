// @vitest-environment jsdom
import { act, cleanup, renderHook, type RenderHookResult } from '@testing-library/react'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import {
  literatureItemInputSchema,
  type LiteratureCatalogSearchPage,
  type LiteratureCatalogSearchRequest
} from '../../../../shared/literature'
import { useLiteratureEntries } from './useLiteratureEntries'

const page: LiteratureCatalogSearchPage = { entries: [], totalCount: 0 }
const search =
  vi.fn<(request: LiteratureCatalogSearchRequest) => Promise<LiteratureCatalogSearchPage>>()
const request: LiteratureCatalogSearchRequest = { scope: 'library', offset: 0, limit: 50 }

type HookProps = { enabled: boolean; scopeKey: string; request: LiteratureCatalogSearchRequest }

const setup = (): RenderHookResult<ReturnType<typeof useLiteratureEntries>, HookProps> & {
  onPage: ReturnType<typeof vi.fn>
  onError: ReturnType<typeof vi.fn>
} => {
  const onPage = vi.fn()
  const onEmptyPage = vi.fn()
  const onError = vi.fn()
  return {
    onPage,
    onError,
    ...renderHook<ReturnType<typeof useLiteratureEntries>, HookProps>(
      ({ enabled, scopeKey, request }) =>
        useLiteratureEntries({ enabled, scopeKey, request, onPage, onEmptyPage, onError }),
      { initialProps: { enabled: true, scopeKey: 'library', request } }
    )
  }
}

describe('useLiteratureEntries failed-load handling', () => {
  beforeEach(() => {
    vi.useFakeTimers()
    search.mockReset().mockResolvedValue(page)
    Object.defineProperty(window, 'api', { configurable: true, value: { literature: { search } } })
  })

  afterEach(() => {
    cleanup()
    vi.useRealTimers()
  })

  // A failed request — initial, a next-page navigation, or a filter change — must
  // end the loading state (no infinite spinner), report the error through the
  // callback, and recover cleanly when the caller reloads.
  it.each(['initial', 'next page', 'filter'] as const)(
    'ends loading after a failed %s request and permits retry',
    async (kind) => {
      if (kind === 'initial') search.mockRejectedValueOnce(new Error('Unavailable'))
      const { result, rerender, onError } = setup()
      await act(async () => {})
      if (kind !== 'initial') {
        search.mockRejectedValueOnce(new Error('Unavailable'))
        rerender({
          enabled: true,
          scopeKey: kind === 'filter' ? 'filtered' : 'library',
          request: { ...request, ...(kind === 'filter' ? { query: 'new' } : { offset: 50 }) }
        })
        await act(async () => {
          await vi.runAllTimersAsync()
        })
      }
      expect(onError).toHaveBeenLastCalledWith(true)
      expect(result.current.loading).toBe(false)
      expect(result.current.pageTransitionLoading).toBe(false)
      search.mockResolvedValueOnce({
        entries: [
          {
            id: 'retry',
            item: literatureItemInputSchema.parse({
              itemType: 'journalArticle',
              title: 'Recovered'
            }),
            attachments: [],
            collectionIds: [],
            projectIds: [],
            metadataRevision: 1,
            createdAt: 1,
            updatedAt: 1
          }
        ],
        totalCount: 51
      })
      await act(() => result.current.reload(true))
      expect(onError).toHaveBeenLastCalledWith(false)
      expect(result.current.loading).toBe(false)
    }
  )

  // Returning to an already-loaded scope after a failed one must reuse the cached
  // page, clear the error, and issue no redundant refetch.
  it('returns from a failed scope to the cached page without another request', async () => {
    const { result, rerender, onError, onPage } = setup()
    await act(async () => {})
    search.mockRejectedValueOnce(new Error('Unavailable'))
    rerender({ enabled: true, scopeKey: 'filtered', request: { ...request, query: 'new' } })
    await act(async () => {})
    expect(onError).toHaveBeenLastCalledWith(true)
    rerender({ enabled: true, scopeKey: 'library', request })
    await act(async () => {})
    expect(onError).toHaveBeenLastCalledWith(false)
    expect(result.current.loading).toBe(false)
    expect(onPage).toHaveBeenCalledTimes(1)
    expect(onPage).toHaveBeenLastCalledWith(page, request, false)
    expect(search).toHaveBeenCalledTimes(2)
  })

  // A late-arriving rejection from a superseded scope must not clobber a newer
  // scope that already succeeded.
  it('ignores an old rejection after a new scope succeeds', async () => {
    let reject: (error: Error) => void = () => {}
    search.mockImplementationOnce(
      () =>
        new Promise((_, fail) => {
          reject = fail
        })
    )
    const { result, rerender, onError } = setup()
    rerender({ enabled: true, scopeKey: 'filtered', request: { ...request, query: 'new' } })
    await act(async () => {})
    await act(async () => reject(new Error('Old failure')))
    expect(onError).not.toHaveBeenCalledWith(true)
    expect(result.current.loading).toBe(false)
  })
})
