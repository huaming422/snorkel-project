## Task

the References library has gotten flaky and we're getting a cluster of reports. it all used to behave sensibly; now bits of it misfire, leaving people stuck or staring at wrong numbers. some of it:

- when a reference search fails, the list sometimes spins forever instead of surfacing an error they can retry from.
- bulk Trash or Restore across a big multi-page selection sometimes only half-lands: some references flip, the operation reports an error, and the page is left inconsistent, with the already-changed rows still showing and no clean way to retry just the ones that failed.
- edits typed into a reference's metadata form while a save is in flight get thrown away.
- the sidebar project and collection counts keep tallying references moved to Trash, so the numbers read wrong.
- the full list of collections cuts off at the first hundred, so anything past that is unreachable.

dig in and make the library solid again. keep it to a behavior fix: no data model or stored-format changes, and already-saved libraries must still load fine.
