#!/usr/bin/env bash
# Environment bootstrap for the verifier (runs in the verifier phase; network is
# an allowlist of only the model gateway). The frontend dependency closure was
# baked into the image at build time (`npm ci` in superset-frontend), so this
# script installs nothing from the network — it only asserts the closure is
# present and flips npm into offline mode so a cache miss fails fast instead of
# hanging against a dead network.
#
# Sourced (not exec'd) by the harbor runner so env vars set here stay live for
# the verifier subprocess.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/superset}"
export REPO_DIR
FE_DIR="${REPO_DIR}/superset-frontend"

# The harbor runner parses verify.toml with the canonical /opt/tooling venv
# (Python 3.12, tomllib built in), so no tomli shim is needed here.

# Make every npm invocation offline from here on: only the task's own npm sees
# this (it is NOT baked as image ENV, which would break harbor's own
# `uv tool install` at trial prep). A cache miss now errors immediately.
export npm_config_offline=true
export npm_config_cache=/opt/npm-cache

# Sanity check: node_modules must be present from the baked `npm ci`. A failure
# here points at a corrupted image, not a missing install — bail loudly rather
# than let jest emit a confusing "Cannot find module" later.
if [ ! -x "${FE_DIR}/node_modules/.bin/jest" ]; then
    echo "test-setup.sh: jest binary missing from ${FE_DIR}/node_modules/.bin/. " \
         "The baked frontend dependency closure is incomplete." >&2
    exit 1
fi

echo "test-setup.sh: ready. REPO_DIR=${REPO_DIR} node=$(node --version) jest=$("${FE_DIR}/node_modules/.bin/jest" --version 2>/dev/null || echo unknown)"
