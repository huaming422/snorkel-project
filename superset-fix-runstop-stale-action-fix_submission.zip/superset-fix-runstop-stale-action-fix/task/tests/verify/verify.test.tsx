/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

// Behavioral checks for the Run/Stop control's gesture handling, driven only
// through each component's pre-existing stable interface:
//   - SQL Lab  RunQueryActionButton: queryState prop + runQuery/stopQuery spies
//     (its redux-dispatched callbacks), rendered with the repo custom render.
//   - Explore  RunQueryButton:       loading prop + onQuery/onStop spies.
// Nothing here imports the gesture hook, the split-button guard, or any symbol
// the fix introduces — an equivalent fix stored in refs/reducer/state machine,
// named/placed differently, or inlined per component passes identically.
//
// The contract these checks encode: the action that runs is the one the button
// showed when the interaction STARTED. When the running state flips mid-press
// so the button now shows the opposite action, releasing the press must NOT run
// that opposite action — the stale, already-finished action is simply dropped,
// so NEITHER callback fires. A fresh, uninterrupted activation still fires the
// shown action across mouse / touch-compat MouseEvent / Enter / Space / detail-0.

// @ts-nocheck
import configureStore from 'redux-mock-store';
import thunk from 'redux-thunk';

import { act, render, fireEvent, screen } from 'spec/helpers/testing-library';
import { initialState, defaultQueryEditor } from 'src/SqlLab/fixtures';
import RunQueryActionButton from 'src/SqlLab/components/RunQueryActionButton';
import { RunQueryButton } from 'src/explore/components/RunQueryButton';

// --- Native DOM event synthesis -------------------------------------------
// JSDOM has no real PointerEvent and does not synthesize the browser's native
// button activation (Enter-on-keydown / Space-on-keyup) or the compatibility
// MouseEvent that follows a touch/pen release. These four helpers reproduce
// those native sequences so the checks exercise what a real browser delivers.

/** Dispatch pointer metadata even when JSDOM does not implement PointerEvent. */
const pointerEvent = (
  type: string,
  target: Element,
  pointerId = 1,
  pointerType = 'mouse',
) =>
  fireEvent(
    target,
    Object.assign(
      new MouseEvent(type, { bubbles: true, cancelable: true, detail: 1 }),
      { pointerId, pointerType },
    ),
  );

/** A compatibility click after touch/pen: a MouseEvent with no pointer identity. */
const mouseClick = (target: Element) =>
  fireEvent(
    target,
    new MouseEvent('click', { bubbles: true, cancelable: true, detail: 1 }),
  );

/** A native button fires its click on each Enter keydown unless prevented. */
const keyDown = (target: HTMLElement, key: string, repeat = false) => {
  if (fireEvent.keyDown(target, { key, repeat }) && key === 'Enter') {
    fireEvent.click(target, { detail: 0 });
  }
};

/** A native button fires its click when Space is released unless prevented. */
const keyUp = (target: HTMLElement, key: string) => {
  if (fireEvent.keyUp(target, { key }) && key === ' ') {
    fireEvent.click(target, { detail: 0 });
  }
};

const flushTimers = () =>
  act(() => new Promise(resolve => setTimeout(resolve, 0)));

// --------------------------------------------------------------------------
// SQL Lab stack
// --------------------------------------------------------------------------

const middlewares = [thunk];
const mockStore = configureStore(middlewares);

const sqlLabBaseProps = {
  queryEditorId: defaultQueryEditor.id,
  dbId: 1,
  selectedText: null,
  overlayCreateAsMenu: null,
};

const renderSqlLab = (startState = 'running') => {
  const runQuery = jest.fn();
  const stopQuery = jest.fn();
  const store = mockStore(initialState);
  const element = (queryState: string) => (
    <RunQueryActionButton
      {...sqlLabBaseProps}
      queryState={queryState}
      runQuery={runQuery}
      stopQuery={stopQuery}
    />
  );
  const utils = render(element(startState), { useRedux: true, store });
  const switchTo = (queryState: string) => utils.rerender(element(queryState));
  return { ...utils, runQuery, stopQuery, switchTo };
};

describe('RunQueryActionButton (SQL Lab) gesture handling', () => {
  // C1 (fail_to_pass): a pointer press begun on Stop must not run the query
  // after the query finishes and the button flips to Run under the cursor.
  test('pointer press begun on Stop does not run after completion', () => {
    const { getByRole, getByText, runQuery, stopQuery, switchTo } =
      renderSqlLab('running');
    const button = getByRole('button');
    expect(getByText('Stop')).toBeInTheDocument();

    pointerEvent('pointerdown', button);
    fireEvent.mouseDown(button);
    switchTo('success');
    expect(getByText('Run')).toBeInTheDocument();
    pointerEvent('pointerup', button);
    fireEvent.mouseUp(button);
    pointerEvent('click', button);

    // The stale Stop is dropped and the opposite Run is suppressed: neither
    // fires. Pre-fix, the flipped-to Run action runs here.
    expect(runQuery).not.toHaveBeenCalled();
    expect(stopQuery).not.toHaveBeenCalled();
  });

  // C2 (fail_to_pass): mirror case — a press begun on Run must not stop a query
  // that started mid-press and flipped the button to Stop.
  test('pointer press begun on Run does not stop after the query starts', () => {
    const { getByRole, runQuery, stopQuery, switchTo } = renderSqlLab('running');
    switchTo('success');
    const button = getByRole('button');

    pointerEvent('pointerdown', button);
    switchTo('running');
    pointerEvent('click', button);

    expect(runQuery).not.toHaveBeenCalled();
    expect(stopQuery).not.toHaveBeenCalled();
  });

  // C4 (fail_to_pass): a touch release arrives as a compatibility MouseEvent
  // (a click with no pointerId, positive detail). It must resolve to the
  // gesture-start action, so a Stop press held across completion still does not
  // run. A mouse-only fix that keys solely off pointerup mishandles this.
  test('touch compatibility click begun on Stop does not run after completion', async () => {
    const { getByRole, runQuery, stopQuery, switchTo } = renderSqlLab('running');
    const button = getByRole('button');

    pointerEvent('pointerdown', button, 7, 'touch');
    switchTo('success');
    pointerEvent('pointerup', button, 7, 'touch');
    pointerEvent('lostpointercapture', button, 7, 'touch');
    await flushTimers();
    mouseClick(button);

    expect(runQuery).not.toHaveBeenCalled();
    expect(stopQuery).not.toHaveBeenCalled();

    // The compatibility click consumed that press; a later real pointer click
    // runs the now-shown action normally.
    pointerEvent('click', button, 7, 'touch');
    expect(runQuery).toHaveBeenCalledTimes(1);
  });

  // C5a (fail_to_pass): Enter activates a native button on keydown. A held
  // Enter begun on Stop must not run after the query completes; auto-repeat
  // keydowns during the completed state are not fresh intent.
  test('held Enter begun on Stop does not run after completion', () => {
    const { getByRole, runQuery, stopQuery, switchTo } = renderSqlLab('running');
    const button = getByRole('button');

    keyDown(button, 'Enter');
    expect(stopQuery).toHaveBeenCalledTimes(1);
    switchTo('success');
    keyDown(button, 'Enter', true);
    keyDown(button, 'Enter', true);
    fireEvent.keyUp(button, { key: 'Enter', code: 'Enter' });

    expect(runQuery).not.toHaveBeenCalled();
    expect(stopQuery).toHaveBeenCalledTimes(1);

    // A fresh Enter after completion runs normally.
    keyDown(button, 'Enter');
    fireEvent.keyUp(button, { key: 'Enter', code: 'Enter' });
    expect(runQuery).toHaveBeenCalledTimes(1);
  });

  // C5b (fail_to_pass): Space activates a native button on keyup, not keydown —
  // a different "gesture start" moment than Enter. A Space press begun on Stop
  // must not run after completion.
  test('held Space begun on Stop does not run after completion', () => {
    const { getByRole, runQuery, stopQuery, switchTo } = renderSqlLab('running');
    const button = getByRole('button');

    keyDown(button, ' ');
    switchTo('success');
    keyDown(button, ' ', true);
    keyUp(button, ' ');

    expect(runQuery).not.toHaveBeenCalled();
    expect(stopQuery).not.toHaveBeenCalled();
  });

  // C6 (fail_to_pass): Escape (or blur) during a pending press cancels it, so
  // the later release fires nothing.
  test('Escape during a Space press cancels it — release runs nothing', () => {
    const { getByRole, runQuery, stopQuery, switchTo } = renderSqlLab('running');
    const button = getByRole('button');

    keyDown(button, ' ');
    switchTo('success');
    fireEvent.keyDown(button, { key: 'Escape', code: 'Escape' });
    keyUp(button, ' ');

    expect(runQuery).not.toHaveBeenCalled();
    expect(stopQuery).not.toHaveBeenCalled();
  });

  test('blur during a Space press cancels it — release runs nothing', () => {
    const { getByRole, runQuery, stopQuery, switchTo } = renderSqlLab('running');
    const button = getByRole('button');

    keyDown(button, ' ');
    fireEvent.blur(button);
    switchTo('success');
    keyUp(button, ' ');

    expect(runQuery).not.toHaveBeenCalled();
    expect(stopQuery).not.toHaveBeenCalled();
  });

  // C7 (pass_to_pass): an assistive-tech / programmatic activation arrives as a
  // detail-0 click with no preceding press. It must fire the currently-shown
  // action, not be swallowed.
  test('a detail-0 click with no prior press runs the shown action', () => {
    const { getByRole, runQuery, stopQuery, switchTo } = renderSqlLab('running');
    switchTo('success');
    const button = getByRole('button');

    fireEvent.click(button, { detail: 0 });

    expect(runQuery).toHaveBeenCalledTimes(1);
    expect(stopQuery).not.toHaveBeenCalled();
  });

  // C8 (pass_to_pass): the ordinary uninterrupted path must keep working —
  // a stable-state press+release+click fires the shown action, both ways.
  test('a normal click on Run runs, and on Stop stops', () => {
    const run = renderSqlLab('success');
    const runButton = run.getByRole('button');
    pointerEvent('pointerdown', runButton);
    pointerEvent('pointerup', runButton);
    pointerEvent('click', runButton);
    expect(run.runQuery).toHaveBeenCalledTimes(1);
    expect(run.stopQuery).not.toHaveBeenCalled();
    run.unmount();

    const stop = renderSqlLab('running');
    const stopButton = stop.getByRole('button');
    pointerEvent('pointerdown', stopButton);
    pointerEvent('pointerup', stopButton);
    pointerEvent('click', stopButton);
    expect(stop.stopQuery).toHaveBeenCalledTimes(1);
    expect(stop.runQuery).not.toHaveBeenCalled();
  });
});

// --------------------------------------------------------------------------
// Explore (chart builder) stack
// --------------------------------------------------------------------------

const exploreProps = (overrides: Record<string, any> = {}) => ({
  loading: false,
  onQuery: jest.fn(),
  onStop: jest.fn(),
  errorMessage: null,
  isNewChart: false,
  canStopQuery: true,
  chartIsStale: true,
  ...overrides,
});

const renderExplore = (startLoading = true) => {
  const props = exploreProps({ loading: startLoading });
  const utils = render(<RunQueryButton {...props} />);
  const finishQuery = () =>
    utils.rerender(<RunQueryButton {...props} loading={false} />);
  const startQuery = () =>
    utils.rerender(<RunQueryButton {...props} loading />);
  return { ...utils, ...props, finishQuery, startQuery };
};

describe('RunQueryButton (Explore) gesture handling', () => {
  // C3 (fail_to_pass): a pointer press begun on Stop must not update the chart
  // after the build completes and the button flips to Update chart.
  test('pointer press begun on Stop does not update the chart after completion', () => {
    const { onQuery, onStop, finishQuery } = renderExplore(true);
    const button = screen.getByRole('button', { name: /Stop/ });

    pointerEvent('pointerdown', button);
    fireEvent.mouseDown(button);
    finishQuery();
    expect(screen.getByRole('button', { name: 'Update chart' })).toBe(button);
    pointerEvent('pointerup', button);
    fireEvent.mouseUp(button);
    pointerEvent('click', button);

    expect(onQuery).not.toHaveBeenCalled();
    expect(onStop).not.toHaveBeenCalled();

    // A fresh press after completion updates the chart normally.
    pointerEvent('pointerdown', button);
    pointerEvent('click', button);
    expect(onQuery).toHaveBeenCalledTimes(1);
  });

  // C3b (fail_to_pass): mirror case on the Explore stack — a press begun on
  // Update chart must not rebuild the chart if the query starts mid-press and
  // the button flips to Stop. This is the decisive drop-vs-replay case: onQuery
  // (triggerQuery) dispatches unconditionally, so replaying the gesture-start
  // action here would fire a second build — the bug — hence the stale press is
  // dropped and NEITHER callback fires.
  test('pointer press begun on Update chart does not rebuild after the query starts', () => {
    const { onQuery, onStop, startQuery } = renderExplore(false);
    const button = screen.getByRole('button', { name: 'Update chart' });

    pointerEvent('pointerdown', button);
    fireEvent.mouseDown(button);
    startQuery();
    pointerEvent('pointerup', button);
    fireEvent.mouseUp(button);
    pointerEvent('click', button);

    expect(onQuery).not.toHaveBeenCalled();
    expect(onStop).not.toHaveBeenCalled();
  });

  // C4 (fail_to_pass): touch compatibility MouseEvent on the Explore stack.
  test('touch compatibility click begun on Stop does not update after completion', async () => {
    const { onQuery, onStop, finishQuery } = renderExplore(true);
    const button = screen.getByRole('button');

    pointerEvent('pointerdown', button, 7, 'touch');
    finishQuery();
    pointerEvent('pointerup', button, 7, 'touch');
    pointerEvent('lostpointercapture', button, 7, 'touch');
    await flushTimers();
    mouseClick(button);

    expect(onQuery).not.toHaveBeenCalled();
    expect(onStop).not.toHaveBeenCalled();

    pointerEvent('click', button, 7, 'touch');
    expect(onQuery).toHaveBeenCalledTimes(1);
  });

  // C5 (fail_to_pass): Enter (keydown) and Space (keyup) gesture-start on Explore.
  test('held Enter begun on Stop does not update after completion', () => {
    const { onQuery, onStop, finishQuery } = renderExplore(true);
    const button = screen.getByRole('button', { name: /Stop/ });

    keyDown(button, 'Enter');
    expect(onStop).toHaveBeenCalledTimes(1);
    finishQuery();
    keyDown(button, 'Enter', true);
    fireEvent.keyUp(button, { key: 'Enter', code: 'Enter' });

    expect(onQuery).not.toHaveBeenCalled();
    expect(onStop).toHaveBeenCalledTimes(1);

    keyDown(button, 'Enter');
    fireEvent.keyUp(button, { key: 'Enter', code: 'Enter' });
    expect(onQuery).toHaveBeenCalledTimes(1);
  });

  test('held Space begun on Stop does not update after completion', () => {
    const { onQuery, onStop, finishQuery } = renderExplore(true);
    const button = screen.getByRole('button', { name: /Stop/ });

    keyDown(button, ' ');
    finishQuery();
    keyDown(button, ' ', true);
    keyUp(button, ' ');

    expect(onQuery).not.toHaveBeenCalled();
    expect(onStop).not.toHaveBeenCalled();
  });

  // C6 (fail_to_pass): Escape cancels a pending Space press on Explore.
  test('Escape during a Space press cancels it — release updates nothing', () => {
    const { onQuery, onStop, finishQuery } = renderExplore(true);
    const button = screen.getByRole('button');

    keyDown(button, ' ');
    finishQuery();
    fireEvent.keyDown(button, { key: 'Escape', code: 'Escape' });
    keyUp(button, ' ');

    expect(onQuery).not.toHaveBeenCalled();
    expect(onStop).not.toHaveBeenCalled();
  });

  // C7 (pass_to_pass): detail-0 assistive-tech click fires the shown action.
  test('a detail-0 click with no prior press updates the chart', () => {
    const { onQuery, onStop, finishQuery } = renderExplore(true);
    finishQuery();
    const button = screen.getByRole('button', { name: 'Update chart' });

    fireEvent.click(button, { detail: 0 });

    expect(onQuery).toHaveBeenCalledTimes(1);
    expect(onStop).not.toHaveBeenCalled();
  });

  // C8 (pass_to_pass): ordinary uninterrupted path on Explore, both ways.
  test('a normal click on Update chart runs, and on Stop stops', () => {
    const run = renderExplore(false);
    const runButton = screen.getByRole('button', { name: 'Update chart' });
    pointerEvent('pointerdown', runButton);
    pointerEvent('pointerup', runButton);
    pointerEvent('click', runButton);
    expect(run.onQuery).toHaveBeenCalledTimes(1);
    expect(run.onStop).not.toHaveBeenCalled();

    run.unmount();

    const stop = renderExplore(true);
    const stopButton = screen.getByRole('button', { name: /Stop/ });
    pointerEvent('pointerdown', stopButton);
    pointerEvent('pointerup', stopButton);
    pointerEvent('click', stopButton);
    expect(stop.onStop).toHaveBeenCalledTimes(1);
    expect(stop.onQuery).not.toHaveBeenCalled();
  });
});
