#!/usr/bin/env bash
#
# Sourced (not exec'd) by tests/test.sh before every verifier, under
# `set -euo pipefail`. Re-asserts the Go build environment defensively in case
# the agent's edits or a wiped layer touched it, and brings the baked module
# cache online without the network.
#
# This is a pure-library Go task: no services to start, no data to seed, no
# assertion logic here.

REPO_DIR="${REPO_DIR:-/repo/tailscale}"
cd "$REPO_DIR"

# Run against the toolchain baked in the image (go.mod declares an older
# language version with no `toolchain` directive, so `local` pins the installed
# compiler). Cut the network immediately so a cache miss fails fast instead of
# reaching for a proxy — the image warmed the full module cache at the base
# commit, including the fix's go-json-experiment subpackage.
export GOTOOLCHAIN=local
export GOFLAGS=-mod=mod
export GOPROXY=off
export CGO_ENABLED=1

# Make `go` reachable even if the harness scrubbed PATH.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

# Dependencies: offline-first against the image bake, logged online fallback.
# The image pre-warmed GOMODCACHE at the base commit; offline is the expected
# path. The fallback only fires if the bake was stale (and only has network
# when the verifier runs online — the smoke gate's offline fold deliberately
# exercises the offline branch with the network cut).
if go mod download > /tmp/test-setup-godl.log 2>&1; then
    echo "[offline-first] go modules satisfied from image cache"
elif GOPROXY=https://proxy.golang.org,direct GOFLAGS=-mod=mod go mod download >> /tmp/test-setup-godl.log 2>&1; then
    echo "[test-setup] go modules downloaded online (image bake was stale)"
else
    tail -40 /tmp/test-setup-godl.log >&2
    exit 1
fi

echo "test-setup.sh: ready (GOTOOLCHAIN=local, GOFLAGS=$GOFLAGS, GOPROXY=$GOPROXY, CGO_ENABLED=$CGO_ENABLED)"
