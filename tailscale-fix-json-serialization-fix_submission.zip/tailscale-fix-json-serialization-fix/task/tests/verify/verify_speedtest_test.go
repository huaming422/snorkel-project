// Copyright (c) Tailscale Inc & contributors
// SPDX-License-Identifier: BSD-3-Clause

// Behavioral verifier: the net/speedtest handshake config round-trips through
// encoding/json under the image's Go toolchain, with its duration field staying
// an int64 nanosecond count.
//
// The speedtest config carries a time.Duration in the same class of struct tag
// that broke the netmap decode. The config type is unexported, so this is a
// same-package (package speedtest) test — the highest level at which this
// behavior is observable, since no higher interface exposes the config's JSON
// encoding. It drives the standard library encoding/json entry points against a
// config value and asserts the exact wire bytes; it never inspects struct tags
// or implementation internals, so every wire-preserving fix passes.
//
// Injected into package speedtest at grade time and run in isolation via the Go
// runner's -run filter.
package speedtest

import (
	"encoding/json"
	"reflect"
	"testing"
	"time"
)

// TestVerifySpeedtestConfigDurationRoundTrip asserts that the speedtest config
// marshals and unmarshals without error under the current toolchain and that
// the duration field is encoded as an int64 nanosecond count (byte-stable wire
// format).
func TestVerifySpeedtestConfigDurationRoundTrip(t *testing.T) {
	in := config{
		Version:      version, // pre-existing package-internal constant
		TestDuration: 5 * time.Second,
		Direction:    Download,
	}

	got, err := json.Marshal(in)
	if err != nil {
		t.Fatalf("json.Marshal(config) returned error: %v\n"+
			"the handshake config must marshal cleanly under this toolchain", err)
	}

	// Exact wire format: version int, duration as int64 nanoseconds under key
	// "time", direction as its int zero value. 5s == 5000000000 ns.
	const want = `{"version":2,"time":5000000000,"direction":0}`
	if string(got) != want {
		t.Fatalf("speedtest config wire format changed\n got: %s\nwant: %s", got, want)
	}

	var back config
	if err := json.Unmarshal(got, &back); err != nil {
		t.Fatalf("json.Unmarshal(config) returned error: %v", err)
	}
	if !reflect.DeepEqual(back, in) {
		t.Fatalf("speedtest config did not round-trip\n got: %+v\nwant: %+v", back, in)
	}

	// A larger, differently-valued duration guards against a unit
	// reinterpretation that coincidentally matches for one value.
	in2 := config{Version: version, TestDuration: 90 * time.Minute, Direction: Upload}
	got2, err := json.Marshal(in2)
	if err != nil {
		t.Fatalf("json.Marshal(config{90m}) returned error: %v", err)
	}
	const want2 = `{"version":2,"time":5400000000000,"direction":1}`
	if string(got2) != want2 {
		t.Fatalf("speedtest config{90m} wire format changed\n got: %s\nwant: %s", got2, want2)
	}
	var back2 config
	if err := json.Unmarshal(got2, &back2); err != nil {
		t.Fatalf("json.Unmarshal(config{90m}) returned error: %v", err)
	}
	if back2.TestDuration != 90*time.Minute {
		t.Fatalf("config{90m} round-trip duration = %v; want 90m", back2.TestDuration)
	}
}
