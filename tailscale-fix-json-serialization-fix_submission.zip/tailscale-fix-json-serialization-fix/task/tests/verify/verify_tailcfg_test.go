// Copyright (c) Tailscale Inc & contributors
// SPDX-License-Identifier: BSD-3-Clause

// Behavioral verifier: tailcfg.SSHAction round-trips through the standard
// library encoding/json under the image's Go toolchain, carrying a non-zero
// session duration encoded as an int64 nanosecond count.
//
// This is the runtime netmap-decode symptom: an SSH access policy rides along
// in a netmap, and a value carrying a session duration must marshal and
// unmarshal without error and with a byte-stable wire format. The test drives
// only the pre-existing public type (tailcfg.SSHAction) through the stdlib
// encoding/json entry points (json.Marshal / json.Unmarshal); it never imports
// implementation-internal helpers and never inspects struct tags, so every
// valid fix that preserves the wire format passes.
//
// Injected into package tailcfg at grade time and run in isolation via the Go
// runner's -run filter, so it is independent of any edits an agent makes to the
// repository's own test files.
package tailcfg

import (
	"encoding/json"
	"reflect"
	"testing"
	"time"
)

// TestVerifySSHActionSessionDurationRoundTrip asserts the externally observable
// contract: an SSHAction with a non-zero session duration encodes to a stable
// JSON byte string (duration as int64 nanoseconds) and decodes back to an equal
// value, with no marshal/unmarshal error under the current toolchain.
func TestVerifySSHActionSessionDurationRoundTrip(t *testing.T) {
	in := SSHAction{
		Accept:          true,
		SessionDuration: 90 * time.Minute, // 5400000000000 ns
	}

	got, err := json.Marshal(in)
	if err != nil {
		t.Fatalf("json.Marshal(SSHAction) returned error: %v\n"+
			"a non-zero session duration must marshal cleanly under this toolchain", err)
	}

	// Exact wire format: the duration is an int64 nanosecond count, not a
	// string, not a renamed key. 90 minutes == 5400000000000 ns. Asserting the
	// exact bytes rejects any fix that silently changes the wire format.
	const want = `{"accept":true,"sessionDuration":5400000000000}`
	if string(got) != want {
		t.Fatalf("SSHAction wire format changed\n got: %s\nwant: %s", got, want)
	}

	var back SSHAction
	if err := json.Unmarshal(got, &back); err != nil {
		t.Fatalf("json.Unmarshal(SSHAction) returned error: %v\n"+
			"the decode step is the exact runtime symptom (every netmap poll on an "+
			"SSH-policy node breaks here)", err)
	}
	if !reflect.DeepEqual(back, in) {
		t.Fatalf("SSHAction did not round-trip\n got: %+v\nwant: %+v", back, in)
	}

	// A second, larger duration guards against an accidental seconds/other-unit
	// reinterpretation that happens to match for one value.
	in2 := SSHAction{SessionDuration: 5 * time.Second}
	got2, err := json.Marshal(in2)
	if err != nil {
		t.Fatalf("json.Marshal(SSHAction{5s}) returned error: %v", err)
	}
	const want2 = `{"sessionDuration":5000000000}`
	if string(got2) != want2 {
		t.Fatalf("SSHAction{5s} wire format changed\n got: %s\nwant: %s", got2, want2)
	}
	var back2 SSHAction
	if err := json.Unmarshal(got2, &back2); err != nil {
		t.Fatalf("json.Unmarshal(SSHAction{5s}) returned error: %v", err)
	}
	if back2.SessionDuration != 5*time.Second {
		t.Fatalf("SSHAction{5s} round-trip duration = %v; want 5s", back2.SessionDuration)
	}
}
