#!/usr/bin/env bash
#
# pass_to_pass guard. Runs under the shell runner from the repo root. Passes on
# both the unfixed and fixed trees; it exists to reject shortcut "fixes":
#
#   - deleting source / breaking compilation to dodge the failures
#     (`go build ./...` must still succeed across the whole module),
#   - deleting or skipping the previously-green tests of an unaffected package
#     (a stable package's own tests must still pass).
#
# It deliberately exercises a package that has nothing to do with the JSON
# regression, so a correct fix leaves it green and an over-aggressive or
# test-deleting "fix" that damages the tree is caught.
set -uo pipefail

REPO_DIR="${REPO_DIR:-/repo/tailscale}"
cd "$REPO_DIR" || { echo "cannot cd to $REPO_DIR" >&2; exit 1; }

# Pin the baked toolchain and cut the network, matching the grade environment.
export GOTOOLCHAIN=local
export GOFLAGS=-mod=mod
export GOPROXY=off
export CGO_ENABLED=1
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

echo "[verify_build] go build ./..."
if ! go build ./... > /tmp/verify-build.log 2>&1; then
    echo "[verify_build] go build ./... FAILED — the module no longer compiles" >&2
    tail -60 /tmp/verify-build.log >&2
    exit 1
fi
echo "[verify_build] go build ./... ok"

# A stable package untouched by the fix. Its tests are green before and after;
# if a shortcut deleted/skipped tests or broke the tree, this turns red.
STABLE_PKG="./util/set/..."
echo "[verify_build] go test ${STABLE_PKG}"
if ! go test -count=1 "${STABLE_PKG}" > /tmp/verify-build-test.log 2>&1; then
    echo "[verify_build] go test ${STABLE_PKG} FAILED — an unaffected package regressed" >&2
    tail -60 /tmp/verify-build-test.log >&2
    exit 1
fi
echo "[verify_build] go test ${STABLE_PKG} ok"

echo "[verify_build] PASS"
exit 0
