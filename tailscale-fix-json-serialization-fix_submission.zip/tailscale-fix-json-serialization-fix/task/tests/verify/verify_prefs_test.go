// Copyright (c) Tailscale Inc & contributors
// SPDX-License-Identifier: BSD-3-Clause

// Behavioral verifier: types/prefs preference types preserve their wire format
// through the standard library encoding/json v1 entry point under the image's
// Go toolchain. Two observable facts are asserted:
//
//   - The per-preference metadata (e.g. the managed flag) is embedded at the
//     top level of the preference object alongside its value, rather than being
//     dropped or nested — the "inline/embed" layout the wire format depends on.
//   - A preference holding an empty slice encodes its value as "[]" (v2
//     semantics), not "null" — i.e. v1 options do not leak into the nested
//     encode.
//
// The test builds preferences through the package's public constructors
// (ItemOf / ListOf with the exported Managed option) and marshals/unmarshals a
// containing struct through the stdlib encoding/json entry points. It asserts
// the exact wire bytes and never inspects struct tags, method bodies, or option
// plumbing, so every wire-preserving fix passes.
//
// Injected into package prefs at grade time and run in isolation via the Go
// runner's -run filter.
package prefs

import (
	"encoding/json"
	"testing"
)

// verifyPrefs is a minimal preferences bundle built only from the package's
// public preference types. Its JSON shape is governed by the same serializable
// layout as every real preferences struct.
type verifyPrefs struct {
	StringItem Item[string]
	IntSlice   List[int]
}

// TestVerifyPrefsMetadataInlineAndSliceSemantics asserts the observable wire
// format of a preferences bundle marshaled through encoding/json v1.
func TestVerifyPrefsMetadataInlineAndSliceSemantics(t *testing.T) {
	// A managed string item plus an empty-slice list. The managed flag must be
	// embedded at the top level of the item object (inline/embed layout); the
	// empty slice must encode as [] (pinned v2 semantics), not null.
	in := &verifyPrefs{
		StringItem: ItemOf("v1", Managed),
		IntSlice:   ListOf([]int{}),
	}

	got, err := json.Marshal(in)
	if err != nil {
		t.Fatalf("json.Marshal(prefs) returned error: %v", err)
	}

	// Exact wire bytes (encoding/json produces compact output). "Managed":true
	// embedded alongside "Value" proves the metadata inline layout survived;
	// "Value":[] proves the empty slice stayed [] rather than becoming null.
	const want = `{"StringItem":{"Value":"v1","Managed":true},"IntSlice":{"Value":[]}}`
	if string(got) != want {
		t.Fatalf("prefs wire format changed via the encoding/json v1 entry point\n"+
			" got: %s\nwant: %s", got, want)
	}

	// Round-trip: decoding restores the managed flag and the configured value.
	var back verifyPrefs
	if err := json.Unmarshal(got, &back); err != nil {
		t.Fatalf("json.Unmarshal(prefs) returned error: %v", err)
	}
	if v, ok := back.StringItem.ValueOk(); !ok || v != "v1" {
		t.Fatalf("StringItem round-trip value = %q (set=%v); want \"v1\" (set=true)", v, ok)
	}
	if !back.StringItem.IsManaged() {
		t.Fatalf("StringItem lost its managed flag on round-trip (metadata not embedded)")
	}
	if v, ok := back.IntSlice.ValueOk(); !ok || len(v) != 0 || v == nil {
		t.Fatalf("IntSlice round-trip value = %#v (set=%v); want an empty non-nil slice (set=true)", v, ok)
	}

	// A read-only, unconfigured item guards the surrounding metadata semantics:
	// no value key, metadata flag embedded at top level.
	in2 := &verifyPrefs{StringItem: ItemWithOpts[string](ReadOnly)}
	got2, err := json.Marshal(in2)
	if err != nil {
		t.Fatalf("json.Marshal(prefs readonly) returned error: %v", err)
	}
	const want2 = `{"StringItem":{"ReadOnly":true},"IntSlice":{}}`
	if string(got2) != want2 {
		t.Fatalf("prefs readonly wire format changed\n got: %s\nwant: %s", got2, want2)
	}
}
