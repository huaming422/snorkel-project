// Copyright (c) Tailscale Inc & contributors
// SPDX-License-Identifier: BSD-3-Clause

// Behavioral verifier: types/logger.AsJSON formats a value to the same JSON
// output as before and within its allocation budget, under the image's Go
// toolchain.
//
// AsJSON returns an fmt.Formatter; printing it must produce the value's JSON
// and must not exceed the historical allocations-per-run bound (an extra
// allocation under the new toolchain is exactly the regression here). This test
// drives only the pre-existing public API (logger.AsJSON via fmt) and asserts
// the output string plus the alloc budget; it never inspects the Format method
// body, so every fix that keeps the output and stays within budget passes.
//
// Injected into package logger at grade time and run in isolation via the Go
// runner's -run filter.
package logger

import (
	"bytes"
	"fmt"
	"testing"

	"tailscale.com/version"
)

// TestVerifyAsJSONOutputAndAllocs asserts that AsJSON produces the expected
// JSON output for a representative value and, outside race mode, does so within
// the allocation budget the package has historically guaranteed.
func TestVerifyAsJSONOutputAndAllocs(t *testing.T) {
	// Output: a small struct formats to compact JSON with field order preserved.
	got := fmt.Sprintf("got %v", AsJSON(struct {
		Foo string
		Bar int
	}{"hi", 123}))
	const want = `got {"Foo":"hi","Bar":123}`
	if got != want {
		t.Fatalf("AsJSON output changed\n got: %#q\nwant: %#q", got, want)
	}

	// A marshal error is still reported inline via the formatter contract.
	gotErr := fmt.Sprintf("got %v", AsJSON(func() {}))
	const wantErr = `got %!JSON-ERROR:json: unsupported type: func()`
	if gotErr != wantErr {
		t.Fatalf("AsJSON marshal-error output changed\n got: %#q\nwant: %#q", gotErr, wantErr)
	}

	if version.IsRace() {
		// Race mode inflates alloc counts; the budget assertion is meaningless
		// there, matching the package's own test.
		return
	}

	// Allocation budget: printing AsJSON must stay within the historical bound.
	// The regression under the new toolchain is a +1 allocation that pushes this
	// over the limit; a correct fix keeps it at or under 2.
	var buf bytes.Buffer
	n := int(testing.AllocsPerRun(1000, func() {
		buf.Reset()
		fmt.Fprintf(&buf, "got %v", AsJSON("hi"))
	}))
	if n > 2 {
		t.Fatalf("AsJSON allocs = %d; want max 2 (an extra allocation under this "+
			"toolchain is the resource-usage regression)", n)
	}
}
