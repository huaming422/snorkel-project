// Copyright (c) Tailscale Inc & contributors
// SPDX-License-Identifier: BSD-3-Clause

// Behavioral verifier: types/opt.Value[T] preserves its v2 wire semantics (a
// nil slice encodes as "[]", a nil map as "{}") when reached through the
// standard library encoding/json v1 entry point.
//
// Under the image's Go toolchain, encoding/json dispatches to the type's custom
// marshal methods; if v1 options leak into the nested encode, a nil slice
// silently becomes "null" instead of "[]" — a wire-format regression. This test
// drives only the pre-existing public type (opt.Value) through the stdlib
// json.Marshal / json.Unmarshal entry points and asserts the exact wire bytes;
// it never inspects the method bodies or option plumbing, so every fix that
// keeps the wire format passes.
//
// Injected into package opt at grade time and run in isolation via the Go
// runner's -run filter.
package opt

import (
	"encoding/json"
	"reflect"
	"testing"
)

// TestVerifyValueNilSliceMapWireFormat asserts the observable contract: via the
// encoding/json v1 entry point, a Value holding a nil slice marshals to "[]"
// and a Value holding a nil map marshals to "{}", and both round-trip to the
// equivalent empty (non-nil) container.
func TestVerifyValueNilSliceMapWireFormat(t *testing.T) {
	in := struct {
		Slice Value[[]int]
		Map   Value[map[string]int]
	}{
		Slice: ValueOf[[]int](nil),
		Map:   ValueOf[map[string]int](nil),
	}

	got, err := json.Marshal(in)
	if err != nil {
		t.Fatalf("json.Marshal returned error: %v", err)
	}

	// The v2 semantics: nil slice -> "[]", nil map -> "{}". If v1 options leak
	// in, these become "null" and the assertion fails.
	const want = `{"Slice":[],"Map":{}}`
	if string(got) != want {
		t.Fatalf("opt.Value wire format changed via the encoding/json v1 entry point\n"+
			" got: %s\nwant: %s\n(a nil slice must stay [] and a nil map {}, not null)", got, want)
	}

	// Round-trip: the empty containers decode back as set, empty (non-nil).
	wantBack := struct {
		Slice Value[[]int]
		Map   Value[map[string]int]
	}{ValueOf([]int{}), ValueOf(map[string]int{})}
	var back struct {
		Slice Value[[]int]
		Map   Value[map[string]int]
	}
	if err := json.Unmarshal(got, &back); err != nil {
		t.Fatalf("json.Unmarshal returned error: %v", err)
	}
	if !reflect.DeepEqual(back, wantBack) {
		t.Fatalf("opt.Value did not round-trip\n got: %+v\nwant: %+v", back, wantBack)
	}

	// A non-empty slice and an unset Value guard the surrounding semantics so a
	// fix cannot special-case only the nil->[] path.
	in2 := struct {
		Set   Value[[]int]
		Unset Value[[]int]
	}{
		Set: ValueOf([]int{1, 2, 3}),
	}
	got2, err := json.Marshal(in2)
	if err != nil {
		t.Fatalf("json.Marshal (set/unset) returned error: %v", err)
	}
	const want2 = `{"Set":[1,2,3],"Unset":null}`
	if string(got2) != want2 {
		t.Fatalf("opt.Value set/unset wire format changed\n got: %s\nwant: %s", got2, want2)
	}
}
