// Copyright (c) Tailscale Inc & contributors
// SPDX-License-Identifier: BSD-3-Clause

// Behavioral verifier: logtail.LogEntry[T] embeds the inner value's fields at
// the top level of the uploaded JSON object (the "inline/embed" layout), under
// the image's Go toolchain.
//
// A LogEntry carries reserved "logtail" metadata plus an inlined payload; the
// payload's fields must appear at the top level alongside "logtail", not nested
// under a "Value" key and not dropped. This test drives only the pre-existing
// public type (logtail.LogEntry) through the stdlib encoding/json entry points
// and asserts the exact wire bytes; it never inspects struct tags, so every fix
// that keeps the inlined layout passes.
//
// Injected into package logtail at grade time and run in isolation via the Go
// runner's -run filter. NOTE: the logtail package ships its own TestMain; this
// file declares no TestMain, so it compiles alongside the package's existing
// test infrastructure and the runner's -run filter selects only this test.
package logtail

import (
	"encoding/json"
	"reflect"
	"testing"
)

// verifyPayload is a small struct used as the inlined LogEntry value.
type verifyPayload struct {
	Text  string `json:"text"`
	Level int    `json:"level"`
}

// TestVerifyLogEntryInlinesValueFields asserts the observable contract: a
// LogEntry marshals to a JSON object whose payload fields sit at the top level
// alongside the "logtail" metadata member, and round-trips back to an equal
// value.
func TestVerifyLogEntryInlinesValueFields(t *testing.T) {
	in := LogEntry[verifyPayload]{
		Value: verifyPayload{Text: "hello", Level: 3},
	}

	got, err := json.Marshal(in)
	if err != nil {
		t.Fatalf("json.Marshal(LogEntry) returned error: %v", err)
	}

	// Exact wire format: the "text" and "level" fields appear at the top level,
	// NOT nested under a "Value"/"value" key. The zero Logtail metadata is
	// omitted (omitzero). If the inline layout is lost, the payload is either
	// nested or dropped and this assertion fails.
	const want = `{"text":"hello","level":3}`
	if string(got) != want {
		t.Fatalf("LogEntry inline layout changed\n got: %s\nwant: %s\n"+
			"(the inner value's fields must be inlined at the top level)", got, want)
	}

	var back LogEntry[verifyPayload]
	if err := json.Unmarshal(got, &back); err != nil {
		t.Fatalf("json.Unmarshal(LogEntry) returned error: %v", err)
	}
	if !reflect.DeepEqual(back, in) {
		t.Fatalf("LogEntry did not round-trip\n got: %+v\nwant: %+v", back, in)
	}
}
