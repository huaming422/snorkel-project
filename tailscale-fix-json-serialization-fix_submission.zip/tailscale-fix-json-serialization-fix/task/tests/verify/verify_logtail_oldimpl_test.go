// Copyright (c) Tailscale Inc & contributors
// SPDX-License-Identifier: BSD-3-Clause

// Behavioral verifier (OLD-toolchain wire identity): logtail.LogEntry[T] must
// inline the inner value's fields at the top level of the uploaded JSON object
// when encoded by the OLD json implementation too — not only under the image's
// Go 1.27 toolchain.
//
// base.md's single hard constraint is that the on-the-wire JSON stays identical
// on BOTH the old and the new toolchain, so a node or control server still
// running the previous Go release keeps interoperating. The companion test
// verify_logtail_test.go pins the layout under Go 1.27's finalized encoding/json
// (which spells the inline tag option `embed`); this file pins the SAME inlined
// bytes under the old implementation (which spells it `inline`). The two
// together reject a fix that keeps only one spelling: an `embed`-only tag
// inlines under Go 1.27 but NESTS under the old implementation (the payload
// lands under a "Value" key), silently breaking old-peer interop.
//
// The old implementation is reached deterministically via the pinned
// go-json-experiment module built with GOEXPERIMENT=nojsonv2 (set in verify.toml
// for this file). Under that build the module compiles its own self-contained
// encoder — the exact code path the previous Go toolchain used — rather than
// aliasing to the standard library's encoding/json/v2. The test drives only the
// pre-existing public type (logtail.LogEntry) through that module's top-level
// Marshal and asserts the exact wire bytes; it never inspects struct tags, so
// every fix that keeps the inlined layout on both toolchains passes.
//
// Injected into package logtail at grade time and run in isolation via the Go
// runner's -run filter. NOTE: the logtail package ships its own TestMain; this
// file declares no TestMain, so it compiles alongside the package's existing
// test infrastructure and the runner's -run filter selects only this test.
package logtail

import (
	"testing"

	oldjson "github.com/go-json-experiment/json"
)

// verifyOldImplPayload is a small struct used as the inlined LogEntry value.
type verifyOldImplPayload struct {
	Text  string `json:"text"`
	Level int    `json:"level"`
}

// TestVerifyLogEntryInlinesValueFieldsOldImpl asserts that a LogEntry marshals
// to a JSON object whose payload fields sit at the top level — alongside the
// "logtail" metadata member, not nested under a "Value" key — when encoded by
// the OLD json implementation, so the wire format matches the Go 1.27 output
// byte-for-byte and old peers keep decoding it.
func TestVerifyLogEntryInlinesValueFieldsOldImpl(t *testing.T) {
	in := LogEntry[verifyOldImplPayload]{
		Value: verifyOldImplPayload{Text: "hello", Level: 3},
	}

	got, err := oldjson.Marshal(in)
	if err != nil {
		t.Fatalf("old-impl Marshal(LogEntry) returned error: %v", err)
	}

	// Exact wire format: the "text" and "level" fields appear at the top level,
	// NOT nested under a "Value" key, and the zero Logtail metadata is omitted.
	// A fix that drops the old implementation's inline spelling (e.g. an
	// `embed`-only tag) nests the payload here and fails this assertion, even
	// though it would pass the Go 1.27 verifier.
	const want = `{"text":"hello","level":3}`
	if string(got) != want {
		t.Fatalf("LogEntry old-toolchain wire format changed\n got: %s\nwant: %s\n"+
			"(the inner value's fields must stay inlined on the OLD implementation "+
			"too, not only under Go 1.27)", got, want)
	}
}
