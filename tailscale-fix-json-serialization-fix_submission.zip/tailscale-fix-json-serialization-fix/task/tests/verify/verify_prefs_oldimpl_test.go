// Copyright (c) Tailscale Inc & contributors
// SPDX-License-Identifier: BSD-3-Clause

// Behavioral verifier (OLD-toolchain wire identity): types/prefs preference
// types must embed their per-preference metadata at the top level of the
// preference object when encoded by the OLD json implementation too — not only
// under the image's Go 1.27 toolchain.
//
// base.md's single hard constraint is that the on-the-wire JSON stays identical
// on BOTH the old and the new toolchain. The companion test verify_prefs_test.go
// pins the metadata-inline layout under Go 1.27's finalized encoding/json (which
// spells the inline tag option `embed`); this file pins the SAME bytes under the
// old implementation (which spells it `inline`). The two together reject a fix
// that keeps only one spelling: an `embed`-only tag embeds the managed/read-only
// flag under Go 1.27 but NESTS it under a "Metadata" key under the old
// implementation, silently breaking old-peer interop.
//
// The old implementation is reached deterministically via the pinned
// go-json-experiment module built with GOEXPERIMENT=nojsonv2 (set in verify.toml
// for this file). Under that build the module compiles its own self-contained
// encoder — the code path the previous Go toolchain used — rather than aliasing
// to the standard library's encoding/json/v2. The test builds preferences
// through the package's public constructors (ItemOf / ListOf / ItemWithOpts with
// the exported Managed / ReadOnly options) and asserts the exact wire bytes; it
// never inspects struct tags, method bodies, or option plumbing, so every fix
// that keeps the layout on both toolchains passes.
//
// Injected into package prefs at grade time and run in isolation via the Go
// runner's -run filter.
package prefs

import (
	"testing"

	oldjson "github.com/go-json-experiment/json"
)

// verifyOldImplPrefs is a minimal preferences bundle built only from the
// package's public preference types. Its JSON shape is governed by the same
// serializable layout as every real preferences struct.
type verifyOldImplPrefs struct {
	StringItem Item[string]
	IntSlice   List[int]
}

// TestVerifyPrefsMetadataInlineOldImpl asserts the observable wire format of a
// preferences bundle marshaled through the OLD json implementation, so it
// matches the Go 1.27 output byte-for-byte and old peers keep decoding it.
func TestVerifyPrefsMetadataInlineOldImpl(t *testing.T) {
	// A managed string item plus an empty-slice list. The managed flag must be
	// embedded at the top level of the item object (not nested under a
	// "Metadata" key); the empty slice must encode as [], not null.
	in := &verifyOldImplPrefs{
		StringItem: ItemOf("v1", Managed),
		IntSlice:   ListOf([]int{}),
	}

	got, err := oldjson.Marshal(in)
	if err != nil {
		t.Fatalf("old-impl Marshal(prefs) returned error: %v", err)
	}

	// Exact wire bytes. "Managed":true embedded alongside "Value" proves the
	// metadata inline layout survives on the OLD implementation; a fix that
	// drops the old inline spelling (e.g. an `embed`-only tag) nests the flag
	// under "Metadata" here and fails, even though it passes the Go 1.27
	// verifier.
	const want = `{"StringItem":{"Value":"v1","Managed":true},"IntSlice":{"Value":[]}}`
	if string(got) != want {
		t.Fatalf("prefs old-toolchain wire format changed\n got: %s\nwant: %s\n"+
			"(metadata must stay embedded at the top level on the OLD "+
			"implementation too, not only under Go 1.27)", got, want)
	}

	// A read-only, unconfigured item guards the surrounding metadata semantics:
	// no value key, metadata flag embedded at the top level (not nested).
	in2 := &verifyOldImplPrefs{StringItem: ItemWithOpts[string](ReadOnly)}
	got2, err := oldjson.Marshal(in2)
	if err != nil {
		t.Fatalf("old-impl Marshal(prefs readonly) returned error: %v", err)
	}
	const want2 = `{"StringItem":{"ReadOnly":true},"IntSlice":{}}`
	if string(got2) != want2 {
		t.Fatalf("prefs readonly old-toolchain wire format changed\n got: %s\nwant: %s", got2, want2)
	}
}
