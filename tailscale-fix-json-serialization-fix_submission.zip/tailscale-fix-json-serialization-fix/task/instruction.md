## Task

after we bumped the go toolchain, tailscaled started choking on netmaps that carry an ssh access policy. every netmap poll on those nodes errors out on decode now, and it was totally fine on the old toolchain. the test suite caught it too: `go test ./...` now fails in a handful of packages that were green before the bump.

figure out why the toolchain change broke our json handling and fix it so decoding works again and the suite goes green.

one hard constraint: the on-the-wire json format has to stay exactly the same, so nodes and control servers still on the old toolchain keep interoperating with the new ones. that means no pinning or downgrading the toolchain to dodge it, and no deleting or skipping tests or dropping the affected behavior just to get green.
