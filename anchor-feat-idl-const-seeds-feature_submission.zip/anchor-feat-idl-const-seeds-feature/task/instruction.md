## Task

We want to broaden how Anchor v2's `#[derive(Accounts)]` IDL generation handles PDA seeds. Today, when a seed in a `seeds = [...]` list is a const-evaluatable, byte-like expression (a reference to a `const` byte value, a const-fn call, and the like), the generated IDL loses the real bytes and records an empty placeholder, and only a small fixed set of built-in program markers gets resolved. We want any const-evaluatable byte-like seed expression to show up in the IDL with its actual bytes, including ones built from a program's own marker rather than only the built-in set. Scope it to that fallback path; the seed forms that already resolve to correct IDL should stay exactly as they are.

## User stories / requirements

- When a PDA account references a const byte value in its seed list, that seed appears in the generated IDL as a constant seed holding the value's real bytes, not an empty one. The same holds across byte-like types: a byte slice, byte array, string, or address.
- When a PDA's program override or a seed is built from a user-defined program marker rather than one of the built-in well-known ones, the generated IDL carries that marker's real program-id bytes. This holds both when the marker drives the `seeds::program` override and when the marker's id is used directly as a seed element.
