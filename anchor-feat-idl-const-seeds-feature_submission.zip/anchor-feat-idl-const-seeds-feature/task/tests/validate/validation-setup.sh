#!/usr/bin/env bash
#
# Validation environment setup for anchor-feat-idl-const-seeds.
#
# The cargo-test driver writes a params helper (validation_params.rs) into
# the target crate's tests/ dir that imports serde:
#     use serde::Deserialize;
#     #[derive(Debug, Deserialize)]
# The `constraints` fixture already carries the `serde_json` and
# `anchor-lang-idl-spec` dev-deps and the `idl-build` feature, but NOT a
# direct `serde` dev-dep with the derive feature. We add exactly that here.
#
# This is safe and deterministic:
#   * serde 1.0.228 + serde_derive 1.0.228 are already pinned in the
#     workspace Cargo.lock (pulled in transitively by anchor-lang-idl-spec),
#     and their crates live in the image's warm CARGO_HOME registry cache —
#     so adding this dev-dep edge resolves offline, with no network fetch.
#     Adding the edge does add one `"serde"` entry to the constraints
#     package's dependency list in Cargo.lock (no version/source lines
#     change — the crate is already locked), so we regenerate the lock here,
#     offline, as part of the same setup step.
#   * Both the manifest edit and the offline lock regeneration land BEFORE
#     the validation agent's pre-run checkpoint (test.sh sources this script
#     in the validation stage, before run_validate.py snapshots the repo for
#     its integrity check), so they are part of the baseline — not mistaken
#     for an agent modification, and the agent's own `--locked` cargo test
#     then needs no further lock update.
#   * The behavioral verifier (verify/verify_test.rs) runs in an earlier
#     stage against the unmodified crate, so this never affects it.
#
# Hardening standard: pin the toolchain ahead of any stray PATH entry,
# make the edit idempotent, and end with a loud smoke guard.

set -euo pipefail

# Pin the repo's rust toolchain ahead of anything a harness runtime may have
# shadowed onto PATH.
export PATH="/opt/cargo/bin:${PATH}"
export RUSTUP_TOOLCHAIN="${RUSTUP_TOOLCHAIN:-1.99.1}"

CRATE_MANIFEST="/repo/anchor/tests-v2/programs/constraints/Cargo.toml"

if [ ! -f "${CRATE_MANIFEST}" ]; then
    echo "validation-setup: expected crate manifest not found: ${CRATE_MANIFEST}" >&2
    exit 1
fi

# Idempotently add `serde` (with derive) to the crate's [dev-dependencies].
# The manifest already has a [dev-dependencies] table (serde_json lives
# there); append the serde line to it if absent.
if grep -qE '^serde[[:space:]]*=' "${CRATE_MANIFEST}"; then
    echo "validation-setup: serde dev-dep already present; skipping edit"
else
    if ! grep -qE '^\[dev-dependencies\]' "${CRATE_MANIFEST}"; then
        echo "validation-setup: no [dev-dependencies] table in ${CRATE_MANIFEST}" >&2
        exit 1
    fi
    # Insert directly after the [dev-dependencies] header line.
    awk '
        /^\[dev-dependencies\]/ && !done {
            print
            print "serde = { version = \"1\", features = [\"derive\"] }"
            done = 1
            next
        }
        { print }
    ' "${CRATE_MANIFEST}" > "${CRATE_MANIFEST}.tmp"
    mv "${CRATE_MANIFEST}.tmp" "${CRATE_MANIFEST}"
    echo "validation-setup: added serde dev-dep to constraints crate"
fi

# Regenerate Cargo.lock offline so the new serde dev-dep edge is recorded
# now (part of the pre-checkpoint baseline). `--offline` forbids any network
# access — resolution must be satisfiable from the warm registry cache — so
# this fails loudly if serde is somehow unavailable, rather than reaching for
# the network. `cargo metadata` drives the resolution/lock update.
echo "validation-setup: regenerating lockfile offline (serde dev-dep)..."
cargo metadata --offline --format-version 1 \
    --manifest-path "${CRATE_MANIFEST}" >/dev/null
echo "validation-setup: constraints dependency graph resolved OK"

# Smoke guard: a --locked resolution must now succeed with no further lock
# change, confirming the baseline lock is complete for the agent's later
# `--locked` cargo test.
cargo metadata --locked --format-version 1 \
    --manifest-path "${CRATE_MANIFEST}" >/dev/null
echo "validation-setup: lockfile is complete (--locked resolves clean)"
