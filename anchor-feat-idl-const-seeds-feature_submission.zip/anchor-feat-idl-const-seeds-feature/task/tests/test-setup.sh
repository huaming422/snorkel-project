#!/usr/bin/env bash
# No services to start and no data to seed. The image bakes the full
# dependency closure (including the `idl-build` feature build for the
# derives-test and constraints fixtures), so the verifier's cargo
# invocations resolve entirely from the warm cache. This script only
# reports the toolchain state.
set -euo pipefail

echo "[test-setup] Rust version:    $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:   $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root:  /repo/anchor"
echo "[test-setup] Setup complete."
