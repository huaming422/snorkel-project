#!/usr/bin/env bash
#
# Structural verifier for anchor-feat-idl-const-seeds.
#
# The feature's static-vs-runtime seed plumbing ripples across four files
# in two crates: the classified-seed representation and the per-field pda
# emission in the derive crate (`lang-v2/derive`), its type threaded through
# the pda metadata and the `impl_accounts` emission site, and a new runtime
# helper in the lang crate's idl-build module (`lang-v2/src/idl_build.rs`).
# Getting one layer wrong — e.g. changing the metadata type but not the
# emission site, or the helper signature but not its call site — fails to
# compile only under `--features idl-build`.
#
# This guard confirms both halves build:
#   * the derive proc-macro crate compiles on its own, and
#   * an idl-build-enabled fixture crate (which forces the derive to expand
#     the `__idl_accounts()` path and call the runtime helper) compiles.
#
# The image pre-builds both targets, so a warm run is under 30 seconds.
# The runner cwd is {repo_dir} (/repo/anchor), which is the cargo
# workspace root.
#
# Exit codes:
#   0 — both build cleanly
#   non-zero — propagates the cargo failure

set -euo pipefail

cd /repo/anchor

# 1. The derive proc-macro crate builds in isolation.
cargo build -p anchor-derive-accounts-v2

# 2. An idl-build-enabled fixture compiles — this forces the derive to
#    expand the IDL-emission path and reference the runtime seed helper,
#    exercising the cross-crate plumbing end to end.
cargo build -p constraints --features idl-build
