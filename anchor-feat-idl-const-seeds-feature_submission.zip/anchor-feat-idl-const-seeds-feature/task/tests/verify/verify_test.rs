//! Regression verifier for `anchor-feat-idl-const-seeds` (pass_to_pass).
//!
//! Injected by the rust runner into
//! `tests-v2/programs/constraints/tests/` and compiled as an integration
//! test of the `constraints` program crate (which already wires the
//! `anchor-lang-idl-spec` + `serde_json` dev-deps and the `idl-build`
//! feature). The runner invokes it with `--features idl-build`.
//!
//! Scope split (deliberate, see the task's reward design):
//!   * The feature's NEW behavior — const-evaluatable byte-like seeds and
//!     user-defined program markers resolving to their real bytes — is the
//!     part that is absent on the unpatched tree, so it is owned by the
//!     validation stories (which must tell an unsolved tree apart from a
//!     solved one). Duplicating it here would violate the "do not duplicate
//!     validation stories in verifiers" rule.
//!   * THIS file owns only the pass_to_pass regression: every seed shape
//!     that already produced a correct IDL entry must keep producing an
//!     identical one. These assertions pass on BOTH the pre-fix and post-fix
//!     trees; they exist to catch a change that regresses the
//!     previously-working classification while adding the new behavior.
//!
//! Every assertion goes through the pre-existing, stable observation
//! interface: each `#[derive(Accounts)]` struct emits an associated
//! `__idl_accounts() -> String` under `--features idl-build`, which we
//! parse into the typed `anchor_lang_idl_spec` structures and read at
//! `account.pda.seeds[i]`. No derive-crate internal helper or type is named
//! or imported — only the generated JSON method and the public IDL spec
//! types. This is identical to the established pattern in
//! `constraints::idl_tests`.
//!
//! The fixtures below are declared inline so the verifier owns its own
//! inputs and does not depend on any fixture the solving agent might edit.

use anchor_lang_v2::prelude::*;
use anchor_lang_idl_spec::{IdlInstructionAccount, IdlInstructionAccountItem, IdlPda, IdlSeed};

// `#[derive(Accounts)]` expands code that references `crate::ID`, so the
// integration-test crate must declare one. The value is irrelevant to IDL
// seed emission (it only feeds client-side PDA derivation helpers).
declare_id!("Con9ukTn9BRPXWcjS2UBbuN3NnCwy1hcaDNZ9Hb8QMNp");

// A const byte slice, used only to pair with the bare field-ident seed so
// that fixture routes through the non-`.as_ref()` branch (see FieldSeed).
const DATA_SEED: &[u8] = b"data-v2";

// ---------------------------------------------------------------------------
// Fixtures: previously-working seed shapes (must stay identical post-fix)
// ---------------------------------------------------------------------------

#[derive(Accounts)]
pub struct LiteralSeed {
    #[account(seeds = [b"data"], bump)]
    pub pda: UncheckedAccount,
}

// A bare field-ident seed classifies to an `account` seed. It is paired
// here with a const seed so the derive's client-side PDA-derivation branch
// (which would emit `authority.as_ref()` into `find_program_address`, a
// shape the account wrappers don't satisfy) is skipped — this mirrors how
// the repo only ever uses field roots through method chains at the runtime
// layer. The IDL classification of the bare ident is unaffected and is what
// we assert.
#[derive(Accounts)]
pub struct FieldSeed {
    pub authority: UncheckedAccount,
    #[account(seeds = [authority, DATA_SEED], bump)]
    pub pda: UncheckedAccount,
}

// A bare instruction-argument ident classifies to an `arg` seed. The arg is
// typed as a byte slice so the pre-existing runtime seeds-check (which coerces
// each seed expression to `&[u8]`) accepts the bare ident directly; the IDL
// classification of the bare arg root is what we assert and is unaffected by
// the element type.
#[derive(Accounts)]
#[instruction(nonce: &[u8])]
pub struct ArgSeed {
    #[account(seeds = [nonce], bump)]
    pub pda: UncheckedAccount,
}

#[derive(Accounts)]
pub struct MethodChainSeed {
    pub payer: Signer,
    #[account(seeds = [b"user", payer.address().as_ref()], bump)]
    pub pda: UncheckedAccount,
}

// A built-in, well-known program marker used as a `seeds::program` override.
// Its program id already resolved to its real bytes before the change (it was
// one of the hardcoded well-known markers); it must keep resolving to those
// same bytes afterwards. This is pass_to_pass: it holds on both the pre-fix
// and post-fix trees. It exists to catch a change that, while broadening
// support to user-defined markers, regresses a built-in marker back to empty
// bytes.
#[derive(Accounts)]
pub struct BuiltinMarkerProgram {
    #[account(seeds = [b"x"], bump, seeds::program = Token::id())]
    pub pda: UncheckedAccount,
}

// ---------------------------------------------------------------------------
// Parse helpers (mirrors constraints::idl_tests)
// ---------------------------------------------------------------------------

fn parse(json: &str) -> Vec<IdlInstructionAccountItem> {
    serde_json::from_str(json)
        .unwrap_or_else(|e| panic!("failed to parse accounts JSON: {e}\njson: {json}"))
}

fn single(items: &[IdlInstructionAccountItem], idx: usize) -> &IdlInstructionAccount {
    match &items[idx] {
        IdlInstructionAccountItem::Single(a) => a,
        IdlInstructionAccountItem::Composite(_) => {
            panic!("expected Single account at index {idx}, got Composite")
        }
    }
}

/// Read the `pda` object off a named account, panicking if absent.
fn pda_of<'a>(account: &'a IdlInstructionAccount, name: &str) -> &'a IdlPda {
    assert_eq!(account.name, name, "unexpected account name");
    account
        .pda
        .as_ref()
        .unwrap_or_else(|| panic!("account `{name}` has no `pda` entry"))
}

/// Assert a seed is `Const` and return its bytes.
fn const_bytes(seed: &IdlSeed) -> &[u8] {
    match seed {
        IdlSeed::Const(c) => &c.value,
        other => panic!("expected IdlSeed::Const, got {other:?}"),
    }
}

/// Assert a seed is `Account` and return its path.
fn account_path(seed: &IdlSeed) -> &str {
    match seed {
        IdlSeed::Account(a) => &a.path,
        other => panic!("expected IdlSeed::Account, got {other:?}"),
    }
}

/// Assert a seed is `Arg` and return its path.
fn arg_path(seed: &IdlSeed) -> &str {
    match seed {
        IdlSeed::Arg(a) => &a.path,
        other => panic!("expected IdlSeed::Arg, got {other:?}"),
    }
}

// ---------------------------------------------------------------------------
// pass_to_pass: previously-working seed shapes stay identical
// ---------------------------------------------------------------------------

#[test]
fn literal_byte_string_seed_unchanged() {
    let items = parse(&LiteralSeed::__idl_accounts());
    let pda = pda_of(single(&items, 0), "pda");
    assert_eq!(const_bytes(&pda.seeds[0]), b"data");
}

#[test]
fn field_ident_seed_unchanged() {
    let items = parse(&FieldSeed::__idl_accounts());
    let pda = pda_of(single(&items, 1), "pda");
    assert_eq!(account_path(&pda.seeds[0]), "authority");
}

#[test]
fn arg_ident_seed_unchanged() {
    let items = parse(&ArgSeed::__idl_accounts());
    let pda = pda_of(single(&items, 0), "pda");
    assert_eq!(arg_path(&pda.seeds[0]), "nonce");
}

#[test]
fn method_chain_seed_unchanged_and_order_preserved() {
    let items = parse(&MethodChainSeed::__idl_accounts());
    let pda = pda_of(single(&items, 1), "pda");
    // Order: the literal comes first, the field-rooted method chain second.
    assert_eq!(pda.seeds.len(), 2, "expected two seeds in declared order");
    assert_eq!(const_bytes(&pda.seeds[0]), b"user");
    assert_eq!(account_path(&pda.seeds[1]), "payer");
}

// The token-program id, base58 `TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA`,
// as its 32 raw bytes. A built-in marker resolved to exactly these bytes
// before the change and must keep doing so afterwards.
const TOKEN_PROGRAM_BYTES: [u8; 32] = [
    6, 221, 246, 225, 215, 101, 161, 147, 217, 203, 225, 70, 206, 235, 121, 172, 28, 180, 133, 237,
    95, 91, 55, 145, 58, 140, 245, 133, 126, 255, 0, 169,
];

#[test]
fn builtin_marker_program_override_unchanged() {
    let items = parse(&BuiltinMarkerProgram::__idl_accounts());
    let pda = pda_of(single(&items, 0), "pda");
    // The literal seed stays resolved.
    assert_eq!(const_bytes(&pda.seeds[0]), b"x");
    // The built-in marker's program override resolves to its real id bytes.
    let program = pda
        .program
        .as_ref()
        .expect("built-in marker override must carry a program entry");
    assert_eq!(const_bytes(program), TOKEN_PROGRAM_BYTES);
}
