"""Behavioral verifier for mise-bug-cask-prune-deps.

`mise bootstrap packages prune` computes its keep-set per package manager and
ignores cross-manager `depends_on` edges. So a Homebrew formula (or another
cask) that is needed ONLY as the dependency closure of a cask the user keeps in
their config is treated as orphaned and pruned — breaking the kept cask the
next time it is used. The fix must extend the keep-set to a configured cask's
dependency closure (formulae for the `brew` manager, transitive casks for the
`brew-cask` manager) while STILL pruning genuinely-unused packages.

This verifier drives the real CLI end-to-end, offline, exactly the way the
repo's own e2e tests do (see `e2e/cli/test_system_prune_brew_cask` and
`e2e/cli/test_system_install_brew_cask_homebrew_owned`). It never imports repo
internals and never inspects the source — any fix that keeps a kept cask's
dependencies while still pruning orphans passes.

Three pre-existing stable seams make the offline run possible, all read by mise
in production code paths:
  * MISE_SYSTEM_BREW_PREFIX — a fake Homebrew prefix holding the "installed"
    formula kegs and casks (Cellar/opt/linked layout + Caskroom + receipts).
  * MISE_URL_REPLACEMENTS — a JSON map redirecting `https://formulae.brew.sh`
    to a loopback python3 HTTP server that serves `/api/formula/<n>.json`
    and `/api/cask/<token>.json`.
  * MISE_STATE_DIR — an isolated state dir (cask journal lookups).

Tests (all fail_to_pass — they fail on the base repo, pass once fixed):
  test_brew_keeps_cask_formula_dependency      (criterion #1, basic)
  test_brew_keeps_transitive_cask_formula_dependency  (criterion #1, transitive)
  test_brew_cask_keeps_transitive_cask         (criterion #2, basic)
  test_cask_closure_cycle_safe                 (criterion #3, cycle nuance)

The remaining senior-engineer nuance of criterion #3 — that the closure
de-duplicates by (name, tap) rather than bare token so same-named casks from
different taps stay distinct — is not exercised here: pinning it behaviorally
would require asserting a specific fix's tap-specific internals, and running a
specific fix's named in-crate unit tests would reject any valid fix that does
not replicate those exact test names. That nuance is judged by rubric criterion
#5 (tap-qualified dependency handling) instead. The cycle-safety nuance IS
exercised behaviorally below, because a closure walk that is not cycle-safe
hangs and trips the prune timeout.

Each behavioral test carries a MANDATORY negative control in the same prune
run: a genuinely-orphaned formula / unused cask that MUST still be reported for
removal, so a "keep everything" stub (which would make the fail_to_pass
assertion pass) is rejected by the control assertion.

The headline separation (verified by hand-running base vs fixed):
  * base repo:  prune removes the depended-on formula/cask AND the orphan.
  * fixed repo: prune keeps the depended-on formula/cask, removes only the
                orphan.
"""

from __future__ import annotations

import hashlib
import json
import os
import socket
import subprocess
import sys
import textwrap
import time
from pathlib import Path
from typing import Iterator

import pytest

# ---------------------------------------------------------------------------
# Repo / binary location
# ---------------------------------------------------------------------------

REPO_DIR = Path(f"/repo/{os.environ.get('REPO_NAME', 'mise')}")
# Honor CARGO_TARGET_DIR (the task image sets it to /opt/cache/cargo-target so
# the warm cargo cache survives outside the clone); fall back to the in-tree
# target/ dir for a plain checkout. The debug `mise` bin lands under
# <target>/debug/mise either way.
_TARGET_DIR = Path(os.environ.get("CARGO_TARGET_DIR") or (REPO_DIR / "target"))
MISE_BIN = _TARGET_DIR / "debug" / "mise"

# Wall-clock ceilings. The image pre-builds the debug binary
# (`cargo build --locked --tests --workspace`), so the warm path is a no-op;
# the cold-cache rebuild is the only slow step.
BUILD_TIMEOUT_S = 900
PRUNE_TIMEOUT_S = 120
SERVER_BOOT_TIMEOUT_S = 30.0


# ---------------------------------------------------------------------------
# Build the binary (defensive; test-setup warms it)
# ---------------------------------------------------------------------------


def _build_mise() -> None:
    # ALWAYS (re)build — never early-return on an existing binary. The task image
    # bakes the warm cargo cache and a debug `mise` built from the BASE source;
    # the grading harness applies the candidate/reference patch to the source but
    # does NOT recompile. If we skipped the build when the (stale, base) binary
    # already existed, every trial would silently run base behavior and the
    # verifier could never separate a real fix from no change. The warm cache
    # makes this an incremental rebuild (only the edited crate recompiles).
    proc = subprocess.run(
        ["cargo", "build", "--locked", "--bin", "mise"],
        cwd=str(REPO_DIR),
        capture_output=True,
        text=True,
        timeout=BUILD_TIMEOUT_S,
        check=False,
    )
    if proc.returncode != 0 or not MISE_BIN.exists():
        raise RuntimeError(
            "cargo build --bin mise failed.\n"
            f"--- stdout ---\n{proc.stdout[-3000:]}\n"
            f"--- stderr ---\n{proc.stderr[-3000:]}"
        )


# ---------------------------------------------------------------------------
# Loopback Homebrew-metadata fixture server
# ---------------------------------------------------------------------------

# A single python3 process serving the JSON the real fetch paths request:
#   GET /api/formula/<name>.json  (brew keep-set resolves formula deps)
#   GET /api/cask/<token>.json    (brew-cask keep-set resolves cask deps)
# Anything else 404s. The fixtures are written to a directory; the server
# reads them per-request so a single server instance serves every scenario.

_SERVER_SRC = r'''
import json, os, sys, http.server, socketserver
fixture_dir = sys.argv[1]
port_file = sys.argv[2]

class H(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        path = self.path.split("?", 1)[0]
        # /api/formula/<name>.json or /api/cask/<token>.json
        local = None
        if path.startswith("/api/formula/") and path.endswith(".json"):
            local = os.path.join(fixture_dir, "formula", path[len("/api/formula/"):])
        elif path.startswith("/api/cask/") and path.endswith(".json"):
            local = os.path.join(fixture_dir, "cask", path[len("/api/cask/"):])
        if local and os.path.isfile(local):
            with open(local, "rb") as f:
                body = f.read()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, *a):
        pass

class S(socketserver.ThreadingTCPServer):
    allow_reuse_address = True

with S(("127.0.0.1", 0), H) as httpd:
    port = httpd.server_address[1]
    tmp = port_file + ".tmp"
    with open(tmp, "w") as f:
        f.write(str(port))
    os.replace(tmp, port_file)
    httpd.serve_forever()
'''


class FixtureServer:
    def __init__(self, fixture_dir: Path, port_file: Path) -> None:
        self.fixture_dir = fixture_dir
        self.port_file = port_file
        self.proc: subprocess.Popen | None = None
        self.port: int | None = None

    def start(self) -> None:
        (self.fixture_dir / "formula").mkdir(parents=True, exist_ok=True)
        (self.fixture_dir / "cask").mkdir(parents=True, exist_ok=True)
        self.proc = subprocess.Popen(
            [sys.executable, "-u", "-c", _SERVER_SRC, str(self.fixture_dir), str(self.port_file)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        deadline = time.monotonic() + SERVER_BOOT_TIMEOUT_S
        while time.monotonic() < deadline:
            if self.proc.poll() is not None:
                raise RuntimeError("fixture server exited during boot")
            if self.port_file.exists():
                text = self.port_file.read_text().strip()
                if text:
                    self.port = int(text)
                    return
            time.sleep(0.05)
        self.stop()
        raise RuntimeError("fixture server never wrote its port file")

    def write_formula(self, name: str, version: str = "1.0.0") -> None:
        (self.fixture_dir / "formula" / f"{name}.json").write_text(
            json.dumps({"name": name, "versions": {"stable": version}})
        )

    def write_cask(
        self,
        token: str,
        version: str = "1.0.0",
        depends_formula: list[str] | None = None,
        depends_cask: list[str] | None = None,
    ) -> None:
        body = {
            "token": token,
            "version": version,
            "url": "https://example.invalid/cask.zip",
            "depends_on": {
                "formula": depends_formula or [],
                "cask": depends_cask or [],
            },
        }
        (self.fixture_dir / "cask" / f"{token}.json").write_text(json.dumps(body))

    def stop(self) -> None:
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                self.proc.wait(timeout=5)


# ---------------------------------------------------------------------------
# Fake Homebrew prefix: installed formula kegs and casks
# ---------------------------------------------------------------------------


def _install_formula_keg(prefix: Path, name: str, version: str = "1.0.0") -> None:
    """Mirror maintenance.rs test helper write_keg + write_linked_record.

    Creates Cellar/<name>/<version>/{bin/<name>,INSTALL_RECEIPT.json},
    opt/<name> -> ../Cellar/<name>/<version>,
    bin/<name> -> ../Cellar/<name>/<version>/bin/<name>,
    var/homebrew/linked/<name> -> ../../../Cellar/<name>/<version>.
    installed_on_request=true so linked_formulae enumerates it.
    """
    keg = prefix / "Cellar" / name / version
    (keg / "bin").mkdir(parents=True, exist_ok=True)
    (keg / "bin" / name).write_text("")
    (keg / "INSTALL_RECEIPT.json").write_text(
        json.dumps({"installed_on_request": True, "source": {"tap": "homebrew/core"}})
    )
    opt = prefix / "opt"
    opt.mkdir(parents=True, exist_ok=True)
    _symlink(Path("../Cellar") / name / version, opt / name)
    binc = prefix / "bin"
    binc.mkdir(parents=True, exist_ok=True)
    _symlink(Path("../Cellar") / name / version / "bin" / name, binc / name)
    linked = prefix / "var" / "homebrew" / "linked"
    linked.mkdir(parents=True, exist_ok=True)
    _symlink(Path("../../../Cellar") / name / version, linked / name)


def _install_cask(prefix: Path, token: str, version: str = "1.0.0") -> None:
    """Mirror e2e/cli/test_system_prune_brew_cask: a prune-safe mise-owned cask.

    Caskroom/<token>/<version>/bin/<token> is the staged binary; a symlink
    <prefix>/bin/<token> points at it. The receipt records that symlink target
    with a symlink fingerprint whose digest is the sha256 of the binary target
    PATH STRING (the repo's `cask_target_fingerprint` for a symlink). No
    `.metadata` dir (that marks a Homebrew-owned cask, which prune skips).
    Target paths are unique per token so the shared-target guard never trips.
    """
    version_dir = prefix / "Caskroom" / token / version
    binary = version_dir / "bin" / token
    target = prefix / "bin" / token
    (version_dir / "bin").mkdir(parents=True, exist_ok=True)
    (prefix / "bin").mkdir(parents=True, exist_ok=True)
    binary.write_text("#!/bin/sh\n")
    _symlink(binary, target)  # absolute symlink, as the e2e template does
    digest = hashlib.sha256(str(binary).encode()).hexdigest()
    (version_dir / ".mise-cask.toml").write_text(
        textwrap.dedent(
            f"""\
            schema_version = 3
            version = "{version}"
            binaries = ["{target}"]
            prune_safe = true

            [[targets]]
            path = "{target}"

            [targets.fingerprint]
            kind = "symlink"
            digest = "{digest}"
            """
        )
    )


def _symlink(target: Path, link: Path) -> None:
    if link.exists() or link.is_symlink():
        link.unlink()
    os.symlink(target, link)


# ---------------------------------------------------------------------------
# Driving the CLI
# ---------------------------------------------------------------------------


def _write_config(workdir: Path, kept: list[str]) -> None:
    lines = ["[bootstrap.packages]"]
    for entry in kept:
        lines.append(f'"{entry}" = "latest"')
    (workdir / "mise.toml").write_text("\n".join(lines) + "\n")


def _run_prune(workdir: Path, prefix: Path, state: Path, port: int, manager: str) -> str:
    """Run `mise bootstrap packages prune --manager <m> --dry-run` offline.

    Returns combined stdout+stderr. Mirrors the e2e harness isolation: a fake
    HOME/config/state inside workdir, the config path trusted, URL replacements
    pointed at the loopback server, and the fake brew prefix.
    """
    home = workdir / "home"
    for sub in (".config/mise", ".local/share/mise", ".cache/mise"):
        (home / sub).mkdir(parents=True, exist_ok=True)
    state.mkdir(parents=True, exist_ok=True)
    env = {
        **os.environ,
        "HOME": str(home),
        "MISE_EXPERIMENTAL": "1",
        "MISE_YES": "1",
        "MISE_TRUSTED_CONFIG_PATHS": str(workdir),
        "MISE_CONFIG_DIR": str(home / ".config/mise"),
        "MISE_DATA_DIR": str(home / ".local/share/mise"),
        "MISE_CACHE_DIR": str(home / ".cache/mise"),
        "MISE_STATE_DIR": str(state),
        "MISE_SYSTEM_BREW_PREFIX": str(prefix),
        "MISE_URL_REPLACEMENTS": json.dumps(
            {"https://formulae.brew.sh": f"http://127.0.0.1:{port}"}
        ),
    }
    proc = subprocess.run(
        [str(MISE_BIN), "bootstrap", "packages", "prune", "--manager", manager, "--dry-run"],
        cwd=str(workdir),
        env=env,
        capture_output=True,
        text=True,
        timeout=PRUNE_TIMEOUT_S,
        check=False,
    )
    if proc.returncode != 0:
        raise AssertionError(
            f"prune --manager {manager} exited {proc.returncode}\n"
            f"--- stdout ---\n{proc.stdout}\n--- stderr ---\n{proc.stderr}"
        )
    return proc.stdout + proc.stderr


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="session", autouse=True)
def _built() -> None:
    _build_mise()


@pytest.fixture
def world(tmp_path: Path) -> Iterator[tuple[Path, Path, Path, FixtureServer]]:
    """A fresh workdir, fake brew prefix, state dir, and running fixture server."""
    workdir = tmp_path / "work"
    prefix = tmp_path / "brew-prefix"
    state = tmp_path / "state"
    workdir.mkdir()
    prefix.mkdir()
    server = FixtureServer(tmp_path / "fixtures", tmp_path / "port")
    server.start()
    try:
        yield workdir, prefix, state, server
    finally:
        server.stop()


# ---------------------------------------------------------------------------
# Criterion #1 — brew manager keeps a kept cask's formula dependency
# ---------------------------------------------------------------------------


def test_brew_keeps_cask_formula_dependency(world) -> None:
    workdir, prefix, state, server = world
    # app-x is a kept cask depending on formula libdep; libdep is installed but
    # not itself a configured brew: package. orphan is a genuinely-unused
    # installed formula (negative control).
    server.write_cask("app-x", depends_formula=["libdep"])
    server.write_formula("libdep")
    _install_formula_keg(prefix, "libdep")
    _install_formula_keg(prefix, "orphan")
    _install_cask(prefix, "app-x")  # kept cask must physically exist in prefix
    _write_config(workdir, ["brew-cask:app-x"])

    out = _run_prune(workdir, prefix, state, server.port, "brew")

    # Headline: the dependency of the kept cask must be preserved.
    assert "remove brew:libdep@1.0.0" not in out, (
        "the kept cask app-x depends on formula libdep, but prune reported it "
        f"for removal:\n{out}"
    )
    # Negative control: a genuinely-orphaned formula MUST still be pruned, so a
    # keep-everything stub cannot satisfy this test.
    assert "remove brew:orphan@1.0.0" in out, (
        "orphan is unused and must still be pruned; a fix that keeps everything "
        f"is wrong:\n{out}"
    )


# ---------------------------------------------------------------------------
# Criterion #1 (transitive) — brew manager keeps a formula needed only via a
# kept cask's transitively-depended cask
# ---------------------------------------------------------------------------


def test_brew_keeps_transitive_cask_formula_dependency(world) -> None:
    workdir, prefix, state, server = world
    # The kept cask (app-root) declares NO formula dependency of its own; it
    # depends on another cask (mid-cask), and it is THAT cask which depends on
    # formula deeplib. Keeping app-root must therefore keep deeplib, because the
    # brew keep-set has to follow the full transitive cask closure of a kept
    # cask — not just the formulae the directly-configured cask names. A fix
    # that extends the brew keep-set with only the directly-configured casks'
    # own formula dependencies passes test_brew_keeps_cask_formula_dependency
    # but still removes deeplib here. orphan is the negative control.
    server.write_cask("app-root", depends_cask=["mid-cask"])
    server.write_cask("mid-cask", depends_formula=["deeplib"])
    server.write_formula("deeplib")
    _install_formula_keg(prefix, "deeplib")
    _install_formula_keg(prefix, "orphan")
    _install_cask(prefix, "app-root")
    _install_cask(prefix, "mid-cask")  # transitively-needed cask must exist too
    _write_config(workdir, ["brew-cask:app-root"])

    out = _run_prune(workdir, prefix, state, server.port, "brew")

    # Headline: a formula needed only through a transitively-depended cask of
    # the kept cask must be preserved.
    assert "remove brew:deeplib@1.0.0" not in out, (
        "deeplib is a formula dependency of mid-cask, which the kept cask "
        "app-root depends on (app-root -> mid-cask -> formula deeplib); the "
        "brew keep-set must follow the kept cask's full transitive cask "
        f"closure, but prune reported deeplib for removal:\n{out}"
    )
    # Negative control: a genuinely-orphaned formula MUST still be pruned.
    assert "remove brew:orphan@1.0.0" in out, (
        "orphan is unused and must still be pruned; a fix that keeps everything "
        f"is wrong:\n{out}"
    )


# ---------------------------------------------------------------------------
# Criterion #2 — brew-cask manager keeps a transitive cask dependency
# ---------------------------------------------------------------------------


def test_brew_cask_keeps_transitive_cask(world) -> None:
    workdir, prefix, state, server = world
    # A genuine two-hop dependency chain, kept via config:
    #   app-y  (kept) -> runtime-z -> deep-dep
    # Keeping app-y must keep BOTH runtime-z (direct) and deep-dep (transitive,
    # two hops away). A fix that only keeps direct dependencies would still
    # remove deep-dep and fail this test. unused-cask is the negative control.
    server.write_cask("app-y", depends_cask=["runtime-z"])
    server.write_cask("runtime-z", depends_cask=["deep-dep"])
    server.write_cask("deep-dep")
    server.write_cask("unused-cask")
    _install_cask(prefix, "app-y")
    _install_cask(prefix, "runtime-z")
    _install_cask(prefix, "deep-dep")
    _install_cask(prefix, "unused-cask")
    _write_config(workdir, ["brew-cask:app-y"])

    out = _run_prune(workdir, prefix, state, server.port, "brew-cask")

    # Headline: the direct cask dependency must be preserved.
    assert "remove brew-cask:runtime-z@1.0.0" not in out, (
        "the kept cask app-y depends on cask runtime-z, but prune reported it "
        f"for removal:\n{out}"
    )
    # Transitivity: a dependency two hops away must also be preserved — a
    # direct-dependencies-only fix would wrongly remove it.
    assert "remove brew-cask:deep-dep@1.0.0" not in out, (
        "deep-dep is a transitive (two-hop) dependency of the kept cask app-y "
        f"(app-y -> runtime-z -> deep-dep) and must be kept:\n{out}"
    )
    # Negative control: an unreferenced cask MUST still be pruned.
    assert "remove brew-cask:unused-cask@1.0.0" in out, (
        "unused-cask is referenced by nothing and must still be pruned:\n" + out
    )


# ---------------------------------------------------------------------------
# Criterion #3 — closure walk is cycle-safe (behavioral case)
# ---------------------------------------------------------------------------


def test_cask_closure_cycle_safe(world) -> None:
    workdir, prefix, state, server = world
    # cask-a depends on cask-b, cask-b depends back on cask-a: a dependency
    # cycle. Keeping cask-a must terminate (no hang) and keep BOTH casks.
    # unused-cask is the negative control.
    server.write_cask("cask-a", depends_cask=["cask-b"])
    server.write_cask("cask-b", depends_cask=["cask-a"])
    server.write_cask("unused-cask")
    _install_cask(prefix, "cask-a")
    _install_cask(prefix, "cask-b")
    _install_cask(prefix, "unused-cask")
    _write_config(workdir, ["brew-cask:cask-a"])

    out = _run_prune(workdir, prefix, state, server.port, "brew-cask")

    assert "remove brew-cask:cask-a@1.0.0" not in out, out
    assert "remove brew-cask:cask-b@1.0.0" not in out, (
        "cask-b is in the dependency cycle of kept cask-a and must be kept "
        f"(a cycle must not break closure resolution):\n{out}"
    )
    assert "remove brew-cask:unused-cask@1.0.0" in out, (
        "unused-cask is referenced by nothing and must still be pruned:\n" + out
    )
