//! Robustness verifier for the RDP wire-format decoders.
//!
//! Every test drives a PRE-EXISTING public decode entry point and observes the
//! externally-visible contract: decoding a truncated or malformed byte buffer
//! must hand back a `Result` (an `Ok` for a legitimately-short message, an
//! `Err` otherwise) and must NEVER unwind the thread. None of the internal
//! bounds-check plumbing is named or imported here, so any faithful
//! implementation that restores the no-crash contract passes — whether it
//! hardens a shared primitive once or guards each decode site individually.
//!
//! Public surfaces exercised (all present at the base revision), spread across
//! four separate channel crates so that the no-crash contract is observed
//! through the shared cursor primitive, not at any one decode site:
//!   * `ironrdp_core::decode::<ironrdp_pdu::mcs::ConnectInitial>` — the MCS /
//!     conference-create path.
//!   * `ironrdp_core::{encode_vec, decode}` over
//!     `ironrdp_pdu::gcc::ClientCoreData` — the client-core-data block with its
//!     optional trailing fields.
//!   * `ironrdp_rdpdr::pdu::RdpdrPdu::decode_io_completion` — the drive
//!     query-directory completion.
//!   * `ironrdp_core::decode::<ironrdp_egfx::pdu::ResetGraphicsPdu>` — a graphics
//!     channel message whose fixed-structure body ends in a trailing skip whose
//!     width is computed from the body contents. A buffer cut inside that body
//!     leaves the skip reaching past the end of the input; the contract is that
//!     every such prefix is rejected with an error.
//!
//! Mechanic: each decode call runs inside `catch_unwind`. A thread unwind (a
//! crash on bad input) is observed as the caught `Err` and fails the test; a
//! returned `Result` passes. Two kinds of positive pin keep a blunt "reject
//! every short buffer" or "swallow every crash" change from passing. The empty
//! drive-response case pins the *successful* decode of a valid zero-length
//! message. The connect-initial and reset-graphics cases pin that a buffer
//! truncated inside a mandatory region decodes to `Err`, not `Ok`: a decoder
//! that advances its cursor past the end without checking — then simply stops —
//! returns a spurious `Ok` here even though no crash occurred, and a wrapper
//! that only converts crashes into errors cannot turn that `Ok` into the
//! required `Err`.

use std::panic::{catch_unwind, AssertUnwindSafe};

use ironrdp_core::{decode, encode_vec, ReadCursor};
use ironrdp_pdu::gcc::{
    ClientCoreData, ClientCoreOptionalData, ClientEarlyCapabilityFlags, ClientGccBlocks, ClientSecurityData,
    ColorDepth, ConnectionType, EncryptionMethod, HighColorDepth, KeyboardType, RdpVersion, SecureAccessSequence,
    SupportedColorDepths,
};
use ironrdp_pdu::gcc::{Monitor, MonitorFlags};
use ironrdp_pdu::mcs::ConnectInitial;
use ironrdp_pdu::nego::SecurityProtocol;
use ironrdp_egfx::pdu::ResetGraphicsPdu;
use ironrdp_rdpdr::pdu::efs::{
    DeviceIoResponse, FileInformationClassLevel, MajorFunction, MinorFunction, NtStatus,
};
use ironrdp_rdpdr::pdu::RdpdrPdu;

/// A client-core-data block whose optional tail is fully populated, so a
/// truncation can land *inside* the optional fields. Mirrors the shape the
/// library already round-trips in its own fixtures.
fn client_core_data_full() -> ClientCoreData {
    let mut optional_data = ClientCoreOptionalData::default();
    optional_data.post_beta2_color_depth = Some(ColorDepth::Bpp8);
    optional_data.client_product_id = Some(1);
    optional_data.serial_number = Some(0);
    optional_data.high_color_depth = Some(HighColorDepth::Bpp24);
    optional_data.supported_color_depths =
        Some(SupportedColorDepths::BPP24 | SupportedColorDepths::BPP16 | SupportedColorDepths::BPP15);
    optional_data.early_capability_flags = Some(ClientEarlyCapabilityFlags::SUPPORT_ERR_INFO_PDU);
    optional_data.dig_product_id = Some(String::from("69712-783-0357974-42714"));
    optional_data.connection_type = Some(ConnectionType::NotUsed);
    optional_data.server_selected_protocol = Some(SecurityProtocol::empty());
    optional_data.desktop_physical_width = Some(5000);
    optional_data.desktop_physical_height = Some(3000);
    optional_data.desktop_orientation = Some(90);
    optional_data.desktop_scale_factor = Some(200);
    optional_data.device_scale_factor = Some(140);

    ClientCoreData {
        version: RdpVersion::V5_PLUS,
        desktop_width: 1280,
        desktop_height: 1024,
        color_depth: ColorDepth::Bpp4,
        sec_access_sequence: SecureAccessSequence::Del,
        keyboard_layout: 1033,
        client_build: 3790,
        client_name: String::from("ELTONS-DEV2"),
        keyboard_type: KeyboardType::IBM_ENHANCED,
        keyboard_subtype: 0,
        keyboard_functional_keys_count: 12,
        ime_file_name: String::new(),
        optional_data,
    }
}

fn client_security_data() -> ClientSecurityData {
    ClientSecurityData {
        encryption_methods: EncryptionMethod::BIT_40
            | EncryptionMethod::BIT_128
            | EncryptionMethod::BIT_56
            | EncryptionMethod::FIPS,
        ext_encryption_methods: 0,
    }
}

fn client_gcc_blocks() -> ClientGccBlocks {
    ClientGccBlocks {
        core: client_core_data_full(),
        security: client_security_data(),
        network: None,
        cluster: None,
        monitor: None,
        message_channel: None,
        multi_transport_channel: None,
        monitor_extended: None,
    }
}

fn some_device_io_response() -> DeviceIoResponse {
    DeviceIoResponse {
        device_id: 7,
        completion_id: 99,
        io_status: NtStatus::SUCCESS,
    }
}

/// C1 — the MCS Connect Initial / Conference Create Request path.
///
/// Build a valid Connect Initial, serialize it, then decode every byte prefix.
/// A buffer cut short of the PER padding that follows the conference name used
/// to push the read cursor past the buffer end and crash a later read.
#[test]
fn truncated_connect_initial_never_panics() {
    let pdu = ConnectInitial::with_gcc_blocks(client_gcc_blocks())
        .expect("a Connect Initial should be constructible from valid GCC blocks");
    let bytes = encode_vec(&pdu).expect("a valid Connect Initial should serialize");
    assert!(bytes.len() > 16, "expected a non-trivial Connect Initial encoding");

    for len in 0..bytes.len() {
        let prefix = &bytes[..len];
        let outcome = catch_unwind(AssertUnwindSafe(|| decode::<ConnectInitial>(prefix)));
        let result = match outcome {
            Ok(result) => result,
            Err(_) => panic!(
                "decoding a {len}-byte prefix of a Connect Initial crashed instead of returning a decode error",
            ),
        };
        // A Connect Initial is a fixed-structure message with no optional tail,
        // so no prefix shorter than the whole encoding is a valid message: each
        // one must decode to an error. A decoder that advances its cursor past
        // the end of a truncated buffer without checking, then reads no further,
        // returns a spurious `Ok` here — and a wrapper that only turns crashes
        // into errors leaves that `Ok` in place.
        assert!(
            result.is_err(),
            "decoding a {len}-byte prefix of a Connect Initial returned Ok, but a buffer cut short of \
             the full message is not a valid Connect Initial and must be rejected with a decode error",
        );
    }

    // The full buffer still decodes successfully.
    decode::<ConnectInitial>(&bytes).expect("the full Connect Initial should decode");
}

/// C2 — the client-core-data block's optional trailing fields.
///
/// Two of the optional fields (physical height after physical width; device
/// scale factor after desktop scale factor) used an infallible read on the
/// assumption that the pair always arrives together. A buffer cut between a
/// pair crashed the decoder; every prefix must now return a `Result`.
#[test]
fn truncated_client_core_data_never_panics() {
    let core = client_core_data_full();
    let bytes = encode_vec(&core).expect("a valid client core data block should serialize");
    assert!(bytes.len() > 64, "expected a client core data encoding with a populated optional tail");

    for len in 0..bytes.len() {
        let prefix = &bytes[..len];
        let outcome = catch_unwind(AssertUnwindSafe(|| decode::<ClientCoreData>(prefix)));
        assert!(
            outcome.is_ok(),
            "decoding a {len}-byte prefix of a client core data block crashed instead of returning a decode error",
        );
    }

    // The full buffer still round-trips to the original value.
    let decoded = decode::<ClientCoreData>(&bytes).expect("the full client core data block should decode");
    assert_eq!(decoded, core, "a full client core data block must round-trip unchanged");
}

/// C3 — the drive query-directory completion.
///
/// Its trailing padding byte is optional: a zero-length response that ends
/// right after the length field is valid and must decode successfully, while
/// the padding is consumed only when actually present. Separately, no
/// query-directory completion input may crash the decoder.
#[test]
fn empty_query_directory_response_decodes_without_consuming_absent_padding() {
    // Zero length, no trailing padding byte: a valid, minimal response.
    let wire: [u8; 4] = [0, 0, 0, 0];
    let mut src = ReadCursor::new(&wire);

    let outcome = catch_unwind(AssertUnwindSafe(|| {
        RdpdrPdu::decode_io_completion(
            MajorFunction::DirectoryControl,
            MinorFunction::IRP_MN_QUERY_DIRECTORY,
            Some(FileInformationClassLevel::FILE_BASIC_INFORMATION),
            None,
            some_device_io_response(),
            &mut src,
        )
    }));
    let decoded = outcome
        .expect("decoding a zero-length query-directory response crashed")
        .expect("a zero-length query-directory response with no trailing padding must decode successfully");
    assert!(
        matches!(decoded, RdpdrPdu::ClientDriveQueryDirectoryResponse(_)),
        "a zero-length query-directory response must decode to a drive query-directory response",
    );
    // No optional padding byte was present, so none may be consumed: the
    // four-byte length field is the entire message. An implementation that
    // skips an absent padding byte over-reads past the end here.
    assert_eq!(
        src.pos(),
        wire.len(),
        "the decoder consumed a padding byte that the zero-length response does not carry",
    );

    // When a trailing padding byte IS present, it is consumed and the message
    // still decodes successfully.
    let padded: [u8; 5] = [0, 0, 0, 0, 0];
    let mut src = ReadCursor::new(&padded);
    let decoded = RdpdrPdu::decode_io_completion(
        MajorFunction::DirectoryControl,
        MinorFunction::IRP_MN_QUERY_DIRECTORY,
        Some(FileInformationClassLevel::FILE_BASIC_INFORMATION),
        None,
        some_device_io_response(),
        &mut src,
    )
    .expect("a zero-length query-directory response with a trailing padding byte must decode");
    assert!(matches!(
        decoded,
        RdpdrPdu::ClientDriveQueryDirectoryResponse(_)
    ));
}

/// C3 (continued) — no query-directory completion buffer may crash the decoder,
/// including truncated and over-claiming length prefixes.
#[test]
fn truncated_query_directory_response_never_panics() {
    // A selection of short and malformed bodies: empty, sub-length-field,
    // a length that claims more bytes than follow, and a zero-length body
    // with and without the optional padding byte.
    let bodies: &[&[u8]] = &[
        &[],
        &[0],
        &[0, 0],
        &[0, 0, 0],
        &[0, 0, 0, 0],
        &[0, 0, 0, 0, 0],
        &[0x10, 0, 0, 0],
        &[0x10, 0, 0, 0, 0xaa, 0xbb],
        &[0xff, 0xff, 0xff, 0xff],
    ];

    for body in bodies {
        let outcome = catch_unwind(AssertUnwindSafe(|| {
            let mut src = ReadCursor::new(body);
            RdpdrPdu::decode_io_completion(
                MajorFunction::DirectoryControl,
                MinorFunction::IRP_MN_QUERY_DIRECTORY,
                Some(FileInformationClassLevel::FILE_BASIC_INFORMATION),
                None,
                some_device_io_response(),
                &mut src,
            )
        }));
        assert!(
            outcome.is_ok(),
            "decoding a {}-byte query-directory completion body crashed instead of returning a decode error",
            body.len(),
        );
    }
}

/// A reset-graphics message with `n` monitor entries. The body is a fixed-width
/// header, the monitor array, then a trailing skip region whose width is
/// `total - header - monitors` — a value derived from the message contents, not
/// a fixed constant.
fn reset_graphics(n: usize) -> ResetGraphicsPdu {
    let monitor = Monitor {
        left: 0,
        top: 0,
        right: 1920,
        bottom: 1080,
        flags: MonitorFlags::PRIMARY,
    };
    ResetGraphicsPdu {
        width: 1920,
        height: 1080,
        monitors: vec![monitor; n],
    }
}

/// C4 — a graphics-channel message whose body ends in a content-derived skip.
///
/// This decode path lives in a different channel crate from the MCS, GCC and
/// RDPDR paths above, and reaches the same shared cursor primitive through its
/// own call site. After the monitor array the decoder skips a trailing region
/// whose width it computes from the body; on a buffer cut inside the body the
/// skip runs past the end of the input. The contract: every truncated prefix is
/// rejected with a decode error and none crashes, while the full message still
/// decodes. A decode site that skips without checking the remaining length
/// returns a spurious `Ok` for the truncated prefixes (the cursor is simply left
/// past the end and nothing reads afterwards), so this case fails both a
/// single-subsystem partial fix that never reaches this call site and a wrapper
/// that merely converts crashes into errors.
#[test]
fn truncated_reset_graphics_rejects_short_buffers() {
    for monitor_count in [0_usize, 1, 2] {
        let pdu = reset_graphics(monitor_count);
        let bytes = encode_vec(&pdu).expect("a valid reset-graphics message should serialize");
        assert!(
            bytes.len() > 16,
            "expected a non-trivial reset-graphics encoding for {monitor_count} monitors",
        );

        for len in 0..bytes.len() {
            let prefix = &bytes[..len];
            let outcome = catch_unwind(AssertUnwindSafe(|| decode::<ResetGraphicsPdu>(prefix)));
            let result = match outcome {
                Ok(result) => result,
                Err(_) => panic!(
                    "decoding a {len}-byte prefix of a reset-graphics message ({monitor_count} monitors) \
                     crashed instead of returning a decode error",
                ),
            };
            assert!(
                result.is_err(),
                "decoding a {len}-byte prefix of a reset-graphics message ({monitor_count} monitors) \
                 returned Ok, but a buffer cut short of the full message is not a valid message and must \
                 be rejected with a decode error",
            );
        }

        // The full buffer still decodes successfully.
        let decoded = decode::<ResetGraphicsPdu>(&bytes).expect("the full reset-graphics message should decode");
        assert_eq!(decoded, pdu, "a full reset-graphics message must round-trip unchanged");
    }
}
