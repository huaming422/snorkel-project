#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
# Rust Cargo workspace; the image baked the dependency closure at the base
# commit (cargo registry + target warmed). Grade time is offline-first.
cd /repo/ironrdp

# Fail fast on a cache miss instead of reaching for a dead network.
export CARGO_NET_OFFLINE=true

# Dependencies: offline-first against the image bake, logged online fallback.
if cargo fetch --locked --offline > /tmp/test-setup-fetch.log 2>&1; then
    echo "[offline-first] cargo deps satisfied from image bake"
elif cargo fetch --locked >> /tmp/test-setup-fetch.log 2>&1; then
    echo "[test-setup] cargo deps fetched online (image bake was stale)"
else
    tail -40 /tmp/test-setup-fetch.log >&2
    exit 1
fi

# The verifier's integration test drives public decode surfaces from four
# channel crates (ironrdp-pdu, ironrdp-rdpdr and ironrdp-egfx) so the no-crash
# contract is observed through the shared cursor primitive, not at any single
# site. The host crate (ironrdp-rdpdr) already depends on ironrdp-pdu; add
# ironrdp-egfx as a dev-dependency so its public `ResetGraphicsPdu` decode
# surface is reachable from the injected test. Idempotent: skip if already
# present. This touches only the test build — no library dependency changes.
RDPDR_CARGO=crates/ironrdp-rdpdr/Cargo.toml
if ! grep -q '^ironrdp-egfx' "${RDPDR_CARGO}"; then
    if grep -q '^\[dev-dependencies\]' "${RDPDR_CARGO}"; then
        sed -i '/^\[dev-dependencies\]/a ironrdp-egfx = { path = "../ironrdp-egfx" }' "${RDPDR_CARGO}"
    else
        printf '\n[dev-dependencies]\nironrdp-egfx = { path = "../ironrdp-egfx" }\n' >> "${RDPDR_CARGO}"
    fi
fi

# No services to start and no data to seed — this is a pure in-process decoder
# bug. The verifier (injected Rust integration test) builds and runs via the
# Rust runner; no assertion logic belongs here.
