## Task

heads up, our RDP message decoder falls over on bad input from the peer. if whatever's on the other end of the wire sends a short, cut-off, or just plain garbage message, the decode path panics and takes the whole connection down with it instead of rejecting the thing cleanly.

this is reachable straight from untrusted input, so it's not great: the remote side gets to crash us by sending a partial or malformed message. decoding should fail gracefully and hand back an error, never panic.

can you dig in and make the decode path robust against truncated and malformed messages? no input should be able to crash it.
