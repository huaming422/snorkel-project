import { assert, it } from "@effect/vitest";
import {
  CommandId,
  EventId,
  type ModelSelection,
  type OrchestrationV2AppThread,
  type OrchestrationV2DomainEvent,
  ProjectId,
  ProviderInstanceId,
  RunId,
  ThreadId,
} from "@t3tools/contracts";
import * as DateTime from "effect/DateTime";
import * as Effect from "effect/Effect";
import * as Fiber from "effect/Fiber";
import * as Layer from "effect/Layer";
import * as Option from "effect/Option";
import * as Ref from "effect/Ref";
import * as TestClock from "effect/testing/TestClock";

import { SqlitePersistenceMemory } from "../persistence/Layers/Sqlite.ts";
import { layer as commandReceiptStoreLayer } from "./CommandReceiptStore.ts";
import {
  EffectOutboxV2,
  type EffectOutboxV2Shape,
  layer as effectOutboxLayer,
} from "./EffectOutbox.ts";
import {
  layerWithOptions as effectWorkerLayerWithOptions,
  OrchestrationEffectExecutorV2,
  runDaemonWithOptions as runEffectWorkerDaemonWithOptions,
} from "./EffectWorker.ts";
import { EventSinkV2, layer as eventSinkLayer } from "./EventSink.ts";
import { layer as eventStoreLayer } from "./EventStore.ts";
import { layer as idAllocatorLayer } from "./IdAllocator.ts";
import { layer as projectionMaintenanceLayer } from "./ProjectionMaintenance.ts";
import { layer as projectionStoreLayer } from "./ProjectionStore.ts";

// ---------------------------------------------------------------------------
// Harness wiring — mirrors the layer composition in
// apps/server/src/orchestration-v2/FoundationPersistence.test.ts (the template
// the task brief points at). One in-memory node:sqlite database, built once per
// test via `Layer.fresh(TestLayer)` for isolation. Within that single build the
// outbox and database layer references are shared, so the command-write surface
// and a separately-constructed worker observe the same durable queue and the
// same in-memory availability signal (Effect memoizes a layer value per build).
// ---------------------------------------------------------------------------
const databaseLayer = SqlitePersistenceMemory;
const eventStoreProvided = eventStoreLayer.pipe(Layer.provideMerge(databaseLayer));
const projectionStoreProvided = projectionStoreLayer.pipe(Layer.provideMerge(databaseLayer));
const storesProvided = Layer.mergeAll(databaseLayer, eventStoreProvided, projectionStoreProvided);
const eventSinkProvided = eventSinkLayer.pipe(Layer.provide(storesProvided));
const effectOutboxProvided = effectOutboxLayer.pipe(Layer.provide(databaseLayer));
const commandReceiptStoreProvided = commandReceiptStoreLayer.pipe(Layer.provide(databaseLayer));
const projectionMaintenanceProvided = projectionMaintenanceLayer.pipe(Layer.provide(storesProvided));

const TestLayer = Layer.mergeAll(
  storesProvided,
  eventSinkProvided,
  effectOutboxProvided,
  commandReceiptStoreProvided,
  idAllocatorLayer,
  projectionMaintenanceProvided,
);

const providerInstanceId = ProviderInstanceId.make("codex");
const modelSelection = {
  instanceId: providerInstanceId,
  model: "gpt-5.4",
} satisfies ModelSelection;

function makeThread(threadId: ThreadId, now: DateTime.Utc): OrchestrationV2AppThread {
  return {
    createdBy: "user",
    creationSource: "web",
    id: threadId,
    projectId: ProjectId.make(`project:${threadId}`),
    title: `Thread ${threadId}`,
    providerInstanceId,
    modelSelection,
    runtimeMode: "full-access",
    interactionMode: "default",
    branch: null,
    worktreePath: null,
    activeProviderThreadId: null,
    lineage: {
      parentThreadId: null,
      relationshipToParent: null,
      rootThreadId: threadId,
    },
    forkedFrom: null,
    createdAt: now,
    updatedAt: now,
    archivedAt: null,
    settledOverride: null,
    settledAt: null,
    deletedAt: null,
  };
}

function threadCreatedEvent(input: {
  readonly id: string;
  readonly thread: OrchestrationV2AppThread;
  readonly now: DateTime.Utc;
}): OrchestrationV2DomainEvent {
  return {
    id: EventId.make(input.id),
    type: "thread.created",
    threadId: input.thread.id,
    providerInstanceId,
    occurredAt: input.now,
    payload: input.thread,
  };
}

// A counting performer records how many effects were actually performed. The
// request payload is irrelevant here — these cases assert scheduling, not
// side-effect content.
const countingExecutor = (performed: Ref.Ref<number>) =>
  Layer.succeed(
    OrchestrationEffectExecutorV2,
    OrchestrationEffectExecutorV2.of({
      execute: () => Ref.update(performed, (count) => count + 1),
    }),
  );

// Yield the fiber scheduler (without moving the clock) until a condition holds
// or a bounded step budget is spent. Bounded so a slot that never makes progress
// fails its assertion instead of hanging the suite.
const settleUntil = (condition: Effect.Effect<boolean>, budget = 4_000): Effect.Effect<void> =>
  Effect.gen(function* () {
    let steps = 0;
    while (steps < budget && !(yield* condition)) {
      yield* Effect.yieldNow;
      steps += 1;
    }
  });

// Yield a fixed, small number of scheduler turns so a freshly-forked slot can run
// its first claim and park on its wait.
const settleTurns = (turns = 64): Effect.Effect<void> =>
  Effect.gen(function* () {
    for (let i = 0; i < turns; i += 1) {
      yield* Effect.yieldNow;
    }
  });

// Consume any availability tokens currently buffered, so a later "no new token"
// check observes only signals emitted after this point. (Enqueue buffers a token
// on some designs and not others; draining normalises that difference away.)
const drainAvailability = (outbox: EffectOutboxV2Shape): Effect.Effect<void> =>
  Effect.gen(function* () {
    while (true) {
      const waiter = yield* outbox.awaitAvailable.pipe(Effect.forkChild);
      yield* settleTurns(4);
      if (waiter.pollUnsafe() === undefined) {
        yield* Fiber.interrupt(waiter);
        return;
      }
    }
  });

// True iff a freshly-forked waiter on awaitAvailable observes a token promptly.
const sawAvailabilityToken = (outbox: EffectOutboxV2Shape): Effect.Effect<boolean> =>
  Effect.gen(function* () {
    const waiter = yield* outbox.awaitAvailable.pipe(Effect.forkChild);
    yield* settleTurns(8);
    const got = waiter.pollUnsafe() !== undefined;
    if (!got) yield* Fiber.interrupt(waiter);
    return got;
  });

// ── A claimable deadline a short interval out is honoured near that deadline ──
// The row is future-dated (not yet due), so a correct sleep-until-deadline slot
// wakes at exactly that instant with no floor applied. 30ms sits comfortably below
// any fixed idle-poll grid, so a slot that still drives timing off a ~50ms poll
// tick performs it late and this assertion fails on it.
it.effect("performs a durable deadline at approximately its scheduled time", () =>
  Effect.gen(function* () {
    const outbox = yield* EffectOutboxV2;
    const performed = yield* Ref.make(0);
    const now = yield* DateTime.now;

    yield* outbox.enqueue([
      {
        id: "effect:deadline",
        commandId: CommandId.make("command:deadline"),
        threadId: ThreadId.make("thread:deadline"),
        request: { type: "terminal.cleanup" },
        availableAt: DateTime.add(now, { milliseconds: 30 }),
      },
    ]);

    const workerLayer = effectWorkerLayerWithOptions({ workerId: "deadline-worker" }).pipe(
      Layer.provide(Layer.merge(Layer.succeed(EffectOutboxV2, outbox), countingExecutor(performed))),
    );

    yield* Effect.gen(function* () {
      // Default options only: the slot's own (contract-mandated infrequent)
      // safety poll governs. A deadline this far inside that interval must still
      // be served from the deadline itself, not deferred to the next poll tick.
      yield* runEffectWorkerDaemonWithOptions({ concurrency: 1 }).pipe(Effect.forkScoped);
      yield* settleTurns();

      yield* TestClock.adjust("29 millis");
      yield* settleTurns();
      assert.equal(yield* Ref.get(performed), 0);

      yield* TestClock.adjust("1 millis");
      yield* settleUntil(Ref.get(performed).pipe(Effect.map((n) => n >= 1)));
      assert.equal(yield* Ref.get(performed), 1);
    }).pipe(Effect.provide(workerLayer), Effect.scoped);
  }).pipe(Effect.provide(Layer.fresh(TestLayer)), Effect.provide(TestClock.layer())),
);

// ── A due-but-blocked row does not cause a hot loop ──────────────────────────
// One thread has a running effect; its second row is due but ineligible. A
// counting claim wrapper records probes over a full virtual second. A fixed
// idle-poll loop re-probes many times; a slot that sleeps until a real deadline
// (finding none claimable) stays quiet.
it.effect("does not spin on a due row blocked by a running same-thread effect", () =>
  Effect.gen(function* () {
    const real = yield* EffectOutboxV2;
    const probes = yield* Ref.make(0);
    const probing: EffectOutboxV2Shape = {
      ...real,
      claimNext: (input) =>
        Ref.update(probes, (count) => count + 1).pipe(Effect.andThen(real.claimNext(input))),
    };
    const performed = yield* Ref.make(0);
    const commandId = CommandId.make("command:blocked");
    const threadId = ThreadId.make("thread:blocked");

    yield* real.enqueue([
      { id: "effect:blocked:a", commandId, threadId, request: { type: "terminal.cleanup" } },
      { id: "effect:blocked:b", commandId, threadId, request: { type: "terminal.cleanup" } },
    ]);
    // Leave the first row running so the second is permanently ineligible
    // (same-thread serialization) for the duration of the window.
    assert.isTrue(
      Option.isSome(yield* real.claimNext({ workerId: "setup", leaseDurationMs: 120_000 })),
    );

    const workerLayer = effectWorkerLayerWithOptions({ workerId: "blocked-worker" }).pipe(
      Layer.provide(Layer.merge(Layer.succeed(EffectOutboxV2, probing), countingExecutor(performed))),
    );

    yield* Effect.gen(function* () {
      yield* runEffectWorkerDaemonWithOptions({ concurrency: 1 }).pipe(Effect.forkScoped);
      yield* settleUntil(Ref.get(probes).pipe(Effect.map((n) => n >= 1)));
      yield* settleTurns();
      const before = yield* Ref.get(probes);

      yield* TestClock.adjust("1000 millis");
      yield* settleTurns();
      const after = yield* Ref.get(probes);

      assert.equal(yield* Ref.get(performed), 0);
      // A fixed-grid idle poll re-probes ~20×/sec; any slot that sleeps until a
      // real claimable deadline (there is none) stays effectively quiet. The
      // bound rejects the tight grid with wide margin while admitting any
      // genuinely-infrequent safety poll.
      assert.isAtMost(after - before, 3);
    }).pipe(Effect.provide(workerLayer), Effect.scoped);
  }).pipe(Effect.provide(Layer.fresh(TestLayer)), Effect.provide(TestClock.layer())),
);

// ── Unblocking same-thread work re-notifies a parked waiter ──────────────────
// Two rows share a thread; the first (process-bound) is claimed and left running,
// so the second is ineligible. Cancelling the running one through the cancel path
// settles it and must re-emit an availability token so a parked slot can pick up
// the now-eligible second row — rather than leaving it to idle until a poll tick.
// A solution that settles work silently (no re-notify when a thread unblocks)
// leaves the waiter parked and this assertion fails on it.
it.effect("re-notifies a parked waiter when unblocking same-thread work", () =>
  Effect.gen(function* () {
    const outbox = yield* EffectOutboxV2;
    const commandId = CommandId.make("command:renotify");
    const threadId = ThreadId.make("thread:renotify");

    // Ids are chosen so the running (process-bound) row sorts first on the
    // claimNext tiebreak (available_at, created_at, effect_id all tie here), so
    // the first claim deterministically takes it and leaves the sibling blocked.
    yield* outbox.enqueue([
      {
        id: "effect:renotify:a-running",
        commandId,
        threadId,
        request: { type: "provider-turn.start", runId: RunId.make("run:renotify") },
      },
      {
        id: "effect:renotify:b-pending",
        commandId,
        threadId,
        request: { type: "terminal.cleanup" },
      },
    ]);

    const running = yield* outbox.claimNext({ workerId: "renotify-setup", leaseDurationMs: 30_000 });
    assert.isTrue(Option.isSome(running));
    if (Option.isNone(running)) return;
    assert.equal(running.value.request.type, "provider-turn.start");

    // Clear any token buffered by the setup so only the unblock's signal remains.
    yield* drainAvailability(outbox);

    const cancelledIds = yield* outbox.cancelUnsettled({
      threadId,
      effectTypes: ["provider-turn.start"],
      reason: "settle the running row",
    });
    yield* outbox.signalCancellations(cancelledIds);

    assert.isTrue(yield* sawAvailabilityToken(outbox));

    // The previously-blocked row is now claimable.
    const unblocked = yield* outbox.claimNext({
      workerId: "renotify-setup",
      leaseDurationMs: 30_000,
    });
    assert.isTrue(Option.isSome(unblocked));
    if (Option.isSome(unblocked)) assert.equal(unblocked.value.request.type, "terminal.cleanup");
  }).pipe(Effect.provide(Layer.fresh(TestLayer))),
);

// ── A deduplicated command replay emits no availability token ────────────────
// The first commit lands its effect and emits a signal; replaying the identical
// command is deduplicated and inserts nothing, so it must not emit a further
// token for work it did not create.
it.effect("does not emit availability for a deduplicated command replay", () =>
  Effect.gen(function* () {
    const eventSink = yield* EventSinkV2;
    const outbox = yield* EffectOutboxV2;
    const now = yield* DateTime.now;
    const commandId = CommandId.make("command:replay");
    const threadId = ThreadId.make("thread:replay");
    const input = {
      commandId,
      threadId,
      commandType: "replay.probe",
      acceptedAt: now,
      events: [threadCreatedEvent({ id: "event:replay", thread: makeThread(threadId, now), now })],
      effects: [
        { id: "effect:replay", commandId, threadId, request: { type: "terminal.cleanup" as const } },
      ],
    };

    const first = yield* eventSink.commitCommand(input);
    assert.isTrue(first.committed);
    // Clear the first commit's token(s); what follows is only the replay's doing.
    yield* drainAvailability(outbox);

    const replay = yield* eventSink.commitCommand(input);
    assert.isFalse(replay.committed);

    assert.isFalse(yield* sawAvailabilityToken(outbox));
  }).pipe(Effect.provide(Layer.fresh(TestLayer))),
);

// ── Claim failures are spaced by a backoff, not spun ─────────────────────────
// Every claim fails. A claim-error backoff retries on the order of seconds; a
// tight idle loop re-attempts tens of times per virtual second.
it.effect("spaces attempts when claiming keeps failing", () =>
  Effect.gen(function* () {
    const real = yield* EffectOutboxV2;
    const attempts = yield* Ref.make(0);
    const failing: EffectOutboxV2Shape = {
      ...real,
      claimNext: () =>
        Ref.update(attempts, (count) => count + 1).pipe(
          Effect.andThen(Effect.fail(new Error("simulated claim failure"))),
        ) as ReturnType<EffectOutboxV2Shape["claimNext"]>,
    };
    const performed = yield* Ref.make(0);

    const workerLayer = effectWorkerLayerWithOptions({ workerId: "backoff-worker" }).pipe(
      Layer.provide(Layer.merge(Layer.succeed(EffectOutboxV2, failing), countingExecutor(performed))),
    );

    yield* Effect.gen(function* () {
      yield* runEffectWorkerDaemonWithOptions({ concurrency: 1 }).pipe(Effect.forkScoped);
      yield* settleUntil(Ref.get(attempts).pipe(Effect.map((n) => n >= 1)));
      yield* settleTurns();
      const before = yield* Ref.get(attempts);

      yield* TestClock.adjust("1000 millis");
      yield* settleTurns();
      const after = yield* Ref.get(attempts);

      // A tight idle loop re-attempts tens of times per virtual second; any
      // real claim-error backoff retries on the order of seconds. The bound
      // rejects the spin with wide margin while admitting a fixed sleep or a
      // capped-exponential schedule whose first step stays sub-second.
      assert.isAtMost(after - before, 3);
    }).pipe(Effect.provide(workerLayer), Effect.scoped);
  }).pipe(Effect.provide(Layer.fresh(TestLayer)), Effect.provide(TestClock.layer())),
);

// ── Normal claim/execute/settle semantics stay intact ────────────────────────
// A pool of slots claims a ready effect exactly once, performs it, and marks it
// succeeded; it is not performed again on a later tick.
it.effect("claims and performs a ready effect exactly once", () =>
  Effect.gen(function* () {
    const outbox = yield* EffectOutboxV2;
    const performed = yield* Ref.make(0);
    const effectId = "effect:exactly-once";

    yield* outbox.enqueue([
      {
        id: effectId,
        commandId: CommandId.make("command:exactly-once"),
        threadId: ThreadId.make("thread:exactly-once"),
        request: { type: "terminal.cleanup" },
      },
    ]);

    const workerLayer = effectWorkerLayerWithOptions({ workerId: "once-worker" }).pipe(
      Layer.provide(Layer.merge(Layer.succeed(EffectOutboxV2, outbox), countingExecutor(performed))),
    );

    yield* Effect.gen(function* () {
      yield* runEffectWorkerDaemonWithOptions({ concurrency: 4 }).pipe(Effect.forkScoped);
      yield* settleUntil(Ref.get(performed).pipe(Effect.map((n) => n >= 1)));
      assert.equal(yield* Ref.get(performed), 1);

      const settled = yield* outbox.get(effectId);
      assert.isTrue(Option.isSome(settled));
      if (Option.isSome(settled)) assert.equal(settled.value.status, "succeeded");

      yield* TestClock.adjust("500 millis");
      yield* settleTurns();
      assert.equal(yield* Ref.get(performed), 1);
    }).pipe(Effect.provide(workerLayer), Effect.scoped);
  }).pipe(Effect.provide(Layer.fresh(TestLayer)), Effect.provide(TestClock.layer())),
);
