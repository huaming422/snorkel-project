## Task

The managed .NET provider currently connects to databases in the local process. Extend it so applications can use the same provider with a hosted Turso database over HTTP. Remote SQL traffic must follow the Turso/libSQL Hrana HTTP pipeline protocol at `/v2/pipeline`.

Keep remote use within the provider's existing ADO.NET connection, command, transaction, batch, and data reader surface. An application should be able to point its existing provider code at a remote database without adopting a separate remote client API. Make this change in the managed .NET client library. The native engine, SQLite compatibility layer, and ORM integration are outside the task.

## User stories / requirements

- With a remote Turso URL, a parameterized command returns its columns and rows through the usual data reader, including database null for a null value. A scalar command yields the first value in the first row, and a command without a result set yields the affected row count.
- A remote connection validates its URL, transport, and options before contacting the server and gives a clear error for incompatible settings. The `Auth Token` connection string keyword requires HTTPS except for a loopback host. An explicit TLS setting must agree with the URL scheme, and options limited to local or remote use cannot be mixed with the other connection kind.
- Remote transactions keep their statements, commit, and rollback in the same continued server session. A SQL error must leave an active transaction session available for rollback. A transport failure must make the connection unusable.
- On a remote connection, a batch can collect several commands, submit them together, and expose each command result set in sequence. Local connections do not offer batching.
