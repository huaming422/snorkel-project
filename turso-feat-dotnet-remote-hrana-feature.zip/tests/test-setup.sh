#!/usr/bin/env bash
# Sourced before the verifier runs. Everything the focused .NET test suite
# needs is baked into the image at the base commit: the pinned .NET 9 SDK
# (/opt/dotnet on PATH), the warm NuGet cache (/opt/nuget/packages), and the
# Turso.Tests build assets (obj/project.assets.json), so `dotnet build/test
# --no-restore` runs fully offline. The remote Hrana suite talks only to an
# in-process loopback TcpListener mock, so no native library or network is
# required. Nothing to install here.
set -euo pipefail

export DOTNET_ROOT="${DOTNET_ROOT:-/opt/dotnet}"
export NUGET_PACKAGES="${NUGET_PACKAGES:-/opt/nuget/packages}"
export PATH="/opt/dotnet:${PATH}"
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_NOLOGO=1 DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1

# Sanity: the SDK must be reachable.
dotnet --version >/dev/null

echo "[test-setup] turso-feat-dotnet-remote-hrana .NET test env ready (offline)"
