#!/bin/bash
# Validation setup for turso-feat-dotnet-remote-hrana.
#
# The stories are pytest shells that run a shared C# fixture through
# `dotnet test`. This script stages that fixture into the test project and
# warms the offline build so the first story run is fast and any compile
# problem surfaces here, loudly, rather than as a silent empty test run.
#
# Sourced (not exec'd) by the validation runner, before the Step-1 repo
# checkpoint, so the staged file lives under a path the integrity check
# excludes (`__validation__/`) and never counts as a repository edit.

set -euo pipefail

REPO_DIR="/repo/${REPO_NAME:-turso}"
PROJECT_DIR="$REPO_DIR/bindings/dotnet/src/Turso.Tests"
STAGE_DIR="$PROJECT_DIR/__validation__"
FIXTURE_SRC="/tests/validate/TursoRemoteValidation.cs"

echo "=== Staging the remote behavior fixture ==="
if [ ! -f "$FIXTURE_SRC" ]; then
    echo "FATAL: fixture not found at $FIXTURE_SRC" >&2
    return 1 2>/dev/null || exit 1
fi
if [ ! -d "$PROJECT_DIR" ]; then
    echo "FATAL: test project not found at $PROJECT_DIR" >&2
    return 1 2>/dev/null || exit 1
fi

mkdir -p "$STAGE_DIR"
cp "$FIXTURE_SRC" "$STAGE_DIR/TursoRemoteValidation.cs"
echo "  staged -> $STAGE_DIR/TursoRemoteValidation.cs"

# The SDK-default source globbing compiles every .cs under the project
# directory, so the staged fixture joins the test assembly automatically.

echo "=== Warming the offline test build ==="
BUILD_LOG="$(mktemp)"
if ( cd "$REPO_DIR/bindings/dotnet" \
     && dotnet build src/Turso.Tests/Turso.Tests.csproj -f net9.0 --no-restore ) \
     > "$BUILD_LOG" 2>&1; then
    echo "  build OK"
else
    echo "WARNING: warm build did not succeed; dumping the tail so the cause is visible." >&2
    tail -80 "$BUILD_LOG" >&2
    # Do not abort: a behavioral failure of the submission should surface
    # through the story runs, not as an aborted setup.
fi
rm -f "$BUILD_LOG"

echo "=== Validation setup complete ==="
