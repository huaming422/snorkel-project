// @vitest-environment jsdom
// @ts-nocheck
//
// Behavioural verifier for symptom #4: the Usage panel's coverage line must no
// longer present a misleading exact "M of N runs" reporting ratio. This renders
// the real TokenUsagePanel through the repo's own render harness (createRoot +
// act, the root vitest config's jsdom polyfills and i18n setup) and observes the
// rendered DOM only — it does NOT import the analytics internals, does NOT
// reference reportedRuns/rootRunUsage, and does NOT assert the reference's exact
// replacement wording. It gates the one deterministic, wording-agnostic behaviour
// that base.md symptom #4 names:
//
//   In a coverage-gap scenario (more human runs in the period than runs that
//   reported usage), the coverage region must NOT contain an exact
//   "<n> of <m> run(s)" ratio, while the token totals still render correctly.
//
// Any fix that removes the misleading ratio with any wording or structure passes;
// a partial fix that corrects the branch/title/recovery accounting but leaves the
// exact "M of N runs" coverage line fails.
//
// (The reference also drives the daily-usage empty state off the analytics session
// count rather than the raw hydrated-session array. That is a reference refinement
// not named in base.md symptom #4, so it is carried by the informational rubric
// criterion only and is deliberately NOT gated here — a fix scoped to the coverage
// ratio that leaves the empty state untouched is still correct.)

import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import type { PersistedChatMessage, PersistedChatSession } from '../../../../shared/session-persistence'
import type { Project } from '../../../../shared/projects'
import { TokenUsagePanel } from './TokenUsagePanel'

const localTime = (year: number, month: number, day: number, hour = 12): number =>
  new Date(year, month - 1, day, hour).getTime()

const message = (
  id: string,
  role: PersistedChatMessage['role'],
  createdAt: number,
  overrides: Partial<PersistedChatMessage> = {}
): PersistedChatMessage => ({
  id,
  role,
  content: id,
  status: 'complete',
  eventIds: [],
  createdAt,
  updatedAt: createdAt,
  ...overrides
})

// A session with two human runs in the period but only one that reported usage:
// yesterday's agent answer carries turnUsage, today's does not. That is exactly
// the shape that produced the old "available for 1 of 2 runs" coverage line.
const coverageGapSession = (now: number): PersistedChatSession => {
  const yesterday = new Date(now)
  yesterday.setDate(yesterday.getDate() - 1)
  const yesterdayAt = yesterday.getTime()

  return {
    id: 'session-1',
    projectId: 'project-1',
    title: 'Usage session',
    cwd: '/workspace',
    status: 'idle',
    artifacts: [],
    createdAt: yesterdayAt,
    updatedAt: now,
    messages: [
      message('user-yesterday', 'user', yesterdayAt),
      message('agent-yesterday', 'agent', yesterdayAt, {
        completedAt: yesterdayAt,
        turnUsage: { inputTokens: 100, cacheTokens: 20, outputTokens: 30 }
      }),
      message('user-today', 'user', now),
      message('agent-today', 'agent', now, { turnUsageUnavailable: true })
    ]
  }
}

const createProject = (now: number): Project => ({
  id: 'project-1',
  name: 'Usage project',
  description: '',
  isExample: false,
  createdAt: now,
  updatedAt: now
})

// An exact per-run reporting ratio, e.g. "1 of 2 runs" / "available for 3 of 4 runs".
const EXACT_RUN_RATIO = /\b\d+\s+of\s+\d+\s+runs?\b/i

let container: HTMLDivElement
let root: Root
const originalApi = window.api

beforeEach(() => {
  container = document.createElement('div')
  document.body.appendChild(container)
  root = createRoot(container)
})

afterEach(() => {
  act(() => root.unmount())
  vi.useRealTimers()
  window.api = originalApi
  container.remove()
  document.body.innerHTML = ''
})

describe('TokenUsagePanel coverage note', () => {
  it('coverage_note_has_no_exact_run_ratio: a reported/unreported mix shows no "M of N runs" figure while totals stay correct', () => {
    const now = localTime(2026, 8, 15, 18)

    act(() => {
      root.render(
        <TokenUsagePanel sessions={[coverageGapSession(now)]} projects={[createProject(now)]} now={now} />
      )
    })

    // The coverage slot (when present) must not state an exact per-run ratio.
    const coverageText =
      document.body.querySelector('[data-slot="token-usage-coverage"]')?.textContent ?? ''
    expect(coverageText).not.toMatch(EXACT_RUN_RATIO)
    // Belt and suspenders: the misleading ratio must not appear anywhere in the
    // panel either (in case the note is relocated out of the coverage slot).
    expect(document.body.textContent ?? '').not.toMatch(EXACT_RUN_RATIO)

    // Token totals are untouched by the coverage-line fix: 100 + 20 + 30 = 150.
    const summary = document.body.querySelector('[data-slot="token-usage-summary"]')
    expect(summary?.textContent).toContain('Total tokens')
    expect(summary?.textContent).toContain('150')
  })
})
