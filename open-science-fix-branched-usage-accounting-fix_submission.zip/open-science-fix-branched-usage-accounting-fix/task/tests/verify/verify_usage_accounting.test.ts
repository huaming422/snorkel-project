// @ts-nocheck
//
// Behavioural verifier for the usage-accounting correction. Every case drives
// the pre-existing public surface only: the renderer session store actions
// build conversations, the shared Session codec round-trips them exactly as the
// app saves, and a real on-disk SQLite project is read back through
// SessionProjectionRepository.usage() and the renderer analytics selectors.
//
// Deliberately black-box over the fix shape. We do NOT import the shared usage
// classifier, do NOT require any per-message back-pointer field, and do NOT
// require a public flush() method or any particular storage verb. Recovery is
// observed through record() + usage() totals; branch exclusion is observed
// through run/token counts and the continued visibility of inherited history's
// turnUsage; title retention through the auxiliary row count and totals. Any
// solution that produces the right observable outputs passes, regardless of
// whether it persists a marker, walks ancestry, upserts, or reconciles on read.

import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import type { PrismaClient } from '@prisma/client'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

vi.mock('electron', () => ({ app: { getPath: () => '/home/user', isPackaged: true } }))

import {
  createSessionFile,
  persistedChatSessionCodec,
  type PersistedChatSession
} from '../../shared/session-persistence'
import {
  createInitialSessionState,
  toPersistedSession,
  useSessionStore
} from '../../renderer/src/stores/session-store'
import {
  buildTokenUsageAnalytics,
  buildTokenUsageAnalyticsFromProjection,
  selectTokenUsageSummary,
  type TokenUsageSummary
} from '../../renderer/src/pages/settings/token-usage-analytics'
import { createProjectDbClient, migrateApplicationDatabase } from '../projects/prisma-client'
import { SessionProjectionRepository } from './projection'
import {
  SessionAuxiliaryTurnUsageRecorder,
  type SessionAuxiliaryTurnUsageRecord
} from './auxiliary-turn-usage'

const usage = { inputTokens: 10, cacheTokens: 2, outputTokens: 3, turnCount: 1 }
const today = new Date(2026, 8, 6, 12).getTime()
let now = today
let client: PrismaClient
let storageRoot: string
let repository: SessionProjectionRepository

beforeEach(async () => {
  now = today
  vi.spyOn(Date, 'now').mockImplementation(() => now)
  useSessionStore.setState(createInitialSessionState())
  storageRoot = await mkdtemp(join(tmpdir(), 'open-science-usage-accounting-'))
  client = createProjectDbClient(storageRoot)
  await migrateApplicationDatabase(client)
  await client.project.create({ data: { id: 'project-1', name: 'Project' } })
  repository = new SessionProjectionRepository(async () => client)
})

afterEach(async () => {
  vi.restoreAllMocks()
  await client?.$disconnect()
  if (storageRoot) await rm(storageRoot, { recursive: true, force: true })
})

// A single human run: user prompt → agent answer → finishRun. `reported`
// controls whether turnUsage/model-call usage is attached; `application` marks
// the prompt as an automatic/application-attributed turn (a correction) rather
// than a human turn.
const run = (
  sessionId: string,
  reported = true,
  application = false
): { prompt: { messageId: string }; answer: { messageId: string } } => {
  const prompt = useSessionStore.getState().appendUserMessage({
    sessionId,
    projectId: 'project-1',
    cwd: '/workspace',
    agentFrameworkId: 'opencode',
    content: application ? 'Reviewer correction' : 'Human prompt',
    ...(application
      ? {
          attribution: {
            kind: 'application' as const,
            feature: 'reviewer' as const,
            purpose: 'correction' as const,
            causeReviewId: 'review-1'
          }
        }
      : {})
  })!
  now += 1
  const answer = useSessionStore.getState().appendAgentMessageChunk({
    sessionId,
    streamId: `${prompt.messageId}-stream`,
    eventId: `${prompt.messageId}-event`,
    content: 'Answer'
  })!
  now += 1
  useSessionStore
    .getState()
    .finishRun(
      sessionId,
      reported ? usage : undefined,
      undefined,
      undefined,
      reported ? [{ id: `${prompt.messageId}-call`, index: 0, ...usage }] : undefined
    )
  return { prompt, answer }
}

// Persist through the exact path the app uses: Session store → codec → the
// JSON round-trip the renderer performs on save → repository prepare/commit.
const save = async (id: string): Promise<PersistedChatSession> => {
  const state = useSessionStore.getState()
  const input = persistedChatSessionCodec.parse(
    JSON.parse(
      JSON.stringify(
        createSessionFile(
          toPersistedSession(
            state.sessions.find((session) => session.id === id)!,
            state.streamingMessages
          )
        )
      )
    )
  )
  const prepared = await repository.prepareSave(input)
  await repository.commitSave(prepared)
  return prepared
}

const summary = async (period: 'all' | 'today' = 'all'): Promise<TokenUsageSummary> =>
  selectTokenUsageSummary(buildTokenUsageAnalyticsFromProjection(await repository.usage(), now), period)

const auxRecord = (sessionId: string, eventId: string): SessionAuxiliaryTurnUsageRecord => ({
  projectId: 'project-1',
  sessionId,
  eventId,
  source: 'side-chat',
  frameworkId: 'opencode',
  model: 'model',
  completedAtMs: 100,
  usage: { inputTokens: 10, cacheTokens: 2, outputTokens: 3 }
})

const saveEmptySession = async (id: string): Promise<void> => {
  const session = await repository.prepareSave({
    id,
    projectId: 'project-1',
    title: 'Session',
    cwd: '/workspace',
    status: 'idle',
    createdAt: 1,
    updatedAt: 1,
    messages: []
  })
  await repository.commitSave(session)
}

describe('usage accounting through store, Session codec, and SQLite', () => {
  it('branch_excludes_inherited: a branch keeps inherited history visible but does not re-count it', async () => {
    const { answer } = run('source')
    const source = await save('source')
    const originalDays = buildTokenUsageAnalyticsFromProjection(await repository.usage(), now).last30Days
    expect(await summary()).toMatchObject({ totalSessions: 1, totalRuns: 1, totalTokens: 15 })

    now += 86_400_000
    const branch = useSessionStore
      .getState()
      .branchInNewSession({ sourceSessionId: 'source', sourceMessageId: answer.messageId })!
    useSessionStore
      .getState()
      .bindPendingSession({ pendingSessionId: branch.sessionId, sessionId: 'branch' })
    const saved = await save('branch')

    // Inherited answer stays visible as history (its turnUsage survives) ...
    expect(saved.messages.find((message) => message.id === answer.messageId)?.turnUsage).toEqual(usage)
    // ... but contributes no new run or token to the totals.
    expect(await summary()).toMatchObject({ totalSessions: 2, totalRuns: 1, totalTokens: 15 })
    const branchDays = buildTokenUsageAnalyticsFromProjection(await repository.usage(), now).last30Days
    expect(branchDays.find((day) => day.dayStart === originalDays.at(-1)!.dayStart)?.totalTokens).toBe(15)
  })

  it('legacy_branch_excludes_inherited: inherited history recognised by branch ancestry without any per-message marker', async () => {
    const { answer } = run('source')
    const source = await save('source')
    now += 86_400_000
    const branch = useSessionStore
      .getState()
      .branchInNewSession({ sourceSessionId: 'source', sourceMessageId: answer.messageId })!
    useSessionStore
      .getState()
      .bindPendingSession({ pendingSessionId: branch.sessionId, sessionId: 'branch' })
    const saved = await save('branch')

    // Strip every optional per-message origin marker, leaving only branchSource,
    // so exclusion must come from branch ancestry alone (legacy-branch shape).
    const legacy = structuredClone(saved)
    for (const message of [...legacy.messages, ...(legacy.conversationGraph?.messages ?? [])])
      delete message.usageOrigin
    await repository.replaceAll([source, legacy])

    expect(await summary()).toMatchObject({ totalSessions: 2, totalRuns: 1, totalTokens: 15 })
  })

  it('nested_and_independent_identity: nested branches and independent sessions reusing IDs stay independent', async () => {
    const { answer } = run('source')
    const source = await save('source')
    now += 86_400_000
    const branch = useSessionStore
      .getState()
      .branchInNewSession({ sourceSessionId: 'source', sourceMessageId: answer.messageId })!
    useSessionStore
      .getState()
      .bindPendingSession({ pendingSessionId: branch.sessionId, sessionId: 'branch' })
    await save('branch')
    expect(await summary()).toMatchObject({ totalSessions: 2, totalRuns: 1, totalTokens: 15 })

    // A real new run on the branch is counted.
    const next = run('branch')
    await save('branch')
    expect(await summary()).toMatchObject({ totalSessions: 2, totalRuns: 2, totalTokens: 30 })

    // Nesting another branch adds a session but no run (inherited prefix only).
    const nested = useSessionStore
      .getState()
      .branchInNewSession({ sourceSessionId: 'branch', sourceMessageId: next.answer.messageId })!
    useSessionStore
      .getState()
      .bindPendingSession({ pendingSessionId: nested.sessionId, sessionId: 'nested' })
    await save('nested')
    expect(await summary()).toMatchObject({ totalSessions: 3, totalRuns: 2, totalTokens: 30 })

    // An independent session that reuses the source's message/call IDs must keep
    // its own execution identity: equal IDs do NOT collapse into shared accounting.
    const independent = await repository.prepareSave({ ...source, id: 'independent', number: undefined })
    await repository.commitSave(independent)
    expect(await summary()).toMatchObject({ totalSessions: 4, totalRuns: 3, totalTokens: 45 })
  })

  it('application_calls_counted_not_as_runs: automatic calls add tokens but not human runs', async () => {
    run('coverage')
    run('coverage', false)
    run('coverage', true, true)
    await save('coverage')
    expect(await summary()).toMatchObject({ newRuns: 2, totalTokens: 30 })
  })

  it('run_date_grouping: runs count on start date, tokens on completion date (cross-midnight)', async () => {
    now = new Date(2026, 8, 5, 23, 59).getTime()
    const prompt = useSessionStore
      .getState()
      .appendUserMessage({ sessionId: 'midnight', projectId: 'project-1', content: 'Late prompt' })!
    now = new Date(2026, 8, 6, 0, 1).getTime()
    useSessionStore
      .getState()
      .appendAgentMessageChunk({
        sessionId: 'midnight',
        streamId: 'late-answer',
        eventId: 'late-event',
        content: 'Answer'
      })
    useSessionStore.getState().finishRun('midnight', usage)
    expect(useSessionStore.getState().sessions[0].messages[1].responseToMessageId).toBe(prompt.messageId)

    now = today
    run('midnight', false)
    await save('midnight')

    // Today's token total includes the run whose completion crossed midnight;
    // today's run count does not (that run started the prior day).
    expect(await summary('today')).toMatchObject({ newRuns: 1, totalTokens: 15 })
    expect(await summary()).toMatchObject({ newRuns: 2 })
  })

  it('title_usage_retained_across_edit_and_rebuild: completed title usage is durable and idempotent', async () => {
    const { prompt } = run('details')
    const details = {
      sourceMessageId: prompt.messageId,
      requestId: 'details-request',
      status: 'succeeded' as const,
      queuedAt: now,
      startedAt: now,
      completedAt: now,
      frameworkId: 'opencode' as const,
      model: 'title-model',
      reasoningEffort: 'default' as const,
      usage: { inputTokens: 4, cacheTokens: 1, outputTokens: 2 }
    }
    useSessionStore.setState((state) => ({
      sessions: state.sessions.map((session) => ({ ...session, sessionDetailsGeneration: details }))
    }))
    await save('details')
    expect(await summary()).toMatchObject({ totalTokens: 22 })

    // Editing (truncating) the first prompt must not erase already-incurred title usage.
    now += 1
    useSessionStore.getState().truncateSessionFromMessage('details', prompt.messageId)
    const editedPrompt = useSessionStore
      .getState()
      .appendUserMessage({ sessionId: 'details', content: 'Edited prompt' })!
    const edited = await save('details')
    // Observe the behaviour, not the saved-JSON shape: already-incurred title
    // usage must survive the first-prompt edit. A design that keeps the usage
    // durable at the persistence layer is correct whether or not it also retains
    // the in-JSON generation claim, so we assert the durable total rather than
    // pinning sessionDetailsGeneration to undefined. The row-count gates below
    // (:316, :334) independently reject JSON-retention-only designs.
    expect(await summary()).toMatchObject({ totalTokens: 22 })

    // Repeated rebuilds stay idempotent: the auxiliary row is upserted, not re-created.
    await repository.replaceAll([edited])
    await repository.replaceAll([edited])
    expect(await client.sessionAuxiliaryTurnUsage.count()).toBe(1)
    expect(await summary()).toMatchObject({ totalTokens: 22 })

    // A second completed title generation adds exactly one more durable row.
    useSessionStore.setState((state) => ({
      sessions: state.sessions.map((session) => ({
        ...session,
        sessionDetailsGeneration: {
          ...details,
          sourceMessageId: editedPrompt.messageId,
          requestId: 'details-request-2'
        }
      }))
    }))
    const regenerated = await save('details')
    await save('details')
    await repository.clearForRebuild()
    await repository.replaceAll([regenerated])
    expect(await client.sessionAuxiliaryTurnUsage.count()).toBe(2)
    expect(await summary()).toMatchObject({ totalTokens: 29 })

    // Deleting the whole session is the only thing that removes the title usage.
    await repository.commitDelete('project-1', 'details')
    expect(await client.sessionAuxiliaryTurnUsage.count()).toBe(0)
  })

  it('auxiliary_retry_recovers_after_readonly: a failed write is recovered exactly once after the DB is writable', async () => {
    await saveEmptySession('session')
    const recorder = new SessionAuxiliaryTurnUsageRecorder(async () => client)

    // This connection owns the write; SQLite itself rejects it (no mocking),
    // exactly as a transient read-only window would. Reads still work.
    await client.$executeRawUnsafe('PRAGMA query_only = ON')
    await expect(recorder.record(auxRecord('session', 'first'))).rejects.toThrow(/readonly/i)
    expect(await client.sessionAuxiliaryTurnUsage.count()).toBe(0)

    await client.$executeRawUnsafe('PRAGMA query_only = OFF')
    // The failed write left nothing persisted yet (recovery happens on the next
    // record / read below), so the projection still reports no usage events.
    expect((await repository.usage()).usageEvents).toHaveLength(0)
    // Recording a second measurement plus a usage read is enough to recover the
    // first: observed via record() + usage() totals, so solutions that reconcile
    // on the write path (next record) OR on the read path (usage) both pass.
    await recorder.record(auxRecord('session', 'second'))
    const total = (await repository.usage()).usageEvents.reduce(
      (sum, event) => sum + event.inputTokens + event.cacheTokens + event.outputTokens,
      0
    )
    const rows = await client.sessionAuxiliaryTurnUsage.findMany({ orderBy: { eventId: 'asc' } })
    expect(rows.map((row) => row.eventId)).toEqual(['first', 'second'])
    // Recovered exactly once: two measurements in, two rows out, total 30.
    expect(total).toBe(30)
  })

  it('auxiliary_retry_discards_deleted_and_malformed: deleted-session and malformed measurements are not retried forever', async () => {
    await saveEmptySession('session')
    const recorder = new SessionAuxiliaryTurnUsageRecorder(async () => client)

    await saveEmptySession('session-2')

    // A pending measurement whose session is soft-deleted is discarded, not retried
    // forever and never resurrecting the deleted session with a late write.
    await client.$executeRawUnsafe('PRAGMA query_only = ON')
    await expect(recorder.record(auxRecord('session', 'first'))).rejects.toThrow(/readonly/i)
    await client.$executeRawUnsafe('PRAGMA query_only = OFF')
    await client.session.update({ where: { id: 'session' }, data: { deletedAtMs: 200n } })

    // A later valid record for a live session must still succeed; recording it also
    // drives recovery of the earlier pending measurement, which must be discarded
    // (its session is gone) rather than resurrecting that session with a late write.
    await recorder.record(auxRecord('session-2', 'later'))
    const remaining = await client.sessionAuxiliaryTurnUsage.findMany()
    expect(remaining.map((row) => row.sessionId)).toEqual(['session-2'])

    // A malformed measurement is rejected and must not block a subsequent valid record.
    const malformed = auxRecord('session-2', 'invalid')
    malformed.usage.inputTokens = -1
    await expect(recorder.record(malformed)).rejects.toThrow(/inputTokens/)
    await expect(recorder.record(auxRecord('session-2', 'valid'))).resolves.toBe(true)
    expect(await client.sessionAuxiliaryTurnUsage.count()).toBe(2)
  })

  it('renderer_analytics_matches_projection: both accounting surfaces agree on a branched scenario', async () => {
    const { answer } = run('source')
    await save('source')
    now += 86_400_000
    const branch = useSessionStore
      .getState()
      .branchInNewSession({ sourceSessionId: 'source', sourceMessageId: answer.messageId })!
    useSessionStore
      .getState()
      .bindPendingSession({ pendingSessionId: branch.sessionId, sessionId: 'branch' })
    await save('branch')

    // Renderer analytics over the raw persisted sessions ...
    const state = useSessionStore.getState()
    const rawSessions = state.sessions.map((session) =>
      persistedChatSessionCodec.parse(
        JSON.parse(
          JSON.stringify(createSessionFile(toPersistedSession(session, state.streamingMessages)))
        )
      )
    )
    const fromRaw = selectTokenUsageSummary(buildTokenUsageAnalytics(rawSessions, now), 'all')
    // ... and the main-process SQLite projection must agree.
    const fromProjection = selectTokenUsageSummary(
      buildTokenUsageAnalyticsFromProjection(await repository.usage(), now),
      'all'
    )
    expect(fromRaw.totalSessions).toBe(fromProjection.totalSessions)
    expect(fromRaw.totalRuns).toBe(fromProjection.totalRuns)
    expect(fromRaw.totalTokens).toBe(fromProjection.totalTokens)
    expect(fromProjection).toMatchObject({ totalSessions: 2, totalRuns: 1, totalTokens: 15 })
  })
})
