## Task

a few operator reports about the usage panel's totals. several look off, and all read like bookkeeping gone wrong rather than real model work.

branching a conversation makes the panel count the inherited history twice: the runs and tokens already belonging to the original get added again to the branch, so every fork inflates the totals. the inherited messages should still show in the branch as history, just not re-counted.

editing the first prompt of a conversation wipes the title-generation usage it had already incurred, so consumption that really happened drops out.

if the local database goes briefly read-only (a transient lock), a usage measurement saving right then fails and is lost for good, never recovered once writes are possible again.

the coverage line claims an exact "available for M of N runs" figure inferred from run and response counts that don't line up, so it reads as a confident number that's plain wrong after an automatic correction or across midnight.

an accounting fix, not a schema change: no new tables, columns, or migrations. dig in and sort it out.
