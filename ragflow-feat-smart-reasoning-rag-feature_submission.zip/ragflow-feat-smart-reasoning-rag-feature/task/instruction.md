## Task

We want to add a new "smart-reasoning" conversation mode to the knowledge-base
assistant: rather than a fixed retrieve-then-answer flow, an agent that reasons
over a knowledge base on its own and decides which retrieval and reasoning tools
to call before it answers. Drive it with the agent loop the project already has,
the cloudwego/eino ADK's chat-model reason-act agent, instead of hand-rolling a
new one.

The work is backend only: a new, self-contained package that assembles the
agent's tool suite and authors its system prompt. Leave the web frontend and the
existing chat request-handling pipeline as they are. Make the system prompt
evidence-first, steering the model to ground its answer in what it actually
retrieves before replying, and keep every retrieval inside the caller's tenant
and the datasets bound to the conversation, so one tenant's assistant never
reaches another tenant's content.

The environment is offline; everything you need is already installed, including
a JavaScript engine for the code-execution tool.

## User stories / requirements

- The smart-reasoning agent exposes exactly six tools — think, todo_write, grep_chunks, search_chunks, list_chunks, run_javascript — each usable by the chat model, and its system prompt advertises them. The prompt names each of the six tools.
- The run_javascript tool executes a self-contained ES5.1 JavaScript snippet and returns its standard output (for example, summing an array and printing the total). It rejects module-system or ES6+ syntax (such as import, require, module.exports, arrow functions, classes, or template literals) with a clear error.
- The grep_chunks tool finds chunks whose text matches a case-insensitive regular expression, ranked so stronger matches come first, and rejects an invalid or empty pattern with an error.
- The list_chunks tool reads one document's full text in reading order with pagination, addressing the document by its document id alone; a request missing the document id is an error.
- The search_chunks tool accepts between one and five semantic queries and returns chunk content; it rejects a request with zero queries and a request with more than five queries.
