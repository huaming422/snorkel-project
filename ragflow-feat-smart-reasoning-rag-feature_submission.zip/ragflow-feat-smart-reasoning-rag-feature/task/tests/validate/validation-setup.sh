#!/usr/bin/env bash
# Validation-phase setup for the smart-reasoning agentic-RAG task.
#
# Runs AFTER the agent's solution has been applied to /repo/ragflow and BEFORE
# the validation agent's generated _test.go files are compiled and run by the
# go-test driver. The image (image/Dockerfile) already baked the full module
# closure — the base tree's deps plus the genuinely-new modules the feature
# introduces (the embedded JavaScript engine goja and its transitives, the
# promoted JSON-schema package). So this runs with the network cut and must
# resolve everything from the warm module cache; `go mod download` only
# reconciles the agent's go.mod/go.sum edits against that cache.

set -euo pipefail

cd /repo/ragflow

# Offline switches (mirror tests/test-setup.sh): a cache miss fails fast instead
# of hanging on a dead network. GOFLAGS=-mod=mod lets `go mod download` accept
# the agent's new direct dependency; GOPROXY=off forbids any network fetch;
# GOTOOLCHAIN=local forbids a toolchain download; pure Go, no cgo.
export GOFLAGS=-mod=mod
export GOPROXY=off
export GOTOOLCHAIN=local
export CGO_ENABLED=0
export GOCACHE="${GOCACHE:-/root/.cache/go-build}"
export GOMODCACHE="${GOMODCACHE:-/root/go/pkg/mod}"
mkdir -p "$GOCACHE" "$GOMODCACHE"

# Resolve modules offline-first against the image bake, with a logged online
# fallback only if the bake was stale (e.g. the agent added a dependency that
# is in the lockfile transitively but not yet materialized).
if GOPROXY=off go mod download > /tmp/validation-setup-godl.log 2>&1; then
    echo "[offline-first] go modules satisfied from image cache"
elif GOFLAGS=-mod=mod GOPROXY='https://proxy.golang.org,direct' go mod download >> /tmp/validation-setup-godl.log 2>&1; then
    echo "[validation-setup] go modules downloaded online (image bake was stale)"
else
    tail -40 /tmp/validation-setup-godl.log >&2
    exit 1
fi

# Loud smoke guard: the validation stories inject an external `package
# runtime_test` file into internal/agent/runtime and import the agent's new
# agentic-RAG package. Confirm the post-solution tree compiles (vet the runtime
# package and build-check the whole module) so a broken solution fails here with
# a clear message rather than as an opaque per-case build_error later.
if ! go build ./... > /tmp/validation-setup-build.log 2>&1; then
    echo "[validation-setup] post-solution tree failed to build:" >&2
    tail -60 /tmp/validation-setup-build.log >&2
    exit 1
fi

echo "[validation-setup] ragflow builds offline; validation environment ready"
