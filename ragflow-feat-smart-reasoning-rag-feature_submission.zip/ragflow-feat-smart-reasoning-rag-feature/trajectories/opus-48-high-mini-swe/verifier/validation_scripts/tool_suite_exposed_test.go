package runtime_test

import (
	"context"
	"strings"
	"testing"

	"ragflow/internal/agent/smartreason"
)

func TestToolSuiteExposedValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			// Read inputs
			requiredRaw := tc.Inputs["required"].([]interface{})
			required := make([]string, len(requiredRaw))
			for i, v := range requiredRaw {
				required[i] = v.(string)
			}

			legacyRaw := tc.Inputs["legacy"].([]interface{})
			legacy := make([]string, len(legacyRaw))
			for i, v := range legacyRaw {
				legacy[i] = v.(string)
			}

			ctx := context.Background()

			// Get tool set with empty tenant and nil datasets
			tools := smartreason.Tools(nil, smartreason.Scope{})

			// tool_count
			toolCount := len(tools)

			// missing_tool_count: check which required names are not present
			toolNames := map[string]bool{}
			for _, tl := range tools {
				info, err := tl.Info(ctx)
				if err == nil && info != nil {
					toolNames[info.Name] = true
				}
			}
			missingToolCount := 0
			for _, req := range required {
				if !toolNames[req] {
					missingToolCount++
				}
			}

			// Get system prompt
			prompt := smartreason.SystemPrompt

			// legacy_in_prompt_count: how many of the legacy names appear in prompt
			legacyInPromptCount := 0
			for _, leg := range legacy {
				if strings.Contains(prompt, leg) {
					legacyInPromptCount++
				}
			}

			// placeholder_in_prompt_count: count occurrences of {{ and }}
			placeholderInPromptCount := 0
			if strings.Contains(prompt, "{{") {
				placeholderInPromptCount++
			}
			if strings.Contains(prompt, "}}") {
				placeholderInPromptCount++
			}

			// nil_model_errors: call NewAgent with nil model, check if it errors or panics
			nilModelErrors := "no"
			func() {
				defer func() {
					if r := recover(); r != nil {
						nilModelErrors = "yes"
					}
				}()
				_, err := smartreason.NewAgent(ctx, smartreason.Config{
					Model: nil,
					Store: nil,
					Scope: smartreason.Scope{TenantID: ""},
				})
				if err != nil {
					nilModelErrors = "yes"
				}
			}()

			// Assertions — all expected keys used unconditionally
			expectedToolCount := int(tc.Expected["tool_count"].(float64))
			expectedMissingToolCount := int(tc.Expected["missing_tool_count"].(float64))
			expectedLegacyInPromptCount := int(tc.Expected["legacy_in_prompt_count"].(float64))
			expectedPlaceholderInPromptCount := int(tc.Expected["placeholder_in_prompt_count"].(float64))
			expectedNilModelErrors := tc.Expected["nil_model_errors"].(string)

			if toolCount != expectedToolCount {
				t.Errorf("tool_count: got %d, want %d", toolCount, expectedToolCount)
			}
			if missingToolCount != expectedMissingToolCount {
				t.Errorf("missing_tool_count: got %d, want %d", missingToolCount, expectedMissingToolCount)
			}
			if legacyInPromptCount != expectedLegacyInPromptCount {
				t.Errorf("legacy_in_prompt_count: got %d, want %d", legacyInPromptCount, expectedLegacyInPromptCount)
			}
			if placeholderInPromptCount != expectedPlaceholderInPromptCount {
				t.Errorf("placeholder_in_prompt_count: got %d, want %d", placeholderInPromptCount, expectedPlaceholderInPromptCount)
			}
			if nilModelErrors != expectedNilModelErrors {
				t.Errorf("nil_model_errors: got %q, want %q", nilModelErrors, expectedNilModelErrors)
			}
		})
	}
}
