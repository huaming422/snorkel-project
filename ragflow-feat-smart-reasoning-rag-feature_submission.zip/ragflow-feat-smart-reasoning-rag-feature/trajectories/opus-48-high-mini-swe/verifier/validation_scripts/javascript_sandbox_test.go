package runtime_test

import (
	"context"
	"encoding/json"
	"strings"
	"testing"
	"time"

	"ragflow/internal/agent/smartreason"

	einotool "github.com/cloudwego/eino/components/tool"
)

func TestJavascriptSandboxValidation(t *testing.T) {
	cases := GetValidationTestCases(t)

	// Get the tool set and find run_javascript
	ctx0 := context.Background()
	tools := smartreason.Tools(nil, smartreason.Scope{})
	var jsTool einotool.InvokableTool
	for _, tl := range tools {
		info, err := tl.Info(ctx0)
		if err == nil && info != nil && info.Name == "run_javascript" {
			if it, ok := tl.(einotool.InvokableTool); ok {
				jsTool = it
			}
		}
	}
	if jsTool == nil {
		t.Fatal("run_javascript tool not found in tool suite")
	}

	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			codeInput := tc.Inputs["code"].(string)
			ctxTimeoutMs := int(tc.Inputs["ctx_timeout_ms"].(float64))

			errored := tc.Expected["errored"].(string)
			stdoutMarker := tc.Expected["stdout_marker"].(string)

			// Build the code string
			var code string
			if codeInput == "__OVERSIZED__" {
				code = strings.Repeat("var x=1;", 5000000) // ~40 MB
			} else {
				code = codeInput
			}

			// Build args JSON with code key
			argsMap := map[string]string{"code": code}
			argsJSON, err := json.Marshal(argsMap)
			if err != nil {
				t.Fatalf("failed to marshal args: %v", err)
			}

			// Choose context based on ctx_timeout_ms
			var callCtx context.Context
			var cancel context.CancelFunc
			if ctxTimeoutMs > 0 {
				callCtx, cancel = context.WithTimeout(context.Background(), time.Duration(ctxTimeoutMs)*time.Millisecond)
				defer cancel()
			} else {
				callCtx = context.Background()
			}

			// Record elapsed time
			start := time.Now()
			out, callErr := jsTool.InvokableRun(callCtx, string(argsJSON))
			elapsed := time.Since(start)

			// Assertions
			if errored == "yes" {
				if callErr == nil {
					t.Errorf("expected error but got nil; output=%q", out)
				}
				// When ctx_timeout_ms is positive, assert the call returned promptly
				if ctxTimeoutMs > 0 {
					if elapsed >= 15*time.Second {
						t.Errorf("runaway snippet not interrupted in time: elapsed=%v", elapsed)
					}
				}
			} else if errored == "no" {
				if callErr != nil {
					t.Errorf("expected no error but got: %v", callErr)
				}
				if stdoutMarker != "__skip__" {
					if !strings.Contains(out, stdoutMarker) {
						t.Errorf("output %q does not contain marker %q", out, stdoutMarker)
					}
				}
			}
			// If stdoutMarker is "__skip__", skip the output assertion (already handled above)
		})
	}
}
