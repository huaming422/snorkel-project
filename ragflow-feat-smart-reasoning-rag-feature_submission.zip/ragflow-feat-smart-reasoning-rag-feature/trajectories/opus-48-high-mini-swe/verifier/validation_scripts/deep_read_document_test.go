package runtime_test

import (
	"context"
	"encoding/json"
	"strings"
	"testing"

	"ragflow/internal/agent/smartreason"
	"ragflow/internal/agent/tool"

	einotool "github.com/cloudwego/eino/components/tool"
	"gorm.io/gorm"
)

// fakeListDocRetrievalSvc is a fake tool.RetrievalService for list_chunks tests.
// It returns its pre-configured chunks when Search is called.
// The retrievalServiceStore.ListDocument filters by DocumentID and sorts by Position.
// Since Position is not mapped from tool.RetrievalChunk to smartreason.Chunk,
// all positions default to 0 and stable sort maintains insertion order.
type fakeListDocRetrievalSvc struct {
	chunks []tool.RetrievalChunk
}

func (f *fakeListDocRetrievalSvc) Search(_ context.Context, _ *gorm.DB, _ tool.RetrievalRequest) ([]tool.RetrievalChunk, error) {
	return f.chunks, nil
}

func TestDeepReadDocumentValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	ctx := context.Background()

	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			mode := tc.Inputs["mode"].(string)
			docID := tc.Inputs["doc_id"].(string)
			markerA := tc.Inputs["marker_a"].(string)
			markerB := tc.Inputs["marker_b"].(string)

			errored := tc.Expected["errored"].(string)
			firstMarker := tc.Expected["first_marker"].(string)
			secondMarker := tc.Expected["second_marker"].(string)

			scope := smartreason.Scope{TenantID: "tenant-test", DatasetIDs: []string{"ds-1"}}

			// Build the fake service with ALPHA and BETA chunks.
			// Chunks are in order [ALPHA, BETA]; since Position defaults to 0 for all
			// (not mapped from RetrievalChunk), stable sort maintains insertion order,
			// so ALPHA precedes BETA in reading order.
			fakeSvc := &fakeListDocRetrievalSvc{
				chunks: []tool.RetrievalChunk{
					{
						ID:         "chunk-alpha",
						Content:    "passage containing " + markerA + " here",
						DocumentID: docID,
					},
					{
						ID:         "chunk-beta",
						Content:    "passage containing " + markerB + " here",
						DocumentID: docID,
					},
				},
			}

			var store smartreason.ChunkStore
			if mode == "missing_doc" {
				// For missing_doc, the tool errors before calling store (empty document_id check).
				// Use an empty store to be safe.
				emptySvc := &fakeListDocRetrievalSvc{chunks: nil}
				store = smartreason.NewRetrievalServiceStore(emptySvc, nil)
			} else {
				store = smartreason.NewRetrievalServiceStore(fakeSvc, nil)
			}

			// Find the list_chunks tool
			var listTool einotool.InvokableTool
			allTools := smartreason.Tools(store, scope)
			for _, tl := range allTools {
				info, err := tl.Info(ctx)
				if err == nil && info != nil && info.Name == "list_chunks" {
					if it, ok := tl.(einotool.InvokableTool); ok {
						listTool = it
					}
				}
			}
			if listTool == nil {
				t.Fatal("list_chunks tool not found in tool suite")
			}

			// Build args based on mode
			var argsJSON []byte
			switch mode {
			case "order":
				// No page limit (use default)
				argsMap := map[string]interface{}{"document_id": docID}
				argsJSON, _ = json.Marshal(argsMap)
			case "page":
				// Page limit of 1
				argsMap := map[string]interface{}{"document_id": docID, "limit": 1}
				argsJSON, _ = json.Marshal(argsMap)
			case "missing_doc":
				// Empty document_id
				argsMap := map[string]interface{}{"document_id": ""}
				argsJSON, _ = json.Marshal(argsMap)
			}

			out, callErr := listTool.InvokableRun(ctx, string(argsJSON))

			// Assertions — all expected keys used unconditionally.
			// "__skip__" means skip that assertion.
			if errored == "yes" {
				if callErr == nil {
					t.Errorf("expected error but got nil; output=%q", out)
				}
				// firstMarker and secondMarker are "__skip__" for the error case — skip them
				_ = firstMarker
				_ = secondMarker
			} else if errored == "no" {
				if callErr != nil {
					t.Errorf("expected no error but got: %v", callErr)
				}
				switch mode {
				case "order":
					// Both markers must appear in the output, ALPHA before BETA (reading order)
					if firstMarker != "__skip__" && !strings.Contains(out, firstMarker) {
						t.Errorf("output does not contain first_marker %q; out=%q", firstMarker, out)
					}
					if secondMarker != "__skip__" && !strings.Contains(out, secondMarker) {
						t.Errorf("output does not contain second_marker %q; out=%q", secondMarker, out)
					}
					if firstMarker != "__skip__" && secondMarker != "__skip__" {
						idxFirst := strings.Index(out, firstMarker)
						idxSecond := strings.Index(out, secondMarker)
						if idxFirst >= idxSecond {
							t.Errorf("reading order violated: first_marker %q (idx=%d) >= second_marker %q (idx=%d); out=%q",
								firstMarker, idxFirst, secondMarker, idxSecond, out)
						}
					}
				case "page":
					// first_marker must appear; second_marker must NOT appear (pagination)
					if firstMarker != "__skip__" && !strings.Contains(out, firstMarker) {
						t.Errorf("output does not contain first_marker %q; out=%q", firstMarker, out)
					}
					if secondMarker != "__skip__" && strings.Contains(out, secondMarker) {
						t.Errorf("output must NOT contain second_marker %q (pagination); out=%q", secondMarker, out)
					}
				}
			}
		})
	}
}
