package runtime_test

import (
	"context"
	"encoding/json"
	"strings"
	"testing"

	"ragflow/internal/agent/smartreason"
	"ragflow/internal/agent/tool"

	einotool "github.com/cloudwego/eino/components/tool"
	"gorm.io/gorm"
)

// fakeSearchRetrievalSvc is a fake tool.RetrievalService for search_chunks tests.
// It returns pre-configured chunks regardless of the request.
type fakeSearchRetrievalSvc struct {
	returnChunks []tool.RetrievalChunk
}

func (f *fakeSearchRetrievalSvc) Search(_ context.Context, _ *gorm.DB, _ tool.RetrievalRequest) ([]tool.RetrievalChunk, error) {
	return f.returnChunks, nil
}

func TestSemanticSearchBoundedValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	ctx := context.Background()

	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			queriesRaw := tc.Inputs["queries"].([]interface{})
			queries := make([]string, len(queriesRaw))
			for i, v := range queriesRaw {
				queries[i] = v.(string)
			}

			markerRaw := tc.Inputs["marker"]
			var marker string
			if markerRaw != nil {
				marker, _ = markerRaw.(string)
			}

			errored := tc.Expected["errored"].(string)
			outMarker := tc.Expected["out_marker"].(string)

			// For the happy case, build a store that returns a chunk with the marker.
			// For error cases (zero or >5 queries), the tool validates before reaching the store.
			scope := smartreason.Scope{TenantID: "tenant-test", DatasetIDs: []string{"ds-1"}}

			var store smartreason.ChunkStore
			if marker != "" && marker != "__skip__" {
				// Happy case: wire a fake that returns the marker chunk
				fakeSvc := &fakeSearchRetrievalSvc{
					returnChunks: []tool.RetrievalChunk{
						{
							ID:      "chunk-search-1",
							Content: "prose containing " + marker + " here",
						},
					},
				}
				store = smartreason.NewRetrievalServiceStore(fakeSvc, nil)
			}
			// For error cases, store can be nil (tool validates query count first).

			// Find the search_chunks tool
			var searchTool einotool.InvokableTool
			allTools := smartreason.Tools(store, scope)
			for _, tl := range allTools {
				info, err := tl.Info(ctx)
				if err == nil && info != nil && info.Name == "search_chunks" {
					if it, ok := tl.(einotool.InvokableTool); ok {
						searchTool = it
					}
				}
			}
			if searchTool == nil {
				t.Fatal("search_chunks tool not found in tool suite")
			}

			// Build args JSON: {"queries": [...]}
			argsMap := map[string]interface{}{"queries": queries}
			argsJSON, err := json.Marshal(argsMap)
			if err != nil {
				t.Fatalf("failed to marshal args: %v", err)
			}

			out, callErr := searchTool.InvokableRun(ctx, string(argsJSON))

			// Assertions — all expected keys used unconditionally.
			// "__skip__" means skip that assertion.
			if errored == "yes" {
				if callErr == nil {
					t.Errorf("expected error but got nil; output=%q", out)
				}
				// outMarker is "__skip__" for error cases — skip it
				_ = outMarker
			} else if errored == "no" {
				if callErr != nil {
					t.Errorf("expected no error but got: %v", callErr)
				}
				if outMarker != "__skip__" {
					if !strings.Contains(out, outMarker) {
						t.Errorf("output %q does not contain out_marker %q", out, outMarker)
					}
				}
			}
		})
	}
}
