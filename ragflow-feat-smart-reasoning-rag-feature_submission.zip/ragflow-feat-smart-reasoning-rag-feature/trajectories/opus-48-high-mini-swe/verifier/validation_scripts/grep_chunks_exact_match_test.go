package runtime_test

import (
	"context"
	"encoding/json"
	"strings"
	"testing"

	"ragflow/internal/agent/smartreason"
	"ragflow/internal/agent/tool"

	einotool "github.com/cloudwego/eino/components/tool"
	"gorm.io/gorm"
)

// fakeGrepRetrievalSvc is a fake tool.RetrievalService that returns
// pre-configured chunks regardless of the request. The real Grep filtering
// (by regex match) is done inside retrievalServiceStore.Grep, which calls
// our Search here to get candidates and then filters them itself.
type fakeGrepRetrievalSvc struct {
	returnChunks []tool.RetrievalChunk
}

func (f *fakeGrepRetrievalSvc) Search(_ context.Context, _ *gorm.DB, _ tool.RetrievalRequest) ([]tool.RetrievalChunk, error) {
	return f.returnChunks, nil
}

func TestGrepChunksExactMatchValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	ctx := context.Background()

	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			query := tc.Inputs["query"].(string)
			markerRaw := tc.Inputs["marker"]
			var marker string
			if markerRaw != nil {
				marker, _ = markerRaw.(string)
			}

			errored := tc.Expected["errored"].(string)
			outMarkerRaw := tc.Expected["out_marker"]
			var outMarker string
			if outMarkerRaw != nil {
				outMarker, _ = outMarkerRaw.(string)
			}

			// Build tool set and find grep_chunks
			var grepTool einotool.InvokableTool
			var store smartreason.ChunkStore
			scope := smartreason.Scope{TenantID: "tenant-test", DatasetIDs: []string{"ds-1"}}

			if marker != "" && marker != "__skip__" {
				// Happy case: use a fake service that returns a chunk containing the marker.
				fakeSvc := &fakeGrepRetrievalSvc{
					returnChunks: []tool.RetrievalChunk{
						{
							ID:      "chunk-1",
							Content: "alpha " + marker + " omega",
						},
					},
				}
				store = smartreason.NewRetrievalServiceStore(fakeSvc, nil)
			}
			// For error cases (invalid/empty pattern), the tool errors before
			// calling store.Grep, so store can be nil.

			allTools := smartreason.Tools(store, scope)
			for _, tl := range allTools {
				info, err := tl.Info(ctx)
				if err == nil && info != nil && info.Name == "grep_chunks" {
					if it, ok := tl.(einotool.InvokableTool); ok {
						grepTool = it
					}
				}
			}
			if grepTool == nil {
				t.Fatal("grep_chunks tool not found in tool suite")
			}

			// Build args JSON: {"pattern": query}
			argsMap := map[string]string{"pattern": query}
			argsJSON, err := json.Marshal(argsMap)
			if err != nil {
				t.Fatalf("failed to marshal args: %v", err)
			}

			out, callErr := grepTool.InvokableRun(ctx, string(argsJSON))

			// Assertions — all expected keys used unconditionally
			if errored == "yes" {
				if callErr == nil {
					t.Errorf("expected error but got nil; output=%q", out)
				}
			} else if errored == "no" {
				if callErr != nil {
					t.Errorf("expected no error but got: %v", callErr)
				}
				if outMarker != "__skip__" {
					if !strings.Contains(out, outMarker) {
						t.Errorf("output %q does not contain out_marker %q", out, outMarker)
					}
				}
			}
		})
	}
}
