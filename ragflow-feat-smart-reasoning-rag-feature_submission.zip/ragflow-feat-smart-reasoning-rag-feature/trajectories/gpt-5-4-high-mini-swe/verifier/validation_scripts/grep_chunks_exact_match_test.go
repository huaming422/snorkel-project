package runtime_test

import (
	"context"
	"encoding/json"
	"strings"
	"testing"

	einotool "github.com/cloudwego/eino/components/tool"

	"ragflow/internal/chatmode/smartreasoning"
)

// fakeStoreGrep3 implements smartreasoning.Store for grep_chunks test.
// The scan field provides chunks returned by ScanChunks.
type fakeStoreGrep3 struct {
	scan []smartreasoning.Chunk
}

func (s *fakeStoreGrep3) SemanticSearch(_ context.Context, queries []string, _ int) (map[string][]smartreasoning.Chunk, error) {
	out := make(map[string][]smartreasoning.Chunk, len(queries))
	for _, q := range queries {
		out[q] = nil
	}
	return out, nil
}

func (s *fakeStoreGrep3) ScanChunks(_ context.Context, offset, limit int) ([]smartreasoning.Chunk, error) {
	if offset >= len(s.scan) {
		return nil, nil
	}
	end := offset + limit
	if end > len(s.scan) {
		end = len(s.scan)
	}
	return append([]smartreasoning.Chunk(nil), s.scan[offset:end]...), nil
}

func (s *fakeStoreGrep3) GetDocument(_ context.Context, documentID string) (*smartreasoning.Document, error) {
	return nil, nil
}

func (s *fakeStoreGrep3) ListDocumentChunks(_ context.Context, documentID string, offset, limit int) ([]smartreasoning.Chunk, int64, error) {
	return nil, 0, nil
}

// fakeJSGrep3 implements smartreasoning.JavaScriptExecutor for grep test.
type fakeJSGrep3 struct{}

func (e *fakeJSGrep3) Execute(_ context.Context, code string) (string, error) {
	return "", nil
}

// findGrepTool finds the grep_chunks tool by name.
func findGrepTool(t *testing.T, tools []einotool.BaseTool) einotool.InvokableTool {
	t.Helper()
	ctx := context.Background()
	for _, tool := range tools {
		info, err := tool.Info(ctx)
		if err != nil || info == nil {
			continue
		}
		if info.Name == "grep_chunks" {
			it, ok := tool.(einotool.InvokableTool)
			if !ok {
				t.Fatalf("grep_chunks does not implement InvokableTool")
			}
			return it
		}
	}
	t.Fatal("grep_chunks tool not found")
	return nil
}

func TestGrepChunksExactMatchValidation(t *testing.T) {
	cases := GetValidationTestCases(t)

	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			query := tc.Inputs["query"].(string)
			markerVal := tc.Inputs["marker"]
			errored := tc.Expected["errored"].(string)
			outMarker := tc.Expected["out_marker"].(string)

			// Determine whether this is a happy-path case that needs a wired fake store.
			// For error cases (empty/invalid pattern), any store works.
			var fakeChunk []smartreasoning.Chunk
			if markerVal != nil && markerVal.(string) != "__skip__" {
				marker := markerVal.(string)
				fakeChunk = []smartreasoning.Chunk{
					{
						ID:           "chunk-1",
						Content:      "alpha " + marker + " omega",
						DocumentID:   "doc-1",
						DocumentName: "Test Doc",
						DatasetID:    "kb-1",
					},
				}
			}

			store := &fakeStoreGrep3{scan: fakeChunk}

			suite, err := smartreasoning.NewSuite(smartreasoning.Options{
				TenantID:       "tenant-1",
				DatasetIDs:     []string{"kb-1"},
				Store:          store,
				JavaScriptExec: &fakeJSGrep3{},
			})
			if err != nil {
				t.Fatalf("NewSuite: %v", err)
			}

			grepTool := findGrepTool(t, suite.Tools())

			// Build args JSON with the pattern key
			argsBytes, jsonErr := json.Marshal(map[string]string{"pattern": query})
			if jsonErr != nil {
				t.Fatalf("marshal args: %v", jsonErr)
			}
			argsJSON := string(argsBytes)

			output, callErr := grepTool.InvokableRun(context.Background(), argsJSON)

			if errored == "yes" {
				if callErr == nil {
					t.Errorf("expected error for query=%q but got nil (output: %q)", query, output)
				}
			} else {
				// errored == "no"
				if callErr != nil {
					t.Errorf("expected no error but got: %v (output: %q)", callErr, output)
				}
				if outMarker != "__skip__" {
					if !strings.Contains(output, outMarker) {
						t.Errorf("output should contain marker %q, got: %q", outMarker, output)
					}
				}
			}
		})
	}
}
