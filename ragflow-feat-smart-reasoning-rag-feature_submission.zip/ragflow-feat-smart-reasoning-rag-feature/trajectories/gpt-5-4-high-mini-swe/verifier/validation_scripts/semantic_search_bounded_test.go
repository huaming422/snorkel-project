package runtime_test

import (
	"context"
	"encoding/json"
	"strings"
	"testing"

	einotool "github.com/cloudwego/eino/components/tool"

	"ragflow/internal/chatmode/smartreasoning"
)

// fakeStoreSearch5 implements smartreasoning.Store for semantic_search_bounded test.
// The semantic field maps query strings to returned chunks.
type fakeStoreSearch5 struct {
	semantic map[string][]smartreasoning.Chunk
}

func (s *fakeStoreSearch5) SemanticSearch(_ context.Context, queries []string, _ int) (map[string][]smartreasoning.Chunk, error) {
	out := make(map[string][]smartreasoning.Chunk, len(queries))
	for _, q := range queries {
		out[q] = append([]smartreasoning.Chunk(nil), s.semantic[q]...)
	}
	return out, nil
}

func (s *fakeStoreSearch5) ScanChunks(_ context.Context, offset, limit int) ([]smartreasoning.Chunk, error) {
	return nil, nil
}

func (s *fakeStoreSearch5) GetDocument(_ context.Context, documentID string) (*smartreasoning.Document, error) {
	return nil, nil
}

func (s *fakeStoreSearch5) ListDocumentChunks(_ context.Context, documentID string, offset, limit int) ([]smartreasoning.Chunk, int64, error) {
	return nil, 0, nil
}

// fakeJSSearch5 implements smartreasoning.JavaScriptExecutor for semantic_search test.
type fakeJSSearch5 struct{}

func (e *fakeJSSearch5) Execute(_ context.Context, code string) (string, error) {
	return "", nil
}

// findSearchTool locates the search_chunks tool.
func findSearchTool(t *testing.T, tools []einotool.BaseTool) einotool.InvokableTool {
	t.Helper()
	ctx := context.Background()
	for _, tool := range tools {
		info, err := tool.Info(ctx)
		if err != nil || info == nil {
			continue
		}
		if info.Name == "search_chunks" {
			it, ok := tool.(einotool.InvokableTool)
			if !ok {
				t.Fatalf("search_chunks does not implement InvokableTool")
			}
			return it
		}
	}
	t.Fatal("search_chunks tool not found")
	return nil
}

func TestSemanticSearchBoundedValidation(t *testing.T) {
	cases := GetValidationTestCases(t)

	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			queriesRaw := tc.Inputs["queries"].([]interface{})
			queries := make([]string, len(queriesRaw))
			for i, q := range queriesRaw {
				queries[i] = q.(string)
			}

			markerVal := tc.Inputs["marker"].(string)
			errored := tc.Expected["errored"].(string)
			outMarker := tc.Expected["out_marker"].(string)

			// Build a semantic map: for the happy case, wire each query to return
			// a chunk containing the marker. For error cases, doesn't matter.
			semanticMap := make(map[string][]smartreasoning.Chunk)
			if markerVal != "__skip__" && errored == "no" {
				for _, q := range queries {
					semanticMap[q] = []smartreasoning.Chunk{
						{
							ID:           "chunk-search-1",
							Content:      "The document " + markerVal + " was found in context.",
							DocumentID:   "doc-1",
							DocumentName: "Search Doc",
							DatasetID:    "kb-1",
						},
					}
				}
			}

			store := &fakeStoreSearch5{semantic: semanticMap}

			suite, err := smartreasoning.NewSuite(smartreasoning.Options{
				TenantID:       "tenant-1",
				DatasetIDs:     []string{"kb-1"},
				Store:          store,
				JavaScriptExec: &fakeJSSearch5{},
			})
			if err != nil {
				t.Fatalf("NewSuite: %v", err)
			}

			searchTool := findSearchTool(t, suite.Tools())

			// Build args JSON with the queries array
			argsBytes, jsonErr := json.Marshal(map[string]interface{}{"queries": queries})
			if jsonErr != nil {
				t.Fatalf("marshal args: %v", jsonErr)
			}
			argsJSON := string(argsBytes)

			output, callErr := searchTool.InvokableRun(context.Background(), argsJSON)

			if errored == "yes" {
				if callErr == nil {
					t.Errorf("expected an error but got nil (output: %q)", output)
				}
			} else {
				// errored == "no"
				if callErr != nil {
					t.Errorf("expected no error but got: %v (output: %q)", callErr, output)
				}
				if outMarker != "__skip__" {
					if !strings.Contains(output, outMarker) {
						t.Errorf("output should contain marker %q, got: %q", outMarker, output)
					}
				}
			}
		})
	}
}
