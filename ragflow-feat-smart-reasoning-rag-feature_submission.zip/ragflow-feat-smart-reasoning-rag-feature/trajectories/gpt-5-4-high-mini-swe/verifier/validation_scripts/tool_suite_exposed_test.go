package runtime_test

import (
	"context"
	"strings"
	"testing"

	"github.com/cloudwego/eino/compose"
	"github.com/cloudwego/eino/flow/agent/react"

	"ragflow/internal/chatmode/smartreasoning"
)

// fakeStoreSuite1 implements smartreasoning.Store for story 1 (no retrieval needed).
type fakeStoreSuite1 struct{}

func (s *fakeStoreSuite1) SemanticSearch(_ context.Context, queries []string, _ int) (map[string][]smartreasoning.Chunk, error) {
	out := make(map[string][]smartreasoning.Chunk, len(queries))
	for _, q := range queries {
		out[q] = nil
	}
	return out, nil
}

func (s *fakeStoreSuite1) ScanChunks(_ context.Context, offset, limit int) ([]smartreasoning.Chunk, error) {
	return nil, nil
}

func (s *fakeStoreSuite1) GetDocument(_ context.Context, documentID string) (*smartreasoning.Document, error) {
	return nil, nil
}

func (s *fakeStoreSuite1) ListDocumentChunks(_ context.Context, documentID string, offset, limit int) ([]smartreasoning.Chunk, int64, error) {
	return nil, 0, nil
}

// fakeJSSuite1 implements smartreasoning.JavaScriptExecutor for story 1.
type fakeJSSuite1 struct{}

func (e *fakeJSSuite1) Execute(_ context.Context, code string) (string, error) {
	return "", nil
}

func TestToolSuiteExposedValidation(t *testing.T) {
	cases := GetValidationTestCases(t)

	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			// required: the required tool names (may include extras for missing-count probe)
			requiredRaw := tc.Inputs["required"].([]interface{})
			required := make([]string, len(requiredRaw))
			for i, r := range requiredRaw {
				required[i] = r.(string)
			}

			// legacy: the four legacy names that should NOT appear in the prompt
			legacyRaw := tc.Inputs["legacy"].([]interface{})
			legacy := make([]string, len(legacyRaw))
			for i, l := range legacyRaw {
				legacy[i] = l.(string)
			}

			// Build the tool suite with a valid tenant and dataset so NewSuite succeeds.
			suite, err := smartreasoning.NewSuite(smartreasoning.Options{
				TenantID:       "tenant-test",
				DatasetIDs:     []string{"kb-test"},
				Store:          &fakeStoreSuite1{},
				JavaScriptExec: &fakeJSSuite1{},
			})
			if err != nil {
				t.Fatalf("NewSuite: %v", err)
			}

			tools := suite.Tools()
			prompt := suite.SystemPrompt()

			// Compute tool_count
			toolCount := len(tools)

			// Compute missing_tool_count: how many required names are absent
			toolNames := make(map[string]struct{}, len(tools))
			ctx := context.Background()
			for _, tool := range tools {
				info, infoErr := tool.Info(ctx)
				if infoErr != nil || info == nil {
					continue
				}
				toolNames[info.Name] = struct{}{}
			}
			missingToolCount := 0
			for _, req := range required {
				if _, ok := toolNames[req]; !ok {
					missingToolCount++
				}
			}

			// Compute legacy_in_prompt_count
			legacyInPromptCount := 0
			for _, leg := range legacy {
				if strings.Contains(prompt, leg) {
					legacyInPromptCount++
				}
			}

			// Compute placeholder_in_prompt_count: count {{ and }} occurrences
			placeholderInPromptCount := strings.Count(prompt, "{{") + strings.Count(prompt, "}}")

			// Compute nil_model_errors:
			// Call react.NewAgent with nil ToolCallingModel (nil chat model) and check if it
			// rejects. Wrap in recover in case it panics.
			nilModelErrors := "no"
			func() {
				defer func() {
					if r := recover(); r != nil {
						nilModelErrors = "yes"
					}
				}()
				_, agentErr := react.NewAgent(ctx, &react.AgentConfig{
					ToolCallingModel: nil,
					ToolsConfig: compose.ToolsNodeConfig{
						Tools: suite.Tools(),
					},
				})
				if agentErr != nil {
					nilModelErrors = "yes"
				}
			}()

			// Assertions
			wantToolCount := int(tc.Expected["tool_count"].(float64))
			if toolCount != wantToolCount {
				t.Errorf("tool_count = %d, want %d", toolCount, wantToolCount)
			}

			wantMissingToolCount := int(tc.Expected["missing_tool_count"].(float64))
			if missingToolCount != wantMissingToolCount {
				t.Errorf("missing_tool_count = %d, want %d", missingToolCount, wantMissingToolCount)
			}

			wantLegacyInPromptCount := int(tc.Expected["legacy_in_prompt_count"].(float64))
			if legacyInPromptCount != wantLegacyInPromptCount {
				t.Errorf("legacy_in_prompt_count = %d, want %d", legacyInPromptCount, wantLegacyInPromptCount)
			}

			wantPlaceholderInPromptCount := int(tc.Expected["placeholder_in_prompt_count"].(float64))
			if placeholderInPromptCount != wantPlaceholderInPromptCount {
				t.Errorf("placeholder_in_prompt_count = %d, want %d", placeholderInPromptCount, wantPlaceholderInPromptCount)
			}

			wantNilModelErrors := tc.Expected["nil_model_errors"].(string)
			if nilModelErrors != wantNilModelErrors {
				t.Errorf("nil_model_errors = %q, want %q", nilModelErrors, wantNilModelErrors)
			}
		})
	}
}
