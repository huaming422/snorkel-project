package runtime_test

import (
	"context"
	"encoding/json"
	"strings"
	"testing"

	einotool "github.com/cloudwego/eino/components/tool"

	"ragflow/internal/chatmode/smartreasoning"
)

// fakeStoreDeep4 implements smartreasoning.Store for deep_read_document test.
// list is a pre-sorted (ALPHA first, BETA second) slice of chunks.
// doc is the document returned by GetDocument.
type fakeStoreDeep4 struct {
	doc   *smartreasoning.Document
	list  []smartreasoning.Chunk
	total int64
}

func (s *fakeStoreDeep4) SemanticSearch(_ context.Context, queries []string, _ int) (map[string][]smartreasoning.Chunk, error) {
	out := make(map[string][]smartreasoning.Chunk, len(queries))
	for _, q := range queries {
		out[q] = nil
	}
	return out, nil
}

func (s *fakeStoreDeep4) ScanChunks(_ context.Context, offset, limit int) ([]smartreasoning.Chunk, error) {
	return nil, nil
}

func (s *fakeStoreDeep4) GetDocument(_ context.Context, documentID string) (*smartreasoning.Document, error) {
	if s.doc == nil || s.doc.ID != documentID {
		return nil, errDeep4("document not found")
	}
	cp := *s.doc
	return &cp, nil
}

func (s *fakeStoreDeep4) ListDocumentChunks(_ context.Context, documentID string, offset, limit int) ([]smartreasoning.Chunk, int64, error) {
	if s.doc == nil || s.doc.ID != documentID {
		return nil, 0, errDeep4("document not found")
	}
	// The chunks are already in reading order (ALPHA first, BETA second).
	// Apply offset/limit.
	if offset >= len(s.list) {
		return nil, s.total, nil
	}
	end := offset + limit
	if end > len(s.list) {
		end = len(s.list)
	}
	return append([]smartreasoning.Chunk(nil), s.list[offset:end]...), s.total, nil
}

type errDeep4 string

func (e errDeep4) Error() string { return string(e) }

// fakeJSDeep4 implements smartreasoning.JavaScriptExecutor for deep_read test.
type fakeJSDeep4 struct{}

func (e *fakeJSDeep4) Execute(_ context.Context, code string) (string, error) {
	return "", nil
}

// findListChunksTool locates the list_chunks tool.
func findListChunksTool(t *testing.T, tools []einotool.BaseTool) einotool.InvokableTool {
	t.Helper()
	ctx := context.Background()
	for _, tool := range tools {
		info, err := tool.Info(ctx)
		if err != nil || info == nil {
			continue
		}
		if info.Name == "list_chunks" {
			it, ok := tool.(einotool.InvokableTool)
			if !ok {
				t.Fatalf("list_chunks does not implement InvokableTool")
			}
			return it
		}
	}
	t.Fatal("list_chunks tool not found")
	return nil
}

func TestDeepReadDocumentValidation(t *testing.T) {
	cases := GetValidationTestCases(t)

	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			mode := tc.Inputs["mode"].(string)
			docID := tc.Inputs["doc_id"].(string)
			markerA := tc.Inputs["marker_a"].(string)
			markerB := tc.Inputs["marker_b"].(string)
			errored := tc.Expected["errored"].(string)
			firstMarker := tc.Expected["first_marker"].(string)
			secondMarker := tc.Expected["second_marker"].(string)

			// Build fake store with two ORDINARY-PROSE chunks in reading order.
			// ALPHA has lower reading order, BETA has higher.
			// For missing_doc mode, the doc id is empty and we don't need a wired doc.
			var fakeDoc *smartreasoning.Document
			var fakeList []smartreasoning.Chunk

			if mode != "missing_doc" {
				fakeDoc = &smartreasoning.Document{
					ID:        "doc-1",
					TenantID:  "tenant-1",
					DatasetID: "kb-1",
					Name:      "Test Document",
				}
				// markerA = "ALPHA", markerB = "BETA"
				// Store in reading order: ALPHA first (index 0), BETA second (index 1).
				alphaContent := "The first section contains " + markerA + " information."
				betaContent := "The second section contains " + markerB + " information."
				fakeList = []smartreasoning.Chunk{
					{
						ID:           "chunk-alpha",
						Content:      alphaContent,
						DocumentID:   "doc-1",
						DocumentName: "Test Document",
						DatasetID:    "kb-1",
					},
					{
						ID:           "chunk-beta",
						Content:      betaContent,
						DocumentID:   "doc-1",
						DocumentName: "Test Document",
						DatasetID:    "kb-1",
					},
				}
			}

			store := &fakeStoreDeep4{
				doc:   fakeDoc,
				list:  fakeList,
				total: int64(len(fakeList)),
			}

			suite, err := smartreasoning.NewSuite(smartreasoning.Options{
				TenantID:       "tenant-1",
				DatasetIDs:     []string{"kb-1"},
				Store:          store,
				JavaScriptExec: &fakeJSDeep4{},
			})
			if err != nil {
				t.Fatalf("NewSuite: %v", err)
			}

			listTool := findListChunksTool(t, suite.Tools())
			ctx := context.Background()

			switch mode {
			case "order":
				// Call with document id and no page limit (defaults: page=1, page_size=20)
				args := map[string]interface{}{"document_id": docID}
				argsBytes, _ := json.Marshal(args)
				output, callErr := listTool.InvokableRun(ctx, string(argsBytes))

				if errored == "yes" {
					if callErr == nil {
						t.Errorf("expected error but got nil (output: %q)", output)
					}
				} else {
					// errored == "no"
					if callErr != nil {
						t.Errorf("expected no error but got: %v (output: %q)", callErr, output)
					}
					if firstMarker != "__skip__" {
						if !strings.Contains(output, firstMarker) {
							t.Errorf("output should contain first_marker %q, got: %q", firstMarker, output)
						}
					}
					if secondMarker != "__skip__" {
						if !strings.Contains(output, secondMarker) {
							t.Errorf("output should contain second_marker %q, got: %q", secondMarker, output)
						}
					}
					// Assert reading order: first_marker appears before second_marker
					if firstMarker != "__skip__" && secondMarker != "__skip__" {
						idxFirst := strings.Index(output, firstMarker)
						idxSecond := strings.Index(output, secondMarker)
						if idxFirst >= idxSecond {
							t.Errorf("first_marker %q (pos %d) should appear before second_marker %q (pos %d) in output",
								firstMarker, idxFirst, secondMarker, idxSecond)
						}
					}
				}

			case "page":
				// Call with document id and page_size=1 to get only first chunk
				args := map[string]interface{}{"document_id": docID, "page": 1, "page_size": 1}
				argsBytes, _ := json.Marshal(args)
				output, callErr := listTool.InvokableRun(ctx, string(argsBytes))

				if errored == "yes" {
					if callErr == nil {
						t.Errorf("expected error but got nil (output: %q)", output)
					}
				} else {
					// errored == "no"
					if callErr != nil {
						t.Errorf("expected no error but got: %v (output: %q)", callErr, output)
					}
					if firstMarker != "__skip__" {
						if !strings.Contains(output, firstMarker) {
							t.Errorf("output should contain first_marker %q, got: %q", firstMarker, output)
						}
					}
					if secondMarker != "__skip__" {
						if strings.Contains(output, secondMarker) {
							t.Errorf("output should NOT contain second_marker %q on first page, got: %q", secondMarker, output)
						}
					}
				}

			case "missing_doc":
				// Call with empty document_id
				args := map[string]interface{}{"document_id": docID}
				argsBytes, _ := json.Marshal(args)
				output, callErr := listTool.InvokableRun(ctx, string(argsBytes))

				if errored == "yes" {
					if callErr == nil {
						t.Errorf("expected error for missing doc_id but got nil (output: %q)", output)
					}
				} else {
					if callErr != nil {
						t.Errorf("expected no error but got: %v", callErr)
					}
				}

			default:
				t.Fatalf("unknown mode: %q", mode)
			}
		})
	}
}
