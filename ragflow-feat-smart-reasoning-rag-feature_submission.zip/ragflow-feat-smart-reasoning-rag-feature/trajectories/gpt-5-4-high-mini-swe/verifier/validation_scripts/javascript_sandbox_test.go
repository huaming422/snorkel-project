package runtime_test

import (
	"context"
	"encoding/json"
	"strings"
	"testing"
	"time"

	einotool "github.com/cloudwego/eino/components/tool"

	"ragflow/internal/chatmode/smartreasoning"
)

// fakeStoreJS2 implements smartreasoning.Store for javascript_sandbox test.
type fakeStoreJS2 struct{}

func (s *fakeStoreJS2) SemanticSearch(_ context.Context, queries []string, _ int) (map[string][]smartreasoning.Chunk, error) {
	out := make(map[string][]smartreasoning.Chunk, len(queries))
	for _, q := range queries {
		out[q] = nil
	}
	return out, nil
}

func (s *fakeStoreJS2) ScanChunks(_ context.Context, offset, limit int) ([]smartreasoning.Chunk, error) {
	return nil, nil
}

func (s *fakeStoreJS2) GetDocument(_ context.Context, documentID string) (*smartreasoning.Document, error) {
	return nil, nil
}

func (s *fakeStoreJS2) ListDocumentChunks(_ context.Context, documentID string, offset, limit int) ([]smartreasoning.Chunk, int64, error) {
	return nil, 0, nil
}

// fakeJSExecutorForCase is a per-case JavaScript executor.
// - If blocking is true, it blocks until ctx.Done() and returns an error.
// - Otherwise it returns the preset output immediately.
type fakeJSExecutorForCase struct {
	output   string
	blocking bool
}

func (e *fakeJSExecutorForCase) Execute(ctx context.Context, code string) (string, error) {
	if e.blocking {
		<-ctx.Done()
		return "", ctx.Err()
	}
	return e.output, nil
}

// findToolByNameJS finds a tool by its Info().Name.
func findToolByNameJS(t *testing.T, tools []einotool.BaseTool, name string) einotool.InvokableTool {
	t.Helper()
	ctx := context.Background()
	for _, tool := range tools {
		info, err := tool.Info(ctx)
		if err != nil || info == nil {
			continue
		}
		if info.Name == name {
			it, ok := tool.(einotool.InvokableTool)
			if !ok {
				t.Fatalf("tool %s does not implement InvokableTool", name)
			}
			return it
		}
	}
	t.Fatalf("tool %q not found in suite", name)
	return nil
}

func TestJavascriptSandboxValidation(t *testing.T) {
	cases := GetValidationTestCases(t)

	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			codeInput := tc.Inputs["code"].(string)
			ctxTimeoutMs := int(tc.Inputs["ctx_timeout_ms"].(float64))
			errored := tc.Expected["errored"].(string)
			stdoutMarker := tc.Expected["stdout_marker"].(string)

			// Compute the actual code to use
			var code string
			if codeInput == "__OVERSIZED__" {
				code = strings.Repeat("var x=1;", 5000000)
			} else {
				code = codeInput
			}

			// Determine if this is an infinite-loop / timeout test
			isBlockingCase := ctxTimeoutMs > 0

			// Build the executor:
			// - For the happy case (errored=no), return canned output.
			// - For the blocking case (timeout test), use a blocking executor.
			// - For error cases due to ES5.1 validation, executor doesn't matter.
			// - For the oversized case, a non-blocking executor; if no size guard exists,
			//   the tool succeeds and the test fails naturally.
			var jsExec smartreasoning.JavaScriptExecutor
			if isBlockingCase {
				jsExec = &fakeJSExecutorForCase{blocking: true}
			} else {
				jsExec = &fakeJSExecutorForCase{output: "sum=10\n"}
			}

			suite, err := smartreasoning.NewSuite(smartreasoning.Options{
				TenantID:       "tenant-test",
				DatasetIDs:     []string{"kb-test"},
				Store:          &fakeStoreJS2{},
				JavaScriptExec: jsExec,
			})
			if err != nil {
				t.Fatalf("NewSuite: %v", err)
			}

			tools := suite.Tools()

			// Find run_javascript tool (code arg key is "code")
			jsTool := findToolByNameJS(t, tools, "run_javascript")

			// Build args JSON
			argsBytes, jsonErr := json.Marshal(map[string]string{"code": code})
			if jsonErr != nil {
				t.Fatalf("marshal args: %v", jsonErr)
			}
			argsJSON := string(argsBytes)

			// Choose context
			var ctx context.Context
			var cancel context.CancelFunc
			if ctxTimeoutMs > 0 {
				ctx, cancel = context.WithTimeout(context.Background(), time.Duration(ctxTimeoutMs)*time.Millisecond)
				defer cancel()
			} else {
				ctx = context.Background()
			}

			// Invoke and time it
			start := time.Now()
			output, callErr := jsTool.InvokableRun(ctx, argsJSON)
			elapsed := time.Since(start)

			// Assertions
			if errored == "yes" {
				if callErr == nil {
					t.Errorf("expected an error but got nil (output: %q)", output)
				}
				if ctxTimeoutMs > 0 {
					if elapsed >= 15*time.Second {
						t.Errorf("runaway snippet must be interrupted well under 15 seconds, got %v", elapsed)
					}
				}
			} else {
				// errored == "no"
				if callErr != nil {
					t.Errorf("expected no error but got: %v (output: %q)", callErr, output)
				}
				if stdoutMarker != "__skip__" {
					if !strings.Contains(output, stdoutMarker) {
						t.Errorf("output should contain %q, got: %q", stdoutMarker, output)
					}
				}
			}
		})
	}
}
