#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from minisweagent.agents.default import DefaultAgent
from minisweagent.environments.local import LocalEnvironment
from minisweagent.models import get_model


OBSERVATION_TEMPLATE = """{%- if output.output | length < 10000 -%}
{
  "returncode": {{ output.returncode }},
  "output": {{ output.output | tojson }}
  {%- if output.exception_info %}, "exception_info": {{ output.exception_info | tojson }}{% endif %}
}
{%- else -%}
{
  "returncode": {{ output.returncode }},
  "output_head": {{ output.output[:5000] | tojson }},
  "output_tail": {{ output.output[-5000:] | tojson }},
  "elided_chars": {{ output.output | length - 10000 }},
  "warning": "Output too long."
  {%- if output.exception_info %}, "exception_info": {{ output.exception_info | tojson }}{% endif %}
}
{%- endif -%}
"""


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--system-prompt", required=True)
    parser.add_argument("--user-prompt", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--extra-headers", default="", help="JSON dict of gateway attribution headers")
    parser.add_argument("--set-cache-control", default="", help="mini-swe set_cache_control mode (e.g. default_end)")
    parser.add_argument("--cwd", required=True)
    parser.add_argument("--step-limit", type=int, default=0)
    parser.add_argument("--command-timeout", type=int, default=600)
    args = parser.parse_args()

    system_prompt = Path(args.system_prompt).read_text()
    user_prompt = Path(args.user_prompt).read_text()

    # Pin temperature=0.0 ONLY for plain openai-slug non-reasoning models. Two
    # classes reject a pinned temperature outright and turn every VA call into a
    # BadRequestError (this killed the 2026-07-22 gitea trial's smoke gate on
    # every family using the default VA path): gpt-5.x/o-series reject
    # temperature != 1, and Anthropic models deprecate the parameter, so a
    # catalog slug riding an OpenAI-compatible request ("openai/@provider/...")
    # 400s on it. Determinism was never real for agentic rollouts anyway.
    _leaf = args.model.split("/")[-1].lower()
    _openai_reasoning = args.model.startswith("openai/") and (
        _leaf.startswith("gpt-5") or (_leaf[:1] == "o" and _leaf[1:2].isdigit())
    )
    _model_kwargs = {"drop_params": True, "parallel_tool_calls": True}
    if args.model.startswith("openai/") and not args.model.startswith("openai/@") and not _openai_reasoning:
        _model_kwargs["temperature"] = 0.0
    if args.extra_headers:
        # Portkey dashboard attribution (present only on the gateway route).
        _model_kwargs["extra_headers"] = json.loads(args.extra_headers)
    model_config = {
        "model_name": args.model,
        "model_kwargs": _model_kwargs,
        "cost_tracking": "ignore_errors",
        "observation_template": OBSERVATION_TEMPLATE,
        "format_error_template": (
            "Tool call error:\n<error>{{ error }}</error>\n"
            "Every response must include at least one bash tool call. "
            "When finished, run exactly: echo COMPLETE_TASK_AND_SUBMIT_FINAL_OUTPUT"
        ),
    }
    if _openai_reasoning:
        # gpt-5.x/o-series must use the Responses API (litellm_response); overrides model_class.
        model_config["model_class"] = "litellm_response"
    # Anthropic prompt caching: decided ONCE by the parent (agent_routing ->
    # is_anthropic_model) and passed in. This runner is generated standalone and
    # deliberately does not re-derive it -- one decision point, no drift.
    if args.set_cache_control:
        model_config["set_cache_control"] = args.set_cache_control

    model = get_model(config=model_config)
    env = LocalEnvironment(
        cwd=args.cwd,
        timeout=args.command_timeout,
        env={
            "PAGER": "cat",
            "MANPAGER": "cat",
            "LESS": "-R",
            "PIP_PROGRESS_BAR": "off",
            "TQDM_DISABLE": "1",
        },
    )
    agent = DefaultAgent(
        model,
        env,
        system_template=system_prompt,
        instance_template="{{ task }}",
        step_limit=args.step_limit,
        cost_limit=0,
        output_path=Path(args.output),
    )
    info = agent.run(user_prompt)
    print(json.dumps(info, indent=2))
    return 0 if info.get("exit_status") == "Submitted" else 1


if __name__ == "__main__":
    raise SystemExit(main())
