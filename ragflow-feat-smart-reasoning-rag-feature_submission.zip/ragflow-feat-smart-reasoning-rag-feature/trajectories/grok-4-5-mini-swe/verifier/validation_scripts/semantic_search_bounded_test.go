package runtime_test

import (
	"context"
	"encoding/json"
	"strings"
	"testing"

	"github.com/cloudwego/eino/components/tool"
	"ragflow/internal/agent/smartreasoning"
)

func TestSemanticSearchBoundedValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			// Get queries from inputs
			queriesRaw := tc.Inputs["queries"].([]interface{})
			queries := make([]string, len(queriesRaw))
			for i, v := range queriesRaw {
				queries[i] = v.(string)
			}

			errored := tc.Expected["errored"].(string)
			outMarker := tc.Expected["out_marker"].(string)

			// For the happy case, register a fake store with a chunk containing the marker
			markerRaw := tc.Inputs["marker"]
			marker := ""
			if markerRaw != nil {
				if s, ok := markerRaw.(string); ok && s != "__skip__" {
					marker = s
				}
			}

			// Build scope and store
			var store smartreasoning.ChunkStore
			scope := smartreasoning.Scope{
				TenantID:   "test-tenant",
				DatasetIDs: []string{"ds-test"},
			}

			if errored == "no" && marker != "" {
				// Happy case: need a real store with a matching chunk
				store = &smartreasoning.MemoryStore{
					DatasetTenant: map[string]string{
						"ds-test": "test-tenant",
					},
					Chunks: []smartreasoning.Chunk{
						{
							ID:         "chunk-search-1",
							Content:    "This document contains " + marker + " and other relevant information about the author and deadline.",
							DocumentID: "doc-search-1",
							DatasetID:  "ds-test",
						},
					},
				}
			}
			// For error cases, store remains nil (validation happens before lookup)

			suite, err := smartreasoning.BuildTools(scope, store)
			if err != nil {
				t.Fatalf("BuildTools failed: %v", err)
			}

			// Find the search_chunks tool
			var searchTool tool.InvokableTool
			for _, tl := range suite.AsList() {
				info, infoErr := tl.Info(context.Background())
				if infoErr != nil {
					t.Fatalf("Info() failed: %v", infoErr)
				}
				if info.Name == "search_chunks" {
					inv, ok := tl.(tool.InvokableTool)
					if !ok {
						t.Fatal("search_chunks must be invokable")
					}
					searchTool = inv
					break
				}
			}
			if searchTool == nil {
				t.Fatal("search_chunks tool not found")
			}

			// Build args JSON with queries array
			args := map[string]interface{}{
				"queries": queries,
			}
			argsJSON, marshalErr := json.Marshal(args)
			if marshalErr != nil {
				t.Fatalf("json.Marshal failed: %v", marshalErr)
			}

			// Invoke
			out, invokeErr := searchTool.InvokableRun(context.Background(), string(argsJSON))

			if errored == "yes" {
				if invokeErr == nil {
					t.Errorf("expected error for queries=%v but got none (output: %s)", queries, out)
				}
			} else {
				// errored == "no"
				if invokeErr != nil {
					t.Errorf("expected no error for queries=%v, got: %v", queries, invokeErr)
				}
				if outMarker != "__skip__" {
					if !strings.Contains(out, outMarker) {
						t.Errorf("output %q should contain out_marker %q", out, outMarker)
					}
				}
			}
		})
	}
}
