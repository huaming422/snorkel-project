package runtime_test

import (
	"context"
	"encoding/json"
	"strings"
	"testing"

	"github.com/cloudwego/eino/components/tool"
	"ragflow/internal/agent/smartreasoning"
)

func TestDeepReadDocumentValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			mode := tc.Inputs["mode"].(string)
			docID := tc.Inputs["doc_id"].(string)

			markerAStr := tc.Inputs["marker_a"].(string)
			markerBStr := tc.Inputs["marker_b"].(string)

			errored := tc.Expected["errored"].(string)
			firstMarker := tc.Expected["first_marker"].(string)
			secondMarker := tc.Expected["second_marker"].(string)

			// Build a fake store with ALPHA before BETA (reading order by insertion order).
			// The MemoryStore.List preserves insertion order, so ALPHA (first in slice)
			// comes before BETA (second in slice).
			var store smartreasoning.ChunkStore
			if mode != "missing_doc" {
				chunks := []smartreasoning.Chunk{}
				if markerAStr != "__skip__" {
					chunks = append(chunks, smartreasoning.Chunk{
						ID:         "chunk-alpha",
						Content:    "Some text about " + markerAStr + " content here",
						DocumentID: docID,
						DatasetID:  "ds-test",
					})
				}
				if markerBStr != "__skip__" {
					chunks = append(chunks, smartreasoning.Chunk{
						ID:         "chunk-beta",
						Content:    "Some text about " + markerBStr + " content here",
						DocumentID: docID,
						DatasetID:  "ds-test",
					})
				}
				store = &smartreasoning.MemoryStore{
					DatasetTenant: map[string]string{
						"ds-test": "test-tenant",
					},
					Chunks: chunks,
				}
			}

			scope := smartreasoning.Scope{
				TenantID:   "test-tenant",
				DatasetIDs: []string{"ds-test"},
			}
			suite, err := smartreasoning.BuildTools(scope, store)
			if err != nil {
				t.Fatalf("BuildTools failed: %v", err)
			}

			// Find the list_chunks tool
			var listTool tool.InvokableTool
			for _, tl := range suite.AsList() {
				info, infoErr := tl.Info(context.Background())
				if infoErr != nil {
					t.Fatalf("Info() failed: %v", infoErr)
				}
				if info.Name == "list_chunks" {
					inv, ok := tl.(tool.InvokableTool)
					if !ok {
						t.Fatal("list_chunks must be invokable")
					}
					listTool = inv
					break
				}
			}
			if listTool == nil {
				t.Fatal("list_chunks tool not found")
			}

			var argsJSON []byte
			var marshalErr error
			switch mode {
			case "order":
				// No page limit (use defaults)
				args := map[string]interface{}{
					"document_id": docID,
				}
				argsJSON, marshalErr = json.Marshal(args)
				if marshalErr != nil {
					t.Fatalf("json.Marshal failed: %v", marshalErr)
				}
			case "page":
				// page_size = 1 to get only first chunk
				args := map[string]interface{}{
					"document_id": docID,
					"page_size":   1,
				}
				argsJSON, marshalErr = json.Marshal(args)
				if marshalErr != nil {
					t.Fatalf("json.Marshal failed: %v", marshalErr)
				}
			case "missing_doc":
				// Empty document_id
				args := map[string]interface{}{
					"document_id": "",
				}
				argsJSON, marshalErr = json.Marshal(args)
				if marshalErr != nil {
					t.Fatalf("json.Marshal failed: %v", marshalErr)
				}
			}

			out, invokeErr := listTool.InvokableRun(context.Background(), string(argsJSON))

			if errored == "yes" {
				if invokeErr == nil {
					t.Errorf("expected error for mode=%s but got none (output: %s)", mode, out)
				}
			} else {
				// errored == "no"
				if invokeErr != nil {
					t.Errorf("expected no error for mode=%s, got: %v", mode, invokeErr)
				}

				switch mode {
				case "order":
					// Both markers must appear; first_marker before second_marker
					if firstMarker != "__skip__" {
						if !strings.Contains(out, firstMarker) {
							t.Errorf("output should contain first_marker %q; output=%q", firstMarker, out)
						}
					}
					if secondMarker != "__skip__" {
						if !strings.Contains(out, secondMarker) {
							t.Errorf("output should contain second_marker %q; output=%q", secondMarker, out)
						}
					}
					if firstMarker != "__skip__" && secondMarker != "__skip__" {
						idxFirst := strings.Index(out, firstMarker)
						idxSecond := strings.Index(out, secondMarker)
						if idxFirst >= idxSecond {
							t.Errorf("first_marker %q (at %d) must appear before second_marker %q (at %d) in output",
								firstMarker, idxFirst, secondMarker, idxSecond)
						}
					}
				case "page":
					// first_marker should appear, second_marker should NOT
					if firstMarker != "__skip__" {
						if !strings.Contains(out, firstMarker) {
							t.Errorf("output should contain first_marker %q (first page); output=%q", firstMarker, out)
						}
					}
					if secondMarker != "__skip__" {
						if strings.Contains(out, secondMarker) {
							t.Errorf("output should NOT contain second_marker %q on first page; output=%q", secondMarker, out)
						}
					}
				}
			}
		})
	}
}
