package runtime_test

import (
	"context"
	"encoding/json"
	"strings"
	"testing"
	"time"

	"github.com/cloudwego/eino/components/tool"
	"ragflow/internal/agent/smartreasoning"
)

func TestJavascriptSandboxValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			// Build tool suite to get the run_javascript tool
			scope := smartreasoning.Scope{TenantID: "test-tenant", DatasetIDs: []string{}}
			suite, err := smartreasoning.BuildTools(scope, nil)
			if err != nil {
				t.Fatalf("BuildTools should succeed: %v", err)
			}

			// Find the run_javascript tool
			var jsTool tool.InvokableTool
			for _, tl := range suite.AsList() {
				info, infoErr := tl.Info(context.Background())
				if infoErr != nil {
					t.Fatalf("Info() failed: %v", infoErr)
				}
				if info.Name == "run_javascript" {
					inv, ok := tl.(tool.InvokableTool)
					if !ok {
						t.Fatal("run_javascript must be invokable")
					}
					jsTool = inv
					break
				}
			}
			if jsTool == nil {
				t.Fatal("run_javascript tool not found")
			}

			// Determine the code to run
			code := tc.Inputs["code"].(string)
			if code == "__OVERSIZED__" {
				// Very large but syntactically valid ES5.1 source (~40 MB)
				code = strings.Repeat("var x=1;", 5000000)
			}

			// Build args JSON
			args := map[string]string{"code": code}
			argsJSON, marshalErr := json.Marshal(args)
			if marshalErr != nil {
				t.Fatalf("json.Marshal failed: %v", marshalErr)
			}

			// Choose context based on ctx_timeout_ms
			ctxTimeoutMs := int(tc.Inputs["ctx_timeout_ms"].(float64))
			var ctx context.Context
			var cancel context.CancelFunc
			if ctxTimeoutMs > 0 {
				ctx, cancel = context.WithTimeout(context.Background(), time.Duration(ctxTimeoutMs)*time.Millisecond)
				defer cancel()
			} else {
				ctx = context.Background()
			}

			// Invoke the tool and measure elapsed time
			start := time.Now()
			out, invokeErr := jsTool.InvokableRun(ctx, string(argsJSON))
			elapsed := time.Since(start)

			errored := tc.Expected["errored"].(string)
			stdoutMarker := tc.Expected["stdout_marker"].(string)

			if errored == "no" {
				if invokeErr != nil {
					t.Errorf("expected no error but got: %v", invokeErr)
				}
				if stdoutMarker != "__skip__" {
					if !strings.Contains(out, stdoutMarker) {
						t.Errorf("output %q should contain stdout_marker %q", out, stdoutMarker)
					}
				}
			} else {
				// errored == "yes"
				if invokeErr == nil {
					t.Errorf("expected an error but got none (output: %s)", out)
				}
				if ctxTimeoutMs > 0 {
					if elapsed >= 15*time.Second {
						t.Errorf("runaway snippet must be interrupted before 15s, elapsed=%v", elapsed)
					}
				}
			}
		})
	}
}
