package runtime_test

import (
	"context"
	"encoding/json"
	"strings"
	"testing"

	"github.com/cloudwego/eino/components/tool"
	"ragflow/internal/agent/smartreasoning"
)

func TestGrepChunksExactMatchValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			query := tc.Inputs["query"].(string)

			// For the happy case, set up a fake store with a chunk containing the marker
			markerRaw := tc.Inputs["marker"]
			marker := ""
			if markerRaw != nil {
				if s, ok := markerRaw.(string); ok && s != "__skip__" {
					marker = s
				}
			}

			errored := tc.Expected["errored"].(string)
			outMarker := tc.Expected["out_marker"].(string)

			// Build the store with a chunk containing the marker (for happy path)
			var store smartreasoning.ChunkStore
			if errored == "no" && marker != "" {
				store = &smartreasoning.MemoryStore{
					DatasetTenant: map[string]string{
						"ds-test": "test-tenant",
					},
					Chunks: []smartreasoning.Chunk{
						{
							ID:         "chunk-1",
							Content:    "alpha " + marker + " omega",
							DocumentID: "doc-1",
							DatasetID:  "ds-test",
						},
					},
				}
			}

			scope := smartreasoning.Scope{
				TenantID:   "test-tenant",
				DatasetIDs: []string{"ds-test"},
			}
			suite, err := smartreasoning.BuildTools(scope, store)
			if err != nil {
				t.Fatalf("BuildTools failed: %v", err)
			}

			// Find the grep_chunks tool
			var grepTool tool.InvokableTool
			for _, tl := range suite.AsList() {
				info, infoErr := tl.Info(context.Background())
				if infoErr != nil {
					t.Fatalf("Info() failed: %v", infoErr)
				}
				if info.Name == "grep_chunks" {
					inv, ok := tl.(tool.InvokableTool)
					if !ok {
						t.Fatal("grep_chunks must be invokable")
					}
					grepTool = inv
					break
				}
			}
			if grepTool == nil {
				t.Fatal("grep_chunks tool not found")
			}

			// Build args JSON: key is "pattern"
			args := map[string]string{"pattern": query}
			argsJSON, marshalErr := json.Marshal(args)
			if marshalErr != nil {
				t.Fatalf("json.Marshal failed: %v", marshalErr)
			}

			// Invoke
			out, invokeErr := grepTool.InvokableRun(context.Background(), string(argsJSON))

			if errored == "yes" {
				if invokeErr == nil {
					t.Errorf("expected error for query %q but got none (output: %s)", query, out)
				}
			} else {
				// errored == "no"
				if invokeErr != nil {
					t.Errorf("expected no error for query %q, got: %v", query, invokeErr)
				}
				if outMarker != "__skip__" {
					if !strings.Contains(out, outMarker) {
						t.Errorf("output %q should contain out_marker %q", out, outMarker)
					}
				}
			}
		})
	}
}
