package runtime_test

import (
	"context"
	"strings"
	"testing"

	"ragflow/internal/agent/smartreasoning"
)

func TestToolSuiteExposedValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			// Get required tool names from inputs
			requiredRaw := tc.Inputs["required"].([]interface{})
			required := make([]string, len(requiredRaw))
			for i, v := range requiredRaw {
				required[i] = v.(string)
			}

			legacyRaw := tc.Inputs["legacy"].([]interface{})
			legacy := make([]string, len(legacyRaw))
			for i, v := range legacyRaw {
				legacy[i] = v.(string)
			}

			// Build tool suite with a valid tenant id and empty datasets
			scope := smartreasoning.Scope{TenantID: "test-tenant", DatasetIDs: []string{}}
			suite, err := smartreasoning.BuildTools(scope, nil)
			if err != nil {
				t.Fatalf("BuildTools should succeed with a valid tenant id: %v", err)
			}

			tools := suite.AsList()

			// Compute tool_count
			toolCount := len(tools)

			// Compute missing_tool_count
			presentNames := make(map[string]bool)
			for _, tl := range tools {
				info, infoErr := tl.Info(context.Background())
				if infoErr != nil {
					t.Fatalf("Info() failed: %v", infoErr)
				}
				presentNames[info.Name] = true
			}
			missingToolCount := 0
			for _, name := range required {
				if !presentNames[name] {
					missingToolCount++
				}
			}

			// Get the system prompt
			prompt := smartreasoning.SystemPrompt

			// Compute legacy_in_prompt_count
			legacyInPromptCount := 0
			for _, name := range legacy {
				if strings.Contains(prompt, name) {
					legacyInPromptCount++
				}
			}

			// Compute placeholder_in_prompt_count: count of "{{" occurrences + "}}" occurrences
			placeholderInPromptCount := strings.Count(prompt, "{{") + strings.Count(prompt, "}}")

			// Compute nil_model_errors: call NewAgent with nil model and see if it errors or panics
			nilModelErrors := "no"
			func() {
				defer func() {
					if r := recover(); r != nil {
						nilModelErrors = "yes"
					}
				}()
				cfg := smartreasoning.Config{
					Model: nil,
					Scope: scope,
					Store: nil,
				}
				_, callErr := smartreasoning.NewAgent(context.Background(), cfg)
				if callErr != nil {
					nilModelErrors = "yes"
				}
			}()

			// Assertions
			expectedToolCount := int(tc.Expected["tool_count"].(float64))
			if toolCount != expectedToolCount {
				t.Errorf("tool_count: got %d, want %d", toolCount, expectedToolCount)
			}

			expectedMissingToolCount := int(tc.Expected["missing_tool_count"].(float64))
			if missingToolCount != expectedMissingToolCount {
				t.Errorf("missing_tool_count: got %d, want %d", missingToolCount, expectedMissingToolCount)
			}

			expectedLegacyInPromptCount := int(tc.Expected["legacy_in_prompt_count"].(float64))
			if legacyInPromptCount != expectedLegacyInPromptCount {
				t.Errorf("legacy_in_prompt_count: got %d, want %d", legacyInPromptCount, expectedLegacyInPromptCount)
			}

			expectedPlaceholderInPromptCount := int(tc.Expected["placeholder_in_prompt_count"].(float64))
			if placeholderInPromptCount != expectedPlaceholderInPromptCount {
				t.Errorf("placeholder_in_prompt_count: got %d, want %d", placeholderInPromptCount, expectedPlaceholderInPromptCount)
			}

			expectedNilModelErrors := tc.Expected["nil_model_errors"].(string)
			if nilModelErrors != expectedNilModelErrors {
				t.Errorf("nil_model_errors: got %q, want %q", nilModelErrors, expectedNilModelErrors)
			}
		})
	}
}
