"""Behavioral checks for cancellation in the prefect-dbt core API."""

from __future__ import annotations

import contextlib
import json
import os
import sys
import tempfile
import threading
import time
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

import pytest

from prefect import task
from prefect._internal.concurrency.cancellation import CancelledError
from prefect.settings import (
    PREFECT_API_SERVICES_TRIGGERS_ENABLED,
    temporary_settings,
)
from prefect.states import StateType
from prefect.testing.utilities import prefect_test_harness
from prefect_dbt.core._executor import DbtCoreExecutor
from prefect_dbt.core._tracker import NodeTaskTracker
from prefect_dbt.core.runner import FAILURE_STATUSES, PrefectDbtRunner
from prefect_dbt.core.settings import PrefectDbtSettings

from dbt_timeout_standin import QueuedDbtRunner


_VERIFY_DIR = Path(__file__).resolve().parent
_CONTROL_PATH = Path(tempfile.gettempdir()) / f"prefect-dbt-verify-{os.getpid()}.json"


@pytest.fixture(scope="session", autouse=True)
def _prefect_server():
    with temporary_settings({PREFECT_API_SERVICES_TRIGGERS_ENABLED: False}):
        with prefect_test_harness(server_startup_timeout=60):
            yield


@pytest.fixture
def mock_settings_context_manager():
    with patch.object(PrefectDbtSettings, "resolve_profiles_yml") as mock_cm:
        mock_cm.return_value.__enter__.return_value = "/profiles/dir"
        yield mock_cm


def _configure_standin(mode: str, work_dir: Path | None = None) -> None:
    control = {"mode": mode, "work_dir": str(work_dir or "")}
    _CONTROL_PATH.write_text(json.dumps(control))
    os.environ["VERIFY_DBT_CONTROL_PATH"] = str(_CONTROL_PATH)

    verify_dir = str(_VERIFY_DIR)
    current_pythonpath = os.environ.get("PYTHONPATH", "")
    entries = [entry for entry in current_pythonpath.split(os.pathsep) if entry]
    if verify_dir not in entries:
        os.environ["PYTHONPATH"] = os.pathsep.join([verify_dir, *entries])
    if verify_dir not in sys.path:
        sys.path.insert(0, verify_dir)


@contextlib.contextmanager
def _patched_runners():
    with (
        patch("prefect_dbt.core.runner.dbtRunner", QueuedDbtRunner),
        patch("prefect_dbt.core._executor.dbtRunner", QueuedDbtRunner),
    ):
        yield


def _make_executor(tmp_path: Path) -> tuple[DbtCoreExecutor, Path]:
    profiles_dir = tmp_path / "profiles"
    project_dir = tmp_path / "project"
    profiles_dir.mkdir()
    project_dir.mkdir()
    (profiles_dir / "profiles.yml").write_text("{}\n")
    (project_dir / "dbt_project.yml").write_text("{}\n")
    settings = PrefectDbtSettings(
        profiles_dir=profiles_dir,
        project_dir=project_dir,
        target_path=Path("target"),
    )
    return DbtCoreExecutor(settings, run_deps=False), profiles_dir


def _call_surface(
    surface: str,
    runner: PrefectDbtRunner,
    executor: DbtCoreExecutor,
    profiles_dir: Path,
):
    if surface == "runner":
        return runner.invoke(["run"])

    with executor.use_resolved_profiles_dir(str(profiles_dir)):
        if surface == "node":
            node = SimpleNamespace(unique_id="model.a", dbt_selector="model.a")
            return executor.execute_node(node, "run")
        if surface == "parse":
            return executor.resolve_manifest_path()
        if surface == "deps":
            return executor.run_deps()
    raise AssertionError(f"unknown surface: {surface}")


class _FakeConnectionManager:
    def __init__(self, adapter: "_FakeAdapter") -> None:
        self._adapter = adapter

    def cancel_open(self):
        self._adapter.cancel_open_connections()
        return []


class _FakeAdapter:
    def __init__(self, slot: int, work_dir: Path) -> None:
        self._slot = slot
        self._work_dir = work_dir
        self.connections = _FakeConnectionManager(self)

    def type(self):
        return f"fake-{self._slot}"

    def is_cancelable(self):
        return True

    @contextlib.contextmanager
    def connection_named(self, name, *args, **kwargs):
        yield

    def cancel_open_connections(self):
        current = self._work_dir / f"current-{self._slot}"
        if current.exists():
            job = current.read_text().strip()
            (self._work_dir / f"cancel-{self._slot}-{job}").touch()
        return []


def _heartbeat_snapshot(work_dir: Path) -> dict[str, str]:
    return {
        path.name: path.read_text()
        for path in sorted(work_dir.glob("heartbeat-*"))
    }


@pytest.mark.parametrize("surface", ["runner", "node", "parse", "deps"])
@pytest.mark.parametrize("wait_mode", ["blocking", "blocking_wait"])
def test_core_timeout_finishes_without_overlapping_work(
    surface, wait_mode, mock_settings_context_manager, tmp_path
):
    """A timed-out core operation finishes promptly with no surviving work."""
    from dbt.adapters.factory import FACTORY

    work_dir = tmp_path / "work"
    work_dir.mkdir()
    _configure_standin(wait_mode, work_dir)
    runner = PrefectDbtRunner()
    executor, profiles_dir = _make_executor(tmp_path)
    adapters = {
        "first": _FakeAdapter(0, work_dir),
        "second": _FakeAdapter(1, work_dir),
    }

    @task(timeout_seconds=6.0)
    def run_surface():
        return _call_surface(surface, runner, executor, profiles_dir)

    outcome: dict[str, object] = {}

    def invoke_task() -> None:
        try:
            outcome["state"] = run_surface(return_state=True)
        except BaseException as exc:
            outcome["error"] = exc

    worker = threading.Thread(target=invoke_task, daemon=True)
    started = time.monotonic()
    try:
        with (
            _patched_runners(),
            patch.object(runner, "_build_dbt_hook_selection_cache", return_value={}),
            patch.dict(FACTORY.adapters, adapters, clear=True),
        ):
            worker.start()
            worker.join(15)

        elapsed = time.monotonic() - started
        assert not worker.is_alive(), "timed-out operation did not reach a final state"
        assert "error" not in outcome, f"task execution raised: {outcome['error']!r}"
        state = outcome["state"]
        assert state.name == "TimedOut"
        assert state.type == StateType.FAILED
        assert elapsed < 15
        assert (work_dir / "started").exists(), "simulated dbt work never started"

        before = _heartbeat_snapshot(work_dir)
        assert len(before) >= 2, "not all simulated warehouse work started"
        time.sleep(0.3)
        assert _heartbeat_snapshot(work_dir) == before, (
            "dbt or warehouse work continued after the Prefect run finished"
        )
    finally:
        (work_dir / "shutdown").touch()
        worker.join(5)


@pytest.mark.parametrize("surface", ["runner", "node", "parse", "deps"])
def test_cancellation_remains_cancellation_across_core_surfaces(
    surface, mock_settings_context_manager, tmp_path
):
    """Cancellation remains cancellation on each core execution surface."""
    _configure_standin("returned_cancellation")
    runner = PrefectDbtRunner()
    executor, profiles_dir = _make_executor(tmp_path)

    with (
        _patched_runners(),
        patch.object(runner, "_build_dbt_hook_selection_cache", return_value={}),
    ):
        with pytest.raises(CancelledError):
            _call_surface(surface, runner, executor, profiles_dir)


def test_cancelled_run_finishes_all_node_tasks(
    mock_settings_context_manager, tmp_path
):
    """Every Prefect node task created for a cancelled run becomes terminal."""
    _configure_standin("returned_cancellation")
    tracker = NodeTaskTracker()
    node_ids = ["model.a", "model.b", "model.c"]
    waiters: list[threading.Thread] = []
    finished = {node_id: threading.Event() for node_id in node_ids}

    for node_id in node_ids:
        tracker.start_task(node_id, Mock())

        def wait(current=node_id):
            tracker.wait_for_node_completion(current)
            finished[current].set()

        waiter = threading.Thread(target=wait, daemon=True)
        waiter.start()
        waiters.append(waiter)

    runner = PrefectDbtRunner()
    try:
        with (
            _patched_runners(),
            patch.object(runner, "_build_dbt_hook_selection_cache", return_value={}),
            patch("prefect_dbt.core.runner.NodeTaskTracker", return_value=tracker),
        ):
            with pytest.raises(CancelledError):
                runner.invoke(["run"])

        for node_id in node_ids:
            assert finished[node_id].wait(2), f"{node_id} did not reach a final state"
            status = tracker.get_node_status(node_id)
            assert status is not None
            node_status = status["event_data"]["node_info"]["node_status"]
            assert node_status in FAILURE_STATUSES
    finally:
        for node_id in node_ids:
            tracker.set_node_status(
                node_id,
                {"node_info": {"node_status": "error"}},
                "verify cleanup",
            )
        for waiter in waiters:
            waiter.join(5)


def test_successful_run_returns_success(
    mock_settings_context_manager, tmp_path
):
    _configure_standin("success")
    runner = PrefectDbtRunner()
    with (
        _patched_runners(),
        patch.object(runner, "_build_dbt_hook_selection_cache", return_value={}),
    ):
        result = runner.invoke(["run"])
    assert result.success is True
    assert result.exception is None


def test_ordinary_failure_keeps_existing_error(
    mock_settings_context_manager, tmp_path
):
    _configure_standin("ordinary_failure")
    runner = PrefectDbtRunner()
    with (
        _patched_runners(),
        patch.object(runner, "_build_dbt_hook_selection_cache", return_value={}),
    ):
        with pytest.raises(ValueError) as raised:
            runner.invoke(["run"])
    assert "run" in str(raised.value)
