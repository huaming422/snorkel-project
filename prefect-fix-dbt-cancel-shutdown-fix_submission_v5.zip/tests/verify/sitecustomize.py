"""Make the verifier stand-in available to spawned Python workers."""

import os

if os.getenv("VERIFY_DBT_CONTROL_PATH"):
    try:
        import dbt.cli.main

        from dbt_timeout_standin import QueuedDbtRunner

        dbt.cli.main.dbtRunner = QueuedDbtRunner
    except ImportError:
        pass
