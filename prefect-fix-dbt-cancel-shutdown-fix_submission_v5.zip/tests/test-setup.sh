#!/usr/bin/env bash
# test-setup.sh — runs once before the verifier (sourced, not exec'd).
# The dependency closure for the prefect-dbt integration (editable install with
# `.[all_extras]`, pytest stack, respx, fastapi, build backends) is already baked
# into the integration's `.venv` in the image, so this is an offline no-op in the
# task and verifier phases. The integration tests use the ephemeral in-process Prefect
# test harness (SQLite) — no standalone server, credentials, or network access.
set -euo pipefail

REPO_DIR=/repo/prefect
INTEGRATION_DIR="${REPO_DIR}/src/integrations/prefect-dbt"

# Force uv to stay offline: the task runtime is no-network, and the baked cache +
# .venv already satisfy every import the focused tests need. Set it HERE, never as
# an image ENV (an image-wide UV_OFFLINE breaks harbor's `uv tool install` during
# trial prep).
export UV_OFFLINE=1
export UV_CACHE_DIR=/opt/uv-cache

cd "$INTEGRATION_DIR"

# The integration's `.venv` is baked in the image with the full offline dependency
# closure (editable `.[all_extras]` + the `dev` group's test runner + fastapi). The
# install is EDITABLE, so working-tree source changes are already reflected without
# a reinstall. Fail loudly if the baked environment is unavailable.
if [ ! -d .venv ]; then
    echo "[test-setup] FATAL: baked integration .venv is missing at ${INTEGRATION_DIR}/.venv" >&2
    return 1 2>/dev/null || exit 1
fi

# Smoke-import the public integration and required runtime dependencies.
.venv/bin/python - <<'PY'
import prefect
import prefect_dbt
from prefect._internal.concurrency.cancellation import CancelledError  # noqa: F401
from dbt.adapters.factory import FACTORY  # noqa: F401
from dbt.cli.main import dbtRunner  # noqa: F401
print("prefect-dbt env OK")
PY

export REPO_NAME=prefect
