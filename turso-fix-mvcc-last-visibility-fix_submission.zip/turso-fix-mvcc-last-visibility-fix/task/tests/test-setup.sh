#!/usr/bin/env bash
# test-setup.sh — sourced by tests/test.sh before the verifier runs (inherits
# set -euo pipefail). Brings the baked Rust build caches online and pre-warms
# the compile the verifier needs so it doesn't pay a cold cargo build inside
# its own time budget. No services to start, no assertion logic here.
set -euo pipefail

cd /repo/turso

# The image baked `cargo fetch` + a base-commit workspace build into
# /opt/cache. Grade time runs with the network cut, so force cargo offline so a
# cache miss fails fast instead of reaching crates.io.
export CARGO_NET_OFFLINE=true
export CARGO_INCREMENTAL=1

# rust-toolchain.toml at the repo root pins channel = "1.88.0"; the image
# materialized it, so cargo uses it without a download.

# Pre-warm the compiles the verifier may use. Both are incremental no-ops if
# the agent already built in this container.
#  - turso_core test binaries: for a native Rust verifier (cargo test).
#  - the tursodb CLI (release): for a subprocess/CLI-driven verifier.
# Offline-first: the image bake satisfies these with the network cut; the
# `|| ...` online fallback is logged and only fires if the bake was stale.
if cargo test --no-run -p turso_core --locked > /tmp/test-setup-core.log 2>&1; then
    echo "[offline-first] turso_core test build satisfied from image cache"
else
    echo "[test-setup] turso_core test build needed network (image bake stale)" >&2
    cargo test --no-run -p turso_core >> /tmp/test-setup-core.log 2>&1 \
        || { tail -80 /tmp/test-setup-core.log >&2; exit 1; }
fi

if cargo build -p turso_cli --release --locked > /tmp/test-setup-cli.log 2>&1; then
    echo "[offline-first] tursodb CLI build satisfied from image cache"
else
    echo "[test-setup] tursodb CLI build needed network (image bake stale)" >&2
    cargo build -p turso_cli --release >> /tmp/test-setup-cli.log 2>&1 \
        || { tail -80 /tmp/test-setup-cli.log >&2; exit 1; }
fi

ls -la "${CARGO_TARGET_DIR:-target}/release/tursodb" 2>/dev/null || true
