# Behavioral verifier for turso-fix-mvcc-last-visibility.
#
# ROUTE B (CLI subprocess, black-box). The bug is a backward-cursor visibility
# defect in turso's experimental MVCC backend: after a row is checkpointed to
# the main db file, the database is reopened, and the row is deleted, a
# reverse-order scan (`ORDER BY <pk> DESC`) still returns the deleted row.
#
# We drive the pre-existing, stable SQL surface through the `tursodb` CLI
# (the `turso_cli` crate's binary), exactly as the repo's own MVCC CLI tests
# do (`testing/cli_tests/test_turso_cli.py` + `.../mvcc.py`). This is fully
# black-box: no fix-introduced symbol, no source file path, no internal API is
# referenced. Reopen is modelled the only honest way for a file-backed MVCC
# db — a FRESH PROCESS on the same db file. Process isolation guarantees a
# genuine reopen (empty DATABASE_MANAGER registry, fresh MvStore that must
# read from the on-disk BTree), which is precisely what makes the defect
# observable. This mirrors the maintainers' native test
# `test_cursor_with_btree_and_mvcc_delete_after_checkpoint` (db.restart() +
# db.connect()) without touching any private `pub(crate)` helper.
#
# Runner: the shared pytest runner (VERIFIER_PYTHON) collects `test_*`
# functions here. This file uses only the Python stdlib + pytest, imports no
# repository code, so no `[pytest] command` override is needed in verify.toml.
#
# -------------------------------------------------------------------------
# Constant provenance (REWARDS.md §"Constant provenance") — every literal
# this harness hardcodes is a STABLE FACT, never a solution choice:
#   `--experimental-mvcc`  : pre-existing CLI flag (cli/app.rs Opts), the only
#                            way to opt into the MVCC backend. Repo-owned.
#   `-q`, `-m list`        : pre-existing CLI flags; list mode emits
#                            `|`-separated, header-less rows (cli/app.rs
#                            OutputMode::List). Repo-owned output contract.
#   `PRAGMA wal_checkpoint(TRUNCATE)` : standard SQLite/turso pragma; flushes
#                            WAL into the main db file. Stable fact.
#   `INTEGER PRIMARY KEY`  : SQLite rowid alias; auto-rowid on insert. Stable.
#   Row-id sets {1,2,3,...}, surviving-row sets, rowid monotonicity : derived
#                            purely from the SQL I issue — stable facts about
#                            the scenario, independent of how the fix is coded.
#   tursodb binary location: discovered from the environment
#                            (CARGO_TARGET_DIR / REPO_NAME), never a pinned
#                            implementation path. Repo-owned build output.
# No solution-choice constant is hardcoded; the verifier asserts observable
# SQL behavior only (ASC/DESC result sets, rowid uniqueness/monotonicity),
# never a symbol, helper name, control-flow shape, or file the fix introduces.
# -------------------------------------------------------------------------

import os
import subprocess
import tempfile
from pathlib import Path

import pytest

# Hard per-subprocess ceiling. Each tursodb invocation runs a handful of
# statements against a tiny db and is sub-second on the prebuilt release
# binary; 60s is pure safety margin so a hang fails fast instead of eating
# the whole pytest budget.
_PROC_TIMEOUT = 60


def _find_tursodb() -> str:
    """Locate the prebuilt `tursodb` CLI binary without pinning a path.

    test-setup.sh builds `turso_cli --release` into CARGO_TARGET_DIR. We try
    the environment-advertised locations in order and fail loudly (not
    silently skip) if none exists, so a build/setup problem surfaces as an
    infra error rather than a bogus pass.
    """
    override = os.environ.get("TURSODB_BIN")
    if override and Path(override).is_file():
        return override

    candidates = []
    cargo_target = os.environ.get("CARGO_TARGET_DIR")
    if cargo_target:
        candidates.append(Path(cargo_target) / "release" / "tursodb")
    repo = Path("/repo") / os.environ.get("REPO_NAME", "turso")
    candidates.append(repo / "target" / "release" / "tursodb")
    candidates.append(Path("/opt/cache/cargo-target/release/tursodb"))

    for c in candidates:
        if c.is_file():
            return str(c)
    raise AssertionError(
        "tursodb CLI binary not found; looked in: "
        + ", ".join(str(c) for c in candidates)
        + " (test-setup.sh should have built turso_cli --release)"
    )


_BIN_CACHE: list[str] = []


def _bin() -> str:
    """Resolve (and cache) the tursodb binary lazily, so pytest collection
    never fails at import — a missing binary surfaces as a loud per-test error
    instead of a collection crash that is harder to attribute."""
    if not _BIN_CACHE:
        _BIN_CACHE.append(_find_tursodb())
    return _BIN_CACHE[0]


def _run(db_path: Path, sql: str, *, mvcc: bool) -> str:
    """Run one tursodb process over `db_path`, feeding `sql` on stdin.

    Returns cleaned stdout (stripped, blank lines dropped). Fails loudly on a
    non-zero exit, an engine `Error:` line, or anything on stderr that is not
    a benign tracing/log line, so a crash can never be mistaken for an empty
    result set.
    """
    flags = ["-q", "-m", "list"]
    if mvcc:
        flags.append("--experimental-mvcc")
    proc = subprocess.run(
        [_bin(), str(db_path), *flags],
        input=sql.encode(),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=_PROC_TIMEOUT,
        check=False,
    )
    stdout = proc.stdout.decode()
    stderr = proc.stderr.decode()

    if proc.returncode != 0:
        raise AssertionError(
            f"tursodb exited {proc.returncode}\nSQL:\n{sql}\n"
            f"STDOUT:\n{stdout}\nSTDERR:\n{stderr}"
        )
    # The engine prints `Error: ...` on a failed statement; treat as a hard
    # failure rather than parsing it as data.
    if "Error:" in stdout or "Error:" in stderr:
        raise AssertionError(
            f"tursodb reported an error\nSQL:\n{sql}\n"
            f"STDOUT:\n{stdout}\nSTDERR:\n{stderr}"
        )
    return stdout


def _section(stdout: str, name: str) -> list[str]:
    """Extract the rows emitted between sentinel markers `@name@` / `@/name@`.

    Each scenario brackets the SELECT it cares about with
    `SELECT '@name@';` ... `SELECT '@/name@';`, so non-row statements
    (CREATE/INSERT/DELETE/PRAGMA) and any incidental output never leak into
    the parsed result set.
    """
    open_m, close_m = f"@{name}@", f"@/{name}@"
    rows: list[str] = []
    capturing = False
    for raw in stdout.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line == open_m:
            capturing = True
            continue
        if line == close_m:
            capturing = False
            continue
        if capturing:
            rows.append(line)
    return rows


def _mark(name: str, select_sql: str) -> str:
    return f"SELECT '@{name}@';\n{select_sql}\nSELECT '@/{name}@';\n"


@pytest.fixture()
def db_path():
    with tempfile.TemporaryDirectory() as d:
        # A path that does NOT yet exist; tursodb creates the db on first open.
        yield Path(d) / "t.db"


# --------------------------------------------------------------------------
# Criterion 1 (fail_to_pass, basic): reverse-order scan does not resurrect a
# row deleted after checkpoint + reopen. This is exactly
# test_cursor_with_btree_and_mvcc_delete_after_checkpoint, driven over SQL.
# --------------------------------------------------------------------------
def test_mvcc_delete_desc_no_phantom(db_path):
    # Process 1: create, insert, flush to the main db file, close cleanly.
    _run(
        db_path,
        "CREATE TABLE t (x INTEGER PRIMARY KEY);\n"
        "INSERT INTO t VALUES (1);\n"
        "PRAGMA wal_checkpoint(TRUNCATE);\n",
        mvcc=True,
    )
    # Process 2 == genuine reopen (fresh process, empty MVCC store reading the
    # row back from the BTree). Delete the row, then scan backwards.
    out = _run(
        db_path,
        "DELETE FROM t WHERE x = 1;\n"
        + _mark("desc", "SELECT x FROM t ORDER BY x DESC;")
        + _mark("asc", "SELECT x FROM t ORDER BY x ASC;"),
        mvcc=True,
    )
    desc = _section(out, "desc")
    asc = _section(out, "asc")
    # Pre-fix: DESC resurrects the deleted row (desc == ["1"]). Post-fix: empty.
    assert desc == [], f"reverse-order scan returned a deleted row: {desc!r}"
    # Forward scan was always correct — assert it too, so a fix that breaks
    # ASC to "balance" DESC cannot sneak through.
    assert asc == [], f"forward scan returned a deleted row: {asc!r}"


# --------------------------------------------------------------------------
# Criterion 2 (fail_to_pass): ASC and DESC agree with the live set across a
# richer interleaving of insert/delete/checkpoint/reopen — catches fixes that
# special-case the single-row repro but still miscount a multi-row backward
# scan (the spirit of test_cursor_with_btree_and_mvcc_fuzz).
# --------------------------------------------------------------------------
def test_mvcc_scans_agree_with_live_set(db_path):
    # Process 1: seed five rows, checkpoint to the main file, close.
    _run(
        db_path,
        "CREATE TABLE t (x INTEGER PRIMARY KEY);\n"
        "INSERT INTO t VALUES (1), (2), (3), (4), (5);\n"
        "PRAGMA wal_checkpoint(TRUNCATE);\n",
        mvcc=True,
    )
    # Process 2 (reopen): delete two interior rows, add two more, then compare
    # both orderings against the surviving set {1, 3, 5, 6, 7}.
    out = _run(
        db_path,
        "DELETE FROM t WHERE x = 2;\n"
        "DELETE FROM t WHERE x = 4;\n"
        "INSERT INTO t VALUES (6), (7);\n"
        + _mark("asc", "SELECT x FROM t ORDER BY x ASC;")
        + _mark("desc", "SELECT x FROM t ORDER BY x DESC;"),
        mvcc=True,
    )
    live_sorted = ["1", "3", "5", "6", "7"]
    asc = _section(out, "asc")
    desc = _section(out, "desc")
    assert asc == live_sorted, f"ASC scan disagrees with live set: {asc!r}"
    assert desc == list(reversed(live_sorted)), (
        f"DESC scan disagrees with live set: {desc!r}"
    )


# --------------------------------------------------------------------------
# Criterion 3 (pass_to_pass): rowid allocation stays collision-free. Deleting
# the current max rowid and then auto-inserting must NOT reuse that rowid —
# allocation accounts for every physically-present row regardless of
# visibility. Passes pre-fix AND the correct fix (both see physical max 3 ->
# new rowid 4); FAILS the naive over-fix that makes the shared last-rowid
# lookup visibility-aware for allocation too (it would reuse rowid 3).
# --------------------------------------------------------------------------
def test_rowid_allocation_collision_free(db_path):
    # Single MVCC session: the deleted row's version is still physically in
    # the in-memory MVCC index, so a correct allocator sees max rowid 3.
    out = _run(
        db_path,
        "CREATE TABLE t (id INTEGER PRIMARY KEY, v TEXT);\n"
        "INSERT INTO t (v) VALUES ('a'), ('b'), ('c');\n"  # rowids 1,2,3
        "DELETE FROM t WHERE id = 3;\n"                      # drop the max
        "INSERT INTO t (v) VALUES ('d');\n"                  # must get 4, not 3
        + _mark("ids", "SELECT id FROM t ORDER BY id ASC;"),
        mvcc=True,
    )
    ids = _section(out, "ids")
    # Live rows are 1, 2, and the newly inserted one. The new rowid must be
    # strictly beyond the previous max (4), never the recycled 3.
    assert ids == ["1", "2", "4"], (
        f"rowid allocation reused a deleted/below-max rowid: {ids!r}"
    )


# --------------------------------------------------------------------------
# Criterion 4 (pass_to_pass, basic): the default (non-MVCC) BTree path is
# unaffected — same checkpoint/reopen/delete sequence, no --experimental-mvcc,
# returns correct forward and backward results. Guards a fix that reaches
# outside the MVCC module and perturbs the shared cursor/BTree behavior.
# --------------------------------------------------------------------------
def test_non_mvcc_path_unaffected(db_path):
    _run(
        db_path,
        "CREATE TABLE t (x INTEGER PRIMARY KEY);\n"
        "INSERT INTO t VALUES (1), (2), (3);\n"
        "PRAGMA wal_checkpoint(TRUNCATE);\n",
        mvcc=False,
    )
    out = _run(
        db_path,
        "DELETE FROM t WHERE x = 2;\n"
        + _mark("asc", "SELECT x FROM t ORDER BY x ASC;")
        + _mark("desc", "SELECT x FROM t ORDER BY x DESC;"),
        mvcc=False,
    )
    asc = _section(out, "asc")
    desc = _section(out, "desc")
    assert asc == ["1", "3"], f"non-MVCC ASC scan wrong: {asc!r}"
    assert desc == ["3", "1"], f"non-MVCC DESC scan wrong: {desc!r}"
