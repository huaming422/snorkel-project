## Task

A Playwright script of ours gets stuck filling an ordinary text input that is plainly on screen. If I give that input a fixed pixel width instead of width: 100%, the same script goes through fine. Here is what I see on the default 1280x720 page:

```
page.fill on the input -> the log keeps saying the element got detached from the DOM and retries until the fill times out
div { width: 50% }, getComputedStyle(div).width -> -32000 "A non null render device with a font size is required to calculate em or rem units." (I'd expect 640px, and 195px after setViewportSize to 390x844)
@media (min-width: 800px) { div { position: absolute } } -> position reads static, though matchMedia('(min-width: 800px)').matches is true
```

Can you find the cause in the headless browser and fix it? Keep to the engine code and leave the tests and package versions alone.
