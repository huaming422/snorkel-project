#!/usr/bin/env bash
# test-setup.sh — verifier-phase environment bootstrap for
# jint-fix-cascade-render-device.
#
# Sourced (not exec'd) by the harbor runner so the env vars set here stay live
# for the verifier subprocess (verify.py → `dotnet test`).
#
# Everything the grade needs is BAKED into the image at build time (image/
# Dockerfile): the .NET SDK 10.0.100, the full NuGet closure for
# Jint.Tests.Browser at the base commit (warm under /root/.nuget/packages),
# and a Release build of the browser test project. The oracle introduces NO
# new NuGet packages (it uses existing AngleSharp / AngleSharp.Css APIs), so
# the base-commit restore closure already covers the reference solution.
#
# The verifier phase has only the model-gateway on the network (agent_offline
# task), so this script MUST NOT reach a package feed. The grade runs
# `dotnet test` against the warm cache; we only pin it to offline behaviour
# and fail loudly if the baked prerequisites are somehow absent.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/jint}"
export REPO_DIR

# Keep NuGet/.NET entirely offline and quiet: the cache is warm, so no restore
# should ever touch the network. If one tries to, fail here rather than hang.
export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1
export DOTNET_ROOT="${DOTNET_ROOT:-/usr/share/dotnet}"
export NUGET_PACKAGES="${NUGET_PACKAGES:-/root/.nuget/packages}"
# Do not let the SDK phone home for a newer version or workload manifests.
export DOTNET_CLI_WORKLOAD_UPDATE_NOTIFY_DISABLE=1
# The grade never restores from a feed: verify.py runs `dotnet test --no-restore`
# against the warm cache the image baked, so a cache miss fails loudly in the
# smoke gate's offline fold (`docker run --network none`) rather than hanging on
# a registry. Nothing here reaches the network.

# Bound NUnit's worker pool so peak memory tracks the task's declared cpus (4)
# rather than the host's visible core count. verify.sh passes this through to
# the NUnit adapter; exporting it here keeps a direct `dotnet test` honest too.
export NUNIT_NUMBER_OF_TEST_WORKERS=4

# --- Baked-prerequisite sanity checks (loud failure, no network) -----------
if ! command -v dotnet >/dev/null 2>&1; then
    echo "[test-setup] FATAL: dotnet SDK not on PATH — image build is corrupt" >&2
    exit 1
fi

if [ ! -d "$NUGET_PACKAGES/nunit" ] && [ ! -d "$NUGET_PACKAGES/anglesharp.css" ]; then
    echo "[test-setup] FATAL: warm NuGet cache missing at $NUGET_PACKAGES" >&2
    echo "[test-setup] the image must bake 'dotnet restore Jint.Tests.Browser' at build time" >&2
    exit 1
fi

if [ ! -d "$REPO_DIR/Jint.Tests.Browser" ]; then
    echo "[test-setup] FATAL: $REPO_DIR/Jint.Tests.Browser not found" >&2
    exit 1
fi

echo "[test-setup] jint-fix-cascade-render-device: baked image, offline-ready (no network needed)"
