using System.Text.Json;
using Jint.Browser;
using Jint.Tests.Browser.DevTools;

namespace Jint.Tests.Browser.Verifiers;

// Alias so the bare name binds to the type rather than the enclosing namespace.
using BrowserEngine = global::Jint.Browser.Browser;

/// <summary>
/// Relative CSS lengths on a page, checked through the page-script surface (<c>getComputedStyle</c>,
/// <c>getBoundingClientRect</c>, <c>matchMedia</c>) and the DevTools Emulation domain. Each test asserts what a page can observe.
/// </summary>
/// <remarks>
/// One behavior per method. The method names are the keys the Python driver maps back to pass/fail.
/// </remarks>
[NonParallelizable]
public sealed class CascadeRenderDeviceVerify
{
    // The page a SetContentAsync produces is html > head, body > …, head is not rendered, and the row height
    // is a fixed 16px, so a rendered element's box is arithmetic on tree order. Mirrors the layout suite.
    private const int Row = 16;

    private static async Task<string> Read(Page page, string property)
        => await page.EvaluateAsync<string>(
            "getComputedStyle(document.getElementById('t')).getPropertyValue('" + property + "')")
           ?? "";

    private static async Task<string> Rect(Page page, string expression)
        => await page.EvaluateAsync<string>(
            $"(() => {{ const r = ({expression}).getBoundingClientRect(); return [r.x, r.y, r.width, r.height].join(','); }})()")
           ?? "";

    /// <summary>
    /// relative_length_resolves: every relative length resolves against the page viewport for the six
    /// properties an author writes them on.
    /// </summary>
    [Test]
    public async Task relative_length_resolves()
    {
        await using var browser = new BrowserEngine();
        var page = await browser.NewPageAsync();

        // The page's own viewport is 1280x720 with a 16px root font size.
        (string Value, string Expected)[] lengths =
        [
            ("2em", "32px"),
            ("2rem", "32px"),
            ("10vw", "128px"),
            ("10vh", "72px"),
        ];

        // Percentages on these properties are taken from the containing block's width.
        (string Value, string Expected)[] widthRelative =
        [
            ("100%", "1280px"),
            ("50%", "640px"),
            ("calc(100% - 10px)", "1270px"),
        ];

        foreach (var property in new[] { "width", "height", "min-width", "margin-left", "padding-left", "font-size" })
        {
            var horizontal = property is not ("height" or "font-size");
            foreach (var (value, expected) in horizontal ? lengths.Concat(widthRelative) : lengths)
            {
                await page.SetContentAsync($"<style>#t {{ {property}: {value} }}</style><div id='t'>g</div>");

                (await Read(page, property))
                    .Should().Be(expected, "{0}: {1} resolves against the viewport", property, value);
            }
        }

        page.Errors.Should().BeEmpty();
    }

    /// <summary>
    /// box_query_survives_relative_length: a box query on a page carrying a <c>width: 100%</c> rule returns
    /// a real rect and does not throw; a sibling <c>display: none</c> element has no box.
    /// </summary>
    [Test]
    public async Task box_query_survives_relative_length()
    {
        await using var browser = new BrowserEngine();
        var page = await browser.NewPageAsync();

        await page.SetContentAsync(
            """
            <style>
              .form-control { width: 100%; display: block }
              #hidden { display: none }
            </style>
            <input id="SiteName" class="form-control" type="text">
            <div id="hidden">gone</div>
            """);

        // html, body, input: the input is the third rendered element; the hidden div is not one.
        (await Rect(page, "document.getElementById('SiteName')"))
            .Should().Be($"0,{2 * Row},1280,{Row}");
        (await Rect(page, "document.getElementById('hidden')"))
            .Should().Be("0,0,0,0", "display: none takes the box away");

        (await page.EvaluateAsync<string>("getComputedStyle(document.getElementById('SiteName')).width"))
            .Should().Be("1280px", "the declared 100% resolves against the viewport");

        page.Errors.Should().BeEmpty();
    }

    /// <summary>
    /// media_rule_agrees_with_matchmedia: a style-sheet <c>@media</c> dimension query and
    /// <c>matchMedia</c> read the same viewport and agree, across two viewport widths.
    /// </summary>
    [TestCase(1280, "absolute")]
    [TestCase(400, "relative")]
    public async Task media_rule_agrees_with_matchmedia(int width, string expected)
    {
        await using var browser = new BrowserEngine(new BrowserOptions { Viewport = new Viewport(width, 720) });
        var page = await browser.NewPageAsync();

        await page.SetContentAsync(
            """
            <style>
              #t { position: relative }
              @media (min-width: 600px) { #t { position: absolute } }
            </style>
            <div id="t">g</div>
            """);

        (await Read(page, "position")).Should().Be(expected);

        (await page.EvaluateAsync<bool>("matchMedia('(min-width: 600px)').matches"))
            .Should().Be(expected == "absolute", "the page's own matchMedia reads the same viewport");

        page.Errors.Should().BeEmpty();
    }

    /// <summary>
    /// emulation_moves_cascade: <c>Emulation.setDeviceMetricsOverride</c> moves what the cascade computes
    /// AND what <c>matchMedia</c> answers, on the same already-built document, through the DevTools domain.
    /// </summary>
    [Test]
    public async Task emulation_moves_cascade()
    {
        await using var session = await PageSession.CreateAsync();
        var attachment = await session.OpenPageAsync();

        await SetContentAsync(
            session,
            attachment,
            """
            <style>
              #t { width: 50%; position: relative }
              @media (max-width: 600px) { #t { position: absolute } }
            </style>
            <div id="t">g</div>
            """);

        const string width = "getComputedStyle(document.getElementById('t')).width";
        const string position = "getComputedStyle(document.getElementById('t')).position";

        (await Text(session, attachment, width)).Should().Be("640px", "half of the 1280px the page opened with");
        (await Text(session, attachment, position)).Should().Be("relative");
        (await Flag(session, attachment, "matchMedia('(max-width: 600px)').matches")).Should().BeFalse();

        await session.ResultAsync(
            "Emulation.setDeviceMetricsOverride",
            """{"width":390,"height":844,"deviceScaleFactor":3,"mobile":true}""",
            attachment);

        (await Text(session, attachment, width)).Should().Be("195px", "the same document, against the emulated viewport");
        (await Text(session, attachment, position)).Should().Be("absolute", "the @media rule is active now");
        (await Flag(session, attachment, "matchMedia('(max-width: 600px)').matches")).Should().BeTrue();
    }

    // ── DevTools helpers (copied shape from EmulationDomainTests) ───────────────────────────────────────
    private static async Task SetContentAsync(PageSession session, string attachment, string html)
    {
        var payload = JsonSerializer.Serialize(new Dictionary<string, string>
        {
            ["frameId"] = await FrameAsync(session, attachment).ConfigureAwait(false),
            ["html"] = html,
        });

        await session.ResultAsync("Page.setDocumentContent", payload, attachment).ConfigureAwait(false);
    }

    private static async Task<string> FrameAsync(PageSession session, string attachment)
    {
        var tree = await session.ResultAsync("Page.getFrameTree", null, attachment).ConfigureAwait(false);
        return tree.GetProperty("frameTree").GetProperty("frame").GetProperty("id").GetString()!;
    }

    private static async Task<bool> Flag(PageSession session, string attachment, string expression)
        => (await session.EvaluateAsync(expression, attachment)).GetProperty("value").GetBoolean();

    private static async Task<string> Text(PageSession session, string attachment, string expression)
        => (await session.EvaluateAsync(expression, attachment)).GetProperty("value").GetString()!;
}
