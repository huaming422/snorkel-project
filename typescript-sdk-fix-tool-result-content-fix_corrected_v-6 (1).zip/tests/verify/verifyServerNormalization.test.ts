// @ts-nocheck
//
// Server-side tools/call handler results. A real Server (or McpServer) is
// driven over an in-memory transport through initialize, initialized and one
// tools/call, the way the repo's server tests do, and only the wire response
// is asserted.

import { describe, expect, it } from 'vitest';

import type { CallToolResult, JSONRPCMessage } from '@modelcontextprotocol/core-internal';
import { InMemoryTransport, LATEST_PROTOCOL_VERSION } from '@modelcontextprotocol/core-internal';
import * as z from 'zod/v4';

import { McpServer } from '../../src/index';
import { Server } from '../../src/server/server';

type Connectable = { connect(transport: unknown): Promise<void>; close(): Promise<void> };

// Runs initialize, notifications/initialized and tools/call (id 2) against
// `server` and returns the id-2 response.
async function callToolThrough(server: Connectable): Promise<JSONRPCMessage> {
    const [clientTransport, serverTransport] = InMemoryTransport.createLinkedPair();
    const received: JSONRPCMessage[] = [];
    clientTransport.onmessage = message => void received.push(message);
    await server.connect(serverTransport);
    await clientTransport.start();

    await clientTransport.send({
        jsonrpc: '2.0',
        id: 1,
        method: 'initialize',
        params: {
            protocolVersion: LATEST_PROTOCOL_VERSION,
            capabilities: {},
            clientInfo: { name: 'test-client', version: '1.0.0' }
        }
    });
    await clientTransport.send({ jsonrpc: '2.0', method: 'notifications/initialized' });
    await clientTransport.send({ jsonrpc: '2.0', id: 2, method: 'tools/call', params: { name: 'echo', arguments: {} } });
    await new Promise(resolve => setTimeout(resolve, 10));
    await server.close();

    const response = received.find(message => (message as { id?: unknown }).id === 2);
    if (!response) {
        throw new Error('no tools/call response received');
    }
    return response;
}

// A low-level Server whose tools/call handler returns `result`.
async function callToolOnServer(result: unknown): Promise<JSONRPCMessage> {
    const server = new Server({ name: 'test', version: '1.0.0' }, { capabilities: { tools: {} } });
    server.setRequestHandler('tools/call', () => result as CallToolResult);
    return callToolThrough(server);
}

// An McpServer with one registered tool `echo` (output schema { ok: boolean })
// whose callback returns `result`.
async function callToolOnMcpServer(result: unknown): Promise<JSONRPCMessage> {
    const server = new McpServer({ name: 'test', version: '1.0.0' });
    server.registerTool('echo', { outputSchema: { ok: z.boolean() } }, async () => result as CallToolResult);
    return callToolThrough(server);
}

// Handler results without content, each with the fields the wire must keep.
const CONTENTLESS_RESULTS: Array<[string, Record<string, unknown>]> = [
    ['empty', {}],
    ['isError only', { isError: true }],
    ['structuredContent + isError + _meta', { structuredContent: { ok: false }, isError: true, _meta: { trace: 'abc' } }]
];

describe('typescript-sdk-fix-tool-result-content :: server handler normalization', () => {
    it('[server_normalizes_plain] a structured-only handler result reaches the wire with a content array', async () => {
        const response = await callToolOnServer({ structuredContent: { ok: true } });
        const result = (response as { result?: { content?: unknown; structuredContent?: unknown } }).result;
        expect(result, `expected a result, got ${JSON.stringify(response)}`).toBeDefined();
        expect(Array.isArray(result!.content), `content must be an array, got ${JSON.stringify(result!.content)}`).toBe(true);
        expect(result!.structuredContent).toEqual({ ok: true });
    });

    it('[server_normalizes_plain] an authored-content handler result passes through unchanged', async () => {
        const response = await callToolOnServer({
            content: [{ type: 'text', text: 'hi' }],
            structuredContent: { ok: true }
        });
        const result = (response as { result?: { content?: unknown; structuredContent?: unknown } }).result;
        expect(result, `expected a result, got ${JSON.stringify(response)}`).toBeDefined();
        expect(result!.content).toEqual([{ type: 'text', text: 'hi' }]);
        expect(result!.structuredContent).toEqual({ ok: true });
    });

    it('[server_normalizes_plain] an McpServer tool returning only structuredContent reaches the wire with a content array', async () => {
        const response = await callToolOnMcpServer({ structuredContent: { ok: true } });
        const result = (response as { result?: { content?: unknown; structuredContent?: unknown } }).result;
        expect(result, `expected a result, got ${JSON.stringify(response)}`).toBeDefined();
        expect(Array.isArray(result!.content), `content must be an array, got ${JSON.stringify(result!.content)}`).toBe(true);
        expect(result!.structuredContent).toEqual({ ok: true });
    });

    it('[server_rejects_nonplain] an array handler result is rejected with -32602', async () => {
        const response = await callToolOnServer([{ type: 'text', text: 'hi' }]);
        const error = (response as { error?: { code: number } }).error;
        expect(error, `expected an error, got ${JSON.stringify(response)}`).toBeDefined();
        expect(error!.code).toBe(-32602);
    });

    it('[server_rejects_nonplain] a task body with an explicit content: undefined is rejected with -32602', async () => {
        const response = await callToolOnServer({ task: { taskId: 't-1', status: 'working' }, content: undefined });
        const error = (response as { error?: { code: number } }).error;
        expect(error, `expected an error, got ${JSON.stringify(response)}`).toBeDefined();
        expect(error!.code).toBe(-32602);
    });

    it('[server_rejects_nonplain] an input-required handler body is rejected with -32602', async () => {
        const response = await callToolOnServer({ inputRequests: { r1: { method: 'elicitation/create' } } });
        const error = (response as { error?: { code: number } }).error;
        expect(error, `expected an error, got ${JSON.stringify(response)}`).toBeDefined();
        expect(error!.code).toBe(-32602);
    });

    it('[server_rejects_nonplain] a task body that also carries structuredContent is rejected with -32602', async () => {
        const response = await callToolOnServer({ task: { taskId: 't-1', status: 'working' }, structuredContent: { ok: true } });
        const error = (response as { error?: { code: number } }).error;
        expect(error, `expected an error, got ${JSON.stringify(response)}`).toBeDefined();
        expect(error!.code).toBe(-32602);
    });

    it('[server_rejects_nonplain] an input-required body that also carries structuredContent is rejected with -32602', async () => {
        const response = await callToolOnServer({ inputRequests: { r1: { method: 'elicitation/create' } }, structuredContent: { ok: true } });
        const error = (response as { error?: { code: number } }).error;
        expect(error, `expected an error, got ${JSON.stringify(response)}`).toBeDefined();
        expect(error!.code).toBe(-32602);
    });

    it('[server_normalizes_plain] handler results without content and without structuredContent, or with isError and _meta, reach the wire with every field kept', async () => {
        for (const [label, body] of CONTENTLESS_RESULTS) {
            const response = await callToolOnServer(body);
            const result = (response as { result?: Record<string, unknown> }).result;
            expect(result, `expected a result for ${label}, got ${JSON.stringify(response)}`).toBeDefined();
            expect(Array.isArray(result!.content), `content must be an array for ${label}, got ${JSON.stringify(result!.content)}`).toBe(true);
            for (const [key, value] of Object.entries(body)) {
                expect(result![key], `${key} must be kept for ${label}`).toEqual(value);
            }
        }
    });

    it('[server_rejects_nonplain] a requestState handler body is rejected with -32602', async () => {
        const response = await callToolOnServer({ requestState: 'opaque-token' });
        const error = (response as { error?: { code: number } }).error;
        expect(error, `expected an error, got ${JSON.stringify(response)}`).toBeDefined();
        expect(error!.code).toBe(-32602);
    });

    it('[server_rejects_nonplain] a requestState body that also carries structuredContent is rejected with -32602', async () => {
        const response = await callToolOnServer({ requestState: 'opaque-token', structuredContent: { ok: true } });
        const error = (response as { error?: { code: number } }).error;
        expect(error, `expected an error, got ${JSON.stringify(response)}`).toBeDefined();
        expect(error!.code).toBe(-32602);
    });

});
