/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
//
// Behavioral tests for the email-report lookup on dashboards and charts.
//
// WHAT IS TESTED, AND THROUGH WHICH INTERFACE
// -------------------------------------------
// Two pre-existing, stable boundaries are exercised; no internal helper is
// imported.
//
//   * reportsReducer — the default-exported pure Redux reducer in ./reducer.
//     Inputs are SET_REPORT / DELETE_REPORT action objects built from the
//     pre-existing action-type constants and interfaces in ./actions. Output
//     is the ReportsState object. We assert only the stored result, never the
//     internal matching mechanism, so a lookup table, a direct index, or an
//     explicit branch all pass equally.
//
//   * ReportModal — the default-exported React component ('.'). It is driven
//     through its pre-existing props (dashboardId, chart, creationMethod,
//     userEmail, show, toast callbacks) and rendered with the repo's own
//     spec/helpers/testing-library. The observable behavior is the HTTP body
//     it POSTs / PUTs (captured with fetch-mock) and the report name it shows
//     in edit mode. We assert the request payload and the rendered name, not
//     which code path produced them, so an inline ternary, a helper, or a
//     precomputed object all pass equally.
//
// The list endpoint serialises a resource's foreign key as `dashboard_id` /
// `chart_id`, whereas create/edit payloads carry flat `dashboard` / `chart`.
// A schedule fetched from the list endpoint must still be recognised, stay
// deletable, and — when a chart is opened inside a dashboard navigation
// context — resolve and save against the chart, sending a single resource id.
//
import fetchMock from 'fetch-mock';
import {
  render,
  screen,
  userEvent,
  waitFor,
  createStore,
} from 'spec/helpers/testing-library';
import reducerIndex from 'spec/helpers/reducerIndex';
import { FeatureFlag, VizType, isFeatureEnabled } from '@superset-ui/core';
import getBootstrapData from 'src/utils/getBootstrapData';
import { DEFAULT_COMMON_BOOTSTRAP_DATA } from 'src/constants';
import type { BootstrapData } from 'src/types/bootstrapTypes';
import reportsReducer, { ReportsState } from './reducer';
import {
  SET_REPORT,
  DELETE_REPORT,
  SetReportAction,
  DeleteReportAction,
} from './actions';
import { ReportObject } from 'src/features/reports/types';
import ReportModal from '.';

// ---------------------------------------------------------------------------
// Reducer suite — list-endpoint id fields must drive matching and deletion.
// ---------------------------------------------------------------------------

const makeReport = (overrides: Partial<ReportObject> = {}): ReportObject =>
  ({
    active: true,
    crontab: '0 12 * * 1',
    name: 'Test Report',
    recipients: [
      {
        recipient_config_json: {
          target: 'a@b.com',
          ccTarget: '',
          bccTarget: '',
        },
        type: 'Email',
      },
    ],
    report_format: 'PNG',
    timezone: 'UTC',
    type: 'Report',
    validator_config_json: null,
    validator_type: '',
    working_timeout: 3600,
    log_retention: 90,
    creation_method: 'dashboards',
    force_screenshot: false,
    editors: [1],
    ...overrides,
  }) as ReportObject;

test('a fetched schedule carrying only the list-endpoint dashboard id is stored for the resource', () => {
  // The fetched row exposes dashboard_id (list shape) and no flat dashboard
  // (create/edit shape). It must still land under the resource key.
  const existing = makeReport({ id: 5, dashboard_id: 10, chart_id: null });
  const initial: ReportsState = { dashboards: { 10: existing } };
  const refetched = makeReport({
    id: 5,
    dashboard_id: 10,
    chart_id: null,
    active: false,
  });
  const action: SetReportAction = {
    type: SET_REPORT,
    report: { result: [refetched] },
    resourceId: 10,
    creationMethod: 'dashboards',
    filterField: 'dashboard_id',
  };

  const result = reportsReducer(initial, action);

  expect(result.dashboards?.[10]).toBeDefined();
  expect(result.dashboards?.[10]).toMatchObject({
    id: refetched.id,
    active: refetched.active,
    dashboard_id: refetched.dashboard_id,
  });
});

test('a fetched chart schedule carrying only chart_id is stored for the chart', () => {
  const refetched = makeReport({
    id: 7,
    dashboard_id: null,
    chart_id: 42,
    creation_method: 'charts',
  });
  const action: SetReportAction = {
    type: SET_REPORT,
    report: { result: [refetched] },
    resourceId: 42,
    creationMethod: 'charts',
    filterField: 'chart_id',
  };

  const result = reportsReducer({}, action);

  expect(result.charts?.[42]).toBeDefined();
  expect(result.charts?.[42]).toMatchObject({
    id: refetched.id,
    active: refetched.active,
    chart_id: refetched.chart_id,
  });
});

test('a report fetched from the list endpoint can be deleted once it is stored', () => {
  // Mirror the real flow: the list fetch stores the schedule (SET_REPORT), and
  // the dropdown deletes the STORED object it reads back from state — never a
  // hand-built list row. Whatever shape a solution keeps in state (the fetched
  // row verbatim, or a normalised copy carrying flat dashboard/chart), deleting
  // that stored object must remove it. Driving delete off the stored object
  // keeps both storage designs passing while still failing a solution that
  // stores something it cannot then delete.
  const refetched = makeReport({ id: 5, dashboard_id: 10, chart_id: null });
  const afterSet = reportsReducer({}, {
    type: SET_REPORT,
    report: { result: [refetched] },
    resourceId: 10,
    creationMethod: 'dashboards',
    filterField: 'dashboard_id',
  } as SetReportAction);

  const stored = afterSet.dashboards?.[10];
  expect(stored).toBeDefined();

  const result = reportsReducer(afterSet, {
    type: DELETE_REPORT,
    report: stored as unknown as DeleteReportAction['report'],
  });

  expect(result.dashboards?.[10]).toBeUndefined();
});

test('a fetched chart schedule can be deleted once it is stored', () => {
  const refetched = makeReport({
    id: 7,
    dashboard_id: null,
    chart_id: 42,
    creation_method: 'charts',
  });
  const afterSet = reportsReducer({}, {
    type: SET_REPORT,
    report: { result: [refetched] },
    resourceId: 42,
    creationMethod: 'charts',
    filterField: 'chart_id',
  } as SetReportAction);

  const stored = afterSet.charts?.[42];
  expect(stored).toBeDefined();

  const result = reportsReducer(afterSet, {
    type: DELETE_REPORT,
    report: stored as unknown as DeleteReportAction['report'],
  });

  expect(result.charts?.[42]).toBeUndefined();
});

test('a delete with no resolvable resource id leaves state untouched', () => {
  // Guard: resolving the key from the id fields must not start matching
  // reports that carry no resource id at all.
  const initial: ReportsState = {
    dashboards: { 10: makeReport({ id: 5, dashboard_id: 10 }) },
  };
  const action: DeleteReportAction = {
    type: DELETE_REPORT,
    report: { id: 5, creation_method: 'dashboards' },
  };

  const result = reportsReducer(initial, action);

  expect(result).toBe(initial);
});

// ---------------------------------------------------------------------------
// Component suite — chart opened inside a dashboard navigation context.
// ---------------------------------------------------------------------------

jest.mock('src/utils/getBootstrapData', () => ({
  __esModule: true,
  default: jest.fn(() => ({
    common: {
      conf: {},
      feature_flags: {},
      user_subject_id: 99,
      user_subjects: [99],
    },
  })),
}));

jest.mock('@superset-ui/core', () => ({
  ...jest.requireActual('@superset-ui/core'),
  isFeatureEnabled: jest.fn(),
}));

const bootstrapData = (
  common: Partial<BootstrapData['common']> = {},
): BootstrapData => ({
  common: {
    ...DEFAULT_COMMON_BOOTSTRAP_DATA,
    ...common,
  },
});

const mockedGetBootstrapData = getBootstrapData as jest.MockedFunction<
  typeof getBootstrapData
>;
const mockedIsFeatureEnabled = isFeatureEnabled as jest.Mock;

const REPORT_ENDPOINT = 'glob:*/api/v1/report*';
fetchMock.get(REPORT_ENDPOINT, {});

const NOOP = () => {};

const defaultProps = {
  addDangerToast: NOOP,
  addSuccessToast: NOOP,
  addReport: NOOP,
  onHide: NOOP,
  onReportAdd: NOOP,
  show: true,
  userEmail: 'test@test.com',
  dashboardId: 1,
  creationMethod: 'dashboards',
  chart: {
    sliceFormData: {
      viz_type: VizType.Table,
    },
  },
};

beforeEach(() => {
  mockedGetBootstrapData.mockReturnValue(
    bootstrapData({
      user_subject_id: 99,
      user_subjects: [99],
    }),
  );
  mockedIsFeatureEnabled.mockImplementation(
    featureFlag => featureFlag === FeatureFlag.AlertReports,
  );
});

test('creating a chart report while a dashboard context is present sends only the chart id', async () => {
  // Explore opened from a dashboard passes a dashboardId alongside the chart;
  // a payload carrying both ids is rejected by the server. The save must send
  // the chart id alone.
  fetchMock.post(
    'glob:*/api/v1/report/subscribe',
    { id: 1, result: {} },
    { name: 'post-subscribe-chart' },
  );

  const chartFromDashboardProps = {
    ...defaultProps,
    dashboardId: 7,
    chart: { id: 119, sliceFormData: { viz_type: VizType.Line } },
    creationMethod: 'charts' as const,
  };
  render(<ReportModal {...chartFromDashboardProps} />, { useRedux: true });

  const addButton = screen.getByRole('button', { name: /add/i });
  await userEvent.click(addButton);

  await waitFor(() => {
    const postCalls = fetchMock.callHistory.calls('post-subscribe-chart');
    expect(postCalls).toHaveLength(1);
  });

  const postCalls = fetchMock.callHistory.calls('post-subscribe-chart');
  const body = JSON.parse(postCalls[0].options.body as string);
  expect(body.chart).toBe(119);
  expect(body.dashboard).toBeUndefined();

  fetchMock.removeRoute('post-subscribe-chart');
});

test('editing a chart report in a dashboard context resolves the chart schedule and saves to its id', async () => {
  // The store holds both a dashboard schedule and the chart's own schedule.
  // With a chart creation context, the modal must load the chart schedule
  // (not the dashboard one) and PUT to the chart schedule id with the chart
  // id alone.
  const dashboardReport = {
    id: 42,
    name: 'Existing Dashboard Report',
    creation_method: 'dashboards',
    crontab: '0 12 * * 1',
    dashboard_id: 7,
    chart_id: null,
    report_format: 'PNG',
    active: true,
    type: 'Report',
    timezone: 'America/New_York',
  };
  const chartReport = {
    ...dashboardReport,
    id: 77,
    name: 'Existing Chart Report',
    creation_method: 'charts',
    dashboard_id: null,
    chart_id: 119,
  };
  const store = createStore(
    {
      reports: {
        dashboards: { 7: dashboardReport },
        charts: { 119: chartReport },
      },
    },
    reducerIndex,
  );

  fetchMock.put(
    'glob:*/api/v1/report/77',
    { id: 77, result: {} },
    { name: 'put-report-77' },
  );

  const chartFromDashboardProps = {
    ...defaultProps,
    dashboardId: 7,
    chart: { id: 119, sliceFormData: { viz_type: VizType.Line } },
    creationMethod: 'charts' as const,
  };
  render(<ReportModal {...chartFromDashboardProps} />, {
    useRedux: true,
    store,
  });

  expect(screen.getByTestId('report-name-test')).toHaveDisplayValue(
    'Existing Chart Report',
  );

  const saveButton = screen.getByRole('button', { name: /save/i });
  await userEvent.click(saveButton);

  await waitFor(() => {
    const calls = fetchMock.callHistory.calls('put-report-77');
    expect(calls.length).toBeGreaterThan(0);
  });

  const calls = fetchMock.callHistory.calls('put-report-77');
  const body = JSON.parse(calls[calls.length - 1].options.body as string);
  expect(body.chart).toBe(119);
  expect(body.dashboard).toBeUndefined();

  fetchMock.removeRoute('put-report-77');
});

test('editing a chart report keeps its stored non-default delivery format on save', async () => {
  // A stored report whose format is XLSX (never the visualization default)
  // must keep that format through an unchanged edit-and-save.
  const fetchedReport = {
    active: true,
    chart_id: 96,
    creation_method: 'charts',
    crontab: '0 12 * * 1',
    dashboard_id: null,
    description: '',
    id: 44,
    name: 'Existing XLSX Report',
    report_format: 'XLSX',
    timezone: 'America/New_York',
    type: 'Report',
  };
  const store = createStore(
    {
      reports: {
        charts: { 96: fetchedReport },
      },
    },
    reducerIndex,
  );

  fetchMock.put(
    'glob:*/api/v1/report/44',
    { id: 44, result: {} },
    { name: 'put-report-44' },
  );

  const chartProps = {
    ...defaultProps,
    dashboardId: undefined,
    chart: { id: 96, sliceFormData: { viz_type: VizType.Line } },
    creationMethod: 'charts' as const,
  };
  render(<ReportModal {...chartProps} />, { useRedux: true, store });

  expect(screen.getByText('Edit email report')).toBeInTheDocument();
  expect(
    screen.getByRole('radio', { name: 'Formatted Excel attached in email' }),
  ).toBeChecked();

  const saveButton = screen.getByRole('button', { name: /save/i });
  await userEvent.click(saveButton);

  await waitFor(() => {
    const calls = fetchMock.callHistory.calls('put-report-44');
    expect(calls.length).toBeGreaterThan(0);
  });

  const calls = fetchMock.callHistory.calls('put-report-44');
  const body = JSON.parse(calls[calls.length - 1].options.body as string);
  expect(body.report_format).toBe('XLSX');

  fetchMock.removeRoute('put-report-44');
});
