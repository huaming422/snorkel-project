"""Behavioral test for the report-schedule list serialization.

The report menu rehydrates an existing schedule from the list endpoint. The
list endpoint's serialized columns are declared on the pre-existing, stable
REST API class ``ReportScheduleRestApi`` in ``superset/reports/api.py`` via its
class-level ``list_columns`` attribute. For a fetched schedule to carry its
delivery format back to the client, that attribute must include the delivery
format column.

This check is a pure source parse of the module: it reads the file, walks the
AST to the ``ReportScheduleRestApi`` class body, finds the ``list_columns``
assignment, and asserts the delivery-format column is among its string
entries. No application context, database, or Redis is needed, so it runs
offline under the shared grading interpreter.

Any shape of the assignment passes: a list literal, a list built from a shared
constant, or a reordered list — the test only asserts membership, never
position or construction.
"""

from __future__ import annotations

import ast
from pathlib import Path

REPO = Path("/repo/superset")
API_SOURCE = REPO / "superset" / "reports" / "api.py"

CLASS_NAME = "ReportScheduleRestApi"
ATTR_NAME = "list_columns"
DELIVERY_FORMAT_COLUMN = "report_format"


def _collect_string_entries(node: ast.AST) -> list[str]:
    """Return the string constants contained directly in a list/tuple/set node."""
    entries: list[str] = []
    if isinstance(node, (ast.List, ast.Tuple, ast.Set)):
        for element in node.elts:
            if isinstance(element, ast.Constant) and isinstance(element.value, str):
                entries.append(element.value)
    return entries


def _list_columns_entries() -> list[str]:
    """Parse the API module and return the ``list_columns`` string entries
    declared on the report-schedule REST API class."""
    source = API_SOURCE.read_text(encoding="utf-8")
    tree = ast.parse(source, filename=str(API_SOURCE))

    class_def = next(
        (
            node
            for node in tree.body
            if isinstance(node, ast.ClassDef) and node.name == CLASS_NAME
        ),
        None,
    )
    assert class_def is not None, (
        f"Could not find class {CLASS_NAME!r} in {API_SOURCE}. The report-schedule "
        f"REST API class is a pre-existing, stable surface and must remain present."
    )

    for stmt in class_def.body:
        targets: list[ast.expr] = []
        value: ast.AST | None = None
        if isinstance(stmt, ast.Assign):
            targets = stmt.targets
            value = stmt.value
        elif isinstance(stmt, ast.AnnAssign) and stmt.value is not None:
            targets = [stmt.target]
            value = stmt.value

        if value is not None and any(
            isinstance(t, ast.Name) and t.id == ATTR_NAME for t in targets
        ):
            return _collect_string_entries(value)

    raise AssertionError(
        f"Could not find a {ATTR_NAME!r} assignment in class {CLASS_NAME!r}."
    )


def test_list_columns_serialises_delivery_format() -> None:
    """The report-schedule list serialization must include the delivery-format
    column so a fetched schedule carries its format to the client."""
    entries = _list_columns_entries()

    assert entries, (
        f"{ATTR_NAME} on {CLASS_NAME} resolved to no string entries; expected a "
        f"list of serialized column names."
    )
    assert DELIVERY_FORMAT_COLUMN in entries, (
        f"{ATTR_NAME} on {CLASS_NAME} does not serialize {DELIVERY_FORMAT_COLUMN!r}; "
        f"a schedule fetched from the list endpoint would lose its delivery "
        f"format. Current entries: {sorted(entries)!r}"
    )
