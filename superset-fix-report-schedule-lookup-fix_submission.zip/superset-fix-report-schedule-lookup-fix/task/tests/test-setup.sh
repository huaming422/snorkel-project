#!/usr/bin/env bash
# test-setup.sh — runs once before the verifiers.
#
# This task has two verifier surfaces:
#   1. Frontend jest tests over the report-modal reducer/component/actions.
#   2. A backend Python check that the report-schedule list API serialises
#      `report_format`.
#
# The image already bakes the full dependency closure:
#   - superset installed editable into the system python
#   - superset-frontend/node_modules via `npm ci`
# so this script is offline-first and only verifies/repairs that closure.
#
# The verifier phase reaches only the model gateway, so nothing here may
# require pypi/npm at run time; the `|| ...` fallbacks exist for local,
# networked self-tests only.

set -e
set -o pipefail

REPO=/repo/superset
export REPO
cd "$REPO"

# Make a cache miss fail fast rather than hang against a dead network.
export UV_OFFLINE=1

# Backend: confirm superset imports under the system python. If the editable
# install was somehow lost, reinstall (networked self-test only).
echo "[test-setup] verifying superset import under system python"
if ! python3 -c "import superset" >/dev/null 2>&1; then
    echo "[test-setup] superset import failed — reinstalling editable" >&2
    uv pip install --system -e . || pip install -e .
fi

# Frontend: node_modules + jest binary must be present and resolvable.
cd "$REPO/superset-frontend"
if ! [ -x node_modules/.bin/jest ]; then
    echo "[test-setup] jest binary missing from node_modules — the image build" \
         "may be corrupt; re-running npm ci (networked self-test only)." >&2
    npm ci --ignore-scripts
fi

echo "[test-setup] node=$(node --version) jest=$(node_modules/.bin/jest --version 2>/dev/null || echo unknown)"
echo "[test-setup] done"
