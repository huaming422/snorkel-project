## Task

Users report that scheduled email reports on dashboards and charts keep
"disappearing". With the `ALERT_REPORTS` flag on, a three-dot menu offers "Set
up an email report" when none exists, and management entries (toggle active,
edit, delete) once one is attached.

When a report already exists, reloading the dashboard or chart page makes the
menu fall back to "Set up an email report", as does toggling the report active.
The request that loads the report returns its data fine, yet the menu shows the
wrong state.

Two more issues in the same area, probably related:

- Editing a report whose format is not the default (say Excel or CSV) and
  saving without touching the format reverts it to the default.
- Creating or editing a chart's report while viewing that chart inside a
  dashboard gets rejected by the server, or loads the wrong report.

Find why an existing report stops being recognised and fix it so reports are
managed consistently in all these cases.

Work offline; everything is installed — do not add new packages. Keep the fix
focused and minimal.
