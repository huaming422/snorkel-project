#!/usr/bin/env bash
# Regression guard: runs the write/exec runtime scenario through mise's own
# end-to-end harness (e2e/run_test) against the freshly built mise binary.
#
# It covers the ordinary write and exec paths: mise x, mise use, mise upgrade
# under the merge and generate lockfile modes, and populating a missing entry
# after install. The scenario body
# (test_lockfile_runtime_scope) is shipped alongside this file.
#
# The harness puts "$CARGO_TARGET_DIR/debug" first on PATH, so the built mise is
# the one under test. Guarded with :- so an outer override always wins.
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"

exec bash /repo/mise/e2e/run_test /tests/verify/test_lockfile_runtime_scope
