#!/bin/bash
# Setup for the mise-fix-lockfile-config-scope verifier.
#
# The behavioral interface for this task is mise's end-to-end lockfile suite
# (e2e/lockfile/...), run through e2e/run_test against a freshly built mise
# binary using the offline `dummy` asdf plugin fixture. The verify_*.sh wrappers
# in tests/verify/ invoke that harness; this script only compiles the binary and
# confirms the harness prerequisites.
#
# The image already holds everything a build needs (the repo is cloned at
# /repo/mise, the full dependency closure is fetched, the workspace is pre-built
# --locked, and `jq` is installed), so building works offline. This script runs
# with network allowed but installs nothing.

set -euo pipefail

REPO_DIR="/repo/mise"
cd "$REPO_DIR"

export REPO_NAME=mise

# The image sets CARGO_TARGET_DIR (see the image Dockerfile); the e2e harness
# resolves the binary under test from "$CARGO_TARGET_DIR/debug" on PATH, and
# cargo writes its output there. Keep both in agreement, with a :- fallback that
# matches cargo's default so this works even if the variable is ever unset.
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-$REPO_DIR/target}"
MISE_BIN="$CARGO_TARGET_DIR/debug/mise"

# Build the binary from the current sources. This is intentionally NON-FATAL:
# if the sources do not compile, there is no binary and the scenario wrappers
# fail, instead of this script aborting the whole run. Any binary left from an
# earlier build is removed first, so a source tree that no longer compiles is
# never tested through an older binary. Build offline-first on the warm cargo
# cache (incremental); fall back to an online build only if the offline build
# cannot be satisfied, logging loudly either way so a broken build is visible in
# the setup output.
rm -f "$MISE_BIN"
echo "[test-setup] building mise from the current sources ..."
if cargo build --locked --offline --bin mise > /tmp/mise-build.log 2>&1; then
    echo "[test-setup] offline build OK"
elif cargo build --locked --bin mise >> /tmp/mise-build.log 2>&1; then
    echo "[test-setup] online-fallback build OK"
else
    echo "[test-setup] WARNING: build failed; there is no binary, so the behavioral wrappers will fail" >&2
    tail -80 /tmp/mise-build.log >&2 || true
fi

if [ -x "$MISE_BIN" ]; then
    echo "[test-setup] binary present: $("$MISE_BIN" --version 2>/dev/null || echo "$MISE_BIN")"
else
    echo "[test-setup] WARNING: no mise binary at $MISE_BIN" >&2
fi

# jq is required by the lockfile suite (it parses `mise ls --current --json`). It
# is baked into the image; assert it rather than installing. Its absence means
# the image is broken, so this check is fatal.
command -v jq >/dev/null 2>&1 || { echo "[test-setup] jq not found on PATH" >&2; exit 1; }

# Confirm the e2e harness entrypoint and the offline dummy plugin fixture the
# suite depends on are present (image invariants). run_test symlinks the dummy
# and needs-dummy plugins from test/data/plugins/ into each test's data dir.
test -x "$REPO_DIR/e2e/run_test" || { echo "[test-setup] e2e/run_test missing" >&2; exit 1; }
test -d "$REPO_DIR/test/data/plugins/dummy" || { echo "[test-setup] dummy plugin fixture missing" >&2; exit 1; }

echo "[test-setup] ready"
