## Task

My project's mise.toml and my global config both have `dummy = "latest"`, each with a mise.lock beside it: 1.1.0 in the project, 2.0.0 globally. Here is what I get running from inside the project, and what I'd expect instead:

| project setup | command | today | expected |
|---|---|---|---|
| both locks as above | `mise which dummy --tool dummy@latest` | lockfile contains multiple resolutions for dummy@latest with the same options | .../installs/dummy/1.1.0/bin/dummy |
| both locks as above | `mise x dummy -- dummy --version` | same error | This is Dummy 1.1.0! --version |
| no dummy entry in the project's lock, global lock pinning 1.0.0 | `mise which dummy --tool dummy@latest --version` | 1.0.0 | 2.0.0 |
| a child folder whose own mise.toml sets dummy, with no lock, under a parent folder whose lock pins 1.0.0 | `mise which dummy --tool dummy@latest --version` | 1.0.0 | 2.0.0 |
| no dummy entry in the project's lock, MISE_LOCKED=1 or `locked = true` under `[tool_config]` | `mise install dummy` | dummy@latest is not in the lockfile | same |
| same | `mise which dummy --tool dummy@latest` | .../installs/dummy/2.0.0/bin/dummy | dummy@latest is not in the lockfile |
| same | `mise which dummy --tool dummy@prefix:2` | .../installs/dummy/2/bin/dummy | dummy@prefix:2 is not in the lockfile |
| same | `mise which dummy --tool dummy@ref:main` | dummy@ref:main is not installed | dummy@ref:main is not in the lockfile |
| mise.toml sets `format = "tar.xz"` and a url; the lock's only latest entry is an http one at 1.0.0 with that format | `mise which dummy --tool dummy@latest` | .../installs/dummy/2.0.0/bin/dummy | .../installs/dummy/1.0.0/bin/dummy |
| the lock has latest under an aqua backend and under asdf (1.0.0), MISE_LOCKED=1 | `mise which dummy --tool dummy@latest --version` | lockfile contains multiple resolutions for dummy@latest with the same options | 1.0.0 |
| only that aqua entry, and mise.toml spells one var as both `foo` and `vars.foo` | `mise which dummy --tool dummy@latest` | .../installs/dummy/2.0.0/bin/dummy | conflicting aqua var `foo`: use only one spelling |
| outside the project, the global config sets dummy with `locked_scopes = ["project"]` and an empty lock, MISE_LOCKED=1 | `mise which dummy --tool dummy@latest` | .../installs/dummy/latest/bin/dummy | dummy@latest is not in the lockfile |
| mise.toml has `dummy = "1"` and its lock pins 1.0.0 | `mise x dummy@2.0.0 -- dummy --version`, then read mise.lock | This is Dummy 2.0.0! --version, and the lock still holds only 1.0.0 | same |

I'd like the expected column. For `which --tool` and for `mise x` with no version, I'd expect the pin to come from the lock next to whichever config's dummy setting wins in that directory. When no config sets dummy, or that lock has no dummy entry, outside locked mode that means plain resolution.
