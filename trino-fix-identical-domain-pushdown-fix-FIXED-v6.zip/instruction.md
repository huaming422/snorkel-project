## Task

Null-safe comparisons (`IS NOT DISTINCT FROM`) misbehave in a handful of spots in the Trino planner, and users have run into each of them on their own. The code is in `/repo/trino`. Use `JAVA_HOME=/opt/jdk25` and run Maven as `./mvnw -o`: there's no network, and the modules involved are already built.

- If you turn off complex join pushdown, joining on `a IS NOT DISTINCT FROM b` against a JDBC source that supports that operator (PostgreSQL, for one) fails on the remote side, because Trino puts a `≡` symbol between the two columns and the database can't parse it. That join should come out as `l."x" IS NOT DISTINCT FROM r."y"`, and joins on other operators must look exactly like they do now.

- The column constraint we derive from `CAST(<varchar column> AS date) IS NOT DISTINCT FROM <date literal>` lets nulls of the column through, but a null can never match a date that isn't null. It should leave nulls out, just as `=` does in that case.

- `(<condition>) IS NOT DISTINCT FROM TRUE`, the FALSE version, and the negated `IS DISTINCT FROM` versions, with the constant on either side: these predicates aren't pushed down at all, while their longhand equivalents are.
