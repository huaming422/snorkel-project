"""Behavioral checks for trino-fix-identical-domain-pushdown.

The breakages are observed at two levels, each with a JUnit test class:

  * The whole planner. ``TestIdenticalPredicatePushdown`` (added by the test
    patch) plans ``SELECT * FROM t WHERE <predicate>`` with every optimizer
    against a mock connector that accepts any domain it is offered, then reads
    the domain the connector received and the filter left in the plan. The
    boolean-constant and varchar-to-date cases are checked here, so a fix in
    the domain extraction, in an expression rewrite rule, or in any other
    planner step all count. The remaining filter is judged by the rows it
    selects together with the pushed domain, over a grid of values including
    nulls and NaN, never by its form.

  * ``io.trino.plugin.jdbc.DefaultQueryBuilder``, through
    ``TestDefaultJdbcQueryBuilder`` against an in-memory H2 database. The stray
    operator glyph in a legacy join surfaces here.

The checks read observable results (pushed domains, what the remaining filter
selects, generated SQL), never the internal structure of the fix. Where more
than one result is correct (a sound but less precise domain where the longhand
form of the predicate pushes nothing, a comparison of two constants kept or
folded), each is accepted.

Null-safe equality over a widening cast (``CAST(c AS bigint) IS NOT DISTINCT
FROM <literal>``) is not checked. The planner unwraps those casts before domain
extraction sees them, so the only way to observe the domain extraction for them
is to call ``DomainTranslator`` directly, which would require a fix to live in
that one class. Run through the planner, the starting code already selects the
right rows and pushes the right domain for every such predicate tried.

The test methods that exercise the fixed behavior are added by
``verifier_tests.patch``, which is not part of the repository. Before applying
it, the test files it touches are put back to their starting versions, along
with ``TestDomainTranslator`` (so that class runs only the repository's own
cases), and any file at the new test class's path is removed (see
``_restore_patched_test_files``), so tests a solution added cannot collide with
the added methods (for example a method of the same name) and break
compilation.

The checks shell out to the repo's Maven wrapper and import no repository
Python (Trino is a Java project), so they run under the shared VERIFIER_PYTHON
with no repo-native pytest command.
"""

from __future__ import annotations

import os
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

import pytest

REPO = Path(os.environ.get("REPO_DIR", "/repo/trino"))
JAVA_HOME = os.environ.get("JAVA_HOME", "/opt/jdk25")

# The test patch lives next to this file. It adds the test methods that
# exercise the fixed behavior: a new planner test class and methods in the JDBC
# query builder test.
PATCH_PATH = Path(__file__).resolve().parent / "verifier_tests.patch"

# The existing test files that are put back to their starting versions (the
# patch edits the second; the first is restored so only its own cases run), the
# new test class the patch adds, and the file holding the commit the image was
# built at (written by the Dockerfile).
PATCHED_TEST_FILES = [
    "core/trino-main/src/test/java/io/trino/sql/planner/TestDomainTranslator.java",
    "plugin/trino-base-jdbc/src/test/java/io/trino/plugin/jdbc/TestDefaultJdbcQueryBuilder.java",
]
ADDED_TEST_FILE = "core/trino-main/src/test/java/io/trino/sql/planner/TestIdenticalPredicatePushdown.java"
BASE_REF_FILE = Path("/var/lib/devcontainer_base_ref")

# Fully-qualified names of the test classes we drive, with the surefire report
# directory of the module each lives in.
DOMAIN_TRANSLATOR_CLASS = "io.trino.sql.planner.TestDomainTranslator"
PUSHDOWN_CLASS = "io.trino.sql.planner.TestIdenticalPredicatePushdown"
QUERY_BUILDER_CLASS = "io.trino.plugin.jdbc.TestDefaultJdbcQueryBuilder"

# Test methods scored by test_legacy_join_sql, test_varchar_cast_to_date_identical
# and test_boolean_constant_identical.
TARGET_METHODS = {
    "testBuildJoinSqlLegacy",
    "testIdenticalOverVarcharCastToDate",
    "testIdenticalToBooleanConstant",
    "testIdenticalToBooleanConstantWhereResultIsOpen",
}

SUREFIRE_REPORTS = {
    DOMAIN_TRANSLATOR_CLASS: REPO / "core/trino-main/target/surefire-reports",
    PUSHDOWN_CLASS: REPO / "core/trino-main/target/surefire-reports",
    QUERY_BUILDER_CLASS: REPO / "plugin/trino-base-jdbc/target/surefire-reports",
}

# Maven flags shared by the reinstall and the test run. Offline (-o): the image
# baked the full dependency closure + compiled reactor, so no network is used.
# The static-analysis checks and the git-commit-id plugin are irrelevant to the
# focused tests and only slow the build.
COMMON_MVN_FLAGS = [
    "-o",
    "-B",
    "-Dair.check.skip-all=true",
    "-Dmaven.gitcommitid.skip=true",
]

# A single Maven invocation (reinstall or test) is a couple of minutes at most
# on a warm image; bound the subprocess well under the pytest timeout.
MVN_TIMEOUT_SEC = 850


def _mvn_env() -> dict:
    env = {**os.environ}
    env["JAVA_HOME"] = JAVA_HOME
    env["PATH"] = f"{JAVA_HOME}/bin:{env.get('PATH', '')}"
    return env


def _run(cmd: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(
        cmd,
        cwd=str(REPO),
        env=_mvn_env(),
        capture_output=True,
        text=True,
        timeout=MVN_TIMEOUT_SEC,
        check=False,
    )


def _restore_patched_test_files() -> None:
    """Put the test files the patch touches (and TestDomainTranslator) back to
    their starting versions.

    A solution may have edited or added tests in these files, or added a file
    at the new test class's path. Those tests are not part of the score, and
    keeping them could make the patch fail to apply or make the class fail to
    compile (a duplicate method name, a changed helper), which would hide a
    correct fix. Restoring them first makes the added assertions run against
    the solution's production code alone.
    """
    if not BASE_REF_FILE.is_file():
        raise RuntimeError(f"starting commit file not found at {BASE_REF_FILE}")
    base = BASE_REF_FILE.read_text().strip()
    restored = subprocess.run(
        ["git", "checkout", base, "--", *PATCHED_TEST_FILES],
        cwd=str(REPO),
        capture_output=True,
        text=True,
        check=False,
    )
    if restored.returncode != 0:
        raise RuntimeError(
            f"could not restore the test files from {base}:\n{restored.stderr}"
        )
    (REPO / ADDED_TEST_FILE).unlink(missing_ok=True)


def _apply_test_patch() -> None:
    """Restore the test files, then apply the test patch to them.

    Genuine infrastructure failures (missing repo, missing patch, a patch that
    does not apply to the restored files) raise, which invalidates the trial
    rather than scoring it.
    """
    if not REPO.is_dir():
        raise RuntimeError(f"repo not found at {REPO}")
    if not PATCH_PATH.is_file():
        raise RuntimeError(f"test patch not found at {PATCH_PATH}")

    _restore_patched_test_files()

    forward_check = subprocess.run(
        ["git", "apply", "--check", str(PATCH_PATH)],
        cwd=str(REPO),
        capture_output=True,
        text=True,
        check=False,
    )
    if forward_check.returncode != 0:
        raise RuntimeError(
            "verifier_tests.patch does not apply to the restored test files:\n"
            f"{forward_check.stderr}"
        )

    applied = subprocess.run(
        ["git", "apply", str(PATCH_PATH)],
        cwd=str(REPO),
        capture_output=True,
        text=True,
        check=False,
    )
    if applied.returncode != 0:
        raise RuntimeError(f"failed to apply verifier_tests.patch:\n{applied.stderr}")


def _reinstall_edited_modules() -> subprocess.CompletedProcess:
    """Republish the solution's edits so downstream modules test against them.

    ``plugin/trino-base-jdbc`` compiles and tests against the ``trino-spi``
    *artifact* in the local Maven repository, not reactor source, so after an
    edit to SPI classes a stale artifact would be used unless ``trino-spi`` is
    reinstalled first.
    Reinstalling ``trino-main`` too keeps the planner artifact consistent.
    Idempotent: a reinstall when nothing changed is cheap.
    """
    return _run(
        ["./mvnw", *COMMON_MVN_FLAGS, "-pl", "core/trino-spi,core/trino-main",
         "-am", "install", "-DskipTests",
         "-Dmaven.javadoc.skip=true", "-Dmaven.source.skip=true", "-T2C"]
    )


def _clean_surefire_reports() -> None:
    """Delete any existing surefire reports for the target classes.

    The image build warms the Maven test-execution cache by running the
    existing classes once; that leaves stale ``TEST-*.xml`` reports in the modules'
    ``surefire-reports`` dirs. If a later Maven invocation skips a module
    (e.g. the reactor bans a downstream module after an earlier test failure),
    ``_parse_surefire`` would otherwise read the stale report and score a run
    that never happened this trial. Removing the specific report files first
    makes "module did not run" observable as an absent report.
    """
    for fq, reports_dir in SUREFIRE_REPORTS.items():
        xml = reports_dir / f"TEST-{fq}.xml"
        try:
            xml.unlink()
        except FileNotFoundError:
            pass
        # Surefire also writes a per-method <class>.txt summary; clear it too so
        # no stale trace lingers next to a fresh run.
        txt = reports_dir / f"{fq}.txt"
        try:
            txt.unlink()
        except FileNotFoundError:
            pass


def _run_test_classes(module: str, simple_classes: list[str]) -> subprocess.CompletedProcess:
    """Run the given test classes of one module, in their own Maven invocation.

    Each module gets a SEPARATE Maven invocation rather than one combined
    ``-pl a,b`` reactor: a combined run aborts (and *skips* the second module)
    as soon as the first module has a test failure, which on a broken solution
    would prevent the jdbc case from ever being exercised, masking a genuine
    failure as an absent report. Within one module surefire runs every listed
    class even when an earlier one fails.
    """
    return _run(
        ["./mvnw", *COMMON_MVN_FLAGS, "-pl", module, "test",
         f"-Dtest={','.join(simple_classes)}", "-DfailIfNoTests=false"]
    )


def _parse_surefire(reports_dir: Path, fq_class: str) -> dict[str, bool]:
    """Return {method_name: passed} for one test class, or {} if no report."""
    xml = reports_dir / f"TEST-{fq_class}.xml"
    if not xml.is_file():
        return {}
    root = ET.parse(str(xml)).getroot()  # noqa: S314 (trusted local surefire output)
    results: dict[str, bool] = {}
    for tc in root.findall("testcase"):
        name = tc.get("name", "")
        # Strip any surefire parametrization suffix, e.g. "method[1]".
        base = name.split("[", 1)[0]
        failed = tc.find("failure") is not None or tc.find("error") is not None
        # A class can list a method more than once (parametrized). It passes
        # only if every execution passed.
        results[base] = results.get(base, True) and not failed
    return results


class _Outcome:
    """Collected result of the one Maven run, shared across the pytest cases."""

    def __init__(self) -> None:
        _apply_test_patch()
        # Remove stale baked reports BEFORE running so a module that is skipped
        # this trial can never be scored from a build-time report.
        _clean_surefire_reports()
        self.reinstall = _reinstall_edited_modules()
        # Run each class in its own module invocation so one module's failure
        # cannot skip the other (see _run_test_class).
        self.test_run_dt = _run_test_classes(
            "core/trino-main",
            [DOMAIN_TRANSLATOR_CLASS.rsplit(".", 1)[-1], PUSHDOWN_CLASS.rsplit(".", 1)[-1]],
        )
        self.test_run_qb = _run_test_classes(
            "plugin/trino-base-jdbc", [QUERY_BUILDER_CLASS.rsplit(".", 1)[-1]]
        )
        self.by_class = {
            fq: _parse_surefire(reports, fq)
            for fq, reports in SUREFIRE_REPORTS.items()
        }

    def _tail(self) -> str:
        parts = []
        if self.reinstall.returncode != 0:
            parts.append("REINSTALL stdout tail:\n" + self.reinstall.stdout[-2500:])
            parts.append("REINSTALL stderr tail:\n" + self.reinstall.stderr[-1500:])
        parts.append("trino-main tests stdout tail:\n"
                     + self.test_run_dt.stdout[-3000:])
        parts.append("TestDefaultJdbcQueryBuilder (trino-base-jdbc) stdout tail:\n"
                     + self.test_run_qb.stdout[-3000:])
        parts.append("TEST stderr tail (jdbc):\n" + self.test_run_qb.stderr[-1200:])
        return "\n\n".join(parts)

    def method(self, fq_class: str, method: str) -> bool:
        """True iff the named method ran and passed.

        A method absent from the surefire report means it never ran (a compile
        failure in the solution, or the suite aborting); that counts as a
        failure, with the Maven output attached so the reason is visible.
        """
        results = self.by_class.get(fq_class, {})
        if method not in results:
            pytest.fail(
                f"{fq_class}.{method} did not run (no surefire result). The "
                f"solution likely fails to compile or the suite aborted before "
                f"reaching it.\n\n{self._tail()}"
            )
        return results[method]

    def class_results(self, fq_class: str) -> dict[str, bool]:
        return self.by_class.get(fq_class, {})


@pytest.fixture(scope="session")
def outcome() -> _Outcome:
    return _Outcome()


def test_legacy_join_sql(outcome: _Outcome) -> None:
    """Legacy join SQL for ``IS NOT DISTINCT FROM``.

    A legacy (non-complex) JDBC join pushdown of an ``IS NOT DISTINCT FROM``
    condition must generate valid remote SQL that reads
    ``IS NOT DISTINCT FROM`` and runs against the database. The EQUAL join
    must keep producing ``=``. Observed through ``TestDefaultJdbcQueryBuilder``
    against in-memory H2. Joins on the other operators are covered by
    ``test_no_regression``.
    """
    assert outcome.method(QUERY_BUILDER_CLASS, "testBuildJoinSqlLegacy"), (
        "legacy IS NOT DISTINCT FROM join pushdown still produces invalid "
        f"remote SQL.\n\n{outcome._tail()}"
    )


def test_varchar_cast_to_date_identical(outcome: _Outcome) -> None:
    """Null-safe equality over a varchar-to-date cast.

    The domain pushed for ``CAST(varchar AS date) IS NOT DISTINCT FROM <date>``
    must exclude nulls, the same as for ``=``, because a null can never match a
    date that is not null. Observed through the whole planner
    (``TestIdenticalPredicatePushdown``), with the remaining filter judged by
    the rows it selects together with the pushed domain.
    """
    assert outcome.method(PUSHDOWN_CLASS, "testIdenticalOverVarcharCastToDate"), (
        "IS NOT DISTINCT FROM over a varchar-to-date cast pushes the wrong "
        f"domain.\n\n{outcome._tail()}"
    )


def test_boolean_constant_identical(outcome: _Outcome) -> None:
    """Null-safe comparison with a boolean constant.

    ``(condition) IS NOT DISTINCT FROM <boolean constant>``, the FALSE form and
    the negated ``IS DISTINCT FROM`` forms, with the constant on either side,
    must push the same domain the planner already pushes for the longhand form
    of the predicate, and every case (including the ones where nothing can be
    pushed: inexact, multi-column and NaN-typed conditions, a null constant,
    two constants) must keep selecting exactly the rows the predicate selects.
    Observed through the whole planner (``TestIdenticalPredicatePushdown``), so
    the fix may live in any planner step.
    """
    for method in ("testIdenticalToBooleanConstant", "testIdenticalToBooleanConstantWhereResultIsOpen"):
        assert outcome.method(PUSHDOWN_CLASS, method), (
            f"IS NOT DISTINCT FROM against a boolean constant is not pushed down "
            f"correctly ({method}).\n\n{outcome._tail()}"
        )


def test_no_regression(outcome: _Outcome) -> None:
    """Existing behavior keeps working.

    The whole existing ``TestDomainTranslator`` and
    ``TestDefaultJdbcQueryBuilder`` suites must stay green (including the
    varchar-to-date cases already there): the fix must not
    break EQUAL / NOT_EQUAL domain extraction, symbol-side IDENTICAL handling,
    or join SQL for other operators. The test patch adds
    ``testBuildJoinSqlLegacyOtherOperators``, which checks the legacy join SQL
    and row counts for <, <=, >, >=, <> and =, so it is scored here. Asserts both suites actually ran a
    plausible number of cases and that none of the existing cases failed (the
    four target methods are scored by the other checks).
    """
    dt = outcome.class_results(DOMAIN_TRANSLATOR_CLASS)
    qb = outcome.class_results(QUERY_BUILDER_CLASS)
    pd = outcome.class_results(PUSHDOWN_CLASS)

    assert dt, (
        "TestDomainTranslator produced no surefire results; the suite did not "
        f"run.\n\n{outcome._tail()}"
    )
    assert qb, (
        "TestDefaultJdbcQueryBuilder produced no surefire results; the suite "
        f"did not run.\n\n{outcome._tail()}"
    )
    assert len(pd) == 3, (
        f"TestIdenticalPredicatePushdown ran {len(pd)} methods, expected 3.\n\n"
        f"{outcome._tail()}"
    )
    # Guard against a vacuous pass: the known existing cases must be present.
    assert "testBuildJoinSqlLegacy" in qb
    assert "testFromBasicComparisons" in dt or len(dt) >= 20, (
        f"TestDomainTranslator ran unexpectedly few cases ({len(dt)}).\n\n"
        f"{outcome._tail()}"
    )

    # The methods the other three checks score are left out here, so this check
    # covers only the cases that already pass before the fix.
    failed = [f"{DOMAIN_TRANSLATOR_CLASS}.{m}" for m, ok in dt.items()
              if not ok and m not in TARGET_METHODS]
    failed += [f"{QUERY_BUILDER_CLASS}.{m}" for m, ok in qb.items()
               if not ok and m not in TARGET_METHODS]
    assert not failed, (
        "these existing cases failed: "
        f"{', '.join(sorted(failed))}\n\n{outcome._tail()}"
    )
