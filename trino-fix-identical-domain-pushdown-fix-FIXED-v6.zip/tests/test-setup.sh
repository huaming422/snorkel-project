#!/usr/bin/env bash
# test-setup.sh: sourced by test.sh before the checks run.
#
# The image baked the full Maven dependency closure and the compiled reactor for
# core/trino-main and plugin/trino-base-jdbc (and the modules they depend on)
# into ~/.m2 and the per-module target/ dirs at the starting commit.
#
# Nothing is rebuilt here. verify.py reinstalls core/trino-spi and
# core/trino-main itself, after it has applied its test patch, so the solution's
# edits are compiled exactly once and a compile failure is reported by the
# checks as a failed run instead of ending test.sh before any score is written.
# This file is sourced, so it does not change shell options or exit.

cd /repo/trino || return 0

export JAVA_HOME="${JAVA_HOME:-/opt/jdk25}"
export PATH="${JAVA_HOME}/bin:${PATH}"

java -version 2>&1 | head -1
echo "test-setup: ready."
