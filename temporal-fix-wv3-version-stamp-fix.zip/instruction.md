## Task

Resetting a workflow that's on worker deployment versioning (v3) can hand back a new run that's tied to a worker build ID it has nothing to do with. If you describe the reset run it shows an assigned build ID, like a workflow on the old build-ID based versioning would, and it gets treated as one from then on. The original run never shows an assigned build ID while it's running, so nobody notices until the workflow gets reset.

Reset runs of v3 workflows should come back with no build ID assignment. Anything that's really on the old build-ID versioning has to keep working the way it does now.
