// Guard tests for the older build-ID-based versioning scheme.
//
// Injected into /repo/temporal/tests/ and compiled into the pre-existing `tests`
// package, reusing VersioningIntegSuite and its helpers. They observe behavior
// only through workflow history (validateWorkflowEventsVersionStamps reads the
// SDK workflow history and asserts each task started event records the expected
// per-task build-version information).
//
// A workflow on old build-ID versioning keeps its assigned build ID and still
// records per-task build-version information on its started events, including
// the started event of a workflow task that is retried after a failure and of
// an update's workflow task that the worker fails.
//
// The workflowStaysInBuildId scenario is invoked once directly (rather than
// through the suite's matching-behavior fan-out) to keep the run short; the
// recorded-stamp assertions are identical across those variants.
package tests

import (
	"context"
	"sync/atomic"
	"testing"
	"time"

	"github.com/google/uuid"
	"github.com/stretchr/testify/suite"
	commonpb "go.temporal.io/api/common/v1"
	enumspb "go.temporal.io/api/enums/v1"
	updatepb "go.temporal.io/api/update/v1"
	"go.temporal.io/api/workflowservice/v1"
	sdkclient "go.temporal.io/sdk/client"
	"go.temporal.io/sdk/worker"
	"go.temporal.io/sdk/workflow"
	"go.temporal.io/server/common/payloads"
	"go.temporal.io/server/common/testing/testvars"
	"go.temporal.io/server/tests/testcore"
)

func TestWv2StampVerify(t *testing.T) {
	suite.Run(t, new(VersioningIntegSuite))
}

func (s *VersioningIntegSuite) TestVerifyOldVersioningStampPreserved() {
	s.workflowStaysInBuildId()
}

func (s *VersioningIntegSuite) TestVerifyOldVersioningStampOnRetriedTask() {
	tq := testcore.RandomizeStr(s.T().Name())
	v1 := s.prefixed("v1")

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	// The first workflow task panics, so the worker fails it and the retried
	// task completes the workflow.
	var runs atomic.Int32
	wf := func(ctx workflow.Context) (string, error) {
		if runs.Add(1) == 1 {
			panic("fail the first workflow task")
		}
		return "done!", nil
	}

	rule := s.addAssignmentRule(ctx, tq, v1)
	s.waitForAssignmentRulePropagation(ctx, tq, rule)

	w1 := worker.New(s.SdkClient(), tq, worker.Options{
		BuildID:                          v1,
		UseBuildIDForVersioning:          true,
		MaxConcurrentWorkflowTaskPollers: numPollers,
	})
	w1.RegisterWorkflow(wf)
	s.NoError(w1.Start())
	defer w1.Stop()

	run, err := s.SdkClient().ExecuteWorkflow(ctx, sdkclient.StartWorkflowOptions{TaskQueue: tq}, wf)
	s.NoError(err)
	var out string
	s.NoError(run.Get(ctx, &out))
	s.Equal("done!", out)
	s.GreaterOrEqual(runs.Load(), int32(2))

	// Both the failed task and its retry record the worker's build ID.
	s.validateWorkflowEventsVersionStamps(ctx, run.GetID(), run.GetRunID(), []string{v1, v1}, "")
}

func (s *VersioningIntegSuite) TestVerifyOldVersioningStampOnFailedUpdateTask() {
	tv := testvars.New(s.T())
	tq := tv.TaskQueue()
	v1 := s.prefixed("v1")
	capabilities := &commonpb.WorkerVersionCapabilities{BuildId: v1, UseVersioning: true}
	stamp := &commonpb.WorkerVersionStamp{BuildId: v1, UseVersioning: true}

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	rule := s.addAssignmentRule(ctx, tq.GetName(), v1)
	s.waitForAssignmentRulePropagation(ctx, tq.GetName(), rule)

	pollWorkflowTask := func() *workflowservice.PollWorkflowTaskQueueResponse {
		resp, err := s.FrontendClient().PollWorkflowTaskQueue(ctx, &workflowservice.PollWorkflowTaskQueueRequest{
			Namespace:                 s.Namespace().String(),
			TaskQueue:                 tq,
			Identity:                  tv.WorkerIdentity(),
			WorkerVersionCapabilities: capabilities,
		})
		s.NoError(err)
		s.NotEmpty(resp.GetTaskToken())
		return resp
	}

	startResp, err := s.FrontendClient().StartWorkflowExecution(ctx, &workflowservice.StartWorkflowExecutionRequest{
		RequestId:    uuid.NewString(),
		Namespace:    s.Namespace().String(),
		WorkflowId:   tv.WorkflowID(),
		WorkflowType: tv.WorkflowType(),
		TaskQueue:    tq,
		Identity:     tv.WorkerIdentity(),
	})
	s.NoError(err)

	// The worker on v1 completes the first workflow task.
	first := pollWorkflowTask()
	_, err = s.FrontendClient().RespondWorkflowTaskCompleted(ctx, &workflowservice.RespondWorkflowTaskCompletedRequest{
		Namespace:          s.Namespace().String(),
		TaskToken:          first.GetTaskToken(),
		Identity:           tv.WorkerIdentity(),
		WorkerVersionStamp: stamp,
	})
	s.NoError(err)

	// An update arrives while the workflow is idle, and the same worker fails
	// the workflow task that delivers it.
	updateDone := make(chan struct{})
	go func() {
		defer close(updateDone)
		updateCtx, updateCancel := context.WithTimeout(ctx, 10*time.Second)
		defer updateCancel()
		_, _ = s.FrontendClient().UpdateWorkflowExecution(updateCtx, &workflowservice.UpdateWorkflowExecutionRequest{
			Namespace:         s.Namespace().String(),
			WorkflowExecution: &commonpb.WorkflowExecution{WorkflowId: tv.WorkflowID()},
			Request: &updatepb.Request{
				Meta: &updatepb.Meta{UpdateId: tv.UpdateID()},
				Input: &updatepb.Input{
					Name: tv.HandlerName(),
					Args: payloads.EncodeString("args"),
				},
			},
		})
	}()
	updateTask := pollWorkflowTask()
	s.NotEmpty(updateTask.GetMessages(), "workflow task should deliver the update")
	_, err = s.FrontendClient().RespondWorkflowTaskFailed(ctx, &workflowservice.RespondWorkflowTaskFailedRequest{
		Namespace:     s.Namespace().String(),
		TaskToken:     updateTask.GetTaskToken(),
		Cause:         enumspb.WORKFLOW_TASK_FAILED_CAUSE_WORKFLOW_WORKER_UNHANDLED_FAILURE,
		Identity:      tv.WorkerIdentity(),
		WorkerVersion: stamp,
	})
	s.NoError(err)

	// Both started workflow tasks record the worker's build ID.
	s.validateWorkflowEventsVersionStamps(ctx, tv.WorkflowID(), startResp.GetRunId(), []string{v1, v1}, "")

	cancel()
	<-updateDone
}
