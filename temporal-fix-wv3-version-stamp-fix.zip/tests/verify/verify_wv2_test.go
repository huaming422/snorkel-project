// Guard tests for the older build-ID-based versioning scheme.
//
// Injected into /repo/temporal/tests/ and compiled into the pre-existing `tests`
// package, reusing VersioningIntegSuite and its helpers. They observe behavior
// only through workflow history (validateWorkflowEventsVersionStamps reads the
// SDK workflow history and asserts each task started event records the expected
// per-task build-version information).
//
// A workflow on old build-ID versioning keeps its assigned build ID and still
// records per-task build-version information on its started events, including
// the started event of a workflow task that is retried after a failure.
//
// The workflowStaysInBuildId scenario is invoked once directly (rather than
// through the suite's matching-behavior fan-out) to keep the run within the
// time budget; the recorded-stamp assertions are identical across those
// variants.
package tests

import (
	"context"
	"sync/atomic"
	"testing"
	"time"

	"github.com/stretchr/testify/suite"
	sdkclient "go.temporal.io/sdk/client"
	"go.temporal.io/sdk/worker"
	"go.temporal.io/sdk/workflow"
	"go.temporal.io/server/tests/testcore"
)

func TestWv2StampVerify(t *testing.T) {
	suite.Run(t, new(VersioningIntegSuite))
}

func (s *VersioningIntegSuite) TestVerifyOldVersioningStampPreserved() {
	s.workflowStaysInBuildId()
}

func (s *VersioningIntegSuite) TestVerifyOldVersioningStampOnRetriedTask() {
	tq := testcore.RandomizeStr(s.T().Name())
	v1 := s.prefixed("v1")

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	// The first workflow task panics, so the worker fails it and the retried
	// task completes the workflow.
	var runs atomic.Int32
	wf := func(ctx workflow.Context) (string, error) {
		if runs.Add(1) == 1 {
			panic("fail the first workflow task")
		}
		return "done!", nil
	}

	rule := s.addAssignmentRule(ctx, tq, v1)
	s.waitForAssignmentRulePropagation(ctx, tq, rule)

	w1 := worker.New(s.SdkClient(), tq, worker.Options{
		BuildID:                          v1,
		UseBuildIDForVersioning:          true,
		MaxConcurrentWorkflowTaskPollers: numPollers,
	})
	w1.RegisterWorkflow(wf)
	s.NoError(w1.Start())
	defer w1.Stop()

	run, err := s.SdkClient().ExecuteWorkflow(ctx, sdkclient.StartWorkflowOptions{TaskQueue: tq}, wf)
	s.NoError(err)
	var out string
	s.NoError(run.Get(ctx, &out))
	s.Equal("done!", out)
	s.GreaterOrEqual(runs.Load(), int32(2))

	// Both the failed task and its retry record the worker's build ID.
	s.validateWorkflowEventsVersionStamps(ctx, run.GetID(), run.GetRunID(), []string{v1, v1}, "")
}
