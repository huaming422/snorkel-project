// Behavioral tests for worker-deployment ("v3") versioned workflows.
//
// This file is injected into /repo/temporal/tests/ and compiled as part of the
// pre-existing `tests` package, so it reuses that package's Versioning3Suite and
// its helpers (drainWorkflowTaskAfterSetCurrent, pollWftAndHandle, sendUpdate,
// UpdateAcceptCompleteCommands/Messages, GetHistory). It drives workflows only
// through the frontend gRPC API and observes them through workflow history,
// ResetWorkflowExecution and DescribeWorkflowExecution.
//
// Every worker in these scenarios is a v3 worker: it polls with versioned
// deployment options and, like the Go SDK, reports a worker version stamp when
// it completes or fails a workflow task.
package tests

import (
	"context"
	"testing"

	"github.com/google/uuid"
	commandpb "go.temporal.io/api/command/v1"
	commonpb "go.temporal.io/api/common/v1"
	deploymentpb "go.temporal.io/api/deployment/v1"
	enumspb "go.temporal.io/api/enums/v1"
	failurepb "go.temporal.io/api/failure/v1"
	"go.temporal.io/api/workflowservice/v1"

	"github.com/stretchr/testify/suite"
	"go.temporal.io/server/common/testing/testvars"
	"go.temporal.io/server/service/worker/workerdeployment"
	"go.temporal.io/server/tests/testcore"
)

func TestWv3StampVerify(t *testing.T) {
	suite.Run(t, &Versioning3Suite{
		deploymentWorkflowVersion: workerdeployment.VersionDataRevisionNumber,
	})
}

func (s *Versioning3Suite) verifyV3DeploymentOptions(tv *testvars.TestVars) *deploymentpb.WorkerDeploymentOptions {
	return &deploymentpb.WorkerDeploymentOptions{
		BuildId:              tv.BuildID(),
		DeploymentName:       tv.DeploymentSeries(),
		WorkerVersioningMode: enumspb.WORKER_VERSIONING_MODE_VERSIONED,
	}
}

// verifyRunUpdatesAndTaskRetryV3 starts a v3 workflow, completes an update on a
// versioned worker, fails the workflow task that carries a second update, and
// fails the workflow from the retried task.
func (s *Versioning3Suite) verifyRunUpdatesAndTaskRetryV3(tv *testvars.TestVars) *commonpb.WorkflowExecution {
	tvUpd1 := tv.WithUpdateIDNumber(1).WithMessageIDNumber(1)
	tvUpd2 := tv.WithUpdateIDNumber(2)
	stamp := &commonpb.WorkerVersionStamp{UseVersioning: true, BuildId: tv.BuildID()}

	// Start workflow and drain first WFT.
	execution, _ := s.drainWorkflowTaskAfterSetCurrent(tv)

	// Send first update.
	updateResultCh := sendUpdateNoError(s, tvUpd1)

	// Poll and handle: accept + complete the first update on a versioned poller.
	s.pollWftAndHandle(tv, false, nil,
		func(task *workflowservice.PollWorkflowTaskQueueResponse) (*workflowservice.RespondWorkflowTaskCompletedRequest, error) {
			s.NotNil(task)
			s.NotEmpty(task.Messages)
			return &workflowservice.RespondWorkflowTaskCompletedRequest{
				Commands:           s.UpdateAcceptCompleteCommands(tvUpd1),
				Messages:           s.UpdateAcceptCompleteMessages(tvUpd1, task.Messages[0]),
				WorkerVersionStamp: stamp,
				VersioningBehavior: vbUnpinned,
				DeploymentOptions:  s.verifyV3DeploymentOptions(tv),
			}, nil
		})
	<-updateResultCh

	// Send second update.
	updateResultCh2 := sendUpdate(context.Background(), s, tvUpd2)

	// Poll and fail the WFT with deployment options to trigger a retry.
	failCtx := testcore.NewContext()
	pollResp, err := s.FrontendClient().PollWorkflowTaskQueue(failCtx, &workflowservice.PollWorkflowTaskQueueRequest{
		Namespace:         s.Namespace().String(),
		TaskQueue:         tv.TaskQueue(),
		Identity:          tv.WorkerIdentity(),
		DeploymentOptions: tv.WorkerDeploymentOptions(true),
	})
	s.NoError(err)
	s.NotEmpty(pollResp.GetTaskToken())
	_, err = s.FrontendClient().RespondWorkflowTaskFailed(failCtx, &workflowservice.RespondWorkflowTaskFailedRequest{
		Namespace:         s.Namespace().String(),
		TaskToken:         pollResp.TaskToken,
		Cause:             enumspb.WORKFLOW_TASK_FAILED_CAUSE_WORKFLOW_WORKER_UNHANDLED_FAILURE,
		Identity:          tv.WorkerIdentity(),
		WorkerVersion:     stamp,
		DeploymentOptions: tv.WorkerDeploymentOptions(true),
	})
	s.NoError(err)

	// Poll the retried WFT and fail the workflow.
	s.pollWftAndHandle(tv, false, nil,
		func(task *workflowservice.PollWorkflowTaskQueueResponse) (*workflowservice.RespondWorkflowTaskCompletedRequest, error) {
			s.NotNil(task)
			return &workflowservice.RespondWorkflowTaskCompletedRequest{
				Commands: []*commandpb.Command{
					{
						CommandType: enumspb.COMMAND_TYPE_FAIL_WORKFLOW_EXECUTION,
						Attributes: &commandpb.Command_FailWorkflowExecutionCommandAttributes{
							FailWorkflowExecutionCommandAttributes: &commandpb.FailWorkflowExecutionCommandAttributes{
								Failure: &failurepb.Failure{Message: "workflow failed intentionally"},
							},
						},
					},
				},
				WorkerVersionStamp: stamp,
				VersioningBehavior: vbUnpinned,
				DeploymentOptions:  s.verifyV3DeploymentOptions(tv),
			}, nil
		})

	<-updateResultCh2
	return execution
}

// verifyResetRunHasNoAssignedBuildId resets the workflow to its last completed
// workflow task and checks that the new run has no assigned build ID.
func (s *Versioning3Suite) verifyResetRunHasNoAssignedBuildId(execution *commonpb.WorkflowExecution) {
	var resetPoint int64
	for _, event := range s.GetHistory(s.Namespace().String(), execution) {
		if event.GetEventType() == enumspb.EVENT_TYPE_WORKFLOW_TASK_COMPLETED {
			resetPoint = event.GetEventId()
		}
	}
	s.NotZero(resetPoint, "history should contain a completed workflow task to reset to")

	resetResp, err := s.FrontendClient().ResetWorkflowExecution(testcore.NewContext(), &workflowservice.ResetWorkflowExecutionRequest{
		Namespace:                 s.Namespace().String(),
		WorkflowExecution:         execution,
		Reason:                    "reset v3 workflow",
		WorkflowTaskFinishEventId: resetPoint,
		RequestId:                 uuid.NewString(),
	})
	s.NoError(err)

	desc, err := s.FrontendClient().DescribeWorkflowExecution(testcore.NewContext(), &workflowservice.DescribeWorkflowExecutionRequest{
		Namespace: s.Namespace().String(),
		Execution: &commonpb.WorkflowExecution{WorkflowId: execution.GetWorkflowId(), RunId: resetResp.GetRunId()},
	})
	s.NoError(err)
	s.Empty(
		desc.GetWorkflowExecutionInfo().GetAssignedBuildId(),
		"run created by resetting a v3 workflow to event %d should not have an assigned build ID",
		resetPoint,
	)
}

func (s *Versioning3Suite) TestVerifyNoWorkerVersionOnStartedEventsV3() {
	tv := testvars.New(s)
	execution := s.verifyRunUpdatesAndTaskRetryV3(tv)

	// For a v3-versioned workflow, no WorkflowTaskStarted event should record
	// per-task worker build-version information.
	events := s.GetHistory(s.Namespace().String(), execution)
	for _, event := range events {
		if event.GetEventType() == enumspb.EVENT_TYPE_WORKFLOW_TASK_STARTED {
			s.Nil(
				//nolint:staticcheck // SA1019
				event.GetWorkflowTaskStartedEventAttributes().GetWorkerVersion(),
				"WorkflowTaskStarted event %d should not record worker build-version information for a v3 workflow",
				event.GetEventId(),
			)
		}
	}
}

func (s *Versioning3Suite) TestVerifyResetRunNotAssignedAfterUpdatesV3() {
	tv := testvars.New(s)
	execution := s.verifyRunUpdatesAndTaskRetryV3(tv)
	s.verifyResetRunHasNoAssignedBuildId(execution)
}

// The workflow's first task fails on a v3 worker and its retry completes, so no
// task has completed on a versioned worker before the retry starts.
func (s *Versioning3Suite) TestVerifyResetRunNotAssignedAfterFirstTaskRetryV3() {
	tv := testvars.New(s)
	stamp := &commonpb.WorkerVersionStamp{UseVersioning: true, BuildId: tv.BuildID()}

	// The first poll registers the version with matching, then receives the
	// first workflow task and fails it.
	failErr := make(chan error, 1)
	go func() {
		ctx := testcore.NewContext()
		resp, err := s.FrontendClient().PollWorkflowTaskQueue(ctx, &workflowservice.PollWorkflowTaskQueueRequest{
			Namespace:         s.Namespace().String(),
			TaskQueue:         tv.TaskQueue(),
			Identity:          tv.WorkerIdentity(),
			DeploymentOptions: tv.WorkerDeploymentOptions(true),
		})
		if err != nil {
			failErr <- err
			return
		}
		_, err = s.FrontendClient().RespondWorkflowTaskFailed(ctx, &workflowservice.RespondWorkflowTaskFailedRequest{
			Namespace:         s.Namespace().String(),
			TaskToken:         resp.TaskToken,
			Cause:             enumspb.WORKFLOW_TASK_FAILED_CAUSE_WORKFLOW_WORKER_UNHANDLED_FAILURE,
			Identity:          tv.WorkerIdentity(),
			WorkerVersion:     stamp,
			DeploymentOptions: tv.WorkerDeploymentOptions(true),
		})
		failErr <- err
	}()
	s.waitForDeploymentDataPropagation(tv, versionStatusInactive, false, tqTypeWf)
	s.setCurrentDeployment(tv)
	runID := s.startWorkflow(tv, nil)
	execution := tv.WithRunID(runID).WorkflowExecution()
	s.NoError(<-failErr)

	// Complete the retried first task on the same versioned worker.
	s.pollWftAndHandle(tv, false, nil,
		func(task *workflowservice.PollWorkflowTaskQueueResponse) (*workflowservice.RespondWorkflowTaskCompletedRequest, error) {
			s.NotNil(task)
			return &workflowservice.RespondWorkflowTaskCompletedRequest{
				WorkerVersionStamp: stamp,
				VersioningBehavior: vbUnpinned,
				DeploymentOptions:  s.verifyV3DeploymentOptions(tv),
			}, nil
		})

	s.verifyResetRunHasNoAssignedBuildId(execution)
}
