#!/usr/bin/env bash
# All deps (Go module cache + build cache for ./tests and
# ./common/worker_versioning) are baked into the image at the base commit.
# GOPROXY=off / GOFLAGS=-mod=mod are already persisted via `go env -w`, so the
# verifier's `go test` run is fully offline. Nothing to install here.
set -euo pipefail
echo "[test-setup] no-op for temporal-fix-wv3-version-stamp (deps baked in image)"
