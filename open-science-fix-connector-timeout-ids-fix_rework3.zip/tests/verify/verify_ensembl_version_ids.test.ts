// @ts-nocheck
//
// Checks for versioned Ensembl stable IDs. Each ID-route tool from
// GENOMES_ENSEMBL_TOOLS runs through a ParserEngine with an injected fetchImpl,
// and two things are observed:
//   - the request URL handed to fetchImpl (the ID without its version);
//   - the record returned to the caller (the ID exactly as the caller gave it).
// The IDs cover genes, transcripts, proteins and exons, a non-human species
// prefix, and one- and two-digit versions. Gene symbols (including a clone-based
// name with a dot in it) and LRG IDs go out unchanged.

import { describe, it, expect, vi } from 'vitest'
import { ParserEngine } from './engine'
import { GENOMES_ENSEMBL_TOOLS } from './descriptors/genomes-ensembl'

const jsonRes = (body: unknown): Response =>
  ({ ok: true, status: 200, json: async () => body }) as Response

const tool = (id: string): (typeof GENOMES_ENSEMBL_TOOLS)[number] => {
  const t = GENOMES_ENSEMBL_TOOLS.find((x) => x.id === id)
  if (!t) throw new Error(`no tool ${id}`)
  return t
}

const run = (
  id: string,
  args: Record<string, unknown>,
  fetchImpl: ReturnType<typeof vi.fn>
): Promise<unknown> =>
  new ParserEngine({
    fetchImpl: fetchImpl as unknown as typeof fetch,
    retries: 0
  }).call(tool(id), args, {})

// [versioned ID as the caller has it, the same ID without its version]
const VERSIONED: Array<[string, string]> = [
  ['ENST00000422447.8', 'ENST00000422447'],
  ['ENSG00000157764.16', 'ENSG00000157764'],
  ['ENSP00000288602.6', 'ENSP00000288602'],
  ['ENSE00001154485.4', 'ENSE00001154485'],
  ['ENSMUSG00000002413.17', 'ENSMUSG00000002413']
]

describe('ensembl version handling', () => {
  it.each(VERSIONED)('lookup of %s requests %s and returns the query as given', async (given, base) => {
    const fetchImpl = vi.fn().mockResolvedValueOnce(jsonRes({ id: base }))
    const out = (await run('ensembl_lookup', { query: given }, fetchImpl)) as { query: string }

    const url = String(fetchImpl.mock.calls[0][0])
    expect(url).toContain(`/lookup/id/${base}?`)
    // Routed as a stable ID, not downgraded to the symbol endpoint.
    expect(url).not.toContain('/lookup/symbol/')
    // The returned record still reports exactly what the caller asked about.
    expect(out.query).toBe(given)
  })

  it.each(VERSIONED)('cross-references of %s request %s and return the ID as given', async (given, base) => {
    const fetchImpl = vi.fn().mockResolvedValueOnce(jsonRes([]))
    const out = (await run('ensembl_xrefs', { stable_id: given }, fetchImpl)) as { stable_id: string }

    const url = String(fetchImpl.mock.calls[0][0])
    expect(url).toContain(`/xrefs/id/${base}?`)
    expect(out.stable_id).toBe(given)
  })

  it.each(VERSIONED)('sequence of %s requests %s and returns the query as given', async (given, base) => {
    const fetchImpl = vi.fn().mockResolvedValueOnce(jsonRes({ id: base, molecule: 'dna', seq: 'ACGT' }))
    const out = (await run('ensembl_sequence', { stable_id: given }, fetchImpl)) as { query: string }

    const url = String(fetchImpl.mock.calls[0][0])
    expect(url).toContain(`/sequence/id/${base}?type=`)
    expect(out.query).toBe(given)
  })

  it('sends an unversioned stable ID unchanged', async () => {
    const fetchImpl = vi.fn().mockResolvedValueOnce(jsonRes({ id: 'ENSG00000157764' }))
    const out = (await run('ensembl_lookup', { query: 'ENSG00000157764' }, fetchImpl)) as { query: string }

    expect(String(fetchImpl.mock.calls[0][0])).toContain('/lookup/id/ENSG00000157764?')
    expect(out.query).toBe('ENSG00000157764')
  })

  it('sends an LRG id unchanged on the stable-ID route', async () => {
    const fetchImpl = vi.fn().mockResolvedValueOnce(jsonRes({ id: 'LRG_299' }))
    await run('ensembl_lookup', { query: 'LRG_299' }, fetchImpl)

    const url = String(fetchImpl.mock.calls[0][0])
    expect(url).toContain('/lookup/id/LRG_299?')
    expect(url).not.toContain('/lookup/symbol/')
  })

  it.each(['BRAF', 'RP11-34P13.7'])('routes the gene symbol %s to the symbol endpoint, untouched', async (symbol) => {
    const fetchImpl = vi.fn().mockResolvedValueOnce(jsonRes({ id: 'ENSG00000157764' }))
    const out = (await run('ensembl_lookup', { query: symbol }, fetchImpl)) as { query: string }

    const url = String(fetchImpl.mock.calls[0][0])
    expect(url).toContain(`/lookup/symbol/homo_sapiens/${symbol}?`)
    expect(url).not.toContain('/lookup/id/')
    expect(out.query).toBe(symbol)
  })
})
