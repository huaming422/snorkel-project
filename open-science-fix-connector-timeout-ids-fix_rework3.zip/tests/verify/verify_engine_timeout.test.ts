// @ts-nocheck
//
// Checks for the shared connector request engine, driven only through
//   new ParserEngine({ fetchImpl, timeoutMs, retries, retryBackoffMs })
//     .call(descriptor, args, credentials, signal?)
// and observed through the injected fetchImpl (how often it is called, the
// signal each attempt gets) and the value the call resolves or rejects with:
//   - when every attempt times out, the rejection is not the cancellation
//     error and its message says it timed out and names the request, the
//     attempt count (for several retry settings) and the per-attempt limit;
//   - a request whose attempts all fail without timing out is not reported
//     as a timeout;
//   - a caller's own cancellation is still a cancellation and is not retried,
//     whether it lands before the response or while the body is arriving;
//   - a body that keeps arriving completes even when it takes many times one
//     attempt's limit, minutes in total;
//   - a body that goes quiet part way is retried, then reported as the
//     timeout with the same details, for JSON, text and POST requests;
//   - the default limit and retry count are unchanged.

import { describe, it, expect, vi } from 'vitest'
import { ParserEngine } from './engine'
import type { ToolDescriptor } from './types'

// A minimal 200 Response fake with no streaming body, used by the
// regression cases.
const jsonResponse = (body: unknown): Response =>
  ({
    ok: true,
    status: 200,
    json: async () => body,
    text: async () => JSON.stringify(body)
  }) as Response

// The attempt count and the per-attempt limit appear as standalone numbers (a digit inside a longer
// number doesn't count). Spelled-out or seconds forms of the same values are accepted too.
const SPELLED = ['zero', 'one', 'two', 'three', 'four', 'five']
const attemptsRe = (n: number): RegExp => new RegExp(`(^|\\D)${n}(\\D|$)|\\b${SPELLED[n]}\\b`, 'i')
const ATTEMPTS_3 = attemptsRe(3)
const LIMIT_5_MS = /(^|\D)5(\D|$)|(^|\D)0?\.005\s*s/i
// The message has to say the request timed out, in any common wording.
const TIMEOUT_WORDING = /tim(e|ed|ing)[\s-]?out|timeout|deadline exceeded/i

// A fetch that never answers until the attempt's signal is aborted.
const hangingFetch = () =>
  vi.fn(
    async (_url: string | URL | Request, init?: RequestInit): Promise<Response> =>
      new Promise((_, reject) => {
        const requestSignal = init?.signal
        requestSignal?.addEventListener('abort', () => reject(requestSignal.reason), { once: true })
      })
  )

const rejectionOf = async (call: Promise<unknown>): Promise<unknown> => {
  try {
    await call
  } catch (err) {
    return err
  }
  throw new Error('expected the call to reject')
}

const urlDesc = (url = 'https://x.test/data'): ToolDescriptor => ({
  id: 't',
  connector: 'c',
  description: '',
  input: {},
  url: () => url,
  parse: (raw) => raw
})

describe('ParserEngine timeout', () => {
  it.each([1, 2, 3])(
    'reports a request whose attempts all time out as a timeout, not a bare cancellation (retries %i)',
    async (retries) => {
      // Every attempt hangs until the engine aborts it.
      const fetchImpl = hangingFetch()
      const engine = new ParserEngine({ fetchImpl, timeoutMs: 5, retries, retryBackoffMs: 0 })

      const error = await rejectionOf(engine.call(urlDesc('https://x.test/data'), {}, {}))
      const name = (error as { name?: unknown })?.name
      const message = error instanceof Error ? error.message : String(error)

      // Not the generic "operation was aborted" a cancelled cell produces.
      expect(name).not.toBe('AbortError')
      // The message says it timed out, which request it was, how many attempts
      // were made (retries + 1) and how long each attempt was allowed (5 ms).
      // Any wording is fine as long as all four are there.
      expect(message).toMatch(TIMEOUT_WORDING)
      expect(message).toContain('https://x.test/data')
      expect(message).toMatch(attemptsRe(retries + 1))
      expect(message).toMatch(LIMIT_5_MS)
      expect(fetchImpl).toHaveBeenCalledTimes(retries + 1)
    }
  )

  it('does not report attempts that fail without timing out as a timeout', async () => {
    // Every attempt fails at once the way an unresolvable host does.
    const fetchImpl = vi.fn(async (): Promise<Response> => {
      throw new TypeError('fetch failed', { cause: new Error('getaddrinfo ENOTFOUND x.test') })
    })
    const engine = new ParserEngine({ fetchImpl, timeoutMs: 5_000, retries: 2, retryBackoffMs: 0 })

    const error = await rejectionOf(engine.call(urlDesc('https://x.test/data'), {}, {}))
    const message = error instanceof Error ? error.message : String(error)

    expect(message).not.toMatch(TIMEOUT_WORDING)
    expect(fetchImpl).toHaveBeenCalledTimes(3)
  })

  it('surfaces a caller cancellation as a cancellation and does not retry it', async () => {
    let observedSignal: AbortSignal | undefined
    const fetchImpl = vi.fn(
      async (_url: string | URL | Request, init?: RequestInit): Promise<Response> =>
        new Promise((_, reject) => {
          observedSignal = init?.signal ?? undefined
          observedSignal?.addEventListener('abort', () => reject(observedSignal?.reason), {
            once: true
          })
        })
    )
    const engine = new ParserEngine({ fetchImpl, timeoutMs: 60_000, retries: 2, retryBackoffMs: 0 })
    const cancellation = new AbortController()

    const call = engine.call(urlDesc(), {}, {}, cancellation.signal)
    await vi.waitFor(() => expect(observedSignal).toBeInstanceOf(AbortSignal))
    cancellation.abort()

    await expect(call).rejects.toMatchObject({ name: 'AbortError' })
    expect(fetchImpl).toHaveBeenCalledOnce()
  })

  it.each([2, 0])(
    'surfaces a cancellation that lands while the body is arriving as a cancellation (retries %i)',
    async (retries) => {
      const encoder = new TextEncoder()
      let bodyStarted = false
      const fetchImpl = vi.fn(
        async (_url: string | URL | Request, init?: RequestInit): Promise<Response> =>
          new Response(
            new ReadableStream({
              start(controller) {
                // Part of the body arrives, then more keeps coming every 10 ms
                // until the request's signal aborts.
                controller.enqueue(encoder.encode('{"value":'))
                bodyStarted = true
                const ticker = setInterval(() => controller.enqueue(encoder.encode(' ')), 10)
                init?.signal?.addEventListener(
                  'abort',
                  () => {
                    clearInterval(ticker)
                    controller.error(init.signal?.reason)
                  },
                  { once: true }
                )
              }
            })
          )
      )
      const engine = new ParserEngine({ fetchImpl, timeoutMs: 60_000, retries, retryBackoffMs: 0 })
      const cancellation = new AbortController()

      const call = engine.call(urlDesc('https://x.test/data'), {}, {}, cancellation.signal)
      await vi.waitFor(() => expect(bodyStarted).toBe(true))
      await new Promise((resolve) => setTimeout(resolve, 30))
      cancellation.abort()

      const error = await rejectionOf(call)
      expect((error as { name?: unknown })?.name).toBe('AbortError')
      const message = error instanceof Error ? error.message : String(error)
      expect(message).not.toMatch(TIMEOUT_WORDING)
      expect(fetchImpl).toHaveBeenCalledOnce()
    }
  )

  it("lets a continuously-progressing body finish even past one attempt's limit", async () => {
    const encoder = new TextEncoder()
    const fetchImpl = vi.fn(
      async (_url: string | URL | Request, init?: RequestInit): Promise<Response> =>
        new Response(
          new ReadableStream({
            start(controller) {
              // Pieces arrive 10 ms apart (the limit is 30 ms) and the body
              // finishes at 150 ms, five times the limit. If the attempt's
              // signal aborts, the stream errors, as a real fetch body would.
              const timers = [
                setTimeout(() => controller.enqueue(encoder.encode('{"value":')), 10),
                ...Array.from({ length: 12 }, (_, i) =>
                  setTimeout(() => controller.enqueue(encoder.encode(' ')), 20 + i * 10)
                ),
                setTimeout(() => controller.enqueue(encoder.encode('9}')), 140),
                setTimeout(() => controller.close(), 150)
              ]
              init?.signal?.addEventListener(
                'abort',
                () => {
                  for (const t of timers) clearTimeout(t)
                  controller.error(init.signal?.reason)
                },
                { once: true }
              )
            }
          })
        )
    )
    const engine = new ParserEngine({ fetchImpl, timeoutMs: 30, retries: 2, retryBackoffMs: 0 })
    const desc: ToolDescriptor = {
      id: 't',
      connector: 'c',
      description: '',
      input: {},
      url: () => 'https://x.test/data',
      parse: (raw) => (raw as { value: number }).value
    }

    await expect(engine.call(desc, {}, {})).resolves.toBe(9)
    expect(fetchImpl).toHaveBeenCalledOnce()
  })

  it('lets a body that keeps arriving for five minutes finish under the default limit', async () => {
    vi.useFakeTimers({ toFake: ['setTimeout', 'clearTimeout'] })
    try {
      const encoder = new TextEncoder()
      const fetchImpl = vi.fn(
        async (_url: string | URL | Request, init?: RequestInit): Promise<Response> =>
          new Response(
            new ReadableStream({
              start(controller) {
                // A piece every 10 s (the default limit is 30 s) for 300 s,
                // then the end of the body.
                const timers = [setTimeout(() => controller.enqueue(encoder.encode('{"value":')), 10_000)]
                for (let t = 20_000; t < 300_000; t += 10_000) {
                  timers.push(setTimeout(() => controller.enqueue(encoder.encode(' ')), t))
                }
                timers.push(setTimeout(() => controller.enqueue(encoder.encode('9}')), 300_000))
                timers.push(setTimeout(() => controller.close(), 300_001))
                init?.signal?.addEventListener(
                  'abort',
                  () => {
                    for (const t of timers) clearTimeout(t)
                    controller.error(init.signal?.reason)
                  },
                  { once: true }
                )
              }
            })
          )
      )
      const engine = new ParserEngine({ fetchImpl, retries: 2, retryBackoffMs: 0 })
      const desc: ToolDescriptor = {
        id: 't',
        connector: 'c',
        description: '',
        input: {},
        url: () => 'https://x.test/data',
        parse: (raw) => (raw as { value: number }).value
      }

      const result = engine.call(desc, {}, {}).then(
        (value) => ({ value }),
        (error) => ({ error })
      )
      await vi.advanceTimersByTimeAsync(301_000)
      expect(await result).toEqual({ value: 9 })
      expect(fetchImpl).toHaveBeenCalledOnce()
    } finally {
      vi.useRealTimers()
    }
  })

  it('gives up on a body that stalls mid-stream and reports it as the timeout', async () => {
    const encoder = new TextEncoder()
    const fetchImpl = vi.fn(
      async (_url: string | URL | Request, init?: RequestInit): Promise<Response> =>
        new Response(
          new ReadableStream({
            start(controller) {
              // Headers + a partial body arrive, then the stream goes quiet.
              controller.enqueue(encoder.encode('{"value":'))
              init?.signal?.addEventListener(
                'abort',
                () => controller.error(init.signal?.reason),
                { once: true }
              )
            }
          })
        )
    )
    const engine = new ParserEngine({ fetchImpl, timeoutMs: 5, retries: 2, retryBackoffMs: 0 })
    const result = engine.call(urlDesc('https://x.test/data'), {}, {}).catch((err: unknown) => err)

    // The call has to settle within 100 ms (three 5 ms attempts); otherwise the
    // race resolves to the 'still pending' marker.
    const settled = (await Promise.race([
      result,
      new Promise((resolve) => setTimeout(() => resolve('still pending'), 100))
    ])) as unknown

    expect(settled).not.toBe('still pending')
    const name = (settled as { name?: unknown })?.name
    const message = settled instanceof Error ? settled.message : String(settled)
    expect(name).not.toBe('AbortError')
    expect(message).toMatch(TIMEOUT_WORDING)
    expect(message).toContain('https://x.test/data')
    expect(message).toMatch(ATTEMPTS_3)
    expect(message).toMatch(LIMIT_5_MS)
    expect(fetchImpl).toHaveBeenCalledTimes(3)
  })

  it('does not treat empty chunks as progress: a zero-byte trickle still times out', async () => {
    const encoder = new TextEncoder()
    const fetchImpl = vi.fn(
      async (_url: string | URL | Request, init?: RequestInit): Promise<Response> =>
        new Response(
          new ReadableStream({
            start(controller) {
              // A partial body, then an endless trickle of zero-byte reads,
              // one every 2 ms, with no further data. The call is expected to
              // settle as a timeout within 100 ms.
              controller.enqueue(encoder.encode('{"value":'))
              const ticker = setInterval(() => {
                try {
                  controller.enqueue(new Uint8Array(0))
                } catch {
                  clearInterval(ticker)
                }
              }, 2)
              init?.signal?.addEventListener(
                'abort',
                () => {
                  clearInterval(ticker)
                  controller.error(init.signal?.reason)
                },
                { once: true }
              )
            }
          })
        )
    )
    const engine = new ParserEngine({ fetchImpl, timeoutMs: 5, retries: 2, retryBackoffMs: 0 })
    const result = engine.call(urlDesc('https://x.test/data'), {}, {}).catch((err: unknown) => err)

    const settled = (await Promise.race([
      result,
      new Promise((resolve) => setTimeout(() => resolve('still pending'), 100))
    ])) as unknown

    expect(settled).not.toBe('still pending')
    const name = (settled as { name?: unknown })?.name
    const message = settled instanceof Error ? settled.message : String(settled)
    expect(name).not.toBe('AbortError')
    expect(message).toContain('https://x.test/data')
    expect(fetchImpl).toHaveBeenCalledTimes(3)
  })
})

describe('ParserEngine timeout on every kind of request', () => {
  // A body that sends a few bytes and then goes quiet, for any request.
  const stallingFetch = () =>
    vi.fn(
      async (_url: string | URL | Request, init?: RequestInit): Promise<Response> =>
        new Response(
          new ReadableStream({
            start(controller) {
              controller.enqueue(new TextEncoder().encode('partial'))
              init?.signal?.addEventListener('abort', () => controller.error(init.signal?.reason), {
                once: true
              })
            }
          })
        )
    )

  const settleWithin = async (call: Promise<unknown>): Promise<unknown> =>
    Promise.race([
      call.catch((err: unknown) => err),
      new Promise((resolve) => setTimeout(() => resolve('still pending'), 100))
    ])

  // The settled rejection says it timed out and names the request, the
  // attempt count and the 5 ms limit.
  const expectTimeoutReport = (settled: unknown, url: string, attempts: number): void => {
    expect(settled).not.toBe('still pending')
    expect((settled as { name?: unknown })?.name).not.toBe('AbortError')
    const message = settled instanceof Error ? settled.message : String(settled)
    expect(message).toMatch(TIMEOUT_WORDING)
    expect(message).toContain(url)
    expect(message).toMatch(attemptsRe(attempts))
    expect(message).toMatch(LIMIT_5_MS)
  }

  it('gives up on a stalled text response and reports the timeout', async () => {
    const fetchImpl = stallingFetch()
    const engine = new ParserEngine({ fetchImpl, timeoutMs: 5, retries: 1, retryBackoffMs: 0 })
    const desc: ToolDescriptor = {
      id: 't',
      connector: 'c',
      description: '',
      input: {},
      run: async (ctx) => ctx.fetchText('https://x.test/notes.txt')
    }
    const settled = await settleWithin(engine.call(desc, {}, {}))
    expectTimeoutReport(settled, 'https://x.test/notes.txt', 2)
    expect(fetchImpl).toHaveBeenCalledTimes(2)
  })

  it('gives up on a stalled POST response and reports the timeout', async () => {
    const fetchImpl = stallingFetch()
    const engine = new ParserEngine({ fetchImpl, timeoutMs: 5, retries: 3, retryBackoffMs: 0 })
    const desc: ToolDescriptor = {
      id: 't',
      connector: 'c',
      description: '',
      input: {},
      run: async (ctx) => ctx.postJson('https://gql.test/api', { query: 'q' })
    }
    const settled = await settleWithin(engine.call(desc, {}, {}))
    expectTimeoutReport(settled, 'https://gql.test/api', 4)
    expect(fetchImpl).toHaveBeenCalledTimes(4)
  })
})

describe('ParserEngine limits that stay the same', () => {
  it('still makes three tries in all by default (two retries)', async () => {
    const fetchImpl = vi.fn().mockResolvedValue({ ok: false, status: 503 } as Response)
    const engine = new ParserEngine({ fetchImpl, retryBackoffMs: 0 })
    await expect(engine.call(urlDesc('https://x.test'), {}, {})).rejects.toThrow(/HTTP 503/)
    expect(fetchImpl).toHaveBeenCalledTimes(3)
  })

  it('still allows each attempt 30 seconds by default', async () => {
    vi.useFakeTimers({ toFake: ['setTimeout', 'clearTimeout'] })
    try {
      let observedSignal: AbortSignal | undefined
      const fetchImpl = vi.fn(
        async (_url: string | URL | Request, init?: RequestInit): Promise<Response> =>
          new Promise((_, reject) => {
            observedSignal = init?.signal ?? undefined
            observedSignal?.addEventListener('abort', () => reject(observedSignal?.reason), {
              once: true
            })
          })
      )
      const engine = new ParserEngine({ fetchImpl, retries: 0, retryBackoffMs: 0 })
      const call = engine.call(urlDesc(), {}, {}).catch((err: unknown) => err)

      await vi.advanceTimersByTimeAsync(29_900)
      expect(observedSignal?.aborted).toBe(false)
      await vi.advanceTimersByTimeAsync(200)
      expect(observedSignal?.aborted).toBe(true)
      await call
    } finally {
      vi.useRealTimers()
    }
  })
})

describe('ParserEngine regression', () => {
  it('retries a transient 5xx up to the configured retries then surfaces an HTTP error', async () => {
    const fetchImpl = vi.fn().mockResolvedValue({ ok: false, status: 503 } as Response)
    const engine = new ParserEngine({ fetchImpl, retries: 2, retryBackoffMs: 0 })
    await expect(engine.call(urlDesc('https://x.test'), {}, {})).rejects.toThrow(/HTTP 503/)
    expect(fetchImpl).toHaveBeenCalledTimes(3) // 1 initial + 2 retries
  })

  it('retries a transient 5xx then succeeds', async () => {
    const fetchImpl = vi
      .fn()
      .mockResolvedValueOnce({ ok: false, status: 503 } as Response)
      .mockResolvedValueOnce(jsonResponse({ value: 7 }))
    const engine = new ParserEngine({ fetchImpl, retryBackoffMs: 0 })
    const desc: ToolDescriptor = {
      id: 't',
      connector: 'c',
      description: '',
      input: {},
      url: () => 'https://x.test',
      parse: (raw) => (raw as { value: number }).value
    }
    expect(await engine.call(desc, {}, {})).toBe(7)
    expect(fetchImpl).toHaveBeenCalledTimes(2)
  })

  it('does not retry a client error (4xx other than 429)', async () => {
    const fetchImpl = vi.fn().mockResolvedValue({ ok: false, status: 400 } as Response)
    const engine = new ParserEngine({ fetchImpl, retryBackoffMs: 0 })
    await expect(engine.call(urlDesc('https://x.test'), {}, {})).rejects.toThrow(/HTTP 400/)
    expect(fetchImpl).toHaveBeenCalledTimes(1)
  })

  it('postJson sends a POST with a JSON body and parses the response', async () => {
    const fetchImpl = vi.fn().mockResolvedValue(jsonResponse({ data: { ok: true } }))
    const engine = new ParserEngine({ fetchImpl })
    const desc: ToolDescriptor = {
      id: 't',
      connector: 'c',
      description: '',
      input: {},
      run: async (ctx) => ctx.postJson('https://gql.test/api', { query: 'q', variables: { a: 1 } })
    }
    const out = await engine.call(desc, {}, {})
    const init = fetchImpl.mock.calls[0][1] as RequestInit & { headers: Record<string, string> }
    expect(init.method).toBe('POST')
    expect(init.headers['content-type']).toBe('application/json')
    expect(JSON.parse(init.body as string)).toEqual({ query: 'q', variables: { a: 1 } })
    expect(out).toEqual({ data: { ok: true } })
  })

  it('sends a User-Agent header (some APIs 403 without one)', async () => {
    const fetchImpl = vi.fn().mockResolvedValue(jsonResponse({ ok: 1 }))
    const engine = new ParserEngine({ fetchImpl })
    await engine.call(urlDesc('https://example.test'), {}, {})
    const headers = (fetchImpl.mock.calls[0][1] as { headers: Record<string, string> }).headers
    expect(headers['user-agent']).toMatch(/OpenScience/)
  })

  it('redacts credentials from the URL in error messages', async () => {
    const fetchImpl = vi.fn().mockResolvedValue({ ok: false, status: 401 } as Response)
    const engine = new ParserEngine({ fetchImpl })
    let message = ''
    try {
      await engine.call(
        urlDesc('https://eutils.ncbi.nlm.nih.gov/entrez?email=a@b.com&api_key=SECRET'),
        {},
        {}
      )
    } catch (error) {
      message = error instanceof Error ? error.message : String(error)
    }
    expect(message).not.toContain('SECRET')
    expect(message).toContain('HTTP 401')
  })
})
