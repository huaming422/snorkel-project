#!/usr/bin/env bash
# Environment bootstrap for the verifier. Sourced (not exec'd) so env
# vars set here stay live for the verifier subprocess.
#
# The agent phase runs with no network; the image already carries the full
# dependency closure (npm ci at the base commit, in the image's clone layer).
# This script only prepares the VERIFIER: it installs nothing the repo itself
# needs and never re-resolves node_modules against the network on the happy path.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/open-science}"
export REPO_DIR
cd "$REPO_DIR"

# Make a cache miss fail fast instead of hanging against a dead network. Only the
# task's own npm sees this; it does not reach the harness installer run at trial prep.
export npm_config_offline=true
export npm_config_audit=false
export npm_config_fund=false

# verify.toml is read by the TypeScript runner driver under VERIFIER_PYTHON
# (the baked /opt/tooling venv, Python 3.11+), which has tomllib in the stdlib,
# so no tomli install is needed here. (Legacy images that drove the runner with
# the 3.10 system python needed a defensive tomli pin; this image does not.)

# vitest must be resolvable from the repo root; a miss means a corrupted
# node_modules from the image build. Reinstall from the warm local cache
# (offline) instead of failing later with a confusing "command not found".
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/. " \
         "The image build looks corrupt — re-running npm ci from the local cache." >&2
    npm ci --prefer-offline --no-audit --no-fund
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR node=$(node --version 2>/dev/null || echo unknown) vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
