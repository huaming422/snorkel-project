// @ts-nocheck
//
// Behavioural verifier for the Ensembl descriptor's handling of versioned
// stable IDs. Drives each ID-route tool through the pre-existing public
// surface — a ParserEngine with an injected fetchImpl executing a descriptor
// from GENOMES_ENSEMBL_TOOLS — and observes two things only:
//   - the upstream request URL handed to fetchImpl (the base stable ID must
//     reach Ensembl, with any trailing `.<version>` removed);
//   - the record returned to the caller (it must still echo the caller's exact
//     query, versioned).
// Nothing imports the internal version-stripping helper: a valid solution may
// inline the strip, share a util, or use an equivalent regex, so only the
// observable request URL and returned data are asserted.

import { describe, it, expect, vi } from 'vitest'
import { ParserEngine } from './engine'
import { GENOMES_ENSEMBL_TOOLS } from './descriptors/genomes-ensembl'

const jsonRes = (body: unknown): Response =>
  ({ ok: true, status: 200, json: async () => body }) as Response

const tool = (id: string): (typeof GENOMES_ENSEMBL_TOOLS)[number] => {
  const t = GENOMES_ENSEMBL_TOOLS.find((x) => x.id === id)
  if (!t) throw new Error(`no tool ${id}`)
  return t
}

const run = (
  id: string,
  args: Record<string, unknown>,
  fetchImpl: ReturnType<typeof vi.fn>
): Promise<unknown> =>
  new ParserEngine({
    fetchImpl: fetchImpl as unknown as typeof fetch,
    retries: 0
  }).call(tool(id), args, {})

describe('ensembl version handling', () => {
  it('strips a numeric version suffix from the lookup request URL', async () => {
    const fetchImpl = vi.fn().mockResolvedValueOnce(jsonRes({ id: 'ENST00000422447' }))
    await run('ensembl_lookup', { query: 'ENST00000422447.8' }, fetchImpl)

    const url = String(fetchImpl.mock.calls[0][0])
    expect(url).toContain('/lookup/id/ENST00000422447')
    expect(url).not.toContain('ENST00000422447.8')
    // Routed as a stable ID, not downgraded to the symbol endpoint.
    expect(url).not.toContain('/lookup/symbol/')
  })

  it('strips a numeric version suffix from the cross-reference request URL and echoes the original query', async () => {
    const fetchImpl = vi.fn().mockResolvedValueOnce(jsonRes([]))
    const out = (await run('ensembl_xrefs', { stable_id: 'ENST00000422447.8' }, fetchImpl)) as {
      stable_id: string
    }

    const url = String(fetchImpl.mock.calls[0][0])
    expect(url).toContain('/xrefs/id/ENST00000422447')
    expect(url).not.toContain('ENST00000422447.8')
    // The returned record still reports exactly what the caller asked about.
    expect(out.stable_id).toBe('ENST00000422447.8')
  })

  it('strips a numeric version suffix from the sequence request URL and echoes the original query', async () => {
    const fetchImpl = vi
      .fn()
      .mockResolvedValueOnce(jsonRes({ id: 'ENST00000422447', molecule: 'dna', seq: 'ACGT' }))
    const out = (await run(
      'ensembl_sequence',
      { stable_id: 'ENST00000422447.8', seq_type: 'cdna' },
      fetchImpl
    )) as { query: string }

    const url = String(fetchImpl.mock.calls[0][0])
    expect(url).toContain('/sequence/id/ENST00000422447?type=cdna')
    expect(url).not.toContain('ENST00000422447.8')
    expect(out.query).toBe('ENST00000422447.8')
  })

  it('sends an LRG id unchanged on the stable-ID route', async () => {
    const fetchImpl = vi.fn().mockResolvedValueOnce(jsonRes({ id: 'LRG_299' }))
    await run('ensembl_lookup', { query: 'LRG_299' }, fetchImpl)

    const url = String(fetchImpl.mock.calls[0][0])
    expect(url).toContain('/lookup/id/LRG_299')
    expect(url).not.toContain('/lookup/symbol/')
  })

  it('routes a plain gene symbol to the symbol endpoint, untouched', async () => {
    const fetchImpl = vi.fn().mockResolvedValueOnce(jsonRes({ id: 'ENSG00000157764' }))
    await run('ensembl_lookup', { query: 'BRAF' }, fetchImpl)

    const url = String(fetchImpl.mock.calls[0][0])
    expect(url).toContain('/lookup/symbol/homo_sapiens/BRAF')
    expect(url).not.toContain('/lookup/id/')
  })
})
