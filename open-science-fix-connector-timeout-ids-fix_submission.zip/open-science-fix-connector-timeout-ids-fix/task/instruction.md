## Task

three reproducible integration failures have turned up in notebook Connector calls.

Ensembl breaks when a stable ID comes back with a version suffix. if a call returns something like `ENST00000422447.8` and that ID is fed straight into a follow-up lookup, cross-reference, or sequence call, the follow-up fails. plain unversioned IDs and symbol lookups are unaffected.

when an upstream request burns through its whole retry budget, all we surface is a generic "operation was aborted". that reads like the notebook itself timed out, and says nothing about which request failed or that the budget ran out.

and a response that starts arriving then stalls partway through the body hangs until the outer notebook execution deadline trips, instead of giving up on its own.

leave the per-request timeout duration and retry count where they are; this isn't a retuning, and the notebook execution deadline stays the overall ceiling. tools that fan out into several upstream requests shouldn't start handing back partial results either.

everything's offline with deps installed, so the repo's test suite reproduces and confirms these. dig in and fix.
