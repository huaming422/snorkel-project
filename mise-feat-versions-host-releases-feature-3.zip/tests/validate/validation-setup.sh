#!/usr/bin/env bash
# Validation setup: runs after the patch is applied, before the stories.
#
# One job: rebuild the `mise` binary from the current source, so the
# stories drive the code under test. The build is incremental — the image
# baked a target/debug/mise built at the base commit and warmed the cargo registry, so only the
# touched crates recompile + relink.
#
# The stories need no on-disk fixtures: mock_release_server.py synthesizes every
# host response at runtime, and test_harness.py drives the freshly built binary
# in a throwaway isolated HOME. So this script only builds and smoke-checks.
#
# Idempotent: re-running just re-builds (the cargo cache survives).
set -euo pipefail

REPO=/repo/mise
# The harness resolves the binary from CARGO_TARGET_DIR (image Dockerfile ENV).
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export PATH="$CARGO_HOME/bin:$PATH"

MISE_BIN="$CARGO_TARGET_DIR/debug/mise"

echo "validation-setup: rustc=$(rustc --version 2>&1 | head -1)"
echo "validation-setup: cargo=$(cargo --version 2>&1 | head -1)"

# Build the mise binary from the current source (incremental, locked to the
# committed Cargo.lock so the dependency graph matches the pre-warmed cache).
echo "validation-setup: building mise (incremental)..."
( cd "$REPO" && cargo build --locked --bin mise 2>&1 | tail -8 )

test -x "$MISE_BIN" || {
    echo "ERROR: mise binary missing at $MISE_BIN after cargo build" >&2
    exit 1
}
echo "validation-setup: mise built at $MISE_BIN ($("$MISE_BIN" --version 2>&1 | head -1))"

# Smoke guard: the binary must at least run. If `mise --version` itself fails,
# every story would fail with the same opaque error — surface it here instead.
"$MISE_BIN" --version >/dev/null || {
    echo "ERROR: '$MISE_BIN --version' failed" >&2
    exit 1
}

# Verifier interpreter the harness launches the mock with (honours
# VERIFIER_PYTHON; falls back to python3). Confirm it exists so the mock can
# start.
VERIFIER_PYTHON="${VERIFIER_PYTHON:-/opt/tooling/venv/bin/python}"
if [ -x "$VERIFIER_PYTHON" ]; then
    echo "validation-setup: verifier python=$("$VERIFIER_PYTHON" --version 2>&1)"
else
    echo "validation-setup: VERIFIER_PYTHON ($VERIFIER_PYTHON) not executable; harness will fall back to python3" >&2
fi

echo "validation-setup: done."
