#!/usr/bin/env bash
#
# Build and regression check.
#
# Confirms the change compiles and the project's own
# version-resolution / HTTP unit tests still pass. This is a stable,
# implementation-agnostic interface: it drives `cargo` the same way the
# project's CI does, naming no new symbol and asserting nothing
# about which files changed. It acts as a build check and as a regression guard
# against edits that break the surrounding modules.
#
# The runner's cwd is {repo_dir} (/repo/mise). The image pre-builds the full
# workspace at the base commit and warms the cargo registry, so a warm
# incremental build + the targeted unit tests finish well inside the timeout.
#
# Exit codes:
#   0 — binary builds and the mise crate's unit tests pass
#   non-zero — propagates the cargo failure

set -euo pipefail

# Toolchain onto PATH (each verifier phase gets a fresh shell); paths match
# the image Dockerfile's ENV block.
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export PATH="$CARGO_HOME/bin:$PATH"

# Run from the repo root (the runner already sets cwd to {repo_dir}, but be
# explicit so the script is robust if invoked directly).
cd /repo/mise

echo "verify: building mise binary (cargo build --locked --bin mise)"
cargo build --locked --bin mise

echo "verify: running mise crate unit tests for the release-metadata module"
# mise is a binary-only crate (no library target), so its in-tree unit tests
# (#[cfg(test)] modules) live in the binary target and are selected with
# --bins plus a name filter.
#
# The check runs the release-metadata module's own unit tests:
#   versions_host::   (shared-host repo split, path-segment encoding, and the
#                      release URL / tag validation this change introduces)
# These are pure-logic tests (string validation and encoding) that run
# deterministically with no HOME, filesystem, network, or process-global state.
#
# Scope rationale: the whole-binary `cargo build` above already compiles every
# touched file (backend/github.rs, backend/mod.rs, github.rs, tool_version.rs,
# versions_host.rs), so any compilation break anywhere is caught regardless of
# the test filter. Running the crate's FULL unit-test set as the regression
# check is NOT hermetic — many unrelated modules (config-file loading,
# task-script parsing, age decryption) assume a real HOME/keyring/filesystem
# and panic under the sandbox, and some touched-area tests depend on a
# process-global install-path cache + the filesystem and so flake under
# parallel execution. Neither is a behavioural regression. The end-to-end
# release-routing behaviour (host order, fallback, validation rejections,
# exact-version fast path) is exercised separately by the behaviour stories
# driving the real binary, so this check only has to confirm the change compiles
# and the new release-metadata validation logic still holds. The trailing "::"
# pins the module boundary.
cargo test --locked -p mise --bins -- versions_host::
