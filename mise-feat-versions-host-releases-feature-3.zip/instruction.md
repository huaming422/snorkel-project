## Task

GitHub rate-limits anonymous API calls hard, so installs of GitHub-hosted tools in CI and Docker builds without a token fail every so often. The calls that matter here fetch a release and its assets.

We run a shared versions host that caches this data. It serves a release at https://mise-versions.jdx.dev/api/github/repos/OWNER/REPO/releases/TAG as JSON in the same shape as GitHub's release object. TAG can be latest; the answer then carries whatever concrete tag the host currently considers latest, the same way GitHub's own /releases/latest never echoes back the literal word "latest".

Signature and attestation verification is out of scope.

## User stories / requirements

- Installing a GitHub-backed tool whose repo is public, or simply checking its latest version, reaches the shared versions host before the public GitHub API whenever the host can serve the release metadata: the very first request for it lands on the versions host, not on api.github.com.
- mise still falls back to the public API when the versions host can't produce the metadata, whether that's a 404, a 429, or any other failure, and the install finishes cleanly with no error or warning reaching the user.
- Metadata the versions host can't be trusted on (download URLs pointing at a different host, owner, repo or release than the one being installed, or a release with no downloadable assets at all) gets thrown out, and mise resolves through the GitHub API instead.
- mise discards a versions-host release whose tag doesn't match the one requested, and resolves through the GitHub API instead.
- For a tool resolved against a non-public GitHub API host, GitHub Enterprise or any other custom API base, mise skips the versions host entirely and talks to the configured host directly, just as before.
- mise leaves the versions host alone for release metadata whenever it's turned off by setting, or mise itself is offline or in prefer-offline mode.
- A fully pinned exact version of a public GitHub-backed tool, a three-part X.Y.Z for instance, gets proven with one release lookup rather than a fetch of the whole release list, and that lookup tries the versions host first, the same as any other release lookup. When it comes up empty, mise drops back to the ordinary path, where a pin can still land on a longer newest tag.
