#!/usr/bin/env bash
# Pre-compile the test binary so the verifier skips the cold compile.
# Runs before the verifier. The image warmed the cargo registry and target
# cache at the base commit, so source changes may require recompilation.
# Offline-first (the closure is already baked), with a
# logged online fallback in case something incidental is missing.
set -euo pipefail

cd /repo/typst

build_tests() {
    cargo test --workspace --locked "$@" --no-run
}

# Offline-first: everything the agent needs to build and run the math suite is
# already in the image.
if build_tests --offline > /tmp/test-setup-build.log 2>&1; then
    echo "test-setup: offline build of tests succeeded"
else
    echo "test-setup: offline build failed; retrying online" >&2
    tail -40 /tmp/test-setup-build.log >&2 || true
    build_tests > /tmp/test-setup-build-online.log 2>&1 || {
        echo "test-setup: online build of tests also failed" >&2
        tail -80 /tmp/test-setup-build-online.log >&2
        exit 1
    }
    echo "test-setup: online build of tests succeeded"
fi
