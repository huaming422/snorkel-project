// Behavioral verifier for typst-fix-math-stretch-fallback.
//
// Each test is an assertion-only (`paged empty`) case in typst's custom test
// harness: it measures a rendered math equation through the public `measure`
// interface and asserts the stretched element reaches the extent the correct
// typesetting produces. No reference image is needed; a wrong extent fails the
// assertion loudly.
//
// Thresholds were measured empirically across three builds (STIX Two Math, the
// test world: 120pt page, 10pt margins -> 100pt inner width, 10pt font):
//   * pre-fix repo   (the bug: stretch gives up on substituted glyphs)
//   * correct fix    (stretch grows the element to span its content)
//   * naive-wrong    (unconditionally drop the alternate glyph shapes)
// Bands are chosen to accept the correct extent and reject BOTH the pre-fix bug
// and the over-correction, coupling only to the public layout surface
// (lr / sqrt / sscript / hat / script + measure).

--- verify-stretch-fallback-delimiter paged empty ---
// A delimiter + radical around a fraction with a tall subscript must grow to
// span the content. pre-fix ~19.83pt; correct ~24.28pt.
#show math.equation: set text(font: "STIX Two Math")
#context {
  let h = measure($ lr(a / b|)_sqrt(c / d) $).height
  assert(h > 22pt, message: "delimiter+radical eqn height " + repr(h) + " not > 22pt (pre-fix ~19.83pt; correct ~24.28pt)")
}

--- verify-stretch-fallback-explicit paged empty ---
// A stretch forced at script size. pre-fix ~11.02pt; correct ~13.46pt. The
// naive over-correction collapses this to ~10.63pt, so it is rejected here too.
#show math.equation: set text(font: "STIX Two Math")
#context {
  let h = measure($ sscript(sqrt(a / b) quad (c / d)) $).height
  assert(h > 11.5pt, message: "sscript radical eqn height " + repr(h) + " not > 11.5pt (pre-fix ~11.02pt; correct ~13.46pt)")
}

--- verify-accent-flattened-fallback paged empty ---
// A wide/flattened accent must stretch taller. pre-fix ~8.40pt; correct ~9.37pt.
// Measured by height: the stretchable accent variant is taller than the
// flat base glyph (the whole-equation width is clamped to the base advance).
#show math.equation: set text(font: "STIX Two Math")
#context {
  let h = measure($ hat(A, size: #2em) $).height
  assert(h > 8.9pt, message: "stretched hat accent height " + repr(h) + " not > 8.9pt (pre-fix ~8.40pt; correct ~9.37pt)")
}

--- verify-no-fallback-when-sufficient paged empty ---
// Over-correction guard (pass-to-pass): no stretch is needed here, so the
// alternate script-size glyph shapes must be kept exactly as today. The correct
// build measures ~20.45pt wide / ~8.77pt tall; the naive "disable the alternate
// shapes" solution collapses the width to ~18.42pt and is rejected by the band.
#show math.equation: set text(font: "STIX Two Math")
#context {
  let m = measure($ script(sqrt(x) (a)) $)
  assert(m.width > 20pt and m.width < 21pt, message: "guard width " + repr(m.width) + " outside [20,21]pt (correct ~20.45pt; naive disable ~18.42pt)")
  assert(m.height > 8.5pt and m.height < 9pt, message: "guard height " + repr(m.height) + " outside [8.5,9]pt (correct ~8.77pt)")
}

--- verify-noto-script-delimiter paged empty ---
// Exercise the same reported script-size delimiter failure in a second bundled
// math font. Compare two public size requests within that font, avoiding an
// exact glyph metric or a dependency on the reference implementation's shape.
#show math.equation: set text(font: "Noto Sans Math")
#context {
  let small = measure($ script(stretch(|, size: #1em)) $).height
  let large = measure($ script(stretch(|, size: #3em)) $).height
  assert(large > small + 7pt, message: "Noto script delimiter did not grow: " + repr(small) + " -> " + repr(large))
}
