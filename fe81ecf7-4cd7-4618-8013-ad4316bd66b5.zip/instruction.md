## Task

Math layout is visibly wrong for some fonts. With STIX Two Math selected for an equation, elements that should stretch remain too short for the material they surround. This affects delimiters beside fractions with tall subscripts, radicals over tall expressions, and wide accents such as `hat`.

Here is a small example:

```typ
#show math.equation: set text(font: "STIX Two Math")
$ lr(a / b|)_sqrt(c / d) $
```

In that output, the `|` and the radical fail to reach across the tall fraction.

The same documents look correct with New Computer Modern Math, and LaTeX typesets the same equations correctly. Please investigate and repair the stretching failure for the affected math fonts.

Noto Sans Math also shows the problem with delimiters in script-sized math. A delimiter requested at a larger size should visibly grow there.
