## Task

Add SQLite's UPDATE ... FROM to the engine, so a table can be updated from values in other tables in one statement. Right now any UPDATE with a FROM clause is refused. Wherever SQLite already settles how the new form behaves, do what SQLite does.

An UPDATE without FROM should give the results it gives today wherever those already match SQLite.

## User stories / requirements

- With a FROM clause, only the target rows the join finds a partner for get changed, and only in the columns listed in SET. The rest of the target stays as it was. A new value may use the source's columns, the target's own, or both in one expression.
- The source after FROM can be anything a SELECT could join: several tables, a derived table or CTE, a grouped aggregate, or VALUES rows, combined by comma, INNER JOIN, USING or NATURAL. Names resolve as in a SELECT, so an unqualified name on both sides is an ambiguity error. The source's own ON clauses can't refer to the target, and FROM can repeat the target's table only under a name the target isn't using.
- All reads of the target during the statement see its old contents, even when the target appears again in FROM under another alias or one changed row would otherwise feed another. If many source rows match one target row, it still changes once, taking its values from any one of them.
- With RETURNING, the statement hands back the target rows as they are after the change, in any order. The list may use the target's columns and subqueries that refer to the target. Asking it for anything from the FROM side fails with an error.
- Going through FROM must leave the target as sound as an ordinary UPDATE does. Its plain, partial and expression indexes keep matching the table, CHECK, NOT NULL and STRICT typing reject bad values, OR IGNORE and OR REPLACE work as usual, foreign-key actions run, and row triggers fire before and after with the new values.
