"""Validation harness for the turso UPDATE ... FROM feature.

Everything goes through one interface: SQL text in, result rows out. The
harness is a thin subprocess wrapper around the built `tursodb` CLI (package
`turso_cli`). It takes a SQL script and returns the result rows plus a success
flag, and it uses no symbol, path or type from the engine's internals.

The CLI is used because the behavior is defined by SQL alone, and the CLI is
the highest-level place it can be seen. It needs no crate features and no
knowledge of internal types.

CLI contract this harness relies on (all pre-existing CLI behavior):
  - `tursodb <db> -q -m list` runs SQL from stdin against <db>.
  - `:memory:` gives a fresh, isolated in-memory database per invocation, so
    cases never share state.
  - `-m list` (OutputMode::List) prints one result row per line, cells joined
    by a single `|`, NO header row, and renders NULL as an EMPTY field.
  - All statements in the script run in order over one connection, so a
    trailing SELECT observes the effects of a preceding UPDATE.
  - On the first statement that errors, the engine prints the error report and
    the process exits non-zero; later statements do not run. The error text is
    emitted on the CLI's writer. We capture stdout+stderr together so the
    message is available regardless of which stream carries it.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path


def _resolve_tursodb() -> str:
    """Locate the pre-built tursodb binary.

    The image sets CARGO_TARGET_DIR (=/opt/cache/cargo-target); tests/test-setup.sh
    builds tursodb there offline-first. Fall back to the in-tree target dir if
    CARGO_TARGET_DIR is unset.
    """
    candidates = []
    target_dir = os.environ.get("CARGO_TARGET_DIR")
    if target_dir:
        candidates.append(Path(target_dir) / "debug" / "tursodb")
    candidates.append(Path("/opt/cache/cargo-target/debug/tursodb"))
    candidates.append(Path("/repo/turso/target/debug/tursodb"))
    for c in candidates:
        if c.is_file() and os.access(c, os.X_OK):
            return str(c)
    # Last resort: PATH lookup, so a helpful error surfaces if nothing is built.
    return "tursodb"


TURSODB = _resolve_tursodb()

# A single SQL script should never take long against an in-memory database.
_TIMEOUT_SEC = 60


def run_sql(sql: str) -> dict:
    """Execute a SQL script against a fresh in-memory database.

    Returns a dict with a uniform shape for every call:
      {
        "ok": bool,          # True iff every statement ran without error
        "rows": list[str],   # result rows, one "|"-joined string per row,
                             #   in statement/row order (empty when ok is False)
        "error": str,        # combined stdout+stderr when ok is False, else ""
      }

    Notes for callers:
      - Each cell is already a string. NULL appears as an empty field, e.g.
        a row (3, NULL) is the string "3|".
      - `rows` is the concatenation of every row-producing statement's output
        (SELECT and UPDATE ... RETURNING both produce rows), in order.
      - For an error case, assert `ok is False`, and when the case names an
        existing engine diagnostic (e.g. "ambiguous column name",
        "NOT NULL constraint failed"), also assert that `error` contains it.
    """
    proc = subprocess.run(
        [TURSODB, ":memory:", "-q", "-m", "list"],
        input=sql,
        text=True,
        capture_output=True,
        timeout=_TIMEOUT_SEC,
    )
    ok = proc.returncode == 0
    combined = (proc.stdout or "") + (proc.stderr or "")
    rows = [line for line in (proc.stdout or "").splitlines()] if ok else []
    return {
        "ok": ok,
        "rows": rows,
        "error": "" if ok else combined,
    }
