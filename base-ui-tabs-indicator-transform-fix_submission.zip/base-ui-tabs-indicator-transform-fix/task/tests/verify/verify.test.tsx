// @ts-nocheck
//
// Behavioral verifier for the Tabs highlight positioning fix.
//
// Every assertion drives the real, pre-existing public component
// (`Tabs.Root` / `Tabs.List` / `Tabs.Tab` / `Tabs.Indicator`) rendered under
// the repository's own real-browser test tier (Chromium via Playwright,
// selected with VITEST_ENV=chromium). Nothing here imports the geometry
// helpers the fix may introduce — the highlight is observed only through its
// rendered box and the public CSS variables it exposes, so any implementation
// that keeps the highlight aligned passes regardless of internal structure.
//
// Observation strategy: a sibling box ("bubble") is laid over the active tab
// using the CSS variables the indicator publishes, exactly as a consumer
// would. Because the bubble and the active tab share any ancestor transform,
// their on-screen rectangles coincide when (and only when) the highlight is
// positioned correctly — a transform-independent proof of alignment.
//
// fail_to_pass group ("rendering"): the transformed-ancestor cases (2D/3D
// rotation, flip, rotate/scale longhands, offset-relative-to-list) are visibly
// off before the fix — a single scalar scale cannot invert a projected-geometry
// warp. The scrolled-container and tab-local-translation cases in this group
// land correctly for a single static render even before the fix, but they guard
// against an incomplete or over-corrected fix: one that reconciles the two
// offsets but forgets to account for the scroll, or for the tab's own
// translation (including the translate longhand and border-box percentages),
// drops the highlight to the layout slot and fails them.
//
// pass_to_pass guards: the flat/scaled CSS-variable exactness checks and the
// pre-hydration execution checks. They keep both a naive "always use the
// layout slot" over-correction (which loses the sub-pixel-precise flat values)
// and a broken pre-hydration path from scoring full marks.

import * as React from 'react';
import { afterEach, expect } from 'vitest';
import { Tabs } from '@base-ui/react/tabs';
import { waitFor, screen } from '@mui/internal-test-utils';
import { createRenderer, isJSDOM } from '#test-utils';
import { getCssDimensions } from '../../utils/getCssDimensions';
import { script as generatedPrehydrationScript } from './prehydrationScript.min';

describe('<Tabs.Indicator /> positioning', () => {
  const { render } = createRenderer();

  // These behaviors are only observable in a real browser: a jsdom environment
  // returns zeroed rects and does not apply CSS transforms, so the transform
  // cases cannot be exercised there.
  describe.skipIf(isJSDOM)('rendering', () => {
    function assertSize(actual: string, expected: number) {
      const actualNumber = parseFloat(actual);
      expect(Math.abs(actualNumber - expected)).toBeLessThanOrEqual(0.01);
    }

    function assertBubblePositionVariables(
      bubble: HTMLElement,
      tabList: HTMLElement,
      activeTab: HTMLElement,
    ) {
      const tabRect = activeTab.getBoundingClientRect();
      const tabListRect = tabList.getBoundingClientRect();
      const { width: tabWidth, height: tabHeight } = getCssDimensions(activeTab);
      const { width: tabListWidth, height: tabListHeight } = getCssDimensions(tabList);
      const scaleX = tabListWidth > 0 ? tabListRect.width / tabListWidth : 1;
      const scaleY = tabListHeight > 0 ? tabListRect.height / tabListHeight : 1;

      const relativeLeft =
        (tabRect.left - tabListRect.left) / scaleX + tabList.scrollLeft - tabList.clientLeft;
      const relativeTop =
        (tabRect.top - tabListRect.top) / scaleY + tabList.scrollTop - tabList.clientTop;
      const relativeRight = tabList.scrollWidth - relativeLeft - tabWidth;
      const relativeBottom = tabList.scrollHeight - relativeTop - tabHeight;

      const bubbleComputedStyle = window.getComputedStyle(bubble);
      assertSize(bubbleComputedStyle.getPropertyValue('--active-tab-left'), relativeLeft);
      assertSize(bubbleComputedStyle.getPropertyValue('--active-tab-right'), relativeRight);
      assertSize(bubbleComputedStyle.getPropertyValue('--active-tab-top'), relativeTop);
      assertSize(bubbleComputedStyle.getPropertyValue('--active-tab-bottom'), relativeBottom);
      assertSize(bubbleComputedStyle.getPropertyValue('--active-tab-width'), tabWidth);
      assertSize(bubbleComputedStyle.getPropertyValue('--active-tab-height'), tabHeight);
    }

    // Lays a box over the active tab from the published CSS variables — the same
    // way the component's consumers place the visible highlight.
    const STYLED_INDICATOR_CSS = `
      [data-testid="bubble"] {
        position: absolute;
        top: 0;
        left: 0;
        width: var(--active-tab-width);
        height: var(--active-tab-height);
        transform: translate(var(--active-tab-left), var(--active-tab-top));
      }
    `;

    // Selects the last tab on purpose: its offset is non-zero, so a highlight
    // positioned from the wrong geometry lands visibly away from it. The first
    // tab sits at the origin and would be matched even by a broken computation.
    function renderTransformedTabs(
      wrapperStyle: React.CSSProperties,
      tabsListStyle: React.CSSProperties = { display: 'flex', position: 'relative' },
    ) {
      return render(
        <React.Fragment>
          <style>{STYLED_INDICATOR_CSS}</style>
          <div style={wrapperStyle}>
            <Tabs.Root value={3}>
              <Tabs.List style={tabsListStyle}>
                <Tabs.Tab value={1} style={{ width: '80px', height: '32px' }}>
                  One
                </Tabs.Tab>
                <Tabs.Tab value={2} style={{ width: '80px', height: '32px' }}>
                  Two
                </Tabs.Tab>
                <Tabs.Tab value={3} style={{ width: '80px', height: '32px' }}>
                  Three
                </Tabs.Tab>
                <Tabs.Indicator data-testid="bubble" />
              </Tabs.List>
            </Tabs.Root>
          </div>
        </React.Fragment>,
      );
    }

    function waitForEdgeToMatch(
      edge: 'left' | 'top' | 'right' | 'bottom',
      bubble: HTMLElement,
      activeTab: HTMLElement,
    ) {
      return waitFor(() => {
        const bubbleRect = bubble.getBoundingClientRect();
        const tabRect = activeTab.getBoundingClientRect();
        expect(Math.abs(bubbleRect[edge] - tabRect[edge])).toBeLessThanOrEqual(1);
      });
    }

    // The highlight's rendered box must coincide with the active tab's box.
    // Both share the ancestor transform, so coincidence proves correct
    // positioning no matter what transform is in effect.
    async function waitForBubbleToOverlapActiveTab(bubble: HTMLElement, activeTab: HTMLElement) {
      await waitForEdgeToMatch('left', bubble, activeTab);
      await waitForEdgeToMatch('top', bubble, activeTab);
      await waitForEdgeToMatch('right', bubble, activeTab);
      await waitForEdgeToMatch('bottom', bubble, activeTab);
    }

    // ----- fail_to_pass: the highlight must stay on the active tab -----
    // The transformed-ancestor cases below are visibly off before the fix. The
    // scroll and tab-local-translate cases render correctly for a single static
    // frame pre-fix, but fail any fix that reconciles the offsets without
    // handling the scroll or the tab's own translation (longhand + border-box %).

    it('accounts for a scrolled container between the tab list and the active tab', async () => {
      await render(
        <React.Fragment>
          <style>{STYLED_INDICATOR_CSS}</style>
          <Tabs.Root value={3}>
            <Tabs.List style={{ display: 'flex', position: 'relative' }}>
              {/* 240px of tabs inside a 200px viewport, so the container scrolls by 40px. */}
              <div
                data-testid="scroller"
                style={{ display: 'flex', width: '200px', overflowX: 'auto' }}
              >
                <Tabs.Tab value={1} style={{ width: '80px', height: '32px', flexShrink: 0 }}>
                  One
                </Tabs.Tab>
                <Tabs.Tab value={2} style={{ width: '80px', height: '32px', flexShrink: 0 }}>
                  Two
                </Tabs.Tab>
                <Tabs.Tab value={3} style={{ width: '80px', height: '32px', flexShrink: 0 }}>
                  Three
                </Tabs.Tab>
              </div>
              <Tabs.Indicator data-testid="bubble" />
            </Tabs.List>
          </Tabs.Root>
        </React.Fragment>,
      );

      const scroller = screen.getByTestId('scroller');
      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[2];

      scroller.scrollLeft = 40;
      // Scrolling alone does not notify the indicator — only tab resizes do — so
      // nudge the active tab to flush the scrolled position through a recompute.
      activeTab.style.width = '84px';

      await waitForBubbleToOverlapActiveTab(bubble, activeTab);
    });

    it('overlays the active tab when an ancestor has a 2D rotation', async () => {
      await renderTransformedTabs({ transform: 'rotate(40deg)' });

      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[2];

      await waitForBubbleToOverlapActiveTab(bubble, activeTab);
      expect(bubble).not.toHaveAttribute('hidden');
    });

    it('overlays the active tab when an ancestor has a size-preserving flip', async () => {
      await renderTransformedTabs({ transform: 'scaleX(-1)' });

      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[2];

      await waitForBubbleToOverlapActiveTab(bubble, activeTab);
      expect(bubble).not.toHaveAttribute('hidden');
    });

    it('sets transformed offsets relative to the tab list when the list is not the offset parent', async () => {
      await renderTransformedTabs(
        { position: 'relative', transform: 'rotate(40deg)' },
        { display: 'flex', marginLeft: '40px' },
      );

      const bubble = screen.getByTestId('bubble');

      await waitFor(() => {
        const bubbleComputedStyle = window.getComputedStyle(bubble);
        assertSize(bubbleComputedStyle.getPropertyValue('--active-tab-left'), 160);
      });
      await waitFor(() => {
        const bubbleComputedStyle = window.getComputedStyle(bubble);
        assertSize(bubbleComputedStyle.getPropertyValue('--active-tab-top'), 0);
      });
    });

    it('overlays the active tab when an ancestor uses the rotate longhand', async () => {
      await renderTransformedTabs({ rotate: '40deg' });

      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[2];

      await waitForBubbleToOverlapActiveTab(bubble, activeTab);
      expect(bubble).not.toHaveAttribute('hidden');
    });

    it('overlays the active tab when an ancestor uses a flipping scale longhand', async () => {
      await renderTransformedTabs({ scale: '-1 1' });

      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[2];

      await waitForBubbleToOverlapActiveTab(bubble, activeTab);
      expect(bubble).not.toHaveAttribute('hidden');
    });

    it('overlays the active tab when an ancestor has a 3D rotation', async () => {
      await renderTransformedTabs({ transform: 'perspective(600px) rotateY(35deg)' });

      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[2];

      await waitForBubbleToOverlapActiveTab(bubble, activeTab);
      expect(bubble).not.toHaveAttribute('hidden');
    });

    it('follows the active tab when it has its own transform translation', async () => {
      await render(
        <React.Fragment>
          <style>{STYLED_INDICATOR_CSS}</style>
          <Tabs.Root value={3}>
            <Tabs.List style={{ display: 'flex', position: 'relative' }}>
              <Tabs.Tab value={1} style={{ width: '80px', height: '32px' }}>
                One
              </Tabs.Tab>
              <Tabs.Tab value={2} style={{ width: '80px', height: '32px' }}>
                Two
              </Tabs.Tab>
              <Tabs.Tab
                value={3}
                style={{
                  width: '80px',
                  height: '32px',
                  transform: 'translateX(12px) translateY(4px)',
                }}
              >
                Three
              </Tabs.Tab>
              <Tabs.Indicator data-testid="bubble" />
            </Tabs.List>
          </Tabs.Root>
        </React.Fragment>,
      );

      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[2];

      await waitForBubbleToOverlapActiveTab(bubble, activeTab);
    });

    it('follows the active tab when it uses the translate longhand', async () => {
      await render(
        <React.Fragment>
          <style>{STYLED_INDICATOR_CSS}</style>
          <Tabs.Root value={3}>
            <Tabs.List style={{ display: 'flex', position: 'relative' }}>
              <Tabs.Tab value={1} style={{ width: '80px', height: '32px' }}>
                One
              </Tabs.Tab>
              <Tabs.Tab value={2} style={{ width: '80px', height: '32px' }}>
                Two
              </Tabs.Tab>
              <Tabs.Tab value={3} style={{ width: '80px', height: '32px', translate: '12px 4px' }}>
                Three
              </Tabs.Tab>
              <Tabs.Indicator data-testid="bubble" />
            </Tabs.List>
          </Tabs.Root>
        </React.Fragment>,
      );

      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[2];

      await waitForBubbleToOverlapActiveTab(bubble, activeTab);
    });

    it('follows the active tab when the translate longhand uses percentages', async () => {
      await render(
        <React.Fragment>
          <style>{STYLED_INDICATOR_CSS}</style>
          <Tabs.Root value={3}>
            <Tabs.List style={{ display: 'flex', position: 'relative' }}>
              <Tabs.Tab value={1} style={{ width: '80px', height: '32px' }}>
                One
              </Tabs.Tab>
              <Tabs.Tab value={2} style={{ width: '80px', height: '32px' }}>
                Two
              </Tabs.Tab>
              {/* 50% of 80px = 40px across, 25% of 32px = 8px down. */}
              <Tabs.Tab value={3} style={{ width: '80px', height: '32px', translate: '50% 25%' }}>
                Three
              </Tabs.Tab>
              <Tabs.Indicator data-testid="bubble" />
            </Tabs.List>
          </Tabs.Root>
        </React.Fragment>,
      );

      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[2];

      await waitForBubbleToOverlapActiveTab(bubble, activeTab);
    });

    // ----- pass_to_pass: regression guards -----

    it('sets sub-pixel-precise CSS variables with no ancestor transform', async () => {
      await render(
        <Tabs.Root value={2}>
          <Tabs.List>
            <Tabs.Tab value={1}>One</Tabs.Tab>
            <Tabs.Tab value={2}>Two</Tabs.Tab>
            <Tabs.Tab value={3}>Three</Tabs.Tab>
            <Tabs.Indicator data-testid="bubble" />
          </Tabs.List>
        </Tabs.Root>,
      );

      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[1];
      const tabList = screen.getByRole('tablist');

      await waitFor(() => {
        assertBubblePositionVariables(bubble, tabList, activeTab);
      });
    });

    it('accounts for scroll and border when the tab list is axis-aligned scaled', async () => {
      await render(
        <div style={{ transform: 'scale(1.5)' }}>
          <Tabs.Root value={3}>
            <Tabs.List
              data-testid="tab-list"
              style={{
                width: '240px',
                display: 'flex',
                gap: '8px',
                overflowX: 'auto',
                border: '6px solid black',
                padding: '4px',
              }}
            >
              <Tabs.Tab value={1} style={{ flex: '0 0 120px' }}>
                One
              </Tabs.Tab>
              <Tabs.Tab value={2} style={{ flex: '0 0 120px' }}>
                Two
              </Tabs.Tab>
              <Tabs.Tab value={3} style={{ flex: '0 0 120px' }}>
                Three
              </Tabs.Tab>
              <Tabs.Tab value={4} style={{ flex: '0 0 120px' }}>
                Four
              </Tabs.Tab>
              <Tabs.Tab value={5} style={{ flex: '0 0 120px' }}>
                Five
              </Tabs.Tab>
              <Tabs.Indicator data-testid="bubble" />
            </Tabs.List>
          </Tabs.Root>
        </div>,
      );

      const bubble = screen.getByTestId('bubble');
      const tabList = screen.getByTestId('tab-list');
      const activeTab = screen.getAllByRole('tab')[2];

      tabList.scrollLeft = 80;

      await waitFor(() => {
        assertBubblePositionVariables(bubble, tabList, activeTab);
      });
    });

    it('falls back to offset positions when the tab list is scaled to zero', async () => {
      await render(
        <div style={{ transform: 'scale(0)' }}>
          <Tabs.Root value={2}>
            <Tabs.List
              data-testid="tab-list"
              style={{
                position: 'relative',
                width: '300px',
                display: 'flex',
                overflow: 'hidden',
              }}
            >
              <Tabs.Tab value={1} style={{ width: '100px', flexShrink: 0 }}>
                One
              </Tabs.Tab>
              <Tabs.Tab value={2} style={{ width: '100px', flexShrink: 0 }}>
                Two
              </Tabs.Tab>
              <Tabs.Indicator data-testid="bubble" />
            </Tabs.List>
          </Tabs.Root>
        </div>,
      );

      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[1];

      await waitFor(() => {
        const bubbleComputedStyle = window.getComputedStyle(bubble);
        assertSize(bubbleComputedStyle.getPropertyValue('--active-tab-left'), activeTab.offsetLeft);
      });

      const bubbleComputedStyle = window.getComputedStyle(bubble);
      assertSize(bubbleComputedStyle.getPropertyValue('--active-tab-top'), activeTab.offsetTop);
      assertSize(bubbleComputedStyle.getPropertyValue('--active-tab-width'), 100);
      expect(bubble).not.toHaveAttribute('hidden');
    });
  });

  // Pre-hydration paint: the inline script that positions the highlight before
  // the component hydrates. These exercise the pre-rendered path and keep a
  // broken offline paint from scoring full marks.
  describe.skipIf(isJSDOM)('pre-hydration script execution', () => {
    let host: HTMLDivElement;

    afterEach(() => {
      host?.remove();
    });

    function renderServerMarkup({
      hidden = false,
      activeTabStyle = 'width: 100px; height: 40px;',
    } = {}) {
      host = document.createElement('div');
      if (hidden) {
        host.style.display = 'none';
      }
      host.innerHTML =
        '<div role="tablist" style="width: 300px; height: 40px; position: relative;">' +
        `<button data-active style="${activeTabStyle} padding: 0; border: 0;">One</button>` +
        '<button style="width: 100px; height: 40px; padding: 0; border: 0;">Two</button>' +
        '<span hidden></span>' +
        '</div>';
      document.body.appendChild(host);

      const tabsList = host.querySelector<HTMLElement>('[role="tablist"]')!;
      const activeTab = host.querySelector<HTMLElement>('[data-active]')!;
      const indicator = host.querySelector<HTMLElement>('span')!;

      const scriptElement = document.createElement('script');
      scriptElement.textContent = generatedPrehydrationScript;
      // Appending an inline script executes it synchronously with
      // `document.currentScript` set.
      indicator.after(scriptElement);

      return { tabsList, activeTab, indicator };
    }

    it('positions the indicator once a hidden streamed segment becomes visible', async () => {
      const { activeTab, indicator } = renderServerMarkup({ hidden: true });

      expect(indicator).toHaveAttribute('hidden');
      host.style.display = '';

      await waitFor(() => {
        expect(indicator).not.toHaveAttribute('hidden');
      });
      expect(getComputedStyle(indicator).getPropertyValue('--active-tab-width')).toBe(
        `${activeTab.offsetWidth}px`,
      );
    });

    it('keeps observing until the active tab is fully measurable', async () => {
      // The tab has width but no height yet (e.g. styles or images still loading).
      const { activeTab, indicator } = renderServerMarkup({
        activeTabStyle: 'width: 100px; height: 0; overflow: hidden;',
      });

      await new Promise((resolve) => {
        setTimeout(resolve, 100);
      });
      expect(indicator).toHaveAttribute('hidden');

      activeTab.style.height = '40px';

      await waitFor(() => {
        expect(indicator).not.toHaveAttribute('hidden');
      });
    });
  });
});
