#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
# Brings the baked dependency closure online and makes a cache miss fail fast instead of
# reaching for a dead network. No assertion logic here.
cd /repo/base-ui

# The Chromium browser was prebaked here at image build (step 10b).
export PLAYWRIGHT_BROWSERS_PATH=/opt/ms-playwright

# Dependencies: offline-first against the image bake, logged online fallback. The first
# attempt carries --offline so a cache miss fails fast (no registry retries) during the
# smoke gate's --network none fold; the fallback drops the flag for a genuinely stale bake.
if pnpm install --offline --frozen-lockfile > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] deps satisfied from image"
elif pnpm install --frozen-lockfile >> /tmp/test-setup-install.log 2>&1; then
    echo "[test-setup] deps installed online (image bake was stale)"
else
    tail -40 /tmp/test-setup-install.log >&2; exit 1
fi
