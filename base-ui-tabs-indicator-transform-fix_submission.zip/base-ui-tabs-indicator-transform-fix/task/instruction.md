## Task

The moving highlight that sits behind the active tab in our Tabs component drifts off as
soon as the tab strip lives inside a rotated or 3D-tilted (perspective) container. On a
flat, untransformed strip it tracks the active tab just fine; tilt the surrounding surface
and the highlight ends up visibly offset from where it should be.

We're seeing the same misbehavior show up a couple of other ways: the highlight gets left
behind when the tab strip is scrolled horizontally, and it no longer follows a tab that has
its own slide/translate animation. Plain layouts have always worked, so this only turns up
once there's a transformed ancestor, horizontal scrolling, or a tab animating on its own.

Dig into why the highlight mispositions under these conditions and get it to stay aligned
with the active tab, without upsetting the normal untransformed case. This is about the
indicator's positioning behavior and shouldn't need any new public API. Heads up: it only
reproduces in a real browser, since the geometry involved can't be observed in a jsdom unit
environment.
