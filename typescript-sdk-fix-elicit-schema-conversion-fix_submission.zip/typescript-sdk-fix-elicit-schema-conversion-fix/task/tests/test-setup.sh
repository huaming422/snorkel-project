#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
cd /repo/typescript-sdk

# Dependencies: offline-first against the image bake, logged online fallback.
# The first attempt is forced offline so a cache miss fails fast rather than
# stalling on a dead network; the fallback only matters if a build runs online.
if pnpm install --offline --frozen-lockfile > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] deps satisfied from image"
elif pnpm install --frozen-lockfile >> /tmp/test-setup-install.log 2>&1; then
    echo "[test-setup] deps installed online (image bake was stale)"
else
    tail -40 /tmp/test-setup-install.log >&2; exit 1
fi

# The js runner invokes `npx vitest run <file>` from the repo root, resolving
# vitest from the root node_modules/.bin. A miss means a corrupted install;
# reinstall now rather than failing later with a confusing "command not found".
# No dist/ rebuild is needed: the verifier imports the conversion path from
# source (../../src/shared/inputRequired), and vitest transforms TypeScript on
# the fly, so the agent's source edits are observed directly.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "[test-setup] vitest binary missing from node_modules/.bin/ — image install is corrupt, reinstalling." >&2
    pnpm install --frozen-lockfile --ignore-scripts >> /tmp/test-setup-install.log 2>&1 \
        || { tail -40 /tmp/test-setup-install.log >&2; exit 1; }
fi
