## Task

our server asks clients for structured input mid-handler, and we build those requests from a validation schema (a zod object, sometimes another schema library). a couple of things are broken.

first it's backwards. if a field uses the library's real validating helpers for an email, url, date, or date-time, building the request throws before anything gets sent. attach the same format as a plain annotation and it goes through fine. the validating form fails, the bare annotation form works.

second, junk is leaking through. a strict object schema (one that forbids unknown keys) can't be carried by the restricted wire shape, so it has to be turned away by name rather than quietly stripped and sent, which would change what the schema promises. we've also seen raw library-internal objects reach the outgoing payload. and when a schema genuinely can't be represented, the error is a multi-kilobyte wall of text that never says which field is at fault.

all of this lives in how an incoming schema gets normalized into the restricted request shape; that shape and the builder we expose are fine, so leave them be. accept the validating forms, refuse cleanly and name the offending field, and keep the junk off the wire. dig in and fix it.
