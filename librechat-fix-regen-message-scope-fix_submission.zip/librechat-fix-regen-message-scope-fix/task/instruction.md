## Task

In LibreChat, assistant responses can produce interactive "artifacts" (HTML, React, or Markdown previews) in a side panel, and any response can be regenerated, branching the conversation.

In conversations with several regenerated branches, the artifact side-panel sometimes pops open on its own showing a preview from a different, already-finished response instead of the one the user is working with. It's most visible while regenerating: a new generation can open an artifact from an older response. A preview that was still "pending" on an older response can also auto-open the panel later when the user revisits that part of the conversation, as if it had just been produced.

Separately, when a regeneration fails (say the request is rejected before any reply streams back), the failed attempt sometimes shows up as a detached, orphaned message instead of staying under the turn it was regenerating.

What we want: the panel should auto-open only for the response the user is actively generating or viewing; older responses' previews stay closed until opened. A failed regeneration should stay attached to its turn. Dig in and fix it.
