/**
 * When a regeneration fails, the error turn it produces must stay parented to
 * the saved user message that started the branch — not to the temporary replay
 * copy made for the retry. Otherwise the failed response detaches from its
 * sibling thread and the merged transcript loses its ordering.
 *
 * Exercised through the module's pre-existing exported helpers
 * (`resolveErrorTurn`, `mergeErrorMessages`), asserting concrete parent ids
 * and the resulting message ordering — observable data, not flags.
 */
import { ContentTypes } from 'librechat-data-provider';
import type {
  TMessageContentParts,
  EventSubmission,
  TMessage,
} from 'librechat-data-provider';
import type { TResData } from '~/common';
import {
  buildCreatedInitialResponse,
  mergeErrorMessages,
  resolveErrorTurn,
} from '~/hooks/SSE/useEventHandlers';

describe('failed regeneration error parenting', () => {
  const userMessage = {
    messageId: 'user-1',
    conversationId: 'conversation-1',
    parentMessageId: 'ROOT',
    isCreatedByUser: true,
    text: 'Look up the issue',
    sender: 'User',
  } as unknown as TMessage;

  const initialResponse = {
    messageId: 'user-1_',
    parentMessageId: 'user-1',
    conversationId: 'conversation-1',
    isCreatedByUser: false,
    text: '',
    sender: 'Lia',
    endpoint: 'agents',
    model: 'agent_1',
  } as TMessage;

  const submission = {
    messages: [],
    userMessage,
    initialResponse,
    conversation: { conversationId: 'conversation-1' },
  } as unknown as EventSubmission;

  const streamedParts = [
    { type: ContentTypes.THINK, think: 'Checking the issue' },
    { type: ContentTypes.TEXT, text: 'Let me try the GitHub CLI from the workspace.' },
    {
      type: ContentTypes.TOOL_CALL,
      tool_call: { id: 'call-1', name: 'execute_code', args: '{}', progress: 1 },
    },
  ] as TMessageContentParts[];

  it('keeps a failed regeneration under its existing user turn when no content streamed', () => {
    const regenerateSubmission = {
      ...submission,
      isRegenerate: true,
      userMessage: {
        ...userMessage,
        messageId: 'temporary-user-id',
        overrideParentMessageId: userMessage.messageId,
      },
      initialResponse: { ...initialResponse, messageId: 'response-id_' },
    } as EventSubmission;
    const siblings = [
      { ...initialResponse, messageId: 'previous-sibling' },
      { ...initialResponse, messageId: 'response-id' },
    ];

    const failedSubmission = {
      ...regenerateSubmission,
      regenerateMessages: [userMessage, ...siblings],
    };
    const { errorResponse } = resolveErrorTurn({
      data: {
        text: 'Model spec mismatch',
        metadata: { streamStartFailed: true },
      } as unknown as TResData,
      submission: failedSubmission,
      getMessages: () => [userMessage, siblings[0], regenerateSubmission.initialResponse],
      isNewConversationRoute: false,
    });

    expect(errorResponse.messageId).toBe('response-id_');
    // Parented to the saved user turn, NOT the temporary replay copy.
    expect(errorResponse.parentMessageId).toBe(userMessage.messageId);
    expect(errorResponse.text).toBe('Model spec mismatch');
    expect(
      mergeErrorMessages({ ...failedSubmission, errorMessage: errorResponse }).map(
        (message) => message.messageId,
      ),
    ).toEqual(['user-1', 'previous-sibling', 'response-id', 'response-id_']);

    const addressed = resolveErrorTurn({
      data: {
        conversationId: 'conversation-1',
        messageId: 'response-id_',
        isCreatedByUser: false,
        text: 'Model spec mismatch',
      } as unknown as TResData,
      submission: failedSubmission,
      getMessages: () => [userMessage, regenerateSubmission.initialResponse],
      isNewConversationRoute: false,
    });
    expect(addressed.errorResponse.parentMessageId).toBe(userMessage.messageId);
  });

  it.each([
    ['transport failure', undefined],
    [
      'server-addressed failure',
      {
        conversationId: 'conversation-1',
        messageId: 'response-id_',
        isCreatedByUser: false,
        text: 'Model spec mismatch',
      },
    ],
  ])('keeps a partially streamed regeneration on its original branch after a %s', (_name, data) => {
    const regenerateSubmission = {
      ...submission,
      isRegenerate: true,
      userMessage: {
        ...userMessage,
        messageId: 'temporary-user-id',
        overrideParentMessageId: userMessage.messageId,
      },
      initialResponse: { ...initialResponse, messageId: 'response-id_' },
    } as EventSubmission;
    const streamed = { ...regenerateSubmission.initialResponse, content: streamedParts };

    const { errorResponse } = resolveErrorTurn({
      data: data as TResData | undefined,
      submission: regenerateSubmission,
      getMessages: () => [userMessage, streamed],
      isNewConversationRoute: false,
    });

    expect(errorResponse.messageId).toBe('response-id_');
    expect(errorResponse.parentMessageId).toBe(userMessage.messageId);
    expect(errorResponse.content?.at(-1)?.type).toBe(ContentTypes.ERROR);
  });

  it('resolves the same parent for a regenerate on the created-response and error paths', () => {
    const regenerateSubmission = {
      ...submission,
      isRegenerate: true,
      userMessage: {
        ...userMessage,
        messageId: 'temporary-user-id',
        overrideParentMessageId: userMessage.messageId,
      },
      initialResponse: { ...initialResponse, messageId: 'response-id_' },
    } as EventSubmission;

    const created = buildCreatedInitialResponse(regenerateSubmission);
    const { errorResponse } = resolveErrorTurn({
      data: undefined,
      submission: regenerateSubmission,
      getMessages: () => [regenerateSubmission.userMessage, regenerateSubmission.initialResponse],
      isNewConversationRoute: false,
    });

    // The optimistic created response and the failed-turn error must land on the
    // same branch parent — the saved original user turn, not the replay copy.
    expect(created.parentMessageId).toBe(userMessage.messageId);
    expect(errorResponse.parentMessageId).toBe(created.parentMessageId);
  });
});
