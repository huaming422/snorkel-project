/**
 * Message-level grouping hoists MCP image attachments out of the collapsible
 * and renders them once per message. Those hoisted groups live OUTSIDE the
 * per-part tree, so they must still learn whether their owning message is the
 * one actively streaming. When a prior response is redisplayed while a newer
 * turn regenerates, its hoisted group must read as history, not live.
 *
 * The behavior is observed through a stand-in AttachmentGroup that surfaces
 * the submission state it sees from the message context as a DOM attribute —
 * the public, observable signal the real group consumes to decide auto-open.
 */
import React from 'react';
import { RecoilRoot } from 'recoil';
import { ContentTypes } from 'librechat-data-provider';
import { render, screen } from '@testing-library/react';
import type { TAttachment, TMessageContentParts } from 'librechat-data-provider';
import ContentParts from '~/components/Chat/Messages/Content/ContentParts';

jest.mock('~/hooks', () => ({
  useLocalize: () => (key: string, values?: Record<string | number, string>) => {
    if (key === 'com_ui_ran_n_actions') {
      return `Ran ${values?.[0]} actions`;
    }
    if (key === 'com_ui_running_n_actions') {
      return `Running ${values?.[0]} actions`;
    }
    if (key === 'com_ui_n_of_n_actions_failed') {
      return `${values?.[0]}/${values?.[1]} failed`;
    }
    return key;
  },
  useExpandCollapse: (isExpanded: boolean) => ({
    style: { display: 'grid', gridTemplateRows: isExpanded ? '1fr' : '0fr' },
    ref: { current: null },
  }),
  useLazyCollapseBody: jest.requireActual('~/hooks/Messages/useLazyCollapseBody').default,
  useProgress: (initial: number) => (initial >= 1 ? 1 : initial),
  scheduleMessageContentLayoutReconcile: jest.fn(() => jest.fn()),
}));

jest.mock('~/hooks/MCP', () => {
  const mcpServerNames: string[] = [];
  return {
    useMCPIconMap: () => new Map(),
    useMCPServerNames: () => mcpServerNames,
  };
});

jest.mock('~/components/Chat/Messages/Content/ToolOutput', () => ({
  StackedToolIcons: () => <span data-testid="stacked-icons" />,
  getMCPServerName: () => '',
  ToolIcon: () => <span data-testid="tool-icon" />,
  getToolIconType: () => 'mcp',
  isError: () => false,
}));

jest.mock('~/components/Chat/Messages/Content/ToolCallInfo', () => ({
  __esModule: true,
  default: () => <div data-testid="tool-call-info" />,
}));

jest.mock('~/components/Chat/Messages/Content/ProgressText', () => ({
  __esModule: true,
  default: ({ onClick, finishedText }: { onClick?: () => void; finishedText?: string }) => (
    <div data-testid="progress-text" onClick={onClick}>
      {finishedText}
    </div>
  ),
}));

jest.mock('lucide-react', () => ({
  ...jest.requireActual('lucide-react'),
  ChevronDown: () => <span>{'chevron'}</span>,
  TriangleAlert: () => <span>{'alert'}</span>,
  Users: () => <span>{'users'}</span>,
}));

jest.mock('@librechat/client', () => ({
  useMediaQuery: () => false,
  Button: ({
    children,
    variant: _variant,
    size: _size,
    ...props
  }: React.ComponentProps<'button'> & { variant?: string; size?: string }) => (
    <button {...props}>{children}</button>
  ),
}));

jest.mock('~/components/Chat/Messages/Content/Parts', () => ({
  StreamingThoughtPeek: ({ text }: { text: string }) => (
    <div data-testid="streaming-thought-peek">{text}</div>
  ),
  /* The hoisted group surfaces the submission state it reads from the live
   * message context so the test can observe how the message is classified. */
  AttachmentGroup: ({ attachments }: { attachments?: TAttachment[] }) => {
    const { isSubmitting } = jest
      .requireActual<typeof import('~/Providers/MessageContext')>('~/Providers/MessageContext')
      .useMessageContext();
    return (
      <div
        data-testid="attachment-group"
        data-count={attachments?.length ?? 0}
        data-paths={(attachments ?? []).map((a) => a.filepath).join(',')}
        data-submitting={String(isSubmitting)}
      />
    );
  },
  ExecuteCode: () => <div data-testid="execute-code" />,
  ImageGen: () => <div data-testid="image-gen" />,
  AgentUpdate: () => <div data-testid="agent-update" />,
  EmptyText: () => <div data-testid="empty-text" />,
  Reasoning: () => <div data-testid="reasoning" />,
  ReasoningCompact: () => <div data-testid="compact-reasoning" />,
  Summary: () => <div data-testid="summary" />,
  Text: ({ text }: { text?: string }) => <div data-testid="text">{text}</div>,
  MemoryCall: ({ attachments }: { attachments?: TAttachment[] }) => (
    <div data-testid="memory-call" data-count={attachments?.length ?? 0} />
  ),
}));

jest.mock('~/components/Chat/Messages/Content/MemoryArtifacts', () => ({
  __esModule: true,
  default: () => <div data-testid="memory-artifacts" />,
}));

jest.mock('~/components/Chat/Messages/Content/WebSearch', () => ({
  __esModule: true,
  default: ({ attachments }: { attachments?: TAttachment[] }) => (
    <div data-testid="web-search" data-count={attachments?.length ?? 0} />
  ),
}));

jest.mock('~/components/Chat/Messages/Content/RetrievalCall', () => ({
  __esModule: true,
  default: () => <div data-testid="retrieval-call" />,
}));

jest.mock('~/components/Chat/Messages/Content/AgentHandoff', () => ({
  __esModule: true,
  default: () => <div data-testid="agent-handoff" />,
}));

jest.mock('~/components/Chat/Messages/Content/CodeAnalyze', () => ({
  __esModule: true,
  default: () => <div data-testid="code-analyze" />,
}));

jest.mock('~/components/Chat/Messages/Content/Image', () => ({
  __esModule: true,
  default: () => <div data-testid="image" />,
}));

jest.mock('~/components/Chat/Messages/Content/Container', () => ({
  __esModule: true,
  default: ({ children }: { children?: React.ReactNode }) => <div>{children}</div>,
}));

jest.mock('~/components/Chat/Messages/Content/SiblingHeader', () => ({
  __esModule: true,
  default: ({ agentId }: { agentId?: string }) => (
    <div data-testid="sibling-header" data-agent-id={agentId} />
  ),
}));

jest.mock('~/utils', () => {
  const actual = jest.requireActual('~/utils');
  return {
    ...actual,
    cn: (...classes: Array<string | false | null | undefined>) => classes.filter(Boolean).join(' '),
    logger: { error: jest.fn() },
  };
});

const MCP_DELIMITER = '_mcp_';

const makeMcpToolCall = (id: string): TMessageContentParts =>
  ({
    type: ContentTypes.TOOL_CALL,
    [ContentTypes.TOOL_CALL]: {
      id,
      name: `getTinyImage${MCP_DELIMITER}Everything`,
      args: '{}',
      output: 'image_returned',
    },
  }) as unknown as TMessageContentParts;

const imageAttachment = (toolCallId: string, name = 'tiny.png'): TAttachment =>
  ({
    filename: name,
    filepath: `/files/${name}`,
    width: 16,
    height: 16,
    messageId: 'm1',
    toolCallId,
    conversationId: 'c1',
  }) as unknown as TAttachment;

const renderContentParts = (props: React.ComponentProps<typeof ContentParts>) =>
  render(
    <RecoilRoot>
      <ContentParts {...props} />
    </RecoilRoot>,
  );

const baseProps = {
  messageId: 'msg1',
  isCreatedByUser: false,
  isLast: true,
  isSubmitting: false,
  showThinking: false,
  isLatestMessage: true,
};

describe('ContentParts hoisted-group submission scoping', () => {
  it('marks grouped artifacts as history while another response regenerates', () => {
    const content = [makeMcpToolCall('t1'), makeMcpToolCall('t2')];
    const attachments = [imageAttachment('t1'), imageAttachment('t2')];

    // A redisplayed, non-latest response: submitting is in flight for a
    // *different* turn, so this message's hoisted group must read as history.
    const { rerender } = renderContentParts({
      ...baseProps,
      isSubmitting: true,
      isLatestMessage: false,
      content,
      attachments,
    });
    expect(screen.getByTestId('attachment-group')).toHaveAttribute('data-submitting', 'false');

    // The same message becomes the latest/streaming one: it now reads live.
    rerender(
      <RecoilRoot>
        <ContentParts {...baseProps} isSubmitting content={content} attachments={attachments} />
      </RecoilRoot>,
    );
    expect(screen.getByTestId('attachment-group')).toHaveAttribute('data-submitting', 'true');
  });
});
