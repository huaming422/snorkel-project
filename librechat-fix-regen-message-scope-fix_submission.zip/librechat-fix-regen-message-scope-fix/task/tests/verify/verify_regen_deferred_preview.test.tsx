/**
 * Deferred-preview auto-open scoping, exercised end-to-end through the real
 * producer→consumer bridge rather than by seeding any internal signal.
 *
 * The producer hook (`useAttachmentPreviewSync`) watches a file's preview go
 * from pending→ready and, for a file that belongs to the live turn, records a
 * one-shot "just resolved" signal. The consumer card reads that signal on
 * mount and, if present for the card's own owning response, auto-opens the
 * panel even though streaming has already ended.
 *
 * Both tests DRIVE the real producer (its upstream `useFilePreview` is mocked
 * to step pending→ready) and then mount the real card, asserting only the
 * observable panel outcome (selected artifact id + visibility). Nothing here
 * constructs, seeds, or reads the producer's internal signal directly, so the
 * scoping behavior is observed, not assumed.
 *
 *   - A card whose owning response differs from the one that resolved the
 *     preview must NOT auto-open (a prior answer reusing the same file id).
 *   - A card whose owning response matches the resolved one MUST still open,
 *     even after streaming has ended and nothing is submitting.
 */
import React from 'react';
import { RecoilRoot, useRecoilValue, useSetRecoilState } from 'recoil';
import { act, render } from '@testing-library/react';
import type { MutableSnapshot } from 'recoil';
import type { TAttachment, TFile, TAttachmentMetadata, TFilePreview } from 'librechat-data-provider';
import Attachment from '~/components/Chat/Messages/Content/Parts/Attachment';
import { MessageContext } from '~/Providers/MessageContext';
import {
  MessagesViewContext,
  type MessagesViewContextValue,
} from '~/Providers/MessagesViewContext';
import useAttachmentPreviewSync from '~/hooks/Files/useAttachmentPreviewSync';
import store from '~/store';

/* Control the producer's upstream preview query so a test can step the file
 * from pending to ready and fire the resolution edge. */
let currentPreview: TFilePreview | undefined;
const mockUseFilePreview = jest.fn();
jest.mock('~/data-provider', () => ({
  useFilePreview: (...args: unknown[]) => mockUseFilePreview(...args),
}));

jest.mock('~/hooks', () => ({
  useLocalize:
    () =>
    (key: string): string =>
      key,
  useAttachmentPreviewSync: () => ({ status: 'ready', previewError: undefined, isPolling: false }),
  useExpandCollapse: (isExpanded: boolean) => ({
    style: { display: 'grid', gridTemplateRows: isExpanded ? '1fr' : '0fr' },
    ref: { current: null },
  }),
}));

jest.mock('~/components/Chat/Messages/Content/Parts/LogLink', () => ({
  useAttachmentLink: () => ({ handleDownload: jest.fn() }),
}));

jest.mock('~/components/Chat/Input/Files/FileContainer', () => ({
  __esModule: true,
  default: ({ file, displayName }: { file: { filename?: string }; displayName?: string }) => (
    <div data-testid="file-container">{displayName ?? file.filename ?? ''}</div>
  ),
}));

jest.mock('~/components/Chat/Input/Files/FilePreview', () => ({
  __esModule: true,
  default: () => <div data-testid="file-preview" />,
}));

jest.mock('~/components/Chat/Messages/Content/Image', () => ({
  __esModule: true,
  default: ({ altText }: { altText?: string }) => <img alt={altText ?? ''} data-testid="image" />,
}));

jest.mock('~/components/Messages/Content/Mermaid/Mermaid', () => ({
  __esModule: true,
  default: ({ children }: { children: string }) => <div data-testid="mermaid-render">{children}</div>,
}));

jest.mock('~/utils', () => ({
  cn: (...classes: Array<string | false | null | undefined>) => classes.filter(Boolean).join(' '),
  getFileType: () => ({ paths: [], color: '', title: 'Artifact' }),
  logger: { log: jest.fn(), warn: jest.fn(), error: jest.fn() },
  isArtifactRoute: () => false,
}));

type AttachmentFixture = TFile & TAttachmentMetadata;

const fileId = 'shared-preview';
const liveResponseId = 'live-response';

/** The pending file the producer polls (same file id as the rendered card). */
const pendingAttachment = (owner: string): AttachmentFixture =>
  ({
    user: 'user-1',
    object: 'file',
    bytes: 1024,
    embedded: false,
    usage: 0,
    file_id: fileId,
    filename: 'chart.html',
    filepath: '/uploads/chart.html',
    type: 'text/html',
    messageId: owner,
    toolCallId: 'tc-1',
    status: 'pending',
  }) as AttachmentFixture;

/** The resolved rich-preview the card renders (routes to a panel artifact). */
const resolvedCardAttachment = (owner: string): TAttachment =>
  ({
    file_id: fileId,
    filename: 'chart.html',
    filepath: '/uploads/chart.html',
    text: '<h1>resolved</h1>',
    type: 'text/html',
    messageId: owner,
  }) as TAttachment;

interface PanelSnapshot {
  visibility: boolean;
  currentArtifactId: string | null;
}

const StateProbe = ({ onSnapshot }: { onSnapshot: (snap: PanelSnapshot) => void }) => {
  const visibility = useRecoilValue(store.artifactsVisibility);
  const currentArtifactId = useRecoilValue(store.currentArtifactId);
  React.useEffect(() => {
    onSnapshot({ visibility, currentArtifactId });
  });
  return null;
};

/* Captures the global-submitting setter so a test can clear it AFTER the
 * producer has captured its mount-time classification but BEFORE the card
 * mounts — the card must see "nothing submitting" so the only path that can
 * open the panel is a consumed deferred-preview signal. */
let setGlobalSubmitting: ((v: boolean) => void) | null = null;
const SubmitBridge = () => {
  setGlobalSubmitting = useSetRecoilState(store.isSubmittingFamily(0));
  return null;
};

/* The live response's preview-sync producer. Rendered under a context that
 * marks this response as actively streaming, so the resolution edge counts as
 * a fresh result for THIS response. */
const Producer = () => {
  useAttachmentPreviewSync(pendingAttachment(liveResponseId));
  return null;
};

/**
 * Step a preview from pending→ready on the live response, then mount a card
 * owned by `cardOwner` and return the resulting panel state.
 */
function runScenario(cardOwner: string): PanelSnapshot {
  currentPreview = { file_id: fileId, status: 'pending' };
  mockUseFilePreview.mockReset();
  mockUseFilePreview.mockImplementation(() => ({ data: currentPreview, isFetching: false }));

  let snapshot: PanelSnapshot = { visibility: false, currentArtifactId: null };
  const onSnapshot = (next: PanelSnapshot) => {
    snapshot = next;
  };

  const initializeState = (snap: MutableSnapshot) => {
    // The live response is streaming when its preview starts resolving.
    snap.set(store.isSubmittingFamily(0), true);
    snap.set(store.artifactsVisibility, false);
  };

  // The live response is the conversation's active branch tail throughout —
  // supplied through MessagesViewContext the way the production tree does, so a
  // fix that scopes the deferred signal by comparing an owner to the active
  // message id resolves identically to one reading the pre-folded context flag.
  const cardIsLive = cardOwner === liveResponseId;
  const Tree = ({ showCard }: { showCard: boolean }) => (
    <MessagesViewContext.Provider
      value={{ latestMessageId: liveResponseId } as MessagesViewContextValue}
    >
      <StateProbe onSnapshot={onSnapshot} />
      <SubmitBridge />
      {/* Producer runs on the live response: every liveness channel agrees it
       * is the active turn (context isSubmitting + isLatestMessage, and it owns
       * the active latestMessageId), so a freshly-resolved preview counts. */}
      <MessageContext.Provider
        value={{
          messageId: liveResponseId,
          isExpanded: true,
          isSubmitting: true,
          isLatestMessage: true,
        }}
      >
        <Producer />
      </MessageContext.Provider>
      {showCard && (
        <MessageContext.Provider
          value={{
            messageId: cardOwner,
            isExpanded: true,
            isSubmitting: false,
            isLatestMessage: cardIsLive,
          }}
        >
          <Attachment attachment={resolvedCardAttachment(cardOwner)} />
        </MessageContext.Provider>
      )}
    </MessagesViewContext.Provider>
  );

  const { rerender } = render(
    <RecoilRoot initializeState={initializeState}>
      <Tree showCard={false} />
    </RecoilRoot>,
  );

  // Fire the pending→ready edge for the live response's preview.
  act(() => {
    currentPreview = {
      file_id: fileId,
      status: 'ready',
      text: '<h1>resolved</h1>',
      textFormat: 'html',
    };
  });
  rerender(
    <RecoilRoot initializeState={initializeState}>
      <Tree showCard={false} />
    </RecoilRoot>,
  );

  // Streaming has ended by the time the card mounts — clear the global flag so
  // the card cannot open via the streaming path.
  act(() => {
    setGlobalSubmitting?.(false);
  });

  // Mount the card owned by `cardOwner`; its only route to auto-open now is a
  // deferred-preview signal left for ITS owning response.
  rerender(
    <RecoilRoot initializeState={initializeState}>
      <Tree showCard={true} />
    </RecoilRoot>,
  );

  return snapshot;
}

describe('deferred-preview auto-open scoping', () => {
  it('still auto-opens the card when the resolved preview belongs to its own response', () => {
    const snapshot = runScenario(liveResponseId);
    expect(snapshot.currentArtifactId).toBe('tool-artifact-shared-preview');
    expect(snapshot.visibility).toBe(true);
  });

  it('does not auto-open a card from a different response that reuses the same file id', () => {
    const snapshot = runScenario('previous-response');
    expect(snapshot.currentArtifactId).toBeNull();
    expect(snapshot.visibility).toBe(false);
  });
});
