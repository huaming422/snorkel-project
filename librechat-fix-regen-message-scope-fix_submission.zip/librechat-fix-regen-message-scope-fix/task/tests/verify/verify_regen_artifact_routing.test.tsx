/**
 * Panel auto-open scoping for tool-artifact rows. A rich-preview card must
 * only steal panel focus for the response that owns it: a card belonging to
 * the actively-streaming turn auto-opens, while a card belonging to a prior
 * answer that happens to be mounted (or reused by positional reconciliation)
 * while a *different* turn streams must stay closed.
 *
 * Everything here is asserted through observable panel state — the selected
 * artifact id, the visibility flag, and the registered artifact ids — read
 * from the public `~/store` atoms via a probe. No internal ref fields, atom
 * key shapes, or helper names are referenced.
 */
import React from 'react';
import { RecoilRoot, useRecoilValue } from 'recoil';
import { render, screen, fireEvent } from '@testing-library/react';
import type { TAttachment } from 'librechat-data-provider';
import type { MutableSnapshot } from 'recoil';
import Attachment from '~/components/Chat/Messages/Content/Parts/Attachment';
import { MessageContext } from '~/Providers/MessageContext';
import {
  MessagesViewContext,
  type MessagesViewContextValue,
} from '~/Providers/MessagesViewContext';
import store from '~/store';

jest.mock('~/hooks', () => ({
  useLocalize:
    () =>
    (key: string): string =>
      key,
  /* The attachment's preview-sync bridge is irrelevant to routing; stub it
   * to a no-op ready result so rendering doesn't touch the polling layer. */
  useAttachmentPreviewSync: () => ({ status: 'ready', previewError: undefined, isPolling: false }),
  useExpandCollapse: (isExpanded: boolean) => ({
    style: { display: 'grid', gridTemplateRows: isExpanded ? '1fr' : '0fr' },
    ref: { current: null },
  }),
}));

jest.mock('~/components/Chat/Messages/Content/Parts/LogLink', () => ({
  useAttachmentLink: () => ({ handleDownload: jest.fn() }),
}));

jest.mock('~/components/Chat/Input/Files/FileContainer', () => ({
  __esModule: true,
  default: ({ file, displayName }: { file: { filename?: string }; displayName?: string }) => (
    <div data-testid="file-container">{displayName ?? file.filename ?? ''}</div>
  ),
}));

jest.mock('~/components/Chat/Input/Files/FilePreview', () => ({
  __esModule: true,
  default: () => <div data-testid="file-preview" />,
}));

jest.mock('~/components/Chat/Messages/Content/Image', () => ({
  __esModule: true,
  default: ({ altText }: { altText?: string }) => <img alt={altText ?? ''} data-testid="image" />,
}));

jest.mock('~/components/Messages/Content/Mermaid/Mermaid', () => ({
  __esModule: true,
  default: ({ children }: { children: string }) => <div data-testid="mermaid-render">{children}</div>,
}));

jest.mock('~/utils', () => ({
  cn: (...classes: Array<string | false | null | undefined>) => classes.filter(Boolean).join(' '),
  getFileType: () => ({ paths: [], color: '', title: 'Artifact' }),
  logger: { log: jest.fn(), warn: jest.fn(), error: jest.fn() },
  isArtifactRoute: () => false,
}));

const baseAttachment = (overrides: Partial<TAttachment> = {}): TAttachment =>
  ({
    file_id: 'file-1',
    filename: 'unset',
    filepath: '/files/file-1',
    type: 'application/octet-stream',
    ...overrides,
  }) as TAttachment;

interface ArtifactsSnapshot {
  visibility: boolean;
  currentArtifactId: string | null;
  artifactIds: string[];
}

const StateProbe = ({ onSnapshot }: { onSnapshot: (snap: ArtifactsSnapshot) => void }) => {
  const visibility = useRecoilValue(store.artifactsVisibility);
  const currentArtifactId = useRecoilValue(store.currentArtifactId);
  const artifacts = useRecoilValue(store.artifactsState);
  React.useEffect(() => {
    onSnapshot({
      visibility,
      currentArtifactId,
      artifactIds: Object.keys(artifacts ?? {}),
    });
  });
  return null;
};

/* The id of whatever OTHER response is the active branch tail while a
 * historical card is on screen. A historical card's owner is, by definition,
 * not this id — so any liveness-derivation that compares the card's owner to
 * the active message resolves to "not live". */
const ACTIVE_ELSEWHERE = 'active-response';

/* Supply the active-message id the way the production tree does — through
 * `MessagesViewContext` — so a fix that scopes liveness by comparing the
 * card's owning message to the conversation's latest message id resolves
 * exactly as it would in the running app. The optional-state readers use
 * optional chaining, so a partial value is sufficient. */
const MessagesView = ({
  latestMessageId,
  children,
}: {
  latestMessageId: string;
  children: React.ReactNode;
}) => (
  <MessagesViewContext.Provider value={{ latestMessageId } as MessagesViewContextValue}>
    {children}
  </MessagesViewContext.Provider>
);

/**
 * Mount a card for a given owning response. `isLive` captures whether the
 * owning message is the response the user is actively generating/viewing;
 * when live, EVERY liveness channel the production providers populate agrees:
 * the message context's `isSubmitting` (the pre-folded signal) and
 * `isLatestMessage`, and `MessagesViewContext.latestMessageId`. When
 * historical, all three read as "not the active response" — exactly as the
 * real tree renders an older branch while a different turn streams. A fix may
 * read any one of these documented channels and classify the card identically.
 */
const renderOwnedRow = (
  messageId: string,
  isLive: boolean,
  attachment: TAttachment,
  onSnapshot: (snap: ArtifactsSnapshot) => void,
  init?: (snap: MutableSnapshot) => void,
) => (
  <RecoilRoot
    initializeState={
      init ??
      (({ set }) => {
        /* A turn is in flight across these regeneration scenarios, so the
         * process-global submit flag is on; per-message scoping — not the
         * absence of the global flag — is what keeps a historical card
         * closed. Seeding it lets a fix that folds the global flag with
         * `isLatestMessage` (the dominant codebase idiom) resolve a live
         * owner identically to one that reads the pre-folded context value. */
        set(store.isSubmittingFamily(0), true);
        set(store.artifactsVisibility, false);
      })
    }
  >
    <StateProbe onSnapshot={onSnapshot} />
    <MessagesView latestMessageId={isLive ? messageId : ACTIVE_ELSEWHERE}>
      <MessageContext.Provider
        value={{ messageId, isExpanded: true, isSubmitting: isLive, isLatestMessage: isLive }}
      >
        <Attachment attachment={attachment} />
      </MessageContext.Provider>
    </MessagesView>
  </RecoilRoot>
);

describe('tool-artifact panel scoping across responses', () => {
  it('auto-opens a rich-preview card that belongs to the actively streaming response', () => {
    const html = baseAttachment({
      file_id: 'live-answer',
      filename: 'index.html',
      text: '<h1>live</h1>',
      // Owner identity is supplied through EVERY channel the production tree
      // populates — the ambient message context (isSubmitting + isLatestMessage),
      // the attachment's own messageId, and the conversation's active message id
      // via MessagesViewContext — all agreeing this card is the live response, so
      // any documented liveness-derivation classifies it as live.
      messageId: 'live-response',
    } as Partial<TAttachment>);
    let snapshot: ArtifactsSnapshot = { visibility: false, currentArtifactId: null, artifactIds: [] };
    render(
      renderOwnedRow('live-response', true, html, (next) => (snapshot = next), (snap) => {
        snap.set(store.isSubmittingFamily(0), true);
        snap.set(store.artifactsVisibility, false);
      }),
    );
    expect(snapshot.currentArtifactId).toBe('tool-artifact-live-answer');
    expect(snapshot.visibility).toBe(true);
  });

  it('does not open a historical artifact remounted while another response regenerates', () => {
    const html = baseAttachment({
      file_id: 'previous-answer',
      filename: 'previous.html',
      text: '<h1>previous answer</h1>',
      // Both owner channels agree this card belongs to a prior response.
      messageId: 'previous-response',
    });
    const initializeState = (snap: MutableSnapshot) => {
      snap.set(store.isSubmittingFamily(0), true);
      snap.set(store.artifactsVisibility, false);
    };
    let snapshot: ArtifactsSnapshot = { visibility: false, currentArtifactId: null, artifactIds: [] };
    render(
      <RecoilRoot initializeState={initializeState}>
        <StateProbe onSnapshot={(next) => (snapshot = next)} />
        {/* A different turn is the active branch tail; this card's owner is an
         * older response, so every liveness channel reads as history. */}
        <MessagesView latestMessageId={ACTIVE_ELSEWHERE}>
          <MessageContext.Provider
            value={{
              messageId: 'previous-response',
              isExpanded: true,
              isSubmitting: false,
              isLatestMessage: false,
            }}
          >
            <Attachment attachment={html} />
          </MessageContext.Provider>
        </MessagesView>
      </RecoilRoot>,
    );
    // The card still registers so the panel can resolve it on an explicit click…
    expect(snapshot.artifactIds).toContain('tool-artifact-previous-answer');
    // …but it must not steal focus or force the panel open.
    expect(snapshot.currentArtifactId).toBeNull();
    expect(snapshot.visibility).toBe(false);
  });

  it('auto-opens when a reused artifact row changes from a historical to a live response', () => {
    const oldFile = baseAttachment({
      file_id: 'reused-file',
      filename: 'output.html',
      text: '<p>previous</p>',
      messageId: 'previous-response',
    });
    let snapshot: ArtifactsSnapshot = { visibility: false, currentArtifactId: null, artifactIds: [] };
    const { rerender } = render(
      renderOwnedRow('previous-response', false, oldFile, (next) => (snapshot = next)),
    );
    expect(snapshot.currentArtifactId).toBeNull();
    rerender(
      renderOwnedRow(
        'new-response',
        true,
        { ...oldFile, messageId: 'new-response', text: '<p>new result</p>' },
        (next) => (snapshot = next),
      ),
    );
    expect(snapshot.currentArtifactId).toBe('tool-artifact-reused-file');
    expect(snapshot.visibility).toBe(true);
  });

  it('does not reopen a reused live artifact when its new owner is historical', () => {
    const liveFile = baseAttachment({
      file_id: 'reused-live-file',
      filename: 'output.html',
      text: '<p>live</p>',
      messageId: 'live-response',
    });
    let snapshot: ArtifactsSnapshot = { visibility: false, currentArtifactId: null, artifactIds: [] };
    const { rerender } = render(
      renderOwnedRow('live-response', true, liveFile, (next) => (snapshot = next)),
    );
    expect(snapshot.currentArtifactId).toBe('tool-artifact-reused-live-file');
    // User closes the panel: the selection clears.
    fireEvent.click(screen.getByRole('button', { expanded: true }));
    expect(snapshot.currentArtifactId).toBeNull();
    rerender(
      renderOwnedRow(
        'older-response',
        false,
        { ...liveFile, messageId: 'older-response', text: '<p>historic</p>' },
        (next) => (snapshot = next),
      ),
    );
    // Reused for an older, non-streaming owner — the panel stays closed.
    expect(snapshot.currentArtifactId).toBeNull();
    expect(snapshot.visibility).toBe(false);
  });
});
