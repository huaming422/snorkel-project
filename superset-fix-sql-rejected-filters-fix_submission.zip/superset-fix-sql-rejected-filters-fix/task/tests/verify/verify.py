"""Behavioral checks for the chart SQL / chart data filter-rejection consistency.

Two MCP chart tools share one chart-data query path: one returns executed data,
one returns only the rendered SQL. When a request carries an extra filter naming
a column the dataset does not have, that filter is dropped while the query is
built. The data path reports this as a user-facing validation error; the SQL
path (before the fix) silently returns the unfiltered SQL as a success.

These checks assert the corrected, consistent behavior through stable,
pre-existing seams:

* The QUERY result builder's materialization path
  (``superset.common.query_actions._materialize_full_payload``) is driven with a
  mocked datasource, exactly as the repository's own unit tests exercise it. We
  assert the public payload shape (``applied_filters`` and the reason-tagged
  ``rejected_filters`` list) without pinning the datasource-only
  ``rejected_filter_columns`` name list (an internal detail the pre-fix path
  deletes) or any helper name or placement the change is free to choose.

* The ``get_chart_sql`` and ``get_chart_data`` tools are driven end to end
  through the fastmcp ``Client``. We patch only the shared upstream seam the
  bug sits downstream of (the chart-data command and the query-context
  builder), so the real decision code runs regardless of where an
  implementation puts the rejection check. The injected command result carries
  both documented rejection shapes (a ``rejected_filters`` list of
  ``{reason, column}`` entries and a ``rejected_filter_columns`` list of names),
  so any correct consumer of the public payload is accepted.

This file bootstraps its own minimal Superset application, mirroring the
repository's ``tests/unit_tests/conftest.py`` app fixture, so it does not rely
on the repository's test configuration being discovered.
"""

from __future__ import annotations

import asyncio
import contextlib
import importlib
import json
import os
from types import SimpleNamespace
from unittest.mock import MagicMock, Mock, patch

REPO = "/repo/superset"

# --------------------------------------------------------------------------- #
# Minimal application bootstrap (mirrors tests/unit_tests/conftest.py::app).
# --------------------------------------------------------------------------- #

_APP = None


def _get_app():
    """Build and cache a minimal Superset application for the checks."""
    global _APP
    if _APP is not None:
        return _APP

    from superset.app import SupersetApp
    from superset.extensions import appbuilder
    from superset.initialization import SupersetAppInitializer

    app = SupersetApp(__name__)
    app.config.from_object("superset.config")
    app.config["SQLALCHEMY_DATABASE_URI"] = (
        os.environ.get("SUPERSET__SQLALCHEMY_DATABASE_URI") or "sqlite://"
    )
    app.config["WTF_CSRF_ENABLED"] = False
    app.config["PREVENT_UNSAFE_DB_CONNECTIONS"] = False
    app.config["TESTING"] = True
    app.config["RATELIMIT_ENABLED"] = False
    app.config["CACHE_CONFIG"] = {}
    app.config["DATA_CACHE_CONFIG"] = {}
    app.config["SERVER_NAME"] = "example.com"
    app.config["APPLICATION_ROOT"] = "/"
    app.config["PREFERRED_URL_SCHEME"] = "http"
    # The permission checks for the chart tools are exercised in their own
    # dedicated tests; disable them here so a mock user can drive tool logic.
    app.config["MCP_RBAC_ENABLED"] = False

    # appbuilder is a singleton; clear views so init can run more than once.
    appbuilder.baseviews = []
    SupersetAppInitializer(app).init_app()

    _APP = app
    return _APP


# --------------------------------------------------------------------------- #
# Lazy module handles (imported inside the application context).
# --------------------------------------------------------------------------- #


def _chart_sql_mod():
    return importlib.import_module("superset.mcp_service.chart.tool.get_chart_sql")


def _chart_data_mod():
    return importlib.import_module("superset.mcp_service.chart.tool.get_chart_data")


def _query_actions_mod():
    return importlib.import_module("superset.common.query_actions")


def _get_data_command_mod():
    return importlib.import_module("superset.commands.chart.data.get_data_command")


def _mcp_server():
    from superset.mcp_service.app import mcp

    return mcp


def _mock_user():
    user = Mock()
    user.id = 1
    user.username = "admin"
    return user


def _fake_command(result):
    """A stand-in for the chart-data command returning a fixed payload."""

    class _Command:
        def __init__(self, query_context):
            self.query_context = query_context

        def validate(self):
            return None

        def run(self):
            return result

    return _Command


def _fake_query_context(*_args, **_kwargs):
    return SimpleNamespace(datasource=SimpleNamespace(id=1, type="table"))


def _is_error(data):
    """True when the tool returned an error response rather than SQL/data."""
    return bool(data.get("error_type"))


# --------------------------------------------------------------------------- #
# Result payloads carrying both documented rejection shapes.
# --------------------------------------------------------------------------- #

_SQL_TEXT = "SELECT country, count(*) FROM sales GROUP BY country"

BAD_ADHOC_FILTER = {
    "clause": "WHERE",
    "expressionType": "SIMPLE",
    "subject": "does_not_exist",
    "operator": "==",
    "comparator": "value",
}

_FORM_DATA = {
    "datasource": "1__table",
    "datasource_id": 1,
    "datasource_type": "table",
    "viz_type": "table",
    "metrics": ["count"],
    "groupby": ["country"],
}


def _query_entry(datasource_rejected, *, temporal_rejected=()):
    """One query payload entry in the public chart-data shape.

    ``datasource_rejected`` names columns dropped because the dataset lacks
    them; ``temporal_rejected`` names dropped time pseudo-filters. Both the
    per-column list and the reason-tagged list are populated so any consumer of
    the public payload observes the same facts.
    """
    rejected_filters = [
        {"reason": "not_in_datasource", "column": col} for col in datasource_rejected
    ] + [
        {"reason": "no_temporal_column", "column": col} for col in temporal_rejected
    ]
    return {
        "query": _SQL_TEXT,
        "language": "sql",
        "rejected_filters": rejected_filters,
        "rejected_filter_columns": list(datasource_rejected),
    }


def _result(datasource_rejected, *, temporal_rejected=()):
    return {
        "queries": [
            _query_entry(datasource_rejected, temporal_rejected=temporal_rejected)
        ]
    }


# --------------------------------------------------------------------------- #
# End-to-end tool drivers.
# --------------------------------------------------------------------------- #


def _run_chart_sql(extra_form_data, command_result):
    """Drive get_chart_sql end to end for an unsaved chart, returning its
    serialized response dict."""
    app = _get_app()
    mod = _chart_sql_mod()
    with app.app_context():
        from fastmcp import Client

        # The embedded-guest feature is disabled in this configuration, so the
        # guest denial branch short-circuits to "not a guest" without consulting
        # request state; a mock user is enough to reach the SQL logic.
        with contextlib.ExitStack() as es:
            es.enter_context(
                patch(
                    "superset.mcp_service.auth.get_user_from_request",
                    return_value=_mock_user(),
                )
            )
            es.enter_context(
                patch.object(
                    _get_data_command_mod(),
                    "ChartDataCommand",
                    _fake_command(command_result),
                )
            )
            es.enter_context(
                patch.object(
                    mod,
                    "_get_cached_form_data",
                    lambda _key: json.dumps(_FORM_DATA),
                )
            )
            es.enter_context(
                patch.object(
                    mod, "_build_query_context_from_form_data", _fake_query_context
                )
            )
            es.enter_context(
                patch.object(mod, "set_query_context_form_data", lambda *a, **k: None)
            )
            es.enter_context(
                patch.object(mod, "_resolve_datasource_name", lambda *a, **k: "sales")
            )
            es.enter_context(
                patch.object(
                    mod,
                    "event_logger",
                    SimpleNamespace(log_context=lambda **k: contextlib.nullcontext()),
                )
            )

            request = {"form_data_key": "cached-key"}
            if extra_form_data is not None:
                request["extra_form_data"] = extra_form_data

            async def _run():
                async with Client(_mcp_server()) as client:
                    res = await client.call_tool("get_chart_sql", {"request": request})
                    return res.structured_content.get(
                        "result", res.structured_content
                    )

            return asyncio.run(_run())


def _run_chart_data(extra_form_data, command_result):
    """Drive get_chart_data end to end for an unsaved chart, returning its
    serialized response dict."""
    app = _get_app()
    mod = _chart_data_mod()
    with app.app_context():
        from fastmcp import Client

        # Guest reads are gated on the embedded-guest feature, which is disabled
        # here, so the unsaved-chart cache path is reachable with a mock user.
        with contextlib.ExitStack() as es:
            es.enter_context(
                patch(
                    "superset.mcp_service.auth.get_user_from_request",
                    return_value=_mock_user(),
                )
            )
            es.enter_context(
                patch.object(
                    _get_data_command_mod(),
                    "ChartDataCommand",
                    _fake_command(command_result),
                )
            )
            es.enter_context(
                patch.object(
                    mod, "get_cached_form_data", lambda _key: json.dumps(_FORM_DATA)
                )
            )
            es.enter_context(
                patch.object(
                    mod, "build_query_context_from_form_data", _fake_query_context
                )
            )
            es.enter_context(
                patch.object(
                    mod,
                    "event_logger",
                    SimpleNamespace(log_context=lambda **k: contextlib.nullcontext()),
                )
            )

            request = {"form_data_key": "cached-key"}
            if extra_form_data is not None:
                request["extra_form_data"] = extra_form_data

            async def _run():
                async with Client(_mcp_server()) as client:
                    res = await client.call_tool(
                        "get_chart_data", {"request": request}
                    )
                    return res.structured_content.get(
                        "result", res.structured_content
                    )

            return asyncio.run(_run())


# --------------------------------------------------------------------------- #
# SQL-tool behavior.
# --------------------------------------------------------------------------- #


def test_sql_rejects_requested_unknown_column():
    """A requested filter on a column the dataset lacks yields a validation
    error naming the column, not unfiltered SQL."""
    data = _run_chart_sql(
        extra_form_data={"adhoc_filters": [BAD_ADHOC_FILTER]},
        command_result=_result(["does_not_exist"]),
    )
    # The contract is that the request fails and the message identifies the
    # unknown column; the exact error_type string is left to the implementation.
    assert _is_error(data), f"expected an error response, got: {data}"
    message = (data.get("error") or "") + " " + (data.get("message") or "")
    assert "does_not_exist" in message, data


def test_sql_ignores_nonrequested_rejection():
    """A rejected column the caller did not request in this call must not fail
    the request."""
    data = _run_chart_sql(
        extra_form_data={"filters": [{"col": "country", "op": "==", "val": "US"}]},
        command_result=_result(["stale_saved_filter"]),
    )
    assert not _is_error(data), f"expected SQL, got error: {data}"
    assert (data.get("sql") or "").startswith("SELECT country"), data


def test_sql_temporal_rejection_not_confused():
    """A temporal pseudo-filter rejection sharing a name with a requested
    filter must not be treated as a datasource-column rejection."""
    data = _run_chart_sql(
        extra_form_data={
            "filters": [{"col": "__time_col", "op": "==", "val": "value"}]
        },
        command_result=_result([], temporal_rejected=["__time_col"]),
    )
    assert not _is_error(data), f"expected SQL, got error: {data}"
    assert data.get("sql"), data


def test_sql_returns_sql_when_no_rejection():
    """With nothing rejected during query construction, SQL is returned as
    before even if the request carried extra filters."""
    data = _run_chart_sql(
        extra_form_data={"adhoc_filters": [BAD_ADHOC_FILTER]},
        command_result=_result([]),
    )
    assert not _is_error(data), f"expected SQL, got error: {data}"
    assert data.get("sql"), data


# --------------------------------------------------------------------------- #
# QUERY result builder behavior.
# --------------------------------------------------------------------------- #


def test_qs_extended_surfaces_rejection_metadata():
    """The QUERY result builder must surface rejected-filter metadata when the
    datasource exposes the extended query-string form.

    This is the root-cause test: before the fix, _get_query called only the
    plain get_query_str method, discarding the applied/rejected filter columns
    the datasource computed.  A correct fix makes _get_query prefer
    get_query_str_extended so the QUERY payload carries the same rejection
    metadata the FULL (data) path reports.

    This test drives _get_query with a datasource that HAS the extended form
    and asserts the returned result surfaces the rejection metadata.  A
    consumer-only fix that never touches _get_query will fail here because the
    real _get_query still returns only {language, query} with no rejection keys.
    """
    app = _get_app()
    with app.app_context():
        query_actions = _query_actions_mod()

        query_obj = MagicMock()
        query_obj.to_dict.return_value = {}

        with patch.object(query_actions, "_get_datasource") as mock_get_ds:
            # Datasource that implements the extended query-string form
            query_str_ext = MagicMock()
            query_str_ext.prequeries = []
            query_str_ext.sql = "SELECT country FROM sales"
            query_str_ext.applied_filter_columns = ["country"]
            query_str_ext.rejected_filter_columns = ["does_not_exist"]

            datasource = MagicMock()
            datasource.query_language = "sql"
            datasource.get_query_str_extended.return_value = query_str_ext
            mock_get_ds.return_value = datasource

            result = query_actions._get_query(MagicMock(), query_obj, False)

    # The QUERY payload must now carry the rejection metadata.  We accept
    # either the raw rejected_filter_columns list OR the reason-tagged
    # rejected_filters shape -- implementations may choose either plumbing.
    has_raw_rejection = (
        "rejected_filter_columns" in result
        and "does_not_exist" in result["rejected_filter_columns"]
    )
    has_tagged_rejection = any(
        isinstance(entry, dict) and entry.get("column") == "does_not_exist"
        for entry in result.get("rejected_filters", [])
    )
    assert has_raw_rejection or has_tagged_rejection, (
        f"_get_query must surface rejection metadata when datasource exposes "
        f"get_query_str_extended.  Got: {result}"
    )


def test_qs_fallback_plain_string():
    """A datasource lacking the extended query-string form keeps the plain
    string path and emits no rejection metadata."""
    app = _get_app()
    with app.app_context():
        query_actions = _query_actions_mod()

        query_obj = MagicMock()
        query_obj.to_dict.return_value = {}

        with patch.object(query_actions, "_get_datasource") as mock_get_ds:
            datasource = MagicMock(spec=["query_language", "get_query_str"])
            datasource.query_language = "sql"
            datasource.get_query_str.return_value = "SELECT 1;"
            mock_get_ds.return_value = datasource

            result = query_actions._get_query(MagicMock(), query_obj, False)

    assert result["query"] == "SELECT 1;", result
    # Accept either no key or an empty list (task.toml alternative #3)
    assert result.get("rejected_filters") in (None, []), result


def test_qs_preserves_datasource_rejection_origin():
    """The data-materialization path combines the datasource-column rejection
    and the temporal pseudo-filter rejection into one public rejected_filters
    list, so neither origin is dropped when the payload is assembled."""
    app = _get_app()
    with app.app_context():
        query_actions = _query_actions_mod()
        from superset.common.chart_data import ChartDataResultType
        from superset.common.db_query_status import QueryStatus

        query_context = MagicMock()
        query_context.result_type = ChartDataResultType.FULL
        query_obj = MagicMock()
        query_obj.result_type = ChartDataResultType.FULL
        query_obj.applied_time_extras = {}
        payload = {
            "df": None,
            "status": QueryStatus.FAILED,
            "applied_filter_columns": [],
            "rejected_filter_columns": ["__time_col"],
        }

        with (
            patch.object(query_actions, "_get_datasource", return_value=MagicMock()),
            patch.object(
                query_actions,
                "get_time_filter_status",
                return_value=(
                    [],
                    [{"reason": "not_in_datasource", "column": "__time_col"}],
                ),
            ),
        ):
            result = query_actions._materialize_full_payload(
                query_context, query_obj, payload
            )

    # The materialization combines the datasource-column rejection and the
    # temporal rejection into the public rejected_filters list; we assert that
    # combination behaviorally rather than pinning the raw rejected_filter_columns
    # key the pre-fix path deletes and a valid implementation may not re-add.
    assert len(result["rejected_filters"]) == 2, result
    assert {entry["column"] for entry in result["rejected_filters"]} == {
        "__time_col"
    }, result


# --------------------------------------------------------------------------- #
# Cross-tool agreement.
# --------------------------------------------------------------------------- #


def test_data_and_sql_agree_on_rejection():
    """The data tool and the SQL tool agree: both reject the same bad requested
    filter instead of one failing open and the other failing closed."""
    extra_form_data = {"adhoc_filters": [BAD_ADHOC_FILTER]}
    command_result = _result(["does_not_exist"])

    data_response = _run_chart_data(extra_form_data, command_result)
    sql_response = _run_chart_sql(extra_form_data, command_result)

    assert _is_error(data_response), f"data tool should reject: {data_response}"
    assert _is_error(sql_response), f"SQL tool should reject: {sql_response}"
