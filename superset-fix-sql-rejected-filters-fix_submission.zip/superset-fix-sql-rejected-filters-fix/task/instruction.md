## Task

our MCP tooling lets you ask for a chart's rendered SQL. ask for that SQL and tack on an extra filter targeting a column the dataset doesn't actually have, and you get back a perfectly normal-looking SQL statement and a success response. the catch: that bogus filter is silently missing from the SQL. no error, no warning.

run the same chart to fetch its data instead and that path does report the bad filter, so the SQL path is the one getting it wrong, and the two disagree with each other. the SQL path should line up with the data path: when a filter names a column the dataset doesn't know about, it should tell the caller the column is unknown instead of quietly handing back SQL that ignores it.

this isn't a permissions problem and it isn't about how the SQL gets parsed. dig into the chart tooling and the shared query path the chart data runs through, and fix it.
