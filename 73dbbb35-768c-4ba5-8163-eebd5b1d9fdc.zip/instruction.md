## Task

A dashboard using a custom theme misbehaves when someone changes its styling while editing. To reproduce it, open the dashboard's styling properties in edit mode, choose another theme or clear the current one, and click Apply. The charts reload and flicker where they should simply take on the new colors. At the same time, Save becomes disabled despite pending changes, leaving the theme choice and any other edits unsaveable.

Please fix both visible effects. Applying or removing a theme should update the dashboard's appearance without restarting its charts, and pending edits must remain available to save in the UI. Keep the existing theme application behavior and the behavior of dashboards that have no custom theme.

This is a frontend issue. The environment is offline with dependencies already installed; use the frontend's existing tests to investigate and check the repair.
