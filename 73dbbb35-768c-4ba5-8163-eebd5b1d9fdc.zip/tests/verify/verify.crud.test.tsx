/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
// A child counts mounts and reads the applied theme after a theme change.
import { type ReactNode, useEffect } from 'react';
import { render, screen } from 'spec/helpers/testing-library';
import { logging } from '@apache-superset/core/utils';
import { Theme, useTheme } from '@apache-superset/core/theme';
import getBootstrapData from 'src/utils/getBootstrapData';
import CrudThemeProvider from 'src/components/CrudThemeProvider';
import dashboardStateReducer from 'src/dashboard/reducers/dashboardState';
import { SET_REFRESH_FREQUENCY } from 'src/dashboard/actions/dashboardState';

jest.mock('src/utils/getBootstrapData', () => ({
  __esModule: true,
  default: jest.fn(() => ({
    common: { theme: { default: {}, dark: {} } },
  })),
}));

const mockGetBootstrapData = getBootstrapData as jest.MockedFunction<
  typeof getBootstrapData
>;

let mountCount = 0;
let pendingEdits = true;
function MountProbe() {
  const theme = useTheme() as Record<string, unknown>;
  useEffect(() => {
    mountCount += 1;
    return () => {
      pendingEdits = Boolean(
        dashboardStateReducer(
          { hasUnsavedChanges: pendingEdits } as Parameters<
            typeof dashboardStateReducer
          >[0],
          {
            type: SET_REFRESH_FREQUENCY,
            refreshFrequency: 0,
            isPersistent: false,
          } as Parameters<typeof dashboardStateReducer>[1],
        ).hasUnsavedChanges,
      );
    };
  }, []);
  return <span data-test="primary">{String(theme.colorPrimary ?? '')}</span>;
}

function themeProp(id: number, name: string, config: unknown) {
  return { id, theme_name: name, json_data: JSON.stringify(config) };
}

beforeEach(() => {
  jest.restoreAllMocks();
  mountCount = 0;
  pendingEdits = true;
  mockGetBootstrapData.mockReturnValue({
    common: { theme: { default: {}, dark: {} } },
  } as unknown as ReturnType<typeof getBootstrapData>);
});

describe('dashboard theme provider on theme change', () => {
  it('does not remount the dashboard subtree when the applied theme changes', () => {
    const { rerender } = render(
      <CrudThemeProvider
        theme={themeProp(1, 'A', { token: { colorPrimary: '#aaaaaa' } })}
      >
        <MountProbe />
      </CrudThemeProvider>,
      { useTheme: true },
    );
    const baselineMounts = mountCount;
    expect(screen.getByTestId('primary').textContent).toBe('#aaaaaa');
    pendingEdits = true;

    rerender(
      <CrudThemeProvider
        theme={themeProp(2, 'B', { token: { colorPrimary: '#bbbbbb' } })}
      >
        <MountProbe />
      </CrudThemeProvider>,
    );

    expect(screen.getByTestId('primary').textContent).toBe('#bbbbbb');
    expect(mountCount).toBe(baselineMounts);
    expect(pendingEdits).toBe(true);
  });

  it('keeps charts mounted and pending edits after clearing an applied theme', () => {
    const { rerender } = render(
      <CrudThemeProvider
        theme={themeProp(1, 'A', { token: { colorPrimary: '#aaaaaa' } })}
      >
        <MountProbe />
      </CrudThemeProvider>,
      { useTheme: true },
    );
    const baselineMounts = mountCount;
    expect(screen.getByTestId('primary').textContent).toBe('#aaaaaa');
    pendingEdits = true;

    rerender(
      <CrudThemeProvider theme={null}>
        <MountProbe />
      </CrudThemeProvider>,
    );

    expect(mountCount).toBe(baselineMounts);
    expect(pendingEdits).toBe(true);
    expect(screen.getByTestId('primary').textContent).not.toBe('#aaaaaa');
  });

  it('warns and keeps rendering when applying a theme fails', () => {
    jest.spyOn(Theme, 'fromConfig').mockImplementation(() => {
      throw new Error('theme construction failed');
    });
    jest.spyOn(logging, 'warn').mockImplementation();

    render(
      <CrudThemeProvider
        theme={themeProp(1, 'Custom Theme', {
          token: { colorPrimary: '#ff0000' },
        })}
      >
        <div>Dashboard Content</div>
      </CrudThemeProvider>,
    );

    expect(logging.warn).toHaveBeenCalled();
    expect(screen.getByText('Dashboard Content')).toBeInTheDocument();
  });
});
