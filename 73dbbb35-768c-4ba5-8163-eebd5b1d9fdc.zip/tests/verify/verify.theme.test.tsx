/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
// Observe a child's mounts and resolved theme values across theme changes.
import { type ReactNode, useEffect } from 'react';
import { render, screen } from 'spec/helpers/testing-library';
import { useTheme } from '@apache-superset/core/theme';
import getBootstrapData from 'src/utils/getBootstrapData';
import CrudThemeProvider from 'src/components/CrudThemeProvider';

jest.mock('src/utils/getBootstrapData', () => ({
  __esModule: true,
  default: jest.fn(() => ({
    common: { theme: { default: {}, dark: {} } },
  })),
}));

const mockGetBootstrapData = getBootstrapData as jest.MockedFunction<
  typeof getBootstrapData
>;

let mountCount = 0;
function ThemeProbe() {
  const theme = useTheme() as Record<string, unknown>;
  useEffect(() => {
    mountCount += 1;
  }, []);
  return (
    <div>
      <span data-test="primary">{String(theme.colorPrimary ?? '')}</span>
      <span data-test="error">{String(theme.colorError ?? '')}</span>
      <span data-test="link">{String(theme.colorLink ?? '')}</span>
      <span data-test="echarts">
        {JSON.stringify(theme.echartsOptionsOverrides ?? null)}
      </span>
      <span data-test="echarts-by-type">
        {JSON.stringify(theme.echartsOptionsOverridesByChartType ?? null)}
      </span>
    </div>
  );
}

function themeProp(id: number, name: string, config: unknown) {
  return { id, theme_name: name, json_data: JSON.stringify(config) };
}

beforeEach(() => {
  jest.restoreAllMocks();
  mountCount = 0;
});

describe('applied dashboard theme after an in-place theme switch', () => {
  it('keeps config tokens and fills untouched tokens from the base theme', () => {
    const baseTheme = {
      token: { colorPrimary: '#111111', colorError: '#ff0000' },
    };
    mockGetBootstrapData.mockReturnValue({
      common: { theme: { default: baseTheme, dark: {} } },
    } as unknown as ReturnType<typeof getBootstrapData>);

    const { rerender } = render(
      <CrudThemeProvider
        theme={themeProp(1, 'A', { token: { colorPrimary: '#aaaaaa' } })}
      >
        <ThemeProbe />
      </CrudThemeProvider>,
    );
    const baselineMounts = mountCount;

    rerender(
      <CrudThemeProvider
        theme={themeProp(2, 'B', { token: { colorPrimary: '#0000ff' } })}
      >
        <ThemeProbe />
      </CrudThemeProvider>,
    );

    expect(mountCount).toBe(baselineMounts);
    expect(screen.getByTestId('primary').textContent).toBe('#0000ff');
    expect(screen.getByTestId('error').textContent).toBe('#ff0000');
  });

  it('keeps the base theme ECharts overrides when the new config sets none', () => {
    const baseTheme = {
      token: { colorPrimary: '#111111' },
      echartsOptionsOverrides: { backgroundColor: '#123456' },
      echartsOptionsOverridesByChartType: {
        pie: { itemStyle: { borderWidth: 2 } },
      },
    };
    mockGetBootstrapData.mockReturnValue({
      common: { theme: { default: baseTheme, dark: {} } },
    } as unknown as ReturnType<typeof getBootstrapData>);

    const { rerender } = render(
      <CrudThemeProvider
        theme={themeProp(1, 'A', { token: { colorPrimary: '#aaaaaa' } })}
      >
        <ThemeProbe />
      </CrudThemeProvider>,
    );
    const baselineMounts = mountCount;

    rerender(
      <CrudThemeProvider
        theme={themeProp(2, 'B', { token: { colorPrimary: '#0000ff' } })}
      >
        <ThemeProbe />
      </CrudThemeProvider>,
    );

    expect(mountCount).toBe(baselineMounts);
    expect(screen.getByTestId('echarts').textContent).toBe(
      JSON.stringify({ backgroundColor: '#123456' }),
    );
    expect(screen.getByTestId('echarts-by-type').textContent).toBe(
      JSON.stringify({ pie: { itemStyle: { borderWidth: 2 } } }),
    );
  });

  it('aligns colorLink to the new primary when the config sets no colorLink', () => {
    const baseTheme = {
      token: {
        colorPrimary: '#111111',
        colorError: '#ff0000',
        colorLink: '#999999',
      },
    };
    mockGetBootstrapData.mockReturnValue({
      common: { theme: { default: baseTheme, dark: {} } },
    } as unknown as ReturnType<typeof getBootstrapData>);

    const { rerender } = render(
      <CrudThemeProvider
        theme={themeProp(1, 'A', { token: { colorPrimary: '#aaaaaa' } })}
      >
        <ThemeProbe />
      </CrudThemeProvider>,
    );
    const baselineMounts = mountCount;

    rerender(
      <CrudThemeProvider
        theme={themeProp(2, 'B', { token: { colorPrimary: '#0000ff' } })}
      >
        <ThemeProbe />
      </CrudThemeProvider>,
    );

    expect(mountCount).toBe(baselineMounts);
    expect(screen.getByTestId('link').textContent).toBe('#0000ff');
  });
});
