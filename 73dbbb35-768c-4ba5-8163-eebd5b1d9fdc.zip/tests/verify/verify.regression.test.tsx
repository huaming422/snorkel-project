/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
// Observe theme wrapping and fallback rendering for existing dashboard paths.
import { type ReactNode } from 'react';
import { render, screen } from 'spec/helpers/testing-library';
import { logging } from '@apache-superset/core/utils';
import { Theme } from '@apache-superset/core/theme';
import getBootstrapData from 'src/utils/getBootstrapData';
import { ThemeContext } from 'src/theme/ThemeProvider';
import type { ThemeContextType } from '@apache-superset/core/theme';
import CrudThemeProvider from 'src/components/CrudThemeProvider';

jest.mock('src/utils/getBootstrapData', () => ({
  __esModule: true,
  default: jest.fn(() => ({
    common: { theme: { default: {}, dark: {} } },
  })),
}));

const mockGetBootstrapData = getBootstrapData as jest.MockedFunction<
  typeof getBootstrapData
>;

// A provider that marks the DOM so a dashboard-theme wrap is observable.
const MarkerThemeProvider = ({ children }: { children: ReactNode }) => (
  <div data-test="dashboard-theme-provider">{children}</div>
);

beforeEach(() => {
  jest.restoreAllMocks();
  jest.spyOn(Theme, 'fromConfig').mockReturnValue({
    SupersetThemeProvider: MarkerThemeProvider,
    setConfig: jest.fn(),
  } as unknown as Theme);
  mockGetBootstrapData.mockReturnValue({
    common: { theme: { default: {}, dark: {} } },
  } as unknown as ReturnType<typeof getBootstrapData>);
  document
    .querySelectorAll('style[data-superset-fonts]')
    .forEach(el => el.remove());
});

describe('preserved behaviors (regression guards)', () => {
  it('renders children directly with no theme wrapper when no theme is provided', () => {
    render(
      <CrudThemeProvider>
        <div>Dashboard Content</div>
      </CrudThemeProvider>,
    );
    expect(screen.getByText('Dashboard Content')).toBeInTheDocument();
    expect(
      screen.queryByTestId('dashboard-theme-provider'),
    ).not.toBeInTheDocument();
  });

  it('renders children directly with no theme wrapper when the theme is null', () => {
    render(
      <CrudThemeProvider theme={null}>
        <div>Dashboard Content</div>
      </CrudThemeProvider>,
    );
    expect(screen.getByText('Dashboard Content')).toBeInTheDocument();
    expect(
      screen.queryByTestId('dashboard-theme-provider'),
    ).not.toBeInTheDocument();
  });

  it('skips the dashboard theme when an SDK theme config override is active', () => {
    render(
      <ThemeContext.Provider
        value={{ hasThemeConfigOverride: true } as unknown as ThemeContextType}
      >
        <CrudThemeProvider
          theme={{
            id: 1,
            theme_name: 'Custom Theme',
            json_data: JSON.stringify({ token: { colorPrimary: '#ff0000' } }),
          }}
        >
          <div>Dashboard Content</div>
        </CrudThemeProvider>
      </ThemeContext.Provider>,
    );
    expect(screen.getByText('Dashboard Content')).toBeInTheDocument();
    expect(
      screen.queryByTestId('dashboard-theme-provider'),
    ).not.toBeInTheDocument();
  });

  it('falls back to rendering children and warns when json_data is invalid', () => {
    jest.spyOn(logging, 'warn').mockImplementation();
    render(
      <CrudThemeProvider
        theme={{ id: 1, theme_name: 'Bad Theme', json_data: 'not-valid-json' }}
      >
        <div>Dashboard Content</div>
      </CrudThemeProvider>,
    );
    expect(screen.getByText('Dashboard Content')).toBeInTheDocument();
    expect(
      screen.queryByTestId('dashboard-theme-provider'),
    ).not.toBeInTheDocument();
    expect(logging.warn).toHaveBeenCalled();
  });

  it('ignores non-array fontUrls without throwing or injecting fonts', () => {
    render(
      <CrudThemeProvider
        theme={{
          id: 1,
          theme_name: 'Malformed Fonts',
          json_data: JSON.stringify({
            token: { colorPrimary: '#ff0000', fontUrls: 'not-an-array' },
          }),
        }}
      >
        <div>Dashboard Content</div>
      </CrudThemeProvider>,
    );
    expect(screen.getByText('Dashboard Content')).toBeInTheDocument();
    expect(
      document.querySelector('style[data-superset-fonts]'),
    ).toBeNull();
  });
});
