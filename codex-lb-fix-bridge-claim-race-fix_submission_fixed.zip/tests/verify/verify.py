"""Single-instance HTTP bridge sessions across reconnects and slow session opens.

Requests go through the proxy service's bridge session entry point
(``ProxyService._get_or_create_http_bridge_session``) with a real durable-bridge
coordinator on an in-memory SQLite engine, the way the repository's own
``tests/unit/test_proxy_http_bridge.py`` drives it: the upstream WebSocket
factory is faked, the instance ring holds one instance, and each request first
looks up the durable session the way the request path does. The tests check
what a client sees (a session back, or a ``ProxyResponseError``) and the stored
durable row.

When a test needs another write to land while a request is talking to the
durable store, it wraps the repository module's ``sqlite_writer_section`` (the
writer lock every durable-bridge write goes through) so that write commits the
first time the request enters it.
"""

from __future__ import annotations

import asyncio
import contextlib
import time
from collections import deque
from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import nullcontext
from dataclasses import dataclass
from types import SimpleNamespace
from typing import Any, cast
from unittest.mock import AsyncMock, Mock

import anyio
import pytest
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

import app.modules.proxy.durable_bridge_repository as repository_module
from app.core.clients.proxy import ProxyResponseError
from app.core.config.settings import Settings
from app.db.models import AccountStatus, Base, HttpBridgeSessionState
from app.modules.proxy import service as proxy_service
from app.modules.proxy.durable_bridge_coordinator import DurableBridgeSessionCoordinator

INSTANCE = "instance-a"
MODEL = "gpt-5.4"


@dataclass
class Bridge:
    service: Any
    coordinator: DurableBridgeSessionCoordinator
    key: Any
    turn_state: str
    sessions: deque


def _bridge_session(key: Any, turn_state: str, *, account_id: str = "acc-1") -> Any:
    return proxy_service._HTTPBridgeSession(
        key=key,
        headers={"x-codex-turn-state": turn_state},
        affinity=proxy_service._AffinityPolicy(key=turn_state),
        request_model=MODEL,
        account=cast(Any, SimpleNamespace(id=account_id, status=AccountStatus.ACTIVE, plan_type="plus")),
        upstream=cast(Any, SimpleNamespace(close=AsyncMock())),
        upstream_control=proxy_service._WebSocketUpstreamControl(),
        pending_requests=deque(),
        pending_lock=anyio.Lock(),
        response_create_gate=asyncio.Semaphore(1),
        queued_request_count=0,
        last_used_at=time.monotonic(),
        idle_ttl_seconds=120.0,
    )


@pytest.fixture
async def async_session_factory() -> AsyncIterator[Callable[[], AsyncSession]]:
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    session_maker = async_sessionmaker(engine, expire_on_commit=False)

    def get_session() -> AsyncSession:
        return session_maker()

    yield get_session
    await engine.dispose()


@pytest.fixture
def coordinator(async_session_factory: Callable[[], AsyncSession]) -> DurableBridgeSessionCoordinator:
    return DurableBridgeSessionCoordinator(async_session_factory)


@pytest.fixture
async def make_bridge(
    coordinator: DurableBridgeSessionCoordinator,
    monkeypatch: pytest.MonkeyPatch,
) -> AsyncIterator[Callable[[str], Bridge]]:
    bridges: list[Bridge] = []

    def make(turn_state: str) -> Bridge:
        bridge = _make_bridge(coordinator, monkeypatch, turn_state)
        bridges.append(bridge)
        return bridge

    yield make
    # Let session closes the service scheduled in the background finish before
    # the database goes away.
    for bridge in bridges:
        await asyncio.gather(*list(bridge.service._background_cleanup_tasks), return_exceptions=True)


def _make_bridge(
    coordinator: DurableBridgeSessionCoordinator,
    monkeypatch: pytest.MonkeyPatch,
    turn_state: str,
) -> Bridge:
    """A single-instance proxy service whose new upstream sessions come from a
    queue the test fills."""
    settings = Settings(
        http_responses_session_bridge_enabled=True,
        http_responses_session_bridge_instance_id=INSTANCE,
    )
    monkeypatch.setattr(proxy_service, "get_settings", lambda: settings)
    monkeypatch.setattr(proxy_service, "_http_bridge_owner_instance", AsyncMock(return_value=INSTANCE))
    monkeypatch.setattr(
        proxy_service,
        "_active_http_bridge_instance_ring",
        AsyncMock(return_value=(INSTANCE, (INSTANCE,))),
    )
    service = proxy_service.ProxyService(cast(Any, nullcontext()))
    service._durable_bridge = coordinator
    service._ring_membership = None
    monkeypatch.setattr(service, "_prune_http_bridge_sessions_locked", Mock(return_value=[]))
    key = proxy_service._HTTPBridgeSessionKey("turn_state_header", turn_state, None)
    bridge = Bridge(service=service, coordinator=coordinator, key=key, turn_state=turn_state, sessions=deque())

    async def create_session(_key: Any, **_kwargs: Any) -> Any:
        produce = bridge.sessions.popleft()
        return await produce() if callable(produce) else produce

    monkeypatch.setattr(service, "_create_http_bridge_session", create_session)
    return bridge


async def _lookup(bridge: Bridge) -> Any:
    return await bridge.coordinator.lookup_request_targets(
        session_key_kind=bridge.key.affinity_kind,
        session_key_value=bridge.key.affinity_key,
        api_key_id=None,
        turn_state=bridge.turn_state,
        session_header=None,
        previous_response_id=None,
    )


async def _send(bridge: Bridge, durable_lookup: Any = None, *, look_up: bool = True) -> Any:
    """One request for the session: look up its durable row, then get a bridge
    session for it."""
    if look_up:
        durable_lookup = await _lookup(bridge)
    return await bridge.service._get_or_create_http_bridge_session(
        bridge.key,
        headers={"x-codex-turn-state": bridge.turn_state},
        affinity=proxy_service._AffinityPolicy(key=bridge.turn_state),
        api_key=None,
        request_model=MODEL,
        idle_ttl_seconds=120.0,
        max_sessions=8,
        allow_forward_to_owner=True,
        durable_lookup=durable_lookup,
    )


async def _send_ok(bridge: Bridge, what: str, durable_lookup: Any = None, *, look_up: bool = True) -> Any:
    try:
        return await _send(bridge, durable_lookup, look_up=look_up)
    except ProxyResponseError as exc:
        error = exc.payload.get("error", {}) if isinstance(exc.payload, dict) else {}
        pytest.fail(f"{what} failed with {exc.status_code} {error.get('code')!r}: {error.get('message')!r}")


async def _retire(bridge: Bridge, session: Any) -> None:
    """The session's upstream WebSocket closed: it leaves the registry now, and
    its teardown (which releases its durable lease) finishes later."""
    async with bridge.service._http_bridge_lock:
        bridge.service._detach_http_bridge_session_locked(bridge.key, expected_session=session)


async def _stored(bridge: Bridge, session: Any) -> Any:
    [stored] = await bridge.coordinator.lookup_sessions(session_ids=[session.durable_session_id])
    return stored


def _assert_serving(stored: Any, session: Any) -> None:
    assert (stored.owner_instance_id, stored.state, stored.owner_epoch) == (
        INSTANCE,
        HttpBridgeSessionState.ACTIVE,
        session.durable_owner_epoch,
    ), (
        "The durable row should be ACTIVE, owned by this instance, at the epoch the "
        f"serving session holds ({session.durable_owner_epoch}); got owner "
        f"{stored.owner_instance_id!r}, state {stored.state!r}, epoch {stored.owner_epoch}."
    )


def _inject_on_first_write(
    monkeypatch: pytest.MonkeyPatch,
    action: Callable[[], Awaitable[None]],
) -> Callable[[], bool]:
    real_writer_section = repository_module.sqlite_writer_section
    fired = False

    @contextlib.asynccontextmanager
    async def writer_section_with_injection():
        nonlocal fired
        if not fired:
            fired = True
            await action()
        async with real_writer_section():
            yield

    monkeypatch.setattr(repository_module, "sqlite_writer_section", writer_section_with_injection)
    return lambda: fired


async def test_reconnect_keeps_serving_after_older_session_teardown(
    make_bridge: Callable[[str], Bridge],
) -> None:
    """A long-lived session's upstream closes; the next request opens a new
    session for it before the old session's teardown has finished. Once the
    teardown finishes, the following request is still served by the new session
    and the stored row stays ACTIVE and owned by this instance.
    """
    bridge = make_bridge("turn-reconnect")
    first = _bridge_session(bridge.key, bridge.turn_state)
    second = _bridge_session(bridge.key, bridge.turn_state)
    bridge.sessions.extend([first, second])

    assert await _send_ok(bridge, "The first request") is first
    await _retire(bridge, first)

    assert await _send_ok(bridge, "The reconnecting request") is second
    await bridge.service._close_http_bridge_session(first)

    served = await _send_ok(bridge, "The request after the old session's teardown")
    assert served is second, "The next request should be served by the reconnected session."
    _assert_serving(await _stored(bridge, second), second)


async def test_reconnect_keeps_serving_when_teardown_lands_during_reconnect(
    make_bridge: Callable[[str], Bridge],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Same reconnect, but the old session's teardown release commits while the
    reconnecting request is already writing to the durable store. Both the
    reconnecting request and the one after it are served, and the stored row is
    ACTIVE and owned by this instance.
    """
    bridge = make_bridge("turn-overlap")
    first = _bridge_session(bridge.key, bridge.turn_state)
    second = _bridge_session(bridge.key, bridge.turn_state)
    bridge.sessions.extend([first, second])

    assert await _send_ok(bridge, "The first request") is first
    await _retire(bridge, first)

    async def old_session_release() -> None:
        await bridge.coordinator.release_live_session(
            session_id=first.durable_session_id,
            instance_id=INSTANCE,
            owner_epoch=first.durable_owner_epoch,
            draining=False,
        )

    durable_lookup = await _lookup(bridge)
    released = _inject_on_first_write(monkeypatch, old_session_release)
    reconnected = await _send_ok(bridge, "The reconnecting request", durable_lookup, look_up=False)
    assert reconnected is second
    if not released():
        # The reconnecting request never took the writer lock, so the release
        # lands right after it instead.
        await old_session_release()

    served = await _send_ok(bridge, "The request after the reconnect")
    assert served is second, "The next request should be served by the reconnected session."
    _assert_serving(await _stored(bridge, second), second)


async def test_slow_open_with_timed_out_waiter_leaves_later_session_serving(
    make_bridge: Callable[[str], Bridge],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A request starts opening a session and its upstream connect is slow. A
    second request for the same session gives up waiting with a 429, and a third
    opens the session and is served. When the slow open finally finishes, it
    does not take the session away: the next request is served by the third
    request's session and the stored row is ACTIVE and owned by this instance.
    """
    bridge = make_bridge("turn-slow-open")
    monkeypatch.setattr(proxy_service, "_proxy_admission_wait_timeout_seconds", lambda settings=None: 0.05)
    earlier = _bridge_session(bridge.key, bridge.turn_state)
    slow = _bridge_session(bridge.key, bridge.turn_state)
    winner = _bridge_session(bridge.key, bridge.turn_state)
    slow_started = asyncio.Event()
    slow_may_finish = asyncio.Event()

    async def open_slowly() -> Any:
        slow_started.set()
        await slow_may_finish.wait()
        return slow

    bridge.sessions.extend([earlier, open_slowly, winner])

    # The session has history: an earlier upstream came and went.
    assert await _send_ok(bridge, "The earliest request") is earlier
    await _retire(bridge, earlier)
    await bridge.service._close_http_bridge_session(earlier)

    slow_request = asyncio.create_task(_send(bridge))
    await asyncio.wait_for(slow_started.wait(), timeout=10)

    with pytest.raises(ProxyResponseError) as waiter:
        await _send(bridge)
    assert waiter.value.status_code == 429

    assert await _send_ok(bridge, "The request that opened the session") is winner

    slow_may_finish.set()
    [slow_outcome] = await asyncio.gather(slow_request, return_exceptions=True)
    if isinstance(slow_outcome, ProxyResponseError):
        assert slow_outcome.status_code != 409, (
            f"The slow request itself failed with a 409: {slow_outcome.payload!r}"
        )

    served = await _send_ok(bridge, "The request after the slow open finished")
    assert served is winner, "The next request should be served by the session the third request opened."
    _assert_serving(await _stored(bridge, winner), winner)


async def test_last_session_teardown_closes_its_row(
    make_bridge: Callable[[str], Bridge],
) -> None:
    """When a session's upstream closes and nothing has replaced it, its
    teardown closes the stored row and leaves it without an owner. The next
    request then opens a new session and is served.
    """
    bridge = make_bridge("turn-teardown")
    first = _bridge_session(bridge.key, bridge.turn_state)
    second = _bridge_session(bridge.key, bridge.turn_state)
    bridge.sessions.extend([first, second])

    assert await _send_ok(bridge, "The first request") is first
    await _retire(bridge, first)
    await bridge.service._close_http_bridge_session(first)

    stored = await _stored(bridge, first)
    assert (stored.owner_instance_id, stored.state) == (None, HttpBridgeSessionState.CLOSED), (
        "The teardown of the only session should close its row and clear the owner; "
        f"got owner {stored.owner_instance_id!r}, state {stored.state!r}."
    )

    assert await _send_ok(bridge, "The request after the teardown") is second
    assert await _send_ok(bridge, "The request after that") is second
    _assert_serving(await _stored(bridge, second), second)


async def test_foreign_claim_still_rejected(
    coordinator: DurableBridgeSessionCoordinator,
) -> None:
    """A claim that is not allowed to take over, made against a session another
    replica holds with a live lease, returns the current owner unchanged and
    leaves the row as it was.
    """

    async def claim(instance_id: str, *, allow_takeover: bool) -> Any:
        return await coordinator.claim_live_session(
            session_key_kind="session_header",
            session_key_value="sid-foreign-live",
            api_key_id=None,
            instance_id=instance_id,
            owner_process_epoch="test-process",
            lease_ttl_seconds=60.0,
            account_id="acc-1",
            model=MODEL,
            service_tier=None,
            latest_turn_state="http_turn_1",
            latest_response_id="resp_1",
            allow_takeover=allow_takeover,
        )

    owner = await claim("instance-a", allow_takeover=True)
    assert owner.owner_instance_id == "instance-a"

    rejected = await claim("instance-b", allow_takeover=False)

    assert rejected.owner_instance_id == "instance-a", (
        "A non-takeover claim against a live foreign owner must return the "
        f"existing owner, not take the row; got {rejected.owner_instance_id!r}."
    )
    assert rejected.state == HttpBridgeSessionState.ACTIVE
    assert rejected.owner_epoch == owner.owner_epoch, (
        "The live foreign owner's epoch must be unchanged by a rejected claim; "
        f"got {rejected.owner_epoch}, expected {owner.owner_epoch}."
    )
    [stored] = await coordinator.lookup_sessions(session_ids=[owner.session_id])
    assert (stored.owner_instance_id, stored.owner_epoch, stored.state) == (
        "instance-a",
        owner.owner_epoch,
        HttpBridgeSessionState.ACTIVE,
    )
