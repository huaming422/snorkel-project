"""Durable bridge session ownership under reconnect and concurrent claims.

These tests drive the durable-session ownership layer through its coordinator
(``DurableBridgeSessionCoordinator.claim_live_session`` /
``release_live_session`` / ``lookup_sessions``) against an in-memory SQLite
engine, the same harness ``tests/unit/test_durable_bridge_sessions.py`` uses.
They assert on the returned ``DurableBridgeLookup`` values and on the stored
row, not on SQL text or attribute names.

To make an interleaving deterministic, some tests wrap the repository module's
``sqlite_writer_section`` (the writer lock every durable-bridge write already
goes through) so a competing release or claim commits the first time a claim
enters it.
"""

from __future__ import annotations

import contextlib
from collections.abc import AsyncIterator, Callable

import pytest
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.db.models import Base, HttpBridgeSessionState
from app.modules.proxy.durable_bridge_coordinator import DurableBridgeSessionCoordinator
from app.modules.proxy.durable_bridge_repository import DurableBridgeRepository


@pytest.fixture
async def async_session_factory() -> AsyncIterator[Callable[[], AsyncSession]]:
    """In-memory SQLite engine + session factory, mirroring the repository's own
    unit-test fixture (``expire_on_commit=False`` so snapshots survive commit)."""
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    session_maker = async_sessionmaker(engine, expire_on_commit=False)

    def get_session() -> AsyncSession:
        return session_maker()

    yield get_session

    await engine.dispose()


@pytest.fixture
async def coordinator(
    async_session_factory: Callable[[], AsyncSession],
) -> DurableBridgeSessionCoordinator:
    return DurableBridgeSessionCoordinator(async_session_factory)


async def _claim(
    coordinator: DurableBridgeSessionCoordinator,
    *,
    session_key_value: str,
    instance_id: str,
    account_id: str = "acc-1",
    allow_takeover: bool,
    latest_turn_state: str | None = None,
    latest_response_id: str | None = None,
    owner_process_epoch: str = "test-process",
):
    """``claim_live_session`` with the fixed arguments these scenarios share."""
    return await coordinator.claim_live_session(
        session_key_kind="session_header",
        session_key_value=session_key_value,
        api_key_id=None,
        instance_id=instance_id,
        owner_process_epoch=owner_process_epoch,
        lease_ttl_seconds=60.0,
        account_id=account_id,
        model="gpt-5.4",
        service_tier=None,
        latest_turn_state=latest_turn_state,
        latest_response_id=latest_response_id,
        allow_takeover=allow_takeover,
    )


async def test_same_instance_reclaim_survives_older_session_release(
    coordinator: DurableBridgeSessionCoordinator,
) -> None:
    """A new session on the same instance claims a session key that an older
    local session still holds. When the older session's teardown release arrives
    afterwards, the new session keeps the row: it stays ACTIVE and owned by this
    instance at the new session's epoch.
    """
    claimed = await _claim(
        coordinator,
        session_key_value="sid-fence",
        instance_id="instance-a",
        allow_takeover=True,
        latest_turn_state="http_turn_1",
        latest_response_id="resp_1",
    )

    successor = await _claim(
        coordinator,
        session_key_value="sid-fence",
        instance_id="instance-a",
        allow_takeover=True,
        latest_turn_state="http_turn_2",
        latest_response_id="resp_2",
    )

    assert successor.session_id == claimed.session_id
    assert successor.owner_epoch == claimed.owner_epoch + 1, (
        "Reclaiming a live session from the same instance should hand the new "
        f"holder a newer owner epoch; got epoch {successor.owner_epoch}, expected "
        f"{claimed.owner_epoch + 1}."
    )

    # The older session's teardown release arrives after the new claim.
    released = await coordinator.release_live_session(
        session_id=claimed.session_id,
        instance_id="instance-a",
        owner_epoch=claimed.owner_epoch,
        draining=False,
    )
    assert released is not None
    assert released.owner_instance_id == "instance-a", (
        "The older session's release closed the row under the new session; "
        f"got owner {released.owner_instance_id!r}."
    )
    assert released.state == HttpBridgeSessionState.ACTIVE, (
        f"The row should stay ACTIVE after the older session's release; got {released.state!r}."
    )
    assert released.owner_epoch == successor.owner_epoch


async def test_release_landing_mid_claim_leaves_claimant_owner(
    coordinator: DurableBridgeSessionCoordinator,
    async_session_factory: Callable[[], AsyncSession],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The older session's teardown release commits while the new session's
    claim is in progress. The claim still comes back ACTIVE, owned by this
    instance, at the next epoch, rather than as a closed row with no owner.
    """
    predecessor = await _claim(
        coordinator,
        session_key_value="sid-race",
        instance_id="instance-a",
        allow_takeover=True,
        latest_turn_state="http_turn_1",
        latest_response_id="resp_1",
    )

    import app.modules.proxy.durable_bridge_repository as repository_module

    real_writer_section = repository_module.sqlite_writer_section
    release_injected = False

    @contextlib.asynccontextmanager
    async def writer_section_with_interleaved_release():
        nonlocal release_injected
        if not release_injected:
            release_injected = True
            # The older session's release commits while the claim is in progress.
            async with async_session_factory() as release_session:
                await DurableBridgeRepository(release_session).release_session(
                    session_id=predecessor.session_id,
                    instance_id="instance-a",
                    owner_epoch=predecessor.owner_epoch,
                    draining=False,
                )
        async with real_writer_section():
            yield

    monkeypatch.setattr(
        repository_module, "sqlite_writer_section", writer_section_with_interleaved_release
    )

    successor = await _claim(
        coordinator,
        session_key_value="sid-race",
        instance_id="instance-a",
        allow_takeover=False,
    )

    assert release_injected is True, "the interleaved release must have been injected"
    assert successor.session_id == predecessor.session_id
    assert successor.owner_instance_id == "instance-a", (
        "The claim came back without this instance as owner after a release "
        f"landed mid-claim; got owner {successor.owner_instance_id!r}."
    )
    assert successor.state == HttpBridgeSessionState.ACTIVE, (
        f"The claimed row should be ACTIVE; got {successor.state!r}."
    )
    assert successor.owner_epoch == predecessor.owner_epoch + 1


async def test_concurrent_same_instance_claims_get_distinct_epochs(
    coordinator: DurableBridgeSessionCoordinator,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Two new sessions on the same instance claim the same session key at the
    same time. Each ends up with its own owner epoch, the later one higher, and
    the stored row matches the claim that finished last.
    """
    predecessor = await _claim(
        coordinator,
        session_key_value="sid-cas",
        instance_id="instance-a",
        allow_takeover=True,
    )

    import app.modules.proxy.durable_bridge_repository as repository_module

    real_writer_section = repository_module.sqlite_writer_section
    competitor_epochs: list[int] = []
    injected = False

    @contextlib.asynccontextmanager
    async def writer_section_with_competing_claim():
        nonlocal injected
        if not injected:
            injected = True
            # A competing same-instance claim commits while this claim is in
            # progress.
            competitor = await _claim(
                coordinator,
                session_key_value="sid-cas",
                instance_id="instance-a",
                allow_takeover=False,
            )
            competitor_epochs.append(competitor.owner_epoch)
        async with real_writer_section():
            yield

    monkeypatch.setattr(
        repository_module, "sqlite_writer_section", writer_section_with_competing_claim
    )

    raced = await _claim(
        coordinator,
        session_key_value="sid-cas",
        instance_id="instance-a",
        allow_takeover=False,
    )

    assert competitor_epochs == [predecessor.owner_epoch + 1], (
        "The competing claim should have taken the next epoch; got "
        f"{competitor_epochs!r}."
    )
    assert raced.owner_instance_id == "instance-a"
    assert raced.owner_epoch > competitor_epochs[0], (
        "Two concurrent claims came back holding the same owner epoch "
        f"(competitor {competitor_epochs[0]}, raced {raced.owner_epoch}); the one "
        "that finished last should hold a higher epoch."
    )
    [stored] = await coordinator.lookup_sessions(session_ids=[raced.session_id])
    assert (stored.owner_instance_id, stored.owner_epoch, stored.state) == (
        "instance-a",
        raced.owner_epoch,
        HttpBridgeSessionState.ACTIVE,
    ), f"The stored row does not match the last claim's result; got {stored!r}."


async def test_racing_foreign_claims_never_share_an_epoch(
    coordinator: DurableBridgeSessionCoordinator,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Two replicas race to pick up a released session; both were allowed to
    take it over when they decided to claim. Whichever outcome the losing claim
    reports, the replicas never hold the same owner epoch: either it reports the
    other replica as owner at that replica's epoch, or it takes the row at a
    strictly higher epoch. The stored row agrees with what it reported.
    """
    released = await _claim(
        coordinator,
        session_key_value="sid-foreign-cas",
        instance_id="instance-old",
        allow_takeover=True,
    )
    # The previous owner releases, so the row is open for takeover when both
    # replicas decide to claim it.
    await coordinator.release_live_session(
        session_id=released.session_id,
        instance_id="instance-old",
        owner_epoch=released.owner_epoch,
        draining=False,
    )

    import app.modules.proxy.durable_bridge_repository as repository_module

    real_writer_section = repository_module.sqlite_writer_section
    injected = False
    winner_epoch: list[int] = []

    @contextlib.asynccontextmanager
    async def writer_section_with_foreign_winner():
        nonlocal injected
        if not injected:
            injected = True
            winner = await _claim(
                coordinator,
                session_key_value="sid-foreign-cas",
                instance_id="instance-b",
                allow_takeover=True,
            )
            winner_epoch.append(winner.owner_epoch)
        async with real_writer_section():
            yield

    monkeypatch.setattr(
        repository_module, "sqlite_writer_section", writer_section_with_foreign_winner
    )

    loser = await _claim(
        coordinator,
        session_key_value="sid-foreign-cas",
        instance_id="instance-a",
        allow_takeover=True,
    )

    assert winner_epoch, "the other replica's claim must have been injected"
    assert loser.state == HttpBridgeSessionState.ACTIVE
    if loser.owner_instance_id == "instance-b":
        assert loser.owner_epoch == winner_epoch[0], (
            "The claim reported the other replica as owner but at a different "
            f"epoch; got {loser.owner_epoch}, expected {winner_epoch[0]}."
        )
    else:
        assert loser.owner_instance_id == "instance-a", (
            f"Unexpected owner {loser.owner_instance_id!r}."
        )
        assert loser.owner_epoch > winner_epoch[0], (
            "Both replicas came back owning the session at owner epoch "
            f"{winner_epoch[0]}; a takeover after the other replica's claim needs "
            f"a higher epoch (got {loser.owner_epoch})."
        )
    [stored] = await coordinator.lookup_sessions(session_ids=[loser.session_id])
    assert (stored.owner_instance_id, stored.owner_epoch, stored.state) == (
        loser.owner_instance_id,
        loser.owner_epoch,
        HttpBridgeSessionState.ACTIVE,
    ), f"The stored row does not match what the claim reported; got {stored!r}."


async def test_foreign_claim_still_rejected(
    coordinator: DurableBridgeSessionCoordinator,
) -> None:
    """A claim that is not allowed to take over, made against a session another
    replica holds with a live lease, returns the current owner unchanged and
    leaves the row as it was.
    """
    owner = await _claim(
        coordinator,
        session_key_value="sid-foreign-live",
        instance_id="instance-a",
        allow_takeover=True,
        latest_turn_state="http_turn_1",
        latest_response_id="resp_1",
    )
    assert owner.owner_instance_id == "instance-a"

    rejected = await _claim(
        coordinator,
        session_key_value="sid-foreign-live",
        instance_id="instance-b",
        allow_takeover=False,
    )

    assert rejected.owner_instance_id == "instance-a", (
        "A non-takeover claim against a live foreign owner must return the "
        f"existing owner, not take the row; got {rejected.owner_instance_id!r}."
    )
    assert rejected.state == HttpBridgeSessionState.ACTIVE
    assert rejected.owner_epoch == owner.owner_epoch, (
        "The live foreign owner's epoch must be unchanged by a rejected claim; "
        f"got {rejected.owner_epoch}, expected {owner.owner_epoch}."
    )
