## Task

On single-instance codex-lb deployments, the odd `/v1/responses` request comes back as a 409 `bridge_instance_mismatch`, telling the client another replica owns its session. There is no other replica. A retry goes through, but it shouldn't happen at all.

Most of the ones we've pulled came right after a long-lived session's upstream WebSocket closed cleanly: the request that reconnected the session got the 409, or the one after it did. A few were on a session that was slow to open. A second request for it gave up with a 429 `capacity_exhausted_active_sessions`, a later request opened it and was served fine, and the request after that got the 409.

Please track this down and stop single-instance deployments from returning these.
