## Task

A small number of `/v1/responses` requests on single-instance deployments fail with a 409 and error code `bridge_instance_mismatch`. That shouldn't be possible with one instance, since there's no other replica that could own the session. It's rare, it comes in clusters, and sending the same request again works.

Each failure we've traced was on a long-lived session: its upstream WebSocket closed cleanly, and the 409 came back on the very next request for that session.

Track down the cause and fix it so single-instance deployments stop returning these.
