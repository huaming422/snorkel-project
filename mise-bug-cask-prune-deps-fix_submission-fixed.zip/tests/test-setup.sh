#!/usr/bin/env bash
# Test-setup for mise-bug-cask-prune-deps. The image bakes the full workspace
# dependency closure at the base commit and pre-warms the cargo cache with a
# `cargo build --locked --bin mise`, and installs python3 (the
# verifier's offline Homebrew-metadata fixture server). Nothing needs to be
# installed or fetched here; there are no services to start and no data to seed.

set -euo pipefail

echo "[test-setup] Rust version:    $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:   $(cargo --version 2>&1 | head -1)"
echo "[test-setup] python3 version: $(python3 --version 2>&1 | head -1)"
echo "[test-setup] Workspace root:  /repo/mise"
echo "[test-setup] Setup complete."
