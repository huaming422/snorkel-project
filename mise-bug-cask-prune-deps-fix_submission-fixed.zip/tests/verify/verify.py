"""End-to-end tests for Homebrew dependency-aware package pruning.

The tests drive the real mise CLI against an isolated Homebrew prefix and a
loopback metadata server. They cover direct and transitive formula/cask
dependencies, custom-tap behavior, and distinct roots with the same token in
different taps. Every scenario also contains an
unreferenced package that must still be reported for removal.

The fixture uses production configuration seams: ``MISE_SYSTEM_BREW_PREFIX``
for the fake installation, ``MISE_URL_REPLACEMENTS`` for offline metadata, and
``MISE_STATE_DIR`` for isolated cask state. No repository internals are
imported or inspected.
"""

from __future__ import annotations

import hashlib
import json
import os
import socket
import subprocess
import sys
import textwrap
import time
from pathlib import Path
from typing import Iterator

import pytest

# ---------------------------------------------------------------------------
# Repo / binary location
# ---------------------------------------------------------------------------

REPO_DIR = Path(f"/repo/{os.environ.get('REPO_NAME', 'mise')}")
# Honor CARGO_TARGET_DIR (the task image sets it to /opt/cache/cargo-target so
# the warm cargo cache survives outside the clone); fall back to the in-tree
# target/ dir for a plain checkout. The debug `mise` bin lands under
# <target>/debug/mise either way.
_TARGET_DIR = Path(os.environ.get("CARGO_TARGET_DIR") or (REPO_DIR / "target"))
MISE_BIN = _TARGET_DIR / "debug" / "mise"

# Wall-clock ceilings. The image pre-builds the debug binary
# (`cargo build --locked --bin mise`), so the warm path is a no-op;
# the cold-cache rebuild is the only slow step.
BUILD_TIMEOUT_S = 900
PRUNE_TIMEOUT_S = 120
SERVER_BOOT_TIMEOUT_S = 30.0


# ---------------------------------------------------------------------------
# Build the binary (defensive; test-setup warms it)
# ---------------------------------------------------------------------------


def _build_mise() -> None:
    # ALWAYS (re)build — never early-return on an existing binary. The task image
    # bakes the warm cargo cache and a debug `mise` built from the initial source;
    # source changes are applied after that image build and must be recompiled.
    # If we skipped the build when the stale binary
    # already existed, every trial would silently run base behavior and the
    # verifier could never separate a real fix from no change. The warm cache
    # makes this an incremental rebuild (only the edited crate recompiles).
    proc = subprocess.run(
        ["cargo", "build", "--locked", "--bin", "mise"],
        cwd=str(REPO_DIR),
        capture_output=True,
        text=True,
        timeout=BUILD_TIMEOUT_S,
        check=False,
    )
    if proc.returncode != 0 or not MISE_BIN.exists():
        raise RuntimeError(
            "cargo build --bin mise failed.\n"
            f"--- stdout ---\n{proc.stdout[-3000:]}\n"
            f"--- stderr ---\n{proc.stderr[-3000:]}"
        )


# ---------------------------------------------------------------------------
# Loopback Homebrew-metadata fixture server
# ---------------------------------------------------------------------------

# A single python3 process serves official metadata at /api/... and custom-tap
# metadata below a namespace such as /taps/acme/HEAD/api/....

_SERVER_SRC = r'''
import json, os, sys, http.server, socketserver
fixture_dir = sys.argv[1]
port_file = sys.argv[2]

class H(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        path = self.path.split("?", 1)[0]
        local = None
        for kind in ("formula", "cask"):
            marker = f"/api/{kind}/"
            if marker in path and path.endswith(".json"):
                namespace, filename = path.split(marker, 1)
                local = os.path.join(fixture_dir, namespace.strip("/"), kind, filename)
                break
        if local and os.path.isfile(local):
            with open(local, "rb") as f:
                body = f.read()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, *a):
        pass

class S(socketserver.ThreadingTCPServer):
    allow_reuse_address = True

with S(("127.0.0.1", 0), H) as httpd:
    port = httpd.server_address[1]
    tmp = port_file + ".tmp"
    with open(tmp, "w") as f:
        f.write(str(port))
    os.replace(tmp, port_file)
    httpd.serve_forever()
'''


class FixtureServer:
    def __init__(self, fixture_dir: Path, port_file: Path) -> None:
        self.fixture_dir = fixture_dir
        self.port_file = port_file
        self.proc: subprocess.Popen | None = None
        self.port: int | None = None

    def start(self) -> None:
        (self.fixture_dir / "formula").mkdir(parents=True, exist_ok=True)
        (self.fixture_dir / "cask").mkdir(parents=True, exist_ok=True)
        self.proc = subprocess.Popen(
            [sys.executable, "-u", "-c", _SERVER_SRC, str(self.fixture_dir), str(self.port_file)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        deadline = time.monotonic() + SERVER_BOOT_TIMEOUT_S
        while time.monotonic() < deadline:
            if self.proc.poll() is not None:
                raise RuntimeError("fixture server exited during boot")
            if self.port_file.exists():
                text = self.port_file.read_text().strip()
                if text:
                    self.port = int(text)
                    return
            time.sleep(0.05)
        self.stop()
        raise RuntimeError("fixture server never wrote its port file")

    def _metadata_path(self, kind: str, name: str, namespace: str | None) -> Path:
        root = self.fixture_dir
        if namespace:
            root = root / namespace.strip("/")
        path = root / kind / f"{name}.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        return path

    def write_formula(
        self,
        name: str,
        version: str = "1.0.0",
        namespace: str | None = None,
    ) -> None:
        self._metadata_path("formula", name, namespace).write_text(
            json.dumps({"name": name, "versions": {"stable": version}})
        )

    def write_cask(
        self,
        token: str,
        version: str = "1.0.0",
        depends_formula: list[str] | None = None,
        depends_cask: list[str] | None = None,
        namespace: str | None = None,
    ) -> None:
        body = {
            "token": token,
            "version": version,
            "url": "https://example.invalid/cask.zip",
            "depends_on": {
                "formula": depends_formula or [],
                "cask": depends_cask or [],
            },
        }
        self._metadata_path("cask", token, namespace).write_text(json.dumps(body))

    def stop(self) -> None:
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                self.proc.wait(timeout=5)


# ---------------------------------------------------------------------------
# Fake Homebrew prefix: installed formula kegs and casks
# ---------------------------------------------------------------------------


def _install_formula_keg(prefix: Path, name: str, version: str = "1.0.0") -> None:
    """Mirror maintenance.rs test helper write_keg + write_linked_record.

    Creates Cellar/<name>/<version>/{bin/<name>,INSTALL_RECEIPT.json},
    opt/<name> -> ../Cellar/<name>/<version>,
    bin/<name> -> ../Cellar/<name>/<version>/bin/<name>,
    var/homebrew/linked/<name> -> ../../../Cellar/<name>/<version>.
    installed_on_request=true so linked_formulae enumerates it.
    """
    keg = prefix / "Cellar" / name / version
    (keg / "bin").mkdir(parents=True, exist_ok=True)
    (keg / "bin" / name).write_text("")
    (keg / "INSTALL_RECEIPT.json").write_text(
        json.dumps({"installed_on_request": True, "source": {"tap": "homebrew/core"}})
    )
    opt = prefix / "opt"
    opt.mkdir(parents=True, exist_ok=True)
    _symlink(Path("../Cellar") / name / version, opt / name)
    binc = prefix / "bin"
    binc.mkdir(parents=True, exist_ok=True)
    _symlink(Path("../Cellar") / name / version / "bin" / name, binc / name)
    linked = prefix / "var" / "homebrew" / "linked"
    linked.mkdir(parents=True, exist_ok=True)
    _symlink(Path("../../../Cellar") / name / version, linked / name)


def _install_cask(prefix: Path, token: str, version: str = "1.0.0") -> None:
    """Mirror e2e/cli/test_system_prune_brew_cask: a prune-safe mise-owned cask.

    Caskroom/<token>/<version>/bin/<token> is the staged binary; a symlink
    <prefix>/bin/<token> points at it. The receipt records that symlink target
    with a symlink fingerprint whose digest is the sha256 of the binary target
    PATH STRING (the repo's `cask_target_fingerprint` for a symlink). No
    `.metadata` dir (that marks a Homebrew-owned cask, which prune skips).
    Target paths are unique per token so the shared-target guard never trips.
    """
    version_dir = prefix / "Caskroom" / token / version
    binary = version_dir / "bin" / token
    target = prefix / "bin" / token
    (version_dir / "bin").mkdir(parents=True, exist_ok=True)
    (prefix / "bin").mkdir(parents=True, exist_ok=True)
    binary.write_text("#!/bin/sh\n")
    _symlink(binary, target)  # absolute symlink, as the e2e template does
    digest = hashlib.sha256(str(binary).encode()).hexdigest()
    (version_dir / ".mise-cask.toml").write_text(
        textwrap.dedent(
            f"""\
            schema_version = 3
            version = "{version}"
            binaries = ["{target}"]
            prune_safe = true

            [[targets]]
            path = "{target}"

            [targets.fingerprint]
            kind = "symlink"
            digest = "{digest}"
            """
        )
    )


def _symlink(target: Path, link: Path) -> None:
    if link.exists() or link.is_symlink():
        link.unlink()
    os.symlink(target, link)


# ---------------------------------------------------------------------------
# Driving the CLI
# ---------------------------------------------------------------------------


def _write_config(workdir: Path, kept: list[str]) -> None:
    lines = ["[bootstrap.packages]"]
    for entry in kept:
        lines.append(f'"{entry}" = "latest"')
    (workdir / "mise.toml").write_text("\n".join(lines) + "\n")


def _run_prune(
    workdir: Path,
    prefix: Path,
    state: Path,
    port: int,
    manager: str,
    extra_url_replacements: dict[str, str] | None = None,
) -> str:
    """Run `mise bootstrap packages prune --manager <m> --dry-run` offline.

    Returns combined stdout+stderr. Mirrors the e2e harness isolation: a fake
    HOME/config/state inside workdir, the config path trusted, URL replacements
    pointed at the loopback server, and the fake brew prefix.
    """
    home = workdir / "home"
    for sub in (".config/mise", ".local/share/mise", ".cache/mise"):
        (home / sub).mkdir(parents=True, exist_ok=True)
    state.mkdir(parents=True, exist_ok=True)
    url_replacements = {"https://formulae.brew.sh": f"http://127.0.0.1:{port}"}
    url_replacements.update(extra_url_replacements or {})
    env = {
        **os.environ,
        "HOME": str(home),
        "MISE_EXPERIMENTAL": "1",
        "MISE_YES": "1",
        "MISE_TRUSTED_CONFIG_PATHS": str(workdir),
        "MISE_CONFIG_DIR": str(home / ".config/mise"),
        "MISE_DATA_DIR": str(home / ".local/share/mise"),
        "MISE_CACHE_DIR": str(home / ".cache/mise"),
        "MISE_STATE_DIR": str(state),
        "MISE_SYSTEM_BREW_PREFIX": str(prefix),
        "MISE_URL_REPLACEMENTS": json.dumps(url_replacements),
    }
    proc = subprocess.run(
        [str(MISE_BIN), "bootstrap", "packages", "prune", "--manager", manager, "--dry-run"],
        cwd=str(workdir),
        env=env,
        capture_output=True,
        text=True,
        timeout=PRUNE_TIMEOUT_S,
        check=False,
    )
    if proc.returncode != 0:
        raise AssertionError(
            f"prune --manager {manager} exited {proc.returncode}\n"
            f"--- stdout ---\n{proc.stdout}\n--- stderr ---\n{proc.stderr}"
        )
    return proc.stdout + proc.stderr


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="session", autouse=True)
def _built() -> None:
    _build_mise()


@pytest.fixture
def world(tmp_path: Path) -> Iterator[tuple[Path, Path, Path, FixtureServer]]:
    """A fresh workdir, fake brew prefix, state dir, and running fixture server."""
    workdir = tmp_path / "work"
    prefix = tmp_path / "brew-prefix"
    state = tmp_path / "state"
    workdir.mkdir()
    prefix.mkdir()
    server = FixtureServer(tmp_path / "fixtures", tmp_path / "port")
    server.start()
    try:
        yield workdir, prefix, state, server
    finally:
        server.stop()


# ---------------------------------------------------------------------------
# Brew manager keeps a configured cask's formula dependency
# ---------------------------------------------------------------------------


def test_brew_keeps_cask_formula_dependency(world) -> None:
    workdir, prefix, state, server = world
    # app-x is a kept cask depending on formula libdep; libdep is installed but
    # not itself a configured brew: package. orphan is a genuinely-unused
    # installed formula (negative control).
    server.write_cask("app-x", depends_formula=["libdep"])
    server.write_formula("libdep")
    _install_formula_keg(prefix, "libdep")
    _install_formula_keg(prefix, "orphan")
    _install_cask(prefix, "app-x")  # kept cask must physically exist in prefix
    _write_config(workdir, ["brew-cask:app-x"])

    out = _run_prune(workdir, prefix, state, server.port, "brew")

    # Headline: the dependency of the kept cask must be preserved.
    assert "remove brew:libdep@1.0.0" not in out, (
        "the kept cask app-x depends on formula libdep, but prune reported it "
        f"for removal:\n{out}"
    )
    # Negative control: a genuinely-orphaned formula MUST still be pruned, so a
    # keep-everything stub cannot satisfy this test.
    assert "remove brew:orphan@1.0.0" in out, (
        "orphan is unused and must still be pruned; a fix that keeps everything "
        f"is wrong:\n{out}"
    )


# ---------------------------------------------------------------------------
# Brew manager follows transitive cask edges to required formulae
# ---------------------------------------------------------------------------


def test_brew_keeps_transitive_cask_formula_dependency(world) -> None:
    workdir, prefix, state, server = world
    # The kept cask (app-root) declares NO formula dependency of its own; it
    # depends on another cask (mid-cask), and it is THAT cask which depends on
    # formula deeplib. Keeping app-root must therefore keep deeplib, because the
    # brew keep-set has to follow the full transitive cask closure of a kept
    # cask — not just the formulae the directly-configured cask names. A fix
    # that extends the brew keep-set with only the directly-configured casks'
    # own formula dependencies passes test_brew_keeps_cask_formula_dependency
    # but still removes deeplib here. orphan is the negative control.
    server.write_cask("app-root", depends_cask=["mid-cask"])
    server.write_cask("mid-cask", depends_formula=["deeplib"])
    server.write_formula("deeplib")
    _install_formula_keg(prefix, "deeplib")
    _install_formula_keg(prefix, "orphan")
    _install_cask(prefix, "app-root")
    _install_cask(prefix, "mid-cask")  # transitively-needed cask must exist too
    _write_config(workdir, ["brew-cask:app-root"])

    out = _run_prune(workdir, prefix, state, server.port, "brew")

    # Headline: a formula needed only through a transitively-depended cask of
    # the kept cask must be preserved.
    assert "remove brew:deeplib@1.0.0" not in out, (
        "deeplib is a formula dependency of mid-cask, which the kept cask "
        "app-root depends on (app-root -> mid-cask -> formula deeplib); the "
        "brew keep-set must follow the kept cask's full transitive cask "
        f"closure, but prune reported deeplib for removal:\n{out}"
    )
    # Negative control: a genuinely-orphaned formula MUST still be pruned.
    assert "remove brew:orphan@1.0.0" in out, (
        "orphan is unused and must still be pruned; a fix that keeps everything "
        f"is wrong:\n{out}"
    )


# ---------------------------------------------------------------------------
# Brew-cask manager keeps a transitive cask dependency
# ---------------------------------------------------------------------------


def test_brew_cask_keeps_transitive_cask(world) -> None:
    workdir, prefix, state, server = world
    # A genuine two-hop dependency chain, kept via config:
    #   app-y  (kept) -> runtime-z -> deep-dep
    # Keeping app-y must keep BOTH runtime-z (direct) and deep-dep (transitive,
    # two hops away). A fix that only keeps direct dependencies would still
    # remove deep-dep and fail this test. unused-cask is the negative control.
    server.write_cask("app-y", depends_cask=["runtime-z"])
    server.write_cask("runtime-z", depends_cask=["deep-dep"])
    server.write_cask("deep-dep")
    server.write_cask("unused-cask")
    _install_cask(prefix, "app-y")
    _install_cask(prefix, "runtime-z")
    _install_cask(prefix, "deep-dep")
    _install_cask(prefix, "unused-cask")
    _write_config(workdir, ["brew-cask:app-y"])

    out = _run_prune(workdir, prefix, state, server.port, "brew-cask")

    # Headline: the direct cask dependency must be preserved.
    assert "remove brew-cask:runtime-z@1.0.0" not in out, (
        "the kept cask app-y depends on cask runtime-z, but prune reported it "
        f"for removal:\n{out}"
    )
    # Transitivity: a dependency two hops away must also be preserved — a
    # direct-dependencies-only fix would wrongly remove it.
    assert "remove brew-cask:deep-dep@1.0.0" not in out, (
        "deep-dep is a transitive (two-hop) dependency of the kept cask app-y "
        f"(app-y -> runtime-z -> deep-dep) and must be kept:\n{out}"
    )
    # Negative control: an unreferenced cask MUST still be pruned.
    assert "remove brew-cask:unused-cask@1.0.0" in out, (
        "unused-cask is referenced by nothing and must still be pruned:\n" + out
    )


def test_custom_tap_cask_dependency_inherits_parent_tap(world) -> None:
    workdir, prefix, state, server = world
    namespace = "taps/acme/HEAD"
    server.write_cask(
        "custom-app",
        depends_cask=["custom-runtime"],
        namespace=namespace,
    )
    server.write_cask("custom-runtime", namespace=namespace)
    server.write_cask("unused-cask")
    _install_cask(prefix, "custom-app")
    _install_cask(prefix, "custom-runtime")
    _install_cask(prefix, "unused-cask")
    _write_config(workdir, ["brew-cask:acme/tools/custom-app"])

    out = _run_prune(
        workdir,
        prefix,
        state,
        server.port,
        "brew-cask",
        {
            "https://raw.githubusercontent.com/acme/homebrew-tools":
                f"http://127.0.0.1:{server.port}/taps/acme"
        },
    )

    assert "remove brew-cask:custom-runtime@1.0.0" not in out, (
        "custom-runtime belongs to the configured cask's custom tap and must "
        f"remain installed:\n{out}"
    )
    assert "remove brew-cask:unused-cask@1.0.0" in out, (
        "the unrelated cask must still be pruned:\n" + out
    )


def test_same_token_from_distinct_taps_contributes_each_dependency(world) -> None:
    workdir, prefix, state, server = world
    server.write_cask(
        "shared-app",
        depends_formula=["acme-lib"],
        namespace="taps/acme/HEAD",
    )
    server.write_formula("acme-lib", namespace="taps/acme/HEAD")
    server.write_cask(
        "shared-app",
        depends_formula=["other-lib"],
        namespace="taps/other/HEAD",
    )
    server.write_formula("other-lib", namespace="taps/other/HEAD")
    _install_formula_keg(prefix, "acme-lib")
    _install_formula_keg(prefix, "other-lib")
    _install_formula_keg(prefix, "orphan")
    _install_cask(prefix, "shared-app")
    _write_config(
        workdir,
        [
            "brew-cask:acme/tools/shared-app",
            "brew-cask:other/tools/shared-app",
        ],
    )

    out = _run_prune(
        workdir,
        prefix,
        state,
        server.port,
        "brew",
        {
            "https://raw.githubusercontent.com/acme/homebrew-tools":
                f"http://127.0.0.1:{server.port}/taps/acme",
            "https://raw.githubusercontent.com/other/homebrew-tools":
                f"http://127.0.0.1:{server.port}/taps/other",
        },
    )

    assert "remove brew:acme-lib@1.0.0" not in out, out
    assert "remove brew:other-lib@1.0.0" not in out, (
        "both custom-tap roots use the same cask token, but each root's "
        f"dependency must be retained:\n{out}"
    )
    assert "remove brew:orphan@1.0.0" in out, (
        "the unrelated formula must still be pruned:\n" + out
    )
