## Task

After I run `mise bootstrap packages prune`, some Homebrew casks that are still listed in my mise config stop working because packages they rely on have been removed. I have seen missing formulae as well as missing casks, and the problem also affects configured casks installed from custom taps.

Could you investigate why prune is treating those required packages as unused and fix it? Packages that really are no longer needed should still be cleaned up.
