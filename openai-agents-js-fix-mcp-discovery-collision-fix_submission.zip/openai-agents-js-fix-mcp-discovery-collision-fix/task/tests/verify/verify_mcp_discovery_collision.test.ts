// Behavioral verifier for the deferred hosted-MCP discovery-collision bug.
//
// This suite drives the SDK entirely through its PUBLIC @openai/agents-core
// surface (Agent / Runner / MemorySession / RunState / hostedMcpTool /
// toolNamespace / tool) plus the offline ScriptedModel test double. It never
// imports any implementation-internal helper, never names an internal field,
// and never asserts a schema constant: every assertion is on OBSERVABLE
// runner.run() behavior (does the run resolve or reject, what is the final
// output, what items the session recorded). The driver patterns are the
// repo's own test/hostedMcpToolSearch.test.ts helpers, reused verbatim.
//
// Coverage (the whole file must pass together):
//  - REJECT cases (collision / session-reuse / resume-collision) fail before the
//    bug is fixed and whenever a submission is still broken, because the deferred
//    hosted call is wrongly admitted and the run does not reject.
//  - ACCEPT cases (genuine discovery / resume-after-recorded-discovery / caller +
//    approval invariance) fail if a submission "fixes" the bug by rejecting every
//    deferred hosted call, or regresses caller/approval handling.
// A correct fix passes every case; any under- or over-correction fails at least
// one.

import { describe, expect, it, vi } from 'vitest';
import { z } from 'zod';
import {
  Agent,
  MemorySession,
  Runner,
  RunState,
  hostedMcpTool,
  tool,
  toolNamespace,
} from '../src';
import { ScriptedModel, assistantMessage } from '../src/testing';
import type * as protocol from '../src/types/protocol';

// --- Drivers (transcribed from test/hostedMcpToolSearch.test.ts) -----------

const server = () =>
  hostedMcpTool({
    serverLabel: 'OpenAI_Docs',
    serverUrl: 'https://example.invalid/mcp',
    deferLoading: true,
    requireApproval: 'never',
  });

const searchTool = {
  type: 'hosted_tool',
  name: 'tool_search',
  providerData: { type: 'tool_search' },
} as const;

// A genuine hosted-MCP discovery turn for the OpenAI_Docs server.
function discovery(namespace = 'mcp_OpenAI_Docs'): protocol.ModelItem[] {
  return [
    {
      type: 'hosted_tool_call',
      name: 'mcp_list_tools',
      status: 'completed',
      providerData: { type: 'mcp_list_tools', server_label: 'OpenAI_Docs' },
    },
    {
      type: 'tool_search_call',
      id: 'search',
      status: 'completed',
      arguments: { paths: [namespace] },
      providerData: { execution: 'server' },
    },
    {
      type: 'tool_search_output',
      id: 'search_output',
      status: 'completed',
      tools: [
        {
          type: 'namespace',
          name: namespace,
          description: 'Documentation tools',
          tools: [
            {
              type: 'function',
              name: 'search_openai_docs',
              description: 'Search documentation',
              parameters: {
                type: 'object',
                properties: {},
                additionalProperties: false,
              },
              strict: true,
            },
          ],
        },
      ],
      providerData: { execution: 'server' },
    },
  ];
}

// A deferred hosted-MCP tool call for the OpenAI_Docs server.
function call(
  name = 'search_openai_docs',
  type = 'mcp_call',
): protocol.HostedToolCallItem {
  return {
    type: 'hosted_tool_call',
    id: 'call_1',
    name: type,
    status: 'completed',
    output: 'Documentation found.',
    providerData: {
      type,
      id: 'call_1',
      server_label: 'OpenAI_Docs',
      name,
      arguments: '{}',
    },
  };
}

const runner = () => new Runner({ tracingDisabled: true });

// Local caller-side namespace that collides with the hosted server's wire
// namespace (mcp_<serverLabel>). Discovering THIS must not count as loading the
// hosted server.
const collidingLocalTools = (execute: () => Promise<string>) =>
  toolNamespace({
    name: 'mcp_OpenAI_Docs',
    description: 'Local documentation',
    tools: [
      tool({
        name: 'search_openai_docs',
        description: 'Local search',
        parameters: z.object({}),
        deferLoading: true,
        execute,
      }),
    ],
  });

describe('deferred hosted MCP discovery collision', () => {
  // C2 (accept): a genuine hosted-MCP discovery turn loads the server, so the
  // following deferred hosted call is admitted and the session records an
  // mcp_call item. Guards against a fix that rejects every deferred hosted call.
  it('accepts a deferred hosted call after genuine hosted MCP discovery', async () => {
    const model = new ScriptedModel([
      [...discovery(), assistantMessage('Tools loaded.')],
      [call(), assistantMessage('Done.')],
    ]);
    const agent = new Agent({
      name: 'Docs',
      model,
      tools: [server(), searchTool],
    });
    const session = new MemorySession();
    expect(
      (await runner().run(agent, 'Discover tools.', { session })).finalOutput,
    ).toBe('Tools loaded.');
    expect(
      (await runner().run(agent, 'Search docs.', { session })).finalOutput,
    ).toBe('Done.');
    expect(
      (await session.getItems()).some(
        (item) =>
          item.type === 'hosted_tool_call' &&
          item.providerData?.type === 'mcp_call',
      ),
    ).toBe(true);
    model.assertComplete();
  });

  // C1 (reject): discovering only the colliding caller-side namespace must NOT
  // load the hosted server; the later deferred hosted call rejects. The two
  // runner.run() turns share one MemorySession, so this also exercises the
  // cross-turn persistence path (C3). Pre-fix the call is wrongly admitted.
  it.each([false, true])(
    'rejects a deferred hosted call when only a colliding user namespace was discovered (stream: %s)',
    async (stream) => {
      const execute = vi.fn(async () => 'local result');
      const localTools = collidingLocalTools(execute);
      const localCall: protocol.FunctionCallItem = {
        type: 'function_call',
        name: 'search_openai_docs',
        namespace: 'mcp_OpenAI_Docs',
        callId: 'local',
        arguments: '{}',
      };
      const model = new ScriptedModel([
        [
          {
            type: 'tool_search_call',
            callId: 'search',
            execution: 'client',
            arguments: { paths: ['mcp_OpenAI_Docs'] },
          } as protocol.ToolSearchCallItem,
        ],
        [localCall],
        [assistantMessage('Local tool called.')],
        [call(), assistantMessage('Done.')],
      ]);
      const agent = new Agent({
        name: 'Docs',
        model,
        tools: [
          ...localTools,
          server(),
          {
            ...searchTool,
            providerData: { type: 'tool_search', execution: 'client' },
          },
        ],
      });
      const session = new MemorySession();
      await runner().run(agent, 'Use local docs.', { session });
      expect(execute).toHaveBeenCalledTimes(1);

      const runHosted = async () => {
        if (stream) {
          const result = await runner().run(agent, 'Use hosted docs.', {
            session,
            stream: true,
          });
          await result.completed;
        } else {
          await runner().run(agent, 'Use hosted docs.', { session });
        }
      };
      await expect(runHosted()).rejects.toThrow(
        /before it was loaded via tool_search/,
      );
      model.assertComplete();
    },
  );

  // C3 (reject): a deferred top-level tool whose own name coincides with a
  // hosted server label stays local across session reuse; after the local tool
  // is removed, the deferred hosted call still rejects because the hosted
  // server was never genuinely discovered.
  it('keeps deferred self-namespace discovery local across session reuse', async () => {
    const execute = vi.fn(async () => 'local');
    const local = tool({
      name: 'mcp_inventory',
      description: 'Local inventory',
      parameters: z.object({}),
      deferLoading: true,
      execute,
    });
    const model = new ScriptedModel([
      [
        {
          type: 'tool_search_output',
          execution: 'server',
          tools: [
            {
              type: 'tool_reference',
              functionName: 'mcp_inventory',
              namespace: 'mcp_inventory',
            },
          ],
        },
        {
          type: 'function_call',
          name: 'mcp_inventory',
          namespace: 'mcp_inventory',
          callId: 'local',
          arguments: '{}',
        },
      ],
      [assistantMessage('Local completed.')],
      [
        {
          type: 'hosted_tool_call',
          name: 'mcp_call',
          providerData: {
            type: 'mcp_call',
            server_label: 'inventory',
            name: 'mcp_inventory',
            arguments: '{}',
          },
        },
      ],
    ]);
    const agent = new Agent({
      name: 'Inventory',
      model,
      tools: [
        local,
        searchTool,
        hostedMcpTool({
          serverLabel: 'inventory',
          serverUrl: 'https://example.invalid/mcp',
          deferLoading: true,
          requireApproval: 'never',
        }),
      ],
    });
    const session = new MemorySession();
    await runner().run(agent, 'Use local inventory.', { session });
    expect(execute).toHaveBeenCalledOnce();
    agent.tools = agent.tools.filter((t) => t !== local);
    await expect(
      runner().run(agent, 'Use hosted inventory.', { session }),
    ).rejects.toThrow(/before it was loaded via tool_search/);
    model.assertComplete();
  });

  // C4 (resume): a deferred hosted call on resume is admitted only when the
  // serialized history carried a genuine hosted discovery ('recorded'); when
  // the recorded history was a colliding user-namespace discovery
  // ('collision'), resume must not admit it on the strength of that old
  // history — a fresh genuine discovery is required.
  it.each(['recorded', 'collision'] as const)(
    'preserves %s discovery provenance through RunState resume',
    async (mode) => {
      const confirm = tool({
        name: 'confirm',
        description: 'Confirm continuation',
        parameters: z.object({}),
        needsApproval: true,
        execute: async () => 'confirmed',
      });
      const localTools =
        mode === 'collision' ? collidingLocalTools(async () => 'local') : [];
      const agent = new Agent({
        name: 'Docs',
        tools: [server(), searchTool, confirm, ...localTools],
        model: new ScriptedModel([
          [
            ...discovery().slice(1),
            {
              type: 'function_call',
              name: 'confirm',
              callId: 'confirm',
              arguments: '{}',
            },
          ],
        ]),
      });
      const paused = await runner().run(agent, 'Discover tools and confirm.');
      const serialized = await paused.state.toString();

      const replacement = new Agent({
        name: 'Docs',
        tools: [server(), searchTool, confirm],
        model: new ScriptedModel([[call(), assistantMessage('Done.')]]),
      });
      const restored = await RunState.fromString(replacement, serialized);
      restored.approve(restored.getInterruptions()[0]);
      const result = runner().run(replacement, restored);
      if (mode === 'recorded') {
        expect((await result).finalOutput).toBe('Done.');
      } else {
        await expect(result).rejects.toThrow(
          /before it was loaded via tool_search/,
        );
      }
    },
  );

  // C2 (accept, over-correction guard): a GENUINE hosted discovery (client-side
  // tool_search over the real server label) must admit the deferred hosted call
  // even when a colliding user namespace is ALSO configured. Rejects the
  // bluntest over-fix ("any mcp_<label> collision present => reject everything").
  it('accepts explicit MCP discovery despite a colliding user namespace', async () => {
    const mcp = server();
    const model = new ScriptedModel([
      [
        {
          type: 'tool_search_call',
          callId: 'search',
          execution: 'client',
          arguments: { paths: ['OpenAI_Docs'] },
        } as protocol.ToolSearchCallItem,
      ],
      [call(), assistantMessage('Done.')],
    ]);
    const agent = new Agent({
      name: 'Docs',
      model,
      tools: [
        mcp,
        ...collidingLocalTools(async () => 'local'),
        {
          ...searchTool,
          providerData: { type: 'tool_search', execution: 'client' },
        },
      ],
    });
    expect((await runner().run(agent, 'Load hosted docs.')).finalOutput).toBe(
      'Done.',
    );
    model.assertComplete();
  });

  // C1 (reject, narrow-fix guard): a bare user function whose name coincides
  // with the hosted server label, surfaced by a hosted search, must not count as
  // discovering the hosted server. Rejects a fix that only special-cases the
  // namespace-shaped collision.
  it('does not confuse a bare user function with an MCP descriptor', async () => {
    const agent = new Agent({
      name: 'Docs',
      tools: [
        server(),
        tool({
          name: 'OpenAI_Docs',
          description: 'Local lookup',
          parameters: z.object({}),
          deferLoading: true,
          execute: async () => 'local',
        }),
        {
          ...searchTool,
          providerData: { type: 'tool_search', execution: 'server' },
        },
      ],
      model: new ScriptedModel([
        [
          {
            type: 'tool_search_output',
            id: 'search',
            status: 'completed',
            execution: 'server',
            tools: [{ type: 'function', name: 'OpenAI_Docs' }],
          },
          call(),
        ],
      ]),
    });
    await expect(runner().run(agent, 'Search.')).rejects.toThrow(
      /before it was loaded via tool_search/,
    );
  });

  // C5 (invariance, pass-to-pass): caller-restriction and approval/interruption
  // behavior for hosted MCP tools is unchanged by the fix.
  it('still enforces caller restrictions after namespace discovery', async () => {
    const mcp = server();
    mcp.providerData.allowed_callers = ['programmatic'];
    const model = new ScriptedModel([
      [...discovery().slice(1), call(), assistantMessage('Done.')],
    ]);
    const agent = new Agent({ name: 'Docs', model, tools: [mcp, searchTool] });
    await expect(runner().run(agent, 'Search docs.')).rejects.toThrow(
      /caller direct/,
    );
  });

  it('preserves approval interruptions after namespace discovery', async () => {
    const mcp = server();
    mcp.providerData.require_approval = 'always';
    const model = new ScriptedModel([
      [...discovery(), call('search_openai_docs', 'mcp_approval_request')],
    ]);
    const agent = new Agent({ name: 'Docs', model, tools: [mcp, searchTool] });
    const result = await runner().run(agent, 'Search docs.');
    expect(result.interruptions).toHaveLength(1);
    expect(result.interruptions[0].rawItem).toMatchObject({
      providerData: { server_label: 'OpenAI_Docs', name: 'search_openai_docs' },
    });
  });

  // C6 (pass-to-pass, backward-compat): loading run state that was serialized
  // by an older SDK (before the schema version was bumped from '1.21' to
  // '1.22') must not throw. Rejects a fix that bumps CURRENT_SCHEMA_VERSION
  // without adding the prior version to SUPPORTED_SCHEMA_VERSIONS.
  it('loads run state serialized before the schema was bumped', async () => {
    // Build a minimal RunState by pausing a run at an approval interruption.
    const gate = tool({
      name: 'approve_gate',
      description: 'Approval gate for test',
      parameters: z.object({}),
      needsApproval: true,
      execute: async () => 'approved',
    });
    const paused = await runner().run(
      new Agent({
        name: 'Docs',
        model: new ScriptedModel([
          [{ type: 'function_call', name: 'approve_gate', callId: 'g1', arguments: '{}' }],
        ]),
        tools: [gate],
      }),
      'Pause.',
    );
    const serialized = await paused.state.toString();
    // Rewrite $schemaVersion to '1.21' (the pre-bump SDK version) to simulate
    // run state saved by an older client. The oracle adds '1.21' to
    // SUPPORTED_SCHEMA_VERSIONS, so this must load without throwing.
    const oldState = serialized.replace(/"\$schemaVersion":"[^"]*"/, '"$$schemaVersion":"1.21"');
    const resumeAgent = new Agent({
      name: 'Docs',
      model: new ScriptedModel([]),
      tools: [gate],
    });
    await expect(RunState.fromString(resumeAgent, oldState)).resolves.toBeDefined();
  });
});
