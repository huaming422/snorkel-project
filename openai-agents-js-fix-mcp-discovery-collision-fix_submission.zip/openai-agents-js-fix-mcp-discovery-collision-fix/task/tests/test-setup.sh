#!/usr/bin/env bash
# Environment bootstrap for the verifier.
#
# The behavioral verifier is a native vitest test in the @openai/agents-core
# project. agents-core's own tests import the package through its `../src`
# entry (see packages/agents-core/test/*.test.ts), so a src/ edit is picked up
# by vitest's on-the-fly transform without a dist/ rebuild. We still regenerate
# the built dist/ outputs defensively: a few integration-style tests resolve the
# published package via Node's module resolution (compiled dist/), and rebuilding
# keeps those consistent with any src/ change. tsc-multi replays unchanged-source
# builds quickly.
#
# Sourced (not exec'd) by the harbor runner so env vars set here stay live for
# the verifier subprocess.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/openai-agents-js}"
export REPO_DIR
cd "$REPO_DIR"

# harbor's js runner reads verify.toml via tomllib (Python 3.11+) or tomli
# (<=3.10). The base image ships Python 3.10 (ubuntu 22.04) with neither, so
# install tomli defensively (exact pin). Without it, verify.toml is silently
# dropped and the runner falls back to its default invocation, which does not
# match this repo's vitest setup. This step has network at verifier time; it is a
# no-op if tomllib (or tomli) is already present. The redirects live on the
# wrapper call, not the `pip install` line, so install output stays quiet.
TOMLI_PIN="tomli==2.0.1"
_pip_quiet() { python3 -m pip install --quiet "$@"; }
if ! python3 -c "import tomllib" >/dev/null 2>&1 && \
   ! python3 -c "import tomli"   >/dev/null 2>&1; then
    _pip_quiet "$TOMLI_PIN" >/dev/null 2>&1 \
        || _pip_quiet --break-system-packages "$TOMLI_PIN" >/dev/null 2>&1 \
        || true
fi

# Sanity check: vitest must be resolvable from the workspace root. A failure here
# points at a corrupted node_modules — bailing now saves time vs. a confusing
# "command not found" later. The image installed the full closure offline, so
# this should already be present.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/. " \
         "Re-running pnpm install (offline)." >&2
    pnpm install --frozen-lockfile --offline --ignore-scripts
fi

# Rebuild dist/ so it reflects any src/ change in agents-core (and its workspace
# dependents). Run tsc-multi directly — NOT `pnpm build` — to avoid the lifecycle
# `prebuild` step that regenerates tracked src/metadata.ts and would dirty the
# tree. tsc-multi uses the already-committed metadata.ts. All dist/ output is
# gitignored, so `git status` stays clean.
echo "test-setup.sh: rebuilding workspace dist/ (tsc-multi)..."
pnpm exec tsc-multi --maxWorkers 1

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
