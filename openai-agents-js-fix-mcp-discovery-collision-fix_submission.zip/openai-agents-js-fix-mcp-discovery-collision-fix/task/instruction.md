## Task

we've had a report about hosted MCP tool servers set up for lazy discovery, whose tool list is pulled in on demand through tool search rather than loaded up front. a deferred call to one of those tools should be rejected if it arrives before the server was discovered, but in one setup the guard fails to fire: the call is wrongly admitted and runs as if the server had been loaded, though nothing ever discovered it.

the triggering setup has more to it: the agent is also configured with an ordinary caller-side tool organized under a namespace whose name coincides with the hosted server's namespace. in that combination the guard fails to fire. the problem persists across turns of a persisted session and across saving and resuming run state, even when the configured tool list changes between turns.

the expected behavior is that a deferred hosted call stays rejected until the server's tools have been genuinely discovered via tool search—the ordinary caller-side tool configuration should not affect that.

leave untouched: the caller-permission checks and the approval and interruption behavior for hosted MCP tools, ordinary caller-side tool execution, explicitly configured non-deferred MCP descriptors, and loading of run state written by older SDK versions.

it's a behavioral issue in `@openai/agents-core`, reproducible and verifiable offline with the SDK's scripted-model test double. dig in and fix it.
