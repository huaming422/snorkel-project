## Task

People on Element X keep seeing messages arrive in the wrong order, always around a send that failed. The failed message gets its red marker, but what they queued next is sent anyway, so the people reading can see a reply ahead of what it replies to. In a room, nothing should go ahead of a send that failed. It doesn't matter what failed or what's behind it (a message, an image, a redaction), and it still holds after an app restart. That send stays failed until the user retries or removes it, and either of those lets the rest go out in order by itself.

It tends to happen during short outages. Logs from one of them show a send answered with a Cloudflare 520 error page. That message then sat marked as failed and never went out, while a timeout two minutes later was treated as something to retry. A blip like that shouldn't fail a send for good: like the timeout, it should keep its place in the queue and go out when the queue is enabled again, and that goes for image uploads too.

Two related problems. After a restart, an image whose upload failed (the file or its thumbnail) still looks like it's sending instead of showing as failed. And when a read from the local store fails, the client sits in a tight loop, pegging a core and flooding the log, until the store answers again.

Nothing here changes on the server or in the protocol.
