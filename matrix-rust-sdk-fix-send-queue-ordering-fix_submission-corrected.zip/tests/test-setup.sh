#!/usr/bin/env bash
# Sourced by tests/test.sh before the tests run, with set -euo pipefail inherited.
# The image holds the dependencies of the workspace with the `testing` feature and
# has no network here, so cargo resolves everything from CARGO_HOME.
cd /repo/matrix-rust-sdk

export CARGO_NET_OFFLINE=true

# A tree whose manifest or lockfile cargo can't resolve fails at the tests' own
# build step, so this one only logs.
if cargo fetch --locked --offline > /tmp/test-setup-fetch.log 2>&1; then
    echo "[offline-first] cargo deps satisfied from image cache"
else
    echo "[test-setup] cargo couldn't resolve the dependencies offline:"
    tail -40 /tmp/test-setup-fetch.log >&2
fi

# The send queue tests start their own in-process mock homeserver, so there is
# nothing to start or seed here.
