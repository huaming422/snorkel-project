//! What a client of the SDK sees of a room's send queue when a request fails.
//!
//! Every case goes through the public queue API (`Room::send_queue`,
//! `SendHandle`, `SendRedactionHandle`, the `RoomSendQueueUpdate` stream, the
//! reloaded local echoes) against a local mock homeserver. The mock's request
//! log says what left the client and in which order. Updates of a kind a case
//! doesn't ask about are passed over.

#![cfg(not(target_family = "wasm"))]
// An integration-test binary is its own crate and needs the crate's own limit, or
// the layout of the deep async futures overflows.
#![recursion_limit = "256"]

use std::{sync::Arc, time::Duration};

use assert_matches2::assert_let;
use matrix_sdk::{
    Client, Error, MemoryStore, Room,
    attachment::{AttachmentConfig, AttachmentInfo, BaseImageInfo, Thumbnail},
    config::StoreConfig,
    send_queue::{
        LocalEcho, LocalEchoContent, RoomSendQueue, RoomSendQueueUpdate, SendHandle,
        SendRedactionHandle,
    },
    test_utils::mocks::MatrixMockServer,
};
use matrix_sdk_common::cross_process_lock::CrossProcessLockConfig;
use matrix_sdk_test::async_test;
use ruma::{
    OwnedTransactionId, RoomId, TransactionId, event_id,
    events::room::message::RoomMessageEventContent, mxc_uri, owned_event_id, room_id, uint,
};
use serde_json::{Value, json};
use tokio::{
    sync::broadcast::Receiver,
    time::{Instant, sleep, timeout},
};
use wiremock::ResponseTemplate;

/// How long a blocked queue gets to show that nothing else leaves the client.
const QUIET: Duration = Duration::from_millis(1000);
/// How long an expected update may take, retries with their pauses included.
const WAIT: Duration = Duration::from_secs(30);

/// A kind of request to queue.
#[derive(Clone, Copy, Debug)]
enum Kind {
    /// A text message with this body.
    Text(&'static str),
    /// An image with no thumbnail, whose upload the server answers first.
    Image,
    /// An image with no thumbnail, whose upload works and whose event the
    /// server answers next.
    ImageEvent,
    /// A redaction of another event.
    Redaction,
}

fn room_a() -> &'static RoomId {
    room_id!("!a:b.c")
}

fn room_b() -> &'static RoomId {
    room_id!("!b:b.c")
}

enum Handle {
    Event(SendHandle),
    Redaction(SendRedactionHandle),
}

struct Queued {
    txn: OwnedTransactionId,
    handle: Handle,
}

impl Queued {
    async fn abort(&self) {
        let removed = match &self.handle {
            Handle::Event(handle) => handle.abort().await.unwrap(),
            Handle::Redaction(handle) => handle.abort().await.unwrap(),
        };
        assert!(removed, "removing a request that hasn't gone out reports success");
    }

    async fn retry(&self) {
        let Handle::Event(handle) = &self.handle else { panic!("only events can be retried") };
        handle.unwedge().await.unwrap();
    }
}

struct Lab {
    mock: MatrixMockServer,
    client: Client,
    room: Room,
    q: RoomSendQueue,
    watch: Receiver<RoomSendQueueUpdate>,
    seen: Vec<RoomSendQueueUpdate>,
}

async fn open_room(mock: MatrixMockServer, client: Client) -> Lab {
    let room = mock.sync_joined_room(&client, room_a()).await;
    client.send_queue().set_enabled(true).await;
    let q = room.send_queue();
    let (_, watch) = q.subscribe().await.unwrap();
    mock.mock_room_state_encryption().plain().mount().await;
    mock.mock_authenticated_media_config().ok_default().mount().await;
    Lab { mock, client, room, q, watch, seen: Vec::new() }
}

async fn lab() -> Lab {
    let mock = MatrixMockServer::new().await;
    let client = mock.client_builder().build().await;
    open_room(mock, client).await
}

async fn client_on(mock: &MatrixMockServer, store: Arc<MemoryStore>) -> Client {
    mock.client_builder()
        .on_builder(move |builder| {
            builder.store_config(
                StoreConfig::new(CrossProcessLockConfig::SingleProcess).state_store(store),
            )
        })
        .build()
        .await
}

/// A lab whose state store outlives its client, for the cases that restart.
async fn lab_on(store: Arc<MemoryStore>) -> Lab {
    let mock = MatrixMockServer::new().await;
    let client = client_on(&mock, store).await;
    open_room(mock, client).await
}

impl Lab {
    /// Drops the client and starts a new one on the same state store, the way
    /// an application comes back after a restart.
    async fn restart(self, store: Arc<MemoryStore>) -> Lab {
        let Lab { mock, client, room, q, watch, .. } = self;
        drop(watch);
        drop(q);
        drop(room);
        drop(client);
        sleep(Duration::from_secs(1)).await;

        let client = client_on(&mock, store).await;
        let lab = open_room(mock, client).await;
        lab.client.send_queue().respawn_tasks_for_rooms_with_unsent_requests().await;
        lab
    }

    /// Waits for an update `pick` recognises. Updates it doesn't are kept, for
    /// a later wait.
    async fn wait_for<T>(
        &mut self,
        what: &str,
        pick: impl Fn(&RoomSendQueueUpdate) -> Option<T>,
    ) -> T {
        if let Some(position) = self.seen.iter().position(|update| pick(update).is_some()) {
            let update = self.seen.remove(position);
            return pick(&update).unwrap();
        }

        let deadline = Instant::now() + WAIT;
        loop {
            let left = deadline.saturating_duration_since(Instant::now());
            let update = match timeout(left, self.watch.recv()).await {
                Ok(update) => update.expect("the update stream stays open"),
                Err(_) => panic!("no {what} within {WAIT:?}; other updates: {:?}", self.seen),
            };
            if let Some(found) = pick(&update) {
                return found;
            }
            self.seen.push(update);
        }
    }

    async fn next_echo(&mut self) -> LocalEcho {
        self.wait_for("local echo", |update| match update {
            RoomSendQueueUpdate::NewLocalEvent(echo) => Some(echo.clone()),
            _ => None,
        })
        .await
    }

    /// Waits for the failure of `txn`. A request that goes out in the meantime
    /// is a failure of the case.
    async fn wait_error(&mut self, txn: &TransactionId) -> (Arc<Error>, bool) {
        let outcome = self
            .wait_for("send error", |update| match update {
                RoomSendQueueUpdate::SendError { transaction_id, error, is_recoverable }
                    if transaction_id == txn =>
                {
                    Some(Ok((error.clone(), *is_recoverable)))
                }
                RoomSendQueueUpdate::SentEvent { transaction_id, .. } => {
                    Some(Err(format!("{transaction_id} went out")))
                }
                _ => None,
            })
            .await;
        outcome.unwrap_or_else(|why| panic!("waiting for the failure of {txn}: {why}"))
    }

    /// Waits for `txn` to go out. Another request going out first, or any
    /// failure, is a failure of the case.
    async fn wait_sent(&mut self, txn: &TransactionId) {
        let outcome = self
            .wait_for("sent event", |update| match update {
                RoomSendQueueUpdate::SentEvent { transaction_id, .. } if transaction_id == txn => {
                    Some(Ok(()))
                }
                RoomSendQueueUpdate::SentEvent { transaction_id, .. } => {
                    Some(Err(format!("{transaction_id} went out first")))
                }
                RoomSendQueueUpdate::SendError { transaction_id, error, .. } => {
                    Some(Err(format!("{transaction_id} failed: {error}")))
                }
                _ => None,
            })
            .await;
        outcome.unwrap_or_else(|why| panic!("waiting for {txn} to go out: {why}"));
    }

    async fn wait_cancelled(&mut self, txn: &TransactionId) {
        self.wait_for("cancelled echo", |update| match update {
            RoomSendQueueUpdate::CancelledLocalEvent { transaction_id }
                if transaction_id == txn =>
            {
                Some(())
            }
            _ => None,
        })
        .await;
    }

    /// Checks that for a while no request reaches the server and none is
    /// reported as sent or failed. A request nobody mocked answers 404 and
    /// reports a failure.
    async fn assert_nothing_goes_out(&mut self) {
        let before = outgoing(&self.mock).await;
        let deadline = Instant::now() + QUIET;
        loop {
            let left = deadline.saturating_duration_since(Instant::now());
            if left.is_zero() {
                break;
            }
            match timeout(left, self.watch.recv()).await {
                Err(_) => break,
                Ok(Ok(
                    update @ (RoomSendQueueUpdate::SentEvent { .. }
                    | RoomSendQueueUpdate::SendError { .. }),
                )) => {
                    panic!("nothing can go out ahead of the stuck request, but got {update:?}")
                }
                Ok(Ok(update)) => self.seen.push(update),
                Ok(Err(error)) => panic!("the update stream broke: {error}"),
            }
        }
        let after = outgoing(&self.mock).await;
        assert_eq!(after, before, "no request can reach the server ahead of the stuck one");
    }

    async fn queue(&mut self, kind: Kind) -> Queued {
        let handle = match kind {
            Kind::Text(body) => Handle::Event(
                self.q.send(RoomMessageEventContent::text_plain(body).into()).await.unwrap(),
            ),
            Kind::Image | Kind::ImageEvent => Handle::Event(queue_image(&self.q).await),
            Kind::Redaction => {
                Handle::Redaction(self.q.redact(owned_event_id!("$target"), None).await.unwrap())
            }
        };
        let txn = self.next_echo().await.transaction_id;
        Queued { txn, handle }
    }

    /// Has the server refuse `kind` once, for good: 413 with `M_TOO_LARGE`.
    async fn mount_refusal(&self, kind: Kind) {
        match kind {
            Kind::Text(body) => {
                self.mock
                    .mock_room_send()
                    .body_matches_partial_json(json!({ "body": body }))
                    .error_too_large()
                    .mock_once()
                    .mount()
                    .await;
            }
            Kind::Image => {
                self.mock.mock_upload().error_too_large().mock_once().mount().await;
            }
            Kind::ImageEvent => {
                self.mock
                    .mock_upload()
                    .ok(mxc_uri!("mxc://sdk.rs/media"))
                    .mock_once()
                    .mount()
                    .await;
                self.mock
                    .mock_room_send()
                    .body_matches_partial_json(json!({ "msgtype": "m.image" }))
                    .error_too_large()
                    .mock_once()
                    .mount()
                    .await;
            }
            Kind::Redaction => {
                self.mock.mock_room_redact().error_too_large().mock_once().mount().await;
            }
        }
    }

    /// Has the server take `kind` once.
    async fn mount_ok(&self, kind: Kind) {
        match kind {
            Kind::Text(body) => {
                self.mock
                    .mock_room_send()
                    .body_matches_partial_json(json!({ "body": body }))
                    .ok(event_id!("$text"))
                    .mock_once()
                    .mount()
                    .await;
            }
            Kind::Image => {
                self.mock
                    .mock_upload()
                    .ok(mxc_uri!("mxc://sdk.rs/media"))
                    .mock_once()
                    .mount()
                    .await;
                self.mock
                    .mock_room_send()
                    .body_matches_partial_json(json!({ "msgtype": "m.image" }))
                    .ok(event_id!("$image"))
                    .mock_once()
                    .mount()
                    .await;
            }
            Kind::ImageEvent => {
                self.mock
                    .mock_room_send()
                    .body_matches_partial_json(json!({ "msgtype": "m.image" }))
                    .ok(event_id!("$image"))
                    .mock_once()
                    .mount()
                    .await;
            }
            Kind::Redaction => {
                self.mock.mock_room_redact().ok(event_id!("$redaction")).mock_once().mount().await;
            }
        }
    }

    /// Queues `head` and `follower`, has the server refuse `head`, re-enables
    /// the queue and checks that nothing else leaves the client.
    async fn stuck_on(head: Kind, follower: Kind) -> (Lab, Queued, Queued) {
        let mut lab = lab().await;
        lab.mount_refusal(head).await;

        let stuck = lab.queue(head).await;
        let behind = lab.queue(follower).await;

        let (error, is_recoverable) = lab.wait_error(&stuck.txn).await;
        assert!(!is_recoverable, "a 413 is final: {error}");

        lab.q.set_enabled(true);
        lab.assert_nothing_goes_out().await;

        (lab, stuck, behind)
    }

    /// The failure a reloaded local echo reports for `txn`.
    async fn reloaded_send_error(&self, txn: &TransactionId) -> Option<String> {
        let (echoes, _) = self.q.subscribe().await.unwrap();
        echo_send_error(&echoes, txn)
    }
}

fn echo_send_error(echoes: &[LocalEcho], txn: &TransactionId) -> Option<String> {
    let echo = echoes
        .iter()
        .find(|echo| echo.transaction_id == txn)
        .unwrap_or_else(|| panic!("{txn} has a local echo in {echoes:?}"));
    match &echo.content {
        LocalEchoContent::Event { send_error, .. } => {
            send_error.as_ref().map(|error| error.to_string())
        }
        LocalEchoContent::Redaction { send_error, .. } => {
            send_error.as_ref().map(|error| error.to_string())
        }
        LocalEchoContent::React { .. } => None,
    }
}

async fn queue_image(q: &RoomSendQueue) -> SendHandle {
    let config = AttachmentConfig::new().info(AttachmentInfo::Image(BaseImageInfo {
        height: Some(uint!(13)),
        width: Some(uint!(37)),
        size: Some(uint!(42)),
        ..Default::default()
    }));
    q.send_attachment("image.jpeg", mime::IMAGE_JPEG, b"hello world".to_vec(), config)
        .await
        .expect("queuing the attachment works")
}

async fn queue_image_with_thumbnail(q: &RoomSendQueue) -> SendHandle {
    let thumbnail = Thumbnail {
        data: b"thumbnail".to_vec(),
        content_type: mime::IMAGE_JPEG,
        height: uint!(13),
        width: uint!(37),
        size: uint!(42),
    };
    let config = AttachmentConfig::new().thumbnail(Some(thumbnail)).info(AttachmentInfo::Image(
        BaseImageInfo {
            height: Some(uint!(13)),
            width: Some(uint!(37)),
            size: Some(uint!(42)),
            ..Default::default()
        },
    ));
    q.send_attachment("image.jpeg", mime::IMAGE_JPEG, b"hello world".to_vec(), config)
        .await
        .expect("queuing the attachment works")
}

/// What reached the server so far, in order: `send <body>`, `redact` or
/// `upload`.
async fn outgoing(mock: &MatrixMockServer) -> Vec<String> {
    let requests = mock.server().received_requests().await.expect("the mock records requests");
    requests
        .iter()
        .filter_map(|request| {
            let path = request.url.path();
            if path.contains("/send/") {
                let body: Value = serde_json::from_slice(&request.body).unwrap_or_default();
                Some(format!("send {}", body["body"].as_str().unwrap_or("?")))
            } else if path.contains("/redact/") {
                Some("redact".to_owned())
            } else if path.ends_with("/media/v3/upload") || path.ends_with("/media/r0/upload") {
                Some("upload".to_owned())
            } else {
                None
            }
        })
        .collect()
}

/// A queue with nothing stuck sends in the order it was given.
#[async_test]
async fn test_preserved_non_wedged_queue_sends_in_order() {
    let mut lab = lab().await;
    lab.mount_ok(Kind::Text("first")).await;
    lab.mount_ok(Kind::Text("second")).await;

    let first = lab.queue(Kind::Text("first")).await;
    let second = lab.queue(Kind::Text("second")).await;

    lab.wait_sent(&first.txn).await;
    lab.wait_sent(&second.txn).await;
    assert_eq!(outgoing(&lab.mock).await, ["send first", "send second"]);
}

/// A refused text message holds back a text, an image and a redaction behind
/// it.
#[async_test]
async fn test_hol_blocking_wedged_head_blocks_followers() {
    let head = Kind::Text("too big");
    for follower in [Kind::Text("aloha"), Kind::Image, Kind::Redaction] {
        Lab::stuck_on(head, follower).await;
    }
}

/// A refused image upload holds back a text, an image and a redaction behind
/// it.
#[async_test]
async fn test_hol_blocking_wedged_upload_blocks_followers() {
    for follower in [Kind::Text("aloha"), Kind::Image, Kind::Redaction] {
        Lab::stuck_on(Kind::Image, follower).await;
    }
}

/// A refused redaction holds back a text, an image and a redaction behind it.
#[async_test]
async fn test_hol_blocking_wedged_redaction_blocks_followers() {
    for follower in [Kind::Text("aloha"), Kind::Image, Kind::Redaction] {
        Lab::stuck_on(Kind::Redaction, follower).await;
    }
}

/// An image whose upload worked and whose event the server refused holds back a
/// text, an image and a redaction queued after it.
#[async_test]
async fn test_hol_blocking_holds_across_priority_classes() {
    for follower in [Kind::Text("behind the media"), Kind::Image, Kind::Redaction] {
        Lab::stuck_on(Kind::ImageEvent, follower).await;
    }
}

/// Removing what's stuck lets the next request go, whatever kind each of them
/// is, with no other call on the queue.
#[async_test]
async fn test_queue_resumes_after_wedged_head_is_aborted() {
    let text = Kind::Text("aloha");
    for (head, follower) in [
        (Kind::Text("too big"), text),
        (Kind::Text("too big"), Kind::Image),
        (Kind::Text("too big"), Kind::Redaction),
        (Kind::Image, text),
        (Kind::ImageEvent, text),
        (Kind::Redaction, text),
    ] {
        let (mut lab, stuck, behind) = Lab::stuck_on(head, follower).await;
        lab.mount_ok(follower).await;
        stuck.abort().await;
        lab.wait_cancelled(&stuck.txn).await;
        lab.wait_sent(&behind.txn).await;
    }
}

/// Removing an image stuck on its thumbnail lets the next request go too.
#[async_test]
async fn test_queue_resumes_after_wedged_thumbnail_is_aborted() {
    let mut lab = lab().await;
    lab.mock.mock_upload().error_too_large().mock_once().mount().await;

    let handle = queue_image_with_thumbnail(&lab.q).await;
    let image = lab.next_echo().await.transaction_id;
    let behind = lab.queue(Kind::Text("aloha")).await;

    let (_, is_recoverable) = lab.wait_error(&image).await;
    assert!(!is_recoverable);
    lab.q.set_enabled(true);
    lab.assert_nothing_goes_out().await;

    lab.mount_ok(Kind::Text("aloha")).await;
    assert!(handle.abort().await.unwrap());
    lab.wait_cancelled(&image).await;
    lab.wait_sent(&behind.txn).await;
}

/// Retrying what's stuck sends it first and the rest after it.
#[async_test]
async fn test_queue_resumes_in_order_after_wedged_head_is_retried() {
    let behind = Kind::Text("aloha");
    for head in [Kind::Text("too big"), Kind::Image, Kind::ImageEvent] {
        let (mut lab, stuck, follower) = Lab::stuck_on(head, behind).await;
        lab.mount_ok(head).await;
        lab.mount_ok(behind).await;

        stuck.retry().await;
        lab.wait_sent(&stuck.txn).await;
        lab.wait_sent(&follower.txn).await;

        let sent = outgoing(&lab.mock).await;
        assert_eq!(sent.last().map(String::as_str), Some("send aloha"), "{head:?}: {sent:?}");
        assert_eq!(sent.iter().filter(|r| *r == "send aloha").count(), 1, "{head:?}: {sent:?}");
    }
}

/// Editing a stuck message retries it, and the rest stays behind it.
#[async_test]
async fn test_queue_resumes_in_order_after_wedged_head_is_edited() {
    let (mut lab, stuck, follower) =
        Lab::stuck_on(Kind::Text("too big"), Kind::Text("aloha")).await;
    lab.mount_ok(Kind::Text("smaller")).await;
    lab.mount_ok(Kind::Text("aloha")).await;

    let Handle::Event(handle) = &stuck.handle else { panic!("a text message is an event") };
    assert!(handle.edit(RoomMessageEventContent::text_plain("smaller").into()).await.unwrap());

    lab.wait_sent(&stuck.txn).await;
    lab.wait_sent(&follower.txn).await;
    assert_eq!(outgoing(&lab.mock).await, ["send too big", "send smaller", "send aloha"]);
}

/// Removing a request behind the stuck one frees nothing.
#[async_test]
async fn test_removing_a_follower_leaves_the_queue_blocked() {
    let (mut lab, stuck, second) = Lab::stuck_on(Kind::Text("too big"), Kind::Text("two")).await;
    let third = lab.queue(Kind::Text("three")).await;
    lab.assert_nothing_goes_out().await;

    second.abort().await;
    lab.wait_cancelled(&second.txn).await;
    lab.assert_nothing_goes_out().await;

    lab.mount_ok(Kind::Text("three")).await;
    stuck.abort().await;
    lab.wait_cancelled(&stuck.txn).await;
    lab.wait_sent(&third.txn).await;
    assert_eq!(outgoing(&lab.mock).await, ["send too big", "send three"]);
}

/// A request stuck in one room leaves another room's queue alone.
#[async_test]
async fn test_other_rooms_keep_sending_while_one_is_blocked() {
    let (lab, _stuck, _behind) = Lab::stuck_on(Kind::Text("too big"), Kind::Text("aloha")).await;

    let other = lab.mock.sync_joined_room(&lab.client, room_b()).await;
    let (_, mut other_watch) = other.send_queue().subscribe().await.unwrap();
    lab.mock
        .mock_room_send()
        .body_matches_partial_json(json!({ "body": "elsewhere" }))
        .ok(event_id!("$other"))
        .mock_once()
        .mount()
        .await;

    other.send_queue().send(RoomMessageEventContent::text_plain("elsewhere").into()).await.unwrap();

    let deadline = Instant::now() + WAIT;
    loop {
        let left = deadline.saturating_duration_since(Instant::now());
        match timeout(left, other_watch.recv()).await.expect("the other room's message goes out") {
            Ok(RoomSendQueueUpdate::SentEvent { .. }) => break,
            Ok(RoomSendQueueUpdate::SendError { error, .. }) => panic!("it failed: {error}"),
            Ok(_) => continue,
            Err(error) => panic!("the update stream broke: {error}"),
        }
    }
}

/// A request that's stuck when the application stops still holds back what's
/// behind it when the application comes back, and removing it through the
/// reloaded echo lets the rest go.
#[async_test]
async fn test_hol_blocking_survives_a_restart() {
    let store = Arc::new(MemoryStore::new());
    let mut lab = lab_on(store.clone()).await;
    lab.mount_refusal(Kind::Text("too big")).await;

    let stuck = lab.queue(Kind::Text("too big")).await;
    let behind = lab.queue(Kind::Text("aloha")).await;
    let (_, is_recoverable) = lab.wait_error(&stuck.txn).await;
    assert!(!is_recoverable);

    let before = outgoing(&lab.mock).await;
    let mut lab = lab.restart(store).await;
    lab.assert_nothing_goes_out().await;
    assert_eq!(outgoing(&lab.mock).await, before, "nothing went out while coming back");

    let (echoes, _) = lab.q.subscribe().await.unwrap();
    assert!(echo_send_error(&echoes, &stuck.txn).is_some(), "the refused message reads as failed");
    assert_eq!(echo_send_error(&echoes, &behind.txn), None, "the one behind it hasn't failed");

    lab.mount_ok(Kind::Text("aloha")).await;
    let echo = echoes.iter().find(|echo| echo.transaction_id == stuck.txn).unwrap();
    assert_let!(LocalEchoContent::Event { send_handle, .. } = &echo.content);
    assert!(send_handle.abort().await.unwrap());
    lab.wait_cancelled(&stuck.txn).await;
    lab.wait_sent(&behind.txn).await;
}

/// A 520 proxy error page reads as momentary: the message stays queued, not
/// failed, what's behind it stays behind it, and both go out in order when the
/// queue is enabled again.
#[async_test]
async fn test_http_520_is_recoverable_and_retried_in_order() {
    let mut lab = lab().await;
    lab.mock
        .mock_room_send()
        .respond_with(ResponseTemplate::new(520).set_body_string(
            "<html><body>520: Web server is returning an unknown error</body></html>",
        ))
        .mount()
        .await;

    let blip = lab.queue(Kind::Text("blip")).await;
    let behind = lab.queue(Kind::Text("after the blip")).await;

    let (error, is_recoverable) = lab.wait_error(&blip.txn).await;
    assert!(is_recoverable, "a 520 is momentary: {error}");
    assert_eq!(error.as_client_api_error().expect("a client API error").status_code, 520);
    assert!(!lab.q.is_enabled(), "a failed send pauses the room's queue");

    assert_eq!(lab.reloaded_send_error(&blip.txn).await, None, "a momentary failure isn't final");
    assert!(
        outgoing(&lab.mock).await.iter().all(|request| request == "send blip"),
        "nothing else goes out while the queue is paused"
    );

    lab.mock
        .mock_room_send()
        .body_matches_partial_json(json!({ "body": "blip" }))
        .ok(event_id!("$1"))
        .mock_once()
        .with_priority(1)
        .mount()
        .await;
    lab.mock
        .mock_room_send()
        .body_matches_partial_json(json!({ "body": "after the blip" }))
        .ok(event_id!("$2"))
        .mock_once()
        .with_priority(1)
        .mount()
        .await;

    lab.q.set_enabled(true);
    lab.wait_sent(&blip.txn).await;
    lab.wait_sent(&behind.txn).await;
    assert_eq!(outgoing(&lab.mock).await.last().map(String::as_str), Some("send after the blip"));
}

/// A 520 on an image upload reads as momentary too, and the image goes out once
/// the queue is enabled again.
#[async_test]
async fn test_http_520_on_an_upload_is_recoverable() {
    let mut lab = lab().await;
    lab.mock
        .mock_upload()
        .respond_with(ResponseTemplate::new(520).set_body_json(json!({})))
        .mount()
        .await;

    let image = lab.queue(Kind::Image).await;

    let (error, is_recoverable) = lab.wait_error(&image.txn).await;
    assert!(is_recoverable, "a 520 is momentary: {error}");
    assert_eq!(error.as_client_api_error().expect("a client API error").status_code, 520);
    assert_eq!(lab.reloaded_send_error(&image.txn).await, None, "a momentary failure isn't final");

    lab.mock
        .mock_upload()
        .ok(mxc_uri!("mxc://sdk.rs/media"))
        .mock_once()
        .with_priority(1)
        .mount()
        .await;
    lab.mount_ok(Kind::ImageEvent).await;
    lab.q.set_enabled(true);
    lab.wait_sent(&image.txn).await;
}

/// An image whose upload the server refused reads as failed when the echoes are
/// loaded again.
#[async_test]
async fn test_wedged_media_upload_error_surfaces_on_local_echo() {
    let mut lab = lab().await;
    lab.mount_refusal(Kind::Image).await;

    let image = lab.queue(Kind::Image).await;

    let (error, is_recoverable) = lab.wait_error(&image.txn).await;
    assert!(!is_recoverable);
    assert_eq!(error.as_client_api_error().expect("a client API error").status_code, 413);

    let (echoes, _) = lab.q.subscribe().await.unwrap();
    assert_eq!(echoes.len(), 1, "the image reads as one item: {echoes:?}");
    assert!(echo_send_error(&echoes, &image.txn).is_some(), "the refused image reads as failed");
}

/// Refusing either of an image's two uploads makes the image read as failed.
#[async_test]
async fn test_wedged_thumbnail_or_file_upload_surfaces_on_local_echo() {
    // The thumbnail goes first and is refused.
    let mut lab = lab().await;
    lab.mock.mock_upload().error_too_large().mock_once().mount().await;
    queue_image_with_thumbnail(&lab.q).await;
    let image = lab.next_echo().await.transaction_id;
    let (_, is_recoverable) = lab.wait_error(&image).await;
    assert!(!is_recoverable);
    assert!(lab.reloaded_send_error(&image).await.is_some(), "a refused thumbnail fails the image");

    // The thumbnail works and the file is refused.
    let mut lab = self::lab().await;
    lab.mock.mock_upload().ok(mxc_uri!("mxc://sdk.rs/thumbnail")).mock_once().mount().await;
    lab.mock.mock_upload().error_too_large().mock_once().mount().await;
    queue_image_with_thumbnail(&lab.q).await;
    let image = lab.next_echo().await.transaction_id;
    let (_, is_recoverable) = lab.wait_error(&image).await;
    assert!(!is_recoverable);
    assert!(lab.reloaded_send_error(&image).await.is_some(), "a refused file fails the image");
}

/// An image whose upload the server refused still reads as failed after a
/// restart, and removing it through the reloaded echo lets the rest go.
#[async_test]
async fn test_wedged_upload_reads_as_failed_after_a_restart() {
    let store = Arc::new(MemoryStore::new());
    let mut lab = lab_on(store.clone()).await;
    lab.mount_refusal(Kind::Image).await;

    let image = lab.queue(Kind::Image).await;
    let behind = lab.queue(Kind::Text("aloha")).await;
    let (_, is_recoverable) = lab.wait_error(&image.txn).await;
    assert!(!is_recoverable);

    let mut lab = lab.restart(store).await;
    lab.assert_nothing_goes_out().await;

    let (echoes, _) = lab.q.subscribe().await.unwrap();
    assert!(echo_send_error(&echoes, &image.txn).is_some(), "the refused image reads as failed");
    assert_eq!(echo_send_error(&echoes, &behind.txn), None, "the one behind it hasn't failed");

    lab.mount_ok(Kind::Text("aloha")).await;
    let echo = echoes.iter().find(|echo| echo.transaction_id == image.txn).unwrap();
    assert_let!(LocalEchoContent::Event { send_handle, .. } = &echo.content);
    assert!(send_handle.abort().await.unwrap());
    lab.wait_cancelled(&image.txn).await;
    lab.wait_sent(&behind.txn).await;
}

/// An image that hasn't failed doesn't read as failed: one still waiting its
/// turn, one whose upload hit a momentary error, and one that was refused and
/// then retried.
#[async_test]
async fn test_media_echo_reads_as_failed_only_after_a_refusal() {
    // Still waiting its turn.
    let mut lab = lab().await;
    lab.q.set_enabled(false);
    let waiting = lab.queue(Kind::Image).await;
    assert_eq!(lab.reloaded_send_error(&waiting.txn).await, None, "a waiting image hasn't failed");

    // A momentary error on the upload.
    let mut lab = self::lab().await;
    lab.mock.mock_upload().error500().mount().await;
    let momentary = lab.queue(Kind::Image).await;
    let (_, is_recoverable) = lab.wait_error(&momentary.txn).await;
    assert!(is_recoverable);
    assert_eq!(lab.reloaded_send_error(&momentary.txn).await, None, "a 500 isn't final");

    // Refused, then retried with the queue paused, so the retry hasn't happened
    // yet.
    let mut lab = self::lab().await;
    lab.mount_refusal(Kind::Image).await;
    let refused = lab.queue(Kind::Image).await;
    let (_, is_recoverable) = lab.wait_error(&refused.txn).await;
    assert!(!is_recoverable);
    assert!(lab.reloaded_send_error(&refused.txn).await.is_some());
    lab.q.set_enabled(false);
    refused.retry().await;
    assert_eq!(lab.reloaded_send_error(&refused.txn).await, None, "a retried image waits its turn");
}
