## Task

Azure Pipelines runs of lage get folded log groups and annotated failures from the Azure output. On GitHub Actions we get neither: every package task's log runs together in one long stream, and a failed build isn't annotated. Add a GitHub output written with GitHub's workflow commands (`::group::`, `::endgroup::`, `::error`). GitHub sets `GITHUB_ACTIONS=true` in every job, and Azure Pipelines sets `TF_BUILD=True`.

## User stories / requirements

- When no reporter is named, a GitHub Actions job gets the GitHub output and an Azure Pipelines job gets Azure's, both grouped without `--grouped`. If both variables are set, GitHub wins. Jobs that export `NODE_ENV=test` count too. Anywhere else the default output doesn't change.
- Each package task's lines sit in a `::group::` that's closed with `::endgroup::` once the task ends. The group's title names the package, the task, how it ended, and its duration. Inside a group, and inline when grouping is off, the lines are exactly what Azure's output writes for that task.
- Every run ends on a summary in its own group, closed explicitly. When the run failed, every failed task also gets an `::error` annotation whose title holds its package name and task name, followed by the lines that task logged. Tasks that passed get neither, and blank lines never get an annotation.
- People can also pick the GitHub output by name with `--reporter`, under one short name and one long name. Both names belong on the supported reporter list, so the error for an unknown reporter name lists them. A reporter picked by name beats the CI detection.
- Picking Azure's output by name gets it as before, in a GitHub Actions job too, and with the same grouping setting. Its groups, lines, summary, and annotations stay byte for byte what they are today. One exception is fine: the line for a queued task, which today wrongly says it was aborted.
