#!/usr/bin/env bash
# test-setup.sh: environment bootstrap for the verifier and the validation agent.
# Sourced (not exec'd) by tests/test.sh so env vars and anything else stay alive
# for the jest runs that follow.
#
# Idempotent. The image materializes node_modules at build time (image
# Dockerfile step 7, `yarn install --immutable`); this re-runs that install
# only if node_modules is gone. The image's install covers every dependency the
# stories need, so there is nothing extra to fetch here.
#
# Because test.sh sources this file, nothing here exits the shell: a failed
# install is logged and the jest runs after it report what went wrong.

set -uo pipefail

REPO_DIR="${REPO_DIR:-/repo/lage}"
cd "$REPO_DIR"

node --version

# Restore workspace deps if node_modules is gone (offline-first against the
# image bake, logged online fallback). `--immutable` is yarn 4's frozen-lockfile.
if [ ! -d "node_modules" ] || [ ! -d "node_modules/memory-streams" ]; then
    echo "[test-setup] node_modules missing, restoring deps offline..."
    if YARN_ENABLE_NETWORK=false yarn install --immutable > /tmp/yarn-install.log 2>&1; then
        echo "[offline-first] yarn install satisfied from image cache"
    else
        echo "[test-setup] offline install failed; retrying with network (fallback)"
        tail -40 /tmp/yarn-install.log || true
        yarn install --immutable || echo "[test-setup] WARNING: yarn install failed" >&2
    fi
fi

# Quick sanity check that the reporters test toolchain is present.
test -f node_modules/memory-streams/package.json \
    || echo "[test-setup] WARNING: memory-streams not installed" >&2

echo "[test-setup] ready: ${REPO_DIR}"
