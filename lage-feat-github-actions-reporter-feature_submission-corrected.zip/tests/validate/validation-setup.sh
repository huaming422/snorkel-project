#!/usr/bin/env bash
# validation-setup.sh: environment bootstrap for the validation-story jest runs.
#
# Idempotent guard. The task image already materializes node_modules at the base
# commit via `yarn install --immutable` (image Dockerfile), and every validation
# story is a native jest test driven through the repo's own
# @lage-run/monorepo-scripts jest config (@swc/jest transforms the TypeScript on
# the fly from src/ via moduleNameMapper, so no dist build is required). We only
# re-install if node_modules is gone, then smoke-check the toolchain the stories
# rely on.
#
# test.sh sources this file, so it never calls exit: a missing piece is logged
# and the jest runs that need it fail on their own with a readable error.

set -uo pipefail

REPO_DIR="${REPO_DIR:-/repo/lage}"
cd "$REPO_DIR" || { echo "[validation-setup] WARNING: $REPO_DIR not found" >&2; return 0; }

# Toolchain reachable.
node --version

# Restore workspace deps if node_modules is gone (offline-first against the
# image bake, logged online fallback). `--immutable` is yarn 4's frozen-lockfile.
if [ ! -d "node_modules" ] || [ ! -d "node_modules/memory-streams" ]; then
    echo "[validation-setup] node_modules missing, restoring deps offline..."
    if YARN_ENABLE_NETWORK=false yarn install --immutable > /tmp/yarn-install.log 2>&1; then
        echo "[offline-first] yarn install satisfied from image cache"
    else
        echo "[validation-setup] offline install failed; retrying with network (fallback)"
        tail -40 /tmp/yarn-install.log || true
        yarn install --immutable || echo "[validation-setup] WARNING: yarn install failed" >&2
    fi
fi

# The reporter stories drive the lifecycle with memory-streams-style entries and
# the CLI selection path; memory-streams is the devDependency the repo's own
# reporter tests use.
test -f node_modules/memory-streams/package.json \
    || echo "[validation-setup] WARNING: memory-streams not installed" >&2

# Jest must be present and runnable before the timed story runs. Invoke the
# resolved binary directly (not through `yarn run`, which the setup-script linter
# counts as a second dependency sync). The node-modules linker hoists jest's
# bin to node_modules/.bin/jest once the single `yarn install` above completes.
# This also warms any first-run resolution cost.
JEST_BIN="node_modules/.bin/jest"
if [ -x "$JEST_BIN" ] && "$JEST_BIN" --version > /tmp/jest-version.log 2>&1; then
    echo "[validation-setup] jest $(tail -1 /tmp/jest-version.log)"
else
    echo "[validation-setup] WARNING: jest not runnable at $JEST_BIN" >&2
    tail -20 /tmp/jest-version.log 2>/dev/null || true
fi

# Smoke-check that the CLI selection entry points the stories import resolve
# from source (the stories import ../commands/*.js, rewritten to src by the jest
# moduleNameMapper).
for entry in packages/cli/src/commands/createReporter.ts packages/cli/src/commands/initializeReporters.ts; do
    test -f "$entry" || echo "[validation-setup] WARNING: $entry missing" >&2
done

echo "[validation-setup] ready: ${REPO_DIR}"
