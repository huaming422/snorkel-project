// @ts-nocheck
// Shared scenario code for the validation stories. The jest driver copies this file
// next to each story file, into packages/cli/src/__validation__/. Reporters are only
// ever obtained through lage's own selection entry points (createReporter and
// initializeReporters), never by class name.
import { Logger, LogLevel } from "@lage-run/logger";
import { createReporter } from "../commands/createReporter.js";
import { initializeReporters } from "../commands/initializeReporters.js";

const CI_VARS = ["GITHUB_ACTIONS", "TF_BUILD", "NODE_ENV"];

export function baseOptions(grouped: boolean, logLevel = "verbose", reporter: string[] = []) {
  return { concurrency: 1, grouped, logLevel, progress: false, reporter, verbose: false };
}

/**
 * Runs fn with GITHUB_ACTIONS and TF_BUILD set only as given and NODE_ENV=test (what a
 * test job exports, and what jest sets anyway), then puts the old values back.
 */
export async function withCiEnv(env: { github?: boolean; azure?: boolean }, fn: () => Promise<any>) {
  const saved = Object.fromEntries(CI_VARS.map((name) => [name, process.env[name]]));
  for (const name of CI_VARS) delete process.env[name];
  process.env.NODE_ENV = "test";
  if (env.github) process.env.GITHUB_ACTIONS = "true";
  if (env.azure) process.env.TF_BUILD = "True";
  try {
    return await fn();
  } finally {
    for (const name of CI_VARS) {
      if (saved[name] === undefined) delete process.env[name];
      else process.env[name] = saved[name];
    }
  }
}

/** Collects everything written to process.stdout while fn runs, async writes included. */
export async function captureStdout(fn: () => Promise<any> | any): Promise<string> {
  const chunks: string[] = [];
  const original = process.stdout.write;
  process.stdout.write = (chunk: any, ...rest: any[]) => {
    chunks.push(typeof chunk === "string" ? chunk : Buffer.from(chunk).toString("utf8"));
    const callback = rest.find((arg) => typeof arg === "function");
    if (callback) callback();
    return true;
  };
  try {
    await fn();
    await new Promise((resolve) => setImmediate(resolve));
    return chunks.join("");
  } finally {
    process.stdout.write = original;
  }
}

export function createTarget(packageName: string, task: string) {
  return {
    id: `${packageName}#${task}`,
    cwd: `/repo/root/packages/${packageName}`,
    dependencies: [],
    dependents: [],
    depSpecs: [],
    packageName,
    task,
    label: `${packageName} - ${task}`,
  };
}

/** A target in a scripted run: its messages, its end status and how many seconds it took. */
export type ScriptedTarget = { pkg: string; task: string; messages: string[]; status: string; seconds: number; hash?: string };

/**
 * Feeds the reporter the entries a run produces: every target starts, the messages
 * arrive interleaved across targets, then each target ends in the given order.
 * Status entries go in at statusLevel, message entries at verbose.
 */
export function feedRun(reporter: any, targets: ScriptedTarget[], statusLevel = "verbose") {
  const level = LogLevel[statusLevel];
  const made = targets.map((t) => ({ ...t, target: createTarget(t.pkg, t.task) }));
  made.forEach((t, index) => {
    reporter.log({ data: { target: t.target, status: "running", duration: [0, 0], startTime: [index, 0] }, level, msg: "", timestamp: 0 });
  });
  const longest = Math.max(0, ...made.map((t) => t.messages.length));
  for (let i = 0; i < longest; i++) {
    for (const t of made) {
      if (i < t.messages.length) {
        reporter.log({ data: { target: t.target, pid: 1 }, level: LogLevel.verbose, msg: t.messages[i], timestamp: 0 });
      }
    }
  }
  made.forEach((t, index) => {
    const data: any = { target: t.target, status: t.status, duration: [t.seconds, 0], startTime: [index, 0] };
    if (t.hash) data.hash = t.hash;
    reporter.log({ data, level, msg: "", timestamp: 0 });
  });
  return made;
}

/** The end-of-run summary lage's scheduler hands every reporter. */
export function runSummary(made: any[]) {
  const byStatus = { success: [], failed: [], pending: [], running: [], aborted: [], skipped: [], queued: [] };
  const targetRuns = new Map();
  for (const t of made) {
    byStatus[t.status].push(t.target.id);
    targetRuns.set(t.target.id, {
      target: t.target,
      status: t.status,
      duration: [t.seconds, 0],
      startTime: [1, 0],
      queueTime: [0, 0],
      threadId: 0,
    });
  }
  const failed = byStatus.failed.length > 0;
  return {
    duration: [100, 0],
    startTime: [0, 0],
    results: failed ? "failed" : "success",
    targetRunByStatus: byStatus,
    targetRuns,
    maxWorkerMemoryUsage: 0,
    workerRestarts: 0,
  };
}

async function byName(name: string, grouped: boolean, logLevel = "verbose") {
  return createReporter(name, baseOptions(grouped, logLevel, [name]));
}

async function defaultReporter(grouped: boolean) {
  const reporters = await initializeReporters(new Logger(), baseOptions(grouped));
  return reporters[reporters.length - 1];
}

const lines = (text: string) => text.split("\n").filter((line) => line !== "");
const isGhGroupStart = (line: string) => line.startsWith("::group::");
const isGhGroupEnd = (line: string) => line.startsWith("::endgroup::");
const tokens = (text: string) => text.split(/[\s#:,()\[\]|]+/).filter(Boolean);

const STATUS_WORDS = {
  success: ["success", "succeeded", "passed", "ok", "done", "✓"],
  failed: ["failed", "failure", "fail", "error", "✖", "✗"],
  skipped: ["skipped", "skip", "cached", "»"],
  aborted: ["aborted", "abort", "cancelled", "canceled"],
};

/** True when a group title names the target's package, task, end status and duration. */
function titleNames(title: string, t: ScriptedTarget) {
  const words = tokens(title).map((word) => word.toLowerCase());
  const hasStatus = STATUS_WORDS[t.status].some((word) => words.includes(word.toLowerCase()) || title.includes(word + " "));
  const duration = new RegExp(`(?<![\\d.])${t.seconds}(?:\\.\\d+)?\\s*(?:s|sec|secs|seconds)\\b`);
  return words.includes(t.pkg.toLowerCase()) && words.includes(t.task.toLowerCase()) && hasStatus && duration.test(title);
}

/** Splits grouped GitHub output into groups and reports anything outside or unclosed. */
function readGroups(output: string) {
  const groups: { title: string; body: string[] }[] = [];
  const problems: string[] = [];
  let open: { title: string; body: string[] } | null = null;
  for (const line of lines(output)) {
    if (isGhGroupStart(line)) {
      if (open) problems.push(`group "${open.title}" not closed before "${line}"`);
      open = { title: line.slice("::group::".length), body: [] };
      groups.push(open);
    } else if (isGhGroupEnd(line)) {
      if (!open) problems.push("::endgroup:: with no open group");
      open = null;
    } else if (open) {
      open.body.push(line);
    } else {
      problems.push(`line outside a group: ${line}`);
    }
  }
  if (open) problems.push(`group "${open.title}" never closed`);
  return { groups, problems };
}

/** Splits grouped Azure output into per-target bodies, keyed by the group header. */
function readAzureGroups(output: string) {
  const groups: { title: string; body: string[] }[] = [];
  let open: { title: string; body: string[] } | null = null;
  for (const line of lines(output)) {
    if (line.startsWith("##[group]")) {
      open = { title: line.slice("##[group]".length).trim(), body: [] };
      groups.push(open);
    } else if (line.startsWith("##[endgroup]")) {
      open = null;
    } else if (open) {
      open.body.push(line);
    }
  }
  return groups;
}

function firstDifference(label: string, gh: string[], azure: string[]) {
  const length = Math.max(gh.length, azure.length);
  for (let i = 0; i < length; i++) {
    if (gh[i] !== azure[i]) {
      return `${label} line ${i + 1}: github=${JSON.stringify(gh[i] ?? null)} azure=${JSON.stringify(azure[i] ?? null)}`;
    }
  }
  return "";
}

const sortedJson = (items: string[]) => JSON.stringify([...items].sort());

// ---------------------------------------------------------------------------
// Story gha_autodetect
// ---------------------------------------------------------------------------
export async function observeAutodetect(inputs: { github: boolean; azure: boolean }) {
  const output = await withCiEnv(inputs, () =>
    captureStdout(async () => {
      const reporter = await defaultReporter(false);
      feedRun(reporter, [{ pkg: "a", task: "test", messages: ["a message"], status: "success", seconds: 10 }]);
    })
  );
  const probes = ["##[group]", "::group::"];
  return { markers: sortedJson(probes.filter((probe) => output.includes(probe))) };
}

// ---------------------------------------------------------------------------
// Story gha_grouped_output
// ---------------------------------------------------------------------------
export async function observeGroupedOutput(
  inputs: { grouped: boolean; status_level: string; log_level: string; targets: ScriptedTarget[] },
  ghAlias: string
) {
  const drive = (name: string) =>
    withCiEnv({}, () =>
      captureStdout(async () => {
        const reporter = await byName(name, inputs.grouped, inputs.log_level);
        feedRun(reporter, inputs.targets, inputs.status_level);
      })
    );
  const gh = await drive(ghAlias);
  const azure = await drive("azureDevops");

  if (!inputs.grouped) {
    const markers = lines(gh).filter((line) => isGhGroupStart(line) || isGhGroupEnd(line));
    return {
      structure: markers.length === 0 ? "no groups" : `group markers with grouping off: ${markers.join(" | ")}`,
      titles: "[]",
      bodies: firstDifference("inline output", lines(gh), lines(azure)) || "same as azure",
    };
  }

  const { groups, problems } = readGroups(gh);
  const titled = inputs.targets.filter((t) => groups.some((g) => titleNames(g.title, t)));
  const azureGroups = readAzureGroups(azure);
  let bodies = "same as azure";
  for (const t of inputs.targets) {
    const ghGroup = groups.find((g) => titleNames(g.title, t));
    const azureGroup = azureGroups.find((g) => g.title.startsWith(`${t.pkg} ${t.task} `));
    if (!ghGroup) {
      bodies = `no github group for ${t.pkg} ${t.task}`;
      break;
    }
    const difference = firstDifference(`${t.pkg} ${t.task}`, ghGroup.body, azureGroup ? azureGroup.body : []);
    if (difference) {
      bodies = difference;
      break;
    }
  }
  return {
    structure: problems.length === 0 ? (groups.length > 0 ? "ok" : "no groups") : problems[0],
    titles: sortedJson(titled.map((t) => `${t.pkg} ${t.task}`)),
    bodies,
  };
}

// ---------------------------------------------------------------------------
// Story gha_summary_and_errors
// ---------------------------------------------------------------------------
function annotationTitle(line: string) {
  // GitHub reads the properties up to the first "::", so a title may hold a single colon.
  const match = /^::error(?:\s+(.*?))?::/.exec(line);
  if (!match || !match[1]) return null;
  const title = /(?:^|,)\s*title=([^,]*)/.exec(match[1]);
  return title ? title[1] : null;
}

export async function observeSummary(inputs: { failing: ScriptedTarget[]; passing: ScriptedTarget[] }, ghAlias: string) {
  const targets = [...inputs.passing, ...inputs.failing];
  let summary = "";
  await withCiEnv({}, async () => {
    const reporter = await byName(ghAlias, true);
    let made: any[] = [];
    await captureStdout(async () => {
      made = feedRun(reporter, targets);
    });
    summary = await captureStdout(async () => {
      reporter.summarize(runSummary(made));
    });
  });

  const summaryLines = lines(summary);
  const groupAt = summaryLines.findIndex((line) => isGhGroupStart(line) && /summary/i.test(line));
  let summaryState = "missing";
  if (groupAt >= 0) {
    summaryState = summaryLines.slice(groupAt + 1).some(isGhGroupEnd) ? "closed" : "open";
  }

  const errorLines = summaryLines.map((line, index) => ({ line, index })).filter(({ line }) => line.startsWith("::error"));
  const titledLines = errorLines.filter(({ line }) => annotationTitle(line) !== null);
  const namesTarget = (line: string, t: ScriptedTarget) => {
    const words = tokens(annotationTitle(line) || "").map((word) => word.toLowerCase());
    return words.includes(t.pkg.toLowerCase()) && words.includes(t.task.toLowerCase());
  };

  const titled = inputs.failing.filter((t) => titledLines.some(({ line }) => namesTarget(line, t)));
  const titledPassing = inputs.passing.filter((t) => titledLines.some(({ line }) => namesTarget(line, t)));

  const followed: string[] = [];
  for (const t of inputs.failing) {
    const own = titledLines.find(({ line }) => namesTarget(line, t));
    if (!own) continue;
    const after = summaryLines.slice(own.index).join("\n");
    for (const message of t.messages) {
      if (message.trim() !== "" && after.includes(message)) followed.push(message);
    }
  }

  const passingLines = inputs.passing.flatMap((t) => t.messages).filter((m) => m.trim() !== "" && summary.includes(m));
  const firstTitled = titledLines.length > 0 ? titledLines[0].index : summaryLines.length;
  const stray = errorLines.filter(({ index }) => index < firstTitled).length;
  const empty = errorLines.filter(({ line }) => /^::error(?:\s+.*?)?::\s*$/.test(line)).length;

  return {
    summary: summaryState,
    titled: sortedJson(titled.map((t) => `${t.pkg} ${t.task}`)),
    titled_passing: sortedJson(titledPassing.map((t) => `${t.pkg} ${t.task}`)),
    followed: sortedJson(followed),
    passing_lines: sortedJson(passingLines),
    untitled_before_first_title: String(stray),
    empty_annotations: String(empty),
  };
}

// ---------------------------------------------------------------------------
// Story explicit_reporter_wins
// ---------------------------------------------------------------------------
export async function observeByName(inputs: { github: boolean; azure: boolean; unknown_name: string }, aliases: string[]) {
  let markers = ["::endgroup::", "::group::"];
  if (aliases.length === 0) markers = [];
  for (const alias of aliases) {
    const output = await withCiEnv(inputs, () =>
      captureStdout(async () => {
        const reporters = await initializeReporters(new Logger(), baseOptions(true, "verbose", [alias]));
        const reporter = reporters[reporters.length - 1];
        feedRun(reporter, [{ pkg: "a", task: "test", messages: ["a message"], status: "success", seconds: 10 }]);
      })
    );
    markers = markers.filter((marker) => output.includes(marker));
  }

  let message = "";
  await withCiEnv(inputs, async () => {
    try {
      await initializeReporters(new Logger(), baseOptions(false, "info", [inputs.unknown_name]));
    } catch (error) {
      message = String(error && error.message ? error.message : error);
    }
  });
  const listed = (alias: string) => message.split(/[\s,:"]+/).includes(alias);
  let missing = aliases.length < 2 ? ["__fewer_than_two_names__", ...aliases] : aliases.filter((alias) => !listed(alias));
  if (aliases.length >= 2 && new Set(aliases.map((alias) => alias.length)).size === 1) {
    missing = [...missing, "__no_shorter_name__"];
  }
  return { markers: sortedJson(markers), missing_from_list: sortedJson(missing) };
}

// ---------------------------------------------------------------------------
// Story ado_regression
// ---------------------------------------------------------------------------
export async function observeAzure(
  inputs: { name: string; github: boolean; azure: boolean; grouped: boolean; summarize: boolean; targets: ScriptedTarget[] }
) {
  const output = await withCiEnv(inputs, () =>
    captureStdout(async () => {
      const reporters = await initializeReporters(new Logger(), baseOptions(inputs.grouped, "verbose", [inputs.name]));
      const reporter = reporters[reporters.length - 1];
      const made = feedRun(reporter, inputs.targets);
      if (inputs.summarize) reporter.summarize(runSummary(made));
    })
  );
  return { output };
}
