## Task

We’re seeing popups render in the wrong place when their custom container is an ancestor or later sibling that isn’t available when the popup first renders. In those cases, the popup falls back to document body or the nearest parent portal and remains there. Please fix this across Dialog, AlertDialog, Drawer, Menu, Tooltip, PreviewCard, Popover, Select, and Toast. When the app provides a custom container, the popup should render inside that container whenever it becomes available, including for initially open or kept-mounted popups. It should not briefly appear in the fallback container when the intended container is part of the mounted tree.

If the provided ref never attaches, preserve the existing fallback behavior which renders into document body, or the nearest parent portal when nested. Existing behavior must remain unchanged for no custom container, an already attached container, and a direct DOM node as the container.
