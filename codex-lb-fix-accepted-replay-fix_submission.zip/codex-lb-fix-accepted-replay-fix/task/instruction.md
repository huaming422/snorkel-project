## Task

The proxy has gotten less resilient to upstream capacity problems than it used to be.

Sometimes an upstream account accepts a request, the client starts seeing the
response come back, and then that account runs out of capacity before any real
answer arrives. The client just gets a hard error, instead of the request
quietly retrying on another account in the pool. It used to ride these out.

On the rare occasions where something does retry, the client's stream looks
corrupted: the response appears to start over, with the "response started"
signal arriving more than once instead of one clean response. This happens both
on the plain HTTP path and on the direct WebSocket path clients connect to.

A retry is only safe in a narrow case, and must stay invisible. Don't
re-send a request that already started producing real output, or one the
account was already charged for. When a retry happens, the client should see
exactly one clean response, as if the first account had worked.

Dig into why these accepted-then-failed requests aren't retried cleanly, and fix it.
