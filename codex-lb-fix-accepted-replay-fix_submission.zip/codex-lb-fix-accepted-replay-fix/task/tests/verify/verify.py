"""Client-visible behaviour of accepted-then-capacity-failed turns.

This module exercises the proxy from the two public client surfaces — the
HTTP->SSE bridge (``POST /backend-api/codex/responses`` and ``POST
/v1/responses``) and the direct client WebSocket (``/backend-api/codex/
responses``) — and asserts only what a client actually observes: the sequence
of streamed response events and their ids, plus which pooled account each
upstream connection was routed to.

An "accepted" turn is one where the upstream has already emitted
``response.created`` and ``response.in_progress`` but produced no model output.
When such a turn then fails for a transient capacity reason, the pool is
expected to quietly move the identical request to another account and let the
client see a single clean response lifecycle (exactly one ``response.created``
whose id is the id of the terminal ``response.completed``). When instead the
turn has already produced output, was already billed, or failed for a quota
reason, re-sending it is unsafe, so the original terminal must surface to the
client unchanged on the single connection it started on.

The file is intentionally self-contained: when it is collected on its own the
repository's own test ``conftest`` is not in scope, so it sets the process
configuration before importing the application, builds its own database schema,
and neutralises the background schedulers / leader election exactly as the
application's own integration suite does.
"""

from __future__ import annotations

import json
import os
import tempfile
from collections import deque
from pathlib import Path
from types import SimpleNamespace
from typing import Any
from uuid import uuid4

import pytest
import pytest_asyncio

# --- Process configuration (must precede the application import) ------------

_TEST_DB_DIR = Path(tempfile.mkdtemp(prefix="codex-lb-accepted-replay-"))
_TEST_DB_PATH = _TEST_DB_DIR / "codex-lb.db"

os.environ["CODEX_LB_DATABASE_URL"] = os.environ.get(
    "CODEX_LB_TEST_DATABASE_URL", f"sqlite+aiosqlite:///{_TEST_DB_PATH}"
)
os.environ["CODEX_LB_UPSTREAM_BASE_URL"] = "https://example.invalid/backend-api"
os.environ["CODEX_LB_USAGE_REFRESH_ENABLED"] = "false"
os.environ["CODEX_LB_MODEL_REGISTRY_ENABLED"] = "false"
os.environ["CODEX_LB_STICKY_SESSION_CLEANUP_ENABLED"] = "false"
os.environ["CODEX_LB_HTTP_RESPONSES_SESSION_BRIDGE_ENABLED"] = "false"
os.environ["CODEX_LB_QUOTA_PLANNER_SCHEDULER_ENABLED"] = "false"
os.environ["CODEX_LB_AUTOMATIONS_SCHEDULER_ENABLED"] = "false"
os.environ["CODEX_LB_UPSTREAM_ROUTE_CACHE_TTL_SECONDS"] = "0"

from fastapi.testclient import TestClient  # noqa: E402
from httpx import ASGITransport, AsyncClient  # noqa: E402
from sqlalchemy import select, text  # noqa: E402
from starlette.websockets import WebSocketDisconnect  # noqa: E402

import app.modules.proxy.api as proxy_api_module  # noqa: E402
import app.modules.proxy.service as proxy_module  # noqa: E402
from app.db.models import Account, Base, DashboardSettings  # noqa: E402
from app.db.session import engine  # noqa: E402
from app.modules.proxy._service.http_bridge import (  # noqa: E402
    upstream_events as http_bridge_upstream_events_module,
)
from app.modules.proxy.load_balancer import AccountSelection  # noqa: E402
from app.core.config.settings import Settings  # noqa: E402

import base64  # noqa: E402


# --- Self-contained test lifecycle (mirrors the integration suite) ----------


class _NoopScheduler:
    async def start(self) -> None:
        return None

    async def stop(self) -> None:
        return None


class _NoopLeaderElection:
    leader_id = "verify-noop-leader"

    @property
    def is_leader(self) -> bool:
        return True

    async def try_acquire(self) -> bool:
        return True

    async def renew(self) -> bool:
        return True

    async def run_if_leader(self, fn):
        return await fn()

    def start_release_keeper(self) -> None:
        return None

    async def release(self) -> bool:
        return True


def _recreate_schema(sync_conn) -> None:
    sync_conn.execute(text("DROP TABLE IF EXISTS alembic_version"))
    sync_conn.execute(text("DROP TABLE IF EXISTS schema_migrations"))
    Base.metadata.drop_all(sync_conn)
    Base.metadata.create_all(sync_conn)


@pytest.fixture(autouse=True)
def _encryption_key_file(monkeypatch):
    key_path = _TEST_DB_DIR / f"encryption-{uuid4().hex}.key"
    monkeypatch.setenv("CODEX_LB_ENCRYPTION_KEY_FILE", str(key_path))
    from app.core.config.settings import get_settings

    get_settings.cache_clear()
    return key_path


@pytest.fixture(autouse=True)
def _neutralise_background_workers(monkeypatch):
    """Keep the application lifespan free of real-clock background writes.

    Left running, the schedulers and the leader-election release keeper perform
    their own writes against the shared single-writer SQLite file and contend
    with schema teardown. They are swapped for inert stand-ins, scoped to the
    lifespan only (the production defaults are untouched)."""
    import app.core.scheduling.leader_election as leader_election_module
    import app.main as main_module

    election = _NoopLeaderElection()
    monkeypatch.setattr(leader_election_module, "get_leader_election", lambda: election)
    monkeypatch.setattr(main_module, "get_leader_election", lambda: election)
    for builder in (
        "build_rate_limit_reset_credits_scheduler",
        "build_account_usage_rollup_scheduler",
        "build_data_retention_scheduler",
        "build_telemetry_scheduler",
    ):
        monkeypatch.setattr(main_module, builder, lambda: _NoopScheduler())


@pytest.fixture(autouse=True)
def _reset_routing_caches():
    """Clear the process-global routing/auth caches around each test so a
    fresh per-test database never collides with a previous test's cached
    account-selection or key state."""

    def _clear() -> None:
        for importer in (
            lambda: __import__("app.core.auth.api_key_cache", fromlist=["get_api_key_cache"]).get_api_key_cache().clear(),
            lambda: __import__(
                "app.modules.proxy.account_cache", fromlist=["get_account_selection_cache"]
            ).get_account_selection_cache().invalidate(),
        ):
            try:
                importer()
            except Exception:
                pass

    _clear()
    yield
    _clear()


async def _reap_bridge_settlement_tasks(app) -> None:
    import asyncio

    service = getattr(getattr(app, "state", None), "proxy_service", None)
    if service is None:
        return
    loop = asyncio.get_running_loop()
    tasks = [
        task
        for task in getattr(service, "_background_cleanup_tasks", ())
        if not task.done()
        and task.get_name().startswith("http-bridge-recovery-settlement-")
        and task.get_loop() is loop
    ]
    for task in tasks:
        task.cancel()
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)
        await asyncio.sleep(0)


@pytest_asyncio.fixture
async def _fresh_database():
    from app.db.session import close_db

    await close_db()
    async with engine.begin() as conn:
        await conn.run_sync(_recreate_schema)
    return True


@pytest_asyncio.fixture
async def app_instance(_fresh_database, monkeypatch):
    del _fresh_database
    import app.main as main_module

    async def _noop_init_db() -> None:
        return None

    monkeypatch.setattr(main_module, "init_db", _noop_init_db)
    app = main_module.create_app()
    yield app
    await _reap_bridge_settlement_tasks(app)


@pytest_asyncio.fixture
async def async_client(app_instance):
    async def _drain(response) -> None:
        del response
        service = getattr(app_instance.state, "proxy_service", None)
        if service is not None and hasattr(service, "drain_persistence_tasks"):
            await service.drain_persistence_tasks(timeout_seconds=5)

    async with app_instance.router.lifespan_context(app_instance):
        transport = ASGITransport(app=app_instance)
        async with AsyncClient(
            transport=transport,
            base_url="http://testserver",
            event_hooks={"response": [_drain]},
        ) as client:
            yield client
        await _reap_bridge_settlement_tasks(app_instance)


# --- Account import + settings installation --------------------------------


def _encode_jwt(payload: dict) -> str:
    raw = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    body = base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")
    return f"header.{body}.sig"


def _make_auth_json(account_id: str, email: str, *, plan_type: str = "plus") -> dict:
    payload = {
        "email": email,
        "chatgpt_account_id": account_id,
        "https://api.openai.com/auth": {"chatgpt_plan_type": plan_type},
    }
    return {
        "tokens": {
            "idToken": _encode_jwt(payload),
            "accessToken": "access-token",
            "refreshToken": "refresh-token",
            "accountId": account_id,
        },
    }


async def _import_account(async_client, account_id: str, email: str) -> str:
    auth_json = _make_auth_json(account_id, email)
    files = {"auth_json": ("auth.json", json.dumps(auth_json), "application/json")}
    response = await async_client.post("/api/accounts/import", files=files)
    assert response.status_code == 200
    return response.json()["accountId"]


async def _get_account(account_id: str) -> Account:
    from app.db.session import SessionLocal

    async with SessionLocal() as session:
        result = await session.execute(select(Account).where(Account.id == account_id))
        account = result.scalar_one()
        session.expunge(account)
        return account


class _SettingsCache:
    def __init__(self, settings: DashboardSettings) -> None:
        self._settings = settings

    async def get(self) -> DashboardSettings:
        return self._settings


def _make_app_settings() -> Settings:
    return Settings(
        http_responses_session_bridge_enabled=True,
        http_responses_session_bridge_idle_ttl_seconds=120.0,
        http_responses_session_bridge_codex_idle_ttl_seconds=900.0,
        http_responses_session_bridge_codex_prewarm_enabled=False,
        http_responses_session_bridge_max_sessions=128,
        http_responses_session_bridge_queue_limit=8,
        http_responses_session_bridge_instance_id="instance-a",
        http_responses_session_bridge_instance_ring=[],
        proxy_admission_wait_timeout_seconds=0.05,
        proxy_request_budget_seconds=75.0,
        compact_request_budget_seconds=75.0,
        transcription_request_budget_seconds=120.0,
        upstream_compact_timeout_seconds=None,
        upstream_stream_transport="auto",
        stream_idle_timeout_seconds=300.0,
        openai_prompt_cache_key_derivation_enabled=True,
    )


def _make_dashboard_settings() -> DashboardSettings:
    return DashboardSettings(
        id=1,
        sticky_threads_enabled=False,
        upstream_stream_transport="auto",
        http_downstream_transport_policy="always_websocket",
        prefer_earlier_reset_accounts=False,
        routing_strategy="usage_weighted",
        openai_cache_affinity_max_age_seconds=300,
        import_without_overwrite=False,
        totp_required_on_login=False,
        api_key_auth_enabled=False,
        http_responses_session_bridge_prompt_cache_idle_ttl_seconds=3600,
        http_responses_session_bridge_gateway_safe_mode=False,
        sticky_reallocation_budget_threshold_pct=95.0,
    )


def _install_bridge_settings(monkeypatch) -> None:
    dashboard_settings = _make_dashboard_settings()
    app_settings = _make_app_settings()
    monkeypatch.setattr(proxy_module, "get_settings_cache", lambda: _SettingsCache(dashboard_settings))
    monkeypatch.setattr(proxy_module, "get_settings", lambda: app_settings)


async def _collect_sse_events(async_client, path: str, *, json_body: dict) -> list[dict]:
    async with async_client.stream("POST", path, json=json_body) as response:
        assert response.status_code == 200
        lines = [line async for line in response.aiter_lines() if line.startswith("data: ")]
    return [
        event
        for line in lines
        if line[6:] != "[DONE]"
        if (event := json.loads(line[6:])).get("type") != "codex.keepalive"
    ]


# --- HTTP->SSE bridge upstream doubles -------------------------------------


class _FakeUpstreamMessage:
    def __init__(
        self,
        kind: str,
        *,
        text: str | None = None,
        close_code: int | None = None,
        error: str | None = None,
        error_code: str | None = None,
    ) -> None:
        self.kind = kind
        self.text = text
        self.close_code = close_code
        self.error = error
        self.error_code = error_code
        self.data = None


class _FakeBridgeUpstreamWebSocket:
    """A healthy upstream: every request produces one clean ``created`` then
    ``completed`` turn whose single output message is the text ``OK``."""

    def __init__(self, response_id_prefix: str = "resp_bridge") -> None:
        import asyncio

        self.sent_text: list[str] = []
        self.closed = False
        self.response_id_prefix = response_id_prefix
        self._messages: asyncio.Queue[_FakeUpstreamMessage] = asyncio.Queue()

    async def send_text(self, text: str) -> None:
        self.sent_text.append(text)
        response_id = f"{self.response_id_prefix}_{len(self.sent_text)}"
        await self._messages.put(
            _FakeUpstreamMessage(
                "text",
                text=json.dumps(
                    {
                        "type": "response.created",
                        "response": {"id": response_id, "object": "response", "status": "in_progress"},
                    },
                    separators=(",", ":"),
                ),
            )
        )
        await self._messages.put(
            _FakeUpstreamMessage(
                "text",
                text=json.dumps(
                    {
                        "type": "response.completed",
                        "response": {
                            "id": response_id,
                            "object": "response",
                            "status": "completed",
                            "output": [
                                {
                                    "type": "message",
                                    "role": "assistant",
                                    "content": [{"type": "output_text", "text": "OK"}],
                                }
                            ],
                            "usage": {
                                "input_tokens": 24,
                                "output_tokens": 2,
                                "total_tokens": 26,
                                "input_tokens_details": {"cached_tokens": 20},
                                "output_tokens_details": {"reasoning_tokens": 0},
                            },
                        },
                    },
                    separators=(",", ":"),
                ),
            )
        )

    async def send_bytes(self, data: bytes) -> None:
        raise AssertionError(f"Unexpected binary frame: {data!r}")

    async def receive(self) -> _FakeUpstreamMessage:
        return await self._messages.get()

    async def close(self) -> None:
        self.closed = True

    def response_header(self, name: str) -> str | None:
        del name
        return None


class _AcceptedOutputFreeTerminalUpstreamWebSocket(_FakeBridgeUpstreamWebSocket):
    """Accepts the turn (``created`` + ``in_progress``) then terminates it with
    an output-free ``error`` carrying ``error_code``. With a transient capacity
    code the turn is safe to move; with a quota code it is not."""

    def __init__(
        self,
        *,
        error_code: str = "server_is_overloaded",
        error_message: str = "Our servers are currently overloaded. Please try again later.",
    ) -> None:
        super().__init__("resp_accepted_output_free_failed")
        self.error_code = error_code
        self.error_message = error_message

    async def send_text(self, text: str) -> None:
        self.sent_text.append(text)
        response_id = f"{self.response_id_prefix}_{len(self.sent_text)}"
        for event in (
            {"type": "response.created", "response": {"id": response_id, "object": "response", "status": "in_progress"}},
            {
                "type": "response.in_progress",
                "response": {"id": response_id, "object": "response", "status": "in_progress"},
            },
            {
                "type": "error",
                "error": {
                    "type": "service_unavailable_error",
                    "code": self.error_code,
                    "message": self.error_message,
                },
            },
        ):
            await self._messages.put(_FakeUpstreamMessage("text", text=json.dumps(event, separators=(",", ":"))))


class _AcceptedBilledCapacityFailureUpstreamWebSocket(_FakeBridgeUpstreamWebSocket):
    """Accepts the turn and fails it with a capacity ``response.failed`` whose
    payload reports billed output tokens: the model ran, so re-sending is
    unsafe even though the failure reason is transient."""

    def __init__(self) -> None:
        super().__init__("resp_accepted_billed_failed")

    async def send_text(self, text: str) -> None:
        self.sent_text.append(text)
        response_id = f"{self.response_id_prefix}_{len(self.sent_text)}"
        for event in (
            {"type": "response.created", "response": {"id": response_id, "object": "response", "status": "in_progress"}},
            {
                "type": "response.in_progress",
                "response": {"id": response_id, "object": "response", "status": "in_progress"},
            },
            {
                "type": "response.failed",
                "response": {
                    "id": response_id,
                    "object": "response",
                    "status": "failed",
                    "error": {
                        "code": "server_is_overloaded",
                        "message": "Our servers are currently overloaded. Please try again later.",
                    },
                    "usage": {"input_tokens": 12, "output_tokens": 3, "total_tokens": 15},
                },
            },
        ):
            await self._messages.put(_FakeUpstreamMessage("text", text=json.dumps(event, separators=(",", ":"))))


def _install_two_account_bridge_failover(
    monkeypatch,
    *,
    first_account: Account,
    second_account: Account,
    upstreams: list[_FakeBridgeUpstreamWebSocket],
) -> tuple[list[str | None], list[frozenset[str]]]:
    """Route selection to ``first_account`` until it is excluded, then to
    ``second_account``; hand out ``upstreams`` in connect order. Returns the
    ``chatgpt-account-id`` header of every upstream connection and the
    ``exclude_account_ids`` of every selection call."""

    connect_account_ids: list[str | None] = []
    selection_exclusions: list[frozenset[str]] = []

    async def fake_select_account_with_budget(self, deadline, *, exclude_account_ids=None, **kwargs):
        del self, deadline, kwargs
        excluded = frozenset(exclude_account_ids or ())
        selection_exclusions.append(excluded)
        chosen = second_account if first_account.id in excluded else first_account
        return AccountSelection(account=chosen, error_message=None, error_code=None)

    async def fake_ensure_fresh_with_budget(self, target, *, force=False, timeout_seconds):
        del self, force, timeout_seconds
        return target

    async def fake_connect_responses_websocket(
        headers, access_token, account_id_header, *, base_url=None, session=None
    ):
        del headers, access_token, base_url, session
        connect_account_ids.append(account_id_header)
        assert upstreams, "unexpected extra upstream connect"
        return upstreams.pop(0)

    async def fail_legacy_stream(*args, **kwargs):
        raise AssertionError("legacy streaming path must not run when the session bridge is enabled")

    monkeypatch.setattr(proxy_module.ProxyService, "_select_account_with_budget", fake_select_account_with_budget)
    monkeypatch.setattr(proxy_module.ProxyService, "_ensure_fresh_with_budget", fake_ensure_fresh_with_budget)
    monkeypatch.setattr(proxy_module, "connect_responses_websocket", fake_connect_responses_websocket)
    monkeypatch.setattr(proxy_module, "core_stream_responses", fail_legacy_stream)
    return connect_account_ids, selection_exclusions


def _assert_single_response_lifecycle_completed(events: list[dict]) -> str:
    """The client observes exactly one ``response.created`` whose id is the id
    of the terminal ``response.completed`` that ends the stream, with no
    error-shaped event in between."""
    types = [event["type"] for event in events]
    created_ids = [event["response"]["id"] for event in events if event["type"] == "response.created"]
    assert len(created_ids) == 1, f"client must observe exactly one response.created, got {types}"
    assert not any(t in {"error", "response.failed", "response.incomplete"} for t in types), types
    assert types[-1] == "response.completed", types
    assert events[-1]["response"]["id"] == created_ids[0]
    assert events[-1]["response"]["output"][0]["content"][0]["text"] == "OK"
    return created_ids[0]


# --- Direct client WebSocket upstream doubles ------------------------------


class _WsFakeUpstreamWebSocket:
    def __init__(self, messages: list[_FakeUpstreamMessage]) -> None:
        import asyncio

        self.sent_text: list[str] = []
        self.closed = False
        self._messages: asyncio.Queue[_FakeUpstreamMessage] = asyncio.Queue()
        for message in messages:
            self._messages.put_nowait(message)

    async def send_text(self, text: str) -> None:
        self.sent_text.append(text)

    async def send_bytes(self, data: bytes) -> None:
        del data

    async def receive(self) -> _FakeUpstreamMessage:
        return await self._messages.get()

    def archive_received(self, message: _FakeUpstreamMessage) -> None:
        del message

    async def close(self) -> None:
        self.closed = True


class _WsSequencedUpstreamWebSocket(_WsFakeUpstreamWebSocket):
    def __init__(
        self,
        messages: list[_FakeUpstreamMessage],
        *,
        deferred_message_batches: list[list[_FakeUpstreamMessage]] | None = None,
    ) -> None:
        super().__init__(messages)
        self._deferred_message_batches = deque(deferred_message_batches or [])

    async def send_text(self, text: str) -> None:
        await super().send_text(text)
        if not self._deferred_message_batches:
            return
        for message in self._deferred_message_batches.popleft():
            self._messages.put_nowait(message)


def _ws_event(payload: dict[str, object]) -> _FakeUpstreamMessage:
    return _FakeUpstreamMessage("text", text=json.dumps(payload, separators=(",", ":")))


def _accepted_output_free_prelude(response_id: str) -> list[_FakeUpstreamMessage]:
    return [
        _ws_event({"type": "response.created", "response": {"id": response_id, "status": "in_progress"}}),
        _ws_event({"type": "response.in_progress", "response": {"id": response_id, "status": "in_progress"}}),
    ]


def _recovered_ws_upstream(response_id: str) -> _WsSequencedUpstreamWebSocket:
    return _WsSequencedUpstreamWebSocket(
        [],
        deferred_message_batches=[
            [
                _ws_event({"type": "response.created", "response": {"id": response_id, "status": "in_progress"}}),
                _ws_event(
                    {
                        "type": "response.completed",
                        "response": {
                            "id": response_id,
                            "status": "completed",
                            "output": [
                                {
                                    "type": "message",
                                    "role": "assistant",
                                    "content": [{"type": "output_text", "text": "OK"}],
                                }
                            ],
                        },
                    }
                ),
            ]
        ],
    )


def _ws_settings(**overrides):
    values = {
        "prefer_earlier_reset_accounts": False,
        "sticky_threads_enabled": False,
        "openai_cache_affinity_max_age_seconds": 300,
        "openai_prompt_cache_key_derivation_enabled": True,
        "routing_strategy": "usage_weighted",
        "proxy_request_budget_seconds": 75.0,
        "stream_idle_timeout_seconds": 300.0,
        "proxy_downstream_websocket_idle_timeout_seconds": 120.0,
        "http_responses_session_bridge_instance_id": "test-instance",
        "sse_keepalive_interval_seconds": 0.5,
        "trace_channels": frozenset(),
        "proxy_token_refresh_limit": 32,
        "proxy_upstream_websocket_connect_limit": 64,
        "proxy_account_stream_recovery_reserve": 1,
        "proxy_api_key_fair_share_congestion_threshold_pct": 0,
        "proxy_response_create_limit": 64,
        "proxy_compact_response_create_limit": 16,
    }
    values.update(overrides)
    return SimpleNamespace(**values)


def _receive_until_terminal(websocket, *, limit: int = 12):
    events: list[dict[str, Any]] = []
    for _ in range(limit):
        try:
            event = json.loads(websocket.receive_text())
        except WebSocketDisconnect as exc:
            return events, exc
        if event.get("type") == "codex.keepalive":
            continue
        events.append(event)
        if event.get("type") in {"response.completed", "response.failed", "response.incomplete", "error"}:
            break
    return events, None


class _WsTwoAccountFailover:
    """Two selectable accounts for the direct WebSocket surface, for an
    unanchored first turn (no previous response, no session affinity). The fake
    connection honours the one thing real re-selection honours here — the set
    of accounts the request has excluded — and otherwise refuses with the same
    ``previous_response_owner_unavailable`` failure the production connect emits
    when no account qualifies. A replay that never excludes the spent account
    lands on it again; only a replay that excludes it reaches the other
    account."""

    FIRST_ACCOUNT_ID = "acct_ws_accepted_a"
    SECOND_ACCOUNT_ID = "acct_ws_accepted_b"

    def __init__(self, first_upstream, recovered_upstream) -> None:
        self.upstreams_by_account: dict[str, deque] = {
            self.FIRST_ACCOUNT_ID: deque([first_upstream]),
            self.SECOND_ACCOUNT_ID: deque([recovered_upstream]),
        }
        self.connect_accounts: list[str] = []
        self.excluded_at_connect: list[set[str]] = []
        self.refused_connects: list[dict[str, Any]] = []

    def install(self, monkeypatch) -> None:
        failover = self

        class _FakeSettingsCache:
            async def get(self):
                return _ws_settings()

        async def allow_firewall(_websocket):
            return None

        async def allow_proxy_api_key(_authorization, *, request=None):
            del request
            return None

        async def fake_connect_proxy_websocket(
            self, headers, *, request_state, websocket, client_send_lock, api_key, **kwargs
        ):
            del headers, kwargs
            excluded_account_ids = set(request_state.excluded_account_ids)
            failover.excluded_at_connect.append(excluded_account_ids)
            candidates = [
                account_id
                for account_id in failover.upstreams_by_account
                if account_id not in excluded_account_ids and failover.upstreams_by_account[account_id]
            ]
            if not candidates:
                failover.refused_connects.append({"excluded": excluded_account_ids})
                message = "Previous response owner account is unavailable; retry later."
                await self._emit_websocket_connect_failure(
                    websocket,
                    client_send_lock=client_send_lock,
                    account_id=None,
                    api_key=api_key,
                    request_state=request_state,
                    status_code=502,
                    payload=proxy_module.openai_error(
                        "previous_response_owner_unavailable",
                        message,
                        error_type="server_error",
                    ),
                    error_code="previous_response_owner_unavailable",
                    error_message=message,
                )
                return None, None
            selected_account_id = candidates[0]
            failover.connect_accounts.append(selected_account_id)
            return SimpleNamespace(id=selected_account_id), failover.upstreams_by_account[selected_account_id].popleft()

        async def fake_write_request_log(self, **kwargs):
            del self, kwargs

        monkeypatch.setattr(proxy_api_module, "_websocket_firewall_denial_response", allow_firewall)
        monkeypatch.setattr(proxy_api_module, "validate_proxy_api_key_authorization", allow_proxy_api_key)
        monkeypatch.setattr(proxy_module, "get_settings_cache", lambda: _FakeSettingsCache())
        monkeypatch.setattr(proxy_module.ProxyService, "_connect_proxy_websocket", fake_connect_proxy_websocket)
        monkeypatch.setattr(proxy_module.ProxyService, "_write_request_log", fake_write_request_log)

    @staticmethod
    def _response_create() -> dict[str, Any]:
        return {
            "type": "response.create",
            "model": "gpt-5.4",
            "input": [{"role": "user", "content": [{"type": "input_text", "text": "hello"}]}],
            "stream": True,
        }

    def run(self, app_instance):
        with TestClient(app_instance) as client:
            with client.websocket_connect("/backend-api/codex/responses") as websocket:
                websocket.send_text(json.dumps(self._response_create()))
                return _receive_until_terminal(websocket)

    def assert_retried_on_another_account(self) -> None:
        assert not self.refused_connects, self.refused_connects
        assert self.connect_accounts == [self.FIRST_ACCOUNT_ID, self.SECOND_ACCOUNT_ID], self.connect_accounts
        assert self.excluded_at_connect[-1] == {self.FIRST_ACCOUNT_ID}, self.excluded_at_connect


def _assert_ws_single_response_lifecycle_completed(events, disconnect) -> str:
    types = [event["type"] for event in events]
    assert disconnect is None, f"unexpected disconnect code={getattr(disconnect, 'code', None)} after {types}"
    created_ids = [event["response"]["id"] for event in events if event["type"] == "response.created"]
    assert len(created_ids) == 1, f"client must observe exactly one response.created, got {types}"
    assert not any(t in {"error", "response.failed", "response.incomplete"} for t in types), types
    assert types[-1] == "response.completed", types
    assert events[-1]["response"]["id"] == created_ids[0]
    return created_ids[0]


# --- Behaviours ------------------------------------------------------------


@pytest.mark.parametrize(
    ("error_code", "error_message"),
    [
        ("server_is_overloaded", "Our servers are currently overloaded. Please try again later."),
        ("model_at_capacity", "Selected model is at capacity. Please try a different model."),
    ],
)
async def test_bridge_retries_accepted_output_free_capacity_failure_within_one_lifecycle(
    async_client, monkeypatch, error_code, error_message
):
    """HTTP->SSE surface: an accepted, output-free turn that fails for a
    transient capacity reason is moved to another account, and the client sees
    a single clean response lifecycle rather than a hard error."""
    _install_bridge_settings(monkeypatch)
    monkeypatch.setattr(
        http_bridge_upstream_events_module, "_ACCOUNT_SELECTION_RECOVERY_DEFAULT_SLEEP_SECONDS", 0.01
    )
    first_account_id = await _import_account(async_client, "acc_bridge_capacity_a", "bridge-capacity-a@example.com")
    second_account_id = await _import_account(async_client, "acc_bridge_capacity_b", "bridge-capacity-b@example.com")
    first_account = await _get_account(first_account_id)
    second_account = await _get_account(second_account_id)
    failing_upstream = _AcceptedOutputFreeTerminalUpstreamWebSocket(error_code=error_code, error_message=error_message)
    retry_upstream = _FakeBridgeUpstreamWebSocket("resp_bridge_capacity_retry")
    connect_account_ids, selection_exclusions = _install_two_account_bridge_failover(
        monkeypatch,
        first_account=first_account,
        second_account=second_account,
        upstreams=[failing_upstream, retry_upstream],
    )

    events = await _collect_sse_events(
        async_client,
        "/backend-api/codex/responses",
        json_body={
            "model": "gpt-5.1",
            "instructions": "Return exactly OK.",
            "input": "retry-accepted-capacity",
            "prompt_cache_key": "accepted-capacity-retry-key",
            "stream": True,
        },
    )

    _assert_single_response_lifecycle_completed(events)
    assert connect_account_ids == ["acc_bridge_capacity_a", "acc_bridge_capacity_b"]
    assert first_account.id in selection_exclusions[-1]
    assert second_account.id not in selection_exclusions[-1]
    assert len(failing_upstream.sent_text) == 1
    assert len(retry_upstream.sent_text) == 1
    assert json.loads(retry_upstream.sent_text[0])["input"] == json.loads(failing_upstream.sent_text[0])["input"]
    assert failing_upstream.closed is True


def test_websocket_retries_accepted_output_free_capacity_failure_within_one_lifecycle(app_instance, monkeypatch):
    """Direct client WebSocket surface: an accepted, output-free turn that
    fails for a transient capacity reason is moved to another account, and the
    client sees a single clean response lifecycle."""
    first_upstream = _WsSequencedUpstreamWebSocket(
        [],
        deferred_message_batches=[
            [
                *_accepted_output_free_prelude("resp_ws_capacity_failed"),
                _ws_event(
                    {
                        "type": "error",
                        "error": {
                            "type": "service_unavailable_error",
                            "code": "server_is_overloaded",
                            "message": "Our servers are currently overloaded. Please try again later.",
                        },
                    }
                ),
            ]
        ],
    )
    recovered_upstream = _recovered_ws_upstream("resp_ws_capacity_recovered")
    failover = _WsTwoAccountFailover(first_upstream, recovered_upstream)
    failover.install(monkeypatch)

    events, disconnect = failover.run(app_instance)

    _assert_ws_single_response_lifecycle_completed(events, disconnect)
    failover.assert_retried_on_another_account()
    assert len(first_upstream.sent_text) == 1
    assert len(recovered_upstream.sent_text) == 1
    assert json.loads(recovered_upstream.sent_text[0])["input"] == json.loads(first_upstream.sent_text[0])["input"]


async def test_bridge_does_not_replay_accepted_failure_reporting_billed_output(async_client, monkeypatch):
    """An accepted turn whose terminal reports billed output tokens proves the
    model ran; the failure must surface unchanged on the single connection
    rather than re-sending an already charged turn."""
    _install_bridge_settings(monkeypatch)
    first_account_id = await _import_account(async_client, "acc_bridge_billed_a", "bridge-billed-a@example.com")
    second_account_id = await _import_account(async_client, "acc_bridge_billed_b", "bridge-billed-b@example.com")
    first_account = await _get_account(first_account_id)
    second_account = await _get_account(second_account_id)
    failing_upstream = _AcceptedBilledCapacityFailureUpstreamWebSocket()
    connect_account_ids, _selection_exclusions = _install_two_account_bridge_failover(
        monkeypatch,
        first_account=first_account,
        second_account=second_account,
        upstreams=[failing_upstream],
    )

    events = await _collect_sse_events(
        async_client,
        "/backend-api/codex/responses",
        json_body={
            "model": "gpt-5.1",
            "instructions": "Return exactly OK.",
            "input": "accepted-billed-capacity",
            "prompt_cache_key": "accepted-billed-capacity-key",
            "stream": True,
        },
    )

    assert [event["type"] for event in events] == ["response.created", "response.in_progress", "response.failed"]
    assert events[-1]["response"]["id"] == events[0]["response"]["id"]
    assert events[-1]["response"]["error"]["code"] == "server_is_overloaded"
    assert connect_account_ids == ["acc_bridge_billed_a"]
    assert len(failing_upstream.sent_text) == 1


async def test_bridge_does_not_replay_accepted_output_free_quota_failure(async_client, monkeypatch):
    """An accepted, output-free turn that fails for a quota reason (as opposed
    to a transient capacity reason) is not safe to move; the terminal error
    surfaces unchanged on the single connection the turn started on."""
    _install_bridge_settings(monkeypatch)
    first_account_id = await _import_account(async_client, "acc_bridge_quota_a", "bridge-quota-a@example.com")
    second_account_id = await _import_account(async_client, "acc_bridge_quota_b", "bridge-quota-b@example.com")
    first_account = await _get_account(first_account_id)
    second_account = await _get_account(second_account_id)
    failing_upstream = _AcceptedOutputFreeTerminalUpstreamWebSocket(
        error_code="usage_limit_reached",
        error_message="You have hit your usage limit.",
    )
    connect_account_ids, selection_exclusions = _install_two_account_bridge_failover(
        monkeypatch,
        first_account=first_account,
        second_account=second_account,
        upstreams=[failing_upstream],
    )

    events = await _collect_sse_events(
        async_client,
        "/backend-api/codex/responses",
        json_body={
            "model": "gpt-5.1",
            "instructions": "Return exactly OK.",
            "input": "accepted-quota",
            "prompt_cache_key": "accepted-quota-key",
            "stream": True,
        },
    )

    assert [event["type"] for event in events] == ["response.created", "response.in_progress", "error"]
    assert events[-1]["error"]["code"] == "usage_limit_reached"
    assert connect_account_ids == ["acc_bridge_quota_a"]
    assert len(selection_exclusions) == 1
    assert len(failing_upstream.sent_text) == 1


async def test_bridge_normal_completion_remains_single_connection_single_lifecycle(async_client, monkeypatch):
    """A turn that completes normally is untouched by the capacity-recovery
    path: one upstream connection, one clean response lifecycle ending in
    ``response.completed``."""
    _install_bridge_settings(monkeypatch)
    first_account_id = await _import_account(async_client, "acc_bridge_normal_a", "bridge-normal-a@example.com")
    second_account_id = await _import_account(async_client, "acc_bridge_normal_b", "bridge-normal-b@example.com")
    first_account = await _get_account(first_account_id)
    second_account = await _get_account(second_account_id)
    healthy_upstream = _FakeBridgeUpstreamWebSocket("resp_bridge_normal")
    connect_account_ids, selection_exclusions = _install_two_account_bridge_failover(
        monkeypatch,
        first_account=first_account,
        second_account=second_account,
        upstreams=[healthy_upstream],
    )

    events = await _collect_sse_events(
        async_client,
        "/backend-api/codex/responses",
        json_body={
            "model": "gpt-5.1",
            "instructions": "Return exactly OK.",
            "input": "normal-completion",
            "prompt_cache_key": "normal-completion-key",
            "stream": True,
        },
    )

    _assert_single_response_lifecycle_completed(events)
    assert connect_account_ids == ["acc_bridge_normal_a"]
    assert len(selection_exclusions) == 1
    assert len(healthy_upstream.sent_text) == 1
