// Shared helper for tests that drive the `opa run` interactive prompt.
//
// This file declares no `func TestXxx`, so the go-test driver compiles it next
// to each test file as a shared helper. It holds the plumbing only: it builds
// the opa binary and drives its interactive prompt over a piped (non-terminal)
// stdin, and it asserts nothing about behavior. Each test file holds its own
// assertions.
//
// It is an external `repl_test` helper: it imports no package under test and
// references no internal identifiers.
package repl_test

import (
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

// repoRoot walks up from the test binary's working directory (the package
// directory it was compiled in) until it finds the module's go.mod, and returns
// that directory. The shipped command's main package lives at the module root.
func repoRoot(t *testing.T) string {
	t.Helper()
	dir, err := os.Getwd()
	if err != nil {
		t.Fatalf("getwd: %v", err)
	}
	for {
		if _, err := os.Stat(filepath.Join(dir, "go.mod")); err == nil {
			return dir
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			t.Fatalf("could not locate go.mod above %s", dir)
		}
		dir = parent
	}
}

// BuildOPA compiles the command under test from the module root and returns the
// path to the built binary. The binary is written to a per-test temp dir.
func BuildOPA(t *testing.T) string {
	t.Helper()
	root := repoRoot(t)
	bin := filepath.Join(t.TempDir(), "opa")
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	cmd := exec.CommandContext(ctx, "go", "build", "-o", bin, ".")
	cmd.Dir = root
	cmd.Env = os.Environ()
	if out, err := cmd.CombinedOutput(); err != nil {
		t.Fatalf("building the command failed: %v\n%s", err, out)
	}
	return bin
}

// RunREPLSession starts the interactive prompt (`<bin> run`) with the given
// lines fed to its stdin as a non-terminal pipe, waits for it to finish reading
// at EOF, and returns the combined session output. The lines are sent verbatim,
// one per prompt line.
func RunREPLSession(t *testing.T, bin string, lines []string) string {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, bin, "run")
	cmd.Stdin = strings.NewReader(strings.Join(lines, "\n") + "\n")
	cmd.Env = append(os.Environ(), "OPA_TELEMETRY_ENABLED=false")
	out, err := cmd.CombinedOutput()
	if ctx.Err() != nil {
		t.Fatalf("interactive session timed out; output so far:\n%s", out)
	}
	if err != nil {
		// The prompt exits cleanly at stdin EOF; surface anything unusual but let
		// the session output remain the authoritative signal for the assertions.
		t.Logf("session process returned %v", err)
	}
	return string(out)
}

// StringList converts a value decoded from the immutable params file (a JSON
// array of strings arriving as []interface{}) into []string.
func StringList(t *testing.T, v interface{}) []string {
	t.Helper()
	raw, ok := v.([]interface{})
	if !ok {
		t.Fatalf("expected a JSON array, got %T", v)
	}
	out := make([]string, len(raw))
	for i, e := range raw {
		s, ok := e.(string)
		if !ok {
			t.Fatalf("expected a string array element, got %T", e)
		}
		out[i] = s
	}
	return out
}
