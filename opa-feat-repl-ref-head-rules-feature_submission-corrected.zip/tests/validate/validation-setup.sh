#!/usr/bin/env bash
# Validation environment setup for the interactive-prompt stories.
#
# Runs after tests/test-setup.sh has prepared the Go toolchain and before the
# story files are written. Two jobs:
#   1. Re-export the Go env the go-test driver needs (test-setup.sh already set
#      these, but exporting here keeps them defined for this stage too).
#   2. Stage the shared Go test helper (cli_repl_harness_test.go) into the
#      validation scripts directory, where the go-test driver injects any
#      sibling *.go file that declares no `func TestXxx` as a shared helper
#      next to each story file.
set -euo pipefail

# Inherit anything already set by test-setup.sh, then enforce the values the
# go-test driver needs.
export GOFLAGS="${GOFLAGS:--mod=mod}"
export CGO_ENABLED="${CGO_ENABLED:-1}"
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"
export GOPATH="${GOPATH:-/root/go}"
# Match the image's warm caches (image/Dockerfile + tests/test-setup.sh resolve
# the module and build caches at these paths when the image is built).
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"

mkdir -p "$GOCACHE" "$GOMODCACHE"

# Make `go` reachable even if the harness scrubbed PATH.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

# Belt-and-suspenders: the image already warmed the module cache, but if a fresh
# layer ever loses it we re-fetch here. Fast when warm, recoverable when cold.
# The stories build the root command and the v1/repl test binary, which
# transitively need the full root-module dependency graph.
( cd /repo/opa && { { GOFLAGS=-mod=mod GOPROXY=off go mod download >/dev/null 2>&1 && echo '[offline-first] go mod satisfied from image'; } || go mod download; } ) || true

# Stage the shared helper into the validation scripts directory. The go-test
# driver (ssb_lib/drivers/go_test_driver.py) globs *.go files in the scripts
# dir and compiles every one WITHOUT a `func TestXxx` as a shared helper next
# to each story file, so this helper compiles into `package repl_test` with
# every story.
SCRIPTS_DIR="${SCRIPTS_DIR:-/logs/verifier/validation_scripts}"
mkdir -p "$SCRIPTS_DIR"
if [ -f /tests/validate/cli_repl_harness_test.go ]; then
    cp /tests/validate/cli_repl_harness_test.go "$SCRIPTS_DIR/cli_repl_harness_test.go"
    echo "validation-setup.sh: staged cli_repl_harness_test.go into $SCRIPTS_DIR"
else
    echo "validation-setup.sh: WARNING cli_repl_harness_test.go not found in /tests/validate" >&2
fi

echo "validation-setup.sh: Go toolchain ready, root module deps cached."
