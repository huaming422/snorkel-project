// Behavioral checks for defining documents key by key and path by path at the
// Rego REPL prompt.
//
// Everything is observed through the long-standing public surface:
//
//	repl.New(store, "", &buf, "", 0, "").WithStderrWriter(&buf)
//	(*REPL).OneShot(ctx, line)
//
// and the text the REPL prints to that buffer, which is what a user sees at
// the prompt. This file lives in an external `repl_test` package and uses no
// internal helper, head field or parser flag.
package repl_test

import (
	"bytes"
	"context"
	"testing"

	"github.com/open-policy-agent/opa/v1/repl"
	"github.com/open-policy-agent/opa/v1/storage/inmem"
)

// newRepl builds a REPL over a fresh in-memory store that writes both its
// normal output and its stderr into the single buffer the checks read.
func newRepl(buf *bytes.Buffer) *repl.REPL {
	return repl.New(inmem.New(), "", buf, "", 0, "").WithStderrWriter(buf)
}

// expectExact drives one line and asserts the buffer holds exactly want.
func expectExact(t *testing.T, r *repl.REPL, buf *bytes.Buffer, line, want string) {
	t.Helper()
	buf.Reset()
	if err := r.OneShot(context.Background(), line); err != nil {
		t.Fatalf("%q: unexpected error: %v", line, err)
	}
	if got := buf.String(); got != want {
		t.Fatalf("%q: expected output %#v but got %#v", line, want, got)
	}
}

// expectDefined drives one assignment and asserts the REPL's usual
// acknowledgement for the rule ref, worded either "defined" or "re-defined".
func expectDefined(t *testing.T, r *repl.REPL, buf *bytes.Buffer, line, ref string) {
	t.Helper()
	buf.Reset()
	if err := r.OneShot(context.Background(), line); err != nil {
		t.Fatalf("%q: unexpected error: %v", line, err)
	}
	got := buf.String()
	defined := "Rule '" + ref + "' defined in package repl. Type 'show' to see rules.\n"
	redefined := "Rule '" + ref + "' re-defined in package repl. Type 'show' to see rules.\n"
	if got != defined && got != redefined {
		t.Fatalf("%q: expected output %#v (or the re-defined form) but got %#v", line, defined, got)
	}
}

// expectError drives one line and asserts it fails.
func expectError(t *testing.T, r *repl.REPL, buf *bytes.Buffer, line string) {
	t.Helper()
	buf.Reset()
	if err := r.OneShot(context.Background(), line); err == nil {
		t.Fatalf("%q: expected an error but got output: %q", line, buf.String())
	}
}

// runAll drives lines whose output the check doesn't read.
func runAll(t *testing.T, r *repl.REPL, buf *bytes.Buffer, lines ...string) {
	t.Helper()
	for _, line := range lines {
		buf.Reset()
		if err := r.OneShot(context.Background(), line); err != nil {
			t.Fatalf("%q: unexpected error: %v", line, err)
		}
	}
}

// Assigning to a numeric or string key defines a rule named by the full ref,
// and querying the name shows the single-key document.
func TestVerifyPartialObjectDefine(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)

	expectExact(t, r, &buf, `a[0] := 1`,
		"Rule 'a[0]' defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r, &buf, `a`, "{\n  \"0\": 1\n}\n")

	var buf2 bytes.Buffer
	r2 := newRepl(&buf2)
	expectExact(t, r2, &buf2, `a["foo"] := "bar"`,
		"Rule 'a.foo' defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r2, &buf2, `a`, "{\n  \"foo\": \"bar\"\n}\n")
}

// Distinct keys accumulate in one document; assigning a key again replaces
// only that key; assigning the whole name replaces the entire document.
func TestVerifyKeysAccumulateAndReplace(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)

	expectExact(t, r, &buf, `a[0] := 1`,
		"Rule 'a[0]' defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r, &buf, `a[1] := 2`,
		"Rule 'a[1]' defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r, &buf, `a`, "{\n  \"0\": 1,\n  \"1\": 2\n}\n")

	expectDefined(t, r, &buf, `a[0] := 3`, "a[0]")
	expectExact(t, r, &buf, `a`, "{\n  \"0\": 3,\n  \"1\": 2\n}\n")

	expectDefined(t, r, &buf, `a := 2`, "a")
	expectExact(t, r, &buf, `a`, "2\n")
}

// Assigning to a path that already holds keys replaces everything stored
// under that path and leaves its siblings alone.
func TestVerifyPathAssignReplacesBelow(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)

	runAll(t, r, &buf, `p.q.r := 1`, `p.x := 3`)
	expectDefined(t, r, &buf, `p.q := {"s": 2}`, "p.q")
	expectExact(t, r, &buf, `p`, "{\n  \"q\": {\n    \"s\": 2\n  },\n  \"x\": 3\n}\n")
}

// Dotted paths build a nested document; sibling paths accumulate under the
// shared prefix.
func TestVerifyDottedRefDefine(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)

	expectExact(t, r, &buf, `p.q.r := 1`,
		"Rule 'p.q.r' defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r, &buf, `p.q.s := 2`,
		"Rule 'p.q.s' defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r, &buf, `p`, "{\n  \"q\": {\n    \"r\": 1,\n    \"s\": 2\n  }\n}\n")
}

// Statements rooted at data or input stay queries: they evaluate (to
// undefined here) and leave the module with no rules.
func TestVerifyDataInputStayQueries(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)
	expectExact(t, r, &buf, `data.foo.bar = 1`, "undefined\n")
	expectExact(t, r, &buf, `show`, "no rules defined\n")

	var buf2 bytes.Buffer
	r2 := newRepl(&buf2)
	expectExact(t, r2, &buf2, `input.foo.bar = 1`, "undefined\n")
	expectExact(t, r2, &buf2, `show`, "no rules defined\n")
}

// An equality statement about a key or path that's already defined is a
// query: it reports truth, undefinedness, or the matching keys, and the module
// still holds only the original definition afterwards.
func TestVerifyEqAboutDefinedIsQuery(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)

	expectExact(t, r, &buf, `p.q.r := 1`,
		"Rule 'p.q.r' defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r, &buf, `p.q.r = 1`, "true\n")
	expectExact(t, r, &buf, `p.q.r = 2`, "undefined\n")
	expectExact(t, r, &buf, `p.q[i] = 1`,
		"┌─────┐\n│  i  │\n├─────┤\n│ \"r\" │\n└─────┘\n")
	expectExact(t, r, &buf, `p.q.r`, "1\n")
	expectExact(t, r, &buf, `show`, "package repl\n\np.q.r := 1\n")

	var buf2 bytes.Buffer
	r2 := newRepl(&buf2)
	expectExact(t, r2, &buf2, `a[0] := 1`,
		"Rule 'a[0]' defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r2, &buf2, `a[0] = 1`, "true\n")
	expectExact(t, r2, &buf2, `a[0] = 2`, "undefined\n")
	expectExact(t, r2, &buf2, `a[k] = 1`, "┌───┐\n│ k │\n├───┤\n│ 0 │\n└───┘\n")
	expectExact(t, r2, &buf2, `a`, "{\n  \"0\": 1\n}\n")
}

// A document assigned in one go answers equality statements about its keys
// and paths as queries, and the module keeps the one rule.
func TestVerifyEqAboutWholeDocIsQuery(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)

	runAll(t, r, &buf, `a := {"r": 1}`)
	expectExact(t, r, &buf, `a.r = 1`, "true\n")
	expectExact(t, r, &buf, `a.r = 2`, "undefined\n")
	expectExact(t, r, &buf, `a[k] = 1`,
		"┌─────┐\n│  k  │\n├─────┤\n│ \"r\" │\n└─────┘\n")
	expectExact(t, r, &buf, `show`, "package repl\n\na := {\"r\": 1}\n")

	var buf2 bytes.Buffer
	r2 := newRepl(&buf2)
	runAll(t, r2, &buf2, `p := {"q": {"r": 1}}`)
	expectExact(t, r2, &buf2, `p.q.r = 1`, "true\n")
	expectExact(t, r2, &buf2, `p.q[k] = 1`,
		"┌─────┐\n│  k  │\n├─────┤\n│ \"r\" │\n└─────┘\n")
}

// An assignment whose key is an unbound variable is unsafe: it errors.
func TestVerifyUnsafeKeyRejected(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)
	expectError(t, r, &buf, `a[i] := 1`)
}

// unset takes a ref: a key leaves the other keys, the name removes every key,
// a dotted path removes that rule, and an already removed ref warns. After an
// unset whose selector holds a variable, the key defined before it is still
// there.
func TestVerifyUnsetByRef(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)

	runAll(t, r, &buf, `a[0] := 1`, `a[1] := 2`, `foo.bar.baz if true`)

	runAll(t, r, &buf, `unset a[0]`)
	expectExact(t, r, &buf, `a`, "{\n  \"1\": 2\n}\n")

	runAll(t, r, &buf, `unset a`, `unset foo.bar.baz`)
	expectExact(t, r, &buf, `show`, "package repl\n")

	expectExact(t, r, &buf, `unset foo.bar.baz`,
		"warning: no matching rules in current module\n")

	expectExact(t, r, &buf, `a[0] := 1`,
		"Rule 'a[0]' defined in package repl. Type 'show' to see rules.\n")
	buf.Reset()
	_ = r.OneShot(context.Background(), `unset a[x]`)
	expectExact(t, r, &buf, `a`, "{\n  \"0\": 1\n}\n")
}

// unset with a path that sits above defined keys removes every key under it
// and keeps the siblings.
func TestVerifyUnsetPathRemovesBelow(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)

	runAll(t, r, &buf, `p.q.r := 1`, `p.q.s := 2`, `p.x := 3`, `unset p.q`)
	expectExact(t, r, &buf, `p`, "{\n  \"x\": 3\n}\n")
}
