// Behavioral checks for defining documents key by key and path by path at the
// Rego REPL prompt.
//
// Everything is observed through the long-standing public surface:
//
//	repl.New(store, "", &buf, "", 0, "").WithStderrWriter(&buf)
//	(*REPL).OneShot(ctx, line)
//
// and the text the REPL prints to that buffer, which is what a user sees at
// the prompt. This file lives in an external `repl_test` package and uses no
// internal helper, head field or parser flag.
package repl_test

import (
	"bytes"
	"context"
	"testing"

	"github.com/open-policy-agent/opa/v1/repl"
	"github.com/open-policy-agent/opa/v1/storage/inmem"
)

// newRepl builds a REPL over a fresh in-memory store that writes both its
// normal output and its stderr into the single buffer the checks read.
func newRepl(buf *bytes.Buffer) *repl.REPL {
	return repl.New(inmem.New(), "", buf, "", 0, "").WithStderrWriter(buf)
}

// expectExact drives one line and asserts the buffer holds exactly want.
func expectExact(t *testing.T, r *repl.REPL, buf *bytes.Buffer, line, want string) {
	t.Helper()
	buf.Reset()
	if err := r.OneShot(context.Background(), line); err != nil {
		t.Fatalf("%q: unexpected error: %v", line, err)
	}
	if got := buf.String(); got != want {
		t.Fatalf("%q: expected output %#v but got %#v", line, want, got)
	}
}

// expectDefined drives one assignment and asserts the REPL's usual
// acknowledgement for the rule ref, worded either "defined" or "re-defined".
func expectDefined(t *testing.T, r *repl.REPL, buf *bytes.Buffer, line, ref string) {
	t.Helper()
	buf.Reset()
	if err := r.OneShot(context.Background(), line); err != nil {
		t.Fatalf("%q: unexpected error: %v", line, err)
	}
	got := buf.String()
	defined := "Rule '" + ref + "' defined in package repl. Type 'show' to see rules.\n"
	redefined := "Rule '" + ref + "' re-defined in package repl. Type 'show' to see rules.\n"
	if got != defined && got != redefined {
		t.Fatalf("%q: expected output %#v (or the re-defined form) but got %#v", line, defined, got)
	}
}

// expectNoRules reads `show` on a module that holds no rule. Whether the module
// exists yet decides which of the REPL's two texts it prints.
func expectNoRules(t *testing.T, r *repl.REPL, buf *bytes.Buffer) {
	t.Helper()
	buf.Reset()
	if err := r.OneShot(context.Background(), `show`); err != nil {
		t.Fatalf("show: unexpected error: %v", err)
	}
	if got := buf.String(); got != "no rules defined\n" && got != "package repl\n" {
		t.Fatalf("show: expected a module with no rules but got %#v", got)
	}
}

// expectError drives one line and asserts it fails.
func expectError(t *testing.T, r *repl.REPL, buf *bytes.Buffer, line string) {
	t.Helper()
	buf.Reset()
	if err := r.OneShot(context.Background(), line); err == nil {
		t.Fatalf("%q: expected an error but got output: %q", line, buf.String())
	}
}

// runAll drives lines whose output the check doesn't read.
func runAll(t *testing.T, r *repl.REPL, buf *bytes.Buffer, lines ...string) {
	t.Helper()
	for _, line := range lines {
		buf.Reset()
		if err := r.OneShot(context.Background(), line); err != nil {
			t.Fatalf("%q: unexpected error: %v", line, err)
		}
	}
}

// documentShapes lists the ways a line can build a document under one name.
var documentShapes = []struct {
	name  string
	lines []string
}{
	{"a", []string{`a[0] := 1`, `a[1] := 2`}},
	{"a", []string{`a["x"] := 1`, `a["y"] := 2`}},
	{"p", []string{`p.q := 1`, `p.x := 2`}},
	{"p", []string{`p.q.r := 1`, `p.q.s := 2`}},
	{"p", []string{`p["q"]["r"] := 1`, `p.x.y.z := 2`}},
	{"foo", []string{`foo.bar.baz if true`}},
	{"team", []string{`team.admins contains "ana"`, `team.devs contains "ben"`}},
}

// Assigning to a numeric or string key defines a rule named by the full ref,
// and querying the name shows the single-key document.
func TestVerifyPartialObjectDefine(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)

	expectExact(t, r, &buf, `a[0] := 1`,
		"Rule 'a[0]' defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r, &buf, `a`, "{\n  \"0\": 1\n}\n")

	var buf2 bytes.Buffer
	r2 := newRepl(&buf2)
	expectExact(t, r2, &buf2, `a["foo"] := "bar"`,
		"Rule 'a.foo' defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r2, &buf2, `a`, "{\n  \"foo\": \"bar\"\n}\n")
}

// Distinct keys accumulate in one document; assigning a key again replaces
// only that key; assigning the whole name replaces the entire document.
func TestVerifyKeysAccumulateAndReplace(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)

	expectExact(t, r, &buf, `a[0] := 1`,
		"Rule 'a[0]' defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r, &buf, `a[1] := 2`,
		"Rule 'a[1]' defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r, &buf, `a`, "{\n  \"0\": 1,\n  \"1\": 2\n}\n")

	expectDefined(t, r, &buf, `a[0] := 3`, "a[0]")
	expectExact(t, r, &buf, `a`, "{\n  \"0\": 3,\n  \"1\": 2\n}\n")

	expectDefined(t, r, &buf, `a := 2`, "a")
	expectExact(t, r, &buf, `a`, "2\n")
}

// Assigning to a path that already holds keys replaces everything stored
// under that path and leaves its siblings alone.
func TestVerifyPathAssignReplacesBelow(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)

	runAll(t, r, &buf, `p.q.r := 1`, `p.x := 3`)
	expectDefined(t, r, &buf, `p.q := {"s": 2}`, "p.q")
	expectExact(t, r, &buf, `p`, "{\n  \"q\": {\n    \"s\": 2\n  },\n  \"x\": 3\n}\n")
}

// Assigning the bare name replaces the whole document, however it was built.
func TestVerifyBareNameAssignReplaces(t *testing.T) {
	for _, shape := range documentShapes {
		var buf bytes.Buffer
		r := newRepl(&buf)

		runAll(t, r, &buf, shape.lines...)
		expectDefined(t, r, &buf, shape.name+` := 5`, shape.name)
		expectExact(t, r, &buf, shape.name, "5\n")
		expectExact(t, r, &buf, `show`, "package repl\n\n"+shape.name+" := 5\n")
	}
}

// Dotted paths build a nested document; sibling paths accumulate under the
// shared prefix, and assigning a path again replaces only that path.
func TestVerifyDottedRefDefine(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)

	expectExact(t, r, &buf, `p.q.r := 1`,
		"Rule 'p.q.r' defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r, &buf, `p.q.s := 2`,
		"Rule 'p.q.s' defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r, &buf, `p`, "{\n  \"q\": {\n    \"r\": 1,\n    \"s\": 2\n  }\n}\n")

	expectDefined(t, r, &buf, `p.q.r := 5`, "p.q.r")
	expectExact(t, r, &buf, `p`, "{\n  \"q\": {\n    \"r\": 5,\n    \"s\": 2\n  }\n}\n")

	var buf2 bytes.Buffer
	r2 := newRepl(&buf2)
	runAll(t, r2, &buf2, `m.x := 1`, `m.y := 2`)
	expectExact(t, r2, &buf2, `m`, "{\n  \"x\": 1,\n  \"y\": 2\n}\n")
}

// Statements rooted at data or input stay queries: they evaluate (to
// undefined here) and leave the module with no rules.
func TestVerifyDataInputStayQueries(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)
	expectExact(t, r, &buf, `data.foo.bar = 1`, "undefined\n")
	expectNoRules(t, r, &buf)

	var buf2 bytes.Buffer
	r2 := newRepl(&buf2)
	expectExact(t, r2, &buf2, `input.foo.bar = 1`, "undefined\n")
	expectNoRules(t, r2, &buf2)
}

// An equality statement about a key or path that was itself assigned is a
// query: it reports truth, undefinedness, or the matching keys, and the module
// still holds only the original definition afterwards.
func TestVerifyEqAboutDefinedIsQuery(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)

	expectExact(t, r, &buf, `p.q.r := 1`,
		"Rule 'p.q.r' defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r, &buf, `p.q.r = 1`, "true\n")
	expectExact(t, r, &buf, `p.q.r = 2`, "undefined\n")
	expectExact(t, r, &buf, `p.q[i] = 1`,
		"┌─────┐\n│  i  │\n├─────┤\n│ \"r\" │\n└─────┘\n")
	expectExact(t, r, &buf, `p.q.r`, "1\n")
	expectExact(t, r, &buf, `show`, "package repl\n\np.q.r := 1\n")

	var buf2 bytes.Buffer
	r2 := newRepl(&buf2)
	expectExact(t, r2, &buf2, `a[0] := 1`,
		"Rule 'a[0]' defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r2, &buf2, `a[0] = 1`, "true\n")
	expectExact(t, r2, &buf2, `a[0] = 2`, "undefined\n")
	expectExact(t, r2, &buf2, `a[k] = 1`, "┌───┐\n│ k │\n├───┤\n│ 0 │\n└───┘\n")
	expectExact(t, r2, &buf2, `a`, "{\n  \"0\": 1\n}\n")

	var buf3 bytes.Buffer
	r3 := newRepl(&buf3)
	runAll(t, r3, &buf3, `b["x"] := "y"`)
	expectExact(t, r3, &buf3, `b["x"] = "y"`, "true\n")
	expectExact(t, r3, &buf3, `b.x = "z"`, "undefined\n")
	expectExact(t, r3, &buf3, `b[k] = "y"`,
		"┌─────┐\n│  k  │\n├─────┤\n│ \"x\" │\n└─────┘\n")

	var buf4 bytes.Buffer
	r4 := newRepl(&buf4)
	runAll(t, r4, &buf4, `m.x := 1`)
	expectExact(t, r4, &buf4, `m.x = 1`, "true\n")
	expectExact(t, r4, &buf4, `m.x = 2`, "undefined\n")
	expectExact(t, r4, &buf4, `m[k] = 1`,
		"┌─────┐\n│  k  │\n├─────┤\n│ \"x\" │\n└─────┘\n")
	expectExact(t, r4, &buf4, `m`, "{\n  \"x\": 1\n}\n")
}

// A document assigned in one go answers equality statements about its keys
// and paths as queries, and the module keeps the one rule.
func TestVerifyEqAboutWholeDocIsQuery(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)

	runAll(t, r, &buf, `a := {"r": 1}`)
	expectExact(t, r, &buf, `a.r = 1`, "true\n")
	expectExact(t, r, &buf, `a.r = 2`, "undefined\n")
	expectExact(t, r, &buf, `a[k] = 1`,
		"┌─────┐\n│  k  │\n├─────┤\n│ \"r\" │\n└─────┘\n")
	expectExact(t, r, &buf, `show`, "package repl\n\na := {\"r\": 1}\n")

	var buf2 bytes.Buffer
	r2 := newRepl(&buf2)
	runAll(t, r2, &buf2, `p := {"q": {"r": 1}}`)
	expectExact(t, r2, &buf2, `p.q.r = 1`, "true\n")
	expectExact(t, r2, &buf2, `p.q[k] = 1`,
		"┌─────┐\n│  k  │\n├─────┤\n│ \"r\" │\n└─────┘\n")
}

// An assignment whose key is an unbound variable is unsafe: it errors.
func TestVerifyUnsafeKeyRejected(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)
	expectError(t, r, &buf, `a[i] := 1`)
}

// unset takes a ref: a key leaves the other keys, the name removes every key,
// and a dotted path removes that rule. A second unset of the same ref changes
// nothing.
func TestVerifyUnsetByRef(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)

	runAll(t, r, &buf, `a[0] := 1`, `a[1] := 2`, `foo.bar.baz if true`)

	runAll(t, r, &buf, `unset a[0]`)
	expectExact(t, r, &buf, `a`, "{\n  \"1\": 2\n}\n")

	runAll(t, r, &buf, `unset a`, `unset foo.bar.baz`)
	expectExact(t, r, &buf, `show`, "package repl\n")

	buf.Reset()
	_ = r.OneShot(context.Background(), `unset foo.bar.baz`)
	expectExact(t, r, &buf, `show`, "package repl\n")
}

// unset with the bare name removes the whole document, however it was built.
func TestVerifyBareNameUnsetRemoves(t *testing.T) {
	for _, shape := range documentShapes {
		var buf bytes.Buffer
		r := newRepl(&buf)

		runAll(t, r, &buf, shape.lines...)
		runAll(t, r, &buf, `unset `+shape.name)
		expectExact(t, r, &buf, `show`, "package repl\n")
		expectError(t, r, &buf, shape.name)
	}
}

// unset with a path that sits above defined keys removes every key under it
// and keeps the siblings, for assignments and contains lines alike.
func TestVerifyUnsetPathRemovesBelow(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)

	runAll(t, r, &buf, `p.q.r := 1`, `p.q.s := 2`, `p.x := 3`, `p.qq := 4`, `unset p.q`)
	expectExact(t, r, &buf, `p`, "{\n  \"qq\": 4,\n  \"x\": 3\n}\n")

	var buf2 bytes.Buffer
	r2 := newRepl(&buf2)
	runAll(t, r2, &buf2, `team.admins contains "ana"`, `team.admins contains "ben"`,
		`team.devs contains "cy"`, `unset team.admins`)
	expectExact(t, r2, &buf2, `team`, "{\n  \"devs\": [\n    \"cy\"\n  ]\n}\n")
}

// unset with a variable in its selector removes nothing, after a key and after
// a dotted path.
func TestVerifyUnsetVariableRemovesNothing(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)

	runAll(t, r, &buf, `a[0] := 1`, `p.q.r := 2`)

	buf.Reset()
	_ = r.OneShot(context.Background(), `unset a[x]`)
	expectExact(t, r, &buf, `a`, "{\n  \"0\": 1\n}\n")

	buf.Reset()
	_ = r.OneShot(context.Background(), `unset p.q[k]`)
	expectExact(t, r, &buf, `p`, "{\n  \"q\": {\n    \"r\": 2\n  }\n}\n")
}
