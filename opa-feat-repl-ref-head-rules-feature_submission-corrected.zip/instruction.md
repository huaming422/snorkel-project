## Task

Typing `x := 1` at the `opa run` prompt defines `x`. A line that assigns to one
key, or to a path like `limits.cpu.max`, doesn't: `team["ana"] := "admin"` fails
with `rego_compile_error: cannot assign to ref`, nothing is kept, and typing
`team` afterwards gives `rego_unsafe_var_error: var team is unsafe`. In a
`.rego` file the same line is a normal rule.

Make the prompt take those assignments, so we can put a document together piece
by piece, with `unset` to match. Lines that start with `input` or `data`, like
`data.users.ana = "admin"`, look up what's stored, and they have to stay queries.

## User stories / requirements

- At the `opa run` prompt, assigning keys or dotted paths one at a time (`team["ana"] := "admin"`, `team["ben"] := "dev"`, `limits.cpu.max := 4`) builds one document, and typing its name prints all of it. Assigning a key again swaps just that key; assigning a name or path swaps out everything stored under it.
- `unset` with a key or dotted path (`unset team["ben"]`, `unset limits.cpu`) removes everything defined at or below it and keeps the rest; a ref inside a definition higher up isn't covered. With only the name it drops the whole document, however it was built. A selector holding a variable (`unset team[k]`) removes nothing.
- An `=` line about a key or path that was itself assigned is a question: after `limits.cpu.max := 4`, `limits.cpu.max = 5` prints undefined and keeps 4, and `limits.cpu[k] = 4` lists `max`. So are lines about keys of a value assigned whole. `limits.cpu = ...` isn't covered, since nothing assigned it.
