## Task

we're getting reports of a cross-customer data leak. an internal service account that calls the gateway on one customer's behalf can read another customer's run data: a service acting for customer A can pull customer B's run list, an individual run, and everything hanging off that run. that covers the messages, the events, the workspace changes, the live stream and cancel, and the saved-artifact download. thread token-usage totals bleed across customers the same way.

it only shows up on older, shared threads. a normal signed-in browser session or API session is unaffected, so the per-owner boundary is holding in the common case; it's these threads where a caller acting for one customer ends up seeing another customer's data.

the internal reads that are supposed to work still need to work, so closing this can't come at the cost of those legitimate reads. figure out why the per-owner boundary isn't being enforced on those threads and close it.
