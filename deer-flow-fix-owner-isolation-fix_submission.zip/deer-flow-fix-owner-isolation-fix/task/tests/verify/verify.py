"""Behavioral coverage for the gateway thread-runs owner-boundary.

Every assertion is driven THROUGH the pre-existing
``app.gateway.routers.thread_runs.router`` HTTP surface (prefix
``/api/threads``) with FastAPI's ``TestClient`` over the harness's in-memory
stores. Nothing here imports the fix's helpers or pins its internal shape: a
correct solution is free to decompose the ownership check, the sub-resource
gate, and the token-usage scoping however it likes, and to rename any private
identifier, as long as the per-endpoint observable outcomes below hold.

The scaffolding (middleware that stamps the auth trio, the real in-memory
thread-meta store standing behind ``owner_check=True``, the recording run
store, the seed helpers) mirrors the repo's own regression harness for this
router, reconstructed here so the verifier is independent of the suite shipped
alongside the change.
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock
from uuid import UUID

import pytest

# ---------------------------------------------------------------------------
# Import bootstrap. This file lives outside ``backend/tests`` so the backend
# conftest does not apply; replicate just the two things it does that matter
# here: put ``app`` / ``deerflow`` on sys.path, and pre-mock the
# ``deerflow.subagents.executor`` module to break a production circular import
# that would otherwise trip when importing the router in isolation.
# ---------------------------------------------------------------------------
_BACKEND = Path("/repo/deer-flow/backend")
if str(_BACKEND) not in sys.path:
    sys.path.insert(0, str(_BACKEND))

if "deerflow.subagents.executor" not in sys.modules:
    _executor_mock = MagicMock()
    _executor_mock.SubagentExecutor = MagicMock
    _executor_mock.SubagentResult = MagicMock
    _executor_mock.SubagentStatus = MagicMock
    _executor_mock.MAX_CONCURRENT_SUBAGENTS = 3
    _executor_mock.get_background_task_result = MagicMock()
    sys.modules["deerflow.subagents.executor"] = _executor_mock

from fastapi import FastAPI, Request, Response  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402
from langgraph.store.memory import InMemoryStore  # noqa: E402
from starlette.middleware.base import BaseHTTPMiddleware  # noqa: E402

from app.gateway.auth.models import User  # noqa: E402
from app.gateway.auth_disabled import (  # noqa: E402
    AUTH_SOURCE_INTERNAL,
    AUTH_SOURCE_SESSION,
)
from app.gateway.authz import AuthContext, Permissions  # noqa: E402
from app.gateway.internal_auth import (  # noqa: E402
    INTERNAL_OWNER_USER_ID_HEADER_NAME,
    get_internal_user,
)
from app.gateway.routers import thread_runs  # noqa: E402
from deerflow.persistence.thread_meta.memory import MemoryThreadMetaStore  # noqa: E402
from deerflow.runtime.events.store.memory import MemoryRunEventStore  # noqa: E402
from deerflow.runtime.runs.manager import RunManager  # noqa: E402
from deerflow.runtime.runs.store.memory import MemoryRunStore  # noqa: E402

# --- stable fixture constants (not solution-chosen; see provenance) ---------
THREAD_ID = "thread-scope"
# A raw trusted-owner value whose make_safe_user_id-normalized form can never
# equal the raw value start_run stamps on a run row (the #5437 mismatch class).
OWNER_RAW = "feishu:owner-777"
STRANGER_RAW = "feishu:owner-999"
BROWSER_USER_ID = UUID("00000000-0000-0000-0000-00000000000a")

_STUB_PERMISSIONS = [
    Permissions.THREADS_READ,
    Permissions.RUNS_READ,
    Permissions.RUNS_CANCEL,
]


class _ScopeAuthMiddleware(BaseHTTPMiddleware):
    """Stamp the same request.state trio the production AuthMiddleware stamps."""

    def __init__(self, app, *, user, auth_source: str) -> None:
        super().__init__(app)
        self._user = user
        self._auth_source = auth_source

    async def dispatch(self, request: Request, call_next) -> Response:
        request.state.user = self._user
        request.state.auth_source = self._auth_source
        request.state.auth = AuthContext(
            user=self._user, permissions=list(_STUB_PERMISSIONS)
        )
        return await call_next(request)


def _browser_user() -> User:
    return User(
        id=BROWSER_USER_ID,
        email="scope-test@example.com",
        password_hash="x",
        system_role="user",
    )


def _internal_user(owner_raw: str | None):
    # Mirrors AuthMiddleware + get_internal_user: a synthetic internal user
    # carrying the safe-spelled owner id ("default" without an owner header).
    return get_internal_user(owner_user_id=owner_raw)


def _seed_run(
    store: MemoryRunStore, run_id: str, *, user_id: str | None, status: str = "success"
) -> None:
    asyncio.run(store.put(run_id, thread_id=THREAD_ID, user_id=user_id, status=status))


def _set_run_tokens(store: MemoryRunStore, run_id: str, total: int) -> None:
    # Token totals live on the stored run snapshot; the in-memory aggregate
    # reads token_usage_by_model (with a total_tokens fallback).
    store._runs[run_id]["token_usage_by_model"] = {"model-x": {"total_tokens": total}}
    store._runs[run_id]["total_tokens"] = total


def _seed_message(
    event_store: MemoryRunEventStore, run_id: str, message_id: str
) -> None:
    asyncio.run(
        event_store.put(
            thread_id=THREAD_ID,
            run_id=run_id,
            event_type="llm.ai.response",
            category="message",
            content={
                "type": "ai",
                "id": message_id,
                "content": message_id,
                "additional_kwargs": {},
            },
            metadata={},
        )
    )


def _missing_meta_store() -> MemoryThreadMetaStore:
    """A real meta store with NO row for THREAD_ID (legacy / shared thread)."""
    return MemoryThreadMetaStore(InMemoryStore())


def _null_owner_meta_store() -> MemoryThreadMetaStore:
    """A real meta store whose THREAD_ID row exists with a NULL owner."""
    store = MemoryThreadMetaStore(InMemoryStore())
    asyncio.run(store.create(THREAD_ID, assistant_id=None, user_id=None))
    return store


def _established_meta_store(owner: str) -> MemoryThreadMetaStore:
    """A real meta store whose THREAD_ID row has a concrete owner."""
    store = MemoryThreadMetaStore(InMemoryStore())
    asyncio.run(store.create(THREAD_ID, assistant_id=None, user_id=owner))
    return store


def _make_app(
    *,
    user,
    auth_source: str,
    run_store: MemoryRunStore,
    thread_store: MemoryThreadMetaStore,
    event_store: MemoryRunEventStore | None = None,
) -> TestClient:
    app = FastAPI()
    app.add_middleware(_ScopeAuthMiddleware, user=user, auth_source=auth_source)
    app.state.thread_store = thread_store
    app.state.run_store = run_store
    app.state.run_manager = RunManager(store=run_store)
    if event_store is not None:
        app.state.run_event_store = event_store
    app.include_router(thread_runs.router)
    return TestClient(app)


def _owner_headers() -> dict[str, str]:
    return {INTERNAL_OWNER_USER_ID_HEADER_NAME: OWNER_RAW}


def _stranger_headers() -> dict[str, str]:
    return {INTERNAL_OWNER_USER_ID_HEADER_NAME: STRANGER_RAW}


# ===========================================================================
# Criterion 1 (fail_to_pass): missing-meta thread isolates the internal caller
# ===========================================================================
def test_missing_meta_thread_isolates_internal_caller() -> None:
    run_store = MemoryRunStore()
    _seed_run(run_store, "run-other", user_id=str(BROWSER_USER_ID), status="success")
    client = _make_app(
        user=_internal_user(OWNER_RAW),
        auth_source=AUTH_SOURCE_INTERNAL,
        run_store=run_store,
        thread_store=_missing_meta_store(),
    )
    with client:
        listed = client.get(f"/api/threads/{THREAD_ID}/runs", headers=_owner_headers())
        page = client.get(
            f"/api/threads/{THREAD_ID}/runs/page", headers=_owner_headers()
        )
        single = client.get(
            f"/api/threads/{THREAD_ID}/runs/run-other", headers=_owner_headers()
        )

    assert listed.status_code == 200
    assert listed.json() == []
    assert page.status_code == 200
    assert page.json()["data"] == []
    assert single.status_code == 404


def test_missing_meta_ownerless_caller_default_filter() -> None:
    # Without an owner header the caller's data identity is the synthetic
    # "default"; another owner's raw-stamped run stays hidden.
    run_store = MemoryRunStore()
    _seed_run(run_store, "run-owner", user_id=OWNER_RAW, status="success")
    client = _make_app(
        user=_internal_user(None),
        auth_source=AUTH_SOURCE_INTERNAL,
        run_store=run_store,
        thread_store=_missing_meta_store(),
    )
    with client:
        listed = client.get(f"/api/threads/{THREAD_ID}/runs")

    assert listed.status_code == 200
    assert listed.json() == []


# ===========================================================================
# Criterion 2 (fail_to_pass): NULL-owner meta row isolates the internal caller
# ===========================================================================
def test_null_owner_thread_isolates_internal_caller() -> None:
    run_store = MemoryRunStore()
    _seed_run(run_store, "run-other", user_id=str(BROWSER_USER_ID), status="success")
    client = _make_app(
        user=_internal_user(OWNER_RAW),
        auth_source=AUTH_SOURCE_INTERNAL,
        run_store=run_store,
        thread_store=_null_owner_meta_store(),
    )
    with client:
        listed = client.get(f"/api/threads/{THREAD_ID}/runs", headers=_owner_headers())
        single = client.get(
            f"/api/threads/{THREAD_ID}/runs/run-other", headers=_owner_headers()
        )

    assert listed.status_code == 200
    assert listed.json() == []
    assert single.status_code == 404


# ===========================================================================
# Criterion 3 (fail_to_pass): the acting owner's OWN raw-stamped run stays
# visible on a non-established thread (the isolation must not over-filter).
# ===========================================================================
def test_acting_owner_own_runs_stay_visible() -> None:
    run_store = MemoryRunStore()
    _seed_run(run_store, "run-own", user_id=OWNER_RAW, status="success")
    client = _make_app(
        user=_internal_user(OWNER_RAW),
        auth_source=AUTH_SOURCE_INTERNAL,
        run_store=run_store,
        thread_store=_missing_meta_store(),
    )
    with client:
        listed = client.get(f"/api/threads/{THREAD_ID}/runs", headers=_owner_headers())
        single = client.get(
            f"/api/threads/{THREAD_ID}/runs/run-own", headers=_owner_headers()
        )

    assert listed.status_code == 200
    assert {row["run_id"] for row in listed.json()} == {"run-own"}
    assert single.status_code == 200
    assert single.json()["run_id"] == "run-own"


# ===========================================================================
# Criterion 4 (fail_to_pass): run-scoped sub-resources respect the owner stamp
# ===========================================================================
def test_run_subresources_isolated_for_stranger_internal_caller() -> None:
    # A NULL-owner meta row keeps every sub-resource endpoint reachable: the
    # cancel and artifact-archive routes carry an existence requirement in
    # their permission gate, which a truly meta-less thread fails before the
    # scope guard is ever consulted. A shared (NULL-owner) row is authorized
    # by that gate, so the scope decision — not the existence gate — is what
    # the stranger's 404s exercise here.
    thread_store = _null_owner_meta_store()
    run_store = MemoryRunStore()
    _seed_run(run_store, "run-owner", user_id=OWNER_RAW, status="success")
    event_store = MemoryRunEventStore()
    _seed_message(event_store, "run-owner", "msg-owner")
    base = f"/api/threads/{THREAD_ID}/runs/run-owner"

    stranger = _make_app(
        user=_internal_user(STRANGER_RAW),
        auth_source=AUTH_SOURCE_INTERNAL,
        run_store=run_store,
        thread_store=thread_store,
        event_store=event_store,
    )
    with stranger:
        h = _stranger_headers()
        assert stranger.get(base + "/messages", headers=h).status_code == 404
        assert stranger.get(base + "/events", headers=h).status_code == 404
        assert stranger.get(base + "/workspace-changes", headers=h).status_code == 404
        assert stranger.get(base + "/join", headers=h).status_code == 404
        # The live-stream routes (observation-only GET join and the POST
        # interrupt-then-stream) are run-scoped sub-resources too: the stranger
        # must be refused there exactly as on the other sub-resources, or the
        # live run stream leaks cross-owner. (A GET /stream carrying ?action is
        # rejected 405 by a separate method guard before the scope check, so the
        # isolation is exercised through the action-less GET and the POST.)
        assert stranger.get(base + "/stream", headers=h).status_code == 404
        assert (
            stranger.post(
                base + "/stream?action=interrupt", headers=h
            ).status_code
            == 404
        )
        assert (
            stranger.post(
                base + "/cancel?action=interrupt", headers=h
            ).status_code
            == 404
        )
        assert stranger.get(base + "/artifacts/archive", headers=h).status_code == 404
        assert stranger.post(base + "/artifacts/archive", headers=h).status_code == 404


def test_run_subresources_visible_to_acting_owner() -> None:
    thread_store = _null_owner_meta_store()
    run_store = MemoryRunStore()
    _seed_run(run_store, "run-owner", user_id=OWNER_RAW, status="success")
    event_store = MemoryRunEventStore()
    _seed_message(event_store, "run-owner", "msg-owner")
    base = f"/api/threads/{THREAD_ID}/runs/run-owner"

    owner = _make_app(
        user=_internal_user(OWNER_RAW),
        auth_source=AUTH_SOURCE_INTERNAL,
        run_store=run_store,
        thread_store=thread_store,
        event_store=event_store,
    )
    with owner:
        h = _owner_headers()
        messages = owner.get(base + "/messages", headers=h)
        events = owner.get(base + "/events", headers=h)
        workspace = owner.get(base + "/workspace-changes", headers=h)
        manifest = owner.get(base + "/artifacts/archive", headers=h)
        # The acting owner is let through the per-owner boundary on the live
        # stream routes and reaches the endpoint's own logic: with no stream
        # bridge wired on this harness app, that logic answers 503 (bridge
        # unavailable), never the stranger's 404. Asserting "not 404" is the
        # proof the boundary admitted the owner on both stream verbs.
        stream_get = owner.get(base + "/stream", headers=h)
        stream_post = owner.post(base + "/stream?action=interrupt", headers=h)
        # A terminal (success) run cannot be cancelled again: the acting owner
        # reaches the real 409 conflict path, not a 404 anti-enumeration answer.
        cancel = owner.post(base + "/cancel?action=interrupt", headers=h)

    assert messages.status_code == 200
    assert [row["content"]["id"] for row in messages.json()["data"]] == ["msg-owner"]
    assert events.status_code == 200
    assert workspace.status_code == 200
    # The acting owner is not blocked by the per-owner boundary on the archive
    # route either: the request reaches the endpoint's own business logic, which
    # answers 409 for a run carrying no recorded artifact delivery. The 409 (vs
    # the stranger's 404 on the same route) is the proof the boundary let the
    # owner through — the endpoint, not the boundary, decided the outcome.
    assert manifest.status_code == 409
    assert stream_get.status_code != 404
    assert stream_post.status_code != 404
    assert cancel.status_code == 409


# ===========================================================================
# Criterion 5 (fail_to_pass): thread token-usage is isolated on non-established
# threads — for internal callers AND browser sessions.
# ===========================================================================
def test_token_usage_isolated_for_internal_caller_without_meta() -> None:
    run_store = MemoryRunStore()
    _seed_run(run_store, "run-owner", user_id=OWNER_RAW, status="success")
    _seed_run(run_store, "run-other", user_id=str(BROWSER_USER_ID), status="success")
    _set_run_tokens(run_store, "run-owner", 111)
    _set_run_tokens(run_store, "run-other", 999)
    client = _make_app(
        user=_internal_user(OWNER_RAW),
        auth_source=AUTH_SOURCE_INTERNAL,
        run_store=run_store,
        thread_store=_missing_meta_store(),
    )
    with client:
        resp = client.get(
            f"/api/threads/{THREAD_ID}/token-usage", headers=_owner_headers()
        )

    assert resp.status_code == 200
    body = resp.json()
    assert body["total_tokens"] == 111
    assert body["total_runs"] == 1


def test_token_usage_isolated_for_browser_session_without_meta() -> None:
    run_store = MemoryRunStore()
    _seed_run(run_store, "run-owner", user_id=OWNER_RAW, status="success")
    _seed_run(
        run_store, "run-browser", user_id=str(BROWSER_USER_ID), status="success"
    )
    _set_run_tokens(run_store, "run-owner", 111)
    _set_run_tokens(run_store, "run-browser", 222)
    client = _make_app(
        user=_browser_user(),
        auth_source=AUTH_SOURCE_SESSION,
        run_store=run_store,
        thread_store=_missing_meta_store(),
    )
    with client:
        resp = client.get(f"/api/threads/{THREAD_ID}/token-usage")

    assert resp.status_code == 200
    body = resp.json()
    assert body["total_tokens"] == 222
    assert body["total_runs"] == 1


# ===========================================================================
# Criterion 6 (pass_to_pass): established-ownership threads keep the
# pre-existing unfiltered read + folded token totals (#5448 regression guard).
# ===========================================================================
def test_established_ownership_reads_unfiltered() -> None:
    thread_store = _established_meta_store(OWNER_RAW)
    run_store = MemoryRunStore()
    _seed_run(run_store, "run-owner", user_id=OWNER_RAW, status="success")
    _seed_run(run_store, "run-legacy-default", user_id="default", status="success")
    _set_run_tokens(run_store, "run-owner", 111)
    _set_run_tokens(run_store, "run-legacy-default", 55)
    client = _make_app(
        user=_internal_user(OWNER_RAW),
        auth_source=AUTH_SOURCE_INTERNAL,
        run_store=run_store,
        thread_store=thread_store,
    )
    with client:
        listed = client.get(f"/api/threads/{THREAD_ID}/runs", headers=_owner_headers())
        usage = client.get(
            f"/api/threads/{THREAD_ID}/token-usage", headers=_owner_headers()
        )

    assert listed.status_code == 200
    assert {row["run_id"] for row in listed.json()} == {
        "run-owner",
        "run-legacy-default",
    }
    assert usage.status_code == 200
    body = usage.json()
    assert body["total_tokens"] == 166
    assert body["total_runs"] == 2


# ===========================================================================
# Criterion 7 (pass_to_pass): browser / API sessions keep their existing
# per-user filter on the run list unchanged (never entered the internal branch).
# ===========================================================================
def test_browser_sessions_unchanged() -> None:
    run_store = MemoryRunStore()
    _seed_run(
        run_store, "run-browser", user_id=str(BROWSER_USER_ID), status="success"
    )
    _seed_run(run_store, "run-owner", user_id=OWNER_RAW, status="success")
    client = _make_app(
        user=_browser_user(),
        auth_source=AUTH_SOURCE_SESSION,
        run_store=run_store,
        thread_store=_missing_meta_store(),
    )
    with client:
        listed = client.get(f"/api/threads/{THREAD_ID}/runs")
        cross = client.get(f"/api/threads/{THREAD_ID}/runs/run-owner")

    assert listed.status_code == 200
    assert [row["run_id"] for row in listed.json()] == ["run-browser"]
    assert cross.status_code == 404


if __name__ == "__main__":  # pragma: no cover
    sys.exit(pytest.main([__file__, "-v"]))
