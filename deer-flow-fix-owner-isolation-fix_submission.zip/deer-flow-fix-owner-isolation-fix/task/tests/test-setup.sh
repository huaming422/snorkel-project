#!/usr/bin/env bash
# Setup for the deer-flow-fix-owner-isolation verifier.
#
# The owner-isolation boundary reproduces entirely in-process: the gateway's
# thread-runs router is driven through FastAPI's TestClient against the
# harness's in-memory run / run-event / thread-meta stores. No PostgreSQL, no
# running server, no network. The image already bakes the backend dependency
# closure at the base commit (offline agent phase), so this is normally a fast
# no-op; it exists to repopulate the venv on a cold sandbox start and to pick
# up any deps the solving agent added.
set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/deer-flow}"
BACKEND_DIR="$REPO_DIR/backend"

cd "$BACKEND_DIR"

# uv sync is idempotent; the image pre-warms /opt/venv via the lockfile, so
# this only does real work on a cold start or after the agent changed deps.
# Offline-first: everything is already in the warm uv cache, so the --offline
# resolve succeeds without network; the logged fallback only runs if a cold
# sandbox lost the cache.
if [ ! -d "$BACKEND_DIR/.venv" ] && [ ! -d /opt/venv ]; then
    uv sync --frozen --offline --group dev \
        || { echo "[test-setup] offline sync miss; retrying online"; uv sync --frozen --group dev; }
fi

# verify.py runs the repo-native pytest via verify.toml's `[pytest] command`
# (`cd backend && PYTHONPATH=. uv run pytest`), which resolves the backend
# project venv and its sys.path shims (app, deerflow). The verifier
# infrastructure itself runs under VERIFIER_PYTHON (/opt/tooling/venv), which
# carries the standalone verifier deps the project venv lacks — do NOT repoint
# it at the project venv here.

# REPO_NAME is read by /tests/run_verify.py to compute REPO_DIR.
export REPO_NAME=deer-flow
export PYTHONPATH=.

echo "[test-setup] ready: $BACKEND_DIR (verifier drives the backend pytest suite via verify.toml)"
