#!/usr/bin/env bash
# test-setup.sh — sourced before the verifier runs (verifier phase, network up).
#
# The verifier exercises the pure replay-safety classifier functions in
# app/modules/proxy/replay_safety.py through the repo's own package, imported
# from the project venv at /opt/venv (baked offline at the base commit by the
# image). Those functions only pull in a light import chain (app.core.openai.*,
# app.core.types, pydantic) — no services, no datastore, no network.
#
# The image already installed the full locked dependency closure into /opt/venv
# via `uv sync --frozen` at the base commit, so this script is an offline no-op
# in the common case: it just confirms the module under test imports. The
# online block is a logged fallback for a cold venv only.
set -euo pipefail

cd /repo/codex-lb

# Offline-first: the project venv is baked. Confirm the module under test
# imports; only fall back to an online sync if the venv is missing/cold.
if ! /opt/venv/bin/python -c "import app.modules.proxy.replay_safety" >/dev/null 2>&1; then
    echo "project venv cold — syncing from lockfile (online fallback)" >&2
    uv sync --frozen --all-extras --group dev > /tmp/verifier-sync.log 2>&1 \
        || (tail -50 /tmp/verifier-sync.log >&2; exit 1)
fi

# Fail fast if the module under test cannot be imported.
/opt/venv/bin/python -c "import app.modules.proxy.replay_safety as r; \
    assert r.responses_payload_is_account_neutral_fresh_replay and \
           r.project_responses_input_for_account_neutral_fresh_replay"
