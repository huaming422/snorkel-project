"""Behavioral checks for the proxy account-neutral replay-safety classifier.

Every assertion runs against the stable, pre-existing public surface of
``app.modules.proxy.replay_safety`` — the same four functions the HTTP bridge,
WebSocket path, and retry path all consume:

    * ``responses_payload_is_account_neutral_fresh_replay`` — top-level verdict
    * ``project_responses_input_for_account_neutral_fresh_replay`` — projection
    * ``responses_input_suffix_retains_prior_output`` — suffix proof
    * ``responses_input_items_are_self_contained_fresh_replay`` — item proof

The tests never import or reference any private helper the change may add,
rename, or inline: a correct solution is free to restructure internals however
it likes as long as these public verdicts come out right. Payload fixtures are
built locally from the documented Responses item schema, not copied from any
repo test module, so this file stands alone when collected from /tests/verify/.

The projection return value is the module's own dataclass; attributes are read
by name (``.input_items`` / ``.stored_prefix_count``), never by index.
"""

from __future__ import annotations

from typing import Any

import pytest

from app.modules.proxy.replay_safety import (
    project_responses_input_for_account_neutral_fresh_replay,
    responses_input_items_are_self_contained_fresh_replay,
    responses_input_suffix_retains_prior_output,
    responses_payload_is_account_neutral_fresh_replay,
)

# --- fixture builders (documented Responses item shapes) --------------------


def _user_message(text: str = "continue") -> dict[str, Any]:
    return {"type": "message", "role": "user", "content": [{"type": "input_text", "text": text}]}


def _compact_context(**extra: Any) -> dict[str, Any]:
    """The encrypted summary that stands in for trimmed history."""
    item: dict[str, Any] = {"type": "compaction", "status": "completed", "encrypted_content": "encrypted-context"}
    item.update(extra)
    return item


def _search_call(**extra: Any) -> dict[str, Any]:
    item: dict[str, Any] = {
        "type": "tool_search_call",
        "call_id": "call_search",
        "arguments": {"query": "codex-lb"},
        "status": "completed",
    }
    item.update(extra)
    return item


def _search_output(**extra: Any) -> dict[str, Any]:
    item: dict[str, Any] = {
        "type": "tool_search_output",
        "call_id": "call_search",
        "output": "result",
        "status": "completed",
    }
    item.update(extra)
    return item


# --- criterion 1: compact summary + message is neutral ----------------------


def test_compaction_plus_message_is_neutral() -> None:
    """A completed compact-context item (non-empty summary, no owner id) followed
    by a fresh user message must be accepted as safe to replay on a neutral
    account."""
    payload = {"input": [_compact_context(), _user_message()]}
    assert responses_payload_is_account_neutral_fresh_replay(payload) is True


# --- criterion 2: owner-bound id fails closed, bare id-less projects neutral -


def test_compaction_id_fails_closed() -> None:
    """A compact-context item carrying owner-bound bookkeeping must still be
    refused: the projection keeps the owner marker, so the resulting payload is
    non-neutral."""
    input_items = [_compact_context(id="cmp_owner_a"), _user_message()]
    projection = project_responses_input_for_account_neutral_fresh_replay(input_items, stored_count=1)
    assert projection is not None
    assert projection.input_items[0].get("id") == "cmp_owner_a"
    assert responses_payload_is_account_neutral_fresh_replay({"input": projection.input_items}) is False


def test_compaction_without_id_projects_neutral() -> None:
    """The same compact-context item WITHOUT owner bookkeeping must project to a
    neutral payload (no owner marker survives) that then classifies as safe."""
    input_items = [_compact_context(), _user_message()]
    projection = project_responses_input_for_account_neutral_fresh_replay(input_items, stored_count=1)
    assert projection is not None
    assert "id" not in projection.input_items[0]
    assert responses_payload_is_account_neutral_fresh_replay({"input": projection.input_items}) is True


# --- criterion 3: client search pair preserved + retained -------------------


def test_post_compact_tool_search_pair_preserved_and_retained() -> None:
    """A completed client-executed search call/output pair after a compact
    summary must be preserved through projection (owner markers stripped, pair
    order kept), count as retained prior output before the fresh message, and
    the whole payload must classify as neutral."""
    input_items = [
        _compact_context(),
        _search_call(id="tsc_owner_a", execution="client"),
        _search_output(id="tso_owner_a", execution="client", tools=[]),
        _user_message("continue after compaction"),
    ]
    projection = project_responses_input_for_account_neutral_fresh_replay(input_items, stored_count=1)
    assert projection is not None
    # Projection keeps all four items, in order, with every owner marker gone.
    assert [item.get("type") for item in projection.input_items] == [
        "compaction",
        "tool_search_call",
        "tool_search_output",
        "message",
    ]
    assert all("id" not in item for item in projection.input_items)
    assert projection.stored_prefix_count == 1
    assert (
        responses_input_suffix_retains_prior_output(
            projection.input_items, stored_count=projection.stored_prefix_count
        )
        is True
    )
    assert responses_payload_is_account_neutral_fresh_replay({"input": projection.input_items}) is True

    # The tools-only settlement variant — a completed client search output that
    # carries no textual result, only an (account-neutral) tools list — is also
    # reproducible context and must be accepted as self-contained and neutral.
    tools_only_items = [
        _search_call(execution="client"),
        {
            "type": "tool_search_output",
            "call_id": "call_search",
            "execution": "client",
            "status": "completed",
            "tools": [],
        },
        _user_message(),
    ]
    assert responses_input_items_are_self_contained_fresh_replay(tools_only_items) is True
    assert responses_payload_is_account_neutral_fresh_replay({"input": tools_only_items}) is True


# --- criterion 4: account-scoped search output fails closed -----------------


@pytest.mark.parametrize(
    "scoped_output",
    [
        pytest.param(_search_output(execution="server", tools=[]), id="server-execution"),
        pytest.param(
            _search_output(execution="client", tools=[{"type": "file_search", "vector_store_ids": ["vs_owner"]}]),
            id="file-search-vector-store",
        ),
        pytest.param(
            _search_output(execution="client", tools=[{"type": "function", "name": "lookup", "namespace": "private"}]),
            id="private-namespace-function",
        ),
    ],
)
def test_account_scoped_tool_search_output_fails_closed(scoped_output: dict[str, Any]) -> None:
    """Search activity that ran server-side, or that references account-scoped
    tool state, must keep the payload non-neutral."""
    input_items = [_search_call(execution="client"), scoped_output, _user_message()]
    assert responses_payload_is_account_neutral_fresh_replay({"input": input_items}) is False


# --- criterion 5: unsafe compaction boundary → projection None --------------


def test_compaction_boundary_not_last_returns_none() -> None:
    """A self-contained compact summary that is not the last item of the stored
    prefix (other raw-prefix bookkeeping follows it within stored_count) is an
    unsafe boundary: projection must return None."""
    input_items = [
        _compact_context(),
        {"type": "web_search_call", "id": "ws_owner_a", "action": {"type": "search", "query": "codex-lb"}, "status": "completed"},
        _search_call(execution="client"),
        _search_output(execution="client", tools=[]),
        _user_message("continue after compaction"),
    ]
    assert project_responses_input_for_account_neutral_fresh_replay(input_items, stored_count=2) is None


# --- criterion 6: mixed tool suffix not retained ----------------------------


def test_mixed_tool_suffix_after_compaction_not_retained() -> None:
    """Only a pure client-search settlement may count as retained output after a
    compact-summary prefix. A mixed function-call + search suffix must NOT be
    treated as retained prior output."""
    input_items = [
        _compact_context(),
        {"type": "function_call", "call_id": "call_function", "name": "lookup", "arguments": "{}", "status": "completed"},
        _search_call(execution="client"),
        {"type": "function_call_output", "call_id": "call_function", "output": "result", "status": "completed"},
        _search_output(execution="client", tools=[]),
        _user_message(),
    ]
    assert responses_input_suffix_retains_prior_output(input_items, stored_count=1) is False


# --- criterion 7 (pass_to_pass): existing contract preserved ----------------


def test_existing_neutral_contract_preserved() -> None:
    """The pre-existing contract must not regress: a self-contained
    function-call loop plus a user message stays neutral, while payloads bound
    to their original account (owner-id compact summary) or carrying
    non-reproducible / account-scoped state (reasoning, server-side web search)
    stay refused."""
    function_loop_items = [
        {"type": "function_call", "call_id": "call_1", "name": "lookup", "arguments": "{}", "status": "completed"},
        {"type": "function_call_output", "call_id": "call_1", "output": "ok", "status": "completed"},
        _user_message(),
    ]
    assert responses_input_items_are_self_contained_fresh_replay(function_loop_items) is True
    assert responses_payload_is_account_neutral_fresh_replay({"input": function_loop_items}) is True

    # Still-refused shapes: owner-pinned compact summary, reasoning state, and
    # server-side web search remain account-scoped / non-reproducible.
    assert responses_payload_is_account_neutral_fresh_replay({"input": [_compact_context(id="cmp_owner_a"), _user_message()]}) is False
    assert responses_payload_is_account_neutral_fresh_replay({"input": [{"type": "reasoning", "encrypted_content": "ciphertext"}]}) is False
    assert (
        responses_payload_is_account_neutral_fresh_replay(
            {
                "input": [
                    {"type": "web_search_call", "id": "ws_owner", "action": {"type": "search", "query": "q"}, "status": "completed"},
                    _user_message(),
                ]
            }
        )
        is False
    )
