## Task

After a Codex conversation gets compacted, the next follow-up turn
sometimes fails to recover when the proxy has to retry it on a different
ChatGPT account. These turns carry the compacted-context summary plus the
tool-search the model just ran, then a fresh user message, and the
account-neutral retry refuses them, so the follow-up fails instead of
continuing. Turns that are only the compacted summary plus a new message
hit the same wall. Make post-compaction follow-ups recover correctly on a
neutral account, while still refusing turns that genuinely must stay on
their original account. Dig in and fix it.
