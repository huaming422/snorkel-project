#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
# No assertion logic here: bring the baked NuGet closure online (offline-first)
# and warm the build so the verifier's `dotnet test` run resolves everything
# from the image with the network cut.
cd /repo/jint

# Make .NET/NuGet fail fast on a cache miss instead of reaching for nuget.org.
# The image baked the full restore for Jint.Tests.Browser at build time, so a
# --no-restore / offline build must already have every package locally.
export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1
export NUGET_PACKAGES=/root/.nuget/packages

# Offline-first restore against the image bake, logged online fallback.
if dotnet restore Jint.Tests.Browser/Jint.Tests.Browser.csproj \
        --source "$NUGET_PACKAGES" > /tmp/test-setup-restore.log 2>&1; then
    echo "[offline-first] NuGet restore satisfied from image"
elif dotnet restore Jint.Tests.Browser/Jint.Tests.Browser.csproj >> /tmp/test-setup-restore.log 2>&1; then
    echo "[test-setup] NuGet restore completed online (image bake was stale)"
else
    tail -60 /tmp/test-setup-restore.log >&2
    exit 1
fi
