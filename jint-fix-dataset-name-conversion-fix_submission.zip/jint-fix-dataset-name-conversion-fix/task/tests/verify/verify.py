"""Behavioral verifier for the DOM `dataset` name-conversion fix.

The repository is C#; there is no native C# verifier format, so this pytest
file is the thin driver mandated for .NET: it injects one focused NUnit test
file into the browser test project, runs `dotnet test` ONCE under Release with
host-contract verification armed, parses the TRX, and maps each C# test's
outcome onto one criterion.

Everything is exercised strictly through the JavaScript engine surface that a
page author sees — `element.dataset` reads/writes/deletes, `Object.keys`,
`'key' in dataset`, `getAttribute`/`hasAttribute`, and the thrown
`DOMException` name/code. No adapter class, host-hook method, overrides entry,
realm symbol, or generated identifier is named anywhere here; an equally valid
fix may name those differently. The one by-name infrastructure reference is
re-running the repository's own pre-existing binding suites (staleness, pin,
host-contract), which are repo-owned and approach-agnostic.

The behavioral keys deliberately differ from the ones the task description
uses (`maxLength`/`data-max-length`, `userId`/`data-user-id`, `my-key`), so a
submission that special-cases the exact strings from the report cannot pass.
"""

from __future__ import annotations

import functools
import os
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

REPO = Path(f"/repo/{os.environ.get('REPO_NAME', 'jint')}")
TEST_PROJECT_DIR = REPO / "Jint.Tests.Browser"
TEST_PROJECT = TEST_PROJECT_DIR / "Jint.Tests.Browser.csproj"
INJECTED_TEST = TEST_PROJECT_DIR / "DatasetNameConversionVerifyTests.cs"
TRX_PATH = Path("/tmp/dataset_verify_results.trx")

# One target framework keeps the run inside the wall-clock budget; net10.0 is
# the toolchain the repo's global.json pins. Release is required because the
# host-contract verifiers only arm outside DEBUG.
TARGET_FRAMEWORK = "net10.0"

# The focused test file. It uses the project's own DomTestFixture (same
# assembly, so its internals are reachable) and drives JavaScript against the
# engine exactly as the existing binding tests do.
INJECTED_SOURCE = r'''// Auto-written focused checks for DOMStringMap name conversion.
// Exercised purely through the JavaScript engine surface, never through the
// projection's internal types, so any correct decomposition satisfies them.
namespace Jint.Tests.Browser;

public sealed class DatasetNameConversionVerifyTests
{
    private static DomTestFixture New() => DomTestFixture.Create("<div id='x'></div>");

    private static string Script(string body) =>
        "(function(){ var e = document.getElementById('x'); " + body + " })()";

    [Test]
    public void ReadsCamelCaseKey()
    {
        using var fx = New();
        fx.Evaluate(Script("e.setAttribute('data-max-length', '7');"));
        fx.Text(Script("return e.dataset.maxLength;")).Should().Be("7");
    }

    [Test]
    public void WritesCamelCaseKey()
    {
        using var fx = New();
        fx.Evaluate(Script("e.dataset.userId = 'u-42';"));
        fx.Text(Script("return e.getAttribute('data-user-id');")).Should().Be("u-42");
    }

    [Test]
    public void DeleteRemovesBackingAttribute()
    {
        using var fx = New();
        fx.Evaluate(Script("e.setAttribute('data-user-id', 'u-1');"));
        fx.Evaluate(Script("delete e.dataset.userId;"));

        // The line an enumeration-only workaround cannot pass: the content
        // attribute must be physically gone, not merely hidden from Object.keys.
        fx.Bool(Script("return e.hasAttribute('data-user-id');")).Should().BeFalse();
        fx.Bool(Script("return e.dataset.userId === undefined;")).Should().BeTrue();
        fx.Bool(Script("return 'userId' in e.dataset;")).Should().BeFalse();
    }

    [Test]
    public void EnumeratesConvertedKeys()
    {
        using var fx = New();
        fx.Evaluate(Script("e.setAttribute('data-foo', 'a'); e.setAttribute('data-max-length', '7');"));
        fx.Text(Script("return Object.keys(e.dataset).sort().join(',');")).Should().Be("foo,maxLength");
    }

    // A hyphen immediately followed by a lowercase ASCII letter is the first
    // refusal case and maps to SyntaxError (code 12).
    [TestCase("my-key")]
    [TestCase("a-b")]
    public void RefusesHyphenLowercaseWithSyntaxError(string property)
    {
        using var fx = New();
        fx.Text(Script(
            "try { e.dataset['" + property + "'] = 'v'; return 'no throw'; } "
            + "catch (err) { return err.name + '/' + err.code; }"))
            .Should().Be("SyntaxError/12");
    }

    // A name that does not yield a valid attribute name is the second refusal
    // case and maps to InvalidCharacterError (code 5) — a distinct exception.
    [TestCase("bad name")]
    [TestCase("bad/name")]
    public void RefusesInvalidNameWithInvalidCharacterError(string property)
    {
        using var fx = New();
        fx.Text(Script(
            "try { e.dataset['" + property + "'] = 'v'; return 'no throw'; } "
            + "catch (err) { return err.name + '/' + err.code; }"))
            .Should().Be("InvalidCharacterError/5");
    }
}
'''

# Pre-existing repository suites that must stay green: the generated-binding
# staleness check, the version pin, and the full binding surface under
# host-contract verification. These are repo-owned and independent of how the
# fix is structured.
CONTRACT_CLASSES = (
    "DomBindingsStalenessTests",
    "DomBindingsPinTests",
    "DomBindingTests",
)

TRX_NS = {"t": "http://microsoft.com/schemas/VisualStudio/TeamTest/2010"}

BEHAVIOR_CLASS = "DatasetNameConversionVerifyTests"


class Outcome:
    """One recorded C# test result."""

    def __init__(self, class_name: str, method: str, display: str, passed: bool) -> None:
        self.class_name = class_name  # short class name (last dotted segment)
        self.method = method          # bare method name, no arg tuple
        self.display = display        # full display name incl. arg tuple
        self.passed = passed


class DotnetRun:
    """Outcome of the single `dotnet test` invocation."""

    def __init__(self, returncode: int, outcomes: list[Outcome], log: str) -> None:
        self.returncode = returncode
        self.outcomes = outcomes
        self.log = log


def _short_class(fq: str) -> str:
    # className is like "Jint.Tests.Browser.DomBindingTests" -> "DomBindingTests".
    return fq.rsplit(".", 1)[-1] if fq else ""


@functools.lru_cache(maxsize=1)
def _run_dotnet() -> DotnetRun:
    INJECTED_TEST.write_text(INJECTED_SOURCE)
    if TRX_PATH.exists():
        TRX_PATH.unlink()

    test_filter = "|".join(
        f"FullyQualifiedName~Jint.Tests.Browser.{name}"
        for name in (BEHAVIOR_CLASS, *CONTRACT_CLASSES)
    )

    env = {
        **os.environ,
        "JINT_HOST_CONTRACT_VERIFICATION": "1",
        "DOTNET_CLI_TELEMETRY_OPTOUT": "1",
        "DOTNET_NOLOGO": "1",
        "NUGET_PACKAGES": os.environ.get("NUGET_PACKAGES", "/root/.nuget/packages"),
    }

    cmd = [
        "dotnet", "test", str(TEST_PROJECT),
        "-c", "Release",
        "-f", TARGET_FRAMEWORK,
        "--no-restore",
        "--filter", test_filter,
        "--logger", f"trx;LogFileName={TRX_PATH.name}",
        "--results-directory", str(TRX_PATH.parent),
    ]

    proc = subprocess.run(
        cmd, cwd=str(REPO), env=env,
        capture_output=True, text=True, timeout=1500, check=False,
    )
    log = (proc.stdout or "")[-6000:] + "\n--- stderr ---\n" + (proc.stderr or "")[-4000:]

    outcomes: list[Outcome] = []
    if TRX_PATH.exists():
        root = ET.parse(str(TRX_PATH)).getroot()
        # Map testId -> className via the TestDefinitions section; UnitTestResult
        # display names do not carry the class, but their testId links to a
        # UnitTest whose <TestMethod className=.../> does.
        class_by_id: dict[str, str] = {}
        for ut in root.findall(".//t:TestDefinitions/t:UnitTest", TRX_NS):
            tid = ut.get("id", "")
            tm = ut.find("t:TestMethod", TRX_NS)
            if tid and tm is not None:
                class_by_id[tid] = _short_class(tm.get("className", ""))
        for r in root.findall(".//t:Results/t:UnitTestResult", TRX_NS):
            display = r.get("testName", "")
            method = display.split("(", 1)[0]
            cls = class_by_id.get(r.get("testId", ""), "")
            outcomes.append(Outcome(cls, method, display, r.get("outcome", "") == "Passed"))

    return DotnetRun(proc.returncode, outcomes, log)


def _assert_method(run: DotnetRun, method: str) -> None:
    """Assert every behavioral C# test case for `method` ran and passed.

    NUnit's TRX display name is the bare method name, plus an argument tuple in
    parentheses for each `[TestCase(...)]` row. Scope to the injected behavioral
    class so no same-named case elsewhere can satisfy it.
    """
    matched = [o for o in run.outcomes if o.class_name == BEHAVIOR_CLASS and o.method == method]
    assert matched, (
        f"no result recorded for C# test '{method}'. "
        f"The project likely failed to build or the test was not run.\n"
        f"dotnet exit={run.returncode}\n{run.log}"
    )
    failed = [o.display for o in matched if not o.passed]
    assert not failed, f"C# test(s) failed: {failed}\n{run.log}"


# --- criterion -> C# behavioral test --------------------------------------

def test_read_camel():
    _assert_method(_run_dotnet(), "ReadsCamelCaseKey")


def test_write_camel():
    _assert_method(_run_dotnet(), "WritesCamelCaseKey")


def test_delete_removes_attribute():
    _assert_method(_run_dotnet(), "DeleteRemovesBackingAttribute")


def test_enumerate_camel():
    _assert_method(_run_dotnet(), "EnumeratesConvertedKeys")


def test_refuse_syntax_error():
    _assert_method(_run_dotnet(), "RefusesHyphenLowercaseWithSyntaxError")


def test_refuse_invalid_char():
    _assert_method(_run_dotnet(), "RefusesInvalidNameWithInvalidCharacterError")


def test_preserve_binding_contract():
    """The pre-existing binding suites stay green under host-contract checks.

    Runs the generated-binding staleness check, the version pin, and the full
    binding surface with host-contract verification armed. A hand-edited
    generated file fails the staleness check; an enumeration/read/delete that
    disagree trip host-contract verification. This is a pass_to_pass check:
    it must hold on the unmodified tree AND after a correct fix, so it asserts
    ONLY the three pre-existing suites, never the injected behavioral cases.
    """
    run = _run_dotnet()
    assert run.outcomes, (
        "no TRX results were produced — the test project did not build or run.\n"
        f"dotnet exit={run.returncode}\n{run.log}"
    )
    for suite in CONTRACT_CLASSES:
        suite_results = [o for o in run.outcomes if o.class_name == suite]
        assert suite_results, (
            f"the pre-existing suite '{suite}' produced no results — it did not "
            f"run (filter miss or build failure).\n{run.log}"
        )
        failed = [o.display for o in suite_results if not o.passed]
        assert not failed, f"binding-contract regressions in {suite}: {failed}\n{run.log}"
