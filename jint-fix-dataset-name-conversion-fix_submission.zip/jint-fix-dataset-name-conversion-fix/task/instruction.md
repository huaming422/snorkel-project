## Task

scripts that touch an element's `dataset` aren't getting browser behavior out of it. reading a camelCase key doesn't come back with the value of the matching dashed `data-*` attribute, and setting a camelCase key doesn't create or update the dashed attribute the way it should. deleting a key is worse: the backing attribute stays stuck on the element, so the key still looks present and keeps showing up when you enumerate. on top of that, property names a browser would reject are being accepted quietly instead of refused.

make `dataset` line up with how a real browser handles the camelCase-to-`data-*` mapping across reads, writes, deletes, and the names it won't allow.
