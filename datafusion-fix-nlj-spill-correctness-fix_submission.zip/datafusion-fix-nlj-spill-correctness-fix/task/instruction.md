## Task

some join queries in datafusion come back wrong under a tight memory limit. give the same query a generous pool and it's correct, so this only shows up once memory pressure pushes the join onto its spill-to-disk path.

it's the non-equi joins, the ones whose condition is an inequality like `l.v > r.w`. run one with plenty of memory and then with a small pool, and the two disagree: under the limit you get a different set of rows, sometimes fewer, sometimes more. no error is raised, so it reads clean until you compare rows.

a spilling query may give up with a resource-exhaustion error when it can't fit the budget. what it must never do is quietly return a row set that differs from the full run. get the memory-limited path to match the full result or fail loudly.

keep what already works: queries that spill fine today shouldn't start erroring, and a join whose left input is empty still needs to finish cleanly. keep the fix in the join execution, not the query api.

dig in and fix.
