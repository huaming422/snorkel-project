// Behavioral verifier for datafusion-fix-nlj-spill-correctness.
//
// Injected as an integration test into `datafusion/core/tests/`, so it reaches
// ONLY the `datafusion` crate's PUBLIC API. Both defects are exercised through
// stable, pre-existing public interfaces:
//
//   * Defect 1 (deferred-emission early-exit drops unmatched probe-side rows):
//     driven entirely through `SessionContext` + SQL. A non-equi LEFT / LEFT
//     ANTI / FULL join is planned as a `NestedLoopJoinExec`; run it once with an
//     ample pool and once under a tiny pool (which forces the spill path) and
//     assert the two row-sets are identical. Pre-fix, the memory-limited run
//     silently drops rows; post-fix the sets match.
//
//   * Defect 2 (spill gate too narrow — only `Full` was excluded from the
//     memory-limited multi-partition path, so Left/LeftSemi/LeftAnti/LeftMark
//     emitted wrong/duplicated rows instead of failing cleanly): reconstructed
//     through the public physical-plan API — `MemorySourceConfig` sources, a
//     `RepartitionExec` that gives the probe side multiple partitions, a
//     `NestedLoopJoinExec`, and a `RuntimeEnv` with a 100-byte pool. Every
//     left-emission join type must surface `ResourcesExhausted` (fail cleanly)
//     rather than return a wrong row-set; the right-emission + inner types must
//     keep spilling successfully.
//
// The Defect-2 reconstruction mirrors the join's own `pub(crate)`
// `multi_partitioned_join_collect` test helper, which is unreachable from an
// integration test; it is rebuilt here from public symbols so the behavior,
// not the internal helper, is what is asserted.

use std::sync::Arc;

use arrow::array::{Int32Array, RecordBatch};
use arrow::datatypes::{DataType, Field, Schema};

use datafusion::datasource::memory::MemorySourceConfig;
use datafusion::execution::runtime_env::RuntimeEnvBuilder;
use datafusion::physical_plan::common::collect;
use datafusion::physical_plan::expressions::{BinaryExpr, Column, Literal};
use datafusion::physical_plan::joins::NestedLoopJoinExec;
use datafusion::physical_plan::joins::utils::{ColumnIndex, JoinFilter};
use datafusion::physical_plan::repartition::RepartitionExec;
use datafusion::physical_plan::{ExecutionPlan, Partitioning, PhysicalExpr};
use datafusion::prelude::{SessionConfig, SessionContext};
use datafusion_common::{JoinSide, JoinType, ScalarValue, assert_contains};
use datafusion_execution::TaskContext;
use datafusion_expr::Operator;

// ===========================================================================
// Defect 1 — row-set equality through the public SQL interface.
// ===========================================================================

/// Deterministic table whose join keys repeat, so most rows match and only a
/// handful remain unmatched — the rows a dropped-bitmap bug would silently lose.
/// (LCG-generated; a standalone fixture, not copied from any reference test.)
fn table(rows: usize, value_column: &str, seed: u64) -> RecordBatch {
    let mut state = seed;
    let mut next = || {
        state = state
            .wrapping_mul(6364136223846793005)
            .wrapping_add(1442695040888963407);
        state >> 33
    };
    let schema = Arc::new(Schema::new(vec![
        Field::new("k", DataType::Int32, true),
        Field::new(value_column, DataType::Int32, true),
    ]));
    let keys: Vec<Option<i32>> = (0..rows).map(|_| Some((next() % 10) as i32)).collect();
    let values: Vec<Option<i32>> = (0..rows).map(|_| Some((next() % 60) as i32)).collect();
    RecordBatch::try_new(
        schema,
        vec![
            Arc::new(Int32Array::from(keys)),
            Arc::new(Int32Array::from(values)),
        ],
    )
    .unwrap()
}

/// Run `sql`, optionally under a memory limit, returning the sorted rows as
/// `|`-joined cell strings.
async fn run_sql(sql: &str, memory_limit: Option<usize>) -> Vec<String> {
    let config = SessionConfig::new()
        .with_target_partitions(1)
        .with_batch_size(16);
    let runtime = match memory_limit {
        Some(bytes) => RuntimeEnvBuilder::new()
            .with_memory_limit(bytes, 1.0)
            .build_arc()
            .unwrap(),
        None => RuntimeEnvBuilder::new().build_arc().unwrap(),
    };
    let ctx = SessionContext::new_with_config_rt(config, runtime);
    ctx.register_batch("l", table(200, "v", 11)).unwrap();
    ctx.register_batch("r", table(90, "w", 16)).unwrap();

    let batches = ctx.sql(sql).await.unwrap().collect().await.unwrap();
    let mut rows = vec![];
    for batch in &batches {
        for row in 0..batch.num_rows() {
            let cells: Vec<String> = (0..batch.num_columns())
                .map(|col| {
                    ScalarValue::try_from_array(batch.column(col), row)
                        .unwrap()
                        .to_string()
                })
                .collect();
            rows.push(cells.join("|"));
        }
    }
    rows.sort();
    rows
}

/// A non-equi `LEFT JOIN` is planned as a `NestedLoopJoinExec`; the optimizer
/// swaps the inputs so the rows needing unmatched emission land on the probe
/// side. Spilling must not lose them.
#[tokio::test(flavor = "multi_thread")]
async fn left_join_spill_rowset_matches_ample() {
    let sql = "SELECT l.k, r.w FROM l LEFT JOIN r ON l.v > r.w";

    let ample = run_sql(sql, None).await;
    let limited = run_sql(sql, Some(64)).await;

    assert!(!ample.is_empty(), "expected the query to produce rows");
    assert_eq!(
        limited,
        ample,
        "memory-limited LEFT JOIN returned {} rows instead of {}",
        limited.len(),
        ample.len()
    );
}

/// `LEFT ANTI` (`NOT EXISTS`) returns only unmatched rows, and `FULL JOIN`
/// needs unmatched emission on both sides — both empty out if the deferred
/// bitmaps are discarded under spill.
#[tokio::test(flavor = "multi_thread")]
async fn anti_and_full_join_spill_rowset_matches_ample() {
    let anti = "SELECT l.k, l.v FROM l WHERE NOT EXISTS (SELECT 1 FROM r WHERE l.v > r.w)";
    let ample_anti = run_sql(anti, None).await;
    let limited_anti = run_sql(anti, Some(64)).await;
    assert!(
        !ample_anti.is_empty(),
        "expected the LEFT ANTI query to match some rows"
    );
    assert_eq!(
        limited_anti,
        ample_anti,
        "memory-limited LEFT ANTI returned {} rows instead of {}",
        limited_anti.len(),
        ample_anti.len()
    );

    let full = "SELECT l.k, r.w FROM l FULL JOIN r ON l.v > r.w";
    let ample_full = run_sql(full, None).await;
    let limited_full = run_sql(full, Some(64)).await;
    assert!(
        !ample_full.is_empty(),
        "expected the FULL JOIN query to produce rows"
    );
    assert_eq!(
        limited_full,
        ample_full,
        "memory-limited FULL JOIN returned {} rows instead of {}",
        limited_full.len(),
        ample_full.len()
    );
}

/// Pass-to-pass (keep-what-works): a join whose left (build) input is empty must
/// still finish cleanly under a tight memory limit and return the same (empty)
/// row-set as the ample run. base.md calls this out explicitly; it guards the
/// over-correction that would turn the empty-from-start fast finish into a
/// spurious extra pass, a hang, or an error.
#[tokio::test(flavor = "multi_thread")]
async fn empty_left_input_join_finishes_cleanly() {
    async fn run_empty_left(memory_limit: Option<usize>) -> Vec<String> {
        let config = SessionConfig::new()
            .with_target_partitions(1)
            .with_batch_size(16);
        let runtime = match memory_limit {
            Some(bytes) => RuntimeEnvBuilder::new()
                .with_memory_limit(bytes, 1.0)
                .build_arc()
                .unwrap(),
            None => RuntimeEnvBuilder::new().build_arc().unwrap(),
        };
        let ctx = SessionContext::new_with_config_rt(config, runtime);
        ctx.register_batch("l", table(0, "v", 11)).unwrap();
        ctx.register_batch("r", table(90, "w", 16)).unwrap();
        let batches = ctx
            .sql("SELECT l.k, r.w FROM l LEFT JOIN r ON l.v > r.w")
            .await
            .unwrap()
            .collect()
            .await
            .unwrap();
        let mut rows = vec![];
        for batch in &batches {
            for row in 0..batch.num_rows() {
                let cells: Vec<String> = (0..batch.num_columns())
                    .map(|col| {
                        ScalarValue::try_from_array(batch.column(col), row)
                            .unwrap()
                            .to_string()
                    })
                    .collect();
                rows.push(cells.join("|"));
            }
        }
        rows.sort();
        rows
    }

    let ample = run_empty_left(None).await;
    let limited = run_empty_left(Some(64)).await;
    assert_eq!(
        limited, ample,
        "empty-left join disagreed between ample ({}) and limited ({}) pools",
        ample.len(),
        limited.len()
    );
}

// ===========================================================================
// Defect 2 — multi-partition probe under a tight pool, through public plan API.
// ===========================================================================

/// Three-row int table `(a, b, c)` as a single-partition in-memory source.
fn mem_table(a: (&str, &[i32]), b: (&str, &[i32]), c: (&str, &[i32])) -> Arc<dyn ExecutionPlan> {
    let schema = Arc::new(Schema::new(vec![
        Field::new(a.0, DataType::Int32, false),
        Field::new(b.0, DataType::Int32, false),
        Field::new(c.0, DataType::Int32, false),
    ]));
    let batch = RecordBatch::try_new(
        Arc::clone(&schema),
        vec![
            Arc::new(Int32Array::from(a.1.to_vec())),
            Arc::new(Int32Array::from(b.1.to_vec())),
            Arc::new(Int32Array::from(c.1.to_vec())),
        ],
    )
    .unwrap();
    MemorySourceConfig::try_new_exec(&[vec![batch]], schema, None).unwrap()
}

fn build_left() -> Arc<dyn ExecutionPlan> {
    mem_table(("a1", &[5, 9, 11]), ("b1", &[5, 8, 8]), ("c1", &[50, 90, 110]))
}

fn build_right() -> Arc<dyn ExecutionPlan> {
    mem_table(("a2", &[12, 2, 10]), ("b2", &[10, 2, 10]), ("c2", &[40, 80, 100]))
}

/// Non-equi filter `left.b1 != 8 AND right.b2 != 10` over the intermediate
/// (left.b1, right.b2) columns — mirrors the join's own test fixture so the
/// matched/unmatched split that exposes the bug is reproduced.
fn prepare_filter() -> JoinFilter {
    let column_indices = vec![
        ColumnIndex { index: 1, side: JoinSide::Left },
        ColumnIndex { index: 1, side: JoinSide::Right },
    ];
    let intermediate_schema = Schema::new(vec![
        Field::new("x", DataType::Int32, true),
        Field::new("x", DataType::Int32, true),
    ]);
    let left_filter = Arc::new(BinaryExpr::new(
        Arc::new(Column::new("x", 0)),
        Operator::NotEq,
        Arc::new(Literal::new(ScalarValue::Int32(Some(8)))),
    )) as Arc<dyn PhysicalExpr>;
    let right_filter = Arc::new(BinaryExpr::new(
        Arc::new(Column::new("x", 1)),
        Operator::NotEq,
        Arc::new(Literal::new(ScalarValue::Int32(Some(10)))),
    )) as Arc<dyn PhysicalExpr>;
    let expr = Arc::new(BinaryExpr::new(left_filter, Operator::And, right_filter))
        as Arc<dyn PhysicalExpr>;
    JoinFilter::new(expr, column_indices, Arc::new(intermediate_schema))
}

/// Build an NLJ whose probe (right) side has `partition_count` partitions and
/// collect every output partition. Returns the join's result, or the error if
/// execution fails (e.g. a clean `ResourcesExhausted`).
async fn multi_partition_collect(
    join_type: JoinType,
    context: Arc<TaskContext>,
    partition_count: usize,
) -> datafusion::error::Result<Vec<RecordBatch>> {
    let left = build_left();
    let right = Arc::new(RepartitionExec::try_new(
        build_right(),
        Partitioning::RoundRobinBatch(partition_count),
    )?) as Arc<dyn ExecutionPlan>;

    let join =
        NestedLoopJoinExec::try_new(left, right, Some(prepare_filter()), &join_type, None)?;

    let mut batches = vec![];
    for i in 0..partition_count {
        let stream = join.execute(i, Arc::clone(&context))?;
        batches.extend(collect(stream).await?);
    }
    Ok(batches)
}

fn tight_task_ctx() -> Arc<TaskContext> {
    let runtime = RuntimeEnvBuilder::new()
        .with_memory_limit(100, 1.0)
        .build_arc()
        .unwrap();
    Arc::new(TaskContext::default().with_runtime(runtime))
}

/// The five left-bitmap-emission join types cannot be served correctly from a
/// multi-partition probe under the memory-limited path (per-partition bitmaps
/// would emit wrong/duplicated rows). They must fail cleanly with
/// `ResourcesExhausted` instead of silently returning a wrong row-set.
#[tokio::test(flavor = "multi_thread")]
async fn left_emission_multi_partition_fails_cleanly() {
    let gated = [
        JoinType::Left,
        JoinType::LeftSemi,
        JoinType::LeftAnti,
        JoinType::LeftMark,
        JoinType::Full,
    ];
    for join_type in gated {
        let result = multi_partition_collect(join_type, tight_task_ctx(), 4).await;
        let err = result.expect_err(&format!(
            "{join_type:?} with a multi-partition probe under a 100-byte pool must \
             fail cleanly, but it returned rows"
        ));
        assert_contains!(err.to_string(), "Resources exhausted");
    }
}

/// Guard (pass-to-pass): the right-emission types and `Inner` own their right
/// rows per partition, so they stay correct under a multi-partition probe and
/// must keep spilling to success under the same tight pool — the fix must not
/// widen the clean-failure to them.
#[tokio::test(flavor = "multi_thread")]
async fn right_emission_multi_partition_still_spills() {
    let fallback = [
        JoinType::Inner,
        JoinType::Right,
        JoinType::RightSemi,
        JoinType::RightAnti,
        JoinType::RightMark,
    ];
    for join_type in fallback {
        let result = multi_partition_collect(join_type, tight_task_ctx(), 4).await;
        assert!(
            result.is_ok(),
            "{join_type:?} with a multi-partition probe under a 100-byte pool must \
             still succeed via the spill path, but it failed: {:?}",
            result.err()
        );
    }
}
