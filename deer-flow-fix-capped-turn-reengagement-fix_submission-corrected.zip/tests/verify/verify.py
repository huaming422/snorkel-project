"""What a model turn that reaches its output limit does in a composed graph.

Every test builds the graph with a scripted model and reads what comes out: how
many model calls it made, what the last message shows, whether a tool ran, and
what the todo list holds. The run worker drives graphs through ``astream``, so
the async entry point runs next to the sync one.
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Any
from unittest.mock import MagicMock

import pytest

# The ``deerflow.agents`` package reaches ``deerflow.subagents.executor`` and then
# comes back into ``deerflow.agents.thread_state`` at import time, which stops a
# cold import of the middleware modules. The repository's own conftest seeds a
# stand-in for the executor module. This file is collected from outside the
# repository, so it seeds the same stand-in.
_executor_stub = MagicMock()
_executor_stub.SubagentExecutor = MagicMock
_executor_stub.SubagentResult = MagicMock
_executor_stub.SubagentStatus = MagicMock
_executor_stub.MAX_CONCURRENT_SUBAGENTS = 3
_executor_stub.get_background_task_result = MagicMock()
sys.modules.setdefault("deerflow.subagents.executor", _executor_stub)

# The package has an editable install in the project venv. The source root goes
# on the path too, so collection doesn't depend on that install being active.
_HARNESS_SRC = Path("/repo/deer-flow/backend/packages/harness")
if _HARNESS_SRC.is_dir() and str(_HARNESS_SRC) not in sys.path:
    sys.path.insert(0, str(_HARNESS_SRC))

from langchain.agents import create_agent  # noqa: E402
from langchain_core.language_models.chat_models import BaseChatModel  # noqa: E402
from langchain_core.messages import AIMessage, HumanMessage  # noqa: E402
from langchain_core.outputs import ChatGeneration, ChatResult  # noqa: E402
from langchain_core.tools import tool  # noqa: E402
from pydantic import PrivateAttr  # noqa: E402

from deerflow.agents.middlewares.model_length_finish_reason_middleware import (  # noqa: E402
    ModelLengthFinishReasonMiddleware,
)
from deerflow.agents.middlewares.todo_middleware import TodoMiddleware  # noqa: E402
from deerflow.agents.thread_state import ThreadState  # noqa: E402

_TOOL_RUNS: list[str] = []


@tool
def write_file(path: str, content: str) -> str:
    """Stand-in for the file-writing tool."""
    _TOOL_RUNS.append("write_file")
    return "written"


@tool
def bash(command: str) -> str:
    """Stand-in for the shell tool."""
    _TOOL_RUNS.append("bash")
    return "ran"


class _ScriptedModel(BaseChatModel):
    """Answers from a list, keeps repeating the last answer, records each request."""

    script: list[Any]
    _requests: list[list[Any]] = PrivateAttr(default_factory=list)

    @property
    def _llm_type(self) -> str:
        return "scripted"

    def bind_tools(self, tools, *, tool_choice=None, **kwargs):
        return self

    def _generate(self, messages, stop=None, run_manager=None, **kwargs):
        self._requests.append(list(messages))
        answer = self.script[min(len(self._requests) - 1, len(self.script) - 1)]
        return ChatResult(generations=[ChatGeneration(message=answer.model_copy(deep=True))])


_OPEN_TODOS = [
    {"content": "Write the report", "status": "in_progress"},
    {"content": "Review the report", "status": "pending"},
]
_MODES = ["async", "sync"]


def _with_todos():
    return [TodoMiddleware(), ModelLengthFinishReasonMiddleware()]


def _without_todos():
    return [ModelLengthFinishReasonMiddleware()]


def _run(script, middleware=_with_todos, todos=_OPEN_TODOS, mode="async", history=None):
    _TOOL_RUNS.clear()
    model = _ScriptedModel(script=script)
    graph = create_agent(model=model, tools=[write_file, bash], middleware=middleware(), state_schema=ThreadState)
    payload: dict[str, Any] = {"messages": history or [("user", "write the report")]}
    if todos is not None:
        payload["todos"] = [dict(todo) for todo in todos]
    context = {"thread_id": "thread-1", "run_id": "run-1"}
    # Three rounds of nudging fit well under this, and a loop ends the test early.
    config = {"recursion_limit": 60}
    if mode == "async":
        result = asyncio.run(graph.ainvoke(payload, config=config, context=context))
    else:
        result = graph.invoke(payload, config=config, context=context)
    return SimpleNamespace(
        calls=len(model._requests),
        requests=model._requests,
        messages=result["messages"],
        last=result["messages"][-1],
        todos=result.get("todos"),
        tools_run=list(_TOOL_RUNS),
    )


def _visible_text(content: Any) -> str:
    """The text a user reads: a string, or the text blocks of a block list."""
    if isinstance(content, str):
        return content
    parts: list[str] = []
    for block in content or []:
        if isinstance(block, str):
            parts.append(block)
        elif isinstance(block, dict) and block.get("type") in {"text", "output_text"}:
            parts.append(str(block.get("text") or ""))
    return "\n".join(parts)


def _shown(run: SimpleNamespace) -> str:
    """Everything the run's answers show the user, however many messages they took."""
    return "\n".join(_visible_text(m.content) for m in run.messages if isinstance(m, AIMessage))


def _has_reminder(request: list[Any]) -> bool:
    return any(isinstance(m, HumanMessage) and m.name == "todo_completion_reminder" for m in request)


_WRITE_CALL = {"name": "write_file", "id": "call_1", "args": {"path": "/mnt/user-data/outputs/report.md", "content": "# Report"}}
_BASH_CALL = {"name": "bash", "id": "call_2", "args": {"command": "ls -la"}}
_BROKEN_CALL = {"name": "write_file", "id": "call_1", "args": '{"path": "/mnt/user-data/outputs/rep', "error": "unterminated string", "type": "invalid_tool_call"}
_RAW_CALL = {"id": "call_1", "type": "function", "function": {"name": "write_file", "arguments": '{"path":"/mnt/user-data/outputs/rep'}}
_USE_BLOCK = {"type": "tool_use", "id": "call_1", "name": "write_file", "input": {"path": "/mnt/user-data/outputs/report.md"}}
_THINKING = {"type": "thinking", "thinking": "Lay out the report first.", "signature": "signed"}
_OPENAI = {"finish_reason": "length", "model_name": "deepseek-v4-pro"}
_ANTHROPIC = {"stop_reason": "max_tokens"}
_GEMINI = {"finish_reason": "MAX_TOKENS"}
_LONG_TEXT = "Section one covers the journal modes in some detail. " * 200

# One entry per shape a provider can hand back: a name and the partial text it holds.
_CAPPED = {
    "parsed_call": ("nit", lambda text: AIMessage(content=text, tool_calls=[_WRITE_CALL], response_metadata=_OPENAI)),
    "unparsable_call": ("| ext4 | jbd2 |", lambda text: AIMessage(content=text, invalid_tool_calls=[_BROKEN_CALL], response_metadata=_OPENAI)),
    "raw_tool_calls": ("Here is the report", lambda text: AIMessage(content=text, additional_kwargs={"tool_calls": [_RAW_CALL]}, response_metadata=_OPENAI)),
    "raw_function_call": ("period", lambda text: AIMessage(content=text, additional_kwargs={"function_call": _RAW_CALL["function"]}, response_metadata=_OPENAI)),
    "another_tool": ("Listing the folder", lambda text: AIMessage(content=text, tool_calls=[_BASH_CALL], response_metadata=_OPENAI)),
    "anthropic_blocks": ("Drafting section two", lambda text: AIMessage(content=[{"type": "text", "text": text}, _USE_BLOCK], tool_calls=[_WRITE_CALL], response_metadata=_ANTHROPIC)),
    "anthropic_use_block_only": ("Drafting section three", lambda text: AIMessage(content=[{"type": "text", "text": text}, _USE_BLOCK], response_metadata=_ANTHROPIC)),
    "anthropic_thinking": ("Drafting section four", lambda text: AIMessage(content=[_THINKING, {"type": "text", "text": text}, _USE_BLOCK], response_metadata=_ANTHROPIC)),
    "gemini_string": ("Tables come next", lambda text: AIMessage(content=text, tool_calls=[_WRITE_CALL], response_metadata=_GEMINI)),
    "gemini_string_list": ("Figures come next", lambda text: AIMessage(content=[text], tool_calls=[_WRITE_CALL], response_metadata=_GEMINI)),
    "output_text_block": ("Closing notes", lambda text: AIMessage(content=[{"type": "output_text", "text": text}], tool_calls=[_WRITE_CALL], response_metadata=_OPENAI)),
    "reason_in_kwargs": ("Appendix first", lambda text: AIMessage(content=text, tool_calls=[_WRITE_CALL], additional_kwargs={"finish_reason": "length"})),
    "long_text": (_LONG_TEXT, lambda text: AIMessage(content=text, tool_calls=[_WRITE_CALL], response_metadata=_OPENAI)),
}
_CAPPED_NO_TEXT = {
    "empty_string": lambda: AIMessage(content="", tool_calls=[_WRITE_CALL], response_metadata=_OPENAI),
    "blank_string": lambda: AIMessage(content="  \n", tool_calls=[_WRITE_CALL], response_metadata=_OPENAI),
    "thinking_only": lambda: AIMessage(content=[_THINKING, _USE_BLOCK], response_metadata=_ANTHROPIC),
}
_PLAIN = {
    "openai": lambda: AIMessage(content="Plain answer one", response_metadata=_OPENAI),
    "anthropic": lambda: AIMessage(content="Plain answer two", response_metadata=_ANTHROPIC),
    "gemini": lambda: AIMessage(content="Plain answer three", response_metadata=_GEMINI),
    "text_block": lambda: AIMessage(content=[{"type": "text", "text": "Plain answer four"}], response_metadata=_ANTHROPIC),
    "text_that_looks_like_a_call": lambda: AIMessage(content='<tool_call><invoke name="write_file"><content># partial', response_metadata=_OPENAI),
}


def _capped(name: str):
    text, build = _CAPPED[name]
    return text, build(text)


@pytest.fixture(scope="module")
def notice() -> str:
    """What the graph shows when the model returned a cut-off call and no text."""
    run = _run([_CAPPED_NO_TEXT["empty_string"]()], middleware=_without_todos, todos=None)
    text = _shown(run).strip()
    assert text, f"a capped call with no text shows nothing: {run.last.content!r}"
    return text


def _assert_shows(run: SimpleNamespace, text: str, notice: str) -> None:
    shown = _shown(run)
    assert shown.count(notice) == 1, f"notice shown {shown.count(notice)} times, the run shows: {shown[:120]!r}"
    assert text.strip() in shown.replace(notice, ""), f"partial text is gone, the run shows: {shown[:120]!r}"


@pytest.mark.parametrize("mode", _MODES)
@pytest.mark.parametrize("form", list(_CAPPED) + [f"no_text:{name}" for name in _CAPPED_NO_TEXT])
def test_capped_call_ends_the_turn(form, mode):
    answer = _CAPPED_NO_TEXT[form[8:]]() if form.startswith("no_text:") else _capped(form)[1]
    run = _run([answer], mode=mode)
    assert run.calls == 1, f"{run.calls} model calls with the todo list open, one is enough"
    assert run.tools_run == [], f"a cut-off call ran: {run.tools_run}"
    assert not run.last.tool_calls and not run.last.invalid_tool_calls, "the last message still carries a tool call"
    assert run.todos == _OPEN_TODOS, f"the todo list changed: {run.todos}"
    # The run worker records a run whose message carries this marker as failed.
    assert not run.last.additional_kwargs.get("deerflow_error_fallback"), "the capped turn is marked as an error fallback"


@pytest.mark.parametrize("mode", _MODES)
@pytest.mark.parametrize("form", list(_CAPPED))
def test_capped_call_shows_text_and_notice(form, mode, notice):
    text, answer = _capped(form)
    run = _run([answer], mode=mode)
    _assert_shows(run, text, notice)


@pytest.mark.parametrize("form", list(_CAPPED))
def test_capped_call_shows_text_and_notice_without_todo_list(form, notice):
    text, answer = _capped(form)
    run = _run([answer], middleware=_without_todos, todos=None)
    assert run.calls == 1, f"{run.calls} model calls without a todo list"
    _assert_shows(run, text, notice)


@pytest.mark.parametrize("form", list(_CAPPED_NO_TEXT))
def test_capped_call_without_text_shows_notice_once(form, notice):
    run = _run([_CAPPED_NO_TEXT[form]()])
    shown = _shown(run)
    assert shown.count(notice) == 1, f"notice shown {shown.count(notice)} times: {shown[:120]!r}"


@pytest.mark.parametrize("answer", [_CAPPED["anthropic_thinking"][1](_CAPPED["anthropic_thinking"][0]), _CAPPED_NO_TEXT["thinking_only"]()], ids=["with_text", "without_text"])
def test_capped_call_keeps_thinking_blocks(answer):
    run = _run([answer])
    blocks = [block for m in run.messages if isinstance(m, AIMessage) and isinstance(m.content, list) for block in m.content]
    assert _THINKING in blocks, f"the thinking block is gone, the run holds: {[type(m.content).__name__ for m in run.messages]}"


@pytest.mark.parametrize("first", ["clean_stop", "plain_at_limit"])
def test_capped_call_after_a_nudge_ends_the_turn(first, notice):
    opener = AIMessage(content="Working on it") if first == "clean_stop" else _PLAIN["openai"]()
    text, answer = _capped("parsed_call")
    run = _run([opener, answer])
    assert run.calls == 2, f"{run.calls} model calls, the second one was cut off and should be the last"
    assert _has_reminder(run.requests[1]), "the first answer got no nudge"
    _assert_shows(run, text, notice)


@pytest.mark.parametrize("mode", _MODES)
@pytest.mark.parametrize("form", list(_PLAIN))
def test_plain_text_at_the_limit_is_nudged(form, mode, notice):
    answer = _PLAIN[form]()
    run = _run([answer, AIMessage(content="All finished")], mode=mode)
    assert run.calls >= 2, "text with no tool call stopped the run although todos are open"
    assert _has_reminder(run.requests[1]), "the second request carries no reminder"
    first = next(m for m in run.messages if isinstance(m, AIMessage))
    assert _visible_text(first.content) == _visible_text(answer.content), f"the text changed: {_visible_text(first.content)[:120]!r}"
    assert notice not in _visible_text(first.content), "text with no tool call got the notice"


@pytest.mark.parametrize("mode", _MODES)
def test_clean_stop_is_nudged(mode):
    run = _run([AIMessage(content="I'm done")], mode=mode)
    assert run.calls >= 2, "a clean stop ended the run although todos are open"
    assert _has_reminder(run.requests[1]), "the second request carries no reminder"


def test_next_request_after_a_capped_call_is_nudged():
    earlier = _run([_capped("parsed_call")[1]], middleware=_without_todos, todos=None).last
    history = [HumanMessage("write the report"), earlier, HumanMessage("continue")]
    run = _run([AIMessage(content="I'm done")], history=history)
    assert run.calls >= 2, "an earlier capped call turned off the nudge for later answers"
    assert _has_reminder(run.requests[1]), "the second request carries no reminder"
