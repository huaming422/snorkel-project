#!/bin/bash
# Test setup for deer-flow-fix-capped-turn-reengagement.
#
# The image already carries the repo's full dependency closure (langchain,
# langgraph, pydantic), installed from the lockfile at image build time. This
# script syncs the project venv offline first, since pyproject.toml may have
# changed, and exports the environment the backend pytest suite expects.
# Everything needed is already in /opt/cache/uv, so the sync needs no network.

set -euo pipefail

REPO_DIR="/repo/deer-flow"
cd "$REPO_DIR/backend"

# Fail fast on a cache miss instead of hanging on a dead network. Then try once
# with the network, which only matters where one is up. test.sh sources this
# file, so a failed sync logs its output and goes on. The tests then run on the
# venv as it stands, report what fails, and the run still ends with a result.
export UV_OFFLINE=1
if ! uv sync --frozen --group dev > /tmp/verifier-sync.log 2>&1; then
  echo "offline uv sync failed; retrying online" >&2
  unset UV_OFFLINE
  uv sync --frozen --group dev > /tmp/verifier-sync.log 2>&1 || tail -50 /tmp/verifier-sync.log >&2 || true
fi

export REPO_NAME=deer-flow
export PYTHONPATH=.
export PYTHONIOENCODING=utf-8
export PYTHONUTF8=1
