## Task

Plan mode falls apart on long documents. The agent starts a big `write_file` call, the model runs out of tokens halfway through, and we throw the cut-off call away, which is right. Then it sends the same request again, gets cut off the same way, and doesn't stop until it's made three model calls. At the end the user is looking at a stray fragment such as `nit`, with nothing to say the reply was cut short.

It isn't only `write_file`, and it isn't one provider: any tool call that gets cut off does this, on OpenAI-compatible, Anthropic and Gemini models alike. With plan mode off there's no extra call, but the user still gets the bare fragment. We only show the output-limit notice when the model returned no text at all.

A turn like that has to end after the one model call and show the text that came back together with that same notice, once.

A reply that's plain text with no tool call in it still gets nudged to carry on if it reaches the limit with todos open, and so does a normal stop with todos open.
