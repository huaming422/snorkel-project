## Task

`bd` picks the wrong planning repo when I point it at a project other than the one I'm standing in.
With `routing.mode auto`, `create`, `list` and `ready` go to the maintainer or contributor planning repo based on `beads.role`.
If I select the project explicitly, with `bd -C ../service-x ...` or an exported `BEADS_DIR`, routing still reads `beads.role` from the checkout I launched from.

Repro, from a checkout with `beads.role = contributor`:
`bd -C ../service-x create "..."`, where service-x has `beads.role = maintainer` and `routing.maintainer` set.
The issue lands in the contributor planning repo.
It should land in service-x's maintainer planning repo, and the mirror case (contributor target, maintainer launch checkout) should go to the contributor repo.
A `BEADS_DIR` line in the launch checkout's `.beads/.env` picks a project just like exporting the variable does, so it needs the same treatment.

When the project is found by walking up from the current directory, routing works today and has to keep working the same way.

Some checkouts have a `.beads/redirect` that keeps their data in another directory.
The role belongs to the checkout, never to the place its data is stored.
Walking up into a redirected checkout should keep routing by that checkout's role, as it does now.
Picking a redirected checkout on purpose is no different.
Whether I name it with `bd -C`, export `BEADS_DIR` pointing at its `.beads`, or put that `BEADS_DIR` line in `.env`, routing should go by the role of the checkout I picked.

One more thing in the same path.
With routing off, or in auto mode with neither `routing.maintainer` nor `routing.contributor` set, every routed command still looks up the role and prints `warning: beads.role not configured` when the repo has none.
Only look the role up when the routing decision can depend on it.
Auto mode with just one of those two repos set still depends on it, so routing by role has to keep working there.
