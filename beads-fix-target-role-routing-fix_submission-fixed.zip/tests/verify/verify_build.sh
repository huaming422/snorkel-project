#!/usr/bin/env bash
# Compile + neighbor-regression gate for role-based routing.
#
# Routing is decided in cmd/bd and backed by internal/routing (role detection,
# the routing decision) and internal/beads (repo context, redirects). This gate
# builds the whole module and runs the existing suites of those two internal
# packages. It never references a name that only an implementation would add.
set -euo pipefail

export GOFLAGS="${GOFLAGS:--mod=mod}"
export CGO_ENABLED="${CGO_ENABLED:-1}"
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"

cd /repo/beads

# Whole-module compile: catches a build break anywhere in the module. This
# covers the command binary and every internal package it imports.
# The examples/ directories are their own modules and are excluded by `./...`
# on the root module.
go build ./...

# Neighbor-regression suite: the existing tests of the two internal packages
# that hold role detection, the routing decision and repo-context resolution.
# Both run hermetically, so a regression in that logic fails here.
#
# The command package's own behavioral suite is NOT run here: it boots the full
# bd runtime, which in this sandbox talks to a Dolt server in proxied-server
# mode and needs Docker for its storage-backed cases - neither is available, so
# several of its pre-existing tests fail for reasons unrelated to any routing
# change (flag-reset against a proxied server, the setup-command integration
# wrappers). Routing behavior in the command layer is covered by the companion
# Go checks instead, which run a locally built bd with embedded storage, and its
# compilation is covered by `go build ./...` above.
go test -count=1 \
    ./internal/routing/... \
    ./internal/beads/...

echo "verify_build.sh: module compiles and neighbor suites pass."
