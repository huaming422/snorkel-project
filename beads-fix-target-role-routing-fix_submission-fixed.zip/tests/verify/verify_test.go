package main

// Behavioral checks for role-based auto-routing in cmd/bd.
//
// These exercise the pre-existing routing decision function
// determineAutoRoutedRepoPath(ctx, nil) and the pre-existing `bd -C`
// selection machinery (the changeDir package var + applyChangeDirSelection).
// Everything here drives observable routing results and the single
// user-visible diagnostic the routing path can emit; nothing reaches into
// helper names, file layout, or imports that an equivalent implementation is
// free to rename or inline.
//
// This file intentionally defines no TestMain: the package's existing
// TestMain (test_repo_beads_guard_test.go) fences git/beads discovery, pins an
// isolated HOME, and clears ambient selection state, and the shared helpers it
// sets up (initConfigForTest, runCmd, captureStderr) are reused below. Every
// check restores the process state it mutates - working directory, the
// changeDir flag, selection env vars, and the process-wide repo/git caches -
// through t.Cleanup so ordering within the binary cannot leak.

import (
	"context"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/steveyegge/beads/internal/beads"
	"github.com/steveyegge/beads/internal/config"
	"github.com/steveyegge/beads/internal/git"
)

// vrfyInitRepoWithRole creates a git repository at dir and records a beads.role
// of its own, so role detection reading from that repo returns a definite
// answer rather than falling through to the global-config / origin-URL
// fallbacks.
func vrfyInitRepoWithRole(t *testing.T, dir, role string) {
	t.Helper()
	if err := os.MkdirAll(dir, 0o755); err != nil {
		t.Fatalf("mkdir %s: %v", dir, err)
	}
	runCmd(t, dir, "git", "init")
	runCmd(t, dir, "git", "config", "user.email", "test@test.com")
	runCmd(t, dir, "git", "config", "user.name", "Test")
	runCmd(t, dir, "git", "config", "core.hooksPath", ".git/hooks")
	if role != "" {
		runCmd(t, dir, "git", "config", "beads.role", role)
	}
}

// vrfyMakeBeadsProject turns dir into a selectable beads project by giving it a
// .beads directory with a database file, which is what the -C resolver and
// discovery both require before they will adopt a directory. Returns the
// .beads path.
func vrfyMakeBeadsProject(t *testing.T, dir string) string {
	t.Helper()
	beadsDir := filepath.Join(dir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o755); err != nil {
		t.Fatalf("mkdir %s: %v", beadsDir, err)
	}
	if err := os.WriteFile(filepath.Join(beadsDir, "beads.db"), []byte{}, 0o644); err != nil {
		t.Fatalf("write beads.db: %v", err)
	}
	return beadsDir
}

// vrfyClearRoutingEnv neutralizes any routing override the host environment may
// export (developer shells and CI runtimes do). The seeded in-memory config set
// below is authoritative for these checks: a host BD_ROUTING_* / BEADS_ROUTING_*
// must neither shadow a seeded value nor silently supply a repo for a key a
// check means to leave unset - the latter would flip whether routing consults
// the role. t.Setenv("") makes each key resolve empty deterministically and is
// restored by the framework after the test.
func vrfyClearRoutingEnv(t *testing.T) {
	t.Helper()
	for _, suffix := range []string{"ROUTING_MODE", "ROUTING_MAINTAINER", "ROUTING_CONTRIBUTOR", "ROUTING_DEFAULT"} {
		t.Setenv("BD_"+suffix, "")
		t.Setenv("BEADS_"+suffix, "")
	}
}

// vrfySeedRouting records routing configuration through the config surface so
// determineAutoRoutedRepoPath(ctx, nil) - which, with a nil store, reads
// routing config from config.* alone - sees the intended mode and repos.
//
// Every key is set explicitly, including the ones meant to be empty. Two of
// these keys carry a NON-EMPTY built-in default (routing.maintainer defaults to
// ".", routing.contributor to "~/.beads-planning"); a key left unset resolves
// to that default, which would silently populate a role-specific planning repo
// for a scenario that means to leave it unconfigured - and that in turn flips
// whether routing consults the user role. An explicit set (the highest config
// precedence, above the ambient environment) pins each key to exactly the
// intended value, "" included, so an unseeded default can never leak in.
func vrfySeedRouting(t *testing.T, mode, maintainer, contributor, deflt string) {
	t.Helper()
	config.Set("routing.mode", mode)
	config.Set("routing.maintainer", maintainer)
	config.Set("routing.contributor", contributor)
	config.Set("routing.default", deflt)
}

// vrfyChdir changes the working directory and restores the original on cleanup.
func vrfyChdir(t *testing.T, dir string) {
	t.Helper()
	orig, err := os.Getwd()
	if err != nil {
		t.Fatalf("getwd: %v", err)
	}
	t.Cleanup(func() { _ = os.Chdir(orig) })
	if err := os.Chdir(dir); err != nil {
		t.Fatalf("chdir %s: %v", dir, err)
	}
}

// vrfySelectWithChangeDir simulates `bd -C target`: it sets the persistent
// changeDir flag and applies it (which resolves target's .beads and rebinds
// BEADS_DIR), restoring both the flag and the mutated env on cleanup.
func vrfySelectWithChangeDir(t *testing.T, target string) {
	t.Helper()
	orig := changeDir
	changeDir = target
	t.Cleanup(func() { changeDir = orig })
	if err := applyChangeDirSelection(); err != nil {
		t.Fatalf("applyChangeDirSelection(%s): %v", target, err)
	}
	t.Cleanup(restoreChangeDirSelection)
}

// vrfyResetDiscoveryCaches rebuilds the process-wide repo/git context so the
// next routing call resolves against the current working directory and
// selection env, not whatever an earlier check in this binary cached.
func vrfyResetDiscoveryCaches(t *testing.T) {
	t.Helper()
	beads.ResetCaches()
	git.ResetCaches()
	t.Cleanup(func() {
		beads.ResetCaches()
		git.ResetCaches()
	})
}

// TestVerifyExplicitSelectionUsesTargetRole: selecting a target explicitly with
// `bd -C <target>` routes by the TARGET repo's beads.role, even when the
// process was launched from a workspace carrying a different role. Here the
// launch workspace is a contributor and the explicitly selected target is a
// maintainer; the routed repo must be the maintainer planning repo.
func TestVerifyExplicitSelectionUsesTargetRole(t *testing.T) {
	initConfigForTest(t)
	vrfyClearRoutingEnv(t)

	tmp := t.TempDir()
	caller := filepath.Join(tmp, "caller")
	target := filepath.Join(tmp, "target")
	maintainerRepo := filepath.Join(tmp, "maintainer-planning")
	contributorRepo := filepath.Join(tmp, "contributor-planning")

	vrfyInitRepoWithRole(t, caller, "contributor")
	vrfyInitRepoWithRole(t, target, "maintainer")
	vrfyMakeBeadsProject(t, target)

	vrfySeedRouting(t, "auto", maintainerRepo, contributorRepo, "")

	vrfyChdir(t, caller)
	vrfySelectWithChangeDir(t, target)
	vrfyResetDiscoveryCaches(t)

	got, _ := determineAutoRoutedRepoPath(context.Background(), nil)
	if got != maintainerRepo {
		t.Fatalf("explicit `-C` of a maintainer target routed to %q, want the maintainer planning repo %q", got, maintainerRepo)
	}
}

// TestVerifyTargetContributorRoleRespected: the symmetric direction. Selecting
// a contributor target with `bd -C` from a maintainer workspace must route to
// the CONTRIBUTOR planning repo - binding to the selected target's own role,
// not unconditionally to one side.
func TestVerifyTargetContributorRoleRespected(t *testing.T) {
	initConfigForTest(t)
	vrfyClearRoutingEnv(t)

	tmp := t.TempDir()
	caller := filepath.Join(tmp, "caller")
	target := filepath.Join(tmp, "target")
	maintainerRepo := filepath.Join(tmp, "maintainer-planning")
	contributorRepo := filepath.Join(tmp, "contributor-planning")

	vrfyInitRepoWithRole(t, caller, "maintainer")
	vrfyInitRepoWithRole(t, target, "contributor")
	vrfyMakeBeadsProject(t, target)

	vrfySeedRouting(t, "auto", maintainerRepo, contributorRepo, "")

	vrfyChdir(t, caller)
	vrfySelectWithChangeDir(t, target)
	vrfyResetDiscoveryCaches(t)

	got, _ := determineAutoRoutedRepoPath(context.Background(), nil)
	if got != contributorRepo {
		t.Fatalf("explicit `-C` of a contributor target routed to %q, want the contributor planning repo %q", got, contributorRepo)
	}
}

// TestVerifyDiscoveryKeepsCwdRole: a project reached by ordinary discovery from
// the working directory keeps detecting its role from the workspace you are
// operating in - including when a .beads/redirect relocates storage elsewhere.
// A redirect moves data, not the project's role. Both sub-checks must route by
// the workspace's own maintainer role.
func TestVerifyDiscoveryKeepsCwdRole(t *testing.T) {
	t.Run("plain", func(t *testing.T) {
		initConfigForTest(t)
		vrfyClearRoutingEnv(t)

		tmp := t.TempDir()
		workspace := filepath.Join(tmp, "workspace")
		maintainerRepo := filepath.Join(tmp, "maintainer-planning")
		contributorRepo := filepath.Join(tmp, "contributor-planning")

		vrfyInitRepoWithRole(t, workspace, "maintainer")
		vrfyMakeBeadsProject(t, workspace)

		vrfySeedRouting(t, "auto", maintainerRepo, contributorRepo, "")

		vrfyChdir(t, workspace)
		vrfyResetDiscoveryCaches(t)

		got, _ := determineAutoRoutedRepoPath(context.Background(), nil)
		if got != maintainerRepo {
			t.Fatalf("in-CWD discovery of a maintainer workspace routed to %q, want %q", got, maintainerRepo)
		}
	})

	// A workspace whose .beads/redirect points storage into a separate,
	// differently-roled repository must still route by the WORKSPACE role.
	// Reading the role from the resolved storage location would route to the
	// storage repo's contributor planning repo instead, which changes routing
	// for an existing discovered checkout.
	t.Run("through_redirect", func(t *testing.T) {
		initConfigForTest(t)
		vrfyClearRoutingEnv(t)

		tmp := t.TempDir()
		workspace := filepath.Join(tmp, "workspace")
		storageRepo := filepath.Join(tmp, "storage")
		maintainerRepo := filepath.Join(tmp, "maintainer-planning")
		contributorRepo := filepath.Join(tmp, "contributor-planning")

		// Workspace: a maintainer checkout whose local .beads only redirects.
		vrfyInitRepoWithRole(t, workspace, "maintainer")
		workspaceBeads := filepath.Join(workspace, ".beads")
		if err := os.MkdirAll(workspaceBeads, 0o755); err != nil {
			t.Fatalf("mkdir workspace .beads: %v", err)
		}
		// Storage: a separate contributor checkout that actually holds the data.
		vrfyInitRepoWithRole(t, storageRepo, "contributor")
		storageBeads := vrfyMakeBeadsProject(t, storageRepo)
		if err := os.WriteFile(filepath.Join(workspaceBeads, beads.RedirectFileName), []byte(storageBeads+"\n"), 0o644); err != nil {
			t.Fatalf("write redirect: %v", err)
		}

		vrfySeedRouting(t, "auto", maintainerRepo, contributorRepo, "")

		vrfyChdir(t, workspace)

		// Reproduce the live process state a redirected workspace routes under.
		// Normal startup resolves the workspace's .beads through its redirect and
		// rebinds BEADS_DIR to the storage dir before routing runs (FindBeadsDir
		// follows the redirect, then the selected-context setup exports it), so by
		// the time the role is read the env var names storage, not the workspace.
		// Routing from the live BEADS_DIR would therefore read the storage repo's
		// contributor role; only startup provenance keeps the role on the
		// workspace. Set it here so the live process state matches startup.
		if err := os.Setenv("BEADS_DIR", storageBeads); err != nil {
			t.Fatalf("setenv BEADS_DIR: %v", err)
		}
		t.Cleanup(func() { _ = os.Unsetenv("BEADS_DIR") })

		vrfyResetDiscoveryCaches(t)

		got, _ := determineAutoRoutedRepoPath(context.Background(), nil)
		if got != maintainerRepo {
			t.Fatalf("redirected discovery routed to %q, want the workspace's maintainer planning repo %q (role must stay on the workspace, not follow storage)", got, maintainerRepo)
		}
	})
}

// vrfyDriveCreatePreviewToRoutedTarget runs createCmd as a dry-run preview that
// resolves the auto-routed destination and then tries to open it for a --parent
// lookup. It returns whatever the routed destination refusal reports: the
// create path resolves the planning repo, and because the routed target is left
// uninitialized the preview's parent-lookup store open refuses it and names the
// resolved destination. That refusal text - error plus stderr - is the single
// observable of WHICH repo create routed to, without reaching into any helper
// name or file the fix is free to rename.
//
// A plain (no --parent) dry-run returns before any store is opened, so a
// --parent is required to drive create past routing to the destination open.
func vrfyDriveCreatePreviewToRoutedTarget(t *testing.T) string {
	t.Helper()
	setStringFlag := func(name, value string) {
		f := createCmd.Flags().Lookup(name)
		if f == nil {
			t.Fatalf("create flag %q missing", name)
		}
		orig := f.Value.String()
		origChanged := f.Changed
		_ = f.Value.Set(value)
		f.Changed = value != ""
		t.Cleanup(func() {
			_ = f.Value.Set(orig)
			f.Changed = origChanged
		})
	}
	setBoolFlag := func(name, value string) {
		f := createCmd.Flags().Lookup(name)
		if f == nil {
			t.Fatalf("create flag %q missing", name)
		}
		_ = f.Value.Set(value)
		f.Changed = value != "false"
		t.Cleanup(func() {
			_ = f.Value.Set("false")
			f.Changed = false
		})
	}
	// No --repo override (auto-routing stays in control); a --parent so the run
	// goes past the no-parent early-return and reaches the routed-target open;
	// --dry-run so nothing is written.
	setStringFlag("repo", "")
	setStringFlag("parent", "bd-routingprobe-absent")
	setBoolFlag("dry-run", "true")

	var runErr error
	stderr := captureStderr(t, func() {
		runErr = createCmd.RunE(createCmd, []string{"routing probe"})
	})
	combined := stderr
	if runErr != nil {
		combined += "\n" + runErr.Error()
	}
	return combined
}

// TestVerifyCreateExplicitSelectionUsesTargetRole: the create command's OWN
// routing site must bind role to the explicitly selected target, the same as
// the list/ready read path. Selecting a target with `bd -C <target>` from a
// workspace carrying a different role must route the created issue to the
// TARGET's role planning repo - the contract's headline worked example. Both
// planning repos are left uninitialized so the dry-run's routed-target open
// refuses the one create actually chose and names it, which is the observable
// this check reads. Both directions run so an "always route to one side"
// shortcut on the create path cannot pass.
func TestVerifyCreateExplicitSelectionUsesTargetRole(t *testing.T) {
	// maintainer: launched from a contributor workspace, selecting a maintainer
	// target, create must route to the MAINTAINER planning repo.
	t.Run("maintainer_target", func(t *testing.T) {
		initConfigForTest(t)
		vrfyClearRoutingEnv(t)
		// The create command reads package-level command globals; snapshot and
		// clear them so this runs the direct local create path with no inherited
		// store and restores whatever an earlier check left behind.
		saveAndRestoreGlobals(t)
		ensureCleanGlobalState(t)
		readonlyMode = false
		t.Cleanup(func() { readonlyMode = false })
		store = nil

		tmp := t.TempDir()
		caller := filepath.Join(tmp, "caller")
		target := filepath.Join(tmp, "target")
		maintainerRepo := filepath.Join(tmp, "maintainer-planning")
		contributorRepo := filepath.Join(tmp, "contributor-planning")

		vrfyInitRepoWithRole(t, caller, "contributor")
		vrfyInitRepoWithRole(t, target, "maintainer")
		vrfyMakeBeadsProject(t, target)

		vrfySeedRouting(t, "auto", maintainerRepo, contributorRepo, "")

		vrfyChdir(t, caller)
		vrfySelectWithChangeDir(t, target)
		vrfyResetDiscoveryCaches(t)

		got := vrfyDriveCreatePreviewToRoutedTarget(t)
		if !strings.Contains(got, maintainerRepo) {
			t.Fatalf("explicit `-C` create of a maintainer target did not route to the maintainer planning repo %q (the target's role was ignored).\noutput:\n%s", maintainerRepo, got)
		}
		if strings.Contains(got, contributorRepo) {
			t.Fatalf("explicit `-C` create routed to the contributor planning repo %q: create read the role from the caller workspace, not the selected target.\noutput:\n%s", contributorRepo, got)
		}
	})

	// contributor: the symmetric direction. Launched from a maintainer
	// workspace, selecting a contributor target, create must route to the
	// CONTRIBUTOR planning repo.
	t.Run("contributor_target", func(t *testing.T) {
		initConfigForTest(t)
		vrfyClearRoutingEnv(t)
		saveAndRestoreGlobals(t)
		ensureCleanGlobalState(t)
		readonlyMode = false
		t.Cleanup(func() { readonlyMode = false })
		store = nil

		tmp := t.TempDir()
		caller := filepath.Join(tmp, "caller")
		target := filepath.Join(tmp, "target")
		maintainerRepo := filepath.Join(tmp, "maintainer-planning")
		contributorRepo := filepath.Join(tmp, "contributor-planning")

		vrfyInitRepoWithRole(t, caller, "maintainer")
		vrfyInitRepoWithRole(t, target, "contributor")
		vrfyMakeBeadsProject(t, target)

		vrfySeedRouting(t, "auto", maintainerRepo, contributorRepo, "")

		vrfyChdir(t, caller)
		vrfySelectWithChangeDir(t, target)
		vrfyResetDiscoveryCaches(t)

		got := vrfyDriveCreatePreviewToRoutedTarget(t)
		if !strings.Contains(got, contributorRepo) {
			t.Fatalf("explicit `-C` create of a contributor target did not route to the contributor planning repo %q (the target's role was ignored).\noutput:\n%s", contributorRepo, got)
		}
		if strings.Contains(got, maintainerRepo) {
			t.Fatalf("explicit `-C` create routed to the maintainer planning repo %q: create bound to one side instead of the selected target's role.\noutput:\n%s", maintainerRepo, got)
		}
	})
}

// vrfyRoleNotConfiguredNotice is the stderr line bd prints when it looks up
// beads.role and finds none. It is the user-visible sign that a command ran
// role detection.
const vrfyRoleNotConfiguredNotice = "beads.role not configured"

// vrfyRoleLessWorkspace sets up a discovered workspace whose repo has no
// beads.role, and points git's global config at an empty directory so a
// developer's own ~/.config/git/config cannot supply one.
func vrfyRoleLessWorkspace(t *testing.T) string {
	t.Helper()
	tmp := t.TempDir()
	workspace := filepath.Join(tmp, "workspace")
	vrfyInitRepoWithRole(t, workspace, "")
	vrfyMakeBeadsProject(t, workspace)
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	vrfyChdir(t, workspace)
	vrfyResetDiscoveryCaches(t)
	return tmp
}

// TestVerifyRoleLookupOnlyWhenRoutingNeedsIt: when the routing config cannot
// pick a repo by role (routing off, or auto mode with no maintainer or
// contributor repo set), list/ready and create must not look up beads.role,
// so the "beads.role not configured" notice stays off stderr. When routing
// does need the role and none is set, the notice still shows.
func TestVerifyRoleLookupOnlyWhenRoutingNeedsIt(t *testing.T) {
	readCases := []struct {
		name        string
		mode        string
		maintainer  bool
		contributor bool
		wantNotice  bool
	}{
		{name: "read_routing_off", mode: "", maintainer: true, contributor: true, wantNotice: false},
		{name: "read_auto_without_role_repos", mode: "auto", wantNotice: false},
		{name: "read_auto_with_role_repos", mode: "auto", maintainer: true, contributor: true, wantNotice: true},
	}
	for _, tc := range readCases {
		t.Run(tc.name, func(t *testing.T) {
			initConfigForTest(t)
			vrfyClearRoutingEnv(t)
			tmp := vrfyRoleLessWorkspace(t)

			maintainerRepo, contributorRepo := "", ""
			if tc.maintainer {
				maintainerRepo = filepath.Join(tmp, "maintainer-planning")
			}
			if tc.contributor {
				contributorRepo = filepath.Join(tmp, "contributor-planning")
			}
			vrfySeedRouting(t, tc.mode, maintainerRepo, contributorRepo, "")

			var got string
			stderr := captureStderr(t, func() {
				got, _ = determineAutoRoutedRepoPath(context.Background(), nil)
			})
			hasNotice := strings.Contains(stderr, vrfyRoleNotConfiguredNotice)
			if hasNotice != tc.wantNotice {
				t.Fatalf("role notice on stderr = %v, want %v (mode=%q maintainer=%q contributor=%q)\nstderr:\n%s",
					hasNotice, tc.wantNotice, tc.mode, maintainerRepo, contributorRepo, stderr)
			}
			if !tc.wantNotice && got != "." {
				t.Fatalf("routing that cannot use a role resolved to %q, want the current repo %q", got, ".")
			}
		})
	}

	// The create command's own routing site, with routing off. routing.default
	// names an uninitialized repo so create stops at the routed-target refusal,
	// the same observable the other create checks read, instead of falling
	// through to the local store.
	t.Run("create_routing_off", func(t *testing.T) {
		initConfigForTest(t)
		vrfyClearRoutingEnv(t)
		saveAndRestoreGlobals(t)
		ensureCleanGlobalState(t)
		readonlyMode = false
		t.Cleanup(func() { readonlyMode = false })
		store = nil

		tmp := vrfyRoleLessWorkspace(t)
		defaultRepo := filepath.Join(tmp, "default-planning")
		vrfySeedRouting(t, "", filepath.Join(tmp, "maintainer-planning"), filepath.Join(tmp, "contributor-planning"), defaultRepo)

		got := vrfyDriveCreatePreviewToRoutedTarget(t)
		if !strings.Contains(got, defaultRepo) {
			t.Fatalf("create with routing off did not route to routing.default %q.\noutput:\n%s", defaultRepo, got)
		}
		if strings.Contains(got, vrfyRoleNotConfiguredNotice) {
			t.Fatalf("create with routing off still looked up beads.role.\noutput:\n%s", got)
		}
	})
}

// TestVerifyStartupSelectionUsesTargetRole: a project selected before the
// command runs - by a .beads/.env that exports BEADS_DIR, the persisted form of
// "export BEADS_DIR before running bd" - routes by the SELECTED target's role,
// the same as an explicit `bd -C`. Here the launch workspace is a contributor
// and the selected target is a maintainer, so routing must resolve to the
// maintainer planning repo.
//
// It drives the pre-existing selection-env loader that early startup uses to
// import a .beads/.env BEADS_DIR line. This check runs LAST in this file on
// purpose: importing a startup selection is a process-level fact the earlier
// in-CWD checks assume absent, and nothing in the pre-existing surface lets a
// test pop it back off, so it must not precede them.
func TestVerifyStartupSelectionUsesTargetRole(t *testing.T) {
	initConfigForTest(t)
	vrfyClearRoutingEnv(t)

	tmp := t.TempDir()
	caller := filepath.Join(tmp, "caller")
	target := filepath.Join(tmp, "target")
	maintainerRepo := filepath.Join(tmp, "maintainer-planning")
	contributorRepo := filepath.Join(tmp, "contributor-planning")

	vrfyInitRepoWithRole(t, caller, "contributor")
	vrfyInitRepoWithRole(t, target, "maintainer")
	targetBeads := vrfyMakeBeadsProject(t, target)

	// The launch workspace carries a .beads/.env that selects the target by
	// exporting BEADS_DIR - the persisted equivalent of setting the variable in
	// the shell before invoking bd.
	callerBeads := filepath.Join(caller, ".beads")
	if err := os.MkdirAll(callerBeads, 0o755); err != nil {
		t.Fatalf("mkdir caller .beads: %v", err)
	}
	if err := os.WriteFile(filepath.Join(callerBeads, ".env"), []byte("BEADS_DIR="+targetBeads+"\n"), 0o644); err != nil {
		t.Fatalf("write caller .env: %v", err)
	}

	vrfySeedRouting(t, "auto", maintainerRepo, contributorRepo, "")

	vrfyChdir(t, caller)

	// Import the selection the way early startup discovery does: this reads the
	// .env and exports BEADS_DIR (raw os.Setenv, no framework restore), so undo
	// it on cleanup to keep the export from leaking to any later binary check.
	t.Cleanup(func() { _ = os.Unsetenv("BEADS_DIR") })
	loadBeadsSelectionEnvFile(callerBeads)
	vrfyResetDiscoveryCaches(t)

	got, _ := determineAutoRoutedRepoPath(context.Background(), nil)
	if got != maintainerRepo {
		t.Fatalf("a startup BEADS_DIR selection of a maintainer target routed to %q, want the maintainer planning repo %q", got, maintainerRepo)
	}
}
