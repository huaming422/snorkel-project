package main

// Behavioral checks for role-based auto-routing in cmd/bd.
//
// Every check runs a real bd binary as a subprocess, built once from this
// package's source with the test binary's own build settings. Each project is
// created with `bd init` and uses embedded storage, so no server is needed and
// bd's own startup decides how a project was picked (bd -C, an exported
// BEADS_DIR, a .beads/.env selector, discovery from the working directory, or a
// .beads/redirect). Routing config is passed through the BD_ROUTING_*
// environment variables.
//
// The planning repos routing can pick are left uninitialized on purpose:
// `bd list` and `bd create --dry-run --parent` both refuse to open an
// uninitialized routed repo and name its path, and that path is what the
// routing checks read. The role-notice checks read the same output for the
// "beads.role not configured" warning.
//
// No check calls into cmd/bd's own functions, so how an implementation
// threads the selected project through the code is free. This file defines no
// TestMain and reuses existing package test helpers (runCmd, testTempDir,
// bdEnv, envWithout, bdModulePackage, bdSourceDir).

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"testing"

	"github.com/steveyegge/beads/internal/beads"
)

var (
	vrfyBDOnce sync.Once
	vrfyBDPath string
	vrfyBDErr  error
)

// vrfyBuildBD builds bd once per test binary. The build inherits GOFLAGS and
// CGO_ENABLED from the environment, the same settings the test binary was
// compiled with, so it reuses the warm build cache instead of compiling a
// second variant of the storage stack.
func vrfyBuildBD(t *testing.T) string {
	t.Helper()
	vrfyBDOnce.Do(func() {
		dir, err := testTempDir("bd-verify-*")
		if err != nil {
			vrfyBDErr = err
			return
		}
		vrfyBDPath = filepath.Join(dir, "bd")
		cmd := exec.Command("go", "build", "-o", vrfyBDPath, bdModulePackage)
		cmd.Dir = bdSourceDir
		if out, err := cmd.CombinedOutput(); err != nil {
			vrfyBDErr = fmt.Errorf("go build: %v\n%s", err, out)
		}
	})
	if vrfyBDErr != nil {
		t.Fatalf("build bd: %v", vrfyBDErr)
	}
	return vrfyBDPath
}

// vrfyInitRepoWithRole creates a git repository at dir and records a beads.role
// of its own ("" for none), so role detection reading from that repo returns a
// definite answer rather than falling through to the global-config / origin-URL
// fallbacks.
func vrfyInitRepoWithRole(t *testing.T, dir, role string) {
	t.Helper()
	if err := os.MkdirAll(dir, 0o755); err != nil {
		t.Fatalf("mkdir %s: %v", dir, err)
	}
	runCmd(t, dir, "git", "init")
	runCmd(t, dir, "git", "config", "user.email", "test@test.com")
	runCmd(t, dir, "git", "config", "user.name", "Test")
	runCmd(t, dir, "git", "config", "core.hooksPath", ".git/hooks")
	if role != "" {
		runCmd(t, dir, "git", "config", "beads.role", role)
	}
}

// vrfyRouting returns BD_ROUTING_* entries for the non-empty values only. A key
// left out stays unset, so bd falls back to its stored config, which is empty
// for a fresh `bd init` project.
func vrfyRouting(mode, maintainer, contributor, deflt string) []string {
	var env []string
	for _, kv := range [][2]string{
		{"BD_ROUTING_MODE", mode},
		{"BD_ROUTING_MAINTAINER", maintainer},
		{"BD_ROUTING_CONTRIBUTOR", contributor},
		{"BD_ROUTING_DEFAULT", deflt},
	} {
		if kv[1] != "" {
			env = append(env, kv[0]+"="+kv[1])
		}
	}
	return env
}

// vrfyFixture is one temp tree: an isolated HOME and the planning repo paths
// routing can choose between.
type vrfyFixture struct {
	bd              string
	root            string
	home            string
	maintainerRepo  string
	contributorRepo string
	defaultRepo     string
}

func vrfyNewFixture(t *testing.T) *vrfyFixture {
	t.Helper()
	root := t.TempDir()
	home := filepath.Join(root, "home")
	if err := os.MkdirAll(home, 0o755); err != nil {
		t.Fatalf("mkdir home: %v", err)
	}
	return &vrfyFixture{
		bd:              vrfyBuildBD(t),
		root:            root,
		home:            home,
		maintainerRepo:  filepath.Join(root, "maintainer-planning"),
		contributorRepo: filepath.Join(root, "contributor-planning"),
		defaultRepo:     filepath.Join(root, "default-planning"),
	}
}

// autoBoth is auto routing with both role repos configured.
func (f *vrfyFixture) autoBoth() []string {
	return vrfyRouting("auto", f.maintainerRepo, f.contributorRepo, "")
}

// project creates a git checkout at root/name with the given beads.role ("" for
// none) and runs `bd init` in it. Non-interactive init records
// beads.role=maintainer, so the role is written again afterwards, or removed
// when the case wants a checkout with no role. Returns the checkout path.
func (f *vrfyFixture) project(t *testing.T, name, role, prefix string) string {
	t.Helper()
	dir := filepath.Join(f.root, name)
	vrfyInitRepoWithRole(t, dir, role)
	cmd := exec.Command(f.bd, "init", "--quiet", "--prefix", prefix)
	cmd.Dir = dir
	cmd.Env = f.env(nil)
	if out, err := cmd.CombinedOutput(); err != nil {
		t.Fatalf("bd init in %s: %v\n%s", dir, err, out)
	}
	if role != "" {
		runCmd(t, dir, "git", "config", "beads.role", role)
		return dir
	}
	unset := exec.Command("git", "config", "--local", "--unset-all", "beads.role")
	unset.Dir = dir
	_ = unset.Run() // exit status 5 just means nothing was set
	check := exec.Command("git", "config", "--get", "beads.role")
	check.Dir = dir
	check.Env = f.env(nil)
	if out, err := check.Output(); err == nil {
		t.Fatalf("checkout %s still has beads.role %q after unset", dir, strings.TrimSpace(string(out)))
	}
	return dir
}

// checkout creates a git checkout at root/name with the given beads.role and
// no beads project of its own.
func (f *vrfyFixture) checkout(t *testing.T, name, role string) string {
	t.Helper()
	dir := filepath.Join(f.root, name)
	vrfyInitRepoWithRole(t, dir, role)
	return dir
}

// env is the subprocess environment: the package's bdEnv (which drops every
// inherited BEADS_* variable), a git global config scope inside the fixture,
// no inherited routing settings, and then extra.
func (f *vrfyFixture) env(extra []string) []string {
	env := bdEnv(f.home)
	for _, key := range []string{"XDG_CONFIG_HOME", "GIT_CONFIG_GLOBAL", "BD_ROUTING_MODE", "BD_ROUTING_MAINTAINER", "BD_ROUTING_CONTRIBUTOR", "BD_ROUTING_DEFAULT"} {
		env = envWithout(env, key)
	}
	env = append(env, "XDG_CONFIG_HOME="+filepath.Join(f.home, ".config"))
	return append(env, extra...)
}

// run executes bd in dir with the given extra environment and returns stdout
// and stderr together. A non-zero exit is expected whenever routing picks one
// of the uninitialized planning repos.
func (f *vrfyFixture) run(t *testing.T, dir string, extraEnv []string, args ...string) string {
	t.Helper()
	cmd := exec.Command(f.bd, args...)
	cmd.Dir = dir
	cmd.Env = f.env(extraEnv)
	out, _ := cmd.CombinedOutput()
	return string(out)
}

// command runs `bd list` or a `bd create --dry-run --parent <absent>` preview,
// with the given leading args (for example -C dir). The --parent makes the
// preview open the routed repo, which is where the refusal naming it comes from.
func (f *vrfyFixture) command(t *testing.T, which, dir string, extraEnv []string, lead ...string) string {
	t.Helper()
	args := append([]string{}, lead...)
	switch which {
	case "list":
		args = append(args, "list")
	case "create":
		args = append(args, "create", "--dry-run", "--parent", "bd-routingprobe-absent", "routing probe")
	default:
		t.Fatalf("unknown command %q", which)
	}
	return f.run(t, dir, extraEnv, args...)
}

// expectRoutedTo fails unless out names want and does not name other.
func expectRoutedTo(t *testing.T, what, out, want, other string) {
	t.Helper()
	if !strings.Contains(out, want) {
		t.Fatalf("%s did not route to %q.\noutput:\n%s", what, want, out)
	}
	if other != "" && strings.Contains(out, other) {
		t.Fatalf("%s routed to %q instead of %q.\noutput:\n%s", what, other, want, out)
	}
}

// forRole returns the planning repo for role and the one for the other role.
func (f *vrfyFixture) forRole(role string) (want, other string) {
	if role == "contributor" {
		return f.contributorRepo, f.maintainerRepo
	}
	return f.maintainerRepo, f.contributorRepo
}

// vrfyWriteRedirect gives checkout a .beads directory that holds only a
// redirect to storageBeads.
func vrfyWriteRedirect(t *testing.T, checkout, storageBeads string) {
	t.Helper()
	beadsDir := filepath.Join(checkout, ".beads")
	if err := os.MkdirAll(beadsDir, 0o755); err != nil {
		t.Fatalf("mkdir %s: %v", beadsDir, err)
	}
	if err := os.WriteFile(filepath.Join(beadsDir, beads.RedirectFileName), []byte(storageBeads+"\n"), 0o644); err != nil {
		t.Fatalf("write redirect: %v", err)
	}
}

var vrfyCommands = []string{"list", "create"}

// ---------------------------------------------------------------------------
// Explicit selection
// ---------------------------------------------------------------------------

// TestVerifyChangeDirUsesTargetRole: `bd -C <target>` routes list and create by
// the target checkout's beads.role, in both directions, while bd runs from a
// checkout with the opposite role.
func TestVerifyChangeDirUsesTargetRole(t *testing.T) {
	for _, tc := range []struct{ name, callerRole, targetRole string }{
		{"maintainer_target", "contributor", "maintainer"},
		{"contributor_target", "maintainer", "contributor"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			f := vrfyNewFixture(t)
			caller := f.checkout(t, "caller", tc.callerRole)
			target := f.project(t, "target", tc.targetRole, "tgt")
			want, other := f.forRole(tc.targetRole)
			for _, which := range vrfyCommands {
				t.Run(which, func(t *testing.T) {
					out := f.command(t, which, caller, f.autoBoth(), "-C", target)
					expectRoutedTo(t, "bd -C <"+tc.targetRole+" target> "+which, out, want, other)
				})
			}
		})
	}
}

// TestVerifyExportedBeadsDirUsesTargetRole: a BEADS_DIR that is already in the
// environment when bd starts selects the project the same way -C does, so
// routing follows that project's beads.role and not the launch checkout's.
func TestVerifyExportedBeadsDirUsesTargetRole(t *testing.T) {
	for _, tc := range []struct{ name, callerRole, targetRole string }{
		{"maintainer_target", "contributor", "maintainer"},
		{"contributor_target", "maintainer", "contributor"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			f := vrfyNewFixture(t)
			caller := f.checkout(t, "caller", tc.callerRole)
			target := f.project(t, "target", tc.targetRole, "tgt")
			env := append(f.autoBoth(), "BEADS_DIR="+filepath.Join(target, ".beads"))
			want, other := f.forRole(tc.targetRole)
			for _, which := range vrfyCommands {
				t.Run(which, func(t *testing.T) {
					out := f.command(t, which, caller, env)
					expectRoutedTo(t, "exported BEADS_DIR of a "+tc.targetRole+" target, "+which, out, want, other)
				})
			}
		})
	}
}

// TestVerifyEnvFileSelectionUsesTargetRole: a BEADS_DIR line in the launch
// project's .beads/.env picks the target project just like exporting it, so
// routing follows the target's beads.role. The launch checkout is a real beads
// project here, which is what lets bd find and read its .env at startup.
func TestVerifyEnvFileSelectionUsesTargetRole(t *testing.T) {
	f := vrfyNewFixture(t)
	caller := f.project(t, "caller", "contributor", "clr")
	target := f.project(t, "target", "maintainer", "tgt")
	envLine := "BEADS_DIR=" + filepath.Join(target, ".beads") + "\n"
	if err := os.WriteFile(filepath.Join(caller, ".beads", ".env"), []byte(envLine), 0o644); err != nil {
		t.Fatalf("write caller .env: %v", err)
	}
	for _, which := range vrfyCommands {
		t.Run(which, func(t *testing.T) {
			out := f.command(t, which, caller, f.autoBoth())
			expectRoutedTo(t, ".beads/.env selection of a maintainer target, "+which, out, f.maintainerRepo, f.contributorRepo)
		})
	}
}

// TestVerifyChangeDirToRedirectedCheckoutUsesItsRole: when -C names a checkout
// whose .beads/redirect sends storage to a different repo, the named checkout's
// beads.role decides routing, not the storage repo's and not the launch
// checkout's.
func TestVerifyChangeDirToRedirectedCheckoutUsesItsRole(t *testing.T) {
	f := vrfyNewFixture(t)
	caller := f.checkout(t, "caller", "contributor")
	storage := f.project(t, "storage", "contributor", "stg")
	workspace := f.checkout(t, "workspace", "maintainer")
	vrfyWriteRedirect(t, workspace, filepath.Join(storage, ".beads"))
	for _, which := range vrfyCommands {
		t.Run(which, func(t *testing.T) {
			out := f.command(t, which, caller, f.autoBoth(), "-C", workspace)
			expectRoutedTo(t, "bd -C <redirected maintainer checkout> "+which, out, f.maintainerRepo, f.contributorRepo)
		})
	}
}

// ---------------------------------------------------------------------------
// Discovery
// ---------------------------------------------------------------------------

// TestVerifyDiscoveryKeepsCwdRole: a project found by walking up from the
// working directory keeps routing list and create by that checkout's
// beads.role, including a checkout whose .beads/redirect sends storage to a
// repo with another role.
func TestVerifyDiscoveryKeepsCwdRole(t *testing.T) {
	t.Run("plain", func(t *testing.T) {
		f := vrfyNewFixture(t)
		workspace := f.project(t, "workspace", "maintainer", "wks")
		for _, which := range vrfyCommands {
			t.Run(which, func(t *testing.T) {
				out := f.command(t, which, workspace, f.autoBoth())
				expectRoutedTo(t, "discovered maintainer checkout, "+which, out, f.maintainerRepo, f.contributorRepo)
			})
		}
	})

	t.Run("through_redirect", func(t *testing.T) {
		f := vrfyNewFixture(t)
		storage := f.project(t, "storage", "contributor", "stg")
		workspace := f.checkout(t, "workspace", "maintainer")
		vrfyWriteRedirect(t, workspace, filepath.Join(storage, ".beads"))
		for _, which := range vrfyCommands {
			t.Run(which, func(t *testing.T) {
				out := f.command(t, which, workspace, f.autoBoth())
				expectRoutedTo(t, "discovered maintainer checkout redirected to contributor storage, "+which, out, f.maintainerRepo, f.contributorRepo)
			})
		}
	})
}

// ---------------------------------------------------------------------------
// Role lookup only when routing can use it
// ---------------------------------------------------------------------------

// vrfyRoleNotConfiguredNotice is the warning bd prints when it looks up
// beads.role and finds none. It is the user-visible sign that a command ran
// role detection.
const vrfyRoleNotConfiguredNotice = "beads.role not configured"

// vrfyRoutedStoreRefusal is how `bd list` reports a routed repo it cannot open.
const vrfyRoutedStoreRefusal = "failed to open routed store"

// TestVerifyRoleLookupOnlyWhenRoutingNeedsIt: in a discovered checkout with no
// beads.role, list and create must not look up the role when routing cannot
// pick a repo by it (routing off, or auto mode with neither routing.maintainer
// nor routing.contributor set), so the notice stays out of the output. When
// auto mode has at least one role repo, the lookup still runs and the notice
// shows.
func TestVerifyRoleLookupOnlyWhenRoutingNeedsIt(t *testing.T) {
	f := vrfyNewFixture(t)
	workspace := f.project(t, "workspace", "", "wks")

	// list cases. With wantNotice false, routing has nowhere to go, so list
	// must also stay on the local project.
	for _, tc := range []struct {
		name       string
		routing    []string
		wantNotice bool
	}{
		{"list_routing_off", vrfyRouting("", f.maintainerRepo, f.contributorRepo, ""), false},
		{"list_auto_without_role_repos", vrfyRouting("auto", "", "", ""), false},
		{"list_auto_with_role_repos", vrfyRouting("auto", f.maintainerRepo, f.contributorRepo, ""), true},
		{"list_auto_contributor_repo_only", vrfyRouting("auto", "", f.contributorRepo, ""), true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			out := f.command(t, "list", workspace, tc.routing)
			if got := strings.Contains(out, vrfyRoleNotConfiguredNotice); got != tc.wantNotice {
				t.Fatalf("role notice in output = %v, want %v (routing env %v)\noutput:\n%s", got, tc.wantNotice, tc.routing, out)
			}
			if !tc.wantNotice && strings.Contains(out, vrfyRoutedStoreRefusal) {
				t.Fatalf("list routed away although routing cannot use a role (routing env %v)\noutput:\n%s", tc.routing, out)
			}
		})
	}

	// create cases. routing.default names an uninitialized repo so the preview
	// stops at the routed-target refusal, which shows where create went.
	for _, tc := range []struct {
		name    string
		routing []string
	}{
		{"create_routing_off", vrfyRouting("", f.maintainerRepo, f.contributorRepo, f.defaultRepo)},
		{"create_auto_without_role_repos", vrfyRouting("auto", "", "", f.defaultRepo)},
	} {
		t.Run(tc.name, func(t *testing.T) {
			out := f.command(t, "create", workspace, tc.routing)
			expectRoutedTo(t, "create with routing env "+strings.Join(tc.routing, " "), out, f.defaultRepo, "")
			if strings.Contains(out, vrfyRoleNotConfiguredNotice) {
				t.Fatalf("create looked up beads.role although routing cannot use it (routing env %v)\noutput:\n%s", tc.routing, out)
			}
		})
	}
}

// TestVerifySingleRoleRepoStillRoutesByRole: auto mode with only one of
// routing.maintainer and routing.contributor set still routes by role, so a
// checkout with the matching role goes to that planning repo for list and
// create.
func TestVerifySingleRoleRepoStillRoutesByRole(t *testing.T) {
	for _, role := range []string{"contributor", "maintainer"} {
		t.Run(role+"_repo_only", func(t *testing.T) {
			f := vrfyNewFixture(t)
			workspace := f.project(t, "workspace", role, "wks")
			want, _ := f.forRole(role)
			routing := vrfyRouting("auto", "", f.contributorRepo, "")
			if role == "maintainer" {
				routing = vrfyRouting("auto", f.maintainerRepo, "", "")
			}
			for _, which := range vrfyCommands {
				t.Run(which, func(t *testing.T) {
					out := f.command(t, which, workspace, routing)
					expectRoutedTo(t, "auto mode with only routing."+role+" set, "+role+" checkout, "+which, out, want, "")
				})
			}
		})
	}
}
