## Task

Our file finder's watcher has no idea a file can move. A rename inside the watched folder reaches every subscriber as an unrelated removal and creation, so a subscriber watching where the file used to be is never told its new path. The ranking history we keep per path also stays behind on the old name.

Make the watcher recognize moves and report one event per move. Big batches are normal (branch switches, bulk deletes, editors writing temp files), and we'd rather miss a move than pair two unrelated files or give one file another file's history. How you decide two paths belong to one file is up to you.

Moves need to come through in every binding of our watch API: the C ABI, Rust, Python, Bun, and Node, with the TypeScript types for events describing them. Programs compiled against `fff.h` index the batch's event array directly, so an event entry keeps its current size and nothing already in the batch moves.

Use the repo's normal commands to build and run tests.

## User stories / requirements

- A file renamed within the watched folder arrives as one move event naming its old and new path, with no separate removal or creation. Subscribers on the old path, its old folder, or its new folder hear it. Moving a file out of the watched folder reports it as removed, naming no outside path.
- A renamed file brings its access history to its new path, so the file list ranks it as high as it did before the rename. The old path keeps its history as well, since the rename copies it instead of handing it over.
