#!/usr/bin/env bash
# No services to start and no data to seed. The image holds the full dependency
# closure of the task's base (cargo fetch --locked plus a complete
# `--no-default-features --features zlob --workspace --exclude fff-nvim
# --exclude fff-python --tests` build), so every crate the tests need is in the
# local cargo registry and builds work without a network.
set -euo pipefail

# Stop at once on a missing crate instead of waiting on a network that isn't
# there. The closure above makes this a no-op in practice.
export CARGO_NET_OFFLINE=true

echo "[test-setup] Rust version:    $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:   $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Zig version:     $(zig version 2>&1 | head -1)"
echo "[test-setup] Workspace root:  /repo/fff"
echo "[test-setup] CARGO_NET_OFFLINE=${CARGO_NET_OFFLINE}"
echo "[test-setup] Setup complete."
