//! Scenario code for the two move stories. A story file passes in the inputs
//! of all its cases and the index of the one to run, and gets back one string
//! per expected key. Each story builds one watched picker over one temporary
//! tree the first time a case runs and reuses it for the rest.

use fff_search::file_picker::{FFFMode, FilePicker};
use fff_search::{FilePickerOptions, FrecencyTracker, SharedFilePicker, SharedFrecency, WatchEvent, WatchOptions};
use serde_json::Value;
use std::collections::BTreeMap;
use std::fs;
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex, OnceLock};
use std::time::{Duration, Instant};
use tempfile::TempDir;

pub type Observed = BTreeMap<String, String>;
pub type MoveEnds = fn(&WatchEvent) -> Option<(PathBuf, PathBuf)>;

/// Scales a wall-clock limit by TIMEOUT_MULTIPLIER (never below 1).
pub fn limit(secs: f64) -> Duration {
    let factor = std::env::var("TIMEOUT_MULTIPLIER")
        .ok()
        .and_then(|value| value.parse::<f64>().ok())
        .filter(|value| *value >= 1.0)
        .unwrap_or(1.0);
    Duration::from_secs_f64(secs * factor)
}

fn wait_until(deadline: Duration, mut done: impl FnMut() -> bool) -> bool {
    let end = Instant::now() + deadline;
    while Instant::now() < end {
        if done() {
            return true;
        }
        std::thread::sleep(Duration::from_millis(25));
    }
    done()
}

fn text(inputs: &Value, key: &str) -> String {
    inputs[key]
        .as_str()
        .unwrap_or_else(|| panic!("input {key} is missing or not a string"))
        .to_string()
}

fn write(path: &Path, body: &str) {
    fs::create_dir_all(path.parent().unwrap()).unwrap();
    fs::write(path, body).unwrap();
}

/// A watched picker over `base`, tried a few times because the backend can
/// report not ready on a cold start.
fn watched_picker(base: &Path, frecency: &SharedFrecency) -> SharedFilePicker {
    for attempt in 0..5 {
        if attempt > 0 {
            std::thread::sleep(Duration::from_millis(500));
        }
        let picker = SharedFilePicker::default();
        let built = FilePicker::new_with_shared_state(
            picker.clone(),
            frecency.clone(),
            FilePickerOptions {
                base_path: base.to_string_lossy().into_owned(),
                mode: FFFMode::Neovim,
                watch: true,
                enable_mmap_cache: false,
                enable_content_indexing: false,
                ..Default::default()
            },
        );
        if built.is_err() {
            continue;
        }
        if picker.wait_for_scan(limit(30.0)) && picker.wait_for_watcher(limit(30.0)) {
            std::thread::sleep(Duration::from_millis(300));
            return picker;
        }
    }
    panic!("the watched picker didn't come up after 5 attempts");
}

struct Tree {
    base: PathBuf,
    outside: PathBuf,
    picker: SharedFilePicker,
    frecency: SharedFrecency,
    _dirs: Vec<TempDir>,
}

fn canonical_temp() -> (TempDir, PathBuf) {
    let dir = TempDir::new().expect("temp dir");
    let path = fff_search::path_utils::canonicalize(dir.path()).expect("canonical path");
    (dir, path)
}

static MOVE_TREE: OnceLock<Mutex<Tree>> = OnceLock::new();

/// Renames one file as the case says and reports what a subscription with the
/// case's pattern was told:
///   delivered: "move" when an event the adapter reads as a move names this
///              file, else "removed" when a plain removal of the old path
///              came, else "nothing";
///   ends:      "<old> -> <new>" from that move event, paths under the base,
///              or "none";
///   extra:     plain removed or created events for the moved file that came
///              along with the move, and any event naming a path outside the
///              tree, or "none".
pub fn observe_move(all_inputs: &[Value], index: usize, move_ends: MoveEnds) -> Observed {
    let tree = MOVE_TREE.get_or_init(|| {
        let (base_dir, base) = canonical_temp();
        let (outside_dir, outside) = canonical_temp();
        for inputs in all_inputs {
            let src = base.join(text(inputs, "src_rel"));
            write(&src, &format!("// {}\n", text(inputs, "src_rel")));
            write(&src.parent().unwrap().join("seed.txt"), "seed\n");
            if !inputs["dst_outside"].as_bool().unwrap_or(false) {
                let dst = base.join(text(inputs, "dst_rel"));
                write(&dst.parent().unwrap().join("seed.txt"), "seed\n");
            }
        }
        let frecency = SharedFrecency::noop();
        let picker = watched_picker(&base, &frecency);
        Mutex::new(Tree { base, outside, picker, frecency, _dirs: vec![base_dir, outside_dir] })
    });
    let tree = tree.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    let inputs = &all_inputs[index];
    let src_rel = text(inputs, "src_rel");
    let dst_rel = text(inputs, "dst_rel");
    let outside_move = inputs["dst_outside"].as_bool().unwrap_or(false);
    let src = tree.base.join(&src_rel);
    let dst = if outside_move { tree.outside.join(&dst_rel) } else { tree.base.join(&dst_rel) };

    let seen: Arc<Mutex<Vec<WatchEvent>>> = Arc::new(Mutex::new(Vec::new()));
    let sink = Arc::clone(&seen);
    let id = tree
        .picker
        .watch(&text(inputs, "watch_pattern"), WatchOptions::default(), move |_, events| {
            sink.lock().unwrap().extend_from_slice(events)
        })
        .expect("watch subscription");

    fs::rename(&src, &dst).expect("rename");

    let rel = |path: &Path| -> String {
        if let Ok(inner) = path.strip_prefix(&tree.base) {
            inner.to_string_lossy().replace('\\', "/")
        } else if let Ok(inner) = path.strip_prefix(&tree.outside) {
            format!("<outside>/{}", inner.to_string_lossy())
        } else {
            path.to_string_lossy().into_owned()
        }
    };
    let names_file = |ends: &(PathBuf, PathBuf)| {
        [rel(&ends.0), rel(&ends.1)]
            .iter()
            .any(|end| *end == src_rel || *end == dst_rel || end.ends_with(&format!("/{dst_rel}")))
    };
    let move_of_file = |events: &[WatchEvent]| {
        events.iter().filter_map(move_ends).find(|ends| names_file(ends))
    };
    wait_until(limit(10.0), || {
        let events = seen.lock().unwrap();
        move_of_file(&events).is_some()
            || events.iter().any(|e| e.kind.as_str() == "removed" && e.path == src)
    });
    std::thread::sleep(limit(0.5));
    tree.picker.unwatch(id);
    let events = seen.lock().unwrap().clone();

    let mut observed = Observed::new();
    match move_of_file(&events) {
        Some(ends) => {
            observed.insert("delivered".into(), "move".into());
            observed.insert("ends".into(), format!("{} -> {}", rel(&ends.0), rel(&ends.1)));
        }
        None => {
            let removed = events.iter().any(|e| e.kind.as_str() == "removed" && e.path == src);
            observed.insert("delivered".into(), if removed { "removed" } else { "nothing" }.into());
            observed.insert("ends".into(), "none".into());
        }
    }
    let outside_text = tree.outside.to_string_lossy().into_owned();
    let mut extra = Vec::new();
    for event in &events {
        if format!("{event:?}").contains(&outside_text) {
            extra.push(format!("outside path in {event:?}"));
        } else if observed["delivered"] == "move"
            && move_ends(event).is_none()
            && ((event.kind.as_str() == "removed" && event.path == src)
                || (event.kind.as_str() == "created" && event.path == dst))
        {
            extra.push(format!("{} {}", event.kind.as_str(), rel(&event.path)));
        }
    }
    observed.insert("extra".into(), if extra.is_empty() { "none".into() } else { extra.join("; ") });
    observed
}

static RANK_TREE: OnceLock<Mutex<Tree>> = OnceLock::new();

fn store_count(frecency: &SharedFrecency, path: &Path) -> usize {
    let guard = frecency.read().expect("frecency read lock");
    guard.as_ref().expect("frecency store").access_count(path).expect("access count")
}

fn store_score(frecency: &SharedFrecency, path: &Path) -> i64 {
    let guard = frecency.read().expect("frecency read lock");
    guard.as_ref().expect("frecency store").get_access_score(path, FFFMode::Neovim)
}

fn listed_score(picker: &SharedFilePicker, path: &Path) -> Option<i16> {
    let guard = picker.read().ok()?;
    guard.as_ref()?.get_file_by_path(path).map(|file| file.access_frecency_score)
}

/// Gives the case's file `access_count` accesses before the picker starts,
/// renames it inside the watched tree and reports:
///   dst_count:  accesses the ranking store holds for the new path;
///   src_count:  accesses it still holds for the old path;
///   same_score: "yes" when both paths now score the same in the store;
///   ranked:     "yes" when the picker's own list ranks the new path with that
///               history (a frecency score above zero), else "no".
pub fn observe_ranking(all_inputs: &[Value], index: usize) -> Observed {
    let tree = RANK_TREE.get_or_init(|| {
        let (base_dir, base) = canonical_temp();
        let (db_dir, _) = canonical_temp();
        let tracker = FrecencyTracker::open(db_dir.path().join("frecency.mdb")).expect("open frecency db");
        for inputs in all_inputs {
            let src = base.join(text(inputs, "src_rel"));
            write(&src, &format!("// {}\n", text(inputs, "src_rel")));
            let dst = base.join(text(inputs, "dst_rel"));
            write(&dst.parent().unwrap().join("seed.txt"), "seed\n");
            let accesses = inputs["access_count"].as_u64().expect("access_count");
            for _ in 0..accesses {
                tracker.track_access(&src).expect("track access");
            }
        }
        let frecency = SharedFrecency::default();
        frecency.init(tracker).expect("init frecency");
        let picker = watched_picker(&base, &frecency);
        Mutex::new(Tree { base: base.clone(), outside: base, picker, frecency, _dirs: vec![base_dir, db_dir] })
    });
    let tree = tree.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    let inputs = &all_inputs[index];
    let src = tree.base.join(text(inputs, "src_rel"));
    let dst = tree.base.join(text(inputs, "dst_rel"));
    let accesses = inputs["access_count"].as_u64().expect("access_count") as usize;

    fs::rename(&src, &dst).expect("rename");
    wait_until(limit(10.0), || {
        store_count(&tree.frecency, &dst) >= accesses
            && listed_score(&tree.picker, &dst).is_some_and(|score| score > 0)
    });

    let mut observed = Observed::new();
    observed.insert("dst_count".into(), store_count(&tree.frecency, &dst).to_string());
    observed.insert("src_count".into(), store_count(&tree.frecency, &src).to_string());
    let same = store_score(&tree.frecency, &dst) == store_score(&tree.frecency, &src);
    observed.insert("same_score".into(), if same { "yes" } else { "no" }.into());
    let ranked = listed_score(&tree.picker, &dst).is_some_and(|score| score > 0);
    observed.insert("ranked".into(), if ranked { "yes" } else { "no" }.into());
    observed
}
