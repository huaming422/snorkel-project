#!/usr/bin/env bash
# validation-setup.sh: environment for the cargo-test story files. Sourced by
# test.sh after tests/test-setup.sh and before the stories run. Idempotent.
#
# No services to start and no data to seed: the image holds the full dependency
# closure (cargo fetch --locked plus a complete `--no-default-features
# --features zlob --workspace` test build), so both stories build the crate
# from the local cargo registry. This script is sourced, so it must never call
# `exit` or `set -e`, which would end the parent shell.

# Keep cargo offline: crates.io can't be reached, and failing at once beats
# waiting on it.
export CARGO_NET_OFFLINE=true

# The driver's validation_params.rs helper parses the case file with
# serde_json, which fff-core only has as an indirect dependency (1.0.149 in
# Cargo.lock). Add it as a dev-dependency for the story build. The local
# registry already holds it, so the fetch stays offline. The tree's diff was
# recorded before this script runs, so the line isn't part of it.
FFF_CORE_TOML=/repo/fff/crates/fff-core/Cargo.toml
if [ -f "$FFF_CORE_TOML" ] && ! grep -q 'serde_json' "$FFF_CORE_TOML"; then
    printf '\n[dev-dependencies.serde_json]\nversion = "1.0.149"\n' >> "$FFF_CORE_TOML"
    (cd /repo/fff && cargo fetch --offline > /tmp/validation-setup-fetch.log 2>&1) \
        || echo "[validation-setup] WARNING: cargo fetch --offline failed, see /tmp/validation-setup-fetch.log" >&2
fi

# The `zlob` feature the stories enable is a Zig-compiled C glob library whose
# build.rs runs `zig build`; the image links zig into /usr/local/bin, and this
# puts it back on PATH if PATH was changed.
if ! command -v zig >/dev/null 2>&1; then
    if [ -x /usr/local/bin/zig ]; then
        export PATH="/usr/local/bin:${PATH}"
    elif [ -x /opt/zig/zig ]; then
        export PATH="/opt/zig:${PATH}"
    fi
fi

echo "[validation-setup] Rust:   $(rustc --version 2>&1 | head -1)"
echo "[validation-setup] Cargo:  $(cargo --version 2>&1 | head -1)"
if command -v zig >/dev/null 2>&1; then
    echo "[validation-setup] Zig:    $(zig version 2>&1 | head -1)"
else
    echo "[validation-setup] WARNING: zig not found on PATH; --features zlob will fail to build" >&2
fi
echo "[validation-setup] Workspace root:   /repo/fff"
echo "[validation-setup] cargo_package:    crates/fff-core (package fff-search)"
echo "[validation-setup] CARGO_NET_OFFLINE=${CARGO_NET_OFFLINE}"
echo "[validation-setup] ready."
