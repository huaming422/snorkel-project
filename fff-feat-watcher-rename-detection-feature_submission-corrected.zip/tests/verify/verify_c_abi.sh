#!/usr/bin/env bash
#
# The C ABI side of file moves.
#
# 1. Layout, checked with _Static_assert against crates/fff-c/include/fff.h:
#    the batch keeps events at offset 0 and count at offset 8, and an event
#    stays 16 bytes with path at 0 and kind at 8. Compiled C callers index
#    batch->events[i] with that 16-byte stride, so none of this may change.
# 2. A live run through the C watch API on a temporary tree: a new file comes
#    through as a plain entry, and a file renamed inside the tree comes through
#    as one entry of a new kind (not 0 to 3) whose path is one end of the move
#    while a fff_watch_events_* accessor returning a string gives the other
#    end. For the plain entry that accessor gives NULL, an empty string or
#    the entry's own path, and the move brings no plain removal of the old
#    path or creation of the new one. The probe reads both ends from path and
#    from every new accessor that returns a string.
#
# Runs from the repository root (/repo/fff).

set -euo pipefail

REPO_DIR="$(pwd)"
HEADER="crates/fff-c/include/fff.h"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

log() { printf '[c-abi] %s\n' "$*" >&2; }
fail() { printf '[c-abi] FAIL: %s\n' "$*" >&2; exit 1; }

MULT="${TIMEOUT_MULTIPLIER:-1}"
case "$MULT" in ''|*[!0-9]*) MULT=1 ;; esac
[ "$MULT" -ge 1 ] || MULT=1

[ -f "$HEADER" ] || fail "C header not found at $HEADER"

log "building the fff-c library..."
if ! cargo build -p fff-c --no-default-features --features zlob > "$WORK/cargo.log" 2>&1; then
    tail -80 "$WORK/cargo.log" >&2
    fail "cargo build -p fff-c failed"
fi
TARGET_ROOT="${CARGO_TARGET_DIR:-$REPO_DIR/target}"
LIBDIR=""
for cand in "$TARGET_ROOT/debug" "$REPO_DIR/target/debug"; do
    if ls "$cand"/libfff_c.so >/dev/null 2>&1; then LIBDIR="$cand"; break; fi
done
[ -n "$LIBDIR" ] || fail "libfff_c.so not found under $TARGET_ROOT/debug"

cat > "$WORK/layout.c" <<'C_EOF'
#include <fff.h>
#include <stddef.h>
_Static_assert(offsetof(struct FffWatchEventBatch, events) == 0, "batch.events must stay at offset 0");
_Static_assert(offsetof(struct FffWatchEventBatch, count) == 8, "batch.count must stay at offset 8");
_Static_assert(sizeof(struct FffWatchEvent) == 16, "FffWatchEvent must stay 16 bytes, the stride of batch->events");
_Static_assert(offsetof(struct FffWatchEvent, path) == 0, "event.path must stay at offset 0");
_Static_assert(offsetof(struct FffWatchEvent, kind) == 8, "event.kind must stay at offset 8");
int main(void) { return 0; }
C_EOF
log "checking the published layout..."
if ! clang -std=c11 -I crates/fff-c/include "$WORK/layout.c" -o "$WORK/layout" > "$WORK/layout_cc.log" 2>&1; then
    cat "$WORK/layout_cc.log" >&2
    fail "the layout of FffWatchEventBatch or FffWatchEvent changed"
fi

# Every fff_watch_events_* function in the header that returns a string,
# except the pre-existing get_path.
mapfile -t ACCESSORS < <(tr '\n' ' ' < "$HEADER" \
    | grep -oE 'char[[:space:]]*\*[[:space:]]*fff_watch_events_[A-Za-z0-9_]+[[:space:]]*\(' \
    | grep -oE 'fff_watch_events_[A-Za-z0-9_]+' | sort -u | grep -vx 'fff_watch_events_get_path' || true)
[ "${#ACCESSORS[@]}" -gt 0 ] || fail "the header has no new fff_watch_events_* function returning a path"
log "accessors returning a string: ${ACCESSORS[*]}"

{
    printf 'typedef const char *(*accessor_fn)(const struct FffWatchEventBatch *, uint32_t);\n'
    printf 'static const char *accessor_names[] = {'
    for a in "${ACCESSORS[@]}"; do printf '"%s", ' "$a"; done
    printf '};\nstatic accessor_fn accessors[] = {'
    for a in "${ACCESSORS[@]}"; do printf '(accessor_fn)%s, ' "$a"; done
    printf '};\n#define ACCESSOR_COUNT %d\n' "${#ACCESSORS[@]}"
} > "$WORK/accessors.h"

cat > "$WORK/probe.c" <<'C_EOF'
#define _DEFAULT_SOURCE
#include <fff.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include "accessors.h"

#define MAX_SEEN 4096
struct seen { char path[1024]; unsigned kind; int has[ACCESSOR_COUNT]; char other[ACCESSOR_COUNT][1024]; };
static struct seen seen[MAX_SEEN];
static int seen_count = 0;
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

static void on_batch(uint64_t watch_id, struct FffWatchEventBatch *batch, void *ud) {
    (void)watch_id; (void)ud;
    pthread_mutex_lock(&lock);
    uint32_t n = fff_watch_events_count(batch);
    for (uint32_t i = 0; i < n && seen_count < MAX_SEEN; i++) {
        struct seen *s = &seen[seen_count++];
        const char *p = fff_watch_events_get_path(batch, i);
        snprintf(s->path, sizeof s->path, "%s", p ? p : "");
        s->kind = fff_watch_events_get_kind(batch, i);
        for (int a = 0; a < ACCESSOR_COUNT; a++) {
            const char *o = accessors[a](batch, i);
            s->has[a] = o != NULL;
            snprintf(s->other[a], sizeof s->other[a], "%s", o ? o : "");
        }
    }
    pthread_mutex_unlock(&lock);
    fff_free_watch_events(batch);
}

static int ends_with(const char *s, const char *tail) {
    size_t a = strlen(s), b = strlen(tail);
    return a >= b && strcmp(s + a - b, tail) == 0;
}

/* Index of the plain entry for created_probe.txt, or -1. */
static int find_created(void) {
    for (int i = 0; i < seen_count; i++)
        if (ends_with(seen[i].path, "/created_probe.txt") && seen[i].kind <= 1) return i;
    return -1;
}

/* Accessor index that gives the other end of the move, or -1. */
static int find_move(const char *src, const char *dst) {
    for (int i = 0; i < seen_count; i++) {
        if (seen[i].kind <= 3) continue;
        for (int a = 0; a < ACCESSOR_COUNT; a++) {
            if (!seen[i].has[a]) continue;
            if ((strcmp(seen[i].path, dst) == 0 && strcmp(seen[i].other[a], src) == 0) ||
                (strcmp(seen[i].path, src) == 0 && strcmp(seen[i].other[a], dst) == 0))
                return a;
        }
    }
    return -1;
}

static void *bring_up(const char *dir) {
    struct FffResult *cr = fff_create_instance_with(&(struct FffCreateOptions){
        .version = FFF_CREATE_OPTIONS_VERSION, .base_path = dir,
        .enable_mmap_cache = false, .enable_content_indexing = false, .watch = true,
    });
    if (!cr->success) { fff_free_result(cr); return NULL; }
    void *picker = cr->handle; fff_free_result(cr);
    struct FffResult *r = fff_wait_for_scan(picker, 30000); fff_free_result(r);
    r = fff_wait_for_watcher(picker, 30000); fff_free_result(r);
    usleep(300 * 1000);
    r = fff_set_watch_callback(picker, on_batch, NULL);
    if (!r->success) { fff_free_result(r); fff_destroy(picker); return NULL; }
    fff_free_result(r);
    r = fff_watch(picker, NULL, NULL);
    if (!r->success) { fff_free_result(r); fff_destroy(picker); return NULL; }
    fff_free_result(r);
    return picker;
}

int main(int argc, char **argv) {
    int wait_steps = 100 * (argc > 1 ? atoi(argv[1]) : 1); /* 10 s per unit */
    char tmpl[] = "/tmp/fff-cabi-XXXXXX";
    char *dir = mkdtemp(tmpl);
    if (!dir) { fprintf(stderr, "mkdtemp failed\n"); return 1; }
    char path[1024], src[1024], dst[1024];
    snprintf(path, sizeof path, "%s/src", dir); mkdir(path, 0755);
    snprintf(path, sizeof path, "%s/moved", dir); mkdir(path, 0755);
    snprintf(path, sizeof path, "%s/moved/seed.txt", dir);
    FILE *f = fopen(path, "w"); fputs("seed\n", f); fclose(f);
    snprintf(src, sizeof src, "%s/src/moved_probe.txt", dir);
    snprintf(dst, sizeof dst, "%s/moved/moved_probe.txt", dir);
    f = fopen(src, "w"); fputs("moves later\n", f); fclose(f);

    void *picker = NULL;
    for (int attempt = 0; attempt < 5 && !picker; attempt++) {
        if (attempt) usleep(500 * 1000);
        picker = bring_up(dir);
    }
    if (!picker) { fprintf(stderr, "the watch backend didn't start after 5 attempts\n"); return 1; }

    snprintf(path, sizeof path, "%s/created_probe.txt", dir);
    f = fopen(path, "w"); fputs("hello\n", f); fclose(f);
    int created = -1;
    for (int i = 0; i < wait_steps && created < 0; i++) {
        usleep(100 * 1000);
        pthread_mutex_lock(&lock); created = find_created(); pthread_mutex_unlock(&lock);
    }
    if (created < 0) { fprintf(stderr, "no entry for a newly created file arrived\n"); fff_destroy(picker); return 1; }

    if (rename(src, dst) != 0) { perror("rename"); fff_destroy(picker); return 1; }
    int accessor = -1;
    for (int i = 0; i < wait_steps && accessor < 0; i++) {
        usleep(100 * 1000);
        pthread_mutex_lock(&lock); accessor = find_move(src, dst); pthread_mutex_unlock(&lock);
    }
    usleep(500 * 1000);
    fff_destroy(picker);

    int status = 0;
    if (accessor < 0) {
        fprintf(stderr, "FAIL: no entry of a new kind named both %s and %s through an accessor\n", src, dst);
        for (int i = 0; i < seen_count; i++) {
            fprintf(stderr, "  seen kind=%u path=%s", seen[i].kind, seen[i].path);
            for (int a = 0; a < ACCESSOR_COUNT; a++) fprintf(stderr, " %s=%s", accessor_names[a], seen[i].has[a] ? seen[i].other[a] : "NULL");
            fprintf(stderr, "\n");
        }
        return 1;
    }
    fprintf(stderr, "move read through %s\n", accessor_names[accessor]);
    if (seen[created].has[accessor] && seen[created].other[accessor][0] != '\0' &&
        strcmp(seen[created].other[accessor], seen[created].path) != 0) {
        fprintf(stderr, "FAIL: %s returned \"%s\" for a newly created file, which has no other end\n",
                accessor_names[accessor], seen[created].other[accessor]);
        status = 1;
    }
    for (int i = 0; i < seen_count; i++) {
        if ((seen[i].kind == 2 && strcmp(seen[i].path, src) == 0) ||
            (seen[i].kind == 0 && strcmp(seen[i].path, dst) == 0)) {
            fprintf(stderr, "FAIL: the move also came as a plain entry kind=%u path=%s\n", seen[i].kind, seen[i].path);
            status = 1;
        }
    }
    return status;
}
C_EOF

log "compiling the live probe..."
if ! clang -std=c11 -Wno-incompatible-function-pointer-types -I crates/fff-c/include -I "$WORK" \
        "$WORK/probe.c" -L "$LIBDIR" -lfff_c -lpthread -ldl -lm -o "$WORK/probe" > "$WORK/probe_cc.log" 2>&1; then
    tail -60 "$WORK/probe_cc.log" >&2
    fail "could not compile the probe against the published header"
fi
log "running the live probe..."
if ! LD_LIBRARY_PATH="$LIBDIR" "$WORK/probe" "$MULT"; then
    fail "the C watch API didn't report the move as described above"
fi
log "PASS"
