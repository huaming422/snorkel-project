#!/usr/bin/env bash
#
# The Bun binding side of file moves, run live.
#
# Builds the fff-c library from the tree and copies packages/fff-bun (its src
# folder and package.json) into a scratch checkout with the library in its bin
# folder and a Cargo.toml two levels up, so the package's own findBinary picks
# the library up. Then js_watch_probe.mjs renames a file through the package's
# FileFinder.watch in Bun, which runs the TypeScript as it is.
#
# Runs from the repository root (/repo/fff).

set -euo pipefail

REPO_DIR="$(pwd)"
HERE="$(cd "$(dirname "$0")" && pwd)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

log() { printf '[bun] %s\n' "$*" >&2; }
fail() { printf '[bun] FAIL: %s\n' "$*" >&2; exit 1; }

MULT="${TIMEOUT_MULTIPLIER:-1}"
case "$MULT" in ''|*[!0-9]*) MULT=1 ;; esac
[ "$MULT" -ge 1 ] || MULT=1

command -v bun >/dev/null || fail "bun is not on PATH"

log "building the fff-c library..."
if ! cargo build -p fff-c --no-default-features --features zlob > "$WORK/cargo.log" 2>&1; then
    tail -80 "$WORK/cargo.log" >&2
    fail "cargo build -p fff-c failed"
fi
LIB="${CARGO_TARGET_DIR:-$REPO_DIR/target}/debug/libfff_c.so"
[ -f "$LIB" ] || fail "libfff_c.so not found at $LIB"

PKG="$WORK/checkout/packages/fff-bun"
mkdir -p "$PKG/bin"
touch "$WORK/checkout/Cargo.toml"
cp packages/fff-bun/package.json "$PKG/"
cp -r packages/fff-bun/src "$PKG/src"
cp "$LIB" "$PKG/bin/libfff_c.so"
[ -f "$PKG/src/index.ts" ] || fail "packages/fff-bun/src has no index.ts"

log "running the live probe in bun $(bun --version)..."
if ! bun "$HERE/js_watch_probe.mjs" "$PKG/src/index.ts" "$MULT"; then
    fail "the Bun binding didn't report the move as described in js_watch_probe.mjs"
fi
log "PASS"
