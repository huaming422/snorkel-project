#!/usr/bin/env bash
#
# The TypeScript types of file moves in packages/shared, packages/fff-node
# and packages/fff-bun, read with comments removed. What the Node and Bun
# decoders put on an event is run live by verify_node_watch.sh and
# verify_bun_watch.sh.
#
# For each of the three fff-api.ts files:
#   * the WatchEventKind union has a kind beyond created, modified, removed
#     and rescan;
#   * the WatchEvent type has a property beyond path and kind for the other
#     end of a move (an optional field, or a field of a move variant).
#
# Runs from the repository root (/repo/fff).

set -euo pipefail

PY="${VERIFIER_PYTHON:-/opt/tooling/venv/bin/python}"

"$PY" - <<'PY_EOF'
import re
import sys
from pathlib import Path

BASE_KINDS = {"created", "modified", "removed", "rescan"}
problems = []


def code_of(path):
    text = Path(path).read_text()
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    return "\n".join(re.sub(r"(^|[^:\"'])//.*$", r"\1", line) for line in text.splitlines())


def union_kinds(code):
    match = re.search(r"type\s+WatchEventKind\s*=(.*?);", code, re.S)
    return set(re.findall(r'"([^"]+)"', match.group(1))) if match else set()


def declaration(code, pattern):
    """Text of a declaration from its name to the `;` or `}` that ends it at
    brace depth 0."""
    match = re.search(pattern, code)
    if not match:
        return None
    depth = 0
    for index in range(match.end(), len(code)):
        char = code[index]
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0 and pattern.startswith("interface"):
                return code[match.end():index]
        elif char == ";" and depth == 0:
            return code[match.end():index]
    return code[match.end():]


def event_has_other_end(code):
    for pattern in (r"interface\s+WatchEvent\b[^{]*", r"type\s+WatchEvent\s*="):
        body = declaration(code, pattern)
        if body is None:
            continue
        props = re.findall(r"([A-Za-z_]\w*)\??\s*:\s*(?:string|[A-Za-z_]\w*)", body)
        if any(p not in ("path", "kind") for p in props):
            return True
    return False


for package, api in [("shared", "packages/shared/fff-api.ts"),
                     ("node", "packages/fff-node/src/fff-api.ts"),
                     ("bun", "packages/fff-bun/src/fff-api.ts")]:
    if not Path(api).exists():
        problems.append(f"{api} is missing")
        continue
    code = code_of(api)
    kinds = union_kinds(code)
    extra = kinds - BASE_KINDS
    if not extra:
        problems.append(f"{api}: WatchEventKind has no kind beyond {sorted(BASE_KINDS)} (found {sorted(kinds)})")
    if not event_has_other_end(code):
        problems.append(f"{api}: WatchEvent has no property beyond path and kind for a move")

if problems:
    for problem in problems:
        print(f"[ts] FAIL: {problem}", file=sys.stderr)
    sys.exit(1)
print("[ts] PASS", file=sys.stderr)
PY_EOF
