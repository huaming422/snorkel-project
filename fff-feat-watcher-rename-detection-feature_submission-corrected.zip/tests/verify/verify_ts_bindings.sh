#!/usr/bin/env bash
#
# The TypeScript types of file moves in packages/shared, packages/fff-node
# and packages/fff-bun, read with comments removed. What the Node and Bun
# decoders put on an event is run live by verify_node_watch.sh and
# verify_bun_watch.sh.
#
# For each of the three fff-api.ts files:
#   * an event can carry a kind beyond created, modified, removed and rescan,
#     either in the WatchEventKind union or as the kind of a move type;
#   * the WatchEvent type has a property beyond path and kind for the other
#     end of a move.
# WatchEvent can be an interface, an object type, or a union or intersection
# of them. Named members are followed to their own declarations, through
# type aliases and interfaces they extend, in any order in the file.
#
# Runs from the repository root (/repo/fff).

set -euo pipefail

PY="${VERIFIER_PYTHON:-/opt/tooling/venv/bin/python}"

"$PY" - <<'PY_EOF'
import re
import sys
from pathlib import Path

BASE_KINDS = {"created", "modified", "removed", "rescan"}
OPEN = "{([<"
CLOSE = "})]>"
STATEMENT = re.compile(r"\n\s*(?:export|type|interface|declare|const|let|function|class|enum|import)\b")
problems = []


def code_of(path):
    text = Path(path).read_text()
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    return "\n".join(re.sub(r"(^|[^:\"'])//.*$", r"\1", line) for line in text.splitlines())


def closing(code, start):
    """Index of the bracket that closes the one at `start`."""
    depth = 0
    for index in range(start, len(code)):
        char = code[index]
        if char == "=" and code[index + 1:index + 2] == ">":
            continue
        if char in OPEN:
            depth += 1
        elif char in CLOSE and not (char == ">" and code[index - 1:index] == "="):
            depth -= 1
            if depth == 0:
                return index
    return len(code)


def declarations(code):
    """Type aliases and interfaces by name: ("type", text) or ("interface", body, heritage)."""
    found = {}
    for match in re.finditer(r"\b(interface|type)\s+([A-Za-z_$][\w$]*)", code):
        kind, name = match.groups()
        index = match.end()
        if code[index:index + 1] == "<":
            index = closing(code, index) + 1
        if kind == "interface":
            brace = code.find("{", index)
            if brace < 0:
                continue
            end = closing(code, brace)
            found.setdefault(name, ("interface", code[brace + 1:end], code[index:brace]))
            continue
        rest = code[index:].lstrip()
        if not rest.startswith("="):
            continue
        start = code.index("=", index) + 1
        depth = 0
        end = len(code)
        index = start
        while index < len(code):
            char = code[index]
            if char == "=" and code[index + 1:index + 2] == ">":
                index += 2
                continue
            if char in OPEN:
                depth += 1
            elif char in CLOSE:
                depth -= 1
            elif depth == 0 and (char == ";" or (char == "\n" and STATEMENT.match(code, index))):
                end = index
                break
            index += 1
        found.setdefault(name, ("type", code[start:end]))
    return found


def split_top(text, separators):
    parts, depth, current = [], 0, []
    index = 0
    while index < len(text):
        char = text[index]
        if char == "=" and text[index + 1:index + 2] == ">":
            current.append("=>")
            index += 2
            continue
        if char in OPEN:
            depth += 1
        elif char in CLOSE:
            depth -= 1
        if depth == 0 and char in separators:
            parts.append("".join(current))
            current = []
        else:
            current.append(char)
        index += 1
    parts.append("".join(current))
    return [part.strip() for part in parts if part.strip()]


def members_of_body(body):
    """Top-level members of an object type body as (name, type text)."""
    out = []
    for member in split_top(body, ";,\n"):
        match = re.match(r"(?:readonly\s+)?[\"']?([A-Za-z_$][\w$]*)[\"']?\s*\??\s*:(.*)$", member, re.S)
        if match:
            out.append((match.group(1), match.group(2).strip()))
    return out


class Shape:
    def __init__(self):
        self.props = set()
        self.kind_types = []


def resolve_type(text, decls, shape, seen):
    text = text.strip()
    if not text:
        return
    parts = split_top(text, "|&")
    if len(parts) > 1:
        for part in parts:
            resolve_type(part, decls, shape, seen)
        return
    if text.startswith("(") and closing(text, 0) == len(text) - 1:
        resolve_type(text[1:-1], decls, shape, seen)
        return
    if text.startswith("{"):
        for name, kind_text in members_of_body(text[1:closing(text, 0)]):
            shape.props.add(name)
            if name == "kind":
                shape.kind_types.append(kind_text)
        return
    match = re.match(r"([A-Za-z_$][\w$]*)", text)
    if match:
        resolve_name(match.group(1), decls, shape, seen)


def resolve_name(name, decls, shape, seen):
    if name in seen or name not in decls:
        return
    seen.add(name)
    entry = decls[name]
    if entry[0] == "type":
        resolve_type(entry[1], decls, shape, seen)
        return
    _, body, heritage = entry
    for member, kind_text in members_of_body(body):
        shape.props.add(member)
        if member == "kind":
            shape.kind_types.append(kind_text)
    extends = re.search(r"\bextends\b(.*)$", heritage, re.S)
    if extends:
        for parent in split_top(extends.group(1), ","):
            resolve_type(parent, decls, shape, seen)


def literals(text, decls, seen):
    found = set(re.findall(r"[\"']([^\"']+)[\"']", text))
    for part in split_top(text, "|"):
        name = re.fullmatch(r"\s*([A-Za-z_$][\w$]*)\s*", part)
        if name and name.group(1) not in seen and name.group(1) in decls:
            seen.add(name.group(1))
            entry = decls[name.group(1)]
            if entry[0] == "type":
                found |= literals(entry[1], decls, seen)
    return found


for package, api in [("shared", "packages/shared/fff-api.ts"),
                     ("node", "packages/fff-node/src/fff-api.ts"),
                     ("bun", "packages/fff-bun/src/fff-api.ts")]:
    if not Path(api).exists():
        problems.append(f"{api} is missing")
        continue
    code = code_of(api)
    decls = declarations(code)
    if "WatchEvent" not in decls:
        problems.append(f"{api}: no WatchEvent type")
        continue
    shape = Shape()
    resolve_name("WatchEvent", decls, shape, set())
    kinds = set()
    if "WatchEventKind" in decls:
        kinds |= literals(decls["WatchEventKind"][1] if decls["WatchEventKind"][0] == "type" else "", decls, {"WatchEventKind"})
    for kind_text in shape.kind_types:
        kinds |= literals(kind_text, decls, set())
    if not kinds - BASE_KINDS:
        problems.append(f"{api}: no event kind beyond {sorted(BASE_KINDS)} (found {sorted(kinds)})")
    if not shape.props - {"path", "kind"}:
        problems.append(f"{api}: WatchEvent has no property beyond path and kind for a move (found {sorted(shape.props)})")

if problems:
    for problem in problems:
        print(f"[ts] FAIL: {problem}", file=sys.stderr)
    sys.exit(1)
print("[ts] PASS", file=sys.stderr)
PY_EOF
