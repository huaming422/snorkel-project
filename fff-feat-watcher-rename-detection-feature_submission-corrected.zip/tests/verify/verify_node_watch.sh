#!/usr/bin/env bash
#
# The Node binding side of file moves, run live.
#
# Builds the fff-c library from the tree, turns the TypeScript of
# packages/fff-node/src into JavaScript with esbuild (no type check, no
# bundling), and lays it out the way a dev checkout has it: the package with
# its package.json, the library in its bin folder and a Cargo.toml two levels
# up, so the package's own findBinary picks the library up. ffi-rs comes from
# /opt/jsdeps. Then js_watch_probe.mjs renames a file through the package's
# FileFinder.watch in Node.
#
# Runs from the repository root (/repo/fff).

set -euo pipefail

REPO_DIR="$(pwd)"
HERE="$(cd "$(dirname "$0")" && pwd)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

log() { printf '[node] %s\n' "$*" >&2; }
fail() { printf '[node] FAIL: %s\n' "$*" >&2; exit 1; }

MULT="${TIMEOUT_MULTIPLIER:-1}"
case "$MULT" in ''|*[!0-9]*) MULT=1 ;; esac
[ "$MULT" -ge 1 ] || MULT=1

command -v node >/dev/null || fail "node is not on PATH"
[ -d /opt/jsdeps/node_modules/ffi-rs ] || fail "ffi-rs isn't installed under /opt/jsdeps"
ESBUILD=/opt/jsdeps/node_modules/.bin/esbuild
[ -x "$ESBUILD" ] || fail "esbuild isn't installed under /opt/jsdeps"

log "building the fff-c library..."
if ! cargo build -p fff-c --no-default-features --features zlob > "$WORK/cargo.log" 2>&1; then
    tail -80 "$WORK/cargo.log" >&2
    fail "cargo build -p fff-c failed"
fi
LIB="${CARGO_TARGET_DIR:-$REPO_DIR/target}/debug/libfff_c.so"
[ -f "$LIB" ] || fail "libfff_c.so not found at $LIB"

PKG="$WORK/checkout/packages/fff-node"
mkdir -p "$PKG/dist" "$PKG/bin"
touch "$WORK/checkout/Cargo.toml"
cp packages/fff-node/package.json "$PKG/"
cp "$LIB" "$PKG/bin/libfff_c.so"
ln -s /opt/jsdeps/node_modules "$WORK/checkout/node_modules"

log "turning packages/fff-node/src into JavaScript..."
if ! "$ESBUILD" packages/fff-node/src/*.ts --outdir="$PKG/dist" --format=esm --platform=node \
        --target=node24 --log-level=warning > "$WORK/esbuild.log" 2>&1; then
    tail -40 "$WORK/esbuild.log" >&2
    fail "esbuild could not read packages/fff-node/src"
fi
[ -f "$PKG/dist/index.js" ] || fail "packages/fff-node/src has no index.ts"

log "running the live probe in node $(node --version)..."
if ! node "$HERE/js_watch_probe.mjs" "$PKG/dist/index.js" "$MULT"; then
    fail "the Node binding didn't report the move as described in js_watch_probe.mjs"
fi
log "PASS"
