#!/usr/bin/env bash
#
# The Python binding side of file moves, run live.
#
# Builds the fff-python extension from the tree, loads it with the Python
# package sources in packages/fff-python/src, and watches a temporary tree
# through fff.FileFinder.watch. A new file has to come through first, then a
# file renamed inside the tree has to come through as one event whose kind is
# none of created, modified, removed or rescan, whose path is one end of the
# move and which carries the other end in a public attribute. For the new file
# that attribute is None, empty or the file's own path, and the move brings no
# plain removal of the old path or creation of the new one. The probe looks for
# the other end in every public attribute.
#
# Runs from the repository root (/repo/fff).

set -euo pipefail

REPO_DIR="$(pwd)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
PY="${VERIFIER_PYTHON:-/opt/tooling/venv/bin/python}"

log() { printf '[python] %s\n' "$*" >&2; }
fail() { printf '[python] FAIL: %s\n' "$*" >&2; exit 1; }

log "building the fff-python extension..."
if ! PYO3_PYTHON="$PY" cargo build -p fff-python --no-default-features --features zlob \
        > "$WORK/cargo.log" 2>&1; then
    tail -80 "$WORK/cargo.log" >&2
    fail "cargo build -p fff-python failed"
fi
TARGET_ROOT="${CARGO_TARGET_DIR:-$REPO_DIR/target}"
LIB="$TARGET_ROOT/debug/libfff_python.so"
[ -f "$LIB" ] || fail "libfff_python.so not found under $TARGET_ROOT/debug"

mkdir -p "$WORK/pkg/fff"
cp packages/fff-python/src/fff/*.py "$WORK/pkg/fff/"
cp "$LIB" "$WORK/pkg/fff/_fff_python.abi3.so"

cat > "$WORK/probe.py" <<'PY_EOF'
import os
import sys
import tempfile
import threading
import time
from pathlib import Path

sys.path.insert(0, sys.argv[1])
from fff import FileFinder  # noqa: E402

try:
    MULT = max(1.0, float(os.environ.get("TIMEOUT_MULTIPLIER") or 1))
except ValueError:
    MULT = 1.0
BASELINE = {"created", "modified", "removed", "rescan"}

root = Path(tempfile.mkdtemp(prefix="fff-py-move-")).resolve()
(root / "src").mkdir()
(root / "moved").mkdir()
(root / "moved" / "seed.txt").write_text("seed\n")
src = root / "src" / "py_mover.txt"
src.write_text("moves later\n")
dst = root / "moved" / "py_mover.txt"
created = root / "py_created.txt"

events = []
lock = threading.Lock()


def on_events(batch):
    with lock:
        events.extend(batch)


def wait(condition, seconds):
    deadline = time.monotonic() + seconds * MULT
    while time.monotonic() < deadline:
        with lock:
            found = condition()
        if found is not None:
            return found
        time.sleep(0.05)
    with lock:
        return condition()


def other_ends(ev):
    """Public attributes other than path and kind, with their values."""
    found = {}
    for name in dir(ev):
        if name.startswith("_") or name in ("path", "kind"):
            continue
        value = getattr(ev, name)
        if callable(value):
            continue
        found[name] = value
    return found


with FileFinder(str(root), watch=True, enable_content_indexing=False) as finder:
    assert finder.wait_for_scan_blocking(timeout_ms=int(30000 * MULT)), "scan didn't finish"
    deadline = time.monotonic() + 30 * MULT
    while not finder.scan_progress.is_watcher_ready:
        assert time.monotonic() < deadline, "watcher never became ready"
        time.sleep(0.05)
    time.sleep(0.5)
    finder.watch("", on_events)

    created.write_text("hello\n")
    new_event = wait(
        lambda: next((e for e in events if e.path == str(created) and e.kind in ("created", "modified")), None),
        10,
    )
    assert new_event is not None, f"no event for a new file, got {events!r}"

    os.rename(src, dst)

    def find_move():
        for e in events:
            if e.kind in BASELINE:
                continue
            for name, value in other_ends(e).items():
                if {e.path, value} == {str(src), str(dst)}:
                    return (e, name)
        return None

    found = wait(find_move, 10)
    time.sleep(0.5 * MULT)
    with lock:
        seen = list(events)
    assert found is not None, f"no move event naming {src} and {dst}, got {seen!r}"
    move, name = found
    print(f"move read through WatchEvent.{name}: {move!r}", file=sys.stderr)
    assert getattr(new_event, name) in (None, "", new_event.path), (
        f"WatchEvent.{name} is {getattr(new_event, name)!r} for a new file, which has no other end"
    )
    pair = [
        e for e in seen
        if (e.kind == "removed" and e.path == str(src)) or (e.kind == "created" and e.path == str(dst))
    ]
    assert not pair, f"the move also came as plain events: {pair!r}"
print("ok", file=sys.stderr)
PY_EOF

log "running the live probe..."
if ! "$PY" "$WORK/probe.py" "$WORK/pkg"; then
    fail "the Python binding didn't report the move as described above"
fi
log "PASS"
