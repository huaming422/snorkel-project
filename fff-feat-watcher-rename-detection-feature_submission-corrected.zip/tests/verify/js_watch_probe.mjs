// A live rename through a JavaScript binding's FileFinder.watch, used by
// verify_node_watch.sh (Node) and verify_bun_watch.sh (Bun).
//
// Usage: <runtime> js_watch_probe.mjs <module that exports FileFinder> <timeout multiplier>
//
// A new file has to come through first. Then a file renamed inside the tree
// has to come through as one event whose kind is none of created, modified,
// removed or rescan, whose path is one end of the move and which holds the
// other end in another property. For the new file that property is missing,
// null, empty or the file's own path, and the move brings no plain removal of
// the old path or creation of the new one. The probe looks for the other end
// in every property of the event.

import { mkdirSync, mkdtempSync, realpathSync, renameSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

const [modulePath, multiplierArg] = process.argv.slice(2);
const MULT = Math.max(1, Number(multiplierArg) || Number(process.env.TIMEOUT_MULTIPLIER) || 1);
const BASELINE = new Set(["created", "modified", "removed", "rescan"]);

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function waitFor(condition, seconds) {
  const end = Date.now() + seconds * 1000 * MULT;
  while (Date.now() < end) {
    const value = condition();
    if (value) return value;
    await sleep(50);
  }
  return condition();
}
function fail(message) {
  console.error(`FAIL: ${message}`);
  process.exit(1);
}

const { FileFinder } = await import(modulePath);

const root = realpathSync(mkdtempSync(join(tmpdir(), "fff-js-move-")));
const dbDir = mkdtempSync(join(tmpdir(), "fff-js-db-"));
mkdirSync(join(root, "src"));
mkdirSync(join(root, "moved"));
writeFileSync(join(root, "moved", "seed.txt"), "seed\n");
const src = join(root, "src", "js_mover.txt");
const dst = join(root, "moved", "js_mover.txt");
const created = join(root, "js_created.txt");
writeFileSync(src, "moves later\n");

const made = FileFinder.create({
  basePath: root,
  frecencyDbPath: join(dbDir, "frecency.mdb"),
  historyDbPath: join(dbDir, "history.mdb"),
});
if (!made.ok) fail(`FileFinder.create: ${made.error}`);
const finder = made.value;

const scan = await finder.waitForScan(30000 * MULT);
if (!scan.ok || !scan.value) fail("the initial scan didn't finish");
const ready = await waitFor(() => {
  const progress = finder.getScanProgress();
  return progress.ok && progress.value.isWatcherReady;
}, 30);
if (!ready) fail("the watcher never became ready");
await sleep(500);

const events = [];
const subscription = finder.watch((batch) => {
  events.push(...batch);
});
if (!subscription.ok) fail(`watch: ${subscription.error}`);

writeFileSync(created, "hello\n");
const newEvent = await waitFor(
  () => events.find((e) => e.path === created && (e.kind === "created" || e.kind === "modified")),
  10,
);
if (!newEvent) fail(`no event for a new file, got ${JSON.stringify(events)}`);

renameSync(src, dst);

const otherKeys = (event) => {
  const keys = [];
  for (const key in event) if (key !== "path" && key !== "kind") keys.push(key);
  return keys;
};
const findMove = () => {
  for (const event of events) {
    if (BASELINE.has(event.kind)) continue;
    for (const key of otherKeys(event)) {
      const value = event[key];
      if ((event.path === dst && value === src) || (event.path === src && value === dst)) {
        return [event, key];
      }
    }
  }
  return null;
};
const found = await waitFor(findMove, 10);
await sleep(500 * MULT);
if (!found) fail(`no move event naming both ${src} and ${dst}, got ${JSON.stringify(events)}`);
const [move, key] = found;
console.error(`move read through ${key}: ${JSON.stringify(move)}`);

const onNew = newEvent[key];
if (!(onNew === undefined || onNew === null || onNew === "" || onNew === newEvent.path)) {
  fail(`${key} is ${JSON.stringify(onNew)} for a new file, which has no other end`);
}
const pair = events.filter(
  (e) => (e.kind === "removed" && e.path === src) || (e.kind === "created" && e.path === dst),
);
if (pair.length) fail(`the move also came as plain events: ${JSON.stringify(pair)}`);

console.error("ok");
process.exit(0);
