//! File moves seen through the public watcher of fff-search.
//!
//! Every case drives a real watched picker over a temporary tree and reads the
//! result the way a subscriber or the file list does. A move event is one whose
//! kind string isn't created, modified, removed or rescan, and the two paths it
//! names are read from its Debug text.

use fff_search::file_picker::{FFFMode, FilePicker};
use fff_search::{
    FFFQuery, FilePickerOptions, FileSearchConfig, FrecencyTracker, FuzzySearchOptions,
    SharedFilePicker, SharedFrecency, WatchEvent, WatchOptions,
};
use std::fs::{self, File};
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant, SystemTime};
use tempfile::TempDir;

/// Scales a wall-clock limit by TIMEOUT_MULTIPLIER (never below 1).
fn limit(secs: f64) -> Duration {
    let factor = std::env::var("TIMEOUT_MULTIPLIER")
        .ok()
        .and_then(|value| value.parse::<f64>().ok())
        .filter(|value| *value >= 1.0)
        .unwrap_or(1.0);
    Duration::from_secs_f64(secs * factor)
}

fn wait_until(deadline: Duration, mut done: impl FnMut() -> bool) -> bool {
    let end = Instant::now() + deadline;
    while Instant::now() < end {
        if done() {
            return true;
        }
        std::thread::sleep(Duration::from_millis(25));
    }
    done()
}

fn temp_base() -> (TempDir, PathBuf) {
    let dir = TempDir::new().expect("temp dir");
    let base = fff_search::path_utils::canonicalize(dir.path()).expect("canonical base");
    (dir, base)
}

fn write(base: &Path, rel: &str, body: &str) -> PathBuf {
    let path = base.join(rel);
    fs::create_dir_all(path.parent().unwrap()).unwrap();
    fs::write(&path, body).unwrap();
    path
}

/// A watched picker over `base`. The backend can report not ready on a cold
/// start, so the bring-up is tried a few times before giving up.
fn watched_picker(base: &Path, frecency: &SharedFrecency) -> SharedFilePicker {
    for attempt in 0..5 {
        if attempt > 0 {
            std::thread::sleep(Duration::from_millis(500));
        }
        let picker = SharedFilePicker::default();
        let built = FilePicker::new_with_shared_state(
            picker.clone(),
            frecency.clone(),
            FilePickerOptions {
                base_path: base.to_string_lossy().into_owned(),
                mode: FFFMode::Neovim,
                watch: true,
                enable_mmap_cache: false,
                enable_content_indexing: false,
                ..Default::default()
            },
        );
        if built.is_err() {
            continue;
        }
        if picker.wait_for_scan(limit(30.0)) && picker.wait_for_watcher(limit(30.0)) {
            std::thread::sleep(Duration::from_millis(300));
            return picker;
        }
    }
    panic!("the watched picker didn't come up after 5 attempts");
}

type Batches = Arc<Mutex<Vec<Vec<WatchEvent>>>>;

fn subscribe(picker: &SharedFilePicker, pattern: &str) -> Batches {
    let batches: Batches = Arc::new(Mutex::new(Vec::new()));
    let sink = Arc::clone(&batches);
    picker
        .watch(pattern, WatchOptions::default(), move |_, events| {
            sink.lock().unwrap().push(events.to_vec());
        })
        .expect("watch subscription");
    batches
}

fn events(batches: &Batches) -> Vec<WatchEvent> {
    batches.lock().unwrap().iter().flatten().cloned().collect()
}

fn is_move(event: &WatchEvent) -> bool {
    !matches!(
        event.kind.as_str(),
        "created" | "modified" | "removed" | "rescan"
    )
}

/// True when the event's Debug text holds both paths. Paths are compared by
/// their part under the base, which a full path also contains.
fn names_both(event: &WatchEvent, one: &str, other: &str) -> bool {
    let text = format!("{event:?}");
    text.contains(one) && text.contains(other)
}

fn plain(event: &WatchEvent, kind: &str, path: &Path) -> bool {
    event.kind.as_str() == kind && event.path == path
}

fn noop_frecency() -> SharedFrecency {
    SharedFrecency::noop()
}

fn real_frecency(db: &TempDir) -> SharedFrecency {
    let frecency = SharedFrecency::default();
    let tracker = FrecencyTracker::open(db.path().join("frecency.mdb")).expect("open frecency db");
    frecency.init(tracker).expect("init frecency");
    frecency
}

fn access_count(frecency: &SharedFrecency, path: &Path) -> usize {
    let guard = frecency.read().expect("frecency read lock");
    guard
        .as_ref()
        .expect("frecency store")
        .access_count(path)
        .expect("access count")
}

fn cached_score(picker: &SharedFilePicker, path: &Path) -> Option<i16> {
    let guard = picker.read().ok()?;
    let picker = guard.as_ref()?;
    picker.get_file_by_path(path).map(|file| file.access_frecency_score)
}

#[test]
fn in_tree_move_arrives_as_one_event_naming_both_paths() {
    let (_dir, base) = temp_base();
    write(&base, "moved/seed.txt", "seed\n");
    let src = write(&base, "src/alpha_mover.rs", "pub fn alpha_mover() {}\n");
    let dst = base.join("moved/alpha_mover.rs");
    let picker = watched_picker(&base, &noop_frecency());
    let batches = subscribe(&picker, "");

    fs::rename(&src, &dst).unwrap();

    let arrived = wait_until(limit(10.0), || {
        events(&batches)
            .iter()
            .any(|e| is_move(e) && names_both(e, "src/alpha_mover.rs", "moved/alpha_mover.rs"))
    });
    std::thread::sleep(limit(0.5));
    let seen = events(&batches);
    assert!(
        arrived,
        "no single move event naming src/alpha_mover.rs and moved/alpha_mover.rs, got: {seen:?}"
    );
    let pair: Vec<&WatchEvent> = seen
        .iter()
        .filter(|e| plain(e, "removed", &src) || plain(e, "created", &dst))
        .collect();
    assert!(
        pair.is_empty(),
        "the move came with a plain removal or creation of the same file: {pair:?}"
    );
}

#[test]
fn move_is_heard_by_subscribers_on_either_side() {
    let (_dir, base) = temp_base();
    write(&base, "moved/seed.txt", "seed\n");
    write(&base, "src/seed.txt", "seed\n");
    let src = write(&base, "src/beta_mover.rs", "pub fn beta_mover() {}\n");
    let dst = base.join("moved/beta_mover.rs");
    let picker = watched_picker(&base, &noop_frecency());
    let source_dir = subscribe(&picker, "src");
    let source_file = subscribe(&picker, "src/beta_mover.rs");
    let destination_dir = subscribe(&picker, "moved");

    fs::rename(&src, &dst).unwrap();

    for (label, batches) in [
        ("the source directory", &source_dir),
        ("the old file path", &source_file),
        ("the destination directory", &destination_dir),
    ] {
        let heard = wait_until(limit(10.0), || {
            events(batches)
                .iter()
                .any(|e| is_move(e) && names_both(e, "src/beta_mover.rs", "moved/beta_mover.rs"))
        });
        assert!(
            heard,
            "a subscription on {label} didn't get the move event, got: {:?}",
            events(batches)
        );
    }
}

#[test]
fn move_out_of_the_tree_stays_a_plain_removal() {
    let (_dir, base) = temp_base();
    let (_outside_dir, outside) = temp_base();
    let src = write(&base, "src/gamma_leaver.rs", "pub fn gamma_leaver() {}\n");
    let dst = outside.join("gamma_leaver.rs");
    let picker = watched_picker(&base, &noop_frecency());
    let batches = subscribe(&picker, "");

    fs::rename(&src, &dst).unwrap();

    let removed = wait_until(limit(10.0), || {
        events(&batches).iter().any(|e| plain(e, "removed", &src))
    });
    std::thread::sleep(limit(0.5));
    let seen = events(&batches);
    assert!(removed, "no removal for src/gamma_leaver.rs, got: {seen:?}");
    let outside_text = outside.to_string_lossy().into_owned();
    let wrong: Vec<&WatchEvent> = seen
        .iter()
        .filter(|e| is_move(e) || format!("{e:?}").contains(&outside_text))
        .collect();
    assert!(
        wrong.is_empty(),
        "a move out of the tree was reported as a move or named the outside path: {wrong:?}"
    );
}

/// Two files disappear and two others appear in one batch, all four with the
/// same size and the same modification time and different contents. Nothing
/// ties a new file to an old one, so no move may be reported and no history
/// may land on the new paths.
#[test]
fn unrelated_files_with_one_size_and_time_stay_unpaired() {
    let (_dir, base) = temp_base();
    let db = TempDir::new().unwrap();
    let frecency = real_frecency(&db);
    let stamp = SystemTime::UNIX_EPOCH + Duration::from_secs(1_700_000_000);
    let stamp_secs = 1_700_000_000u64;
    let set_stamp = |path: &Path| File::open(path).unwrap().set_modified(stamp).unwrap();

    // Sources for every attempt exist and carry history before the picker starts.
    let rounds = 5;
    let mut sources = Vec::new();
    for round in 0..rounds {
        let a = write(&base, &format!("bulk/old_a{round}.txt"), "xy");
        let b = write(&base, &format!("bulk/old_b{round}.txt"), "zw");
        set_stamp(&a);
        set_stamp(&b);
        {
            let guard = frecency.read().unwrap();
            let store = guard.as_ref().unwrap();
            for _ in 0..3 {
                store.track_access(&a).unwrap();
            }
        }
        sources.push((a, b));
    }
    let picker = watched_picker(&base, &frecency);
    let batches = subscribe(&picker, "");

    for (round, (a, b)) in sources.iter().enumerate() {
        let c = base.join(format!("bulk/new_c{round}.txt"));
        let d = base.join(format!("bulk/new_d{round}.txt"));
        let names = [
            format!("old_a{round}.txt"),
            format!("old_b{round}.txt"),
            format!("new_c{round}.txt"),
            format!("new_d{round}.txt"),
        ];
        let start = batches.lock().unwrap().len();

        fs::remove_file(a).unwrap();
        fs::remove_file(b).unwrap();
        fs::write(&c, "pq").unwrap();
        fs::write(&d, "rs").unwrap();
        set_stamp(&c);
        set_stamp(&d);

        let mentioned = |batch: &Vec<WatchEvent>, name: &str| {
            batch.iter().any(|e| format!("{e:?}").contains(name))
        };
        wait_until(limit(10.0), || {
            let all = batches.lock().unwrap();
            names
                .iter()
                .all(|name| all[start..].iter().any(|batch| mentioned(batch, name)))
        });
        std::thread::sleep(limit(0.5));

        let after: Vec<Vec<WatchEvent>> = batches.lock().unwrap()[start..].to_vec();
        let moves: Vec<&WatchEvent> = after.iter().flatten().filter(|e| is_move(e)).collect();
        assert!(
            moves.is_empty(),
            "two old and two new files sharing one size and time were reported as moves: {moves:?}"
        );
        for new_path in [&c, &d] {
            assert_eq!(
                access_count(&frecency, new_path),
                0,
                "history of an unrelated file landed on {}",
                new_path.display()
            );
        }

        // The case only counts when all four changes were handled together
        // and both new files had the shared time when they were indexed.
        let together = after
            .iter()
            .any(|batch| names.iter().all(|name| mentioned(batch, name)));
        let indexed_with_stamp = [&c, &d].iter().all(|path| {
            picker
                .read()
                .ok()
                .and_then(|guard| {
                    guard
                        .as_ref()
                        .and_then(|p| p.get_file_by_path(path).map(|f| f.modified))
                })
                == Some(stamp_secs)
        });
        if together && indexed_with_stamp {
            return;
        }
        eprintln!(
            "round {round}: changes split across batches ({together}) or time not indexed ({indexed_with_stamp}), trying again"
        );
    }
    panic!("the four changes never arrived in one batch in {rounds} rounds");
}

#[test]
fn moved_file_keeps_its_place_at_the_top_of_results() {
    let (_dir, base) = temp_base();
    let db = TempDir::new().unwrap();
    let frecency = real_frecency(&db);
    write(&base, "moved/seed.txt", "seed\n");
    write(&base, "src/quiet_one.rs", "pub fn quiet_one() {}\n");
    write(&base, "src/quiet_two.rs", "pub fn quiet_two() {}\n");
    let src = write(&base, "src/delta_worked.rs", "pub fn delta_worked() {}\n");
    let dst = base.join("moved/delta_worked.rs");
    {
        let guard = frecency.read().unwrap();
        let store = guard.as_ref().unwrap();
        for _ in 0..4 {
            store.track_access(&src).unwrap();
        }
    }
    let picker = watched_picker(&base, &frecency);
    assert!(
        wait_until(limit(10.0), || cached_score(&picker, &src).is_some_and(|s| s > 0)),
        "the file with history wasn't ranked before the move (score {:?})",
        cached_score(&picker, &src)
    );

    fs::rename(&src, &dst).unwrap();

    let carried = wait_until(limit(10.0), || {
        access_count(&frecency, &dst) == 4 && cached_score(&picker, &dst).is_some_and(|s| s > 0)
    });
    assert!(
        carried,
        "after the move the new path had {} accesses in the store and a cached score of {:?}",
        access_count(&frecency, &dst),
        cached_score(&picker, &dst)
    );
    assert_eq!(
        access_count(&frecency, &src),
        4,
        "the old path lost its own history"
    );

    let guard = picker.read().unwrap();
    let file_picker = guard.as_ref().unwrap();
    let query = FFFQuery::parse("", FileSearchConfig);
    let results = file_picker.fuzzy_search(&query, None, FuzzySearchOptions::default());
    let top = results.items.first().copied();
    let moved = file_picker.get_file_by_path(&dst);
    assert!(
        top.is_some() && moved.is_some() && std::ptr::eq(top.unwrap(), moved.unwrap()),
        "the moved file isn't the first result of an empty search (scores {:?})",
        results.scores.iter().map(|s| s.total).collect::<Vec<_>>()
    );
}
