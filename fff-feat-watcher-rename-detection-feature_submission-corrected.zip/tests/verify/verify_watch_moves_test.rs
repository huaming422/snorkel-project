//! Big batches of unrelated file changes seen through the public watcher of
//! fff-search.
//!
//! Every case drives a real watched picker over a temporary tree and reads what
//! a subscriber and the access history see. A move event is one whose kind
//! string isn't created, modified, removed or rescan.

use fff_search::file_picker::{FFFMode, FilePicker};
use fff_search::{
    FilePickerOptions, FrecencyTracker, SharedFilePicker, SharedFrecency, WatchEvent, WatchOptions,
};
use std::fs::{self, File};
use std::os::unix::fs::MetadataExt;
use std::path::{Path, PathBuf};
use std::process::Command;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant, SystemTime};
use tempfile::TempDir;

/// Scales a wall-clock limit by TIMEOUT_MULTIPLIER (never below 1).
fn limit(secs: f64) -> Duration {
    let factor = std::env::var("TIMEOUT_MULTIPLIER")
        .ok()
        .and_then(|value| value.parse::<f64>().ok())
        .filter(|value| *value >= 1.0)
        .unwrap_or(1.0);
    Duration::from_secs_f64(secs * factor)
}

fn wait_until(deadline: Duration, mut done: impl FnMut() -> bool) -> bool {
    let end = Instant::now() + deadline;
    while Instant::now() < end {
        if done() {
            return true;
        }
        std::thread::sleep(Duration::from_millis(25));
    }
    done()
}

fn temp_base() -> (TempDir, PathBuf) {
    let dir = TempDir::new().expect("temp dir");
    let base = fff_search::path_utils::canonicalize(dir.path()).expect("canonical base");
    (dir, base)
}

fn write(base: &Path, rel: &str, body: &str) -> PathBuf {
    let path = base.join(rel);
    fs::create_dir_all(path.parent().unwrap()).unwrap();
    fs::write(&path, body).unwrap();
    path
}

/// A watched picker over `base`. The backend can report not ready on a cold
/// start, so the bring-up is tried a few times before giving up.
fn watched_picker(base: &Path, frecency: &SharedFrecency) -> SharedFilePicker {
    for attempt in 0..5 {
        if attempt > 0 {
            std::thread::sleep(Duration::from_millis(500));
        }
        let picker = SharedFilePicker::default();
        let built = FilePicker::new_with_shared_state(
            picker.clone(),
            frecency.clone(),
            FilePickerOptions {
                base_path: base.to_string_lossy().into_owned(),
                mode: FFFMode::Neovim,
                watch: true,
                enable_mmap_cache: false,
                enable_content_indexing: false,
                ..Default::default()
            },
        );
        if built.is_err() {
            continue;
        }
        if picker.wait_for_scan(limit(30.0)) && picker.wait_for_watcher(limit(30.0)) {
            std::thread::sleep(Duration::from_millis(300));
            return picker;
        }
    }
    panic!("the watched picker didn't come up after 5 attempts");
}

type Batches = Arc<Mutex<Vec<Vec<WatchEvent>>>>;

fn subscribe(picker: &SharedFilePicker, pattern: &str) -> Batches {
    let batches: Batches = Arc::new(Mutex::new(Vec::new()));
    let sink = Arc::clone(&batches);
    picker
        .watch(pattern, WatchOptions::default(), move |_, events| {
            sink.lock().unwrap().push(events.to_vec());
        })
        .expect("watch subscription");
    batches
}

fn is_move(event: &WatchEvent) -> bool {
    !matches!(
        event.kind.as_str(),
        "created" | "modified" | "removed" | "rescan"
    )
}

fn real_frecency(db: &TempDir) -> SharedFrecency {
    let frecency = SharedFrecency::default();
    let tracker = FrecencyTracker::open(db.path().join("frecency.mdb")).expect("open frecency db");
    frecency.init(tracker).expect("init frecency");
    frecency
}

fn access_count(frecency: &SharedFrecency, path: &Path) -> usize {
    let guard = frecency.read().expect("frecency read lock");
    guard
        .as_ref()
        .expect("frecency store")
        .access_count(path)
        .expect("access count")
}

fn inode_number(path: &Path) -> u64 {
    fs::metadata(path).expect("metadata").ino()
}

/// Two files disappear and two others appear in one batch, all four with the
/// same size and the same modification time and different contents. Nothing
/// ties a new file to an old one, so no move may be reported and no history
/// may land on the new paths. With `numbers_handed_out_again`, each new file
/// also reports the inode number one of the deleted files had.
fn unrelated_files_stay_unpaired(base: &Path, numbers_handed_out_again: bool) {
    let db = TempDir::new().unwrap();
    let frecency = real_frecency(&db);
    let stamp = SystemTime::UNIX_EPOCH + Duration::from_secs(1_700_000_000);
    let stamp_secs = 1_700_000_000u64;
    let set_stamp = |path: &Path| File::open(path).unwrap().set_modified(stamp).unwrap();

    // Sources for every attempt exist and carry history before the picker starts.
    let rounds = 5;
    let mut sources = Vec::new();
    for round in 0..rounds {
        let a = write(base, &format!("bulk/old_a{round}.txt"), "xy");
        let b = write(base, &format!("bulk/old_b{round}.txt"), "zw");
        set_stamp(&a);
        set_stamp(&b);
        {
            let guard = frecency.read().unwrap();
            let store = guard.as_ref().unwrap();
            for _ in 0..3 {
                store.track_access(&a).unwrap();
            }
        }
        sources.push((a, b));
    }
    let picker = watched_picker(base, &frecency);
    let batches = subscribe(&picker, "");

    for (round, (a, b)) in sources.iter().enumerate() {
        let c = base.join(format!("bulk/new_c{round}.txt"));
        let d = base.join(format!("bulk/new_d{round}.txt"));
        let names = [
            format!("old_a{round}.txt"),
            format!("old_b{round}.txt"),
            format!("new_c{round}.txt"),
            format!("new_d{round}.txt"),
        ];
        let mut old_numbers = vec![inode_number(a), inode_number(b)];
        old_numbers.sort_unstable();
        let start = batches.lock().unwrap().len();

        fs::remove_file(a).unwrap();
        fs::remove_file(b).unwrap();
        fs::write(&c, "pq").unwrap();
        fs::write(&d, "rs").unwrap();
        set_stamp(&c);
        set_stamp(&d);

        if numbers_handed_out_again {
            let mut new_numbers = vec![inode_number(&c), inode_number(&d)];
            new_numbers.sort_unstable();
            assert_eq!(
                new_numbers, old_numbers,
                "the new files didn't report the inode numbers of the deleted files"
            );
            println!(
                "round {round}: deleted files had inode numbers {old_numbers:?}, the new files report {new_numbers:?}"
            );
        }

        let mentioned = |batch: &Vec<WatchEvent>, name: &str| {
            batch.iter().any(|e| format!("{e:?}").contains(name))
        };
        wait_until(limit(10.0), || {
            let all = batches.lock().unwrap();
            names
                .iter()
                .all(|name| all[start..].iter().any(|batch| mentioned(batch, name)))
        });
        std::thread::sleep(limit(0.5));

        let after: Vec<Vec<WatchEvent>> = batches.lock().unwrap()[start..].to_vec();
        let moves: Vec<&WatchEvent> = after.iter().flatten().filter(|e| is_move(e)).collect();
        assert!(
            moves.is_empty(),
            "two old and two new files sharing one size and time were reported as moves: {moves:?}"
        );
        for new_path in [&c, &d] {
            assert_eq!(
                access_count(&frecency, new_path),
                0,
                "history of an unrelated file landed on {}",
                new_path.display()
            );
        }

        // The case only counts when all four changes were handled together
        // and both new files had the shared time when they were indexed.
        let together = after
            .iter()
            .any(|batch| names.iter().all(|name| mentioned(batch, name)));
        let indexed_with_stamp = [&c, &d].iter().all(|path| {
            picker
                .read()
                .ok()
                .and_then(|guard| {
                    guard
                        .as_ref()
                        .and_then(|p| p.get_file_by_path(path).map(|f| f.modified))
                })
                == Some(stamp_secs)
        });
        if together && indexed_with_stamp {
            return;
        }
        eprintln!(
            "round {round}: changes split across batches ({together}) or time not indexed ({indexed_with_stamp}), trying again"
        );
    }
    panic!("the four changes never arrived in one batch in {rounds} rounds");
}

#[test]
fn unrelated_files_with_one_size_and_time_stay_unpaired() {
    let (_dir, base) = temp_base();
    unrelated_files_stay_unpaired(&base, false);
}

/// The root the library below works under, set for the second run of the case.
const REUSE_ROOT: &str = "FFF_INODE_REUSE_ROOT";
const REUSE_DONE: &str = "inode number case finished";

/// Loaded with LD_PRELOAD. Under the root it hands the inode number of a
/// deleted regular file to the next new regular file, the way ext4 often
/// does, and keeps every other number fixed. It changes what statx reports
/// and nothing else.
const REUSE_LIBRARY: &str = r##"
#define _GNU_SOURCE
#include <dlfcn.h>
#include <fcntl.h>
#include <limits.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <unistd.h>

#define SLOTS 8192
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
static unsigned long long real_of[SLOTS], given_of[SLOTS];
static int used;
static unsigned long long free_numbers[SLOTS];
static int free_count;
static unsigned long long next_number = 7000000001ULL;

static const char *root(void) {
    const char *value = getenv("FFF_INODE_REUSE_ROOT");
    return value && *value ? value : NULL;
}

static int full_path(int dirfd, const char *path, char *out, size_t size) {
    char dir[PATH_MAX];
    if (path && path[0] == '/') {
        snprintf(out, size, "%s", path);
        return 1;
    }
    if (dirfd == AT_FDCWD) {
        if (!getcwd(dir, sizeof dir)) return 0;
    } else {
        char link[64];
        snprintf(link, sizeof link, "/proc/self/fd/%d", dirfd);
        ssize_t n = readlink(link, dir, sizeof dir - 1);
        if (n < 0) return 0;
        dir[n] = 0;
    }
    if (!path || !path[0]) snprintf(out, size, "%s", dir);
    else snprintf(out, size, "%s/%s", dir, path);
    return 1;
}

static int under_root(int dirfd, const char *path) {
    const char *r = root();
    char full[2 * PATH_MAX];
    if (!r || !full_path(dirfd, path, full, sizeof full)) return 0;
    size_t len = strlen(r);
    return strncmp(full, r, len) == 0 && (full[len] == '/' || full[len] == 0);
}

static unsigned long long given(unsigned long long real) {
    unsigned long long out;
    pthread_mutex_lock(&lock);
    for (int i = 0; i < used; i++) {
        if (real_of[i] == real) {
            out = given_of[i];
            pthread_mutex_unlock(&lock);
            return out;
        }
    }
    out = free_count > 0 ? free_numbers[--free_count] : next_number++;
    if (used < SLOTS) {
        real_of[used] = real;
        given_of[used] = out;
        used++;
    }
    pthread_mutex_unlock(&lock);
    return out;
}

static void forget(unsigned long long real) {
    pthread_mutex_lock(&lock);
    for (int i = 0; i < used; i++) {
        if (real_of[i] == real) {
            if (free_count < SLOTS) free_numbers[free_count++] = given_of[i];
            used--;
            real_of[i] = real_of[used];
            given_of[i] = given_of[used];
            break;
        }
    }
    pthread_mutex_unlock(&lock);
}

int statx(int dirfd, const char *path, int flags, unsigned int mask, struct statx *buf) {
    static int (*next)(int, const char *, int, unsigned int, struct statx *);
    if (!next) next = (int (*)(int, const char *, int, unsigned int, struct statx *))dlsym(RTLD_NEXT, "statx");
    int rc = next(dirfd, path, flags, mask, buf);
    if (rc == 0 && S_ISREG(buf->stx_mode) && under_root(dirfd, path)) buf->stx_ino = given(buf->stx_ino);
    return rc;
}

static int last_link(int dirfd, const char *path, int flags, unsigned long long *ino) {
    struct stat st;
    if (flags & AT_REMOVEDIR) return 0;
    if (!under_root(dirfd, path)) return 0;
    if (syscall(SYS_newfstatat, dirfd, path, &st, AT_SYMLINK_NOFOLLOW) != 0) return 0;
    if (!S_ISREG(st.st_mode) || st.st_nlink != 1) return 0;
    *ino = st.st_ino;
    return 1;
}

int unlinkat(int dirfd, const char *path, int flags) {
    static int (*next)(int, const char *, int);
    if (!next) next = (int (*)(int, const char *, int))dlsym(RTLD_NEXT, "unlinkat");
    unsigned long long ino = 0;
    int watched = last_link(dirfd, path, flags, &ino);
    int rc = next(dirfd, path, flags);
    if (rc == 0 && watched) forget(ino);
    return rc;
}

int unlink(const char *path) {
    static int (*next)(const char *);
    if (!next) next = (int (*)(const char *))dlsym(RTLD_NEXT, "unlink");
    unsigned long long ino = 0;
    int watched = last_link(AT_FDCWD, path, 0, &ino);
    int rc = next(path);
    if (rc == 0 && watched) forget(ino);
    return rc;
}
"##;

fn build_reuse_library(dir: &Path) -> PathBuf {
    let source = dir.join("inode_reuse.c");
    let library = dir.join("inode_reuse.so");
    fs::write(&source, REUSE_LIBRARY).unwrap();
    let mut errors = String::new();
    for compiler in ["cc", "clang", "gcc"] {
        match Command::new(compiler)
            .args(["-shared", "-fPIC", "-O1", "-o"])
            .arg(&library)
            .arg(&source)
            .args(["-ldl", "-lpthread"])
            .output()
        {
            Ok(out) if out.status.success() => return library,
            Ok(out) => errors.push_str(&String::from_utf8_lossy(&out.stderr)),
            Err(err) => errors.push_str(&format!("{compiler}: {err}\n")),
        }
    }
    panic!("couldn't build the inode number library: {errors}");
}

/// The same batch as above, on a filesystem that hands each new file the
/// inode number of a file just deleted. The case runs again in a child
/// process with a small library preloaded that makes statx report numbers
/// that way under the temporary tree.
#[test]
fn new_files_given_the_inode_numbers_of_deleted_files_stay_unpaired() {
    if let Some(root) = std::env::var_os(REUSE_ROOT) {
        unrelated_files_stay_unpaired(Path::new(&root), true);
        println!("{REUSE_DONE}");
        return;
    }
    let (_dir, base) = temp_base();
    let work = TempDir::new().unwrap();
    let library = build_reuse_library(work.path());
    let out = Command::new(std::env::current_exe().expect("test binary"))
        .args([
            "--exact",
            "new_files_given_the_inode_numbers_of_deleted_files_stay_unpaired",
            "--nocapture",
            "--test-threads=1",
        ])
        .env(REUSE_ROOT, &base)
        .env("LD_PRELOAD", &library)
        .output()
        .expect("run the case again with the library preloaded");
    let text: String = String::from_utf8_lossy(&out.stdout)
        .lines()
        .chain(String::from_utf8_lossy(&out.stderr).lines())
        .map(|line| format!("  | {line}\n"))
        .collect();
    assert!(
        out.status.success() && text.contains(REUSE_DONE),
        "the case failed when new files got the inode numbers of deleted ones:\n{text}"
    );
}
