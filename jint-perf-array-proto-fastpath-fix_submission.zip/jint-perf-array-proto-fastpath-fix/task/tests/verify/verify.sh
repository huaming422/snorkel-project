#!/usr/bin/env bash
#
# Behavioral verifier for the array-access work. Drops a self-contained xUnit
# verification class into the repo's existing Jint.Tests project (so it inherits
# the project's package references and its ProjectReference on the agent's
# Jint engine), then builds + runs it with `dotnet test -c Release`. The same
# invocation re-runs the repo's own pre-existing array / for-in enumeration test
# classes as the no-regression guard. Exit 0 iff every selected test passes.
#
# The verification class exercises everything through the stable public
# `Jint.Engine.Evaluate` API: allocation-bounded performance checks (via
# GC.GetAllocatedBytesForCurrentThread, the technique the repo already uses) and
# concrete-value correctness checks. It references no engine internals, so any
# correct implementation links and passes.
#
# Runner cwd is {repo_dir} (/repo/jint). The verify dir is staged at
# /tests/verify. Exit codes: 0 = all selected tests green; non-zero = any
# failure (or build error) propagates.
set -euo pipefail

REPO_DIR="/repo/jint"
VERIFY_DIR="/tests/verify"
SRC="${VERIFY_DIR}/ArrayAccessFastPathVerification.cs"
DEST_DIR="${REPO_DIR}/Jint.Tests/Runtime"
DEST="${DEST_DIR}/ArrayAccessFastPathVerification.cs"

cd "${REPO_DIR}"

# Make the SDK + warm NuGet cache reachable (idempotent with test-setup.sh).
export DOTNET_ROOT="${DOTNET_ROOT:-/opt/dotnet}"
export PATH="/opt/dotnet:${PATH}"
export NUGET_PACKAGES="${NUGET_PACKAGES:-/opt/cache/nuget}"
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1 DOTNET_NOLOGO=1

# Stage the verification class into the test project and guarantee cleanup so a
# re-run against the same tree starts clean.
cleanup() { rm -f "${DEST}"; }
trap cleanup EXIT
cp "${SRC}" "${DEST}"

# Select: the new verification class + the repo's own array and for-in
# enumeration suites (the no-regression guard). FullyQualifiedName match is a
# substring contains; the class-qualified prefixes below are unambiguous in this
# repo.
FILTER='FullyQualifiedName~ArrayAccessFastPathVerification'
FILTER+='|FullyQualifiedName~Jint.Tests.Runtime.ArrayTests.'
FILTER+='|FullyQualifiedName~Jint.Tests.Runtime.ForInEnumerationTests.'

dotnet test Jint.Tests/Jint.Tests.csproj \
    -c Release -f net10.0 \
    --filter "${FILTER}" \
    -p:NuGetAudit=false
