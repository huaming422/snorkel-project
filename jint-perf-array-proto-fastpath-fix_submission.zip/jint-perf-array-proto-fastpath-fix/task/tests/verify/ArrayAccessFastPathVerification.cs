namespace Jint.Tests.Runtime;

/// <summary>
/// Independent verification of the two array access patterns: enumerating an array with
/// <c>for (k in arr)</c>, and reading / membership-testing absent (hole) indices. Both must stay
/// allocation-light once the engine is warm, while preserving every observable enumeration and
/// read semantic. Everything is exercised through the stable public <c>Jint.Engine.Evaluate</c>
/// surface — no engine internals are referenced, so any correct implementation passes regardless of
/// how it proves the receiver/chain is clean or how it names its helpers.
///
/// The allocation bounds reuse the repository's own deterministic technique
/// (<c>GC.GetAllocatedBytesForCurrentThread()</c> around a warm prepared evaluation, under
/// <c>#if NET</c>) seen in <c>SlotLocationCacheTests</c>. The workloads mirror the per-operation
/// cost that the clean cases ("a kilobyte or two") should never exceed: pre-fix these allocate
/// megabytes per evaluation, so the generous sub-200 KB bound separates a real fix from an
/// unchanged tree by two to three orders of magnitude while leaving ample headroom for any correct
/// implementation.
/// </summary>
public class ArrayAccessFastPathVerification
{
    private static string EvalString(string source) => new Engine().Evaluate(source).AsString();

    private static double EvalNumber(string source) => new Engine().Evaluate(source).AsNumber();

    // -----------------------------------------------------------------------------------------
    // Performance contract — allocation-bounded. A warm evaluation that repeats the access pattern
    // many times must allocate far below the bound. These fail hard on an unchanged tree
    // (megabytes) and on any "fix" that leaves either surface materializing per operation.
    // -----------------------------------------------------------------------------------------

#if NET
    [Fact]
    public void ForInOverDenseArrayStaysAllocationLight()
    {
        var engine = new Engine();
        engine.Execute("var denseArr = []; for (var i = 0; i < 1000; i++) { denseArr[i] = i; }");
        var prepared = Engine.PrepareScript("""
            function f() {
                var s = 0;
                for (var i = 0; i < 200; i++) {
                    for (var k in denseArr) { s++; }
                }
                return s;
            }
            f();
            """);

        // the enumeration must actually run (and visit every dense index) — a degenerate "skip it"
        // fix cannot pass the allocation bound by doing nothing.
        Assert.Equal(200000, engine.Evaluate(prepared).AsNumber());
        for (var e = 0; e < 5; e++) { engine.Evaluate(prepared); }

        var before = GC.GetAllocatedBytesForCurrentThread();
        engine.Evaluate(prepared);
        var perEvaluation = GC.GetAllocatedBytesForCurrentThread() - before;

        Assert.True(
            perEvaluation < 200_000,
            $"for-in over a warm dense array should not allocate per enumeration; allocated {perEvaluation} bytes across 200 enumerations of a 1000-element array");
    }

    [Fact]
    public void ForInOverHoleyArrayStaysAllocationLight()
    {
        var engine = new Engine();
        engine.Execute("var holeyArr = []; for (var i = 0; i < 1000; i += 4) { holeyArr[i] = i; }");
        var prepared = Engine.PrepareScript("""
            function f() {
                var s = 0;
                for (var i = 0; i < 200; i++) {
                    for (var k in holeyArr) { s++; }
                }
                return s;
            }
            f();
            """);

        // 250 present indices (every 4th of 1000), 200 enumerations — holes skipped, no key-list blowup.
        Assert.Equal(50000, engine.Evaluate(prepared).AsNumber());
        for (var e = 0; e < 5; e++) { engine.Evaluate(prepared); }

        var before = GC.GetAllocatedBytesForCurrentThread();
        engine.Evaluate(prepared);
        var perEvaluation = GC.GetAllocatedBytesForCurrentThread() - before;

        Assert.True(
            perEvaluation < 200_000,
            $"for-in over a warm holey array should not allocate per enumeration; allocated {perEvaluation} bytes across 200 enumerations");
    }

    [Fact]
    public void HoleReadTraversalStaysAllocationLight()
    {
        var engine = new Engine();
        engine.Execute("""
            var dense = [];
            var holey = [];
            for (var i = 0; i < 8000; i++) { dense[i] = i; }
            for (var i = 0; i < 8000; i += 4) { holey[i] = i; }
            holey[7999] = 7999;
            """);
        var prepared = Engine.PrepareScript("""
            function f() {
                var s = 0;
                for (var n = 0; n < 20; n++) {
                    for (var i = 0; i < 8000; i++) { s += holey[i] | 0; }
                }
                return s;
            }
            f();
            """);

        // reading a hole yields undefined (|0 => 0); present values sum to a fixed total each pass.
        // Asserting the exact sum also pins that hole reads return the correct value, not garbage.
        Assert.Equal(160079980, engine.Evaluate(prepared).AsNumber());
        for (var e = 0; e < 5; e++) { engine.Evaluate(prepared); }

        var before = GC.GetAllocatedBytesForCurrentThread();
        engine.Evaluate(prepared);
        var perEvaluation = GC.GetAllocatedBytesForCurrentThread() - before;

        Assert.True(
            perEvaluation < 200_000,
            $"reading holes on a warm holey array should not allocate per read; allocated {perEvaluation} bytes across 160,000 index reads");
    }

    [Fact]
    public void InOperatorOverHoleyArrayStaysAllocationLight()
    {
        var engine = new Engine();
        engine.Execute("""
            var holey = [];
            for (var i = 0; i < 8000; i += 4) { holey[i] = i; }
            holey[7999] = 7999;
            """);
        var prepared = Engine.PrepareScript("""
            function f() {
                var s = 0;
                for (var n = 0; n < 20; n++) {
                    for (var i = 0; i < 8000; i++) { if (i in holey) { s++; } }
                }
                return s;
            }
            f();
            """);

        // 2001 present indices (0,4,..,7996 plus 7999) over 20 passes — the `in` probe must not
        // walk/allocate for the 75% that are holes.
        Assert.Equal(40020, engine.Evaluate(prepared).AsNumber());
        for (var e = 0; e < 5; e++) { engine.Evaluate(prepared); }

        var before = GC.GetAllocatedBytesForCurrentThread();
        engine.Evaluate(prepared);
        var perEvaluation = GC.GetAllocatedBytesForCurrentThread() - before;

        Assert.True(
            perEvaluation < 200_000,
            $"`index in arr` over a warm holey array should not allocate per probe; allocated {perEvaluation} bytes across 160,000 membership tests");
    }
#endif

    // -----------------------------------------------------------------------------------------
    // Correctness — the fast path must stay off wherever it is not provably safe. These assert
    // concrete key sequences / values through Engine.Evaluate. The inherited-prototype-index cases
    // fail on an unchanged tree (a real pre-existing enumeration bug the change also repairs); the
    // rest guard against a fast path that engages when it must not (shadowed holes, custom chains,
    // exotic descriptors) or that breaks snapshot/mutation semantics.
    // -----------------------------------------------------------------------------------------

    [Fact]
    public void ForInEnumeratesInheritedEnumerableArrayPrototypeIndex()
    {
        // Array.prototype is itself array-backed; a script-placed index on it is an own enumerable
        // key of the chain. for-in must enumerate the inherited '5' after the own indices, and the
        // own '1' must shadow the inherited '1'. (Fails on the unchanged tree.)
        var result = EvalString("""
            Array.prototype[5] = 'inherited';
            Array.prototype[1] = 'shadowed';
            var arr = [10, 20];
            var out = [];
            for (var k in arr) { out.push(k); }
            out.join(',');
            """);

        Assert.Equal("0,1,5", result);
    }

    [Fact]
    public void ForInEnumeratesEnumerablePropertyOnObjectPrototype()
    {
        var result = EvalString("""
            Object.prototype.zzz = 1;
            var arr = [10, 20];
            var out = [];
            for (var k in arr) { out.push(k); }
            out.join(',');
            """);

        Assert.Equal("0,1,zzz", result);
    }

    [Fact]
    public void HoleReadWalksChainWhenPrototypeGainsIndex()
    {
        // The pristine-prototype shortcut must disengage the instant Array.prototype / Object.prototype
        // gains an index property: hole reads and `in` then observe the inherited values.
        var result = EvalString("""
            var a = [1, , 3];
            var before = [a[1], 1 in a, a[10], 10 in a];
            Array.prototype[1] = 'ap';
            Object.prototype[10] = 'op';
            var after = [a[1], 1 in a, a[10], 10 in a];
            JSON.stringify([before, after]);
            """);

        Assert.Equal("[[null,false,null,false],[\"ap\",true,\"op\",true]]", result);
    }

    [Fact]
    public void HoleReadHonorsOwnIndexGetter()
    {
        // an exotic own accessor descriptor clears the fast-access invariant on the instance.
        var result = EvalString("""
            var a = [1, 2, 3];
            Object.defineProperty(a, '5', { get: function () { return 'got'; } });
            [a[5], 5 in a, a[7] === undefined].join(',');
            """);

        Assert.Equal("got,true,true", result);
    }

    [Fact]
    public void HoleReadWalksCustomPrototypeChain()
    {
        var result = EvalString("""
            var proto = { 1: 'inherited' };
            var a = [0];
            a.length = 3;
            Object.setPrototypeOf(a, proto);
            [a[1], 1 in a, a[2] === undefined, 2 in a].join(',');
            """);

        Assert.Equal("inherited,true,true,false", result);
    }

    [Fact]
    public void ForInOverDenseArrayYieldsAscendingStringIndices()
    {
        var result = EvalString("""
            var arr = [10, 20, 30, 40];
            var out = [];
            for (var k in arr) { out.push(typeof k + ':' + k); }
            out.join(',');
            """);

        Assert.Equal("string:0,string:1,string:2,string:3", result);
    }

    [Fact]
    public void ForInOverHoleyArraySkipsHoles()
    {
        var result = EvalString("""
            var arr = [];
            arr[0] = 'a'; arr[3] = 'b'; arr[7] = 'c';
            var out = [];
            for (var k in arr) { out.push(k); }
            out.join(',');
            """);

        Assert.Equal("0,3,7", result);
    }

    [Fact]
    public void ForInOverEmptyArrayWithLargeLengthYieldsNothing()
    {
        var result = EvalNumber("""
            var arr = [];
            arr.length = 100000;
            var n = 0;
            for (var k in arr) { n++; }
            n;
            """);

        Assert.Equal(0, result);
    }

    [Fact]
    public void ForInDeleteDuringIterationSkipsNotYetVisitedIndex()
    {
        var result = EvalString("""
            var arr = [10, 20, 30, 40];
            var out = [];
            for (var k in arr) { out.push(k); if (k === '0') { delete arr[2]; } }
            out.join(',');
            """);

        Assert.Equal("0,1,3", result);
    }

    [Fact]
    public void ForInPushDuringIterationDoesNotVisitNewIndex()
    {
        var result = EvalString("""
            var arr = [10, 20];
            var out = [];
            for (var k in arr) { out.push(k); arr.push(99); }
            out.join(',');
            """);

        Assert.Equal("0,1", result);
    }

    [Fact]
    public void ForInLengthTruncationDuringIterationSkipsRemovedIndices()
    {
        var result = EvalString("""
            var arr = [10, 20, 30, 40, 50];
            var out = [];
            for (var k in arr) { out.push(k); if (k === '1') { arr.length = 3; } }
            out.join(',');
            """);

        Assert.Equal("0,1,2", result);
    }

    [Fact]
    public void ForInNonEnumerableIndexIsSkipped()
    {
        var result = EvalString("""
            var arr = [10, 20, 30];
            Object.defineProperty(arr, '1', { value: 20, enumerable: false });
            var out = [];
            for (var k in arr) { out.push(k); }
            out.join(',');
            """);

        Assert.Equal("0,2", result);
    }

    [Fact]
    public void ForInDefinePropertyMidLoopHonorsNewEnumerability()
    {
        var result = EvalString("""
            var arr = [10, 20, 30, 40];
            var out = [];
            for (var k in arr) {
                out.push(k);
                if (k === '0') { Object.defineProperty(arr, '2', { value: 30, enumerable: false }); }
            }
            out.join(',');
            """);

        Assert.Equal("0,1,3", result);
    }

    [Fact]
    public void ForInSparseConversionMidLoopKeepsEnumeratingOriginalIndices()
    {
        var result = EvalString("""
            var arr = [10, 20, 30, 40];
            var out = [];
            for (var k in arr) { out.push(k); if (k === '1') { arr[50000000] = 1; } }
            out.join(',');
            """);

        Assert.Equal("0,1,2,3", result);
    }

    [Fact]
    public void NestedForInOverSameArrayDoNotShareState()
    {
        var result = EvalString("""
            var arr = [1, 2, 3];
            var pairs = [];
            for (var k in arr) { for (var j in arr) { pairs.push(k + j); } }
            pairs.join(',');
            """);

        Assert.Equal("00,01,02,10,11,12,20,21,22", result);
    }

    [Fact]
    public void ForInBreakThenReuseResetsPooledIterator()
    {
        var result = EvalString("""
            var arr = [1, 2, 3, 4];
            var rounds = [];
            for (var r = 0; r < 3; r++) {
                var got = [];
                for (var k in arr) { got.push(k); if (k === '1') break; }
                rounds.push(got.join(''));
            }
            rounds.join(',');
            """);

        Assert.Equal("01,01,01", result);
    }

    [Fact]
    public void InterleavedGeneratorsOverSameArrayDoNotShareState()
    {
        var result = EvalString("""
            var arr = [7, 8, 9];
            function* keys(a) { for (var k in a) { yield k; } }
            var g1 = keys(arr), g2 = keys(arr);
            var seq = [];
            seq.push(g1.next().value);
            seq.push(g2.next().value);
            seq.push(g1.next().value);
            seq.push(g2.next().value);
            seq.push(g1.next().value);
            seq.push(g2.next().value);
            seq.push(g1.next().done);
            seq.join(',');
            """);

        Assert.Equal("0,0,1,1,2,2,true", result);
    }

    [Fact]
    public void ForInOverSubclassInstanceYieldsIndices()
    {
        var result = EvalString("""
            class A extends Array {}
            var a = new A();
            a[0] = 'x'; a[1] = 'y';
            var out = [];
            for (var k in a) { out.push(k); }
            out.join(',');
            """);

        Assert.Equal("0,1", result);
    }
}
