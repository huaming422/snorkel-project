## Task

Jint is our embeddable ECMAScript interpreter for .NET. Programs that embed it loop over and probe JavaScript arrays constantly, so array access sits on a hot path, and two of the most ordinary array operations are burning far more memory than they should.

Enumerating an array with `for (k in arr)` allocates on the order of megabytes per enumeration, even for a plain, densely packed array whose prototype nobody has touched. Reading a hole (`arr[i]` for an index that was never assigned) and the matching `i in arr` test are just as bad, again on arrays with a completely stock prototype. Both run slow to match. The equivalent clean cases should cost a kilobyte or two, so something here is plainly wrong.

Reproduce it by building an array, warming the engine with a few evaluations, then measuring the per-operation allocation delta with `GC.GetAllocatedBytesForCurrentThread()` around one `for (k in arr)` enumeration or a hole-reading pass, via `Engine.Evaluate`.

Get these patterns fast and allocation-light in the common case without changing any observable JavaScript behavior, and keep the fix in the engine source.
