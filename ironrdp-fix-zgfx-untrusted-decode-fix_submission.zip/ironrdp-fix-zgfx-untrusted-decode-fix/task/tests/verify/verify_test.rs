//! Behavioural verifier for `ironrdp-fix-zgfx-untrusted-decode`.
//!
//! Everything a remote RDP peer controls enters the ZGFX decoder through one
//! pre-existing public entry point:
//!
//!   `ironrdp_graphics::zgfx::Decompressor::decompress(
//!        &mut self, input: &[u8], output: &mut Vec<u8>) -> Result<usize, _>`
//!
//! Valid traffic is produced through the sibling public API
//! (`Compressor`, `compress_and_wrap_egfx`, `CompressionMode`). This file
//! tests THROUGH those public symbols only — it never touches the private
//! decode internals (`decompress_segment`, `handle_match`,
//! `read_unencoded_bytes`, `read_encoded_bytes`, `FixedCircularBuffer`,
//! `Bits`), which a valid alternative solution may organise differently, and
//! never asserts a specific `ZgfxError` variant name or any budget constant —
//! only observable behaviour (panic-vs-error, peak memory, byte-exact
//! round-trip).
//!
//! Two distinct checking mechanisms are used, matching the two bug classes:
//!
//!   * Panic cases (truncated / garbled Single segments, out-of-range
//!     length-token widths, match distance past the history window): the
//!     unhardened decoder panics (out-of-bounds slice index, unsigned
//!     underflow, or arithmetic overflow). Under `cargo test` a panic fails
//!     the test; a hardened decoder returns `Err`. So `assert!(... .is_err())`
//!     separates them: the no-op (pre-fix) solution panics and fails; a
//!     correct solution returns `Err` and passes.
//!
//!   * Decompression bomb (a small multipart frame whose segments sum to far
//!     more than any real frame): `is_err()` ALONE does not separate them —
//!     the pre-fix decoder also returns an error eventually, but only after
//!     decompressing every segment in full. The signal is PEAK MEMORY,
//!     measured with a counting `#[global_allocator]` (same technique as the
//!     `firezone-feat-connlib-reduce-allocations` gold verifier). The
//!     hardened decoder caps the aggregate during decode and stays well under
//!     a generous ceiling; the pre-fix decoder blows past it.

use ironrdp_graphics::zgfx::{CompressionMode, Compressor, Decompressor, compress_and_wrap_egfx};
use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};

// ---------------------------------------------------------------------------
// Counting global allocator (peak outstanding bytes)
// ---------------------------------------------------------------------------
//
// The allocator is always installed; accounting is gated off by default and
// flipped on only around the measured region. It tracks the running total of
// *outstanding* bytes (allocations minus frees, with `realloc` accounted as a
// delta so a growing `Vec` is counted as its logical capacity rather than the
// transient old+new overlap) and records the peak.
//
// `dealloc` subtracts saturating-to-zero so a free of something allocated
// before measurement began can never underflow the counter.
//
// The single global counter is only correct with `--test-threads=1`, which
// the rust runner already appends.

struct PeakAllocator;

static COUNTING_ENABLED: AtomicBool = AtomicBool::new(false);
static CURRENT: AtomicUsize = AtomicUsize::new(0);
static PEAK: AtomicUsize = AtomicUsize::new(0);

fn account_add(n: usize) {
    let current = CURRENT.fetch_add(n, Ordering::Relaxed) + n;
    PEAK.fetch_max(current, Ordering::Relaxed);
}

fn account_sub(n: usize) {
    let mut current = CURRENT.load(Ordering::Relaxed);
    loop {
        let next = current.saturating_sub(n);
        match CURRENT.compare_exchange_weak(current, next, Ordering::Relaxed, Ordering::Relaxed) {
            Ok(_) => break,
            Err(observed) => current = observed,
        }
    }
}

unsafe impl GlobalAlloc for PeakAllocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let ptr = unsafe { System.alloc(layout) };
        if !ptr.is_null() && COUNTING_ENABLED.load(Ordering::Relaxed) {
            account_add(layout.size());
        }
        ptr
    }

    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        if COUNTING_ENABLED.load(Ordering::Relaxed) {
            account_sub(layout.size());
        }
        unsafe { System.dealloc(ptr, layout) }
    }

    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let ptr = unsafe { System.alloc_zeroed(layout) };
        if !ptr.is_null() && COUNTING_ENABLED.load(Ordering::Relaxed) {
            account_add(layout.size());
        }
        ptr
    }

    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        let new_ptr = unsafe { System.realloc(ptr, layout, new_size) };
        if !new_ptr.is_null() && COUNTING_ENABLED.load(Ordering::Relaxed) {
            let old_size = layout.size();
            if new_size >= old_size {
                account_add(new_size - old_size);
            } else {
                account_sub(old_size - new_size);
            }
        }
        new_ptr
    }
}

#[global_allocator]
static GLOBAL: PeakAllocator = PeakAllocator;

/// Run `f`, returning the peak outstanding-byte count observed during it.
fn measure_peak<F: FnOnce()>(f: F) -> usize {
    CURRENT.store(0, Ordering::Relaxed);
    PEAK.store(0, Ordering::Relaxed);
    COUNTING_ENABLED.store(true, Ordering::Relaxed);
    f();
    COUNTING_ENABLED.store(false, Ordering::Relaxed);
    PEAK.load(Ordering::Relaxed)
}

// ---------------------------------------------------------------------------
// Wire-format helpers (public layout only — MS-RDPEGFX 2.2.1.1 / 3.1.9.1.2)
// ---------------------------------------------------------------------------

/// `type_and_flags` byte for an RDP8 + COMPRESSED segment (0x24).
const COMPRESSED_RDP8: u8 = 0x24;
/// Single-segment descriptor.
const DESC_SINGLE: u8 = 0xE0;
/// Multipart descriptor.
const DESC_MULTIPART: u8 = 0xE1;

/// Wrap raw compressed-segment bytes in a Single ZGFX PDU
/// (`[0xE0][0x24][bytes...]`), as a hostile or conforming peer would frame a
/// single compressed segment.
fn single_compressed_frame(segment_bytes: &[u8]) -> Vec<u8> {
    let mut v = Vec::with_capacity(segment_bytes.len() + 2);
    v.push(DESC_SINGLE);
    v.push(COMPRESSED_RDP8);
    v.extend_from_slice(segment_bytes);
    v
}

/// Minimal MSB-first bit writer used to hand-build adversarial compressed
/// token streams without reading or importing any decoder internals. The
/// final byte emitted is the ZGFX trailer: the count (0..=7) of unused bits
/// in the last data byte, exactly as this crate's own compressor emits it.
struct BitBuf {
    bytes: Vec<u8>,
    cur: u8,
    nbits: usize,
}

impl BitBuf {
    fn new() -> Self {
        Self {
            bytes: Vec::new(),
            cur: 0,
            nbits: 0,
        }
    }

    fn push_bit(&mut self, bit: bool) {
        if bit {
            self.cur |= 1 << (7 - self.nbits);
        }
        self.nbits += 1;
        if self.nbits == 8 {
            self.bytes.push(self.cur);
            self.cur = 0;
            self.nbits = 0;
        }
    }

    fn push_bits(&mut self, bits: &[u8]) {
        for &b in bits {
            self.push_bit(b != 0);
        }
    }

    fn push_ones(&mut self, count: usize) {
        for _ in 0..count {
            self.push_bit(true);
        }
    }

    fn push_zeros(&mut self, count: usize) {
        for _ in 0..count {
            self.push_bit(false);
        }
    }

    /// Finalise into `[data bytes..., trailer]`. `trailer` = unused bits in the
    /// last data byte, so a decoder computes exactly the bit count pushed.
    fn finish_segment(mut self) -> Vec<u8> {
        let unused = if self.nbits == 0 { 0 } else { 8 - self.nbits };
        if self.nbits > 0 {
            self.bytes.push(self.cur);
        }
        self.bytes.push(u8::try_from(unused).expect("unused bits is 0..=7"));
        self.bytes
    }
}

// Token-table prefixes (MS-RDPEGFX 2.2.1.1.1.1), used only to *build* inputs.
// These are the on-the-wire encoding every conforming compressor emits — a
// stable wire fact, not a decoder-internal symbol.
const TOKEN_MATCH_SMALL: [u8; 5] = [1, 0, 0, 0, 1]; // distance_base 0, 5 value bits
const TOKEN_MATCH_FARTHEST: [u8; 9] = [1, 0, 1, 1, 1, 1, 1, 1, 0]; // distance_base ~17M, 24 value bits

// ---------------------------------------------------------------------------
// Criterion 1 — truncated / garbled Single segment rejected, no panic
// ---------------------------------------------------------------------------

#[test]
fn truncated_single_segment_short_trailer_is_error_not_panic() {
    // A Single compressed segment whose only data byte is 0xFF. Reading the
    // whole trailer byte as the unused-bit count underflows the bit budget
    // (8*(1-1) - 0xFF) in the unhardened decoder; a hardened decoder masks to
    // the low 3 bits and reports a decode error.
    let frame = single_compressed_frame(&[0xFF]);

    let mut decompressor = Decompressor::new();
    let mut output = Vec::new();
    let result = decompressor.decompress(&frame, &mut output);

    assert!(
        result.is_err(),
        "a truncated single segment must surface as a decode error, not decode successfully",
    );
}

#[test]
fn single_segment_insufficient_bits_for_literal_is_error_not_panic() {
    // Bit stream `0 0000000` (one NULL-literal prefix bit, then only 7 of the
    // 8 payload bits it demands). The unhardened decoder slices 8 bits off a
    // 7-bit remainder and panics; a hardened decoder reports a short read.
    let frame = single_compressed_frame(&[0x00, 0x00]);

    let mut decompressor = Decompressor::new();
    let mut output = Vec::new();
    let result = decompressor.decompress(&frame, &mut output);

    assert!(
        result.is_err(),
        "a segment that ends mid-token must surface as a decode error, not panic",
    );
}

#[test]
fn multipart_segment_size_past_buffer_is_error_not_panic() {
    // Multipart frame: 1 segment, declared uncompressedSize 0, segment size
    // 0x7FFF_FFFF, but no segment payload follows. Splitting the buffer at an
    // attacker-declared size past its end panics in the unhardened parser; a
    // hardened parser reports the oversized segment size.
    let mut frame = vec![DESC_MULTIPART];
    frame.extend_from_slice(&1u16.to_le_bytes()); // segment_count = 1
    frame.extend_from_slice(&0u32.to_le_bytes()); // uncompressedSize = 0
    frame.extend_from_slice(&0x7FFF_FFFFu32.to_le_bytes()); // segment size, no data

    let mut decompressor = Decompressor::new();
    let mut output = Vec::new();
    let result = decompressor.decompress(&frame, &mut output);

    assert!(
        result.is_err(),
        "a multipart segment size past the end of the buffer must error, not panic",
    );
}

// ---------------------------------------------------------------------------
// Criterion 3 — out-of-range token width / match distance rejected, no panic
// ---------------------------------------------------------------------------

#[test]
fn match_distance_beyond_history_is_error_not_panic() {
    // A match token whose base distance alone (~17 MiB, the farthest token)
    // exceeds the 2.5 MB sliding-window history. The unhardened decoder feeds
    // it into the circular buffer's position math, which underflows and
    // panics; a hardened decoder bounds the distance and reports an error.
    let mut seg = BitBuf::new();
    seg.push_bits(&TOKEN_MATCH_FARTHEST); // farthest match token (base ~17 MiB)
    seg.push_zeros(24); // 24-bit distance value = 0  -> distance = base, > history
    seg.push_zeros(1); // length prefix: single 0 bit -> length == 3
    let frame = single_compressed_frame(&seg.finish_segment());

    let mut decompressor = Decompressor::new();
    let mut output = Vec::new();
    let result = decompressor.decompress(&frame, &mut output);

    assert!(
        result.is_err(),
        "a match distance past the history window must error, not panic",
    );
}

#[test]
fn oversized_length_token_width_is_error_not_panic() {
    // A match token (distance 1, in-range) followed by a 65-bit run of ones
    // for the match-length token width. Computing `2^(width+1)` overflows the
    // unhardened decoder (pow/shift panic, or an out-of-bounds bit split); a
    // hardened decoder bounds the width against the integer size and reports
    // an error.
    let mut seg = BitBuf::new();
    seg.push_bits(&TOKEN_MATCH_SMALL); // small match token, distance_base 0
    seg.push_bits(&[0, 0, 0, 0, 1]); // 5-bit distance value = 1 -> distance 1 (in range)
    seg.push_ones(65); // length-token width run (>= usize::BITS)
    seg.push_zeros(1); // terminating zero for the unary width
    let frame = single_compressed_frame(&seg.finish_segment());

    let mut decompressor = Decompressor::new();
    let mut output = Vec::new();
    let result = decompressor.decompress(&frame, &mut output);

    assert!(
        result.is_err(),
        "an out-of-range match-length token width must error, not overflow/panic",
    );
}

// ---------------------------------------------------------------------------
// Criterion 2 — decompression bomb: peak memory bounded during decode
// ---------------------------------------------------------------------------

#[test]
fn decompression_bomb_keeps_peak_memory_bounded_and_errors() {
    // Each segment decompresses to 60 MiB of repetitive data; twenty such
    // segments are framed into one small multipart message (a few KB on the
    // wire) whose declared uncompressedSize is set far larger than the frame
    // could ever produce.
    //
    // `is_err()` ALONE does NOT separate the two here: the unhardened decoder also
    // returns an error for this frame — but only at the very end, because its
    // decoded total (~1.2 GiB) never matches the inflated declared size. It
    // reaches that error having first decompressed every segment in full, so
    // its peak output is ~1.2 GiB (and, with amortised `Vec` growth, its peak
    // *allocation* is the next power of two above that, ~2 GiB). A hardened
    // decoder caps the aggregate DURING decode and errors after a few hundred
    // MiB. The deciding signal is therefore PEAK MEMORY, measured below. Both
    // solutions return `Err`; only the memory ceiling separates them.
    //
    // The ceiling sits with wide margin on both sides: a correct solution
    // peaks a few hundred MiB (the reference caps the aggregate near 256 MiB →
    // ~512 MiB allocated after growth rounding), while the unhardened decoder
    // peaks ~2 GiB. 1 GiB splits them with ~2x clearance each way, so it
    // cannot be tuned to whatever exact budget a valid solution happens to
    // pick.
    const PER_SEGMENT: usize = 60 * 1024 * 1024; // 60 MiB decompressed per segment
    const SEGMENT_COUNT: u16 = 20; // ~1.2 GiB decoded if fully expanded
    const PEAK_CEILING: usize = 1024 * 1024 * 1024; // 1 GiB

    // Build one real compressed segment with the public compressor (done once
    // and reused), outside the measured region.
    let raw = vec![0xABu8; PER_SEGMENT];
    let mut compressor = Compressor::new();
    let compressed = compressor.compress(&raw).expect("compressing a repetitive buffer should succeed");

    // Declared uncompressedSize is set BELOW any plausible solution ceiling
    // (50 MiB vs. reference 256 MiB), so an upfront `if declared > ceiling { Err }`
    // shortcut does NOT fire — the decoder must actually start decoding segments
    // before it hits the cap. The segments still expand to ~1.2 GiB in total, so
    // a true DURING-decode cap stops the frame early (within a few hundred MiB),
    // but a solution with no during-decode cap decodes everything and peaks > 1 GiB.
    // Unlike the prior 4 GB figure this also cannot be satisfied by comparing the
    // declared size to the decoded total (they differ), so the only passing behaviour
    // is an incremental cap applied while decoding each segment.
    const DECLARED_TOTAL: u32 = 50_000_000; // 50 MiB — below any plausible ceiling

    let mut frame = vec![DESC_MULTIPART];
    frame.extend_from_slice(&SEGMENT_COUNT.to_le_bytes());
    frame.extend_from_slice(&DECLARED_TOTAL.to_le_bytes());
    let seg_size = u32::try_from(compressed.len() + 1).expect("segment size fits in u32");
    for _ in 0..SEGMENT_COUNT {
        frame.extend_from_slice(&seg_size.to_le_bytes());
        frame.push(COMPRESSED_RDP8);
        frame.extend_from_slice(&compressed);
    }

    let mut decompressor = Decompressor::new();
    let mut output = Vec::new();
    let mut result = None;
    let peak = measure_peak(|| {
        result = Some(decompressor.decompress(&frame, &mut output));
    });

    let result = result.expect("closure ran");
    eprintln!(
        "decompression bomb: peak outstanding = {} MiB, output len = {} MiB, result_is_err = {}",
        peak / (1024 * 1024),
        output.len() / (1024 * 1024),
        result.is_err(),
    );

    // (a) The bomb must be rejected ...
    assert!(
        result.is_err(),
        "an oversized multipart message must be rejected, not decompressed in full",
    );
    // (b) ... and rejected WITHOUT first allocating the whole declared output.
    assert!(
        peak < PEAK_CEILING,
        "peak memory {} MiB exceeded the {} MiB ceiling — the decoder allocated \
         the bomb before rejecting it",
        peak / (1024 * 1024),
        PEAK_CEILING / (1024 * 1024),
    );
}

// Second bomb variant: many small segments, each well under any per-segment cap,
// whose AGGREGATE far exceeds the total cap.
//
// A solution that only enforces a per-segment ceiling (e.g. "reject any single
// segment that decompresses to more than 2 MiB") passes the first bomb test
// (each segment decompresses to only 1 MiB) but is still vulnerable to a
// hostile peer that sends hundreds of conforming-sized segments whose total
// output exhausts memory. This test closes that gap.
#[test]
fn decompression_bomb_many_small_segments_exceeds_aggregate_ceiling() {
    // Each compressed segment decompresses to 1 MiB — well under any per-segment
    // ceiling a valid solution would choose (the reference per-segment cap is
    // 65535 bytes; even a generous 4 MiB per-segment cap would pass each segment
    // individually). 1000 such segments sum to ~1000 MiB, which far exceeds the
    // ~256 MiB aggregate ceiling the reference solution enforces. A solution with
    // only a per-segment cap and no aggregate cap decodes all ~1000 MiB and
    // peaks over 1 GiB (Vec growth); a solution with a true aggregate cap stops
    // after ~256 MiB and peaks well under 1 GiB.
    //
    // The frame's declared uncompressedSize is set to the exact sum the segments
    // would produce IF decoded in full (400 MiB), so it is NOT available as an
    // upfront-reject shortcut — a decoder that only checks declared size against
    // its ceiling would need to declare 400 MiB > ceiling to fire, but 400 MiB
    // is plausibly within some ceilings. Instead the test relies on PEAK MEMORY:
    // a decoder with a true aggregate cap stops after a few hundred MiB, while
    // one with only a per-segment cap decodes all 400 MiB and peaks well over 1 GiB
    // (Vec growth doubles, so ~512 MiB allocated). The ceiling and margin are
    // the same as the first bomb test.

    const PER_SEGMENT_DECODED: usize = 1 * 1024 * 1024; // 1 MiB per segment
    const SEGMENT_COUNT: u16 = 1000;                     // ~1000 MiB decoded if not capped
    const PEAK_CEILING: usize = 1024 * 1024 * 1024;      // 1 GiB

    // Compress once outside the measured region (repetitive data compresses well).
    let raw = vec![0xCDu8; PER_SEGMENT_DECODED];
    let mut compressor = Compressor::new();
    // The ZGFX compressor wraps at 65535 bytes; compress() returns the raw
    // compressed bitstream for a single segment. We call it once per segment to
    // exercise the real compressor, then re-use the result.
    let compressed = compressor.compress(&raw).expect("compress should succeed on a repetitive buffer");

    // Declared uncompressedSize equals what the frame would decode to if fully
    // expanded (~1000 MiB). A naive upfront `if declared > ceiling { Err }` check
    // might fire (1000 MiB > 256 MiB), so we use the exact decoded total — which
    // makes the declared size indistinguishable from the true expansion. Any
    // solution that rejects on declared-size alone would need a ceiling >= 1000 MiB,
    // which would also let the first bomb (50 MiB declared, 1.2 GiB actual) pass.
    let declared_total = u32::try_from(PER_SEGMENT_DECODED * usize::from(SEGMENT_COUNT))
        .expect("~1000 MiB fits in u32");

    let mut frame = vec![DESC_MULTIPART];
    frame.extend_from_slice(&SEGMENT_COUNT.to_le_bytes());
    frame.extend_from_slice(&declared_total.to_le_bytes());
    let seg_size = u32::try_from(compressed.len() + 1).expect("segment size fits in u32");
    for _ in 0..SEGMENT_COUNT {
        frame.extend_from_slice(&seg_size.to_le_bytes());
        frame.push(COMPRESSED_RDP8);
        frame.extend_from_slice(&compressed);
    }

    let mut decompressor = Decompressor::new();
    let mut output = Vec::new();
    let mut result = None;
    let peak = measure_peak(|| {
        result = Some(decompressor.decompress(&frame, &mut output));
    });

    let result = result.expect("closure ran");
    eprintln!(
        "aggregate bomb: peak outstanding = {} MiB, output len = {} MiB, result_is_err = {}",
        peak / (1024 * 1024),
        output.len() / (1024 * 1024),
        result.is_err(),
    );

    assert!(
        result.is_err(),
        "a many-small-segments aggregate bomb must be rejected, not decoded in full",
    );
    assert!(
        peak < PEAK_CEILING,
        "peak memory {} MiB exceeded the {} MiB ceiling — the decoder has no aggregate cap",
        peak / (1024 * 1024),
        PEAK_CEILING / (1024 * 1024),
    );
}

// ---------------------------------------------------------------------------
// Criterion 4 — valid traffic still round-trips byte-for-byte
// ---------------------------------------------------------------------------

fn assert_round_trips(data: &[u8], mode: CompressionMode) {
    let mut compressor = Compressor::new();
    let wrapped = compress_and_wrap_egfx(data, &mut compressor, mode).expect("compress_and_wrap_egfx should succeed");

    let mut decompressor = Decompressor::new();
    let mut output = Vec::new();
    let written = decompressor
        .decompress(&wrapped, &mut output)
        .expect("decompressing valid compressor output must succeed");

    assert_eq!(output.as_slice(), data, "round-trip mismatch for mode {mode:?}");
    assert_eq!(written, data.len(), "reported byte count mismatch for mode {mode:?}");
}

#[test]
fn valid_messages_round_trip_all_modes() {
    let payloads: &[&[u8]] = &[
        b"",
        b"Test data with some repetition: AAAA BBBB CCCC",
        b"The quick brown fox jumps over the lazy dog",
    ];
    for payload in payloads {
        for mode in [CompressionMode::Never, CompressionMode::Auto, CompressionMode::Always] {
            assert_round_trips(payload, mode);
        }
    }
}

#[test]
fn valid_message_with_larger_mixed_payload_round_trips() {
    // A non-trivial payload mixing repetition (exercises match tokens) and
    // varied bytes (exercises literals), to confirm the sliding-window
    // contract is preserved for conforming input.
    let mut data = Vec::new();
    for i in 0..4096u32 {
        data.extend_from_slice(b"frame-");
        data.extend_from_slice(&i.to_le_bytes());
        data.extend_from_slice(b"-REPEATREPEATREPEAT");
    }
    assert_round_trips(&data, CompressionMode::Always);
    assert_round_trips(&data, CompressionMode::Auto);
}

#[test]
fn valid_single_pdu_with_reserved_trailer_bits_decodes_identically() {
    // MS-RDPEGFX 3.1.9.1.2.4 reserves the five high-order bits of the trailer
    // byte; only the low three are the unused-bit count. A conforming peer may
    // leave the reserved bits non-zero. The byte stream `1100_1000` with
    // trailer `0x03` decodes to a single 0x01 literal; setting the reserved
    // high bits (`| 0b1010_0000`) must decode identically. The unhardened
    // decoder reads the whole trailer byte and underflows; a hardened decoder
    // masks it off.
    let clean = single_compressed_frame(&[0b1100_1000, 0x03]);
    let reserved_set = single_compressed_frame(&[0b1100_1000, 0x03 | 0b1010_0000]);

    let mut d1 = Decompressor::new();
    let mut out_clean = Vec::new();
    d1.decompress(&clean, &mut out_clean)
        .expect("baseline single PDU must decode");

    let mut d2 = Decompressor::new();
    let mut out_reserved = Vec::new();
    d2.decompress(&reserved_set, &mut out_reserved)
        .expect("a PDU with reserved trailer bits set must still decode");

    assert_eq!(out_clean, vec![0x01], "baseline trailer decode mismatch");
    assert_eq!(
        out_reserved, out_clean,
        "reserved high bits in the trailer byte must not change the decoded output",
    );
}
