#!/usr/bin/env bash
# No services to start, no data to seed: the image pre-warms the cargo
# cache at the base commit and the verifier is self-contained (it exercises
# the public `ironrdp_graphics::zgfx` API through a Rust integration test).
set -euo pipefail

echo "[test-setup] Rust version:    $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:   $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root:  /repo/ironrdp"
echo "[test-setup] Setup complete."
