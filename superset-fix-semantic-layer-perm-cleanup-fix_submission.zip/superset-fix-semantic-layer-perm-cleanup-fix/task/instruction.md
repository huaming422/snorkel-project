## Task

Our security reviewer turned up orphaned `datasource_access` permissions piling up in the metadata database: roles still granting access to semantic-layer views that were deleted a while ago. It traces back to deleting a semantic layer. Some layer deletions clean up their views' permissions and the role grants along with them, others leave the whole lot behind, and it's inconsistent which way it goes.

The pattern the reviewer noticed: deleting a layer with a lot of views, or one whose views weren't already loaded in the current session, tends to leak. Delete a layer whose views got loaded first and it cleans up fine.

Figure out why the cleanup is unreliable and fix it. Don't revoke a permission that another live resource still legitimately uses. Some of these layers carry a large number of views, so the cleanup should stay efficient as that count grows, resolving their permissions in a bounded number of database queries rather than a lookup per view. Focused unit tests live under `tests/unit_tests/semantic_layers/`.
