#!/usr/bin/env bash
# test-setup.sh — runs once before the verifier.
#
# The agent phase is offline (agent_offline = true): the image already bakes
# Superset and its full dependency closure (requirements/development.txt
# installed system-wide at the base commit in image/Dockerfile), so there is
# nothing to install here on the happy path. This script is offline-first:
# it only confirms the repo's import chain works under a minimal app context
# (the interface the behavioral verifier exercises), and falls back to a
# logged online editable install if — and only if — that import fails.
#
# The behavioral verifier runs the repo's own pytest (the baked system
# python3.11 with all deps present) against tests/unit_tests/semantic_layers/,
# using an in-memory SQLite metadata DB. No Postgres/Redis, no examples.
# The verifier HARNESS runs through the canonical /opt/tooling/venv
# (VERIFIER_PYTHON); this script never creates a second verifier install.

set -euo pipefail

REPO=/repo/superset
cd "$REPO"

# Many Superset modules (e.g. superset.models.core via encrypt.py) are
# app-context-bound, so the canonical import smoke test builds a minimal
# TESTING app and enters an app context — mirroring tests/unit_tests/conftest.py.
smoke_test() {
    python3 - <<'PY'
import sys
sys.path.insert(0, "/repo/superset")
from superset.app import SupersetApp
from superset.extensions import appbuilder
from superset.initialization import SupersetAppInitializer

app = SupersetApp(__name__)
app.config.from_object("superset.config")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite://"
app.config["WTF_CSRF_ENABLED"] = False
app.config["TESTING"] = True
app.config["RATELIMIT_ENABLED"] = False
app.config["CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
app.config["DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
app.config["PREVENT_UNSAFE_DB_CONNECTIONS"] = False
appbuilder.baseviews = []
SupersetAppInitializer(app).init_app()
with app.app_context():
    import superset.security.manager  # noqa: F401
    import superset.semantic_layers.models  # noqa: F401
    import superset.connectors.sqla.models  # noqa: F401
    import superset.models.core  # noqa: F401
    print("[test-setup] import chain OK")
PY
}

echo "[test-setup] offline-first import smoke test"
if smoke_test; then
    echo "[test-setup] baked dependency closure is intact; no install needed"
else
    echo "[test-setup] WARNING: baked import chain failed; attempting logged online editable install" >&2
    if command -v uv >/dev/null 2>&1; then
        uv pip install --system -e . &> /tmp/test-setup-install.log \
            || { tail -80 /tmp/test-setup-install.log >&2; exit 1; }
    else
        pip install -e . &> /tmp/test-setup-install.log \
            || { tail -80 /tmp/test-setup-install.log >&2; exit 1; }
    fi
    smoke_test || { echo "[test-setup] import chain still failing after install" >&2; exit 1; }
fi

echo "[test-setup] done"
