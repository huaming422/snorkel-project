"""Behavioral tests for semantic-layer permission cleanup on delete.

These tests exercise the running permission lifecycle through pre-existing,
stable interfaces only:

- ``from superset import security_manager`` and
  ``security_manager.find_permission_view_menu("datasource_access", perm)`` as
  the central probe for whether a ``datasource_access`` PermissionView still
  exists.
- The ORM models ``SemanticLayer`` / ``SemanticView`` and their pre-existing
  ``after_insert`` events (which create the per-view PermissionView on flush),
  ``SqlaTable`` / ``Database`` for the dataset-sharing scenarios, and FAB's
  ``PermissionView`` / ``Role`` for role-grant assertions.

Nothing here imports or names any symbol introduced by the fix: the
child-cleanup hook is discovered through SQLAlchemy's own event registry
(``mapper.dispatch.before_delete``) rather than by function name, so any
implementation that wires cleanup into the parent delete through the standard
event mechanism is accepted regardless of how it names its helpers.

The fixtures mirror the repository's own unit-test fixtures
(``tests/unit_tests/conftest.py``): a module-scoped Superset app under an
application context, and a per-test in-memory SQLite session patched onto the
security manager and ``superset.db``. The verifier file lives outside the
repository test tree, so the fixtures are replicated here rather than resolved
from the repo conftest.
"""

from __future__ import annotations

import uuid
from contextlib import ExitStack
from typing import Any, Iterator
from unittest.mock import MagicMock, patch

import pytest
from sqlalchemy import create_engine, inspect as sqla_inspect, text
from sqlalchemy.engine import Connection, Engine
from sqlalchemy.orm import Session, sessionmaker

PERM_TYPE = "datasource_access"


@pytest.fixture(scope="module")
def app() -> Iterator[Any]:
    """Build a minimal Superset app and keep it for the module."""
    from superset.app import SupersetApp
    from superset.extensions import appbuilder
    from superset.initialization import SupersetAppInitializer

    flask_app = SupersetApp(__name__)
    flask_app.config.from_object("superset.config")
    flask_app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite://"
    flask_app.config["WTF_CSRF_ENABLED"] = False
    flask_app.config["PREVENT_UNSAFE_DB_CONNECTIONS"] = False
    flask_app.config["TESTING"] = True
    flask_app.config["RATELIMIT_ENABLED"] = False
    flask_app.config["CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    flask_app.config["DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    flask_app.config["SERVER_NAME"] = "example.com"
    flask_app.config["APPLICATION_ROOT"] = "/"
    # A singleton appbuilder keeps views across rebuilds; clear them so init
    # can run once more in this process.
    appbuilder.baseviews = []
    SupersetAppInitializer(flask_app).init_app()
    yield flask_app


@pytest.fixture(autouse=True)
def app_context(app: Any) -> Iterator[None]:
    """Push an application context around every test (makes the security
    manager usable), mirroring the repository's autouse fixture."""
    with app.app_context():
        yield


@pytest.fixture
def session() -> Iterator[Session]:
    """In-memory SQLite session wired onto the security manager and
    ``superset.db``, mirroring the repository's ``session`` fixture."""
    engine: Engine = create_engine("sqlite://")
    session_factory = sessionmaker(bind=engine)
    in_memory_session = session_factory()
    # Flask would call db.session.remove(); make it a no-op here.
    in_memory_session.remove = lambda: None  # type: ignore[method-assign]

    with ExitStack() as stack:
        sm_session = stack.enter_context(
            patch("superset.security.SupersetSecurityManager.session")
        )
        sm_session.return_value = in_memory_session
        sm_session.get_bind.return_value = engine
        sm_session.query = in_memory_session.query
        stack.enter_context(patch("superset.db.session", in_memory_session))
        yield in_memory_session

    in_memory_session.close()
    engine.dispose()


def _make_layer(session: Session, name: str) -> Any:
    from superset.semantic_layers.models import SemanticLayer

    layer = SemanticLayer(
        uuid=uuid.uuid4(), name=name, type="test", configuration="{}"
    )
    session.add(layer)
    session.flush()
    return layer


def _make_view(session: Session, layer: Any, name: str, view_id: int | None = None) -> Any:
    from superset.semantic_layers.models import SemanticView

    kwargs: dict[str, Any] = {
        "name": name,
        "semantic_layer_uuid": layer.uuid,
        "configuration": "{}",
    }
    if view_id is not None:
        kwargs["id"] = view_id
    view = SemanticView(**kwargs)
    session.add(view)
    session.flush()
    return view


def _pvm(perm: str) -> Any:
    from superset import security_manager

    return security_manager.find_permission_view_menu(PERM_TYPE, perm)


# ---------------------------------------------------------------------------
# Core defect: deleting a layer whose children are NOT loaded must still remove
# every child view's access permission and detach it from its roles.
# ---------------------------------------------------------------------------
def test_removes_unloaded_child_permissions(session: Session) -> None:
    from flask_appbuilder.security.sqla.models import Role

    from superset.semantic_layers.models import SemanticView

    session.execute(text("PRAGMA foreign_keys=ON"))
    SemanticView.metadata.create_all(session.get_bind())

    layer = _make_layer(session, "Deleted Layer")
    views = [
        _make_view(session, layer, name)
        for name in ("Child View", "Second Child View")
    ]
    view_perms = [view.perm for view in views]
    pvms = [_pvm(perm) for perm in view_perms]
    assert all(pvms), "pre-existing after_insert should create a PVM per view"

    role = Role(name="child view reader", permissions=pvms)
    session.add(role)
    session.commit()
    role_id = role.id

    # Force the children out of the session so the parent delete relies on the
    # database cascade rather than the per-child ORM delete path.
    session.expire(layer, ["semantic_views"])
    session.delete(layer)
    session.commit()
    session.expire_all()

    assert session.query(SemanticView).count() == 0
    assert all(_pvm(perm) is None for perm in view_perms)
    assert session.get(Role, role_id).permissions == []


# ---------------------------------------------------------------------------
# Same end-state when the children ARE loaded in the ORM collection: a fix that
# only patches the unloaded path must not regress this.
# ---------------------------------------------------------------------------
def test_removes_loaded_child_permissions(session: Session) -> None:
    from flask_appbuilder.security.sqla.models import Role

    from superset.semantic_layers.models import SemanticView

    session.execute(text("PRAGMA foreign_keys=ON"))
    SemanticView.metadata.create_all(session.get_bind())

    layer = _make_layer(session, "Loaded Layer")
    views = [
        _make_view(session, layer, name)
        for name in ("Loaded Child", "Second Loaded Child")
    ]
    view_perms = [view.perm for view in views]
    pvms = [_pvm(perm) for perm in view_perms]
    assert all(pvms)

    role = Role(name="loaded view reader", permissions=pvms)
    session.add(role)
    session.commit()
    role_id = role.id

    # Children are loaded in the collection before the delete.
    assert layer.semantic_views
    session.delete(layer)
    session.commit()
    session.expire_all()

    assert session.query(SemanticView).count() == 0
    assert all(_pvm(perm) is None for perm in view_perms)
    assert session.get(Role, role_id).permissions == []


# ---------------------------------------------------------------------------
# The unloaded-cleanup resolves child ownership in a small fixed number of
# SELECTs regardless of child count and removes every orphaned child perm.
# ---------------------------------------------------------------------------
def test_batches_ownership_queries(session: Session) -> None:
    from sqlalchemy import event

    from superset import security_manager
    from superset.semantic_layers.models import SemanticView

    session.execute(text("PRAGMA foreign_keys=ON"))
    SemanticView.metadata.create_all(session.get_bind())

    layer = _make_layer(session, "Many Views")
    child_perms: set[str] = set()
    for number in range(30):
        view = _make_view(session, layer, f"Child {number}")
        child_perms.add(view.perm)
    assert len(child_perms) == 30
    session.commit()

    # Load the parent's own attributes so its delete does not re-read the row,
    # but keep the child collection unloaded so the parent delete relies on the
    # database cascade — the path that strands child permissions before the fix.
    session.refresh(layer)
    session.expire(layer, ["semantic_views"])

    connection: Connection = session.connection()
    selects: list[str] = []

    def record_select(
        _connection: Connection,
        _cursor: Any,
        statement: str,
        _parameters: Any,
        _context: Any,
        _executemany: bool,
    ) -> None:
        if statement.lstrip().upper().startswith("SELECT"):
            selects.append(statement)

    # Measure the real deletion through the public ORM path — the cleanup is
    # never invoked by name, only triggered by deleting the layer. Permission
    # removal is intercepted at the security manager so no view-menu rows are
    # actually dropped, keeping the SELECT trace limited to ownership lookups.
    delete_pvm = MagicMock()
    event.listen(connection, "before_cursor_execute", record_select)
    try:
        with patch.object(security_manager, "_delete_pvm_on_sqla_event", delete_pvm):
            session.delete(layer)
            session.flush()
    finally:
        event.remove(connection, "before_cursor_execute", record_select)

    # Every orphaned child's permission is removed. The view-menu name is passed
    # positionally (permission_name, view_menu_name) or by keyword; accept
    # either. The parent's own permission is removed too, so the call set is a
    # superset of the children.
    removed = {
        (call.args[3] if len(call.args) > 3 else call.kwargs.get("view_menu_name"))
        for call in delete_pvm.call_args_list
    }
    assert child_perms.issubset(removed), (
        f"missing {len(child_perms - removed)} of {len(child_perms)} child "
        "permission removals"
    )
    # Ownership is resolved with a small fixed number of reads, not per-child:
    # the cleanup must scale with a bounded query count rather than issuing a
    # lookup per child view. The specific read shape (SELECT *, column-scoped
    # select, IN-list, join) is left to the implementation.
    assert len(selects) <= 3, (
        f"expected <=3 ownership SELECTs for 30 children, got {len(selects)}:\n"
        + "\n".join(selects)
    )


# ---------------------------------------------------------------------------
# A permission a live dataset still owns must survive deleting a semantic view
# that shares the same key.
# ---------------------------------------------------------------------------
def test_retains_perm_a_dataset_owns_on_view_delete(session: Session) -> None:
    from flask_appbuilder.security.sqla.models import Role

    from superset.connectors.sqla.models import SqlaTable
    from superset.models.core import Database
    from superset.semantic_layers.models import SemanticView

    session.execute(text("PRAGMA foreign_keys=ON"))
    SemanticView.metadata.create_all(session.get_bind())

    database = Database(database_name="shared", sqlalchemy_uri="sqlite://")
    dataset = SqlaTable(id=1, table_name="orders", database=database)
    session.add(dataset)
    session.flush()
    layer = _make_layer(session, "shared")
    view = _make_view(session, layer, "orders", view_id=1)
    assert view.perm == dataset.perm
    key = dataset.perm

    pvm = _pvm(key)
    assert pvm is not None
    role = Role(name="orders reader", permissions=[pvm])
    session.add(role)
    session.commit()
    role_id = role.id

    session.delete(view)
    session.commit()
    session.expire_all()

    assert session.query(SemanticView).count() == 0
    assert session.get(SqlaTable, 1) is not None
    assert _pvm(key) is not None
    assert [p.view_menu.name for p in session.get(Role, role_id).permissions] == [key]


# ---------------------------------------------------------------------------
# A key still owned by a view in ANOTHER layer must survive deleting one layer
# (over-deletion guard: cleanup must not revoke a live resource's grant).
# ---------------------------------------------------------------------------
def test_retains_perm_a_view_in_another_layer_owns_on_layer_delete(
    session: Session,
) -> None:
    from flask_appbuilder.security.sqla.models import Role

    from superset.semantic_layers.models import SemanticView

    session.execute(text("PRAGMA foreign_keys=ON"))
    SemanticView.metadata.create_all(session.get_bind())

    deleted_layer = _make_layer(session, "Deleted Layer")
    retained_layer = _make_layer(session, "Retained Layer")
    deleted_view = _make_view(session, deleted_layer, "Deleted View")
    retained_view = _make_view(session, retained_layer, "Retained View")
    key = deleted_view.perm

    pvm = _pvm(key)
    assert pvm is not None
    role = Role(name="shared view reader", permissions=[pvm])
    session.add(role)
    session.commit()
    role_id = role.id
    retained_view_id = retained_view.id

    # Give the retained view the same key directly, without firing the update
    # event, modelling a legacy shared key.
    from sqlalchemy import update

    session.execute(
        update(SemanticView.__table__)
        .where(SemanticView.__table__.c.id == retained_view_id)
        .values(perm=key)
    )
    session.commit()
    session.expire(deleted_layer, ["semantic_views"])
    session.delete(deleted_layer)
    session.commit()
    session.expire_all()

    assert session.get(SemanticView, retained_view_id).perm == key
    assert _pvm(key) is not None
    assert [p.view_menu.name for p in session.get(Role, role_id).permissions] == [key]


# ---------------------------------------------------------------------------
# Deleting a dataset whose key a live semantic view still owns must retain that
# permission and its role grant.
# ---------------------------------------------------------------------------
def test_retains_dataset_perm_a_view_owns(session: Session) -> None:
    from flask_appbuilder.security.sqla.models import Role

    from superset.connectors.sqla.models import SqlaTable
    from superset.models.core import Database
    from superset.semantic_layers.models import SemanticView

    SemanticView.metadata.create_all(session.get_bind())

    database = Database(database_name="shared", sqlalchemy_uri="sqlite://")
    dataset = SqlaTable(id=1, table_name="orders", database=database)
    session.add(dataset)
    session.flush()
    layer = _make_layer(session, "shared")
    view = _make_view(session, layer, "orders", view_id=1)
    assert view.perm == dataset.perm
    key = view.perm

    pvm = _pvm(key)
    assert pvm is not None
    role = Role(name="shared permission reader", permissions=[pvm])
    session.add(role)
    session.commit()
    role_id = role.id

    session.delete(dataset)
    session.commit()
    session.expire_all()

    assert session.get(SemanticView, view.id) is not None
    assert _pvm(key) is not None
    assert [p.view_menu.name for p in session.get(Role, role_id).permissions] == [key]


# ---------------------------------------------------------------------------
# Wiring: layer deletion must run a before-delete cleanup hook (absent before
# the fix). The standard pattern in this module registers it through
# SQLAlchemy's event system on the model.
# ---------------------------------------------------------------------------
def test_before_delete_hook_is_registered(session: Session) -> None:
    from superset.semantic_layers.models import SemanticLayer

    mapper = sqla_inspect(SemanticLayer)
    listeners = list(mapper.dispatch.before_delete)
    assert listeners, (
        "no before-delete hook is registered on the layer model; unloaded "
        "children cannot be cleaned up without one"
    )
