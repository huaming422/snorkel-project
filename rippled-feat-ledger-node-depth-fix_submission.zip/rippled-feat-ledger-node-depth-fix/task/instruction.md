## Task

when peers sync ledger data, every tree node we reference goes out on the wire
carrying its full node identifier. for a lot of those nodes that's redundant:
the receiver already has what it takes to rebuild the identifier itself, so
we're spending bandwidth on a hot path resending something the other side could
derive. i'd like to shrink that per-node reference to a more compact form.

it changes the wire format, so it has to be negotiated between peers: only use
the leaner reference with a peer that understands it, and stay fully
interoperable with peers that don't, including correctly serving and relaying
ledger data to them. keep the change at the peer protocol and its version
negotiation; how the ledger and its tree get stored and computed is out of
scope.
