// Overlay unit tests for the negotiated, compact per-node reference used when
// peers exchange ledger tree data.
//
// The suite observes behaviour exclusively through pre-existing, stable
// interfaces:
//
//   * `negotiateProtocolVersion` / `makeProtocol` — the free functions that
//     decide which peer-protocol version two nodes agree on.
//   * `PeerImp::onMessage(TMGetLedger)` — the public reply path, driven through
//     the JobQueue and drained with `rendezvous()`, with the outgoing reply
//     captured by overriding `send()`.
//   * `PeerImp::onMessage(TMLedgerData)` — the public relay path, which runs
//     inline and forwards to the peer named by the request cookie.
//
// Crucially, the tests never name the compact wire fields. They only read the
// legacy `nodeid` presence bit (`has_nodeid`) that exists in every version of
// the protobuf, and they obtain compact-format nodes by harvesting them from a
// real reply rather than constructing them field-by-field. A node whose
// reference is *not* the legacy `nodeid` is, by definition, the compact form —
// whatever the implementation chose to call it.

#include <test/jtx/Env.h>

#include <xrpld/app/ledger/LedgerMaster.h>
#include <xrpld/app/main/Application.h>
#include <xrpld/overlay/Compression.h>
#include <xrpld/overlay/Message.h>
#include <xrpld/overlay/Peer.h>
#include <xrpld/overlay/detail/OverlayImpl.h>
#include <xrpld/overlay/detail/PeerImp.h>
#include <xrpld/overlay/detail/ProtocolVersion.h>

#include <xrpl/basics/base_uint.h>
#include <xrpl/basics/make_SSLContext.h>
#include <xrpl/core/JobQueue.h>
#include <xrpl/beast/net/IPEndpoint.h>
#include <xrpl/beast/unit_test/suite.h>
#include <xrpl/protocol/KeyType.h>
#include <xrpl/protocol/PublicKey.h>
#include <xrpl/protocol/SecretKey.h>
#include <xrpl/shamap/SHAMapNodeID.h>

#include <boost/asio/ip/address.hpp>
#include <boost/beast/core/tcp_stream.hpp>
#include <boost/beast/ssl/ssl_stream.hpp>

#include <xrpl.pb.h>

#include <algorithm>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace xrpl::test {

using namespace jtx;

class LedgerNodeDepth_test : public beast::unit_test::Suite
{
    using middle_type = boost::beast::tcp_stream;
    using stream_type = boost::beast::ssl_stream<middle_type>;
    using socket_type = boost::asio::ip::tcp::socket;
    using shared_context = std::shared_ptr<boost::asio::ssl::context>;

    // A peer whose outgoing messages are captured instead of being written to a
    // socket, so a test can inspect exactly what this peer would have sent.
    class PeerTest : public PeerImp
    {
    public:
        PeerTest(
            Application& app,
            std::shared_ptr<PeerFinder::Slot> const& slot,
            http_request_type&& request,
            PublicKey const& publicKey,
            ProtocolVersion protocol,
            Resource::Consumer consumer,
            std::unique_ptr<LedgerNodeDepth_test::stream_type>&& streamPtr,
            OverlayImpl& overlay)
            : PeerImp(
                  app,
                  nextId_++,
                  slot,
                  std::move(request),
                  publicKey,
                  protocol,
                  consumer,
                  std::move(streamPtr),
                  overlay)
        {
        }

        ~PeerTest() override = default;

        void
        run() override
        {
        }

        void
        send(std::shared_ptr<Message> const& m) override
        {
            lastSentMessage_ = m;
        }

        std::shared_ptr<Message>
        getLastSentMessage() const
        {
            return lastSentMessage_;
        }

        void
        clearLastSentMessage()
        {
            lastSentMessage_.reset();
        }

        static void
        resetId()
        {
            nextId_ = 0;
        }

    private:
        inline static Peer::id_t nextId_ = 0;
        std::shared_ptr<Message> lastSentMessage_;
    };

    shared_context context_{makeSslContext("")};

    // Each peer needs a distinct remote endpoint: the slot table rejects a
    // duplicate remote address (returning a null slot), so sharing one address
    // across several peers would hand the peer constructor a null slot. A
    // per-call counter varies the remote address so every peer in a test gets
    // its own slot.
    int nextRemote_ = 2;

    std::shared_ptr<PeerTest>
    createPeer(jtx::Env& env, ProtocolVersion protocol)
    {
        auto& overlay = dynamic_cast<OverlayImpl&>(env.app().getOverlay());
        boost::beast::http::request<boost::beast::http::dynamic_body> request;
        auto streamPtr =
            std::make_unique<stream_type>(socket_type(env.app().getIOContext()), *context_);

        int const octet = nextRemote_++;
        beast::IP::Endpoint const local(boost::asio::ip::make_address("172.1.1.1"), 51235);
        beast::IP::Endpoint const remote(
            boost::asio::ip::make_address("172.1.1." + std::to_string(octet)), 51235);

        PublicKey const key(std::get<0>(randomKeyPair(KeyType::Ed25519)));
        auto consumer = overlay.resourceManager().newInboundEndpoint(remote);
        auto [slot, _] = overlay.peerFinder().newInboundSlot(local, remote);

        auto peer = std::make_shared<PeerTest>(
            env.app(),
            slot,
            std::move(request),
            key,
            protocol,
            consumer,
            std::move(streamPtr),
            overlay);

        overlay.addActive(peer);
        return peer;
    }

    // Build a ledger with enough account-state entries to form a multi-node
    // SHAMap and close it, so a TMGetLedger reply for its account-state tree
    // exercises real inner and leaf tree nodes.
    static void
    seedLedger(jtx::Env& env)
    {
        env.fund(
            XRP(100000),
            "alice",
            "bob",
            "carol",
            "dave",
            "erin",
            "frank",
            "grace",
            "heidi");
        env.close();
    }

    // Request the account-state tree of the most-recently-closed ledger,
    // starting from the root node and pulling a fat subtree, and return the
    // captured reply parsed out of the peer's outgoing message. Selecting the
    // ledger by the `ltCLOSED` type rather than by hash avoids any dependency
    // on ledger-history population and always targets the ledger `seedLedger`
    // just closed.
    static std::optional<protocol::TMLedgerData>
    requestAccountStateReply(jtx::Env& env, std::shared_ptr<PeerTest> const& peer)
    {
        peer->clearLastSentMessage();

        auto getLedger = std::make_shared<protocol::TMGetLedger>();
        getLedger->set_itype(protocol::liAS_NODE);
        getLedger->set_ltype(protocol::ltCLOSED);
        // Pull several levels so the reply contains both inner and leaf nodes.
        getLedger->set_querydepth(3);
        // Root of the tree: depth 0.
        getLedger->add_nodeids(SHAMapNodeID().getRawString());

        peer->onMessage(getLedger);
        // The reply is produced on a JobQueue worker; wait for it to finish.
        env.app().getJobQueue().rendezvous();

        auto const sent = peer->getLastSentMessage();
        if (!sent)
            return std::nullopt;

        auto const& buffer = sent->getBuffer(compression::Compressed::Off);
        if (buffer.size() <= 6)
            return std::nullopt;

        protocol::TMLedgerData reply;
        // Skip the 6-byte framing header (4 bytes size + 2 bytes type).
        if (!reply.ParseFromArray(buffer.data() + 6, buffer.size() - 6))
            return std::nullopt;
        return reply;
    }

    static bool
    everyNodeHasNodeId(protocol::TMLedgerData const& data)
    {
        if (data.nodes_size() <= 0)
            return false;
        for (auto const& n : data.nodes())
            if (!n.has_nodeid())
                return false;
        return true;
    }

    static bool
    noNodeHasNodeId(protocol::TMLedgerData const& data)
    {
        if (data.nodes_size() <= 0)
            return false;
        for (auto const& n : data.nodes())
            if (n.has_nodeid())
                return false;
        return true;
    }

    // Multiset of nodedata blobs, order-independent.
    static std::vector<std::string>
    nodeDataMultiset(protocol::TMLedgerData const& data)
    {
        std::vector<std::string> out;
        out.reserve(data.nodes_size());
        for (auto const& n : data.nodes())
            out.push_back(n.nodedata());
        std::sort(out.begin(), out.end());
        return out;
    }

    // Multiset of (nodedata, nodeid) pairs, order-independent — identity of a
    // fully legacy-encoded reply.
    static std::vector<std::pair<std::string, std::string>>
    legacyRefMultiset(protocol::TMLedgerData const& data)
    {
        std::vector<std::pair<std::string, std::string>> out;
        out.reserve(data.nodes_size());
        for (auto const& n : data.nodes())
            out.emplace_back(n.nodedata(), n.has_nodeid() ? n.nodeid() : std::string{});
        std::sort(out.begin(), out.end());
        return out;
    }

    static std::optional<protocol::TMLedgerData>
    parseReply(std::shared_ptr<Message> const& sent)
    {
        if (!sent)
            return std::nullopt;
        auto const& buffer = sent->getBuffer(compression::Compressed::Off);
        if (buffer.size() <= 6)
            return std::nullopt;
        protocol::TMLedgerData reply;
        if (!reply.ParseFromArray(buffer.data() + 6, buffer.size() - 6))
            return std::nullopt;
        return reply;
    }

    void
    testProtocolNegotiation()
    {
        testcase("protocol negotiation advertises the new version");

        // The newest supported peer-protocol version is now agreed when a peer
        // offers it.
        BEAST_EXPECT(negotiateProtocolVersion("XRPL/2.3") == makeProtocol(2, 3));
        BEAST_EXPECT(
            negotiateProtocolVersion("XRPL/2.1, XRPL/2.2, XRPL/2.3") == makeProtocol(2, 3));
        BEAST_EXPECT(
            negotiateProtocolVersion("RTXP/1.2, XRPL/2.3, XRPL/2.4, XRPL/999.999") ==
            makeProtocol(2, 3));

        // Older peers keep negotiating their highest shared version unchanged.
        BEAST_EXPECT(negotiateProtocolVersion("XRPL/2.2") == makeProtocol(2, 2));
        BEAST_EXPECT(negotiateProtocolVersion("XRPL/2.1") == makeProtocol(2, 1));
        BEAST_EXPECT(negotiateProtocolVersion("XRPL/999.999, WebSocket/1.0") == std::nullopt);
    }

    void
    testEmitEncoding()
    {
        testcase("reply uses compact reference only for a capable peer");

        Env env(*this);
        PeerTest::resetId();

        seedLedger(env);

        auto capablePeer = createPeer(env, makeProtocol(2, 3));
        auto legacyPeer = createPeer(env, makeProtocol(2, 2));

        auto capableReply = requestAccountStateReply(env, capablePeer);
        auto legacyReply = requestAccountStateReply(env, legacyPeer);

        BEAST_EXPECT(capableReply.has_value());
        BEAST_EXPECT(legacyReply.has_value());
        if (!capableReply || !legacyReply)
            return;

        BEAST_EXPECT(capableReply->nodes_size() > 0);
        BEAST_EXPECT(legacyReply->nodes_size() > 0);

        // A capable peer never receives the legacy node identifier; a legacy
        // peer always does.
        BEAST_EXPECT(noNodeHasNodeId(*capableReply));
        BEAST_EXPECT(everyNodeHasNodeId(*legacyReply));

        // The two replies carry the same underlying node data for the same
        // request — only the per-node reference encoding differs.
        BEAST_EXPECT(nodeDataMultiset(*capableReply) == nodeDataMultiset(*legacyReply));

        // The whole point of the capable encoding is a smaller per-node
        // reference on the wire. With identical node data, the only thing that
        // can move the byte count is the reference, so the capable reply must
        // serialize strictly smaller than the legacy one. This observes the
        // size-reduction contract directly without naming any compact field or
        // pinning its encoding: a solution that merely moves the full legacy
        // identifier into a different field (no real compaction) would fail
        // here even though it keeps `nodeid` absent.
        BEAST_EXPECT(capableReply->ByteSizeLong() < legacyReply->ByteSizeLong());
    }

    void
    testRelayDowngradeToLegacyPeer()
    {
        testcase("relaying compact data to an older peer rewrites it to legacy");

        Env env(*this);
        PeerTest::resetId();

        seedLedger(env);

        auto capablePeer = createPeer(env, makeProtocol(2, 3));
        auto legacyPeer = createPeer(env, makeProtocol(2, 2));
        auto relayingPeer = createPeer(env, makeProtocol(2, 3));

        auto capableReply = requestAccountStateReply(env, capablePeer);
        auto legacyReply = requestAccountStateReply(env, legacyPeer);
        BEAST_EXPECT(capableReply.has_value());
        BEAST_EXPECT(legacyReply.has_value());
        if (!capableReply || !legacyReply)
            return;

        // Precondition: the harvested reply is genuinely in the compact form.
        BEAST_EXPECT(noNodeHasNodeId(*capableReply));
        if (!noNodeHasNodeId(*capableReply))
            return;

        // Relay the compact reply toward the older (legacy) peer.
        auto relay = std::make_shared<protocol::TMLedgerData>(*capableReply);
        relay->set_requestcookie(legacyPeer->id());

        legacyPeer->clearLastSentMessage();
        relayingPeer->onMessage(relay);

        auto relayed = parseReply(legacyPeer->getLastSentMessage());
        BEAST_EXPECT(relayed.has_value());
        if (!relayed)
            return;

        // The older peer receives a fully legacy-encoded message...
        BEAST_EXPECT(everyNodeHasNodeId(*relayed));
        BEAST_EXPECT(relayed->nodes_size() == capableReply->nodes_size());
        BEAST_EXPECT(!relayed->has_requestcookie());

        // ...and the reconstructed node identifiers match exactly what a direct
        // legacy reply for the same request would contain.
        BEAST_EXPECT(legacyRefMultiset(*relayed) == legacyRefMultiset(*legacyReply));
    }

    void
    testRelayToCapablePeerUnchanged()
    {
        testcase("relaying compact data to a capable peer leaves it compact");

        Env env(*this);
        PeerTest::resetId();

        seedLedger(env);

        auto capablePeer = createPeer(env, makeProtocol(2, 3));
        auto targetPeer = createPeer(env, makeProtocol(2, 3));
        auto relayingPeer = createPeer(env, makeProtocol(2, 3));

        auto capableReply = requestAccountStateReply(env, capablePeer);
        BEAST_EXPECT(capableReply.has_value());
        if (!capableReply)
            return;

        BEAST_EXPECT(noNodeHasNodeId(*capableReply));
        if (!noNodeHasNodeId(*capableReply))
            return;

        auto relay = std::make_shared<protocol::TMLedgerData>(*capableReply);
        relay->set_requestcookie(targetPeer->id());

        targetPeer->clearLastSentMessage();
        relayingPeer->onMessage(relay);

        auto relayed = parseReply(targetPeer->getLastSentMessage());
        BEAST_EXPECT(relayed.has_value());
        if (!relayed)
            return;

        // No downgrade: the capable target keeps the compact references.
        BEAST_EXPECT(noNodeHasNodeId(*relayed));
        BEAST_EXPECT(nodeDataMultiset(*relayed) == nodeDataMultiset(*capableReply));
        BEAST_EXPECT(!relayed->has_requestcookie());
    }

    void
    testRelayMixedModeRejected()
    {
        testcase("relaying a message that mixes reference formats is rejected");

        Env env(*this);
        PeerTest::resetId();

        seedLedger(env);

        auto capablePeer = createPeer(env, makeProtocol(2, 3));
        auto legacyEmitPeer = createPeer(env, makeProtocol(2, 2));
        auto legacyTarget = createPeer(env, makeProtocol(2, 2));
        auto relayingPeer = createPeer(env, makeProtocol(2, 3));

        auto capableReply = requestAccountStateReply(env, capablePeer);
        auto legacyReply = requestAccountStateReply(env, legacyEmitPeer);
        BEAST_EXPECT(capableReply.has_value());
        BEAST_EXPECT(legacyReply.has_value());
        if (!capableReply || !legacyReply)
            return;

        // Need a compact node and a legacy node to splice together.
        BEAST_EXPECT(noNodeHasNodeId(*capableReply));
        BEAST_EXPECT(everyNodeHasNodeId(*legacyReply));
        if (!noNodeHasNodeId(*capableReply) || !everyNodeHasNodeId(*legacyReply))
            return;

        // Build a message that carries one legacy-encoded node and one
        // compact-encoded node — an inconsistent mixture.
        auto mixed = std::make_shared<protocol::TMLedgerData>(*legacyReply);
        mixed->clear_nodes();
        *mixed->add_nodes() = legacyReply->nodes(0);   // legacy reference
        *mixed->add_nodes() = capableReply->nodes(0);  // compact reference
        mixed->set_requestcookie(legacyTarget->id());

        legacyTarget->clearLastSentMessage();
        relayingPeer->onMessage(mixed);

        // The inconsistent message must not be forwarded.
        BEAST_EXPECT(legacyTarget->getLastSentMessage() == nullptr);
    }

public:
    void
    run() override
    {
        testProtocolNegotiation();
        testEmitEncoding();
        testRelayDowngradeToLegacyPeer();
        testRelayToCapablePeerUnchanged();
        testRelayMixedModeRejected();
    }
};

BEAST_DEFINE_TESTSUITE(LedgerNodeDepth, overlay, xrpl);

}  // namespace xrpl::test
