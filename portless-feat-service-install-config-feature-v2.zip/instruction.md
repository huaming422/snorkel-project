## Task

portless service install only ever sets up one thing, the proxy on HTTPS port 443 with .localhost names. service install should accept the same options as proxy start, with the same precedence and defaults.

service status should report the configuration the installed service actually has, even when the current shell environment is empty or disagrees.

A --lan install on a platform that cannot advertise LAN names over mDNS should fail before it writes anything for the service. Reinstalling on a different port should not leave the previous proxy running.

## User stories / requirements

- Installing the service with a specific set of options (a custom port, HTTPS off, a custom TLD, wildcard on, a custom state directory) and then checking status reports those same values back. A LAN-mode install with a pinned LAN IP shows up as LAN mode with that IP.
- Installing with an unusable configuration (a certificate without its matching key, an out-of-range port, or a malformed TLD) fails with an error naming the problem and leaves no service file behind. Uninstalling still works even with invalid proxy settings in the environment.
