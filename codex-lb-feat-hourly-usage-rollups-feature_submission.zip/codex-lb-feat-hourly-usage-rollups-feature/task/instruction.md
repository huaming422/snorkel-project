## Task

Our usage statistics are built the expensive way: we keep a growing `request_logs` table and, on every read, scan and aggregate those raw rows for the usage dashboard time-series, the quota planner, and the per-API-key trend charts. That gets slow and memory-hungry as the table grows.

We want usage time-series statistics to become permanent: once a time window has passed, its numbers should stay correct from then on, even after the raw rows behind it are pruned by retention.

While raw logs are still present, nothing callers see today may change: every dashboard time-series, quota-planner, and per-API-key trend response returns the same numbers, in the same shapes, from the same API. No schema changes, no frontend changes, no new configuration to switch it on. It runs on both SQLite and PostgreSQL.

It also has to stay consistent with the two processes that touch those same rows: retention pruning, and account lifecycle operations (soft-delete, hard-delete, and merging duplicates).

Out of scope, all still computed from raw logs only: distinct conversation counts, report medians, calendar/timezone day aggregation, and the lifetime usage-summary read.

## User stories / requirements

- Once a window's statistics are permanent, the usage dashboard reads return exactly the values a full scan of the raw logs would give for that window: the time-series at every bucket grain, the total-activity summaries, the top error code, and the earliest activity timestamp.
- Once statistics are permanent, the quota planner's demand bins match a full raw scan exactly, including bins where one group of requests drives one demand component while a different group drives another in the same bin.
- Once statistics are permanent, the per-API-key trend buckets match a full raw scan, both across the older windows that are now permanent and across the most recent activity that is still only in the raw logs.
- Making statistics permanent happens incrementally in the background and is safe to repeat: running it again, resuming after an interruption, or restarting from scratch never changes the values the reads return. Before anything is made permanent, the reads fall back to scanning raw logs and return today's values, with nothing to switch on.
- After a window's raw rows have been pruned by retention, that window's statistics are still correct. Retention never removes a raw row whose statistics have not been recorded yet, so no window's numbers are ever lost to a retention pass.
- After an account is soft-deleted, hard-deleted, or merged into another account, the permanent statistics show the same result the raw logs would: a soft-deleted account's history still appears under the deleted-account view, a hard-deleted account's history is gone, and a merged account's history moves onto the surviving account.
