"""Validation harness for the durable usage-statistics task.

This module provides *framework plumbing only* for the validation stories:

- it bootstraps the application database onto an isolated temporary SQLite
  file BEFORE importing ``app.db.session`` (that module binds its engine and
  session factory at import time, so the environment has to be in place
  first);
- it seeds raw request-log rows through the pre-existing
  ``RequestLogsRepository.add_log`` entry point and the pre-existing ORM
  models;
- it drives the background capture through the pre-existing scheduler tick
  (``build_account_usage_rollup_scheduler()._fold_as_leader()``), and, when a
  design registers a SEPARATE background fold entry point, through whatever
  additional ``module:async_callable`` paths the caller lists in
  ``EXTRA_FOLD_ENTRYPOINTS`` (read from the submitted patch) — so a design
  that extends the pre-existing scheduler and one that runs its own tick are
  both captured, without the harness pinning either shape;
- it reads usage statistics back through the three pre-existing read
  repositories (dashboard time-series, quota-planner demand, per-key
  trends);
- it exercises retention pruning through the pre-existing
  ``run_retention_pass`` entry point, and physically removes aged raw rows
  through the ORM so a "statistics survive raw pruning" assertion is real.

Design constraints this file deliberately honours:

* It hardcodes no name, column, table, or helper that the solution gets to
  choose. The only application literals it imports are stable facts present
  at the base commit: the fold-lag window, the warmup request kinds, and the
  pre-existing lifetime-fold / retention entry points. Everything durable is
  observed through method return values.
* Every public helper returns a plain JSON-friendly dict of concrete
  observed values. It never returns a bare pass/fail flag; the story decides
  what to assert.
* The "legacy" snapshot is captured from a full raw scan *before* any fold,
  and the "durable" snapshot is captured from the same reads *after* the
  fold has run and the aged raw rows behind the folded window have been
  physically deleted. A reader that still scans raw rows loses the pruned
  window; a reader backed by a durable store does not. That difference is
  what the stories assert.
"""

from __future__ import annotations

import asyncio
import importlib
import inspect
import os
import tempfile
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Callable

# ---------------------------------------------------------------------------
# Environment bootstrap — MUST run before any ``app.*`` import.
#
# ``app.db.session`` resolves settings and constructs its async engine and
# session factory at module import time, keyed on the database URL. Point it
# at a throwaway SQLite file and give the token encryptor a writable key path
# before that import happens. Retention is disabled by default here and set
# per-scenario via the application settings env vars.
# ---------------------------------------------------------------------------

_STATE_DIR = Path(tempfile.mkdtemp(prefix="usage-durable-harness-"))
_DB_PATH = _STATE_DIR / "store.db"
_KEY_PATH = _STATE_DIR / "token.key"

os.environ.setdefault("CODEX_LB_DATABASE_URL", f"sqlite+aiosqlite:///{_DB_PATH}")
os.environ.setdefault("CODEX_LB_ENCRYPTION_KEY_FILE", str(_KEY_PATH))
os.environ.setdefault("CODEX_LB_UPSTREAM_BASE_URL", "https://example.invalid/backend-api")
# Keep every background scheduler off; the harness drives the fold explicitly.
os.environ.setdefault("CODEX_LB_USAGE_REFRESH_ENABLED", "false")
os.environ.setdefault("CODEX_LB_MODEL_REGISTRY_ENABLED", "false")
os.environ.setdefault("CODEX_LB_QUOTA_PLANNER_SCHEDULER_ENABLED", "false")
os.environ.setdefault("CODEX_LB_AUTOMATIONS_SCHEDULER_ENABLED", "false")
os.environ.setdefault("CODEX_LB_STICKY_SESSION_CLEANUP_ENABLED", "false")
os.environ.setdefault("CODEX_LB_HTTP_RESPONSES_SESSION_BRIDGE_ENABLED", "false")
os.environ.setdefault("CODEX_LB_REQUEST_LOG_RETENTION_DAYS", "0")
os.environ.setdefault("CODEX_LB_USAGE_HISTORY_RETENTION_DAYS", "0")

from sqlalchemy import delete, select  # noqa: E402

from app.core.config.settings import get_settings  # noqa: E402
from app.core.crypto import TokenEncryptor  # noqa: E402
from app.core.utils.time import utcnow  # noqa: E402
from app.db.models import (  # noqa: E402
    Account,
    AccountStatus,
    Base,
    RequestKind,
    RequestLog,
)
from app.db.session import SessionLocal, close_db, engine  # noqa: E402
from app.modules.accounts.repository import AccountsRepository  # noqa: E402
from app.modules.accounts.usage_rollup import FOLD_LAG, run_fold_pass  # noqa: E402
from app.modules.accounts.usage_rollup_scheduler import (  # noqa: E402
    build_account_usage_rollup_scheduler,
)
from app.modules.api_keys.repository import ApiKeysRepository  # noqa: E402
from app.modules.quota_planner.repository import QuotaPlannerRepository  # noqa: E402
from app.modules.request_logs.repository import RequestLogsRepository  # noqa: E402
from app.core.retention.job import run_retention_pass  # noqa: E402

_MODEL = "gpt-5.1-codex"


# ---------------------------------------------------------------------------
# Async plumbing.
# ---------------------------------------------------------------------------


def _run(coro_factory: Callable[[], Any]) -> Any:
    """Run one scenario coroutine on a fresh event loop; reset schema first.

    Each public helper is synchronous so the calling test does not need
    an async test runner. The engine is disposed at the end of every call so
    no SQLite connection survives into the next scenario's loop.
    """

    async def _wrapper() -> Any:
        try:
            await _reset_schema()
            return await coro_factory()
        finally:
            await close_db()

    return asyncio.run(_wrapper())


async def _reset_schema() -> None:
    await close_db()
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)


def _set_retention_days(request_log_days: int) -> None:
    os.environ["CODEX_LB_REQUEST_LOG_RETENTION_DAYS"] = str(request_log_days)
    get_settings.cache_clear()


# ---------------------------------------------------------------------------
# Seeding helpers (all through pre-existing models / repositories).
# ---------------------------------------------------------------------------


def _floor_hour(moment: datetime) -> datetime:
    return moment.replace(minute=0, second=0, microsecond=0)


def _make_account(account_id: str, email: str, *, chatgpt_account_id: str | None = None) -> Account:
    encryptor = TokenEncryptor()
    return Account(
        id=account_id,
        email=email,
        chatgpt_account_id=chatgpt_account_id,
        plan_type="plus",
        access_token_encrypted=encryptor.encrypt("access"),
        refresh_token_encrypted=encryptor.encrypt("refresh"),
        id_token_encrypted=encryptor.encrypt("id"),
        last_refresh=utcnow(),
        status=AccountStatus.ACTIVE,
        deactivation_reason=None,
    )


async def _add_log(
    logs: RequestLogsRepository,
    *,
    account_id: str | None,
    request_id: str,
    requested_at: datetime,
    input_tokens: int | None = 100,
    output_tokens: int | None = 50,
    cached_input_tokens: int | None = 20,
    cost_usd: float = 0.01,
    status: str = "success",
    error_code: str | None = None,
    request_kind: str = RequestKind.NORMAL.value,
    service_tier: str | None = None,
    reasoning_effort: str | None = None,
    api_key_id: str | None = "key_main",
    model: str = _MODEL,
) -> None:
    await logs.add_log(
        account_id=account_id,
        request_id=request_id,
        model=model,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        latency_ms=100,
        status=status,
        error_code=error_code,
        requested_at=requested_at,
        cost_usd=cost_usd,
        cached_input_tokens=cached_input_tokens,
        reasoning_effort=reasoning_effort,
        service_tier=service_tier,
        api_key_id=api_key_id,
        request_kind=request_kind,
    )


# ---------------------------------------------------------------------------
# Fold + prune drivers.
# ---------------------------------------------------------------------------


def _parse_entrypoints(raw: str) -> list[str]:
    """Split a ``module:callable`` list (comma / whitespace separated)."""
    items: list[str] = []
    for chunk in raw.replace(",", " ").split():
        chunk = chunk.strip()
        if chunk:
            items.append(chunk)
    return items


async def _call_entrypoint(spec: str, *, now: datetime | None) -> None:
    """Import and invoke one ``module:callable`` capture entry point.

    The callable is passed ``now=`` only if it declares that parameter, and
    awaited if it returns a coroutine, so a design's own fold tick / fold pass
    can be driven without the harness knowing its signature.
    """
    module_name, _, attr = spec.partition(":")
    if not module_name or not attr:
        raise ValueError(f"EXTRA_FOLD_ENTRYPOINTS entry {spec!r} is not 'module:callable'")
    target = getattr(importlib.import_module(module_name), attr)
    kwargs: dict[str, Any] = {}
    try:
        if "now" in inspect.signature(target).parameters:
            kwargs["now"] = now
    except (TypeError, ValueError):
        pass
    result = target(**kwargs)
    if inspect.isawaitable(result):
        await result


async def _run_extra_fold_entrypoints(*, now: datetime | None = None) -> None:
    """Drive any capture entry points the solution registered beyond the
    pre-existing scheduler tick.

    A design that extends the pre-existing scheduler is captured by
    ``_fold_as_leader`` alone; a design that runs capture through its own tick
    or fold pass lists those ``module:callable`` paths in the
    ``EXTRA_FOLD_ENTRYPOINTS`` environment variable (the per-trial validation
    script sets it from the submitted patch). The harness never hardcodes the
    callable name, so no particular fold shape is pinned.
    """
    for spec in _parse_entrypoints(os.environ.get("EXTRA_FOLD_ENTRYPOINTS", "")):
        await _call_entrypoint(spec, now=now)


async def _drive_full_fold(passes: int = 3) -> None:
    """Advance the durable store(s) to current through the registered capture
    entry points.

    ``_fold_as_leader`` runs the pre-existing scheduler tick's fold work
    directly (it does not go through leader election), swallowing its own
    exceptions; any additional entry points a design registers are driven
    alongside it (see ``_run_extra_fold_entrypoints``). Repeat a few times so a
    multi-slice backlog converges; capture is idempotent once caught up.
    """
    scheduler = build_account_usage_rollup_scheduler()
    for _ in range(passes):
        await scheduler._fold_as_leader()
        await _run_extra_fold_entrypoints()


async def _drive_capture_behind(now: datetime, passes: int = 4) -> None:
    """Reach the state the retention gate must defend: the window's lifetime
    totals are current but its time-axis statistics have NOT been captured.

    Driven through the pre-existing ``run_fold_pass`` entry point, which brings
    the lifetime account totals to a current watermark. For a design that keeps
    a time-axis store on a watermark of its own, this leaves that store behind,
    so a correct retention gate must still refuse to prune the window's raw
    rows. For a design that captures every statistic in one pass, this same
    call captures the window too — in which case retention may legitimately
    prune it, because the invariant the case asserts (the window's statistics
    survive the pass) holds either way. The harness does not assume which shape
    the solution took; it asserts only that no window's statistics are lost.
    """
    for _ in range(passes):
        await run_fold_pass(now=now)


async def _prune_folded_raw() -> int:
    """Physically delete raw rows a full fold-lag below the folded frontier.

    The fold leaves the trailing ``FOLD_LAG`` window live, so rows older than
    two fold-lags from now are certainly folded. Deleting them leaves a
    raw-scanning reader unable to recover the window, while a durable-store
    reader still serves it.
    """
    cutoff = utcnow() - 2 * FOLD_LAG
    async with SessionLocal() as session:
        result = await session.execute(
            delete(RequestLog).where(RequestLog.requested_at < cutoff).returning(RequestLog.id)
        )
        await session.commit()
        return len(result.scalars().all())


async def _count_raw() -> int:
    async with SessionLocal() as session:
        return len((await session.execute(select(RequestLog.id))).scalars().all())


# ---------------------------------------------------------------------------
# Reader snapshot helpers (pre-existing read interfaces).
# ---------------------------------------------------------------------------


def _bucket_key(agg: Any) -> tuple:
    # Keep a real NULL service_tier distinct from an empty string.
    return (agg.bucket_epoch, agg.model, agg.service_tier is not None, agg.service_tier or "")


def _buckets_snapshot(buckets: list[Any]) -> list[list[Any]]:
    rows = []
    for agg in sorted(buckets, key=_bucket_key):
        rows.append(
            [
                agg.bucket_epoch,
                agg.model,
                "__null__" if agg.service_tier is None else agg.service_tier,
                agg.request_count,
                agg.error_count,
                agg.input_tokens,
                agg.output_tokens,
                agg.cached_input_tokens,
                round(float(agg.cost_usd), 6),
            ]
        )
    return rows


def _activity_snapshot(agg: Any) -> dict[str, Any]:
    # Additive fields only; conversation metrics are a documented raw-only
    # non-goal and are intentionally excluded from the parity contract.
    return {
        "request_count": agg.request_count,
        "error_count": agg.error_count,
        "input_tokens": agg.input_tokens,
        "output_tokens": agg.output_tokens,
        "cached_input_tokens": agg.cached_input_tokens,
        "cost_usd": round(float(agg.cost_usd), 6),
    }


def _demand_snapshot(bins: list[Any]) -> list[list[Any]]:
    rows = []
    for b in bins:
        rows.append(
            [
                b.slot_epoch,
                b.account_id if b.account_id is not None else "__null__",
                b.api_key_id if b.api_key_id is not None else "__null__",
                b.model,
                b.reasoning_effort if b.reasoning_effort is not None else "__null__",
                b.request_kind,
                b.status,
                b.input_tokens,
                b.cached_input_tokens,
                b.output_tokens,
                b.request_count,
                round(float(b.cost_usd), 6),
            ]
        )
    rows.sort(key=lambda r: r[:7])
    return rows


def _trends_snapshot(buckets: list[Any]) -> list[list[Any]]:
    rows = [[b.bucket_epoch, b.total_tokens, round(float(b.total_cost_usd), 6)] for b in buckets]
    rows.sort(key=lambda r: r[0])
    return rows


# ===========================================================================
# Story 1 — parity_timeseries_reads
# ===========================================================================


async def _parity_timeseries(seed_live_tail: bool, bucket_seconds: int) -> dict[str, Any]:
    now = utcnow()
    since = now - timedelta(days=12)
    old_hour = _floor_hour(now - timedelta(days=5))
    live_hour = _floor_hour(now - timedelta(hours=1))

    async with SessionLocal() as session:
        accounts = AccountsRepository(session)
        logs = RequestLogsRepository(session)
        await accounts.upsert(_make_account("acc_ts", "ts@example.com"))
        # Earliest row sits exactly on the hour boundary so the durable
        # (hour-granular) earliest timestamp equals the raw earliest.
        await _add_log(logs, account_id="acc_ts", request_id="old_ok_0", requested_at=old_hour, service_tier=None)
        # Distinct nullable dimensions in the same bucket: NULL vs '' vs value.
        await _add_log(logs, account_id="acc_ts", request_id="old_ok_1", requested_at=old_hour + timedelta(seconds=11), service_tier="")
        await _add_log(logs, account_id="acc_ts", request_id="old_ok_2", requested_at=old_hour + timedelta(seconds=12), service_tier="flex")
        await _add_log(
            logs,
            account_id="acc_ts",
            request_id="old_err",
            requested_at=old_hour + timedelta(seconds=40),
            status="error",
            error_code="upstream_500",
            service_tier=None,
        )
        # A warmup row that the reads must exclude from statistics.
        await _add_log(
            logs,
            account_id="acc_ts",
            request_id="old_warm",
            requested_at=old_hour + timedelta(seconds=50),
            request_kind=RequestKind.WARMUP.value,
        )
        if seed_live_tail:
            for i in range(2):
                await _add_log(
                    logs,
                    account_id="acc_ts",
                    request_id=f"live_ok_{i}",
                    requested_at=live_hour + timedelta(seconds=10 + i),
                    service_tier=None,
                )

    async def _read():
        async with SessionLocal() as session:
            rlr = RequestLogsRepository(session)
            buckets = await rlr.aggregate_by_bucket(since, bucket_seconds=bucket_seconds)
            activity = await rlr.aggregate_activity_since(since)
            top_error = await rlr.top_error_since(since)
            earliest = await rlr.earliest_activity_at()
            return {
                "buckets": _buckets_snapshot(buckets),
                "activity": _activity_snapshot(activity),
                "top_error_code": top_error,
                "earliest_epoch": None if earliest is None else int(earliest.timestamp()),
            }

    legacy = await _read()
    await _drive_full_fold()
    pruned = await _prune_folded_raw()
    durable = await _read()

    # Floor the old-window anchor to the grain under test so it matches the
    # reader's bucket_epoch at both the hour and 6-hour grains.
    old_epoch = (int(old_hour.timestamp()) // bucket_seconds) * bucket_seconds
    old_buckets = [r for r in durable["buckets"] if r[0] == old_epoch]
    return {
        "legacy": legacy,
        "durable": durable,
        "pruned_raw_rows": pruned,
        # Concrete guards from the deliberately-seeded old window (all gone
        # for a raw-scanning reader after the prune).
        "old_window_request_count": sum(r[3] for r in old_buckets),
        "old_window_input_tokens": sum(r[5] for r in old_buckets),
        "old_window_distinct_tier_buckets": len(old_buckets),
        "activity_request_count": durable["activity"]["request_count"],
        "top_error_code": durable["top_error_code"],
    }


def parity_timeseries_reads(*, seed_live_tail: bool = True, bucket_seconds: int = 3600, **_: Any) -> dict[str, Any]:
    """Dashboard time-series parity across fold + raw pruning."""
    return _run(lambda: _parity_timeseries(seed_live_tail, bucket_seconds))


# ===========================================================================
# Story 2 — parity_planner_demand
# ===========================================================================


async def _parity_planner(grouping: str) -> dict[str, Any]:
    now = utcnow()
    since = now - timedelta(days=12)
    old_slot = _floor_hour(now - timedelta(days=5))
    live_slot = _floor_hour(now - timedelta(hours=1))

    async with SessionLocal() as session:
        accounts = AccountsRepository(session)
        logs = RequestLogsRepository(session)
        await accounts.upsert(_make_account("acc_dem", "dem@example.com"))
        if grouping == "split":
            # Same 15-min slot, two DISTINCT demand groups keyed on a nullable
            # dimension kept distinct (NULL vs ''): one group drives input
            # tokens, the other drives output tokens. A coarser fold grain
            # would collapse these and shrink the per-group demand.
            for i in range(2):
                await _add_log(
                    logs,
                    account_id="acc_dem",
                    request_id=f"old_in_{i}",
                    requested_at=old_slot + timedelta(seconds=10 + i),
                    reasoning_effort=None,
                    input_tokens=500,
                    output_tokens=0,
                )
            for i in range(2):
                await _add_log(
                    logs,
                    account_id="acc_dem",
                    request_id=f"old_out_{i}",
                    requested_at=old_slot + timedelta(seconds=20 + i),
                    reasoning_effort="",
                    input_tokens=0,
                    output_tokens=400,
                )
        else:  # "single"
            for i in range(4):
                await _add_log(
                    logs,
                    account_id="acc_dem",
                    request_id=f"old_one_{i}",
                    requested_at=old_slot + timedelta(seconds=10 + i),
                    reasoning_effort="high",
                    input_tokens=500,
                    output_tokens=0,
                )
        # Live tail (stays raw).
        await _add_log(
            logs,
            account_id="acc_dem",
            request_id="live_dem",
            requested_at=live_slot + timedelta(seconds=5),
            reasoning_effort="high",
        )

    async def _read():
        async with SessionLocal() as session:
            qpr = QuotaPlannerRepository(session)
            bins = await qpr.aggregate_demand_bins(since=since, bucket_seconds=900)
            return _demand_snapshot(bins)

    legacy = await _read()
    await _drive_full_fold()
    pruned = await _prune_folded_raw()
    durable = await _read()

    old_epoch = int((old_slot.timestamp() // 900) * 900)
    old_bins = [r for r in durable if r[0] == old_epoch]
    return {
        "legacy": legacy,
        "durable": durable,
        "pruned_raw_rows": pruned,
        "old_slot_bin_count": len(old_bins),
        "old_slot_total_input_tokens": sum(r[7] for r in old_bins),
        "old_slot_total_output_tokens": sum(r[9] for r in old_bins),
        "total_bin_count": len(durable),
    }


def parity_planner_demand(*, grouping: str = "split", **_: Any) -> dict[str, Any]:
    """Quota-planner demand-bin parity across fold + raw pruning."""
    return _run(lambda: _parity_planner(grouping))


# ===========================================================================
# Story 3 — parity_api_key_trends
# ===========================================================================


async def _parity_trends(old_row_count: int) -> dict[str, Any]:
    now = utcnow()
    old_hour = _floor_hour(now - timedelta(days=5))
    live_hour = _floor_hour(now - timedelta(hours=1))
    since = _floor_hour(now - timedelta(days=12))
    until = now + timedelta(hours=1)

    async with SessionLocal() as session:
        accounts = AccountsRepository(session)
        logs = RequestLogsRepository(session)
        await accounts.upsert(_make_account("acc_key", "key@example.com"))
        # Old window under one key (now-prunable); input 100 + output 50 ->
        # 150 tokens/row by the trend reader's token formula.
        for i in range(old_row_count):
            await _add_log(
                logs,
                account_id="acc_key",
                request_id=f"old_key_{i}",
                requested_at=old_hour + timedelta(seconds=10 + i),
                api_key_id="key_trend",
            )
        # Live tail under the same key (stays raw).
        for i in range(2):
            await _add_log(
                logs,
                account_id="acc_key",
                request_id=f"live_key_{i}",
                requested_at=live_hour + timedelta(seconds=10 + i),
                api_key_id="key_trend",
            )

    async def _read():
        async with SessionLocal() as session:
            akr = ApiKeysRepository(session)
            buckets = await akr.trends_by_key("key_trend", since=since, until=until, bucket_seconds=3600)
            return _trends_snapshot(buckets)

    legacy = await _read()
    await _drive_full_fold()
    pruned = await _prune_folded_raw()
    durable = await _read()

    old_epoch = int(old_hour.timestamp())
    live_epoch = int(live_hour.timestamp())
    old_bucket = [r for r in durable if r[0] == old_epoch]
    live_bucket = [r for r in durable if r[0] == live_epoch]
    return {
        "legacy": legacy,
        "durable": durable,
        "pruned_raw_rows": pruned,
        "old_bucket_total_tokens": old_bucket[0][1] if old_bucket else 0,
        "live_bucket_total_tokens": live_bucket[0][1] if live_bucket else 0,
        "bucket_count": len(durable),
    }


def parity_api_key_trends(*, old_row_count: int = 3, **_: Any) -> dict[str, Any]:
    """Per-API-key trend parity across folded history and live tail."""
    return _run(lambda: _parity_trends(old_row_count))


# ===========================================================================
# Story 4 — fold_incremental_idempotent
# ===========================================================================


async def _fold_idempotent(hours: int, rows_per_hour: int) -> dict[str, Any]:
    now = utcnow()
    since = now - timedelta(days=12)
    base = now - timedelta(days=5)

    seeded = 0
    async with SessionLocal() as session:
        accounts = AccountsRepository(session)
        logs = RequestLogsRepository(session)
        await accounts.upsert(_make_account("acc_idem", "idem@example.com"))
        for h in range(hours):
            hour = _floor_hour(base - timedelta(hours=h * 6))
            for i in range(rows_per_hour):
                await _add_log(
                    logs,
                    account_id="acc_idem",
                    request_id=f"idem_{h}_{i}",
                    requested_at=hour + timedelta(seconds=10 + i),
                )
                seeded += 1

    async def _read():
        async with SessionLocal() as session:
            rlr = RequestLogsRepository(session)
            buckets = await rlr.aggregate_by_bucket(since, bucket_seconds=3600)
            activity = await rlr.aggregate_activity_since(since)
            return {"activity": _activity_snapshot(activity), "bucket_count": len(buckets)}

    # Before any fold the reads must already return today's values (no switch
    # to flip): raw fallback.
    before_fold = await _read()

    scheduler = build_account_usage_rollup_scheduler()
    # Fold once, then physically prune the folded raw so a raw-scanning reader
    # cannot recover the window.
    await scheduler._fold_as_leader()
    pruned = await _prune_folded_raw()
    after_prune = await _read()
    # Resume / restart: fold again repeatedly — must neither lose nor
    # double-count the already-folded window.
    await scheduler._fold_as_leader()
    await scheduler._fold_as_leader()
    after_refold = await _read()

    return {
        "before_fold": before_fold,
        "after_prune": after_prune,
        "after_refold": after_refold,
        "pruned_raw_rows": pruned,
        "before_request_count": before_fold["activity"]["request_count"],
        "after_prune_request_count": after_prune["activity"]["request_count"],
        "after_refold_request_count": after_refold["activity"]["request_count"],
        "after_prune_bucket_count": after_prune["bucket_count"],
    }


def fold_incremental_idempotent(*, hours: int = 1, rows_per_hour: int = 4, **_: Any) -> dict[str, Any]:
    """Folding is incremental, idempotent, and absent until it runs."""
    return _run(lambda: _fold_idempotent(hours, rows_per_hour))


# ===========================================================================
# Story 5 — retention_min_gate
# ===========================================================================


async def _retention_gate(scenario: str) -> dict[str, Any]:
    now = utcnow()
    since = now - timedelta(days=90)
    old_hour = _floor_hour(now - timedelta(days=40))

    async with SessionLocal() as session:
        accounts = AccountsRepository(session)
        logs = RequestLogsRepository(session)
        await accounts.upsert(_make_account("acc_ret", "ret@example.com"))
        # One very old row (older than the 30-day retention window, so
        # eligible for pruning) and one fresh row that must always survive.
        await _add_log(logs, account_id="acc_ret", request_id="ret_old", requested_at=old_hour)
        await _add_log(logs, account_id="acc_ret", request_id="ret_recent", requested_at=now - timedelta(hours=1))

    if scenario == "capture_behind":
        # Reach the state the retention gate must defend without assuming the
        # design's fold shape: the lifetime totals are current, and a design
        # that keeps a time-axis store on its own watermark is left behind.
        await _drive_capture_behind(now)
    else:  # "caught_up"
        await _drive_full_fold()

    _set_retention_days(30)
    deleted = await run_retention_pass(now=now)

    async with SessionLocal() as session:
        rlr = RequestLogsRepository(session)
        activity = await rlr.aggregate_activity_since(since)

    return {
        "deleted_request_logs": int(deleted["request_logs"]),
        "raw_rows_remaining": await _count_raw(),
        "activity_request_count": activity.request_count,
    }


def retention_min_gate(*, scenario: str = "capture_behind", **_: Any) -> dict[str, Any]:
    """Retention never removes a raw row whose statistics are not yet captured;
    captured windows survive pruning."""
    return _run(lambda: _retention_gate(scenario))


# ===========================================================================
# Story 6 — lifecycle_mirrors
# ===========================================================================


async def _seed_account_history(account_id: str, email: str, old_hour: datetime, *, chatgpt_account_id: str | None = None) -> None:
    async with SessionLocal() as session:
        accounts = AccountsRepository(session)
        logs = RequestLogsRepository(session)
        await accounts.upsert(
            _make_account(account_id, email, chatgpt_account_id=chatgpt_account_id),
            merge_by_email=False,
        )
        await _add_log(
            logs,
            account_id=account_id,
            request_id=f"{account_id}_ok",
            requested_at=old_hour + timedelta(seconds=10),
            api_key_id="key_life",
        )
        await _add_log(
            logs,
            account_id=account_id,
            request_id=f"{account_id}_err",
            requested_at=old_hour + timedelta(seconds=20),
            status="error",
            error_code="upstream_500",
            api_key_id="key_life",
        )


async def _lifecycle_reads(since: datetime) -> dict[str, Any]:
    async with SessionLocal() as session:
        rlr = RequestLogsRepository(session)
        qpr = QuotaPlannerRepository(session)
        # Dashboard activity keeps soft-deleted history; planner demand
        # excludes it. Both read the durable store after the raw prune.
        activity = await rlr.aggregate_activity_since(since)
        demand = await qpr.aggregate_demand_bins(since=since, bucket_seconds=900)
        account_ids = sorted({b.account_id for b in demand if b.account_id is not None})
    return {
        "dashboard_total_request_count": activity.request_count,
        "planner_demand_request_count": sum(b.request_count for b in demand),
        "surviving_planner_account_ids": account_ids,
    }


async def _lifecycle(operation: str) -> dict[str, Any]:
    now = utcnow()
    since = now - timedelta(days=12)
    old_hour = _floor_hour(now - timedelta(days=5))

    if operation == "merge":
        # Two duplicate accounts sharing one upstream identity.
        await _seed_account_history("acc_can", "merge@example.com", old_hour, chatgpt_account_id="chatgpt_ident")
        await _seed_account_history("acc_can__dup", "merge@example.com", old_hour, chatgpt_account_id="chatgpt_ident")
        await _drive_full_fold()
        await _prune_folded_raw()
        async with SessionLocal() as session:
            reauth = _make_account("acc_can", "merge@example.com", chatgpt_account_id="chatgpt_ident")
            saved = await AccountsRepository(session).upsert(
                reauth, merge_by_email=False, merge_by_chatgpt_identity=True
            )
            assert saved.id == "acc_can"
        return await _lifecycle_reads(since)

    # soft_delete / hard_delete: one operated account plus a survivor whose
    # durable statistics must be left untouched.
    await _seed_account_history("acc_op", "op@example.com", old_hour)
    await _seed_account_history("acc_keep", "keep@example.com", old_hour)
    await _drive_full_fold()
    await _prune_folded_raw()

    async with SessionLocal() as session:
        if operation == "hard_delete":
            assert await AccountsRepository(session).delete("acc_op", delete_history=True)
        else:  # "soft_delete"
            assert await AccountsRepository(session).delete("acc_op")

    return await _lifecycle_reads(since)


def lifecycle_mirrors(*, operation: str = "soft_delete", **_: Any) -> dict[str, Any]:
    """Durable statistics follow soft-delete, hard-delete, and merge."""
    return _run(lambda: _lifecycle(operation))
