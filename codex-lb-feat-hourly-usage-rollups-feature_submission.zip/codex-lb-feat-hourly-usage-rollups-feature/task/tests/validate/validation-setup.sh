#!/usr/bin/env bash
# validation-setup.sh — runs once before the validation agent starts.
#
# tests/test-setup.sh has already activated the baked project virtualenv at
# /opt/venv (the full dependency closure for this repo was baked at the base
# commit; the agent phase and this setup both run OFFLINE, so nothing is
# installed here). This script:
#   1. Re-activates the venv (idempotent) so the validation tests import the
#      possibly-agent-modified application source.
#   2. Keeps uv strictly offline — a cache miss fails fast instead of hanging
#      on a dead network.
#   3. Smoke-imports the harness and the pre-existing read / fold / retention
#      entry points so a bad import surfaces here, not mid-run.

set -euo pipefail

REPO=/repo/codex-lb
cd "$REPO"

export UV_OFFLINE=1

# Route grading infrastructure through the baked project venv.
# shellcheck disable=SC1091
. /opt/venv/bin/activate

# Smoke-import the harness + the stable interfaces it drives through. The
# harness bootstraps its own isolated SQLite database at import time, so a
# successful import also proves the app package loads under the chosen env.
python - <<'PY'
import sys

sys.path.insert(0, "/tests/validate")
import test_harness  # noqa: F401

# The pre-existing, base-commit-stable interfaces the harness uses.
import app.modules.request_logs.repository  # noqa: F401
import app.modules.quota_planner.repository  # noqa: F401
import app.modules.api_keys.repository  # noqa: F401
import app.modules.accounts.repository  # noqa: F401
import app.modules.accounts.usage_rollup  # noqa: F401
import app.modules.accounts.usage_rollup_scheduler  # noqa: F401
import app.core.retention.job  # noqa: F401

print("[validation-setup] test_harness + codex-lb interfaces import OK")
PY

export REPO_NAME=codex-lb
