#!/usr/bin/env bash
# test-setup.sh — runs once before the verifier (sourced, not exec'd).
# The task image already bakes the full dependency closure at the base commit
# into /opt/venv (project `dev` group: pytest, pytest-asyncio, pytest-timeout,
# aiosqlite, SQLAlchemy, FastAPI, httpx, …). Nothing is installed here — the
# agent phase and this setup both run offline, so every import must already be
# present in the baked venv. This script only activates that venv and verifies
# the pre-existing entrypoints the verifier reads through still import.
set -euo pipefail

REPO=/repo/codex-lb
cd "$REPO"

# Keep this task's uv strictly offline (a cache miss fails fast rather than
# retrying against a dead network). Scoped to this script only.
export UV_OFFLINE=1

# Route all grading infrastructure through the baked project venv, which is
# where the (possibly agent-modified) application source is importable from.
. /opt/venv/bin/activate

# Sanity check: the pre-existing read/fold/retention entrypoints the verifier
# exercises must import. Fail fast here rather than from a confusing pytest
# stack later. These are the stable interfaces present at the base commit.
python - <<'PY'
import app.modules.request_logs.repository as rlr
import app.modules.quota_planner.repository as qpr
import app.modules.api_keys.repository as akr
import app.modules.accounts.usage_rollup as ur
import app.core.retention.job as rj
from app.db.models import AccountUsageRollupState, RequestLog

assert hasattr(rlr.RequestLogsRepository, "aggregate_by_bucket")
assert hasattr(rlr.RequestLogsRepository, "aggregate_activity_between")
assert hasattr(rlr.RequestLogsRepository, "top_error_between")
assert hasattr(rlr.RequestLogsRepository, "earliest_activity_at")
assert hasattr(qpr.QuotaPlannerRepository, "aggregate_demand_bins")
assert hasattr(akr.ApiKeysRepository, "trends_by_key")
assert hasattr(ur, "run_fold_pass")
assert hasattr(rj, "run_retention_pass")
print("pre-existing entrypoints import OK")
PY
