#!/usr/bin/env bash
# Test-setup for seaweedfs-fix-tier-move-consistency.
#
# The image already carries the full dependency closure for BOTH cargo
# workspaces at the base commit (seaweed-common and seaweed-volume), warmed
# with `cargo fetch --locked` + `cargo test --no-run --locked` (Dockerfile
# steps 8 and 10). The behavioral verifier is a native `cargo test`
# integration test hosted in seaweed-volume/tests/, which the image's warm
# already compiled the lib dependencies for. There are no verifier-only
# packages to install and no services to start or data to seed.
#
# This script therefore only reports the toolchain and asserts the workspace
# is where the verifier expects it. It must succeed with the network cut
# (smoke Check 3 offline fold runs it under `docker run --network none`), so it
# performs no fetches.

set -euo pipefail

WORKSPACE=/repo/seaweedfs/seaweed-volume

echo "[test-setup] Rust version:    $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:   $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root:  ${WORKSPACE}"

if [[ ! -f "${WORKSPACE}/Cargo.toml" ]]; then
    echo "[test-setup] ERROR: ${WORKSPACE}/Cargo.toml not found" >&2
    exit 1
fi

echo "[test-setup] Setup complete."
