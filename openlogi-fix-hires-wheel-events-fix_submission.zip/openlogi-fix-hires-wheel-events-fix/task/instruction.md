## Task

a couple of scroll-wheel problems showing up on some of our Logitech mice.

with smooth scrolling turned on, a few mice every so often throw in phantom sideways scroll motion that nothing on screen is actually driving.

separately, flipping the wheel between ratchet and free-spin with the physical button under the wheel no longer moves the SmartShift card in the app over to match. the card just sits on whatever mode it was on until you change it from inside the app. it used to follow the button on the mouse.

both of these seem to trace back to how the scroll wheel's events get handled, and they may be leaning on the same machinery. can you dig in, find the root cause(s), and fix them?
