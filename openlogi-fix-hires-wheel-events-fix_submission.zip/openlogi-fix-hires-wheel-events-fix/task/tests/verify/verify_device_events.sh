#!/usr/bin/env bash
#
# Behavioural verifier for the device event/inventory layer (crate
# `openlogi-device`). Two behaviours are graded here, both observable only
# from inside the crate (the event-index table, the subscription decoder, the
# revision counter and the probe-cache schema constant are all crate-private),
# so this verifier appends `#[cfg(test)]` modules to the crate's own source and
# runs `cargo test --lib` over just those added tests. A child module sees its
# ancestors' private items, so the added tests reach the private decode path
# through the SAME entry points the crate's own unit tests use — no behaviour
# is imported, only exercised.
#
# The added tests assert BEHAVIOUR, never a particular internal shape:
#
#   1. A device-reported wheel ratchet/free-spin switch on the `0x2121` index
#      is treated as a device-side settings change — it advances the device's
#      settings-revision counter so a client re-reads the wheel mode. A wheel
#      MOVEMENT on the same index is ordinary input and must NOT advance it.
#      The test reads only the revision counter; it never names the event
#      variant or the index field the fix adds, so any structure that advances
#      the revision on a switch and not on a movement passes.
#
#   2. The probe-cache schema constant is greater than its pre-change value, so
#      an on-disk cache written before the new event index existed is discarded
#      and re-probed instead of loaded with a stale shape.
#
# Mechanics: back up the two source files, append the test modules, run only
# the added tests by name, restore the originals (even on failure), and fail if
# either added test is missing from the run (a filter that matched nothing must
# not read as a pass) or did not report `ok`.

set -uo pipefail

# The checkout the suite grades lives at /repo/${REPO_NAME}; the runner exports
# REPO_NAME. Derive the path from it so this verifier reads the same tree the
# patch was applied to, never a divergent hardcoded path.
REPO="/repo/${REPO_NAME:?REPO_NAME must be set by the verifier runner}"
EVENTS="$REPO/crates/openlogi-device/src/inventory/events.rs"
PERSIST="$REPO/crates/openlogi-device/src/inventory/persist.rs"

MARK_RATCHET=__reward_ratchet_switch_bumps_revision
MARK_SCHEMA=__reward_schema_version_discards_stale_cache

restore() {
    [ -f "$EVENTS.rewardbak" ] && mv -f "$EVENTS.rewardbak" "$EVENTS"
    [ -f "$PERSIST.rewardbak" ] && mv -f "$PERSIST.rewardbak" "$PERSIST"
}
trap restore EXIT

cp -p "$EVENTS" "$EVENTS.rewardbak"
cp -p "$PERSIST" "$PERSIST.rewardbak"

# --- crit 3: a ratchet switch bumps the revision; a movement does not --------
cat >> "$EVENTS" <<'RUST'

#[cfg(test)]
mod __reward_verify_wheel_settings_change {
    use hidpp::nibble::U4;
    use hidpp::protocol::v20;

    use super::*;

    fn mk_state() -> Arc<SubscriptionState> {
        let (notifier, _receiver) = event_channel();
        Arc::new(SubscriptionState {
            protocol: Some(ReceiverProtocol::Bolt),
            devices: RwLock::new(Vec::new()),
            receiver_snapshot_depth: AtomicUsize::new(0),
            notifier,
        })
    }

    /// Build an unsolicited broadcast (software id 0) from device index 1 on
    /// `feature_index` with the given event sub-id. `long` selects a 16-byte
    /// long report; otherwise a 3-byte short report.
    fn broadcast(feature_index: u8, sub_id: u8, body: [u8; 3], long: bool) -> HidppMessage {
        let header = v20::MessageHeader {
            device_index: 1,
            feature_index,
            function_id: U4::from_lo(sub_id),
            software_id: U4::from_lo(0),
        };
        if long {
            let mut payload = [0u8; 16];
            payload[..3].copy_from_slice(&body);
            v20::Message::Long(header, payload).into()
        } else {
            v20::Message::Short(header, body).into()
        }
    }

    #[test]
    fn __reward_ratchet_switch_bumps_revision() {
        let state = mk_state();
        let handle = EventSubscriptionHandle {
            state: Arc::clone(&state),
        };
        // A mouse whose feature table carries the hi-res wheel (`0x2121`) at
        // runtime table position 3 (0x0001, 0x0003, 0x2121).
        let features = EventFeatureIndices::from_feature_ids(&[0x0001, 0x0003, 0x2121]);
        handle.register_device(1, features);
        assert_eq!(handle.settings_revision(1), 0, "no broadcasts seen yet");

        // Ratchet/free-spin switch (sub-id 1): the mouse telling the host its
        // wheel mode flipped on-device. One byte of body, so it is carried by a
        // short report. This is a device-side settings change; it must advance
        // the revision so a client re-reads SmartShift.
        state.decode(broadcast(3, 1, [0, 0, 0], false), false);
        assert_eq!(
            handle.settings_revision(1),
            1,
            "a wheel ratchet switch on the 0x2121 index must be counted as a settings change \
             and advance settings_revision",
        );

        // Wheel MOVEMENT (sub-id 0) on the same index: ordinary scroll input,
        // not a setting. It must NOT advance the revision. A fix that treats
        // every wheel report as a settings change would fail here.
        state.decode(broadcast(3, 0, [1, 0xff, 0xff], true), false);
        assert_eq!(
            handle.settings_revision(1),
            1,
            "a wheel movement is input, not a settings change, and must not advance \
             settings_revision",
        );
    }
}
RUST

# --- crit 5: the probe-cache schema version is bumped past its old value -----
cat >> "$PERSIST" <<'RUST'

#[cfg(test)]
mod __reward_verify_schema_version {
    use super::SCHEMA_VERSION;

    #[test]
    fn __reward_schema_version_discards_stale_cache() {
        // The event-index table gained a new field for the wheel event, so a
        // cache written before it must be discarded rather than loaded with a
        // stale shape. The schema version is bumped past its prior value (15)
        // to force that discard-and-re-probe.
        assert!(
            SCHEMA_VERSION > 15,
            "probe-cache schema version must be increased past 15 so a pre-existing v15 \
             cache lacking the new event index is discarded and re-probed",
        );
    }
}
RUST

cd "$REPO" || exit 1

LOG=$(mktemp)
# Run only the two added tests by name. Compiling the crate's test target still
# requires the agent's own code to build; running by name isolates grading to
# these behavioural assertions.
cargo test -p openlogi-device --lib "__reward_" -- --test-threads=1 2>&1 | tee "$LOG"
CARGO_STATUS=${PIPESTATUS[0]}

status=0
if [ "$CARGO_STATUS" -ne 0 ]; then
    echo "FAIL: cargo test exited $CARGO_STATUS" >&2
    status=1
fi
# A filter that matched nothing exits 0 but runs no tests: require each added
# test to have run and reported ok.
if ! grep -Eq "test .*${MARK_RATCHET} \.\.\. ok" "$LOG"; then
    echo "FAIL: ${MARK_RATCHET} did not run or did not pass" >&2
    status=1
fi
if ! grep -Eq "test .*${MARK_SCHEMA} \.\.\. ok" "$LOG"; then
    echo "FAIL: ${MARK_SCHEMA} did not run or did not pass" >&2
    status=1
fi

rm -f "$LOG"
exit "$status"
