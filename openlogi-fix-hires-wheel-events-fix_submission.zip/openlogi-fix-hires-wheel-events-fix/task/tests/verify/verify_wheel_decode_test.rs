//! Behavioural verifier for the hi-res wheel event decode.
//!
//! Tests through the PRE-EXISTING public entry point of the `0x2121`
//! hi-res wheel feature in the `openlogi-hidpp` crate (library name
//! `hidpp`):
//!
//!   * `hidpp::feature::hires_wheel::decode_event(&v20::Message, u8, u8)
//!      -> Option<HiResWheelEvent>`
//!   * `hidpp::feature::hires_wheel::{HiResWheelEvent, WheelRatchetState}`
//!   * `hidpp::protocol::v20::{Message, MessageHeader}`, `hidpp::nibble::U4`
//!
//! `decode_event` has a stable signature (feeding it a synthetic report is
//! exactly how the crate's own module tests exercise it) and is the highest
//! public boundary where the two decode behaviours this verifier gates are
//! observable. The test imports ONLY these pre-existing public items —
//! nothing the fix invents (no trait method, no length constant, no payload
//! helper). A report that arrives in a SHORT frame carries three payload
//! bytes on the wire; the same report in a LONG frame carries sixteen. The
//! verifier observes what `decode_event` returns for each, never how the
//! implementation decides it.
//!
//! Decoupling rationale:
//!   * A movement is asserted via `matches!(.., WheelMovement(_))`, not by
//!     reading `delta_horizontal` / `delta_vertical`. The symptom is a
//!     phantom horizontal delta read out of zero padding; pinning the delta
//!     value would couple the test to the (intentionally unchanged) sign
//!     convention. Behaviour under test is "does a short movement decode at
//!     all", so the variant is the right granularity.
//!   * The ratchet case asserts the `RatchetSwitch` variant decodes from a
//!     short frame — the behaviour that a blanket "drop every short report"
//!     over-correction would break. It does not assert which byte the state
//!     came from.

use hidpp::feature::hires_wheel::{decode_event, HiResWheelEvent};
use hidpp::nibble::U4;
use hidpp::protocol::v20::{Message, MessageHeader};

const DEVICE_INDEX: u8 = 2;
const FEATURE_INDEX: u8 = 0x0e;

/// Movement event sub-id (function id 0) and ratchet-switch sub-id
/// (function id 1), as the wheel feature dispatches them. These are the
/// protocol's stable HID++ sub-ids, not fix-invented values.
const MOVEMENT_SUB_ID: u8 = 0;
const RATCHET_SUB_ID: u8 = 1;

fn header(function_id: u8) -> MessageHeader {
    MessageHeader {
        device_index: DEVICE_INDEX,
        feature_index: FEATURE_INDEX,
        function_id: U4::from_lo(function_id),
        // Zero software id: an unsolicited device broadcast, not a reply.
        software_id: U4::from_lo(0),
    }
}

/// A short HID++ 2.0 frame: three payload bytes on the wire.
fn short(function_id: u8, payload: [u8; 3]) -> Message {
    Message::Short(header(function_id), payload)
}

/// A long HID++ 2.0 frame: sixteen payload bytes on the wire. The first
/// `bytes` are set; the rest are zero, exactly as a real long report pads.
fn long(function_id: u8, bytes: &[u8]) -> Message {
    let mut payload = [0u8; 16];
    payload[..bytes.len()].copy_from_slice(bytes);
    Message::Long(header(function_id), payload)
}

/// Root-cause reproduction. A wheel MOVEMENT that arrives in a short frame
/// must be dropped rather than decoded from zero padding: a short frame
/// cannot carry the horizontal-delta bytes, so pre-fix the horizontal delta
/// was read out of padding the device never sent, producing phantom sideways
/// motion. The identical movement in a long frame still decodes.
///
/// `[1, 0xff, 0xff]` is a complete low-resolution vertical move (resolution
/// bit clear, one period, deltaV = -1) — a payload that looks valid, so the
/// drop is about the wire length, not an unparsable body.
#[test]
fn a_short_movement_is_dropped_but_a_long_one_decodes() {
    assert_eq!(
        decode_event(&short(MOVEMENT_SUB_ID, [1, 0xff, 0xff]), DEVICE_INDEX, FEATURE_INDEX),
        None,
        "a wheel movement in a short frame must be dropped, not decoded from zero padding \
         (pre-fix this decoded a movement whose horizontal delta came from padding)",
    );

    assert!(
        matches!(
            decode_event(&long(MOVEMENT_SUB_ID, &[1, 0xff, 0xff]), DEVICE_INDEX, FEATURE_INDEX),
            Some(HiResWheelEvent::WheelMovement(_)),
        ),
        "the same movement in a long frame still carries its full payload and must decode",
    );
}

/// The drop is specific to the movement event, not a blanket rejection of
/// short frames. A ratchet-switch broadcast reads a single byte, so it still
/// decodes from a short frame. A fix that drops every short report (an
/// over-correction) would fail here.
#[test]
fn a_short_ratchet_switch_still_decodes() {
    assert!(
        matches!(
            decode_event(&short(RATCHET_SUB_ID, [1, 0, 0]), DEVICE_INDEX, FEATURE_INDEX),
            Some(HiResWheelEvent::RatchetSwitch(_)),
        ),
        "a ratchet switch reads one byte and must still decode from a short frame; only the \
         movement, which needs more bytes than a short frame carries, is dropped",
    );
}
