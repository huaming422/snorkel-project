#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# The image baked the full workspace dependency closure and compiled every test
# target at the base commit (image/Dockerfile blocks 8 and 10), so this script is
# offline-first: it verifies the cargo caches are warm and fails fast on a miss
# instead of reaching for crates.io. The oracle changes no Cargo.lock/Cargo.toml,
# so no new crate is ever fetched here.
cd /repo/openlogi

# Force cargo offline right after cd so a cache miss fails fast rather than
# silently reaching a registry (the offline fold runs this with the network cut).
export CARGO_NET_OFFLINE=true

# Dependencies: offline-first against the image bake, logged online fallback.
if cargo fetch --locked > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] cargo deps satisfied from image"
elif { unset CARGO_NET_OFFLINE; cargo fetch --locked >> /tmp/test-setup-install.log 2>&1; }; then
    echo "[test-setup] cargo deps fetched online (image bake was stale)"
    export CARGO_NET_OFFLINE=true
else
    tail -40 /tmp/test-setup-install.log >&2; exit 1
fi

# No services, no seed data: the symptom is exercised entirely by in-process unit
# tests built on synthetic HID++ reports. No assertion logic belongs here.
