## Task

The GUI helps operators run red-teaming campaigns, but campaign identity and the security findings discovered during a campaign currently live outside the backend. Give both durable records that the GUI can manage and query.

Introduce **Operations** for named campaigns and **Findings** for severity-classified results. Each finding belongs to an operation and can cite stored `AttackResult` and `ScenarioResult` evidence.

Make operations and findings available through the existing model, memory, and `/api` backend interfaces. The GUI can create and list operations at `GET|POST /api/operations`, using `id` and `name` resource fields and an `items` list envelope. Operations created through the API must remain consistent with operations recovered by the migration. A populated database must reach this feature through an Alembic upgrade to the current head. Keep the existing compatibility-header gate on business requests.

Work within the provisioned offline environment: leave packages and lockfiles alone. Preserve the `tests/unit/` suite and the ORM's SQLite and SQL Server behavior, including dialect-specific types and collations. Extend the existing mechanisms instead of building a parallel store.

## User stories / requirements

- Callers choose a finding's id and create it beneath an existing operation. Repeating a create with the same id and content returns the stored finding; changing the content while reusing the id produces a conflict. Reject creation beneath an unknown operation.
- Classify finding harm with the shared harm vocabulary and its tolerant fallback. A stored label that is absent from the current taxonomy must remain readable and listable, with its original text retained and surfaced through that fallback.
- Linking a recorded attack to a finding creates one evidence link for that pair, including under concurrent requests. A repeated attach reports the existing link. Only attacks with saved messages qualify as evidence.
- For each evidence link, list its availability, objective, outcome, score, and source operation. Resolve the current operation name when the attack has an id link; otherwise use its retained historical name. Removing an attack makes its evidence unavailable while retaining the evidence row. An attach must leave the attack's attribution intact.
- On a populated database, the forward migration creates the new tables and backfills operation links for recorded activity. Merge legacy names with the same identity after case and surrounding-whitespace normalization, and skip blank or over-bound names without failing the migration. Refuse downgrade while operation rows exist.
