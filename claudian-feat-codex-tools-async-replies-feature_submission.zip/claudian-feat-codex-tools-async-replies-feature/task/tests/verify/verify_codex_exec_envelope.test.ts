// @ts-nocheck
//
// Behavioral verifier — criterion `exec_envelope_strip`.
//
// WHAT THIS TESTS (observable behavior, not implementation):
//   When the codex provider runs a script, its raw tool result arrives wrapped
//   in the provider's transport envelope
//       Script completed|failed|running with cell ID <id>
//       Wall time <...>
//       Output:
//       <the actual script output>
//   The common tool pipeline must strip ONLY that transport envelope (so the
//   rendered script card shows the real output), must leave arbitrary script
//   output intact even when the output itself contains JSON or an "Output:"
//   line, and must surface a failed run as an error state.
//
// WHY THESE INTERFACES ARE STABLE (survives all four blueprint alternatives):
//   `normalizeCodexToolResult(normalizedName, rawResult)` and
//   `isCodexToolOutputError(output)` are PRE-EXISTING public exports of the
//   codex result-normalization module (present in the pre-fix tree, each with
//   its own pre-existing unit test and 8 call sites spanning BOTH the live
//   notification router AND the history-reload path). Every alternative keeps
//   the "normalize the provider's native result, then render" architecture
//   (the task's stated design axis); none of them relocates codex result
//   normalization out of this module. These two functions are therefore a
//   genuine architectural chokepoint, not introduced by this change.
//
//   DELIBERATELY NOT IMPORTED HERE (introduced by this change or
//   solution-chosen — would fail the alternative-implementation gate):
//   formatCodexQuestionReply /
//   parseCodexQuestionReply / stripCodexQuestionReplies, the
//   `<send_user_message_question_reply>` wire envelope, ProviderRegistry
//   .formatQuestionReply, InputController.answerQuestion. The reply round-trip
//   and reply-not-command behaviors are graded by validation stories
//   (adaptive discovery), not pinned here.
//
// Provenance of every literal below: the exec transport-envelope grammar and
// the "Script failed"/"Script completed"/"Script running with cell ID" markers
// are codex app-server protocol facts (external, stable), listed in task.toml
// context as "pre-existing facts of the provider, not inventions of this
// change." The native tool name 'exec' is likewise a codex native tool name.

import {
  isCodexToolOutputError,
  normalizeCodexToolResult,
} from '@/providers/codex/normalization/codexToolNormalization';

const LF = '\n';

describe('exec_envelope_strip: transport envelope removal', () => {
  it('strips a completed-run transport envelope, leaving the raw output', () => {
    const raw = [
      'Script completed',
      'Wall time 12ms',
      'Output:',
      'hello world',
    ].join(LF);

    const out = normalizeCodexToolResult('exec', raw);

    expect(out).toBe('hello world');
    // The transport markers must be gone from the rendered result.
    expect(out).not.toMatch(/Wall time/);
    expect(out).not.toMatch(/^Script completed/);
  });

  it('strips a failed-run envelope while keeping the real output body', () => {
    const raw = [
      'Script failed',
      'Wall time 3ms',
      'Output:',
      'Traceback: boom',
    ].join(LF);

    const out = normalizeCodexToolResult('exec', raw);

    expect(out).toBe('Traceback: boom');
    expect(out).not.toMatch(/Wall time/);
  });

  it('strips a running-with-cell-ID envelope (the async/streaming first chunk)', () => {
    const raw = [
      'Script running with cell ID cell-42',
      'Wall time 0ms',
      'Output:',
      'partial line 1',
    ].join(LF);

    const out = normalizeCodexToolResult('exec', raw);

    expect(out).toBe('partial line 1');
    expect(out).not.toMatch(/cell ID/);
  });

  it('removes ONLY the leading transport envelope — inner "Output:" and JSON survive', () => {
    // Senior nuance: arbitrary script output may itself contain an "Output:"
    // label or a JSON object. A naive strip that removes every "Output:\n"
    // prefix (or JSON-unwraps) would corrupt real output. Only the single
    // leading transport envelope may be removed.
    const body = ['{"result": 1}', 'Output:', 'second block'].join(LF);
    const raw = ['Script completed', 'Wall time 9ms', 'Output:', body].join(LF);

    const out = normalizeCodexToolResult('exec', raw);

    expect(out).toBe(body);
    expect(out).toContain('{"result": 1}');
    expect(out).toContain('Output:'); // the INNER label is preserved
  });

  it('passes through exec output that has no transport envelope unchanged', () => {
    const raw = 'plain output with no envelope';
    expect(normalizeCodexToolResult('exec', raw)).toBe(raw);
  });

  it('does not treat a non-script tool result as an exec envelope', () => {
    // A tool whose name is not a script tool must not have exec-envelope
    // stripping applied; its result is returned unchanged (it is not in the
    // set of tools whose results are transport-wrapped).
    const raw = ['Script completed', 'Wall time 1ms', 'Output:', 'x'].join(LF);
    const out = normalizeCodexToolResult('Read', raw);
    expect(out).toBe(raw);
  });
});

describe('exec_envelope_strip: failure detection', () => {
  it('marks a "Script failed" result as an error', () => {
    expect(isCodexToolOutputError('Script failed\nWall time 1ms\nOutput:\nboom')).toBe(true);
  });

  it('marks a bare "Script failed" line as an error', () => {
    expect(isCodexToolOutputError('Script failed')).toBe(true);
  });

  it('does NOT mark a "Script completed" result as an error', () => {
    expect(isCodexToolOutputError('Script completed\nWall time 1ms\nOutput:\nok')).toBe(false);
  });

  it('does NOT mark ordinary successful output as an error', () => {
    expect(isCodexToolOutputError('all good here')).toBe(false);
  });
});
