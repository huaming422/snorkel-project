// @ts-nocheck
//
// Framework plumbing ONLY for the chat tool-rendering validation stories.
//
// This harness does three things and nothing else:
//   1. Polyfills the handful of Obsidian DOM helpers that tests/setupWindow.ts
//      does not already provide under jsdom (empty/addClass/removeClass/
//      toggleClass/scrollIntoView). setupWindow.ts already provides
//      createDiv/createEl/createSpan/createSvg/setText and the prototype
//      helpers, so we only add the missing ones, each behind an existence
//      guard so a repo that adds them keeps its own version.
//   2. `restoreTool(...)` turns a native provider tool call + result into the
//      common ToolCallInfo the chat renders, by driving the SAME two
//      pre-existing public entrypoints the real app uses — the live
//      notification router and the saved-session parser. It performs NO
//      assertions about how a card looks; it only hands back the normalized
//      tool object (or the parsed session messages) so the test file can
//      assert observable behavior.
//   3. Thin pass-throughs to the three public render entrypoints and the
//      session parser, so the test file never has to re-import module paths.
//
// It deliberately does NOT: import any symbol the change introduces, name any
// reply/question-controller/registry method, assert any CSS class, icon
// string, or header label, or encode any solution-chosen output shape. Every
// identifier it uses (the render entrypoints, the session parser, the live
// router, the native codex tool/record field names) pre-exists in the base
// tree and is part of the provider's own protocol — not an invention of this
// change. Discovery of anything the solution chooses is the test file's job.
//
// Lazy `require()` inside each function (not top-level imports) so that any
// jest.mock(...) a test file declares is hoisted and registered before these
// modules load. Do NOT convert these to top-level imports.

// ---------------------------------------------------------------------------
// 1. Obsidian DOM helpers missing from setupWindow.ts under jsdom.
// ---------------------------------------------------------------------------
function installMissingDomHelpers(): void {
  if (typeof HTMLElement === 'undefined') return;
  const proto = HTMLElement.prototype as any;
  if (!proto.empty) {
    proto.empty = function (this: HTMLElement) { this.replaceChildren(); };
  }
  if (!proto.addClass) {
    proto.addClass = function (this: HTMLElement, ...classes: string[]) {
      this.classList.add(...classes);
    };
  }
  if (!proto.removeClass) {
    proto.removeClass = function (this: HTMLElement, ...classes: string[]) {
      this.classList.remove(...classes);
    };
  }
  if (!proto.toggleClass) {
    proto.toggleClass = function (this: HTMLElement, names: string | string[], enabled?: boolean) {
      for (const name of Array.isArray(names) ? names : [names]) {
        this.classList.toggle(name, enabled);
      }
    };
  }
  if (!proto.scrollIntoView) {
    proto.scrollIntoView = function () { /* no-op under jsdom */ };
  }
}

/**
 * Create a detached host div (already appended to document.body) that card
 * renderers can draw into. jsdom is assumed (DOM stories run under the
 * `/** @jest-environment jsdom *\/` docblock).
 */
export function host(): HTMLElement {
  installMissingDomHelpers();
  return (document.body as any).createDiv();
}

// ---------------------------------------------------------------------------
// 2. Native tool call + result -> common ToolCallInfo, via the real
//    live/history entrypoints. `name` is a native provider tool name
//    (e.g. the script-exec tool, a web-run tool, an agent-lifecycle tool,
//    the async-question tool) — a protocol fact, supplied by the test file.
//    `wrapped=true` models the provider nesting a call inside a script-exec
//    envelope (the native `custom_tool_call` form), exactly as the live
//    stream and saved sessions can carry it.
// ---------------------------------------------------------------------------
export function restoreTool(
  mode: 'live' | 'history',
  name: string,
  input: unknown,
  output: string = '',
  wrapped: boolean = false,
): any {
  installMissingDomHelpers();
  const { testTime } = require('@test/helpers/testClock');

  const call = wrapped
    ? {
        type: 'custom_tool_call',
        call_id: 'tool',
        name: 'exec',
        input: `text(await tools.${name}(${JSON.stringify(input)}));`,
      }
    : { type: 'function_call', call_id: 'tool', name, arguments: JSON.stringify(input) };
  const result = {
    type: wrapped ? 'custom_tool_call_output' : 'function_call_output',
    call_id: 'tool',
    output,
  };

  if (mode === 'history') {
    const { parseCodexSessionContent } = require('@/providers/codex/history/CodexHistoryStore');
    const jsonl = [call, result]
      .map((payload, index) =>
        JSON.stringify({ type: 'response_item', timestamp: testTime({ seconds: index }), payload }),
      )
      .join('\n');
    const tools = parseCodexSessionContent(jsonl).flatMap((m: any) => m.toolCalls ?? []);
    return tools[0];
  }

  const { CodexNotificationRouter } = require('@/providers/codex/runtime/CodexNotificationRouter');
  const chunks: any[] = [];
  const router = new CodexNotificationRouter((chunk: any) => chunks.push(chunk), '/workspace');
  router.beginTurn();
  for (const item of [call, result]) router.handleNotification('rawResponseItem/completed', { item });
  router.handleNotification('turn/completed', {
    turn: { id: 'turn', items: [], status: 'completed', error: null },
  });
  const uses = chunks.filter(chunk => chunk.type === 'tool_use');
  const results = chunks.filter(chunk => chunk.type === 'tool_result');
  if (uses.length !== 1) {
    throw new Error(`expected exactly one tool_use chunk, got ${uses.length}`);
  }
  const tool: any = { ...uses[0] };
  if (results.length > 0) {
    tool.status = results[0].isError ? 'error' : 'completed';
    tool.result = results[0].content;
  }
  return tool;
}

/**
 * Parse a saved session from raw record objects. Each record is JSON-stringified
 * with an injected timestamp and joined with newlines — the on-disk JSONL shape
 * the saved-session parser already consumes. Returns the parsed messages so the
 * test file can read toolCalls / role / displayContent, etc.
 *
 * A record that supplies only `{ payload }` is wrapped as a `response_item`
 * (the persisted-transcript record envelope the parser expects) — that record
 * `type` is a protocol fact of the saved-session format, not anything this
 * change introduces. A record may still set its own `type`/`timestamp` to
 * override.
 */
export function parseSession(records: unknown[]): any[] {
  installMissingDomHelpers();
  const { testTime } = require('@test/helpers/testClock');
  const { parseCodexSessionContent } = require('@/providers/codex/history/CodexHistoryStore');
  const jsonl = records
    .map((record: any, index: number) =>
      JSON.stringify({ type: 'response_item', timestamp: testTime({ seconds: index }), ...record }),
    )
    .join('\n');
  return parseCodexSessionContent(jsonl);
}

// ---------------------------------------------------------------------------
// 3. Pass-throughs to the public render entrypoints.
// ---------------------------------------------------------------------------

/** Render a stored (history) tool card into a fresh host; return the block. */
export function renderStored(tool: any, options: Record<string, unknown> = {}): HTMLElement {
  const { renderStoredToolCall } = require('@/features/chat/rendering/ToolCallRenderer');
  return renderStoredToolCall(host(), tool, { initiallyExpanded: true, ...options });
}

/**
 * Render a live tool card; returns { block, elements } so the test file can
 * later swap in a result via `update(...)`.
 */
export function renderLive(tool: any, options: Record<string, unknown> = {}): { block: HTMLElement; elements: Map<string, HTMLElement> } {
  const { renderToolCall } = require('@/features/chat/rendering/ToolCallRenderer');
  const elements = new Map<string, HTMLElement>();
  const block = renderToolCall(host(), tool, elements, { initiallyExpanded: true, ...options });
  return { block, elements };
}

/** Apply an updated tool (e.g. a resolved result) to a live card. */
export function update(toolId: string, tool: any, elements: Map<string, HTMLElement>): void {
  const { updateToolCallResult } = require('@/features/chat/rendering/ToolCallRenderer');
  updateToolCallResult(toolId, tool, elements);
}

/** Count how many tool-card blocks a parsed session produced (dedup check). */
export function toolCallsOf(messages: any[]): any[] {
  return messages.flatMap((m: any) => m.toolCalls ?? []);
}
