#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# Runs with the network cut during the smoke gate's offline fold, so everything
# below must be satisfiable from the image bake (§1.5).
cd /repo/claudian

# Fail a cache miss fast instead of reaching for the registry. npm offline
# switch lives here (not image ENV): harbor installs the agent harness with
# `uv tool install` while the network is still up at trial prep.
export npm_config_offline=true

# Dependencies: offline-first against the image bake, logged online fallback.
# The image ran `npm ci` at the base commit; node_modules + /opt/cache/npm are
# warm. --ignore-scripts skips postinstall (it only copies a dev .env.local).
if npm ci --offline --ignore-scripts > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] deps satisfied from image"
elif { unset npm_config_offline; npm ci --ignore-scripts >> /tmp/test-setup-install.log 2>&1; }; then
    echo "[test-setup] deps installed online (image bake was stale)"
else
    tail -40 /tmp/test-setup-install.log >&2; exit 1
fi

# No services to start and no data to seed: the suite is pure jest/ts-jest with
# a jsdom integration tier; all behavior is exercised in-process.
