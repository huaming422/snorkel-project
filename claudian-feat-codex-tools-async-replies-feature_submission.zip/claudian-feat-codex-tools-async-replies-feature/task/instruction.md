## Task

Our Codex provider is the odd one out in chat right now. When it runs a
script, calls another agent, or does web work, those tool calls come through
as blank or raw fallback cards instead of the readable cards the other
providers get, and when it pauses mid-run to ask a question there's no way to
answer it from the chat.

We want its tool activity rendered as proper cards, and we want to answer its
questions right from the conversation, in the main chat and in a side chat
alike, with the answer reaching the turn that's waiting on it and still being
there when the conversation is reopened later.

Keep this scoped to how chat presents this provider's tool calls and routes
its question replies. The other providers' cards and the chat's normal send
and queue behavior should work exactly as they do now. Everything's already
installed and there's no network, so lean on the existing test suites to check
your work.

## User stories / requirements

- When the provider runs a script, the chat shows a single readable card for it with the script's source and its output together. A script that fails still shows its source and makes the failure visible rather than collapsing to a blank or raw card.
- When the provider messages, continues, lists, or interrupts another agent, each of those calls renders as its own readable card with a human-readable detail of what it did.
- When the provider does a web action that bundles several steps (a search, opening a page, finding within it, clicking, and other kinds too), the chat shows them all in one card with every step listed.
- When the provider pauses mid-run to ask a question, the chat shows that question as its own readable card with the question text visible, rather than dropping it or leaving a blank entry.
- When the provider pauses to ask a question mid-run and you answer it from the chat, your answer goes to the turn that was waiting on it, and after the conversation is reloaded the answered question still shows the answer you gave rather than coming back blank.
- After a saved conversation is reloaded, the provider's tool activity comes back as the same readable cards — a reloaded script shows its source and output, and a reloaded web run shows its operations — instead of raw or empty entries.
- The chat continues to render an ordinary question-and-answer tool card the way it already did — the question and the answer that was given both remain visible.
