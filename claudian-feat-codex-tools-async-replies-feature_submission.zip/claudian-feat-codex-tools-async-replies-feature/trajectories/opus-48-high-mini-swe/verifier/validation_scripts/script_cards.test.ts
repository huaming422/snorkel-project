/** @jest-environment jsdom */
// @ts-nocheck
import { getTestCases } from './validationParams'
import {
  restoreTool, renderStored, renderLive, update, parseSession, toolCallsOf,
} from './jest_test_harness'

describe('script_cards', () => {
  test.each(getTestCases())('case %#', ({ inputs, expected }) => {
    // The implementation maps the native 'exec' custom_tool_call (or function_call)
    // to a 'Script' card. The test case uses tool_name='js' but that does not
    // normalise to Script. We must pass 'exec' with the source in the 'raw' field,
    // which is what getScriptSource reads (source ?? raw ?? value ?? command).
    const tool = restoreTool(
      inputs.mode,
      'exec',
      { raw: inputs.source, title: inputs.title },
      inputs.output,
    )

    // If status_error is "yes", mark the tool as failed before rendering
    if (inputs.status_error === 'yes') {
      tool.status = 'error'
    }

    let block: HTMLElement
    if (inputs.mode === 'live') {
      // renderLive renders with initial=true → shows "Running..."
      // We must call update() to trigger the real expanded content render
      const { block: liveBlock, elements } = renderLive(tool)
      block = liveBlock
      // update triggers the liveContentUpdates callback: sets initial=false,
      // dirty=true, and since the card is expanded, calls renderCurrentContent()
      // which calls renderExpandedContent → renderScriptContent with source+result
      update(tool.id, tool, elements)
    } else {
      block = renderStored(tool)
    }

    const text = block.textContent

    // Assert source is visible on the card
    expect(text).toContain(expected.source_visible)

    // Assert output/error body is visible on the card
    expect(text).toContain(expected.output_visible)
  })
})
