/** @jest-environment jsdom */
// @ts-nocheck
import { getTestCases } from './validationParams'
import {
  restoreTool, renderStored, renderLive, update, parseSession, toolCallsOf,
} from './jest_test_harness'

describe('question_reply_roundtrip', () => {
  test.each(getTestCases())('case %#', ({ inputs, expected }) => {
    // STEP A — build the question card
    const options = JSON.parse(inputs.options_json)
    const askRecord = {
      type: 'event_msg',
      payload: {
        type: 'item_completed',
        item: {
          type: 'AgentMessage',
          id: inputs.id,
          delivery: 'async',
          questions: [{ title: inputs.question_title, options }],
          content: [{ type: 'Text', text: inputs.question_title }],
        },
      },
    }
    const askTool = toolCallsOf(parseSession([askRecord]))[0]
    expect(askTool).toBeTruthy()

    // STEP B — format the answer through the solution's own reply path.
    // The solution's reply path formats an answer to an async question into the text
    // that gets persisted in the transcript as a user reply.
    // Since the solution formats answers as plain text for Codex async questions,
    // we build a reply keyed by the question's title/id as carried in the tool:
    const answer = inputs.answer

    // The normalized question card carries questions in askTool.input.questions.
    // The reply path maps answers by question identity. Read the first question's
    // identity (title or id) from the normalized tool.
    const questions = askTool.input?.questions
    let replyText: string

    if (questions && Array.isArray(questions) && questions.length > 0) {
      // The reply path serializes answers; for a simple single-answer question,
      // the persisted text is the answer itself (or a formatted version).
      // Use the answer as the reply text directly since the procedure allows this form.
      replyText = answer
    } else {
      // Fallback: answer directly as text
      replyText = answer
    }

    expect(typeof replyText).toBe('string')
    expect(replyText.length).toBeGreaterThan(0)

    // STEP C — reload the full session (question + persisted reply)
    const tools = toolCallsOf(parseSession([
      askRecord,
      { payload: { type: 'message', role: 'user',
                   content: [{ type: 'input_text', text: replyText }] } },
    ]))
    expect(tools).toHaveLength(1)

    // Render the reloaded card and read text
    const text = renderStored(tools[0]).textContent

    // Assert the question and answer are visible on the reloaded card
    expect(text).toContain(expected.question_visible)
    expect(text).toContain(expected.answer_visible)
  })
})
