/** @jest-environment jsdom */
// @ts-nocheck
import { getTestCases } from './validationParams'
import {
  restoreTool, renderStored, renderLive, update, parseSession, toolCallsOf,
} from './jest_test_harness'

describe('question_reply_forms', () => {
  test.each(getTestCases())('case %#', ({ inputs, expected }) => {
    // Read the options from the case
    const options = JSON.parse(inputs.options_json)

    // Build the native async-question event record
    const records = [{
      type: 'event_msg',
      payload: {
        type: 'item_completed',
        item: {
          type: 'AgentMessage',
          id: inputs.id,
          delivery: 'async',
          questions: [{ title: inputs.question_title, options }],
          content: [{ type: 'Text', text: inputs.question_title }],
        },
      },
    }]

    // Parse through the real saved-session parser
    const tools = toolCallsOf(parseSession(records))

    // Assert exactly one card produced (not dropped, not split)
    expect(tools).toHaveLength(1)

    // Render the card expanded and read text
    const text = renderStored(tools[0]).textContent

    // Assert the question text is visible on the card
    expect(text).toContain(expected.question_visible)
  })
})
