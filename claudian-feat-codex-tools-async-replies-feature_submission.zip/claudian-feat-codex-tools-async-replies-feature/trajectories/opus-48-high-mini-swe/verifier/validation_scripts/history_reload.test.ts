/** @jest-environment jsdom */
// @ts-nocheck
import { getTestCases } from './validationParams'
import {
  restoreTool, renderStored, renderLive, update, parseSession, toolCallsOf,
} from './jest_test_harness'

describe('history_reload', () => {
  test.each(getTestCases())('case %#', ({ inputs, expected }) => {
    // Parse the input
    const input = JSON.parse(inputs.input_json)

    // The implementation normalises 'js' scripts through the 'exec' pipeline:
    // a function_call named 'exec' with raw source → becomes a Script card.
    // 'web__run' normalises directly to WebSearch.
    // Determine the on-wire name and arguments to use for this tool.
    let wireName = inputs.tool_name
    let wireArgs = JSON.stringify(input)

    if (inputs.tool_name === 'js') {
      // Map the js tool to exec with the source in the 'raw' field so that
      // normalizeCodexToolCall('exec', { raw: source }) → Script card with source.
      const source = typeof input.code === 'string' ? input.code
        : typeof input.source === 'string' ? input.source
        : ''
      wireName = 'exec'
      wireArgs = JSON.stringify({ raw: source })
    }

    // Build a saved session with the call + its result and parse it
    const tools = toolCallsOf(parseSession([
      { payload: { type: 'function_call', call_id: 'c', name: wireName,
                   arguments: wireArgs } },
      { payload: { type: 'function_call_output', call_id: 'c', output: inputs.output } },
    ]))
    expect(tools).toHaveLength(1)

    // Render the rebuilt card and read text
    const text = renderStored(tools[0]).textContent

    // Assert each fragment is visible
    for (const frag of expected.visible) {
      expect(text).toContain(frag)
    }
  })
})
