/** @jest-environment jsdom */
// @ts-nocheck
import { getTestCases } from './validationParams'
import {
  restoreTool, renderStored, renderLive, update, parseSession, toolCallsOf,
} from './jest_test_harness'

describe('no_regression', () => {
  test.each(getTestCases())('case %#', ({ inputs, expected }) => {
    // Parse the inputs
    const input = JSON.parse(inputs.input_json)
    const resolved = JSON.parse(inputs.resolved_json)

    // Build a stored tool for the pre-existing synchronous question tool
    const tool = restoreTool('history', inputs.tool_name, input, '')

    // Attach the resolved answers as the renderer reads them from resolvedAnswers
    tool.resolvedAnswers = resolved

    // Render expanded and read text
    const text = renderStored(tool).textContent

    // Assert question text is visible
    expect(text).toContain(expected.question_visible)

    // Assert answer is visible
    expect(text).toContain(expected.answer_visible)
  })
})
