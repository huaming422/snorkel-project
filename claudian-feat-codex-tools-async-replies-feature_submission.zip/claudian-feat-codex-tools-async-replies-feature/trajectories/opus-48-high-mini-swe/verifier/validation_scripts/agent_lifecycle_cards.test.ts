/** @jest-environment jsdom */
// @ts-nocheck
import { getTestCases } from './validationParams'
import {
  restoreTool, renderStored, renderLive, update, parseSession, toolCallsOf,
} from './jest_test_harness'

describe('agent_lifecycle_cards', () => {
  test.each(getTestCases())('case %#', ({ inputs, expected }) => {
    // Parse the input object
    const input = JSON.parse(inputs.input_json)

    // Restore + render the card
    const tool = restoreTool(inputs.mode, inputs.tool_name, input, inputs.output)
    const text = renderStored(tool).textContent

    // Assert the input-derived detail is visible
    expect(text).toContain(expected.detail_visible)
  })
})
