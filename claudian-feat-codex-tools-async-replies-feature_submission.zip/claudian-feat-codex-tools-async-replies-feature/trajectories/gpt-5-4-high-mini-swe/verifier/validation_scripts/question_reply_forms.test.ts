/** @jest-environment jsdom */
// @ts-nocheck
import { getTestCases } from './validationParams'
import {
  restoreTool, renderStored, renderLive, update, parseSession, toolCallsOf,
} from './jest_test_harness'

describe('question_reply_forms', () => {
  test.each(getTestCases())('case %#', ({ inputs, expected }) => {
    const options = JSON.parse(inputs.options_json)

    // Build the provider's native async-question event record
    const records = [{
      type: 'event_msg',
      payload: {
        type: 'item_completed',
        item: {
          type: 'AgentMessage',
          id: inputs.id,
          delivery: 'async',
          questions: [{ title: inputs.question_title, options }],
          content: [{ type: 'Text', text: inputs.question_title }],
        },
      },
    }]

    const tools = toolCallsOf(parseSession(records))

    // The async question should produce exactly one card
    expect(tools).toHaveLength(1)

    // Render the card expanded and read text
    const text = renderStored(tools[0]).textContent

    // Assert the question text is visible
    expect(text).toContain(expected.question_visible)
  })
})
