/** @jest-environment jsdom */
// @ts-nocheck
import { getTestCases } from './validationParams'
import {
  restoreTool, renderStored, renderLive, update, parseSession, toolCallsOf,
} from './jest_test_harness'

describe('script_cards', () => {
  test.each(getTestCases())('case %#', ({ inputs, expected }) => {
    // Script tools in Codex are rendered under the 'exec' tool name.
    // The source code lives in the 'raw' input field.
    const tool = restoreTool(
      inputs.mode,
      'exec',
      { raw: inputs.source },
      inputs.output,
    )

    // Mark as error if status_error is "yes"
    if (inputs.status_error === 'yes') {
      tool.status = 'error'
    }

    let text: string
    if (inputs.mode === 'live') {
      // For live mode, the initial render shows 'Running...' — we must call
      // update() to advance the card to its completed state before reading text.
      const { block, elements } = renderLive(tool)
      update(tool.id, tool, elements)
      text = block.textContent
    } else {
      text = renderStored(tool).textContent
    }

    // Assert source code is visible
    expect(text).toContain(expected.source_visible)
    // Assert output is visible
    expect(text).toContain(expected.output_visible)
  })
})
