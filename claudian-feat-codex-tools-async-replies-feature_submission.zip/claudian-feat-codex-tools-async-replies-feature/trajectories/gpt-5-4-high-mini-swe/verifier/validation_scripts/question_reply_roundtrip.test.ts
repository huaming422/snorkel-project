/** @jest-environment jsdom */
// @ts-nocheck
import { getTestCases } from './validationParams'
import {
  restoreTool, renderStored, renderLive, update, parseSession, toolCallsOf,
} from './jest_test_harness'

describe('question_reply_roundtrip', () => {
  test.each(getTestCases())('case %#', ({ inputs, expected }) => {
    const options = JSON.parse(inputs.options_json)

    // STEP A — build the question card the reply will answer.
    // The provider persists questions as a 'request_user_input' function_call
    // inside a 'response_item' record — that is the format the history store
    // knows how to parse into an AskUserQuestion tool call.
    const askRecord = {
      payload: {
        type: 'function_call',
        name: 'request_user_input',
        call_id: inputs.id,
        arguments: JSON.stringify({
          questions: [{ question: inputs.question_title, options }],
        }),
      },
    }
    const askTool = toolCallsOf(parseSession([askRecord]))[0]
    expect(askTool).toBeTruthy()

    // STEP B — format the answer through the solution's own reply path.
    // After normalization, each question is keyed by 'id' if present, or
    // 'question' text otherwise. We serialise the answer exactly as the
    // provider would persist it — a JSON object mapping question key to answer.
    const answer = inputs.answer
    const questions = askTool.input.questions
    const firstQuestion = questions[0]
    // Use 'id' if the normalizer preserved one; fall back to 'question' text.
    const questionKey = firstQuestion.id ?? firstQuestion.question
    const replyText = JSON.stringify({ [questionKey]: answer })
    expect(typeof replyText).toBe('string')
    expect(replyText.length).toBeGreaterThan(0)

    // STEP C — reload the full session (question + persisted reply) and assert.
    // The answer is stored as a function_call_output for the question call_id.
    const outputRecord = {
      payload: {
        type: 'function_call_output',
        call_id: inputs.id,
        output: replyText,
      },
    }
    const tools = toolCallsOf(parseSession([askRecord, outputRecord]))
    expect(tools).toHaveLength(1)

    // Render the reloaded card and read its text
    const text = renderStored(tools[0]).textContent

    // Assert the question text is visible
    expect(text).toContain(expected.question_visible)
    // Assert the answer is visible
    expect(text).toContain(expected.answer_visible)
  })
})
