/** @jest-environment jsdom */
// @ts-nocheck
import { getTestCases } from './validationParams'
import {
  restoreTool, renderStored, renderLive, update, parseSession, toolCallsOf,
} from './jest_test_harness'

describe('agent_lifecycle_cards', () => {
  test.each(getTestCases())('case %#', ({ inputs, expected }) => {
    const input = JSON.parse(inputs.input_json)

    const tool = restoreTool(inputs.mode, inputs.tool_name, input, inputs.output)
    const text = renderStored(tool).textContent

    // Assert that the input-derived detail is visible
    expect(text).toContain(expected.detail_visible)
  })
})
