/** @jest-environment jsdom */
// @ts-nocheck
import { getTestCases } from './validationParams'
import {
  restoreTool, renderStored, renderLive, update, parseSession, toolCallsOf,
} from './jest_test_harness'

describe('history_reload', () => {
  test.each(getTestCases())('case %#', ({ inputs, expected }) => {
    const input = JSON.parse(inputs.input_json)

    // Build a saved session with the call + its result and parse it
    const tools = toolCallsOf(parseSession([
      { payload: { type: 'function_call', call_id: 'c', name: inputs.tool_name,
                   arguments: JSON.stringify(input) } },
      { payload: { type: 'function_call_output', call_id: 'c', output: inputs.output } },
    ]))
    expect(tools).toHaveLength(1)

    // Render the rebuilt card and read text
    const text = renderStored(tools[0]).textContent

    // Assert every fragment is visible
    for (const frag of expected.visible) {
      expect(text).toContain(frag)
    }
  })
})
