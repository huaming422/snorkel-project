/** @jest-environment jsdom */
// @ts-nocheck
import { getTestCases } from './validationParams'
import {
  restoreTool, renderStored, renderLive, update, parseSession, toolCallsOf,
} from './jest_test_harness'

describe('no_regression', () => {
  test.each(getTestCases())('case %#', ({ inputs, expected }) => {
    const input = JSON.parse(inputs.input_json)
    const resolved = JSON.parse(inputs.resolved_json)

    // Build a stored tool for the pre-existing synchronous question tool
    const tool = restoreTool('history', inputs.tool_name, input, '')
    // Attach the resolved answers the way the tool object carries answers
    tool.resolvedAnswers = resolved

    // Render expanded and read text
    const text = renderStored(tool).textContent

    // Assert question is visible
    expect(text).toContain(expected.question_visible)
    // Assert answer is visible
    expect(text).toContain(expected.answer_visible)
  })
})
