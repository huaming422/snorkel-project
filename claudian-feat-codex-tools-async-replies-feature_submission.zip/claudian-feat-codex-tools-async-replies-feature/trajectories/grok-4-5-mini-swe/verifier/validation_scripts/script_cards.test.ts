/** @jest-environment jsdom */
// @ts-nocheck
import { getTestCases } from './validationParams'
import {
  restoreTool, renderStored, renderLive, update, parseSession, toolCallsOf,
} from './jest_test_harness'

describe('script_cards', () => {
  test.each(getTestCases())('case %#', ({ inputs, expected }) => {
    // Build the script tool using the native tool name.
    // The procedure specifies `code` as the input field; the exec normalizer reads
    // firstNonEmptyString(input.source, input.raw, input.value, input.script, input.code).
    const tool = restoreTool(
      inputs.mode,
      inputs.tool_name,
      { code: inputs.source, title: inputs.title },
      inputs.output,
    )

    // If status_error is "yes", mark the tool as a failed run.
    if (inputs.status_error === 'yes') {
      tool.status = 'error'
    }

    // Render the card and read its text.
    // For live cards, renderLive renders with "Running..." (initial=true); call
    // update() to advance past the initial state and show the actual content.
    let block: HTMLElement
    if (inputs.mode === 'live') {
      const { block: liveBlock, elements } = renderLive(tool)
      update(tool.id, tool, elements)
      block = liveBlock
    } else {
      block = renderStored(tool)
    }
    const text = block.textContent

    // The script's own source is shown on the card.
    expect(text).toContain(expected.source_visible)

    // The run's output/error body is shown.
    expect(text).toContain(expected.output_visible)
  })
})
