/** @jest-environment jsdom */
// @ts-nocheck
import { getTestCases } from './validationParams'
import {
  restoreTool, renderStored, renderLive, update, parseSession, toolCallsOf,
} from './jest_test_harness'

describe('agent_lifecycle_cards', () => {
  test.each(getTestCases())('case %#', ({ inputs, expected }) => {
    // Parse the case input object.
    const input = JSON.parse(inputs.input_json)

    // Restore + render the card and read text.
    const tool = restoreTool(inputs.mode, inputs.tool_name, input, inputs.output)
    const text = renderStored(tool).textContent

    // An input-derived human detail (agent path or message text) must be visible.
    // On a raw fallback card this input detail is absent.
    expect(text).toContain(expected.detail_visible)
  })
})
