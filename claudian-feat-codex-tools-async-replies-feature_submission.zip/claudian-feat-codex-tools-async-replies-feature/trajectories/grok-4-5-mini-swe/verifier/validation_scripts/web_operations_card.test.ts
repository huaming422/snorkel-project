/** @jest-environment jsdom */
// @ts-nocheck
import { getTestCases } from './validationParams'
import {
  restoreTool, renderStored, renderLive, update, parseSession, toolCallsOf,
} from './jest_test_harness'

describe('web_operations_card', () => {
  test.each(getTestCases())('case %#', ({ inputs, expected }) => {
    // Parse the input.
    const input = JSON.parse(inputs.input_json)

    // Confirm it is ONE card (no duplicate / split cards): build a single-call
    // history session and assert exactly one tool card is produced.
    const tools = toolCallsOf(parseSession([
      { payload: { type: 'function_call', call_id: 'w', name: inputs.tool_name,
                   arguments: JSON.stringify(input) } },
      { payload: { type: 'function_call_output', call_id: 'w', output: inputs.output } },
    ]))
    expect(tools).toHaveLength(1)

    // Render and read text.
    const text = renderStored(tools[0]).textContent

    // Every listed operation step must appear.
    for (const frag of expected.operations_visible) {
      expect(text).toContain(frag)
    }
  })
})
