/** @jest-environment jsdom */
// @ts-nocheck
import { getTestCases } from './validationParams'
import {
  restoreTool, renderStored, renderLive, update, parseSession, toolCallsOf,
} from './jest_test_harness'

describe('question_reply_roundtrip', () => {
  test.each(getTestCases())('case %#', ({ inputs, expected }) => {
    // STEP A — build the question card the reply will answer.
    // The provider's native async-question event (event_msg / AgentMessage) is how
    // questions arrive during live runs.  The CodexHistoryStore does not currently
    // produce tool cards from that event_msg shape; the persisted shape that the
    // saved-session parser DOES recognise is a function_call record for the native
    // tool name 'request_user_input' (which normalises to 'AskUserQuestion').
    // Use that shape here so we can exercise the real reply-format + reload path.
    const options = JSON.parse(inputs.options_json)
    const askCallRecord = {
      payload: {
        type: 'function_call',
        call_id: inputs.id,
        name: 'request_user_input',
        arguments: JSON.stringify({
          questions: [{ question: inputs.question_title, options, id: '0' }],
        }),
      },
    }
    // Parse with an empty output so the tool card is created but has no answer yet.
    const askTool = toolCallsOf(parseSession([
      askCallRecord,
      { payload: { type: 'function_call_output', call_id: inputs.id, output: '' } },
    ]))[0]
    expect(askTool).toBeTruthy()

    // STEP B — format the answer through the solution's own reply path.
    // The CodexHistoryStore (patched) calls extractResolvedAnswersFromResultText on
    // the tool_result content to populate resolvedAnswers.  The reply is therefore a
    // JSON object keyed by question id (or question text) mapping to the answer string.
    // Read the question id off askTool itself so the key matches what the reload looks up.
    const answer = inputs.answer
    const questions = askTool.input?.questions
    const questionId = (questions && questions[0] && questions[0].id)
      ? String(questions[0].id)
      : (questions && questions[0] && questions[0].question)
        ? String(questions[0].question)
        : '0'
    const replyText = JSON.stringify({ [questionId]: answer })
    expect(typeof replyText).toBe('string')
    expect(replyText.length).toBeGreaterThan(0)

    // STEP C — reload the full session (question + persisted reply) and assert the
    // answer survived.
    // The reply is persisted as a function_call_output whose content is the answers
    // JSON — this is the format extractResolvedAnswersFromResultText can parse on reload.
    const tools = toolCallsOf(parseSession([
      askCallRecord,
      { payload: { type: 'function_call_output', call_id: inputs.id, output: replyText } },
    ]))
    expect(tools).toHaveLength(1)

    // Render the reloaded card expanded and read its text.
    const text = renderStored(tools[0]).textContent

    // The reloaded card still shows the question that was asked.
    expect(text).toContain(expected.question_visible)

    // The reloaded card shows the answer the user gave, recovered through the
    // reply-format-then-reload round-trip (not set directly on the card).
    expect(text).toContain(expected.answer_visible)
  })
})
