/** @jest-environment jsdom */
// @ts-nocheck
import { getTestCases } from './validationParams'
import {
  restoreTool, renderStored, renderLive, update, parseSession, toolCallsOf,
} from './jest_test_harness'

describe('question_reply_forms', () => {
  test.each(getTestCases())('case %#', ({ inputs, expected }) => {
    // Read the question text and option labels from the case.
    const options = JSON.parse(inputs.options_json)

    // Build the provider's native async-question event record and parse the saved
    // session through the real parser, then collect the tool cards.
    const records = [{
      type: 'event_msg',
      payload: {
        type: 'item_completed',
        item: {
          type: 'AgentMessage',
          id: inputs.id,
          delivery: 'async',
          questions: [{ title: inputs.question_title, options }],
          content: [{ type: 'Text', text: inputs.question_title }],
        },
      },
    }]
    const tools = toolCallsOf(parseSession(records))

    // Assert the async question produced exactly ONE card (not dropped, not split).
    expect(tools).toHaveLength(1)

    // Render the rebuilt card expanded and read its text.
    const text = renderStored(tools[0]).textContent

    // The question's own text is shown on the card.
    expect(text).toContain(expected.question_visible)
  })
})
