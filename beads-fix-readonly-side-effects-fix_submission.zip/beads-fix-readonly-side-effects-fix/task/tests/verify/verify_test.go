//go:build cgo

package main

// These checks drive the compiled bd binary as a black box through its public
// surface only: the persistent --readonly flag, the classified read command
// `list`, and the non-classified command `config validate`. They never set an
// internal store-config field and never read program source, so any lifecycle
// wiring that routes a mutation-free invocation away from the write-capable
// lifecycle — regardless of how that signal is named or plumbed — satisfies
// them. The shared subprocess helpers (buildEmbeddedBD, bdInit, bdCreate,
// bdEnv, bdCommand) and the package TestMain come from the package's existing
// //go:build cgo test files, which the runner compiles alongside this file.
//
// Two of the checks observe the gitignored version-bookkeeping marker that the
// tool maintains directly under the project state directory. On the current
// binary that marker is refreshed during the ordinary, write-capable command
// lifecycle whenever the stored value differs from the running build; seeding an
// older value makes that refresh observable. A mutation-free invocation must
// suppress the whole write-capable lifecycle (marker untouched); an ordinary
// classified read must keep it (marker refreshed). The marker lives beside the
// data, so the engine's own internal files never enter these assertions.
//
// A third check reproduces the reported symptom end to end: when the project is
// configured to talk to a managed database server, the managed-server open path
// sweeps stale leftover housekeeping state out of a shared scratch area before it
// does anything else. That sweep is a destructive side effect, and it is exactly
// what the reporter observed a mutation-free audit performing. The check plants a
// uniquely-named stale leftover entry in that shared scratch area, drives a
// mutation-free read against a server-configured project, and asserts the planted
// entry survives. A mutation-free invocation must not reach the sweep (entry
// survives); the pre-fix binary runs it unconditionally (entry deleted). The
// invocation is expected to fail afterwards because no server is actually running
// — the sweep happens before the connection attempt, so the symptom is observable
// without standing up a server, and the check never asserts on the exit status.

import (
	"bytes"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"io/fs"
	"os"
	"os/exec"
	"path/filepath"
	"reflect"
	"testing"
	"time"
)

// embeddedDataDirName is the on-disk subdirectory the embedded backend creates
// under the project state directory to hold its data. The tree snapshot prunes
// it so that opening the store to read — which both the baseline and the fixed
// binary do — cannot by itself register as a difference. This is a stable
// repository layout fact, not a solution choice.
const embeddedDataDirName = "embeddeddolt"

// versionMarkerName is the gitignored file the tool rewrites during its normal,
// write-capable command lifecycle when the stored build value is stale. It is a
// pre-existing bookkeeping file written at init time, not a solution choice.
const versionMarkerName = ".local_version"

// staleMarker is a build value guaranteed to differ from any real build, so the
// normal lifecycle has a concrete rewrite to perform. Harness-owned fixture.
const staleMarker = "0.0.1"

// requireEmbeddedEnabled skips when the offline embedded backend is not enabled
// for this run. The image sets it; a bare `go test` without it would skip.
func requireEmbeddedEnabled(t *testing.T) {
	t.Helper()
	if os.Getenv("BEADS_TEST_EMBEDDED_DOLT") != "1" {
		t.Skip("set BEADS_TEST_EMBEDDED_DOLT=1 to run the embedded read-only checks")
	}
}

// runBDRaw runs the bd binary in dir with the given args and returns stdout+stderr
// combined and the process error (nil on exit 0). Unlike bdCommand it never
// fatals, so callers can assert on both success and refusal.
func runBDRaw(t *testing.T, bd, dir string, args ...string) (string, error) {
	t.Helper()
	cmd := exec.Command(bd, args...)
	cmd.Dir = dir
	cmd.Env = bdEnv(dir)
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	err := cmd.Run()
	return stdout.String() + stderr.String(), err
}

// treeEntry captures mode plus a content fingerprint for one path.
type treeEntry struct {
	Mode   fs.FileMode
	SHA256 string
}

// snapshotTree walks root and fingerprints every entry (mode for all, content
// hash for regular files, link target hash for symlinks), skipping the embedded
// engine's own data subtree. Two snapshots compare equal only when the managed
// bookkeeping around the data is byte-for-byte identical.
//
// The engine subtree is pruned on purpose. Opening the versioned store — even
// purely to read — lets its engine touch its own internal lock/manifest files,
// and the invocation under test opens that store (read-only) just like the
// baseline opens it (writable). Comparing the engine's private files would
// therefore flag the open itself rather than the lifecycle writes this check is
// about (version bookkeeping, server/port artifacts, post-run maintenance),
// which all land directly under root.
func snapshotTree(t *testing.T, root string) map[string]treeEntry {
	t.Helper()
	out := make(map[string]treeEntry)
	if _, err := os.Lstat(root); os.IsNotExist(err) {
		return out
	} else if err != nil {
		t.Fatalf("stat snapshot root %s: %v", root, err)
	}
	err := filepath.WalkDir(root, func(path string, entryInfo fs.DirEntry, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		rel, err := filepath.Rel(root, path)
		if err != nil {
			return err
		}
		if entryInfo.IsDir() && rel == embeddedDataDirName {
			return filepath.SkipDir
		}
		info, err := os.Lstat(path)
		if err != nil {
			return err
		}
		entry := treeEntry{Mode: info.Mode()}
		switch {
		case info.Mode().IsRegular():
			data, err := os.ReadFile(path)
			if err != nil {
				return err
			}
			entry.SHA256 = fmt.Sprintf("%x", sha256.Sum256(data))
		case info.Mode()&os.ModeSymlink != 0:
			target, err := os.Readlink(path)
			if err != nil {
				return err
			}
			entry.SHA256 = fmt.Sprintf("%x", sha256.Sum256([]byte(target)))
		}
		out[rel] = entry
		return nil
	})
	if err != nil {
		t.Fatalf("snapshot %s: %v", root, err)
	}
	return out
}

// seedStaleMarker plants an older build value in the version-bookkeeping file so
// the normal, write-capable lifecycle has a concrete rewrite to perform. init
// writes the current value, so without this the lifecycle has nothing to do.
func seedStaleMarker(t *testing.T, beadsDir string) string {
	t.Helper()
	markerPath := filepath.Join(beadsDir, versionMarkerName)
	if err := os.WriteFile(markerPath, []byte(staleMarker+"\n"), 0o600); err != nil {
		t.Fatalf("seed version marker: %v", err)
	}
	return markerPath
}

// readMarker returns the trimmed contents of the version-bookkeeping file.
func readMarker(t *testing.T, path string) string {
	t.Helper()
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read version marker: %v", err)
	}
	return string(bytes.TrimSpace(data))
}

// TestStrictReadOnlyLeavesManagedStateUntouched is the headline guarantee: a
// mutation-free invocation (the --readonly flag) against a fully seeded location
// leaves the managed state byte-for-byte identical. It seeds a project, plants an
// older value in the version-bookkeeping file so the normal lifecycle has a
// concrete mutation to make, snapshots the project state directory, runs a read
// under --readonly, and re-snapshots. The pre-fix binary runs the normal
// write-capable lifecycle and rewrites the bookkeeping file (diff); the corrected
// binary suppresses that lifecycle (identical).
func TestStrictReadOnlyLeavesManagedStateUntouched(t *testing.T) {
	requireEmbeddedEnabled(t)
	t.Parallel()

	bd := buildEmbeddedBD(t)
	dir, beadsDir, _ := bdInit(t, bd, "--prefix", "hm")
	bdCreate(t, bd, dir, "Seed issue")

	markerPath := seedStaleMarker(t, beadsDir)
	before := snapshotTree(t, beadsDir)

	out, err := runBDRaw(t, bd, dir, "list", "--readonly")
	if err != nil {
		t.Fatalf("mutation-free read of a seeded location should succeed, got error: %v\noutput:\n%s", err, out)
	}

	after := snapshotTree(t, beadsDir)
	if !reflect.DeepEqual(after, before) {
		t.Fatalf("mutation-free read changed managed state\nbefore: %#v\nafter:  %#v\noutput: %s", before, after, out)
	}
	if got := readMarker(t, markerPath); got != staleMarker {
		t.Fatalf("mutation-free read rewrote the version-bookkeeping marker: got %q, want %q", got, staleMarker)
	}
}

// TestClassifiedReadKeepsNormalMaintenance guards against an over-broad fix. An
// ordinary classified read (no --readonly flag) against the same seeded location
// must still succeed AND keep running its normal, write-capable lifecycle — here
// observed as the refresh of the stale version-bookkeeping marker. That is how
// list/show keep behaving exactly as they do today. A fix that suppresses the
// maintenance lifecycle for every read-only open (not just the strict one), or
// that makes ordinary reads refuse, breaks this and is rejected here. Both the
// pre-fix baseline and the correct fix pass.
func TestClassifiedReadKeepsNormalMaintenance(t *testing.T) {
	requireEmbeddedEnabled(t)
	t.Parallel()

	bd := buildEmbeddedBD(t)
	dir, beadsDir, _ := bdInit(t, bd, "--prefix", "cr")
	bdCreate(t, bd, dir, "Seed issue")

	markerPath := seedStaleMarker(t, beadsDir)

	out, err := runBDRaw(t, bd, dir, "list")
	if err != nil {
		t.Fatalf("classified read of a seeded location should succeed, got error: %v\noutput:\n%s", err, out)
	}
	if got := readMarker(t, markerPath); got == staleMarker {
		t.Fatalf("classified read did not run its normal version-bookkeeping refresh; marker still %q", got)
	}
}

// sharedHousekeepingDir is the process-global scratch directory the managed-server
// open path sweeps for stale leftover housekeeping entries. It is a stable
// repository layout fact (a fixed path the tool has always used), not a solution
// choice: the check plants a uniquely-named entry here and only ever inspects that
// one entry, so it neither depends on nor disturbs anything else under the path.
const sharedHousekeepingDir = "/tmp/beads-circuit"

// switchToManagedServerMode rewrites the freshly-initialized project metadata so
// the next invocation routes through the managed-server open path (where the
// destructive leftover-state sweep lives) instead of the embedded open. It flips
// the single stored mode field from the embedded default to the server value and
// is a fixture step, not an assertion about the fix.
func switchToManagedServerMode(t *testing.T, beadsDir string) {
	t.Helper()
	metaPath := filepath.Join(beadsDir, "metadata.json")
	data, err := os.ReadFile(metaPath)
	if err != nil {
		t.Fatalf("read project metadata: %v", err)
	}
	var meta map[string]any
	if err := json.Unmarshal(data, &meta); err != nil {
		t.Fatalf("parse project metadata: %v", err)
	}
	if got, _ := meta["dolt_mode"].(string); got != "embedded" {
		t.Fatalf("expected freshly-initialized project to default to embedded mode, got %q", got)
	}
	meta["dolt_mode"] = "server"
	out, err := json.MarshalIndent(meta, "", "  ")
	if err != nil {
		t.Fatalf("re-encode project metadata: %v", err)
	}
	if err := os.WriteFile(metaPath, out, 0o600); err != nil {
		t.Fatalf("write project metadata: %v", err)
	}
}

// plantStaleLeftover writes a uniquely-named leftover housekeeping entry into the
// shared scratch directory, aged well past the staleness horizon so the
// managed-server open path's sweep treats it as collectable. The unique name
// isolates this check from any other entry in the shared directory (including
// concurrent runs and host leftovers): the check asserts only on this file. The
// recorded shape mirrors a tripped-then-abandoned leftover — the kind of stale
// state the reporter watched a mutation-free audit delete.
func plantStaleLeftover(t *testing.T, name string) string {
	t.Helper()
	if err := os.MkdirAll(sharedHousekeepingDir, 0o755); err != nil {
		t.Fatalf("prepare shared scratch dir: %v", err)
	}
	aged := time.Now().Add(-1 * time.Hour).UTC().Format(time.RFC3339)
	// Minimal record the sweep classifies as a stale, collectable leftover.
	body := fmt.Sprintf(`{"state":"open","tripped_at":%q,"last_failure":%q}`, aged, aged)
	path := filepath.Join(sharedHousekeepingDir, name)
	if err := os.WriteFile(path, []byte(body), 0o600); err != nil {
		t.Fatalf("plant stale leftover: %v", err)
	}
	return path
}

// TestMutationFreeAuditLeavesLeftoverHousekeepingUntouched reproduces the reported
// symptom directly: a mutation-free audit (the --readonly flag) against a
// server-configured project was observed deleting stale leftover housekeeping
// state it should only have been inspecting. The managed-server open path runs
// that destructive sweep before it ever contacts a server, so the deletion is
// observable here without one running; the invocation is expected to fail
// afterwards (no server is up) and the check deliberately ignores the exit status.
//
// The check seeds a project, switches it to managed-server mode, plants a
// uniquely-named stale leftover in the shared scratch directory, runs a read under
// --readonly, and asserts the planted leftover still exists. The pre-fix binary
// runs the sweep unconditionally and deletes it; a fix that makes a mutation-free
// invocation genuinely side-effect-free never reaches the sweep and leaves it in
// place. This is the one write side effect the reported symptom names, and it is
// invisible to the version-bookkeeping checks above.
func TestMutationFreeAuditLeavesLeftoverHousekeepingUntouched(t *testing.T) {
	requireEmbeddedEnabled(t)
	t.Parallel()

	bd := buildEmbeddedBD(t)
	dir, beadsDir, _ := bdInit(t, bd, "--prefix", "cb")
	bdCreate(t, bd, dir, "Seed issue")
	switchToManagedServerMode(t, beadsDir)

	// Name is unique per run (pid-based) so the shared scratch directory cannot
	// collide with any other entry, test, or stale host leftover. The host/port/
	// database fields embedded in the name do not correspond to this project, so
	// only the unconditional sweep — never a targeted write for this project — can
	// remove it.
	leftover := fmt.Sprintf("beads-dolt-circuit-vfy%d-59999-vfydb.json", os.Getpid())
	path := plantStaleLeftover(t, leftover)
	t.Cleanup(func() { _ = os.Remove(path) })

	// Exit status is intentionally ignored: with no server running the read fails,
	// but the destructive sweep (if reached) already ran before the dial.
	out, _ := runBDRaw(t, bd, dir, "list", "--readonly")

	if _, err := os.Stat(path); err != nil {
		t.Fatalf("mutation-free audit deleted stale leftover housekeeping state it should only have inspected (%s): %v\noutput:\n%s", path, err, out)
	}
}

// exportArtifactNames are the files the post-run auto-export maintenance step
// writes directly under the project state directory when it runs: the portable
// JSONL snapshot and the throttle-state bookkeeping beside it. They are
// pre-existing output names of the maintenance lifecycle, not solution choices.
var exportArtifactNames = []string{"issues.jsonl", "export-state.json"}

// enableAutoExport turns on the post-run auto-export maintenance step and
// records a remote so the maintenance-bearing command the test drives runs to
// completion instead of refusing early. Both are written through the public
// config surface, and both are maintenance-enabling fixture steps, not
// assertions about the fix. A remote of this file:// shape is accepted by the
// tool's own remote-URL validation.
func enableAutoExport(t *testing.T, bd, dir string) {
	t.Helper()
	bdCommand(t, bd, dir, "config", "set", "export.auto", "true")
	bdCommand(t, bd, dir, "config", "set", "federation.remote", "file:///tmp/beads-vfy-remote")
}

// clearExportThrottle removes the auto-export output and throttle-state files so
// the next run is neither throttled nor change-detected into a no-op. A fresh
// run with these absent re-exports if (and only if) it reaches the maintenance
// lifecycle at all.
func clearExportThrottle(t *testing.T, beadsDir string) {
	t.Helper()
	for _, name := range exportArtifactNames {
		if err := os.Remove(filepath.Join(beadsDir, name)); err != nil && !os.IsNotExist(err) {
			t.Fatalf("clear export artifact %s: %v", name, err)
		}
	}
}

// TestMutationFreeNonClassifiedCommandSkipsPostRunMaintenance closes the leak a
// version-and-circuit-only fix leaves open: a mutation-free invocation of a
// command that is NOT a classified read must still run none of the post-run
// maintenance a normal command does. The two version-bookkeeping checks above
// only ever drive `list`, a classified read, whose post-run export/push are
// already suppressed by command classification regardless of any fix — so a
// partial fix that gates only the version marker and the circuit sweep passes
// them while a non-classified command under the mutation-free flag still writes
// inside the project state directory.
//
// `config validate` is such a command: it opens the store and reaches the
// post-run maintenance block, but it is not on the classified-read list, so on
// the pre-fix binary the auto-export maintenance step writes the portable JSONL
// snapshot and its throttle-state file directly under the project state
// directory. The check seeds a project with one issue, enables auto-export and
// records a remote so the command runs to completion, clears any throttle state,
// snapshots the project state tree, runs `config validate` under the
// mutation-free flag, and asserts the tree is byte-for-byte identical and no
// export artifact appeared. A mutation-free invocation that genuinely suppresses
// the whole post-run maintenance lifecycle leaves the tree untouched; the pre-fix
// binary and any fix that gates only the marker/circuit paths write the export
// artifacts and fail. Exit status is ignored: the assertion is purely on-disk
// state, and the command's own success does not matter to the leak.
func TestMutationFreeNonClassifiedCommandSkipsPostRunMaintenance(t *testing.T) {
	requireEmbeddedEnabled(t)
	t.Parallel()

	bd := buildEmbeddedBD(t)
	dir, beadsDir, _ := bdInit(t, bd, "--prefix", "pm")
	bdCreate(t, bd, dir, "Seed issue")

	enableAutoExport(t, bd, dir)
	clearExportThrottle(t, beadsDir)

	before := snapshotTree(t, beadsDir)

	// `config validate` is not a classified read, so the post-run maintenance
	// block is reachable. Exit status is intentionally ignored.
	out, _ := runBDRaw(t, bd, dir, "config", "validate", "--readonly")

	after := snapshotTree(t, beadsDir)
	if !reflect.DeepEqual(after, before) {
		t.Fatalf("mutation-free run of a non-classified command performed post-run maintenance writes\nbefore: %#v\nafter:  %#v\noutput: %s", before, after, out)
	}
	for _, name := range exportArtifactNames {
		if _, err := os.Stat(filepath.Join(beadsDir, name)); err == nil {
			t.Fatalf("mutation-free run of a non-classified command performed post-run maintenance: %s was written\noutput:\n%s", name, out)
		}
	}
}
