#!/usr/bin/env bash
# The image bakes the full dependency closure at the base commit (Go module +
# build caches warm, CGO_ENABLED=1, -tags gms_pure_go), so the offline-first Go
# verifiers compile and run with no network and nothing to install here.
#
# The two primary store-factory verifiers run fully offline against the embedded
# backend (they drive the embedded dolt store through the in-package factory).
# The end-to-end hermeticity canary needs a running dolt sql-server; it is
# SKIP-guarded when one is not reachable, so no server is started here. If a
# future reward revision wants that canary live, start the server in this script
# (it runs with network) and export BEADS_DOLT_PORT for the verifier.
set -euo pipefail
echo "[test-setup] no-op for beads-fix-readonly-side-effects (deps baked into image)"
