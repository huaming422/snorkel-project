## Task

running beads in read-only mode is broken: it isn't actually read-only. a read-only invocation was seen changing things on disk in the project's managed state, which is wrong. in one case a read-only audit quietly deleted some stale leftover state it should only have been inspecting.

read-only should mean read-only: an invocation that's only meant to look at things should leave the .beads directory exactly as it found it. track down why a read-only run still writes, and fix it.

ordinary read commands (listing, showing, and the like) should keep behaving exactly as they do today, including how they manage the local database; this isn't about making them start erroring.
