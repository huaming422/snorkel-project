## Task

Since the last release, tool calls to a lot of MCP servers on `2025-11-25` fail before the caller sees anything, with `INVALID_RESULT` (`-32602`). Those servers haven't changed, and the release before this one handled them fine.

People building servers on this SDK are running into it from their end too. Tools that used to work now fail with `-32602` when they're called.

Callers should get those results back again with nothing the server sent missing, and those tools should work again. Just don't let a response that's really something else, like a task result, slip through as a successful tool call, whatever else is on it. Everything else should behave exactly as it does now.
