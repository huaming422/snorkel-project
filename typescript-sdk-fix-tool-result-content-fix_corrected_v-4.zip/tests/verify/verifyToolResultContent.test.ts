// @ts-nocheck
//
// Inbound tools/call results on the client request path. Each case drives
// Protocol.request over an in-memory transport whose peer answers with a fixed
// raw result body, with the era set through setNegotiatedProtocolVersion the
// way the repo's own wire tests do. Only the resolved value or the rejection is
// asserted.

import { describe, expect, it } from 'vitest';

import { SdkError, SdkErrorCode } from '../../src/errors/sdkErrors';
import type { BaseContext } from '../../src/shared/protocol';
import { Protocol, setNegotiatedProtocolVersion } from '../../src/shared/protocol';
import type { JSONRPCRequest } from '../../src/types/index';
import { isCallToolResult } from '../../src/types/index';
import { InMemoryTransport } from '../../src/util/inMemory';

class TestProtocol extends Protocol<BaseContext> {
    protected assertCapabilityForMethod(): void {}
    protected assertNotificationCapability(): void {}
    protected assertRequestHandlerCapability(): void {}
    protected buildContext(ctx: BaseContext): BaseContext {
        return ctx;
    }
}

// Client-side protocol whose peer answers every request with `rawResult`.
async function connectWithPeerResult(rawResult: unknown, era?: '2025-11-25' | '2026-07-28'): Promise<TestProtocol> {
    const [clientTx, serverTx] = InMemoryTransport.createLinkedPair();
    serverTx.onmessage = message => {
        const request = message as JSONRPCRequest;
        void serverTx.send({ jsonrpc: '2.0', id: request.id, result: rawResult } as Parameters<typeof serverTx.send>[0]);
    };
    await serverTx.start();
    const protocol = new TestProtocol();
    await protocol.connect(clientTx);
    if (era !== undefined) setNegotiatedProtocolVersion(protocol, era);
    return protocol;
}

type Outcome = { resolved: Record<string, unknown> } | { rejected: unknown };

async function callTool(rawResult: unknown, era?: '2025-11-25' | '2026-07-28'): Promise<Outcome> {
    const protocol = await connectWithPeerResult(rawResult, era);
    try {
        return await protocol.request({ method: 'tools/call', params: { name: 'echo', arguments: {} } }).then(
            result => ({ resolved: result as Record<string, unknown> }),
            error => ({ rejected: error as unknown })
        );
    } finally {
        await protocol.close();
    }
}

// Task and input-required bodies without content.
const FOREIGN_FAMILY_BODIES: Array<[string, Record<string, unknown>]> = [
    ['task', { task: { taskId: 't-1', status: 'working' } }],
    ['inputRequests', { inputRequests: { r1: { method: 'elicitation/create' } } }],
    ['requestState', { requestState: 'opaque-token' }]
];

// The same bodies alongside structuredContent, still without content.
const FOREIGN_FAMILY_WITH_STRUCTURED: Array<[string, Record<string, unknown>]> = [
    ['task + structuredContent', { task: { taskId: 't-1', status: 'working' }, structuredContent: { ok: true } }],
    ['inputRequests + structuredContent', { inputRequests: { r1: { method: 'elicitation/create' } }, structuredContent: { ok: true } }],
    ['requestState + structuredContent', { requestState: 'opaque-token', structuredContent: { ok: true } }]
];

describe('typescript-sdk-fix-tool-result-content :: inbound client tool-result handling', () => {
    it('[legacy_plain_tolerance] a 2025 structured-only tool result is delivered with a content array', async () => {
        const outcome = await callTool({ structuredContent: { ok: true } }, '2025-11-25');
        expect('resolved' in outcome, `expected delivery, got ${JSON.stringify(outcome)}`).toBe(true);
        const result = (outcome as { resolved: Record<string, unknown> }).resolved;
        expect(Array.isArray(result.content), `content must be an array, got ${JSON.stringify(result.content)}`).toBe(true);
        expect(result.structuredContent).toEqual({ ok: true });
    });

    it('[legacy_plain_tolerance] a 2025 result that carries content is delivered unchanged', async () => {
        const outcome = await callTool({ content: [{ type: 'text', text: 'hi' }], structuredContent: { ok: true } }, '2025-11-25');
        expect('resolved' in outcome, `expected delivery, got ${JSON.stringify(outcome)}`).toBe(true);
        const result = (outcome as { resolved: Record<string, unknown> }).resolved;
        expect(result.content).toEqual([{ type: 'text', text: 'hi' }]);
        expect(result.structuredContent).toEqual({ ok: true });
    });

    it('[foreign_family_rejected] task and input-required bodies without content are rejected as InvalidResult', async () => {
        for (const [label, body] of FOREIGN_FAMILY_BODIES) {
            const outcome = await callTool(body, '2025-11-25');
            expect('rejected' in outcome, `must reject ${label}, got ${JSON.stringify(outcome)}`).toBe(true);
            expect((outcome as { rejected: unknown }).rejected).toBeInstanceOf(SdkError);
            expect(((outcome as { rejected: SdkError }).rejected).code, `must reject ${label} as InvalidResult`).toBe(
                SdkErrorCode.InvalidResult
            );
        }
    });

    it('[foreign_family_rejected] task and input-required bodies that also carry structuredContent are rejected as InvalidResult', async () => {
        for (const [label, body] of FOREIGN_FAMILY_WITH_STRUCTURED) {
            const outcome = await callTool(body, '2025-11-25');
            expect('rejected' in outcome, `must reject ${label}, got ${JSON.stringify(outcome)}`).toBe(true);
            expect((outcome as { rejected: unknown }).rejected).toBeInstanceOf(SdkError);
            expect(((outcome as { rejected: SdkError }).rejected).code, `must reject ${label} as InvalidResult`).toBe(
                SdkErrorCode.InvalidResult
            );
        }
    });

    it('[foreign_family_rejected] a structured-only result is delivered while a task body is rejected', async () => {
        const plain = await callTool({ structuredContent: { ok: true } }, '2025-11-25');
        expect('resolved' in plain, `plain body must be delivered, got ${JSON.stringify(plain)}`).toBe(true);
        expect(Array.isArray((plain as { resolved: Record<string, unknown> }).resolved.content)).toBe(true);

        const foreign = await callTool({ task: { taskId: 't-1', status: 'working' } }, '2025-11-25');
        expect('rejected' in foreign, `foreign body must be rejected, got ${JSON.stringify(foreign)}`).toBe(true);
    });

    it('[foreign_family_rejected] a task body with an explicit content: undefined is rejected', async () => {
        const outcome = await callTool({ task: { taskId: 't-1', status: 'working' }, content: undefined }, '2025-11-25');
        expect('rejected' in outcome, `must reject foreign body with content: undefined, got ${JSON.stringify(outcome)}`).toBe(true);
        expect((outcome as { rejected: unknown }).rejected).toBeInstanceOf(SdkError);
    });

    it('[modern_era_strict] a 2026-07-28 client rejects a structured-only result and delivers the same result with content', async () => {
        const withContent = await callTool({ resultType: 'complete', content: [], structuredContent: { ok: true } }, '2026-07-28');
        expect('resolved' in withContent, `a complete result with content must be delivered, got ${JSON.stringify(withContent)}`).toBe(true);

        const outcome = await callTool({ resultType: 'complete', structuredContent: { ok: true } }, '2026-07-28');
        expect('rejected' in outcome, `must reject a 2026 result without content, got ${JSON.stringify(outcome)}`).toBe(true);
        expect((outcome as { rejected: unknown }).rejected).toBeInstanceOf(SdkError);
        expect(((outcome as { rejected: SdkError }).rejected).code).toBe(SdkErrorCode.InvalidResult);
    });

    it('[guard_requires_content] isCallToolResult rejects absent / undefined content, accepts an explicit array', () => {
        expect(isCallToolResult({ structuredContent: { ok: true } })).toBe(false);
        expect(isCallToolResult({ content: undefined, structuredContent: { ok: true } })).toBe(false);
        expect(isCallToolResult({})).toBe(false);
        expect(isCallToolResult({ content: [] })).toBe(true);
        expect(isCallToolResult({ content: [{ type: 'text', text: 'hi' }] })).toBe(true);
    });
});
