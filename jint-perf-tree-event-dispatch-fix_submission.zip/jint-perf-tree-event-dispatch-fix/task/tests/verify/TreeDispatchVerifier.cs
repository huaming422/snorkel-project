#if NET8_0_OR_GREATER
#nullable enable

using Jint.Native;
using Jint.Runtime;
using Jint.WebApi;
using Jint.WebApi.Events;

namespace Jint.Tests.Runtime.WebApi;

/// <summary>
/// Behavioral verifier for jint-perf-tree-event-dispatch. It drives one real
/// <c>dispatchEvent</c> over a host tree supplied by a counting fixture and reads
/// the <i>cost</i> of a dispatch as the number of times it reaches the host's tree
/// seams, so a complexity claim is a deterministic count rather than a stopwatch.
/// </summary>
/// <remarks>
/// <para>
/// The fixture overrides ONLY the two seams that are <c>virtual</c> in both the
/// pre-fix and the fixed engine — <see cref="JsEventTarget.TreeParent"/> (the
/// node-tree parent the root walk climbs) and <see cref="JsEventTarget.GetParent"/>
/// (the event path's <i>get the parent</i>) — plus the pre-existing shadow-query
/// seams. It never overrides <c>GetRoot()</c> and never names the engine's depth
/// bound or its cyclic-tree reporter: those are the reference solution's own
/// internals, and referencing them would couple the verifier to one implementation
/// and stop it compiling against a different-but-correct fix. Discrimination is
/// therefore purely behavioral — call counts and the thrown exception — and the
/// same test file compiles unchanged against a quadratic engine, the reference
/// engine, and any linear refactor that keeps the two seam contracts.
/// </para>
/// <para>
/// A host that answers its own root in O(1) (the reference solution exposes an
/// overridable <c>GetRoot()</c> for exactly that) is a solution-OPTIONAL
/// mechanism the task contract never mandates, so it is judged by the rubric
/// (<c>root_override_contract</c>) rather than
/// pinned here.
/// </para>
/// </remarks>
public class TreeDispatchVerifier
{
    /// <summary>
    /// The depth the cost pins dispatch over. Deep enough that a quadratic dispatch
    /// is unmistakable (the pre-fix walk read <c>TreeParent</c> tens of thousands of
    /// times here) and shallow enough that the test costs nothing.
    /// </summary>
    private const int DeepTree = 200;

    /// <summary>
    /// Where the two cycle fixtures stop answering. It is far above any bound a
    /// correct engine imposes, so a dispatch that reaches it is one the engine did
    /// NOT stop — which is a failing test, not a hung trial.
    /// </summary>
    private const int FixtureCeiling = 50_000;

    /// <summary>How often one dispatch reached each tree seam.</summary>
    private sealed class SeamCounts
    {
        internal int TreeParentReads { get; set; }

        internal int GetParentCalls { get; set; }

        internal int ShadowHostReads { get; set; }
    }

    private enum TreeKind
    {
        Node,
        Slot,
        OpenShadowRoot,
        ClosedShadowRoot,
    }

    /// <summary>
    /// The smallest host a tree dispatch needs: a target that is a node, answers a
    /// tree parent and a <i>get the parent</i>, and can be a shadow root / slot. It
    /// counts every read of the two walk seams, and can be wired to cycle — stopping
    /// at <see cref="FixtureCeiling"/> — so an unbounded engine fails rather than hangs.
    /// </summary>
    private sealed class ProbeEventTarget : JsEventTarget
    {
        private readonly SeamCounts _counts;

        internal ProbeEventTarget(Engine engine, Realm realm, string name, TreeKind kind, SeamCounts counts)
            : base(engine, realm)
        {
            _prototype = realm.Intrinsics.EventTarget.PrototypeObject;
            Name = name;
            Kind = kind;
            _counts = counts;
            DefineOwnDataPropertyUnchecked("name", JsString.Create(name));
        }

        internal string Name { get; }

        private TreeKind Kind { get; }

        /// <summary>The node-tree parent — what roots and retargeting are computed from.</summary>
        internal ProbeEventTarget? NodeParent { get; set; }

        /// <summary>The shadow host, set on a shadow root.</summary>
        internal ProbeEventTarget? Host { get; init; }

        /// <summary>The slot this slottable is assigned to, if any.</summary>
        internal ProbeEventTarget? Slot { get; set; }

        /// <summary>
        /// What <see cref="GetParent"/> answers whatever the real tree says — how a
        /// broken host's event path is built here. It stops at the fixture ceiling so a
        /// dispatcher that fails to bound the walk fails the assertion rather than hanging.
        /// </summary>
        internal ProbeEventTarget? CyclicParent { get; set; }

        /// <summary>The same, for the node-tree parent the root walk climbs.</summary>
        internal ProbeEventTarget? CyclicTreeParent { get; set; }

        /// <summary>
        /// What <see cref="ShadowHost"/> answers when this root is wired to cycle — the host whose own root
        /// climbs back to this one, so retargeting a related target out of the tree never bottoms out. Read
        /// once per climb step and stopped at the fixture ceiling, so a dispatcher that fails to bound the
        /// shadow-host climb fails the assertion rather than hanging.
        /// </summary>
        internal ProbeEventTarget? CyclicShadowHost { get; set; }

        internal override bool IsNode => true;

        internal override JsEventTarget? TreeParent
        {
            get
            {
                _counts.TreeParentReads++;

                if (CyclicTreeParent is { } cyclic)
                {
                    return _counts.TreeParentReads > FixtureCeiling ? null : cyclic;
                }

                return NodeParent;
            }
        }

        internal override bool IsShadowRoot => Kind is TreeKind.OpenShadowRoot or TreeKind.ClosedShadowRoot;

        internal override bool IsClosedShadowRoot => Kind == TreeKind.ClosedShadowRoot;

        /// <summary>
        /// The shadow host, counted. A root wired to cycle answers its cyclic host until the fixture ceiling,
        /// so a dispatcher that fails to bound the shadow-host climb retargeting runs fails the assertion
        /// rather than hanging; every other root answers the host it was built with.
        /// </summary>
        internal override JsEventTarget? ShadowHost
        {
            get
            {
                _counts.ShadowHostReads++;

                if (CyclicShadowHost is { } cyclic)
                {
                    return _counts.ShadowHostReads > FixtureCeiling ? null : cyclic;
                }

                return Host;
            }
        }

        internal override bool IsSlot => Kind == TreeKind.Slot;

        internal override JsEventTarget? AssignedSlot => Slot;

        /// <summary>
        /// DOM's <i>get the parent</i>, counted. A shadow root answers its host, a
        /// slottable its assigned slot, anything else its node parent — the subset the
        /// composed-event tests below exercise. A wired cycle answers its cyclic parent
        /// until the fixture ceiling.
        /// </summary>
        internal override JsEventTarget? GetParent(JsEvent ev)
        {
            _counts.GetParentCalls++;

            if (CyclicParent is { } cyclic)
            {
                return _counts.GetParentCalls > FixtureCeiling ? null : cyclic;
            }

            if (IsShadowRoot)
            {
                return Host;
            }

            return Slot ?? (JsEventTarget?) NodeParent;
        }
    }

    /// <summary>
    /// An engine with the events feature, a <c>log</c>/<c>note</c> pair for the
    /// ordering tests, and factories that build the fixture tree and publish each
    /// node to script under its own name.
    /// </summary>
    private sealed class Fixture
    {
        internal Fixture(WebApiFeatures features = WebApiFeatures.Events)
        {
            Engine = new Engine(options => options.UseWebApis(features));
            Engine.Execute("var log = []; function note(s) { log.push(s); }");
        }

        internal Engine Engine { get; }

        /// <summary>How often the tree seams were reached over this fixture's dispatches.</summary>
        internal SeamCounts Counts { get; } = new();

        private Realm Realm => Engine.Realm;

        internal ProbeEventTarget Node(string name, ProbeEventTarget? parent = null, TreeKind kind = TreeKind.Node)
        {
            var node = new ProbeEventTarget(Engine, Realm, name, kind, Counts) { NodeParent = parent };
            Engine.SetValue(name, node);
            return node;
        }

        internal ProbeEventTarget ShadowRoot(string name, ProbeEventTarget host, bool closed)
        {
            var kind = closed ? TreeKind.ClosedShadowRoot : TreeKind.OpenShadowRoot;
            var root = new ProbeEventTarget(Engine, Realm, name, kind, Counts) { Host = host };
            Engine.SetValue(name, root);
            return root;
        }

        internal (ProbeEventTarget Root, ProbeEventTarget Mid, ProbeEventTarget Leaf) Chain()
        {
            var root = Node("root");
            var mid = Node("mid", root);
            var leaf = Node("leaf", mid);
            return (root, mid, leaf);
        }

        /// <summary>
        /// A chain of <paramref name="depth"/> nodes from a root down to the leaf it
        /// answers, published as <c>leaf</c>. Nothing listens: what the cost tests read
        /// is the price of building the path. Counts are zeroed after construction so
        /// only the dispatch is measured.
        /// </summary>
        internal ProbeEventTarget Line(int depth)
        {
            var root = new ProbeEventTarget(Engine, Realm, "n0", TreeKind.Node, Counts);
            var node = root;
            for (var i = 1; i < depth; i++)
            {
                node = new ProbeEventTarget(Engine, Realm, "n" + i, TreeKind.Node, Counts) { NodeParent = node };
            }

            Counts.TreeParentReads = 0;
            Counts.GetParentCalls = 0;
            Engine.SetValue("leaf", node);
            return node;
        }

        internal string Log => Engine.Evaluate("log.join(',')").AsString();

        internal void Execute(string source) => Engine.Execute(source);

        internal JsValue Evaluate(string source) => Engine.Evaluate(source);
    }

    private const string ListenOnChain = """
        ['root', 'mid', 'leaf'].forEach(function (name) {
            var t = globalThis[name];
            t.addEventListener('ping', function (e) { note(name + ':capture:' + e.eventPhase + ':' + (e.currentTarget === t)); }, true);
            t.addEventListener('ping', function (e) { note(name + ':bubble:' + e.eventPhase + ':' + (e.currentTarget === t)); }, false);
        });
        """;

    // -----------------------------------------------------------------------
    // linear_dispatch / one_root_walk (fail_to_pass) — the core cost pin.
    // -----------------------------------------------------------------------

    /// <summary>
    /// One dispatch over a deep chain reads the tree seams a small constant multiple
    /// of the depth, not its square. The pre-fix dispatcher re-derived each path
    /// item's root by re-walking to the top, so the reads grew quadratically; a fix
    /// derives every root from one walk and threads it forward, so they grow linearly.
    /// The bound also rejects a memo/caching band-aid: on a chain every node is a
    /// distinct target, so caching a per-node root still pays one walk per node
    /// unless the shared-root insight (the actual fix) is used.
    /// </summary>
    [Test]
    public void OneDeepDispatchReadsTheTreeSeamsLinearlyInDepthNotQuadratically()
    {
        var fixture = new Fixture();
        fixture.Line(DeepTree);

        fixture.Execute("leaf.dispatchEvent(new Event('ping', { bubbles: true }));");

        // A linear dispatch reads TreeParent a small constant times per depth — one
        // root walk plus a same-tree check per hop. A quadratic one re-derives each
        // item's root by re-walking to the top, so its reads grow with DeepTree^2
        // (order tens of thousands here). The bound sits a decade below that quadratic
        // cost yet well above any constant-factor a linear refactor could plausibly
        // pay, so it rejects the quadratic dispatch without pinning one linear shape.
        fixture.Counts.TreeParentReads.Should().BeLessThan(10 * DeepTree);
    }

    // -----------------------------------------------------------------------
    // get_parent_once_per_item (pass_to_pass) — the promise the cycle fix must keep.
    // -----------------------------------------------------------------------

    /// <summary>
    /// <i>get the parent</i> is called exactly once per path item — before and after
    /// the fix. This guards the senior decision to bound the walk by depth rather than
    /// detect cycles with a tortoise-and-hare that would read the seam twice per item;
    /// a host reconciles state in <c>GetParent</c> and relies on it firing once.
    /// </summary>
    [Test]
    public void GetTheParentIsCalledExactlyOncePerPathItem()
    {
        var fixture = new Fixture();
        fixture.Line(DeepTree);

        fixture.Execute("leaf.dispatchEvent(new Event('ping', { bubbles: true }));");

        fixture.Counts.GetParentCalls.Should().Be(DeepTree);
    }

    // -----------------------------------------------------------------------
    // cycle_refused + cycle_exception_shape (fail_to_pass) — both bounded walks.
    // -----------------------------------------------------------------------

    /// <summary>
    /// A <i>get the parent</i> override that forms a cycle is refused promptly — the
    /// dispatch raises an error and stops after a bound instead of building an
    /// unbounded path and hanging. The error reaches the embedder rather than the
    /// offending script: the dispatch is wrapped in a script try/catch, and the error
    /// is asserted to propagate PAST it (an uncatchable, non-script-level failure).
    /// </summary>
    /// <remarks>
    /// The assertion is deliberately on the error's observable STATE — that one is
    /// raised, that it is not script-catchable, and that it arrived well before the
    /// fixture stopped answering — not on its CLR type or message text. The exact
    /// exception type and the message's content (which host, which seam) are a free
    /// design choice the task contract never spells out, judged by the rubric rather
    /// than pinned here; pinning them would reject a valid refusal that worded itself
    /// differently or chose another host-contract exception.
    /// </remarks>
    [Test]
    public void AGetParentCycleIsRefusedWithAnUncatchableHostError()
    {
        var fixture = new Fixture();
        var a = fixture.Node("a");
        var b = fixture.Node("b");
        a.CyclicParent = b;
        b.CyclicParent = a;

        // Assert.Catch admits ANY CLR exception, so the test pins "a non-script
        // exception was raised", not its type. The script try/catch is the other half:
        // a band-aid that signalled the cycle through the engine's own script-catchable
        // error channel would be swallowed by the catch, no exception would propagate,
        // and Assert.Catch would fail. A nop that never bounds the walk returns once the
        // fixture stops answering at the ceiling — no exception — and also fails.
        Assert.Catch(
            () => fixture.Execute("""
                try {
                    a.dispatchEvent(new Event('ping', { bubbles: true }));
                    note('returned');
                } catch (e) {
                    note('caught');
                }
                """));

        // The engine stopped the walk well before the fixture gave up answering, so the
        // refusal was prompt rather than a walk of the whole 50,000-step ceiling.
        fixture.Counts.GetParentCalls.Should().BeLessThan(FixtureCeiling);
    }

    /// <summary>
    /// The path walk is not the only walk a dispatch makes: deriving the tree root
    /// climbs <see cref="JsEventTarget.TreeParent"/>, and a cycle there hangs the same
    /// dispatch. It is bounded too, and refused the same way.
    /// </summary>
    [Test]
    public void ATreeParentCycleIsRefusedByTheRootWalk()
    {
        var fixture = new Fixture();
        var a = fixture.Node("a");
        var b = fixture.Node("b");
        a.CyclicTreeParent = b;
        b.CyclicTreeParent = a;

        // As with the path-walk cycle: pin that SOME non-script error is raised and the
        // walk stopped before the fixture's ceiling, not the error's CLR type or text.
        Assert.Catch(
            () => fixture.Execute("""
                try {
                    a.dispatchEvent(new Event('ping'));
                    note('returned');
                } catch (e) {
                    note('caught');
                }
                """));

        fixture.Counts.TreeParentReads.Should().BeLessThan(FixtureCeiling);
    }

    /// <summary>
    /// A dispatch retargets its event's related target against every path item, and that
    /// retarget climbs out of each shadow tree the item is not inside by stepping from a
    /// shadow root to its host. A host chain whose shadow hosts loop makes that climb a
    /// third non-terminating walk — one neither the path walk nor the root walk goes near,
    /// because it is driven by the related target rather than by the dispatch target's own
    /// ancestors. It is bounded too, and refused the same way.
    /// </summary>
    /// <remarks>
    /// The related target is reachable only from inside the engine (no event interface this
    /// engine ships exposes it to script), so the event is built here and dispatched at a
    /// plain node whose own tree is a single step — which keeps the dispatch-target walks
    /// finite and isolates the looping climb to retargeting. A fix that bounds the path and
    /// root walks but leaves the shadow-host climb unbounded walks the whole fixture ceiling
    /// and returns rather than throwing, and fails here. As with the other two cycles, the
    /// assertion pins that SOME non-script error is raised and that the climb stopped before
    /// the fixture's ceiling — never the error's CLR type or text.
    /// </remarks>
    [Test]
    public void AShadowHostCycleIsRefusedByTheRetargetClimb()
    {
        var fixture = new Fixture();

        // The dispatch target is a plain node in no tree, so its own path and root walks are
        // a single step and cannot be what loops. The event's related target sits in a shadow
        // tree whose host is a node inside the very tree it hosts: shadow root sr hosts host,
        // whose own root climbs back to sr — so climbing a shadow host to leave the tree never
        // bottoms out, though every per-node root walk (up the node-tree parents) is finite.
        var target = fixture.Node("t");

        var sr = fixture.ShadowRoot("sr", host: null!, closed: false);
        var host = fixture.Node("host", sr);
        var related = fixture.Node("related", sr);
        sr.CyclicShadowHost = host;

        Assert.Catch(
            () => DispatchWithRelatedTarget(fixture, target, related));

        // The engine stopped the shadow-host climb well before the fixture gave up answering.
        fixture.Counts.ShadowHostReads.Should().BeLessThan(FixtureCeiling);
    }

    /// <summary>
    /// Build a bubbling event carrying <paramref name="related"/> as its related target — the
    /// one dispatch input no event interface this engine ships lets script set — and dispatch
    /// it at <paramref name="target"/> through the same internal entry <c>dispatchEvent</c> uses.
    /// </summary>
    private static void DispatchWithRelatedTarget(Fixture fixture, ProbeEventTarget target, ProbeEventTarget related)
    {
        var ev = fixture.Engine.Realm.Intrinsics.Event.CreateTrustedEvent(
            JsString.Create("ping"),
            new EventInit(Bubbles: true, Cancelable: false, Composed: true));
        ev.RelatedTarget = related;
        target.DispatchEvent(ev);
    }

    // -----------------------------------------------------------------------
    // dispatch_semantics_intact (pass_to_pass) — regression guards. These hold on
    // both the pre-fix engine and any correct refactor; a refactor that breaks
    // ordering, composedPath, retargeting or closed-tree hiding fails them.
    // -----------------------------------------------------------------------

    [Test]
    public void WalksTheTreeDownInTheCapturePhaseAndBackUpInTheBubblePhase()
    {
        var fixture = new Fixture();
        fixture.Chain();

        fixture.Execute(ListenOnChain);
        fixture.Execute("leaf.dispatchEvent(new Event('ping', { bubbles: true }));");

        fixture.Log.Should().Be(
            "root:capture:1:true,mid:capture:1:true,leaf:capture:2:true,leaf:bubble:2:true,mid:bubble:3:true,root:bubble:3:true");
    }

    [Test]
    public void ComposedPathAnswersTheWholePathFromEveryPhase()
    {
        var fixture = new Fixture();
        fixture.Chain();

        fixture.Execute("""
            function names(e) { return e.composedPath().map(function (t) { return t.name; }).join('>'); }
            ['root', 'mid', 'leaf'].forEach(function (name) {
                globalThis[name].addEventListener('ping', function (e) { note(name + '=' + names(e)); }, true);
            });
            leaf.dispatchEvent(new Event('ping', { bubbles: true }));
            note('after=' + names(new Event('x')));
            """);

        fixture.Log.Should().Be("root=leaf>mid>root,mid=leaf>mid>root,leaf=leaf>mid>root,after=");
    }

    [Test]
    public void AnEventOutOfAnOpenShadowTreeRetargetsItsTargetButHidesNothing()
    {
        var fixture = ShadowFixture(closed: false);

        fixture.Execute("""
            function names(e) { return e.composedPath().map(function (t) { return t.name; }).join('>'); }
            outer.addEventListener('ping', function (e) { note('outer:' + e.target.name + ':' + names(e)); });
            inner.addEventListener('ping', function (e) { note('inner:' + e.target.name + ':' + names(e)); });
            inner.dispatchEvent(new Event('ping', { bubbles: true, composed: true }));
            """);

        // The listener inside sees the real target; the one outside sees the host,
        // because a node in a shadow tree is retargeted against it. An open tree hides
        // nothing from composedPath().
        fixture.Log.Should().Be("inner:inner:inner>shadow>host>outer,outer:host:inner>shadow>host>outer");
    }

    [Test]
    public void AClosedShadowTreeIsHiddenFromComposedPathOutsideIt()
    {
        var fixture = ShadowFixture(closed: true);

        fixture.Execute("""
            function names(e) { return e.composedPath().map(function (t) { return t.name; }).join('>'); }
            outer.addEventListener('ping', function (e) { note('outer:' + e.target.name + ':' + names(e)); });
            inner.addEventListener('ping', function (e) { note('inner:' + e.target.name + ':' + names(e)); });
            inner.dispatchEvent(new Event('ping', { bubbles: true, composed: true }));
            """);

        fixture.Log.Should().Be("inner:inner:inner>shadow>host>outer,outer:host:host>outer");
    }

    /// <summary>
    /// <c>outer &gt; host</c>, a shadow root on the host, and <c>inner</c> inside it.
    /// </summary>
    private static Fixture ShadowFixture(bool closed)
    {
        var fixture = new Fixture();
        var outer = fixture.Node("outer");
        var host = fixture.Node("host", outer);
        var shadow = fixture.ShadowRoot("shadow", host, closed);
        fixture.Node("inner", shadow);
        return fixture;
    }
}
#endif
