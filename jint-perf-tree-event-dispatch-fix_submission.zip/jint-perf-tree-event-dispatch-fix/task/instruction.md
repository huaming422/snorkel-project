## Task

we've had reports that DOM event dispatch over the WebApi Events feature gets pathologically slow on deep host trees. the host is a DOM-like structure where many nested nodes each act as an event target. dispatch one event down a moderately deep subtree and that dispatch's cost grows roughly with the square of how deep the target sits, so a host a few hundred nodes deep burns wildly disproportionate time on one dispatch. it should scale with the depth, not its square.

a separate report: a malformed host whose parent links never bottom out, a node that ends up its own ancestor, hangs the engine on dispatch. it spins forever and the embedder never gets an error back.

dig into the Events dispatch path and fix both: one dispatch linear in tree depth, and a non-terminating host tree refused promptly with a clear error instead of hanging. that error has to reach the embedder even if the dispatching script tries to catch it; a page that could swallow the engine's only report of the broken host is left right back where it started. the flat path that ordinary non-tree targets take is already cheap, so leave it be.

to see the slowness deterministically, count how often one dispatch reaches into the host for tree structure rather than timing it. rework the internals freely, but keep the public API and the existing dispatch semantics intact: ordering, how the current target reports across shadow boundaries, the composed path, and closed-subtree hiding.
