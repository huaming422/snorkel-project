## Task

Our server can ask a client for structured input while a handler is running. The request builder accepts a validation schema, usually a Zod object but sometimes one from another schema library, and turns it into the restricted form schema sent to the client. That conversion currently has several user-visible problems.

Schemas using native email, URL, date, or date-time validators can fail during request construction, while the equivalent format supplied only as an annotation succeeds. Authors should be able to use these validating declarations and retain each supported format in the request.

Some unsupported schemas take the opposite path and reach the client. A strict object forbids unknown keys, yet its constraint cannot be expressed in this form schema; silently dropping that constraint changes its meaning. Raw schema-library internals have also appeared in outgoing requests. Reject constraints that cannot be represented without weakening them, including a customized validation pattern or a required field that has no matching property. Identify the offending field or keyword when rejecting a schema. Today the error can instead be several kilobytes long and fail to make the problem clear.

Repair the conversion of incoming validation schemas while preserving the existing restricted wire shape and public request builder. Ordinary flat fields and schemas already valid for the wire should continue to work.
