## Task

a project here lets mise auto-create a python virtualenv (e.g. `_.python.venv = { create = true }`), and the `[deps.*]` providers built on that venv should run their install step whenever mise creates it fresh.

the bad sequence: `rm -rf .venv`, then let a *separate, later* mise process recreate it, via shell activation or a plain `mise env`. afterward the providers all report fresh. `mise deps install <provider> --explain` prints `Status: fresh`, the install never reruns, the venv stays empty, and first real use fails (e.g. a python import raises `ModuleNotFoundError`).

the giveaway: it only breaks across a process boundary. the process that recreates the venv handles it right; a *different* process checking freshness afterward calls a stale provider fresh. after mise recreates a tracked venv, a provider depending on it should read as needing to run.

keep the rest of the freshness logic honest: providers still rerun on a declared source or install-command change, a missing output still needs a rerun, and a venv mise didn't create shouldn't read as stale on its own.

dig in and fix it.
