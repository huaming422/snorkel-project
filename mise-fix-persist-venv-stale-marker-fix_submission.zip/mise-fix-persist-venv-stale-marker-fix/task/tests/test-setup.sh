#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# This task's behavior is observable only through the compiled `mise` CLI driven
# by the repo's e2e harness, so the verifier needs an up-to-date `mise` binary
# built from whatever the agent left in the working tree.
cd /repo/mise

# Build offline: the image baked the full workspace dependency closure and a
# warm target cache at build time (Dockerfile blocks 5 and 7), so a cargo build
# here resolves entirely from the cache. Force offline so a cache miss fails
# fast instead of reaching for crates.io.
export CARGO_NET_OFFLINE=true

# Rebuild the `mise` binary from the current (agent-modified) sources so the
# e2e harness picks it up at $CARGO_TARGET_DIR/debug/mise. Offline-first with a
# logged online fallback in case the image bake was stale.
if cargo build --locked --bin mise > /tmp/test-setup-build.log 2>&1; then
    echo "[offline-first] mise built from image-warmed cache"
elif CARGO_NET_OFFLINE=false cargo build --locked --bin mise >> /tmp/test-setup-build.log 2>&1; then
    echo "[test-setup] mise built after online fetch (image cache was stale)"
else
    tail -60 /tmp/test-setup-build.log >&2; exit 1
fi

# Sanity: the binary exists where the e2e harness looks for it.
test -x "${CARGO_TARGET_DIR:-/repo/mise/target}/debug/mise" \
    || { echo "mise binary not found after build" >&2; exit 1; }

# No services to start, no data to seed: the reproduction is self-contained
# (stdlib venv via system python3, fake `touch` provider commands). The e2e
# harness provisions its own isolated HOME/STATE dirs per test.
