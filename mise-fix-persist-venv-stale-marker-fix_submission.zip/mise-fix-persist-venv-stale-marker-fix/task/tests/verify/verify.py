"""Behavioral verifier for mise-fix-persist-venv-stale-marker.

The deps freshness/staleness behavior under test is observable ONLY through the
`mise` CLI, so every check here drives the real binary. Each scenario is a small
bash script run through the repository's own e2e harness (`e2e/run_test`), which
provisions an isolated HOME / state dir per run, resolves the freshly built
`mise` from `$CARGO_TARGET_DIR/debug`, and exports the experimental + non-
interactive flags the `deps` feature needs. We force the harness's in-process
path with `MISE_E2E_INSIDE_DOCKER=1` (no nested docker).

Why the e2e harness and not an in-process unit test: the defect is a
*cross-process* one. A marker set while one `mise` process recreates the venv
must still be visible to a *different*, later `mise` process that checks
freshness. Every `mise ...` line below is its own process, so the process
boundary is exercised for real — an in-memory-only implementation cannot pass.

Coupling guards (deliberate):
  * Assertions key on exit codes and the pre-existing stable strings
    `Installed: <id>` and `up to date` only. They never read the staleness
    reason wording, the on-disk marker path/format, or any internal field or
    function name — all of which a valid alternative fix may change.
  * `mise deps install <prov> --explain` exits non-zero when a provider is
    stale; we assert that exit status directly (`assert_fail`), not the text it
    prints.

The three tests map one-to-one onto the task's three behavioral criteria.
"""

from __future__ import annotations

import os
import subprocess
import tempfile
from pathlib import Path

import pytest

REPO_DIR = Path(f"/repo/{os.environ.get('REPO_NAME', 'mise')}")
RUN_TEST = REPO_DIR / "e2e" / "run_test"


def _run_e2e(script_body: str, *, timeout: int = 300) -> subprocess.CompletedProcess:
    """Run one bash scenario through the repo's e2e harness.

    The harness sources `e2e/assert.sh` (providing `assert_contains`,
    `assert_fail`, `assert`, `assert_directory_exists`, ...) and runs the
    script inside a fresh isolated environment. A zero exit means every
    assertion in the script passed.
    """
    assert RUN_TEST.exists(), f"e2e harness not found at {RUN_TEST}"

    env = dict(os.environ)
    # Force the harness to run the test locally in this container rather than
    # spinning up a nested docker image.
    env["MISE_E2E_INSIDE_DOCKER"] = "1"
    # The harness expands ${CARGO_TARGET_DIR} in its own shell to locate the
    # built binary; the task image sets it, but default defensively.
    env.setdefault("CARGO_TARGET_DIR", "/opt/cache/cargo-target")

    with tempfile.NamedTemporaryFile(
        "w", suffix="", prefix="verify_deps_", delete=False
    ) as fh:
        fh.write(script_body)
        script_path = fh.name
    try:
        return subprocess.run(
            ["bash", str(RUN_TEST), script_path],
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=str(REPO_DIR),
            env=env,
            check=False,
        )
    finally:
        try:
            os.unlink(script_path)
        except OSError:
            pass


def _assert_e2e_passed(proc: subprocess.CompletedProcess, *, hint: str) -> None:
    assert proc.returncode == 0, (
        f"{hint}\n"
        f"e2e scenario exited with {proc.returncode}.\n"
        f"--- last stdout ---\n{proc.stdout[-3000:]}\n"
        f"--- last stderr ---\n{proc.stderr[-3000:]}"
    )


# --------------------------------------------------------------------------- #
# Criterion 1 (fail_to_pass, basic): cross-process staleness
# --------------------------------------------------------------------------- #

_CROSS_PROCESS_STALE = r"""#!/usr/bin/env bash
# mise auto-creates .venv; a deps provider that builds into that venv declares
# the venv as its output, so its freshness is judged against that venv (the way
# a real venv-consuming provider tracks it). A custom-named provider is used so
# it is never shadowed by a built-in provider of the same name.
cat >requirements.txt <<'EOF2'
six
EOF2
cat >mise.toml <<'EOF2'
[settings]
python.venv_stdlib = true

[env]
_.python.venv = { path = ".venv", create = true }

[deps.venvdep]
sources = ["requirements.txt"]
outputs = [".venv"]
run = "touch .venv/installed"
EOF2

# First run creates the venv and runs the provider, then settles to up to date.
assert_contains "mise deps 2>&1" "Installed: venvdep"
assert_contains "mise deps 2>&1" "up to date"

# Delete the venv and let a SEPARATE, later process recreate it.
rm -rf .venv
mise env >/dev/null
assert_directory_exists .venv

# A different process checking freshness afterward must see the provider as
# needing to run. `--explain` exits non-zero when the provider is stale; we
# assert the exit status only (wording-independent).
assert_fail "mise deps install venvdep --explain 2>&1"
"""


def test_cross_process_stale() -> None:
    """After a separate process recreates a tracked venv, a later process must
    report the deps provider over it as stale (needing a rerun).

    An implementation that tracks the "mise created this venv" marker only in
    process memory cannot satisfy this: the recreating process and the checking
    process are distinct, so the marker is invisible and the provider is wrongly
    reported fresh (`--explain` exits 0).
    """
    proc = _run_e2e(_CROSS_PROCESS_STALE)
    _assert_e2e_passed(
        proc,
        hint=(
            "A provider over a venv recreated by a separate `mise` process was "
            "not reported stale in a later process (its `--explain` exited 0). "
            "The staleness signal is not surviving the process boundary."
        ),
    )


# --------------------------------------------------------------------------- #
# Criterion 2 (fail_to_pass): per-provider independent clearing
# --------------------------------------------------------------------------- #

_SHARED_VENV_INDEPENDENT_CLEAR = r"""#!/usr/bin/env bash
# Two providers both depend on the same auto-created venv.
cat >requirements.txt <<'EOF2'
six
EOF2
cat >mise.toml <<'EOF2'
[settings]
python.venv_stdlib = true

[env]
_.python.venv = { path = ".venv", create = true }

[deps.pip]
run = "touch .venv/installed"

[deps.extra]
sources = ["requirements.txt"]
outputs = [".venv"]
run = "touch .venv/extra"
EOF2

assert_contains "mise deps 2>&1" "Installed: pip"
assert_contains "mise deps 2>&1" "up to date"

# A separate process recreates the venv.
rm -rf .venv
mise env >/dev/null
assert_directory_exists .venv

# Run only `pip`. It becomes up to date and its install ran.
assert_contains "mise deps --only pip 2>&1" "Installed: pip"
assert "test -f .venv/installed"
assert_contains "mise deps --only pip 2>&1" "up to date"

# `extra` shares the same venv but has NOT run yet, so it must still be stale.
# A fix that clears a single shared flag the first time any provider runs would
# wrongly report `extra` fresh here.
assert_fail "mise deps install extra --explain 2>&1"

# Running `extra` clears its own staleness; afterwards everything is settled.
assert_contains "mise deps --only extra 2>&1" "Installed: extra"
assert "test -f .venv/extra"
assert_contains "mise deps 2>&1" "up to date"
"""


def test_shared_venv_independent_clear() -> None:
    """Two providers sharing one recreated venv each stay stale until they
    individually run; running one must not mark the other fresh.

    A durable but single-flag-per-venv fix passes the cross-process case yet
    fails here: after `pip` runs, `extra` is wrongly reported fresh. Staleness
    of a shared output has to be tracked per provider.
    """
    proc = _run_e2e(_SHARED_VENV_INDEPENDENT_CLEAR)
    _assert_e2e_passed(
        proc,
        hint=(
            "Running one provider over a shared recreated venv prematurely "
            "cleared another provider's staleness: the second provider was "
            "reported fresh before it had run. Staleness must be per provider."
        ),
    )


# --------------------------------------------------------------------------- #
# Criterion 3 (pass_to_pass, basic): ordinary freshness is unchanged
# --------------------------------------------------------------------------- #

_NO_FRESHNESS_REGRESSION = r"""#!/usr/bin/env bash
# Ordinary (non-venv) freshness: source change, unchanged, and missing output.
cat >requirements.txt <<'EOF2'
six
EOF2
cat >mise.toml <<'EOF2'
[deps.extra]
sources = ["requirements.txt"]
outputs = ["built.txt"]
run = "touch built.txt"
EOF2

# First run installs; an unchanged second run is up to date.
assert_contains "mise deps 2>&1" "Installed: extra"
assert_contains "mise deps 2>&1" "up to date"

# Editing a declared source makes the provider rerun.
echo "seven" >>requirements.txt
assert_contains "mise deps 2>&1" "Installed: extra"
assert_contains "mise deps 2>&1" "up to date"

# A missing output makes the provider rerun.
rm -f built.txt
assert_contains "mise deps 2>&1" "Installed: extra"
assert_contains "mise deps 2>&1" "up to date"

# A venv that mise did NOT create must not be reported stale on its own.
# Here `.venv` already exists as a plain directory and there is no
# `_.python.venv` auto-create directive, so nothing ever marked it as a
# freshly mise-created output. A provider whose output is that pre-existing
# `.venv` must therefore read as up to date, not stale.
mkdir -p nonmise/.venv
cd nonmise
cat >mise.toml <<'EOF2'
[deps.local]
outputs = [".venv"]
run = "touch .venv/built"
EOF2
assert_contains "mise deps 2>&1" "up to date"
assert_succeed "mise deps install local --explain 2>&1"
"""


def test_no_freshness_regression() -> None:
    """Ordinary freshness semantics still hold: a provider reruns on a declared
    source change and on a missing output, an unchanged provider is up to date,
    and a venv mise did not itself create is not spuriously stale.

    These paths work identically before and after the fix (pass_to_pass); they
    guard against an overreaching change that marks every tracked output — or
    every venv-shaped output — stale regardless of whether mise created it.
    """
    proc = _run_e2e(_NO_FRESHNESS_REGRESSION)
    _assert_e2e_passed(
        proc,
        hint=(
            "Ordinary freshness regressed: a source edit / missing output no "
            "longer reruns, an unchanged provider is no longer up to date, or a "
            "venv mise did not create was spuriously reported stale."
        ),
    )


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v", "--tb=short"]))
