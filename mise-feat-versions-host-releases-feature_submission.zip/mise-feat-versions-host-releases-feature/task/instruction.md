## Task

We install many tools from public GitHub releases, and to find a release's assets and resolve which version to install we call the public GitHub REST API directly. Anonymous calls get rate-limited hard, so installs in CI and Docker builds with no GitHub token fail intermittently.

We already run a shared versions host that caches version data for mise, and it can serve GitHub release metadata too. I want mise to pull a public repo's release metadata (the release and its downloadable assets) from the versions host when it can, and hit the GitHub API only when the host can't. That response is cached data we don't fully control, so treat it as untrusted: confirm it belongs to the release being installed before relying on it, and fall back to the API whenever it's missing or unusable. I'd also like a faster path for resolving fully-pinned exact versions.

Scope is release metadata and version resolution only. Signature and attestation verification is out of scope, and this is only the public GitHub path: leave Enterprise, custom hosts, and private repos alone.

## User stories / requirements

- When a tool backed by a public GitHub repo is installed and the shared versions host can serve its release metadata, mise gets the metadata from the versions host: the first request for that release's metadata goes to the versions host, not to the public GitHub API.
- When the versions host can't serve the metadata, whether it's a not-found, a rate-limit, or any other error, mise falls back to the public GitHub API and the install still succeeds, with no spurious error or warning surfaced to the user.
- When the metadata from the versions host carries download URLs that don't belong to the project being installed, for instance a different host, a different owner or repo, or a different release, mise doesn't trust it: it discards that response and falls back to the GitHub API.
- When the metadata from the versions host describes a release with no downloadable assets, mise treats it as unusable, discards it, and falls back to the GitHub API.
- When the release returned by the versions host isn't the release that was requested, its tag doesn't match, mise discards it and falls back to the GitHub API.
- When a tool resolves against a non-public GitHub API host, such as GitHub Enterprise or a custom API base, mise doesn't consult the versions host at all and goes straight to the configured GitHub host, exactly as it does today.
- When the versions host is turned off by setting, or mise is running offline or prefer-offline, mise doesn't reach for the versions host for release metadata.
- When a fully pinned exact version (such as a three-part X.Y.Z) of a public GitHub-backed tool is requested, mise confirms it with a single release lookup instead of fetching the full release list. If that lookup finds nothing, resolution falls through to the normal path, so a pin can still match a longer newest tag.
