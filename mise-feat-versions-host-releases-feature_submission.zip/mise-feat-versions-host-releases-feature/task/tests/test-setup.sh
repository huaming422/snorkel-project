#!/usr/bin/env bash
# Verifier-side setup: runs before the reward harness. The image already
# installed the Rust toolchain, the canonical verifier venv, warmed the cargo
# registry, and pre-built the full workspace + the `mise` binary at the base
# commit. This just re-exports the toolchain onto PATH (each phase gets a fresh
# shell) and sanity-checks the pieces the reward harness needs.
set -euo pipefail

# Rust toolchain — paths match the image Dockerfile's ENV block.
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export PATH="$CARGO_HOME/bin:$PATH"

rustc --version >/dev/null 2>&1 || {
    echo "ERROR: rustc not found on PATH (CARGO_HOME=$CARGO_HOME)" >&2
    exit 1
}
cargo --version >/dev/null 2>&1 || {
    echo "ERROR: cargo not found on PATH" >&2
    exit 1
}

# Canonical verifier interpreter. The reward harness runs Python through
# VERIFIER_PYTHON; expose it for scripts that honor it.
export VERIFIER_PYTHON="${VERIFIER_PYTHON:-/opt/tooling/venv/bin/python}"
"$VERIFIER_PYTHON" -c "import pytest, requests, unidiff" >/dev/null 2>&1 || {
    echo "ERROR: verifier venv missing expected packages ($VERIFIER_PYTHON)" >&2
    exit 1
}

echo "test-setup: rustc=$(rustc --version), cargo=$(cargo --version | head -1), verifier=$("$VERIFIER_PYTHON" --version 2>&1)"
