// @ts-nocheck
//
// Behavioral verifier for the elicitation form-schema conversion fix.
//
// Tests drive ONE pre-existing, stable public interface — the elicitation
// request builder `inputRequired.elicit({ message, requestedSchema })` — and
// observe only what it returns or throws. `inputRequired` is the builder the
// package exposes for authoring multi-round-trip handler results; this suite
// imports it from the module that defines it, exactly as the repo's own
// `test/shared/inputRequired.test.ts` does. No helper, predicate, routing
// function, or internal of the conversion path is imported or named here — a
// correct fix is observable entirely through the builder's input/output
// contract, so the suite admits any implementation that honours it.
//
// What the builder must do: accept a validation schema (a Zod object, or any
// Standard Schema library's object) for `requestedSchema` and convert it to
// the restricted form-elicitation wire schema (a flat object of primitive
// properties). The converted schema rides at `request.params.requestedSchema`.
//
// Routing is marked per test: FAIL-TO-PASS (f2p) checks the reported defects;
// PASS-TO-PASS (p2p) protects existing behavior.

import { describe, expect, test } from 'vitest';
import * as z from 'zod/v4';

import { inputRequired } from '../../src/shared/inputRequired';

// The converted/forwarded wire schema as the client would receive it.
function wireSchema(request: unknown): Record<string, any> {
    return (request as { params: { requestedSchema: Record<string, any> } }).params.requestedSchema;
}
function props(request: unknown): Record<string, Record<string, unknown>> {
    return wireSchema(request).properties as Record<string, Record<string, unknown>>;
}

describe('elicitation form-schema conversion', () => {
    // ─────────────────────────────────────────────────────────────────────
    // CRITERION native_format_helpers_convert
    //
    // The library's native validating string helpers (email / url / date /
    // date-time, and ISO variants) must convert: the request builds, the wire
    // property keeps the mapped `format`, and the library's companion
    // validation `pattern` that rides beside that format is dropped (the wire
    // grammar has no place for it). URL and annotation cases check the same
    // format contract through other supported declarations.
    // ─────────────────────────────────────────────────────────────────────
    test.each([
        ['z.email()', () => z.email(), 'email'],
        ['z.iso.date()', () => z.iso.date(), 'date'],
        ['z.iso.datetime()', () => z.iso.datetime(), 'date-time'],
        ['z.iso.datetime({ offset: true, precision: 3 })', () => z.iso.datetime({ offset: true, precision: 3 }), 'date-time']
    ])('[f2p] native_format_helpers_convert: %s keeps format and drops the companion pattern', (_label, make, expectedFormat) => {
        const request = inputRequired.elicit({
            message: 'Value?',
            requestedSchema: z.object({ value: make() })
        });

        const value = props(request).value!;
        expect(value.format).toBe(expectedFormat);
        expect(value.pattern).toBeUndefined();
    });

    test.each([
        ['z.url()', () => z.url(), 'uri'],
        ['z.string().meta({ format })', () => z.string().meta({ format: 'email' }), 'email']
    ])('[p2p] native_format_helpers_convert: %s keeps its format', (_label, make, expectedFormat) => {
        const request = inputRequired.elicit({ message: 'Value?', requestedSchema: z.object({ value: make() }) });
        expect(props(request).value!.format).toBe(expectedFormat);
        expect(props(request).value!.pattern).toBeUndefined();
    });

    // ─────────────────────────────────────────────────────────────────────
    // CRITERION strict_object_rejected
    //
    // A strict object (one that forbids unknown keys) carries a non-spec root
    // keyword (`additionalProperties`) the restricted wire shape does not
    // allow — it must be refused, naming the offending keyword, rather than
    // shipped. And no successfully-built request may carry `additionalProperties`
    // or `$defs` at the root of the wire schema.
    // ─────────────────────────────────────────────────────────────────────
    test('[f2p] strict_object_rejected: a strict object is refused, naming the non-spec root keyword', () => {
        const act = () =>
            inputRequired.elicit({
                message: 'Name?',
                requestedSchema: z.strictObject({ name: z.string() })
            });
        expect(act).toThrow(TypeError);
        expect(act).toThrow(/additionalProperties/);
    });

    test('[f2p] strict_object_rejected: a local reference is resolved or refused without leaking unsupported keywords', () => {
        const act = () =>
            inputRequired.elicit({
                message: 'Name?',
                requestedSchema: {
                    '~standard': {
                        version: 1,
                        vendor: 'test',
                        validate: (value: unknown) => ({ value }),
                        jsonSchema: {
                            input: () => ({
                                $defs: { Name: { type: 'string' } },
                                type: 'object',
                                properties: { name: { $ref: '#/$defs/Name' } },
                                required: ['name']
                            }),
                            output: () => ({})
                        }
                    }
                } as never
            });
        let request: unknown;
        try {
            request = act();
        } catch (error) {
            expect(error).toBeInstanceOf(TypeError);
            expect((error as Error).message).toMatch(/\bname\b|\$ref|\$defs/);
            expect((error as Error).message.length).toBeLessThan(500);
            return;
        }
        const schema = wireSchema(request);
        expect(schema).toMatchObject({
            type: 'object',
            properties: { name: { type: 'string' } },
            required: ['name']
        });
        expect('$defs' in schema).toBe(false);
        expect('$ref' in schema.properties.name).toBe(false);
    });

    test('[p2p] strict_object_rejected: a successfully converted object leaks no additionalProperties/$defs at the root', () => {
        const request = inputRequired.elicit({
            message: 'Name?',
            requestedSchema: z.object({ name: z.string() })
        });
        const schema = wireSchema(request);
        expect('additionalProperties' in schema).toBe(false);
        expect('$defs' in schema).toBe(false);
    });

    // ─────────────────────────────────────────────────────────────────────
    // CRITERION validate_only_fails_closed
    //
    // A Standard Schema that can validate but does not implement the JSON
    // Schema producer, from a vendor the builder cannot otherwise handle, must
    // fail closed through the converter — never ship the raw library-internal
    // object onto the wire.
    // ─────────────────────────────────────────────────────────────────────
    test('[f2p] validate_only_fails_closed: a validate-only non-handled vendor is refused, not shipped', () => {
        const validateOnly = {
            '~standard': {
                version: 1,
                vendor: 'not-zod',
                validate: (value: unknown) => ({ value })
            }
        };
        const act = () => inputRequired.elicit({ message: 'Name?', requestedSchema: validateOnly as never });
        expect(act).toThrow(TypeError);
    });

    test('[p2p] validate_only_fails_closed: no raw ~standard/internal object reaches a built request', () => {
        // A handled vendor converts; the raw Standard-Schema wrapper object must
        // not survive onto the wire as the requestedSchema.
        const request = inputRequired.elicit({
            message: 'Name?',
            requestedSchema: z.object({ name: z.string() })
        });
        const schema = wireSchema(request);
        expect('~standard' in schema).toBe(false);
        expect(typeof schema.validate).toBe('undefined');
    });

    // ─────────────────────────────────────────────────────────────────────
    // CRITERION corrupt_conversion_rejected
    //
    // When conversion yields a schema that lists a `required` entry with no
    // matching property (observed when a `__proto__` key is lost from
    // `properties` but kept in `required`), the builder must refuse rather
    // than emit the corrupt schema. A property typed after an Object.prototype
    // member must also be refused with its field identified.
    // ─────────────────────────────────────────────────────────────────────
    test('[f2p] corrupt_conversion_rejected: a required entry with no matching property is refused', () => {
        const act = () =>
            inputRequired.elicit({
                message: 'Name?',
                requestedSchema: z.object({ ['__proto__']: z.string() })
            });
        // Core contract: refuse rather than ship the corrupt schema, and name the
        // offending field. `__proto__` is the input field name (not any fix-internal
        // wording), so this admits any implementation that rejects and names it.
        expect(act).toThrow(TypeError);
        expect(act).toThrow(/__proto__/);
    });

    test('[p2p] corrupt_conversion_rejected: a prototype-shadowing property type rejects and names its field', () => {
        const schema = {
            '~standard': {
                version: 1,
                vendor: 'test',
                validate: (value: unknown) => ({ value }),
                jsonSchema: {
                    input: () => ({ type: 'object', properties: { x: { type: 'constructor' } }, required: ['x'] }),
                    output: () => ({})
                }
            }
        };
        expect(() => inputRequired.elicit({ message: 'x', requestedSchema: schema as never })).toThrow(TypeError);
        // and it names the offending input field (its own token, not any fix-internal wording)
        expect(() => inputRequired.elicit({ message: 'x', requestedSchema: schema as never })).toThrow(/\bx\b/);
    });

    // ─────────────────────────────────────────────────────────────────────
    // CRITERION flat_object_converts
    //
    // A plain flat object — annotation-form format, bounded number, enum,
    // array-of-enum, literal-array enum, optional, defaults — converts to the
    // exact restricted wire shape, dropping property annotations the wire
    // cannot place.
    // ─────────────────────────────────────────────────────────────────────
    test('[p2p] flat_object_converts: a flat object converts to the restricted wire shape', () => {
        const request = inputRequired.elicit({
            message: 'Registration details?',
            requestedSchema: z.object({
                email: z.string().meta({ title: 'Email', format: 'email' }),
                count: z.number().min(1).max(5),
                role: z.enum(['admin', 'member'])
            })
        });

        expect(wireSchema(request)).toEqual({
            $schema: 'https://json-schema.org/draft/2020-12/schema',
            type: 'object',
            properties: {
                email: { type: 'string', title: 'Email', format: 'email' },
                count: { type: 'number', minimum: 1, maximum: 5 },
                role: { type: 'string', enum: ['admin', 'member'] }
            },
            required: ['email', 'count', 'role']
        });
    });

    test('[p2p] flat_object_converts: multi-select enums, optionals, and defaults convert as-is', () => {
        const request = inputRequired.elicit({
            message: 'Preferences?',
            requestedSchema: z.object({
                roles: z.array(z.enum(['admin', 'member'])),
                plan: z.literal(['free', 'pro']),
                nickname: z.string().optional(),
                newsletter: z.boolean().default(false)
            })
        });

        expect(wireSchema(request)).toEqual({
            $schema: 'https://json-schema.org/draft/2020-12/schema',
            type: 'object',
            properties: {
                roles: { type: 'array', items: { type: 'string', enum: ['admin', 'member'] } },
                plan: { type: 'string', enum: ['free', 'pro'] },
                nickname: { type: 'string' },
                newsletter: { type: 'boolean', default: false }
            },
            required: ['roles', 'plan']
        });
    });

    // ─────────────────────────────────────────────────────────────────────
    // CRITERION genuinely_unrepresentable_still_rejects
    //
    // Shapes the restricted wire schema genuinely cannot express still reject,
    // naming the offending field/path: nested objects, an explicit `.regex()`
    // pattern, a literal union, and — the case that rules out a naive
    // "strip every pattern" fix — a format whose validation pattern has been
    // CUSTOMIZED (sending `format` alone would silently weaken the advertised
    // constraint, so it must reject rather than drop the pattern).
    // ─────────────────────────────────────────────────────────────────────
    test('[p2p] genuinely_unrepresentable_still_rejects: a nested object rejects, naming its field', () => {
        const act = () => inputRequired.elicit({
            message: 'Address?',
            requestedSchema: z.object({ address: z.object({ city: z.string() }) })
        });
        expect(act).toThrow(TypeError);
        expect(act).toThrow(/\baddress\b/);
    });

    test('[p2p] genuinely_unrepresentable_still_rejects: an explicit .regex() pattern rejects, naming the path', () => {
        const act = () =>
            inputRequired.elicit({
                message: 'Code?',
                requestedSchema: z.object({ code: z.string().regex(/^[A-Z]{3}$/) })
            });
        expect(act).toThrow(TypeError);
        // names the offending input field (its own token), not any fix-internal path format
        expect(act).toThrow(/\bcode\b/);
    });

    test('[p2p] genuinely_unrepresentable_still_rejects: a literal union rejects (not a wire enum variant)', () => {
        expect(() =>
            inputRequired.elicit({
                message: 'Role?',
                requestedSchema: z.object({ role: z.union([z.literal('admin'), z.literal('member')]) })
            })
        ).toThrow(TypeError);
    });

    test('[p2p] genuinely_unrepresentable_still_rejects: a CUSTOMIZED format pattern rejects rather than silently weakening', () => {
        // z.email({ pattern }) layers a custom pattern on the email format.
        // Dropping the pattern and sending `format` alone would weaken the
        // advertised constraint, so this must reject — naming the field — while
        // the native z.email() (library-default pattern) still converts above.
        const act = () =>
            inputRequired.elicit({
                message: 'Email?',
                requestedSchema: z.object({ email: z.email({ pattern: /@corp\.com$/ }) })
            });
        expect(act).toThrow(TypeError);
        // names the offending input field (its own token), not any fix-internal path format
        expect(act).toThrow(/\bemail\b/);
    });

    // ─────────────────────────────────────────────────────────────────────
    // CRITERION annotations_dropped_and_raw_passthrough
    //
    // Annotation-only metadata (title/description on a property and on the
    // object root) must be tolerated — it is dropped where the wire grammar
    // cannot carry it, never a cause for rejection, and the schema still
    // converts. A plain wire-ready JSON schema (not a Standard Schema) passes
    // through with its contents intact, and an unknown top-level params key on
    // that pass-through request survives.
    //
    // (How the fix treats a non-zod library's own format-companion pattern —
    // trust-and-drop vs fail-closed — is left to the implementation and not
    // asserted here; the native-helper conversion and the customized-pattern
    // rejection above pin the only format-pattern behavior the contract fixes.)
    // ─────────────────────────────────────────────────────────────────────
    test('[p2p] annotations_dropped_and_raw_passthrough: annotation metadata is tolerated, not rejected, and the schema converts', () => {
        const request = inputRequired.elicit({
            message: 'Name?',
            requestedSchema: z.object({ name: z.string().meta({ title: 'Full name' }) }).meta({ title: 'User', description: 'User info' })
        });
        const schema = wireSchema(request);
        expect(schema.type).toBe('object');
        expect(schema.required).toEqual(['name']);
        expect(props(request).name!.type).toBe('string');
    });

    test('[p2p] annotations_dropped_and_raw_passthrough: a plain wire-ready JSON schema preserves its contents', () => {
        const rawSchema = {
            type: 'object' as const,
            properties: { name: { type: 'string' as const } },
            '~standard': 'extension-data'
        };
        const request = inputRequired.elicit({ message: 'Name?', requestedSchema: rawSchema as never });
        expect(wireSchema(request)).toEqual(rawSchema);
    });

    test('[p2p] annotations_dropped_and_raw_passthrough: an unknown params extension key survives on a pass-through request', () => {
        const rawRequest = inputRequired.elicit({
            message: 'OK?',
            requestedSchema: { type: 'object', properties: {} },
            myExtension: 'keep-me'
        } as never);

        expect((rawRequest.params as { myExtension?: string }).myExtension).toBe('keep-me');
    });
});
