## Task

Our server can ask a client for structured input while a handler is running. The request builder accepts a validation schema, usually a Zod object but sometimes one from another schema library, and turns it into the restricted form schema sent to the client. That conversion currently has several user-visible problems.

The trouble is easiest to see with native email, date, and date-time validators: building the request throws before it reaches the client. A plain format annotation works. URL fields belong to this same supported set, even though a URL field by itself already converts. Keep the supported formats in requests built from the validating declarations.

Some unsupported schemas take the opposite path and reach the client. A strict object forbids unknown keys, yet its constraint cannot be expressed in this form schema; silently dropping that constraint changes its meaning. Raw schema-library internals have also appeared in outgoing requests. Reject constraints that cannot be represented without weakening them, including a customized validation pattern or a required field that has no matching property. Identify the offending field or keyword when rejecting a schema. Today the error can instead be several kilobytes long and fail to make the problem clear.

Please fix the conversion path. Keep the request builder and restricted wire shape as they are, and make sure ordinary flat fields and wire-ready schemas still work.
