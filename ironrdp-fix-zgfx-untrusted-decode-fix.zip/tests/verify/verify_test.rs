//! Behavioural checks for the ZGFX decoder on untrusted input.
//!
//! Everything a remote RDP peer controls enters the ZGFX decoder through one
//! public entry point:
//!
//!   `ironrdp_graphics::zgfx::Decompressor::decompress(
//!        &mut self, input: &[u8], output: &mut Vec<u8>) -> Result<usize, _>`
//!
//! Valid traffic is produced through the sibling public API (`Compressor`,
//! `compress_and_wrap_egfx`, `CompressionMode`). Hostile traffic is built by
//! hand from the MS-RDPEGFX wire layout. Only observable behaviour is asserted:
//! a malformed message returns `Err` without panicking (a panic the decoder
//! catches itself still counts), an oversized message is
//! refused without allocating its full expansion (peak memory), and conforming
//! traffic round-trips byte for byte. No error variant, message text or size
//! constant is asserted.

use ironrdp_graphics::zgfx::{CompressionMode, Compressor, Decompressor, compress_and_wrap_egfx};
use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::Once;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};

// ---------------------------------------------------------------------------
// Counting global allocator (peak outstanding bytes)
// ---------------------------------------------------------------------------
//
// The allocator is always installed; accounting is gated off by default and
// flipped on only around the measured region. It tracks the running total of
// *outstanding* bytes (allocations minus frees, with `realloc` accounted as a
// delta so a growing `Vec` is counted as its logical capacity rather than the
// transient old+new overlap) and records the peak.
//
// `dealloc` subtracts saturating-to-zero so a free of something allocated
// before measurement began can never underflow the counter.
//
// The single global counter is only correct with `--test-threads=1`, which
// the rust runner already appends.

struct PeakAllocator;

static COUNTING_ENABLED: AtomicBool = AtomicBool::new(false);
static CURRENT: AtomicUsize = AtomicUsize::new(0);
static PEAK: AtomicUsize = AtomicUsize::new(0);

fn account_add(n: usize) {
    let current = CURRENT.fetch_add(n, Ordering::Relaxed) + n;
    PEAK.fetch_max(current, Ordering::Relaxed);
}

fn account_sub(n: usize) {
    let mut current = CURRENT.load(Ordering::Relaxed);
    loop {
        let next = current.saturating_sub(n);
        match CURRENT.compare_exchange_weak(current, next, Ordering::Relaxed, Ordering::Relaxed) {
            Ok(_) => break,
            Err(observed) => current = observed,
        }
    }
}

unsafe impl GlobalAlloc for PeakAllocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let ptr = unsafe { System.alloc(layout) };
        if !ptr.is_null() && COUNTING_ENABLED.load(Ordering::Relaxed) {
            account_add(layout.size());
        }
        ptr
    }

    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        if COUNTING_ENABLED.load(Ordering::Relaxed) {
            account_sub(layout.size());
        }
        unsafe { System.dealloc(ptr, layout) }
    }

    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let ptr = unsafe { System.alloc_zeroed(layout) };
        if !ptr.is_null() && COUNTING_ENABLED.load(Ordering::Relaxed) {
            account_add(layout.size());
        }
        ptr
    }

    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        let new_ptr = unsafe { System.realloc(ptr, layout, new_size) };
        if !new_ptr.is_null() && COUNTING_ENABLED.load(Ordering::Relaxed) {
            let old_size = layout.size();
            if new_size >= old_size {
                account_add(new_size - old_size);
            } else {
                account_sub(old_size - new_size);
            }
        }
        new_ptr
    }
}

#[global_allocator]
static GLOBAL: PeakAllocator = PeakAllocator;

/// Run `f`, returning the peak outstanding-byte count observed during it.
fn measure_peak<F: FnOnce()>(f: F) -> usize {
    CURRENT.store(0, Ordering::Relaxed);
    PEAK.store(0, Ordering::Relaxed);
    COUNTING_ENABLED.store(true, Ordering::Relaxed);
    f();
    COUNTING_ENABLED.store(false, Ordering::Relaxed);
    PEAK.load(Ordering::Relaxed)
}

// ---------------------------------------------------------------------------
// Panic detection
// ---------------------------------------------------------------------------
//
// A panic hook runs at the moment of the panic, before any unwinding, so it
// sees panics that the decoder catches internally as well as ones that escape.
// Every decode in this file goes through `decode`, which fails the test if the
// decoder panicked at any point during the call, whatever it returned.

static DECODER_PANICKED: AtomicBool = AtomicBool::new(false);
static INSTALL_HOOK: Once = Once::new();

fn decode(decompressor: &mut Decompressor, input: &[u8], output: &mut Vec<u8>) -> Result<usize, impl std::fmt::Debug + use<>> {
    INSTALL_HOOK.call_once(|| {
        let previous = std::panic::take_hook();
        std::panic::set_hook(Box::new(move |info| {
            DECODER_PANICKED.store(true, Ordering::SeqCst);
            previous(info);
        }));
    });
    DECODER_PANICKED.store(false, Ordering::SeqCst);
    let result = decompressor.decompress(input, output);
    assert!(
        !DECODER_PANICKED.swap(false, Ordering::SeqCst),
        "the decoder panicked while handling this input, even if it returned afterwards"
    );
    result
}

const MIB: usize = 1024 * 1024;

/// Peak-allocation ceiling shared by the oversized-message checks.
///
/// Every oversized message below would expand to more than 3 GiB if decoded in
/// full, so a decoder that accepts it ends up holding an output buffer of 4 GiB
/// (amortised `Vec` growth). A decoder that refuses it part way stays far
/// lower: with any per-message budget up to about 2 GiB the buffer never grows
/// past 2 GiB. 3 GiB sits between the two, so the check does not depend on the
/// exact budget a decoder picks.
const PEAK_CEILING: usize = 3 * 1024 * MIB;

/// Decode `frame` under the counting allocator and require that it is refused
/// with peak allocation under [`PEAK_CEILING`].
fn assert_refused_with_bounded_memory(label: &str, frame: &[u8]) {
    let mut decompressor = Decompressor::new();
    let mut output = Vec::new();
    let mut result = None;
    let peak = measure_peak(|| {
        result = Some(decode(&mut decompressor, frame, &mut output));
    });

    let result = result.expect("closure ran");
    eprintln!(
        "{label}: peak outstanding = {} MiB, output len = {} MiB, result_is_err = {}",
        peak / MIB,
        output.len() / MIB,
        result.is_err(),
    );

    assert!(
        result.is_err(),
        "{label}: an oversized message must be refused with an error, not decoded in full",
    );
    assert!(
        peak < PEAK_CEILING,
        "{label}: peak memory {} MiB reached the {} MiB ceiling before the message was refused",
        peak / MIB,
        PEAK_CEILING / MIB,
    );
}

// ---------------------------------------------------------------------------
// Wire-format helpers (public layout only, MS-RDPEGFX 2.2.5 / 3.1.9.1)
// ---------------------------------------------------------------------------

/// `type_and_flags` byte for an RDP8 + COMPRESSED segment (0x24).
const COMPRESSED_RDP8: u8 = 0x24;
/// Single-segment descriptor.
const DESC_SINGLE: u8 = 0xE0;
/// Multipart descriptor.
const DESC_MULTIPART: u8 = 0xE1;

/// Wrap raw compressed-segment bytes in a Single ZGFX PDU
/// (`[0xE0][0x24][bytes...]`).
fn single_compressed_frame(segment_bytes: &[u8]) -> Vec<u8> {
    let mut v = Vec::with_capacity(segment_bytes.len() + 2);
    v.push(DESC_SINGLE);
    v.push(COMPRESSED_RDP8);
    v.extend_from_slice(segment_bytes);
    v
}

/// Build a Multipart ZGFX PDU that repeats one compressed segment
/// `segment_count` times under the given declared uncompressed size.
fn multipart_frame(segment: &[u8], segment_count: u16, declared_total: u32) -> Vec<u8> {
    let mut frame = vec![DESC_MULTIPART];
    frame.extend_from_slice(&segment_count.to_le_bytes());
    frame.extend_from_slice(&declared_total.to_le_bytes());
    let seg_size = u32::try_from(segment.len() + 1).expect("segment size fits in u32");
    for _ in 0..segment_count {
        frame.extend_from_slice(&seg_size.to_le_bytes());
        frame.push(COMPRESSED_RDP8);
        frame.extend_from_slice(segment);
    }
    frame
}

/// Minimal MSB-first bit writer used to hand-build compressed token streams.
/// The final byte emitted is the ZGFX trailer: the count (0..=7) of unused
/// bits in the last data byte.
struct BitBuf {
    bytes: Vec<u8>,
    cur: u8,
    nbits: usize,
}

impl BitBuf {
    fn new() -> Self {
        Self {
            bytes: Vec::new(),
            cur: 0,
            nbits: 0,
        }
    }

    fn push_bit(&mut self, bit: bool) {
        if bit {
            self.cur |= 1 << (7 - self.nbits);
        }
        self.nbits += 1;
        if self.nbits == 8 {
            self.bytes.push(self.cur);
            self.cur = 0;
            self.nbits = 0;
        }
    }

    fn push_bits(&mut self, bits: &[u8]) {
        for &b in bits {
            self.push_bit(b != 0);
        }
    }

    /// Push the low `width` bits of `value`, most significant first.
    fn push_value(&mut self, value: u64, width: usize) {
        for shift in (0..width).rev() {
            self.push_bit((value >> shift) & 1 == 1);
        }
    }

    fn push_ones(&mut self, count: usize) {
        for _ in 0..count {
            self.push_bit(true);
        }
    }

    fn push_zeros(&mut self, count: usize) {
        for _ in 0..count {
            self.push_bit(false);
        }
    }

    /// Pad with zero bits up to the next byte boundary.
    fn align(&mut self) {
        while self.nbits != 0 {
            self.push_bit(false);
        }
    }

    fn push_raw_bytes(&mut self, raw: &[u8]) {
        assert_eq!(self.nbits, 0, "raw bytes go on a byte boundary");
        self.bytes.extend_from_slice(raw);
    }

    /// Finalise into `[data bytes..., trailer]`. `trailer` = unused bits in the
    /// last data byte, so a decoder computes exactly the bit count pushed.
    fn finish_segment(mut self) -> Vec<u8> {
        let unused = if self.nbits == 0 { 0 } else { 8 - self.nbits };
        if self.nbits > 0 {
            self.bytes.push(self.cur);
        }
        self.bytes.push(u8::try_from(unused).expect("unused bits is 0..=7"));
        self.bytes
    }
}

// Token-table prefixes (MS-RDPEGFX 2.2.5.3, the RDP 8.0 token table), used only
// to build inputs. They are the on-the-wire encoding every conforming
// compressor emits.
const TOKEN_MATCH_SMALL: [u8; 5] = [1, 0, 0, 0, 1]; // distance base 0, 5 value bits
const TOKEN_MATCH_12BIT: [u8; 5] = [1, 0, 1, 0, 1]; // distance base 1696, 12 value bits
const TOKEN_MATCH_12BIT_BASE: u64 = 1696;
const TOKEN_MATCH_21BIT: [u8; 8] = [1, 0, 1, 1, 1, 1, 0, 1]; // distance base 2_414_240, 21 value bits
const TOKEN_MATCH_21BIT_BASE: u64 = 2_414_240;
const TOKEN_MATCH_FARTHEST: [u8; 9] = [1, 0, 1, 1, 1, 1, 1, 1, 0]; // distance base ~17M, 24 value bits

/// Decode one compressed segment framed as a Single PDU; `true` if it was rejected.
fn single_segment_is_rejected(segment: &[u8]) -> bool {
    let frame = single_compressed_frame(segment);
    let mut decompressor = Decompressor::new();
    let mut output = Vec::new();
    decode(&mut decompressor, &frame, &mut output).is_err()
}

// ---------------------------------------------------------------------------
// Truncated or garbled messages are rejected with an error, no panic
// ---------------------------------------------------------------------------

#[test]
fn truncated_single_segment_short_trailer_is_error_not_panic() {
    // A Single compressed segment whose only byte is the trailer, and that
    // trailer claims unused bits in a data byte that does not exist.
    let frame = single_compressed_frame(&[0xFF]);

    let mut decompressor = Decompressor::new();
    let mut output = Vec::new();
    let result = decode(&mut decompressor, &frame, &mut output);

    assert!(
        result.is_err(),
        "a segment with no data bytes and a non-zero unused-bit count must surface as a decode error",
    );
}

#[test]
fn single_segment_insufficient_bits_for_literal_is_error_not_panic() {
    // Bit stream `0 0000000`: a null-literal prefix bit, then only 7 of the 8
    // payload bits it needs.
    let frame = single_compressed_frame(&[0x00, 0x00]);

    let mut decompressor = Decompressor::new();
    let mut output = Vec::new();
    let result = decode(&mut decompressor, &frame, &mut output);

    assert!(
        result.is_err(),
        "a segment that ends mid-token must surface as a decode error, not panic",
    );
}

#[test]
fn segments_ending_inside_a_token_are_errors_not_panics() {
    // Each stream stops part way through a different kind of token. Every one
    // is malformed and must come back as Err.
    let mut cases: Vec<(&str, Vec<u8>)> = Vec::new();

    // A lone `1` bit: the start of a match or literal prefix, cut short.
    let mut s = BitBuf::new();
    s.push_bits(&[1]);
    cases.push(("prefix cut short", s.finish_segment()));

    // A match token followed by only 2 of its 5 distance bits.
    let mut s = BitBuf::new();
    s.push_bits(&TOKEN_MATCH_SMALL);
    s.push_zeros(2);
    cases.push(("distance cut short", s.finish_segment()));

    // A match (distance 1) whose unary length prefix never reaches its
    // terminating zero bit.
    let mut s = BitBuf::new();
    s.push_bits(&TOKEN_MATCH_SMALL);
    s.push_value(1, 5);
    s.push_ones(6);
    cases.push(("length prefix unterminated", s.finish_segment()));

    // A match (distance 1) with length prefix `1110`, which needs 4 value
    // bits, but only 2 follow.
    let mut s = BitBuf::new();
    s.push_bits(&TOKEN_MATCH_SMALL);
    s.push_value(1, 5);
    s.push_bits(&[1, 1, 1, 0]);
    s.push_zeros(2);
    cases.push(("length value cut short", s.finish_segment()));

    // A raw-byte run (distance 0) whose 15-bit byte count stops after 7 bits.
    let mut s = BitBuf::new();
    s.push_bits(&TOKEN_MATCH_SMALL);
    s.push_value(0, 5);
    s.push_zeros(7);
    cases.push(("raw run count cut short", s.finish_segment()));

    // A raw-byte run (distance 0) announcing 1 byte, with the stream ending
    // before the padding bits that align the run to a byte boundary.
    let mut s = BitBuf::new();
    s.push_bits(&TOKEN_MATCH_SMALL);
    s.push_value(0, 5);
    s.push_value(1, 15);
    cases.push(("raw run padding cut short", s.finish_segment()));

    // A raw-byte run (distance 0) announcing 100 bytes, followed by 3.
    let mut s = BitBuf::new();
    s.push_bits(&TOKEN_MATCH_SMALL);
    s.push_value(0, 5);
    s.push_value(100, 15);
    s.align();
    s.push_raw_bytes(&[0x41, 0x42, 0x43]);
    cases.push(("raw run cut short", s.finish_segment()));

    for (label, segment) in &cases {
        eprintln!("case: {label}");
        assert!(
            single_segment_is_rejected(segment),
            "{label}: a segment that ends mid-token must be a decode error",
        );
    }
}

#[test]
fn multipart_segment_size_past_buffer_is_error_not_panic() {
    // Multipart frame: 1 segment, declared uncompressedSize 0, segment size
    // 0x7FFF_FFFF, but no segment payload follows.
    let mut frame = vec![DESC_MULTIPART];
    frame.extend_from_slice(&1u16.to_le_bytes()); // segment_count = 1
    frame.extend_from_slice(&0u32.to_le_bytes()); // uncompressedSize = 0
    frame.extend_from_slice(&0x7FFF_FFFFu32.to_le_bytes()); // segment size, no data

    let mut decompressor = Decompressor::new();
    let mut output = Vec::new();
    let result = decode(&mut decompressor, &frame, &mut output);

    assert!(
        result.is_err(),
        "a multipart segment size past the end of the buffer must error, not panic",
    );
}

// ---------------------------------------------------------------------------
// Out-of-range match distances and length widths are rejected, no panic
// ---------------------------------------------------------------------------

#[test]
fn match_distance_beyond_history_is_error_not_panic() {
    // Match distances past the 2.5 MB sliding window: one just past it
    // (2_614_240) and one far past it (~17 MiB, the farthest token).
    let mut just_past = BitBuf::new();
    just_past.push_bits(&TOKEN_MATCH_21BIT);
    just_past.push_value(2_614_240 - TOKEN_MATCH_21BIT_BASE, 21);
    just_past.push_zeros(1); // length prefix: single 0 bit -> length == 3

    let mut far_past = BitBuf::new();
    far_past.push_bits(&TOKEN_MATCH_FARTHEST);
    far_past.push_zeros(24); // 24-bit distance value = 0 -> distance = base
    far_past.push_zeros(1);

    for (label, seg) in [("just past the window", just_past), ("far past the window", far_past)] {
        eprintln!("case: {label}");
        assert!(
            single_segment_is_rejected(&seg.finish_segment()),
            "{label}: a match distance past the history window must error, not panic",
        );
    }
}

#[test]
fn oversized_length_token_width_is_error_not_panic() {
    // A match (distance 1) followed by a run of ones for the length prefix and
    // its terminating zero, with the stream ending there. A width of 63 is the
    // first whose length (2^64 plus the value) does not fit a 64-bit integer.
    for width in [63, 64, 65] {
        let mut seg = BitBuf::new();
        seg.push_bits(&TOKEN_MATCH_SMALL);
        seg.push_bits(&[0, 0, 0, 0, 1]); // 5-bit distance value = 1
        seg.push_ones(width);
        seg.push_zeros(1);
        let frame = single_compressed_frame(&seg.finish_segment());

        let mut decompressor = Decompressor::new();
        let mut output = Vec::new();
        let result = decode(&mut decompressor, &frame, &mut output);

        assert!(
            result.is_err(),
            "width {width}: an out-of-range match-length token width must error, not overflow/panic",
        );
    }
}

#[test]
fn oversized_length_token_width_with_full_payload_is_error_not_panic() {
    // The same length prefixes, but this time every value bit each one calls
    // for (width + 1) is present, so the stream is not short. At width 63 the
    // 64 value bits still load into a 64-bit integer, but the length they
    // name does not fit one.
    for width in [63, 64, 65] {
        let mut seg = BitBuf::new();
        seg.push_bits(&TOKEN_MATCH_SMALL);
        seg.push_value(1, 5);
        seg.push_ones(width);
        seg.push_zeros(1);
        seg.push_zeros(width + 1);
        let frame = single_compressed_frame(&seg.finish_segment());

        let mut decompressor = Decompressor::new();
        let mut output = Vec::new();
        let result = decode(&mut decompressor, &frame, &mut output);

        assert!(
            result.is_err(),
            "width {width}: a match length too large for any integer must error, not overflow/panic",
        );
    }
}

// ---------------------------------------------------------------------------
// Oversized messages are refused before their full expansion is allocated
// ---------------------------------------------------------------------------

#[test]
fn single_segment_match_bomb_is_refused_with_bounded_memory() {
    // A Single PDU of a few bytes holding one match token (distance 4096, which
    // lies inside the zero-initialised window) whose length is 3.5 GiB.
    const LENGTH_EXPONENT: usize = 31; // length = 2^31 + 2^30 + 2^29 = 3.5 GiB
    let mut seg = BitBuf::new();
    seg.push_bits(&TOKEN_MATCH_12BIT);
    seg.push_value(4096 - TOKEN_MATCH_12BIT_BASE, 12);
    seg.push_ones(LENGTH_EXPONENT - 1);
    seg.push_zeros(1);
    seg.push_value((1 << 30) + (1 << 29), LENGTH_EXPONENT);
    let frame = single_compressed_frame(&seg.finish_segment());

    assert_refused_with_bounded_memory("single-segment match bomb", &frame);
}

#[test]
fn single_segment_of_many_ordinary_matches_is_refused_with_bounded_memory() {
    // A Single PDU (about 300 KB) of 56_000 match tokens, each copying 65_535
    // bytes from distance 4096: no single match is larger than what a
    // conforming compressor emits, but together they expand to ~3.4 GiB.
    const MATCH_COUNT: usize = 56_000;
    let mut seg = BitBuf::new();
    for _ in 0..MATCH_COUNT {
        seg.push_bits(&TOKEN_MATCH_12BIT);
        seg.push_value(4096 - TOKEN_MATCH_12BIT_BASE, 12);
        // length 65_535 = 2^15 + 32_767: 14 ones, a zero, then 15 value bits
        seg.push_ones(14);
        seg.push_zeros(1);
        seg.push_value(32_767, 15);
    }
    let frame = single_compressed_frame(&seg.finish_segment());

    assert_refused_with_bounded_memory("many-matches single-segment bomb", &frame);
}

#[test]
fn decompression_bomb_keeps_peak_memory_bounded_and_errors() {
    // 60 copies of one compressed segment that expands to 60 MiB of repetitive
    // data (~3.5 GiB in total, a small frame on the wire). The declared
    // uncompressedSize is 50 MB, so the declared size and the real expansion
    // disagree from the first segment on, and an up-front check of the declared
    // size alone does not refuse the frame.
    const PER_SEGMENT: usize = 60 * MIB;
    const SEGMENT_COUNT: u16 = 60;
    const DECLARED_TOTAL: u32 = 50_000_000;

    let raw = vec![0xABu8; PER_SEGMENT];
    let mut compressor = Compressor::new();
    let compressed = compressor
        .compress(&raw)
        .expect("compressing a repetitive buffer should succeed");
    drop(raw);

    let frame = multipart_frame(&compressed, SEGMENT_COUNT, DECLARED_TOTAL);
    assert_refused_with_bounded_memory("large-segment bomb", &frame);
}

#[test]
fn decompression_bomb_many_small_segments_exceeds_aggregate_ceiling() {
    // 3600 copies of one compressed segment that expands to 1 MiB, with the
    // declared uncompressedSize equal to the full 3600 MiB the frame would
    // produce. Each segment on its own is modest; the message as a whole is
    // not, and the declared size agrees with the real expansion, so it gives
    // no hint that anything is wrong.
    const PER_SEGMENT: usize = MIB;
    const SEGMENT_COUNT: u16 = 3600;

    let raw = vec![0xCDu8; PER_SEGMENT];
    let mut compressor = Compressor::new();
    let compressed = compressor
        .compress(&raw)
        .expect("compressing a repetitive buffer should succeed");

    let declared_total =
        u32::try_from(PER_SEGMENT * usize::from(SEGMENT_COUNT)).expect("3600 MiB fits in u32");

    let frame = multipart_frame(&compressed, SEGMENT_COUNT, declared_total);
    assert_refused_with_bounded_memory("many-small-segments bomb", &frame);
}

// ---------------------------------------------------------------------------
// Conforming traffic still round-trips byte for byte
// ---------------------------------------------------------------------------

fn assert_round_trips(data: &[u8], mode: CompressionMode) {
    let mut compressor = Compressor::new();
    let wrapped = compress_and_wrap_egfx(data, &mut compressor, mode).expect("compress_and_wrap_egfx should succeed");

    let mut decompressor = Decompressor::new();
    let mut output = Vec::new();
    let written = decode(&mut decompressor, &wrapped, &mut output)
        .expect("decompressing valid compressor output must succeed");

    assert_eq!(output.as_slice(), data, "round-trip mismatch for mode {mode:?}");
    assert_eq!(written, data.len(), "reported byte count mismatch for mode {mode:?}");
}

#[test]
fn valid_messages_round_trip_all_modes() {
    let payloads: &[&[u8]] = &[
        b"",
        b"Test data with some repetition: AAAA BBBB CCCC",
        b"The quick brown fox jumps over the lazy dog",
    ];
    for payload in payloads {
        for mode in [CompressionMode::Never, CompressionMode::Auto, CompressionMode::Always] {
            assert_round_trips(payload, mode);
        }
    }
}

#[test]
fn valid_message_with_larger_mixed_payload_round_trips() {
    // A payload mixing repetition (match tokens) and varied bytes (literals),
    // large enough to span several segments.
    let mut data = Vec::new();
    for i in 0..4096u32 {
        data.extend_from_slice(b"frame-");
        data.extend_from_slice(&i.to_le_bytes());
        data.extend_from_slice(b"-REPEATREPEATREPEAT");
    }
    assert_round_trips(&data, CompressionMode::Always);
    assert_round_trips(&data, CompressionMode::Auto);
}

/// `type_and_flags` byte for an RDP8 segment sent uncompressed (0x04).
const UNCOMPRESSED_RDP8: u8 = 0x04;

#[test]
fn valid_streams_this_crate_never_emits_still_decode() {
    // Conforming messages another encoder can send but this crate's own
    // compressor never produces. Each must decode to exactly the expected bytes.

    // A raw-byte run (distance 0): count 3, padding to the byte boundary, "ABC".
    let raw_run = {
        let mut s = BitBuf::new();
        s.push_bits(&TOKEN_MATCH_SMALL);
        s.push_value(0, 5);
        s.push_value(3, 15);
        s.align();
        s.push_raw_bytes(b"ABC");
        s.finish_segment()
    };
    let mut decompressor = Decompressor::new();
    let mut output = Vec::new();
    decode(&mut decompressor, &single_compressed_frame(&raw_run), &mut output).expect("a raw-byte run must decode");
    assert_eq!(output.as_slice(), b"ABC", "raw-byte run");

    // The same raw run as each of 20 segments in one multipart message.
    let frame = multipart_frame(&raw_run, 20, 60);
    let mut decompressor = Decompressor::new();
    let mut output = Vec::new();
    decode(&mut decompressor, &frame, &mut output).expect("a 20-segment multipart message must decode");
    assert_eq!(output, b"ABC".repeat(20), "20-segment multipart message");

    // A match reaching 100,000 bytes back, inside the 2.5 MB window: one
    // multipart message whose first segment is 100,000 uncompressed bytes and
    // whose second copies the first 3 of them.
    let history: Vec<u8> = (0..100_000u32).map(|i| u8::try_from(i * 7 % 251).expect("below 251")).collect();
    let far_match = {
        let mut s = BitBuf::new();
        s.push_bits(&[1, 0, 1, 1, 1, 0, 0]); // distance base 54,944, 18 value bits
        s.push_value(100_000 - 54_944, 18);
        s.push_zeros(1); // length 3
        s.finish_segment()
    };
    let mut frame = vec![DESC_MULTIPART];
    frame.extend_from_slice(&2u16.to_le_bytes());
    frame.extend_from_slice(&100_003u32.to_le_bytes());
    frame.extend_from_slice(&u32::try_from(history.len() + 1).expect("fits").to_le_bytes());
    frame.push(UNCOMPRESSED_RDP8);
    frame.extend_from_slice(&history);
    frame.extend_from_slice(&u32::try_from(far_match.len() + 1).expect("fits").to_le_bytes());
    frame.push(COMPRESSED_RDP8);
    frame.extend_from_slice(&far_match);
    let mut decompressor = Decompressor::new();
    let mut output = Vec::new();
    decode(&mut decompressor, &frame, &mut output).expect("a match 100,000 bytes back must decode");
    assert_eq!(output.len(), 100_003, "far match: output length");
    assert_eq!(&output[100_000..], &history[..3], "far match: copied bytes");

    // History carries over between messages on one decoder: an uncompressed
    // "hello world", then a second message copying "hello" from 11 bytes back.
    let mut decompressor = Decompressor::new();
    let mut first = vec![DESC_SINGLE, UNCOMPRESSED_RDP8];
    first.extend_from_slice(b"hello world");
    let mut output = Vec::new();
    decode(&mut decompressor, &first, &mut output).expect("an uncompressed message must decode");
    assert_eq!(output.as_slice(), b"hello world", "first message");
    let back_reference = {
        let mut s = BitBuf::new();
        s.push_bits(&TOKEN_MATCH_SMALL);
        s.push_value(11, 5);
        s.push_bits(&[1, 0, 0, 1]); // length 4 + 1 = 5
        s.finish_segment()
    };
    let mut output = Vec::new();
    decode(&mut decompressor, &single_compressed_frame(&back_reference), &mut output)
        .expect("a match into the previous message must decode");
    assert_eq!(output.as_slice(), b"hello", "match into the previous message");
}

#[test]
fn single_pdu_with_reserved_trailer_bits_decodes_or_errors_without_panic() {
    // MS-RDPEGFX 3.1.9.1.2.4 reserves the five high-order bits of the trailer
    // byte; only the low three are the unused-bit count. With the reserved bits
    // clear each stream must decode to its expected bytes. With them set, a
    // decode error is acceptable, as is the same output; a panic or different
    // output is not.
    //   `1100_1000` + trailer 3: one 0x01 literal.
    //   `0011_0010 1100_0100 0011_0000` + trailer 1: a 0x65 null literal and a
    //   distance-1 match, five 0x65 bytes in all.
    let streams: [(&[u8], u8, &[u8]); 2] = [
        (&[0b1100_1000], 0x03, &[0x01]),
        (&[0b0011_0010, 0b1100_0100, 0b0011_0000], 0x01, &[0x65; 5]),
    ];
    for (data, unused, expected) in streams {
        for reserved in [0u8, 0b1010_0000, 0b1111_1000] {
            let mut segment = data.to_vec();
            segment.push(unused | reserved);
            let frame = single_compressed_frame(&segment);

            let mut decompressor = Decompressor::new();
            let mut output = Vec::new();
            match decode(&mut decompressor, &frame, &mut output) {
                Ok(_) => assert_eq!(
                    output.as_slice(),
                    expected,
                    "trailer {:#04x}: a successful decode must produce the expected bytes",
                    unused | reserved,
                ),
                Err(e) => assert!(
                    reserved != 0,
                    "trailer {:#04x} has no reserved bits set and must decode, got {e:?}",
                    unused | reserved,
                ),
            }
        }
    }
}
