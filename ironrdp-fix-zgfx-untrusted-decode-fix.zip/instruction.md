## Task

Malformed compressed graphics updates from a remote RDP server can crash or hang our client. Some updates aren't damaged at all, just enormous once decoded, and they use up all its memory. Instead of going down, the client should surface a protocol error, and no single update should need more than about a gigabyte. Servers that work today still need to work.
