## Task

Malformed compressed graphics updates from a remote RDP server can crash or hang our client, sometimes after it has used up all its memory. Instead of going down, the client should surface a protocol error. Some servers that follow the spec also trigger decode failures that shouldn't happen. Servers that work today still need to work.
