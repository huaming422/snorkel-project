## Task

Connecting to an untrusted RDP server can crash or hang our client while it is drawing the remote desktop. It happens with the server's compressed graphics updates: a damaged update can take the whole process down, and a small one can push memory use into the gigabytes. Some servers also have their updates refused when the only unusual thing about them is bits the spec reserves. Nobody should have to worry about any of this when they connect.
