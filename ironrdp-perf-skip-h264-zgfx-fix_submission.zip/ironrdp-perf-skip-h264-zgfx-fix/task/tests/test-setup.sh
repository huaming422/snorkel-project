#!/usr/bin/env bash
# No services to start, no data to seed: the image pre-warms the cargo
# registry/git caches and builds the workspace --tests at the base commit,
# so the verifier compiles a single integration test against a warm target
# dir with no network. This script only reports the toolchain it will use.
set -euo pipefail

echo "[test-setup] Rust version:    $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:   $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root:  /repo/ironrdp"
echo "[test-setup] Setup complete."
