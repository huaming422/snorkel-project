//! Integration test for the EGFX server's ZGFX output path, exercised only
//! through the crate's pre-existing public API: `GraphicsPipelineServer`,
//! its `with_compression` constructor, the `send_*_frame` queueing methods,
//! `drain_output`, and the public `zgfx::Decompressor`. Nothing here imports
//! or names any internal helper the send path may use; the behavior is
//! observed from the wire bytes a receiver would see, so any implementation
//! that produces the right bytes passes.
//!
//! What a receiver observes, and what these tests assert:
//!
//!   1. In a compressing mode, an H.264 surface command (AVC420, AVC444, or
//!      AVC444v2) leaves the server with its first ZGFX segment NOT carrying
//!      the PACKET_COMPRESSED flag, while ordinary ClearCodec tiles in the
//!      same session still do.
//!
//!   2. The receiver decodes the full ClearCodec / H.264 / ClearCodec
//!      sequence with a single `Decompressor`, and the trailing ClearCodec
//!      round-trips to the original bytes. That only holds if the bytes sent
//!      uncompressed were still entered into the sender's history, because
//!      the receiver records every segment and a later back-reference points
//!      across them (MS-RDPEGFX 3.1.9.1.2).
//!
//!   3. Both properties hold for all three H.264 codecs and for a payload
//!      that fits one ZGFX segment and one that spans several.
//!
//!   4. In Auto mode the same sequence round-trips, so the pre-existing
//!      compressing and plain paths keep working.
//!
//! The helpers (`TestHandler`, `encode_pdu`, `first_segment_is_compressed`)
//! are inlined because the crate's own testsuite lives in a sibling crate
//! whose dev-dependencies are not on this test target's path.

use ironrdp_core::{Decode as _, Encode, ReadCursor, WriteCursor, encode_vec};
use ironrdp_dvc::DvcProcessor as _;
use ironrdp_egfx::pdu::{
    Avc420Region, CapabilitiesAdvertisePdu, CapabilitiesV10Flags, CapabilitySet, Codec1Type, Encoding, GfxPdu,
};
use ironrdp_egfx::server::{GraphicsPipelineHandler, GraphicsPipelineServer};
use ironrdp_graphics::zgfx::{CompressionMode, Decompressor};
use ironrdp_pdu::geometry::ExclusiveRectangle;

// ---------------------------------------------------------------------------
// Inlined test helpers.
// ---------------------------------------------------------------------------

/// Minimal handler; the server drives negotiation on its own, so the callbacks
/// need no behavior for these tests.
struct TestHandler;

impl GraphicsPipelineHandler for TestHandler {
    fn capabilities_advertise(&mut self, _pdu: &CapabilitiesAdvertisePdu) {}
    fn on_ready(&mut self, _negotiated: &CapabilitySet) {}
}

/// Encode a PDU to bytes for feeding the server's `process()` method.
fn encode_pdu<T: Encode>(pdu: &T) -> Vec<u8> {
    let mut buf = vec![0u8; pdu.size()];
    let mut cursor = WriteCursor::new(&mut buf);
    pdu.encode(&mut cursor).expect("encode failed");
    buf
}

/// Whether the first ZGFX segment of a wrapped DVC message carries the
/// PACKET_COMPRESSED flag (MS-RDPEGFX 2.2.5.1 to 2.2.5.3; PACKET_COMPRESSED
/// is 0x20 in the segment flags byte). A single-part descriptor is 0xE0 with
/// the flags byte at offset 1; a multipart descriptor is 0xE1 followed by a
/// u16 segment count and a u32 uncompressed size, putting the first segment's
/// flags byte at offset 1 + 2 + 4 + 4.
fn first_segment_is_compressed(wrapped: &[u8]) -> bool {
    match wrapped[0] {
        0xE0 => wrapped[1] & 0x20 != 0,
        0xE1 => wrapped[1 + 2 + 4 + 4] & 0x20 != 0,
        descriptor => panic!("unexpected ZGFX descriptor {descriptor:#x}"),
    }
}

/// Deterministic, highly repetitive bytes that stand in for a lossless tile;
/// they compress well so a compressing mode marks them compressed.
fn clearcodec_bytes() -> Vec<u8> {
    b"lossless tile bytes that repeat ".repeat(64)
}

/// Deterministic bytes standing in for an H.264 payload of a given length.
fn h264_bytes(len: usize) -> Vec<u8> {
    (0..=u8::MAX).cycle().skip(3).step_by(7).take(len).collect()
}

/// Queue one H.264 frame of the requested codec on `surface_id`.
fn send_h264(
    server: &mut GraphicsPipelineServer,
    codec: Codec1Type,
    surface_id: u16,
    data: &[u8],
    regions: &[Avc420Region],
) -> Option<u32> {
    match codec {
        Codec1Type::Avc420 => server.send_avc420_frame(surface_id, data, regions, 42),
        Codec1Type::Avc444 => server.send_avc444_frame(surface_id, data, regions, None, None, 42),
        Codec1Type::Avc444v2 => {
            server.send_avc444v2_frame(surface_id, Encoding::LUMA, data, regions, None, None, 42)
        }
        other => panic!("not an H.264 codec: {other:?}"),
    }
}

/// A decoded WireToSurface1 observation: whether its first ZGFX segment was
/// compressed, which codec it carried, and the decoded bitmap bytes.
struct Observed {
    compressed: bool,
    codec_id: Codec1Type,
    bitmap_data: Vec<u8>,
}

/// Run the ClearCodec / H.264 / ClearCodec sequence end to end under `mode`
/// with the given H.264 `codec` and payload length, decoding the whole
/// drained stream with a single receiver-side `Decompressor`. Returns the
/// WireToSurface1 PDUs observed, in order.
///
/// A single `Decompressor` across the whole session is the crux: the receiver
/// records every segment it sees, so the trailing ClearCodec only decodes if
/// the sender recorded the intervening H.264 bytes too.
fn run_sequence(mode: CompressionMode, codec: Codec1Type, h264_len: usize) -> Vec<Observed> {
    let mut server = GraphicsPipelineServer::with_compression(Box::new(TestHandler), mode);

    let caps = GfxPdu::CapabilitiesAdvertise(CapabilitiesAdvertisePdu::from_typed(&[CapabilitySet::V10 {
        flags: CapabilitiesV10Flags::SMALL_CACHE,
    }]));
    server.process(0, &encode_pdu(&caps)).expect("process capabilities");

    let surface_id = server.create_surface(64, 64).expect("create surface");

    let mut decompressor = Decompressor::new();
    let mut decode_all = |server: &mut GraphicsPipelineServer| -> Vec<Observed> {
        server
            .drain_output()
            .iter()
            .filter_map(|message| {
                let wrapped = encode_vec(message.as_ref()).expect("encode DVC message");
                let compressed = first_segment_is_compressed(&wrapped);
                let mut decoded = Vec::new();
                decompressor
                    .decompress(&wrapped, &mut decoded)
                    .expect("receiver decompress");
                let pdu = GfxPdu::decode(&mut ReadCursor::new(&decoded)).expect("decode PDU");
                match pdu {
                    GfxPdu::WireToSurface1(wire) => Some(Observed {
                        compressed,
                        codec_id: wire.codec_id,
                        bitmap_data: wire.bitmap_data,
                    }),
                    _ => None,
                }
            })
            .collect()
    };

    // Drain the handshake output (ResetGraphics, caps confirm, etc.) through
    // the same decompressor so its history matches the sender from the start.
    decode_all(&mut server);

    let clearcodec_data = clearcodec_bytes();
    let h264_data = h264_bytes(h264_len);
    let destination = ExclusiveRectangle {
        left: 0,
        top: 0,
        right: 16,
        bottom: 16,
    };
    let regions = [Avc420Region::full_frame(64, 64, 22)];

    server
        .send_clearcodec_frame(surface_id, destination.clone(), clearcodec_data.clone(), 42)
        .expect("queue first ClearCodec frame");
    send_h264(&mut server, codec, surface_id, &h264_data, &regions).expect("queue H.264 frame");
    server
        .send_clearcodec_frame(surface_id, destination, clearcodec_data, 42)
        .expect("queue second ClearCodec frame");

    decode_all(&mut server)
}

/// Assert the shape of the sequence: exactly ClearCodec, then the H.264 codec,
/// then ClearCodec, and both ClearCodec tiles round-trip to the original
/// bytes. Shared by the tests below.
fn assert_sequence_roundtrips(observed: &[Observed], codec: Codec1Type) {
    let codecs: Vec<Codec1Type> = observed.iter().map(|o| o.codec_id).collect();
    assert_eq!(
        codecs,
        [Codec1Type::ClearCodec, codec, Codec1Type::ClearCodec],
        "expected the ClearCodec / H.264 / ClearCodec order to survive the round trip"
    );

    let expected = clearcodec_bytes();
    // The trailing ClearCodec is the telling one: it can only decode to the
    // original bytes if the H.264 bytes were recorded in the sender history,
    // because the receiver recorded them and a back-reference spans them.
    assert_eq!(
        observed[2].bitmap_data, expected,
        "the ClearCodec PDU sent after the H.264 PDU must round-trip to the original bytes; \
         a mismatch means the sender and receiver histories drifted out of step across the \
         H.264 payload"
    );
    assert_eq!(
        observed[0].bitmap_data, expected,
        "the ClearCodec PDU sent before the H.264 PDU must round-trip to the original bytes"
    );
}

// ---------------------------------------------------------------------------
// H.264 goes out uncompressed in Always mode while ClearCodec is still
// compressed.
// ---------------------------------------------------------------------------

#[test]
fn h264_uncompressed_in_always() {
    let observed = run_sequence(CompressionMode::Always, Codec1Type::Avc420, 8_000);

    assert_eq!(
        observed.len(),
        3,
        "expected ClearCodec, H.264, ClearCodec (3 surface commands)"
    );

    for o in &observed {
        match o.codec_id {
            Codec1Type::ClearCodec => assert!(
                o.compressed,
                "ordinary ClearCodec tiles should still be compressed in Always mode"
            ),
            Codec1Type::Avc420 => assert!(
                !o.compressed,
                "the H.264 surface command should be placed on the wire uncompressed \
                 (ZGFX PACKET_COMPRESSED clear) in Always mode"
            ),
            other => panic!("unexpected codec {other:?}"),
        }
    }
}

// ---------------------------------------------------------------------------
// The H.264 bytes are kept in the sender history, so a later back-referencing
// ClearCodec decodes correctly on the receiver.
// ---------------------------------------------------------------------------

#[test]
fn history_in_step_after_h264() {
    // Always mode, single-part H.264: every PDU must decode under one
    // Decompressor and the trailing ClearCodec must round-trip.
    let observed = run_sequence(CompressionMode::Always, Codec1Type::Avc420, 8_000);
    assert_sequence_roundtrips(&observed, Codec1Type::Avc420);
}

// ---------------------------------------------------------------------------
// Holds for every H.264 codec and for both a single-segment and a multipart
// payload.
// ---------------------------------------------------------------------------

#[test]
fn h264_all_codecs_and_multipart() {
    // 8,000 bytes fits one ZGFX segment; 70,000 bytes exceeds the 65,535-byte
    // ceiling and exercises the multipart recording path.
    for codec in [Codec1Type::Avc420, Codec1Type::Avc444, Codec1Type::Avc444v2] {
        for &h264_len in &[8_000usize, 70_000usize] {
            let observed = run_sequence(CompressionMode::Always, codec, h264_len);

            // Uncompressed-send property for the H.264 command.
            let h264_obs = observed
                .iter()
                .find(|o| o.codec_id == codec)
                .unwrap_or_else(|| panic!("no H.264 PDU observed for {codec:?} at len {h264_len}"));
            assert!(
                !h264_obs.compressed,
                "the H.264 surface command ({codec:?}, {h264_len} bytes) should be sent \
                 uncompressed in Always mode"
            );

            // History-in-step property across the payload size and codec.
            assert_sequence_roundtrips(&observed, codec);
        }
    }
}

// ---------------------------------------------------------------------------
// A burst of several H.264 commands back to back, with ClearCodec tiles that
// back-reference content from before the burst, still round-trips. Every H.264
// command in the run must be recorded in the sender history, not just one: the
// trailing ClearCodec tiles resolve back-references that span the whole burst,
// and a single un-recorded H.264 payload anywhere in the run shifts the two
// histories by its length and corrupts the next back-referencing tile.
// ---------------------------------------------------------------------------

/// One queued frame in a mixed sequence: an ordinary ClearCodec tile, or an
/// H.264 frame of a given codec and payload length.
enum Frame {
    ClearCodec,
    H264(Codec1Type, usize),
}

/// Drive `frames` through a fresh server in `mode`, decoding the whole drained
/// stream (handshake included) with a single receiver-side `Decompressor`, and
/// return the observed WireToSurface1 PDUs in order. Same contract as
/// `run_sequence`, but the caller supplies an arbitrary frame list so a long
/// run of consecutive H.264 commands can be exercised.
fn run_frames(mode: CompressionMode, frames: &[Frame]) -> Vec<Observed> {
    let mut server = GraphicsPipelineServer::with_compression(Box::new(TestHandler), mode);

    // Lift the frames-in-flight backpressure so a long burst of frames can be
    // queued before draining; this run submits more frames than the default
    // acknowledgement window and never acknowledges them.
    server.set_max_frames_in_flight(0);

    let caps = GfxPdu::CapabilitiesAdvertise(CapabilitiesAdvertisePdu::from_typed(&[CapabilitySet::V10 {
        flags: CapabilitiesV10Flags::SMALL_CACHE,
    }]));
    server.process(0, &encode_pdu(&caps)).expect("process capabilities");

    let surface_id = server.create_surface(64, 64).expect("create surface");

    let mut decompressor = Decompressor::new();
    let mut decode_all = |server: &mut GraphicsPipelineServer| -> Vec<Observed> {
        server
            .drain_output()
            .iter()
            .filter_map(|message| {
                let wrapped = encode_vec(message.as_ref()).expect("encode DVC message");
                let compressed = first_segment_is_compressed(&wrapped);
                let mut decoded = Vec::new();
                decompressor
                    .decompress(&wrapped, &mut decoded)
                    .expect("receiver decompress");
                let pdu = GfxPdu::decode(&mut ReadCursor::new(&decoded)).expect("decode PDU");
                match pdu {
                    GfxPdu::WireToSurface1(wire) => Some(Observed {
                        compressed,
                        codec_id: wire.codec_id,
                        bitmap_data: wire.bitmap_data,
                    }),
                    _ => None,
                }
            })
            .collect()
    };

    // Drain the handshake through the same decompressor so its history matches
    // the sender from the start.
    decode_all(&mut server);

    let destination = ExclusiveRectangle {
        left: 0,
        top: 0,
        right: 16,
        bottom: 16,
    };
    let regions = [Avc420Region::full_frame(64, 64, 22)];

    for frame in frames {
        match *frame {
            Frame::ClearCodec => {
                server
                    .send_clearcodec_frame(surface_id, destination.clone(), clearcodec_bytes(), 42)
                    .expect("queue ClearCodec frame");
            }
            Frame::H264(codec, len) => {
                send_h264(&mut server, codec, surface_id, &h264_bytes(len), &regions)
                    .expect("queue H.264 frame");
            }
        }
    }

    decode_all(&mut server)
}

#[test]
fn history_in_step_across_consecutive_h264() {
    // A ClearCodec anchor, then several H.264 commands back to back mixing all
    // three codecs and both single-part (8,000 B) and multipart (70,000 B)
    // payloads, then a ClearCodec that back-references across the whole burst,
    // then one more H.264 command, then a final ClearCodec that back-references
    // across two separate H.264 regions. Every ClearCodec can only decode to the
    // original bytes if every intervening H.264 payload was recorded in the
    // sender history exactly as the receiver recorded it.
    let frames = [
        Frame::ClearCodec,
        Frame::H264(Codec1Type::Avc420, 8_000),
        Frame::H264(Codec1Type::Avc444, 70_000),
        Frame::H264(Codec1Type::Avc444v2, 8_000),
        Frame::H264(Codec1Type::Avc420, 70_000),
        Frame::ClearCodec,
        Frame::H264(Codec1Type::Avc444, 8_000),
        Frame::ClearCodec,
    ];

    let observed = run_frames(CompressionMode::Always, &frames);

    let expected_codecs = [
        Codec1Type::ClearCodec,
        Codec1Type::Avc420,
        Codec1Type::Avc444,
        Codec1Type::Avc444v2,
        Codec1Type::Avc420,
        Codec1Type::ClearCodec,
        Codec1Type::Avc444,
        Codec1Type::ClearCodec,
    ];
    let codecs: Vec<Codec1Type> = observed.iter().map(|o| o.codec_id).collect();
    assert_eq!(
        codecs,
        expected_codecs,
        "the ClearCodec / H.264-burst / ClearCodec order must survive the round trip"
    );

    let expected_tile = clearcodec_bytes();
    for o in &observed {
        match o.codec_id {
            Codec1Type::ClearCodec => {
                assert!(
                    o.compressed,
                    "ordinary ClearCodec tiles should still be compressed in Always mode"
                );
                assert_eq!(
                    o.bitmap_data, expected_tile,
                    "a ClearCodec tile failed to round-trip; the sender and receiver histories \
                     drifted out of step across the H.264 burst, which means at least one H.264 \
                     payload was sent uncompressed without recording its bytes"
                );
            }
            Codec1Type::Avc420 | Codec1Type::Avc444 | Codec1Type::Avc444v2 => assert!(
                !o.compressed,
                "every H.264 surface command in the burst ({:?}) should be sent uncompressed \
                 in Always mode",
                o.codec_id
            ),
            other => panic!("unexpected codec {other:?}"),
        }
    }
}

// ---------------------------------------------------------------------------
// Auto mode still round-trips the full sequence.
// ---------------------------------------------------------------------------

#[test]
fn modes_preserved_auto_never() {
    // Both compressing Auto and plain Never must decode the full sequence and
    // round-trip the trailing ClearCodec, before and after the change. Never
    // sends every segment uncompressed and records nothing; Auto compresses
    // what wins. Neither is the mode the change targets, so both guard the
    // pre-existing paths against collateral damage.
    for mode in [CompressionMode::Auto, CompressionMode::Never] {
        for codec in [Codec1Type::Avc420, Codec1Type::Avc444, Codec1Type::Avc444v2] {
            let observed = run_sequence(mode, codec, 8_000);
            assert_sequence_roundtrips(&observed, codec);
        }
    }
}
