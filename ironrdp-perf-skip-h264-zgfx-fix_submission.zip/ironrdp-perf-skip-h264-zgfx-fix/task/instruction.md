## Task

when ZGFX compression is turned on, the EGFX server runs every surface command it's about to send through the compressor before it goes on the wire. that's worth it for ordinary tiles, but it also happens to H.264 surface commands, and H.264 is already entropy coded, so the compressor almost never shrinks those and mostly just burns CPU on the send path.

can we stop paying that cost for H.264? when compression is enabled, H.264 surface commands should go out without being run through the compressor, while the other tiles in the same session keep getting compressed exactly as they do today. this is only about the send side, so leave the non-H.264 tiles and the existing compression modes behaving exactly as they do now.
