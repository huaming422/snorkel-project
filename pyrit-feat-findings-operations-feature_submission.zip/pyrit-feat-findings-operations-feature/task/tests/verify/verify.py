# Copyright (c) Microsoft Corporation.
# Licensed under the MIT license.

"""Behavioral verifier for pyrit-feat-findings-operations.

This file is collected from ``/tests/verify/``, where the repository's own
``tests/unit`` conftest is NOT in scope. Every fixture below is therefore
self-contained — ``use_sqlite_memory`` and the backend compatibility/auth
fixtures are inlined rather than imported from ``test_support`` — so the
verifier depends only on installed ``pyrit`` package code, never on the repo's
test tree. ``verify.toml`` runs this through the repository's own interpreter
(``uv run pytest``) because the file imports ``pyrit.*``.

Scope — why this verifier couples ONLY to the operations root:

The task is a greenfield feature with a wide design space. The agent-facing
contract (instruction.md) dictates a small, stable surface: a router mounted
under the existing ``/api`` prefix with ``GET|POST /api/operations`` as its root,
the ``items`` list-envelope, the ``name`` resource field, the compatibility
header gate, operations with a case/whitespace-insensitive identity, and a name
length bound. Everything below that root — the per-operation finding sub-path,
the finding-create model shape and field names, the severity enum values, the
harm-category-listing surface, the evidence routes, the ORM/migration internals,
and the specific HTTP status codes — is SOLUTION-CHOSEN and varies across valid
implementations. Those behaviors are gated adaptively by the validation stories
(``finding_idempotent_create``, ``evidence_attach_transactional``,
``evidence_listing_resolution``, ``migration_backfill_and_merge``), which
discover each solution's routes/fields from the submitted patch and assert the
observable behavior.

This verifier therefore asserts only the operations-root behaviors that every
correct implementation must expose identically:

  * an operation's case/whitespace-insensitive identity (a case/space variant of
    an existing name does not create a second operation), through
    ``POST|GET /api/operations``;
  * the presence of a name length bound and rejection of a blank name, through
    ``POST /api/operations`` (asserting only that a bound exists — never its
    unit, value, or enforcement layer);
  * the compatibility-header gate on the ``/api`` surface.

Every test here fails on the nop baseline (the operations route does not exist)
and passes on any correct implementation regardless of its design choices below
the operations root.
"""

from __future__ import annotations

import asyncio
import tempfile
from contextlib import contextmanager
from unittest.mock import patch

import pytest

# Pre-existing, stable imports — present on the nop baseline too, so module
# collection never hard-errors.
from pyrit import _compatibility
from pyrit.backend.main import app
from pyrit.memory import SQLiteMemory

_IDENTITY = "0.14.0+g" + "a" * 40


# --------------------------------------------------------------------------- #
# Self-contained fixtures (mirrors tests/unit/conftest.py +                    #
# tests/unit/backend/conftest.py + test_support/fixtures.py, inlined).        #
# --------------------------------------------------------------------------- #
@contextmanager
def _use_sqlite_memory(mem: SQLiteMemory):
    """Bind CentralMemory and the SQLite singleton to a fixture-owned instance."""
    from pyrit.common.singleton import Singleton
    from pyrit.memory import CentralMemory

    previous = Singleton._instances.get(SQLiteMemory)
    Singleton._instances[SQLiteMemory] = mem
    try:
        with patch.object(CentralMemory, "_memory_instance", None):
            CentralMemory.set_memory_instance(mem)
            yield
    finally:
        if previous is None:
            Singleton._instances.pop(SQLiteMemory, None)
        else:
            Singleton._instances[SQLiteMemory] = previous


@pytest.fixture(scope="module")
def sqlite_instance():
    """A real, isolated SQLite-backed memory with the full schema migrated.

    Module-scoped: built and disposed exactly ONCE for the whole file. The
    in-memory SQLite engine is created and torn down a single time, so there is
    no per-test build/dispose churn of the aiosqlite connection pool — a build
    that registers its ORM tables once per process is therefore never left with
    a stale/closed engine between tests. Each test keys its data under its own
    operation names, so sharing one database across the handful of tests here is
    safe (assertions below scope to the names they create, never to row totals).
    """
    with tempfile.TemporaryDirectory() as results_path:
        mem = SQLiteMemory.__new__(SQLiteMemory)
        try:
            with patch.object(mem, "cleanup"):
                mem.__init__(db_path=":memory:", skip_schema_migration=False)
            mem.results_path = results_path
            mem.disable_embedding()
            with _use_sqlite_memory(mem):
                yield mem
        finally:
            try:
                asyncio.run(mem.dispose_engine_async())
            except Exception:
                pass


@pytest.fixture
def patch_central_database(sqlite_instance):
    """Route CentralMemory.get_memory_instance() at the shared instance."""
    from pyrit.memory import CentralMemory

    with patch.object(CentralMemory, "get_memory_instance", return_value=sqlite_instance) as m:
        yield m


@pytest.fixture(autouse=True)
def _compat_identity():
    """Supply startup provenance to clients that skip the app lifespan."""
    with (
        patch.object(_compatibility, "get_compatibility_id", return_value=_IDENTITY),
        patch.object(app.state, "compatibility_id", _IDENTITY, create=True),
    ):
        yield _IDENTITY


@pytest.fixture(autouse=True)
def _auth_policy():
    """Supply a local auth policy to the backend app."""
    from pyrit.backend.authentication_policy import AuthenticationPolicy

    policy = AuthenticationPolicy(mode="local")
    with patch.object(app.state, "authentication_policy", policy, create=True):
        yield policy


@pytest.fixture
def compat_headers() -> dict[str, str]:
    return {_compatibility.COMPATIBILITY_HEADER: _IDENTITY}


@pytest.fixture
def client(patch_central_database, compat_headers):
    """A FastAPI TestClient over the isolated memory, carrying the compat header."""
    from fastapi.testclient import TestClient

    return TestClient(app, headers=compat_headers)


# --------------------------------------------------------------------------- #
# Helpers that assert behavior without pinning solution-chosen shapes.         #
# --------------------------------------------------------------------------- #
def _create_operation(client, name: str):
    """POST a new operation; return the parsed body. Asserts a success status."""
    resp = client.post("/api/operations", json={"name": name})
    assert resp.status_code < 300, (
        f"Creating operation {name!r} should succeed; got {resp.status_code}: {resp.text[:300]}"
    )
    return resp.json()


def _list_envelope(body) -> list:
    """Return the list payload of a list response, tolerating the envelope key.

    ``items`` is the repo-wide pagination convention, but the exact key is a
    solution choice; fall back to the first list-valued entry so the test does
    not couple to the key name.
    """
    if isinstance(body, list):
        return body
    if isinstance(body, dict):
        if isinstance(body.get("items"), list):
            return body["items"]
        for value in body.values():
            if isinstance(value, list):
                return value
    return []


def _list_operations(client):
    """GET the operations list and return its payload items (key-tolerant)."""
    listing = client.get("/api/operations")
    assert listing.status_code == 200, f"{listing.status_code}: {listing.text[:300]}"
    return _list_envelope(listing.json())


# --------------------------------------------------------------------------- #
# operation_identity (behavioral_verifier, basic) — through the REST surface.  #
# --------------------------------------------------------------------------- #
def test_operation_identity_is_case_and_whitespace_insensitive(client):
    """A name differing only in case/whitespace denotes the SAME operation.

    Uses ASCII names where lower()/casefold()/NFC all agree, so any reasonable
    normalization passes. Creating "Red Team A" and then "  red team a  " must
    not yield a second operation: after both attempts the listing holds exactly
    one operation, carrying the canonical first name. (A case-sensitive or
    untrimmed implementation creates a duplicate row — two items — and fails;
    the specific conflict status code is a solution choice and is not pinned.)
    """
    first = _create_operation(client, "Red Team A")
    assert first["name"] == "Red Team A"

    # Second create of a case/whitespace variant — whatever it signals, it must
    # not produce a second distinct operation.
    client.post("/api/operations", json={"name": "  red team a  "})

    # Scope to just this test's identity: count how many listed operations share
    # the "red team a" case/whitespace identity. A correct implementation keeps
    # exactly one (carrying the canonical trimmed name); a case-sensitive or
    # untrimmed one creates a second row. The specific conflict status code on
    # the duplicate attempt is a solution choice and is not pinned.
    items = _list_operations(client)
    mine = [i for i in items if i.get("name", "").strip().casefold() == "red team a"]
    assert len(mine) == 1, (
        f"A case/whitespace variant of an existing name must not create a second "
        f"operation; saw {len(mine)} with the 'red team a' identity: "
        f"{[i.get('name') for i in mine]}"
    )
    assert mine[0]["name"] == "Red Team A", (
        f"The single surviving operation must carry the canonical trimmed name; "
        f"got {mine[0].get('name')!r}"
    )


# --------------------------------------------------------------------------- #
# name_bound (behavioral_verifier) — through the REST surface.                 #
# --------------------------------------------------------------------------- #
def test_operation_name_is_length_bounded(client):
    """A name length bound is enforced observably, via the REST root.

    The contract establishes that operation names have a length bound (the
    migration skips legacy names over it). This asserts only that a wildly
    over-length name is rejected — never the bound's unit, value, or enforcement
    layer, all of which are solution choices. A normal name is accepted first,
    so the rejection is attributable to the bound and not a broken route (and the
    positive branch is the nop discriminator: on nop there is no route, so even a
    normal create does not succeed).
    """
    ok = client.post("/api/operations", json={"name": "Ordinary Campaign"})
    assert ok.status_code < 300, (
        f"A normal operation name must be accepted; got {ok.status_code}: {ok.text[:300]}"
    )

    overlong = client.post("/api/operations", json={"name": "x" * 10000})
    assert overlong.status_code >= 400, (
        f"An operation name far over any reasonable length bound must be rejected; "
        f"got {overlong.status_code}: {overlong.text[:300]}"
    )


# --------------------------------------------------------------------------- #
# compatibility_gate (behavioral_verifier, basic) — through the TestClient.    #
# --------------------------------------------------------------------------- #
def test_business_request_requires_the_compatibility_header(patch_central_database):
    """The /api surface is gated by the compatibility header.

    With the header a create succeeds; without it the same request does NOT
    succeed. The positive branch is the nop discriminator (no route → not a
    success status); the negative branch pins the documented compat gate.
    """
    from fastapi.testclient import TestClient

    with_header = TestClient(app, headers={_compatibility.COMPATIBILITY_HEADER: _IDENTITY})
    ok = with_header.post("/api/operations", json={"name": "Gated"})
    assert ok.status_code < 300, (
        f"A create carrying the compatibility header must succeed; got {ok.status_code}: {ok.text[:300]}"
    )

    without_header = TestClient(app)
    gated = without_header.post("/api/operations", json={"name": "Ungated"})
    assert gated.status_code >= 300, (
        f"A business request without the compatibility header must not succeed; got {gated.status_code}"
    )
