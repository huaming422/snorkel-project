# Copyright (c) Microsoft Corporation.
# Licensed under the MIT license.

"""Validation conftest override for pyrit-feat-findings-operations.

The pytest driver auto-loads this file as a pytest plugin, so everything defined
here is visible to the story test files the driver runs.

It exposes ONE autouse, function-scoped fixture, ``_backend_env``, that
reproduces the pre-existing PyRIT test environment every story needs:

  * a fresh, isolated in-memory ``SQLiteMemory`` migrated to head, bound as the
    central memory singleton (so ``CentralMemory.get_memory_instance()`` — which
    the new routes/service resolve through — returns it), and recorded in
    ``test_harness._CURRENT`` so synchronous harness helpers can reach it;
  * the backend app's startup compatibility id and a local
    ``AuthenticationPolicy`` patched in, so ``TestClient`` business requests
    carrying the compatibility header are accepted.

All of this is pre-existing, stable PyRIT surface — the feature adds methods and
routes on top of it, not a new way to build or bind memory. Nothing here encodes
a solution-chosen name.

The migration story builds its OWN throwaway engine via
``test_harness.migration_engine`` and does not use the bound memory, but the
autouse fixture is harmless there (it just binds an unused in-memory DB).
"""

from __future__ import annotations

import sys

import pytest

sys.path.insert(0, "/tests/validate")

import test_harness as th  # noqa: E402


@pytest.fixture(autouse=True)
def _backend_env():
    """Bind an isolated SQLite memory + backend compat/auth for each test."""
    from unittest.mock import patch

    from pyrit import _compatibility
    from pyrit.backend.authentication_policy import AuthenticationPolicy
    from pyrit.backend.main import app

    mem = th.build_sqlite_memory()
    policy = AuthenticationPolicy(mode="local")
    try:
        with (
            th.use_sqlite_memory(mem),
            patch.object(_compatibility, "get_compatibility_id", return_value=th._IDENTITY),
            patch.object(app.state, "compatibility_id", th._IDENTITY, create=True),
            patch.object(app.state, "authentication_policy", policy, create=True),
        ):
            th._CURRENT["mem"] = mem
            yield mem
    finally:
        th._CURRENT["mem"] = None
        try:
            th.run(mem.dispose_engine_async())
        except Exception:
            pass
