# Copyright (c) Microsoft Corporation.
# Licensed under the MIT license.

"""Test harness for pyrit-feat-findings-operations validation stories.

Exposes SYNCHRONOUS public helpers that validation-story test functions (which
the driver runs *without* asyncio auto-mode, so they are plain ``def``) can call
directly. Every async interaction with PyRIT's memory layer is wrapped in
``asyncio.run`` inside a helper here.

What this harness hardcodes is STABLE, PRE-EXISTING PyRIT surface only:

  * ``SQLiteMemory`` / ``CentralMemory`` / ``Singleton`` — the pre-existing
    memory-discovery infrastructure (mirrors the repo's own ``sqlite_instance``
    fixture). The feature adds *methods* on the memory object, not a new way to
    build or bind it.
  * ``fastapi.testclient.TestClient(pyrit.backend.main.app)`` plus the
    pre-existing compatibility header and local auth policy — the HTTP surface.
    The new routes mount under the existing ``/api`` prefix.
  * the pre-existing attack/message/score memory API
    (``add_attack_results_to_memory_async``, ``add_message_to_memory_async``,
    ``add_message_pieces_to_memory_async``, ``add_scores_to_memory_async``,
    ``update_attack_result_by_id_async``) and the pre-existing activity ORM
    classes (``AttackResultEntry`` / ``PromptMemoryEntry``) — used to seed and
    to tear down recorded activity.
  * ``alembic`` + the pre-existing migrations directory
    ``pyrit/memory/alembic`` and the two pre-existing revision ids that bracket
    this feature's migration (the PARENT ``901e6c7bf9d4`` and the prior head
    ``3f6a9d2c8b1e``). The feature's own new revision is reached as ``"head"``
    so its hash is never named here.

It deliberately provides NO helper that constructs or parses a solution-chosen
shape (operation/finding/evidence memory-method names, service method names,
response field names, REST sub-paths beyond ``/api/operations``, the new ORM
*Entry* class/table/column names, query-param names). Stories discover those
from the submitted patch in prose and assert the observable behaviour — see the
DISCOVERY section of ``validation_spec.toml``.

Usage from a validation script::

    import sys
    sys.path.insert(0, "/tests/validate")
    import test_harness as th
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import tempfile
from typing import Any, Iterable
from unittest.mock import patch
from uuid import UUID, uuid4

REPO = "/repo/PyRIT"

# Startup provenance the backend expects from clients that skip the app
# lifespan — same value the repo's backend test fixtures synthesise.
_IDENTITY = "0.14.0+g" + "a" * 40

# Pre-existing migrations directory and the two public revision ids that bracket
# this feature's migration. 901e6c7bf9d4 is the PARENT the backfill runs on;
# 3f6a9d2c8b1e is the prior head (this feature's down_revision). The feature's
# OWN revision is reached via the "head" alias so its hash is never named.
ALEMBIC_SCRIPT_LOCATION = REPO + "/pyrit/memory/alembic"
MIGRATION_PARENT_REVISION = "901e6c7bf9d4"
MIGRATION_PRIOR_HEAD_REVISION = "3f6a9d2c8b1e"
MIGRATION_VERSION_TABLE = "pyrit_memory_alembic_version"

# Filled by conftest_override's autouse fixture with the memory bound for the
# currently-running test; read it via `memory()`.
_CURRENT: dict[str, Any] = {"mem": None}


# --------------------------------------------------------------------------- #
# Event-loop plumbing                                                          #
# --------------------------------------------------------------------------- #
def run(coro):
    """Run an async coroutine to completion from synchronous story code."""
    return asyncio.run(coro)


def gather(coro_factory, n: int = 2):
    """Run ``n`` freshly-built coroutines concurrently in one event loop.

    ``coro_factory`` is a zero-arg callable returning a NEW coroutine each call
    (e.g. ``lambda: svc.attach(...)``). Returns the list of results, with any
    raised exception captured in place (``return_exceptions=True``) so a story
    can assert "exactly one row resulted" without a single failing coroutine
    aborting the whole gather. This is the in-loop concurrency the attach
    idempotency guarantee is exercised against.
    """

    async def _run():
        return await asyncio.gather(*[coro_factory() for _ in range(n)], return_exceptions=True)

    return run(_run())


# --------------------------------------------------------------------------- #
# Memory binding (pre-existing infrastructure; mirrors the repo fixture).      #
# --------------------------------------------------------------------------- #
@contextlib.contextmanager
def use_sqlite_memory(mem):
    """Bind ``CentralMemory`` and the ``SQLiteMemory`` singleton to ``mem``."""
    from pyrit.common.singleton import Singleton
    from pyrit.memory import CentralMemory, SQLiteMemory

    previous = Singleton._instances.get(SQLiteMemory)
    Singleton._instances[SQLiteMemory] = mem
    try:
        with patch.object(CentralMemory, "_memory_instance", None):
            CentralMemory.set_memory_instance(mem)
            yield
    finally:
        if previous is None:
            Singleton._instances.pop(SQLiteMemory, None)
        else:
            Singleton._instances[SQLiteMemory] = previous


def build_sqlite_memory():
    """Create a fresh, isolated in-memory ``SQLiteMemory`` with the full schema.

    Mirrors the repo's ``sqlite_instance`` fixture: ``__new__`` + an ``__init__``
    with ``cleanup`` patched out so the shared on-disk results store is left
    alone, then ``disable_embedding()``. The schema is migrated to head
    (``skip_schema_migration=False``) so the new operations/findings/evidence
    tables exist.
    """
    from pyrit.memory import SQLiteMemory

    mem = SQLiteMemory.__new__(SQLiteMemory)
    with patch.object(mem, "cleanup"):
        mem.__init__(db_path=":memory:", skip_schema_migration=False)
    mem.results_path = tempfile.mkdtemp()
    mem.disable_embedding()
    return mem


def memory():
    """Return the ``SQLiteMemory`` bound for the current test (set by conftest)."""
    mem = _CURRENT.get("mem")
    if mem is None:  # pragma: no cover - defensive
        raise RuntimeError(
            "No memory is bound. The autouse _backend_env fixture in "
            "conftest_override.py binds one per test."
        )
    return mem


# --------------------------------------------------------------------------- #
# HTTP surface (pre-existing TestClient over the existing /api mount).         #
# --------------------------------------------------------------------------- #
def compat_headers() -> dict[str, str]:
    from pyrit import _compatibility

    return {_compatibility.COMPATIBILITY_HEADER: _IDENTITY}


def client():
    """A ``TestClient`` over the backend app, carrying the compatibility header.

    The autouse ``_backend_env`` fixture has already patched the app's
    compatibility id and installed a local auth policy, so business requests
    carrying this header are accepted.
    """
    from fastapi.testclient import TestClient

    from pyrit.backend.main import app

    return TestClient(app, headers=compat_headers())


# --------------------------------------------------------------------------- #
# Pre-existing attack / message / score seeding.                              #
# These methods and models all predate this feature; only the optional        #
# `operation_id` attribution link is new (the feature's central concept).     #
# --------------------------------------------------------------------------- #
def seed_attack(*, conversation_id: str, objective: str, operation_id=None, with_message: bool = True):
    """Record an ``AttackResult`` (optionally attributed to an operation id) and,
    by default, one saved message in its conversation.

    Returns the ``AttackResult`` object. ``operation_id`` is the operation
    attribution link the feature introduces; pass it to attribute the activity
    to a known operation, or omit it for an unattributed attack.
    """
    mem = memory()

    async def _seed():
        from pyrit.models import AttackResult, Message, MessagePiece

        kwargs: dict[str, Any] = {"conversation_id": conversation_id, "objective": objective}
        if operation_id is not None:
            kwargs["operation_id"] = operation_id
        attack = AttackResult(**kwargs)
        await mem.add_attack_results_to_memory_async(attack_results=[attack])
        if with_message:
            await mem.add_message_to_memory_async(
                request=Message(
                    message_pieces=[
                        MessagePiece(
                            role="user",
                            original_value=objective,
                            conversation_id=conversation_id,
                        )
                    ]
                )
            )
        return attack

    return run(_seed())


def seed_score_on_conversation(*, conversation_id: str, value: str = "Branch answer"):
    """Add one assistant message to ``conversation_id`` and a true/false score on
    it. Returns ``(message_piece, score)``.

    Uses only pre-existing models/methods (``MessagePiece``, ``Score``,
    ``ComponentIdentifier``, ``add_message_pieces_to_memory_async``,
    ``add_scores_to_memory_async``).
    """
    mem = memory()

    async def _seed():
        from pyrit.models import ComponentIdentifier, MessagePiece, Score

        piece = MessagePiece(role="assistant", original_value=value, conversation_id=conversation_id)
        await mem.add_message_pieces_to_memory_async(message_pieces=[piece])
        score = Score(
            score_value="true",
            score_type="true_false",
            score_rationale="validation seed",
            scorer_class_identifier=ComponentIdentifier(
                class_name="SelfAskTrueFalseScorer", class_module="pyrit.score"
            ),
            message_piece_id=piece.id,
        )
        await mem.add_scores_to_memory_async(scores=[score])
        return piece, score

    return run(_seed())


def link_score_to_attack(*, attack_id, score_id, conversation_id: str):
    """Point an attack's automated score + pruned conversation at a seeded score.

    Uses the pre-existing ``update_attack_result_by_id_async`` update API with
    the pre-existing ``automated_score_id`` / ``pruned_conversation_ids`` fields.
    """
    mem = memory()

    async def _update():
        await mem.update_attack_result_by_id_async(
            attack_result_id=str(attack_id),
            update_fields={
                "pruned_conversation_ids": [conversation_id],
                "automated_score_id": str(score_id),
            },
        )

    run(_update())


def delete_all_recorded_activity():
    """Delete every recorded attack-result and prompt-memory row.

    Removes the underlying activity an evidence row points at — without touching
    any findings/evidence table — so a story can observe an evidence entry flip
    to unavailable while its row survives. Uses only the pre-existing activity
    ORM classes.
    """
    mem = memory()

    async def _del():
        from sqlalchemy import delete

        from pyrit.memory.memory_models import AttackResultEntry, PromptMemoryEntry

        async with await mem.get_session_async() as session, session.begin():
            for table in (AttackResultEntry, PromptMemoryEntry):
                await session.execute(delete(table))

    run(_del())


def insert_legacy_name_attack(*, conversation_id: str, objective: str, legacy_operation_name: str, with_message: bool = True):
    """Record an attack attributed ONLY by a legacy operation NAME (no id), as a
    row written before operation ids existed.

    The legacy-name attribution attribute is part of this feature's deprecation
    plumbing; this helper constructs the ``AttackResult`` with that legacy name
    set (discover the exact attribute from the patch if this default does not
    match — see the DISCOVERY notes) and persists it through the pre-existing
    memory API so later resolution must fall back to the stored historical name.

    Returns the ``AttackResult``.
    """
    mem = memory()

    async def _seed():
        from pyrit.models import AttackResult, Message, MessagePiece

        attack = AttackResult(
            conversation_id=conversation_id,
            objective=objective,
            operation=legacy_operation_name,
        )
        await mem.add_attack_results_to_memory_async(attack_results=[attack])
        if with_message:
            await mem.add_message_to_memory_async(
                request=Message(
                    message_pieces=[
                        MessagePiece(
                            role="user",
                            original_value=objective,
                            conversation_id=conversation_id,
                        )
                    ]
                )
            )
        return attack

    return run(_seed())


def raw_execute(sql: str, params: dict | None = None):
    """Execute a raw SQL statement against the bound memory's engine and return
    all rows (as tuples). For stories that must read or write a solution-chosen
    table directly (e.g. inserting a finding row with an out-of-taxonomy harm
    value to exercise the tolerant read). Discover the table/column names from
    the submitted patch; this helper only runs the SQL you build.
    """
    mem = memory()

    async def _exec():
        from sqlalchemy import text

        async with await mem.get_session_async() as session, session.begin():
            result = await session.execute(text(sql), params or {})
            try:
                return [tuple(row) for row in result.all()]
            except Exception:
                return []

    return run(_exec())


def insert_legacy_activity_row(connection, *, name, timestamp, conversation_id=None, objective="legacy-objective"):
    """Insert ONE pre-feature activity row into the ``AttackResultEntries`` table
    on an arbitrary alembic-migrated ``connection`` (the migration story's shared
    in-memory DB), carrying a legacy operation NAME and an explicit ``timestamp``.

    This encodes only the PRE-EXISTING, repo-owned ``AttackResultEntries`` schema
    that predates this feature: its NOT-NULL columns (``id``, ``conversation_id``,
    ``objective``, ``executed_turns``, ``execution_time_ms``, ``outcome``,
    ``timestamp``) and the legacy operation-name column (``operation``). It does
    NOT touch any feature-new table or column — the backfill under test reads this
    row's ``operation`` name and ``timestamp`` to decide merge order. ``timestamp``
    is an ISO-8601 string; earlier timestamps win a merge. Returns the row id.
    """
    import uuid as _uuid

    from sqlalchemy import text

    row_id = str(_uuid.uuid4())
    conv = conversation_id or str(_uuid.uuid4())
    connection.execute(
        text(
            "INSERT INTO AttackResultEntries "
            "(id, conversation_id, objective, executed_turns, execution_time_ms, "
            " outcome, timestamp, operation) "
            "VALUES (:id, :conv, :obj, 1, 0, 'success', :ts, :op)"
        ),
        {"id": row_id, "conv": conv, "obj": objective, "ts": timestamp, "op": name},
    )
    # Commit-as-you-go so the row is durable on this shared connection before the
    # feature migration (run on the same connection) reads it.
    try:
        connection.commit()
    except Exception:
        pass
    return row_id


# --------------------------------------------------------------------------- #
# Alembic migration plumbing (pre-existing alembic + migrations dir).         #
# --------------------------------------------------------------------------- #
@contextlib.contextmanager
def migration_engine():
    """Yield ``(engine, connection)`` over a single shared in-memory SQLite DB.

    One connection is held open for the whole block (StaticPool) so that schema
    applied by ``alembic`` persists across ``command.upgrade`` /
    ``command.downgrade`` calls and raw reads within the same test.
    """
    from sqlalchemy import create_engine
    from sqlalchemy.pool import StaticPool

    engine = create_engine(
        "sqlite://",
        poolclass=StaticPool,
        connect_args={"check_same_thread": False},
    )
    conn = engine.connect()
    try:
        yield engine, conn
    finally:
        conn.close()
        engine.dispose()


def alembic_config(connection):
    """Build an ``alembic`` ``Config`` bound to ``connection`` for this repo's
    migrations. Targets are passed to ``command.upgrade`` / ``command.downgrade``
    by the story (use ``"head"`` to reach the feature's new revision without
    naming it, ``MIGRATION_PARENT_REVISION`` for the pre-feature parent, and
    ``MIGRATION_PRIOR_HEAD_REVISION`` to downgrade past the feature).
    """
    from alembic.config import Config

    cfg = Config()
    cfg.set_main_option("script_location", ALEMBIC_SCRIPT_LOCATION)
    cfg.attributes["connection"] = connection
    cfg.attributes["version_table"] = MIGRATION_VERSION_TABLE
    return cfg


# --------------------------------------------------------------------------- #
# Generic observation helpers (no solution-chosen names baked in).            #
# --------------------------------------------------------------------------- #
def iter_strings(value) -> Iterable[str]:
    """Yield every string anywhere in a nested JSON-like value."""
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for v in value.values():
            yield from iter_strings(v)
    elif isinstance(value, (list, tuple)):
        for v in value:
            yield from iter_strings(v)


def iter_dicts(value) -> Iterable[dict]:
    """Yield every ``dict`` anywhere in a nested JSON-like value (self included)."""
    if isinstance(value, dict):
        yield value
        for v in value.values():
            yield from iter_dicts(v)
    elif isinstance(value, (list, tuple)):
        for v in value:
            yield from iter_dicts(v)


def find_value_for(value, wanted: str) -> bool:
    """True if ``wanted`` appears as a string anywhere in the nested value."""
    return any(s == wanted for s in iter_strings(value))


def list_envelope(body) -> list:
    """Return the list payload of a paginated list response, tolerating the key.

    The pagination envelope key (``items``) is a repo-wide convention; the list
    body is expected to carry a list under it. Falls back to the first list
    value found so a story does not couple to the exact key if an implementation
    differs.
    """
    if isinstance(body, list):
        return body
    if isinstance(body, dict):
        if isinstance(body.get("items"), list):
            return body["items"]
        for v in body.values():
            if isinstance(v, list):
                return v
    return []


def as_json(value) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def exception_haystack(exc: BaseException) -> str:
    """A broad searchable string from an exception's message and attributes, so a
    story can assert a token is referenced without coupling to a message format.
    """
    parts: list[str] = [str(exc), repr(exc), type(exc).__name__]
    for attr in dir(exc):
        if attr.startswith("__"):
            continue
        try:
            val = getattr(exc, attr)
        except Exception:
            continue
        if isinstance(val, (str, list, tuple, set, dict)):
            parts.append(str(val))
    return " ".join(parts)


__all__ = [
    "REPO",
    "MIGRATION_PARENT_REVISION",
    "MIGRATION_PRIOR_HEAD_REVISION",
    "run",
    "gather",
    "use_sqlite_memory",
    "build_sqlite_memory",
    "memory",
    "compat_headers",
    "client",
    "seed_attack",
    "seed_score_on_conversation",
    "link_score_to_attack",
    "delete_all_recorded_activity",
    "insert_legacy_name_attack",
    "raw_execute",
    "migration_engine",
    "alembic_config",
    "iter_strings",
    "iter_dicts",
    "find_value_for",
    "list_envelope",
    "as_json",
    "exception_haystack",
    "UUID",
    "uuid4",
]
