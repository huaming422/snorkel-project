#!/usr/bin/env bash
# Validation-story environment for pyrit-feat-findings-operations.
#
# The stories run through PyRIT's own project virtualenv (/opt/venv), which the
# task image pre-populated with the full dependency closure at the base commit
# via `uv sync --frozen --all-extras --group dev`. Nothing new is installed here
# (no bare `pip install`); this script only exports the environment the repo's
# memory + backend layers expect and fails loudly if the harness cannot import.
#
# Runs with network available, but is offline-first: the only package operation
# is an offline-first `uv sync` that is a no-op on a normal trial and reaches
# the network solely if the baked /opt/venv was deleted.
set -euo pipefail

REPO=/repo/PyRIT
cd "$REPO"

export PATH="/usr/local/bin:$PATH"   # uv
export UV_PYTHON_INSTALL_DIR=/opt/python
export UV_CACHE_DIR=/opt/cache/uv
export VIRTUAL_ENV=/opt/venv
export UV_PROJECT_ENVIRONMENT=/opt/venv

# Point the repo's memory layer at the pre-warmed on-disk dataset cache so no
# test resolves a remote seed dataset over the network.
export DB_DATA_PATH="${DB_DATA_PATH:-$REPO/dbdata}"

# Restore the venv only if it is missing (offline-first, logged online
# fallback). The image pre-runs `uv sync`, so on a normal trial this branch is
# skipped entirely.
if [ ! -x "/opt/venv/bin/python" ]; then
    echo "[validation-setup] /opt/venv missing — recreating (offline first)..."
    uv venv --python 3.13.13 /opt/venv 2>&1 | tail -3
    uv sync --frozen --all-extras --group dev --offline 2>&1 | tail -5 \
        || { echo "[validation-setup] offline sync failed, retrying online..."; \
             uv sync --frozen --all-extras --group dev 2>&1 | tail -5; }
fi

export PATH="/opt/venv/bin:$PATH"

# Loud smoke guard: the pre-existing surface every story builds on must import
# and the harness itself must load. These are all STABLE base modules (the
# feature adds methods/routes on top of them); the solution-chosen symbols the
# stories discover at runtime are deliberately NOT imported here.
/opt/venv/bin/python - <<'PY'
import sys
sys.path.insert(0, "/tests/validate")

# Stable pre-existing PyRIT surface the harness and stories rely on.
import pyrit.memory  # noqa: F401
from pyrit.memory import CentralMemory, SQLiteMemory  # noqa: F401
import pyrit.backend.main  # noqa: F401
from fastapi.testclient import TestClient  # noqa: F401
import alembic  # noqa: F401
from alembic import command  # noqa: F401
import sqlalchemy  # noqa: F401

# The harness must import and expose its documented helpers.
import test_harness as th
for name in (
    "run", "gather", "memory", "client", "use_sqlite_memory",
    "build_sqlite_memory", "seed_attack", "seed_score_on_conversation",
    "link_score_to_attack", "delete_all_recorded_activity",
    "insert_legacy_name_attack", "raw_execute", "migration_engine",
    "alembic_config", "iter_strings", "iter_dicts", "find_value_for",
    "list_envelope", "exception_haystack",
):
    assert hasattr(th, name), f"test_harness missing helper: {name}"

print("validation env OK: pyrit + backend + alembic + test_harness importable")
PY
