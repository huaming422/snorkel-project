#!/usr/bin/env bash
# Container setup for verifiers. This file is `source`d (not executed as a
# subprocess) so the exported PATH/VIRTUAL_ENV persist into the verifier
# process. The verifier runs the repo's own pytest from the project venv
# (/opt/venv), which the image pre-populated with the full dependency closure
# at the base commit via `uv sync --frozen --all-extras --group dev`.
#
# The agent phase is offline (agent_offline = true); everything the solving
# agent and the focused tests need is already baked into the image. This script
# runs with network available and is offline-first: the `uv sync` below is a
# no-op on a normal trial and only reaches the network if an agent deleted the
# baked environment.
set -u

REPO=/repo/PyRIT
cd "$REPO" || { echo "test-setup: $REPO missing" >&2; return 1 2>/dev/null || exit 1; }

export PATH="/usr/local/bin:$PATH"   # uv
export UV_PYTHON_INSTALL_DIR=/opt/python
export UV_CACHE_DIR=/opt/cache/uv
export VIRTUAL_ENV=/opt/venv
export UV_PROJECT_ENVIRONMENT=/opt/venv

# Point the repo's memory layer at the pre-warmed on-disk dataset cache so no
# test resolves a remote seed dataset over the network.
export DB_DATA_PATH="${DB_DATA_PATH:-$REPO/dbdata}"

# Rebuild/verify the venv. The image pre-runs `uv sync`, so on a normal trial
# this is a fast offline no-op (resolution against the existing /opt/venv, no
# downloads). --frozen pins to uv.lock; the `dev` group (pytest, pytest-asyncio)
# installs by default. Offline-first, with a logged online fallback only if the
# baked environment was removed.
if [ ! -x "/opt/venv/bin/python" ]; then
    echo "[test-setup] /opt/venv missing — recreating (offline first)..."
    uv venv --python 3.13.13 /opt/venv 2>&1 | tail -3 || true
    uv sync --frozen --all-extras --group dev --offline 2>&1 | tail -5 \
        || { echo "[test-setup] offline sync failed, retrying online..."; \
             uv sync --frozen --all-extras --group dev 2>&1 | tail -5; }
fi

if [ -d "/opt/venv/bin" ]; then
    export PATH="/opt/venv/bin:$PATH"
fi

# Sanity: the modules under test must import cleanly before any verifier runs.
# (Post-fix these include the new operation/finding models; pre-fix / nop they
# are absent, which is expected — the import guard only checks the stable base
# modules the backend and memory layer always provide.)
python -c "import pyrit.memory.memory_interface; import pyrit.backend.main; import pyrit.models" \
    && echo "test-setup: pyrit importable" \
    || echo "test-setup: WARNING pyrit import failed" >&2
