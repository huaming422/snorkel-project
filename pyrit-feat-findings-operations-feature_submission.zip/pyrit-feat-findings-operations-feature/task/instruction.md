## Task

We run red-teaming campaigns through the GUI, but the backend has no persistent
notion of a campaign and nowhere to record the security findings one turns up;
operators track that out of band. I want both as durable, queryable objects.

Add **Operations** (named campaigns) and **Findings** (severity-classified
results that cite evidence from the `AttackResult` and `ScenarioResult` records
we already store). A finding belongs to an operation, and its harm
classification should reuse the existing harm-taxonomy enum and its tolerant
parse fallback, not a new one.

It spans three layers a GUI drives over HTTP: domain models in `pyrit/models/`,
re-exported through the package's lazy-import mechanism; persistence in
`pyrit/memory/` (ORM tables, async create/read/update/delete/query methods on
the memory API, and a new Alembic revision on the current head); and a REST
surface in `pyrit/backend/` (a router under the existing `/api` prefix plus its
service, Pydantic request and response bodies, storage reached through
`CentralMemory.get_memory_instance()`). The migration also links activity
already recorded in a populated database to the operations it introduces, so
existing data is not orphaned. Operations are identified by name; the matching,
length bound, and conflict behavior are in the requirements below.

The environment is offline and fully provisioned: do not add, upgrade, or remove
packages or touch lockfiles. Keep the `tests/unit/` suite green and the ORM's
dual-dialect behavior (SQLite and SQL Server, with their dialect-specific column
types and collations), and stay within the existing patterns rather than a
parallel mechanism.

Exercise the work from `tests/unit/` (pytest and pytest-asyncio): the memory
layer against a real SQLite-backed instance from the shared `tests/unit/memory/`
fixtures, and the backend through a FastAPI `TestClient` with the
compatibility-header fixtures under `tests/unit/backend/`.

## User stories / requirements

- A finding is created with a caller-chosen id and always under an existing operation. Replaying the same id with identical content returns the already-saved finding instead of duplicating it; reusing that id with different content is a conflict; and creating a finding under an operation that does not exist is rejected.
- A finding's harm classification should draw on the same shared harm vocabulary the rest of the project already uses, including its forgiving handling of values that don't match a known category, rather than introducing a separate stricter check. If a finding was saved with a harm label that is no longer part of the current vocabulary, reading or listing that finding still succeeds instead of erroring out. The original label is kept and surfaced through the vocabulary's tolerant fallback, so it is never silently discarded or left as something that makes the finding impossible to read back.
- Attaching an attack to a finding as evidence links the pair exactly once: replaying the same finding-and-attack attach reports it as already linked, and concurrent attaches of the same pair never produce duplicates. Evidence may only cite an attack that has saved messages.
- Listing a finding's evidence resolves, per linked attack, whether it still exists, its objective, outcome, and score, and its source operation (the current name when linked by id, else the retained historical name). Deleting the attack marks that entry unavailable without dropping its row; attaching evidence never rewrites the attack's attribution.
- Applying the new migration forward on a populated database creates the tables and backfills the operation link onto activity already recorded, merging legacy operation-name variants that share the same case-and-whitespace identity into single operation rows and skipping names over the length bound rather than failing. Its downgrade refuses to run when operations exist.
