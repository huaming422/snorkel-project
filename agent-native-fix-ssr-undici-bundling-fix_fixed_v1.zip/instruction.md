## Task

Since #5958 went out, Clips workspaces that bring their own S3-compatible bucket can't watch anything on our Netlify deploy. Every GET /api/video/<recordingId> for those recordings comes back 502 in about half a second, even a two-byte range request, so the player just says the video couldn't be loaded. Thumbnails and frame grabs for the same clips still return 200, clips on the built-in storage play normally, and the same workspace plays fine when the template runs locally.

The SSRF hardening #5958 put on the S3 calls is deliberate: if the server can't set up that protection, those requests are meant to fail rather than go out without it, in any runtime, and that has to stay true. So turning the requirement off, retrying without it, or skipping it based on where the code is running doesn't count as a fix. Work out what's different about the deployed function and fix that.
