// @ts-nocheck
//
// Drives the exported post-build step
// `copyInstalledExternalSsrPackages(serverDir, projectCwd)` the way the
// package's own build.spec.ts "copyInstalledExternalSsrPackages" block does: a
// hermetic temp project whose node_modules holds a synthetic install of undici
// and react, an emitted server chunk, then the copy step, then a look at which
// packages landed next to the function.
//
// Two of the chunks are not hand-written: they are the repository's
// url-safety module bundled by the same Rolldown that Nitro builds the
// serverless function with, once with minification (the deploy build sets
// `minify: true`) and once without.

import fs from "fs";
import { createRequire } from "module";
import path from "path";

import { afterEach, describe, expect, it } from "vitest";

import { copyInstalledExternalSsrPackages } from "./build.js";

const URL_SAFETY_SOURCE = path.resolve(
  __dirname,
  "..",
  "extensions",
  "url-safety.ts",
);

const tempDirs: string[] = [];

afterEach(() => {
  for (const directory of tempDirs.splice(0)) {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

function installPackage(root: string, name: string, version: string): void {
  const packageDir = path.join(root, "node_modules", ...name.split("/"));
  fs.mkdirSync(packageDir, { recursive: true });
  fs.writeFileSync(
    path.join(packageDir, "package.json"),
    JSON.stringify({ name, version }),
  );
  fs.writeFileSync(path.join(packageDir, "index.js"), "module.exports = {};\n");
}

// A temp root with synthetic installs of undici and react, plus an empty
// server bundle directory holding the generated function manifest.
function makeProject(): { root: string; serverDir: string } {
  const root = fs.mkdtempSync(
    path.join(process.cwd(), ".tmp-ssr-copy-verify-"),
  );
  tempDirs.push(root);
  installPackage(root, "undici", "7.28.0");
  installPackage(root, "react", "19.2.0");

  const serverDir = path.join(root, "server");
  fs.mkdirSync(serverDir, { recursive: true });
  fs.writeFileSync(
    path.join(serverDir, "package.json"),
    JSON.stringify({ name: "traced-node-modules", dependencies: {} }),
  );

  return { root, serverDir };
}

function writeChunk(serverDir: string, relativePath: string, source: string) {
  const filePath = path.join(serverDir, ...relativePath.split("/"));
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, source);
}

function packageCopied(serverDir: string, name: string): boolean {
  return fs.existsSync(
    path.join(serverDir, "node_modules", ...name.split("/"), "package.json"),
  );
}

// Nitro's own Rolldown, resolved through the nitro dependency of this package.
async function loadNitroRolldown() {
  const requireFromCore = createRequire(path.join(__dirname, "build.ts"));
  const nitroManifest = requireFromCore.resolve("nitro/package.json");
  const rolldownEntry = createRequire(nitroManifest).resolve("rolldown");
  return import(rolldownEntry);
}

async function bundleUrlSafety(minify: boolean): Promise<string> {
  const { rolldown } = await loadNitroRolldown();
  const bundle = await rolldown({
    input: URL_SAFETY_SOURCE,
    platform: "node",
    external: [/^node:/],
    logLevel: "silent",
  });
  try {
    const { output } = await bundle.generate({ format: "esm", minify });
    return output
      .filter((item) => item.type === "chunk")
      .map((item) => item.code)
      .join("\n");
  } finally {
    await bundle.close();
  }
}

describe("deployed serverless bundle ships the Node-only packages its server code loads", () => {
  it("copies undici when the server bundle holds the minified url-safety module", async () => {
    const { root, serverDir } = makeProject();
    writeChunk(serverDir, "chunks/_/url-safety.mjs", await bundleUrlSafety(true));
    writeChunk(serverDir, "index.mjs", 'import "./chunks/_/url-safety.mjs";\n');

    const copiedCount = copyInstalledExternalSsrPackages(serverDir, root);

    expect(
      packageCopied(serverDir, "undici"),
      "expected undici to be copied into the function directory when the server bundle contains the minified url-safety module, but its package.json was not found there",
    ).toBe(true);
    expect(copiedCount).toBeGreaterThanOrEqual(1);
  }, 120_000);

  it("copies undici when the only reference is a template-literal specifier", () => {
    const { root, serverDir } = makeProject();
    writeChunk(
      serverDir,
      "chunk.mjs",
      "const react = require(`react`);\n" +
        'export { Link } from "react-router";\n' +
        'export * from "@tanstack/react-query";\n' +
        "await import(`undici`);\n" +
        "export { react };",
    );

    const copiedCount = copyInstalledExternalSsrPackages(serverDir, root);

    expect(
      packageCopied(serverDir, "undici"),
      "expected undici to be copied into the function directory when the chunk loads it through a backtick specifier, but its package.json was not found there",
    ).toBe(true);
    expect(
      packageCopied(serverDir, "react"),
      "expected react, which the same chunk requires, to be copied as well",
    ).toBe(true);
    expect(copiedCount).toBeGreaterThanOrEqual(2);
  });

  it("copies undici when the server bundle holds the unminified url-safety module", async () => {
    const { root, serverDir } = makeProject();
    writeChunk(serverDir, "chunks/_/url-safety.mjs", await bundleUrlSafety(false));

    copyInstalledExternalSsrPackages(serverDir, root);

    expect(
      packageCopied(serverDir, "undici"),
      "expected undici to be copied into the function directory when the server bundle contains the unminified url-safety module",
    ).toBe(true);
  }, 120_000);

  it("copies undici when referenced through a double-quoted specifier", () => {
    const { root, serverDir } = makeProject();
    writeChunk(
      serverDir,
      "chunk.mjs",
      "const react = require(`react`);\n" +
        'export { Link } from "react-router";\n' +
        'const dispatcherSpecifier = "undici";\n' +
        "await import(dispatcherSpecifier);\n" +
        "export { react };",
    );

    copyInstalledExternalSsrPackages(serverDir, root);

    expect(
      packageCopied(serverDir, "undici"),
      "expected undici to be copied into the function directory when the chunk names it through a double-quoted specifier",
    ).toBe(true);
  });

  it("copies undici when referenced through a single-quoted specifier", () => {
    const { root, serverDir } = makeProject();
    writeChunk(
      serverDir,
      "chunk.mjs",
      "const react=require('react');const d=await import('undici');export{react,d};",
    );

    copyInstalledExternalSsrPackages(serverDir, root);

    expect(
      packageCopied(serverDir, "undici"),
      "expected undici to be copied into the function directory when the chunk loads it through a single-quoted specifier",
    ).toBe(true);
  });

  it("does not copy undici when the chunk has no reference to it", () => {
    const { root, serverDir } = makeProject();
    writeChunk(
      serverDir,
      "chunk.mjs",
      "const react = require(`react`);\n" +
        'export { Link } from "react-router";\n' +
        'export * from "@tanstack/react-query";\n' +
        "export { react };",
    );

    copyInstalledExternalSsrPackages(serverDir, root);

    expect(
      packageCopied(serverDir, "undici"),
      "expected undici not to be copied into the function directory when the chunk never references it",
    ).toBe(false);
  });

  it("does not copy undici when the chunk only mentions the name in other text", () => {
    const { root, serverDir } = makeProject();
    writeChunk(
      serverDir,
      "chunk.mjs",
      "const react = require(`react`);\n" +
        "const undiciAgent = null;\n" +
        "const typesPackage = `undici-types`;\n" +
        'const hint = "undici-types";\n' +
        "if (!undiciAgent) console.warn(`undici is not used by this route`);\n" +
        "export { react, typesPackage, hint };",
    );

    copyInstalledExternalSsrPackages(serverDir, root);

    expect(
      packageCopied(serverDir, "undici"),
      "expected undici not to be copied when the chunk only mentions its name in identifiers, messages or another package's name, without loading it",
    ).toBe(false);
  });
});
