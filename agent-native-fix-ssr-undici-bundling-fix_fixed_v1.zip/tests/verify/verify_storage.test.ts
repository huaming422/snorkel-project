// @ts-nocheck
//
// Drives the Clips S3 storage provider through its exported read, upload,
// resumable-upload and delete entry points with the core url-safety module
// loaded from source, the same way the template's own s3-upload-provider tests
// mock request-scoped secrets. The only thing changed between runs is whether
// the Node-only undici package can be imported; global fetch records every
// request instead of reaching the network.

import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const S3_VALUES: Record<string, string> = {
  S3_BUCKET: "clips-bucket",
  S3_ACCESS_KEY_ID: "access",
  S3_SECRET_ACCESS_KEY: "secret",
  S3_ENDPOINT: "https://s3.example.com",
  S3_REGION: "us-east-1",
  S3_PUBLIC_BASE_URL: "https://media.example.com",
};

const RECORDING_ID = "rec-1";
const MEDIA_URL = `https://media.example.com/clips/${RECORDING_ID}/1700000000000-abcd1234.webm`;

let requests: { url: string; init: any }[];

async function loadProvider({ undiciLoads }: { undiciLoads: boolean }) {
  vi.resetModules();
  vi.doMock("@agent-native/core/server", () => ({
    getRequestOrgId: () => "org-1",
    resolveSecret: async (key: string) => S3_VALUES[key] ?? null,
  }));
  vi.doMock("@agent-native/core/secrets", () => ({
    readAppSecret: async () => null,
  }));
  // The configured endpoint resolves to a public address.
  vi.doMock("node:dns/promises", () => {
    const lookup = async () => [{ address: "93.184.215.14", family: 4 }];
    return { lookup, default: { lookup } };
  });
  vi.doMock("@agent-native/core/extensions/url-safety", () =>
    import("../../../../packages/core/src/extensions/url-safety.ts"),
  );
  if (undiciLoads) {
    vi.doMock("undici", () =>
      import("../../../../packages/core/node_modules/undici/index.js"),
    );
  } else {
    // What Node raises when the package is absent from the function bundle.
    vi.doMock("undici", () => {
      const error = new Error(
        "Cannot find package 'undici' imported from /var/task/chunks/_/url-safety.mjs",
      );
      error.code = "ERR_MODULE_NOT_FOUND";
      throw error;
    });
  }
  return import("./s3-upload-provider.js");
}

const OPERATIONS: Record<string, (provider: any) => Promise<unknown>> = {
  "media read": (provider) =>
    provider.fetchS3ObjectByUrl(MEDIA_URL, {
      recordingId: RECORDING_ID,
      range: "bytes=0-1",
    }),
  upload: (provider) =>
    provider.s3FileUploadProvider.upload({
      data: new Uint8Array([1, 2, 3]),
      filename: "rec-1.webm",
      mimeType: "video/webm",
    }),
  "resumable upload start": (provider) =>
    provider.s3FileUploadProvider.resumable.startSession(
      "rec-1.webm",
      "video/webm",
      10 * 1024 * 1024,
    ),
  delete: (provider) => provider.deleteS3ObjectByUrl(MEDIA_URL),
};

beforeEach(() => {
  requests = [];
  vi.stubGlobal(
    "fetch",
    vi.fn(async (url: any, init: any) => {
      requests.push({ url: String(url), init });
      return new Response("<Result></Result>", { status: 200 });
    }),
  );
});

afterEach(() => {
  vi.unstubAllGlobals();
  vi.doUnmock("undici");
  vi.doUnmock("node:dns/promises");
});

describe("Clips S3 requests when the connect-time SSRF guard cannot be built", () => {
  for (const [name, run] of Object.entries(OPERATIONS)) {
    it(`${name} goes out through the guarded dispatcher when undici loads`, async () => {
      const provider = await loadProvider({ undiciLoads: true });
      await run(provider).catch(() => undefined);

      expect(
        requests.length,
        `expected the ${name} to send its S3 request when undici is available`,
      ).toBeGreaterThanOrEqual(1);
      expect(
        requests[0].url.startsWith("https://s3.example.com/"),
        `expected the ${name} to target the configured S3 endpoint, got ${requests[0].url}`,
      ).toBe(true);
      expect(
        requests.every((request) => request.init?.dispatcher),
        `expected every ${name} request to carry the SSRF-guarded dispatcher`,
      ).toBe(true);
    });

    it(`${name} fails without sending anything when undici cannot be loaded`, async () => {
      const provider = await loadProvider({ undiciLoads: false });

      await expect(
        run(provider),
        `expected the ${name} to fail when the guarded dispatcher cannot be built`,
      ).rejects.toThrow();
      expect(
        requests.map((request) => request.url),
        `expected no ${name} request to leave without the guarded dispatcher`,
      ).toEqual([]);
    });
  }

  it("media read fails without sending anything when edge-runtime globals are present", async () => {
    vi.stubGlobal("__cf_env", {});
    vi.stubGlobal("__env__", {});
    vi.stubGlobal("Deno", { version: { deno: "2.0.0" } });
    vi.stubGlobal("EdgeRuntime", "edge-runtime");
    const provider = await loadProvider({ undiciLoads: false });

    await expect(
      OPERATIONS["media read"](provider),
      "expected the media read to fail when the guarded dispatcher cannot be built, whatever runtime globals are present",
    ).rejects.toThrow();
    expect(
      requests.map((request) => request.url),
      "expected no media read request to leave without the guarded dispatcher",
    ).toEqual([]);
  });
});
