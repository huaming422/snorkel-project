import sys
sys.path.insert(0, "/tests/validate")
from test_harness import run_sql


def test_update_from_basic_join(inputs, expected):
    """Test basic UPDATE ... FROM join behavior."""
    result = run_sql(inputs["sql"])
    if expected["error_contains"] != "__skip__":
        # Error case
        assert result["ok"] is False, f"expected an error, got rows {result['rows']}"
        assert expected["error_contains"] in result["error"], (
            f"expected error containing {expected['error_contains']!r}, "
            f"got: {result['error']!r}"
        )
    else:
        # Success case
        assert result["ok"] is True, f"unexpected error: {result['error']!r}"
        assert result["rows"] == expected["rows"], (
            f"expected rows {expected['rows']}, got {result['rows']}"
        )
