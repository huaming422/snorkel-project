import sys
sys.path.insert(0, "/tests/validate")
from test_harness import run_sql

def test_update_from_returning(inputs, expected):
    result = run_sql(inputs["sql"])
    if expected["error_contains"] != "__skip__":
        assert result["ok"] is False, f"expected an error, got rows {result['rows']}"
        assert expected["error_contains"] in result["error"], (
            f"expected error containing {expected['error_contains']!r}, "
            f"got: {result['error']!r}"
        )
    else:
        assert result["ok"] is True, f"unexpected error: {result['error']!r}"
        # Sort both lists before comparing: RETURNING does not guarantee row
        # order, so a correct implementation that returns rows in a different
        # order must not be penalised. The SQL in inputs["sql"] may not include
        # ORDER BY on the RETURNING clause (not all engines support it there),
        # so we normalise order here.
        assert sorted(result["rows"]) == sorted(expected["rows"]), (
            f"expected rows {expected['rows']}, got {result['rows']}"
        )
