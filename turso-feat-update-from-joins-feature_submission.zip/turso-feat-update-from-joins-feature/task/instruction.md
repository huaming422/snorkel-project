## Task

We want UPDATE to be able to take its new values from other tables. Today it can only set columns from constants, the target row's own columns, or an uncorrelated subquery, with no way to drive an update off rows joined in from one or more other relations in the same statement. That's the capability we're after.

Follow the SQL dialect we already target elsewhere in the engine rather than inventing anything: this is a compatibility feature, so wherever that dialect fixes what a given case should do, match it.

Keep it scoped to the new joined form. A plain UPDATE that doesn't pull from other relations should behave exactly as it does now, and the joined form needs to leave the engine's existing integrity guarantees intact.

## User stories / requirements

- An UPDATE can set the target's columns from a table it's joined to, with the join match choosing which target rows change. Unmatched rows are left untouched, and a SET expression can combine the target's own columns with the joined table's.
- The joined source isn't limited to one base table: several tables, a subquery or CTE, a grouped result, or a constant row set, combined with any join form the engine supports (comma, INNER JOIN, USING, NATURAL). Column references resolve, and genuinely ambiguous ones are reported, as everywhere else.
- Every value the statement reads from the target reflects the target as it stood before the statement ran, even under a self-join or a chain where a row it changes would otherwise feed a later match. A target row matched by several source rows is written exactly once, from an unspecified one of them.
- A RETURNING clause on this form of UPDATE returns the final, post-update target rows and may reference the target's own columns and correlated subqueries over the target. Referencing a column of the joined source in RETURNING is not allowed and is reported as an error.
- The joined form preserves the engine's data-integrity behavior end to end: secondary, partial, and expression indexes stay consistent; CHECK, NOT NULL, and type constraints are enforced; OR IGNORE and OR REPLACE behave as they do for an ordinary UPDATE; foreign-key actions cascade; and BEFORE/AFTER triggers fire and see the updated rows.
