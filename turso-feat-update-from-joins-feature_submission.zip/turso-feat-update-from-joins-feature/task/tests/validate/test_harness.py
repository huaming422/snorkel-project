"""Validation harness for the turso UPDATE ... FROM feature.

Everything here goes through the SINGLE pre-existing, stable, implementation-
agnostic interface for this engine: SQL text in -> result rows out. The harness
is a thin subprocess wrapper around the already-built `tursodb` CLI (package
`turso_cli`, a pre-existing binary that has shipped for the whole life of the
repo). It takes a SQL script and returns the parsed result rows plus a success
flag — it is parameterized on SQL text ONLY. It references NO symbol, path,
module, struct, or buffering strategy that the implementation introduces, so it
is neutral across every valid implementation of the feature (ephemeral
rowid-keyed scratch table, in-memory sorted write-set, already-updated marker
bit, or a structurally-divergent rewrite).

Why `tursodb` and not an in-process API: the behavior under test is defined
purely by the SQLite-compatible SQL dialect the engine already targets, and the
CLI is the highest-level surface where it is observable. It needs no crate
features, no serde, and no knowledge of internal types.

CLI contract this harness relies on (all pre-existing CLI behavior):
  - `tursodb <db> -q -m list` runs SQL from stdin against <db>.
  - `:memory:` gives a fresh, isolated in-memory database per invocation, so
    cases never share state.
  - `-m list` (OutputMode::List) prints one result row per line, cells joined
    by a single `|`, NO header row, and renders NULL as an EMPTY field.
  - All statements in the script run in order over one connection, so a
    trailing SELECT observes the effects of a preceding UPDATE.
  - On the first statement that errors, the engine prints the error report and
    the process exits non-zero; later statements do not run. The error text is
    emitted on the CLI's writer. We capture stdout+stderr together so the
    message is available regardless of which stream carries it.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path


def _resolve_tursodb() -> str:
    """Locate the pre-built tursodb binary.

    The image sets CARGO_TARGET_DIR (=/opt/cache/cargo-target); tests/test-setup.sh
    builds tursodb there offline-first. Fall back to the in-tree target dir if
    CARGO_TARGET_DIR is unset.
    """
    candidates = []
    target_dir = os.environ.get("CARGO_TARGET_DIR")
    if target_dir:
        candidates.append(Path(target_dir) / "debug" / "tursodb")
    candidates.append(Path("/opt/cache/cargo-target/debug/tursodb"))
    candidates.append(Path("/repo/turso/target/debug/tursodb"))
    for c in candidates:
        if c.is_file() and os.access(c, os.X_OK):
            return str(c)
    # Last resort: PATH lookup, so a helpful error surfaces if nothing is built.
    return "tursodb"


TURSODB = _resolve_tursodb()

# A single SQL script should never take long against an in-memory database.
_TIMEOUT_SEC = 60


def run_sql(sql: str) -> dict:
    """Execute a SQL script against a fresh in-memory database.

    Returns a dict with a uniform shape for every call:
      {
        "ok": bool,          # True iff every statement ran without error
        "rows": list[str],   # result rows, one "|"-joined string per row,
                             #   in statement/row order (empty when ok is False)
        "error": str,        # combined stdout+stderr when ok is False, else ""
      }

    Notes for callers:
      - Each cell is already a string. NULL appears as an empty field, e.g.
        a row (3, NULL) is the string "3|".
      - `rows` is the concatenation of every row-producing statement's output
        (SELECT and UPDATE ... RETURNING both produce rows), in order.
      - For an error case, assert on `ok is False` AND that `error` contains the
        specific diagnostic the dialect produces (e.g. "ambiguous column name",
        "NOT NULL constraint failed"). Do NOT assert merely that it errored:
        an engine lacking the feature also errors on any UPDATE ... FROM, but
        with a different message, so only a message-specific assertion
        pins the intended behavior.
    """
    proc = subprocess.run(
        [TURSODB, ":memory:", "-q", "-m", "list"],
        input=sql,
        text=True,
        capture_output=True,
        timeout=_TIMEOUT_SEC,
    )
    ok = proc.returncode == 0
    combined = (proc.stdout or "") + (proc.stderr or "")
    rows = [line for line in (proc.stdout or "").splitlines()] if ok else []
    return {
        "ok": ok,
        "rows": rows,
        "error": "" if ok else combined,
    }
