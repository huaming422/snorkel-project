#!/usr/bin/env bash
#
# Reward-owned regression verifier (pass_to_pass behavioral).
#
# Runs the pinned plain-UPDATE / UPDATE ... RETURNING behavioral suite
# (regression_plain_update.sqltest, shipped alongside this script) through the
# engine's own pre-existing `test-runner` harness. Every case uses only the
# pre-existing UPDATE syntax (no FROM), so the engine passes them at the base
# commit; this guard fails iff the agent's new join-driven UPDATE form regresses
# the plain path.
#
# The `.sqltest` lives in the reward stack (next to this script), NOT in the
# agent-writable /repo tree, so the agent cannot weaken the guard by editing the
# in-repo test files. `test-runner run <file>` exits 0 iff every case matches its
# expected rows and non-zero otherwise, which the shell runner maps directly to
# pass/fail.
#
# The shell runner invokes this with cwd={repo_dir} (/repo/turso); we do not rely
# on cwd — paths are resolved absolutely.

set -euo pipefail

# Directory this script was shipped into (/tests/verify), so we find the pinned
# .sqltest regardless of the runner's cwd.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SQLTEST="$SCRIPT_DIR/regression_plain_update.sqltest"

if [[ ! -f "$SQLTEST" ]]; then
    echo "[verify_regression] FATAL: pinned suite not found at $SQLTEST" >&2
    exit 1
fi

# Locate the pre-built test-runner binary. The image sets CARGO_TARGET_DIR
# (=/opt/cache/cargo-target) and tests/test-setup.sh builds the binary there
# offline-first; fall back to the in-tree target dir.
resolve_test_runner() {
    local c
    if [[ -n "${CARGO_TARGET_DIR:-}" && -x "$CARGO_TARGET_DIR/debug/test-runner" ]]; then
        echo "$CARGO_TARGET_DIR/debug/test-runner"; return 0
    fi
    for c in /opt/cache/cargo-target/debug/test-runner /repo/turso/target/debug/test-runner; do
        if [[ -x "$c" ]]; then echo "$c"; return 0; fi
    done
    # Last resort: PATH lookup, so a helpful error surfaces if nothing is built.
    if command -v test-runner >/dev/null 2>&1; then command -v test-runner; return 0; fi
    return 1
}

TEST_RUNNER="$(resolve_test_runner || true)"
if [[ -z "${TEST_RUNNER:-}" ]]; then
    echo "[verify_regression] FATAL: test-runner binary not found (expected under \$CARGO_TARGET_DIR/debug or /opt/cache/cargo-target/debug)" >&2
    exit 1
fi

echo "[verify_regression] running pinned plain-UPDATE regression suite via $TEST_RUNNER"
# Default backend is 'rust' (in-process engine) — the same execution path plain
# UPDATE runs through. Exit status is 0 iff every case passes.
exec "$TEST_RUNNER" run "$SQLTEST" --backend rust --output pretty
