#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# No assertion logic here — just bring the baked build surfaces online so the
# verifier can run SQL through the in-process engine and/or the tursodb CLI.
#
# The image baked the full dependency closure and compiled the workspace at the
# base commit (agent_offline = true), so this must run with the network cut.
# Force cargo offline so a cache miss fails fast instead of reaching a registry.
cd /repo/turso
export CARGO_NET_OFFLINE=true

# Build the behavioral SQL test harness (test-runner) and the CLI, offline-first
# against the image bake, with a logged online fallback. Check each exit status
# directly — never pipe through `tail`, which would mask the exit code.
build_offline_first() {
    # $1 = human label, remaining args = the cargo build target selector
    local label="$1"; shift
    if cargo build "$@" --offline > /tmp/test-setup-"$label".log 2>&1; then
        echo "[offline-first] $label built from image bake"
    elif cargo build "$@" >> /tmp/test-setup-"$label".log 2>&1; then
        echo "[test-setup] $label built online (image bake was stale)"
    else
        echo "[test-setup] $label FAILED to build:" >&2
        tail -40 /tmp/test-setup-"$label".log >&2
        return 1
    fi
}

build_offline_first "test-runner" -p test-runner --bin test-runner
build_offline_first "tursodb"     --package turso_cli

# Sanity: the SQL surfaces are runnable. Binaries land under CARGO_TARGET_DIR
# (the image sets CARGO_TARGET_DIR=/opt/cache/cargo-target), not /repo/turso/target.
TARGET_DIR="${CARGO_TARGET_DIR:-/repo/turso/target}"
test -x "$TARGET_DIR/debug/test-runner" || { echo "[test-setup] test-runner binary missing under $TARGET_DIR" >&2; exit 1; }
test -x "$TARGET_DIR/debug/tursodb"     || { echo "[test-setup] tursodb binary missing under $TARGET_DIR" >&2; exit 1; }
echo "[test-setup] SQL test surfaces ready (test-runner + tursodb) under $TARGET_DIR"
