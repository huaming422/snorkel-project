## Task

we're getting reports that javascript regexes using the `u` (unicode) flag are painfully slow in jint. on a large input string even a simple pattern (a literal search, a `[a-z]+`, a `.*`) takes far longer than it should, and when the engine is configured with a regex timeout those matches fail with a timeout error on inputs that ought to match almost instantly. the same patterns without the `u` flag run fine, so it's something specific to the path the unicode-flag regexes take. dig in and make the `/u` regexes fast again without changing the match results they produce.
