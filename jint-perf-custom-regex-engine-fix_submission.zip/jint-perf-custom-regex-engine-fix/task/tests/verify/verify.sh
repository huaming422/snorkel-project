#!/usr/bin/env bash
# Behavioral verifier for the unicode-flag regex performance symptom.
#
# Jint is a C#/.NET library, so the test is an xunit class exercised through the
# public Engine API. The SHELL runner discovers this file by its verify*.sh name
# and scores on exit code: every assertion in the injected class plus the repo's
# own RegExp suite must pass (dotnet test returns non-zero if any fail).
set -euo pipefail

REPO=/repo/jint
VERIFY_SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/RegExpUnicodePerfVerify.cs"
DEST="$REPO/Jint.Tests/Runtime/RegExpUnicodePerfVerify.cs"

export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1

# Inject the verifier test class into the test project so it compiles against the
# agent's build of Jint (picked up by the project's default source globbing).
cp "$VERIFY_SRC" "$DEST"
trap 'rm -f "$DEST"' EXIT

cd "$REPO"

# Rebuild the library and tests so the agent's edits under Jint/ are reflected,
# then run the RegExp-filtered suite. The filter collects both the injected
# RegExpUnicodePerfVerify class and the repository's existing RegExpTests, so a
# regression anywhere on the RegExp surface also fails the verifier.
# NuGetAudit is disabled because it reaches api.nuget.org for vulnerability
# data on every restore; with the network cut (the grading sandbox runs
# offline) that fetch surfaces as NU1900, which TreatWarningsAsErrors would
# promote to a fatal build error. The warm package cache baked into the image
# already satisfies the restore, so no real dependency resolution is skipped.
dotnet build -c Release -f net10.0 Jint/Jint.csproj -p:NuGetAudit=false
dotnet test Jint.Tests/Jint.Tests.csproj -c Release -f net10.0 \
    -p:NuGetAudit=false --filter "FullyQualifiedName~RegExp"
