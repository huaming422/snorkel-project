using System;
using System.Text.RegularExpressions;
using Jint;

namespace Jint.Tests.Runtime;

// Behavioral verifier for the unicode-flag regex performance symptom. Exercises
// the engine only through its public JavaScript API (new Engine(...) + Evaluate/
// Execute), mirroring the existing RegExpTests style, so it is agnostic to how
// any particular fix is structured internally. The class name contains "RegExp"
// so `dotnet test --filter "FullyQualifiedName~RegExp"` collects it alongside the
// repository's own RegExp suite.
public class RegExpUnicodePerfVerify
{
    // Builds a deterministic ~120k-char lowercase string in a global `s`, using a
    // small linear-congruential generator so both the slow and fast builds see the
    // exact same input. A greedy dot-star search over this string is the symptom's
    // sharpest case.
    private const string LcgSetup = @"
        var N = 120000, seed = 12345, arr = [];
        for (var i = 0; i < N; i++) {
            seed = (seed * 1103515245 + 12345) & 0x7fffffff;
            arr.push(String.fromCharCode(97 + (seed % 26)));
        }
        var s = arr.join('');
    ";

    // Primary performance check. On the slow engine the greedy `.*`
    // backtracks character-by-character over a 120k input (quadratic work) and
    // blows past the 2s interrupt budget, throwing RegexMatchTimeoutException.
    // A correct optimization completes in a few tens of milliseconds and returns
    // the correct result (no match: the string is all lowercase, the pattern
    // needs the digit '9').
    [Fact]
    public void UnicodeGreedyDotStar_CompletesWithinTimeout_OnLargeInput()
    {
        var engine = new Engine(e => e.RegexTimeoutInterval(TimeSpan.FromMilliseconds(2000)));
        engine.Evaluate(LcgSetup);

        // If the match is still slow this line throws RegexMatchTimeoutException
        // and the test fails; a working engine returns a correct (null) result.
        var isNoMatch = engine.Evaluate("s.match(/a.*ab9/u) === null").AsBoolean();
        Assert.True(isNoMatch);
    }

    // The regex timeout must remain a genuine cancellation signal for the custom
    // engine, not something bypassed to dodge the slowness. A catastrophic
    // nested-quantifier /u pattern is exponential regardless of the common-case
    // optimizations, so it must still trip the interpreter's interrupt check and
    // throw. A "fix" that neuters or removes the custom-engine cancellation check
    // would run this unbounded and never throw.
    [Fact]
    public void CustomEngine_StillHonorsTimeout_OnCatastrophicUnicodePattern()
    {
        var engine = new Engine(e => e.RegexTimeoutInterval(TimeSpan.FromMilliseconds(300)));
        Assert.Throws<RegexMatchTimeoutException>(() =>
            engine.Execute("'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa!'.match(/(a+)+$/u)"));
    }

    // The regex timeout must also remain wired for the non-unicode (.NET-engine)
    // path. A pathological non-/u pattern on a long input must still throw, so a
    // change that disabled timeouts globally is caught here.
    [Fact]
    public void NonUnicodeTimeout_StillFires_OnPathologicalPattern()
    {
        const string pattern = "^(https?:\\/\\/)?([\\da-z\\.-]+)\\.([a-z\\.]{2,6})([\\/\\w\\.-]*)*\\/?$";
        const string value = "https://archiverbx.blob.core.windows.net/static/C:/Users/USR/Documents/Projects/PROJ/static/images/full/1234567890.jpg";
        var engine = new Engine(e => e.RegexTimeoutInterval(TimeSpan.FromSeconds(1)));
        Assert.Throws<RegexMatchTimeoutException>(() => engine.Execute($"'{value}'.match(/{pattern}/)"));
    }

    // Unicode-flag matching must stay spec-correct. These are ECMAScript /u
    // results that differ from .NET's regex semantics, so a "fix" that routes /u
    // to System.Text.RegularExpressions, or an unsound bulk scan that mislocates
    // or drops matches, fails here. Values are the observable results of each
    // expression.
    [Fact]
    public void UnicodeMatching_StaysSpecCorrect()
    {
        var engine = new Engine();

        Assert.Equal("abc", engine.Evaluate("'xxabcyy'.match(/abc/u)[0]").AsString());
        Assert.Equal(2, engine.Evaluate("'xxabcyy'.match(/abc/u).index").AsInteger());
        Assert.Equal(3, engine.Evaluate("[...'a1b2c3'.matchAll(/[a-z]\\d/gu)].length").AsInteger());
        Assert.Equal("X", engine.Evaluate("'aaXbb'.match(/a+(?<mid>X)b+/u).groups.mid").AsString());
        Assert.Equal("f0barbaz", engine.Evaluate("'foobarbaz'.replace(/o+/u,'0')").AsString());
        Assert.Equal(6, engine.Evaluate("'hello world'.search(/world/u)").AsInteger());
        Assert.Equal(3, engine.Evaluate("'a,b,c'.split(/,/u).length").AsInteger());
        Assert.Equal("ABC", engine.Evaluate("'ABC'.match(/abc/iu)[0]").AsString());
        Assert.Equal("aaa", engine.Evaluate("'aaa'.match(/a*/u)[0]").AsString());
        Assert.Equal("abracadabra", engine.Evaluate("'abracadabra'.match(/a.*a/u)[0]").AsString());
    }

    // Surrogate-pair handling in unicode mode is the clearest ECMAScript-vs-.NET
    // divergence. With /u, `.` matches a whole astral code point (a length-2 UTF-16
    // string), and empty-pattern matchAll yields positions at code-point boundaries
    // (no match inside a surrogate pair). These fail on any engine that falls back
    // to .NET regex for /u.
    [Fact]
    public void UnicodeSurrogateHandling_StaysSpecCorrect()
    {
        var engine = new Engine();

        Assert.True(engine.Evaluate("/\\u{1F600}/u.test('\\u{1F600}')").AsBoolean());
        Assert.Equal(2, engine.Evaluate("'\\u{1F600}x'.match(/./u)[0].length").AsInteger());

        // One astral char: matchAll(/()/ug) yields boundary positions 0 and 2, not 0/1/2.
        Assert.Equal(2, engine.Evaluate("[...'\\u{1F4A9}'.matchAll(/()/ug)].length").AsInteger());
        Assert.Equal(0, engine.Evaluate("[...'\\u{1F4A9}'.matchAll(/()/ug)][0].index").AsInteger());
        Assert.Equal(2, engine.Evaluate("[...'\\u{1F4A9}'.matchAll(/()/ug)][1].index").AsInteger());
    }
}
