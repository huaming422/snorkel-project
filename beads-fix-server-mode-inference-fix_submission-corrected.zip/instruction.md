## Task

Teams sharing one Dolt server that runs on a different box keep finding their issues in the wrong place. Here's what we've reproduced with `bd`:

- In a workspace set up the usual way (the `metadata.json` from `bd init` says `dolt_mode: embedded`), exporting `BEADS_DOLT_SERVER_HOST` with that box's address doesn't change anything. `bd create` and `bd list` keep using the embedded database under `.beads`, so new issues never get to the server and nobody else sees them. It's the same with `dolt.mode: embedded` in `config.yaml`.
- Older workspaces whose `metadata.json` has no `dolt_mode` stay embedded too when the host comes from `dolt_server_host` in `metadata.json` or `dolt.host` in `config.yaml`. A `.beads` folder that has a `config.yaml` but no `metadata.json` answers "no beads database found", whether the host is in that file or in the environment. Commands that open that folder on their own ignore the host too: `bd human list` quietly makes an embedded database there (a `CGO_ENABLED=0` build refuses and says embedded needs CGO), and `bd list` in a contributor workspace with `dolt.host` set, auto-routed to such a folder, goes looking for an embedded database.
- Exporting `BEADS_DOLT_SERVER_MODE=1` as well gets bd talking to the server, wherever the host was set, but nobody set a port, so it dials port 0. The server listens on the default 3307. On a laptop that used to run bd's own local server, it picks up that old server's port instead.
- When the server can't be reached, bd's error suggests `bd dolt start`, which only ever runs a server on this machine.

None of this applies to a host that means this machine (`localhost`, `127.0.0.1`, `::1`, `0.0.0.0`), wherever it's set, or to a setup with no host at all, with or without `BEADS_DOLT_SERVER_MODE=1`. Those setups are fine as they are, including the local server's port and the `bd dolt start` advice. When the host is set in more than one place, bd already connects to just one of them: `BEADS_DOLT_SERVER_HOST` if it isn't empty, then `metadata.json`, then `config.yaml`. That's the one that counts here.

Please find the cause and get this fixed.
