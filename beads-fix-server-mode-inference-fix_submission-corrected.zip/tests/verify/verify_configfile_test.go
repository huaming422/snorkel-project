// Storage-mode resolution on the loaded workspace config.
//
// Runs inside internal/configfile as `package configfile`, next to the
// package's own tests, and reads the result through existing exported API:
//   - (*Config).IsDoltServerMode() bool
//   - (*Config).GetDoltMode() string      (only on workspaces with no host)
// Hosts and modes come from the existing struct fields (Backend,
// DoltServerHost, DoltMode), the BEADS_DOLT_SERVER_HOST environment variable
// and config.yaml (dolt.host / dolt.mode). Cases that need "no host in the
// environment" unset the variable rather than setting it to an empty string;
// one case sets it to an empty string on purpose.
//
// The subtests are sequential (no t.Parallel): several drive the process-global
// config.yaml layer, which is reset between cases.

package configfile

import (
	"os"
	"path/filepath"
	"testing"

	"github.com/steveyegge/beads/internal/config"
)

const vsmiRemoteHost = "192.0.2.10"

// vsmiUnsetEnv removes key from the environment for the rest of the test and
// puts the previous value back afterwards.
func vsmiUnsetEnv(t *testing.T, key string) {
	t.Helper()
	prev, had := os.LookupEnv(key)
	if err := os.Unsetenv(key); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		if had {
			os.Setenv(key, prev)
		} else {
			os.Unsetenv(key)
		}
	})
}

// vsmiCleanEnv clears every environment variable that steers the storage mode
// and the user-global config.yaml layer.
func vsmiCleanEnv(t *testing.T) {
	t.Helper()
	for _, k := range []string{"BEADS_DOLT_SERVER_HOST", "BEADS_DOLT_SERVER_MODE", "BEADS_DOLT_SHARED_SERVER"} {
		vsmiUnsetEnv(t, k)
	}
	config.ResetForTesting()
	t.Cleanup(config.ResetForTesting)
}

// vsmiConfigYAML writes a config.yaml into a temp dir and points the loader at
// it through BEADS_DIR, the way the CLI reads that layer.
func vsmiConfigYAML(t *testing.T, body string) {
	t.Helper()
	dir := t.TempDir()
	if err := os.WriteFile(filepath.Join(dir, "config.yaml"), []byte(body), 0o600); err != nil {
		t.Fatal(err)
	}
	t.Setenv("BEADS_DIR", dir)
	if err := config.Initialize(); err != nil {
		t.Fatalf("config.Initialize: %v", err)
	}
	t.Cleanup(config.ResetForTesting)
}

func vsmiWantServer(t *testing.T, cfg *Config, want bool, why string) {
	t.Helper()
	if got := cfg.IsDoltServerMode(); got != want {
		t.Errorf("IsDoltServerMode() = %v, want %v: %s", got, want, why)
	}
}

// TestVerifyStorageModeHostInference: a host on another machine selects the
// server, whichever of the three places it comes from.
func TestVerifyStorageModeHostInference(t *testing.T) {
	t.Run("env_host_ipv4_infers_server", func(t *testing.T) {
		vsmiCleanEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", vsmiRemoteHost)
		vsmiWantServer(t, &Config{Backend: BackendDolt}, true, "remote BEADS_DOLT_SERVER_HOST, no mode recorded")
	})

	t.Run("env_host_name_infers_server", func(t *testing.T) {
		vsmiCleanEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "dolt-primary.internal.example.com")
		vsmiWantServer(t, &Config{Backend: BackendDolt}, true, "remote BEADS_DOLT_SERVER_HOST given as a name")
	})

	t.Run("env_host_over_recorded_embedded_mode", func(t *testing.T) {
		// The metadata.json that bd init writes records dolt_mode: embedded.
		vsmiCleanEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", vsmiRemoteHost)
		vsmiWantServer(t, &Config{Backend: BackendDolt, DoltMode: DoltModeEmbedded}, true,
			"remote BEADS_DOLT_SERVER_HOST in a workspace whose metadata.json says dolt_mode: embedded")
	})

	t.Run("env_host_over_config_yaml_embedded_mode", func(t *testing.T) {
		vsmiCleanEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", vsmiRemoteHost)
		vsmiConfigYAML(t, "dolt.mode: embedded\n")
		vsmiWantServer(t, &Config{Backend: BackendDolt}, true,
			"remote BEADS_DOLT_SERVER_HOST with dolt.mode: embedded in config.yaml")
	})

	t.Run("metadata_host_no_mode_infers_server", func(t *testing.T) {
		vsmiCleanEnv(t)
		vsmiWantServer(t, &Config{Backend: BackendDolt, DoltServerHost: "10.0.0.5"}, true,
			"remote dolt_server_host in metadata.json, no mode recorded")
	})

	t.Run("config_yaml_host_no_mode_infers_server", func(t *testing.T) {
		vsmiCleanEnv(t)
		vsmiConfigYAML(t, "dolt.host: 100.64.0.1\n")
		vsmiWantServer(t, &Config{Backend: BackendDolt}, true,
			"remote dolt.host in config.yaml, no mode recorded")
	})

	t.Run("empty_env_host_counts_as_unset", func(t *testing.T) {
		vsmiCleanEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "")
		vsmiWantServer(t, &Config{Backend: BackendDolt, DoltServerHost: "10.0.0.5"}, true,
			"an empty BEADS_DOLT_SERVER_HOST leaves the remote metadata.json host in charge")
	})
}

// TestVerifyLocalHostsStayEmbedded: a host that names this machine, or no host
// at all, keeps the embedded store.
func TestVerifyLocalHostsStayEmbedded(t *testing.T) {
	for _, h := range []string{"localhost", "127.0.0.1", "::1", "0.0.0.0"} {
		h := h
		t.Run("env_host_"+h, func(t *testing.T) {
			vsmiCleanEnv(t)
			t.Setenv("BEADS_DOLT_SERVER_HOST", h)
			vsmiWantServer(t, &Config{Backend: BackendDolt}, false, "BEADS_DOLT_SERVER_HOST="+h+" names this machine")
		})
	}

	t.Run("metadata_host_localhost", func(t *testing.T) {
		vsmiCleanEnv(t)
		vsmiWantServer(t, &Config{Backend: BackendDolt, DoltServerHost: "localhost"}, false,
			"dolt_server_host localhost names this machine")
	})

	t.Run("no_host_anywhere", func(t *testing.T) {
		vsmiCleanEnv(t)
		vsmiWantServer(t, &Config{Backend: BackendDolt}, false, "no host configured")
	})
}

// TestVerifyHostOrder: the host bd would connect to decides. The order is
// BEADS_DOLT_SERVER_HOST, then metadata.json, then config.yaml.
func TestVerifyHostOrder(t *testing.T) {
	t.Run("env_localhost_over_remote_metadata_host", func(t *testing.T) {
		vsmiCleanEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "localhost")
		vsmiWantServer(t, &Config{Backend: BackendDolt, DoltServerHost: "10.0.0.5"}, false,
			"BEADS_DOLT_SERVER_HOST=localhost comes before the remote metadata.json host")
	})

	t.Run("env_remote_over_local_metadata_host", func(t *testing.T) {
		vsmiCleanEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", vsmiRemoteHost)
		vsmiWantServer(t, &Config{Backend: BackendDolt, DoltServerHost: "127.0.0.1"}, true,
			"a remote BEADS_DOLT_SERVER_HOST comes before dolt_server_host 127.0.0.1")
	})

	t.Run("metadata_localhost_over_remote_config_yaml_host", func(t *testing.T) {
		vsmiCleanEnv(t)
		vsmiConfigYAML(t, "dolt.host: 100.64.0.1\n")
		vsmiWantServer(t, &Config{Backend: BackendDolt, DoltServerHost: "localhost"}, false,
			"dolt_server_host localhost in metadata.json comes before the remote config.yaml host")
	})
}

// TestVerifyPreservedModeBehaviorConfigfile: workspaces with no host resolve
// as they always have.
func TestVerifyPreservedModeBehaviorConfigfile(t *testing.T) {
	t.Run("default_is_embedded", func(t *testing.T) {
		vsmiCleanEnv(t)
		cfg := &Config{Backend: BackendDolt}
		vsmiWantServer(t, cfg, false, "default workspace")
		if got := cfg.GetDoltMode(); got != DoltModeEmbedded {
			t.Errorf("GetDoltMode() = %q, want %q for a default workspace", got, DoltModeEmbedded)
		}
	})

	t.Run("explicit_embedded_metadata_is_embedded", func(t *testing.T) {
		vsmiCleanEnv(t)
		cfg := &Config{Backend: BackendDolt, DoltMode: DoltModeEmbedded}
		vsmiWantServer(t, cfg, false, "dolt_mode: embedded")
		if got := cfg.GetDoltMode(); got != DoltModeEmbedded {
			t.Errorf("GetDoltMode() = %q, want %q", got, DoltModeEmbedded)
		}
	})

	t.Run("explicit_server_metadata_is_server", func(t *testing.T) {
		vsmiCleanEnv(t)
		cfg := &Config{Backend: BackendDolt, DoltMode: DoltModeServer}
		vsmiWantServer(t, cfg, true, "dolt_mode: server")
		if got := cfg.GetDoltMode(); got != DoltModeServer {
			t.Errorf("GetDoltMode() = %q, want %q", got, DoltModeServer)
		}
	})

	t.Run("shared_server_env_is_server", func(t *testing.T) {
		vsmiCleanEnv(t)
		t.Setenv("BEADS_DOLT_SHARED_SERVER", "1")
		vsmiWantServer(t, &Config{Backend: BackendDolt}, true, "BEADS_DOLT_SHARED_SERVER=1")
	})
}
