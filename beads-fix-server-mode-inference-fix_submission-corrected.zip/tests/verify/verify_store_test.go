// The connect-failure message a data command prints when the Dolt server
// can't be reached.
//
// Runs inside internal/storage/dolt as `package dolt`, next to the package's
// own tests, and opens a store through newServerMode(ctx, *Config), the open
// every server-mode bd command goes through. Inputs are existing Config fields
// (ServerHost / ServerPort / Path / AutoStart), the same ones the package's
// port_provenance_test.go uses. BEADS_TEST_MODE=1 turns the circuit breaker
// off so no state files are written, as that test does.

package dolt

import (
	"context"
	"regexp"
	"strings"
	"testing"
)

// A mention of the start command counts as advice unless the words right next
// to it say the command doesn't apply: "`bd dolt start` only runs a server on
// this machine" or "don't run bd dolt start".
var (
	vsmiStartCommand   = regexp.MustCompile(`bd dolt start`)
	vsmiDeclinedAfter  = regexp.MustCompile("(?i)^['\"`]?\\s*(?:only\\b|won't\\b|wouldn't\\b|can't\\b|cannot\\b|can not\\b|doesn't\\b|does not\\b|will not\\b|would\\b|isn't\\b|is not\\b|(?:is|runs|starts|manages|handles|works|applies)\\s+(?:only\\b|just\\b|locally\\b|on this\\b|for local\\b|a local\\b|local\\b))")
	vsmiDeclinedBefore = regexp.MustCompile("(?i)(?:\\bnot|\\bdon't|\\bwon't|\\bnever|\\bavoid|\\binstead of|\\bwithout)(?:\\s+(?:run|use|running|using|call|try|need))?\\s+['\"`]?$")
)

// vsmiStartAdvice returns the line of msg that tells the reader to run the start
// command, or "" when no line does.
func vsmiStartAdvice(msg string) string {
	for _, line := range strings.Split(msg, "\n") {
		for _, loc := range vsmiStartCommand.FindAllStringIndex(line, -1) {
			if vsmiDeclinedAfter.MatchString(line[loc[1]:]) || vsmiDeclinedBefore.MatchString(line[:loc[0]]) {
				continue
			}
			return strings.TrimSpace(line)
		}
	}
	return ""
}

func vsmiOpenUnreachable(t *testing.T, host string, autoStart bool) string {
	t.Helper()
	t.Setenv("BEADS_TEST_MODE", "1")
	cfg := &Config{
		Database:   "beads",
		Path:       t.TempDir(),
		ServerHost: host,
		ServerPort: 1,
		AutoStart:  autoStart,
	}
	_, err := newServerMode(context.Background(), cfg)
	if err == nil {
		t.Fatalf("newServerMode(%s port 1): err = nil, want a connect failure", host)
	}
	return err.Error()
}

// vsmiRemoteHosts are servers on another machine that nothing answers on, both
// on port 1: 192.0.2.10 is TEST-NET-1 (RFC 5737) and 2001:db8::10 is the IPv6
// documentation prefix (RFC 3849). Where outbound traffic goes through a sandbox
// proxy, the IPv4 dial can be accepted by the proxy and fail later at the MySQL
// handshake; the IPv6 dial has no route there and fails at the dial itself.
var vsmiRemoteHosts = []string{"192.0.2.10", "2001:db8::10"}

// TestVerifyStoreUnreachableHintForRemoteHost: for a server on another machine
// the message names that host and doesn't tell the reader to run bd dolt start.
func TestVerifyStoreUnreachableHintForRemoteHost(t *testing.T) {
	for _, auto := range []bool{true, false} {
		auto := auto
		name := "auto_start_off"
		if auto {
			name = "auto_start_on"
		}
		t.Run(name, func(t *testing.T) {
			for _, host := range vsmiRemoteHosts {
				msg := vsmiOpenUnreachable(t, host, auto)
				if !strings.Contains(msg, host) {
					t.Errorf("the message must name the configured host %s; got:\n%s", host, msg)
				}
				if line := vsmiStartAdvice(msg); line != "" {
					t.Errorf("the message for a server on another machine (%s) tells the reader to run bd dolt start in %q; got:\n%s", host, line, msg)
				}
			}
		})
	}
}

// TestVerifyStoreUnreachableHintForLocalHost: for a server on this machine, under
// any of the names that mean this machine, the start command is still the advice.
func TestVerifyStoreUnreachableHintForLocalHost(t *testing.T) {
	for _, host := range []string{"localhost", "127.0.0.1", "::1", "0.0.0.0"} {
		host := host
		t.Run(host, func(t *testing.T) {
			msg := vsmiOpenUnreachable(t, host, false)
			if vsmiStartAdvice(msg) == "" {
				t.Errorf("the message for a stopped server on this machine (%s) should still tell the reader to run bd dolt start; got:\n%s", host, msg)
			}
		})
	}
}
