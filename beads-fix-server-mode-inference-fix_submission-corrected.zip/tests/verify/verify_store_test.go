// The connect-failure message a data command prints when the Dolt server
// can't be reached.
//
// Runs inside internal/storage/dolt as `package dolt`, next to the package's
// own tests, and opens a store through newServerMode(ctx, *Config), the open
// every server-mode bd command goes through. Inputs are existing Config fields
// (ServerHost / ServerPort / Path / AutoStart), the same ones the package's
// port_provenance_test.go uses. BEADS_TEST_MODE=1 turns the circuit breaker
// off so no state files are written, as that test does.

package dolt

import (
	"context"
	"regexp"
	"strings"
	"testing"
)

// vsmiStartAdvice matches a line that tells the reader to run the local start
// command: the command on a line of its own (optionally as "$ bd dolt start",
// a list item, in backticks or followed by a "# ..." comment), or after a
// colon ("Start manually: bd dolt start"). A sentence that only mentions the
// command doesn't match.
var vsmiStartAdvice = regexp.MustCompile("(?m)(^[ \\t]*(?:[-*>$][ \\t]*)?`?bd dolt start`?[ \\t]*(?:#.*)?$)|(:[ \\t]*`?bd dolt start`?[ \\t]*(?:#.*)?$)")

func vsmiOpenUnreachable(t *testing.T, host string) string {
	t.Helper()
	t.Setenv("BEADS_TEST_MODE", "1")
	cfg := &Config{
		Database:   "beads",
		Path:       t.TempDir(),
		ServerHost: host,
		ServerPort: 1,
		AutoStart:  false,
	}
	_, err := newServerMode(context.Background(), cfg)
	if err == nil {
		t.Fatalf("newServerMode(%s:1): err = nil, want a connect failure", host)
	}
	return err.Error()
}

// vsmiRemoteHosts are servers on another machine that nothing answers on:
// 192.0.2.10 is TEST-NET-1 (RFC 5737) and 2001:db8::10 is the IPv6
// documentation prefix (RFC 3849), both on port 1. Where outbound traffic goes
// through a sandbox proxy, the IPv4 dial can be accepted by the proxy and fail
// later at the MySQL handshake; the IPv6 dial has no route there and fails at
// the dial itself, the path a stopped server on another machine takes.
var vsmiRemoteHosts = []string{"192.0.2.10", "2001:db8::10"}

// TestVerifyStoreUnreachableHintForRemoteHost: for a server on another machine
// the message names that host and doesn't tell the reader to run bd dolt start.
func TestVerifyStoreUnreachableHintForRemoteHost(t *testing.T) {
	for _, auto := range []bool{true, false} {
		auto := auto
		name := "auto_start_off"
		if auto {
			name = "auto_start_on"
		}
		t.Run(name, func(t *testing.T) {
			t.Setenv("BEADS_TEST_MODE", "1")
			for _, host := range vsmiRemoteHosts {
				cfg := &Config{
					Database:   "beads",
					Path:       t.TempDir(),
					ServerHost: host,
					ServerPort: 1,
					AutoStart:  auto,
				}
				_, err := newServerMode(context.Background(), cfg)
				if err == nil {
					t.Errorf("newServerMode: err = nil, want a connect failure for %s port 1", host)
					continue
				}
				msg := err.Error()
				if !strings.Contains(msg, host) {
					t.Errorf("the message must name the configured host %s; got:\n%s", host, msg)
				}
				if m := vsmiStartAdvice.FindString(msg); m != "" {
					t.Errorf("the message for a server on another machine (%s) tells the reader to run %q; got:\n%s", host, strings.TrimSpace(m), msg)
				}
			}
		})
	}
}

// TestVerifyStoreUnreachableHintForLocalHost: for a server on this machine the
// local start command is still the advice.
func TestVerifyStoreUnreachableHintForLocalHost(t *testing.T) {
	msg := vsmiOpenUnreachable(t, "127.0.0.1")
	if !strings.Contains(msg, "bd dolt start") {
		t.Errorf("the message for a stopped server on this machine should still mention bd dolt start; got:\n%s", msg)
	}
}
