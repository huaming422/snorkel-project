// Server lifecycle classification and the port bd dials.
//
// Runs inside internal/doltserver as `package doltserver`, next to the
// package's own tests, and reads the result through existing exported API:
//   - ResolveServerMode(beadsDir) ServerMode   (ServerModeExternal /
//     ServerModeOwned / ServerModeEmbedded)
//   - DefaultConfig(beadsDir) *Config           (.Port against
//     configfile.DefaultDoltServerPort and explicitly configured ports)
// Inputs are the BEADS_DOLT_SERVER_* environment variables and a workspace
// metadata.json written with configfile.Config{...}.Save(dir). The port-file
// path comes from the package's own portPath helper, as its existing tests do.
//
// Subtests are sequential (no t.Parallel): they drive process-global env/config.

package doltserver

import (
	"os"
	"testing"

	"github.com/steveyegge/beads/internal/config"
	"github.com/steveyegge/beads/internal/configfile"
)

const vsmiRemoteHost = "192.0.2.10"

// vsmiUnsetEnv removes key from the environment for the rest of the test and
// puts the previous value back afterwards.
func vsmiUnsetEnv(t *testing.T, key string) {
	t.Helper()
	prev, had := os.LookupEnv(key)
	if err := os.Unsetenv(key); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		if had {
			os.Setenv(key, prev)
		} else {
			os.Unsetenv(key)
		}
	})
}

// vsmiClearModeEnv clears every environment variable that steers mode and port
// resolution so each case starts from a known ambient state.
func vsmiClearModeEnv(t *testing.T) {
	t.Helper()
	for _, k := range []string{
		"BEADS_DOLT_SHARED_SERVER", "BEADS_DOLT_SERVER_MODE", "BEADS_DOLT_SERVER_HOST",
		"BEADS_DOLT_SERVER_PORT", "BEADS_DOLT_PORT", "BEADS_DOLT_AUTO_START",
	} {
		vsmiUnsetEnv(t, k)
	}
	config.ResetForTesting()
	t.Cleanup(config.ResetForTesting)
}

func vsmiSave(t *testing.T, dir string, cfg *configfile.Config) {
	t.Helper()
	if err := cfg.Save(dir); err != nil {
		t.Fatal(err)
	}
}

func vsmiWantMode(t *testing.T, dir string, want ServerMode, why string) {
	t.Helper()
	if got := ResolveServerMode(dir); got != want {
		t.Errorf("ResolveServerMode = %v, want %v: %s", got, want, why)
	}
}

// TestVerifyLifecycleResolverHostInference: a server on another machine is
// one bd doesn't run itself.
func TestVerifyLifecycleResolverHostInference(t *testing.T) {
	t.Run("metadata_host_no_mode_is_external", func(t *testing.T) {
		vsmiClearModeEnv(t)
		dir := t.TempDir()
		vsmiSave(t, dir, &configfile.Config{DoltServerHost: "10.0.0.5"})
		vsmiWantMode(t, dir, ServerModeExternal, "remote dolt_server_host, no mode recorded")
	})

	t.Run("env_host_without_metadata_is_external", func(t *testing.T) {
		vsmiClearModeEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", vsmiRemoteHost)
		vsmiWantMode(t, t.TempDir(), ServerModeExternal, "remote BEADS_DOLT_SERVER_HOST, no metadata.json")
	})

	t.Run("env_host_over_recorded_embedded_mode_is_external", func(t *testing.T) {
		vsmiClearModeEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", vsmiRemoteHost)
		dir := t.TempDir()
		vsmiSave(t, dir, &configfile.Config{DoltMode: configfile.DoltModeEmbedded})
		vsmiWantMode(t, dir, ServerModeExternal, "remote BEADS_DOLT_SERVER_HOST, metadata.json says dolt_mode: embedded")
	})

	t.Run("empty_env_host_counts_as_unset", func(t *testing.T) {
		vsmiClearModeEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "")
		dir := t.TempDir()
		vsmiSave(t, dir, &configfile.Config{DoltServerHost: "10.0.0.5"})
		vsmiWantMode(t, dir, ServerModeExternal, "an empty BEADS_DOLT_SERVER_HOST leaves the remote metadata.json host in charge")
	})

	t.Run("localhost_metadata_host_is_owned", func(t *testing.T) {
		vsmiClearModeEnv(t)
		dir := t.TempDir()
		vsmiSave(t, dir, &configfile.Config{DoltServerHost: "127.0.0.1"})
		vsmiWantMode(t, dir, ServerModeOwned, "dolt_server_host 127.0.0.1 is this machine")
	})

	t.Run("env_localhost_over_remote_metadata_host_is_owned", func(t *testing.T) {
		vsmiClearModeEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "localhost")
		dir := t.TempDir()
		vsmiSave(t, dir, &configfile.Config{DoltServerHost: "10.0.0.5"})
		vsmiWantMode(t, dir, ServerModeOwned, "BEADS_DOLT_SERVER_HOST=localhost comes before the remote metadata.json host")
	})

	t.Run("explicit_embedded_metadata_is_embedded", func(t *testing.T) {
		vsmiClearModeEnv(t)
		dir := t.TempDir()
		vsmiSave(t, dir, &configfile.Config{DoltMode: configfile.DoltModeEmbedded})
		vsmiWantMode(t, dir, ServerModeEmbedded, "dolt_mode: embedded, no host")
	})
}

// TestVerifyDefaultConfigPortForExternalHost: with a server on another machine
// and no port set, bd dials the standard port; a port that is set still wins,
// and a local server's leftover port file isn't used for the remote host.
func TestVerifyDefaultConfigPortForExternalHost(t *testing.T) {
	wantPort := func(t *testing.T, dir string, want int, why string) {
		t.Helper()
		if got := DefaultConfig(dir).Port; got != want {
			t.Errorf("DefaultConfig.Port = %d, want %d: %s", got, want, why)
		}
	}

	t.Run("host_only_uses_default_port", func(t *testing.T) {
		vsmiClearModeEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", vsmiRemoteHost)
		wantPort(t, t.TempDir(), configfile.DefaultDoltServerPort, "remote host, no port configured")
	})

	t.Run("explicit_server_mode_host_only_uses_default_port", func(t *testing.T) {
		vsmiClearModeEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_MODE", "1")
		t.Setenv("BEADS_DOLT_SERVER_HOST", vsmiRemoteHost)
		wantPort(t, t.TempDir(), configfile.DefaultDoltServerPort, "BEADS_DOLT_SERVER_MODE=1, remote host, no port configured")
	})

	t.Run("stale_local_port_file_not_used_for_remote_host", func(t *testing.T) {
		vsmiClearModeEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", vsmiRemoteHost)
		dir := t.TempDir()
		if err := os.WriteFile(portPath(dir), []byte("45123"), 0o600); err != nil {
			t.Fatal(err)
		}
		wantPort(t, dir, configfile.DefaultDoltServerPort, "a local server's leftover port file, remote host")
	})

	t.Run("env_port_still_wins_for_remote_host", func(t *testing.T) {
		vsmiClearModeEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", vsmiRemoteHost)
		t.Setenv("BEADS_DOLT_SERVER_PORT", "3399")
		wantPort(t, t.TempDir(), 3399, "BEADS_DOLT_SERVER_PORT=3399 with a remote host")
	})

	t.Run("metadata_port_still_wins_for_remote_host", func(t *testing.T) {
		vsmiClearModeEnv(t)
		dir := t.TempDir()
		vsmiSave(t, dir, &configfile.Config{DoltServerHost: "10.0.0.5", DoltServerPort: 3411})
		wantPort(t, dir, 3411, "dolt_server_port 3411 with a remote metadata.json host")
	})

	t.Run("local_workspace_keeps_its_port_file", func(t *testing.T) {
		vsmiClearModeEnv(t)
		dir := t.TempDir()
		if err := os.WriteFile(portPath(dir), []byte("45123"), 0o600); err != nil {
			t.Fatal(err)
		}
		wantPort(t, dir, 45123, "no remote host: the local server's port file stays in use")
	})
}

// TestVerifyPreservedModeBehaviorDoltserver: workspaces with no host resolve as
// they always have.
func TestVerifyPreservedModeBehaviorDoltserver(t *testing.T) {
	t.Run("default_is_owned", func(t *testing.T) {
		vsmiClearModeEnv(t)
		vsmiWantMode(t, t.TempDir(), ServerModeOwned, "default workspace")
	})

	t.Run("explicit_port_metadata_is_external", func(t *testing.T) {
		vsmiClearModeEnv(t)
		dir := t.TempDir()
		vsmiSave(t, dir, &configfile.Config{DoltServerPort: 3307})
		vsmiWantMode(t, dir, ServerModeExternal, "explicit dolt_server_port")
	})

	t.Run("explicit_server_mode_env_is_external", func(t *testing.T) {
		vsmiClearModeEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_MODE", "1")
		vsmiWantMode(t, t.TempDir(), ServerModeExternal, "BEADS_DOLT_SERVER_MODE=1")
	})
}
