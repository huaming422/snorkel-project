// The port bd dials and how a workspace with no remote host is classified.
//
// Runs inside internal/doltserver as `package doltserver`, next to the
// package's own tests, and reads the result through existing exported API:
//   - DefaultConfig(beadsDir) *Config           (.Port against
//     configfile.DefaultDoltServerPort and explicitly configured ports)
//   - ResolveServerMode(beadsDir) ServerMode    (only for workspaces with a
//     host that means this machine or no host at all)
// Inputs are the BEADS_DOLT_SERVER_* environment variables, a workspace
// metadata.json written with configfile.Config{...}.Save(dir), and a config.yaml
// read through BEADS_DIR. The port-file path comes from the package's own
// portPath helper, as its existing tests do.
//
// Subtests are sequential (no t.Parallel): they drive process-global env/config.

package doltserver

import (
	"os"
	"path/filepath"
	"strconv"
	"testing"

	"github.com/steveyegge/beads/internal/config"
	"github.com/steveyegge/beads/internal/configfile"
)

const vsmiStalePort = 45123

// vsmiUnsetEnv removes key from the environment for the rest of the test and
// puts the previous value back afterwards.
func vsmiUnsetEnv(t *testing.T, key string) {
	t.Helper()
	prev, had := os.LookupEnv(key)
	if err := os.Unsetenv(key); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		if had {
			os.Setenv(key, prev)
		} else {
			os.Unsetenv(key)
		}
	})
}

// vsmiClearModeEnv clears every environment variable that steers mode and port
// resolution so each case starts from a known ambient state.
func vsmiClearModeEnv(t *testing.T) {
	t.Helper()
	for _, k := range []string{
		"BEADS_DOLT_SHARED_SERVER", "BEADS_DOLT_SERVER_MODE", "BEADS_DOLT_SERVER_HOST",
		"BEADS_DOLT_SERVER_PORT", "BEADS_DOLT_PORT", "BEADS_DOLT_AUTO_START",
	} {
		vsmiUnsetEnv(t, k)
	}
	config.ResetForTesting()
	t.Cleanup(config.ResetForTesting)
}

func vsmiSave(t *testing.T, dir string, cfg *configfile.Config) {
	t.Helper()
	if err := cfg.Save(dir); err != nil {
		t.Fatal(err)
	}
}

// vsmiConfigYAML writes dir/config.yaml and points the loader at it through
// BEADS_DIR, the way the CLI reads that layer.
func vsmiConfigYAML(t *testing.T, dir, body string) {
	t.Helper()
	if err := os.WriteFile(filepath.Join(dir, "config.yaml"), []byte(body), 0o600); err != nil {
		t.Fatal(err)
	}
	t.Setenv("BEADS_DIR", dir)
	if err := config.Initialize(); err != nil {
		t.Fatalf("config.Initialize: %v", err)
	}
	t.Cleanup(config.ResetForTesting)
}

// vsmiHostSources are the three places a host can be set.
var vsmiHostSources = []struct {
	name string
	set  func(t *testing.T, dir, host string)
}{
	{"env", func(t *testing.T, dir, host string) {
		t.Setenv("BEADS_DOLT_SERVER_HOST", host)
	}},
	{"metadata", func(t *testing.T, dir, host string) {
		vsmiSave(t, dir, &configfile.Config{DoltServerHost: host})
	}},
	{"config_yaml", func(t *testing.T, dir, host string) {
		vsmiConfigYAML(t, dir, "dolt.host: "+strconv.Quote(host)+"\n")
	}},
}

func vsmiWritePortFile(t *testing.T, dir string) {
	t.Helper()
	if err := os.WriteFile(portPath(dir), []byte(strconv.Itoa(vsmiStalePort)), 0o600); err != nil {
		t.Fatal(err)
	}
}

func vsmiWantPort(t *testing.T, dir string, want int, why string) {
	t.Helper()
	if got := DefaultConfig(dir).Port; got != want {
		t.Errorf("DefaultConfig.Port = %d, want %d: %s", got, want, why)
	}
}

func vsmiWantMode(t *testing.T, dir string, want ServerMode, why string) {
	t.Helper()
	if got := ResolveServerMode(dir); got != want {
		t.Errorf("ResolveServerMode = %v, want %v: %s", got, want, why)
	}
}

// TestVerifyDefaultConfigPortForExternalHost: with a server on another machine
// and no port set, bd dials the standard port, wherever the host was set and
// with or without BEADS_DOLT_SERVER_MODE=1. A local server's leftover port file
// isn't used for that host, and a port that is set still wins.
func TestVerifyDefaultConfigPortForExternalHost(t *testing.T) {
	for _, src := range vsmiHostSources {
		src := src
		for _, serverMode := range []bool{false, true} {
			serverMode := serverMode
			suffix := ""
			if serverMode {
				suffix = "_server_mode"
			}
			for _, host := range []string{"192.0.2.10", "dolt-primary.internal.example.com"} {
				host := host
				t.Run(src.name+suffix+"_"+host+"_no_port", func(t *testing.T) {
					vsmiClearModeEnv(t)
					if serverMode {
						t.Setenv("BEADS_DOLT_SERVER_MODE", "1")
					}
					dir := t.TempDir()
					src.set(t, dir, host)
					vsmiWantPort(t, dir, configfile.DefaultDoltServerPort, "remote host from "+src.name+", no port configured")
				})
			}
			t.Run(src.name+suffix+"_leftover_port_file", func(t *testing.T) {
				vsmiClearModeEnv(t)
				if serverMode {
					t.Setenv("BEADS_DOLT_SERVER_MODE", "1")
				}
				dir := t.TempDir()
				src.set(t, dir, "192.0.2.10")
				vsmiWritePortFile(t, dir)
				vsmiWantPort(t, dir, configfile.DefaultDoltServerPort, "a local server's leftover port file, remote host from "+src.name)
			})
		}
	}

	t.Run("empty_env_leaves_metadata_host_in_charge", func(t *testing.T) {
		vsmiClearModeEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "")
		dir := t.TempDir()
		vsmiSave(t, dir, &configfile.Config{DoltServerHost: "10.0.0.5"})
		vsmiWritePortFile(t, dir)
		vsmiWantPort(t, dir, configfile.DefaultDoltServerPort, "an empty BEADS_DOLT_SERVER_HOST, remote host in metadata.json")
	})

	t.Run("env_port_still_wins_for_remote_host", func(t *testing.T) {
		vsmiClearModeEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "192.0.2.10")
		t.Setenv("BEADS_DOLT_SERVER_PORT", "3399")
		vsmiWantPort(t, t.TempDir(), 3399, "BEADS_DOLT_SERVER_PORT=3399 with a remote host")
	})

	t.Run("metadata_port_still_wins_for_remote_host", func(t *testing.T) {
		vsmiClearModeEnv(t)
		dir := t.TempDir()
		vsmiSave(t, dir, &configfile.Config{DoltServerHost: "10.0.0.5", DoltServerPort: 3411})
		vsmiWantPort(t, dir, 3411, "dolt_server_port 3411 with a remote metadata.json host")
	})

	t.Run("config_yaml_port_still_wins_for_remote_host", func(t *testing.T) {
		vsmiClearModeEnv(t)
		dir := t.TempDir()
		vsmiConfigYAML(t, dir, "dolt.host: 100.64.0.1\ndolt.port: 3422\n")
		vsmiWantPort(t, dir, 3422, "dolt.port 3422 with a remote config.yaml host")
	})
}

// TestVerifyLocalHostKeepsPortFile: a host that means this machine, or no host
// at all, keeps the local server's port file, wherever the host was set and with
// or without BEADS_DOLT_SERVER_MODE=1.
func TestVerifyLocalHostKeepsPortFile(t *testing.T) {
	for _, host := range []string{"localhost", "127.0.0.1", "::1", "0.0.0.0"} {
		host := host
		for _, src := range vsmiHostSources {
			src := src
			t.Run(src.name+"_"+host, func(t *testing.T) {
				vsmiClearModeEnv(t)
				dir := t.TempDir()
				src.set(t, dir, host)
				vsmiWritePortFile(t, dir)
				vsmiWantPort(t, dir, vsmiStalePort, host+" from "+src.name+" names this machine")
			})
			t.Run(src.name+"_server_mode_"+host, func(t *testing.T) {
				vsmiClearModeEnv(t)
				t.Setenv("BEADS_DOLT_SERVER_MODE", "1")
				dir := t.TempDir()
				src.set(t, dir, host)
				vsmiWritePortFile(t, dir)
				vsmiWantPort(t, dir, vsmiStalePort, "BEADS_DOLT_SERVER_MODE=1, "+host+" from "+src.name+" names this machine")
			})
		}
	}

	t.Run("no_host", func(t *testing.T) {
		vsmiClearModeEnv(t)
		dir := t.TempDir()
		vsmiWritePortFile(t, dir)
		vsmiWantPort(t, dir, vsmiStalePort, "no host: the local server's port file stays in use")
	})

	t.Run("no_host_server_mode", func(t *testing.T) {
		vsmiClearModeEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_MODE", "1")
		dir := t.TempDir()
		vsmiWritePortFile(t, dir)
		vsmiWantPort(t, dir, vsmiStalePort, "BEADS_DOLT_SERVER_MODE=1, no host: the local server's port file stays in use")
	})
}

// TestVerifyPreservedModeBehaviorDoltserver: workspaces with no host, or with a
// host that means this machine, resolve as they always have.
func TestVerifyPreservedModeBehaviorDoltserver(t *testing.T) {
	t.Run("default_is_owned", func(t *testing.T) {
		vsmiClearModeEnv(t)
		vsmiWantMode(t, t.TempDir(), ServerModeOwned, "default workspace")
	})

	for _, host := range []string{"localhost", "127.0.0.1", "::1", "0.0.0.0"} {
		host := host
		for _, src := range vsmiHostSources {
			src := src
			t.Run(src.name+"_"+host+"_is_owned", func(t *testing.T) {
				vsmiClearModeEnv(t)
				dir := t.TempDir()
				src.set(t, dir, host)
				vsmiWantMode(t, dir, ServerModeOwned, host+" from "+src.name+" names this machine")
			})
		}
	}

	t.Run("env_localhost_over_remote_metadata_host_is_owned", func(t *testing.T) {
		vsmiClearModeEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "localhost")
		dir := t.TempDir()
		vsmiSave(t, dir, &configfile.Config{DoltServerHost: "10.0.0.5"})
		vsmiWantMode(t, dir, ServerModeOwned, "BEADS_DOLT_SERVER_HOST=localhost comes before the remote metadata.json host")
	})

	t.Run("explicit_embedded_metadata_is_embedded", func(t *testing.T) {
		vsmiClearModeEnv(t)
		dir := t.TempDir()
		vsmiSave(t, dir, &configfile.Config{DoltMode: configfile.DoltModeEmbedded})
		vsmiWantMode(t, dir, ServerModeEmbedded, "dolt_mode: embedded, no host")
	})

	t.Run("explicit_port_metadata_is_external", func(t *testing.T) {
		vsmiClearModeEnv(t)
		dir := t.TempDir()
		vsmiSave(t, dir, &configfile.Config{DoltServerPort: 3307})
		vsmiWantMode(t, dir, ServerModeExternal, "explicit dolt_server_port")
	})

	t.Run("explicit_server_mode_env_is_external", func(t *testing.T) {
		vsmiClearModeEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_MODE", "1")
		vsmiWantMode(t, t.TempDir(), ServerModeExternal, "BEADS_DOLT_SERVER_MODE=1")
	})
}
