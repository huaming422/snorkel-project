// End-to-end checks through the bd command itself.
//
// Runs from internal/configfile as `package configfile` only because the
// runner needs a package to host it; nothing here touches that package. The
// test builds ./cmd/bd from the module root once, then runs `bd list` in
// throwaway workspaces with HOME, TMPDIR and the config directory pointed into
// the test's own temp folder. 192.0.2.10 is TEST-NET-1 (RFC 5737): nothing
// answers there, so a bd that goes to that server reports a connect failure
// for 192.0.2.10 on some port, and the case reads that report.

package configfile

import (
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

// vcliTests is the number of Test functions below that share one bd build;
// the build folder is removed when the last of them finishes.
const vcliTests = 4

var (
	vcliOnce   sync.Once
	vcliDir    string
	vcliBinary string
	vcliErr    string
	vcliDone   int32
)

// vcliShare registers the test as a user of the shared build.
func vcliShare(t *testing.T) {
	t.Cleanup(func() {
		if atomic.AddInt32(&vcliDone, 1) == vcliTests && vcliDir != "" {
			os.RemoveAll(vcliDir)
		}
	})
}

// vcliModuleRoot walks up from the package directory to the folder holding go.mod.
func vcliModuleRoot(t *testing.T) string {
	t.Helper()
	dir, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	for {
		if _, err := os.Stat(filepath.Join(dir, "go.mod")); err == nil {
			return dir
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			t.Fatal("go.mod not found above the package directory")
		}
		dir = parent
	}
}

// vcliBuild compiles bd once per test binary.
func vcliBuild(t *testing.T) string {
	t.Helper()
	vcliOnce.Do(func() {
		out, err := os.MkdirTemp("", "vcli-bd-")
		if err != nil {
			vcliErr = err.Error()
			return
		}
		vcliDir = out
		bin := filepath.Join(out, "bd")
		ctx, cancel := context.WithTimeout(context.Background(), 8*time.Minute)
		defer cancel()
		cmd := exec.CommandContext(ctx, "go", "build", "-o", bin, "./cmd/bd")
		cmd.Dir = vcliModuleRoot(t)
		if b, err := cmd.CombinedOutput(); err != nil {
			vcliErr = "go build ./cmd/bd: " + err.Error() + "\n" + string(b)
			return
		}
		vcliBinary = bin
	})
	if vcliBinary == "" {
		t.Fatalf("bd did not build: %s", vcliErr)
	}
	return vcliBinary
}

// vcliWorkspace makes a git repository with a .beads folder holding the given
// files, and returns the repository path and a home folder for the run.
func vcliWorkspace(t *testing.T, files map[string]string) (string, string) {
	t.Helper()
	root := t.TempDir()
	ws := filepath.Join(root, "ws")
	home := filepath.Join(root, "home")
	for _, d := range []string{filepath.Join(ws, ".beads"), filepath.Join(home, "tmp"), filepath.Join(home, ".config")} {
		if err := os.MkdirAll(d, 0o700); err != nil {
			t.Fatal(err)
		}
	}
	for name, body := range files {
		if err := os.WriteFile(filepath.Join(ws, ".beads", name), []byte(body), 0o600); err != nil {
			t.Fatal(err)
		}
	}
	git := exec.Command("git", "init", "-q")
	git.Dir = ws
	if b, err := git.CombinedOutput(); err != nil {
		t.Fatalf("git init: %v\n%s", err, b)
	}
	return ws, home
}

// vcliRun runs bd with a clean environment plus extra variables and returns its
// combined output and whether it exited 0.
func vcliRun(t *testing.T, ws, home string, extra map[string]string, args ...string) (string, bool) {
	t.Helper()
	bin := vcliBuild(t)
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, bin, args...)
	cmd.Dir = ws
	env := []string{}
	for _, kv := range os.Environ() {
		k := kv[:strings.IndexByte(kv+"=", '=')]
		if strings.HasPrefix(k, "BEADS_") || strings.HasPrefix(k, "BD_") || k == "HOME" || k == "TMPDIR" || k == "XDG_CONFIG_HOME" {
			continue
		}
		env = append(env, kv)
	}
	env = append(env,
		"HOME="+home,
		"TMPDIR="+filepath.Join(home, "tmp"),
		"XDG_CONFIG_HOME="+filepath.Join(home, ".config"),
		"BD_DISABLE_METRICS=1",
		"BD_NON_INTERACTIVE=1",
		"CI=true",
	)
	for k, v := range extra {
		env = append(env, k+"="+v)
	}
	cmd.Env = env
	b, err := cmd.CombinedOutput()
	if ctx.Err() != nil {
		t.Fatalf("bd %s did not finish within 90s; output:\n%s", strings.Join(args, " "), b)
	}
	return string(b), err == nil
}

// vcliWentToRemoteServer checks that bd reported a failed connection to
// 192.0.2.10 on the standard port and created no embedded database.
func vcliWentToRemoteServer(t *testing.T, ws, out string, ok bool) {
	t.Helper()
	if ok {
		t.Errorf("bd list exited 0, want a failure to reach 192.0.2.10; output:\n%s", out)
	}
	if !strings.Contains(out, "192.0.2.10") || !strings.Contains(out, "3307") {
		t.Errorf("bd list output doesn't report the server at 192.0.2.10 on port 3307; output:\n%s", out)
	}
	if _, err := os.Stat(filepath.Join(ws, ".beads", "embeddeddolt")); err == nil {
		t.Errorf("bd list created an embedded database under .beads for a workspace whose server is on another machine; output:\n%s", out)
	}
}

const vcliInitMetadata = `{
  "database": "dolt",
  "backend": "dolt",
  "dolt_mode": "embedded",
  "dolt_database": "vcli"
}
`

// TestVerifyCLIRemoteHostFromEnv: the workspace bd init leaves behind
// (dolt_mode: embedded) with only BEADS_DOLT_SERVER_HOST pointing elsewhere.
func TestVerifyCLIRemoteHostFromEnv(t *testing.T) {
	vcliShare(t)
	ws, home := vcliWorkspace(t, map[string]string{"metadata.json": vcliInitMetadata, "config.yaml": ""})
	out, ok := vcliRun(t, ws, home, map[string]string{"BEADS_DOLT_SERVER_HOST": "192.0.2.10"}, "list")
	vcliWentToRemoteServer(t, ws, out, ok)
}

// TestVerifyCLINoMetadataYAMLHost: a .beads folder with a config.yaml naming
// the server host and no metadata.json.
func TestVerifyCLINoMetadataYAMLHost(t *testing.T) {
	vcliShare(t)
	ws, home := vcliWorkspace(t, map[string]string{"config.yaml": "dolt.host: 192.0.2.10\n"})
	out, ok := vcliRun(t, ws, home, nil, "list")
	vcliWentToRemoteServer(t, ws, out, ok)
}

// TestVerifyCLINoMetadataEnvHost: a .beads folder with an empty config.yaml,
// no metadata.json, and BEADS_DOLT_SERVER_HOST pointing elsewhere.
func TestVerifyCLINoMetadataEnvHost(t *testing.T) {
	vcliShare(t)
	ws, home := vcliWorkspace(t, map[string]string{"config.yaml": ""})
	out, ok := vcliRun(t, ws, home, map[string]string{"BEADS_DOLT_SERVER_HOST": "192.0.2.10"}, "list")
	vcliWentToRemoteServer(t, ws, out, ok)
}

// TestVerifyCLINoMetadataNoHost: the same folder with no host anywhere doesn't
// try to reach any server.
func TestVerifyCLINoMetadataNoHost(t *testing.T) {
	vcliShare(t)
	ws, home := vcliWorkspace(t, map[string]string{"config.yaml": ""})
	out, _ := vcliRun(t, ws, home, nil, "list")
	if strings.Contains(out, "3307") || strings.Contains(strings.ToLower(out), "unreachable") {
		t.Errorf("bd list tried to reach a server in a workspace with no host configured; output:\n%s", out)
	}
}
