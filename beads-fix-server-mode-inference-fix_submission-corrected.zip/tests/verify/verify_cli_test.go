// End-to-end checks through the bd command itself.
//
// Runs from internal/configfile as `package configfile` only because the
// runner needs a package to host it; nothing here touches that package. The
// test builds ./cmd/bd from the module root, then runs bd in throwaway
// workspaces with HOME, TMPDIR and the config directory pointed into the test's
// own temp folder. 192.0.2.10 is TEST-NET-1 (RFC 5737) and 2001:db8::10 is the
// IPv6 documentation prefix (RFC 3849): nothing answers there, so a bd that goes
// to that server reports a connect failure naming it, and the case reads that
// report.

package configfile

import (
	"context"
	"encoding/json"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

const (
	// vcliTests is the number of Test functions below that share the bd builds;
	// the build folder is removed when the last of them finishes.
	vcliTests = 7

	vcliRemoteHost = "192.0.2.10"
	vcliStalePort  = "45123"
)

var (
	vcliDirOnce sync.Once
	vcliDir     string
	vcliDirErr  error
	vcliDone    int32

	vcliCgoOnce, vcliNoCgoOnce     sync.Once
	vcliCgoBinary, vcliNoCgoBinary string
	vcliCgoErr, vcliNoCgoErr       string
)

// vcliShare registers the test as a user of the shared builds.
func vcliShare(t *testing.T) {
	t.Cleanup(func() {
		if atomic.AddInt32(&vcliDone, 1) == vcliTests && vcliDir != "" {
			os.RemoveAll(vcliDir)
		}
	})
}

// vcliModuleRoot walks up from the package directory to the folder holding go.mod.
func vcliModuleRoot(t *testing.T) string {
	t.Helper()
	dir, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	for {
		if _, err := os.Stat(filepath.Join(dir, "go.mod")); err == nil {
			return dir
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			t.Fatal("go.mod not found above the package directory")
		}
		dir = parent
	}
}

func vcliCompile(t *testing.T, name string, env ...string) (string, string) {
	t.Helper()
	vcliDirOnce.Do(func() { vcliDir, vcliDirErr = os.MkdirTemp("", "vcli-bd-") })
	if vcliDirErr != nil {
		return "", vcliDirErr.Error()
	}
	bin := filepath.Join(vcliDir, name)
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Minute)
	defer cancel()
	cmd := exec.CommandContext(ctx, "go", "build", "-o", bin, "./cmd/bd")
	cmd.Dir = vcliModuleRoot(t)
	cmd.Env = append(os.Environ(), env...)
	if b, err := cmd.CombinedOutput(); err != nil {
		return "", "go build ./cmd/bd: " + err.Error() + "\n" + string(b)
	}
	return bin, ""
}

// vcliBuild compiles bd once per test binary.
func vcliBuild(t *testing.T) string {
	t.Helper()
	vcliCgoOnce.Do(func() { vcliCgoBinary, vcliCgoErr = vcliCompile(t, "bd") })
	if vcliCgoBinary == "" {
		t.Fatalf("bd did not build: %s", vcliCgoErr)
	}
	return vcliCgoBinary
}

// vcliBuildNoCgo compiles bd with CGO_ENABLED=0 once per test binary.
func vcliBuildNoCgo(t *testing.T) string {
	t.Helper()
	vcliNoCgoOnce.Do(func() { vcliNoCgoBinary, vcliNoCgoErr = vcliCompile(t, "bd-nocgo", "CGO_ENABLED=0") })
	if vcliNoCgoBinary == "" {
		t.Fatalf("bd did not build with CGO_ENABLED=0: %s", vcliNoCgoErr)
	}
	return vcliNoCgoBinary
}

// vcliFolders makes a git repository and a home folder for the run.
func vcliFolders(t *testing.T) (string, string) {
	t.Helper()
	root := t.TempDir()
	ws := filepath.Join(root, "ws")
	home := filepath.Join(root, "home")
	for _, d := range []string{ws, filepath.Join(home, "tmp"), filepath.Join(home, ".config")} {
		if err := os.MkdirAll(d, 0o700); err != nil {
			t.Fatal(err)
		}
	}
	vcliGit(t, ws, "init", "-q")
	return ws, home
}

func vcliGit(t *testing.T, dir string, args ...string) {
	t.Helper()
	git := exec.Command("git", args...)
	git.Dir = dir
	if b, err := git.CombinedOutput(); err != nil {
		t.Fatalf("git %s: %v\n%s", strings.Join(args, " "), err, b)
	}
}

func vcliWriteBeadsFile(t *testing.T, ws, name, body string) {
	t.Helper()
	dir := filepath.Join(ws, ".beads")
	if err := os.MkdirAll(dir, 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(dir, name), []byte(body), 0o600); err != nil {
		t.Fatal(err)
	}
}

func vcliReadBeadsFile(t *testing.T, ws, name string) string {
	t.Helper()
	b, err := os.ReadFile(filepath.Join(ws, ".beads", name))
	if err != nil {
		t.Fatal(err)
	}
	return string(b)
}

// vcliRunWith runs one bd binary with a clean environment plus extra variables
// and returns its combined output and whether it exited 0. Each run gets its own
// TMPDIR, because bd counts failed connections per host in a file under it and
// stops naming the host after five.
func vcliRunWith(t *testing.T, bin, ws, home string, extra map[string]string, args ...string) (string, bool) {
	t.Helper()
	tmp, err := os.MkdirTemp(filepath.Join(home, "tmp"), "run-")
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	cmd := exec.CommandContext(ctx, bin, args...)
	cmd.Dir = ws
	env := []string{}
	for _, kv := range os.Environ() {
		k := kv[:strings.IndexByte(kv+"=", '=')]
		if strings.HasPrefix(k, "BEADS_") || strings.HasPrefix(k, "BD_") || k == "HOME" || k == "TMPDIR" || k == "XDG_CONFIG_HOME" {
			continue
		}
		env = append(env, kv)
	}
	env = append(env,
		"HOME="+home,
		"TMPDIR="+tmp,
		"XDG_CONFIG_HOME="+filepath.Join(home, ".config"),
		"BD_DISABLE_METRICS=1",
		"BD_NON_INTERACTIVE=1",
		"CI=true",
	)
	for k, v := range extra {
		env = append(env, k+"="+v)
	}
	cmd.Env = env
	b, runErr := cmd.CombinedOutput()
	if ctx.Err() != nil {
		t.Fatalf("bd %s did not finish within 5 minutes; output:\n%s", strings.Join(args, " "), b)
	}
	return string(b), runErr == nil
}

func vcliRun(t *testing.T, ws, home string, extra map[string]string, args ...string) (string, bool) {
	t.Helper()
	return vcliRunWith(t, vcliBuild(t), ws, home, extra, args...)
}

// vcliInitWorkspace runs bd init in a new repository and creates one issue in the
// embedded store it sets up.
func vcliInitWorkspace(t *testing.T) (string, string) {
	t.Helper()
	ws, home := vcliFolders(t)
	if out, ok := vcliRun(t, ws, home, nil, "init", "--quiet", "--prefix", "vcli"); !ok {
		t.Fatalf("bd init failed; output:\n%s", out)
	}
	if out, ok := vcliRun(t, ws, home, nil, "create", "vcli-seed-issue"); !ok {
		t.Fatalf("bd create in the new workspace failed; output:\n%s", out)
	}
	return ws, home
}

// vcliForgetRecordedMode removes dolt_mode from the workspace's metadata.json,
// which is what a workspace from before bd recorded a mode looks like.
func vcliForgetRecordedMode(t *testing.T, ws string) {
	t.Helper()
	var meta map[string]any
	if err := json.Unmarshal([]byte(vcliReadBeadsFile(t, ws, "metadata.json")), &meta); err != nil {
		t.Fatal(err)
	}
	delete(meta, "dolt_mode")
	vcliWriteMetadata(t, ws, meta)
}

func vcliWriteMetadata(t *testing.T, ws string, meta map[string]any) {
	t.Helper()
	b, err := json.MarshalIndent(meta, "", "  ")
	if err != nil {
		t.Fatal(err)
	}
	vcliWriteBeadsFile(t, ws, "metadata.json", string(b)+"\n")
}

// vcliLocalIssues lists the workspace's embedded store with no host set.
func vcliLocalIssues(t *testing.T, ws, home string) string {
	t.Helper()
	out, ok := vcliRun(t, ws, home, nil, "list")
	if !ok {
		t.Fatalf("bd list with no host set failed; output:\n%s", out)
	}
	return out
}

// vcliWantServer checks that bd reported a failed connection to the host on the
// standard port.
func vcliWantServer(t *testing.T, what, host, out string, ok bool) {
	t.Helper()
	if ok {
		t.Errorf("%s exited 0, want a failure to reach %s; output:\n%s", what, host, out)
	}
	if !strings.Contains(out, host) || !strings.Contains(out, "3307") {
		t.Errorf("%s output doesn't report the server at %s on port 3307; output:\n%s", what, host, out)
	}
	if strings.Contains(out, vcliStalePort) {
		t.Errorf("%s output reports the local server's leftover port %s; output:\n%s", what, vcliStalePort, out)
	}
}

// vcliWantNoEmbedded checks that no embedded database appeared under .beads.
func vcliWantNoEmbedded(t *testing.T, what, ws, out string) {
	t.Helper()
	if _, err := os.Stat(filepath.Join(ws, ".beads", "embeddeddolt")); err == nil {
		t.Errorf("%s created an embedded database under .beads for a workspace whose server is on another machine; output:\n%s", what, out)
	}
}

// vcliWriteAndRead runs bd create and bd list with the host set, and checks that
// both go to the server. local reads the embedded store afterwards.
func vcliWriteAndRead(t *testing.T, ws, home string, env map[string]string, title string, local func() string) {
	t.Helper()
	out, ok := vcliRun(t, ws, home, env, "create", title)
	vcliWantServer(t, "bd create", vcliRemoteHost, out, ok)
	out2, ok2 := vcliRun(t, ws, home, env, "list")
	vcliWantServer(t, "bd list", vcliRemoteHost, out2, ok2)
	if strings.Contains(out2, "vcli-seed-issue") {
		t.Errorf("bd list showed the embedded store's issue; output:\n%s", out2)
	}
	if issues := local(); strings.Contains(issues, title) {
		t.Errorf("bd create wrote %q to the embedded store; bd create said:\n%s\nembedded store holds:\n%s", title, out, issues)
	}
}

// TestVerifyCLIRemoteHostOnInitWorkspace: the workspace bd init leaves behind
// (dolt_mode: embedded) with BEADS_DOLT_SERVER_HOST pointing elsewhere.
func TestVerifyCLIRemoteHostOnInitWorkspace(t *testing.T) {
	vcliShare(t)
	ws, home := vcliInitWorkspace(t)
	env := map[string]string{"BEADS_DOLT_SERVER_HOST": vcliRemoteHost}
	local := func() string { return vcliLocalIssues(t, ws, home) }

	t.Run("recorded_embedded_mode", func(t *testing.T) {
		vcliWriteAndRead(t, ws, home, env, "vcli-remote-write-one", local)
	})

	t.Run("leftover_port_file", func(t *testing.T) {
		vcliWriteBeadsFile(t, ws, "dolt-server.port", vcliStalePort)
		defer os.Remove(filepath.Join(ws, ".beads", "dolt-server.port"))
		vcliWriteAndRead(t, ws, home, env, "vcli-remote-write-two", local)
	})

	t.Run("embedded_mode_in_config_yaml", func(t *testing.T) {
		yaml := vcliReadBeadsFile(t, ws, "config.yaml")
		vcliWriteBeadsFile(t, ws, "config.yaml", yaml+"\ndolt.mode: embedded\n")
		defer vcliWriteBeadsFile(t, ws, "config.yaml", yaml)
		vcliWriteAndRead(t, ws, home, env, "vcli-remote-write-three", local)
	})
}

// TestVerifyCLIOlderWorkspace: a workspace with no recorded mode and the host in
// metadata.json or in config.yaml.
func TestVerifyCLIOlderWorkspace(t *testing.T) {
	vcliShare(t)
	ws, home := vcliInitWorkspace(t)
	vcliForgetRecordedMode(t, ws)
	metadata := vcliReadBeadsFile(t, ws, "metadata.json")
	yaml := vcliReadBeadsFile(t, ws, "config.yaml")

	// local puts the two files back before reading, since the files name the host.
	restore := func() {
		vcliWriteBeadsFile(t, ws, "metadata.json", metadata)
		vcliWriteBeadsFile(t, ws, "config.yaml", yaml)
	}
	local := func() string {
		restore()
		return vcliLocalIssues(t, ws, home)
	}
	hostInMetadata := func() {
		var meta map[string]any
		if err := json.Unmarshal([]byte(metadata), &meta); err != nil {
			t.Fatal(err)
		}
		meta["dolt_server_host"] = vcliRemoteHost
		vcliWriteMetadata(t, ws, meta)
	}
	hostInYAML := func() {
		vcliWriteBeadsFile(t, ws, "config.yaml", yaml+"\ndolt.host: "+vcliRemoteHost+"\n")
	}

	check := func(t *testing.T, setHost func(), title string) {
		t.Helper()
		setHost()
		defer restore()
		out, ok := vcliRun(t, ws, home, nil, "create", title)
		vcliWantServer(t, "bd create", vcliRemoteHost, out, ok)
		setHost()
		out2, ok2 := vcliRun(t, ws, home, nil, "list")
		vcliWantServer(t, "bd list", vcliRemoteHost, out2, ok2)
		if issues := local(); strings.Contains(issues, title) {
			t.Errorf("bd create wrote %q to the embedded store; bd create said:\n%s\nembedded store holds:\n%s", title, out, issues)
		}
	}

	t.Run("host_in_metadata_json", func(t *testing.T) { check(t, hostInMetadata, "vcli-older-write-one") })
	t.Run("host_in_config_yaml", func(t *testing.T) { check(t, hostInYAML, "vcli-older-write-two") })

	t.Run("host_in_metadata_json_leftover_port_file", func(t *testing.T) {
		vcliWriteBeadsFile(t, ws, "dolt-server.port", vcliStalePort)
		defer os.Remove(filepath.Join(ws, ".beads", "dolt-server.port"))
		check(t, hostInMetadata, "vcli-older-write-three")
	})

	t.Run("host_in_config_yaml_leftover_port_file", func(t *testing.T) {
		vcliWriteBeadsFile(t, ws, "dolt-server.port", vcliStalePort)
		defer os.Remove(filepath.Join(ws, ".beads", "dolt-server.port"))
		check(t, hostInYAML, "vcli-older-write-four")
	})
}

// TestVerifyCLIFolderWithoutMetadata: a .beads folder with a config.yaml and no
// metadata.json, the host in that file or in the environment.
func TestVerifyCLIFolderWithoutMetadata(t *testing.T) {
	vcliShare(t)
	shapes := []struct {
		name string
		yaml string
		env  map[string]string
	}{
		{"host_in_config_yaml", "dolt.host: " + vcliRemoteHost + "\n", nil},
		{"host_in_environment", "", map[string]string{"BEADS_DOLT_SERVER_HOST": vcliRemoteHost}},
	}
	commands := []struct {
		name string
		args []string
	}{
		{"create", []string{"create", "vcli-folder-write"}},
		{"list", []string{"list"}},
		{"human_list", []string{"human", "list"}},
	}
	for _, shape := range shapes {
		shape := shape
		for _, command := range commands {
			command := command
			t.Run(shape.name+"_"+command.name, func(t *testing.T) {
				ws, home := vcliFolders(t)
				vcliWriteBeadsFile(t, ws, "config.yaml", shape.yaml)
				what := "bd " + strings.Join(command.args, " ")
				out, ok := vcliRun(t, ws, home, shape.env, command.args...)
				vcliWantServer(t, what, vcliRemoteHost, out, ok)
				vcliWantNoEmbedded(t, what, ws, out)
			})
		}
	}

	for _, command := range commands {
		command := command
		t.Run("no_host_"+command.name, func(t *testing.T) {
			ws, home := vcliFolders(t)
			vcliWriteBeadsFile(t, ws, "config.yaml", "")
			out, _ := vcliRun(t, ws, home, nil, command.args...)
			if strings.Contains(out, "3307") || strings.Contains(strings.ToLower(out), "unreachable") {
				t.Errorf("bd %s tried to reach a server in a workspace with no host configured; output:\n%s", strings.Join(command.args, " "), out)
			}
		})
	}
}

// TestVerifyCLIRoutedRead: bd list in a contributor workspace, auto-routed to a
// second repository whose .beads folder has no metadata.json, with the host in
// the contributor workspace's config.yaml.
func TestVerifyCLIRoutedRead(t *testing.T) {
	vcliShare(t)
	ws, home := vcliInitWorkspace(t)
	target := filepath.Join(filepath.Dir(ws), "target")
	if err := os.MkdirAll(target, 0o700); err != nil {
		t.Fatal(err)
	}
	vcliGit(t, target, "init", "-q")
	vcliWriteBeadsFile(t, target, "config.yaml", "")
	vcliGit(t, ws, "config", "beads.role", "contributor")
	yaml := vcliReadBeadsFile(t, ws, "config.yaml")
	vcliWriteBeadsFile(t, ws, "config.yaml", yaml+"\ndolt.host: "+vcliRemoteHost+"\nrouting.mode: auto\nrouting.contributor: "+target+"\n")

	out, ok := vcliRun(t, ws, home, nil, "list")
	vcliWantServer(t, "routed bd list", vcliRemoteHost, out, ok)
	vcliWantNoEmbedded(t, "routed bd list", target, out)
}

// TestVerifyCLINoCgoBuild: a bd built with CGO_ENABLED=0 in a .beads folder with
// no metadata.json and the host in the environment.
func TestVerifyCLINoCgoBuild(t *testing.T) {
	vcliShare(t)
	bin := vcliBuildNoCgo(t)
	env := map[string]string{"BEADS_DOLT_SERVER_HOST": vcliRemoteHost}
	for _, args := range [][]string{{"create", "vcli-nocgo-write"}, {"list"}, {"human", "list"}} {
		args := args
		what := "bd " + strings.Join(args, " ")
		t.Run(args[0], func(t *testing.T) {
			ws, home := vcliFolders(t)
			vcliWriteBeadsFile(t, ws, "config.yaml", "")
			out, ok := vcliRunWith(t, bin, ws, home, env, args...)
			vcliWantServer(t, what, vcliRemoteHost, out, ok)
		})
	}
}

// TestVerifyCLIHostsOfThisMachine: on a bd init workspace, a host that means this
// machine leaves bd create and bd list on the embedded store.
func TestVerifyCLIHostsOfThisMachine(t *testing.T) {
	vcliShare(t)
	ws, home := vcliInitWorkspace(t)
	for _, host := range []string{"localhost", "127.0.0.1", "::1", "0.0.0.0"} {
		host := host
		t.Run(host, func(t *testing.T) {
			env := map[string]string{"BEADS_DOLT_SERVER_HOST": host}
			title := "vcli-local-" + strings.ReplaceAll(host, ":", "-")
			if out, ok := vcliRun(t, ws, home, env, "create", title); !ok {
				t.Fatalf("bd create with BEADS_DOLT_SERVER_HOST=%s failed; output:\n%s", host, out)
			}
			out, ok := vcliRun(t, ws, home, env, "list")
			if !ok || !strings.Contains(out, title) {
				t.Errorf("bd list with BEADS_DOLT_SERVER_HOST=%s doesn't show %q (exit ok: %v); output:\n%s", host, title, ok, out)
			}
			if issues := vcliLocalIssues(t, ws, home); !strings.Contains(issues, title) {
				t.Errorf("%q isn't in the embedded store; output:\n%s", title, issues)
			}
		})
	}
}

// A mention of the start command counts as advice unless the words right next
// to it say the command doesn't apply: "`bd dolt start` only runs a server on
// this machine" or "don't run bd dolt start".
var (
	vcliStartCommand   = regexp.MustCompile(`bd dolt start`)
	vcliDeclinedAfter  = regexp.MustCompile("(?i)^['\"`]?\\s*(?:only\\b|won't\\b|wouldn't\\b|can't\\b|cannot\\b|can not\\b|doesn't\\b|does not\\b|will not\\b|would\\b|isn't\\b|is not\\b|(?:is|runs|starts|manages|handles|works|applies)\\s+(?:only\\b|just\\b|locally\\b|on this\\b|for local\\b|a local\\b|local\\b))")
	vcliDeclinedBefore = regexp.MustCompile("(?i)(?:\\bnot|\\bdon't|\\bwon't|\\bnever|\\bavoid|\\binstead of|\\bwithout)(?:\\s+(?:run|use|running|using|call|try|need))?\\s+['\"`]?$")
)

// vcliStartAdvice returns the line of out that tells the reader to run the start
// command, or "" when no line does.
func vcliStartAdvice(out string) string {
	for _, line := range strings.Split(out, "\n") {
		for _, loc := range vcliStartCommand.FindAllStringIndex(line, -1) {
			if vcliDeclinedAfter.MatchString(line[loc[1]:]) || vcliDeclinedBefore.MatchString(line[:loc[0]]) {
				continue
			}
			return strings.TrimSpace(line)
		}
	}
	return ""
}

// TestVerifyCLIUnreachableMessage: what bd prints when the server doesn't answer.
// The IPv6 documentation address has no route, so its dial fails at the dial
// itself, with or without a sandbox proxy for outbound traffic.
func TestVerifyCLIUnreachableMessage(t *testing.T) {
	vcliShare(t)
	const metadata = `{"database": "dolt", "backend": "dolt", "dolt_mode": "embedded", "dolt_database": "vcli"}` + "\n"

	for _, args := range [][]string{{"create", "vcli-message-write"}, {"list"}} {
		args := args
		t.Run("remote_host_"+args[0], func(t *testing.T) {
			ws, home := vcliFolders(t)
			vcliWriteBeadsFile(t, ws, "metadata.json", metadata)
			host := "2001:db8::10"
			out, ok := vcliRun(t, ws, home, map[string]string{"BEADS_DOLT_SERVER_HOST": host}, args...)
			if ok {
				t.Errorf("bd %s exited 0, want a failure to reach %s; output:\n%s", args[0], host, out)
			}
			if !strings.Contains(out, host) {
				t.Errorf("bd %s output doesn't name %s; output:\n%s", args[0], host, out)
			}
			if line := vcliStartAdvice(out); line != "" {
				t.Errorf("bd %s tells the reader to run bd dolt start for a server on another machine, in %q; output:\n%s", args[0], line, out)
			}
		})
	}

	for _, host := range []string{"localhost", "127.0.0.1", "::1", "0.0.0.0"} {
		host := host
		t.Run("local_host_"+host, func(t *testing.T) {
			ws, home := vcliFolders(t)
			vcliWriteBeadsFile(t, ws, "metadata.json", metadata)
			env := map[string]string{
				"BEADS_DOLT_SERVER_MODE": "1",
				"BEADS_DOLT_SERVER_HOST": host,
				"BEADS_DOLT_SERVER_PORT": "1",
				"BEADS_DOLT_AUTO_START":  "0",
			}
			out, ok := vcliRun(t, ws, home, env, "list")
			if ok {
				t.Errorf("bd list exited 0 with nothing listening on port 1; output:\n%s", out)
			}
			if vcliStartAdvice(out) == "" {
				t.Errorf("bd list should still tell the reader to run bd dolt start for a server on this machine (%s); output:\n%s", host, out)
			}
		})
	}
}
