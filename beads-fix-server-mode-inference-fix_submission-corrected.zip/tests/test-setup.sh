#!/usr/bin/env bash
# Verifier-phase setup for beads-fix-server-mode-inference.
#
# The image already carries every Go module the repository needs (GOMODCACHE
# warm, build tree compiled in image block 7), so there is nothing to install
# here. The exports below make a module cache miss fail fast instead of
# hanging on a network the container doesn't have.
#
# GOPROXY=off forbids module downloads, GOFLAGS=-mod=mod keeps the build
# working against the warm module cache without demanding go.sum network checks.
set -euo pipefail

export GOFLAGS=-mod=mod
export GOPROXY=off
export GOTOOLCHAIN=local

echo "[test-setup] beads-fix-server-mode-inference: deps baked into image; Go offline switches set"
