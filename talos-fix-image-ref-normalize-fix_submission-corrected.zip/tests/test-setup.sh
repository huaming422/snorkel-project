#!/usr/bin/env bash
# Every Go module the verify package and its tests import is already in the
# image's module cache, so they compile with no network. Nothing to install
# here.
set -euo pipefail
echo "[test-setup] no-op for talos-fix-image-ref-normalize"
