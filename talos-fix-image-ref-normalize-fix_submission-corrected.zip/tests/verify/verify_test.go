// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.

// Image verification decisions for image references written in different but
// equivalent ways. Rules go in through the machine config, the way a node gets
// them: the ImageVerificationConfig document is handed to the image verification
// config controller. Decisions come from the machine API's image Verify call and
// from image.Pull, with registry mirror settings that point at local test
// registries, and pulls talk to a stand-in containerd daemon.
package verify_test

import (
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha256"
	"crypto/x509"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"encoding/pem"
	"fmt"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"

	introspectionapi "github.com/containerd/containerd/api/services/introspection/v1"
	leasesapi "github.com/containerd/containerd/api/services/leases/v1"
	namespacesapi "github.com/containerd/containerd/api/services/namespaces/v1"
	containerd "github.com/containerd/containerd/v2/client"
	"github.com/containerd/containerd/v2/pkg/namespaces"
	"github.com/cosi-project/runtime/pkg/controller/runtime"
	"github.com/cosi-project/runtime/pkg/safe"
	"github.com/cosi-project/runtime/pkg/state"
	"github.com/cosi-project/runtime/pkg/state/impl/inmem"
	"github.com/cosi-project/runtime/pkg/state/impl/namespaced"
	digest "github.com/opencontainers/go-digest"
	ocispecs "github.com/opencontainers/image-spec/specs-go"
	ocispec "github.com/opencontainers/image-spec/specs-go/v1"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.uber.org/zap"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/types/known/emptypb"

	"github.com/siderolabs/talos/internal/app/images"
	securityctrl "github.com/siderolabs/talos/internal/app/machined/pkg/controllers/security"
	talosruntime "github.com/siderolabs/talos/internal/app/machined/pkg/runtime"
	"github.com/siderolabs/talos/internal/pkg/containers/image"
	"github.com/siderolabs/talos/pkg/machinery/api/machine"
	"github.com/siderolabs/talos/pkg/machinery/config/container"
	securitycfg "github.com/siderolabs/talos/pkg/machinery/config/types/security"
	configres "github.com/siderolabs/talos/pkg/machinery/resources/config"
	"github.com/siderolabs/talos/pkg/machinery/resources/cri"
	"github.com/siderolabs/talos/pkg/machinery/resources/security"
)

// vrefScaled stretches a time limit by TIMEOUT_MULTIPLIER on slow hosts.
func vrefScaled(d time.Duration) time.Duration {
	m, err := strconv.ParseFloat(os.Getenv("TIMEOUT_MULTIPLIER"), 64)
	if err != nil || m < 1 {
		m = 1
	}

	return time.Duration(float64(d) * m)
}

func vrefDeny(pattern string) securitycfg.ImageVerificationRuleV1Alpha1 {
	return securitycfg.ImageVerificationRuleV1Alpha1{RuleImagePattern: pattern, RuleDeny: new(true)}
}

func vrefSkip(pattern string) securitycfg.ImageVerificationRuleV1Alpha1 {
	return securitycfg.ImageVerificationRuleV1Alpha1{RuleImagePattern: pattern, RuleSkip: new(true)}
}

func vrefSigned(pattern, publicKeyPEM string) securitycfg.ImageVerificationRuleV1Alpha1 {
	return securitycfg.ImageVerificationRuleV1Alpha1{
		RuleImagePattern:      pattern,
		RulePublicKeyVerifier: &securitycfg.ImagePublicKeyVerifierV1Alpha1{ConfigCertificate: publicKeyPEM},
	}
}

// vrefRulesState is a node whose registry settings send every registry to an
// empty local registry, with the rules applied.
func vrefRulesState(t *testing.T, rules ...securitycfg.ImageVerificationRuleV1Alpha1) state.State {
	t.Helper()

	nowhere := vrefNewRegistry(t, "catch-all", "nothing")

	return vrefNode(t, cri.RegistriesConfigSpec{
		RegistryMirrors: map[string]*cri.RegistryMirrorConfig{
			"*": {MirrorEndpoints: []cri.RegistryEndpointConfig{{EndpointEndpoint: nowhere.srv.URL}}, MirrorSkipFallback: true},
		},
	}, rules...)
}

// vrefNode holds the registry settings of a node and applies the rules as an
// ImageVerificationConfig document of the machine config, then waits until the
// controller has stored one rule per entry.
func vrefNode(t *testing.T, registries cri.RegistriesConfigSpec, rules ...securitycfg.ImageVerificationRuleV1Alpha1) state.State {
	t.Helper()

	ctx, cancel := context.WithCancel(context.Background())

	st := state.WrapCore(namespaced.NewState(inmem.Build))

	rt, err := runtime.NewRuntime(st, zap.NewNop())
	require.NoError(t, err)
	require.NoError(t, rt.RegisterController(&securityctrl.ImageVerificationConfigController{}))

	done := make(chan error, 1)

	go func() { done <- rt.Run(ctx) }()

	t.Cleanup(func() {
		cancel()
		<-done
	})

	registriesConfig := cri.NewRegistriesConfig()
	*registriesConfig.TypedSpec() = registries
	require.NoError(t, st.Create(ctx, registriesConfig))

	doc := securitycfg.NewImageVerificationConfigV1Alpha1()
	doc.ConfigRules = rules

	cont, err := container.New(doc)
	require.NoError(t, err)
	require.NoError(t, st.Create(ctx, configres.NewMachineConfig(cont)))

	deadline := time.Now().Add(vrefScaled(30 * time.Second))

	for {
		stored, err := safe.StateListAll[*security.ImageVerificationRule](ctx, st)
		require.NoError(t, err)

		if stored.Len() == len(rules) {
			return st
		}

		if time.Now().After(deadline) {
			t.Fatalf("the controller stored %d image verification rules, expected %d", stored.Len(), len(rules))
		}

		time.Sleep(10 * time.Millisecond)
	}
}

// The vrefMachined types hand the machine API's image service the node's
// resource state, which is all its Verify call reads.
type vrefMachined struct {
	talosruntime.Controller

	st state.State
}

func (m vrefMachined) Runtime() talosruntime.Runtime { return vrefMachinedRuntime{st: m.st} }

type vrefMachinedRuntime struct {
	talosruntime.Runtime

	st state.State
}

func (r vrefMachinedRuntime) State() talosruntime.State { return vrefMachinedState{st: r.st} }

type vrefMachinedState struct {
	talosruntime.State

	st state.State
}

func (s vrefMachinedState) V1Alpha2() talosruntime.V1Alpha2State {
	return vrefMachinedResources{st: s.st}
}

type vrefMachinedResources struct {
	talosruntime.V1Alpha2State

	st state.State
}

func (r vrefMachinedResources) Resources() state.State { return r.st }

// vrefVerifyAPI asks the machine API's image Verify call about the reference.
func vrefVerifyAPI(ctx context.Context, st state.State, imageRef string) (*machine.ImageServiceVerifyResponse, error) {
	return images.NewService(vrefMachined{st: st}, zap.NewNop()).Verify(ctx, &machine.ImageServiceVerifyRequest{ImageRef: imageRef})
}

func vrefDecide(st state.State, imageRef string) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), vrefScaled(30*time.Second))
	defer cancel()

	resp, err := vrefVerifyAPI(ctx, st, imageRef)
	if err != nil {
		return "", err
	}

	return fmt.Sprintf("verified=%v message=%q", resp.GetVerified(), resp.GetMessage()), nil
}

func vrefRequireDenied(t *testing.T, st state.State, imageRef string) {
	t.Helper()

	got, err := vrefDecide(st, imageRef)

	require.Error(t, err, "%q is covered by a deny rule, got %s", imageRef, got)
	assert.Equal(t, codes.PermissionDenied, status.Code(err), "%q is covered by a deny rule: %v", imageRef, err)
}

func vrefDenyRules(t *testing.T) state.State {
	return vrefRulesState(t,
		vrefDeny("registry.k8s.io/*"),
		vrefDeny("docker.io/library/busybox*"),
		vrefDeny("docker.io/library/nginx"),
		vrefDeny("localhost:5000/*"),
	)
}

// A deny rule written the way the configuration reference shows it stops its
// image under every spelling of the reference that names that image.
func TestVrefDenyRuleCoversEverySpelling(t *testing.T) {
	st := vrefDenyRules(t)

	for _, imageRef := range []string{
		"registry.k8s.io/pause:3.9",
		"localhost:5000/tools/app:1",
		"docker.io/library/busybox:1.36",
		"busybox:1.36",
		"index.docker.io/library/busybox:1.36",
		"registry-1.docker.io/library/busybox:1.36",
		"docker.io/busybox:1.36",
		"busybox@sha256:7031c1b283388d2c2e09b57badb803c05ebed362dc88d84b480cc47f72a21097",
		"nginx:1.27",
		"docker.io/library/nginx@sha256:7031c1b283388d2c2e09b57badb803c05ebed362dc88d84b480cc47f72a21097",
	} {
		t.Run(imageRef, func(t *testing.T) {
			vrefRequireDenied(t, st, imageRef)
		})
	}
}

// A registry name is a DNS name, so writing it in capitals names the same
// registry and the same image.
func TestVrefRegistryNameCaseDoesNotMatter(t *testing.T) {
	st := vrefDenyRules(t)

	for _, imageRef := range []string{
		"REGISTRY.K8S.IO/pause:3.9",
		"Registry.K8s.Io/pause:3.9",
		"DOCKER.IO/library/busybox:1.36",
		"INDEX.DOCKER.IO/busybox:1.36",
		"LOCALHOST:5000/tools/app:1",
	} {
		t.Run(imageRef, func(t *testing.T) {
			vrefRequireDenied(t, st, imageRef)
		})
	}
}

// A rule that names its registry another way stops the same images: rules
// written against index.docker.io keep working, and a registry named in
// capitals or as registry-1.docker.io in a rule is the same registry too.
func TestVrefRulesNamingTheRegistryOtherwise(t *testing.T) {
	busybox := []string{
		"busybox:1.36",
		"docker.io/library/busybox:1.36",
		"index.docker.io/library/busybox:1.36",
	}

	for _, tc := range []struct {
		pattern   string
		imageRefs []string
	}{
		{"index.docker.io/library/busybox*", busybox},
		{"registry-1.docker.io/library/busybox*", busybox},
		{"INDEX.DOCKER.IO/library/busybox*", busybox},
		{"REGISTRY.K8S.IO/*", []string{"registry.k8s.io/pause:3.9"}},
	} {
		t.Run(tc.pattern, func(t *testing.T) {
			st := vrefRulesState(t, vrefDeny(tc.pattern))

			for _, imageRef := range tc.imageRefs {
				t.Run(imageRef, func(t *testing.T) {
					vrefRequireDenied(t, st, imageRef)
				})
			}
		})
	}
}

// A reference that no rule covers is allowed, and nothing about it is matched
// against a rule it doesn't fall under: not its tag, not a registry name that
// only starts like a rule's, not another namespace on Docker Hub.
func TestVrefUnmatchedReferencesStayAllowed(t *testing.T) {
	st := vrefDenyRules(t)

	for _, imageRef := range []string{
		"quay.io/some/image:v1.0.0",
		"ghcr.io/siderolabs/kubelet:v1.34.1",
		"quay.io/registry.k8s.io:latest",
		"registry.k8s.io.example.com/pause:3.9",
		"docker.io/library/alpine:3.19",
		"nginx-unprivileged:1.27",
		"myuser/busybox:1.36",
	} {
		t.Run(imageRef, func(t *testing.T) {
			ctx, cancel := context.WithTimeout(context.Background(), vrefScaled(30*time.Second))
			defer cancel()

			resp, err := vrefVerifyAPI(ctx, st, imageRef)

			require.NoError(t, err, "%q matches no rule and is allowed", imageRef)
			require.NotNil(t, resp)
			assert.False(t, resp.GetVerified(), "%q matches no rule, so it is allowed without being marked verified", imageRef)
		})
	}
}

// Only the registry name is case-insensitive: a repository path with capitals
// is not a valid reference.
func TestVrefUppercaseRepositoryStaysInvalid(t *testing.T) {
	st := vrefDenyRules(t)

	for _, imageRef := range []string{
		"registry.k8s.io/Pause:3.9",
		"docker.io/library/BusyBox:1.36",
		"Foo/bar:1",
	} {
		t.Run(imageRef, func(t *testing.T) {
			got, err := vrefDecide(st, imageRef)

			require.Error(t, err, "%q is not a valid reference, got %s", imageRef, got)
			assert.Equal(t, codes.InvalidArgument, status.Code(err), "%q is not a valid reference: %v", imageRef, err)
		})
	}
}

// vrefRegistry is a small OCI registry for one repository, which records every
// request it gets.
type vrefRegistry struct {
	name string
	repo string

	mu        sync.Mutex
	hits      []string
	manifests map[string]vrefContent
	blobs     map[string]vrefContent

	srv *httptest.Server
}

type vrefContent struct {
	mediaType string
	body      []byte
}

func vrefDigest(body []byte) string {
	sum := sha256.Sum256(body)

	return "sha256:" + hex.EncodeToString(sum[:])
}

func vrefNewRegistry(t *testing.T, name, repo string) *vrefRegistry {
	r := &vrefRegistry{
		name:      name,
		repo:      repo,
		manifests: map[string]vrefContent{},
		blobs:     map[string]vrefContent{},
	}

	r.srv = httptest.NewServer(http.HandlerFunc(r.serve))
	t.Cleanup(r.srv.Close)

	return r
}

func (r *vrefRegistry) serve(w http.ResponseWriter, req *http.Request) {
	r.mu.Lock()
	r.hits = append(r.hits, req.Method+" "+req.URL.Path)
	r.mu.Unlock()

	if req.URL.Path == "/v2/" || req.URL.Path == "/v2" {
		w.WriteHeader(http.StatusOK)

		return
	}

	rest, ok := strings.CutPrefix(req.URL.Path, "/v2/"+r.repo+"/")
	if !ok {
		http.NotFound(w, req)

		return
	}

	var (
		content vrefContent
		found   bool
	)

	r.mu.Lock()

	if ref, isManifest := strings.CutPrefix(rest, "manifests/"); isManifest {
		content, found = r.manifests[ref]
	} else if dgst, isBlob := strings.CutPrefix(rest, "blobs/"); isBlob {
		content, found = r.blobs[dgst]
	}

	r.mu.Unlock()

	if !found {
		http.NotFound(w, req)

		return
	}

	w.Header().Set("Content-Type", content.mediaType)
	w.Header().Set("Docker-Content-Digest", vrefDigest(content.body))
	w.Header().Set("Content-Length", strconv.Itoa(len(content.body)))
	w.WriteHeader(http.StatusOK)

	if req.Method != http.MethodHead {
		w.Write(content.body) //nolint:errcheck
	}
}

func (r *vrefRegistry) take() []string {
	r.mu.Lock()
	defer r.mu.Unlock()

	hits := r.hits
	r.hits = nil

	return hits
}

func vrefManifest(t *testing.T, config ocispec.Descriptor, layers ...ocispec.Descriptor) []byte {
	if layers == nil {
		layers = []ocispec.Descriptor{}
	}

	body, err := json.Marshal(ocispec.Manifest{
		Versioned: ocispecs.Versioned{SchemaVersion: 2},
		MediaType: ocispec.MediaTypeImageManifest,
		Config:    config,
		Layers:    layers,
	})
	require.NoError(t, err)

	return body
}

// addImage stores an image under the tag and returns its manifest digest. A
// signed image also gets a cosign signature stored under the .sig tag; a
// lagging one has its signature manifest served by that tag only, not yet by
// its digest.
func (r *vrefRegistry) addImage(t *testing.T, tag, dockerReference string, key *ecdsa.PrivateKey, lagging bool) string {
	r.mu.Lock()
	defer r.mu.Unlock()

	config := []byte(`{"architecture":"amd64","os":"linux","tag":"` + tag + `"}`)
	configDesc := ocispec.Descriptor{MediaType: ocispec.MediaTypeImageConfig, Digest: vrefDigestOf(config), Size: int64(len(config))}
	r.blobs[configDesc.Digest.String()] = vrefContent{mediaType: ocispec.MediaTypeImageConfig, body: config}

	manifest := vrefManifest(t, configDesc)
	manifestDigest := vrefDigest(manifest)
	r.manifests[tag] = vrefContent{mediaType: ocispec.MediaTypeImageManifest, body: manifest}
	r.manifests[manifestDigest] = r.manifests[tag]

	if key == nil {
		return manifestDigest
	}

	payload := fmt.Appendf(nil,
		`{"critical":{"identity":{"docker-reference":%q},"image":{"docker-manifest-digest":%q},"type":"cosign container image signature"},"optional":null}`,
		dockerReference, manifestDigest)
	payloadSum := sha256.Sum256(payload)

	signature, err := ecdsa.SignASN1(rand.Reader, key, payloadSum[:])
	require.NoError(t, err)

	payloadDigest := vrefDigest(payload)
	r.blobs[payloadDigest] = vrefContent{mediaType: "application/vnd.dev.cosign.simplesigning.v1+json", body: payload}

	signatureManifest := vrefManifest(t, configDesc, ocispec.Descriptor{
		MediaType:   "application/vnd.dev.cosign.simplesigning.v1+json",
		Digest:      vrefDigestOf(payload),
		Size:        int64(len(payload)),
		Annotations: map[string]string{"dev.cosignproject.cosign/signature": base64.StdEncoding.EncodeToString(signature)},
	})

	signatureTag := strings.ReplaceAll(manifestDigest, ":", "-") + ".sig"
	r.manifests[signatureTag] = vrefContent{mediaType: ocispec.MediaTypeImageManifest, body: signatureManifest}

	if !lagging {
		r.manifests[vrefDigest(signatureManifest)] = r.manifests[signatureTag]
	}

	return manifestDigest
}

func vrefDigestOf(body []byte) digest.Digest {
	return digest.Digest(vrefDigest(body))
}

func vrefKey(t *testing.T) (*ecdsa.PrivateKey, string) {
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	require.NoError(t, err)

	der, err := x509.MarshalPKIXPublicKey(&key.PublicKey)
	require.NoError(t, err)

	return key, string(pem.EncodeToMemory(&pem.Block{Type: "PUBLIC KEY", Bytes: der}))
}

// vrefMirrors is the registry setup of a node that reaches no public registry:
// Docker Hub and registry.k8s.io each come from a mirror configured under their
// own name, and every other registry goes to a catch-all that holds no images,
// so a lookup that leaves the configured mirror finds nothing and is counted.
type vrefMirrors struct {
	hub, k8s, elsewhere *vrefRegistry

	registries   cri.RegistriesConfigSpec
	publicKeyPEM string

	signedBusybox, laggingBusybox, signedPause, laggingPause string
}

func vrefNewMirrors(t *testing.T) *vrefMirrors {
	key, publicKeyPEM := vrefKey(t)

	m := &vrefMirrors{
		hub:          vrefNewRegistry(t, "docker.io mirror", "library/busybox"),
		k8s:          vrefNewRegistry(t, "registry.k8s.io mirror", "pause"),
		elsewhere:    vrefNewRegistry(t, "catch-all", "nothing"),
		publicKeyPEM: publicKeyPEM,
	}

	m.signedBusybox = m.hub.addImage(t, "1.36", "docker.io/library/busybox", key, false)
	m.hub.addImage(t, "1.37", "", nil, false)
	m.laggingBusybox = m.hub.addImage(t, "1.38", "docker.io/library/busybox", key, true)

	m.signedPause = m.k8s.addImage(t, "3.9", "registry.k8s.io/pause", key, false)
	m.laggingPause = m.k8s.addImage(t, "3.10", "registry.k8s.io/pause", key, true)

	m.registries = cri.RegistriesConfigSpec{
		RegistryMirrors: map[string]*cri.RegistryMirrorConfig{
			"docker.io": {
				MirrorEndpoints:    []cri.RegistryEndpointConfig{{EndpointEndpoint: m.hub.srv.URL}},
				MirrorSkipFallback: true,
			},
			"registry.k8s.io": {
				MirrorEndpoints:    []cri.RegistryEndpointConfig{{EndpointEndpoint: m.k8s.srv.URL}},
				MirrorSkipFallback: true,
			},
			"*": {
				MirrorEndpoints:    []cri.RegistryEndpointConfig{{EndpointEndpoint: m.elsewhere.srv.URL}},
				MirrorSkipFallback: true,
			},
		},
	}

	return m
}

func (m *vrefMirrors) reset() {
	m.hub.take()
	m.k8s.take()
	m.elsewhere.take()
}

// Signed images come from the registry mirror configured for their registry,
// for every lookup the verification makes and for the digested reference it
// hands back to be pulled, however the reference was written.
func TestVrefSignedImageComesThroughItsMirror(t *testing.T) {
	m := vrefNewMirrors(t)
	hub, k8s, elsewhere := m.hub, m.k8s, m.elsewhere
	signedBusybox, laggingBusybox, signedPause, laggingPause := m.signedBusybox, m.laggingBusybox, m.signedPause, m.laggingPause
	publicKeyPEM := m.publicKeyPEM

	resolver := image.NewResolver(m.registries)

	type signedCase struct {
		imageRef string
		mirror   *vrefRegistry
		digest   string
	}

	signed := []signedCase{
		{"docker.io/library/busybox:1.36", hub, signedBusybox},
		{"busybox:1.36", hub, signedBusybox},
		{"index.docker.io/library/busybox:1.36", hub, signedBusybox},
		{"registry-1.docker.io/library/busybox:1.36", hub, signedBusybox},
		{"DOCKER.IO/library/busybox:1.36", hub, signedBusybox},
		{"busybox@" + signedBusybox, hub, signedBusybox},
		{"registry.k8s.io/pause:3.9", k8s, signedPause},
		{"REGISTRY.K8S.IO/pause:3.9", k8s, signedPause},
		{"docker.io/library/busybox:1.38", hub, laggingBusybox},
		{"registry.k8s.io/pause:3.10", k8s, laggingPause},
	}

	unsigned := []string{
		"docker.io/library/busybox:1.37",
		"busybox:1.37",
		"index.docker.io/library/busybox:1.37",
	}

	for _, ruleSet := range []struct {
		name  string
		rules []securitycfg.ImageVerificationRuleV1Alpha1
	}{
		{"every image needs a signature", []securitycfg.ImageVerificationRuleV1Alpha1{vrefSigned("*", publicKeyPEM)}},
		{"rules name the registry", []securitycfg.ImageVerificationRuleV1Alpha1{
			vrefSigned("docker.io/library/busybox*", publicKeyPEM),
			vrefSigned("registry.k8s.io/*", publicKeyPEM),
		}},
	} {
		t.Run(ruleSet.name, func(t *testing.T) {
			st := vrefNode(t, m.registries, ruleSet.rules...)

			for _, tc := range signed {
				t.Run(tc.imageRef, func(t *testing.T) {
					m.reset()

					ctx, cancel := context.WithTimeout(context.Background(), vrefScaled(60*time.Second))
					defer cancel()

					resp, err := vrefVerifyAPI(ctx, st, tc.imageRef)
					require.NoError(t, err, "%q is signed and its signature is on the %s; lookups that went elsewhere: %v",
						tc.imageRef, tc.mirror.name, elsewhere.take())
					require.NotNil(t, resp)
					require.True(t, resp.GetVerified(), "%q falls under a signature rule and is signed, got %q", tc.imageRef, resp.GetMessage())
					require.True(t, strings.HasSuffix(resp.GetDigestedImageRef(), "@"+tc.digest),
						"the reference handed back to be pulled has to carry the verified digest %s, got %q", tc.digest, resp.GetDigestedImageRef())

					// the pull fetches the image by the reference handed back, through the same registry settings
					_, desc, err := resolver.Resolve(ctx, resp.GetDigestedImageRef())
					require.NoError(t, err, "pulling %q has to reach the %s", resp.GetDigestedImageRef(), tc.mirror.name)
					assert.Equal(t, tc.digest, desc.Digest.String(), "pulling %q has to get the image that was verified", resp.GetDigestedImageRef())

					assert.Empty(t, elsewhere.take(), "every lookup for %q has to go to the %s", tc.imageRef, tc.mirror.name)
					assert.NotEmpty(t, tc.mirror.take(), "%q is served by the %s", tc.imageRef, tc.mirror.name)
				})
			}

			for _, imageRef := range unsigned {
				t.Run(imageRef, func(t *testing.T) {
					m.reset()

					ctx, cancel := context.WithTimeout(context.Background(), vrefScaled(60*time.Second))
					defer cancel()

					resp, err := vrefVerifyAPI(ctx, st, imageRef)
					require.Error(t, err, "%q falls under a signature rule and has no signature, got %v", imageRef, resp)
					assert.Equal(t, codes.PermissionDenied, status.Code(err), "%q has no signature: %v", imageRef, err)

					assert.Empty(t, elsewhere.take(), "every lookup for %q has to go to the docker.io mirror", imageRef)
					assert.NotEmpty(t, hub.take(), "%q is served by the docker.io mirror", imageRef)
				})
			}
		})
	}
}

type vrefMode struct{}

func (vrefMode) String() string        { return "vref" }
func (vrefMode) RequiresInstall() bool { return false }
func (vrefMode) InContainer() bool     { return false }

// A rule whose pattern doesn't start with a registry, like library/busybox*,
// can't go by without a word: either config validation warns about it, or the
// rule stops the image it names. A pattern that does start with a registry
// draws no warning.
func TestVrefPatternThatCannotMatchIsNotSilent(t *testing.T) {
	validate := func(t *testing.T, pattern string) []string {
		doc := securitycfg.NewImageVerificationConfigV1Alpha1()
		doc.ConfigRules = []securitycfg.ImageVerificationRuleV1Alpha1{vrefSkip(pattern)}

		warnings, err := doc.Validate(vrefMode{})
		require.NoError(t, err, "a skip rule for %q is a valid config", pattern)

		return warnings
	}

	for _, tc := range []struct {
		pattern  string
		imageRef string
	}{
		{"library/busybox*", "busybox:1.36"},
		{"myorg/*", "myorg/app:1"},
		{"busybox", "busybox:1.36"},
	} {
		t.Run(tc.pattern, func(t *testing.T) {
			warnings := validate(t, tc.pattern)

			_, err := vrefDecide(vrefRulesState(t, vrefDeny(tc.pattern)), tc.imageRef)
			stops := status.Code(err) == codes.PermissionDenied

			assert.True(t, len(warnings) > 0 || stops,
				"a rule for %q neither draws a validation warning nor stops %q (decision: %v)", tc.pattern, tc.imageRef, err)
		})
	}

	for _, pattern := range []string{
		"docker.io/library/busybox*",
		"registry.k8s.io/*",
		"localhost:5000/*",
		"*",
		"*/library/busybox*",
	} {
		t.Run(pattern, func(t *testing.T) {
			assert.Empty(t, validate(t, pattern), "%q starts with a registry and can match images", pattern)
		})
	}
}

// The vrefDaemon services stand in for the containerd daemon of a node: it hands out leases,
// knows the namespace and the overlayfs snapshotter, and answers every other
// call, the content store first of all, with an error that says where the pull
// got to.
type vrefDaemonLeases struct {
	leasesapi.UnimplementedLeasesServer
}

func (vrefDaemonLeases) Create(_ context.Context, req *leasesapi.CreateRequest) (*leasesapi.CreateResponse, error) {
	return &leasesapi.CreateResponse{Lease: &leasesapi.Lease{ID: req.GetID()}}, nil
}

func (vrefDaemonLeases) Delete(context.Context, *leasesapi.DeleteRequest) (*emptypb.Empty, error) {
	return &emptypb.Empty{}, nil
}

type vrefDaemonNamespaces struct {
	namespacesapi.UnimplementedNamespacesServer
}

func (vrefDaemonNamespaces) Get(_ context.Context, req *namespacesapi.GetNamespaceRequest) (*namespacesapi.GetNamespaceResponse, error) {
	return &namespacesapi.GetNamespaceResponse{Namespace: &namespacesapi.Namespace{Name: req.GetName()}}, nil
}

type vrefDaemonIntrospection struct {
	introspectionapi.UnimplementedIntrospectionServer
}

func (vrefDaemonIntrospection) Plugins(context.Context, *introspectionapi.PluginsRequest) (*introspectionapi.PluginsResponse, error) {
	return &introspectionapi.PluginsResponse{
		Plugins: []*introspectionapi.Plugin{{Type: "io.containerd.snapshotter.v1", ID: "overlayfs"}},
	}, nil
}

const vrefReachedContent = "vref: the pull reached the content store"

func vrefNewDaemon(t *testing.T) *containerd.Client {
	lis, err := net.Listen("tcp", "127.0.0.1:0")
	require.NoError(t, err)

	srv := grpc.NewServer(grpc.UnknownServiceHandler(func(_ any, stream grpc.ServerStream) error {
		method, _ := grpc.MethodFromServerStream(stream)
		if strings.HasPrefix(method, "/containerd.services.content.") {
			return status.Error(codes.FailedPrecondition, vrefReachedContent)
		}

		return status.Errorf(codes.Unimplemented, "vref: %s is not part of this test", method)
	}))
	leasesapi.RegisterLeasesServer(srv, vrefDaemonLeases{})
	namespacesapi.RegisterNamespacesServer(srv, vrefDaemonNamespaces{})
	introspectionapi.RegisterIntrospectionServer(srv, vrefDaemonIntrospection{})

	go srv.Serve(lis) //nolint:errcheck

	t.Cleanup(srv.Stop)

	conn, err := grpc.NewClient(lis.Addr().String(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	require.NoError(t, err)

	client, err := containerd.NewWithConn(conn)
	require.NoError(t, err)

	t.Cleanup(func() { client.Close() }) //nolint:errcheck

	return client
}

// A pull goes through the registry mirror configured for the image's registry,
// however the reference was written, whether no rule matches the image or a
// rule wants it signed.
func TestVrefPullComesThroughItsMirror(t *testing.T) {
	m := vrefNewMirrors(t)
	client := vrefNewDaemon(t)

	for _, ruleSet := range []struct {
		name  string
		rules []securitycfg.ImageVerificationRuleV1Alpha1
	}{
		{"no rule matches", []securitycfg.ImageVerificationRuleV1Alpha1{vrefDeny("quay.io/*")}},
		{"every image needs a signature", []securitycfg.ImageVerificationRuleV1Alpha1{vrefSigned("*", m.publicKeyPEM)}},
	} {
		t.Run(ruleSet.name, func(t *testing.T) {
			st := vrefNode(t, m.registries, ruleSet.rules...)

			for _, tc := range []struct {
				imageRef string
				mirror   *vrefRegistry
			}{
				{"docker.io/library/busybox:1.36", m.hub},
				{"busybox:1.36", m.hub},
				{"index.docker.io/library/busybox:1.36", m.hub},
				{"registry-1.docker.io/library/busybox:1.36", m.hub},
				{"DOCKER.IO/library/busybox:1.36", m.hub},
				{"registry.k8s.io/pause:3.9", m.k8s},
				{"REGISTRY.K8S.IO/pause:3.9", m.k8s},
			} {
				t.Run(tc.imageRef, func(t *testing.T) {
					m.reset()

					ctx, cancel := context.WithTimeout(context.Background(), vrefScaled(60*time.Second))
					defer cancel()

					ctx = namespaces.WithNamespace(ctx, "system")

					_, err := image.Pull(ctx, cri.RegistryBuilder(st), st, client, tc.imageRef)

					require.Error(t, err, "the content store of this test refuses every write")
					assert.Contains(t, err.Error(), vrefReachedContent,
						"pulling %q has to get as far as downloading the image; lookups that went elsewhere: %v", tc.imageRef, m.elsewhere.take())
					assert.Empty(t, m.elsewhere.take(), "every lookup for %q has to go to the %s", tc.imageRef, tc.mirror.name)
					assert.NotEmpty(t, tc.mirror.take(), "%q is served by the %s", tc.imageRef, tc.mirror.name)
				})
			}
		})
	}
}
