## Task

Our image verification rules fall apart as soon as an image reference is written a little differently. A deny rule copied from the examples in the ImageVerificationConfig docs, say `docker.io/library/busybox*` or `docker.io/library/nginx`, blocks nothing. `busybox:1.36`, `docker.io/busybox:1.36`, `docker.io/library/busybox:1.36` and `index.docker.io/library/busybox:1.36` all get pulled, tagged or pinned by digest. Some of our manifests spell Docker Hub as `registry-1.docker.io`, and some put the registry name in capitals. `REGISTRY.K8S.IO/pause:3.9` gets past a `registry.k8s.io/*` deny rule that way, although DNS treats it as the same host. The older rules we wrote against `index.docker.io` do block, and they need to keep blocking. A rule that names its registry in capitals, or names Docker Hub as `registry-1.docker.io`, misses the image just the same. Rules that want a signature miss all of these spellings too, so the image gets pulled without one.

The registry mirrors have their own trouble. Our nodes can't reach the public registries, so Docker Hub and registry.k8s.io images come from mirrors we configured under `docker.io` and `registry.k8s.io`. A mirror sometimes has a new signature by tag a little before it has it by digest. Even under a rule that wants a signature on every image, a signed `docker.io/library/busybox:1.36` fails verification. The mirror's log shows the tag lookup, while the signature lookups go out to `index.docker.io`. Spelled `index.docker.io/...`, `registry-1.docker.io/...` or with the registry in capitals, a signed image never touches its mirror. Plain pulls with no rule on them miss the mirror for `registry-1.docker.io` and capitals too. Asking the image Verify API about `busybox:1.36` under that rule fails with:

```
failed to resolve image reference: parse "dummy://busybox:1.36": invalid port ":1.36" after host
```

Config validation warns about a pattern like a bare `busybox`, but `library/busybox*` and `myorg/*` go through without a word, and rules like that never match an image.

Anything without a matching rule stays allowed. A repository with capitals in its name, like `registry.k8s.io/Pause:3.9`, still isn't a valid reference.

Please track down why this happens and get it fixed.
