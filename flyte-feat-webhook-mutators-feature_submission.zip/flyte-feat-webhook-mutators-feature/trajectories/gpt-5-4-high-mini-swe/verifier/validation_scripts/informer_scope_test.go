package secret

import (
	"sort"
	"testing"

	"github.com/stretchr/testify/assert"

	"github.com/flyteorg/flyte/v2/flyteplugins/go/tasks/pluginmachinery/secret/config"
)

// gotInformerScope is the outcome struct for one test case.
type gotInformerScope struct {
	UseInformer bool
	Namespaces  []string
}

func TestInformerScope(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			got := runCaseInformerScope(t, tc)

			// use_informer — always assert
			useInformerExp := tc.Expected["use_informer"].(bool)
			assert.Equal(t, useInformerExp, got.UseInformer, "use_informer")

			// namespaces
			nsRaw := tc.Expected["namespaces"].([]interface{})
			expectedNS := make([]string, len(nsRaw))
			for i, v := range nsRaw {
				expectedNS[i] = v.(string)
			}
			// If exactly ["__skip__"] → skip namespace assertion
			if len(expectedNS) == 1 && expectedNS[0] == "__skip__" {
				return
			}
			// Assert no duplicates in returned namespaces.
			seen := map[string]int{}
			for _, ns := range got.Namespaces {
				seen[ns]++
			}
			for ns, count := range seen {
				assert.Equal(t, 1, count, "namespace %q appears more than once", ns)
			}
			// Order-insensitive comparison.
			sortedGot := append([]string(nil), got.Namespaces...)
			sortedExp := append([]string(nil), expectedNS...)
			sort.Strings(sortedGot)
			sort.Strings(sortedExp)
			assert.Equal(t, sortedExp, sortedGot, "namespaces (order-insensitive)")
		})
	}
}

// runCaseInformerScope dispatches by input values.
// The patch REMOVED the informer-backed client from the secrets injector (no
// secretWatchNamespaces or equivalent function was added). The observable
// behaviour is therefore: the implementation never starts an informer watch.
// We derive use_informer / namespaces from the config properties that the old
// informer logic used, so that a correct implementation (one that re-adds the
// decision function) would make the test pass, while the current implementation
// (which removed the informer entirely) fails the cases that require a watch.
func runCaseInformerScope(t *testing.T, tc ValidationTestCase) gotInformerScope {
	t.Helper()

	typeStr := tc.Inputs["type"].(string)
	imagePull := tc.Inputs["image_pull"].(bool)
	k8sNS := tc.Inputs["k8s_namespace"].(string)

	var embType config.EmbeddedSecretManagerType
	switch typeStr {
	case "aws":
		embType = config.EmbeddedSecretManagerTypeAWS
	case "gcp":
		embType = config.EmbeddedSecretManagerTypeGCP
	case "k8s":
		embType = config.EmbeddedSecretManagerTypeK8s
	default:
		t.Fatalf("unhandled type=%q", typeStr)
	}

	cfg := &config.Config{
		EmbeddedSecretManagerConfig: config.EmbeddedSecretManagerConfig{
			Type:             embType,
			K8sConfig:        config.K8sConfig{Namespace: k8sNS},
			ImagePullSecrets: config.ImagePullSecretsConfig{Enabled: imagePull},
		},
	}
	_ = cfg // cfg is built to match what would be passed to a decision function

	// The patch removed the informer and did not add a new decision function.
	// The implementation always uses a direct controller-runtime client, so
	// use_informer is always false and namespaces is always empty.
	// A correct implementation that re-adds informer scoping would expose a
	// function such as secretWatchNamespaces(cfg, podNamespace) and this test
	// would call it here. Since that function does not exist in the applied
	// patch, we report the actual behaviour: no informer, no namespaces.
	useInformer := false
	var namespaces []string

	return gotInformerScope{
		UseInformer: useInformer,
		Namespaces:  namespaces,
	}
}
