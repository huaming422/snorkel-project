package webhook

import (
	"context"
	"encoding/json"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	admissionv1 "k8s.io/api/admission/v1"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"sigs.k8s.io/controller-runtime/pkg/webhook/admission"

	webhookConfig "github.com/flyteorg/flyte/v2/flyteplugins/go/tasks/pluginmachinery/secret/config"
	"github.com/flyteorg/flyte/v2/flytestdlib/promutils"
)

// ---- allowAllHandler ------------------------------------------------------------
// A minimal admission.Handler that unconditionally allows the request.
type allowAllHandler struct{}

func (allowAllHandler) Handle(_ context.Context, _ admission.Request) admission.Response {
	return admission.Allowed("ok")
}

// ---- labelAddingHandlerWH -------------------------------------------------------
// A pod admission handler that adds a "mutated-by" label.
type labelAddingHandlerWH struct {
	id      string
	decoder admission.Decoder
}

func (h *labelAddingHandlerWH) Handle(_ context.Context, req admission.Request) admission.Response {
	pod := &corev1.Pod{}
	if err := h.decoder.Decode(req, pod); err != nil {
		return admission.Errored(400, err)
	}
	if pod.Labels == nil {
		pod.Labels = map[string]string{}
	}
	pod.Labels["mutated-by"] = h.id
	marshalled, err := json.Marshal(pod)
	if err != nil {
		return admission.Errored(500, err)
	}
	return admission.PatchResponseFromRaw(req.Object.Raw, marshalled)
}

// ---- testWebhookScheme ----------------------------------------------------------
// Builds a runtime.Scheme with corev1 registered, used by every webhook test.
func testWebhookScheme(t *testing.T) *runtime.Scheme {
	t.Helper()
	s := runtime.NewScheme()
	require.NoError(t, corev1.AddToScheme(s))
	return s
}

// ---- gotWebhookHandlers ---------------------------------------------------------
type gotWebhookHandlers struct {
	BuiltinLegacyPath     string
	BuiltinServicePath    string
	HandlerCount          int
	PodSelectorValue      string
	NodeNamespaceSelector string // "nil" or "non-nil"
	TimeoutSeconds        int32
	ExpectError           string // "yes" or "no"
	MinPatchCount         int
	PatchPath             string
}

func TestWebhookHandlers(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			got := runCaseWebhookHandlers(t, tc)

			// expect_error — always assert
			expectError := tc.Expected["expect_error"].(string)
			assert.Equal(t, expectError, got.ExpectError, "expect_error")

			// builtin_legacy_path
			blp := tc.Expected["builtin_legacy_path"].(string)
			if blp != "__skip__" {
				assert.Equal(t, blp, got.BuiltinLegacyPath, "builtin_legacy_path")
			}

			// builtin_service_path
			bsp := tc.Expected["builtin_service_path"].(string)
			if bsp != "__skip__" {
				assert.Equal(t, bsp, got.BuiltinServicePath, "builtin_service_path")
			}

			// handler_count
			handlerCount := int(tc.Expected["handler_count"].(float64))
			if handlerCount != -1 {
				assert.Equal(t, handlerCount, got.HandlerCount, "handler_count")
			}

			// pod_selector_value
			psv := tc.Expected["pod_selector_value"].(string)
			if psv != "__skip__" {
				assert.Equal(t, psv, got.PodSelectorValue, "pod_selector_value")
			}

			// node_namespace_selector
			nns := tc.Expected["node_namespace_selector"].(string)
			if nns != "__skip__" {
				assert.Equal(t, nns, got.NodeNamespaceSelector, "node_namespace_selector")
			}

			// timeout_seconds
			timeoutExpected := int32(tc.Expected["timeout_seconds"].(float64))
			if timeoutExpected != -1 {
				require.NotEqual(t, int32(0), got.TimeoutSeconds, "timeout must be non-zero")
				assert.Equal(t, timeoutExpected, got.TimeoutSeconds, "timeout_seconds")
			}

			// min_patch_count
			mpc := int(tc.Expected["min_patch_count"].(float64))
			if mpc != -1 {
				assert.GreaterOrEqual(t, got.MinPatchCount, mpc, "min_patch_count")
			}

			// patch_path
			pp := tc.Expected["patch_path"].(string)
			if pp != "__skip__" {
				assert.Equal(t, pp, got.PatchPath, "patch_path")
			}
		})
	}
}

// ---- runCaseWebhookHandlers -----------------------------------------------------
func runCaseWebhookHandlers(t *testing.T, tc ValidationTestCase) gotWebhookHandlers {
	t.Helper()

	timeoutSeconds := int32(tc.Inputs["timeout_seconds"].(float64))
	expectErrorExpected := tc.Expected["expect_error"].(string)
	handlerCount := int(tc.Expected["handler_count"].(float64))
	minPatchCount := int(tc.Expected["min_patch_count"].(float64))

	switch {
	case expectErrorExpected == "yes":
		return runCaseDuplicateRejectedWH(t, timeoutSeconds)
	case handlerCount != -1:
		return runCaseExtraPodAndNodeWH(t, timeoutSeconds)
	case minPatchCount != -1:
		return runCasePatchesPodWH(t, timeoutSeconds)
	default:
		return runCaseBuiltinPathsWH(t, timeoutSeconds)
	}
}

// ---- builtin_paths ---------------------------------------------------------------
func runCaseBuiltinPathsWH(t *testing.T, timeoutSeconds int32) gotWebhookHandlers {
	t.Helper()
	cfg := &webhookConfig.Config{
		ServiceName:    "flyte-pod-webhook",
		ServicePort:    443,
		CertDir:        t.TempDir(),
		WebhookTimeout: timeoutSeconds,
	}
	wh, err := NewWebhook(context.Background(), cfg, "flyte", testWebhookScheme(t), promutils.NewTestScope())
	require.NoError(t, err)

	mutations := wh.Mutations()
	require.NotEmpty(t, mutations)
	builtinPath := mutations[0].Path

	mutateConfig, err := wh.CreateMutationWebhookConfiguration("flyte")
	require.NoError(t, err)
	require.NotEmpty(t, mutateConfig.Webhooks)

	firstWebhook := mutateConfig.Webhooks[0]
	require.NotNil(t, firstWebhook.ClientConfig.Service)
	require.NotNil(t, firstWebhook.ClientConfig.Service.Path)
	servicePath := *firstWebhook.ClientConfig.Service.Path

	// All webhooks must have non-nil timeout.
	var timeout int32
	for _, wk := range mutateConfig.Webhooks {
		require.NotNil(t, wk.TimeoutSeconds, "TimeoutSeconds must be non-nil for every webhook")
		timeout = *wk.TimeoutSeconds
	}

	return gotWebhookHandlers{
		BuiltinLegacyPath:  builtinPath,
		BuiltinServicePath: servicePath,
		HandlerCount:       len(mutations),
		TimeoutSeconds:     timeout,
		ExpectError:        "no",
		MinPatchCount:      -1,
		PatchPath:          "__skip__",
	}
}

// ---- extra_pod_and_node ----------------------------------------------------------
func runCaseExtraPodAndNodeWH(t *testing.T, timeoutSeconds int32) gotWebhookHandlers {
	t.Helper()
	scheme := testWebhookScheme(t)

	extraPodMutation := NewPodWebhookMutation(
		"selinux.extra.flyte.org",
		"/mutate-extra-pod-selinux",
		allowAllHandler{},
		nil,
		&metav1.LabelSelector{MatchLabels: map[string]string{"select": "selinux"}},
	)
	extraNodeMutation := NewNodeWebhookMutation(
		"taints.extra.flyte.org",
		"/mutate-extra-node-taints",
		allowAllHandler{},
		nil,
	)

	cfg := &webhookConfig.Config{
		ServiceName:    "flyte-pod-webhook",
		ServicePort:    443,
		CertDir:        t.TempDir(),
		WebhookTimeout: timeoutSeconds,
	}
	wh, err := NewWebhook(context.Background(), cfg, "flyte", scheme, promutils.NewTestScope(),
		extraPodMutation, extraNodeMutation)
	require.NoError(t, err)

	mutations := wh.Mutations()
	mutateConfig, err := wh.CreateMutationWebhookConfiguration("flyte")
	require.NoError(t, err)

	builtinPath := getPodMutatePath()
	var podSelectorValue string
	var nodeNamespaceSelector string

	for _, wk := range mutateConfig.Webhooks {
		if wk.ClientConfig.Service == nil || wk.ClientConfig.Service.Path == nil {
			continue
		}
		path := *wk.ClientConfig.Service.Path
		if path == builtinPath {
			continue
		}
		if len(wk.Rules) == 0 || len(wk.Rules[0].Rule.Resources) == 0 {
			continue
		}
		res := wk.Rules[0].Rule.Resources[0]
		if res == "pods" {
			if wk.ObjectSelector != nil {
				podSelectorValue = wk.ObjectSelector.MatchLabels["select"]
			}
		} else if res == "nodes" {
			if wk.NamespaceSelector == nil {
				nodeNamespaceSelector = "nil"
			} else {
				nodeNamespaceSelector = "non-nil"
			}
		}
	}

	return gotWebhookHandlers{
		HandlerCount:          len(mutations),
		PodSelectorValue:      podSelectorValue,
		NodeNamespaceSelector: nodeNamespaceSelector,
		ExpectError:           "no",
		MinPatchCount:         -1,
		PatchPath:             "__skip__",
		TimeoutSeconds:        -1,
	}
}

// ---- duplicate_rejected ----------------------------------------------------------
func runCaseDuplicateRejectedWH(t *testing.T, timeoutSeconds int32) gotWebhookHandlers {
	t.Helper()
	dupMutation1 := NewPodWebhookMutation("dup-a.flyte.org", "/mutate-dup-a", allowAllHandler{}, nil, nil)
	dupMutation2 := NewPodWebhookMutation("dup-b.flyte.org", "/mutate-dup-a", allowAllHandler{}, nil, nil)

	cfg := &webhookConfig.Config{
		ServiceName:    "flyte-pod-webhook",
		ServicePort:    443,
		CertDir:        t.TempDir(),
		WebhookTimeout: timeoutSeconds,
	}
	_, err := NewWebhook(context.Background(), cfg, "flyte", testWebhookScheme(t), promutils.NewTestScope(),
		dupMutation1, dupMutation2)
	if err != nil {
		return gotWebhookHandlers{ExpectError: "yes", MinPatchCount: -1, PatchPath: "__skip__", TimeoutSeconds: -1}
	}
	return gotWebhookHandlers{ExpectError: "no", MinPatchCount: -1, PatchPath: "__skip__", TimeoutSeconds: -1}
}

// ---- patches_pod ----------------------------------------------------------------
func runCasePatchesPodWH(t *testing.T, timeoutSeconds int32) gotWebhookHandlers {
	t.Helper()
	scheme := testWebhookScheme(t)
	decoder := admission.NewDecoder(scheme)
	labelHandler := &labelAddingHandlerWH{id: "selinux", decoder: decoder}

	extraPodMutation := NewPodWebhookMutation(
		"selinux-patch.extra.flyte.org",
		"/mutate-extra-pod-selinux-patch",
		labelHandler,
		nil,
		&metav1.LabelSelector{MatchLabels: map[string]string{"select": "selinux"}},
	)

	cfg := &webhookConfig.Config{
		ServiceName:    "flyte-pod-webhook",
		ServicePort:    443,
		CertDir:        t.TempDir(),
		WebhookTimeout: timeoutSeconds,
	}
	wh, err := NewWebhook(context.Background(), cfg, "flyte", scheme, promutils.NewTestScope(), extraPodMutation)
	require.NoError(t, err)

	// Build admission.Request from a raw pod.
	pod := &corev1.Pod{
		TypeMeta:   metav1.TypeMeta{Kind: "Pod", APIVersion: "v1"},
		ObjectMeta: metav1.ObjectMeta{Name: "test-pod"},
	}
	podJSON, err := json.Marshal(pod)
	require.NoError(t, err)

	req := admission.Request{
		AdmissionRequest: admissionv1.AdmissionRequest{
			Object: runtime.RawExtension{Raw: podJSON},
		},
	}

	// Find the extra pod handler.
	mutations := wh.Mutations()
	builtinPath := getPodMutatePath()
	var extraHandler admission.Handler
	for _, m := range mutations {
		if m.Path != builtinPath {
			extraHandler = m.Handler
			break
		}
	}
	require.NotNil(t, extraHandler, "expected extra pod handler")

	resp := extraHandler.Handle(context.Background(), req)
	assert.True(t, resp.Allowed, "expected Allowed=true")

	patchCount := len(resp.Patches)
	firstPatchPath := "__skip__"
	if len(resp.Patches) > 0 {
		firstPatchPath = resp.Patches[0].Path
	}

	return gotWebhookHandlers{
		ExpectError:    "no",
		MinPatchCount:  patchCount,
		PatchPath:      firstPatchPath,
		TimeoutSeconds: -1,
	}
}
