package secret

import (
	"context"
	"encoding/base64"
	"errors"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	k8sfake "k8s.io/client-go/kubernetes/fake"
	k8sTesting "k8s.io/client-go/testing"

	"github.com/flyteorg/flyte/v2/flyteplugins/go/tasks/pluginmachinery/secret/config"
	"github.com/flyteorg/flyte/v2/flyteplugins/go/tasks/pluginmachinery/secret/mocks"
	stdlibErrors "github.com/flyteorg/flyte/v2/flytestdlib/errors"
	"github.com/flyteorg/flyte/v2/gen/go/flyteidl2/core"
)

// Key names used across all cluster_scoped_secret cases.
const (
	clusterKeyCS  = "my-cluster-secret"
	secondKeyCS   = "other-key"
	clusterNameCS = "dp-gcp-default"
	secretsNSCS   = "flyte"
)

// gotClusterScopedSecret is the outcome struct.
type gotClusterScopedSecret struct {
	Injected   bool
	Value      string // "V_CLUSTER", "V_SHARED", or "__skip__"
	IsError    bool
	ErrorCause string // "SecretReadFailure" or "__skip__"
}

func TestClusterScopedSecret(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			got := runCaseClusterScopedSecret(t, tc)

			// injected
			injectedExp := tc.Expected["injected"].(bool)
			assert.Equal(t, injectedExp, got.Injected, "injected")

			// value
			valueExp := tc.Expected["value"].(string)
			if valueExp != "__skip__" {
				assert.Equal(t, valueExp, got.Value, "value")
			}

			// is_error
			isErrorExp := tc.Expected["is_error"].(bool)
			assert.Equal(t, isErrorExp, got.IsError, "is_error")

			// error_cause
			errorCauseExp := tc.Expected["error_cause"].(string)
			if errorCauseExp != "__skip__" {
				assert.Equal(t, errorCauseExp, got.ErrorCause, "error_cause")
			}
		})
	}
}

// runCaseClusterScopedSecret dispatches by input values.
func runCaseClusterScopedSecret(t *testing.T, tc ValidationTestCase) gotClusterScopedSecret {
	t.Helper()
	clusterName := tc.Inputs["cluster_name"].(string)
	keyKind := tc.Inputs["key_kind"].(string)
	presentIDs := tc.Inputs["present_ids"].([]interface{})

	// Determine which key to request.
	requestKey := clusterKeyCS
	if keyKind == "non_cluster" {
		requestKey = secondKeyCS
	}

	// Check if this is the error case.
	for _, pid := range presentIDs {
		if pid.(string) == "__cluster_read_fails__" {
			return runClusterCaseErrorCS(t, clusterName, requestKey)
		}
	}

	// Build seed flags.
	seedCluster := false
	seedShared := false
	for _, pid := range presentIDs {
		switch pid.(string) {
		case "cluster":
			seedCluster = true
		case "shared":
			seedShared = true
		}
	}

	return runClusterCaseNormalCS(t, clusterName, requestKey, seedCluster, seedShared)
}

// runClusterCaseNormalCS runs a normal (non-error) case.
func runClusterCaseNormalCS(t *testing.T, clusterName, requestKey string, seedCluster, seedShared bool) gotClusterScopedSecret {
	t.Helper()
	require.NotEmpty(t, requestKey)
	ctx := context.Background()

	// Compute the logical secretID for the requested key using pod labels.
	secretIDCS := EncodeSecretName("o-apple", "d-cherry", "p-banana", requestKey)

	// Compute k8s secret names.
	clusterK8sName := EncodeClusterQualifiedK8sSecretName(secretIDCS, clusterName)
	sharedK8sName := EncodeK8sSecretName(secretIDCS)

	// Seed the fake clientset.
	var objs []runtime.Object
	if seedCluster && clusterName != "" {
		objs = append(objs, &corev1.Secret{
			ObjectMeta: metav1.ObjectMeta{Name: clusterK8sName, Namespace: secretsNSCS},
			Data:       map[string][]byte{secretIDCS: []byte("V_CLUSTER")},
		})
	}
	if seedShared {
		objs = append(objs, &corev1.Secret{
			ObjectMeta: metav1.ObjectMeta{Name: sharedK8sName, Namespace: secretsNSCS},
			Data:       map[string][]byte{secretIDCS: []byte("V_SHARED")},
		})
	}

	fakeKubeClient := k8sfake.NewClientset(objs...)
	secretsClient := fakeKubeClient.CoreV1().Secrets(secretsNSCS)

	// Build the K8s secret fetcher with optional cluster name.
	var fetcher SecretFetcher
	if clusterName != "" {
		fetcher = NewK8sSecretFetcher(secretsClient, clusterName)
	} else {
		fetcher = NewK8sSecretFetcher(secretsClient)
	}

	// The controller-runtime client is used for image pull secrets and isStoredInK8sSecret.
	// cfg.Type = EmbeddedSecretManagerTypeAWS means secretStoredInK8s=false → isStoredInK8sSecret never called.
	mockCtrlClient := &mocks.MockableControllerRuntimeClient{}

	secretCache := newAlwaysMissCache(t)
	embCfg := config.EmbeddedSecretManagerConfig{
		// Use a non-K8s type to avoid isStoredInK8sSecret calls.
		Type:     config.EmbeddedSecretManagerTypeAWS,
		K8sConfig: config.K8sConfig{Namespace: secretsNSCS},
	}
	parentCfg := &config.Config{SecretEnvVarPrefix: config.DefaultSecretEnvVarPrefix}

	injector := NewEmbeddedSecretManagerInjector(embCfg, []SecretFetcher{fetcher}, mockCtrlClient, testReferenceNamespace, secretCache, parentCfg)

	pod := buildPodCS()
	secretReq := &core.Secret{
		Key:              requestKey,
		MountRequirement: core.Secret_FILE,
	}

	mutatedPod, injected, err := injector.Inject(ctx, secretReq, pod)
	if err != nil {
		return gotClusterScopedSecret{Injected: false, Value: "__skip__", IsError: true, ErrorCause: "__skip__"}
	}
	if !injected {
		return gotClusterScopedSecret{Injected: false, Value: "__skip__", IsError: false, ErrorCause: "__skip__"}
	}

	// Read back the value from the SECRETS env var in init containers.
	value, found := clusterCopyValueCS(mutatedPod, requestKey)
	if !found {
		return gotClusterScopedSecret{Injected: injected, Value: "__skip__", IsError: false, ErrorCause: "__skip__"}
	}

	return gotClusterScopedSecret{Injected: injected, Value: value, IsError: false, ErrorCause: "__skip__"}
}

// runClusterCaseErrorCS runs the error_not_masked case.
func runClusterCaseErrorCS(t *testing.T, clusterName, requestKey string) gotClusterScopedSecret {
	t.Helper()
	ctx := context.Background()

	secretIDCS := EncodeSecretName("o-apple", "d-cherry", "p-banana", requestKey)
	clusterK8sName := EncodeClusterQualifiedK8sSecretName(secretIDCS, clusterName)

	// Fake clientset: cluster-qualified k8s name returns a genuine (non-notfound) error.
	fakeKubeClient := k8sfake.NewClientset()
	fakeKubeClient.PrependReactor("get", "secrets", func(action k8sTesting.Action) (bool, runtime.Object, error) {
		getAction := action.(k8sTesting.GetAction)
		if getAction.GetName() == clusterK8sName {
			return true, nil, errors.New("storage error: disk full")
		}
		return false, nil, nil
	})
	secretsClient := fakeKubeClient.CoreV1().Secrets(secretsNSCS)
	fetcher := NewK8sSecretFetcher(secretsClient, clusterName)

	mockCtrlClient := &mocks.MockableControllerRuntimeClient{}
	secretCache := newAlwaysMissCache(t)
	embCfg := config.EmbeddedSecretManagerConfig{
		Type:     config.EmbeddedSecretManagerTypeAWS,
		K8sConfig: config.K8sConfig{Namespace: secretsNSCS},
	}
	parentCfg := &config.Config{SecretEnvVarPrefix: config.DefaultSecretEnvVarPrefix}
	injector := NewEmbeddedSecretManagerInjector(embCfg, []SecretFetcher{fetcher}, mockCtrlClient, testReferenceNamespace, secretCache, parentCfg)

	pod := buildPodCS()
	secretReq := &core.Secret{
		Key:              requestKey,
		MountRequirement: core.Secret_FILE,
	}

	_, injected, err := injector.Inject(ctx, secretReq, pod)

	isError := err != nil
	errorCause := "__skip__"
	if isError && stdlibErrors.IsCausedBy(err, ErrCodeSecretReadFailure) {
		errorCause = "SecretReadFailure"
	}

	return gotClusterScopedSecret{
		Injected:   injected,
		Value:      "__skip__",
		IsError:    isError,
		ErrorCause: errorCause,
	}
}

// buildPodCS constructs a pod with the required labels and namespace.
func buildPodCS() *corev1.Pod {
	return &corev1.Pod{
		ObjectMeta: metav1.ObjectMeta{
			Namespace: testPodNamespace,
			Labels: map[string]string{
				OrganizationLabel: "o-apple",
				DomainLabel:       "d-cherry",
				ProjectLabel:      "p-banana",
			},
		},
		Spec: corev1.PodSpec{
			Containers: []corev1.Container{{}},
		},
	}
}

// clusterCopyValueCS reads the value for the given key from the SECRETS env var
// in any init container. Returns (value, found).
func clusterCopyValueCS(pod *corev1.Pod, key string) (string, bool) {
	for _, initContainer := range pod.Spec.InitContainers {
		for _, env := range initContainer.Env {
			if env.Name != EmbeddedSecretsFileMountInitContainerEnvVariableName {
				continue
			}
			// env.Value is like "key1=<base64>\nkey2=<base64>\n"
			for _, line := range strings.Split(env.Value, "\n") {
				if line == "" {
					continue
				}
				eqIdx := strings.Index(line, "=")
				if eqIdx < 0 {
					continue
				}
				lineKey := line[:eqIdx]
				lineVal := line[eqIdx+1:]
				if lineKey != key {
					continue
				}
				decoded, err := base64.StdEncoding.DecodeString(lineVal)
				if err != nil {
					return "", false
				}
				return string(decoded), true
			}
		}
	}
	return "", false
}
