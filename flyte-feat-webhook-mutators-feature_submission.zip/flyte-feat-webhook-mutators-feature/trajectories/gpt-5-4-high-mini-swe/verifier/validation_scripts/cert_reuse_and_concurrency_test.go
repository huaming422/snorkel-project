package webhook

import (
	"bytes"
	"context"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	corev1 "k8s.io/api/core/v1"
	k8sErrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	k8sfake "k8s.io/client-go/kubernetes/fake"
	k8sTesting "k8s.io/client-go/testing"

	webhookConfig "github.com/flyteorg/flyte/v2/flyteplugins/go/tasks/pluginmachinery/secret/config"
)

// ---- gotCertReuse ---------------------------------------------------------------
type gotCertReuse struct {
	Regenerated         bool
	AdoptWinner         string // "winner", "__skip__"
	LocalFilesMatchStored string // "match", "__skip__"
}

func TestCertReuseAndConcurrency(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			got := runCaseCertReuse(t, tc)

			// regenerated (bool) — always assert
			regeneratedExp := tc.Expected["regenerated"].(bool)
			assert.Equal(t, regeneratedExp, got.Regenerated, "regenerated")

			// adopt_winner
			adoptWinnerExp := tc.Expected["adopt_winner"].(string)
			if adoptWinnerExp != "__skip__" {
				assert.Equal(t, adoptWinnerExp, got.AdoptWinner, "adopt_winner")
			}

			// local_files_match_stored
			lfmsExp := tc.Expected["local_files_match_stored"].(string)
			if lfmsExp != "__skip__" {
				assert.Equal(t, lfmsExp, got.LocalFilesMatchStored, "local_files_match_stored")
			}
		})
	}
}

// ---- runCaseCertReuse -----------------------------------------------------------
func runCaseCertReuse(t *testing.T, tc ValidationTestCase) gotCertReuse {
	t.Helper()
	existing := tc.Inputs["existing"].(string)

	switch existing {
	case "valid":
		return runCertReuseValid(t)
	case "none":
		return runCertReuseNone(t)
	case "inside_window":
		return runCertReuseInsideWindow(t)
	case "wrong_namespace":
		return runCertReuseWrongNamespace(t)
	case "adopt_winner":
		return runCertReuseAdoptWinner(t)
	case "local_cert_writes_stored":
		return runCertReuseLocalCert(t)
	default:
		t.Fatalf("unhandled existing=%q", existing)
		return gotCertReuse{}
	}
}

// ---- helpers --------------------------------------------------------------------

const (
	certReuseServiceName = "flyte-pod-webhook"
	certReuseNamespace   = "flyte"
)

func makeCfgCertReuse(t *testing.T, localCert bool) *webhookConfig.Config {
	t.Helper()
	return &webhookConfig.Config{
		ServiceName: certReuseServiceName,
		SecretName:  certReuseServiceName,
		LocalCert:   localCert,
		CertDir:     t.TempDir(),
	}
}

// certsToDataMapCertReuse converts webhookCerts to a k8s Secret data map.
func certsToDataMapCertReuse(certs webhookCerts) map[string][]byte {
	return map[string][]byte{
		CaCertKey:            certs.CaPEM.Bytes(),
		ServerCertKey:        certs.ServerPEM.Bytes(),
		ServerCertPrivateKey: certs.PrivateKeyPEM.Bytes(),
	}
}

// buildValidSecretCertReuse creates a *corev1.Secret from fresh far-future certs for the given namespace.
func buildValidSecretCertReuse(t *testing.T, cfg *webhookConfig.Config, ns string) (*corev1.Secret, webhookCerts) {
	t.Helper()
	certs, err := createCerts(certReuseServiceName, ns)
	require.NoError(t, err)
	secret := buildWebhookSecret(ns, cfg, certs)
	return secret, certs
}

// runEnsureWithGenerator calls ensureWebhookSecret with a fresh set of certs,
// recording whether generation was needed.
// Since ensureWebhookSecret doesn't accept a callback, "generation" is modeled
// as: we pass the fresh certs and observe if the stored secret matches them.
func runEnsureAndCheckRegenerated(
	t *testing.T,
	ctx context.Context,
	cfg *webhookConfig.Config,
	client *k8sfake.Clientset,
	originalData map[string][]byte,
) (regenerated bool, storedData map[string][]byte) {
	t.Helper()
	freshCerts, err := createCerts(certReuseServiceName, certReuseNamespace)
	require.NoError(t, err)

	secretsClient := client.CoreV1().Secrets(certReuseNamespace)
	returnedCerts, err := ensureWebhookSecret(ctx, certReuseNamespace, cfg, freshCerts, secretsClient)
	require.NoError(t, err)

	stored, err := client.CoreV1().Secrets(certReuseNamespace).Get(ctx, cfg.SecretName, metav1.GetOptions{})
	require.NoError(t, err)

	storedData = stored.Data
	returnedData := certsToDataMapCertReuse(returnedCerts)

	// Assert returned == stored
	assert.True(t, bytes.Equal(returnedData[CaCertKey], storedData[CaCertKey]), "returned ca matches stored")
	assert.True(t, bytes.Equal(returnedData[ServerCertKey], storedData[ServerCertKey]), "returned server cert matches stored")

	// Determine if regenerated: if stored matches original, not regenerated; else regenerated.
	if originalData != nil {
		regenerated = !bytes.Equal(originalData[ServerCertKey], storedData[ServerCertKey])
	} else {
		// No original — always regenerated (new secret was created).
		regenerated = true
	}
	return regenerated, storedData
}

// ---- case runners ---------------------------------------------------------------

func runCertReuseValid(t *testing.T) gotCertReuse {
	t.Helper()
	ctx := context.Background()
	cfg := makeCfgCertReuse(t, false)
	origSecret, origCerts := buildValidSecretCertReuse(t, cfg, certReuseNamespace)
	_ = origCerts
	client := k8sfake.NewClientset(origSecret)
	origData := certsToDataMapCertReuse(origCerts)

	regenerated, _ := runEnsureAndCheckRegenerated(t, ctx, cfg, client, origData)
	return gotCertReuse{Regenerated: regenerated, AdoptWinner: "__skip__", LocalFilesMatchStored: "__skip__"}
}

func runCertReuseNone(t *testing.T) gotCertReuse {
	t.Helper()
	ctx := context.Background()
	cfg := makeCfgCertReuse(t, false)
	client := k8sfake.NewClientset() // no existing secret
	regenerated, _ := runEnsureAndCheckRegenerated(t, ctx, cfg, client, nil)
	return gotCertReuse{Regenerated: regenerated, AdoptWinner: "__skip__", LocalFilesMatchStored: "__skip__"}
}

func runCertReuseInsideWindow(t *testing.T) gotCertReuse {
	t.Helper()
	ctx := context.Background()
	cfg := makeCfgCertReuse(t, false)

	// Certs valid now but expire in ~1h — well inside any renewal window.
	nearExpiryCerts, err := createCertsWithValidity(certReuseServiceName, certReuseNamespace,
		time.Now().Add(-time.Hour), time.Now().Add(time.Hour))
	require.NoError(t, err)
	existingSecret := buildWebhookSecret(certReuseNamespace, cfg, nearExpiryCerts)
	origData := certsToDataMapCertReuse(nearExpiryCerts)

	client := k8sfake.NewClientset(existingSecret)
	regenerated, _ := runEnsureAndCheckRegenerated(t, ctx, cfg, client, origData)
	return gotCertReuse{Regenerated: regenerated, AdoptWinner: "__skip__", LocalFilesMatchStored: "__skip__"}
}

func runCertReuseWrongNamespace(t *testing.T) gotCertReuse {
	t.Helper()
	ctx := context.Background()
	cfg := makeCfgCertReuse(t, false)

	// Certs for "other" namespace — unusable for "flyte".
	wrongCerts, err := createCerts(certReuseServiceName, "other")
	require.NoError(t, err)
	existingSecret := buildWebhookSecret(certReuseNamespace, cfg, wrongCerts)
	origData := certsToDataMapCertReuse(wrongCerts)

	client := k8sfake.NewClientset(existingSecret)
	regenerated, _ := runEnsureAndCheckRegenerated(t, ctx, cfg, client, origData)
	return gotCertReuse{Regenerated: regenerated, AdoptWinner: "__skip__", LocalFilesMatchStored: "__skip__"}
}

func runCertReuseAdoptWinner(t *testing.T) gotCertReuse {
	t.Helper()
	ctx := context.Background()
	cfg := makeCfgCertReuse(t, false)

	// The "winner" secret that another replica wrote.
	winnerCerts, err := createCerts(certReuseServiceName, certReuseNamespace)
	require.NoError(t, err)
	winnerData := certsToDataMapCertReuse(winnerCerts)
	winnerSecret := buildWebhookSecret(certReuseNamespace, cfg, winnerCerts)

	// Seed the client with the winner secret but reactor returns NotFound on first get,
	// then AlreadyExists on create, then the tracker works normally.
	client := k8sfake.NewClientset()
	firstGet := true
	client.PrependReactor("get", "secrets", func(action k8sTesting.Action) (bool, runtime.Object, error) {
		if firstGet {
			firstGet = false
			return true, nil, k8sErrors.NewNotFound(corev1.Resource("secrets"), cfg.SecretName)
		}
		// After first get, defer to tracker.
		return false, nil, nil
	})

	// Pre-seed the winner in the tracker so subsequent gets find it.
	require.NoError(t, client.Tracker().Add(winnerSecret))
	// Make create return AlreadyExists.
	client.PrependReactor("create", "secrets", func(action k8sTesting.Action) (bool, runtime.Object, error) {
		return true, nil, k8sErrors.NewAlreadyExists(corev1.Resource("secrets"), cfg.SecretName)
	})

	freshCerts, err := createCerts(certReuseServiceName, certReuseNamespace)
	require.NoError(t, err)

	secretsClient := client.CoreV1().Secrets(certReuseNamespace)
	returnedCerts, err := ensureWebhookSecret(ctx, certReuseNamespace, cfg, freshCerts, secretsClient)
	require.NoError(t, err)

	returnedData := certsToDataMapCertReuse(returnedCerts)

	// The returned data should be the winner's data (adopted).
	adoptWinner := "__skip__"
	if bytes.Equal(returnedData[ServerCertKey], winnerData[ServerCertKey]) {
		adoptWinner = "winner"
	}

	return gotCertReuse{Regenerated: true, AdoptWinner: adoptWinner, LocalFilesMatchStored: "__skip__"}
}

func runCertReuseLocalCert(t *testing.T) gotCertReuse {
	t.Helper()
	ctx := context.Background()
	cfg := makeCfgCertReuse(t, true)

	// Seed a valid secret.
	origSecret, origCerts := buildValidSecretCertReuse(t, cfg, certReuseNamespace)
	_ = origCerts
	client := k8sfake.NewClientset(origSecret)

	err := InitCerts(ctx, client, cfg, certReuseNamespace)
	require.NoError(t, err)

	// Read the stored secret.
	stored, err := client.CoreV1().Secrets(certReuseNamespace).Get(ctx, cfg.SecretName, metav1.GetOptions{})
	require.NoError(t, err)

	// Check files match stored.
	certDir := cfg.ExpandCertDir()
	caFile, err := os.ReadFile(filepath.Join(certDir, CaCertKey))
	require.NoError(t, err)
	serverFile, err := os.ReadFile(filepath.Join(certDir, ServerCertKey))
	require.NoError(t, err)
	keyFile, err := os.ReadFile(filepath.Join(certDir, ServerCertPrivateKey))
	require.NoError(t, err)

	match := "match"
	if !bytes.Equal(caFile, stored.Data[CaCertKey]) ||
		!bytes.Equal(serverFile, stored.Data[ServerCertKey]) ||
		!bytes.Equal(keyFile, stored.Data[ServerCertPrivateKey]) {
		match = "mismatch"
	}

	// Check stored == original (not regenerated).
	regenerated := !bytes.Equal(origCerts.ServerPEM.Bytes(), stored.Data[ServerCertKey])

	return gotCertReuse{Regenerated: regenerated, AdoptWinner: "__skip__", LocalFilesMatchStored: match}
}
