package secret

import (
	"context"
	"encoding/base64"
	"errors"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	k8sfake "k8s.io/client-go/kubernetes/fake"
	k8sTesting "k8s.io/client-go/testing"

	"github.com/flyteorg/flyte/v2/flyteplugins/go/tasks/pluginmachinery/secret/config"
	"github.com/flyteorg/flyte/v2/flyteplugins/go/tasks/pluginmachinery/secret/mocks"
	stdlibErrors "github.com/flyteorg/flyte/v2/flytestdlib/errors"
	"github.com/flyteorg/flyte/v2/gen/go/flyteidl2/core"
)

// TestClusterScopedSecret exercises the cluster-qualified secret lookup.
func TestClusterScopedSecret(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			got := runCaseClusterScopedSecret(t, tc)

			// injected
			expectedInjected := tc.Expected["injected"].(bool)
			assert.Equal(t, expectedInjected, got.injected, "injected mismatch")

			// value
			expectedValue := tc.Expected["value"].(string)
			if expectedValue != "__skip__" {
				assert.Equal(t, expectedValue, got.value, "injected value mismatch")
			}

			// is_error
			expectedIsError := tc.Expected["is_error"].(bool)
			assert.Equal(t, expectedIsError, got.isError, "is_error mismatch")

			// error_cause
			expectedErrorCause := tc.Expected["error_cause"].(string)
			if expectedErrorCause != "__skip__" {
				assert.Equal(t, expectedErrorCause, got.errorCause, "error_cause mismatch")
			}
		})
	}
}

// gotClusterScopedSecret is the flat outcome struct.
type gotClusterScopedSecret struct {
	injected   bool
	value      string
	isError    bool
	errorCause string
}

const (
	// csClusterKey is the pod-facing key for the per-cluster secret.
	csClusterKey = "my-cluster-secret"
	// csSecondKey is a regular (non-per-cluster) key.
	csSecondKey = "my-shared-secret"

	// Pod label values for test pods.
	csOrg     = "o-apple"
	csDomain  = "d-cherry"
	csProject = "p-banana"
)

// makeCsPod builds a test pod in testPodNamespace with the required labels.
func makeCsPod() *corev1.Pod {
	return &corev1.Pod{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "test-pod-cs",
			Namespace: testPodNamespace,
			Labels: map[string]string{
				OrganizationLabel: csOrg,
				DomainLabel:       csDomain,
				ProjectLabel:      csProject,
			},
		},
		Spec: corev1.PodSpec{
			Containers: []corev1.Container{{Name: "main", Image: "busybox"}},
		},
	}
}

// csProjectScopeID returns the project-scoped secret ID for a given key.
func csProjectScopeID(key string) string {
	return EncodeSecretName(csOrg, csDomain, csProject, key)
}

// clusterCopyValueCS reads the VALUE injected via file mount.
// The SECRETS env var format: "key=base64(value)\n" per line.
func clusterCopyValueCS(pod *corev1.Pod, key string) (string, bool) {
	for _, c := range pod.Spec.InitContainers {
		for _, env := range c.Env {
			if env.Name != EmbeddedSecretsFileMountInitContainerEnvVariableName {
				continue
			}
			for _, line := range strings.Split(env.Value, "\n") {
				line = strings.TrimSpace(line)
				if line == "" {
					continue
				}
				parts := strings.SplitN(line, "=", 2)
				if len(parts) != 2 {
					continue
				}
				if parts[0] == key {
					decoded, err := base64.StdEncoding.DecodeString(parts[1])
					if err != nil {
						return "", false
					}
					return string(decoded), true
				}
			}
		}
	}
	return "", false
}

// buildInjectorCS constructs an EmbeddedSecretManagerInjector using
// NewK8sSecretFetcher (mechanism A: cluster-qualified k8s secret name).
func buildInjectorCS(
	t *testing.T,
	clusterName string,
	fakeClientset *k8sfake.Clientset,
	mockClient *mocks.MockableControllerRuntimeClient,
) SecretsInjector {
	t.Helper()
	secretClient := fakeClientset.CoreV1().Secrets(testReferenceNamespace)
	fetcher := NewK8sSecretFetcher(secretClient, clusterName)
	parentCfg := &config.Config{SecretEnvVarPrefix: config.DefaultSecretEnvVarPrefix}
	cache := newAlwaysMissCache(t)
	return NewEmbeddedSecretManagerInjector(
		config.EmbeddedSecretManagerConfig{
			Type: config.EmbeddedSecretManagerTypeK8s,
			K8sConfig: config.K8sConfig{
				Namespace:   testReferenceNamespace,
				ClusterName: clusterName,
			},
		},
		[]SecretFetcher{fetcher},
		mockClient,
		testPodNamespace,
		cache,
		parentCfg,
	)
}

// seedK8sSecretCS creates a k8s Secret in the fake clientset at testReferenceNamespace.
func seedK8sSecretCS(
	t *testing.T,
	fakeClientset *k8sfake.Clientset,
	storageName, dataKey, value string,
) {
	t.Helper()
	secret := &corev1.Secret{
		ObjectMeta: metav1.ObjectMeta{
			Name:      storageName,
			Namespace: testReferenceNamespace,
		},
		Data: map[string][]byte{dataKey: []byte(value)},
	}
	_, err := fakeClientset.CoreV1().Secrets(testReferenceNamespace).Create(
		context.Background(), secret, metav1.CreateOptions{})
	require.NoError(t, err)
}

// makeMockClientCS returns a permissive mock ctrl-runtime client.
func makeMockClientCS(t *testing.T) *mocks.MockableControllerRuntimeClient {
	t.Helper()
	mockClient := &mocks.MockableControllerRuntimeClient{}
	mockClient.On("Get",
		mock.Anything, mock.Anything, mock.Anything).
		Return(nil).Maybe()
	return mockClient
}

func runCaseClusterScopedSecret(t *testing.T, tc ValidationTestCase) gotClusterScopedSecret {
	t.Helper()

	clusterName := tc.Inputs["cluster_name"].(string)
	presentIDsRaw := tc.Inputs["present_ids"].([]interface{})
	keyKind := tc.Inputs["key_kind"].(string)

	ctx := context.Background()
	fakeClientset := k8sfake.NewSimpleClientset()

	// Determine which key to request.
	requestedKey := csClusterKey
	if keyKind == "non_cluster" {
		requestedKey = csSecondKey
	}

	// Project-level secretID for the requested key.
	projectScopeID := csProjectScopeID(requestedKey)

	// Check for special error sentinel.
	isErrorSentinel := false
	for _, pid := range presentIDsRaw {
		if pid.(string) == "__cluster_read_fails__" {
			isErrorSentinel = true
			break
		}
	}

	if isErrorSentinel {
		// Cluster copy read returns a non-not-found error.
		clusterScopeK8sName := EncodeK8sSecretName(EncodeClusterSecretName(clusterName, projectScopeID))
		fakeClientset.PrependReactor("get", "secrets", func(action k8sTesting.Action) (bool, runtime.Object, error) {
			ga := action.(k8sTesting.GetAction)
			if ga.GetName() == clusterScopeK8sName {
				return true, nil, errors.New("apiserver internal error")
			}
			return false, nil, nil
		})
		// Also seed shared so fallback would work (but must not be reached).
		sharedK8sName := EncodeK8sSecretName(projectScopeID)
		seedK8sSecretCS(t, fakeClientset, sharedK8sName, projectScopeID, "V_SHARED")
	} else {
		for _, pid := range presentIDsRaw {
			switch pid.(string) {
			case "cluster":
				clusterK8sName := EncodeK8sSecretName(EncodeClusterSecretName(clusterName, projectScopeID))
				seedK8sSecretCS(t, fakeClientset, clusterK8sName, projectScopeID, "V_CLUSTER")
			case "shared":
				sharedK8sName := EncodeK8sSecretName(projectScopeID)
				seedK8sSecretCS(t, fakeClientset, sharedK8sName, projectScopeID, "V_SHARED")
			}
		}
	}

	mockClient := makeMockClientCS(t)
	injector := buildInjectorCS(t, clusterName, fakeClientset, mockClient)

	pod := makeCsPod()
	secretReq := &core.Secret{
		Key:              requestedKey,
		MountRequirement: core.Secret_FILE,
	}

	newPod, injected, err := injector.Inject(ctx, secretReq, pod)

	var got gotClusterScopedSecret
	got.injected = injected
	got.isError = err != nil

	if err != nil {
		if stdlibErrors.IsCausedBy(err, ErrCodeSecretReadFailure) {
			got.errorCause = "SecretReadFailure"
		} else if stdlibErrors.IsCausedBy(err, ErrCodeSecretNotFoundAcrossAllScopes) {
			got.errorCause = "SecretNotFoundAcrossAllScopes"
		} else {
			got.errorCause = err.Error()
		}
	}

	if injected && newPod != nil {
		val, found := clusterCopyValueCS(newPod, requestedKey)
		if found {
			got.value = val
		}
	}

	return got
}
