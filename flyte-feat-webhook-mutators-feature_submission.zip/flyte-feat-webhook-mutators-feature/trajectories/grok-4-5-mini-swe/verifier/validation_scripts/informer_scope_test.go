package secret

import (
	"testing"

	"github.com/stretchr/testify/assert"

	"github.com/flyteorg/flyte/v2/flyteplugins/go/tasks/pluginmachinery/secret/config"
)

// TestInformerScope validates the Secret informer scope decision based on config.
// This test exercises the config-field decision that controls whether a Secrets
// informer is started and which namespaces it watches.
//
// The logic: a Secret informer is needed when:
//   - ImagePullSecrets.Enabled is true (image-pull reads use the controller-runtime client), OR
//   - The embedded secret manager type is K8s with a non-empty reference namespace
//     (the K8s fetcher reads Secrets from that namespace on the hot path).
//
// When needed and a referenceNamespace is set, the watch is scoped to that namespace.
// When needed but no referenceNamespace is set (e.g., image-pull with no K8s namespace),
// the exact watched set is implementation-defined (cluster-wide or per-pod-namespace).
func TestInformerScope(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			got := runCaseInformerScope(t, tc)

			// use_informer
			expectedUseInformer := tc.Expected["use_informer"].(bool)
			assert.Equal(t, expectedUseInformer, got.useInformer,
				"use_informer mismatch for type=%v image_pull=%v k8s_namespace=%v",
				tc.Inputs["type"], tc.Inputs["image_pull"], tc.Inputs["k8s_namespace"])

			// namespaces
			expectedNSRaw := tc.Expected["namespaces"].([]interface{})
			if len(expectedNSRaw) == 1 && expectedNSRaw[0].(string) == "__skip__" {
				// Do not assert namespace set for skip cases.
				return
			}

			expectedNS := make([]string, 0, len(expectedNSRaw))
			for _, v := range expectedNSRaw {
				expectedNS = append(expectedNS, v.(string))
			}

			if len(expectedNS) == 0 {
				assert.Empty(t, got.watchedNamespaces,
					"expected empty/nil namespace list (no watch or cluster-wide)")
			} else {
				assert.ElementsMatch(t, expectedNS, got.watchedNamespaces,
					"watched namespaces set mismatch")
				// Check no duplicates.
				seen := map[string]bool{}
				for _, ns := range got.watchedNamespaces {
					assert.False(t, seen[ns], "duplicate namespace %q in watched list", ns)
					seen[ns] = true
				}
			}
		})
	}
}

// gotInformerScope is the flat outcome struct.
type gotInformerScope struct {
	useInformer       bool
	watchedNamespaces []string
}

// secretWatchScopeIS computes the informer-scope decision from the config.
//
// A Secrets informer is needed when:
//  1. ImagePullSecrets is enabled — image-pull mirroring reads Secrets via the
//     controller-runtime client, so a watch is beneficial.
//  2. The embedded type is K8s AND K8sConfig.Namespace is non-empty — the K8s
//     secret fetcher reads from that namespace repeatedly on the hot path.
//
// When the watch is started and referenceNamespace is non-empty, the watch is
// scoped to that single namespace. When image-pull is enabled but no reference
// namespace is configured, the watched set is implementation-defined (the
// procedure marks those cases __skip__ so only use_informer is asserted).
func secretWatchScopeIS(cfg config.Config, podNamespace string) (useInformer bool, watchedNamespaces []string) {
	emCfg := cfg.EmbeddedSecretManagerConfig
	referenceNamespace := emCfg.K8sConfig.Namespace

	// An informer is needed when image-pull is enabled OR when the K8s embedded
	// type is active with a configured reference namespace.
	needsSecretWatch := emCfg.ImagePullSecrets.Enabled ||
		(emCfg.Type == config.EmbeddedSecretManagerTypeK8s && referenceNamespace != "")

	if !needsSecretWatch {
		return false, nil
	}
	if referenceNamespace != "" {
		// Scope the watch to the single namespace whose Secrets are read on the hot path.
		return true, []string{referenceNamespace}
	}
	// Needs watch but no specific namespace (e.g., image-pull with no K8s namespace):
	// cluster-wide or pod-namespace-scoped — implementation's choice, so we return
	// nil here (signals cluster-wide / unspecified). The procedure marks these __skip__.
	return true, nil
}

func runCaseInformerScope(t *testing.T, tc ValidationTestCase) gotInformerScope {
	t.Helper()

	typeStr := tc.Inputs["type"].(string)
	imagePull := tc.Inputs["image_pull"].(bool)
	k8sNamespace := tc.Inputs["k8s_namespace"].(string)

	var emType config.EmbeddedSecretManagerType
	switch typeStr {
	case "aws":
		emType = config.EmbeddedSecretManagerTypeAWS
	case "gcp":
		emType = config.EmbeddedSecretManagerTypeGCP
	case "k8s":
		emType = config.EmbeddedSecretManagerTypeK8s
	default:
		t.Fatalf("unknown type %q", typeStr)
	}

	cfg := config.Config{
		EmbeddedSecretManagerConfig: config.EmbeddedSecretManagerConfig{
			Type: emType,
			K8sConfig: config.K8sConfig{
				Namespace: k8sNamespace,
			},
			ImagePullSecrets: config.ImagePullSecretsConfig{
				Enabled: imagePull,
			},
		},
	}

	useInformer, watchedNS := secretWatchScopeIS(cfg, "flyte-system")
	return gotInformerScope{
		useInformer:       useInformer,
		watchedNamespaces: watchedNS,
	}
}
