package webhook

import (
	"bytes"
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	cryptorand "crypto/rand"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"math/big"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	corev1 "k8s.io/api/core/v1"
	kubeErrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	k8sfake "k8s.io/client-go/kubernetes/fake"
	k8sTesting "k8s.io/client-go/testing"

	webhookConfig "github.com/flyteorg/flyte/v2/flyteplugins/go/tasks/pluginmachinery/secret/config"
)

// TestCertReuseAndConcurrency validates keep-vs-reissue and race-convergence.
func TestCertReuseAndConcurrency(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			got := runCaseCertReuseAndConcurrency(t, tc)

			// regenerated
			expectedRegenerated := tc.Expected["regenerated"].(bool)
			assert.Equal(t, expectedRegenerated, got.regenerated,
				"regenerated mismatch for existing=%q", tc.Inputs["existing"])

			// adopt_winner
			adoptWinner := tc.Expected["adopt_winner"].(string)
			if adoptWinner != "__skip__" {
				assert.Equal(t, adoptWinner, got.adoptWinnerMarker,
					"adopt_winner mismatch")
			}

			// local_files_match_stored
			localFilesMatch := tc.Expected["local_files_match_stored"].(string)
			if localFilesMatch != "__skip__" {
				assert.Equal(t, localFilesMatch, got.localFilesMatchStored,
					"local_files_match_stored mismatch")
			}
		})
	}
}

// gotCertReuseAndConcurrency is the flat outcome struct.
type gotCertReuseAndConcurrency struct {
	regenerated           bool
	adoptWinnerMarker     string // "winner" or ""
	localFilesMatchStored string // "match" or ""
}

const (
	testServiceNameCRC = "flyte-pod-webhook"
	testNamespaceCRC   = "flyte"
	testSecretNameCRC  = "flyte-pod-webhook"
)

// webhookCertsToDataCRC converts webhookCerts to the Secret Data map.
func webhookCertsToDataCRC(certs webhookCerts) map[string][]byte {
	return map[string][]byte{
		CaCertKey:            certs.CaPEM.Bytes(),
		ServerCertKey:        certs.ServerPEM.Bytes(),
		ServerCertPrivateKey: certs.PrivateKeyPEM.Bytes(),
	}
}

// makeShortExpirySecretDataCRC creates cert data with server cert expiring ~1 hour from now.
// A 1-hour expiry is inside any sensible renewal window (minCertRemaining = 30 days).
func makeShortExpirySecretDataCRC(t *testing.T) map[string][]byte {
	t.Helper()
	// Build a minimal CA.
	caKey, err := ecdsa.GenerateKey(elliptic.P256(), cryptorand.Reader)
	require.NoError(t, err)
	caTemplate := &x509.Certificate{
		SerialNumber:          big.NewInt(1),
		Subject:               pkix.Name{Organization: []string{"test"}},
		NotBefore:             time.Now().Add(-time.Hour),
		NotAfter:              time.Now().AddDate(99, 0, 0),
		IsCA:                  true,
		BasicConstraintsValid: true,
		KeyUsage:              x509.KeyUsageCertSign | x509.KeyUsageDigitalSignature,
	}
	caDER, err := x509.CreateCertificate(cryptorand.Reader, caTemplate, caTemplate, &caKey.PublicKey, caKey)
	require.NoError(t, err)
	caPEM := new(bytes.Buffer)
	require.NoError(t, pem.Encode(caPEM, &pem.Block{Type: "CERTIFICATE", Bytes: caDER}))

	// Server cert expires in 1 hour — inside the 30-day renewal window.
	srvKey, err := ecdsa.GenerateKey(elliptic.P256(), cryptorand.Reader)
	require.NoError(t, err)
	srvTemplate := &x509.Certificate{
		SerialNumber: big.NewInt(2),
		Subject: pkix.Name{
			CommonName:   testServiceNameCRC + "." + testNamespaceCRC + ".svc",
			Organization: []string{"test"},
		},
		DNSNames: []string{
			testServiceNameCRC,
			testServiceNameCRC + "." + testNamespaceCRC,
			testServiceNameCRC + "." + testNamespaceCRC + ".svc",
		},
		NotBefore:   time.Now().Add(-time.Minute),
		NotAfter:    time.Now().Add(time.Hour),
		ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth, x509.ExtKeyUsageClientAuth},
	}
	caCert, err := x509.ParseCertificate(caDER)
	require.NoError(t, err)
	srvDER, err := x509.CreateCertificate(cryptorand.Reader, srvTemplate, caCert, &srvKey.PublicKey, caKey)
	require.NoError(t, err)
	srvPEM := new(bytes.Buffer)
	require.NoError(t, pem.Encode(srvPEM, &pem.Block{Type: "CERTIFICATE", Bytes: srvDER}))

	srvKeyBytes, err := x509.MarshalECPrivateKey(srvKey)
	require.NoError(t, err)
	srvKeyPEM := new(bytes.Buffer)
	require.NoError(t, pem.Encode(srvKeyPEM, &pem.Block{Type: "EC PRIVATE KEY", Bytes: srvKeyBytes}))

	return map[string][]byte{
		CaCertKey:            caPEM.Bytes(),
		ServerCertKey:        srvPEM.Bytes(),
		ServerCertPrivateKey: srvKeyPEM.Bytes(),
	}
}

func runCaseCertReuseAndConcurrency(t *testing.T, tc ValidationTestCase) gotCertReuseAndConcurrency {
	t.Helper()
	existing := tc.Inputs["existing"].(string)

	ctx := context.Background()
	certDir := t.TempDir()
	cfg := &webhookConfig.Config{
		SecretName:  testSecretNameCRC,
		ServiceName: testServiceNameCRC,
		LocalCert:   false,
		CertDir:     certDir,
	}

	switch existing {
	case "valid":
		// Seed a fully valid Secret; must be kept as-is.
		certs, err := createCerts(testServiceNameCRC, testNamespaceCRC)
		require.NoError(t, err)
		originalData := webhookCertsToDataCRC(certs)
		secret := &corev1.Secret{
			ObjectMeta: metav1.ObjectMeta{Name: testSecretNameCRC, Namespace: testNamespaceCRC},
			Data:       originalData,
		}
		client := k8sfake.NewSimpleClientset(secret)
		require.NoError(t, InitCerts(ctx, client, cfg, testNamespaceCRC))
		stored, err := client.CoreV1().Secrets(testNamespaceCRC).Get(ctx, testSecretNameCRC, metav1.GetOptions{})
		require.NoError(t, err)
		regenerated := !bytes.Equal(stored.Data[ServerCertKey], originalData[ServerCertKey])
		return gotCertReuseAndConcurrency{regenerated: regenerated}

	case "none":
		// No pre-existing Secret → must issue a new identity.
		client := k8sfake.NewSimpleClientset()
		require.NoError(t, InitCerts(ctx, client, cfg, testNamespaceCRC))
		stored, err := client.CoreV1().Secrets(testNamespaceCRC).Get(ctx, testSecretNameCRC, metav1.GetOptions{})
		require.NoError(t, err)
		ok, _ := isUsableTLSIdentity(stored.Data, testServiceNameCRC, testNamespaceCRC)
		return gotCertReuseAndConcurrency{regenerated: ok}

	case "inside_window":
		// Present but cert expires within renewal window (1 hour) → reissue.
		data := makeShortExpirySecretDataCRC(t)
		secret := &corev1.Secret{
			ObjectMeta: metav1.ObjectMeta{Name: testSecretNameCRC, Namespace: testNamespaceCRC},
			Data:       data,
		}
		client := k8sfake.NewSimpleClientset(secret)
		require.NoError(t, InitCerts(ctx, client, cfg, testNamespaceCRC))
		stored, err := client.CoreV1().Secrets(testNamespaceCRC).Get(ctx, testSecretNameCRC, metav1.GetOptions{})
		require.NoError(t, err)
		regenerated := !bytes.Equal(stored.Data[ServerCertKey], data[ServerCertKey])
		return gotCertReuseAndConcurrency{regenerated: regenerated}

	case "wrong_namespace":
		// Cert DNS names cover namespace "other", not "flyte" → reissue.
		certs, err := createCerts(testServiceNameCRC, "other")
		require.NoError(t, err)
		wrongData := webhookCertsToDataCRC(certs)
		secret := &corev1.Secret{
			ObjectMeta: metav1.ObjectMeta{Name: testSecretNameCRC, Namespace: testNamespaceCRC},
			Data:       wrongData,
		}
		client := k8sfake.NewSimpleClientset(secret)
		require.NoError(t, InitCerts(ctx, client, cfg, testNamespaceCRC))
		stored, err := client.CoreV1().Secrets(testNamespaceCRC).Get(ctx, testSecretNameCRC, metav1.GetOptions{})
		require.NoError(t, err)
		regenerated := !bytes.Equal(stored.Data[ServerCertKey], wrongData[ServerCertKey])
		return gotCertReuseAndConcurrency{regenerated: regenerated}

	case "adopt_winner":
		// Winner Secret is already in the tracker. Simulate concurrent replica race:
		//   - Our first Get returns NotFound (reactor) → we decide to create.
		//   - Create fails AlreadyExists (winner is in tracker).
		//   - Our second Get (inside createWebhookSecret) reads winner from tracker.
		//   - We adopt the winner's bytes.
		// Drive through InitCerts so the full flow is exercised.
		winnerCerts, err := createCerts(testServiceNameCRC, testNamespaceCRC)
		require.NoError(t, err)
		winnerData := webhookCertsToDataCRC(winnerCerts)
		winnerSecret := &corev1.Secret{
			ObjectMeta: metav1.ObjectMeta{Name: testSecretNameCRC, Namespace: testNamespaceCRC},
			Data:       winnerData,
		}
		client := k8sfake.NewSimpleClientset(winnerSecret)

		// First Get returns NotFound; subsequent Gets go to the tracker.
		firstGetDone := false
		client.PrependReactor("get", "secrets", func(action k8sTesting.Action) (bool, runtime.Object, error) {
			if !firstGetDone {
				firstGetDone = true
				return true, nil, kubeErrors.NewNotFound(
					schema.GroupResource{Resource: "secrets"},
					action.(k8sTesting.GetAction).GetName())
			}
			return false, nil, nil // defer to tracker
		})

		// InitCerts: Get→NotFound, generate certs, Create→AlreadyExists, Get→winner, adopt.
		require.NoError(t, InitCerts(ctx, client, cfg, testNamespaceCRC),
			"InitCerts must succeed by adopting winner")

		stored, err := client.CoreV1().Secrets(testNamespaceCRC).Get(ctx, testSecretNameCRC, metav1.GetOptions{})
		require.NoError(t, err)
		adoptedWinner := bytes.Equal(stored.Data[ServerCertKey], winnerData[ServerCertKey])
		marker := ""
		if adoptedWinner {
			marker = "winner"
		}
		return gotCertReuseAndConcurrency{
			regenerated:       true, // a generation was attempted (fresh certs were generated before Create)
			adoptWinnerMarker: marker,
		}

	case "local_cert_writes_stored":
		// Seed valid Secret; with LocalCert=true, files on disk must match stored.
		certs, err := createCerts(testServiceNameCRC, testNamespaceCRC)
		require.NoError(t, err)
		originalData := webhookCertsToDataCRC(certs)
		secret := &corev1.Secret{
			ObjectMeta: metav1.ObjectMeta{Name: testSecretNameCRC, Namespace: testNamespaceCRC},
			Data:       originalData,
		}
		client := k8sfake.NewSimpleClientset(secret)
		localCfg := &webhookConfig.Config{
			SecretName:  testSecretNameCRC,
			ServiceName: testServiceNameCRC,
			LocalCert:   true,
			CertDir:     certDir,
		}
		require.NoError(t, InitCerts(ctx, client, localCfg, testNamespaceCRC))

		stored, err := client.CoreV1().Secrets(testNamespaceCRC).Get(ctx, testSecretNameCRC, metav1.GetOptions{})
		require.NoError(t, err)

		// Each file on disk must match the stored Secret's value.
		keys := []string{CaCertKey, ServerCertKey, ServerCertPrivateKey}
		allMatch := true
		for _, key := range keys {
			filePath := filepath.Join(certDir, key)
			fileBytes, readErr := os.ReadFile(filePath)
			if readErr != nil {
				t.Logf("cannot read file %s: %v", filePath, readErr)
				allMatch = false
				continue
			}
			if !bytes.Equal(fileBytes, stored.Data[key]) {
				t.Logf("file %s does not match stored Secret data for key %s", filePath, key)
				allMatch = false
			}
		}

		fileMarker := ""
		if allMatch {
			fileMarker = "match"
		}
		regenerated := !bytes.Equal(stored.Data[ServerCertKey], originalData[ServerCertKey])
		return gotCertReuseAndConcurrency{
			regenerated:           regenerated,
			localFilesMatchStored: fileMarker,
		}

	default:
		t.Fatalf("unhandled input existing=%q", existing)
		return gotCertReuseAndConcurrency{}
	}
}
