package webhook

import (
	"context"
	"encoding/json"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	admissionv1 "k8s.io/api/admission/v1"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/types"
	"sigs.k8s.io/controller-runtime/pkg/webhook/admission"

	webhookConfig "github.com/flyteorg/flyte/v2/flyteplugins/go/tasks/pluginmachinery/secret/config"
)

// TestWebhookHandlers exercises handler registration and webhook config rendering.
func TestWebhookHandlers(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			got := runCaseWebhookHandlers(t, tc)

			// expect_error (checked first so we can skip further assertions on error cases)
			expectError := tc.Expected["expect_error"].(string)
			if expectError == "yes" {
				require.Error(t, got.constructErr, "construction must fail for duplicate paths")
			} else {
				require.NoError(t, got.constructErr, "construction must succeed")
			}

			// builtin_legacy_path
			builtinLegacyPath := tc.Expected["builtin_legacy_path"].(string)
			if builtinLegacyPath != "__skip__" {
				require.NotEmpty(t, got.builtinPaths, "built-in handler must have paths")
				assert.Contains(t, got.builtinPaths, builtinLegacyPath,
					"legacy path must be among built-in handler paths")
			}

			// builtin_service_path
			builtinServicePath := tc.Expected["builtin_service_path"].(string)
			if builtinServicePath != "__skip__" && got.webhookCfgErr == nil {
				require.NotEmpty(t, got.webhookCfgServicePaths, "webhook config must have service paths")
				assert.Equal(t, builtinServicePath, got.webhookCfgServicePaths[0],
					"first webhook in config must be legacy path")
			}

			// handler_count
			handlerCount := int(tc.Expected["handler_count"].(float64))
			if handlerCount >= 0 {
				assert.Equal(t, handlerCount, got.handlerCount, "handler count mismatch")
				// Verify path disjointness for extra mutators.
				if expectError == "no" {
					// Built-in paths, extra pod paths, extra node paths must be pairwise disjoint and non-empty.
					builtinSet := toStringSet(got.builtinPaths)
					extraPodSet := toStringSet(got.extraPodHandlerPaths)
					extraNodeSet := toStringSet(got.extraNodeHandlerPaths)
					assert.NotEmpty(t, extraPodSet, "extra pod handler must have non-empty path set")
					assert.NotEmpty(t, extraNodeSet, "extra node handler must have non-empty path set")
					for p := range extraPodSet {
						assert.NotContains(t, builtinSet, p,
							"extra pod path %q must differ from built-in paths", p)
						assert.NotContains(t, extraNodeSet, p,
							"extra pod path %q must differ from node paths", p)
					}
				}
			}

			// pod_selector_value
			podSelectorValue := tc.Expected["pod_selector_value"].(string)
			if podSelectorValue != "__skip__" {
				assert.Equal(t, podSelectorValue, got.extraPodHandlerSelector["select"],
					"extra pod handler selector value mismatch")
			}

			// node_namespace_selector
			nodeNSSelector := tc.Expected["node_namespace_selector"].(string)
			if nodeNSSelector != "__skip__" && nodeNSSelector == "nil" {
				assert.True(t, got.nodeWebhookNSSelectorIsNil,
					"node webhook NamespaceSelector must be nil (nodes are cluster-scoped)")
			}

			// timeout_seconds
			timeoutSeconds := int(tc.Expected["timeout_seconds"].(float64))
			if timeoutSeconds >= 0 {
				require.NotEmpty(t, got.webhookTimeouts, "must have at least one webhook")
				for i, ts := range got.webhookTimeouts {
					assert.NotNil(t, ts, "webhook %d TimeoutSeconds must not be nil", i)
					if ts != nil {
						assert.Equal(t, int32(timeoutSeconds), *ts,
							"webhook %d timeout mismatch", i)
					}
				}
			}

			// min_patch_count and patch_path
			minPatchCount := int(tc.Expected["min_patch_count"].(float64))
			patchPath := tc.Expected["patch_path"].(string)
			if minPatchCount >= 0 && patchPath != "__skip__" {
				assert.True(t, got.admissionAllowed, "admission must be allowed")
				assert.GreaterOrEqual(t, len(got.patchOps), minPatchCount,
					"patch count must meet minimum")
				if len(got.patchOps) > 0 {
					assert.Equal(t, patchPath, got.patchOps[0]["path"],
						"first patch path mismatch")
				}
			}
		})
	}
}

// gotWebhookHandlers is the flat outcome struct for webhook_handlers.
type gotWebhookHandlers struct {
	constructErr               error
	handlerCount               int
	builtinPaths               []string
	extraPodHandlerPaths       []string
	extraNodeHandlerPaths      []string
	extraPodHandlerSelector    map[string]string
	nodeWebhookNSSelectorIsNil bool
	webhookCfgServicePaths     []string
	webhookCfgErr              error
	webhookTimeouts            []*int32
	admissionAllowed           bool
	patchOps                   []map[string]interface{}
}

// toStringSet converts a slice to a set for membership tests.
func toStringSet(ss []string) map[string]struct{} {
	m := make(map[string]struct{}, len(ss))
	for _, s := range ss {
		m[s] = struct{}{}
	}
	return m
}

// labelAddingPodMutationWH is a file-unique PodMutation that adds a label.
type labelAddingPodMutationWH struct {
	id       string
	selector *metav1.LabelSelector
}

func (m labelAddingPodMutationWH) ID() string                           { return m.id }
func (m labelAddingPodMutationWH) Path() string                         { return "" }
func (m labelAddingPodMutationWH) LabelSelector() *metav1.LabelSelector { return m.selector }
func (m labelAddingPodMutationWH) Mutate(ctx context.Context, pod *corev1.Pod) (*corev1.Pod, bool, *admission.Response) {
	if pod.Labels == nil {
		pod.Labels = map[string]string{}
	}
	pod.Labels["mutated-by"] = m.id
	return pod, true, nil
}

// nopNodeMutationWH is a file-unique NodeMutation that does nothing.
type nopNodeMutationWH struct {
	id       string
	selector *metav1.LabelSelector
}

func (n nopNodeMutationWH) ID() string                           { return n.id }
func (n nopNodeMutationWH) Path() string                         { return "" }
func (n nopNodeMutationWH) LabelSelector() *metav1.LabelSelector { return n.selector }
func (n nopNodeMutationWH) Mutate(ctx context.Context, node *corev1.Node) (*corev1.Node, bool, *admission.Response) {
	return node, false, nil
}

// buildTestWebhookWH builds a MutatingWebhook via struct literal (no kubeConfig needed).
func buildTestWebhookWH(t *testing.T, timeoutSeconds int, extraPods []PodMutation, extraNodes []NodeMutation) (*MutatingWebhook, error) {
	t.Helper()
	certDir := t.TempDir()
	timeout := int32(timeoutSeconds)

	allPods := make([]PodMutation, 0, 1+len(extraPods))
	// Built-in secret mutation uses the legacy path.
	allPods = append(allPods, stubPodMutation{id: "secrets", path: SecretsMutatePath, selector: nil})
	allPods = append(allPods, extraPods...)

	if err := validateMutationPaths(allPods, extraNodes); err != nil {
		return nil, err
	}

	scheme := runtime.NewScheme()
	_ = corev1.AddToScheme(scheme)

	return &MutatingWebhook{
		decoder:       admission.NewDecoder(scheme),
		cfg:           &webhookConfig.Config{ServiceName: "flyte-pod-webhook", ServicePort: 443, CertDir: certDir, WebhookTimeout: timeout},
		podMutations:  allPods,
		nodeMutations: extraNodes,
	}, nil
}

func runCaseWebhookHandlers(t *testing.T, tc ValidationTestCase) gotWebhookHandlers {
	t.Helper()

	timeoutSeconds := int(tc.Inputs["timeout_seconds"].(float64))
	expectError := tc.Expected["expect_error"].(string)
	handlerCount := int(tc.Expected["handler_count"].(float64))
	minPatchCount := int(tc.Expected["min_patch_count"].(float64))

	var got gotWebhookHandlers

	if expectError == "yes" {
		// duplicate_rejected: two pod mutators with the same id → same derived path.
		dupMutation1 := stubPodMutation{id: "a", path: ""}
		dupMutation2 := stubPodMutation{id: "a", path: ""}
		_, got.constructErr = buildTestWebhookWH(t, timeoutSeconds,
			[]PodMutation{dupMutation1, dupMutation2}, nil)
		return got
	}

	if handlerCount >= 0 {
		// extra_pod_and_node: one extra pod mutator + one extra node mutator.
		selinuxMutator := labelAddingPodMutationWH{
			id:       "selinux",
			selector: &metav1.LabelSelector{MatchLabels: map[string]string{"select": "selinux"}},
		}
		taintsMutator := nopNodeMutationWH{
			id:       "taints",
			selector: nil,
		}
		wh, err := buildTestWebhookWH(t, timeoutSeconds,
			[]PodMutation{selinuxMutator}, []NodeMutation{taintsMutator})
		got.constructErr = err
		if err != nil {
			return got
		}

		got.handlerCount = len(wh.podMutations) + len(wh.nodeMutations)
		got.builtinPaths = collectPodHandlerPathsWH(wh.podMutations[:1])
		got.extraPodHandlerPaths = collectPodHandlerPathsWH(wh.podMutations[1:])
		got.extraNodeHandlerPaths = collectNodeHandlerPathsWH(wh.nodeMutations)

		if sel := selinuxMutator.LabelSelector(); sel != nil {
			got.extraPodHandlerSelector = sel.MatchLabels
		}

		cfg, cfgErr := wh.CreateMutationWebhookConfiguration("flyte")
		got.webhookCfgErr = cfgErr
		if cfgErr == nil {
			for _, wk := range cfg.Webhooks {
				p := ""
				if wk.ClientConfig.Service != nil && wk.ClientConfig.Service.Path != nil {
					p = *wk.ClientConfig.Service.Path
				}
				got.webhookCfgServicePaths = append(got.webhookCfgServicePaths, p)
				got.webhookTimeouts = append(got.webhookTimeouts, wk.TimeoutSeconds)
			}
			for _, wk := range cfg.Webhooks {
				for _, rule := range wk.Rules {
					for _, res := range rule.Resources {
						if res == "nodes" {
							got.nodeWebhookNSSelectorIsNil = (wk.NamespaceSelector == nil)
						}
					}
				}
			}
		}
		return got
	}

	if minPatchCount >= 0 {
		// patches_pod: extra label-adding pod mutator, call Handle.
		selinuxMutator := labelAddingPodMutationWH{
			id:       "selinux",
			selector: &metav1.LabelSelector{MatchLabels: map[string]string{"select": "selinux"}},
		}
		wh, err := buildTestWebhookWH(t, timeoutSeconds,
			[]PodMutation{selinuxMutator}, nil)
		got.constructErr = err
		if err != nil {
			return got
		}

		scheme := runtime.NewScheme()
		_ = corev1.AddToScheme(scheme)
		handler := &podMutationHandler{
			decoder:  admission.NewDecoder(scheme),
			mutation: wh.podMutations[1], // extra pod handler
		}

		pod := &corev1.Pod{
			TypeMeta: metav1.TypeMeta{Kind: "Pod", APIVersion: "v1"},
		}
		rawPod, err := json.Marshal(pod)
		require.NoError(t, err, "failed to marshal test pod")

		req := admission.Request{
			AdmissionRequest: admissionv1.AdmissionRequest{
				UID:    types.UID("test-uid"),
				Object: runtime.RawExtension{Raw: rawPod},
			},
		}
		resp := handler.Handle(context.Background(), req)
		got.admissionAllowed = resp.Allowed
		for _, op := range resp.Patches {
			got.patchOps = append(got.patchOps, map[string]interface{}{
				"op":   op.Operation,
				"path": op.Path,
			})
		}
		return got
	}

	// builtin_paths: build with NO extra mutators.
	wh, err := buildTestWebhookWH(t, timeoutSeconds, nil, nil)
	got.constructErr = err
	if err != nil {
		return got
	}

	got.handlerCount = len(wh.podMutations) + len(wh.nodeMutations)
	got.builtinPaths = collectPodHandlerPathsWH(wh.podMutations)

	cfg, cfgErr := wh.CreateMutationWebhookConfiguration("flyte")
	got.webhookCfgErr = cfgErr
	if cfgErr == nil {
		for _, wk := range cfg.Webhooks {
			p := ""
			if wk.ClientConfig.Service != nil && wk.ClientConfig.Service.Path != nil {
				p = *wk.ClientConfig.Service.Path
			}
			got.webhookCfgServicePaths = append(got.webhookCfgServicePaths, p)
			got.webhookTimeouts = append(got.webhookTimeouts, wk.TimeoutSeconds)
		}
	}

	return got
}

func collectPodHandlerPathsWH(mutations []PodMutation) []string {
	paths := make([]string, 0, len(mutations))
	for _, m := range mutations {
		paths = append(paths, resolvePodMutationPath(m))
	}
	return paths
}

func collectNodeHandlerPathsWH(mutations []NodeMutation) []string {
	paths := make([]string, 0, len(mutations))
	for _, m := range mutations {
		paths = append(paths, resolveNodeMutationPath(m))
	}
	return paths
}
