package secret

import (
	"context"
	"encoding/base64"
	"errors"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/client-go/kubernetes/fake"
	k8sTesting "k8s.io/client-go/testing"

	"github.com/flyteorg/flyte/v2/flyteplugins/go/tasks/pluginmachinery/secret/config"
	"github.com/flyteorg/flyte/v2/flyteplugins/go/tasks/pluginmachinery/secret/mocks"
	stdlibErrors "github.com/flyteorg/flyte/v2/flytestdlib/errors"
	"github.com/flyteorg/flyte/v2/gen/go/flyteidl2/core"
)

// Cluster-scoped secret story constants.
const (
	// clusterKeyCS is the key we request as a per-cluster secret.
	clusterKeyCS = "my-cluster-secret"
	// secondKeyCS is a distinct ordinary key.
	secondKeyCS = "my-ordinary-secret"
	// clusterNSCS is the cluster namespace for the cluster-scoped copy.
	clusterNSCS = "flyte-cluster"
	// sharedNSCS is the shared namespace for the shared copy.
	sharedNSCS = "flyte"
)

// podLabelsCS are the pod labels used for every cluster_scoped_secret test.
var podLabelsCS = map[string]string{
	"organization": "o-apple",
	"domain":       "d-cherry",
	"project":      "p-banana",
}

// parentCfgCS is the parent config used for all cluster_scoped_secret tests.
var parentCfgCS = &config.Config{SecretEnvVarPrefix: config.DefaultSecretEnvVarPrefix}

// TestClusterScopedSecret is the entry point for the cluster_scoped_secret story.
func TestClusterScopedSecret(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			got := runCaseClusterScopedSecret(t, tc)

			// injected
			expectedInjected := tc.Expected["injected"].(bool)
			assert.Equal(t, expectedInjected, got.injected, "injected mismatch for case %q", tc.Name)

			// value
			expectedValue := tc.Expected["value"].(string)
			if expectedValue != "__skip__" {
				assert.Equal(t, expectedValue, got.value, "value mismatch for case %q", tc.Name)
			}

			// is_error
			expectedIsError := tc.Expected["is_error"].(bool)
			assert.Equal(t, expectedIsError, got.isError, "is_error mismatch for case %q", tc.Name)

			// error_cause
			expectedErrorCause := tc.Expected["error_cause"].(string)
			if expectedErrorCause != "__skip__" {
				if expectedErrorCause == "SecretReadFailure" {
					assert.True(t, stdlibErrors.IsCausedBy(got.err, ErrCodeSecretReadFailure),
						"expected error caused by SecretReadFailure for case %q, got: %v", tc.Name, got.err)
				}
			}
		})
	}
}

// gotClusterScopedSecret holds the flat outcome for one test case.
type gotClusterScopedSecret struct {
	injected bool
	value    string
	isError  bool
	err      error
}

func runCaseClusterScopedSecret(t *testing.T, tc ValidationTestCase) gotClusterScopedSecret {
	t.Helper()
	ctx := context.Background()

	clusterNameRaw := tc.Inputs["cluster_name"].(string)
	keyKind := tc.Inputs["key_kind"].(string)
	presentIDsRaw := tc.Inputs["present_ids"].([]interface{})

	// Collect present_ids as strings
	var presentIDs []string
	for _, v := range presentIDsRaw {
		presentIDs = append(presentIDs, v.(string))
	}

	// Determine which key we're requesting
	var requestedKey string
	switch keyKind {
	case "per_cluster":
		requestedKey = clusterKeyCS
	case "non_cluster":
		requestedKey = secondKeyCS
	default:
		t.Fatalf("unknown key_kind: %q", keyKind)
	}

	// Compute the project-scoped secretID for the requested key.
	org := podLabelsCS["organization"]
	domain := podLabelsCS["domain"]
	project := podLabelsCS["project"]
	secretID := EncodeSecretName(org, domain, project, requestedKey)
	k8sSecretName := EncodeK8sSecretName(secretID)

	// Detect the error case
	isErrorCase := len(presentIDs) == 1 && presentIDs[0] == "__cluster_read_fails__"

	// Build shared fake clientset
	sharedCS := fake.NewSimpleClientset()
	// Build cluster fake clientset (may be nil if no cluster configured)
	var clusterCS *fake.Clientset
	if clusterNameRaw != "" {
		clusterCS = fake.NewSimpleClientset()
	}

	// Seed the copies based on present_ids
	for _, pid := range presentIDs {
		switch pid {
		case "cluster":
			if clusterCS != nil {
				clusterSecret := &corev1.Secret{
					ObjectMeta: metav1.ObjectMeta{
						Name:      k8sSecretName,
						Namespace: clusterNSCS,
					},
					Data: map[string][]byte{secretID: []byte("V_CLUSTER")},
				}
				_, err := clusterCS.CoreV1().Secrets(clusterNSCS).Create(ctx, clusterSecret, metav1.CreateOptions{})
				require.NoError(t, err)
			}
		case "shared":
			sharedSecret := &corev1.Secret{
				ObjectMeta: metav1.ObjectMeta{
					Name:      k8sSecretName,
					Namespace: sharedNSCS,
				},
				Data: map[string][]byte{secretID: []byte("V_SHARED")},
			}
			_, err := sharedCS.CoreV1().Secrets(sharedNSCS).Create(ctx, sharedSecret, metav1.CreateOptions{})
			require.NoError(t, err)
		case "__cluster_read_fails__":
			// Wire cluster client to return a genuine non-not-found error
			if clusterCS != nil {
				clusterCS.PrependReactor("get", "secrets", func(action k8sTesting.Action) (bool, runtime.Object, error) {
					return true, nil, errors.New("simulated cluster read failure")
				})
			}
		default:
			t.Fatalf("unknown present_ids value: %q", pid)
		}
	}

	// Build the fetcher using mechanism B (cluster namespace client first, shared as fallback)
	var fetcher SecretFetcher
	if clusterNameRaw != "" && clusterCS != nil {
		fetcher = NewClusterAwareK8sSecretFetcher(
			sharedCS.CoreV1().Secrets(sharedNSCS),
			clusterCS.CoreV1().Secrets(clusterNSCS),
		)
	} else {
		// No cluster configured: unqualified lookup (nil cluster client)
		fetcher = NewClusterAwareK8sSecretFetcher(
			sharedCS.CoreV1().Secrets(sharedNSCS),
			nil,
		)
	}

	// Use a minimal mock k8sClient (not called for FILE mounts with non-K8s embedded type)
	mockClient := &mocks.MockableControllerRuntimeClient{}

	secretCache := newAlwaysMissCache(t)

	embCfg := config.EmbeddedSecretManagerConfig{
		// Use non-K8s embedded type so isK8sSecret=false and k8sClient.Get is skipped.
		Type: config.EmbeddedSecretManagerTypeAWS,
		FileMountInitContainer: config.FileMountInitContainerConfig{
			ContainerName: "init-embedded-secret",
		},
	}

	injector := NewEmbeddedSecretManagerInjector(
		embCfg,
		[]SecretFetcher{fetcher},
		mockClient,
		testReferenceNamespace,
		secretCache,
		parentCfgCS,
	)

	// Build a pod
	pod := &corev1.Pod{
		ObjectMeta: metav1.ObjectMeta{
			Namespace: testPodNamespace,
			Labels:    podLabelsCS,
		},
		Spec: corev1.PodSpec{
			Containers: []corev1.Container{{Name: "main"}},
		},
	}

	// Request the secret as a FILE mount
	secret := &core.Secret{
		Key:              requestedKey,
		MountRequirement: core.Secret_FILE,
	}

	resultPod, injected, err := injector.Inject(ctx, secret, pod)

	if isErrorCase {
		return gotClusterScopedSecret{
			injected: injected,
			value:    "",
			isError:  err != nil,
			err:      err,
		}
	}

	var value string
	if injected && resultPod != nil {
		value, _ = clusterCopyValueCS(resultPod, requestedKey)
	}

	return gotClusterScopedSecret{
		injected: injected,
		value:    value,
		isError:  err != nil,
		err:      err,
	}
}

// clusterCopyValueCS reads the injected file-mount value for the given secretKey from the pod's
// init containers by scanning the SECRETS env var (EmbeddedSecretsFileMountInitContainerEnvVariableName).
// The format is: "key=base64(value)\n"
func clusterCopyValueCS(pod *corev1.Pod, secretKey string) (string, bool) {
	for _, ic := range pod.Spec.InitContainers {
		for _, env := range ic.Env {
			if env.Name != EmbeddedSecretsFileMountInitContainerEnvVariableName {
				continue
			}
			lines := strings.Split(env.Value, "\n")
			for _, line := range lines {
				eqIdx := strings.Index(line, "=")
				if eqIdx < 0 {
					continue
				}
				k := line[:eqIdx]
				v := line[eqIdx+1:]
				if k == secretKey {
					decoded, err := base64.StdEncoding.DecodeString(v)
					if err != nil {
						return "", false
					}
					return string(decoded), true
				}
			}
		}
	}
	return "", false
}
