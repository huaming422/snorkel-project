package webhook

import (
	"bytes"
	"context"
	cryptorand "crypto/rand"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"math/big"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	corev1 "k8s.io/api/core/v1"
	k8sErrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/client-go/kubernetes/fake"
	k8sTesting "k8s.io/client-go/testing"

	webhookConfig "github.com/flyteorg/flyte/v2/flyteplugins/go/tasks/pluginmachinery/secret/config"
)

const (
	crcServiceName = "flyte-pod-webhook"
	crcSecretName  = "flyte-pod-webhook"
	crcNamespace   = "flyte"
)

// TestCertReuseAndConcurrency is the entry point for the cert_reuse_and_concurrency story.
func TestCertReuseAndConcurrency(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			got := runCaseCertReuseAndConcurrency(t, tc)

			// regenerated
			expectedRegenerated := tc.Expected["regenerated"].(bool)
			assert.Equal(t, expectedRegenerated, got.regenerated,
				"regenerated mismatch for case %q", tc.Name)

			// adopt_winner
			expectedAdoptWinner := tc.Expected["adopt_winner"].(string)
			if expectedAdoptWinner != "__skip__" && expectedAdoptWinner == "winner" {
				assert.True(t, got.adoptedWinner,
					"expected returned data to equal winner data for case %q", tc.Name)
				// Direct equality: the full stored data map must equal the winner's data.
				assert.Equal(t, got.winnerData, got.storedData,
					"stored data must equal winner data for case %q", tc.Name)
			}

			// local_files_match_stored
			expectedLocalFiles := tc.Expected["local_files_match_stored"].(string)
			if expectedLocalFiles != "__skip__" && expectedLocalFiles == "match" {
				assert.True(t, got.localFilesMatchStored,
					"expected on-disk files to match stored secret for case %q", tc.Name)
			}
		})
	}
}

// gotCertReuseAndConcurrency holds the flat outcome for one test case.
type gotCertReuseAndConcurrency struct {
	regenerated           bool
	adoptedWinner         bool
	winnerData            map[string][]byte // non-nil only for adopt_winner case
	storedData            map[string][]byte // the secret data after InitCerts completes
	localFilesMatchStored bool
}

func runCaseCertReuseAndConcurrency(t *testing.T, tc ValidationTestCase) gotCertReuseAndConcurrency {
	t.Helper()
	ctx := context.Background()
	existing := tc.Inputs["existing"].(string)

	switch existing {
	case "valid":
		return crcValid(t, ctx)
	case "none":
		return crcNone(t, ctx)
	case "inside_window":
		return crcInsideWindow(t, ctx)
	case "wrong_namespace":
		return crcWrongNamespace(t, ctx)
	case "adopt_winner":
		return crcAdoptWinner(t, ctx)
	case "local_cert_writes_stored":
		return crcLocalCertWritesStored(t, ctx)
	default:
		t.Fatalf("unknown existing value: %q", existing)
		return gotCertReuseAndConcurrency{}
	}
}

// crcCfg builds a minimal Config for cert tests.
func crcCfg(certDir string) *webhookConfig.Config {
	return &webhookConfig.Config{
		SecretName:  crcSecretName,
		ServiceName: crcServiceName,
		CertDir:     certDir,
	}
}

// crcData converts a webhookCerts to a Secret Data map.
func crcData(certs webhookCerts) map[string][]byte {
	return map[string][]byte{
		CaCertKey:            certs.CaPEM.Bytes(),
		ServerCertKey:        certs.ServerPEM.Bytes(),
		ServerCertPrivateKey: certs.PrivateKeyPEM.Bytes(),
	}
}

// crcSecret builds a Kubernetes Secret from cert data.
func crcSecret(data map[string][]byte) *corev1.Secret {
	return &corev1.Secret{
		ObjectMeta: metav1.ObjectMeta{Name: crcSecretName, Namespace: crcNamespace},
		Data:       data,
	}
}

// crcNearExpiry builds a server cert with NotAfter ~1 hour from now (close to expiry).
func crcNearExpiry(t *testing.T) map[string][]byte {
	t.Helper()

	caKey, err := ecdsa.GenerateKey(elliptic.P256(), cryptorand.Reader)
	require.NoError(t, err)

	caTemplate := &x509.Certificate{
		SerialNumber:          big.NewInt(100),
		Subject:               pkix.Name{Organization: []string{"test-ca"}},
		NotBefore:             time.Now().Add(-time.Minute),
		NotAfter:              time.Now().Add(365 * 24 * time.Hour),
		IsCA:                  true,
		KeyUsage:              x509.KeyUsageCertSign,
		BasicConstraintsValid: true,
	}
	caDER, err := x509.CreateCertificate(cryptorand.Reader, caTemplate, caTemplate, &caKey.PublicKey, caKey)
	require.NoError(t, err)
	caCert, err := x509.ParseCertificate(caDER)
	require.NoError(t, err)
	caPEM := new(bytes.Buffer)
	require.NoError(t, pem.Encode(caPEM, &pem.Block{Type: "CERTIFICATE", Bytes: caDER}))

	serverKey, err := ecdsa.GenerateKey(elliptic.P256(), cryptorand.Reader)
	require.NoError(t, err)

	commonName := crcServiceName + "." + crcNamespace + ".svc"
	serverTemplate := &x509.Certificate{
		SerialNumber: big.NewInt(101),
		Subject:      pkix.Name{CommonName: commonName},
		DNSNames: []string{
			crcServiceName,
			crcServiceName + "." + crcNamespace,
			commonName,
		},
		NotBefore:   time.Now().Add(-time.Minute),
		NotAfter:    time.Now().Add(1 * time.Hour), // ~1h: well within any sensible renewal window
		ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth, x509.ExtKeyUsageClientAuth},
		KeyUsage:    x509.KeyUsageDigitalSignature,
	}
	serverDER, err := x509.CreateCertificate(cryptorand.Reader, serverTemplate, caCert, &serverKey.PublicKey, caKey)
	require.NoError(t, err)
	serverPEM := new(bytes.Buffer)
	require.NoError(t, pem.Encode(serverPEM, &pem.Block{Type: "CERTIFICATE", Bytes: serverDER}))

	privDER, err := x509.MarshalECPrivateKey(serverKey)
	require.NoError(t, err)
	keyPEM := new(bytes.Buffer)
	require.NoError(t, pem.Encode(keyPEM, &pem.Block{Type: "EC PRIVATE KEY", Bytes: privDER}))

	return map[string][]byte{
		CaCertKey:            caPEM.Bytes(),
		ServerCertKey:        serverPEM.Bytes(),
		ServerCertPrivateKey: keyPEM.Bytes(),
	}
}

func crcValid(t *testing.T, ctx context.Context) gotCertReuseAndConcurrency {
	validCerts, err := createCerts(crcServiceName, crcNamespace)
	require.NoError(t, err)
	originalData := crcData(validCerts)

	client := fake.NewSimpleClientset(crcSecret(originalData))
	cfg := crcCfg(t.TempDir())

	require.NoError(t, InitCerts(ctx, client, cfg, crcNamespace))

	stored, err := client.CoreV1().Secrets(crcNamespace).Get(ctx, crcSecretName, metav1.GetOptions{})
	require.NoError(t, err)

	// Kept as-is → stored cert bytes match original
	regenerated := !bytes.Equal(stored.Data[ServerCertKey], originalData[ServerCertKey])
	return gotCertReuseAndConcurrency{
		regenerated: regenerated,
		storedData:  stored.Data,
	}
}

func crcNone(t *testing.T, ctx context.Context) gotCertReuseAndConcurrency {
	client := fake.NewSimpleClientset()
	cfg := crcCfg(t.TempDir())

	require.NoError(t, InitCerts(ctx, client, cfg, crcNamespace))

	stored, err := client.CoreV1().Secrets(crcNamespace).Get(ctx, crcSecretName, metav1.GetOptions{})
	require.NoError(t, err)
	require.NotEmpty(t, stored.Data[ServerCertKey])

	return gotCertReuseAndConcurrency{
		regenerated: true,
		storedData:  stored.Data,
	}
}

func crcInsideWindow(t *testing.T, ctx context.Context) gotCertReuseAndConcurrency {
	nearData := crcNearExpiry(t)
	client := fake.NewSimpleClientset(crcSecret(nearData))
	cfg := crcCfg(t.TempDir())

	require.NoError(t, InitCerts(ctx, client, cfg, crcNamespace))

	stored, err := client.CoreV1().Secrets(crcNamespace).Get(ctx, crcSecretName, metav1.GetOptions{})
	require.NoError(t, err)

	regenerated := !bytes.Equal(stored.Data[ServerCertKey], nearData[ServerCertKey])
	return gotCertReuseAndConcurrency{
		regenerated: regenerated,
		storedData:  stored.Data,
	}
}

func crcWrongNamespace(t *testing.T, ctx context.Context) gotCertReuseAndConcurrency {
	wrongCerts, err := createCerts(crcServiceName, "other")
	require.NoError(t, err)
	wrongData := crcData(wrongCerts)

	client := fake.NewSimpleClientset(crcSecret(wrongData))
	cfg := crcCfg(t.TempDir())

	require.NoError(t, InitCerts(ctx, client, cfg, crcNamespace))

	stored, err := client.CoreV1().Secrets(crcNamespace).Get(ctx, crcSecretName, metav1.GetOptions{})
	require.NoError(t, err)

	regenerated := !bytes.Equal(stored.Data[ServerCertKey], wrongData[ServerCertKey])
	return gotCertReuseAndConcurrency{
		regenerated: regenerated,
		storedData:  stored.Data,
	}
}

func crcAdoptWinner(t *testing.T, ctx context.Context) gotCertReuseAndConcurrency {
	winnerCerts, err := createCerts(crcServiceName, crcNamespace)
	require.NoError(t, err)
	winnerData := crcData(winnerCerts)

	client := fake.NewSimpleClientset(crcSecret(winnerData))

	// Reactor: first get returns NotFound, subsequent gets go through tracker
	firstGet := true
	client.PrependReactor("get", "secrets", func(action k8sTesting.Action) (bool, runtime.Object, error) {
		if firstGet {
			firstGet = false
			return true, nil, k8sErrors.NewNotFound(corev1.Resource("secrets"), crcSecretName)
		}
		return false, nil, nil
	})

	cfg := crcCfg(t.TempDir())
	require.NoError(t, InitCerts(ctx, client, cfg, crcNamespace))

	stored, err := client.CoreV1().Secrets(crcNamespace).Get(ctx, crcSecretName, metav1.GetOptions{})
	require.NoError(t, err)

	// Direct assertion: the stored data must equal the winner's data (the real discriminator).
	assert.Equal(t, winnerData[ServerCertKey], stored.Data[ServerCertKey],
		"stored ServerCertKey must equal winner's for adopt_winner case")
	assert.Equal(t, winnerData[CaCertKey], stored.Data[CaCertKey],
		"stored CaCertKey must equal winner's for adopt_winner case")
	assert.Equal(t, winnerData[ServerCertPrivateKey], stored.Data[ServerCertPrivateKey],
		"stored ServerCertPrivateKey must equal winner's for adopt_winner case")

	adoptedWinner := bytes.Equal(stored.Data[ServerCertKey], winnerData[ServerCertKey]) &&
		bytes.Equal(stored.Data[CaCertKey], winnerData[CaCertKey]) &&
		bytes.Equal(stored.Data[ServerCertPrivateKey], winnerData[ServerCertPrivateKey])

	return gotCertReuseAndConcurrency{
		regenerated:   true, // a cert was generated (even though winner won)
		adoptedWinner: adoptedWinner,
		winnerData:    winnerData,
		storedData:    stored.Data,
	}
}

func crcLocalCertWritesStored(t *testing.T, ctx context.Context) gotCertReuseAndConcurrency {
	validCerts, err := createCerts(crcServiceName, crcNamespace)
	require.NoError(t, err)
	originalData := crcData(validCerts)

	client := fake.NewSimpleClientset(crcSecret(originalData))
	certDir := t.TempDir()
	cfg := crcCfg(certDir)
	cfg.LocalCert = true

	require.NoError(t, InitCerts(ctx, client, cfg, crcNamespace))

	stored, err := client.CoreV1().Secrets(crcNamespace).Get(ctx, crcSecretName, metav1.GetOptions{})
	require.NoError(t, err)

	// Check regenerated (should be false - kept as-is)
	regenerated := !bytes.Equal(stored.Data[ServerCertKey], originalData[ServerCertKey])

	// Read each file individually and assert byte-equality against the stored Secret's data.
	expandedDir := cfg.ExpandCertDir()
	caDisk, e1 := os.ReadFile(filepath.Join(expandedDir, CaCertKey))
	serverDisk, e2 := os.ReadFile(filepath.Join(expandedDir, ServerCertKey))
	keyDisk, e3 := os.ReadFile(filepath.Join(expandedDir, ServerCertPrivateKey))

	require.NoError(t, e1, "ca.crt must exist on disk")
	require.NoError(t, e2, "tls.crt must exist on disk")
	require.NoError(t, e3, "tls.key must exist on disk")

	assert.Equal(t, stored.Data[CaCertKey], caDisk,
		"ca.crt on disk must equal stored Secret's CaCertKey")
	assert.Equal(t, stored.Data[ServerCertKey], serverDisk,
		"tls.crt on disk must equal stored Secret's ServerCertKey")
	assert.Equal(t, stored.Data[ServerCertPrivateKey], keyDisk,
		"tls.key on disk must equal stored Secret's ServerCertPrivateKey")

	localFilesMatchStored := e1 == nil && e2 == nil && e3 == nil &&
		bytes.Equal(caDisk, stored.Data[CaCertKey]) &&
		bytes.Equal(serverDisk, stored.Data[ServerCertKey]) &&
		bytes.Equal(keyDisk, stored.Data[ServerCertPrivateKey])

	return gotCertReuseAndConcurrency{
		regenerated:           regenerated,
		localFilesMatchStored: localFilesMatchStored,
		storedData:            stored.Data,
	}
}
