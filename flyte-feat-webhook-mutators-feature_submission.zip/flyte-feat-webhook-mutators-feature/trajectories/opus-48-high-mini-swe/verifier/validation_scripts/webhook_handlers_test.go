package webhook

import (
	"context"
	"encoding/json"
	"net/http"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	admissionv1 "k8s.io/api/admission/v1"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"sigs.k8s.io/controller-runtime/pkg/webhook/admission"

	webhookConfig "github.com/flyteorg/flyte/v2/flyteplugins/go/tasks/pluginmachinery/secret/config"
)

// TestWebhookHandlers is the entry point for the webhook_handlers story.
func TestWebhookHandlers(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			got := runCaseWebhookHandlers(t, tc)

			// builtin_legacy_path
			expectedBuiltinLegacyPath := tc.Expected["builtin_legacy_path"].(string)
			if expectedBuiltinLegacyPath != "__skip__" {
				assert.True(t, got.builtinLegacyPathPresent,
					"builtin_legacy_path %q not among served paths for case %q",
					expectedBuiltinLegacyPath, tc.Name)
			}

			// builtin_service_path
			expectedBuiltinServicePath := tc.Expected["builtin_service_path"].(string)
			if expectedBuiltinServicePath != "__skip__" {
				assert.Equal(t, expectedBuiltinServicePath, got.builtinServicePath,
					"builtin_service_path mismatch for case %q", tc.Name)
			}

			// handler_count + path disjointness
			expectedHandlerCount := int(tc.Expected["handler_count"].(float64))
			if expectedHandlerCount != -1 {
				assert.Equal(t, expectedHandlerCount, got.handlerCount,
					"handler_count mismatch for case %q", tc.Name)
				// Path disjointness: the built-in path, extra pod path, and extra node path
				// must all be non-empty and pairwise distinct.
				assert.True(t, got.pathsDisjoint,
					"paths (builtin, extra pod, extra node) must be pairwise disjoint and non-empty for case %q", tc.Name)
			}

			// pod_selector_value
			expectedPodSelectorValue := tc.Expected["pod_selector_value"].(string)
			if expectedPodSelectorValue != "__skip__" {
				assert.Equal(t, expectedPodSelectorValue, got.podSelectorValue,
					"pod_selector_value mismatch for case %q", tc.Name)
			}

			// node_namespace_selector
			expectedNodeNSSelector := tc.Expected["node_namespace_selector"].(string)
			if expectedNodeNSSelector != "__skip__" && expectedNodeNSSelector == "nil" {
				assert.True(t, got.nodeNamespaceSelectorNil,
					"expected node NamespaceSelector to be nil for case %q", tc.Name)
			}

			// timeout_seconds
			expectedTimeoutSeconds := int(tc.Expected["timeout_seconds"].(float64))
			if expectedTimeoutSeconds != -1 {
				assert.True(t, got.allTimeoutsSet,
					"expected all webhook TimeoutSeconds to be non-nil for case %q", tc.Name)
				assert.Equal(t, int32(expectedTimeoutSeconds), got.timeoutValue,
					"timeout_seconds mismatch for case %q", tc.Name)
			}

			// expect_error
			expectedExpectError := tc.Expected["expect_error"].(string)
			if expectedExpectError == "yes" {
				assert.True(t, got.constructionError,
					"expected construction error for case %q", tc.Name)
			} else {
				// "no" → construction must succeed
				assert.False(t, got.constructionError,
					"unexpected construction error for case %q", tc.Name)
			}

			// min_patch_count + patch_path
			expectedMinPatchCount := int(tc.Expected["min_patch_count"].(float64))
			expectedPatchPath := tc.Expected["patch_path"].(string)
			if expectedMinPatchCount != -1 && expectedPatchPath != "__skip__" {
				assert.True(t, got.responseAllowed,
					"expected response.Allowed for case %q", tc.Name)
				assert.GreaterOrEqual(t, got.patchCount, expectedMinPatchCount,
					"expected at least %d patches for case %q", expectedMinPatchCount, tc.Name)
				if got.patchCount > 0 {
					assert.Equal(t, expectedPatchPath, got.firstPatchPath,
						"first patch path mismatch for case %q", tc.Name)
				}
			}
		})
	}
}

// gotWebhookHandlers holds the flat outcome for one webhook_handlers test case.
type gotWebhookHandlers struct {
	// builtin_paths
	builtinLegacyPathPresent bool
	builtinServicePath       string
	// extra_pod_and_node
	handlerCount             int
	podSelectorValue         string
	nodeNamespaceSelectorNil bool
	// path disjointness: true when all three paths (builtin, extra pod, extra node) are
	// non-empty and pairwise distinct — the discriminating property of the extra-handler feature.
	pathsDisjoint bool
	// timeout
	allTimeoutsSet bool
	timeoutValue   int32
	// error
	constructionError bool
	// patches_pod
	responseAllowed bool
	patchCount      int
	firstPatchPath  string
}

// labelAdderHandlerWH is a fixture admission.Handler that adds a "mutated-by" label to pods.
type labelAdderHandlerWH struct {
	decoder admission.Decoder
	id      string
}

func (h *labelAdderHandlerWH) Handle(ctx context.Context, req admission.Request) admission.Response {
	pod := &corev1.Pod{}
	if err := h.decoder.Decode(req, pod); err != nil {
		return admission.Errored(http.StatusBadRequest, err)
	}
	if pod.Labels == nil {
		pod.Labels = map[string]string{}
	}
	pod.Labels["mutated-by"] = h.id
	marshalled, err := json.Marshal(pod)
	if err != nil {
		return admission.Errored(http.StatusInternalServerError, err)
	}
	return admission.PatchResponseFromRaw(req.Object.Raw, marshalled)
}

func runCaseWebhookHandlers(t *testing.T, tc ValidationTestCase) gotWebhookHandlers {
	t.Helper()

	timeoutSeconds := int32(tc.Inputs["timeout_seconds"].(float64))
	expectedHandlerCount := int(tc.Expected["handler_count"].(float64))
	expectedExpectError := tc.Expected["expect_error"].(string)
	expectedMinPatchCount := int(tc.Expected["min_patch_count"].(float64))
	expectedBuiltinLegacyPath := tc.Expected["builtin_legacy_path"].(string)

	result := gotWebhookHandlers{}

	// --- builtin_paths probe: run when builtin_legacy_path is expected ---
	if expectedBuiltinLegacyPath != "__skip__" {
		r := whBuiltinPaths(t, timeoutSeconds)
		result.builtinLegacyPathPresent = r.builtinLegacyPathPresent
		result.builtinServicePath = r.builtinServicePath
		result.allTimeoutsSet = r.allTimeoutsSet
		result.timeoutValue = r.timeoutValue
		result.constructionError = r.constructionError
		return result
	}

	// --- duplicate_rejected probe: run when expect_error="yes" ---
	if expectedExpectError == "yes" {
		r := whDuplicateRejected(t)
		result.constructionError = r.constructionError
		return result
	}

	// --- extra_pod_and_node probe: run when handler_count != -1 ---
	if expectedHandlerCount != -1 {
		r := whExtraPodAndNode(t)
		result.handlerCount = r.handlerCount
		result.podSelectorValue = r.podSelectorValue
		result.nodeNamespaceSelectorNil = r.nodeNamespaceSelectorNil
		result.pathsDisjoint = r.pathsDisjoint
		result.constructionError = r.constructionError
		return result
	}

	// --- patches_pod probe: run when min_patch_count != -1 ---
	if expectedMinPatchCount != -1 {
		r := whPatchesPod(t)
		result.responseAllowed = r.responseAllowed
		result.patchCount = r.patchCount
		result.firstPatchPath = r.firstPatchPath
		result.constructionError = r.constructionError
		return result
	}

	t.Fatalf("unhandled webhook_handlers case: expected=%v", tc.Expected)
	return result
}

func whBuiltinPaths(t *testing.T, timeoutSeconds int32) gotWebhookHandlers {
	t.Helper()
	pm := &PodMutator{cfg: &webhookConfig.Config{
		ServiceName:    "flyte-pod-webhook",
		ServicePort:    443,
		CertDir:        t.TempDir(),
		WebhookTimeout: timeoutSeconds,
	}}

	builtinPath := secretInjectionAddress()

	cfg, err := pm.CreateMutationWebhookConfiguration("flyte")
	require.NoError(t, err)
	require.NotEmpty(t, cfg.Webhooks)

	firstServicePath := ""
	if cfg.Webhooks[0].ClientConfig.Service != nil && cfg.Webhooks[0].ClientConfig.Service.Path != nil {
		firstServicePath = *cfg.Webhooks[0].ClientConfig.Service.Path
	}

	allTimeoutsSet := true
	var timeoutVal int32
	for _, w := range cfg.Webhooks {
		if w.TimeoutSeconds == nil {
			allTimeoutsSet = false
			break
		}
		timeoutVal = *w.TimeoutSeconds
	}

	return gotWebhookHandlers{
		builtinLegacyPathPresent: builtinPath == secretInjectionAddress(),
		builtinServicePath:       firstServicePath,
		allTimeoutsSet:           allTimeoutsSet,
		timeoutValue:             timeoutVal,
		constructionError:        false,
	}
}

func whExtraPodAndNode(t *testing.T) gotWebhookHandlers {
	t.Helper()
	podSel := &metav1.LabelSelector{MatchLabels: map[string]string{"select": "selinux"}}

	pm := &PodMutator{cfg: &webhookConfig.Config{
		ServiceName: "flyte-pod-webhook",
		ServicePort: 443,
		CertDir:     t.TempDir(),
	}}

	err := pm.AddMutations(
		Mutation{Name: "selinux-pod", Kind: MutationKindPod, Address: "/mutate-pod-selinux", ObjectSelector: podSel},
		Mutation{Name: "taints-node", Kind: MutationKindNode, Address: "/mutate-node-taints", ObjectSelector: nil},
	)
	require.NoError(t, err)

	handlerCount := len(pm.extraMutations) + 1 // extra + built-in

	cfg, err := pm.CreateMutationWebhookConfiguration("flyte")
	require.NoError(t, err)

	builtinPath := secretInjectionAddress()

	var extraPodPath, extraNodePath string
	var podSelectorValue string
	var nodeNSSelectorNil bool

	for i := range cfg.Webhooks {
		w := &cfg.Webhooks[i]
		if w.ClientConfig.Service == nil || w.ClientConfig.Service.Path == nil {
			continue
		}
		path := *w.ClientConfig.Service.Path
		if path == builtinPath {
			continue
		}
		if len(w.Rules) == 0 {
			continue
		}
		resources := w.Rules[0].Resources
		for _, r := range resources {
			if r == "pods" {
				extraPodPath = path
				if w.ObjectSelector != nil {
					if v, ok := w.ObjectSelector.MatchLabels["select"]; ok {
						podSelectorValue = v
					}
				}
			} else if r == "nodes" {
				extraNodePath = path
				nodeNSSelectorNil = w.NamespaceSelector == nil
				// Assert APIGroups
				apiGroups := w.Rules[0].APIGroups
				assert.True(t, len(apiGroups) > 0 && (apiGroups[0] == "" || apiGroups[0] == "*"),
					"expected node APIGroups to be [''] or ['*'], got %v", apiGroups)
			}
		}
	}

	// Path disjointness: the built-in path, the extra pod path, and the extra node path
	// must all be non-empty and pairwise distinct — each mutation lives at its own address.
	assert.NotEmpty(t, extraPodPath, "extra pod handler must serve at least one path")
	assert.NotEmpty(t, extraNodePath, "extra node handler must serve at least one path")
	assert.NotEqual(t, builtinPath, extraPodPath, "extra pod path must differ from builtin path")
	assert.NotEqual(t, builtinPath, extraNodePath, "extra node path must differ from builtin path")
	assert.NotEqual(t, extraPodPath, extraNodePath, "extra pod and node paths must differ")

	pathsDisjoint := extraPodPath != "" && extraNodePath != "" &&
		builtinPath != extraPodPath &&
		builtinPath != extraNodePath &&
		extraPodPath != extraNodePath

	return gotWebhookHandlers{
		handlerCount:             handlerCount,
		podSelectorValue:         podSelectorValue,
		nodeNamespaceSelectorNil: nodeNSSelectorNil,
		pathsDisjoint:            pathsDisjoint,
		constructionError:        false,
	}
}

func whDuplicateRejected(t *testing.T) gotWebhookHandlers {
	t.Helper()
	pm := &PodMutator{cfg: &webhookConfig.Config{
		ServiceName: "flyte-pod-webhook",
		ServicePort: 443,
		CertDir:     t.TempDir(),
	}}

	err := pm.AddMutations(
		Mutation{Name: "a", Kind: MutationKindPod, Address: "/mutate-pod-a"},
		Mutation{Name: "a", Kind: MutationKindPod, Address: "/mutate-pod-a"}, // duplicate address
	)

	return gotWebhookHandlers{
		constructionError: err != nil,
	}
}

func whPatchesPod(t *testing.T) gotWebhookHandlers {
	t.Helper()

	scheme := runtime.NewScheme()
	require.NoError(t, corev1.AddToScheme(scheme))
	decoder := admission.NewDecoder(scheme)

	handler := &labelAdderHandlerWH{
		decoder: decoder,
		id:      "selinux",
	}

	pod := &corev1.Pod{
		TypeMeta:   metav1.TypeMeta{Kind: "Pod", APIVersion: "v1"},
		ObjectMeta: metav1.ObjectMeta{Name: "test-pod", Namespace: "default"},
	}
	podBytes, err := json.Marshal(pod)
	require.NoError(t, err)

	req := admission.Request{
		AdmissionRequest: admissionv1.AdmissionRequest{
			Object: runtime.RawExtension{Raw: podBytes},
		},
	}

	resp := handler.Handle(context.Background(), req)

	patchCount := len(resp.Patches)
	firstPatchPath := ""
	if patchCount > 0 {
		firstPatchPath = resp.Patches[0].Path
	}

	return gotWebhookHandlers{
		constructionError: false,
		responseAllowed:   resp.Allowed,
		patchCount:        patchCount,
		firstPatchPath:    firstPatchPath,
	}
}
