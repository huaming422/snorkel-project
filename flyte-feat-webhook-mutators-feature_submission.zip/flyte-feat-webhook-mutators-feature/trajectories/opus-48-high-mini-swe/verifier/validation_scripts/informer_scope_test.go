package secret_test

import (
	"sort"
	"testing"

	"github.com/stretchr/testify/assert"

	webhookPkg "github.com/flyteorg/flyte/v2/executor/pkg/webhook"
	"github.com/flyteorg/flyte/v2/flyteplugins/go/tasks/pluginmachinery/secret/config"
)

func TestInformerScope(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			got := runCaseInformerScope(t, tc)

			// use_informer: bool
			expectedUseInformer := tc.Expected["use_informer"].(bool)
			assert.Equal(t, expectedUseInformer, got.useInformer,
				"use_informer mismatch for case %q", tc.Name)

			// namespaces: list or ["__skip__"]
			rawNS := tc.Expected["namespaces"].([]interface{})
			isSkip := len(rawNS) == 1 && rawNS[0].(string) == "__skip__"
			if !isSkip {
				if len(rawNS) == 0 {
					// An empty expected list means nil/cluster-wide — both nil and
					// empty slice are "no namespaces" and must both pass.
					assert.Empty(t, got.namespaces,
						"namespaces mismatch for case %q", tc.Name)
				} else {
					var expectedNS []string
					for _, v := range rawNS {
						expectedNS = append(expectedNS, v.(string))
					}
					sort.Strings(expectedNS)
					gotNS := make([]string, len(got.namespaces))
					copy(gotNS, got.namespaces)
					sort.Strings(gotNS)
					assert.Equal(t, expectedNS, gotNS,
						"namespaces mismatch for case %q", tc.Name)
				}
			}
		})
	}
}

// gotInformerScope holds the outcome of one informer_scope test case.
type gotInformerScope struct {
	useInformer bool
	namespaces  []string
}

func runCaseInformerScope(t *testing.T, tc ValidationTestCase) gotInformerScope {
	typeStr := tc.Inputs["type"].(string)
	imagePull := tc.Inputs["image_pull"].(bool)
	k8sNamespace := tc.Inputs["k8s_namespace"].(string)

	var embType config.EmbeddedSecretManagerType
	switch typeStr {
	case "aws":
		embType = config.EmbeddedSecretManagerTypeAWS
	case "gcp":
		embType = config.EmbeddedSecretManagerTypeGCP
	case "k8s":
		embType = config.EmbeddedSecretManagerTypeK8s
	default:
		t.Fatalf("unknown type: %q", typeStr)
	}

	cfg := &config.Config{
		// Enable the embedded manager so that usesEmbeddedK8sSecrets can pick it up.
		SecretManagerTypes: []config.SecretManagerType{config.SecretManagerTypeEmbedded},
		EmbeddedSecretManagerConfig: config.EmbeddedSecretManagerConfig{
			Type: embType,
			K8sConfig: config.K8sConfig{
				Namespace: k8sNamespace,
			},
			ImagePullSecrets: config.ImagePullSecretsConfig{
				Enabled: imagePull,
			},
		},
	}

	const referenceNamespace = "flyte-system"
	namespaces := webhookPkg.SecretWatchNamespaces(cfg, referenceNamespace)

	useInformer := len(namespaces) > 0

	// Verify deduplication: no namespace appears twice.
	seen := map[string]struct{}{}
	var deduped []string
	for _, ns := range namespaces {
		if _, ok := seen[ns]; !ok {
			seen[ns] = struct{}{}
			deduped = append(deduped, ns)
		}
	}

	return gotInformerScope{
		useInformer: useInformer,
		namespaces:  deduped,
	}
}
