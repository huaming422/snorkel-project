## Task

The executor's mutating admission webhook only hosts our built-in secret
injection today. We want it to also host additional pod and node mutations that a
deployment supplies, each scoped independently so a mutation only ever sees the
objects it selects — enough that a single webhook can take over from the older one
we still run alongside it. While you're there, it also needs to carry the
secret-handling behaviors that retirement depends on: reusing an already-valid TLS
identity across restarts and replicas instead of reissuing it, watching only the
cluster secrets it actually needs, and resolving per-cluster secrets correctly.
Keep the built-in secret injection working exactly as it does now, including the
address external configurations already point at, and don't pull in any new
dependencies. Some existing tests in the webhook package reference its current
concrete type and will need updating to match.

## User stories / requirements

- When a deployment registers extra pod or node mutations, each gets its own address and selector so it only sees the objects it selects; the built-in secret injection keeps the address external configurations already use. Two mutations claiming the same address are rejected up front, and the configured call-timeout applies to every one.
- When the webhook starts and a usable TLS identity already exists, it is kept and reused as-is rather than reissued; one that is unusable or close to expiring is reissued. When several replicas start at once, they converge on a single shared identity instead of clobbering each other's.
- When the webhook needs to watch cluster secrets to do its job, it watches only the namespaces it actually reads from, and when no feature needs one it starts no watch at all.
- When a secret is provisioned per cluster, the webhook looks up the cluster's own copy first and falls back to a shared copy when it is absent, while the name a task asks for stays the same; when no cluster is configured the lookup is unqualified from the start. A genuine read failure on the cluster's copy surfaces as an error, not hidden by the fallback.
