#!/usr/bin/env bash
# Test environment setup for the executor webhook pluggable-mutators feature.
#
# The Docker image already baked the full dependency closure at the base commit
# (go mod download + go build ./...), so this is deliberately minimal: it just
# re-exports the Go toolchain config the focused go-test runs inherit and makes
# sure the cache dirs exist. Heavy lifting stays in the image.
set -euo pipefail

export GOFLAGS="${GOFLAGS:--mod=mod}"
export GOPROXY="${GOPROXY:-off}"
export CGO_ENABLED="${CGO_ENABLED:-1}"
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"

mkdir -p "$GOMODCACHE" "$GOCACHE"

# Warm, offline-first: the image already ran `go mod download`, so verify the
# module cache satisfies the graph without touching the network first. Only if
# that fails do we log and fall back to an online fetch.
if ! ( cd /repo/flyte && GOFLAGS=-mod=mod GOPROXY=off go mod download ); then
  echo "test-setup.sh: offline module cache incomplete; falling back to online go mod download" >&2
  ( cd /repo/flyte && GOPROXY="${GOPROXY_ONLINE:-https://proxy.golang.org}" go mod download ) || true
fi

echo "test-setup.sh: Go toolchain ready (offline, GOPROXY=$GOPROXY)."
