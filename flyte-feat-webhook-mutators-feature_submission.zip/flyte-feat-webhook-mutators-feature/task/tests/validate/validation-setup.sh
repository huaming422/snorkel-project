#!/usr/bin/env bash
# Validation environment setup for the webhook pluggable-mutators feature.
#
# Runs after tests/test-setup.sh has prepared the Go toolchain and before the
# validation agent starts writing its test files. The Docker image already
# pre-downloaded the module cache for the single module
# (github.com/flyteorg/flyte/v2); we re-export env vars so the go-test driver
# inherits the correct toolchain config and build the packages once so a warm
# build cache makes each validation story's `go test` fast.
set -euo pipefail

export GOFLAGS="${GOFLAGS:--mod=mod}"
export CGO_ENABLED="${CGO_ENABLED:-1}"
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"
export GOCACHE="${GOCACHE:-/root/.cache/go-build}"
export GOMODCACHE="${GOMODCACHE:-/root/go/pkg/mod}"

mkdir -p "$GOCACHE" "$GOMODCACHE"

cd /repo/flyte

# Single Go module, no go.work / submodules. The image already ran
# `go mod download`, so the module cache is warm and this is an offline no-op;
# try the offline form first, fall back to a logged online fetch only if a
# fresh layer ever lost the cache.
if ! GOPROXY=off go mod download 2>/tmp/gomod-offline.log; then
  echo "validation-setup.sh: offline 'go mod download' incomplete, retrying online" >&2
  cat /tmp/gomod-offline.log >&2
  go mod download || true
fi

# Warm the build cache for the two packages the stories inject into, so the
# first `go test` in each story does not rebuild the world. Loud on failure:
# a broken baseline must surface here, not as a confusing per-story error.
BUILD_LOG=$(mktemp)
if ! go build ./executor/pkg/webhook/... ./flyteplugins/go/tasks/pluginmachinery/secret/... > "$BUILD_LOG" 2>&1; then
  echo "validation-setup.sh: baseline build FAILED" >&2
  tail -80 "$BUILD_LOG" >&2
  exit 1
fi
rm -f "$BUILD_LOG"

echo "validation-setup.sh: Go toolchain ready, module deps cached, target packages built."
