// Verifier for server-survival-fix-load-signal-calibration.
//
// What this checks (stated as behavior, not as numbers): the on-screen load
// signals a player reads in survival mode must track how close a node is to its
// real capacity and warn while there is still time to act. Four signals are in
// scope — the coloured ring on a node, the sampled utilization series, the paid
// Monitoring node's high-load alert, and the metrics panel's hot-cell tint — and
// they all must agree with each other and with the point at which the node
// actually starts dropping requests.
//
// Ground truth (pre-existing, unchanged by any correct fix, so safe to anchor
// on):
//   - A node's reported utilization figure divides in-flight work by a quantity
//     that carries an extra factor of two, so a reading of 0.5 on that axis is
//     100% of the node's rated capacity.
//   - The request-failure curve (calculateFailChanceBasedOnLoad, pre-existing in
//     src/core/actions.js) returns zero at or below 0.5 and rises above it, so
//     the FIRST dropped request happens just past 0.5 on that same axis. This is
//     the "failure onset" every warning must precede.
//   - The ring hex palette is fixed in the renderer: red 0xff0000, orange
//     0xffaa00, yellow 0xffff00, green 0x00ff00. A correct fix recalibrates WHEN
//     each colour shows, never the colours themselves.
//
// Design stance: thresholds, config key names, and the exact sustain count are
// the solver's to choose. Every assertion below is derived behaviorally — by
// sweeping a signal across loads and reading where it transitions, or by driving
// the real reference board and counting frames — and compared against the
// pre-existing failure curve, never against the reference solution's literals.
// The only load numbers written in this file are the stable-fact capacity point
// (0.5) and probe inputs; no threshold, no key name, no sample count is pinned.

import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import { STATE } from "../../src/state.js";
import { resetWorld, place, connect } from "../helpers/sim-world.mjs";
import {
  metricsTick,
  resetMetrics,
  getServiceMetrics,
} from "../../src/core/metrics.js";
import { renderMetricsPanel } from "../../src/ui/metrics-panel.js";
import { calculateFailChanceBasedOnLoad } from "../../src/core/actions.js";
import {
  buildReferenceBoard,
  frame,
  mulberry32,
  REFERENCE_MIX,
  SEEDS,
} from "../helpers/reference-board.mjs";

// --- stable facts -----------------------------------------------------------

// On the utilization axis the signals live on, this is 100% of rated capacity
// and the point at or below which the failure curve drops nothing. Derived, not
// assumed: confirmed against the pre-existing curve in the ordering test below.
const CAPACITY = 0.5;

// The fixed ring palette (renderer constants, not thresholds).
const RED = 0xff0000;
const ORANGE = 0xffaa00;
const YELLOW = 0xffff00;
const GREEN = 0x00ff00;

// --- helpers ----------------------------------------------------------------

// Pin BOTH load axes of a service to a fixed value: the instantaneous getter and
// the smoothed property. Pinning both means a correct fix (which reads the
// smoothed signal) and the pre-fix code (which read the instantaneous one) are
// each given the same value, so these probes isolate the THRESHOLD calibration
// from the smoothed-vs-instantaneous question (which the strobe/sample tests
// below handle separately).
function pinLoad(service, value) {
  Object.defineProperty(service, "totalLoad", {
    get: () => value,
    configurable: true,
  });
  Object.defineProperty(service, "smoothedLoad", {
    value,
    writable: true,
    configurable: true,
  });
}

// Settle a freshly placed node's ring at a pinned load, then read its colour.
// One update() is enough because pinLoad fixes both axes, so the smoothed value
// the ring reads is already the pinned value.
function ringColorAt(value) {
  resetWorld();
  const s = place("compute");
  pinLoad(s, value);
  s.update(1 / 60);
  return s.loadRing.material.color.getHex();
}

// The reference frame loop (mirrors reference-board.mjs / game.js animate order)
// driven at a fixed RPS, reporting what the bottleneck ring actually did over a
// real run: how many frames it spent red, and how many frames the node was truly
// over capacity (smoothed load past the capacity point). Used for the
// "red is meaningful" criterion — a real board, not a hand-pinned value.
function runBoard(rps, seed, seconds = 40) {
  resetWorld({ money: 1e9, gameMode: "survival" });
  vi.spyOn(Math, "random").mockImplementation(mulberry32(seed));
  const nodes = buildReferenceBoard();
  STATE.currentRPS = rps;
  STATE.trafficDistribution = { ...REFERENCE_MIX };
  if (!STATE.services.length) throw new Error("reference board did not build");
  const b = nodes.bottleneck;

  let redFrames = 0;
  let overCapFrames = 0;
  const dt = 1 / 60;
  const total = Math.round(seconds / dt);
  for (let i = 0; i < total; i++) {
    // frame(dt) is the helper's own one-frame step: services update, requests
    // move, the spawner runs on game-scaled dt, reputation clamp — the exact
    // order game.js animate() uses. Driving the real loop (not a reimplementation)
    // keeps this honest.
    frame(dt);
    const hex = b.loadRing.material.color.getHex();
    if (hex === RED) redFrames++;
    if (b.smoothedLoad > CAPACITY) overCapFrames++;
  }
  const failures = Object.values(STATE.failures || {}).reduce(
    (a, n) => a + (typeof n === "number" ? n : 0),
    0
  );
  vi.restoreAllMocks();
  return { redFrames, overCapFrames, failures, peakSmoothed: b.smoothedLoad };
}

// Discover the load at which the Monitoring alert first fires, by holding a node
// just above a candidate load and sampling. Returns the lowest probed load that
// produced a "High load" warning within a short sustained window, or null.
// Drives the real alert path (metricsTick -> STATE.intervention.warnings), so it
// does not read any threshold constant by name.
function alertFiresAt(load, maxSamples = 6) {
  resetWorld();
  resetMetrics();
  STATE.intervention.warnings = [];
  place("monitor");
  const svc = place("compute");
  pinLoad(svc, load);
  for (let i = 0; i < maxSamples; i++) {
    STATE.elapsedGameTime += 0.5;
    metricsTick(0.5);
    if (STATE.intervention.warnings.some((w) => w.message.includes("High load"))) {
      return i + 1; // number of samples it took to fire
    }
  }
  return null;
}

// Does the metrics panel paint its hot-cell tint for a node held at `load`?
// Observed by stubbing canvas getContext to count fillRect calls (the tint is a
// full-cell fillRect). Returns true if any tint was painted. Tests the panel's
// private predicate THROUGH its only observable effect — no import of the
// predicate or its threshold.
function panelTintsAt(load) {
  resetWorld();
  resetMetrics();
  place("monitor");
  const svc = place("compute");
  pinLoad(svc, load);
  // Two samples so the util buffer's latest value is the pinned load.
  STATE.elapsedGameTime += 0.5;
  metricsTick(0.5);
  STATE.elapsedGameTime += 0.5;
  metricsTick(0.5);

  const Proto =
    globalThis.HTMLCanvasElement?.prototype ||
    globalThis.window?.HTMLCanvasElement?.prototype;
  const orig = Proto.getContext;
  let fillRects = 0;
  Proto.getContext = function () {
    return {
      clearRect() {},
      fillRect() {
        fillRects++;
      },
      beginPath() {},
      moveTo() {},
      lineTo() {},
      stroke() {},
      set fillStyle(_v) {},
      set strokeStyle(_v) {},
      set lineWidth(_v) {},
    };
  };
  try {
    renderMetricsPanel();
  } finally {
    Proto.getContext = orig;
  }
  return fillRects > 0;
}

afterEach(() => {
  vi.restoreAllMocks();
});

// ---------------------------------------------------------------------------
// Criterion 7 (foundation): ordering invariant against the real failure curve.
// alert threshold < ring-red threshold <= capacity (0.5), and a node showing red
// still has zero chance of dropping a request (red means "at capacity, drops
// next", not "already collapsing"). Boundaries are discovered by sweeping the
// signals, so renamed/relocated config keys are fine.
// ---------------------------------------------------------------------------
describe("ordering invariant: alert < red <= capacity, red not deep in collapse", () => {
  // Discover the ring-red onset behaviorally: the lowest load at which the ring
  // reads red. Swept past capacity so an un-recalibrated (red-at-collapse)
  // threshold is still located and judged, not just reported missing.
  function discoverRedOnset() {
    let onset = null;
    for (let v = 0; v <= 1.0; v += 0.005) {
      const load = +v.toFixed(3);
      if (ringColorAt(load) === RED) {
        onset = load;
        break;
      }
    }
    return onset;
  }
  // Discover the alert onset behaviorally: the lowest load at which a sustained
  // hold fires the Monitoring alert.
  function discoverAlertOnset() {
    let onset = null;
    for (let v = 0; v <= 1.0; v += 0.005) {
      const load = +v.toFixed(3);
      if (alertFiresAt(load) !== null) {
        onset = load;
        break;
      }
    }
    return onset;
  }

  it("the failure curve is unchanged ground truth: no drops at or below capacity", () => {
    expect(calculateFailChanceBasedOnLoad(CAPACITY)).toBe(0);
    expect(calculateFailChanceBasedOnLoad(CAPACITY - 0.01)).toBe(0);
    expect(calculateFailChanceBasedOnLoad(CAPACITY + 0.05)).toBeGreaterThan(0);
  });

  it("ring red lights by the capacity point, not only deep in collapse", () => {
    const redOnset = discoverRedOnset();
    expect(redOnset).not.toBeNull();
    // The meaning of "red" must be "at capacity, drops now/next", so red is
    // lit by the time the node reaches capacity (give or take the sweep's own
    // granularity around a threshold placed exactly at the capacity point).
    // A threshold up at ~160% of capacity (red only once deep in collapse)
    // lands its onset far past this bound and fails. EPS covers the single
    // sweep-step gap between a threshold at capacity and the first strictly-
    // greater sample that renders red.
    const EPS = 0.03;
    expect(redOnset).toBeLessThanOrEqual(CAPACITY + EPS);
  });

  it("the alert fires at a lighter load than the one that turns the ring red", () => {
    const redOnset = discoverRedOnset();
    const alertOnset = discoverAlertOnset();
    expect(alertOnset).not.toBeNull();
    expect(redOnset).not.toBeNull();
    expect(alertOnset).toBeLessThan(redOnset);
  });
});

// ---------------------------------------------------------------------------
// Criterion 1: the load ring turns red at (not well past) rated capacity, and
// green/yellow genuinely mean fine. Asserts the ORDERING of the colour bands and
// that the red band begins no later than capacity — never the literal threshold.
// ---------------------------------------------------------------------------
describe("ring calibrated to capacity", () => {
  it("a node just past capacity reads red", () => {
    // A node a touch over 100% of rated capacity (where requests are already at
    // risk) must be red. Probing just above the capacity point rather than
    // exactly at it admits a valid solution that places its red threshold right
    // at capacity with a strict greater-than comparison. This still fails an
    // un-recalibrated ring, which needs ~160% of capacity before it reads red.
    expect(ringColorAt(CAPACITY + 0.03)).toBe(RED);
  });

  it("a comfortably-under-capacity node does not read red", () => {
    // Half of capacity is a healthy node; it must not be screaming red.
    expect(ringColorAt(CAPACITY / 2)).not.toBe(RED);
  });

  it("a lightly loaded node reads calm (green), not a warning colour", () => {
    // A nearly idle node must be green — not yellow/orange/red. Pre-fix, yellow
    // lit at 40% of capacity (load 0.2 on this axis); a tenth of capacity must
    // be unambiguously calm.
    expect(ringColorAt(CAPACITY / 5)).toBe(GREEN);
  });

  it("the colour bands are monotonic in load: green < yellow < orange < red", () => {
    // Sweep upward and record the order in which colours first appear. Each
    // warmer colour must first appear at a strictly higher load than the
    // previous one. This pins the ORDERING, not any boundary value.
    const firstSeen = new Map();
    for (let v = 0; v <= 0.6; v += 0.005) {
      const load = +v.toFixed(3);
      const hex = ringColorAt(load);
      if (!firstSeen.has(hex)) firstSeen.set(hex, load);
    }
    // Green exists at the bottom; the three warning colours each appear and do
    // so in increasing-load order.
    for (const hex of [YELLOW, ORANGE, RED]) {
      expect(firstSeen.has(hex)).toBe(true);
    }
    expect(firstSeen.get(YELLOW)).toBeLessThan(firstSeen.get(ORANGE));
    expect(firstSeen.get(ORANGE)).toBeLessThan(firstSeen.get(RED));
    if (firstSeen.has(GREEN)) {
      expect(firstSeen.get(GREEN)).toBeLessThan(firstSeen.get(YELLOW));
    }
  });
});

// ---------------------------------------------------------------------------
// Criterion 2: the ring reads a smoothed signal, so one pathological frame
// cannot flip its colour (no strobe). Settle low, spike the INSTANTANEOUS load
// for a single frame, and assert the colour is unchanged. A fix that recalibrates
// but keeps reading the instantaneous signal fails here.
// ---------------------------------------------------------------------------
describe("ring does not strobe on a single spike frame", () => {
  it("one over-capacity frame does not change a settled-calm ring", () => {
    resetWorld();
    const s = place("compute");
    // Drive the instantaneous load via a mutable backing variable; let the
    // smoothed signal (if the fix reads one) evolve on its own.
    let raw = CAPACITY / 5; // calm
    Object.defineProperty(s, "totalLoad", {
      get: () => raw,
      configurable: true,
    });
    // Settle for a couple seconds of frames at the calm load.
    for (let i = 0; i < 180; i++) s.update(1 / 60);
    const settled = s.loadRing.material.color.getHex();
    expect(settled).toBe(GREEN);
    // One pathological spike frame far over capacity.
    raw = 3.0;
    s.update(1 / 60);
    const afterSpike = s.loadRing.material.color.getHex();
    // A smoothed ring barely moves; it must NOT have jumped to a warning colour.
    expect(afterSpike).toBe(settled);
  });
});

// ---------------------------------------------------------------------------
// Criterion 3: the sampled utilization series tracks the smoothed signal, not
// the instantaneous one. Hold the two axes APART and assert the latest sample
// follows the smoothed value.
// ---------------------------------------------------------------------------
describe("sampled utilization series uses the smoothed signal", () => {
  it("the latest util sample equals the smoothed load, not the instantaneous one", () => {
    resetWorld();
    resetMetrics();
    const svc = place("compute");
    // Deliberately diverge the two axes: instantaneous is high, smoothed is low.
    const instantaneous = 0.95;
    const smoothed = 0.2;
    Object.defineProperty(svc, "totalLoad", {
      get: () => instantaneous,
      configurable: true,
    });
    Object.defineProperty(svc, "smoothedLoad", {
      value: smoothed,
      writable: true,
      configurable: true,
    });
    STATE.elapsedGameTime += 0.5;
    metricsTick(0.5);
    const m = getServiceMetrics(svc.id);
    expect(m).toBeTruthy();
    const latest = m.util[m.util.length - 1];
    // The sample must reflect the smoothed axis.
    expect(latest).toBeCloseTo(smoothed, 5);
    expect(latest).not.toBeCloseTo(instantaneous, 2);
  });
});

// ---------------------------------------------------------------------------
// Criterion 4: the Monitoring high-load alert fires BEFORE the first dropped
// request on a steadily rising load. Build monitor+alb+compute+db, ramp the load
// in small steps, record the load at which the alert first fires and the load at
// which the failure curve first exceeds zero; assert alert precedes failure.
// ---------------------------------------------------------------------------
describe("alert precedes the first dropped request", () => {
  it("on a rising load, the alert fires before failures begin", () => {
    resetWorld();
    resetMetrics();
    STATE.intervention.warnings = [];
    place("monitor");
    const alb = place("alb");
    const compute = place("compute");
    const db = place("db");
    connect("internet", alb);
    connect(alb, compute);
    connect(compute, db);

    let alertAt = null;
    let firstFailAt = null;
    for (let v = 0.0; v <= 0.7; v += 0.01) {
      const load = +v.toFixed(2);
      pinLoad(compute, load);
      STATE.elapsedGameTime += 0.5;
      metricsTick(0.5);
      if (
        alertAt === null &&
        STATE.intervention.warnings.some((w) => w.message.includes("High load"))
      ) {
        alertAt = load;
      }
      if (firstFailAt === null && calculateFailChanceBasedOnLoad(load) > 0) {
        firstFailAt = load;
      }
    }
    expect(alertAt).not.toBeNull();
    expect(firstFailAt).not.toBeNull();
    // The whole point of the fix: the warning arrives while there is still time
    // to act, i.e. strictly before the first request is at risk of dropping.
    expect(alertAt).toBeLessThan(firstFailAt);
  });
});

// ---------------------------------------------------------------------------
// Criterion 5: the alert's sustained-sample debounce is short enough that the
// alert is not pushed past failure onset. Hold a node above the alert threshold
// and assert the alert fires within a short streak (a small number of 0.5s
// samples), not only after the old long 3-second filter.
// ---------------------------------------------------------------------------
describe("alert sustain is short", () => {
  it("a sustained overload fires the alert within about a second, not three", () => {
    // Hold at capacity (which is above any valid alert threshold, since
    // alert < red <= capacity). The alert must fire within a short streak. The
    // old filter needed 6 samples (3s); a value past failure onset. Require it
    // to fire in at most 3 samples (<=1.5s), admitting any 1-2 sample design.
    const samples = alertFiresAt(CAPACITY, 6);
    expect(samples).not.toBeNull();
    expect(samples).toBeLessThanOrEqual(3);
  });
});

// ---------------------------------------------------------------------------
// Criterion 6 (pass_to_pass): the metrics panel's hot-cell tint and the alert
// rule agree on what counts as "hot". Observed behaviorally: the panel tints a
// node that is above the alert-firing load, and stays clean for a node that is
// below it. The panel's predicate is private; this tests it through its only
// visible effect and through agreement with the alert, not by reading a constant.
// ---------------------------------------------------------------------------
describe("panel tint agrees with the alert rule", () => {
  it("the panel tints above the alert's firing load and stays clean below it", () => {
    // Discover the alert's firing load behaviorally.
    let alertOnset = null;
    for (let v = 0; v <= 0.6; v += 0.01) {
      const load = +v.toFixed(2);
      if (alertFiresAt(load) !== null) {
        alertOnset = load;
        break;
      }
    }
    expect(alertOnset).not.toBeNull();
    // Just above the alert onset the panel must tint; comfortably below it must
    // not. (A margin avoids the exact boundary where > vs >= could differ.)
    expect(panelTintsAt(alertOnset + 0.05)).toBe(true);
    expect(panelTintsAt(Math.max(0, alertOnset - 0.15))).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// Criterion 8: red is meaningful — quiet on a healthy board, lit on a drowning
// one — and tied to real over-capacity, not wallpaper. Uses the real reference
// board: a low-RPS healthy run shows no red and no failures; a high-RPS drowning
// run spends most of its over-capacity time red. An unfixed board, where red
// needs ~160% of capacity, under-lights the drowning board and fails the
// coverage bar.
// ---------------------------------------------------------------------------
describe("red is meaningful on the real board", () => {
  it("a healthy board shows no red ring and drops nothing", () => {
    // A low, sustainable RPS across every seed: never red, never failing.
    for (const seed of SEEDS) {
      const r = runBoard(3, seed, 40);
      expect(r.failures).toBe(0);
      expect(r.redFrames).toBe(0);
    }
  });

  it("a drowning board lights red for most of the time it is over capacity", () => {
    // A heavy RPS drives the bottleneck well past capacity. Whenever the node is
    // truly over capacity the ring should be red, so red frames should cover the
    // large majority of over-capacity frames. When red needs ~160% of capacity
    // (the unfixed calibration), it covers only a fraction of the over-capacity
    // time and fails this bar. A coverage floor of 0.8 sits above that fractional
    // regime and below a correctly-calibrated board's near-complete coverage.
    for (const seed of SEEDS) {
      const r = runBoard(8, seed, 40);
      expect(r.overCapFrames).toBeGreaterThan(0);
      const coverage = r.redFrames / r.overCapFrames;
      expect(coverage).toBeGreaterThan(0.8);
    }
  });
});

// ---------------------------------------------------------------------------
// Criterion 9 (structural pass_to_pass): the rings are display-only; campaign
// level outcomes must not change. The CampaignController lifecycle (persistence,
// unlock/star logic, win gate) is driven directly — it is independent of the
// display signals, so it must stay green regardless of the ring/alert
// recalibration. This guards against a "fix" that reached into the simulation.
// ---------------------------------------------------------------------------
describe("campaign simulation is unaffected (display-only guard)", () => {
  let CampaignController;
  beforeEach(async () => {
    resetWorld();
    ({ CampaignController } = await import("../../src/campaign/campaign.js"));
    globalThis.localStorage.removeItem("serverSurvivalCampaignProgress");
  });

  it("fresh progress, round-trip, and corrupt-store recovery are intact", () => {
    const c = new CampaignController();
    expect(c.loadProgress()).toEqual({
      version: 1,
      completed: {},
      highestUnlocked: 1,
    });
    const p = {
      version: 1,
      completed: { 1: { stars: 3, bestTimeSec: 42, lastPlayed: 5 } },
      highestUnlocked: 2,
    };
    c.saveProgress(p);
    expect(c.loadProgress()).toEqual(p);
    globalThis.localStorage.setItem("serverSurvivalCampaignProgress", "{not json");
    expect(c.loadProgress()).toEqual({
      version: 1,
      completed: {},
      highestUnlocked: 1,
    });
  });

  it("a win requires a completed request and unlocks the next level", () => {
    const c = new CampaignController();
    expect(c.loadLevel(1)).toBe(true);
    for (const o of STATE.campaign.level.objectives.primary) {
      STATE.campaign.objectiveResults[o.id] = true;
    }
    // No completion yet -> no win.
    c._checkEndConditions();
    expect(STATE.campaign.ended).toBe(false);
    // One completion -> win, and the next level unlocks.
    c.onRequestCompleted({ type: "READ" }, "db");
    c._checkEndConditions();
    expect(STATE.campaign.ended).toBe(true);
    expect(STATE.campaign.outcome).toBe("win");
    expect(c.loadProgress().highestUnlocked).toBe(2);
  });
});
