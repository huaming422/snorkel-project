## Task

the on-screen load warnings in survival mode aren't telling players the truth. the coloured rings on the service nodes stay calm, green or yellow, right up until a node is already dropping requests, and only turn red once the run is well into a collapse. the paid Monitoring node's alert has the same problem: it fires so late that requests are already failing by the time it warns you, with nothing useful left to do about it. the warnings should track how close a node actually is to its capacity, and the alert should give you a heads-up before requests start dropping. this is only about the survival-mode signals the player sees, so it shouldn't change how campaign levels play out. dig in and fix it.

## General instructions

- The code repo is at /repo/server-survival.
- You are inside of a Docker container with no network access. You may not be able to perform all operations you would normally be able to do on a local machine. The project's dependencies and toolchain are already installed and the package manager caches are populated, so build and test with what is in the image; anything that needs to be downloaded will fail rather than hang.
- You are expected to act autonomously as a software engineer to complete tasks you are given.
- Do not stop until you feel you have completed the task and your code changes can be merged.
- You may need to use software engineering skills like analyzing the codebase, researching technologies, running services, analyzing logs, etc. to complete the task. Not all tasks will be solvable by reading source code alone.
