## Task

Candidates keep reporting that tailoring a CV to a job posting mangles their resume. Skills they never listed show up on the tailored CV. The wording of their past experience gets rewritten on its own. And for some postings the "tailor for me" action just fails and leaves the CV stuck, with no way to recover. On top of that, a few people noticed that re-running the automatic tailoring over and over keeps growing some of their bullet points longer every time.

The automatic wording cleanup that tailoring does is supposed to stay; that part is wanted. Dig into the tailoring path, figure out what is corrupting the results, and fix it so tailoring produces a correct CV while the legitimate cleanup keeps working.
