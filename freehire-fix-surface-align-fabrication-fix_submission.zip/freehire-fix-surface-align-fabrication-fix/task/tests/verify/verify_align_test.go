// Internal-package (cv) test. Every test exercises the two pre-existing public
// entry points of the wording-alignment prepass:
//
//   skilltag.PreferredFromText(text) map[string]string
//   cv.Align(doc, preferred)           -> the rewritten CV document
//
// These are the functions the tailoring path calls; they existed before this
// task and their names are the stable contract. Everything a correct fix
// reworks underneath them (how the preferred spellings are resolved, how prose
// is rewritten, how "did anything change" is computed) is an internal detail,
// so this file never names or imports any helper beneath these two entry
// points. It also never assumes cv.Align's return arity: a valid fix may keep
// the single-value signature or widen it to also report whether anything
// changed, so Align is invoked reflectively and only its document result is
// asserted. Idempotency is proved by document stability, not by any change
// flag.
//
// Inputs are built the way the in-tree tests build them (cv.Document with skill
// groups, experience stacks, summaries and bullets) and vacancy text is run
// through PreferredFromText so the preferred map is produced by the code under
// test, not hand-assembled from canonical slugs.

package cv

import (
	"reflect"
	"strings"
	"testing"

	"github.com/strelov1/freehire/internal/skilltag"
)

// alignDoc calls cv.Align reflectively and returns only the rewritten document.
// Align may be func(Document, map[string]string) Document or
// func(Document, map[string]string) (Document, bool); both are valid solution
// shapes, so the second result (if any) is ignored.
func alignDoc(t *testing.T, doc Document, preferred map[string]string) Document {
	t.Helper()
	fn := reflect.ValueOf(Align)
	out := fn.Call([]reflect.Value{reflect.ValueOf(doc), reflect.ValueOf(preferred)})
	if len(out) == 0 {
		t.Fatalf("Align returned no values")
	}
	d, ok := out[0].Interface().(Document)
	if !ok {
		t.Fatalf("Align's first result is %T, want cv.Document", out[0].Interface())
	}
	return d
}

// firstChip is a tiny accessor so a malformed result fails loudly instead of
// panicking with an index error.
func firstChip(t *testing.T, doc Document) string {
	t.Helper()
	if len(doc.Skills) == 0 || len(doc.Skills[0].Items) == 0 {
		t.Fatalf("expected at least one skill chip, got %#v", doc.Skills)
	}
	return doc.Skills[0].Items[0]
}

// preferredValueSet collapses the resolved preferred map to the set of surface
// spellings it chose, so tests can assert "a chip/prose token was rewritten to
// one of the vacancy's preferred spellings" without naming any canonical slug
// key or hardcoding the spelling itself — both of which are data/solution
// choices this verifier must not pin.
func preferredValueSet(preferred map[string]string) map[string]bool {
	set := make(map[string]bool, len(preferred))
	for _, v := range preferred {
		if v != "" {
			set[v] = true
		}
	}
	return set
}

// containsAnyValue reports whether text contains any of the preferred spellings.
func containsAnyValue(text string, values map[string]bool) bool {
	for v := range values {
		if strings.Contains(text, v) {
			return true
		}
	}
	return false
}

// TestVerifyNarrowerTermDoesNotFabricateSkill covers test criterion 1
// (fail_to_pass): a vacancy that spells a NARROWER or more specific technology
// than the one the candidate actually listed must never rewrite the
// candidate's chip into that other skill. Alignment may restyle how a skill is
// spelled; it must never change WHICH skill it is.
//
// Each case lists a chip the candidate wrote and a vacancy whose wording is a
// different (narrower/broader) skill that the pre-fix code folds onto the same
// canonical and then "upgrades" the chip to. A correct fix leaves every chip
// untouched because none of these vacancy terms is an interchangeable spelling
// of the candidate's term.
func TestVerifyNarrowerTermDoesNotFabricateSkill(t *testing.T) {
	cases := []struct {
		name string
		chip string
		jd   string
	}{
		{"rails_is_not_ruby", "Ruby", "We are a Ruby on Rails shop."},
		{"spring_boot_is_not_spring", "Spring", "Java 17 with Spring Boot microservices."},
		{"c_developer_is_not_c", "C", "Looking for a C developer."},
		{"restful_is_not_rest", "REST", "You will design RESTful APIs."},
		{"html5_is_not_html", "HTML", "Frontend with HTML5 and CSS3."},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			preferred := skilltag.PreferredFromText(tc.jd)
			doc := Document{Skills: []SkillGroup{{Items: []string{tc.chip}}}}
			got := firstChip(t, alignDoc(t, doc, preferred))
			if got != tc.chip {
				t.Fatalf("chip changed from %q to %q for vacancy %q; a narrower/broader term must not replace the candidate's skill",
					tc.chip, got, tc.jd)
			}
		})
	}
}

// TestVerifyInterchangeableSpellingStillAligns covers test criterion 2
// (pass_to_pass): the legitimate feature must keep working. When a vacancy
// writes a genuinely interchangeable spelling of a skill the candidate wrote
// (the acronym vs the expansion of the SAME skill), the chip, the experience
// stack entry, and the unambiguous prose alias are all rewritten to the
// vacancy's spelling. This guards against a "fix" that disables alignment
// altogether.
//
// The vacancy text spells out two skills in full; the candidate wrote the
// equivalent acronyms. The preferred spellings come from PreferredFromText, so
// the assertions compare against whatever spellings the resolver actually chose
// (the value set), never a hardcoded surface or a canonical-slug map key — both
// of which are data/solution choices. The property under test is "the acronym
// chips are rewritten to the vacancy's spelling", i.e. the feature is not a
// no-op.
func TestVerifyInterchangeableSpellingStillAligns(t *testing.T) {
	jd := "We run Kubernetes clusters and practice infrastructure as code throughout."
	preferred := skilltag.PreferredFromText(jd)
	values := preferredValueSet(preferred)
	if len(values) < 2 {
		t.Fatalf("vacancy did not resolve two skills: preferred=%#v", preferred)
	}

	inChips := []string{"IaC", "k8s"}
	doc := Document{
		Skills: []SkillGroup{{Items: append([]string(nil), inChips...)}},
		Experience: []ExperienceItem{{
			Stack:   []string{"k8s"},
			Bullets: []string{"Ran k8s clusters for the platform team."},
		}},
	}
	got := alignDoc(t, doc, preferred)

	chips := got.Skills[0].Items
	if len(chips) != len(inChips) {
		t.Fatalf("chip count changed: got %#v, want %d chips", chips, len(inChips))
	}
	for i, c := range chips {
		if c == inChips[i] {
			t.Fatalf("chip %q was not aligned (feature disabled?); result %#v", inChips[i], chips)
		}
		if !values[c] {
			t.Fatalf("chip %q is not one of the vacancy's preferred spellings %v", c, values)
		}
	}
	// The experience stack acronym is likewise rewritten to a preferred spelling.
	if stack := got.Experience[0].Stack; len(stack) != 1 || stack[0] == "k8s" || !values[stack[0]] {
		t.Fatalf("experience stack = %#v, expected the acronym rewritten to a preferred spelling %v", stack, values)
	}
	// The unambiguous prose alias in the bullet is rewritten in place.
	gotBullet := got.Experience[0].Bullets[0]
	if gotBullet == doc.Experience[0].Bullets[0] || !containsAnyValue(gotBullet, values) {
		t.Fatalf("bullet = %q, expected the unambiguous alias rewritten to a preferred spelling %v", gotBullet, values)
	}
}

// TestVerifyNonAsciiVacancyIsSafe covers test criterion 3 (fail_to_pass): a
// vacancy description containing a rune whose lowercase differs in byte length
// (İ U+0130, Ⱥ U+023A) must neither panic the request nor truncate/corrupt the
// resolved spelling or the prose rewriting around the non-ASCII text.
//
// Two sub-checks:
//   - a pathological description (a long run of Ⱥ followed by real skills)
//     must resolve without panicking. The pre-fix code slices the original
//     string with offsets taken from the lowercased copy and panics with a
//     slice-bounds error on this input.
//   - a candidate summary that embeds a non-ASCII place name next to a real
//     skill must still align that skill correctly; the pre-fix code stops
//     rewriting after the length-changing rune and leaves the skill unaligned.
func TestVerifyNonAsciiVacancyIsSafe(t *testing.T) {
	t.Run("pathological_description_does_not_panic", func(t *testing.T) {
		defer func() {
			if r := recover(); r != nil {
				t.Fatalf("PreferredFromText/Align panicked on a non-ASCII vacancy: %v", r)
			}
		}()
		jd := strings.Repeat("Ⱥ", 200) + " We run Kubernetes and infrastructure as code."
		preferred := skilltag.PreferredFromText(jd)
		doc := Document{
			Summary: "Ran Kubernetes clusters.",
			Skills:  []SkillGroup{{Items: []string{"IaC"}}},
		}
		_ = alignDoc(t, doc, preferred)
	})

	t.Run("skill_aligns_around_non_ascii_text", func(t *testing.T) {
		jd := "We run Kubernetes and practice infrastructure as code."
		preferred := skilltag.PreferredFromText(jd)
		values := preferredValueSet(preferred)
		if len(values) == 0 {
			t.Fatalf("vacancy resolved no skills: %#v", preferred)
		}
		for _, name := range []string{"İstanbul", "Ⱥrhus", "Straẞe", "Кёльн"} {
			doc := Document{Summary: "Led the " + name + " team that ran k8s in production."}
			got := alignDoc(t, doc, preferred).Summary
			// The acronym must have been rewritten to one of the vacancy's
			// preferred spellings; the pre-fix code stops rewriting after a
			// length-changing rune and leaves "k8s" in place.
			if strings.Contains(got, "k8s") || !containsAnyValue(got, values) {
				t.Fatalf("summary with %q not aligned around the non-ASCII text: got %q", name, got)
			}
			// The non-ASCII place name must survive intact — not truncated or corrupted.
			if !strings.Contains(got, name) {
				t.Fatalf("summary with %q corrupted the non-ASCII text: got %q", name, got)
			}
		}
	})
}

// TestVerifyAlignmentIsIdempotent covers test criterion 4 (fail_to_pass):
// running alignment a second time over its own output must change nothing. In
// particular no alias may re-read a prior replacement and keep appending to it
// (the "REST API" -> "REST APIs APIs APIs" growth). Idempotency is asserted via
// document stability across two runs — reflect.DeepEqual of the first and
// second outputs — never via any change flag, which is a solution-chosen
// signal.
//
// The vacancy spells "REST APIs", whose shorter alias ("API"/"APIs") embeds in
// the longer surface; the candidate summary already contains that surface, so a
// re-reading rewrite grows it on every pass. A correct fix makes the second
// alignment a no-op.
func TestVerifyAlignmentIsIdempotent(t *testing.T) {
	jd := "You will design REST APIs for the platform."
	preferred := skilltag.PreferredFromText(jd)

	doc := Document{
		Summary: "Built REST APIs for scale.",
		Experience: []ExperienceItem{{
			Stack:   []string{"k8s"},
			Bullets: []string{"Owned the REST APIs powering checkout."},
		}},
	}

	first := alignDoc(t, doc, preferred)
	second := alignDoc(t, first, preferred)
	if !reflect.DeepEqual(first, second) {
		t.Fatalf("alignment is not idempotent:\n first  = %#v\n second = %#v", first, second)
	}

	// A third pass guards against a two-cycle oscillation masquerading as
	// stability and documents that the output has genuinely settled.
	third := alignDoc(t, second, preferred)
	if !reflect.DeepEqual(second, third) {
		t.Fatalf("alignment still changing on the third run:\n second = %#v\n third = %#v", second, third)
	}
}

// TestVerifyResumeOnlyAcronymNotRewrittenInProse covers test criterion 5
// (fail_to_pass): an acronym that is ordinary English inside prose (RAG =
// red/amber/green project health) must not be expanded inside a summary or
// bullet even when the vacancy names the expanded skill (retrieval augmented
// generation). The pre-fix code unions the resume-only acronym tier into the
// prose rewriter and corrupts the sentence.
func TestVerifyResumeOnlyAcronymNotRewrittenInProse(t *testing.T) {
	jd := "You will build LLM features using retrieval augmented generation."
	preferred := skilltag.PreferredFromText(jd)

	doc := Document{
		Summary: "Programme lead reporting RAG status to the steering committee.",
		Experience: []ExperienceItem{{
			Bullets: []string{"Ran the weekly RAG review with stakeholders."},
		}},
	}
	got := alignDoc(t, doc, preferred)

	if strings.Contains(strings.ToLower(got.Summary), "retrieval augmented generation") {
		t.Fatalf("summary expanded a resume-only acronym in prose: %q", got.Summary)
	}
	if got.Summary != doc.Summary {
		t.Fatalf("summary prose was rewritten; got %q, want unchanged %q", got.Summary, doc.Summary)
	}
	if b := got.Experience[0].Bullets[0]; b != doc.Experience[0].Bullets[0] {
		t.Fatalf("bullet prose was rewritten; got %q, want unchanged %q", b, doc.Experience[0].Bullets[0])
	}
}

// TestVerifyPreferredSpellingIsCuratedAndDeterministic covers test criterion 6
// (fail_to_pass): PreferredFromText must return a curated spelling, never a
// span sliced out of the (possibly HTML-noisy, SHOUTY) description, and the
// result must be deterministic across repeated calls regardless of internal
// map iteration order.
//
// The description carries the skills inside HTML markup, across a line break,
// and under a shouty ALL-CAPS heading. A correct fix returns clean curated
// spellings with no markup, no collapsed double spaces, and no all-caps carried
// through from the heading. The result is compared against the resolution of the
// SAME skills from clean text, so the test pins no specific surface string nor
// any canonical-slug key (both are solution/data choices) — only that the noisy
// and clean inputs resolve identically and that no output carries the noise.
func TestVerifyPreferredSpellingIsCuratedAndDeterministic(t *testing.T) {
	clean := skilltag.PreferredFromText("We run Kubernetes and infrastructure as code.")
	if len(clean) < 2 {
		t.Fatalf("clean vacancy did not resolve both skills: %#v", clean)
	}

	noisy := "<ul><li>Strong <b>infrastructure</b> as code (Terraform)</li>\n" +
		"<li>Runs on\nKubernetes</li></ul> REQUIREMENTS: KUBERNETES EXPERIENCE."

	first := skilltag.PreferredFromText(noisy)

	// The noisy input must resolve to exactly the same canonical→spelling map as
	// the clean input: markup/whitespace/casing noise must not change which
	// skills are found nor the spelling returned for each.
	if !reflect.DeepEqual(first, clean) {
		t.Fatalf("noisy input resolved differently from clean input:\n noisy = %#v\n clean = %#v", first, clean)
	}

	// Belt-and-braces: no returned surface may carry raw markup, collapsed
	// double-whitespace, or all-caps sliced from the shouty heading.
	for canonical, surface := range first {
		if strings.ContainsAny(surface, "<>") {
			t.Fatalf("%s spelling %q contains markup characters", canonical, surface)
		}
		if strings.Contains(surface, "  ") {
			t.Fatalf("%s spelling %q contains collapsed double whitespace from the source", canonical, surface)
		}
		if surface == strings.ToUpper(surface) && surface != strings.ToLower(surface) {
			t.Fatalf("%s spelling %q is all-caps, i.e. sliced from the shouty heading", canonical, surface)
		}
	}

	// Determinism: repeated resolution must be identical regardless of map
	// iteration order inside the resolver.
	for i := 0; i < 200; i++ {
		again := skilltag.PreferredFromText(noisy)
		if !reflect.DeepEqual(again, first) {
			t.Fatalf("PreferredFromText is not deterministic: run %d = %#v, first = %#v", i, again, first)
		}
	}
}
