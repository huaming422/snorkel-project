## Task

we hit something odd with worker deployment versioning (the newer "v3" versioning). when we reset one of our v3-versioned workflows, the fresh run that the reset produces comes back incorrectly pinned to a specific worker build id that it has no business being tied to.

it only shows up after a reset. running these versioned workflows normally looks completely fine, which is why it went unnoticed for a while; it's just the reset run that comes up with the wrong build-id pinning.

can you dig in and get the reset runs to stop picking up a build id they were never supposed to be associated with?
