// Guard test for the older build-ID-based versioning scheme.
//
// Injected into /repo/temporal/tests/ and compiled into the pre-existing `tests`
// package, reusing VersioningIntegSuite and its helpers. It observes behavior
// only through workflow history (validateWorkflowEventsVersionStamps reads the
// SDK workflow history and asserts each task started event records the expected
// per-task build-version information).
//
// This exercises an old build-ID versioned workflow, where the per-task
// build-version information MUST still be recorded on started events. A change
// that suppresses that information for everyone (instead of only the v3 case)
// drops these stamps and fails here.
//
// The underlying scenario is invoked once directly (rather than through the
// suite's matching-behavior fan-out) to keep the run focused and within the
// time budget; the recorded-stamp assertions are identical across those
// variants.
package tests

import (
	"testing"

	"github.com/stretchr/testify/suite"
)

func TestWv2StampVerify(t *testing.T) {
	suite.Run(t, new(VersioningIntegSuite))
}

func (s *VersioningIntegSuite) TestVerifyOldVersioningStampPreserved() {
	s.workflowStaysInBuildId()
}
