// Behavioral test for worker-deployment ("v3") versioned workflows.
//
// This file is injected into /repo/temporal/tests/ and compiled as part of the
// pre-existing `tests` package, so it reuses that package's Versioning3Suite and
// its helpers (drainWorkflowTaskAfterSetCurrent, pollWftAndHandle, sendUpdate,
// UpdateAcceptCompleteCommands/Messages, GetHistory). It observes behavior only
// through the pre-existing gRPC history interface (s.GetHistory); it does not
// reference any internal symbol the fix may restructure, so any valid
// implementation shape is accepted.
//
// Scenario: drive a v3-versioned workflow through an update accept+complete and a
// workflow-task failure+retry (the belated event-production paths), then read the
// full history back and assert no WorkflowTaskStarted event records per-task
// worker build-version information for a v3 workflow.
package tests

import (
	"context"
	"testing"

	commandpb "go.temporal.io/api/command/v1"
	commonpb "go.temporal.io/api/common/v1"
	deploymentpb "go.temporal.io/api/deployment/v1"
	enumspb "go.temporal.io/api/enums/v1"
	failurepb "go.temporal.io/api/failure/v1"
	"go.temporal.io/api/workflowservice/v1"

	"github.com/stretchr/testify/suite"
	"go.temporal.io/server/common/testing/testvars"
	"go.temporal.io/server/service/worker/workerdeployment"
	"go.temporal.io/server/tests/testcore"
)

func TestWv3StampVerify(t *testing.T) {
	suite.Run(t, &Versioning3Suite{
		deploymentWorkflowVersion: workerdeployment.VersionDataRevisionNumber,
	})
}

func (s *Versioning3Suite) TestVerifyNoWorkerVersionOnStartedEventsV3() {
	tv := testvars.New(s)
	tvUpd1 := tv.WithUpdateIDNumber(1).WithMessageIDNumber(1)
	tvUpd2 := tv.WithUpdateIDNumber(2)
	stamp := &commonpb.WorkerVersionStamp{UseVersioning: true, BuildId: tv.BuildID()}

	// Start workflow and drain first WFT.
	execution, _ := s.drainWorkflowTaskAfterSetCurrent(tv)

	// Send first update.
	updateResultCh := sendUpdateNoError(s, tvUpd1)

	// Poll and handle: accept + complete the first update on a versioned poller.
	s.pollWftAndHandle(tv, false, nil,
		func(task *workflowservice.PollWorkflowTaskQueueResponse) (*workflowservice.RespondWorkflowTaskCompletedRequest, error) {
			s.NotNil(task)
			s.NotEmpty(task.Messages)
			return &workflowservice.RespondWorkflowTaskCompletedRequest{
				Commands:           s.UpdateAcceptCompleteCommands(tvUpd1),
				Messages:           s.UpdateAcceptCompleteMessages(tvUpd1, task.Messages[0]),
				WorkerVersionStamp: stamp,
				VersioningBehavior: vbUnpinned,
				DeploymentOptions: &deploymentpb.WorkerDeploymentOptions{
					BuildId:              tv.BuildID(),
					DeploymentName:       tv.DeploymentSeries(),
					WorkerVersioningMode: enumspb.WORKER_VERSIONING_MODE_VERSIONED,
				},
			}, nil
		})
	<-updateResultCh

	// Send second update.
	updateResultCh2 := sendUpdate(context.Background(), s, tvUpd2)

	// Poll and fail the WFT with deployment options to trigger a transient retry.
	failCtx := testcore.NewContext()
	pollResp, err := s.FrontendClient().PollWorkflowTaskQueue(failCtx, &workflowservice.PollWorkflowTaskQueueRequest{
		Namespace:         s.Namespace().String(),
		TaskQueue:         tv.TaskQueue(),
		Identity:          tv.WorkerIdentity(),
		DeploymentOptions: tv.WorkerDeploymentOptions(true),
	})
	s.NoError(err)
	s.NotEmpty(pollResp.GetTaskToken())
	_, err = s.FrontendClient().RespondWorkflowTaskFailed(failCtx, &workflowservice.RespondWorkflowTaskFailedRequest{
		Namespace:         s.Namespace().String(),
		TaskToken:         pollResp.TaskToken,
		Cause:             enumspb.WORKFLOW_TASK_FAILED_CAUSE_WORKFLOW_WORKER_UNHANDLED_FAILURE,
		Identity:          tv.WorkerIdentity(),
		WorkerVersion:     stamp,
		DeploymentOptions: tv.WorkerDeploymentOptions(true),
	})
	s.NoError(err)

	// Poll the retried (transient) WFT and fail the workflow.
	s.pollWftAndHandle(tv, false, nil,
		func(task *workflowservice.PollWorkflowTaskQueueResponse) (*workflowservice.RespondWorkflowTaskCompletedRequest, error) {
			s.NotNil(task)
			return &workflowservice.RespondWorkflowTaskCompletedRequest{
				Commands: []*commandpb.Command{
					{
						CommandType: enumspb.COMMAND_TYPE_FAIL_WORKFLOW_EXECUTION,
						Attributes: &commandpb.Command_FailWorkflowExecutionCommandAttributes{
							FailWorkflowExecutionCommandAttributes: &commandpb.FailWorkflowExecutionCommandAttributes{
								Failure: &failurepb.Failure{Message: "workflow failed intentionally"},
							},
						},
					},
				},
				WorkerVersionStamp: stamp,
				VersioningBehavior: vbUnpinned,
				DeploymentOptions: &deploymentpb.WorkerDeploymentOptions{
					BuildId:              tv.BuildID(),
					DeploymentName:       tv.DeploymentSeries(),
					WorkerVersioningMode: enumspb.WORKER_VERSIONING_MODE_VERSIONED,
				},
			}, nil
		})

	<-updateResultCh2

	// For a v3-versioned workflow, no WorkflowTaskStarted event should record
	// per-task worker build-version information. A started event that still
	// carries it is replayed on reset and wrongly pins the reset run to a build.
	events := s.GetHistory(s.Namespace().String(), execution)
	for _, event := range events {
		if event.GetEventType() == enumspb.EVENT_TYPE_WORKFLOW_TASK_STARTED {
			s.Nil(
				//nolint:staticcheck // SA1019
				event.GetWorkflowTaskStartedEventAttributes().GetWorkerVersion(),
				"WorkflowTaskStarted event %d should not record worker build-version information for a v3 workflow",
				event.GetEventId(),
			)
		}
	}
}
