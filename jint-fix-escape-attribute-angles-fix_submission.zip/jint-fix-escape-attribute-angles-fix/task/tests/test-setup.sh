#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier runs (set -euo pipefail inherited).
# Bring the baked .NET dependency closure online for the verifier's dotnet build/test.
# No assertion logic here.
cd /repo/jint

# Cut .NET off the network so a cache miss fails fast instead of reaching nuget.org.
# The image (image/Dockerfile) already warmed /opt/cache/nuget by restoring + building
# Jint.Tests.Browser and its full ProjectReference closure at the base commit.
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1 DOTNET_NOLOGO=1
export NUGET_PACKAGES=/opt/cache/nuget

# Dependencies: offline-first against the image bake, logged online fallback.
if dotnet restore Jint.slnx --source /opt/cache/nuget > /tmp/test-setup-restore.log 2>&1; then
    echo "[offline-first] dotnet restore satisfied from image cache"
elif dotnet restore Jint.slnx >> /tmp/test-setup-restore.log 2>&1; then
    echo "[test-setup] dotnet restore pulled from network (image cache was stale)"
else
    tail -60 /tmp/test-setup-restore.log >&2; exit 1
fi
