using System.Text.Json;
using AngleSharp.Xml.Parser;
using Jint.Browser.Dom;
using Jint.Tests.Browser.DevTools;

namespace Jint.Tests.Browser.Dom;

using Browser = global::Jint.Browser.Browser;

// Behavioural checks for HTML attribute serialization, written entirely against
// pre-existing, stable interfaces: the JS DOM markup getters exercised through
// DomTestFixture, the public Page.ContentAsync API, the DevTools DOM.getOuterHTML
// protocol result through PageSession, and AngleSharp's XML serialization. None of
// the extension points a fix might introduce are named here; only observable
// string output is asserted.
public sealed class AttributeMarkupSerializationChecks
{
    // Reading an element's markup must escape angle brackets in attribute values,
    // the way a real browser serializes them. Asserted on both the element getter
    // and the parent's inner markup so a change that reaches only one still shows.
    [TestCase("axx>", "axx&gt;")]
    [TestCase("some<>", "some&lt;&gt;")]
    public void AttributeAnglesAreEscapedInHtmlMarkup(string value, string escaped)
    {
        using var fixture = DomTestFixture.Create("<main></main>");
        fixture.Engine.SetValue("value", value);
        fixture.Execute("var el = document.createElement('el'); el.setAttribute('attr', value); document.querySelector('main').append(el);");
        fixture.Text("el.outerHTML").Should().Be("<el attr=\"" + escaped + "\"></el>");
        fixture.Text("document.querySelector('main').innerHTML").Should().Be("<el attr=\"" + escaped + "\"></el>");
    }

    // Only the two missing escapes are added. Characters the serializer already
    // escapes (&, ", the non-breaking space) must not be escaped a second time, and
    // the live attribute value read back through getAttribute stays the raw text.
    [Test]
    public void ExistingEscapesAreNotDoubledAndRawValueIsPreserved()
    {
        const string value = "&lt;<>\"\u00a0&";
        const string escaped = "&amp;lt;&lt;&gt;&quot;&nbsp;&amp;";
        using var fixture = DomTestFixture.Create("<main></main>");
        fixture.Engine.SetValue("value", value);
        fixture.Execute("var el = document.createElement('el'); el.setAttribute('attr', value); document.querySelector('main').append(el);");
        fixture.Text("el.outerHTML").Should().Be("<el attr=\"" + escaped + "\"></el>");
        fixture.Text("el.getAttribute('attr')").Should().Be(value);
    }

    // The escaping applies to the attribute value only. An attribute name that
    // itself carries a quote or an angle bracket must come out untouched, and so
    // must a namespaced name's spelling; only the quoted value is rewritten.
    [Test]
    public void AttributeNamesAndNamespaceSpellingRemainNative()
    {
        using var fixture = DomTestFixture.Create("<main></main>");
        fixture.Execute("""
            var el = document.createElement('el');
            el.setAttribute('a"<', '<>');
            el.setAttributeNS('http://www.w3.org/XML/1998/namespace', 'xml:lang', '<>');
            document.querySelector('main').append(el);
            """);
        fixture.Text("el.outerHTML").Should().Be("""<el a"<="&lt;&gt;" xml:lang="&lt;&gt;"></el>""");
    }

    // The same serialization backs template content and shadow-root markup, so the
    // escaped attribute value must appear through those getters too.
    [Test]
    public void TemplateAndShadowRootMarkupUseTheSameSerialization()
    {
        using var fixture = DomTestFixture.Create("<main></main>");
        fixture.Execute("""
            var template = document.createElement('template');
            template.innerHTML = '<el attr="some<>"></el>';
            var shadow = document.querySelector('main').attachShadow({mode:'open'});
            shadow.append(template.content.cloneNode(true));
            """);
        fixture.Text("template.innerHTML").Should().Be("<el attr=\"some&lt;&gt;\"></el>");
        fixture.Text("shadow.innerHTML").Should().Be("<el attr=\"some&lt;&gt;\"></el>");
    }

    // The public page-content API reads markup through the same path, so it must
    // show the escaped attribute value as well. The XML serialization path is
    // separate and keeps its own rules: serializeToString escapes '<' but leaves
    // '>' literal, unchanged by any HTML-markup change.
    [Test]
    public async Task PageContentEscapesAttributeAnglesWhileXmlSerializerStaysNative()
    {
        await using var browser = new Browser();
        var page = await browser.NewPageAsync();
        await page.SetContentAsync("<!doctype html><el attr='some<>'></el>");
        (await page.ContentAsync()).Should().Contain("<el attr=\"some&lt;&gt;\"></el>");
        (await page.EvaluateAsync<string>("new XMLSerializer().serializeToString(document.querySelector('el'))"))
            .Should().Be("<el attr=\"some&lt;>\" />");
    }

    // The DevTools DOM.getOuterHTML result reads markup through the same path on
    // both a single element and the whole document, and a plain outerHTML read via
    // the protocol's expression evaluation must agree.
    [Test]
    public async Task DevToolsOuterHtmlEscapesAttributeAngles()
    {
        await using var session = await PageSession.CreateAsync();
        var attachment = await session.OpenPageAsync();
        await SetBody(session, attachment, "<el attr='some<>'></el>");
        var root = (await session.ResultAsync("DOM.getDocument", "{}", attachment)).GetProperty("root");
        var documentId = root.GetProperty("nodeId").GetInt32();
        var element = (await session.ResultAsync("DOM.querySelector",
            $$"""{"nodeId":{{documentId}},"selector":"el"}""", attachment)).GetProperty("nodeId").GetInt32();
        (await session.ResultAsync("DOM.getOuterHTML", $$"""{"nodeId":{{element}}}""", attachment))
            .GetProperty("outerHTML").GetString().Should().Be("<el attr=\"some&lt;&gt;\"></el>");
        (await session.ResultAsync("DOM.getOuterHTML", $$"""{"nodeId":{{documentId}}}""", attachment))
            .GetProperty("outerHTML").GetString().Should().Contain("<el attr=\"some&lt;&gt;\"></el>");
        (await session.EvaluateAsync("document.querySelector('el').outerHTML", attachment))
            .GetProperty("value").GetString().Should().Be("<el attr=\"some&lt;&gt;\"></el>");
    }

    // XML-document markup getters stay on the native path: the JS getter output
    // equals the native OuterHtml/InnerHtml, with namespace declarations, empty
    // tags and the non-breaking space preserved exactly as before.
    [Test]
    public void XmlDocumentMarkupGettersPreserveNativeSerialization()
    {
        using var fixture = DomTestFixture.Create("<main></main>");
        using var xml = new XmlParser().ParseDocument(
            "<root xmlns='urn:root' xmlns:p='urn:p'><p:leaf/></root>");
        var root = xml.DocumentElement!;
        root.FirstElementChild!.SetAttribute("data", "\u00a0");
        var nativeInner = root.InnerHtml;
        var nativeOuter = root.OuterHtml;
        fixture.Engine.SetValue("xml", DomBindings.Wrap(fixture.Engine, xml));
        fixture.Text("xml.documentElement.innerHTML").Should().Be(nativeInner);
        fixture.Text("xml.documentElement.outerHTML").Should().Be(nativeOuter);
        nativeInner.Should().Contain("<p:leaf data=\"&nbsp;\">");
        nativeOuter.Should().Contain("xmlns=\"urn:root\" xmlns:p=\"urn:p\"");
    }

    // Content that is not an attribute value keeps its existing serialization: a
    // text node, a comment and raw <script> content all stay exactly as before.
    [Test]
    public void NonAttributeContentKeepsNativeEscaping()
    {
        using var fixture = DomTestFixture.Create("<main></main>");
        fixture.Execute("""
            var el = document.createElement('el');
            el.append(document.createTextNode('<>&'), document.createComment('<>'));
            var script = document.createElement('script');
            script.textContent = 'a < b && c > d';
            el.append(script);
            document.querySelector('main').append(el);
            """);
        fixture.Text("el.outerHTML").Should().Be("<el>&lt;&gt;&amp;<!--<>--><script>a < b && c > d</script></el>");
    }

    private static async Task SetBody(PageSession session, string attachment, string body)
    {
        await session.ResultAsync(
            "Page.setDocumentContent",
            JsonSerializer.Serialize(new Dictionary<string, object> { ["frameId"] = "", ["html"] = body }),
            attachment);
    }
}
