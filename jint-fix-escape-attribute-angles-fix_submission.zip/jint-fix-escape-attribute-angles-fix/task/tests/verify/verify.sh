#!/usr/bin/env bash
# Behavioural verifier for the HTML attribute-serialization fix.
#
# Drops an authored NUnit source file into the browser test project, then runs a
# filtered `dotnet test` on one target framework in Release (the repo's host-contract
# leg). The authored file asserts observable markup-getter / page / DevTools / XML
# output through pre-existing interfaces only. The pre-existing binding-consistency
# suite is run in the same pass so a change that re-routes the getters through the
# generated bindings must keep that suite green.
#
# Runs with cwd = the repo root (/repo/jint). Exit 0 = all assertions pass; non-zero
# = at least one assertion (or the consistency suite) failed.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO="/repo/jint"
PROJECT="Jint.Tests.Browser/Jint.Tests.Browser.csproj"
SRC="${SCRIPT_DIR}/AttributeMarkupSerializationChecks.cs"
DEST_DIR="${REPO}/Jint.Tests.Browser/Dom"
DEST="${DEST_DIR}/AttributeMarkupSerializationChecks.cs"

cd "${REPO}" || { echo "FAIL: repo not found at ${REPO}" >&2; exit 2; }

if [ ! -f "${SRC}" ]; then
    echo "FAIL: authored source not found at ${SRC}" >&2
    exit 2
fi

cp "${SRC}" "${DEST}" || { echo "FAIL: could not place authored source" >&2; exit 2; }
# Remove the injected source on exit so grading leaves the checkout as it found it.
trap 'rm -f "${DEST}"' EXIT

export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1 DOTNET_NOLOGO=1
export NUGET_PACKAGES=/opt/cache/nuget
# Release host-contract leg, matching the repository's own verification run.
export JINT_HOST_CONTRACT_VERIFICATION=1

FILTER="FullyQualifiedName~AttributeMarkupSerializationChecks|FullyQualifiedName~DomBindingsStalenessTests"

echo "[verify] running filtered dotnet test on net10.0 (Release, host-contract)"
# test-setup.sh already restored from the warm image cache; skip re-restore so a
# transient cache miss cannot reach the network from inside the verifier.
dotnet test "${PROJECT}" -c Release -f net10.0 --no-restore --filter "${FILTER}"
status=$?

if [ "${status}" -ne 0 ]; then
    echo "FAIL: markup-serialization checks or binding-consistency suite did not pass (exit ${status})" >&2
    exit 1
fi

echo "OK: all markup-serialization checks and the binding-consistency suite passed"
exit 0
