## Task

when a script reads an element's HTML markup back out through our headless-browser HTML serialization, any attribute value that contains `<` or `>` comes out with those characters left literal instead of escaped. the result is malformed markup that doesn't match what a real browser produces, so anything that round-trips or inspects that markup through us gets the wrong thing. track down why the serialized attribute values are wrong and fix it so the markup matches standard browser behavior.
