"""Behavioral checks for upstream-WebSocket transport liveness.

These tests drive the two upstream-WebSocket adapter classes
(``WebsocketsUpstreamWebSocket`` for the direct ``websockets`` path and
``CodexUpstreamWebSocket`` for the routed ``aiohttp`` path) in-process with
fake transports. No network, no services, no running proxy.

After a network change a socket can sit half-open: the transport is dead but
no read or write ever raises. A ping/pong watchdog reports that as a
locally sent keepalive-timeout close on the direct path and as a
``ServerTimeoutError`` ("No PONG received after ...") on the routed path,
either handed to ``receive`` directly or stored on the socket for the next
receive or send. Every one of those reports comes out of the adapter as an
error carrying the same relay-visible error code, and the HTTP bridge reader
fails the pending request on it without sending it again or blaming the
account.

The code's string value is left to the implementation: it is read from the
adapter's own output and compared across paths, never hardcoded.
"""

from __future__ import annotations

import asyncio
import time
from collections import deque
from contextlib import nullcontext
from types import SimpleNamespace
from typing import Any, cast
from unittest.mock import AsyncMock

import aiohttp
import anyio
import pytest
from websockets.exceptions import ConnectionClosedError
from websockets.frames import Close

import app.core.clients.proxy_websocket as proxy_websocket_module
from app.core.clients.codex import CodexWebSocketResult
from app.core.clients.proxy_websocket import (
    CodexUpstreamWebSocket,
    UpstreamWebSocketTransportError,
    WebsocketsUpstreamWebSocket,
    connect_responses_websocket,
)
from app.core.config.settings import get_settings
from app.core.upstream_proxy import ResolvedProxyEndpoint, ResolvedUpstreamRoute

_KEEPALIVE_REASON = "keepalive ping timeout"
_HEARTBEAT_MESSAGE = "No PONG received after 60.0 seconds"


class _FakeDirectConnection:
    """Minimal ``websockets`` connection whose ``recv`` raises a close error."""

    def __init__(self, exc: BaseException) -> None:
        self._exc = exc

    async def recv(self) -> object:
        raise self._exc


class _FakeAiohttpWebSocket:
    """Minimal ``aiohttp`` websocket exposing the surface the adapter uses."""

    def __init__(
        self,
        *,
        receive_message: aiohttp.WSMessage | None = None,
        send_exc: BaseException | None = None,
        stored_exc: BaseException | None = None,
    ) -> None:
        self._receive_message = receive_message
        self._send_exc = send_exc
        self._stored_exc = stored_exc
        self.close_code: int | None = None

    async def receive(self) -> aiohttp.WSMessage:
        assert self._receive_message is not None
        return self._receive_message

    async def send_str(self, data: str) -> None:
        del data
        if self._send_exc is not None:
            raise self._send_exc

    async def send_bytes(self, data: bytes) -> None:
        del data
        if self._send_exc is not None:
            raise self._send_exc

    def exception(self) -> BaseException | None:
        return self._stored_exc

    async def close(self, *, code: int = 1000, message: bytes = b"") -> None:
        del message
        self.close_code = code


def _direct_adapter(exc: BaseException) -> WebsocketsUpstreamWebSocket:
    return WebsocketsUpstreamWebSocket(cast(Any, _FakeDirectConnection(exc)))


async def _classify_direct_local_keepalive() -> str | None:
    """Direct path: the client's own 1011 keepalive-timeout close."""
    exc = ConnectionClosedError(None, Close(1011, _KEEPALIVE_REASON))
    message = await _direct_adapter(exc).receive()
    assert message.kind == "error"
    return message.error_code


async def _classify_routed_immediate_timeout() -> str | None:
    """Routed path: heartbeat timeout delivered as an ERROR frame."""
    ws = _FakeAiohttpWebSocket(
        receive_message=aiohttp.WSMessage(
            aiohttp.WSMsgType.ERROR,
            aiohttp.ServerTimeoutError(_HEARTBEAT_MESSAGE),
            None,
        ),
    )
    message = await CodexUpstreamWebSocket(ws).receive()
    assert message.kind == "error"
    return message.error_code


async def _classify_routed_stored_timeout() -> tuple[str, str | None]:
    """Routed path: heartbeat timeout stored, next receive returns CLOSED."""
    ws = _FakeAiohttpWebSocket(
        receive_message=aiohttp.WSMessage(aiohttp.WSMsgType.CLOSED, None, None),
        stored_exc=aiohttp.ServerTimeoutError(_HEARTBEAT_MESSAGE),
    )
    message = await CodexUpstreamWebSocket(ws).receive()
    return message.kind, message.error_code


async def _classify_routed_send_timeout(payload: str | bytes) -> str | None:
    """Routed path: a send fails while a heartbeat timeout is stored."""
    ws = _FakeAiohttpWebSocket(
        send_exc=RuntimeError("Cannot write to closing transport"),
        stored_exc=aiohttp.ServerTimeoutError(_HEARTBEAT_MESSAGE),
    )
    adapter = CodexUpstreamWebSocket(ws)
    with pytest.raises(UpstreamWebSocketTransportError) as exc_info:
        if isinstance(payload, str):
            await adapter.send_text(payload)
        else:
            await adapter.send_bytes(payload)
    return exc_info.value.error_code


@pytest.mark.asyncio
async def test_direct_adapter_classifies_local_keepalive_timeout() -> None:
    """The direct client's own keepalive-timeout close carries the same code as
    a routed heartbeat timeout."""
    local_code = await _classify_direct_local_keepalive()
    routed_code = await _classify_routed_immediate_timeout()

    assert local_code is not None
    assert local_code == routed_code


@pytest.mark.asyncio
async def test_routed_adapter_classifies_immediate_heartbeat_timeout() -> None:
    """A heartbeat timeout delivered as ERROR comes out with an error code."""
    routed_code = await _classify_routed_immediate_timeout()

    assert routed_code is not None


@pytest.mark.asyncio
async def test_routed_adapter_classifies_stored_heartbeat_timeout() -> None:
    """A heartbeat timeout stored between receives is reported as an error.

    With no receive waiting when the heartbeat expires, aiohttp keeps the
    timeout on the socket and the next receive returns CLOSED. The adapter
    reports that as the same error as the immediate case, not as a clean close.
    """
    kind, stored_code = await _classify_routed_stored_timeout()
    routed_code = await _classify_routed_immediate_timeout()

    assert kind == "error"
    assert stored_code is not None
    assert stored_code == routed_code


@pytest.mark.asyncio
@pytest.mark.parametrize("payload", ["request", b"request"], ids=["text", "bytes"])
async def test_routed_adapter_send_carries_liveness_code(payload: str | bytes) -> None:
    """A send that fails while a heartbeat timeout is stored raises a transport
    error with the same code a receive reports."""
    send_code = await _classify_routed_send_timeout(payload)
    routed_code = await _classify_routed_immediate_timeout()

    assert send_code is not None
    assert send_code == routed_code


@pytest.mark.asyncio
async def test_liveness_code_is_the_same_on_every_path() -> None:
    """Direct close, routed immediate, routed stored and routed send-time
    timeouts all report one non-empty code."""
    codes = {
        "direct close": await _classify_direct_local_keepalive(),
        "routed immediate": await _classify_routed_immediate_timeout(),
        "routed stored": (await _classify_routed_stored_timeout())[1],
        "routed send text": await _classify_routed_send_timeout("request"),
        "routed send bytes": await _classify_routed_send_timeout(b"request"),
    }

    assert all(code is not None for code in codes.values()), codes
    assert len(set(codes.values())) == 1, codes


def _responses_route() -> ResolvedUpstreamRoute:
    """A minimal resolved route so the Responses connect takes the routed path."""
    return ResolvedUpstreamRoute(
        mode="account_bound",
        pool_id="pool_1",
        endpoint=ResolvedProxyEndpoint("ep_1", "http", "proxy.test", 8080),
    )


class _CaptureRoutedCodexClient:
    """Routed opener that records the kwargs the connect path hands it.

    Same surface as ``CodexClient.open_ws_with_route_metadata``. It performs no
    I/O and returns a fake upstream websocket so the adapter can be built.
    """

    def __init__(self) -> None:
        self.kwargs: dict[str, Any] = {}

    async def open_ws_with_route_metadata(
        self, url: str, *, route: ResolvedUpstreamRoute, **kwargs: Any
    ) -> CodexWebSocketResult:
        del url
        self.kwargs = kwargs
        return CodexWebSocketResult(
            websocket=_FakeAiohttpWebSocket(),
            context=None,
            route=route,
            fallback_used=False,
        )

    async def close(self) -> None:
        return None


def _within_idle_window(value: Any) -> bool:
    """A positive watchdog timeout no longer than the proxy's idle window."""
    idle_timeout = get_settings().proxy_downstream_websocket_idle_timeout_seconds
    return isinstance(value, (int, float)) and not isinstance(value, bool) and 0 < value <= idle_timeout


@pytest.mark.asyncio
async def test_responses_routed_connect_enables_heartbeat_watchdog() -> None:
    """The routed Responses connect turns on aiohttp's heartbeat.

    The opener receives a positive ``heartbeat`` no longer than the proxy's
    existing idle window, so a black-holed route is noticed within minutes.
    """
    client = _CaptureRoutedCodexClient()

    await connect_responses_websocket(
        {"user-agent": "codex"},
        "access",
        "chatgpt_account",
        base_url="https://chatgpt.test/backend-api",
        route=_responses_route(),
        codex_client=cast(Any, client),
    )

    heartbeat = client.kwargs.get("heartbeat")
    assert _within_idle_window(heartbeat), client.kwargs


@pytest.mark.asyncio
async def test_responses_direct_connect_enables_ping_timeout_watchdog(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The direct Responses connect leaves the websockets ping timeout on.

    Either a positive ``ping_timeout`` no longer than the idle window is passed,
    or the argument is left out so the library's own default applies; an
    explicit ``None`` turns the timeout off. Pings themselves stay enabled.
    """
    captured: dict[str, Any] = {}

    async def fake_websocket_connect(url: str, **kwargs: Any) -> Any:
        del url
        captured.update(kwargs)
        return object()

    monkeypatch.setattr(proxy_websocket_module, "websocket_connect", fake_websocket_connect)

    await connect_responses_websocket(
        {"user-agent": "codex"},
        "access",
        "chatgpt_account",
        base_url="https://chatgpt.test/backend-api",
        route=None,
        allow_direct_egress=True,
    )

    assert "ping_timeout" not in captured or _within_idle_window(captured["ping_timeout"]), captured
    assert "ping_interval" not in captured or _within_idle_window(captured["ping_interval"]), captured


def _bridge_request() -> Any:
    from app.modules.proxy import service as proxy_service

    return proxy_service._WebSocketRequestState(
        request_id="req-liveness",
        model="gpt-5.4",
        service_tier=None,
        reasoning_effort=None,
        api_key_reservation=None,
        started_at=time.monotonic(),
        awaiting_response_created=True,
        request_text='{"type":"response.create","model":"gpt-5.4","input":"hello"}',
        transport="http",
    )


def _bridge_session(request_state: Any, upstream: Any) -> Any:
    from app.db.models import AccountStatus
    from app.modules.proxy import service as proxy_service

    return proxy_service._HTTPBridgeSession(
        key=proxy_service._HTTPBridgeSessionKey("session_header", "liveness", None),
        headers={"x-codex-session-id": "liveness"},
        affinity=proxy_service._AffinityPolicy(
            key="liveness",
            kind=proxy_service.StickySessionKind.CODEX_SESSION,
        ),
        request_model="gpt-5.4",
        account=cast(Any, SimpleNamespace(id="acc-liveness", status=AccountStatus.ACTIVE, plan_type="plus")),
        upstream=upstream,
        upstream_control=proxy_service._WebSocketUpstreamControl(),
        pending_requests=deque([request_state]),
        pending_lock=anyio.Lock(),
        response_create_gate=asyncio.Semaphore(1),
        queued_request_count=1,
        last_used_at=1.0,
        idle_ttl_seconds=120.0,
    )


@pytest.mark.asyncio
@pytest.mark.parametrize("delivery", ["immediate", "stored"])
async def test_bridge_fails_request_without_resend_or_account_penalty(
    monkeypatch: pytest.MonkeyPatch, delivery: str
) -> None:
    """A heartbeat timeout seen by the HTTP bridge reader fails the pending
    request back without sending it upstream again and without counting the
    failure against the account."""
    from app.core.config.settings import Settings
    from app.modules.proxy import service as proxy_service

    if delivery == "immediate":
        ws = _FakeAiohttpWebSocket(
            receive_message=aiohttp.WSMessage(
                aiohttp.WSMsgType.ERROR, aiohttp.ServerTimeoutError(_HEARTBEAT_MESSAGE), None
            ),
        )
    else:
        ws = _FakeAiohttpWebSocket(
            receive_message=aiohttp.WSMessage(aiohttp.WSMsgType.CLOSED, None, None),
            stored_exc=aiohttp.ServerTimeoutError(_HEARTBEAT_MESSAGE),
        )
    sent: list[Any] = []

    async def record_send(data: Any) -> None:
        sent.append(data)

    ws.send_str = record_send  # type: ignore[method-assign]
    ws.send_bytes = record_send  # type: ignore[method-assign]
    service = proxy_service.ProxyService(cast(Any, nullcontext()))
    request_state = _bridge_request()
    session = _bridge_session(request_state, CodexUpstreamWebSocket(ws))
    monkeypatch.setattr(
        proxy_service, "get_settings", lambda: Settings(http_responses_session_bridge_enabled=True)
    )
    reconnect = AsyncMock()
    monkeypatch.setattr(service, "_reconnect_http_bridge_session", reconnect)
    failures: list[dict[str, Any]] = []

    async def fail_reader(target_session: Any, **kwargs: Any) -> bool:
        failures.append(dict(kwargs))
        target_session.closed = True
        return True

    monkeypatch.setattr(service, "_fail_http_bridge_reader_and_maybe_retire", fail_reader)

    await asyncio.wait_for(service._relay_http_bridge_upstream_messages(session), timeout=10)

    assert sent == []
    reconnect.assert_not_awaited()
    assert len(failures) == 1, failures
    assert failures[0].get("penalize_account") is False, failures
