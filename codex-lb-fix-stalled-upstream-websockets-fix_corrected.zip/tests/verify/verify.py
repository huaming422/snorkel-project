"""Responses conversations over an upstream connection that stops carrying data.

Each test connects through the proxy's own upstream connect path to a local
websocket server behind a TCP relay. The relay can drop every byte in both
directions while both sockets stay open, the way a connection looks after the
machine changes networks. Tests run on a fresh event loop whose clock runs
faster than wall time, so minutes of quiet pass in seconds.
"""

from __future__ import annotations

import asyncio
import json
import time
from collections import deque
from types import SimpleNamespace
from typing import Any, Callable, cast
from unittest.mock import AsyncMock

import aiohttp
import anyio
import pytest
from websockets.asyncio.server import serve

from app.core.clients.codex import CodexClient
from app.core.clients.proxy_websocket import connect_responses_websocket
from app.core.config.settings import Settings, get_settings
from app.core.upstream_proxy import ResolvedProxyEndpoint, ResolvedUpstreamRoute
from app.core.utils.time import utcnow
from app.db.models import Account, AccountStatus
from app.modules.proxy import service as proxy_service

# Virtual seconds per real second once a test is past its handshake.
_SPEED = 40.0
# Upper bound for noticing a connection that carries nothing.
_NOTICE_WITHIN = 300.0
# How long a healthy turn stays quiet before it answers.
_QUIET_FOR = 250.0
# How long a websocket client waits before its next turn, inside the proxy's client idle limit.
_CLIENT_PAUSE = 60.0
_PENALTY_METHODS = ("record_error", "mark_rate_limit", "mark_quota_exceeded", "mark_permanent_failure")


class _Clock:
    """Loop and monotonic clock that can run faster than wall time."""

    def __init__(self, loop: asyncio.AbstractEventLoop) -> None:
        self._real = time.monotonic
        self._base_virtual = self._real()
        self._base_real = self._base_virtual
        self.speed = 1.0
        selector = loop._selector  # type: ignore[attr-defined]
        select = selector.select
        loop.time = self.now  # type: ignore[method-assign]
        selector.select = lambda timeout=None: select(None if timeout is None else timeout / self.speed)

    def now(self) -> float:
        return self._base_virtual + (self._real() - self._base_real) * self.speed

    def fast(self) -> None:
        self._set(_SPEED)

    def slow(self) -> None:
        self._set(1.0)

    def _set(self, speed: float) -> None:
        self._base_virtual = self.now()
        self._base_real = self._real()
        self.speed = speed


def _run(scenario: Callable[[_Clock], Any]) -> Any:
    loop = asyncio.new_event_loop()
    clock = _Clock(loop)
    monotonic = time.monotonic
    time.monotonic = clock.now
    try:
        return loop.run_until_complete(scenario(clock))
    finally:
        time.monotonic = monotonic
        pending = [task for task in asyncio.all_tasks(loop) if not task.done()]
        for task in pending:
            task.cancel()
        if pending:
            loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
        loop.run_until_complete(loop.shutdown_asyncgens())
        loop.close()


class _Upstream:
    """A websocket server behind a TCP relay that can stop carrying bytes."""

    def __init__(self) -> None:
        self.requests: list[str] = []
        self.request_seen = asyncio.Event()
        self._connections: list[Any] = []
        self.black_hole = False
        self._server: Any = None
        self._relay: asyncio.AbstractServer | None = None
        self._relay_tasks: set[asyncio.Task[Any]] = set()
        self.port = 0

    async def __aenter__(self) -> "_Upstream":
        async def handler(ws: Any) -> None:
            self._connections.append(ws)
            async for message in ws:
                self.requests.append(message)
                self.request_seen.set()

        self._server = await serve(handler, "127.0.0.1", 0, ping_interval=None)
        server_port = self._server.sockets[0].getsockname()[1]

        async def relay(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
            self._relay_tasks.add(asyncio.current_task())  # type: ignore[arg-type]
            up_reader, up_writer = await asyncio.open_connection("127.0.0.1", server_port)

            async def carry(src: asyncio.StreamReader, dst: asyncio.StreamWriter) -> None:
                while data := await src.read(65536):
                    if not self.black_hole:
                        dst.write(data)
                        await dst.drain()

            try:
                await asyncio.gather(carry(reader, up_writer), carry(up_reader, writer))
            finally:
                writer.close()
                up_writer.close()

        self._relay = await asyncio.start_server(relay, "127.0.0.1", 0)
        self.port = self._relay.sockets[0].getsockname()[1]
        return self

    async def __aexit__(self, *exc: object) -> None:
        for task in self._relay_tasks:
            task.cancel()
        assert self._relay is not None
        self._relay.close()
        self._server.close()

    @property
    def base_url(self) -> str:
        return f"http://127.0.0.1:{self.port}/backend-api"

    async def reply(self, event: dict[str, Any]) -> None:
        await self._connections[-1].send(json.dumps(event))

    async def close_cleanly(self) -> None:
        await self._connections[-1].close(1000, "done")

    async def wait_for_request(self) -> str:
        await asyncio.wait_for(self.request_seen.wait(), 30)
        self.request_seen.clear()
        return self.requests[-1]


class _LocalSession:
    """aiohttp session that dials the URL directly instead of through the route's proxy."""

    def __init__(self) -> None:
        self._session = aiohttp.ClientSession()

    def ws_connect(self, url: str, *, proxy: Any = None, **kwargs: Any) -> Any:
        del proxy
        return self._session.ws_connect(url, **kwargs)

    async def close(self) -> None:
        await self._session.close()


async def _connect(kind: str, upstream: _Upstream) -> Any:
    if kind == "direct":
        return await connect_responses_websocket(
            {"user-agent": "codex"},
            "access",
            "chatgpt_account",
            base_url=upstream.base_url,
            route=None,
            allow_direct_egress=True,
        )
    route = ResolvedUpstreamRoute(
        mode="account_bound",
        pool_id="pool_1",
        endpoint=ResolvedProxyEndpoint("ep_1", "http", "proxy.test", 8080),
    )
    return await connect_responses_websocket(
        {"user-agent": "codex"},
        "access",
        "chatgpt_account",
        base_url=upstream.base_url,
        route=route,
        codex_client=CodexClient(_LocalSession()),
    )


class _RequestLogs:
    def __init__(self) -> None:
        self.calls: list[dict[str, object]] = []

    async def add_log(self, **kwargs: object) -> None:
        self.calls.append(dict(kwargs))

    async def find_latest_owner_record_for_response_id(self, **kwargs: object) -> None:
        return None

    async def find_latest_account_id_for_response_id(self, **kwargs: object) -> None:
        return None

    async def find_latest_response_id_for_session_id(self, **kwargs: object) -> None:
        return None


class _Repos:
    def __init__(self) -> None:
        from app.modules.proxy.repo_bundle import ProxyRepositories

        capability_lineage = AsyncMock()
        capability_lineage.is_required.return_value = False
        capability_lineage.require.return_value = ("marker",)
        self.request_logs = _RequestLogs()
        self._repos = ProxyRepositories(
            accounts=cast(Any, AsyncMock()),
            usage=cast(Any, AsyncMock()),
            request_logs=cast(Any, self.request_logs),
            sticky_sessions=cast(Any, AsyncMock()),
            api_keys=cast(Any, AsyncMock()),
            additional_usage=cast(Any, AsyncMock()),
            capability_lineage=capability_lineage,
        )

    async def __aenter__(self) -> Any:
        return self._repos

    async def __aexit__(self, *exc: object) -> bool:
        return False


class _Harness:
    """A proxy service whose account penalties and upstream reconnects are recorded."""

    def __init__(self, monkeypatch: pytest.MonkeyPatch) -> None:
        repos = _Repos()
        self.service = proxy_service.ProxyService(lambda: repos)
        self.account = Account(
            id="acc-liveness",
            chatgpt_account_id="acc-liveness",
            email="liveness@example.com",
            plan_type="plus",
            access_token_encrypted=b"access",
            refresh_token_encrypted=b"refresh",
            id_token_encrypted=b"id",
            last_refresh=utcnow(),
            status=AccountStatus.ACTIVE,
            deactivation_reason=None,
        )
        self.penalties: list[tuple[str, tuple[Any, ...]]] = []
        for name in _PENALTY_METHODS:
            monkeypatch.setattr(self.service._load_balancer, name, self._recorder(name))
        self.reconnects: list[dict[str, Any]] = []

        async def reconnect(*args: Any, **kwargs: Any) -> Any:
            self.reconnects.append(kwargs)
            raise RuntimeError("no other upstream in this test")

        monkeypatch.setattr(self.service, "_reconnect_http_bridge_session", reconnect)
        monkeypatch.setattr(self.service, "_retry_http_bridge_request_on_fresh_upstream", reconnect)
        settings = Settings(http_responses_session_bridge_enabled=True)
        monkeypatch.setattr(proxy_service, "get_settings", lambda: settings)

    def _recorder(self, name: str) -> Any:
        async def record(*args: Any, **kwargs: Any) -> None:
            self.penalties.append((name, args))

        return record

    def request(self, request_id: str, *, created: bool = False) -> Any:
        state = proxy_service._WebSocketRequestState(
            request_id=request_id,
            model="gpt-5.4",
            service_tier=None,
            reasoning_effort=None,
            api_key_reservation=None,
            started_at=time.monotonic(),
            awaiting_response_created=not created,
            event_queue=asyncio.Queue(),
            request_text=json.dumps({"type": "response.create", "model": "gpt-5.4", "input": request_id}),
            transport="http",
        )
        if created:
            state.response_id = f"resp-{request_id}"
        return state

    def bridge_session(self, upstream: Any, pending: list[Any]) -> Any:
        key = proxy_service._HTTPBridgeSessionKey("session_header", "liveness", None)
        session = proxy_service._HTTPBridgeSession(
            key=key,
            headers={"x-codex-session-id": "liveness"},
            affinity=proxy_service._AffinityPolicy(key="liveness"),
            request_model="gpt-5.4",
            account=self.account,
            upstream=upstream,
            upstream_control=proxy_service._WebSocketUpstreamControl(),
            pending_requests=deque(pending),
            pending_lock=anyio.Lock(),
            response_create_gate=asyncio.Semaphore(1),
            queued_request_count=len(pending),
            last_used_at=time.monotonic(),
            idle_ttl_seconds=120.0,
        )
        self.service._http_bridge_sessions[key] = session
        return session


async def _drain(queue: asyncio.Queue[Any]) -> list[Any]:
    items: list[Any] = []
    while True:
        try:
            items.append(await asyncio.wait_for(queue.get(), 1))
        except TimeoutError:
            return items


def _event_types(items: list[Any]) -> list[str | None]:
    types: list[str | None] = []
    for item in items:
        if item is None:
            types.append(None)
            continue
        text = item.decode() if isinstance(item, bytes) else str(item)
        found = None
        for line in text.splitlines():
            if line.startswith("data:"):
                try:
                    found = json.loads(line[5:].strip()).get("type")
                except ValueError:
                    found = None
        types.append(found)
    return types


def _created(request_id: str) -> dict[str, Any]:
    return {"type": "response.created", "response": {"id": f"resp-{request_id}", "status": "in_progress"}}


def _completed(request_id: str) -> dict[str, Any]:
    return {
        "type": "response.completed",
        "response": {"id": f"resp-{request_id}", "status": "completed", "output": []},
    }


_KINDS = pytest.mark.parametrize("kind", ["direct", "routed"])
# Whether the reader is already waiting on the connection when it goes dark, or only starts
# reading after the connection has been dark for a while.
_READING = pytest.mark.parametrize("reading", ["already", "later"])


@_KINDS
def test_dead_connection_is_noticed(kind: str) -> None:
    async def scenario(clock: _Clock) -> None:
        async with _Upstream() as upstream:
            ws = await _connect(kind, upstream)
            await ws.send_text('{"type":"response.create"}')
            await upstream.wait_for_request()
            clock.fast()
            upstream.black_hole = True
            message = await asyncio.wait_for(ws.receive(), _NOTICE_WITHIN)
            assert message.kind in {"error", "close"}, message

    _run(scenario)


@_KINDS
@_READING
def test_bridge_fails_request_on_dead_connection(kind: str, reading: str, monkeypatch: pytest.MonkeyPatch) -> None:
    async def scenario(clock: _Clock) -> None:
        harness = _Harness(monkeypatch)
        async with _Upstream() as upstream:
            ws = await _connect(kind, upstream)
            request = harness.request("dead-bridge")
            await ws.send_text(request.request_text)
            await upstream.wait_for_request()
            session = harness.bridge_session(ws, [request])
            clock.fast()
            upstream.black_hole = True
            if reading == "later":
                await asyncio.sleep(_NOTICE_WITHIN)
            await asyncio.wait_for(harness.service._relay_http_bridge_upstream_messages(session), _NOTICE_WITHIN)
            clock.slow()
            events = _event_types(await _drain(request.event_queue))
            upstream.black_hole = False
            assert events == ["response.failed", None], events
            assert len(upstream.requests) == 1, upstream.requests
            assert harness.reconnects == []
            assert harness.penalties == [], harness.penalties

    _run(scenario)


class _Downstream:
    """The client end of a proxied Responses websocket."""

    def __init__(self) -> None:
        self.sent: list[str] = []

    async def send_text(self, text: str) -> None:
        self.sent.append(text)

    async def send_bytes(self, data: bytes) -> None:
        self.sent.append(data.decode())

    async def close(self, code: int = 1000, reason: str | None = None) -> None:
        del code, reason


def _ws_request(request_id: str) -> Any:
    return proxy_service._WebSocketRequestState(
        request_id=request_id,
        model="gpt-5.4",
        service_tier=None,
        reasoning_effort=None,
        api_key_reservation=None,
        started_at=time.monotonic(),
        request_text=json.dumps({"type": "response.create", "model": "gpt-5.4", "input": request_id}),
        response_create_sent_at=0.0,
        awaiting_response_created=True,
    )


def _relay(harness: _Harness, downstream: _Downstream, upstream: Any, pending: deque[Any], control: Any) -> Any:
    settings = proxy_service.get_settings()
    return harness.service._relay_upstream_websocket_messages(
        cast(Any, downstream),
        upstream,
        account=harness.account,
        account_id_value=harness.account.id,
        pending_requests=pending,
        pending_lock=anyio.Lock(),
        client_send_lock=anyio.Lock(),
        api_key=None,
        upstream_control=control,
        response_create_gate=asyncio.Semaphore(1),
        proxy_request_budget_seconds=settings.proxy_request_budget_seconds,
        stream_idle_timeout_seconds=settings.stream_idle_timeout_seconds,
        downstream_activity=proxy_service._DownstreamWebSocketActivity(),
    )


def _client_events(downstream: _Downstream) -> list[str | None]:
    """Response events the client saw, without the proxy's own keepalive frames."""
    events: list[str | None] = []
    for frame in downstream.sent:
        try:
            event_type = json.loads(frame).get("type")
        except ValueError:
            event_type = None
        if event_type != "codex.keepalive":
            events.append(event_type)
    return events


async def _wait_for_sent(downstream: _Downstream, event_type: str, within: float) -> None:
    deadline = asyncio.get_running_loop().time() + within
    while event_type not in _client_events(downstream):
        if asyncio.get_running_loop().time() > deadline:
            return
        await asyncio.sleep(0.05)


@_KINDS
@_READING
def test_websocket_relay_fails_request_on_dead_connection(kind: str, reading: str, monkeypatch: pytest.MonkeyPatch) -> None:
    async def scenario(clock: _Clock) -> None:
        harness = _Harness(monkeypatch)
        async with _Upstream() as upstream:
            ws = await _connect(kind, upstream)
            request = _ws_request("dead-relay")
            await ws.send_text(request.request_text)
            await upstream.wait_for_request()
            downstream = _Downstream()
            control = proxy_service._WebSocketUpstreamControl()
            clock.fast()
            upstream.black_hole = True
            if reading == "later":
                await asyncio.sleep(_NOTICE_WITHIN)
            await asyncio.wait_for(_relay(harness, downstream, ws, deque([request]), control), _NOTICE_WITHIN)
            clock.slow()
            await _wait_for_sent(downstream, "response.failed", 5)
            upstream.black_hole = False
            assert _client_events(downstream) == ["response.failed"], downstream.sent
            assert control.replay_request_state is None
            assert len(upstream.requests) == 1, upstream.requests
            assert harness.penalties == [], harness.penalties

    _run(scenario)


@_KINDS
def test_websocket_relay_keeps_quiet_turn(kind: str, monkeypatch: pytest.MonkeyPatch) -> None:
    async def scenario(clock: _Clock) -> None:
        harness = _Harness(monkeypatch)
        async with _Upstream() as upstream:
            ws = await _connect(kind, upstream)
            request = _ws_request("quiet-relay")
            await ws.send_text(request.request_text)
            await upstream.wait_for_request()
            downstream = _Downstream()
            control = proxy_service._WebSocketUpstreamControl()
            relay = asyncio.ensure_future(_relay(harness, downstream, ws, deque([request]), control))
            clock.fast()
            await asyncio.sleep(_QUIET_FOR)
            await upstream.reply(_created("quiet-relay"))
            await upstream.reply(_completed("quiet-relay"))
            await _wait_for_sent(downstream, "response.completed", 60)
            clock.slow()
            relay.cancel()
            await asyncio.gather(relay, return_exceptions=True)
            assert _client_events(downstream) == ["response.created", "response.completed"], downstream.sent
            assert len(upstream.requests) == 1, upstream.requests
            assert harness.penalties == [], harness.penalties

    _run(scenario)


@_KINDS
def test_bridge_keeps_quiet_turn(kind: str, monkeypatch: pytest.MonkeyPatch) -> None:
    async def scenario(clock: _Clock) -> None:
        harness = _Harness(monkeypatch)
        async with _Upstream() as upstream:
            ws = await _connect(kind, upstream)
            request = harness.request("quiet-bridge")
            await ws.send_text(request.request_text)
            await upstream.wait_for_request()
            session = harness.bridge_session(ws, [request])
            reader = asyncio.ensure_future(harness.service._relay_http_bridge_upstream_messages(session))
            clock.fast()
            await asyncio.sleep(_QUIET_FOR)
            await upstream.reply(_created("quiet-bridge"))
            await upstream.reply(_completed("quiet-bridge"))
            items: list[Any] = []
            while None not in items:
                items.append(await asyncio.wait_for(request.event_queue.get(), 60))
            clock.slow()
            reader.cancel()
            await asyncio.gather(reader, return_exceptions=True)
            events = _event_types(items)
            assert events[0] == "response.created" and events[-2:] == ["response.completed", None], events
            assert "response.failed" not in events, events
            assert len(upstream.requests) == 1, upstream.requests
            assert harness.reconnects == []
            assert harness.penalties == [], harness.penalties

    _run(scenario)


@_KINDS
def test_bridge_send_on_dead_connection_fails_each_request_once(kind: str, monkeypatch: pytest.MonkeyPatch) -> None:
    async def scenario(clock: _Clock) -> None:
        from app.core.clients.proxy import ProxyResponseError

        harness = _Harness(monkeypatch)
        service = harness.service
        async with _Upstream() as upstream:
            ws = await _connect(kind, upstream)
            earlier = harness.request("earlier", created=True)
            await ws.send_text(earlier.request_text)
            await upstream.wait_for_request()
            session = harness.bridge_session(ws, [earlier])
            later = harness.request("later")
            monkeypatch.setattr(service, "_inline_http_bridge_image_urls", AsyncMock(return_value=later.request_text))
            monkeypatch.setattr(service, "_maybe_prewarm_http_bridge_session", AsyncMock())
            monkeypatch.setattr(service, "_acquire_request_state_response_create_admission", AsyncMock())
            monkeypatch.setattr(service, "_start_request_state_api_key_reservation_heartbeat", lambda *a, **k: None)
            clock.fast()
            upstream.black_hole = True
            await asyncio.sleep(_NOTICE_WITHIN)
            with pytest.raises(ProxyResponseError):
                await asyncio.wait_for(
                    service._submit_http_bridge_request(
                        session, request_state=later, text_data=later.request_text, queue_limit=4
                    ),
                    60,
                )
            await asyncio.wait_for(service._relay_http_bridge_upstream_messages(session), 60)
            clock.slow()
            earlier_events = _event_types(await _drain(earlier.event_queue))
            later_events = _event_types(await _drain(later.event_queue))
            upstream.black_hole = False
            assert earlier_events == ["response.failed", None], earlier_events
            assert later_events in ([], ["response.failed", None]), later_events
            assert len(upstream.requests) == 1, upstream.requests
            assert harness.reconnects == []
            assert harness.penalties == [], harness.penalties
            assert session.closed is True

    _run(scenario)


# Settings fields that already exist at the starting commit.
_EXISTING_SETTINGS = {
    "auth_guardian_enabled", "automations_scheduler_enabled", "backpressure_max_concurrent_requests",
    "bulkhead_dashboard_limit", "bulkhead_proxy_limit", "circuit_breaker_enabled",
    "compact_request_budget_seconds", "conversation_archive_dir", "conversation_archive_enabled",
    "conversation_archive_queue_max_bytes", "dashboard_auth_mode", "dashboard_auth_proxy_header",
    "dashboard_bootstrap_token", "dashboard_trust_loopback_host_header_for_long_sessions", "data_dir",
    "database_alembic_auto_remap_enabled", "database_max_overflow", "database_migrate_on_startup",
    "database_migration_lock_timeout_seconds", "database_migrations_fail_fast", "database_pool_size",
    "database_sqlite_pre_migrate_backup_enabled", "database_sqlite_pre_migrate_backup_max_files",
    "database_sqlite_startup_check_mode", "database_url", "deterministic_failover_enabled",
    "encryption_key_file", "encryption_key_fingerprint_mode", "firewall_ip_cache_ttl_seconds",
    "firewall_trust_proxy_headers", "firewall_trusted_proxy_cidrs", "http_connector_limit",
    "http_connector_limit_per_host", "http_downstream_transport_policy",
    "http_responses_session_bridge_advertise_base_url",
    "http_responses_session_bridge_clean_close_retry_jitter_max_seconds",
    "http_responses_session_bridge_codex_idle_ttl_seconds",
    "http_responses_session_bridge_codex_prewarm_enabled", "http_responses_session_bridge_enabled",
    "http_responses_session_bridge_gateway_safe_mode", "http_responses_session_bridge_idle_ttl_seconds",
    "http_responses_session_bridge_instance_id", "http_responses_session_bridge_instance_ring",
    "http_responses_session_bridge_max_sessions", "http_responses_session_bridge_queue_limit",
    "http_responses_session_bridge_request_budget_seconds",
    "http_responses_session_bridge_stuck_gate_retire_after_seconds",
    "http_responses_stream_request_budget_seconds", "image_inline_allowed_hosts",
    "image_inline_fetch_enabled", "images_default_model", "leader_election_enabled",
    "leader_election_ttl_seconds", "live_usage_ingestion_enabled", "log_format",
    "max_decompressed_body_bytes", "max_decompressed_responses_body_bytes", "max_sse_event_bytes",
    "memory_reject_threshold_mb", "metrics_enabled", "metrics_port", "model_context_window_overrides",
    "model_registry_client_version", "model_registry_enabled", "model_registry_snapshot_max_age_seconds",
    "oauth_callback_host", "oauth_timeout_seconds", "openai_cache_affinity_max_age_seconds",
    "openai_prompt_cache_key_derivation_enabled", "otel_enabled", "otel_exporter_endpoint",
    "proxy_account_cap_partition_scale_down_seconds", "proxy_account_caps_scope",
    "proxy_account_inflight_penalty_pct", "proxy_account_lease_token_weight",
    "proxy_account_lease_ttl_seconds", "proxy_account_response_create_limit", "proxy_account_stream_limit",
    "proxy_account_stream_recovery_reserve", "proxy_admission_wait_timeout_seconds",
    "proxy_api_key_fair_share_congestion_threshold_pct", "proxy_compact_response_create_limit",
    "proxy_downstream_websocket_idle_timeout_seconds", "proxy_refresh_failure_cooldown_seconds",
    "proxy_request_budget_seconds", "proxy_response_create_limit", "proxy_token_refresh_limit",
    "proxy_unauthenticated_client_cidrs", "proxy_upstream_websocket_connect_limit",
    "quota_planner_scheduler_enabled", "rate_limit_reset_credits_refresh_interval_seconds",
    "request_log_retention_days", "shutdown_drain_timeout_seconds", "soft_drain_enabled",
    "sse_keepalive_interval_seconds", "sticky_session_cleanup_enabled", "stream_idle_timeout_seconds",
    "token_refresh_claim_ttl_seconds", "token_refresh_interval_days", "token_refresh_timeout_seconds",
    "trace", "transcription_request_budget_seconds", "upstream_base_url", "upstream_compact_timeout_seconds",
    "upstream_connect_timeout_seconds", "upstream_response_create_max_bytes",
    "upstream_route_cache_ttl_seconds", "upstream_stream_transport", "upstream_websocket_trust_env",
    "usage_fetch_max_retries", "usage_fetch_timeout_seconds", "usage_history_retention_days",
    "usage_refresh_auth_failure_cooldown_seconds", "usage_refresh_enabled", "usage_refresh_interval_seconds",
    "warmup_model", "workers_per_instance",
}


# Dashboard settings columns, command line options and environment variables
# that already exist at the starting commit.
_EXISTING_DASHBOARD_SETTINGS = {
    "additional_quota_routing_policies_json", "api_key_auth_enabled",
    "auto_redeem_reset_credits_before_expiry", "bootstrap_token_encrypted", "bootstrap_token_hash",
    "created_at", "dashboard_session_ttl_seconds", "guest_access_enabled", "guest_password_hash",
    "hide_upstream_quota_from_api_keys", "http_downstream_transport_policy",
    "http_responses_session_bridge_gateway_safe_mode",
    "http_responses_session_bridge_prompt_cache_idle_ttl_seconds", "id", "import_without_overwrite",
    "limit_warmup_cooldown_seconds", "limit_warmup_enabled", "limit_warmup_exhausted_threshold_percent",
    "limit_warmup_idle_threshold_percent", "limit_warmup_min_available_percent", "limit_warmup_model",
    "limit_warmup_prompt", "limit_warmup_staggered_idle_enabled", "limit_warmup_windows",
    "openai_cache_affinity_max_age_seconds", "password_hash", "prefer_earlier_reset_accounts",
    "prefer_earlier_reset_window", "prohibit_fast_mode", "proxy_account_response_create_limit",
    "proxy_account_stream_limit", "proxy_account_stream_recovery_reserve",
    "proxy_api_key_fair_share_congestion_threshold_pct", "relative_availability_power",
    "relative_availability_top_k", "request_log_retention_days", "routing_strategy",
    "show_reset_credit_badges", "show_reset_credit_expiry_badge", "single_account_id",
    "sticky_reallocation_budget_threshold_pct", "sticky_reallocation_primary_budget_threshold_pct",
    "sticky_reallocation_secondary_budget_threshold_pct", "sticky_threads_enabled",
    "totp_last_verified_step", "totp_required_on_login", "totp_secret_encrypted", "updated_at",
    "upstream_proxy_default_pool_id", "upstream_proxy_routing_enabled", "upstream_stream_transport",
    "usage_history_retention_days", "version", "warmup_model", "weekly_pace_smoothing_minutes",
    "weekly_pace_working_days",
}
_EXISTING_CLI_OPTIONS = {"command", "host", "port", "ssl_certfile", "ssl_keyfile", "timeout_keep_alive", "ws_max_size"}
_EXISTING_ENV_VARS = {
    "CODEX_HOME", "CODEX_LB_ADDITIONAL_QUOTA_REGISTRY_FILE", "CODEX_LB_CONNECT_ADDRESS", "CODEX_LB_DATA_DIR",
    "CODEX_LB_OPENAI_CACHE_AFFINITY_MAX_AGE_SECONDS", "CODEX_LB_TEST_DATABASE_URL", "FORWARDED_ALLOW_IPS",
    "HOST", "HOSTNAME", "POD_IP", "POD_NAME", "PORT", "PROMETHEUS_MULTIPROC_DIR", "REQUEST_METHOD",
    "SSL_CERTFILE", "SSL_KEYFILE", "TZ", "USERPROFILE", "UVICORN_TIMEOUT_KEEP_ALIVE", "UVICORN_WS_MAX_SIZE",
}


def _env_vars_read_by_app() -> set[str]:
    import ast
    import pathlib

    import app

    names: set[str] = set()
    for path in pathlib.Path(app.__file__).parent.rglob("*.py"):
        for node in ast.walk(ast.parse(path.read_text())):
            if (
                isinstance(node, ast.Call)
                and ast.unparse(node.func) in {"os.getenv", "os.environ.get", "getenv", "environ.get"}
                and node.args
                and isinstance(node.args[0], ast.Constant)
                and isinstance(node.args[0].value, str)
            ):
                names.add(node.args[0].value)
            if (
                isinstance(node, ast.Subscript)
                and ast.unparse(node.value) in {"os.environ", "environ"}
                and isinstance(node.slice, ast.Constant)
                and isinstance(node.slice.value, str)
            ):
                names.add(node.slice.value)
    return names


def test_no_new_config_option() -> None:
    import app.cli
    from app.db.models import DashboardSettings

    assert sorted(set(Settings.model_fields) - _EXISTING_SETTINGS) == []
    assert sorted({column.name for column in DashboardSettings.__table__.columns} - _EXISTING_DASHBOARD_SETTINGS) == []
    assert sorted(set(vars(app.cli._parse_args([]))) - _EXISTING_CLI_OPTIONS) == []
    assert sorted(_env_vars_read_by_app() - _EXISTING_ENV_VARS) == []


@_KINDS
def test_bridge_still_retries_after_clean_close(kind: str, monkeypatch: pytest.MonkeyPatch) -> None:
    async def scenario(clock: _Clock) -> None:
        harness = _Harness(monkeypatch)
        async with _Upstream() as upstream:
            ws = await _connect(kind, upstream)
            request = harness.request("clean-close-bridge")
            await ws.send_text(request.request_text)
            await upstream.wait_for_request()
            session = harness.bridge_session(ws, [request])
            reader = asyncio.ensure_future(harness.service._relay_http_bridge_upstream_messages(session))
            await upstream.close_cleanly()
            await asyncio.wait({reader}, timeout=30)
            reader.cancel()
            await asyncio.gather(reader, return_exceptions=True)
            assert len(harness.reconnects) >= 1, _event_types(await _drain(request.event_queue))

    _run(scenario)


@_KINDS
def test_websocket_relay_still_retries_after_clean_close(kind: str, monkeypatch: pytest.MonkeyPatch) -> None:
    async def scenario(clock: _Clock) -> None:
        harness = _Harness(monkeypatch)
        async with _Upstream() as upstream:
            ws = await _connect(kind, upstream)
            request = _ws_request("clean-close-relay")
            await ws.send_text(request.request_text)
            await upstream.wait_for_request()
            downstream = _Downstream()
            control = proxy_service._WebSocketUpstreamControl()
            relay = asyncio.ensure_future(_relay(harness, downstream, ws, deque([request]), control))
            await upstream.close_cleanly()
            await asyncio.wait_for(relay, 30)
            assert control.replay_request_state is request, _client_events(downstream)
            assert "response.failed" not in _client_events(downstream)

    _run(scenario)


class _ClientSocket:
    """The client side of a proxied Responses websocket, fed one message at a time."""

    def __init__(self) -> None:
        self.incoming: asyncio.Queue[dict[str, Any]] = asyncio.Queue()
        self.sent: list[str] = []

    def say(self, text: str) -> None:
        self.incoming.put_nowait({"type": "websocket.receive", "text": text})

    def hang_up(self) -> None:
        self.incoming.put_nowait({"type": "websocket.disconnect"})

    async def receive(self) -> dict[str, Any]:
        return await self.incoming.get()

    async def send_text(self, text: str) -> None:
        self.sent.append(text)

    async def send_bytes(self, data: bytes) -> None:
        self.sent.append(data.decode())

    async def close(self, code: int = 1000, reason: str | None = None) -> None:
        del code, reason


class _DashboardAndAppSettings:
    def __init__(self) -> None:
        self._app = Settings()
        self._dashboard = SimpleNamespace(
            prefer_earlier_reset_accounts=False,
            prefer_earlier_reset_window="secondary",
            sticky_threads_enabled=False,
            sticky_reallocation_budget_threshold_pct=95.0,
            upstream_stream_transport="default",
            routing_strategy="usage_weighted",
            http_downstream_transport_policy="smart",
        )

    def __getattr__(self, name: str) -> Any:
        if hasattr(self._dashboard, name):
            return getattr(self._dashboard, name)
        return getattr(self._app, name)

    async def get(self) -> Any:
        return self


def _turn(text: str) -> str:
    return json.dumps({"type": "response.create", "model": "gpt-5.4", "instructions": "", "input": text, "stream": True})


@_KINDS
def test_websocket_next_turn_after_connection_went_dead_while_idle(kind: str, monkeypatch: pytest.MonkeyPatch) -> None:
    async def scenario(clock: _Clock) -> None:
        harness = _Harness(monkeypatch)
        settings = _DashboardAndAppSettings()
        monkeypatch.setattr(proxy_service, "get_settings", lambda: settings)
        monkeypatch.setattr(proxy_service, "get_settings_cache", lambda: settings)
        async with _Upstream() as first_upstream, _Upstream() as fresh_upstream:
            upstreams = [first_upstream, fresh_upstream]
            connections: list[Any] = []

            async def connect(self: Any, *args: Any, **kwargs: Any) -> Any:
                connections.append(await _connect(kind, upstreams[min(len(connections), 1)]))
                return harness.account, connections[-1]

            monkeypatch.setattr(proxy_service.ProxyService, "_connect_proxy_websocket", connect)
            client = _ClientSocket()
            client.say(_turn("first"))
            handler = asyncio.ensure_future(
                harness.service.proxy_responses_websocket(
                    cast(Any, client),
                    {"session_id": "liveness"},
                    codex_session_affinity=False,
                    openai_cache_affinity=False,
                    api_key=None,
                )
            )
            await first_upstream.wait_for_request()
            await first_upstream.reply(_created("first"))
            await first_upstream.reply(_completed("first"))
            await _wait_for_sent(cast(Any, client), "response.completed", 10)
            clock.fast()
            first_upstream.black_hole = True
            await asyncio.sleep(_CLIENT_PAUSE)
            client.say(_turn("second"))
            deadline = asyncio.get_running_loop().time() + _NOTICE_WITHIN
            answered = False
            while asyncio.get_running_loop().time() < deadline:
                if _client_events(cast(Any, client))[2:]:
                    break
                if fresh_upstream.requests and not answered:
                    answered = True
                    await fresh_upstream.reply(_created("second"))
                    await fresh_upstream.reply(_completed("second"))
                await asyncio.sleep(0.5)
            await _wait_for_sent(cast(Any, client), "response.completed" if answered else "response.failed", 5)
            clock.slow()
            client.hang_up()
            await asyncio.wait({handler}, timeout=10)
            first_upstream.black_hole = False
            second_turn = _client_events(cast(Any, client))[2:]
            assert second_turn in (["response.failed"], ["response.created", "response.completed"]), client.sent
            assert len(first_upstream.requests) == 1, first_upstream.requests
            assert len(fresh_upstream.requests) == (1 if answered else 0), fresh_upstream.requests
            assert harness.penalties == [], harness.penalties

    _run(scenario)
