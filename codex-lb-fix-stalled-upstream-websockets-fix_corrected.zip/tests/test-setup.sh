#!/usr/bin/env bash
# test-setup.sh: sourced (not executed) before the verifier runs.
#
# The verifier runs the proxy's upstream connect path, HTTP bridge and
# websocket relay in-process against a websocket server it starts on
# 127.0.0.1. No outside network, no services, no running proxy. It only needs
# the repo package and its dependency closure importable under the repo venv
# (/opt/venv), which the image already baked at the base commit, so this is
# normally an offline no-op.
#
# Tries the offline install first and logs a second, online attempt if that
# fails, in case the baked environment is ever stale.
set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/codex-lb}"
export REPO_DIR
cd "$REPO_DIR"

export UV_OFFLINE=1

LOG=/tmp/test-setup-install.log
IMPORT_CHECK="import aiohttp, anyio, websockets.asyncio.server; from app.core.clients.proxy_websocket import connect_responses_websocket; from app.modules.proxy import service"
# The image installs the project editable into /opt/venv and keeps its build
# backend in /opt/cache/uv, not in the per-user UV_CACHE_DIR, so a sync is
# only attempted when the baked venv cannot import the code under test.
if uv run --no-sync python -c "$IMPORT_CHECK" > "$LOG" 2>&1; then
    echo "test-setup.sh: baked environment imports cleanly."
elif UV_CACHE_DIR=/opt/cache/uv uv sync --frozen --offline >> "$LOG" 2>&1; then
    echo "test-setup.sh: dependency closure satisfied offline from the image."
elif UV_OFFLINE=0 uv sync --frozen >> "$LOG" 2>&1; then
    echo "test-setup.sh: deps installed online (image bake was stale)."
else
    echo "test-setup.sh: dependency bring-up failed; last 40 log lines:" >&2
    tail -40 "$LOG" >&2
    exit 1
fi

# Fail fast if the module under test and its transport deps cannot be imported.
uv run --no-sync python -c "$IMPORT_CHECK"

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR"
