"""Exercise replay preparation, execution, and reload through the Gateway HTTP API.

Each test starts the production FastAPI lifespan with isolated SQLite storage
and the real lead-agent factory. A deterministic chat model records the prompt
and context it receives. Date and memory sources are controlled locally; no
external model or service is contacted.
"""

from __future__ import annotations

import sys
from datetime import datetime
from types import SimpleNamespace
from unittest.mock import MagicMock
from uuid import uuid4

import pytest

# Match the repository test bootstrap for its executor import cycle.
sys.path.insert(0, "/repo/deer-flow/backend")
if "deerflow.subagents.executor" not in sys.modules:
    stub = MagicMock()
    stub.SubagentExecutor = MagicMock
    stub.SubagentResult = MagicMock
    stub.SubagentStatus = MagicMock
    stub.MAX_CONCURRENT_SUBAGENTS = 3
    sys.modules["deerflow.subagents.executor"] = stub

# ruff: noqa: E402
from fastapi.testclient import TestClient
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, HumanMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from pydantic import Field


def _text(message):
    content = message.content if hasattr(message, "content") else message["content"]
    if isinstance(content, str):
        return content
    return "".join(
        block.get("text", "") for block in content if isinstance(block, dict)
    )


class RecordingModel(BaseChatModel):
    calls: list = Field(default_factory=list)

    @property
    def _llm_type(self):
        return "replay-test"

    def bind_tools(self, tools, **kwargs):
        return self

    def _generate(self, messages, stop=None, run_manager=None, **kwargs):
        self.calls.append(list(messages))
        human = next(
            m
            for m in reversed(messages)
            if isinstance(m, HumanMessage)
            and not m.additional_kwargs.get("hide_from_ui")
        )
        return ChatResult(
            generations=[
                ChatGeneration(
                    message=AIMessage(
                        content="answer: "
                        + _text(human)
                        .removeprefix("--- BEGIN USER INPUT ---\n")
                        .removesuffix("\n--- END USER INPUT ---"),
                        id=str(uuid4()),
                    )
                )
            ]
        )

    async def _agenerate(self, messages, stop=None, run_manager=None, **kwargs):
        return self._generate(messages, stop, run_manager, **kwargs)


@pytest.fixture(params=["full", "delta"])
def gateway(request, tmp_path, monkeypatch):
    mode = request.param
    home = tmp_path / "home"
    home.mkdir()
    config_path = tmp_path / "config.yaml"
    config_path.write_text(f"""models:
  - name: replay-test
    use: langchain_openai:ChatOpenAI
    model: replay-test
    api_key: unused
sandbox:
  use: deerflow.sandbox.local:LocalSandboxProvider
title:
  enabled: false
memory:
  enabled: false
  injection_enabled: true
  backend_config:
    token_counting: char
database:
  backend: sqlite
  sqlite_dir: {tmp_path / "db"}
  checkpoint_channel_mode: {mode}
run_events:
  backend: memory
""")
    extensions = tmp_path / "extensions.json"
    extensions.write_text('{"mcpServers": {}, "skills": {}}')
    for key, value in {
        "DEER_FLOW_HOME": str(home),
        "DEER_FLOW_CONFIG_PATH": str(config_path),
        "DEER_FLOW_EXTENSIONS_CONFIG_PATH": str(extensions),
        "DEER_FLOW_AUTH_DISABLED": "1",
        "DEER_FLOW_ENV": "test",
        "ENVIRONMENT": "test",
        "GATEWAY_WORKERS": "1",
    }.items():
        monkeypatch.setenv(key, value)
    from app.gateway import deps, services
    from deerflow.config import app_config, extensions_config, paths
    from deerflow.persistence import engine
    from deerflow.runtime import checkpoint_mode
    from deerflow.agents import thread_state

    for module, attr, value in (
        (app_config, "_app_config", None),
        (app_config, "_app_config_path", None),
        (app_config, "_app_config_mtime", None),
        (app_config, "_app_config_is_custom", False),
        (extensions_config, "_extensions_config", None),
        (paths, "_paths_singleton", None),
        (paths, "_paths", None),
        (engine, "_engine", None),
        (engine, "_session_factory", None),
        (deps, "_cached_local_provider", None),
        (deps, "_cached_repo", None),
        (checkpoint_mode, "_frozen_checkpoint_channel_mode", None),
        (thread_state, "_frozen_delta_snapshot_frequency", None),
    ):
        monkeypatch.setattr(module, attr, value, raising=False)
    services._state_accessor_graph_cache.clear()
    model = RecordingModel()
    clock = SimpleNamespace(value=datetime(2026, 5, 8, 12))

    class Clock:
        @staticmethod
        def now():
            return clock.value

    monkeypatch.setattr(
        "deerflow.agents.lead_agent.agent.create_chat_model",
        lambda *args, **kwargs: model,
    )
    monkeypatch.setattr(
        "deerflow.agents.lead_agent.prompt._get_memory_context",
        lambda *args, **kwargs: "<memory>Use short answers.</memory>",
    )
    monkeypatch.setattr(
        "deerflow.agents.middlewares.dynamic_context_middleware.datetime", Clock
    )
    from app.gateway.app import create_app

    app = create_app()
    with TestClient(app) as client:
        created = client.post("/api/threads", json={})
        assert created.status_code == 200, created.text
        yield SimpleNamespace(
            client=client,
            app=app,
            thread=created.json()["thread_id"],
            model=model,
            clock=clock,
            mode=mode,
        )


def _post(gateway, path, body):
    response = gateway.client.post(f"/api/threads/{gateway.thread}/{path}", json=body)
    assert response.status_code == 200, response.text
    return response.json()


def _run(gateway, text=None, message_id="human-1", prepared=None):
    body = {
        "assistant_id": "lead_agent",
        "input": {"messages": [{"type": "human", "content": text, "id": message_id}]},
        "context": {
            "thinking_enabled": False,
            "is_plan_mode": False,
            "subagent_enabled": False,
        },
    }
    if prepared is not None:
        body.update({key: prepared[key] for key in ("input", "checkpoint", "metadata")})
    return _post(gateway, "runs/wait", body)


def _state(gateway):
    response = gateway.client.get(f"/api/threads/{gateway.thread}/state")
    assert response.status_code == 200, response.text
    return response.json()["values"]["messages"]


def _visible(messages, kind):
    return [
        m
        for m in messages
        if m["type"] == kind and not m.get("additional_kwargs", {}).get("hide_from_ui")
    ]


def _prepare(gateway, operation, messages):
    if operation == "edit":
        return _post(
            gateway,
            "runs/edit-regenerate/prepare",
            {
                "human_message_id": _visible(messages, "human")[-1]["id"],
                "replacement_text": "edited question",
            },
        )
    return _post(
        gateway,
        "runs/regenerate/prepare",
        {"message_id": _visible(messages, "ai")[-1]["id"]},
    )


@pytest.mark.parametrize("operation", ["edit", "regenerate"])
@pytest.mark.parametrize("later", [False, True], ids=["first", "later"])
def test_replay_persists_intended_turn_and_context(gateway, operation, later):
    _run(gateway, "first question")
    earlier = _state(gateway) if later else []
    if later:
        _run(gateway, "later question", "human-2")
    messages = _state(gateway)
    prepared = _prepare(gateway, operation, messages)
    if operation == "regenerate" and not later:
        assert prepared["input"]["messages"][0]["id"] == "human-1"
    gateway.clock.value = datetime(2026, 5, 9, 12)
    expected = (
        "edited question"
        if operation == "edit"
        else ("later question" if later else "first question")
    )
    _run(gateway, prepared=prepared)
    saved = _state(gateway)
    assert [_text(m) for m in _visible(saved, "human")] == (
        ["first question"] if later else []
    ) + [expected]
    answers = _visible(saved, "ai")
    assert len(answers) == (2 if later else 1)
    assert _text(answers[-1]) == "answer: " + expected
    assert saved[: len(earlier)] == earlier
    model_messages = gateway.model.calls[-1]
    assert any("2026-05-09" in _text(m) for m in model_messages)
    assert any(
        "<memory>Use short answers.</memory>" in _text(m) for m in model_messages
    )


@pytest.mark.parametrize(
    "message_id,swapped",
    [("plain-user", False), ("contains__user_middle", False), ("human-1", True)],
)
def test_regenerate_message_identity(gateway, message_id, swapped):
    if not swapped:
        _run(gateway, "first question", "seed-user")
    _run(gateway, "target question", message_id)
    messages = _state(gateway)
    expected_persisted = message_id + "__user" if swapped else message_id
    assert _visible(messages, "human")[-1]["id"] == expected_persisted
    prepared = _prepare(gateway, "regenerate", messages)
    assert prepared["input"]["messages"][0]["id"] == message_id


def _sql(gateway, statements):
    """Apply a historical storage fixture in the test's isolated SQLite DB."""

    async def update():
        conn = gateway.app.state.checkpointer.conn
        for query, params in statements:
            await conn.execute(query, params)
        await conn.commit()

    gateway.client.portal.call(update)


@pytest.mark.parametrize("gateway", ["full"], indirect=True)
@pytest.mark.parametrize("operation", ["edit", "regenerate"])
def test_pending_only_history_reports_http_error(gateway, operation):
    _run(gateway, "first question")
    history = _post(gateway, "history", {"limit": 100})

    # History responses omit messages on older entries. Inspect the stored
    # full snapshots to retain a pending answer and a pending user input.
    async def select_pending():
        cp = gateway.app.state.checkpointer
        head = parent = None
        for item in history:
            if not item["next"]:
                continue
            raw = await cp.aget_tuple(
                {
                    "configurable": {
                        "thread_id": gateway.thread,
                        "checkpoint_ns": "",
                        "checkpoint_id": item["checkpoint_id"],
                    }
                }
            )
            messages = raw.checkpoint["channel_values"].get("messages", [])
            if head is None and any(isinstance(m, AIMessage) for m in messages):
                head = item
            if parent is None and any(
                isinstance(m, HumanMessage) and m.id == "human-1" for m in messages
            ):
                parent = item
        assert head is not None and parent is not None
        return head, parent

    head, parent = gateway.client.portal.call(select_pending)
    _sql(
        gateway,
        [
            ("DELETE FROM writes WHERE thread_id = ?", (gateway.thread,)),
            (
                "DELETE FROM checkpoints WHERE thread_id = ? AND checkpoint_id NOT IN (?, ?)",
                (gateway.thread, head["checkpoint_id"], parent["checkpoint_id"]),
            ),
            (
                "UPDATE checkpoints SET parent_checkpoint_id = ? WHERE thread_id = ? AND checkpoint_id = ?",
                (parent["checkpoint_id"], gateway.thread, head["checkpoint_id"]),
            ),
            (
                "UPDATE checkpoints SET parent_checkpoint_id = NULL WHERE thread_id = ? AND checkpoint_id = ?",
                (gateway.thread, parent["checkpoint_id"]),
            ),
        ],
    )

    async def stored_rows():
        conn = gateway.app.state.checkpointer.conn
        async with conn.execute(
            "SELECT * FROM checkpoints WHERE thread_id = ? ORDER BY checkpoint_id",
            (gateway.thread,),
        ) as cursor:
            return await cursor.fetchall()

    remaining = gateway.client.portal.call(stored_rows)
    assert len(remaining) == 2
    state = gateway.client.get(f"/api/threads/{gateway.thread}/state")
    assert state.status_code == 200 and state.json()["next"], state.text
    messages = _state(gateway)
    if operation == "edit":
        path = "runs/edit-regenerate/prepare"
        body = {
            "human_message_id": _visible(messages, "human")[-1]["id"],
            "replacement_text": "edited question",
        }
    else:
        path = "runs/regenerate/prepare"
        body = {"message_id": _visible(messages, "ai")[-1]["id"]}
    response = gateway.client.post(f"/api/threads/{gateway.thread}/{path}", json=body)
    assert response.status_code == 409, response.text
    assert response.json().get("detail")
    assert gateway.client.portal.call(stored_rows) == remaining


@pytest.mark.parametrize("gateway", ["full"], indirect=True)
@pytest.mark.parametrize("operation", ["edit", "regenerate"])
def test_legacy_first_turn_replay(gateway, operation):
    _run(gateway, "first question")
    _sql(
        gateway,
        [
            (
                "UPDATE checkpoints SET parent_checkpoint_id = NULL WHERE thread_id = ?",
                (gateway.thread,),
            )
        ],
    )
    history = _post(gateway, "history", {"limit": 100})
    assert all(item["parent_checkpoint_id"] is None for item in history)
    prepared = _prepare(gateway, operation, _state(gateway))
    if operation == "regenerate":
        assert prepared["input"]["messages"][0]["id"] == "human-1"
    gateway.clock.value = datetime(2026, 5, 9, 12)
    _run(gateway, prepared=prepared)
    expected = "edited question" if operation == "edit" else "first question"
    saved = _state(gateway)
    assert [_text(m) for m in _visible(saved, "human")] == [expected]
    assert [_text(m) for m in _visible(saved, "ai")] == ["answer: " + expected]
    assert any("2026-05-09" in _text(m) for m in gateway.model.calls[-1])
    assert any(
        "<memory>Use short answers.</memory>" in _text(m)
        for m in gateway.model.calls[-1]
    )


@pytest.mark.parametrize("gateway", ["full"], indirect=True)
@pytest.mark.parametrize("operation", ["edit", "regenerate"])
def test_degraded_history_still_prepares_replay(gateway, operation, monkeypatch):
    _run(gateway, "first question")
    _run(gateway, "later question", "human-2")
    messages = _state(gateway)

    def unavailable_model(*args, **kwargs):
        raise RuntimeError("test model unavailable")

    from app.gateway import services

    services._state_accessor_graph_cache.clear()
    monkeypatch.setattr(
        "deerflow.agents.lead_agent.agent.create_chat_model", unavailable_model
    )
    prepared = _prepare(gateway, operation, messages)
    expected = "edited question" if operation == "edit" else "later question"
    assert _text(prepared["input"]["messages"][0]) == expected
    assert prepared["checkpoint"]["checkpoint_id"]


@pytest.mark.parametrize("operation", ["edit", "regenerate"])
def test_replay_stays_on_active_branch(gateway, operation):
    _run(gateway, "first question")
    base = {
        "checkpoint_id": gateway.client.get(
            f"/api/threads/{gateway.thread}/state"
        ).json()["checkpoint"]["id"],
        "checkpoint_ns": "",
    }
    _run(gateway, "old target question", "target-user")
    _run(
        gateway,
        prepared={
            "input": {
                "messages": [
                    {"type": "human", "id": "branch-user", "content": "branch context"}
                ]
            },
            "checkpoint": base,
            "metadata": {},
        },
    )
    _run(gateway, "active target question", "target-user")
    messages = _state(gateway)
    prefix = _visible(messages, "human")[:-1]
    assert [_text(m) for m in prefix] == ["first question", "branch context"]
    prepared = _prepare(gateway, operation, messages)
    _run(gateway, prepared=prepared)
    expected = "edited question" if operation == "edit" else "active target question"
    saved = _state(gateway)
    assert [_text(m) for m in _visible(saved, "human")] == [
        "first question",
        "branch context",
        expected,
    ]
    assert _text(_visible(saved, "ai")[-1]) == "answer: " + expected
