## Task

In a new chat thread, send a message, wait for the answer, then edit that
message and rerun it. The edited text appears in the bubble, but the assistant
answers the original prompt. Reloading the thread brings the original text
back. Editing the latest turn of a longer conversation works.

Fix first-turn edit-and-rerun and plain regenerate so the assistant receives
the intended prompt and the saved conversation matches the rerun. Preserve
the normal date and memory context, earlier turns, and existing support for
legacy histories. If there is no usable replay history, report that instead
of rerunning the wrong turn.
