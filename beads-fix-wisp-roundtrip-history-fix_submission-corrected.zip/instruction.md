## Task

We run our bead store with versioned history turned on, and beads that make a trip through the wisps table come back with the wrong recording state. The trip is an ordinary one: someone flags a bead as ephemeral, which moves it into the wisps table, and later it's made persistent with `bd update --persistent` or promoted back to the issues table.

Beads from before we turned history on don't have any versions, and they're meant to keep it that way. Once one of them has made that trip, it starts recording: it gets a version when it lands back in the issues table and another for every edit after that. One of them can go either way: one we moved into the wisps table while history was still off and only bring back after it's turned on. That one may stay silent or start recording when it lands, as long as its later edits do the same.

Beads that were already being versioned before the trip still get new versions. But if the store's epoch was bumped while one sat in the wisps table, it returns carrying the new epoch as its participation generation instead of the one it had.

Only the trip does this. We see it on the embedded store and on a Dolt server backend, through any of the store's calls that move a bead into the wisps table. Beads that stay in the issues table behave, and one that was born ephemeral starts recording the first time it lands in the issues table, even if it was born back when history was still off.

When the history flag is off, the store has to keep writing exactly what it writes today.

Find out what the trip is doing to the recording state and put it right.
