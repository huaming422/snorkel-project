#!/usr/bin/env bash
# All Go dependencies and the compiled test tree are baked into the image
# (blocks 5 and 7). Every later phase runs offline (GOPROXY=off), so nothing
# is fetched here.
set -euo pipefail
echo "[test-setup] no-op for beads-fix-wisp-roundtrip-history"
