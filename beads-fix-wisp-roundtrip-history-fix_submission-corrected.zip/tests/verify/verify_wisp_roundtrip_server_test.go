package dolt

// Round trips of a bead off the main plane and back on the server-backed
// store, where UpdateIssue with the "wisp" field moves a bead to the wisps
// table itself. Read through ListVersions and, where a case says so, the
// participation_generation columns the repository's own fixtures read.
//
// The package's TestMain starts a local Dolt sql-server from the dolt CLI on
// PATH (BEADS_TEST_DOLT_SERVER=local). Every case first checks that the server
// is up, so a missing CLI fails the case instead of skipping it. Every helper
// here carries the wrtvs prefix.

import (
	"context"
	"database/sql"
	"fmt"
	"os/exec"
	"testing"

	"github.com/steveyegge/beads/internal/storage"
	"github.com/steveyegge/beads/internal/storage/historyoffequiv"
	"github.com/steveyegge/beads/internal/types"
	publicops "github.com/steveyegge/beads/issueops"
)

// wrtvsRequireServer fails the case when the test Dolt server is missing.
func wrtvsRequireServer(t *testing.T) {
	t.Helper()
	if _, err := exec.LookPath("dolt"); err != nil {
		t.Fatalf("no dolt CLI on PATH: these cases run against a local Dolt sql-server (%v)", err)
	}
	if testServerPort == 0 {
		t.Fatal("the package's test Dolt server is not running")
	}
}

type wrtvsEnv struct {
	store *DoltStore
	cfg   storage.VersionedHistoryConfigurer
	ctx   context.Context
}

func wrtvsSetup(t *testing.T) *wrtvsEnv {
	t.Helper()
	wrtvsRequireServer(t)
	store, cleanup := setupTestStore(t)
	t.Cleanup(cleanup)
	ctx, cancel := testContext(t)
	t.Cleanup(cancel)
	cfg, ok := any(store).(storage.VersionedHistoryConfigurer)
	if !ok {
		t.Fatalf("%T does not implement storage.VersionedHistoryConfigurer", store)
	}
	t.Cleanup(func() { cfg.SetVersionedHistoryEnabled(false) })
	return &wrtvsEnv{store: store, cfg: cfg, ctx: ctx}
}

func (e *wrtvsEnv) create(t *testing.T, id string) {
	t.Helper()
	if err := e.store.CreateIssue(e.ctx, &types.Issue{
		ID: id, Title: "t-" + id, IssueType: types.TypeTask, Status: types.StatusOpen,
	}, "actor"); err != nil {
		t.Fatalf("CreateIssue(%s): %v", id, err)
	}
}

func (e *wrtvsEnv) edit(t *testing.T, id, title string) {
	t.Helper()
	if err := e.store.UpdateIssue(e.ctx, id, map[string]any{"title": title}, "actor"); err != nil {
		t.Fatalf("UpdateIssue(%s, title=%q): %v", id, title, err)
	}
}

// markEphemeral is UpdateIssue with the "wisp" field set, the storage call
// that moves a bead to the wisps table on this store.
func (e *wrtvsEnv) markEphemeral(t *testing.T, id string) {
	t.Helper()
	if err := e.store.UpdateIssue(e.ctx, id, map[string]any{"wisp": true}, "actor"); err != nil {
		t.Fatalf("UpdateIssue(%s, wisp=true): %v", id, err)
	}
	var rows int
	if err := e.store.db.QueryRowContext(e.ctx, `SELECT COUNT(*) FROM wisps WHERE id = ?`, id).Scan(&rows); err != nil {
		t.Fatalf("reading the wisps table for %s: %v", id, err)
	}
	if rows == 0 {
		t.Fatalf("%s is not in the wisps table after it was marked ephemeral", id)
	}
}

func (e *wrtvsEnv) count(t *testing.T, id string) int {
	t.Helper()
	versions, err := any(e.store).(storage.VersionLister).ListVersions(e.ctx, id)
	if err != nil {
		t.Fatalf("ListVersions(%s): %v", id, err)
	}
	return len(versions)
}

// generation reads participation_generation of id in table (NULL -> nil).
func (e *wrtvsEnv) generation(t *testing.T, table, id string) *int64 {
	t.Helper()
	var gen sql.NullInt64
	if err := e.store.db.QueryRowContext(e.ctx,
		`SELECT participation_generation FROM `+table+` WHERE id = ?`, id).Scan(&gen); err != nil {
		t.Fatalf("reading %s.participation_generation for %s: %v", table, id, err)
	}
	if !gen.Valid {
		return nil
	}
	return &gen.Int64
}

var wrtvsArrivals = []struct {
	name   string
	arrive func(t *testing.T, e *wrtvsEnv, id string)
}{
	{"persistence_move", func(t *testing.T, e *wrtvsEnv, id string) {
		t.Helper()
		ops, err := NewIssueOperations(e.store)
		if err != nil {
			t.Fatalf("NewIssueOperations: %v", err)
		}
		result, err := ops.Update(e.ctx, publicops.UpdateRequest{Actor: "actor", IssueID: id, Patch: publicops.IssuePatch{
			Persistence: publicops.Field[publicops.PersistenceMode]{Set: true, Value: publicops.PersistenceModePersistent},
		}})
		if err != nil {
			t.Fatalf("persistence move of %s back to persistent: %v", id, err)
		}
		if !result.Changed {
			t.Fatalf("persistence move of %s back to persistent reported no change", id)
		}
	}},
	{"promote", func(t *testing.T, e *wrtvsEnv, id string) {
		t.Helper()
		if err := e.store.PromoteFromEphemeral(e.ctx, id, "actor"); err != nil {
			t.Fatalf("PromoteFromEphemeral(%s): %v", id, err)
		}
	}},
}

// A bead created before history was on, marked ephemeral through UpdateIssue
// and brought back, records nothing on arrival or after an edit.
func TestVerifyServerLegacyStaysLegacy(t *testing.T) {
	for _, a := range wrtvsArrivals {
		t.Run(a.name, func(t *testing.T) {
			e := wrtvsSetup(t)
			id := "test-wrtvs-silent-" + a.name

			e.cfg.SetVersionedHistoryEnabled(false)
			e.create(t, id)
			e.cfg.SetVersionedHistoryEnabled(true)
			e.edit(t, id, "silent-before")
			if got := e.count(t, id); got != 0 {
				t.Fatalf("version count for %s = %d after an edit before the round trip, want 0: the bead was created with history off", id, got)
			}

			e.markEphemeral(t, id)
			a.arrive(t, e, id)
			if got := e.count(t, id); got != 0 {
				t.Errorf("version count for %s = %d after the round trip (%s), want 0: a bead that was not recording stays silent", id, got, a.name)
			}
			e.edit(t, id, "silent-after")
			if got := e.count(t, id); got != 0 {
				t.Errorf("version count for %s = %d after an edit following the round trip (%s), want 0", id, got, a.name)
			}
		})
	}
}

// A recording bead marked ephemeral through UpdateIssue, with the epoch
// bumped meanwhile, comes back with the participation generation it had,
// gains one version on arrival and one more per edit.
func TestVerifyServerRecordingKeepsRecording(t *testing.T) {
	for _, a := range wrtvsArrivals {
		t.Run(a.name, func(t *testing.T) {
			e := wrtvsSetup(t)
			id := "test-wrtvs-recording-" + a.name

			e.cfg.SetVersionedHistoryEnabled(true)
			e.create(t, id)
			before := e.generation(t, "issues", id)
			if before == nil {
				t.Fatalf("participation_generation for %s is NULL right after a create with history on", id)
			}
			beforeCount := e.count(t, id)

			e.markEphemeral(t, id)
			if _, err := e.store.BumpEpoch(e.ctx, "verify-store", "while ephemeral"); err != nil {
				t.Fatalf("BumpEpoch: %v", err)
			}
			a.arrive(t, e, id)

			if after := e.generation(t, "issues", id); after == nil {
				t.Errorf("participation_generation for %s is NULL after the round trip (%s), want %d", id, a.name, *before)
			} else if *after != *before {
				t.Errorf("participation_generation for %s = %d after the round trip (%s), want %d: the bead keeps the generation it had before it went ephemeral", id, *after, a.name, *before)
			}
			arrived := e.count(t, id)
			if arrived != beforeCount+1 {
				t.Errorf("version count for %s went from %d to %d across the round trip (%s), want exactly +1", id, beforeCount, arrived, a.name)
			}
			e.edit(t, id, "recording-after")
			if got := e.count(t, id); got != arrived+1 {
				t.Errorf("version count for %s went from %d to %d across an edit after the round trip (%s), want exactly +1", id, arrived, got, a.name)
			}
		})
	}
}

// Three recording beads created at different epochs, so with three different
// participation generations, are marked ephemeral through UpdateIssue, the
// epoch is bumped, and they come back in another order than they left in.
// Each comes back with its own generation, gains one version on arrival and
// one more per edit.
func TestVerifyServerRecordingBeadsKeepTheirOwnGenerations(t *testing.T) {
	for _, a := range wrtvsArrivals {
		t.Run(a.name, func(t *testing.T) {
			e := wrtvsSetup(t)
			e.cfg.SetVersionedHistoryEnabled(true)

			var ids []string
			gens := map[string]int64{}
			for n, bumps := range []int{0, 1, 2} {
				for b := 0; b < bumps; b++ {
					if _, err := e.store.BumpEpoch(e.ctx, "verify-store", fmt.Sprintf("before bead %d", n)); err != nil {
						t.Fatalf("BumpEpoch: %v", err)
					}
				}
				id := fmt.Sprintf("test-wrtvs-gen%d-%s", n, a.name)
				e.create(t, id)
				gen := e.generation(t, "issues", id)
				if gen == nil {
					t.Fatalf("participation_generation for %s is NULL right after a create with history on", id)
				}
				for other, g := range gens {
					if g == *gen {
						t.Fatalf("%s and %s both have participation_generation %d after creates at different epochs", other, id, g)
					}
				}
				ids = append(ids, id)
				gens[id] = *gen
			}

			counts := map[string]int{}
			for _, id := range ids {
				counts[id] = e.count(t, id)
				e.markEphemeral(t, id)
			}
			if _, err := e.store.BumpEpoch(e.ctx, "verify-store", "while ephemeral"); err != nil {
				t.Fatalf("BumpEpoch: %v", err)
			}
			for _, id := range []string{ids[1], ids[2], ids[0]} {
				a.arrive(t, e, id)
			}

			for _, id := range ids {
				if after := e.generation(t, "issues", id); after == nil {
					t.Errorf("participation_generation for %s is NULL after the round trip (%s), want %d", id, a.name, gens[id])
				} else if *after != gens[id] {
					t.Errorf("participation_generation for %s = %d after the round trip (%s), want %d: each bead keeps the generation it had before it went ephemeral", id, *after, a.name, gens[id])
				}
				arrived := e.count(t, id)
				if arrived != counts[id]+1 {
					t.Errorf("version count for %s went from %d to %d across the round trip (%s), want exactly +1", id, counts[id], arrived, a.name)
				}
				e.edit(t, id, "generation-edited")
				if got := e.count(t, id); got != arrived+1 {
					t.Errorf("version count for %s went from %d to %d across an edit after the round trip (%s), want exactly +1", id, arrived, got, a.name)
				}
			}
		})
	}
}

// With history off, marking a bead ephemeral through UpdateIssue and bringing
// it back writes nothing to participation_generation on either plane, the
// same rule the repository's history-off differential applies to every
// column the versioned-history stack added.
func TestVerifyServerHistoryOffTripWritesNothing(t *testing.T) {
	for _, a := range wrtvsArrivals {
		t.Run(a.name, func(t *testing.T) {
			e := wrtvsSetup(t)
			id := "test-wrtvs-off-" + a.name

			e.cfg.SetVersionedHistoryEnabled(false)
			e.create(t, id)
			e.markEphemeral(t, id)
			if gen := e.generation(t, "wisps", id); gen != nil {
				t.Errorf("wisps.participation_generation for %s = %d after it was marked ephemeral with history off, want NULL: with history off nothing writes that column", id, *gen)
			}
			a.arrive(t, e, id)
			if gen := e.generation(t, "issues", id); gen != nil {
				t.Errorf("issues.participation_generation for %s = %d after it came back (%s) with history off, want NULL", id, *gen, a.name)
			}
		})
	}
}

// The repository's history-off differential on this store: with versioned
// history off, the scripted mutation set leaves every table as the recorded
// golden says.
func TestVerifyServerHistoryOffWritesWhatItWroteBefore(t *testing.T) {
	wrtvsRequireServer(t)
	store, cleanup := setupConcurrentTestStore(t)
	t.Cleanup(cleanup)
	if err := store.SetConfig(t.Context(), "issue_prefix", historyoffequiv.Prefix); err != nil {
		t.Fatalf("set issue_prefix: %v", err)
	}
	historyoffequiv.Run(t, historyoffequiv.Leg{
		Name:  "server",
		Roles: store,
		Wake: func(ctx context.Context) error {
			store.WakeExpiredDefersAdvisory(ctx)
			return nil
		},
		Extra: historyoffequiv.DoltStorageSteps(store),
		Query: historyoffequiv.SQLQuery(func(context.Context) (*sql.DB, func(), error) {
			return store.DB(), func() {}, nil
		}),
	})
}
