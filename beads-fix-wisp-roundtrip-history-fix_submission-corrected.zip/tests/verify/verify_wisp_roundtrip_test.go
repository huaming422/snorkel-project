//go:build cgo

// Round trips of a bead off the main plane (the wisps table) and back on the
// in-process store, driven through its public operations and read through two
// paths:
//
//   - storage.VersionLister.ListVersions(ctx, id), the recorded version trail
//     the dashboard and `bd` show.
//   - the issues-plane participation_generation column, read with a raw SELECT
//     the same way the repository's own fence fixtures read it, only where a
//     case is about the generation a recording bead carries.
//
// The history-off case at the end runs the repository's own history-off
// differential (internal/storage/historyoffequiv) on this store.
//
// The file joins the package's external test harness: newTestEnv,
// skipUnlessEmbeddedDolt and (*testEnv).queryScalar come from the test files
// already in this directory. Every helper here carries the wrtv prefix.

package embeddeddolt_test

import (
	"context"
	"database/sql"
	"fmt"
	"testing"
	"time"

	"github.com/steveyegge/beads/internal/storage"
	"github.com/steveyegge/beads/internal/storage/embeddeddolt"
	"github.com/steveyegge/beads/internal/storage/historyoffequiv"
	"github.com/steveyegge/beads/internal/types"
	publicops "github.com/steveyegge/beads/issueops"
)

// wrtvStoreID is any store identifier. The epoch counter is per database, so
// the string only has to be non-empty.
const wrtvStoreID = "verify-store"

// wrtvActor is the actor every operation runs under.
const wrtvActor = "actor"

// wrtvCreate makes an issue through CreateIssue and returns its generated id.
// ephemeral picks the plane the row is born on.
func wrtvCreate(t *testing.T, ctx context.Context, store *embeddeddolt.EmbeddedDoltStore, title string, ephemeral bool) string {
	t.Helper()
	issue := &types.Issue{
		Title:     title,
		IssueType: types.TypeTask,
		Status:    types.StatusOpen,
		Ephemeral: ephemeral,
	}
	if err := store.CreateIssue(ctx, issue, wrtvActor); err != nil {
		t.Fatalf("CreateIssue(%q, ephemeral=%v): %v", title, ephemeral, err)
	}
	if issue.ID == "" {
		t.Fatalf("CreateIssue(%q) did not generate an id", title)
	}
	return issue.ID
}

// wrtvSetHistory turns versioned history on or off through the configurer
// interface `bd serve` uses.
func wrtvSetHistory(t *testing.T, store *embeddeddolt.EmbeddedDoltStore, enabled bool) {
	t.Helper()
	configurer, ok := any(store).(storage.VersionedHistoryConfigurer)
	if !ok {
		t.Fatalf("%T does not implement storage.VersionedHistoryConfigurer", store)
	}
	configurer.SetVersionedHistoryEnabled(enabled)
}

// wrtvMove runs the guarded persistence-mode update that `bd update
// --ephemeral` and `bd update --persistent` run.
func wrtvMove(t *testing.T, ctx context.Context, store *embeddeddolt.EmbeddedDoltStore, id string, mode publicops.PersistenceMode) {
	t.Helper()
	ops, err := embeddeddolt.NewIssueOperations(store)
	if err != nil {
		t.Fatalf("NewIssueOperations: %v", err)
	}
	result, err := ops.Update(ctx, publicops.UpdateRequest{
		Actor:   wrtvActor,
		IssueID: id,
		Patch: publicops.IssuePatch{
			Persistence: publicops.Field[publicops.PersistenceMode]{Set: true, Value: mode},
		},
	})
	if err != nil {
		t.Fatalf("persistence move of %s to %v: %v", id, mode, err)
	}
	if !result.Changed {
		t.Fatalf("persistence move of %s to %v reported no change", id, mode)
	}
}

// wrtvDemote marks id ephemeral and checks that the row now sits in the
// wisps table, so the case really is a round trip through that plane.
func wrtvDemote(t *testing.T, ctx context.Context, env *testEnv, id string) {
	t.Helper()
	wrtvMove(t, ctx, env.store, id, publicops.PersistenceModeEphemeral)
	if !wrtvInWisps(t, ctx, env, id) {
		t.Fatalf("%s is not in the wisps table after it was marked ephemeral", id)
	}
}

// wrtvPromote brings id back with PromoteFromEphemeral.
func wrtvPromote(t *testing.T, ctx context.Context, env *testEnv, id string) {
	t.Helper()
	if err := env.store.PromoteFromEphemeral(ctx, id, wrtvActor); err != nil {
		t.Fatalf("PromoteFromEphemeral(%s): %v", id, err)
	}
}

// wrtvEdit changes the title through UpdateIssue: an ordinary content edit.
func wrtvEdit(t *testing.T, ctx context.Context, store *embeddeddolt.EmbeddedDoltStore, id, title string) {
	t.Helper()
	if err := store.UpdateIssue(ctx, id, map[string]any{"title": title}, wrtvActor); err != nil {
		t.Fatalf("UpdateIssue(%s, title=%q): %v", id, title, err)
	}
}

// wrtvCount is the length of id's version trail as ListVersions reports it.
func wrtvCount(t *testing.T, ctx context.Context, store *embeddeddolt.EmbeddedDoltStore, id string) int {
	t.Helper()
	lister, ok := any(store).(storage.VersionLister)
	if !ok {
		t.Fatalf("%T does not implement storage.VersionLister", store)
	}
	versions, err := lister.ListVersions(ctx, id)
	if err != nil {
		t.Fatalf("ListVersions(%s): %v", id, err)
	}
	return len(versions)
}

// wrtvGeneration reads id's participation_generation on the issues plane
// (NULL -> nil).
func wrtvGeneration(t *testing.T, ctx context.Context, env *testEnv, id string) *int64 {
	t.Helper()
	var gen sql.NullInt64
	env.queryScalar(t, ctx, "SELECT participation_generation FROM issues WHERE id = ?", []any{id}, &gen)
	if !gen.Valid {
		return nil
	}
	return &gen.Int64
}

// wrtvInWisps reports whether the wisps table holds a row for id.
func wrtvInWisps(t *testing.T, ctx context.Context, env *testEnv, id string) bool {
	t.Helper()
	var rows int
	env.queryScalar(t, ctx, "SELECT COUNT(*) FROM wisps WHERE id = ?", []any{id}, &rows)
	return rows > 0
}

// wrtvBumpEpoch advances the store's epoch counter.
func wrtvBumpEpoch(t *testing.T, ctx context.Context, store *embeddeddolt.EmbeddedDoltStore, reason string) {
	t.Helper()
	if _, err := store.BumpEpoch(ctx, wrtvStoreID, reason); err != nil {
		t.Fatalf("BumpEpoch(%q): %v", reason, err)
	}
}

// wrtvLegacyRoundTrips creates a bead with history off, turns history on and
// checks that an edit records nothing (the bead is not recording). It then
// takes the bead off the main plane and back twice, the way back being
// arrive, and checks the trail stays empty after each arrival and each edit.
func wrtvLegacyRoundTrips(t *testing.T, prefix, how string, arrive func(t *testing.T, ctx context.Context, env *testEnv, id string)) {
	t.Helper()
	env := newTestEnv(t, prefix)
	ctx := t.Context()

	wrtvSetHistory(t, env.store, false)
	id := wrtvCreate(t, ctx, env.store, "silent-"+how, false)
	wrtvSetHistory(t, env.store, true)

	wrtvEdit(t, ctx, env.store, id, "silent-"+how+"-before")
	if got := wrtvCount(t, ctx, env.store, id); got != 0 {
		t.Fatalf("version count for %s = %d after an edit before any round trip, want 0: the bead was created with history off and should not be recording yet", id, got)
	}

	for trip := 1; trip <= 2; trip++ {
		wrtvDemote(t, ctx, env, id)
		arrive(t, ctx, env, id)
		if got := wrtvCount(t, ctx, env.store, id); got != 0 {
			t.Errorf("version count for %s = %d after round trip %d (%s), want 0: a bead that was not recording stays silent when it comes back", id, got, trip, how)
		}
		wrtvEdit(t, ctx, env.store, id, fmt.Sprintf("silent-%s-edited-%d", how, trip))
		if got := wrtvCount(t, ctx, env.store, id); got != 0 {
			t.Errorf("version count for %s = %d after an edit following round trip %d (%s), want 0", id, got, trip, how)
		}
	}
}

// A bead created before history was on comes back from the trips through
// `bd update --persistent` with an empty trail.
func TestVerifyLegacyStaysLegacyAcrossPersistenceMove(t *testing.T) {
	skipUnlessEmbeddedDolt(t)
	wrtvLegacyRoundTrips(t, "wrtpm", "persistence move", func(t *testing.T, ctx context.Context, env *testEnv, id string) {
		wrtvMove(t, ctx, env.store, id, publicops.PersistenceModePersistent)
	})
}

// The same, with each way back a promote.
func TestVerifyLegacyStaysLegacyAcrossPromote(t *testing.T) {
	skipUnlessEmbeddedDolt(t)
	wrtvLegacyRoundTrips(t, "wrtpr", "promote", wrtvPromote)
}

// wrtvArrivals are the two ways a bead reaches the main plane without being
// created there.
var wrtvArrivals = []struct {
	name   string
	arrive func(t *testing.T, ctx context.Context, env *testEnv, id string)
}{
	{"persistence_move", func(t *testing.T, ctx context.Context, env *testEnv, id string) {
		wrtvMove(t, ctx, env.store, id, publicops.PersistenceModePersistent)
	}},
	{"promote", wrtvPromote},
}

// A recording bead, with the epoch bumped while it is ephemeral, comes back
// with the participation generation it had, gains one version on arrival and
// one per later edit.
func TestVerifyParticipatingKeepsHistoryAcrossRoundTrip(t *testing.T) {
	skipUnlessEmbeddedDolt(t)
	for i, a := range wrtvArrivals {
		t.Run(a.name, func(t *testing.T) {
			env := newTestEnv(t, []string{"wrtkm", "wrtkr"}[i])
			ctx := t.Context()

			wrtvSetHistory(t, env.store, true)
			id := wrtvCreate(t, ctx, env.store, "recording-"+a.name, false)

			before := wrtvGeneration(t, ctx, env, id)
			if before == nil {
				t.Fatalf("participation_generation for %s is NULL right after a create with history on", id)
			}
			beforeCount := wrtvCount(t, ctx, env.store, id)

			wrtvDemote(t, ctx, env, id)
			if got := wrtvCount(t, ctx, env.store, id); got != beforeCount {
				t.Errorf("version count for %s went from %d to %d when it was marked ephemeral, want unchanged", id, beforeCount, got)
			}

			wrtvBumpEpoch(t, ctx, env.store, "while ephemeral")
			a.arrive(t, ctx, env, id)

			after := wrtvGeneration(t, ctx, env, id)
			if after == nil {
				t.Errorf("participation_generation for %s is NULL after the round trip, want %d", id, *before)
			} else if *after != *before {
				t.Errorf("participation_generation for %s = %d after the round trip, want %d: the bead keeps the generation it had before it went ephemeral, whatever the epoch is now", id, *after, *before)
			}

			arrivedCount := wrtvCount(t, ctx, env.store, id)
			if arrivedCount != beforeCount+1 {
				t.Errorf("version count for %s went from %d to %d across the round trip, want exactly +1", id, beforeCount, arrivedCount)
			}
			wrtvEdit(t, ctx, env.store, id, "recording-"+a.name+"-edited")
			if got := wrtvCount(t, ctx, env.store, id); got != arrivedCount+1 {
				t.Errorf("version count for %s went from %d to %d across an edit after the round trip, want exactly +1", id, arrivedCount, got)
			}
		})
	}
}

// Three recording beads created at different epochs, so with three different
// participation generations, make the trip together. The epoch is bumped
// while all three are ephemeral, and they come back in another order than
// they left in. Each comes back with its own generation, gains one version on
// arrival and one per later edit.
func TestVerifyRecordingBeadsKeepTheirOwnGenerations(t *testing.T) {
	skipUnlessEmbeddedDolt(t)
	for i, a := range wrtvArrivals {
		t.Run(a.name, func(t *testing.T) {
			env := newTestEnv(t, []string{"wrtnm", "wrtnr"}[i])
			ctx := t.Context()
			wrtvSetHistory(t, env.store, true)

			var ids []string
			gens := map[string]int64{}
			for n, bumps := range []int{0, 1, 2} {
				for b := 0; b < bumps; b++ {
					wrtvBumpEpoch(t, ctx, env.store, fmt.Sprintf("before bead %d", n))
				}
				id := wrtvCreate(t, ctx, env.store, fmt.Sprintf("generation-%d-%s", n, a.name), false)
				gen := wrtvGeneration(t, ctx, env, id)
				if gen == nil {
					t.Fatalf("participation_generation for %s is NULL right after a create with history on", id)
				}
				for other, g := range gens {
					if g == *gen {
						t.Fatalf("%s and %s both have participation_generation %d after creates at different epochs", other, id, g)
					}
				}
				ids = append(ids, id)
				gens[id] = *gen
			}

			counts := map[string]int{}
			for _, id := range ids {
				counts[id] = wrtvCount(t, ctx, env.store, id)
				wrtvDemote(t, ctx, env, id)
			}
			wrtvBumpEpoch(t, ctx, env.store, "while ephemeral")
			for _, id := range []string{ids[1], ids[2], ids[0]} {
				a.arrive(t, ctx, env, id)
			}

			for _, id := range ids {
				after := wrtvGeneration(t, ctx, env, id)
				if after == nil {
					t.Errorf("participation_generation for %s is NULL after the round trip, want %d", id, gens[id])
				} else if *after != gens[id] {
					t.Errorf("participation_generation for %s = %d after the round trip, want %d: each bead keeps the generation it had before it went ephemeral", id, *after, gens[id])
				}
				arrived := wrtvCount(t, ctx, env.store, id)
				if arrived != counts[id]+1 {
					t.Errorf("version count for %s went from %d to %d across the round trip, want exactly +1", id, counts[id], arrived)
				}
				wrtvEdit(t, ctx, env.store, id, "generation-edited-"+id)
				if got := wrtvCount(t, ctx, env.store, id); got != arrived+1 {
					t.Errorf("version count for %s went from %d to %d across an edit after the round trip, want exactly +1", id, arrived, got)
				}
			}
		})
	}
}

// wrtvWispStartsRecording creates a bead on the wisps plane (history set to
// bornWith at creation), turns history on, brings it to the main plane and
// checks it starts recording: one version on arrival, one more per edit.
func wrtvWispStartsRecording(t *testing.T, prefixes [2]string, bornWith bool) {
	t.Helper()
	for i, a := range wrtvArrivals {
		t.Run(a.name, func(t *testing.T) {
			env := newTestEnv(t, prefixes[i])
			ctx := t.Context()

			wrtvSetHistory(t, env.store, bornWith)
			id := wrtvCreate(t, ctx, env.store, "born-ephemeral-"+a.name, true)
			if !wrtvInWisps(t, ctx, env, id) {
				t.Fatalf("%s created ephemeral is not in the wisps table", id)
			}
			wrtvSetHistory(t, env.store, true)

			a.arrive(t, ctx, env, id)
			if got := wrtvCount(t, ctx, env.store, id); got != 1 {
				t.Errorf("version count for %s after it first reached the main plane = %d, want 1 (created ephemeral with history on=%v)", id, got, bornWith)
			}
			wrtvEdit(t, ctx, env.store, id, "born-ephemeral-"+a.name+"-edited")
			if got := wrtvCount(t, ctx, env.store, id); got != 2 {
				t.Errorf("version count for %s after an edit on the main plane = %d, want 2 (created ephemeral with history on=%v)", id, got, bornWith)
			}
		})
	}
}

// A bead created ephemeral with history on starts recording when it first
// reaches the main plane.
func TestVerifyGenuineWispStartsRecording(t *testing.T) {
	skipUnlessEmbeddedDolt(t)
	wrtvWispStartsRecording(t, [2]string{"wrtgm", "wrtgr"}, true)
}

// A bead created ephemeral while history was still off starts recording too,
// once history is on and it first reaches the main plane.
func TestVerifyWispCreatedBeforeHistoryStartsRecording(t *testing.T) {
	skipUnlessEmbeddedDolt(t)
	wrtvWispStartsRecording(t, [2]string{"wrtbm", "wrtbr"}, false)
}

// A bead created and marked ephemeral while history was off, then brought
// back after history was turned on. Either reading of that bead is accepted:
// it starts recording (one version on arrival, one more after an edit) or it
// stays silent (none, and none after an edit). A mix of the two is not.
func TestVerifyHistoryOffDemotionComesBackConsistently(t *testing.T) {
	skipUnlessEmbeddedDolt(t)
	for i, a := range wrtvArrivals {
		t.Run(a.name, func(t *testing.T) {
			env := newTestEnv(t, []string{"wrtom", "wrtor"}[i])
			ctx := t.Context()

			wrtvSetHistory(t, env.store, false)
			id := wrtvCreate(t, ctx, env.store, "off-trip-"+a.name, false)
			wrtvDemote(t, ctx, env, id)

			wrtvSetHistory(t, env.store, true)
			a.arrive(t, ctx, env, id)
			arrived := wrtvCount(t, ctx, env.store, id)
			wrtvEdit(t, ctx, env.store, id, "off-trip-"+a.name+"-edited")
			edited := wrtvCount(t, ctx, env.store, id)

			startsRecording := arrived == 1 && edited == 2
			staysSilent := arrived == 0 && edited == 0
			if !startsRecording && !staysSilent {
				t.Errorf("version counts for %s = %d on arrival and %d after an edit, want 1 then 2 (it starts recording) or 0 then 0 (it stays silent)", id, arrived, edited)
			}
		})
	}
}

// wrtvUpdatedAt reads id's updated_at from table as text.
func wrtvUpdatedAt(t *testing.T, ctx context.Context, env *testEnv, table, id string) string {
	t.Helper()
	var at string
	env.queryScalar(t, ctx, "SELECT CAST(updated_at AS CHAR) FROM "+table+" WHERE id = ?", []any{id}, &at)
	return at
}

// A trip through the wisps table with history on leaves the bead's updated_at
// where it was, for a bead from before history and for a recording one, on
// the wisps row and after each way back. The beads are created with an old
// fixed timestamp, so any write that lets the column move to now shows up.
func TestVerifyRoundTripKeepsUpdatedAt(t *testing.T) {
	skipUnlessEmbeddedDolt(t)
	old := time.Date(2001, 2, 3, 4, 5, 6, 0, time.UTC)
	for i, a := range wrtvArrivals {
		for j, recording := range []bool{false, true} {
			name := fmt.Sprintf("%s/recording=%v", a.name, recording)
			t.Run(name, func(t *testing.T) {
				env := newTestEnv(t, []string{"wrtua", "wrtub", "wrtuc", "wrtud"}[2*i+j])
				ctx := t.Context()

				wrtvSetHistory(t, env.store, recording)
				issue := &types.Issue{
					Title: "dated-" + a.name, IssueType: types.TypeTask, Status: types.StatusOpen,
					CreatedAt: old, UpdatedAt: old,
				}
				if err := env.store.CreateIssue(ctx, issue, wrtvActor); err != nil {
					t.Fatalf("CreateIssue: %v", err)
				}
				id := issue.ID
				wrtvSetHistory(t, env.store, true)
				before := wrtvUpdatedAt(t, ctx, env, "issues", id)

				wrtvDemote(t, ctx, env, id)
				if got := wrtvUpdatedAt(t, ctx, env, "wisps", id); got != before {
					t.Errorf("updated_at for %s is %s on the wisps row, want %s as before the trip", id, got, before)
				}
				a.arrive(t, ctx, env, id)
				if got := wrtvUpdatedAt(t, ctx, env, "issues", id); got != before {
					t.Errorf("updated_at for %s is %s after the trip (%s), want %s as before it", id, got, name, before)
				}
			})
		}
	}
}

// With versioned history off, the repository's scripted mutation set
// (internal/storage/historyoffequiv), plane moves included, leaves every table
// as the recorded golden says: the columns and table the versioned-history
// stack added stay NULL and empty.
func TestVerifyHistoryOffWritesWhatItWroteBefore(t *testing.T) {
	skipUnlessEmbeddedDolt(t)
	te := newTestEnv(t, historyoffequiv.Prefix)
	historyoffequiv.Run(t, historyoffequiv.Leg{
		Name:  "embedded",
		Roles: te.store,
		Wake: func(ctx context.Context) error {
			te.store.WakeExpiredDefersAdvisory(ctx)
			return nil
		},
		Extra: historyoffequiv.DoltStorageSteps(te.store),
		Query: historyoffequiv.SQLQuery(func(ctx context.Context) (*sql.DB, func(), error) {
			db, cleanup, err := embeddeddolt.OpenSQL(ctx, te.dataDir, te.database, "main")
			if err != nil {
				return nil, nil, err
			}
			return db, func() { _ = cleanup() }, nil
		}),
	})
}
