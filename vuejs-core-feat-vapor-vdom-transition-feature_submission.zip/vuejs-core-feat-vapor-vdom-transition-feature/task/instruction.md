## Task

When a vdom `<Transition>` wraps content that the vapor runtime renders (a vapor slot's content, or a vapor component), that content doesn't animate. It just appears and disappears instead of playing the transition.

We want a vdom `<Transition>` to drive its enter and leave animations over vapor-rendered content the same way it does over vdom content, including the `out-in` and `in-out` modes and `appear` on first mount. A vapor-native `<Transition>` (vapor content with no vdom wrapper) already handles this, so the work is only on the path where a vdom `<Transition>` is the wrapper.

## User stories / requirements

- When a vdom `<Transition>` wraps a vapor component's slot content and that content is toggled away, it plays its leave and stays in the DOM until the leave finishes, then is removed; bringing it back plays the enter. On first mount with appear set, the initial content plays its appear animation.
- With the transition in `out-in` mode, swapping the vapor slot content for different content lets the outgoing content finish leaving and get removed before the incoming content starts entering.
- With the transition in `in-out` mode, swapping the vapor slot content enters the incoming content first and keeps the outgoing content around until that enter finishes. If the previous content is restored while it is still leaving, the leaving copy is removed rather than left behind as a duplicate.
- A vapor component placed directly as the vdom `<Transition>`'s child, not just a bare slot, animates the same way: toggling the component out plays its leave, and toggling it back in plays its enter.
- When the vapor child currently renders nothing to show, toggling the surrounding condition plays no enter or leave. Once the child renders real content, animations run as normal.
- A vapor-native `<Transition>` (compiled with `vapor: true`) wrapping vapor-native content plays enter and leave hooks and keeps leaving content in the DOM until the leave finishes — the same contract as the vdom `<Transition>` control. The vapor-native out-in mode also sequences correctly: the outgoing element leaves fully before the incoming one enters.
