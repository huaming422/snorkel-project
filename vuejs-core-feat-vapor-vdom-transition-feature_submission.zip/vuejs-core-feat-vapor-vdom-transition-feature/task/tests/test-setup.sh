#!/usr/bin/env bash
# All required deps are baked into the image at the base commit: the Node
# toolchain, pnpm with a warm store (/opt/cache/pnpm), the full workspace
# `pnpm install --frozen-lockfile`, the puppeteer/playwright browsers, and
# the prebuilt global dev bundle. The oracle introduces no new package or
# lockfile change, so the agent phase runs fully offline with nothing to
# fetch. Nothing to do at verifier time.
set -euo pipefail
echo "[test-setup] no-op for vuejs-core-feat-vapor-vdom-transition"
