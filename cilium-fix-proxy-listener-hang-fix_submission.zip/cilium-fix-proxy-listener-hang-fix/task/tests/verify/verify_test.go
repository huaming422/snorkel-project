// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

// Drives the embedded xDS server through its pre-existing, exported surface
// only: the proxy-listener teardown entry point RemoveListener, and the
// stable resource-mutator operations Upsert / HandleResourceVersionAck used to
// stage and observe a pending policy wait. It never references the teardown
// resolution helper the fix adds, nor any new metric symbol, so every
// behaviorally-equivalent fix (inline loop, renamed helper, pushed-down
// decision) is accepted on equal footing.
//
// Internal package (envoy) so scenario preconditions can be staged on the
// unexported listener bookkeeping fields (listenerCount, proxyListeners) and
// on the per-type mutators the server wires at construction. That is setup,
// not coupling: the asserted effect is always observed at RemoveListener.
//
// Identifiers carry a vrf prefix so this file composes cleanly with the
// package's own internal test files.

package envoy

import (
	"context"
	"testing"
	"time"

	"github.com/cilium/hive/hivetest"
	"github.com/stretchr/testify/require"

	cilium "github.com/cilium/proxy/go/cilium/api"
	envoy_config_route "github.com/envoyproxy/go-control-plane/envoy/config/route/v3"

	"github.com/cilium/cilium/pkg/completion"
	"github.com/cilium/cilium/pkg/envoy/xds"
	testipcache "github.com/cilium/cilium/pkg/testutils/ipcache"
)

const (
	// vrfNode is a single node id shared between staging a wait and
	// acknowledging it. The teardown path treats node ids opaquely; the value
	// only has to be internally consistent within a scenario. It mirrors the
	// canonical single-node id the server itself passes on resource deletes.
	vrfNode = "127.0.0.1"

	// vrfSettleDeadline bounds how long a wait is allowed to take once the
	// triggering action has run. Resolution happens inline during the action,
	// so on success this returns immediately; the generous bound only caps how
	// long the never-settling case is allowed to block before surfacing.
	vrfSettleDeadline = 2 * time.Second

	// vrfPendingWindow is a short observation window used to confirm a wait has
	// NOT settled. Nothing resolves it during the window, so it is stable.
	vrfPendingWindow = 300 * time.Millisecond

	// vrfWaitCtxTimeout is intentionally long so a staged wait never resolves
	// on its own via context expiry within an observation window — resolution
	// must come from the teardown path, not from the wait quietly timing out.
	vrfWaitCtxTimeout = 60 * time.Second

	// vrfAckVersion is a version far above any version the fresh per-scenario
	// caches will assign, so an acknowledgement unambiguously covers the staged
	// update regardless of the exact cache version counter.
	vrfAckVersion = 1000
)

// vrfSignal observes a single resource wait. The mutator invokes the callback
// synchronously, exactly once, when the wait resolves; the buffered channel
// keeps that invocation non-blocking.
type vrfSignal struct {
	ch chan error
}

func vrfNewSignal() (func(error), *vrfSignal) {
	sig := &vrfSignal{ch: make(chan error, 1)}
	return func(err error) { sig.ch <- err }, sig
}

// settled reports whether the wait resolved within d, and with what error.
// A resolved wait returns (true, err); an unresolved one returns (false, nil)
// after d elapses.
func (sig *vrfSignal) settled(d time.Duration) (bool, error) {
	select {
	case err := <-sig.ch:
		return true, err
	case <-time.After(d):
		return false, nil
	}
}

// vrfNewServer builds the embedded xDS server headless — no proxy process, no
// sockets opened — wiring the per-type resource mutators via the server's own
// constructor. Mirrors the construction used by the package's embedded test.
func vrfNewServer(t *testing.T) *xdsServer {
	t.Helper()
	logger := hivetest.Logger(t)
	s := newXDSServer(logger, nil, testipcache.NewMockIPCache(), newLocalEndpointStore(),
		xdsServerConfig{
			envoySocketDir:    GetSocketDir(t.TempDir()),
			proxyGID:          1337,
			httpNormalizePath: true,
			metrics:           xds.NewXDSMetric(),
		},
		nil)
	require.NotNil(t, s)
	return s
}

// vrfNewPolicyResource returns a minimal, valid network-policy message. The
// cache only stores it; policy semantics are not exercised here.
func vrfNewPolicyResource() *cilium.NetworkPolicy {
	return &cilium.NetworkPolicy{EndpointIps: []string{"10.0.0.1"}, EndpointId: 1}
}

// vrfStagePolicyWait records a pending network-policy update on the server's
// network-policy mutator and returns a handle to observe its resolution.
func vrfStagePolicyWait(t *testing.T, s *xdsServer, wg *completion.WaitGroup, name string) *vrfSignal {
	t.Helper()
	cb, sig := vrfNewSignal()
	s.networkPolicyMutator.Upsert(NetworkPolicyTypeURL, name, vrfNewPolicyResource(), []string{vrfNode}, wg, cb)
	// Precondition: the update is genuinely waiting before any teardown runs.
	if settled, _ := sig.settled(vrfPendingWindow); settled {
		t.Fatalf("precondition failed: staged policy update %q resolved before teardown", name)
	}
	return sig
}

// Criterion root_cause_addressed (fail_to_pass).
//
// Network-policy updates still waiting for the proxy when the last proxy
// listener is torn down must settle instead of blocking forever. Observed at
// RemoveListener: before the fix a wait never resolves (bounded assertion
// fires); after the fix teardown resolves it.
//
// Stages MORE THAN ONE in-flight network-policy update and requires every one
// of them to settle. Teardown is a wholesale event — the acknowledging
// component is gone, so no pending policy wait can ever get a real ack. A fix
// that settles only a single waiter (and leaves the rest hanging) still hangs
// in practice, so the bounded assertion must hold for all of them, not just
// one. Stated purely at the RemoveListener boundary via the per-wait callback
// channels; no fix symbol is referenced, so any design that resolves the
// pending policy waits on last-listener teardown is accepted.
func TestVrfLastListenerCancelsNPCompletion(t *testing.T) {
	s := vrfNewServer(t)

	ctx, cancel := context.WithTimeout(context.Background(), vrfWaitCtxTimeout)
	defer cancel()
	wg := completion.NewWaitGroup(ctx)

	const ln = "vrf-listener"
	s.listenerCount[ln] = 1
	s.proxyListeners = 1

	sigA := vrfStagePolicyWait(t, s, wg, "vrf-np-a")
	sigB := vrfStagePolicyWait(t, s, wg, "vrf-np-b")

	s.RemoveListener(ln, nil)

	settledA, _ := sigA.settled(vrfSettleDeadline)
	require.True(t, settledA,
		"removing the last proxy listener must settle a pending network-policy update, but it stayed blocked")
	settledB, _ := sigB.settled(vrfSettleDeadline)
	require.True(t, settledB,
		"every network-policy update still pending at last-listener teardown must settle, not just one")
}

// Criterion cancel_without_error (fail_to_pass).
//
// A teardown is not a failure: the resolved update must finish cleanly, not
// come back looking like it errored. Rejects a fix that resolves the wait with
// a synthetic error.
func TestVrfCancelCompletesWithNilError(t *testing.T) {
	s := vrfNewServer(t)

	ctx, cancel := context.WithTimeout(context.Background(), vrfWaitCtxTimeout)
	defer cancel()
	wg := completion.NewWaitGroup(ctx)

	const ln = "vrf-listener"
	s.listenerCount[ln] = 1
	s.proxyListeners = 1

	sig := vrfStagePolicyWait(t, s, wg, "vrf-np")

	s.RemoveListener(ln, nil)

	settled, err := sig.settled(vrfSettleDeadline)
	require.True(t, settled,
		"removing the last proxy listener must settle the pending network-policy update")
	require.NoError(t, err,
		"a teardown is not a failure: the settled update must carry no error")
}

// Criterion last_listener_guard (fail_to_pass).
//
// Resolution must trigger only when the LAST proxy listener is removed. While
// other proxy listeners remain, the acknowledging component is still running,
// so an in-flight update must keep waiting for a real acknowledgement. Removing
// the final listener must then settle it.
//
// Two-phase so it both rejects an over-eager fix (one that resolves on any
// removal — phase one would settle early) and remains fail_to_pass on unfixed
// code (phase two never settles).
func TestVrfNonLastListenerKeepsCompletionPending(t *testing.T) {
	s := vrfNewServer(t)

	ctx, cancel := context.WithTimeout(context.Background(), vrfWaitCtxTimeout)
	defer cancel()
	wg := completion.NewWaitGroup(ctx)

	const lnA = "vrf-listener-a"
	const lnB = "vrf-listener-b"
	s.listenerCount[lnA] = 1
	s.listenerCount[lnB] = 1
	s.proxyListeners = 2

	sig := vrfStagePolicyWait(t, s, wg, "vrf-np")

	// Phase one: removing a non-last proxy listener must leave the update waiting.
	s.RemoveListener(lnA, nil)
	settledEarly, _ := sig.settled(vrfPendingWindow)
	require.False(t, settledEarly,
		"removing a non-last proxy listener must not settle an in-flight network-policy update")

	// Phase two: removing the final proxy listener must settle it.
	s.RemoveListener(lnB, nil)
	settled, err := sig.settled(vrfSettleDeadline)
	require.True(t, settled,
		"removing the last proxy listener must settle the pending network-policy update")
	require.NoError(t, err,
		"the settled update must carry no error")
}

// Criterion typeurl_scoping (fail_to_pass).
//
// Only network-policy waits are resolved on last-listener teardown. A pending
// wait for a different kind of proxy update (here a route update, staged on a
// different resource mutator) must be left untouched.
func TestVrfCancelScopedToNetworkPolicy(t *testing.T) {
	s := vrfNewServer(t)

	ctx, cancel := context.WithTimeout(context.Background(), vrfWaitCtxTimeout)
	defer cancel()
	wg := completion.NewWaitGroup(ctx)

	const ln = "vrf-listener"
	s.listenerCount[ln] = 1
	s.proxyListeners = 1

	npSig := vrfStagePolicyWait(t, s, wg, "vrf-np")

	// Stage an unrelated route update that must survive the teardown.
	routeCb, routeSig := vrfNewSignal()
	s.routeMutator.Upsert(RouteTypeURL, "vrf-route", &envoy_config_route.RouteConfiguration{Name: "vrf-route"},
		[]string{vrfNode}, wg, routeCb)
	if settled, _ := routeSig.settled(vrfPendingWindow); settled {
		t.Fatal("precondition failed: staged route update resolved before teardown")
	}

	s.RemoveListener(ln, nil)

	npSettled, npErr := npSig.settled(vrfSettleDeadline)
	require.True(t, npSettled, "the network-policy update must settle on last-listener teardown")
	require.NoError(t, npErr, "the settled network-policy update must carry no error")

	routeSettled, _ := routeSig.settled(vrfPendingWindow)
	require.False(t, routeSettled,
		"an unrelated route update must be left waiting; only network-policy waits are resolved on teardown")
}

// Criterion no_regression_normal_ack (pass_to_pass).
//
// The ordinary acknowledgement path still resolves a pending network-policy
// update exactly as before — the fix must not regress it. No teardown involved;
// passes on both unfixed and fixed code.
func TestVrfNormalAckStillCompletes(t *testing.T) {
	s := vrfNewServer(t)

	ctx, cancel := context.WithTimeout(context.Background(), vrfWaitCtxTimeout)
	defer cancel()
	wg := completion.NewWaitGroup(ctx)

	const name = "vrf-np"
	sig := vrfStagePolicyWait(t, s, wg, name)

	// Drive the ordinary acknowledgement path. HandleResourceVersionAck lives on
	// the pre-existing exported ack-observer interface, which the network-policy
	// mutator already implements; assert to it rather than referencing any fix
	// symbol. Box through any() first so this reaches the observer regardless of
	// whether the fix keeps the field interface-typed or narrows it to the
	// concrete mutator — both are behaviorally identical and both implement it.
	acker := any(s.networkPolicyMutator).(xds.ResourceVersionAckObserver)
	acker.HandleResourceVersionAck(vrfAckVersion, vrfAckVersion, vrfNode,
		[]string{name}, NetworkPolicyTypeURL, "")

	settled, err := sig.settled(vrfSettleDeadline)
	require.True(t, settled, "an ordinary acknowledgement must still settle a pending network-policy update")
	require.NoError(t, err, "a normal acknowledgement settles the update with no error")
}
