## Task

We've had a few reports of the agent getting stuck during network-policy updates. On an affected node, an operation that updates network policy (or the identity information that policy depends on) sometimes never returns; the caller just blocks indefinitely instead of the update settling.

Can you track down why these updates hang and make them settle instead of blocking?
