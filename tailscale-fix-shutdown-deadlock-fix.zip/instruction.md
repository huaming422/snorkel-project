## Task

Some operators find that stopping the node agent never finishes. The backend gets partway through shutdown, then remains stuck and the process does not exit. Most stops succeed, so this appears to depend on timing.

The reports tend to involve nodes with TLS/ACME certificate refresh activity, SSH sessions still in progress when the stop is requested, or both. Once a stop hangs, it does not recover on its own. Investigate the backend's coordination with the components it owns and make shutdown complete under these conditions. After shutdown, new SSH traffic must not bring its server back. Keep the rest of the backend teardown intact.
