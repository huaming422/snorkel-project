// Copyright (c) Tailscale Inc & contributors
// SPDX-License-Identifier: BSD-3-Clause

// In-package behavioral check for the certificate-refresh half of
// LocalBackend teardown coordination.
//
// Injected into feature/acme as package acme so it drives the REAL cert
// refresh machinery — the registered cert-shutdown hook, the extension's
// goroutine tracking, and the extension-host drain — rather than a
// replaced test hook. Driving the real machinery is what lets this check
// judge the behavioral contract ("stopping the backend always completes,
// even while cert work that needs the backend's primary lock is in
// flight") without pinning WHERE the blocking drain runs: whether
// teardown moves the cert stop out from under the lock, or cancels the
// loop under the lock and drains through the extension host after
// releasing it, this check passes as long as Shutdown returns. The cert
// shutdown hook is not linked into the ipn/ipnlocal test binary, so a
// hook-replacement check in that package could only exercise a
// substitute closure invoked at the same call site for every solution,
// which cannot distinguish these designs.
package acme

import (
	"context"
	"os"
	"os/exec"
	"testing"
	"time"

	"tailscale.com/ipn/ipnlocal"
	"tailscale.com/ipn/ipnlocal/ipnlocaltest"
)

// TestShutdownCompletesWithInFlightCertRefresh is the cert-refresh half of
// fail_to_pass criterion C1, and via the second Shutdown call the cert-refresh
// half of the idempotency criterion C3.
//
// It parks a tracked cert-refresh worker inside the extension's cert machinery
// and then has that worker call a backend method that needs the primary lock.
// Pre-fix, Shutdown waits for the worker while holding the primary lock, so the
// worker can never acquire the lock and Shutdown never returns — the backend's
// own teardown watchdog trips (or the check's own timeout fires) and the test
// fails. Any fix that lets Shutdown complete — moving the blocking cert drain
// out from under the lock, or cancelling the loop under the lock and draining
// after releasing it — passes. Shutdown is called twice to confirm teardown is
// idempotent and safe to repeat.
func TestShutdownCompletesWithInFlightCertRefresh(t *testing.T) {
	// A deadlocked backend also blocks NewBackend's cleanup and eventually
	// triggers its process-wide watchdog panic. Run that case in a child test
	// process so the parent can report the failed named test deterministically.
	if os.Getenv("SSB_ACME_SHUTDOWN_CHILD") != "1" {
		ctx, cancel := context.WithTimeout(context.Background(), 12*time.Second)
		defer cancel()
		cmd := exec.CommandContext(ctx, os.Args[0], "-test.run=^TestShutdownCompletesWithInFlightCertRefresh$", "-test.v")
		cmd.Env = append(os.Environ(), "SSB_ACME_SHUTDOWN_CHILD=1")
		output, err := cmd.CombinedOutput()
		if ctx.Err() != nil {
			t.Fatalf("certificate shutdown did not finish before child timeout: %s", output)
		}
		if err != nil {
			t.Fatalf("certificate shutdown child failed: %v\n%s", err, output)
		}
		return
	}

	// NewBackend registers b.Shutdown as a t.Cleanup. This check drives
	// Shutdown in the body; once the backend is torn down the cleanup's
	// repeat Shutdown is a safe idempotent no-op (which this check also
	// asserts), so no special no-cleanup constructor is needed.
	b := ipnlocaltest.NewBackend(t)
	b.SetVarRoot(t.TempDir())
	e := extOf(t, b)

	entered := make(chan struct{})
	release := make(chan struct{})

	// Install a cert retrieval function that parks one cert-refresh worker
	// until released, then calls back into a backend method that takes the
	// primary lock. This models the real deadlock: a cert goroutine mid-flight
	// that needs the lock teardown is holding.
	b.ForTest().ConfigureCerts(func(host string) (*ipnlocal.TLSCertKeyPair, error) {
		close(entered)
		<-release
		_ = b.ServeConfig() // acquires the backend's primary lock
		return &ipnlocal.TLSCertKeyPair{}, nil
	})

	// Launch the worker as a goroutine tracked by the extension, exactly as the
	// real refresh loop does, so the extension's drain waits on it.
	e.Go(func() {
		_, _ = e.getCertPEMWithValidity(context.Background(), b, "node.example.com", 0)
	})

	select {
	case <-entered:
	case <-time.After(5 * time.Second):
		t.Fatal("cert refresh worker never started")
	}

	done := make(chan struct{})
	go func() {
		b.Shutdown()
		b.Shutdown() // idempotent: a repeat call must also return
		close(done)
	}()

	// Let Shutdown reach the cert drain, then release the parked worker so it
	// tries to take the primary lock.
	time.Sleep(100 * time.Millisecond)
	close(release)

	select {
	case <-done:
		// Shutdown returned: teardown did not wedge on the cert machinery.
	case <-time.After(5 * time.Second):
		t.Fatal("LocalBackend.Shutdown did not complete; teardown wedged while stopping the cert refresh machinery")
	}
}
