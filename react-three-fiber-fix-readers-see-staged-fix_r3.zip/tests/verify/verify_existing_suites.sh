#!/usr/bin/env bash
# The pre-existing @react-three/tsl and @react-three/fiber suites must still pass.
#
# Run without --coverage: the root vitest config carries a coverage ratchet
# that is irrelevant to correctness and would make this check flake on
# unrelated line-count drift. Only the existing tests' results matter here.
set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/react-three-fiber}"
cd "$REPO_DIR"

export NODE_OPTIONS="${NODE_OPTIONS:---max-old-space-size=4096}"

echo "[existing-suites] running packages/tsl + packages/fiber (no coverage)..."
pnpm exec vitest run packages/tsl packages/fiber --no-coverage
