// @ts-nocheck
//
// Verifier for TSL resource sharing between components.
//
// Everything is driven through public hooks exported from `@react-three/tsl`
// (`useUniforms`, `useNodes`, `useBuffers`, `useGPUStorage`, `useRenderPipeline`),
// rendered under the repo's own `context.Provider` test store
// (`packages/tsl/tests/store.ts`). Nothing here imports package internals.
//
// The scenario: one component declares a resource while it renders, and
// another component reads it through the same hook. The reader must get the
// declared resource on its own first render, and later reads must stay
// consistent with what has been declared. The last group reads the same
// resources from the state the render pipeline's callbacks are handed.
//
// This file lives in packages/tsl/tests at grade time (verify.toml
// test_parent), so `../src` and `./store` resolve against the tsl package.

import { describe, expect, it, beforeEach, afterEach, vi } from 'vitest'
import * as React from 'react'
import { act } from 'react'
import { render } from '@testing-library/react'
import * as THREE from 'three/webgpu'
import { float, instancedArray } from 'three/tsl'

import type { RootStore } from '@react-three/fiber/webgpu'
import { rebuildAllUniforms, useBuffers, useGPUStorage, useNodes, useRenderPipeline, useUniforms } from '../src'
import { createStore, context } from './store'

const noop = () => {}
const makeStore = () => createStore(noop, noop)

let warnSpy: ReturnType<typeof vi.spyOn>
beforeEach(() => {
  warnSpy = vi.spyOn(console, 'warn').mockImplementation(noop)
})
afterEach(() => warnSpy.mockRestore())

async function mount(store: RootStore, children: React.ReactNode) {
  const tree = <context.Provider value={store}>{children}</context.Provider>
  let view: ReturnType<typeof render> = null!
  await act(async () => {
    view = render(tree)
  })
  return view
}

/** Records the value a reader saw on each render, in order. */
function recorder<T>() {
  const renders: T[] = []
  return { renders, first: () => renders[0], last: () => renders[renders.length - 1] }
}

//* ── a child reads what its parent declares ──
// A child reading with the whole-store form or the scoped form gets the entry
// its parent declares in the same render, on the child's first render.

describe('a child sees what its parent declares in the same render', () => {
  it('useUniforms() (whole-store) sees a uniform its parent declared this render', async () => {
    const store = makeStore()
    const created = recorder<unknown>()
    const read = recorder<unknown>()

    function Child() {
      read.renders.push(useUniforms<{ uSpeed: number }>().uSpeed)
      return null
    }
    function Parent() {
      created.renders.push(useUniforms({ uSpeed: 2 }).uSpeed)
      return <Child />
    }

    await mount(store, <Parent />)

    // The child's first read is the node the parent created.
    expect(read.first(), "child's first useUniforms() read missed the uniform its parent declared in the same render").toBeDefined()
    expect(read.first(), "child's first read is not the node the parent created").toBe(created.first())
    // Afterwards the reader holds the node that is in the store.
    expect(read.last(), 'afterwards the reader should hold the node in the store').toBe(store.getState().uniforms.uSpeed)
  })

  it("useUniforms('scope') sees a scoped uniform its parent declared this render", async () => {
    const store = makeStore()
    const created = recorder<unknown>()
    const read = recorder<unknown>()

    function Child() {
      read.renders.push(useUniforms<{ uHealth: number }>('player').uHealth)
      return null
    }
    function Parent() {
      created.renders.push(useUniforms({ uHealth: 100 }, 'player').uHealth)
      return <Child />
    }

    await mount(store, <Parent />)

    expect(read.first(), "child's first useUniforms('player') read missed the scoped uniform its parent declared").toBeDefined()
    expect(read.first(), "child's first scoped read is not the node the parent created").toBe(created.first())
    expect(read.last(), 'afterwards the scoped reader should hold the node in the store').toBe(
      (store.getState().uniforms.player as Record<string, unknown>).uHealth,
    )
  })

  it('a child bakes the real uniform (not undefined) into a layout-effect build', async () => {
    // A descendant reads a uniform with useUniforms() and closes over it once
    // in a layout effect, the way a render-pipeline build does. The value it
    // captures must be the real uniform.
    const store = makeStore()
    const captured: unknown[] = []
    let registered: unknown = null

    function PipelineManager() {
      const { blurAmount } = useUniforms<{ blurAmount: number }>()
      React.useLayoutEffect(() => {
        captured.push(blurAmount) // built once, like a render-pipeline graph
      }, [])
      return null
    }
    function Experience() {
      registered = useUniforms({ blurAmount: 1 }).blurAmount
      return <PipelineManager />
    }

    await mount(store, <Experience />)

    expect(captured, 'the layout effect should run exactly once').toHaveLength(1)
    expect(captured[0], 'the layout-effect build closed over undefined instead of the parent uniform').toBeDefined()
    expect(captured[0], 'the layout-effect build closed over a different node than the parent registered').toBe(registered)
    expect(captured[0], 'the captured node is not the one in the store').toBe(store.getState().uniforms.blurAmount)
  })

  it('the same holds under StrictMode double rendering', async () => {
    // StrictMode renders every component twice and replays effects. The child
    // must still see the parent's uniform on every render, including the first.
    const store = makeStore()
    const created = recorder<unknown>()
    const read = recorder<unknown>()

    function Child() {
      read.renders.push(useUniforms<{ uGain: number }>().uGain)
      return null
    }
    function Parent() {
      created.renders.push(useUniforms({ uGain: 3 }).uGain)
      return <Child />
    }

    await mount(
      store,
      <React.StrictMode>
        <Parent />
      </React.StrictMode>,
    )

    expect(read.renders.length, 'the child never rendered').toBeGreaterThan(0)
    for (const seen of read.renders) {
      expect(seen, 'under StrictMode a child render missed the uniform its parent declared').toBeDefined()
    }
    expect(read.first(), "under StrictMode the child's first read is not the parent's node").toBe(created.first())
    expect(read.last(), 'under StrictMode the reader should end on the node in the store').toBe(
      store.getState().uniforms.uGain,
    )
  })
})

//* ── every resource hook ──
// The same parent-declares, child-reads sharing for nodes, buffers and GPU
// storage, in both the whole-store and the scoped form.

describe('every resource hook shares what a parent declares, not just useUniforms', () => {
  it('useNodes() and useNodes(scope) see nodes their parent declared this render', async () => {
    const store = makeStore()
    const created = recorder<{ wobble: unknown; offset: unknown }>()
    const root = recorder<unknown>()
    const scoped = recorder<unknown>()
    const nested = recorder<unknown>()

    function Child() {
      const all = useNodes()
      root.renders.push(all.wobble)
      nested.renders.push((all.player as Record<string, unknown> | undefined)?.offset)
      scoped.renders.push(useNodes('player').offset)
      return null
    }
    function Parent() {
      const { wobble } = useNodes(() => ({ wobble: float(1) }))
      const { offset } = useNodes(() => ({ offset: float(2) }), 'player')
      created.renders.push({ wobble, offset })
      return <Child />
    }

    await mount(store, <Parent />)

    expect(root.first(), "useNodes(): child's first read missed the parent's node").toBeDefined()
    expect(root.first(), "useNodes(): child's first read is not the parent's node").toBe(created.first().wobble)
    expect(scoped.first(), "useNodes('player'): child's first read missed the parent's scoped node").toBe(
      created.first().offset,
    )
    // The whole-store form also shows the declared scope, nested under its key.
    expect(nested.first(), "useNodes(): the parent's scoped node is missing under its scope key").toBe(
      created.first().offset,
    )
    expect(root.last(), 'useNodes(): afterwards the reader should hold the node in the store').toBe(
      store.getState().nodes.wobble,
    )
  })

  it('useBuffers() and useBuffers(scope) see buffers their parent declared this render', async () => {
    const store = makeStore()
    const positions = new Float32Array(4)
    const velocities = instancedArray(4, 'vec2')
    const root = recorder<unknown>()
    const scoped = recorder<unknown>()
    const nested = recorder<unknown>()

    function Child() {
      const all = useBuffers()
      root.renders.push(all.positions)
      nested.renders.push((all.particles as Record<string, unknown> | undefined)?.velocities)
      scoped.renders.push(useBuffers('particles').velocities)
      return null
    }
    function Parent() {
      useBuffers(() => ({ positions }))
      useBuffers(() => ({ velocities }), 'particles')
      return <Child />
    }

    await mount(store, <Parent />)

    expect(root.first(), "useBuffers(): child's first read missed the parent's buffer").toBe(positions)
    expect(scoped.first(), "useBuffers('particles'): child's first read missed the parent's scoped buffer").toBe(
      velocities,
    )
    expect(nested.first(), "useBuffers(): the parent's scoped buffer is missing under its scope key").toBe(velocities)
    expect(root.last(), 'useBuffers(): afterwards the reader should hold the buffer in the store').toBe(
      store.getState().buffers.positions,
    )
  })

  it('useGPUStorage() and useGPUStorage(scope) see storage their parent declared this render', async () => {
    const store = makeStore()
    const heightMap = new THREE.StorageTexture(8, 8)
    const normal = new THREE.StorageTexture(8, 8)
    const root = recorder<unknown>()
    const scoped = recorder<unknown>()
    const nested = recorder<unknown>()

    function Child() {
      const all = useGPUStorage()
      root.renders.push(all.heightMap)
      nested.renders.push((all.terrain as Record<string, unknown> | undefined)?.normal)
      scoped.renders.push(useGPUStorage('terrain').normal)
      return null
    }
    function Parent() {
      useGPUStorage(() => ({ heightMap }))
      useGPUStorage(() => ({ normal }), 'terrain')
      return <Child />
    }

    await mount(store, <Parent />)

    expect(root.first(), "useGPUStorage(): child's first read missed the parent's storage").toBe(heightMap)
    expect(scoped.first(), "useGPUStorage('terrain'): child's first read missed the parent's scoped storage").toBe(
      normal,
    )
    expect(nested.first(), "useGPUStorage(): the parent's scoped storage is missing under its scope key").toBe(normal)
    expect(scoped.last(), 'useGPUStorage(): afterwards the scoped reader should hold the storage in the store').toBe(
      (store.getState().gpuStorage.terrain as Record<string, unknown>).normal,
    )
  })
})

//* ── existing read results ──
// A scoped read of a name that holds a single root uniform returns no entries,
// a read of the empty scope name returns no root entries, and a whole-store
// read keeps a scope's existing entries next to new ones.

describe('scoped and whole-store reads keep their existing results', () => {
  it('a root uniform named like a scope is not returned as that scope', async () => {
    const store = makeStore()
    // Declare a root-level uniform named "player"; there is no scope "player".
    function Creator() {
      useUniforms({ player: 1 })
      return null
    }
    await mount(store, <Creator />)
    // It is in the store as a root-level uniform.
    const leaf = store.getState().uniforms.player as Record<string, unknown>
    expect(leaf, "the root uniform 'player' should be in the store").toBeDefined()
    expect(leaf.isUniformNode, "'player' should be stored as a uniform node").toBe(true)

    const scoped = recorder<Record<string, unknown>>()
    function Reader() {
      // Reading "player" as a scope must not return the uniform's own fields.
      scoped.renders.push(useUniforms('player') as Record<string, unknown>)
      return null
    }
    await act(async () => {
      render(
        <context.Provider value={store}>
          <Reader />
        </context.Provider>,
      )
    })

    // The scoped read holds only the hook's utility functions: no 'player'
    // entry and none of the uniform's own fields.
    const seen = scoped.first()
    expect(seen.player, "a root uniform named 'player' leaked into the 'player' scope read").toBeUndefined()
    expect(seen.isUniformNode, "the 'player' leaf was returned as if it were a scope").toBeUndefined()
    expect(seen.value, "the 'player' leaf's own fields leaked into the scope read").toBeUndefined()
  })

  it("a read of the empty scope name returns no root entries", async () => {
    // A parent declares a root-level uniform; a child reads the empty scope
    // name in the same render.
    const store = makeStore()
    const scoped = recorder<Record<string, unknown>>()

    function Child() {
      scoped.renders.push(useUniforms('') as Record<string, unknown>)
      return null
    }
    function Parent() {
      useUniforms({ uRoot: 1 }) // a root-level uniform, declared this render
      return <Child />
    }

    await mount(store, <Parent />)

    // The root-level uniform does not appear in the '' read.
    expect(scoped.first().uRoot, "a root-level entry declared this render surfaced through a '' scope read").toBeUndefined()

    // And once uRoot is in the store, a '' scope read still returns no root entries,
    // exactly as it did before the change.
    const later = recorder<Record<string, unknown>>()
    function LateReader() {
      later.renders.push(useUniforms('') as Record<string, unknown>)
      return null
    }
    await act(async () => {
      render(
        <context.Provider value={store}>
          <LateReader />
        </context.Provider>,
      )
    })
    expect(store.getState().uniforms.uRoot, 'uRoot should be in the store at the root').toBeDefined()
    expect(later.first().uRoot, "a later '' scope read returned a root-level entry").toBeUndefined()
  })

  it("a whole-store read shows a scope's existing entries next to one declared this render", async () => {
    const store = makeStore()
    function Existing() {
      useUniforms({ uOld: 1 }, 'fx')
      return null
    }
    const view = await mount(store, <Existing />)
    const existingOld = (store.getState().uniforms.fx as Record<string, unknown>).uOld

    const read = recorder<Record<string, unknown> | undefined>()
    function Child() {
      read.renders.push(useUniforms().fx as Record<string, unknown> | undefined)
      return null
    }
    function Parent() {
      useUniforms({ uNew: 2 }, 'fx')
      return <Child />
    }
    await act(async () => {
      view.rerender(
        <context.Provider value={store}>
          <Existing />
          <Parent />
        </context.Provider>,
      )
    })

    // The child sees both the existing entry and the new one.
    expect(read.first()?.uOld, "the 'fx' entry declared earlier vanished while a new one was being declared").toBe(
      existingOld,
    )
    expect(read.first()?.uNew, "the 'fx' entry declared this render is missing from the child's first read").toBeDefined()
    expect(read.first()?.uNew, "the 'fx' entry the child saw is not the one in the store").toBe(
      (store.getState().uniforms.fx as Record<string, unknown>).uNew,
    )
  })
})

//* ── later renders, rebuilds, canvases and stores ──
// The same sharing after mount, after a rebuild, on a secondary canvas, and
// never across unrelated stores.

describe('readers stay in step with what other components declare', () => {
  it('an already-mounted child sees an entry its parent adds on a later render, in that render', async () => {
    const store = makeStore()
    const log: Array<[string, unknown, unknown]> = []

    function Child() {
      const root = useUniforms<{ uExtra: number }>().uExtra
      const scoped = useUniforms<{ b: number }>('fx').b
      log.push(['child', root, scoped])
      return null
    }
    function Parent({ extra }: { extra: boolean }) {
      const root = useUniforms(extra ? { uBase: 1, uExtra: 2 } : { uBase: 1 }).uExtra
      const scoped = useUniforms(extra ? { a: 1, b: 2 } : { a: 1 }, 'fx').b
      log.push(['parent', root, scoped])
      return <Child />
    }

    const view = await mount(store, <Parent extra={false} />)
    await act(async () => {
      view.rerender(
        <context.Provider value={store}>
          <Parent extra={true} />
        </context.Provider>,
      )
    })

    const i = log.findIndex(([who, root]) => who === 'parent' && root !== undefined)
    expect(i, 'the parent never declared the new entries').toBeGreaterThan(-1)
    expect(log[i + 1]?.[0], 'the child did not render after the parent in that pass').toBe('child')
    expect(log[i + 1][1], 'the mounted child missed the root uniform its parent added in the same render').toBe(log[i][1])
    expect(log[i + 1][2], 'the mounted child missed the scoped uniform its parent added in the same render').toBe(
      log[i][2],
    )
  })

  it('after a rebuild, a child sees the new generation its parent declares in that render', async () => {
    const store = makeStore()
    const log: Array<[string, unknown]> = []

    function Child() {
      log.push(['child', useUniforms<{ uR: number }>().uR])
      return null
    }
    function Parent() {
      log.push(['parent', useUniforms({ uR: 1 }).uR])
      return <Child />
    }

    await mount(store, <Parent />)
    const before = store.getState().uniforms.uR
    log.length = 0
    await act(async () => {
      rebuildAllUniforms(store)
    })

    const i = log.findIndex(([who, node]) => who === 'parent' && node !== before)
    expect(i, 'the rebuild did not produce a new uniform node').toBeGreaterThan(-1)
    expect(log[i + 1]?.[0], 'the child did not render after the parent in that pass').toBe('child')
    expect(log[i + 1][1], 'in the rebuild render the child saw the previous generation, not the one just declared').toBe(
      log[i][1],
    )
    expect(store.getState().uniforms.uR, 'the new generation should end up in the store').toBe(log[i][1])
  })

  it('a parent and child on a secondary canvas share an entry in the same render', async () => {
    const primary = makeStore()
    const secondary = makeStore()
    secondary.setState({ primaryStore: primary })
    const created = recorder<unknown>()
    const read = recorder<unknown>()

    function Child() {
      read.renders.push(useUniforms<{ uSec: number }>().uSec)
      return null
    }
    function Parent() {
      created.renders.push(useUniforms({ uSec: 1 }).uSec)
      return <Child />
    }

    await mount(secondary, <Parent />)

    expect(read.first(), "a child on a secondary canvas missed the uniform its parent declared").toBeDefined()
    expect(read.first(), "the secondary-canvas child's first read is not the parent's node").toBe(created.first())
  })

  it('a reader on one store never sees what a component declares on another', async () => {
    const a = makeStore()
    const b = makeStore()
    const read = recorder<unknown>()

    function DeclaresOnA() {
      useUniforms({ uOnlyA: 1 })
      return null
    }
    function ReadsOnB() {
      read.renders.push(useUniforms<{ uOnlyA: number }>().uOnlyA)
      return null
    }

    await act(async () => {
      render(
        <>
          <context.Provider value={a}>
            <DeclaresOnA />
          </context.Provider>
          <context.Provider value={b}>
            <ReadsOnB />
          </context.Provider>
        </>,
      )
    })

    for (const seen of read.renders) {
      expect(seen, "a reader on store B saw a uniform declared on store A").toBeUndefined()
    }
  })

  it('after a rebuild of one scope, scoped and whole-store readers see its new generation in that render', async () => {
    const store = makeStore()
    const log: Array<[string, unknown, unknown]> = []

    function Child() {
      const scoped = useUniforms<{ uR: number }>('fx').uR
      const whole = (useUniforms().fx as Record<string, unknown> | undefined)?.uR
      log.push(['child', scoped, whole])
      return null
    }
    function Parent() {
      const node = useUniforms({ uR: 1 }, 'fx').uR
      log.push(['parent', node, node])
      return <Child />
    }

    await mount(store, <Parent />)
    const before = (store.getState().uniforms.fx as Record<string, unknown>).uR
    log.length = 0
    await act(async () => {
      rebuildAllUniforms(store, 'fx')
    })

    const i = log.findIndex(([who, node]) => who === 'parent' && node !== before)
    expect(i, 'the rebuild did not produce a new uniform node in the scope').toBeGreaterThan(-1)
    expect(log[i + 1]?.[0], 'the child did not render after the parent in that pass').toBe('child')
    expect(log[i + 1][1], "in the rebuild render the scoped reader saw the scope's previous generation").toBe(log[i][1])
    expect(log[i + 1][2], "in the rebuild render the whole-store reader saw the scope's previous generation").toBe(
      log[i][1],
    )
    expect((store.getState().uniforms.fx as Record<string, unknown>).uR, 'the new generation should end up in the store').toBe(
      log[i][1],
    )
  })

  it('reading what a parent adds on a later render updates no other component while it renders', async () => {
    const store = makeStore()
    const errors = vi.spyOn(console, 'error').mockImplementation(noop)
    const seen = recorder<[unknown, unknown]>()
    let updates: string[] = []
    // Counts store notifications that arrive while one of the components below is rendering.
    let rendering = 0
    let writesDuringRender = 0
    const unsubscribe = store.subscribe(() => {
      if (rendering > 0) writesDuringRender++
    })

    // Names used by no other case, so React reports an update made while one of these renders.
    function LateEntryReader() {
      rendering++
      seen.renders.push([useUniforms<{ uExtra: number }>().uExtra, useUniforms<{ b: number }>('fx').b])
      rendering--
      return null
    }
    function LateEntryDeclarer({ extra }: { extra: boolean }) {
      rendering++
      useUniforms(extra ? { uBase: 1, uExtra: 2 } : { uBase: 1 })
      useUniforms(extra ? { a: 1, b: 2 } : { a: 1 }, 'fx')
      rendering--
      return <LateEntryReader />
    }
    // Another component already reading the same uniforms, at the root and in the scope.
    function LateEntryWatcher() {
      void useUniforms().uBase
      void useUniforms('fx').a
      return null
    }

    try {
      const view = await mount(
        store,
        <>
          <LateEntryWatcher />
          <LateEntryDeclarer extra={false} />
        </>,
      )
      await act(async () => {
        view.rerender(
          <context.Provider value={store}>
            <LateEntryWatcher />
            <LateEntryDeclarer extra={true} />
          </context.Provider>,
        )
      })
    } finally {
      unsubscribe()
      updates = errors.mock.calls.map((call) => String(call[0])).filter((m) => m.includes('Cannot update a component'))
      errors.mockRestore()
    }

    expect(writesDuringRender, 'the store changed while a component that declares or reads was rendering').toBe(0)
    expect(updates, 'a read during render updated another component while it was rendering').toEqual([])
    expect(seen.last()?.[0], 'the child never got the root uniform its parent added').toBe(store.getState().uniforms.uExtra)
    expect(seen.last()?.[1], 'the child never got the scoped uniform its parent added').toBe(
      (store.getState().uniforms.fx as Record<string, unknown>).b,
    )
  })
})

//* ── stable results ──
// When nothing new is declared, a whole-store read returns the scope objects
// that are in the store, and a reader that rendered before anything was
// declared picks the entry up later.

describe('reads stay stable when nothing new is declared', () => {
  it('a whole-store read returns the scope object that is in the store', async () => {
    const store = makeStore()
    const read = recorder<unknown>()
    function Creator() {
      useUniforms({ uA: 1 }, 'fx')
      return null
    }
    function Reader() {
      read.renders.push(useUniforms().fx)
      return null
    }
    const view = await mount(store, <Creator />)

    await act(async () => {
      view.rerender(
        <context.Provider value={store}>
          <Creator />
          <Reader />
        </context.Provider>,
      )
    })

    // Nothing new was declared in this render, so it is the store's own object.
    expect(read.first(), "with nothing declared this render, useUniforms().fx should be the store's own scope object").toBe(
      store.getState().uniforms.fx,
    )
  })

  it('still updates reactively when another component registers in a later render', async () => {
    // A reader that renders before anything is declared still picks the entry
    // up once it is in the store.
    const store = makeStore()
    const read = recorder<unknown>()
    function Reader() {
      read.renders.push(useUniforms<{ uLate: number }>().uLate)
      return null
    }
    function Late() {
      useUniforms({ uLate: 7 })
      return null
    }

    const view = await mount(store, <Reader />)
    expect(read.last(), 'nothing has declared uLate yet').toBeUndefined()

    await act(async () => {
      view.rerender(
        <context.Provider value={store}>
          <Reader />
          <Late />
        </context.Provider>,
      )
    })

    expect(read.last(), 'the reader did not pick up uLate once it was in the store').toBeDefined()
    expect(read.last(), 'the reader holds a different node than the uLate in the store').toBe(store.getState().uniforms.uLate)
  })
})

//* ── the render pipeline's callbacks ──
// The pipeline callbacks can take the shared resources from the state they are
// handed. They see what other components declare, wherever the pipeline
// component sits; a resource they looked for before anything declared it
// rebuilds the pipeline once it is declared, in time for the next frame; and
// nothing else rebuilds it. Checks that concern a frame render one first.

describe('the render pipeline callbacks see the resources other components declare', () => {
  /** The scene, camera and renderer the pipeline hook reads from the canvas state. */
  function seedRenderer(store: RootStore) {
    // A near-bare renderer is enough: the pipeline only keeps the reference until it renders.
    store.setState({
      scene: new THREE.Scene(),
      camera: new THREE.PerspectiveCamera(),
      renderer: { isWebGPURenderer: true },
      isLegacy: false,
    } as any)
  }

  /** One frame of the canvas's render job, with the GPU draw itself stubbed out. */
  async function renderFrame(store: RootStore) {
    await act(async () => {
      const pipeline = store.getState().renderPipeline
      if (pipeline) vi.spyOn(pipeline, 'render').mockImplementation(noop)
      store.getState().internal.renderOverride?.()
    })
  }

  function rerender(view: ReturnType<typeof render>, store: RootStore, children: React.ReactNode) {
    return act(async () => {
      view.rerender(<context.Provider value={store}>{children}</context.Provider>)
    })
  }

  it('a pipeline component sees the uniforms its parent declares, at the root and in a scope', async () => {
    const store = makeStore()
    seedRenderer(store)
    const runs: Array<[unknown, unknown]> = []

    function Effects() {
      useRenderPipeline(({ renderPipeline, uniforms }) => {
        const blur = uniforms.blurAmount
        runs.push([blur, (uniforms.fx as Record<string, unknown> | undefined)?.amount])
        if (blur) renderPipeline.outputNode = blur
      })
      return null
    }
    function Experience() {
      useUniforms({ blurAmount: 1 })
      useUniforms({ amount: 2 }, 'fx')
      return <Effects />
    }

    await mount(store, <Experience />)
    await renderFrame(store)

    const { uniforms, renderPipeline } = store.getState()
    expect(runs.length, 'the pipeline callbacks never ran').toBeGreaterThan(0)
    const [blur, amount] = runs[runs.length - 1]
    expect(blur, "the pipeline was left built without the parent's root uniform").toBe(uniforms.blurAmount)
    expect(amount, "the pipeline was left built without the parent's scoped uniform").toBe(
      (uniforms.fx as Record<string, unknown>).amount,
    )
    expect(renderPipeline!.outputNode, "the pipeline's graph does not use the parent's uniform").toBe(uniforms.blurAmount)
  })

  it('the setup callback sees nodes, buffers and storage a later sibling declares', async () => {
    const store = makeStore()
    seedRenderer(store)
    const positions = new Float32Array(4)
    const heightMap = new THREE.StorageTexture(8, 8)
    const runs: Array<[unknown, unknown, unknown]> = []

    function Effects() {
      useRenderPipeline(
        () => {},
        ({ nodes, buffers, gpuStorage }) => {
          runs.push([nodes.wobble, buffers.positions, (gpuStorage.terrain as Record<string, unknown> | undefined)?.heightMap])
        },
      )
      return null
    }
    function Scene() {
      useNodes(() => ({ wobble: float(1) }))
      useBuffers(() => ({ positions }))
      useGPUStorage(() => ({ heightMap }), 'terrain')
      return null
    }

    // The pipeline component comes first in the tree.
    await mount(
      store,
      <>
        <Effects />
        <Scene />
      </>,
    )
    await renderFrame(store)

    expect(runs.length, 'the setup callback never ran').toBeGreaterThan(0)
    const [wobble, buffer, storage] = runs[runs.length - 1]
    expect(wobble, "the pipeline was left built without the sibling's node").toBe(store.getState().nodes.wobble)
    expect(buffer, "the pipeline was left built without the sibling's buffer").toBe(positions)
    expect(storage, "the pipeline was left built without the sibling's scoped storage").toBe(heightMap)
  })

  it('a uniform the callbacks looked for rebuilds the pipeline once a later component declares it', async () => {
    const store = makeStore()
    seedRenderer(store)
    const runs: unknown[] = []
    let showLate: (show: boolean) => void = noop

    function Effects() {
      useRenderPipeline(({ renderPipeline, uniforms }) => {
        const late = uniforms.uLate
        runs.push(late)
        if (late) renderPipeline.outputNode = late
      })
      return null
    }
    function Late() {
      useUniforms({ uLate: 1 })
      return null
    }
    // Mounts the declaring component later, from its own state.
    function Loader() {
      const [show, setShow] = React.useState(false)
      showLate = setShow
      return show ? <Late /> : null
    }

    await mount(
      store,
      <>
        <Effects />
        <Loader />
      </>,
    )
    await renderFrame(store)
    expect(runs.length, 'the pipeline callbacks never ran').toBeGreaterThan(0)
    expect(runs[runs.length - 1], 'nothing has declared uLate yet').toBeUndefined()
    // As after a rendered frame: the compiled graph is up to date.
    store.getState().renderPipeline!.needsUpdate = false
    const before = runs.length

    await act(async () => showLate(true))
    await renderFrame(store)

    const late = store.getState().uniforms.uLate
    expect(late, 'uLate should be in the store').toBeDefined()
    expect(runs.length, 'the pipeline was not rebuilt once uLate was declared').toBeGreaterThan(before)
    expect(runs[runs.length - 1], 'the rebuilt pipeline does not use the declared uLate').toBe(late)
    const { renderPipeline } = store.getState()
    expect(renderPipeline!.outputNode, "the rebuilt graph is not the pipeline's output").toBe(late)
    expect(renderPipeline!.needsUpdate, 'the rebuilt graph was not marked for recompilation').toBe(true)
  })

  it('a callback that fails for want of a uniform rebuilds the pipeline once it is declared', async () => {
    const store = makeStore()
    seedRenderer(store)
    const seen: unknown[] = []

    function Effects() {
      useRenderPipeline(({ renderPipeline, uniforms }) => {
        const late = uniforms.uLate
        seen.push(late)
        // Throws while uLate is missing, as building a graph from an absent uniform does.
        renderPipeline.outputNode = late.mul(2)
      })
      return null
    }
    function Late() {
      useUniforms({ uLate: 1 })
      return null
    }

    const view = await mount(store, <Effects />)
    await renderFrame(store)
    expect(seen.length, 'the pipeline callbacks never ran').toBeGreaterThan(0)
    expect(seen[seen.length - 1], 'nothing has declared uLate yet').toBeUndefined()

    await rerender(
      view,
      store,
      <>
        <Effects />
        <Late />
      </>,
    )
    await renderFrame(store)

    const late = store.getState().uniforms.uLate
    expect(late, 'uLate should be in the store').toBeDefined()
    expect(seen[seen.length - 1], 'the pipeline was not rebuilt with uLate after its first build failed').toBe(late)
    expect(store.getState().renderPipeline!.outputNode, 'the pipeline still renders the passthrough from before uLate existed').not.toBe(
      store.getState().passes!.scenePass,
    )
  })

  it('entries declared later in an existing scope, a node, a buffer and storage rebuild the pipeline that looked for them', async () => {
    const store = makeStore()
    seedRenderer(store)
    const main: Array<[unknown, unknown]> = []
    const setup: Array<[unknown, unknown]> = []
    const positions = new Float32Array(4)
    const heightMap = new THREE.StorageTexture(8, 8)

    function Existing() {
      useUniforms({ a: 1 }, 'fx')
      return null
    }
    function Effects() {
      useRenderPipeline(
        ({ uniforms, nodes }) => {
          main.push([(uniforms.fx as Record<string, unknown>).b, nodes.glow])
        },
        ({ buffers, gpuStorage }) => {
          setup.push([buffers.positions, (gpuStorage.terrain as Record<string, unknown> | undefined)?.heightMap])
        },
      )
      return null
    }
    function AddsB() {
      useUniforms({ b: 2 }, 'fx')
      return null
    }
    function AddsGlow() {
      useNodes(() => ({ glow: float(3) }))
      return null
    }
    function AddsData() {
      useBuffers(() => ({ positions }))
      useGPUStorage(() => ({ heightMap }), 'terrain')
      return null
    }

    const view = await mount(
      store,
      <>
        <Existing />
        <Effects />
      </>,
    )
    await renderFrame(store)
    expect(main.length, 'the pipeline callbacks never ran').toBeGreaterThan(0)
    expect(main[main.length - 1], 'neither fx.b nor the glow node exists yet').toEqual([undefined, undefined])
    expect(setup[setup.length - 1], 'neither the buffer nor the storage exists yet').toEqual([undefined, undefined])

    await rerender(
      view,
      store,
      <>
        <Existing />
        <Effects />
        <AddsB />
      </>,
    )
    await renderFrame(store)
    const b = (store.getState().uniforms.fx as Record<string, unknown>).b
    expect(b, 'fx.b should be in the store').toBeDefined()
    expect(main[main.length - 1][0], 'the pipeline was not rebuilt with the fx.b declared in an existing scope').toBe(b)

    await rerender(
      view,
      store,
      <>
        <Existing />
        <Effects />
        <AddsB />
        <AddsGlow />
      </>,
    )
    await renderFrame(store)
    const glow = store.getState().nodes.glow
    expect(glow, 'the glow node should be in the store').toBeDefined()
    expect(main[main.length - 1][1], 'the pipeline was not rebuilt with the node declared later').toBe(glow)

    await rerender(
      view,
      store,
      <>
        <Existing />
        <Effects />
        <AddsB />
        <AddsGlow />
        <AddsData />
      </>,
    )
    await renderFrame(store)
    expect(setup[setup.length - 1][0], 'the setup callback was not re-run with the buffer declared later').toBe(positions)
    expect(setup[setup.length - 1][1], 'the setup callback was not re-run with the storage declared later').toBe(heightMap)
  })

  it('declarations the callbacks never read do not rebuild the pipeline', async () => {
    const store = makeStore()
    seedRenderer(store)
    let runs = 0

    function Blur() {
      useUniforms({ blurAmount: 1 })
      useUniforms({ a: 1 }, 'fx')
      return null
    }
    function Effects() {
      useRenderPipeline(({ uniforms }) => {
        runs++
        // One uniform that exists, one scoped entry that exists, one optional uniform nobody declares.
        void uniforms.blurAmount
        void (uniforms.fx as Record<string, unknown>).a
        void uniforms.optional
      })
      return null
    }
    function Unrelated() {
      useUniforms({ uOther: 1 })
      useUniforms({ zzz: 2 }, 'fx')
      useNodes(() => ({ other: float(1) }))
      return null
    }

    const view = await mount(
      store,
      <>
        <Blur />
        <Effects />
      </>,
    )
    await renderFrame(store)
    expect(runs, 'the pipeline callbacks never ran').toBeGreaterThan(0)
    const before = runs

    await rerender(
      view,
      store,
      <>
        <Blur />
        <Effects />
        <Unrelated />
      </>,
    )
    await renderFrame(store)

    expect(store.getState().uniforms.uOther, 'the unrelated uniform should be in the store').toBeDefined()
    expect((store.getState().uniforms.fx as Record<string, unknown>).zzz, 'fx.zzz should be in the store').toBeDefined()
    expect(runs, 'the pipeline was rebuilt for declarations its callbacks never read').toBe(before)
  })

  it('part of the scene that is still loading does not keep the pipeline rebuilding', async () => {
    const store = makeStore()
    seedRenderer(store)
    let runs = 0
    const errSpy = vi.spyOn(console, 'error').mockImplementation(noop)

    // Declares a uniform, then waits on data that never arrives.
    const pending = new Promise<never>(() => {})
    function Loading() {
      useUniforms({ uLoading: 1 })
      throw pending
    }
    function Effects() {
      useRenderPipeline(({ uniforms }) => {
        runs++
        void uniforms.uLoading
      })
      return null
    }

    let failure: unknown = null
    try {
      await mount(
        store,
        <>
          <React.Suspense fallback={null}>
            <Loading />
          </React.Suspense>
          <Effects />
        </>,
      )
      await renderFrame(store)
    } catch (error) {
      failure = error
    } finally {
      errSpy.mockRestore()
    }

    expect(failure, 'mounting next to a loading component failed').toBeNull()
    expect(store.getState().renderPipeline, 'the pipeline was not built').toBeTruthy()
    expect(runs, 'the pipeline callbacks never ran').toBeGreaterThan(0)
    expect(runs, 'the pipeline kept rebuilding while nothing it read changed').toBeLessThanOrEqual(3)
  })

  it('a pipeline that was reset is not brought back when a uniform it looked for is declared', async () => {
    const store = makeStore()
    seedRenderer(store)
    let api: ReturnType<typeof useRenderPipeline> = null!

    function Effects() {
      api = useRenderPipeline(({ uniforms }) => {
        void uniforms.uLate
      })
      return null
    }
    function Late() {
      useUniforms({ uLate: 1 })
      return null
    }

    const view = await mount(store, <Effects />)
    expect(store.getState().renderPipeline, 'the pipeline was not built').toBeTruthy()
    await act(async () => api.reset())
    expect(store.getState().renderPipeline, 'reset() should tear the pipeline down').toBeNull()

    await rerender(
      view,
      store,
      <>
        <Effects />
        <Late />
      </>,
    )
    await renderFrame(store)

    expect(store.getState().uniforms.uLate, 'uLate should be in the store').toBeDefined()
    expect(store.getState().renderPipeline, 'a reset pipeline came back').toBeNull()
    expect(store.getState().internal.renderOverride, 'a reset pipeline took over rendering again').toBeNull()
  })
})
