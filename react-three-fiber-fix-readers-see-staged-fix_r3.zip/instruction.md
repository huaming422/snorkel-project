## Task

On the v10 branch the WebGPU motion blur example comes up empty. Shader compilation fails and the console fills with GPU validation errors, while the other WebGPU examples look fine. The example is correct as written, so the fault is in the library.

Components share nodes, uniforms, buffers and storage through the TSL hooks, reading either everything that is registered or one named scope. Whatever one component declares should already be there for the others that read it in that same render, for all four resource types, without changing anything else about how those hooks behave.

The render pipeline hook needs the same treatment. Its callbacks can take those resources from the state they are handed rather than from a hook, and those reads should see what the rest of the scene declares, wherever the pipeline component sits in the tree. When the callbacks look for a resource nobody has declared yet, the pipeline should rebuild its graph once it is declared, so the next frame renders with it. Rebuilding is costly, though: declarations the callbacks never read must not trigger it, a part of the scene that is still loading must not keep it going, and a pipeline that was reset stays torn down.
