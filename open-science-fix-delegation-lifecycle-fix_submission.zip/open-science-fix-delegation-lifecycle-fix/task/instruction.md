## Task

the delegation subsystem misreports state and leaks capacity under concurrent load. a handful of reproductions, all when several things hit the same session at once.

when a running batch of delegated children has one child independently continued with more work at nearly the same moment, reading back the batch's result can return the continuation's outcome instead of the batch's own, and the batch's result disappears.

a child paused on a user question reads as finished, both when you collect the batch's results and when you read that child's status directly. it should read as waiting on the user in both, not done.

stopping a session, or just the active branch, can miss children that were mid-start when stop ran, and they keep going past it. anything begun after stop fully returns should still run normally.

handing a continuation to the runtime can fail after the work was already recorded, leaving a child stuck running but never running and still holding its reserved capacity slot, so the subsystem slowly runs out of room to start anything. cleanup has to be complete: no stuck child, the capacity freed, the failed message marked failed, and any answer the user already confirmed kept intact.

preparing a child that needs several inputs resolved at once, a failure in one leaks what the others already acquired, including inputs that finished just after the failure landed. partial failure should never leave an acquired resource behind.

none of this changes anything a caller sees: same public interfaces, stored data, and UI. it's internal bookkeeping, no new persisted state or schema change wanted. the existing suite reproduces these under controlled concurrency. dig in and fix it.
