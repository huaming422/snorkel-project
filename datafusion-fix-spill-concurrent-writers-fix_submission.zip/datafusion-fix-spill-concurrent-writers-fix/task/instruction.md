## Task

we've got an intermittent hang on sorted queries that are running tight on memory. once one of these queries gets big enough that it starts spilling intermediate results out to disk, it occasionally just wedges and never finishes. most of the time the exact same query over the exact same data completes fine, and then every so often it stalls and sits there forever until you kill it. it seems to depend on timing, load, and how much parallelism the plan ends up using, and turning the memory limit down so it spills more often makes it much easier to trigger.

can you dig into the on-disk path these sorted queries fall back to when they run low on memory, figure out why they sometimes hang, and fix it so they reliably finish? results still need to come back fully ordered with nothing dropped.
