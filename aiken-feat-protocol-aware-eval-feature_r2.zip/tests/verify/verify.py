"""Structural / regression guard for `aiken-feat-protocol-aware-eval`.

This verifier covers the pass_to_pass structural criterion: the whole `uplc`
crate must still COMPILE after the change, and the crate's pre-existing unit
test suite must still PASS. The feature is purely additive — a correct solution
threads an explicit protocol major version through the machine, cost model,
value-memory, builtin dispatch, the `Program` entry points, and the tx phase-two
path WITHOUT breaking any existing caller or the existing public API.

Both checks are behavioral regression gates on a PRE-EXISTING interface
(`cargo check` / the crate's own `--lib` test binary); neither imports or names
any implementation-invented symbol, so any valid additive implementation passes
and only a build break / existing-behavior regression fails.

Runs under VERIFIER_PYTHON (no repo imports) — just shells cargo via subprocess.
The cargo toolchain and a warm offline target dir are provided by the image +
tests/test-setup.sh.
"""

from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path

import pytest

REPO_DIR = Path(f"/repo/{os.environ.get('REPO_NAME', 'aiken')}")

# Offline: the image baked the full dependency closure and test-setup.sh warmed
# the target dir. A cache miss should fail fast rather than hang on the cut net.
_CARGO_ENV = {**os.environ, "CARGO_NET_OFFLINE": "true"}


def _run_cargo(*args: str, timeout: int = 600) -> subprocess.CompletedProcess:
    cmd = ["cargo", *args]
    return subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=timeout,
        cwd=str(REPO_DIR),
        env=_CARGO_ENV,
        check=False,
    )


_RESULT_LINE = re.compile(
    r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed",
    re.MULTILINE,
)


def test_uplc_crate_still_compiles() -> None:
    """`cargo check -p uplc` must succeed.

    The change spans ast.rs, machine.rs, cost_model.rs, runtime.rs, value.rs,
    tx.rs and tx/eval.rs. Threading a new protocol parameter through shared
    signatures (e.g. the machine constructor, builtin `call`, value-memory)
    while leaving a caller inconsistent, or altering an existing public entry
    point's signature so an existing caller no longer type-checks, breaks the
    build here. A correct additive solution compiles cleanly, exactly as the
    pre-fix tree does.
    """
    proc = _run_cargo("check", "-p", "uplc", "--offline", timeout=600)
    assert proc.returncode == 0, (
        "`cargo check -p uplc` failed — the uplc crate no longer compiles. A "
        "correct solution adds the protocol-aware path alongside the existing "
        "API without breaking any caller.\n"
        f"--- last stdout ---\n{proc.stdout[-2000:]}\n"
        f"--- last stderr ---\n{proc.stderr[-3000:]}"
    )


def test_uplc_existing_unit_tests_pass() -> None:
    """The crate's pre-existing `--lib` unit suite must still pass.

    This guards the "purely additive, existing behavior preserved" contract:
    the language-only entry points, the existing cost-model construction, and
    the default value-memory computation keep their pre-fix behavior. A
    solution that repurposes a shared code path (changing default semantics,
    perturbing the existing cost model, or altering value-memory) instead of
    adding a parallel protocol-aware path regresses the crate's own tests.
    """
    proc = _run_cargo("test", "-p", "uplc", "--lib", "--offline", timeout=720)
    combined = proc.stdout + "\n" + proc.stderr
    summaries = _RESULT_LINE.findall(combined)

    assert proc.returncode == 0, (
        f"`cargo test -p uplc --lib` exited with {proc.returncode} — a "
        "pre-existing unit test regressed (existing behavior must be "
        "preserved; the feature is additive).\n"
        f"--- last stdout ---\n{proc.stdout[-2000:]}\n"
        f"--- last stderr ---\n{proc.stderr[-3000:]}"
    )
    assert summaries, (
        "expected 'test result: …' summary lines from cargo test, got none — "
        "did the uplc test binary fail to compile?\n"
        f"--- stdout ---\n{proc.stdout[-2000:]}"
    )
    total_passed = sum(int(p) for _, p, _ in summaries)
    total_failed = sum(int(f) for _, _, f in summaries)
    assert total_failed == 0, (
        f"{total_failed} pre-existing uplc unit test(s) FAILED — existing "
        "behavior was not preserved.\n"
        f"--- last stdout ---\n{proc.stdout[-2000:]}"
    )
    assert total_passed > 0, (
        "expected at least one uplc unit test to pass; saw zero (test binary "
        "likely failed to build).\n"
        f"--- last stdout ---\n{proc.stdout[-2000:]}"
    )


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v", "--tb=short"]))
