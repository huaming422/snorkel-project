#!/usr/bin/env bash
# test-setup.sh — sourced before the verifier runs (verifier phase, after the
# agent has edited the tree). The image already baked the full dependency
# closure (cargo registry/git cache under /opt/cargo warmed at build time, plus
# a complete `cargo build --locked --tests` of the workspace at the base
# commit), so this runs with cargo in offline mode.
set -euo pipefail

cd /repo/aiken

# Force cargo offline: every crate the workspace needs is already in the
# registry/git cache under CARGO_HOME (/opt/cargo). A cache miss should fail
# fast rather than hang against the cut network during the verifier phase.
export CARGO_NET_OFFLINE=true

# Warm the build for the crate the verifier exercises. The agent's edits are
# incremental against the populated target dir (/opt/cache/cargo-target), so
# this compiles only the changed crates. `--no-run` builds the uplc test
# binary without executing it, so the verifier's own `cargo test` invocation
# is near-instant and deterministic.
echo "test-setup: building uplc test binary (offline, incremental)..."
cargo test --locked --offline -p uplc --no-run

echo "test-setup: ready."
