#!/usr/bin/env bash
# validation-setup.sh — prepare the container for the cargo-test validation
# stories. Runs AFTER the agent has edited the tree, BEFORE the validation
# agent's generated integration tests run.
#
# The image already baked the full dependency closure (cargo registry/git cache
# under CARGO_HOME warmed at build time, plus a complete offline build of the
# uplc workspace at the base commit into the shared target dir). So this runs
# entirely offline and only needs to (a) pin the toolchain, (b) warm the uplc
# test binary against the agent's edits, and (c) smoke-guard that the crate's
# integration-test harness actually builds before any story runs.
set -euo pipefail

cd /repo/aiken

# Force offline: every crate is already cached under CARGO_HOME. A cache miss
# should fail fast rather than hang against the cut network.
export CARGO_NET_OFFLINE=true

# Pin the toolchain ahead of any stray cargo/rustc on PATH. The repo pins
# 1.94.1; honor the repo's rust-toolchain file if present, else force the pin.
if [ -f rust-toolchain.toml ] || [ -f rust-toolchain ]; then
  echo "validation-setup: using repo-pinned toolchain"
else
  export RUSTUP_TOOLCHAIN=1.94.1
  echo "validation-setup: forcing toolchain 1.94.1"
fi

cargo --version
rustc --version

# Warm the uplc test target so the first story's `cargo test --test <file>` is
# near-instant. `--no-run` builds the test harness (including a dummy
# integration test) without executing it; the agent's edits compile
# incrementally against the populated target dir.
echo "validation-setup: building uplc test binary (offline, incremental)..."
if ! cargo test --locked --offline -p uplc --no-run > /tmp/val-setup-build.log 2>&1; then
  echo "validation-setup: FAILED to build uplc test binary — the crate does not compile."
  tail -120 /tmp/val-setup-build.log
  exit 1
fi

# Smoke guard: a trivial integration test must compile AND run against the
# edited crate's public API. If this fails, the environment is broken and the
# trial must error loudly rather than silently score every story 0.
SMOKE_DIR=crates/uplc/tests
SMOKE_FILE="$SMOKE_DIR/_validation_setup_smoke_test.rs"
cleanup() { rm -f "$SMOKE_FILE"; }
trap cleanup EXIT
cat > "$SMOKE_FILE" <<'RS'
// Smoke guard written by validation-setup.sh: proves the uplc integration-test
// harness builds and the public evaluation seam is reachable. Removed on exit.
use num_bigint::BigInt;
use uplc::ast::{Constant, NamedDeBruijn, Program, Term};
use uplc::builtins::DefaultFunction;
use uplc::machine::cost_model::ExBudget;
use uplc::Language;

#[test]
fn validation_setup_smoke() {
    // Build `addInteger 1 2`, evaluate via the pre-existing language-only path,
    // and confirm the EvalResult seam is reachable.
    let program = Program::<NamedDeBruijn> {
        version: (1, 1, 0),
        term: Term::Apply {
            function: Term::Apply {
                function: Term::Builtin(DefaultFunction::AddInteger).into(),
                argument: Term::Constant(Constant::Integer(BigInt::from(1)).into()).into(),
            }
            .into(),
            argument: Term::Constant(Constant::Integer(BigInt::from(2)).into()).into(),
        },
    };
    let result = program.eval_version(ExBudget::default(), &Language::PlutusV3);
    // We only need the seam to be callable; don't assert specifics here.
    let _ = result.cost();
    assert!(result.result().is_ok());
}
RS

echo "validation-setup: running integration-test smoke guard..."
if ! cargo test --offline -p uplc --test _validation_setup_smoke_test \
    -- --test-threads=1 > /tmp/val-setup-smoke.log 2>&1; then
  echo "validation-setup: SMOKE GUARD FAILED — uplc integration tests do not build/run."
  tail -120 /tmp/val-setup-smoke.log
  exit 1
fi

echo "validation-setup: ready."
