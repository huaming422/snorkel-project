## Task

`uplc` can be told which Plutus language version a script targets, but not which Cardano protocol era it runs under. The ledger changes how some builtins are costed from one era to the next, so a script evaluated with the right language version can still come back with a different execution budget than it really has on chain.

We need to evaluate a program under an explicit protocol major version and have it follow the era rules below, for all three Plutus languages. Add this next to what is there: the language-only entry points keep their signatures, and keep their results for cost vectors no longer than today's. Everything stays inside the `uplc` crate, and the crate and its existing tests still have to build and pass.

The era rules: Chang is protocol major version 9 and Van Rossem is 11, and PlutusV3 exists only from Chang on. Before Chang, `multiplyInteger`'s CPU cost grows with the sum of the two argument sizes rather than their product. From Van Rossem on, `divideInteger` and `modInteger` no longer charge a flat CPU cost when the first argument is the smaller one: they apply their usual size model with the larger argument size first and the smaller second. Also from Van Rossem on, for every language, a string's memory size is its UTF-8 length in bytes divided by four and rounded up, with an empty string at 0, instead of its character count. The PlutusV3 cost vector under Van Rossem is longer than today's: it keeps every existing entry where it is and appends entries for builtins this repo cannot run yet.

## User stories / requirements

- Evaluating under an explicit protocol major version picks that era's builtin costing for every Plutus language, so the same program and cost vector can cost differently before and after Chang and at Van Rossem. A protocol whose rules match today's gives exactly the language-only result.
- Under Van Rossem, a PlutusV3 cost vector longer than today's still costs every builtin whose entries it carries, while a vector that stops short of a builtin's entries leaves it at the unavailable cost, so running it fails.
- From Van Rossem on, every Plutus language sizes strings by the Van Rossem rule, so multi-byte text and the empty string cost differently than before, while earlier protocols and language-only evaluation keep counting characters.
