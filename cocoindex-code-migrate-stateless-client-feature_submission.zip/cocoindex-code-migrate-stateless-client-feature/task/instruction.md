## Task

We want to simplify how the `ccc` command line talks to its background indexing daemon: move the CLI and daemon to a stateless, per-operation connection model instead of one long-lived connection that carries many requests. Two related improvements come along with it: a running daemon should keep up with a project's edited indexing settings, and daemon shutdown should be more dependable. Nothing is broken here, this is a deliberate cleanup of the connection model rather than a bug to chase down.

Keep the user-facing `ccc` CLI the same throughout: indexing, searching, and status should behave exactly as they do today. The daemon's wire-protocol message types are fixed as well, so the request and response formats the CLI and daemon exchange must not change — the existing response types, among them `HandshakeResponse`, `DaemonStatusResponse`, and `ProjectStatusResponse`, keep their current names and shapes.

## User stories / requirements

- Each client operation uses its own connection: it connects, performs the version handshake, sends one request, and reads the response. The daemon closes the connection after that single request, so another request needs a new connection, and sequential operations each succeed over their own. The handshake precedes the request on every connection.
- When a user edits a project's indexing settings and re-indexes, the change takes effect against the same running daemon on the next index run, with no daemon restart required.
- When a user edits a project's ignore rules and re-indexes, the change takes effect against the same running daemon on the next index run, with no daemon restart required. Adding a file to the ignore rules drops it from the next index; removing it again brings the file back.
- Indexing a codebase and then searching it returns relevant results through the normal command-line flow, the same as a user sees today.
- Asking the daemon to stop makes it exit promptly; once it has stopped, its socket and PID file are gone, so a fresh daemon can be started afterward.
