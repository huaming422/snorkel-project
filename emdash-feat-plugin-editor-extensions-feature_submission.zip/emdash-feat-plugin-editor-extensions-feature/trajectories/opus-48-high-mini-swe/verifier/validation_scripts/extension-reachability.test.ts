// @ts-nocheck
import { describe, expect, it } from "vitest";
import { getTestCases } from "./validationParams";

import type { EmDashConfig } from "../../../../src/astro/integration/runtime.js";
import { EmDashRuntime } from "../../../../src/emdash-runtime.js";
import type { RuntimeDependencies } from "../../../../src/emdash-runtime.js";
import { definePlugin } from "../../../../src/plugins/define-plugin.js";
import { createHookPipeline } from "../../../../src/plugins/hooks.js";
import { handleContentCreate } from "../../../../src/api/handlers/content.js";
import { setupTestDatabaseWithCollections, teardownTestDatabase } from "../../../utils/test-db.js";
import { injectCoreRoutes } from "../../../../src/astro/integration/routes.js";
import { POST } from "../../../../src/astro/routes/api/plugins/[pluginId]/[...path].js";

const ROLE = { subscriber: 10, contributor: 20, author: 30, editor: 40, admin: 50 };
const EXTENSION_ID = "test-panel";
const ROUTE_NAME = "editor/seo";

// Convert an Astro route pattern to a regex for URL matching.
// [name] matches one path segment; [...name] matches one or more trailing segments.
const toRegex = (pattern: string) => {
  const body = pattern
    .split("/")
    .map((seg) =>
      /^\[\.\.\..+\]$/.test(seg) ? "[^/]+(?:/[^/]+)*"
      : /^\[.+\]$/.test(seg) ? "[^/]+"
      : seg.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"))
    .join("/");
  return new RegExp("^" + body + "$");
};

describe("extension-reachability", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    const db = await setupTestDatabaseWithCollections();
    try {
      // Seed saved entry owned by inputs.owner_id
      const created = await handleContentCreate(db, "post", {
        data: { title: "Saved entry" },
        authorId: inputs.owner_id,
        locale: inputs.locale,
        status: "published",
      });
      const saved = (created as any).data.item;

      const captured = { invoked: 0, ctx: null as any };
      const validResponse = { blocks: [] };

      // Declare ONE enabled panel extension whose declared collections include "post"
      const plugin = definePlugin({
        id: "editor-fixture",
        version: "1.0.0",
        admin: {
          editorPanels: [
            { id: EXTENSION_ID, collection: "post", title: "Test Panel", route: ROUTE_NAME },
          ],
        },
        routes: {
          [ROUTE_NAME]: {
            public: false,
            permission: "content:edit_own" as any,
            handler: async (ctx: any) => {
              captured.invoked += 1;
              captured.ctx = ctx;
              return validResponse;
            },
          },
        },
      });

      const pipelineFactoryOptions = { db };
      const hooks = createHookPipeline([plugin], pipelineFactoryOptions);
      const runtimeDeps: RuntimeDependencies = {
        config: {},
        plugins: [plugin],
        createDialect: () => { throw new Error("unused"); },
        createStorage: null,
        sandboxEnabled: false,
        sandboxedPluginEntries: [],
        createSandboxRunner: null,
      };

      const runtime = new EmDashRuntime({
        db,
        storage: null,
        configuredPlugins: [plugin],
        sandboxedPlugins: new Map(),
        sandboxedPluginEntries: [],
        hooks,
        enabledPlugins: new Set([plugin.id]),
        pluginStates: new Map(),
        config: {} as EmDashConfig,
        mediaProviders: new Map(),
        mediaProviderEntries: [],
        cronExecutor: null,
        cronScheduler: null,
        emailPipeline: null,
        allPipelinePlugins: [plugin],
        pipelineFactoryOptions,
        runtimeDeps,
        pipelineRef: { current: hooks },
      });

      // PART A: Collect the app's mounted route table and check if the capability URL is served.
      // The capability URL is the path a client would send a panel extension request to.
      // Since no dedicated route was added by the patch, we use the pre-existing plugin
      // request path: /_emdash/api/plugins/{pluginId}/{routeName}
      const routes: Array<{ pattern: string; entrypoint: string }> = [];
      injectCoreRoutes((route) => routes.push(route));

      const urlPath = `/_emdash/api/plugins/${plugin.id}/${ROUTE_NAME}`;
      const mounted = routes.some((r) => toRegex(r.pattern).test(urlPath));
      const registered = mounted ? "yes" : "no";

      // PART B: Drive the capability through the handler the app mounts for urlPath.
      // Invoke it exactly as the extension-request happy panel case does:
      // authenticated owner, same-origin signal, private serving route,
      // grammar-valid block_action body, params matching the handler's dynamic segments.
      // Provide all required RouteCallerInput fields.
      const user = {
        id: inputs.owner_id,
        role: ROLE.author,
        email: `${inputs.owner_id}@example.com`,
        name: "Test User",
        createdAt: "2024-01-01T00:00:00.000Z",
      };
      const bodyObj = { type: "block_action", action_id: "do_thing", block_id: "blk-1" };

      const url = `http://localhost${urlPath}`;
      const request = new Request(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-EmDash-Request": "1",
        },
        body: JSON.stringify(bodyObj),
      });

      const params = { pluginId: plugin.id, path: ROUTE_NAME };
      const locals = { emdash: runtime, user, tokenScopes: undefined };

      const res = await POST({ params, request, locals, cache: { enabled: false } });

      const ctxText = JSON.stringify(captured.ctx);
      // "served" is "yes" only when:
      // - the response is a success (< 300),
      // - the plugin was invoked, AND
      // - the reloaded entry's real id reached the plugin (canonical context)
      const served =
        (res.status < 300 && captured.invoked > 0 && ctxText.includes(saved.id))
          ? "yes"
          : "no";

      expect(registered, "registered mismatch").toBe(expected.registered);
      expect(served, "served mismatch").toBe(expected.served);
    } finally {
      await teardownTestDatabase(db);
    }
  }, 120_000);
});
