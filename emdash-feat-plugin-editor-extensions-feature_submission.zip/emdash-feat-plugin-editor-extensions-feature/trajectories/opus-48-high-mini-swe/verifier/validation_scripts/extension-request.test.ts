// @ts-nocheck
import { describe, expect, it, vi } from "vitest";
import { getTestCases } from "./validationParams";

import type { EmDashConfig } from "../../../../src/astro/integration/runtime.js";
import { EmDashRuntime } from "../../../../src/emdash-runtime.js";
import type { RuntimeDependencies } from "../../../../src/emdash-runtime.js";
import { definePlugin } from "../../../../src/plugins/define-plugin.js";
import { createHookPipeline } from "../../../../src/plugins/hooks.js";
import { handleContentCreate } from "../../../../src/api/handlers/content.js";
import { setupTestDatabaseWithCollections, teardownTestDatabase } from "../../../utils/test-db.js";
import { POST } from "../../../../src/astro/routes/api/plugins/[pluginId]/[...path].js";

const ROLE = { subscriber: 10, contributor: 20, author: 30, editor: 40, admin: 50 };

async function buildHost({
  db,
  surface,
  routeName,
  routePublic,
  pluginResponse,
  enabled = true,
}: {
  db: any;
  surface: "panel" | "action";
  routeName: string;
  routePublic: boolean;
  pluginResponse: "valid" | "invalid";
  enabled?: boolean;
}) {
  const captured = { invoked: 0, ctx: null as any };
  // A valid response per surface:
  // panel: plugin returns Block Kit response ({blocks: []})
  // action: plugin returns empty object (no toast/refresh/navigate)
  const validResponse = surface === "panel" ? { blocks: [] } : {};

  const editorExtConfig =
    surface === "panel"
      ? {
          admin: {
            editorPanels: [
              {
                id: "test-panel",
                collection: "post",
                title: "Test Panel",
                route: routeName,
              },
            ],
          },
        }
      : {
          admin: {
            editorActions: [
              {
                id: "test-action",
                collection: "post",
                label: "Test Action",
                route: routeName,
              },
            ],
          },
        };

  const plugin = definePlugin({
    id: "editor-fixture",
    version: "1.0.0",
    ...editorExtConfig,
    routes: {
      [routeName]: {
        public: routePublic,
        permission: "content:edit_own" as any,
        handler: async (ctx: any) => {
          captured.invoked += 1;
          captured.ctx = ctx;
          return pluginResponse === "invalid" ? { not: "a valid response" } : validResponse;
        },
      },
    },
  });

  const pipelineFactoryOptions = { db };
  const hooks = createHookPipeline([plugin], pipelineFactoryOptions);
  const runtimeDeps: RuntimeDependencies = {
    config: {},
    plugins: [plugin],
    createDialect: () => { throw new Error("unused"); },
    createStorage: null,
    sandboxEnabled: false,
    sandboxedPluginEntries: [],
    createSandboxRunner: null,
  };

  const pluginStates = new Map<string, string>();
  if (!enabled) pluginStates.set(plugin.id, "inactive");

  const runtime = new EmDashRuntime({
    db,
    storage: null,
    configuredPlugins: [plugin],
    sandboxedPlugins: new Map(),
    sandboxedPluginEntries: [],
    hooks,
    enabledPlugins: enabled ? new Set([plugin.id]) : new Set<string>(),
    pluginStates,
    config: {} as EmDashConfig,
    mediaProviders: new Map(),
    mediaProviderEntries: [],
    cronExecutor: null,
    cronScheduler: null,
    emailPipeline: null,
    allPipelinePlugins: [plugin],
    pipelineFactoryOptions,
    runtimeDeps,
    pipelineRef: { current: hooks },
  });

  const getSpy = vi.spyOn(runtime, "handleContentGet");
  return { runtime, plugin, captured, contentLoads: () => getSpy.mock.calls.length };
}

describe("extension-request", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    const db = await setupTestDatabaseWithCollections();
    try {
      // Seed saved entry
      const created = await handleContentCreate(db, "post", {
        data: { title: "Saved entry" },
        authorId: inputs.owner_id,
        locale: inputs.locale,
        status: "published",
      });
      const saved = (created as any).data.item;

      const routeName = "editor-route";
      const surface = inputs.surface as "panel" | "action";
      const { runtime, plugin, captured, contentLoads } = await buildHost({
        db,
        surface,
        routeName,
        routePublic: inputs.route_public === true,
        pluginResponse: inputs.plugin_response as "valid" | "invalid",
        enabled: true,
      });

      // Build locals.user — provide all required RouteCallerInput fields
      let user: any;
      if (inputs.role === null || !inputs.role || !(inputs.role in ROLE)) {
        user = null;
      } else {
        const roleLevel = ROLE[inputs.role as keyof typeof ROLE];
        const userId = inputs.is_owner ? inputs.owner_id : "other-user-id";
        user = {
          id: userId,
          role: roleLevel,
          email: `${userId}@example.com`,
          name: "Test User",
          createdAt: "2024-01-01T00:00:00.000Z",
        };
      }

      // Build request body
      let bodyObj: any;
      if (surface === "panel") {
        if (inputs.interaction_kind === "valid") {
          bodyObj = { type: "block_action", action_id: "do_thing", block_id: "blk-1" };
        } else {
          // malformed: block_action missing action_id
          bodyObj = { type: "block_action" };
        }
      } else {
        // action: arbitrary body with decoys
        bodyObj = { anything: "IGNORED-VALUE", entry: { id: "FORGED-ID" } };
      }

      const headers: Record<string, string> = {
        "Content-Type": "application/json",
      };
      if (inputs.csrf !== false) {
        headers["X-EmDash-Request"] = "1";
      }

      const url = `http://localhost/_emdash/api/plugins/${plugin.id}/${routeName}`;
      const request = new Request(url, {
        method: "POST",
        headers,
        body: JSON.stringify(bodyObj),
      });

      const params = { pluginId: plugin.id, path: routeName };
      const locals = { emdash: runtime, user, tokenScopes: undefined };

      const res = await POST({ params, request, locals, cache: { enabled: false } });

      const s = res.status;
      const statusClass =
        s < 300 ? "ok"
        : s === 401 ? "unauthenticated"
        : s === 403 ? "forbidden"
        : s === 404 ? "not_found"
        : s >= 500 ? "server_error"
        : "client_error";

      const pluginInvoked = captured.invoked > 0 ? "yes" : "no";
      const contentLoaded = contentLoads() > 0 ? "yes" : "no";

      let hostContext: string;
      if (inputs.case_kind === "panel_happy" || inputs.case_kind === "action_happy") {
        const ctxText = JSON.stringify(captured.ctx);
        if (inputs.case_kind === "panel_happy") {
          hostContext = ctxText.includes(saved.id) ? "has-canonical" : "no-canonical";
        } else {
          hostContext = [
            ctxText.includes(saved.id) ? "has-canonical" : "no-canonical",
            (ctxText.includes("IGNORED-VALUE") || ctxText.includes("FORGED-ID"))
              ? "LEAKED" : "clean",
          ].join("|");
        }
      } else {
        hostContext = "__skip__";
      }

      if (expected.status_class !== "__skip__") {
        expect(statusClass, `statusClass mismatch`).toBe(expected.status_class);
      }
      expect(pluginInvoked, `pluginInvoked mismatch`).toBe(expected.plugin_invoked);
      if (expected.content_loaded !== "__skip__") {
        expect(contentLoaded, `contentLoaded mismatch`).toBe(expected.content_loaded);
      }
      if (expected.host_context !== "__skip__") {
        expect(hostContext, `hostContext mismatch`).toBe(expected.host_context);
      }
    } finally {
      await teardownTestDatabase(db);
    }
  }, 120_000);
});
