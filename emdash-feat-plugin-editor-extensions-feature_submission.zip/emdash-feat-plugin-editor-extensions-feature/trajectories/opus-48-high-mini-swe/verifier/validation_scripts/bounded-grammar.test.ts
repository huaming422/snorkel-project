// @ts-nocheck
import { describe, expect, it } from "vitest";
import { getTestCases } from "./validationParams";

// The patch adds validators to packages/core/src/plugins/editor-extensions.ts
// and exports them from that module. Import as a namespace to discover by name.
import * as grammar from "../../../../src/plugins/editor-extensions.js";

describe("bounded-grammar", () => {
  // Resolve both validators from the chosen public surface (core module the patch adds).
  // The panel-interaction validator validates PanelInteraction shapes.
  // The action-response validator validates EditorActionResponse shapes.
  const panelValidator = grammar["validatePanelInteraction"];
  const actionValidator = grammar["validateEditorActionResponse"];

  // Hard guard: both MUST be real function exports.
  expect(typeof panelValidator).toBe("function");
  expect(typeof actionValidator).toBe("function");

  const cases = getTestCases();
  it.each(cases)("case $#", ({ inputs, expected }) => {
    const target = inputs.target as "panel" | "action";
    const validator = target === "panel" ? panelValidator : actionValidator;

    let value: unknown;
    if (inputs.build === "refresh_and_navigate") {
      // Construct an action response that requests BOTH a refresh AND a navigation.
      // From the validateEditorActionResponse source: refresh field = "refresh",
      // navigation field = "navigate".
      value = {
        refresh: true,
        navigate: { kind: "content", collection: "post", id: "some-id" },
      };
    } else {
      value = inputs.value;
    }

    // Call the validator. The patch's validators return { ok, code, message }
    // (not { valid, errors }). Use result.ok for the validity check.
    const result = validator(value);

    // Use result.message to check if the rejection names the expected field.
    const outcome = result.ok
      ? "accepted"
      : (inputs.expect_field !== "__skip__" && result.message?.includes(inputs.expect_field)
          ? "rejected:" + inputs.expect_field
          : "rejected");

    expect(outcome, `outcome mismatch for target=${target}, build=${inputs.build}`).toBe(expected.outcome);
  });
});
