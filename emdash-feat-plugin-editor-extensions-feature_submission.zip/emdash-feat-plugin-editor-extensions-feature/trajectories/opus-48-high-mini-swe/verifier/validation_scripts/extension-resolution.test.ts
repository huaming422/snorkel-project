// @ts-nocheck
import { describe, expect, it, vi } from "vitest";
import { getTestCases } from "./validationParams";

import type { EmDashConfig } from "../../../../src/astro/integration/runtime.js";
import { EmDashRuntime } from "../../../../src/emdash-runtime.js";
import type { RuntimeDependencies } from "../../../../src/emdash-runtime.js";
import { definePlugin } from "../../../../src/plugins/define-plugin.js";
import { createHookPipeline } from "../../../../src/plugins/hooks.js";
import { handleContentCreate } from "../../../../src/api/handlers/content.js";
import { setupTestDatabaseWithCollections, teardownTestDatabase } from "../../../utils/test-db.js";
import { POST } from "../../../../src/astro/routes/api/plugins/[pluginId]/[...path].js";

const ROLE = { subscriber: 10, contributor: 20, author: 30, editor: 40, admin: 50 };
const EXTENSION_ID = "test-panel";
const ROUTE_NAME = "editor-route";

async function buildHostForScenario({
  db,
  scenario,
}: {
  db: any;
  scenario: string;
}) {
  const captured = { invoked: 0, ctx: null as any };
  const validResponse = { blocks: [] };

  let pluginFields: any;
  let enabled = true;

  if (scenario === "match") {
    pluginFields = {
      admin: {
        editorPanels: [
          { id: EXTENSION_ID, collection: "post", title: "Panel", route: ROUTE_NAME },
        ],
      },
    };
  } else if (scenario === "collection_mismatch") {
    pluginFields = {
      admin: {
        editorPanels: [
          { id: EXTENSION_ID, collection: "page", title: "Panel", route: ROUTE_NAME },
        ],
      },
    };
  } else if (scenario === "ambiguous_duplicate") {
    // Two extensions sharing the SAME id, both matching "post"
    // definePlugin does not validate duplicate editorPanel IDs, so we can supply them directly
    pluginFields = {
      admin: {
        editorPanels: [
          { id: EXTENSION_ID, collection: "post", title: "Panel A", route: ROUTE_NAME },
          { id: EXTENSION_ID, collection: "post", title: "Panel B", route: ROUTE_NAME },
        ],
      },
    };
  } else if (scenario === "disabled") {
    pluginFields = {
      admin: {
        editorPanels: [
          { id: EXTENSION_ID, collection: "post", title: "Panel", route: ROUTE_NAME },
        ],
      },
    };
    enabled = false;
  }

  const plugin = definePlugin({
    id: "editor-fixture",
    version: "1.0.0",
    ...pluginFields,
    routes: {
      [ROUTE_NAME]: {
        public: false,
        permission: "content:edit_own" as any,
        handler: async (ctx: any) => {
          captured.invoked += 1;
          captured.ctx = ctx;
          return validResponse;
        },
      },
    },
  });

  const pipelineFactoryOptions = { db };
  const hooks = createHookPipeline([plugin], pipelineFactoryOptions);
  const runtimeDeps: RuntimeDependencies = {
    config: {},
    plugins: [plugin],
    createDialect: () => { throw new Error("unused"); },
    createStorage: null,
    sandboxEnabled: false,
    sandboxedPluginEntries: [],
    createSandboxRunner: null,
  };

  const pluginStates = new Map<string, string>();
  if (!enabled) pluginStates.set(plugin.id, "inactive");

  const runtime = new EmDashRuntime({
    db,
    storage: null,
    configuredPlugins: [plugin],
    sandboxedPlugins: new Map(),
    sandboxedPluginEntries: [],
    hooks,
    enabledPlugins: enabled ? new Set([plugin.id]) : new Set<string>(),
    pluginStates,
    config: {} as EmDashConfig,
    mediaProviders: new Map(),
    mediaProviderEntries: [],
    cronExecutor: null,
    cronScheduler: null,
    emailPipeline: null,
    allPipelinePlugins: [plugin],
    pipelineFactoryOptions,
    runtimeDeps,
    pipelineRef: { current: hooks },
  });

  return { runtime, plugin, captured };
}

describe("extension-resolution", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    const db = await setupTestDatabaseWithCollections();
    try {
      // Seed saved entry owned by inputs.owner_id
      const created = await handleContentCreate(db, "post", {
        data: { title: "Saved entry" },
        authorId: inputs.owner_id,
        locale: inputs.locale,
        status: "published",
      });
      const saved = (created as any).data.item;

      const { runtime, plugin, captured } = await buildHostForScenario({
        db,
        scenario: inputs.scenario,
      });

      // Authenticate as the owner (author level) — provide all required RouteCallerInput fields
      const user = {
        id: inputs.owner_id,
        role: ROLE.author,
        email: `${inputs.owner_id}@example.com`,
        name: "Test User",
        createdAt: "2024-01-01T00:00:00.000Z",
      };

      const bodyObj = { type: "block_action", action_id: "do_thing", block_id: "blk-1" };

      const url = `http://localhost/_emdash/api/plugins/${plugin.id}/${ROUTE_NAME}`;
      const request = new Request(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-EmDash-Request": "1",
        },
        body: JSON.stringify(bodyObj),
      });

      const params = { pluginId: plugin.id, path: ROUTE_NAME };
      const locals = { emdash: runtime, user, tokenScopes: undefined };

      const res = await POST({ params, request, locals, cache: { enabled: false } });

      const s = res.status;
      const statusClass =
        s < 300 ? "ok"
        : s === 401 ? "unauthenticated"
        : s === 403 ? "forbidden"
        : s === 404 ? "not_found"
        : s >= 500 ? "server_error"
        : "client_error";

      const pluginInvoked = captured.invoked > 0 ? "yes" : "no";

      expect(statusClass, `statusClass mismatch for scenario=${inputs.scenario}`).toBe(expected.status_class);
      expect(pluginInvoked, `pluginInvoked mismatch for scenario=${inputs.scenario}`).toBe(expected.plugin_invoked);
    } finally {
      await teardownTestDatabase(db);
    }
  }, 120_000);
});
