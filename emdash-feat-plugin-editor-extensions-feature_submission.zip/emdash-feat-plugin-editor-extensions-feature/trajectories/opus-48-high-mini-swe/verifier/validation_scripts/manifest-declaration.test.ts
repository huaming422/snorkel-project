// @ts-nocheck
import { describe, expect, it } from "vitest";
import { getTestCases } from "./validationParams";

// The patch adds editorPanels/editorActions to packages/plugin-types/src/manifest-schema.ts.
// Import pluginManifestSchema from @emdash-cms/plugin-types which is the schema
// that was actually patched with editor extension support.
import { pluginManifestSchema, EDITOR_PANELS_MAX, EDITOR_ACTIONS_MAX } from "@emdash-cms/plugin-types";

// Minimal valid manifest (pre-existing required fields from the schema)
const MINIMAL_MANIFEST = {
  id: "test-plugin",
  version: "1.0.0",
  capabilities: [],
  allowedHosts: [],
  storage: {},
  hooks: [],
  routes: [
    "editor/panel",    // private route for panel extension (string form = private)
    "editor/action",   // private route for action extension (string form = private)
  ],
  admin: {},
};

describe("manifest-declaration", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", ({ inputs, expected }) => {
    const scenario = inputs.scenario as string;
    let manifest: any;

    if (scenario === "legal") {
      manifest = {
        ...MINIMAL_MANIFEST,
        admin: {
          editorPanels: [
            { id: "my-panel", collection: "post", title: "My Panel", route: "editor/panel" },
          ],
          editorActions: [
            { id: "my-action", collection: "post", label: "My Action", route: "editor/action" },
          ],
        },
      };
    } else if (scenario === "duplicate_ids") {
      manifest = {
        ...MINIMAL_MANIFEST,
        admin: {
          editorActions: [
            { id: "dup-action", collection: "post", label: "Action A", route: "editor/action" },
            { id: "dup-action", collection: "post", label: "Action B", route: "editor/action" },
          ],
        },
      };
    } else if (scenario === "non_slug_id") {
      manifest = {
        ...MINIMAL_MANIFEST,
        admin: {
          editorPanels: [
            { id: "Bad Id!", collection: "post", title: "Bad Panel", route: "editor/panel" },
          ],
        },
      };
    } else if (scenario === "over_cap") {
      // Declare EDITOR_PANELS_MAX + 1 panels
      const panels = Array.from({ length: EDITOR_PANELS_MAX + 1 }, (_, i) => ({
        id: `panel${i}`,
        collection: "post",
        title: `Panel ${i}`,
        route: "editor/panel",
      }));
      manifest = {
        ...MINIMAL_MANIFEST,
        admin: { editorPanels: panels },
      };
    } else if (scenario === "route_not_private") {
      // An extension that names a route declared as PUBLIC — not private.
      // Route declared as public using the object form { name, public: true }.
      manifest = {
        ...MINIMAL_MANIFEST,
        routes: [
          { name: "editor/panel", public: true }, // declared as PUBLIC, not private
        ],
        admin: {
          editorPanels: [
            { id: "my-panel", collection: "post", title: "Panel", route: "editor/panel" },
          ],
        },
      };
    } else if (scenario === "danger_confirm_missing") {
      manifest = {
        ...MINIMAL_MANIFEST,
        admin: {
          editorActions: [
            {
              id: "del-action",
              collection: "post",
              label: "Delete",
              route: "editor/action",
              destructive: true,
              // confirm is intentionally missing
            },
          ],
        },
      };
    } else {
      throw new Error(`Unknown scenario: ${scenario}`);
    }

    const result = pluginManifestSchema.safeParse(manifest);

    let retainedEditorExtensionCount = 0;
    if (result.success) {
      const panels = result.data?.admin?.editorPanels?.length ?? 0;
      const actions = result.data?.admin?.editorActions?.length ?? 0;
      retainedEditorExtensionCount = panels + actions;
    }

    const outcome = result.success
      ? ("accepted:" + retainedEditorExtensionCount)
      : "rejected";

    expect(outcome, `outcome mismatch for scenario=${scenario}`).toBe(expected.outcome);
  });
});
