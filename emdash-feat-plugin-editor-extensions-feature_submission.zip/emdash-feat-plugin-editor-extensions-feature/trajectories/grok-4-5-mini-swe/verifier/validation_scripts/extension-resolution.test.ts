// @ts-nocheck
import { describe, expect, it } from "vitest";
import { getTestCases } from "./validationParams";

import { EmDashRuntime } from "../../../../src/emdash-runtime.js";
import type { EmDashConfig } from "../../../../src/astro/integration/runtime.js";
import type { RuntimeDependencies } from "../../../../src/emdash-runtime.js";
import { definePlugin } from "../../../../src/plugins/define-plugin.js";
import { createHookPipeline } from "../../../../src/plugins/hooks.js";
import { handleContentCreate } from "../../../../src/api/handlers/content.js";
import { setupTestDatabaseWithCollections, teardownTestDatabase } from "../../../utils/test-db.js";
import { dispatchPluginApiRequest } from "../../../../src/plugins/http-route-dispatch.js";

function statusClass(s: number): string {
  return s < 300 ? "ok"
    : s === 401 ? "unauthenticated"
    : s === 403 ? "forbidden"
    : s === 404 ? "not_found"
    : s >= 500 ? "server_error"
    : "client_error";
}

describe("extension-resolution", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    const db = await setupTestDatabaseWithCollections();

    try {
      const ownerId = inputs.owner_id as string;
      const locale = inputs.locale as string;
      const scenario = inputs.scenario as string;

      // Seed entry in "post" collection
      const createResult = await handleContentCreate(db, "post", {
        data: { title: "Test Entry" },
        authorId: ownerId,
        locale,
        status: "draft",
      });
      if (!createResult.success) throw new Error("Failed to create test entry: " + JSON.stringify(createResult));
      const savedEntryId = createResult.data.item.id;

      const captured: { invoked: number } = { invoked: 0 };
      const extensionId = "test-ext";
      const routeName = "editor/panel";
      const altRouteName = "editor/panel-b";

      const routeHandler = async (_ctx: any) => {
        captured.invoked += 1;
        return { blocks: [] };
      };

      // Build editor declaration based on scenario
      let editorDeclaration: any;
      let pluginEnabled = true;

      switch (scenario) {
        case "match":
          editorDeclaration = {
            panels: [{ id: extensionId, label: "Test", route: routeName, collections: ["post"] }],
          };
          break;
        case "collection_mismatch":
          // Same extension id but collections exclude "post"
          editorDeclaration = {
            panels: [{ id: extensionId, label: "Test", route: routeName, collections: ["page"] }],
          };
          break;
        case "ambiguous_duplicate":
          // Two panels with the same id, both including "post" - ambiguous resolution
          editorDeclaration = {
            panels: [
              { id: extensionId, label: "Test A", route: routeName, collections: ["post"] },
              { id: extensionId, label: "Test B", route: altRouteName, collections: ["post"] },
            ],
          };
          break;
        case "disabled":
          editorDeclaration = {
            panels: [{ id: extensionId, label: "Test", route: routeName, collections: ["post"] }],
          };
          pluginEnabled = false;
          break;
        default:
          throw new Error(`Unknown scenario: ${scenario}`);
      }

      // Build routes - need at least the routeName route
      const pluginRoutes: Record<string, any> = {
        [routeName]: { public: false, handler: routeHandler },
      };
      if (scenario === "ambiguous_duplicate") {
        pluginRoutes[altRouteName] = { public: false, handler: routeHandler };
      }

      const plugin = definePlugin({
        id: "test-plugin",
        version: "1.0.0",
        routes: pluginRoutes,
        admin: { editor: editorDeclaration },
      });

      const config: EmDashConfig = {};
      const pipelineFactoryOptions = { db } as const;
      const hooks = createHookPipeline([plugin], pipelineFactoryOptions);
      const pipelineRef = { current: hooks };
      const runtimeDeps: RuntimeDependencies = {
        config, plugins: [plugin],
        createDialect: () => { throw new Error("not used"); },
        createStorage: null, sandboxEnabled: false,
        sandboxedPluginEntries: [], createSandboxRunner: null,
      };

      const enabledSet = pluginEnabled ? new Set([plugin.id]) : new Set<string>();

      const runtime = new EmDashRuntime({
        db, storage: null,
        configuredPlugins: [plugin], sandboxedPlugins: new Map(),
        sandboxedPluginEntries: [], hooks,
        enabledPlugins: enabledSet, pluginStates: new Map(),
        config, mediaProviders: new Map(), mediaProviderEntries: [],
        cronExecutor: null, cronScheduler: null, emailPipeline: null,
        allPipelinePlugins: [plugin], pipelineFactoryOptions, runtimeDeps, pipelineRef,
      });

      // Authenticated owner (author level = 30)
      const user = {
        id: ownerId, email: `${ownerId}@example.com`,
        name: "Owner", role: 30, createdAt: new Date(),
      };

      // Grammar-valid panel interaction (block_action)
      const body = {
        kind: "panel", id: extensionId,
        entry: { collection: "post", id: savedEntryId, locale },
        interaction: { type: "block_action", action_id: "do-thing", block_id: "blk-1" },
      };

      const request = new Request(
        `https://example.com/_emdash/api/plugins/test-plugin/${routeName}`,
        { method: "POST", headers: { "Content-Type": "application/json", "X-EmDash-Request": "1" }, body: JSON.stringify(body) },
      );

      const res = await dispatchPluginApiRequest({
        runtime, pluginId: "test-plugin",
        path: `/${routeName}`, request, user, tokenScopes: undefined,
      });

      const sc = statusClass(res.status);
      const pluginInvoked = captured.invoked > 0 ? "yes" : "no";

      expect(sc).toBe(expected.status_class);
      expect(pluginInvoked).toBe(expected.plugin_invoked);
    } finally {
      await teardownTestDatabase(db);
    }
  }, 120_000);
});
