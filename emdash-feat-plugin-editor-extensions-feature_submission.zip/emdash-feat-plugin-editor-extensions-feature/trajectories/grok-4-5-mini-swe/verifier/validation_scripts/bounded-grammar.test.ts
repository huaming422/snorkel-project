// @ts-nocheck
import { describe, expect, it } from "vitest";
import { getTestCases } from "./validationParams";

// Discover validators from the patch:
// The patch adds validateEditorPanelInteraction and validateEditorActionResponse
// to packages/core/src/plugins/editor-extensions.ts, exported from its index.
// These are the validators the patch adds for the panel interaction and action response grammars.
import * as grammar from "../../../../src/plugins/editor-extensions.js";

describe("bounded-grammar", () => {
  // Resolve both validators off the chosen public surface.
  const panelValidator = grammar["validateEditorPanelInteraction"];
  const actionValidator = grammar["validateEditorActionResponse"];

  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    // Hard guards: both MUST be real function exports of the chosen public surface.
    expect(typeof panelValidator).toBe("function");
    expect(typeof actionValidator).toBe("function");

    // Select validator by target
    const validator = inputs.target === "panel" ? panelValidator : actionValidator;

    // Build the value to validate
    let valueToValidate: unknown;
    if (inputs.build === "refresh_and_navigate") {
      // Construct an action response that simultaneously requests BOTH refresh AND navigate.
      // Discovered from validateEditorActionResponse source: fields are "refresh" and "navigate".
      valueToValidate = {
        refresh: true,
        navigate: { kind: "external", url: "https://example.com" },
      };
    } else {
      valueToValidate = inputs.value;
    }

    // Call the selected validator.
    // For "action", also pass the policy argument the validator expects (permissive/empty).
    const result =
      inputs.target === "action"
        ? validator(valueToValidate, { pluginPagePaths: [] })
        : validator(valueToValidate);

    // Compute outcome per the procedure using result.ok and result.message.
    // The validators return { ok: true, ... } or { ok: false, message: string }.
    const errorsText = result.ok ? "" : (result.message ?? "");
    const outcome = result.ok
      ? "accepted"
      : inputs.expect_field !== "__skip__" && errorsText.includes(inputs.expect_field)
        ? "rejected:" + inputs.expect_field
        : "rejected";

    expect(outcome).toBe(expected.outcome);
  }, 120_000);
});
