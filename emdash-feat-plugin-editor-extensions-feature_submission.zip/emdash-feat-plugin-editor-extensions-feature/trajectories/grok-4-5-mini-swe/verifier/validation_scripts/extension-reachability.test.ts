// @ts-nocheck
import { describe, expect, it } from "vitest";
import { getTestCases } from "./validationParams";

import { EmDashRuntime } from "../../../../src/emdash-runtime.js";
import type { EmDashConfig } from "../../../../src/astro/integration/runtime.js";
import type { RuntimeDependencies } from "../../../../src/emdash-runtime.js";
import { definePlugin } from "../../../../src/plugins/define-plugin.js";
import { createHookPipeline } from "../../../../src/plugins/hooks.js";
import { handleContentCreate } from "../../../../src/api/handlers/content.js";
import { setupTestDatabaseWithCollections, teardownTestDatabase } from "../../../utils/test-db.js";
import { injectCoreRoutes } from "../../../../src/astro/integration/routes.js";
import { dispatchPluginApiRequest } from "../../../../src/plugins/http-route-dispatch.js";

const toRegex = (pattern: string) => {
  const body = pattern
    .split("/")
    .map((seg) =>
      /^\[\.\.\..+\]$/.test(seg) ? "[^/]+(?:/[^/]+)*"
        : /^\[.+\]$/.test(seg) ? "[^/]+"
        : seg.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"),
    )
    .join("/");
  return new RegExp("^" + body + "$");
};

describe("extension-reachability", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    const db = await setupTestDatabaseWithCollections();

    try {
      const ownerId = inputs.owner_id as string;
      const locale = inputs.locale as string;

      // Seed entry
      const createResult = await handleContentCreate(db, "post", {
        data: { title: "Test Entry" },
        authorId: ownerId,
        locale,
        status: "draft",
      });
      if (!createResult.success) throw new Error("Failed to create entry");
      const savedEntryId = createResult.data.item.id;

      const captured: { invoked: number; ctx: any } = { invoked: 0, ctx: null };
      const extensionId = "test-ext";
      const routeName = "editor/panel";

      const routeHandler = async (ctx: any) => {
        captured.invoked += 1;
        captured.ctx = ctx;
        return { blocks: [] };
      };

      const plugin = definePlugin({
        id: "test-plugin",
        version: "1.0.0",
        routes: { [routeName]: { public: false, handler: routeHandler } },
        admin: {
          editor: {
            panels: [{ id: extensionId, label: "Test Extension", route: routeName, collections: ["post"] }],
          },
        },
      });

      const config: EmDashConfig = {};
      const pipelineFactoryOptions = { db } as const;
      const hooks = createHookPipeline([plugin], pipelineFactoryOptions);
      const pipelineRef = { current: hooks };
      const runtimeDeps: RuntimeDependencies = {
        config, plugins: [plugin],
        createDialect: () => { throw new Error("not used"); },
        createStorage: null, sandboxEnabled: false,
        sandboxedPluginEntries: [], createSandboxRunner: null,
      };

      const runtime = new EmDashRuntime({
        db, storage: null,
        configuredPlugins: [plugin], sandboxedPlugins: new Map(),
        sandboxedPluginEntries: [], hooks,
        enabledPlugins: new Set([plugin.id]), pluginStates: new Map(),
        config, mediaProviders: new Map(), mediaProviderEntries: [],
        cronExecutor: null, cronScheduler: null, emailPipeline: null,
        allPipelinePlugins: [plugin], pipelineFactoryOptions, runtimeDeps, pipelineRef,
      });

      // PART A: Check the mounted route table
      const routes: Array<{ pattern: string; entrypoint: string }> = [];
      injectCoreRoutes((route) => routes.push(route));

      // The client URL uses the pre-existing plugin catch-all:
      // /_emdash/api/plugins/<pluginId>/<routeName>
      const urlPath = `/_emdash/api/plugins/${plugin.id}/${routeName}`;

      const mounted = routes.some((r) => toRegex(r.pattern).test(urlPath));
      const registered = mounted ? "yes" : "no";

      // PART B: Drive the capability via dispatchPluginApiRequest
      const user = {
        id: ownerId, email: `${ownerId}@example.com`,
        name: "Owner", role: 30, createdAt: new Date(),
      };

      const body = {
        kind: "panel", id: extensionId,
        entry: { collection: "post", id: savedEntryId, locale },
        interaction: { type: "block_action", action_id: "do-thing", block_id: "blk-1" },
      };

      const request = new Request(`https://example.com${urlPath}`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-EmDash-Request": "1" },
        body: JSON.stringify(body),
      });

      const res = await dispatchPluginApiRequest({
        runtime, pluginId: plugin.id,
        path: `/${routeName}`, request, user, tokenScopes: undefined,
      });

      // Serialize only ctx.input to avoid circular-reference issues with the
      // full RouteContext (which contains db connections, Request objects, etc.).
      // ctx.input is the EditorExtensionPluginInput — a plain object with entry.id.
      const ctxInput = captured.ctx?.input ?? {};
      const ctxText = JSON.stringify(ctxInput);
      const served =
        res.status < 300 && captured.invoked > 0 && ctxText.includes(savedEntryId)
          ? "yes" : "no";

      expect(registered).toBe(expected.registered);
      expect(served).toBe(expected.served);
    } finally {
      await teardownTestDatabase(db);
    }
  }, 120_000);
});
