// @ts-nocheck
import { describe, expect, it } from "vitest";
import { getTestCases } from "./validationParams";

import { pluginManifestSchema } from "../../../../src/plugins/manifest-schema.js";
import { MAX_EDITOR_PANELS, MAX_EDITOR_ACTIONS } from "../../../../src/plugins/editor-extensions.js";

// Base minimal valid manifest
function makeManifest(overrides: Record<string, unknown> = {}) {
  return {
    id: "test-plugin",
    version: "1.0.0",
    capabilities: [],
    allowedHosts: [],
    storage: {},
    hooks: [],
    routes: [
      { name: "editor/panel", public: false },
      { name: "editor/action", public: false },
      { name: "public-route", public: true },
    ],
    admin: {},
    ...overrides,
  };
}

describe("manifest-declaration", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    const scenario = inputs.scenario as string;

    let manifest: any;

    switch (scenario) {
      case "legal":
        manifest = makeManifest({
          admin: {
            editor: {
              panels: [
                { id: "my-panel", label: "My Panel", route: "editor/panel", collections: ["post"] },
              ],
              actions: [
                { id: "my-action", label: "My Action", route: "editor/action" },
              ],
            },
          },
        });
        break;

      case "duplicate_ids":
        manifest = makeManifest({
          routes: [
            { name: "editor/panel", public: false },
            { name: "editor/panel-2", public: false },
          ],
          admin: {
            editor: {
              panels: [
                { id: "dup-panel", label: "Panel A", route: "editor/panel" },
                { id: "dup-panel", label: "Panel B", route: "editor/panel-2" },
              ],
            },
          },
        });
        break;

      case "non_slug_id":
        manifest = makeManifest({
          admin: {
            editor: {
              panels: [
                { id: "Bad Id!", label: "Bad Panel", route: "editor/panel" },
              ],
            },
          },
        });
        break;

      case "over_cap": {
        // More panels than the cap allows
        const panelCount = MAX_EDITOR_PANELS + 1;
        const panels = Array.from({ length: panelCount }, (_, i) => ({
          id: `panel-${i}`,
          label: `Panel ${i}`,
          route: `editor/panel-${i}`,
        }));
        const panelRoutes = panels.map((p) => ({ name: p.route, public: false }));
        manifest = makeManifest({
          routes: panelRoutes,
          admin: {
            editor: { panels },
          },
        });
        break;
      }

      case "route_not_private":
        // Extension names a serving route that is NOT declared as private
        // (declared as public, or undeclared entirely)
        manifest = makeManifest({
          admin: {
            editor: {
              panels: [
                // "public-route" is declared as public in base manifest routes
                { id: "my-panel", label: "My Panel", route: "public-route" },
              ],
            },
          },
        });
        break;

      case "danger_confirm_missing":
        manifest = makeManifest({
          admin: {
            editor: {
              actions: [
                { id: "dangerous-action", label: "Wipe", route: "editor/action", dangerous: true },
              ],
            },
          },
        });
        break;

      default:
        throw new Error(`Unknown scenario: ${scenario}`);
    }

    const result = pluginManifestSchema.safeParse(manifest);

    let retainedEditorExtensionCount = 0;
    if (result.success) {
      const editor = result.data.admin?.editor;
      retainedEditorExtensionCount =
        (editor?.panels?.length ?? 0) + (editor?.actions?.length ?? 0);
    }

    const outcome = result.success
      ? "accepted:" + retainedEditorExtensionCount
      : "rejected";

    expect(outcome).toBe(expected.outcome);
  }, 120_000);
});
