// @ts-nocheck
import { describe, expect, it, vi } from "vitest";
import { getTestCases } from "./validationParams";

import { EmDashRuntime } from "../../../../src/emdash-runtime.js";
import type { EmDashConfig } from "../../../../src/astro/integration/runtime.js";
import type { RuntimeDependencies } from "../../../../src/emdash-runtime.js";
import { definePlugin } from "../../../../src/plugins/define-plugin.js";
import { createHookPipeline } from "../../../../src/plugins/hooks.js";
import { handleContentCreate } from "../../../../src/api/handlers/content.js";
import { setupTestDatabaseWithCollections, teardownTestDatabase } from "../../../utils/test-db.js";
import { ContentRepository } from "../../../../src/database/repositories/content.js";
import { dispatchPluginApiRequest } from "../../../../src/plugins/http-route-dispatch.js";

const ROLE = {
  subscriber: 10,
  author: 30,
  editor: 40,
  admin: 50,
} as const;

function statusClass(s: number): string {
  return s < 300 ? "ok"
    : s === 401 ? "unauthenticated"
    : s === 403 ? "forbidden"
    : s === 404 ? "not_found"
    : s >= 500 ? "server_error"
    : "client_error";
}

describe("extension-request", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    const db = await setupTestDatabaseWithCollections();

    // Spy on ContentRepository.prototype.findById to count content loads.
    // The editor-extension handler creates a new ContentRepository(db) and calls
    // repo.findById directly, so we spy at the prototype level.
    const findByIdSpy = vi.spyOn(ContentRepository.prototype, "findById");

    try {
      const captured: { invoked: number; ctx: any } = { invoked: 0, ctx: null };

      // Seed the entry
      const ownerId = inputs.owner_id as string;
      const locale = inputs.locale as string;
      const createResult = await handleContentCreate(db, "post", {
        data: { title: "Test Entry" },
        authorId: ownerId,
        locale,
        status: "draft",
      });
      if (!createResult.success) throw new Error("Failed to create test entry: " + JSON.stringify(createResult));
      // ContentResponse has { item: ContentItem }
      const savedEntryId = createResult.data.item.id;

      // Reset the spy call count AFTER seeding (seeding may also use findById internally)
      findByIdSpy.mockClear();

      const surface = inputs.surface as string;
      const extensionId = "test-ext";
      const routeName = `editor/${surface}`;
      const routePublic = inputs.route_public === true;

      // Plugin responses
      const validPanelResponse = { blocks: [] };
      const validActionResponse = { notification: { message: "Done", type: "success" } };
      const invalidResponse = "INVALID_RESPONSE_NOT_AN_OBJECT";

      const routeHandler = async (ctx: any) => {
        captured.invoked += 1;
        captured.ctx = ctx;
        return inputs.plugin_response === "invalid" ? invalidResponse
          : surface === "panel" ? validPanelResponse
          : validActionResponse;
      };

      const editorDeclaration =
        surface === "panel"
          ? { panels: [{ id: extensionId, label: "Test Panel", route: routeName, collections: ["post"] }] }
          : { actions: [{ id: extensionId, label: "Test Action", route: routeName, collections: ["post"] }] };

      const plugin = definePlugin({
        id: "test-plugin",
        version: "1.0.0",
        routes: { [routeName]: { public: routePublic, handler: routeHandler } },
        admin: { editor: editorDeclaration },
      });

      const config: EmDashConfig = {};
      const pipelineFactoryOptions = { db } as const;
      const hooks = createHookPipeline([plugin], pipelineFactoryOptions);
      const pipelineRef = { current: hooks };
      const runtimeDeps: RuntimeDependencies = {
        config, plugins: [plugin],
        createDialect: () => { throw new Error("not used"); },
        createStorage: null, sandboxEnabled: false,
        sandboxedPluginEntries: [], createSandboxRunner: null,
      };

      const runtime = new EmDashRuntime({
        db, storage: null,
        configuredPlugins: [plugin], sandboxedPlugins: new Map(),
        sandboxedPluginEntries: [], hooks,
        enabledPlugins: new Set([plugin.id]), pluginStates: new Map(),
        config, mediaProviders: new Map(), mediaProviderEntries: [],
        cronExecutor: null, cronScheduler: null, emailPipeline: null,
        allPipelinePlugins: [plugin], pipelineFactoryOptions, runtimeDeps, pipelineRef,
      });

      // Determine user
      const roleValue = inputs.role;
      let user: any = null;
      if (roleValue !== null && roleValue !== undefined) {
        const roleLevel = ROLE[roleValue as keyof typeof ROLE] ?? 30;
        const userId = inputs.is_owner ? ownerId : `other-user-xyz`;
        user = { id: userId, email: `${userId}@example.com`, name: "Test", role: roleLevel, createdAt: new Date() };
      }

      // Build request body
      const csrfHeader = inputs.csrf !== false ? { "X-EmDash-Request": "1" } : {};
      let body: any;
      if (surface === "panel") {
        const interaction = inputs.interaction_kind === "malformed"
          ? { type: "block_action", block_id: "blk-1" }
          : { type: "block_action", action_id: "do-thing", block_id: "blk-1" };
        body = { kind: "panel", id: extensionId, entry: { collection: "post", id: savedEntryId, locale }, interaction };
      } else {
        // action surface: include decoy values host must NOT echo
        body = {
          kind: "action", id: extensionId,
          entry: { collection: "post", id: savedEntryId, locale },
          anything: "IGNORED-VALUE",
          forged_entry: { id: "FORGED-ID" },
        };
      }

      const request = new Request(
        `https://example.com/_emdash/api/plugins/test-plugin/${routeName}`,
        { method: "POST", headers: { "Content-Type": "application/json", ...csrfHeader }, body: JSON.stringify(body) },
      );

      const res = await dispatchPluginApiRequest({
        runtime, pluginId: "test-plugin",
        path: `/${routeName}`, request, user, tokenScopes: undefined,
      });

      // Compute metrics
      const sc = statusClass(res.status);
      const pluginInvoked = captured.invoked > 0 ? "yes" : "no";
      // Use spy call count for content loads (spy was cleared after seeding).
      const contentLoaded = findByIdSpy.mock.calls.length > 0 ? "yes" : "no";

      let hostContext: string = "__skip__";
      if (inputs.case_kind === "panel_happy" || inputs.case_kind === "action_happy") {
        // Serialize only ctx.input to avoid circular-reference issues with the
        // full RouteContext (which contains db connections, Request objects, etc.).
        // ctx.input is the EditorExtensionPluginInput — a plain object with entry.id.
        const ctxInput = captured.ctx?.input ?? {};
        const ctxText = JSON.stringify(ctxInput);
        if (inputs.case_kind === "panel_happy") {
          hostContext = ctxText.includes(savedEntryId) ? "has-canonical" : "no-canonical";
        } else {
          hostContext = [
            ctxText.includes(savedEntryId) ? "has-canonical" : "no-canonical",
            ctxText.includes("IGNORED-VALUE") || ctxText.includes("FORGED-ID") ? "LEAKED" : "clean",
          ].join("|");
        }
      }

      // Assert per expected
      if (expected.status_class !== "__skip__") {
        expect(sc).toBe(expected.status_class);
      }
      expect(pluginInvoked).toBe(expected.plugin_invoked);
      if (expected.content_loaded !== "__skip__") {
        expect(contentLoaded).toBe(expected.content_loaded);
      }
      if (expected.host_context !== "__skip__") {
        expect(hostContext).toBe(expected.host_context);
      }
    } finally {
      findByIdSpy.mockRestore();
      await teardownTestDatabase(db);
    }
  }, 120_000);
});
