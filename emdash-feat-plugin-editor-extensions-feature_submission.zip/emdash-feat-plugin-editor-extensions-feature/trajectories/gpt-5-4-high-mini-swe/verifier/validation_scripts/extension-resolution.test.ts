// @ts-nocheck
import { randomUUID } from "node:crypto";
import { describe, expect, it, vi } from "vitest";
import { getTestCases } from "./validationParams";

import {
  EmDashRuntime,
} from "../../../../src/emdash-runtime.js";
import { POST } from "../../../../src/astro/routes/api/plugins/content-editor/[kind]/[collection]/[id]/[extensionId].js";
import { setupTestDatabaseWithCollections, teardownTestDatabase } from "../../../utils/test-db.js";
import { handleContentCreate } from "../../../../src/api/handlers/content.js";
import { createHookPipeline } from "../../../../src/plugins/hooks.js";

const ROLE: Record<string, number> = {
  subscriber: 10,
  contributor: 20,
  author: 30,
  editor: 40,
  admin: 50,
};

function makeSandboxedPlugins(entries: Array<{ id: string; version: string; captureRef: { invoked: number } }>) {
  const sandboxedPlugins = new Map<string, any>();
  for (const { id, version, captureRef } of entries) {
    const instance = {
      id: `${id}:${version}`,
      invokeHook: vi.fn(),
      invokeRoute: vi.fn(async (_rn: string, _payload: unknown) => {
        captureRef.invoked += 1;
        return { blocks: [] };
      }),
      terminate: vi.fn(),
    };
    sandboxedPlugins.set(`${id}:${version}`, instance);
  }
  return sandboxedPlugins;
}

describe("extension-resolution", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    const db = await setupTestDatabaseWithCollections();
    let runtime: EmDashRuntime | null = null;
    try {
      const scenario = inputs.scenario as string;
      const ownerId = inputs.owner_id as string;
      const locale = inputs.locale as string;
      const extensionId = "my-panel";
      const routeName = "panel-route";
      const pluginId = `fixture-${randomUUID()}`;
      const pluginVersion = randomUUID();

      // Seed entry
      const createResult = await handleContentCreate(db, "post", {
        data: { title: "Test" },
        status: "draft",
        authorId: ownerId,
        locale,
      });
      if (!createResult.success) throw new Error("Failed to seed entry");
      const saved = (createResult.data as { item: { id: string } }).item;

      // Authenticated owner author
      const user = { id: ownerId, role: ROLE.author };

      // Capture for invocation tracking
      const captureRef = { invoked: 0 };

      // Build entries and plugins based on scenario
      let sandboxedPluginEntries: any[] = [];
      let sandboxedPlugins: Map<string, any>;
      let enabledPlugins = new Set<string>();
      let pluginStates = new Map<string, string>();

      if (scenario === "match") {
        const entry = {
          id: pluginId, version: pluginVersion, options: {}, code: "",
          capabilities: [], allowedHosts: [], storage: {},
          routes: [routeName], adminPages: [], adminWidgets: [],
          contentEditorPanels: [{ id: extensionId, collection: "post", route: routeName }],
        };
        sandboxedPluginEntries = [entry];
        sandboxedPlugins = makeSandboxedPlugins([{ id: pluginId, version: pluginVersion, captureRef }]);
        enabledPlugins.add(pluginId);

      } else if (scenario === "collection_mismatch") {
        const entry = {
          id: pluginId, version: pluginVersion, options: {}, code: "",
          capabilities: [], allowedHosts: [], storage: {},
          routes: [routeName], adminPages: [], adminWidgets: [],
          contentEditorPanels: [{ id: extensionId, collection: "page", route: routeName }],
        };
        sandboxedPluginEntries = [entry];
        sandboxedPlugins = makeSandboxedPlugins([{ id: pluginId, version: pluginVersion, captureRef }]);
        enabledPlugins.add(pluginId);

      } else if (scenario === "ambiguous_duplicate") {
        const pluginId2 = `fixture2-${randomUUID()}`;
        const pluginVersion2 = randomUUID();
        const captureRef2 = { invoked: 0 };
        const entry1 = {
          id: pluginId, version: pluginVersion, options: {}, code: "",
          capabilities: [], allowedHosts: [], storage: {},
          routes: [routeName], adminPages: [], adminWidgets: [],
          contentEditorPanels: [{ id: extensionId, collection: "post", route: routeName }],
        };
        const entry2 = {
          id: pluginId2, version: pluginVersion2, options: {}, code: "",
          capabilities: [], allowedHosts: [], storage: {},
          routes: [routeName], adminPages: [], adminWidgets: [],
          contentEditorPanels: [{ id: extensionId, collection: "post", route: routeName }],
        };
        sandboxedPluginEntries = [entry1, entry2];
        sandboxedPlugins = makeSandboxedPlugins([
          { id: pluginId, version: pluginVersion, captureRef },
          { id: pluginId2, version: pluginVersion2, captureRef: captureRef2 },
        ]);
        enabledPlugins.add(pluginId);
        enabledPlugins.add(pluginId2);

      } else if (scenario === "disabled") {
        const entry = {
          id: pluginId, version: pluginVersion, options: {}, code: "",
          capabilities: [], allowedHosts: [], storage: {},
          routes: [routeName], adminPages: [], adminWidgets: [],
          contentEditorPanels: [{ id: extensionId, collection: "post", route: routeName }],
        };
        sandboxedPluginEntries = [entry];
        sandboxedPlugins = makeSandboxedPlugins([{ id: pluginId, version: pluginVersion, captureRef }]);
        // Plugin disabled
        pluginStates.set(pluginId, "inactive");
        // enabledPlugins remains empty
      } else {
        throw new Error(`Unknown scenario: ${scenario}`);
      }

      const hooks = createHookPipeline([], { db });
      const pipelineFactoryOptions = { db };
      const runtimeDeps: any = {
        config: {},
        plugins: [],
        createDialect: () => { throw new Error("unused"); },
        createStorage: null,
        sandboxEnabled: true,
        sandboxedPluginEntries,
        createSandboxRunner: null,
      };

      runtime = new EmDashRuntime({
        db,
        storage: null,
        configuredPlugins: [],
        sandboxedPlugins,
        sandboxedPluginEntries,
        hooks,
        enabledPlugins,
        pluginStates,
        config: {},
        mediaProviders: new Map(),
        mediaProviderEntries: [],
        cronExecutor: null,
        cronScheduler: null,
        emailPipeline: null,
        allPipelinePlugins: [],
        pipelineFactoryOptions,
        runtimeDeps,
        pipelineRef: { current: hooks },
      });

      const kind = "panels";
      const baseUrl = `https://example.test/_emdash/api/plugins/content-editor/${kind}/post/${saved.id}/${extensionId}?locale=${locale}`;

      const request = new Request(baseUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-EmDash-Request": "1",
        },
        body: JSON.stringify({ type: "block_action", action_id: "do-thing", block_id: "blk-1" }),
      });

      const locals = {
        emdash: runtime,
        user,
        tokenScopes: undefined,
      };

      const res = await POST({
        params: { kind, collection: "post", id: saved.id, extensionId },
        request,
        url: new URL(baseUrl),
        locals,
        cache: undefined,
      } as never);

      const s = res.status;
      const statusClass =
        s < 300 ? "ok"
        : s === 401 ? "unauthenticated"
        : s === 403 ? "forbidden"
        : s === 404 ? "not_found"
        : s >= 500 ? "server_error"
        : "client_error";

      const pluginInvoked = captureRef.invoked > 0 ? "yes" : "no";

      expect(statusClass, `statusClass [${scenario}]`).toBe(expected.status_class);
      expect(pluginInvoked, `pluginInvoked [${scenario}]`).toBe(expected.plugin_invoked);
    } finally {
      if (runtime) {
        await runtime.stopCron();
      }
      await teardownTestDatabase(db);
    }
  }, 120_000);
});
