// @ts-nocheck
import { randomUUID } from "node:crypto";
import { describe, expect, it, vi } from "vitest";
import { getTestCases } from "./validationParams";

import {
  EmDashRuntime,
} from "../../../../src/emdash-runtime.js";
import { POST } from "../../../../src/astro/routes/api/plugins/content-editor/[kind]/[collection]/[id]/[extensionId].js";
import { injectCoreRoutes } from "../../../../src/astro/integration/routes.js";
import { setupTestDatabaseWithCollections, teardownTestDatabase } from "../../../utils/test-db.js";
import { handleContentCreate } from "../../../../src/api/handlers/content.js";
import { createHookPipeline } from "../../../../src/plugins/hooks.js";

const ROLE: Record<string, number> = {
  subscriber: 10,
  contributor: 20,
  author: 30,
  editor: 40,
  admin: 50,
};

// Convert an Astro route pattern to a regex matcher
const toRegex = (pattern: string): RegExp => {
  const body = pattern
    .split("/")
    .map((seg) =>
      /^\[\.\.\..+\]$/.test(seg) ? "[^/]+(?:/[^/]+)*"
      : /^\[.+\]$/.test(seg) ? "[^/]+"
      : seg.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
    )
    .join("/");
  return new RegExp("^" + body + "$");
};

describe("extension-reachability", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    const db = await setupTestDatabaseWithCollections();
    let runtime: EmDashRuntime | null = null;
    try {
      const ownerId = inputs.owner_id as string;
      const locale = inputs.locale as string;
      const pluginId = `fixture-${randomUUID()}`;
      const pluginVersion = randomUUID();
      const extensionId = "my-panel";
      const routeName = "panel-route";

      // Seed a saved entry
      const createResult = await handleContentCreate(db, "post", {
        data: { title: "Reachability Test" },
        status: "draft",
        authorId: ownerId,
        locale,
      });
      if (!createResult.success) throw new Error("Failed to seed entry");
      const saved = (createResult.data as { item: { id: string } }).item;

      // PART A: collect all mounted route patterns
      const routes: Array<{ pattern: string; entrypoint: string }> = [];
      injectCoreRoutes((route) => routes.push(route));

      // Determine the client URL path for a panel extension on this entry.
      // The dedicated route file uses: /_emdash/api/plugins/content-editor/[kind]/[collection]/[id]/[extensionId]
      const kind = "panels";
      const urlPath = `/_emdash/api/plugins/content-editor/${kind}/post/${saved.id}/${extensionId}`;

      // Check if any mounted pattern matches this URL
      const mounted = routes.some((r) => toRegex(r.pattern).test(urlPath));
      const registered = mounted ? "yes" : "no";

      // PART B: invoke the handler directly and check if plugin is invoked
      const captureRef = { invoked: 0, ctx: null as unknown };

      const instance = {
        id: `${pluginId}:${pluginVersion}`,
        invokeHook: vi.fn(),
        invokeRoute: vi.fn(async (_rn: string, payload: unknown) => {
          captureRef.invoked += 1;
          captureRef.ctx = payload;
          return { blocks: [] };
        }),
        terminate: vi.fn(),
      };

      const sandboxedPlugins = new Map<string, any>();
      sandboxedPlugins.set(`${pluginId}:${pluginVersion}`, instance);

      const entry = {
        id: pluginId,
        version: pluginVersion,
        options: {},
        code: "",
        capabilities: [],
        allowedHosts: [],
        storage: {},
        routes: [routeName],
        adminPages: [],
        adminWidgets: [],
        contentEditorPanels: [{ id: extensionId, collection: "post", route: routeName }],
      };

      const hooks = createHookPipeline([], { db });
      const pipelineFactoryOptions = { db };
      const runtimeDeps: any = {
        config: {},
        plugins: [],
        createDialect: () => { throw new Error("unused"); },
        createStorage: null,
        sandboxEnabled: true,
        sandboxedPluginEntries: [entry],
        createSandboxRunner: null,
      };

      runtime = new EmDashRuntime({
        db,
        storage: null,
        configuredPlugins: [],
        sandboxedPlugins,
        sandboxedPluginEntries: [entry],
        hooks,
        enabledPlugins: new Set([pluginId]),
        pluginStates: new Map(),
        config: {},
        mediaProviders: new Map(),
        mediaProviderEntries: [],
        cronExecutor: null,
        cronScheduler: null,
        emailPipeline: null,
        allPipelinePlugins: [],
        pipelineFactoryOptions,
        runtimeDeps,
        pipelineRef: { current: hooks },
      });

      const user = { id: ownerId, role: ROLE.author };

      const baseUrl = `https://example.test${urlPath}?locale=${locale}`;
      const request = new Request(baseUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-EmDash-Request": "1",
        },
        body: JSON.stringify({ type: "block_action", action_id: "do-thing", block_id: "blk-1" }),
      });

      const locals = {
        emdash: runtime,
        user,
        tokenScopes: undefined,
      };

      const res = await POST({
        params: { kind, collection: "post", id: saved.id, extensionId },
        request,
        url: new URL(baseUrl),
        locals,
        cache: undefined,
      } as never);

      const served =
        res.status < 300 &&
        captureRef.invoked > 0 &&
        JSON.stringify(captureRef.ctx).includes(saved.id)
          ? "yes"
          : "no";

      expect(registered, "registered").toBe(expected.registered);
      expect(served, "served").toBe(expected.served);
    } finally {
      if (runtime) {
        await runtime.stopCron();
      }
      await teardownTestDatabase(db);
    }
  }, 120_000);
});
