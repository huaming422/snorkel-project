// @ts-nocheck
import { describe, expect, it } from "vitest";
import { getTestCases } from "./validationParams";

// Discover from the patch: the bounded-grammar validators for editor-panel interactions
// and action responses live in packages/core/src/plugins/editor-extensions.ts.
// They are Zod schemas exported as:
//   contentEditorPanelInteractionSchema (validates panel interactions)
//   contentEditorActionResponseSchema   (validates action responses)
import * as grammar from "../../../../src/plugins/editor-extensions.js";

describe("bounded-grammar", () => {
  // Resolve both validators from the imported namespace
  const panelValidator = grammar["contentEditorPanelInteractionSchema"];
  const actionValidator = grammar["contentEditorActionResponseSchema"];

  // Helper: wrap a Zod schema (or plain function) as a canonical validator
  // returning { valid: boolean, errors: [{ path, message }] }
  function asValidator(v: any) {
    if (typeof v === "function") {
      // Plain validator function
      return v;
    }
    // Zod schema
    return (value: unknown, ..._args: unknown[]) => {
      const r = v.safeParse(value);
      if (r.success) {
        return { valid: true, errors: [] };
      }
      return {
        valid: false,
        errors: (r.error?.issues ?? []).map((i: any) => ({
          path: i.path.join("."),
          message: i.message,
        })),
      };
    };
  }

  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    // Hard guard: both validators must be callable (as Zod schemas or functions)
    const pv = asValidator(panelValidator);
    const av = asValidator(actionValidator);
    expect(typeof pv).toBe("function");
    expect(typeof av).toBe("function");

    const target = inputs.target as string;
    const build = inputs.build as string;
    const expectField = inputs.expect_field as string;

    let value: unknown;
    if (build === "refresh_and_navigate") {
      // Construct an action response that simultaneously requests refresh AND navigation
      // The validator has a 'refresh' field (literal true) and 'navigate' field (object with 'to')
      value = {
        refresh: true,
        navigate: { to: "/admin/some/path" },
      };
    } else {
      value = inputs.value;
    }

    const validate = target === "panel" ? pv : av;
    const result = validate(value);

    const errorsText = JSON.stringify(result.errors || []);
    const outcome = result.valid
      ? "accepted"
      : (expectField !== "__skip__" && errorsText.includes(expectField)
          ? "rejected:" + expectField
          : "rejected");

    expect(outcome).toBe(expected.outcome);
  }, 120_000);
});
