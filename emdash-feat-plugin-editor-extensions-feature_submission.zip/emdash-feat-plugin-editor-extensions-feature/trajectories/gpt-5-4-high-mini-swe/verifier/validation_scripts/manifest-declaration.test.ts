// @ts-nocheck
import { describe, expect, it } from "vitest";
import { getTestCases } from "./validationParams";

import { pluginManifestSchema } from "../../../../src/plugins/manifest-schema.js";

// Discover the caps from the schema (MAX_CONTENT_EDITOR_PANELS = MAX_CONTENT_EDITOR_ACTIONS = 32)
const MAX_CAP = 32;

// Minimal valid manifest base
function baseManifest(extraRoutes: string[] = []) {
  return {
    id: "test-plugin",
    version: "1.0.0",
    capabilities: [],
    allowedHosts: [],
    storage: {},
    hooks: [],
    routes: ["panel-route", "action-route", ...extraRoutes],
    admin: {},
  };
}

describe("manifest-declaration", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    const scenario = inputs.scenario as string;
    let manifest: unknown;
    let retainedEditorExtensionCount = 0;

    if (scenario === "legal") {
      manifest = {
        ...baseManifest(),
        admin: {
          contentEditorPanels: [
            { id: "my-panel", collection: "post", route: "panel-route" },
          ],
          contentEditorActions: [
            { id: "my-action", collection: "post", route: "action-route", confirmation: { text: "Sure?" } },
          ],
        },
      };
    } else if (scenario === "duplicate_ids") {
      manifest = {
        ...baseManifest(),
        admin: {
          contentEditorPanels: [
            { id: "shared-id", collection: "post", route: "panel-route" },
            { id: "shared-id", collection: "post", route: "panel-route" },
          ],
        },
      };
    } else if (scenario === "non_slug_id") {
      manifest = {
        ...baseManifest(),
        admin: {
          contentEditorPanels: [
            { id: "Bad Id!", collection: "post", route: "panel-route" },
          ],
        },
      };
    } else if (scenario === "over_cap") {
      // MAX_CONTENT_EDITOR_PANELS = 32, declare 33
      const panels = Array.from({ length: MAX_CAP + 1 }, (_, i) => ({
        id: `panel-${i}`,
        collection: "post",
        route: "panel-route",
      }));
      manifest = {
        ...baseManifest(),
        admin: {
          contentEditorPanels: panels,
        },
      };
    } else if (scenario === "route_not_private") {
      // Reference a route that isn't declared in manifest routes
      manifest = {
        ...baseManifest(),
        admin: {
          contentEditorPanels: [
            { id: "my-panel", collection: "post", route: "undeclared-route" },
          ],
        },
      };
    } else if (scenario === "danger_confirm_missing") {
      manifest = {
        ...baseManifest(),
        admin: {
          contentEditorActions: [
            { id: "my-action", collection: "post", route: "action-route", dangerous: true },
          ],
        },
      };
    } else {
      throw new Error(`Unknown scenario: ${scenario}`);
    }

    const result = pluginManifestSchema.safeParse(manifest);

    if (result.success && scenario === "legal") {
      const panels = result.data.admin?.contentEditorPanels ?? [];
      const actions = result.data.admin?.contentEditorActions ?? [];
      retainedEditorExtensionCount = panels.length + actions.length;
    }

    const outcome = result.success
      ? ("accepted:" + retainedEditorExtensionCount)
      : "rejected";

    expect(outcome).toBe(expected.outcome);
  }, 120_000);
});
