// @ts-nocheck
import { randomUUID } from "node:crypto";
import { describe, expect, it, vi } from "vitest";
import { getTestCases } from "./validationParams";

import {
  EmDashRuntime,
} from "../../../../src/emdash-runtime.js";
import { POST } from "../../../../src/astro/routes/api/plugins/content-editor/[kind]/[collection]/[id]/[extensionId].js";
import { setupTestDatabaseWithCollections, teardownTestDatabase } from "../../../utils/test-db.js";
import { handleContentCreate } from "../../../../src/api/handlers/content.js";
import { createHookPipeline } from "../../../../src/plugins/hooks.js";

// Role levels
const ROLE: Record<string, number> = {
  subscriber: 10,
  contributor: 20,
  author: 30,
  editor: 40,
  admin: 50,
};

async function buildRuntime(opts: {
  db: any;
  pluginId: string;
  pluginVersion: string;
  surface: "panel" | "action";
  routeName: string;
  collection: string;
  extensionId: string;
  captureRef: { invoked: number; ctx: unknown };
  pluginResponse: "valid" | "invalid";
  enabled: boolean;
  declareExtension: boolean; // false -> don't declare -> extension won't resolve
}) {
  const {
    db, pluginId, pluginVersion, surface, routeName, collection, extensionId,
    captureRef, pluginResponse, enabled, declareExtension,
  } = opts;

  // Build a sandboxed plugin instance that captures invocations
  const instance = {
    id: `${pluginId}:${pluginVersion}`,
    invokeHook: vi.fn(),
    invokeRoute: vi.fn(async (rn: string, payload: unknown) => {
      captureRef.invoked += 1;
      captureRef.ctx = payload;
      if (pluginResponse === "invalid") {
        return { not_a_valid_response: true };
      }
      return surface === "panel" ? { blocks: [] } : {};
    }),
    terminate: vi.fn(),
  };

  // Build sandboxed plugin entry
  const entry: any = {
    id: pluginId,
    version: pluginVersion,
    options: {},
    code: "",
    capabilities: [],
    allowedHosts: [],
    storage: {},
    routes: [routeName],
    adminPages: [],
    adminWidgets: [],
  };

  if (declareExtension) {
    if (surface === "panel") {
      entry.contentEditorPanels = [{ id: extensionId, collection, route: routeName }];
    } else {
      entry.contentEditorActions = [{ id: extensionId, collection, route: routeName }];
    }
  }

  // Populate sandboxedPlugins Map with our fake instance
  const sandboxedPlugins = new Map<string, any>();
  sandboxedPlugins.set(`${pluginId}:${pluginVersion}`, instance);

  const enabledPlugins = new Set<string>();
  const pluginStates = new Map<string, string>();
  if (enabled) {
    enabledPlugins.add(pluginId);
  } else {
    pluginStates.set(pluginId, "inactive");
  }

  const hooks = createHookPipeline([], { db });
  const pipelineFactoryOptions = { db };
  const runtimeDeps: any = {
    config: {},
    plugins: [],
    createDialect: () => { throw new Error("unused"); },
    createStorage: null,
    sandboxEnabled: true,
    sandboxedPluginEntries: [entry],
    createSandboxRunner: null,
  };

  const runtime = new EmDashRuntime({
    db,
    storage: null,
    configuredPlugins: [],
    sandboxedPlugins,
    sandboxedPluginEntries: [entry],
    hooks,
    enabledPlugins,
    pluginStates,
    config: {},
    mediaProviders: new Map(),
    mediaProviderEntries: [],
    cronExecutor: null,
    cronScheduler: null,
    emailPipeline: null,
    allPipelinePlugins: [],
    pipelineFactoryOptions,
    runtimeDeps,
    pipelineRef: { current: hooks },
  });

  return runtime;
}

describe("extension-request", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    const db = await setupTestDatabaseWithCollections();
    let runtime: EmDashRuntime | null = null;
    try {
      const surface: "panel" | "action" = inputs.surface === "action" ? "action" : "panel";
      const routeName = "ext-route";
      const pluginId = `fixture-${randomUUID()}`;
      const pluginVersion = randomUUID();
      const extensionId = "my-extension";
      const ownerId = inputs.owner_id as string;
      const locale = inputs.locale as string;
      const routePublic = inputs.route_public as boolean;
      const pluginResponse = inputs.plugin_response as "valid" | "invalid";
      const caseKind = inputs.case_kind as string;

      // Seed the saved entry
      const createResult = await handleContentCreate(db, "post", {
        data: { title: "Test Post" },
        status: "draft",
        authorId: ownerId,
        locale,
      });
      if (!createResult.success) {
        throw new Error("Failed to create test entry");
      }
      const saved = (createResult.data as { item: { id: string } }).item;

      // Track plugin invocations
      const captureRef = { invoked: 0, ctx: null as unknown };

      // When routePublic=true: don't declare the extension so it won't resolve
      // (the runtime resolver skips public routes; we simulate by not declaring)
      const declareExtension = !routePublic;

      runtime = await buildRuntime({
        db, pluginId, pluginVersion, surface, routeName,
        collection: "post", extensionId, captureRef, pluginResponse,
        enabled: true, declareExtension,
      });

      // Spy on handleContentGet to count content loads
      const getSpy = vi.spyOn(runtime, "handleContentGet");
      const contentLoads = () => getSpy.mock.calls.length;

      // Build user from role + ownership
      const roleInput = inputs.role as string | null;
      let user: { id: string; role: number } | null;
      if (!roleInput || !(roleInput in ROLE)) {
        user = null; // unauthenticated
      } else {
        const isOwner = inputs.is_owner as boolean;
        const userId = isOwner ? ownerId : `other-user-${randomUUID()}`;
        user = { id: userId, role: ROLE[roleInput] };
      }

      // Build request
      const kind = surface === "panel" ? "panels" : "actions";
      const baseUrl = `https://example.test/_emdash/api/plugins/content-editor/${kind}/post/${saved.id}/${extensionId}?locale=${locale}`;

      const reqHeaders: Record<string, string> = {
        "Content-Type": "application/json",
      };
      if (inputs.csrf !== false) {
        reqHeaders["X-EmDash-Request"] = "1";
      }

      let bodyValue: unknown;
      if (surface === "panel") {
        const interactionKind = inputs.interaction_kind as string;
        if (interactionKind === "valid") {
          bodyValue = { type: "block_action", action_id: "do-thing", block_id: "blk-1" };
        } else {
          // malformed: block_action missing required action_id
          bodyValue = { type: "block_action", block_id: "blk-1" };
        }
      } else {
        // action: arbitrary body with decoy values the host must NOT forward
        bodyValue = { anything: "IGNORED-VALUE", entry: { id: "FORGED-ID" } };
      }

      const request = new Request(baseUrl, {
        method: "POST",
        headers: reqHeaders,
        body: JSON.stringify(bodyValue),
      });

      const locals = {
        emdash: runtime,
        user,
        tokenScopes: undefined,
      };

      const res = await POST({
        params: { kind, collection: "post", id: saved.id, extensionId },
        request,
        url: new URL(baseUrl),
        locals,
        cache: undefined,
      } as never);

      const s = res.status;
      const statusClass =
        s < 300 ? "ok"
        : s === 401 ? "unauthenticated"
        : s === 403 ? "forbidden"
        : s === 404 ? "not_found"
        : s >= 500 ? "server_error"
        : "client_error";

      const pluginInvoked = captureRef.invoked > 0 ? "yes" : "no";
      const contentLoaded = contentLoads() > 0 ? "yes" : "no";

      let hostContext: string;
      if (caseKind === "panel_happy" || caseKind === "action_happy") {
        const ctxText = JSON.stringify(captureRef.ctx);
        if (caseKind === "panel_happy") {
          hostContext = ctxText.includes(saved.id) ? "has-canonical" : "no-canonical";
        } else {
          hostContext = [
            ctxText.includes(saved.id) ? "has-canonical" : "no-canonical",
            (ctxText.includes("IGNORED-VALUE") || ctxText.includes("FORGED-ID"))
              ? "LEAKED"
              : "clean",
          ].join("|");
        }
      } else {
        hostContext = "__skip__";
      }

      // Assertions — use ALL expected values, skip only "__skip__" sentinels
      if (expected.status_class !== "__skip__") {
        expect(statusClass, `statusClass [${caseKind}]`).toBe(expected.status_class);
      }
      expect(pluginInvoked, `pluginInvoked [${caseKind}]`).toBe(expected.plugin_invoked);
      if (expected.content_loaded !== undefined && expected.content_loaded !== "__skip__") {
        expect(contentLoaded, `contentLoaded [${caseKind}]`).toBe(expected.content_loaded);
      }
      if (expected.host_context !== "__skip__") {
        expect(hostContext, `hostContext [${caseKind}]`).toBe(expected.host_context);
      }
    } finally {
      if (runtime) {
        await runtime.stopCron();
      }
      await teardownTestDatabase(db);
    }
  }, 120_000);
});
