## Task

We want sandboxed plugins to be able to extend the saved-entry editing experience. Add a server-side capability that lets a plugin contribute two kinds of editor extension to a saved entry: a panel, a plugin-rendered surface shown beside the entry, and an action, an operation a user triggers on the entry. Both are served through the existing plugin request path.

The defining rule is the sandbox boundary. When the host invokes a plugin for one of these extensions, the plugin receives only the canonical, already-saved identity of the entry (collection, id, locale, version), the editing surface's locale and text direction, and the extension's identifier. The unsaved values the user is currently editing must never reach the plugin; the host, not the client, decides and builds everything the plugin sees.

Around that, enforce who may act on an entry, keep the plugin payloads within a bounded grammar, and let plugins declare these extensions in their manifest.

Build the server capability, its payload validation, and the manifest declarations only. No admin or web UI, browser flows, or external CLI and marketplace tooling.

## User stories / requirements

- When a user triggers a plugin editor extension on a saved entry, the host reloads the saved entry and only proceeds for an authenticated user who owns the entry or holds the elevated content-editing permission, with a valid same-origin signal, over a private plugin route. It then invokes the plugin with only that host-built context.
- For a request the host resolves exactly one enabled extension whose collection matches the entry. If none matches, or more than one would, the request is a not-found.
- A user can trigger a plugin editor extension on a saved entry over the plugin request path, and the host serves that request by running the extension for the entry.
- Panel interactions come in a small fixed set of kinds, each permitting only its own fields. Action responses may only ask the host to show a brief notification, refresh the current view, or navigate to a validated destination, with sensible mutual exclusivity. Anything outside the grammar is an error, not forwarded to the client.
- A plugin declares its editor panels and actions in its manifest. It is accepted when identifiers follow the usual slug shape, counts stay within their caps, identifiers are unique, and each extension names the private route serving it, and a dangerous action declares a confirmation step. Violating any bound is rejected.
