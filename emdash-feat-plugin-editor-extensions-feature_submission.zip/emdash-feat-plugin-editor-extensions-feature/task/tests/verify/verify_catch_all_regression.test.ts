// Pass-to-pass regression guard for the pre-existing plugin API catch-all
// (`/_emdash/api/plugins/{id}/*`). The new saved-entry capability factors the
// private-route policy (CSRF + permission + scope) that this catch-all already
// enforces; whether a solution extracts a shared authorizer or inlines it, the
// catch-all's observable authorization behavior must not change.
//
// This drives the catch-all's own GET/POST exports — a pre-existing, stable
// module that exists at the base commit — through a mocked runtime, exactly as
// the repo's own regression suite does. It imports no code the solution invents.
import { Role, type RoleLevel } from "@emdash-cms/auth";
import type { APIRoute } from "astro";
import { describe, expect, it, vi } from "vitest";

import { GET, POST } from "../../../src/astro/routes/api/plugins/[pluginId]/[...path].js";

function createLocals(role: RoleLevel | null, routePublic: boolean, permission?: string) {
	const handlePluginApiRoute = vi.fn(async () => ({ success: true, data: { ok: true } }));
	return {
		locals: {
			user: role == null ? null : { id: "u1", role },
			emdash: {
				handlePluginApiRoute,
				getPluginRouteMeta: () => ({ public: routePublic, permission }),
			},
		},
		handlePluginApiRoute,
	};
}

function invoke(
	handler: APIRoute,
	method: string,
	locals: unknown,
	{ csrf = true }: { csrf?: boolean } = {},
) {
	const headers = new Headers();
	if (csrf) headers.set("X-EmDash-Request", "1");
	const request = new Request("https://example.com/_emdash/api/plugins/demo/updateHomeConfig", {
		method,
		headers,
	});
	return handler({
		params: { pluginId: "demo", path: "updateHomeConfig" },
		request,
		locals,
	} as never);
}

describe("plugin API catch-all authorization (regression)", () => {
	it("blocks an editor on a private route via POST", async () => {
		const { locals, handlePluginApiRoute } = createLocals(Role.EDITOR, false);
		const res = await invoke(POST, "POST", locals);
		expect(res.status).toBe(403);
		expect(handlePluginApiRoute).not.toHaveBeenCalled();
	});

	it("blocks an editor on a private route via GET (method does not tier auth)", async () => {
		const { locals, handlePluginApiRoute } = createLocals(Role.EDITOR, false);
		const res = await invoke(GET, "GET", locals);
		expect(res.status).toBe(403);
		expect(handlePluginApiRoute).not.toHaveBeenCalled();
	});

	it("honors a private route's explicitly declared permission", async () => {
		const { locals, handlePluginApiRoute } = createLocals(Role.EDITOR, false, "content:create");
		const res = await invoke(POST, "POST", locals);
		expect(res.status).toBe(200);
		expect(handlePluginApiRoute).toHaveBeenCalledOnce();
	});

	it("rejects a private request without the same-origin signal even for an admin", async () => {
		const { locals, handlePluginApiRoute } = createLocals(Role.ADMIN, false);
		const res = await invoke(GET, "GET", locals, { csrf: false });
		expect(res.status).toBe(403);
		expect(handlePluginApiRoute).not.toHaveBeenCalled();
	});

	it("allows an admin carrying the same-origin signal", async () => {
		const { locals, handlePluginApiRoute } = createLocals(Role.ADMIN, false);
		const res = await invoke(POST, "POST", locals);
		expect(res.status).toBe(200);
		expect(handlePluginApiRoute).toHaveBeenCalledOnce();
	});

	it("leaves public routes reachable without auth or the same-origin signal", async () => {
		const { locals, handlePluginApiRoute } = createLocals(null, true);
		const res = await invoke(GET, "GET", locals, { csrf: false });
		expect(res.status).toBe(200);
		expect(handlePluginApiRoute).toHaveBeenCalledOnce();
	});

	it("forwards the authenticated caller for private routes", async () => {
		const { locals, handlePluginApiRoute } = createLocals(Role.ADMIN, false);
		const res = await invoke(POST, "POST", locals);
		expect(res.status).toBe(200);
		// Assert the semantic leading positions only — NOT the full call arity.
		// The forwarding runtime method is a pre-existing stable interface whose
		// first positions (id, method, path, forwarded request, caller) are the
		// contract; any trailing optional arguments it grows are an internal
		// dispatch detail a solution is free to add, so pinning the exact arity
		// (toHaveBeenCalledWith) would be a false-negative trap. The caller
		// identity is the real regression signal.
		expect(handlePluginApiRoute).toHaveBeenCalledOnce();
		const [pluginId, method, path, forwardedRequest, caller] =
			handlePluginApiRoute.mock.calls[0];
		expect(pluginId).toBe("demo");
		expect(method).toBe("POST");
		expect(path).toBe("/updateHomeConfig");
		// The forwarded request object: assert only that it is present and
		// request-shaped. Its constructor identity is environment-dependent (the
		// route may build the Request from a different global realm than this
		// test file's), so a constructor matcher is a false-negative trap.
		expect(forwardedRequest).toBeTruthy();
		expect(typeof (forwardedRequest as Request).method).toBe("string");
		expect(caller).toMatchObject({ id: "u1", role: Role.ADMIN });
	});

	it("does not bind an ambient session as the caller of a public route", async () => {
		const { locals, handlePluginApiRoute } = createLocals(Role.ADMIN, true);
		const res = await invoke(GET, "GET", locals, { csrf: false });
		expect(res.status).toBe(200);
		expect(handlePluginApiRoute).toHaveBeenCalledOnce();
		const [pluginId, method, path, forwardedRequest, caller] =
			handlePluginApiRoute.mock.calls[0];
		expect(pluginId).toBe("demo");
		expect(method).toBe("GET");
		expect(path).toBe("/updateHomeConfig");
		// See note above: assert presence, not constructor identity.
		expect(forwardedRequest).toBeTruthy();
		// No caller is bound for a public route (the ambient admin session must
		// NOT leak through as the caller) — this undefined is the regression signal.
		expect(caller).toBeUndefined();
	});
});
