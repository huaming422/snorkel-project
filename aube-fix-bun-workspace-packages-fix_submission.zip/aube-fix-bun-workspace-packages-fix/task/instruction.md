## Task

heads up: the `bun.lock` files we generate for monorepo projects come out wrong, they're missing the project's own workspace packages. plain single-package projects are fine, but as soon as a project has workspaces, those packages don't show up in the lockfile we write. and because they're missing, a dependency from one workspace package to another silently gets dropped once you write the lockfile out and read it back. our output is supposed to match what bun itself produces here. can you dig into why and fix it?
