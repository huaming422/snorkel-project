#!/usr/bin/env bash
# Test-setup for aube-fix-bun-workspace-packages.
#
# The image already baked the full dependency closure and ran
# `cargo build --locked --tests` at the base commit, so the cargo registry
# and git caches are warm and /opt/cache/cargo-target holds compiled
# dependencies. This script just re-warms the one crate the verifier
# exercises (aube-lockfile and its path deps) so the verifier's first
# `cargo test` only has to compile the injected test binary. No services to
# start, no data to seed.
#
# Offline-first: the warm build runs under `--offline`; if that ever fails
# (e.g. an agent added a dependency not yet in the baked cache) it logs and
# retries online, since test-setup runs with network while the agent phase
# does not.
set -euo pipefail

cd /repo/aube

echo "[test-setup] rustc:           $(rustc --version 2>&1 | head -1)"
echo "[test-setup] cargo:           $(cargo --version 2>&1 | head -1)"
echo "[test-setup] workspace root:  /repo/aube"
echo "[test-setup] target dir:      ${CARGO_TARGET_DIR:-target}"

warm() {
    # Build the verifier's crate and its dev-dependencies (lib + test deps)
    # without running anything, so the compile is cached before grading.
    cargo build -p aube-lockfile --tests "$@"
}

echo "[test-setup] warming aube-lockfile build (offline)..."
if warm --offline > /tmp/test-setup-warm.log 2>&1; then
    echo "[test-setup] offline warm build OK"
else
    echo "[test-setup] offline warm build failed; last lines:" >&2
    tail -40 /tmp/test-setup-warm.log >&2
    echo "[test-setup] retrying online (test-setup has network)..." >&2
    warm > /tmp/test-setup-warm-online.log 2>&1 || {
        echo "[test-setup] online warm build also failed:" >&2
        tail -60 /tmp/test-setup-warm-online.log >&2
        exit 1
    }
    echo "[test-setup] online warm build OK"
fi

echo "[test-setup] setup complete."
