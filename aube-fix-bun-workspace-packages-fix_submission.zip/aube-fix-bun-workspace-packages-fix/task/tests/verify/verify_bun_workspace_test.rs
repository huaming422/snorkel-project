//! Behavioral verifier for the bun.lock workspace-package emission fix.
//!
//! Tests through the crate's PUBLIC API only, exactly like a downstream
//! consumer: build a `LockfileGraph` for a two-package monorepo, serialize
//! it with [`write_lockfile_as`] in bun format, then read it back with
//! [`parse_lockfile`]. No private helpers are referenced, so the checks are
//! independent of whichever internal strategy the solution uses to emit the
//! workspace entries (removing the skip branch, a dedicated append pass,
//! folding the emission into the shared entry builder, etc.).
//!
//! Fixture: a root project with two workspace packages, `storefront` at
//! `packages/storefront` depending on `ui-kit` at `packages/ui-kit` via
//! `workspace:*`. The names/paths are deliberately distinct from any used in
//! the repo's own tests so a hard-coded ident string cannot satisfy the
//! checks.
//!
//! Before the fix, the bun writer drops `workspace:`-sourced packages from the
//! lockfile's package list entirely. Both checks below fail in that state: the
//! workspace idents never appear in the written file, and because the
//! depending package is never emitted, its edge to the other workspace package
//! has nowhere to live and is gone after a write/read round trip.

use std::collections::BTreeMap;
use std::path::{Path, PathBuf};

use aube_lockfile::{
    parse_lockfile, write_lockfile_as, DirectDep, LocalSource, LockedPackage, LockfileGraph,
    LockfileKind,
};
use tempfile::TempDir;

/// Write the root + workspace `package.json` files into `dir` and return the
/// in-memory graph plus the root manifest the writer needs. The on-disk
/// manifests are required because the bun writer reads each non-root
/// workspace's `package.json` from disk when building the lockfile.
fn fixture(dir: &Path) -> (LockfileGraph, aube_manifest::PackageJson) {
    std::fs::write(
        dir.join("package.json"),
        r#"{"name":"storefront-monorepo","version":"1.0.0","workspaces":["packages/*"]}"#,
    )
    .unwrap();
    std::fs::create_dir_all(dir.join("packages/storefront")).unwrap();
    std::fs::create_dir_all(dir.join("packages/ui-kit")).unwrap();
    std::fs::write(
        dir.join("packages/storefront/package.json"),
        r#"{"name":"storefront","version":"0.1.0","dependencies":{"ui-kit":"workspace:*"}}"#,
    )
    .unwrap();
    std::fs::write(
        dir.join("packages/ui-kit/package.json"),
        r#"{"name":"ui-kit","version":"0.1.0"}"#,
    )
    .unwrap();

    let mut packages: BTreeMap<String, LockedPackage> = BTreeMap::new();
    packages.insert(
        "storefront@workspace:packages/storefront".to_string(),
        LockedPackage {
            name: "storefront".to_string(),
            version: "workspace:packages/storefront".to_string(),
            dep_path: "storefront@workspace:packages/storefront".to_string(),
            local_source: Some(LocalSource::Link(PathBuf::from("packages/storefront"))),
            dependencies: [(
                "ui-kit".to_string(),
                "ui-kit@workspace:packages/ui-kit".to_string(),
            )]
            .into(),
            declared_dependencies: [("ui-kit".to_string(), "workspace:*".to_string())].into(),
            ..Default::default()
        },
    );
    packages.insert(
        "ui-kit@workspace:packages/ui-kit".to_string(),
        LockedPackage {
            name: "ui-kit".to_string(),
            version: "workspace:packages/ui-kit".to_string(),
            dep_path: "ui-kit@workspace:packages/ui-kit".to_string(),
            local_source: Some(LocalSource::Link(PathBuf::from("packages/ui-kit"))),
            ..Default::default()
        },
    );

    let mut importers: BTreeMap<String, Vec<DirectDep>> = BTreeMap::new();
    importers.insert(".".to_string(), vec![]);
    importers.insert("packages/storefront".to_string(), vec![]);
    importers.insert("packages/ui-kit".to_string(), vec![]);

    let graph = LockfileGraph {
        importers,
        packages,
        ..Default::default()
    };
    let manifest = aube_manifest::PackageJson::from_path(&dir.join("package.json")).unwrap();
    (graph, manifest)
}

/// Locate a parsed package by its declared name, independent of the map key
/// the parser chose for it.
fn find_pkg<'a>(graph: &'a LockfileGraph, name: &str) -> &'a LockedPackage {
    graph
        .packages
        .values()
        .find(|p| p.name == name)
        .unwrap_or_else(|| {
            panic!(
                "workspace package `{name}` missing from parsed lockfile graph; \
                 present packages: {:?}",
                graph.packages.values().map(|p| &p.name).collect::<Vec<_>>()
            )
        })
}

/// The written bun.lock must list each workspace package by its
/// `name@workspace:<rel-path>` ident. Pre-fix the idents are absent entirely.
#[test]
fn emits_workspace_packages_into_lockfile() {
    let project = TempDir::new().unwrap();
    let dir = project.path();
    let (graph, manifest) = fixture(dir);

    let lock_path = write_lockfile_as(dir, &graph, &manifest, LockfileKind::Bun).unwrap();
    let raw = std::fs::read_to_string(&lock_path).unwrap();

    assert!(
        raw.contains("storefront@workspace:packages/storefront"),
        "written bun.lock omits the `storefront` workspace package:\n{raw}"
    );
    assert!(
        raw.contains("ui-kit@workspace:packages/ui-kit"),
        "written bun.lock omits the `ui-kit` workspace package:\n{raw}"
    );
}

/// After a write then read, both workspace packages come back as local links
/// and the storefront -> ui-kit edge survives. Pre-fix the depending package
/// is never written, so the edge is lost on the round trip.
#[test]
fn preserves_workspace_to_workspace_edge_on_round_trip() {
    let project = TempDir::new().unwrap();
    let dir = project.path();
    let (graph, manifest) = fixture(dir);

    write_lockfile_as(dir, &graph, &manifest, LockfileKind::Bun).unwrap();
    let parsed = parse_lockfile(dir, &manifest).unwrap();

    let storefront = find_pkg(&parsed, "storefront");
    let ui_kit = find_pkg(&parsed, "ui-kit");

    assert!(
        matches!(storefront.local_source, Some(LocalSource::Link(_))),
        "`storefront` should round-trip as a workspace link, got {:?}",
        storefront.local_source
    );
    assert!(
        matches!(ui_kit.local_source, Some(LocalSource::Link(_))),
        "`ui-kit` should round-trip as a workspace link, got {:?}",
        ui_kit.local_source
    );
    assert_eq!(
        storefront.dependencies.get("ui-kit"),
        Some(&ui_kit.dep_path),
        "the storefront -> ui-kit workspace edge was lost on the write/read round trip; \
         storefront dependencies: {:?}",
        storefront.dependencies
    );
}
