## Task

Org owners want to give a team one permission, write or admin, that covers every unit of the organization's repositories, unit types added to Gitea later included, without granting units one at a time. Admin teams already work this way. Write teams do not: a member of a team given write reaches only the units granted to that team individually, and a unit added later stays out of reach until someone edits the team. Teams set up unit by unit should keep working exactly as they do now.

The organization team endpoints of the REST API carry these settings in their `permission`, `units_map` and older `units` fields. Changes to the team web form and its wording are optional.

## User stories / requirements

- A write team's members reach every unit of the team's repositories, units nobody set up included, at the strongest level each unit allows: write, or read for a read-only unit such as an external issue tracker. Admin teams keep full access, and per-unit teams reach only the units they list.
- Via the REST API, write and admin teams read back their permission without contradicting per-unit entries, and members reach units nobody set up; per-unit teams read back their entries, no single permission. Description-only edits change nothing else. Units plus a per-unit map, or neither permission nor units, get a client error and no team.
- A write team's members find the team's repositories in code search and the organization's Actions run list, count as members of them when a signed commit's trust is decided, and are notified when the team is mentioned in their issues. Per-unit teams get each of these only through a unit they list.
- A write team's members can open the organization's project boards and create new ones. Members of a per-unit team get the level the team lists for projects.
