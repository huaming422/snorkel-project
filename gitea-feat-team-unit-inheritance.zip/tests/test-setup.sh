#!/usr/bin/env bash
#
# Sourced (not exec'd, so exported env sticks) before the focused tests run.
# The image already pre-warmed the Go module + build caches, switched Go to
# offline mode (GOFLAGS=-mod=mod, GOPROXY=off), and materialised
# tests/sqlite.ini. This script makes the environment robust against an agent's
# edits and a freshly-spawned shell that did not inherit the image ENV.
#
# The agent phase is no-network (agent_offline = true); the verifier phase has
# allowlisted network (model gateway only). Everything below is offline-safe:
# the dependency closure and build cache are baked at the base commit, so the
# warm-up compiles entirely from cache.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/gitea}"
cd "$REPO_DIR"

# Build tags & cgo are required for sqlite-backed unittest.MainTest. The image
# exports these already; repeat them so a scrubbed/fresh shell still sees them.
export CGO_ENABLED=1
export GOEXPERIMENT=jsonv2
export GOTOOLCHAIN=local

# Keep Go offline even if the ENV was scrubbed: a cache miss must fail fast
# rather than hang on a dead network during the agent phase.
export GOFLAGS=-mod=mod
export GOPROXY=off

# Make `go` discoverable even when the harness scrubs PATH.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

# Re-materialise tests/sqlite.ini if it is missing (defensive: the image build
# creates it, but an agent's `git clean -fdx` would erase it). The sqlite
# unittest harness reads I_AM_BEING_UNSAFE_RUNNING_AS_ROOT from the config file
# because UnsetUnnecessaryEnvVars scrubs the GITEA_* env-var path before
# loadRunModeFrom. The flag must also live in the TEMPLATE: the integration
# harness's PrepareIntegrationTestConfig regenerates tests/sqlite.ini from the
# template at run time, so a flag present only in the .ini would be lost. The
# template carries three placeholders ({{TEST_WORK_PATH}}, {{TEST_LOGGER}},
# {{GITEA_TEST_ROOT}}); substitute them with the same values the harness uses.
if ! grep -q '^I_AM_BEING_UNSAFE_RUNNING_AS_ROOT' tests/sqlite.ini.tmpl; then
    sed -i '1a I_AM_BEING_UNSAFE_RUNNING_AS_ROOT = true' tests/sqlite.ini.tmpl
fi
if [[ ! -f tests/sqlite.ini ]]; then
    sed -e 's|{{TEST_WORK_PATH}}|/repo/gitea/tests/integration/gitea-integration-sqlite|g' \
        -e 's|{{TEST_LOGGER}}|test,file|g' \
        -e 's|{{GITEA_TEST_ROOT}}|/repo/gitea|g' \
        tests/sqlite.ini.tmpl > tests/sqlite.ini
fi

# Warm the typechecker for the packages the reward stack exercises. `go vet`
# type-checks (including the _test variant under the given tags) without
# executing TestMain, which would otherwise bring up the sqlite test DB. Runs
# fully from the baked build cache; errors are non-fatal here (the actual test
# run reports real failures).
go vet -tags 'sqlite sqlite_unlock_notify' \
    ./models/perm/access/... \
    ./models/organization/... \
    ./models/repo/... \
    ./models/issues/... \
    ./services/org/... \
    ./services/convert/... \
    >/dev/null 2>&1 || true

echo "test-setup.sh: ready (CGO_ENABLED=$CGO_ENABLED, GOPROXY=$GOPROXY, tags='sqlite sqlite_unlock_notify')"
