#!/usr/bin/env bash
#
# Validation environment setup for the team-unit-inheritance feature. Runs
# after tests/test-setup.sh and layers on the bits the go-test validation
# driver needs, defensive against an agent having wiped image-time state.
#
# All four stories run in tests/integration and drive the in-process web and
# REST harness via PrepareTestEnv, which installs server-side git hooks that
# shell out to the `gitea` binary, so that binary must exist and
# GITEA_TEST_CONF must point at the sqlite integration config.
# IDEMPOTENT: may be sourced multiple times.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/gitea}"

cd "$REPO_DIR"

# Re-export the Go toolchain knobs the go-test driver depends on (the image
# exports these; repeat them so a scrubbed/fresh shell still sees them).
export CGO_ENABLED="${CGO_ENABLED:-1}"
export GOEXPERIMENT="${GOEXPERIMENT:-jsonv2}"
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"
export GOCACHE="${GOCACHE:-/root/.cache/go-build}"
export GOMODCACHE="${GOMODCACHE:-/root/go/pkg/mod}"
export GITEA_TEST_CONF="${GITEA_TEST_CONF:-tests/sqlite.ini}"

# Keep Go offline even if the ENV was scrubbed: a cache miss must fail fast
# rather than hang on a dead network.
export GOFLAGS="${GOFLAGS:--mod=mod}"
export GOPROXY="${GOPROXY:-off}"

mkdir -p "$GOCACHE" "$GOMODCACHE"

# Make `go` reachable even if the harness scrubbed PATH.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

# Ensure tests/sqlite.ini exists with the root-unsafe flag. The sqlite test
# harness reads I_AM_BEING_UNSAFE_RUNNING_AS_ROOT from this file because env-var
# scrubbing happens before the root check. The integration stories'
# PrepareIntegrationTestConfig REGENERATES tests/sqlite.ini from
# tests/sqlite.ini.tmpl at run time, so the flag must live in the TEMPLATE to
# survive that regeneration — a flag only in the .ini would be discarded. The
# template ships three placeholders ({{TEST_WORK_PATH}}, {{TEST_LOGGER}},
# {{GITEA_TEST_ROOT}}); substitute them with the harness's own values. The image
# build already did all of this, but a `git clean -fdx` from the agent could wipe
# the generated .ini (the committed .tmpl flag survives a clean).
if ! grep -q '^I_AM_BEING_UNSAFE_RUNNING_AS_ROOT' tests/sqlite.ini.tmpl; then
    sed -i '1a I_AM_BEING_UNSAFE_RUNNING_AS_ROOT = true' tests/sqlite.ini.tmpl
fi
if [[ ! -f tests/sqlite.ini ]]; then
    sed -e 's|{{TEST_WORK_PATH}}|/repo/gitea/tests/integration/gitea-integration-sqlite|g' \
        -e 's|{{TEST_LOGGER}}|test,file|g' \
        -e 's|{{GITEA_TEST_ROOT}}|/repo/gitea|g' \
        tests/sqlite.ini.tmpl > tests/sqlite.ini
fi

# The integration stories' harness installs server-side hooks that exec the
# `gitea` binary, so repository setup in those tests fails without it. Build it
# once when it is missing. The module path for this repo is `gitea.dev` (NOT
# code.gitea.io/gitea). The web and REST behavior under test is served
# in-process by the test binary, so this binary only has to exist.
if [[ ! -x "$REPO_DIR/gitea" ]]; then
    go build -tags 'sqlite sqlite_unlock_notify' -o "$REPO_DIR/gitea" gitea.dev
fi

# Install the stories' helpers next to the story test files. The source lives in
# tests/validate/helpers/; every story procedure names its helper. The copy is a _test.go file
# in package integration, so it compiles only into that package's test binary. Overwritten on
# every run, so sourcing this script again is harmless.
HELPERS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-/tests/validate/validation-setup.sh}")" && pwd)/helpers"
install -m 0644 "$HELPERS_DIR/team_access_helper_test.go" \
    "$REPO_DIR/tests/integration/validation_team_access_helper_test.go"

# Belt-and-suspenders module check against the warm cache. Offline-first: the
# image baked the full module closure at the base commit and GOPROXY=off keeps
# us from reaching the network, so this is a no-op verification. Fall back to a
# logged online fetch only if the offline pass reports a gap.
if ! GOFLAGS=-mod=mod GOPROXY=off go mod download 2>/dev/null; then
    echo "validation-setup.sh: offline module check incomplete; attempting online fetch" >&2
    go mod download || true
fi

echo "validation-setup.sh: ready (CGO_ENABLED=$CGO_ENABLED, tags='sqlite sqlite_unlock_notify', GITEA_TEST_CONF=$GITEA_TEST_CONF, gitea binary present, story helpers installed)"
