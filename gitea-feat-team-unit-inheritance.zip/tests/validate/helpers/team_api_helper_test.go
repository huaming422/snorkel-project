// Validation helper for the team_permission_api_roundtrip story. tests/validate/validation-setup.sh
// copies this file into tests/integration/, next to the story's test file, so the story's test
// calls it directly (same package, integration).

package integration

import (
	"fmt"
	"net/http"
	"strings"
	"sync/atomic"
	"testing"

	auth_model "gitea.dev/models/auth"
	"gitea.dev/models/db"
	"gitea.dev/models/organization"
	perm_model "gitea.dev/models/perm"
	access_model "gitea.dev/models/perm/access"
	repo_model "gitea.dev/models/repo"
	"gitea.dev/models/unit"
	"gitea.dev/models/unittest"
	user_model "gitea.dev/models/user"
	api "gitea.dev/modules/structs"

	"github.com/stretchr/testify/require"
)

var validationTeamAPISeq atomic.Int64

// validationTeamAPIAccessName renders an access level the way the story's expected values spell it.
func validationTeamAPIAccessName(m perm_model.AccessMode) string {
	switch {
	case m >= perm_model.AccessModeOwner:
		return "owner"
	case m == perm_model.AccessModeAdmin:
		return "admin"
	case m == perm_model.AccessModeWrite:
		return "write"
	case m == perm_model.AccessModeRead:
		return "read"
	default:
		return "none"
	}
}

// validationTeamAPI reloads the fixtures, takes user28 out of every team of organization org3,
// signs in as the site administrator (user1), runs one team scenario against org3 through the
// REST API, and reports what it observed.
// It needs a running test environment: call it inside a test that started with
// `defer tests.PrepareTestEnv(t)()`.
//
// inputs (all four keys are present in every case):
//
//	"kind"        which requests to send, below
//	"permission"  the single team permission to send, a string ("" sends none)
//	"units"       the older units list to send, a list of unit keys (may be empty)
//	"units_map"   per-unit permissions to send, a map of unit key to level (may be empty)
//
// kinds:
//
//	"blanket"           POST /api/v1/orgs/org3/teams with only the permission
//	"both"              POST with the permission, the units list AND the per-unit map
//	"empty"             POST with an empty permission and no per-unit settings
//	"granular"          POST with only the per-unit map
//	"units_list"        POST with the permission and the units list, no per-unit map
//	"edit_description"  POST with only the per-unit map, then PATCH /api/v1/teams/{id} that sends
//	                    only a new description
//	"edit_to_units"     POST with only the permission, then PATCH /api/v1/teams/{id} that sends
//	                    only the per-unit map
//	"edit_to_blanket"   POST with only the per-unit map, then PATCH /api/v1/teams/{id} that sends
//	                    only the permission
//	"edit_units_list"   POST with only the permission, then PATCH /api/v1/teams/{id} that sends
//	                    the permission and the units list, no per-unit map
//
// The result has every key below for every kind; "" means the key does not apply:
//
//	"http_class"     "2xx", "3xx", "4xx" or "5xx" for the last request sent (the PATCH for the edit
//	                 kinds; for those, a failed POST ends the scenario and its class is reported)
//	"team_created"   "yes" when organization org3 now has a team of the name the POST sent, else "no"
//	"permission"     the team's permission as GET /api/v1/teams/{id} reads it back (lower case), or
//	                 "" when there is no team
//	"code_entry"     the per-unit entry GET /api/v1/teams/{id} reads back for "repo.code" ("" when
//	                 absent); reported for granular, units_list, edit_description, edit_to_units
//	                 and edit_units_list only
//	"issues_entry"   the same for "repo.issues"
//	"blanket_view"   for blanket and edit_to_blanket only: "agrees" when the read-back per-unit
//	                 entries for "repo.code" and "repo.issues" are each absent or equal to the
//	                 team's permission (an empty per-unit map agrees; for admin, "owner" also
//	                 agrees), else "disagrees"
//	"member_actions" for any kind that left a team: the team gets member user28 and repository
//	                 org3/repo3 (user28 has no other access to it), the team's per-unit entry for
//	                 the actions unit is removed if it has one (as for a unit added to the product
//	                 after the team was set up), access records are recalculated, and this is
//	                 user28's access to repo3's actions unit: "none", "read", "write", "admin" or
//	                 "owner"
func validationTeamAPI(t *testing.T, inputs map[string]any) map[string]string {
	t.Helper()
	require.NoError(t, unittest.LoadFixtures())
	ctx := t.Context()
	// user28 reaches org3/repo3 only through the team this scenario builds.
	_, err := db.GetEngine(ctx).Where("org_id = ? AND uid = ?", 3, 28).Delete(new(organization.TeamUser))
	require.NoError(t, err)

	kind, _ := inputs["kind"].(string)
	permission, _ := inputs["permission"].(string)
	units := []string{}
	if raw, ok := inputs["units"].([]any); ok {
		for _, v := range raw {
			s, _ := v.(string)
			units = append(units, s)
		}
	}
	unitsMap := map[string]string{}
	if raw, ok := inputs["units_map"].(map[string]any); ok {
		for k, v := range raw {
			s, _ := v.(string)
			unitsMap[k] = s
		}
	}

	admin := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 1})
	token := getTokenForLoggedInUser(t, loginUser(t, admin.Name), auth_model.AccessTokenScopeWriteOrganization)
	name := fmt.Sprintf("validation-%s-%d", strings.ReplaceAll(kind, "_", "-"), validationTeamAPISeq.Add(1))
	class := func(code int) string { return fmt.Sprintf("%dxx", code/100) }

	create := &api.CreateTeamOption{Name: name}
	switch kind {
	case "blanket", "empty", "edit_to_units", "edit_units_list":
		create.Permission = api.RepoWritePermission(permission)
	case "both":
		create.Permission = api.RepoWritePermission(permission)
		create.Units = units
		create.UnitsMap = unitsMap
	case "units_list":
		create.Permission = api.RepoWritePermission(permission)
		create.Units = units
	case "granular", "edit_description", "edit_to_blanket":
		create.UnitsMap = unitsMap
	default:
		t.Fatalf("validationTeamAPI: unknown kind %q", kind)
	}
	resp := MakeRequest(t, NewRequestWithJSON(t, "POST", "/api/v1/orgs/org3/teams", create).AddTokenAuth(token), NoExpectedStatus)
	last := resp.Code
	var teamID int64
	if resp.Code/100 == 2 {
		teamID = DecodeJSON(t, resp, &api.Team{}).ID
		var edit *api.EditTeamOption
		switch kind {
		case "edit_description":
			desc := "edited description"
			edit = &api.EditTeamOption{Description: &desc}
		case "edit_to_units":
			edit = &api.EditTeamOption{UnitsMap: unitsMap}
		case "edit_to_blanket":
			edit = &api.EditTeamOption{Permission: api.RepoWritePermission(permission)}
		case "edit_units_list":
			edit = &api.EditTeamOption{Permission: api.RepoWritePermission(permission), Units: units}
		}
		if edit != nil {
			last = MakeRequest(t, NewRequestWithJSON(t, "PATCH", fmt.Sprintf("/api/v1/teams/%d", teamID), edit).AddTokenAuth(token), NoExpectedStatus).Code
		}
	}

	out := map[string]string{
		"http_class": class(last), "team_created": "no", "permission": "", "code_entry": "",
		"issues_entry": "", "blanket_view": "", "member_actions": "",
	}
	team, err := organization.GetTeam(ctx, 3, name)
	if err != nil {
		require.True(t, organization.IsErrTeamNotExist(err), "looking up team %q: %v", name, err)
		return out
	}
	out["team_created"] = "yes"

	got := MakeRequest(t, NewRequestf(t, "GET", "/api/v1/teams/%d", team.ID).AddTokenAuth(token), http.StatusOK)
	apiTeam := DecodeJSON(t, got, &api.Team{})
	out["permission"] = strings.ToLower(string(apiTeam.Permission))
	switch kind {
	case "granular", "units_list", "edit_description", "edit_to_units", "edit_units_list":
		out["code_entry"] = apiTeam.UnitsMap["repo.code"]
		out["issues_entry"] = apiTeam.UnitsMap["repo.issues"]
	case "blanket", "edit_to_blanket":
		out["blanket_view"] = "agrees"
		for _, key := range []string{"repo.code", "repo.issues"} {
			v := strings.ToLower(apiTeam.UnitsMap[key])
			if v != "" && v != out["permission"] && (out["permission"] != "admin" || v != "owner") {
				out["blanket_view"] = "disagrees"
			}
		}
	}

	require.NoError(t, db.Insert(ctx, &organization.TeamUser{OrgID: 3, TeamID: team.ID, UID: 28}))
	require.NoError(t, db.Insert(ctx, &organization.TeamRepo{OrgID: 3, TeamID: team.ID, RepoID: 3}))
	_, err = db.GetEngine(ctx).Where("team_id = ? AND `type` = ?", team.ID, unit.TypeActions).Delete(new(organization.TeamUnit))
	require.NoError(t, err)
	repo := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 3})
	require.NoError(t, repo.LoadOwner(ctx))
	require.NoError(t, access_model.RecalculateAccesses(ctx, repo))
	repo = unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 3})
	member := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 28})
	perm, err := access_model.GetDoerRepoPermission(ctx, repo, member)
	require.NoError(t, err)
	out["member_actions"] = validationTeamAPIAccessName(perm.UnitAccessMode(unit.TypeActions))
	return out
}
