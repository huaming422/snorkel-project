// Validation helper for the team_write_repo_visibility story. tests/validate/validation-setup.sh
// copies this file into models/repo/, next to the story's test file, so the story's test calls it
// directly (same package, repo_test).

package repo_test

import (
	"slices"
	"testing"

	"gitea.dev/models/db"
	issues_model "gitea.dev/models/issues"
	"gitea.dev/models/organization"
	perm_model "gitea.dev/models/perm"
	"gitea.dev/models/perm/access"
	repo_model "gitea.dev/models/repo"
	"gitea.dev/models/unit"
	"gitea.dev/models/unittest"
	user_model "gitea.dev/models/user"

	"github.com/stretchr/testify/require"
)

// validationTeamRepoReach starts from the unit-test fixtures with every team removed and builds
// ONE team in organization 3 that holds private repository 3 and has user 28 as its only member:
//
//	teamMode "write":           the team's single permission is write; nothing configured per unit
//	teamMode "granular_code":   no single permission; one per-unit entry, code at write
//	teamMode "granular_issues": no single permission; one per-unit entry, issues at read
//
// User 28 has no other access to repository 3. The repository's access records are then
// recalculated the way adding a member or a repository to a team does, and the helper reports
// how user 28 reaches repository 3 through four lookups:
//
//	"code_search"   "visible" when repository 3 is among the organization 3 repositories whose
//	                code user 28 may search, else "hidden"
//	"actions_runs"  "visible" when repository 3 is among the organization 3 repositories whose
//	                Actions runs user 28 may list, else "hidden"
//	"membership"    "member" when user 28 counts as the owner, a collaborator or a team member
//	                of repository 3 (the check signed-commit trust uses), else "none"
//	"team_mention"  "notified" when mentioning the team as @org3/validation-team in issue 6 (an
//	                issue of repository 3) reaches user 28, else "not notified"
func validationTeamRepoReach(t *testing.T, teamMode string) map[string]string {
	t.Helper()
	require.NoError(t, unittest.PrepareTestDatabase())
	ctx := t.Context()
	require.NoError(t, db.TruncateBeans(ctx,
		&organization.Team{}, &organization.TeamUser{},
		&organization.TeamRepo{}, &organization.TeamUnit{}))

	team := &organization.Team{OrgID: 3, LowerName: "validation-team", Name: "validation-team"}
	var row *organization.TeamUnit
	switch teamMode {
	case "write":
		team.AccessMode = perm_model.AccessModeWrite
	case "granular_code":
		team.AccessMode = perm_model.AccessModeNone
		row = &organization.TeamUnit{OrgID: 3, Type: unit.TypeCode, AccessMode: perm_model.AccessModeWrite}
	case "granular_issues":
		team.AccessMode = perm_model.AccessModeNone
		row = &organization.TeamUnit{OrgID: 3, Type: unit.TypeIssues, AccessMode: perm_model.AccessModeRead}
	default:
		t.Fatalf("validationTeamRepoReach: unknown teamMode %q", teamMode)
	}
	require.NoError(t, db.Insert(ctx, team))
	require.NoError(t, db.Insert(ctx, &organization.TeamUser{OrgID: 3, TeamID: team.ID, UID: 28}))
	require.NoError(t, db.Insert(ctx, &organization.TeamRepo{OrgID: 3, TeamID: team.ID, RepoID: 3}))
	if row != nil {
		row.TeamID = team.ID
		require.NoError(t, db.Insert(ctx, row))
	}

	repo := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 3})
	require.NoError(t, repo.LoadOwner(ctx))
	require.NoError(t, access.RecalculateAccesses(ctx, repo))
	user := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 28})

	seen := func(ids []int64) string {
		if slices.Contains(ids, int64(3)) {
			return "visible"
		}
		return "hidden"
	}
	codeIDs, err := repo_model.FindUserCodeAccessibleOwnerRepoIDs(ctx, 3, user)
	require.NoError(t, err)
	actionsIDs, err := repo_model.SearchRepositoryIDsByCondition(ctx,
		repo_model.UserActionsAccessibleOwnerRepoCond(3, user, false))
	require.NoError(t, err)
	isMember, err := repo_model.IsOwnerMemberCollaborator(ctx, repo, 28)
	require.NoError(t, err)
	membership := "none"
	if isMember {
		membership = "member"
	}

	issue := unittest.AssertExistsAndLoadBean(t, &issues_model.Issue{ID: 6, RepoID: 3})
	require.NoError(t, issue.LoadRepo(ctx))
	doer := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 1})
	mentioned, err := issues_model.ResolveIssueMentionsByVisibility(ctx, issue, doer, []string{"org3/validation-team"})
	require.NoError(t, err)
	mention := "not notified"
	if slices.ContainsFunc(mentioned, func(u *user_model.User) bool { return u.ID == 28 }) {
		mention = "notified"
	}
	return map[string]string{
		"code_search":  seen(codeIDs),
		"actions_runs": seen(actionsIDs),
		"membership":   membership,
		"team_mention": mention,
	}
}
