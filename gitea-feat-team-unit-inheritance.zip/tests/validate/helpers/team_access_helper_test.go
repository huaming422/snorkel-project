// Validation helpers for the four team stories. tests/validate/validation-setup.sh copies this file
// into tests/integration/, next to the story test files, so a story's test calls these functions
// directly (same package, integration). Call them inside a test that started with
// `defer tests.PrepareTestEnv(t)()`.
//
// Everything here goes through the REST API and the web pages, as a user or an API client would:
// teams are created and changed only with the organization team endpoints, members and
// repositories are added with the team member and team repository endpoints, and every value a
// helper reports comes from a request user28 makes, or one the org owner makes about user28's work.
// Nothing here reads or writes team storage or calls a permission function, so nothing here
// depends on how the submitted patch stores or resolves a team's access. The two steps that do
// depend on it are written by the story file from the submitted patch and passed in as functions
// (see removeActionsEntry and extTrackerLevel below). Three pieces of plumbing do what a push
// would do in a running instance, with no server round trip: ensureDispatchWorkflow commits a
// workflow file onto master with git, commitTrust writes its signed commit into org3/repo3's
// object store with git (no endpoint stores a commit a user signed with their own key) and then
// looks at it only through the commit page, and codeSearch asks the code indexer to index
// org3/repo3.
//
// Every scenario uses organization org3, its private repository org3/repo3 and user28, a plain
// member of org3. Before a scenario looks at anything, user28 is a member of exactly one org3
// team, the one the scenario created, and that team holds org3/repo3. user28 has no other access
// to org3/repo3. user2, the owner of org3, creates and changes the teams.

package integration

import (
	"bytes"
	"fmt"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	auth_model "gitea.dev/models/auth"
	perm_model "gitea.dev/models/perm"
	repo_model "gitea.dev/models/repo"
	"gitea.dev/models/unittest"
	user_model "gitea.dev/models/user"
	code_indexer "gitea.dev/modules/indexer/code"
	"gitea.dev/modules/setting"
	api "gitea.dev/modules/structs"

	"github.com/ProtonMail/go-crypto/openpgp"
	"github.com/ProtonMail/go-crypto/openpgp/armor"
	"github.com/PuerkitoBio/goquery"
	"github.com/stretchr/testify/require"
)

var validationSeq atomic.Int64

// validationEnv holds the two signed-in actors of a scenario.
type validationEnv struct {
	owner       *TestSession // user2, the owner of organization org3
	ownerToken  string
	member      *TestSession // user28
	memberToken string
}

func validationNewEnv(t *testing.T) *validationEnv {
	t.Helper()
	e := &validationEnv{owner: loginUser(t, "user2"), member: loginUser(t, "user28")}
	e.ownerToken = getTokenForLoggedInUser(t, e.owner, auth_model.AccessTokenScopeAll)
	e.memberToken = getTokenForLoggedInUser(t, e.member, auth_model.AccessTokenScopeAll)
	return e
}

func validationName(prefix string) string {
	return fmt.Sprintf("validation-%s-%d", strings.ReplaceAll(prefix, "_", "-"), validationSeq.Add(1))
}

func validationClass(code int) string { return fmt.Sprintf("%dxx", code/100) }

// validationLevelName renders an access level the way the stories' expected values spell it:
// "none", "read", "write" or "admin" (admin and owner both read "admin").
func validationLevelName(m perm_model.AccessMode) string {
	switch {
	case m >= perm_model.AccessModeAdmin:
		return "admin"
	case m == perm_model.AccessModeWrite:
		return "write"
	case m == perm_model.AccessModeRead:
		return "read"
	default:
		return "none"
	}
}

// postTeam sends POST /api/v1/orgs/org3/teams as user2 and returns the created team.
func (e *validationEnv) postTeam(t *testing.T, opt *api.CreateTeamOption) *api.Team {
	t.Helper()
	resp := MakeRequest(t, NewRequestWithJSON(t, "POST", "/api/v1/orgs/org3/teams", opt).AddTokenAuth(e.ownerToken), NoExpectedStatus)
	require.Equal(t, "2xx", validationClass(resp.Code), "creating team %q: %s", opt.Name, resp.Body.String())
	return DecodeJSON(t, resp, &api.Team{})
}

// teamByName finds an org3 team by name through GET /api/v1/orgs/org3/teams; nil when there is none.
func (e *validationEnv) teamByName(t *testing.T, name string) *api.Team {
	t.Helper()
	for page := 1; ; page++ {
		resp := MakeRequest(t, NewRequestf(t, "GET", "/api/v1/orgs/org3/teams?page=%d&limit=50", page).AddTokenAuth(e.ownerToken), http.StatusOK)
		teams := DecodeJSON(t, resp, []*api.Team{})
		for _, team := range teams {
			if team.Name == name {
				return team
			}
		}
		if len(teams) < 50 {
			return nil
		}
	}
}

// grant makes user28 a member of team teamID, takes user28 out of every other org3 team, then adds
// org3/repo3 to the team, all through the team endpoints. The member is added before the repository
// so that the automatic watch Gitea sets up when a team gains a repository happens while this
// request runs.
func (e *validationEnv) grant(t *testing.T, teamID int64) {
	t.Helper()
	MakeRequest(t, NewRequestf(t, "PUT", "/api/v1/teams/%d/members/user28", teamID).AddTokenAuth(e.ownerToken), http.StatusNoContent)
	for page := 1; ; page++ {
		resp := MakeRequest(t, NewRequestf(t, "GET", "/api/v1/orgs/org3/teams?page=%d&limit=50", page).AddTokenAuth(e.ownerToken), http.StatusOK)
		teams := DecodeJSON(t, resp, []*api.Team{})
		for _, team := range teams {
			if team.ID != teamID {
				MakeRequest(t, NewRequestf(t, "DELETE", "/api/v1/teams/%d/members/user28", team.ID).AddTokenAuth(e.ownerToken), http.StatusNoContent)
			}
		}
		if len(teams) < 50 {
			break
		}
	}
	MakeRequest(t, NewRequestf(t, "PUT", "/api/v1/teams/%d/repos/org3/repo3", teamID).AddTokenAuth(e.ownerToken), http.StatusNoContent)
}

// codeLevel is user28's access to org3/repo3's code as GET /api/v1/repos/org3/repo3 reports it:
// "none" when the repository is not found for user28, else "admin", "write" (push), "read" (pull)
// or "none" from its permissions.
func (e *validationEnv) codeLevel(t *testing.T) string {
	t.Helper()
	resp := MakeRequest(t, NewRequest(t, "GET", "/api/v1/repos/org3/repo3").AddTokenAuth(e.memberToken), NoExpectedStatus)
	if resp.Code != http.StatusOK {
		return "none"
	}
	repo := DecodeJSON(t, resp, &api.Repository{})
	switch {
	case repo.Permissions == nil:
		return "none"
	case repo.Permissions.Admin:
		return "admin"
	case repo.Permissions.Push:
		return "write"
	case repo.Permissions.Pull:
		return "read"
	default:
		return "none"
	}
}

const validationWorkflow = ".gitea/workflows/validation-dispatch.yml"

// validationGit runs git on org3/repo3's repository on disk, with env added to the environment and
// stdin as its input, and requires it to succeed. It returns the trimmed output.
func validationGit(t *testing.T, env []string, stdin string, args ...string) string {
	t.Helper()
	cmd := exec.Command("git", append([]string{"--git-dir", filepath.Join(setting.RepoRootPath, "org3", "repo3.git")}, args...)...)
	cmd.Env = append(os.Environ(), env...)
	cmd.Stdin = strings.NewReader(stdin)
	out, err := cmd.CombinedOutput()
	require.NoError(t, err, "git %v: %s", args, out)
	return strings.TrimSpace(string(out))
}

// ensureDispatchWorkflow makes sure org3/repo3's master branch holds a workflow that can be started
// by hand (on: workflow_dispatch). When it is missing, it commits the file onto master as user2 with
// git, as a push would deliver it.
func (e *validationEnv) ensureDispatchWorkflow(t *testing.T) {
	t.Helper()
	parent := validationGit(t, nil, "", "rev-parse", "refs/heads/master")
	if strings.Contains(validationGit(t, nil, "", "ls-tree", "-r", "--name-only", parent, ".gitea/workflows"), validationWorkflow) {
		return
	}
	content := "name: validation-dispatch\non:\n  workflow_dispatch:\njobs:\n  noop:\n    runs-on: ubuntu-latest\n    steps:\n      - run: echo ok\n"
	index := []string{"GIT_INDEX_FILE=" + filepath.Join(t.TempDir(), "index")}
	blob := validationGit(t, nil, content, "hash-object", "-w", "--stdin")
	validationGit(t, index, "", "read-tree", parent)
	validationGit(t, index, "", "update-index", "--add", "--cacheinfo", "100644,"+blob+","+validationWorkflow)
	tree := validationGit(t, index, "", "write-tree")
	commit := validationGit(t, []string{
		"GIT_AUTHOR_NAME=user2", "GIT_AUTHOR_EMAIL=user2@example.com",
		"GIT_COMMITTER_NAME=user2", "GIT_COMMITTER_EMAIL=user2@example.com",
	}, "add a workflow that can be started by hand\n", "commit-tree", tree, "-p", parent)
	validationGit(t, nil, "", "update-ref", "refs/heads/master", commit, parent)
}

// actionsLevel is user28's access to org3/repo3's Actions: "write" when user28 can start the
// workflow by hand (POST .../actions/workflows/{workflow}/dispatches answers 2xx), "read" when user28
// can list the repository's workflows but not start one, else "none". Needs ensureDispatchWorkflow.
func (e *validationEnv) actionsLevel(t *testing.T) string {
	t.Helper()
	list := MakeRequest(t, NewRequest(t, "GET", "/api/v1/repos/org3/repo3/actions/workflows").AddTokenAuth(e.memberToken), NoExpectedStatus)
	if list.Code != http.StatusOK {
		return "none"
	}
	dispatch := MakeRequest(t, NewRequestWithJSON(t, "POST", "/api/v1/repos/org3/repo3/actions/workflows/validation-dispatch.yml/dispatches",
		&api.CreateActionWorkflowDispatch{Ref: "master"}).AddTokenAuth(e.memberToken), NoExpectedStatus)
	if dispatch.Code/100 == 2 {
		return "write"
	}
	return "read"
}

// useExternalTracker switches org3/repo3 to an external issue tracker through PATCH
// /api/v1/repos/org3/repo3 (this replaces the repository's own issue tracker).
func (e *validationEnv) useExternalTracker(t *testing.T) {
	t.Helper()
	hasIssues := true
	opt := &api.EditRepoOption{HasIssues: &hasIssues, ExternalTracker: &api.ExternalTracker{
		ExternalTrackerURL:    "https://tracker.example.com/",
		ExternalTrackerFormat: "https://tracker.example.com/{user}/{repo}/issues/{index}",
		ExternalTrackerStyle:  "numeric",
	}}
	MakeRequest(t, NewRequestWithJSON(t, "PATCH", "/api/v1/repos/org3/repo3", opt).AddTokenAuth(e.ownerToken), http.StatusOK)
}

// reachesExternalTracker reports whether user28 is sent on to the external tracker when opening
// /org3/repo3/issues.
func (e *validationEnv) reachesExternalTracker(t *testing.T) bool {
	t.Helper()
	resp := e.member.MakeRequest(t, NewRequest(t, "GET", "/org3/repo3/issues"), NoExpectedStatus)
	return resp.Code/100 == 3 && strings.HasPrefix(resp.Header().Get("Location"), "https://tracker.example.com/")
}

// validationTeamUnitAccess serves the team_write_inherits_all_units story. It switches org3/repo3 to an
// external issue tracker and gives it a workflow that can be started by hand, then creates ONE team
// over REST (POST /api/v1/orgs/org3/teams) and grants it (see grant):
//
//	teamMode "write":    {"permission": "write"}, nothing per unit
//	teamMode "admin":    {"permission": "admin"}, nothing per unit
//	teamMode "granular": {"units_map": {"repo.code": "write"}}
//
// It then calls removeActionsEntry(t, teamID), the story file's step for a unit nobody set up, and
// reports user28's access to three units of org3/repo3:
//
//	"code_access"         codeLevel: "none", "read", "write" or "admin"
//	"actions_access"      actionsLevel: "none", "read" or "write"
//	"ext_tracker_access"  "none" when /org3/repo3/issues does not send user28 on to the external
//	                      tracker; otherwise validationLevelName of extTrackerLevel(t, repo, member),
//	                      the story file's reading of the level, or "inconsistent" when that level is
//	                      none although the page sent user28 on
//
// repo and member are freshly loaded org3/repo3 and user28.
func validationTeamUnitAccess(t *testing.T, teamMode string,
	removeActionsEntry func(t *testing.T, teamID int64),
	extTrackerLevel func(t *testing.T, repo *repo_model.Repository, member *user_model.User) perm_model.AccessMode,
) map[string]string {
	t.Helper()
	e := validationNewEnv(t)
	e.useExternalTracker(t)
	e.ensureDispatchWorkflow(t)

	opt := &api.CreateTeamOption{Name: validationName("units-" + teamMode)}
	switch teamMode {
	case "write", "admin":
		opt.Permission = api.RepoWritePermission(teamMode)
	case "granular":
		opt.UnitsMap = map[string]string{"repo.code": "write"}
	default:
		t.Fatalf("validationTeamUnitAccess: unknown teamMode %q", teamMode)
	}
	team := e.postTeam(t, opt)
	e.grant(t, team.ID)
	removeActionsEntry(t, team.ID)

	ext := "none"
	if e.reachesExternalTracker(t) {
		repo := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 3})
		member := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 28})
		ext = validationLevelName(extTrackerLevel(t, repo, member))
		if ext == "none" {
			ext = "inconsistent"
		}
	}
	return map[string]string{
		"code_access":        e.codeLevel(t),
		"actions_access":     e.actionsLevel(t),
		"ext_tracker_access": ext,
	}
}

// validationTeamAPI serves the team_permission_api_roundtrip story: one team scenario against org3
// through the REST API, as user2.
//
// inputs (all four keys are present in every case):
//
//	"kind"        which requests to send, below
//	"permission"  the single team permission to send, a string ("" sends none)
//	"units"       the older units list to send, a list of unit keys (may be empty)
//	"units_map"   per-unit permissions to send, a map of unit key to level (may be empty)
//
// kinds:
//
//	"blanket"           POST /api/v1/orgs/org3/teams with only the permission
//	"both"              POST with the permission, the units list AND the per-unit map
//	"empty"             POST with an empty permission and no per-unit settings
//	"granular"          POST with only the per-unit map
//	"units_list"        POST with the permission and the units list, no per-unit map
//	"edit_description"  POST with only the per-unit map, then PATCH /api/v1/teams/{id} that sends
//	                    only a new description
//	"edit_to_units"     POST with only the permission, then PATCH /api/v1/teams/{id} that sends
//	                    only the per-unit map
//	"edit_to_blanket"   POST with only the per-unit map, then PATCH /api/v1/teams/{id} that sends
//	                    only the permission
//	"edit_units_list"   POST with only the permission, then PATCH /api/v1/teams/{id} that sends
//	                    the permission and the units list, no per-unit map
//	"blanket_edit_description"
//	                    POST with only the permission, then PATCH /api/v1/teams/{id} that sends
//	                    only a new description
//
// The result has every key below for every kind; "" means the key does not apply:
//
//	"http_class"     "2xx", "3xx", "4xx" or "5xx" for the last request sent (the PATCH for the edit
//	                 kinds; for those, a failed POST ends the scenario and its class is reported)
//	"team_created"   "yes" when GET /api/v1/orgs/org3/teams lists a team of the name the POST sent,
//	                 else "no"
//	"permission"     the team's permission as GET /api/v1/teams/{id} reads it back (lower case), or
//	                 "" when there is no team
//	"code_entry"     the per-unit entry GET /api/v1/teams/{id} reads back for "repo.code" ("" when
//	                 absent); reported for granular, units_list, edit_description, edit_to_units
//	                 and edit_units_list only
//	"issues_entry"   the same for "repo.issues"
//	"blanket_view"   for blanket, edit_to_blanket and blanket_edit_description only: "agrees" when
//	                 the read-back per-unit entries for "repo.code" and "repo.issues" are each
//	                 absent or equal to the team's permission (an empty per-unit map agrees; for
//	                 admin, "owner" also agrees), else "disagrees"
//	"member_actions" for any kind that left a team: the team is granted (see grant), the story
//	                 file's removeActionsEntry(t, teamID) runs (as for a unit added to Gitea after the
//	                 team was set up), and this is actionsLevel, user28's access to org3/repo3's
//	                 Actions: "none", "read" or "write"
func validationTeamAPI(t *testing.T, inputs map[string]any, removeActionsEntry func(t *testing.T, teamID int64)) map[string]string {
	t.Helper()
	e := validationNewEnv(t)

	kind, _ := inputs["kind"].(string)
	permission, _ := inputs["permission"].(string)
	units := []string{}
	if raw, ok := inputs["units"].([]any); ok {
		for _, v := range raw {
			s, _ := v.(string)
			units = append(units, s)
		}
	}
	unitsMap := map[string]string{}
	if raw, ok := inputs["units_map"].(map[string]any); ok {
		for k, v := range raw {
			s, _ := v.(string)
			unitsMap[k] = s
		}
	}

	name := validationName("api-" + kind)
	create := &api.CreateTeamOption{Name: name}
	switch kind {
	case "blanket", "empty", "edit_to_units", "edit_units_list", "blanket_edit_description":
		create.Permission = api.RepoWritePermission(permission)
	case "both":
		create.Permission = api.RepoWritePermission(permission)
		create.Units = units
		create.UnitsMap = unitsMap
	case "units_list":
		create.Permission = api.RepoWritePermission(permission)
		create.Units = units
	case "granular", "edit_description", "edit_to_blanket":
		create.UnitsMap = unitsMap
	default:
		t.Fatalf("validationTeamAPI: unknown kind %q", kind)
	}
	resp := MakeRequest(t, NewRequestWithJSON(t, "POST", "/api/v1/orgs/org3/teams", create).AddTokenAuth(e.ownerToken), NoExpectedStatus)
	last := resp.Code
	if resp.Code/100 == 2 {
		teamID := DecodeJSON(t, resp, &api.Team{}).ID
		var edit *api.EditTeamOption
		switch kind {
		case "edit_description", "blanket_edit_description":
			desc := "edited description"
			edit = &api.EditTeamOption{Description: &desc}
		case "edit_to_units":
			edit = &api.EditTeamOption{UnitsMap: unitsMap}
		case "edit_to_blanket":
			edit = &api.EditTeamOption{Permission: api.RepoWritePermission(permission)}
		case "edit_units_list":
			edit = &api.EditTeamOption{Permission: api.RepoWritePermission(permission), Units: units}
		}
		if edit != nil {
			last = MakeRequest(t, NewRequestWithJSON(t, "PATCH", fmt.Sprintf("/api/v1/teams/%d", teamID), edit).AddTokenAuth(e.ownerToken), NoExpectedStatus).Code
		}
	}

	out := map[string]string{
		"http_class": validationClass(last), "team_created": "no", "permission": "", "code_entry": "",
		"issues_entry": "", "blanket_view": "", "member_actions": "",
	}
	listed := e.teamByName(t, name)
	if listed == nil {
		return out
	}
	out["team_created"] = "yes"

	got := MakeRequest(t, NewRequestf(t, "GET", "/api/v1/teams/%d", listed.ID).AddTokenAuth(e.ownerToken), http.StatusOK)
	apiTeam := DecodeJSON(t, got, &api.Team{})
	out["permission"] = strings.ToLower(string(apiTeam.Permission))
	switch kind {
	case "granular", "units_list", "edit_description", "edit_to_units", "edit_units_list":
		out["code_entry"] = apiTeam.UnitsMap["repo.code"]
		out["issues_entry"] = apiTeam.UnitsMap["repo.issues"]
	case "blanket", "edit_to_blanket", "blanket_edit_description":
		out["blanket_view"] = "agrees"
		for _, key := range []string{"repo.code", "repo.issues"} {
			v := strings.ToLower(apiTeam.UnitsMap[key])
			if v != "" && v != out["permission"] && (out["permission"] != "admin" || v != "owner") {
				out["blanket_view"] = "disagrees"
			}
		}
	}

	e.ensureDispatchWorkflow(t)
	e.grant(t, listed.ID)
	removeActionsEntry(t, listed.ID)
	out["member_actions"] = e.actionsLevel(t)
	return out
}

// validationCodeSearch reports "visible" when user28's search of org3's code
// (GET /org3/-/code?q=Description, after org3/repo3 is indexed) answers 200 and lists a result in
// org3/repo3, else "hidden".
func (e *validationEnv) codeSearch(t *testing.T) string {
	t.Helper()
	repo := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 3})
	code_indexer.UpdateRepoIndexer(repo)
	resp := e.member.MakeRequest(t, NewRequest(t, "GET", "/org3/-/code?q=Description"), NoExpectedStatus)
	if resp.Code != http.StatusOK {
		return "hidden"
	}
	found := false
	NewHTMLParser(t, resp.Body).Find(".repo-search-result a[href]").Each(func(_ int, a *goquery.Selection) {
		if href, _ := a.Attr("href"); strings.Contains(href, "/org3/repo3/") {
			found = true
		}
	})
	if found {
		return "visible"
	}
	return "hidden"
}

// actionsRuns reports "visible" when org3's Actions run list as user28 sees it
// (GET /api/v1/orgs/org3/actions/runs) holds a run of org3/repo3, else "hidden". It first makes sure
// org3/repo3 has a run: user2 starts the hand-started workflow when the repository has none.
func (e *validationEnv) actionsRuns(t *testing.T) string {
	t.Helper()
	e.ensureDispatchWorkflow(t)
	runs := DecodeJSON(t, MakeRequest(t, NewRequest(t, "GET", "/api/v1/repos/org3/repo3/actions/runs").AddTokenAuth(e.ownerToken), http.StatusOK), &api.ActionWorkflowRunsResponse{})
	if runs.TotalCount == 0 {
		MakeRequest(t, NewRequestWithJSON(t, "POST", "/api/v1/repos/org3/repo3/actions/workflows/validation-dispatch.yml/dispatches",
			&api.CreateActionWorkflowDispatch{Ref: "master"}).AddTokenAuth(e.ownerToken), http.StatusNoContent)
	}
	resp := MakeRequest(t, NewRequest(t, "GET", "/api/v1/orgs/org3/actions/runs?limit=50").AddTokenAuth(e.memberToken), NoExpectedStatus)
	if resp.Code != http.StatusOK {
		return "hidden"
	}
	for _, run := range DecodeJSON(t, resp, &api.ActionWorkflowRunsResponse{}).Entries {
		if run.RepositoryID == 3 || (run.Repository != nil && run.Repository.ID == 3) {
			return "visible"
		}
	}
	return "hidden"
}

var validationGPG struct {
	once    sync.Once
	entity  *openpgp.Entity
	armored string
	err     error
}

// commitTrust has user28 sign a commit on org3/repo3 with a GPG key registered to user28 (POST
// /api/v1/user/gpg_keys, for user28@example.com, user28's activated address), then reads the
// signature badge of that commit's page (/org3/repo3/commit/{sha}) as user2. org3/repo3 uses the
// default "collaborator" trust model, so the badge says whether user28 counts as the owner, a
// collaborator or a team member of org3/repo3. It reports "trusted", "untrusted", "unmatched" or
// "unsigned" (no signed badge on the page).
func (e *validationEnv) commitTrust(t *testing.T) string {
	t.Helper()
	validationGPG.once.Do(func() {
		entity, err := openpgp.NewEntity("user28", "", "user28@example.com", nil)
		if err != nil {
			validationGPG.err = err
			return
		}
		var buf bytes.Buffer
		w, err := armor.Encode(&buf, openpgp.PublicKeyType, nil)
		if err == nil {
			err = entity.Serialize(w)
		}
		if err == nil {
			err = w.Close()
		}
		validationGPG.entity, validationGPG.armored, validationGPG.err = entity, buf.String(), err
	})
	require.NoError(t, validationGPG.err)
	// 201 the first time; 422 when the key is already registered from an earlier case.
	reg := MakeRequest(t, NewRequestWithJSON(t, "POST", "/api/v1/user/gpg_keys",
		&api.CreateGPGKeyOption{ArmoredKey: validationGPG.armored}).AddTokenAuth(e.memberToken), NoExpectedStatus)
	require.Contains(t, []int{http.StatusCreated, http.StatusUnprocessableEntity}, reg.Code, "registering user28's GPG key: %s", reg.Body.String())

	tree := validationGit(t, nil, "", "rev-parse", "refs/heads/master^{tree}")
	parent := validationGit(t, nil, "", "rev-parse", "refs/heads/master")
	when := time.Now().Unix()
	payload := fmt.Sprintf("tree %s\nparent %s\nauthor user28 <user28@example.com> %d +0000\ncommitter user28 <user28@example.com> %d +0000\n\nsigned by user28 (%d)\n",
		tree, parent, when, when, validationSeq.Add(1))
	var sig bytes.Buffer
	require.NoError(t, openpgp.ArmoredDetachSign(&sig, validationGPG.entity, strings.NewReader(payload), nil))
	header := "gpgsig " + strings.Join(strings.Split(strings.TrimRight(sig.String(), "\n"), "\n"), "\n ") + "\n"
	split := strings.Index(payload, "\n\n") + 1
	sha := validationGit(t, nil, payload[:split]+header+payload[split:], "hash-object", "-t", "commit", "-w", "--stdin")

	resp := e.owner.MakeRequest(t, NewRequest(t, "GET", "/org3/repo3/commit/"+sha), http.StatusOK)
	badge := NewHTMLParser(t, resp.Body).Find(".commit-sign-badge").First()
	switch {
	case badge.HasClass("sign-trusted"):
		return "trusted"
	case badge.HasClass("sign-untrusted"):
		return "untrusted"
	case badge.HasClass("sign-unmatched"):
		return "unmatched"
	default:
		return "unsigned"
	}
}

// teamMention has user28 stop watching org3/repo3 (DELETE /api/v1/repos/org3/repo3/subscription), so
// that only a mention can notify user28 of a new issue there, then user2 opens an issue on org3/repo3
// whose text mentions the team as @org3/{teamName}. It reports "notified" when user28's notifications
// (GET /api/v1/notifications?all=true) include that issue, else "not notified".
func (e *validationEnv) teamMention(t *testing.T, teamName string) string {
	t.Helper()
	MakeRequest(t, NewRequest(t, "DELETE", "/api/v1/repos/org3/repo3/subscription").AddTokenAuth(e.memberToken), NoExpectedStatus)
	title := validationName("mention")
	MakeRequest(t, NewRequestWithJSON(t, "POST", "/api/v1/repos/org3/repo3/issues", &api.CreateIssueOption{
		Title: title, Body: "Could you take a look, @org3/" + teamName + "?",
	}).AddTokenAuth(e.ownerToken), http.StatusCreated)
	link, _ := url.Parse("/api/v1/notifications")
	link.RawQuery = url.Values{"all": {"true"}, "limit": {"50"}}.Encode()
	resp := MakeRequest(t, NewRequest(t, "GET", link.String()).AddTokenAuth(e.memberToken), http.StatusOK)
	for _, thread := range DecodeJSON(t, resp, []*api.NotificationThread{}) {
		if thread.Subject != nil && thread.Subject.Title == title {
			return "notified"
		}
	}
	return "not notified"
}

// validationTeamRepoReach serves the team_write_repo_visibility story. It creates ONE team over REST
// (POST /api/v1/orgs/org3/teams) and grants it (see grant):
//
//	teamMode "write":            {"permission": "write"}, nothing per unit
//	teamMode "granular_code":    {"units_map": {"repo.code": "write"}}
//	teamMode "granular_issues":  {"units_map": {"repo.issues": "read"}}
//	teamMode "granular_actions": {"units_map": {"repo.actions": "read"}}
//
// and reports how user28 reaches org3/repo3 in four places:
//
//	"code_search"   codeSearch: "visible" or "hidden"
//	"actions_runs"  actionsRuns: "visible" or "hidden"
//	"commit_trust"  commitTrust: "trusted", "untrusted", "unmatched" or "unsigned"
//	"team_mention"  teamMention for this team: "notified" or "not notified"
func validationTeamRepoReach(t *testing.T, teamMode string) map[string]string {
	t.Helper()
	e := validationNewEnv(t)
	opt := &api.CreateTeamOption{Name: validationName("reach-" + teamMode)}
	switch teamMode {
	case "write":
		opt.Permission = "write"
	case "granular_code":
		opt.UnitsMap = map[string]string{"repo.code": "write"}
	case "granular_issues":
		opt.UnitsMap = map[string]string{"repo.issues": "read"}
	case "granular_actions":
		opt.UnitsMap = map[string]string{"repo.actions": "read"}
	default:
		t.Fatalf("validationTeamRepoReach: unknown teamMode %q", teamMode)
	}
	team := e.postTeam(t, opt)
	e.grant(t, team.ID)
	return map[string]string{
		"code_search":  e.codeSearch(t),
		"actions_runs": e.actionsRuns(t),
		"commit_trust": e.commitTrust(t),
		"team_mention": e.teamMention(t, team.Name),
	}
}

// validationTeamOrgProjects serves the team_write_org_projects story. It creates ONE team over REST
// (POST /api/v1/orgs/org3/teams) and grants it (see grant):
//
//	teamMode "write":                   {"permission": "write"}, nothing per unit
//	teamMode "granular_projects_read":  {"units_map": {"repo.projects": "read"}}
//	teamMode "granular_projects_write": {"units_map": {"repo.projects": "write"}}
//	teamMode "granular_code":           {"units_map": {"repo.code": "write"}}
//
// then, as user28, opens the organization's project list (GET /org3/-/projects) and submits the
// new-project form (POST /org3/-/projects/new with a fresh title). "created" means the project list
// as user2 sees it (GET /org3/-/projects?q={title}) then holds a project of that title. It reports,
// under "org_projects":
//
//	"write"         the list answers 2xx for user28 and the project was created
//	"read"          the list answers 2xx for user28 and no project was created
//	"none"          the list does not answer 2xx for user28 and no project was created
//	"inconsistent"  the project was created although the list does not answer 2xx for user28
func validationTeamOrgProjects(t *testing.T, teamMode string) map[string]string {
	t.Helper()
	e := validationNewEnv(t)
	opt := &api.CreateTeamOption{Name: validationName("projects-" + teamMode)}
	switch teamMode {
	case "write":
		opt.Permission = "write"
	case "granular_projects_read":
		opt.UnitsMap = map[string]string{"repo.projects": "read"}
	case "granular_projects_write":
		opt.UnitsMap = map[string]string{"repo.projects": "write"}
	case "granular_code":
		opt.UnitsMap = map[string]string{"repo.code": "write"}
	default:
		t.Fatalf("validationTeamOrgProjects: unknown teamMode %q", teamMode)
	}
	team := e.postTeam(t, opt)
	e.grant(t, team.ID)

	list := e.member.MakeRequest(t, NewRequest(t, "GET", "/org3/-/projects"), NoExpectedStatus).Code/100 == 2
	title := validationName("project-" + teamMode)
	e.member.MakeRequest(t, NewRequestWithValues(t, "POST", "/org3/-/projects/new", map[string]string{
		"title": title, "content": "", "template_type": "0", "card_type": "0",
	}), NoExpectedStatus)
	link, _ := url.Parse("/org3/-/projects")
	link.RawQuery = url.Values{"q": {title}}.Encode()
	created := false
	page := e.owner.MakeRequest(t, NewRequest(t, "GET", link.String()), http.StatusOK)
	NewHTMLParser(t, page.Body).Find(".milestone-list .list-item-large-title a").Each(func(_ int, a *goquery.Selection) {
		if strings.TrimSpace(a.Text()) == title {
			created = true
		}
	})
	access := "none"
	switch {
	case list && created:
		access = "write"
	case list:
		access = "read"
	case created:
		access = "inconsistent"
	}
	return map[string]string{"org_projects": access}
}
