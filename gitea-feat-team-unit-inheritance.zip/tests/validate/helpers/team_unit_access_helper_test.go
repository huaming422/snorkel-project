// Validation helper for the team_write_inherits_all_units story. tests/validate/validation-setup.sh
// copies this file into models/perm/access/, next to the story's test file, so the story's test
// calls it directly (same package, access_test).

package access_test

import (
	"testing"

	"gitea.dev/models/db"
	"gitea.dev/models/organization"
	perm_model "gitea.dev/models/perm"
	"gitea.dev/models/perm/access"
	repo_model "gitea.dev/models/repo"
	"gitea.dev/models/unit"
	"gitea.dev/models/unittest"
	user_model "gitea.dev/models/user"

	"github.com/stretchr/testify/require"
)

// validationAccessName renders an access level the way the story's expected values spell it.
func validationAccessName(m perm_model.AccessMode) string {
	switch {
	case m >= perm_model.AccessModeOwner:
		return "owner"
	case m == perm_model.AccessModeAdmin:
		return "admin"
	case m == perm_model.AccessModeWrite:
		return "write"
	case m == perm_model.AccessModeRead:
		return "read"
	default:
		return "none"
	}
}

// validationTeamUnitAccess starts from the unit-test fixtures with every team removed, adds an
// external issue tracker unit to private repository 3 (organization 3), and builds ONE team in
// organization 3 that holds repository 3 and has user 28 as its only member:
//
//	teamMode "write":    the team's single permission is write; nothing configured per unit
//	teamMode "admin":    the team's single permission is admin; nothing configured per unit
//	teamMode "granular": no single permission; one per-unit entry, code at write
//
// User 28 has no other access to repository 3, so the result comes from that team alone. The
// repository's access records are recalculated the way adding a member or a repository to a team
// does; then user 28's permission on repository 3 is resolved through access.GetDoerRepoPermission
// (the entry point request handlers use), and the helper returns the access to three units, each
// "none", "read", "write", "admin" or "owner":
//
//	"code_access"         the code unit
//	"actions_access"      the actions unit
//	"ext_tracker_access"  the external issue tracker unit, a unit that only ever allows read
func validationTeamUnitAccess(t *testing.T, teamMode string) map[string]string {
	t.Helper()
	require.NoError(t, unittest.PrepareTestDatabase())
	ctx := t.Context()
	require.NoError(t, db.TruncateBeans(ctx,
		&organization.Team{}, &organization.TeamUser{},
		&organization.TeamRepo{}, &organization.TeamUnit{}))
	require.NoError(t, db.Insert(ctx, &repo_model.RepoUnit{
		RepoID: 3, Type: unit.TypeExternalTracker,
		Config: &repo_model.ExternalTrackerConfig{ExternalTrackerURL: "https://tracker.example.com/"},
	}))

	team := &organization.Team{OrgID: 3, LowerName: "validation-team", Name: "validation-team"}
	switch teamMode {
	case "write":
		team.AccessMode = perm_model.AccessModeWrite
	case "admin":
		team.AccessMode = perm_model.AccessModeAdmin
	case "granular":
		team.AccessMode = perm_model.AccessModeNone
	default:
		t.Fatalf("validationTeamUnitAccess: unknown teamMode %q", teamMode)
	}
	require.NoError(t, db.Insert(ctx, team))
	require.NoError(t, db.Insert(ctx, &organization.TeamUser{OrgID: 3, TeamID: team.ID, UID: 28}))
	require.NoError(t, db.Insert(ctx, &organization.TeamRepo{OrgID: 3, TeamID: team.ID, RepoID: 3}))
	if teamMode == "granular" {
		require.NoError(t, db.Insert(ctx, &organization.TeamUnit{
			OrgID: 3, TeamID: team.ID, Type: unit.TypeCode, AccessMode: perm_model.AccessModeWrite,
		}))
	}

	// Recalculate the repository's access records the way adding a member or a repository to a
	// team does, then resolve on fresh beans, so nothing cached before the inserts is used.
	owned := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 3})
	require.NoError(t, owned.LoadOwner(ctx))
	require.NoError(t, access.RecalculateAccesses(ctx, owned))
	repo := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 3})
	user := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 28})
	perm, err := access.GetDoerRepoPermission(ctx, repo, user)
	require.NoError(t, err)
	return map[string]string{
		"code_access":        validationAccessName(perm.UnitAccessMode(unit.TypeCode)),
		"actions_access":     validationAccessName(perm.UnitAccessMode(unit.TypeActions)),
		"ext_tracker_access": validationAccessName(perm.UnitAccessMode(unit.TypeExternalTracker)),
	}
}
