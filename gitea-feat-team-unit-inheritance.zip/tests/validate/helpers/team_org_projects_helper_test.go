// Validation helper for the team_write_org_projects story. tests/validate/validation-setup.sh
// copies this file into tests/integration/, next to the story's test file, so the story's test
// calls it directly (same package, integration).

package integration

import (
	"testing"

	"gitea.dev/models/db"
	"gitea.dev/models/organization"
	perm_model "gitea.dev/models/perm"
	access_model "gitea.dev/models/perm/access"
	repo_model "gitea.dev/models/repo"
	"gitea.dev/models/unit"
	"gitea.dev/models/unittest"

	"github.com/stretchr/testify/require"
)

// validationTeamOrgProjects reloads the fixtures, takes user28 out of every team of organization
// org3, and builds ONE team in org3 that holds repository org3/repo3 and has user28 as its only
// member:
//
//	teamMode "write":                   the team's single permission is write; nothing per unit
//	teamMode "granular_projects_read":  no single permission; one per-unit entry, projects at read
//	teamMode "granular_projects_write": no single permission; one per-unit entry, projects at write
//
// It recalculates org3/repo3's access records the way adding a member or a repository to a team
// does, signs in as user28, opens the organization's project pages and reports, under the key
// "org_projects":
//
//	"write"         both GET /org3/-/projects (the list) and GET /org3/-/projects/new (the
//	                new-project form) answer 2xx
//	"read"          the list answers 2xx and the new-project form does not
//	"none"          neither answers 2xx
//	"inconsistent"  only the new-project form answers 2xx
//
// It needs a running test environment: call it inside a test that started with
// `defer tests.PrepareTestEnv(t)()`.
func validationTeamOrgProjects(t *testing.T, teamMode string) map[string]string {
	t.Helper()
	require.NoError(t, unittest.LoadFixtures())
	ctx := t.Context()
	_, err := db.GetEngine(ctx).Where("org_id = ? AND uid = ?", 3, 28).Delete(new(organization.TeamUser))
	require.NoError(t, err)

	team := &organization.Team{OrgID: 3, LowerName: "validation-team", Name: "validation-team"}
	var row *organization.TeamUnit
	switch teamMode {
	case "write":
		team.AccessMode = perm_model.AccessModeWrite
	case "granular_projects_read":
		team.AccessMode = perm_model.AccessModeNone
		row = &organization.TeamUnit{OrgID: 3, Type: unit.TypeProjects, AccessMode: perm_model.AccessModeRead}
	case "granular_projects_write":
		team.AccessMode = perm_model.AccessModeNone
		row = &organization.TeamUnit{OrgID: 3, Type: unit.TypeProjects, AccessMode: perm_model.AccessModeWrite}
	default:
		t.Fatalf("validationTeamOrgProjects: unknown teamMode %q", teamMode)
	}
	require.NoError(t, db.Insert(ctx, team))
	require.NoError(t, db.Insert(ctx, &organization.TeamUser{OrgID: 3, TeamID: team.ID, UID: 28}))
	require.NoError(t, db.Insert(ctx, &organization.TeamRepo{OrgID: 3, TeamID: team.ID, RepoID: 3}))
	if row != nil {
		row.TeamID = team.ID
		require.NoError(t, db.Insert(ctx, row))
	}
	repo := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 3})
	require.NoError(t, repo.LoadOwner(ctx))
	require.NoError(t, access_model.RecalculateAccesses(ctx, repo))

	session := loginUser(t, "user28")
	ok := func(path string) bool {
		return session.MakeRequest(t, NewRequest(t, "GET", path), NoExpectedStatus).Code/100 == 2
	}
	list, form := ok("/org3/-/projects"), ok("/org3/-/projects/new")
	access := "none"
	switch {
	case list && form:
		access = "write"
	case list:
		access = "read"
	case form:
		access = "inconsistent"
	}
	return map[string]string{"org_projects": access}
}
