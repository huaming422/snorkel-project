// @ts-nocheck
import type * as fsType from 'node:fs';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';

import pair from '@test/fixtures/providers/codex/turn-stats-pair.json';
import { capturedSelectionPrompt, capturedSelections } from '@test/helpers/capturedSelections';
import { TEST_CODEX_MODEL } from '@test/helpers/codexModels';

import type {
  ProviderExecutionEvent,
  ProviderExecutionRequest,
  ProviderInteractionPort,
  ProviderSessionConfig,
  ProviderSessionEvent,
} from '@/core/execution';
import { isSteerableExecutionSession } from '@/core/execution';
import type { ProviderHost } from '@/core/providers/ProviderHost';
import type { ClaudianSettings } from '@/core/types';
import { createCodexPathMapper } from '@/providers/codex/runtime/CodexPathMapper';
type MutableTestHost = ProviderHost & { settings: ClaudianSettings };

const mockTransportRequest = jest.fn();
const mockTransportNotify = jest.fn();
const mockTransportOnNotification = jest.fn();
const mockTransportOnServerRequest = jest.fn();
const mockTransportDispose = jest.fn();
const mockUnsubscribe = jest.fn().mockResolvedValue({});
const mockTransportStart = jest.fn();
const mockResolveLaunchSpec = jest.fn();

jest.mock('@/providers/codex/runtime/CodexRPCTransport', () => {
  const actual = jest.requireActual('@/providers/codex/runtime/CodexRPCTransport');
  return {
    ...actual,
    CodexRPCTransport: jest.fn().mockImplementation(() => ({
      request: (method: string, ...args: unknown[]) => method === 'plugin/reconcile' ? Promise.resolve({}) : method === 'thread/unsubscribe' ? mockUnsubscribe(...args) : mockTransportRequest(method, ...(args[1] === 0 ? args.slice(0, 1) : args)),
      notify: mockTransportNotify,
      onNotification: mockTransportOnNotification,
      onServerRequest: mockTransportOnServerRequest,
      dispose: mockTransportDispose,
      start: mockTransportStart,
    })),
  };
});

const mockProcessStart = jest.fn();
const mockProcessShutdown = jest.fn().mockResolvedValue(undefined);
const mockProcessIsAlive = jest.fn().mockReturnValue(true);
const mockProcessOnExit = jest.fn();
const mockProcessOffExit = jest.fn();

jest.mock('@/providers/codex/runtime/CodexAppServerProcess', () => ({
  CodexAppServerProcess: jest.fn().mockImplementation(() => ({
    start: mockProcessStart,
    shutdown: mockProcessShutdown,
    isAlive: mockProcessIsAlive,
    onExit: mockProcessOnExit,
    offExit: mockProcessOffExit,
  })),
}));

jest.mock('@/providers/codex/runtime/codexAppServerSupport', () => {
  const actual = jest.requireActual('@/providers/codex/runtime/codexAppServerSupport');
  return {
    ...actual,
    resolveCodexAppServerLaunchSpec: (...args: unknown[]) => mockResolveLaunchSpec(...args),
  };
});

import { CodexExecutionBackend } from '@/providers/codex/execution/CodexExecutionBackend';
import { parseCodexSessionContent } from '@/providers/codex/history/CodexHistoryStore';
import { CodexAppServerRuntime } from '@/providers/codex/runtime/CodexAppServerRuntime';
import { CodexRPCResponseError } from '@/providers/codex/runtime/CodexRPCTransport';
import { updateCodexProviderSettings } from '@/providers/codex/settings';

const runtimes: CodexAppServerRuntime[] = [];
function createBackend(plugin: ProviderHost): CodexExecutionBackend {
  const runtime = new CodexAppServerRuntime(plugin, () => undefined);
  runtimes.push(runtime);
  return new CodexExecutionBackend(plugin, runtime);
}
afterEach(async () => { await Promise.all(runtimes.splice(0).map(runtime => runtime.dispose())); });

type NotificationHandler = (params: unknown) => void;
type ServerRequestHandler = (
  requestId: string | number,
  params: unknown,
) => Promise<unknown>;

let notificationHandlers: Map<string, NotificationHandler>;
let serverRequestHandlers: Map<string, ServerRequestHandler>;
let exitHandler: (() => void) | null;

interface Deferred<T> {
  readonly promise: Promise<T>;
  reject(reason: unknown): void;
  resolve(value: T): void;
}

function createDeferred<T>(): Deferred<T> {
  let resolve!: (value: T) => void;
  let reject!: (reason: unknown) => void;
  const promise = new Promise<T>((nextResolve, nextReject) => {
    resolve = nextResolve;
    reject = nextReject;
  });
  return { promise, reject, resolve };
}

async function waitForCondition(condition: () => boolean): Promise<void> {
  for (let attempt = 0; attempt < 100 && !condition(); attempt += 1) {
    await Promise.resolve();
  }
  expect(condition()).toBe(true);
}

function captureHandlers(): void {
  notificationHandlers = new Map();
  serverRequestHandlers = new Map();
  exitHandler = null;
  mockTransportOnNotification.mockImplementation(
    (method: string, handler: NotificationHandler) => {
      notificationHandlers.set(method, handler);
    },
  );
  mockTransportOnServerRequest.mockImplementation(
    (method: string, handler: ServerRequestHandler) => {
      serverRequestHandlers.set(method, handler);
    },
  );
  mockProcessOnExit.mockImplementation((handler: () => void) => {
    exitHandler = handler;
  });
}

function emitNotification(method: string, params: unknown): void {
  notificationHandlers.get(method)?.(params);
}

// Policies the app server derives from a config.toml with sandbox_workspace_write overrides.
const CONFIGURED_WORKSPACE_WRITE_SANDBOX = {
  type: 'workspaceWrite',
  writableRoots: ['/configured/root'],
  networkAccess: true,
  excludeTmpdirEnvVar: false,
  excludeSlashTmp: false,
} as const;

function configuredSandboxFor(mode: unknown) {
  if (mode === 'danger-full-access') return { type: 'dangerFullAccess' };
  if (mode === 'read-only') return { type: 'readOnly', networkAccess: false };
  return CONFIGURED_WORKSPACE_WRITE_SANDBOX;
}

function createThreadResult(
  threadId: string,
  turns: Array<{
    id: string;
    error?: unknown;
    items?: unknown[];
    status?: 'completed' | 'failed' | 'inProgress' | 'interrupted';
  }> = [],
) {
  return {
    thread: {
      id: threadId,
      path: `/tmp/sessions/${threadId}.jsonl`,
      preview: '',
      ephemeral: false,
      status: { type: 'idle' },
      turns: turns.map(turn => ({
        ...turn,
        items: turn.items ?? [],
        status: turn.status ?? 'completed',
        error: turn.error ?? null,
      })),
      cwd: '/vault',
      cliVersion: '0.146.0',
      modelProvider: 'openai',
      source: 'app-server',
      createdAt: 0,
      lastActivityAt: 0,
      agentNickname: null,
      agentRole: null,
      gitInfo: null,
      name: null,
    },
    model: TEST_CODEX_MODEL,
    modelProvider: 'openai',
    serviceTier: null,
    cwd: '/vault',
    approvalPolicy: 'never',
    approvalsReviewer: 'user',
    sandbox: CONFIGURED_WORKSPACE_WRITE_SANDBOX as Record<string, unknown>,
    reasoningEffort: 'medium',
  };
}

function createTurnResult(turnId: string) {
  return {
    turn: { id: turnId, items: [], status: 'inProgress', error: null },
  };
}

function createPlugin(): MutableTestHost {
  return {
    settings: {
      model: TEST_CODEX_MODEL,
      effortLevel: 'medium',
      serviceTier: 'default',
      permissionMode: 'normal',
      systemPrompt: '',
      mediaFolder: '',
      userName: '',
      providerConfigs: {
        codex: {
          enabled: true,
          discoveredModels: [{
            model: TEST_CODEX_MODEL,
            displayName: 'Test Codex',
            description: '',
            supportedReasoningEfforts: [
              { value: 'low', description: '' },
              { value: 'medium', description: '' },
              { value: 'high', description: '' },
            ],
            defaultReasoningEffort: 'medium',
            serviceTiers: [{ id: 'priority', name: 'Fast', description: '' }],
            defaultServiceTier: null,
            inputModalities: ['text', 'image'],
            isDefault: true,
          }],
        },
      },
    },
  } as unknown as MutableTestHost;
}

function createInteractionPort(): ProviderInteractionPort {
  return {
    requestApproval: jest.fn().mockImplementation(async request => ({
      interactionId: request.interactionId,
      decision: 'allow',
    })),
    askUserQuestion: jest.fn().mockImplementation(async request => ({
      interactionId: request.interactionId,
      answers: { choice: 'yes' },
    })),
    dismissInteraction: jest.fn(),
  };
}

function createSessionConfig(
  overrides: Partial<ProviderSessionConfig> = {},
): ProviderSessionConfig {
  return {
    lifecycle: 'persistent',
    nativePersistence: 'enabled',
    vaultWorkingDirectory: '/vault',
    interactionPort: createInteractionPort(),
    ...overrides,
  };
}

function createForkSessionConfig(
  providerState: Record<string, unknown> = {},
): ProviderSessionConfig {
  return createSessionConfig({
    resumeSeed: {
      providerState: {
        forkSourceSessionFilePath: '/tmp/source.jsonl',
        forkSourceTranscriptRootPath: '/tmp/sessions',
        forkSource: { sessionId: 'thread-source', resumeAt: 'checkpoint' },
        unknownFutureState: { keep: true },
        ...providerState,
      },
    },
  });
}

function expectPendingForkOwnership(
  session: ReturnType<CodexExecutionBackend['createSession']>,
  status: 'idle' | 'invalidated' | 'disposed' = 'idle',
): void {
  expect(session.getSnapshot()).toMatchObject({
    providerSessionId: 'thread-fork-target',
    providerState: {
      forkSource: { sessionId: 'thread-source', resumeAt: 'checkpoint' },
      pendingForkTarget: {
        sessionFilePath: '/tmp/sessions/thread-fork-target.jsonl',
        threadId: 'thread-fork-target',
      },
      threadId: 'thread-fork-target',
      unknownFutureState: { keep: true },
    },
    status,
  });
  expect(session.getSnapshot().providerStateDeletes).toBeUndefined();
}

function expectPendingForkOwnershipEvent(
  events: readonly ProviderExecutionEvent[],
): void {
  expect(events).toEqual(expect.arrayContaining([
    expect.objectContaining({
      type: 'session_state_changed',
      snapshot: expect.objectContaining({
        providerSessionId: 'thread-fork-target',
        providerState: expect.objectContaining({
          forkSource: { sessionId: 'thread-source', resumeAt: 'checkpoint' },
          pendingForkTarget: {
            sessionFilePath: '/tmp/sessions/thread-fork-target.jsonl',
            threadId: 'thread-fork-target',
          },
          threadId: 'thread-fork-target',
          unknownFutureState: { keep: true },
        }),
      }),
    }),
  ]));
}

async function flushMicrotasks(iterations = 10): Promise<void> {
  for (let index = 0; index < iterations; index += 1) {
    await Promise.resolve();
  }
}

function createRequest(
  signal: AbortSignal = new AbortController().signal,
  overrides: Partial<ProviderExecutionRequest> = {},
): ProviderExecutionRequest {
  return {
    input: [{ type: 'text', text: 'hello' }],
    configuration: {
      systemInstructions: { kind: 'explicit', instructions: 'Be concise.' },
      model: TEST_CODEX_MODEL,
      reasoning: 'high',
      serviceTier: 'priority',
      permissionMode: 'normal',
    },
    toolPolicy: { kind: 'provider-default' },
    signal,
    ...overrides,
  };
}

async function collectEvents(
  events: AsyncIterable<ProviderExecutionEvent>,
): Promise<ProviderExecutionEvent[]> {
  const result: ProviderExecutionEvent[] = [];
  for await (const event of events) {
    result.push(event);
  }
  return result;
}

function createImageRequest(): ProviderExecutionRequest {
  return createRequest(undefined, {
    input: [{
      type: 'image',
      image: {
        id: 'image-1', name: 'pasted.png', mediaType: 'image/png',
        data: 'aGVsbG8=', size: 5, source: 'paste',
      },
    }],
  });
}

async function collectUntil(
  events: AsyncIterable<ProviderExecutionEvent>,
  predicate: (event: ProviderExecutionEvent) => boolean,
): Promise<ProviderExecutionEvent[]> {
  const result: ProviderExecutionEvent[] = [];
  for await (const event of events) {
    result.push(event);
    if (predicate(event)) break;
  }
  return result;
}

function completeTurn(threadId: string, turnId: string): void {
  emitNotification('turn/completed', {
    threadId,
    turn: { id: turnId, items: [], status: 'completed', error: null },
  });
}

function configureSteerTransport(
  threadId: string,
  turnId: string,
  steer: () => unknown | Promise<unknown>,
): void {
  mockTransportRequest.mockImplementation(async (method: string) => {
    if (method === 'initialize') {
      return {
        userAgent: 'test',
        codexHome: '/tmp/.codex',
        platformFamily: 'unix',
        platformOs: 'macos',
      };
    }
    if (method === 'thread/start') return createThreadResult(threadId);
    if (method === 'turn/start') return createTurnResult(turnId);
    if (method === 'turn/steer') return steer();
    if (method === 'turn/interrupt') return {};
    throw new Error(`Unexpected method: ${method}`);
  });
}

async function createActiveSteerSession() {
  const session = createBackend(createPlugin())
    .createSession(createSessionConfig());
  const run = session.execute(createRequest());
  await waitForCondition(() => mockTransportRequest.mock.calls.some(
    ([method]) => method === 'turn/start',
  ));
  if (!isSteerableExecutionSession(session)) {
    throw new Error('Codex session should be steerable');
  }
  return { run, session };
}

describe('CodexExecutionBackend', () => {

  beforeEach(() => {
    jest.clearAllMocks();
    captureHandlers();
    mockUnsubscribe.mockReset().mockResolvedValue({});
    mockProcessIsAlive.mockReturnValue(true);
    mockResolveLaunchSpec.mockResolvedValue({
      target: {
        method: 'host-native',
        platformFamily: 'unix',
        platformOs: 'macos',
      },
      command: '/usr/local/bin/codex',
      args: ['app-server', '--listen', 'stdio://'],
      spawnCwd: '/vault',
      targetCwd: '/vault',
      env: { HOME: '/tmp' },
      pathMapper: {
        target: {
          method: 'host-native',
          platformFamily: 'unix',
          platformOs: 'macos',
        },
        toTargetPath: (value: string) => value,
        toHostPath: (value: string) => value,
        mapTargetPathList: (values: string[]) => values,
        canRepresentHostPath: () => true,
      },
    });
  });

  it.each(['/compact', ' \t/CoMpAcT  '])('preserves native compact %j and derives its turn ID from turn/started', async text => {
    mockTransportRequest.mockImplementation(async (method: string) => {
      if (method === 'initialize') {
        return {
          userAgent: 'test',
          codexHome: '/tmp/.codex',
          platformFamily: 'unix',
          platformOs: 'macos',
        };
      }
      if (method === 'thread/resume') return createThreadResult('thread-compact');
      if (method === 'thread/compact/start') {
        queueMicrotask(() => {
          emitNotification('turn/started', {
            threadId: 'thread-compact',
            turn: createTurnResult('turn-compact').turn,
          });
          completeTurn('thread-compact', 'turn-compact');
        });
        return {};
      }
      throw new Error(`Unexpected method: ${method}`);
    });
    const session = createBackend(createPlugin()).createSession(
      createSessionConfig({
        resumeSeed: {
          providerSessionId: 'thread-compact',
          providerState: {
            threadId: 'thread-compact',
            nativeConversationContextEstablished: true,
          },
        },
      }),
    );
    const events = await collectEvents(session.execute(createRequest(
      new AbortController().signal,
      { input: [{ type: 'text', text }, { type: 'image', image: {
        id: 'capture', name: 'capture.png', data: 'aW1hZ2U=',
        mediaType: 'image/png', size: 5, source: 'paste',
      } }], context: { ...capturedSelections, linkedContent: { path: 'note.md' },
        sessionReferences: [{ id: 'ref', title: 'Review', providerId: 'codex', updatedAt: 'updated', snapshotPath: '/tmp/ref.md' }],
      } },
    )).events);

    expect(mockTransportRequest).toHaveBeenCalledWith(
      'thread/compact/start',
      { threadId: 'thread-compact' },
    );
    expect(mockTransportRequest).not.toHaveBeenCalledWith(
      'turn/start',
      expect.anything(),
    );
    expect(events).toContainEqual(expect.objectContaining({
      type: 'turn_started',
      accepted: true,
      nativeTurnId: 'turn-compact',
    }));

    await session.dispose();
  });

  it.each([
    { texts: ['/compact keep recent edits'] },
    { texts: ['/compact', 'keep recent edits'] },
  ])('rejects explicit compact instructions across text blocks: $texts', async ({ texts }) => {
    mockTransportRequest.mockImplementation(async (method: string) => {
      if (method === 'initialize') return { userAgent: 'test', codexHome: '/tmp/.codex', platformFamily: 'unix', platformOs: 'macos' };
      if (method === 'thread/start') return createThreadResult('thread-compact-args');
      throw new Error(`Unexpected method: ${method}`);
    });
    const session = createBackend(createPlugin()).createSession(createSessionConfig());
    try {
      const events = await collectEvents(session.execute(createRequest(new AbortController().signal, {
        input: texts.map(text => ({ type: 'text', text })),
      })).events);
      // Codex compaction takes no instructions: the user sees an error (wording not fixed) and
      // neither a turn nor a compaction starts.
      expect(events.at(-1)).toMatchObject({ type: 'execution_error', message: expect.any(String) });
      expect(mockTransportRequest.mock.calls.filter(([method]) => method === 'turn/start' || method === 'thread/compact/start')).toEqual([]);
    } finally { await session.dispose(); }
  });

  it('rejects compact without consuming history that still needs recovery', async () => {
    configureSteerTransport('thread-recover', 'turn-recover', () => ({}));
    const session = createBackend(createPlugin()).createSession(createSessionConfig());
    const conversationHistory = [{ id: 'prior', role: 'user' as const, content: 'Remember prior context', timestamp: 1 }];
    try {
      const events = await collectEvents(session.execute(createRequest(new AbortController().signal, {
        input: [{ type: 'text', text: '/compact' }], conversationHistory,
      })).events);
      expect(events.at(-1)).toMatchObject({ type: 'execution_error', message: expect.any(String) });
      expect(mockTransportRequest.mock.calls.filter(([method]) => method === 'turn/start' || method === 'thread/compact/start')).toEqual([]);
      const run = session.execute(createRequest(new AbortController().signal, {
        input: [{ type: 'text', text: 'Continue' }], conversationHistory,
      }));
      await waitForCondition(() => mockTransportRequest.mock.calls.some(([method]) => method === 'turn/start'));
      emitNotification('turn/started', { threadId: 'thread-recover', turn: createTurnResult('turn-recover').turn });
      completeTurn('thread-recover', 'turn-recover');
      await collectEvents(run.events);
      const turnStart = mockTransportRequest.mock.calls.find(([method]) => method === 'turn/start')![1];
      expect(JSON.stringify(turnStart)).toContain('Remember prior context');
    } finally { await session.dispose(); }
  });

  it('steers literal /compact text with its captured context', async () => {
    configureSteerTransport('thread-steer', 'turn-steer', () => ({ turnId: 'turn-steer' }));
    const { run, session } = await createActiveSteerSession();
    try {
      await expect(session.steer(createRequest(new AbortController().signal, {
        input: [{ type: 'text', text: '/compact' }], context: capturedSelections,
      }))).resolves.toBe(true);
      const input = mockTransportRequest.mock.calls.find(([method]) => method === 'turn/steer')![1].input;
      expect(input).toEqual([{ type: 'text', text_elements: [], text: `/compact\n\n${capturedSelectionPrompt}` }]);
      expect(mockTransportRequest.mock.calls.some(([method]) => method === 'thread/compact/start')).toBe(false);
    } finally { run.cancel(); await collectEvents(run.events); await session.dispose(); }
  });

});
