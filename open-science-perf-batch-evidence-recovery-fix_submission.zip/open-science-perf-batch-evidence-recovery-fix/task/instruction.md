## Task

app launch has gotten steadily slower for our long-time users. it was snappy
back when a workspace was fresh, but the more projects and sessions someone
piles up, the longer startup drags, and it keeps getting worse. it's slow even
on a clean restart when there's nothing new to deal with. nothing's broken, all
the history is intact, it's just the launch itself that's sluggish. the cost
seems to track how much history has accumulated rather than how much actual new
work there is. dig into why startup scales with accumulated history and make it
fast again. don't change how anything is stored on disk and don't require a
migration (existing saved data has to stay readable by the old version), and
every bit of history still has to recover correctly after both a normal restart
and a crash restart.
