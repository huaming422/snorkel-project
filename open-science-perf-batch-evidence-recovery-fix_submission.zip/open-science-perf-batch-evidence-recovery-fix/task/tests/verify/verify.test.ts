// @ts-nocheck
// Behavioral verifier for startup Compute-evidence recovery. It drives the stable,
// pre-existing exported entry point reconcileComputeJobFileEvidence(storageRoot, jobs)
// over a temporary storage directory and observes two things that any correct fix must
// exhibit: (1) how many real child recovery processes get launched as the amount of
// recorded history grows, and (2) that recovered history stays byte-for-byte intact.
//
// Observability note: the number of recovery processes is measured by counting real
// node:child_process.spawn launches of the runtime executable — the quantity the
// symptom is about — NOT by any injected test-only dependency. The request payload the
// launcher sends is an internal detail a solution is free to shape differently, so no
// assertion inspects it; only the launch COUNT and the on-disk result are observed.

import { createHash } from 'node:crypto'
import {
  mkdir,
  mkdtemp,
  readFile,
  readdir,
  rm,
  stat,
  writeFile
} from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it, vi } from 'vitest'

// Count only launches of the runtime executable (the recovery child process), while
// letting every launch really run so on-disk effects are genuine.
vi.mock('node:child_process', async (importOriginal) => {
  const actual = await importOriginal<typeof import('node:child_process')>()
  return { ...actual, spawn: vi.fn(actual.spawn) }
})
import { spawn } from 'node:child_process'

import {
  beginComputeJobFileEvidence,
  publishComputeJobFileEvidence,
  reconcileComputeJobFileEvidence,
  runEvidenceWorker,
  startWorkingFileObservation
} from './notebook/working-file-observer'

type Job = Parameters<typeof reconcileComputeJobFileEvidence>[1][number]

const launchCount = (): number =>
  (spawn as any).mock.calls.filter((call: any[]) => call[0] === process.execPath).length

const projectId = 'project-batch'
const sharedBytes = 'shared immutable scientific input\n'
let storageRoot: string

const evidenceDir = (): string => join(storageRoot, 'execution-file-evidence')
const sessionRoot = (project: string, sessionId: string): string =>
  join(evidenceDir(), project, sessionId)

const setup = async (): Promise<void> => {
  storageRoot = await mkdtemp(join(tmpdir(), 'os-compute-batch-recovery-'))
  await writeFile(join(storageRoot, 'input.csv'), sharedBytes)
}

// Create a recorded Project directory with `count` empty recorded-Session directories,
// mirroring an accumulated-but-already-recovered workspace. Uses the exported runner to
// stamp the Project ownership record the scan requires, then drops bare Session dirs.
const seedEmptyProject = async (project: string, count: number): Promise<void> => {
  const root = evidenceDir()
  await mkdir(root, { recursive: true })
  const metadata = await stat(root)
  await runEvidenceWorker(root, {
    operation: 'ensure-project',
    projectName: project,
    expectedRootIdentity: { dev: metadata.dev, ino: metadata.ino }
  })
  for (let index = 0; index < count; index++) {
    await mkdir(join(root, project, `session-${index}`))
  }
}

const begin = async (sessionId: string, jobId: string): Promise<Job> => {
  await beginComputeJobFileEvidence({
    storageRoot,
    projectId,
    sessionId,
    jobId,
    producerRunId: 'run-producer',
    inputs: [
      { localPath: join(storageRoot, 'input.csv'), dstFilename: 'input.csv', label: 'input.csv' }
    ]
  })
  return {
    project_id: projectId,
    session_id: sessionId,
    job_id: jobId,
    producer_run_id: 'run-producer',
    status: 'running',
    submitted_at: 1,
    harvested_at: undefined
  }
}

const publish = async (sessionId: string, jobId: string): Promise<Job> => {
  const job = await begin(sessionId, jobId)
  return {
    ...job,
    status: 'success',
    harvested_at: 2,
    file_evidence: await publishComputeJobFileEvidence({
      storageRoot,
      projectId,
      sessionId,
      jobId,
      producerRunId: 'run-producer',
      outputs: []
    })
  }
}

const readEvidence = async (job: Job): Promise<Buffer> =>
  readFile(join(storageRoot, job.file_evidence!.storageKey!))

const expectSharedBlob = async (job: Job): Promise<void> => {
  const sidecar = JSON.parse((await readEvidence(job)).toString()) as {
    relations: Array<{ generation?: { contentStorageKey: string } }>
  }
  const keys = sidecar.relations.flatMap(({ generation }) =>
    generation ? [generation.contentStorageKey] : []
  )
  expect(keys.length).toBeGreaterThan(0)
  for (const key of keys) {
    expect(await readFile(join(storageRoot, key), 'utf8')).toBe(sharedBytes)
  }
  expect(
    createHash('sha256')
      .update(await readEvidence(job))
      .digest('hex')
  ).toBe(job.file_evidence!.checksum)
}

afterEach(async () => {
  vi.unstubAllEnvs()
  if (storageRoot) await rm(storageRoot, { recursive: true, force: true })
})

describe('reconcileComputeJobFileEvidence', () => {
  // Criterion: the number of recovery child processes scales with the number of
  // Projects, not the number of Sessions. Two Projects with only a handful of recorded
  // Sessions each must recover with exactly one child per Project. A per-item
  // implementation would instead launch on the order of the recorded-Session count.
  // Eight Sessions per Project is small enough that any sane batch bound keeps each
  // Project to a single batch, so this asserts the per-Project shape WITHOUT pinning the
  // batch-bound value the solution chose.
  it('launches recovery work per Project, not per Session', async () => {
    await setup()
    await seedEmptyProject('project-a', 8)
    await seedEmptyProject('project-b', 8)

    ;(spawn as any).mockClear()
    await expect(reconcileComputeJobFileEvidence(storageRoot, [])).resolves.toEqual({
      removedStagingEntries: 0,
      removedActivityEntries: 0
    })

    // Exactly one recovery child per Project. (A per-Session implementation would launch
    // on the order of the 16 recorded Sessions.)
    expect(launchCount()).toBe(2)
  })

  // Criterion: recovery of a single large Project is amortized — the number of recovery
  // children does NOT grow proportionally with the Session count. With 130 recorded
  // Sessions the launch count must stay far below the Session count. The ceiling is
  // deliberately generous so it admits any reasonable batch bound (anything from roughly
  // the design target down to ~10 Sessions per batch) without pinning a specific value; a
  // per-Session implementation launches on the order of 130+ and fails it.
  it('amortizes recovery of a large Project instead of scaling per Session', async () => {
    await setup()
    await seedEmptyProject('project-batched', 130)

    ;(spawn as any).mockClear()
    await expect(reconcileComputeJobFileEvidence(storageRoot, [])).resolves.toEqual({
      removedStagingEntries: 0,
      removedActivityEntries: 0
    })

    const launches = launchCount()
    // At least one child actually ran the recovery, and recovery is strongly amortized:
    // 130 Sessions reduced to a small, sub-linear number of launches.
    expect(launches).toBeGreaterThanOrEqual(1)
    expect(launches).toBeLessThanOrEqual(16)
  })

  // Criterion: a content-addressed blob hardlinked by Sessions that land in different
  // batches must survive the earlier batch's sweep. session-first (abandoned) and
  // session-last (committed) share one blob and straddle the 64-Session boundary.
  it('keeps a blob shared across batch boundaries after the earlier batch is swept', async () => {
    await setup()
    const orphan = await begin('session-first', 'job-orphan')
    orphan.status = 'error'
    const committed = await publish('session-last', 'job-retained')
    const jobs: Job[] = [
      orphan,
      ...Array.from({ length: 63 }, (_, index): Job => ({
        project_id: projectId,
        session_id: `session-padding-${index}`,
        job_id: `job-padding-${index}`,
        status: 'running',
        submitted_at: 1,
        harvested_at: undefined
      })),
      committed
    ]

    expect(await reconcileComputeJobFileEvidence(storageRoot, jobs)).toEqual({
      removedStagingEntries: 1,
      removedActivityEntries: 0
    })
    // Abandoned Session reclaimed, committed Session's shared blob and evidence intact.
    expect(await readdir(sessionRoot(projectId, 'session-first'))).toEqual([])
    await expectSharedBlob(committed)

    // Idempotent retry removes nothing further and still preserves the shared blob.
    expect(await reconcileComputeJobFileEvidence(storageRoot, jobs)).toEqual({
      removedStagingEntries: 0,
      removedActivityEntries: 0
    })
    await expectSharedBlob(committed)
  })

  // Criterion: per-Session ownership / identity / path-safety is preserved through the
  // batched path. An unsafe target in a later Session must abort the whole recovery
  // (fail closed) without touching retained evidence or anything outside the root, and
  // recovery must remain safe to retry once the corruption is cleared — proving the
  // removed-entry counts are preserved (retention equivalence).
  it('fails closed on an unsafe Session target and retries cleanly once repaired', async () => {
    await setup()
    const committed = await publish('session-first', 'job-retained')
    const bad = await begin('session-later', 'job-bad')
    bad.status = 'error'
    const receiptPath = join(sessionRoot(projectId, bad.session_id), 'receipt-job-bad.json')
    const validReceipt = await readFile(receiptPath)
    const outsidePath = join(storageRoot, 'outside', 'keep.txt')
    await mkdir(join(storageRoot, 'outside'))
    await writeFile(outsidePath, 'outside data')
    const corrupt = { ...JSON.parse(validReceipt.toString()), stagingName: '../../outside' }
    await writeFile(receiptPath, JSON.stringify(corrupt))
    const committedBytes = await readEvidence(committed)

    await expect(
      reconcileComputeJobFileEvidence(storageRoot, [committed, bad])
    ).rejects.toThrow()
    // Nothing reclaimed, nothing outside the root touched.
    expect(await readFile(outsidePath, 'utf8')).toBe('outside data')
    expect(await readFile(receiptPath, 'utf8')).toBe(JSON.stringify(corrupt))
    expect(await readEvidence(committed)).toEqual(committedBytes)
    await expectSharedBlob(committed)

    // Repair the receipt: recovery now reclaims exactly the one abandoned Session.
    await writeFile(receiptPath, validReceipt)
    expect(await reconcileComputeJobFileEvidence(storageRoot, [committed, bad])).toEqual({
      removedStagingEntries: 1,
      removedActivityEntries: 0
    })
    expect(await readdir(sessionRoot(projectId, bad.session_id))).toEqual([])
    expect(await readEvidence(committed)).toEqual(committedBytes)
    expect(await readFile(outsidePath, 'utf8')).toBe('outside data')
  })

  // Criterion (retention/deferral equivalence + Notebook co-tenant safety): over a mixed
  // fixture the batched path removes exactly the staging/activity entries the per-item
  // path removed, retains committed + live + Notebook evidence, and defers a live job.
  it('removes exactly the abandoned entries while retaining committed, live, and notebook evidence', async () => {
    await setup()
    const committed = await publish('session-committed', 'job-committed')
    const live = await begin('session-live', 'job-live')
    await begin('session-orphan', 'job-orphan')
    await writeFile(join(storageRoot, 'input.csv'), 'uncommitted orphan bytes')
    await publish('session-uncommitted', 'job-uncommitted')
    await writeFile(join(storageRoot, 'input.csv'), sharedBytes)
    const cancelled = await begin('session-cancelled', 'job-cancelled')
    cancelled.cancellation_status = 'cancelled'
    cancelled.submitted_at = undefined
    const harvested = await begin('session-harvested', 'job-harvested')
    harvested.status = 'success'
    harvested.harvested_at = 2

    const notebookRoot = join(storageRoot, 'notebook')
    const dataRoot = join(notebookRoot, 'data')
    await mkdir(dataRoot, { recursive: true })
    await writeFile(join(dataRoot, 'input.csv'), sharedBytes)
    const observation = await startWorkingFileObservation(
      {
        dataRoot,
        notebookSessionRoot: notebookRoot,
        runId: 'run-notebook',
        fileEvidenceStorageRoot: storageRoot,
        fileEvidenceRoot: sessionRoot(projectId, 'session-notebook'),
        fileEvidenceStoragePrefix: `execution-file-evidence/${projectId}/session-notebook`
      },
      {
        watchDirectory: () => {
          throw Object.assign(new Error('watch unavailable'), { code: 'ENOSPC' })
        }
      }
    )
    const notebook = await observation.finish()
    const notebookPath = join(storageRoot, notebook.fileEvidence.storageKey!)
    const notebookBytes = await readFile(notebookPath)
    const committedBytes = await readEvidence(committed)
    const liveCapturePath = join(
      sessionRoot(projectId, live.session_id),
      'staging-job-live',
      'capture.json'
    )
    const liveCapture = await readFile(liveCapturePath)
    const jobs = [committed, live, cancelled, harvested]

    expect(await reconcileComputeJobFileEvidence(storageRoot, jobs)).toEqual({
      removedStagingEntries: 3,
      removedActivityEntries: 1
    })
    for (const name of ['orphan', 'uncommitted', 'cancelled', 'harvested']) {
      expect(await readdir(sessionRoot(projectId, `session-${name}`))).toEqual([])
    }
    expect(await readdir(sessionRoot(projectId, committed.session_id))).not.toContain(
      'receipt-job-committed.json'
    )
    expect(await readFile(liveCapturePath)).toEqual(liveCapture)
    expect(await readFile(notebookPath)).toEqual(notebookBytes)
    expect(await readdir(sessionRoot(projectId, 'session-notebook'))).toContain(
      'receipt-run-notebook.json'
    )
    expect(await readEvidence(committed)).toEqual(committedBytes)
    await expectSharedBlob(committed)

    // Idempotent: a second recovery over the same catalog removes nothing further.
    expect(await reconcileComputeJobFileEvidence(storageRoot, jobs)).toEqual({
      removedStagingEntries: 0,
      removedActivityEntries: 0
    })
    expect(await readFile(liveCapturePath)).toEqual(liveCapture)
    expect(await readFile(notebookPath)).toEqual(notebookBytes)
    expect(await readEvidence(committed)).toEqual(committedBytes)
    await expectSharedBlob(committed)
  })
})
