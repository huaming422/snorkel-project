#!/usr/bin/env bash
# Validation setup: runs after the agent applies its edits, before any story.
# Two jobs:
#   1. Rebuild the `mise` CLI binary (incremental — the image baked a pre-fix
#      target/debug/mise, so only touched crates recompile + relink).
#   2. Smoke-check the binary runs.
# No global fixtures are staged: each story builds its own isolated
# $MISE_DATA_DIR (fresh temp home) and symlinks the offline `dummy` plugin or
# writes its own inline plugin, mirroring the repo's e2e isolation harness.
# Idempotent: re-running just rebuilds; the cargo cache survives.
set -euo pipefail

REPO=/repo/mise

# Re-export the Rust toolchain paths baked by the image Dockerfile (a fresh
# shell per phase does not inherit the Dockerfile ENV lines).
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export RUSTUP_TOOLCHAIN="${RUSTUP_TOOLCHAIN:-1.99.0}"
export PATH="$CARGO_HOME/bin:$PATH"
# No new crates are introduced; rebuild offline against the warm cache.
export CARGO_NET_OFFLINE=true

MISE_BIN="$CARGO_TARGET_DIR/debug/mise"

echo "validation-setup: rustc=$(rustc --version 2>&1 | head -1)"
echo "validation-setup: cargo=$(cargo --version 2>&1 | head -1)"

# Step 1: Rebuild mise with the agent's edits applied (incremental, offline).
echo "validation-setup: rebuilding mise (incremental, offline)..."
( cd "$REPO" && cargo build --locked --offline --bin mise 2>&1 | tail -8 )
test -x "$MISE_BIN" || {
    echo "ERROR: mise binary missing at $MISE_BIN after cargo build" >&2
    exit 1
}

# Step 2: Loud smoke guard — if `mise --version` itself fails, every story
# would fail with the same opaque error; surface it here.
( "$MISE_BIN" --version >/dev/null ) || {
    echo "ERROR: $MISE_BIN --version failed after build" >&2
    exit 1
}

echo "validation-setup: done. mise=$("$MISE_BIN" --version 2>&1 | head -1) at $MISE_BIN"
