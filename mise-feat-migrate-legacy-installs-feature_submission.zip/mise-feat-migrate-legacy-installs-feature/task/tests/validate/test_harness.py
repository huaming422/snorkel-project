"""Shared test plumbing for mise-feat-migrate-legacy-installs validation stories.

This task uses the subprocess (cli-tool) driver: each story shells out to the
prebuilt `mise` binary against its own throwaway `$MISE_DATA_DIR`, then inspects
the on-disk `installs/` tree. There is no shared Python state — this module only
collects the hermetic-env plumbing the repo's own e2e harness uses
(`e2e/run_test` `setup_isolated_env`/`within_isolated_env`) so each story does
not re-spell it.

Nothing here encodes the migration's internal design (no journal/aside/lock
names, no new symbol names). The only literals are pre-existing, stable facts:
the identity-layout directory shape, the receipt filename, and the hermetic
`MISE_*` env vars — all present in the pre-fix codebase.
"""

from __future__ import annotations

import os
import re
import subprocess

# Pre-existing locations baked by the image Dockerfile.
MISE_ROOT = "/repo/mise"
TARGET_DIR = os.environ.get("CARGO_TARGET_DIR", os.path.join(MISE_ROOT, "target"))
MISE_BIN = os.path.join(TARGET_DIR, "debug", "mise")

# The offline asdf-style plugin shipped in the repo's test fixtures.
DUMMY_PLUGIN_SRC = os.path.join(MISE_ROOT, "test", "data", "plugins", "dummy")

# Pre-existing identity-layout facts (src/install_layout/record.rs:
# RECEIPT_FILE = ".mise-install.toml"; label-<8 base32 chars> hashed dir). These
# are stable layout contracts, NOT migration-design choices.
RECEIPT_FILE = ".mise-install.toml"
# A migrated/identity install resolves to `<installs>/<label>-<8 base32 chars>`.
HASHED_DIR_RE = re.compile(r"-[a-z2-7]{8}$")


def isolated_env(home: str) -> dict:
    """Return os.environ merged with the hermetic MISE_* vars for a fresh run.

    `home` is an empty temp directory owned by the caller; all mise state lives
    beneath it so runs never touch the real user or each other. Mirrors
    e2e/run_test's isolated env. Caller is responsible for mkdir of `home` and
    for symlinking any plugin into `<data_dir>/plugins/` before running.
    """
    data_dir = os.path.join(home, ".local", "share", "mise")
    env = {
        **os.environ,
        "MISE_DATA_DIR": data_dir,
        "MISE_CACHE_DIR": os.path.join(home, ".cache", "mise"),
        "MISE_CONFIG_DIR": os.path.join(home, ".config", "mise"),
        "MISE_STATE_DIR": os.path.join(home, ".local", "state", "mise"),
        "MISE_EXPERIMENTAL": "1",
        "MISE_YES": "1",
        # Force local resolution — never reach the versions host (offline).
        "MISE_USE_VERSIONS_HOST": "0",
        "MISE_TRUSTED_CONFIG_PATHS": home,
        # Keep output clean/deterministic.
        "MISE_HISTORY_NOTIFY": "0",
    }
    return env


def data_dir(env: dict) -> str:
    """The MISE_DATA_DIR of an env built by isolated_env()."""
    return env["MISE_DATA_DIR"]


def installs_dir(env: dict) -> str:
    """`<MISE_DATA_DIR>/installs`."""
    return os.path.join(data_dir(env), "installs")


def link_dummy_plugin(env: dict) -> None:
    """Symlink the repo's offline `dummy` plugin into this run's plugins dir."""
    plugins = os.path.join(data_dir(env), "plugins")
    os.makedirs(plugins, exist_ok=True)
    dst = os.path.join(plugins, "dummy")
    if not os.path.lexists(dst):
        os.symlink(DUMMY_PLUGIN_SRC, dst)


def run_mise(env: dict, args, cwd: str | None = None, timeout: int = 180):
    """Run the built `mise` with `args`; return the CompletedProcess.

    Does not raise on non-zero exit (stories assert on returncode themselves).
    """
    return subprocess.run(
        [MISE_BIN, *args],
        env=env,
        cwd=cwd or data_dir(env),
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
    )


def resolved_kind(where_path: str) -> str:
    """Classify a `mise where` path: 'hashed' (identity) or 'legacy'."""
    return "hashed" if HASHED_DIR_RE.search(where_path.rstrip("/")) else "legacy"


def receipt_state(dir_path: str) -> str:
    """'present'/'absent' for the `.mise-install.toml` receipt in dir_path."""
    return "present" if os.path.isfile(os.path.join(dir_path, RECEIPT_FILE)) else "absent"


def link_kind(path: str) -> str:
    """'symlink' if path is a symlink, 'directory' if a real dir, else 'missing'."""
    if os.path.islink(path):
        return "symlink"
    if os.path.isdir(path):
        return "directory"
    return "missing"


def journal_residue(env: dict) -> int:
    """Count leftover files under `<installs>/.mise/migrations`.

    The journal path is one reference crash-safety-record choice. This counts
    files under it ONLY to confirm a correct run leaves no bookkeeping behind; a
    design that records recovery elsewhere simply never creates this dir (count
    0, correct). Expected is always 0 — we assert cleanliness, not format.
    """
    mdir = os.path.join(installs_dir(env), ".mise", "migrations")
    if not os.path.isdir(mdir):
        return 0
    return sum(1 for _ in os.listdir(mdir))


def make_slow_plugin(env: dict, version: str, workdir: str):
    """Write an inline asdf-style plugin whose postinstall can be held open.

    Creates `<data>/plugins/asdf-slow` (bin/list-all, bin/install writing a
    `bin/slow` that echoes `slow <version>`) and a `mise.toml` in `workdir`
    pinning `asdf:slow@<version>` with a postinstall that blocks while a hold
    file exists (touching a `started` sentinel first). Returns
    `(hold_path, started_path)`.

    This is pure test plumbing modelled on the repo's own
    e2e/cli/test_install_layout_migrate_interrupted fixture; it encodes no part
    of the migration's internal design.
    """
    plugin = os.path.join(data_dir(env), "plugins", "asdf-slow")
    os.makedirs(os.path.join(plugin, "bin"), exist_ok=True)
    list_all = os.path.join(plugin, "bin", "list-all")
    with open(list_all, "w") as f:
        f.write("#!/usr/bin/env bash\necho 1.0.0 1.1.0 2.0.0\n")
    install = os.path.join(plugin, "bin", "install")
    with open(install, "w") as f:
        f.write(
            "#!/usr/bin/env bash\n"
            'mkdir -p "$ASDF_INSTALL_PATH/bin"\n'
            # echo the version so each story case has a distinct observable
            'printf \'#!/bin/sh\\necho slow %s\\n\' "$ASDF_INSTALL_VERSION" '
            '>"$ASDF_INSTALL_PATH/bin/slow"\n'
            'chmod +x "$ASDF_INSTALL_PATH/bin/slow"\n'
        )
    os.chmod(list_all, 0o755)
    os.chmod(install, 0o755)

    hold = os.path.join(workdir, "hold")
    started = os.path.join(workdir, "started")
    mise_toml = os.path.join(workdir, "mise.toml")
    postinstall = (
        f"if [ -e '{hold}' ]; then touch '{started}'; "
        f"while [ -e '{hold}' ]; do sleep 0.1; done; fi"
    )
    with open(mise_toml, "w") as f:
        f.write(
            "[tools]\n"
            f'"asdf:slow" = {{ version = "{version}", '
            f'postinstall = "{postinstall}" }}\n'
        )
    return hold, started


def interrupt_migration(env: dict, workdir: str, tool_at_version: str,
                        hold: str, started: str, timeout: int = 60) -> None:
    """Start a migration, wait until its reinstall postinstall is running, kill it.

    Plumbing only (no assertions): `touch hold`; launch
    `mise installs migrate <tool_at_version>` in the background with cwd=workdir;
    poll up to `timeout`s for the `started` sentinel; `kill -9` the process
    group; remove `hold` so a later run's postinstall does not block. Raises
    TimeoutError if the postinstall never started.
    """
    import signal
    import time

    open(hold, "w").close()
    proc = subprocess.Popen(
        [MISE_BIN, "installs", "migrate", tool_at_version],
        env=env,
        cwd=workdir,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    try:
        deadline = time.time() + timeout
        while time.time() < deadline:
            if os.path.exists(started):
                break
            if proc.poll() is not None:
                break
            time.sleep(0.1)
        else:
            raise TimeoutError("the reinstall postinstall never started")
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
        except ProcessLookupError:
            pass
        proc.wait(timeout=30)
    finally:
        if os.path.exists(hold):
            os.remove(hold)


def migrating_residue(installs_tool_dir: str) -> int:
    """Count leftover `.*mise-migrating` holding entries under a tool's dir.

    The dot-suffixed holding name is one reference choice; this counts ANY
    `*mise-migrating` sibling so an alternative holding scheme that still leaks a
    similarly-named entry is caught, while an alternative that leaves nothing
    (correct, regardless of naming) scores 0. A fully-clean run leaves none.
    """
    if not os.path.isdir(installs_tool_dir):
        return 0
    return sum(
        1
        for name in os.listdir(installs_tool_dir)
        if "mise-migrating" in name
    )
