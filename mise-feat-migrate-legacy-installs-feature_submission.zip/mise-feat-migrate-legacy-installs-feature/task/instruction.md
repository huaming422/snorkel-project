## Task

mise keeps every installed tool version on disk under its data directory (`$MISE_DATA_DIR`, by default `~/.local/share/mise`), in an `installs/` tree with two possible layouts. In the older legacy layout a version is just a plain directory at `installs/<tool>/<version>/`. In the newer identity layout each installation lives in its own content-hashed directory with a small `.mise-install.toml` receipt, and `installs/<tool>/<version>` becomes a link into it.

Installations predating the identity layout still run where they sit, but nothing moves them over, and short of uninstalling and reinstalling by hand there's no supported way to bring one into the new layout.

Add `mise installs migrate`, under the existing `mise installs` group, to bring legacy installations into the identity layout. With no arguments it covers every eligible legacy installation; optional `TOOL@VERSION` arguments narrow it to specific tools or versions, selected the way `mise uninstall` selects installed versions. It also takes a `--dry-run` (`-n`) flag for previewing.

Since it rewrites real installations on disk, it has to be safe to interrupt.

## User stories / requirements

- When a user migrates a specific legacy installation, that version afterward resolves to an identity-layout location carrying a `.mise-install.toml` receipt, and the original `installs/<tool>/<version>` path still resolves to the migrated installation. Installations the user did not name stay in the legacy layout.
- Running the migrate command with `--dry-run` (`-n`), with or without `TOOL@VERSION` filters, reports which installations would be migrated and honors the filters, but leaves every installation exactly as it was on disk.
- A successful migration replaces the legacy installation with its identity-layout form. If migrating an installation fails, that installation is left exactly as it was before, still usable, with no partial or leftover state.
- If a migration is interrupted partway, the next run of the command brings each affected installation to a clean end state: either fully migrated into the identity layout or restored to its original working form, never left half-migrated.
