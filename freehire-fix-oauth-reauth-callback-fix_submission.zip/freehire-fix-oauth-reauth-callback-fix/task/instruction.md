## Task

heads up, social sign-in's re-authentication step is broken. when a member clicks "Confirm with GitHub" to re-confirm their identity, the provider refuses the hand-off and they never make it back; what they see is an error along the lines of "the redirect_uri is not associated with this application". ordinary first-time sign-in with the same provider works fine, it's only the re-auth confirm that falls over.

this reportedly worked with Google at one point. it's gone unnoticed for months, since the buttons that kick off this flow only recently became reachable, which is how it finally surfaced.

can you dig into why the provider rejects the re-auth hand-off and fix it? first-time sign-in is the path that still goes through today, and the fix can't come at its expense.
