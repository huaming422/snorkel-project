package handler

import (
	"context"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/gofiber/fiber/v2"
	fiberrecover "github.com/gofiber/fiber/v2/middleware/recover"

	"github.com/strelov1/freehire/internal/identity/auth"
	"github.com/strelov1/freehire/internal/identity/auth/oauth"
)

// Self-contained provider/registry stubs (prefixed so they never clash with the
// package's own test helpers or anything a solution happens to add). AuthCodeURL
// is a fixed string so nothing here touches the network; the registry answers
// both the first-time sign-in and the re-authentication resolver, so it stands
// in for a deployment with the second flow turned on.
type verifyStubProvider struct{ name string }

func (p *verifyStubProvider) Name() string { return p.name }
func (p *verifyStubProvider) AuthCodeURL(state string) string {
	return "https://provider.example/consent?state=" + state
}
func (p *verifyStubProvider) FetchIdentity(context.Context, string) (oauth.Identity, error) {
	return oauth.Identity{}, nil
}

type verifyStubRegistry map[string]oauth.Provider

func (r verifyStubRegistry) Names() []string {
	names := make([]string, 0, len(r))
	for name := range r {
		names = append(names, name)
	}
	return names
}
func (r verifyStubRegistry) Provider(name, _ string) (oauth.Provider, bool) {
	p, ok := r[name]
	return p, ok
}
func (r verifyStubRegistry) ProviderV2(name, _ string) (oauth.Provider, bool) {
	p, ok := r[name]
	return p, ok
}

// verifyDispatchApp wires the callback route onto a handler whose only variable
// is whether the second (re-authentication) flow is switched on. A panic guard
// is installed so that if a hand-off reaches the re-authentication path on this
// deliberately-minimal deployment (no attempt store wired up), the request
// surfaces as a server-error response rather than tearing down the test — the
// observable fact under test is only WHICH flow claimed the hand-off, not how a
// bare-bones deployment finishes it.
func verifyDispatchApp(secondFlowEnabled bool) *fiber.App {
	app := fiber.New(fiber.Config{ErrorHandler: RenderError})
	app.Use(fiberrecover.New())
	h := &authHandlers{
		issuer:         auth.NewIssuer("test-secret", time.Hour),
		oauth:          verifyStubRegistry{"github": &verifyStubProvider{name: "github"}},
		oauthCodes:     oauth.NewCodeStore(time.Minute),
		frontendOrigin: "http://app.example",
		authV2Enabled:  secondFlowEnabled,
	}
	app.Get("/api/v1/auth/oauth/:provider/callback", h.OAuthCallback)
	return app
}

// verifyCallbackLocation drives the provider hand-off the way the browser would
// — a GET to the one registered callback carrying the state and code — with
// whatever cookies the browser brought back, and returns where the handler sent
// the browser next. That redirect target is the one thing that tells the two
// flows apart from outside.
func verifyCallbackLocation(t *testing.T, app *fiber.App, cookies map[string]string) string {
	t.Helper()
	req := httptest.NewRequestWithContext(context.Background(), http.MethodGet,
		"/api/v1/auth/oauth/github/callback?state=S&code=C", nil)
	for name, value := range cookies {
		req.AddCookie(&http.Cookie{Name: name, Value: value})
	}
	resp, err := app.Test(req)
	if err != nil {
		t.Fatalf("callback request: %v", err)
	}
	defer func() { _ = resp.Body.Close() }()
	return resp.Header.Get("Location")
}

// The first-time sign-in path answers every failure by redirecting the browser
// back with a generic auth_error marker; seeing exactly this is proof the
// request was handled as an ordinary sign-in rather than diverted.
const verifySignInFailure = "http://app.example/?auth_error=oauth"

// A hand-off that comes back carrying the re-authentication state cookie, with a
// value matching the state the provider returned, must be handed to the
// re-authentication path — NOT swallowed by first-time sign-in. The tell is that
// it does NOT end at the sign-in auth_error redirect; where the re-authentication
// path takes it from there is that flow's business, not this test's.
func TestVerifyDispatchesReauthToSecondFlow(t *testing.T) {
	loc := verifyCallbackLocation(t, verifyDispatchApp(true),
		map[string]string{oauthV2StateCookieName: "S"})

	if loc == verifySignInFailure {
		t.Fatalf("re-authentication hand-off was handled as an ordinary sign-in (Location %q)", loc)
	}
}

// Ordinary first-time sign-in must be untouched by the change: a hand-off
// carrying only the sign-in state cookie is still handled by the sign-in path,
// even with the second flow enabled. A deliberately mismatched value parks the
// request at the state check — the branch under test — without needing the
// account resolver this stub has no business carrying.
func TestVerifySignInStillHandledBySignInFlow(t *testing.T) {
	loc := verifyCallbackLocation(t, verifyDispatchApp(true),
		map[string]string{oauth.StateCookieName: "OTHER"})

	if loc != verifySignInFailure {
		t.Fatalf("Location = %q, want the sign-in path to have handled it (%q)", loc, verifySignInFailure)
	}
}

// With the second flow switched off, no re-authentication attempt can exist, so a
// cookie of that name proves nothing and must not divert an ordinary sign-in —
// the hand-off stays on the sign-in path and ends at its state-mismatch redirect.
func TestVerifyNoDispatchWhenSecondFlowDisabled(t *testing.T) {
	loc := verifyCallbackLocation(t, verifyDispatchApp(false),
		map[string]string{oauthV2StateCookieName: "S"})

	if loc != verifySignInFailure {
		t.Fatalf("Location = %q, want the sign-in state-mismatch redirect (%q); a cookie of that name must not divert sign-in while the second flow is off", loc, verifySignInFailure)
	}
}

// A re-authentication cookie is only a genuine hand-off when its value matches
// the state the provider actually returned; a leftover cookie from an abandoned
// attempt carries a value the current request does not. Such a stale cookie must
// NOT capture an ordinary sign-in: with the second flow on but the cookie value
// disagreeing with the returned state, the request stays on the sign-in path and
// ends at its state-mismatch redirect. A dispatch keyed on the cookie's mere
// presence would divert this sign-in instead — a regression this guards against.
func TestVerifyStaleReauthCookieDoesNotDivertSignIn(t *testing.T) {
	loc := verifyCallbackLocation(t, verifyDispatchApp(true),
		map[string]string{oauthV2StateCookieName: "STALE"})

	if loc != verifySignInFailure {
		t.Fatalf("Location = %q, want the sign-in path's state-mismatch redirect (%q); a re-authentication cookie whose value does not match the provider-returned state must not divert an ordinary sign-in", loc, verifySignInFailure)
	}
}
