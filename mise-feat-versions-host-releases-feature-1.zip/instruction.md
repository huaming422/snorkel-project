## Task

GitHub rate-limits anonymous API calls hard, so installs of GitHub-hosted tools in CI and Docker builds without a token fail every so often. The calls that matter here fetch a release and its assets.

We run a shared versions host that caches this data. It serves a release at https://mise-versions.jdx.dev/api/github/repos/OWNER/REPO/releases/TAG as JSON in the same shape as GitHub's release object. TAG can be latest; the answer then carries whatever concrete tag the host currently considers latest, the same way GitHub's own /releases/latest never echoes back the literal word "latest". mise should use the host for public GitHub releases, including latest lookups.

Signature and attestation verification is out of scope.

## User stories / requirements

- When a tool backed by a public GitHub repo is installed or its latest version is looked up, and the shared versions host can serve its release metadata, mise gets the metadata from the versions host: the first request for that release's metadata goes to the versions host, not to the public GitHub API.
- When the versions host can't serve the metadata, whether it's a not-found, a rate-limit, or any other error, mise falls back to the public GitHub API and the install still succeeds, with no spurious error or warning surfaced to the user.
- When the metadata from the versions host can't be used, either because its download URLs don't belong to the project being installed (a different host, owner, repo or release) or because the release has no downloadable assets, mise doesn't trust it: it discards that response and falls back to the GitHub API.
- When the release returned by the versions host isn't the release that was requested, its tag doesn't match, mise discards it and falls back to the GitHub API.
- When a tool resolves against a non-public GitHub API host, such as GitHub Enterprise or a custom API base, mise doesn't consult the versions host at all and goes straight to the configured GitHub host, exactly as it does today.
- When the versions host is turned off by setting, or mise is running offline or prefer-offline, mise doesn't reach for the versions host for release metadata.
- When a fully pinned exact version (such as a three-part X.Y.Z) of a public GitHub-backed tool is requested, mise confirms it with a single release lookup instead of fetching the full release list. That lookup goes to the versions host first, like any other release lookup. If it finds nothing, resolution falls through to the normal path, so a pin can still match a longer newest tag.
