"""The repository's own tests for multi-period builds, rolling horizons and the
optimization expressions, in the versions the image's baseline commit holds.

They pin what a model built with the snapshot setting left alone gives: the
multi-period results, the rolling-horizon runs and the expressions built from the
model. Each test writes one of those files from the baseline commit into the
repository's test folder, runs it with the repository's interpreter and removes the
copy afterwards, so edits to the files in the tree change nothing here.
"""

from __future__ import annotations

import os
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

import pytest

REPO = Path("/repo/pypsa")
PYTHON = REPO / ".venv" / "bin" / "python"
BASE_REF_FILE = Path("/var/lib/devcontainer_base_ref")
MULTIPLIER = max(1.0, float(os.environ.get("TIMEOUT_MULTIPLIER") or 1))

# file -> tests left out, by "function" for a module-level test or "Class::function".
# The example networks the tests load come from the cache the image fills at build
# time, and pypsa's network requests are switched off for the run, so a cached
# network loads without its release check. The one test left out compares the
# printed text of a piecewise expression; an equal expression that also lists its
# zero-coefficient terms prints differently.
FILES = {
    "test_lopf_multiinvest.py": set(),
    "test_lopf_rolling_horizon.py": set(),
    "test_optimization_expressions.py": {
        "TestExpressionsWithPiecewise::test_supply_withdrawal_with_negative_piecewise_port",
    },
}


def _left_out(node_id: str, names: set[str]) -> bool:
    """Whether a collected node id (file::[Class::]function[params]) is left out."""
    parts = node_id.split("[", 1)[0].split("::")[1:]
    return "::".join(parts) in names


def _failed_tests(xml_path: Path) -> list[str]:
    root = ET.parse(xml_path).getroot()
    failed = []
    for case in root.iter("testcase"):
        if case.find("failure") is not None or case.find("error") is not None:
            cls = case.get("classname", "").rsplit(".", 1)[-1]
            failed.append(f"{cls}::{case.get('name')}")
    return failed


@pytest.mark.parametrize("name", sorted(FILES))
def test_repository_tests_pass(name: str, tmp_path: Path) -> None:
    base_ref = BASE_REF_FILE.read_text().strip()
    source = subprocess.run(
        ["git", "show", f"{base_ref}:test/{name}"],
        cwd=REPO, capture_output=True, check=True,
    ).stdout
    copy = REPO / "test" / f"zz_verify_{name}"
    copy.write_bytes(source)
    rel = copy.relative_to(REPO)
    xml_path = tmp_path / "results.xml"
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1",
           "PYPSA_GENERAL__ALLOW_NETWORK_REQUESTS": "false"}
    env.pop("PYTHONPATH", None)
    try:
        listed = subprocess.run(
            [str(PYTHON), "-m", "pytest", str(rel), "-q", "-p", "no:cacheprovider",
             "--collect-only"],
            cwd=REPO, capture_output=True, text=True, timeout=300 * MULTIPLIER,
            env=env, check=False,
        ).stdout.splitlines()
        node_ids = [
            line.strip() for line in listed
            if line.startswith(f"{rel}::") and not _left_out(line.strip(), FILES[name])
        ]
        if not node_ids:
            pytest.fail(f"no tests collected from {name}: {' | '.join(listed[-3:])}")
        cmd = [str(PYTHON), "-m", "pytest", *node_ids, "-q", "-p", "no:cacheprovider",
               f"--junitxml={xml_path}"]
        proc = subprocess.run(cmd, cwd=REPO, capture_output=True, text=True,
                              timeout=900 * MULTIPLIER, env=env, check=False)
    finally:
        copy.unlink(missing_ok=True)
    if not xml_path.exists():
        tail = (proc.stdout + proc.stderr).strip().splitlines()[-3:]
        pytest.fail(f"{name} didn't run (exit {proc.returncode}): {' | '.join(tail)}")
    failed = _failed_tests(xml_path)
    assert not failed and proc.returncode == 0, (
        f"{len(failed)} failed in {name}: {', '.join(failed[:3])}"
        + (f" (exit {proc.returncode})" if not failed else "")
    )
