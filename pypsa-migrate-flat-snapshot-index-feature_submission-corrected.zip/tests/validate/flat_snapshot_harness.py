"""Networks and observations for the multi-period snapshot labelling stories.

Every observe_* function takes the case's `inputs` and the story file's
`representation(mode)` adapter, builds and solves the networks the story
describes with HiGHS, and returns a dict keyed like the story's EXPECTED lines.

`representation(mode)` returns `(context_manager, build_kwargs)`. Builds run
inside the context manager, and `build_kwargs` go to every `n.optimize(...)`,
`n.optimize.create_model(...)` and rolling-horizon call. Mode "default" leaves
the setting alone, "flat" turns the flat labelling on, and "invalid" passes the
same setting a value it doesn't know.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

import pypsa

SOLVER = {"solver_name": "highs"}


# ---------------------------------------------------------------- helpers
def _settings(representation, mode):
    got = representation(mode)
    if not (isinstance(got, tuple) and len(got) == 2):
        msg = f"representation({mode!r}) must return (context_manager, kwargs), got {got!r}"
        raise TypeError(msg)
    return got


def _model_labels(n):
    return n.model.variables["Generator-p"].indexes["snapshot"]


def _multiindex_parts(n):
    """Names of the model's variables and constraints whose snapshot dimension is a MultiIndex."""
    parts = []
    for kind, group in (("variable", n.model.variables), ("constraint", n.model.constraints)):
        for name in group:
            idx = group[name].indexes.get("snapshot")
            if isinstance(idx, pd.MultiIndex):
                parts.append(f"{kind} {name}")
    return parts


def _describe_labels(labels, built):
    """How a model labels its snapshot dimension, relative to the snapshots it covers."""
    if isinstance(labels, pd.MultiIndex):
        return "multiindex" if list(labels) == list(built) else "other multiindex"
    entries = list(labels)
    if len(entries) == len(built) and all(isinstance(e, tuple) for e in entries):
        if entries == list(built):
            return "flat pairs"
    first = entries[0] if entries else None
    return f"other: {type(labels).__name__} of {len(entries)}, first {first!r}"


def _status(status):
    return tuple(str(s) for s in status)


def _series(n):
    """Every solved time series and capacity of the network, keyed by name."""
    out = {}
    for c in ("Generator", "StorageUnit", "Store", "Line", "Link"):
        comp = n.c[c]
        if comp.static.empty:
            continue
        for attr in ("p", "p0", "state_of_charge", "e"):
            df = comp.dynamic.get(attr)
            if df is not None and not df.empty:
                df = df.reindex(index=n.snapshots, columns=comp.static.index)
                out[f"{c}.{attr}"] = df.fillna(0.0).to_numpy(dtype=float)
        nom = comp._operational_attrs["nom"] + "_opt"
        if nom in comp.static:
            out[f"{c}.{nom}"] = comp.static[nom].to_numpy(dtype=float)
    return out


def _compare(a, b):
    """'same' when two solved networks agree, else the names of what differs."""
    diff = []
    for key, va in a.items():
        vb = b.get(key)
        if vb is None or vb.shape != va.shape or not np.allclose(va, vb, rtol=1e-7, atol=1e-6):
            diff.append(key)
    diff += [k for k in b if k not in a]
    return "same" if not diff else "differs: " + ", ".join(sorted(diff))


def _error(e):
    return f"error: {type(e).__name__}: {str(e).splitlines()[0][:160] if str(e) else ''}"


# ---------------------------------------------------------------- networks
def two_buses():
    n = pypsa.Network(snapshots=range(4))
    n.investment_periods = [2020, 2030]
    n.add("Bus", ["north", "south"])
    n.add("Generator", ["gn", "gs"], bus=["north", "south"], p_nom_extendable=True,
          capital_cost=[10, 20], marginal_cost=[8, 4])
    n.add("Load", ["ln", "ls"], bus=["north", "south"], p_set=1.0)
    return n


def emissions_cap():
    n = pypsa.Network(snapshots=range(4))
    n.investment_periods = [2020, 2030]
    n.investment_period_weightings["years"] = [10, 1]
    n.add("Bus", "b")
    n.add("Carrier", "coal", co2_emissions=1.0)
    n.add("Carrier", "clean", co2_emissions=0.0)
    n.add("Generator", "dirty", bus="b", p_nom=1000, marginal_cost=4, carrier="coal")
    n.add("Generator", "cleang", bus="b", p_nom=1000, marginal_cost=20, carrier="clean")
    n.add("Load", "l", bus="b", p_set=100.0)
    n.add("GlobalConstraint", "co2", sense="<=", type="primary_energy",
          carrier_attribute="co2_emissions", constant=1200.0)
    return n


def cyclic_storage():
    n = pypsa.Network(snapshots=range(4))
    n.investment_periods = [2020, 2030]
    n.add("Bus", "b")
    mc = pd.Series([1.0, 50.0, 1.0, 50.0, 1.0, 50.0, 1.0, 50.0], index=n.snapshots)
    n.add("Generator", "g", bus="b", p_nom=200, marginal_cost=mc)
    n.add("Load", "l", bus="b", p_set=100.0)
    n.add("StorageUnit", "su", bus="b", p_nom=100, max_hours=4,
          cyclic_state_of_charge=True)
    return n


def mixed():
    """Three periods with lines, a link, storage, a store, ramp limits and caps."""
    periods = (2020, 2030, 2040)
    n = pypsa.Network(snapshots=range(4))
    n.investment_periods = list(periods)
    n.investment_period_weightings["years"] = [10, 5, 2]
    n.investment_period_weightings["objective"] = [1.0, 0.7, 0.4]
    hours = np.tile([1.0, 2.0, 3.0, 2.0], len(periods))
    for col in ("objective", "stores", "generators"):
        n.snapshot_weightings[col] = hours
    n.add("Carrier", "gas", co2_emissions=0.5)
    n.add("Carrier", "wind", co2_emissions=0.0)
    n.add("Carrier", "AC")
    n.add("Bus", ["a", "b", "c"], carrier="AC", v_nom=380)
    n.add("Line", ["ab", "bc", "ca"], bus0=["a", "b", "c"], bus1=["b", "c", "a"],
          x=[0.1, 0.2, 0.15], r=0.01, s_nom=60, s_nom_extendable=True, capital_cost=5,
          carrier="AC")
    rng = np.random.default_rng(7)
    wind = pd.Series(rng.uniform(0.05, 1.0, len(n.snapshots)), index=n.snapshots)
    load = pd.Series(rng.uniform(60, 140, len(n.snapshots)), index=n.snapshots)
    n.add("Generator", "wind", bus="a", carrier="wind", p_nom_extendable=True,
          capital_cost=40, marginal_cost=0.1, p_max_pu=wind)
    for p in periods:
        n.add("Generator", f"gas-{p}", bus="b", carrier="gas", p_nom_extendable=True,
              capital_cost=15, marginal_cost=30 + (p - 2020) / 10, build_year=p,
              lifetime=15, ramp_limit_up=0.5, ramp_limit_down=0.5)
    n.add("Load", "la", bus="a", p_set=load * 0.5)
    n.add("Load", "lc", bus="c", p_set=load)
    n.add("StorageUnit", "su", bus="c", p_nom_extendable=True, capital_cost=8,
          max_hours=3, cyclic_state_of_charge=True,
          cyclic_state_of_charge_per_period=True)
    n.add("Bus", "h", carrier="AC")
    n.add("Store", "st", bus="h", e_nom_extendable=True, capital_cost=2,
          e_cyclic=True, e_cyclic_per_period=True)
    n.add("Link", "ch", bus0="c", bus1="h", p_nom=50, efficiency=0.9, p_min_pu=-1)
    n.add("GlobalConstraint", "co2", sense="<=", type="primary_energy",
          carrier_attribute="co2_emissions", constant=4000.0)
    n.add("GlobalConstraint", "co2-2030", sense="<=", type="primary_energy",
          carrier_attribute="co2_emissions", constant=300.0, investment_period=2030)
    n.add("GlobalConstraint", "windcap", type="tech_capacity_expansion_limit",
          carrier_attribute="wind", sense="<=", constant=300)
    return n


def line_budget():
    """Four periods of new generators and lines under one transmission cost budget."""
    n = pypsa.Network(snapshots=range(3))
    n.investment_periods = [2020, 2030, 2040, 2050]
    n.add("Carrier", "gencarrier")
    n.add("Bus", ["one", "two"])
    for i, period in enumerate(n.investment_periods):
        factor = (10 + i) / 10
        n.add("Generator", [f"gen1-{period}", f"gen2-{period}"], bus=["one", "two"],
              lifetime=30, build_year=period, capital_cost=[100 / factor, 100 * factor],
              marginal_cost=[i + 2, i + 1], p_nom_extendable=True, carrier="gencarrier")
        n.add("Line", f"line-{period}", bus0="one", bus1="two", length=1, build_year=period,
              lifetime=40, capital_cost=30 + i, x=0.0001, s_nom_extendable=True)
    load = pd.Series(np.arange(100.0, 100.0 + len(n.snapshots)), index=n.snapshots)
    n.add("Load", ["load1", "load2"], bus=["one", "two"],
          p_set=pd.DataFrame({"load1": load, "load2": load}))
    n.add("GlobalConstraint", "line_budget", type="transmission_expansion_cost_limit",
          constant=1000, sense="==", carrier_attribute="AC")
    return n


def later_load():
    n = pypsa.Network(snapshots=range(3))
    n.investment_periods = [2020, 2030]
    n.add("Bus", "b")
    n.add("Generator", "g", bus="b", p_nom=1000, marginal_cost=10)
    load = pd.Series(100.0, index=n.snapshots)
    load.loc[2030] = 777.0
    n.add("Load", "load", bus="b", p_set=load)
    return n


def storage_over_time():
    n = pypsa.Network(snapshots=range(6))
    n.investment_periods = [2020, 2030]
    n.add("Bus", "b")
    mc = pd.Series(np.tile([50.0, 1.0, 5.0], 4), index=n.snapshots)
    n.add("Generator", "g", bus="b", p_nom=300, marginal_cost=mc,
          ramp_limit_up=0.1, ramp_limit_down=0.1)
    n.add("Generator", "peak", bus="b", p_nom=300, marginal_cost=200)
    load = pd.Series(np.linspace(80, 160, len(n.snapshots)), index=n.snapshots)
    n.add("Load", "l", bus="b", p_set=load)
    n.add("StorageUnit", "su", bus="b", p_nom=100, max_hours=2,
          cyclic_state_of_charge=True, cyclic_state_of_charge_per_period=True)
    return n


def callback_network():
    n = pypsa.Network(snapshots=range(3))
    n.investment_periods = [2020, 2030, 2040, 2050]
    n.add("Bus", "b")
    n.add("Generator", "g", bus="b", p_nom=1000, marginal_cost=10)
    n.add("Generator", "backup", bus="b", p_nom=1000, marginal_cost=100)
    n.add("Load", "l", bus="b", p_set=500.0)
    pmax = pd.Series(np.linspace(0.3, 1.0, len(n.snapshots)), index=n.snapshots)
    n.c.generators.dynamic.p_max_pu["g"] = pmax
    return n


NETWORKS = {
    "two_buses": two_buses,
    "emissions_cap": emissions_cap,
    "cyclic_storage": cyclic_storage,
    "mixed": mixed,
    "later_load": later_load,
    "line_budget": line_budget,
}


def _window(n, name):
    sns = n.snapshots
    period = sns.get_level_values("period")
    if name == "all":
        return None
    if name == "later_periods":
        return sns[period >= 2030]
    if name == "across_boundary":
        return sns[2:7]
    if name == "period_2030":
        return sns[period == 2030]
    raise ValueError(name)


def _solve(mk, window, representation, mode):
    n = mk()
    ctx, kw = _settings(representation, mode)
    with ctx:
        status = n.optimize(_window(n, window), multi_investment_periods=True,
                            **SOLVER, **kw)
    return n, _status(status)


# ---------------------------------------------------------------- stories
def _labels_of_build(n, built):
    """How the live model labels its snapshots, checked on every variable and constraint."""
    kind = _describe_labels(_model_labels(n), built)
    if kind == "flat pairs" and (parts := _multiindex_parts(n)):
        kind = f"flat pairs, but {len(parts)} parts keep a MultiIndex, such as {parts[0]}"
    return kind


def observe_setting(inputs, representation):
    """Story snapshot_index_option: build one model and read how it labels snapshots."""
    n = two_buses()
    window = _window(n, inputs["window"])
    built = n.snapshots if window is None else window
    try:
        ctx, kw = _settings(representation, inputs["mode"])
        with ctx:
            n.optimize.create_model(window, multi_investment_periods=True, **kw)
    except NotImplementedError:
        raise
    except Exception:  # noqa: BLE001
        return {"build": "rejected", "model_labels": "none"}
    return {"build": "accepted", "model_labels": _labels_of_build(n, built)}


def observe_results(inputs, representation):
    """Story flat_results_identical: one network solved under both labellings."""
    mk = NETWORKS[inputs["network"]]
    nd, sd = _solve(mk, inputs["window"], representation, "default")
    out = {"default_objective": round(float(nd.objective), 3)
           if sd == ("ok", "optimal") else f"status {sd}"}
    try:
        nf, sf = _solve(mk, inputs["window"], representation, "flat")
    except NotImplementedError:
        raise
    except Exception as e:  # noqa: BLE001
        out["flat_objective"] = _error(e)
        out["flat_vs_default"] = _error(e)
        return out
    if sf != ("ok", "optimal"):
        out["flat_objective"] = f"status {sf}"
        out["flat_vs_default"] = f"status {sf}"
        return out
    out["flat_objective"] = round(float(nf.objective), 3)
    out["flat_vs_default"] = _compare(_series(nd), _series(nf))
    return out


def _window_labels(net):
    """How the model of one window labels its snapshots, read while that model is live."""
    labels = _model_labels(net)
    if isinstance(labels, pd.MultiIndex):
        return "multiindex"
    entries = list(labels)
    order = {s: i for i, s in enumerate(net.snapshots)}
    positions = [order.get(e) for e in entries if isinstance(e, tuple)]
    if len(positions) != len(entries) or None in positions or positions != sorted(positions):
        return f"other: {type(labels).__name__} of {len(entries)}"
    if parts := _multiindex_parts(net):
        return f"flat pairs, but {len(parts)} parts keep a MultiIndex, such as {parts[0]}"
    return "flat pairs"


def _run_windows(inputs, representation, mode):
    n = storage_over_time()
    ctx, kw = _settings(representation, mode)
    kinds = []
    if mode == "flat":
        kw = {**kw, "extra_functionality": lambda net, sns: kinds.append(_window_labels(net))}
    with ctx:
        if inputs["run"] == "rolling_horizon":
            n.optimize.optimize_with_rolling_horizon(
                horizon=int(inputs["horizon"]), overlap=int(inputs["overlap"]),
                multi_investment_periods=True, **SOLVER, **kw)
        elif inputs["run"] == "period_by_period":
            period = n.snapshots.get_level_values("period")
            for p in n.investment_periods:
                status = n.optimize(n.snapshots[period == p],
                                    multi_investment_periods=True, **SOLVER, **kw)
                if _status(status) != ("ok", "optimal"):
                    raise RuntimeError(f"period {p}: status {_status(status)}")
        else:
            raise ValueError(inputs["run"])
    return n, kinds


def _dispatch_cost(n):
    p = n.c.generators.dynamic.p.reindex(n.snapshots)
    mc = n.get_switchable_as_dense("Generator", "marginal_cost")
    return round(float((p * mc).sum().sum()), 3)


def observe_windows(inputs, representation):
    """Story windowed_runs: rolling-horizon and period-by-period runs under both labellings."""
    nd, _ = _run_windows(inputs, representation, "default")
    out = {"default_dispatch_cost": _dispatch_cost(nd)}
    try:
        nf, kinds = _run_windows(inputs, representation, "flat")
    except NotImplementedError:
        raise
    except Exception as e:  # noqa: BLE001
        out["flat_dispatch_cost"] = _error(e)
        out["flat_vs_default"] = _error(e)
        out["flat_window_labels"] = _error(e)
        return out
    out["flat_dispatch_cost"] = _dispatch_cost(nf)
    out["flat_vs_default"] = _compare(_series(nd), _series(nf))
    others = [k for k in kinds if k != "flat pairs"]
    if not kinds:
        out["flat_window_labels"] = "no window reached the callback"
    else:
        out["flat_window_labels"] = "flat pairs" if not others else f"{len(others)} of {len(kinds)} windows: {others[0]}"
    return out


_SOLVED = {}


def _solved_mixed(representation, mode, window):
    """The mixed network solved once per labelling and window, kept for the file's cases."""
    if (mode, window) not in _SOLVED:
        try:
            _SOLVED[mode, window] = _solve(mixed, window, representation, mode)[0]
        except NotImplementedError:
            raise
        except Exception as e:  # noqa: BLE001
            _SOLVED[mode, window] = e
    return _SOLVED[mode, window]


def _total(values):
    arr = np.asarray(values, dtype=float)
    return round(float(np.nansum(np.abs(arr))), 3)


def _same_statistic(a, b):
    if isinstance(a, pd.Series):
        a, b = a.to_frame(), b.to_frame() if isinstance(b, pd.Series) else b
    if not isinstance(b, pd.DataFrame) or a.shape != b.shape:
        return "differs: shape"
    b = b.reindex(index=a.index, columns=a.columns)
    va, vb = a.to_numpy(dtype=float), b.to_numpy(dtype=float)
    if np.allclose(np.nan_to_num(va), np.nan_to_num(vb), rtol=1e-7, atol=1e-6) and (
        np.isnan(va) == np.isnan(vb)
    ).all():
        return "same"
    return "differs: values"


def observe_statistics(inputs, representation):
    """Story statistics_after_solve: n.statistics read after a default and a flat solve."""
    name = inputs["statistic"]
    nd = _solved_mixed(representation, "default", inputs["window"])
    sd = getattr(nd.statistics, name)()
    out = {"default_total": _total(sd)}
    nf = _solved_mixed(representation, "flat", inputs["window"])
    if isinstance(nf, Exception):
        out["flat_vs_default"] = _error(nf)
        return out
    try:
        sf = getattr(nf.statistics, name)()
    except Exception as e:  # noqa: BLE001
        out["flat_vs_default"] = _error(e)
        return out
    out["flat_vs_default"] = _same_statistic(sd, sf)
    return out


def observe_callback(inputs, representation):
    """Story extra_functionality_snapshots: what the callback gets and a constraint it adds."""
    n = callback_network()
    built = n.snapshots if inputs["scope"] == "all" else n.snapshots[:7]
    seen = []

    def callback(net, sns):
        seen.append(sns)
        m = net.model
        cap = 600 * net.c.generators.da.p_max_pu.sel(name="g", snapshot=sns)
        m.add_constraints(m["Generator-p"].sel(name="g") <= cap, name="g-user-cap")

    ctx, kw = _settings(representation, inputs["mode"])
    try:
        with ctx:
            if inputs["entry"] == "optimize":
                status = n.optimize(built, multi_investment_periods=True,
                                    extra_functionality=callback, **SOLVER, **kw)
            else:
                n.optimize.create_model(built, multi_investment_periods=True, **kw)
                status = n.optimize.solve_model(extra_functionality=callback, **SOLVER)
    except NotImplementedError:
        raise
    except Exception as e:  # noqa: BLE001
        got = seen[0] if seen else None
        return {"callback_snapshots": "none" if got is None else _callback_kind(n, got, built),
                "callback_count": -1 if got is None else len(got),
                "capped_output": _error(e)}
    got = seen[0]
    if _status(status) != ("ok", "optimal"):
        capped = f"status {_status(status)}"
    else:
        p = n.c.generators.dynamic.p["g"].reindex(built)
        capped = [round(float(v), 6) for v in p.to_numpy(dtype=float)]
    return {"callback_snapshots": _callback_kind(n, got, built),
            "callback_count": len(got),
            "capped_output": capped}


def _callback_kind(n, got, built):
    model = _model_labels(n)
    if isinstance(got, pd.MultiIndex) == isinstance(model, pd.MultiIndex) and list(got) == list(
        model
    ):
        return "model labels"
    if len(got) == len(built):
        got_kind = _describe_labels(got, built)
    elif len(got) == len(n.snapshots):
        got_kind = "every network snapshot"
    else:
        got_kind = f"{len(got)} snapshots"
    return f"{got_kind} while the model has {_describe_labels(model, built)}"
