#!/usr/bin/env bash
# validation-setup.sh runs once before the validation agent starts, with the
# network available. The image already holds the full dependency closure from
# `uv sync --frozen --extra test` (PyPSA + legacy linopy + HiGHS), so on a
# healthy image this changes nothing. The online sync below only runs when the
# closure doesn't import, and it says so in the log. A tree that doesn't import
# or can't solve a small multi-period model is logged here and left for the
# stories to score.
set -euo pipefail

REPO=/repo/pypsa
cd "$REPO"

export UV_CACHE_DIR="${UV_CACHE_DIR:-/opt/uv-cache}"
export UV_PYTHON_INSTALL_DIR="${UV_PYTHON_INSTALL_DIR:-/opt/python}"
export SETUPTOOLS_SCM_PRETEND_VERSION="${SETUPTOOLS_SCM_PRETEND_VERSION:-1.2.4}"
export PATH="/repo/pypsa/.venv/bin:${PATH}"

# Offline first: check the venv imports PyPSA and the optimization stack the
# stories use (legacy linopy + HiGHS for LP solves).
if uv run --no-sync --frozen python -c \
    "import pypsa, linopy, highspy, pandas, xarray, numpy" >/dev/null 2>&1; then
    echo "[validation-setup] baked dependency closure OK (offline)"
else
    echo "[validation-setup] WARNING: closure doesn't import; attempting online sync" >&2
    if ! uv sync --frozen --extra test > /tmp/validation-setup-sync.log 2>&1; then
        echo "[validation-setup] uv sync failed:" >&2
        tail -80 /tmp/validation-setup-sync.log >&2 || true
    fi
    uv pip install --python .venv/bin/python setuptools==84.2.1 setuptools_scm==10.3.4 || true
    if ! uv run --no-sync --frozen python -c \
        "import pypsa, linopy, highspy, pandas, xarray, numpy"; then
        echo "[validation-setup] WARNING: still doesn't import; the stories will report it" >&2
    fi
fi

# Smoke check: a small multi-period LP builds and solves to optimality with the
# setting left alone and the bundled HiGHS solver, on the linopy release the
# task targets. Only public PyPSA calls are used here.
if ! uv run --no-sync --frozen python - <<'PY'
import pandas as pd
import pypsa

n = pypsa.Network(snapshots=range(3))
n.investment_periods = [2020, 2030]
n.add("Bus", "b")
n.add("Generator", "g", bus="b", p_nom=1000, marginal_cost=10)
n.add("Load", "l", bus="b", p_set=1.0)
status, cond = n.optimize(multi_investment_periods=True, solver_name="highs")
assert (status, cond) == ("ok", "optimal"), (status, cond)
assert isinstance(n.model.parameters.snapshots.to_index(), pd.MultiIndex)
import linopy
print(f"[validation-setup] pypsa {pypsa.__version__} linopy {linopy.__version__}; "
      "multi-period HiGHS solve OK (default MultiIndex build)")
PY
then
    echo "[validation-setup] WARNING: the multi-period smoke solve failed; the stories will report it" >&2
fi

echo "[validation-setup] validation env ready"
