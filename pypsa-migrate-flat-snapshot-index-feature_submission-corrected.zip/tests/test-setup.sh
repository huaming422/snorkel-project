#!/usr/bin/env bash
# test-setup.sh runs once before the verifier, with the network available.
# The image already holds the full dependency closure from
# `uv sync --frozen --extra test` (base deps + pytest + HiGHS), so on a healthy
# image this changes nothing. The online sync below only runs when the closure
# doesn't import, and it says so in the log. A tree whose own code doesn't import
# is logged here and left for the verifier and the stories to score.
set -euo pipefail

REPO=/repo/pypsa
cd "$REPO"

export UV_CACHE_DIR="${UV_CACHE_DIR:-/opt/uv-cache}"
export UV_PYTHON_INSTALL_DIR="${UV_PYTHON_INSTALL_DIR:-/opt/python}"
export SETUPTOOLS_SCM_PRETEND_VERSION="${SETUPTOOLS_SCM_PRETEND_VERSION:-1.2.4}"
export PATH="/repo/pypsa/.venv/bin:${PATH}"

# Offline first: check the closure imports the solver and optimization stack the
# verifier relies on. When it does, nothing here touches the network.
if uv run --no-sync --frozen python -c \
    "import pypsa, linopy, highspy, pandas, xarray, numpy" >/dev/null 2>&1; then
    echo "[test-setup] baked dependency closure OK (offline)"
else
    echo "[test-setup] WARNING: closure doesn't import; attempting online sync" >&2
    if ! uv sync --frozen --extra test > /tmp/test-setup-sync.log 2>&1; then
        echo "[test-setup] uv sync failed:" >&2
        tail -80 /tmp/test-setup-sync.log >&2 || true
    fi
    uv pip install --python .venv/bin/python setuptools==84.2.1 setuptools_scm==10.3.4 || true
    if ! uv run --no-sync --frozen python -c \
        "import pypsa, linopy, highspy, pandas, xarray, numpy"; then
        echo "[test-setup] WARNING: still doesn't import; the tests will report it" >&2
    fi
fi

# The installed linopy has to be the release the task is built around, and HiGHS
# has to be there for offline LP solves.
if ! uv run --no-sync --frozen python - <<'PY'
import linopy, highspy, pypsa
print(f"[test-setup] pypsa {pypsa.__version__} linopy {linopy.__version__} (HiGHS available)")
PY
then
    echo "[test-setup] WARNING: pypsa doesn't import; the tests will report it" >&2
fi

echo "[test-setup] pypsa optimization test env ready"
