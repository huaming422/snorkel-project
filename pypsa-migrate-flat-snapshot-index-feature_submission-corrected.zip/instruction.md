## Task

linopy's next release won't take any pandas MultiIndex as a dimension coordinate, and the models we build with investment periods keep their snapshots on one. Once we move to that release, those builds stop working. Add an opt-in flat labeling of snapshots for multi-period models, and keep what we have now as the default.

## User stories / requirements

- One setting decides how multi-period builds label snapshots. Left alone, models keep today's MultiIndex. Switched to flat, every variable and constraint uses plain (period, timestep) tuples, in the order of the snapshots being optimized. A value the setting doesn't know makes the model build raise an error.
- Solved with flat labels, a multi-period network reaches the default's objective, dispatch, storage levels and capacities, with storage, lines, links, ramp limits, emission caps and expansion limits, also when part of the horizon is optimized. Left alone, the setting keeps today's multi-period solutions, rolling-horizon runs and single-period expression results.
- Rolling-horizon runs, and runs that go through the investment periods in turn, dispatch the same way and leave storage at the same levels under either labeling.
- Once a flat build is solved, n.statistics reports capex, opex, supply, energy balance, curtailment and system cost equal to what it reports after a default build, with the solved model still attached.
- The extra_functionality callback receives the build's snapshots, labeled the way the model labels them, under either setting and for a partial build, passed to n.optimize or to solve_model after create_model. Inside it, n.c.<component>.da data lines up with those labels, so a constraint mixing that data with model variables holds the same way.
