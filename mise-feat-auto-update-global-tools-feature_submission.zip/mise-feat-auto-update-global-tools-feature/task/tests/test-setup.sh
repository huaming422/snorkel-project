#!/usr/bin/env bash
# Prepare the container for the verifier/validation run.
#
# No services to start and no data to seed: the image pre-fetches the full
# workspace dependency closure at the base commit (`cargo fetch --locked`) and
# pre-builds the workspace test binaries including the `mise` binary, so the
# agent's and verifier's first `cargo build` is incremental. The behavioral
# tests drive the mise CLI offline through the repo's local `dummy` /
# `needs-dummy` asdf plugins via the e2e harness (`e2e/run_test`), which needs
# no network.
#
# This script runs with network available (verifier phase), but the task is an
# offline-agent task: force cargo offline so any accidental cache miss fails fast
# here instead of hanging on the network, matching the agent phase.
set -euo pipefail

# Offline switches scoped to the task's own cargo (NOT baked into the image ENV,
# which would break harbor's `uv tool install` agent-harness setup). CARGO_HOME
# and CARGO_TARGET_DIR are inherited from the image; the warmed registry + target
# caches live under them.
export CARGO_NET_OFFLINE=true

echo "[test-setup] Rust version:    $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:   $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root:  /repo/mise"
echo "[test-setup] CARGO_HOME:      ${CARGO_HOME:-<unset>}"
echo "[test-setup] CARGO_TARGET_DIR:${CARGO_TARGET_DIR:-<unset>}"
echo "[test-setup] CARGO_NET_OFFLINE=${CARGO_NET_OFFLINE}"

# Sanity: the e2e harness and the local dummy plugins the behavioral tests use
# must be present in the checked-out repo (they ship with the repo; no fetch).
for p in e2e/run_test e2e/assert.sh test/data/plugins/dummy test/data/plugins/needs-dummy; do
  if [[ -e "/repo/mise/$p" ]]; then
    echo "[test-setup] found: $p"
  else
    echo "[test-setup] WARNING: expected e2e asset missing: $p" >&2
  fi
done

echo "[test-setup] Setup complete."
