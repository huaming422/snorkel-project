## Task

People install plenty of tools globally with mise (an AI CLI, a formatter, a language runtime) and they quietly fall behind because nobody remembers to run `mise upgrade`. We want a way to mark a tool in your global config so mise keeps it current on its own, either always or on a cadence you choose. Right before that tool is launched through a shim or `mise x`, mise should bring it up to the newest version allowed by what you've pinned and then run the freshly updated tool.

## User stories / requirements

- When a user runs an opted-in global tool (through its shim or `mise x`) and a newer version exists within the range they pinned, mise installs and runs that newer in-range version. An exact pin is never changed, and a launch within the interval runs the installed version without re-checking.
- Only the global config can opt a tool in: a project or local config that sets the option does not enable auto-updating. And if a project pins its own version of the tool, running the tool in that project does not update it.
- If a user configures a check interval shorter than one hour, mise treats it as one hour and warns that the value was raised.
- Auto-update stays out of the way when it shouldn't run: being offline, running under `--locked`, and shell `hook-env` evaluation never trigger an update check.
- If an update fails (for example, when offline), mise warns and still runs the version already installed. The failure is reported in `mise doctor` and keeps showing there until a later update succeeds or the tool stops opting in.
- Inside an activated shell, the update does not pick up the project's `[env]`; it runs with the environment the shell had before mise's activation changed it, so project settings don't leak into the update.
- If updating one tool runs a post-install step that itself invokes another opted-in tool that is also due, the whole thing completes promptly rather than hanging.
- When a global lockfile pins the tool, an auto-update moves that entry to the new version. A project lockfile is left byte-for-byte unchanged.
- Saving the option through `mise use -g --tool-option auto_update=…` writes it into the global config, and later rewrites of that entry keep the option intact.
- The `auto_update` option accepts `true`, `false`, or a duration string, and rejects anything else with a clear error.
