#!/usr/bin/env bash
# Validation setup: rebuild the `mise` binary with the agent's edits applied,
# then prove it runs the local dummy plugin offline. Idempotent; incremental
# build on the warm target cache baked into the image.
#
# The behavioral tests build their own throwaway environments at run time (see
# test_harness.py / MiseEnv), so there are no fixtures to stage here, only the
# binary and a loud smoke guard.
set -euo pipefail

REPO=/repo/mise
# CARGO_TARGET_DIR is inherited from the image; the warmed registry + target
# caches live under it. Fall back to the in-tree target dir if unset.
CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-$REPO/target}"
export CARGO_TARGET_DIR
MISE_BIN="$CARGO_TARGET_DIR/debug/mise"

# Offline switch scoped to this build (matches the no-network agent phase): a
# cache miss fails fast here instead of hanging on the network.
export CARGO_NET_OFFLINE=true

echo "validation-setup: rustc=$(rustc --version 2>&1 | head -1)"
echo "validation-setup: cargo=$(cargo --version 2>&1 | head -1)"
echo "validation-setup: CARGO_HOME=${CARGO_HOME:-<unset>}"
echo "validation-setup: CARGO_TARGET_DIR=$CARGO_TARGET_DIR"

# Step 1: Rebuild mise with the agent's edits applied. Loud on failure.
echo "validation-setup: building mise (incremental)..."
( cd "$REPO" && cargo build --locked --bin mise ) > /tmp/validate-build.log 2>&1 || {
    echo "ERROR: cargo build failed; last 80 lines:" >&2
    tail -80 /tmp/validate-build.log >&2
    exit 1
}
test -x "$MISE_BIN" || {
    echo "ERROR: mise binary missing at $MISE_BIN after cargo build" >&2
    exit 1
}
echo "validation-setup: mise built at $MISE_BIN ($("$MISE_BIN" --version 2>&1 | head -1))"

# Step 2: Confirm the local dummy / needs-dummy plugins the stories rely on are
# present in the checked-out repo (they ship with it; no fetch).
for p in test/data/plugins/dummy test/data/plugins/needs-dummy; do
    if [[ -e "$REPO/$p" ]]; then
        echo "validation-setup: found plugin: $p"
    else
        echo "ERROR: expected plugin missing: $REPO/$p" >&2
        exit 1
    fi
done

# Step 3: Loud smoke guard: surface a broken binary / plugin wiring here rather
# than as an opaque per-story error. Build a minimal isolated env, opt dummy in,
# and confirm an in-range auto-update actually runs the newer version offline.
echo "validation-setup: smoke-checking an offline auto-update..."
SMOKE_ROOT="$(mktemp -d /tmp/validate-smoke.XXXXXX)"
(
    export HOME="$SMOKE_ROOT/home"
    export MISE_CONFIG_DIR="$HOME/.config/mise"
    export MISE_DATA_DIR="$HOME/.local/share/mise"
    export MISE_STATE_DIR="$HOME/.local/state/mise"
    export MISE_CACHE_DIR="$HOME/.cache/mise"
    export MISE_TRUSTED_CONFIG_PATHS="$SMOKE_ROOT"
    export MISE_YES=1 MISE_EXPERIMENTAL=1
    export PATH="$(dirname "$MISE_BIN"):$PATH"
    mkdir -p "$MISE_CONFIG_DIR" "$MISE_DATA_DIR/plugins" "$MISE_STATE_DIR" "$MISE_CACHE_DIR"
    ln -sf "$REPO/test/data/plugins/dummy" "$MISE_DATA_DIR/plugins/dummy"
    ln -sf "$REPO/test/data/plugins/needs-dummy" "$MISE_DATA_DIR/plugins/needs-dummy"
    printf '[tools]\ndummy = { version = "1", auto_update = true }\n' > "$MISE_CONFIG_DIR/config.toml"
    "$MISE_BIN" install dummy@1.0.0 >/dev/null 2>&1
    out="$("$MISE_BIN" x -- dummy 2>&1)"
    echo "validation-setup: smoke launch output: $out"
    case "$out" in
        *"This is Dummy "*) : ;;  # binary + plugin wiring works end to end
        *) echo "ERROR: dummy did not run under mise x; wiring is broken" >&2; exit 1 ;;
    esac
)
rm -rf "$SMOKE_ROOT"

# Step 4: Build the clock shim test_harness.py uses for scenarios where a check
# interval must have passed, and prove it moves the wall clock.
CLOCK_LIB="${TMPDIR:-/tmp}/mise_story_clock_ahead.so"
CLOCK_SRC=/tests/validate/clock_ahead.c
[[ -f "$CLOCK_SRC" ]] || CLOCK_SRC="$(dirname "$0")/clock_ahead.c"
cc -shared -fPIC -O2 -o "$CLOCK_LIB.$$" "$CLOCK_SRC" -ldl
mv -f "$CLOCK_LIB.$$" "$CLOCK_LIB"
real_now="$(date +%s)"
ahead_now="$(LD_PRELOAD="$CLOCK_LIB" CLOCK_AHEAD_SEC=10800 date +%s)"
if (( ahead_now - real_now < 10790 )); then
    echo "ERROR: clock shim did not move the wall clock ($real_now vs $ahead_now)" >&2
    exit 1
fi
echo "validation-setup: clock shim ok ($CLOCK_LIB)"

echo "validation-setup: done."
