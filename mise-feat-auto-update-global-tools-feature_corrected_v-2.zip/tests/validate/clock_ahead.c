/* LD_PRELOAD shim: processes see the wall clock CLOCK_AHEAD_SEC seconds ahead.
 *
 * Lets a scenario act as if a check interval has passed without waiting for
 * it. Only the wall clock moves. The monotonic clock and file timestamps the
 * kernel records stay real, so anything written earlier simply looks older.
 */
#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>

static long ahead(void) {
    const char *s = getenv("CLOCK_AHEAD_SEC");
    return s ? atol(s) : 0;
}

int clock_gettime(clockid_t id, struct timespec *ts) {
    static int (*real)(clockid_t, struct timespec *);
    if (!real) real = (int (*)(clockid_t, struct timespec *))dlsym(RTLD_NEXT, "clock_gettime");
    int rc = real(id, ts);
    if (rc == 0 && ts && (id == CLOCK_REALTIME || id == CLOCK_REALTIME_COARSE))
        ts->tv_sec += ahead();
    return rc;
}

int gettimeofday(struct timeval *tv, void *tz) {
    static int (*real)(struct timeval *, void *);
    if (!real) real = (int (*)(struct timeval *, void *))dlsym(RTLD_NEXT, "gettimeofday");
    int rc = real(tv, tz);
    if (rc == 0 && tv) tv->tv_sec += ahead();
    return rc;
}

time_t time(time_t *out) {
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    if (out) *out = ts.tv_sec;
    return ts.tv_sec;
}
