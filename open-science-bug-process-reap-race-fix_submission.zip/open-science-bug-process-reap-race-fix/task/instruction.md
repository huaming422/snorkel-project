## Task

we're getting intermittent reports that quitting the app, and letting it
install a pending update, sometimes claims the backend didn't shut down cleanly
and cancels the update, even though the backend processes clearly did stop. it's
flaky and seems to ride on timing and load, and we've only seen it on macOS and
Linux. this used to be rock solid. can you dig in and stop a genuinely clean
shutdown from being reported as degraded? just don't let the shutdown
confirmation wait around forever; it still needs to stay bounded so quit can't
hang.
