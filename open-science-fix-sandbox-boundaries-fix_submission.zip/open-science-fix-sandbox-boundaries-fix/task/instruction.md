## Task

the command sandbox in `@aipoch/notebook-network-sandbox` has stopped holding its boundaries. these rules keep untrusted notebook code from reading protected files, writing where it isn't allowed, and reaching network it was never meant to, so this is a confidentiality and integrity problem, not a cosmetic one.

when a command resolves a file path that passes through an intermediate directory symlink, the policy judges it against the wrong physical location: a protected path becomes reachable, and a permitted path gets wrongly refused.

on macOS, a file the policy marks off-limits can still be moved out from under its rule by renaming or replacing one of the directories above it.

the outbound HTTP gateway misbehaves two ways. the resource path and query it forwards upstream don't always match what the caller asked for. and when an upstream reply comes back malformed or cut short, it can surface that broken reply as a normal response, or leave the proxy process unstable, instead of failing the one request cleanly.

restore the intended boundaries at the layer responsible for them, without widening what files are reachable or dropping a denial that's currently correct.

this covers the macOS and generic POSIX behavior of this sandbox; the Windows path and the Linux kernel-namespace architecture aren't the subject here.
