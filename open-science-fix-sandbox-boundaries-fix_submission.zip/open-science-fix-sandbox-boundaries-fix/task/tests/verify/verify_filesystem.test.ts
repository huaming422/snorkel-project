import {
  mkdirSync,
  mkdtempSync,
  realpathSync,
  rmSync,
  symlinkSync,
  writeFileSync
} from 'node:fs'
import { tmpdir } from 'node:os'
import { join, sep } from 'node:path'
import { describe, expect, it } from 'vitest'

import {
  absolutePhysicalPath,
  hiddenByFilesystemLayout,
  normalizeFilesystemLayout
} from '../runtime/src/platform/filesystem-layout.js'
import { seatbeltProfile } from '../runtime/src/platform/macos-isolation.js'
import { ViolationLog } from '../runtime/src/gateway/violation-log.js'

// These run on Linux: the resolver, layout normalizer and seatbelt profile
// generator are all pure/filesystem helpers with no macOS host requirement.
// The darwin-only launch probe from the upstream suite is intentionally not
// mirrored here; the pure profile string carries the same observable effect.
const posixIt = it.skipIf(process.platform === 'win32')

describe('sandbox filesystem path resolution', () => {
  posixIt(
    'anchors a path to the physical target its links point at, not the lexical one',
    () => {
      const root = realpathSync(mkdtempSync(join(tmpdir(), 'os-physical-path-')))
      try {
        mkdirSync(join(root, 'real', 'deep'), { recursive: true })
        symlinkSync(join(root, 'real', 'deep'), join(root, 'alias'))
        writeFileSync(join(root, 'real', 'secret'), 'physical')
        writeFileSync(join(root, 'secret'), 'lexical')

        // A spelling that crosses the link and then walks `..` must resolve the
        // link first: the physical answer is <root>/real/secret, never the
        // lexical sibling <root>/secret.
        const spelling = `${root}${sep}alias${sep}..${sep}secret`
        expect(absolutePhysicalPath(spelling)).toBe(realpathSync.native(spelling))
        expect(absolutePhysicalPath(spelling)).toBe(join(root, 'real', 'secret'))
      } finally {
        rmSync(root, { recursive: true, force: true })
      }
    }
  )

  posixIt(
    'anchors a not-yet-existing leaf to its physical parent and rejects unsafe spellings',
    () => {
      const root = realpathSync(mkdtempSync(join(tmpdir(), 'os-missing-leaf-')))
      try {
        mkdirSync(join(root, 'real', 'deep'), { recursive: true })
        symlinkSync(join(root, 'real', 'deep'), join(root, 'alias'))
        writeFileSync(join(root, 'secret'), 'file')

        // A missing leaf behind a link anchors to the link's physical parent.
        const missing = `${root}${sep}alias${sep}..${sep}new${sep}leaf`
        expect(absolutePhysicalPath(missing)).toBe(
          join(realpathSync.native(`${root}${sep}alias${sep}..`), 'new', 'leaf')
        )
        expect(absolutePhysicalPath(missing)).toBe(join(root, 'real', 'new', 'leaf'))

        // A harmless `.` segment is accepted on a missing path.
        const missingDot = `${root}${sep}missing${sep}.${sep}leaf`
        expect(absolutePhysicalPath(missingDot)).toBe(join(root, 'missing', 'leaf'))
        expect(absolutePhysicalPath(`${root}${sep}missing${sep}.`)).toBe(join(root, 'missing'))

        // The resolved leaf propagates into normalized policy roots unchanged.
        expect(
          normalizeFilesystemLayout({
            readOnlyRoots: [],
            readWriteRoots: [missingDot],
            deniedReadRoots: [],
            deniedWriteRoots: []
          }).readWriteRoots
        ).toEqual([join(root, 'missing', 'leaf')])

        // `..` traversal through a missing parent must be rejected, not folded.
        expect(() =>
          absolutePhysicalPath(`${root}${sep}missing${sep}..${sep}leaf`)
        ).toThrow()

        // A file standing in for a directory ancestor is rejected.
        expect(() => absolutePhysicalPath(join(root, 'secret', 'leaf'))).toThrow()

        // A dangling link is not a safely-inferable missing leaf.
        symlinkSync(join(root, 'absent'), join(root, 'dangling'))
        expect(() => absolutePhysicalPath(join(root, 'dangling', 'leaf'))).toThrow()
        expect(() =>
          absolutePhysicalPath(`${root}${sep}dangling${sep}.${sep}leaf`)
        ).toThrow()
      } finally {
        rmSync(root, { recursive: true, force: true })
      }
    }
  )

  posixIt(
    'treats an unresolvable diagnostic path leniently and keeps recorded violations intact',
    () => {
      const root = realpathSync(mkdtempSync(join(tmpdir(), 'os-diagnostic-path-')))
      try {
        writeFileSync(join(root, 'file'), 'fixture')
        symlinkSync(join(root, 'absent'), join(root, 'dangling'))
        const layout = normalizeFilesystemLayout({
          privateRoot: root,
          readOnlyRoots: [],
          readWriteRoots: [],
          deniedReadRoots: [],
          deniedWriteRoots: []
        })
        const paths = [
          join(root, 'file', 'leaf'),
          join(root, 'dangling', 'leaf'),
          `${root}${sep}missing${sep}..${sep}leaf`
        ]
        const hidden = (path: string): boolean => hiddenByFilesystemLayout(layout, path)
        const log = new ViolationLog()
        for (const path of paths) {
          // The path genuinely cannot resolve...
          expect(() => absolutePhysicalPath(path)).toThrow()
          // ...but using it only to annotate a diagnostic must not throw or be
          // read as a sandbox denial.
          expect(hidden(path)).toBe(false)
          const stderr = `cat: '${path}': No such file or directory`
          expect(log.attach('plain', stderr, hidden)).toBe(stderr)
          log.record('recorded', 'deny network-outbound example.org:443 (not approved)')
          const annotated = log.attach('recorded', stderr, hidden)
          expect(annotated).toContain(stderr)
          expect(annotated).toContain('deny network-outbound example.org:443 (not approved)')
          expect(annotated).not.toContain('OPEN_SCIENCE_FILESYSTEM_ACCESS_BLOCKED')
        }
      } finally {
        rmSync(root, { recursive: true, force: true })
      }
    }
  )

  posixIt(
    'keeps the writable ancestors of a denied path in place while leaving sibling writes allowed',
    () => {
      const root = realpathSync(mkdtempSync(join(tmpdir(), 'os-deny-ancestor-')))
      try {
        mkdirSync(join(root, 'parent'))
        writeFileSync(join(root, 'parent', 'secret'), 'fixture')

        const profile = seatbeltProfile({
          command: 'true',
          shell: '/bin/sh',
          gatewayPort: 3128,
          gatewayCredentials: { username: 'fixture', password: 'fixture' },
          env: { PATH: '/usr/bin:/bin' },
          filesystem: {
            privateRoot: root,
            readOnlyRoots: [],
            readWriteRoots: [root],
            deniedReadRoots: [join(root, 'parent', 'secret')],
            deniedWriteRoots: []
          }
        })

        // Identify the writable ancestor of the denied path by its exact
        // quoted literal. Using the quoted form distinguishes a `(literal …)`
        // rule from the denied subtree's own `(subpath …/secret)` rule, which
        // the ancestor path is only a textual prefix of.
        const protectedAncestor = JSON.stringify(join(root, 'parent'))
        const sibling = JSON.stringify(join(root, 'parent', 'sibling'))
        const denyWrites = (line: string): boolean =>
          line.startsWith('(deny') &&
          (line.includes('file-write-unlink') ||
            line.includes('file-write-create') ||
            line.includes('file-write*'))

        // The observable effect: a write-denying rule covers the writable
        // ancestor so it cannot be relocated or replaced. Tolerate grouping
        // and order — accept the dedicated unlink/create guard or any
        // write-deny carrying that literal — rather than pinning one spelling.
        const ancestorGuards = profile
          .split('\n')
          .filter((line) => denyWrites(line) && line.includes(protectedAncestor))
        expect(ancestorGuards.length).toBeGreaterThan(0)

        // An ordinary sibling write target is NOT swept up by such a rule.
        const siblingGuards = profile
          .split('\n')
          .filter((line) => denyWrites(line) && line.includes(sibling))
        expect(siblingGuards).toEqual([])

        // The denied subtree itself stays denied for writes (boundary intact).
        expect(profile).toContain(
          `(deny file-write* (subpath ${JSON.stringify(join(root, 'parent', 'secret'))}))`
        )
      } finally {
        rmSync(root, { recursive: true, force: true })
      }
    }
  )
})
