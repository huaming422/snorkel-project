import { createServer, type Socket } from 'node:net'
import { request } from 'node:http'
import { afterEach, describe, expect, it } from 'vitest'

import { CommandGateway } from '../runtime/src/gateway/command-gateway.js'

// The gateway is driven through its public surface only: CommandGateway.open
// listens on a loopback port and we speak raw HTTP/SOCKS to it, exactly as the
// package's own gateway suite does. No internal proxy/forward helper is imported.

const credentials = { username: 'command-a', password: 'secret-a' }
const authorization = `Basic ${Buffer.from('command-a:secret-a').toString('base64')}`

const closeTasks: Array<() => Promise<void>> = []

afterEach(async () => {
  while (closeTasks.length) {
    const task = closeTasks.pop()
    try {
      await task?.()
    } catch {
      // best-effort teardown
    }
  }
})

const listen = async (
  onConnection: (socket: Socket) => void
): Promise<{ port: number; close: () => Promise<void> }> => {
  const server = createServer(onConnection)
  await new Promise<void>((resolve, reject) => {
    server.once('error', reject)
    server.listen(0, '127.0.0.1', resolve)
  })
  const address = server.address()
  if (!address || typeof address === 'string') throw new Error('Expected a TCP address.')
  const close = (): Promise<void> => new Promise((resolve) => server.close(() => resolve()))
  closeTasks.push(close)
  return { port: address.port, close }
}

const readBytes = (socket: Socket, count: number): Promise<Buffer> =>
  new Promise((resolve, reject) => {
    let buffered = Buffer.alloc(0)
    const receive = (chunk: Buffer): void => {
      buffered = Buffer.concat([buffered, chunk])
      if (buffered.length < count) return
      socket.removeListener('data', receive)
      const result = buffered.subarray(0, count)
      const remainder = buffered.subarray(count)
      if (remainder.length) socket.unshift(remainder)
      resolve(result)
    }
    socket.on('data', receive)
    socket.once('error', reject)
  })

const readHttpHeader = (socket: Socket): Promise<string> =>
  new Promise((resolve, reject) => {
    let buffered = Buffer.alloc(0)
    const receive = (chunk: Buffer): void => {
      buffered = Buffer.concat([buffered, chunk])
      const end = buffered.indexOf('\r\n\r\n')
      if (end < 0) return
      socket.removeListener('data', receive)
      const remainder = buffered.subarray(end + 4)
      if (remainder.length) socket.unshift(remainder)
      resolve(buffered.subarray(0, end + 4).toString('latin1'))
    }
    socket.on('data', receive)
    socket.once('error', reject)
  })

const exchange = (
  port: number,
  path: string,
  method = 'GET'
): Promise<{ status: number; body: string; complete: boolean }> =>
  new Promise((resolve, reject) => {
    const outgoing = request(
      {
        hostname: '127.0.0.1',
        port,
        path,
        method,
        agent: false,
        headers: { host: 'example.test', 'proxy-authorization': authorization }
      },
      (incoming) => {
        let body = ''
        incoming.setEncoding('utf8')
        incoming.on('data', (chunk: string) => {
          body += chunk
        })
        const finish = (): void =>
          resolve({ status: incoming.statusCode!, body, complete: incoming.complete })
        incoming.on('end', finish)
        incoming.on('error', finish)
      }
    )
    outgoing.on('error', reject)
    outgoing.setTimeout(3000, () => outgoing.destroy(new Error('Fixture request timed out')))
    outgoing.end()
  })

describe('gateway HTTP forwarding integrity', () => {
  it.each([false, true])(
    'preserves the exact requested path and query spelling with parent proxy %s',
    async (parent) => {
      const targets: string[] = []
      const origin = await listen((socket) =>
        socket.once('data', (data) => {
          targets.push(data.toString().split('\r\n')[0]!)
          socket.end('HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok')
        })
      )
      const gateway = await CommandGateway.open({
        credentials,
        decide: async () => ({ allowed: true, address: '127.0.0.1' }),
        ...(parent ? { parentProxy: { http: `http://127.0.0.1:${origin.port}` } } : {})
      })
      closeTasks.push(() => gateway.close())
      for (const path of ['/a/../b', '/a/%2e%2e/b', '//a/b', '/a?', '/a?x=%2F', '/a%2Fb']) {
        expect(
          (await exchange(gateway.port, `http://example.test:${origin.port}${path}`)).body
        ).toBe('ok')
        // The upstream request line must carry the raw spelling verbatim,
        // never a URL-normalized rewrite, independent of the parent-proxy route.
        expect(targets.at(-1)).toBe(
          `GET ${parent ? `http://127.0.0.1:${origin.port}` : ''}${path} HTTP/1.1`
        )
      }
    }
  )

  it.each([false, true])(
    'owns upstream response errors and preserves fully-received bodies with parent proxy %s',
    async (parent) => {
      let reply = ''
      const origin = await listen((socket) => socket.once('data', () => socket.end(reply)))
      const gateway = await CommandGateway.open({
        credentials,
        decide: async () => ({ allowed: true, address: '127.0.0.1' }),
        ...(parent ? { parentProxy: { http: `http://127.0.0.1:${origin.port}` } } : {})
      })
      closeTasks.push(() => gateway.close())
      const path = `http://example.test:${origin.port}/`

      // An invalid status line yields a 502 before headers, with no upstream
      // body leaked downstream.
      for (const status of ['099', '000']) {
        reply = `HTTP/1.1 ${status} Invalid\r\nContent-Length: 6\r\n\r\nsecret`
        const failed = await exchange(gateway.port, path)
        expect(failed.status).toBe(502)
        expect(failed.body).not.toContain('secret')
      }

      // A fully-received body is preserved even when trailing bytes are rejected
      // by the parser (declared length 3, extra 'def' discarded).
      reply = 'HTTP/1.1 200 OK\r\nContent-Length: 3\r\n\r\nabcdef'
      expect(await exchange(gateway.port, path)).toEqual({
        status: 200,
        body: 'abc',
        complete: true
      })

      // A truncated response is terminated and marked incomplete, with no
      // diagnostic text appended to the already-started body.
      reply = 'HTTP/1.1 200 OK\r\nContent-Length: 9\r\n\r\nabc'
      expect(await exchange(gateway.port, path)).toEqual({
        status: 200,
        body: 'abc',
        complete: false
      })

      // A clean response still flows end to end.
      reply = 'HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nok'
      expect(await exchange(gateway.port, path)).toEqual({
        status: 200,
        body: 'ok',
        complete: true
      })
    }
  )

  it(
    'completes a separate SOCKS handshake per destination and closes each tunnel without pooling',
    async () => {
      const seen = [0, 1].map(() =>
        Promise.withResolvers<{ address: string; header: string }>()
      )
      const closed = [0, 1].map(() => Promise.withResolvers<void>())
      let connections = 0
      const parent = await listen((socket) => {
        const index = connections++
        socket.once('close', () => closed[index]!.resolve())
        void (async () => {
          await readBytes(socket, 3)
          socket.write(Buffer.from([5, 0]))
          const destination = await readBytes(socket, 10)
          socket.write(Buffer.from([5, 0, 0, 1, 127, 0, 0, 1, 0, 80]))
          seen[index]!.resolve({
            address: [...destination.subarray(4, 8)].join('.'),
            header: await readHttpHeader(socket)
          })
          // Offer keep-alive so accidental pooling of the tunnel would show up
          // as a reused connection on the second destination.
          socket.write(
            `HTTP/1.1 200 OK\r\nContent-Length: 1\r\nConnection: keep-alive\r\n\r\n${index}`
          )
        })().catch(seen[index]!.reject)
      })
      const gateway = await CommandGateway.open({
        credentials,
        parentProxy: { http: `socks5://127.0.0.1:${parent.port}` },
        decide: async (host) => ({
          allowed: true,
          address: host === 'first.test' ? '203.0.113.10' : '203.0.113.11'
        })
      })
      closeTasks.push(() => gateway.close())
      for (const [index, host] of ['first.test', 'second.test'].entries()) {
        expect((await exchange(gateway.port, `http://${host}/a/../b?`)).body).toBe(String(index))
        expect(await seen[index]!.promise).toEqual({
          address: `203.0.113.${10 + index}`,
          header: expect.stringContaining('GET /a/../b? HTTP/1.1')
        })
        // Each tunnel closes before the next destination is dialed.
        await closed[index]!.promise
      }
      expect(connections).toBe(2)
    }
  )
})
