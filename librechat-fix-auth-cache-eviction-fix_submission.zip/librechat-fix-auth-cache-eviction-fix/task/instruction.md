## Task

security flagged this one and I want it chased down. when an operator resets a user's password, or a user resets their own through account recovery, the reset comes back as success, but for a few seconds afterward an OpenID access token issued before the reset still gets accepted. operators treat a confirmed reset as "old access is revoked right now," so that window is a real hole.

it only shows up with the authenticated-user cache turned on, and it's worst when that cache's backend is unhealthy (think a flaky Redis) rather than a clean one. flip the cache off and the problem disappears entirely, which points at the cache rather than the token-validation path. the credential-change check itself looks correct, so dig into what a confirmed reset does to the cached authentication state, and what it fails to do, then fix it so a reset that reports success can't leave stale state behind that keeps authorizing.

keep the change on the authenticated-user auth path: don't change how unrelated cache namespaces behave, and don't disturb other users' cached state.
