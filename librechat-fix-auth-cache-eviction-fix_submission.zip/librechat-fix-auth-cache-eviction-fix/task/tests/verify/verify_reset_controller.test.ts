// @ts-nocheck
//
// Behavioural verifier — the password-reset controller's revoke-then-settle
// sequencing, exercised through the auth layer's own pre-existing controller
// factory.
//
// Placement: copied into packages/api/src/auth at grade time so it runs under
// the api package's jest config and resolves the controller factory by the same
// relative path the repo's sibling specs use (`./passwordReset`). The factory is
// a stable public export of the auth layer; the reset flow is wired through it.
//
// Neither test names any symbol the fix invents. The controller test observes
// the settle step through a Proxy over the controller's dependency object: any
// dependency name the submission introduces is captured and its call order
// recorded, so the revoke-before-settle sequencing and the "response waits for
// the settle step" invariant are asserted without knowing what the step is
// called.

import { createResetPasswordController } from './passwordReset';

/** A minimal Express-style response double whose status/json are chainable spies. */
function makeResponse() {
  const res: { status: jest.Mock; json: jest.Mock } = {
    status: jest.fn(() => res),
    json: jest.fn(() => res),
  };
  return res;
}

const flushAsync = async () => {
  for (let i = 0; i < 5; i++) {
    await new Promise((resolve) => setImmediate(resolve));
  }
};

describe('password-reset controller sequencing', () => {
  // Criterion: reset_revokes_before_settle (fail_to_pass).
  // A confirmed reset must revoke sessions and passkeys and then, before it
  // responds success, wait on the step that settles cached auth state — so no
  // stale cached document can keep authorizing once the caller sees success.
  // The settle step is injected through the controller's dependency object; a
  // Proxy captures whatever name the submission gives it. We assert (1) the
  // response is not sent while that step is still pending, and (2) both
  // revocations were invoked before it.
  test('the controller revokes sessions and passkeys before awaiting the settle step, and defers its response until the step resolves', async () => {
    const userId = 'user-reset-c6';

    let releaseSettle: () => void = () => undefined;
    const settlePending = new Promise<void>((resolve) => {
      releaseSettle = resolve;
    });

    const known: Record<string, jest.Mock> = {
      resetPassword: jest.fn(async () => ({ message: 'password reset' })),
      deleteAllUserSessions: jest.fn(async () => ({ deletedCount: 1 })),
      deletePasskeysByUser: jest.fn(async () => ({ deletedCount: 0 })),
    };

    // Any dependency the controller reads that is not one of the known three is
    // treated as a submission-introduced collaborator; the first time it is read
    // we install a recording spy whose promise stays pending until released, so
    // we can see whether the response waits on it.
    const addedSpies = new Map<string, jest.Mock>();
    const deps = new Proxy(known, {
      get(target, prop: string | symbol) {
        if (typeof prop !== 'string') {
          return undefined;
        }
        if (prop in target) {
          return target[prop];
        }
        // Keep the dependency object from being mistaken for a thenable.
        if (prop === 'then' || prop === 'catch' || prop === 'finally') {
          return undefined;
        }
        if (!addedSpies.has(prop)) {
          addedSpies.set(
            prop,
            jest.fn(async () => {
              await settlePending;
            }),
          );
        }
        return addedSpies.get(prop);
      },
    });

    const controller = createResetPasswordController(deps);
    const req = { body: { userId, token: 'reset-token', password: 'new-password' } };
    const res = makeResponse();

    const pending = controller(req, res);
    await flushAsync();

    // The settle step is still pending, so the success response must not be sent.
    expect(res.status).not.toHaveBeenCalled();

    releaseSettle();
    await pending;

    // The reset reported success only after the settle step resolved.
    expect(res.status).toHaveBeenCalledWith(200);

    // At least one submission-introduced collaborator was awaited — the settle
    // step the response blocked on. Its name is not assumed; whatever the
    // submission called it, the response above did not resolve until it did. If a
    // fix injected more than one new collaborator, the settle step is the latest
    // one to run (the response waited on it), which is what the ordering below
    // must sit after.
    const invokedAdded = [...addedSpies.values()].filter((spy) => spy.mock.calls.length > 0);
    expect(invokedAdded.length).toBeGreaterThanOrEqual(1);
    const latestAddedOrder = Math.max(
      ...invokedAdded.map((spy) => spy.mock.invocationCallOrder[0]),
    );

    // Both revocations ran before the settle step was awaited.
    expect(known.deleteAllUserSessions).toHaveBeenCalled();
    expect(known.deletePasskeysByUser).toHaveBeenCalled();
    expect(known.deleteAllUserSessions.mock.invocationCallOrder[0]).toBeLessThan(latestAddedOrder);
    expect(known.deletePasskeysByUser.mock.invocationCallOrder[0]).toBeLessThan(latestAddedOrder);
  });

  // Criterion: reset_failure_skips_settle (fail_to_pass companion to the above).
  // When the reset itself fails, the controller returns the failure and performs
  // no revocations and no settle wait. This holds on the unfixed controller too
  // (it has no settle step), so it never runs the pending-promise path; it guards
  // against a fix that waits unconditionally.
  test('a failed reset returns without revoking or awaiting the settle step', async () => {
    const userId = 'user-reset-fail';

    const known: Record<string, jest.Mock> = {
      resetPassword: jest.fn(async () => new Error('invalid or expired token')),
      deleteAllUserSessions: jest.fn(async () => ({ deletedCount: 0 })),
      deletePasskeysByUser: jest.fn(async () => ({ deletedCount: 0 })),
    };
    const addedSpies = new Map<string, jest.Mock>();
    const deps = new Proxy(known, {
      get(target, prop: string | symbol) {
        if (typeof prop !== 'string') {
          return undefined;
        }
        if (prop in target) {
          return target[prop];
        }
        if (prop === 'then' || prop === 'catch' || prop === 'finally') {
          return undefined;
        }
        if (!addedSpies.has(prop)) {
          addedSpies.set(prop, jest.fn(async () => undefined));
        }
        return addedSpies.get(prop);
      },
    });

    const controller = createResetPasswordController(deps);
    const res = makeResponse();
    await controller({ body: { userId, token: 'bad', password: 'x' } }, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(known.deleteAllUserSessions).not.toHaveBeenCalled();
    expect(known.deletePasskeysByUser).not.toHaveBeenCalled();
    const invokedAdded = [...addedSpies.values()].filter((spy) => spy.mock.calls.length > 0);
    expect(invokedAdded).toHaveLength(0);
  });
});
