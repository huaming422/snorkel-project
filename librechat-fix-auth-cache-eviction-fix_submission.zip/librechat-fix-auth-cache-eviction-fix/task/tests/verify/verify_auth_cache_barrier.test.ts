// @ts-nocheck
//
// Behavioural verifier — authenticated-user document cache eviction and the
// post-reset settle barrier, exercised through the data-schemas user-method
// factory.
//
// Placement: copied into packages/data-schemas/src/methods at grade time so it
// runs under that package's jest config (babel TS transform, `~/` alias →
// data-schemas src) and can import the user-method factory by its relative
// source path. That factory is the stable seam the whole app builds its user
// methods through; `getCache` is its documented cache-injection point, through
// which a degraded backend is simulated.
//
// The settle step a correct fix adds is a NEW method on the factory's return
// object. This file never names it: it locates it by set-difference against the
// factory's pre-change method surface, so a submission that chooses a different
// name still resolves. Its effect is asserted through the injected cache store:
// after the step runs, a document cached before the reset can no longer be
// served — whether the step deleted it or waited out its lifetime is not pinned.
// When the store is degraded so the step cannot confirm the document is gone,
// the step blocks until the cache's own lifetime has elapsed; this is observed
// by wall-clock, so a poll-until-gone loop and a single fixed sleep both read as
// "waited" and no strategy or exact duration is pinned.

import mongoose from 'mongoose';
import { MongoMemoryServer } from 'mongodb-memory-server';
import { AUTH_USER_DOC_BY_ID_PREFIX, CacheKeys } from 'librechat-data-provider';
import type * as t from '~/types';
import { createUserMethods } from './user';
import userSchema from '~/schema/user';
import balanceSchema from '~/schema/balance';

// This file stays within the data-schemas package and its declared dependencies
// (mongoose, mongodb-memory-server, librechat-data-provider). It drives the
// user-method factory directly and observes the configured cache store it is
// given, so the settle step's effect is asserted as cache state — a stale
// document is or is not still serve-able — rather than by importing a
// higher-layer sign-in helper. The reverse-index key prefix is the pre-existing
// contract both the cache writer and the eviction path key their entries on.

/**
 * A minimal in-process cache store with real time-based expiry, standing in for
 * the configured auth-user cache. `set(key, value, ttlMs)` records an expiry so
 * `get` returns undefined once the entry's lifetime has elapsed in wall-clock
 * time — the same observable contract the sign-in cache relies on. No external
 * cache dependency is needed, so this stays within the package's own deps.
 */
function makeTtlStore() {
  const entries = new Map<string, { value: unknown; expiresAt: number }>();
  return {
    entries,
    async get(key: string) {
      const entry = entries.get(key);
      if (!entry) {
        return undefined;
      }
      if (Date.now() > entry.expiresAt) {
        entries.delete(key);
        return undefined;
      }
      return entry.value;
    },
    async set(key: string, value: unknown, ttlMs?: number) {
      entries.set(key, { value, expiresAt: Date.now() + (ttlMs ?? 60_000) });
      return true;
    },
    async delete(key: string) {
      return entries.delete(key);
    },
  };
}

// The user-method factory's return keys before this change — a stable fact of
// the repo's pre-existing surface. Any function-valued key outside this set is a
// method the submission added; the post-revocation settle step is the one a
// correct fix introduces, so resolving "the single added method" finds it
// without depending on whatever name the submission gave it.
const PRE_EXISTING_USER_METHOD_NAMES = new Set<string>([
  'findUser',
  'findUsers',
  'findOwnerContactUsers',
  'countUsers',
  'createUser',
  'updateUser',
  'claimSamlIdentity',
  'acceptTerms',
  'searchUsers',
  'getUserById',
  'generateToken',
  'beginAgentTriggerUserDeletion',
  'recoverStaleAgentTriggerUserDeletion',
  'cancelAgentTriggerUserDeletion',
  'isAgentTriggerPrincipalActive',
  'fenceSubagentAdmission',
  'renewSubagentAdmission',
  'releaseSubagentAdmission',
  'isSubagentOwnerAdmissible',
  'deleteUserById',
  'updateUserPlugins',
  'toggleUserMemories',
  'updateUserStatefulCodeEnvironment',
]);

/**
 * Locate the single method the submission added to the factory. The reset flows
 * (web controller + CLI) await exactly one post-revocation settle step, so a
 * correct fix adds exactly one new callable here; we resolve it without naming
 * it. Returns the function, or undefined when the submission added none or more
 * than one (which the caller turns into a failure rather than a wrong guess).
 */
function resolveSettleBarrier(
  methods: Record<string, unknown>,
): ((userId: string) => Promise<unknown>) | undefined {
  const added = Object.keys(methods).filter(
    (key) => typeof methods[key] === 'function' && !PRE_EXISTING_USER_METHOD_NAMES.has(key),
  );
  if (added.length !== 1) {
    return undefined;
  }
  return methods[added[0]] as (userId: string) => Promise<unknown>;
}

const INDEXED_KEYS = ['auth-cache-key-a', 'auth-cache-key-b'];

/**
 * A cache store standing in for a Redis-backed one. When `indexRead` is set its
 * reverse-index GET throws the way a throwing store surfaces a failed read
 * instead of swallowing it; otherwise GET returns the reverse-index key list.
 * Deletes succeed — the degraded modes this file exercises are driven through
 * the index read or through a store that offers no delete at all.
 */
function makeFailingCache(failing: { indexRead?: boolean } = {}) {
  return {
    get: jest.fn(async () => {
      if (failing.indexRead) {
        throw new Error('WRONGTYPE Operation against a key holding the wrong kind of value');
      }
      return [...INDEXED_KEYS];
    }),
    set: jest.fn().mockResolvedValue(true),
    delete: jest.fn().mockResolvedValue(true),
  };
}

// The real auth-user cache lifetime is a stable repo fact (five seconds). A
// settle step that must wait out the window blocks for at least that long; one
// that has nothing to wait for returns effectively immediately. These two
// thresholds sit far inside that gap so the "waited vs. returned at once"
// decision is robust to scheduling jitter without pinning an exact duration or
// a wait strategy.
const WAIT_THRESHOLD_MS = 2000;
const PROMPT_THRESHOLD_MS = 1500;

// A cached document's modelled lifetime for the headline test, set below the
// real ~5s cache lifetime. A settle step that clears the stale document by
// waiting out the window (rather than deleting it) blocks for at least the real
// lifetime, which outlasts this, so the document is gone once the step returns;
// a step that deletes it clears it immediately; a step that does neither returns
// before this elapses and leaves the document readable. So the one assertion
// admits either mechanism and still rejects a do-nothing step.
const MODELLED_DOC_LIFETIME_MS = 3000;

/** Run an async thunk and report how long it took, in wall-clock milliseconds. */
async function timed(fn: () => Promise<unknown>): Promise<number> {
  const start = Date.now();
  await fn();
  return Date.now() - start;
}

let mongoServer: MongoMemoryServer;
let User: mongoose.Model<t.IUser>;

const ORIGINAL_CACHE_MODE = process.env.AUTH_USER_CACHE_MODE;

function enableAuthUserDocCache() {
  process.env.AUTH_USER_CACHE_MODE = 'on';
}

function restoreCacheMode() {
  if (ORIGINAL_CACHE_MODE === undefined) {
    delete process.env.AUTH_USER_CACHE_MODE;
  } else {
    process.env.AUTH_USER_CACHE_MODE = ORIGINAL_CACHE_MODE;
  }
}

beforeAll(async () => {
  mongoServer = await MongoMemoryServer.create();
  await mongoose.connect(mongoServer.getUri());
  User = mongoose.models.User || mongoose.model<t.IUser>('User', userSchema);
  mongoose.models.Balance || mongoose.model('Balance', balanceSchema);
});

afterAll(async () => {
  await mongoose.disconnect();
  await mongoServer.stop();
});

beforeEach(async () => {
  restoreCacheMode();
  await mongoose.connection.dropDatabase();
});

afterEach(() => {
  restoreCacheMode();
});

describe('auth-user-document eviction and the post-reset settle barrier', () => {
  // Criterion: stale_cached_doc_not_serveable_after_reset (fail_to_pass).
  // The headline. A user has a cached auth document from before a reset; once the
  // settle step the reset awaits has run, that pre-reset document can no longer
  // be served from the cache. Here the store is healthy, so this is the baseline
  // guarantee: a confirmed reset leaves no pre-reset cached document behind.
  // Fails on the pre-change code because there is no settle step to resolve (no
  // method is added to the factory), and a submission that adds a do-nothing
  // method fails too, because the seeded document is still readable afterwards.
  // How the step clears it — deleting it, or waiting out its lifetime — is not
  // pinned; only that it is gone once the step returns.
  test('a cached document from before the reset can no longer be served once the settle step runs', async () => {
    enableAuthUserDocCache();

    const store = makeTtlStore();
    const methods = createUserMethods(mongoose, {
      getCache: (key: string) => (key === CacheKeys.AUTH_USER_DOC ? store : undefined),
    });
    const barrier = resolveSettleBarrier(methods);
    expect(typeof barrier).toBe('function');

    // Seed a cached auth document for the user and the reverse index that names
    // it (the prefix the cache writer and the eviction path both key on), the
    // state left behind when the user signed in before the reset. The index
    // outlives the window so an eviction path can read it; the document is
    // modelled below the real cache lifetime so a wait-out-the-window path clears
    // it by expiry.
    const userId = 'user-c1';
    const cacheKey = 'auth-user-doc:cached-before-reset';
    await store.set(`${AUTH_USER_DOC_BY_ID_PREFIX}:${userId}`, [cacheKey], 60_000);
    await store.set(cacheKey, { _id: userId, email: 'oidc@example.com' }, MODELLED_DOC_LIFETIME_MS);

    // Pre-condition: the stale document is readable right now.
    expect(await store.get(cacheKey)).toBeDefined();

    // The settle step the reset awaits.
    await barrier!(userId);

    // Once it returns, no pre-reset document may be served.
    expect(await store.get(cacheKey)).toBeUndefined();
  }, 20_000);

  // Criterion: reset_barrier_waits_when_eviction_incomplete (fail_to_pass).
  // When the settle step cannot confirm the cached document is gone, it must not
  // let the reset confirm until the document could no longer be served. Driven
  // through two degraded modes in which a cached document can still be served:
  // the reverse index cannot be read (its keys are unknown), and a store that
  // offers no delete at all (nothing can be removed). In both, once the step
  // returns the window has closed, so it blocks for the cache lifetime. Observed
  // by wall-clock, so a poll-until-gone loop and a single fixed sleep both pass;
  // no wait strategy or duration is pinned. (That the step does NOT stall a
  // healthy reset is covered by the best-effort-update p2p test below, which
  // returns promptly against a degraded cache.)
  test('the barrier does not let the reset confirm until a serve-able document could no longer be read', async () => {
    enableAuthUserDocCache();

    const build = (cache: unknown) => {
      const methods = createUserMethods(mongoose, { getCache: () => cache });
      const barrier = resolveSettleBarrier(methods);
      expect(typeof barrier).toBe('function');
      return barrier!;
    };

    // (a) reverse-index read fails -> keys unknown -> may still be served -> wait
    {
      const elapsed = await timed(() => build(makeFailingCache({ indexRead: true }))('user-1'));
      expect(elapsed).toBeGreaterThanOrEqual(WAIT_THRESHOLD_MS);
    }

    // (b) the store can read but offers no delete at all -> cannot remove -> wait
    {
      const elapsed = await timed(() => build({ get: jest.fn(), set: jest.fn() })('user-1'));
      expect(elapsed).toBeGreaterThanOrEqual(WAIT_THRESHOLD_MS);
    }
  }, 30_000);

  // Criterion: eviction_preserves_other_users (pass_to_pass).
  // Evicting one user's cached documents never touches another user's entries.
  // Routed through updateUser, which triggers invalidation on both the fixed and
  // unfixed code, so it must hold either way.
  test("evicting one user never deletes another user's cached entries", async () => {
    enableAuthUserDocCache();
    const otherIndexKey = `${AUTH_USER_DOC_BY_ID_PREFIX}:other-user`;
    const cache = {
      get: jest.fn(async (key: string) => {
        if (key.endsWith(':other-user')) {
          return ['other-doc'];
        }
        return [...INDEXED_KEYS];
      }),
      set: jest.fn().mockResolvedValue(true),
      delete: jest.fn().mockResolvedValue(true),
    };
    const methods = createUserMethods(mongoose, { getCache: () => cache });

    const user = await User.create({ name: 'Target', email: 'target@example.com', provider: 'openid' });
    await methods.updateUser(user._id.toString(), { credentialsChangedAt: new Date() });

    const deleted = cache.delete.mock.calls.map((call: unknown[]) => call[0]);
    expect(deleted).not.toContain(otherIndexKey);
    expect(deleted).not.toContain('other-doc');
  });

  // Criterion: update_user_stays_best_effort (pass_to_pass).
  // An ordinary update never waits on eviction and never fails because the cache
  // is degraded. Holds on both the fixed and unfixed code.
  test('an ordinary update neither waits nor fails when the cache is degraded', async () => {
    enableAuthUserDocCache();
    const methods = createUserMethods(mongoose, {
      getCache: () => makeFailingCache({ indexRead: true }),
    });

    const user = await User.create({ name: 'Original', email: 'best-effort@example.com', provider: 'openid' });
    let updated: Awaited<ReturnType<typeof methods.updateUser>>;
    const elapsed = await timed(async () => {
      updated = await methods.updateUser(user._id.toString(), { name: 'Renamed' });
    });

    // The update applied and did not block on cache eviction even though the
    // backend is degraded — ordinary writes stay best-effort, never a barrier.
    expect(updated?.name).toBe('Renamed');
    expect(elapsed).toBeLessThan(PROMPT_THRESHOLD_MS);
  }, 20_000);
});
