## Task

People keep reporting that their scheduled email reports for dashboards and charts seem to "disappear." When the `ALERT_REPORTS` flag is enabled, the three-dot menu displays "Set up an email report" if no report exists, and provides options to toggle, edit, or delete it once one has been created.

If a report already exists, reloading the dashboard or chart page resets the menu back to "Set up an email report", and the exact same thing happens right after toggling the report to active. Even though the request that loads the report returns the correct data, the menu still acts like nothing is there. Also, if you reload the page and then delete the report, it stays stuck in the menu instead of clearing.

A couple of other issues in the same area seem related. If a report is set to Excel or CSV and you reload the page, editing and saving it without changing the format will cause the format to revert to the default. Additionally, when viewing a chart inside a dashboard, creating a report for that chart gets rejected by the server, and editing it opens the dashboard report instead of the chart report.

Get existing reports recognised again and make all of these work. There's no network access, so stick to the packages that are already installed.
