"""Check that the report schedule list response returns each report's format.

The dashboard and chart report menu loads an existing schedule from the report
list endpoint, so the columns that endpoint returns decide what the menu knows
about the schedule after a page reload. The format has to be one of them, and
the columns the menu already relies on (id, name, active, schedule, creation
method and the dashboard or chart id) have to stay.

This is a source check. Calling the list endpoint would need the whole
application, a database and its config, which the verifier runtime does not
start, so the check reads the declared list columns from the API module
instead. It understands the usual ways of declaring them: a list, tuple or set
literal, a concatenation with another named list, an extra ``+=`` line, and
``.append()`` or ``.extend()`` calls, either in the class body or on the class
after it is defined. Only real column entries count; a string that merely
appears somewhere inside an expression (for example in a filter) does not.
"""

from __future__ import annotations

import ast
from pathlib import Path

REPO = Path("/repo/superset")
API_SOURCE = REPO / "superset" / "reports" / "api.py"

CLASS_NAME = "ReportScheduleRestApi"
ATTR_NAME = "list_columns"
FORMAT_COLUMN = "report_format"

# Columns the report menu already reads from the list response. A change that
# adds the format must keep these.
EXISTING_COLUMNS = (
    "id",
    "name",
    "active",
    "crontab",
    "creation_method",
    "dashboard_id",
    "chart_id",
)

_MAX_DEPTH = 10


def _named_values(tree: ast.Module, class_def: ast.ClassDef) -> dict[str, ast.expr]:
    """Simple ``NAME = value`` assignments at module level and in the class body,
    so a concatenation such as ``BASE + [...]`` can be followed."""
    values: dict[str, ast.expr] = {}
    for body in (tree.body, class_def.body):
        for stmt in body:
            if isinstance(stmt, ast.Assign):
                for target in stmt.targets:
                    if isinstance(target, ast.Name):
                        values[target.id] = stmt.value
            elif isinstance(stmt, ast.AnnAssign) and stmt.value is not None:
                if isinstance(stmt.target, ast.Name):
                    values[stmt.target.id] = stmt.value
    return values


def _entries(node: ast.AST, names: dict[str, ast.expr], depth: int = 0) -> list[str]:
    """Column names that ``node`` evaluates to, counting only real elements."""
    if depth > _MAX_DEPTH:
        return []
    if isinstance(node, (ast.List, ast.Tuple, ast.Set)):
        found: list[str] = []
        for element in node.elts:
            if isinstance(element, ast.Constant) and isinstance(element.value, str):
                found.append(element.value)
            elif isinstance(element, ast.Starred):
                found.extend(_entries(element.value, names, depth + 1))
        return found
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        return _entries(node.left, names, depth + 1) + _entries(
            node.right, names, depth + 1
        )
    if isinstance(node, ast.Name) and node.id in names:
        return _entries(names[node.id], names, depth + 1)
    if (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id in {"list", "tuple"}
        and len(node.args) == 1
    ):
        return _entries(node.args[0], names, depth + 1)
    return []


def _is_columns_target(node: ast.expr, in_class: bool) -> bool:
    """True for ``list_columns`` in the class body, or ``Class.list_columns``."""
    if in_class:
        return isinstance(node, ast.Name) and node.id == ATTR_NAME
    return (
        isinstance(node, ast.Attribute)
        and node.attr == ATTR_NAME
        and isinstance(node.value, ast.Name)
        and node.value.id == CLASS_NAME
    )


def _apply(stmt: ast.stmt, in_class: bool, names: dict[str, ast.expr], cols: list[str]) -> bool:
    """Apply one statement to the running column list. Returns True if it
    touched the list columns."""
    if isinstance(stmt, ast.Assign) and any(
        _is_columns_target(t, in_class) for t in stmt.targets
    ):
        cols[:] = _entries(stmt.value, names)
        return True
    if (
        isinstance(stmt, ast.AnnAssign)
        and stmt.value is not None
        and _is_columns_target(stmt.target, in_class)
    ):
        cols[:] = _entries(stmt.value, names)
        return True
    if (
        isinstance(stmt, ast.AugAssign)
        and isinstance(stmt.op, ast.Add)
        and _is_columns_target(stmt.target, in_class)
    ):
        cols.extend(_entries(stmt.value, names))
        return True
    if (
        isinstance(stmt, ast.Expr)
        and isinstance(stmt.value, ast.Call)
        and isinstance(stmt.value.func, ast.Attribute)
        and _is_columns_target(stmt.value.func.value, in_class)
        and stmt.value.func.attr in {"append", "extend"}
        and len(stmt.value.args) == 1
    ):
        arg = stmt.value.args[0]
        if stmt.value.func.attr == "append":
            if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                cols.append(arg.value)
        else:
            cols.extend(_entries(arg, names))
        return True
    return False


def _list_columns() -> list[str]:
    """The column names the report list endpoint is declared to return."""
    source = API_SOURCE.read_text(encoding="utf-8")
    tree = ast.parse(source, filename=str(API_SOURCE))

    class_def = next(
        (
            node
            for node in tree.body
            if isinstance(node, ast.ClassDef) and node.name == CLASS_NAME
        ),
        None,
    )
    assert class_def is not None, "The report schedule API could not be found."

    names = _named_values(tree, class_def)
    cols: list[str] = []
    found = False
    for stmt in class_def.body:
        found = _apply(stmt, True, names, cols) or found
    after_class = tree.body[tree.body.index(class_def) + 1 :]
    for stmt in after_class:
        found = _apply(stmt, False, names, cols) or found

    assert found, "The report list endpoint no longer declares which columns it returns."
    return cols


def test_list_response_includes_report_format() -> None:
    """The report list returns each report's format and keeps the columns the
    report menu already uses."""
    cols = _list_columns()

    missing = [c for c in EXISTING_COLUMNS if c not in cols]
    assert not missing, (
        f"The report list no longer returns columns the report menu relies on: "
        f"{missing}. Returned columns: {sorted(set(cols))}"
    )
    assert FORMAT_COLUMN in cols, (
        "The report list does not return the report's format, so a report "
        "loaded after a page reload loses it. Returned columns: "
        f"{sorted(set(cols))}"
    )
