/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
//
// Tests for the email report menu on dashboards and charts.
//
// Reports are loaded, created and deleted through the existing report actions
// (fetchUISpecificReport, subscribeReport, deleteActiveReport) dispatched on a
// real store, with fetch-mock standing in for the API. The checks look at what
// ends up in the store and what the modal sends, so it doesn't matter whether a
// fix reshapes the list rows in the action or in the reducer.
//
// The modal is driven through its existing props and the checks look at the
// request body it sends and the report it shows.
//
import fetchMock from 'fetch-mock';
import {
  render,
  screen,
  userEvent,
  waitFor,
  createStore,
} from 'spec/helpers/testing-library';
import reducerIndex from 'spec/helpers/reducerIndex';
import { FeatureFlag, VizType, isFeatureEnabled } from '@superset-ui/core';
import getBootstrapData from 'src/utils/getBootstrapData';
import { DEFAULT_COMMON_BOOTSTRAP_DATA } from 'src/constants';
import type { BootstrapData } from 'src/types/bootstrapTypes';
import {
  fetchUISpecificReport,
  subscribeReport,
  deleteActiveReport,
} from './actions';
import ReportModal from '.';

// ---------------------------------------------------------------------------
// Store suite: loading and deleting reports.
// ---------------------------------------------------------------------------

const REPORT_ENDPOINT = 'glob:*/api/v1/report*';
const DEFAULT_GET_ROUTE = 'report-get-default';

// A row shaped the way the report list endpoint returns it.
const listRow = (overrides: Record<string, unknown> = {}) => ({
  active: true,
  changed_on_delta_humanized: 'a day ago',
  chart_id: null,
  creation_method: 'dashboards',
  crontab: '0 12 * * 1',
  dashboard_id: null,
  description: '',
  id: 1,
  name: 'Weekly Report',
  timezone: 'UTC',
  type: 'Report',
  ...overrides,
});

const newStore = (reports: object = {}) =>
  createStore({ reports }, reducerIndex);

const reportsOf = (store: ReturnType<typeof newStore>) =>
  (store.getState() as any).reports;

// Load reports the way the report menu does, with the list endpoint returning
// `rows`.
const loadReports = async (
  store: ReturnType<typeof newStore>,
  rows: object[],
  params: {
    filterField: 'dashboard_id' | 'chart_id';
    creationMethod: 'dashboards' | 'charts';
    resourceId: number;
  },
) => {
  fetchMock.removeRoute(DEFAULT_GET_ROUTE);
  fetchMock.get(REPORT_ENDPOINT, { result: rows }, { name: 'report-list' });
  try {
    await store.dispatch(
      fetchUISpecificReport({ userId: 1, ...params }) as any,
    );
  } finally {
    fetchMock.removeRoute('report-list');
    fetchMock.get(REPORT_ENDPOINT, {}, { name: DEFAULT_GET_ROUTE });
  }
};

const deleteReport = async (
  store: ReturnType<typeof newStore>,
  report: Record<string, any>,
) => {
  fetchMock.delete(
    `glob:*/api/v1/report/${report.id}`,
    {},
    { name: 'report-delete' },
  );
  try {
    await store.dispatch(deleteActiveReport(report as any) as any);
  } finally {
    fetchMock.removeRoute('report-delete');
  }
};

test('a dashboard report loaded from the report list is stored for the dashboard', async () => {
  const store = newStore();
  await loadReports(
    store,
    [
      listRow({ id: 6, dashboard_id: 11, name: 'Other dashboard' }),
      listRow({ id: 5, dashboard_id: 10, active: false }),
    ],
    { filterField: 'dashboard_id', creationMethod: 'dashboards', resourceId: 10 },
  );

  expect(reportsOf(store).dashboards?.[10]).toMatchObject({
    id: 5,
    active: false,
  });
});

test('a chart report loaded from the report list is stored for the chart', async () => {
  const store = newStore();
  await loadReports(
    store,
    [
      listRow({ id: 8, chart_id: 43, creation_method: 'charts' }),
      listRow({ id: 7, chart_id: 42, creation_method: 'charts' }),
    ],
    { filterField: 'chart_id', creationMethod: 'charts', resourceId: 42 },
  );

  expect(reportsOf(store).charts?.[42]).toMatchObject({ id: 7 });
});

test('a dashboard report loaded from the report list can be deleted', async () => {
  const store = newStore();
  await loadReports(store, [listRow({ id: 5, dashboard_id: 10 })], {
    filterField: 'dashboard_id',
    creationMethod: 'dashboards',
    resourceId: 10,
  });
  const stored = reportsOf(store).dashboards?.[10];
  expect(stored).toBeDefined();

  await deleteReport(store, stored);

  expect(reportsOf(store).dashboards?.[10]).toBeUndefined();
});

test('a chart report loaded from the report list can be deleted', async () => {
  const store = newStore();
  await loadReports(
    store,
    [listRow({ id: 7, chart_id: 42, creation_method: 'charts' })],
    { filterField: 'chart_id', creationMethod: 'charts', resourceId: 42 },
  );
  const stored = reportsOf(store).charts?.[42];
  expect(stored).toBeDefined();

  await deleteReport(store, stored);

  expect(reportsOf(store).charts?.[42]).toBeUndefined();
});

test('reports created in this session can still be deleted', async () => {
  const store = newStore();
  fetchMock.post(
    'glob:*/api/v1/report/subscribe',
    {
      id: 5,
      result: { creation_method: 'dashboards', dashboard: 10, name: 'D' },
    },
    { name: 'subscribe-dashboard', repeat: 1 },
  );
  fetchMock.post(
    'glob:*/api/v1/report/subscribe',
    { id: 7, result: { creation_method: 'charts', chart: 42, name: 'C' } },
    { name: 'subscribe-chart', repeat: 1 },
  );
  try {
    await store.dispatch(subscribeReport({ dashboard: 10 } as any) as any);
    await store.dispatch(subscribeReport({ chart: 42 } as any) as any);
  } finally {
    fetchMock.removeRoute('subscribe-dashboard');
    fetchMock.removeRoute('subscribe-chart');
  }
  const dashboardReport = reportsOf(store).dashboards?.[10];
  const chartReport = reportsOf(store).charts?.[42];
  expect(dashboardReport).toBeDefined();
  expect(chartReport).toBeDefined();

  await deleteReport(store, dashboardReport);
  await deleteReport(store, chartReport);

  expect(reportsOf(store).dashboards?.[10]).toBeUndefined();
  expect(reportsOf(store).charts?.[42]).toBeUndefined();
});

test('deleting a report with no dashboard or chart id leaves other reports alone', async () => {
  const store = newStore({
    dashboards: { 10: { ...listRow({ id: 5, dashboard_id: 10 }), dashboard: 10 } },
  });

  await deleteReport(store, { id: 5, creation_method: 'dashboards' });

  expect(reportsOf(store).dashboards?.[10]).toMatchObject({ id: 5 });
});

// ---------------------------------------------------------------------------
// Component suite: the report modal on dashboards and charts.
// ---------------------------------------------------------------------------

jest.mock('src/utils/getBootstrapData', () => ({
  __esModule: true,
  default: jest.fn(() => ({
    common: {
      conf: {},
      feature_flags: {},
      user_subject_id: 99,
      user_subjects: [99],
    },
  })),
}));

jest.mock('@superset-ui/core', () => ({
  ...jest.requireActual('@superset-ui/core'),
  isFeatureEnabled: jest.fn(),
}));

const bootstrapData = (
  common: Partial<BootstrapData['common']> = {},
): BootstrapData => ({
  common: {
    ...DEFAULT_COMMON_BOOTSTRAP_DATA,
    ...common,
  },
});

const mockedGetBootstrapData = getBootstrapData as jest.MockedFunction<
  typeof getBootstrapData
>;
const mockedIsFeatureEnabled = isFeatureEnabled as jest.Mock;

fetchMock.get(REPORT_ENDPOINT, {}, { name: DEFAULT_GET_ROUTE });

// A failing assertion inside a test can skip that test's own route cleanup
// and leave a stale route in place, which then intercepts the next test's
// request under the wrong name. Clear every route after each test so one
// failure never bleeds into the next.
afterEach(() => {
  fetchMock.removeRoutes();
  fetchMock.get(REPORT_ENDPOINT, {}, { name: DEFAULT_GET_ROUTE });
});

const NOOP = () => {};

const defaultProps = {
  addDangerToast: NOOP,
  addSuccessToast: NOOP,
  addReport: NOOP,
  onHide: NOOP,
  onReportAdd: NOOP,
  show: true,
  userEmail: 'test@test.com',
  dashboardId: 1,
  creationMethod: 'dashboards',
  chart: {
    sliceFormData: {
      viz_type: VizType.Table,
    },
  },
};

beforeEach(() => {
  mockedGetBootstrapData.mockReturnValue(
    bootstrapData({
      user_subject_id: 99,
      user_subjects: [99],
    }),
  );
  mockedIsFeatureEnabled.mockImplementation(
    featureFlag => featureFlag === FeatureFlag.AlertReports,
  );
});

test('creating a chart report while a dashboard context is present sends only the chart id', async () => {
  // Explore opened from a dashboard passes a dashboardId alongside the chart;
  // a payload carrying both ids is rejected by the server. The save must send
  // the chart id alone.
  fetchMock.post(
    'glob:*/api/v1/report/subscribe',
    { id: 1, result: {} },
    { name: 'post-subscribe-chart' },
  );

  const chartFromDashboardProps = {
    ...defaultProps,
    dashboardId: 7,
    chart: { id: 119, sliceFormData: { viz_type: VizType.Line } },
    creationMethod: 'charts' as const,
  };
  render(<ReportModal {...chartFromDashboardProps} />, { useRedux: true });

  const addButton = screen.getByRole('button', { name: /add/i });
  await userEvent.click(addButton);

  await waitFor(() => {
    const postCalls = fetchMock.callHistory.calls('post-subscribe-chart');
    expect(postCalls).toHaveLength(1);
  });

  const postCalls = fetchMock.callHistory.calls('post-subscribe-chart');
  const body = JSON.parse(postCalls[0].options.body as string);
  expect(body.chart).toBe(119);
  expect(body.dashboard == null).toBe(true);

  fetchMock.removeRoute('post-subscribe-chart');
});

test('editing a chart report in a dashboard context resolves the chart schedule and saves to its id', async () => {
  // The store holds both a dashboard schedule and the chart's own schedule.
  // With a chart creation context, the modal must load the chart schedule
  // (not the dashboard one) and PUT to the chart schedule id with the chart
  // id alone.
  const dashboardReport = {
    id: 42,
    name: 'Existing Dashboard Report',
    creation_method: 'dashboards',
    crontab: '0 12 * * 1',
    dashboard_id: 7,
    chart_id: null,
    report_format: 'PNG',
    active: true,
    type: 'Report',
    timezone: 'America/New_York',
  };
  const chartReport = {
    ...dashboardReport,
    id: 77,
    name: 'Existing Chart Report',
    creation_method: 'charts',
    dashboard_id: null,
    chart_id: 119,
  };
  const store = createStore(
    {
      reports: {
        dashboards: { 7: dashboardReport },
        charts: { 119: chartReport },
      },
    },
    reducerIndex,
  );

  fetchMock.put(
    'glob:*/api/v1/report/77',
    { id: 77, result: {} },
    { name: 'put-report-77' },
  );

  const chartFromDashboardProps = {
    ...defaultProps,
    dashboardId: 7,
    chart: { id: 119, sliceFormData: { viz_type: VizType.Line } },
    creationMethod: 'charts' as const,
  };
  render(<ReportModal {...chartFromDashboardProps} />, {
    useRedux: true,
    store,
  });

  expect(screen.getByTestId('report-name-test')).toHaveDisplayValue(
    'Existing Chart Report',
  );

  const saveButton = screen.getByRole('button', { name: /save/i });
  await userEvent.click(saveButton);

  await waitFor(() => {
    const calls = fetchMock.callHistory.calls('put-report-77');
    expect(calls.length).toBeGreaterThan(0);
  });

  const calls = fetchMock.callHistory.calls('put-report-77');
  const body = JSON.parse(calls[calls.length - 1].options.body as string);
  expect(body.chart).toBe(119);
  expect(body.dashboard == null).toBe(true);

  fetchMock.removeRoute('put-report-77');
});

test('editing a chart report keeps its stored non-default delivery format on save', async () => {
  // A stored report whose format is XLSX (never the visualization default)
  // must keep that format through an unchanged edit-and-save.
  const fetchedReport = {
    active: true,
    chart_id: 96,
    creation_method: 'charts',
    crontab: '0 12 * * 1',
    dashboard_id: null,
    description: '',
    id: 44,
    name: 'Existing XLSX Report',
    report_format: 'XLSX',
    timezone: 'America/New_York',
    type: 'Report',
  };
  const store = createStore(
    {
      reports: {
        charts: { 96: fetchedReport },
      },
    },
    reducerIndex,
  );

  fetchMock.put(
    'glob:*/api/v1/report/44',
    { id: 44, result: {} },
    { name: 'put-report-44' },
  );

  const chartProps = {
    ...defaultProps,
    dashboardId: undefined,
    chart: { id: 96, sliceFormData: { viz_type: VizType.Line } },
    creationMethod: 'charts' as const,
  };
  render(<ReportModal {...chartProps} />, { useRedux: true, store });

  expect(screen.getByText('Edit email report')).toBeInTheDocument();
  expect(
    screen.getByRole('radio', { name: 'Formatted Excel attached in email' }),
  ).toBeChecked();

  const saveButton = screen.getByRole('button', { name: /save/i });
  await userEvent.click(saveButton);

  await waitFor(() => {
    const calls = fetchMock.callHistory.calls('put-report-44');
    expect(calls.length).toBeGreaterThan(0);
  });

  const calls = fetchMock.callHistory.calls('put-report-44');
  const body = JSON.parse(calls[calls.length - 1].options.body as string);
  expect(body.report_format).toBe('XLSX');

  fetchMock.removeRoute('put-report-44');
});

test('creating a report from a dashboard sends the dashboard id', async () => {
  fetchMock.post(
    'glob:*/api/v1/report/subscribe',
    { id: 2, result: {} },
    { name: 'post-subscribe-dashboard' },
  );

  render(<ReportModal {...defaultProps} />, { useRedux: true });

  await userEvent.click(screen.getByRole('button', { name: /add/i }));

  await waitFor(() => {
    expect(
      fetchMock.callHistory.calls('post-subscribe-dashboard'),
    ).toHaveLength(1);
  });

  const [call] = fetchMock.callHistory.calls('post-subscribe-dashboard');
  const body = JSON.parse(call.options.body as string);
  expect(body.dashboard).toBe(1);
  expect(body.chart == null).toBe(true);

  fetchMock.removeRoute('post-subscribe-dashboard');
});

test('editing a dashboard report loads the dashboard report and saves to its id', async () => {
  const dashboardReport = {
    id: 42,
    name: 'Existing Dashboard Report',
    creation_method: 'dashboards',
    crontab: '0 12 * * 1',
    dashboard_id: 1,
    chart_id: null,
    report_format: 'PNG',
    active: true,
    type: 'Report',
    timezone: 'America/New_York',
  };
  const store = createStore(
    { reports: { dashboards: { 1: dashboardReport } } },
    reducerIndex,
  );

  fetchMock.put(
    'glob:*/api/v1/report/42',
    { id: 42, result: {} },
    { name: 'put-report-42' },
  );

  render(<ReportModal {...defaultProps} />, { useRedux: true, store });

  expect(screen.getByTestId('report-name-test')).toHaveDisplayValue(
    'Existing Dashboard Report',
  );

  await userEvent.click(screen.getByRole('button', { name: /save/i }));

  await waitFor(() => {
    expect(fetchMock.callHistory.calls('put-report-42').length).toBeGreaterThan(
      0,
    );
  });

  const calls = fetchMock.callHistory.calls('put-report-42');
  const body = JSON.parse(calls[calls.length - 1].options.body as string);
  expect(body.dashboard).toBe(1);
  expect(body.chart == null).toBe(true);

  fetchMock.removeRoute('put-report-42');
});
