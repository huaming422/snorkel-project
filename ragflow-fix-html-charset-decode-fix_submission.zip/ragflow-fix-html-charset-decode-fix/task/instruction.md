## Task

a user imported an HTML document into the ingestion pipeline and got back garbage. the extracted text is full of `�` replacement characters and stray Latin gibberish instead of the actual content. the file is a Chinese balance sheet they saved off a finance site; open it in a browser and the Chinese reads perfectly, but once it goes through parsing the text comes out as mojibake.

English pages and anything already saved as UTF-8 come through clean. it's only the documents that aren't already UTF-8 that break.

figure out why these documents parse into garbage and fix it, so the text extracted from one reads back as the real content of the page. keep it scoped to this problem.
