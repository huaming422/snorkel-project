#!/usr/bin/env bash
# Verifier-time setup for ragflow-fix-html-charset-decode.
#
# The image bakes the full Go dependency closure at the base commit, plus the
# one module the oracle introduces (github.com/saintfish/chardet), into a warm
# GOMODCACHE, and prewarms the parser package's build cache. The agent phase
# runs offline (agent_offline = true), so everything needed to build and run
# the focused parser tests is already present. There is nothing to install here.
#
# Offline-first by contract: do not fetch anything. If a future verifier needs
# a package the image lacks, add it to image/Dockerfile's baked closure rather
# than installing it here.
set -euo pipefail
echo "[test-setup] no-op for ragflow-fix-html-charset-decode (deps baked at image build)"
