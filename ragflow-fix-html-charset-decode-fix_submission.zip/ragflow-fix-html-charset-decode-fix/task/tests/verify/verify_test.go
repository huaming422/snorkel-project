package parser

// Behavioral verifier for the HTML ingestion charset problem.
//
// Everything is exercised through the stable public seam
// NewHTMLParser().ParseWithResult(ctx, name, bytes) -> ParseResult; no
// helper, file, or symbol introduced by a candidate fix is referenced, so
// the suite compiles and runs against any correct implementation regardless
// of how it is structured internally.
//
// Fixtures are built by re-encoding known UTF-8 source into a legacy byte
// encoding at run time with golang.org/x/text/encoding/* (a public library
// already in the module cache), so the inputs are real non-UTF-8 bytes
// rather than checked-in blobs. Each non-UTF-8 fixture is guarded to be
// invalid UTF-8, otherwise the fast path would carry it through untouched
// and the check would prove nothing.

import (
	"context"
	"strings"
	"testing"
	"unicode/utf8"

	"golang.org/x/text/encoding"
	"golang.org/x/text/encoding/japanese"
	"golang.org/x/text/encoding/simplifiedchinese"
	"golang.org/x/text/encoding/traditionalchinese"
)

// reEncode converts a UTF-8 source string into enc's byte encoding and
// asserts the result is genuinely non-UTF-8, so the fixture actually
// exercises the decode path instead of slipping through the UTF-8 fast lane.
func reEncode(t *testing.T, src string, enc encoding.Encoding) []byte {
	t.Helper()
	raw, err := enc.NewEncoder().Bytes([]byte(src))
	if err != nil {
		t.Fatalf("re-encode fixture: %v", err)
	}
	if utf8.Valid(raw) {
		t.Fatal("fixture bytes are valid UTF-8; the fixture would pass through the fast path and prove nothing")
	}
	return raw
}

// parse runs the input through the public seam with content-preserving
// defaults (NewHTMLParser leaves RemoveHeaderFooter/RemoveTOC false, so no
// block is stripped) and fails on any parse error.
func parse(t *testing.T, name string, data []byte) ParseResult {
	t.Helper()
	res := NewHTMLParser().ParseWithResult(context.Background(), name, data)
	if res.Err != nil {
		t.Fatalf("ParseWithResult(%s): %v", name, res.Err)
	}
	return res
}

// joinedText concatenates the text of every emitted item, newline-separated.
func joinedText(res ParseResult) string {
	var sb strings.Builder
	for _, it := range res.JSON {
		if s, ok := it["text"].(string); ok {
			sb.WriteString(s)
			sb.WriteByte('\n')
		}
	}
	return sb.String()
}

// encodingLabel reads the reported File["encoding"] label.
func encodingLabel(res ParseResult) string {
	if res.File == nil {
		return ""
	}
	s, _ := res.File["encoding"].(string)
	return s
}

// assertReadable fails if the extracted text contains the U+FFFD
// replacement rune or is missing any expected substring.
func assertReadable(t *testing.T, res ParseResult, wants []string) {
	t.Helper()
	got := joinedText(res)
	if strings.ContainsRune(got, '�') {
		t.Errorf("extracted text contains U+FFFD replacement runes (input decoded as the wrong encoding): %q", got)
	}
	for _, w := range wants {
		if !strings.Contains(got, w) {
			t.Errorf("extracted text missing expected content %q; got: %q", w, got)
		}
	}
}

// --- Shared fixture content ------------------------------------------------

// Simplified-Chinese balance-sheet body with a table, mirroring the reported
// document (a Chinese financial statement saved from a finance site).
const (
	cjkTitle = "贵州茅台资产负债表" // 贵州茅台资产负债表
	cjkCell  = "货币资金"                               // 货币资金
	cjkCell2 = "应收账款"                               // 应收账款
)

func gbkBody() string {
	return "<h1>" + cjkTitle + "</h1>" +
		"<table><tr><th>项目</th><th>20251231</th></tr>" + // 项目
		"<tr><td>" + cjkCell + "</td><td>56000000000.00</td></tr>" +
		"<tr><td>" + cjkCell2 + "</td><td>1200000000.00</td></tr></table>" +
		"<p>单位：元</p>" // 单位：元
}

// --- Criterion: declared_nonutf8_readable ---------------------------------

// A non-UTF-8 page that declares its charset (http-equiv meta) must parse to
// readable text with a reported non-UTF-8 encoding label. This is the
// reported reproduction: the declaration should drive the decode.
func TestDeclaredNonUTF8_Readable(t *testing.T) {
	src := "<html><head>" +
		`<meta http-equiv="Content-Type" content="text/html; charset=gb2312">` +
		"<title>" + cjkTitle + "</title></head><body>" + gbkBody() +
		"</body></html>"
	res := parse(t, "balance.html", reEncode(t, src, simplifiedchinese.GBK))

	assertReadable(t, res, []string{cjkTitle, cjkCell, cjkCell2})

	label := encodingLabel(res)
	if label == "" || strings.EqualFold(label, "utf-8") {
		t.Errorf("File[\"encoding\"] = %q, want a detected non-UTF-8 label (not empty, not utf-8)", label)
	}
}

// --- Criterion: undeclared_gbk_readable -----------------------------------

// GBK bytes with NO charset declaration (the exact reported case) must still
// parse to readable text. A fix that only honors an explicit declaration
// fails here.
func TestUndeclaredGBK_Readable(t *testing.T) {
	src := "<html><head><title>" + cjkTitle + "</title></head><body>" +
		gbkBody() + "</body></html>"
	res := parse(t, "undeclared.html", reEncode(t, src, simplifiedchinese.GBK))
	assertReadable(t, res, []string{cjkTitle, cjkCell, cjkCell2})
}

// --- Criterion: undeclared_other_multibyte_roundtrip ----------------------

// An undeclared Big5 page must round-trip to its TRUE Traditional-Chinese
// characters. Every Big5 double-byte pair is also a valid GB18030 pair, so a
// fix that only walks an ordered fallback chain (GB18030 first) silently
// decodes this into wrong Chinese without any U+FFFD. Correct handling needs
// statistical detection to steer the decode; this fixture catches the
// swallow because the original characters must survive verbatim.
func TestUndeclaredBig5_RoundTrips(t *testing.T) {
	// 台灣大學資料庫 / 繁體中文編碼偵測
	big5Title := "台灣大學資料庫"
	big5Body := "這是一份繁體中文測試文件。"
	src := "<html><body><h1>" + big5Title + "</h1><p>" + big5Body + "</p></body></html>"
	res := parse(t, "tw.html", reEncode(t, src, traditionalchinese.Big5))
	assertReadable(t, res, []string{big5Title, "繁體中文"})
}

// A second undeclared non-GB multibyte page (Shift-JIS) reinforces the
// detection requirement in a different script family: Japanese kana/kanji
// must survive rather than being absorbed as mojibake Chinese.
func TestUndeclaredShiftJIS_RoundTrips(t *testing.T) {
	// 日本語のテスト / 東京都庁
	jpTitle := "日本語のテスト"
	jpBody := "これはシフトJISで書かれた文書です。東京都庁。"
	src := "<html><body><h1>" + jpTitle + "</h1><p>" + jpBody + "</p></body></html>"
	res := parse(t, "jp.html", reEncode(t, src, japanese.ShiftJIS))
	assertReadable(t, res, []string{jpTitle, "東京都庁"})
}

// --- Criterion: utf8_passthrough (pass_to_pass) ---------------------------

// Valid UTF-8 input must be left untouched and reported as utf-8. This is the
// no-regression guarantee for the pages that already work.
func TestUTF8_Passthrough(t *testing.T) {
	src := "<html><body><h1>" + cjkTitle + "</h1><p>plain ascii content</p></body></html>"
	res := parse(t, "utf8.html", []byte(src))
	assertReadable(t, res, []string{cjkTitle, "plain ascii content"})
	if label := encodingLabel(res); !strings.EqualFold(label, "utf-8") {
		t.Errorf("File[\"encoding\"] = %q, want utf-8 for a UTF-8 input", label)
	}
}

// Empty input must parse without error and report utf-8 — the degenerate
// boundary must be no worse than before the fix.
func TestEmptyInput_NoRegression(t *testing.T) {
	res := parse(t, "empty.html", nil)
	if label := encodingLabel(res); !strings.EqualFold(label, "utf-8") {
		t.Errorf("File[\"encoding\"] = %q for empty input, want utf-8", label)
	}
}

// --- Criterion: table_item_decoded ----------------------------------------

// The structured table item (doc_type_kwd == "table") emitted from a
// non-UTF-8 page must carry decoded cell text. Decoding has to happen before
// the parse/walk, otherwise the table markup the walker serializes is still
// mojibake.
func TestTableItemDecoded_FromGBK(t *testing.T) {
	src := "<html><head>" +
		`<meta http-equiv="Content-Type" content="text/html; charset=gb2312">` +
		"</head><body>" + gbkBody() + "</body></html>"
	res := parse(t, "table.html", reEncode(t, src, simplifiedchinese.GBK))

	var tableText string
	found := false
	for _, it := range res.JSON {
		if dt, _ := it["doc_type_kwd"].(string); dt == "table" {
			found = true
			tableText, _ = it["text"].(string)
		}
	}
	if !found {
		t.Fatalf("no doc_type_kwd==\"table\" item emitted; items: %#v", res.JSON)
	}
	if strings.ContainsRune(tableText, '�') {
		t.Errorf("table item text contains U+FFFD replacement runes: %q", tableText)
	}
	if !strings.Contains(tableText, cjkCell) {
		t.Errorf("table item missing decoded cell %q; got: %q", cjkCell, tableText)
	}
}
