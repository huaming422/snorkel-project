// Structural verifier: the shipped, content-hashed migration SQL stays frozen.
//
// Criterion: migration_sql_frozen (pass_to_pass).
//
// WHY pass_to_pass, NOT fail_to_pass: neither an unchanged tree nor a correct
// fix edits any migration/*.up.sql file, so a frozen-bytes check passes on BOTH
// and cannot tell them apart. It is an anti-reward-hack guard: it FAILS only on
// the tempting-but-wrong solution that "fixes" the brick by editing 0040/0041 to
// be idempotent (e.g. INSERT -> INSERT IGNORE, or adding --skip-empty). Those
// bytes are content-hashed into schema_migrations.content_hash; rewriting them
// forks every already-upgraded clone. A correct fix heals around the frozen
// bodies, leaving the SQL byte-identical. The behavioral separation is carried
// by the fail_to_pass recovery tests in verify_idempotent_test.go (interrupted
// 0040 and 0041 setups finish on the next open).
//
// It tests THROUGH the pre-existing exported schema.MigrationSQL(name), which
// returns the byte-exact embedded migration content runMigrations itself applies
// (compiled from the submitted source tree), so an edit to the shipped file is
// reflected here. It asserts the sha256 of the two migrations this task's brick
// involves against their frozen base-commit digests. Both digests are stable
// facts: the content-hash contract freezes these exact bytes (see
// scripts/check-migration-hygiene.sh check C).

package schema_test

import (
	"crypto/sha256"
	"encoding/hex"
	"testing"

	"github.com/steveyegge/beads/internal/storage/schema"
)

func TestFrozenMigrationBytesUnchanged(t *testing.T) {
	// Stable facts: sha256 of the frozen, content-hashed shipped bytes at the base
	// commit (verified with sha256sum on the pre-fix tree).
	frozen := []struct {
		name   string
		sha256 string
	}{
		{"0040_ignored_tables_also_nonlocal_tables.up.sql", "c7068d67ad3e2b4852549e04d97f25814121de83db919e220bdcb9bdd9b61e5e"},
		{"0041_split_dependencies_target.up.sql", "e84ef393576df31550570fd3217579b1880850c0645b7d2b6ad8cf55a18ac1c0"},
	}

	for _, f := range frozen {
		body, err := schema.MigrationSQL(f.name)
		if err != nil {
			t.Fatalf("read frozen migration %s via schema.MigrationSQL: %v", f.name, err)
		}
		sum := sha256.Sum256([]byte(body))
		got := hex.EncodeToString(sum[:])
		if got != f.sha256 {
			t.Fatalf("frozen migration %s was edited: sha256 = %s, want %s.\n"+
				"These bytes are content-hashed into schema_migrations.content_hash; "+
				"editing them forks every already-upgraded clone. Heal the "+
				"non-idempotent replay around the frozen body (a version-keyed "+
				"pre-migration repair) instead of rewriting the shipped SQL.",
				f.name, got, f.sha256)
		}
	}
}
