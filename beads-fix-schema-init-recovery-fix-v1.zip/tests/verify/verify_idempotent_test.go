//go:build integration && !windows

// Behavioral verifier: a workspace whose schema setup was cut off partway must
// finish setting up the next time bd opens it, keeping the data it already had,
// and a never-interrupted workspace must set up and open exactly as before.
// Everything runs against a REAL offline Dolt sql-server (no Docker, no network).
//
// THE USER-VISIBLE FAILURE
//
// Migrations 0040 and 0041 are frozen, content-hashed files whose bodies commit
// their own side effects with CALL DOLT_COMMIT before the migration engine
// records the version row. When an init dies between those two points (for
// example a "busy buffer" / "driver: bad connection" under concurrent load), the
// database is left with part of the migration committed and no record that it
// ran. Every later open replays the whole frozen body against that state and
// fails the same way forever: 0040 with "duplicate primary key given: [wisps]",
// 0041 with "nothing to commit".
//
// WHAT EACH SCENARIO FORGES
//
// Each subtest builds, on its own fresh database, one on-disk state an
// interrupted init really leaves behind, with a committed `config` row as the
// user's pre-existing data, then opens the database again:
//
//   - 0040 first_row_after_full_init: the first frozen 0040 row ('wisps') is
//     committed and the version cursor sits below 40 (the shape the bug report
//     reproduced on a database that had already been fully set up).
//   - 0040 two_rows_mid_body: a database set up through 0039 that ran the first
//     two INSERT / CALL DOLT_COMMIT pairs of the frozen 0040 body and then died.
//   - 0040 all_rows_before_version_recorded: the whole 0040 body ran and
//     committed, but the version row for 40 was never written.
//   - 0041 after_full_init: 0041 already emptied dolt_nonlocal_tables and
//     committed, but its version row is missing.
//   - 0041 before_column_split: a database set up through 0040 that ran 0041's
//     leading DELETE and its CALL DOLT_COMMIT and then died, before the rest of
//     0041 (the dependencies column split) ran.
//
// "Recovered" means: the re-open returns no error; the schema version reaches
// schema.LatestVersion(); the database's column fingerprint (table, column,
// type, nullability) and its dolt_nonlocal_tables rows equal those of a
// database freshly set up by the same code in the same run; the user's data is
// still there; and opening it once more is a clean no-op (no error, 0 applied).
// The frozen statements are read from the shipped bytes via schema.MigrationSQL,
// so the forged state is exactly what the real migration produces.
//
// WHY BOTH INIT PATHS
//
// Server-mode opens (the dolt store, the unit-of-work provider and the public
// schema wrapper) run schema.MigrateUpWithLock on a pinned connection; embedded
// mode runs schema.MigrateUp directly. Both drive the same migration engine, and
// the task requires recovery in server AND embedded mode, so the scenarios are
// split across the two entry points: a recovery that only works through one of
// them leaves the other kind of workspace permanently broken.
//
// OFFLINE SERVER. The repo's package-`dolt` TestMain boots Dolt via
// testcontainers (Docker), unavailable here. This file owns its own TestMain
// that boots the baked dolt binary directly with doltserver.Start. A missing
// binary or a failed boot FAILS the run (it never skips). Because this file
// defines TestMain, the Go runner stashes every sibling *_test.go in the
// package before running, so this file is fully self-contained.

package dolt

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	_ "github.com/go-sql-driver/mysql"
	"github.com/steveyegge/beads/internal/doltserver"
	"github.com/steveyegge/beads/internal/storage/doltutil"
	"github.com/steveyegge/beads/internal/storage/schema"
)

const (
	vidxMigration0040 = "0040_ignored_tables_also_nonlocal_tables.up.sql"
	vidxMigration0041 = "0041_split_dependencies_target.up.sql"

	vidxMarkerInsert = "INSERT INTO config (`key`, value) VALUES ('vidx.recovery-marker', 'kept')"
	vidxMarkerSelect = "SELECT value FROM config WHERE `key`='vidx.recovery-marker'"

	vidxDiffCap = 15
)

var (
	// vidxServerPort is the MySQL-protocol port of the offline dolt server
	// booted by TestMain.
	vidxServerPort int

	// vidxDBSeq keeps database names unique within one run.
	vidxDBSeq atomic.Int64

	// The expected fingerprint comes from ONE database freshly set up by the
	// code under test, computed once per test binary run.
	vidxFreshOnce sync.Once
	vidxFreshFP   []string
	vidxFreshErr  error
)

// TestMain boots a single offline dolt sql-server for all tests in this file,
// against the baked dolt binary. If the binary is missing or any boot step
// fails, it reports why and exits non-zero without running any test.
func TestMain(m *testing.M) {
	code := func() int {
		doltPath, err := exec.LookPath("dolt")
		if err != nil {
			fmt.Fprintf(os.Stderr, "verify: FAIL: dolt binary not found on PATH (%v); the schema recovery tests need a real dolt sql-server and were not run\n", err)
			return 1
		}

		tmpDir, err := os.MkdirTemp("", "vidx-beads-")
		if err != nil {
			fmt.Fprintf(os.Stderr, "verify: FAIL: mkdtemp: %v\n", err)
			return 1
		}
		defer os.RemoveAll(tmpDir)

		beadsDir := filepath.Join(tmpDir, ".beads")
		doltDir := filepath.Join(beadsDir, "dolt")
		if err := os.MkdirAll(doltDir, 0o700); err != nil {
			fmt.Fprintf(os.Stderr, "verify: FAIL: mkdir dolt: %v\n", err)
			return 1
		}

		// dolt refuses to init/commit without an author identity. Configure one
		// in the per-run DOLT_ROOT_PATH before init, as the repo's own offline
		// server tests do. HOME and DOLT_ROOT_PATH both point at the temp dir so
		// the --global config stays scoped to this run.
		doltEnv := append(os.Environ(), "HOME="+tmpDir, "DOLT_ROOT_PATH="+tmpDir)
		for _, args := range [][]string{
			{"config", "--global", "--add", "user.name", "beads-verify"},
			{"config", "--global", "--add", "user.email", "beads@verify"},
		} {
			cfgCmd := exec.Command(doltPath, args...)
			cfgCmd.Env = doltEnv
			if out, err := cfgCmd.CombinedOutput(); err != nil {
				fmt.Fprintf(os.Stderr, "verify: FAIL: dolt %v: %v\n%s\n", args, err, out)
				return 1
			}
		}

		initCmd := exec.Command(doltPath, "init")
		initCmd.Dir = doltDir
		initCmd.Env = doltEnv
		if out, err := initCmd.CombinedOutput(); err != nil {
			fmt.Fprintf(os.Stderr, "verify: FAIL: dolt init: %v\n%s\n", err, out)
			return 1
		}

		// doltserver.Start launches the sql-server subprocess with the process
		// environment, and that server performs commits during migration, so
		// it needs the same author identity and root path.
		for _, kv := range [][2]string{
			{"HOME", tmpDir},
			{"DOLT_ROOT_PATH", tmpDir},
			{"BEADS_DOLT_SHARED_SERVER", "0"},
			{"BEADS_DOLT_AUTO_START", "1"},
			{"BEADS_TEST_MODE", "1"},
			{"BEADS_TEST_PDEATHSIG", "1"},
		} {
			if err := os.Setenv(kv[0], kv[1]); err != nil {
				fmt.Fprintf(os.Stderr, "verify: FAIL: setenv %s: %v\n", kv[0], err)
				return 1
			}
		}

		state, err := doltserver.Start(beadsDir)
		if err != nil {
			fmt.Fprintf(os.Stderr, "verify: FAIL: doltserver.Start: %v\n", err)
			return 1
		}
		defer func() { _ = doltserver.Stop(beadsDir) }()
		if state == nil || state.Port == 0 {
			fmt.Fprintln(os.Stderr, "verify: FAIL: doltserver.Start returned no MySQL port; the schema recovery tests were not run")
			return 1
		}
		vidxServerPort = state.Port

		return m.Run()
	}()
	os.Exit(code)
}

func vidxContext() (context.Context, context.CancelFunc) {
	return context.WithTimeout(context.Background(), 4*time.Minute)
}

// vidxCreateDB creates a brand-new database on the offline server and returns
// an open *sql.DB scoped to it. DROP is intentionally never issued: rapid drop
// cycles can destabilise the server, and TestMain removes the data dir.
func vidxCreateDB(ctx context.Context) (*sql.DB, error) {
	if vidxServerPort == 0 {
		return nil, errors.New("no offline Dolt server is running (TestMain did not boot one)")
	}

	rootDB, err := sql.Open("mysql", doltutil.ServerDSN{
		Host: "127.0.0.1", Port: vidxServerPort, User: "root", Timeout: 10 * time.Second,
	}.String())
	if err != nil {
		return nil, fmt.Errorf("open root connection: %w", err)
	}
	defer rootDB.Close()

	dbName := "vidx_" + strconv.FormatInt(time.Now().UnixNano(), 36) + "_" + strconv.FormatInt(vidxDBSeq.Add(1), 10)
	if _, err := rootDB.ExecContext(ctx, "CREATE DATABASE `"+dbName+"`"); err != nil {
		return nil, fmt.Errorf("create database %q: %w", dbName, err)
	}

	db, err := sql.Open("mysql", doltutil.ServerDSN{
		Host: "127.0.0.1", Port: vidxServerPort, User: "root", Database: dbName, Timeout: 10 * time.Second,
	}.String())
	if err != nil {
		return nil, fmt.Errorf("open database %q: %w", dbName, err)
	}
	db.SetMaxOpenConns(4)
	return db, nil
}

// vidxFreshDB gives a test its own brand-new database.
func vidxFreshDB(ctx context.Context, t *testing.T) *sql.DB {
	t.Helper()
	if vidxServerPort == 0 {
		t.Fatalf("no offline Dolt server port: TestMain did not boot the dolt sql-server")
	}
	db, err := vidxCreateDB(ctx)
	if err != nil {
		t.Fatalf("fresh database: %v", err)
	}
	t.Cleanup(func() { _ = db.Close() })
	return db
}

// vidxInitLock runs the server-mode init sequence: pin a connection, read the
// database name, schema.MigrateUpWithLock.
func vidxInitLock(ctx context.Context, db *sql.DB) (int, error) {
	conn, err := db.Conn(ctx)
	if err != nil {
		return 0, fmt.Errorf("pin connection: %w", err)
	}
	defer conn.Close()

	var dbName string
	if err := conn.QueryRowContext(ctx, "SELECT DATABASE()").Scan(&dbName); err != nil {
		return 0, fmt.Errorf("read database name: %w", err)
	}
	return schema.MigrateUpWithLock(ctx, conn, dbName)
}

// vidxInitEmbedded runs the embedded-mode init sequence: schema.MigrateUp on a
// pinned connection.
func vidxInitEmbedded(ctx context.Context, db *sql.DB) (int, error) {
	conn, err := db.Conn(ctx)
	if err != nil {
		return 0, fmt.Errorf("pin connection: %w", err)
	}
	defer conn.Close()
	return schema.MigrateUp(ctx, conn)
}

// vidxFullInit sets a fresh database up to the latest version (server path).
func vidxFullInit(ctx context.Context, t *testing.T, db *sql.DB) {
	t.Helper()
	if _, err := vidxInitLock(ctx, db); err != nil {
		t.Fatalf("initial setup of a fresh database fails: %v", err)
	}
	latest := schema.LatestVersion()
	if got := vidxSchemaVersion(ctx, t, db); got < latest {
		t.Fatalf("initial setup of a fresh database stopped at schema version %d, want >= %d", got, latest)
	}
}

// vidxMigrateTo sets a fresh database up through exactly `version` (the state
// of a workspace whose init had not yet reached the next migration).
func vidxMigrateTo(ctx context.Context, t *testing.T, db *sql.DB, version int) {
	t.Helper()
	conn, err := db.Conn(ctx)
	if err != nil {
		t.Fatalf("pin connection: %v", err)
	}
	_, err = schema.MigrateUpTo(ctx, conn, version)
	if closeErr := conn.Close(); closeErr != nil && err == nil {
		err = closeErr
	}
	if err != nil {
		t.Fatalf("set the database up through migration %04d: %v", version, err)
	}
	if got := vidxSchemaVersion(ctx, t, db); got != version {
		t.Fatalf("database set up through migration %04d reports schema version %d", version, got)
	}
}

func vidxSchemaVersion(ctx context.Context, t *testing.T, db *sql.DB) int {
	t.Helper()
	var got int
	if err := db.QueryRowContext(ctx, "SELECT COALESCE(MAX(version), 0) FROM schema_migrations").Scan(&got); err != nil {
		t.Fatalf("read schema version: %v", err)
	}
	return got
}

// vidxExecAll runs each statement separately, in order, on the pool
// (autocommit).
func vidxExecAll(ctx context.Context, t *testing.T, db *sql.DB, what string, stmts []string) {
	t.Helper()
	for i, stmt := range stmts {
		if _, err := db.ExecContext(ctx, stmt); err != nil {
			t.Fatalf("%s: statement %d %q: %v", what, i+1, stmt, err)
		}
	}
}

// vidxCommit commits everything in the working set with a forge message.
func vidxCommit(ctx context.Context, t *testing.T, db *sql.DB, msg string) {
	t.Helper()
	if _, err := db.ExecContext(ctx, "CALL DOLT_COMMIT('-Am', '"+msg+"', '--skip-empty')"); err != nil {
		t.Fatalf("commit forged state (%s): %v", msg, err)
	}
}

// vidxInsertMarker writes the user's pre-existing data that recovery must keep.
func vidxInsertMarker(ctx context.Context, t *testing.T, db *sql.DB) {
	t.Helper()
	if _, err := db.ExecContext(ctx, vidxMarkerInsert); err != nil {
		t.Fatalf("write workspace data marker: %v", err)
	}
}

// vidxFrozenStatements returns the first len(keywords) statements of a frozen
// migration, read from the shipped bytes. 0040's body and 0041's leading
// statements are one statement per line; each line must start with the
// expected keyword, so a changed file fails loudly instead of forging a
// different state.
func vidxFrozenStatements(t *testing.T, name string, keywords []string) []string {
	t.Helper()
	body, err := schema.MigrationSQL(name)
	if err != nil {
		t.Fatalf("read frozen migration %s: %v", name, err)
	}
	var stmts []string
	for _, line := range strings.Split(body, "\n") {
		if len(stmts) == len(keywords) {
			break
		}
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		want := keywords[len(stmts)]
		if !strings.HasPrefix(strings.ToUpper(line), want+" ") {
			t.Fatalf("frozen migration %s line %d = %q, want a %s statement (the shipped file changed)",
				name, len(stmts)+1, line, want)
		}
		stmts = append(stmts, strings.TrimSuffix(line, ";"))
	}
	if len(stmts) != len(keywords) {
		t.Fatalf("frozen migration %s has %d statements, want at least %d (the shipped file changed)",
			name, len(stmts), len(keywords))
	}
	return stmts
}

// vidxForgeFromMigrateUpTo builds a database set up through `upTo`, commits
// the user's data, then runs the leading frozen statements of the next
// migration exactly as shipped, without recording its version row: the state
// an init leaves behind when it dies inside that migration's body.
func vidxForgeFromMigrateUpTo(ctx context.Context, t *testing.T, db *sql.DB, upTo int, migration string, keywords []string) {
	t.Helper()
	vidxMigrateTo(ctx, t, db, upTo)
	vidxInsertMarker(ctx, t, db)
	vidxCommit(ctx, t, db, "vidx: workspace set up through "+strconv.Itoa(upTo))
	stmts := vidxFrozenStatements(t, migration, keywords)
	vidxExecAll(ctx, t, db, "run the leading statements of "+migration, stmts)
}

// vidxFingerprint is the database's column shape (table, column, type,
// nullability) plus its dolt_nonlocal_tables rows, sorted.
func vidxFingerprint(ctx context.Context, db *sql.DB) ([]string, error) {
	var out []string

	rows, err := db.QueryContext(ctx,
		"SELECT TABLE_NAME, COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE()")
	if err != nil {
		return nil, fmt.Errorf("read columns: %w", err)
	}
	for rows.Next() {
		var table, column, colType, nullable sql.NullString
		if err := rows.Scan(&table, &column, &colType, &nullable); err != nil {
			rows.Close()
			return nil, fmt.Errorf("scan column: %w", err)
		}
		out = append(out, "column "+table.String+"."+column.String+" type="+colType.String+" nullable="+nullable.String)
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return nil, fmt.Errorf("read columns: %w", err)
	}
	rows.Close()

	nonlocal, err := db.QueryContext(ctx, "SELECT table_name FROM dolt_nonlocal_tables")
	if err != nil {
		return nil, fmt.Errorf("read dolt_nonlocal_tables: %w", err)
	}
	for nonlocal.Next() {
		var name sql.NullString
		if err := nonlocal.Scan(&name); err != nil {
			nonlocal.Close()
			return nil, fmt.Errorf("scan dolt_nonlocal_tables: %w", err)
		}
		out = append(out, "dolt_nonlocal_tables row "+name.String)
	}
	if err := nonlocal.Err(); err != nil {
		nonlocal.Close()
		return nil, fmt.Errorf("read dolt_nonlocal_tables: %w", err)
	}
	nonlocal.Close()

	sort.Strings(out)
	return out, nil
}

// vidxExpectedFingerprint returns the fingerprint of one database freshly set
// up (server path) by the code under test, computed once per run.
func vidxExpectedFingerprint(t *testing.T) []string {
	t.Helper()
	vidxFreshOnce.Do(func() {
		ctx, cancel := vidxContext()
		defer cancel()
		db, err := vidxCreateDB(ctx)
		if err != nil {
			vidxFreshErr = fmt.Errorf("create reference database: %w", err)
			return
		}
		defer db.Close()
		if _, err := vidxInitLock(ctx, db); err != nil {
			vidxFreshErr = fmt.Errorf("fresh setup of the reference database fails: %w", err)
			return
		}
		vidxFreshFP, vidxFreshErr = vidxFingerprint(ctx, db)
	})
	if vidxFreshErr != nil {
		t.Fatalf("cannot compute the schema of a freshly set up database: %v", vidxFreshErr)
	}
	return vidxFreshFP
}

// vidxDiff reports the multiset difference between want and got, capped.
func vidxDiff(want, got []string) string {
	counts := make(map[string]int, len(want))
	for _, w := range want {
		counts[w]++
	}
	for _, g := range got {
		counts[g]--
	}
	var missing, extra []string
	for k, n := range counts {
		for ; n > 0; n-- {
			missing = append(missing, k)
		}
		for ; n < 0; n++ {
			extra = append(extra, k)
		}
	}
	sort.Strings(missing)
	sort.Strings(extra)

	var b strings.Builder
	section := func(title string, items []string) {
		if len(items) == 0 {
			return
		}
		fmt.Fprintf(&b, "\n  %s (%d):", title, len(items))
		for i, item := range items {
			if i == vidxDiffCap {
				fmt.Fprintf(&b, "\n    ... and %d more", len(items)-vidxDiffCap)
				break
			}
			fmt.Fprintf(&b, "\n    %s", item)
		}
	}
	section("missing compared to a freshly set up database", missing)
	section("extra compared to a freshly set up database", extra)
	return b.String()
}

// vidxAssertRecovered checks that a re-opened database is indistinguishable
// from a freshly set up one, kept the user's data, and opens cleanly again
// through the same path.
func vidxAssertRecovered(ctx context.Context, t *testing.T, db *sql.DB, reinit func(context.Context, *sql.DB) (int, error)) {
	t.Helper()

	latest := schema.LatestVersion()
	if got := vidxSchemaVersion(ctx, t, db); got < latest {
		t.Fatalf("re-open after the interrupted setup returned no error but left schema version %d, want >= %d", got, latest)
	}

	want := vidxExpectedFingerprint(t)
	got, err := vidxFingerprint(ctx, db)
	if err != nil {
		t.Fatalf("read schema of the recovered database: %v", err)
	}
	if diff := vidxDiff(want, got); diff != "" {
		t.Errorf("recovered database does not match a freshly set up database:%s", diff)
	}

	var marker string
	switch err := db.QueryRowContext(ctx, vidxMarkerSelect).Scan(&marker); {
	case errors.Is(err, sql.ErrNoRows):
		t.Errorf("workspace data written before the interruption was lost by the recovery (config row vidx.recovery-marker is gone)")
	case err != nil:
		t.Errorf("read workspace data marker after recovery: %v", err)
	case marker != "kept":
		t.Errorf("workspace data written before the interruption was changed by the recovery: config row vidx.recovery-marker = %q, want %q", marker, "kept")
	}

	applied, err := reinit(ctx, db)
	if err != nil {
		t.Fatalf("opening the recovered workspace again fails: %v", err)
	}
	if applied != 0 {
		t.Errorf("opening the recovered workspace again applied %d migrations, want 0 (setup did not converge)", applied)
	}
}

// TestSchemaInitRecoversFromPartial0040: a workspace whose setup died inside
// migration 0040 (some of its dolt_nonlocal_tables rows committed, version 40
// never recorded). Unfixed, every re-open fails with
// "duplicate primary key given: [wisps]".
func TestSchemaInitRecoversFromPartial0040(t *testing.T) {
	// A fully set up database whose cursor was rewound below 40, with 0040's
	// first frozen row ('wisps') committed: the state reported in the bug.
	// Re-opened through the server path.
	t.Run("first_row_after_full_init", func(t *testing.T) {
		ctx, cancel := vidxContext()
		defer cancel()
		db := vidxFreshDB(ctx, t)

		vidxFullInit(ctx, t, db)
		vidxInsertMarker(ctx, t, db)
		vidxExecAll(ctx, t, db, "forge interrupted 0040", []string{
			"DELETE FROM schema_migrations WHERE version >= 40",
			"INSERT IGNORE INTO dolt_nonlocal_tables (table_name, target_ref, options) VALUES ('wisps', 'main', 'immediate')",
		})
		vidxCommit(ctx, t, db, "vidx: interrupted 0040, first nonlocal row committed, version 40 missing")

		if _, err := vidxInitLock(ctx, db); err != nil {
			t.Fatalf("re-open after interrupted 0040 still fails (server mode; first nonlocal row committed, version 40 not recorded): %v", err)
		}
		vidxAssertRecovered(ctx, t, db, vidxInitLock)
	})

	// A database set up through 0039 whose init ran the first two
	// INSERT / CALL DOLT_COMMIT pairs of the frozen 0040 body and died.
	// Re-opened through the embedded path.
	t.Run("two_rows_mid_body", func(t *testing.T) {
		ctx, cancel := vidxContext()
		defer cancel()
		db := vidxFreshDB(ctx, t)

		vidxForgeFromMigrateUpTo(ctx, t, db, 39, vidxMigration0040,
			[]string{"INSERT", "CALL", "INSERT", "CALL"})

		if _, err := vidxInitEmbedded(ctx, db); err != nil {
			t.Fatalf("re-open after interrupted 0040 still fails (embedded mode; two of four nonlocal rows committed, version 40 not recorded): %v", err)
		}
		vidxAssertRecovered(ctx, t, db, vidxInitEmbedded)
	})

	// A database set up through 0039 whose init ran the whole frozen 0040
	// body (all four rows committed) and died before recording version 40.
	// Re-opened through the server path.
	t.Run("all_rows_before_version_recorded", func(t *testing.T) {
		ctx, cancel := vidxContext()
		defer cancel()
		db := vidxFreshDB(ctx, t)

		vidxForgeFromMigrateUpTo(ctx, t, db, 39, vidxMigration0040,
			[]string{"INSERT", "CALL", "INSERT", "CALL", "INSERT", "CALL", "INSERT", "CALL"})

		if _, err := vidxInitLock(ctx, db); err != nil {
			t.Fatalf("re-open after interrupted 0040 still fails (server mode; all four nonlocal rows committed, version 40 not recorded): %v", err)
		}
		vidxAssertRecovered(ctx, t, db, vidxInitLock)
	})
}

// TestSchemaInitRecoversFromPartial0041: a workspace whose setup died inside
// migration 0041 after its leading DELETE FROM dolt_nonlocal_tables was
// committed, version 41 never recorded. Unfixed, every re-open fails with
// "nothing to commit".
func TestSchemaInitRecoversFromPartial0041(t *testing.T) {
	// A fully set up database (dolt_nonlocal_tables already emptied and
	// committed) whose cursor was rewound to 40. Re-opened through the
	// embedded path.
	t.Run("after_full_init", func(t *testing.T) {
		ctx, cancel := vidxContext()
		defer cancel()
		db := vidxFreshDB(ctx, t)

		vidxFullInit(ctx, t, db)
		vidxInsertMarker(ctx, t, db)
		vidxExecAll(ctx, t, db, "forge interrupted 0041", []string{
			"DELETE FROM schema_migrations WHERE version >= 41",
		})
		vidxCommit(ctx, t, db, "vidx: interrupted 0041, nonlocal rows deleted, version 41 missing")

		if _, err := vidxInitEmbedded(ctx, db); err != nil {
			t.Fatalf("re-open after interrupted 0041 still fails (embedded mode; nonlocal rows already deleted, version 41 not recorded): %v", err)
		}
		vidxAssertRecovered(ctx, t, db, vidxInitEmbedded)
	})

	// A database set up through 0040 whose init ran 0041's leading DELETE and
	// its CALL DOLT_COMMIT and died before the dependencies column split.
	// Re-opened through the server path.
	t.Run("before_column_split", func(t *testing.T) {
		ctx, cancel := vidxContext()
		defer cancel()
		db := vidxFreshDB(ctx, t)

		vidxForgeFromMigrateUpTo(ctx, t, db, 40, vidxMigration0041,
			[]string{"DELETE", "CALL"})

		if _, err := vidxInitLock(ctx, db); err != nil {
			t.Fatalf("re-open after interrupted 0041 still fails (server mode; nonlocal rows deleted and committed, column split not applied, version 41 not recorded): %v", err)
		}
		vidxAssertRecovered(ctx, t, db, vidxInitLock)
	})
}

// TestFreshInitReachesLatestNoOvercorrection: a never-interrupted workspace
// still sets up to the latest version on an idle server, and opening it again
// is a clean no-op. Passes before and after a correct change; fails if the
// recovery misfires on a healthy database or breaks normal setup.
func TestFreshInitReachesLatestNoOvercorrection(t *testing.T) {
	ctx, cancel := vidxContext()
	defer cancel()

	db := vidxFreshDB(ctx, t)

	if _, err := vidxInitLock(ctx, db); err != nil {
		t.Fatalf("fresh init on idle server must succeed: %v", err)
	}
	latest := schema.LatestVersion()
	if got := vidxSchemaVersion(ctx, t, db); got < latest {
		t.Fatalf("fresh init schema version = %d, want >= %d", got, latest)
	}

	// Re-running init on an already-current database must also be a clean
	// no-op (idempotent steady state), not an over-correction that errors or
	// regresses.
	applied, err := vidxInitLock(ctx, db)
	if err != nil {
		t.Fatalf("re-init on a current database must be a clean no-op: %v", err)
	}
	if applied != 0 {
		t.Fatalf("re-init on a current database applied = %d migrations, want 0", applied)
	}
	if got := vidxSchemaVersion(ctx, t, db); got < latest {
		t.Fatalf("after no-op re-init schema version = %d, want >= %d", got, latest)
	}
}
