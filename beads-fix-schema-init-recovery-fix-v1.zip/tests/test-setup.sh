#!/usr/bin/env bash
# Verifier-time setup for beads-fix-schema-init-recovery.
#
# Everything the verifier needs is baked into the image (agent_offline = true):
#   - Go 1.26.10 toolchain + warm module/build cache at the base commit
#   - github.com/DATA-DOG/go-sqlmock v1.5.2 (in go.mod/go.sum → module cache),
#     for the connection-draining (sqlmock) half of the verifier
#   - a real dolt v2.2.0 binary on PATH (/usr/local/bin/dolt), so the
#     idempotency half can boot an offline Dolt sql-server via
#     doltserver.Start (exec.LookPath("dolt"))
#
# This runs with network available at verifier time, but must not need it:
# offline-first with a loud failure if a prerequisite is somehow absent.
set -euo pipefail

echo "[test-setup] beads-fix-schema-init-recovery: verifying baked prerequisites (offline-first)"

# Go toolchain
if ! command -v go >/dev/null 2>&1; then
    echo "[test-setup] FATAL: go not on PATH" >&2
    exit 1
fi
go version

# Real dolt binary for the offline real-server verifier half
if ! command -v dolt >/dev/null 2>&1; then
    echo "[test-setup] FATAL: dolt not on PATH (idempotency-half verifier needs a real sql-server)" >&2
    exit 1
fi
dolt version

echo "[test-setup] all baked prerequisites present; no network install required"
