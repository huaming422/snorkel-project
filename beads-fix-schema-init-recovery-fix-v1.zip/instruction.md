## Task

`bd init` against a shared Dolt sql-server can leave a workspace unusable. When several inits hit the same server at once, one of them sometimes dies partway through setting up the schema, usually with `busy buffer` or `driver: bad connection`. After that every open of that workspace fails, with `duplicate primary key given: [wisps]` or with `nothing to commit` depending on the workspace, and retrying never gets past it.

Can you fix it so a workspace whose schema setup was cut off partway finishes setting up the next time bd opens it, in server or embedded mode, and keeps the data it already has? Workspaces that were never interrupted should set up and open the same way they do now.
