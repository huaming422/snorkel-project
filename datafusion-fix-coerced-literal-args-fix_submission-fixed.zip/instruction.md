## Task

Our custom scalar functions on DataFusion have started getting bad constant-argument information when they resolve a call's return type.
Take a function whose signature coerces a numeric argument down to Int16 and call it with a plain literal, for example `my_udf(1)` or `my_udf(x, 2)`.
Inside `return_field_from_args` we expect an Int16 constant for that argument, since that is what we declared, and we used to get one.
Now the slot is either empty, as if we had passed a column, or it holds something our Int16 match arm rejects.
Passing NULL in that position comes back as missing too.
Anything that sizes its output from a constant, the way `round(x, 2)` reads the `2`, is guessing now.
This worked on the main build we were on a couple of weeks ago, and it looks like it hits any function that declares a coercing signature, not just ours.

At minimum, a plain literal, NULL included, needs to reach the function as a usable constant of the type we declared, every time the planner asks for the return field.
Nothing else about how these calls plan, run, or fail should change.
