// @ts-nocheck
// Behavioral checks for the shared connector request executor.
//
// Everything here drives the public boundaries the module already exposes:
// `ParserEngine.call()` (with an injected `fetchImpl` and vitest fake timers,
// exactly as the module's own suites do), the `connectorRetryDelay` policy
// helper, and the real `search_sequence` descriptor from `RNA_TOOLS`. No
// internal/private symbol is imported: error identity is asserted by its
// `name`, and timing is asserted by the fake clock.
import { describe, it, expect, vi } from 'vitest'
import { ParserEngine } from './engine'
import { connectorRetryDelay } from './request-policy'
import { RNA_TOOLS } from './descriptors/rna'

const tool = (id) => RNA_TOOLS.find((t) => t.id === id)

// A declarative descriptor whose body is a stream we control, used to observe
// how the executor treats response bodies on the non-success paths.
const streamDescriptor = {
  id: 'lifecycle',
  connector: 'test',
  description: '',
  input: {},
  url: () => 'https://x.test/data',
  parse: (raw) => raw,
  format: 'text'
}

describe('shared whole-call deadline', () => {
  it('bounds sequential requests made by one run() descriptor', async () => {
    vi.useFakeTimers()
    try {
      const fetchImpl = vi.fn(async (_url, init) => {
        await new Promise((resolve, reject) => {
          const timer = setTimeout(resolve, 20)
          init?.signal?.addEventListener(
            'abort',
            () => {
              clearTimeout(timer)
              reject(init.signal?.reason)
            },
            { once: true }
          )
        })
        return new Response('ok')
      })
      const engine = new ParserEngine({ fetchImpl, totalTimeoutMs: 30 })
      const result = engine
        .call(
          {
            ...streamDescriptor,
            run: async (ctx) => {
              await ctx.fetchText('https://x.test/one')
              return ctx.fetchText('https://x.test/two')
            }
          },
          {},
          {}
        )
        .catch((error) => error)
      await vi.advanceTimersByTimeAsync(40)
      // Two ~20ms requests cannot both finish inside a single 30ms budget that
      // spans the whole call; the second request is already in flight when the
      // shared clock fires.
      expect(await result).toMatchObject({ name: 'ConnectorRequestTimeoutError' })
      expect(fetchImpl).toHaveBeenCalledTimes(2)
    } finally {
      vi.useRealTimers()
    }
  })

  it('counts retry backoff against the call budget', async () => {
    vi.useFakeTimers()
    try {
      const fetchImpl = vi.fn(async () => new Response(null, { status: 503 }))
      const engine = new ParserEngine({ fetchImpl, totalTimeoutMs: 30, retryBackoffMs: 40 })
      const result = engine.call(streamDescriptor, {}, {}).catch((error) => error)
      await vi.advanceTimersByTimeAsync(30)
      // The 40ms backoff wait would push past the 30ms call budget, so the call
      // ends at 30ms after a single request rather than resetting the clock.
      // Behavior, not wording, is what this checks: only the whole-call clock
      // can fire at 30ms here (the per-attempt idle timer defaults to 30s), so a
      // timeout now with exactly one request already separates it from the
      // reset-per-attempt bug without asserting the error text.
      expect(await Promise.race([result, Promise.resolve('still pending')])).toMatchObject({
        name: 'ConnectorRequestTimeoutError'
      })
      expect(fetchImpl).toHaveBeenCalledOnce()
      await vi.runAllTimersAsync()
      await result
    } finally {
      vi.useRealTimers()
    }
  })
})

describe('cancellation handling', () => {
  it('stops a run() descriptor that never settles at the deadline', async () => {
    vi.useFakeTimers()
    try {
      const result = new ParserEngine({ totalTimeoutMs: 30 })
        .call(
          {
            ...streamDescriptor,
            run: async () => new Promise(() => {})
          },
          {},
          {}
        )
        .catch((error) => error)
      await vi.advanceTimersByTimeAsync(30)
      expect(await Promise.race([result, Promise.resolve('still pending')])).toMatchObject({
        name: 'ConnectorRequestTimeoutError'
      })
      expect(vi.getTimerCount()).toBe(0)
    } finally {
      vi.useRealTimers()
    }
  })

  it('propagates caller cancellation through the run-style context signal', async () => {
    const engine = new ParserEngine({ fetchImpl: vi.fn() })
    const cancellation = new AbortController()
    let observed
    const desc = {
      id: 't',
      connector: 'c',
      description: '',
      input: {},
      run: async (ctx) => {
        observed = ctx.signal
        return new Promise((_, reject) => {
          ctx.signal?.addEventListener('abort', () => reject(ctx.signal?.reason), { once: true })
        })
      }
    }
    const result = engine.call(desc, {}, {}, cancellation.signal)
    expect(observed).toBeInstanceOf(AbortSignal)
    expect(observed?.aborted).toBe(false)
    const reason = new Error('user cancelled')
    cancellation.abort(reason)
    await expect(result).rejects.toBe(reason)
    expect(observed?.reason).toBe(reason)
  })
})

describe('Retry-After handling', () => {
  it('honors numeric Retry-After in full with no cap', () => {
    expect(connectorRetryDelay(0, '2')).toBe(2_000)
    expect(connectorRetryDelay(0, '30')).toBe(30_000)
    vi.spyOn(Math, 'random').mockReturnValue(0.5)
    expect(connectorRetryDelay(2, null, 200)).toBe(900)
    vi.restoreAllMocks()
  })

  it.each(['60', 'Sat, 05 Sep 2026 00:01:00 GMT'])(
    'waits the full server-requested delay before retrying (%s)',
    async (retryAfter) => {
      vi.useFakeTimers()
      vi.setSystemTime(new Date('2026-09-05T00:00:00Z'))
      try {
        const fetchImpl = vi
          .fn()
          .mockResolvedValueOnce(
            new Response(null, { status: 429, headers: { 'Retry-After': retryAfter } })
          )
          .mockResolvedValueOnce(new Response('ok'))
        const result = new ParserEngine({ fetchImpl }).call(streamDescriptor, {}, {})
        await vi.advanceTimersByTimeAsync(59_999)
        expect(fetchImpl).toHaveBeenCalledOnce()
        await vi.advanceTimersByTimeAsync(1)
        await expect(result).resolves.toBe('ok')
        expect(fetchImpl).toHaveBeenCalledTimes(2)
      } finally {
        vi.useRealTimers()
      }
    }
  )

  it('surfaces the status and retry time when the wait cannot fit the budget', async () => {
    vi.useFakeTimers()
    try {
      const fetchImpl = vi.fn(
        async () => new Response(null, { status: 429, headers: { 'Retry-After': '60' } })
      )
      const outcome = new ParserEngine({ fetchImpl, totalTimeoutMs: 30_000 })
        .call(streamDescriptor, {}, {})
        .catch((error) => error)
      await vi.runAllTimersAsync()
      const settled = await outcome
      // The core check is behavioral: the server asked for 60s, which does not
      // fit the 30s budget, so the engine must NOT retry early. One request only
      // (pre-fix caps the wait to 5s and retries up to 3x). It surfaces the
      // upstream status (pre-existing "HTTP <status>" text) and the requested
      // wait, without asserting the exact enrichment wording.
      expect(settled).toBeInstanceOf(Error)
      expect(settled.name).not.toBe('ConnectorRequestTimeoutError')
      expect(settled.message).toMatch(/HTTP 429/)
      expect(settled.message).toMatch(/60/)
      expect(fetchImpl).toHaveBeenCalledOnce()
    } finally {
      vi.useRealTimers()
    }
  })
})

describe('response body release', () => {
  it.each([400, 429, 503])('cancels every unfinished HTTP %i body', async (status) => {
    const cancellations = []
    const fetchImpl = vi.fn(async () => {
      const cancel = vi.fn()
      cancellations.push(cancel)
      return new Response(
        new ReadableStream({
          start(controller) {
            controller.enqueue(new Uint8Array(1024 * 1024))
          },
          cancel
        }),
        { status }
      )
    })
    const engine = new ParserEngine({ fetchImpl, retryBackoffMs: 0 })
    await expect(engine.call(streamDescriptor, {}, {})).rejects.toThrow(`HTTP ${status}`)
    expect(fetchImpl).toHaveBeenCalledTimes(status === 400 ? 1 : 3)
    for (const cancel of cancellations) expect(cancel).toHaveBeenCalledOnce()
  })

  it.each(['reject', 'pending'])(
    'keeps the HTTP failure when cancellation is %s',
    async (mode) => {
      const cancel = vi.fn(() =>
        mode === 'reject' ? Promise.reject(new Error('cancel failed')) : new Promise(() => {})
      )
      const response = new Response(new ReadableStream({ cancel }), { status: 400 })
      const engine = new ParserEngine({ fetchImpl: vi.fn().mockResolvedValue(response) })
      await expect(engine.call(streamDescriptor, {}, {})).rejects.toThrow('HTTP 400')
      expect(cancel).toHaveBeenCalledOnce()
    }
  )

  it('cancels the remainder of an oversized successful body', async () => {
    const cancel = vi.fn()
    const response = new Response(
      new ReadableStream({
        start(controller) {
          controller.enqueue(new Uint8Array(10))
        },
        cancel
      })
    )
    const engine = new ParserEngine({
      fetchImpl: vi.fn().mockResolvedValue(response),
      maxResponseBytes: 5
    })
    await expect(engine.call(streamDescriptor, {}, {})).rejects.toMatchObject({
      name: 'ConnectorResponseTooLargeError'
    })
    expect(cancel).toHaveBeenCalledOnce()
    expect(response.body?.locked).toBe(false)
  })

  it('attempts cleanup after a body read fails without hiding the error', async () => {
    const error = new Error('stream read failed')
    const response = new Response(
      new ReadableStream({
        pull(controller) {
          controller.error(error)
        }
      })
    )
    const engine = new ParserEngine({ fetchImpl: vi.fn().mockResolvedValue(response), retries: 0 })
    await expect(engine.call(streamDescriptor, {}, {})).rejects.toBe(error)
    expect(response.body?.locked).toBe(false)
  })

  it.each(['user', 'idle', 'total'])('cancels a stalled body on %s cancellation', async (mode) => {
    vi.useFakeTimers()
    try {
      const cancel = vi.fn()
      const response = new Response(new ReadableStream({ cancel }))
      const caller = new AbortController()
      const engine = new ParserEngine({
        fetchImpl: vi.fn().mockResolvedValue(response),
        timeoutMs: mode === 'idle' ? 10 : 100,
        totalTimeoutMs: mode === 'total' ? 10 : 100
      })
      const result = engine.call(streamDescriptor, {}, {}, caller.signal).catch((error) => error)
      await vi.advanceTimersByTimeAsync(0)
      if (mode === 'user') caller.abort()
      await vi.advanceTimersByTimeAsync(10)
      expect(await Promise.race([result, Promise.resolve('still pending')])).toMatchObject({
        name: mode === 'user' ? 'AbortError' : 'ConnectorRequestTimeoutError'
      })
      expect(cancel).toHaveBeenCalledOnce()
      expect(response.body?.locked).toBe(false)
    } finally {
      vi.useRealTimers()
    }
  })
})

describe('Rfam search_sequence whole-call window', () => {
  it.each([150_000, 295_000])(
    'preserves the default polling window for a job ready after %ims',
    async (readyAfterMs) => {
      vi.useFakeTimers()
      vi.setSystemTime(0)
      try {
        const submissionMs = 20_000
        const fetchImpl = vi.fn(async (_url, init) => {
          if (init?.method === 'POST') {
            await new Promise((resolve) => setTimeout(resolve, submissionMs))
            return Response.json({ jobId: 'job-1', resultURL: 'https://rfam.test/result/1' })
          }
          return Response.json(
            Date.now() >= submissionMs + readyAfterMs
              ? { hits: {}, searchSequence: 'GGUUCC' }
              : { status: 'PEND' }
          )
        })
        const result = new ParserEngine({ fetchImpl })
          .call(tool('search_sequence'), { sequence: 'GGUUCC' }, {})
          .then(
            (value) => ({ value, finishedAt: Date.now() }),
            (error) => ({ error, finishedAt: Date.now() })
          )
        await vi.advanceTimersByTimeAsync(submissionMs + readyAfterMs)
        expect(await result).toMatchObject({
          value: { job_id: 'job-1', num_hits: 0, search_sequence: 'GGUUCC' },
          finishedAt: submissionMs + readyAfterMs
        })
        expect(vi.getTimerCount()).toBe(0)
      } finally {
        vi.useRealTimers()
      }
    }
  )

  it('still stops an unfinished job at its default polling deadline', async () => {
    vi.useFakeTimers()
    vi.setSystemTime(0)
    try {
      const fetchImpl = vi.fn(async (_url, init) =>
        Response.json(
          init?.method === 'POST'
            ? { jobId: 'job-1', resultURL: 'https://rfam.test/result/1' }
            : { status: 'PEND' }
        )
      )
      const result = new ParserEngine({ fetchImpl })
        .call(tool('search_sequence'), { sequence: 'GGUUCC' }, {})
        .catch((error) => ({ error, finishedAt: Date.now() }))
      await vi.advanceTimersByTimeAsync(300_000)
      expect(await result).toMatchObject({
        error: { message: expect.stringContaining('Rfam sequence search not finished after 300s') },
        finishedAt: 300_000
      })
      expect(vi.getTimerCount()).toBe(0)
    } finally {
      vi.useRealTimers()
    }
  })

  it('keeps a hard whole-call cap for longer custom polling waits', async () => {
    vi.useFakeTimers()
    vi.setSystemTime(0)
    try {
      const customWaitMs = 1_200_000
      const fetchImpl = vi.fn(async (_url, init) =>
        Response.json(
          init?.method === 'POST'
            ? { jobId: 'job-1', resultURL: 'https://rfam.test/result/1' }
            : { status: 'PEND' }
        )
      )
      const outcome = new ParserEngine({ fetchImpl })
        .call(
          tool('search_sequence'),
          { sequence: 'GGUUCC', max_wait_s: 1200, poll_interval_s: 30 },
          {}
        )
        .catch((error) => ({ error, finishedAt: Date.now() }))
      // Advance across the full requested wait so the call settles no matter
      // where the hard cap sits. The exact cap is a design choice (the reference
      // uses 600s); what must hold is that a custom wait far above the cap is
      // still bounded by the whole-call deadline: the call ends with a
      // whole-call timeout strictly before the requested window elapses, not
      // with the poll loop's own "not finished" result.
      await vi.advanceTimersByTimeAsync(customWaitMs)
      const settled = await outcome
      expect(settled.error).toMatchObject({ name: 'ConnectorRequestTimeoutError' })
      expect(settled.finishedAt).toBeGreaterThan(300_000)
      expect(settled.finishedAt).toBeLessThan(customWaitMs)
      expect(vi.getTimerCount()).toBe(0)
    } finally {
      vi.useRealTimers()
    }
  })
})

describe('existing executor behavior preserved', () => {
  const jsonResponse = (body) =>
    ({
      ok: true,
      status: 200,
      json: async () => body,
      text: async () => JSON.stringify(body)
    })

  it('builds the url, fetches json, and runs parse', async () => {
    const fetchImpl = vi.fn().mockResolvedValue(jsonResponse({ value: 42 }))
    const engine = new ParserEngine({ fetchImpl })
    const desc = {
      id: 't',
      connector: 'c',
      description: '',
      input: {},
      url: (a) => `https://example.test/${a.id}`,
      parse: (raw) => raw.value
    }
    const out = await engine.call(desc, { id: 7 }, {})
    expect(fetchImpl).toHaveBeenCalledWith('https://example.test/7', expect.any(Object))
    expect(out).toBe(42)
  })

  it('retries transient 5xx and gives up after the configured retries', async () => {
    const fetchImpl = vi.fn().mockResolvedValue({ ok: false, status: 503 })
    const engine = new ParserEngine({ fetchImpl, retries: 2, retryBackoffMs: 0 })
    const desc = {
      id: 't',
      connector: 'c',
      description: '',
      input: {},
      url: () => 'https://x.test',
      parse: (r) => r
    }
    await expect(engine.call(desc, {}, {})).rejects.toThrow(/HTTP 503/)
    expect(fetchImpl).toHaveBeenCalledTimes(3)
  })

  it('retries a transient 5xx then succeeds', async () => {
    const fetchImpl = vi
      .fn()
      .mockResolvedValueOnce({ ok: false, status: 503 })
      .mockResolvedValueOnce(jsonResponse({ value: 1 }))
    const engine = new ParserEngine({ fetchImpl, retries: 2, retryBackoffMs: 0 })
    const desc = {
      id: 't',
      connector: 'c',
      description: '',
      input: {},
      url: () => 'https://x.test',
      parse: (r) => r.value
    }
    await expect(engine.call(desc, {}, {})).resolves.toBe(1)
    expect(fetchImpl).toHaveBeenCalledTimes(2)
  })

  it('does not retry a client error other than 429', async () => {
    const fetchImpl = vi.fn().mockResolvedValue({ ok: false, status: 400 })
    const engine = new ParserEngine({ fetchImpl, retries: 2, retryBackoffMs: 0 })
    const desc = {
      id: 't',
      connector: 'c',
      description: '',
      input: {},
      url: () => 'https://x.test',
      parse: (r) => r
    }
    await expect(engine.call(desc, {}, {})).rejects.toThrow(/HTTP 400/)
    expect(fetchImpl).toHaveBeenCalledOnce()
  })
})
