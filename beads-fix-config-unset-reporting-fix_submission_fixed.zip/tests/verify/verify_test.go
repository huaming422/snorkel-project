//go:build cgo

// Subprocess-driven checks for `bd config unset`, exercised exactly the way the
// repo's own tests in this package do: build the tool once, run it as a child
// process, and read its stdout / stderr / exit status and the resulting
// config.yaml bytes. Nothing here imports package internals, so any solution
// that behaves correctly passes regardless of how it is structured.
//
// The checks assert outcomes, not wording: a cleared key is a key that no
// longer resolves in config.yaml (commented out or removed), a multi-line value
// is either refused with a non-zero exit and an untouched file or removed
// whole, and a false success is detected by comparing the command's output
// against the output of a real clear of the same key, so the no-op wording
// stays the implementer's choice.
//
// Two tiers:
//   - YAML-only keys need only a temp .beads/config.yaml and BEADS_DIR.
//   - Other keys need a real `bd init` workspace (embedded, in-process, offline).
//
// Reused helpers (buildEmbeddedBD, bdEnv, bdInit, runCommandBuffers) come from
// the package's existing test files; this file is injected into cmd/bd/.
package main

import (
	"os"
	"os/exec"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	"gopkg.in/yaml.v3"
)

// cfg runs `bd config <args...>` with the given working dir and environment and
// returns stdout, stderr and the process exit code. Unlike bdConfig it does not
// fail the test on a non-zero exit, because some cases may exit non-zero.
func cfg(t *testing.T, bd, dir string, env []string, args ...string) (stdout, stderr string, code int) {
	t.Helper()
	cmd := exec.Command(bd, append([]string{"config"}, args...)...)
	cmd.Dir = dir
	cmd.Env = env
	outBuf, errBuf, err := runCommandBuffers(t, cmd)
	code = 0
	if err != nil {
		if exitErr, ok := err.(*exec.ExitError); ok {
			code = exitErr.ExitCode()
		} else {
			t.Fatalf("bd config %s: could not run: %v\nstderr:\n%s", strings.Join(args, " "), err, errBuf.String())
		}
	}
	return outBuf.String(), errBuf.String(), code
}

// yamlOnlyWorkspace writes a standalone .beads/config.yaml with the given body
// and returns the working dir, the config path and the environment (BEADS_DIR
// pointed at it). No workspace or database is created.
func yamlOnlyWorkspace(t *testing.T, bd, body string) (dir, configPath string, env []string) {
	t.Helper()
	home := t.TempDir()
	beadsDir := filepath.Join(home, ".beads")
	if err := os.MkdirAll(beadsDir, 0o755); err != nil {
		t.Fatalf("mkdir .beads: %v", err)
	}
	configPath = filepath.Join(beadsDir, "config.yaml")
	if err := os.WriteFile(configPath, []byte(body), 0o600); err != nil {
		t.Fatalf("write config.yaml: %v", err)
	}
	env = append(bdEnv(home), "BEADS_DIR="+beadsDir)
	return home, configPath, env
}

func readBytes(t *testing.T, path string) []byte {
	t.Helper()
	b, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read %s: %v", path, err)
	}
	return b
}

// topLevelKeyLive reports whether key appears as a live (uncommented) top-level
// entry in content: a line that begins at column zero with `key:`. A commented
// line starts with '#', and a nested same-named key is indented, so neither
// counts.
func topLevelKeyLive(content, key string) bool {
	for _, ln := range strings.Split(content, "\n") {
		if strings.HasPrefix(ln, key+":") || strings.HasPrefix(ln, key+" :") {
			return true
		}
	}
	return false
}

func nonBlankLines(s string) []string {
	var out []string
	for _, ln := range strings.Split(s, "\n") {
		if ln = strings.TrimSpace(ln); ln != "" {
			out = append(out, ln)
		}
	}
	return out
}

// sharedLine returns the first non-blank line of out that also appears in ref.
// Lines containing any of the skip strings (per-run temp paths) are ignored,
// and when mustContain is non-empty only lines containing it count.
func sharedLine(out, ref, mustContain string, skip ...string) (string, bool) {
	refLines := map[string]bool{}
	for _, ln := range nonBlankLines(ref) {
		refLines[ln] = true
	}
next:
	for _, ln := range nonBlankLines(out) {
		for _, s := range skip {
			if s != "" && strings.Contains(ln, s) {
				continue next
			}
		}
		if mustContain != "" && !strings.Contains(ln, mustContain) {
			continue
		}
		if refLines[ln] {
			return ln, true
		}
	}
	return "", false
}

// hasLine reports whether out carries one of the given lines verbatim.
func hasLine(out string, lines ...string) (string, bool) {
	for _, ln := range nonBlankLines(out) {
		for _, want := range lines {
			if ln == want {
				return ln, true
			}
		}
	}
	return "", false
}

// dropKey removes key from a decoded YAML mapping, in either the flat spelling
// (a top-level key containing the dots) or the nested one.
func dropKey(m map[string]interface{}, key string) {
	if m == nil {
		return
	}
	if _, ok := m[key]; ok {
		delete(m, key)
		return
	}
	segs := strings.Split(key, ".")
	cur := m
	for i, s := range segs {
		if i == len(segs)-1 {
			delete(cur, s)
			return
		}
		next, ok := cur[s].(map[string]interface{})
		if !ok {
			return
		}
		cur = next
	}
}

// normalizeYAML treats a null value and an emptied mapping as absent, so a
// parent left with no children compares equal to a parent that is gone.
func normalizeYAML(v interface{}) interface{} {
	switch x := v.(type) {
	case map[string]interface{}:
		out := map[string]interface{}{}
		for k, val := range x {
			nv := normalizeYAML(val)
			if nv == nil {
				continue
			}
			if mm, ok := nv.(map[string]interface{}); ok && len(mm) == 0 {
				continue
			}
			out[k] = nv
		}
		return out
	case []interface{}:
		out := make([]interface{}, len(x))
		for i, e := range x {
			out[i] = normalizeYAML(e)
		}
		return out
	default:
		return v
	}
}

// clearedWhole reports, as an error, anything wrong with an unset that exited 0
// on a key whose value spans several lines: the file must still parse, the key
// must no longer resolve, and every other setting must keep its value.
func clearedWhole(before, after []byte, key string) string {
	var want, got map[string]interface{}
	if err := yaml.Unmarshal(before, &want); err != nil {
		return "seeded config.yaml did not parse: " + err.Error()
	}
	if err := yaml.Unmarshal(after, &got); err != nil {
		return "config.yaml no longer parses: " + err.Error()
	}
	dropKey(want, key)
	if !reflect.DeepEqual(normalizeYAML(want), normalizeYAML(got)) {
		return "config.yaml does not hold exactly the other settings with " + key + " removed"
	}
	return ""
}

// checkMultiLineUnset accepts either outcome for a key whose value continues
// on the lines beneath it: a refusal (non-zero exit, file byte-identical) or a
// clear of the whole value that leaves a valid file with every other setting
// intact. Exiting 0 with the value or orphaned lines left behind fails.
func checkMultiLineUnset(t *testing.T, key string, before, after []byte, code int, stdout, stderr string) {
	t.Helper()
	if code != 0 {
		if string(after) != string(before) {
			t.Errorf("unset of %q exited %d but still rewrote config.yaml:\nbefore: %q\nafter:  %q\nstderr:\n%s",
				key, code, before, after, stderr)
		}
		return
	}
	if msg := clearedWhole(before, after, key); msg != "" {
		t.Errorf("unset of %q exited 0 but did not clear its whole value cleanly: %s\nbefore: %q\nafter:  %q\nstdout:\n%s",
			key, msg, before, after, stdout)
	}
}

// yamlOnlyClearOutput unsets key from a config.yaml that holds it and returns
// the combined output and the temp dir, as the reference for what a real clear
// of that key prints.
func yamlOnlyClearOutput(t *testing.T, bd, body, key string) (out, home string) {
	t.Helper()
	home, configPath, env := yamlOnlyWorkspace(t, bd, body)
	stdout, stderr, code := cfg(t, bd, filepath.Dir(configPath), env, "unset", key)
	if code != 0 {
		t.Fatalf("unset of %q present in config.yaml should exit 0, got %d\nstdout:\n%s\nstderr:\n%s", key, code, stdout, stderr)
	}
	return stdout + "\n" + stderr, home
}

// TestVerifyConfigUnsetYAMLOnly covers keys stored only in config.yaml.
func TestVerifyConfigUnsetYAMLOnly(t *testing.T) {
	bd := buildEmbeddedBD(t)

	// Unsetting a key the file does not hold exits 0, leaves the file alone and
	// prints nothing that a real clear of the same key prints (the success line
	// or the "removed" hint).
	t.Run("crit_yaml_absent_key_no_false_claim", func(t *testing.T) {
		ref, refHome := yamlOnlyClearOutput(t, bd, "issue_prefix: vp\nbackup.enabled: true\n", "backup.enabled")
		home, configPath, env := yamlOnlyWorkspace(t, bd, "issue_prefix: vp\nexport.auto: true\n")
		before := readBytes(t, configPath)

		stdout, stderr, code := cfg(t, bd, filepath.Dir(configPath), env, "unset", "backup.enabled")
		if code != 0 {
			t.Fatalf("unset of an absent yaml-only key should exit 0, got %d\nstdout:\n%s", code, stdout)
		}
		out := stdout + "\n" + stderr
		if ln, ok := hasLine(out, "Unset backup.enabled (in config.yaml)"); ok {
			t.Errorf("unset of a key the file never held reported a clear: %q\n%s", ln, out)
		} else if ln, ok := sharedLine(out, ref, "", home, refHome); ok {
			t.Errorf("unset of a key the file never held printed the same line as a real clear: %q\nno-op output:\n%s\nreal clear output:\n%s", ln, out, ref)
		}
		if got := readBytes(t, configPath); string(got) != string(before) {
			t.Errorf("a no-op unset rewrote config.yaml:\nbefore: %q\nafter:  %q", before, got)
		}
	})

	// The same for a key kept in the user-global config.yaml
	// ($HOME/.config/bd/config.yaml): unsetting a key that file does not hold
	// exits 0, leaves the file alone and does not print the line a real clear
	// of that key prints.
	t.Run("crit_user_global_absent_key_no_false_claim", func(t *testing.T) {
		userConfig := func(home, body string) string {
			dir := filepath.Join(home, ".config", "bd")
			if err := os.MkdirAll(dir, 0o700); err != nil {
				t.Fatalf("mkdir user config dir: %v", err)
			}
			path := filepath.Join(dir, "config.yaml")
			if err := os.WriteFile(path, []byte(body), 0o600); err != nil {
				t.Fatalf("write user config.yaml: %v", err)
			}
			return path
		}
		const key = "metrics.endpoint"

		refHome := t.TempDir()
		userConfig(refHome, key+": https://example.invalid/collect\n")
		refOut, refErr, code := cfg(t, bd, refHome, bdEnv(refHome), "unset", key)
		if code != 0 {
			t.Fatalf("unset of %q present in the user config.yaml should exit 0, got %d\nstdout:\n%s\nstderr:\n%s", key, code, refOut, refErr)
		}
		ref := strings.ReplaceAll(refOut+"\n"+refErr, refHome, "$HOME")

		home := t.TempDir()
		path := userConfig(home, "metrics.notice_shown: true\n")
		before := readBytes(t, path)
		stdout, stderr, code := cfg(t, bd, home, bdEnv(home), "unset", key)
		if code != 0 {
			t.Fatalf("unset of a key absent from the user config.yaml should exit 0, got %d\nstdout:\n%s\nstderr:\n%s", code, stdout, stderr)
		}
		out := strings.ReplaceAll(stdout+"\n"+stderr, home, "$HOME")
		if ln, ok := hasLine(out, "Unset "+key+" (in $HOME/.config/bd/config.yaml)"); ok {
			t.Errorf("unset of a key the user config.yaml never held reported a clear: %q\n%s", ln, out)
		} else if ln, ok := sharedLine(out, ref, key); ok {
			t.Errorf("unset of a key the user config.yaml never held printed the same line as a real clear: %q\nno-op output:\n%s\nreal clear output:\n%s", ln, out, ref)
		}
		if got := readBytes(t, path); string(got) != string(before) {
			t.Errorf("a no-op unset rewrote the user config.yaml:\nbefore: %q\nafter:  %q", before, got)
		}
	})

	// A present YAML-only key is cleared: afterward it is no longer a live
	// top-level entry.
	t.Run("crit_yaml_present_key_cleared", func(t *testing.T) {
		_, configPath, env := yamlOnlyWorkspace(t, bd, "issue_prefix: vp\nbackup.enabled: true\n")

		stdout, _, code := cfg(t, bd, filepath.Dir(configPath), env, "unset", "backup.enabled")
		if code != 0 {
			t.Fatalf("unset of a present yaml-only key should exit 0, got %d\nstdout:\n%s", code, stdout)
		}
		if topLevelKeyLive(string(readBytes(t, configPath)), "backup.enabled") {
			t.Errorf("present key is still live after unset:\n%s", readBytes(t, configPath))
		}
	})

	// A second present key on a different YAML-only section is cleared too.
	t.Run("crit_present_yaml_key_still_unsets", func(t *testing.T) {
		_, configPath, env := yamlOnlyWorkspace(t, bd, "issue_prefix: vp\nrouting.mode: auto\n")

		stdout, _, code := cfg(t, bd, filepath.Dir(configPath), env, "unset", "routing.mode")
		if code != 0 {
			t.Fatalf("unset of a present yaml-only key should exit 0, got %d\nstdout:\n%s", code, stdout)
		}
		if topLevelKeyLive(string(readBytes(t, configPath)), "routing.mode") {
			t.Errorf("present key is still live after unset:\n%s", readBytes(t, configPath))
		}
	})

	// The same no-op on a config.yaml with CRLF line endings leaves the bytes
	// identical and prints nothing a real clear prints.
	t.Run("crit_crlf_absent_key_untouched", func(t *testing.T) {
		ref, refHome := yamlOnlyClearOutput(t, bd, "issue_prefix: vp\nbackup.enabled: true\n", "backup.enabled")
		body := "issue_prefix: vp\r\nexport.auto: true\r\n"
		home, configPath, env := yamlOnlyWorkspace(t, bd, body)

		stdout, stderr, code := cfg(t, bd, filepath.Dir(configPath), env, "unset", "backup.enabled")
		if code != 0 {
			t.Fatalf("no-op unset on a CRLF file should exit 0, got %d\nstdout:\n%s", code, stdout)
		}
		if got := string(readBytes(t, configPath)); got != body {
			t.Errorf("a no-op unset rewrote a CRLF file:\ngot:  %q\nwant: %q", got, body)
		}
		out := stdout + "\n" + stderr
		if ln, ok := hasLine(out, "Unset backup.enabled (in config.yaml)"); ok {
			t.Errorf("no-op unset on a CRLF file reported a clear: %q\n%s", ln, out)
		} else if ln, ok := sharedLine(out, ref, "", home, refHome); ok {
			t.Errorf("no-op unset on a CRLF file printed the same line as a real clear: %q\nno-op output:\n%s\nreal clear output:\n%s", ln, out, ref)
		}
	})

	// Unsetting a top-level key leaves a same-named key nested under another
	// section exactly as it was.
	t.Run("crit_nested_namesake_untouched", func(t *testing.T) {
		body := "issue_prefix: vp\nsomesection:\n  no-push: true\n"
		_, configPath, env := yamlOnlyWorkspace(t, bd, body)

		stdout, _, code := cfg(t, bd, filepath.Dir(configPath), env, "unset", "no-push")
		if code != 0 {
			t.Fatalf("unset of an absent top-level key should exit 0, got %d\nstdout:\n%s", code, stdout)
		}
		if after := string(readBytes(t, configPath)); !strings.Contains(after, "  no-push: true") {
			t.Errorf("unset of the top-level key changed a nested key of the same name:\n%s", after)
		}
	})

	// A key whose value continues on the lines beneath it (a nested mapping or
	// a list) must not leave a broken or half-cleared file: either the command
	// refuses and leaves the file untouched, or it removes the whole value and
	// every other setting survives.
	t.Run("crit_multiline_value_not_left_broken", func(t *testing.T) {
		cases := []struct {
			name, body, key string
		}{
			{"mapping_nested", "issue_prefix: vp\ndirectory:\n  labels:\n    a: x\n  keep: y\n", "directory.labels"},
			{"list_nested", "issue_prefix: vp\nsync:\n  remotes:\n    - a\n    - b\n  keep: y\n", "sync.remotes"},
			{"list_own_indent", "issue_prefix: vp\nrouting:\n  extra:\n  - x\n  mode: auto\n", "routing.extra"},
		}
		for _, tc := range cases {
			t.Run(tc.name, func(t *testing.T) {
				_, configPath, env := yamlOnlyWorkspace(t, bd, tc.body)
				before := readBytes(t, configPath)

				stdout, stderr, code := cfg(t, bd, filepath.Dir(configPath), env, "unset", tc.key)
				checkMultiLineUnset(t, tc.key, before, readBytes(t, configPath), code, stdout, stderr)
			})
		}
	})
}

// dbClearOutput unsets no-hooks in a fresh workspace where it is set in the
// database and also written in config.yaml, and returns the combined output and
// the workspace dir, as the reference for what a clear of both layers prints.
func dbClearOutput(t *testing.T, bd string) (out, dir string) {
	t.Helper()
	dir, beadsDir, _ := bdInit(t, bd, "--prefix", "tc")
	configPath := filepath.Join(beadsDir, "config.yaml")
	original := readBytes(t, configPath)
	if _, _, code := cfg(t, bd, dir, bdEnv(dir), "set", "no-hooks", "true"); code != 0 {
		t.Fatalf("config set no-hooks true exited %d", code)
	}
	if err := os.WriteFile(configPath, append(original, []byte("no-hooks: true\n")...), 0o600); err != nil {
		t.Fatalf("append no-hooks to config.yaml: %v", err)
	}
	stdout, stderr, _ := cfg(t, bd, dir, bdEnv(dir), "unset", "no-hooks")
	return stdout + "\n" + stderr, dir
}

// claimsConfigYamlClear reports a line of out that says config.yaml was
// cleared: one of the two location lines the command uses for that, or a line
// mentioning config.yaml that the command also printed when it really did
// clear config.yaml.
func claimsConfigYamlClear(out, ref string, skip ...string) (string, bool) {
	if ln, ok := hasLine(out, "Unset no-hooks (in config.yaml)", "Unset no-hooks (in database, config.yaml)"); ok {
		return ln, true
	}
	return sharedLine(out, ref, "config.yaml", skip...)
}

// TestVerifyConfigUnsetDB covers keys stored in the workspace database, which
// need a real `bd init` workspace.
func TestVerifyConfigUnsetDB(t *testing.T) {
	bd := buildEmbeddedBD(t)

	// A database-backed key that config.yaml also carries is cleared from
	// config.yaml as well: afterward it is no longer a live top-level entry.
	// This reads the file rather than `bd config get`, which answers from the
	// database for this key.
	t.Run("crit_db_key_clears_yaml_layer", func(t *testing.T) {
		dir, beadsDir, _ := bdInit(t, bd, "--prefix", "tc")
		configPath := filepath.Join(beadsDir, "config.yaml")
		original := readBytes(t, configPath)
		if topLevelKeyLive(string(original), "no-hooks") {
			t.Skip("fresh config.yaml already carries no-hooks; probe needs a key it does not")
		}

		if _, _, code := cfg(t, bd, dir, bdEnv(dir), "set", "no-hooks", "true"); code != 0 {
			t.Fatalf("config set no-hooks true exited %d", code)
		}
		if err := os.WriteFile(configPath, append(original, []byte("no-hooks: true\n")...), 0o600); err != nil {
			t.Fatalf("append no-hooks to config.yaml: %v", err)
		}

		_, _, code := cfg(t, bd, dir, bdEnv(dir), "unset", "no-hooks")
		if code != 0 {
			t.Fatalf("unset of a workspace-backed key also in config.yaml should exit 0, got %d", code)
		}
		if topLevelKeyLive(string(readBytes(t, configPath)), "no-hooks") {
			t.Errorf("config.yaml still holds the key after unset:\n%s", readBytes(t, configPath))
		}
	})

	// A database-backed key with a default, set only in the database: the unset
	// exits 0, leaves config.yaml byte-identical and does not say config.yaml
	// was cleared.
	t.Run("crit_db_only_key_no_config_yaml_claim", func(t *testing.T) {
		ref, refDir := dbClearOutput(t, bd)
		dir, beadsDir, _ := bdInit(t, bd, "--prefix", "tc")
		configPath := filepath.Join(beadsDir, "config.yaml")
		before := readBytes(t, configPath)
		if topLevelKeyLive(string(before), "no-hooks") {
			t.Skip("fresh config.yaml already carries no-hooks; probe needs a key it does not")
		}

		if _, _, code := cfg(t, bd, dir, bdEnv(dir), "set", "no-hooks", "true"); code != 0 {
			t.Fatalf("config set no-hooks true exited %d", code)
		}

		stdout, stderr, code := cfg(t, bd, dir, bdEnv(dir), "unset", "no-hooks")
		if code != 0 {
			t.Fatalf("unset of a database-only key should exit 0, got %d\nstdout:\n%s", code, stdout)
		}
		if ln, ok := claimsConfigYamlClear(stdout+"\n"+stderr, ref, dir, refDir); ok {
			t.Errorf("unset said config.yaml was cleared though the key was never written there: %q\noutput:\n%s\nboth-layer clear output:\n%s", ln, stdout+stderr, ref)
		}
		if got := readBytes(t, configPath); string(got) != string(before) {
			t.Errorf("unset rewrote config.yaml though it had nothing to clear there:\nbefore: %q\nafter:  %q", before, got)
		}
	})

	// With no project config.yaml at all, unsetting a database-backed key
	// still succeeds, does not create config.yaml and does not say config.yaml
	// was cleared.
	t.Run("crit_db_key_no_project_yaml_succeeds", func(t *testing.T) {
		ref, refDir := dbClearOutput(t, bd)
		dir, beadsDir, _ := bdInit(t, bd, "--prefix", "tc")
		configPath := filepath.Join(beadsDir, "config.yaml")

		if _, _, code := cfg(t, bd, dir, bdEnv(dir), "set", "no-hooks", "true"); code != 0 {
			t.Fatalf("config set no-hooks true exited %d", code)
		}
		if err := os.Remove(configPath); err != nil {
			t.Fatalf("remove config.yaml: %v", err)
		}

		stdout, stderr, code := cfg(t, bd, dir, bdEnv(dir), "unset", "no-hooks")
		if code != 0 {
			t.Fatalf("unset with no project config.yaml should exit 0, got %d\nstdout:\n%s\nstderr:\n%s", code, stdout, stderr)
		}
		if _, err := os.Stat(configPath); !os.IsNotExist(err) {
			t.Errorf("unset created config.yaml (stat err=%v)", err)
		}
		if ln, ok := claimsConfigYamlClear(stdout+"\n"+stderr, ref, dir, refDir); ok {
			t.Errorf("unset said config.yaml was cleared though none exists: %q\noutput:\n%s", ln, stdout+stderr)
		}
	})

	// A single-segment key whose value is a block scalar, unset through the
	// database-backed route: either a refusal that leaves the file untouched,
	// or a clear of the whole value that keeps every other setting.
	t.Run("crit_single_segment_block_scalar_not_left_broken", func(t *testing.T) {
		dir, beadsDir, _ := bdInit(t, bd, "--prefix", "tc")
		configPath := filepath.Join(beadsDir, "config.yaml")
		original := readBytes(t, configPath)
		if err := os.WriteFile(configPath, append(original, []byte("notes: |\n  line one\n  line two\n")...), 0o600); err != nil {
			t.Fatalf("append notes block scalar to config.yaml: %v", err)
		}
		seeded := readBytes(t, configPath)

		stdout, stderr, code := cfg(t, bd, dir, bdEnv(dir), "unset", "notes")
		checkMultiLineUnset(t, "notes", seeded, readBytes(t, configPath), code, stdout, stderr)
	})
}
