## Task

`bd config unset` reports clears it never made, and sometimes edits parts of config.yaml it was never pointed at. Cases we've hit:

- `bd config unset backup.enabled` on a config.yaml that doesn't have the key still prints `Unset backup.enabled (in config.yaml)` and the hint that backups will no longer run. If the file has CRLF line endings, the same command also rewrites the whole file with LF endings. Keys in the user-level config (`metrics.*`) get the same false message.
- `no-hooks` set with `bd config set` and also written in config.yaml: after `bd config unset no-hooks` the line is still live in config.yaml, so the setting stays in effect.
- With no top-level `no-push` but a `no-push:` nested under another section, `bd config unset no-push` comments out the nested one.
- For a key whose value continues on the lines below it (a nested mapping or a list), unset comments out only the key line. What's left either breaks the file or gets read as some other setting.

Make unset actually clear the setting, be honest about whether it cleared anything, and never leave config.yaml broken or half-edited.
