"""Drives the Codex provider catalog check through the repo's own test runner.

t3code is a pnpm workspace monorepo whose suite runs through vite-plus
(`vp test run`), not plain vitest — there is no `vitest` binary in
`node_modules/.bin`. The shared Node runner shells out to `npx vitest`, which
does not exist here, so this Python wrapper drives `vp` directly instead:

1. Copy the TypeScript catalog check next to `CodexProvider.ts` so its relative
   import (`./CodexProvider.ts`) and the workspace's vite-plus config resolve.
2. Run `node_modules/.bin/vp test run <copied> --reporter=json
   --outputFile=<tmp>` from the repo root.
3. Parse the Jest-compatible JSON report and map each case title to its result.
4. Remove the copied file.

This module only shells out to Node and imports nothing from the repository, so
it runs under the isolated tooling interpreter with no `[pytest] command`
override.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import tempfile
from functools import lru_cache
from pathlib import Path

REPO_DIR = Path(os.environ.get("REPO_DIR", "/repo/t3code"))
PROVIDER_DIR = REPO_DIR / "apps" / "server" / "src" / "provider"
SOURCE_TEST = Path(__file__).with_name("catalog_probe.ts")
# A distinctive basename so cleanup is unambiguous and nothing pre-existing is
# ever overwritten. Ends in `.test.ts` so the runner treats it as a case file.
COPIED_NAME = "__ssb_catalog_check.test.ts"

RUN_TIMEOUT_SEC = 1100

# Case title (as emitted in the JSON report) → result key.
CASE_BY_KEY = {
    "catalog_race_recovered": "keeps Ultrafast when another Codex client wrote the shared catalog cache",
    "entitlement_loss_drops_tier": "drops Ultrafast once the account is no longer entitled to it",
    "user_originator_override_respected": "lets a caller-supplied client identity take precedence over the default",
    "session_spawn_uses_non_cli_originator": "sessions spawn the app-server under a non-CLI client identity",
}


@lru_cache(maxsize=1)
def _run() -> dict[str, bool]:
    """Run the catalog check once and return {case_title: passed}.

    Raises if the run could not produce a report at all (binary missing,
    compile failure, timeout) — that surfaces as an errored case rather than a
    silent pass.
    """
    copied = PROVIDER_DIR / COPIED_NAME
    report_handle, report_path = tempfile.mkstemp(prefix="t3-catalog-report-", suffix=".json")
    os.close(report_handle)
    report = Path(report_path)
    try:
        shutil.copyfile(SOURCE_TEST, copied)

        runner = REPO_DIR / "node_modules" / ".bin" / "vp"
        proc = subprocess.run(
            [str(runner), "test", "run", str(copied), "--reporter=json", f"--outputFile={report}"],
            capture_output=True,
            text=True,
            timeout=RUN_TIMEOUT_SEC,
            cwd=str(REPO_DIR),
            check=False,
        )

        if not report.exists() or report.stat().st_size == 0:
            raise RuntimeError(
                "test runner produced no JSON report "
                f"(exit {proc.returncode}).\n--- stdout ---\n{proc.stdout[-4000:]}\n"
                f"--- stderr ---\n{proc.stderr[-4000:]}"
            )

        data = json.loads(report.read_text())
        results: dict[str, bool] = {}
        for suite in data.get("testResults", []):
            for case in suite.get("assertionResults", []):
                results[case.get("title", "")] = case.get("status") == "passed"
        return results
    finally:
        for leftover in (copied, report):
            try:
                leftover.unlink()
            except OSError:
                pass


def _check(key: str) -> None:
    results = _run()
    title = CASE_BY_KEY[key]
    assert title in results, (
        f"case {title!r} did not appear in the test report; "
        f"observed cases: {sorted(results)}"
    )
    assert results[title], f"case {title!r} did not pass"


def test_catalog_race_recovered() -> None:
    _check("catalog_race_recovered")


def test_entitlement_loss_drops_tier() -> None:
    _check("entitlement_loss_drops_tier")


def test_user_originator_override_respected() -> None:
    _check("user_originator_override_respected")


def test_session_spawn_uses_non_cli_originator() -> None:
    _check("session_spawn_uses_non_cli_originator")
