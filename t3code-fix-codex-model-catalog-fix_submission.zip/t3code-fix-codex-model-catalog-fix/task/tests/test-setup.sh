#!/usr/bin/env bash
# test-setup.sh — environment bootstrap for the verifier.
#
# t3code is a pnpm workspace monorepo. Workspace packages export their
# `src/*.ts` directly (the `import` export condition points at source), so
# there is NO build step: an agent's `.ts` edit under apps/server is live the
# moment it is written and the verifier imports it directly. We therefore do
# NOT rebuild anything here.
#
# The suite runs through vite-plus (`vp test run`), NOT plain vitest: the repo
# patches `@effect/vitest` to import from `vite-plus/test`, and there is no
# `vitest` binary in node_modules/.bin — only `vp`. The verify.py wrapper
# invokes `node_modules/.bin/vp test run ...` directly for this reason.
#
# Sourced (not exec'd) by the harbor runner so env vars set here stay live for
# the verifier subprocess.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/t3code}"
export REPO_DIR
cd "$REPO_DIR"

# The canonical verifier venv (/opt/tooling/venv, Python 3.12) ships tomllib,
# so the verify.py wrapper parses any TOML config without an extra dependency.
# Nothing to install here.

# Sanity check: the vite-plus runner must be resolvable from the workspace
# root. A failure here means a corrupt node_modules — bail now with a clear
# message instead of a confusing "vp: not found" deep in the verifier.
if ! [ -x node_modules/.bin/vp ]; then
    echo "test-setup.sh: vite-plus (vp) binary missing from node_modules/.bin/. " \
         "The image build is corrupt." >&2
    exit 1
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR vp=$(node_modules/.bin/vp --version 2>/dev/null || echo unknown)"
