## Task

On accounts entitled to it, GPT-6.1 Sol's "Ultrafast" service tier keeps intermittently disappearing from the Codex model picker. When it drops out, any thread that was set to Ultrafast gets silently downgraded to a slower tier (Standard or Fast). Refreshing providers brings Ultrafast back, but only for a few minutes, and then it vanishes again. The flicker is recurring and we can't predict when it'll hit.

This needs fixing in how the server starts up and probes the Codex provider, because the catalog it publishes keeps coming out wrong and unstable. Don't paper over it by hardcoding, pinning, or force-adding Ultrafast (or any tier) into the catalog. The picker has to keep reflecting what the account is genuinely entitled to, so if an account really does lose a tier, that tier should still drop out.

For an entitled account, Ultrafast should stay in the picker consistently instead of flickering in and out, and threads should keep the tier they're set to.
