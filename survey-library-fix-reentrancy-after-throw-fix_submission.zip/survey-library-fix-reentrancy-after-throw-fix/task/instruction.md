## Task

We're getting customer reports that a survey can get permanently stuck
after a one-off error in their own code.

A customer has a custom validation function, a custom expression function
registered with the function factory, or an event handler such as an
`onValueChanged` / `onPropertyChanged` listener, and it throws once. The
exception surfaces to them as expected. But after that one throw, parts of
the survey quietly stop reacting for the rest of the session:

- conditional questions stop showing and hiding when values change;
- `setvalue` / `runexpression` triggers stop firing on later changes;
- a question that carries its choices from another question
  (`choicesFromQuestion`) stops updating when the source changes;
- the "other" option's comment text stops being saved;
- composite / custom question inner values stop reaching `survey.data`;
- a page mid-randomize stops tracking question visibility.

Reloading clears it, but until then the form is half-dead. The throw
itself is fine; it's everything after it that breaks. It reproduces
reliably: arm one of these functions to throw once, trigger it, then keep
using the survey and watch the affected behaviour go quiet.

Find out why a single exception from customer code leaves the survey
half-responsive and fix it, so that afterward the survey keeps behaving
normally while the exception still propagates to the caller as before.

Work is in the `packages/survey-core` package; its unit tests run under vitest against the model classes directly from source, so no build step is needed. Focused runs: `npx vitest run tests/<file>.ts`. <!-- lint: allow -->
