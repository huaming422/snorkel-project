// @ts-nocheck
//
// Behavioural verifier for: a single throw from customer code must not leave
// the survey half-responsive. Each guarded core operation runs user-supplied
// code (a registered expression function, a property/value-changed handler)
// behind an "I'm already inside this" re-entrancy guard. If the guard is only
// cleared on the normal exit path, a throw leaves it set and every later entry
// early-returns — the behaviour goes dead until reload.
//
// We exercise every scenario through the public survey-core model API only
// (SurveyModel / Question / PageModel): setValue, question visibility,
// triggers, randomizeElements, choicesFromQuestion, otherValue / getComment,
// composite contentPanel values, survey.data. We deliberately do NOT import
// the re-entrancy helper, reference any guard field by name, or inspect the
// submitted diff — the fix is observed black-box over the public surface, so
// reusing the repo's scope utility, hand-rolling try/finally, or any other
// decomposition are all accepted equally.
//
// How it separates fixed from unfixed: pre-fix each armed throw leaks its
// site's guard and the following same-family operation stays dead; post-fix
// the guard is cleared on
// the throwing exit and the later operation works again. The breadth is the
// point — seven independent sites across six modules each have their own case,
// so a one- or two-site fix still leaves most cases failing.
//
// The f2p cases ("later operation still works after a throw") and the single
// p2p case (normal no-throw runs stay correct, and the armed call still throws
// rather than being swallowed) together reject the two shortcuts: deleting the
// guard (changes normal behaviour) and swallowing the exception (the throw no
// longer reaches the caller).

import { describe, test, expect } from "vitest";
import { SurveyModel } from "../src/survey";
import { FunctionFactory } from "../src/functionsfactory";
import { Base } from "../src/base";
import { PageModel } from "../src/page";
import { QuestionRatingModel } from "../src/question_rating";
import { QuestionCheckboxModel } from "../src/question_checkbox";
import { QuestionRadiogroupModel } from "../src/question_radiogroup";
import { ComponentCollection, QuestionCompositeModel } from "../src/question_custom";

// A one-shot switch: throws the first time it is checked after arming, then
// disarms, so the very next operation runs clean. Mirrors the transient
// customer bug in the report (a handler that throws once).
function createThrowOnce(name: string): { arm: () => void, check: () => void } {
  let isArmed = false;
  return {
    arm: (): void => { isArmed = true; },
    check: (): void => {
      if (!isArmed) return;
      isArmed = false;
      throw new Error(name);
    },
  };
}

function registerThrowOnceFunction(name: string): { arm: () => void } {
  const throwOnce = createThrowOnce(name);
  FunctionFactory.Instance.register(name, (): boolean => {
    throwOnce.check();
    return true;
  });
  return throwOnce;
}

function throwOnPropertyChange(obj: Base, propertyName: string, errorText: string): { arm: () => void } {
  const throwOnce = createThrowOnce(errorText);
  obj.onPropertyChanged.add((_, options) => {
    if (options.name === propertyName) throwOnce.check();
  });
  return throwOnce;
}

describe("A single throw from customer code leaves the survey working", () => {
  // --- fail_to_pass: condition evaluation ---------------------------------
  test("conditions: after a custom function throws while conditions run, a later value change still re-evaluates visibility", () => {
    const fn = registerThrowOnceFunction("throwOnceInVisibleIf");
    try {
      const survey = new SurveyModel({ elements: [
        { type: "text", name: "q1" },
        { type: "text", name: "q2", visibleIf: "{q1} = 'a'" },
        { type: "text", name: "q3", visibleIf: "throwOnceInVisibleIf({q1})" },
      ] });
      const q2 = survey.getQuestionByName("q2");
      expect(q2.isVisible).toBe(false);
      fn.arm();
      expect(() => survey.setValue("q1", "x")).toThrow("throwOnceInVisibleIf");
      survey.setValue("q1", "a");
      expect(q2.isVisible).toBe(true);
    } finally {
      FunctionFactory.Instance.unregister("throwOnceInVisibleIf");
    }
  });

  // --- fail_to_pass: trigger running --------------------------------------
  test("triggers: after a custom function throws while triggers run, a later change still fires a setvalue trigger", () => {
    const fn = registerThrowOnceFunction("throwOnceInTrigger");
    try {
      const survey = new SurveyModel({
        elements: [{ type: "text", name: "q1" }, { type: "text", name: "q2" }],
        triggers: [
          { type: "runexpression", expression: "{q1} notempty", runExpression: "throwOnceInTrigger({q1})" },
          { type: "setvalue", expression: "{q1} = 'a'", setToName: "q2", setValue: "done" },
        ],
      });
      fn.arm();
      expect(() => survey.setValue("q1", "x")).toThrow("throwOnceInTrigger");
      survey.setValue("q1", "a");
      expect(survey.getValue("q2")).toBe("done");
    } finally {
      FunctionFactory.Instance.unregister("throwOnceInTrigger");
    }
  });

  // --- fail_to_pass: page randomization -----------------------------------
  test("randomization: after a property handler throws while a page randomizes, the page still tracks question visibility", () => {
    const survey = new SurveyModel({ pages: [{ name: "p1", elements: [
      { type: "text", name: "q1" }, { type: "text", name: "q2" }, { type: "text", name: "q3" },
    ] }] });
    const page = <PageModel>survey.pages[0];
    const q2 = survey.getQuestionByName("q2");
    const handler = throwOnPropertyChange(page, "rows", "throwOnRows");
    handler.arm();
    expect(() => page.randomizeElements(true)).toThrow("throwOnRows");
    const rowOfQ2 = page.rows.filter(row => row.elements.indexOf(q2) > -1)[0];
    expect(rowOfQ2.visible).toBe(true);
    q2.visible = false;
    expect(rowOfQ2.visible).toBe(false);
  });

  // --- fail_to_pass: dependent-property sync ------------------------------
  test("property sync: after a property handler throws while derived properties sync, a later driver change still syncs", () => {
    const survey = new SurveyModel({ elements: [{ type: "rating", name: "q1", rateMin: 1, rateMax: 5 }] });
    const q1 = <QuestionRatingModel>survey.getQuestionByName("q1");
    const handler = throwOnPropertyChange(q1, "rateMax", "throwOnRateMax");
    handler.arm();
    expect(() => { q1.rateCount = 3; }).toThrow("throwOnRateMax");
    q1.rateCount = 4;
    expect(q1.rateMax).toBe(4);
  });

  // --- fail_to_pass: carried-forward choices ------------------------------
  test("carried-forward choices: after a value-changed handler throws while dependent choices update, later source changes still propagate", () => {
    const survey = new SurveyModel({ elements: [
      { type: "checkbox", name: "q1", choices: ["a", "b", "c"] },
      { type: "checkbox", name: "q2", choicesFromQuestion: "q1" },
    ] });
    const q1 = <QuestionCheckboxModel>survey.getQuestionByName("q1");
    const q2 = <QuestionCheckboxModel>survey.getQuestionByName("q2");
    q2.value = ["c"];
    const throwOnce = createThrowOnce("throwOnQ2Change");
    survey.onValueChanged.add((_, options) => {
      if (options.name === "q2") throwOnce.check();
    });
    throwOnce.arm();
    expect(() => { q1.choices = ["a", "b"]; }).toThrow("throwOnQ2Change");
    expect(q2.visibleChoices.map(item => item.value)).toEqual(["a", "b"]);
    q1.choices = ["x"];
    expect(q2.visibleChoices.map(item => item.value)).toEqual(["x"]);
  });

  // --- fail_to_pass: other-item comment -----------------------------------
  test("other-item comment: after a value-changed handler throws while the other comment is set, later other values still persist", () => {
    const survey = new SurveyModel({ elements: [{ type: "radiogroup", name: "q1", choices: ["a"], showOtherItem: true }] });
    const q1 = <QuestionRadiogroupModel>survey.getQuestionByName("q1");
    q1.value = "other";
    const throwOnce = createThrowOnce("throwOnComment");
    survey.onValueChanged.add(() => { throwOnce.check(); });
    throwOnce.arm();
    expect(() => { q1.otherValue = "x"; }).toThrow("throwOnComment");
    q1.otherValue = "y";
    expect(q1.otherValue).toBe("y");
    expect(survey.getComment("q1")).toBe("y");
  });

  // --- fail_to_pass: composite inner value --------------------------------
  test("composite value: after a value-changed handler throws while a composite sets an inner value, later inner values still reach survey.data", () => {
    ComponentCollection.Instance.add({ name: "throwingcomposite", elementsJSON: [{ type: "text", name: "a" }, { type: "text", name: "b" }] });
    try {
      const survey = new SurveyModel({ elements: [{ type: "throwingcomposite", name: "q1" }] });
      const q1 = <QuestionCompositeModel>survey.getQuestionByName("q1");
      const throwOnce = createThrowOnce("throwOnCompositeChange");
      survey.onValueChanged.add(() => { throwOnce.check(); });
      throwOnce.arm();
      expect(() => { q1.contentPanel.getQuestionByName("a").value = 1; }).toThrow("throwOnCompositeChange");
      q1.contentPanel.getQuestionByName("b").value = 2;
      expect(survey.data).toEqual({ q1: { a: 1, b: 2 } });
    } finally {
      ComponentCollection.Instance.clear();
    }
  });

  // --- pass_to_pass: normal operation unchanged + exception not swallowed --
  // Runs every scenario once with NOTHING armed and asserts the ordinary
  // results hold (so a fix that deletes the guard, changing normal behaviour,
  // is rejected), and separately confirms every armed call above actually
  // threw (so a fix that swallows the exception is rejected). Keeping this as
  // one case makes the regression guard independent of the per-site f2p cases.
  test("normal operation is unchanged when nothing throws and armed calls still throw", () => {
    // conditions
    {
      const survey = new SurveyModel({ elements: [
        { type: "text", name: "q1" },
        { type: "text", name: "q2", visibleIf: "{q1} = 'a'" },
      ] });
      const q2 = survey.getQuestionByName("q2");
      expect(q2.isVisible).toBe(false);
      survey.setValue("q1", "a");
      expect(q2.isVisible).toBe(true);
    }
    // triggers
    {
      const survey = new SurveyModel({
        elements: [{ type: "text", name: "q1" }, { type: "text", name: "q2" }],
        triggers: [{ type: "setvalue", expression: "{q1} = 'a'", setToName: "q2", setValue: "done" }],
      });
      survey.setValue("q1", "a");
      expect(survey.getValue("q2")).toBe("done");
    }
    // randomization visibility tracking
    {
      const survey = new SurveyModel({ pages: [{ name: "p1", elements: [
        { type: "text", name: "q1" }, { type: "text", name: "q2" }, { type: "text", name: "q3" },
      ] }] });
      const page = <PageModel>survey.pages[0];
      const q2 = survey.getQuestionByName("q2");
      expect(page.randomizeElements(true)).toBe(true);
      const rowOfQ2 = page.rows.filter(row => row.elements.indexOf(q2) > -1)[0];
      expect(rowOfQ2.visible).toBe(true);
      q2.visible = false;
      expect(rowOfQ2.visible).toBe(false);
    }
    // property sync
    {
      const survey = new SurveyModel({ elements: [{ type: "rating", name: "q1", rateMin: 1, rateMax: 5 }] });
      const q1 = <QuestionRatingModel>survey.getQuestionByName("q1");
      q1.rateCount = 4;
      expect(q1.rateMax).toBe(4);
    }
    // carried-forward choices
    {
      const survey = new SurveyModel({ elements: [
        { type: "checkbox", name: "q1", choices: ["a", "b", "c"] },
        { type: "checkbox", name: "q2", choicesFromQuestion: "q1" },
      ] });
      const q1 = <QuestionCheckboxModel>survey.getQuestionByName("q1");
      const q2 = <QuestionCheckboxModel>survey.getQuestionByName("q2");
      expect(q2.visibleChoices.map(item => item.value)).toEqual(["a", "b", "c"]);
      q1.choices = ["x", "y"];
      expect(q2.visibleChoices.map(item => item.value)).toEqual(["x", "y"]);
    }
    // other-item comment
    {
      const survey = new SurveyModel({ elements: [{ type: "radiogroup", name: "q1", choices: ["a"], showOtherItem: true }] });
      const q1 = <QuestionRadiogroupModel>survey.getQuestionByName("q1");
      q1.value = "other";
      q1.otherValue = "z";
      expect(q1.otherValue).toBe("z");
      expect(survey.getComment("q1")).toBe("z");
    }
    // composite inner value
    {
      ComponentCollection.Instance.add({ name: "normalcomposite", elementsJSON: [{ type: "text", name: "a" }, { type: "text", name: "b" }] });
      try {
        const survey = new SurveyModel({ elements: [{ type: "normalcomposite", name: "q1" }] });
        const q1 = <QuestionCompositeModel>survey.getQuestionByName("q1");
        q1.contentPanel.getQuestionByName("a").value = 1;
        q1.contentPanel.getQuestionByName("b").value = 2;
        expect(survey.data).toEqual({ q1: { a: 1, b: 2 } });
      } finally {
        ComponentCollection.Instance.clear();
      }
    }
    // the exception is not swallowed: an armed throw-once still reaches the caller
    {
      const fn = registerThrowOnceFunction("throwOnceNotSwallowed");
      try {
        const survey = new SurveyModel({ elements: [
          { type: "text", name: "q1" },
          { type: "text", name: "q3", visibleIf: "throwOnceNotSwallowed({q1})" },
        ] });
        fn.arm();
        expect(() => survey.setValue("q1", "x")).toThrow("throwOnceNotSwallowed");
      } finally {
        FunctionFactory.Instance.unregister("throwOnceNotSwallowed");
      }
    }
  });
});
