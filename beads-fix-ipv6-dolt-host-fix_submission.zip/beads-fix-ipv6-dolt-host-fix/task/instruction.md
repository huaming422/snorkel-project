## Task

An operator can point bd at a Dolt server they run themselves, setting the host and port through the workspace metadata, an environment variable, the config file, or an `init` flag. That's fine for IPv4 or a DNS hostname, but the moment the host is an IPv6 address bd can't use the server at all: listing issues, serving, and the doctor diagnostics all fall over with host/port errors.

It makes no difference how the address is written. Bare (`::1`) or bracketed (`[::1]`), bd breaks either way, and the doctor and the regular commands don't even agree about which spelling is supposed to work. Both spellings should work and land on the same server.

A password an operator already saved for an IPv6 server must still be found once the host connects, in either spelling.

Leave the IPv4 and DNS-hostname paths exactly as they behave today. Also out of scope: the Dolt server bd starts for itself (it always listens on the IPv4 loopback `127.0.0.1`), and a host value that already carries its own port like `127.0.0.1:3307`. Dig in and fix the IPv6 case.
