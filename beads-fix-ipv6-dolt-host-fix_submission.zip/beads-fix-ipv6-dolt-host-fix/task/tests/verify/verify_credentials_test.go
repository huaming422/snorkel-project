package configfile

import (
	"io"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
)

// TestLookupCredentialsPassword_IPv6EitherSpelling checks that the credentials
// password lookup for an IPv6 host returns the stored password whether the
// host is written bare ("::1") or bracketed ("[::1]") — and whether the file's
// section header is written in the bracketed host:port form ([[::1]:3307]) or
// in the bare-joined legacy form ([::1:3307]). Both spellings name the same
// server, so the lookup has to agree whichever of the two section spellings
// the file uses. A surrounding-whitespace host is included because the host is
// classified and dialed trimmed. A different port must still miss.
func TestLookupCredentialsPassword_IPv6EitherSpelling(t *testing.T) {
	for _, tc := range []struct{ addr, section string }{
		{"::1", "[[::1]:3307]"},
		{"::1", "[::1:3307]"},
		{"2001:db8::1", "[[2001:db8::1]:3307]"},
		{"2001:db8::1", "[2001:db8::1:3307]"},
	} {
		t.Run(tc.section, func(t *testing.T) {
			credFile := filepath.Join(t.TempDir(), "credentials")
			if err := os.WriteFile(credFile, []byte(tc.section+"\npassword=ipv6Pass\n"), 0600); err != nil {
				t.Fatalf("failed to write credentials file: %v", err)
			}
			t.Setenv("BEADS_CREDENTIALS_FILE", credFile)

			for _, host := range []string{tc.addr, "[" + tc.addr + "]", " [" + tc.addr + "] "} {
				if got := LookupCredentialsPassword(host, 3307); got != "ipv6Pass" {
					t.Errorf("LookupCredentialsPassword(%q, 3307) = %q, want %q", host, got, "ipv6Pass")
				}
			}
			if got := LookupCredentialsPassword(tc.addr, 3308); got != "" {
				t.Errorf("LookupCredentialsPassword(%q, 3308) = %q, want no password for another port", tc.addr, got)
			}
		})
	}
}

// TestLookupCredentialsPassword_WarnsOnceForIPv6Host checks that a single
// lookup for an IPv6 host reads the credentials file — and so checks its
// permissions — exactly once, warning once about an overly permissive file,
// not once per candidate section spelling. The returned password is asserted
// alongside the warning count: for a bracketed host against the bare-joined
// legacy section, only a lookup that tries both section spellings returns the
// password at all, so the warning count is read on the code path that actually
// found it.
func TestLookupCredentialsPassword_WarnsOnceForIPv6Host(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("credentials file permissions are not checked on Windows")
	}
	credFile := filepath.Join(t.TempDir(), "credentials")
	if err := os.WriteFile(credFile, []byte("[::1:3307]\npassword=legacyPass\n"), 0600); err != nil {
		t.Fatalf("failed to write credentials file: %v", err)
	}
	if err := os.Chmod(credFile, 0644); err != nil {
		t.Fatalf("chmod: %v", err)
	}
	t.Setenv("BEADS_CREDENTIALS_FILE", credFile)

	for _, tc := range []struct{ host, want string }{
		{"::1", "legacyPass"},   // found under the legacy bare-joined section
		{"[::1]", "legacyPass"}, // same server, bracketed spelling
		{"2001:db8::1", ""},     // no section: both candidate spellings are tried
	} {
		t.Run(tc.host, func(t *testing.T) {
			var got string
			stderr := drainStderr(t, func() { got = LookupCredentialsPassword(tc.host, 3307) })
			if got != tc.want {
				t.Errorf("LookupCredentialsPassword(%q, 3307) = %q, want %q", tc.host, got, tc.want)
			}
			if n := strings.Count(stderr, "overly permissive permissions"); n != 1 {
				t.Errorf("permissions warning printed %d times, want once; stderr:\n%s", n, stderr)
			}
		})
	}
}

// drainStderr captures everything fn writes to os.Stderr and returns it.
func drainStderr(t *testing.T, fn func()) string {
	t.Helper()
	r, w, err := os.Pipe()
	if err != nil {
		t.Fatalf("pipe: %v", err)
	}
	orig := os.Stderr
	os.Stderr = w
	defer func() { os.Stderr = orig }()
	fn()
	if err := w.Close(); err != nil {
		t.Fatalf("close pipe: %v", err)
	}
	out, err := io.ReadAll(r)
	if err != nil {
		t.Fatalf("read pipe: %v", err)
	}
	return string(out)
}
