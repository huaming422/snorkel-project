package dolt

import (
	"context"
	"net"
	"sync/atomic"
	"testing"
)

// ipv6LoopbackProbe listens on an ephemeral port of the IPv6 loopback [::1],
// accepting and closing every connection until the test ends, and returns the
// port plus a count of the connections it has accepted. The count tells an
// address that was actually dialed from one that failed to parse before any
// dial happened. The test is skipped when this host has no IPv6 loopback.
func ipv6LoopbackProbe(t *testing.T) (port int, accepted func() int64) {
	t.Helper()
	ln, err := net.Listen("tcp", "[::1]:0")
	if err != nil {
		t.Skipf("IPv6 loopback not available: %v", err)
	}
	t.Cleanup(func() { _ = ln.Close() })
	var n atomic.Int64
	go func() {
		for {
			conn, err := ln.Accept()
			if err != nil {
				return
			}
			n.Add(1)
			_ = conn.Close()
		}
	}()
	return ln.Addr().(*net.TCPAddr).Port, n.Load
}

// TestServerMode_IPv6HostDialReachesServer checks that opening a server-mode
// store whose host is an IPv6 address actually dials that server, rather than
// failing on a malformed address before the dial. The store's connection path
// joins the configured host with its port to form the TCP address it dials; a
// bracketed IPv6 literal ("[::1]") joined as if it were a bare host yields the
// unusable "[[::1]]:port" and never reaches the server, which is the listing
// and serving outage the task is about. The store is opened against a plain
// IPv6 loopback listener in both the bracketed and the surrounding-whitespace
// spelling — the host is classified and dialed trimmed, so a padded spelling
// names the same server — and the listener must observe the connection. The
// open still ends in an error (the listener speaks no MySQL), but by then the
// dial has either reached the listener or never been attempted; only the
// address the connection path built decides which.
func TestServerMode_IPv6HostDialReachesServer(t *testing.T) {
	for _, host := range []string{"[::1]", " [::1] "} {
		t.Run(host, func(t *testing.T) {
			port, accepted := ipv6LoopbackProbe(t)

			cfg := &Config{
				Path:             t.TempDir(),
				BeadsDir:         t.TempDir(),
				Database:         "testdb_ipv6probe",
				ServerMode:       true,
				ServerHost:       host,
				ServerPort:       port,
				DisableAutoStart: true,
			}

			// The open fails downstream of the dial (the probe is not a real
			// Dolt server), so its error is deliberately not asserted on. What
			// is asserted is that the configured IPv6 host was dialed at all.
			if store, err := New(context.Background(), cfg); err == nil && store != nil {
				_ = store.Close()
			}

			if accepted() == 0 {
				t.Errorf("opening a store at IPv6 host %q never reached the server; "+
					"the connection path built an address it could not dial", host)
			}
		})
	}
}
