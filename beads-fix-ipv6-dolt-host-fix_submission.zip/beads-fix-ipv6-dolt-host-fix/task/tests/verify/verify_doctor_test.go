package doctor

import (
	"net"
	"sync/atomic"
	"testing"
)

// ipv6DoctorProbe listens on an ephemeral port of the IPv6 loopback [::1],
// accepting and closing every connection until the test ends, and returns the
// port plus a count of the connections it has accepted. The count tells an
// address that was actually dialed from one that failed to parse before any
// dial happened. The test is skipped when this host has no IPv6 loopback.
func ipv6DoctorProbe(t *testing.T) (port int, accepted func() int64) {
	t.Helper()
	ln, err := net.Listen("tcp", "[::1]:0")
	if err != nil {
		t.Skipf("IPv6 loopback not available: %v", err)
	}
	t.Cleanup(func() { _ = ln.Close() })
	var n atomic.Int64
	go func() {
		for {
			conn, err := ln.Accept()
			if err != nil {
				return
			}
			n.Add(1)
			_ = conn.Close()
		}
	}()
	return ln.Addr().(*net.TCPAddr).Port, n.Load
}

// TestDoctorLivenessProbe_IPv6HostReachesServer checks that the doctor's
// server-liveness probe reaches an IPv6 Dolt server configured in the bare
// spelling, so `bd doctor` reports it running and agrees with the regular
// commands about which spelling works. The probe forms the TCP address it
// dials from the configured host and port; a bare IPv6 literal ("::1") joined
// without bracketing yields the ambiguous "::1:port" and never reaches the
// server, so doctor reports a reachable server as down — the "doctor and the
// regular commands don't agree" half of the outage. The probe runs against a
// plain IPv6 loopback listener and must report the server reachable: the
// listener speaks no MySQL, but the probe reports reachable on a completed TCP
// dial, so a report of "running" is proof the dial reached the listener. The
// bare spelling is used because that is the one the probe's join breaks on; the
// bracketed spelling already dials for a host joined bare downstream, so it
// does not force this site's fix.
func TestDoctorLivenessProbe_IPv6HostReachesServer(t *testing.T) {
	port, accepted := ipv6DoctorProbe(t)

	if running := isDoltServerRunning("::1", port); !running {
		t.Errorf("doctor liveness probe reported the IPv6 server at ::1 not running; "+
			"the probe built an address it could not dial (accepted=%d)", accepted())
	}
	if accepted() == 0 {
		t.Errorf("doctor liveness probe for IPv6 host ::1 never reached the server; "+
			"the probe built an address it could not dial")
	}
}
