package server

import (
	"context"
	"net"
	"sync/atomic"
	"testing"
	"time"

	"github.com/steveyegge/beads/internal/configfile"
)

// ipv6DialProbe listens on an ephemeral port of the IPv6 loopback [::1],
// accepting and closing every connection until the test ends, and returns the
// port plus a count of the connections it has accepted. The count confirms an
// address that was actually dialed. The test is skipped when this host has no
// IPv6 loopback.
func ipv6DialProbe(t *testing.T) (port int, accepted func() int64) {
	t.Helper()
	ln, err := net.Listen("tcp", "[::1]:0")
	if err != nil {
		t.Skipf("IPv6 loopback not available: %v", err)
	}
	t.Cleanup(func() { _ = ln.Close() })
	var n atomic.Int64
	go func() {
		for {
			conn, err := ln.Accept()
			if err != nil {
				return
			}
			n.Add(1)
			_ = conn.Close()
		}
	}()
	return ln.Addr().(*net.TCPAddr).Port, n.Load
}

// TestExternalDoltServer_IPv6HostDialReachesServer checks that the proxied
// external-server path dials an IPv6 Dolt server rather than failing on a
// malformed address before the dial. The proxy forms the TCP address it dials
// by joining the configured external host with its port; a bracketed IPv6
// literal ("[::1]") joined as if it were a bare host yields the unusable
// "[[::1]]:port" that no dial can resolve, and serving in proxied mode never
// reaches the server — the serving-in-proxied-mode half of the outage. The
// external server is constructed through the package's public
// NewExternalDoltServer entry from an ExternalDoltConfig, the same struct the
// proxied-server config carries, so a host normalized where that config is
// consumed is exercised too. Dial runs against a plain IPv6 loopback listener
// in both the bracketed and the surrounding-whitespace spelling — the host is
// classified and dialed trimmed, so a padded spelling names the same server.
// The dial must succeed and land on the probe's port: the listener speaks no
// MySQL, but a completed TCP dial to that port proves the address the dial
// path built reached this server.
func TestExternalDoltServer_IPv6HostDialReachesServer(t *testing.T) {
	for _, host := range []string{"[::1]", " [::1] "} {
		t.Run(host, func(t *testing.T) {
			port, accepted := ipv6DialProbe(t)

			s, err := NewExternalDoltServer(configfile.ExternalDoltConfig{Host: host, Port: port})
			if err != nil {
				t.Fatalf("NewExternalDoltServer(host=%q): %v", host, err)
			}
			if err := s.Start(context.Background()); err != nil {
				t.Fatalf("Start: %v", err)
			}
			t.Cleanup(func() { _ = s.Stop(context.Background()) })

			conn, err := s.Dial(context.Background())
			if err != nil {
				t.Fatalf("proxied external-server dial to IPv6 host %q failed; "+
					"the dial path built an address it could not dial: %v", host, err)
			}
			remote := conn.RemoteAddr().(*net.TCPAddr)
			_ = conn.Close()

			if remote.Port != port {
				t.Errorf("proxied external-server dial to IPv6 host %q reached port %d, "+
					"not the configured server at [::1]:%d", host, remote.Port, port)
			}

			// Confirm the listener observed the connection (userspace Accept
			// trails the kernel handshake, so poll briefly rather than read once).
			if !waitAccepted(accepted) {
				t.Errorf("proxied external-server dial to IPv6 host %q never reached the server", host)
			}
		})
	}
}

// waitAccepted reports whether the probe accepted at least one connection,
// polling briefly because userspace Accept runs after the client's dial returns.
func waitAccepted(accepted func() int64) bool {
	deadline := time.Now().Add(2 * time.Second)
	for time.Now().Before(deadline) {
		if accepted() > 0 {
			return true
		}
		time.Sleep(10 * time.Millisecond)
	}
	return accepted() > 0
}
