package doltserver_test

import (
	"path/filepath"
	"strings"
	"testing"

	"github.com/steveyegge/beads/internal/config"
	"github.com/steveyegge/beads/internal/configfile"
	"github.com/steveyegge/beads/internal/doltserver"
)

// TestUnreachableEndpointAdvice_IPv6SingleBracket checks that the
// unreachable-server advice for an IPv6 host names the endpoint as the
// canonical [host]:port, never the double-bracketed [[host]]:port that results
// from bracketing an already-bracketed literal, and never the bare-joined
// host:port with no brackets. The host is exercised both bare ("::1") and
// bracketed ("[::1]"): the same server is named the same way either way.
func TestUnreachableEndpointAdvice_IPv6SingleBracket(t *testing.T) {
	const port = 3309
	for _, host := range []string{"::1", "[::1]"} {
		t.Run(host, func(t *testing.T) {
			resetServerClassificationEnv(t)
			dir := newExternalPortWorkspace(t, port)

			msg := doltserver.UnreachableEndpointAdvice(dir, host, port, doltserver.PortSourceMetadataJSON)
			if msg == "" {
				t.Fatalf("UnreachableEndpointAdvice(%q, %d) returned no advice", host, port)
			}
			if !strings.Contains(msg, "[::1]:3309") {
				t.Errorf("advice for host %q should name the endpoint [::1]:3309; got: %s", host, msg)
			}
			if strings.Contains(msg, "[[::1]]") {
				t.Errorf("advice for host %q double-brackets the endpoint; got: %s", host, msg)
			}
			if strings.Contains(msg, " ::1:3309") {
				t.Errorf("advice for host %q names the endpoint unbracketed; got: %s", host, msg)
			}
		})
	}
}

// resetServerClassificationEnv clears every setting that classifies a
// workspace's Dolt server, so a case names exactly the one it configures.
// Mirrors the package's own test-env reset through the exported config API.
func resetServerClassificationEnv(t *testing.T) {
	t.Helper()
	home := t.TempDir()
	t.Setenv("HOME", home)
	t.Setenv("USERPROFILE", home)
	t.Setenv("BEADS_SHARED_SERVER_DIR", filepath.Join(home, "shared-server"))
	for _, name := range []string{
		"BEADS_DOLT_SERVER_MODE", "BEADS_DOLT_SHARED_SERVER", "BEADS_DOLT_SERVER_HOST",
		"BEADS_DOLT_SERVER_PORT", "BEADS_DOLT_PORT", "BEADS_DOLT_AUTO_START",
	} {
		t.Setenv(name, "")
	}
	config.ResetForTesting()
	t.Cleanup(config.ResetForTesting)
}

// newExternalPortWorkspace writes a .beads workspace whose persisted
// server-mode metadata names metadataPort, so the workspace's Dolt server is
// classified as externally managed on that port — the state under which the
// unreachable-server advice names the endpoint.
func newExternalPortWorkspace(t *testing.T, metadataPort int) string {
	t.Helper()
	dir := t.TempDir()
	cfg := configfile.DefaultConfig()
	cfg.Backend = configfile.BackendDolt
	cfg.DoltMode = configfile.DoltModeServer
	cfg.DoltServerPort = metadataPort
	if err := cfg.Save(dir); err != nil {
		t.Fatal(err)
	}
	return dir
}
