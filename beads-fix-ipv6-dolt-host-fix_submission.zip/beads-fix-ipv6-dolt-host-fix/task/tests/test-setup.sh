#!/usr/bin/env bash
# All required dependencies are baked into the image at the base commit: the
# Go 1.26.10 toolchain, build-essential + libicu-dev for cgo, and a prewarmed
# Go module + build cache (go mod download / go build / go test compiled the
# whole tree). The verifier only needs `go test` against pre-existing exported
# interfaces (DSN builders, credentials lookup, advice builder) plus a plain
# IPv6 loopback TCP listener — no real Dolt server, no extra packages, no
# network. Nothing to do at verifier time.
set -euo pipefail
echo "[test-setup] no-op for beads-fix-ipv6-dolt-host"
