// Structural verifier for cozystack-fix-restore-pvc-deletion (C6).
//
// The read-back-after-delete that drives the wait issues a Get on CDI
// DataVolumes. The in-memory fakes run unauthorized, so a missing RBAC verb
// only bites on a real cluster -- hence this static chart assertion: the
// backupstrategy-controller ClusterRole must grant the controller both get and
// delete on cdi.kubevirt.io datavolumes (pre-fix it grants delete only).
//
// The template is plain YAML (no Helm directives), so it is parsed directly.
// This file is injected into internal/backupcontroller/ and compiles as part of
// package backupcontroller; Go runs the test with its working directory set to
// that package, so the chart path is resolved relative to the module root found
// by walking up to go.mod.
package backupcontroller

import (
	"os"
	"path/filepath"
	"testing"

	"sigs.k8s.io/yaml"
)

func vfyModuleRoot(t *testing.T) string {
	t.Helper()
	dir, err := os.Getwd()
	if err != nil {
		t.Fatalf("getwd: %v", err)
	}
	for {
		if _, err := os.Stat(filepath.Join(dir, "go.mod")); err == nil {
			return dir
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			t.Fatalf("could not locate module root (go.mod) above the test working directory")
		}
		dir = parent
	}
}

type vfyClusterRole struct {
	Rules []struct {
		APIGroups []string `json:"apiGroups"`
		Resources []string `json:"resources"`
		Verbs     []string `json:"verbs"`
	} `json:"rules"`
}

// C6: the controller ClusterRole grants get AND delete on cdi.kubevirt.io
// datavolumes, so the read-back-after-delete that drives the wait is authorized.
func TestVerifyRBAC_DataVolumesGrantGetAndDelete(t *testing.T) {
	path := filepath.Join(vfyModuleRoot(t),
		"packages", "system", "backupstrategy-controller", "templates", "rbac.yaml")

	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read ClusterRole template %s: %v", path, err)
	}

	var role vfyClusterRole
	if err := yaml.Unmarshal(raw, &role); err != nil {
		t.Fatalf("parse ClusterRole template: %v", err)
	}

	wantVerbs := []string{"get", "delete"}
	found := false
	for _, rule := range role.Rules {
		if !vfyContains(rule.APIGroups, "cdi.kubevirt.io") || !vfyContains(rule.Resources, "datavolumes") {
			continue
		}
		found = true
		for _, want := range wantVerbs {
			if !vfyContains(rule.Verbs, want) {
				t.Errorf("cdi.kubevirt.io/datavolumes rule is missing the %q verb; verbs = %v", want, rule.Verbs)
			}
		}
	}
	if !found {
		t.Error("no ClusterRole rule grants any verb on cdi.kubevirt.io/datavolumes")
	}
}

func vfyContains(haystack []string, needle string) bool {
	for _, s := range haystack {
		if s == needle {
			return true
		}
	}
	return false
}
