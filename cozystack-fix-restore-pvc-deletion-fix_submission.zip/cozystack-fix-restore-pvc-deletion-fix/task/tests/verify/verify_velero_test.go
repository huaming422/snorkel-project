// Behavioral verifier for cozystack-fix-restore-pvc-deletion.
//
// This file is injected into internal/backupcontroller/ at run time and
// compiles as part of package backupcontroller, alongside the package's own
// sibling test files (it reuses their helpers: newTestRestoreJobReconciler,
// newTestRestoreJobReconcilerWithDynamic, mockRESTMapper). The runner filters
// -run to this file's Test* functions.
//
// The tests drive the two package-level entry points the reconciler already
// exposes -- prepareForRestore and reconcileVeleroRestore -- and assert only on
// resulting object state (PVC existence/deletionTimestamp read back through the
// client, DataVolume presence through the dynamic client, RestoreJob phase, VM
// runStrategy through the dynamic client, and ctrl.Result.RequeueAfter). They
// never reference the fix's internal helper names, never match on recorded
// Event strings, and never require a particular requeue duration (only that one
// is requested). Any arrangement of the behavior -- inlined, renamed helpers, a
// single combined wait loop, the up-front usability check folded elsewhere --
// satisfies them.
package backupcontroller

import (
	"context"
	"encoding/json"
	"testing"

	corev1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime"
	dynamicfake "k8s.io/client-go/dynamic/fake"
	"k8s.io/client-go/kubernetes/scheme"
	k8stesting "k8s.io/client-go/testing"
	"sigs.k8s.io/controller-runtime/pkg/client"
	clientfake "sigs.k8s.io/controller-runtime/pkg/client/fake"

	strategyv1alpha1 "github.com/cozystack/cozystack/api/backups/strategy/v1alpha1"
	backupsv1alpha1 "github.com/cozystack/cozystack/api/backups/v1alpha1"
	velerov1 "github.com/vmware-tanzu/velero/pkg/apis/velero/v1"
)

// vfyInPlaceNoKeep returns the inputs for an in-place VMInstance restore of a
// single disk (vm-disk-ubuntu-source) with keepOriginalPVC=false.
func vfyInPlaceNoKeep(ns string) (*backupsv1alpha1.RestoreJob, *backupsv1alpha1.Backup, *runtime.RawExtension, restoreTarget, RestoreOptions) {
	restoreJob := &backupsv1alpha1.RestoreJob{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "restore-test",
			Namespace: ns,
		},
		Spec: backupsv1alpha1.RestoreJobSpec{
			BackupRef: corev1.LocalObjectReference{Name: "my-backup"},
		},
	}

	backup := &backupsv1alpha1.Backup{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "my-backup",
			Namespace: ns,
		},
		Spec: backupsv1alpha1.BackupSpec{
			ApplicationRef: corev1.TypedLocalObjectReference{
				APIGroup: new("apps.cozystack.io"),
				Kind:     "VMInstance",
				Name:     "test-vm",
			},
		},
	}

	urData := vmInstanceResources{
		DataVolumes: []backupsv1alpha1.DataVolumeResource{
			{DataVolumeName: "vm-disk-ubuntu-source", ApplicationName: "ubuntu-source"},
		},
	}
	urRaw, _ := json.Marshal(urData)

	target := restoreTarget{
		Namespace: ns,
		AppName:   "test-vm",
		AppKind:   "VMInstance",
		IsCopy:    false,
	}

	return restoreJob, backup, &runtime.RawExtension{Raw: urRaw}, target, RestoreOptions{KeepOriginalPVC: new(false)}
}

// vfyMakeDataVolume builds an unstructured CDI DataVolume for the dynamic fake.
func vfyMakeDataVolume(name, namespace string) *unstructured.Unstructured {
	dv := &unstructured.Unstructured{}
	dv.SetAPIVersion("cdi.kubevirt.io/v1beta1")
	dv.SetKind("DataVolume")
	dv.SetName(name)
	dv.SetNamespace(namespace)
	return dv
}

// vfyDriveToReady calls prepareForRestore until it reports ready, tolerating any
// number of requeue cycles (an implementation may stage the deletions across
// reconciles). It fails if preparation errors, stalls without requesting a
// requeue, or never completes.
func vfyDriveToReady(t *testing.T, r *RestoreJobReconciler, rj *backupsv1alpha1.RestoreJob, b *backupsv1alpha1.Backup, ur *runtime.RawExtension, target restoreTarget, opts RestoreOptions) {
	t.Helper()
	ctx := context.Background()
	for i := 0; i < 20; i++ {
		ready, result, err := r.prepareForRestore(ctx, rj, b, ur, target, opts)
		if err != nil {
			t.Fatalf("prepareForRestore() error = %v", err)
		}
		if ready {
			return
		}
		if result.RequeueAfter == 0 {
			t.Fatalf("prepareForRestore() reported not-ready without requesting a requeue")
		}
	}
	t.Fatalf("prepareForRestore() never reached ready within the iteration budget")
}

// C1: an in-place keepOriginalPVC=false restore removes the original claim
// during preparation (so Velero recreates it from the backup) rather than
// leaving it in place, and it does not rename it to an -orig copy either.
func TestVerifyPrepareForRestore_KeepOriginalPVCFalse_DeletesPVC(t *testing.T) {
	ns := "tenant-root"
	restoreJob, backup, ur, target, opts := vfyInPlaceNoKeep(ns)

	pvc := &corev1.PersistentVolumeClaim{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "vm-disk-ubuntu-source",
			Namespace: ns,
		},
		Spec: corev1.PersistentVolumeClaimSpec{},
	}

	reconciler := newTestRestoreJobReconciler(t, pvc, restoreJob, backup)
	vfyDriveToReady(t, reconciler, restoreJob, backup, ur, target, opts)

	ctx := context.Background()
	err := reconciler.Get(ctx, client.ObjectKey{Namespace: ns, Name: "vm-disk-ubuntu-source"}, &corev1.PersistentVolumeClaim{})
	if !errors.IsNotFound(err) {
		t.Errorf("original PVC should be gone before Velero restores it when keepOriginalPVC=false, got error: %v", err)
	}

	origSuffix := "-orig-" + shortHash(restoreJob.Name)
	err = reconciler.Get(ctx, client.ObjectKey{Namespace: ns, Name: "vm-disk-ubuntu-source" + origSuffix}, &corev1.PersistentVolumeClaim{})
	if err == nil {
		t.Error("no renamed -orig PVC should exist when keepOriginalPVC=false")
	}
}

// C2: preparation must not report ready while a claim it is removing is still
// terminating. A PVC held by the pvc-protection finalizer keeps preparation
// requeuing (and the claim is marked for deletion but still present); only once
// the claim is actually gone does preparation complete.
func TestVerifyPrepareForRestore_KeepOriginalPVCFalse_WaitsForTerminatingPVC(t *testing.T) {
	ns := "tenant-root"
	restoreJob, backup, ur, target, opts := vfyInPlaceNoKeep(ns)

	pvc := &corev1.PersistentVolumeClaim{
		ObjectMeta: metav1.ObjectMeta{
			Name:       "vm-disk-ubuntu-source",
			Namespace:  ns,
			Finalizers: []string{"kubernetes.io/pvc-protection"},
		},
		Spec: corev1.PersistentVolumeClaimSpec{},
	}

	reconciler := newTestRestoreJobReconciler(t, pvc, restoreJob, backup)
	ctx := context.Background()

	ready, result, err := reconciler.prepareForRestore(ctx, restoreJob, backup, ur, target, opts)
	if err != nil {
		t.Fatalf("prepareForRestore() error = %v", err)
	}
	if ready {
		t.Fatal("expected not-ready while the PVC is still terminating, got ready")
	}
	if result.RequeueAfter == 0 {
		t.Error("expected a requeue while the PVC is still terminating")
	}

	stuck := &corev1.PersistentVolumeClaim{}
	if err := reconciler.Get(ctx, client.ObjectKey{Namespace: ns, Name: "vm-disk-ubuntu-source"}, stuck); err != nil {
		t.Fatalf("terminating PVC should still be readable: %v", err)
	}
	if stuck.DeletionTimestamp == nil {
		t.Fatal("PVC should have been marked for deletion while preparation waits")
	}

	stuck.Finalizers = nil
	if err := reconciler.Update(ctx, stuck); err != nil {
		t.Fatalf("failed to release the PVC finalizer: %v", err)
	}

	ready, _, err = reconciler.prepareForRestore(ctx, restoreJob, backup, ur, target, opts)
	if err != nil {
		t.Fatalf("prepareForRestore() error = %v", err)
	}
	if !ready {
		t.Fatal("expected ready once the PVC is gone, got not-ready")
	}
}

// C3: while a disk's DataVolume still exists, its PVC must be preserved (a
// surviving DataVolume makes CDI recreate the claim, which Velero then skips).
// A DataVolume deletion that errors fails the restore; a deletion still pending
// keeps it requeuing. In neither case is the PVC removed.
func TestVerifyPrepareForRestore_KeepOriginalPVCFalse_KeepsPVCWhileDataVolumeRemains(t *testing.T) {
	tests := []struct {
		name      string
		deleteErr error
		wantErr   bool
	}{
		{
			name:      "DataVolume deletion fails",
			deleteErr: errors.NewForbidden(dataVolumeGVR.GroupResource(), "vm-disk-ubuntu-source", nil),
			wantErr:   true,
		},
		{
			name: "DataVolume deletion is still pending",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ns := "tenant-root"
			restoreJob, backup, ur, target, opts := vfyInPlaceNoKeep(ns)
			pvc := &corev1.PersistentVolumeClaim{
				ObjectMeta: metav1.ObjectMeta{Name: "vm-disk-ubuntu-source", Namespace: ns},
			}
			reconciler := newTestRestoreJobReconcilerWithDynamic(t,
				[]runtime.Object{vfyMakeDataVolume("vm-disk-ubuntu-source", ns)},
				pvc, restoreJob, backup)
			reconciler.Interface.(*dynamicfake.FakeDynamicClient).PrependReactor("delete", "datavolumes",
				func(k8stesting.Action) (bool, runtime.Object, error) {
					return true, nil, tt.deleteErr
				})

			ctx := context.Background()
			ready, result, err := reconciler.prepareForRestore(ctx, restoreJob, backup, ur, target, opts)
			if tt.wantErr {
				if err == nil {
					t.Fatal("expected an error when the DataVolume cannot be deleted")
				}
			} else {
				if err != nil {
					t.Fatalf("prepareForRestore() error = %v", err)
				}
				if result.RequeueAfter == 0 {
					t.Error("expected a requeue while the DataVolume is still present")
				}
			}
			if ready {
				t.Fatal("expected not-ready while the DataVolume is still present")
			}

			got := &corev1.PersistentVolumeClaim{}
			if err := reconciler.Get(ctx, client.ObjectKeyFromObject(pvc), got); err != nil {
				t.Fatalf("original PVC should survive while its DataVolume remains: %v", err)
			}
			if got.DeletionTimestamp != nil {
				t.Error("original PVC should not be marked for deletion while its DataVolume remains")
			}
		})
	}
}

// C5 (regression guard): keepOriginalPVC=true must never delete the original
// claim, even when the rename that would preserve it fails (its bound PV is
// missing) and leaves the claim under its original name.
func TestVerifyPrepareForRestore_KeepOriginalPVCTrue_FailedRenameKeepsPVC(t *testing.T) {
	ns := "tenant-root"
	restoreJob, backup, ur, target, _ := vfyInPlaceNoKeep(ns)
	opts := RestoreOptions{KeepOriginalPVC: new(true)}

	pvc := &corev1.PersistentVolumeClaim{
		ObjectMeta: metav1.ObjectMeta{Name: "vm-disk-ubuntu-source", Namespace: ns},
		// The bound PV does not exist, so the rename fails before touching the claim.
		Spec: corev1.PersistentVolumeClaimSpec{VolumeName: "pv-missing"},
	}
	reconciler := newTestRestoreJobReconciler(t, pvc, restoreJob, backup)

	ctx := context.Background()
	if _, _, err := reconciler.prepareForRestore(ctx, restoreJob, backup, ur, target, opts); err != nil {
		t.Fatalf("prepareForRestore() error = %v", err)
	}

	if err := reconciler.Get(ctx, client.ObjectKeyFromObject(pvc), &corev1.PersistentVolumeClaim{}); err != nil {
		t.Errorf("original PVC should survive a failed rename when keepOriginalPVC=true, got error: %v", err)
	}
}

// C4: a restore whose referenced Velero Backup is unusable (missing/expired, or
// not in the Completed phase) must fail the RestoreJob before preparation halts
// the VM or deletes any disk. The VM runStrategy, the DataVolume, and the PVC
// are all left untouched.
func TestVerifyReconcileVeleroRestore_UnusableVeleroBackupTouchesNothing(t *testing.T) {
	tests := []struct {
		name         string
		veleroBackup *velerov1.Backup
	}{
		{
			name: "Velero Backup expired",
		},
		{
			name: "Velero Backup being deleted",
			veleroBackup: &velerov1.Backup{
				ObjectMeta: metav1.ObjectMeta{Name: "vb", Namespace: veleroNamespace},
				Status:     velerov1.BackupStatus{Phase: velerov1.BackupPhaseDeleting},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ns := "tenant-root"
			restoreJob, backup, ur, _, opts := vfyInPlaceNoKeep(ns)
			rawOpts, err := json.Marshal(opts)
			if err != nil {
				t.Fatalf("marshal options: %v", err)
			}
			started := metav1.Now()
			restoreJob.Spec.Options = &runtime.RawExtension{Raw: rawOpts}
			restoreJob.Status = backupsv1alpha1.RestoreJobStatus{
				Phase:     backupsv1alpha1.RestoreJobPhaseRunning,
				StartedAt: &started,
			}
			backup.Spec.StrategyRef = corev1.TypedLocalObjectReference{Kind: "Velero", Name: "cozy-default-velero"}
			backup.Spec.DriverMetadata = map[string]string{veleroBackupNameMetadataKey: "vb"}
			backup.Status.UnderlyingResources = ur

			pvc := &corev1.PersistentVolumeClaim{
				ObjectMeta: metav1.ObjectMeta{Name: "vm-disk-ubuntu-source", Namespace: ns},
			}
			strategy := &strategyv1alpha1.Velero{ObjectMeta: metav1.ObjectMeta{Name: "cozy-default-velero"}}
			objs := []client.Object{restoreJob, backup, pvc, strategy}
			if tt.veleroBackup != nil {
				objs = append(objs, tt.veleroBackup)
			}

			vm := &unstructured.Unstructured{}
			vm.SetAPIVersion("kubevirt.io/v1")
			vm.SetKind("VirtualMachine")
			vm.SetName(vmNamePrefix + "test-vm")
			vm.SetNamespace(ns)
			if err := unstructured.SetNestedField(vm.Object, "Always", "spec", "runStrategy"); err != nil {
				t.Fatalf("set runStrategy: %v", err)
			}

			reconciler := newTestRestoreJobReconcilerWithDynamic(t,
				[]runtime.Object{vm, vfyMakeDataVolume("vm-disk-ubuntu-source", ns)})

			testScheme := runtime.NewScheme()
			_ = scheme.AddToScheme(testScheme)
			_ = backupsv1alpha1.AddToScheme(testScheme)
			_ = velerov1.AddToScheme(testScheme)
			_ = strategyv1alpha1.AddToScheme(testScheme)
			reconciler.Client = clientfake.NewClientBuilder().
				WithScheme(testScheme).
				WithObjects(objs...).
				WithStatusSubresource(&backupsv1alpha1.RestoreJob{}).
				Build()

			ctx := context.Background()
			if _, err := reconciler.reconcileVeleroRestore(ctx, restoreJob, backup); err != nil {
				t.Fatalf("reconcileVeleroRestore() error = %v", err)
			}

			got := &backupsv1alpha1.RestoreJob{}
			if err := reconciler.Get(ctx, client.ObjectKeyFromObject(restoreJob), got); err != nil {
				t.Fatalf("get RestoreJob: %v", err)
			}
			if got.Status.Phase != backupsv1alpha1.RestoreJobPhaseFailed {
				t.Fatalf("RestoreJob phase = %q, want %q", got.Status.Phase, backupsv1alpha1.RestoreJobPhaseFailed)
			}

			if err := reconciler.Get(ctx, client.ObjectKeyFromObject(pvc), &corev1.PersistentVolumeClaim{}); err != nil {
				t.Errorf("original PVC should survive a restore that cannot run: %v", err)
			}
			if _, err := reconciler.Resource(dataVolumeGVR).Namespace(ns).Get(ctx, "vm-disk-ubuntu-source", metav1.GetOptions{}); err != nil {
				t.Errorf("DataVolume should survive a restore that cannot run: %v", err)
			}
			gotVM, err := reconciler.Resource(virtualMachineGVR).Namespace(ns).Get(ctx, vm.GetName(), metav1.GetOptions{})
			if err != nil {
				t.Fatalf("get VirtualMachine: %v", err)
			}
			if rs, _, _ := unstructured.NestedString(gotVM.Object, "spec", "runStrategy"); rs != "Always" {
				t.Errorf("VirtualMachine runStrategy = %q, want it left at %q", rs, "Always")
			}
		})
	}
}
