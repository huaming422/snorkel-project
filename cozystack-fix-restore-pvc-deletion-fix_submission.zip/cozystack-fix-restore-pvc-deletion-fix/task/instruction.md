## Task

we restore tenant VMs from Velero backups. when someone restores a
VMInstance in place and does not ask to keep the original disks
(keepOriginalPVC is false), the restore is supposed to throw away each
disk's current contents and bring the backup data back in its place.

that's not what's happening. the restore reports Succeeded, but every
disk still holds exactly the data it had before. nothing actually came
back from the backup. and the disks it touched then get stuck: the VM's
HelmRelease goes Ready=False and stays there, and its DataVolume keeps
getting rejected with "Destination PVC <namespace>/<name> already
exists". deleting the disk by hand and recreating one with the same name
fails the same way.

so from the operator's side it's a green restore that silently kept the
old data and bricked the disk.

please track down why an in-place restore without keepOriginalPVC leaves
the old disk in place instead of letting the backup be restored, and fix
it. with keepOriginalPVC=true, operators are deliberately holding
onto the original disk, so that path should still leave it in place.
