// @ts-nocheck
//
// Behavioral verifier — server-side authoring normalization. Runs inside the
// server package via its own vitest.config.js (config_dir in verify.toml) so
// the @modelcontextprotocol/core-internal alias resolves to src/ and the real
// Server round-trips over an in-memory transport — no dist build, no mocks.
//
// Interface exercised (pre-existing, stable): a real `new Server(...)` with a
// `tools/call` request handler, driven through InMemoryTransport exactly as the
// SDK's own server tests drive it. We assert the wire response only — the
// defaulted `content: []` on a content-less plain result, or the `-32602`
// error on a result the server must not normalize. No fix-introduced internal
// symbol is imported; the normalizer is observed purely through its wire effect.

import { describe, expect, it } from 'vitest';

import type { CallToolResult, JSONRPCMessage } from '@modelcontextprotocol/core-internal';
import { InMemoryTransport, LATEST_PROTOCOL_VERSION } from '@modelcontextprotocol/core-internal';
import { Server } from '../../src/server/server';

// Mirrors packages/server/test/server/server.test.ts :: callToolOnServer.
// A fresh server whose tools/call handler returns `result`; drive initialize →
// notifications/initialized → tools/call (id 2) and return the id-2 response.
async function callToolOnServer(result: unknown): Promise<JSONRPCMessage> {
    const server = new Server({ name: 'test', version: '1.0.0' }, { capabilities: { tools: {} } });
    server.setRequestHandler('tools/call', () => result as CallToolResult);

    const [clientTransport, serverTransport] = InMemoryTransport.createLinkedPair();
    const received: JSONRPCMessage[] = [];
    clientTransport.onmessage = message => void received.push(message);
    await server.connect(serverTransport);
    await clientTransport.start();

    await clientTransport.send({
        jsonrpc: '2.0',
        id: 1,
        method: 'initialize',
        params: {
            protocolVersion: LATEST_PROTOCOL_VERSION,
            capabilities: {},
            clientInfo: { name: 'test-client', version: '1.0.0' }
        }
    });
    await clientTransport.send({ jsonrpc: '2.0', method: 'notifications/initialized' });
    await clientTransport.send({ jsonrpc: '2.0', id: 2, method: 'tools/call', params: { name: 'echo', arguments: {} } });
    await new Promise(resolve => setTimeout(resolve, 10));
    await server.close();

    const response = received.find(message => (message as { id?: unknown }).id === 2);
    if (!response) {
        throw new Error('no tools/call response received');
    }
    return response;
}

describe('typescript-sdk-fix-tool-result-content :: server handler normalization', () => {
    // ── FAIL-TO-PASS — server_normalizes_plain ───────────────────────────
    // A content-less PLAIN handler result yields a wire result with content: []
    // (era-independent normalization before validation); structuredContent is
    // preserved. Pre-fix the handler result is rejected with -32602.
    it('[server_normalizes_plain] a structured-only handler result reaches the wire as content: []', async () => {
        const response = await callToolOnServer({ structuredContent: { ok: true } });
        const result = (response as { result?: { content?: unknown; structuredContent?: unknown } }).result;
        expect(result, `expected a result, got ${JSON.stringify(response)}`).toBeDefined();
        expect(result!.content).toEqual([]);
        expect(result!.structuredContent).toEqual({ ok: true });
    });

    it('[server_normalizes_plain] an authored-content handler result passes through unchanged', async () => {
        // Pins that normalization does not disturb a result that already carries
        // content — the happy path still round-trips verbatim.
        const response = await callToolOnServer({
            content: [{ type: 'text', text: 'hi' }],
            structuredContent: { ok: true }
        });
        const result = (response as { result?: { content?: unknown; structuredContent?: unknown } }).result;
        expect(result, `expected a result, got ${JSON.stringify(response)}`).toBeDefined();
        expect(result!.content).toEqual([{ type: 'text', text: 'hi' }]);
        expect(result!.structuredContent).toEqual({ ok: true });
    });

    // ── FAIL-TO-PASS — server_rejects_nonplain ───────────────────────────
    // The server does NOT normalize non-plain or foreign-family handler
    // results: an array result, and a foreign-family body (including one with an
    // explicit content: undefined), are rejected with -32602. Guards the
    // server-side half of the foreign-family hazard: an over-broad normalizer
    // that defaulted these would score this case wrong.
    it('[server_rejects_nonplain] an array handler result is rejected with -32602', async () => {
        const response = await callToolOnServer([{ type: 'text', text: 'hi' }]);
        const error = (response as { error?: { code: number } }).error;
        expect(error, `expected an error, got ${JSON.stringify(response)}`).toBeDefined();
        expect(error!.code).toBe(-32602);
    });

    it('[server_rejects_nonplain] a foreign-family body with an explicit content: undefined is rejected with -32602', async () => {
        const response = await callToolOnServer({ task: { taskId: 't-1', status: 'working' }, content: undefined });
        const error = (response as { error?: { code: number } }).error;
        expect(error, `expected an error, got ${JSON.stringify(response)}`).toBeDefined();
        expect(error!.code).toBe(-32602);
    });

    it('[server_rejects_nonplain] an inputRequests-family handler body is rejected with -32602', async () => {
        const response = await callToolOnServer({ inputRequests: { r1: { method: 'elicitation/create' } } });
        const error = (response as { error?: { code: number } }).error;
        expect(error, `expected an error, got ${JSON.stringify(response)}`).toBeDefined();
        expect(error!.code).toBe(-32602);
    });
});
