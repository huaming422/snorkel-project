// @ts-nocheck
//
// Behavioral verifier — legacy-era content-less tool-result tolerance, the
// era split, and the foreign-family guard, exercised through the END-TO-END
// inbound client path. Runs inside the core-internal package via its own
// vitest.config.js (config_dir in verify.toml), so the workspace resolves to
// src/ through vite-tsconfig-paths — no dist build.
//
// The reported symptom is observable on the client request path: a client
// talking to a legacy-era server receives the server's result, and that result
// is decoded and validated before it is handed back to the caller. We drive
// that exact path — a `Protocol.request({ method: 'tools/call' })` over an
// in-memory transport whose peer answers with a scripted raw result body, with
// the negotiated era pinned the same way the SDK's own wire tests pin it
// (`setNegotiatedProtocolVersion`, mirroring test/shared/rawResultTypeFirst and
// test/wire/eraGates). Asserting on the resolved value / rejection — rather than
// on any one internal schema or codec seam — lets the verifier accept any fix
// that restores the inbound behavior, wherever it places the tolerance (the
// decode lift hop, the era result schema, the era validateResult, or the
// neutral schema), while still catching a fix that reopens the hazard.
//
// Interfaces exercised (all pre-existing and stable; the fix changes only the
// observable decode/validate behavior behind them):
//   - the end-to-end request path:  Protocol.request(...)          (shared)
//   - the negotiated-era seam:       setNegotiatedProtocolVersion   (shared)
//   - the era codec (p2p guard):     codecForVersion(v)             (barrel)
//   - the narrowing guard (p2p):     isCallToolResult               (types barrel)
// No fix-introduced internal symbol (the normalizer, the wire wrapper schema,
// the foreign-key constant) is imported; only observable behavior is asserted.

import { describe, expect, it } from 'vitest';

import { SdkError, SdkErrorCode } from '../../src/errors/sdkErrors';
import type { BaseContext } from '../../src/shared/protocol';
import { Protocol, setNegotiatedProtocolVersion } from '../../src/shared/protocol';
import type { JSONRPCRequest } from '../../src/types/index';
import { isCallToolResult } from '../../src/types/index';
import { InMemoryTransport } from '../../src/util/inMemory';
import { codecForVersion } from '../../src/wire/codec';

class TestProtocol extends Protocol<BaseContext> {
    protected assertCapabilityForMethod(): void {}
    protected assertNotificationCapability(): void {}
    protected assertRequestHandlerCapability(): void {}
    protected buildContext(ctx: BaseContext): BaseContext {
        return ctx;
    }
}

// Wire a client-side protocol whose peer answers every request with the given
// raw result body, and negotiate the given era (omitted = legacy 2025-11-25, the
// default for an unbound instance). Mirrors test/shared/rawResultTypeFirst.
async function connectWithPeerResult(rawResult: unknown, era?: '2025-11-25' | '2026-07-28'): Promise<TestProtocol> {
    const [clientTx, serverTx] = InMemoryTransport.createLinkedPair();
    serverTx.onmessage = message => {
        const request = message as JSONRPCRequest;
        void serverTx.send({ jsonrpc: '2.0', id: request.id, result: rawResult } as Parameters<typeof serverTx.send>[0]);
    };
    await serverTx.start();
    const protocol = new TestProtocol();
    await protocol.connect(clientTx);
    if (era !== undefined) setNegotiatedProtocolVersion(protocol, era);
    return protocol;
}

type Outcome = { resolved: Record<string, unknown> } | { rejected: unknown };

// Drive the full inbound tools/call path end to end and report the outcome.
async function callTool(rawResult: unknown, era?: '2025-11-25' | '2026-07-28'): Promise<Outcome> {
    const protocol = await connectWithPeerResult(rawResult, era);
    try {
        return await protocol.request({ method: 'tools/call', params: { name: 'echo', arguments: {} } }).then(
            result => ({ resolved: result as Record<string, unknown> }),
            error => ({ rejected: error as unknown })
        );
    } finally {
        await protocol.close();
    }
}

// A content-less body carrying another result family's vocabulary. On the frozen
// 2025 era this key set is complete (task / inputRequests / requestState).
const FOREIGN_FAMILY_BODIES: Array<[string, Record<string, unknown>]> = [
    ['task', { task: { taskId: 't-1', status: 'working' } }],
    ['inputRequests', { inputRequests: { r1: { method: 'elicitation/create' } } }],
    ['requestState', { requestState: 'opaque-token' }]
];

describe('typescript-sdk-fix-tool-result-content :: inbound client tool-result handling', () => {
    // ── FAIL-TO-PASS — legacy_plain_tolerance ────────────────────────────
    // A client talking to a 2025-11-25 server that returns a content-less,
    // structuredContent-only result gets that result delivered again — content
    // defaults to [] and structuredContent is preserved. Pre-fix the client
    // rejects it with INVALID_RESULT before it reaches the caller.
    it('[legacy_plain_tolerance] a 2025 structured-only tool result is delivered with content: []', async () => {
        const outcome = await callTool({ structuredContent: { ok: true } }, '2025-11-25');
        expect('resolved' in outcome, `expected delivery, got ${JSON.stringify(outcome)}`).toBe(true);
        const result = (outcome as { resolved: Record<string, unknown> }).resolved;
        expect(result.content).toEqual([]);
        expect(result.structuredContent).toEqual({ ok: true });
    });

    it('[legacy_plain_tolerance] the restored tolerance also holds on an unbound (default-legacy) instance', async () => {
        // An instance that has not negotiated a version defaults to the legacy
        // era (the hand-wired posture), so the same content-less result is
        // delivered there too.
        const outcome = await callTool({ structuredContent: { ok: true } });
        expect('resolved' in outcome, `expected delivery, got ${JSON.stringify(outcome)}`).toBe(true);
        expect((outcome as { resolved: Record<string, unknown> }).resolved.content).toEqual([]);
    });

    // ── FAIL-TO-PASS (separating case) — foreign_family_rejected ─────────
    // A content-less body carrying another result family's vocabulary is
    // rejected loudly on the legacy era — never delivered as an empty
    // tools/call success. A naive fix that only re-adds the content default
    // (without the family guard) delivers legacy_plain_tolerance but FAILS
    // here, because a foreign-family body would default into an empty success.
    it('[foreign_family_rejected] every content-less foreign-family body is rejected, not delivered', async () => {
        for (const [label, body] of FOREIGN_FAMILY_BODIES) {
            const outcome = await callTool(body, '2025-11-25');
            expect('rejected' in outcome, `must reject ${label}, got ${JSON.stringify(outcome)}`).toBe(true);
            expect((outcome as { rejected: unknown }).rejected).toBeInstanceOf(SdkError);
            expect(((outcome as { rejected: SdkError }).rejected).code, `must reject ${label} as InvalidResult`).toBe(
                SdkErrorCode.InvalidResult
            );
        }
    });

    it('[foreign_family_rejected] the guard is specific — a plain content-less result is still delivered alongside the rejections', async () => {
        // Pins the specificity: the guard fires on foreign-family keys only, not
        // on content-less-ness in general.
        const plain = await callTool({ structuredContent: { ok: true } }, '2025-11-25');
        expect('resolved' in plain, `plain body must be delivered, got ${JSON.stringify(plain)}`).toBe(true);
        expect((plain as { resolved: Record<string, unknown> }).resolved.content).toEqual([]);

        const foreign = await callTool({ task: { taskId: 't-1', status: 'working' } }, '2025-11-25');
        expect('rejected' in foreign, `foreign body must be rejected, got ${JSON.stringify(foreign)}`).toBe(true);
    });

    it('[foreign_family_rejected] a foreign-family body with an explicit content: undefined is still rejected', async () => {
        // A bare `content: undefined` would otherwise default like an absent key;
        // a foreign-family body carrying it must still be refused.
        const outcome = await callTool({ task: { taskId: 't-1', status: 'working' }, content: undefined }, '2025-11-25');
        expect('rejected' in outcome, `must reject foreign body with content: undefined, got ${JSON.stringify(outcome)}`).toBe(true);
        expect((outcome as { rejected: unknown }).rejected).toBeInstanceOf(SdkError);
    });

    // ── PASS-TO-PASS — modern_era_strict ─────────────────────────────────
    // The modern 2026-07-28 era stays strict: a content-less body is still
    // rejected there. Guards against an over-broad fix that defaults every era.
    // True both pre- and post-fix.
    it('[modern_era_strict] 2026-07-28 era codec rejects a content-less tools/call body', () => {
        const outcome = codecForVersion('2026-07-28').validateResult('tools/call', { structuredContent: { ok: true } });
        expect(outcome.ok).toBe(false);
        expect(codecForVersion('2026-07-28').validateResult('tools/call', {}).ok).toBe(false);
    });

    // ── PASS-TO-PASS — guard_requires_content ────────────────────────────
    // isCallToolResult returns false for a value with absent or explicitly-
    // undefined content, even though the inbound path would default it (the
    // narrowed type requires the array). Catches a fix that loosened the guard
    // along with the tolerance. True both pre- and post-fix.
    it('[guard_requires_content] isCallToolResult rejects absent / undefined content, accepts an explicit array', () => {
        expect(isCallToolResult({ structuredContent: { ok: true } })).toBe(false);
        expect(isCallToolResult({ content: undefined, structuredContent: { ok: true } })).toBe(false);
        expect(isCallToolResult({})).toBe(false);
        expect(isCallToolResult({ content: [] })).toBe(true);
        expect(isCallToolResult({ content: [{ type: 'text', text: 'hi' }] })).toBe(true);
    });
});
