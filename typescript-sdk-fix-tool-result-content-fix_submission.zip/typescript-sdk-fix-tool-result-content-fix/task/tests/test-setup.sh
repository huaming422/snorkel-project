#!/usr/bin/env bash
# Environment bootstrap for the verifier.
#
# The MCP TypeScript SDK's vitest config (common/vitest-config/vitest.config.js)
# resolves every workspace package through vite-tsconfig-paths to its `src/`
# TypeScript (each package's tsconfig `paths` aliases the workspace deps to
# `.../src/index.ts`, and the config excludes `**/dist/**`). A `src/` edit is
# therefore picked up directly by the test run — there is NO dist/ build step to
# regenerate. This setup only needs the dependency closure present.
#
# Sourced (not exec'd) by the harbor runner so env vars set here stay live for
# the verifier subprocess.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/typescript-sdk}"
export REPO_DIR
cd "$REPO_DIR"

# harbor's js runner reads verify.toml via tomllib (3.11+) or tomli (<=3.10).
# run_verify.py runs under VERIFIER_PYTHON (the /opt/tooling venv, Python 3.12),
# whose stdlib already ships tomllib, so verify.toml is never silently dropped.
# This image has no system `python3` on PATH, so guard the interpreter lookup
# and keep the whole stanza non-fatal (it is a belt-and-suspenders fallback for
# a <3.11 interpreter only; a failure here must not abort setup under `set -e`).
_SETUP_PY="${VERIFIER_PYTHON:-}"
if [ -z "$_SETUP_PY" ] || [ ! -x "$_SETUP_PY" ]; then
    _SETUP_PY="$(command -v python3 || command -v python || true)"
fi
if [ -n "$_SETUP_PY" ]; then
    if ! "$_SETUP_PY" -c "import tomllib" >/dev/null 2>&1 && \
       ! "$_SETUP_PY" -c "import tomli"   >/dev/null 2>&1; then
        "$_SETUP_PY" -m pip install --quiet 'tomli==2.2.1' \
            || "$_SETUP_PY" -m pip install --break-system-packages --quiet 'tomli==2.2.1' \
            || echo "test-setup.sh: tomli fallback install skipped (VERIFIER_PYTHON stdlib tomllib is used at grade time)." >&2
    fi
fi

# The dependency closure is baked into the image at the base commit (pnpm store
# warm under /opt/cache/pnpm, node_modules installed in the clone layer).
# Install offline-first; fall back to an online install with a logged reason
# only if the workspace binaries are somehow missing. The agent phase runs with
# no network, but the verifier phase (this script) has network available.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/ — reinstalling." >&2
    pnpm config set store-dir /opt/cache/pnpm
    if ! pnpm install --frozen-lockfile --offline; then
        echo "test-setup.sh: offline install failed; retrying online." >&2
        pnpm install --frozen-lockfile
    fi
fi

# Sanity check: the two packages the verifier exercises must be resolvable.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest still unavailable after install attempts." >&2
    exit 1
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
