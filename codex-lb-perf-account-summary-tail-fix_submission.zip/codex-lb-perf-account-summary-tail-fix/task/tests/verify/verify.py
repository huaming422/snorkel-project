"""Behavioral checks for the accounts-listing usage summary.

These exercise the account-listing usage-summary path end to end through the
repository's own public surface:

- ``AccountsRepository.list_request_usage_summary_by_account(account_ids)`` —
  the per-account summary the accounts listing renders (folded sums merged
  with a live re-aggregation of the still-raw recent tail).
- ``AccountsRepository.delete`` / ``AccountsRepository.upsert`` — the deletion
  and duplicate-identity consolidation paths that re-attribute usage.
- ``usage_rollup.run_fold_pass`` — the periodic compaction that moves settled
  raw rows into the per-account aggregates so the live tail stays small.

The headline performance property — the listing stops getting slower as
request-log history grows — is measured directly: the per-call work of the
usage aggregate (counted as SQLite virtual-machine steps) must not scale with
the amount of accumulated history. That is a property of the observable
behavior, not of any particular bounding mechanism, so a fix that advances the
fold boundary, compacts on a different cadence, or reshapes the tail read all
pass equally, while a solution that re-scans all of history on every load — or
only caches the result without bounding the cold read — fails. The remaining
checks assert the correctness invariants that must survive whatever mechanism is
chosen: the reported totals (with #904 dedupe and warmup exclusion) stay exact,
and deleted/consolidated accounts disappear from the listing immediately.

The fixtures are self-contained: this file is collected from its own directory,
so the repo's ``tests/conftest.py`` is not in scope. The database URL and the
schedulers/leader-election knobs are set below exactly as that conftest would
set them at import time, and the per-check schema reset mirrors the repo's own
``_reset_db_state`` fixture.
"""

from __future__ import annotations

import os
import tempfile
from datetime import timedelta

import pytest

# The repo builds its async engine at import time from CODEX_LB_DATABASE_URL,
# and its listing/rollup code reads several CODEX_LB_* knobs. Set them before
# importing anything under ``app`` so the engine binds to a throwaway SQLite
# file and no background scheduler or leader election starts. (test-setup.sh
# also exports several of these defensively; setting them here keeps this file
# runnable on its own.)
_DB_DIR = tempfile.mkdtemp(prefix="codex-lb-accounts-summary-")
os.environ.setdefault(
    "CODEX_LB_DATABASE_URL",
    os.environ.get("CODEX_LB_TEST_DATABASE_URL", f"sqlite+aiosqlite:///{_DB_DIR}/codex-lb.db"),
)
os.environ.setdefault("CODEX_LB_UPSTREAM_BASE_URL", "https://example.invalid/backend-api")
os.environ.setdefault("CODEX_LB_USAGE_REFRESH_ENABLED", "false")
os.environ.setdefault("CODEX_LB_MODEL_REGISTRY_ENABLED", "false")
os.environ.setdefault("CODEX_LB_STICKY_SESSION_CLEANUP_ENABLED", "false")
os.environ.setdefault("CODEX_LB_HTTP_RESPONSES_SESSION_BRIDGE_ENABLED", "false")
os.environ.setdefault("CODEX_LB_QUOTA_PLANNER_SCHEDULER_ENABLED", "false")
os.environ.setdefault("CODEX_LB_UPSTREAM_ROUTE_CACHE_TTL_SECONDS", "0")
os.environ.setdefault("CODEX_LB_AUTOMATIONS_SCHEDULER_ENABLED", "false")

import app.modules.accounts.repository as accounts_repository_module  # noqa: E402
from app.core.crypto import TokenEncryptor  # noqa: E402
from app.core.utils.time import utcnow  # noqa: E402
from app.db.models import (  # noqa: E402
    Account,
    AccountStatus,
    AccountUsageRollup,
    AccountUsageRollupState,
    Base,
    RequestLog,
)
from app.db.session import SessionLocal, engine  # noqa: E402
from app.modules.accounts.repository import AccountsRepository  # noqa: E402
from app.modules.accounts.usage_rollup import run_fold_pass  # noqa: E402
from app.modules.request_logs.repository import RequestLogsRepository  # noqa: E402
from sqlalchemy import event, insert, select  # noqa: E402

pytestmark = pytest.mark.asyncio


# ---------------------------------------------------------------------------
# Deterministic work meter.
#
# The accounts listing is "slow at scale" precisely because the per-call usage
# aggregate re-reads the still-raw tail of ``request_logs`` on every load, and
# that tail keeps growing with history. The contract (base.md) is that the fix
# makes the listing stop getting slower as history piles up — i.e. the listing's
# per-call work stops scaling with total request-log history. We measure that
# work directly and deterministically by counting SQLite virtual-machine steps
# executed during a single ``list_request_usage_summary_by_account`` call, via
# the driver connection's progress handler. This observes the *behavior* (work
# bounded vs. work that grows with history) and is agnostic to HOW a solution
# bounds it: advancing the fold boundary, a different compaction cadence, or any
# other approach that keeps the re-aggregated tail small all pass, while a
# solution that still re-scans all of history (or only caches without bounding
# the cold read) does not.
# ---------------------------------------------------------------------------

_work_steps = {"n": 0}
_work_armed = {"v": False}


def _progress_tick() -> int:
    if _work_armed["v"]:
        _work_steps["n"] += 1
    return 0


@event.listens_for(engine.sync_engine, "connect")
def _install_work_meter(dbapi_conn, _record) -> None:
    """Attach a per-VM-step progress handler to every raw SQLite connection so a
    measured call can count the work the aggregate performs. No-op on any backend
    whose driver connection does not expose ``set_progress_handler``."""
    raw = getattr(dbapi_conn, "_connection", None) or dbapi_conn
    inner = getattr(raw, "_conn", None) or raw
    if hasattr(inner, "set_progress_handler"):
        inner.set_progress_handler(_progress_tick, 1)


async def _measure_listing_work(account_ids: list[str] | None = None):
    """Run one listing-summary call with the work meter armed; return
    (vm_steps, summaries). Any process-local memoization is cleared first so the
    measurement always reflects a cold (cache-miss) computation."""
    clear = getattr(accounts_repository_module, "_clear_request_usage_summary_cache", None)
    if callable(clear):
        clear()
    _work_steps["n"] = 0
    _work_armed["v"] = True
    try:
        async with SessionLocal() as session:
            summaries = await AccountsRepository(session).list_request_usage_summary_by_account(account_ids)
    finally:
        _work_armed["v"] = False
    return _work_steps["n"], summaries


def _perf_log_rows(account_id: str, start_index: int, count: int, age: timedelta) -> list[dict]:
    """Build a block of ``count`` ordinary request-log rows for bulk insertion,
    all aged ``age`` before now (staggered by seconds so ids/timestamps are
    distinct). Used to populate large raw tails cheaply."""
    now = utcnow()
    return [
        dict(
            account_id=account_id,
            request_id=f"{account_id}-r{start_index + j}",
            request_kind="normal",
            requested_at=now - age - timedelta(seconds=j),
            model="gpt-5.1-codex",
            status="success",
            input_tokens=100,
            output_tokens=50,
            cached_input_tokens=0,
            reasoning_tokens=0,
            cost_usd=0.01,
            latency_ms=1,
        )
        for j in range(count)
    ]


async def _bulk_insert_logs(rows: list[dict]) -> None:
    chunk = 5000
    async with engine.begin() as conn:
        for start in range(0, len(rows), chunk):
            await conn.execute(insert(RequestLog), rows[start : start + chunk])


async def _reset_db_full() -> None:
    """Drop/recreate the schema and pin any summary-memo TTL to 0 (exact mode),
    for the performance checks that seed their own corpora from scratch."""
    from app.db.session import close_db

    await close_db()
    async with engine.begin() as conn:
        await conn.run_sync(_reset_schema)
    if hasattr(accounts_repository_module, "_SUMMARY_CACHE_TTL_SECONDS"):
        accounts_repository_module._SUMMARY_CACHE_TTL_SECONDS = 0.0


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _reset_schema(sync_conn) -> None:
    from sqlalchemy import text

    sync_conn.execute(text("DROP TABLE IF EXISTS alembic_version"))
    sync_conn.execute(text("DROP TABLE IF EXISTS schema_migrations"))
    Base.metadata.drop_all(sync_conn)
    Base.metadata.create_all(sync_conn)


def _reset_summary_memo(ttl: float | None) -> float | None:
    """Best-effort reset of any process-local listing-summary memoization the
    solution may keep, returning the prior TTL so callers can restore it.

    A solution that bounds the live tail without any such memoization is a
    valid approach, so this must stay a no-op when the hooks are absent rather
    than presuppose a particular caching design. When the hooks DO exist, the
    checks below that observe staleness need them reset between runs (the
    repo's own test suite resets them the same way through an autouse
    fixture)."""
    clear = getattr(accounts_repository_module, "_clear_request_usage_summary_cache", None)
    if callable(clear):
        clear()
    prior = getattr(accounts_repository_module, "_SUMMARY_CACHE_TTL_SECONDS", None)
    if ttl is not None and hasattr(accounts_repository_module, "_SUMMARY_CACHE_TTL_SECONDS"):
        accounts_repository_module._SUMMARY_CACHE_TTL_SECONDS = ttl
    return prior


@pytest.fixture
async def db_setup():
    """Drop and recreate all tables before each check (mirrors the repo's own
    per-test schema reset).

    Summary assertions in the fold/totals checks below are written to be robust
    to short-lived staleness (they compare against an earlier snapshot or read
    the compacted rows straight from the database), so they hold whether or not
    the solution memoizes summaries. Where any process-local memoization does
    exist, it is reset to an exact (non-stale) mode for these checks; the
    staleness-observing checks opt back into a positive window themselves."""
    from app.db.session import close_db

    await close_db()
    async with engine.begin() as conn:
        await conn.run_sync(_reset_schema)

    prior_ttl = _reset_summary_memo(0.0)
    try:
        yield True
    finally:
        _reset_summary_memo(prior_ttl)


# ---------------------------------------------------------------------------
# Helpers (ported from the repo's accounts usage-rollup test module)
# ---------------------------------------------------------------------------


def _make_account(
    account_id: str, email: str, plan_type: str = "plus", chatgpt_account_id: str | None = None
) -> Account:
    encryptor = TokenEncryptor()
    return Account(
        id=account_id,
        email=email,
        plan_type=plan_type,
        chatgpt_account_id=chatgpt_account_id,
        access_token_encrypted=encryptor.encrypt("access"),
        refresh_token_encrypted=encryptor.encrypt("refresh"),
        id_token_encrypted=encryptor.encrypt("id"),
        last_refresh=utcnow(),
        status=AccountStatus.ACTIVE,
        deactivation_reason=None,
    )


async def _add_log(
    logs_repo: RequestLogsRepository,
    *,
    account_id: str,
    request_id: str,
    requested_at,
    input_tokens: int = 100,
    output_tokens: int = 50,
    cached_input_tokens: int = 0,
    cost_usd: float | None = 0.01,
    request_kind: str = "normal",
):
    return await logs_repo.add_log(
        account_id=account_id,
        request_id=request_id,
        model="gpt-5.1-codex",
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        cached_input_tokens=cached_input_tokens,
        latency_ms=100,
        status="success",
        error_code=None,
        requested_at=requested_at,
        cost_usd=cost_usd,
        request_kind=request_kind,
    )


async def _summaries(account_ids: list[str] | None = None):
    async with SessionLocal() as session:
        return await AccountsRepository(session).list_request_usage_summary_by_account(account_ids)


async def _rollup_rows():
    async with SessionLocal() as session:
        return (await session.execute(select(AccountUsageRollup))).scalars().all()


async def _watermark():
    async with SessionLocal() as session:
        return (
            await session.execute(
                select(AccountUsageRollupState.folded_through).where(AccountUsageRollupState.id == 1)
            )
        ).scalar_one_or_none()


# A solution may keep a process-local memoization of the listing summary (to
# absorb repeated loads within a short staleness window), or it may bound the
# live tail tightly enough that no memoization is needed, or place one at a
# different layer. These helpers let the checks below observe memoized behavior
# when the repository exposes the established hooks, and stay neutral otherwise
# so a valid no-memo (or differently-placed) approach is never penalized.
def _summary_memo_control_present() -> bool:
    return hasattr(accounts_repository_module, "_SUMMARY_CACHE_TTL_SECONDS") and callable(
        getattr(accounts_repository_module, "_clear_request_usage_summary_cache", None)
    )


def _prime_summary_memo(monkeypatch, window_seconds: float = 30.0) -> None:
    """If the repository exposes its summary-memo hooks, enable a positive
    staleness window and start from empty so the assertions observe memoized
    behavior. No-op when no such hooks exist."""
    if hasattr(accounts_repository_module, "_SUMMARY_CACHE_TTL_SECONDS"):
        monkeypatch.setattr(accounts_repository_module, "_SUMMARY_CACHE_TTL_SECONDS", window_seconds)
    clear = getattr(accounts_repository_module, "_clear_request_usage_summary_cache", None)
    if callable(clear):
        clear()


# ---------------------------------------------------------------------------
# Dedupe/fold math and the reported lifetime totals are unchanged by the
# change; only query shape and freshness differ.
# ---------------------------------------------------------------------------


async def test_fold_preserves_summary_totals_and_dedupe(db_setup):
    now = utcnow()
    old = now - timedelta(days=2)
    async with SessionLocal() as session:
        accounts_repo = AccountsRepository(session)
        logs_repo = RequestLogsRepository(session)
        await accounts_repo.upsert(_make_account("acc_fold", "fold@example.com"))
        await _add_log(logs_repo, account_id="acc_fold", request_id="req_1", requested_at=old, input_tokens=1000)
        # Rows sharing (account_id, request_id, requested_at) collapse to the
        # latest id only (issue #904 semantics).
        dup_at = old + timedelta(minutes=5)
        await _add_log(
            logs_repo, account_id="acc_fold", request_id="req_dup", requested_at=dup_at, input_tokens=999_999
        )
        await _add_log(logs_repo, account_id="acc_fold", request_id="req_dup", requested_at=dup_at, input_tokens=200)
        # Warmup rows are excluded from summaries entirely.
        await _add_log(
            logs_repo,
            account_id="acc_fold",
            request_id="req_warm",
            requested_at=old,
            request_kind="warmup",
            input_tokens=777,
        )
        # Recent row stays on the live-tail side of the fold boundary.
        await _add_log(logs_repo, account_id="acc_fold", request_id="req_new", requested_at=now, input_tokens=10)

    before = await _summaries()
    assert before["acc_fold"].request_count == 3
    assert before["acc_fold"].total_tokens == 1000 + 200 + 10 + 3 * 50

    folded_slices = await run_fold_pass(now=now)
    assert folded_slices >= 1
    rows = await _rollup_rows()
    assert len(rows) == 1
    assert rows[0].account_id == "acc_fold"
    assert rows[0].request_count == 2
    assert rows[0].input_tokens == 1000 + 200
    # The watermark position (which lag governs it) is implementation-defined;
    # the p2p contract is only that totals are preserved regardless of boundary.

    after = await _summaries()
    assert after == before


# ---------------------------------------------------------------------------
# The headline contract: the accounts-listing usage summary must stop getting
# slower as request-log history grows. We assert that directly and
# mechanism-agnostically -- the per-call work of the listing aggregate does not
# scale with the amount of accumulated (compactable) history. A fix that bounds
# the re-aggregated live tail (by any means) keeps the work flat; a solution
# that still re-scans all of history on every load -- or only caches the result
# without bounding the cold read -- scales linearly and fails.
# ---------------------------------------------------------------------------


async def test_listing_work_does_not_scale_with_history():
    async def _work_over_history(aged_rows: int) -> tuple[int, int]:
        await _reset_db_full()
        now = utcnow()
        async with SessionLocal() as session:
            await AccountsRepository(session).upsert(_make_account("acc_scale", "scale@example.com"))
        # A fixed small recent tail every solution must re-aggregate live, plus a
        # variable block of older history that any history-bounding fix compacts
        # out of the live tail. Both ages are far from the boundary of any
        # plausible bounding window, so no assertion depends on a specific value.
        await _bulk_insert_logs(_perf_log_rows("acc_scale", 0, 40, timedelta(minutes=10)))
        await _bulk_insert_logs(_perf_log_rows("acc_scale", 1_000, aged_rows, timedelta(hours=12)))
        await run_fold_pass(now=now)
        steps, summaries = await _measure_listing_work()
        return steps, summaries["acc_scale"].request_count

    small_steps, small_count = await _work_over_history(4_000)
    large_steps, large_count = await _work_over_history(12_000)

    # Totals are correct in both corpora (sanity: the summary still reports every
    # row, folded or live).
    assert small_count == 4_040
    assert large_count == 12_040

    # 3x the history must not cost materially more work. A bounded fix keeps the
    # ratio ~1.0; an unbounded re-scan grows ~3x. The 1.8 ceiling is a wide
    # margin that only an actually-bounded aggregate clears.
    ratio = large_steps / max(small_steps, 1)
    assert ratio < 1.8, (
        "the accounts-listing aggregate still scales with total request-log history "
        f"(work grew {ratio:.1f}x for 3x history: {small_steps} -> {large_steps} vm-steps); "
        "the listing is not bounded to the recent tail"
    )


# ---------------------------------------------------------------------------
# Deep compactable history is absorbed so the listing re-aggregates only a small
# recent tail, AND every reported total stays exact across the compaction
# (duplicate #904 collapse and warmup exclusion preserved). This guards the
# correctness invariant that must survive whatever bounding mechanism is chosen.
# ---------------------------------------------------------------------------


async def test_deep_history_folds_with_totals_exact_and_bounded_work():
    await _reset_db_full()
    now = utcnow()
    async with SessionLocal() as session:
        accounts_repo = AccountsRepository(session)
        logs_repo = RequestLogsRepository(session)
        await accounts_repo.upsert(_make_account("acc_deep", "deep@example.com"))
        # A recent tail carrying a #904 duplicate pair (collapses to the latest
        # id) and a warmup row (excluded from summaries entirely).
        await _add_log(
            logs_repo, account_id="acc_deep", request_id="req_dup", requested_at=now - timedelta(minutes=30),
            input_tokens=5,
        )
        await _add_log(
            logs_repo, account_id="acc_deep", request_id="req_dup", requested_at=now - timedelta(minutes=30),
            input_tokens=7,
        )
        await _add_log(
            logs_repo, account_id="acc_deep", request_id="req_warm", requested_at=now - timedelta(minutes=20),
            request_kind="warmup", input_tokens=999,
        )

    # Work over the current small corpus establishes the bounded baseline.
    reference_steps, before = await _measure_listing_work()
    assert before["acc_deep"].request_count == 1  # dup collapsed, warmup excluded

    # Pile on a large block of history older than any plausible bounding window.
    await _bulk_insert_logs(_perf_log_rows("acc_deep", 10_000, 12_000, timedelta(hours=14)))
    await run_fold_pass(now=now)

    deep_steps, after = await _measure_listing_work()

    # Totals stay exact: the duplicate still collapses to one, the warmup stays
    # excluded, and all 12_000 aged rows are counted (folded + live merge).
    assert after["acc_deep"].request_count == 1 + 12_000
    assert after["acc_deep"].total_tokens == before["acc_deep"].total_tokens + 12_000 * (100 + 50)

    # The deep history must have been absorbed, not re-scanned on every load: the
    # listing's work stays close to the small-corpus baseline rather than growing
    # with the 12_000 added rows.
    assert deep_steps <= reference_steps + 4_000, (
        "deep compactable history inflated the listing aggregate's per-call work "
        f"({reference_steps} -> {deep_steps} vm-steps); the live tail is not bounded"
    )


# ---------------------------------------------------------------------------
# Within a short staleness window a repeated same-signature call returns the
# prior (slightly stale) result; a different account-id signature is computed
# fresh; clearing returns fresh results.
# ---------------------------------------------------------------------------


async def test_summary_cache_serves_within_ttl_per_signature(db_setup, monkeypatch):
    # Observing "a repeated call within the window returns the prior, slightly
    # stale result" only has meaning when the solution keeps such a memo. A
    # solution whose bounded live tail makes the listing fast without one is
    # valid, so stay neutral when no memo hooks are present.
    if not _summary_memo_control_present():
        pytest.skip("no process-local summary memoization exposed; staleness window not applicable")
    _prime_summary_memo(monkeypatch)
    now = utcnow()
    async with SessionLocal() as session:
        accounts_repo = AccountsRepository(session)
        logs_repo = RequestLogsRepository(session)
        await accounts_repo.upsert(_make_account("acc_ttl", "ttl@example.com"))
        await _add_log(
            logs_repo, account_id="acc_ttl", request_id="req_ttl_1", requested_at=now - timedelta(minutes=5)
        )

    first = await _summaries()
    assert first["acc_ttl"].request_count == 1

    async with SessionLocal() as session:
        await _add_log(
            RequestLogsRepository(session),
            account_id="acc_ttl",
            request_id="req_ttl_2",
            requested_at=now - timedelta(minutes=1),
        )

    # Same signature within the window: served from the prior result, staleness
    # tolerated.
    assert (await _summaries())["acc_ttl"].request_count == 1
    # A different account-id signature is a separate entry, computed fresh.
    scoped = await _summaries(["acc_ttl"])
    assert scoped["acc_ttl"].request_count == 2

    accounts_repository_module._clear_request_usage_summary_cache()
    assert (await _summaries())["acc_ttl"].request_count == 2


# ---------------------------------------------------------------------------
# Deletion drops the account from the summary immediately rather than after the
# staleness window expires.
# ---------------------------------------------------------------------------


async def test_summary_cache_cleared_on_account_delete(db_setup, monkeypatch):
    # Deleting an account must drop it from the listing summary immediately.
    # Prime any process-local summary memo first (no-op if none exists): a
    # solution that memoizes but fails to invalidate on deletion keeps
    # reporting the removed account and fails here; a no-memo solution is
    # trivially fresh and passes.
    _prime_summary_memo(monkeypatch)
    now = utcnow()
    async with SessionLocal() as session:
        accounts_repo = AccountsRepository(session)
        logs_repo = RequestLogsRepository(session)
        await accounts_repo.upsert(_make_account("acc_keep", "keep@example.com"))
        await accounts_repo.upsert(_make_account("acc_gone", "gone@example.com"))
        await _add_log(
            logs_repo, account_id="acc_keep", request_id="req_keep", requested_at=now - timedelta(minutes=5)
        )
        await _add_log(
            logs_repo, account_id="acc_gone", request_id="req_gone", requested_at=now - timedelta(minutes=5)
        )

    first = await _summaries()
    assert "acc_gone" in first

    async with SessionLocal() as session:
        assert await AccountsRepository(session).delete("acc_gone")

    after = await _summaries()
    assert "acc_gone" not in after
    assert after["acc_keep"].request_count == 1


# ---------------------------------------------------------------------------
# Duplicate-identity consolidation reports the merged account's totals
# immediately and drops the duplicate.
# ---------------------------------------------------------------------------


async def test_summary_cache_cleared_on_identity_consolidation(db_setup, monkeypatch):
    # Consolidating a duplicate identity must report the merged account's
    # totals (and drop the duplicate) immediately. Prime any process-local
    # summary memo first (no-op if none exists): a solution that memoizes but
    # fails to invalidate on consolidation keeps reporting the duplicate and
    # stale totals and fails here; a no-memo solution is trivially fresh.
    _prime_summary_memo(monkeypatch)
    now = utcnow()
    async with SessionLocal() as session:
        accounts_repo = AccountsRepository(session)
        logs_repo = RequestLogsRepository(session)
        canonical = _make_account("acc_cc", "cc@example.com", chatgpt_account_id="chatgpt_cc")
        duplicate = _make_account("acc_cc__copy", "cc@example.com", chatgpt_account_id="chatgpt_cc")
        await accounts_repo.upsert(canonical, merge_by_email=False)
        await accounts_repo.upsert(duplicate, merge_by_email=False)
        await _add_log(logs_repo, account_id="acc_cc", request_id="req_cc_1", requested_at=now - timedelta(minutes=5))
        await _add_log(
            logs_repo, account_id="acc_cc__copy", request_id="req_cc_2", requested_at=now - timedelta(minutes=5)
        )

    first = await _summaries()
    assert first["acc_cc"].request_count == 1
    assert first["acc_cc__copy"].request_count == 1

    async with SessionLocal() as session:
        reauth = _make_account("acc_cc", "cc@example.com", chatgpt_account_id="chatgpt_cc")
        saved = await AccountsRepository(session).upsert(
            reauth, merge_by_email=False, merge_by_chatgpt_identity=True
        )
        assert saved.id == "acc_cc"

    after = await _summaries()
    assert "acc_cc__copy" not in after
    assert after["acc_cc"].request_count == 2


# ---------------------------------------------------------------------------
# A summary computation that began before an invalidation must not store its
# pre-clear result afterward.
# ---------------------------------------------------------------------------


async def test_summary_cache_fill_discarded_when_invalidated_mid_flight(db_setup, monkeypatch):
    # The race fence is an internal property of the specific memo design: a
    # summary computation that began before an invalidation must not store its
    # pre-clear result. It can only be observed through the memo's own store
    # (``_request_usage_summary_cache``). A solution that keeps no such memo,
    # or fences via a different mechanism/placement, is valid and has nothing
    # to observe here, so stay neutral unless the established store is present.
    store = getattr(accounts_repository_module, "_request_usage_summary_cache", None)
    if not (_summary_memo_control_present() and isinstance(store, dict)):
        pytest.skip("no in-process summary-memo store exposed; mid-flight fence not observable here")
    _prime_summary_memo(monkeypatch)
    now = utcnow()
    async with SessionLocal() as session:
        accounts_repo = AccountsRepository(session)
        logs_repo = RequestLogsRepository(session)
        await accounts_repo.upsert(_make_account("acc_racefill", "racefill@example.com"))
        await _add_log(
            logs_repo, account_id="acc_racefill", request_id="req_rf", requested_at=now - timedelta(minutes=5)
        )

    real_read_state = accounts_repository_module.AccountUsageRollupRepository.read_state

    async def _read_state_with_racing_clear(self, account_ids=None):
        result = await real_read_state(self, account_ids)
        # Simulate a consolidation/deletion committing and clearing while this
        # fill is still between its two statements.
        accounts_repository_module._clear_request_usage_summary_cache()
        return result

    monkeypatch.setattr(
        accounts_repository_module.AccountUsageRollupRepository, "read_state", _read_state_with_racing_clear
    )
    first = await _summaries()
    assert first["acc_racefill"].request_count == 1
    # The interleaved clear must have won: nothing is left stored.
    assert accounts_repository_module._request_usage_summary_cache == {}
