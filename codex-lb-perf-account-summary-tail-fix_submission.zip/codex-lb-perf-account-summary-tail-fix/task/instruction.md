## Task

Operators are reporting that the dashboard's accounts listing has gotten
painfully slow on our large production deployment. It takes around a minute to
load cold, a couple of seconds when warm, and sometimes hangs long enough to
time out. It keeps getting worse the more request-log history piles up.

The per-account usage numbers it shows (request counts, token totals, cost) are
correct, so this isn't a data problem. It's the backend that builds that summary
that's crawling; the frontend is fine.

Dig into why the accounts listing is so slow at this scale and fix it on the
backend. The usage totals each account shows have to stay exactly the same, and
account deletion and duplicate-account consolidation both need to keep behaving
correctly. A code change in the accounts and usage-rollup area should do it; no
schema migration or new dependency is needed.
