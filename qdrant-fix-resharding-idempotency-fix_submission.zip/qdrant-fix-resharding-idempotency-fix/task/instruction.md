## Task

We run Qdrant as a multi-peer cluster and resharding keeps breaking consistency
across restarts. When a collection goes through a resharding operation (adding or
removing a shard) and a peer restarts while that operation is in flight or just
after, it comes back permanently out of sync. That peer's shard set is wrong: a
shard the others have goes missing, an extra shard nobody else has shows up, or
the persisted shard count no longer matches the shards it holds.

It doesn't heal on its own, and a collection in this state blocks any further
resharding on it. A run with no restarts is fine; the divergence only shows up
around a restart during or right after resharding. We only catch it through chaos
testing that restarts peers at random.

The fault is in the collection library crate's resharding apply path. Work out why
a restart leaves a peer diverged and fix it so it reconverges with the cluster. A
first-time resharding with no restart should behave as it does now, with no API,
wire-format, or configuration change.
