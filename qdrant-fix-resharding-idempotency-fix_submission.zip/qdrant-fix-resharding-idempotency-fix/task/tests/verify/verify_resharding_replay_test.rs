//! Behavioral verifier for `qdrant-fix-resharding-idempotency`.
//!
//! Tests through the pre-existing public `Collection` API (the layer the
//! consensus apply loop actually calls).  Each f2p test simulates the exact
//! crash window exposed by PR #8789: a partially-applied resharding step is
//! forced onto disk (resharding_state cleared/set, config.shard_number NOT
//! yet updated to match), the collection is reloaded, and the same step is
//! re-applied.
//!
//! Pre-fix, `finish_resharding` / `abort_resharding` each start with:
//!
//!   if shard_holder.resharding_state().is_none() { return Ok(()); }
//!
//! — which causes an early-return on the second apply even though
//! `config.shard_number` was not updated on the (simulated) first apply.
//! The count is therefore permanently wrong.  The correct fix removes those
//! early-returns so each step falls through individually-idempotent code
//! that reconciles `shard_number` correctly.
//!
//! For `start_resharding`, the Collection-layer's own guard:
//!
//!   if resharding_state.is_some() && state.matches(key) { return Ok(()); }
//!
//! is removed by the fix so that `shard_number` is always reconciled via
//! the id-derived expression instead of being skipped on replay.  The crash
//! window is: start wrote resharding_state but did NOT persist
//! shard_number += 1 yet.  On replay, pre-fix sees resharding_state=Some →
//! returns Ok() → never fixes the drift.
//!
//! Decoupling rationale (why this is implementation-agnostic):
//!   * Entry-points: `Collection::start/finish/abort_resharding` — pre-existing
//!     public methods with unchanged signatures.  Nothing the fix introduces
//!     is named.
//!   * Crash-window injection: we manipulate two plain files on disk
//!     (`resharding_state.json` and `config.json`) using their stable JSON
//!     serialisation. These files predate the PR and their schemas are
//!     unchanged; our manipulation is a JSON patch, not code import.
//!   * Observations: `Collection::state().config.params.shard_number`
//!     (persisted count via the public `State` struct) and
//!     `Collection::get_local_shards()` (shard ID set) — both pre-existing.
//!   * Helpers: `simple_collection_fixture` + `load_local_collection` from
//!     `lib/collection/tests/integration/common/` — pre-existing test helpers.

use std::num::NonZeroU32;
use std::path::Path;
use std::sync::Arc;

use async_trait::async_trait;
use collection::collection::{Collection, RequestShardTransfer};
use collection::config::{CollectionConfigInternal, CollectionParams, WalConfig};
use collection::operations::cluster_ops::ReshardingDirection;
use collection::operations::types::CollectionResult;
use collection::operations::vector_params_builder::VectorParamsBuilder;
use collection::optimizers_builder::OptimizersConfig;
use collection::shards::channel_service::ChannelService;
use collection::shards::collection_shard_distribution::CollectionShardDistribution;
use collection::shards::replica_set::replica_set_state::ReplicaState;
use collection::shards::replica_set::{AbortShardTransfer, ChangePeerFromState};
use collection::shards::resharding::{ReshardKey, ReshardState, ReshardingStage};
use collection::shards::shard::{PeerId, ShardId};
use collection::shards::transfer::{
    ShardTransfer, ShardTransferConsensus, ShardTransferKey, ShardTransferMethod,
};
use collection::shards::CollectionId;
use common::budget::ResourceBudget;
use segment::types::Distance;
use tempfile::Builder;
use uuid::Uuid;

// ---------------------------------------------------------------------------
// Stub implementations
// ---------------------------------------------------------------------------

const REST_PORT: u16 = 6333;

const TEST_OPTIMIZERS_CONFIG: OptimizersConfig = OptimizersConfig {
    deleted_threshold: 0.9,
    vacuum_min_vector_number: 1000,
    default_segment_number: 2,
    max_segment_size: None,
    #[expect(deprecated)]
    memmap_threshold: None,
    indexing_threshold: Some(50_000),
    flush_interval_sec: 30,
    max_optimization_threads: Some(2),
    prevent_unoptimized: None,
};

/// Minimal no-op consensus stub.  `Collection::start_resharding` accepts a
/// `Box<dyn ShardTransferConsensus>` but the parameter is named `_consensus`
/// in the pre-fix code — none of the stub methods are ever called.
struct NopConsensus;

#[async_trait]
impl ShardTransferConsensus for NopConsensus {
    fn this_peer_id(&self) -> PeerId {
        0
    }
    fn peers(&self) -> Vec<PeerId> {
        vec![0]
    }
    fn consensus_commit_term(&self) -> (u64, u64) {
        (0, 0)
    }
    fn recovered_switch_to_partial(
        &self,
        _transfer_config: &ShardTransfer,
        _collection_id: CollectionId,
    ) -> CollectionResult<()> {
        Ok(())
    }
    async fn start_shard_transfer(
        &self,
        _transfer_config: ShardTransfer,
        _collection_id: CollectionId,
    ) -> CollectionResult<()> {
        Ok(())
    }
    async fn restart_shard_transfer(
        &self,
        _transfer_config: ShardTransfer,
        _collection_id: CollectionId,
        _default_method: ShardTransferMethod,
    ) -> CollectionResult<()> {
        Ok(())
    }
    async fn abort_shard_transfer(
        &self,
        _transfer: ShardTransferKey,
        _collection_id: CollectionId,
        _reason: &str,
    ) -> CollectionResult<()> {
        Ok(())
    }
    async fn set_shard_replica_set_state(
        &self,
        _peer_id: Option<PeerId>,
        _collection_id: CollectionId,
        _shard_id: ShardId,
        _state: ReplicaState,
        _from_state: Option<ReplicaState>,
    ) -> CollectionResult<()> {
        Ok(())
    }
    async fn commit_read_hashring(
        &self,
        _collection_id: CollectionId,
        _reshard_key: ReshardKey,
    ) -> CollectionResult<()> {
        Ok(())
    }
    async fn commit_write_hashring(
        &self,
        _collection_id: CollectionId,
        _reshard_key: ReshardKey,
    ) -> CollectionResult<()> {
        Ok(())
    }
}

fn nop_consensus() -> Box<NopConsensus> {
    Box::new(NopConsensus)
}

fn dummy_on_replica_failure() -> ChangePeerFromState {
    Arc::new(move |_peer_id, _shard_id, _from_state| {})
}

fn dummy_request_shard_transfer() -> RequestShardTransfer {
    Arc::new(move |_transfer| {})
}

fn dummy_abort_shard_transfer() -> AbortShardTransfer {
    Arc::new(|_transfer, _reason| {})
}

fn collection_config(shard_number: u32) -> CollectionConfigInternal {
    CollectionConfigInternal {
        params: CollectionParams {
            vectors: VectorParamsBuilder::new(4, Distance::Dot).build().into(),
            shard_number: NonZeroU32::new(shard_number).unwrap(),
            ..CollectionParams::empty()
        },
        optimizer_config: TEST_OPTIMIZERS_CONFIG.clone(),
        wal_config: WalConfig {
            wal_capacity_mb: 1,
            wal_segments_ahead: 0,
            wal_retain_closed: 1,
        },
        hnsw_config: Default::default(),
        quantization_config: Default::default(),
        strict_mode_config: Default::default(),
        uuid: None,
        metadata: None,
    }
}

/// Create a fresh collection with `shard_number` shards, all local + Active.
async fn new_collection(path: &Path, shard_number: u32) -> Collection {
    let snapshots = path.join("snapshots");
    std::fs::create_dir_all(&snapshots).unwrap();
    let config = collection_config(shard_number);
    let collection = Collection::new(
        "test".to_string(),
        0,
        path,
        &snapshots,
        &config,
        Default::default(),
        CollectionShardDistribution::all_local(Some(config.params.shard_number.into()), 0),
        None,
        ChannelService::new(REST_PORT, false, None, None),
        dummy_on_replica_failure(),
        dummy_request_shard_transfer(),
        dummy_abort_shard_transfer(),
        None,
        None,
        ResourceBudget::default(),
        None,
    )
    .await
    .expect("Collection::new should succeed");

    for shard_id in collection.get_local_shards().await {
        collection
            .set_shard_replica_state(shard_id, 0, ReplicaState::Active, None)
            .await
            .expect("set_shard_replica_state should succeed");
    }
    collection
}

/// Reload collection from disk — identical to what a node does on restart.
async fn reload_collection(path: &Path) -> Collection {
    let snapshots = path.join("snapshots");
    Collection::load(
        "test".to_string(),
        0,
        path,
        &snapshots,
        Default::default(),
        ChannelService::new(REST_PORT, false, None, None),
        dummy_on_replica_failure(),
        dummy_request_shard_transfer(),
        dummy_abort_shard_transfer(),
        None,
        None,
        ResourceBudget::default(),
        None,
    )
    .await
}

/// Observe the persisted shard count via the public State snapshot.
async fn persisted_shard_count(c: &Collection) -> u32 {
    c.state().await.config.params.shard_number.get()
}

/// Sorted shard ID set via the public `get_local_shards` method.
async fn sorted_shard_ids(c: &Collection) -> Vec<ShardId> {
    let mut ids = c.get_local_shards().await;
    ids.sort_unstable();
    ids
}

fn up_key(shard_id: u32) -> ReshardKey {
    ReshardKey {
        uuid: Uuid::new_v4(),
        direction: ReshardingDirection::Up,
        peer_id: 0,
        shard_id,
        shard_key: None,
    }
}

fn down_key(shard_id: u32) -> ReshardKey {
    ReshardKey {
        uuid: Uuid::new_v4(),
        direction: ReshardingDirection::Down,
        peer_id: 0,
        shard_id,
        shard_key: None,
    }
}

// ---------------------------------------------------------------------------
// Crash-window injection helpers
//
// These helpers manipulate two stable on-disk files to reproduce the exact
// crash window the PR targets.  They use plain `serde_json` on the files
// that have existed since before the PR — not any fix-introduced code.
// ---------------------------------------------------------------------------

/// Path of `config.json` relative to the collection root.
const COLLECTION_CONFIG_FILE: &str = "config.json";
/// Path of `resharding_state.json` relative to the collection root.
const RESHARDING_STATE_FILE: &str = "resharding_state.json";

/// Overwrite `config.json` on disk so that `params.shard_number` equals
/// `n`.  This simulates a crash that happened BEFORE the shard-count update
/// was persisted (but AFTER the resharding-state update that preceded it).
fn corrupt_config_shard_number(collection_path: &Path, n: u32) {
    let config_path = collection_path.join(COLLECTION_CONFIG_FILE);
    let raw = std::fs::read_to_string(&config_path)
        .expect("config.json must exist at collection_path");
    let mut v: serde_json::Value = serde_json::from_str(&raw).expect("config.json valid JSON");
    v["params"]["shard_number"] = serde_json::json!(n);
    std::fs::write(&config_path, serde_json::to_string_pretty(&v).unwrap())
        .expect("write corrupted config.json");
}

/// Write `resharding_state.json` to Some(state) for the given key.
/// Simulates a crash that happened AFTER the state was written but BEFORE
/// the next step in the apply function ran.
fn inject_resharding_state(collection_path: &Path, key: &ReshardKey, stage: ReshardingStage) {
    let state = ReshardState {
        uuid: key.uuid,
        peer_id: key.peer_id,
        shard_id: key.shard_id,
        shard_key: key.shard_key.clone(),
        direction: key.direction,
        stage,
    };
    let state_path = collection_path.join(RESHARDING_STATE_FILE);
    let json = serde_json::to_string_pretty(&Some::<ReshardState>(state))
        .expect("serialize ReshardState");
    std::fs::write(state_path, json).expect("write resharding_state.json");
}

/// Clear `resharding_state.json` to None.
/// Simulates a crash that happened AFTER the state was cleared (by
/// finish_resharding_unchecked / abort_resharding) but BEFORE the
/// subsequent `config.shard_number` update was persisted.
fn clear_resharding_state(collection_path: &Path) {
    let state_path = collection_path.join(RESHARDING_STATE_FILE);
    std::fs::write(state_path, "null").expect("write null resharding_state.json");
}

// ---------------------------------------------------------------------------
// FAIL-TO-PASS tests (3 f2p)
// ---------------------------------------------------------------------------

/// Crash window: `start_resharding` wrote `resharding_state.json` but crashed
/// BEFORE persisting `config.shard_number += 1`.
///
/// On reload the peer sees resharding_state=Some(matching) and
/// shard_number=1 (unchanged).  Pre-fix: the Collection-layer guard
/// `if resharding_state.is_some() && matches(key) { return Ok() }` fires
/// immediately — `shard_number` stays at 1 forever.  Fix: removes that
/// guard so the id-derived `shard_number = shard_id + 1 = 2` is written.
#[tokio::test(flavor = "multi_thread")]
async fn start_replay_reconverges() {
    let dir = Builder::new().prefix("start_replay").tempdir().unwrap();
    // shard_id=1 → after a successful start, shard_number should be 2.
    let key = up_key(1);

    // ── Step 1: full first apply (reference state) ──
    let c1 = new_collection(dir.path(), 1).await;
    c1.start_resharding(key.clone(), nop_consensus(), async {}, async {})
        .await
        .expect("first-time start_resharding must succeed");
    // After a successful start: shard_number=2, shard_set contains shard 1.
    let count_after_one = persisted_shard_count(&c1).await;
    let shards_after_one = sorted_shard_ids(&c1).await;
    assert_eq!(count_after_one, 2, "precondition: start raised count to 2");
    c1.stop_gracefully().await;
    drop(c1);

    // ── Step 2: inject crash window ──
    // Simulate: resharding_state was written, but the shard_number save
    // crashed before completing.  Reset shard_number to 1 on disk.
    corrupt_config_shard_number(dir.path(), 1);
    // resharding_state.json still holds Some(state) from the first apply —
    // no change needed there (it was persisted before the crash).

    // ── Step 3: reload (peer restart) + replay ──
    let c2 = reload_collection(dir.path()).await;
    assert_eq!(
        persisted_shard_count(&c2).await,
        1,
        "after crash-window injection: shard_number must be 1 (corrupted)",
    );
    c2.start_resharding(key.clone(), nop_consensus(), async {}, async {})
        .await
        .expect(
            "replaying start_resharding after a crash window must not error \
             (pre-fix Collection-layer guard fires and returns Ok without \
             fixing shard_number; the fix removes the guard so shard_number is reconciled)",
        );

    // ── Step 4: assert convergence ──
    let count_after_replay = persisted_shard_count(&c2).await;
    let shards_after_replay = sorted_shard_ids(&c2).await;

    assert_eq!(
        count_after_replay, count_after_one,
        "persisted shard_number after crash-window replay must equal single-apply value (2) \
         (pre-fix: stuck at 1 because Collection guard skips the id-derived update)",
    );
    assert_eq!(
        shards_after_replay, shards_after_one,
        "shard ID set after crash-window replay must equal single-apply set",
    );

    c2.stop_gracefully().await;
}

/// Crash window: `finish_resharding` cleared `resharding_state.json` (via
/// `finish_resharding_unchecked`) but crashed BEFORE
/// `drop_and_remove_shard` and `config.shard_number` update ran.
///
/// On reload the peer sees resharding_state=None, shard_number=3 (the
/// pre-finish value), and shard 2 still present on disk.  Pre-fix: the
/// Collection-layer guard `if resharding_state.is_none() { return Ok() }`
/// fires immediately — shard_number stays at 3 forever (should be 2) and
/// shard 2 is never dropped.  Fix: removes the guard so each step falls
/// through the individually-idempotent code: shard 2 is dropped and
/// `shard_number` is reconciled to `shard_id = 2`.
#[tokio::test(flavor = "multi_thread")]
async fn finish_replay_reconverges() {
    let dir = Builder::new().prefix("finish_replay").tempdir().unwrap();
    // Scale-down: remove shard_id=2 from a 3-shard collection.
    let key_down = down_key(2);

    // ── Step 1: reference state — what a single clean apply produces ──
    // We drive start+commit_read+commit_write only, then compute what finish
    // SHOULD produce so we can assert convergence after the crash replay.
    // (We don't call finish here — the crash happens before finish runs.)
    let c_ref = new_collection(dir.path().join("ref").as_path(), 3).await;
    c_ref
        .start_resharding(key_down.clone(), nop_consensus(), async {}, async {})
        .await
        .expect("ref: start scale-down");
    c_ref
        .commit_read_hashring(&key_down)
        .await
        .expect("ref: commit_read_hashring");
    c_ref
        .commit_write_hashring(&key_down)
        .await
        .expect("ref: commit_write_hashring");
    c_ref
        .finish_resharding(key_down.clone())
        .await
        .expect("ref: finish_resharding must succeed on clean collection");
    let count_after_one = persisted_shard_count(&c_ref).await;
    let shards_after_one = sorted_shard_ids(&c_ref).await;
    // After finish: shard_number=2, shard_set is {0,1}.
    assert_eq!(count_after_one, 2, "precondition: finish reduced count to 2");
    c_ref.stop_gracefully().await;
    drop(c_ref);

    // ── Step 2: build the crash-window state on a separate collection dir ──
    // This is the state the peer is in after `finish_resharding_unchecked`
    // ran (clearing resharding_state) but the process crashed before
    // `drop_and_remove_shard` and `config.shard_number` update ran.
    //
    // On disk: resharding_state=None, shard_number=3, shard 2 EXISTS.
    let coll_path = dir.path().join("crash");
    std::fs::create_dir_all(&coll_path).unwrap();
    let snapshots = coll_path.join("snapshots");
    std::fs::create_dir_all(&snapshots).unwrap();

    // Create a 3-shard collection and drive it to the WriteHashRingCommitted
    // stage, but NOT call finish_resharding.
    let c1 = new_collection(&coll_path, 3).await;
    c1.start_resharding(key_down.clone(), nop_consensus(), async {}, async {})
        .await
        .expect("start scale-down");
    c1.commit_read_hashring(&key_down)
        .await
        .expect("commit_read_hashring");
    c1.commit_write_hashring(&key_down)
        .await
        .expect("commit_write_hashring");
    // Now manually clear resharding_state.json on disk to simulate
    // `finish_resharding_unchecked` having run (which only clears the state
    // file).  The shard is still on disk and shard_number is still 3.
    c1.stop_gracefully().await;
    drop(c1);
    clear_resharding_state(&coll_path);

    // ── Step 3: reload (peer restart after crash) ──
    let c2 = reload_collection(&coll_path).await;
    assert_eq!(
        persisted_shard_count(&c2).await,
        3,
        "after crash-window injection: shard_number must be 3 (stale, pre-finish value)",
    );
    // Shard 2 should still be present (not yet dropped)
    assert!(
        sorted_shard_ids(&c2).await.contains(&2),
        "shard 2 must still exist in the crash-window state",
    );

    // ── Step 4: replay finish_resharding ──
    c2.finish_resharding(key_down.clone())
        .await
        .expect(
            "replaying finish_resharding after a crash window must not error \
             (pre-fix Collection guard returns Ok without reconciling; \
             the fix removes the guard so shard is dropped and shard_number is reconciled)",
        );

    // ── Step 5: assert convergence ──
    let count_after_replay = persisted_shard_count(&c2).await;
    let shards_after_replay = sorted_shard_ids(&c2).await;

    assert_eq!(
        count_after_replay, count_after_one,
        "persisted shard_number after crash-window replay must equal single-apply value (2) \
         (pre-fix: stuck at 3 because Collection guard skips the shard_number update)",
    );
    assert_eq!(
        shards_after_replay, shards_after_one,
        "shard ID set after crash-window replay must equal single-apply set ({shards_after_one:?}); \
         pre-fix leaves shard 2 present (never dropped), the fix removes it",
    );

    c2.stop_gracefully().await;
}

/// Crash window: `abort_resharding` (scale-up) cleared `resharding_state.json`
/// via the ShardHolder-level abort (which removes the shard from the in-memory
/// map and the on-disk state) but the Collection-level logic crashed BEFORE
/// `drop_and_remove_shard` and `config.shard_number -= 1` ran.
///
/// On reload the peer sees resharding_state=None, shard_number=3 (the
/// post-start/pre-abort value), and shard 2 still present on disk.
/// Pre-fix: the Collection-layer guard
/// `if resharding_state.is_none() { return Ok() }` fires immediately —
/// shard_number stays at 3 forever (should be 2) and shard 2 is never
/// cleaned up.  Fix: removes the guard so each step falls through:
/// shard 2 is dropped and `shard_number` is reconciled to `shard_id = 2`.
#[tokio::test(flavor = "multi_thread")]
async fn abort_replay_reconverges() {
    let dir = Builder::new().prefix("abort_replay").tempdir().unwrap();
    // Abort a scale-up of shard_id=2 on a 2-shard collection.
    let key = up_key(2);

    // ── Step 1: reference state — what a single clean apply produces ──
    let c_ref = new_collection(dir.path().join("ref").as_path(), 2).await;
    c_ref
        .start_resharding(key.clone(), nop_consensus(), async {}, async {})
        .await
        .expect("ref: start scale-up");
    c_ref
        .abort_resharding(key.clone(), false)
        .await
        .expect("ref: abort_resharding must succeed");
    let count_after_one = persisted_shard_count(&c_ref).await;
    let shards_after_one = sorted_shard_ids(&c_ref).await;
    // After abort-up: shard_number=2, shard_set is {0,1}.
    assert_eq!(count_after_one, 2, "precondition: abort restored count to 2");
    c_ref.stop_gracefully().await;
    drop(c_ref);

    // ── Step 2: build the crash-window state on a separate collection dir ──
    // This is the state after `start_resharding` succeeded (shard_number=3,
    // shard 2 created) and resharding_state was cleared (simulating
    // abort_resharding's ShardHolder-level clear running), but before the
    // Collection-level `drop_and_remove_shard` + shard_number update ran.
    //
    // On disk: resharding_state=None, shard_number=3, shard 2 EXISTS.
    let coll_path = dir.path().join("crash");
    std::fs::create_dir_all(&coll_path).unwrap();
    let snapshots = coll_path.join("snapshots");
    std::fs::create_dir_all(&snapshots).unwrap();

    let c1 = new_collection(&coll_path, 2).await;
    c1.start_resharding(key.clone(), nop_consensus(), async {}, async {})
        .await
        .expect("start scale-up");
    // After start: shard_number=3, shard 2 on disk, resharding_state=Some.
    assert_eq!(
        persisted_shard_count(&c1).await,
        3,
        "precondition: start raised count to 3",
    );
    // Simulate ShardHolder abort having cleared resharding_state.json but
    // Collection not having finished the drop + count update.
    c1.stop_gracefully().await;
    drop(c1);
    clear_resharding_state(&coll_path);
    // shard_number stays at 3 (not decremented yet), shard 2 still on disk.

    // ── Step 3: reload (peer restart after crash) ──
    let c2 = reload_collection(&coll_path).await;
    assert_eq!(
        persisted_shard_count(&c2).await,
        3,
        "after crash-window injection: shard_number must be 3 (stale, pre-abort value)",
    );
    assert!(
        sorted_shard_ids(&c2).await.contains(&2),
        "shard 2 must still exist in the crash-window state",
    );

    // ── Step 4: replay abort_resharding ──
    c2.abort_resharding(key.clone(), false)
        .await
        .expect(
            "replaying abort_resharding after a crash window must not error \
             (pre-fix Collection guard returns Ok without reconciling; \
             the fix removes the guard so shard is dropped and shard_number is reconciled)",
        );

    // ── Step 5: assert convergence ──
    let count_after_replay = persisted_shard_count(&c2).await;
    let shards_after_replay = sorted_shard_ids(&c2).await;

    assert_eq!(
        count_after_replay, count_after_one,
        "persisted shard_number after crash-window abort replay must equal single-apply value (2) \
         (pre-fix: stuck at 3 because Collection guard skips the shard_number reconcile)",
    );
    assert_eq!(
        shards_after_replay, shards_after_one,
        "shard ID set after crash-window abort replay must equal single-apply set",
    );

    c2.stop_gracefully().await;
}

// ---------------------------------------------------------------------------
// FAIL-TO-PASS tests (3 more f2p): full-apply-then-replay (no crash window)
//
// These discriminate the id-derived (idempotent) count update from an
// arithmetic gaming fix that removes the early-return guards but keeps
// `shard_number += 1` / `-= 1`.  With no rollback, the count is already
// correct; the id-derived expression is a no-op, while arithmetic
// drifts.  Pre-fix PASSES these via its early-return guards — the guards are
// correct on a no-op replay; the gaming fix removes the guard AND keeps the
// drift.
// ---------------------------------------------------------------------------

/// Full-apply-then-replay: `start_resharding` with the count already correct.
///
/// The id-derived update (`shard_id + 1 = 2`) is a no-op when the
/// persisted count is already 2.  An arithmetic fix that keeps
/// `shard_number += 1` would drift to 3 — the must-reject gaming shape in
/// task.toml.  Pre-fix passes this test via its early-return guard
/// (`resharding_state.is_some() && matches(key) → Ok()`); the guard is correct
/// here, but the arithmetic gaming fix removes it AND keeps the drift.
#[tokio::test(flavor = "multi_thread")]
async fn start_replay_idempotent() {
    let dir = Builder::new().prefix("start_idem").tempdir().unwrap();
    let key = up_key(1);

    // ── Step 1: full first apply ──
    let c1 = new_collection(dir.path(), 1).await;
    c1.start_resharding(key.clone(), nop_consensus(), async {}, async {})
        .await
        .expect("first start_resharding must succeed");
    let count_after_one = persisted_shard_count(&c1).await;
    let shards_after_one = sorted_shard_ids(&c1).await;
    assert_eq!(count_after_one, 2, "precondition: shard_number=2 after start");
    c1.stop_gracefully().await;
    drop(c1);

    // ── Step 2: reload — no crash injection, shard_number stays 2 on disk ──
    let c2 = reload_collection(dir.path()).await;
    assert_eq!(
        persisted_shard_count(&c2).await,
        2,
        "precondition: shard_number=2 persisted correctly after full apply",
    );

    // ── Step 3: replay (count already correct) ──
    c2.start_resharding(key.clone(), nop_consensus(), async {}, async {})
        .await
        .expect(
            "replaying start_resharding when shard_number is already correct must not error; \
             id-derived update is a no-op; arithmetic +1 would drift to 3",
        );

    // ── Step 4: assert no drift ──
    let count_after_replay = persisted_shard_count(&c2).await;
    let shards_after_replay = sorted_shard_ids(&c2).await;

    assert_eq!(
        count_after_replay, count_after_one,
        "shard_number must NOT drift on replay when already correct ({count_after_one}); \
         arithmetic `+= 1` gaming fix would produce 3 instead of 2",
    );
    assert_eq!(
        shards_after_replay, shards_after_one,
        "shard ID set must not change on a no-op replay of start",
    );

    c2.stop_gracefully().await;
}

/// Full-apply-then-replay: `finish_resharding` with the count already correct.
///
/// The id-derived update (`shard_id = 2`) is a no-op when the
/// persisted count is already 2.  An arithmetic fix that keeps
/// `shard_number -= 1` would drift to 1 — the must-reject gaming shape.
/// Pre-fix passes via its early-return guard
/// (`resharding_state.is_none() → Ok()`); the arithmetic gaming fix removes
/// that guard AND keeps the drift.
#[tokio::test(flavor = "multi_thread")]
async fn finish_replay_idempotent() {
    let dir = Builder::new().prefix("finish_idem").tempdir().unwrap();
    let key_down = down_key(2);

    // ── Step 1: full apply (3-shard collection → finish scale-down) ──
    let c1 = new_collection(dir.path(), 3).await;
    c1.start_resharding(key_down.clone(), nop_consensus(), async {}, async {})
        .await
        .expect("start scale-down");
    c1.commit_read_hashring(&key_down)
        .await
        .expect("commit_read_hashring");
    c1.commit_write_hashring(&key_down)
        .await
        .expect("commit_write_hashring");
    c1.finish_resharding(key_down.clone())
        .await
        .expect("finish_resharding must succeed on clean collection");
    let count_after_one = persisted_shard_count(&c1).await;
    let shards_after_one = sorted_shard_ids(&c1).await;
    assert_eq!(count_after_one, 2, "precondition: shard_number=2 after finish");
    c1.stop_gracefully().await;
    drop(c1);

    // ── Step 2: reload — no crash injection, shard_number stays 2 ──
    let c2 = reload_collection(dir.path()).await;
    assert_eq!(
        persisted_shard_count(&c2).await,
        2,
        "precondition: shard_number=2 persisted correctly after full finish",
    );

    // ── Step 3: replay (count already correct, shard 2 already dropped) ──
    c2.finish_resharding(key_down.clone())
        .await
        .expect(
            "replaying finish_resharding when already finished must not error; \
             fix ShardHolder ops are individually idempotent; \
             arithmetic -= 1 gaming fix would drift to 1",
        );

    // ── Step 4: assert no drift ──
    let count_after_replay = persisted_shard_count(&c2).await;
    let shards_after_replay = sorted_shard_ids(&c2).await;

    assert_eq!(
        count_after_replay, count_after_one,
        "shard_number must NOT drift on replay when already correct ({count_after_one}); \
         arithmetic `-= 1` gaming fix would produce 1 instead of 2",
    );
    assert_eq!(
        shards_after_replay, shards_after_one,
        "shard ID set must not change on a no-op replay of finish",
    );

    c2.stop_gracefully().await;
}

/// Full-apply-then-replay: `abort_resharding` with the count already correct.
///
/// The id-derived update (`shard_id = 2`) is a no-op when the
/// persisted count is already 2.  An arithmetic fix that keeps
/// `shard_number -= 1` would drift to 1 — the must-reject gaming shape.
/// Pre-fix passes via its early-return guard
/// (`resharding_state.is_none() → Ok()`); the arithmetic gaming fix removes
/// that guard AND keeps the drift.
#[tokio::test(flavor = "multi_thread")]
async fn abort_replay_idempotent() {
    let dir = Builder::new().prefix("abort_idem").tempdir().unwrap();
    let key = up_key(2);

    // ── Step 1: full apply (start + abort on a 2-shard collection) ──
    let c1 = new_collection(dir.path(), 2).await;
    c1.start_resharding(key.clone(), nop_consensus(), async {}, async {})
        .await
        .expect("start scale-up");
    c1.abort_resharding(key.clone(), false)
        .await
        .expect("abort_resharding must succeed");
    let count_after_one = persisted_shard_count(&c1).await;
    let shards_after_one = sorted_shard_ids(&c1).await;
    assert_eq!(count_after_one, 2, "precondition: shard_number=2 after abort");
    c1.stop_gracefully().await;
    drop(c1);

    // ── Step 2: reload — no crash injection, shard_number stays 2 ──
    let c2 = reload_collection(dir.path()).await;
    assert_eq!(
        persisted_shard_count(&c2).await,
        2,
        "precondition: shard_number=2 persisted correctly after full abort",
    );

    // ── Step 3: replay (count already correct, shard 2 already dropped) ──
    c2.abort_resharding(key.clone(), false)
        .await
        .expect(
            "replaying abort_resharding when already aborted must not error; \
             fix ShardHolder ops are individually idempotent; \
             arithmetic -= 1 gaming fix would drift to 1",
        );

    // ── Step 4: assert no drift ──
    let count_after_replay = persisted_shard_count(&c2).await;
    let shards_after_replay = sorted_shard_ids(&c2).await;

    assert_eq!(
        count_after_replay, count_after_one,
        "shard_number must NOT drift on replay when already correct ({count_after_one}); \
         arithmetic `-= 1` gaming fix would produce 1 instead of 2",
    );
    assert_eq!(
        shards_after_replay, shards_after_one,
        "shard ID set must not change on a no-op replay of abort",
    );

    c2.stop_gracefully().await;
}

// ---------------------------------------------------------------------------
// PASS-TO-PASS test (1 p2p)
// ---------------------------------------------------------------------------

/// Happy path: a first-time apply on a fresh collection still registers the
/// new shard and updates the persisted count.  Guards against an over-
/// correction that makes the idempotency guards no-op the FIRST apply too.
/// Holds on both pre-fix and post-fix trees.
#[tokio::test(flavor = "multi_thread")]
async fn first_apply_still_registers() {
    let dir = Builder::new().prefix("first_apply").tempdir().unwrap();
    let key = up_key(1);

    let c = new_collection(dir.path(), 1).await;
    assert_eq!(
        persisted_shard_count(&c).await,
        1,
        "precondition: fresh 1-shard collection has shard_number=1",
    );

    c.start_resharding(key.clone(), nop_consensus(), async {}, async {})
        .await
        .expect("first-time start_resharding on a clean collection must succeed");

    let count = persisted_shard_count(&c).await;
    let shards = sorted_shard_ids(&c).await;

    assert_eq!(
        count, 2,
        "a first-time scale-up start must increase shard_number to 2 \
         (idempotency guards must not no-op the first apply)",
    );
    assert!(
        shards.contains(&1),
        "a first-time start must register the new shard id in the shard set, got: {shards:?}",
    );
    assert!(
        c.resharding_state().await.is_some(),
        "a first-time start must record resharding state",
    );

    c.stop_gracefully().await;
}
