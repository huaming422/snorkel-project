## Task

Our CLI installs AI-assistant config files from Git/GitHub "sources" and apm
packages, recording what it installed in lockfiles (`rulesync.lock`,
`rulesync-apm.lock.yaml`). Operators have sent in a cluster of install/lock
reports that all look like the same trust problem.

`rulesync install --mode apm`, run in a repo that already carries a committed
apm lockfile, sometimes deletes in-project files it never installed. One user
lost local files under `.git/` this way. That same cleanup can also follow a
symlink and clobber the link's target instead of the link.

Ref resolution is loose too. An install can pull the wrong commit for a tag
when another branch shares that tag's name. And a commit pinned in a lockfile
stays trusted blindly: after the ref changes in the manifest, `install` reuses
the old commit, and `--frozen` doesn't catch the drift.

Dig in and fix the whole path. Out of scope: detecting a rewritten lockfile
that downgrades a version, and how `rulesync fetch` handles symlinks at the
project root. Keep the public install and resolve signatures unchanged; this is
behavioral hardening, not an API change.
