#!/usr/bin/env bash
# Verifier setup for rulesync-fix-install-hardening.
#
# rulesync is a single-package repo: vitest transforms `src/**/*.test.ts`
# directly through vite (see vitest.config.ts `include`), so there is NO build
# step — a verifier test that imports `./git-client.js`, `./sources.js`,
# `./apm/apm-install.js` or `./gh/gh-install.js` sees the agent's edited source
# immediately. Nothing to rebuild here.
#
# Sourced (not exec'd) by the harbor runner, so env vars set here stay live for
# the verifier subprocess.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/rulesync}"
export REPO_DIR
cd "$REPO_DIR"

# The harbor runner shells out to run_verify.py + runners/js.py, which read the
# per-task verify.toml via Python's tomllib. The verifier runs under the baked
# /opt/tooling verifier venv (Python 3.12), which has tomllib in the standard
# library, so no extra install is needed here.

# Sanity check: vitest must be resolvable from the repo root. The image baked a
# frozen `pnpm install` from this commit's lockfile into the pnpm store +
# node_modules, so this should always be present; a missing binary points at a
# corrupt image.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/." \
         "The image build looks corrupt." >&2
    exit 1
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
