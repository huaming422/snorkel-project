// @ts-nocheck
//
// Behavioral verifier for ref resolution through the pre-existing, stable
// exported function `resolveRefToSha(url, ref)` in src/lib/git-client.ts. Its
// signature is unchanged by the fix; only its internal resolution behavior is
// hardened. We drive it exactly as the repo's own git-client.test.ts does, by
// mocking the promisified `execFile` so no real `git` or network is touched.
//
// What is asserted is OBSERVABLE BEHAVIOR of the function, never the shape of
// any new internal helper (e.g. a stdout parser): the returned SHA, and whether
// the call throws. A valid fix may issue one multi-ref `ls-remote` or several
// single-ref calls, parse stdout differently, or query in a different order —
// every such variant passes here as long as:
//   * a branch whose name is only a suffix of the requested ref cannot stand
//     in for it,
//   * an annotated tag resolves to its PEELED commit (not the tag-object SHA),
//   * a branch and a tag of the same name at different commits are refused,
//     and at the same commit are accepted.
//
// There is NO argv-shaped assertion anywhere in this file. We never inspect the
// `ls-remote` arguments, the query count, or the order of calls — only the
// returned SHA and whether the call throws. A correct fix may query exact ref
// names in one call or several, filter `--heads --tags`, or keep passing a
// pattern and exact-match client-side; every such variant passes here.

import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const { mockExecFileAsync } = vi.hoisted(() => ({ mockExecFileAsync: vi.fn() }));

vi.mock("node:child_process", () => ({ execFile: vi.fn() }));
vi.mock("node:util", () => ({ promisify: () => mockExecFileAsync }));

import { GitClientError, resetGitCheck, resolveRefToSha } from "./git-client.js";

const SHA = "a".repeat(40);
const URL = "https://example.com/repo.git";

describe("resolveRefToSha", () => {
  beforeEach(() => {
    // `checkGitAvailable()` runs `git --version` through the same mocked
    // execFile; a resolved value keeps the availability probe happy.
    mockExecFileAsync.mockResolvedValue({ stdout: "git version 2.43.0\n" });
  });

  afterEach(() => {
    vi.clearAllMocks();
    resetGitCheck();
  });

  // NOTE: we deliberately do NOT assert on the `ls-remote` argv (not the exact
  // array, the query count, nor the `refs/tags/<ref>^{}` form). A correct fix
  // may query exact ref names in one call or several, filter `--heads --tags`,
  // or even keep passing the pattern and exact-match the returned refs
  // client-side — all are valid. The four behavioral cases below (suffix
  // rejected, annotated tag peeled, ambiguity thrown/accepted) fully separate
  // the pre-fix suffix-pattern behavior from any hardened resolver through
  // observable return values alone.

  it("ignores a same-suffix branch and returns the peeled commit of an annotated tag", async () => {
    const branchSha = "b".repeat(40);
    const tagObjectSha = "c".repeat(40);
    const tagCommitSha = "d".repeat(40);
    // A branch `feature/v1` shares the suffix `v1` with the requested tag. The
    // tag is annotated, so its own object SHA differs from the commit it points
    // at (the `^{}` peeled line). The fix must return the peeled commit, never
    // the branch (which the pre-fix "first 40-hex line wins" logic would pick).
    mockExecFileAsync.mockResolvedValue({
      stdout: [
        `${branchSha}\trefs/heads/feature/v1`,
        `${tagObjectSha}\trefs/tags/v1`,
        `${tagCommitSha}\trefs/tags/v1^{}`,
        "",
      ].join("\n"),
    });

    expect(await resolveRefToSha(URL, "v1")).toBe(tagCommitSha);
  });

  it("does not resolve a ref that only matches by suffix", async () => {
    // Only a branch whose name ends with the requested ref is present; there is
    // no exact `refs/heads/v1` or `refs/tags/v1`. The ref must be reported not
    // found rather than resolving to the suffix branch.
    mockExecFileAsync.mockResolvedValue({ stdout: `${SHA}\trefs/heads/feature/v1\n` });

    // The pre-fix resolver returns the suffix branch's SHA (no throw); a
    // hardened one refuses. We assert only that it refuses — the error wording
    // ("not found", "could not resolve", …) is not pinned.
    await expect(resolveRefToSha(URL, "v1")).rejects.toThrow();
  });

  it("refuses a branch and a tag of the same name pointing at different commits", async () => {
    mockExecFileAsync.mockResolvedValue({
      stdout: `${"b".repeat(40)}\trefs/heads/v1\n${"c".repeat(40)}\trefs/tags/v1\n`,
    });

    await expect(resolveRefToSha(URL, "v1")).rejects.toThrow(/ambiguous/);
  });

  it("accepts a branch and a tag of the same name pointing at the same commit", async () => {
    // Guard against an over-aggressive ambiguity check that rejects ANY
    // branch+tag coincidence: when both point at the same commit there is no
    // ambiguity and the SHA must be returned.
    mockExecFileAsync.mockResolvedValue({
      stdout: `${SHA}\trefs/heads/v1\n${SHA}\trefs/tags/v1\n`,
    });

    expect(await resolveRefToSha(URL, "v1")).toBe(SHA);
  });

  it("returns the resolved commit for an ordinary branch", async () => {
    // Baseline happy path: an exact branch match resolves to its commit. This
    // keeps a hardened resolver from regressing the common case.
    mockExecFileAsync.mockResolvedValue({ stdout: `${SHA}\trefs/heads/main\n` });

    expect(await resolveRefToSha(URL, "main")).toBe(SHA);
  });
});

// Keep the import referenced so an unused-import lint cannot trip the suite.
void GitClientError;
