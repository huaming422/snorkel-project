// @ts-nocheck
//
// Behavioral verifier for the apm install/lock path through the pre-existing,
// stable exported function `installApm({ projectRoot, logger, options })` in
// src/lib/apm/apm-install.ts. Its signature is unchanged by the fix; only its
// internal behavior is hardened. We drive it exactly as the repo's own
// apm-install.test.ts does: mock the GitHubClient (now including a
// `compareCommits` method on the mock surface, which the real client already
// exposes and gh mode already uses) and run against a real temp project dir.
//
// Everything asserted is OBSERVABLE: files on disk after install, thrown
// errors, `failedDependencyCount`, the written lockfile, and warn-log messages.
// No fix-introduced internal helper (resolveApmDependencyRef,
// writeFrozenApmDeployments, removeFileWithoutFollowingSymlinks) is imported or
// named — a valid fix may inline, rename, or restructure all of them.

import { mkdir, readdir, symlink } from "node:fs/promises";
import { join } from "node:path";

import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { createMockLogger } from "../../test-utils/mock-logger.js";
import { setupTestDirectory } from "../../test-utils/test-directories.js";
import { fileExists, readFileContent, writeFileContent } from "../../utils/file.js";
import { installApm } from "./apm-install.js";
import { getApmLockPath, readApmLock } from "./apm-lock.js";
import { getApmManifestPath } from "./apm-manifest.js";

let mockClientInstance: any;

vi.mock("../github-client.js", () => ({
  GitHubClient: class MockGitHubClient {
    static resolveToken = vi.fn().mockReturnValue(undefined);

    getDefaultBranch(...args: any[]) {
      return mockClientInstance.getDefaultBranch(...args);
    }
    resolveRefToSha(...args: any[]) {
      return mockClientInstance.resolveRefToSha(...args);
    }
    listDirectory(...args: any[]) {
      return mockClientInstance.listDirectory(...args);
    }
    getFileContent(...args: any[]) {
      return mockClientInstance.getFileContent(...args);
    }
    compareCommits(...args: any[]) {
      return mockClientInstance.compareCommits(...args);
    }
  },
  GitHubClientError: class GitHubClientError extends Error {
    statusCode?: number;
    constructor(message: string, statusCode?: number) {
      super(message);
      this.statusCode = statusCode;
    }
  },
  logGitHubAuthHints: vi.fn(),
}));

const VALID_SHA = "a".repeat(40);
const SECOND_SHA = "b".repeat(40);

describe("installApm", () => {
  let testDir: string;
  let cleanup: () => Promise<void>;
  const logger = createMockLogger();

  beforeEach(async () => {
    ({ testDir, cleanup } = await setupTestDirectory());

    mockClientInstance = {
      getDefaultBranch: vi.fn().mockResolvedValue("main"),
      resolveRefToSha: vi.fn().mockResolvedValue(VALID_SHA),
      listDirectory: vi.fn(),
      getFileContent: vi.fn(),
      compareCommits: vi.fn().mockResolvedValue("identical"),
    };
  });

  afterEach(async () => {
    await cleanup();
    vi.clearAllMocks();
  });

  async function writeManifest(content: string): Promise<void> {
    await writeFileContent(getApmManifestPath(testDir), content);
  }

  // A committed lockfile naming `deployedFiles` as stale. No content_hash is
  // written, so the integrity check is skipped and the run reaches stale
  // removal / re-resolution directly.
  function staleLockYaml(deployedFiles: string[]): string {
    return `lockfile_version: "1"
generated_at: "2026-04-20T00:00:00Z"
apm_version: "0.7.7"
dependencies:
  - repo_url: https://github.com/acme/security
    resolved_commit: ${VALID_SHA}
    resolved_ref: v1.0.0
    depth: 1
    package_type: apm_package
    deployed_files:
${deployedFiles.map((file) => `      - ${file}`).join("\n")}
`;
  }

  // ── Stale-removal confinement to the apm deploy directories ──────────────

  it("refuses to remove stale files outside the apm deploy directories", async () => {
    // A committed lockfile names paths all over the checkout — a .git file, an
    // untracked file, and two LOOK-ALIKE prefixes (`instructions-evil`,
    // `skills-extra`) that a naive `startsWith(deployDir)` check would match —
    // plus one genuine stale file inside `.github/instructions/`. Only the
    // genuine one may be removed.
    await writeFileContent(join(testDir, ".git", "HEAD"), "ref: refs/heads/main\n");
    await writeFileContent(join(testDir, "notes.txt"), "untracked");
    await writeFileContent(join(testDir, ".github/instructions-evil/x.md"), "lookalike");
    await writeFileContent(join(testDir, ".github/skills-extra/y.md"), "lookalike");
    await writeFileContent(join(testDir, ".github/instructions/old.instructions.md"), "stale");
    await writeFileContent(
      getApmLockPath(testDir),
      staleLockYaml([
        ".git/HEAD",
        "notes.txt",
        ".github/instructions-evil/x.md",
        ".github/skills-extra/y.md",
        ".github/instructions/old.instructions.md",
      ]),
    );
    await writeManifest(`dependencies:
  apm:
    - acme/security#v1.0.0
`);
    mockClientInstance.listDirectory.mockResolvedValue([]);

    const localLogger = createMockLogger();
    await installApm({ projectRoot: testDir, logger: localLogger, options: { update: true } });

    expect(await fileExists(join(testDir, ".git", "HEAD"))).toBe(true);
    expect(await fileExists(join(testDir, "notes.txt"))).toBe(true);
    expect(await fileExists(join(testDir, ".github/instructions-evil/x.md"))).toBe(true);
    expect(await fileExists(join(testDir, ".github/skills-extra/y.md"))).toBe(true);
    expect(await fileExists(join(testDir, ".github/instructions/old.instructions.md"))).toBe(false);
    // The four survivals + the one genuine removal fully separate a hardened
    // install from an unhardened one on their own (the pre-fix code deletes all
    // five, including `.git/HEAD`), and they do not depend on any message text.
    // We additionally require that skipping the outside paths was not silent —
    // at least one warn was emitted — without pinning the sentence, since the
    // wording is a solution choice.
    expect(localLogger.warn.mock.calls.length).toBeGreaterThan(0);
  });

  // ── Symlink-safe stale removal (the stale entry is itself a link) ─────────

  it.skipIf(process.platform === "win32")(
    "unlinks a stale file that is itself a symbolic link without touching its target",
    async () => {
      // The stale entry under `.github/instructions/` is a symlink to a kept
      // file one level up. The fix must unlink the LINK ITSELF (leaving its
      // target untouched); the pre-fix code refuses to touch a stale entry that
      // is a symlink at all, so it orphans the link — it stays on disk. We
      // assert the link is gone and the target is intact: both must hold.
      await writeFileContent(join(testDir, "kept.md"), "link target");
      await mkdir(join(testDir, ".github", "instructions"), { recursive: true });
      await symlink(
        join("..", "..", "kept.md"),
        join(testDir, ".github", "instructions", "old.instructions.md"),
      );
      await writeFileContent(
        getApmLockPath(testDir),
        staleLockYaml([".github/instructions/old.instructions.md"]),
      );
      await writeManifest(`dependencies:
  apm:
    - acme/security#v1.0.0
`);
      mockClientInstance.listDirectory.mockResolvedValue([]);

      await installApm({ projectRoot: testDir, logger, options: { update: true } });

      // The link is gone (directory is empty) but the target survives unchanged.
      expect(await readdir(join(testDir, ".github", "instructions"))).toEqual([]);
      expect(await readFileContent(join(testDir, "kept.md"))).toBe("link target");
    },
  );

  // ── apm lock-pin ref-history check via compareCommits ────────────────────

  it("refuses a locked commit that is not in the declared ref's history", async () => {
    // First install populates the lock with the resolved commit. Then the
    // client reports the locked commit has `diverged` from the declared ref:
    // a normal install must re-resolve and count the dependency as failed
    // (leaving the lock unchanged), and a --frozen install must reject.
    await writeManifest(`dependencies:
  apm:
    - acme/security#v1.0.0
`);
    mockClientInstance.listDirectory.mockResolvedValue([]);
    await installApm({ projectRoot: testDir, logger });
    const lockBefore = await readApmLock(testDir);

    mockClientInstance.compareCommits.mockResolvedValue("diverged");
    const result = await installApm({ projectRoot: testDir, logger });

    // The ref-history check must relate the LOCKED COMMIT (VALID_SHA) to the
    // declared ref (v1.0.0) through compareCommits. We assert both appear as the
    // two commit-ish arguments, in EITHER base/head orientation: "is the locked
    // commit an ancestor of the ref" can be asked as base=commit/head=ref
    // (accept identical|ahead) or base=ref/head=commit (accept identical|behind)
    // — both are correct, so pinning one orientation would reject a valid fix.
    // owner/repo are the pre-existing method's own parameter names (not a
    // solution choice). We do NOT assert the status set or the call count.
    const compareArgs = mockClientInstance.compareCommits.mock.calls.map((c) => c[0]);
    expect(
      compareArgs.some(
        (a) =>
          a?.owner === "acme" &&
          a?.repo === "security" &&
          [a?.base, a?.head].includes(VALID_SHA) &&
          [a?.base, a?.head].includes("v1.0.0"),
      ),
    ).toBe(true);
    expect(result.failedDependencyCount).toBe(1);
    expect((await readApmLock(testDir))?.dependencies).toEqual(lockBefore?.dependencies);

    // --frozen must reject the diverged pin. The THROW is the distinguishing
    // signal: the pre-fix code reuses the locked commit and never throws here.
    // We anchor loosely on the "commit not in the ref's history" reason,
    // allowing the common rewordings (history / diverged / ancestor / reachable
    // / belongs), so a fix that phrases the same reason differently still passes.
    await expect(
      installApm({ projectRoot: testDir, logger, options: { frozen: true } }),
    ).rejects.toThrow(/history|diverge|ancestor|reachable|belong/i);
  });

  it("--frozen refuses a locked default branch that is no longer the default branch", async () => {
    // The dependency declares no ref, so the lock pins the then-default branch
    // `main`. The default branch later moves to `trunk`; under --frozen the
    // install must reject because the declared ref (the new default) no longer
    // matches the locked ref — without re-resolving.
    await writeManifest(`dependencies:
  apm:
    - acme/security
`);
    mockClientInstance.listDirectory.mockResolvedValue([]);
    await installApm({ projectRoot: testDir, logger });

    mockClientInstance.getDefaultBranch.mockResolvedValue("trunk");
    // The locked ref (`main`) no longer matches the now-declared ref (the new
    // default `trunk`), so --frozen must reject. Two observable signals, relied
    // on together and independent of any message text: (1) it THROWS at all (the
    // pre-fix code reuses the locked commit and never throws), and (2) it
    // refused up front without re-resolving — resolveRefToSha was called only by
    // the first, non-frozen install.
    await expect(
      installApm({ projectRoot: testDir, logger, options: { frozen: true } }),
    ).rejects.toThrow();
    expect(mockClientInstance.resolveRefToSha).toHaveBeenCalledTimes(1);
  });

  it("re-resolves a dependency whose declared ref no longer matches the lock", async () => {
    // Install at v1.0.0, then edit the manifest to v2.0.0. The next install
    // must re-resolve against the NEW ref and rewrite the lock — not keep
    // reusing the commit resolved for the old ref.
    await writeManifest(`dependencies:
  apm:
    - acme/security#v1.0.0
`);
    mockClientInstance.listDirectory.mockResolvedValue([]);
    await installApm({ projectRoot: testDir, logger });

    await writeManifest(`dependencies:
  apm:
    - acme/security#v2.0.0
`);
    mockClientInstance.resolveRefToSha.mockResolvedValue(SECOND_SHA);
    await installApm({ projectRoot: testDir, logger });

    expect(mockClientInstance.resolveRefToSha).toHaveBeenLastCalledWith(
      "acme",
      "security",
      "v2.0.0",
    );
    const lock = await readApmLock(testDir);
    expect(lock?.dependencies[0]).toMatchObject({
      resolved_commit: SECOND_SHA,
      resolved_ref: "v2.0.0",
    });
  });

  // ── --frozen cross-dependency write barrier ──────────────────────────────

  it.skipIf(process.platform === "win32")(
    "--frozen checks every dependency's targets before writing any dependency",
    async () => {
      // Two dependencies, installed concurrently. Only the SECOND deploys
      // skills, and its skills directory is a symlink pointing outside the
      // project, so processing the second dependency must fail. Under --frozen
      // the run must fail WITHOUT writing the first dependency's file — a cross-
      // dependency barrier checks every dependency's targets before any write.
      //
      // The behavioral fork we rely on: a per-dependency writer couples the
      // first dependency's write to its OWN completion (it is written as soon as
      // that dependency is processed, regardless of the second), whereas a
      // cross-dependency barrier gates every write behind all dependencies
      // passing. To observe that fork deterministically rather than racing the
      // two concurrent dependencies, we make the second dependency strictly
      // slower (a delayed mock): a per-dependency writer therefore finishes
      // writing the first dependency's file well before the second fails, so the
      // file is present; the barrier writes nothing because the second
      // dependency never clears the pre-write check. The delay cannot make the
      // barrier write the file — it only removes the scheduling coin-flip.
      const projectRoot = join(testDir, "project");
      const outsideDir = join(testDir, "outside");
      await mkdir(join(projectRoot, ".github"), { recursive: true });
      await mkdir(outsideDir, { recursive: true });
      await symlink(outsideDir, join(projectRoot, ".github", "skills"));
      const lockEntry = (repo: string, deployed: string): string =>
        `  - repo_url: https://github.com/acme/${repo}
    resolved_commit: ${VALID_SHA}
    resolved_ref: v1.0.0
    depth: 1
    package_type: apm_package
    content_hash: "sha256:legacy"
    deployed_files:
      - ${deployed}
`;
      await writeFileContent(
        getApmLockPath(projectRoot),
        `lockfile_version: "1"
generated_at: "2026-04-20T00:00:00Z"
apm_version: "0.7.7"
dependencies:
${lockEntry("first", ".github/instructions/a.instructions.md")}${lockEntry("second", ".github/skills/s/SKILL.md")}`,
      );
      await writeFileContent(
        getApmManifestPath(projectRoot),
        `dependencies:
  apm:
    - acme/first#v1.0.0
    - acme/second#v1.0.0
`,
      );
      // The two dependencies install concurrently; to make the first
      // dependency's write deterministically precede the second's failure (so a
      // per-dependency writer is reliably caught), the second dependency's
      // directory listings are delayed. The delay only orders the race — it
      // never changes WHICH dependency fails.
      const delay = (ms: number): Promise<void> =>
        new Promise((resolve) => {
          setTimeout(resolve, ms);
        });
      mockClientInstance.listDirectory.mockImplementation(
        async (_owner: string, repo: string, path: string) => {
          if (repo === "first" && path === ".apm/instructions") {
            return [
              {
                name: "a.instructions.md",
                path: ".apm/instructions/a.instructions.md",
                type: "file",
                size: 10,
              },
            ];
          }
          if (repo === "second") {
            await delay(80);
          }
          if (repo === "second" && path === ".apm/skills") {
            return [{ name: "s", path: ".apm/skills/s", type: "dir", size: 0 }];
          }
          if (repo === "second" && path === ".apm/skills/s") {
            return [{ name: "SKILL.md", path: ".apm/skills/s/SKILL.md", type: "file", size: 10 }];
          }
          return [];
        },
      );
      mockClientInstance.getFileContent.mockResolvedValue("content");

      // Both the pre-fix and the hardened code reject the symlinked target, so
      // the throw and its wording are NOT the distinguishing signal here — the
      // barrier is. We assert only that it rejects; the real signal is below:
      // the first dependency's file must be absent (the pre-fix code writes it
      // before reaching the second dependency's symlink; the hardened code
      // checks all targets first).
      await expect(
        installApm({ projectRoot, logger, options: { frozen: true } }),
      ).rejects.toThrow();

      // The symlinked skills directory was never written through, and the first
      // dependency's instruction file was never written to disk.
      expect(await readdir(outsideDir)).toEqual([]);
      expect(await fileExists(join(projectRoot, ".github/instructions/a.instructions.md"))).toBe(
        false,
      );
    },
  );
});
