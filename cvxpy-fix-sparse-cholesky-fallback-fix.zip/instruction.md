## Task

Users working with semidefinite programs have found that cvxpy's symmetric-matrix factorization routine does not reliably handle low-rank inputs. Well-conditioned, full-rank matrices continue to factor normally, but rank-deficient positive- and negative-semidefinite matrices expose the problem.

For example, the valid PSD matrix `[[1, 1, 0], [1, 1, 0], [0, 0, 1]]` can produce "Cholesky factorization failed". Other low-rank inputs may return a factor without an error even though it does not reconstruct the matrix.

Investigate and repair the routine so that it produces a factorization that reconstructs low-rank PSD and NSD inputs. Continue to reject genuinely indefinite matrices.
