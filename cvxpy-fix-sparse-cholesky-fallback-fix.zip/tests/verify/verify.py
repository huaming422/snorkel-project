"""Behavioral verifier for cvxpy-fix-sparse-cholesky-fallback.

The symmetric sparse factorization helper ``sparse_cholesky(A, sym_tol)``
returns ``(sign, L, p)`` such that ``L[p, :] @ L[p, :].T == sign * A`` within
numerical precision, with ``L`` an ``n``-by-``rank(A)`` factor and
``sign in {+1.0, -1.0}``. On rank-deficient positive- and negative-semidefinite
inputs it previously misbehaved two ways: it raised
"Cholesky factorization failed." on inputs with a singular leading minor, and
for other low-rank inputs it returned a numerically-wrong factor (entries
blown up to ~1e13) without raising. A correct fix returns a factor that
reconstructs ``sign * A`` for both classes while still rejecting genuinely
indefinite inputs and preserving every input class that already worked.

These tests couple ONLY to the pre-existing, stable public surface
``cvxpy.utilities.linalg.sparse_cholesky`` (plus
``cvxpy.atoms.quad_form.decomp_quad`` / ``quad_form`` for the downstream
consumer regression). They assert the ``(sign, L, p)`` contract through gram
reconstruction + shape + factor magnitude, never the factorization METHOD, so
any correct fix passes regardless of how the fallback is structured or named
(shared helper, inline dense factorization, or an eigen-decomposition path
whose factor is not lower-triangular). Triangularity is deliberately NOT
asserted on the recovered inputs, since a valid dense fallback factor need not
be triangular.
"""

from __future__ import annotations

import numpy as np
import pytest
import scipy.sparse as sp

from cvxpy.atoms.quad_form import decomp_quad
from cvxpy.utilities import linalg as lau

# --- reconstruction / magnitude tolerances (stable numerical facts) ----------
# Measured post-fix gram residual on the battery is 0.0..1e-15; the pre-fix
# silent-wrong factor carries entries ~1e13. A generous residual bound and a
# wide magnitude bound separate a correct factor from garbage without coupling
# to any method-specific scale.
GRAM_ATOL = 1e-6
MAXL_BOUND = 1e6


def _csc(A):
    return sp.csc_array(np.asarray(A, dtype=float))


def _gram_residual(A_dense, sign, L, p):
    """Frobenius norm of ``sign * A - L[p, :] @ L[p, :].T`` (dense)."""
    Lp = L[p, :]
    G = (Lp @ Lp.T)
    if sp.issparse(G):
        G = G.toarray()
    return float(np.linalg.norm(G - sign * A_dense))


def _max_abs_L(L):
    if L.shape[1] == 0:
        return 0.0
    data = L.toarray() if sp.issparse(L) else np.asarray(L)
    return float(np.abs(data).max())


def _assert_contract(A_dense, sign, L, p, expected_sign, expected_rank):
    """Assert the ``(sign, L, p)`` contract through reconstruction + shape +
    magnitude. Implementation-agnostic: no triangularity or method assumption."""
    n = A_dense.shape[0]
    assert sign == pytest.approx(expected_sign), (
        f"expected sign {expected_sign}, got {sign}"
    )
    assert L.shape[0] == n, f"factor must have {n} rows, got {L.shape[0]}"
    assert L.shape[1] == expected_rank, (
        f"factor must have rank {expected_rank} columns, got {L.shape[1]}"
    )
    maxl = _max_abs_L(L)
    assert maxl < MAXL_BOUND, (
        f"factor entries blew up (max|L|={maxl:.2e}); a correct factor stays "
        f"bounded, a silent-wrong one does not"
    )
    resid = _gram_residual(A_dense, sign, L, p)
    assert resid < GRAM_ATOL, (
        f"L[p,:] @ L[p,:].T must reconstruct sign*A; residual {resid:.2e}"
    )


# --- deterministic rank-deficient PSD battery (singular leading minor) --------
# Each matrix is mathematically PSD and rank-deficient; each makes the
# underlying quasi-definite solver refuse to factor pre-fix. (name, matrix,
# expected_rank). Verified pre-fix: every one raises
# ValueError("Cholesky factorization failed...").
_PSD_SINGULAR_MINOR = [
    ("minor_3x3", [[1.0, 1.0, 0.0], [1.0, 1.0, 0.0], [0.0, 0.0, 1.0]], 2),
    ("ones_3x3", np.ones((3, 3)), 1),
    ("rank1_2x2", [[1.0, 1.0], [1.0, 1.0]], 1),
    ("block_ones_4x4",
     [[1.0, 1.0, 0.0, 0.0],
      [1.0, 1.0, 0.0, 0.0],
      [0.0, 0.0, 1.0, 1.0],
      [0.0, 0.0, 1.0, 1.0]], 2),
    ("outer_uz_5x5",
     (np.outer([1.0, 1.0, 1.0, 0.0, 0.0], [1.0, 1.0, 1.0, 0.0, 0.0])
      + np.outer([0.0, 0.0, 1.0, 1.0, 1.0], [0.0, 0.0, 1.0, 1.0, 1.0])), 2),
]


@pytest.mark.parametrize("name,matrix,rank", _PSD_SINGULAR_MINOR,
                         ids=[c[0] for c in _PSD_SINGULAR_MINOR])
def test_ftp_throw_mode_psd(name, matrix, rank):
    """fail_to_pass: rank-deficient PSD inputs with a singular leading minor
    are factored (sign=+1, reconstructing A) instead of raising
    "Cholesky factorization failed." Pre-fix every case raises; a correct
    fallback returns a factor that reconstructs A."""
    A = np.asarray(matrix, dtype=float)
    sign, L, p = lau.sparse_cholesky(_csc(A), 0.0)
    _assert_contract(A, sign, L, p, expected_sign=1.0, expected_rank=rank)


@pytest.mark.parametrize("name,matrix,rank", _PSD_SINGULAR_MINOR,
                         ids=[c[0] for c in _PSD_SINGULAR_MINOR])
def test_ftp_throw_mode_nsd(name, matrix, rank):
    """fail_to_pass: the negation of each singular-minor PSD input is
    rank-deficient NSD; it must factor with sign=-1 and reconstruct -A
    (i.e. ``L[p,:] @ L[p,:].T == sign * A`` with sign=-1). Pre-fix each
    raises "Cholesky factorization failed."."""
    A = -np.asarray(matrix, dtype=float)
    sign, L, p = lau.sparse_cholesky(_csc(A), 0.0)
    _assert_contract(A, sign, L, p, expected_sign=-1.0, expected_rank=rank)


def test_ftp_numeric_correctness():
    """fail_to_pass: across the full rank-deficient PSD/NSD battery the
    returned factorization is numerically correct — the gram residual is tiny
    AND the factor entries are bounded (not ~1e13). This catches the
    silent-wrong failure mode where the solver returns without raising but the
    factor does not reconstruct the input."""
    failures = []
    for name, matrix, rank in _PSD_SINGULAR_MINOR:
        for sgn_name, A in (("psd", np.asarray(matrix, dtype=float)),
                            ("nsd", -np.asarray(matrix, dtype=float))):
            expected_sign = 1.0 if sgn_name == "psd" else -1.0
            try:
                sign, L, p = lau.sparse_cholesky(_csc(A), 0.0)
            except Exception as e:  # noqa: BLE001 - report, do not swallow
                failures.append(f"{name}/{sgn_name}: raised {type(e).__name__}")
                continue
            if sign != pytest.approx(expected_sign):
                failures.append(f"{name}/{sgn_name}: sign {sign} != {expected_sign}")
            maxl = _max_abs_L(L)
            if not (maxl < MAXL_BOUND):
                failures.append(f"{name}/{sgn_name}: max|L|={maxl:.2e} unbounded")
            resid = _gram_residual(A, sign, L, p)
            if not (resid < GRAM_ATOL):
                failures.append(f"{name}/{sgn_name}: gram residual {resid:.2e}")
    assert not failures, "numerically-wrong factorizations: " + "; ".join(failures)


# --- deterministic silent-wrong (mode-2) anchor -------------------------------
# A rank-3 integer PSD matrix on which the underlying QDLDL solver SUCCEEDS
# (raises nothing) but returns a near-zero pivot paired with large L entries, so
# the pre-fix "|D|-only" column mask drops a non-negligible contribution and the
# returned factor fails to reconstruct the input by O(1) (gram residual ~3.2,
# factor entries bounded — the silent-wrong mode, distinct from the throw mode).
# Verified on the pinned qdldl 0.1.9.post1 build: pre-fix, and under any fix that
# only catches the QDLDL throw while leaving the mask path unrepaired, this
# returns a wrong factor; a correct fix (residual-guarded dense fallback or an
# eigen path) reconstructs it. Eigenvalues are {0, 0, 0.50, 6.60, 13.90}, so the
# rank is unambiguously 3.
_SILENT_WRONG_RANK3 = np.array(
    [[1.0, 0.0, 2.0, 0.0, 0.0],
     [0.0, 5.0, -2.0, 3.0, -5.0],
     [2.0, -2.0, 8.0, -2.0, 2.0],
     [0.0, 3.0, -2.0, 2.0, -3.0],
     [0.0, -5.0, 2.0, -3.0, 5.0]],
    dtype=float,
)


def test_ftp_silent_wrong_mode_psd():
    """fail_to_pass: a rank-deficient PSD input on which QDLDL does NOT raise but
    returns a tiny pivot + large L entries must still be factored correctly
    (sign=+1, rank-3 factor reconstructing A). Pre-fix — and under a fix that
    only handles the throw mode — the masked factor misses an O(1) contribution
    and the gram residual is ~3.2; a correct fix reconstructs A."""
    A = _SILENT_WRONG_RANK3
    sign, L, p = lau.sparse_cholesky(_csc(A), 0.0)
    _assert_contract(A, sign, L, p, expected_sign=1.0, expected_rank=3)


def test_ftp_silent_wrong_mode_nsd():
    """fail_to_pass: the NSD negation of the silent-wrong input must factor with
    sign=-1 and reconstruct -A. Same silent-wrong mode as the PSD case, mirrored
    through the negative-definite branch."""
    A = -_SILENT_WRONG_RANK3
    sign, L, p = lau.sparse_cholesky(_csc(A), 0.0)
    _assert_contract(A, sign, L, p, expected_sign=-1.0, expected_rank=3)


# --- pass_to_pass: genuinely indefinite inputs stay rejected ------------------
def test_ptp_nonsingular_indefinite_rejected():
    """pass_to_pass: a nonsingular indefinite matrix must raise ValueError
    (INDEFINITE). The fallback must not launder indefinite into PSD/NSD."""
    A = _csc([[1.0, 2.0], [2.0, 1.0]])  # eigenvalues 3, -1
    with pytest.raises(ValueError):
        lau.sparse_cholesky(A, 0.0)


def test_ptp_indefinite_zero_diagonal_rejected():
    """pass_to_pass: an indefinite matrix with a non-negative (zero-containing)
    diagonal must still be rejected with ValueError (INDEFINITE)."""
    A = _csc([[1.0, 2.0], [2.0, 0.0]])  # indefinite, diag has a zero
    with pytest.raises(ValueError):
        lau.sparse_cholesky(A, 0.0)


# --- pass_to_pass: previously-working input classes still factor --------------
def test_ptp_full_rank_pd():
    """pass_to_pass: full-rank PD matrices factor and reconstruct."""
    rng = np.random.RandomState(0)
    B = rng.randn(3, 3)
    A = B @ B.T
    sign, L, p = lau.sparse_cholesky(_csc(A))
    _assert_contract(A, sign, L, p, expected_sign=1.0, expected_rank=3)


def test_ptp_diagonal():
    """pass_to_pass: a positive diagonal matrix factors and reconstructs."""
    A = np.diag([0.7, 0.2, 0.9, 0.4])
    sign, L, p = lau.sparse_cholesky(_csc(A), 0.0)
    _assert_contract(A, sign, L, p, expected_sign=1.0, expected_rank=4)


def test_ptp_tridiagonal():
    """pass_to_pass: a diagonally-dominant tridiagonal PD matrix reconstructs."""
    n = 5
    diag = np.array([1.1, 1.2, 1.3, 1.4, 1.5])
    off = (np.min(np.abs(diag)) / 2.0) * np.ones(n - 1)
    A = sp.diags_array([off, diag, off], offsets=[-1, 0, 1]).toarray()
    sign, L, p = lau.sparse_cholesky(_csc(A), 0.0)
    _assert_contract(A, sign, L, p, expected_sign=1.0, expected_rank=5)


def test_ptp_rank_deficient_already_handled():
    """pass_to_pass: a rank-deficient PSD input the solver could already handle
    (4x2 outer product) still factors to an n-by-rank factor that reconstructs."""
    rng = np.random.RandomState(0)
    B = rng.randn(4, 2)
    A = B @ B.T
    sign, L, p = lau.sparse_cholesky(_csc(A))
    _assert_contract(A, sign, L, p, expected_sign=1.0, expected_rank=2)


def test_ptp_nsd_rank_deficient_already_handled():
    """pass_to_pass: a rank-deficient NSD input factors with sign=-1 and
    reconstructs -A (``sign * A``)."""
    rng = np.random.RandomState(0)
    B = rng.randn(4, 2)
    A = -(B @ B.T)
    sign, L, p = lau.sparse_cholesky(_csc(A))
    _assert_contract(A, sign, L, p, expected_sign=-1.0, expected_rank=2)


def test_ptp_diagonal_with_zeros():
    """pass_to_pass: a PSD diagonal matrix with zero entries factors to an
    n-by-(nonzero-count) factor that reconstructs."""
    A = np.diag([3.0, 0.0, 5.0, 0.0])
    sign, L, p = lau.sparse_cholesky(_csc(A), 0.0)
    _assert_contract(A, sign, L, p, expected_sign=1.0, expected_rank=2)


def test_ptp_zero_matrix():
    """pass_to_pass: the all-zero matrix is rank 0 — factor has zero columns
    and reconstructs the zero matrix."""
    A = np.zeros((4, 4))
    sign, L, p = lau.sparse_cholesky(_csc(A), 0.0)
    assert L.shape == (4, 0), (
        f"zero matrix is rank 0; factor must have zero columns, got shape {L.shape}"
    )
    assert _gram_residual(A, sign, L, p) < GRAM_ATOL, (
        "factor of the zero matrix must reconstruct the zero matrix"
    )


def test_ptp_nontrivial_permutation():
    """pass_to_pass: a matrix whose factorization needs a non-trivial fill
    permutation reconstructs correctly through the permuted factor."""
    n = 6
    B = sp.random(n, n, density=0.4, format="csr", random_state=123)
    A = (B @ B.T + n * sp.eye(n)).toarray()
    sign, L, p = lau.sparse_cholesky(_csc(A))
    _assert_contract(A, sign, L, p, expected_sign=1.0, expected_rank=n)


# --- pass_to_pass: downstream consumer (decomp_quad / quad_form) --------------
def test_ptp_decomp_quad_consumer_reconstructs():
    """pass_to_pass: ``decomp_quad`` over a rank-deficient dense PSD matrix
    returns ``(scale, M1, M2)`` with
    ``scale * (M1 @ M1.T - M2 @ M2.T) == P``. Confirms the consumer path stays
    correct through any refactor of the shared factorization logic."""
    rng = np.random.RandomState(0)
    B = rng.randn(4, 2)
    P = B @ B.T
    scale, M1, M2 = decomp_quad(P)
    recon = scale * (M1 @ M1.T - M2 @ M2.T)
    assert np.linalg.norm(recon - P) < 1e-6, "decomp_quad must reconstruct P"


def test_ptp_quad_form_solves_to_optimal():
    """pass_to_pass: a small quadratic program built with ``quad_form`` over a
    PD matrix solves to optimal. Confirms the end-to-end consumer stays intact."""
    import cvxpy as cp

    rng = np.random.RandomState(2)
    D = rng.randn(3, 3)
    P = D @ D.T + 0.1 * np.eye(3)
    x = cp.Variable(3)
    prob = cp.Problem(cp.Minimize(cp.quad_form(x, P)),
                      [cp.sum(x) == 1, x >= 0])
    prob.solve()
    assert prob.status == "optimal", f"expected optimal, got {prob.status}"
    assert prob.value is not None and np.isfinite(prob.value)
