## Task

been hitting some weird selection bugs in the editor. if you highlight the same run of text two ways that should land in the exact same place, like dragging out to the start of the next block versus dropping right after the last character, you can end up copying different text. and sometimes copying or pulling a selection out drops the highlighted characters completely, like nothing was selected at all.

styling misbehaves in the same spots. applying a color or toggling bold/italic on one of these selections will hit the wrong run, do nothing, or leave the highlight sitting on some neighbouring chunk afterward. and when we style a specific selection from code instead of the one the user has active, it styles whatever the user currently has highlighted rather than the one we handed it.

these look like separate glitches across copying, extracting, formatting, and styling, but they feel like one underlying thing rather than four. dig in and get selection text, extraction, formatting, and styling all agreeing with each other at these boundaries.
