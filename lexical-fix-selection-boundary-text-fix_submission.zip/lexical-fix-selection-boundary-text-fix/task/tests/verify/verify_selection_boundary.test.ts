/**
 * Behavioral verifier for the selection boundary-equivalence family.
 *
 * Every test exercises ONLY pre-existing, stable public API of the `lexical`
 * and `@lexical/selection` packages:
 *   - RangeSelection.getTextContent() / .extract() / .formatText() / .getNodes()
 *   - $patchStyleText(selection, patch)
 *   - $sliceSelectedTextNodeContent(selection, node, mutates)
 * A RangeSelection is built directly by creating nodes and setting its anchor
 * and focus Points (text point: (key, offset, 'text'); element point:
 * (parentKey, childIndex, 'element')). No internal helper, no newly-added
 * export, and no implementation file is imported or named — a correct fix may
 * share one slice helper, inline the logic per call site, or add/skip any
 * export, and every one of those must satisfy these assertions.
 *
 * Runner: vitest (jsdom), single file, via ssb_lib/runners/js.py. The whole
 * file passes only if every test passes.
 */
import {$createLinkNode, LinkNode} from '@lexical/link';
import {$patchStyleText, $sliceSelectedTextNodeContent} from '@lexical/selection';
import {buildEditorFromExtensions} from '@lexical/extension';
import {
  $createParagraphNode,
  $createRangeSelection,
  $createTextNode,
  $getRoot,
  $getSelection,
  $isTextNode,
  $setSelection,
  $setSlot,
  IS_BOLD,
  IS_ITALIC,
  type LexicalNode,
  type TextNode,
} from 'lexical';
import {expect, test} from 'vitest';

function textChildren(node: LexicalNode): TextNode[] {
  if (!('getChildren' in node)) {
    return [];
  }
  // @ts-expect-error — node is an ElementNode in every call site below.
  return node.getChildren().filter($isTextNode) as TextNode[];
}

// ---------------------------------------------------------------------------
// getTextContent()
// ---------------------------------------------------------------------------

test('gettextcontent_boundary_equiv', () => {
  using editor = buildEditorFromExtensions({name: 'v-gettextcontent'});
  for (const backward of [false, true]) {
    editor.update(
      () => {
        const first = $createTextNode('abcd');
        const second = $createTextNode('efgh').setFormat('italic');
        const paragraph = $createParagraphNode().append(
          first,
          second,
          $createTextNode('ijkl').setFormat('bold'),
        );
        $getRoot().clear().append(paragraph);
        const selection = $createRangeSelection();
        const [start, end] = backward
          ? [selection.focus, selection.anchor]
          : [selection.anchor, selection.focus];
        start.set(first.getKey(), 1, 'text');
        // Text point at the end of `second`.
        end.set(second.getKey(), 4, 'text');
        expect(selection.getTextContent()).toBe('bcdefgh');
        // The equivalent ELEMENT point (child index after `second`) must agree.
        end.set(paragraph.getKey(), 2, 'element');
        expect(selection.getTextContent()).toBe('bcdefgh');
        // Sanity: nothing was mutated in the document.
        expect(paragraph.getTextContent()).toBe('abcdefghijkl');
      },
      {discrete: true},
    );
  }
});

test('empty_mixed_range_empty', () => {
  using editor = buildEditorFromExtensions({name: 'v-emptymixed'});
  for (const backward of [false, true]) {
    editor.update(
      () => {
        const first = $createTextNode('abcd');
        const paragraph = $createParagraphNode().append(
          first,
          $createTextNode('efgh').setFormat('italic'),
        );
        $getRoot().clear().append(paragraph);
        const selection = $createRangeSelection();
        const [start, end] = backward
          ? [selection.focus, selection.anchor]
          : [selection.anchor, selection.focus];
        // Text point at end of `first` == element point just after `first`.
        start.set(first.getKey(), 4, 'text');
        end.set(paragraph.getKey(), 1, 'element');
        expect(selection.getTextContent()).toBe('');
        expect(paragraph.getTextContent()).toBe('abcdefgh');
      },
      {discrete: true},
    );
  }
});

test('collapsed_returns_empty', () => {
  using editor = buildEditorFromExtensions({name: 'v-collapsed'});
  for (const offset of [0, 1]) {
    editor.update(
      () => {
        const root = $getRoot();
        const host = $createParagraphNode();
        root.clear().append(host);
        $setSlot(
          host,
          'title',
          $createParagraphNode().append($createTextNode('Title')),
        );
        const selection = $createRangeSelection();
        selection.anchor.set(root.getKey(), offset, 'element');
        selection.focus.set(root.getKey(), offset, 'element');
        // The slot-bearing host still appears in the collapsed selection's
        // nodes and keeps its own text, but the collapsed range itself is empty.
        expect(selection.getNodes()).toEqual([host]);
        expect(selection.getTextContent()).toBe('');
        expect(host.getTextContent()).toBe('Title');
      },
      {discrete: true},
    );
  }
});

// ---------------------------------------------------------------------------
// extract()
// ---------------------------------------------------------------------------

test('extract_isolates_fragment', () => {
  using editor = buildEditorFromExtensions({name: 'v-extract'});

  // (a) Single partially-selected TextNode: extract returns the isolated
  //     fragment and repins the selection onto it (forward and backward).
  for (const backward of [false, true]) {
    editor.update(
      () => {
        const text = $createTextNode('abcde');
        const paragraph = $createParagraphNode().append(text);
        $getRoot().clear().append(paragraph);
        const selection = $createRangeSelection();
        const [start, end] = backward
          ? [selection.focus, selection.anchor]
          : [selection.anchor, selection.focus];
        start.set(text.getKey(), 1, 'text');
        end.set(text.getKey(), 4, 'text');
        const extracted = extractTextContents(selection);
        expect(extracted).toEqual(['bcd']);
        // Points now sit on the isolated fragment.
        expect(selection.getTextContent()).toBe('bcd');
        expect(selection.anchor.type).toBe('text');
        expect(selection.focus.type).toBe('text');
        expect(selection.anchor.key).toBe(selection.focus.key);
      },
      {discrete: true},
    );
  }

  // (b) Range whose focus is an ELEMENT point between children: extract splits
  //     and isolates the selected fragments across both TextNodes.
  for (const backward of [false, true]) {
    editor.update(
      () => {
        const first = $createTextNode('abcd');
        const second = $createTextNode('efgh').setFormat('italic');
        const third = $createTextNode('ijkl').setFormat('bold');
        const paragraph = $createParagraphNode().append(first, second, third);
        $getRoot().clear().append(paragraph);
        const selection = $createRangeSelection();
        const [start, end] = backward
          ? [selection.focus, selection.anchor]
          : [selection.anchor, selection.focus];
        start.set(first.getKey(), 1, 'text');
        end.set(paragraph.getKey(), 2, 'element');
        expect(extractTextContents(selection)).toEqual(['bcd', 'efgh']);
        // The remaining document is intact.
        expect(paragraph.getTextContent()).toBe('abcdefghijkl');
        expect(selection.isBackward()).toBe(backward);
      },
      {discrete: true},
    );
  }

  // (c) Empty mixed-point range extracts nothing and leaves the tree untouched.
  editor.update(
    () => {
      const text = $createTextNode('abcd');
      const following = $createTextNode('efgh').setFormat('italic');
      const paragraph = $createParagraphNode().append(text, following);
      $getRoot().clear().append(paragraph);
      const selection = $createRangeSelection();
      selection.anchor.set(paragraph.getKey(), 1, 'element');
      selection.focus.set(text.getKey(), 4, 'text');
      expect(selection.extract()).toEqual([]);
      expect(paragraph.getChildren()).toEqual([text, following]);
      expect(text.getTextContent()).toBe('abcd');
    },
    {discrete: true},
  );

  function extractTextContents(selection: ReturnType<typeof $createRangeSelection>): string[] {
    return selection
      .extract()
      .filter($isTextNode)
      .map((node) => node.getTextContent());
  }
});

// ---------------------------------------------------------------------------
// formatText()
// ---------------------------------------------------------------------------

test('formattext_partial_fragment', () => {
  using editor = buildEditorFromExtensions({name: 'v-formattext'});
  for (const operationBackward of [false, true]) {
    editor.update(
      () => {
        const first = $createTextNode('abc');
        const second = $createTextNode('def').setFormat('italic');
        const paragraph = $createParagraphNode().append(first, second);
        const other = $createTextNode('other');
        $getRoot()
          .clear()
          .append(paragraph, $createParagraphNode().append(other));
        // An unrelated, non-active selection: formatting a different selection
        // must not disturb it.
        const active = other.select(2, 2);
        const selection = $createRangeSelection();
        const [start, end] = operationBackward
          ? [selection.focus, selection.anchor]
          : [selection.anchor, selection.focus];
        // Spans part of `first` through an element point past `second`.
        start.set(first.getKey(), 1, 'text');
        end.set(paragraph.getKey(), 2, 'element');

        selection.formatText('bold');

        // Exactly the selected fragment ('bcdef') is bold; the unselected
        // prefix 'a' is untouched.
        const bolded = textChildren(paragraph)
          .filter((node) => (node.getFormat() & IS_BOLD) !== 0)
          .map((node) => node.getTextContent())
          .join('');
        expect(bolded).toBe('bcdef');
        const unbolded = textChildren(paragraph)
          .filter((node) => (node.getFormat() & IS_BOLD) === 0)
          .map((node) => node.getTextContent())
          .join('');
        expect(unbolded).toBe('a');
        // The highlight still covers the formatted fragment.
        expect(selection.getTextContent()).toBe('bcdef');
        // The unrelated active selection is unchanged.
        expect($getSelection()).toBe(active);
        expect(active.anchor.key).toBe(other.getKey());
        expect(active.anchor.offset).toBe(2);
      },
      {discrete: true},
    );
  }
});

// ---------------------------------------------------------------------------
// $patchStyleText()
// ---------------------------------------------------------------------------

test('patchstyle_supplied_selection', () => {
  using editor = buildEditorFromExtensions({name: 'v-patchstyle-supplied'});
  editor.update(
    () => {
      const text = $createTextNode('abcdef');
      const paragraph = $createParagraphNode().append(text);
      const other = $createTextNode('xyz');
      $getRoot().clear().append(paragraph, $createParagraphNode().append(other));
      // A DIFFERENT selection is active (a range over `other`).
      const activeSelection = other.select(0, 2);
      $setSelection(activeSelection);

      // The supplied, detached selection covers 'cd' inside `text`.
      const selection = $createRangeSelection();
      selection.anchor.set(text.getKey(), 2, 'text');
      selection.focus.set(text.getKey(), 4, 'text');

      $patchStyleText(selection, {color: 'red'});

      // Only the supplied selection's fragment got styled.
      const styled = textChildren(paragraph).find(
        (node) => node.getStyle() !== '',
      );
      expect(styled?.getTextContent()).toBe('cd');
      expect(styled?.getStyle()).toBe('color: red;');
      expect(selection.getTextContent()).toBe('cd');
      // The active selection and its node are untouched: `other` was never
      // styled, and the active range still selects exactly 'xy' over `other`.
      // (Asserting the active range's VALUE rather than object identity so any
      // valid mechanism — a private supplied-selection iterator, or making the
      // supplied selection active and restoring the previous one — is admitted;
      // the bug under test would style `other`/leave 'cd' unstyled regardless.)
      expect(other.getStyle()).toBe('');
      const active = $getSelection();
      expect(active?.getTextContent()).toBe('xy');
      expect(active?.getNodes()).toEqual([other]);
    },
    {discrete: true},
  );
});

test('patchstyle_endpoints_survive', () => {
  using editor = buildEditorFromExtensions({name: 'v-patchstyle-repeat'});
  editor.update(
    () => {
      const text = $createTextNode('abcdef');
      const paragraph = $createParagraphNode().append(text);
      const other = $createTextNode('xyz');
      $getRoot().clear().append(paragraph, $createParagraphNode().append(other));
      // No active selection at all.
      $setSelection(null);

      const selection = $createRangeSelection();
      selection.anchor.set(text.getKey(), 2, 'text');
      selection.focus.set(text.getKey(), 4, 'text');

      $patchStyleText(selection, {color: 'red'});
      const styled = textChildren(paragraph).find(
        (node) => node.getStyle().includes('color: red'),
      );
      expect(styled?.getTextContent()).toBe('cd');
      // After the first call the endpoints resolve exactly to the styled run.
      expect(selection.getNodes()).toEqual([styled]);
      expect(selection.getTextContent()).toBe('cd');

      // A second call keeps valid endpoints and accumulates the style.
      $patchStyleText(selection, {'font-size': '20px'});
      expect(styled?.getStyle()).toBe('color: red;font-size: 20px;');
      expect(selection.getTextContent()).toBe('cd');
      expect(paragraph.getTextContent()).toBe('abcdef');
      // No active selection was fabricated as a side effect.
      expect($getSelection()).toBe(null);
    },
    {discrete: true},
  );
});

// ---------------------------------------------------------------------------
// $sliceSelectedTextNodeContent()
// ---------------------------------------------------------------------------

test('slice_element_endpoints', () => {
  using editor = buildEditorFromExtensions({
    name: 'v-slice',
    nodes: [LinkNode],
  });

  // (a) Equivalent mixed text/element endpoints produce an empty slice.
  for (const offset of [0, 2]) {
    for (const outer of [false, true]) {
      editor.update(
        () => {
          const text = $createTextNode('jh');
          const link = $createLinkNode('https://example.com').append(text);
          const paragraph = $createParagraphNode().append(link);
          $getRoot().clear().append(paragraph);
          const selection = $createRangeSelection();
          selection.anchor.set(text.getKey(), offset, 'text');
          selection.focus.set(
            (outer ? paragraph : link).getKey(),
            offset === 0 ? 0 : 1,
            'element',
          );
          const slice = $sliceSelectedTextNodeContent(selection, text, 'self');
          expect(slice).toBe(text);
          expect(slice.getTextContent()).toBe('');
        },
        {discrete: true},
      );
    }
  }

  // (b) Text-only fast path still returns the correct substring.
  editor.update(
    () => {
      const text = $createTextNode('hello');
      const paragraph = $createParagraphNode().append(text);
      $getRoot().clear().append(paragraph);
      const selection = $createRangeSelection();
      selection.anchor.set(text.getKey(), 1, 'text');
      selection.focus.set(text.getKey(), 3, 'text');
      const slice = $sliceSelectedTextNodeContent(selection, text, 'self');
      expect(slice.getTextContent()).toBe('el');
    },
    {discrete: true},
  );
});

// ---------------------------------------------------------------------------
// Regression guard (pass_to_pass): baseline selection/caret behaviors that are
// correct both before and after the fix must keep working. The vitest runner
// only executes this single file, so the regression coverage is encoded here as
// explicit assertions rather than by invoking the repo's existing suites.
// ---------------------------------------------------------------------------

test('no_regression_selection_caret', () => {
  using editor = buildEditorFromExtensions({name: 'v-regression'});
  editor.update(
    () => {
      const a = $createTextNode('Hello');
      const b = $createTextNode(' World').setFormat('italic');
      const paragraph = $createParagraphNode().append(a, b);
      $getRoot().clear().append(paragraph);

      // Full multi-node selection returns the complete text and both nodes.
      const full = $createRangeSelection();
      full.anchor.set(a.getKey(), 0, 'text');
      full.focus.set(b.getKey(), b.getTextContentSize(), 'text');
      expect(full.getTextContent()).toBe('Hello World');
      expect(full.getNodes().filter($isTextNode).map((n) => n.getTextContent())).toEqual([
        'Hello',
        ' World',
      ]);

      // A collapsed text selection is empty (pre-existing fast path).
      const collapsed = $createRangeSelection();
      collapsed.anchor.set(a.getKey(), 2, 'text');
      collapsed.focus.set(a.getKey(), 2, 'text');
      expect(collapsed.getTextContent()).toBe('');

      // Extracting a whole-node multi-node selection returns the nodes as-is.
      const extractSel = $createRangeSelection();
      extractSel.anchor.set(a.getKey(), 0, 'text');
      extractSel.focus.set(b.getKey(), b.getTextContentSize(), 'text');
      expect(
        extractSel.extract().filter($isTextNode).map((n) => n.getTextContent()),
      ).toEqual(['Hello', ' World']);

      // The pre-existing italic format on `b` survived untouched.
      expect((b.getFormat() & IS_ITALIC) !== 0).toBe(true);
    },
    {discrete: true},
  );
});
