#!/usr/bin/env bash
#
# Behavioral verifier (fail_to_pass): a program-interface description whose
# defined names coincide with framework-provided items must generate code that
# COMPILES when consumed through the program-interface macro.
#
# This builds an INDEPENDENT fixture, authored here, not drawn from the task
# repo: a hand-written foreign interface description that forces a coincidence
# on every vocabulary the macro re-exports into the generated scope, so a
# submission that special-cases a single vocabulary still fails to compile:
#   - a `types` enum named `Space` (coincides with a framework-provided
#     `Space`), referenced from an instruction argument so the generated
#     bindings mention it in type position;
#   - an `accounts` entry named `Key` (coincides with a framework-provided
#     `Key`), so the generated account parser mentions it in type position;
#   - an `events` entry named `Owner` (coincides with a framework-provided
#     `Owner`), so the generated event parser mentions it in type position.
# A throwaway consumer crate feeds that description to the macro and is
# compiled.
#
# The coinciding names used here are deliberately different from any name the
# task repo already exercises, so this check is independent of whichever
# specific name a submission might have touched: a submission that merely
# renames one offending description, or special-cases a single name or a single
# vocabulary (e.g. separating only `types` while leaving `accounts`/`events`
# sharing a resolution scope with the prelude), still fails this check. Only a
# submission that keeps the described and framework vocabularies from sharing a
# resolution scope IN GENERAL makes it compile.
#
# Pre-fix: the generated code fails to compile (a bare reference resolves
# ambiguously between the framework item and the described item). Post-fix: it
# compiles. The build exit code IS the signal; this script never reads
# generated symbol names, so it accepts any fix shape.

set -euo pipefail

WS=/repo/anchor/tests/declare-program
IDL_NAME=collision_probe_space
CRATE=collision_probe_space_verify
CRATE_DIR="${WS}/programs/${CRATE}"
IDL_FILE="${WS}/idls/${IDL_NAME}.json"

cleanup() {
    rm -rf "${CRATE_DIR}" "${IDL_FILE}"
}
trap cleanup EXIT

mkdir -p "${CRATE_DIR}/src"

# Foreign interface description with defined names that coincide with
# framework-provided items on every re-exported vocabulary: a `types` enum
# (`Space`, referenced from an instruction argument), an `accounts` entry
# (`Key`), and an `events` entry (`Owner`). Each coinciding name forces the
# generated code to mention that name in type position in a different codegen
# path, so separating only one vocabulary still leaves the others ambiguous.
cat > "${IDL_FILE}" <<'JSON'
{
  "address": "11111111111111111111111111111111",
  "metadata": {
    "name": "collision_probe_space",
    "version": "0.1.0",
    "spec": "0.1.0",
    "description": "Hand-authored fixture: a foreign interface whose defined type, account, and event names each coincide with a framework-provided item. No source program in this repo."
  },
  "instructions": [
    {
      "name": "probe",
      "discriminator": [0, 0, 0, 0, 0, 0, 0, 0],
      "accounts": [],
      "args": [
        {
          "name": "value",
          "type": {
            "defined": {
              "name": "Space"
            }
          }
        }
      ]
    }
  ],
  "accounts": [
    {
      "name": "Key",
      "discriminator": [0, 0, 0, 0, 0, 0, 0, 0]
    }
  ],
  "events": [
    {
      "name": "Owner",
      "discriminator": [0, 0, 0, 0, 0, 0, 0, 0]
    }
  ],
  "types": [
    {
      "name": "Space",
      "type": {
        "kind": "enum",
        "variants": [
          { "name": "Small" },
          { "name": "Large" }
        ]
      }
    },
    {
      "name": "Key",
      "type": {
        "kind": "struct",
        "fields": [
          { "name": "value", "type": "u64" }
        ]
      }
    },
    {
      "name": "Owner",
      "type": {
        "kind": "struct",
        "fields": [
          { "name": "value", "type": "u64" }
        ]
      }
    }
  ]
}
JSON

cat > "${CRATE_DIR}/Cargo.toml" <<'TOML'
[package]
name = "collision_probe_space_verify"
version = "0.0.0"
edition = "2021"
publish = false

[lib]
name = "collision_probe_space_verify"
path = "src/lib.rs"

[dependencies]
anchor-lang = { path = "../../../../lang" }
TOML

cat > "${CRATE_DIR}/src/lib.rs" <<'RUST'
use anchor_lang::prelude::*;

declare_program!(collision_probe_space);
RUST

cd "${WS}"
cargo build -p "${CRATE}"
