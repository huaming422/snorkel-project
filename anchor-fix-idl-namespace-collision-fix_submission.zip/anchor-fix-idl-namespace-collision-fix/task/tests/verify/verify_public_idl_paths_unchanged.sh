#!/usr/bin/env bash
#
# Behavioral verifier (pass_to_pass): types defined by an interface description
# must stay reachable at their public paths for external callers after the fix.
# The fix is supposed to touch only the private imports inside the generated
# module, never the public surface, so code outside the generated module that
# refers to a generated type through its public path must still resolve.
#
# A throwaway consumer crate generates bindings from the repo's existing
# current-format interface description and then, from OUTSIDE the generated
# module, names a generated account type and a generated defined type through
# their public paths. If a submission moved or renamed the public paths while
# separating the vocabularies, this fails to compile. Pre-fix and post-fix a
# correct tree both compile; the build exit code IS the signal.
#
# The public path segments referenced here (`external` as the generated module
# name, `::accounts::` and `::types::` as the public sub-namespaces, and the
# type names `MyAccount` / `GenericStruct`) are the pre-existing public contract
# of the macro and of the checked-in `external` description, not anything a
# submission authors. These two references mirror the repo's OWN working uses of
# the same public paths (`external::accounts::MyAccount` in type position in
# programs/declare-program/src/lib.rs, and `use external::types::GenericStruct;`
# in programs/declare-program/tests/generics.rs). The `types::` probe uses a path
# import rather than a bare type instantiation because `GenericStruct` carries
# two generic parameters, so naming it bare in type position would be an E0107
# arity error unrelated to this fix; a `use` import still proves the public path
# resolves after the vocabularies are separated.

set -euo pipefail

WS=/repo/anchor/tests/declare-program
CRATE=public_paths_verify
CRATE_DIR="${WS}/programs/${CRATE}"

cleanup() {
    rm -rf "${CRATE_DIR}"
}
trap cleanup EXIT

mkdir -p "${CRATE_DIR}/src"

cat > "${CRATE_DIR}/Cargo.toml" <<'TOML'
[package]
name = "public_paths_verify"
version = "0.0.0"
edition = "2021"
publish = false

[lib]
name = "public_paths_verify"
path = "src/lib.rs"

[dependencies]
anchor-lang = { path = "../../../../lang" }
TOML

cat > "${CRATE_DIR}/src/lib.rs" <<'RUST'
use anchor_lang::prelude::*;

// A generated defined type is reachable at its public `types::` path. This
// mirrors the repo's own `use external::types::GenericStruct;` (generics.rs);
// a path import proves the public path resolves without instantiating the
// type's two generic parameters.
use external::types::GenericStruct as _GenericStructPathResolves;

declare_program!(external);

// A generated account type is reachable at its public `accounts::` path, in
// type position, from outside the generated module. This mirrors the repo's own
// `external::accounts::MyAccount` use (src/lib.rs). These must resolve
// regardless of how the generated module privately arranges its imports.
#[allow(dead_code)]
fn _assert_account_path_resolves(_: &external::accounts::MyAccount) {}
RUST

cd "${WS}"
cargo build -p "${CRATE}"
