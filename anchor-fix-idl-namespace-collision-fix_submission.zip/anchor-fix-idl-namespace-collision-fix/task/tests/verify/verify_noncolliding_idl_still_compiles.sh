#!/usr/bin/env bash
#
# Behavioral verifier (pass_to_pass): interface descriptions whose names do NOT
# coincide with framework-provided items must keep generating code that
# compiles, unchanged. This guards against an over-narrow fix that only patches
# one emission site, or that breaks the general binding generation while
# chasing the one failing description.
#
# It builds the repo's own pre-existing consumer crate, which feeds several
# real interface descriptions (a current-format one, a legacy-format one, and a
# large third-party one) through the program-interface macro and also exercises
# cross-program-call bindings. All of these compile both before and after a
# correct fix; a fix that regresses general binding generation fails here.
#
# The build exit code IS the signal.

set -euo pipefail

cd /repo/anchor/tests/declare-program
cargo build -p declare-program
