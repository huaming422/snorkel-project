#!/usr/bin/env bash
# test-setup.sh — sourced by tests/test.sh before the jest verifier, under
# `set -euo pipefail`. Brings the baked frontend dependency tree online so the
# jest verifier can run with the network cut.
#
# The image already ran `npm ci` at build time into the warm npm cache, so the
# offline-first install below is a no-op when the bake is fresh; the online
# fallback only fires if the bake went stale. No services, no seed data — this
# is a pure frontend unit-test task (jest against the generated chart option).

cd /repo/superset/superset-frontend

# Make a cache miss fail fast rather than reaching for the registry on the
# offline-fold pass. npm honours these for `npm ci`.
export npm_config_offline=true
export npm_config_audit=false
export npm_config_fund=false

if npm ci --offline --ignore-scripts > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] frontend deps satisfied from image"
else
    echo "[test-setup] offline npm ci failed; retrying online (image bake may be stale)"
    unset npm_config_offline
    if npm ci --ignore-scripts >> /tmp/test-setup-install.log 2>&1; then
        echo "[test-setup] frontend deps installed online"
    else
        tail -60 /tmp/test-setup-install.log >&2
        exit 1
    fi
fi

echo "[test-setup] done"
