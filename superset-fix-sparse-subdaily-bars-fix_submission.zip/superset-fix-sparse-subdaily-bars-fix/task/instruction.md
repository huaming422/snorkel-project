## Task

Bar charts bucketed on a sub-daily grain (hourly, every 15 minutes) misrender when the query only fills one or a few buckets in the window. The populated bar blows up far too wide: instead of sitting in its own slot it spills across the neighboring empty buckets, and the sparser the data the worse it gets.

In that same sparse case the x-axis sometimes falls back to raw numeric timestamps (big millisecond-looking numbers) instead of time-of-day labels. The data is fine, and hovering a bar shows the correct time in the tooltip; only the axis reads wrong.

Both symptoms hit the standard time-series bar chart and the mixed one. The width problem also shows up in horizontal orientation and when a legend squeezes the chart narrow.

Well-populated daily-or-coarser charts look fine; only the sparse sub-daily case breaks. It all lives in how the frontend builds the chart, not the backend or query layer. The visible time range and the tooltip are already right, so the fix is in the bar sizing and the axis labels. Dig in and fix it.
