## Task

our Microsoft Entra ID sign-in keeps losing returning users. someone signs in with Microsoft today and gets their account, all fine. then an admin changes the org's Microsoft (Azure) app registration, and the next time that same person signs in they no longer match their existing account and get a brand new one. so we end up with orphaned accounts and duplicate users for the same human. this used to work fine before the registration changed.

it happens in both ways you can wire up Microsoft here: the built-in Microsoft provider and the generic Entra setup. both drift the same way, so both need fixing.

the identity a Microsoft login is pinned to should stay put for the same person across app-registration changes, so a returning user keeps landing on their existing account. and if a login can't establish a stable identity at all, it shouldn't quietly spin up or link an account off the back of it.

this is a correctness fix inside the existing sign-in paths, no new options or public surface. dig in and fix it.
