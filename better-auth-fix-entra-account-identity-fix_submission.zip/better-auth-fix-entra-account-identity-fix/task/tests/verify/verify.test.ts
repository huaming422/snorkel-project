// @ts-nocheck
//
// Behavioral verifier for the Microsoft Entra ID account-identity fix.
//
// Everything here drives PRE-EXISTING, STABLE public interfaces that the
// repo's own tests already use:
//   - the built-in `microsoft` social provider through
//     `client.signIn.social({ provider: "microsoft", idToken })` and the
//     persisted account row via `(await auth.$context).internalAdapter` /
//     `.adapter`.
//   - the generic-oauth `microsoftEntraId(...)` config helper through its
//     returned `getUserInfo(tokens)` / `accountSubject({ profile, tokens })`
//     (the helper's own unit tests call these directly).
//   - provider initialization through `await auth.$context` (a rejected
//     promise is the observable effect of an init guard).
//
// No implementation-internal symbol is imported, and no implementation file
// path is referenced. Where the solving agent is free to choose a form (the
// exact stable identifier), the assertions test the STABILITY PROPERTY: the
// resolved id CONTAINS the token's directory object id and is NOT the pairwise
// subject — so a bare id or a `{tenant}:{id}` composite both pass, while the
// pre-fix behavior (persisting the pairwise subject) fails.

import { exportJWK, generateKeyPair, SignJWT } from "jose";
import { HttpResponse, http } from "msw";
import { setupServer } from "msw/node";
import {
	afterAll,
	afterEach,
	beforeAll,
	describe,
	expect,
	it,
} from "vitest";
import { getTestInstance } from "./test-utils/test-instance";
import { microsoftEntraId } from "./plugins/generic-oauth/providers/microsoft-entra-id";

const mswServer = setupServer();

beforeAll(() => {
	mswServer.listen({ onUnhandledRequest: "bypass" });
});
afterEach(() => {
	mswServer.resetHandlers();
});
afterAll(() => {
	mswServer.close();
});

// A fixed RSA key pair + JWKS for the built-in provider's ID-token signature
// verification. The built-in provider verifies the ID token against the Entra
// JWKS endpoint, so these tokens must be properly signed.
const rsaKeyPair = await generateKeyPair("RS256");
const rsaJwk = await exportJWK(rsaKeyPair.publicKey);
const msKid = "verify-microsoft-kid";
rsaJwk.kid = msKid;
rsaJwk.alg = "RS256";
rsaJwk.use = "sig";

const ENTRA_JWKS_URL =
	"https://login.microsoftonline.com/common/discovery/v2.0/keys";
const GRAPH_PHOTO_URL = "https://graph.microsoft.com/v1.0/me/photos/*";
const GRAPH_USERINFO_URL = "https://graph.microsoft.com/oidc/userinfo";

// Mint a validly-signed built-in-provider ID token. The token's issuer must
// name its own tenant (`iss === authority/<tid>/v2.0`) to pass the provider's
// claim binding; audience must equal the configured clientId.
async function signBuiltinIdToken(
	clientId: string,
	claims: Record<string, unknown>,
) {
	const tid = (claims.tid as string) ?? "verify-tenant";
	return new SignJWT({ tid, ...claims })
		.setProtectedHeader({ alg: "RS256", kid: msKid })
		.setIssuedAt()
		.setIssuer(`https://login.microsoftonline.com/${tid}/v2.0`)
		.setAudience(clientId)
		.setExpirationTime("1h")
		.sign(rsaKeyPair.privateKey);
}

// Mint a generic-helper ID token. The helper only decodes the ID token (it does
// not verify the signature itself), so a simple HS256 token is sufficient — this
// mirrors the helper's own unit tests.
async function signHelperIdToken(payload: Record<string, unknown>) {
	return new SignJWT(payload)
		.setProtectedHeader({ alg: "HS256" })
		.setIssuedAt()
		.setExpirationTime("1h")
		.sign(new TextEncoder().encode("verify-helper-secret"));
}

function newHelper(tenantId = "12345678-1234-1234-1234-123456789012") {
	return microsoftEntraId({
		clientId: "verify-ms-client-id",
		clientSecret: "verify-ms-client-secret",
		tenantId,
	});
}

describe("account_id_is_stable_oid_builtin", () => {
	it("persists the account id from the stable directory object id, not the pairwise subject", async () => {
		const clientId = "verify-builtin-stable";
		const oid = "stable-oid-aaaa1111";
		const sub = "pairwise-sub-bbbb2222";

		const idToken = await signBuiltinIdToken(clientId, {
			sub,
			oid,
			tid: "verify-tenant-stable",
			email: "stable-user@outlook.com",
			name: "Stable User",
		});

		mswServer.use(
			http.get(ENTRA_JWKS_URL, async () =>
				HttpResponse.json({ keys: [rsaJwk] }),
			),
			http.get(GRAPH_PHOTO_URL, async () => new HttpResponse(null, { status: 404 })),
		);

		const { auth, client } = await getTestInstance(
			{
				socialProviders: {
					microsoft: { clientId, clientSecret: "verify-builtin-secret" },
				},
			},
			{ disableTestUser: true },
		);

		const res = await client.signIn.social({
			provider: "microsoft",
			callbackURL: "/callback",
			idToken: { token: idToken },
		});

		expect(res.error).toBeFalsy();
		expect(res.data?.redirect).toBe(false);

		const ctx = await auth.$context;
		const accounts = await ctx.internalAdapter.findAccounts(res.data.user.id);
		const accountId = accounts.find(
			(a) => a.providerId === "microsoft",
		)?.providerAccountId;

		// Stability property: the persisted id is derived from the stable `oid`
		// (bare or `{tid}:{oid}` both contain it) and is NOT the pairwise `sub`.
		expect(accountId).toBeTruthy();
		expect(accountId).toContain(oid);
		expect(accountId).not.toBe(sub);
	}, 60_000);
});

describe("account_id_is_stable_oid_generic", () => {
	it("resolves the account subject from the stable directory object id, not the pairwise subject", async () => {
		const oid = "stable-oid-cccc3333";
		const sub = "pairwise-sub-dddd4444";
		const helper = newHelper();

		// Keep the Graph endpoint deterministic+offline for any implementation
		// that chooses to call it; the correct token-only path (no access token)
		// never reaches it.
		mswServer.use(
			http.get(GRAPH_USERINFO_URL, () =>
				HttpResponse.json({ sub, email: "graph@example.com", name: "Graph User" }),
			),
		);

		// No access token -> the helper resolves identity from the ID token alone
		// and never needs Graph.
		const idToken = await signHelperIdToken({
			sub,
			oid,
			tid: "verify-tenant-generic",
			email: "generic-user@example.com",
			name: "Generic User",
		});

		const profile = await helper.getUserInfo({ idToken });
		expect(profile).toBeTruthy();

		const subject = await helper.accountSubject({
			tokens: { idToken },
			profile,
		});

		expect(subject).toBeTruthy();
		expect(subject).toContain(oid);
		expect(subject).not.toBe(sub);
	}, 60_000);
});

describe("reject_token_without_oid_builtin", () => {
	it("rejects an ID-token sign-in with no usable oid and creates no account row", async () => {
		const clientId = "verify-builtin-no-oid";
		const idToken = await signBuiltinIdToken(clientId, {
			sub: "pairwise-sub-eeee5555",
			// deliberately no `oid` claim
			tid: "verify-tenant-no-oid",
			email: "no-oid@outlook.com",
			name: "No Oid User",
		});

		mswServer.use(
			http.get(ENTRA_JWKS_URL, async () =>
				HttpResponse.json({ keys: [rsaJwk] }),
			),
			http.get(GRAPH_PHOTO_URL, async () => new HttpResponse(null, { status: 404 })),
		);

		const { auth, client } = await getTestInstance(
			{
				socialProviders: {
					microsoft: { clientId, clientSecret: "verify-no-oid-secret" },
				},
			},
			{ disableTestUser: true },
		);

		const res = await client.signIn.social({
			provider: "microsoft",
			callbackURL: "/callback",
			idToken: { token: idToken },
		});

		// Sign-in fails and no microsoft account is created for the unstable identity.
		expect(res.error).toBeTruthy();
		expect(res.error?.status).toBe(401);

		const ctx = await auth.$context;
		const accounts = await ctx.adapter.findMany({
			model: "account",
			where: [{ field: "providerId", value: "microsoft" }],
		});
		expect(accounts).toHaveLength(0);
	}, 60_000);
});

describe("reject_token_without_oid_generic", () => {
	it.each([
		["missing", undefined],
		["not a string", 123],
		["blank", " \t"],
	])("returns no identity (and never calls Graph) when oid is %s", async (_label, oid) => {
		const helper = newHelper();
		let graphCalls = 0;
		mswServer.use(
			http.get(GRAPH_USERINFO_URL, () => {
				graphCalls++;
				return HttpResponse.json({
					sub: "pairwise-sub-ffff6666",
					email: "graph@example.com",
					name: "Graph User",
				});
			}),
		);

		const idToken = await signHelperIdToken({
			sub: "pairwise-sub-ffff6666",
			oid,
			email: "legacy@example.com",
			name: "Legacy User",
		});

		const profile = await helper.getUserInfo({
			accessToken: "verify-ms-access-token",
			idToken,
		});

		expect(profile).toBeNull();
		expect(graphCalls).toBe(0);
	}, 60_000);
});
