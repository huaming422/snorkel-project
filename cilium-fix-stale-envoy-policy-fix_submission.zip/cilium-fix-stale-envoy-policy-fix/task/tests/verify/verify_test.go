// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

// In-package tests for the Envoy network-policy update/remove control path.
//
// Everything is driven through the stable method pair on *xdsServer
// (UpdateNetworkPolicy / RemoveNetworkPolicy) and observed through the stable
// read surfaces the access-log path already uses: localEndpointStore's
// getLocalEndpoint(name) and the network-policy cache's Lookup(typeURL, name).
// State is seeded only through those stable methods and the pre-existing cache
// mutator, never through the internal store setters — so any internal
// restructuring of the correlation store is accepted equally.
//
// Fixtures (endpoint IDs, IP strings, identity labels) are local test values:
// the only constraint that matters is that two endpoints share one IP, modelling
// address reuse after workload churn.
package envoy

import (
	"strconv"
	"testing"

	"github.com/cilium/hive/hivetest"
	"github.com/stretchr/testify/require"

	"github.com/cilium/cilium/pkg/crypto/certificatemanager"
	envoypolicy "github.com/cilium/cilium/pkg/envoy/policy"
	"github.com/cilium/cilium/pkg/envoy/test"
	"github.com/cilium/cilium/pkg/identity"
	"github.com/cilium/cilium/pkg/identity/identitymanager"
	k8sConst "github.com/cilium/cilium/pkg/k8s/apis/cilium.io"
	"github.com/cilium/cilium/pkg/labels"
	"github.com/cilium/cilium/pkg/policy"
	"github.com/cilium/cilium/pkg/policy/api"
	testpolicy "github.com/cilium/cilium/pkg/testutils/policy"
)

// vrfNewXDSServer constructs an *xdsServer wired to a fresh correlation store and
// an initialized network-policy cache/mutator, using only pre-existing constructors.
func vrfNewXDSServer(t *testing.T) *xdsServer {
	logger := hivetest.Logger(t)
	xds := newXDSServer(
		logger,
		nil,
		nil,
		newLocalEndpointStore(),
		xdsServerConfig{},
		certificatemanager.NewMockSecretManagerInline(),
	)
	xds.l7RulesTranslator = envoypolicy.NewEnvoyL7RulesTranslator(logger, nil)
	return xds
}

// vrfNewPolicyRepo builds a policy repository holding a single egress-allow rule
// and returns it along with the local identity the rule selects. Reused to distill
// a real *policy.EndpointPolicy for any endpoint under test.
func vrfNewPolicyRepo(t *testing.T) (*policy.Repository, *identity.Identity) {
	logger := hivetest.Logger(t)
	localIdentity := identity.NewIdentity(9001, labels.LabelArray{
		labels.NewLabel("id", "a", labels.LabelSourceK8s),
		labels.NewLabel(k8sConst.PodNamespaceLabel, "default", labels.LabelSourceK8s),
	}.Labels())

	idMgr := identitymanager.NewIDManager(logger)
	repo := policy.NewPolicyRepository(
		logger,
		identity.IdentityMap{localIdentity.ID: localIdentity.LabelArray},
		nil,
		envoypolicy.NewEnvoyL7RulesTranslator(logger, certificatemanager.NewMockSecretManagerInline()),
		idMgr,
		testpolicy.NewPolicyMetricsNoop(),
	)
	idMgr.Add(localIdentity)
	t.Cleanup(func() { idMgr.Remove(localIdentity) })

	rule := &api.Rule{
		EndpointSelector: api.NewESFromLabels(labels.ParseSelectLabel("id=a")),
		Egress: []api.EgressRule{{
			EgressCommonRule: api.EgressCommonRule{
				ToEndpoints: []api.EndpointSelector{api.WildcardEndpointSelector},
			},
		}},
	}
	require.NoError(t, rule.Sanitize())
	repo.MustAddList(api.Rules{rule})
	return repo, localIdentity
}

// vrfDistill resolves and distills an endpoint policy for the given endpoint from repo.
func vrfDistill(t *testing.T, repo *policy.Repository, localIdentity *identity.Identity, ep *listenerProxyUpdaterMock) *policy.EndpointPolicy {
	logger := hivetest.Logger(t)
	selPolicy, _, err := repo.GetSelectorPolicy(localIdentity, 0, &dummyPolicyStats{}, ep.GetID())
	require.NoError(t, err)
	epp := selPolicy.DistillPolicy(logger, ep, nil)
	t.Cleanup(func() { epp.Detach(logger) })
	return epp
}

func vrfEndpoint(id uint64, ipv4, ipv6 string) *listenerProxyUpdaterMock {
	return &listenerProxyUpdaterMock{ProxyUpdaterMock: &test.ProxyUpdaterMock{
		Id:   id,
		Ipv4: ipv4,
		Ipv6: ipv6,
	}}
}

// TestStaleEntryEvictedOnUpdate: a policy update for an endpoint that reuses an
// address still held by an earlier, different endpoint instance must leave the
// address resolving to the current endpoint and leave NO correlation entry
// pointing at the superseded one — including entries under names the current
// endpoint never reports.
func TestStaleEntryEvictedOnUpdate(t *testing.T) {
	repo, id := vrfNewPolicyRepo(t)
	xds := vrfNewXDSServer(t)

	staleEP := vrfEndpoint(500, "10.0.0.159", "fd00:10:244::500")
	currentEP := vrfEndpoint(2766, "10.0.0.159", "fd00:10:244::ab0e") // reuses staleEP's IPv4

	// Seed the stale endpoint through the stable update method: this populates the
	// correlation store under both of its names and publishes its policy resource.
	err, revert := xds.UpdateNetworkPolicy(staleEP, vrfDistill(t, repo, id, staleEP), nil)
	require.NoError(t, err)
	require.NotNil(t, revert)
	require.Equal(t, staleEP.GetID(), xds.localEndpointStore.getLocalEndpoint(staleEP.Ipv6).GetID())

	// Conflicting update for the endpoint that reuses the shared IPv4.
	err, revert = xds.UpdateNetworkPolicy(currentEP, vrfDistill(t, repo, id, currentEP), nil)
	require.NoError(t, err)
	require.NotNil(t, revert)

	got := xds.localEndpointStore.getLocalEndpoint(currentEP.Ipv4)
	require.NotNil(t, got)
	require.Equal(t, currentEP.GetID(), got.GetID())
	got = xds.localEndpointStore.getLocalEndpoint(currentEP.Ipv6)
	require.NotNil(t, got)
	require.Equal(t, currentEP.GetID(), got.GetID())
	// The superseded endpoint's other name must be gone, not just the shared one.
	require.Nil(t, xds.localEndpointStore.getLocalEndpoint(staleEP.Ipv6))
}

// TestStaleXdsPolicyDeletedOnConflict: when a conflicting (stale) endpoint is
// detected during an update, that endpoint's published policy resource (keyed by
// its ID) must be removed from the proxy-facing cache, so the proxy stops
// enforcing it. A fix that only repairs the correlation map leaves this behind.
func TestStaleXdsPolicyDeletedOnConflict(t *testing.T) {
	repo, id := vrfNewPolicyRepo(t)
	xds := vrfNewXDSServer(t)

	staleEP := vrfEndpoint(500, "10.0.0.159", "fd00:10:244::500")
	currentEP := vrfEndpoint(2766, "10.0.0.159", "fd00:10:244::ab0e")
	staleResourceName := strconv.FormatUint(staleEP.GetID(), 10)

	err, _ := xds.UpdateNetworkPolicy(staleEP, vrfDistill(t, repo, id, staleEP), nil)
	require.NoError(t, err)
	// The stale endpoint's policy resource is present before the conflict.
	seeded, err := xds.networkPolicyCache.Lookup(NetworkPolicyTypeURL, staleResourceName)
	require.NoError(t, err)
	require.NotNil(t, seeded)

	err, _ = xds.UpdateNetworkPolicy(currentEP, vrfDistill(t, repo, id, currentEP), nil)
	require.NoError(t, err)

	stalePolicy, err := xds.networkPolicyCache.Lookup(NetworkPolicyTypeURL, staleResourceName)
	require.NoError(t, err)
	require.Nil(t, stalePolicy)

	// Conflict handling must remove the stale resource only: the current endpoint's
	// own freshly published policy must still be live (guards against an
	// over-aggressive fix that clears more than the superseded resource).
	currentPolicy, err := xds.networkPolicyCache.Lookup(NetworkPolicyTypeURL, strconv.FormatUint(currentEP.GetID(), 10))
	require.NoError(t, err)
	require.NotNil(t, currentPolicy)
}

// TestStoreSurvivesPolicyUpdateRevert: the correlation-store changes made during
// an update reflect endpoint existence only; running the update's revert function
// (the proxy ack/completion machinery uses it) must NOT roll the store back to the
// stale mapping. After revert, the current endpoint still owns its names and the
// evicted stale entry stays gone.
func TestStoreSurvivesPolicyUpdateRevert(t *testing.T) {
	repo, id := vrfNewPolicyRepo(t)
	xds := vrfNewXDSServer(t)

	staleEP := vrfEndpoint(500, "10.0.0.159", "fd00:10:244::500")
	currentEP := vrfEndpoint(2766, "10.0.0.159", "fd00:10:244::ab0e")

	err, _ := xds.UpdateNetworkPolicy(staleEP, vrfDistill(t, repo, id, staleEP), nil)
	require.NoError(t, err)

	err, revert := xds.UpdateNetworkPolicy(currentEP, vrfDistill(t, repo, id, currentEP), nil)
	require.NoError(t, err)
	require.NotNil(t, revert)

	require.NoError(t, revert())

	got := xds.localEndpointStore.getLocalEndpoint(currentEP.Ipv4)
	require.NotNil(t, got)
	require.Equal(t, currentEP.GetID(), got.GetID())
	got = xds.localEndpointStore.getLocalEndpoint(currentEP.Ipv6)
	require.NotNil(t, got)
	require.Equal(t, currentEP.GetID(), got.GetID())
	require.Nil(t, xds.localEndpointStore.getLocalEndpoint(staleEP.Ipv6))
}

// TestTeardownRemovesAllEntries: tearing an endpoint down must remove every
// correlation entry belonging to that endpoint instance, including an entry under
// an address it reported earlier but no longer reports at removal time (its IP set
// changed while it was live).
func TestTeardownRemovesAllEntries(t *testing.T) {
	repo, id := vrfNewPolicyRepo(t)
	xds := vrfNewXDSServer(t)

	oldIPv4 := "10.0.0.159"
	newIPv4 := "10.0.0.200"
	ipv6 := "fd00:10:244::ab0e"
	ep := vrfEndpoint(2766, oldIPv4, ipv6)

	// An unrelated, co-resident endpoint that must be untouched by the teardown.
	otherEP := vrfEndpoint(4100, "10.0.0.77", "fd00:10:244::77")
	err, _ := xds.UpdateNetworkPolicy(otherEP, vrfDistill(t, repo, id, otherEP), nil)
	require.NoError(t, err)

	// Seed the target while it reports oldIPv4 + ipv6.
	err, _ = xds.UpdateNetworkPolicy(ep, vrfDistill(t, repo, id, ep), nil)
	require.NoError(t, err)
	require.Equal(t, ep.GetID(), xds.localEndpointStore.getLocalEndpoint(oldIPv4).GetID())
	require.Equal(t, ep.GetID(), xds.localEndpointStore.getLocalEndpoint(ipv6).GetID())

	// The same endpoint instance now reports a changed IPv4 (address churn while live).
	ep.Ipv4 = newIPv4

	xds.RemoveNetworkPolicy(ep)

	// No correlation entry may survive for this endpoint under any address.
	require.Nil(t, xds.localEndpointStore.getLocalEndpoint(oldIPv4))
	require.Nil(t, xds.localEndpointStore.getLocalEndpoint(newIPv4))
	require.Nil(t, xds.localEndpointStore.getLocalEndpoint(ipv6))

	// Teardown must be scoped to the removed endpoint: the co-resident endpoint's
	// entries must still resolve (guards against a blunt clear-everything removal).
	still := xds.localEndpointStore.getLocalEndpoint(otherEP.Ipv4)
	require.NotNil(t, still)
	require.Equal(t, otherEP.GetID(), still.GetID())
	still = xds.localEndpointStore.getLocalEndpoint(otherEP.Ipv6)
	require.NotNil(t, still)
	require.Equal(t, otherEP.GetID(), still.GetID())
}

// TestNormalUpdateAndHostSkip: the normal, non-conflicting path still records the
// endpoint under every name it reports and publishes its policy resource; and an
// endpoint that reports no names (e.g. the host endpoint) is skipped without error
// and without publishing anything.
func TestNormalUpdateAndHostSkip(t *testing.T) {
	repo, id := vrfNewPolicyRepo(t)
	xds := vrfNewXDSServer(t)

	normalEP := vrfEndpoint(3001, "10.0.0.50", "fd00:10:244::50")
	err, revert := xds.UpdateNetworkPolicy(normalEP, vrfDistill(t, repo, id, normalEP), nil)
	require.NoError(t, err)
	require.NotNil(t, revert)

	require.Equal(t, normalEP.GetID(), xds.localEndpointStore.getLocalEndpoint(normalEP.Ipv4).GetID())
	require.Equal(t, normalEP.GetID(), xds.localEndpointStore.getLocalEndpoint(normalEP.Ipv6).GetID())
	published, err := xds.networkPolicyCache.Lookup(NetworkPolicyTypeURL, strconv.FormatUint(normalEP.GetID(), 10))
	require.NoError(t, err)
	require.NotNil(t, published)

	// Host-style endpoint: no reported names. Must return no error and publish nothing.
	hostEP := vrfEndpoint(1, "", "")
	err, revert = xds.UpdateNetworkPolicy(hostEP, vrfDistill(t, repo, id, hostEP), nil)
	require.NoError(t, err)
	require.NotNil(t, revert)
	hostPolicy, err := xds.networkPolicyCache.Lookup(NetworkPolicyTypeURL, strconv.FormatUint(hostEP.GetID(), 10))
	require.NoError(t, err)
	require.Nil(t, hostPolicy)
}
