## Task

When a page script sets an attribute to a value with `<` or `>` in it and
reads the markup back, those two characters come out literal. A browser
writes them as `&lt;` and `&gt;` inside the quoted value.

It isn't only an element's `outerHTML` and `innerHTML`. The same raw
characters show up in a template's or a shadow root's `innerHTML`, in
`Page.ContentAsync()`, and in what the DevTools `DOM.getOuterHTML` command
returns, whether you ask it for one element or for the whole document.

All of those should serialize attributes the way a browser does.
`getAttribute` should still hand back the raw value.
