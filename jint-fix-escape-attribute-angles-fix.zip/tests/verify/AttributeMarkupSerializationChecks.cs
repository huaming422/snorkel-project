using System.Text.Json;
using AngleSharp.Xml.Parser;
using Jint.Browser.Dom;
using Jint.Tests.Browser.DevTools;

namespace Jint.Tests.Browser.Dom;

using Browser = global::Jint.Browser.Browser;

// HTML attribute serialization read back through the JS DOM markup getters
// (DomTestFixture), Page.ContentAsync, the DevTools DOM.getOuterHTML result
// (PageSession) and AngleSharp's XML serialization. Only string output is asserted.
public sealed class AttributeMarkupSerializationChecks
{
    // Angle brackets in an attribute value come out as &lt; and &gt;, through the
    // element's own markup and through its parent's inner markup.
    [TestCase("axx>", "axx&gt;")]
    [TestCase("some<>", "some&lt;&gt;")]
    public void AttributeAnglesAreEscapedInHtmlMarkup(string value, string escaped)
    {
        using var fixture = DomTestFixture.Create("<main></main>");
        fixture.Engine.SetValue("value", value);
        fixture.Execute("var el = document.createElement('el'); el.setAttribute('attr', value); document.querySelector('main').append(el);");
        fixture.Text("el.outerHTML").Should().Be("<el attr=\"" + escaped + "\"></el>");
        fixture.Text("document.querySelector('main').innerHTML").Should().Be("<el attr=\"" + escaped + "\"></el>");
    }

    // An SVG element's attribute value is escaped the same way.
    [Test]
    public void SvgElementAttributeAnglesAreEscaped()
    {
        using var fixture = DomTestFixture.Create("<main></main>");
        fixture.Execute("var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); svg.setAttribute('data-x', 'some<>'); document.querySelector('main').append(svg);");
        fixture.Text("svg.outerHTML").Should().Be("<svg data-x=\"some&lt;&gt;\"></svg>");
    }

    // &, " and the non-breaking space come out escaped once, an apostrophe stays
    // literal, and getAttribute returns the raw value.
    [Test]
    public void ExistingEscapesAreNotDoubledAndRawValueIsPreserved()
    {
        const string value = "&lt;<>\"\u00a0&'";
        const string escaped = "&amp;lt;&lt;&gt;&quot;&nbsp;&amp;'";
        using var fixture = DomTestFixture.Create("<main></main>");
        fixture.Engine.SetValue("value", value);
        fixture.Execute("var el = document.createElement('el'); el.setAttribute('attr', value); document.querySelector('main').append(el);");
        fixture.Text("el.outerHTML").Should().Be("<el attr=\"" + escaped + "\"></el>");
        fixture.Text("el.getAttribute('attr')").Should().Be(value);
    }

    // An attribute name holding a quote or an angle bracket, and a namespaced
    // name, come out as written; their values are escaped.
    [Test]
    public void AttributeNamesAndNamespaceSpellingRemainNative()
    {
        using var fixture = DomTestFixture.Create("<main></main>");
        fixture.Execute("""
            var el = document.createElement('el');
            el.setAttribute('a"<', '<>');
            el.setAttributeNS('http://www.w3.org/XML/1998/namespace', 'xml:lang', '<>');
            document.querySelector('main').append(el);
            """);
        fixture.Text("el.outerHTML").Should().Be("""<el a"<="&lt;&gt;" xml:lang="&lt;&gt;"></el>""");
    }

    // Template content and shadow-root markup show the escaped value too.
    [Test]
    public void TemplateAndShadowRootMarkupUseTheSameSerialization()
    {
        using var fixture = DomTestFixture.Create("<main></main>");
        fixture.Execute("""
            var template = document.createElement('template');
            template.innerHTML = '<el attr="some<>"></el>';
            var shadow = document.querySelector('main').attachShadow({mode:'open'});
            shadow.append(template.content.cloneNode(true));
            """);
        fixture.Text("template.innerHTML").Should().Be("<el attr=\"some&lt;&gt;\"></el>");
        fixture.Text("shadow.innerHTML").Should().Be("<el attr=\"some&lt;&gt;\"></el>");
    }

    // Page.ContentAsync returns the whole document, doctype included, with the
    // escaped value. XMLSerializer output escapes '<'
    // and leaves '>' literal in the attribute value.
    [Test]
    public async Task PageContentEscapesAttributeAnglesWhileXmlSerializerStaysNative()
    {
        await using var browser = new Browser();
        var page = await browser.NewPageAsync();
        await page.SetContentAsync("<!doctype html><el attr='some<>'></el>");
        (await page.ContentAsync()).Should().Be("<!DOCTYPE html><html><head></head><body><el attr=\"some&lt;&gt;\"></el></body></html>");
        (await page.EvaluateAsync<string>("new XMLSerializer().serializeToString(document.querySelector('el'))"))
            .Should().Be("<el attr=\"some&lt;>\" />");
    }

    // DOM.getOuterHTML on an element and on the document shows the escaped value,
    // and outerHTML read through Runtime evaluation agrees.
    [Test]
    public async Task DevToolsOuterHtmlEscapesAttributeAngles()
    {
        await using var session = await PageSession.CreateAsync();
        var attachment = await session.OpenPageAsync();
        await SetBody(session, attachment, "<el attr='some<>'></el>");
        var root = (await session.ResultAsync("DOM.getDocument", "{}", attachment)).GetProperty("root");
        var documentId = root.GetProperty("nodeId").GetInt32();
        var element = (await session.ResultAsync("DOM.querySelector",
            $$"""{"nodeId":{{documentId}},"selector":"el"}""", attachment)).GetProperty("nodeId").GetInt32();
        (await session.ResultAsync("DOM.getOuterHTML", $$"""{"nodeId":{{element}}}""", attachment))
            .GetProperty("outerHTML").GetString().Should().Be("<el attr=\"some&lt;&gt;\"></el>");
        (await session.ResultAsync("DOM.getOuterHTML", $$"""{"nodeId":{{documentId}}}""", attachment))
            .GetProperty("outerHTML").GetString().Should().Be("<html><head></head><body><el attr=\"some&lt;&gt;\"></el></body></html>");
        (await session.EvaluateAsync("document.querySelector('el').outerHTML", attachment))
            .GetProperty("value").GetString().Should().Be("<el attr=\"some&lt;&gt;\"></el>");
    }

    // For an XML document the JS markup getters return the same string as
    // AngleSharp's OuterHtml/InnerHtml, with the namespace declarations, the empty
    // tag and the non-breaking space.
    [Test]
    public void XmlDocumentMarkupGettersPreserveNativeSerialization()
    {
        using var fixture = DomTestFixture.Create("<main></main>");
        using var xml = new XmlParser().ParseDocument(
            "<root xmlns='urn:root' xmlns:p='urn:p'><p:leaf/></root>");
        var root = xml.DocumentElement!;
        root.FirstElementChild!.SetAttribute("data", "\u00a0");
        var nativeInner = root.InnerHtml;
        var nativeOuter = root.OuterHtml;
        fixture.Engine.SetValue("xml", DomBindings.Wrap(fixture.Engine, xml));
        fixture.Text("xml.documentElement.innerHTML").Should().Be(nativeInner);
        fixture.Text("xml.documentElement.outerHTML").Should().Be(nativeOuter);
        nativeInner.Should().Contain("<p:leaf data=\"&nbsp;\">");
        nativeOuter.Should().Contain("xmlns=\"urn:root\" xmlns:p=\"urn:p\"");
    }

    // Text escapes <, > and & and leaves quotes literal; comment and raw <script>
    // content stay literal, including text shaped like a quoted attribute.
    [Test]
    public void NonAttributeContentKeepsNativeEscaping()
    {
        using var fixture = DomTestFixture.Create("<main></main>");
        fixture.Execute("""
            var el = document.createElement('el');
            el.append(document.createTextNode('<>& c="<>"'), document.createComment('<> b="<>"'));
            var script = document.createElement('script');
            script.textContent = 'var t = \'x="<>"\'; a < b && c > d';
            el.append(script);
            document.querySelector('main').append(el);
            """);
        fixture.Text("el.outerHTML").Should().Be("<el>&lt;&gt;&amp; c=\"&lt;&gt;\"<!--<> b=\"<>\"--><script>var t = 'x=\"<>\"'; a < b && c > d</script></el>");
    }

    private static async Task SetBody(PageSession session, string attachment, string body)
    {
        await session.ResultAsync(
            "Page.setDocumentContent",
            JsonSerializer.Serialize(new Dictionary<string, object> { ["frameId"] = "", ["html"] = body }),
            attachment);
    }
}
