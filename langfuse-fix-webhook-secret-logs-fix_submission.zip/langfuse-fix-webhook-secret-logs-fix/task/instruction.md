## Task

operators are reporting two problems on the same webhook deliveries.

first, a credential leak. some customers point webhooks at destinations whose URL carries a shared secret baked in, the kind of signed callback URL cloud iPaaS products hand out. when one fails, the secret shows up verbatim in the worker's logs and gets saved onto the failed delivery's stored error record, so anyone who can read our logs, traces, or database can harvest a live secret. and it isn't one stray line: the URL reaches logs and stored errors through more than one path, logged directly and also riding inside an error object a generic failure handler serializes later. a single-spot patch won't close it.

this is only about what we log and store. the request we send must keep the full, unmodified URL, since the receiver authenticates with that secret. but don't scrub so hard you blind operators: a failure still has to show which destination it was (enough of the URL to recognize) and why.

second, those same deliveries intermittently fail with a connection timeout a fraction of a second in, well before our configured request timeout, nothing changed on the destination. dig into both and fix.
