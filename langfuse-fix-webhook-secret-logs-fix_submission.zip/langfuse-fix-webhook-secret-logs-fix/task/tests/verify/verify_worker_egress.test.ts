// @ts-nocheck
//
// Behavioral verifier for the redaction contract AT THE WORKER EGRESS BOUNDARY,
// not in isolation. It exercises the pre-existing worker symbol
//   rethrowIfOutboundValidationFailure  (worker/src/features/analyticsIntegrationEgress)
// together with the pre-existing shared RedirectValidationError, exactly the way
// a failed outbound send is classified and re-reported before the queue's
// generic `failed` handler logs the whole error and persists its `failedReason`.
//
// This mirrors the worker's offline analytics SSRF-pinning harness: prisma, the
// worker env, and encryption are mocked; the shared logger is replaced; no
// network, no datastore. The gating assertions ride pre-existing symbols only —
// no new helper symbol is imported or required.
//
// Behavior under test: a credentialed + signed redirect target reaches the
// rethrown error's serializable surface verbatim before the fix; after the fix
// every surface is secret-free while still carrying the blocked host and the
// failure reason.

import { describe, expect, it, vi } from "vitest";

// The worker env module reads process.env and would otherwise pull the full
// zod-validated worker schema; the egress classifier under test never reads it,
// so a minimal stub keeps the import offline and deterministic.
vi.mock("../env", () => ({
  env: {
    LANGFUSE_MIGRATION_V4_WRITE_MODE: "legacy",
  },
  v4WritesToLegacyTables: () => true,
  v4WritesToEventsTable: () => false,
}));

// The classifier never touches prisma, but sibling modules in the barrel can
// construct a client at import; stub it so the import graph stays datastore-free.
vi.mock("@langfuse/shared/src/db", () => ({
  prisma: {},
}));

// Replace ONLY the shared logger (the classifier calls logger.error); keep every
// other shared export — the real RedirectValidationError, OutboundUrlValidationError,
// redactUrlCredentials, etc. — intact via importOriginal.
vi.mock("@langfuse/shared/src/server", async (importOriginal) => {
  const actual =
    await importOriginal<typeof import("@langfuse/shared/src/server")>();
  return {
    ...actual,
    logger: { info: vi.fn(), warn: vi.fn(), error: vi.fn(), debug: vi.fn() },
  };
});

// Imported after mocks are registered.
import {
  RedirectValidationError,
  OutboundUrlValidationError,
} from "@langfuse/shared/src/server";
import { isUnrecoverableError } from "../errors/UnrecoverableError";
import { rethrowIfOutboundValidationFailure } from "../features/analyticsIntegrationEgress";

const QUERY_SECRET = "super-secret-sig";
const USERINFO_SECRET = "hunter2";
const BLOCKED_HOST = "169.254.169.254";
const KEPT_PATH = "/latest";
const BLOCK_REASON = "Blocked IP address detected: 169.254.169.254";

// Everything a structured logger or tracer can pull off a thrown error: its
// enumerable own fields (winston copies those into the JSON log line), its
// message, its stack, and the same again for each `cause` a chain-walking
// reporter follows.
function serializableSurface(error: unknown): string {
  const parts: string[] = [];
  let current: any = error;
  for (let depth = 0; depth < 6 && current; depth++) {
    parts.push(JSON.stringify({ ...current }));
    if (typeof current.message === "string") parts.push(current.message);
    if (typeof current.stack === "string") parts.push(current.stack);
    current = current.cause;
  }
  return parts.join("\n");
}

// A connect-time redirect block, shaped the way undici surfaces it: a generic
// "fetch failed" TypeError whose enumerable `cause` is the real validation
// error, whose rejected redirect target carries userinfo credentials AND a
// query-string secret.
const credentialedRedirect = () =>
  Object.assign(new TypeError("fetch failed"), {
    cause: new RedirectValidationError(
      BLOCK_REASON,
      "http://exporter:hunter2@169.254.169.254/latest?sig=super-secret-sig",
      0,
      new OutboundUrlValidationError("blocked-ip", BLOCK_REASON),
    ),
  });

function captureRethrow(error: unknown): unknown {
  try {
    rethrowIfOutboundValidationFailure(error, {
      logSubject: "Webhook outbound send",
      jobSubject: "Webhook delivery",
    });
  } catch (caught) {
    return caught;
  }
  return undefined;
}

describe("worker egress — terminal outbound failure reporting", () => {
  // FAIL-TO-PASS, basic_functionality.
  it("strips the secret from the rethrown message while keeping the host and reason", () => {
    const thrown = captureRethrow(credentialedRedirect());

    expect(isUnrecoverableError(thrown)).toBe(true);
    const message = (thrown as Error).message;
    expect(message).not.toContain(USERINFO_SECRET);
    expect(message).not.toContain(QUERY_SECRET);
    // Host + path survive so the operator can identify the destination.
    expect(message).toContain(BLOCKED_HOST);
    expect(message).toContain(KEPT_PATH);
    // The diagnostic reason must survive redaction.
    expect(message).toContain(BLOCK_REASON);
  });

  // FAIL-TO-PASS, basic_functionality.
  // The source error is logged directly by the executor BEFORE any re-report
  // runs, so the original object has to be clean on every serializable surface,
  // and so does the rethrown object.
  it("keeps the secret off every serializable surface of the source and rethrown error", () => {
    const source = credentialedRedirect();
    const sourceCause = (source as any).cause as Error;
    // The validation error the executor logs directly must be clean.
    expect(serializableSurface(sourceCause)).not.toContain(USERINFO_SECRET);
    expect(serializableSurface(sourceCause)).not.toContain(QUERY_SECRET);

    const thrown = captureRethrow(source);
    // Redacting only the message is not enough: the generic `failed` handler
    // passes the whole error to the logger and tracer.
    const surface = serializableSurface(thrown);
    expect(surface).not.toContain(USERINFO_SECRET);
    expect(surface).not.toContain(QUERY_SECRET);
    expect(surface).not.toContain("exporter:hunter2@169.254.169.254");
    // Non-vacuous: the redacted reason really is reachable on that surface.
    expect(surface).toContain(BLOCK_REASON);
  });

  // PASS-TO-PASS, over-correction / no-op guard.
  // A credential-free validation error still rethrows as terminal and keeps its
  // reason intact — redaction must not blank out a clean message.
  it("leaves a credential-free block message intact and still terminal", () => {
    let thrown: unknown;
    try {
      rethrowIfOutboundValidationFailure(
        new OutboundUrlValidationError(
          "blocked-ip",
          "Blocked IP address detected: 127.0.0.1",
        ),
        { logSubject: "Webhook outbound send", jobSubject: "Webhook delivery" },
      );
    } catch (caught) {
      thrown = caught;
    }
    expect(isUnrecoverableError(thrown)).toBe(true);
    expect((thrown as Error).message).toContain(
      "Blocked IP address detected: 127.0.0.1",
    );
  });
});
