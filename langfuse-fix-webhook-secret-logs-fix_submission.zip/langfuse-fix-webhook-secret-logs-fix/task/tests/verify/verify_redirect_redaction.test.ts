// @ts-nocheck
//
// Behavioral verifier for the outbound-URL redaction contract, exercised
// entirely through the three PRE-EXISTING, stable redirect error classes that
// the shared outbound layer exports today:
//   RedirectValidationError, MaxRedirectsExceededError, CircularRedirectError
//
// These classes already exist pre-change; their constructor signatures and
// their public fields (.message, .stack, .redirectUrl, .redirectChain, and
// JSON.stringify output) are the highest-level stable surface where the leak
// is observable. A destination URL carrying a secret reaches worker logs and
// the persisted execution error THROUGH these error objects (a generic failure
// handler serializes the whole object), so the error itself must be clean.
//
// What this file deliberately does NOT do:
//   - It does not import or require any new helper symbol (a URL-sanitizing
//     helper is one valid implementation, not a contract). All gating rides
//     the pre-existing error classes.
//   - It does not assert the exact redacted string shape where formatting is a
//     solution choice; it asserts the behavioral contract via substrings:
//     the secret/userinfo/fragment are GONE, and the scheme+host+path plus the
//     failure reason SURVIVE.
//
// The input URLs, secret tokens, and host/path substrings below are test
// fixtures chosen by this verifier — not names the solution must produce.

import { describe, expect, it } from "vitest";
import {
  CircularRedirectError,
  MaxRedirectsExceededError,
  RedirectValidationError,
} from "./fetch";

// Fixture secrets. Shaped like a real signed-callback URL (Azure Logic Apps /
// Power Platform SAS: `sig=` in the query) plus userinfo credentials and a
// fragment secret. None of these may survive onto any serializable surface.
const QUERY_SECRET = "super-secret-sig";
const USERINFO_SECRET = "hunter2";
const FRAGMENT_SECRET = "frag-secret";

const SIGNED_URL =
  "https://exporter:hunter2@host.example/hook/path?api-version=2016-06-01&sig=super-secret-sig#frag-secret";

// What an operator must still be able to read after redaction, to know which
// destination failed: the host (which server) and the path (which endpoint on
// it). The scheme is intentionally NOT required — whether the readable form
// keeps a leading `https://` is a formatting choice, and it never carries a
// secret, so pinning it would reject an equally-valid host+path rendering.
const KEPT_HOST = "host.example";
const KEPT_PATH = "/hook/path";

// Every surface a structured logger / tracer / JSON persistence layer can pull
// off a thrown error: enumerable own fields (winston copies these into the log
// line), the message, the stack, and the JSON serialization — repeated down the
// `cause` chain a chain-walking reporter follows.
function serializableSurface(error: unknown): string {
  const parts: string[] = [];
  let current: any = error;
  for (let depth = 0; depth < 6 && current; depth++) {
    parts.push(JSON.stringify(current));
    parts.push(JSON.stringify({ ...current }));
    if (typeof current.message === "string") parts.push(current.message);
    if (typeof current.stack === "string") parts.push(current.stack);
    current = current.cause;
  }
  return parts.join("\n");
}

function assertNoSecretAnywhere(error: Error) {
  const surface = serializableSurface(error);
  // The credential-bearing components must be gone from EVERY serializable
  // surface, not just the human-readable message. A half-fix that only rewrites
  // `.message` leaves the secret in `.stack` / enumerable fields / JSON output.
  expect(error.message).not.toContain(QUERY_SECRET);
  expect(error.message).not.toContain(USERINFO_SECRET);
  expect(error.stack ?? "").not.toContain(QUERY_SECRET);
  expect(error.stack ?? "").not.toContain(USERINFO_SECRET);
  expect(surface).not.toContain(QUERY_SECRET);
  expect(surface).not.toContain(USERINFO_SECRET);
  expect(surface).not.toContain(FRAGMENT_SECRET);
  expect(surface).not.toContain("exporter:hunter2@");
}

function assertDiagnosticSurvives(error: Error) {
  // Redaction cannot be a blanket scrub: host+path must stay readable so an
  // operator can still identify the destination that failed.
  expect(error.message).toContain(KEPT_HOST);
  expect(error.message).toContain(KEPT_PATH);
}

describe("RedirectValidationError redaction", () => {
  // FAIL-TO-PASS, basic_functionality.
  it("keeps a signed/credentialed redirect target out of every serializable surface", () => {
    const err = new RedirectValidationError(
      "Blocked IP address detected: 169.254.169.254",
      SIGNED_URL,
      0,
      new Error("blocked-ip"),
    );
    assertNoSecretAnywhere(err);
    assertDiagnosticSurvives(err);
    // The failure reason must survive so a blocked IP can be told from a
    // rejected scheme.
    expect(err.message).toContain("Blocked IP address detected");
    // The enumerable field the generic serializer reads must itself be clean.
    expect(err.redirectUrl).not.toContain(QUERY_SECRET);
    expect(err.redirectUrl).not.toContain(USERINFO_SECRET);
    expect(err.redirectUrl).toContain(KEPT_HOST);
    expect(err.redirectUrl).toContain(KEPT_PATH);
  });

  // FAIL-TO-PASS, basic_functionality.
  // A non-special scheme (gopher/file) has URL.origin === "null", so the
  // obvious `origin + pathname` build silently drops the host. The correct
  // build composes scheme+host+path and keeps the host visible.
  it("keeps the host of a non-special-scheme redirect target", () => {
    const err = new RedirectValidationError(
      "Blocked IP address detected: 169.254.169.254",
      "gopher://169.254.169.254/x?sig=super-secret-sig",
      0,
      new Error("blocked-ip"),
    );
    assertNoSecretAnywhere(err);
    expect(err.message).toContain("169.254.169.254");
    expect(err.redirectUrl).toContain("169.254.169.254");
  });

  // FAIL-TO-PASS, nuance (robustness).
  // A value that reaches the sanitized form but does not parse as a URL must be
  // handled gracefully (query/fragment stripped) rather than throwing — the
  // logging path itself must not crash.
  it("handles a non-URL redirect target without throwing and still strips the secret", () => {
    let err: RedirectValidationError | undefined;
    expect(() => {
      err = new RedirectValidationError(
        "Invalid redirect URL",
        "not a url?sig=super-secret-sig#frag-secret",
        0,
        new Error("bad-url"),
      );
    }).not.toThrow();
    const surface = serializableSurface(err as Error);
    expect(surface).not.toContain(QUERY_SECRET);
    expect(surface).not.toContain(FRAGMENT_SECRET);
  });

  // PASS-TO-PASS, over-correction guard.
  // A credential-free URL must stay readable — the goal is to strip secrets, not
  // to reduce every logged URL to an opaque placeholder. Host and path (the
  // destination identity) must survive; the exact rendering of a clean URL is a
  // formatting choice, so assert the identifying components, not the full string.
  it("leaves a credential-free redirect target readable (no over-redaction)", () => {
    const err = new RedirectValidationError(
      "Blocked IP address detected: 10.0.0.1",
      "https://webhook.example.com/clean/path",
      0,
      new Error("blocked-ip"),
    );
    expect(err.message).toContain("webhook.example.com");
    expect(err.message).toContain("/clean/path");
    expect(err.redirectUrl).toContain("webhook.example.com");
    expect(err.redirectUrl).toContain("/clean/path");
  });
});

describe("MaxRedirectsExceededError redaction", () => {
  // FAIL-TO-PASS, basic_functionality.
  it("keeps signed/credentialed chain entries out of every serializable surface", () => {
    const err = new MaxRedirectsExceededError(5, [SIGNED_URL, SIGNED_URL]);
    assertNoSecretAnywhere(err);
    assertDiagnosticSurvives(err);
    // The enumerable chain field is itself a serializable surface.
    for (const entry of err.redirectChain) {
      expect(entry).not.toContain(QUERY_SECRET);
      expect(entry).not.toContain(USERINFO_SECRET);
    }
    // Non-vacuous: the kept diagnostic is really reachable on the chain field.
    expect(err.redirectChain.join(" ")).toContain(KEPT_HOST);
    expect(err.redirectChain.join(" ")).toContain(KEPT_PATH);
  });
});

describe("CircularRedirectError redaction", () => {
  // FAIL-TO-PASS, basic_functionality.
  it("keeps signed/credentialed chain entries out of every serializable surface", () => {
    const err = new CircularRedirectError([SIGNED_URL, SIGNED_URL, SIGNED_URL]);
    assertNoSecretAnywhere(err);
    for (const entry of err.redirectChain) {
      expect(entry).not.toContain(QUERY_SECRET);
      expect(entry).not.toContain(USERINFO_SECRET);
    }
    expect(err.redirectChain.join(" ")).toContain(KEPT_HOST);
    expect(err.redirectChain.join(" ")).toContain(KEPT_PATH);
  });
});
