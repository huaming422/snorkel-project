// @ts-nocheck
//
// Behavioral verifier at the WORKER WEBHOOK-DELIVERY boundary. It drives the
// pre-existing worker entry point `executeWebhook` (worker/src/queues/webhooks)
// end-to-end over a failing delivery with every external dependency mocked —
// prisma, the worker env, encryption, the automation repository reads, and the
// shared outbound `fetchWithSecureRedirects` — and the shared logger replaced
// with spies, the same offline mocking shape the sibling egress suite uses.
//
// It closes three reward holes that the other three suites leave open. All three
// are named co-equal in base.md and all three ride the SAME delivery through this
// one entry point:
//
//   GAP 1 — direct-log redaction. webhooks.ts logs the destination URL directly
//   through the shared logger (the "Sending HTTP request to <url>" line, the
//   non-2xx line, and the generic failure handler that serializes the thrown
//   error, whose message embeds the url). base.md calls the directly-logged path
//   a distinct leak. A solution that only cleans the shared error classes leaves
//   this path leaking and would otherwise score 1.0. ASSERTION (fail-to-pass):
//   the signed secret appears on NO logger call and in NO stored execution error.
//
//   GAP 2 — full URL on the wire. base.md: "the request we send must keep the
//   full, unmodified URL". An over-redaction fix that strips the secret from the
//   actual outbound call breaks receiver authentication with nothing to catch it.
//   ASSERTION (over-redaction guard): the outbound fetch is invoked with the
//   full, unmodified URL.
//
//   GAP 3 — the webhook delivery path actually REQUESTS a widened per-address
//   connection-attempt window. The sibling connection-timeout suite proves the
//   shared pool keys on such a window, but nothing proves the webhook callsite
//   threads one through. A solution that builds the keying plumbing but never
//   wires a value at the delivery callsite leaves the real timeout bug unfixed
//   and still scores 1.0. ASSERTION (fail-to-pass): the connection-validation
//   options the webhook delivery hands to the outbound fetch carry a per-address
//   attempt window ABOVE Node's 250ms default.
//
// WHY THE ROOT `@langfuse/shared` BARREL IS MOCKED: its built `dist/src/index.js`
// throws a circular zod-enum init error when loaded under this test harness (it
// fails identically in plain node and under every existing worker test that
// imports the root barrel). The sibling verifiers sidestep it by importing only
// `@langfuse/shared/src/server`, which loads cleanly. `webhooks.ts` imports the
// root barrel directly, so to exercise `executeWebhook` at all we must mock the
// root barrel with the handful of symbols it uses. The real `src/server` barrel
// is kept intact via importOriginal, exactly as the egress suite does.
//
// IMPLEMENTATION-AGNOSTIC BY CONSTRUCTION:
//   - Rides only the pre-existing `executeWebhook` export and the pre-existing
//     shared `fetchWithSecureRedirects` seam. Imports no symbol the solution
//     must invent (no `urlForLog`, no `sanitizeUrlForLogs`, no new constant).
//   - GAP 1/2 assert on the SECRET and the URL, never on a redaction format.
//   - GAP 3 asserts a numeric PROPERTY (some value in the outbound options is
//     > Node's 250ms default), never a field name or a specific constant. The
//     oracle names it `addressAttemptTimeoutMs`; frontier variants name it
//     differently — any field carrying a raised window satisfies this.

import { beforeEach, describe, expect, it, vi } from "vitest";

// The delivery URL under test: a signed callback whose shared secret rides the
// query string, the exact shape base.md describes (cloud iPaaS signed URL).
const DELIVERY_URL = "https://host.example/hook/path?sig=super-secret-sig";
const SECRET = "super-secret-sig";
const DEST_HOST = "host.example";

// Node's per-address connection-attempt default (undici autoSelectFamily). The
// fix must raise the webhook window strictly above this; we assert the property,
// not any particular raised value.
const NODE_DEFAULT_ATTEMPT_TIMEOUT_MS = 250;

// All captured spies/fns live in a hoisted record so the hoisted vi.mock
// factories below may reference them safely (vitest lifts vi.mock above imports).
const h = vi.hoisted(() => {
  const logger = {
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
    debug: vi.fn(),
  };
  const executionUpdate = vi.fn(async () => undefined);
  const triggerUpdate = vi.fn(async () => undefined);
  const deliveryUrl = "https://host.example/hook/path?sig=super-secret-sig";
  const fetchWithSecureRedirects = vi.fn(async () => ({
    response: new Response('{"error":"nope"}', { status: 500 }),
    redirectChain: [],
    finalUrl: deliveryUrl,
  }));
  return { logger, executionUpdate, triggerUpdate, fetchWithSecureRedirects };
});

// Root `@langfuse/shared` barrel: its dist is broken under this harness, so we
// supply only the runtime symbols webhooks.ts imports from it. Type-only imports
// (AutomationDomain, ActionDomainWithSecrets) are erased and need nothing here.
vi.mock("@langfuse/shared", () => {
  class InternalServerError extends Error {
    constructor(message: string) {
      super(message);
      this.name = "InternalServerError";
    }
  }
  class LangfuseNotFoundError extends Error {
    constructor(message: string) {
      super(message);
      this.name = "LangfuseNotFoundError";
    }
  }
  return {
    InternalServerError,
    LangfuseNotFoundError,
    ActionExecutionStatus: {
      COMPLETED: "COMPLETED",
      ERROR: "ERROR",
      PENDING: "PENDING",
      CANCELLED: "CANCELLED",
    },
    JobConfigState: { ACTIVE: "ACTIVE", INACTIVE: "INACTIVE" },
    WebhookDefaultHeaders: {},
    PromptWebhookOutboundSchema: {
      safeParse: (data: unknown) => ({ success: true, data }),
    },
    // The delivery under test is a WEBHOOK action; the guard just needs to agree.
    isWebhookAction: (action: { type?: string }) => action?.type === "WEBHOOK",
    isSlackActionConfig: () => false,
    isGitHubDispatchAction: () => false,
  };
});

// Backoff collapsed to a single attempt so the delivery path runs once and
// deterministically; the real retry policy is irrelevant to what we assert.
vi.mock("exponential-backoff", () => ({
  backOff: vi.fn(async (fn: () => Promise<unknown>) => fn()),
}));

// Encryption and the monitor barrel are import-time heavy (the monitor barrel is
// broken under this harness too) and unrelated to the contract; stub them.
vi.mock("@langfuse/shared/encryption", () => ({
  decrypt: vi.fn(() => "signing-secret"),
  createSignatureHeader: vi.fn(() => "t=1,v1=sig"),
}));

vi.mock("@langfuse/shared/monitors/server", () => ({
  MonitorWebhookQueueEventSchema: {
    safeParse: vi.fn((payload: unknown) => ({ success: true, data: payload })),
  },
  buildMonitorAlertSlackMessage: vi.fn(),
}));

// The slack message builder transitively pulls broken modules at import; the
// WEBHOOK delivery path never invokes it, so a stub keeps the import graph clean.
vi.mock("../features/slack/slackMessageBuilder", () => ({
  SlackMessageBuilder: class {},
}));

// Prisma: capture the ERROR-row write so we can inspect the stored error text.
vi.mock("@langfuse/shared/src/db", () => ({
  prisma: {
    $transaction: vi.fn(async (cb: any) =>
      cb({
        automationExecution: { update: h.executionUpdate },
        trigger: { update: h.triggerUpdate },
      }),
    ),
    automationExecution: { update: vi.fn(async () => undefined) },
  },
  Prisma: {},
}));

// Worker env: only the two fields the delivery path reads.
vi.mock("../env", () => ({
  env: {
    LANGFUSE_WEBHOOK_TIMEOUT_MS: 10_000,
    LANGFUSE_WEBHOOK_MAX_REDIRECTS: 5,
  },
}));

// Logger spies + the handful of repository reads the delivery path makes; every
// other shared/server export (buildWebhookOutboundPayload's schema, constants,
// etc.) stays intact via importOriginal — the same seam the egress suite uses.
vi.mock("@langfuse/shared/src/server", async (importOriginal) => {
  const actual =
    await importOriginal<typeof import("@langfuse/shared/src/server")>();
  return {
    ...actual,
    logger: h.logger,
    fetchWithSecureRedirects: h.fetchWithSecureRedirects,
    whitelistFromEnv: vi.fn(() => ({ hosts: [], ips: [], ip_ranges: [] })),
    validateWebhookURL: vi.fn(async () => undefined),
    buildWebhookRequestHeaders: vi.fn(() => ({
      headers: { "content-type": "application/json" },
      sensitiveHeaderNames: [],
    })),
    getConsecutiveAutomationFailures: vi.fn(async () => 0),
    getAutomationById: vi.fn(async () => ({
      id: "automation-1",
      name: "Test Automation",
      trigger: { id: "trigger-1" },
      action: { id: "action-1", type: "WEBHOOK" },
    })),
    getActionByIdWithSecrets: vi.fn(async () => ({
      id: "action-1",
      type: "WEBHOOK",
      config: {
        type: "WEBHOOK",
        url: "https://host.example/hook/path?sig=super-secret-sig",
        requestHeaders: {},
        displayHeaders: {},
        secretKey: "enc",
        displaySecretKey: "sec***",
        apiVersion: { prompt: "v1", "project-notification": "v1" },
      },
    })),
    ProjectNotificationWebhookQueueEventSchema: {
      safeParse: vi.fn((payload: unknown) => ({ success: true, data: payload })),
    },
    redis: undefined,
  };
});

// Imported after mocks are registered.
import { executeWebhook } from "../queues/webhooks";

// A project-notification delivery (no auto-disable branch) with the signed URL
// baked into the action config above. skipValidation is intentionally OMITTED so
// the redirect-validation branch — where the fix threads its per-address attempt
// window — actually runs.
function deliveryInput() {
  return {
    projectId: "project-1",
    automationId: "automation-1",
    executionId: "execution-1",
    payload: {
      type: "project-notification",
      apiVersion: "v1",
      event: {
        eventType: "blob-export-failed",
        severity: "ALERT",
        projectId: "project-1",
        projectName: "Test Project",
        resourceId: "resource-1",
        resourceName: "bucket-1",
        message: "Blob storage export failed.",
      },
    },
  };
}

// Every string a structured logger could emit across all its calls, walked
// depth-first through strings, errors (name/message/stack/cause), arrays, and
// plain objects — the same surface winston copies into a JSON log line.
function allLoggedText(): string {
  const parts: string[] = [];
  const visit = (value: unknown, depth: number): void => {
    if (value == null || depth > 6) return;
    if (
      typeof value === "string" ||
      typeof value === "number" ||
      typeof value === "boolean"
    ) {
      parts.push(String(value));
      return;
    }
    if (value instanceof Error) {
      parts.push(value.name, value.message, String(value.stack ?? ""));
      visit((value as Error & { cause?: unknown }).cause, depth + 1);
      return;
    }
    if (Array.isArray(value)) {
      value.forEach((entry) => visit(entry, depth + 1));
      return;
    }
    if (typeof value === "object") {
      Object.values(value as Record<string, unknown>).forEach((entry) =>
        visit(entry, depth + 1),
      );
    }
  };
  for (const level of [
    h.logger.info,
    h.logger.warn,
    h.logger.error,
    h.logger.debug,
  ]) {
    level.mock.calls.forEach((call) => call.forEach((arg) => visit(arg, 0)));
  }
  return parts.join("\n");
}

// Any numeric value anywhere in an options object that exceeds a threshold.
function hasNumberAbove(value: unknown, threshold: number, depth = 0): boolean {
  if (value == null || depth > 6) return false;
  if (typeof value === "number") return value > threshold;
  if (Array.isArray(value)) {
    return value.some((entry) => hasNumberAbove(entry, threshold, depth + 1));
  }
  if (typeof value === "object") {
    return Object.values(value as Record<string, unknown>).some((entry) =>
      hasNumberAbove(entry, threshold, depth + 1),
    );
  }
  return false;
}

describe("worker webhook delivery — redaction + wire + timeout contract", () => {
  beforeEach(() => {
    h.logger.info.mockClear();
    h.logger.warn.mockClear();
    h.logger.error.mockClear();
    h.logger.debug.mockClear();
    h.fetchWithSecureRedirects.mockClear();
    h.executionUpdate.mockClear();
  });

  // GAP 1 — FAIL-TO-PASS. The signed secret must not reach any logger call or
  // the stored execution error, while the destination stays recognizable.
  it("keeps the signed secret out of every log and stored error", async () => {
    await executeWebhook(deliveryInput());

    const logged = allLoggedText();
    expect(logged).not.toContain(SECRET);

    // Non-vacuous: the failed delivery really did write an error row.
    expect(h.executionUpdate).toHaveBeenCalled();
    const storedError = String(
      h.executionUpdate.mock.calls[0]?.[0]?.data?.error ?? "",
    );
    expect(storedError).not.toContain(SECRET);

    // Don't scrub so hard operators can't tell which destination failed: the
    // host must still be recognizable somewhere in the logs.
    expect(logged).toContain(DEST_HOST);
  });

  // GAP 2 — over-redaction guard (passes before and after the fix; fails only a
  // solution that redacts the URL on the actual request). The outbound request
  // itself must carry the full, unmodified URL so the receiver can authenticate.
  it("sends the full unmodified URL on the wire", async () => {
    await executeWebhook(deliveryInput());

    expect(h.fetchWithSecureRedirects).toHaveBeenCalled();
    const wireUrl = h.fetchWithSecureRedirects.mock.calls[0]?.[0];
    expect(wireUrl).toBe(DELIVERY_URL);
    expect(String(wireUrl)).toContain(SECRET);
  });

  // GAP 3 — FAIL-TO-PASS. The webhook delivery path must request a per-address
  // connection-attempt window above Node's 250ms default, threaded through the
  // outbound-fetch options. A redaction-only (or plumbing-without-wiring)
  // solution threads no such window and fails here.
  it("requests a per-address attempt window above the runtime default", async () => {
    await executeWebhook(deliveryInput());

    expect(h.fetchWithSecureRedirects).toHaveBeenCalled();
    const outboundOptions = h.fetchWithSecureRedirects.mock.calls[0]?.[2];
    expect(outboundOptions).toBeDefined();
    expect(
      hasNumberAbove(outboundOptions, NODE_DEFAULT_ATTEMPT_TIMEOUT_MS),
    ).toBe(true);
  });
});
