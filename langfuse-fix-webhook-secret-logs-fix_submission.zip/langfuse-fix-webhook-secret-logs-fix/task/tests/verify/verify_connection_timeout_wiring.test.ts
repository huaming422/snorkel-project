// @ts-nocheck
//
// Behavioral verifier for the SECOND half of this task's contract: the
// intermittent early connection timeout. base.md names it as a co-equal
// requirement ("dig into both and fix"). The redaction half is already gated by
// the two sibling verifier suites; this file closes the reward hole where a
// redaction-only (or materially-wrong-timeout) solution would otherwise score
// correctness 1.0 because nothing deterministic gates the timeout wiring.
//
// WHAT IS UNDER TEST — the OBSERVABLE pooling behavior, not an option name.
// The shared outbound layer reuses one undici Agent per distinct connection
// policy, keyed by `getConnectionValidationPolicyKey`. The correct timeout fix
// raises a per-address connection-attempt window for webhook deliveries and
// INCLUDES that window in the pool key — because the Agent fixes the window at
// construction time, a pool keyed without it would hand back an Agent built with
// the old (too-short) window. The two materially-worse solutions the contract
// rejects both bake a timeout into the SHARED Agent with NO pool-key change, so
// every caller shares one Agent regardless of the requested window.
//
// The discriminator is therefore: two sets of connection-validation options
// that differ ONLY in a per-address attempt-timeout value must resolve to
// DISTINCT pooled dispatchers. A correctly-keyed implementation (per-call option
// or webhook-scoped constant — both flow the value through the options object)
// yields two Agents; a global/unkeyed implementation yields one.
//
// IMPLEMENTATION-AGNOSTIC BY CONSTRUCTION:
//   - It rides the PRE-EXISTING exported entry point
//     `addSecureOutboundConnectionValidation`, whose returned `.dispatcher` is
//     the pooled Agent. It imports no symbol the solution must invent and does
//     not touch the non-exported pool-key/dispatcher internals directly.
//   - It does NOT pin the oracle's field name or constant. It sprays every
//     plausible per-address-timeout field name at once; a solution that keys on
//     ANY ONE of them produces distinct dispatchers and passes. Only a solution
//     that keys on NONE (i.e. a global, unkeyed timeout) fails.
//   - It asserts instance identity, never a numeric value or wiring shape.

import { describe, expect, it } from "vitest";
import { addSecureOutboundConnectionValidation } from "./connection";

// A fixed, normalized whitelist + logContext so the ONLY thing that can vary the
// pool key between calls is the per-address timeout field. Reusing the same
// values keeps every call in this file on one policy except for the timeout.
const WHITELIST = { hosts: [], ips: [], ip_ranges: [] };
const LOG_CONTEXT = "Outbound URL";

// Every plausible name a solution might give the per-address connection-attempt
// timeout it threads through the connection-validation options. The oracle uses
// `addressAttemptTimeoutMs`; observed frontier variants use `connectTimeoutMs` /
// `autoSelectFamilyAttemptTimeoutMs`. Spraying all of them at a single value
// means any correctly-keyed solution — whatever it named the field — produces a
// distinct key when the value changes. A global/unkeyed solution ignores all of
// them and produces the same key either way.
function optionsWithAttemptTimeout(valueMs: number) {
  const timeoutFields = {
    addressAttemptTimeoutMs: valueMs,
    autoSelectFamilyAttemptTimeout: valueMs,
    autoSelectFamilyAttemptTimeoutMs: valueMs,
    connectTimeoutMs: valueMs,
    connectTimeout: valueMs,
    attemptTimeout: valueMs,
    attemptTimeoutMs: valueMs,
    perAddressTimeout: valueMs,
    perAddressTimeoutMs: valueMs,
    perAddressAttemptTimeout: valueMs,
    perAddressAttemptTimeoutMs: valueMs,
    connectionAttemptTimeout: valueMs,
    connectionAttemptTimeoutMs: valueMs,
  };
  return { whitelist: WHITELIST, logContext: LOG_CONTEXT, ...timeoutFields };
}

// The pooled dispatcher for a given set of validation options, pulled off the
// pre-existing public entry point exactly as a caller obtains it.
function dispatcherFor(validationOptions: object) {
  const result = addSecureOutboundConnectionValidation({}, validationOptions) as {
    dispatcher?: unknown;
  };
  return result.dispatcher;
}

// Two per-address attempt-timeout values that are both reasonable windows (so a
// solution that clamps to a sane range cannot collapse them) yet distinct.
const SHORT_WINDOW_MS = 1500;
const LONG_WINDOW_MS = 3000;

describe("outbound connection pool — per-address attempt-timeout wiring", () => {
  // PASS-TO-PASS invariant that makes the identity comparisons below meaningful:
  // the layer really pools, so two calls with IDENTICAL options return the SAME
  // dispatcher instance. Holds before and after the fix. Without this, a broken
  // "fresh Agent every call" layer would make the f2p check pass vacuously.
  it("returns the same pooled dispatcher for identical options", () => {
    const first = dispatcherFor(optionsWithAttemptTimeout(SHORT_WINDOW_MS));
    const second = dispatcherFor(optionsWithAttemptTimeout(SHORT_WINDOW_MS));
    expect(first).toBeDefined();
    expect(second).toBe(first);
  });

  // FAIL-TO-PASS, basic_functionality.
  // Options that differ ONLY in the per-address attempt-timeout value must
  // resolve to DISTINCT pooled dispatchers — i.e. the timeout is part of the
  // pool key. A webhook-scoped widening whose value is baked into the shared
  // Agent without a pool-key change (the two rejected non-fixes) returns the
  // same instance here and fails.
  it("keys the pool on the per-address attempt timeout (distinct values -> distinct dispatchers)", () => {
    const shortWindow = dispatcherFor(optionsWithAttemptTimeout(SHORT_WINDOW_MS));
    const longWindow = dispatcherFor(optionsWithAttemptTimeout(LONG_WINDOW_MS));
    expect(shortWindow).toBeDefined();
    expect(longWindow).toBeDefined();
    expect(longWindow).not.toBe(shortWindow);
  });
});
