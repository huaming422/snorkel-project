#!/usr/bin/env bash
# Environment bootstrap for the verifier.
#
# Sourced (not exec'd) by the harbor runner so env vars exported here stay live
# for the verifier subprocess.
#
# The behavioral surface is two vitest suites, both fully offline:
#   - a suite under packages/shared (shared layer, relative `./` imports)
#   - a suite under worker/src (worker egress boundary)
# Both run under vitest, which transpiles TypeScript on the fly.
#
# The shared-layer suite reaches its neighbours through relative `./` imports, so
# it needs no package build. The worker suite imports the shared package across
# the workspace boundary (`@langfuse/shared/src/server`), whose package exports
# resolve to the built `dist/`. The database client that the shared type surface
# re-exports is generated at image-build time (where the network is available);
# the package `dist/` is NOT, because the solution edits shared source and a
# baked `dist/` would be stale. So this script rebuilds `dist/` from the current
# source on every run. The build invokes the TypeScript compiler through the
# already-installed toolchain (`pnpm exec`, not `npx`/install), reads only local
# source plus the pre-baked dependency store, touches neither the network nor a
# datastore, and completes in a few seconds.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/langfuse}"
export REPO_DIR
cd "$REPO_DIR"

# ---------------------------------------------------------------------------
# Import-time environment. langfuse's shared `env.ts` (pulled in transitively by
# logger.ts, which the outbound-url layer imports) validates a handful of
# required variables at module-load time via zod and THROWS if they are absent.
# The focused redaction/timing tests never touch ClickHouse or S3 — these are
# throwaway values that only satisfy the import-time schema. The package test
# scripts normally load these from a `.env` that is NOT present in the task
# image, so the verifier must export them itself and invoke vitest directly
# (node_modules/.bin/vitest) rather than through the `dotenv -e ../../.env`
# wrapper script.
# ---------------------------------------------------------------------------
export NODE_ENV="${NODE_ENV:-test}"
export CLICKHOUSE_URL="${CLICKHOUSE_URL:-http://localhost:8123}"
export CLICKHOUSE_USER="${CLICKHOUSE_USER:-default}"
export CLICKHOUSE_PASSWORD="${CLICKHOUSE_PASSWORD:-notused}"
export CLICKHOUSE_CLUSTER_ENABLED="${CLICKHOUSE_CLUSTER_ENABLED:-false}"
export LANGFUSE_S3_EVENT_UPLOAD_BUCKET="${LANGFUSE_S3_EVENT_UPLOAD_BUCKET:-notused}"
export DATABASE_URL="${DATABASE_URL:-postgresql://notused:notused@localhost:5432/notused}"
export SALT="${SALT:-notused}"
export ENCRYPTION_KEY="${ENCRYPTION_KEY:-0000000000000000000000000000000000000000000000000000000000000000}"
export NEXTAUTH_SECRET="${NEXTAUTH_SECRET:-notused}"
export NEXTAUTH_URL="${NEXTAUTH_URL:-http://localhost:3000}"
export REDIS_CONNECTION_STRING="${REDIS_CONNECTION_STRING:-redis://localhost:6379}"

# Dependencies are baked into the image at the base commit (offline-first). In a
# pnpm workspace each package links its own tool binaries under
# `<package>/node_modules/.bin`, not at the repository root, so the presence probe
# targets the shared package's vitest binary. If the store is somehow cold (cache
# wipe), fall back to a logged offline re-link, then a logged online install.
if ! [ -x packages/shared/node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing — reinstalling, offline-first." >&2
    # Offline-first: the image bakes the whole closure into the pnpm store, so a
    # cold node_modules re-links from the store with no network. Only if that
    # fails do we fall back to a logged online install.
    pnpm install --offline --frozen-lockfile --ignore-scripts > /tmp/setup-install.log 2>&1 \
        || { echo "test-setup.sh: offline install failed; retrying online." >&2; \
             pnpm install --frozen-lockfile --ignore-scripts > /tmp/setup-install.log 2>&1; } \
        || { tail -80 /tmp/setup-install.log; exit 1; }
fi

# ---------------------------------------------------------------------------
# Cross-package resolution. The worker suite imports the shared package through
# its published `exports` map, which resolves to the built `dist/`. The solution
# edits shared source, so `dist/` is rebuilt here from the current tree on every
# run (an unconditional build — never trust a pre-baked `dist/`, which would hide
# the solution's edits). The compiler is invoked through `pnpm exec` so it uses
# the already-installed toolchain with no `npx`/registry access; it reads only
# local source plus the generated database client baked into the image at build
# time, so it stays fully offline and finishes in a few seconds.
#
# `--noEmitOnError false`: the shared package's `src/server/topics/` and a few
# util modules reference Prisma-client types (LlmApiKeys, TopicConfig, Prisma,
# Organization, PrismaClient, JobConfigState) that were added to the schema
# AFTER this task's base commit, so strict tsc reports TS2305/TS2459/TS7006
# against them. Those modules are NOT on the verifier's import path — the two
# suites reach only `outbound-url/` and the worker egress boundary — so their
# type errors must not block the emit. With this flag tsc writes the full
# `dist/` (all 800+ JS files, including the modules the verifier does need)
# despite the non-zero exit, so we key success on the presence of the emitted
# entry points, not on tsc's exit code.
# ---------------------------------------------------------------------------
pnpm --filter @langfuse/shared exec tsc --noEmitOnError false \
    > /tmp/setup-sharedbuild.log 2>&1 || true
if ! [ -f packages/shared/dist/src/server/index.js ] \
   || ! [ -f packages/shared/dist/src/db.js ]; then
    echo "test-setup.sh: shared package build did not emit dist/." >&2
    tail -60 /tmp/setup-sharedbuild.log
    exit 1
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR node=$(node --version) vitest=$(packages/shared/node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
