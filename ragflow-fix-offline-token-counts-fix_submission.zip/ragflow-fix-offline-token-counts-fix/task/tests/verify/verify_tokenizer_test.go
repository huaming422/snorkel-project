//
//  Copyright 2026 The InfiniFlow Authors. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

// This file is copied into internal/tokenizer/ and run with the network cut and
// the cl100k_base table already present on disk where RAGFlow ships it. It
// exercises the package through its pre-existing public entry point,
// NumTokensFromString, and asserts the exact token count for a corpus of
// strings. It references no symbol introduced by a fix, so it is agnostic to
// how any particular solution wires the table to the encoder.
//
// The counts below are objective properties of the cl100k_base encoding (a
// fixed, published tokenization), independently reproducible with Python's
// tiktoken over the same strings. Exact values are the point: NumTokensFromString
// returns 0 both for an empty string and when the encoder cannot be built, so a
// "greater than zero" assertion would be satisfied by a non-working encoder and
// by a structurally valid but wrong table. Pinning the numbers detects both.

package tokenizer

import "testing"

func TestVerifyOfflineTokenAnchors(t *testing.T) {
	anchors := []struct {
		in   string
		want int
	}{
		{"", 0},
		{"hello", 1},
		{"hello world", 2},
		{"hello, world!", 4},
		{"世界", 3},
		{"Hello 世界 🌍", 8},
		{"RAGFlow", 3},
		{"1234567890", 4},
		{"a  b", 3},
		{"hello\nworld", 3},
		{"user@example.com", 3},
		{"https://example.com/path?x=1", 9},
		{"func main() {}", 4},
		{"aaaaaaaaaa", 2},
		{"中文字符测试", 4},
		{"🚀🔥", 6},
		{"state-of-the-art", 4},
		{`"quoted"`, 3},
		{"The quick brown fox jumps over the lazy dog.", 10},
		{"Café naïve résumé", 8},
		{"x² + y² = z²", 8},
		{"混合 English 和 中文 的 sentence。", 10},
		{"tokenization is the process of splitting text into tokens", 10},
		{"人工智能正在改变世界，这是毫无疑问的事实。", 25},
		{"SELECT * FROM users WHERE id = 1;", 10},
		{"こんにちは世界", 4},
	}
	for _, tc := range anchors {
		if got := NumTokensFromString(tc.in); got != tc.want {
			t.Errorf("NumTokensFromString(%q) = %d, want %d", tc.in, got, tc.want)
		}
	}
}
