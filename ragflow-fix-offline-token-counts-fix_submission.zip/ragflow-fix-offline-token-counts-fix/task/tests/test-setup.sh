# Sourced by the verifier runner before the Go tests execute. The toolchain and
# the full module cache come from the image (baked at build time); this only
# exports a deterministic, offline Go environment. No dependency-resolving
# command runs here — `go mod download` already ran in the image.

set -euo pipefail

cd /repo/ragflow

# Build the tokenizer package and its tests with no C++ toolchain: the package
# reaches C only through internal/binding, which has a //go:build !cgo stub.
export CGO_ENABLED="0"
export GOTOOLCHAIN="local"
# Offline-first: the module cache is warm from the image; fail fast on a miss
# instead of hitting a dead network.
export GOFLAGS="-mod=mod"
export GOPROXY="off"
export GOCACHE="${GOCACHE:-/root/.cache/go-build}"
export GOMODCACHE="${GOMODCACHE:-/root/go/pkg/mod}"
mkdir -p "$GOCACHE" "$GOMODCACHE"
