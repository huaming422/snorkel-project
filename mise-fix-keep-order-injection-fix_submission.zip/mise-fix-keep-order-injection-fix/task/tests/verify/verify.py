"""Behavioral verifier for mise-fix-keep-order-injection.

`mise run --output keep-order` is supposed to collect each task's output into
one contiguous block and emit the blocks in a stable, declaration-derived
order, so that *which* task happens to print first never changes the result.
That held for tasks named directly on the command line, but not for tasks a
run entry pulls in: a parent whose `run` starts other tasks, and the tasks
those reach through `depends` / `depends_post`. Their blocks landed wherever
their first line happened to arrive, so the order drifted from one run to the
next and disagreed with running the same tasks directly by name.

This verifier drives the compiled `mise` command-line tool — the pre-existing,
stable interface where the behavior is observable — and asserts the *invariants*
the behavior must hold to, never a particular block order or any internal
detail of how the tool reaches it:

  * the pulled-in form produces the same block order as the by-name form, for
    both `depends` and `depends_post`;
  * that order is the same on every run of the same config;
  * parents that each print and start a child order their blocks the same way on
    every run, since the position comes from their declared slots rather than
    from which parent injected its child first;
  * the same holds when injection is nested — a started child that itself prints
    and starts a further task;
  * a parent that only aggregates dependencies does not freeze the live stream;
  * a dependency shared between two pulled-in tasks runs once and does not stall
    the stream.

The task configs below (task names, sleep durations, job count) are test
fixtures authored here, mirroring the reasoning of the project's own end-to-end
coverage. Which specific order is "the" right one, and the finest grouping of
nested injections, are design questions the behavior deliberately leaves open —
so nothing here pins a literal order; equality and stability are what is
asserted.

The tool is a Rust binary. This verifier never imports or inspects the
repository's source; it builds the binary once and then only observes its
command-line output. It therefore runs under the shared verifier interpreter
with no repository-Python dependency.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

import pytest

# Where the repository is checked out in the task image.
REPO_DIR = Path(f"/repo/{os.environ.get('REPO_NAME', 'mise')}")

# Parallelism high enough for the ordering defect to surface: with a single job
# the work serializes and the drift cannot reproduce.
JOBS = "4"

# Per-invocation wall-clock ceiling. Every config here finishes in a couple of
# seconds; a run that blows past this has frozen the live stream, which is one
# of the failures under test. Kept well under the verifier timeout so a stall
# surfaces as a clean assertion rather than a runner-level timeout.
RUN_TIMEOUT = 60

# A block line looks like `[task-name] some output`. Capture the task name.
_BLOCK_RE = re.compile(r"^\[([A-Za-z0-9_.:-]+)\]")

# How many times a determinism check runs the same config. The ordering drift is
# probabilistic, so a few runs can agree by luck; this many makes an unstable
# ordering show up essentially every time while an actually-stable one stays
# identical throughout. Measured on the reference fix (stable across hundreds of
# runs) and on partial fixes that leave the injected blocks unslotted (which
# produce several distinct orders within the first handful of runs).
DETERMINISM_RUNS = 20


# --------------------------------------------------------------------------- #
# Building and running the tool
# --------------------------------------------------------------------------- #


@pytest.fixture(scope="module")
def mise_bin() -> str:
    """Build the `mise` binary once from the checked-out source and return its
    path. The image pre-fetches the full dependency closure and pre-builds the
    binary, so this rebuild from the (possibly patched) source is incremental
    and fully offline."""
    env = {**os.environ, "CARGO_NET_OFFLINE": "true"}
    proc = subprocess.run(
        ["cargo", "build", "--bin", "mise"],
        cwd=str(REPO_DIR),
        env=env,
        capture_output=True,
        text=True,
        timeout=1500,
        check=False,
    )
    assert proc.returncode == 0, (
        "failed to build the mise binary from source:\n"
        f"{proc.stdout[-4000:]}\n{proc.stderr[-4000:]}"
    )

    candidates = []
    target_dir = os.environ.get("CARGO_TARGET_DIR")
    if target_dir:
        candidates.append(Path(target_dir) / "debug" / "mise")
    candidates.append(REPO_DIR / "target" / "debug" / "mise")

    for cand in candidates:
        if cand.is_file() and os.access(cand, os.X_OK):
            return str(cand)

    # Fallback: locate it under the cache tree.
    found = subprocess.run(
        ["find", "/opt/cache", "-name", "mise", "-type", "f", "-executable"],
        capture_output=True,
        text=True,
        check=False,
    )
    for line in found.stdout.splitlines():
        line = line.strip()
        if line.endswith("/debug/mise"):
            return line

    raise AssertionError(
        "built the project but could not locate the resulting `mise` binary; "
        f"looked at: {', '.join(str(c) for c in candidates)}"
    )


def _run(mise_bin: str, workdir: Path, *args: str) -> subprocess.CompletedProcess:
    """Run `mise <args>` in an isolated, trusted workspace and capture the
    combined stdout+stderr stream (keep-order writes task output to stderr)."""
    home = workdir / "home"
    for sub in (
        home,
        home / ".local/share/mise",
        home / ".cache/mise",
        home / ".config/mise",
        home / ".local/state/mise",
    ):
        sub.mkdir(parents=True, exist_ok=True)

    env = {
        "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
        "HOME": str(home),
        "MISE_DATA_DIR": str(home / ".local/share/mise"),
        "MISE_CACHE_DIR": str(home / ".cache/mise"),
        "MISE_CONFIG_DIR": str(home / ".config/mise"),
        "MISE_STATE_DIR": str(home / ".local/state/mise"),
        "MISE_TRUSTED_CONFIG_PATHS": str(workdir),
        "MISE_YES": "1",
        "MISE_EXPERIMENTAL": "1",
        "MISE_JOBS": JOBS,
        "MISE_USE_VERSIONS_HOST": "0",
    }
    if "CARGO_HOME" in os.environ:
        env["CARGO_HOME"] = os.environ["CARGO_HOME"]
    if "RUSTUP_HOME" in os.environ:
        env["RUSTUP_HOME"] = os.environ["RUSTUP_HOME"]

    return subprocess.run(
        [mise_bin, *args],
        cwd=str(workdir),
        env=env,
        capture_output=True,
        text=True,
        timeout=RUN_TIMEOUT,
        check=False,
    )


def _keep_order(mise_bin: str, workdir: Path, *run_args: str) -> subprocess.CompletedProcess:
    """`mise run --quiet --output keep-order <run_args>` with combined output."""
    return _run(mise_bin, workdir, "run", "--quiet", "--output", "keep-order", *run_args)


def _block_order(output: str) -> list[str]:
    """The order task-output blocks appear in, as the sequence of distinct
    `[name]` prefixes with consecutive repeats collapsed. keep-order guarantees
    each task's lines are contiguous, so this is exactly the block order."""
    order: list[str] = []
    for line in output.splitlines():
        m = _BLOCK_RE.match(line)
        if not m:
            continue
        name = m.group(1)
        if not order or order[-1] != name:
            order.append(name)
    return order


def _write_config(workdir: Path, toml: str) -> None:
    (workdir / "mise.toml").write_text(toml, encoding="utf-8")


def _fresh_workdir() -> Path:
    return Path(tempfile.mkdtemp(prefix="mise-keep-order-"))


# --------------------------------------------------------------------------- #
# Config fixtures (test data authored here; not derived from any solution)
# --------------------------------------------------------------------------- #

# A parent whose only job is to start three tasks, each carrying its own
# `depends`. The sleeps are inverted relative to declaration order so that, with
# the dependencies landing in finish order, the pulled-in form is wrong every
# run rather than only sometimes.
CONFIG_DEPENDS = """\
[tasks.launch]
run = { tasks = ["r1", "r2", "r3"] }

[tasks.r1]
depends = ["dep1"]
run = 'echo R1'

[tasks.r2]
depends = ["dep2"]
run = 'echo R2'

[tasks.r3]
depends = ["dep3"]
run = 'echo R3'

[tasks.dep1]
run = 'echo DEP1'

[tasks.dep2]
run = 'sleep 0.5; echo DEP2'

[tasks.dep3]
run = 'sleep 1; echo DEP3'
"""

# The same shape with no artificial delays: the dependencies then finish in
# whatever order the scheduler started them, which is what made the original
# report intermittent.
CONFIG_DEPENDS_SLEEPLESS = """\
[tasks.launch]
run = { tasks = ["r1", "r2", "r3"] }

[tasks.r1]
depends = ["dep1"]
run = 'echo R1'

[tasks.r2]
depends = ["dep2"]
run = 'echo R2'

[tasks.r3]
depends = ["dep3"]
run = 'echo R3'

[tasks.dep1]
run = 'echo DEP1'

[tasks.dep2]
run = 'echo DEP2'

[tasks.dep3]
run = 'echo DEP3'
"""

# `depends_post` arrives through the same path. One post task sleeps so that,
# unslotted, its block lands out of place.
CONFIG_DEPENDS_POST = """\
[tasks.launch]
run = { tasks = ["p1", "p2"] }

[tasks.p1]
depends_post = ["post1"]
run = 'echo P1'

[tasks.p2]
depends_post = ["post2"]
run = 'echo P2'

[tasks.post1]
run = 'echo POST1'

[tasks.post2]
run = 'sleep 0.5; echo POST2'
"""

# Three parents that each print their own output and start a child. No artificial
# delays: the child each parent starts prints nothing to force a particular
# finish order, so whether the blocks come out in a stable, declaration-derived
# order or in whatever order the parents happened to inject their children is
# exactly what varies run to run when the injected blocks have no reserved slot.
# A single-level print-and-inject shape; `test_printing_parents_order_is_stable`
# runs it many times and checks the order never changes.
CONFIG_PRINTING_PARENTS = """\
[tasks.p1]
run = ["echo P1-START", { tasks = ["c1"] }, "echo P1-END"]

[tasks.p2]
run = ["echo P2-START", { tasks = ["c2"] }, "echo P2-END"]

[tasks.p3]
run = ["echo P3-START", { tasks = ["c3"] }, "echo P3-END"]

[tasks.c1]
run = 'echo C1'

[tasks.c2]
run = 'echo C2'

[tasks.c3]
run = 'echo C3'
"""

# The nested shape: each printing parent starts a child that *itself* prints and
# starts a further task. The injected tasks are two levels deep, so a fix that
# only slots the directly-named-in-a-run-entry tasks (or reuses an order that is
# scrambled once the graph prunes/removes a node) leaves the deeper blocks to
# land wherever their first line arrives — a different order each run.
# `test_nested_injection_order_is_stable` runs it many times and checks the order
# never changes.
CONFIG_NESTED_INJECTION = """\
[tasks.p1]
run = ["echo P1-START", { tasks = ["c1"] }, "echo P1-END"]

[tasks.p2]
run = ["echo P2-START", { tasks = ["c2"] }, "echo P2-END"]

[tasks.p3]
run = ["echo P3-START", { tasks = ["c3"] }, "echo P3-END"]

[tasks.c1]
run = ["echo C1-START", { tasks = ["g1"] }, "echo C1-END"]

[tasks.c2]
run = ["echo C2-START", { tasks = ["g2"] }, "echo C2-END"]

[tasks.c3]
run = ["echo C3-START", { tasks = ["g3"] }, "echo C3-END"]

[tasks.g1]
run = 'echo G1'

[tasks.g2]
run = 'echo G2'

[tasks.g3]
run = 'echo G3'
"""

# A parent that produces no output of its own and only aggregates dependencies.
# It finishes last; it must not be given a front-of-stream position that would
# hold back everything it waits on.
CONFIG_AGGREGATOR = """\
[tasks.agg]
depends = ["w1", "w2", "w3"]

[tasks.w1]
run = 'echo W1'

[tasks.w2]
run = 'sleep 0.3; echo W2'

[tasks.w3]
run = 'sleep 0.6; echo W3'
"""

# Three directly-named tasks whose names are deliberately out of alphabetical
# order. Running them by name must keep them in the order they were named: this
# is keep-order's long-standing guarantee for directly-named tasks and the
# reference every pulled-in form is compared against. A fix that "stabilises" the
# order by sorting on a fixed key (task name, say) would reorder these and is
# rejected here — such a sort can look stable yet never matches the declared
# order for an arbitrary set.
CONFIG_NAMED_ORDER = """\
[tasks.zebra]
run = 'echo ZEBRA'

[tasks.apple]
run = 'echo APPLE'

[tasks.mango]
run = 'echo MANGO'
"""

# Two pulled-in tasks that share a dependency. The shared task runs once; when
# the second task's sub-graph is built the shared task is already complete and
# is pruned. A pruned task never runs, so it must not be left holding a slot.
CONFIG_SHARED_DEP = """\
[tasks.launch]
run = { tasks = ["a", "b"] }

[tasks.a]
depends = ["shared"]
run = 'echo A'

[tasks.b]
depends = ["shared"]
run = 'echo B'

[tasks.shared]
run = 'echo SHARED'
"""


# --------------------------------------------------------------------------- #
# Tests
# --------------------------------------------------------------------------- #


def test_injected_depends_match_toplevel_form(mise_bin: str) -> None:
    """A parent that starts tasks carrying their own `depends` must produce the
    same block order as running those tasks directly by name."""
    workdir = _fresh_workdir()
    try:
        _write_config(workdir, CONFIG_DEPENDS)

        injected = _keep_order(mise_bin, workdir, "launch")
        assert injected.returncode == 0, (
            f"`mise run launch` failed (exit {injected.returncode}):\n"
            f"{injected.stdout}\n{injected.stderr}"
        )
        toplevel = _keep_order(mise_bin, workdir, "r1", ":::", "r2", ":::", "r3")
        assert toplevel.returncode == 0, (
            f"by-name run failed (exit {toplevel.returncode}):\n"
            f"{toplevel.stdout}\n{toplevel.stderr}"
        )

        injected_order = _block_order(injected.stdout + injected.stderr)
        toplevel_order = _block_order(toplevel.stdout + toplevel.stderr)

        assert injected_order, f"no task blocks seen for the pulled-in form:\n{injected.stdout}\n{injected.stderr}"
        assert toplevel_order, f"no task blocks seen for the by-name form:\n{toplevel.stdout}\n{toplevel.stderr}"
        assert injected_order == toplevel_order, (
            "the pulled-in form ordered its blocks differently from the by-name "
            "form for the same task set:\n"
            f"  pulled in via a run entry: {injected_order}\n"
            f"  named directly:           {toplevel_order}"
        )
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def test_injected_depends_order_is_deterministic(mise_bin: str) -> None:
    """Repeated runs of the same config must produce the same block order."""
    workdir = _fresh_workdir()
    try:
        _write_config(workdir, CONFIG_DEPENDS_SLEEPLESS)

        orders: list[list[str]] = []
        for i in range(6):
            res = _keep_order(mise_bin, workdir, "launch")
            assert res.returncode == 0, (
                f"run {i + 1} failed (exit {res.returncode}):\n{res.stdout}\n{res.stderr}"
            )
            order = _block_order(res.stdout + res.stderr)
            assert order, f"run {i + 1} produced no task blocks:\n{res.stdout}\n{res.stderr}"
            orders.append(order)

        first = orders[0]
        for i, order in enumerate(orders[1:], start=2):
            assert order == first, (
                f"run {i} reordered the blocks relative to the first run:\n"
                f"  run 1: {first}\n"
                f"  run {i}: {order}"
            )
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def test_depends_post_matches_toplevel_form(mise_bin: str) -> None:
    """`depends_post` tasks pulled in through a parent order the same as the
    by-name form."""
    workdir = _fresh_workdir()
    try:
        _write_config(workdir, CONFIG_DEPENDS_POST)

        injected = _keep_order(mise_bin, workdir, "launch")
        assert injected.returncode == 0, (
            f"`mise run launch` failed (exit {injected.returncode}):\n"
            f"{injected.stdout}\n{injected.stderr}"
        )
        toplevel = _keep_order(mise_bin, workdir, "p1", ":::", "p2")
        assert toplevel.returncode == 0, (
            f"by-name run failed (exit {toplevel.returncode}):\n"
            f"{toplevel.stdout}\n{toplevel.stderr}"
        )

        injected_order = _block_order(injected.stdout + injected.stderr)
        toplevel_order = _block_order(toplevel.stdout + toplevel.stderr)

        assert injected_order, f"no task blocks seen for the pulled-in form:\n{injected.stdout}\n{injected.stderr}"
        assert toplevel_order, f"no task blocks seen for the by-name form:\n{toplevel.stdout}\n{toplevel.stderr}"
        assert injected_order == toplevel_order, (
            "with `depends_post`, the pulled-in form ordered its blocks "
            "differently from the by-name form:\n"
            f"  pulled in via a run entry: {injected_order}\n"
            f"  named directly:           {toplevel_order}"
        )
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def test_printing_parents_order_is_stable(mise_bin: str) -> None:
    """Parents that each print their own output and start a child must order
    their blocks by their declared positions, not by which child's injection
    happened to land first.

    The race is in which parent reserves its injected child's position, and that
    is decided before any child runs — so putting an artificial delay inside the
    children does not exercise it. What does is running the same no-delay config
    many times: if the injected blocks have no reserved slot, the order they come
    out in follows whichever parent injected first and varies from one run to the
    next. A fix that gives every injected task a declaration-derived slot makes
    every run identical."""
    workdir = _fresh_workdir()
    try:
        _write_config(workdir, CONFIG_PRINTING_PARENTS)

        orders: list[list[str]] = []
        for i in range(DETERMINISM_RUNS):
            res = _keep_order(mise_bin, workdir, "p1", ":::", "p2", ":::", "p3")
            assert res.returncode == 0, (
                f"run {i + 1} failed (exit {res.returncode}):\n{res.stdout}\n{res.stderr}"
            )
            order = _block_order(res.stdout + res.stderr)
            assert order, f"run {i + 1} produced no task blocks:\n{res.stdout}\n{res.stderr}"
            orders.append(order)

        first = orders[0]
        for i, order in enumerate(orders[1:], start=2):
            assert order == first, (
                "two printing parents ordered their injected blocks by which "
                "parent injected first rather than by their declared positions — "
                f"run {i} differs from run 1:\n"
                f"  run 1: {first}\n"
                f"  run {i}: {order}"
            )
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def test_nested_injection_order_is_stable(mise_bin: str) -> None:
    """A printing parent whose started child itself prints and starts a further
    task — injection nested two levels deep — must come out in the same block
    order on every run.

    This is the recursive form of the contract: the deeper injected tasks are
    pulled in rather than named, so a fix that only reserves slots for the tasks
    named directly in a run entry (or that reuses a task ordering which is
    scrambled once the graph prunes a node) leaves those deeper blocks to land
    wherever their first line arrives, giving a different order each run. Only a
    fix that reserves a declaration-derived slot for every task in the whole
    pulled-in sub-graph holds the order stable here."""
    workdir = _fresh_workdir()
    try:
        _write_config(workdir, CONFIG_NESTED_INJECTION)

        orders: list[list[str]] = []
        for i in range(DETERMINISM_RUNS):
            res = _keep_order(mise_bin, workdir, "p1", ":::", "p2", ":::", "p3")
            assert res.returncode == 0, (
                f"run {i + 1} failed (exit {res.returncode}):\n{res.stdout}\n{res.stderr}"
            )
            order = _block_order(res.stdout + res.stderr)
            assert order, f"run {i + 1} produced no task blocks:\n{res.stdout}\n{res.stderr}"
            orders.append(order)

        first = orders[0]
        for i, order in enumerate(orders[1:], start=2):
            assert order == first, (
                "nested injected blocks came out in a different order across "
                f"runs — run {i} differs from run 1:\n"
                f"  run 1: {first}\n"
                f"  run {i}: {order}"
            )
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def test_aggregator_parent_does_not_stall_stream(mise_bin: str) -> None:
    """A parent that only aggregates dependencies must not freeze the live
    stream: the dependencies' output appears and the run completes promptly."""
    workdir = _fresh_workdir()
    try:
        _write_config(workdir, CONFIG_AGGREGATOR)

        try:
            res = _keep_order(mise_bin, workdir, "agg")
        except subprocess.TimeoutExpired:
            pytest.fail(
                "an aggregator-only parent held the keep-order stream: the run "
                f"did not finish within {RUN_TIMEOUT}s"
            )

        assert res.returncode == 0, (
            f"`mise run agg` failed (exit {res.returncode}):\n{res.stdout}\n{res.stderr}"
        )
        combined = res.stdout + res.stderr
        order = _block_order(combined)
        for dep in ("w1", "w2", "w3"):
            assert dep in order, (
                f"dependency block [{dep}] is missing from the aggregator run — "
                f"its output was held back:\n{combined}"
            )
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def test_shared_dependency_runs_once_and_does_not_stall(mise_bin: str) -> None:
    """A dependency shared by two pulled-in tasks runs once; the pruned second
    occurrence must not reappear or hold the stream."""
    workdir = _fresh_workdir()
    try:
        _write_config(workdir, CONFIG_SHARED_DEP)

        orders: list[list[str]] = []
        for i in range(2):
            try:
                res = _keep_order(mise_bin, workdir, "launch")
            except subprocess.TimeoutExpired:
                pytest.fail(
                    "a shared, already-complete dependency held the keep-order "
                    f"stream: run {i + 1} did not finish within {RUN_TIMEOUT}s"
                )
            assert res.returncode == 0, (
                f"run {i + 1} failed (exit {res.returncode}):\n{res.stdout}\n{res.stderr}"
            )
            combined = res.stdout + res.stderr
            order = _block_order(combined)
            assert order.count("shared") == 1, (
                "the shared dependency should produce exactly one block, but its "
                f"block order was: {order}\n{combined}"
            )
            for name in ("a", "b", "shared"):
                assert name in order, f"[{name}] missing from run {i + 1}:\n{combined}"
            orders.append(order)

        assert orders[0] == orders[1], (
            "the block order with a shared dependency varied between runs:\n"
            f"  run 1: {orders[0]}\n"
            f"  run 2: {orders[1]}"
        )
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def test_named_tasks_keep_command_line_order(mise_bin: str) -> None:
    """Tasks named directly on the command line come out in the order they were
    named — keep-order's standing guarantee and the reference every pulled-in
    form is measured against. This guards against a fix that manufactures
    stability by imposing a fixed sort (e.g. alphabetical by task name): such a
    sort would reorder these deliberately-unalphabetical names and is wrong."""
    workdir = _fresh_workdir()
    try:
        _write_config(workdir, CONFIG_NAMED_ORDER)

        res = _keep_order(mise_bin, workdir, "zebra", ":::", "apple", ":::", "mango")
        assert res.returncode == 0, (
            f"by-name run failed (exit {res.returncode}):\n{res.stdout}\n{res.stderr}"
        )
        order = _block_order(res.stdout + res.stderr)
        assert order == ["zebra", "apple", "mango"], (
            "directly-named tasks did not keep the order they were named on the "
            "command line — an ordering that ignores the declared/named order "
            "(for instance a sort by task name) cannot be a correct keep-order:\n"
            f"  named:    ['zebra', 'apple', 'mango']\n"
            f"  produced: {order}"
        )
    finally:
        shutil.rmtree(workdir, ignore_errors=True)
