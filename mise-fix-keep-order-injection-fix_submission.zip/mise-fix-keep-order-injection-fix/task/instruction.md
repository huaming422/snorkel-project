## Task

we lean on `mise run --output keep-order` a lot because it's supposed to give us one clean block of output per task, in a stable order that doesn't ride on however the scheduler happens to interleave the actual work. that holds up fine when we run tasks directly by name. where it breaks is when one task kicks off others. say a task whose whole job is to start a few more, or tasks pulled in through `depends` / `depends_post`. in that case the order those blocks come out in is flaky: run the same config twice on the same machine and the blocks land in a different order each time, and the order comes out wrong against what you get running those same tasks directly by name. it gets noticeably worse the more jobs we let run in parallel. the whole point of keep-order is that the output order shouldn't be at the mercy of timing like this. dig in and fix it.

## General instructions

- The code repo is at /repo/mise.
- You are inside of a Docker container with no network access. You may not be able to perform all operations you would normally be able to do on a local machine. The project's dependencies and toolchain are already installed and the package manager caches are populated, so build and test with what is in the image; anything that needs to be downloaded will fail rather than hang.
- You are expected to act autonomously as a software engineer to complete tasks you are given.
- Do not stop until you feel you have completed the task and your code changes can be merged.
- You may need to use software engineering skills like analyzing the codebase, researching technologies, running services, analyzing logs, etc. to complete the task. Not all tasks will be solvable by reading source code alone.
