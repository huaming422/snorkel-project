## Task

The vector-store ingestion pipeline in the semantic router misbehaves on
shutdown under load. It embeds and stores uploaded files through background
worker goroutines, and stopping it while a worker is still wedged mid-work goes
wrong:

- A bounded shutdown that times out with a worker still busy will, on a second
  shutdown call, report success even though the pipeline never drained. Callers
  that retry stop are told everything is clean when it isn't.
- After a shutdown that timed out, restarting the pipeline can proceed while
  the previous run's workers are still unwinding, so the new run shares state
  with the old one instead of starting fresh.
- When the metadata store is slow, a bounded shutdown can run well past its
  deadline, and the per-store file counts drift: work that was queued but never
  processed is not accounted as failed.

The runtime that owns the pipeline also swallows a failed shutdown and keeps
closing its dependencies instead of surfacing it.

Fix the shutdown and restart behavior so concurrent and repeated stop/start
cycles stay correct, and keep the public start, stop, attach, and status
surface the same shape.
