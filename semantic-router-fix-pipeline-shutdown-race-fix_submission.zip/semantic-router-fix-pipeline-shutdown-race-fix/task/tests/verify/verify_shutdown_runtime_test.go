/*
Copyright 2025 vLLM Semantic Router.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

// Covers the runtime wrapper that owns the ingestion pipeline plus the backend
// and metadata registry: when the pipeline's bounded stop fails, the wrapper's
// shutdown entry must surface that failure to its caller instead of swallowing
// it and continuing to close dependencies under still-live workers.
//
// White-box (package routerruntime) so the wrapper can be constructed directly
// around a real pipeline wedged mid-work with a short drain bound. It drives
// only the exported Shutdown entry and asserts on its returned error; it never
// inspects the wrapper's internal shutdown steps. Identifiers are `vrs`-prefixed
// so they don't collide with the package's own test files.
package routerruntime

import (
	"context"
	"os"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/stretchr/testify/require"

	vs "github.com/vllm-project/semantic-router/src/semantic-router/pkg/vectorstore"
)

// vrsBlockingEmbedder blocks inside Embed until released, so a worker can be
// wedged deterministically and the bounded stop is forced to time out. It is
// this test's own copy; it references no unexported repo symbol.
type vrsBlockingEmbedder struct {
	dim         int
	startOnce   sync.Once
	releaseOnce sync.Once
	started     chan struct{}
	release     chan struct{}
}

func vrsNewBlockingEmbedder(dim int) *vrsBlockingEmbedder {
	return &vrsBlockingEmbedder{
		dim:     dim,
		started: make(chan struct{}),
		release: make(chan struct{}),
	}
}

func (e *vrsBlockingEmbedder) Embed(_ context.Context, _ string) ([]float32, error) {
	e.startOnce.Do(func() { close(e.started) })
	<-e.release
	emb := make([]float32, e.dim)
	for i := range emb {
		emb[i] = 0.1
	}
	return emb, nil
}

func (e *vrsBlockingEmbedder) Dimension() int { return e.dim }

func (e *vrsBlockingEmbedder) releaseAll() {
	e.releaseOnce.Do(func() { close(e.release) })
}

// vrsTrackingBackend wraps an in-memory backend and records whether Close was
// called. It lets the verifier observe whether Shutdown tore the backend down
// out from under workers that may still be using it. It references no
// unexported repo symbol.
type vrsTrackingBackend struct {
	vs.VectorStoreBackend
	closed atomic.Bool
}

func (b *vrsTrackingBackend) Close() error {
	b.closed.Store(true)
	return b.VectorStoreBackend.Close()
}

// vrsTrackingCloser stands in for the runtime's metadata-registry closer and
// records whether Close was called.
type vrsTrackingCloser struct {
	closed atomic.Bool
}

func (c *vrsTrackingCloser) Close() error {
	c.closed.Store(true)
	return nil
}

// Criterion: shutdown_reports_stop_failure (fail_to_pass)
//
// With a pipeline wedged mid-embed and a short drain bound, the bounded stop
// inside Shutdown times out; Shutdown must return a non-nil error reflecting the
// stop failure (the deadline error), rather than swallowing it and returning
// nil after closing its dependencies. Pre-fix Shutdown logs and returns nil.
func TestVerifyShutdownReportsStopFailure(t *testing.T) {
	embedder := vrsNewBlockingEmbedder(3)

	tempDir, err := os.MkdirTemp("", "vrs-shutdown-runtime-*")
	require.NoError(t, err)
	t.Cleanup(func() { _ = os.RemoveAll(tempDir) })

	backend := vs.NewMemoryBackend(vs.MemoryBackendConfig{})
	registry := vs.NewMemoryMetadataRegistry()
	fileStore, err := vs.NewFileStore(tempDir, vs.NewMemoryMetadataRegistry())
	require.NoError(t, err)
	manager := vs.NewManager(backend, registry, 3, vs.BackendTypeMemory)

	pipeline := vs.NewIngestionPipeline(
		backend,
		fileStore,
		manager,
		embedder,
		vs.PipelineConfig{Workers: 1, QueueSize: 10},
	)
	pipeline.Start()

	runtime := &VectorStoreRuntime{
		FileStore:    fileStore,
		Backend:      backend,
		Manager:      manager,
		Pipeline:     pipeline,
		Embedder:     embedder,
		drainTimeout: 150 * time.Millisecond,
	}
	t.Cleanup(func() {
		embedder.releaseAll()
		_ = pipeline.Stop(context.Background())
	})

	store, err := manager.CreateStore(context.Background(), vs.CreateStoreRequest{Name: "shutdown-runtime"})
	require.NoError(t, err)
	record, err := fileStore.Save("wedged.txt", []byte("content to embed"), "assistants")
	require.NoError(t, err)
	_, err = pipeline.AttachFile(store.ID, record.ID, nil)
	require.NoError(t, err)

	// Wait until the worker is wedged inside Embed, so the drain is guaranteed
	// to time out.
	select {
	case <-embedder.started:
	case <-time.After(5 * time.Second):
		t.Fatal("embedder never entered its blocked stage")
	}

	// Run Shutdown on a goroutine with a generous bound: a wrapper that honors
	// its drain deadline returns quickly; this guard only prevents a pathological
	// hang from stalling the whole test binary.
	type shutdownResult struct{ err error }
	done := make(chan shutdownResult, 1)
	go func() { done <- shutdownResult{err: runtime.Shutdown()} }()

	select {
	case res := <-done:
		require.Error(t, res.err,
			"Shutdown must surface the pipeline stop failure, not swallow it and return nil")
		require.ErrorIs(t, res.err, context.DeadlineExceeded,
			"the surfaced Shutdown error should reflect the bounded stop's deadline failure")
	case <-time.After(10 * time.Second):
		t.Fatal("Shutdown did not return within its bound")
	}
}

// Criterion: shutdown_leaves_dependencies_open_on_stop_failure (fail_to_pass)
//
// A bounded stop that times out means workers may still be inside backend or
// registry calls. Shutdown must not tear those dependencies down while that is
// true: when the pipeline stop fails, Shutdown must surface the error AND leave
// the backend and the metadata-registry closer untouched, so it does not close
// resources out from under still-live workers. A solution that surfaces the
// stop error but closes the dependencies anyway (the use-after-close hazard the
// task calls out) is rejected here.
func TestVerifyShutdownLeavesDependenciesOpenOnStopFailure(t *testing.T) {
	embedder := vrsNewBlockingEmbedder(3)

	tempDir, err := os.MkdirTemp("", "vrs-shutdown-deps-*")
	require.NoError(t, err)
	t.Cleanup(func() { _ = os.RemoveAll(tempDir) })

	trackedBackend := &vrsTrackingBackend{VectorStoreBackend: vs.NewMemoryBackend(vs.MemoryBackendConfig{})}
	registry := vs.NewMemoryMetadataRegistry()
	closer := &vrsTrackingCloser{}
	fileStore, err := vs.NewFileStore(tempDir, vs.NewMemoryMetadataRegistry())
	require.NoError(t, err)
	manager := vs.NewManager(trackedBackend, registry, 3, vs.BackendTypeMemory)

	pipeline := vs.NewIngestionPipeline(
		trackedBackend,
		fileStore,
		manager,
		embedder,
		vs.PipelineConfig{Workers: 1, QueueSize: 10},
	)
	pipeline.Start()

	runtime := &VectorStoreRuntime{
		FileStore:      fileStore,
		Backend:        trackedBackend,
		Manager:        manager,
		Pipeline:       pipeline,
		Embedder:       embedder,
		registryCloser: closer,
		drainTimeout:   150 * time.Millisecond,
	}
	t.Cleanup(func() {
		embedder.releaseAll()
		_ = pipeline.Stop(context.Background())
	})

	store, err := manager.CreateStore(context.Background(), vs.CreateStoreRequest{Name: "shutdown-deps"})
	require.NoError(t, err)
	record, err := fileStore.Save("wedged.txt", []byte("content to embed"), "assistants")
	require.NoError(t, err)
	_, err = pipeline.AttachFile(store.ID, record.ID, nil)
	require.NoError(t, err)

	// Wait until the worker is wedged inside Embed, so the bounded drain is
	// guaranteed to time out.
	select {
	case <-embedder.started:
	case <-time.After(5 * time.Second):
		t.Fatal("embedder never entered its blocked stage")
	}

	type shutdownResult struct{ err error }
	done := make(chan shutdownResult, 1)
	go func() { done <- shutdownResult{err: runtime.Shutdown()} }()

	select {
	case res := <-done:
		require.Error(t, res.err,
			"Shutdown must surface the pipeline stop failure, not swallow it")
		require.ErrorIs(t, res.err, context.DeadlineExceeded,
			"the surfaced Shutdown error should reflect the bounded stop's deadline failure")
		require.False(t, trackedBackend.closed.Load(),
			"Shutdown must not close the backend after a failed drain — workers may still be using it")
		require.False(t, closer.closed.Load(),
			"Shutdown must not close the metadata registry after a failed drain — workers may still be using it")
	case <-time.After(10 * time.Second):
		t.Fatal("Shutdown did not return within its bound")
	}
}
