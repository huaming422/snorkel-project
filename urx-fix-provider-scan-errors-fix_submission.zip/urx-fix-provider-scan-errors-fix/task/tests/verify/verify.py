"""Behavioral verifier for urx-fix-provider-scan-errors.

urx is a binary-only crate: there is no library target and the provider
modules are private, with their injection seams gated behind ``#[cfg(test)]``.
The only stable, public surface on which the reported behavior is observable
is the compiled ``urx`` command-line binary, so this verifier drives that
binary directly. It is implementation-agnostic: it never imports, names, or
inspects any provider symbol. It stands up loopback HTTP servers (and a
bound-then-closed TCP port) as the "target host", runs the binary against
them, and asserts on the two public output streams:

  * stdout -- discovered URLs, one per line (default plain format);
  * stderr -- the ``--stats`` per-provider summary, whose columns are
    ``provider  urls  partial  errors  elapsed``.

Any fix that classifies a probe that never got an answer as a failed scan,
resolves relative discovery references against the location they were
fetched from, and trims whitespace off the locations it hands back will
pass -- regardless of which file the fix lives in, which helpers (if any)
it introduces, or what any of them are named.

The whole verifier runs on loopback: no external network, no API keys, no
services. It runs under VERIFIER_PYTHON (stdlib only).
"""

from __future__ import annotations

import http.server
import os
import socket
import subprocess
import threading
import time

import pytest

# The binary is built from /repo/urx with CARGO_TARGET_DIR pointing at the
# image's shared cache dir; resolve the path from that env var rather than
# assuming target/ under the crate.
REPO_DIR = os.environ.get("REPO_DIR", "/repo/urx")
_TARGET_DIR = os.environ.get("CARGO_TARGET_DIR", os.path.join(REPO_DIR, "target"))
URX_BIN = os.path.join(_TARGET_DIR, "debug", "urx")

# Transport timeout handed to the binary. Connection refusals on loopback are
# instant; this only bounds the (also local) read side.
PROBE_TIMEOUT_SEC = 5


# Discovery-data bodies.

# A robots.txt advertising four kinds of Sitemap value: a root-relative path,
# a document-relative path, an absolute cross-host URL, and a non-fetchable
# scheme. The two relative values must be resolved against the host they were
# fetched from so they survive host validation; the junk scheme must be dropped.
ROBOTS_WITH_SITEMAP_DIRECTIVES = (
    "User-agent: *\n"
    "Sitemap: /sitemap.xml\n"
    "Sitemap: sitemaps/extra.xml\n"
    "Sitemap: https://cdn.example.com/absolute.xml\n"
    "Sitemap: javascript:alert(1)\n"
)


def _pretty_urlset(host: str) -> str:
    """A urlset whose single <loc> is pretty-printed: the URL sits on its own
    line, wrapped in indentation whitespace. Unless the location is trimmed
    before it is handed back, the surrounding whitespace rides into the value
    and host validation drops it."""
    return (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
        "  <url>\n"
        "    <loc>\n"
        f"      http://{host}/pretty\n"
        "    </loc>\n"
        "  </url>\n"
        "</urlset>\n"
    )


# Loopback HTTP server helpers.

# Candidate sitemap locations the binary speculatively probes, so the mock
# handler can answer the ones that matter for the trimming case.
_SITEMAP_PATHS = frozenset(
    {
        "/sitemap.xml",
        "/sitemap_index.xml",
        "/sitemap.txt",
    }
)


def _make_handler(robots_body: str | None, sitemap_body_for_host: bool):
    class _Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, *_args):  # silence request logging
            pass

        def _send(self, status: int, body: bytes = b"", ctype: str = "text/plain"):
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            if body:
                self.wfile.write(body)

        def do_GET(self):  # noqa: N802 (http.server API)
            host = self.headers.get("Host", "")
            if robots_body is not None and self.path == "/robots.txt":
                self._send(200, robots_body.encode(), "text/plain")
            elif sitemap_body_for_host and self.path in _SITEMAP_PATHS:
                self._send(200, _pretty_urlset(host).encode(), "application/xml")
            else:
                self._send(404)

    return _Handler


class _Server:
    """A ThreadingHTTPServer on 127.0.0.1:<ephemeral>, torn down on exit."""

    def __init__(self, robots_body=None, sitemap_body_for_host=False):
        handler = _make_handler(robots_body, sitemap_body_for_host)
        self._srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
        self.port = self._srv.server_address[1]
        self.host = f"127.0.0.1:{self.port}"
        self._thread = threading.Thread(target=self._srv.serve_forever, daemon=True)
        self._thread.start()

    def __enter__(self):
        return self

    def __exit__(self, *_exc):
        self._srv.shutdown()
        self._srv.server_close()


def _closed_port_host() -> str:
    """Bind an ephemeral loopback port, read it, then close the socket so
    nothing listens there. A connection to it is refused outright -- a real
    transport failure, which a sandbox that 404s blocked public hostnames
    would not reproduce."""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return f"127.0.0.1:{port}"


# Running the binary + parsing its output.


def _run_urx(target: str, providers: str, timeout: int = PROBE_TIMEOUT_SEC):
    """Run the binary against ``target`` for the given provider ids and return
    (stdout, stderr). The binary exits 0 even when a provider errors, so the
    outcome is read from the streams, never from the exit code."""
    proc = subprocess.run(
        [
            URX_BIN,
            target,
            "--providers",
            providers,
            "--stats",
            "--no-progress",
            "--no-cache",
            "--timeout",
            str(timeout),
        ],
        capture_output=True,
        text=True,
        timeout=120,
        cwd=REPO_DIR,
    )
    return proc.stdout, proc.stderr


def _stdout_lines(stdout: str) -> list[str]:
    return [ln.strip() for ln in stdout.splitlines() if ln.strip()]


def _raw_stdout_lines(stdout: str) -> list[str]:
    """Physical lines exactly as emitted, with surrounding whitespace intact and
    only fully-empty lines dropped. A location handed back with its indentation
    still attached shows up here as a line that is NOT equal to the clean URL."""
    return [ln for ln in stdout.splitlines() if ln != ""]


def _errors_for(stderr: str, label: str):
    """Return the errors count for a provider row in the --stats table, matched
    by its display label. Columns are ``provider urls partial errors elapsed``,
    so errors is the penultimate whitespace token (elapsed is the last). Returns
    None if the row is absent."""
    for line in stderr.splitlines():
        stripped = line.strip()
        if stripped.lower().startswith(label.lower()):
            tokens = stripped.split()
            if len(tokens) >= 2:
                try:
                    return int(tokens[-2])
                except ValueError:
                    return None
    return None


# One-time build of the binary under test.


@pytest.fixture(scope="session", autouse=True)
def _built_binary():
    """Ensure the binary reflects the current source tree. The image pre-builds
    it and the setup step rebuilds after any change, but building here too keeps
    the verifier self-contained; cargo is incremental, so a warm tree is cheap.
    Deps are baked into the image, so the build runs offline."""
    env = {**os.environ, "CARGO_NET_OFFLINE": "true"}
    proc = subprocess.run(
        ["cargo", "build", "--locked"],
        cwd=REPO_DIR,
        env=env,
        capture_output=True,
        text=True,
        timeout=1000,
    )
    if proc.returncode != 0:
        pytest.fail(
            "cargo build failed; cannot exercise the binary:\n"
            + proc.stderr[-4000:]
        )
    # Give the filesystem a beat to settle the freshly linked binary.
    for _ in range(50):
        if os.path.exists(URX_BIN) and os.access(URX_BIN, os.X_OK):
            break
        time.sleep(0.1)
    assert os.access(URX_BIN, os.X_OK), f"binary not executable at {URX_BIN}"


# Tests.


def test_unreachable_host_counts_as_error():
    """A host that never answers (connection refused) must be reported as a scan
    error in the per-provider summary, not as a completed zero-URL scan.

    Both direct-probe discovery providers must mark the error: pre-fix each
    reports 0 errors for a dead host (a failed scan wearing a clean summary)."""
    target = _closed_port_host()
    _stdout, stderr = _run_urx(target, "robots,sitemap")

    robots_errors = _errors_for(stderr, "Robots.txt")
    sitemap_errors = _errors_for(stderr, "Sitemap")

    assert robots_errors is not None, f"no Robots.txt row in stats:\n{stderr}"
    assert sitemap_errors is not None, f"no Sitemap row in stats:\n{stderr}"
    assert robots_errors >= 1, (
        f"unreachable host reported {robots_errors} errors for the robots "
        f"provider; expected it to be counted as a failed scan.\n{stderr}"
    )
    assert sitemap_errors >= 1, (
        f"unreachable host reported {sitemap_errors} errors for the sitemap "
        f"provider; expected it to be counted as a failed scan.\n{stderr}"
    )


def test_missing_discovery_data_is_clean_success():
    """A host that ANSWERS it has no discovery data (404 everywhere) is a
    successful zero-URL scan and must report zero errors.

    This is the pair-mate of the unreachable case: a fix that marks every empty
    result as an error breaks this legitimate empty scan."""
    with _Server(robots_body=None, sitemap_body_for_host=False) as srv:
        stdout, stderr = _run_urx(srv.host, "robots,sitemap")

    robots_errors = _errors_for(stderr, "Robots.txt")
    sitemap_errors = _errors_for(stderr, "Sitemap")

    assert robots_errors is not None, f"no Robots.txt row in stats:\n{stderr}"
    assert sitemap_errors is not None, f"no Sitemap row in stats:\n{stderr}"
    assert robots_errors == 0, (
        f"a reachable host with no discovery data reported {robots_errors} "
        f"errors for the robots provider; it must stay a clean scan.\n{stderr}"
    )
    assert sitemap_errors == 0, (
        f"a reachable host with no discovery data reported {sitemap_errors} "
        f"errors for the sitemap provider; it must stay a clean scan.\n{stderr}"
    )
    assert _stdout_lines(stdout) == [], (
        f"expected no URLs from a host with no discovery data, got:\n{stdout}"
    )


def test_relative_discovery_references_are_resolved():
    """Relative discovery references a reachable host publishes must be resolved
    to absolute URLs against the location they were fetched from, so they
    survive to the output; non-fetchable schemes must be dropped.

    Pre-fix the relative values leave the provider as bare paths, which host
    validation drops, so neither resolved URL ever reaches stdout."""
    with _Server(robots_body=ROBOTS_WITH_SITEMAP_DIRECTIVES) as srv:
        host = srv.host
        stdout, _stderr = _run_urx(host, "robots")

    lines = _stdout_lines(stdout)

    assert f"http://{host}/sitemap.xml" in lines, (
        f"root-relative reference was not resolved to the fetched host.\n{stdout}"
    )
    assert f"http://{host}/sitemaps/extra.xml" in lines, (
        f"document-relative reference was not resolved to the fetched host.\n{stdout}"
    )
    # A non-fetchable scheme must never be emitted as if it were a URL.
    assert not any(ln.startswith("javascript:") for ln in lines), (
        f"a non-http(s) scheme leaked into the output.\n{stdout}"
    )
    # Nothing may leave the provider as an unresolved bare path.
    assert not any(ln in ("/sitemap.xml", "sitemaps/extra.xml") for ln in lines), (
        f"an unresolved relative reference leaked into the output.\n{stdout}"
    )
    assert all(ln.startswith("http://") or ln.startswith("https://") for ln in lines), (
        f"a non-URL value reached the output.\n{stdout}"
    )


def test_pretty_printed_locations_are_trimmed():
    """A location published with surrounding whitespace (pretty-printed XML)
    must be trimmed before it is handed back, so it passes host validation and
    reaches the output exactly.

    Pre-fix the untrimmed value carries newlines and indentation, fails host
    validation, and is dropped -- the URL is absent from stdout."""
    with _Server(sitemap_body_for_host=True) as srv:
        host = srv.host
        stdout, _stderr = _run_urx(host, "sitemap")

    # Compare against the RAW lines: pre-fix the location is handed back with its
    # pretty-printing indentation still attached, so the physical line reads
    # "      http://host/pretty" (and host validation then drops it anyway). Only
    # a build that trims the location emits the clean URL as its own exact line.
    raw_lines = _raw_stdout_lines(stdout)
    expected = f"http://{host}/pretty"
    assert expected in raw_lines, (
        f"the pretty-printed location was not trimmed and did not reach the "
        f"output as a clean URL; expected an exact {expected!r} line among:\n{stdout!r}"
    )
    # No emitted line may carry surrounding whitespace.
    assert all(ln == ln.strip() for ln in raw_lines), (
        f"an emitted URL carried surrounding whitespace.\n{stdout!r}"
    )
