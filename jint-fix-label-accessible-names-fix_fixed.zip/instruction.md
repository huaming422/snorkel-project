
## Task

Playwright connected to a jint-browser page over the DevTools (CDP) endpoint can't find form controls by role and name when the name comes from a `<label>`. With `<label for="email">Email</label><input id="email">`, `page.GetByRole(AriaRole.Textbox, new() { Name = "Email" })` matches nothing, and the same happens when the label wraps the input instead. Controls named with aria-label or aria-labelledby are found fine.

Please fix this in the browser. Which control a label belongs to should match the HTML spec everywhere a page can observe it, not just in role queries, and accessible names should follow accname. Everything else should keep working as it does now.
