using AngleSharp.Css.Dom;
using AngleSharp.Dom;
using Jint.Browser.Accessibility;
using Jint.Browser.BindingGenerator;
using Jint.Tests.Browser;
using Jint.Tests.Browser.Accessibility;

namespace Jint.Tests.Browser.Verify;

// This test namespace sits under Jint.Tests.Browser, so the bare name `Browser` binds to that
// namespace rather than to the type. The alias belongs inside the namespace declaration, where it
// wins that lookup.
using Browser = global::Jint.Browser.Browser;

// Exercises HTML's label/labelable-control association the way the script-visible
// DOM, the accessible-name computation and label click activation all read it.
// Every assertion rides a pre-existing, stable boundary: the JS `labels`/`control`
// accessors over the in-process DOM-eval fixture, the accessible-name computation
// over its own fixture, in-process click activation, and the checked-in binding
// pin diffed against the emitter.
public sealed class LabelAccessibleNameVerifyTests
{
    // One page covering the ordinary association shapes: explicit for/id (including
    // a hidden one), a control with several labels in tree order, a wrapping label,
    // and an empty `for` that associates with nothing.
    private const string Page = """
        <!doctype html>
        <html><body>
        <label id="first" for="named">First</label>
        <label id="hidden" for="named" hidden>Hidden</label>
        <input id="named">
        <label id="second" for="named">Second</label>
        <label id="wrapped">Wrapped <input id="inside"></label>
        <label id="empty" for="">Not wrapped <input id="not-associated"></label>
        <label id="area-label" for="area">Message</label>
        <textarea id="area"></textarea>
        <label id="sel-label">Choice <select id="sel"></select></label>
        <label id="btn-label" for="btn">Go</label>
        <button id="btn"></button>
        <label id="meter-label" for="mtr">Load</label>
        <meter id="mtr"></meter>
        <label id="out-label" for="out">Result</label>
        <output id="out"></output>
        <label id="prog-label" for="prg">Progress</label>
        <progress id="prg"></progress>
        </body></html>
        """;

    // A labelable control answers every label whose labeled control it is: those
    // naming it with `for` AND the one wrapping it, in document order, and an empty
    // `for` names nothing.
    [Test]
    public void LabelsReturnsExplicitAndWrappingLabelsInTreeOrder()
    {
        using var fixture = DomTestFixture.Create(Page);

        fixture.Text("""
            (function () {
              const explicit = [...document.getElementById('named').labels].map(x => x.id).join(',');
              const wrapped = Array.from(document.getElementById('inside').labels, x => x.id).join(',');
              const empty = document.getElementById('not-associated').labels.length;
              const textarea = Array.from(document.getElementById('area').labels, x => x.id).join(',');
              const select = Array.from(document.getElementById('sel').labels, x => x.id).join(',');
              const button = Array.from(document.getElementById('btn').labels, x => x.id).join(',');
              const meter = Array.from(document.getElementById('mtr').labels, x => x.id).join(',');
              const output = Array.from(document.getElementById('out').labels, x => x.id).join(',');
              const progress = Array.from(document.getElementById('prg').labels, x => x.id).join(',');
              return [explicit, wrapped, empty, textarea, select, button, meter, output, progress].join('|');
            })()
            """).Should().Be("first,hidden,second|wrapped|0|area-label|sel-label|btn-label|meter-label|out-label|prog-label");
    }

    // A label answers the control it labels: the `for` target, otherwise the first
    // labelable descendant, otherwise nothing.
    [Test]
    public void LabelControlUsesForOrTheFirstLabelableDescendant()
    {
        using var fixture = DomTestFixture.Create(Page);

        fixture.Text("""
            (function () {
              return [
                document.getElementById('first').control.id,
                document.getElementById('wrapped').control.id,
                String(document.getElementById('empty').control),
              ].join('|');
            })()
            """).Should().Be("named|inside|null");
    }

    // A `for` labels the first element in the tree with that id, and only when that element
    // is labelable: a `for` naming a div or a hidden input, or a duplicate id whose first
    // holder is not labelable, labels nothing. A hidden input inside a wrapping label is
    // skipped for the next labelable descendant.
    [Test]
    public void AForTargetMustBeTheFirstElementWithThatIdAndLabelable()
    {
        using var fixture = DomTestFixture.Create("""
            <!doctype html>
            <html><body>
            <label id="to-div" for="d">X</label><div id="d"></div>
            <label id="to-hidden" for="h">Y</label><input type="hidden" id="h">
            <label id="skip-hidden"><input type="hidden"><input id="vis"></label>
            <input id="dup" class="first"><input id="dup" class="second"><label id="dup-label" for="dup">Z</label>
            <div id="div-first"></div><input id="div-first" class="after-div"><label id="div-first-label" for="div-first">W</label>
            </body></html>
            """);

        fixture.Text("""
            (function () {
              const first = document.querySelector('input.first');
              return [
                String(document.getElementById('to-div').control),
                String(document.getElementById('to-hidden').control),
                document.getElementById('skip-hidden').control.id,
                Array.from(document.getElementById('vis').labels, x => x.id).join(','),
                Array.from(first.labels, x => x.id).join(','),
                document.querySelector('input.second').labels.length,
                document.getElementById('dup-label').control === first,
                String(document.getElementById('div-first-label').control),
                document.querySelector('input.after-div').labels.length,
              ].join('|');
            })()
            """).Should().Be("null|null|vis|skip-hidden|dup-label|0|true|null|0");
    }

    // A `for` is looked up in the label's own tree: a detached subtree and a shadow root
    // each resolve their own ids, even when the document holds an element with the same id.
    [Test]
    public void AForTargetIsResolvedInTheLabelsOwnTree()
    {
        using var fixture = DomTestFixture.Create(
            "<!doctype html><html><body><input id=\"x\" class=\"doc\"><div id=\"host\"></div></body></html>");

        fixture.Text("""
            (function () {
              const detached = document.createElement('div');
              detached.innerHTML = '<label id="dl" for="x">L</label><input id="x" class="detached">';
              const detachedInput = detached.querySelector('input');
              const shadow = document.getElementById('host').attachShadow({ mode: 'open' });
              shadow.innerHTML = '<label id="sl" for="x">S</label><input id="x" class="shadow">';
              const shadowInput = shadow.querySelector('input');
              return [
                detached.querySelector('label').control === detachedInput,
                Array.from(detachedInput.labels, x => x.id).join(','),
                shadow.querySelector('label').control === shadowInput,
                Array.from(shadowInput.labels, x => x.id).join(','),
                document.querySelector('input.doc').labels.length,
              ].join('|');
            })()
            """).Should().Be("true|dl|true|sl|0");
    }

    // A wrapping label with no `for` labels only its first labelable descendant, so a
    // second control inside the same label has no labels and the label's control is
    // the first one.
    [Test]
    public void AWrappingLabelLabelsOnlyItsFirstLabelableDescendant()
    {
        using var fixture = DomTestFixture.Create(
            "<!doctype html><html><body><label id=\"multi\">Both <input id=\"m1\"><input id=\"m2\"></label></body></html>");

        fixture.Text("""
            (function () {
              return [
                Array.from(document.getElementById('m1').labels, x => x.id).join(','),
                document.getElementById('m2').labels.length,
                document.getElementById('multi').control.id,
              ].join('|');
            })()
            """).Should().Be("multi|0|m1");
    }

    // The labels collection is live: it re-answers after a `for` is re-pointed on
    // the same reference, dropping the label that moved away in tree order.
    [Test]
    public void LabelsIsALiveNodeList()
    {
        using var fixture = DomTestFixture.Create(Page);

        fixture.Text("""
            (function () {
              const input = document.getElementById('named');
              const labels = input.labels;
              const before = labels.length;
              document.getElementById('second').htmlFor = 'inside';
              return [before, labels.length, labels.item(1).id].join('|');
            })()
            """).Should().Be("3|2|hidden");
    }

    // A non-labelable control, a hidden input, answers a null labels collection
    // rather than an empty one.
    [Test]
    public void AHiddenInputHasNoLabelsNodeList()
    {
        using var fixture = DomTestFixture.Create(Page);

        fixture.Text("""
            (function () {
              const input = document.createElement('input');
              input.type = 'hidden';
              return String(input.labels);
            })()
            """).Should().Be("null");
    }

    // The accessible name of a control named only by its associated labels is that
    // label text, in tree order, and a hidden label that is the direct target of
    // the association still contributes.
    [Test]
    public void AccessibleNameReadsAssociatedLabelTextIncludingHiddenReferences()
    {
        NameOf("<label for=t>Full name</label><input id=t>").Should().Be("Full name");
        NameOf("<label for=t>A</label><label for=t>B</label><input id=t>").Should().Be("A B");
        NameOf("<label>Full name <input id=t></label>").Should().Be("Full name");
        NameOf("<label for=t hidden>Hidden</label><label for=t>Visible</label><input id=t>")
            .Should().Be("Hidden Visible");

        // A wrapping label labels only its first labelable descendant, so a second control
        // inside it is not named by that label and falls through to its own placeholder.
        NameOf("<label>Pick <input id=a><input id=t placeholder=P></label>").Should().Be("P");
    }

    // The accessible name follows the same association as the DOM: an empty `for` names
    // nothing it wraps, a `for` whose first id holder is not labelable or is another control
    // names nothing else, and a `for` inside a shadow root names the control in that tree.
    [Test]
    public void AccessibleNameUsesTheSameLabelAssociation()
    {
        NameOfFirst("<label for=''>Wrapped <input class=t placeholder=P></label>").Should().Be("P");
        NameOfFirst("<div id=x></div><label for=x>L</label><input id=x class=t placeholder=P>").Should().Be("P");
        NameOfFirst("<input id=x><label for=x>L</label><input id=x class=t placeholder=P>").Should().Be("P");

        using var document = PageFixture.Parse("<label for=x>Doc</label><input id=x><div id=host></div>");
        var shadow = document.GetElementById("host")!.AttachShadow();
        shadow.InnerHtml = "<label for=x>Shadow</label><input id=x>";
        Compute(shadow.QuerySelector("input")!).Should().Be("Shadow");
        Compute(document.GetElementById("x")!).Should().Be("Doc");
    }

    // Names that do not come from a label resolve exactly as before.
    [Test]
    public void NamesThatDoNotComeFromALabelStillResolve()
    {
        NameOf("<input id=t placeholder='Search the docs'>").Should().Be("Search the docs");
        NameOf("<label for=t>Query</label><input id=t placeholder='Search'>").Should().Be("Query");
        NameOf("<input id=t type=submit>").Should().Be("Submit");
        NameOf("<input id=t type=image>").Should().Be("Submit Query");
        NameOf("<button id=t>Save <b>now</b></button>").Should().Be("Save now");
        NameOf("<button id=t title='Tooltip only'></button>").Should().Be("Tooltip only");
        NameOf("<span id=a hidden>Hidden label</span><button id=t aria-labelledby=a>Content</button>")
            .Should().Be("Hidden label");
    }

    // An explicit ARIA name still wins over associated-label text; the fallback is
    // consulted only when nothing above it named the control.
    [Test]
    public void AriaNamePrecedenceOverAssociatedLabelIsPreserved()
    {
        NameOf("<label for=t>Native</label><input id=t aria-label='ARIA label'>")
            .Should().Be("ARIA label");
        NameOf("<span id=a hidden>Referenced</span><label for=t>Native</label>"
             + "<input id=t aria-labelledby=a aria-label='ARIA label'>")
            .Should().Be("Referenced");
    }

    // Clicking inside a label forwards activation to the control it labels, for both
    // the wrapping and the `for` spellings. A label whose only descendant is a
    // non-labelable control, whose `for` is empty, or whose `for` names a non-labelable
    // first holder of the id, forwards nothing. A `for` inside a shadow root forwards to
    // the control in that shadow tree, not to a document control with the same id.
    [Test]
    public async Task ClickingInsideALabelForwardsToTheControlItLabels()
    {
        await using var browser = new Browser();
        var page = await browser.NewPageAsync();
        await page.SetContentAsync(
            "<label id='wrapping'><input id='inner' type='checkbox'><span id='text'>text</span></label>"
            + "<label id='naming' for='outer'>text</label><input id='outer' type='checkbox'>"
            + "<label id='hiddenOnly'><input type='hidden'><span id='hiddenText'>text</span></label>"
            + "<label id='emptyFor' for=''><input id='unlabeled' type='checkbox'><span id='emptyText'>text</span></label>"
            + "<div id='y'></div><label for='y'><span id='yText'>text</span></label><input id='y' type='checkbox' class='dupY'>"
            + "<input id='x' type='checkbox' class='docX'><div id='host'></div>");

        (await page.EvaluateAsync<string>(
            """
            (() => {
              const seen = [];
              for (const id of ['inner', 'outer', 'unlabeled']) {
                document.getElementById(id).addEventListener('click', e => seen.push(id + ':' + e.isTrusted));
              }

              document.getElementById('text').click();
              document.getElementById('naming').click();
              document.getElementById('hiddenText').click();
              document.getElementById('emptyText').click();
              document.getElementById('yText').click();

              const shadow = document.getElementById('host').attachShadow({ mode: 'open' });
              shadow.innerHTML = '<label for="x"><span id="shadowText">S</span></label><input id="x" type="checkbox">';
              shadow.getElementById('shadowText').click();

              return seen.join(',') + '|' + document.getElementById('inner').checked + document.getElementById('outer').checked
                + document.getElementById('unlabeled').checked
                + '|' + document.querySelector('input.dupY').checked
                + '|' + document.querySelector('input.docX').checked + shadow.querySelector('input').checked;
            })()
            """))
            .Should().Be("inner:false,outer:false|truetruefalse|false|falsetrue");
    }

    // The checked-in generated bindings must equal what the emitter produces from
    // the override table and the pinned assemblies, with no extra generated file.
    [Test]
    public void TheCheckedInBindingsMatchTheEmitter()
    {
        var result = BindingGenerator.Run(new BindingGeneratorOptions
        {
            CoreAssembly = typeof(IElement).Assembly.Location,
            CssAssembly = typeof(ICssStyleDeclaration).Assembly.Location,
            OverridesPath = RepositoryPaths.OverridesPath,
        });

        var differences = new List<string>();

        foreach (var (name, expected) in result.Files)
        {
            var path = System.IO.Path.Combine(RepositoryPaths.GeneratedDirectory, name);
            var actual = System.IO.File.Exists(path)
                ? RepositoryPaths.NormalizeNewlines(System.IO.File.ReadAllText(path))
                : null;

            if (!string.Equals(actual, expected, StringComparison.Ordinal))
            {
                differences.Add(actual is null ? name + " is missing" : name + " differs");
            }
        }

        foreach (var path in System.IO.Directory.GetFiles(RepositoryPaths.GeneratedDirectory, "*.g.cs"))
        {
            var name = System.IO.Path.GetFileName(path);
            if (!result.Files.ContainsKey(name))
            {
                differences.Add(name + " is checked in but the emitter does not produce it");
            }
        }

        differences.Should().BeEmpty(
            "the checked-in generated bindings must equal what the emitter produces from the override table");
    }

    private static string NameOf(string html)
    {
        using var document = PageFixture.Parse(html);
        return Compute(document.GetElementById("t")!);
    }

    private static string NameOfFirst(string html)
    {
        using var document = PageFixture.Parse(html);
        return Compute(document.QuerySelector(".t")!);
    }

    private static string Compute(IElement element)
    {
        var computation = new AccessibleName(new ElementVisibility(useComputedStyle: true));
        return computation.Compute(element, AccessibleName.ResolveRole(element));
    }
}
