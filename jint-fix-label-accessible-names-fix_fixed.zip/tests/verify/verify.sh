#!/usr/bin/env bash
# Behavioral checks for jint-fix-label-accessible-names.
#
# The repo is C# and the runner registry has no .NET runner, so .NET is routed
# through this shell script: it stages the label test class into the
# Jint.Tests.Browser project and runs `dotnet test` filtered to just that class.
# Exit 0 = every test in the class passed; non-zero propagates the build/test failure.
#
# The class lives beside this script (staged read-only into /tests/verify/)
# and is copied into the project so the project's default compile glob picks it up.
# It rides only pre-existing, stable boundaries (the in-process DOM-eval fixture's
# `labels`, `control` and `form` accessors, the accessible-name computation, in-process click
# activation, and the checked-in binding pin diffed against the emitter), so any
# restructuring that keeps those answers correct passes.
#
# The class is staged into its own folder, not the project's existing Verify/
# (which holds the public API baselines), and only that folder is removed afterwards.
# A filter that matches no test is an error, so a project change that keeps the class
# out of the build cannot pass by running nothing.
#
# The image baked the net10.0 build of Jint.Tests.Browser at the base commit, so the
# compile is incremental and the NuGet cache is warm; --no-restore keeps it offline.
set -uo pipefail

REPO_NAME="${REPO_NAME:-jint}"
REPO_DIR="/repo/${REPO_NAME}"
PROJECT="Jint.Tests.Browser"
STAGE_DIR="${REPO_DIR}/${PROJECT}/LabelAssociationChecks"
LOG="$(mktemp)"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_NOLOGO=1 DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1

cd "${REPO_DIR}" || { echo "FAIL: repo dir ${REPO_DIR} missing" >&2; exit 2; }

# Stage the test class where the project's compile glob will pick it up.
mkdir -p "${STAGE_DIR}"
cp "${HERE}/LabelAccessibleNameVerifyTests.cs" "${STAGE_DIR}/LabelAccessibleNameVerifyTests.cs" \
    || { echo "FAIL: could not stage the test class" >&2; exit 2; }

cleanup() { rm -rf "${STAGE_DIR}" "${LOG}"; }
trap cleanup EXIT

FILTER="FullyQualifiedName~Jint.Tests.Browser.Verify.LabelAccessibleNameVerifyTests"

echo "[verify] dotnet test ${PROJECT} -c Release -f net10.0 --filter ${FILTER}"
dotnet test "${PROJECT}/${PROJECT}.csproj" \
    -c Release -f net10.0 --no-restore \
    --filter "${FILTER}" \
    --logger "console;verbosity=normal" \
    -- RunConfiguration.TreatNoTestsAsError=true 2>&1 | tee "${LOG}"
status=${PIPESTATUS[0]}

if [ "${status}" -eq 0 ]; then
    echo "PASS: label/name association behaves correctly across all shapes"
else
    failed=$(grep -oE '^[[:space:]]+Failed [A-Za-z0-9_]+' "${LOG}" | awk '{print $2}' | sort -u | paste -sd, -)
    echo "FAIL: dotnet test exited ${status}; failed: ${failed:-none reported (build or discovery error)}" >&2
fi
exit "${status}"
