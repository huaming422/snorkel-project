#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# No services, no seeding, no assertions: this task's behaviour is exercised
# entirely in-process by the Jint.Tests.Browser suite the verifier runs.
#
# The image baked the full .NET dependency closure at the base commit: the NuGet
# global-packages cache (/opt/cache/nuget) is warm and Jint.Tests.Browser was
# restored + built on net10.0. So this step only confirms packages resolve from
# that bake with the network down; it must NOT compile the agent's edited sources
# (a compile failure is the verifier's to report, not setup's to abort on).
cd /repo/jint

# Keep NuGet off the network: restore must be satisfiable from the warm cache.
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_NOLOGO=1 DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1

# Dependencies: offline-first against the image bake, logged online fallback.
# /p:NuGetAudit=false suppresses the vulnerability-data fetch (NU1900) which
# requires api.nuget.org; the audit is a network-only check that is irrelevant
# in the verifier sandbox and would be a hard error under TreatWarningsAsErrors.
if dotnet restore Jint.Tests.Browser/Jint.Tests.Browser.csproj \
        --locked-mode /p:NuGetAudit=false > /tmp/test-setup-restore.log 2>&1 \
   || dotnet restore Jint.Tests.Browser/Jint.Tests.Browser.csproj \
        /p:NuGetAudit=false > /tmp/test-setup-restore.log 2>&1; then
    # Re-run with the source feed disabled to prove the cache alone satisfies it.
    if dotnet restore Jint.Tests.Browser/Jint.Tests.Browser.csproj \
            --source /opt/cache/nuget /p:NuGetAudit=false >> /tmp/test-setup-restore.log 2>&1; then
        echo "[offline-first] NuGet restore satisfied from image bake"
    else
        echo "[test-setup] NuGet restore used the online feed (image bake was stale)"
    fi
else
    # Do not abort test.sh here: the verifier's --no-restore build then fails and
    # reports the failure, instead of the run ending with no result at all.
    tail -40 /tmp/test-setup-restore.log >&2
    echo "[test-setup] NuGet restore failed; leaving the failure to the verifier" >&2
fi
