## Task

`rtk ls` has drifted from how real `ls` behaves for a bunch of argument shapes. people hand it the same arguments they'd give `ls` and get the wrong listing back.

a few of the things we've seen: a file whose name starts with a dash (say a file literally named `-al`) doesn't show up, you get the whole directory instead. arguments that are meant to be the value for a preceding option, or a path, get misread, so the listing shows the wrong files. some of the long-form options `ls` understands aren't being recognized. and on some bad input it comes back with the wrong result, or a different exit status than you'd get from `ls` itself.

it's all confined to `rtk ls` and the way it handles the arguments it's given before it hands them off to the underlying `ls`; the other subcommands are fine. make `rtk ls` read its arguments the way real `ls` does, so that for these shapes both the listing and the exit status line up with running `ls` directly.
