//! Integration checks for how `rtk ls` interprets its command-line arguments.
//!
//! Every check drives the compiled `rtk` binary through its public `ls`
//! subcommand and reads only its standard output and process exit status — the
//! same surface a person at a terminal sees. Nothing here looks at how the
//! arguments are sorted internally, so any implementation that makes `rtk ls`
//! line up with the system `ls` for these argument shapes is accepted.
//!
//! The binary is spawned with its data directory, home, and configuration
//! pointed at a throwaway location so a check never reads or writes the
//! grader's real `~/.local/share/rtk/`. Each check builds its own directory of
//! known files (permissions fixed explicitly so the rendered octal column is
//! stable) and runs the binary with that directory as the working directory.

use std::path::Path;
use std::process::{Command, Output};

use std::os::unix::fs::PermissionsExt;

/// A fresh, empty directory to populate with fixture files. Removed on drop.
fn fixture() -> tempfile::TempDir {
    tempfile::Builder::new()
        .prefix("rtk-ls-fix-")
        .tempdir()
        .expect("create a fixture directory")
}

/// Write `name` into `dir` with exactly `mode`, so the long listing's octal
/// column does not depend on the process umask.
fn write_file(dir: &Path, name: &str, contents: &[u8], mode: u32) {
    let path = dir.join(name);
    std::fs::write(&path, contents).unwrap_or_else(|e| panic!("write {name}: {e}"));
    std::fs::set_permissions(&path, std::fs::Permissions::from_mode(mode))
        .unwrap_or_else(|e| panic!("chmod {name}: {e}"));
}

/// Run `rtk ls <args>` with `dir` as the working directory, isolated from the
/// grader's own rtk data and home. Returns the finished process output.
fn run_rtk_ls(dir: &Path, args: &[&str]) -> Output {
    // A throwaway root for everything the child would otherwise write under the
    // developer's data and config directories. Kept alive until the child has
    // finished (the call below is synchronous), then removed on drop.
    let root = tempfile::Builder::new()
        .prefix("rtk-ls-data-")
        .tempdir()
        .expect("create an isolated data root");
    let root = root.path();

    let mut cmd = Command::new(env!("CARGO_BIN_EXE_rtk"));

    // The child is an ordinary release of the binary and obeys whatever it
    // inherits, so clear any RTK_ variables the environment carries before
    // pinning the ones that send its state into the throwaway root.
    let inherited: Vec<_> = std::env::vars_os()
        .map(|(name, _)| name)
        .filter(|name| {
            name.to_str()
                .is_some_and(|n| n.to_ascii_uppercase().starts_with("RTK_"))
        })
        .collect();
    for name in inherited {
        cmd.env_remove(name);
    }

    cmd.env("RTK_DB_PATH", root.join("rtk").join("history.db"))
        .env("RTK_TEE_DIR", root.join("rtk").join("tee"))
        .env("RTK_RECALL_DB", root.join("rtk").join("recall.db"))
        .env("XDG_DATA_HOME", root)
        .env("XDG_CONFIG_HOME", root.join(".config"))
        .env("HOME", root)
        .env("RTK_TELEMETRY_DISABLED", "1")
        .current_dir(dir)
        .arg("ls")
        .args(args);

    cmd.output().expect("spawn the rtk binary")
}

/// `rtk ls -- -al` on a directory that holds a file literally named `-al`.
///
/// The `--` separator means the token after it is a path, so the file named
/// `-al` is what gets listed — not the directory's other entries, which is what
/// happens when the separator is lost and `-al` is read as the `-a`/`-l`
/// option cluster.
#[test]
fn ls_double_dash_path() {
    let dir = fixture();
    write_file(dir.path(), "-al", b"", 0o644);
    write_file(dir.path(), "alpha.txt", b"", 0o644);
    write_file(dir.path(), "beta.txt", b"", 0o644);

    let out = run_rtk_ls(dir.path(), &["--", "-al"]);
    let stdout = String::from_utf8_lossy(&out.stdout);

    assert_eq!(
        out.status.code(),
        Some(0),
        "stderr: {}",
        String::from_utf8_lossy(&out.stderr)
    );
    assert!(
        stdout.contains("-al"),
        "the listing should name the dash-prefixed file: {stdout}"
    );
    assert!(
        !stdout.contains("alpha.txt"),
        "only the named file should be listed, not the whole directory: {stdout}"
    );
}

/// `rtk ls . -I beta` — the token after `-I` is its ignore pattern.
///
/// If that value is mistaken for a path, the child never receives a directory
/// to list and reports that it cannot access `beta`, exiting 2. Taken as the
/// ignore value, the current directory is listed and the command exits 0.
#[test]
fn ls_flag_value_not_a_path() {
    let dir = fixture();
    write_file(dir.path(), "alpha.txt", b"", 0o644);
    write_file(dir.path(), "beta.txt", b"", 0o644);

    let out = run_rtk_ls(dir.path(), &[".", "-I", "beta"]);
    let stdout = String::from_utf8_lossy(&out.stdout);

    assert_eq!(
        out.status.code(),
        Some(0),
        "stderr: {}",
        String::from_utf8_lossy(&out.stderr)
    );
    assert!(
        stdout.contains("alpha.txt"),
        "the directory's contents should be listed: {stdout}"
    );
}

/// `rtk ls -I -al` in a directory with a dotfile.
///
/// `-al` is the value for `-I`, not another option cluster, so the `a` must not
/// switch on all-files output: the dotfile stays hidden. Reading `-al` as
/// `-a`/`-l` instead would reveal it.
#[test]
fn ls_flag_value_looking_like_flag() {
    let dir = fixture();
    write_file(dir.path(), ".hidden", b"", 0o644);
    write_file(dir.path(), "alpha.txt", b"", 0o644);

    let out = run_rtk_ls(dir.path(), &["-I", "-al"]);
    let stdout = String::from_utf8_lossy(&out.stdout);

    assert_eq!(
        out.status.code(),
        Some(0),
        "stderr: {}",
        String::from_utf8_lossy(&out.stderr)
    );
    assert!(
        !stdout.contains(".hidden"),
        "a dotfile must not appear when `-al` is consumed as the ignore value: {stdout}"
    );
}

/// `rtk ls --format long <file>` — the separated value form.
///
/// It selects the long listing just as the attached `--format=long` form does.
/// The long listing carries an octal permissions column, so the fixed-mode file
/// renders with its `644`.
#[test]
fn ls_separate_format_implies_long() {
    let dir = fixture();
    write_file(dir.path(), "alpha.txt", b"", 0o644);

    let out = run_rtk_ls(dir.path(), &["--format", "long", "alpha.txt"]);
    let stdout = String::from_utf8_lossy(&out.stdout);

    assert_eq!(
        out.status.code(),
        Some(0),
        "stderr: {}",
        String::from_utf8_lossy(&out.stderr)
    );
    assert!(
        stdout.contains("644"),
        "a long listing should carry the octal permissions column: {stdout}"
    );
}

/// `rtk ls --format=lon <file>` — an unambiguous abbreviation of the value.
///
/// `lon` resolves to `long` the way the system tool resolves it, producing the
/// long listing (and therefore the octal column).
#[test]
fn ls_abbrev_resolution() {
    let dir = fixture();
    write_file(dir.path(), "alpha.txt", b"", 0o644);

    let out = run_rtk_ls(dir.path(), &["--format=lon", "alpha.txt"]);
    let stdout = String::from_utf8_lossy(&out.stdout);

    assert_eq!(
        out.status.code(),
        Some(0),
        "stderr: {}",
        String::from_utf8_lossy(&out.stderr)
    );
    assert!(
        stdout.contains("644"),
        "the abbreviated format value should still produce a long listing: {stdout}"
    );
}

/// `rtk ls -l --human-readable <1024-byte file>`.
///
/// Sizes are rendered by `rtk` itself, so a 1024-byte file reads as `1.0K`.
/// Passing the alias through to the child instead leaves the size mis-read.
#[test]
fn ls_human_readable_dropped() {
    let dir = fixture();
    write_file(dir.path(), "big.bin", &[0u8; 1024], 0o644);

    let out = run_rtk_ls(dir.path(), &["-l", "--human-readable", "big.bin"]);
    let stdout = String::from_utf8_lossy(&out.stdout);

    assert_eq!(
        out.status.code(),
        Some(0),
        "stderr: {}",
        String::from_utf8_lossy(&out.stderr)
    );
    assert!(
        stdout.contains("1.0K"),
        "1024 bytes should render as 1.0K: {stdout}"
    );
}

/// `rtk ls -a --indicator-style` — a value-taking option left without its value.
///
/// It must surface the child's missing-argument status (2), rather than
/// consuming the separator and failing some other way.
#[test]
fn ls_dangling_value_flag() {
    let dir = fixture();
    write_file(dir.path(), "alpha.txt", b"", 0o644);

    let out = run_rtk_ls(dir.path(), &["-a", "--indicator-style"]);

    assert_eq!(
        out.status.code(),
        Some(2),
        "stderr: {}",
        String::from_utf8_lossy(&out.stderr)
    );
}

/// `rtk ls -la` — clustered short flags.
///
/// This common form keeps working unchanged: `-a` reveals the dotfile and `-l`
/// produces the octal column. It holds both before and after the argument
/// handling is reworked.
#[test]
fn ls_short_cluster_regression() {
    let dir = fixture();
    write_file(dir.path(), ".hidden", b"", 0o644);
    write_file(dir.path(), "alpha.txt", b"", 0o644);

    let out = run_rtk_ls(dir.path(), &["-la"]);
    let stdout = String::from_utf8_lossy(&out.stdout);

    assert_eq!(
        out.status.code(),
        Some(0),
        "stderr: {}",
        String::from_utf8_lossy(&out.stderr)
    );
    assert!(
        stdout.contains(".hidden"),
        "`-a` should reveal the dotfile: {stdout}"
    );
    assert!(
        stdout.contains("644"),
        "`-l` should produce the octal column: {stdout}"
    );
}
