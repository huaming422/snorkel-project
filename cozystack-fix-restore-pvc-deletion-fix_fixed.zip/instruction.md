## Task

In-place VMInstance restores from Velero with keepOriginalPVC=false aren't bringing anything back. The RestoreJob goes Succeeded, but every disk still has the data it had before the restore. The disks are stuck after that too. The VM's HelmRelease stays Ready=False, and its DataVolume keeps getting rejected with "Destination PVC <namespace>/<name> already exists". Deleting the disk and creating a new one with the same name fails the same way.

Can you find out why the old disk survives the restore and fix it, so the backup data actually comes back? With keepOriginalPVC=true the original disk still has to be kept, same as now.

Once the restore throws disks away it needs to be careful about it. If the Velero backup it points at has expired or is being deleted, the RestoreJob should fail before it stops the VM or touches a disk. If it can't remove part of a disk, it should stop there instead of deleting the rest of it or carrying on with the restore. Keep in mind the controller only has the permissions its chart's ClusterRole gives it.
