#!/usr/bin/env bash
# All deps are baked into the image (offline agent phase); nothing to do at
# verifier time. The backupcontroller unit suite compiles against the module
# cache and build cache already warmed at the base commit.
set -euo pipefail
echo "[test-setup] no-op for cozystack-fix-restore-pvc-deletion"
