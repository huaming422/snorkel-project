// RBAC verifier for cozystack-fix-restore-pvc-deletion (C6).
//
// On a cluster the controller runs under the backupstrategy-controller
// ClusterRole (packages/system/backupstrategy-controller/templates/rbac.yaml),
// and every request it sends through its dynamic client (VirtualMachines,
// VMIs, HelmReleases, DataVolumes) needs a matching rule there. The in-memory
// fakes never enforce that, so this test records the requests instead: it
// drives in-place restore preparation through the states a real one passes
// through (a running VM to halt, a DataVolume whose deletion goes through, one
// whose deletion is still pending, a keepOriginalPVC=true restore), collects
// the group, resource and verb of every request sent through the dynamic
// client, and checks the ClusterRole grants each of them. Requests through the
// typed client are not checked: in production those go through the manager's
// cache, whose list/watch grants are a different shape.
//
// This file is injected into internal/backupcontroller/ on its own and
// compiles as part of package backupcontroller, reusing the package's
// newTestRestoreJobReconcilerWithDynamic builder. Go runs the test with its
// working directory set to that package, so the chart path is resolved
// relative to the module root found by walking up to go.mod. The template is
// plain YAML (no Helm directives), so it is parsed directly.
package backupcontroller

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"testing"

	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	dynamicfake "k8s.io/client-go/dynamic/fake"
	k8stesting "k8s.io/client-go/testing"
	"k8s.io/client-go/tools/record"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/yaml"

	backupsv1alpha1 "github.com/cozystack/cozystack/api/backups/v1alpha1"
)

type rbacRule struct {
	APIGroups []string `json:"apiGroups"`
	Resources []string `json:"resources"`
	Verbs     []string `json:"verbs"`
}

type rbacDoc struct {
	Kind  string     `json:"kind"`
	Rules []rbacRule `json:"rules"`
}

// rbacRequest is one group/resource/verb the controller sent.
type rbacRequest struct {
	group, resource, verb string
}

func (q rbacRequest) String() string {
	group := q.group
	if group == "" {
		group = "core"
	}
	return fmt.Sprintf("%s on %s/%s", q.verb, group, q.resource)
}

func rbacModuleRoot(t *testing.T) string {
	t.Helper()
	dir, err := os.Getwd()
	if err != nil {
		t.Fatalf("getwd: %v", err)
	}
	for {
		if _, err := os.Stat(filepath.Join(dir, "go.mod")); err == nil {
			return dir
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			t.Fatalf("could not locate module root (go.mod) above the test working directory")
		}
		dir = parent
	}
}

// rbacClusterRoleRules reads every ClusterRole in the controller's chart template.
func rbacClusterRoleRules(t *testing.T) []rbacRule {
	t.Helper()
	path := filepath.Join(rbacModuleRoot(t),
		"packages", "system", "backupstrategy-controller", "templates", "rbac.yaml")
	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read ClusterRole template %s: %v", path, err)
	}
	var rules []rbacRule
	for _, chunk := range strings.Split("\n"+string(raw), "\n---") {
		if strings.TrimSpace(chunk) == "" {
			continue
		}
		var doc rbacDoc
		if err := yaml.Unmarshal([]byte(chunk), &doc); err != nil {
			t.Fatalf("parse %s: %v", path, err)
		}
		if doc.Kind == "ClusterRole" {
			rules = append(rules, doc.Rules...)
		}
	}
	if len(rules) == 0 {
		t.Fatalf("no ClusterRole rules found in %s", path)
	}
	return rules
}

func rbacHas(list []string, want string) bool {
	for _, s := range list {
		if s == want || s == "*" {
			return true
		}
	}
	return false
}

func rbacGranted(rules []rbacRule, q rbacRequest) bool {
	for _, rule := range rules {
		if rbacHas(rule.APIGroups, q.group) && rbacHas(rule.Resources, q.resource) && rbacHas(rule.Verbs, q.verb) {
			return true
		}
	}
	return false
}

// rbacReconciler builds a RestoreJobReconciler on the package's own fake
// clients, with a dynamic fake that serves the kinds the restore path reaches,
// list kinds included, and an event buffer that never fills up.
func rbacReconciler(t *testing.T, dynamicObjects []runtime.Object, objects ...client.Object) (*RestoreJobReconciler, *dynamicfake.FakeDynamicClient) {
	t.Helper()
	r := newTestRestoreJobReconcilerWithDynamic(t, nil, objects...)
	s := runtime.NewScheme()
	for gvr, kind := range map[schema.GroupVersionResource]string{
		dataVolumeGVR:     "DataVolume",
		virtualMachineGVR: "VirtualMachine",
		vmiGVR:            "VirtualMachineInstance",
		helmReleaseGVR:    "HelmRelease",
	} {
		s.AddKnownTypeWithName(gvr.GroupVersion().WithKind(kind), &unstructured.Unstructured{})
		s.AddKnownTypeWithName(gvr.GroupVersion().WithKind(kind+"List"), &unstructured.UnstructuredList{})
	}
	fake := dynamicfake.NewSimpleDynamicClientWithCustomListKinds(s, nil, dynamicObjects...)
	r.Interface = fake
	r.Recorder = record.NewFakeRecorder(4096)
	return r, fake
}

func rbacObject(apiVersion, kind, ns, name string, spec map[string]any) *unstructured.Unstructured {
	u := &unstructured.Unstructured{Object: map[string]any{}}
	u.SetAPIVersion(apiVersion)
	u.SetKind(kind)
	u.SetNamespace(ns)
	u.SetName(name)
	if spec != nil {
		u.Object["spec"] = spec
	}
	return u
}

// rbacScenario is one in-place restore of the single disk
// vm-disk-ubuntu-source of VMInstance test-vm.
type rbacScenario struct {
	name string
	keep bool
	// pendingDelete makes every DataVolume delete succeed while the DataVolume stays.
	pendingDelete bool
	passes        int
}

// rbacCollect runs a scenario and returns every request prepareForRestore sent
// through the dynamic client.
func rbacCollect(t *testing.T, sc rbacScenario) map[rbacRequest]bool {
	t.Helper()
	ns := "tenant-root"
	restoreJob := &backupsv1alpha1.RestoreJob{
		ObjectMeta: metav1.ObjectMeta{Name: "restore-test", Namespace: ns, UID: "restore-job-uid"},
		Spec:       backupsv1alpha1.RestoreJobSpec{BackupRef: corev1.LocalObjectReference{Name: "my-backup"}},
	}
	backup := &backupsv1alpha1.Backup{
		ObjectMeta: metav1.ObjectMeta{Name: "my-backup", Namespace: ns},
		Spec: backupsv1alpha1.BackupSpec{
			ApplicationRef: corev1.TypedLocalObjectReference{
				APIGroup: new("apps.cozystack.io"),
				Kind:     "VMInstance",
				Name:     "test-vm",
			},
		},
	}
	urRaw, err := json.Marshal(vmInstanceResources{
		DataVolumes: []backupsv1alpha1.DataVolumeResource{
			{DataVolumeName: "vm-disk-ubuntu-source", ApplicationName: "ubuntu-source"},
		},
	})
	if err != nil {
		t.Fatal(err)
	}
	ur := &runtime.RawExtension{Raw: urRaw}
	target := restoreTarget{Namespace: ns, AppName: "test-vm", AppKind: "VMInstance"}
	opts := RestoreOptions{KeepOriginalPVC: new(sc.keep)}

	pvc := &corev1.PersistentVolumeClaim{
		ObjectMeta: metav1.ObjectMeta{Name: "vm-disk-ubuntu-source", Namespace: ns},
	}
	dynamicObjects := []runtime.Object{
		rbacObject("kubevirt.io/v1", "VirtualMachine", ns, vmNamePrefix+"test-vm", map[string]any{"runStrategy": "Always"}),
		rbacObject("helm.toolkit.fluxcd.io/v2", "HelmRelease", ns, vmNamePrefix+"test-vm", map[string]any{"suspend": false}),
		rbacObject("helm.toolkit.fluxcd.io/v2", "HelmRelease", ns, "vm-disk-ubuntu-source", map[string]any{"suspend": false}),
		rbacObject("cdi.kubevirt.io/v1beta1", "DataVolume", ns, "vm-disk-ubuntu-source", nil),
	}
	r, fake := rbacReconciler(t, dynamicObjects, pvc, restoreJob, backup)
	if sc.pendingDelete {
		fake.PrependReactor("delete", "datavolumes", func(k8stesting.Action) (bool, runtime.Object, error) {
			return true, nil, nil
		})
	}

	sent := map[rbacRequest]bool{}
	ctx := context.Background()
	for pass := 0; pass < sc.passes; pass++ {
		fake.ClearActions()
		ready, _, err := r.prepareForRestore(ctx, restoreJob, backup, ur, target, opts)
		for _, a := range fake.Actions() {
			res := a.GetResource()
			resource := res.Resource
			if sub := a.GetSubresource(); sub != "" {
				resource += "/" + sub
			}
			verb := a.GetVerb()
			if verb == "delete-collection" {
				verb = "deletecollection"
			}
			sent[rbacRequest{group: res.Group, resource: resource, verb: verb}] = true
		}
		if ready || err != nil {
			break
		}
	}
	return sent
}

// C6: every verb restore preparation sends through the dynamic client is
// granted by the backupstrategy-controller ClusterRole.
func TestVerifyRBAC_ClusterRoleGrantsEveryDynamicRequest(t *testing.T) {
	rules := rbacClusterRoleRules(t)

	scenarios := []rbacScenario{
		{name: "keepOriginalPVC=false", passes: 20},
		{name: "keepOriginalPVC=false with a DataVolume deletion still pending", pendingDelete: true, passes: 3},
		{name: "keepOriginalPVC=true", keep: true, passes: 20},
	}
	sent := map[rbacRequest][]string{}
	for _, sc := range scenarios {
		for q := range rbacCollect(t, sc) {
			sent[q] = append(sent[q], sc.name)
		}
	}

	touchedDataVolumes := false
	var missing []string
	for q, from := range sent {
		if q.group == dataVolumeGVR.Group && q.resource == dataVolumeGVR.Resource {
			touchedDataVolumes = true
		}
		if !rbacGranted(rules, q) {
			missing = append(missing, fmt.Sprintf("%s (sent in: %s)", q, strings.Join(from, "; ")))
		}
	}
	if !touchedDataVolumes {
		t.Fatal("restore preparation sent no DataVolume request through the dynamic client; the scenarios did not exercise the disk path")
	}
	sort.Strings(missing)
	for _, m := range missing {
		t.Errorf("the controller sends %s, which the backupstrategy-controller ClusterRole does not grant", m)
	}
}
