// Behavioral verifier for cozystack-fix-restore-pvc-deletion.
//
// This file is injected into internal/backupcontroller/ at run time and
// compiles as part of package backupcontroller, alongside the package's own
// sibling test files (it reuses their newTestRestoreJobReconcilerWithDynamic
// builder and its mockRESTMapper). The runner filters -run to this file's
// Test* functions.
//
// The tests drive the two package-level entry points the reconciler already
// exposes -- prepareForRestore and reconcileVeleroRestore -- and assert only on
// resulting object state (PVC existence/deletionTimestamp read back through the
// client, DataVolume presence through the dynamic client, RestoreJob phase, VM
// runStrategy through the dynamic client) and on whether preparation reports
// ready, returns an error, or asks to be requeued. They never reference the
// fix's internal helper names, never match on recorded Event strings, never
// require a particular requeue duration, and let an implementation take as
// many requeue passes as it likes. Preparation that has to stop may either
// return an error (which fails the RestoreJob) or requeue (which retries it):
// the package already does both for its preparation steps, so both pass. Any
// arrangement of the behavior -- inlined or renamed helpers, a single combined
// wait loop, the claim deleted in the same pass as its DataVolume or only once
// the DataVolume is gone, a point Get, a List or delete-only probing to see
// what is left, the up-front usability check folded elsewhere -- satisfies
// them.
package backupcontroller

import (
	"context"
	"encoding/json"
	"testing"

	corev1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	dynamicfake "k8s.io/client-go/dynamic/fake"
	"k8s.io/client-go/kubernetes/scheme"
	k8stesting "k8s.io/client-go/testing"
	"k8s.io/client-go/tools/record"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client"
	clientfake "sigs.k8s.io/controller-runtime/pkg/client/fake"

	strategyv1alpha1 "github.com/cozystack/cozystack/api/backups/strategy/v1alpha1"
	backupsv1alpha1 "github.com/cozystack/cozystack/api/backups/v1alpha1"
	velerov1 "github.com/vmware-tanzu/velero/pkg/apis/velero/v1"
)

// vfyDynamicKinds are the kinds the restore path reaches through the dynamic
// client. They are registered with their list kinds, so a fix that lists them
// rather than reading one back works against the fake.
var vfyDynamicKinds = map[schema.GroupVersionResource]string{
	dataVolumeGVR:     "DataVolume",
	virtualMachineGVR: "VirtualMachine",
	vmiGVR:            "VirtualMachineInstance",
	helmReleaseGVR:    "HelmRelease",
}

// vfyReconciler builds a RestoreJobReconciler on the package's own fake
// clients, swapping in a dynamic fake that can list every kind above and an
// event buffer deep enough that a multi-pass test never blocks on a full one.
func vfyReconciler(t *testing.T, dynamicObjects []runtime.Object, objects ...client.Object) *RestoreJobReconciler {
	t.Helper()
	r := newTestRestoreJobReconcilerWithDynamic(t, nil, objects...)
	s := runtime.NewScheme()
	for gvr, kind := range vfyDynamicKinds {
		s.AddKnownTypeWithName(gvr.GroupVersion().WithKind(kind), &unstructured.Unstructured{})
		s.AddKnownTypeWithName(gvr.GroupVersion().WithKind(kind+"List"), &unstructured.UnstructuredList{})
	}
	r.Interface = dynamicfake.NewSimpleDynamicClientWithCustomListKinds(s, nil, dynamicObjects...)
	r.Recorder = record.NewFakeRecorder(4096)
	return r
}

func vfyDynamicFake(r *RestoreJobReconciler) *dynamicfake.FakeDynamicClient {
	return r.Interface.(*dynamicfake.FakeDynamicClient)
}

// vfyRequeued reports whether a not-ready result asks to be retried.
func vfyRequeued(result ctrl.Result) bool {
	return result.RequeueAfter > 0 || result.Requeue //nolint:staticcheck // either way of asking counts
}

// vfyInPlaceNoKeep returns the inputs for an in-place VMInstance restore of a
// single disk (vm-disk-ubuntu-source) with keepOriginalPVC=false.
func vfyInPlaceNoKeep(ns string) (*backupsv1alpha1.RestoreJob, *backupsv1alpha1.Backup, *runtime.RawExtension, restoreTarget, RestoreOptions) {
	restoreJob := &backupsv1alpha1.RestoreJob{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "restore-test",
			Namespace: ns,
		},
		Spec: backupsv1alpha1.RestoreJobSpec{
			BackupRef: corev1.LocalObjectReference{Name: "my-backup"},
		},
	}

	backup := &backupsv1alpha1.Backup{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "my-backup",
			Namespace: ns,
		},
		Spec: backupsv1alpha1.BackupSpec{
			ApplicationRef: corev1.TypedLocalObjectReference{
				APIGroup: new("apps.cozystack.io"),
				Kind:     "VMInstance",
				Name:     "test-vm",
			},
		},
	}

	urData := vmInstanceResources{
		DataVolumes: []backupsv1alpha1.DataVolumeResource{
			{DataVolumeName: "vm-disk-ubuntu-source", ApplicationName: "ubuntu-source"},
		},
	}
	urRaw, _ := json.Marshal(urData)

	target := restoreTarget{
		Namespace: ns,
		AppName:   "test-vm",
		AppKind:   "VMInstance",
		IsCopy:    false,
	}

	return restoreJob, backup, &runtime.RawExtension{Raw: urRaw}, target, RestoreOptions{KeepOriginalPVC: new(false)}
}

// vfyMakeDataVolume builds an unstructured CDI DataVolume for the dynamic fake.
func vfyMakeDataVolume(name, namespace string) *unstructured.Unstructured {
	dv := &unstructured.Unstructured{}
	dv.SetAPIVersion("cdi.kubevirt.io/v1beta1")
	dv.SetKind("DataVolume")
	dv.SetName(name)
	dv.SetNamespace(namespace)
	return dv
}

// vfyDriveToReady calls prepareForRestore until it reports ready, tolerating any
// number of requeue cycles (an implementation may stage the deletions across
// reconciles). It fails if preparation errors, stalls without requesting a
// requeue, or never completes.
func vfyDriveToReady(t *testing.T, r *RestoreJobReconciler, rj *backupsv1alpha1.RestoreJob, b *backupsv1alpha1.Backup, ur *runtime.RawExtension, target restoreTarget, opts RestoreOptions) {
	t.Helper()
	ctx := context.Background()
	for i := 0; i < 20; i++ {
		ready, result, err := r.prepareForRestore(ctx, rj, b, ur, target, opts)
		if err != nil {
			t.Fatalf("prepareForRestore() error = %v", err)
		}
		if ready {
			return
		}
		if !vfyRequeued(result) {
			t.Fatalf("prepareForRestore() reported not-ready without requesting a requeue")
		}
	}
	t.Fatalf("prepareForRestore() never reached ready within the iteration budget")
}

// C1: an in-place keepOriginalPVC=false restore removes the original claim
// during preparation (so Velero recreates it from the backup) rather than
// leaving it in place, and it does not rename it to an -orig copy either.
func TestVerifyPrepareForRestore_KeepOriginalPVCFalse_DeletesPVC(t *testing.T) {
	ns := "tenant-root"
	restoreJob, backup, ur, target, opts := vfyInPlaceNoKeep(ns)

	pvc := &corev1.PersistentVolumeClaim{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "vm-disk-ubuntu-source",
			Namespace: ns,
		},
		Spec: corev1.PersistentVolumeClaimSpec{},
	}

	reconciler := vfyReconciler(t, nil, pvc, restoreJob, backup)
	vfyDriveToReady(t, reconciler, restoreJob, backup, ur, target, opts)

	ctx := context.Background()
	err := reconciler.Get(ctx, client.ObjectKey{Namespace: ns, Name: "vm-disk-ubuntu-source"}, &corev1.PersistentVolumeClaim{})
	if !errors.IsNotFound(err) {
		t.Errorf("original PVC should be gone before Velero restores it when keepOriginalPVC=false, got error: %v", err)
	}

	origSuffix := "-orig-" + shortHash(restoreJob.Name)
	err = reconciler.Get(ctx, client.ObjectKey{Namespace: ns, Name: "vm-disk-ubuntu-source" + origSuffix}, &corev1.PersistentVolumeClaim{})
	if err == nil {
		t.Error("no renamed -orig PVC should exist when keepOriginalPVC=false")
	}
}

// C2: preparation must not report ready while a claim it is removing is still
// terminating. A PVC held by the pvc-protection finalizer keeps preparation
// requeuing (and the claim is marked for deletion but still present); only once
// the claim is actually gone does preparation complete. The claim may be
// reached on any pass, but no pass may report ready while it is still there.
func TestVerifyPrepareForRestore_KeepOriginalPVCFalse_WaitsForTerminatingPVC(t *testing.T) {
	ns := "tenant-root"
	restoreJob, backup, ur, target, opts := vfyInPlaceNoKeep(ns)

	pvc := &corev1.PersistentVolumeClaim{
		ObjectMeta: metav1.ObjectMeta{
			Name:       "vm-disk-ubuntu-source",
			Namespace:  ns,
			Finalizers: []string{"kubernetes.io/pvc-protection"},
		},
		Spec: corev1.PersistentVolumeClaimSpec{},
	}

	reconciler := vfyReconciler(t, nil, pvc, restoreJob, backup)
	ctx := context.Background()
	key := client.ObjectKeyFromObject(pvc)

	stuck := &corev1.PersistentVolumeClaim{}
	for pass := 1; ; pass++ {
		ready, result, err := reconciler.prepareForRestore(ctx, restoreJob, backup, ur, target, opts)
		if err != nil {
			t.Fatalf("pass %d: prepareForRestore() error = %v", pass, err)
		}
		if ready {
			t.Fatalf("pass %d: expected not-ready while the PVC is still present, got ready", pass)
		}
		if !vfyRequeued(result) {
			t.Fatalf("pass %d: expected a requeue while the PVC is still present", pass)
		}
		if err := reconciler.Get(ctx, key, stuck); err != nil {
			t.Fatalf("pass %d: terminating PVC should still be readable: %v", pass, err)
		}
		if stuck.DeletionTimestamp != nil {
			break
		}
		if pass == 5 {
			t.Fatal("PVC was never marked for deletion while preparation waited")
		}
	}

	// Still terminating: another pass must keep holding the restore back.
	ready, result, err := reconciler.prepareForRestore(ctx, restoreJob, backup, ur, target, opts)
	if err != nil || ready || !vfyRequeued(result) {
		t.Fatalf("while the PVC is terminating: prepareForRestore() = ready %v, %+v, error %v; want a requeue", ready, result, err)
	}

	if err := reconciler.Get(ctx, key, stuck); err != nil {
		t.Fatalf("terminating PVC should still be readable: %v", err)
	}
	stuck.Finalizers = nil
	if err := reconciler.Update(ctx, stuck); err != nil {
		t.Fatalf("failed to release the PVC finalizer: %v", err)
	}

	vfyDriveToReady(t, reconciler, restoreJob, backup, ur, target, opts)
	if err := reconciler.Get(ctx, key, &corev1.PersistentVolumeClaim{}); !errors.IsNotFound(err) {
		t.Errorf("PVC should be gone once preparation completes, got error: %v", err)
	}
}

// C3: a disk's DataVolume has to be out of the way before the restore goes on
// (a surviving DataVolume makes CDI recreate the claim, which Velero then
// skips). A DataVolume that cannot be deleted stops preparation, by an error or
// by a requeue, without deleting the claim. A DataVolume still present after
// its delete keeps preparation requeuing, and preparation completes, claim
// gone, once the DataVolume is.
func TestVerifyPrepareForRestore_KeepOriginalPVCFalse_WaitsForDataVolume(t *testing.T) {
	t.Run("DataVolume deletion fails", func(t *testing.T) {
		ns := "tenant-root"
		restoreJob, backup, ur, target, opts := vfyInPlaceNoKeep(ns)
		pvc := &corev1.PersistentVolumeClaim{
			ObjectMeta: metav1.ObjectMeta{Name: "vm-disk-ubuntu-source", Namespace: ns},
		}
		reconciler := vfyReconciler(t,
			[]runtime.Object{vfyMakeDataVolume("vm-disk-ubuntu-source", ns)},
			pvc, restoreJob, backup)
		deleteErr := errors.NewForbidden(dataVolumeGVR.GroupResource(), "vm-disk-ubuntu-source", nil)
		vfyDynamicFake(reconciler).PrependReactor("delete", "datavolumes",
			func(k8stesting.Action) (bool, runtime.Object, error) {
				return true, nil, deleteErr
			})

		ctx := context.Background()
		for pass := 1; pass <= 3; pass++ {
			ready, result, err := reconciler.prepareForRestore(ctx, restoreJob, backup, ur, target, opts)
			if ready {
				t.Fatalf("pass %d: preparation reported ready although the DataVolume could not be deleted", pass)
			}
			if err != nil {
				break // the RestoreJob fails here; nothing runs after it
			}
			if !vfyRequeued(result) {
				t.Fatalf("pass %d: preparation neither failed nor asked to be retried after the DataVolume could not be deleted", pass)
			}
		}

		got := &corev1.PersistentVolumeClaim{}
		if err := reconciler.Get(ctx, client.ObjectKeyFromObject(pvc), got); err != nil {
			t.Fatalf("original PVC should survive when its DataVolume cannot be deleted: %v", err)
		}
		if got.DeletionTimestamp != nil {
			t.Error("original PVC should not be marked for deletion when its DataVolume cannot be deleted")
		}
	})

	t.Run("DataVolume still present after its delete", func(t *testing.T) {
		ns := "tenant-root"
		restoreJob, backup, ur, target, opts := vfyInPlaceNoKeep(ns)
		pvc := &corev1.PersistentVolumeClaim{
			ObjectMeta: metav1.ObjectMeta{Name: "vm-disk-ubuntu-source", Namespace: ns},
		}
		reconciler := vfyReconciler(t,
			[]runtime.Object{vfyMakeDataVolume("vm-disk-ubuntu-source", ns)},
			pvc, restoreJob, backup)
		// While pending, a delete is accepted but the DataVolume stays.
		pending := true
		vfyDynamicFake(reconciler).PrependReactor("delete", "datavolumes",
			func(k8stesting.Action) (bool, runtime.Object, error) {
				return pending, nil, nil
			})

		ctx := context.Background()
		for pass := 1; pass <= 3; pass++ {
			ready, result, err := reconciler.prepareForRestore(ctx, restoreJob, backup, ur, target, opts)
			if err != nil {
				t.Fatalf("pass %d: prepareForRestore() error = %v (a DataVolume deletion still in progress is not a failure)", pass, err)
			}
			if ready {
				t.Fatalf("pass %d: expected not-ready while the DataVolume is still present, got ready", pass)
			}
			if !vfyRequeued(result) {
				t.Fatalf("pass %d: expected a requeue while the DataVolume is still present", pass)
			}
		}

		// The deletion finishes.
		pending = false
		if err := vfyDynamicFake(reconciler).Tracker().Delete(dataVolumeGVR, ns, "vm-disk-ubuntu-source"); err != nil {
			t.Fatalf("finish the DataVolume deletion: %v", err)
		}
		vfyDriveToReady(t, reconciler, restoreJob, backup, ur, target, opts)
		if err := reconciler.Get(ctx, client.ObjectKeyFromObject(pvc), &corev1.PersistentVolumeClaim{}); !errors.IsNotFound(err) {
			t.Errorf("original PVC should be gone once preparation completes, got error: %v", err)
		}
	})
}

// C5 (regression guard): keepOriginalPVC=true must never delete the original
// claim, even when the rename that would preserve it fails (its bound PV is
// missing) and leaves the claim under its original name.
func TestVerifyPrepareForRestore_KeepOriginalPVCTrue_FailedRenameKeepsPVC(t *testing.T) {
	ns := "tenant-root"
	restoreJob, backup, ur, target, _ := vfyInPlaceNoKeep(ns)
	opts := RestoreOptions{KeepOriginalPVC: new(true)}

	pvc := &corev1.PersistentVolumeClaim{
		ObjectMeta: metav1.ObjectMeta{Name: "vm-disk-ubuntu-source", Namespace: ns},
		// The bound PV does not exist, so the rename fails before touching the claim.
		Spec: corev1.PersistentVolumeClaimSpec{VolumeName: "pv-missing"},
	}
	reconciler := vfyReconciler(t, nil, pvc, restoreJob, backup)

	ctx := context.Background()
	if _, _, err := reconciler.prepareForRestore(ctx, restoreJob, backup, ur, target, opts); err != nil {
		t.Fatalf("prepareForRestore() error = %v", err)
	}

	if err := reconciler.Get(ctx, client.ObjectKeyFromObject(pvc), &corev1.PersistentVolumeClaim{}); err != nil {
		t.Errorf("original PVC should survive a failed rename when keepOriginalPVC=true, got error: %v", err)
	}
}

// C4: a restore whose referenced Velero Backup is unusable (missing/expired, or
// being deleted) must fail the RestoreJob before preparation halts the VM or
// touches any disk, whether or not it keeps the original claims. The VM
// runStrategy, the DataVolume and the PVC are all left untouched, and no -orig
// copy is made. The RestoreJob may take a few reconciles to fail.
func TestVerifyReconcileVeleroRestore_UnusableVeleroBackupTouchesNothing(t *testing.T) {
	deleting := &velerov1.Backup{
		ObjectMeta: metav1.ObjectMeta{Name: "vb", Namespace: veleroNamespace},
		Status:     velerov1.BackupStatus{Phase: velerov1.BackupPhaseDeleting},
	}
	tests := []struct {
		name         string
		veleroBackup *velerov1.Backup
		keep         bool
	}{
		{name: "Velero Backup expired"},
		{name: "Velero Backup being deleted", veleroBackup: deleting},
		{name: "Velero Backup expired, keepOriginalPVC=true", keep: true},
		{name: "Velero Backup being deleted, keepOriginalPVC=true", veleroBackup: deleting, keep: true},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ns := "tenant-root"
			restoreJob, backup, ur, _, _ := vfyInPlaceNoKeep(ns)
			rawOpts, err := json.Marshal(RestoreOptions{KeepOriginalPVC: new(tt.keep)})
			if err != nil {
				t.Fatalf("marshal options: %v", err)
			}
			started := metav1.Now()
			restoreJob.Spec.Options = &runtime.RawExtension{Raw: rawOpts}
			restoreJob.Status = backupsv1alpha1.RestoreJobStatus{
				Phase:     backupsv1alpha1.RestoreJobPhaseRunning,
				StartedAt: &started,
			}
			backup.Spec.StrategyRef = corev1.TypedLocalObjectReference{Kind: "Velero", Name: "cozy-default-velero"}
			backup.Spec.DriverMetadata = map[string]string{veleroBackupNameMetadataKey: "vb"}
			backup.Status.UnderlyingResources = ur

			pvc := &corev1.PersistentVolumeClaim{
				ObjectMeta: metav1.ObjectMeta{Name: "vm-disk-ubuntu-source", Namespace: ns},
			}
			strategy := &strategyv1alpha1.Velero{ObjectMeta: metav1.ObjectMeta{Name: "cozy-default-velero"}}
			objs := []client.Object{restoreJob, backup, pvc, strategy}
			if tt.veleroBackup != nil {
				objs = append(objs, tt.veleroBackup.DeepCopy())
			}

			vm := &unstructured.Unstructured{}
			vm.SetAPIVersion("kubevirt.io/v1")
			vm.SetKind("VirtualMachine")
			vm.SetName(vmNamePrefix + "test-vm")
			vm.SetNamespace(ns)
			if err := unstructured.SetNestedField(vm.Object, "Always", "spec", "runStrategy"); err != nil {
				t.Fatalf("set runStrategy: %v", err)
			}

			reconciler := vfyReconciler(t,
				[]runtime.Object{vm, vfyMakeDataVolume("vm-disk-ubuntu-source", ns)})

			testScheme := runtime.NewScheme()
			_ = scheme.AddToScheme(testScheme)
			_ = backupsv1alpha1.AddToScheme(testScheme)
			_ = velerov1.AddToScheme(testScheme)
			_ = strategyv1alpha1.AddToScheme(testScheme)
			reconciler.Client = clientfake.NewClientBuilder().
				WithScheme(testScheme).
				WithObjects(objs...).
				WithStatusSubresource(&backupsv1alpha1.RestoreJob{}).
				Build()

			ctx := context.Background()
			key := client.ObjectKeyFromObject(restoreJob)
			got := &backupsv1alpha1.RestoreJob{}
			var lastErr error
			for pass := 1; pass <= 3; pass++ {
				if err := reconciler.Get(ctx, key, got); err != nil {
					t.Fatalf("get RestoreJob: %v", err)
				}
				if got.Status.Phase == backupsv1alpha1.RestoreJobPhaseFailed {
					break
				}
				// A returned error is retried by controller-runtime, like a requeue.
				_, lastErr = reconciler.reconcileVeleroRestore(ctx, got, backup)
			}

			if err := reconciler.Get(ctx, key, got); err != nil {
				t.Fatalf("get RestoreJob: %v", err)
			}
			if got.Status.Phase != backupsv1alpha1.RestoreJobPhaseFailed {
				t.Fatalf("RestoreJob phase = %q, want %q (last reconcile error: %v)", got.Status.Phase, backupsv1alpha1.RestoreJobPhaseFailed, lastErr)
			}

			if err := reconciler.Get(ctx, client.ObjectKeyFromObject(pvc), &corev1.PersistentVolumeClaim{}); err != nil {
				t.Errorf("original PVC should survive a restore that cannot run: %v", err)
			}
			origName := "vm-disk-ubuntu-source-orig-" + shortHash(restoreJob.Name)
			if err := reconciler.Get(ctx, client.ObjectKey{Namespace: ns, Name: origName}, &corev1.PersistentVolumeClaim{}); err == nil {
				t.Errorf("no -orig PVC should be made for a restore that cannot run")
			}
			if _, err := reconciler.Resource(dataVolumeGVR).Namespace(ns).Get(ctx, "vm-disk-ubuntu-source", metav1.GetOptions{}); err != nil {
				t.Errorf("DataVolume should survive a restore that cannot run: %v", err)
			}
			gotVM, err := reconciler.Resource(virtualMachineGVR).Namespace(ns).Get(ctx, vm.GetName(), metav1.GetOptions{})
			if err != nil {
				t.Fatalf("get VirtualMachine: %v", err)
			}
			if rs, _, _ := unstructured.NestedString(gotVM.Object, "spec", "runStrategy"); rs != "Always" {
				t.Errorf("VirtualMachine runStrategy = %q, want it left at %q", rs, "Always")
			}
		})
	}
}
