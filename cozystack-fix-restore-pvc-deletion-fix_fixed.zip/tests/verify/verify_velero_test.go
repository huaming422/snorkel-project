// Behavioral verifier for cozystack-fix-restore-pvc-deletion.
//
// This file is injected into internal/backupcontroller/ at run time and
// compiles as part of package backupcontroller, alongside the package's own
// sibling test files (it reuses their newTestRestoreJobReconcilerWithDynamic
// builder and its mockRESTMapper). The runner filters -run to this file's
// Test* functions.
//
// The tests call the package's prepareForRestore and reconcileVeleroRestore
// against in-memory fake clients. They check object state fetched through
// those clients (claims, DataVolumes, the VirtualMachine, Velero Restores and
// the RestoreJob phase) and whether preparation reports ready, returns an
// error or asks to be requeued. Where preparation has to stop, returning an
// error and asking for a requeue both count as stopping. No test looks at
// event text, a requeue delay or how many passes preparation takes.
package backupcontroller

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"testing"
	"time"

	corev1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	dynamicfake "k8s.io/client-go/dynamic/fake"
	"k8s.io/client-go/kubernetes/scheme"
	k8stesting "k8s.io/client-go/testing"
	"k8s.io/client-go/tools/record"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client"
	clientfake "sigs.k8s.io/controller-runtime/pkg/client/fake"
	"sigs.k8s.io/controller-runtime/pkg/client/interceptor"

	strategyv1alpha1 "github.com/cozystack/cozystack/api/backups/strategy/v1alpha1"
	backupsv1alpha1 "github.com/cozystack/cozystack/api/backups/v1alpha1"
	velerov1 "github.com/vmware-tanzu/velero/pkg/apis/velero/v1"
)

var vfyVeleroBackupGVR = schema.GroupVersionResource{Group: "velero.io", Version: "v1", Resource: "backups"}

// vfyDynamicKinds are the kinds the dynamic fake serves, registered with their
// list kinds so List requests work against it too. Velero Backups are served
// here as well as by the typed fake, as both clients reach the same API server.
var vfyDynamicKinds = map[schema.GroupVersionResource]string{
	dataVolumeGVR:      "DataVolume",
	virtualMachineGVR:  "VirtualMachine",
	vmiGVR:             "VirtualMachineInstance",
	helmReleaseGVR:     "HelmRelease",
	vfyVeleroBackupGVR: "Backup",
}

// vfyReconciler builds a RestoreJobReconciler on the package's own fake
// clients, swapping in a dynamic fake that can list every kind above and an
// event buffer deep enough that a multi-pass test never blocks on a full one.
func vfyReconciler(t *testing.T, dynamicObjects []runtime.Object, objects ...client.Object) *RestoreJobReconciler {
	t.Helper()
	r := newTestRestoreJobReconcilerWithDynamic(t, nil, objects...)
	s := runtime.NewScheme()
	for gvr, kind := range vfyDynamicKinds {
		s.AddKnownTypeWithName(gvr.GroupVersion().WithKind(kind), &unstructured.Unstructured{})
		s.AddKnownTypeWithName(gvr.GroupVersion().WithKind(kind+"List"), &unstructured.UnstructuredList{})
	}
	r.Interface = dynamicfake.NewSimpleDynamicClientWithCustomListKinds(s, nil, dynamicObjects...)
	r.Recorder = record.NewFakeRecorder(4096)
	return r
}

func vfyDynamicFake(r *RestoreJobReconciler) *dynamicfake.FakeDynamicClient {
	return r.Interface.(*dynamicfake.FakeDynamicClient)
}

// vfyRequeued reports whether a not-ready result asks to be retried.
func vfyRequeued(result ctrl.Result) bool {
	return result.RequeueAfter > 0 || result.Requeue //nolint:staticcheck // either way of asking counts
}

// vfyRefuseClaimDeletes wraps a fake typed client so that every claim delete
// is refused with Forbidden. Everything else passes through.
func vfyRefuseClaimDeletes(t *testing.T, c client.Client) client.Client {
	t.Helper()
	ww, ok := c.(client.WithWatch)
	if !ok {
		t.Fatalf("typed client is %T, want a fake client.WithWatch", c)
	}
	refuse := func(obj client.Object) error {
		if _, isClaim := obj.(*corev1.PersistentVolumeClaim); isClaim {
			return errors.NewForbidden(corev1.Resource("persistentvolumeclaims"), obj.GetName(), fmt.Errorf("delete refused by the test"))
		}
		return nil
	}
	return interceptor.NewClient(ww, interceptor.Funcs{
		Delete: func(ctx context.Context, c client.WithWatch, obj client.Object, opts ...client.DeleteOption) error {
			if err := refuse(obj); err != nil {
				return err
			}
			return c.Delete(ctx, obj, opts...)
		},
		DeleteAllOf: func(ctx context.Context, c client.WithWatch, obj client.Object, opts ...client.DeleteAllOfOption) error {
			if err := refuse(obj); err != nil {
				return err
			}
			return c.DeleteAllOf(ctx, obj, opts...)
		},
	})
}

// vfyInPlaceNoKeep returns the inputs for an in-place VMInstance restore of a
// single disk (vm-disk-ubuntu-source) with keepOriginalPVC=false.
func vfyInPlaceNoKeep(ns string) (*backupsv1alpha1.RestoreJob, *backupsv1alpha1.Backup, *runtime.RawExtension, restoreTarget, RestoreOptions) {
	restoreJob := &backupsv1alpha1.RestoreJob{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "restore-test",
			Namespace: ns,
		},
		Spec: backupsv1alpha1.RestoreJobSpec{
			BackupRef: corev1.LocalObjectReference{Name: "my-backup"},
		},
	}

	backup := &backupsv1alpha1.Backup{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "my-backup",
			Namespace: ns,
		},
		Spec: backupsv1alpha1.BackupSpec{
			ApplicationRef: corev1.TypedLocalObjectReference{
				APIGroup: new("apps.cozystack.io"),
				Kind:     "VMInstance",
				Name:     "test-vm",
			},
		},
	}

	target := restoreTarget{
		Namespace: ns,
		AppName:   "test-vm",
		AppKind:   "VMInstance",
		IsCopy:    false,
	}

	return restoreJob, backup, vfyDisks("vm-disk-ubuntu-source"), target, RestoreOptions{KeepOriginalPVC: new(false)}
}

// vfyDisks returns the underlying resources of a VMInstance whose disks have
// the given DataVolume names.
func vfyDisks(names ...string) *runtime.RawExtension {
	var res vmInstanceResources
	for _, name := range names {
		res.DataVolumes = append(res.DataVolumes, backupsv1alpha1.DataVolumeResource{
			DataVolumeName:  name,
			ApplicationName: strings.TrimPrefix(name, "vm-disk-"),
		})
	}
	raw, _ := json.Marshal(res)
	return &runtime.RawExtension{Raw: raw}
}

// vfyMakeDataVolume builds an unstructured CDI DataVolume for the dynamic fake.
func vfyMakeDataVolume(name, namespace string) *unstructured.Unstructured {
	dv := &unstructured.Unstructured{}
	dv.SetAPIVersion("cdi.kubevirt.io/v1beta1")
	dv.SetKind("DataVolume")
	dv.SetName(name)
	dv.SetNamespace(namespace)
	return dv
}

// vfyDriveToReady calls prepareForRestore until it reports ready, tolerating any
// number of requeue cycles. It fails if preparation errors, stalls without
// requesting a requeue, or never completes.
func vfyDriveToReady(t *testing.T, r *RestoreJobReconciler, rj *backupsv1alpha1.RestoreJob, b *backupsv1alpha1.Backup, ur *runtime.RawExtension, target restoreTarget, opts RestoreOptions) {
	t.Helper()
	ctx := context.Background()
	for i := 0; i < 20; i++ {
		ready, result, err := r.prepareForRestore(ctx, rj, b, ur, target, opts)
		if err != nil {
			t.Fatalf("prepareForRestore() error = %v", err)
		}
		if ready {
			return
		}
		if !vfyRequeued(result) {
			t.Fatalf("prepareForRestore() reported not-ready without requesting a requeue")
		}
	}
	t.Fatalf("prepareForRestore() never reached ready within the iteration budget")
}

// C1: once preparation for an in-place keepOriginalPVC=false restore reports
// ready, the original claim is gone, and no -orig copy of it was made.
func TestVerifyPrepareForRestore_KeepOriginalPVCFalse_DeletesPVC(t *testing.T) {
	ns := "tenant-root"
	restoreJob, backup, ur, target, opts := vfyInPlaceNoKeep(ns)

	pvc := &corev1.PersistentVolumeClaim{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "vm-disk-ubuntu-source",
			Namespace: ns,
		},
		Spec: corev1.PersistentVolumeClaimSpec{},
	}

	reconciler := vfyReconciler(t, nil, pvc, restoreJob, backup)
	vfyDriveToReady(t, reconciler, restoreJob, backup, ur, target, opts)

	ctx := context.Background()
	err := reconciler.Get(ctx, client.ObjectKey{Namespace: ns, Name: "vm-disk-ubuntu-source"}, &corev1.PersistentVolumeClaim{})
	if !errors.IsNotFound(err) {
		t.Errorf("original PVC should be gone before Velero restores it when keepOriginalPVC=false, got error: %v", err)
	}

	origSuffix := "-orig-" + shortHash(restoreJob.Name)
	err = reconciler.Get(ctx, client.ObjectKey{Namespace: ns, Name: "vm-disk-ubuntu-source" + origSuffix}, &corev1.PersistentVolumeClaim{})
	if err == nil {
		t.Error("no renamed -orig PVC should exist when keepOriginalPVC=false")
	}
}

// C2: preparation must not report ready while the claim is still terminating.
// The claim here carries the pvc-protection finalizer, so it stays readable
// with a deletionTimestamp once deleted. Every pass until then has to requeue,
// and preparation completes, claim gone, after the finalizer is released.
func TestVerifyPrepareForRestore_KeepOriginalPVCFalse_WaitsForTerminatingPVC(t *testing.T) {
	ns := "tenant-root"
	restoreJob, backup, ur, target, opts := vfyInPlaceNoKeep(ns)

	pvc := &corev1.PersistentVolumeClaim{
		ObjectMeta: metav1.ObjectMeta{
			Name:       "vm-disk-ubuntu-source",
			Namespace:  ns,
			Finalizers: []string{"kubernetes.io/pvc-protection"},
		},
		Spec: corev1.PersistentVolumeClaimSpec{},
	}

	reconciler := vfyReconciler(t, nil, pvc, restoreJob, backup)
	ctx := context.Background()
	key := client.ObjectKeyFromObject(pvc)

	stuck := &corev1.PersistentVolumeClaim{}
	for pass := 1; ; pass++ {
		ready, result, err := reconciler.prepareForRestore(ctx, restoreJob, backup, ur, target, opts)
		if err != nil {
			t.Fatalf("pass %d: prepareForRestore() error = %v", pass, err)
		}
		if ready {
			t.Fatalf("pass %d: expected not-ready while the PVC is still present, got ready", pass)
		}
		if !vfyRequeued(result) {
			t.Fatalf("pass %d: expected a requeue while the PVC is still present", pass)
		}
		if err := reconciler.Get(ctx, key, stuck); err != nil {
			t.Fatalf("pass %d: terminating PVC should still be readable: %v", pass, err)
		}
		if stuck.DeletionTimestamp != nil {
			break
		}
		if pass == 5 {
			t.Fatal("PVC was never marked for deletion while preparation waited")
		}
	}

	// Still terminating: another pass must keep holding the restore back.
	ready, result, err := reconciler.prepareForRestore(ctx, restoreJob, backup, ur, target, opts)
	if err != nil || ready || !vfyRequeued(result) {
		t.Fatalf("while the PVC is terminating: prepareForRestore() = ready %v, %+v, error %v; want a requeue", ready, result, err)
	}

	if err := reconciler.Get(ctx, key, stuck); err != nil {
		t.Fatalf("terminating PVC should still be readable: %v", err)
	}
	stuck.Finalizers = nil
	if err := reconciler.Update(ctx, stuck); err != nil {
		t.Fatalf("failed to release the PVC finalizer: %v", err)
	}

	vfyDriveToReady(t, reconciler, restoreJob, backup, ur, target, opts)
	if err := reconciler.Get(ctx, key, &corev1.PersistentVolumeClaim{}); !errors.IsNotFound(err) {
		t.Errorf("PVC should be gone once preparation completes, got error: %v", err)
	}
}

// C3: preparation must not report ready while the disk's DataVolume is still
// there. A DataVolume that cannot be deleted stops preparation without the
// claim being deleted. A DataVolume still present after its delete keeps
// preparation requeuing, and preparation completes, claim gone, once the
// DataVolume is gone.
func TestVerifyPrepareForRestore_KeepOriginalPVCFalse_WaitsForDataVolume(t *testing.T) {
	t.Run("DataVolume deletion fails", func(t *testing.T) {
		ns := "tenant-root"
		restoreJob, backup, ur, target, opts := vfyInPlaceNoKeep(ns)
		pvc := &corev1.PersistentVolumeClaim{
			ObjectMeta: metav1.ObjectMeta{Name: "vm-disk-ubuntu-source", Namespace: ns},
		}
		reconciler := vfyReconciler(t,
			[]runtime.Object{vfyMakeDataVolume("vm-disk-ubuntu-source", ns)},
			pvc, restoreJob, backup)
		deleteErr := errors.NewForbidden(dataVolumeGVR.GroupResource(), "vm-disk-ubuntu-source", nil)
		vfyDynamicFake(reconciler).PrependReactor("delete", "datavolumes",
			func(k8stesting.Action) (bool, runtime.Object, error) {
				return true, nil, deleteErr
			})

		ctx := context.Background()
		for pass := 1; pass <= 3; pass++ {
			ready, result, err := reconciler.prepareForRestore(ctx, restoreJob, backup, ur, target, opts)
			if ready {
				t.Fatalf("pass %d: preparation reported ready although the DataVolume could not be deleted", pass)
			}
			if err != nil {
				break // the RestoreJob fails here; nothing runs after it
			}
			if !vfyRequeued(result) {
				t.Fatalf("pass %d: preparation neither failed nor asked to be retried after the DataVolume could not be deleted", pass)
			}
		}

		got := &corev1.PersistentVolumeClaim{}
		if err := reconciler.Get(ctx, client.ObjectKeyFromObject(pvc), got); err != nil {
			t.Fatalf("original PVC should survive when its DataVolume cannot be deleted: %v", err)
		}
		if got.DeletionTimestamp != nil {
			t.Error("original PVC should not be marked for deletion when its DataVolume cannot be deleted")
		}
	})

	t.Run("DataVolume still present after its delete", func(t *testing.T) {
		ns := "tenant-root"
		restoreJob, backup, ur, target, opts := vfyInPlaceNoKeep(ns)
		pvc := &corev1.PersistentVolumeClaim{
			ObjectMeta: metav1.ObjectMeta{Name: "vm-disk-ubuntu-source", Namespace: ns},
		}
		reconciler := vfyReconciler(t,
			[]runtime.Object{vfyMakeDataVolume("vm-disk-ubuntu-source", ns)},
			pvc, restoreJob, backup)
		// While pending, a delete is accepted but the DataVolume stays.
		pending := true
		vfyDynamicFake(reconciler).PrependReactor("delete", "datavolumes",
			func(k8stesting.Action) (bool, runtime.Object, error) {
				return pending, nil, nil
			})

		ctx := context.Background()
		for pass := 1; pass <= 3; pass++ {
			ready, result, err := reconciler.prepareForRestore(ctx, restoreJob, backup, ur, target, opts)
			if err != nil {
				t.Fatalf("pass %d: prepareForRestore() error = %v (a DataVolume deletion still in progress is not a failure)", pass, err)
			}
			if ready {
				t.Fatalf("pass %d: expected not-ready while the DataVolume is still present, got ready", pass)
			}
			if !vfyRequeued(result) {
				t.Fatalf("pass %d: expected a requeue while the DataVolume is still present", pass)
			}
		}

		// The deletion finishes.
		pending = false
		if err := vfyDynamicFake(reconciler).Tracker().Delete(dataVolumeGVR, ns, "vm-disk-ubuntu-source"); err != nil {
			t.Fatalf("finish the DataVolume deletion: %v", err)
		}
		vfyDriveToReady(t, reconciler, restoreJob, backup, ur, target, opts)
		if err := reconciler.Get(ctx, client.ObjectKeyFromObject(pvc), &corev1.PersistentVolumeClaim{}); !errors.IsNotFound(err) {
			t.Errorf("original PVC should be gone once preparation completes, got error: %v", err)
		}
	})
}

// C7: a claim that cannot be deleted stops preparation. Every delete of it is
// refused, and no pass may report ready while it is still there.
func TestVerifyPrepareForRestore_KeepOriginalPVCFalse_FailedClaimDeletionStops(t *testing.T) {
	ns := "tenant-root"
	restoreJob, backup, ur, target, opts := vfyInPlaceNoKeep(ns)
	pvc := &corev1.PersistentVolumeClaim{
		ObjectMeta: metav1.ObjectMeta{Name: "vm-disk-ubuntu-source", Namespace: ns},
	}
	reconciler := vfyReconciler(t,
		[]runtime.Object{vfyMakeDataVolume("vm-disk-ubuntu-source", ns)},
		pvc, restoreJob, backup)
	reconciler.Client = vfyRefuseClaimDeletes(t, reconciler.Client)

	ctx := context.Background()
	for pass := 1; pass <= 3; pass++ {
		ready, result, err := reconciler.prepareForRestore(ctx, restoreJob, backup, ur, target, opts)
		if ready {
			t.Fatalf("pass %d: preparation reported ready although the PVC could not be deleted and is still there", pass)
		}
		if err != nil {
			break // the RestoreJob fails here; nothing runs after it
		}
		if !vfyRequeued(result) {
			t.Fatalf("pass %d: preparation neither failed nor asked to be retried after the PVC could not be deleted", pass)
		}
	}

	if err := reconciler.Get(ctx, client.ObjectKeyFromObject(pvc), &corev1.PersistentVolumeClaim{}); err != nil {
		t.Errorf("PVC should still be there after every delete of it was refused: %v", err)
	}
}

// C9: with two disks, preparation removes the claim and the DataVolume of
// each, and it does not report ready while any one of them is still there.
// Each wait is tried with either disk as the one still there.
func TestVerifyPrepareForRestore_KeepOriginalPVCFalse_EveryDisk(t *testing.T) {
	ns := "tenant-root"
	disks := []string{"vm-disk-ubuntu-source", "vm-disk-data"}
	ctx := context.Background()

	// setup seeds a claim and a DataVolume for each disk. The claim of the
	// disk named held carries the pvc-protection finalizer. It returns the
	// reconciler, one preparation pass, and a run of passes up to ready.
	setup := func(t *testing.T, held string) (*RestoreJobReconciler, func() (bool, ctrl.Result, error), func()) {
		t.Helper()
		restoreJob, backup, _, target, opts := vfyInPlaceNoKeep(ns)
		ur := vfyDisks(disks...)
		objs := []client.Object{restoreJob, backup}
		var dataVolumes []runtime.Object
		for _, disk := range disks {
			pvc := &corev1.PersistentVolumeClaim{ObjectMeta: metav1.ObjectMeta{Name: disk, Namespace: ns}}
			if disk == held {
				pvc.Finalizers = []string{"kubernetes.io/pvc-protection"}
			}
			objs = append(objs, pvc)
			dataVolumes = append(dataVolumes, vfyMakeDataVolume(disk, ns))
		}
		r := vfyReconciler(t, dataVolumes, objs...)
		prepare := func() (bool, ctrl.Result, error) {
			return r.prepareForRestore(ctx, restoreJob, backup, ur, target, opts)
		}
		driveToReady := func() { vfyDriveToReady(t, r, restoreJob, backup, ur, target, opts) }
		return r, prepare, driveToReady
	}

	allGone := func(t *testing.T, r *RestoreJobReconciler, scenario string) {
		t.Helper()
		for _, disk := range disks {
			if err := r.Get(ctx, client.ObjectKey{Namespace: ns, Name: disk}, &corev1.PersistentVolumeClaim{}); !errors.IsNotFound(err) {
				t.Errorf("%s: PVC %s should be gone once preparation completes, got error: %v", scenario, disk, err)
			}
			if _, err := r.Resource(dataVolumeGVR).Namespace(ns).Get(ctx, disk, metav1.GetOptions{}); !errors.IsNotFound(err) {
				t.Errorf("%s: DataVolume %s should be gone once preparation completes, got error: %v", scenario, disk, err)
			}
		}
	}

	t.Run("every claim and DataVolume is removed", func(t *testing.T) {
		r, _, driveToReady := setup(t, "")
		driveToReady()
		allGone(t, r, "two disks")
	})

	t.Run("waits for every claim", func(t *testing.T) {
		for _, held := range disks {
			scenario := "PVC " + held + " terminating"
			r, prepare, driveToReady := setup(t, held)
			key := client.ObjectKey{Namespace: ns, Name: held}
			claim := &corev1.PersistentVolumeClaim{}
			for pass := 1; ; pass++ {
				ready, result, err := prepare()
				if err != nil {
					t.Fatalf("%s: pass %d: prepareForRestore() error = %v", scenario, pass, err)
				}
				if ready {
					t.Fatalf("%s: pass %d: preparation reported ready while that PVC is still there", scenario, pass)
				}
				if !vfyRequeued(result) {
					t.Fatalf("%s: pass %d: expected a requeue while that PVC is still there", scenario, pass)
				}
				if err := r.Get(ctx, key, claim); err != nil {
					t.Fatalf("%s: pass %d: the terminating PVC should still be readable: %v", scenario, pass, err)
				}
				if claim.DeletionTimestamp != nil {
					break
				}
				if pass == 5 {
					t.Fatalf("%s: that PVC was never marked for deletion while preparation waited", scenario)
				}
			}
			if ready, result, err := prepare(); err != nil || ready || !vfyRequeued(result) {
				t.Fatalf("%s: prepareForRestore() = ready %v, %+v, error %v; want a requeue", scenario, ready, result, err)
			}
			if err := r.Get(ctx, key, claim); err != nil {
				t.Fatalf("%s: the terminating PVC should still be readable: %v", scenario, err)
			}
			claim.Finalizers = nil
			if err := r.Update(ctx, claim); err != nil {
				t.Fatalf("%s: failed to release the PVC finalizer: %v", scenario, err)
			}
			driveToReady()
			allGone(t, r, scenario)
		}
	})

	t.Run("waits for every DataVolume", func(t *testing.T) {
		for _, held := range disks {
			scenario := "DataVolume " + held + " still deleting"
			r, prepare, driveToReady := setup(t, "")
			// While pending, a delete of that one DataVolume is accepted but it stays.
			pending := true
			vfyDynamicFake(r).PrependReactor("delete", "datavolumes",
				func(a k8stesting.Action) (bool, runtime.Object, error) {
					del, ok := a.(k8stesting.DeleteAction)
					return pending && ok && del.GetName() == held, nil, nil
				})
			for pass := 1; pass <= 3; pass++ {
				ready, result, err := prepare()
				if err != nil {
					t.Fatalf("%s: pass %d: prepareForRestore() error = %v (a DataVolume deletion still in progress is not a failure)", scenario, pass, err)
				}
				if ready {
					t.Fatalf("%s: pass %d: preparation reported ready while that DataVolume is still there", scenario, pass)
				}
				if !vfyRequeued(result) {
					t.Fatalf("%s: pass %d: expected a requeue while that DataVolume is still there", scenario, pass)
				}
			}
			pending = false
			if err := vfyDynamicFake(r).Tracker().Delete(dataVolumeGVR, ns, held); err != nil {
				t.Fatalf("%s: finish the DataVolume deletion: %v", scenario, err)
			}
			driveToReady()
			allGone(t, r, scenario)
		}
	})
}

// C5: keepOriginalPVC=true must never delete the original claim, even when the
// rename that would preserve it fails (its bound PV is missing) and leaves the
// claim under its original name.
func TestVerifyPrepareForRestore_KeepOriginalPVCTrue_FailedRenameKeepsPVC(t *testing.T) {
	ns := "tenant-root"
	restoreJob, backup, ur, target, _ := vfyInPlaceNoKeep(ns)
	opts := RestoreOptions{KeepOriginalPVC: new(true)}

	pvc := &corev1.PersistentVolumeClaim{
		ObjectMeta: metav1.ObjectMeta{Name: "vm-disk-ubuntu-source", Namespace: ns},
		// The bound PV does not exist, so the rename fails before touching the claim.
		Spec: corev1.PersistentVolumeClaimSpec{VolumeName: "pv-missing"},
	}
	reconciler := vfyReconciler(t, nil, pvc, restoreJob, backup)

	ctx := context.Background()
	if _, _, err := reconciler.prepareForRestore(ctx, restoreJob, backup, ur, target, opts); err != nil {
		t.Fatalf("prepareForRestore() error = %v", err)
	}

	if err := reconciler.Get(ctx, client.ObjectKeyFromObject(pvc), &corev1.PersistentVolumeClaim{}); err != nil {
		t.Errorf("original PVC should survive a failed rename when keepOriginalPVC=true, got error: %v", err)
	}
}

// vfyRestore is an in-place restore of VMInstance test-vm, set up for
// reconcileVeleroRestore: a Running RestoreJob, its Backup pointing at Velero
// Backup vb, the Velero strategy, a VirtualMachine with runStrategy Always, and
// one disk (vm-disk-ubuntu-source) with a DataVolume and a claim bound to a PV.
type vfyRestore struct {
	r          *RestoreJobReconciler
	restoreJob *backupsv1alpha1.RestoreJob
	backup     *backupsv1alpha1.Backup
	pvc        *corev1.PersistentVolumeClaim
	vm         *unstructured.Unstructured
}

// vfyNewRestore builds a vfyRestore. veleroBackup, when not nil, is seeded into
// both the typed and the dynamic fake.
func vfyNewRestore(t *testing.T, keep bool, veleroBackup *velerov1.Backup) *vfyRestore {
	t.Helper()
	ns := "tenant-root"
	restoreJob, backup, ur, _, _ := vfyInPlaceNoKeep(ns)
	rawOpts, err := json.Marshal(RestoreOptions{KeepOriginalPVC: new(keep)})
	if err != nil {
		t.Fatalf("marshal options: %v", err)
	}
	started := metav1.Now()
	restoreJob.Spec.Options = &runtime.RawExtension{Raw: rawOpts}
	restoreJob.Status = backupsv1alpha1.RestoreJobStatus{
		Phase:     backupsv1alpha1.RestoreJobPhaseRunning,
		StartedAt: &started,
	}
	backup.Spec.StrategyRef = corev1.TypedLocalObjectReference{Kind: "Velero", Name: "cozy-default-velero"}
	backup.Spec.DriverMetadata = map[string]string{veleroBackupNameMetadataKey: "vb"}
	backup.Status.UnderlyingResources = ur

	pv := &corev1.PersistentVolume{
		ObjectMeta: metav1.ObjectMeta{Name: "pv-vm-disk-ubuntu-source"},
		Spec: corev1.PersistentVolumeSpec{
			PersistentVolumeReclaimPolicy: corev1.PersistentVolumeReclaimDelete,
			ClaimRef: &corev1.ObjectReference{
				APIVersion: "v1",
				Kind:       "PersistentVolumeClaim",
				Namespace:  ns,
				Name:       "vm-disk-ubuntu-source",
			},
		},
	}
	pvc := &corev1.PersistentVolumeClaim{
		ObjectMeta: metav1.ObjectMeta{Name: "vm-disk-ubuntu-source", Namespace: ns},
		Spec:       corev1.PersistentVolumeClaimSpec{VolumeName: pv.Name},
	}
	strategy := &strategyv1alpha1.Velero{ObjectMeta: metav1.ObjectMeta{Name: "cozy-default-velero"}}
	objs := []client.Object{restoreJob, backup, pvc, pv, strategy}

	vm := &unstructured.Unstructured{}
	vm.SetAPIVersion("kubevirt.io/v1")
	vm.SetKind("VirtualMachine")
	vm.SetName(vmNamePrefix + "test-vm")
	vm.SetNamespace(ns)
	if err := unstructured.SetNestedField(vm.Object, "Always", "spec", "runStrategy"); err != nil {
		t.Fatalf("set runStrategy: %v", err)
	}
	dynamicObjs := []runtime.Object{vm, vfyMakeDataVolume("vm-disk-ubuntu-source", ns)}

	if veleroBackup != nil {
		objs = append(objs, veleroBackup.DeepCopy())
		content, err := runtime.DefaultUnstructuredConverter.ToUnstructured(veleroBackup.DeepCopy())
		if err != nil {
			t.Fatalf("convert Velero Backup: %v", err)
		}
		u := &unstructured.Unstructured{Object: content}
		u.SetAPIVersion(vfyVeleroBackupGVR.GroupVersion().String())
		u.SetKind("Backup")
		dynamicObjs = append(dynamicObjs, u)
	}

	reconciler := vfyReconciler(t, dynamicObjs)
	testScheme := runtime.NewScheme()
	_ = scheme.AddToScheme(testScheme)
	_ = backupsv1alpha1.AddToScheme(testScheme)
	_ = velerov1.AddToScheme(testScheme)
	_ = strategyv1alpha1.AddToScheme(testScheme)
	reconciler.Client = clientfake.NewClientBuilder().
		WithScheme(testScheme).
		WithObjects(objs...).
		WithStatusSubresource(&backupsv1alpha1.RestoreJob{}).
		Build()

	return &vfyRestore{r: reconciler, restoreJob: restoreJob, backup: backup, pvc: pvc, vm: vm}
}

// C4: a restore whose referenced Velero Backup is unusable (missing/expired, or
// being deleted) must fail the RestoreJob before preparation halts the VM or
// touches any disk, whether or not it keeps the original claims. The VM
// runStrategy, the DataVolume and the PVC are all left untouched, and no -orig
// copy is made. The RestoreJob may take a few reconciles to fail.
func TestVerifyReconcileVeleroRestore_UnusableVeleroBackupTouchesNothing(t *testing.T) {
	deleting := &velerov1.Backup{
		ObjectMeta: metav1.ObjectMeta{Name: "vb", Namespace: veleroNamespace},
		Status:     velerov1.BackupStatus{Phase: velerov1.BackupPhaseDeleting},
	}
	tests := []struct {
		name         string
		veleroBackup *velerov1.Backup
		keep         bool
	}{
		{name: "Velero Backup expired"},
		{name: "Velero Backup being deleted", veleroBackup: deleting},
		{name: "Velero Backup expired, keepOriginalPVC=true", keep: true},
		{name: "Velero Backup being deleted, keepOriginalPVC=true", veleroBackup: deleting, keep: true},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			rs := vfyNewRestore(t, tt.keep, tt.veleroBackup)
			reconciler, ns := rs.r, rs.restoreJob.Namespace

			ctx := context.Background()
			key := client.ObjectKeyFromObject(rs.restoreJob)
			got := &backupsv1alpha1.RestoreJob{}
			var lastErr error
			for pass := 1; pass <= 3; pass++ {
				if err := reconciler.Get(ctx, key, got); err != nil {
					t.Fatalf("get RestoreJob: %v", err)
				}
				if got.Status.Phase == backupsv1alpha1.RestoreJobPhaseFailed {
					break
				}
				// A returned error is retried by controller-runtime, like a requeue.
				_, lastErr = reconciler.reconcileVeleroRestore(ctx, got, rs.backup)
			}

			if err := reconciler.Get(ctx, key, got); err != nil {
				t.Fatalf("get RestoreJob: %v", err)
			}
			if got.Status.Phase != backupsv1alpha1.RestoreJobPhaseFailed {
				t.Fatalf("RestoreJob phase = %q, want %q (last reconcile error: %v)", got.Status.Phase, backupsv1alpha1.RestoreJobPhaseFailed, lastErr)
			}

			if err := reconciler.Get(ctx, client.ObjectKeyFromObject(rs.pvc), &corev1.PersistentVolumeClaim{}); err != nil {
				t.Errorf("original PVC should survive a restore that cannot run: %v", err)
			}
			origName := "vm-disk-ubuntu-source-orig-" + shortHash(rs.restoreJob.Name)
			if err := reconciler.Get(ctx, client.ObjectKey{Namespace: ns, Name: origName}, &corev1.PersistentVolumeClaim{}); err == nil {
				t.Errorf("no -orig PVC should be made for a restore that cannot run")
			}
			if _, err := reconciler.Resource(dataVolumeGVR).Namespace(ns).Get(ctx, "vm-disk-ubuntu-source", metav1.GetOptions{}); err != nil {
				t.Errorf("DataVolume should survive a restore that cannot run: %v", err)
			}
			gotVM, err := reconciler.Resource(virtualMachineGVR).Namespace(ns).Get(ctx, rs.vm.GetName(), metav1.GetOptions{})
			if err != nil {
				t.Fatalf("get VirtualMachine: %v", err)
			}
			if runStrategy, _, _ := unstructured.NestedString(gotVM.Object, "spec", "runStrategy"); runStrategy != "Always" {
				t.Errorf("VirtualMachine runStrategy = %q, want it left at %q", runStrategy, "Always")
			}
		})
	}
}

// C8: a restore whose Velero Backup is usable (phase Completed) goes ahead.
// The RestoreJob does not fail, a Velero Restore of that backup is created,
// and by then the original claim's name is free. With keepOriginalPVC=true
// the original disk is still there as its -orig copy.
func TestVerifyReconcileVeleroRestore_UsableVeleroBackupRestores(t *testing.T) {
	completed := &velerov1.Backup{
		ObjectMeta: metav1.ObjectMeta{Name: "vb", Namespace: veleroNamespace},
		Status: velerov1.BackupStatus{
			Phase:      velerov1.BackupPhaseCompleted,
			Expiration: &metav1.Time{Time: time.Now().Add(24 * time.Hour)},
		},
	}
	for _, keep := range []bool{false, true} {
		t.Run(fmt.Sprintf("keepOriginalPVC=%v", keep), func(t *testing.T) {
			rs := vfyNewRestore(t, keep, completed)
			reconciler := rs.r

			ctx := context.Background()
			key := client.ObjectKeyFromObject(rs.restoreJob)
			got := &backupsv1alpha1.RestoreJob{}
			restores := &velerov1.RestoreList{}
			var lastErr error
			for pass := 1; pass <= 20 && len(restores.Items) == 0; pass++ {
				if err := reconciler.Get(ctx, key, got); err != nil {
					t.Fatalf("get RestoreJob: %v", err)
				}
				if got.Status.Phase == backupsv1alpha1.RestoreJobPhaseFailed {
					t.Fatalf("pass %d: RestoreJob failed although its Velero Backup is Completed: %s", pass, got.Status.Message)
				}
				// A returned error is retried by controller-runtime, like a requeue.
				_, lastErr = reconciler.reconcileVeleroRestore(ctx, got, rs.backup)
				if err := reconciler.List(ctx, restores, client.InNamespace(veleroNamespace)); err != nil {
					t.Fatalf("list Velero Restores: %v", err)
				}
			}

			if err := reconciler.Get(ctx, key, got); err != nil {
				t.Fatalf("get RestoreJob: %v", err)
			}
			if len(restores.Items) == 0 {
				t.Fatalf("no Velero Restore was created within 20 reconciles (RestoreJob phase %q, message %q, last reconcile error: %v)",
					got.Status.Phase, got.Status.Message, lastErr)
			}
			if got.Status.Phase == backupsv1alpha1.RestoreJobPhaseFailed {
				t.Errorf("RestoreJob failed although its Velero Backup is Completed: %s", got.Status.Message)
			}
			if name := restores.Items[0].Spec.BackupName; name != "vb" {
				t.Errorf("Velero Restore spec.backupName = %q, want %q", name, "vb")
			}

			if err := reconciler.Get(ctx, client.ObjectKeyFromObject(rs.pvc), &corev1.PersistentVolumeClaim{}); !errors.IsNotFound(err) {
				t.Errorf("PVC %s should be gone by the time the Velero Restore is created, got error: %v", rs.pvc.Name, err)
			}
			if keep {
				origName := rs.pvc.Name + "-orig-" + shortHash(rs.restoreJob.Name)
				if err := reconciler.Get(ctx, client.ObjectKey{Namespace: rs.pvc.Namespace, Name: origName}, &corev1.PersistentVolumeClaim{}); err != nil {
					t.Errorf("keepOriginalPVC=true should keep the original disk as PVC %s: %v", origName, err)
				}
			}
		})
	}
}
