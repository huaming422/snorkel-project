using AngleSharp;
using AngleSharp.Css;
using AngleSharp.Css.Dom;
using AngleSharp.Css.RenderTree;
using AngleSharp.Dom;
using Jint.Browser.Accessibility;
using Jint.Browser.Layout;

namespace Jint.Tests.Browser.Reward;

// Work-shape of the geometry query, measured as deterministic counts over stable AngleSharp
// seams and driven through the pre-existing FlatLayout.Of entry point. No wall-clock, and no
// subsystem type is named: whatever resolves element style during one query is free to be shaped
// any way, as long as (1) a single query reads the default stylesheet once (not once per element)
// and keeps nothing for the next query, and (2) a whole-document query matches a document's
// selectors about once per element rather than once per element for each of its ancestors.
public class RewardCascadeWorkTests
{
    // One layout query reads the default stylesheet exactly once for the whole query; the next
    // query reads it again (nothing is kept between queries). A per-element resolution reads once
    // per element, so this reads many times per query.
    [Test]
    public async Task OneQueryReadsTheDefaultSheetOnceAndTheNextQueryReadsItAgain()
    {
        using var seed = BrowsingContext.New(Configuration.Default.WithCss());
        var provider = new CountingProvider(seed.GetService<ICssDefaultStyleSheetProvider>()!);
        using var context = BrowsingContext.New(Configuration.Default.WithCss().With(provider));
        using var document = await context.OpenAsync(response => response.Content(
            "<div><div><div><button>Save</button></div></div></div>"));
        var visibility = new ElementVisibility(useComputedStyle: true);
        provider.Reads = 0;

        FlatLayout.Of(document, visibility, 1280, 720, 0).Count.Should().Be(6);
        provider.Reads.Should().Be(1, "every element in one layout query is served from a single read");

        document.QuerySelector("button")!.SetAttribute("hidden", "");
        FlatLayout.Of(document, visibility, 1280, 720, 0).Count.Should().Be(5);
        provider.Reads.Should().Be(2, "the next query keeps nothing and reads the sheets again");
    }

    // Matching work for a whole document is about one selector-match pass per element, not an extra
    // pass per element for each of its ancestors. Both totals below are counted over the same default
    // stylesheet via the same seam, so the (unknown, version-dependent) number of default rules
    // cancels out of the comparison. Resolving every element on its own repeats the match passes for
    // each of its ancestors, so for a deep tree that total is far larger than a single query that
    // reuses the matching down the document. A query that still repeats ancestor passes per element
    // lands near the per-element total and fails. A custom token at the root whose literal value is
    // `inherit` must not make every descendant take the value-forwarding ancestor fallback, which
    // would inflate the query total toward the per-element one; the one genuine leaf that asks for
    // that value must still take it.
    [Test]
    public async Task AWholeDocumentQueryMatchesFarFewerSelectorsThanResolvingEachElementSeparately()
    {
        using var seed = BrowsingContext.New(Configuration.Default.WithCss());
        var provider = new MatchCountingDefaults(seed.GetService<ICssDefaultStyleSheetProvider>()!);
        using var context = BrowsingContext.New(Configuration.Default.WithCss().With(provider));
        const int depth = 40;
        using var document = await context.OpenAsync(response => response.Content(
            "<style>:root{--colour:red;--token:inherit} div{color:var(--colour)} .leaf{display:inherit}</style>"
            + string.Concat(Enumerable.Repeat("<div>", depth))
            + "<button class=\"leaf\">Save</button>"
            + string.Concat(Enumerable.Repeat("</div>", depth))));
        var visibility = new ElementVisibility(useComputedStyle: true);
        var styles = document.DefaultView!.GetStyleCollection(new DefaultRenderDevice());
        var elements = document.All.OfType<IElement>().ToArray();

        provider.Reset();
        FlatLayout.Of(document, visibility, 1280, 720, 0);
        var queryWork = provider.Matches;

        provider.Reset();
        foreach (var element in elements)
        {
            styles.ComputeDeclarations(element);
        }

        var perElementWork = provider.Matches;

        queryWork.Should().BeGreaterThan(0, "the query must actually match selectors");
        perElementWork.Should().BeGreaterThan(queryWork * 4,
            "resolving every element on its own repeats each ancestor's passes, which one query avoids");
    }

    private sealed class CountingProvider(ICssDefaultStyleSheetProvider inner) : ICssDefaultStyleSheetProvider
    {
        internal int Reads { get; set; }

        public ICssStyleSheet Default
        {
            get
            {
                Reads++;
                return inner.Default;
            }
        }

        public void SetDefault(ICssStyleSheet? sheet) => inner.SetDefault(sheet);
        public void SetDefault(string source) => inner.SetDefault(source);
        public void AppendDefault(string source) => inner.AppendDefault(source);
    }
}
