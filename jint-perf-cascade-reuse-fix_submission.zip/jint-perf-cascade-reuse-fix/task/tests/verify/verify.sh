#!/usr/bin/env bash
# Behavioural verifier. Compiles this directory's own NUnit test files into a copy-free drop
# folder inside the repo's browser test project and runs only those tests against the submitted
# build. Every assertion is a deterministic count or a value read through a pre-existing public
# surface (the page's JavaScript, the automation client, AngleSharp's own interfaces) — never a
# wall-clock measurement and never a name the submission is free to choose. Exit 0 iff all the
# dropped tests pass; the runner turns that into one pass/fail result.
set -uo pipefail

REPO="${REPO_DIR:-$PWD}"
if [ ! -d "$REPO/Jint.Tests.Browser" ]; then
    REPO="/repo/${REPO_NAME:-jint}"
fi
PROJECT_DIR="$REPO/Jint.Tests.Browser"
PROJECT="$PROJECT_DIR/Jint.Tests.Browser.csproj"

if [ ! -f "$PROJECT" ]; then
    echo "INFRA: browser test project not found at $PROJECT" >&2
    exit 2
fi

# The NUnit source files to drop live next to this script (Reward*.cs). They are staged under the
# tests subtree only for this run and removed on the way out.
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if ! ls "$HERE"/Reward*.cs >/dev/null 2>&1; then
    echo "INFRA: no test source files found next to the verifier at $HERE" >&2
    exit 2
fi

# Drop the tests into a fresh, isolated folder so nothing in the project tree is overwritten, and
# remove it on the way out whether the run passes, fails or is interrupted.
DROP="$PROJECT_DIR/_rwtests"
cleanup() { rm -rf "$DROP"; }
trap cleanup EXIT
rm -rf "$DROP"
mkdir -p "$DROP"
cp "$HERE"/Reward*.cs "$DROP"/ || { echo "INFRA: could not stage test files" >&2; exit 2; }

export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1

# net10.0 only (the project multi-targets); the dropped tests target that. The filter runs only
# this verifier's own tests, so the suite's internet-gated client tests are never touched.
cd "$REPO" || { echo "INFRA: repo dir missing" >&2; exit 2; }

echo "Running dropped reward tests from $DROP ..."
dotnet test "$PROJECT" \
    --framework net10.0 \
    --no-restore \
    --nologo \
    --filter "FullyQualifiedName~Jint.Tests.Browser.Reward" \
    -- NUnit.DefaultTimeout=120000
status=$?

echo "dotnet test exit status: $status"
exit "$status"
