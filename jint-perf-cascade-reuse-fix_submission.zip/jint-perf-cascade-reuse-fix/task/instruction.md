## Task

Automating a large, server-rendered admin form through this browser's remote-automation connection has gotten painfully slow. Clicking the form's Save control (an actionability-checked click that submits the page back to the same URL) takes several seconds on big pages. Nothing is broken: the click lands, exactly one submission happens, the page reports success. It is just too slow, and the giveaway is how it scales. Shallow pages are fast; deep, heavily-styled ones crawl, and the per-click cost climbs faster than the page does. Make a single click scale with the page.

Keep every observable result identical. Repeated queries within one interaction must reflect the current page: DOM edits, style changes, control state, layout and viewport changes show up on the next query. A stale result is not a fix. Stay inside the rendering and layout path; the automation protocol and page-navigation lifecycle are already correct.

Reproduce this in-process, no server binary or network: the test project drives the slow page. Wall-clock time is noisy, so lean on how much repeated style and selector work each query does. Run the focused tests.
