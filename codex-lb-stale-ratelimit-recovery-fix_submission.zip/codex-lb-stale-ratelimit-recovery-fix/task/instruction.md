## Task

some of our paid accounts are getting stuck benched long after they should be back in rotation. upstream rolls their quota window over earlier than the deadline we had recorded, so the account is actually usable again: direct calls on it start succeeding, and our background usage refresh keeps reporting fresh, available quota for it every interval. but we keep it benched anyway until that original deadline finally passes, which can be days. free accounts recover on their own just fine; it's only the paid plans that hang like this. dig in and fix it.
