"""Behavioral verifier for codex-lb-stale-ratelimit-recovery.

Background usage refresh reconciles accounts between ``active`` and the
rate-limited status. When upstream rolls a paid account's quota window earlier
than the deadline the 429 persisted, usage history records the exhausted window
hitting its old deadline and then rolling to fresh availability under a later
deadline. The reconciliation must release such an account on the next refresh
cycle -- but only when the reset evidence is anchored to the very window the
block came from, and only when no other live quota window for the plan is still
exhausted. A paid account released into a still-spent sibling window would earn
a fresh 429 on its first request.

Every test drives the whole reconcile cycle through the pre-existing, stable
``UsageRefreshScheduler._refresh_once()`` entry point against a seeded SQLite
database, then asserts the persisted account row's observable
``(status, reset_at, blocked_at)`` transition. Nothing here imports or names any
internal reconciliation helper, evidence dataclass, or predicate: a correct fix
is free to rename every private symbol, reorder the slot search, fold or split
the guard, and bound the lookback however it likes. The seams monkeypatched
(``_get_leader_election``, ``build_background_usage_updater``) are the same
long-standing seams the repo's own integration suite drives the scheduler
through; warm-up is disabled via the settings row rather than patched.

Fixtures are self-contained because the repo's ``tests/conftest.py`` is not in
scope when this file is collected from ``/tests/verify/``. The ``db`` fixture
points the app at a throwaway on-disk SQLite file and builds the schema the same
way the repo's own harness does (``Base.metadata.create_all`` plus the preset
role / provider seed rows), then disposes the engine between tests so no state
crosses a boundary. The background session factory is left unset so
``get_background_session`` falls back to ``SessionLocal`` on the same engine,
exactly as the repo's integration tests rely on.
"""

from __future__ import annotations

import os
import tempfile
from collections.abc import Awaitable, Callable
from datetime import datetime, timezone
from pathlib import Path

import pytest

# The app reads its database URL and encryption-key location from the
# environment at import time, so both must be set before anything under ``app``
# is imported. A throwaway directory holds the SQLite file and the per-run
# encryption key; an on-disk (not in-memory) URL lets the scheduler's background
# sessions reach the same database the fixture seeds.
_TMP_DIR = Path(tempfile.mkdtemp(prefix="recovery-verify-"))
os.environ.setdefault("CODEX_LB_DATABASE_URL", f"sqlite+aiosqlite:///{_TMP_DIR / 'app.db'}")
os.environ.setdefault("CODEX_LB_ENCRYPTION_KEY_FILE", str(_TMP_DIR / "enc.key"))
os.environ.setdefault("CODEX_LB_UPSTREAM_BASE_URL", "https://example.invalid/backend-api")

from app.core.crypto import TokenEncryptor  # noqa: E402
from app.core.usage import default_window_minutes  # noqa: E402
from app.core.usage import refresh_scheduler as refresh_scheduler_module  # noqa: E402
from app.core.utils.time import utcnow  # noqa: E402
from app.db.models import Account, AccountStatus, Base  # noqa: E402
from app.db.session import SessionLocal, close_db, engine  # noqa: E402
from app.modules.accounts.repository import AccountsRepository  # noqa: E402
from app.modules.auth_providers.seed import seed_default_auth_providers  # noqa: E402
from app.modules.dashboard_roles.seed import seed_preset_dashboard_roles  # noqa: E402
from app.modules.settings.repository import SettingsRepository  # noqa: E402
from app.modules.usage.repository import UsageRepository  # noqa: E402

pytestmark = pytest.mark.asyncio

# Window-slot vocabulary and canonical durations are repo-owned stable facts
# (the quota-window taxonomy the repository filters on). Reading the durations
# from the repo's own accessor keeps the verifier faithful to whatever the
# project defines them as, rather than restating magic numbers.
PRIMARY = "primary"
SECONDARY = "secondary"
MONTHLY = "monthly"
PRIMARY_MINUTES = default_window_minutes(PRIMARY)
SECONDARY_MINUTES = default_window_minutes(SECONDARY)
MONTHLY_MINUTES = default_window_minutes(MONTHLY)

# A fixed clock anchor keeps every derived deadline/offset deterministic across
# runs. It sits far from any real now() the production code reads, but the code
# under test compares the account's persisted markers against ``time.time()``;
# the offsets below are chosen so the account is past its post-429 cooldown yet
# still before its stale deadline at real wall-clock time.
DAY = 24 * 60 * 60
MINUTE = 60


def _epoch_now() -> int:
    import time

    return int(time.time())


def _naive(epoch: int) -> datetime:
    """Match how the repository stores ``recorded_at`` (naive UTC)."""
    return datetime.fromtimestamp(epoch, timezone.utc).replace(tzinfo=None)


def _build_account(
    account_id: str,
    *,
    plan_type: str,
    status: AccountStatus,
    reset_at: int | None = None,
    blocked_at: int | None = None,
) -> Account:
    encryptor = TokenEncryptor()
    account = Account(
        id=account_id,
        chatgpt_account_id=f"workspace-{account_id}",
        email=f"{account_id}@example.com",
        plan_type=plan_type,
        access_token_encrypted=encryptor.encrypt("access"),
        refresh_token_encrypted=encryptor.encrypt("refresh"),
        id_token_encrypted=encryptor.encrypt("id"),
        last_refresh=utcnow(),
        status=status,
        reset_at=reset_at,
        blocked_at=blocked_at,
        limit_warmup_enabled=True,
    )
    return account


def _reset_schema(sync_conn) -> None:
    Base.metadata.drop_all(sync_conn)
    Base.metadata.create_all(sync_conn)
    # ``create_all`` does not run the production migrations that seed preset
    # dashboard roles and auth providers; the repo's own test harness seeds them
    # explicitly after building the schema, so mirror that here.
    seed_preset_dashboard_roles(sync_conn)
    seed_default_auth_providers(sync_conn)


@pytest.fixture
async def db():
    """A clean, schema-built SQLite database for one test.

    Disposes and rebuilds the schema per test so no account or usage-history row
    survives into the next. The background session factory is intentionally left
    at its default so ``get_background_session`` resolves to ``SessionLocal`` on
    this same engine -- the scheduler and the fixture then read and write one
    database.
    """
    await close_db()
    async with engine.begin() as conn:
        await conn.run_sync(_reset_schema)
    try:
        yield
    finally:
        await close_db()


def _install_cycle_seams(monkeypatch, updater) -> None:
    """Replace the leader-election and usage-updater seams for a refresh cycle.

    The leader election is replaced with an inline runner and the background
    usage updater with the test's stand-in (it records the post-refresh usage
    rows). These are the same long-standing seams the repo's integration suite
    patches; neither belongs to the reconciliation logic under test. Warm-up is
    left disabled via the settings row, so the real streaming sender is
    constructed but never sends -- no sender patch is needed.
    """

    class _Leader:
        async def run_if_leader(self, fn: Callable[[], Awaitable[object]]) -> object:
            return await fn()

    monkeypatch.setattr(refresh_scheduler_module, "_get_leader_election", lambda: _Leader())
    monkeypatch.setattr(refresh_scheduler_module, "build_background_usage_updater", lambda: updater)


async def _run_cycle(monkeypatch, *, updater) -> float:
    """Drive exactly one leader-gated refresh cycle and return its delay."""
    _install_cycle_seams(monkeypatch, updater)
    scheduler = refresh_scheduler_module.UsageRefreshScheduler(interval_seconds=60, enabled=True)
    return await scheduler._refresh_once()


async def _run_cycles(monkeypatch, *, updater, count: int) -> None:
    """Drive ``count`` successive refresh cycles on one scheduler.

    The scheduler selects one account per cycle, round-robin by account id, so
    running one cycle per seeded account reconciles them all. Each account's
    reconciliation is scoped to its own id, so the accounts never interfere.
    """
    _install_cycle_seams(monkeypatch, updater)
    scheduler = refresh_scheduler_module.UsageRefreshScheduler(interval_seconds=60, enabled=True)
    for _ in range(count):
        await scheduler._refresh_once()


async def _persisted_state(account_id: str) -> tuple[AccountStatus, int | None, int | None]:
    async with SessionLocal() as session:
        account = await AccountsRepository(session).get_by_id(account_id)
    assert account is not None
    return account.status, account.reset_at, account.blocked_at


def _appending_updater(account_id: str, rows: list[dict]):
    """An updater stand-in that appends the given post-refresh usage rows.

    Models the real refresh writing a fresh sample for the selected account: the
    scheduler reads these rows back as the "after" window state that drives
    reconciliation. ``rows`` is a list of kwargs for ``UsageRepository.add_entry``.
    """

    class _Updater:
        async def refresh_accounts(self, accounts: list[Account], latest_usage) -> bool:
            del latest_usage
            assert [candidate.id for candidate in accounts] == [account_id]
            async with SessionLocal() as session:
                usage_repo = UsageRepository(session)
                for row in rows:
                    await usage_repo.add_entry(account_id, **row)
            return True

    return _Updater()


def _multi_updater(rows_by_account: dict[str, list[dict]]):
    """An updater stand-in for multi-account tests.

    The scheduler selects one account per cycle; this appends the post-refresh
    rows registered for whichever account was selected, so one cycle per seeded
    account reconciles them all independently.
    """

    class _Updater:
        async def refresh_accounts(self, accounts: list[Account], latest_usage) -> bool:
            del latest_usage
            assert len(accounts) == 1
            account_id = accounts[0].id
            async with SessionLocal() as session:
                usage_repo = UsageRepository(session)
                for row in rows_by_account.get(account_id, []):
                    await usage_repo.add_entry(account_id, **row)
            return True

    return _Updater()


def _recovering_secondary_rows(now: int) -> tuple[dict, dict]:
    """Seed + post-refresh rows for a paid account that recovers on its 7d window.

    Returns ``(baseline_row_kwargs, after_row_kwargs)`` for a secondary-slot
    window that was exhausted at the account's persisted deadline and then rolled
    to fresh availability under a later deadline. Used as the positive control
    that only a correct fix recovers, so a guard test also fails on a do-nothing
    submission.
    """
    baseline_recorded = now - 2 * MINUTE
    after_recorded = now - MINUTE
    stale_deadline = now + 3 * DAY
    after_deadline = after_recorded + SECONDARY_MINUTES * MINUTE
    baseline = {
        "used_percent": 100.0,
        "window": SECONDARY,
        "recorded_at": _naive(baseline_recorded),
        "reset_at": stale_deadline,
        "window_minutes": SECONDARY_MINUTES,
    }
    after = {
        "used_percent": 0.0,
        "window": SECONDARY,
        "recorded_at": _naive(after_recorded),
        "reset_at": after_deadline,
        "window_minutes": SECONDARY_MINUTES,
    }
    return baseline, after


# --------------------------------------------------------------------------- #
# Behavior 1: a paid account blocked on its long window recovers once history
# confirms that window reset early. The unmodified code never recovers a paid
# account, so this fails before the fix and passes after it.
# --------------------------------------------------------------------------- #
async def test_recovers_paid_account_after_confirmed_window_reset(db, monkeypatch):
    now = _epoch_now()
    stale_deadline = now + 3 * DAY
    blocked_at = now - 2 * DAY
    baseline_recorded = now - 2 * MINUTE
    after_recorded = now - MINUTE
    # The rolled window reports a later deadline; the jump past the old deadline
    # is what proves a genuine reset rather than a Retry-After nudge.
    after_deadline = after_recorded + SECONDARY_MINUTES * MINUTE

    account = _build_account(
        "acc_paid",
        plan_type="pro",
        status=AccountStatus.RATE_LIMITED,
        reset_at=stale_deadline,
        blocked_at=blocked_at,
    )

    async with SessionLocal() as session:
        await AccountsRepository(session).upsert(account)
        # The exhausted 7d window that produced the 429, still carrying the
        # deadline persisted on the account.
        await UsageRepository(session).add_entry(
            account.id,
            100.0,
            window=SECONDARY,
            recorded_at=_naive(baseline_recorded),
            reset_at=stale_deadline,
            window_minutes=SECONDARY_MINUTES,
        )
        await SettingsRepository(session).update(limit_warmup_enabled=False)

    updater = _appending_updater(
        account.id,
        [
            {
                "used_percent": 0.0,
                "window": SECONDARY,
                "recorded_at": _naive(after_recorded),
                "reset_at": after_deadline,
                "window_minutes": SECONDARY_MINUTES,
            }
        ],
    )

    assert await _run_cycle(monkeypatch, updater=updater) == 60.0
    assert await _persisted_state(account.id) == (AccountStatus.ACTIVE, None, None)


# --------------------------------------------------------------------------- #
# Behavior 2: reset evidence in a window whose baseline deadline does NOT match
# the persisted reset_at must not release the account. A monthly reset while
# blocked on the long (secondary) window is unrelated evidence.
# --------------------------------------------------------------------------- #
async def test_does_not_recover_on_unanchored_window_reset(db, monkeypatch):
    now = _epoch_now()
    stale_deadline = now + 3 * DAY
    blocked_at = now - 2 * DAY
    baseline_recorded = now - 2 * MINUTE
    after_recorded = now - MINUTE
    # A confirmed reset, but in the MONTHLY slot, whose baseline deadline is a
    # different value than the account's persisted secondary-window deadline.
    monthly_baseline_deadline = now + 10 * DAY
    monthly_after_deadline = after_recorded + MONTHLY_MINUTES * MINUTE

    # Guard subject: blocked on the secondary window, but its only reset evidence
    # is in an unrelated monthly window (baseline deadline != persisted reset_at).
    subject = _build_account(
        "acc_unanchored",
        plan_type="pro",
        status=AccountStatus.RATE_LIMITED,
        reset_at=stale_deadline,
        blocked_at=blocked_at,
    )
    # Positive control: an otherwise identical paid account whose reset evidence
    # IS anchored to its blocked window. A correct fix recovers it; a do-nothing
    # submission leaves it benched -- so this test fails before the fix and
    # passes after it.
    control = _build_account(
        "acc_anchored_control",
        plan_type="pro",
        status=AccountStatus.RATE_LIMITED,
        reset_at=stale_deadline,
        blocked_at=blocked_at,
    )
    control_baseline, control_after = _recovering_secondary_rows(now)

    async with SessionLocal() as session:
        accounts_repo = AccountsRepository(session)
        usage_repo = UsageRepository(session)
        await accounts_repo.upsert(subject)
        await accounts_repo.upsert(control)
        # Subject: monthly evidence anchored to a deadline the block never carried.
        await usage_repo.add_entry(
            subject.id,
            100.0,
            window=MONTHLY,
            recorded_at=_naive(baseline_recorded),
            reset_at=monthly_baseline_deadline,
            window_minutes=MONTHLY_MINUTES,
        )
        # Control: exhausted secondary window anchored to its own deadline.
        await usage_repo.add_entry(control.id, **control_baseline)
        await SettingsRepository(session).update(limit_warmup_enabled=False)

    updater = _multi_updater(
        {
            subject.id: [
                {
                    "used_percent": 0.0,
                    "window": MONTHLY,
                    "recorded_at": _naive(after_recorded),
                    "reset_at": monthly_after_deadline,
                    "window_minutes": MONTHLY_MINUTES,
                }
            ],
            control.id: [control_after],
        }
    )

    await _run_cycles(monkeypatch, updater=updater, count=2)

    # The anchored control recovers; the unanchored subject stays benched on its
    # persisted deadline. A fix that drops the gates without re-establishing the
    # anchor would release the subject and fail here.
    assert await _persisted_state(control.id) == (AccountStatus.ACTIVE, None, None)
    assert await _persisted_state(subject.id) == (
        AccountStatus.RATE_LIMITED,
        stale_deadline,
        blocked_at,
    )


# --------------------------------------------------------------------------- #
# Behavior 3: sibling-exhaustion guard. Even with anchored reset evidence on the
# blocked window, a DIFFERENT live window carrying real quota for the plan that
# still reports 100% keeps the account blocked -- releasing it would buy one
# request before a fresh 429.
# --------------------------------------------------------------------------- #
async def test_keeps_account_blocked_when_live_sibling_window_exhausted(db, monkeypatch):
    now = _epoch_now()
    stale_deadline = now + 3 * DAY
    blocked_at = now - 2 * DAY
    baseline_recorded = now - 2 * MINUTE
    after_recorded = now - MINUTE
    secondary_after_deadline = after_recorded + SECONDARY_MINUTES * MINUTE
    # The primary (short) window is still fully spent with a live, future
    # deadline: a real exhausted sibling.
    primary_live_deadline = now + 2 * 60 * MINUTE

    # Guard subject: anchored reset evidence on the blocked window, but a live
    # exhausted sibling window that must keep it benched.
    subject = _build_account(
        "acc_live_sibling",
        plan_type="pro",
        status=AccountStatus.RATE_LIMITED,
        reset_at=stale_deadline,
        blocked_at=blocked_at,
    )
    # Positive control: same anchored recovery, no exhausted sibling. A correct
    # fix recovers it; a do-nothing submission leaves it benched, so this test
    # fails before the fix and passes after it.
    control = _build_account(
        "acc_no_sibling_control",
        plan_type="pro",
        status=AccountStatus.RATE_LIMITED,
        reset_at=stale_deadline,
        blocked_at=blocked_at,
    )
    control_baseline, control_after = _recovering_secondary_rows(now)

    async with SessionLocal() as session:
        accounts_repo = AccountsRepository(session)
        usage_repo = UsageRepository(session)
        await accounts_repo.upsert(subject)
        await accounts_repo.upsert(control)
        # Subject: anchored reset evidence on the blocked secondary window.
        await usage_repo.add_entry(
            subject.id,
            100.0,
            window=SECONDARY,
            recorded_at=_naive(baseline_recorded),
            reset_at=stale_deadline,
            window_minutes=SECONDARY_MINUTES,
        )
        # Subject: a live, still-exhausted primary sibling (real capacity for pro).
        await usage_repo.add_entry(
            subject.id,
            100.0,
            window=PRIMARY,
            recorded_at=_naive(after_recorded),
            reset_at=primary_live_deadline,
            window_minutes=PRIMARY_MINUTES,
        )
        # Control: exhausted secondary anchored to its deadline, no live sibling.
        await usage_repo.add_entry(control.id, **control_baseline)
        await SettingsRepository(session).update(limit_warmup_enabled=False)

    updater = _multi_updater(
        {
            subject.id: [
                {
                    "used_percent": 0.0,
                    "window": SECONDARY,
                    "recorded_at": _naive(after_recorded),
                    "reset_at": secondary_after_deadline,
                    "window_minutes": SECONDARY_MINUTES,
                }
            ],
            control.id: [control_after],
        }
    )

    await _run_cycles(monkeypatch, updater=updater, count=2)

    # The control recovers; the subject with a live exhausted sibling stays
    # benched. A fix that drops the gates without the sibling guard would release
    # the subject and fail here.
    assert await _persisted_state(control.id) == (AccountStatus.ACTIVE, None, None)
    assert await _persisted_state(subject.id) == (
        AccountStatus.RATE_LIMITED,
        stale_deadline,
        blocked_at,
    )


# --------------------------------------------------------------------------- #
# Behavior 4: an exhausted sibling whose own deadline has already elapsed is
# stale evidence, not a live block, and must not prevent recovery. Identical to
# behavior 3 except the sibling's deadline is in the past.
# --------------------------------------------------------------------------- #
async def test_recovers_when_exhausted_sibling_window_has_elapsed(db, monkeypatch):
    now = _epoch_now()
    stale_deadline = now + 3 * DAY
    blocked_at = now - 2 * DAY
    baseline_recorded = now - 2 * MINUTE
    after_recorded = now - MINUTE
    secondary_after_deadline = after_recorded + SECONDARY_MINUTES * MINUTE
    # The primary sibling reports 100% but its OWN deadline has already passed:
    # stale exhaustion evidence, not a live block.
    primary_elapsed_deadline = now - 30 * MINUTE

    account = _build_account(
        "acc_elapsed_sibling",
        plan_type="pro",
        status=AccountStatus.RATE_LIMITED,
        reset_at=stale_deadline,
        blocked_at=blocked_at,
    )

    async with SessionLocal() as session:
        await AccountsRepository(session).upsert(account)
        usage_repo = UsageRepository(session)
        await usage_repo.add_entry(
            account.id,
            100.0,
            window=SECONDARY,
            recorded_at=_naive(baseline_recorded),
            reset_at=stale_deadline,
            window_minutes=SECONDARY_MINUTES,
        )
        await usage_repo.add_entry(
            account.id,
            100.0,
            window=PRIMARY,
            recorded_at=_naive(after_recorded),
            reset_at=primary_elapsed_deadline,
            window_minutes=PRIMARY_MINUTES,
        )
        await SettingsRepository(session).update(limit_warmup_enabled=False)

    updater = _appending_updater(
        account.id,
        [
            {
                "used_percent": 0.0,
                "window": SECONDARY,
                "recorded_at": _naive(after_recorded),
                "reset_at": secondary_after_deadline,
                "window_minutes": SECONDARY_MINUTES,
            }
        ],
    )

    assert await _run_cycle(monkeypatch, updater=updater) == 60.0
    assert await _persisted_state(account.id) == (AccountStatus.ACTIVE, None, None)


# --------------------------------------------------------------------------- #
# Behavior 5: the pre-existing Free-account monthly reset recovery still works.
# The normalized Free primary slot carries zero capacity and must be excluded
# from the sibling guard, so its 100% artifact row does not block recovery. This
# is a non-regression guard: it must pass both before and after the fix.
# --------------------------------------------------------------------------- #
async def test_free_monthly_recovery_preserved(db, monkeypatch):
    now = _epoch_now()
    stale_deadline = now + 8 * DAY
    blocked_at = now - 5 * DAY
    baseline_recorded = now - 2 * MINUTE
    after_recorded = now - MINUTE
    after_deadline = after_recorded + MONTHLY_MINUTES * MINUTE

    account = _build_account(
        "acc_free",
        plan_type="free",
        status=AccountStatus.RATE_LIMITED,
        reset_at=stale_deadline,
        blocked_at=blocked_at,
    )

    async with SessionLocal() as session:
        await AccountsRepository(session).upsert(account)
        usage_repo = UsageRepository(session)
        # The blocked monthly window, anchored to the account's deadline.
        await usage_repo.add_entry(
            account.id,
            100.0,
            window=MONTHLY,
            recorded_at=_naive(baseline_recorded),
            reset_at=stale_deadline,
            window_minutes=MONTHLY_MINUTES,
        )
        # The normalized Free primary artifact: 100% used, but the plan carries
        # zero primary capacity, so it is not a real window and must not veto.
        await usage_repo.add_entry(
            account.id,
            100.0,
            window=PRIMARY,
            recorded_at=_naive(after_recorded),
            reset_at=now + 4 * 60 * MINUTE,
            window_minutes=PRIMARY_MINUTES,
        )
        await SettingsRepository(session).update(limit_warmup_enabled=False)

    updater = _appending_updater(
        account.id,
        [
            {
                "used_percent": 0.0,
                "window": MONTHLY,
                "recorded_at": _naive(after_recorded),
                "reset_at": after_deadline,
                "window_minutes": MONTHLY_MINUTES,
            }
        ],
    )

    assert await _run_cycle(monkeypatch, updater=updater) == 60.0
    assert await _persisted_state(account.id) == (AccountStatus.ACTIVE, None, None)


# --------------------------------------------------------------------------- #
# Behavior 6: full-cycle reproduction of the production incident -- a paid
# account benched on a 7d window that upstream reports through the PRIMARY slot
# (the weekly-primary shape) recovers end-to-end through the refresh entry point
# once that window rolls early. Distinct slot coverage from behavior 1, driven
# entirely through the persisted account row.
# --------------------------------------------------------------------------- #
async def test_scheduler_cycle_recovers_paid_after_early_reset(db, monkeypatch):
    now = _epoch_now()
    stale_deadline = now + 3 * DAY
    blocked_at = now - 2 * DAY
    baseline_recorded = now - 2 * MINUTE
    after_recorded = now - MINUTE
    # A 7d-duration window delivered through the primary slot: the exact shape
    # from the reproduced incident. The post-reset row carries a later deadline.
    after_deadline = after_recorded + SECONDARY_MINUTES * MINUTE

    account = _build_account(
        "acc_cycle",
        plan_type="pro",
        status=AccountStatus.RATE_LIMITED,
        reset_at=stale_deadline,
        blocked_at=blocked_at,
    )

    async with SessionLocal() as session:
        await AccountsRepository(session).upsert(account)
        await UsageRepository(session).add_entry(
            account.id,
            100.0,
            window=PRIMARY,
            recorded_at=_naive(baseline_recorded),
            reset_at=stale_deadline,
            window_minutes=SECONDARY_MINUTES,
        )
        await SettingsRepository(session).update(limit_warmup_enabled=False)

    updater = _appending_updater(
        account.id,
        [
            {
                "used_percent": 0.0,
                "window": PRIMARY,
                "recorded_at": _naive(after_recorded),
                "reset_at": after_deadline,
                "window_minutes": SECONDARY_MINUTES,
            }
        ],
    )

    assert await _run_cycle(monkeypatch, updater=updater) == 60.0
    assert await _persisted_state(account.id) == (AccountStatus.ACTIVE, None, None)
