#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# Brings the baked dependency closure online for the project's own test run.
# Must run with the network cut: the image (step 10) already synced the full
# locked closure into /opt/venv, so this is offline-first. Export uv's offline
# switch here (never image-wide) so a cache miss fails fast.
cd /repo/codex-lb

export UV_OFFLINE=1 UV_NO_CACHE=0

# Dependencies: offline-first against the image bake, logged online fallback.
if uv sync --frozen --all-extras --group dev > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] uv sync satisfied from image"
elif uv sync --frozen --group dev >> /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] uv sync satisfied from image (no extras)"
else
    unset UV_OFFLINE
    if uv sync --frozen --all-extras --group dev >> /tmp/test-setup-install.log 2>&1; then
        echo "[test-setup] deps installed online (image bake was stale)"
    else
        tail -60 /tmp/test-setup-install.log >&2; exit 1
    fi
fi

# No services: the project's tests run against an ephemeral SQLite file created
# per test by the repo's own fixtures. No data seeding here — the verifier
# constructs its own account/usage-history rows.
