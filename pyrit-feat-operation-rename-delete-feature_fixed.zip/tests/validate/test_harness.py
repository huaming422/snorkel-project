# Copyright (c) Microsoft Corporation.
# Licensed under the MIT license.

"""Framework plumbing for the operation-rename-delete validation stories.

This module holds ONLY test-infrastructure mechanics - building an isolated
store, binding it so both the FastAPI app and the async memory/attack code see
it, authored test doubles (a pausable target, a counting attack strategy), and
small read/seed shortcuts over PRE-EXISTING public interfaces. It contains NO
knowledge of the behavior under test: it never names the update/delete/usage
methods the solution adds, never asserts a status code or a usage shape, and
never discovers a candidate symbol. The story procedures own all of that.

Why the stories are written synchronously
------------------------------------------
The validation driver runs these tests from a temporary rootdir, so the repo's
own ``tests/unit/conftest.py`` and its ``asyncio_mode = "auto"`` setting are NOT
loaded. There is therefore no ambient async-test plumbing. Each test function is
an ordinary ``def test_...(inputs, expected)`` that:

  * drives async PyRIT code by wrapping a coroutine in ``run_async(...)``
    (a thin ``asyncio.run`` that opens a fresh event loop each call), and
  * drives the HTTP surface through a synchronous ``TestClient(app)`` returned
    by ``operations_api()``.

A single in-memory SQLite store underlies both. ``SQLiteMemory`` keeps its
in-memory database alive across event loops (a shared-cache named database plus a
keepalive connection), so data seeded in one ``run_async(...)`` call is visible
to a later ``run_async(...)`` call AND to the synchronous ``TestClient``. Bind
once with ``operations_api()`` or ``memory_session()``; seed and read freely.

Interfaces used here are all pre-existing and stable:
  * ``pyrit.backend.main.app`` + ``fastapi.testclient.TestClient`` - HTTP surface.
  * ``test_support.fixtures.use_sqlite_memory`` - binds a store to ``CentralMemory``.
  * ``pyrit.memory.SQLiteMemory`` - the default in-memory store.
  * ``pyrit.models`` ``Operation`` / ``Finding`` / ``AttackResult`` and
    ``unit.mocks`` ``MockPromptTarget`` / ``make_scenario_result`` - pre-existing
    models and test doubles (``operation_id`` is a pre-existing field on
    ``AttackResult`` / ``ScenarioResult``).
  * ``pyrit.executor.attack`` public execution entry points.
"""

from __future__ import annotations

import asyncio
import os
import tempfile
import uuid
import warnings
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any, Awaitable, Callable, Iterator
from unittest.mock import patch

if TYPE_CHECKING:
    from fastapi.testclient import TestClient

    from pyrit.memory import SQLiteMemory
    from pyrit.models import AttackResult, Operation, ScenarioResult

# Generous ceiling for the paused-target rendezvous; the events fire in
# milliseconds, this only guards against a genuine hang.
_RENDEZVOUS_TIMEOUT = 10.0


def run_async(coro: Awaitable[Any]) -> Any:
    """Run one coroutine to completion on a fresh event loop.

    Each call opens and closes its own loop (``asyncio.run``). The bound store's
    in-memory database survives between calls, so seeding in one call is visible
    to reads or HTTP requests in another.
    """
    return asyncio.run(coro)  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Store construction + binding
# ---------------------------------------------------------------------------


def _build_memory() -> "SQLiteMemory":
    """Build a migrated, isolated in-memory SQLite store (embedding disabled).

    Mirrors the repo's ``sqlite_instance`` fixture mechanics: construct without
    running the package-level cleanup hook (which would otherwise retain the
    instance process-wide), migrate the schema, and disable embedding so no
    network/model calls are attempted.
    """
    from pyrit.memory import SQLiteMemory

    memory = SQLiteMemory.__new__(SQLiteMemory)
    with patch.object(memory, "cleanup"):
        memory.__init__(db_path=":memory:")  # migrates the schema
    memory.disable_embedding()
    return memory


@contextmanager
def memory_session() -> Iterator["SQLiteMemory"]:
    """Yield a fresh store bound to ``CentralMemory`` for the duration.

    Use this for stories that work directly against the async memory / attack
    interfaces. The bound store is what ``CentralMemory.get_memory_instance()``
    returns everywhere in the process while the context is open.
    """
    from test_support.fixtures import use_sqlite_memory

    memory = _build_memory()
    try:
        with use_sqlite_memory(memory):
            yield memory
    finally:
        run_async(memory.dispose_engine_async())


@contextmanager
def operations_api() -> Iterator["tuple[TestClient, SQLiteMemory]"]:
    """Yield ``(client, memory)`` for the HTTP operations surface.

    ``client`` is a synchronous ``TestClient(app)`` carrying the local
    authentication / compatibility headers the backend requires (the app's
    lifespan is skipped, so the needed ``app.state`` values are patched in, as
    the repo's backend tests do). ``memory`` is the same bound store, so you can
    seed activity with ``run_async(...)`` and then observe it over HTTP.
    """
    from fastapi.testclient import TestClient

    from pyrit import _compatibility
    from pyrit.backend.authentication_policy import AuthenticationPolicy
    from pyrit.backend.main import app

    identity = "0.14.0+g" + "a" * 40
    policy = AuthenticationPolicy(mode="local")
    with memory_session() as memory:
        with (
            patch.object(_compatibility, "get_compatibility_id", return_value=identity),
            patch.object(app.state, "compatibility_id", identity, create=True),
            patch.object(app.state, "authentication_policy", policy, create=True),
        ):
            headers = {_compatibility.COMPATIBILITY_HEADER: identity}
            client = TestClient(app, headers=headers)
            yield client, memory


def unauthenticated_client() -> "TestClient":
    """A ``TestClient(app)`` with NO compatibility/auth headers.

    Use inside an open ``operations_api()`` context to probe how the surface
    treats a request that lacks the normal authenticated-caller marker.
    """
    from fastapi.testclient import TestClient

    from pyrit.backend.main import app

    return TestClient(app)


# ---------------------------------------------------------------------------
# Seeding helpers (pre-existing models + memory methods only)
# ---------------------------------------------------------------------------


def new_operation(memory: "SQLiteMemory", name: str) -> "Operation":
    """Create and return an operation by name (pre-existing ``add_operation_async``)."""
    from pyrit.models import Operation

    return run_async(memory.add_operation_async(Operation(name=name)))


def seed_finding(memory: "SQLiteMemory", operation_id: uuid.UUID) -> None:
    """Attach one finding to an operation BY ID (pre-existing ``Finding.operation_id``)."""
    from pyrit.models import Finding

    finding = Finding(operation_id=operation_id, title="Assessment", severity="low")
    run_async(memory.add_finding_async(finding=finding))


def seed_attack(memory: "SQLiteMemory", operation_id: uuid.UUID) -> "AttackResult":
    """Save one attack result linked to an operation BY ID; returns the result."""
    from pyrit.models import AttackResult

    result = AttackResult(
        conversation_id=f"linked-{uuid.uuid4().hex}",
        objective="objective",
        operation_id=operation_id,
    )
    run_async(memory.add_attack_results_to_memory_async(attack_results=[result]))
    return result


def seed_scenario(memory: "SQLiteMemory", operation_id: uuid.UUID) -> "ScenarioResult":
    """Save one scenario result linked to an operation BY ID; returns the result."""
    from unit.mocks import make_scenario_result

    from pyrit.models import ComponentIdentifier

    scenario = make_scenario_result(
        scenario_name="Attribution",
        objective_target_identifier=ComponentIdentifier(class_name="Target", class_module="test"),
        attack_results={},
    )
    scenario.operation_id = operation_id
    run_async(memory.add_scenario_results_to_memory_async(scenario_results=[scenario]))
    return scenario


def seed_legacy_name_attack(memory: "SQLiteMemory", name: str) -> "AttackResult":
    """Save an attack result that refers to an operation by NAME only (legacy shape).

    Legacy name-only attribution uses the pre-existing ``AttackResult.operation``
    field and emits a deprecation warning, which is suppressed here. Returns the
    saved result so the story can look it up afterward.
    """
    from pyrit.models import AttackResult

    legacy = AttackResult(
        conversation_id=f"legacy-{uuid.uuid4().hex}",
        objective="objective",
        operation=name,
    )
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        run_async(memory.add_attack_results_to_memory_async(attack_results=[legacy]))
    return legacy


# ---------------------------------------------------------------------------
# Read helpers (pre-existing query methods)
# ---------------------------------------------------------------------------


def list_operations(memory: "SQLiteMemory") -> "list[Operation]":
    """All operations currently in the store (pre-existing ``get_operations_async``)."""
    return run_async(memory.get_operations_async())


def all_saved_attacks(memory: "SQLiteMemory") -> "list[AttackResult]":
    """Every saved attack result, regardless of attribution (pre-existing query)."""
    from pyrit.models import AttackResultSelection

    return run_async(memory.get_attack_results_async(result_selection=AttackResultSelection.ALL_RESULTS))


def attacks_by_name(memory: "SQLiteMemory", name: str) -> "list[AttackResult]":
    """Attack results attributed to an operation NAME (pre-existing ``operation=`` filter)."""
    return run_async(memory.get_attack_results_async(operation=[name]))


# ---------------------------------------------------------------------------
# Authored test doubles for the in-flight-deletion story
# ---------------------------------------------------------------------------


def make_pausable_target() -> Any:
    """A ``MockPromptTarget`` that blocks mid-send until released.

    It sets ``.sending`` when the attack reaches the target and then awaits
    ``.release`` before producing its canned reply - giving the test a window to
    delete the operation while the attack is genuinely in flight. Both are
    ``asyncio.Event`` objects. Construct inside the loop that will run the attack.
    """
    from unit.mocks import MockPromptTarget

    class _PausableTarget(MockPromptTarget):  # pragma: no cover - exercised via attacks
        def __init__(self) -> None:
            super().__init__()
            self.sending = asyncio.Event()
            self.release = asyncio.Event()

        async def _send_prompt_to_target_async(self, *, normalized_conversation: Any) -> Any:
            self.sending.set()
            await self.release.wait()
            return await super()._send_prompt_to_target_async(normalized_conversation=normalized_conversation)

    return _PausableTarget()


def make_counting_attack(*, fail: bool = False) -> Any:
    """An ``AttackStrategy`` that counts setup/perform calls and saves one result.

    Mirrors the repo's minimal probe strategy: it records ``setup_count`` and
    ``perform_count`` so a story can prove an attack was rejected BEFORE any
    setup/perform ran (e.g. a batch handed an operation that never existed). With
    ``fail=True`` the perform step raises, to prove the save path is reached even
    on an error result.
    """
    from unit.mocks import MockPromptTarget

    from pyrit.executor.attack.core.attack_parameters import AttackParameters
    from pyrit.executor.attack.core.attack_strategy import AttackContext, AttackStrategy
    from pyrit.models import AttackResult

    class _CountingAttack(AttackStrategy[AttackContext[AttackParameters], AttackResult]):  # pragma: no cover
        def __init__(self, *, fail: bool = False) -> None:
            super().__init__(objective_target=MockPromptTarget(), context_type=AttackContext)
            self.setup_count = 0
            self.perform_count = 0
            self.fail = fail

        def _validate_context(self, *, context: AttackContext[AttackParameters]) -> None:
            pass

        async def _setup_async(self, *, context: AttackContext[AttackParameters]) -> None:
            self.setup_count += 1

        async def _teardown_async(self, *, context: AttackContext[AttackParameters]) -> None:
            pass

        async def _perform_async(self, *, context: AttackContext[AttackParameters]) -> "AttackResult":
            self.perform_count += 1
            if self.fail:
                raise RuntimeError("Probe failed")
            return AttackResult(conversation_id="probe", objective=context.objective)

    return _CountingAttack(fail=fail)


async def run_attack_during_deletion_async(
    *,
    attack_coro: Awaitable[Any],
    target: Any,
    delete_operation: Callable[[], Awaitable[Any]],
) -> Any:
    """Launch an attack, delete its operation mid-send, release, and return the result.

    Orchestration only - the caller supplies:
      * ``attack_coro``: the not-yet-awaited attack execution coroutine
        (e.g. ``PromptSendingAttack(objective_target=target).execute_async(...)``
        or an ``AttackExecutor().execute_attack_async(...)``),
      * ``target``: the pausable target the attack sends through, and
      * ``delete_operation``: a zero-arg async callable that removes the operation
        (the caller decides, by reading the submitted patch, which coroutine does
        the removal - this helper never names it).

    Everything runs on one event loop so the attack and the deletion share the
    store. Wrap the whole call in ``run_async(...)``.
    """
    task = asyncio.ensure_future(attack_coro)
    try:
        await asyncio.wait_for(target.sending.wait(), timeout=_RENDEZVOUS_TIMEOUT)
        await delete_operation()
        target.release.set()
        return await asyncio.wait_for(task, timeout=_RENDEZVOUS_TIMEOUT)
    finally:
        if not task.done():
            target.release.set()
            task.cancel()


# ---------------------------------------------------------------------------
# True-concurrency race orchestration for the delete/insert story
# ---------------------------------------------------------------------------


def _enable_sqlite_foreign_keys(dbapi_connection: Any, _record: Any) -> None:
    """Turn on SQLite foreign-key enforcement for every connection in a pool."""
    cursor = dbapi_connection.cursor()
    cursor.execute("PRAGMA foreign_keys=ON")
    cursor.close()


def _build_race_memory(*, path: str, foreign_keys: bool) -> "SQLiteMemory":
    """Build a file-backed, migrated store, optionally one that enforces foreign keys.

    A FILE-backed store is used (not the in-memory one the other stories bind) on
    purpose: the in-memory store serializes whole transactions across event loops
    with a process-wide lock, so two coroutines can never actually interleave
    there. A file-backed store lets the delete and the insert run as genuinely
    concurrent transactions, which is what a true race needs. With
    ``foreign_keys=True`` the connection enforces referential integrity, standing
    in for a production engine that does - a store the default one does not model.
    """
    from pyrit.memory import SQLiteMemory

    memory = SQLiteMemory.__new__(SQLiteMemory)
    with patch.object(memory, "cleanup"):
        memory.__init__(db_path=path, silent=True)  # migrates the schema
    memory.disable_embedding()
    if foreign_keys:
        from sqlalchemy import event

        event.listen(memory.engine, "connect", _enable_sqlite_foreign_keys)
        _original_create_async_engine = memory._create_async_engine

        def _create_async_engine_with_fk() -> Any:
            engine = _original_create_async_engine()
            event.listen(engine.sync_engine, "connect", _enable_sqlite_foreign_keys)
            return engine

        memory._create_async_engine = _create_async_engine_with_fk  # type: ignore[method-assign]
    return memory


async def _run_one_delete_insert_trial(
    memory: "SQLiteMemory", delete_operation: Callable[[Any], Awaitable[Any]]
) -> "dict[str, Any]":
    """Create an operation, then race its removal against an attack-result insert.

    Both coroutines wait on one shared ``asyncio.Event`` and are released together
    with ``asyncio.gather`` so neither can win a head start. Returns an observation
    of what each side did and the resulting store state - the caller asserts the
    outcome, this helper names no behavior-under-test.
    """
    from pyrit.models import AttackResult, AttackResultSelection, Operation

    op = await memory.add_operation_async(Operation(name="Race-" + uuid.uuid4().hex))
    start = asyncio.Event()

    async def _remove() -> "tuple[str, Any]":
        await start.wait()
        try:
            return ("completed", await delete_operation(op.id))
        except BaseException as exc:  # noqa: BLE001 - the story classifies whatever is raised
            return ("raised", exc)

    async def _insert() -> "tuple[str, Any]":
        await start.wait()
        try:
            await memory.add_attack_results_to_memory_async(
                attack_results=[
                    AttackResult(conversation_id="race-" + op.id.hex, objective="objective", operation_id=op.id)
                ]
            )
            return ("completed", None)
        except BaseException as exc:  # noqa: BLE001
            return ("raised", exc)

    remove_task = asyncio.ensure_future(_remove())
    insert_task = asyncio.ensure_future(_insert())
    start.set()
    delete_outcome, insert_outcome = await asyncio.gather(remove_task, insert_task)

    ops = await memory.get_operations_async()
    saved = await memory.get_attack_results_async(result_selection=AttackResultSelection.ALL_RESULTS)
    present_ids = {o.id for o in ops}
    return {
        "delete_outcome": delete_outcome,
        "insert_outcome": insert_outcome,
        "op_present": op.id in present_ids,
        "my_rows": sum(1 for a in saved if a.operation_id == op.id),
        "orphan_rows": sum(1 for a in saved if a.operation_id is not None and a.operation_id not in present_ids),
    }


def run_delete_insert_race(
    *,
    delete_operation: Callable[[Any], Awaitable[Any]],
    foreign_keys: bool = False,
    iterations: int = 30,
) -> "list[dict[str, Any]]":
    """Race a removal against a referencing insert many times; return one observation per trial.

    The caller supplies ``delete_operation`` - a one-arg async callable that takes
    an operation id and performs the removal the solution added (discovered from
    the submitted patch; this helper never names it). Each trial runs on a fresh
    file-backed store so the delete and insert are genuinely concurrent, and the
    whole race is repeated ``iterations`` times because the losing interleave is
    timing-dependent. Each observation is a dict with:

      * ``delete_outcome`` / ``insert_outcome`` - ``(kind, value)`` where ``kind``
        is ``"completed"`` or ``"raised"``; ``value`` is the return value (delete)
        or the raised exception.
      * ``op_present`` - whether the operation still exists after the race.
      * ``my_rows`` - saved attack rows that reference this operation's id.
      * ``orphan_rows`` - saved rows whose operation id is absent from the store.
    """
    observations: "list[dict[str, Any]]" = []
    for _ in range(iterations):
        workdir = tempfile.mkdtemp()
        memory = _build_race_memory(path=os.path.join(workdir, "race.db"), foreign_keys=foreign_keys)
        try:
            with memory_session_bound(memory):
                observations.append(run_async(_run_one_delete_insert_trial(memory, delete_operation)))
        finally:
            run_async(memory.dispose_engine_async())
    return observations


@contextmanager
def memory_session_bound(memory: "SQLiteMemory") -> Iterator["SQLiteMemory"]:
    """Bind an already-built store to ``CentralMemory`` for the duration.

    Like ``memory_session()`` but for a store the caller constructed (the race
    orchestrator builds file-backed / FK-enforcing stores itself). Disposal is the
    caller's responsibility.
    """
    from test_support.fixtures import use_sqlite_memory

    with use_sqlite_memory(memory):
        yield memory
