#nullable enable
using System.Collections;
using Jint;
using Jint.Runtime;

namespace Jint.Tests.PublicInterface;

// Compare host operations with ordinary JavaScript objects built from public
// property observations and fixture values. CLR exceptions are never normalized.
public class VerifyHostCountedCollection
{
    public static TheoryData<string> CountedButNotIndexed => new()
    {
        nameof(Queue<int>), nameof(Stack<int>), nameof(LinkedList<int>),
        nameof(SortedSet<int>), nameof(HashSet<int>), nameof(BareCountedCollection),
    };

    private static object MakeCollection(string kind, int[]? items = null) => kind switch
    {
        nameof(Queue<int>) => new Queue<int>(items ?? [1, 2, 3]),
        nameof(Stack<int>) => new Stack<int>((items ?? [1, 2, 3]).Reverse()),
        nameof(LinkedList<int>) => new LinkedList<int>(items ?? [1, 2, 3]),
        nameof(SortedSet<int>) => new SortedSet<int>(items ?? [1, 2, 3]),
        nameof(BareCountedCollection) => new BareCountedCollection(items),
        _ => new HashSet<int>(items ?? [1, 2, 3]),
    };

    private static Engine MakeEngine(object host, Action<Options>? configure = null)
    {
        var engine = new Engine(options => configure?.Invoke(options));
        engine.SetValue("host", host);
        return engine;
    }

    private static void InstallOrdinaryObjectFactory(Engine engine, object host)
    {
        engine.SetValue("getFixtureItems", new Func<int[]>(() => ((IEnumerable) host).Cast<int>().ToArray()));
        engine.Execute("""
            function ordinaryObject(source) {
                const result = Object.create(Object.getPrototypeOf(source));
                const lengthDescriptor = Object.getOwnPropertyDescriptor(source, 'length');
                Object.defineProperty(result, 'length', {
                    get: function () { return source.length; },
                    enumerable: lengthDescriptor.enumerable,
                    configurable: lengthDescriptor.configurable
                });
                for (let i = 0; i < source.length; i++) {
                    if (i in source) {
                        Object.defineProperty(result, String(i), {
                            get: function () { return source[i]; },
                            enumerable: true,
                            configurable: true
                        });
                    }
                }
                Object.defineProperty(result, Symbol.iterator, {
                    value: function* () {
                        const values = getFixtureItems();
                        for (let i = 0; i < values.length; i++) yield values[i];
                    },
                    configurable: true
                });
                return result;
            }
            """);
    }

    private static readonly string[] Reads =
    [
        "x => Array.prototype.join.call(x, '-')",
        "x => Array.prototype.map.call(x, v => v * 2)",
        "x => Array.prototype.slice.call(x)",
        "x => { const visits = []; const result = Array.prototype.filter.call(x, v => { visits.push(v); return true; }); return [result, visits]; }",
        "x => Array.prototype.indexOf.call(x, 2)",
        "x => Array.prototype.lastIndexOf.call(x, 2)",
        "x => Array.prototype.includes.call(x, 2)",
        "x => { const visits = []; Array.prototype.forEach.call(x, v => visits.push(v)); return visits; }",
    ];

    private static readonly string[] Bindings =
    [
        "x => { var [...r] = x; return r; }",
        "x => { var [first] = x; return first; }",
        "x => { var [, second] = x; return second; }",
    ];

    private static string Observe(Engine engine, object host, string operation, bool useOrdinaryObject)
    {
        InstallOrdinaryObjectFactory(engine, host);
        engine.SetValue("useOrdinaryObject", useOrdinaryObject);
        engine.SetValue("observeAppend", operation.Contains("Array.prototype.push"));
        var observation = engine.Evaluate("""
            (function () {
                const x = useOrdinaryObject ? ordinaryObject(host) : host;
                function encode(value) {
                    if (value === x) return { receiver: true };
                    if (value === undefined) return { undefined: true };
                    if (Array.isArray(value)) {
                        return { length: value.length, entries: Object.keys(value).map(k => [k, encode(value[k])]) };
                    }
                    return value;
                }
                function profile() {
                    const entries = [];
                    for (let i = 0; i < x.length; i++) entries.push([i in x, encode(x[i])]);
                    return { length: x.length, arrayPrototype: Object.getPrototypeOf(x) === Array.prototype,
                        boundary: observeAppend ? [x.length in x, encode(x[x.length])] : null, entries: entries };
                }
                const before = profile();
                let outcome;
                try { outcome = { returned: encode((
            """ + operation + """
                )(x)) }; }
                catch (e) { outcome = { error: e.name }; }
                return JSON.stringify({ before: before, outcome: outcome, after: profile() });
            })()
            """).AsString();
        return observation + "|host:" + string.Join(",", ((IEnumerable) host).Cast<int>());
    }

    private static void AssertEquivalent(Func<object> factory, string operation, Action<Options>? configure = null)
    {
        var direct = factory();
        var ordinary = factory();
        var expected = Observe(MakeEngine(ordinary, configure), ordinary, operation, true);
        var actual = Observe(MakeEngine(direct, configure), direct, operation, false);
        actual.Should().Be(expected, operation);
    }

    [Theory]
    [MemberData(nameof(CountedButNotIndexed))]
    public void ArrayMethodsFollowJavaScriptSemantics(string kind)
    {
        foreach (var operation in Reads) AssertEquivalent(() => MakeCollection(kind), operation);
    }

    [Theory]
    [MemberData(nameof(CountedButNotIndexed))]
    public void EmptyAndNontrivialCollectionsFollowTheSameContract(string kind)
    {
        foreach (var items in new[] { Array.Empty<int>(), new[] { 17 }, new[] { 9, -2, 5, 8 } })
        {
            foreach (var operation in Reads.Concat(Bindings))
                AssertEquivalent(() => MakeCollection(kind, items), operation);
            var host = MakeCollection(kind, items);
            var expected = string.Join(",", ((IEnumerable) host).Cast<int>());
            MakeEngine(host).Evaluate("[...host].join(',')").Should().Be(expected);
        }
    }

    [Fact]
    public void LengthAndIterationStayLiveAfterHostChanges()
    {
        var direct = new Queue<int>();
        var ordinary = new Queue<int>();
        var a = MakeEngine(direct);
        var b = MakeEngine(ordinary);
        foreach (var items in new[] { new[] { 1, 2, 3 }, Array.Empty<int>(), new[] { 17 }, new[] { 9, -2, 5, 8 } })
        {
            direct.Clear(); ordinary.Clear();
            foreach (var item in items) { direct.Enqueue(item); ordinary.Enqueue(item); }
            a.Evaluate("host.length").Should().Be(items.Length);
            a.Evaluate("[...host].join(',')").Should().Be(string.Join(",", items));
            foreach (var operation in Reads.Concat(Bindings))
                Observe(a, direct, operation, false).Should().Be(Observe(b, ordinary, operation, true));
        }
    }

    [Theory]
    [MemberData(nameof(CountedButNotIndexed))]
    public void EveryIteratingFormYieldsTheRealElements(string kind)
    {
        foreach (var operation in new[] { "x => [...x]", "x => Array.from(x)", "x => { const r = []; for (const v of x) r.push(v); return r; }" })
            AssertEquivalent(() => MakeCollection(kind), operation);
        var host = MakeCollection(kind);
        MakeEngine(host).Evaluate("[...host].join(',')").Should().Be(string.Join(",", ((IEnumerable) host).Cast<int>()));
    }

    [Theory]
    [MemberData(nameof(CountedButNotIndexed))]
    public void DestructuringFollowsJavaScriptSemantics(string kind)
    {
        foreach (var operation in Bindings) AssertEquivalent(() => MakeCollection(kind), operation);
        var host = MakeCollection(kind);
        MakeEngine(host).Evaluate("(function () { var [...r] = host; return r.join(','); })()")
            .Should().Be(string.Join(",", ((IEnumerable) host).Cast<int>()));
    }

    [Theory]
    [MemberData(nameof(CountedButNotIndexed))]
    public void NothingSurfacesExceptAJavaScriptException(string kind)
    {
        // whatever the answer for each operation is, reads and writes alike must stay inside the engine:
        // the only exception a script may raise to the host is a JavaScriptException
        string[] scripts =
        [
            "Array.prototype.join.call(host, '-')",
            "Array.prototype.map.call(host, function (x) { return x; })",
            "Array.prototype.filter.call(host, function () { return true; })",
            "Array.prototype.forEach.call(host, function () { })",
            "Array.prototype.indexOf.call(host, 2)",
            "Array.prototype.lastIndexOf.call(host, 2)",
            "Array.prototype.includes.call(host, 2)",
            "Array.prototype.slice.call(host)",
            "Array.prototype.every.call(host, function () { return true; })",
            "Array.prototype.some.call(host, function () { return true; })",
            "Array.prototype.reduce.call(host, function (a, b) { return a + b; }, 0)",
            "Array.prototype.flat.call(host)",
            "Array.prototype.toString.call(host)",
            "[...host]",
            "Array.from(host)",
            "(function () { var [...r] = host; return r; })()",
            "Math.max.apply(null, host)",
            "JSON.stringify(host)",
            "try { Array.prototype.sort.call(host); } catch (e) { }",
            "try { Array.prototype.reverse.call(host); } catch (e) { }",
            "try { Array.prototype.push.call(host, 4); } catch (e) { }",
            "try { Array.prototype.pop.call(host); } catch (e) { }",
            "try { Array.prototype.fill.call(host, 0); } catch (e) { }",
            "try { Array.prototype.splice.call(host, 0, 1); } catch (e) { }",
        ];

        foreach (var script in scripts)
        {
            var engine = MakeEngine(MakeCollection(kind));
            try
            {
                engine.Evaluate(script);
            }
            catch (JavaScriptException)
            {
                // a script-level error is a legitimate answer; a CLR exception is the defect
            }
            catch (Exception exception)
            {
                Assert.Fail($"'{script}' leaked a {exception.GetType().FullName} for a {kind}");
            }
        }
    }

    [Theory]
    [MemberData(nameof(CountedButNotIndexed))]
    public void PushFollowsJavaScriptSemantics(string kind)
    {
        AssertEquivalent(() => MakeCollection(kind), "x => Array.prototype.push.call(x, 4)");
    }

    [Theory]
    [MemberData(nameof(CountedButNotIndexed))]
    public void ReorderingFollowsJavaScriptSemantics(string kind)
    {
        AssertEquivalent(() => MakeCollection(kind), "x => Array.prototype.sort.call(x)");
        AssertEquivalent(() => MakeCollection(kind), "x => Array.prototype.reverse.call(x)");
    }

    [Fact]
    public void CustomIndexedCollectionFollowsJavaScriptSemantics()
    {
        foreach (var operation in Reads.Concat(Bindings))
            AssertEquivalent(() => new IndexedCountedCollection(), operation);
    }

    [Fact]
    public void AnIndexableListStaysUnchanged()
    {
        foreach (var operation in Reads.Concat(Bindings))
            AssertEquivalent(() => new List<int> { 1, 2, 3 }, operation);
    }

    [Theory]
    [MemberData(nameof(CountedButNotIndexed))]
    public void ConversionModesChangeNothing(string kind)
    {
        foreach (var configure in new Action<Options>[]
        {
            o => o.Interop.ArrayConversion = ArrayConversionMode.LiveView,
            o => o.Interop.EnumerableConversion = EnumerableConversionMode.Snapshot,
        })
        foreach (var operation in Reads.Concat(Bindings))
        {
            AssertEquivalent(() => MakeCollection(kind), operation, configure);
            var a = MakeCollection(kind);
            var b = MakeCollection(kind);
            Observe(MakeEngine(a, configure), a, operation, false)
                .Should().Be(Observe(MakeEngine(b), b, operation, false));
        }
    }

    private sealed class BareCountedCollection : ICollection
    {
        private readonly int[] _items;

        public BareCountedCollection(int[]? items = null)
        {
            _items = items ?? new[] { 1, 2, 3 };
        }

        public int Count => _items.Length;

        public bool IsSynchronized => false;

        public object SyncRoot => this;

        public void CopyTo(Array array, int index) => _items.CopyTo(array, index);

        public IEnumerator GetEnumerator() => _items.GetEnumerator();
    }

    private sealed class IndexedCountedCollection : ICollection
    {
        private readonly int[] _items = [1, 2, 3];

        public int Count => _items.Length;

        public bool IsSynchronized => false;

        public object SyncRoot => this;

        public int this[int index] => _items[index];

        public void CopyTo(Array array, int index) => _items.CopyTo(array, index);

        public IEnumerator GetEnumerator() => _items.GetEnumerator();
    }

    // Ordinary JavaScript controls pin the language-level outcomes independently of host operations.
    private static Engine MakeOrdinaryEngine(object host, Action<Options>? configure = null)
    {
        var engine = MakeEngine(host, configure);
        InstallOrdinaryObjectFactory(engine, host);
        engine.Execute("host = ordinaryObject(host);");
        return engine;
    }

    [Theory]
    [MemberData(nameof(CountedButNotIndexed))]
    public void Ordinary_LengthIsHonouredButIndexReadsFindNothing(string kind)
    {
        var engine = MakeOrdinaryEngine(MakeCollection(kind));

        engine.Evaluate("host.length").Should().Be(3);
        engine.Evaluate("Object.getPrototypeOf(host) === Array.prototype").Should().BeTrue();

        engine.Evaluate("host[0]").Should().BeUndefined();
        engine.Evaluate("'0' in host").Should().BeFalse();
        engine.Evaluate("Array.prototype.join.call(host, '-')").Should().Be("--");
        engine.Evaluate("Array.prototype.map.call(host, function (x) { return x; }).join('-')").Should().Be("--");
        engine.Evaluate("Array.prototype.slice.call(host).length").Should().Be(3);
        engine.Evaluate("Array.prototype.filter.call(host, function () { return true; }).length").Should().Be(0);
        engine.Evaluate("Array.prototype.indexOf.call(host, 2)").Should().Be(-1);
        engine.Evaluate("Array.prototype.includes.call(host, 2)").Should().BeFalse();
        engine.Evaluate("""
            var visited = 0;
            Array.prototype.forEach.call(host, function () { visited++; });
            visited;
            """).Should().Be(0);
    }

    [Theory]
    [MemberData(nameof(CountedButNotIndexed))]
    public void Ordinary_EmptyAndNontrivialCollectionsFollowTheSameContract(string kind)
    {
        foreach (var items in new[] { Array.Empty<int>(), new[] { 17 }, new[] { 9, -2, 5, 8 } })
        {
            var host = MakeCollection(kind, items);
            var expected = ((IEnumerable) host).Cast<int>().ToArray();
            var engine = MakeOrdinaryEngine(host);

            engine.Evaluate("host.length").Should().Be(expected.Length);
            engine.Evaluate("'0' in host").Should().BeFalse();
            engine.Evaluate("Array.prototype.join.call(host, '-')")
                .Should().Be(new string('-', Math.Max(0, expected.Length - 1)));
            engine.Evaluate("Array.prototype.filter.call(host, function () { return true; }).length").Should().Be(0);
            engine.Evaluate("[...host].join(',')").Should().Be(string.Join(",", expected));
            engine.Evaluate("Array.from(host).join(',')").Should().Be(string.Join(",", expected));
            engine.Evaluate("(function () { var [...r] = host; return r.join(','); })()")
                .Should().Be(string.Join(",", expected));
        }
    }

    [Fact]
    public void Ordinary_LengthAndIterationStayLiveAfterHostChanges()
    {
        var host = new Queue<int>(new[] { 1, 2, 3 });
        var engine = MakeOrdinaryEngine(host);
        engine.Evaluate("Array.prototype.join.call(host, '-')").Should().Be("--");
        engine.Evaluate("[...host].join(',')").Should().Be("1,2,3");

        foreach (var items in new[] { Array.Empty<int>(), new[] { 17 }, new[] { 9, -2, 5, 8 } })
        {
            host.Clear();
            foreach (var item in items)
            {
                host.Enqueue(item);
            }

            engine.Evaluate("host.length").Should().Be(items.Length);
            engine.Evaluate("Array.prototype.join.call(host, '-')")
                .Should().Be(new string('-', Math.Max(0, items.Length - 1)));
            engine.Evaluate("[...host].join(',')").Should().Be(string.Join(",", items));
            engine.Evaluate("(function () { var [...r] = host; return r.join(','); })()")
                .Should().Be(string.Join(",", items));
        }
    }

    [Theory]
    [MemberData(nameof(CountedButNotIndexed))]
    public void Ordinary_EveryIteratingFormYieldsTheRealElements(string kind)
    {
        var engine = MakeOrdinaryEngine(MakeCollection(kind));

        engine.Evaluate("[...host].join('-')").Should().Be("1-2-3");
        engine.Evaluate("Array.from(host).join('-')").Should().Be("1-2-3");
        engine.Evaluate("(function () { var r = []; for (var x of host) { r.push(x); } return r.join('-'); })()")
            .Should().Be("1-2-3");
    }

    [Theory]
    [MemberData(nameof(CountedButNotIndexed))]
    public void Ordinary_DestructuringAgreesWithSpread(string kind)
    {
        var engine = MakeOrdinaryEngine(MakeCollection(kind));

        engine.Evaluate("(function () { var [...r] = host; return r.join('-'); })()").Should().Be("1-2-3");
        engine.Evaluate("(function () { var [first] = host; return first; })()").Should().Be(1);
        engine.Evaluate("(function () { var [, second] = host; return second; })()").Should().Be(2);
    }

    [Theory]
    [MemberData(nameof(CountedButNotIndexed))]
    public void Ordinary_NothingSurfacesExceptAJavaScriptException(string kind)
    {
        string[] scripts =
        [
            "Array.prototype.join.call(host, '-')",
            "Array.prototype.map.call(host, function (x) { return x; })",
            "Array.prototype.filter.call(host, function () { return true; })",
            "Array.prototype.forEach.call(host, function () { })",
            "Array.prototype.indexOf.call(host, 2)",
            "Array.prototype.lastIndexOf.call(host, 2)",
            "Array.prototype.includes.call(host, 2)",
            "Array.prototype.slice.call(host)",
            "Array.prototype.every.call(host, function () { return true; })",
            "Array.prototype.some.call(host, function () { return true; })",
            "Array.prototype.reduce.call(host, function (a, b) { return a + b; }, 0)",
            "Array.prototype.flat.call(host)",
            "Array.prototype.toString.call(host)",
            "[...host]",
            "Array.from(host)",
            "(function () { var [...r] = host; return r; })()",
            "Math.max.apply(null, host)",
            "JSON.stringify(host)",
            "try { Array.prototype.sort.call(host); } catch (e) { }",
            "try { Array.prototype.reverse.call(host); } catch (e) { }",
            "try { Array.prototype.push.call(host, 4); } catch (e) { }",
            "try { Array.prototype.pop.call(host); } catch (e) { }",
            "try { Array.prototype.fill.call(host, 0); } catch (e) { }",
            "try { Array.prototype.splice.call(host, 0, 1); } catch (e) { }",
        ];

        foreach (var script in scripts)
        {
            var engine = MakeOrdinaryEngine(MakeCollection(kind));
            try
            {
                engine.Evaluate(script);
            }
            catch (JavaScriptException)
            {
            }
            catch (Exception exception)
            {
                Assert.Fail($"'{script}' leaked a {exception.GetType().FullName} for a {kind}");
            }
        }
    }

    [Theory]
    [MemberData(nameof(CountedButNotIndexed))]
    public void Ordinary_GrowingRaisesACatchableTypeError(string kind)
    {
        var engine = MakeOrdinaryEngine(MakeCollection(kind));

        engine.Evaluate("""
            try {
                Array.prototype.push.call(host, 4);
                'no throw';
            } catch (e) {
                e instanceof TypeError ? 'TypeError' : 'other: ' + e;
            }
            """).Should().Be("TypeError");

        var throwsToHost = () => engine.Evaluate("Array.prototype.push.call(host, 4)");
        throwsToHost.Should().Throw<JavaScriptException>();
    }

    [Theory]
    [MemberData(nameof(CountedButNotIndexed))]
    public void Ordinary_OrderMutatingGenericsAreNoOps(string kind)
    {
        var engine = MakeOrdinaryEngine(MakeCollection(kind));

        engine.Evaluate("Array.prototype.sort.call(host) === host").Should().BeTrue();
        engine.Evaluate("Array.prototype.reverse.call(host) === host").Should().BeTrue();
        engine.Evaluate("[...host].join('-')").Should().Be("1-2-3");
    }

    [Fact]
    public void Ordinary_AnIntegerIndexerDecidesWhetherElementsAreFound()
    {
        var engine = MakeOrdinaryEngine(new IndexedCountedCollection());

        engine.Evaluate("host.length").Should().Be(3);
        engine.Evaluate("host[0]").Should().Be(1);
        engine.Evaluate("Array.prototype.join.call(host, '-')").Should().Be("1-2-3");
        engine.Evaluate("Array.prototype.indexOf.call(host, 2)").Should().Be(1);
        engine.Evaluate("Array.prototype.filter.call(host, function (x) { return x > 1; }).join('-')").Should().Be("2-3");
        engine.Evaluate("(function () { var [...r] = host; return r.join('-'); })()").Should().Be("1-2-3");
    }

    [Fact]
    public void Ordinary_AnIndexableListStaysUnchanged()
    {
        var engine = MakeOrdinaryEngine(new List<int> { 1, 2, 3 });

        engine.Evaluate("host.length").Should().Be(3);
        engine.Evaluate("host[0]").Should().Be(1);
        engine.Evaluate("'0' in host").Should().BeTrue();
        engine.Evaluate("Array.prototype.join.call(host, '-')").Should().Be("1-2-3");
        engine.Evaluate("Array.prototype.indexOf.call(host, 2)").Should().Be(1);
        engine.Evaluate("Array.prototype.map.call(host, function (x) { return x * 2; }).join('-')").Should().Be("2-4-6");
        engine.Evaluate("(function () { var [...r] = host; return r.join('-'); })()").Should().Be("1-2-3");
    }

    [Theory]
    [MemberData(nameof(CountedButNotIndexed))]
    public void Ordinary_ConversionModesChangeNothing(string kind)
    {
        foreach (var configure in new Action<Options>[]
                 {
                     o => o.Interop.ArrayConversion = ArrayConversionMode.LiveView,
                     o => o.Interop.EnumerableConversion = EnumerableConversionMode.Snapshot,
                 })
        {
            var engine = MakeOrdinaryEngine(MakeCollection(kind), configure);

            engine.Evaluate("host.length").Should().Be(3);
            engine.Evaluate("Array.prototype.join.call(host, '-')").Should().Be("--");
            engine.Evaluate("[...host].join('-')").Should().Be("1-2-3");
        }
    }

}
