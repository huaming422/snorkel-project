## Task

Some scripts break when a .NET collection is passed to Jint. With a Queue<int> containing 1, 2, 3 exposed as host, Array.prototype.join.call(host, '-') fails. Array destructuring can also fail to deliver the collection's values.

Please fix collection use in scripts, including collections supplied by an embedder. Array methods and destructuring must follow standard JavaScript semantics for the exposed object. The public embedding API, its conversion options and later host-side changes should keep working as covered by the existing public interop tests.
