package dolt

// Behavioral verification for the server-Dolt write path at the commit
// boundary. These tests drive the pre-existing public store surface
// (ClaimIssue / ClaimReadyIssue / UpdateIssueChecked / UpdateIssue /
// MergeMetadata) through an injectable database/sql driver that counts each
// write phase (row mutation, staging, versioned commit, SQL commit/rollback,
// transaction attempts). The driver is the only seam needed: every assertion
// is expressed in terms of observable phase counts and the error the caller
// receives, never in terms of any internal helper, error value, or message
// string that a fix is free to name. The only error values named are the
// precondition refusals the store already defines at the base commit.
//
// The file owns TestMain so the runner executes it in isolation from the
// package's other test files; every identifier below is self-contained and
// prefixed `vrf` to avoid colliding with package-level test helpers.

import (
	"context"
	"database/sql"
	"database/sql/driver"
	"encoding/json"
	"errors"
	"io"
	"os"
	"strings"
	"sync"
	"testing"

	mysql "github.com/go-sql-driver/mysql"

	"github.com/steveyegge/beads/internal/storage"
	"github.com/steveyegge/beads/internal/storage/issueops"
	"github.com/steveyegge/beads/internal/types"
)

func TestMain(m *testing.M) {
	os.Exit(m.Run())
}

// vrfConnLoss models a transport-level connection drop, the short blip the
// reported symptom lines up with. The tests inject it at different phases of a
// write and observe what the caller is told and how many times the write ran.
var vrfConnLoss = errors.New("invalid connection")

// vrfBoundaryDriver models a permanent issue write through its SQL mutation,
// staging, and versioned-commit phases, and records a counter for each phase
// so the number of times a write ran, the number of commits issued, and the
// reads made after a commit are all observable.
type vrfBoundaryDriver struct {
	mu sync.Mutex

	// Injected outcomes.
	stageErr        error
	commitErr       error // returned from the first versioned-commit call only
	mutationErrOnce error // returned from the first claim row mutation, then cleared
	sqlCommitErr    error
	nothingToCommit bool
	checkedUpdate   bool
	verifyAssignee  string
	verifyStatus    types.Status
	// landedAfterCommit models the lost-response commit having actually
	// landed: once the first versioned commit has been issued, every read of
	// the row (its coordination state and the full row) shows the write
	// applied. This is the world the reported symptom lives in: the write
	// landed although its caller never heard so.
	landedAfterCommit bool
	// landedTitle is the title the row shows once a landed commit is visible
	// (landedAfterCommit), for example the value a concurrent writer set after
	// our commit; empty keeps the fixture title.
	landedTitle string

	// Observed phase counters.
	claimMutations  int
	claimedIDs      []string
	updateMutations int
	eventInserts    int
	claimStateReads int
	// rowReadsAfterCommit counts reads of the row (its coordination state or
	// the full row) made after the first versioned commit was issued: a store
	// that resolves an uncertain commit by re-reading the row is observable
	// here.
	rowReadsAfterCommit int
	// commitSucceeded is set once a versioned commit returned normally, so the
	// row then reads as claimed: a store that verifies a reported success by
	// re-reading the row (as the server-mode store does) sees the claim it made.
	commitSucceeded bool
	stageCalls      int
	doltCommits     int
	txCommits       int
	txRollbacks     int
	txAttempts      int
	// writeAttempts counts transactions in which a row mutation ran, which is
	// how many times the write itself was executed. Read-only transactions
	// open a transaction too and are not counted here.
	writeAttempts int
	txMutated     bool
	activeID      string
	readyIDs      []string
}

func (d *vrfBoundaryDriver) Open(string) (driver.Conn, error) {
	return &vrfBoundaryConn{driver: d}, nil
}

func (d *vrfBoundaryDriver) Connect(context.Context) (driver.Conn, error) {
	return &vrfBoundaryConn{driver: d}, nil
}

func (d *vrfBoundaryDriver) Driver() driver.Driver { return d }

type vrfBoundaryConn struct {
	driver *vrfBoundaryDriver
}

func (c *vrfBoundaryConn) Prepare(string) (driver.Stmt, error) {
	return nil, errors.New("vrf boundary driver does not prepare statements")
}

func (c *vrfBoundaryConn) Close() error { return nil }

func (c *vrfBoundaryConn) Begin() (driver.Tx, error) {
	c.driver.mu.Lock()
	c.driver.txAttempts++
	c.driver.txMutated = false
	c.driver.activeID = "vrf-boundary"
	if len(c.driver.readyIDs) > 0 {
		index := c.driver.txAttempts - 1
		if index >= len(c.driver.readyIDs) {
			index = len(c.driver.readyIDs) - 1
		}
		c.driver.activeID = c.driver.readyIDs[index]
	}
	c.driver.mu.Unlock()
	return &vrfBoundaryTx{driver: c.driver}, nil
}

func (c *vrfBoundaryConn) QueryContext(_ context.Context, query string, _ []driver.NamedValue) (driver.Rows, error) {
	c.driver.mu.Lock()
	defer c.driver.mu.Unlock()

	switch {
	case strings.Contains(query, "SELECT 1 FROM wisps WHERE id = ? LIMIT 1"):
		return &vrfBoundaryRows{columns: []string{"exists"}}, nil
	case strings.Contains(query, "SELECT assignee, status FROM issues WHERE id = ?"):
		c.driver.claimStateReads++
		if c.driver.doltCommits >= 1 {
			c.driver.rowReadsAfterCommit++
		}
		assignee, status := c.driver.coordinationState()
		return &vrfBoundaryRows{
			columns: []string{"assignee", "status"},
			values:  [][]driver.Value{{assignee, string(status)}},
		}, nil
	case strings.Contains(query, "SELECT metadata FROM issues WHERE id = ?"):
		if c.driver.doltCommits >= 1 {
			c.driver.rowReadsAfterCommit++
		}
		return &vrfBoundaryRows{
			columns: []string{"metadata"},
			values:  [][]driver.Value{{"{}"}},
		}, nil
	case strings.Contains(query, "SELECT id FROM issues"):
		return &vrfBoundaryRows{
			columns: []string{"id"},
			values:  [][]driver.Value{{c.driver.activeID}},
		}, nil
	case strings.Contains(query, "FROM issues") && strings.Contains(query, "LEFT JOIN leases") && strings.Contains(query, "WHERE id IN ("):
		assignee, status := c.driver.coordinationState()
		return &vrfBoundaryRows{
			columns: vrfIssueColumns(),
			values:  [][]driver.Value{vrfIssueValues(c.driver.activeID, c.driver.title(), assignee, status)},
		}, nil
	case strings.Contains(query, "FROM issues") && strings.Contains(query, "LEFT JOIN leases") && strings.Contains(query, "WHERE id = ?"):
		if c.driver.doltCommits >= 1 {
			c.driver.rowReadsAfterCommit++
		}
		assignee, status := c.driver.coordinationState()
		return &vrfBoundaryRows{
			columns: vrfIssueColumns(),
			values:  [][]driver.Value{vrfIssueValues(c.driver.activeID, c.driver.title(), assignee, status)},
		}, nil
	case strings.Contains(query, "SELECT label FROM labels"):
		return &vrfBoundaryRows{columns: []string{"label"}}, nil
	case strings.Contains(query, "SELECT issue_id, label FROM labels"):
		return &vrfBoundaryRows{columns: []string{"issue_id", "label"}}, nil
	case strings.Contains(query, "SELECT name, category FROM custom_statuses"):
		return &vrfBoundaryRows{columns: []string{"name", "category"}}, nil
	case strings.Contains(query, "SELECT value FROM config"):
		return &vrfBoundaryRows{columns: []string{"value"}}, nil
	case strings.Contains(query, "CALL DOLT_ADD"):
		c.driver.stageCalls++
		if c.driver.stageErr != nil {
			return nil, c.driver.stageErr
		}
		return &vrfBoundaryRows{columns: []string{"status"}}, nil
	case strings.Contains(query, "CALL DOLT_COMMIT"):
		c.driver.doltCommits++
		if c.driver.commitErr != nil && c.driver.doltCommits == 1 {
			return nil, c.driver.commitErr
		}
		if c.driver.nothingToCommit {
			return nil, errors.New("nothing to commit")
		}
		c.driver.commitSucceeded = true
		return &vrfBoundaryRows{columns: []string{"hash"}}, nil
	default:
		return &vrfBoundaryRows{columns: []string{"value"}}, nil
	}
}

func (c *vrfBoundaryConn) ExecContext(_ context.Context, query string, _ []driver.NamedValue) (driver.Result, error) {
	c.driver.mu.Lock()
	defer c.driver.mu.Unlock()
	if strings.Contains(query, "UPDATE issues") || strings.Contains(query, "INSERT INTO events") || strings.Contains(query, "INSERT INTO issues") {
		if !c.driver.txMutated {
			c.driver.txMutated = true
			c.driver.writeAttempts++
		}
	}
	if strings.Contains(query, "UPDATE issues") && strings.Contains(query, "SET assignee") {
		c.driver.claimMutations++
		c.driver.claimedIDs = append(c.driver.claimedIDs, c.driver.activeID)
		if c.driver.mutationErrOnce != nil {
			err := c.driver.mutationErrOnce
			c.driver.mutationErrOnce = nil
			return nil, err
		}
	}
	if strings.Contains(query, "UPDATE issues") && strings.Contains(query, "`title`") {
		c.driver.updateMutations++
	}
	if strings.Contains(query, "INSERT INTO events") {
		c.driver.eventInserts++
	}
	return driver.RowsAffected(1), nil
}

// title is the title the row currently shows: the fixture title until a
// landed commit (landedAfterCommit with a landedTitle) is visible. The caller
// holds mu.
func (d *vrfBoundaryDriver) title() string {
	if d.landedTitle != "" && d.landedAfterCommit && d.doltCommits >= 1 {
		return d.landedTitle
	}
	return "vrf boundary"
}

// coordinationState is the assignee/status the row currently shows. Before
// any versioned commit it is the untouched open row. It shows the write
// applied once a versioned commit returned normally, once a commit has been
// issued when the driver models a landed lost-response commit
// (landedAfterCommit), or after the first precondition read when the driver
// models a checked update's verification target (checkedUpdate). The caller
// holds mu.
func (d *vrfBoundaryDriver) coordinationState() (string, types.Status) {
	applied := d.commitSucceeded ||
		(d.landedAfterCommit && d.doltCommits >= 1) ||
		(d.checkedUpdate && d.claimStateReads > 1)
	if !applied {
		return "", types.StatusOpen
	}
	assignee, status := d.verifyAssignee, d.verifyStatus
	if assignee == "" {
		assignee = "alice"
	}
	if status == "" {
		status = types.StatusInProgress
	}
	return assignee, status
}

type vrfBoundaryTx struct {
	driver *vrfBoundaryDriver
}

func (t *vrfBoundaryTx) Commit() error {
	t.driver.mu.Lock()
	defer t.driver.mu.Unlock()
	t.driver.txCommits++
	return t.driver.sqlCommitErr
}

func (t *vrfBoundaryTx) Rollback() error {
	t.driver.mu.Lock()
	defer t.driver.mu.Unlock()
	t.driver.txRollbacks++
	return nil
}

type vrfBoundaryRows struct {
	columns []string
	values  [][]driver.Value
	index   int
}

func (r *vrfBoundaryRows) Columns() []string { return r.columns }
func (r *vrfBoundaryRows) Close() error      { return nil }
func (r *vrfBoundaryRows) Next(dest []driver.Value) error {
	if r.index >= len(r.values) {
		return io.EOF
	}
	copy(dest, r.values[r.index])
	r.index++
	return nil
}

func vrfIssueColumns() []string {
	parts := strings.Split(strings.ReplaceAll(issueops.IssueSelectColumns, "\n", " "), ",")
	for i := range parts {
		parts[i] = strings.TrimSpace(parts[i])
	}
	return parts
}

func vrfIssueValues(id string, title string, assignee string, status types.Status) []driver.Value {
	values := make([]driver.Value, 0, len(vrfIssueColumns()))
	for _, column := range vrfIssueColumns() {
		switch column {
		case "id":
			values = append(values, id)
		case "title":
			values = append(values, title)
		case "description", "design", "acceptance_criteria", "notes":
			values = append(values, "")
		case "status":
			values = append(values, string(status))
		case "assignee":
			if assignee == "" {
				values = append(values, nil)
			} else {
				values = append(values, assignee)
			}
		case "priority":
			values = append(values, int64(2))
		case "issue_type":
			values = append(values, string(types.TypeTask))
		case "compaction_level":
			values = append(values, int64(0))
		default:
			values = append(values, nil)
		}
	}
	return values
}

// vrfNewStore builds a store over the injected driver in server mode, the
// deployment the reported symptom comes from (a Dolt SQL server reached over a
// network connection that can blip at commit time).
func vrfNewStore(d *vrfBoundaryDriver) *DoltStore {
	return &DoltStore{db: sql.OpenDB(d), serverMode: true}
}

// vrfIsPreconditionRefusal reports whether err is one of the store's
// pre-existing precondition refusals (the "already claimed" / "state changed
// out from under you" family). A write whose commit outcome is uncertain must
// never come back as one of these.
func vrfIsPreconditionRefusal(err error) bool {
	return errors.Is(err, storage.ErrAlreadyClaimed) ||
		errors.Is(err, storage.ErrNotOwner) ||
		errors.Is(err, storage.ErrAssigneeMismatch) ||
		errors.Is(err, storage.ErrStatusMismatch) ||
		errors.Is(err, storage.ErrVersionMismatch)
}

// vrfRequireUncertainOutcomeHonest checks the two outcomes a store may report
// for a write whose commit response was lost when the commit in fact landed:
//
//   - a failure that is not a precondition refusal (the caller learns the
//     write did not verifiably complete and can re-read), or
//   - success, but only if the store re-read the row after the lost commit
//     and so could show the write landed.
//
// Either way the write must have run exactly once with exactly one versioned
// commit issued. Rejected: a second run of the write, a precondition refusal,
// and a success that never looked at the row.
func vrfRequireUncertainOutcomeHonest(t *testing.T, op string, err error, d *vrfBoundaryDriver) {
	t.Helper()
	d.mu.Lock()
	defer d.mu.Unlock()
	if err != nil && vrfIsPreconditionRefusal(err) {
		t.Fatalf("%s error = %v, want either success after a verifying re-read or a failure that is not a precondition refusal (the write's commit outcome was uncertain, not refused)", op, err)
	}
	if err == nil && d.rowReadsAfterCommit == 0 {
		t.Fatalf("%s reported success without re-reading the row after the lost commit response; a success that never looked at the row cannot show the write landed", op)
	}
	if d.writeAttempts != 1 {
		t.Fatalf("%s write attempts = %d, want 1 (the write must not run a second time once the commit outcome is unknown)", op, d.writeAttempts)
	}
	if d.doltCommits != 1 {
		t.Fatalf("%s versioned-commit calls = %d, want 1 (the write must not run a second time once the commit outcome is unknown)", op, d.doltCommits)
	}
}

// TestClaimIssueCommitResponseLossIsNotReplayed covers a named claim whose
// versioned-commit response is lost although the commit landed. The claim
// must run exactly once: the store may surface the uncertain outcome as a
// failure that is not a precondition refusal, or re-read the row and report
// the verified success; it may not run the claim a second time (a second
// claim mutation and a second event row for one request) or report success
// without looking at the row.
func TestClaimIssueCommitResponseLossIsNotReplayed(t *testing.T) {
	d := &vrfBoundaryDriver{
		commitErr:         vrfConnLoss,
		landedAfterCommit: true,
		verifyAssignee:    "alice",
		verifyStatus:      types.StatusInProgress,
	}
	store := vrfNewStore(d)
	t.Cleanup(func() { _ = store.db.Close() })

	err := store.ClaimIssue(context.Background(), "vrf-boundary", "alice")

	vrfRequireUncertainOutcomeHonest(t, "ClaimIssue()", err, d)

	d.mu.Lock()
	defer d.mu.Unlock()
	if d.claimMutations != 1 {
		t.Fatalf("claim row mutations = %d, want 1 (the claim must not run a second time on an uncertain commit)", d.claimMutations)
	}
}

// TestClaimReadyIssueCommitResponseLossDoesNotDoubleClaim covers the dequeue
// variant: the first ready issue's claim landed but its commit response was
// lost. One request must claim one issue: the store may surface the uncertain
// outcome as a failure that is not a precondition refusal, or re-read the row
// it claimed and report that verified claim; it may not end up with a second
// ready issue claimed as well.
func TestClaimReadyIssueCommitResponseLossDoesNotDoubleClaim(t *testing.T) {
	d := &vrfBoundaryDriver{
		commitErr:         vrfConnLoss,
		readyIDs:          []string{"vrf-ready-first", "vrf-ready-second"},
		landedAfterCommit: true,
		verifyAssignee:    "alice",
		verifyStatus:      types.StatusInProgress,
	}
	store := vrfNewStore(d)
	t.Cleanup(func() { _ = store.db.Close() })

	claimed, err := store.ClaimReadyIssue(context.Background(), types.WorkFilter{}, "alice")

	vrfRequireUncertainOutcomeHonest(t, "ClaimReadyIssue()", err, d)
	if err != nil && claimed != nil {
		t.Fatalf("ClaimReadyIssue() claimed = %+v alongside an error, want nil while the commit outcome is unknown", claimed)
	}
	if err == nil && (claimed == nil || claimed.ID != "vrf-ready-first") {
		t.Fatalf("ClaimReadyIssue() claimed = %+v after a verified success, want the first ready issue", claimed)
	}

	d.mu.Lock()
	defer d.mu.Unlock()
	if got, want := strings.Join(d.claimedIDs, ","), "vrf-ready-first"; got != want {
		t.Fatalf("claimed IDs = %q, want %q (one request must not claim a second ready issue)", got, want)
	}
}

// TestUpdateIssueCheckedMixedCommitLossIsNotMasked covers a guarded update
// that sets coordination fields (assignee/status) together with an ordinary
// field (title) and loses its commit response. Afterwards the row shows the
// requested assignee and status but the old title, which is what a concurrent
// writer landing the same assignee/status leaves behind. The update must come
// back as a failure that is not a precondition refusal, and it must have run
// exactly once: neither a success (the "assignee right, title untouched"
// symptom) nor a "state changed out from under you" refusal is honest here.
func TestUpdateIssueCheckedMixedCommitLossIsNotMasked(t *testing.T) {
	d := &vrfBoundaryDriver{
		commitErr:      vrfConnLoss,
		checkedUpdate:  true,
		verifyAssignee: "alice",
		verifyStatus:   types.StatusInProgress,
	}
	store := vrfNewStore(d)
	t.Cleanup(func() { _ = store.db.Close() })

	expectedAssignee := ""
	expectedStatus := string(types.StatusOpen)
	err := store.UpdateIssueChecked(context.Background(), "vrf-boundary", map[string]interface{}{
		"assignee": "alice",
		"status":   string(types.StatusInProgress),
		"title":    "ordinary field riding the coordination write",
	}, "alice", storage.UpdateIssueOptions{
		ExpectedAssignee: &expectedAssignee,
		ExpectedStatus:   &expectedStatus,
	})

	if err == nil {
		t.Fatal("UpdateIssueChecked() returned nil after the commit response was lost, although the title cannot be shown to have landed")
	}
	if vrfIsPreconditionRefusal(err) {
		t.Fatalf("UpdateIssueChecked() error = %v, want a failure that is not a precondition refusal (the commit outcome was uncertain, the row was not refused)", err)
	}

	d.mu.Lock()
	defer d.mu.Unlock()
	if d.writeAttempts != 1 {
		t.Fatalf("write attempts = %d, want 1 (the mixed write must not run a second time)", d.writeAttempts)
	}
	if d.updateMutations != 1 {
		t.Fatalf("update row mutations = %d, want 1", d.updateMutations)
	}
}

// TestUpdateIssueCommitResponseLossIsNotReplayed covers a plain, unguarded
// update of an ordinary field whose commit response is lost although the
// commit landed, after which a concurrent writer retitles the same issue (the
// row can change under a request). The same rule applies as for the
// coordination writes: the update runs exactly once and writes one event row,
// and the caller gets either a failure that is not a precondition refusal or
// a success backed by a re-read of the row. A second run would overwrite the
// concurrent writer's title and record the update twice.
func TestUpdateIssueCommitResponseLossIsNotReplayed(t *testing.T) {
	d := &vrfBoundaryDriver{
		commitErr:         vrfConnLoss,
		landedAfterCommit: true,
		landedTitle:       "retitled by a concurrent writer",
	}
	store := vrfNewStore(d)
	t.Cleanup(func() { _ = store.db.Close() })

	err := store.UpdateIssue(context.Background(), "vrf-boundary", map[string]interface{}{
		"title": "renamed while the connection blipped",
	}, "alice")

	vrfRequireUncertainOutcomeHonest(t, "UpdateIssue()", err, d)

	d.mu.Lock()
	defer d.mu.Unlock()
	if d.updateMutations != 1 {
		t.Fatalf("update row mutations = %d, want 1 (the update must not run a second time on an uncertain commit)", d.updateMutations)
	}
	if d.eventInserts != 1 {
		t.Fatalf("event rows written = %d, want 1 (a second run would record the update twice)", d.eventInserts)
	}
}

// TestMergeMetadataCommitResponseLossIsNotReplayed covers a metadata (slot)
// merge, a writer in a different file from the issue updates, whose commit
// response is lost although the commit landed. It must run exactly once with
// one event row, and come back as either a failure that is not a precondition
// refusal or a success backed by a re-read of the row.
func TestMergeMetadataCommitResponseLossIsNotReplayed(t *testing.T) {
	d := &vrfBoundaryDriver{
		commitErr:         vrfConnLoss,
		landedAfterCommit: true,
	}
	store := vrfNewStore(d)
	t.Cleanup(func() { _ = store.db.Close() })

	err := store.MergeMetadata(context.Background(), "vrf-boundary", "owner", json.RawMessage(`"alice"`), "alice")

	vrfRequireUncertainOutcomeHonest(t, "MergeMetadata()", err, d)

	d.mu.Lock()
	defer d.mu.Unlock()
	if d.eventInserts != 1 {
		t.Fatalf("event rows written = %d, want 1 (a second run would record the merge twice)", d.eventInserts)
	}
}

// TestDeterminateSerializationCommitIsStillRetried is a preservation guard:
// a commit refused with a serialization conflict (the server rolled the
// transaction back, so nothing landed) must still be retried to success,
// exactly as it is at the base commit.
func TestDeterminateSerializationCommitIsStillRetried(t *testing.T) {
	d := &vrfBoundaryDriver{
		commitErr: &mysql.MySQLError{Number: 1213, Message: "Deadlock found when trying to get lock; try restarting transaction"},
	}
	store := vrfNewStore(d)
	t.Cleanup(func() { _ = store.db.Close() })

	err := store.ClaimIssue(context.Background(), "vrf-boundary", "alice")
	if err != nil {
		t.Fatalf("ClaimIssue() error = %v, want nil (a determinate serialization conflict must be retried to success)", err)
	}

	d.mu.Lock()
	defer d.mu.Unlock()
	// The retry re-ran the callback and the second versioned commit succeeded.
	if d.doltCommits != 2 {
		t.Fatalf("versioned-commit calls = %d, want 2 (first conflicts, retry succeeds)", d.doltCommits)
	}
	if d.claimMutations != 2 {
		t.Fatalf("claim row mutations = %d, want 2 (a determinate rollback is safe to replay)", d.claimMutations)
	}
}

// TestPreCommitConnectionLossIsStillRetried is the other preservation guard:
// a connection blip that strikes before any commit (here, on the row mutation
// inside the transaction body) leaves nothing committed and must still be
// retried to success, exactly as it is at the base commit.
func TestPreCommitConnectionLossIsStillRetried(t *testing.T) {
	d := &vrfBoundaryDriver{mutationErrOnce: vrfConnLoss}
	store := vrfNewStore(d)
	t.Cleanup(func() { _ = store.db.Close() })

	err := store.ClaimIssue(context.Background(), "vrf-boundary", "alice")
	if err != nil {
		t.Fatalf("ClaimIssue() error = %v, want nil (a pre-commit connection blip must be retried to success)", err)
	}

	d.mu.Lock()
	defer d.mu.Unlock()
	// First attempt failed before commit (one mutation, one rollback, no commit);
	// the retry re-ran the callback and committed.
	if d.writeAttempts != 2 {
		t.Fatalf("write attempts = %d, want 2 (pre-commit blip must be retried)", d.writeAttempts)
	}
	if d.claimMutations != 2 {
		t.Fatalf("claim row mutations = %d, want 2 (first blips pre-commit, retry succeeds)", d.claimMutations)
	}
	if d.doltCommits != 1 {
		t.Fatalf("versioned-commit calls = %d, want 1 (only the successful retry reaches commit)", d.doltCommits)
	}
}

// Compile-time guarantees that the injectable driver satisfies the database/sql
// connector contract the store exercises.
var _ driver.Connector = (*vrfBoundaryDriver)(nil)
var _ driver.ExecerContext = (*vrfBoundaryConn)(nil)
var _ driver.QueryerContext = (*vrfBoundaryConn)(nil)
