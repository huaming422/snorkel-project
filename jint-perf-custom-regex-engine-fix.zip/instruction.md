## Task

In Jint, regexes with the `u` flag are much slower on long strings than the same regex without the flag, even for simple patterns. Bring them close to the speed of the version without `u`, without changing what they match.
