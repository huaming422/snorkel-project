using System;
using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Jint;

namespace Jint.Tests.Runtime;

// Behavioral checks for regexes with the u flag, driven only through the public
// JavaScript API (new Engine(...) + Evaluate/Execute). The class name contains
// "RegExp" so `dotnet test --filter "FullyQualifiedName~RegExp"` collects it
// alongside the repository's own RegExp suite.
public class RegExpUnicodePerfVerify
{
    private const int Inputs = 32;
    private const int InputLength = 120_000;

    // Text every timed search looks for. It is written once into each input, late and at a
    // different position per string, so each search scans most of the string and ends in a
    // real match.
    private const string Planted = "#qz0z#zq0q#qz0q#qZ0z#9b#7x#qzé#";

    // 32 deterministic lowercase strings of 120k chars (one linear-congruential
    // generator per seed) with Planted written in near the end, and the same strings with
    // an astral character every 1000 positions. Operations rotate through them so each
    // call sees a different string.
    private static readonly string[] Lowercase = BuildInputs(astral: false);
    private static readonly string[] WithAstral = BuildInputs(astral: true);

    private static string[] BuildInputs(bool astral)
    {
        var result = new string[Inputs];
        for (var k = 0; k < Inputs; k++)
        {
            var seed = 12345L + k;
            var plantAt = InputLength - 2000 - 53 * k;
            var sb = new StringBuilder(InputLength + 2);
            for (var i = 0; i < InputLength; i++)
            {
                seed = (seed * 1103515245 + 12345) & 0x7fffffff;
                if (i >= plantAt && i < plantAt + Planted.Length)
                {
                    sb.Append(Planted[i - plantAt]);
                }
                else if (astral && i % 1000 == 999)
                {
                    sb.Append("\uD83D\uDE00");
                }
                else
                {
                    sb.Append((char) ('a' + seed % 26));
                }
            }

            result[k] = sb.ToString();
        }

        return result;
    }

    private static Engine CreateEngine(bool astral)
    {
        var engine = new Engine(e => e.RegexTimeoutInterval(TimeSpan.FromSeconds(30)));
        engine.Execute("var data = [];");
        foreach (var s in astral ? WithAstral : Lowercase)
        {
            engine.SetValue("__s", s);
            engine.Execute("data.push(__s);");
        }

        engine.Execute(@"
            function runOp(re, op, n) { for (var i = 0; i < n; i++) { re.lastIndex = 0; op(re, data[i % data.length]); } }
            function results(re, op) { var r = []; for (var i = 0; i < data.length; i++) { re.lastIndex = 0; r.push(String(op(re, data[i]))); } return r.join('|'); }
        ");
        return engine;
    }

    private static double BestPerCall(Engine engine, string runCall, int n, int rounds)
    {
        var best = double.MaxValue;
        for (var round = 0; round < rounds; round++)
        {
            var sw = Stopwatch.StartNew();
            engine.Evaluate(runCall);
            best = Math.Min(best, sw.Elapsed.TotalMilliseconds / n);
        }

        return best;
    }

    // Simple patterns over long strings. Each case must give the same results with and
    // without the u flag, and the u version may cost at most `maxRatio` times the plain
    // one. Plain and u rounds alternate in one engine so machine load affects both.
    [Theory]
    [InlineData("literal search", "qz0z", "", "function(re, s){return s.search(re);}", 500, 6.0, false)]
    [InlineData("literal test", "zq0q", "", "function(re, s){return re.test(s);}", 500, 6.0, false)]
    [InlineData("literal exec", "zq0q", "", "function(re, s){return re.exec(s);}", 500, 6.0, false)]
    [InlineData("literal match", "qz0q", "", "function(re, s){return s.match(re);}", 500, 6.0, false)]
    [InlineData("case-insensitive literal", "QZ0Z", "i", "function(re, s){return s.search(re);}", 300, 6.0, false)]
    [InlineData("single character", "9", "", "function(re, s){return s.search(re);}", 800, 6.0, false)]
    [InlineData("class then literal", "[0-9]x", "", "function(re, s){return s.search(re);}", 800, 6.0, false)]
    [InlineData("anchored literal", "^zzq", "", "function(re, s){return s.search(re);}", 1000, 6.0, false)]
    [InlineData("non-ASCII literal", "qz\u00e9", "", "function(re, s){return s.search(re);}", 500, 6.0, false)]
    [InlineData("literal in text with emoji", "qz0z", "", "function(re, s){return s.search(re);}", 500, 6.0, true)]
    [InlineData("global replace", "qz0z", "g", "function(re, s){return s.replace(re, 'X');}", 200, 6.0, false)]
    public void UnicodeFlag_SimplePatterns_StayCloseToPlainSpeed(string name, string regex, string flags, string op, int n, double maxRatio, bool astral)
    {
        var engine = CreateEngine(astral);
        engine.Execute($"var __p = /{regex}/{flags}; var __u = /{regex}/{flags}u; var __op = {op};");

        var plainResults = engine.Evaluate("results(__p, __op)").AsString();
        var unicodeResults = engine.Evaluate("results(__u, __op)").AsString();
        Assert.True(plainResults == unicodeResults, $"{name}: /{regex}/{flags}u gives different results than without u");

        engine.Evaluate($"runOp(__p, __op, {n})");
        engine.Evaluate($"runOp(__u, __op, {n})");

        double plainMs = double.MaxValue, unicodeMs = double.MaxValue;
        for (var round = 0; round < 7; round++)
        {
            plainMs = Math.Min(plainMs, BestPerCall(engine, $"runOp(__p, __op, {n})", n, 1));
            unicodeMs = Math.Min(unicodeMs, BestPerCall(engine, $"runOp(__u, __op, {n})", n, 1));
        }

        Assert.True(unicodeMs <= plainMs * maxRatio,
            $"{name}: /{regex}/{flags}u took {unicodeMs:F4} ms per call vs {plainMs:F4} ms without u (limit {maxRatio}x)");
    }

    // A /u literal search must also stay within a fixed multiple of a plain string
    // search for the same text, so the comparison above cannot be met by making the
    // version without u slower.
    [Fact]
    public void UnicodeFlag_LiteralSearch_StaysCloseToIndexOf()
    {
        var engine = CreateEngine(astral: false);
        engine.Execute("var __u = /qz0z/u; var __re = function(re, s){return s.search(re);}; var __str = function(re, s){return s.indexOf('qz0z');};");
        Assert.Equal(engine.Evaluate("results(__u, __str)").AsString(), engine.Evaluate("results(__u, __re)").AsString());

        engine.Evaluate("runOp(__u, __re, 500)");
        engine.Evaluate("runOp(__u, __str, 500)");
        double regexMs = double.MaxValue, indexOfMs = double.MaxValue;
        for (var round = 0; round < 7; round++)
        {
            regexMs = Math.Min(regexMs, BestPerCall(engine, "runOp(__u, __re, 500)", 500, 1));
            indexOfMs = Math.Min(indexOfMs, BestPerCall(engine, "runOp(__u, __str, 500)", 500, 1));
        }

        Assert.True(regexMs <= indexOfMs * 60.0,
            $"/qz0z/u search took {regexMs:F4} ms per call vs {indexOfMs:F4} ms for indexOf (limit 60x)");
    }

    // The regex timeout must still cancel a /u match that runs away, whichever method
    // runs it. A nested quantifier with a backreference is exponential for a backtracking
    // matcher, and every character the pattern requires is present in the input. The
    // match runs on a worker so a match that never stops fails the test instead of
    // hanging it.
    [Theory]
    [InlineData("s.match(re)", "")]
    [InlineData("re.test(s)", "")]
    [InlineData("s.search(re)", "")]
    [InlineData("s.replace(re, 'x')", "")]
    [InlineData("s.match(re)", "g")]
    public async Task UnicodeFlag_TimeoutStillCancelsRunawayMatch(string call, string flags)
    {
        var engine = new Engine(e => e.RegexTimeoutInterval(TimeSpan.FromMilliseconds(300)));
        await AssertTimesOut(() => engine.Execute($"var s = 'a'.repeat(40) + 'cb'; var re = /^(a+)+\\1b$/{flags}u; {call};"));
    }

    // The timeout must also stay wired for patterns without the u flag.
    [Fact]
    public async Task PlainPattern_TimeoutStillFires()
    {
        const string pattern = "^(https?:\\/\\/)?([\\da-z\\.-]+)\\.([a-z\\.]{2,6})([\\/\\w\\.-]*)*\\/?$";
        const string value = "https://archiverbx.blob.core.windows.net/static/C:/Users/USR/Documents/Projects/PROJ/static/images/full/1234567890.jpg";
        var engine = new Engine(e => e.RegexTimeoutInterval(TimeSpan.FromSeconds(1)));
        await AssertTimesOut(() => engine.Execute($"'{value}'.match(/{pattern}/)"));
    }

    private static async Task AssertTimesOut(Action match)
    {
        var run = Task.Run(match);
        var first = await Task.WhenAny(run, Task.Delay(TimeSpan.FromSeconds(60)));
        Assert.True(first == run, "match did not stop within 60 s");
        await Assert.ThrowsAsync<RegexMatchTimeoutException>(() => run);
    }

    // Results of ordinary /u matching, including greedy quantifiers that have to give
    // characters back after a later part of the pattern fails, lastIndex handling and
    // the legacy RegExp statics.
    [Fact]
    public void UnicodeMatching_StaysSpecCorrect()
    {
        var engine = new Engine();

        Assert.Equal("abc", engine.Evaluate("'xxabcyy'.match(/abc/u)[0]").AsString());
        Assert.Equal(2, engine.Evaluate("'xxabcyy'.match(/abc/u).index").AsInteger());
        Assert.Equal(3, engine.Evaluate("[...'a1b2c3'.matchAll(/[a-z]\\d/gu)].length").AsInteger());
        Assert.Equal("X", engine.Evaluate("'aaXbb'.match(/a+(?<mid>X)b+/u).groups.mid").AsString());
        Assert.Equal("f0barbaz", engine.Evaluate("'foobarbaz'.replace(/o+/u,'0')").AsString());
        Assert.Equal(6, engine.Evaluate("'hello world'.search(/world/u)").AsInteger());
        Assert.Equal(3, engine.Evaluate("'a,b,c'.split(/,/u).length").AsInteger());
        Assert.Equal("ABC", engine.Evaluate("'ABC'.match(/abc/iu)[0]").AsString());
        Assert.Equal("aaa", engine.Evaluate("'aaa'.match(/a*/u)[0]").AsString());
        Assert.Equal("abracadabra", engine.Evaluate("'abracadabra'.match(/a.*a/u)[0]").AsString());

        Assert.Equal("aab@1", engine.Evaluate("(m => m[0] + '@' + m.index)('xaabxa'.match(/a.*ab/u))").AsString());
        Assert.Equal("aab@1", engine.Evaluate("(m => m[0] + '@' + m.index)('xaabxa'.match(/a.*ab/su))").AsString());
        Assert.Equal("aab9aab9", engine.Evaluate("'aab9aab9ab'.match(/a.*ab9/u)[0]").AsString());
        Assert.Equal("a1b", engine.Evaluate("'a1b2c'.match(/a.*\\db/u)[0]").AsString());
        Assert.Equal("a1b", engine.Evaluate("'a1b2c'.match(/a.*[0-9]b/u)[0]").AsString());
        Assert.Equal("xyzxyz", engine.Evaluate("'xyzxyzyy'.match(/x.*y.*z/u)[0]").AsString());
        Assert.Equal("aXbXcY,aXb,c", engine.Evaluate("String('aXbXcY'.match(/(a.*)X(.*)Y/u))").AsString());
        Assert.Equal("ab", engine.Evaluate("'ab\\ncab'.match(/a.*b/u)[0]").AsString());
        Assert.Equal("abcabc", engine.Evaluate("'zzabcabcd'.match(/[a-c]+/u)[0]").AsString());
        Assert.Equal(2, engine.Evaluate("'x\\nabc'.match(/^abc/mu).index").AsInteger());
        Assert.True(engine.Evaluate("'xabc'.match(/^abc/u) === null").AsBoolean());
        Assert.Equal("ABcD@2", engine.Evaluate("(m => m[0] + '@' + m.index)('xxABcDyy'.match(/abcd/iu))").AsString());
        Assert.Equal("a[b]c[b]", engine.Evaluate("'abcb'.replace(/b/gu, '[$&]')").AsString());
        Assert.Equal("-a-b-c-", engine.Evaluate("'abc'.replace(/x*/gu, '-')").AsString());
        Assert.Equal("true:3,true:6,false:0,true:3",
            engine.Evaluate("(re => [0,1,2,3].map(() => re.test('abcabcab') + ':' + re.lastIndex).join(','))(/abc/gu)").AsString());
        Assert.Equal("true:3", engine.Evaluate("(re => (re.lastIndex = 3, re.test('abc') + ':' + re.lastIndex))(/$/gu)").AsString());
        Assert.Equal("2:3", engine.Evaluate("(re => { re.lastIndex = 3; return 'xxabc'.search(re) + ':' + re.lastIndex; })(/abc/gu)").AsString());
        Assert.Equal("axc:5", engine.Evaluate("(re => { re.lastIndex = 5; return 'abc'.replace(re, 'x') + ':' + re.lastIndex; })(/b/u)").AsString());
        Assert.Equal("axab:2", engine.Evaluate("(re => { re.lastIndex = 1; return 'abab'.replace(re, 'x') + ':' + re.lastIndex; })(/b/yu)").AsString());
        Assert.Equal("bc|a|d|b", engine.Evaluate("/(b)(c)/u.exec('abcd'), [RegExp.lastMatch, RegExp['$`'], RegExp[\"$'\"], RegExp.$1].join('|')").AsString());
        Assert.Equal("bc|c", engine.Evaluate("/b(c)/u.test('abcd'), [RegExp.lastMatch, RegExp.$1].join('|')").AsString());
        Assert.Equal("yz|z", engine.Evaluate("'xyzw'.search(/y(z)/u), [RegExp.lastMatch, RegExp.$1].join('|')").AsString());
        Assert.Equal("pq|q", engine.Evaluate("'opqr'.replace(/p(q)/u, '-'), [RegExp.lastMatch, RegExp.$1].join('|')").AsString());
        Assert.Equal("b|b", engine.Evaluate("'xaybz'.replace(/([ab])/gu, '-'), [RegExp.lastMatch, RegExp.$1].join('|')").AsString());
        Assert.Equal("r", engine.Evaluate("'pqrs'.match(/[pr]/gu), RegExp.lastMatch").AsString());
        Assert.Equal("-1:1", engine.Evaluate("(re => { re.lastIndex = 1; return 'xab'.search(re) + ':' + re.lastIndex; })(/ab/yu)").AsString());
        Assert.Equal("a,a", engine.Evaluate("String('aaXa'.match(/a/gyu))").AsString());
        Assert.Equal("true:2", engine.Evaluate("(re => (re.lastIndex = 2, re.test('abc') + ':' + re.lastIndex))(/a/u)").AsString());
    }

    // Unicode-mode semantics that differ from matching without the u flag: astral
    // characters are single code points, positions never fall inside a surrogate
    // pair, and case-insensitive matching uses Unicode case folding.
    [Fact]
    public void UnicodeSurrogateHandling_StaysSpecCorrect()
    {
        var engine = new Engine();

        Assert.True(engine.Evaluate("/\\u{1F600}/u.test('\\u{1F600}')").AsBoolean());
        Assert.Equal(2, engine.Evaluate("'\\u{1F600}x'.match(/./u)[0].length").AsInteger());
        Assert.Equal(2, engine.Evaluate("'\\u{1F600}'.match(/[^x]/u)[0].length").AsInteger());
        Assert.Equal(2, engine.Evaluate("[...'\\u{1F4A9}'.matchAll(/()/ug)].length").AsInteger());
        Assert.Equal(0, engine.Evaluate("[...'\\u{1F4A9}'.matchAll(/()/ug)][0].index").AsInteger());
        Assert.Equal(2, engine.Evaluate("[...'\\u{1F4A9}'.matchAll(/()/ug)][1].index").AsInteger());
        Assert.Equal(6, engine.Evaluate("'a\\u{1F600}\\u{1F600}b'.match(/a.*b/u)[0].length").AsInteger());
        Assert.True(engine.Evaluate("'a\\u{1F600}b\\u{1F600}c'.match(/a.*\\uDE00/u) === null").AsBoolean());
        Assert.True(engine.Evaluate("'xx\\u{1F600}yy\\u{1F600}'.match(/x.*[\\uDC00-\\uDFFF]/u) === null").AsBoolean());
        Assert.Equal(4, engine.Evaluate("'a\\uDE00b\\uDE00c'.match(/a.*\\uDE00/u)[0].length").AsInteger());
        Assert.Equal(-1, engine.Evaluate("'x\\uD83D\\uDE00'.search(/\\uDE00/u)").AsInteger());
        Assert.True(engine.Evaluate("'x\\u{1F600}'.match(/[\\u0100-\\uFFFD]/u) === null").AsBoolean());
        Assert.Equal(1, engine.Evaluate("'\\u0100\\u{1F600}'.match(/[\\u0100-\\uFFFD]+/u)[0].length").AsInteger());
        Assert.True(engine.Evaluate("/s/iu.test('\\u017F')").AsBoolean());
        Assert.True(engine.Evaluate("/k/iu.test('\\u212A')").AsBoolean());
        Assert.Equal(1, engine.Evaluate("'x\\u017F\\u212Ay'.search(/sk/iu)").AsInteger());
        Assert.Equal(2, engine.Evaluate("'ab\\u212Aitty'.search(/kitty/iu)").AsInteger());
        Assert.True(engine.Evaluate("/\\u212A/iu.test('k')").AsBoolean());
        Assert.True(engine.Evaluate("/\\w/iu.test('\\u017F')").AsBoolean());
    }
}
