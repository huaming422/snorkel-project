#!/usr/bin/env bash
# Checks for regexes with the u flag in Jint.
#
# Jint is a C#/.NET library, so the checks are an xunit class exercised through the
# public Engine API. Every assertion in the injected class plus the repo's own
# RegExp tests must pass (dotnet test returns non-zero if any fail).
set -euo pipefail

REPO=/repo/jint
VERIFY_SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/RegExpUnicodePerfVerify.cs"
DEST="$REPO/Jint.Tests/Runtime/RegExpUnicodePerfVerify.cs"

export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1

cd "$REPO"

# Run the repository's RegExp tests as they are at the base commit, so edits to the
# test project cannot change what is checked.
git checkout "$(cat /var/lib/devcontainer_base_ref)" -- Jint.Tests
git clean -fdq -- Jint.Tests

# Inject the test class into the test project so it compiles against the current
# build of Jint (picked up by the project's default source globbing).
cp "$VERIFY_SRC" "$DEST"
trap 'rm -f "$DEST"' EXIT

# Rebuild the library for every target framework it ships (net462 through net10.0),
# then run the RegExp-filtered tests on net10.0. The filter collects both the
# injected RegExpUnicodePerfVerify class and the repository's existing RegExp tests,
# so a regression anywhere on the RegExp surface also fails.
# NuGetAudit is disabled because it reaches api.nuget.org for vulnerability
# data on every restore; with the network cut that fetch surfaces as NU1900,
# which TreatWarningsAsErrors would promote to a fatal build error. The warm
# package cache baked into the image already satisfies the restore, so no real
# dependency resolution is skipped.
dotnet build -c Release Jint/Jint.csproj -p:NuGetAudit=false
dotnet test Jint.Tests/Jint.Tests.csproj -c Release -f net10.0 \
    -p:NuGetAudit=false --filter "FullyQualifiedName~RegExp"
