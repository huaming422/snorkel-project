#!/usr/bin/env bash
set -euo pipefail

# Prepare the Jint build and test environment. The image already holds the
# NuGet dependency closure and a warm Release build at the base commit, so
# these steps are hot-cache no-ops in the normal case; the online fallback
# only matters if a source change pulled in a new package.

cd /repo/jint

export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1

# NuGetAudit reaches api.nuget.org for vulnerability data on every restore/build;
# with the network cut it surfaces as NU1900, which TreatWarningsAsErrors would
# promote to a fatal error. Disable it so the baked package cache alone satisfies
# the build. The online fallback keeps it off too.
NUGET_AUDIT_OFF="-p:NuGetAudit=false"

# Restore offline first (packages are baked into the image's NuGet cache). If a
# restore is somehow needed and the offline cache misses, fall back to an online
# restore and log it loudly rather than failing silently.
if ! dotnet restore Jint.Tests/Jint.Tests.csproj $NUGET_AUDIT_OFF --source "$(dotnet nuget locals global-packages --list | awk '{print $NF}')" >/tmp/restore-offline.log 2>&1; then
    echo "WARN: offline restore of Jint.Tests failed; falling back to online restore" >&2
    tail -40 /tmp/restore-offline.log >&2 || true
    dotnet restore Jint.Tests/Jint.Tests.csproj
fi

# Recompile the library and test project; on a hot cache this is incremental
# and fast.
dotnet build -c Release -f net10.0 Jint/Jint.csproj $NUGET_AUDIT_OFF
dotnet build -c Release Jint.Tests/Jint.Tests.csproj $NUGET_AUDIT_OFF

# Fail closed if the repository's RegExp test class is missing.
if ! grep -q "class RegExpTests" Jint.Tests/Runtime/RegExpTests.cs; then
    echo "ERROR: Jint.Tests/Runtime/RegExpTests.cs missing expected RegExpTests class" >&2
    exit 1
fi

echo "setup-ok: jint regex test environment ready"
