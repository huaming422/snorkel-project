#!/usr/bin/env bash
# test-setup.sh — sourced before the verifier runs.
#
# The DeerFlow backend dependency closure is baked into /opt/venv at image
# build time (Dockerfile block 10, `uv sync --frozen --group dev`). The fix
# is pure Python stdlib — no new packages, no version bump — so the offline
# agent phase already has everything. This script just makes the repo venv
# active for the verifier and sanity-checks that the modules under test
# import cleanly.
set -euo pipefail

cd /repo/deer-flow/backend

# Activate the backend venv baked at the base commit. The verifier may be
# invoked with a clean env, so set PATH/VIRTUAL_ENV explicitly rather than
# relying on inheritance.
export VIRTUAL_ENV=/opt/venv
export PATH="/opt/venv/bin:${PATH}"

# The repo's test suite imports first-party packages from these roots
# (deerflow.* lives under packages/harness; extension-api is a sibling
# package). conftest.py also wires sys.path, but exporting PYTHONPATH keeps
# a bare `pytest` invocation working regardless of entry point.
export PYTHONPATH=".:packages/harness:packages/extension-api"

# Sanity check: the two modules the task touches, plus the broker server
# entry points the verifier drives, must import cleanly under the repo venv.
python -c "
import sys
from deerflow.community.aio_sandbox import aio_sandbox
from deerflow.integrations.lark_broker import (
    BrokerConfig, run_lark_cli, serve, LARK_CLI_BROKER_SHIM_SCRIPT,
)
assert isinstance(LARK_CLI_BROKER_SHIM_SCRIPT, str) and LARK_CLI_BROKER_SHIM_SCRIPT
print('deer-flow sandbox/broker test env ready')
"
