"""Behavioral verifier for deer-flow-fix-sandbox-stdin-eof.

The sandbox runs a command through two transports with DIFFERENT standard-input
contracts. The persistent terminal transport reads input as a TTY (which the
broker shim already treats as "no input"), while the fresh per-invocation
transport keeps a subprocess input pipe open for writes. A bare command issued
through that second transport never observes end-of-input and blocks forever;
and a producer that stalls mid-stream can let a partial, never-finished payload
reach the broker. A correct change gives the fresh transport's default input an
immediate end-of-input (so a bare command returns) while leaving the persistent
transport's command byte-identical and keeping genuine pipe/heredoc/file input
intact; and it drains the shim's input under an idle budget so a never-finishing
pipe aborts without contacting the broker, while complete or slow-but-advancing
input still round-trips.

These tests assert that CONTRACT through pre-existing, stable public interfaces:

  * ``AioSandbox.execute_command`` / ``execute_command_in_scope`` with the two
    transport callables replaced by local subprocesses that faithfully model
    each transport's input channel (a pseudo-terminal for the persistent one, an
    open-but-unclosed pipe for the fresh one) — exactly how the repo's own
    ``tests/test_aio_sandbox.py`` exercises these paths.
  * ``LARK_CLI_BROKER_SHIM_SCRIPT`` written to a temp file and run as a
    subprocess against a loopback broker stood up from ``serve(BrokerConfig(...))``
    — exactly how the repo's ``tests/test_lark_broker.py`` exercises the shim.

They assert OBSERVABLE OUTCOMES (a bare command sees end-of-input and returns;
explicit input round-trips byte-for-byte; the persistent command is delivered
unchanged; parsing/status are undisturbed; a never-finishing pipe aborts non-zero
without a broker call), never an internal mechanism: not the literal text a fix
prepends, not any private helper inside the shim, not a specific abort exit code,
and not the names of any idle-window environment overrides. Any change that
produces the correct behavior passes regardless of how it is built.

Fixtures are self-contained because the repo's own test ``conftest.py`` is not in
scope when this file is collected from the verifier directory; they mirror the
repo's ``sandbox`` / ``broker_server`` fixtures.
"""

from __future__ import annotations

import base64
import json
import logging
import os
import shlex
import subprocess
import sys
import textwrap
import threading
import time
import urllib.request
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

# This file is collected from the verifier directory, so the backend suite's own
# ``tests/conftest.py`` is not in scope. That conftest breaks a known circular
# import in the package __init__ chain (``deerflow.subagents.__init__`` ->
# ``.executor`` -> ... -> back to ``deerflow.subagents.executor``) by registering
# a stand-in for that leaf module before anything triggers the import. The two
# modules under test can pull that chain in transitively, so reproduce the same
# guard here. It is a no-op if the real import graph is already acyclic.
if "deerflow.subagents.executor" not in sys.modules:
    _executor_stub = MagicMock()
    _executor_stub.SubagentExecutor = MagicMock
    _executor_stub.SubagentResult = MagicMock
    _executor_stub.SubagentStatus = MagicMock
    _executor_stub.MAX_CONCURRENT_SUBAGENTS = 3
    _executor_stub.get_background_task_result = MagicMock()
    sys.modules["deerflow.subagents.executor"] = _executor_stub

# A never-finishing input channel must terminate the operation under test well
# within this bound. A correct change returns in well under a second (idle
# budgets are short); a regression blocks forever. The bound only has to be long
# enough that a correct change never trips it and short enough that the suite
# stays far under the verifier wall-clock budget when a regression hangs.
HANG_BUDGET_SECONDS = 15

pytestmark = pytest.mark.skipif(
    os.name == "nt",
    reason="exercises the POSIX sandbox shell transports and '#!' broker scripts",
)


# ───────────────────────── AioSandbox transport modeling ────────────────────


@pytest.fixture()
def sandbox():
    """An ``AioSandbox`` whose SDK client is mocked (repo's own fixture)."""
    with patch("deerflow.community.aio_sandbox.aio_sandbox.AioSandboxClient"):
        from deerflow.community.aio_sandbox.aio_sandbox import AioSandbox

        return AioSandbox(id="test-sandbox", base_url="http://localhost:8080")


_UNSET = object()

# Conventional names an exec-interface fix might use to hand the fresh transport
# a standard-input (Alt 1: EOF via the SDK's own stdin parameter rather than a
# command-level redirect). Honoring any of them only ever lets the model accept
# MORE valid fixes; an unchanged repo passes none of them, so the bug still reproduces.
_STDIN_KWARG_NAMES = ("stdin", "stdin_b64", "stdin_data", "input", "stdin_bytes")


def _extract_stdin_signal(kwargs):
    for name in _STDIN_KWARG_NAMES:
        if name in kwargs:
            value = kwargs[name]
            if name == "stdin_b64" and isinstance(value, str):
                try:
                    return base64.b64decode(value)
                except Exception:  # noqa: BLE001 - fall through to raw handling
                    return value
            return value
    return _UNSET


def _resolve_fresh_stdin(stdin_signal):
    """Map a fix-supplied stdin signal to how a faithful transport wires fd0.

    The fresh transport delivers whatever standard-input the exec call asks for.
    A fix can give a bare command end-of-input two ways and both must be honored
    identically here (the observable outcome is the same EOF):

      * by redirecting inside the command it hands over (``exec < /dev/null`` and
        kin) — handled by the shell itself, so the exec call passes no stdin
        signal and the default open pipe is simply never read; or
      * by passing a no-input standard-input through the exec interface itself
        (a closed / ``/dev/null`` / empty stdin via the SDK's own parameter or a
        session option) — modeled here by wiring fd0 to ``/dev/null``.

    When no signal is supplied (an unchanged repo, or a producer-less bare command), fd0 is
    the open session pipe that is never written and never closed, so a reader
    blocks on an end-of-input that never comes — exactly the bug.
    """
    if stdin_signal is _UNSET or stdin_signal is None or stdin_signal is subprocess.PIPE:
        return subprocess.PIPE, None
    if stdin_signal in (subprocess.DEVNULL, "/dev/null"):
        return subprocess.DEVNULL, None
    if isinstance(stdin_signal, (bytes, bytearray)):
        return subprocess.PIPE, bytes(stdin_signal)
    if isinstance(stdin_signal, str):
        return subprocess.PIPE, stdin_signal.encode()
    if isinstance(stdin_signal, int):  # an already-opened fd the fix supplied
        return stdin_signal, None
    return subprocess.PIPE, None


def _execute_with_open_session_stdin(command, env=None, *, shell="/bin/sh", terminal=False, **kwargs):
    """Run ``command`` the way a sandbox transport does, modeling its input channel.

    ``terminal=True`` models the persistent transport: the command's input is a
    pseudo-terminal that stays open for the whole run (there is no end-of-input
    to read). Otherwise it models the fresh transport, whose fd0 follows whatever
    standard-input the exec call requested (see ``_resolve_fresh_stdin``): an
    open, never-closed pipe by default, so a command that reads its input sees no
    end-of-input unless the command or the exec call redirects that channel.
    ``communicate()`` is deliberately NOT used to feed/close the default pipe, as
    that would supply the end-of-input the bug is about.
    """
    terminal_fds = None
    priming = None
    if terminal:
        import pty

        terminal_fds = pty.openpty()
        stdin = terminal_fds[1]
    else:
        stdin, priming = _resolve_fresh_stdin(_extract_stdin_signal(kwargs))
    proc = subprocess.Popen(
        [shell, "-c", command],
        stdin=stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env={**os.environ, **(env or {})},
    )
    if priming is not None:
        # The fix supplied a bounded explicit stdin through the exec interface:
        # deliver exactly those bytes and close, so the command sees that input
        # followed by end-of-input.
        proc.stdin.write(priming)
        proc.stdin.close()
    try:
        proc.wait(timeout=HANG_BUDGET_SECONDS)
        stdout = proc.stdout.read().decode()
        stderr = proc.stderr.read().decode()
        return SimpleNamespace(
            data=SimpleNamespace(output=stdout, stdout=stdout, stderr=stderr, exit_code=proc.returncode)
        )
    finally:
        if proc.poll() is None:
            proc.kill()
        proc.communicate()
        if terminal_fds:
            for fd in terminal_fds:
                os.close(fd)


def _drive(sandbox, command, execution_path, *, env_extra=None):
    """Drive ``command`` through one of the three public execution entry points."""
    from deerflow.integrations.lark_broker import LARK_BROKER_URL_ENV

    if execution_path == "env":
        env = {LARK_BROKER_URL_ENV: "http://127.0.0.1:8788"}
        if env_extra:
            env.update(env_extra)
        return sandbox.execute_command(command, env=env)
    if execution_path == "scope":
        return sandbox.execute_command_in_scope(command, scope_id="subagent")
    return sandbox.execute_command(command)


@pytest.mark.parametrize("input_kind", ["session", "pipeline", "heredoc", "file"])
@pytest.mark.parametrize("execution_path", ["shell", "scope", "env"])
def test_bare_command_sees_eof_and_explicit_input_round_trips(sandbox, tmp_path, input_kind, execution_path):
    """Core contract across both transports (criteria: default-stdin EOF,
    persistent command unchanged, explicit input preserved).

    A bare command on the fresh (env-bearing) transport must observe end-of-input
    and return the empty read; the persistent transport reports a terminal; and
    pipe / heredoc / file input round-trips byte-for-byte on every path.

    Pre-fix, the bare command on the env path hangs on a read that never sees
    end-of-input (the open session pipe is never closed) — the hang budget trips
    and this case fails.
    """
    reader = (
        f"{shlex.quote(sys.executable)} -c "
        "'import sys; print(\"tty\" if sys.stdin.isatty() else repr(sys.stdin.read()))'"
    )
    # No explicit input: fresh transport should deliver EOF (empty read),
    # persistent transport reads a terminal.
    expected = "''\n" if execution_path == "env" else "tty\n"
    if input_kind == "pipeline":
        command = f"printf 'pipeline input' | {reader}"
        expected = "'pipeline input'\n"
    elif input_kind == "heredoc":
        command = f"{reader} <<'INPUT'\nheredoc input\nINPUT"
        expected = "'heredoc input\\n'\n"
    elif input_kind == "file":
        input_file = tmp_path / "input with spaces.txt"
        input_file.write_text("file input", encoding="utf-8")
        command = f"{reader} < {shlex.quote(str(input_file))}"
        expected = "'file input'\n"
    else:
        command = reader

    sandbox._client.bash.exec = _execute_with_open_session_stdin

    def execute_on_terminal(command, **kwargs):
        return _execute_with_open_session_stdin(command, terminal=True, **kwargs)

    sandbox._client.shell.exec_command = execute_on_terminal

    result = _drive(sandbox, command, execution_path)
    assert result == expected


@pytest.mark.parametrize("execution_path", ["shell", "scope", "env"])
@pytest.mark.parametrize(
    "command",
    [
        pytest.param("printf '[%s]' one two" + "\\", id="trailing_backslash_arg"),
        pytest.param("printf '%s-%s' a b" + "\\", id="trailing_backslash_after_args"),
    ],
)
def test_trailing_backslash_command_runs_like_the_unmodified_command(sandbox, execution_path, command):
    """A command ending in an unquoted trailing backslash must produce the SAME
    observable result as the unmodified command (criterion: bash parsing
    preserved).

    This is the invariant the ``eval`` / brace-group wrapper class violates: a
    fix that wraps the command and *appends* a delimiter after it (``{ CMD ; } <
    /dev/null``, ``CMD < /dev/null``) lets the trailing backslash line-continue
    onto that appended text, so the final argument changes and the output
    differs from the baseline. Every fix that instead gives end-of-input ahead of
    the command, or through the exec interface, or protects the command from an
    appended redirect leaves the final backslash at true end-of-input and
    reproduces the baseline exactly — so this asserts the behavior, not any
    particular prefix text.
    """
    # Baseline: the unmodified command run with end-of-input already available.
    # The probe reads no standard input, so the only thing that can change its
    # output is a top-level parse perturbation (the splice).
    baseline = subprocess.run(
        ["/bin/bash", "-c", command],
        stdin=subprocess.DEVNULL,
        capture_output=True,
        timeout=5,
    ).stdout.decode()

    def execute_in_bash(command, **kwargs):
        return _execute_with_open_session_stdin(
            command, shell="/bin/bash", terminal=execution_path != "env", **kwargs
        )

    sandbox._client.bash.exec = execute_in_bash
    sandbox._client.shell.exec_command = execute_in_bash

    result = _drive(sandbox, command, execution_path, env_extra={"REQUEST_VALUE": "present"})
    assert result == baseline


@pytest.mark.parametrize("execution_path", ["shell", "scope", "env"])
@pytest.mark.parametrize(
    ("command", "expected", "exit_code"),
    [
        pytest.param(
            "shopt -s extglob\ncase test.py in *.@(py|sh)) printf extglob-ok;; esac",
            "extglob-ok",
            0,
            id="enable_extglob",
        ),
        pytest.param(
            "shopt -s expand_aliases\nalias project_status='printf alias-ok'\nproject_status",
            "alias-ok",
            0,
            id="define_alias",
        ),
        pytest.param("false | true\nprintf '%s' \"${PIPESTATUS[*]}\"", "1 0", 0, id="pipeline_status"),
        pytest.param("trap 'printf error-trap' ERR\nfalse", "error-trap", 1, id="error_trap"),
    ],
)
def test_bash_parsing_and_status_preserved(sandbox, execution_path, command, expected, exit_code):
    """Top-level parsing/status must survive the fix (criterion: bash parsing
    preserved).

    These cases confirm the fix leaves alias/extglob timing, ``PIPESTATUS`` and
    the ``ERR`` trap intact on the fresh path — a guard that the chosen fix adds
    no observable parsing or status change. (The trailing-backslash *splice* that
    the ``eval``/brace-group wrapper class gets wrong is caught separately by
    ``test_command_delivered_without_consumable_trailing_delimiter``; here we
    pin that the ordinary multi-line constructs still evaluate exactly as the
    unmodified command would.)
    """

    def execute_in_bash(command, **kwargs):
        return _execute_with_open_session_stdin(
            command, shell="/bin/bash", terminal=execution_path != "env", **kwargs
        )

    sandbox._client.bash.exec = execute_in_bash
    sandbox._client.shell.exec_command = execute_in_bash

    result = _drive(sandbox, command, execution_path, env_extra={"REQUEST_VALUE": "present"})
    assert result == expected + (f"\nExit Code: {exit_code}" if exit_code else "")


def test_persistent_shell_preserves_session_state(sandbox, tmp_path):
    """The persistent transport drives a reusable terminal: its commands must be
    delivered unchanged so working directory, exported variables, exit status,
    ``PIPESTATUS``, an ``ERR`` trap, and an open terminal input all carry across
    calls (criterion: persistent command unchanged).
    """
    commands: list[str] = []

    def record_command(command, **_kwargs):
        commands.append(command)
        return SimpleNamespace(
            data=SimpleNamespace(output="ok", stdout="ok", stderr="", exit_code=0)
        )

    sandbox._client.shell.exec_command = record_command

    sandbox.execute_command(f"cd {shlex.quote(str(tmp_path))}; export SESSION_VALUE=preserved")
    sandbox.execute_command('printf "%s\\n" "$PWD" "$SESSION_VALUE"; exit 7')
    completed = subprocess.run(
        ["/bin/sh", "-c", "\n".join(commands)], input=b"", capture_output=True, timeout=5
    )
    assert completed.returncode == 7
    assert completed.stdout.decode().splitlines() == [str(tmp_path), "preserved"]

    commands.clear()
    sandbox.execute_command("false | true")
    sandbox.execute_command('printf "%s" "${PIPESTATUS[*]}"')
    completed = subprocess.run(
        ["/bin/bash", "-c", "\n".join(commands)], input=b"", capture_output=True, timeout=5
    )
    assert completed.returncode == 0
    assert completed.stdout == b"1 0"

    commands.clear()
    sandbox.execute_command("trap 'printf error-trap' ERR")
    sandbox.execute_command("false")
    completed = subprocess.run(
        ["/bin/bash", "-c", "\n".join(commands)], input=b"", capture_output=True, timeout=5
    )
    assert completed.returncode == 1
    assert completed.stdout == b"error-trap"

    commands.clear()
    sandbox.execute_command("true")
    completed = subprocess.run(
        ["/bin/sh", "-c", commands[0] + '\nread session_input; printf "%s" "$session_input"'],
        input=b"session still open\n",
        capture_output=True,
        timeout=5,
    )
    assert completed.returncode == 0
    assert completed.stdout == b"session still open"


# ─────────────────────────── broker shim modeling ───────────────────────────


def _fake_lark_cli(tmp_path: Path) -> str:
    """A stub broker CLI that echoes argv/stdin (repo's own helper)."""
    script = tmp_path / "fake-lark-cli"
    script.write_text(
        textwrap.dedent(
            """\
            #!/usr/bin/env python3
            import json, os, sys
            print(json.dumps({
                "argv": sys.argv[1:],
                "stdin": sys.stdin.read(),
            }))
            sys.exit(0)
            """
        ),
        encoding="utf-8",
    )
    script.chmod(0o755)
    return str(script)


@pytest.fixture()
def broker_server(tmp_path: Path):
    """A loopback broker on an ephemeral port (repo's own fixture shape)."""
    from deerflow.integrations.lark_broker import BrokerConfig, serve

    config = BrokerConfig(
        lark_cli_path=_fake_lark_cli(tmp_path),
        config_dir="/broker/only/config",
        data_dir="/broker/only/data",
        port=0,
    )
    server = serve(config)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    host, port = server.server_address[0], server.server_address[1]
    try:
        yield host, port
    finally:
        server.shutdown()
        thread.join(timeout=5)


def _write_shim(tmp_path: Path, name: str = "lark-cli") -> Path:
    from deerflow.integrations.lark_broker import LARK_CLI_BROKER_SHIM_SCRIPT

    shim = tmp_path / name
    shim.write_text(LARK_CLI_BROKER_SHIM_SCRIPT, encoding="utf-8")
    shim.chmod(0o755)
    return shim


def _shim_env(host: str, port: int, **extra) -> dict:
    from deerflow.integrations.lark_broker import LARK_BROKER_URL_ENV

    env = {**os.environ, LARK_BROKER_URL_ENV: f"http://{host}:{port}"}
    env.update(extra)
    return env


def test_shim_terminal_stdin_needs_no_input(broker_server, tmp_path):
    """The persistent transport's input is a terminal; the shim must treat that
    as "no input" and forward an empty payload (criterion: persistent path
    already correct). This holds before and after the fix.
    """
    import pty

    host, port = broker_server
    shim = _write_shim(tmp_path, "lark-cli-shim.py")
    master, slave = pty.openpty()
    try:
        completed = subprocess.run(
            [sys.executable, str(shim), "auth", "status"],
            stdin=slave,
            capture_output=True,
            env=_shim_env(host, port),
            timeout=HANG_BUDGET_SECONDS,
        )
    finally:
        os.close(slave)
        os.close(master)
    assert completed.returncode == 0, completed.stderr
    assert json.loads(completed.stdout)["stdin"] == ""


def _run_shim_with_open_pipe(shim, env, *, prime: bytes | None = None):
    """Launch the shim with an input pipe held open and never closed.

    Models a bare command (no producer) or a producer that stalls mid-stream
    (``prime`` written, then silence). ``communicate()`` is avoided so the pipe
    is never closed — the end-of-input the bug hinges on never arrives.
    Returns (returncode, stdout, stderr) or raises on a genuine hang.
    """
    proc = subprocess.Popen(
        [sys.executable, str(shim), "auth", "status"],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    if prime is not None:
        proc.stdin.write(prime)
        proc.stdin.flush()
    try:
        proc.wait(timeout=HANG_BUDGET_SECONDS)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait()
        proc.stdin.close()
        pytest.fail("shim blocked waiting for end-of-input on a session-held stdin pipe")
    stdout = proc.stdout.read()
    stderr = proc.stderr.read()
    proc.stdin.close()
    return proc.returncode, stdout, stderr


def test_shim_open_pipe_without_producer_aborts_without_executing(broker_server, tmp_path, monkeypatch):
    """A bare command on the fresh transport: the input pipe is held open and
    nothing is ever written. The shim must terminate with a non-success outcome
    WITHOUT contacting the broker — never block, never run on empty guessed input
    (criterion: idle stdin aborts without executing).

    Pre-fix the shim reads until end-of-input, which never comes, so it hangs and
    the hang budget trips.
    """
    from deerflow.integrations import lark_broker

    executions = []
    monkeypatch.setattr(
        lark_broker,
        "run_lark_cli",
        lambda *args: executions.append(args) or lark_broker.ExecResult(0, b"", b"", False),
    )
    host, port = broker_server
    shim = _write_shim(tmp_path)
    # Best-effort speedup if the fix honors an idle-window override; if it names
    # the knob differently the default short window still fires well within budget.
    env = _shim_env(host, port, DEERFLOW_LARK_BROKER_STDIN_GRACE_SECONDS="0.2")

    returncode, stdout, stderr = _run_shim_with_open_pipe(shim, env)
    assert returncode != 0, stderr
    assert stdout == b""
    assert b"stdin" in stderr.lower()
    assert executions == []


def test_shim_stalled_producer_aborts_without_executing_partial_input(broker_server, tmp_path, monkeypatch):
    """A producer that writes one chunk then stalls (never writes again, never
    closes) must NOT have its partial payload executed. The shim must abort
    non-zero without contacting the broker (criterion: idle stdin aborts without
    executing). Pre-fix the shim blocks waiting for end-of-input after the chunk.
    """
    from deerflow.integrations import lark_broker

    executions = []
    monkeypatch.setattr(
        lark_broker,
        "run_lark_cli",
        lambda *args: executions.append(args) or lark_broker.ExecResult(0, b"", b"", False),
    )
    host, port = broker_server
    shim = _write_shim(tmp_path)
    env = _shim_env(host, port, DEERFLOW_LARK_BROKER_STDIN_TAIL_SECONDS="0.3")

    returncode, stdout, stderr = _run_shim_with_open_pipe(shim, env, prime=b"first-chunk")
    assert returncode != 0, stderr
    assert stdout == b""
    assert b"stdin" in stderr.lower()
    assert executions == []


def test_shim_piped_stdin_is_forwarded(broker_server, tmp_path):
    """Explicit piped input must still reach the broker intact (criterion:
    complete input forwarded). Works before and after the fix."""
    host, port = broker_server
    shim = _write_shim(tmp_path)
    completed = subprocess.run(
        [sys.executable, str(shim), "docs", "+fetch"],
        input=b"streamed-input",
        capture_output=True,
        env=_shim_env(host, port),
        timeout=HANG_BUDGET_SECONDS,
    )
    assert completed.returncode == 0, completed.stderr
    assert json.loads(completed.stdout.decode())["stdin"] == "streamed-input"


def test_shim_drip_fed_stdin_round_trips(broker_server, tmp_path):
    """A slow producer writing in chunks that each advance before the idle window
    expires must keep all of its input (criterion: complete input forwarded).
    """
    host, port = broker_server
    shim = _write_shim(tmp_path)
    proc = subprocess.Popen(
        [sys.executable, str(shim), "docs", "+fetch"],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=_shim_env(host, port),
    )
    try:
        for piece in (b"streamed", b"-", b"input"):
            proc.stdin.write(piece)
            proc.stdin.flush()
            time.sleep(0.3)
        proc.stdin.close()
        proc.wait(timeout=HANG_BUDGET_SECONDS)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait()
        pytest.fail("shim stalled on drip-fed stdin that was advancing")
    stdout = proc.stdout.read()
    assert proc.returncode == 0, proc.stderr.read()
    assert json.loads(stdout.decode())["stdin"] == "streamed-input"


def test_shim_large_file_input_is_preserved(broker_server, tmp_path):
    """A large explicit file redirect must round-trip in full (criterion:
    complete input forwarded)."""
    host, port = broker_server
    shim = _write_shim(tmp_path)
    contents = "document body\n" * 16000
    input_file = tmp_path / "input.txt"
    input_file.write_text(contents, encoding="utf-8")
    with input_file.open("rb") as stdin:
        completed = subprocess.run(
            [sys.executable, str(shim), "docs", "+fetch"],
            stdin=stdin,
            capture_output=True,
            env=_shim_env(host, port),
            timeout=HANG_BUDGET_SECONDS,
        )
    assert completed.returncode == 0, completed.stderr
    assert json.loads(completed.stdout)["stdin"] == contents


# ─────────────────────── broker exec-log redaction ──────────────────────────


def _post_exec(host: str, port: int, args: list[str], stdin: bytes = b""):
    """POST one exec request to the broker and return its parsed JSON body."""
    payload = json.dumps(
        {"args": args, "stdin_b64": base64.b64encode(stdin).decode("ascii")}
    ).encode("utf-8")
    request = urllib.request.Request(
        f"http://{host}:{port}/v1/exec",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=HANG_BUDGET_SECONDS) as resp:
        return json.loads(resp.read().decode("utf-8"))


def test_broker_exec_logging_never_leaks_argument_or_stdin_values(broker_server, caplog):
    """Whatever the broker records around running a credentialed CLI call must
    never contain the call's argument values or standard-input bytes (criterion:
    broker exec log redaction — secondary hardening).

    This asserts the redaction INVARIANT, not that any particular line is
    emitted: the broker owns real credentials, so a secret-looking token passed
    as an argument or on stdin must not survive into any log record the broker
    produces for that exec. A change that logs only call metadata (argument
    count, exit status, elapsed) satisfies it; one that never logs around the
    exec at all satisfies it vacuously; only a change that writes the raw
    argument or stdin values into a record fails. The secrets are unique, random-
    looking sentinels so an incidental substring cannot mask a real leak.
    """
    secret_arg = "ghs-SENTINEL-7Qw9fL2xArg"
    secret_stdin = b"stdin-SENTINEL-8Zv3kP6mBody"

    host, port = broker_server
    with caplog.at_level(logging.NOTSET, logger="deerflow.integrations.lark_broker"):
        body = _post_exec(
            host,
            port,
            ["im", "send", "--token", secret_arg, secret_arg],
            stdin=secret_stdin,
        )

    # The call itself succeeded end-to-end (the fake CLI echoes argv/stdin and
    # exits 0), so any logging path around the exec has run.
    assert body["exit_code"] == 0

    broker_records = "\n".join(
        record.getMessage()
        for record in caplog.records
        if record.name == "deerflow.integrations.lark_broker"
    )
    assert secret_arg not in broker_records
    assert secret_stdin.decode("ascii") not in broker_records
