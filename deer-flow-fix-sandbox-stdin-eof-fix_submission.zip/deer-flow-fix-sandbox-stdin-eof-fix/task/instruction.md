## Task

something's wrong with broker mode in the sandbox. when the agent runs a
plain `lark-cli ...` command, no pipe into it, no input redirect, no heredoc,
just the bare command, it hangs. not slow, actually stuck: the command runs
but never comes back, and it sits there until some outer timeout kills it, if
there even is one. commands that *do* feed it input the normal ways (a pipe, a
heredoc, a file redirect) are fine, so it's specific to the "nothing was ever
going to be piped in" case.

there's a nastier version of it too. when something upstream is slowly
producing the input and stalls partway, starts sending, then never finishes,
the command can end up acting on that half-finished chunk instead of refusing
it. a partially-formed request getting run is worse than a hang.

this used to just work. dig in, find out why a bare command wedges like this,
and make it a defined outcome instead of an open-ended hang, without breaking
the commands that really do supply input.
