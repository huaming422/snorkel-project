## Task

On macOS and Linux, quitting the desktop app to install a pending update can
occasionally cancel the installation with a degraded backend shutdown report.
The backend's processes have actually stopped when this happens. The reports
are intermittent, seem sensitive to load and timing, and describe a regression
from previously reliable quits. Please investigate the false shutdown result
and restore accurate confirmation of a clean teardown. Confirmation must still
finish within a bounded time so the quit flow cannot hang.
