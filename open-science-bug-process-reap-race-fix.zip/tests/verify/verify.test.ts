// @ts-nocheck
//
// Drives the pre-existing stable export `terminateProcessTree` from
// ./process-tree — the highest-level, terminal interface where the teardown
// result is observable. The private POSIX helper is never imported, so any
// valid restructuring of it (concurrent vs serial await, re-enumerated
// descendants, inline polling loop, a differently-named bounded helper) is
// admitted as long as the observable `{ reaped }` result is correct.
//
// Seam mirrors the repo's own src/main/process-tree.test.ts: a hoisted
// spawn double (returns a fake `ps` / taskkill), a spied `process.kill`, and
// vitest fake timers to drive the asynchronous force-kill exit grace.

import { EventEmitter } from 'node:events'
import { afterEach, describe, expect, it, vi } from 'vitest'

const { spawnMock } = vi.hoisted(() => ({ spawnMock: vi.fn() }))
vi.mock('node:child_process', () => ({ spawn: spawnMock }))

const { registerOwnedPosixProcessGroup, terminateProcessTree } = await import('./process-tree')

// Minimal ChildProcess stand-in: an EventEmitter (so the exit wait resolves)
// exposing the pid/kill/killed/exitCode surface the code under test touches.
class FakeChild extends EventEmitter {
  kill = vi.fn(() => {
    this.killed = true
    return true
  })
  killed = false
  exitCode: number | null = null
  signalCode: string | null = null
  constructor(public pid: number | undefined) {
    super()
  }
}

// A `ps` stand-in: an EventEmitter with its own stdout EventEmitter, matching
// spawn('ps', ...).
class FakePs extends EventEmitter {
  stdout = new EventEmitter()
  kill = vi.fn(() => true)
}

const esrch = (): NodeJS.ErrnoException => Object.assign(new Error('ESRCH'), { code: 'ESRCH' })

const originalPlatform = process.platform
const setPlatform = (value: string): void => {
  Object.defineProperty(process, 'platform', { value, configurable: true })
}

afterEach(() => {
  setPlatform(originalPlatform)
  vi.restoreAllMocks()
  vi.clearAllMocks()
  vi.useRealTimers()
})

describe('terminateProcessTree — POSIX descendant-exit confirmation (PR #2274)', () => {
  // C1 (fail_to_pass, basic_functionality) — the headline defect, on both
  // POSIX scheduling models. The direct child exits first; a surviving
  // descendant is reaped a short time AFTER the force-kill signal is
  // delivered. Once the force-kill grace absorbs that asynchronous exit, the
  // whole tree must be reported confirmed gone.
  it.each(['linux', 'darwin'])(
    'confirms a tree reaped shortly after the force-kill signal when the child exits first on %s',
    async (platform) => {
      vi.useFakeTimers()
      setPlatform(platform)
      const ps = new FakePs()
      spawnMock.mockReturnValueOnce(ps)

      // The lone descendant (1001) stays alive until ~100ms after it receives
      // the force-kill signal — i.e. the kernel reaps it asynchronously.
      let descendantAlive = true
      const killSpy = vi.spyOn(process, 'kill').mockImplementation((pid, signal) => {
        expect(pid).toBe(1001)
        if (signal === 0 && !descendantAlive) throw esrch()
        if (signal === 'SIGKILL') setTimeout(() => (descendantAlive = false), 100)
        return true
      })
      const child = new FakeChild(1000)
      const settled = vi.fn()
      const pending = terminateProcessTree(child as never).then(settled)

      ps.stdout.emit('data', Buffer.from('1000 1\n1001 1000\n'))
      ps.emit('close', 0)
      await Promise.resolve()
      await Promise.resolve()
      child.emit('exit', 0, null) // parent exits first
      await vi.advanceTimersByTimeAsync(100) // descendant exits asynchronously
      await pending

      expect(killSpy).toHaveBeenCalledWith(1001, 'SIGKILL')
      expect(settled).toHaveBeenCalledExactlyOnceWith({ reaped: true })
    }
  )

  // C2 (pass_to_pass guard) — fail-closed is preserved. A descendant that
  // genuinely never exits within the bounded force-kill grace must still
  // yield a non-clean result. Guards against an over-correction that weakens
  // the confirmation into always-true (e.g. dropping the descendant check).
  it('still reports a non-clean teardown when a descendant never exits within the grace', async () => {
    vi.useFakeTimers()
    setPlatform('linux')
    const ps = new FakePs()
    spawnMock.mockReturnValueOnce(ps)

    // The descendant never dies: signal 0 always succeeds.
    const killSpy = vi.spyOn(process, 'kill').mockImplementation(() => true)
    const child = new FakeChild(1000)
    const settled = vi.fn()
    const pending = terminateProcessTree(child as never).then(settled)

    ps.stdout.emit('data', Buffer.from('1000 1\n1001 1000\n'))
    ps.emit('close', 0)
    await Promise.resolve()
    await Promise.resolve()
    child.emit('exit', 0, null) // parent exits first
    await vi.advanceTimersByTimeAsync(1_000) // past the bounded force-kill grace
    await pending

    expect(killSpy).toHaveBeenCalledWith(1001, 'SIGKILL')
    expect(settled).toHaveBeenCalledExactlyOnceWith({ reaped: false })
  })

  // C3 (pass_to_pass, basic_functionality) — the clean fast path is
  // unchanged: when the child exits and every descendant is already gone
  // after the graceful signal, the tree is reported reaped with no force-kill
  // escalation to a live descendant.
  it('reports reaped without escalation when the child and descendants exit on the graceful signal', async () => {
    setPlatform('linux')
    const ps = new FakePs()
    spawnMock.mockReturnValueOnce(ps)

    // Descendants accept the graceful signal; the liveness probe (signal 0)
    // then reports them gone.
    const killSpy = vi.spyOn(process, 'kill').mockImplementation((_pid, sig) => {
      if (sig === 0) throw esrch()
      return true
    })
    const child = new FakeChild(1000)

    const pending = terminateProcessTree(child as never, 'SIGTERM')
    ps.stdout.emit('data', Buffer.from('1000 1\n1001 1000\n1002 1001\n'))
    ps.emit('close', 0)
    await Promise.resolve()
    await Promise.resolve()
    child.emit('exit', 0, null)

    await expect(pending).resolves.toEqual({ reaped: true })
    expect(killSpy).not.toHaveBeenCalledWith(expect.any(Number), 'SIGKILL')
  })

  // C4 (pass_to_pass regression) — the Windows taskkill path keeps its
  // reaped semantics. A clean taskkill exit reaps the tree; a fix mistakenly
  // placed in the shared/Windows path would break this.
  it('keeps the Windows taskkill path reporting reaped on a clean taskkill exit', async () => {
    setPlatform('win32')
    const killer = new EventEmitter()
    spawnMock.mockReturnValueOnce(killer)
    const child = new FakeChild(4321)

    const pending = terminateProcessTree(child as never)
    expect(spawnMock).toHaveBeenCalledWith(
      'taskkill',
      ['/pid', '4321', '/T', '/F'],
      expect.objectContaining({ windowsHide: true })
    )
    killer.emit('exit', 0, null)

    await expect(pending).resolves.toEqual({ reaped: true })
    expect(child.kill).not.toHaveBeenCalled()
  })

  // C5 (pass_to_pass regression) — the detached / owned process-group path
  // keeps its reaped semantics. This path already awaits descendant exit
  // correctly and is NOT where the defect lives; a fix wrongly placed here
  // would regress it.
  it('keeps the owned/detached process-group path reporting reaped when its members exit', async () => {
    vi.useFakeTimers()
    setPlatform('linux')
    const ps = new FakePs()
    spawnMock.mockReturnValueOnce(ps)

    let groupAlive = true
    let detachedDescendantAlive = true
    const killSpy = vi.spyOn(process, 'kill').mockImplementation((pid, signal) => {
      if (pid === -1000) {
        if (signal === 0 && !groupAlive) throw esrch()
        if (signal === 'SIGKILL') groupAlive = false
        return true
      }
      expect(pid).toBe(1001)
      if (signal === 0 && !detachedDescendantAlive) throw esrch()
      if (signal === 'SIGKILL') detachedDescendantAlive = false
      return true
    })
    const child = new FakeChild(1000)
    registerOwnedPosixProcessGroup(child as never)

    const pending = terminateProcessTree(child as never)
    ps.stdout.emit('data', Buffer.from('1000 1\n1001 1000\n'))
    ps.emit('close', 0)
    await Promise.resolve()
    await Promise.resolve()
    await vi.advanceTimersByTimeAsync(3_000)

    await expect(pending).resolves.toEqual({ reaped: true })
    expect(killSpy).toHaveBeenCalledWith(-1000, 'SIGKILL')
    expect(killSpy).toHaveBeenCalledWith(1001, 'SIGKILL')
  })
})
