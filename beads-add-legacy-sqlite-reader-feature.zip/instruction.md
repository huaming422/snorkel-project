## Task

People upgrading from an old SQLite-era release of bd have no way to get a legacy SQLite workspace into the current binary short of keeping an old build around to open it. Add a subcommand to the existing `bd migrate` group that reads one of these workspaces directly and writes it out as current-format canonical JSONL, with no older bd release involved. It takes the path to the source database and an output destination, which can be a file or stdout, and it has to run on a machine with no current workspace set up yet.

Only the SQLite schemas of releases v0.49.6 and v0.50.3 are in scope. Older Dolt-based workspaces and any other on-disk format are not. An empty or missing optional value that means the same thing in the current format is not a loss.

## User stories / requirements

- Running the command on a legacy workspace from a supported release whose issues have labels, dependencies, and comments produces current-format canonical JSONL. Importing that output into a fresh current workspace brings every issue across with its field values and all of its labels, dependencies, and comments intact, and the source database is left unchanged.
- A source that cannot be converted exactly is refused: the command exits with an error and writes nothing to the file or stdout. That includes a release marker, table, or foreign key that differs from a supported release, and any value or relationship the current format cannot hold or the importer would lose or change.
- Every legacy timestamp, including those on dependencies and comments, comes across in UTC rounded to the nearest second, which is how the current format stores time. If a rounded value falls outside the range the current format can store, the workspace is refused instead of having the value clamped or shifted into range.
- A workspace from a supported release that has zero issues still converts successfully, producing empty current-format output with no issue records rather than an error.
