#!/usr/bin/env bash
# Coherence guard: the command and internal trees still compile with CGO enabled.
#
# This catches the half-wired change that compiles in the file it was edited in but
# breaks a consumer elsewhere in the tree. It is a compilation check only; every
# path built below already exists in the codebase, and nothing the work introduces
# is named here, so any design that keeps the tree coherent passes — whatever shape
# it took. Behaviour is exercised by the validation stories, not here.
set -euo pipefail

export GOFLAGS="${GOFLAGS:--mod=mod}"
export CGO_ENABLED="${CGO_ENABLED:-1}"
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"

cd /repo/beads

# The command tree and the internal tree must keep compiling together. CGO stays
# on to match the image and the normal product build.
echo "== build (cgo on): ./cmd/... ./internal/... =="
go build ./cmd/... ./internal/...

echo "OK: command and internal trees compile with CGO enabled"
