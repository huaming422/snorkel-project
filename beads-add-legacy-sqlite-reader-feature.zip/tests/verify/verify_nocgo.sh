#!/usr/bin/env bash
# Regression guard: the command binary and the whole internal tree still compile
# with CGO off.
#
# The product ships CGO-free builds for some release targets (.goreleaser.yml), so
# whatever the conversion is built on, a CGO_ENABLED=0 build has to stay green. A
# conversion that uses a CGO-only driver needs a build-tag split for that; one
# that needs no CGO passes as is. This step builds the command and internal trees
# with CGO_ENABLED=0.
#
# This is a compilation check only. It names nothing the work introduces: whatever
# the submission called its package, its entry point, its command token or its
# flags, a no-CGO build of the command and internal trees must still succeed. The
# message a no-CGO build reports at runtime is a solution-chosen string and is not
# asserted anywhere that gates correctness.
#
# On a tree that has not added the feature yet this passes (the pre-change tree
# already builds without CGO), so it is a pure regression gate.
set -euo pipefail

export GOFLAGS="${GOFLAGS:--mod=mod}"
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"
export CGO_ENABLED=0

cd /repo/beads

echo "== build (cgo off): ./cmd/... ./internal/... =="
go build ./cmd/... ./internal/...

echo "OK: command and internal trees compile with CGO disabled"
