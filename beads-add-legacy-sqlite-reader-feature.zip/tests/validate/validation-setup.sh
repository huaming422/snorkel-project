#!/usr/bin/env bash
# Environment setup for the legacy-SQLite reader validation stories.
#
# Runs after tests/test-setup.sh has prepared the Go toolchain and before any
# story test files are written. The stories build a genuine legacy SQLite
# workspace with the C sqlite driver (github.com/mattn/go-sqlite3), so CGO MUST
# stay enabled and the toolchain pinned, matching the image bake. A submission
# may or may not use that driver itself. The image already pre-downloaded the
# module+build cache at the base commit (incl. go-sqlite3 v1.14.8); we re-export
# the env the go-test driver inherits and, belt-and-suspenders, re-satisfy the
# module cache offline-first.
set -euo pipefail

cd /repo/beads

# Match the image's baked cache locations and the go-test driver's required env.
# CGO on: the fixtures link the C sqlite driver.
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"
export CGO_ENABLED="${CGO_ENABLED:-1}"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"
mkdir -p "$GOMODCACHE" "$GOCACHE"

# The story test runs MUST never rewrite the module manifest. Under the default
# resolver a `go test` whose import graph has an unresolved package edits
# go.mod/go.sum to try to satisfy it; that post-checkpoint write is then flagged
# as a repo-integrity violation. A change that does not build should simply fail
# its stories. So pin the downstream resolver to read-only: a missing import now
# fails the build cleanly and the manifest is left untouched. Every later story
# run inherits this env, and the go-test driver's settings.go env pins the same
# value. The cache-warm and CGO smoke below run under an explicit
# -mod=mod override only — they execute pre-checkpoint, so any manifest touch they
# make is baked into the integrity baseline and never flagged.
export GOFLAGS="-mod=readonly"

# Offline-first against the image bake, with a logged online fallback if a layer
# ever lost the cache. The C sqlite driver is in the base go.sum but the base
# manifest does not require it, so warm its specific version explicitly (an
# explicit module@version download goes straight to the cache and needs no
# manifest edit); then satisfy the rest from the manifest's build list.
# `go mod download` has no -mod flag, so it ignores the exported GOFLAGS -mod and
# needs none itself — downloading never rewrites the manifest regardless.
if GOPROXY=off go mod download github.com/mattn/go-sqlite3@v1.14.8 > /tmp/validation-setup.log 2>&1 \
   && GOPROXY=off go mod download >> /tmp/validation-setup.log 2>&1; then
    echo "[offline-first] go modules satisfied from image"
elif go mod download github.com/mattn/go-sqlite3@v1.14.8 >> /tmp/validation-setup.log 2>&1 \
     && go mod download >> /tmp/validation-setup.log 2>&1; then
    echo "[validation-setup] go modules downloaded online (image bake was stale)"
else
    tail -40 /tmp/validation-setup.log >&2
    echo "validation-setup.sh: go mod download failed" >&2
    exit 1
fi

# Loud smoke guard: the stories cannot run at all unless the module compiles a CGO
# test binary that links the C sqlite driver. Prove the toolchain + C driver are
# wired before any story runs, so a toolchain/CGO breakage fails here with a clear
# message instead of surfacing as an opaque per-story compile error. Runs with an
# explicit -mod=mod (pre-checkpoint, so a manifest touch is harmless) and builds
# only pre-existing driver code — it names nothing the submission introduces.
if ! go build -mod=mod github.com/mattn/go-sqlite3 > /tmp/validation-cgo-smoke.log 2>&1; then
    echo "validation-setup.sh: CGO sqlite driver failed to build — the stories need CGO_ENABLED=1 and a C toolchain:" >&2
    tail -40 /tmp/validation-cgo-smoke.log >&2
    exit 1
fi

echo "validation-setup.sh: Go toolchain ready, CGO sqlite driver builds, module deps cached."
