//! Rollback-heavy workloads in MVCC journal mode.
//!
//! Workloads run through `Database::open_file` and `Connection::execute(SQL)`.
//! What stays in memory afterwards is read from the `MvStore` behind
//! `Database::get_mv_store()`: its `rows` / `index_rows` maps and the
//! `live_version_count_approx` / `drop_unused_row_versions` counters.
//!
//! Every test sets `mvcc_checkpoint_threshold = -1` and `mvcc_gc_threshold = -1`,
//! so no automatic checkpoint or GC pass runs while a test is going.

use std::sync::Arc;
use turso_core::mvcc::database::SQLITE_SCHEMA_MVCC_TABLE_ID;
use turso_core::{Database, MemoryIO, SqliteDialect};

/// In-memory database in MVCC journal mode with background reclamation disabled.
/// Mirrors the engine's own public-API construction path.
fn mvcc_db() -> (Arc<Database>, Arc<turso_core::Connection>) {
    let io = Arc::new(MemoryIO::new());
    let db = Database::open_file(io, ":memory:", Arc::new(SqliteDialect)).unwrap();
    let conn = db.connect().unwrap();
    conn.execute("PRAGMA journal_mode = 'mvcc'").unwrap();
    conn.execute("PRAGMA mvcc_checkpoint_threshold = -1").unwrap();
    conn.execute("PRAGMA mvcc_gc_threshold = -1").unwrap();
    (db, conn)
}

fn query_rows(conn: &Arc<turso_core::Connection>, sql: &str) -> Vec<String> {
    let mut stmt = conn.prepare(sql).unwrap();
    let mut rows = Vec::new();
    stmt.run_with_row_callback(|row| {
        rows.push(
            row.get_values()
                .map(|value| value.to_string())
                .collect::<Vec<_>>()
                .join("|"),
        );
        Ok(())
    })
    .unwrap();
    rows
}

/// A hot row updated and rolled back many times keeps only its committed
/// version, a sweep finds nothing left over, and the committed value still reads
/// back after each rollback, including a rolled-back delete.
#[test]
fn rollback_removes_aborted_versions_immediately() {
    let (db, conn) = mvcc_db();
    let store = db.get_mv_store().clone().unwrap();

    conn.execute("CREATE TABLE t(id INTEGER PRIMARY KEY, v TEXT)")
        .unwrap();
    conn.execute("INSERT INTO t VALUES (1, 'committed')").unwrap();

    // Sum the version-chain lengths of all user-table rows (ignore the schema
    // table). Exactly one committed row exists, with a single committed version.
    let data_versions = || -> usize {
        store
            .rows
            .iter()
            .filter(|e| e.key().table_id != SQLITE_SCHEMA_MVCC_TABLE_ID)
            .map(|e| e.value().read().len())
            .sum()
    };
    let data_rows = || -> usize {
        store
            .rows
            .iter()
            .filter(|e| e.key().table_id != SQLITE_SCHEMA_MVCC_TABLE_ID)
            .count()
    };

    assert_eq!(data_rows(), 1, "exactly one committed user row");
    assert_eq!(data_versions(), 1, "committed row starts with one version");

    for _ in 0..100 {
        conn.execute("BEGIN").unwrap();
        conn.execute("UPDATE t SET v = 'aborted' WHERE id = 1")
            .unwrap();
        conn.execute("ROLLBACK").unwrap();
        assert_eq!(
            query_rows(&conn, "SELECT v FROM t WHERE id = 1"),
            vec!["committed".to_string()],
            "the committed value is still read after each aborted update"
        );
    }

    conn.execute("BEGIN").unwrap();
    conn.execute("DELETE FROM t WHERE id = 1").unwrap();
    conn.execute("ROLLBACK").unwrap();
    assert_eq!(
        query_rows(&conn, "SELECT v FROM t WHERE id = 1"),
        vec!["committed".to_string()],
        "an aborted delete leaves the committed row readable"
    );

    assert_eq!(
        data_rows(),
        1,
        "aborted modifications must not add user rows"
    );
    assert_eq!(
        data_versions(),
        1,
        "chain holds only the committed version; aborted versions were removed at abort time"
    );
    assert_eq!(
        store.drop_unused_row_versions(),
        0,
        "nothing is left for a later sweep to reclaim"
    );
}

/// After many rolled-back updates of one row, the live-version count is the
/// same as right after the commit.
#[test]
fn rollback_live_count_not_inflated() {
    let (db, conn) = mvcc_db();
    let store = db.get_mv_store().clone().unwrap();

    conn.execute("CREATE TABLE t(id INTEGER PRIMARY KEY, v TEXT)")
        .unwrap();
    conn.execute("INSERT INTO t VALUES (1, 'committed')").unwrap();

    let baseline = store.live_version_count_approx();

    for _ in 0..100 {
        conn.execute("BEGIN").unwrap();
        conn.execute("UPDATE t SET v = 'aborted' WHERE id = 1")
            .unwrap();
        conn.execute("ROLLBACK").unwrap();
    }

    assert_eq!(
        store.live_version_count_approx(),
        baseline,
        "aborted work must not inflate the live-version count"
    );
}

/// A retried `CREATE INDEX` that is rolled back each time, and a rolled-back
/// `CREATE TABLE` with inserts, leave the index-map count and the index / table
/// slot counts where they were before the transaction.
#[test]
fn rollback_reclaims_created_btree_maps() {
    let (db, conn) = mvcc_db();
    let store = db.get_mv_store().clone().unwrap();

    conn.execute("CREATE TABLE t(id INTEGER PRIMARY KEY, v TEXT)")
        .unwrap();
    conn.execute("BEGIN").unwrap();
    for i in 0..100 {
        conn.execute(format!("INSERT INTO t VALUES ({i}, 'v{i}')"))
            .unwrap();
    }
    conn.execute("COMMIT").unwrap();

    let index_slots = || -> usize {
        store.index_rows.iter().map(|index| index.value().len()).sum()
    };
    let table_slots = || -> usize {
        store
            .rows
            .iter()
            .filter(|entry| entry.key().table_id != SQLITE_SCHEMA_MVCC_TABLE_ID)
            .count()
    };

    let index_maps_before = store.index_rows.len();
    let index_slots_before = index_slots();
    let table_slots_before = table_slots();

    // A retried CREATE INDEX gets a fresh index id every attempt. Its slots exist
    // inside the transaction and are gone after the rollback.
    for _ in 0..5 {
        conn.execute("BEGIN").unwrap();
        conn.execute("CREATE INDEX idx_v ON t(v)").unwrap();
        assert_eq!(
            index_slots(),
            index_slots_before + 100,
            "index build populated its slots inside the transaction"
        );
        conn.execute("ROLLBACK").unwrap();
        assert_eq!(
            store.index_rows.len(),
            index_maps_before,
            "aborted index map must be gone"
        );
        assert_eq!(
            index_slots(),
            index_slots_before,
            "aborted index slots must be reclaimed"
        );
    }

    // The same for a table created and filled in the aborted transaction.
    conn.execute("BEGIN").unwrap();
    conn.execute("CREATE TABLE u(id INTEGER PRIMARY KEY, v TEXT)")
        .unwrap();
    for i in 0..50 {
        conn.execute(format!("INSERT INTO u VALUES ({i}, 'u{i}')"))
            .unwrap();
    }
    assert_eq!(
        table_slots(),
        table_slots_before + 50,
        "new table rows exist inside the transaction"
    );
    conn.execute("ROLLBACK").unwrap();
    assert_eq!(
        table_slots(),
        table_slots_before,
        "aborted table's row slots must be reclaimed"
    );
}

/// A committed index keeps one entry per row and keeps answering lookups after
/// rolled-back transactions that create another index or write through it.
#[test]
fn committed_btree_survives_rollback_reclaim() {
    let (db, conn) = mvcc_db();
    let store = db.get_mv_store().clone().unwrap();

    conn.execute("CREATE TABLE t(id INTEGER PRIMARY KEY, v TEXT)")
        .unwrap();
    conn.execute("BEGIN").unwrap();
    for i in 0..100 {
        conn.execute(format!("INSERT INTO t VALUES ({i}, 'v{i}')"))
            .unwrap();
    }
    conn.execute("COMMIT").unwrap();
    conn.execute("CREATE INDEX idx_keep ON t(v)").unwrap();

    let index_versions = || -> usize {
        store
            .index_rows
            .iter()
            .map(|index| {
                index
                    .value()
                    .iter()
                    .map(|entry| entry.value().read().len())
                    .sum::<usize>()
            })
            .sum()
    };

    assert_eq!(
        index_versions(),
        100,
        "committed index holds one entry per indexed row"
    );

    // Roll back a CREATE INDEX and writes that go through the committed index.
    for sql in [
        "CREATE INDEX idx_tmp ON t(v)",
        "UPDATE t SET v = 'aborted' || id WHERE id < 10",
        "INSERT INTO t VALUES (1000, 'v1000')",
        "DELETE FROM t WHERE id >= 90",
    ] {
        conn.execute("BEGIN").unwrap();
        conn.execute(sql).unwrap();
        conn.execute("ROLLBACK").unwrap();
    }

    // The committed index and its rows are unchanged.
    assert_eq!(
        index_versions(),
        100,
        "committed index keeps an entry per indexed row"
    );
    for (value, id) in [("v5", "5"), ("v42", "42"), ("v95", "95")] {
        assert_eq!(
            query_rows(&conn, &format!("SELECT id FROM t WHERE v = '{value}'")),
            vec![id.to_string()],
            "lookup of {value} returns its committed row"
        );
    }
    assert_eq!(
        query_rows(&conn, "SELECT count(*) FROM t WHERE v LIKE 'v%'"),
        vec!["100".to_string()],
        "all committed rows are still present"
    );
}
