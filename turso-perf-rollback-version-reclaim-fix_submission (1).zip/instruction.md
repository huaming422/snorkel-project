## Task

Our service keeps one turso database open for days with `PRAGMA journal_mode = 'mvcc'`, and it degrades when transactions keep rolling back. One worker updates a hot row and rolls back in a loop. Reads of that row get slower and slower, though the committed value never changes.

A migration also retries `BEGIN; CREATE INDEX ...; ROLLBACK` after timeouts, and each failed attempt leaves the process using more memory until a restart. Query results are right throughout. Once a rollback finishes, that row should read as fast as it did before, and a rolled-back migration shouldn't leave anything behind.
