## Task

Our service keeps one turso database open for days with `PRAGMA journal_mode = 'mvcc'`, and it gets worse the more transactions roll back. One worker updates a hot row and rolls back in a loop. Reads of that row keep getting slower, though the committed value never changes.

A migration also retries `BEGIN; CREATE INDEX ...; ROLLBACK` after timeouts, and each rolled-back attempt adds memory that only a restart gives back. Query results are right the whole time. Once a transaction rolls back, memory and read cost should be back where they were before it started.
