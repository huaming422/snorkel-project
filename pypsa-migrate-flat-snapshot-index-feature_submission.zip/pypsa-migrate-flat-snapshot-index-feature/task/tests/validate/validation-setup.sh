#!/usr/bin/env bash
# validation-setup.sh — runs once before the validation agent starts (network
# available). The task image already bakes the full dependency closure at the
# base commit via `uv sync --frozen --extra test` (PyPSA + legacy linopy +
# HiGHS), so on a healthy image this is an offline no-op; it only reaches the
# network if the baked closure is somehow incomplete, and logs loudly then.
set -euo pipefail

REPO=/repo/pypsa
cd "$REPO"

export UV_CACHE_DIR="${UV_CACHE_DIR:-/opt/uv-cache}"
export UV_PYTHON_INSTALL_DIR="${UV_PYTHON_INSTALL_DIR:-/opt/python}"
export SETUPTOOLS_SCM_PRETEND_VERSION="${SETUPTOOLS_SCM_PRETEND_VERSION:-1.2.4}"
export PATH="/repo/pypsa/.venv/bin:${PATH}"

# Offline-first: confirm the baked venv can import PyPSA plus the optimization
# stack the stories exercise (legacy linopy + HiGHS for LP solves).
if uv run --no-sync --frozen python -c \
    "import pypsa, linopy, highspy, pandas, xarray, numpy" >/dev/null 2>&1; then
    echo "[validation-setup] baked dependency closure OK (offline)"
else
    echo "[validation-setup] WARNING: baked closure incomplete; attempting online sync" >&2
    uv sync --frozen --extra test > /tmp/validation-setup-sync.log 2>&1 \
        || { echo "[validation-setup] uv sync failed:" >&2; tail -80 /tmp/validation-setup-sync.log >&2; exit 1; }
    uv pip install --python .venv/bin/python setuptools==84.2.1 setuptools_scm==10.3.4 || true
    uv run --no-sync --frozen python -c \
        "import pypsa, linopy, highspy, pandas, xarray, numpy" \
        || { echo "[validation-setup] closure still broken after online sync" >&2; exit 1; }
fi

# Loud smoke guard: a multi-period LP must build and solve to optimality under
# the default representation with the bundled HiGHS solver, and the legacy
# linopy line (the one the task targets) must be installed. Only pre-existing,
# implementation-agnostic symbols are touched here.
uv run --no-sync --frozen python - <<'PY'
import pandas as pd
import pypsa

n = pypsa.Network(snapshots=range(3))
n.investment_periods = [2020, 2030]
n.add("Bus", "b")
n.add("Generator", "g", bus="b", p_nom=1000, marginal_cost=10)
n.add("Load", "l", bus="b", p_set=1.0)
status, cond = n.optimize(multi_investment_periods=True, solver_name="highs")
assert (status, cond) == ("ok", "optimal"), (status, cond)
assert isinstance(n.model.parameters.snapshots.to_index(), pd.MultiIndex)
import linopy
print(f"[validation-setup] pypsa {pypsa.__version__} linopy {linopy.__version__}; "
      "multi-period HiGHS solve OK (default MultiIndex build)")
PY

echo "[validation-setup] validation env ready"
