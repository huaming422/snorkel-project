#!/usr/bin/env bash
# test-setup.sh — runs once before the verifier (runs with network available).
# The image already bakes the full dependency closure at the base commit via
# `uv sync --frozen --extra test` (base deps + pytest + HiGHS), so this is an
# offline no-op on a healthy image. The online fallback only fires if the baked
# closure is somehow incomplete, and logs loudly when it does.
set -euo pipefail

REPO=/repo/pypsa
cd "$REPO"

export UV_CACHE_DIR="${UV_CACHE_DIR:-/opt/uv-cache}"
export UV_PYTHON_INSTALL_DIR="${UV_PYTHON_INSTALL_DIR:-/opt/python}"
export SETUPTOOLS_SCM_PRETEND_VERSION="${SETUPTOOLS_SCM_PRETEND_VERSION:-1.2.4}"
export PATH="/repo/pypsa/.venv/bin:${PATH}"

# Offline-first: verify the baked closure can import the solver + optimization
# stack the verifier relies on. If it already imports, we are done — no network.
if uv run --no-sync --frozen python -c \
    "import pypsa, linopy, highspy, pandas, xarray, numpy" >/dev/null 2>&1; then
    echo "[test-setup] baked dependency closure OK (offline)"
else
    echo "[test-setup] WARNING: baked closure incomplete; attempting online sync" >&2
    uv sync --frozen --extra test > /tmp/test-setup-sync.log 2>&1 \
        || { echo "[test-setup] uv sync failed:" >&2; tail -80 /tmp/test-setup-sync.log >&2; exit 1; }
    uv pip install --python .venv/bin/python setuptools==84.2.1 setuptools_scm==10.3.4 || true
    uv run --no-sync --frozen python -c \
        "import pypsa, linopy, highspy, pandas, xarray, numpy" \
        || { echo "[test-setup] closure still broken after online sync" >&2; exit 1; }
fi

# Sanity check: the installed linopy must be the legacy (pre-v1) line the task
# is designed around, and HiGHS must be available for offline LP solves.
uv run --no-sync --frozen python - <<'PY'
import linopy, highspy, pypsa
print(f"[test-setup] pypsa {pypsa.__version__} linopy {linopy.__version__} (HiGHS available)")
PY

echo "[test-setup] pypsa optimization test env ready"
