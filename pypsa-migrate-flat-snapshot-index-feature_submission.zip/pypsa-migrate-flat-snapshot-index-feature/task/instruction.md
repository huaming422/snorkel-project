## Task

We build our optimization models on linopy, and a forthcoming change there will stop allowing a pandas MultiIndex on a model dimension. Our multi-period (investment period) models currently index their snapshot dimension with exactly such a MultiIndex, so once that lands we could not build them at all. Let's get ahead of it.

We want the option to build a multi-period model over a flat snapshot dimension instead, alongside today's MultiIndex build. Today's build stays the default: with the default setting, on the linopy we currently run, the model we build and every number it produces (objective, dispatch, capacities) comes out exactly as it does now. The flat path is purely additive.

It reaches across the whole optimization build (variables, constraints, expressions, the objective, global constraints) and the paths that read solved values back onto the network (the per-component accessors and the statistics layer). It also covers windowed, myopic, and rolling-horizon runs, where we solve over a subset of snapshots or one investment period at a time, under both representations.

## User stories / requirements

- The optimization layer takes a setting that chooses how a multi-period model labels its snapshot dimension. The default labels it as today; the flat setting builds over a flat snapshot dimension whose labels are the (period, timestep) pairs of the network's snapshots. An invalid value is rejected with an error when the model is built.
- Building a multi-period model under the flat representation and solving it gives the same objective value and the same optimal dispatch and capacities as building and solving the same network under the default representation.
- After a model is built, the snapshot data the build relies on (such as snapshot weightings) is available already lined up with the model's own snapshot labels, through one path that translates between the network's labels and the model's across every investment period under either labelling, with values matching the network's exactly.
- A user-supplied extra_functionality(n, sns) callback is handed exactly the snapshots the model was built over, in the model's own labelling, under both the default and the flat representation, and likewise when the build is restricted to a subset of snapshots.
