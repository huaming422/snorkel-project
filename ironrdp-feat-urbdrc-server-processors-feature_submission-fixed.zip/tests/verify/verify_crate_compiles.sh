#!/usr/bin/env bash
#
# Structural compile verifier for ironrdp-feat-urbdrc-server-processors.
#
# The feature's behavior — the control/device server state machines, pending-I/O
# tracking, completion routing, no-ack OUT handling, buffer bounds — is observable
# only by DRIVING the new processors, so it lives entirely in the validation
# stories. This verifier does the one thing a static gate can do cheaply and
# implementation-agnostically: confirm the affected crate still TYPE-CHECKS after
# the submitted edits.
#
# Why this matters as a gate:
#   * An empty/untouched crate is caught by validation, not here —
#     `ironrdp-rdpeusb` already compiles at the base commit, so an unmodified
#     submission passes this check. That is intentional: this verifier is a cheap
#     pre-filter that stops a non-compiling submission before validation wastes a
#     full test build on a doomed crate.
#   * The intended change pulls the backend-facing request/completion types into
#     a shared module and reworks the `usb_dev`/`ts_urb` types the client half
#     uses. A submission that adds the server processors but leaves the client
#     side (or the shared data model) inconsistent surfaces as a compile error
#     here, before any story runs.
#
# Implementation-agnostic by construction:
#   * Tests THROUGH the pre-existing, stable build interface `cargo check -p
#     ironrdp-rdpeusb` (the package name exists in the pre-fix Cargo.toml).
#   * No imports of agent-named modules, no grep for the new `server`/`io`
#     modules, no new type/function/method names, and no `cargo test` (so it is
#     insensitive to which test names, if any, exist).
#
# We deliberately use `cargo check` (NOT `cargo check --tests`): the behavioral
# test build is the validation stories' job (they add serde dev-deps + inject a
# test file). A lib+bins check is all that is needed to prove the crate and its
# client/server/io surfaces integrate.
# That covers the crate itself. Its existing tests in ironrdp-testsuite-core
# are a separate package, and the second step at the end builds them.
#
# The image pre-warms `cargo build --locked --tests` for the whole workspace at
# the base commit, so a warm `cargo check -p ironrdp-rdpeusb` is typically well
# under 30s. The second step adds a few minutes; the 900s timeout in verify.toml
# covers both on a cold target/ with margin.
#
# Exit codes:
#   0        — the crate type-checks cleanly
#   non-zero — propagates the cargo failure (runner reports the tail of stderr)

set -euo pipefail

# The runner invokes this script with cwd = {repo_dir} (/repo/ironrdp); make the
# working directory explicit so the check is robust to runner cwd changes.
cd /repo/ironrdp

# Honor the image's canonical toolchain/cache locations. These match the task
# Dockerfile (CARGO_HOME=/opt/cargo, RUSTUP_HOME=/opt/rustup); fall back to them
# only if the environment did not already set them.
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export PATH="$CARGO_HOME/bin:$PATH"

echo "verify: rustc=$(rustc --version 2>&1 | head -1)"
echo "verify: cargo=$(cargo --version 2>&1 | head -1)"

cargo check -p ironrdp-rdpeusb --message-format=short

# The crate's integration tests live in ironrdp-testsuite-core
# (tests/rdpeusb/), outside the crate, and drive the client half through its
# public API. A change to that API has to bring them along, so build the
# workspace's test targets as well. This is the command the image ran to warm
# the target directory, so only ironrdp-rdpeusb and what depends on it (the
# ironrdp-testsuite-core test binary) are rebuilt here.
cargo build --tests --message-format=short
