## Task

`ironrdp-rdpeusb` has no server side yet, so a server application can't use the USB devices an RDP client passes to it. Add URBDRC server processors for it, one for the control side and one for each device. Each should talk to the application through its own backend trait, the way the client pair does, and implement `DvcProcessor` and `DvcServerProcessor` so the DVC server stack can host it. Keep the changes inside `ironrdp-rdpeusb`, plus whatever `ironrdp-testsuite-core` needs to keep up with them.

## User stories / requirements

- When a control server starts, it should send its capability request itself and answer the client in MS-RDPEUSB's order until the crate's own control client is ready. After that, each device channel the client asks for goes to the backend to set up; one asked for earlier does not.
- Each added device should reach the device server's backend once, then be set up for I/O. Completions go to their request's callback, but only over the client's completion interface and within the requested size. Don't wait on no-ack OUT transfers. Refuse one unless it's isochronous to a device that said it supports no-ack.
- Client and server should describe I/O requests and completion results with the same types, rather than each side keeping its own copy. The client should still answer the server exactly as it does today.
