## Task

`ironrdp-rdpeusb` gives a server application no way to drive the USB devices of an RDP client, since the crate implements only the client side of MS-RDPEUSB. Add the missing URBDRC server processors, a control-side one and one per device, each with a backend trait the application implements, so the server half has the same shape as the client pair. Both should be `DvcProcessor`s like the client processors, and `DvcServerProcessor`s as well, so the DVC server stack can host them.

MS-RDPEUSB sets the order of the messages both processors send and expect. Nothing outside `ironrdp-rdpeusb` should need to change.

## User stories / requirements

- The capability request goes out as soon as a connection's control server starts. The server's backend provisions each device channel, but only after the server is ready: that takes a correct reply to every step of the capability exchange and the channel setup.
- The per-device server sends a device's I/O setup messages and registers it with the backend when first told it was added; a repeat changes nothing. A completion goes to the backend callback of the request it answers, matched by identifier, and an OUT transfer that asks for no acknowledgement is not waited on.
- On the wire, nothing changes for the client. Its I/O request and completion-result types become one set the server uses as well: a single, carefully designed API for both halves and their backends, rather than two parallel sets.
