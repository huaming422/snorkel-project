## Task

`ironrdp-rdpeusb` gives a server application no way to drive the USB devices of an RDP client. Add the missing URBDRC server processors. The control side needs one and each device another, and the application hooks into each through a backend trait, so the server half has the same shape as the client pair. Both should be `DvcProcessor`s like the client processors, and `DvcServerProcessor`s as well, so the DVC server stack can host them. The work stays in `ironrdp-rdpeusb`; only its callers in `ironrdp-testsuite-core` have to follow its changes.

## User stories / requirements

- A control server's backend provisions a device channel each time the client asks for one, once their handshake is over and not before. The server runs that handshake unaided: its capability request goes out as it starts, and the crate's own control client reaches ready on the server's replies, which keep to MS-RDPEUSB's order.
- A device server's backend gets a device, and its I/O setup messages go out, on the first addition notice only. Completions reach the backend through their request's callback by identifier, and only from the client's assigned completion interface with no more output than the request allowed. No-ack OUT transfers are not waited on, and refused unless isochronous to a device whose addition announced no-ack isochronous support.
- Whether a backend is for the client or the server, the I/O requests and completion results it handles use the same types, with no second copy kept on either side. On the wire, nothing changes for the client.
