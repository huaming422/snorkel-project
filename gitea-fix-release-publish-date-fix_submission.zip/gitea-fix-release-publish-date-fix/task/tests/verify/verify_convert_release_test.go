// Copyright 2026 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package convert

import (
	"encoding/json"
	"testing"

	repo_model "gitea.dev/models/repo"
	"gitea.dev/models/unittest"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// publishedAtRaw serializes a release through the stable public ToAPIRelease
// interface and returns the raw JSON of the `published_at` field exactly as a
// client would observe it on the wire. Observing the serialized contract (rather
// than a Go struct field) keeps the check agnostic to how the publication time is
// represented internally: the nullable field may be modeled however the code
// likes, so long as a published release reports a concrete timestamp and an
// unpublished one reports none.
//
// "No publication date" has two equally-valid wire spellings — an explicit JSON
// null, or the key omitted entirely — and both report the value as absent. A
// missing key is therefore normalised to the string "null" so the check accepts
// either serialization choice and only separates absent from concrete.
func publishedAtRaw(t *testing.T, repo *repo_model.Repository, rel *repo_model.Release) string {
	t.Helper()
	api := ToAPIRelease(t.Context(), repo, rel)
	require.NotNil(t, api)
	blob, err := json.Marshal(api)
	require.NoError(t, err)
	var fields map[string]json.RawMessage
	require.NoError(t, json.Unmarshal(blob, &fields))
	raw, ok := fields["published_at"]
	if !ok {
		return "null"
	}
	return string(raw)
}

// A release's publication date and the date of the commit it describes are
// separate facts. The API must reflect that at the serialization boundary: an
// unpublished (draft) release reports no publication date even though it still
// has a creation date. Pre-fix, the payload reported the creation date as the
// publication date for every release including drafts; a draft must now report
// its publication date as absent.
//
// This isolates the serialization layer against a genuine, reachable draft: the
// fixture's draft release carries a creation date but no recorded publication
// time, exactly the consistent state a draft occupies in production (the update
// path never leaves a draft with a lingering publication time). The check is
// therefore agnostic to how the serializer decides absence — keying on the draft
// flag and keying on an unset publication time are behaviourally identical for
// every state a draft can actually reach, and both must report absence here.
//
// The complementary direction — that a genuinely published release reports a
// concrete publication date, distinct from its creation/commit date — is
// exercised end to end through the release-creation flow (which stamps an actual
// publication time) rather than against a fixture's unset time, so both
// behaviours are observed where they are reachable.
func TestVerify_PublishedAtNullableForDrafts(t *testing.T) {
	require.NoError(t, unittest.PrepareTestDatabase())

	repo1 := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 1})
	// Fixture release id=4 is a genuine draft in repo 1 (is_draft=true, no
	// recorded publication time) — a reachable, consistent state, not one
	// synthesised by flipping a published release's flag in memory.
	rel := unittest.AssertExistsAndLoadBean(t, &repo_model.Release{ID: 4})
	require.NoError(t, rel.LoadAttributes(t.Context()))
	require.True(t, rel.IsDraft, "fixture precondition: release 4 is a draft")

	// A draft reports no publication date: the field serializes to JSON null
	// (or is omitted), even though the release carries a creation date.
	draft := publishedAtRaw(t, repo1, rel)
	assert.Equal(t, "null", draft,
		"an unpublished release has no publication date")

	createdAt := func() string {
		blob, err := json.Marshal(ToAPIRelease(t.Context(), repo1, rel))
		require.NoError(t, err)
		var fields map[string]json.RawMessage
		require.NoError(t, json.Unmarshal(blob, &fields))
		return string(fields["created_at"])
	}()
	assert.NotEqual(t, "null", createdAt,
		"the draft still carries a creation date, so absence is specific to publication")
}
