// Copyright 2026 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package repository

import (
	"testing"
	"time"

	repo_model "gitea.dev/models/repo"
	"gitea.dev/models/unittest"
	"gitea.dev/modules/git"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// Syncing tags into releases dates each release by the date of the commit the
// tag points at — not by when the tag itself was written. The distinction only
// shows up for an annotated tag, whose own (tagger) time is independent of its
// target commit's time.
//
// Observed end-to-end through the stable SyncReleasesWithTags interface reading
// the pre-existing CreatedUnix field: an annotated tag is created now, pointing
// at an old fixture commit, then the sync runs and the resulting release's date
// is compared to the commit's committer date. A tree that dated the release by
// the tag-writing time instead would record ~now, which is years away from the
// 2017 fixture commit.
func TestVerify_TagCommitDateResolved(t *testing.T) {
	require.NoError(t, unittest.PrepareTestDatabase())

	repo := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 1})

	gitRepo, err := git.OpenRepository(t.Context(), repo)
	require.NoError(t, err)
	defer gitRepo.Close()

	// The target: an old commit on the fixture repo. Its committer date is the
	// value a correct sync must record.
	commit, err := gitRepo.GetBranchCommit(t.Context(), "master")
	require.NoError(t, err)
	commitWhen := commit.Committer.When.Unix()

	// Precondition: the commit is far enough in the past that "the commit's date"
	// and "roughly now" (when the tag is written below) can never be confused.
	// The fixture commit is from 2017, many years back; a two-year margin is a
	// safe lower bound that still leaves no room for clock noise to blur the two.
	require.Lessf(t, commitWhen, time.Now().Unix()-(2*365*24*3600),
		"fixture precondition: master points at a commit at least two years old (got %d)", commitWhen)

	// Write an annotated tag NOW at that old commit. An annotated tag records its
	// own creation (tagger) time — roughly now — which is distinct from the
	// target commit's committer time.
	const tagName = "v9.9-syncprobe"
	require.NoError(t, gitRepo.CreateAnnotatedTag(t.Context(), tagName, "probe for tag commit date", commit.ID.String()))

	_, err = SyncReleasesWithTags(t.Context(), repo, gitRepo)
	require.NoError(t, err)

	rel, err := repo_model.GetRelease(t.Context(), repo.ID, tagName)
	require.NoError(t, err)

	assert.Equal(t, commitWhen, int64(rel.CreatedUnix),
		"a synced tag's release is dated by the commit it points at, not by when the tag was written")
}
