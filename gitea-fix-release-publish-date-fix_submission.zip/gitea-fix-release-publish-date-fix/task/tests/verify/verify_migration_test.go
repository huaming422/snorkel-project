// Copyright 2026 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package v28_test

import (
	"strconv"
	"testing"

	"gitea.dev/modelmigration"
	"gitea.dev/modelmigration/migrationtest"

	"github.com/stretchr/testify/require"
)

// toInt64 reads one raw SQL cell (always delivered as decimal-ASCII bytes by the
// []byte-mode query path) as an integer. A NULL / absent cell reads as zero,
// matching the "no recorded publication time" state.
func toInt64(b []byte) int64 {
	if len(b) == 0 {
		return 0
	}
	n, err := strconv.ParseInt(string(b), 10, 64)
	if err != nil {
		return -1 // a non-integer cell can never match the expected backfill pattern
	}
	return n
}

// The schema change backfills existing data: a normal release receives a
// publication time equal to its creation time, while a draft is left with none.
// Observed by seeding the table with a normal release, a draft, and a bare git
// tag, running the migration sequence, then reading the rows back.
//
// The sequence is driven through the public entry point rather than by calling
// the newest step by name: the recorded schema version is seeded at the
// pre-change head, so every step added on top of it runs (one or several),
// whatever those steps are named. This additionally confirms the new step was
// wired into the sequence rather than merely defined. A minimal local release
// shape (without the new column) is synced first so the starting schema matches
// the pre-change world.
//
// The publication time is located by VALUE, not by column name: of all the
// columns present after the migration, exactly the backfilled one carries the
// normal release's creation time while the draft reads zero. The creation column
// itself does not match (its draft cell holds the draft's own creation time, not
// zero), so this identifies the new column without assuming what it was named.
//
// The bare git-tag row (is_tag=true) is NOT pinned: whether the backfill reaches
// it depends on how the fix scopes the UPDATE. "Only real releases" (is_draft=false
// AND is_tag=false) and "every non-draft" (is_draft=false) are both contract-valid
// — base.md speaks only to already-published releases and drafts — so the tag cell
// is accepted at either its creation time or zero.
func TestVerify_MigrationBackfillsNonDrafts(t *testing.T) {
	type Release struct {
		ID          int64 `xorm:"pk autoincr"`
		IsDraft     bool  `xorm:"NOT NULL DEFAULT false"`
		IsTag       bool  `xorm:"NOT NULL DEFAULT false"`
		CreatedUnix int64 `xorm:"INDEX"`
	}

	x, deferable := migrationtest.PrepareTestEnv(t, 0, new(Release))
	defer deferable()
	if x == nil || t.Failed() {
		return
	}

	_, err := x.Insert(
		&Release{CreatedUnix: 1000000},                // normal release -> backfilled
		&Release{IsDraft: true, CreatedUnix: 2000000}, // draft          -> left unset
		&Release{IsTag: true, CreatedUnix: 3000000},   // tag            -> backfilled
	)
	require.NoError(t, err)

	// Seed the schema-version row at the pre-change head so every step stacked on
	// top of it runs. The baseline checkout's newest step records version 350, so
	// a database sitting at 350 is one that has applied everything that already
	// shipped and nothing new; the run then applies exactly the added step(s).
	require.NoError(t, x.Sync(new(modelmigration.Version)))
	_, err = x.Insert(&modelmigration.Version{ID: 1, Version: 350})
	require.NoError(t, err)

	require.NoError(t, modelmigration.Migrate(t.Context(), x))

	rows, err := x.Query("SELECT * FROM `release` ORDER BY id")
	require.NoError(t, err)
	require.Len(t, rows, 3, "the three seeded rows survive the migration")

	// The backfill contract: the normal release carries its creation time, the
	// draft none. The bare git-tag row is accepted either way (backfilled to its
	// creation time, or left unset) — scoping the UPDATE to exclude tag rows is a
	// defensible reading of a contract that only speaks to releases and drafts.
	matched := ""
	for col := range rows[0] {
		normal := toInt64(rows[0][col])
		draft := toInt64(rows[1][col])
		tag := toInt64(rows[2][col])
		if normal == 1000000 && draft == 0 && (tag == 3000000 || tag == 0) {
			matched = col
			break
		}
	}
	require.NotEmptyf(t, matched,
		"no column was backfilled with the publication time (the normal release "+
			"dated from its creation time, the draft left unset); got rows %v", rows)
}
