// Copyright 2026 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package release

import (
	"encoding/json"
	"testing"
	"time"

	repo_model "gitea.dev/models/repo"
	"gitea.dev/models/unittest"
	user_model "gitea.dev/models/user"
	"gitea.dev/modules/git"
	"gitea.dev/modules/timeutil"
	"gitea.dev/services/convert"

	_ "gitea.dev/models/actions"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// verifyAPIReleaseDates serializes a release through the stable public
// ToAPIRelease interface and returns the raw JSON of its `created_at` and
// `published_at` fields exactly as an API client observes them. Reading the
// serialized contract keeps the checks agnostic to how the publication time is
// stored or named internally: only the externally-visible dates matter.
//
// A publication time reported as absent has two equally-valid wire spellings —
// an explicit JSON null, or the key omitted — so a missing published_at is
// normalised to the string "null"; the checks only separate absent from
// concrete. created_at is always present (a release always has a creation date).
func verifyAPIReleaseDates(t *testing.T, repo *repo_model.Repository, rel *repo_model.Release) (createdAt, publishedAt string) {
	t.Helper()
	require.NoError(t, rel.LoadAttributes(t.Context()))
	api := convert.ToAPIRelease(t.Context(), repo, rel)
	require.NotNil(t, api)
	blob, err := json.Marshal(api)
	require.NoError(t, err)
	var fields map[string]json.RawMessage
	require.NoError(t, json.Unmarshal(blob, &fields))
	created, ok := fields["created_at"]
	require.Truef(t, ok, "serialized release carries created_at; got %s", blob)
	published, ok := fields["published_at"]
	if !ok {
		return string(created), "null"
	}
	return string(created), string(published)
}

// Creating a release dates it by the committer date of the commit it points at,
// while its publication date is the (later) moment of publication — the two are
// independent. Observed through the stable CreateRelease interface on repo
// fixture id=1, pointing at an old commit so the commit date and "now" are far
// apart.
func TestVerify_CreatedAtIsCommitDate(t *testing.T) {
	require.NoError(t, unittest.PrepareTestDatabase())

	user := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 2})
	repo := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 1})

	gitRepo, err := git.OpenRepository(t.Context(), repo)
	require.NoError(t, err)
	defer gitRepo.Close()

	rel := &repo_model.Release{
		RepoID: repo.ID, Repo: repo, PublisherID: user.ID, Publisher: user,
		TagName: "v9.9-dated", Target: "master", Title: "v9.9-dated",
	}
	require.NoError(t, CreateRelease(t.Context(), gitRepo, rel, nil, ""))

	commit, err := gitRepo.GetBranchCommit(t.Context(), "master")
	require.NoError(t, err)

	// The stored creation date is the commit's committer date (a pre-existing,
	// stable field on the release model).
	assert.Equal(t, commit.Committer.When.Unix(), int64(rel.CreatedUnix),
		"a release is dated by the commit it points at")

	// Observed through the API: a published release carries a concrete
	// publication date, and it is NOT the commit date — publication happened now,
	// long after this old commit was authored.
	createdAt, publishedAt := verifyAPIReleaseDates(t, repo, rel)
	assert.NotEqual(t, "null", publishedAt,
		"a published release reports a concrete publication date")
	assert.NotEqual(t, createdAt, publishedAt,
		"the publication date is distinct from the commit date")
}

// Publishing a release that points at an OLDER commit must not take over the
// "latest release" badge from a release pointing at a newer commit. Observed
// through GetLatestReleaseByRepoID after creating two releases whose target
// branches have distinct commit dates (DefaultBranch newer, master older).
func TestVerify_LatestReleaseByCommitDate(t *testing.T) {
	require.NoError(t, unittest.PrepareTestDatabase())

	user := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 2})
	repo := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 1})

	gitRepo, err := git.OpenRepository(t.Context(), repo)
	require.NoError(t, err)
	defer gitRepo.Close()

	newRelease := func(tagName, target string) *repo_model.Release {
		rel := &repo_model.Release{
			RepoID: repo.ID, Repo: repo, PublisherID: user.ID, Publisher: user,
			TagName: tagName, Target: target, Title: tagName,
		}
		require.NoError(t, CreateRelease(t.Context(), gitRepo, rel, nil, ""))
		return rel
	}

	// Sanity-check that the two branches really do point at commits with
	// different dates, otherwise the scenario proves nothing.
	recentCommit, err := gitRepo.GetBranchCommit(t.Context(), "DefaultBranch")
	require.NoError(t, err)
	oldCommit, err := gitRepo.GetBranchCommit(t.Context(), "master")
	require.NoError(t, err)
	require.Greater(t, recentCommit.Committer.When.Unix(), oldCommit.Committer.When.Unix(),
		"fixture precondition: DefaultBranch points at a newer commit than master")

	recent := newRelease("v9.9-recent", "DefaultBranch")
	// Published afterwards, but from an older commit, so it must NOT take over
	// as the latest release.
	_ = newRelease("v9.9-old", "master")

	latest, err := repo_model.GetLatestReleaseByRepoID(t.Context(), repo.ID)
	require.NoError(t, err)
	assert.Equal(t, recent.ID, latest.ID,
		"the latest release is the one pointing at the newest commit")
}

// The publication date reflects the draft lifecycle through UpdateRelease:
// editing a published release does not move it, publishing a draft sets it, and
// withdrawing back to a draft clears it. Observed entirely through the API
// `published_at` field (null when unpublished, concrete when published).
func TestVerify_DraftPublishToggle(t *testing.T) {
	require.NoError(t, unittest.PrepareTestDatabase())

	user := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 2})
	repo := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 1})

	gitRepo, err := git.OpenRepository(t.Context(), repo)
	require.NoError(t, err)
	defer gitRepo.Close()

	// Advance a mocked clock between operations instead of sleeping, so a
	// publication date is deterministic AND any wrongful re-stamp on a plain edit
	// would visibly move the value.
	fakeNow := time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC)
	defer timeutil.MockSet(fakeNow)()
	advance := func() { fakeNow = fakeNow.Add(time.Hour); timeutil.MockSet(fakeNow) }

	publishedAt := func(id int64) string {
		rel, err := repo_model.GetReleaseByID(t.Context(), id)
		require.NoError(t, err)
		rel.Repo = repo
		_, p := verifyAPIReleaseDates(t, repo, rel)
		return p
	}

	// A published release has a concrete publication date.
	published := &repo_model.Release{
		RepoID: repo.ID, Repo: repo, PublisherID: user.ID, Publisher: user,
		TagName: "v8.1-published", Target: "master", Title: "v8.1 published",
		Note: "published", IsDraft: false,
	}
	require.NoError(t, CreateRelease(t.Context(), gitRepo, published, nil, ""))
	at0 := publishedAt(published.ID)
	assert.NotEqual(t, "null", at0, "a published release has a publication date")

	// Editing a published release leaves its publication date unchanged, even
	// though the clock has moved on.
	advance()
	edited, err := repo_model.GetReleaseByID(t.Context(), published.ID)
	require.NoError(t, err)
	edited.Repo, edited.Publisher = repo, user
	edited.Note = "Changed note"
	require.NoError(t, UpdateRelease(t.Context(), user, gitRepo, edited, nil, nil, nil))
	assert.Equal(t, at0, publishedAt(published.ID),
		"editing a published release does not move its publication date")

	// A freshly created draft has no publication date.
	draft := &repo_model.Release{
		RepoID: repo.ID, Repo: repo, PublisherID: user.ID, Publisher: user,
		TagName: "v8.2-draft", Target: "master", Title: "v8.2 draft",
		Note: "draft", IsDraft: true,
	}
	require.NoError(t, CreateRelease(t.Context(), gitRepo, draft, nil, ""))
	assert.Equal(t, "null", publishedAt(draft.ID), "a draft has no publication date")

	// Publishing the draft sets a publication date.
	advance()
	toPublish, err := repo_model.GetReleaseByID(t.Context(), draft.ID)
	require.NoError(t, err)
	toPublish.Repo, toPublish.Publisher = repo, user
	toPublish.IsDraft = false
	require.NoError(t, UpdateRelease(t.Context(), user, gitRepo, toPublish, nil, nil, nil))
	assert.NotEqual(t, "null", publishedAt(draft.ID), "publishing sets a publication date")

	// Withdrawing it back to a draft clears the publication date again.
	advance()
	toWithdraw, err := repo_model.GetReleaseByID(t.Context(), draft.ID)
	require.NoError(t, err)
	toWithdraw.Repo, toWithdraw.Publisher = repo, user
	toWithdraw.IsDraft = true
	require.NoError(t, UpdateRelease(t.Context(), user, gitRepo, toWithdraw, nil, nil, nil))
	assert.Equal(t, "null", publishedAt(draft.ID), "withdrawing unpublishes it again")
}
