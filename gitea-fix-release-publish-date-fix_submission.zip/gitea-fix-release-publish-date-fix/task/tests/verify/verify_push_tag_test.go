// Copyright 2026 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package repository

import (
	"testing"
	"time"

	repo_model "gitea.dev/models/repo"
	"gitea.dev/models/unittest"
	user_model "gitea.dev/models/user"
	"gitea.dev/modules/git"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// A tag pushed from the command line must date its release by the commit it
// points at, not by when the tag object itself was written. Only an annotated
// tag exposes the distinction — its tagger time is independent of the target
// commit's committer time — so a tree that dated the release by the tag-writing
// time would record ~now, years away from the old fixture commit.
//
// Observed end-to-end through the stable PushUpdateAddDeleteTags interface (the
// public entry point the push handler calls), reading the pre-existing
// CreatedUnix field: an annotated tag is written NOW at an old fixture commit,
// the push path syncs it into a release, and the release's date is compared to
// the commit's committer date by VALUE. This exercises services/repository's
// push handling, which the web-UI release flow does not reach.
func TestVerify_PushedTagDatedByCommit(t *testing.T) {
	require.NoError(t, unittest.PrepareTestDatabase())

	pusher := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 2})
	repo := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 1})

	gitRepo, err := git.OpenRepository(t.Context(), repo)
	require.NoError(t, err)
	defer gitRepo.Close()

	// The target: an old commit on the fixture repo. Its committer date is the
	// value a correct push sync must record on the release.
	commit, err := gitRepo.GetBranchCommit(t.Context(), "master")
	require.NoError(t, err)
	commitWhen := commit.Committer.When.Unix()

	// Precondition: the commit is far enough in the past that "the commit's date"
	// and "roughly now" (when the tag is written below) can never be confused.
	require.Lessf(t, commitWhen, time.Now().Unix()-(2*365*24*3600),
		"fixture precondition: master points at a commit at least two years old (got %d)", commitWhen)

	// Write an annotated tag NOW at that old commit, then drive it through the
	// command-line push path. An annotated tag records its own (tagger) time —
	// roughly now — which is distinct from the target commit's committer time.
	const tagName = "v9.9-pushprobe"
	require.NoError(t, gitRepo.CreateAnnotatedTag(t.Context(), tagName, "probe for pushed tag commit date", commit.ID.String()))

	require.NoError(t, PushUpdateAddDeleteTags(t.Context(), repo, gitRepo, pusher, []string{tagName}, nil))

	rel, err := repo_model.GetRelease(t.Context(), repo.ID, tagName)
	require.NoError(t, err)

	assert.Equal(t, commitWhen, int64(rel.CreatedUnix),
		"a pushed tag's release is dated by the commit it points at, not by when the tag was written")
}
