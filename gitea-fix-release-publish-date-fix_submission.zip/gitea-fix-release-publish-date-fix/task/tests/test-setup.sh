#!/usr/bin/env bash
#
# test-setup.sh — sourced by the verifier harness BEFORE `go test` runs.
#
# The image already baked the Go module cache, the compiled test binaries,
# and tests/sqlite.ini (+ the flag in tests/sqlite.ini.tmpl) with the
# unsafe-root flag, so this script only has to:
#   1. Make the env the harness inherits the right shape (build tags, CGO,
#      toolchain on PATH, GITEA_TEST_CONF).
#   2. Re-materialise the INI config if an agent's `git clean -fdx` erased it.
#   3. Install nothing from the network on the happy path (offline-first):
#      every Go dependency is already in the module cache, so the agent
#      phase (no-network) and the verifier phase both resolve offline.
#
# Sourced (not exec'd) so the environment we export sticks for the runner.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/gitea}"
cd "$REPO_DIR"

# The repo's default unit-test sqlite driver is the pure-Go modernc build
# (models/db/driver_sqlite_modernc.go, `//go:build !sqlite_mattn`), so no
# cgo and no build tags are needed for `go test`. Keep CGO off to match the
# image. GOEXPERIMENT must match the image's baked build cache selection.
export CGO_ENABLED=0
export GOEXPERIMENT=jsonv2
export GOTOOLCHAIN=local

# Offline-first: the module cache is baked at the base commit (go mod download
# in the image) and the oracle introduces no new module dependency, so the
# agent phase (no-network) resolves everything locally. GOFLAGS=-mod=mod lets
# `go test` use the cache without a network-touching `-mod=readonly` download;
# GOPROXY=off makes any accidental fetch fail loudly instead of hanging.
export GOFLAGS="${GOFLAGS:-} -mod=mod"
export GOPROXY=off

# unittest.MainTest and migrationtest.MainTest both call
# setting.SetupGiteaTestEnv, which strips GITEA_* env vars before the
# run-as-root check — so I_AM_BEING_UNSAFE_RUNNING_AS_ROOT must come from the
# INI. Point the unit-test path at the baked config.
export GITEA_TEST_CONF=tests/sqlite.ini

# Make `go test` find the toolchain even when the harness scrubs PATH.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

# Re-materialise the INI config if an agent's edits blew it away (defensive:
# the image build creates both, but `git clean -fdx` would erase the
# gitignored tests/*.ini). The migration bootstrap regenerates
# tests/sqlite.ini from the template on every run, so the flag MUST be in the
# template; the unit path reads the generated INI directly, so refresh that too.
if ! grep -q '^I_AM_BEING_UNSAFE_RUNNING_AS_ROOT' tests/sqlite.ini.tmpl; then
    sed -i '1a I_AM_BEING_UNSAFE_RUNNING_AS_ROOT = true' tests/sqlite.ini.tmpl
fi
if [[ ! -f tests/sqlite.ini ]] || ! grep -q '^I_AM_BEING_UNSAFE_RUNNING_AS_ROOT' tests/sqlite.ini; then
    sed -e 's|{{TEST_WORK_PATH}}|/repo/gitea/tests/integration/gitea-integration-sqlite|g' \
        -e 's|{{GITEA_TEST_ROOT}}|/repo/gitea|g' \
        -e 's|{{TEST_LOGGER}}|test,file|g' \
        tests/sqlite.ini.tmpl > tests/sqlite.ini
    if ! grep -q '^I_AM_BEING_UNSAFE_RUNNING_AS_ROOT' tests/sqlite.ini; then
        sed -i '1a I_AM_BEING_UNSAFE_RUNNING_AS_ROOT = true' tests/sqlite.ini
    fi
fi

echo "test-setup.sh: ready (CGO_ENABLED=$CGO_ENABLED, GOPROXY=$GOPROXY, GITEA_TEST_CONF=$GITEA_TEST_CONF)"
