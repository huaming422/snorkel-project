## Task

our release dates are wrong in a few related ways.

a release published off an already-existing tag or commit gets stamped with that commit's date as its publication time rather than when it went out, so one published today off an old tag reads months old. those two dates are distinct and should be tracked and reported separately. a draft that was never published still carries a publication time; it should have none, reported as absent by the API. "latest release" should be whichever points at the newest commit, but publishing one on an old commit wrongly takes that spot from a release on a newer commit. and a tag made in the web UI is dated differently from the same tag pushed from the command line; both should follow their commit.

this isn't a one-layer fix: the conflation runs from storage through read-back and serving, so expect to touch the data model, existing rows, tag reading, release logic, and the API, UI, and feeds. already-published releases must keep their publication time afterward, drafts none.

dig in and fix it.
