#!/bin/bash
# Setup for public collection interoperability checks.
#
# The verifier is a shell runner that compiles two C# xUnit classes into the
# pre-existing Jint.Tests.PublicInterface project and runs them with
# `dotnet test`. Everything it needs is baked into the image at build time:
# the NuGet dependency closure is already restored under /opt/nuget/packages
# and the net10.0 test assembly is pre-built, so this phase installs nothing.
# Dependencies must already be installed; there is no network install fallback.
#
# This script only exports the environment the verifier's `dotnet` invocations
# rely on and points NuGet at the warm, offline package cache.

set -euo pipefail

REPO_DIR="/repo/jint"

export REPO_NAME=jint

# dotnet / NuGet: use the pre-warmed offline package cache baked at build time
# and keep the CLI quiet and non-interactive.
export NUGET_PACKAGES=/opt/nuget/packages
export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1

cd "$REPO_DIR"
