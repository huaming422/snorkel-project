// @ts-nocheck
//
// Behavioral verifier for the "configurable service install" feature.
//
// Everything is driven through the package's pre-existing, stable public entry
// point `handleService(args, { entryScript, runner })`, the same interface the
// CLI dispatches `service install | uninstall | status` to, and the same one
// the package's own tests exercise. We assert only on observable effects: the
// injected command `runner`'s calls, the mocked filesystem writes, the process
// exit code, and the text `service status` prints. No implementation-internal
// helper, type, or field name is imported, so every valid implementation shape (a
// shared config type or inlined parsing; command-only, env-only, or both
// persistence channels; any serialization that round-trips) passes.
//
// Guards:
//   - lan_requires_mdns (linux and win32): a LAN install is refused before any
//     service definition is written when mDNS publishing is unsupported.
//     Directory creation and read-only manager queries are allowed.
//   - stop_old_and_new_port: changing the service port stops the proxy running
//     on the old port, not only the new one, on linux, darwin, and win32. The
//     old port is seeded through both a live-state probe and a prior service
//     file, so either discovery mechanism satisfies the guard.
//   - bakes_config_into_service_file: non-default port, TLS, TLD, wildcard, and
//     state directory are persisted into a channel the service boots from
//     (command arguments and/or service environment, including a systemd
//     EnvironmentFile the unit references). A status-only sidecar is not enough.
//     The state directory counts only as PORTLESS_STATE_DIR.
//   - status_reads_config_from_service_file: status reports the installed
//     configuration after the install-time PORTLESS_* env is cleared, even when
//     the status shell sets a conflicting PORTLESS_TLD. Status runs from a
//     freshly loaded service module so a process-lifetime cache cannot stand
//     in for the installed file. Those same values are present in the boot
//     channel.
//   - platform_boot_survives_cleared_env: darwin launchd and Windows scheduled-
//     task installs persist port, TLS, wildcard, TLD, and state directory into
//     the platform boot artifact. A freshly loaded status module reports the
//     installed TLS mode, wildcard, port, TLD, and state directory when ambient
//     PORTLESS_TLD and PORTLESS_STATE_DIR disagree.
//   - env_modes_reach_boot: PORTLESS_* mode variables (no matching flags) reach
//     the boot channel on linux, darwin, and win32.
//   - http_off_defaults_port_80: HTTPS off (`--no-tls` or PORTLESS_HTTPS=0)
//     with no port uses 80, the HTTP default from proxy start.
//   - https_flag_beats_env: `--https` beats PORTLESS_HTTPS=0. With no port
//     chosen, the boot channel uses 443 on linux, darwin, and win32.
//   - explicit_lan_reaches_boot: `--lan` and `--ip` (not only the environment)
//     reach the boot channel on darwin and win32 when mDNS publishing is
//     supported, and status reports that LAN mode and IP.
//   - env_lan_reaches_boot: LAN mode and a pinned IP from the environment reach
//     the boot channel where mDNS is supported (linux and darwin).
//   - env_lan_rejected_without_mdns: a Windows PORTLESS_LAN install is refused
//     when mDNS is unsupported, and no service definition is written.
//   - cert_pair_reaches_boot: a readable matching PEM pair is consumed and the
//     paths are written as --cert and --key on the boot command (linux, darwin,
//     and win32).
//   - default_install_443: a plain `service install` still boots HTTPS on 443
//     with the localhost TLD and status still reports 443. Omitting `--https`
//     is still HTTPS: the proxy default is on unless an off signal is present.
//   - invalid_install_rejected: a certificate without its key, a key without
//     its certificate, an out-of-range port (70000 or 0), or a malformed TLD
//     (the --tld flag or PORTLESS_TLD alone) is refused on linux, darwin, and
//     win32 before a service definition is written.
//   - service registration: a successful install persistently registers the
//     installed artifact (systemctl enable of portless.service, launchctl
//     bootstrap/load/enable of the launchd plist or its label, or schtasks
//     /Create of the installed task). A one-time start does not. A refused
//     install still must not enable, start, or create the service.
//
// The node:fs / certs / utils / mdns / cli-utils mocks mirror the package's own
// service.test.ts: filesystem effects and the mDNS/discovery collaborators are
// stubbed so the install path is observable without touching the real OS.

import os from "node:os";
import path from "node:path";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { handleService } from "./service.js";

vi.mock("node:fs", async (importOriginal) => {
  const mod = await importOriginal<typeof import("node:fs")>();
  return {
    ...mod,
    chmodSync: vi.fn(),
    existsSync: vi.fn(mod.existsSync),
    mkdirSync: vi.fn(),
    readFileSync: vi.fn(mod.readFileSync),
    rmSync: vi.fn(),
    writeFileSync: vi.fn(),
  };
});

vi.mock("./certs.js", () => ({
  ensureCerts: vi.fn(() => ({
    certPath: "/fake/server.pem",
    keyPath: "/fake/server-key.pem",
    caPath: "/fake/ca.pem",
    caGenerated: false,
  })),
  isCATrusted: vi.fn(() => true),
  trustCA: vi.fn(() => ({ trusted: true })),
}));

vi.mock("./utils.js", () => ({
  fixOwnership: vi.fn(),
}));

vi.mock("./mdns.js", () => ({
  isMdnsSupported: vi.fn(() => ({ supported: true })),
}));

vi.mock("./cli-utils.js", async (importOriginal) => {
  const mod = await importOriginal<typeof import("./cli-utils.js")>();
  return {
    ...mod,
    discoverState: vi.fn(mod.discoverState),
    isProxyRunning: vi.fn(mod.isProxyRunning),
  };
});

const { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } = await import("node:fs");
const { isMdnsSupported } = await import("./mdns.js");
const { discoverState, isProxyRunning } = await import("./cli-utils.js");
const actualCliUtils = await vi.importActual<typeof import("./cli-utils.js")>("./cli-utils.js");
const actualFs = await vi.importActual<typeof import("node:fs")>("node:fs");

// Paths the package already uses for the three service definitions. Assertions
// read whichever boot channel an implementation writes: command arguments,
// inline environment, or a systemd EnvironmentFile the unit actually references.
const LINUX_UNIT = "/etc/systemd/system/portless.service";
const DARWIN_PLIST = "/Library/LaunchDaemons/sh.portless.proxy.plist";

const PORTLESS_ENV_KEYS = [
  "PORTLESS_STATE_DIR",
  "PORTLESS_PORT",
  "PORTLESS_HTTPS",
  "PORTLESS_LAN",
  "PORTLESS_LAN_IP",
  "PORTLESS_TLD",
  "PORTLESS_WILDCARD",
  "PORTLESS_CERT",
  "PORTLESS_KEY",
];

type BootChannel = { command: string[]; env: Record<string, string> };

function shellTokens(raw: string): string[] {
  const argv = raw.match(/"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|\S+/g) ?? [];
  return argv.map((token) => token.replace(/^["']|["']$/g, "").replace(/\\(.)/g, "$1"));
}

// cmd.exe splits on whitespace and treats `"` as quoting. A backslash is a
// path separator, not an escape, so tokens keep every `\`.
function cmdTokens(raw: string): string[] {
  const words: string[] = [];
  let current = "";
  let inQuote = false;
  let inWord = false;
  for (let i = 0; i < raw.length; i += 1) {
    const char = raw[i];
    if (char === '"') {
      inQuote = !inQuote;
      inWord = true;
      continue;
    }
    if (!inQuote && /\s/.test(char)) {
      if (inWord) {
        words.push(current);
        current = "";
        inWord = false;
      }
      continue;
    }
    current += char;
    inWord = true;
  }
  if (inWord) words.push(current);
  return words;
}

function xmlUnescape(value: string): string {
  return value
    .replace(/&apos;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/&gt;/g, ">")
    .replace(/&lt;/g, "<")
    .replace(/&amp;/g, "&");
}

function writtenText(predicate: (file: string) => boolean): string | undefined {
  const calls = vi.mocked(writeFileSync).mock.calls.filter(([file]) => predicate(String(file)));
  const call = calls[calls.length - 1];
  return call ? String(call[1]) : undefined;
}

function unquoteEnvValue(value: string): string {
  const trimmed = value.trim();
  if (
    (trimmed.startsWith('"') && trimmed.endsWith('"')) ||
    (trimmed.startsWith("'") && trimmed.endsWith("'"))
  ) {
    return shellTokens(trimmed)[0] ?? trimmed.slice(1, -1);
  }
  return trimmed;
}

function assignEnv(env: Record<string, string>, body: string, override: boolean): void {
  for (const raw of body.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith("#") || line.startsWith(";")) continue;
    const eq = line.indexOf("=");
    if (eq <= 0) continue;
    const key = line.slice(0, eq).trim();
    const value = unquoteEnvValue(line.slice(eq + 1));
    if (override || env[key] === undefined) env[key] = value;
  }
}

// systemd Environment= is a whitespace-separated list of shell assignments.
// KEY="value" and "KEY=value" are both valid, and one directive may carry
// several quoted assignments. Unquote each word before splitting on "=" so a
// quoted whole assignment is not stored under a key that still contains a quote.
function systemdAssignmentWords(body: string): string[] {
  const words: string[] = [];
  let current = "";
  let inWord = false;
  let quote: '"' | "'" | null = null;
  for (let i = 0; i < body.length; i += 1) {
    const char = body[i];
    if (quote === '"') {
      if (char === "\\" && i + 1 < body.length) {
        current += body[i + 1];
        i += 1;
        inWord = true;
        continue;
      }
      if (char === '"') {
        quote = null;
        inWord = true;
        continue;
      }
      current += char;
      inWord = true;
      continue;
    }
    if (quote === "'") {
      if (char === "'") {
        quote = null;
        inWord = true;
        continue;
      }
      current += char;
      inWord = true;
      continue;
    }
    if (char === '"' || char === "'") {
      quote = char;
      inWord = true;
      continue;
    }
    if (char === "\\" && i + 1 < body.length) {
      current += body[i + 1];
      i += 1;
      inWord = true;
      continue;
    }
    if (/\s/.test(char)) {
      if (inWord) {
        words.push(current);
        current = "";
        inWord = false;
      }
      continue;
    }
    current += char;
    inWord = true;
  }
  if (inWord) words.push(current);
  return words;
}

function assignSystemdEnvironment(env: Record<string, string>, body: string): void {
  for (const word of systemdAssignmentWords(body)) {
    const eq = word.indexOf("=");
    if (eq <= 0) continue;
    env[word.slice(0, eq)] = word.slice(eq + 1);
  }
}

// systemd allows whitespace around "=". Longer names are matched before
// Environment so EnvironmentFile and UnsetEnvironment are not split.
function normalizeSystemdAssignment(line: string): string {
  return line
    .trim()
    .replace(/^(ExecStart|EnvironmentFile|UnsetEnvironment|Environment)\s*=\s*/, "$1=");
}

function linuxBoot(): BootChannel {
  const unit = writtenText((file) => file === LINUX_UNIT);
  expect(unit).toBeDefined();
  const text = unit as string;
  // Effective ExecStart after empty-list resets, including backslash
  // continuations and whitespace around "=". Same body as the foreground check.
  const command = shellTokens(execStartBody(text));
  const env: Record<string, string> = {};
  // systemd.exec(5) uses three layers on logical lines, not source order.
  // Non-empty Environment= assignments accumulate first. An empty Environment=
  // clears only that inline layer. EnvironmentFile= is applied afterward, so a
  // referenced file overrides inline keys no matter which directive came first.
  // Later files win, and an empty EnvironmentFile= drops the file list so far.
  // A path without a leading "-" is required: a missing body fails the unit.
  // UnsetEnvironment= runs last. A bare KEY is always removed. KEY=value
  // removes KEY only when the current value matches exactly, after the same
  // unquoting the assignment splitter already applied. An empty
  // UnsetEnvironment= drops that list.
  const envFiles: string[] = [];
  const unsets: string[] = [];
  for (const line of unfoldSystemdLogicalLines(text).map(normalizeSystemdAssignment)) {
    if (line === "Environment=") {
      for (const key of Object.keys(env)) delete env[key];
      continue;
    }
    if (line.startsWith("Environment=")) {
      assignSystemdEnvironment(env, line.slice("Environment=".length));
      continue;
    }
    if (line === "EnvironmentFile=") {
      envFiles.length = 0;
      continue;
    }
    if (line.startsWith("EnvironmentFile=")) {
      for (const word of systemdAssignmentWords(line.slice("EnvironmentFile=".length))) {
        if (word) envFiles.push(word);
      }
      continue;
    }
    if (line === "UnsetEnvironment=") {
      unsets.length = 0;
      continue;
    }
    if (!line.startsWith("UnsetEnvironment=")) continue;
    for (const word of systemdAssignmentWords(line.slice("UnsetEnvironment=".length))) {
      if (word) unsets.push(word);
    }
  }
  for (const path of envFiles) {
    const optional = path.startsWith("-");
    const file = optional ? path.slice(1) : path;
    const body = writtenText((candidate) => candidate === file);
    // Empty files are present and add nothing. Only a missing required file
    // fails; EnvironmentFile=-/path stays optional when the body was not written.
    if (body === undefined) {
      if (!optional) expect(body).toBeDefined();
      continue;
    }
    assignEnv(env, body, true);
  }
  for (const item of unsets) {
    const eq = item.indexOf("=");
    if (eq < 0) {
      if (item) delete env[item];
      continue;
    }
    if (eq === 0) continue;
    const name = item.slice(0, eq);
    const value = unquoteEnvValue(item.slice(eq + 1));
    if (name && env[name] === value) delete env[name];
  }
  // Omitted Type defaults to simple and tracks ExecStart. Type=exec, Type=idle,
  // and notify-class types track that same process, including a shell wrapper.
  // The CLI detaches unless --foreground is present or the wrapper stays alive.
  // Type=forking and a BusName unit use a different lifecycle.
  expectSimpleUnitForeground(text, command);
  return { command, env };
}

function systemdServiceType(unit: string): string | undefined {
  let found: string | undefined;
  // Same logical lines as ExecStart. `Type=\` followed by `oneshot` is oneshot
  // before cardinality and lifetime rules run. Forking and dbus stay exempt.
  for (const raw of unfoldSystemdLogicalLines(unit)) {
    const match = raw.trim().match(/^Type\s*=\s*(\S+)/);
    if (match) found = match[1].toLowerCase();
  }
  return found;
}

function isFullLineComment(raw: string): boolean {
  const trimmed = raw.trim();
  return trimmed.startsWith("#") || trimmed.startsWith(";");
}

// A physical line ending in `\` continues onto the next fragment. A full-line
// `#` or `;` comment, or a blank line, between fragments is not part of the
// command and does not end the pending line. A `#` later in a fragment stays
// in that fragment. A `#` or `;` line outside a continuation is left as its
// own line, so it is not an ExecStart assignment. ExecStart and the
// environment directives share this join.
function unfoldSystemdLogicalLines(text: string): string[] {
  const lines = text.split(/\r?\n/);
  const logical: string[] = [];
  for (let i = 0; i < lines.length; i += 1) {
    const start = lines[i] ?? "";
    if (isFullLineComment(start)) {
      logical.push(start);
      continue;
    }
    if (!start.trimEnd().endsWith("\\")) {
      logical.push(start);
      continue;
    }
    const parts: string[] = [];
    let j = i;
    while (j < lines.length) {
      const raw = lines[j] ?? "";
      if (j > i && (isFullLineComment(raw) || raw.trim() === "")) {
        j += 1;
        continue;
      }
      parts.push(raw.trim().replace(/\\$/, ""));
      if (!raw.trimEnd().endsWith("\\")) break;
      j += 1;
    }
    logical.push(parts.join(" "));
    i = j;
  }
  return logical;
}

// systemd.service(5): an empty ExecStart= clears the command list; each later
// nonempty assignment appends. Only Type=oneshot may list several commands.
// simple, exec, idle, notify, notify-reload, forking, dbus, and an omitted
// Type (with or without BusName) each have exactly one effective command.
// Forking and dbus still skip the foreground check; that lifetime exception
// is separate from this list. Continuations are already one logical line.
function execStartCommands(unit: string): string[] {
  const commands: string[] = [];
  for (const raw of unfoldSystemdLogicalLines(unit)) {
    const line = raw.trim();
    if (!/^ExecStart\s*=/.test(line)) continue;
    const body = line.replace(/^ExecStart\s*=\s*/, "");
    if (!body) commands.length = 0;
    else commands.push(body);
  }
  return commands;
}

function unitTracksSingleExecStart(unit: string): boolean {
  return systemdServiceType(unit) !== "oneshot";
}

function commandMentionsProxyStart(body: string): boolean {
  const tokens = shellTokens(body);
  for (let i = 0; i < tokens.length - 1; i += 1) {
    if (tokens[i] === "proxy" && tokens[i + 1] === "start") return true;
  }
  return false;
}

// A oneshot list runs in order and stops at the first failure that is not
// ignored. A leading "-" (optional following space) is that prefix, so
// `-/bin/false` and `- /bin/false` still reach a later command. `/bin/true`
// and `true` succeed. A bare `/bin/false` or `false` aborts before the proxy.
// So does `sh -c false` and `sh -c 'exit 1'` (also `-lc`). A shell script that
// itself runs `proxy start` is not a failed prerequisite.
function inlineShellScript(tokens: string[]): string | undefined {
  if (!SHELL_ARGV0.has(argv0Base(tokens[0] ?? ""))) return undefined;
  let index = 1;
  while (index < tokens.length && (tokens[index] ?? "").startsWith("-")) {
    const flag = tokens[index] ?? "";
    index += 1;
    if (flag === "-c" || flag === "-lc") return tokens[index] ?? "";
  }
  return undefined;
}

function oneshotPrerequisiteAborts(body: string): boolean {
  const trimmed = body.trim();
  if (!trimmed || trimmed.startsWith("-")) return false;
  const tokens = shellTokens(trimmed);
  if (argv0Base(tokens[0] ?? "") === "false") return true;
  const script = inlineShellScript(tokens);
  if (script === undefined) return false;
  if (commandMentionsProxyStart(shellTokens(script))) return false;
  return /^(?:false|exit(?:\s+\d+)?)$/.test(script.trim());
}

function execStartBody(unit: string): string {
  const commands = execStartCommands(unit);
  if (unitTracksSingleExecStart(unit)) {
    expect(commands.length).toBe(1);
    return commands[0] ?? "";
  }
  // A multi-command oneshot is a boot channel when one command is the proxy
  // and every earlier command can still reach it.
  for (let i = commands.length - 1; i >= 0; i -= 1) {
    const body = commands[i] ?? "";
    if (!commandMentionsProxyStart(body)) continue;
    for (let prior = 0; prior < i; prior += 1) {
      expect(oneshotPrerequisiteAborts(commands[prior] ?? "")).toBe(false);
    }
    return body;
  }
  return commands.length > 0 ? (commands[commands.length - 1] ?? "") : "";
}

const SHELL_ARGV0 = new Set(["sh", "bash", "dash", "zsh", "ksh", "busybox"]);

function argv0Base(token: string): string {
  const bare = token.replace(/^["']|["']$/g, "");
  const slash = Math.max(bare.lastIndexOf("/"), bare.lastIndexOf("\\"));
  return (slash >= 0 ? bare.slice(slash + 1) : bare).toLowerCase();
}

// A direct ExecStart is `… proxy start` itself. A shell wrapper is a
// different process the manager can track.
function isDirectProxyExec(command: string[], unit: string): boolean {
  const tokens = command.length > 0 ? command : shellTokens(execStartBody(unit));
  if (tokens.length < 2) return false;
  if (SHELL_ARGV0.has(argv0Base(tokens[0] ?? ""))) return false;
  for (let i = 0; i < tokens.length - 1; i += 1) {
    if (tokens[i] === "proxy" && tokens[i + 1] === "start") return true;
  }
  return false;
}

function unitHasBusName(unit: string): boolean {
  return unit.split(/\r?\n/).some((raw) => /^BusName\s*=\s*\S/.test(raw.trim()));
}

// A Type=simple shell wrapper stays up when it runs the proxy args and then
// keeps a process in the cgroup. `exec "$@"` alone still daemonizes with the CLI.
function scriptKeepsAliveAfterArgs(body: string): boolean {
  const marker = body.match(/"\$@"|'\$@'|\$@/);
  if (!marker || marker.index === undefined) return false;
  const before = body.slice(0, marker.index);
  if (/(?:^|[\n;&|])\s*exec\s+$/.test(before)) return false;
  const after = body.slice(marker.index + marker[0].length);
  const bin = "(?:\\S*/)?";
  const tail = new RegExp(
    `(?:^|[\\n;&|])\\s*(?:exec\\s+)?${bin}tail\\b[^\\n;&|]*?(?:-[fF]\\b|--follow\\b)`
  );
  const sleep = new RegExp(`(?:^|[\\n;&|])\\s*(?:exec\\s+)?${bin}sleep\\s+(?:infinity|inf)\\b`);
  const loop = /(?:^|[\n;&|])\s*while\s+(?:true|:)\b/;
  return tail.test(after) || sleep.test(after) || loop.test(after);
}

function isSustainedShellWrapper(command: string[], unit: string): boolean {
  const tokens = command.length > 0 ? command : shellTokens(execStartBody(unit));
  if (!SHELL_ARGV0.has(argv0Base(tokens[0] ?? ""))) return false;
  let index = 1;
  while (index < tokens.length && (tokens[index] ?? "").startsWith("-")) {
    const flag = tokens[index] ?? "";
    index += 1;
    // `sh -c '…'` and `sh -lc '…'` carry the script in the next argv token.
    if (flag === "-c" || flag === "-lc") return scriptKeepsAliveAfterArgs(tokens[index] ?? "");
  }
  const scriptPath = (tokens[index] ?? "").replace(/^["']|["']$/g, "");
  if (!scriptPath || scriptPath.startsWith("-")) return false;
  const want = scriptPath.replace(/\\/g, "/");
  const script = writtenText((file) => file.replace(/\\/g, "/") === want);
  if (script === undefined) return false;
  return scriptKeepsAliveAfterArgs(script);
}

// Require --foreground unless the unit is clearly not tracking the proxy
// process: Type=forking, Type=dbus, or an omitted Type with BusName (systemd
// then defaults to dbus). A missing Type with no BusName is simple.
// Type=simple, Type=exec, Type=idle, and notify-class types (notify,
// notify-reload) track ExecStart. A shell ExecStart is exempt only when its
// script runs "$@" and then stays alive. The script may be a written file or
// the inline body of `sh -c` / `sh -lc`. A direct proxy launch, and a wrapper
// that only execs a daemonizing CLI, still need --foreground. Any other type
// needs the flag when ExecStart is the proxy itself.
function unitRequiresForeground(unit: string, command: string[]): boolean {
  const type = systemdServiceType(unit);
  if (type === "forking" || type === "dbus") return false;
  if (type === undefined && unitHasBusName(unit)) return false;
  if (
    type === undefined ||
    type === "simple" ||
    type === "exec" ||
    type === "idle" ||
    type === "notify" ||
    type === "notify-reload"
  ) {
    return !isSustainedShellWrapper(command, unit);
  }
  return isDirectProxyExec(command, unit);
}

function expectSimpleUnitForeground(unit: string, command: string[]): void {
  if (!unitRequiresForeground(unit, command)) return;
  const foreground =
    command.some((token) => token.includes("--foreground")) ||
    execStartBody(unit).includes("--foreground");
  expect(foreground).toBe(true);
}

function darwinBoot(): BootChannel {
  const plist = writtenText((file) => file === DARWIN_PLIST);
  expect(plist).toBeDefined();
  const text = plist as string;
  const argsBlock = text.match(/<key>ProgramArguments<\/key>\s*<array>([\s\S]*?)<\/array>/);
  const command = argsBlock
    ? [...argsBlock[1].matchAll(/<string>([\s\S]*?)<\/string>/g)].map((match) => xmlUnescape(match[1]))
    : [];
  const env: Record<string, string> = {};
  const envBlock = text.match(/<key>EnvironmentVariables<\/key>\s*<dict>([\s\S]*?)<\/dict>/);
  if (envBlock) {
    for (const match of envBlock[1].matchAll(/<key>([\s\S]*?)<\/key>\s*<string>([\s\S]*?)<\/string>/g)) {
      env[xmlUnescape(match[1])] = xmlUnescape(match[2]);
    }
  }
  return { command, env };
}

function isWindowsScriptPath(file: string): boolean {
  return file.replace(/\\/g, "/").endsWith("/portless-service.cmd");
}

// An unconditional `exit`, `exit /b`, `exit /b %errorlevel%`, or `@exit …`
// before any launch command stops the script, so a proxy written after it
// never runs. The same statement after a launch only returns that launch's
// status and does not clear the command or the environment captured there.
// `REM` / `::` lines (optional leading `@`) are comments. None of these is
// the proxy command line. `setlocal` pushes the current environment and
// `endlocal` restores it, so assignments between them are gone once the
// scope ends. The boot environment is the one in force on the launch line:
// a later `endlocal`, `REM`, or `exit` does not rewrite it.
function isWindowsExitEpilogue(statement: string): boolean {
  return /^exit(?:\s*\/b)?(?:\s+\S+)?$/i.test(statement.trim());
}

function isWindowsComment(statement: string): boolean {
  const line = statement.trim();
  if (/^rem(?:\s|$)/i.test(line)) return true;
  return line.startsWith("::");
}

function windowsBoot(): BootChannel {
  const script = writtenText((file) => isWindowsScriptPath(file));
  expect(script).toBeDefined();
  // cmd environment names are case-insensitive. Store the canonical uppercase
  // form so a later `set portless_state_dir=…` overrides `PORTLESS_STATE_DIR`
  // and a fully lowercase script still matches the PORTLESS_* lookups.
  // POSIX unit and plist keys stay case-sensitive.
  let env: Record<string, string> = {};
  const scopes: Record<string, string>[] = [];
  let command: string[] = [];
  let launchEnv: Record<string, string> = {};
  let launchSeen = false;
  for (const raw of (script as string).split(/\r?\n/)) {
    const line = raw.trim();
    if (!line) continue;
    // cmd.exe accepts `@set` to suppress echo. The optional @ is not part of
    // the assignment. Matching stays case-insensitive (`SET` and `set`).
    const assignment = line.startsWith("@") ? line.slice(1).trim() : line;
    if (!assignment || assignment.toLowerCase() === "echo off") continue;
    if (isWindowsExitEpilogue(assignment)) {
      if (!launchSeen) break;
      continue;
    }
    if (/^setlocal(?:\s|$)/i.test(assignment)) {
      scopes.push({ ...env });
      continue;
    }
    if (/^endlocal(?:\s|$)/i.test(assignment)) {
      env = scopes.pop() ?? env;
      continue;
    }
    if (isWindowsComment(assignment)) continue;
    const quoted = assignment.match(/^set\s+"([^=]+)=(.*)"$/i);
    const plain = assignment.match(/^set\s+([^=\s]+)=(.*)$/i);
    const match = quoted ?? plain;
    if (match && assignment.toLowerCase().startsWith("set ")) {
      env[match[1].toUpperCase()] = match[2].replace(/%%/g, "%").replace(/^"(.*)"$/, "$1");
      continue;
    }
    command = cmdTokens(line);
    launchEnv = { ...env };
    launchSeen = true;
  }
  return { command, env: launchEnv };
}

function bootFor(platform: "linux" | "darwin" | "win32"): BootChannel {
  if (platform === "linux") return linuxBoot();
  if (platform === "darwin") return darwinBoot();
  return windowsBoot();
}

function flagValue(command: string[], name: string): string | undefined {
  const index = command.indexOf(name);
  if (index < 0) return undefined;
  return command[index + 1];
}

function bootPort(boot: BootChannel): string | undefined {
  return flagValue(boot.command, "--port") ?? flagValue(boot.command, "-p") ?? boot.env.PORTLESS_PORT;
}

function bootTld(boot: BootChannel): string {
  return flagValue(boot.command, "--tld") ?? boot.env.PORTLESS_TLD ?? "localhost";
}

function bootStateDir(boot: BootChannel): string | undefined {
  // `proxy start` reads the state directory only from PORTLESS_STATE_DIR.
  return boot.env.PORTLESS_STATE_DIR;
}

function bootLanIp(boot: BootChannel): string | undefined {
  return flagValue(boot.command, "--ip") ?? boot.env.PORTLESS_LAN_IP;
}

function bootCert(boot: BootChannel): string | undefined {
  // `proxy start` reads the certificate only from the --cert command flag.
  return flagValue(boot.command, "--cert");
}

function bootKey(boot: BootChannel): string | undefined {
  // `proxy start` reads the private key only from the --key command flag.
  return flagValue(boot.command, "--key");
}

// Windows path strings may use `\` and an optional drive letter. POSIX
// `path.resolve` and `path.win32.resolve` are both acceptable on win32.
function canonicalServicePath(value: string): string {
  const slashed = value.replace(/\\/g, "/").replace(/^[A-Za-z]:/, "");
  const collapsed = slashed.replace(/\/+/g, "/");
  return collapsed.length > 1 && collapsed.endsWith("/") ? collapsed.slice(0, -1) : collapsed;
}

function expectWin32CompatiblePath(actual: string | undefined, expected: string): void {
  expect(actual).toBeTruthy();
  const got = canonicalServicePath(String(actual));
  const accepted = [expected, path.resolve(expected), path.win32.resolve(expected)].map(canonicalServicePath);
  expect(accepted).toContain(got);
}

function expectStatusHasPath(output: string, expected: string): void {
  const folded = output.replace(/\\/g, "/");
  const variants = [expected, path.resolve(expected), path.win32.resolve(expected)];
  const hit = variants.some((variant) => {
    if (output.includes(variant)) return true;
    const slashed = canonicalServicePath(variant);
    return slashed.length > 1 && folded.includes(slashed);
  });
  expect(hit).toBe(true);
}

function commandDisablesHttps(boot: BootChannel): boolean {
  return boot.command.includes("--no-tls");
}

function envDisablesHttps(boot: BootChannel): boolean {
  return boot.env.PORTLESS_HTTPS === "0" || boot.env.PORTLESS_HTTPS === "false";
}

// Read the baked boot artifact the way the booted proxy will. HTTPS is off when
// the command includes `--no-tls` or the service environment sets
// PORTLESS_HTTPS=0/false. A `--https` token on that command is not an on signal
// by itself. Install-time resolution is separate: `service install --https` has
// to bake an on result, with no off signal, even when the install shell had
// PORTLESS_HTTPS=0. With no off signal, HTTPS is on even when the boot command
// omits `--https` and the environment omits PORTLESS_HTTPS.
function expectBootHttps(boot: BootChannel, enabled: boolean): void {
  const off = commandDisablesHttps(boot) || envDisablesHttps(boot);
  expect(off).toBe(!enabled);
}

// Status text is free-form. Pipes become spaces so a table cell (`| HTTPS | no |`)
// stays visible. A scheme (`http://` / `https://`) outranks the word "on".
// When several polarity words appear, the first one after the label wins, and
// "on" before a port is a preposition so it does not cancel "no"/"off". A bare
// `http` / `https` token (`Mode: http`, `Proxy on 80 (HTTP)`) is a mode signal,
// and a polarity word immediately before the label (`disabled HTTPS`) counts.
// `*` next to a wildcard label means on. A LAN line is on when it carries the
// installed IP, "auto", or any other non-off value.
const STATUS_AFFIRM = new Set(["yes", "on", "true", "enabled"]);
const STATUS_NEGATE = new Set(["no", "off", "false", "disabled"]);

function normalizeStatusLine(line: string): string {
  return line.replace(/\|/g, " ").replace(/[ \t]+/g, " ").trim();
}

function isPrepositionOn(text: string, index: number): boolean {
  return /^on\s+(?:port\b|\d+)/i.test(text.slice(index));
}

function polarityTokens(text: string): Array<{ index: number; word: string; affirmative: boolean }> {
  const found: Array<{ index: number; word: string; affirmative: boolean }> = [];
  for (const match of text.matchAll(/\b(yes|no|on|off|true|false|enabled|disabled)\b/gi)) {
    const word = match[1].toLowerCase();
    const index = match.index ?? 0;
    if (word === "on" && isPrepositionOn(text, index)) continue;
    found.push({ index, word, affirmative: STATUS_AFFIRM.has(word) });
  }
  return found;
}

function wordImmediatelyBefore(text: string, index: number): string | null {
  const prefix = text.slice(0, index).trim();
  if (!prefix) return null;
  const raw = prefix.split(/\s+/).pop() ?? "";
  const word = raw.replace(/[^a-z]/gi, "").toLowerCase();
  return word || null;
}

function classifyStatusLine(line: string, label: RegExp, lanIp?: string): boolean | null {
  const text = normalizeStatusLine(line);
  const httpsMode = /https|tls/.test(label.source);
  const wildcardMode = /wildcard/.test(label.source);
  const lanMode = /lan/.test(label.source);

  label.lastIndex = 0;
  const labelMatch = label.exec(text);
  let anchor = labelMatch?.index ?? -1;
  let anchorEnd = labelMatch ? labelMatch.index + labelMatch[0].length : -1;
  let anchorIsBareHttp = false;

  if (!labelMatch && httpsMode) {
    const extra = /\b(protocol|scheme|url)\b|https?:\/\/|\bhttps?\b/i.exec(text);
    if (!extra) return null;
    anchor = extra.index;
    anchorEnd = extra.index + extra[0].length;
    anchorIsBareHttp = /^http$/i.test(extra[0]);
  } else if (!labelMatch) {
    return null;
  }

  if (httpsMode) {
    const httpsScheme = /https:\/\//i.test(text);
    const httpScheme = /http:\/\//i.test(text);
    if (httpsScheme !== httpScheme) return httpsScheme;
  }

  const after = polarityTokens(text).filter((token) => token.index >= anchorEnd);
  if (after.length > 0) {
    const first = after[0];
    // A bare "on" does not outrank an http token in the value ("HTTP on").
    if (
      httpsMode &&
      first.word === "on" &&
      /\bhttp\b/i.test(text.slice(anchorEnd)) &&
      !/\bhttps\b/i.test(text.slice(anchorEnd))
    ) {
      return false;
    }
    return first.affirmative;
  }

  const preceding = wordImmediatelyBefore(text, anchor);
  if (preceding && (STATUS_AFFIRM.has(preceding) || STATUS_NEGATE.has(preceding))) {
    const affirmative = STATUS_AFFIRM.has(preceding);
    // "on HTTP" is the protocol token, not an affirmative "on".
    if (!(affirmative && preceding === "on" && anchorIsBareHttp)) return affirmative;
  }

  if (httpsMode) {
    const region = text.slice(anchor);
    const hasHttps = /\bhttps\b/i.test(region);
    const hasHttp = /\bhttp\b/i.test(region);
    if (hasHttps !== hasHttp) return hasHttps;
    return null;
  }

  if (wildcardMode && text.slice(Math.max(0, anchor - 24), anchorEnd + 64).includes("*")) return true;

  if (lanMode) {
    if (lanIp && text.includes(lanIp)) return true;
    const around = text.slice(anchor, anchor + 64);
    if (/\bauto\b/i.test(around)) return true;
    const value = text.slice(anchor).split(":").slice(1).join(":").trim();
    if (!value || /^(mode|ip)$/i.test(value)) return null;
    if (/\b(no|off|false|disabled)\b/i.test(value)) return false;
    return true;
  }

  return null;
}

function expectStatusMode(output: string, label: RegExp, enabled: boolean, lanIp?: string): void {
  const hits = output
    .split(/\n/)
    .map((line) => classifyStatusLine(line, label, lanIp))
    .filter((value) => value !== null);
  expect(hits.length).toBeGreaterThan(0);
  expect(hits.every((value) => value === enabled)).toBe(true);
}

function expectBootWildcard(boot: BootChannel, enabled: boolean): void {
  const on =
    boot.command.includes("--wildcard") ||
    boot.env.PORTLESS_WILDCARD === "1" ||
    boot.env.PORTLESS_WILDCARD === "true";
  expect(on).toBe(enabled);
}

function expectBootLan(boot: BootChannel, enabled: boolean): void {
  const on =
    boot.command.includes("--lan") || boot.env.PORTLESS_LAN === "1" || boot.env.PORTLESS_LAN === "true";
  expect(on).toBe(enabled);
}

function installMemoryFs(): Map<string, string> {
  const store = new Map<string, string>();
  vi.mocked(writeFileSync).mockImplementation((p: unknown, data: unknown) => {
    store.set(String(p), String(data));
  });
  vi.mocked(readFileSync).mockImplementation(((p: unknown, ...rest: unknown[]) => {
    const key = String(p);
    if (store.has(key)) return store.get(key) as string;
    return (actualFs.readFileSync as (...a: unknown[]) => unknown)(p, ...rest);
  }) as typeof readFileSync);
  vi.mocked(existsSync).mockImplementation(((p: unknown) => {
    const key = String(p);
    if (store.has(key)) return true;
    return (actualFs.existsSync as (p: unknown) => boolean)(p);
  }) as typeof existsSync);
  return store;
}

// Status is a later process. Drop the module that performed install, keep the
// bytes it wrote, and call status on a newly loaded `./service.js`. Re-bind
// the filesystem and collaborator mocks first: resetModules can replace the
// mock functions, and the fresh module has to see the same installed files.
async function invokeColdStatus(store: Map<string, string>, runner: unknown): Promise<void> {
  const snapshot = new Map(store);
  vi.resetModules();

  const fsMod = await import("node:fs");
  vi.mocked(fsMod.writeFileSync).mockImplementation((p: unknown, data: unknown) => {
    const key = String(p);
    const text = String(data);
    snapshot.set(key, text);
    store.set(key, text);
  });
  vi.mocked(fsMod.readFileSync).mockImplementation(((p: unknown, ...rest: unknown[]) => {
    const key = String(p);
    if (snapshot.has(key)) return snapshot.get(key) as string;
    return (actualFs.readFileSync as (...a: unknown[]) => unknown)(p, ...rest);
  }) as typeof readFileSync);
  vi.mocked(fsMod.existsSync).mockImplementation(((p: unknown) => {
    if (snapshot.has(String(p))) return true;
    return (actualFs.existsSync as (p: unknown) => boolean)(p);
  }) as typeof existsSync);
  vi.mocked(fsMod.mkdirSync).mockImplementation(() => undefined);

  const mdns = await import("./mdns.js");
  vi.mocked(mdns.isMdnsSupported).mockReturnValue({ supported: true });

  const cli = await import("./cli-utils.js");
  vi.mocked(cli.discoverState).mockResolvedValue({
    dir: "/tmp/portless-service-cold-status",
    port: 443,
    tls: true,
    tld: "localhost",
    lanMode: false,
    lanIp: null,
  });
  vi.mocked(cli.isProxyRunning).mockResolvedValue(false);

  const service = await import("./service.js");
  await service.handleService(["service", "status"], {
    entryScript: "/fake/cli.js",
    runner,
  });
}

function isServiceDefinitionPath(file: string): boolean {
  const normalized = file.replace(/\\/g, "/");
  return (
    normalized === LINUX_UNIT ||
    normalized === DARWIN_PLIST ||
    normalized.endsWith("/portless-service.cmd")
  );
}

function expectNoServiceDefinitionWritten(): void {
  const written = vi.mocked(writeFileSync).mock.calls.map(([file]) => String(file));
  expect(written.filter((file) => isServiceDefinitionPath(file))).toEqual([]);
}

function isActivationRunnerCall(command: unknown, args: unknown): boolean {
  const base = String(command ?? "")
    .replace(/\\/g, "/")
    .toLowerCase()
    .split("/")
    .pop();
  const verbs = (Array.isArray(args) ? args : []).map((part) => String(part).toLowerCase());
  if (base === "systemctl") {
    return verbs.some((part) => part === "enable" || part === "start" || part === "restart");
  }
  if (base === "launchctl") {
    return verbs.some(
      (part) => part === "bootstrap" || part === "load" || part === "enable" || part === "kickstart" || part === "start"
    );
  }
  if (base === "schtasks" || base === "schtasks.exe") {
    return verbs.some((part) => part === "/create" || part === "/run");
  }
  return false;
}

function expectNoServiceActivation(runner: { mock: { calls: unknown[][] } }): void {
  const activations = runner.mock.calls.filter((call) => isActivationRunnerCall(call[0], call[1]));
  expect(activations).toEqual([]);
}

function registrationArg(part: string): string {
  return part.replace(/^["']+|["']+$/g, "").replace(/\\/g, "/").toLowerCase();
}

const LINUX_UNIT_NAME = LINUX_UNIT.slice(LINUX_UNIT.lastIndexOf("/") + 1);
const DARWIN_LABEL = DARWIN_PLIST.slice(DARWIN_PLIST.lastIndexOf("/") + 1).replace(/\.plist$/i, "");

function referencesLinuxUnit(args: string[]): boolean {
  const unitPath = LINUX_UNIT.toLowerCase();
  return args.some((raw) => {
    const norm = registrationArg(raw);
    return norm === LINUX_UNIT_NAME || norm === unitPath || norm.endsWith("/" + LINUX_UNIT_NAME);
  });
}

function referencesDarwinArtifact(args: string[]): boolean {
  const plist = DARWIN_PLIST.toLowerCase();
  const plistName = `${DARWIN_LABEL}.plist`;
  return args.some((raw) => {
    const norm = registrationArg(raw);
    if (norm === plist || norm === plistName || norm.endsWith("/" + plistName)) return true;
    return norm === DARWIN_LABEL || norm.endsWith("/" + DARWIN_LABEL);
  });
}

function writtenWindowsScriptPath(): string | undefined {
  const calls = vi.mocked(writeFileSync).mock.calls.filter(([file]) => isWindowsScriptPath(String(file)));
  const call = calls[calls.length - 1];
  return call ? String(call[0]) : undefined;
}

function schtasksRunActions(args: string[]): string[] {
  const actions: string[] = [];
  for (let i = 0; i < args.length; i += 1) {
    const part = args[i] ?? "";
    const lower = part.toLowerCase();
    if (lower === "/tr" || lower === "-tr") {
      const next = args[i + 1];
      if (next !== undefined) actions.push(next);
      continue;
    }
    if (lower.startsWith("/tr:") || lower.startsWith("-tr:")) actions.push(part.slice(part.indexOf(":") + 1));
  }
  return actions;
}

// `/TR` must run the script whose bytes were checked. A task name, or the
// basename in a different directory, does not. A wrapper may embed that path.
function actionReferencesScript(action: string, scriptPath: string): boolean {
  const want = registrationArg(scriptPath);
  if (!want) return false;
  const got = registrationArg(action);
  if (got === want) return true;
  const padded = ` ${got.replace(/["']/g, " ")} `;
  return padded.includes(` ${want} `);
}

function schtasksXmlPath(args: string[]): string | undefined {
  for (let i = 0; i < args.length; i += 1) {
    const part = args[i] ?? "";
    const lower = part.toLowerCase();
    if (lower === "/xml" || lower === "-xml") return args[i + 1];
    if (lower.startsWith("/xml:") || lower.startsWith("-xml:")) return part.slice(part.indexOf(":") + 1);
  }
  return undefined;
}

// schtasks /XML points at a task document. The Exec action's Command and
// Arguments are the process the task runs, the same role as /TR.
function taskXmlExecActions(body: string): string[] {
  const actions: string[] = [];
  for (const exec of body.matchAll(/<Exec\b[^>]*>([\s\S]*?)<\/Exec>/gi)) {
    const inner = exec[1] ?? "";
    const command = inner.match(/<Command>([\s\S]*?)<\/Command>/i)?.[1];
    if (!command) continue;
    const argv = inner.match(/<Arguments>([\s\S]*?)<\/Arguments>/i)?.[1] ?? "";
    const action = `${xmlUnescape(command)} ${xmlUnescape(argv)}`.trim();
    if (action) actions.push(action);
  }
  return actions;
}

function referencesWindowsArtifact(args: string[]): boolean {
  const scriptPath = writtenWindowsScriptPath();
  if (!scriptPath) return false;
  const actions = schtasksRunActions(args);
  const xmlPath = schtasksXmlPath(args);
  if (xmlPath) {
    const body = writtenText((file) => registrationArg(file) === registrationArg(xmlPath));
    if (body) actions.push(...taskXmlExecActions(body));
  }
  return actions.some((action) => actionReferencesScript(action, scriptPath));
}

// Persistent registration of the installed artifact. A one-time start, restart,
// kickstart, or schtasks /Run does not survive reboot. A verb aimed at a
// different unit, plist, or task does not register this service. On Windows the
// created task has to run the written portless-service.cmd, either as /TR or
// as the Exec action of the task XML passed to /XML.
function isPersistentRegistration(command: unknown, args: unknown): boolean {
  const base = String(command ?? "")
    .replace(/\\/g, "/")
    .toLowerCase()
    .split("/")
    .pop();
  const parts = (Array.isArray(args) ? args : []).map((part) => String(part));
  const verbs = parts.map((part) => part.toLowerCase());
  if (base === "systemctl") {
    return verbs.includes("enable") && referencesLinuxUnit(parts);
  }
  if (base === "launchctl") {
    const registers = verbs.some((part) => part === "bootstrap" || part === "load" || part === "enable");
    return registers && referencesDarwinArtifact(parts);
  }
  if (base === "schtasks" || base === "schtasks.exe") {
    return verbs.includes("/create") && referencesWindowsArtifact(parts);
  }
  return false;
}

function expectServiceActivation(runner: { mock: { calls: unknown[][] } }): void {
  const registrations = runner.mock.calls.filter((call) => isPersistentRegistration(call[0], call[1]));
  expect(registrations.length).toBeGreaterThan(0);
}

// Real matching self-signed pair. Install-time readers that require the files
// to exist and to be PEM (and that the key matches the cert) can load these
// through the memory filesystem. Generated once; not produced at runtime.
const MATCHING_CERT_PEM = `-----BEGIN CERTIFICATE-----
MIIDHzCCAgegAwIBAgIUKWGra6wWzdUwNNbPcXUa5Ah2RX4wDQYJKoZIhvcNAQEL
BQAwHzEdMBsGA1UEAwwUcG9ydGxlc3MtdmVyaWZ5LXRlc3QwHhcNMjYxMDI3MDUx
MjI5WhcNMzYxMDI0MDUxMjI5WjAfMR0wGwYDVQQDDBRwb3J0bGVzcy12ZXJpZnkt
dGVzdDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALuhW7uPmuvnhNdQ
1mExj0FXHAGUk6Qe+u780+uDMwnMc1+ht/mpfia3DDbW8vbZkd8R5sD6k7hgQ7RF
zs8A65W9fH8CiicsqzN7yd7Qz4l8u537gNOdqYUs1AnLooaNFOhw1saNkmrFA2CC
Tkp/YFCCQdFoD0paJRi/+lEE2U/LqzS+dS8V7gR84zNTpx5Y6YC4xtdCL1b3Hsrf
Y0xJZNhbD3Lh8n9rcqpdqyU64XKGAtJchxTiEcF7ZEcpYUl2TSVId3X9iJzRbX/K
JnfyTjkotDF572lNxMG86qXq8/HgkDF3JGLxgCfmU+1Sst1UPNbDVVj/l7FPZASD
4xQi5lsCAwEAAaNTMFEwHQYDVR0OBBYEFN4MvLskxKc6SAlpXE4MojLJT3BqMB8G
A1UdIwQYMBaAFN4MvLskxKc6SAlpXE4MojLJT3BqMA8GA1UdEwEB/wQFMAMBAf8w
DQYJKoZIhvcNAQELBQADggEBAGystwu/Opw2Zud7NFYWpSm3tq6pkeOF2bdOZz/e
F/N3dN0df28x+ZeNT6QdqjzBIjNrJGMlw+nhuyjtvzWgb6NCloCz4jfWcqRgPOVn
p0H00gROj4UXhco1mfyOR27XoztrzQpoRYVEJvRe4xPqxqe0hxcmKW+S42IqVa8K
98+qku9Ue7hdAUleL0e8sd4OFP74zq6UrirpCKu/yDAETA9b2QrmTFZcGRwGqqAC
ihTQ6K34qAzkZN0GSvrZUPOH30X61K8zi7UwP82+2r8gRJtJye9QLgTS6Wj2Jd2q
hL95uBt7ID+L36Nid02vY+gr2iSio3HyEBQosFv8gPRMEUM=
-----END CERTIFICATE-----
`;

const MATCHING_KEY_PEM = `-----BEGIN PRIVATE KEY-----
MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQC7oVu7j5rr54TX
UNZhMY9BVxwBlJOkHvru/NPrgzMJzHNfobf5qX4mtww21vL22ZHfEebA+pO4YEO0
Rc7PAOuVvXx/AoonLKsze8ne0M+JfLud+4DTnamFLNQJy6KGjRTocNbGjZJqxQNg
gk5Kf2BQgkHRaA9KWiUYv/pRBNlPy6s0vnUvFe4EfOMzU6ceWOmAuMbXQi9W9x7K
32NMSWTYWw9y4fJ/a3KqXaslOuFyhgLSXIcU4hHBe2RHKWFJdk0lSHd1/Yic0W1/
yiZ38k45KLQxee9pTcTBvOql6vPx4JAxdyRi8YAn5lPtUrLdVDzWw1VY/5exT2QE
g+MUIuZbAgMBAAECggEAAU5bNAI7d/garx8bPxvihXURUfHSXnDUuFyIfFJ+WZvj
8pdvcYpg4hC8YrFi7riEgUzt2CbE5N3vhARfrzLaDruzjUgJ1lzVOfjg+3Ogcb5o
6qwWl+/n8GFkxaBD30EiLfNWYwZ8TjZDN//d+c/fnfti4hy2xy9hwelKDtCrI7+d
mJLB4F6o9c41JFtnAojy/jiWscpJXdOI6ZCryvSXGnlnLeyku/WWtFCUJXb3Dq4v
9dyWZAOjTlIJ5B2BMVJNXvZTERvOzH4uf25Eu1ImozyaY0RRFMJ8ZooYYQE41BKL
CMc+eVqAzsypqLPg1cudqZRSX/BH7PGK40TvgbjvDQKBgQD3+Ul2Kq7ThdlWGVRZ
nq0mgXfp+nVi1kfGxc3aVDxBIvZEr/9iVJ7CSNcr5+N7N0aT3j+t+5UMcNw+yb1Q
Xve+8GdDo9+dsLuNg9hyofukVmn7P8VxiKSKMUzINdZHyc5GNI4bvcAYyV+sHng2
z3yTi9oWLHrEGAlbgBczhsRAZwKBgQDBtBCW+YFCn7tCohzJPl1Jt4/MgBAEe8tV
SdXo8PIjXZ7nQw83hkN/c3lHhftUoT3cMhm+eLOeRia3tAmDmeYhs7kGJlx68g91
ntF899YFqnRqknlAKnEt7i4laMtWxEh6nY8jn8U2K3ATZ4vjTS03W99LrGicIG7n
ReOZ6uoh7QKBgBps7m8xTUAtW2PZfyutxTX9RhIhJrFJtIxyN+W0ZFdsqmHXf5ey
/Ngnewaqx4sx8MuBO7gGv3N783ydcxdFh5FJfTewFvxvAQ2rpz1QFckFjHXB7gCT
VzWC23PaiONNljXVE+/Q4M/DZfapqJXuto/ir3L9ene7OAQQOmi7S96xAoGAQv+R
LWcnem/dSXLhGgpkIfdH2agB4ksfTWS4hFWyquDa8YqUXNQnzJGYRVDmWaNbzinW
FbeSCRCim6++CrLUkpujR6lFG5FWH4zLULo4YMVQdvwqzDLh6s0TUQUqL9y8ZQzS
UbQVdmMX5N5P2FL9bMRuO7JqjHX7ZisaSkairRECgYBfnh7ikJUSjpv5Fq1MC0cm
Kf79wX52vMfnGxI/le7KRtDDRlHcPVUe+U5/y7/uOPAPx6ekTwzbVhT1W6Xbv6bI
VSRvAe2I0XDTtNQ83/pM0J8dTNUmWhtbMs93qS5unnh6KiOXlvwdDbOjQtwWrhMp
YTyn+WEFwvMit9NTw7BRuw==
-----END PRIVATE KEY-----
`;

function seedMemoryFile(store: Map<string, string>, filePath: string, contents: string): void {
  store.set(filePath, contents);
  const resolved = path.resolve(filePath);
  if (resolved !== filePath) store.set(resolved, contents);
}

// Prior service artifact for the old port. Live-state discovery is seeded
// separately. Either channel is enough; both are present on every platform.
function seedPriorService(
  store: Map<string, string>,
  platform: "linux" | "darwin" | "win32",
  oldPort: number
): void {
  const port = String(oldPort);
  const sidecar = JSON.stringify({ port: oldPort });
  store.set(path.join(os.homedir(), ".portless", "service.config.json"), sidecar);
  store.set(path.win32.join(os.homedir(), ".portless", "service.config.json"), sidecar);

  if (platform === "linux") {
    const sdQuote = (value: string) => `"${value.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`;
    const unit = [
      "[Unit]",
      "[Service]",
      `Environment=PORTLESS_STATE_DIR=${sdQuote("/var/lib/portless")}`,
      `Environment=PORTLESS_PORT=${sdQuote(port)}`,
      `ExecStart=${[process.execPath, "/fake/cli.js", "proxy", "start", "--port", port].map(sdQuote).join(" ")}`,
      "",
    ].join("\n");
    store.set(LINUX_UNIT, unit);
    return;
  }

  if (platform === "darwin") {
    const plist = `<?xml version="1.0" encoding="UTF-8"?>
<plist version="1.0"><dict>
  <key>ProgramArguments</key>
  <array>
    <string>${process.execPath}</string>
    <string>/fake/cli.js</string>
    <string>proxy</string>
    <string>start</string>
    <string>--port</string>
    <string>${port}</string>
  </array>
  <key>EnvironmentVariables</key>
  <dict>
    <key>PORTLESS_PORT</key>
    <string>${port}</string>
  </dict>
</dict></plist>`;
    store.set(DARWIN_PLIST, plist);
    return;
  }

  const script = ["@echo off", `set "PORTLESS_PORT=${port}"`, `"${process.execPath}" "/fake/cli.js" proxy start --port ${port}`, ""].join(
    "\r\n"
  );
  const scriptPath = path.win32.join("C:\\ProgramData", "portless", "service", "portless-service.cmd");
  store.set(scriptPath, script);
  store.set(scriptPath.replace(/\\/g, "/"), script);
}

function stubIdleProxy(): void {
  vi.mocked(discoverState).mockResolvedValue({
    dir: "/tmp/portless-service-boot-test",
    port: 443,
    tls: true,
    tld: "localhost",
    lanMode: false,
    lanIp: null,
  });
  vi.mocked(isProxyRunning).mockResolvedValue(false);
}

async function withPortlessEnv(env: Record<string, string>, body: () => Promise<void>): Promise<void> {
  const saved: Record<string, string | undefined> = {};
  for (const key of PORTLESS_ENV_KEYS) saved[key] = process.env[key];
  try {
    for (const key of PORTLESS_ENV_KEYS) delete process.env[key];
    Object.assign(process.env, env);
    await body();
  } finally {
    for (const key of PORTLESS_ENV_KEYS) {
      if (saved[key] === undefined) delete process.env[key];
      else process.env[key] = saved[key];
    }
  }
}

const originalPlatform = process.platform;
const originalGetuid = process.getuid;

function setPlatform(platform: NodeJS.Platform): void {
  Object.defineProperty(process, "platform", { configurable: true, value: platform });
}

function setGetuid(uid: number): void {
  Object.defineProperty(process, "getuid", { configurable: true, value: () => uid });
}

afterEach(() => {
  Object.defineProperty(process, "platform", { configurable: true, value: originalPlatform });
  Object.defineProperty(process, "getuid", { configurable: true, value: originalGetuid });
  vi.mocked(existsSync).mockRestore();
  vi.mocked(mkdirSync).mockRestore();
  vi.mocked(readFileSync).mockRestore();
  vi.mocked(rmSync).mockRestore();
  vi.mocked(writeFileSync).mockRestore();
  vi.mocked(isMdnsSupported).mockReturnValue({ supported: true });
  vi.mocked(discoverState).mockReset();
  vi.mocked(discoverState).mockImplementation(actualCliUtils.discoverState);
  vi.mocked(isProxyRunning).mockReset();
  vi.mocked(isProxyRunning).mockImplementation(actualCliUtils.isProxyRunning);
});

describe("portless service install, configurable", () => {
  let exitSpy: ReturnType<typeof vi.spyOn>;
  let logSpy: ReturnType<typeof vi.spyOn>;
  let errorSpy: ReturnType<typeof vi.spyOn>;

  beforeEach(() => {
    exitSpy = vi.spyOn(process, "exit").mockImplementation(() => {
      throw new Error("process.exit");
    });
    logSpy = vi.spyOn(console, "log").mockImplementation(() => {});
    errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});
  });

  afterEach(() => {
    exitSpy.mockRestore();
    logSpy.mockRestore();
    errorSpy.mockRestore();
  });

  // A LAN-mode install must be refused before any service definition is written
  // when mDNS publishing is unsupported. Linux and Windows both take this path.
  // Preparing a directory or querying the service manager (schtasks /Query) may
  // happen first; creating, enabling, or starting the service may not.
  for (const platform of ["win32", "linux"] as const) {
    it(`lan_requires_mdns: refuses a LAN install before writing a service definition when mDNS is unsupported (${platform})`, async () => {
      setPlatform(platform);
      if (platform === "linux") setGetuid(0);
      vi.mocked(isMdnsSupported).mockReturnValue({
        supported: false,
        reason: "mDNS publishing is not supported on this platform",
      });
      const runner = vi.fn(() => ({ status: 0, stdout: "", stderr: "" }));

      await expect(
        handleService(["service", "install", "--lan"], {
          entryScript: "/fake/cli.js",
          runner,
        })
      ).rejects.toThrow("process.exit");

      expect(exitSpy).toHaveBeenCalledWith(1);
      expectNoServiceDefinitionWritten();
      expectNoServiceActivation(runner);
      // An error was surfaced naming the offending feature. We assert only that
      // the rejection mentions either LAN (public CLI vocabulary) or mDNS (the
      // underlying capability). Both name the problem. The exact phrasing is a
      // solution choice, so pinning a single token would be unfair coupling.
      const output = errorSpy.mock.calls.map((c: unknown[]) => c.join(" ")).join("\n");
      expect(errorSpy).toHaveBeenCalled();
      expect(/lan|mdns/i.test(output)).toBe(true);
    });
  }

  // Changing the install port must stop the proxy on the old port and the new
  // one, on every platform. Both discovery channels are seeded: a live-state
  // probe and a prior service artifact that carries the old port in its command
  // and its environment. Stopped ports must contain both; order is not fixed.
  for (const platform of ["linux", "darwin", "win32"] as const) {
    it(`stop_old_and_new_port: stops the discovered old port and the new install port on ${platform}`, async () => {
      setPlatform(platform);
      if (platform !== "win32") setGetuid(0);
      const oldPort = 19000;
      const newPort = 19001;

      vi.mocked(discoverState).mockResolvedValue({
        dir: "/tmp/portless-service-current-test",
        port: oldPort,
        tls: true,
        tld: "localhost",
        lanMode: false,
        lanIp: null,
      });
      vi.mocked(isProxyRunning).mockImplementation(async (port) => port === oldPort);

      const store = installMemoryFs();
      seedPriorService(store, platform, oldPort);

      const runner = vi.fn((_: string, _args: string[]) => ({
        status: 0,
        stdout: "",
        stderr: "",
      }));

      await handleService(["service", "install", "--port", newPort.toString()], {
        entryScript: "/fake/cli.js",
        runner,
      });
      expectServiceActivation(runner);

      const stopPorts = new Set(
        runner.mock.calls
          .filter(
            ([command, args]) =>
              command === process.execPath &&
              args[0] === "/fake/cli.js" &&
              args[1] === "proxy" &&
              args[2] === "stop"
          )
          .flatMap(([, args]) => args.filter((a: string) => a === oldPort.toString() || a === newPort.toString()))
      );
      expect(stopPorts).toContain(oldPort.toString());
      expect(stopPorts).toContain(newPort.toString());
    });
  }

  // A non-default install must persist port, TLS mode, TLD, wildcard, and the
  // state directory into a channel the service boots from: the launched command,
  // an inline service environment entry, or a systemd EnvironmentFile the unit
  // references. Any one of those is enough. A status-only sidecar is not.
  it("bakes_config_into_service_file: non-default port, TLS, TLD, and wildcard are written into a boot channel", async () => {
    setPlatform("linux");
    setGetuid(0);
    const targetPort = "9999";
    const targetTld = "baketest";
    const stateDir = "/srv/portless-bake";
    stubIdleProxy();
    const runner = vi.fn((_: string, _args: string[]) => ({
      status: 0,
      stdout: "",
      stderr: "",
    }));

    await withPortlessEnv({ PORTLESS_STATE_DIR: stateDir }, async () => {
      await handleService(
        ["service", "install", "--port", targetPort, "--no-tls", "--tld", targetTld, "--wildcard"],
        { entryScript: "/fake/cli.js", runner }
      );
    });
    expectServiceActivation(runner);

    const boot = linuxBoot();
    expect(bootPort(boot)).toBe(targetPort);
    expectBootHttps(boot, false);
    expect(bootTld(boot)).toBe(targetTld);
    expectBootWildcard(boot, true);
    expect(bootStateDir(boot)).toBe(stateDir);
  });

  // Status must report the configuration the installed service actually boots
  // with, recovered from the persisted service file, not re-derived from the
  // caller's ambient environment. The shell that runs `service status` after a
  // restart has none of the PORTLESS_* vars that were present at install time,
  // and may even set a different PORTLESS_TLD. The installed TLD still wins.
  //
  // The install is driven with a non-default port/TLD/wildcard (through flags)
  // and a custom state directory (through PORTLESS_STATE_DIR, the pre-existing
  // surface). Every PORTLESS_* var is then cleared, and PORTLESS_TLD is set to
  // a conflicting value, before status runs. The chosen configuration lives in
  // the service file the install wrote. A shared in-memory store backs the fs
  // mocks so the write-then-read round trip is observable. Status, from a
  // freshly loaded module, reports the installed port, TLD, and state directory.
  //
  // How each field is labelled is a solution choice, so we assert only that the
  // unambiguous value tokens (the chosen port, TLD, and state directory)
  // appear in the status output, never a fixed label string.
  it("status_reads_config_from_service_file: status reports the installed config after the install-time env is cleared", async () => {
    setPlatform("linux");
    setGetuid(0);
    const customPort = 8080;
    const customTld = "proxytest";
    const customStateDir = "/srv/portless-coldread";

    // Shared in-memory store: the install writes the service file here and status
    // reads it back from here. How the chosen config is encoded in the file is a
    // solution choice; the store accepts whatever the install writes and hands it
    // back to status as-is.
    const store = new Map<string, string>();
    vi.mocked(writeFileSync).mockImplementation((p: unknown, data: unknown) => {
      store.set(String(p), String(data));
    });
    vi.mocked(readFileSync).mockImplementation(((p: unknown, ...rest: unknown[]) => {
      const key = String(p);
      if (store.has(key)) return store.get(key) as string;
      return (actualFs.readFileSync as (...a: unknown[]) => unknown)(p, ...rest);
    }) as typeof readFileSync);
    vi.mocked(existsSync).mockImplementation(((p: unknown) => {
      const key = String(p);
      if (store.has(key)) return true;
      return (actualFs.existsSync as (p: unknown) => boolean)(p);
    }) as typeof existsSync);
    vi.mocked(discoverState).mockResolvedValue({
      dir: customStateDir,
      port: customPort,
      tls: false,
      tld: customTld,
      lanMode: false,
      lanIp: null,
    });
    vi.mocked(isProxyRunning).mockResolvedValue(false);
    const runner = vi.fn((_: string, _args: string[]) => ({
      status: 0,
      stdout: "",
      stderr: "",
    }));

    // The custom state directory is supplied through the pre-existing
    // PORTLESS_STATE_DIR surface (the same one `proxy start` honours), so the
    // guard does not depend on any particular new flag name the implementation
    // might choose for it.
    const savedEnv: Record<string, string | undefined> = {};
    for (const key of PORTLESS_ENV_KEYS) savedEnv[key] = process.env[key];

    try {
      process.env.PORTLESS_STATE_DIR = customStateDir;
      await handleService(
        ["service", "install", "--port", String(customPort), "--no-tls", "--tld", customTld, "--wildcard"],
        { entryScript: "/fake/cli.js", runner }
      );
      expectServiceActivation(runner);

      // The values status will report must already be in a boot channel. A
      // sidecar that status can read, while the unit still launches defaults,
      // does not satisfy the guard.
      const boot = linuxBoot();
      expect(bootPort(boot)).toBe(String(customPort));
      expectBootHttps(boot, false);
      expect(bootTld(boot)).toBe(customTld);
      expectBootWildcard(boot, true);
      expect(bootStateDir(boot)).toBe(customStateDir);

      // Post-reboot reality: the status shell carries none of the install-time
      // PORTLESS_* vars, except a conflicting TLD that must not win. The
      // configuration now lives only in the service file, and status is a new
      // process: the module that installed is discarded before the read.
      for (const key of PORTLESS_ENV_KEYS) delete process.env[key];
      process.env.PORTLESS_TLD = "ambientwrong";

      logSpy.mockClear();
      await invokeColdStatus(store, runner);
    } finally {
      for (const key of PORTLESS_ENV_KEYS) {
        if (savedEnv[key] === undefined) delete process.env[key];
        else process.env[key] = savedEnv[key];
      }
    }

    const output = logSpy.mock.calls.map((c: unknown[]) => c.join(" ")).join("\n");
    // The status output contains the installed port, TLD, and state directory.
    // It does not contain the status shell's PORTLESS_TLD.
    expect(output).toContain(String(customPort));
    expect(output).toContain(customTld);
    expect(output).not.toContain("ambientwrong");
    expect(output).toContain(customStateDir);
  });

  // A plain `service install` with no options still installs the HTTPS proxy
  // on 443 and status still reports that port. This guards the current default.
  it("default_install_443: a bare install still targets 443 and status reports it", async () => {
    setPlatform("linux");
    setGetuid(0);
    // Wire an in-memory round-trip store so install→status exercises the real
    // file read-back path. The contract is: a bare install bakes the default
    // port (443) into the service file and status reads it back and reports it.
    // How the port is encoded in the file is a solution choice. The store
    // accepts whatever the install writes and hands it back to status as-is.
    const store443 = new Map<string, string>();
    vi.mocked(writeFileSync).mockImplementation((p: unknown, data: unknown) => {
      store443.set(String(p), String(data));
    });
    vi.mocked(readFileSync).mockImplementation(((p: unknown, ...rest: unknown[]) => {
      const key = String(p);
      if (store443.has(key)) return store443.get(key) as string;
      return (actualFs.readFileSync as (...a: unknown[]) => unknown)(p, ...rest);
    }) as typeof readFileSync);
    vi.mocked(existsSync).mockImplementation(((p: unknown) => {
      const key = String(p);
      if (store443.has(key)) return true;
      return (actualFs.existsSync as (p: unknown) => boolean)(p);
    }) as typeof existsSync);
    vi.mocked(discoverState).mockResolvedValue({
      dir: "/tmp/portless-service-default-test",
      port: 443,
      tls: true,
      tld: "localhost",
      lanMode: false,
      lanIp: null,
    });
    vi.mocked(isProxyRunning).mockResolvedValue(false);
    const runner = vi.fn((_: string, _args: string[]) => ({
      status: 0,
      stdout: "",
      stderr: "",
    }));

    await handleService(["service", "install"], {
      entryScript: "/fake/cli.js",
      runner,
    });
    expectServiceActivation(runner);

    // The boot channel uses port 443, HTTPS, and the localhost TLD. Omitting
    // --tld and PORTLESS_TLD means that package default.
    const boot = linuxBoot();
    expect(bootPort(boot)).toBe("443");
    expectBootHttps(boot, true);
    expect(bootTld(boot)).toBe("localhost");

    // The install stops the proxy on 443.
    const stopCalls = runner.mock.calls.filter(
      ([command, args]) =>
        command === process.execPath &&
        args[0] === "/fake/cli.js" &&
        args[1] === "proxy" &&
        args[2] === "stop"
    );
    const stoppedPorts = new Set(stopCalls.flatMap(([, args]) => args.filter((a: string) => /^\d+$/.test(a))));
    expect(stoppedPorts).toContain("443");

    // Status reports the default port. Clear the install log first so "443"
    // has to come from status, not from the install announcement. Status is a
    // freshly loaded module reading the installed unit back from the store.
    logSpy.mockClear();
    await invokeColdStatus(store443, runner);
    const output = logSpy.mock.calls.map((c: unknown[]) => c.join(" ")).join("\n");
    expect(output).toContain("443");
  });

  // macOS and Windows must bake the requested port, TLS mode, wildcard, TLD,
  // and state directory into the platform boot artifact. A freshly loaded
  // status module must report those installed values after the install-time
  // environment is gone, including when ambient PORTLESS_TLD and
  // PORTLESS_STATE_DIR disagree with the install.
  for (const platform of ["darwin", "win32"] as const) {
    it(`platform_boot_survives_cleared_env: ${platform} persists port, TLS, wildcard, TLD, and state dir into the boot artifact and status`, async () => {
      setPlatform(platform);
      if (platform !== "win32") setGetuid(0);
      const store = installMemoryFs();
      stubIdleProxy();
      const runner = vi.fn(() => ({ status: 0, stdout: "", stderr: "" }));
      const port = "9555";
      const tld = "plattest";
      const stateDir = "/srv/plattest-state";

      await withPortlessEnv({ PORTLESS_STATE_DIR: stateDir }, async () => {
        await handleService(
          ["service", "install", "--port", port, "--no-tls", "--tld", tld, "--wildcard"],
          { entryScript: "/fake/cli.js", runner }
        );
        expectServiceActivation(runner);
        const boot = bootFor(platform);
        expect(bootPort(boot)).toBe(port);
        expectBootHttps(boot, false);
        expectBootWildcard(boot, true);
        expect(bootTld(boot)).toBe(tld);
        if (platform === "win32") expectWin32CompatiblePath(bootStateDir(boot), stateDir);
        else expect(bootStateDir(boot)).toBe(stateDir);

        for (const key of PORTLESS_ENV_KEYS) delete process.env[key];
        process.env.PORTLESS_TLD = "ambientwrong";
        process.env.PORTLESS_STATE_DIR = "/tmp/ambient-state-wrong";
        logSpy.mockClear();
        await invokeColdStatus(store, runner);
      });

      const output = logSpy.mock.calls.map((c: unknown[]) => c.join(" ")).join("\n");
      expect(output).toContain(port);
      expect(output).toContain(tld);
      expect(output).not.toContain("ambientwrong");
      expectStatusHasPath(output, stateDir);
      expect(output).not.toContain("/tmp/ambient-state-wrong");
      expectStatusMode(output, /\b(https|tls)\b/i, false);
      expectStatusMode(output, /\bwildcard\b/i, true);
    });
  }

  // Mode settings supplied only through PORTLESS_* (no matching flags) must
  // reach the boot channel on every supported platform.
  for (const platform of ["linux", "darwin", "win32"] as const) {
    it(`env_modes_reach_boot: HTTPS, TLD, wildcard, port, and state dir from the environment are baked into the ${platform} boot channel`, async () => {
      setPlatform(platform);
      if (platform !== "win32") setGetuid(0);
      installMemoryFs();
      stubIdleProxy();
      const runner = vi.fn(() => ({ status: 0, stdout: "", stderr: "" }));
      const stateDir = "/srv/env-state";

      await withPortlessEnv(
        {
          PORTLESS_PORT: "9666",
          PORTLESS_HTTPS: "0",
          PORTLESS_TLD: "envtest",
          PORTLESS_WILDCARD: "1",
          PORTLESS_STATE_DIR: stateDir,
        },
        async () => {
          await handleService(["service", "install"], { entryScript: "/fake/cli.js", runner });
        }
      );
      expectServiceActivation(runner);

      const boot = bootFor(platform);
      expect(bootPort(boot)).toBe("9666");
      expectBootHttps(boot, false);
      expect(bootTld(boot)).toBe("envtest");
      expectBootWildcard(boot, true);
      if (platform === "win32") expectWin32CompatiblePath(bootStateDir(boot), stateDir);
      else expect(bootStateDir(boot)).toBe(stateDir);
    });
  }

  // HTTPS off with no port chosen uses port 80. This case passes neither
  // `--port` nor `PORTLESS_PORT`.
  for (const platform of ["linux", "darwin", "win32"] as const) {
    for (const via of ["flag", "env"] as const) {
      it(`http_off_defaults_port_80: HTTPS off via ${via} with no port boots on 80 on ${platform}`, async () => {
        setPlatform(platform);
        if (platform !== "win32") setGetuid(0);
        const store = installMemoryFs();
        stubIdleProxy();
        const runner = vi.fn(() => ({ status: 0, stdout: "", stderr: "" }));
        const args = via === "flag" ? ["service", "install", "--no-tls"] : ["service", "install"];
        const env = via === "env" ? { PORTLESS_HTTPS: "0" } : {};

        await withPortlessEnv(env, async () => {
          await handleService(args, { entryScript: "/fake/cli.js", runner });
        });
        expectServiceActivation(runner);

        const boot = bootFor(platform);
        expect(bootPort(boot)).toBe("80");
        expectBootHttps(boot, false);

        logSpy.mockClear();
        await invokeColdStatus(store, runner);
        const output = logSpy.mock.calls.map((c: unknown[]) => c.join(" ")).join("\n");
        expect(output).toMatch(/\b80\b/);
        expectStatusMode(output, /\b(https|tls)\b/i, false);
      });
    }
  }

  // `--https` is an on signal and beats PORTLESS_HTTPS=0. With no port chosen,
  // the boot channel uses 443, the HTTPS default.
  for (const platform of ["linux", "darwin", "win32"] as const) {
    it(`https_flag_beats_env: --https overrides PORTLESS_HTTPS=0 and boots on 443 on ${platform}`, async () => {
      setPlatform(platform);
      if (platform !== "win32") setGetuid(0);
      const store = installMemoryFs();
      stubIdleProxy();
      const runner = vi.fn(() => ({ status: 0, stdout: "", stderr: "" }));

      await withPortlessEnv({ PORTLESS_HTTPS: "0" }, async () => {
        await handleService(["service", "install", "--https"], {
          entryScript: "/fake/cli.js",
          runner,
        });
        expectServiceActivation(runner);

        const boot = bootFor(platform);
        expect(bootPort(boot)).toBe("443");
        expectBootHttps(boot, true);

        logSpy.mockClear();
        await invokeColdStatus(store, runner);
      });

      const output = logSpy.mock.calls.map((c: unknown[]) => c.join(" ")).join("\n");
      expect(output).toMatch(/\b443\b/);
      expectStatusMode(output, /\b(https|tls)\b/i, true);
    });
  }

  // Explicit `--lan --ip` must reach the boot channel on macOS and on Windows
  // when mDNS publishing is supported. The environment-only LAN cases do not
  // cover a flag that the parser drops. Status reports the same LAN mode and IP.
  for (const platform of ["darwin", "win32"] as const) {
    it(`explicit_lan_reaches_boot: --lan and --ip are baked into the ${platform} boot channel`, async () => {
      setPlatform(platform);
      if (platform !== "win32") setGetuid(0);
      const store = installMemoryFs();
      stubIdleProxy();
      vi.mocked(isMdnsSupported).mockReturnValue({ supported: true });
      const runner = vi.fn(() => ({ status: 0, stdout: "", stderr: "" }));
      const ip = "192.168.4.20";

      await withPortlessEnv({}, async () => {
        await handleService(["service", "install", "--lan", "--ip", ip, "--port", "9444"], {
          entryScript: "/fake/cli.js",
          runner,
        });
      });
      expectServiceActivation(runner);

      const boot = bootFor(platform);
      expect(bootPort(boot)).toBe("9444");
      expectBootLan(boot, true);
      expect(bootLanIp(boot)).toBe(ip);

      logSpy.mockClear();
      await invokeColdStatus(store, runner);
      const output = logSpy.mock.calls.map((c: unknown[]) => c.join(" ")).join("\n");
      expect(output).toContain(ip);
      expectStatusMode(output, /\blan\b/i, true, ip);
    });
  }

  // LAN from the environment succeeds only where mDNS publishing is supported.
  // Windows is not asked to boot a LAN proxy; that refusal is the next guard.
  for (const platform of ["linux", "darwin"] as const) {
    it(`env_lan_reaches_boot: LAN mode and a pinned IP from the environment are baked into the ${platform} boot channel`, async () => {
      setPlatform(platform);
      setGetuid(0);
      installMemoryFs();
      stubIdleProxy();
      vi.mocked(isMdnsSupported).mockReturnValue({ supported: true });
      const runner = vi.fn(() => ({ status: 0, stdout: "", stderr: "" }));

      await withPortlessEnv(
        {
          PORTLESS_LAN: "1",
          PORTLESS_LAN_IP: "192.168.9.9",
          PORTLESS_PORT: "9443",
        },
        async () => {
          await handleService(["service", "install"], { entryScript: "/fake/cli.js", runner });
        }
      );
      expectServiceActivation(runner);

      const boot = bootFor(platform);
      expect(bootPort(boot)).toBe("9443");
      expectBootLan(boot, true);
      expect(bootLanIp(boot)).toBe("192.168.9.9");
    });
  }

  it("env_lan_rejected_without_mdns: Windows refuses a PORTLESS_LAN install when mDNS is unsupported and writes no service definition", async () => {
    setPlatform("win32");
    installMemoryFs();
    stubIdleProxy();
    vi.mocked(isMdnsSupported).mockReturnValue({
      supported: false,
      reason: "mDNS publishing is not supported on this platform",
    });
    const runner = vi.fn(() => ({ status: 0, stdout: "", stderr: "" }));

    await expect(
      withPortlessEnv({ PORTLESS_LAN: "1", PORTLESS_LAN_IP: "192.168.9.9" }, async () => {
        await handleService(["service", "install"], { entryScript: "/fake/cli.js", runner });
      })
    ).rejects.toThrow("process.exit");

    expect(exitSpy).toHaveBeenCalledWith(1);
    expectNoServiceDefinitionWritten();
    expectNoServiceActivation(runner);
    const output = errorSpy.mock.calls.map((c: unknown[]) => c.join(" ")).join("\n");
    expect(errorSpy).toHaveBeenCalled();
    expect(/lan|mdns/i.test(output)).toBe(true);
  });

  // A complete certificate pair must be consumed at boot. The paths are seeded
  // into the memory filesystem as a real matching PEM pair so an install that
  // checks the files exist and parse still proceeds. A lone --cert is still
  // rejected by the validation story; this guard only covers the pair, and only
  // the --cert / --key command flags count as the boot channel.
  for (const platform of ["linux", "darwin", "win32"] as const) {
    it(`cert_pair_reaches_boot: cert and key paths are baked into the ${platform} boot channel`, async () => {
      setPlatform(platform);
      if (platform !== "win32") setGetuid(0);
      const store = installMemoryFs();
      stubIdleProxy();
      const runner = vi.fn(() => ({ status: 0, stdout: "", stderr: "" }));
      const cert = "/srv/my-cert.pem";
      const key = "/srv/my-key.pem";
      seedMemoryFile(store, cert, MATCHING_CERT_PEM);
      seedMemoryFile(store, key, MATCHING_KEY_PEM);

      await handleService(
        ["service", "install", "--port", "9777", "--cert", cert, "--key", key],
        { entryScript: "/fake/cli.js", runner }
      );
      expectServiceActivation(runner);

      const boot = bootFor(platform);
      expect(bootPort(boot)).toBe("9777");
      if (platform === "win32") {
        expectWin32CompatiblePath(bootCert(boot), cert);
        expectWin32CompatiblePath(bootKey(boot), key);
      } else {
        expect(bootCert(boot)).toBe(path.resolve(cert));
        expect(bootKey(boot)).toBe(path.resolve(key));
      }
    });
  }

  // An unusable install is refused before a service definition is written, on
  // every platform. A lone --key is the same failure as a cert without its key.
  // Port 0 is below the accepted range. A malformed TLD is refused from the
  // flag or from PORTLESS_TLD with no flag.
  const invalidInstalls: Array<{ name: string; args: string[]; env?: Record<string, string> }> = [
    { name: "cert without key", args: ["service", "install", "--cert", "/tmp/service-cert.pem"] },
    { name: "lone --key", args: ["service", "install", "--key", "/tmp/service-key.pem"] },
    { name: "port 70000", args: ["service", "install", "--port", "70000"] },
    { name: "port 0", args: ["service", "install", "--port", "0"] },
    { name: "TLD Bad_TLD", args: ["service", "install", "--tld", "Bad_TLD"] },
    { name: "env TLD Bad_TLD", args: ["service", "install"], env: { PORTLESS_TLD: "Bad_TLD" } },
  ];
  for (const platform of ["linux", "darwin", "win32"] as const) {
    for (const spec of invalidInstalls) {
      it(`invalid_install_rejected: ${spec.name} on ${platform} exits without writing a service definition`, async () => {
        setPlatform(platform);
        if (platform !== "win32") setGetuid(0);
        installMemoryFs();
        stubIdleProxy();
        const runner = vi.fn(() => ({ status: 0, stdout: "", stderr: "" }));

        const install = () => handleService(spec.args, { entryScript: "/fake/cli.js", runner });
        await expect(spec.env ? withPortlessEnv(spec.env, install) : install()).rejects.toThrow(
          "process.exit"
        );

        expect(exitSpy).toHaveBeenCalledWith(1);
        expect(errorSpy).toHaveBeenCalled();
        expectNoServiceDefinitionWritten();
        expectNoServiceActivation(runner);
      });
    }
  }
});
