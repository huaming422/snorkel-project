## Task

portless service install only ever sets up one thing, the proxy on HTTPS port 443 with .localhost names. service install should accept the same options as proxy start, with the same defaults. A flag takes precedence over its matching variable.

service status should report the configuration the installed service actually has, even when the current shell environment is empty or disagrees.

A --lan install on a platform that cannot advertise LAN names over mDNS should fail before it writes anything for the service. Reinstalling on a different port should not leave the previous proxy running.

## User stories / requirements

- Status should agree with the install. When HTTPS is off, a custom port, TLD, and state directory were chosen, and wildcard is on, status should show that port, HTTPS off, that TLD, wildcard on, and that directory. When the install is LAN mode with a pinned address, status should show LAN mode and that address.
- Give install a certificate and no key, a port outside the allowed range, or a malformed TLD. It should stop, the error should name the bad certificate, port, or TLD, and it should not write a service file. Uninstall should still finish when proxy settings in the environment are invalid.
