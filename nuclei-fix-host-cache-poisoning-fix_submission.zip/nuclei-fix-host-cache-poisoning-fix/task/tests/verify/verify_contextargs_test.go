package contextargs

import (
	"context"
	"testing"

	"github.com/stretchr/testify/require"
)

// TestVerifyGetCopyIfHostOutdatedSchemePort pins the per-request "updated input"
// derivation that keys the host-errors cache. When a template rewrites the
// target to a different port, the derived context must resolve to the rewritten
// port so a failure is attributed to the port that actually failed, and the
// original base context must stay untouched.
//
// Assertions are on the resolved Address() of the updated context, not on any
// internal storage layout, so any implementation that derives the per-request
// address correctly is accepted.
func TestVerifyGetCopyIfHostOutdatedSchemePort(t *testing.T) {
	t.Run("same host and scheme leaves the base address untouched", func(t *testing.T) {
		ctx := NewWithInput(context.Background(), "http://127.0.0.1:3000")
		updated := GetCopyIfHostOutdated(ctx, "http://127.0.0.1:3000/api/v1")
		require.Equal(t, "127.0.0.1:3000", updated.MetaInput.Address())
	})

	t.Run("custom port is attributed to the rewritten port and leaves the base unchanged", func(t *testing.T) {
		ctx := NewWithInput(context.Background(), "http://127.0.0.1:3000")
		updated := GetCopyIfHostOutdated(ctx, "http://127.0.0.1:8080/probe")
		require.Equal(t, "127.0.0.1:8080", updated.MetaInput.Address(), "updated context must resolve to the rewritten custom port")
		require.Equal(t, "127.0.0.1:3000", ctx.MetaInput.Address(), "the original base context must not be mutated")
	})
}
