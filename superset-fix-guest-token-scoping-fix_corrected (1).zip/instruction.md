## Task

Our security review turned up a few ways for someone viewing an embedded dashboard to get more out of it than it's meant to give. A guest token is meant to keep its holder to the charts on that one dashboard, and each data request to what it's for. By editing the requests the dashboard sends, a guest can get more back than that.

A guest can add annotation layers to a chart request that the saved chart doesn't have. The server fetches those layers and returns their annotations, so the guest can read annotation sources they were never given.

A guest can also turn a request into one for the dataset's raw rows, every column included. A chart request should only return what the chart displays, such as its aggregated numbers. The requests the dashboard makes to look up a filter's values or open Drill By on a chart should only return those values or that breakdown. Right now all three can be made to hand back the raw rows instead.

On top of that, the page served for the embedded URL, before any guest token has been presented, includes the dashboard's title and description, so anyone who knows the URL can read them.

Please close all of these. Guests should still get everything the dashboard is meant to give them: the charts, along with the annotation layers they're saved with, a chart's plain results, filter values, Drill By, and Drill to Detail where the dashboard offers it, since that one is supposed to show the dataset's rows. Protections that already work should stay as they are. Only the Python backend needs to change.
