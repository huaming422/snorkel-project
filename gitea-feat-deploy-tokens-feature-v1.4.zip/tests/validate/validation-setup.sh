#!/usr/bin/env bash
#
# Validation environment setup for the repository-HTTPS-credential feature task.
#
# Runs after `tests/test-setup.sh` (which already prepared the gitea Go test
# runtime — sqlite.ini, build tags, env vars). This script layers on the bits
# the go-test validation driver needs to drive the integration package (a full
# in-memory server + sqlite + YAML fixtures) over git-http, LFS and the REST
# API:
#
#   - CGO_ENABLED / GOEXPERIMENT / GOTOOLCHAIN exported so `go test` picks the
#     bundled toolchain and links mattn/go-sqlite3 on a cold shell.
#   - GOCACHE / GOMODCACHE created up-front in case the image's pre-warmed
#     cache was wiped by the agent.
#   - GITEA_TEST_CONF + tests/sqlite.ini regen (with the
#     I_AM_BEING_UNSAFE_RUNNING_AS_ROOT flag) if the agent ran `git clean -fdx`.
#   - sqlite WAL/journal sibling files gitignored so they don't trip the
#     post-agent `git diff` integrity check.
#   - A defensive `go mod download` (no-op on a warm cache).
#
# This script must be IDEMPOTENT — it may be sourced multiple times.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/gitea}"
cd "$REPO_DIR"

# Re-export the Go toolchain knobs the go-test driver needs.
export CGO_ENABLED="${CGO_ENABLED:-1}"
export GOEXPERIMENT="${GOEXPERIMENT:-jsonv2}"
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"
export GOFLAGS="${GOFLAGS:--mod=mod}"
export GOCACHE="${GOCACHE:-/root/.cache/go-build}"
export GOMODCACHE="${GOMODCACHE:-/root/go/pkg/mod}"
export GITEA_TEST_CONF="${GITEA_TEST_CONF:-tests/sqlite.ini}"

mkdir -p "$GOCACHE" "$GOMODCACHE"

# Make `go` reachable even if the harness scrubbed PATH.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

# Root-user guard flag. The boot sequence reads I_AM_BEING_UNSAFE_RUNNING_AS_ROOT
# from the config file's root (unnamed) section because the GITEA_* env-var path
# is scrubbed before the root check runs. CRITICAL at this repo revision:
# setting.PrepareIntegrationTestConfig() REGENERATES tests/sqlite.ini from
# tests/sqlite.ini.tmpl on every `go test` boot (placeholder substitution only),
# so a flag written into the generated .ini is overwritten before it is read.
# The flag must therefore live in the .tmpl's root section so it survives
# regeneration. Insert it idempotently at the top (above the first [section]).
if [[ -f tests/sqlite.ini.tmpl ]] && ! grep -q '^I_AM_BEING_UNSAFE_RUNNING_AS_ROOT' tests/sqlite.ini.tmpl; then
    sed -i '1i I_AM_BEING_UNSAFE_RUNNING_AS_ROOT = true' tests/sqlite.ini.tmpl
fi
# Re-materialise the generated .ini too (defensive: an agent `git clean -fdx`
# could erase it, and a cold boot reads it before the first regeneration).
if [[ -f tests/sqlite.ini.tmpl && ! -f tests/sqlite.ini ]]; then
    sed -e 's|{{WORK_PATH}}|/repo/gitea/tests/integration/gitea-integration-sqlite|g' \
        tests/sqlite.ini.tmpl > tests/sqlite.ini
fi
if [[ -f tests/sqlite.ini ]] && ! grep -q '^I_AM_BEING_UNSAFE_RUNNING_AS_ROOT' tests/sqlite.ini; then
    sed -i '1i I_AM_BEING_UNSAFE_RUNNING_AS_ROOT = true' tests/sqlite.ini
fi

# Ensure SQLite temporary/WAL-mode files are gitignored so they do not trigger
# the post-agent integrity check (git diff). *.db is already ignored but the
# journal/wal/shm siblings use different extensions.
for pat in '*.db-journal' '*.db-wal' '*.db-shm'; do
    if ! grep -qF "$pat" .gitignore 2>/dev/null; then
        echo "$pat" >> .gitignore
    fi
done

# Belt-and-suspenders module fetch. The image baked the module cache at the
# base commit, so try the offline path first (GOPROXY=off, no network); only
# if that reports something genuinely missing do we fall back to the CDN with
# a visible log. Tolerate failure either way — `go test` surfaces anything
# actually missing.
if ! GOPROXY=off go mod download 2>/tmp/go-mod-offline.log; then
    echo "validation-setup.sh: offline 'go mod download' incomplete; retrying online" >&2
    go mod download || true
fi

echo "validation-setup.sh: ready (CGO_ENABLED=$CGO_ENABLED, tags='sqlite sqlite_unlock_notify', module=gitea.dev)"
