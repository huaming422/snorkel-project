#!/usr/bin/env bash
#
# Sourced (not exec'd, so exported env sticks) before the Go tests run. The
# Dockerfile already pre-warmed the module cache, baked the full dependency
# closure, and materialised tests/sqlite.ini. This script only makes the
# environment robust against an agent's edits and a freshly-spawned shell that
# did not inherit the image ENV. Everything the solving agent needs to build
# and run the focused tests is ALREADY in the image — this performs no network
# fetches for the build/test path (the image's agent phase is offline).

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/gitea}"
cd "$REPO_DIR"

# sqlite-backed unittest/integration tests require CGO and these build tags.
export CGO_ENABLED=1
export GOEXPERIMENT=jsonv2

# Make `go test` find the toolchain even when the harness scrubs PATH.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

# Defensive offline switches. The image sets these via `go env -w`, but a shell
# that recomputes GOENV or an agent that reset it should still fail fast on a
# cache miss rather than hang against a dead network. The dependency closure is
# already in the module cache, so -mod=mod + GOPROXY=off resolve locally.
export GOFLAGS="${GOFLAGS:--mod=mod}"
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"

# Root-user guard flag. unittest/integration boot reads
# I_AM_BEING_UNSAFE_RUNNING_AS_ROOT from the config file's root (unnamed)
# section because UnsetUnnecessaryEnvVars scrubs the GITEA_* env-var path before
# loadRunModeFrom runs. CRITICAL: setting.PrepareIntegrationTestConfig()
# REGENERATES tests/sqlite.ini from tests/sqlite.ini.tmpl on every integration
# `go test` boot (placeholder substitution only), so the flag MUST live in the
# .tmpl root section; a flag only in the generated .ini is overwritten before it
# is read. Insert at line 1 (above the first [section]) idempotently.
if [[ -f tests/sqlite.ini.tmpl ]] && ! grep -q '^I_AM_BEING_UNSAFE_RUNNING_AS_ROOT' tests/sqlite.ini.tmpl; then
    sed -i '1i I_AM_BEING_UNSAFE_RUNNING_AS_ROOT = true' tests/sqlite.ini.tmpl
fi
if [[ -f tests/sqlite.ini.tmpl && ! -f tests/sqlite.ini ]]; then
    sed -e 's|{{WORK_PATH}}|/repo/gitea/tests/integration/gitea-integration-sqlite|g' \
        tests/sqlite.ini.tmpl > tests/sqlite.ini
fi
if [[ -f tests/sqlite.ini ]] && ! grep -q '^I_AM_BEING_UNSAFE_RUNNING_AS_ROOT' tests/sqlite.ini; then
    sed -i '1i I_AM_BEING_UNSAFE_RUNNING_AS_ROOT = true' tests/sqlite.ini
fi

# The canonical isolated verifier venv (/opt/tooling/venv, baked by the image)
# already carries pinned pytest==9.1.1; the harness routes verifier infra through
# VERIFIER_PYTHON. This script does not install any Python package — the solving
# agent's offline build/test path is pure Go and needs nothing from pip.
if [[ -x /opt/tooling/venv/bin/python ]]; then
    /opt/tooling/venv/bin/python -c 'import pytest' 2>/dev/null \
        && echo "test-setup.sh: canonical verifier venv present" \
        || echo "test-setup.sh: warning — verifier venv missing pytest" >&2
fi

# Make sure the packages the reward stack targets compile under our test tags.
# `go vet` runs the typechecker and compiles the _test.go variants without
# executing TestMain, so it warms the cache offline without a test DB.
go vet -tags 'sqlite sqlite_unlock_notify' \
    ./models/deploykey/... \
    ./models/perm/access/... \
    ./models/user/... \
    ./services/auth/... \
    ./services/lfs/... \
    ./services/convert/... \
    ./routers/api/v1/... \
    ./routers/private/... \
    ./routers/web/repo/... \
    ./tests/integration/... \
    >/dev/null 2>&1 || true

echo "test-setup.sh: ready (CGO_ENABLED=$CGO_ENABLED, tags='sqlite sqlite_unlock_notify', GOPROXY=$(go env GOPROXY))"
