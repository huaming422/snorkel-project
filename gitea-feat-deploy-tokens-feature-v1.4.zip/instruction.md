## Task

Repos can get deploy keys for SSH, but not for HTTPS. Anything that clones or pushes over HTTPS must use a full user account.

Add a repo-level credential for HTTPS. The client sends it as the password on a Git request. Each one is either read-only or read/write, covers plain Git and Git LFS, and can have its secret rotated without being recreated. Repo admins should be able to manage them from the repo's settings page and from the REST API.

## User stories / requirements

- A credential is only valid for the repo it is made for. A read-only one can fetch, but a push with it is refused. A read/write one can both fetch and push. Branch protection treats a credential like a deploy key. A read/write credential can push to a protected branch that lets anyone with write access push. If the branch limits pushing to a list of users, the credential can push only when the branch also lets deploy keys push.
- Using a credential doesn't turn the holder into the repo's owner. It gets Git and LFS into its own repository and nothing else. Access to other repositories is blocked, and other privileges granted to the owner are blocked as well.
- The secret is visible a single time, when the credential is made, and it can't be seen afterward. Rotating swaps in a new secret while the credential keeps its name and its level.
- LFS has the same limits as regular Git. A credential can't reach another repository's LFS objects, and a read-only credential can download objects but not upload them.
- Only repo admins can list, create and delete these credentials through the REST API.
- A repo admin can also create a credential on the repo's settings page, which shows the new secret once, and rotate it from the same page. The secret the page shows works over HTTPS at the level picked there, and after a rotation only the new secret works.
- SSH deploy keys keep working as before, including keys added before the upgrade. Repo admins can still add, list and delete them through the REST API. Over SSH a key still only reaches its own repo, where a read-only key can fetch but not push and a read/write key can push.
