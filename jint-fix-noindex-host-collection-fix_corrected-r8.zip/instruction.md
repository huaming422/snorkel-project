## Task

With a `Queue<int>` containing 1, 2, 3 exposed as `host`, evaluating `Array.prototype.join.call(host, '-')` throws `System.InvalidCastException` back to the calling C# code. Putting the expression inside JavaScript `try/catch` does not catch it.

Please fix this. The rest of the collection behavior should stay the same.
