## Task

Virtual generated columns are returning inconsistent results. With `a TEXT`
and `b AS (a > 5)`, the value `'10'` should give `b = 0`, but queries and
indexes disagree. Selecting a generated column that calls `union_tag(val)`
also crashes instead of returning its tag. Please investigate these problems
and fix generated-column evaluation wherever it is used, including index
creation and maintenance, joins, integrity checks, and INSERT/UPDATE/DELETE
RETURNING. Keep comparisons correct for each source column's type, and keep
rejecting NULL generated values on both INSERT and UPDATE when the column is
NOT NULL.

Triggers have a related comparison problem: an ordinary TEXT `NEW.a` or
`OLD.a` containing `'5'` matches `= 5`, although it shouldn't. The numeric
case matters too: an ordinary INTEGER column containing `5` shouldn't match
`= '5'` through NEW or OLD. These references have no comparison affinity,
including generated columns, in WHEN guards and body WHERE/HAVING clauses;
normal storage conversions still apply. Rowid and INTEGER PRIMARY KEY
aliases are the exception: both NEW and OLD values of `1` still match `'1'`.
Please cover these cases while preserving the existing generated-column and
trigger behavior.
