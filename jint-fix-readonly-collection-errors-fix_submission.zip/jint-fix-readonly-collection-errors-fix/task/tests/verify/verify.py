"""Behavioral verifier for the read-only host-collection refusal contract.

The behavior under test lives in the embedding engine's .NET assembly, so the
only honest way to observe it is from a .NET embedder's vantage point: build a
tiny standalone program that references the freshly rebuilt engine assembly and
drives it through the public embedding surface (the engine object, its options,
the value binder, and the evaluate entry point) — exactly the surface a host
application uses, with no access to engine internals.

`test-setup.sh` rebuilds the engine and exports JINT_DLL (the path to the built
assembly). This module writes a throwaway console program next to a project file
under a temp directory (NOT under the repository tree, so it inherits none of the
repo's build settings), references the built assembly and its siblings, builds it
once, then runs it once per behavioral group.

The probe classifies each attempted mutation by what the *script* sees: a
`TypeError` the script's own `try/catch` caught, a silent no-op, or a value read
back afterwards. Around the evaluate call the probe catches only the engine's own
script-error type; any other CLR exception is left to tear out of the evaluate
call unhandled, which crashes the probe with a non-zero exit — that crash is the
pre-fix defect made visible, and it fails the corresponding test. The probe never
blanket-catches the base exception type, because doing so would hide exactly the
leak these tests exist to catch.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# The standalone embedder program. One argument selects a behavioral group; it
# prints a single JSON line of {case -> outcome} and exits 0. If a mutation
# leaks a non-script CLR exception out of the evaluate call, the program exits
# non-zero (unhandled), which the tests read as a failure for that group.
# ---------------------------------------------------------------------------
PROBE_SOURCE = r"""
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using Jint;
using Jint.Native;
using Jint.Runtime;

internal static class Probe
{
    private static Engine CreateEngine(object host, bool strict)
    {
        var engine = new Engine(options =>
        {
            options.Strict = strict;
            options.Interop.AllowWrite = true;
        });
        engine.SetValue("host", host);
        return engine;
    }

    // Classify a mutation by what the script catches: a caught TypeError, a
    // silent no-op, or some other script error. The host catch is deliberately
    // narrow (only the engine's script-error type); any other CLR exception is
    // left to propagate out of Evaluate and out of Main.
    private static string Classify(object host, string op, bool strict)
    {
        var engine = CreateEngine(host, strict);
        try
        {
            return engine.Evaluate(Script(op, strict)).AsString();
        }
        catch (JavaScriptException)
        {
            return "host-js-exception";
        }
    }

    // Like Classify, but when no error is thrown it reads an expression back so
    // the caller can confirm what the value became (e.g. element unchanged, or
    // element written through).
    private static string ClassifyValue(object host, string op, string readExpr, bool strict)
    {
        var engine = CreateEngine(host, strict);
        try
        {
            return engine.Evaluate(ScriptValue(op, readExpr, strict)).AsString();
        }
        catch (JavaScriptException)
        {
            return "host-js-exception";
        }
    }

    private static string Script(string op, bool strict)
    {
        var prologue = strict ? "'use strict';\n" : "";
        return prologue
            + "(function () { try { " + op + "; return 'no-throw'; } "
            + "catch (e) { return e instanceof TypeError ? 'TypeError' : 'unexpected:' + e; } })()";
    }

    private static string ScriptValue(string op, string readExpr, bool strict)
    {
        var prologue = strict ? "'use strict';\n" : "";
        return prologue
            + "(function () { try { " + op + "; return 'V:' + (" + readExpr + "); } "
            + "catch (e) { return e instanceof TypeError ? 'TypeError' : 'unexpected:' + e; } })()";
    }

    // A host sequence that offers reads only — no writing member of any kind —
    // so the engine must supply the refusal itself. Reaches the engine through a
    // different wrapper path than a mutable-looking list that merely declares
    // itself unmodifiable.
    private sealed class HostReadOnlySequence : IReadOnlyList<int>
    {
        private readonly List<int> _items;
        public HostReadOnlySequence(List<int> items) => _items = items;
        public int Count => _items.Count;
        public int this[int index] => _items[index];
        public IEnumerator<int> GetEnumerator() => _items.GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }

    private static object NewReadOnlyCollection() =>
        new ReadOnlyCollection<int>(new List<int> { 1, 2, 3 });

    private static object NewReadOnlySequence() =>
        new HostReadOnlySequence(new List<int> { 1, 2, 3 });

    // A non-generic read-only list — reaches the engine through yet another
    // wrapper path than the two above.
    private static object NewNonGenericReadOnlyList() =>
        ArrayList.ReadOnly(new ArrayList { 1, 2, 3 });

    private static object NewFixedSizeSegment() =>
        new ArraySegment<int>(new[] { 1, 2, 3 });

    private static object NewGrowableList() =>
        new List<int> { 1, 2, 3 };

    public static int Main(string[] args)
    {
        var which = args.Length > 0 ? args[0] : "";
        var r = new Dictionary<string, string>();

        switch (which)
        {
            case "catchable_refusal":
                r["push_sloppy"] = Classify(NewReadOnlyCollection(), "host.push(4)", false);
                r["push_strict"] = Classify(NewReadOnlyCollection(), "host.push(4)", true);
                break;

            case "per_operation_semantics":
                // length-changing generics: a caught TypeError in both modes
                r["push_sloppy"] = Classify(NewReadOnlyCollection(), "host.push(4)", false);
                r["push_strict"] = Classify(NewReadOnlyCollection(), "host.push(4)", true);
                // bare assignment / delete / length write: TypeError in strict,
                // silent and value-preserving in sloppy
                r["elem_write_strict"] = Classify(NewReadOnlyCollection(), "host[0] = 9", true);
                r["elem_write_sloppy"] = ClassifyValue(NewReadOnlyCollection(), "host[0] = 9", "host[0]", false);
                r["delete_strict"] = Classify(NewReadOnlyCollection(), "delete host[0]", true);
                r["delete_sloppy"] = ClassifyValue(NewReadOnlyCollection(), "delete host[0]", "host[0]", false);
                r["length_strict"] = Classify(NewReadOnlyCollection(), "host.length = 5", true);
                r["length_sloppy"] = ClassifyValue(NewReadOnlyCollection(), "host.length = 5", "host.length", false);
                break;

            case "fixed_size_carveout":
                // reports "cannot grow" yet accepts element writes: the write
                // goes through, only growth is refused with a caught TypeError
                r["elem_write"] = ClassifyValue(NewFixedSizeSegment(), "host[0] = 9", "host[0]", false);
                r["push"] = Classify(NewFixedSizeSegment(), "host.push(4)", false);
                break;

            case "two_lane":
                // the same refusal must hold across distinct wrapper paths — a
                // read-only collection reached as a mutable-shaped generic list,
                // a read-only sequence offering no writing member, and a
                // non-generic read-only list — so the fix is not a single-shape
                // patch. Each uses an operation that leaks a raw CLR exception on
                // the unfixed engine for THAT path.
                r["lane_a_push"] = Classify(NewReadOnlyCollection(), "host.push(4)", false);
                r["lane_b_pop"] = Classify(NewReadOnlySequence(), "host.pop()", false);
                r["lane_c_elem_write_strict"] = Classify(NewNonGenericReadOnlyList(), "host[0] = 9", true);
                break;

            case "growable_control":
                // the control: a genuinely growable list must keep growing and
                // keep accepting element writes — a fix that refuses writes too
                // broadly breaks this.
                r["grow"] = ClassifyValue(NewGrowableList(), "host.push(4)", "host.length", false);
                r["elem_write"] = ClassifyValue(NewGrowableList(), "host[0] = 9", "host[0]", false);
                break;

            default:
                Console.Error.WriteLine("unknown group: " + which);
                return 2;
        }

        Console.WriteLine(ToJson(r));
        return 0;
    }

    private static string ToJson(Dictionary<string, string> d)
    {
        var sb = new StringBuilder();
        sb.Append('{');
        var first = true;
        foreach (var kv in d)
        {
            if (!first)
            {
                sb.Append(',');
            }
            first = false;
            sb.Append('"').Append(Escape(kv.Key)).Append("\":\"").Append(Escape(kv.Value)).Append('"');
        }
        sb.Append('}');
        return sb.ToString();
    }

    private static string Escape(string s) =>
        s.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", "").Replace("\n", "\\n");
}
"""

PROBE_TIMEOUT = 300


def _dotnet() -> str:
    exe = shutil.which("dotnet")
    if exe:
        return exe
    for candidate in ("/usr/local/dotnet/dotnet", "/usr/share/dotnet/dotnet"):
        if Path(candidate).is_file():
            return candidate
    raise RuntimeError("dotnet CLI not found on PATH or in the usual locations")


def _engine_project() -> Path:
    """Locate the engine's own project file — the thing the probe references the
    way the repo's own public-surface suite does. The rebuilt-assembly check is a
    fast-fail that confirms test-setup.sh ran, but the reference itself is to the
    project so all transitive dependencies resolve into the probe's output."""
    env = os.environ.get("JINT_CSPROJ")
    if env and Path(env).is_file():
        return Path(env)
    for candidate in (
        "/repo/jint/Jint/Jint.csproj",
        "/repo/jint/jint/Jint.csproj",
    ):
        if Path(candidate).is_file():
            return Path(candidate)
    # Last resort: search for it under the repo root.
    hits = sorted(Path("/repo/jint").rglob("Jint.csproj"))
    hits = [h for h in hits if h.parent.name.lower() == "jint"]
    if hits:
        return hits[0]
    raise RuntimeError("could not locate the engine project file (Jint.csproj) under /repo/jint")


def _fastfail_rebuilt() -> None:
    """Confirm test-setup.sh rebuilt the engine (JINT_DLL points at a net10.0
    build), so a stale tree surfaces as a clear message rather than a slow build."""
    env = os.environ.get("JINT_DLL")
    if env and Path(env).is_file():
        return
    for root in ("/repo/jint/artifacts/bin/Jint", "/repo/jint/Jint/bin"):
        base = Path(root)
        if base.exists() and any("net10.0" in str(p) for p in base.rglob("Jint.dll")):
            return
    # Not fatal: the ProjectReference build below will compile the engine itself.
    # We only warn via an exception-free path; the build is the real gate.


def _write_project(work: Path) -> None:
    engine_csproj = _engine_project()
    csproj = f"""<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <TargetFramework>net10.0</TargetFramework>
    <Nullable>disable</Nullable>
    <ImplicitUsings>disable</ImplicitUsings>
    <TreatWarningsAsErrors>false</TreatWarningsAsErrors>
    <AssemblyName>collectionprobe</AssemblyName>
    <EnableDefaultCompileItems>true</EnableDefaultCompileItems>
    <RestorePackagesWithLockFile>false</RestorePackagesWithLockFile>
  </PropertyGroup>
  <ItemGroup>
    <ProjectReference Include="{engine_csproj}" />
  </ItemGroup>
</Project>
"""
    (work / "collectionprobe.csproj").write_text(csproj)
    (work / "Program.cs").write_text(PROBE_SOURCE)


@pytest.fixture(scope="session")
def probe_exe() -> Path:
    """Build the standalone embedder program once and return its built assembly."""
    _fastfail_rebuilt()
    work = Path(tempfile.mkdtemp(prefix="collection-probe-"))
    _write_project(work)

    env = {**os.environ}
    env.setdefault("DOTNET_CLI_TELEMETRY_OPTOUT", "1")
    env.setdefault("DOTNET_NOLOGO", "1")
    env.setdefault("DOTNET_SKIP_FIRST_TIME_EXPERIENCE", "1")
    env.setdefault("NUGET_PACKAGES", "/opt/nuget/packages")

    proc = subprocess.run(
        [_dotnet(), "build", "-c", "Release", "-v", "quiet", "--nologo"],
        cwd=str(work),
        capture_output=True,
        text=True,
        timeout=PROBE_TIMEOUT,
        env=env,
        check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            "probe build failed (exit "
            f"{proc.returncode})\nSTDOUT:\n{proc.stdout[-4000:]}\nSTDERR:\n{proc.stderr[-4000:]}"
        )

    built = work / "bin" / "Release" / "net10.0" / "collectionprobe.dll"
    if not built.is_file():
        raise RuntimeError(f"probe build reported success but {built} is missing")
    return built


def _run_group(probe_exe: Path, group: str) -> dict:
    """Run one behavioral group. On a clean run, return the parsed outcomes. On a
    leaked CLR exception (non-zero exit) or absent JSON, return a marker dict so
    the calling test fails with a readable message rather than erroring."""
    env = {**os.environ}
    env.setdefault("NUGET_PACKAGES", "/opt/nuget/packages")
    proc = subprocess.run(
        [_dotnet(), str(probe_exe), group],
        capture_output=True,
        text=True,
        timeout=PROBE_TIMEOUT,
        env=env,
        check=False,
    )
    if proc.returncode != 0:
        return {
            "__leak__": (
                f"the embedder program exited {proc.returncode} running group "
                f"'{group}' — a non-script CLR exception tore out of Evaluate.\n"
                f"STDERR:\n{proc.stderr[-2000:]}"
            )
        }
    line = ""
    for candidate in reversed(proc.stdout.strip().splitlines()):
        candidate = candidate.strip()
        if candidate.startswith("{"):
            line = candidate
            break
    if not line:
        return {"__leak__": f"group '{group}' produced no JSON.\nSTDOUT:\n{proc.stdout[-2000:]}"}
    return json.loads(line)


def _assert_clean(result: dict) -> None:
    assert "__leak__" not in result, result.get("__leak__")


def test_readonly_collection_refuses_length_change_catchably(probe_exe):
    """A read-only host collection refuses a length-changing mutation with a
    script-catchable TypeError, not a raw CLR exception escaping the evaluate call."""
    r = _run_group(probe_exe, "catchable_refusal")
    _assert_clean(r)
    assert r["push_sloppy"] == "TypeError", r
    assert r["push_strict"] == "TypeError", r


def test_refusal_is_per_operation_like_a_frozen_array(probe_exe):
    """Per-operation semantics matching a frozen array: length-changing generics
    throw in both modes; a bare element write / delete / length write throws in
    strict mode and is silent (value unchanged) in sloppy mode."""
    r = _run_group(probe_exe, "per_operation_semantics")
    _assert_clean(r)
    # length generics throw in both modes
    assert r["push_sloppy"] == "TypeError", r
    assert r["push_strict"] == "TypeError", r
    # strict assignments throw
    assert r["elem_write_strict"] == "TypeError", r
    assert r["delete_strict"] == "TypeError", r
    assert r["length_strict"] == "TypeError", r
    # sloppy assignments are silent and leave the value untouched
    assert r["elem_write_sloppy"] == "V:1", r
    assert r["delete_sloppy"] == "V:1", r
    assert r["length_sloppy"] == "V:3", r


def test_fixed_size_segment_keeps_element_writes(probe_exe):
    """A fixed-size shape that reports "cannot grow" still accepts element writes;
    only growth is refused (with a caught TypeError). It must not be classified as
    fully read-only, which would wrongly reject the element write."""
    r = _run_group(probe_exe, "fixed_size_carveout")
    _assert_clean(r)
    assert r["elem_write"] == "V:9", r   # element write goes through
    assert r["push"] == "TypeError", r   # growth refused catchably


def test_refusal_holds_across_two_wrapper_lanes(probe_exe):
    """The refusal holds across two distinct wrapper paths — a read-only
    collection reached as a mutable-shaped list, and a read-only sequence that
    offers no writing member at all — so the fix is not a single-shape patch."""
    r = _run_group(probe_exe, "two_lane")
    _assert_clean(r)
    assert r["lane_a_push"] == "TypeError", r
    assert r["lane_b_pop"] == "TypeError", r


def test_growable_list_still_grows(probe_exe):
    """Regression control: a genuinely growable host list keeps growing and keeps
    accepting element writes. Nothing above may be bought by refusing writes that
    were always legitimate."""
    r = _run_group(probe_exe, "growable_control")
    _assert_clean(r)
    assert r["grow"] == "V:4", r          # push appended -> length 4
    assert r["elem_write"] == "V:9", r    # element write went through
