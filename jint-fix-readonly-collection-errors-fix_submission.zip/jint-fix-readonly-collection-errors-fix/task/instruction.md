## Task

we expose a read-only .NET collection into script, with interop writes on and arrays handed over as live views. when script mutates that collection (`push`, `pop`, `splice`, `x[0] = 9`, `delete x[0]`, setting `length`), a raw CLR exception flies out of `engine.Evaluate(...)`: usually `System.NotSupportedException`, sometimes `System.ArgumentOutOfRangeException`. nothing catches it, not a script `try`/`catch`, not the host's `catch (JavaScriptException)` around `Evaluate`.

the odd part: a read-only CLR *array* (a plain `int[]`, which also can't grow) refuses with an ordinary, script-catchable error. only read-only *collections* leak the raw CLR exception.

a refused write on a read-only host collection should surface as a script-catchable `TypeError`, like the array case. dig in and fix it.

leave alone a growable `List<int>` that refuses a past-the-end write with `ArgumentOutOfRangeException`; that's a separate, pre-existing inconsistency.

the repo is at `/repo/jint` with the .NET 10 SDK on PATH and a warm package cache, so everything builds offline. you can work entirely through the public embedder surface (`Engine`, `Options`, `SetValue`, `Evaluate`), the way `Jint.Tests.PublicInterface` does.
