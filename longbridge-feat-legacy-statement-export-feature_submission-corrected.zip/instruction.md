## Task

`longbridge statement` only copes with statements from 2024-08 on. A customer went back further and nothing older worked. Some exports came out as empty tables, others stopped with `invalid type: null, expected a sequence`. For a long run of months there's nothing structured at all, just a password-protected PDF. `statement list` shows a blank `file_key` there, and a guessed key dies with `expected value at line 1 column 1`.

PDF password: the phone number's final four digits, then the final four letters or digits from the ID the account was opened with, in capitals. `13800138000` and `g123456(a)` give `8000456A`.

Every period should show up in `statement list` and export with `statement export`.

## User stories / requirements

- Older files that the current sections don't fit use a layout that changes from file to file. Exporting one shows every value in it as tables: markdown to stdout, one CSV per table under `-o <dir>`, and JSON with `--format json`. Rows inside a parent entry keep its fields, like a holding's market.
- If a download isn't statement JSON, like an XML or HTML error or an empty body, export fails showing the status code, the content type and the start of the body, and says that statement may only exist as a PDF. A blank `--file-key` gets told to choose a row in `statement list`.
- A file that sends empty sections as `null` still exports, and each balance shows its currency. With `--section`, only those sections come out, and one section with `-o asset.csv` goes to that file, not a directory. Without `--section`, every section with rows comes out.
- `statement list` also shows the periods that only have a PDF, with a Format column saying `json` or `pdf`, and a period with a structured file keeps it. The statements API lists the PDFs at `GET /v1/statement/pdf/list` as an `items` array, each with a `display_name` like `2024.03` and the `key` to export it by.
- PDFs stop at 2024-12, and every period from 2025-01 has a structured file. Each PDF lookup is one more API call, so `statement list` only makes it when a PDF could fill a row the structured list leaves blank or out.
- A `.pdf` key exports by writing the PDF to the `-o` file or directory (ending in `/` or existing), else to the working directory under its file name, then printing the unlock rule. `GET /v1/statement/pdf/download?key=<key>` hands out a presigned `url` and a `cache_key`. `--format json` gives back the path, the `cache_key` and the rule.
