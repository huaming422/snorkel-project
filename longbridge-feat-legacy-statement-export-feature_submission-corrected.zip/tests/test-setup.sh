#!/usr/bin/env bash
# Setup for longbridge-feat-legacy-statement-export, run before the checks.
#
# There are no services to start and no data to seed: the checks run the
# compiled `longbridge` CLI against a local stand-in for the statements API
# that each check starts itself. The image already holds the full dependency
# closure (cargo registry warmed and the workspace built in
# environment/Dockerfile block 7), so a later `cargo build` or `cargo test`
# is incremental and works with the network cut.
#
# CARGO_NET_OFFLINE makes an offline cache miss fail fast instead of hanging
# on a dead network. It is set here for this repository's cargo calls rather
# than image-wide, so tools installed while the network is still up are not
# affected.
set -euo pipefail

export CARGO_NET_OFFLINE=true

echo "[test-setup] Rust:   $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo:  $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Repo:   /repo/longbridge-terminal"
echo "[test-setup] Setup complete."
