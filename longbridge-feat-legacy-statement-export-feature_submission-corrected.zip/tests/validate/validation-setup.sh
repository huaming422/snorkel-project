#!/usr/bin/env bash
# Validation setup: runs after the edits are in place and before the
# validation stories. One job: build the `longbridge` CLI binary from the
# edited tree and record its absolute path for the harness.
#
# The binary has to be a DEBUG build: the LONGBRIDGE_HTTP_URL redirect the
# stories rely on lives in a `cfg!(debug_assertions)` branch in
# src/openapi/context.rs, so a release build would ignore it and try the live
# API. `cargo build` (no --release) is a debug build.
#
# test.sh sources this file, so it never calls `exit` and never turns on
# `set -e`: either would end test.sh itself. When the build fails it leaves no
# binary path behind, the harness then reports that no binary was built, and
# every story fails with that message.

REPO=/repo/longbridge-terminal

# Match environment/Dockerfile's ENV block; default defensively.
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export PATH="$CARGO_HOME/bin:$PATH"
export CARGO_NET_OFFLINE=true

rm -f /tmp/longbridge_bin_path

echo "validation-setup: rustc=$(rustc --version 2>&1 | head -1)"
echo "validation-setup: CARGO_TARGET_DIR=$CARGO_TARGET_DIR"
echo "validation-setup: building longbridge (debug, incremental)..."
if ( cd "$REPO" && cargo build --locked --bin longbridge > /tmp/validation_build.log 2>&1 ); then
    _lb_bin=""
    for _lb_cand in "$CARGO_TARGET_DIR/debug/longbridge" "$REPO/target/debug/longbridge"; do
        if [ -x "$_lb_cand" ]; then _lb_bin="$_lb_cand"; break; fi
    done
    if [ -n "$_lb_bin" ] && "$_lb_bin" --version >/dev/null 2>&1; then
        printf '%s\n' "$_lb_bin" > /tmp/longbridge_bin_path
        echo "validation-setup: built $_lb_bin ($("$_lb_bin" --version 2>&1 | head -1))"
    else
        echo "ERROR: no runnable longbridge binary after the build" >&2
    fi
else
    echo "ERROR: cargo build failed; last 80 lines:" >&2
    tail -80 /tmp/validation_build.log >&2
fi
echo "validation-setup: done."
