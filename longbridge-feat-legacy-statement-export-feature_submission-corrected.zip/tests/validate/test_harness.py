"""Helpers for the `longbridge statement` validation stories.

Each story runs the debug `longbridge` binary that validation-setup.sh built
against a small HTTP server on 127.0.0.1 that plays the statements API, with
no network. LONGBRIDGE_HTTP_URL points the debug binary at that server, a
plain JSON token under HOME logs it in, and a token that expires in 2100 plus
LONGBRIDGE_REGION=global keep it from refreshing or probing anything.

The server answers these routes, each wrapped in the API's success envelope
{"code": 0, "message": "", "data": ...}:

  GET /v1/statement/list           the structured statement list
  GET /v1/statement/download       a presigned url that points back here
  GET /v1/statement/pdf/list       the PDF statements, as {"items": [...]}
  GET /v1/statement/pdf/download   a presigned url and cache_key for one PDF key
  GET /file/<name>                 the bytes behind a presigned url

The PDF list returns every staged PDF in one answer. It narrows the answer to a
kind (0 daily, 1 monthly), a month range (start_dt, end_dt as yyyyMM) or a page
(page from 1, as many items as size, page_size, pageSize or limit asks for, 100
when none of them is sent) only when a request sends those parameters.

Every request is recorded, so a story can count the calls to a route.

The observe_* functions at the end each run one story case and return the
values that the story's EXPECTED lines compare.
"""

from __future__ import annotations

import datetime
import json
import os
import re
import subprocess
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlparse

REPO_DIR = "/repo/longbridge-terminal"

# validation-setup.sh writes the path of the binary it built here.
_BIN_PATH_FILE = "/tmp/longbridge_bin_path"


def timeout_multiplier() -> float:
    try:
        return max(1.0, float(os.environ.get("TIMEOUT_MULTIPLIER") or 1))
    except ValueError:
        return 1.0


def longbridge_bin() -> str:
    """Absolute path of the debug `longbridge` binary built from the tree under test."""
    override = os.environ.get("LONGBRIDGE_BIN", "").strip()
    if override and Path(override).is_file():
        return override
    try:
        p = Path(_BIN_PATH_FILE).read_text(encoding="utf-8").strip()
    except OSError:
        p = ""
    if p and Path(p).is_file():
        return p
    raise AssertionError(
        f"no longbridge binary: {_BIN_PATH_FILE} is missing or names no file, "
        "so the build in validation-setup.sh did not produce one"
    )


# ---------------------------------------------------------------------------
# Offline auth token
# ---------------------------------------------------------------------------

_FAR_FUTURE_EXPIRES_AT = 4102444800  # 2100-01-01


def seed_token(home: str | os.PathLike[str]) -> None:
    """Write a plain JSON auth token under HOME so the CLI starts without a login."""
    token_dir = Path(home) / ".longbridge" / "openapi"
    token_dir.mkdir(parents=True, exist_ok=True)
    token = {
        "client_id": "test-client",
        "access_token": "test-access-token",
        "refresh_token": "test-refresh-token",
        "expires_at": _FAR_FUTURE_EXPIRES_AT,
        "logged_in_at": 1600000000,
    }
    (token_dir / "cli-auth").write_text(json.dumps(token), encoding="utf-8")


# ---------------------------------------------------------------------------
# The statements API
# ---------------------------------------------------------------------------

STATEMENT_LIST_PATH = "/v1/statement/list"
STATEMENT_DOWNLOAD_PATH = "/v1/statement/download"
PDF_LIST_PATH = "/v1/statement/pdf/list"
PDF_DOWNLOAD_PATH = "/v1/statement/pdf/download"
PDF_PAGE_DEFAULT = 100
# Any of these names the page size of a PDF list request.
PDF_PAGE_SIZE_PARAMS = ("size", "page_size", "pageSize", "limit")


def _envelope(data: object, code: int = 0, message: str = "") -> bytes:
    return json.dumps({"code": code, "message": message, "data": data}).encode("utf-8")


def _month(value: str | None) -> int | None:
    digits = re.sub(r"\D", "", value or "")
    return int(digits[:6]) if len(digits) >= 6 else None


def pdf_key(display_name: str) -> str:
    """The key the PDF list gives a statement, e.g. 2024.03 or 2024.03.19."""
    digits = display_name.replace(".", "")
    kind = "daily" if len(digits) == 8 else "monthly"
    return f"*lb-statement*lb*1*{digits}*statement-{kind}-{digits}-H10062184.pdf"


def pdf_file_name(key: str) -> str:
    return key.rsplit("*", 1)[-1]


def pdf_cache_key(display_name: str) -> str:
    return "ck-" + display_name.replace(".", "") + "-7f3a"


PDF_BYTES = b"%PDF-1.4\n% longbridge statement test document\n1 0 obj << >> endobj\n%%EOF\n"


class MockStatementServer:
    """The statements API on 127.0.0.1. Use it as a context manager."""

    def __init__(self) -> None:
        self.requests: list[dict] = []
        self._lock = threading.Lock()
        self._statement_list: list[dict] = []
        self._download_body = b""
        self._download_status = 200
        self._download_content_type = "application/json"
        self._pdfs: list[dict] = []
        self._files: dict[str, tuple[bytes, str]] = {}
        self._server: ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None

    # -- data ---------------------------------------------------------------

    def set_statement_list(self, entries: list[dict]) -> None:
        """entries: [{"dt": int, "file_key": str}, ...]; dt is yyyymm or yyyymmdd."""
        self._statement_list = entries

    def set_download_body(self, body: bytes | str, status: int = 200,
                          content_type: str = "application/json") -> None:
        """What the presigned url of /v1/statement/download serves."""
        self._download_body = body.encode("utf-8") if isinstance(body, str) else body
        self._download_status = status
        self._download_content_type = content_type

    def add_pdf(self, display_name: str, body: bytes = PDF_BYTES) -> dict:
        """A PDF statement; `2024.03` is monthly, `2024.03.19` daily."""
        digits = display_name.replace(".", "")
        item = {
            "kind": "daily" if len(digits) == 8 else "monthly",
            "month": int(digits[:6]),
            "display_name": display_name,
            "key": pdf_key(display_name),
            "cache_key": pdf_cache_key(display_name),
            "body": body,
        }
        self._pdfs.append(item)
        return item

    # -- urls and request log ----------------------------------------------

    @property
    def base_url(self) -> str:
        assert self._server is not None, "server not started"
        return f"http://127.0.0.1:{self._server.server_address[1]}"

    def file_url(self, name: str) -> str:
        return f"{self.base_url}/file/{quote(name)}"

    def _record(self, path: str, query: dict) -> None:
        with self._lock:
            self.requests.append({"path": path, "query": query})

    def calls(self, path: str) -> list[dict]:
        with self._lock:
            return [r for r in self.requests if r["path"] == path]

    # -- answers ------------------------------------------------------------

    def _pdf_list_page(self, query: dict) -> dict:
        items = sorted(self._pdfs, key=lambda p: p["display_name"])
        kind = query.get("kind")
        if kind in ("0", "1"):
            wanted = "daily" if kind == "0" else "monthly"
            items = [p for p in items if p["kind"] == wanted]
        start, end = _month(query.get("start_dt")), _month(query.get("end_dt"))
        if start is not None:
            items = [p for p in items if p["month"] >= start]
        if end is not None:
            items = [p for p in items if p["month"] <= end]
        size_param = next((name for name in PDF_PAGE_SIZE_PARAMS if name in query), None)
        if "page" not in query and size_param is None:
            return {"items": [{"display_name": p["display_name"], "key": p["key"],
                               "cache_key": p["cache_key"]} for p in items]}
        try:
            page = max(1, int(query.get("page") or 1))
        except ValueError:
            page = 1
        try:
            size = max(1, int(query.get(size_param) or PDF_PAGE_DEFAULT)) if size_param else PDF_PAGE_DEFAULT
        except ValueError:
            size = PDF_PAGE_DEFAULT
        chunk = items[(page - 1) * size: page * size]
        return {"items": [{"display_name": p["display_name"], "key": p["key"],
                           "cache_key": p["cache_key"]} for p in chunk]}

    def __enter__(self) -> "MockStatementServer":
        server = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_args):
                pass

            def _send(self, status: int, body: bytes, content_type: str) -> None:
                self.send_response(status)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_GET(self):  # noqa: N802
                parsed = urlparse(self.path)
                path = parsed.path.rstrip("/") or "/"
                query = {k: v[0] for k, v in parse_qs(parsed.query, keep_blank_values=True).items()}
                server._record(path, query)

                if path.startswith("/file/"):
                    name = path[len("/file/"):]
                    if name in server._files:
                        body, ct = server._files[name]
                        self._send(200, body, ct)
                    else:
                        self._send(server._download_status, server._download_body,
                                   server._download_content_type)
                    return
                if path == PDF_LIST_PATH:
                    self._send(200, _envelope(server._pdf_list_page(query)), "application/json")
                    return
                if path == PDF_DOWNLOAD_PATH:
                    match = [p for p in server._pdfs if p["key"] == query.get("key")]
                    if not match:
                        self._send(200, _envelope(None, 404001, "statement file not found"),
                                   "application/json")
                        return
                    item = match[0]
                    name = f"pdf-{server._pdfs.index(item)}/{pdf_file_name(item['key'])}"
                    server._files[name] = (item["body"], "application/pdf")
                    url = server.file_url(name) + "?X-Amz-Expires=600&X-Amz-Signature=3f9c"
                    self._send(200, _envelope({"url": url, "cache_key": item["cache_key"]}),
                               "application/json")
                    return
                if path == STATEMENT_LIST_PATH:
                    self._send(200, _envelope({"list": server._statement_list}), "application/json")
                    return
                if path == STATEMENT_DOWNLOAD_PATH:
                    url = server.file_url("statement-body") + "?X-Amz-Expires=600"
                    self._send(200, _envelope({"url": url}), "application/json")
                    return
                self._send(200, _envelope({}), "application/json")

            def do_POST(self):  # noqa: N802
                self.do_GET()

        self._server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *_exc) -> None:
        if self._server is not None:
            self._server.shutdown()
            self._server.server_close()
        if self._thread is not None:
            self._thread.join(timeout=5)


# ---------------------------------------------------------------------------
# Running the CLI
# ---------------------------------------------------------------------------


def merged_env(mock: MockStatementServer, home: str | os.PathLike[str]) -> dict:
    env = {**os.environ}
    env["HOME"] = str(home)
    env["LONGBRIDGE_HTTP_URL"] = mock.base_url
    env["LONGBRIDGE_REGION"] = "global"
    env.pop("LONGBRIDGE_ENV", None)
    env["CARGO_NET_OFFLINE"] = "true"
    return env


def run_cli(args: list[str], mock: MockStatementServer, home: str | os.PathLike[str],
            cwd: str | os.PathLike[str] | None = None, timeout: int = 60) -> subprocess.CompletedProcess:
    """Run `longbridge <args>` against the mock; `cwd` defaults to `home`."""
    return subprocess.run(
        [longbridge_bin()] + args,
        cwd=str(cwd) if cwd is not None else str(home),
        env=merged_env(mock, home),
        capture_output=True,
        text=True,
        timeout=int(timeout * timeout_multiplier()),
        check=False,
    )


def combined_output(proc: subprocess.CompletedProcess) -> str:
    return (proc.stdout or "") + (proc.stderr or "")


def try_parse_json(text: str) -> object | None:
    """Parse `text` as JSON, or the largest object or array inside it, else None."""
    text = (text or "").strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    m = re.search(r"(\{.*\}|\[.*\])", text, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(1))
        except json.JSONDecodeError:
            return None
    return None


# ---------------------------------------------------------------------------
# Small readers shared by the stories
# ---------------------------------------------------------------------------


def _has_word(text: str, word: str) -> bool:
    return re.search(r"(?<![A-Za-z0-9])" + re.escape(word) + r"(?![A-Za-z0-9])", text) is not None


def _leaves(value: object, keys: bool = False) -> list[str]:
    """Every scalar under `value` as a string; with `keys`, every object key too."""
    if isinstance(value, dict):
        return [s for k, v in value.items() for s in ([str(k)] if keys else []) + _leaves(v, keys)]
    if isinstance(value, list):
        return [s for v in value for s in _leaves(v, keys)]
    if value is None:
        return []
    return [str(value)]


def _containers(value: object) -> list[object]:
    """Every object and array under `value`, plus each object entry on its own
    (as a one-entry object), so a key that names a group goes with what it holds."""
    found: list[object] = []
    if isinstance(value, (dict, list)):
        found.append(value)
        if isinstance(value, dict):
            found.extend({k: v} for k, v in value.items())
        children = value.values() if isinstance(value, dict) else value
        for child in children:
            found.extend(_containers(child))
    return found


def rows_keep_parent_in_text(text: str, pairs: list[list[str]], same_line: bool) -> bool:
    """Each [child, parent] pair: the line naming `child` names `parent` too, or,
    when `same_line` is False, the nearest earlier line naming any parent of the
    set names `parent` alone (a heading per parent)."""
    lines = text.splitlines()
    parents = {p for _, p in pairs}
    for child, parent in pairs:
        idx = next((i for i, line in enumerate(lines) if _has_word(line, child)), None)
        if idx is None:
            return False
        named = [p for p in parents if _has_word(lines[idx], p)]
        if named == [parent]:
            continue
        if named or same_line:
            return False
        for j in range(idx - 1, -1, -1):
            named = [p for p in parents if _has_word(lines[j], p)]
            if named:
                if named != [parent]:
                    return False
                break
        else:
            return False
    return True


def rows_keep_parent_in_json(doc: object, pairs: list[list[str]]) -> bool:
    """Each [child, parent] pair sits in one JSON object, array or object entry
    that holds `child` and `parent`, as a value or as a key (records grouped
    under a market key count), and no other parent of the set."""
    parents = {p for _, p in pairs}
    boxes = _containers(doc)
    for child, parent in pairs:
        ok = False
        for box in boxes:
            leaves = set(_leaves(box, keys=True))
            if child in leaves and parent in leaves and not (leaves & (parents - {parent})):
                ok = True
                break
        if not ok:
            return False
    return True


def states_unlock_rule(text: str) -> bool:
    """The text states the unlock rule: it names both inputs, the mobile (or
    phone) number and the ID, and gives the steps: four characters, taken from
    the end, letters or digits, in capitals. Each step takes the usual synonyms
    in any wording and order. Instead of the steps it may quote the
    instruction's example result, 8000456A. A bare "number" doesn't count as
    the letters-or-digits step, since "phone number" would always supply it.
    Whether the steps are put together in the right order is the rubric's."""
    low = (text or "").lower()
    names_inputs = (
        re.search(r"mobile|phone|\bcell", low) is not None
        and re.search(r"\bids?\b|hkid|identif|identity|passport", low) is not None
    )
    gives_steps = (
        re.search(r"\b4\b|four", low) is not None
        and re.search(r"last|final|\bend|trailing|rightmost", low) is not None
        and re.search(r"letter|char|alpha|digit|numer", low) is not None
        and re.search(r"upper|capital|\bcaps\b", low) is not None
    )
    return names_inputs and (gives_steps or "8000456a" in low)


def _require_filled(name: str, value: object) -> None:
    values = value.values() if isinstance(value, dict) else [value]
    if any(v is ... for v in values):
        raise AssertionError(f"{name} in the story file still has a placeholder; fill it from the diff")


def _dig(record: object, path: str | None) -> object:
    """The value at a dotted path such as "statement.file" in parsed JSON, or None."""
    if not path:
        return None
    for part in path.split("."):
        if isinstance(record, dict) and part in record:
            record = record[part]
        else:
            return None
    return record


def _table_rows(text: str) -> list[list[str]]:
    rows = []
    for line in text.splitlines():
        line = line.strip()
        if not line.startswith("|"):
            continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        if all(re.fullmatch(r":?-+:?", c or "-") for c in cells):
            continue
        rows.append(cells)
    return rows


def _list_rows(stdout: str, as_json: bool) -> list[list[str]]:
    if not as_json:
        return _table_rows(stdout)
    doc = try_parse_json(stdout)
    if isinstance(doc, dict):
        doc = next((v for v in doc.values() if isinstance(v, list)), [])
    if not isinstance(doc, list):
        return []
    return [_leaves(rec) for rec in doc if isinstance(rec, dict)]


def _row_for(rows: list[list[str]], date: str) -> list[str] | None:
    for cells in rows:
        if any(re.sub(r"[.\-/]", "", c) == date for c in cells):
            return cells
    return None


def _format_of(cells: list[str]) -> str:
    for c in cells:
        if c.lower() in ("json", "pdf"):
            return c.lower()
    return "-"


def _named_records(stdout: str, as_json: bool, names: dict) -> list[dict]:
    """The list's rows as {"date", "key", "format"}, read by the column names a
    story's adapter gives: header labels for the table, record keys for JSON."""
    fields = ("date", "key", "format")
    if as_json:
        doc = try_parse_json(stdout)
        if isinstance(doc, dict):
            doc = next((v for v in doc.values() if isinstance(v, list)), [])
        records = [r for r in doc if isinstance(r, dict)] if isinstance(doc, list) else []
        out = []
        for rec in records:
            row = {}
            for f in fields:
                value = _dig(rec, names.get(f))
                row[f] = "" if value is None else str(value)
            out.append(row)
        return out
    rows = _table_rows(stdout)
    if not rows:
        return []
    header = [c.lower() for c in rows[0]]
    index = {}
    for f in fields:
        label = (names.get(f) or "").strip().lower()
        index[f] = header.index(label) if label and label in header else None
    return [{f: (cells[i] if i is not None and i < len(cells) else "") for f, i in index.items()}
            for cells in rows[1:]]


# ---------------------------------------------------------------------------
# Statement documents the stories serve
# ---------------------------------------------------------------------------

# Older layout: no Asset block; rows sit inside per-market entries.
LEGACY_DOCS = {
    "stock_holdings": {
        "doc": {
            "Date": "2021.11.30",
            "AssetDetail": {"Cash": "5310.25", "Total": "88123.40"},
            "CashDetails": {
                "Currency": "HKD",
                "CashDetail": [
                    {"Currency": "HKD", "Amount": "4410.25"},
                    {"Currency": "USD", "Amount": "900.00"},
                ],
            },
            "StockHoldingDetails": [
                {"Market": "US", "StockHolding": [{"StName": "DAL", "Total": "199"}]},
                {"Market": "HK", "StockHolding": [{"StName": "00175", "Total": "1000"}]},
            ],
            "Empty": None,
            "Nothing": [],
        },
        "values": ["2021.11.30", "5310.25", "88123.40", "4410.25", "900.00",
                   "DAL", "199", "00175", "1000"],
        "pairs": [["DAL", "US"], ["00175", "HK"]],
    },
    "fund_holdings": {
        "doc": {
            "Date": "2022.01.31",
            "AssetDetail": {"Cash": "77.10", "Total": "6420.55"},
            "FundHoldingDetails": [
                {"Market": "US", "FundHolding": [
                    {"FundName": "QQQX", "Units": "12.5"},
                    {"FundName": "VTIP", "Units": "40.125"},
                ]},
                {"Market": "SG", "FundHolding": [{"FundName": "ES3", "Units": "300"}]},
            ],
            "TradeDetails": [
                {"Market": "HK", "Trade": [{"StName": "00700", "Qty": "1713", "Price": "301.40"}]},
            ],
            "IpoDetails": None,
        },
        "values": ["2022.01.31", "77.10", "6420.55", "QQQX", "12.5", "VTIP", "40.125",
                   "ES3", "300", "00700", "1713", "301.40"],
        "pairs": [["QQQX", "US"], ["VTIP", "US"], ["ES3", "SG"], ["00700", "HK"]],
    },
    "option_holdings": {
        "doc": {
            "Date": "2021.12.31",
            "AssetDetail": {"Cash": "12.75", "Total": "5550.00"},
            "OptionHoldingDetails": [
                {"Market": "US", "OptionHolding": [{"Contract": "AAPL240119C150", "Qty": "2"}]},
                {"Market": "HK", "OptionHolding": [{"Contract": "TCH240130C380", "Qty": "5"}]},
            ],
        },
        "values": ["2021.12.31", "12.75", "5550.00", "AAPL240119C150", "TCH240130C380"],
        "pairs": [["AAPL240119C150", "US"], ["TCH240130C380", "HK"]],
    },
}

# Current layout. Empty sections can come as null in files from 2022-03 to
# 2022-11, and their balances carry Currency without CurrencyCode.
CURRENT_DOCS = {
    "null_sections": {
        "Asset": {"Currency": "HKD", "Total": "123456.78"},
        "Interests": None,
        "FundTradeSums": None,
        "AccountBalanceSum": None,
        "EquityHoldingSums": None,
    },
    "null_inside_sections": {
        "Asset": {"Currency": "HKD", "Total": "123456.78"},
        "AccountBalanceSum": {"Currency": "HKD", "AccountBalances": None},
        "EquityHoldingSums": [{"Market": "US", "EquityHoldings": None}],
        "StockTradeSums": None,
    },
    "balance_currency_only": {
        "Asset": {"Currency": "HKD", "Total": "123456.78"},
        "AccountBalanceSum": {"AccountBalances": [
            {"Currency": "USD", "BeginAmount": "777.01"},
            {"Currency": "SGD", "BeginAmount": "35.90"},
        ]},
    },
    "three_sections": {
        "Asset": {"Currency": "HKD", "Total": "123456.78"},
        "AccountBalanceSum": {"AccountBalances": [{"CurrencyCode": "USD", "BeginAmount": "777.01"}]},
        "EquityHoldingSums": [{"Market": "US", "Currency": "USD", "EquityHoldings": [
            {"Code": "AAPL", "Name": "Apple", "LedgerQuantity": "15"},
        ]}],
    },
    "two_null_sections": {
        "Asset": {"Currency": "HKD", "Total": "123456.78"},
        "AccountBalanceSum": {"AccountBalances": [{"CurrencyCode": "USD", "BeginAmount": "777.01"}]},
        "StockTradeSums": None,
        "Corps": None,
    },
}

# Downloads that aren't statement JSON: (status, content type, body).
BAD_BODIES = {
    "xml_404": (404, "application/xml",
                '<?xml version="1.0" encoding="UTF-8"?><Error><Code>NoSuchKey</Code>'
                '<Message>The specified key does not exist.</Message></Error>'),
    "empty_200": (200, "application/octet-stream", ""),
    "csv_410": (410, "text/csv", "period,status\n202305,expired\n"),
    "html_403": (403, "text/html",
                 "<html><body><h1>403 Forbidden</h1><p>AccessDenied: Request has expired</p></body></html>"),
    "text_502": (502, "text/plain", "Bad Gateway: storage did not answer in time"),
}

STRUCTURED_KEY = "/statement_data/data/lb/1/{dt}/10000104.json"


def _structured(entries: list[list]) -> list[dict]:
    out = []
    for dt, key in entries:
        out.append({"dt": int(dt), "file_key": STRUCTURED_KEY.format(dt=dt) if key == "file" else key})
    return out


def _days(start: str, count: int) -> list[str]:
    day = datetime.date.fromisoformat(start)
    return [(day + datetime.timedelta(days=i)).strftime("%Y.%m.%d") for i in range(count)]


# ---------------------------------------------------------------------------
# Story observations
# ---------------------------------------------------------------------------


def observe_legacy_export(inputs: dict) -> dict:
    """Export an older-layout file (inputs["layout"]) in inputs["mode"]:
    "markdown" (stdout), "csv" (-o <dir>) or "json" (--format json)."""
    spec = LEGACY_DOCS[inputs["layout"]]
    mode = inputs["mode"]
    key = "/statement_data/data/lb/1/202111/10000104.json"
    with tempfile.TemporaryDirectory() as home:
        seed_token(home)
        with MockStatementServer() as mock:
            mock.set_download_body(json.dumps(spec["doc"]), content_type="application/json")
            args = ["statement", "export", "--file-key", key]
            outdir = os.path.join(home, "tables")
            if mode == "json":
                args = ["--format", "json"] + args
            if mode == "csv":
                args += ["-o", outdir]
            proc = run_cli(args, mock, home)
        if mode == "csv":
            csvs = sorted(Path(outdir).glob("*.csv")) if os.path.isdir(outdir) else []
            text = "\n".join(p.read_text(encoding="utf-8", errors="replace") for p in csvs)
            form_ok = len(csvs) >= 2
            keeps_parent = rows_keep_parent_in_text(text, spec["pairs"], same_line=True)
        elif mode == "json":
            text = proc.stdout or ""
            doc = try_parse_json(text)
            form_ok = isinstance(doc, (dict, list)) and bool(doc)
            keeps_parent = form_ok and rows_keep_parent_in_json(doc, spec["pairs"])
        else:
            text = proc.stdout or ""
            lines = text.splitlines()
            child_lines = [next((ln for ln in lines if _has_word(ln, child)), "") for child, _ in spec["pairs"]]
            form_ok = all("|" in ln for ln in child_lines)
            keeps_parent = rows_keep_parent_in_text(text, spec["pairs"], same_line=False)
    return {
        "exit_ok": proc.returncode == 0,
        "missing_values": sorted(v for v in spec["values"] if v not in text),
        "rows_keep_parent": bool(keeps_parent),
        "form_ok": bool(form_ok),
        "output": combined_output(proc),
    }


def observe_download_error(inputs: dict) -> dict:
    """Export inputs["file_key"] while the download serves BAD_BODIES[inputs["body"]],
    and report which of inputs["probes"] the output never mentions."""
    with tempfile.TemporaryDirectory() as home:
        seed_token(home)
        with MockStatementServer() as mock:
            status, content_type, body = BAD_BODIES[inputs["body"]]
            mock.set_download_body(body, status=status, content_type=content_type)
            proc = run_cli(["statement", "export", "--file-key", inputs["file_key"]], mock, home)
    out = combined_output(proc)
    low = out.lower()
    return {
        "exit_ok": proc.returncode == 0,
        "missing": sorted(p for p in inputs["probes"] if p.lower() not in low),
        "output": out,
    }


def observe_current_export(inputs: dict) -> dict:
    """Export CURRENT_DOCS[inputs["doc"]] with inputs["global"] before and
    inputs["args"] after `statement export --file-key KEY`, then read
    inputs["target"]: "stdout", "file:<name>" or "dir:<name>" under the run's cwd."""
    key = "/statement_data/data/lb/1/202206/10000104.json"
    with tempfile.TemporaryDirectory() as home:
        seed_token(home)
        with MockStatementServer() as mock:
            mock.set_download_body(json.dumps(CURRENT_DOCS[inputs["doc"]]), content_type="application/json")
            args = list(inputs.get("global") or []) + ["statement", "export", "--file-key", key]
            args += list(inputs.get("args") or [])
            proc = run_cli(args, mock, home)
        target = inputs["target"]
        files = 0
        if target == "stdout":
            kind, text = "stdout", proc.stdout or ""
        else:
            where, name = target.split(":", 1)
            path = Path(home) / name
            if path.is_file():
                kind, text, files = "file", path.read_text(encoding="utf-8", errors="replace"), 1
            elif path.is_dir():
                found = sorted(p for p in path.iterdir() if p.is_file())
                kind, files = "dir", len(found)
                text = "\n".join(p.read_text(encoding="utf-8", errors="replace") for p in found)
            else:
                kind, text = "missing", ""
    out = combined_output(proc)
    pairs = inputs.get("pairs") or []
    return {
        "exit_ok": proc.returncode == 0,
        "target_kind": kind,
        "missing": sorted(t for t in inputs.get("present") or [] if t not in text),
        "leaked": sorted(t for t in inputs.get("absent") or [] if t in text),
        "files": files,
        "null_error": "invalid type: null" in out,
        "pairs_ok": rows_keep_parent_in_text(text, pairs, same_line=True) if pairs else True,
        "output": out,
    }


def observe_list(inputs: dict, table: dict | None = None, json_names: dict | None = None) -> dict:
    """Run `statement list` with the structured list inputs["structured"]
    ([dt, "file" | "" | key] entries) and the PDFs inputs["pdf_months"] or
    inputs["pdf_days"], then read the rows of inputs["dates"].

    `table` and `json_names` give, for "date", "key" and "format", the header
    label (table output) or record key (--format json) the tree under test uses.
    Without them every cell of a row is searched instead."""
    names = json_names if inputs.get("json") else table
    if names is not None:
        _require_filled("the list adapter", names)
    pdfs = list(inputs.get("pdf_months") or [])
    if inputs.get("pdf_days"):
        pdfs += _days(inputs["pdf_days"]["start"], int(inputs["pdf_days"]["count"]))
    as_json = bool(inputs.get("json"))
    with tempfile.TemporaryDirectory() as home:
        seed_token(home)
        with MockStatementServer() as mock:
            mock.set_statement_list(_structured(inputs.get("structured") or []))
            for name in pdfs:
                mock.add_pdf(name)
            args = (["--format", "json"] if as_json else []) + [
                "statement", "list", "--type", inputs["type"],
                "--start-date", inputs["start_date"], "--limit", str(inputs["limit"])]
            proc = run_cli(args, mock, home)
            pdf_list_calls = len(mock.calls(PDF_LIST_PATH))
    pdf_by_date = {name.replace(".", ""): pdf_key(name) for name in pdfs}
    file_by_date = {str(e["dt"]): e["file_key"] for e in _structured(inputs.get("structured") or [])
                    if e["file_key"]}
    formats, pdf_keys, json_keys = [], [], []
    if names is None:
        rows = _list_rows(proc.stdout or "", as_json)
        for date in inputs.get("dates") or []:
            cells = _row_for(rows, date)
            formats.append(f"{date}:{'none' if cells is None else _format_of(cells)}")
            if cells is not None and pdf_by_date.get(date) in cells:
                pdf_keys.append(date)
            if cells is not None and file_by_date.get(date) in cells:
                json_keys.append(date)
        pdf_rows = sum(1 for cells in rows if _format_of(cells) == "pdf")
    else:
        records = _named_records(proc.stdout or "", as_json, names)
        for date in inputs.get("dates") or []:
            rec = next((r for r in records if re.sub(r"[.\-/]", "", r["date"]) == date), None)
            label = rec["format"].strip().lower() if rec else ""
            formats.append(f"{date}:{'none' if rec is None else (label if label in ('json', 'pdf') else '-')}")
            if rec is not None and rec["key"] == pdf_by_date.get(date):
                pdf_keys.append(date)
            if rec is not None and rec["key"] == file_by_date.get(date):
                json_keys.append(date)
        pdf_rows = sum(1 for r in records if r["format"].strip().lower() == "pdf")
    return {
        "exit_ok": proc.returncode == 0,
        "formats": formats,
        "pdf_keys": sorted(pdf_keys),
        "json_keys": sorted(json_keys),
        "pdf_rows": pdf_rows,
        "asked_pdf_list": pdf_list_calls > 0,
        "output": combined_output(proc),
    }


def observe_pdf_export(inputs: dict, report_fields: dict | None = None) -> dict:
    """Export the PDF listed as inputs["display_name"] with inputs["output"]:
    "none", "dir_slash:<name>", "dir_existing:<name>" or "file:<name>";
    inputs["json"] adds the global --format json.

    `report_fields` gives the dotted paths of "file", "cache_key" and "rule" in
    the tree's --format json output (None for one it doesn't print). Without it
    every value of the JSON is searched instead."""
    if report_fields is not None:
        _require_filled("REPORT_FIELDS", report_fields)
    with tempfile.TemporaryDirectory() as home:
        seed_token(home)
        with MockStatementServer() as mock:
            item = mock.add_pdf(inputs["display_name"])
            args = (["--format", "json"] if inputs.get("json") else []) + [
                "statement", "export", "--file-key", item["key"]]
            output = inputs["output"]
            if output != "none":
                how, name = output.split(":", 1)
                path = os.path.join(home, name)
                if how == "dir_existing":
                    os.makedirs(path)
                args += ["-o", path + os.sep if how == "dir_slash" else path]
            proc = run_cli(args, mock, home)
            asked = any(c["query"].get("key") == item["key"] for c in mock.calls(PDF_DOWNLOAD_PATH))
        saved = sorted(
            p.relative_to(home).as_posix()
            for p in Path(home).rglob("*")
            if p.is_file() and p.suffix.lower() == ".pdf" and ".longbridge" not in p.parts
        )
        bytes_match = bool(saved) and all((Path(home) / s).read_bytes() == item["body"] for s in saved)
    out = combined_output(proc)
    reports = []
    if inputs.get("json"):
        doc = try_parse_json(proc.stdout or "")
        names = {s.rsplit("/", 1)[-1] for s in saved}
        if report_fields is None:
            leaves = _leaves(doc) if isinstance(doc, (dict, list)) else []
            files, cache_keys, rules = leaves, leaves, leaves
        else:
            def at(field: str) -> list[str]:
                value = _dig(doc, report_fields.get(field))
                return [] if value is None or isinstance(value, (dict, list)) else [str(value)]
            files, cache_keys, rules = at("file"), at("cache_key"), at("rule")
        if item["cache_key"] in cache_keys:
            reports.append("cache_key")
        if any(re.split(r"[/\\]", v)[-1] in names for v in files):
            reports.append("file")
        if any(states_unlock_rule(v) for v in rules):
            reports.append("rule")
    return {
        "exit_ok": proc.returncode == 0,
        "saved": saved,
        "bytes_match": bytes_match,
        "asked_pdf_download": asked,
        "rule_stated": states_unlock_rule(out),
        "json_reports": sorted(reports),
        "output": out,
    }
