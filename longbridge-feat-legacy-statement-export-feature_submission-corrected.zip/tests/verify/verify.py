"""Checks for `longbridge statement`, run on the built CLI.

test_crate_compiles builds the single binary crate with `cargo build --locked`
and fails with the compiler's output when the tree no longer builds.

The other tests run the debug `longbridge` binary against the local stand-in
for the statements API in tests/validate/test_harness.py, one or two cases per
behavior the instruction asks for, with documents and dates of their own.
"""

from __future__ import annotations

import os
import subprocess
import sys
import textwrap
from pathlib import Path

import pytest

VALIDATE_DIR = Path(__file__).resolve().parents[1] / "validate"
sys.path.insert(0, str(VALIDATE_DIR))

import test_harness as th  # noqa: E402

# Repository directory inside the task container (see environment/Dockerfile:
# WORKDIR /repo/longbridge-terminal).
REPO_DIR = "/repo/longbridge-terminal"

# `cargo build --locked` builds the single binary crate. --locked keeps the
# lockfile authoritative, and the default (debug) profile matches the build the
# image warms up, so the build here only recompiles what changed.
BUILD_CMD = ["cargo", "build", "--locked"]

# A warm incremental build takes seconds to a couple of minutes; 12 minutes
# leaves room for a cold sandbox. Scaled by TIMEOUT_MULTIPLIER, like every CLI
# run in the harness.
BUILD_TIMEOUT_SEC = 720


def _cargo_env() -> dict:
    env = {**os.environ}
    env.setdefault("CARGO_HOME", "/opt/cargo")
    env.setdefault("RUSTUP_HOME", "/opt/rustup")
    env.setdefault("CARGO_TARGET_DIR", "/opt/cache/cargo-target")
    env["PATH"] = f"{env['CARGO_HOME']}/bin:" + env.get("PATH", "")
    # No network here: fail fast on a cache miss instead of hanging.
    env.setdefault("CARGO_NET_OFFLINE", "true")
    return env


def _tail(text: str, n: int = 200) -> str:
    return "\n".join(text.splitlines()[-n:])


def test_crate_compiles() -> None:
    """The crate still builds with `cargo build --locked`."""
    result = subprocess.run(
        BUILD_CMD,
        cwd=REPO_DIR,
        capture_output=True,
        text=True,
        timeout=int(BUILD_TIMEOUT_SEC * th.timeout_multiplier()),
        env=_cargo_env(),
        check=False,
    )
    if result.returncode == 0:
        return
    msg = textwrap.dedent(
        f"""\
        `cargo build --locked` failed (exit {result.returncode}).

        --- cargo build stderr (last 200 lines) ---
        {_tail(result.stderr)}

        --- cargo build stdout (last 200 lines) ---
        {_tail(result.stdout)}
        """
    )
    raise AssertionError(msg)


@pytest.fixture(scope="module")
def cli() -> str:
    """Path of the debug binary built from the tree under test."""
    preset = os.environ.get("LONGBRIDGE_BIN", "").strip()
    if preset:
        return preset
    env = _cargo_env()
    result = subprocess.run(
        ["cargo", "build", "--locked", "--bin", "longbridge"],
        cwd=REPO_DIR,
        capture_output=True,
        text=True,
        timeout=int(BUILD_TIMEOUT_SEC * th.timeout_multiplier()),
        env=env,
        check=False,
    )
    if result.returncode != 0:
        pytest.fail("the longbridge binary did not build:\n" + _tail(result.stderr, 60))
    path = Path(env["CARGO_TARGET_DIR"]) / "debug" / "longbridge"
    if not path.is_file():
        pytest.fail(f"no binary at {path} after the build")
    os.environ["LONGBRIDGE_BIN"] = str(path)
    return str(path)


def _check(seen: dict, want: dict) -> None:
    for key, value in want.items():
        assert seen[key] == value, (
            f"{key}: expected {value!r}, got {seen[key]!r}\n{seen['output'][-1500:]}")


def test_older_layout_exports_every_value_with_its_market(cli) -> None:
    for mode in ("markdown", "csv"):
        seen = th.observe_legacy_export({"layout": "option_holdings", "mode": mode})
        _check(seen, {"exit_ok": True, "missing_values": [], "rows_keep_parent": True, "form_ok": True})


def test_bad_download_names_status_type_body_and_pdf(cli) -> None:
    seen = th.observe_download_error({
        "file_key": "/statement_data/data/lb/1/202309/10000104.json",
        "body": "text_502",
        "probes": ["502", "text/plain", "Bad Gateway", "pdf"],
    })
    _check(seen, {"exit_ok": False, "missing": []})


def test_null_sections_export(cli) -> None:
    seen = th.observe_current_export({
        "doc": "two_null_sections", "global": [], "args": [], "target": "stdout",
        "present": ["123456.78", "777.01"], "absent": [], "pairs": [["777.01", "USD"]],
    })
    _check(seen, {"exit_ok": True, "missing": [], "null_error": False, "pairs_ok": True})


def test_explicit_section_with_output_writes_that_file(cli) -> None:
    seen = th.observe_current_export({
        "doc": "three_sections", "global": [], "args": ["--section", "account_balances", "-o", "balances.csv"],
        "target": "file:balances.csv", "present": ["777.01"], "absent": ["123456.78", "AAPL"], "pairs": [],
    })
    _check(seen, {"exit_ok": True, "target_kind": "file", "missing": [], "leaked": []})


def test_list_fills_periods_without_a_file_from_pdfs(cli) -> None:
    seen = th.observe_list({
        "type": "monthly", "start_date": "2023-09-01", "limit": 4, "json": False,
        "structured": [[202309, ""], [202310, "file"], [202311, ""], [202312, "file"]],
        "pdf_months": ["2023.09", "2023.11"],
        "dates": ["202309", "202310", "202311", "202312"],
    })
    _check(seen, {
        "exit_ok": True,
        "formats": ["202309:pdf", "202310:json", "202311:pdf", "202312:json"],
        "pdf_keys": ["202309", "202311"],
        "json_keys": ["202310", "202312"],
        "asked_pdf_list": True,
    })


def test_list_leaves_pdfs_alone_when_nothing_is_missing(cli) -> None:
    covered = {
        "type": "monthly", "start_date": "2023-01-01", "limit": 3, "json": False,
        "structured": [[202301, "file"], [202302, "file"], [202303, "file"]],
        "pdf_months": ["2023.01"], "dates": [],
    }
    recent = {
        "type": "monthly", "start_date": "2025-06-01", "limit": 6, "json": False,
        "structured": [[202506, "file"], [202507, "file"], [202508, "file"]],
        "pdf_months": ["2024.12"], "dates": [],
    }
    for inputs in (covered, recent):
        _check(th.observe_list(inputs), {"exit_ok": True, "asked_pdf_list": False})


def test_pdf_export_saves_file_and_states_rule(cli) -> None:
    seen = th.observe_pdf_export({"display_name": "2023.08", "output": "file:aug.pdf", "json": False})
    _check(seen, {"exit_ok": True, "saved": ["aug.pdf"], "bytes_match": True,
                  "asked_pdf_download": True, "rule_stated": True})
    seen = th.observe_pdf_export({"display_name": "2023.08", "output": "dir_slash:pdfs", "json": True})
    _check(seen, {"exit_ok": True, "saved": ["pdfs/statement-monthly-202308-H10062184.pdf"],
                  "bytes_match": True, "json_reports": ["cache_key", "file", "rule"]})
