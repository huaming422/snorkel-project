package dolt

// Behavioral verification for the server-Dolt write path at the commit
// boundary. These tests drive the pre-existing public store surface
// (ClaimIssue / ClaimReadyIssue / UpdateIssueChecked) through an injectable
// database/sql driver that counts each write phase (row mutation, staging,
// versioned commit, SQL commit/rollback, transaction attempts). The driver is
// the only seam needed: every assertion is expressed in terms of observable
// phase counts and the error the caller receives, never in terms of any
// internal helper, error value, or message string that a fix is free to name.
//
// The file owns TestMain so the runner executes it in isolation from the
// package's other test files; every identifier below is self-contained and
// prefixed `vrf` to avoid colliding with package-level test helpers.

import (
	"context"
	"database/sql"
	"database/sql/driver"
	"errors"
	"io"
	"os"
	"strings"
	"sync"
	"testing"

	mysql "github.com/go-sql-driver/mysql"

	"github.com/steveyegge/beads/internal/storage"
	"github.com/steveyegge/beads/internal/storage/issueops"
	"github.com/steveyegge/beads/internal/types"
)

func TestMain(m *testing.M) {
	os.Exit(m.Run())
}

// vrfConnLoss models a transport-level connection drop. Its message is one the
// server-write stack treats as transient at the pre-commit phases; the whole
// point of the behavior under test is what happens when that same drop lands on
// the versioned-commit step, where the outcome is genuinely unknown.
var vrfConnLoss = errors.New("invalid connection")

// vrfBoundaryDriver models a permanent claim/update through its SQL mutation,
// staging, and versioned-commit phases. It deliberately keeps the row's
// coordination state unchanged after a rollback so that an unsafe second run of
// the caller callback is observable as a second mutation (or a claim landing on
// a different ready row).
type vrfBoundaryDriver struct {
	mu sync.Mutex

	// Injected outcomes.
	stageErr        error
	commitErr       error // returned from the first versioned-commit call only
	mutationErrOnce error // returned from the first claim row mutation, then cleared
	sqlCommitErr    error
	nothingToCommit bool
	checkedUpdate   bool
	verifyAssignee  string
	verifyStatus    types.Status

	// Observed phase counters.
	claimMutations  int
	claimedIDs      []string
	updateMutations int
	eventInserts    int
	claimStateReads int
	stageCalls      int
	doltCommits     int
	txCommits       int
	txRollbacks     int
	txAttempts      int
	activeID        string
	readyIDs        []string
}

func (d *vrfBoundaryDriver) Open(string) (driver.Conn, error) {
	return &vrfBoundaryConn{driver: d}, nil
}

func (d *vrfBoundaryDriver) Connect(context.Context) (driver.Conn, error) {
	return &vrfBoundaryConn{driver: d}, nil
}

func (d *vrfBoundaryDriver) Driver() driver.Driver { return d }

type vrfBoundaryConn struct {
	driver *vrfBoundaryDriver
}

func (c *vrfBoundaryConn) Prepare(string) (driver.Stmt, error) {
	return nil, errors.New("vrf boundary driver does not prepare statements")
}

func (c *vrfBoundaryConn) Close() error { return nil }

func (c *vrfBoundaryConn) Begin() (driver.Tx, error) {
	c.driver.mu.Lock()
	c.driver.txAttempts++
	c.driver.activeID = "vrf-boundary"
	if len(c.driver.readyIDs) > 0 {
		index := c.driver.txAttempts - 1
		if index >= len(c.driver.readyIDs) {
			index = len(c.driver.readyIDs) - 1
		}
		c.driver.activeID = c.driver.readyIDs[index]
	}
	c.driver.mu.Unlock()
	return &vrfBoundaryTx{driver: c.driver}, nil
}

func (c *vrfBoundaryConn) QueryContext(_ context.Context, query string, _ []driver.NamedValue) (driver.Rows, error) {
	c.driver.mu.Lock()
	defer c.driver.mu.Unlock()

	switch {
	case strings.Contains(query, "SELECT 1 FROM wisps WHERE id = ? LIMIT 1"):
		return &vrfBoundaryRows{columns: []string{"exists"}}, nil
	case strings.Contains(query, "SELECT assignee, status FROM issues WHERE id = ?"):
		c.driver.claimStateReads++
		assignee := ""
		status := types.StatusOpen
		if c.driver.checkedUpdate && c.driver.claimStateReads > 1 {
			assignee = c.driver.verifyAssignee
			status = c.driver.verifyStatus
		}
		return &vrfBoundaryRows{
			columns: []string{"assignee", "status"},
			values:  [][]driver.Value{{assignee, string(status)}},
		}, nil
	case strings.Contains(query, "SELECT id FROM issues"):
		return &vrfBoundaryRows{
			columns: []string{"id"},
			values:  [][]driver.Value{{c.driver.activeID}},
		}, nil
	case strings.Contains(query, "FROM issues") && strings.Contains(query, "LEFT JOIN leases") && strings.Contains(query, "WHERE id IN ("):
		return &vrfBoundaryRows{
			columns: vrfIssueColumns(),
			values:  [][]driver.Value{vrfIssueValues(c.driver.activeID)},
		}, nil
	case strings.Contains(query, "FROM issues") && strings.Contains(query, "LEFT JOIN leases") && strings.Contains(query, "WHERE id = ?"):
		return &vrfBoundaryRows{
			columns: vrfIssueColumns(),
			values:  [][]driver.Value{vrfIssueValues(c.driver.activeID)},
		}, nil
	case strings.Contains(query, "SELECT label FROM labels"):
		return &vrfBoundaryRows{columns: []string{"label"}}, nil
	case strings.Contains(query, "SELECT issue_id, label FROM labels"):
		return &vrfBoundaryRows{columns: []string{"issue_id", "label"}}, nil
	case strings.Contains(query, "SELECT name, category FROM custom_statuses"):
		return &vrfBoundaryRows{columns: []string{"name", "category"}}, nil
	case strings.Contains(query, "SELECT value FROM config"):
		return &vrfBoundaryRows{columns: []string{"value"}}, nil
	case strings.Contains(query, "CALL DOLT_ADD"):
		c.driver.stageCalls++
		if c.driver.stageErr != nil {
			return nil, c.driver.stageErr
		}
		return &vrfBoundaryRows{columns: []string{"status"}}, nil
	case strings.Contains(query, "CALL DOLT_COMMIT"):
		c.driver.doltCommits++
		if c.driver.commitErr != nil && c.driver.doltCommits == 1 {
			return nil, c.driver.commitErr
		}
		if c.driver.nothingToCommit {
			return nil, errors.New("nothing to commit")
		}
		return &vrfBoundaryRows{columns: []string{"hash"}}, nil
	default:
		return &vrfBoundaryRows{columns: []string{"value"}}, nil
	}
}

func (c *vrfBoundaryConn) ExecContext(_ context.Context, query string, _ []driver.NamedValue) (driver.Result, error) {
	c.driver.mu.Lock()
	defer c.driver.mu.Unlock()
	if strings.Contains(query, "UPDATE issues") && strings.Contains(query, "SET assignee") {
		c.driver.claimMutations++
		c.driver.claimedIDs = append(c.driver.claimedIDs, c.driver.activeID)
		if c.driver.mutationErrOnce != nil {
			err := c.driver.mutationErrOnce
			c.driver.mutationErrOnce = nil
			return nil, err
		}
	}
	if strings.Contains(query, "UPDATE issues") && strings.Contains(query, "`title`") {
		c.driver.updateMutations++
	}
	if strings.Contains(query, "INSERT INTO events") {
		c.driver.eventInserts++
	}
	return driver.RowsAffected(1), nil
}

type vrfBoundaryTx struct {
	driver *vrfBoundaryDriver
}

func (t *vrfBoundaryTx) Commit() error {
	t.driver.mu.Lock()
	defer t.driver.mu.Unlock()
	t.driver.txCommits++
	return t.driver.sqlCommitErr
}

func (t *vrfBoundaryTx) Rollback() error {
	t.driver.mu.Lock()
	defer t.driver.mu.Unlock()
	t.driver.txRollbacks++
	return nil
}

type vrfBoundaryRows struct {
	columns []string
	values  [][]driver.Value
	index   int
}

func (r *vrfBoundaryRows) Columns() []string { return r.columns }
func (r *vrfBoundaryRows) Close() error      { return nil }
func (r *vrfBoundaryRows) Next(dest []driver.Value) error {
	if r.index >= len(r.values) {
		return io.EOF
	}
	copy(dest, r.values[r.index])
	r.index++
	return nil
}

func vrfIssueColumns() []string {
	parts := strings.Split(strings.ReplaceAll(issueops.IssueSelectColumns, "\n", " "), ",")
	for i := range parts {
		parts[i] = strings.TrimSpace(parts[i])
	}
	return parts
}

func vrfIssueValues(id string) []driver.Value {
	values := make([]driver.Value, 0, len(vrfIssueColumns()))
	for _, column := range vrfIssueColumns() {
		switch column {
		case "id":
			values = append(values, id)
		case "title":
			values = append(values, "vrf boundary")
		case "description", "design", "acceptance_criteria", "notes":
			values = append(values, "")
		case "status":
			values = append(values, string(types.StatusOpen))
		case "priority":
			values = append(values, int64(2))
		case "issue_type":
			values = append(values, string(types.TypeTask))
		case "compaction_level":
			values = append(values, int64(0))
		default:
			values = append(values, nil)
		}
	}
	return values
}

func vrfNewStore(d *vrfBoundaryDriver) *DoltStore {
	return &DoltStore{db: sql.OpenDB(d)}
}

// TestClaimIssueCommitResponseLossIsNotReplayed covers the headline symptom:
// when the versioned commit's response is lost (the outcome is unknown), the
// claim must surface a single, honest failure that still carries the transport
// cause. It must NOT re-run the caller callback — a second run would re-apply
// the already-possibly-committed mutation (a false-failure-then-double-apply).
func TestClaimIssueCommitResponseLossIsNotReplayed(t *testing.T) {
	d := &vrfBoundaryDriver{commitErr: vrfConnLoss}
	store := vrfNewStore(d)
	t.Cleanup(func() { _ = store.db.Close() })

	err := store.ClaimIssue(context.Background(), "vrf-boundary", "alice")

	// The caller must learn the write failed...
	if err == nil {
		t.Fatal("ClaimIssue() returned nil after the commit response was lost; the uncertain outcome was reported as success")
	}
	// ...and the surfaced error must still carry the underlying transport cause,
	// not a masked or swallowed substitute.
	if !errors.Is(err, vrfConnLoss) {
		t.Fatalf("ClaimIssue() error = %v, want it to join the injected connection loss %v", err, vrfConnLoss)
	}

	d.mu.Lock()
	defer d.mu.Unlock()
	// The callback (row mutation + versioned commit) ran at most once: no replay.
	if d.claimMutations != 1 {
		t.Fatalf("claim row mutations = %d, want 1 (callback must not be replayed on an uncertain commit)", d.claimMutations)
	}
	if d.doltCommits != 1 {
		t.Fatalf("versioned-commit calls = %d, want 1 (callback must not be replayed on an uncertain commit)", d.doltCommits)
	}
	if d.txAttempts != 1 {
		t.Fatalf("transaction attempts = %d, want 1 (the whole write must not be replayed)", d.txAttempts)
	}
}

// TestClaimReadyIssueCommitResponseLossDoesNotDoubleClaim covers the dequeue
// variant: on an uncertain commit the ready-claim must not re-scan the ready
// front and claim a *different* issue. A replay here is uniquely damaging — the
// first (possibly-committed) claim plus a second claim on another row leaves two
// issues assigned from one request.
func TestClaimReadyIssueCommitResponseLossDoesNotDoubleClaim(t *testing.T) {
	d := &vrfBoundaryDriver{
		commitErr: vrfConnLoss,
		readyIDs:  []string{"vrf-ready-first", "vrf-ready-second"},
	}
	store := vrfNewStore(d)
	t.Cleanup(func() { _ = store.db.Close() })

	claimed, err := store.ClaimReadyIssue(context.Background(), types.WorkFilter{}, "alice")

	if err == nil {
		t.Fatal("ClaimReadyIssue() returned nil error after the commit response was lost")
	}
	if !errors.Is(err, vrfConnLoss) {
		t.Fatalf("ClaimReadyIssue() error = %v, want it to join the injected connection loss %v", err, vrfConnLoss)
	}
	if claimed != nil {
		t.Fatalf("ClaimReadyIssue() claimed = %+v, want nil while the commit outcome is unknown", claimed)
	}

	d.mu.Lock()
	defer d.mu.Unlock()
	if got, want := strings.Join(d.claimedIDs, ","), "vrf-ready-first"; got != want {
		t.Fatalf("claimed IDs = %q, want %q (must not replay onto a second ready issue)", got, want)
	}
	if d.txAttempts != 1 {
		t.Fatalf("transaction attempts = %d, want 1 (no re-scan of the ready front)", d.txAttempts)
	}
	if d.doltCommits != 1 {
		t.Fatalf("versioned-commit calls = %d, want 1", d.doltCommits)
	}
}

// TestUpdateIssueCheckedMixedCommitLossIsNotMasked covers the guarded-update
// path when the update mixes coordination fields (assignee/status) with an
// ordinary field (title). Verification by assignee/status re-read cannot prove
// the ordinary column or the event row landed, so an uncertain commit here must
// be surfaced with its transport cause intact — never replayed into a masking
// precondition-mismatch failure, and never reported as success.
func TestUpdateIssueCheckedMixedCommitLossIsNotMasked(t *testing.T) {
	d := &vrfBoundaryDriver{
		commitErr:      vrfConnLoss,
		checkedUpdate:  true,
		verifyAssignee: "alice",
		verifyStatus:   types.StatusInProgress,
	}
	store := vrfNewStore(d)
	store.serverMode = true
	t.Cleanup(func() { _ = store.db.Close() })

	expectedAssignee := ""
	expectedStatus := string(types.StatusOpen)
	err := store.UpdateIssueChecked(context.Background(), "vrf-boundary", map[string]interface{}{
		"assignee": "alice",
		"status":   string(types.StatusInProgress),
		"title":    "ordinary field riding the coordination write",
	}, "alice", storage.UpdateIssueOptions{
		ExpectedAssignee: &expectedAssignee,
		ExpectedStatus:   &expectedStatus,
	})

	if err == nil {
		t.Fatal("UpdateIssueChecked() returned nil after the commit response was lost")
	}
	// The true cause must reach the caller; a replay would instead re-read the
	// post-mutation row and surface an unrelated precondition-mismatch error,
	// masking the uncertain commit.
	if !errors.Is(err, vrfConnLoss) {
		t.Fatalf("UpdateIssueChecked() error = %v, want it to join the injected connection loss %v (the uncertain commit must not be masked)", err, vrfConnLoss)
	}

	d.mu.Lock()
	defer d.mu.Unlock()
	if d.txAttempts != 1 {
		t.Fatalf("transaction attempts = %d, want 1 (the mixed write must not be replayed)", d.txAttempts)
	}
	if d.updateMutations != 1 {
		t.Fatalf("update row mutations = %d, want 1", d.updateMutations)
	}
}

// TestDeterminateSerializationCommitIsStillRetried is the preservation guard:
// a determinate, guaranteed-rollback commit error (a serialization conflict)
// MUST still be retried to success — the uncertain-commit fix must not become a
// blanket disable of the write-retry safety net. A solution that stops retrying
// every commit error fails here while the correct fix passes, both before and
// after the change.
func TestDeterminateSerializationCommitIsStillRetried(t *testing.T) {
	d := &vrfBoundaryDriver{
		commitErr: &mysql.MySQLError{Number: 1213, Message: "Deadlock found when trying to get lock; try restarting transaction"},
	}
	store := vrfNewStore(d)
	t.Cleanup(func() { _ = store.db.Close() })

	err := store.ClaimIssue(context.Background(), "vrf-boundary", "alice")
	if err != nil {
		t.Fatalf("ClaimIssue() error = %v, want nil (a determinate serialization conflict must be retried to success)", err)
	}

	d.mu.Lock()
	defer d.mu.Unlock()
	// The retry re-ran the callback and the second versioned commit succeeded.
	if d.doltCommits != 2 {
		t.Fatalf("versioned-commit calls = %d, want 2 (first conflicts, retry succeeds)", d.doltCommits)
	}
	if d.claimMutations != 2 {
		t.Fatalf("claim row mutations = %d, want 2 (a determinate rollback is safe to replay)", d.claimMutations)
	}
}

// TestPreCommitConnectionLossIsStillRetried guards the normal transient-retry
// safety net: a connection blip that strikes BEFORE the commit (here, on the
// row mutation inside the transaction body) leaves nothing committed, so it is
// safe to replay and MUST still be retried to success. Making every connection
// error non-retryable would break this — the first attempt's error becomes
// terminal and the write fails spuriously. Not replaying must be scoped to the
// uncertain *commit* boundary only, so a pre-commit blip is still retried and
// the write ultimately succeeds.
func TestPreCommitConnectionLossIsStillRetried(t *testing.T) {
	d := &vrfBoundaryDriver{mutationErrOnce: vrfConnLoss}
	store := vrfNewStore(d)
	t.Cleanup(func() { _ = store.db.Close() })

	err := store.ClaimIssue(context.Background(), "vrf-boundary", "alice")
	if err != nil {
		t.Fatalf("ClaimIssue() error = %v, want nil (a pre-commit connection blip must be retried to success)", err)
	}

	d.mu.Lock()
	defer d.mu.Unlock()
	// First attempt failed before commit (one mutation, one rollback, no commit);
	// the retry re-ran the callback and committed.
	if d.txAttempts != 2 {
		t.Fatalf("transaction attempts = %d, want 2 (pre-commit blip must be retried)", d.txAttempts)
	}
	if d.claimMutations != 2 {
		t.Fatalf("claim row mutations = %d, want 2 (first blips pre-commit, retry succeeds)", d.claimMutations)
	}
	if d.doltCommits != 1 {
		t.Fatalf("versioned-commit calls = %d, want 1 (only the successful retry reaches commit)", d.doltCommits)
	}
}

// Compile-time guarantees that the injectable driver satisfies the database/sql
// connector contract the store exercises.
var _ driver.Connector = (*vrfBoundaryDriver)(nil)
var _ driver.ExecerContext = (*vrfBoundaryConn)(nil)
var _ driver.QueryerContext = (*vrfBoundaryConn)(nil)
