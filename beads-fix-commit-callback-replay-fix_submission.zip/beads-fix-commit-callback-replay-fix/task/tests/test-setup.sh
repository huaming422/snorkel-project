#!/usr/bin/env bash
# All dependencies (Go module closure at the base commit, the embedded-Dolt cgo
# build, and go-sqlmock) are baked into the image with warm module/build caches.
# Nothing to install at verifier time.
set -euo pipefail
echo "[test-setup] no-op for beads-fix-commit-callback-replay"
