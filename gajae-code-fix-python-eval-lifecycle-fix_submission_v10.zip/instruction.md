## Task

Python execution can leave work behind after cancellation or a deadline expires. Cancelling during startup can affect the next run, and shutdown sometimes returns before active work has finished.

Make those lifecycle paths reliable, including concurrent requests. Stop work owned by the cancelled or timed-out run without disturbing other sessions or processes. Cleanup should finish promptly without blocking other work or preventing the application from exiting. Keep the existing public API and Python runner protocol compatible.

