// Lifecycle regression checks for Python execution, cancellation, and shutdown.
import { afterAll, afterEach, describe, expect, it } from "bun:test";
import * as fsSync from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { disposeAllKernelSessions, executePython, type PythonResult } from "@gajae-code/coding-agent/eval/py/executor";
import type {
	KernelExecuteOptions,
	KernelExecuteResult,
	KernelShutdownResult,
} from "@gajae-code/coding-agent/eval/py/kernel";
import { PythonKernel } from "@gajae-code/coding-agent/eval/py/kernel";
import { TempDir } from "@gajae-code/utils";
// Pre-existing stable test utility: the resolved shell environment (which backs
// the interpreter PATH that provisioning reads) is memoized process-wide on
// first use, so a test that varies PATH must clear that cache for the change to
// take effect. Used by the repo's own tests for exactly this purpose.
import { resetShellConfigCache } from "@gajae-code/utils/shell-config";

const originalStart = PythonKernel.start;

// ---------------------------------------------------------------------------
// Stand-in interpreter for provisioning tests.
//
// The provisioning path resolves `python3` from PATH. Interpreter resolution is
// memoized by command name, so the stand-in stays at a fixed path throughout
// repeated runs. It forwards regular invocations to the real interpreter.
// ---------------------------------------------------------------------------
const REAL_PYTHON3 = process.platform === "win32" ? null : Bun.which("python3");
const fakeInterpreterRoot =
	process.platform === "win32" ? null : fsSync.mkdtempSync(path.join(os.tmpdir(), "gjc-provision-standin-"));
const fakeInterpreterBinDir = fakeInterpreterRoot ? path.join(fakeInterpreterRoot, "bin") : null;
const fakeInterpreterPath = fakeInterpreterBinDir ? path.join(fakeInterpreterBinDir, "python3") : null;

if (fakeInterpreterBinDir && fakeInterpreterPath && REAL_PYTHON3) {
	fsSync.mkdirSync(fakeInterpreterBinDir, { recursive: true });
	fsSync.writeFileSync(
		fakeInterpreterPath,
		[
			"#!/bin/sh",
			"__gjc_is_venv=0",
			'for __gjc_arg in "$@"; do',
			'\tif [ "$__gjc_arg" = "venv" ]; then __gjc_is_venv=1; fi',
			"done",
			'if [ "$__gjc_is_venv" = "1" ]; then',
			'\t(trap "" TERM; while :; do sleep 1; done) &',
			"\tprintf '%s' \"$!\" > \"$PWD/provision-child.pid\"",
			"\twait",
			"\texit 0",
			"fi",
			`exec ${JSON.stringify(REAL_PYTHON3)} "$@"`,
			"",
		].join("\n"),
	);
	fsSync.chmodSync(fakeInterpreterPath, 0o755);
}

afterAll(() => {
	if (fakeInterpreterRoot) {
		try {
			fsSync.rmSync(fakeInterpreterRoot, { recursive: true, force: true });
		} catch {
			// best-effort cleanup
		}
	}
});

const READINESS_TIMEOUT_MS = 1_000;
const PROCESS_EXIT_TIMEOUT_MS = 4_000;
const CLEANUP_TIMEOUT_MS = 9_000;
// Kernel startup permits two 10s phases; readiness and cleanup consume up to 10s more.
const LIFECYCLE_TEST_TIMEOUT_MS = 35_000;

const OK_RESULT: KernelExecuteResult = {
	status: "ok",
	cancelled: false,
	timedOut: false,
	stdinRequested: false,
};

class FakeKernel {
	alive = true;
	executeCalls: string[] = [];
	shutdownCalls = 0;
	shutdownResult: KernelShutdownResult = { confirmed: true };
	private readonly executeImpl?: (code: string, options?: KernelExecuteOptions) => Promise<KernelExecuteResult>;

	constructor(executeImpl?: (code: string, options?: KernelExecuteOptions) => Promise<KernelExecuteResult>) {
		this.executeImpl = executeImpl;
	}

	async execute(code: string, options?: KernelExecuteOptions): Promise<KernelExecuteResult> {
		this.executeCalls.push(code);
		return this.executeImpl ? await this.executeImpl(code, options) : OK_RESULT;
	}

	async shutdown(): Promise<KernelShutdownResult> {
		this.shutdownCalls += 1;
		this.alive = false;
		return this.shutdownResult;
	}

	isAlive(): boolean {
		return this.alive;
	}
}

function isProcessAlive(pid: number): boolean {
	try {
		process.kill(pid, 0);
		return true;
	} catch {
		return false;
	}
}

async function waitForProcessGone(pid: number, timeoutMs = PROCESS_EXIT_TIMEOUT_MS): Promise<boolean> {
	const deadline = Date.now() + timeoutMs;
	while (Date.now() < deadline) {
		if (!isProcessAlive(pid)) return true;
		await Bun.sleep(50);
	}
	return !isProcessAlive(pid);
}

async function waitForOwnedProcess(pidFile: string, timeoutMs = READINESS_TIMEOUT_MS): Promise<number> {
	const deadline = Date.now() + timeoutMs;
	while (Date.now() < deadline) {
		if (await Bun.file(pidFile).exists()) {
			const pid = Number((await Bun.file(pidFile).text()).trim());
			if (Number.isSafeInteger(pid) && pid > 0 && isProcessAlive(pid)) return pid;
		}
		await Bun.sleep(10);
	}
	throw new Error(`Timed out waiting for owned descendant PID at ${pidFile}`);
}

async function waitForFile(path: string, timeoutMs = READINESS_TIMEOUT_MS): Promise<void> {
	const deadline = Date.now() + timeoutMs;
	while (Date.now() < deadline) {
		if (await Bun.file(path).exists()) return;
		await Bun.sleep(10);
	}
	throw new Error(`Timed out waiting for readiness file at ${path}`);
}

async function settlesWithin(promise: Promise<unknown>, timeoutMs: number): Promise<boolean> {
	return await Promise.race([
		promise.then(
			() => true,
			() => true,
		),
		Bun.sleep(timeoutMs).then(() => false),
	]);
}

function countAbortListeners(signal: AbortSignal): { readonly count: () => number; readonly restore: () => void } {
	let count = 0;
	const originalAdd = signal.addEventListener.bind(signal);
	const originalRemove = signal.removeEventListener.bind(signal);
	signal.addEventListener = ((
		type: string,
		listener: Parameters<typeof originalAdd>[1],
		options?: AddEventListenerOptions | boolean,
	) => {
		if (type === "abort") count += 1;
		return originalAdd(type, listener, options);
	}) as typeof signal.addEventListener;
	signal.removeEventListener = ((
		type: string,
		listener: Parameters<typeof originalRemove>[1],
		options?: EventListenerOptions | boolean,
	) => {
		if (type === "abort") count -= 1;
		return originalRemove(type, listener, options);
	}) as typeof signal.removeEventListener;
	return {
		count: () => count,
		restore: () => {
			signal.addEventListener = originalAdd as typeof signal.addEventListener;
			signal.removeEventListener = originalRemove as typeof signal.removeEventListener;
		},
	};
}

describe("python execution lifecycle", () => {
	it(
		"stops managed-runtime provisioning and its descendants after cancellation",
		async () => {
			if (process.platform === "win32") return;
			if (!fakeInterpreterBinDir || !REAL_PYTHON3) throw new Error("No python3 available to back the provisioning stand-in");
			using tempDir = TempDir.createSync("@gjc-python-lifecycle-redteam-");
			// The managed-runtime provisioning step runs the resolved interpreter
			// with its working directory set to the provisioning root, so the
			// stand-in records its descendant PID in the current working directory.
			const childPidPath = path.join(tempDir.path(), "provision-child.pid");

			// Drive provisioning entirely through the stable public entry point:
			// executePython with a managed workspace venv requested. The interpreter
			// is discovered from the live PATH, so prepend the stand-in ahead of any
			// system interpreter for this run and restore afterwards. Clear any
			// ambient virtual-env hints so provisioning actually spawns the managed
			// interpreter instead of reusing a pre-existing environment.
			const controller = new AbortController();
			const originalPath = process.env.PATH;
			const originalVirtualEnv = process.env.VIRTUAL_ENV;
			const originalCondaPrefix = process.env.CONDA_PREFIX;
			delete process.env.VIRTUAL_ENV;
			delete process.env.CONDA_PREFIX;
			process.env.PATH = `${fakeInterpreterBinDir}:${originalPath ?? ""}`;
			// The shell environment that backs interpreter resolution is memoized
			// on first use; an earlier case may already have populated it with the
			// unmodified PATH. Clear it so provisioning re-reads the live PATH and
			// resolves the stand-in prepended just above.
			resetShellConfigCache();

			let execution: Promise<PythonResult> | undefined;
			let childPid: number | undefined;
			try {
				execution = executePython("print('provisioning')", {
					cwd: tempDir.path(),
					sessionId: "redteam-proc-group-cancel",
					kernelMode: "session",
					signal: controller.signal,
					runtimeOptions: { managedWorkspaceVenv: true, seedPackages: [] },
				});
				void execution.catch(() => undefined);
				// Routing through the public entry point adds setup layers before
				// provisioning spawns the interpreter, so allow a generous (but still
				// bounded, well within the case deadline) window for the descendant to
				// appear before cancelling.
				childPid = await waitForOwnedProcess(childPidPath, 15_000);
				controller.abort(new DOMException("Python execution cancelled", "AbortError"));
				const result = await execution;
				expect(result.cancelled).toBe(true);
				expect(await waitForProcessGone(childPid)).toBe(true);
			} finally {
				controller.abort();
				await execution?.catch(() => undefined);
				if (childPid !== undefined && isProcessAlive(childPid)) {
					try {
						process.kill(childPid, "SIGKILL");
					} catch {
						// ignore cleanup races
					}
				}
				process.env.PATH = originalPath;
				if (originalVirtualEnv !== undefined) process.env.VIRTUAL_ENV = originalVirtualEnv;
				if (originalCondaPrefix !== undefined) process.env.CONDA_PREFIX = originalCondaPrefix;
				// Drop the stand-in PATH from the memoized shell environment so the
				// later cases that start a real kernel resolve the system interpreter.
				resetShellConfigCache();
				await disposeAllKernelSessions();
			}
		},
		LIFECYCLE_TEST_TIMEOUT_MS,
	);

	it(
		"stops provisioned descendants when the execution deadline expires without caller abort",
		async () => {
			if (process.platform === "win32") return;
			if (!fakeInterpreterBinDir || !REAL_PYTHON3) throw new Error("python3 is required");
			using tempDir = TempDir.createSync("@gjc-python-lifecycle-deadline-");
			const pidFile = path.join(tempDir.path(), "provision-child.pid");
			const oldPath = process.env.PATH;
			const oldVenv = process.env.VIRTUAL_ENV;
			const oldConda = process.env.CONDA_PREFIX;
			delete process.env.VIRTUAL_ENV;
			delete process.env.CONDA_PREFIX;
			process.env.PATH = `${fakeInterpreterBinDir}:${oldPath ?? ""}`;
			resetShellConfigCache();
			let execution: Promise<PythonResult> | undefined;
			let childPid: number | undefined;
			try {
				execution = executePython("print('deadline')", {
					cwd: tempDir.path(), sessionId: "deadline-provisioning",
					kernelMode: "session", timeoutMs: 18_000,
					runtimeOptions: { managedWorkspaceVenv: true, seedPackages: [] },
				});
				void execution.catch(() => undefined);
				childPid = await waitForOwnedProcess(pidFile, 15_000);
				const result = await execution;
				expect(result.timedOut || result.cancelled).toBe(true);
				expect(await waitForProcessGone(childPid)).toBe(true);
			} finally {
				await execution?.catch(() => undefined);
				if (childPid !== undefined && isProcessAlive(childPid)) {
					try { process.kill(childPid, "SIGKILL"); } catch { /* already exited */ }
				}
				process.env.PATH = oldPath;
				if (oldVenv !== undefined) process.env.VIRTUAL_ENV = oldVenv;
				if (oldConda !== undefined) process.env.CONDA_PREFIX = oldConda;
				resetShellConfigCache();
				await disposeAllKernelSessions();
			}
		},
		LIFECYCLE_TEST_TIMEOUT_MS,
	);

	afterEach(async () => {
		PythonKernel.start = originalStart;
		delete Bun.env.PI_PYTHON_SKIP_CHECK;
		await disposeAllKernelSessions();
	});

	it("keeps another active session usable when one session is cancelled", async () => {
		Bun.env.PI_PYTHON_SKIP_CHECK = "1";
		using tempDir = TempDir.createSync("@gjc-python-lifecycle-isolation-");
		const controller = new AbortController();
		const started = Promise.withResolvers<void>();
		const pending = Promise.withResolvers<KernelExecuteResult>();
		const first = new FakeKernel(async (_code, options) => {
			started.resolve();
			if (options?.signal?.aborted) return { ...OK_RESULT, cancelled: true };
			return await new Promise<KernelExecuteResult>((resolve) => {
				const onAbort = () => resolve({ ...OK_RESULT, cancelled: true });
				options?.signal?.addEventListener("abort", onAbort, { once: true });
				void pending.promise.then(resolve);
			});
		});
		const second = new FakeKernel();
		let starts = 0;
		PythonKernel.start = async () => (++starts === 1 ? first : second) as unknown as PythonKernel;
		try {
			const cancelled = executePython("print('first')", {
				cwd: tempDir.path(), sessionId: "cancelled-session", kernelMode: "session", signal: controller.signal,
			});
			await started.promise;
			await executePython("print('second')", {
				cwd: tempDir.path(), sessionId: "independent-session", kernelMode: "session",
			});
			controller.abort(new DOMException("Execution cancelled", "AbortError"));
			expect((await cancelled).cancelled).toBe(true);
			await executePython("print('still alive')", {
				cwd: tempDir.path(), sessionId: "independent-session", kernelMode: "session",
			});
			expect(second.executeCalls).toEqual(["print('second')", "print('still alive')"]);
			expect(second.shutdownCalls).toBe(0);
		} finally {
			controller.abort();
			pending.resolve({ ...OK_RESULT, cancelled: true });
			await disposeAllKernelSessions();
		}
	}, LIFECYCLE_TEST_TIMEOUT_MS);

	it("coalesces five concurrent first acquires for the same new session without orphan kernels", async () => {
		Bun.env.PI_PYTHON_SKIP_CHECK = "1";
		using tempDir = TempDir.createSync("@gjc-python-lifecycle-redteam-");
		const startup = Promise.withResolvers<void>();
		const kernel = new FakeKernel();
		let startCalls = 0;
		PythonKernel.start = async () => {
			startCalls += 1;
			await startup.promise;
			return kernel as unknown as PythonKernel;
		};

		const executions = Array.from({ length: 5 }, (_, index) =>
			executePython(`print(${index})`, {
				cwd: tempDir.path(),
				sessionId: "redteam-concurrent-same-session",
				kernelMode: "session",
			}),
		);
		await Bun.sleep(0);
		expect(startCalls).toBe(1);

		startup.resolve();
		await Promise.all(executions);
		expect(startCalls).toBe(1);
		expect(kernel.executeCalls).toEqual(["print(0)", "print(1)", "print(2)", "print(3)", "print(4)"]);

		await disposeAllKernelSessions();
		expect(kernel.shutdownCalls).toBe(1);
	});

	it(
		"kills only the owned bash background descendant after timeout while an unrelated sibling survives",
		async () => {
			if (process.platform === "win32") return;
			Bun.env.PI_PYTHON_SKIP_CHECK = "1";
			using tempDir = TempDir.createSync("@gjc-python-lifecycle-redteam-");
			const unrelated = Bun.spawn(["/bin/sh", "-c", "sleep 30"], { stdout: "ignore", stderr: "ignore" });
			const startupGate = Promise.withResolvers<void>();
			const startupCalled = Promise.withResolvers<void>();
			const kernelStarted = Promise.withResolvers<void>();
			const controller = new AbortController();
			let execution: Promise<PythonResult> | undefined;
			try {
				PythonKernel.start = async options => {
					startupCalled.resolve();
					await startupGate.promise;
					try {
						const kernel = await originalStart(options);
						kernelStarted.resolve();
						return kernel;
					} catch (error) {
						kernelStarted.reject(error);
						throw error;
					}
				};
				const pidFile = `${tempDir.path()}/owned-child.pid`;
				execution = executePython(`%%bash\n(sleep 30) &\nprintf '%s' "$!" > "${pidFile}"\nwait`, {
					cwd: tempDir.path(),
					sessionId: "redteam-bash-descendant-timeout",
					kernelMode: "session",
					signal: controller.signal,
				});
				await startupCalled.promise;
				startupGate.resolve();
				await kernelStarted.promise;
				const childPid = await waitForOwnedProcess(pidFile);
				controller.abort(new DOMException("Python execution timed out", "TimeoutError"));
				const result = await execution;
				expect(result.cancelled).toBe(true);
				expect(await waitForProcessGone(childPid)).toBe(true);
				expect(isProcessAlive(unrelated.pid)).toBe(true);
			} finally {
				startupGate.resolve();
				controller.abort(new DOMException("Python execution timed out", "TimeoutError"));
				await execution?.catch(() => undefined);
				try {
					unrelated.kill("SIGKILL");
				} catch {
					// ignore cleanup races
				}
				await unrelated.exited.catch(() => undefined);
			}
		},
		LIFECYCLE_TEST_TIMEOUT_MS,
	);

	it(
		"rejects the startup handshake and cleans up when kernel startup fails",
		async () => {
			Bun.env.PI_PYTHON_SKIP_CHECK = "1";
			using tempDir = TempDir.createSync("@gjc-python-lifecycle-redteam-");
			const unrelated = Bun.spawn([process.execPath, "-e", "setTimeout(() => {}, 30_000)"], {
				stdout: "ignore",
				stderr: "ignore",
			});
			const kernelStarted = Promise.withResolvers<void>();
			const startupError = new Error("kernel startup failed");
			PythonKernel.start = async () => {
				try {
					throw startupError;
				} catch (error) {
					kernelStarted.reject(error);
					throw error;
				}
			};
			const execution = executePython("print('never runs')", {
				cwd: tempDir.path(),
				sessionId: "redteam-startup-failure",
				kernelMode: "session",
			});
			void execution.catch(() => undefined);
			try {
				await expect(kernelStarted.promise).rejects.toThrow(startupError);
				await expect(execution).rejects.toThrow(startupError);
				expect(isProcessAlive(unrelated.pid)).toBe(true);
			} finally {
				try {
					unrelated.kill("SIGKILL");
				} catch {
					// ignore cleanup races
				}
				await unrelated.exited.catch(() => undefined);
				await disposeAllKernelSessions();
			}
		},
		LIFECYCLE_TEST_TIMEOUT_MS,
	);

	it(
		"retires a cancelled initializer before an uncancelled successor acquires a replacement",
		async () => {
			Bun.env.PI_PYTHON_SKIP_CHECK = "1";
			using tempDir = TempDir.createSync("@gjc-python-lifecycle-redteam-");
			const controller = new AbortController();
			const listeners = countAbortListeners(controller.signal);
			const startup = Promise.withResolvers<void>();
			const startupCalled = Promise.withResolvers<void>();
			const firstKernel = new FakeKernel();
			const secondKernel = new FakeKernel();
			let startCalls = 0;
			PythonKernel.start = async () => {
				startCalls += 1;
				if (startCalls === 1) {
					startupCalled.resolve();
					await startup.promise;
					return firstKernel as unknown as PythonKernel;
				}
				return secondKernel as unknown as PythonKernel;
			};
			try {
				const cancelled = executePython("print('cancelled')", {
					cwd: tempDir.path(),
					sessionId: "redteam-cancelled-initializer",
					kernelMode: "session",
					signal: controller.signal,
				});
				await startupCalled.promise;
				controller.abort(new DOMException("Python execution timed out", "TimeoutError"));
				expect(listeners.count()).toBe(0);

				const successor = executePython("print('successor')", {
					cwd: tempDir.path(),
					sessionId: "redteam-cancelled-initializer",
					kernelMode: "session",
				});
				startup.resolve();
				const [cancelledResult, successorResult] = await Promise.all([cancelled, successor]);
				expect(cancelledResult.cancelled).toBe(true);
				expect(successorResult.cancelled).toBe(false);
				expect(startCalls).toBe(2);
				expect(firstKernel.shutdownCalls).toBe(1);
				expect(secondKernel.executeCalls).toEqual(["print('successor')"]);
			} finally {
				startup.resolve();
				await disposeAllKernelSessions();
				listeners.restore();
			}
			expect(secondKernel.shutdownCalls).toBe(1);
		},
		LIFECYCLE_TEST_TIMEOUT_MS,
	);

	it(
		"settles an in-flight cell during shutdown without leaked abort listeners",
		async () => {
			Bun.env.PI_PYTHON_SKIP_CHECK = "1";
			using tempDir = TempDir.createSync("@gjc-python-lifecycle-redteam-");
			const controller = new AbortController();
			const listeners = countAbortListeners(controller.signal);
			const kernelStarted = Promise.withResolvers<void>();
			let shutdown: (() => Promise<KernelShutdownResult>) | undefined;
			let execution: Promise<PythonResult> | undefined;
			try {
				PythonKernel.start = async () => {
					try {
						const kernel = await originalStart({ cwd: tempDir.path() });
						shutdown = () => kernel.shutdown({ timeoutMs: 100 });
						kernelStarted.resolve();
						return kernel;
					} catch (error) {
						kernelStarted.reject(error);
						throw error;
					}
				};

				const executionReadyFile = `${tempDir.path()}/kernel-executing`;
				execution = executePython(
					`from pathlib import Path\nPath(${JSON.stringify(executionReadyFile)}).touch()\nimport time\ntime.sleep(60)`,
					{
						cwd: tempDir.path(),
						sessionId: "redteam-inflight-shutdown",
						kernelMode: "session",
						signal: controller.signal,
						timeoutMs: 60_000,
					},
				);
				await kernelStarted.promise;
				await waitForFile(executionReadyFile);
				expect(listeners.count()).toBe(1);
				if (!shutdown) throw new Error("Python kernel did not expose shutdown after startup");

				let finished = false;
				void execution.then(() => { finished = true; }, () => { finished = true; });
				await disposeAllKernelSessions();
				await Promise.resolve();
				expect(finished).toBe(true);
				await execution;
				expect(listeners.count()).toBe(0);
			} finally {
				await shutdown?.().catch(() => undefined);
				await execution?.catch(() => undefined);
				listeners.restore();
			}
		},
		LIFECYCLE_TEST_TIMEOUT_MS,
	);

	it(
		"finishes cleanup of a late-starting kernel within a bounded time",
		async () => {
			Bun.env.PI_PYTHON_SKIP_CHECK = "1";
			using tempDir = TempDir.createSync("@gjc-python-lifecycle-redteam-");
			const controller = new AbortController();
			const startup = Promise.withResolvers<void>();
			const startupCalled = Promise.withResolvers<void>();
			const kernel = new FakeKernel();
			kernel.shutdownResult = { confirmed: false };
			// Unconfirmed shutdown leaves the resource live until cleanup succeeds.
			kernel.shutdown = async () => {
				kernel.shutdownCalls += 1;
				if (kernel.shutdownResult.confirmed) kernel.alive = false;
				return kernel.shutdownResult;
			};
			let startupFinished = false;
			PythonKernel.start = async () => {
				startupCalled.resolve();
				await startup.promise;
				startupFinished = true;
				return kernel as unknown as PythonKernel;
			};
			const execution = executePython("import time\ntime.sleep(60)", {
				cwd: tempDir.path(),
				sessionId: "redteam-readiness-failure-cleanup",
				kernelMode: "session",
				signal: controller.signal,
			});
			await startupCalled.promise;
			try {
				await expect(waitForFile(`${tempDir.path()}/never-created`)).rejects.toThrow(
					"Timed out waiting for readiness file",
				);
			} finally {
				controller.abort(new DOMException("Python execution timed out", "TimeoutError"));
				startup.resolve();
				// Cleanup may retry, but it must leave the event loop free to run other work.
				// Only require a heartbeat when cleanup actually takes long enough to measure.
				let heartbeats = 0;
				const startedAt = Date.now();
				const heartbeat = setInterval(() => { heartbeats += 1; }, 10);
				heartbeat.unref();
				try {
					const settled = await settlesWithin(execution, CLEANUP_TIMEOUT_MS);
					expect(settled).toBe(true);
					if (Date.now() - startedAt >= 100) {
						expect(heartbeats).toBeGreaterThan(0);
					}
				} finally {
					clearInterval(heartbeat);
					await execution;
				}
			}
			expect(startupFinished).toBe(true);
			kernel.shutdownResult = { confirmed: true };
			// A later cleanup attempt, whether scheduled internally or requested by
			// the caller, must retire a resource once termination can be confirmed.
			const deadline = Date.now() + CLEANUP_TIMEOUT_MS;
			while (kernel.alive && Date.now() < deadline) {
				await disposeAllKernelSessions();
				if (kernel.alive) await Bun.sleep(50);
			}
			expect(kernel.alive).toBe(false);
		},
		LIFECYCLE_TEST_TIMEOUT_MS,
	);


	it("keeps the original Python runner message protocol compatible", async () => {
		const python = Bun.which("python3");
		expect(python).not.toBeNull();
		// Check the runner directly against the pinned pre-fix version. Using the
		// current TypeScript client on both sides would miss coordinated protocol changes.
		const checker = String.raw`
import json
import os
import pathlib
import subprocess
import sys
import tempfile

source_path = 'packages/coding-agent/src/eval/py/runner.py'
base = subprocess.run(
    ['git', 'show', '540607931662964b814820aa9dcf52c8ee20cdc6:' + source_path],
    check=True, capture_output=True, text=True,
).stdout
current = pathlib.Path(source_path)
assert current.is_file(), 'Python runner is missing'

requests = [
    {'id': 'wire-first', 'code': "value = 42\nprint('wire-stdout')\nvalue", 'silent': False, 'storeHistory': True},
    {'id': 'wire-second', 'code': "raise ValueError('wire-error')", 'silent': False, 'storeHistory': True},
    {'id': 'wire-third', 'code': 'value + 1', 'silent': False, 'storeHistory': True},
    {'type': 'exit'},
]
request_bytes = ''.join(json.dumps(item) + '\n' for item in requests).encode()

def exercise(script):
    proc = subprocess.Popen(
        [sys.executable, '-u', str(script)],
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        cwd=os.getcwd(),
    )
    try:
        stdout, stderr = proc.communicate(request_bytes, timeout=12)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.communicate()
        raise AssertionError('Python runner did not finish its protocol exchange')
    assert proc.returncode == 0, stderr.decode(errors='replace')[-1200:]
    frames = [json.loads(line) for line in stdout.decode().splitlines() if line.strip()]
    assert frames, 'Python runner sent no NDJSON frames'
    ids = ('wire-first', 'wire-second', 'wire-third')
    seen = {key: [] for key in ids}
    for frame in frames:
        assert isinstance(frame, dict) and isinstance(frame.get('type'), str), frame
        if frame.get('id') in seen:
            seen[frame['id']].append(frame)
    for request_id in ids:
        events = seen[request_id]
        assert events and events[0]['type'] == 'started', (request_id, events)
        assert events[-1]['type'] == 'done', (request_id, events)
    # Check the documented protocol values, not the number of stream writes,
    # traceback locations, whitespace in JSON, or additional optional fields.
    first, second, third = (seen[key] for key in ids)
    out = ''.join(str(frame.get('data', '')) for frame in first if frame['type'] == 'stdout')
    assert out == 'wire-stdout\n', first
    assert any(frame['type'] == 'result' and frame.get('bundle', {}).get('text/plain') == '42' for frame in first), first
    assert any(frame['type'] == 'error' and frame.get('ename') == 'ValueError' and frame.get('evalue') == 'wire-error' for frame in second), second
    assert any(frame['type'] == 'result' and frame.get('bundle', {}).get('text/plain') == '43' for frame in third), third
    for index, events in enumerate((first, second, third), start=1):
        done = events[-1]
        assert done.get('status') == ('error' if index == 2 else 'ok'), done
        assert done.get('cancelled') is False, done
        assert done.get('executionCount') == index, done
    return True

with tempfile.TemporaryDirectory() as directory:
    baseline = pathlib.Path(directory) / 'runner.py'
    baseline.write_text(base)
    assert exercise(baseline), 'Pinned runner does not support the expected protocol'
    assert exercise(current.resolve()), 'Python runner broke the existing NDJSON protocol'
`;
		const proc = Bun.spawn([python!, "-c", checker], {
			cwd: process.cwd(), stdout: "pipe", stderr: "pipe",
		});
		const [stdout, stderr, exitCode] = await Promise.all([
			new Response(proc.stdout).text(),
			new Response(proc.stderr).text(),
			proc.exited,
		]);
		expect(exitCode, `${stdout}\n${stderr}`).toBe(0);
	}, LIFECYCLE_TEST_TIMEOUT_MS);

	it("treats clean exit code 0 as confirmed and starts a fresh session instead of reinserting", async () => {
		Bun.env.PI_PYTHON_SKIP_CHECK = "1";
		using tempDir = TempDir.createSync("@gjc-python-lifecycle-redteam-");
		const firstKernel = new FakeKernel();
		const secondKernel = new FakeKernel();
		let startCalls = 0;
		PythonKernel.start = async () => {
			startCalls += 1;
			return (startCalls === 1 ? firstKernel : secondKernel) as unknown as PythonKernel;
		};

		await executePython("print('before clean shutdown')", {
			cwd: tempDir.path(),
			sessionId: "redteam-clean-exit-not-reinserted",
			kernelMode: "session",
		});
		await disposeAllKernelSessions();
		await executePython("print('after clean shutdown')", {
			cwd: tempDir.path(),
			sessionId: "redteam-clean-exit-not-reinserted",
			kernelMode: "session",
		});

		expect(firstKernel.shutdownCalls).toBe(1);
		expect(startCalls).toBe(2);
		expect(secondKernel.executeCalls).toEqual(["print('after clean shutdown')"]);
	});
});
