"""Run the Python execution lifecycle tests through Bun and report their results."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import uuid
import xml.etree.ElementTree as ET
from pathlib import Path

import pytest

REPO_DIR = Path(os.environ.get("REPO_DIR") or f"/repo/{os.environ.get('REPO_NAME', 'gajae-code')}")
BUN_BIN = shutil.which("bun") or "/opt/bun/bin/bun"

# Repeated runs surface the timing-dependent races the suite targets; a stable implementation remains green across all of them.
RERUN_EACH = int(os.environ.get("GJC_VERIFY_RERUN_EACH", "10"))

# Hard ceiling for the whole Bun run. Each case is bounded at 35s; the suite runs
# 11 cases × RERUN_EACH. The ceiling keeps the full run inside its wall
# -clock budget while leaving generous headroom for a healthy run.
BUN_TIMEOUT_SEC = int(os.environ.get("GJC_VERIFY_BUN_TIMEOUT_SEC", "900"))

# Child-subreaper launcher (see module docstring). Materialized next to the copied
# suite at grade time and used as ``python3 <launcher> <bun> test …`` so Bun runs
# as a subreaper: any descendant orphaned by the engine's own cancellation kill
# reparents here and is waited on immediately, so the suite's ``kill(pid, 0)``
# liveness probes observe the real exit instead of a lingering zombie. Runs under
# the verifier's own Python; imports stdlib only.
_REAPER_SOURCE = r'''
import ctypes
import os
import sys

# Linux prctl(2) option: processes orphaned below us reparent to us, not PID 1,
# so we can wait() on them and clear the zombies a plain kill leaves behind.
_PR_SET_CHILD_SUBREAPER = 36


def _become_subreaper() -> None:
    if not sys.platform.startswith("linux"):
        return
    try:
        libc = ctypes.CDLL("libc.so.6", use_errno=True)
        libc.prctl(_PR_SET_CHILD_SUBREAPER, 1, 0, 0, 0)
    except Exception:
        # Best effort: without the subreaper bit a correct run is unaffected on a
        # host that already reaps (e.g. an init-backed container); only the
        # no-init container needs this, and there prctl is available.
        pass


def main() -> None:
    cmd = sys.argv[1:]
    if not cmd:
        os._exit(2)
    _become_subreaper()
    child = os.fork()
    if child == 0:
        try:
            os.execvp(cmd[0], cmd)
        except OSError:
            os._exit(127)
    exit_code = 0
    while True:
        try:
            wpid, status = os.waitpid(-1, 0)
        except ChildProcessError:
            break
        if wpid != child:
            # A reparented orphan: reaped by this very waitpid; keep going.
            continue
        exit_code = 128 + os.WTERMSIG(status) if os.WIFSIGNALED(status) else os.WEXITSTATUS(status)
        # Drain any descendants still queued as zombies before exiting so none
        # outlive this launcher.
        while True:
            try:
                reaped, _ = os.waitpid(-1, os.WNOHANG)
            except ChildProcessError:
                break
            if reaped == 0:
                break
        break
    sys.exit(exit_code)


main()
'''

# Behavioral case key -> the Bun ``it(...)`` title it is reported under. Keys are
# the stable identifiers used across the task's criteria; titles must match the
# suite verbatim.
CASE_TITLES: dict[str, str] = {
    "proc_group_terminated": "stops managed-runtime provisioning and its descendants after cancellation",
    "deadline_expired": "stops provisioned descendants when the execution deadline expires without caller abort",
    "independent_session_survives": "keeps another active session usable when one session is cancelled",
    "coalesce_no_orphan": "coalesces five concurrent first acquires for the same new session without orphan kernels",
    "owned_descendant_only": "kills only the owned bash background descendant after timeout while an unrelated sibling survives",
    "startup_failure_cleanup": "rejects the startup handshake and cleans up when kernel startup fails",
    "cancelled_initializer_retired": "retires a cancelled initializer before an uncancelled successor acquires a replacement",
    "inflight_settled_no_leak": "settles an in-flight cell during shutdown without leaked abort listeners",
    "retiring_kernel_retry_bounded": "finishes cleanup of a late-starting kernel within a bounded time",
    "runner_protocol_compatible": "keeps the original Python runner message protocol compatible",
    "clean_exit_confirmed": "treats clean exit code 0 as confirmed and starts a fresh session instead of reinserting",
}

_SUITE_SOURCE = Path(__file__).resolve().parent / "python-lifecycle.verify.test.ts"


def _run_bun_suite() -> dict[str, bool]:
    """Run the Bun suite once (with reruns) and return {case_key: passed}.

    Raises when the run itself could not be carried out (environment, toolchain,
    or invocation broke) so that condition is reported as an execution error
    rather than being scored as a wrong answer. A clean run where some cases fail
    returns those cases as False.
    """
    if not REPO_DIR.is_dir():
        raise RuntimeError(f"repo dir not found: {REPO_DIR}")
    if not _SUITE_SOURCE.is_file():
        raise RuntimeError(f"lifecycle suite not found: {_SUITE_SOURCE}")

    # Copy the lifecycle suite into a unique directory under the repo root so Bun
    # resolves the workspace packages and the submitted change cannot have
    # touched it. A nested dir keeps the repo's own test tree untouched.
    grader_dir = REPO_DIR / f".gjc-verify-{uuid.uuid4().hex}"
    grader_dir.mkdir(parents=True, exist_ok=False)
    suite_path = grader_dir / "python-lifecycle.verify.test.ts"
    xml_path = grader_dir / "bun-results.xml"
    reaper_path = grader_dir / "gjc_subreaper.py"
    try:
        shutil.copyfile(_SUITE_SOURCE, suite_path)
        reaper_path.write_text(_REAPER_SOURCE)
        # Launch Bun through the child-subreaper so descendants orphaned by the
        # engine's cancellation kill are reaped promptly (see module docstring),
        # keeping the suite's liveness probes honest in the no-init grading
        # container.
        cmd = [
            sys.executable,
            str(reaper_path),
            BUN_BIN,
            "test",
            str(suite_path),
            "--rerun-each",
            str(RERUN_EACH),
            "--reporter=junit",
            f"--reporter-outfile={xml_path}",
        ]
        env = {**os.environ}
        env["PATH"] = os.pathsep.join(filter(None, ["/opt/bun/bin", env.get("PATH", "")]))
        try:
            proc = subprocess.run(
                cmd,
                cwd=str(REPO_DIR),
                capture_output=True,
                text=True,
                timeout=BUN_TIMEOUT_SEC,
                check=False,
                env=env,
            )
        except subprocess.TimeoutExpired as exc:
            raise RuntimeError(f"bun test timed out after {BUN_TIMEOUT_SEC}s") from exc

        if not xml_path.exists():
            raise RuntimeError(
                "bun test produced no JUnit XML "
                f"(exit {proc.returncode}).\n--- stdout ---\n{proc.stdout[-4000:]}\n"
                f"--- stderr ---\n{proc.stderr[-4000:]}"
            )
        return _parse_results(xml_path, proc.stdout, proc.stderr, proc.returncode)
    finally:
        shutil.rmtree(grader_dir, ignore_errors=True)


def _parse_results(xml_path: Path, stdout: str, stderr: str, returncode: int) -> dict[str, bool]:
    """Parse Bun's JUnit XML into {case_key: passed_every_rerun}.

    Bun emits one <testcase> per execution; with --rerun-each a case appears
    multiple times. A case passes only if no occurrence failed or errored and at
    least one occurrence was recorded.
    """
    tree = ET.parse(str(xml_path))  # noqa: S314 - trusted local file produced by bun
    root = tree.getroot()

    seen: dict[str, int] = {}
    failed: dict[str, bool] = {}
    for tc in root.iter("testcase"):
        name = tc.get("name", "")
        classname = tc.get("classname", "")
        hay = f"{classname} {name}"
        for key, title in CASE_TITLES.items():
            if title in hay:
                seen[key] = seen.get(key, 0) + 1
                is_bad = tc.find("failure") is not None or tc.find("error") is not None
                failed[key] = failed.get(key, False) or is_bad

    missing = [key for key in CASE_TITLES if seen.get(key, 0) == 0]
    if missing:
        raise RuntimeError(
            "bun suite did not report expected case(s): "
            f"{missing}\n--- stdout ---\n{stdout[-4000:]}\n--- stderr ---\n{stderr[-4000:]}"
        )
    return {key: not failed.get(key, False) for key in CASE_TITLES}


# Run the Bun suite exactly once for the whole module; each case assertion reads
# from the shared result map.
@pytest.fixture(scope="module")
def suite_results() -> dict[str, bool]:
    return _run_bun_suite()


@pytest.mark.parametrize("case_key", list(CASE_TITLES))
def test_python_eval_lifecycle_case(case_key: str, suite_results: dict[str, bool]) -> None:
    assert suite_results.get(case_key) is True, (
        f"behavioral case '{case_key}' did not pass on every rerun"
    )
