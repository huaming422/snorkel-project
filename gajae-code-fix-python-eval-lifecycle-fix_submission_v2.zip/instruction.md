## Task

The Python evaluation engine sometimes leaves child processes running after a cancellation or timeout. Cancelling during kernel startup can also interfere with the next run, and shutdown can finish while a cell is still active. These problems are intermittent and show up more often when the lifecycle tests are repeated.

Make cancellation, timeout, startup failure, and shutdown reliable, including when several callers start work at the same time. Clean up work owned by the cancelled run without disrupting unrelated processes. Cleanup must finish within a reasonable bound without spinning or keeping the application alive after shutdown. Preserve the existing public API and Python runner protocol.

The work is offline. Bun and Python 3 are available in the environment.
