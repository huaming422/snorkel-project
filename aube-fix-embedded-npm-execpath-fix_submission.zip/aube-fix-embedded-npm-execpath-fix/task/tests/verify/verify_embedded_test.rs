//! Behavioral verifier — embedded case (fail_to_pass, basic).
//!
//! When aube runs embedded inside a foreign host, a package lifecycle
//! script's `npm_execpath` must never be the host/running executable: the
//! host's CLI is its own, so `${npm_execpath} run <script>` stamped with it
//! silently misroutes into the host's command surface. A valid fix makes the
//! stamped value a re-entrant aube shim or leaves it unset — never the host.
//!
//! HOW THIS STAYS DECOUPLED FROM THE FIX:
//!   * It drives aube's PRE-EXISTING public `embed` facade — `initialize` +
//!     `add` — exactly the interface `crates/aube/tests/embed.rs` already
//!     tests through. No symbol the fix invents is named or imported.
//!   * The embedded state is established the supported way: register a `Host`
//!     whose name is not `"aube"` via `aube::embed::initialize`.
//!   * It observes the stamped environment the way a real package does — a
//!     `pnpm:devPreinstall` lifecycle script records its own `npm_execpath`
//!     to a marker file — then discriminates by VALUE: the recorded value is
//!     compared against the test process's own `std::env::current_exe()`
//!     (the host, in-process). Pre-fix they are equal (the bug); post-fix
//!     they differ. Nothing here turns the pre-fix state into a compile
//!     error.
//!
//! Its own test binary: the active embedder profile is registered
//! once-per-process, so the embedded assertion cannot share a process with
//! the standalone one (`verify_standalone_test.rs`). The runner gives each
//! `verify*_test.rs` its own `cargo test --test <stem>` process.

use aube::embed::{AddToProjectOptions, Host, InstallControl};
use std::path::PathBuf;

/// A foreign host: its `name` is not `"aube"`, so `aube` recognizes it as an
/// embedder. Shape copied from the `TEST_HOST` in `crates/aube/tests/embed.rs`.
static FOREIGN_HOST: Host = Host {
    name: "testhost",
    display_name: "Test Host",
    vendor: None,
    version: "1.0.0",
    user_agent: "testhost/1.0.0",
    self_names: &["testhost"],
    compatible_names: &["pnpm"],
    lockfile_basename: "testhost-lock.yaml",
    workspace_yaml: None,
    manifest_namespace: "testhost",
    env_prefix: None,
    config_env_prefix: None,
    cache_namespace: "testhost",
    data_namespace: "testhost",
    canonical_lockfile_always_wins: true,
    runtime_switching: false,
    self_engines_check: false,
    self_update_enabled: false,
};

/// Name of the marker file the lifecycle script writes into its working
/// directory (the workspace root, where a root `pnpm:devPreinstall` runs).
const MARKER_NAME: &str = "execpath.marker";

/// A pnpm workspace with an `app` member and a `library` member, plus a root
/// `package.json` whose `pnpm:devPreinstall` lifecycle script records the
/// `npm_execpath` it is handed into `MARKER_NAME` in its CWD. `add
/// library@workspace:*` to the app runs that root lifecycle script. Mirrors
/// `workspace_fixture` + `facade_add_runs_root_dev_preinstall` from
/// `crates/aube/tests/embed.rs` (whose root script likewise writes a marker
/// into its CWD — the workspace root).
fn workspace_with_execpath_probe() -> (tempfile::TempDir, PathBuf) {
    let workspace = tempfile::tempdir().unwrap();
    let app = workspace.path().join("packages/app");
    let library = workspace.path().join("packages/library");
    std::fs::create_dir_all(&app).unwrap();
    std::fs::create_dir_all(&library).unwrap();

    // The script writes the marker to a relative path, so it lands in the
    // script's working directory (the workspace root) — the proven pattern
    // from `facade_add_runs_root_dev_preinstall`, no path escaping needed.
    let manifest = serde_json::json!({
        "private": true,
        "scripts": {
            "pnpm:devPreinstall":
                "node -e \"require('fs').writeFileSync('execpath.marker', 'npm_execpath=' + (process.env.npm_execpath || ''))\""
        }
    });
    std::fs::write(
        workspace.path().join("package.json"),
        serde_json::to_vec(&manifest).unwrap(),
    )
    .unwrap();
    std::fs::write(
        workspace.path().join("pnpm-workspace.yaml"),
        "packages:\n  - packages/*\n",
    )
    .unwrap();
    std::fs::write(app.join("package.json"), "{\"name\":\"app\"}\n").unwrap();
    std::fs::write(
        library.join("package.json"),
        "{\"name\":\"library\",\"version\":\"1.0.0\"}\n",
    )
    .unwrap();

    (workspace, app)
}

/// Read back the `npm_execpath=<value>` the lifecycle script recorded; an
/// absent variable records an empty value.
fn recorded_execpath(marker: &std::path::Path) -> String {
    let contents = std::fs::read_to_string(marker).unwrap_or_else(|e| {
        panic!("the devPreinstall lifecycle script did not record a marker at {marker:?}: {e}")
    });
    contents
        .strip_prefix("npm_execpath=")
        .unwrap_or(&contents)
        .trim_end()
        .to_string()
}

#[tokio::test]
async fn embedded_lifecycle_execpath_is_never_the_host_executable() {
    aube::embed::initialize(
        &FOREIGN_HOST,
        vec![("minimumReleaseAge".to_string(), "0".to_string())],
    );

    let (workspace, app) = workspace_with_execpath_probe();
    let marker = workspace.path().join(MARKER_NAME);

    aube::embed::add(
        &app,
        &["library@workspace:*".to_string()],
        AddToProjectOptions {
            offline: true,
            control: InstallControl::silent(),
            ..Default::default()
        },
    )
    .await
    .unwrap();

    let recorded = recorded_execpath(&marker);
    let host_exe = std::env::current_exe()
        .expect("the test process has a current_exe")
        .to_string_lossy()
        .into_owned();

    // Discriminate by VALUE. Pre-fix the stamp is unconditionally
    // `current_exe()` — this very process's (the host's) executable — so
    // `recorded == host_exe` and this fails. Post-fix the embedded value is a
    // re-entrant aube shim or unset (empty), so it differs from the host.
    assert_ne!(
        recorded, host_exe,
        "embedded, a lifecycle script's npm_execpath must not be the host/running executable \
         ({host_exe:?}); it must be a re-entrant aube shim or left unset, got {recorded:?}"
    );
}
