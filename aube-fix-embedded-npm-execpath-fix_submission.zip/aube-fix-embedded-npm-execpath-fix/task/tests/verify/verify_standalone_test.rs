//! Behavioral verifier — standalone case (pass_to_pass, basic).
//!
//! The common, non-embedded path must not regress: standalone aube still
//! exports its own binary as `npm_execpath` to lifecycle scripts. A fix that
//! unsets or shims the standalone case too is wrong, and this holds both
//! pre-fix and post-fix.
//!
//! HOW THIS STAYS DECOUPLED FROM THE FIX:
//!   * Same pre-existing public `embed` facade and same lifecycle-script
//!     probe as `verify_embedded_test.rs`. No fix-invented symbol is named.
//!   * "Standalone" is established by registering aube's OWN profile
//!     (`aube::embed::AUBE`) as the active embedder — what aube's own binary
//!     does on every run — so the host/guest predicate reads not-embedded.
//!   * Discriminates by VALUE: the recorded `npm_execpath` is compared for
//!     equality against the test process's own `current_exe()`.
//!
//! Its own test binary: the active embedder profile is once-per-process, so
//! this standalone assertion cannot share a process with the embedded tests.

use aube::embed::{AddToProjectOptions, InstallControl};
use std::path::PathBuf;

/// Name of the marker file the lifecycle script writes into its working
/// directory (the workspace root, where a root `pnpm:devPreinstall` runs).
const MARKER_NAME: &str = "execpath.marker";

fn workspace_with_execpath_probe() -> (tempfile::TempDir, PathBuf) {
    let workspace = tempfile::tempdir().unwrap();
    let app = workspace.path().join("packages/app");
    let library = workspace.path().join("packages/library");
    std::fs::create_dir_all(&app).unwrap();
    std::fs::create_dir_all(&library).unwrap();

    let manifest = serde_json::json!({
        "private": true,
        "scripts": {
            "pnpm:devPreinstall":
                "node -e \"require('fs').writeFileSync('execpath.marker', 'npm_execpath=' + (process.env.npm_execpath || ''))\""
        }
    });
    std::fs::write(
        workspace.path().join("package.json"),
        serde_json::to_vec(&manifest).unwrap(),
    )
    .unwrap();
    std::fs::write(
        workspace.path().join("pnpm-workspace.yaml"),
        "packages:\n  - packages/*\n",
    )
    .unwrap();
    std::fs::write(app.join("package.json"), "{\"name\":\"app\"}\n").unwrap();
    std::fs::write(
        library.join("package.json"),
        "{\"name\":\"library\",\"version\":\"1.0.0\"}\n",
    )
    .unwrap();

    (workspace, app)
}

fn recorded_execpath(marker: &std::path::Path) -> String {
    let contents = std::fs::read_to_string(marker).unwrap_or_else(|e| {
        panic!("the devPreinstall lifecycle script did not record a marker at {marker:?}: {e}")
    });
    contents
        .strip_prefix("npm_execpath=")
        .unwrap_or(&contents)
        .trim_end()
        .to_string()
}

#[tokio::test]
async fn standalone_lifecycle_execpath_is_the_running_binary() {
    // Register aube's own profile — the active embedder is aube itself, so
    // the host/guest predicate reads standalone (not embedded).
    aube::embed::initialize(
        &aube::embed::AUBE,
        vec![("minimumReleaseAge".to_string(), "0".to_string())],
    );

    let (workspace, app) = workspace_with_execpath_probe();
    let marker = workspace.path().join(MARKER_NAME);

    aube::embed::add(
        &app,
        &["library@workspace:*".to_string()],
        AddToProjectOptions {
            offline: true,
            control: InstallControl::silent(),
            ..Default::default()
        },
    )
    .await
    .unwrap();

    let recorded = recorded_execpath(&marker);
    let aube_exe = std::env::current_exe()
        .expect("the test process has a current_exe")
        .to_string_lossy()
        .into_owned();

    // Standalone, the running binary IS the package manager, so a script's
    // `${npm_execpath} run …` must reach it. Holds pre-fix and post-fix.
    assert_eq!(
        recorded, aube_exe,
        "standalone, a lifecycle script's npm_execpath must be aube's own binary ({aube_exe:?}), \
         got {recorded:?}"
    );
}
