//! Behavioral verifier — inherited outer value (fail_to_pass, non-basic).
//!
//! aube may itself be spawned inside *someone else's* package-manager
//! lifecycle, which exports its own `npm_execpath` into the environment aube
//! inherits. aube must stamp its OWN answer onto the scripts it spawns — it
//! must not pass that stale inherited value through.
//!
//! This runs embedded (a foreign host) so it is a genuine fail_to_pass:
//!   * pre-fix, the stamp is unconditionally the running (host) executable,
//!     so the recorded value equals this process's `current_exe()` — the
//!     same misrouting `verify_embedded_test.rs` pins — and the first
//!     assertion fails;
//!   * post-fix, the value is a re-entrant aube shim or unset, which is
//!     neither the host executable NOR the inherited sentinel.
//!
//! The pre-set sentinel adds a distinct guarantee beyond the embedded test:
//! it rejects a fix that merely *skips* stamping when embedded (leaving
//! whatever was inherited in place) instead of clearing it first — such a
//! fix would hand the scripts the outer manager's stale path. Both clauses
//! must hold.
//!
//! HOW THIS STAYS DECOUPLED: same pre-existing public `embed` facade and
//! lifecycle-script probe as the sibling verifiers; discriminates by VALUE
//! (against the test process's own `current_exe()` and the sentinel it set),
//! never by whether an internal symbol compiles. Its own test binary for the
//! once-per-process embedder registration.

use aube::embed::{AddToProjectOptions, Host, InstallControl};
use std::path::PathBuf;

static FOREIGN_HOST: Host = Host {
    name: "testhost",
    display_name: "Test Host",
    vendor: None,
    version: "1.0.0",
    user_agent: "testhost/1.0.0",
    self_names: &["testhost"],
    compatible_names: &["pnpm"],
    lockfile_basename: "testhost-lock.yaml",
    workspace_yaml: None,
    manifest_namespace: "testhost",
    env_prefix: None,
    config_env_prefix: None,
    cache_namespace: "testhost",
    data_namespace: "testhost",
    canonical_lockfile_always_wins: true,
    runtime_switching: false,
    self_engines_check: false,
    self_update_enabled: false,
};

/// A path no real resolution would ever produce — stands in for an outer
/// package manager's `npm_execpath` that aube inherits.
const INHERITED_SENTINEL: &str = "/outer-package-manager/bin/not-aube-execpath";

/// Name of the marker file the lifecycle script writes into its working
/// directory (the workspace root, where a root `pnpm:devPreinstall` runs).
const MARKER_NAME: &str = "execpath.marker";

fn workspace_with_execpath_probe() -> (tempfile::TempDir, PathBuf) {
    let workspace = tempfile::tempdir().unwrap();
    let app = workspace.path().join("packages/app");
    let library = workspace.path().join("packages/library");
    std::fs::create_dir_all(&app).unwrap();
    std::fs::create_dir_all(&library).unwrap();

    let manifest = serde_json::json!({
        "private": true,
        "scripts": {
            "pnpm:devPreinstall":
                "node -e \"require('fs').writeFileSync('execpath.marker', 'npm_execpath=' + (process.env.npm_execpath || ''))\""
        }
    });
    std::fs::write(
        workspace.path().join("package.json"),
        serde_json::to_vec(&manifest).unwrap(),
    )
    .unwrap();
    std::fs::write(
        workspace.path().join("pnpm-workspace.yaml"),
        "packages:\n  - packages/*\n",
    )
    .unwrap();
    std::fs::write(app.join("package.json"), "{\"name\":\"app\"}\n").unwrap();
    std::fs::write(
        library.join("package.json"),
        "{\"name\":\"library\",\"version\":\"1.0.0\"}\n",
    )
    .unwrap();

    (workspace, app)
}

fn recorded_execpath(marker: &std::path::Path) -> String {
    let contents = std::fs::read_to_string(marker).unwrap_or_else(|e| {
        panic!("the devPreinstall lifecycle script did not record a marker at {marker:?}: {e}")
    });
    contents
        .strip_prefix("npm_execpath=")
        .unwrap_or(&contents)
        .trim_end()
        .to_string()
}

#[tokio::test]
async fn inherited_outer_execpath_is_not_passed_through() {
    aube::embed::initialize(
        &FOREIGN_HOST,
        vec![("minimumReleaseAge".to_string(), "0".to_string())],
    );

    // Seed the ambient outer manager's value into this process's environment,
    // which a non-jailed lifecycle script would otherwise inherit.
    // SAFETY: single-threaded test process, set before any spawn.
    unsafe { std::env::set_var("npm_execpath", INHERITED_SENTINEL) };

    let (workspace, app) = workspace_with_execpath_probe();
    let marker = workspace.path().join(MARKER_NAME);

    aube::embed::add(
        &app,
        &["library@workspace:*".to_string()],
        AddToProjectOptions {
            offline: true,
            control: InstallControl::silent(),
            ..Default::default()
        },
    )
    .await
    .unwrap();

    let recorded = recorded_execpath(&marker);
    let host_exe = std::env::current_exe()
        .expect("the test process has a current_exe")
        .to_string_lossy()
        .into_owned();

    // f2p driver: pre-fix the stamp is unconditionally this (host) process's
    // executable, so the embedded value misroutes into the host CLI.
    assert_ne!(
        recorded, host_exe,
        "embedded, a lifecycle script's npm_execpath must not be the host/running executable \
         ({host_exe:?}), got {recorded:?}"
    );
    // Passthrough guard: the inherited outer value must never reach the
    // script — aube stamps its own answer, not the one it inherited.
    assert_ne!(
        recorded, INHERITED_SENTINEL,
        "an npm_execpath inherited from an outer package manager must not be passed through to \
         the scripts aube spawns, got {recorded:?}"
    );
}
