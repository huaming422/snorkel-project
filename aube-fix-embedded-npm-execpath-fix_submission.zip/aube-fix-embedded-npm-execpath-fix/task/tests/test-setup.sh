#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# aube is a Rust workspace; the image baked the full dependency closure
# (cargo fetch --locked + cargo build --locked --tests). This step brings that
# closure online offline-first and fails fast if the image bake was stale.
cd /repo/aube

# Cut the network for cargo so a cache miss fails loudly instead of reaching a
# registry (the smoke gate's offline fold sources this under `--network none`).
export CARGO_NET_OFFLINE=true

# Dependencies: offline-first against the image bake, logged online fallback.
if cargo fetch --locked --offline > /tmp/test-setup-fetch.log 2>&1; then
    echo "[offline-first] cargo deps satisfied from image"
elif CARGO_NET_OFFLINE=false cargo fetch --locked >> /tmp/test-setup-fetch.log 2>&1; then
    echo "[test-setup] cargo deps fetched online (image bake was stale)"
else
    tail -40 /tmp/test-setup-fetch.log >&2; exit 1
fi

# No services to start and no data to seed: the behavior under test is produced
# entirely in-process by aube's embedding facade when it runs a lifecycle script.
# No assertion logic here — that lives in the verifier.
