// Checks for the hh.ru source adapter and the egress tiers it participates in. These run as
// `package sources` to reach the package's own stable test helpers (hhVac, hhSearchHTML,
// hhDetailHTML, hhFake) and the exported tier-application entry points — NOT to read any adapter's
// internal fields or name its constructors. Every assertion is on an OBSERVABLE: a provider's
// registry entry rewired (or deliberately left alone) by an egress tier, or a description hydrated
// by the public FetchNew path. No constructor, struct field, or tier-map key introduced by the fix
// is referenced, so any wiring that produces the same observable routing satisfies these checks.
//
// What the checks pin, and why at this altitude: the two production failure halves are each a
// transport decision observable at the registry boundary — the per-vacancy detail fetch must be
// carried by the hosted (scraping-API) tier, and the listing crawl must no longer be carried by the
// proxy tier. The no-key dev path is pinned behaviorally (a new posting still hydrates through the
// per-posting detail fetch) so an over-correction that leaves the detail getter unwired is caught.
package sources

import (
	"context"
	"io"
	"net/url"
	"strings"
	"testing"

	"golang.org/x/net/html"
)

// fullHHFake adapts the package's hh recording getter (hhFake, which implements only GetHTML) up to
// the full HTTPClient surface All() expects, so the dev path can be driven through the public
// registry instead of any adapter constructor. Every call the hh crawl makes — listing and detail —
// still lands on the embedded hhFake's GetHTML (and its recorders); the remaining transport roles
// are unused by hh and stub out.
type fullHHFake struct {
	*hhFake
}

func (fullHHFake) GetJSON(context.Context, string, any) error               { return nil }
func (fullHHFake) GetJSONResolved(_ context.Context, u string, _ any) (string, error) {
	return u, nil
}
func (fullHHFake) GetStream(context.Context, string, string, func(io.Reader) error) error {
	return nil
}
func (fullHHFake) GetXML(context.Context, string, any) error { return nil }
func (fullHHFake) GetHTMLResolved(_ context.Context, u string) (*html.Node, string, error) {
	return nil, u, nil
}
func (fullHHFake) GetText(context.Context, string) (string, error) { return "", nil }
func (fullHHFake) GetTextWithHeaders(context.Context, string, map[string]string) (string, error) {
	return "", nil
}
func (fullHHFake) GetLargeText(context.Context, string) (string, error)   { return "", nil }
func (fullHHFake) PostJSON(context.Context, string, any, any) error       { return nil }
func (fullHHFake) GetJSONWithHeaders(context.Context, string, map[string]string, any) error {
	return nil
}
func (fullHHFake) PostJSONWithHeaders(context.Context, string, map[string]string, any, any) error {
	return nil
}
func (fullHHFake) PostFormWithHeaders(context.Context, string, map[string]string, url.Values) (*html.Node, error) {
	return nil, nil
}
func (fullHHFake) CookieValue(string, string) string { return "" }

// TestVerifyHHListingNotProxied: hh must no longer be carried by the proxy egress tier. With
// SOURCES_PROXY_URL set, applying the proxy tier over the full registry must leave hh's entry
// exactly as All built it — hh is not a proxied provider, so that tier does not rebuild it. Fails
// pre-fix (hh is a proxied provider, so the tier rebuilds its entry and the pointer changes).
func TestVerifyHHListingNotProxied(t *testing.T) {
	registry := All(NewClient())
	before := registry["hh"]
	t.Setenv("SOURCES_PROXY_URL", "http://user:pass@proxy.example:8080")
	if err := ApplyProxyEgress(registry); err != nil {
		t.Fatalf("ApplyProxyEgress: %v", err)
	}
	if registry["hh"] != before {
		t.Error("hh must stay on its direct client after the proxy tier is applied; its crawl must not be re-proxied")
	}
}

// TestVerifyHHDetailOnHostedTier: the hh detail fetch must be served by the hosted (scraping-API)
// egress tier. With a hosted-tier key configured, applying that tier must rewire hh's registry
// entry onto the hosted transport. Keyed on the provider name only — the membership is observed
// through ApplyFirecrawlEgress, not by reading the tier map or naming the build function. Fails
// pre-fix (hh is not a hosted-tier member, so the tier does not rewire it).
func TestVerifyHHDetailOnHostedTier(t *testing.T) {
	registry := All(NewClient())
	before := registry["hh"]
	t.Setenv("FIRECRAWL_API_KEY", "test-key")
	if err := ApplyFirecrawlEgress(registry); err != nil {
		t.Fatalf("ApplyFirecrawlEgress: %v", err)
	}
	if registry["hh"] == before {
		t.Error("with a hosted-tier key set, hh must be rewired onto the hosted transport for its detail fetch")
	}
}

// TestVerifyHHDevPathHydrates: the no-key / dev path still hydrates a new posting's description
// through the per-posting detail fetch, and never leaves that fetch unwired. Driven through the
// public All() registry entry and the HydratingSource interface with one recording client serving
// both the listing and the detail pages — the dev path is whatever transport wiring All() gives hh
// with no egress tier applied. Passes pre- and post-fix — a pass_to_pass guard against an
// over-correction that leaves the dev detail fetch unset (which would stop hydrating or nil-panic).
func TestVerifyHHDevPathHydrates(t *testing.T) {
	v := hhVac(101, "Go Developer", "Контур")
	fake := &hhFake{
		searchByPage: map[int][]hhVacancy{0: {v}},
		detailByID:   map[string]string{"101": "<p>Full description body.</p>"},
	}
	jobs, err := All(fullHHFake{fake})["hh"].(HydratingSource).
		FetchNew(context.Background(), CompanyEntry{Board: "96"}, func(string) bool { return false })
	if err != nil {
		t.Fatalf("FetchNew: %v", err)
	}
	if len(jobs) != 1 {
		t.Fatalf("len(jobs) = %d, want 1", len(jobs))
	}
	if d := jobs[0].Description; !strings.Contains(d, "Full description body") {
		t.Errorf("dev path did not hydrate the description body from the detail fetch: %q", d)
	}
	if len(fake.detailHits) != 1 || fake.detailHits[0] != "101" {
		t.Errorf("the per-posting detail fetch did not run for the new vacancy; detail hits = %v", fake.detailHits)
	}
}
