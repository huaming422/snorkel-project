## Task

freehire pulls postings from many job boards, hh.ru among them. hh works in two passes: a listing crawl enumerates the open vacancies, then a follow-up fetch pulls each one's full description body.

in production a big chunk of hh postings are landing with no description. title, company, location, salary all come through fine, but the body is empty or missing. the listing side looks healthy, we're finding roles and the postings show up, so it's the per-posting detail fetch that's coming back empty. and it's production only: the same posting that lands body-less in production hydrates fine from a local or dev run. so it's about how that detail fetch leaves our infra in production, not the posting data or how we parse the page.

it doesn't sort itself out on later runs either. once we've seen a posting we refresh it by identity and never go back for the detail, so anything that landed body-less stays body-less.

dig into why hh detail hydration is failing in production and fix it so the descriptions get ingested again. the local/dev path works today and the other sources are fine; the fix shouldn't disturb either.
