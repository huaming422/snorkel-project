## Task

3D figures such as sensor alignment, source estimates and field maps do not render in JupyterLite or Pyodide browser kernels because VTK has no WebAssembly build.

Add a new backend named `jupyterlite_notebook` that uses the already installed `pyvista-js` library for browser-based rendering.

It should support the required 3D geometry, including surfaces, meshes, tubes, spheres and glyphs such as arrows, cones and cylinders. Their size, position and orientation must match the desktop backend exactly, since visually plausible but incorrect transformations are not acceptable.

The figure's `plotter` should be the rendering library's own plotter, following the same approach as the desktop backends.

Each mesh should use one solid color, with per-instance transparency preserved through opacity.

The backend must work without VTK installed. Automatic backend selection must never choose it, even when no other backend is available.

The interactive time viewer, contours, scalar bars, legends, subplots and in-kernel screenshots must raise `NotImplementedError` with clear messages.

The scope covers the new backend and any numpy changes it requires. JupyterLite documentation wiring is out of scope.

## User stories / requirements

- Selecting the new browser backend and drawing a static scene of a mesh and a sphere yields a figure whose scene data comes through intact: the mesh points, the triangle faces, and the camera orientation all match what was set. Setting the view by azimuth and elevation orients the scene like the desktop backend does.
- The sensor alignment 3D plot runs successfully on a small dataset and produces a complete figure. Instances with the same color are merged into a single object, and the number of drawn objects reflects this grouping.
