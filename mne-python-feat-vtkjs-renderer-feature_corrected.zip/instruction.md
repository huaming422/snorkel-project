## Task

3D figures such as sensor alignment, source estimates and field maps do not render in JupyterLite or Pyodide browser kernels because VTK has no WebAssembly build.

Add a new backend named `jupyterlite_notebook` that uses the already installed `pyvista-js` library for browser-based rendering.

It should support the required 3D geometry, including surfaces, meshes, tubes, spheres and glyphs such as arrows, cones and cylinders. Their size, position and orientation must match the desktop backend exactly.

Users should be able to interact with the `pyvista-js` plotter directly through the figure, just as they can work with PyVista on the desktop.

Each mesh should use a single solid color, while preserving the transparency of individual instances.

The backend must work without VTK installed. Automatic backend selection must never choose it, even when no other backend is available.

The interactive time viewer, contours, scalar bars, legends, subplots and in-kernel screenshots must raise `NotImplementedError` with clear messages.

The scope covers the new backend and any numpy changes it requires. JupyterLite documentation wiring is out of scope.

## User stories / requirements

- Selecting this backend and rendering a mesh and a sphere produces a figure. The points and triangles in the rendered geometry match the input geometry. The azimuth and elevation set the library camera to the same viewing direction as the desktop backend.

- The sensor alignment 3D plot runs successfully on a small dataset and produces a complete figure. Instances with the same color are merged into a single object, and the number of drawn objects reflects this grouping.
