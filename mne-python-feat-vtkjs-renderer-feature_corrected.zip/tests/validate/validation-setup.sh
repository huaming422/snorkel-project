#!/usr/bin/env bash
# Sourced before the validation stories run. It mirrors tests/test-setup.sh:
# the image already baked the full dependency closure (repo runtime deps + the
# pinned test tools + the browser drawing library, installed editable into
# /opt/mne-venv at the base commit), so there is nothing to install here.
# Everything below must succeed with the network cut.
cd /repo/mne-python

# Fail fast on a cache miss instead of reaching for PyPI if any uv touchpoint
# re-resolves (the repo venv is plain-venv editable, but keep the guard honest).
export UV_OFFLINE=1
export PIP_NO_INDEX=1

# Make the repo's own venv the active interpreter for the validation stories.
# It already has numpy/scipy/matplotlib, the MNE editable install, the pinned
# pytest stack, and the browser drawing library baked in. The pytest driver is
# additionally pointed at /opt/mne-venv/bin/python via [settings.pytest].python
# in validation_spec.toml.
export VIRTUAL_ENV=/opt/mne-venv
export PATH="/opt/mne-venv/bin:${PATH}"

# Confirm the baked closure is present offline. This is a readiness check, not
# an install — if it fails the image bake was wrong and validation must abort.
if /opt/mne-venv/bin/python - <<'PY' > /tmp/validation-setup-closure.log 2>&1
import importlib
for mod in ("numpy", "scipy", "matplotlib", "mne", "pyvista_js"):
    importlib.import_module(mod)
PY
then
    echo "[offline-first] repo + browser-renderer closure satisfied from image bake"
else
    echo "[validation-setup] FATAL: baked dependency closure missing offline" >&2
    tail -40 /tmp/validation-setup-closure.log >&2
    exit 1
fi
