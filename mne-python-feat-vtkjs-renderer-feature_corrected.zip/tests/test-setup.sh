#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# The image baked the full dependency closure (repo runtime deps + the pinned
# test tools + pyvista-js, all installed editable into /opt/mne-venv at the base
# commit), so there is nothing to install online here. Everything below must
# succeed with the network cut — the offline fold sources this script under
# `docker run --network none`.
cd /repo/mne-python

# Fail fast on a cache miss instead of reaching for PyPI if any uv touchpoint
# re-resolves (the repo venv is plain-venv editable, but keep the guard honest).
export UV_OFFLINE=1
export PIP_NO_INDEX=1

# Make the repo's own venv the active interpreter for the verifier's focused
# tests. It already has numpy/scipy/matplotlib, the MNE editable install, the
# pinned pytest stack, and pyvista-js baked in.
export VIRTUAL_ENV=/opt/mne-venv
export PATH="/opt/mne-venv/bin:${PATH}"

# Confirm the baked closure is present offline. This is a readiness check, not
# an install — if it fails the image bake was wrong and grading must abort.
if /opt/mne-venv/bin/python - <<'PY' > /tmp/test-setup-closure.log 2>&1
import importlib
for mod in ("numpy", "scipy", "matplotlib", "mne", "pyvista_js"):
    importlib.import_module(mod)
PY
then
    echo "[offline-first] repo + pyvista-js closure satisfied from image bake"
else
    echo "[test-setup] FATAL: baked dependency closure missing offline" >&2
    tail -40 /tmp/test-setup-closure.log >&2
    exit 1
fi
