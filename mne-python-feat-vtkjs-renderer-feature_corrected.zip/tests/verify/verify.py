"""Behavioral verifier for the browser-capable 3D renderer backend.

Every test drives MNE's *pre-existing, stable* public 3D surface:
``mne.viz.set_3d_backend`` / ``mne.viz.backends.renderer._get_renderer`` and the
``_AbstractRenderer`` method contract (mesh/surface/sphere/tube/quiver3d/
instanced_mesh/text2d/contour/.../set_camera). Geometry is read from the
``(actor, mesh)`` pair those methods return and from the drawn objects behind
``figure.plotter``, which ``Figure3D`` documents as the native library's plotter.

The accessors below read that collection shape-agnostically: ``plotter.actors``
or ``plotter.renderer.actors``, as a list or a name-keyed dict, with entries that
are dicts or objects. Colors may be names or RGB values, and faces may be a VTK
cell array or plain triangle indices. All of those are defensible choices.

No implementation-internal symbol is imported or named: not the backend module
filename, not any private helper, renderer class, or scene format. In particular
no assertion pins how the backend computes glyph orientation internally:
orientation is checked only through the drawn geometry.

The camera is checked by validation story 1, where the agent can discover how the
submitted backend reads a view back. The ``_AbstractRenderer`` contract names a
camera setter but no reader, so a fixed read-back here would pin one design.

The ``jupyterlite_notebook`` backend name is the maintainer-dictated public API
(the ``set_3d_backend`` argument stated in the task); asserting on it is fair.
"""

import numpy as np
import pytest
from matplotlib.colors import to_rgb
from numpy.testing import assert_allclose

from mne.viz.backends import renderer as _renderer_mod
from mne.viz.backends.renderer import set_3d_backend

BACKEND = "jupyterlite_notebook"

# A unit square split into two triangles: a minimal mesh whose points and faces
# are trivial to check. These are harness-owned test fixtures.
_RR = np.array([[0, 0, 0], [1, 0, 0], [1, 1, 0], [0, 1, 0]], float)
_TRIS = np.array([[0, 1, 2], [0, 2, 3]])


@pytest.fixture
def lite():
    """Select the browser backend and hand back a fresh renderer.

    On unmodified code ``set_3d_backend('jupyterlite_notebook')`` raises
    ``ValueError`` (the name is unregistered), so every test that needs a
    renderer fails before the backend exists, which is the fail-to-pass gate.
    """
    saved = (_renderer_mod.MNE_3D_BACKEND, _renderer_mod.backend)
    try:
        set_3d_backend(BACKEND)
        yield _renderer_mod._get_renderer(bgcolor="white")
    finally:
        try:
            _renderer_mod.backend._close_all()
        except Exception:
            pass
        _renderer_mod.MNE_3D_BACKEND, _renderer_mod.backend = saved


def _actors(rend):
    """The drawn-object collection as a list, whichever way the plotter holds it."""
    plotter = rend.plotter
    actors = getattr(plotter, "actors", None)
    if actors is None:
        actors = plotter.renderer.actors
    if hasattr(actors, "values") and not isinstance(actors, (list, tuple)):
        return list(actors.values())
    return list(actors)


def _field(actor, name):
    """Read one field of a drawn object, held either as a dict key or an attribute."""
    return actor[name] if isinstance(actor, dict) else getattr(actor, name)


def _rgb(actor):
    """A drawn object's color as an RGB tuple, whichever way it was given."""
    color = _field(actor, "color")
    return to_rgb(color if isinstance(color, str) else tuple(map(float, color)))


def _points(actor):
    return np.asarray(_field(actor, "mesh").points)


def _triangles(mesh):
    """A mesh's triangles as index rows, from a VTK cell array or plain indices."""
    faces = np.asarray(mesh.faces).ravel()
    if faces.size % 4 == 0 and (faces[::4] == 3).all():
        faces = np.delete(faces, np.arange(0, faces.size, 4))
    return faces.reshape(-1, 3).tolist()


def _sorted_rows(points):
    points = np.asarray(points, float)
    return points[np.lexsort(np.round(points, 5).T[::-1])]


# -- 1. backend loads and draws without VTK -----------------------------------
def test_backend_loads_and_draws(lite):
    """jupyterlite_notebook selects a working renderer that draws a mesh."""
    _, mesh = lite.mesh(*_RR.T, _TRIS, color="red", opacity=0.5)
    # it actually drew something (one actor) and kept the input geometry
    assert len(_actors(lite)) == 1
    assert_allclose(np.asarray(mesh.points), _RR, atol=1e-6)
    actor = _actors(lite)[-1]
    assert _rgb(actor) == pytest.approx((1.0, 0.0, 0.0))
    assert _field(actor, "opacity") == pytest.approx(0.5)


# -- 5. the triangles come through intact -------------------------------------
def test_mesh_connectivity(lite):
    """The drawn mesh keeps its triangles; empty geometry draws nothing."""
    _, mesh = lite.mesh(*_RR.T, _TRIS, color="red")
    assert _triangles(mesh) == _TRIS.tolist()
    # an empty surface draws nothing rather than raising. The desktop backend
    # hands back (None, None) for empty spheres and glyphs, so that is fine too.
    _, empty = lite.mesh(
        np.zeros(0), np.zeros(0), np.zeros(0), np.zeros((0, 3), int), color="red"
    )
    if empty is not None:
        assert np.asarray(empty.points).size == 0
        assert np.asarray(empty.faces).size == 0


# -- 5b. surfaces, which source estimate and field map figures draw through ---
def test_surface_draws(lite):
    """surface() draws its rr/tris dict with the given color and opacity."""
    _, mesh = lite.surface(surface=dict(rr=_RR, tris=_TRIS), color="red", opacity=0.5)
    assert len(_actors(lite)) == 1
    assert_allclose(np.asarray(mesh.points), _RR, atol=1e-6)
    assert _triangles(mesh) == _TRIS.tolist()
    actor = _actors(lite)[-1]
    assert _rgb(actor) == pytest.approx((1.0, 0.0, 0.0))
    assert _field(actor, "opacity") == pytest.approx(0.5)


# -- 6. primitives draw the geometry the desktop backend would ----------------
def test_primitives_sized_like_pyvista(lite):
    """sphere scales a radius-0.5 template / uses radius as-is; tube spans & defaults white."""
    # sphere: scale sizes a radius-0.5 sphere; an explicit radius is used as-is
    for kwargs, want in ((dict(scale=0.1), 0.05), (dict(scale=1, radius=0.02), 0.02)):
        lite.sphere(np.array([[1.0, 0.0, 0.0]]), "green", **kwargs)
        pts = _points(_actors(lite)[-1]) - [1.0, 0.0, 0.0]
        assert np.linalg.norm(pts, axis=1).max() == pytest.approx(want, abs=1e-6)
    # tube: each segment spans origin->destination with the radius kept and
    # default color white (gray would vanish into plot_alignment's background).
    # The desktop backend draws one actor per segment and a merged mesh is equally
    # good, so read every object this call drew.
    before = len(_actors(lite))
    lite.tube([[0.0, 0, 0]] * 2, [[1.0, 0, 0], [0, 2.0, 0]], radius=0.01)
    drawn = _actors(lite)[before:]
    assert drawn
    pts = np.vstack([_points(actor) for actor in drawn])
    assert (pts[:, 0].max(), pts[:, 1].max()) == pytest.approx((1.0, 2.0))
    # every point sits within the radius of one of the two segment axes
    to_x_axis = np.linalg.norm(pts[:, [1, 2]], axis=1)
    to_y_axis = np.linalg.norm(pts[:, [0, 2]], axis=1)
    assert np.minimum(to_x_axis, to_y_axis).max() == pytest.approx(0.01, abs=1e-6)
    for actor in drawn:
        assert _rgb(actor) == (1.0, 1.0, 1.0)
        opacity = _field(actor, "opacity")
        assert opacity is None or opacity == pytest.approx(1.0)


# -- 7. glyphs match the desktop templates and orient onto direction ----------
@pytest.mark.parametrize(
    "mode, span, radius",
    [
        # The desktop arrow is VTK's default vtkArrowSource. Nothing in the repo
        # states its tip radius and this image has no VTK to read it from, so any
        # similar proportion passes. A cone and cylinder take glyph_radius=0.15.
        ("arrow", (0.0, 1.0), (0.05, 0.2)),
        ("cone", (0.0, 1.0), (0.15, 0.15)),
        ("cylinder", (-0.5, 0.5), (0.15, 0.15)),
        ("sphere", None, (0.5, 0.5)),
    ],
)
def test_glyph_geometry_and_orientation(lite, mode, span, radius):
    """Each glyph's size matches, and directional glyphs turn onto their direction."""
    # includes antiparallel -x, and a direction a hair off it where a rotation
    # helper that treats "nearly parallel" as parallel leaves the glyph backwards
    dirs = np.array([[1, 0, 0], [0, 1, 0], [-1, 0, 0], [-1, 1e-9, 0]], float)
    sizes = np.array([1.0, 2.0, 2.0, 2.0])
    _, mesh = lite.quiver3d(
        *np.zeros((3, 4)),
        *dirs.T,
        color="red",
        scale=2.0,
        mode=mode,
        scale_mode="scalar",
        scalars=sizes / 2,
    )
    low, high = radius
    for pts, d, size in zip(np.asarray(mesh.points).reshape(4, -1, 3), dirs, sizes):
        if mode == "sphere":
            # isotropic, so only its radius counts. Measured from the center
            # because which vertices a tessellation has is its own business.
            assert np.linalg.norm(pts, axis=1).max() == pytest.approx(
                high * size, abs=1e-5
            )
            continue
        d = d / np.linalg.norm(d)
        along = pts @ d
        across = np.linalg.norm(pts - np.outer(along, d), axis=1).max()
        assert low * size - 1e-5 <= across <= high * size + 1e-5
        # the along-axis span is the orientation signal: it must land on the
        # requested direction, including the antiparallel case a naive rotation
        # gets backwards.
        assert (along.min(), along.max()) == pytest.approx(
            np.array(span) * size, abs=1e-5
        )


# -- 8. instanced_mesh: merge per color, fold alpha, single cloud -------------
def test_instanced_mesh_merge_and_cloud(lite):
    """Instances sharing a color merge into one drawn object; alpha folds into opacity."""
    positions = np.array([[0.0, 0, 0], [1.0, 0, 0], [2.0, 0, 0]])
    colors = np.array([[1.0, 0, 0, 0.25], [0, 1.0, 0, 1.0], [1.0, 0, 0, 0.25]])
    quats = np.zeros((3, 3))  # identity, MNE's (x, y, z) convention
    _, cloud = lite.instanced_mesh(_RR, _TRIS, positions, quats, colors, opacity=0.5)
    # Two distinct colors over three instances -> two drawn objects (the two red
    # instances merged), read through the drawn-object collection rather than the
    # return value so any grouping that produces the right objects passes. Each
    # object's per-instance alpha folds into its opacity (0.25 * 0.5 = 0.125). The
    # tolerance allows for 8-bit colors, which is how the desktop backend holds them.
    got = {_rgb(a): _field(a, "opacity") for a in _actors(lite)}
    assert got == pytest.approx({(1.0, 0.0, 0.0): 0.125, (0.0, 1.0, 0.0): 0.5}, abs=0.01)
    # the point cloud handed back carries one point per instance (the anchor
    # plot_alignment writes channel names onto)
    assert_allclose(np.asarray(cloud.points), positions)


def test_instanced_mesh_applies_rotation_and_scale(lite):
    """Each instance lands rotated, scaled and placed, as the desktop glyph mapper does.

    Sensor coils draw through this path, so a backend that dropped the rotation
    would still draw a believable picture with every coil facing the wrong way.
    """
    half = np.sqrt(0.5)
    quats = np.array([[0.0, 0.0, half]])  # 90 degrees about +z, MNE's (x, y, z)
    positions = np.array([[10.0, 0.0, 0.0]])
    lite.instanced_mesh(
        _RR,
        _TRIS,
        positions,
        quats,
        np.array([[1.0, 0.0, 0.0, 1.0]]),
        scales=np.array([2.0]),
    )
    # +x turns onto +y and +y onto -x, doubled, then moved to the position
    want = np.c_[-2 * _RR[:, 1], 2 * _RR[:, 0], _RR[:, 2]] + positions
    assert_allclose(_sorted_rows(_points(_actors(lite)[-1])), _sorted_rows(want), atol=1e-5)


# -- 9. browser-impossible operations raise NotImplementedError ---------------
def test_unsupported_operations_refuse(lite):
    """The operations the task lists as out of scope each refuse cleanly.

    Each must raise a clean ``NotImplementedError`` rather than silently drawing
    something misleading; the exact wording is the backend's choice (its
    informativeness is judged in the rubric, not pinned here). Operations the
    task does *not* declare out of scope (e.g. 2D projection or text
    justification) are the solution's call and are not asserted here.
    """
    surf = dict(rr=np.zeros((3, 3)), tris=np.array([[0, 1, 2]]))
    cases = [
        lambda: lite.contour(surface=surf, scalars=np.zeros(3), contours=[0.5], kind="line"),
        lambda: lite.scalarbar(source=None, title="bar"),
        lambda: lite.legend(labels=[]),
        lambda: lite.subplot(0, 0),
    ]
    for call in cases:
        with pytest.raises(NotImplementedError):
            call()
    # the module-level screenshot entry point refuses too
    with pytest.raises(NotImplementedError):
        _renderer_mod.backend._take_3d_screenshot(lite.scene())


# -- 11. automatic selection never picks the browser backend ------------------
def test_auto_selection_excludes_browser():
    """jupyterlite is selectable only explicitly; auto-selection never reaches it."""
    saved = (_renderer_mod.MNE_3D_BACKEND, _renderer_mod.backend)
    try:
        # explicit selection works (before the fix: name unregistered -> ValueError)
        set_3d_backend(BACKEND)
        assert _renderer_mod.get_3d_backend() == BACKEND
        # but with nothing chosen, automatic fallback must NOT land on it. On this
        # image the VTK desktop backends cannot import, so a solution that left the
        # browser backend in the auto-fallback set would wrongly select it here.
        _renderer_mod.MNE_3D_BACKEND = None
        auto = _renderer_mod.get_3d_backend()  # None if nothing desktop loads
        assert auto != BACKEND
    finally:
        try:
            _renderer_mod.backend._close_all()
        except Exception:
            pass
        _renderer_mod.MNE_3D_BACKEND, _renderer_mod.backend = saved
