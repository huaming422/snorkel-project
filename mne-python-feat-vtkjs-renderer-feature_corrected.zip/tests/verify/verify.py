"""Behavioral verifier for the browser-capable 3D renderer backend.

Every test drives MNE's *pre-existing, stable* public 3D surface:
``mne.viz.set_3d_backend`` / ``mne.viz.backends.renderer._get_renderer`` and the
``_AbstractRenderer`` method contract (mesh/surface/sphere/tube/quiver3d/
instanced_mesh/text2d/contour/.../set_camera). Geometry is read from the
``(actor, mesh)`` pair those methods return and from the drawn objects behind
``figure.plotter``, which ``Figure3D`` documents as the native library's plotter.

The accessors below read that collection shape-agnostically: ``plotter.actors``
or ``plotter.renderer.actors``, as a list or a name-keyed dict, with entries that
are dicts or objects. Colors may be names or RGB values, and faces may be a VTK
cell array or plain triangle indices. All of those are defensible choices.

Nothing a solution defines is imported or named: not the backend module filename,
not any helper, renderer class, or scene format. In particular no assertion pins
how the backend computes glyph orientation internally: orientation is checked only
through the drawn geometry.

The view is read from the camera data the pinned pyvista-js hands to the page,
because ``_AbstractRenderer`` names a camera setter but no reader, and a reader the
backend defines would only report what the backend stored. Any way of setting the
library's camera or view vector ends up there.

The ``jupyterlite_notebook`` backend name is the maintainer-dictated public API
(the ``set_3d_backend`` argument stated in the task); asserting on it is fair.
"""

import numpy as np
import pytest
import pyvista_js
from matplotlib.colors import to_rgb
from numpy.testing import assert_allclose

from mne import EvokedArray, create_info
from mne.transforms import _find_vector_rotation
from mne.viz import plot_evoked_field
from mne.viz.backends import renderer as _renderer_mod
from mne.viz.backends.renderer import set_3d_backend, set_3d_view

BACKEND = "jupyterlite_notebook"

# A unit square split into two triangles: a minimal mesh whose points and faces
# are trivial to check. These are harness-owned test fixtures.
_RR = np.array([[0, 0, 0], [1, 0, 0], [1, 1, 0], [0, 1, 0]], float)
_TRIS = np.array([[0, 1, 2], [0, 2, 3]])
# A refusal message may name the operation or the backend that cannot do it.
_BACKEND_WORDS = (
    "browser",
    "jupyterlite",
    "pyvista",
    "vtk.js",
    "wasm",
    "webassembly",
    "pyodide",
)


@pytest.fixture
def lite():
    """Select the browser backend and hand back a fresh renderer."""
    saved = (_renderer_mod.MNE_3D_BACKEND, _renderer_mod.backend)
    try:
        set_3d_backend(BACKEND)
        yield _renderer_mod._get_renderer(bgcolor="white")
    finally:
        try:
            _renderer_mod.backend._close_all()
        except Exception:
            pass
        _renderer_mod.MNE_3D_BACKEND, _renderer_mod.backend = saved


def _actors(rend):
    """The drawn-object collection as a list, whichever way the plotter holds it."""
    plotter = rend.plotter
    actors = getattr(plotter, "actors", None)
    if actors is None:
        actors = plotter.renderer.actors
    if hasattr(actors, "values") and not isinstance(actors, (list, tuple)):
        return list(actors.values())
    return list(actors)


def _field(actor, name):
    """Read one field of a drawn object, held either as a dict key or an attribute."""
    return actor[name] if isinstance(actor, dict) else getattr(actor, name)


def _rgb(actor):
    """A drawn object's color as an RGB tuple, whichever way it was given."""
    color = _field(actor, "color")
    return to_rgb(color if isinstance(color, str) else tuple(map(float, color)))


def _points(actor):
    return np.asarray(_field(actor, "mesh").points)


def _triangles(mesh):
    """A mesh's triangles as index rows, from a VTK cell array or plain indices."""
    faces = np.asarray(mesh.faces).ravel()
    if faces.size % 4 == 0 and (faces[::4] == 3).all():
        faces = np.delete(faces, np.arange(0, faces.size, 4))
    return faces.reshape(-1, 3).tolist()


def _sorted_rows(points):
    points = np.asarray(points, float)
    return points[np.lexsort(np.round(points, 5).T[::-1])]


def _unit(vector):
    vector = np.asarray(vector, float)
    return vector / np.linalg.norm(vector)


def _view(rend):
    """The unit view direction the pinned pyvista-js gives the page."""
    data = rend.scene().plotter._renderer._build_camera_data()
    assert data is not None, "the library's camera was never set"
    if "viewVector" in data:
        return _unit(data["viewVector"])
    return _unit(np.subtract(data["position"], data["focalPoint"]))


def _spherical(azimuth, elevation):
    """Where the desktop backend's _set_3d_view puts the camera, as a unit vector."""
    phi, theta = np.deg2rad([azimuth, elevation])
    return np.array(
        [np.cos(phi) * np.sin(theta), np.sin(phi) * np.sin(theta), np.cos(theta)]
    )


def _assert_refuses(call, *names):
    """The call raises NotImplementedError and its message says what is refused."""
    with pytest.raises(NotImplementedError) as excinfo:
        call()
    message = str(excinfo.value).lower()
    assert any(word in message for word in names + _BACKEND_WORDS), repr(message)


# -- 1. backend loads and draws without VTK -----------------------------------
def test_backend_loads_and_draws(lite):
    """jupyterlite_notebook selects a working renderer that draws a mesh."""
    _, mesh = lite.mesh(*_RR.T, _TRIS, color="red", opacity=0.5)
    # it actually drew something (one actor) and kept the input geometry
    assert len(_actors(lite)) == 1
    assert_allclose(np.asarray(mesh.points), _RR, atol=1e-6)
    actor = _actors(lite)[-1]
    assert _rgb(actor) == pytest.approx((1.0, 0.0, 0.0))
    assert _field(actor, "opacity") == pytest.approx(0.5)


# -- 2. the figure holds the library's own plotter ----------------------------
def test_figure_plotter_is_the_library_plotter(lite):
    """Figure3D documents .plotter as the native library's plotter; a subclass is fine."""
    assert isinstance(lite.scene().plotter, pyvista_js.Plotter)


# -- 3. the view reaches the library's camera ---------------------------------
def test_view_reaches_the_library_camera(lite):
    """Both view setters point the library's camera the way the desktop backend points its own."""
    lite.set_camera(azimuth=30, elevation=60)
    assert_allclose(_view(lite), _spherical(30, 60), atol=1e-5)
    # the module-level setter moves the same figure
    set_3d_view(lite.scene(), azimuth=120, elevation=45)
    assert_allclose(_view(lite), _spherical(120, 45), atol=1e-5)
    # setting one angle keeps the other
    set_3d_view(lite.scene(), azimuth=200)
    assert_allclose(_view(lite), _spherical(200, 45), atol=1e-5)
    set_3d_view(lite.scene(), elevation=0)
    assert_allclose(_view(lite), _spherical(200, 0), atol=1e-5)


# -- 5. the triangles come through intact -------------------------------------
def test_mesh_connectivity(lite):
    """The drawn mesh keeps its triangles; empty geometry draws nothing."""
    _, mesh = lite.mesh(*_RR.T, _TRIS, color="red")
    assert _triangles(mesh) == _TRIS.tolist()
    # an empty surface draws nothing rather than raising. The desktop backend
    # hands back (None, None) for empty spheres and glyphs, so that is fine too.
    _, empty = lite.mesh(
        np.zeros(0), np.zeros(0), np.zeros(0), np.zeros((0, 3), int), color="red"
    )
    if empty is not None:
        assert np.asarray(empty.points).size == 0
        assert np.asarray(empty.faces).size == 0


# -- 5b. surfaces, which source estimate and field map figures draw through ---
def test_surface_draws(lite):
    """surface() draws its rr/tris dict with the given color and opacity."""
    _, mesh = lite.surface(surface=dict(rr=_RR, tris=_TRIS), color="red", opacity=0.5)
    assert len(_actors(lite)) == 1
    assert_allclose(np.asarray(mesh.points), _RR, atol=1e-6)
    assert _triangles(mesh) == _TRIS.tolist()
    actor = _actors(lite)[-1]
    assert _rgb(actor) == pytest.approx((1.0, 0.0, 0.0))
    assert _field(actor, "opacity") == pytest.approx(0.5)


# -- 6. primitives draw the geometry the desktop backend would ----------------
def test_primitives_sized_like_pyvista(lite):
    """sphere scales a radius-0.5 template / uses radius as-is; tube spans & defaults white."""
    # sphere: scale sizes a radius-0.5 sphere; an explicit radius is used as-is
    for kwargs, want in ((dict(scale=0.1), 0.05), (dict(scale=1, radius=0.02), 0.02)):
        lite.sphere(np.array([[1.0, 0.0, 0.0]]), "green", **kwargs)
        pts = _points(_actors(lite)[-1]) - [1.0, 0.0, 0.0]
        assert np.linalg.norm(pts, axis=1).max() == pytest.approx(want, abs=1e-6)
    # several centers each get their own sphere, drawn as one object or several
    centers = np.array([[1.0, 0, 0], [0, 3.0, 0]])
    before = len(_actors(lite))
    lite.sphere(centers, "green", scale=0.1)
    pts = np.vstack([_points(actor) for actor in _actors(lite)[before:]])
    to_centers = np.linalg.norm(pts[:, np.newaxis] - centers, axis=2)
    assert to_centers.min(axis=1).max() == pytest.approx(0.05, abs=1e-5)
    assert set(to_centers.argmin(axis=1)) == {0, 1}
    # tube: each segment spans origin->destination with the radius kept and
    # default color white (gray would vanish into plot_alignment's background).
    # The desktop backend draws one actor per segment and a merged mesh is equally
    # good, so read every object this call drew.
    origins = np.array([[1.0, 1.0, 1.0], [-2.0, 0.0, 3.0]])
    ends = np.array([[2.0, 1.0, 1.0], [-2.0, 2.0, 3.0]])
    before = len(_actors(lite))
    lite.tube(origins, ends, radius=0.01)
    drawn = _actors(lite)[before:]
    assert drawn
    pts = np.vstack([_points(actor) for actor in drawn])
    # every point sits within the radius of a segment, and each segment is fully
    # covered from its own origin to its own destination
    lengths = np.linalg.norm(ends - origins, axis=1)
    dirs = (ends - origins) / lengths[:, np.newaxis]
    along = np.sum((pts[:, np.newaxis] - origins) * dirs, axis=2)
    nearest = origins + np.clip(along, 0, lengths)[..., np.newaxis] * dirs
    distance = np.linalg.norm(pts[:, np.newaxis] - nearest, axis=2)
    assert distance.min(axis=1).max() == pytest.approx(0.01, abs=1e-5)
    owner = distance.argmin(axis=1)
    for k, length in enumerate(lengths):
        spans = along[owner == k, k]
        assert (spans.min(), spans.max()) == pytest.approx((0.0, length), abs=1e-5)
    for actor in drawn:
        assert _rgb(actor) == (1.0, 1.0, 1.0)
        opacity = _field(actor, "opacity")
        assert opacity is None or opacity == pytest.approx(1.0)


# -- 7. glyphs match the desktop templates and orient onto direction ----------
@pytest.mark.parametrize(
    "mode, span, radius",
    [
        # vtkArrowSource defaults: tip radius 0.1, tip length 0.35, shaft radius 0.03.
        # A cone and cylinder take glyph_radius=0.15.
        ("arrow", (0.0, 1.0), 0.1),
        ("cone", (0.0, 1.0), 0.15),
        ("cylinder", (-0.5, 0.5), 0.15),
        ("sphere", None, 0.5),
    ],
)
def test_glyph_geometry_and_orientation(lite, mode, span, radius):
    """Each glyph lands on its own anchor at its size, turned onto its direction."""
    # includes antiparallel -x and a direction a hair off it
    dirs = np.array([[1, 0, 0], [0, 1, 0], [-1, 0, 0], [-1, 1e-9, 0]], float)
    sizes = np.array([1.0, 2.0, 2.0, 2.0])
    anchors = np.array([[1.0, 0, 0], [0, 2.0, 0], [0, 0, 3.0], [-1.0, -1.0, -1.0]])
    _, mesh = lite.quiver3d(
        *anchors.T,
        *dirs.T,
        color="red",
        scale=2.0,
        mode=mode,
        scale_mode="scalar",
        scalars=sizes / 2,
    )
    glyphs = np.asarray(mesh.points).reshape(4, -1, 3)
    for pts, anchor, d, size in zip(glyphs, anchors, dirs, sizes):
        pts = pts - anchor
        if mode == "sphere":
            # isotropic, so only its radius counts. Measured from the center
            # because which vertices a tessellation has is its own business.
            assert np.linalg.norm(pts, axis=1).max() == pytest.approx(
                radius * size, abs=1e-5
            )
            continue
        d = d / np.linalg.norm(d)
        along = pts @ d
        across = np.linalg.norm(pts - np.outer(along, d), axis=1)
        assert across.max() == pytest.approx(radius * size, abs=1e-5)
        # the along-axis span must land on the requested direction, including the
        # antiparallel case, where a glyph left unturned spans the wrong side
        assert (along.min(), along.max()) == pytest.approx(
            np.array(span) * size, abs=1e-5
        )
        if mode == "arrow":
            shaft = across[along < 0.65 * size - 1e-4]
            assert shaft.max() == pytest.approx(0.03 * size, abs=1e-5)
            tip = along[across > 0.03 * size + 1e-4]
            assert tip.min() == pytest.approx(0.65 * size, abs=1e-5)


# -- 8. instanced_mesh: merge per color, fold alpha, single cloud -------------
def test_instanced_mesh_merge_and_cloud(lite):
    """Instances sharing a color merge into one drawn object; alpha folds into opacity."""
    positions = np.array([[0.0, 0, 0], [1.0, 0, 0], [2.0, 0, 0]])
    colors = np.array([[1.0, 0, 0, 0.25], [0, 1.0, 0, 1.0], [1.0, 0, 0, 0.25]])
    quats = np.zeros((3, 3))  # identity, MNE's (x, y, z) convention
    _, cloud = lite.instanced_mesh(_RR, _TRIS, positions, quats, colors, opacity=0.5)
    # Two distinct colors over three instances -> two drawn objects (the two red
    # instances merged), read through the drawn-object collection rather than the
    # return value so any grouping that produces the right objects passes. Each
    # object's per-instance alpha folds into its opacity (0.25 * 0.5 = 0.125). The
    # tolerance allows for 8-bit colors, which is how the desktop backend holds them.
    got = {_rgb(a): _field(a, "opacity") for a in _actors(lite)}
    assert got == pytest.approx({(1.0, 0.0, 0.0): 0.125, (0.0, 1.0, 0.0): 0.5}, abs=0.01)
    # the point cloud handed back carries one point per instance (the anchor
    # plot_alignment writes channel names onto)
    assert_allclose(np.asarray(cloud.points), positions)


def test_instanced_mesh_applies_rotation_and_scale(lite):
    """Every instance lands rotated, scaled and placed, as the desktop glyph mapper does.

    Sensor coils draw through this path, so a backend that dropped the rotation, or
    drew each merged object from its first instance, would still draw a believable
    picture with coils facing the wrong way or missing.
    """
    half = np.sqrt(0.5)
    # identity, 90 degrees about +z and 90 degrees about +x, MNE's (x, y, z)
    quats = np.array([[0.0, 0.0, 0.0], [0.0, 0.0, half], [half, 0.0, 0.0]])
    positions = np.array([[10.0, 0.0, 0.0], [0.0, 10.0, 0.0], [0.0, 0.0, 10.0]])
    red, green = (1.0, 0.0, 0.0), (0.0, 1.0, 0.0)
    lite.instanced_mesh(
        _RR,
        _TRIS,
        positions,
        quats,
        np.array([[*red, 1.0], [*green, 1.0], [*red, 1.0]]),
        scales=np.array([1.0, 2.0, 3.0]),
    )
    x, y, z = _RR.T
    want = {
        red: np.vstack([_RR + positions[0], 3 * np.c_[x, -z, y] + positions[2]]),
        green: 2 * np.c_[-y, x, z] + positions[1],
    }
    got = {_rgb(actor): _points(actor) for actor in _actors(lite)}
    assert set(got) == set(want)
    for color, points in want.items():
        assert got[color].shape == points.shape
        assert_allclose(_sorted_rows(got[color]), _sorted_rows(points), atol=1e-5)


# -- 9. browser-impossible operations raise NotImplementedError ---------------
def test_unsupported_operations_refuse(lite):
    """The operations the task lists as out of scope each refuse with a clear message.

    Each must raise ``NotImplementedError`` rather than silently drawing something
    misleading, and the message must name the operation or the backend. Operations
    the task does *not* declare out of scope (e.g. 2D projection or text
    justification) are the solution's call and are not asserted here.
    """
    surf = dict(rr=np.zeros((3, 3)), tris=np.array([[0, 1, 2]]))
    _assert_refuses(
        lambda: lite.contour(surface=surf, scalars=np.zeros(3), contours=[0.5], kind="line"),
        "contour",
    )
    _assert_refuses(
        lambda: lite.scalarbar(source=None, title="bar"),
        "scalar bar",
        "scalarbar",
        "colorbar",
    )
    _assert_refuses(lambda: lite.legend(labels=[]), "legend")
    _assert_refuses(lambda: lite.subplot(0, 0), "subplot")
    # the module-level screenshot entry point refuses too
    _assert_refuses(
        lambda: _renderer_mod.backend._take_3d_screenshot(lite.scene()), "screenshot"
    )


def test_time_viewer_refuses():
    """The public field map plot refuses when asked for its time viewer."""
    saved = (_renderer_mod.MNE_3D_BACKEND, _renderer_mod.backend)
    info = create_info(["MEG001", "MEG002"], 1000.0, "mag")
    evoked = EvokedArray(np.array([[1e-12, 2e-12], [2e-12, 1e-12]]), info)
    surf_map = dict(
        kind="meg",
        ch_names=info.ch_names,
        data=np.ones((len(_RR), 2)),
        surf=dict(rr=_RR, tris=_TRIS, nn=np.tile([0.0, 0.0, 1.0], (len(_RR), 1))),
    )
    try:
        set_3d_backend(BACKEND)
        # one contour or fewer draws no contours, so the refusal is the time viewer's
        _assert_refuses(
            lambda: plot_evoked_field(
                evoked, [surf_map], time=0.0, n_contours=0, time_viewer=True
            ),
            "time",
        )
    finally:
        try:
            _renderer_mod.backend._close_all()
        except Exception:
            pass
        _renderer_mod.MNE_3D_BACKEND, _renderer_mod.backend = saved


# -- 10. shared numpy rotation code keeps working for its other callers --------
def test_rotation_helper_maps_one_vector_onto_another():
    """The existing helper still turns one unit vector onto another with a proper rotation."""
    x, y, z = np.eye(3)
    pairs = [(x, y), (x, z), (y, z), (x, np.array([0.6, 0.8, 0.0])), (x, x)]
    for a, b in pairs:
        rot = _find_vector_rotation(a, b)
        assert rot.shape == (3, 3)
        assert_allclose(rot @ a, b, atol=1e-12)
        assert_allclose(rot.T @ rot, np.eye(3), atol=1e-12)
        assert np.linalg.det(rot) == pytest.approx(1.0)


# -- 11. automatic selection never picks the browser backend ------------------
def test_auto_selection_excludes_browser():
    """jupyterlite is selectable only explicitly; auto-selection never reaches it."""
    saved = (_renderer_mod.MNE_3D_BACKEND, _renderer_mod.backend)
    try:
        # explicit selection works
        set_3d_backend(BACKEND)
        assert _renderer_mod.get_3d_backend() == BACKEND
        # but with nothing chosen, automatic selection must not land on it, even
        # here where the VTK desktop backends cannot import
        _renderer_mod.MNE_3D_BACKEND = None
        auto = _renderer_mod.get_3d_backend()
        assert auto != BACKEND
    finally:
        try:
            _renderer_mod.backend._close_all()
        except Exception:
            pass
        _renderer_mod.MNE_3D_BACKEND, _renderer_mod.backend = saved
