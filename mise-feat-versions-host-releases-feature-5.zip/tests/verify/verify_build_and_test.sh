#!/usr/bin/env bash
#
# Build and regression check.
#
# Confirms the change compiles and the project's own
# version-resolution / HTTP unit tests still pass. This is a stable,
# implementation-agnostic interface: it drives `cargo` the same way the
# project's CI does, naming no new symbol and asserting nothing
# about which files changed. It acts as a build check and as a regression guard
# against edits that break the surrounding modules.
#
# The runner's cwd is {repo_dir} (/repo/mise). The image pre-builds the full
# workspace at the base commit and warms the cargo registry, so a warm
# incremental build + the targeted unit tests finish well inside the timeout.
#
# Exit codes:
#   0 - binary builds and the mise crate's unit tests pass
#   non-zero - propagates the cargo failure

set -euo pipefail

# Toolchain onto PATH (each verifier phase gets a fresh shell); paths match
# the image Dockerfile's ENV block.
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export PATH="$CARGO_HOME/bin:$PATH"

# Run from the repo root (the runner already sets cwd to {repo_dir}, but be
# explicit so the script is robust if invoked directly).
cd /repo/mise

echo "verify: building mise binary (cargo build --locked --bin mise)"
cargo build --locked --bin mise

echo "verify: running the targeted unit-test subset"
# mise is a binary-only crate (no library target), so its in-tree unit tests
# (#[cfg(test)] modules) live in the binary target and are selected with
# --bins plus a name filter.
#
# The filter below selects a stable, pre-existing pure-logic module that runs
# deterministically with no HOME, filesystem, network, or process-global
# state. This check is a build-and-regression guard, not the primary signal
# for this feature: the whole-binary `cargo build` above already compiles
# every file the change could touch, so any compilation break anywhere is
# caught regardless of this filter.
#
# Running the crate's FULL unit-test set here is NOT hermetic - many unrelated
# modules (config-file loading, task-script parsing, age decryption) assume a
# real HOME/keyring/filesystem and panic under the sandbox, and some modules
# depend on a process-global install-path cache and so flake under parallel
# execution. Neither failure mode is a behavioural regression from this
# change. The feature's own end-to-end behaviour (host preference, fallback,
# untrusted-response handling, the exact-version fast path) is exercised
# separately by the behaviour stories driving the real binary; this check
# only has to confirm the change compiles and a stable slice of existing unit
# tests still holds.
cargo test --locked -p mise --bins -- versions_host::
