#!/usr/bin/env python3
"""Local HTTP mock for the release-metadata behaviour stories.

Adapted from the repo's own ``e2e/helpers/scripts/http_test_server.py`` (same
request-logging idea), this server stands in for the two external hosts the
CLI talks to during a public-repo release resolve/install:

  * the shared versions host (``mise-versions.jdx.dev``)
  * the public GitHub REST API (``api.github.com``)
  * a non-public / Enterprise GitHub API base (a custom host)
  * the GitHub release-download host (``github.com``) — most stories use
    ``latest`` / ``--dry-run``, which never reach it; a real (non-dry-run)
    install does reach it, and gets a 404, since no real archive bytes are
    served here. That is enough to prove resolution ran all the way through
    to asset selection; it is not enough to finish an install.

Routing is deliberately **host-level**, keyed on a sentinel path prefix that
the ``url_replacements`` setting injects when it rewrites each outbound host to
this server:

    https://mise-versions.jdx.dev/<anything>   ->  http://127.0.0.1:PORT/vh/<anything>
    https://api.github.com/<anything>          ->  http://127.0.0.1:PORT/api/<anything>
    https://<custom-ghe-host>/<anything>       ->  http://127.0.0.1:PORT/ghe/<anything>
    https://github.com/<anything>              ->  http://127.0.0.1:PORT/dl/<anything>

Because a versions-host request is recognised purely by the ``/vh`` prefix,
the server is agnostic to whatever sub-path a solution chooses for that
endpoint — any path under ``/vh`` counts as "the versions host was contacted".
The API routes (``/releases/latest``, ``/releases/tags/<tag>``, ``/releases``)
are GitHub's own REST shape, which every solution must conform to.

Every received request is appended to an ordered JSON log so a story can assert
*which* host was contacted and in *what order*.

Usage:
    mock_release_server.py <scenario_json_path> <log_dir> [port]

The scenario JSON is produced by test_harness.py; its schema lives there.
The chosen port is written to the file named by MISE_HTTP_TEST_PORT_FILE (or
printed on stdout as ``PORT <n>``) so the harness can discover it.
"""

from __future__ import annotations

import http.server
import json
import os
import socketserver
import sys
import threading
from pathlib import Path

CREATED_AT = "2026-01-01T00:00:00Z"


def _asset(owner: str, repo: str, tag: str, variant: str,
           name: str = "widget-1.0.0.tar.gz") -> dict:
    """Build one release asset. ``variant`` controls whether the mirrored URLs
    are trustworthy (belong to owner/repo/tag) or tampered.

    Tamper variants each corrupt exactly one coordinate so a story can prove the
    corresponding check in isolation:
      * ``bad_host``          -- download URL is on a different host
      * ``bad_owner``         -- download + API URL carry a different owner
      * ``bad_repo``          -- same owner but a different repo name
      * ``wrong_download_tag``-- release tag matches, but the download URL's
                                 ``/download/<tag>/`` segment is a different tag
      * ``bad_api_url``       -- only the asset API `url` carries a different
                                 owner; the download URL is untouched and
                                 valid, so a check that only looks at the
                                 download URL would accept this asset
    """
    dl_host = "github.com"
    dl_owner, dl_repo, dl_tag = owner, repo, tag
    api_owner, api_repo = owner, repo
    if variant == "bad_host":
        dl_host = "evil.example.com"
    elif variant == "bad_owner":
        dl_owner = api_owner = "someone-else"
    elif variant == "bad_repo":
        dl_repo = api_repo = "other-widget"
    elif variant == "wrong_download_tag":
        dl_tag = "v0.0.1"
    elif variant == "bad_api_url":
        api_owner = "someone-else"
    bdu = f"https://{dl_host}/{dl_owner}/{dl_repo}/releases/download/{dl_tag}/{name}"
    api = f"https://api.github.com/repos/{api_owner}/{api_repo}/releases/assets/1"
    return {
        "name": name,
        "browser_download_url": bdu,
        "url": api,
        "digest": None,
    }


def make_release(owner: str, repo: str, tag: str, asset_variant: str = "valid",
                 empty_assets: bool = False) -> dict:
    """Construct a GitHub release object (the repo's own release/asset schema)."""
    if empty_assets:
        assets = []
    elif asset_variant == "multi_asset_one_bad":
        # A release carrying several assets where only a LATER one is tampered.
        # The first asset is trustworthy, so a check that validates only the
        # first asset (or short-circuits on the first success) accepts this
        # release; whole-list validation that fails closed rejects it.
        assets = [
            _asset(owner, repo, tag, "valid", name="widget-1.0.0-linux.tar.gz"),
            _asset(owner, repo, tag, "bad_owner", name="widget-1.0.0-darwin.tar.gz"),
        ]
    else:
        assets = [_asset(owner, repo, tag, asset_variant)]
    return {
        "tag_name": tag,
        "draft": False,
        "prerelease": False,
        "created_at": CREATED_AT,
        "assets": assets,
    }


class Handler(http.server.SimpleHTTPRequestHandler):
    scenario: dict = {}
    log_dir: Path = Path("/tmp")
    _lock = threading.Lock()
    _counter = 0

    # -- logging -----------------------------------------------------------
    def _log_request_record(self) -> None:
        with Handler._lock:
            Handler._counter += 1
            n = Handler._counter
        rec = {"n": n, "path": self.path, "method": self.command}
        (self.log_dir / f"request_{n:04d}.json").write_text(json.dumps(rec))

    def log_message(self, fmt, *args):  # silence default stderr spam
        pass

    # -- responses ---------------------------------------------------------
    def _send_json(self, code: int, payload) -> None:
        body = json.dumps(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _send_status(self, code: int) -> None:
        self.send_response(code)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_HEAD(self):
        self._log_request_record()
        self._route(head=True)

    def do_GET(self):
        self._log_request_record()
        self._route(head=False)

    # -- routing -----------------------------------------------------------
    def _route(self, head: bool) -> None:
        path = self.path.split("?", 1)[0]
        sc = Handler.scenario
        owner = sc.get("owner", "acme")
        repo = sc.get("repo", "widget")

        if path.startswith("/vh"):
            return self._serve_versions_host(sc.get("vh", {}), owner, repo, path)
        if path.startswith("/api"):
            return self._serve_github_api(sc.get("api", {}), owner, repo, path, "/api")
        if path.startswith("/ghe"):
            return self._serve_github_api(sc.get("ghe", {}), owner, repo, path, "/ghe")
        if path.startswith("/dl"):
            # Download host safety net; stories never actually download.
            return self._send_status(404)
        self._send_status(404)

    def _requested_tag(self, path: str) -> str:
        # ".../releases/tags/<tag>" -> <tag> (last path segment)
        return path.rstrip("/").rsplit("/", 1)[-1]

    def _effective_tag(self, vh: dict, path: str) -> str:
        """The concrete tag_name the mirror should report. A request for the
        ``latest`` release resolves to a concrete version (GitHub's
        /releases/latest returns the real tag, never the literal 'latest')."""
        requested = self._requested_tag(path)
        if requested == "latest":
            return vh.get("latest_tag", "v2.0.0")
        return requested

    def _serve_versions_host(self, vh: dict, owner: str, repo: str, path: str) -> None:
        # The pre-existing TOML version-LIST endpoint (``/tools/<tool>.toml``)
        # is a different concern from the new release-metadata endpoint. An
        # unmodified baseline already hits it during a full-list resolve, so it
        # must NOT be driven by the release-metadata ``mode`` — serve a plain
        # 404 so list resolution falls through to the public GitHub API exactly
        # as it does in production when the host has no cached list.
        base = path.split("?", 1)[0]
        if base.endswith(".toml") or "/tools/" in base:
            return self._send_status(404)
        mode = vh.get("mode", "notfound")
        if mode == "notfound":
            return self._send_status(404)
        if mode == "ratelimit":
            return self._send_status(429)
        if mode == "error":
            return self._send_status(500)
        if mode == "malformed":
            # A 200 whose body isn't a release object at all (missing every
            # required field): must be treated like any other failed lookup
            # (quiet fallback), not let a parse error through to the user.
            return self._send_json(200, {"unexpected": "shape", "no_release_fields": True})
        tag = self._effective_tag(vh, path)
        if mode == "valid":
            return self._send_json(200, make_release(owner, repo, tag, "valid"))
        if mode == "empty_assets":
            return self._send_json(200, make_release(owner, repo, tag, empty_assets=True))
        if mode in ("bad_host", "bad_owner", "bad_repo", "wrong_download_tag",
                    "bad_api_url", "multi_asset_one_bad"):
            return self._send_json(200, make_release(owner, repo, tag, mode))
        if mode == "tag_mismatch":
            wrong = vh.get("wrong_tag", "v9.9.9")
            # Assets are internally consistent with the (wrong) tag, so only the
            # tag check — not the asset-URL check — is what rejects this.
            return self._send_json(200, make_release(owner, repo, wrong, "valid"))
        return self._send_status(404)

    def _serve_github_api(self, api: dict, owner: str, repo: str, path: str,
                          prefix: str) -> None:
        if path.endswith("/releases/latest"):
            mode = api.get("latest", "valid")
            if mode == "valid":
                tag = api.get("latest_tag", "v1.2.3")
                return self._send_json(200, make_release(owner, repo, tag, "valid"))
            return self._send_status(404)
        if "/releases/tags/" in path:
            mode = api.get("tags", "echo")
            if mode == "echo":
                tag = self._requested_tag(path)
                return self._send_json(200, make_release(owner, repo, tag, "valid"))
            return self._send_status(404)
        if path.endswith("/releases"):
            mode = api.get("list", "notfound")
            if mode == "list":
                tags = api.get("list_tags", [])
                releases = [make_release(owner, repo, t, "valid") for t in tags]
                return self._send_json(200, releases)
            return self._send_json(200, [])
        self._send_status(404)


def main() -> None:
    scenario_path = sys.argv[1]
    log_dir = Path(sys.argv[2])
    port = int(sys.argv[3]) if len(sys.argv) > 3 else 0

    log_dir.mkdir(parents=True, exist_ok=True)
    Handler.scenario = json.loads(Path(scenario_path).read_text())
    Handler.log_dir = log_dir

    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("127.0.0.1", port), Handler) as httpd:
        actual = httpd.server_address[1]
        port_file = os.environ.get("MISE_HTTP_TEST_PORT_FILE")
        if port_file:
            p = Path(port_file)
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(str(actual))
        print(f"PORT {actual}", flush=True)
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
