"""Shared plumbing for the release-metadata validation stories.

The feature is observable only by running the prebuilt ``mise`` binary against a
local mock that stands in for the versions host, the public GitHub API, a
custom/Enterprise GitHub API base, and the GitHub download host (see
``mock_release_server.py``). Every story:

  1. builds a *scenario* describing what each mocked host should return,
  2. runs one ``mise`` command in a throwaway isolated HOME with the
     ``url_replacements`` setting pointed at the mock,
  3. inspects the result — exit code, stdout, stderr, and the mock's ordered
     request log — to decide which host was contacted, in what order, and
     whether the operation succeeded.

Nothing here pins a solution-chosen shape: the mock recognises a versions-host
request purely by host (an injected ``/vh`` path prefix), so whatever sub-path a
solution picks for the versions-host release endpoint is accepted. The GitHub
REST routes (``/releases/latest``, ``/releases/tags/<tag>``, ``/releases``) are
GitHub's own API shape, which every solution must conform to.

Stories import the high-level helpers (``resolve_latest``, ``install_pin``) and
the request-classification predicates; they assert the behaviour the procedures
describe.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import tempfile
import time
from pathlib import Path

# --- fixed image / repo layout (stable-fact: image Dockerfile ENV) ----------
_CARGO_TARGET = os.environ.get("CARGO_TARGET_DIR", "/opt/cache/cargo-target")
MISE_BIN = os.path.join(_CARGO_TARGET, "debug", "mise")
HERE = os.path.dirname(os.path.abspath(__file__))
MOCK_SERVER = os.path.join(HERE, "mock_release_server.py")

# Neutral public-repo fixture coordinates (harness-owned test fixture).
OWNER = "acme"
REPO = "widget"
TOOL = f"github:{OWNER}/{REPO}"

# A non-public (Enterprise/custom) GitHub API base, used by the public-base-only
# story. Its host is redirected to the mock's ``/ghe`` route.
GHE_API_URL = "https://ghe.acme.example/api/v3"
GHE_HOST = "https://ghe.acme.example"

# Host bases mise targets, redirected to the single local mock. Order matters
# only in that apply_url_replacements applies the first matching prefix; none of
# these is a prefix of another.
_VERSIONS_HOST = "https://mise-versions.jdx.dev"
_API_HOST = "https://api.github.com"
_DL_HOST = "https://github.com"


def _python() -> str:
    return os.environ.get("VERIFIER_PYTHON") or "python3"


def _start_mock(scenario: dict, log_dir: Path):
    """Launch the mock server; return (proc, port)."""
    scen_path = log_dir / "scenario.json"
    scen_path.write_text(json.dumps(scenario))
    env = {**os.environ, "MISE_HTTP_TEST_PORT_FILE": str(log_dir / "port")}
    proc = subprocess.Popen(
        [_python(), MOCK_SERVER, str(scen_path), str(log_dir)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        env=env,
    )
    # The server prints "PORT <n>" only after it has bound the socket.
    line = proc.stdout.readline().strip()
    if not line.startswith("PORT "):
        err = proc.stderr.read()
        raise RuntimeError(f"mock server failed to start: {line!r} {err!r}")
    return proc, int(line.split()[1])


def _url_replacements(port: int) -> str:
    base = f"http://127.0.0.1:{port}"
    return json.dumps({
        _VERSIONS_HOST: f"{base}/vh",
        _API_HOST: f"{base}/api",
        GHE_HOST: f"{base}/ghe",
        _DL_HOST: f"{base}/dl",
    })


def _isolated_env(home: Path, port: int, extra: dict | None) -> dict:
    """A clean environment mirroring the repo's e2e isolation (fresh HOME and
    mise dirs, versions host on, no retry backoff, telemetry off)."""
    env = {
        "HOME": str(home),
        "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
        "LANG": "C.UTF-8",
        "MISE_DATA_DIR": str(home / ".local/share/mise"),
        "MISE_CACHE_DIR": str(home / ".cache/mise"),
        "MISE_CONFIG_DIR": str(home / ".config/mise"),
        "MISE_STATE_DIR": str(home / ".local/state/mise"),
        "MISE_SYSTEM_DIR": str(home / "etc/mise"),
        "MISE_TMP_DIR": str(home / "tmp"),
        "MISE_YES": "1",
        "MISE_EXPERIMENTAL": "1",
        "MISE_USE_VERSIONS_HOST_TRACK": "0",
        "MISE_HTTP_RETRIES": "0",  # no backoff when a host returns 429/5xx
        "MISE_URL_REPLACEMENTS": _url_replacements(port),
        "MISE_HTTP_TEST_PORT_FILE": str(home / "tmp/http_port"),
    }
    # Toolchain vars so the pre-built binary's children (if any) resolve.
    for k in ("RUSTUP_HOME", "CARGO_HOME", "CARGO_TARGET_DIR"):
        if k in os.environ:
            env[k] = os.environ[k]
    for d in ("MISE_DATA_DIR", "MISE_CACHE_DIR", "MISE_CONFIG_DIR",
              "MISE_STATE_DIR", "MISE_SYSTEM_DIR", "MISE_TMP_DIR"):
        Path(env[d]).mkdir(parents=True, exist_ok=True)
    if extra:
        env.update(extra)
    return env


def read_requests(log_dir: Path) -> list[str]:
    """Return the mock's received request paths in the order they arrived."""
    recs = []
    for f in log_dir.glob("request_*.json"):
        try:
            recs.append(json.loads(f.read_text()))
        except (OSError, json.JSONDecodeError):
            continue
    recs.sort(key=lambda r: r.get("n", 0))
    return [r.get("path", "") for r in recs]


# --- request classification (host-level, path-shape for the GitHub API) -----
# A versions-host request is recognised purely by the injected "/vh" host
# prefix. Two *kinds* of versions-host request exist and must not be confused:
#   * the pre-existing TOML version-LIST endpoint (``/tools/<tool>.toml``) that
#     list_remote_versions already uses today — both a correct solution AND an
#     unmodified baseline hit this during a full-list resolve, so it is NOT
#     evidence of the new feature; and
#   * the new release-metadata request (any other "/vh" path) — contacting this
#     at all is the feature. Its sub-path is solution-chosen, so we match it by
#     host and simply exclude the one pre-existing TOML list path.
def _is_vh(p: str) -> bool:
    return p.startswith("/vh")


def _is_vh_toml(p: str) -> bool:
    base = p.split("?", 1)[0]
    return p.startswith("/vh") and (base.endswith(".toml") or "/tools/" in base)


def _is_vh_release(p: str) -> bool:
    return _is_vh(p) and not _is_vh_toml(p)


def _is_api_latest(p: str) -> bool:
    return p.startswith("/api") and p.split("?", 1)[0].endswith("/releases/latest")


def _is_api_tag_lookup(p: str) -> bool:
    return p.startswith("/api") and "/releases/tags/" in p


def _is_api_list(p: str) -> bool:
    return p.startswith("/api") and p.split("?", 1)[0].endswith("/releases")


def _is_ghe(p: str) -> bool:
    return p.startswith("/ghe")


def _is_download_attempt(p: str) -> bool:
    """True for a request against the asset-download surface: the browser
    download host, or the GitHub API asset endpoint. Reaching either one means
    resolution finished and mise moved on to picking/fetching an asset - the
    part of a real install a `--dry-run` or `latest` lookup never reaches."""
    base = p.split("?", 1)[0]
    return base.startswith("/dl") or (base.startswith("/api") and "/releases/assets/" in base)


class Result:
    """Outcome of one mise invocation against the mock."""

    def __init__(self, proc: subprocess.CompletedProcess, requests: list[str]):
        self.returncode = proc.returncode
        self.stdout = proc.stdout or ""
        self.stderr = proc.stderr or ""
        self.requests = requests

    # host-contact facts (concrete, order-aware)
    @property
    def vh_contacted(self) -> bool:
        """True iff the versions host was contacted for release metadata (the
        pre-existing TOML version-list endpoint does not count)."""
        return any(_is_vh_release(p) for p in self.requests)

    @property
    def api_latest_contacted(self) -> bool:
        return any(_is_api_latest(p) for p in self.requests)

    @property
    def api_tag_lookup_contacted(self) -> bool:
        return any(_is_api_tag_lookup(p) for p in self.requests)

    @property
    def api_list_contacted(self) -> bool:
        return any(_is_api_list(p) for p in self.requests)

    @property
    def ghe_contacted(self) -> bool:
        return any(_is_ghe(p) for p in self.requests)

    @property
    def download_attempted(self) -> bool:
        """True iff mise got far enough to attempt fetching an asset (the
        browser download host or the API asset endpoint), not just release
        metadata. A real (non-dry-run) install reaches this; `mise latest`
        and `install --dry-run` never do."""
        return any(_is_download_attempt(p) for p in self.requests)

    @property
    def resolved_install_version(self) -> str | None:
        """The concrete version an install resolved to, read from the
        progress line mise prints on stderr for every install
        (``<tool>@<version> ... would install`` / ``... already
        installed``), not from the literal pin that was requested. None if
        no such line is present (e.g. the process errored before resolving)."""
        for line in self.stderr.splitlines():
            if "would install" in line or "already installed" in line:
                m = re.search(r"@([^\s]+)", line)
                if m:
                    return m.group(1)
        return None

    @property
    def first_release_host(self) -> str:
        """Bucket of the first release-metadata request: 'vh', 'api', 'ghe', or ''.
        The pre-existing TOML version-list request is ignored — it is not a
        release-metadata lookup."""
        for p in self.requests:
            if _is_vh_toml(p):
                continue
            if _is_vh_release(p):
                return "vh"
            if _is_ghe(p):
                return "ghe"
            if _is_api_latest(p) or _is_api_tag_lookup(p) or _is_api_list(p):
                return "api"
        return ""

    @property
    def stderr_has_warning(self) -> bool:
        low = self.stderr
        return ("WARN" in low) or ("ERROR" in low) or ("Error:" in low)


def _run(args: list[str], scenario: dict, env_overrides: dict | None,
         mise_toml: str | None, timeout: int = 120) -> Result:
    with tempfile.TemporaryDirectory(prefix="mise_vh_") as td:
        log_dir = Path(td) / "log"
        log_dir.mkdir(parents=True, exist_ok=True)
        home = Path(td) / "home"
        workdir = home / "workdir"
        workdir.mkdir(parents=True, exist_ok=True)

        proc_srv, port = _start_mock(scenario, log_dir)
        try:
            env = _isolated_env(home, port, env_overrides)
            if mise_toml is not None:
                (workdir / "mise.toml").write_text(mise_toml)
            cp = subprocess.run(
                [MISE_BIN, *args],
                cwd=str(workdir),
                env=env,
                capture_output=True,
                text=True,
                timeout=timeout,
                check=False,
            )
        finally:
            proc_srv.terminate()
            try:
                proc_srv.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc_srv.kill()
        # Give the OS a beat to flush the last request file on slow sandboxes.
        time.sleep(0.05)
        return Result(cp, read_requests(log_dir))


# --- high-level story helpers ----------------------------------------------
def resolve_latest(*, vh: dict | None = None, api_latest: str = "valid",
                   api_latest_tag: str = "v1.2.3", ghe_latest_tag: str | None = None,
                   use_api_url: str | None = None, use_versions_host: bool = True,
                   prefer_offline: bool = False) -> Result:
    """Run ``mise latest github:acme/widget`` (optionally with a custom api_url).

    ``vh`` is the versions-host behaviour dict, e.g. ``{"mode": "valid"}``,
    ``{"mode": "notfound"}``, ``{"mode": "bad_host"}``, ``{"mode": "empty_assets"}``.
    Omit it (None) to leave the versions host returning 404.
    """
    scenario = {
        "owner": OWNER, "repo": REPO,
        "vh": vh or {"mode": "notfound"},
        "api": {"latest": api_latest, "latest_tag": api_latest_tag},
        "ghe": {"latest": "valid", "latest_tag": ghe_latest_tag or "v1.2.3"},
    }
    env: dict = {}
    if not use_versions_host:
        env["MISE_USE_VERSIONS_HOST"] = "0"
    else:
        env["MISE_USE_VERSIONS_HOST"] = "1"
    if prefer_offline:
        env["MISE_PREFER_OFFLINE"] = "1"

    tool = TOOL
    if use_api_url:
        tool = f"{TOOL}[api_url={use_api_url}]"
    return _run(["latest", tool], scenario, env, None)


def install_pin(pin: str, *, vh: dict | None = None,
                api_tags: str = "echo", api_list_tags: list[str] | None = None,
                use_versions_host: bool = True, use_api_url: str | None = None) -> Result:
    """Run ``mise install --dry-run github:acme/widget@<pin>`` against the mock.

    ``api_tags`` is ``"echo"`` (the API serves any requested tag) or
    ``"notfound"`` (every by-tag lookup 404s). ``api_list_tags`` seeds the
    ``/releases`` list endpoint for the fall-through path. ``use_api_url``
    installs against a custom/Enterprise API base (pass ``GHE_API_URL``)
    instead of the public one, same as ``resolve_latest``'s keyword of the
    same name.
    """
    scenario = {
        "owner": OWNER, "repo": REPO,
        "vh": vh or {"mode": "notfound"},
        "api": {
            "tags": api_tags,
            "list": "list" if api_list_tags is not None else "empty",
            "list_tags": api_list_tags or [],
        },
        "ghe": {"tags": api_tags, "list": "list" if api_list_tags is not None else "empty",
                "list_tags": api_list_tags or []},
    }
    env = {"MISE_USE_VERSIONS_HOST": "1" if use_versions_host else "0"}
    tool = TOOL
    if use_api_url:
        tool = f"{TOOL}[api_url={use_api_url}]"
    return _run(["install", "--dry-run", f"{tool}@{pin}"], scenario, env, None)


def install_real(tag_or_pin: str | None, *, vh: dict | None = None,
                 api_latest_tag: str = "v1.2.3", api_tags: str = "echo") -> Result:
    """Run a REAL (non-dry-run) ``mise install`` of the fixture tool against
    the mock: ``mise install github:acme/widget`` when ``tag_or_pin`` is
    None (resolves "latest" the way an install normally does), or
    ``mise install github:acme/widget@<tag_or_pin>`` for a pin.

    Unlike ``install_pin``, this is NOT ``--dry-run``: resolution runs the
    same way, but mise then moves on to asset selection and an actual
    download attempt against the mock's download surface (``/dl`` and the
    API asset endpoint), which a dry run returns before reaching. The mock
    serves no real archive bytes, so the install itself still fails (a
    404 on the download); this helper is for observing which host was
    consulted for release metadata and whether resolution got far enough to
    attempt a download, not for a successful install. Timeout is longer
    than the other helpers' to allow for the extra HEAD/GET round trip.
    """
    scenario = {
        "owner": OWNER, "repo": REPO,
        "vh": vh or {"mode": "notfound"},
        "api": {
            "latest": "valid", "latest_tag": api_latest_tag,
            "tags": api_tags, "list": "empty", "list_tags": [],
        },
    }
    env = {"MISE_USE_VERSIONS_HOST": "1"}
    target = TOOL if tag_or_pin is None else f"{TOOL}@{tag_or_pin}"
    return _run(["install", target], scenario, env, None, timeout=60)
