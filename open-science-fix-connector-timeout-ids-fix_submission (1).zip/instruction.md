## Task

We're seeing three failures when notebooks call our Connector tools, and all three happen every time.

First, Ensembl. Its records hand back stable IDs with a version on the end, like `ENST00000422447.8`. Feeding one of those directly into another call fails, whether that next call is a lookup, a cross-reference query or a sequence fetch. Unversioned IDs and gene symbols are fine. The record we return should still show the ID exactly as the caller gave it.

Second, when a request to an upstream service runs out of tries because every attempt timed out, all the notebook sees is the generic message "operation was aborted", which looks just like someone cancelling the notebook. The error should make clear it was a request timeout, and say which request it was, how many attempts were made and how long each attempt was allowed. If the person running the notebook cancels it themselves, they should still get the plain cancellation, and that request shouldn't be tried again.

Third, when a response begins to come in and then stops sending data part way through, it just hangs until the notebook's overall time limit kills it. It should be given up on and retried like any other timed-out attempt. A slow response that keeps delivering data shouldn't be cut off just because the whole download takes longer than one attempt is allowed.

Keep the per-request time limit and the number of retries as they are, and the notebook's time limit stays the outer bound. A tool that makes several upstream requests for one call must still fail as a whole rather than return part of its results.
