// @ts-nocheck
//
// A tool that makes several upstream requests for one call fails as a whole
// when one of them times out, instead of returning part of its result.
//
// cbioportal_get_study reads the study record, then its molecular profiles,
// samples and patients. Here every request answers except the patients
// request, which never responds until the attempt is aborted. The call must
// reject; it must not resolve with a study that lacks the patient count.

import { describe, it, expect, vi } from 'vitest'
import { ParserEngine } from './engine'
import { CANCER_MODELS_TOOLS } from './descriptors/cancer-models'

const jsonRes = (body: unknown): Response =>
  ({ ok: true, status: 200, json: async () => body }) as Response

const STUDY = {
  studyId: 'brca_tcga',
  name: 'Breast Invasive Carcinoma',
  description: 'd',
  cancerTypeId: 'brca',
  cancerType: { name: 'Breast' },
  referenceGenome: 'hg19',
  publicStudy: true,
  sequencedSampleCount: 4
}

describe('fan-out tools', () => {
  it('rejects the whole call when one of its upstream requests times out', async () => {
    const fetchImpl = vi.fn(
      async (url: string, init?: RequestInit): Promise<Response> => {
        if (url.includes('/patients?')) {
          return new Promise((_, reject) => {
            init?.signal?.addEventListener('abort', () => reject(init.signal?.reason), {
              once: true
            })
          })
        }
        if (url.includes('/samples?')) return jsonRes([{ sampleId: 's1' }, { sampleId: 's2' }])
        if (url.includes('/molecular-profiles')) return jsonRes([])
        if (url.includes('/studies/brca_tcga')) return jsonRes(STUDY)
        throw new Error(`unexpected fetch: ${url}`)
      }
    )
    const tool = CANCER_MODELS_TOOLS.find((t) => t.id === 'cbioportal_get_study')
    const engine = new ParserEngine({ fetchImpl, timeoutMs: 20, retries: 1, retryBackoffMs: 0 })

    const outcome = await engine.call(tool, { study_id: 'brca_tcga' }, {}).then(
      (value) => ({ resolved: true, value }),
      (error) => ({ resolved: false, error })
    )

    expect(outcome.resolved).toBe(false)
    const patientCalls = fetchImpl.mock.calls.filter(([url]) => String(url).includes('/patients?'))
    expect(patientCalls).toHaveLength(2) // the timed-out request was retried once, then gave up
  })
})
