// @ts-nocheck
//
// Checks for the shared connector request engine, driven only through
//   new ParserEngine({ fetchImpl, timeoutMs, retries, retryBackoffMs })
//     .call(descriptor, args, credentials, signal?)
// and observed through the injected fetchImpl (how often it is called, the
// signal each attempt gets) and the value the call resolves or rejects with:
//   - when every attempt times out, the rejection is not the cancellation
//     error and its message names the request, the attempt count and the
//     per-attempt limit;
//   - a caller's own cancellation is still a cancellation and is not retried;
//   - a body that keeps arriving completes even when it takes longer than one
//     attempt's limit;
//   - a body that goes quiet part way is retried, then reported as the
//     timeout, for JSON, text and POST requests;
//   - the default limit and retry count are unchanged.

import { describe, it, expect, vi } from 'vitest'
import { ParserEngine } from './engine'
import type { ToolDescriptor } from './types'

// A minimal 200 Response fake with no streaming body, used by the
// regression cases.
const jsonResponse = (body: unknown): Response =>
  ({
    ok: true,
    status: 200,
    json: async () => body,
    text: async () => JSON.stringify(body)
  }) as Response

// The attempt count and the per-attempt limit appear as standalone numbers (a digit inside a longer
// number doesn't count). Spelled-out or seconds forms of the same values are accepted too.
const ATTEMPTS_3 = /(^|\D)3(\D|$)|\bthree\b/i
const LIMIT_5_MS = /(^|\D)5(\D|$)|(^|\D)0?\.005\s*s/i

const urlDesc = (url = 'https://x.test/data'): ToolDescriptor => ({
  id: 't',
  connector: 'c',
  description: '',
  input: {},
  url: () => url,
  parse: (raw) => raw
})

describe('ParserEngine timeout', () => {
  it('reports an exhausted request deadline as a distinct timeout, not a bare cancellation', async () => {
    // Every attempt hangs until its own per-attempt deadline aborts it.
    const fetchImpl = vi.fn(
      async (_url: string | URL | Request, init?: RequestInit): Promise<Response> =>
        new Promise((_, reject) => {
          const requestSignal = init?.signal
          requestSignal?.addEventListener('abort', () => reject(requestSignal.reason), {
            once: true
          })
        })
    )
    const engine = new ParserEngine({ fetchImpl, timeoutMs: 5, retries: 2, retryBackoffMs: 0 })

    let error: unknown
    try {
      await engine.call(urlDesc('https://x.test/data'), {}, {})
      throw new Error('expected the call to reject')
    } catch (err) {
      error = err
    }

    const name = (error as { name?: unknown })?.name
    const message = error instanceof Error ? error.message : String(error)

    // Not the generic "operation was aborted" a cancelled cell produces.
    expect(name).not.toBe('AbortError')
    // The message says which request it was, how many attempts were made
    // (retries + 1 = 3) and how long each attempt was allowed (5 ms). Any
    // wording is fine as long as all three are there.
    expect(message).toContain('https://x.test/data')
    expect(message).toMatch(ATTEMPTS_3)
    expect(message).toMatch(LIMIT_5_MS)
    // 1 initial attempt + 2 retries.
    expect(fetchImpl).toHaveBeenCalledTimes(3)
  })

  it('surfaces a caller cancellation as a cancellation and does not retry it', async () => {
    let observedSignal: AbortSignal | undefined
    const fetchImpl = vi.fn(
      async (_url: string | URL | Request, init?: RequestInit): Promise<Response> =>
        new Promise((_, reject) => {
          observedSignal = init?.signal ?? undefined
          observedSignal?.addEventListener('abort', () => reject(observedSignal?.reason), {
            once: true
          })
        })
    )
    const engine = new ParserEngine({ fetchImpl, timeoutMs: 60_000, retries: 2, retryBackoffMs: 0 })
    const cancellation = new AbortController()

    const call = engine.call(urlDesc(), {}, {}, cancellation.signal)
    await vi.waitFor(() => expect(observedSignal).toBeInstanceOf(AbortSignal))
    cancellation.abort()

    await expect(call).rejects.toMatchObject({ name: 'AbortError' })
    expect(fetchImpl).toHaveBeenCalledOnce()
  })

  it('lets a continuously-progressing body finish even past one deadline', async () => {
    const encoder = new TextEncoder()
    const fetchImpl = vi.fn(
      async (_url: string | URL | Request, init?: RequestInit): Promise<Response> =>
        new Response(
          new ReadableStream({
            start(controller) {
              // Pieces arrive 10 ms apart (the limit is 30 ms) and the body
              // finishes at 40 ms. If the attempt's signal aborts, the stream
              // errors, as a real fetch body would.
              const timers = [
                setTimeout(() => controller.enqueue(encoder.encode('{"value":')), 10),
                setTimeout(() => controller.enqueue(encoder.encode('9}')), 20),
                setTimeout(() => controller.close(), 40)
              ]
              init?.signal?.addEventListener(
                'abort',
                () => {
                  for (const t of timers) clearTimeout(t)
                  controller.error(init.signal?.reason)
                },
                { once: true }
              )
            }
          })
        )
    )
    const engine = new ParserEngine({ fetchImpl, timeoutMs: 30, retries: 2, retryBackoffMs: 0 })
    const desc: ToolDescriptor = {
      id: 't',
      connector: 'c',
      description: '',
      input: {},
      url: () => 'https://x.test/data',
      parse: (raw) => (raw as { value: number }).value
    }

    await expect(engine.call(desc, {}, {})).resolves.toBe(9)
    expect(fetchImpl).toHaveBeenCalledOnce()
  })

  it('gives up on a body that stalls mid-stream and reports it as the deadline error', async () => {
    const encoder = new TextEncoder()
    const fetchImpl = vi.fn(
      async (_url: string | URL | Request, init?: RequestInit): Promise<Response> =>
        new Response(
          new ReadableStream({
            start(controller) {
              // Headers + a partial body arrive, then the stream goes quiet.
              controller.enqueue(encoder.encode('{"value":'))
              init?.signal?.addEventListener(
                'abort',
                () => controller.error(init.signal?.reason),
                { once: true }
              )
            }
          })
        )
    )
    const engine = new ParserEngine({ fetchImpl, timeoutMs: 5, retries: 2, retryBackoffMs: 0 })
    const result = engine.call(urlDesc('https://x.test/data'), {}, {}).catch((err: unknown) => err)

    // The call has to settle within 100 ms (three 5 ms attempts); otherwise the
    // race resolves to the 'still pending' marker.
    const settled = (await Promise.race([
      result,
      new Promise((resolve) => setTimeout(() => resolve('still pending'), 100))
    ])) as unknown

    expect(settled).not.toBe('still pending')
    const name = (settled as { name?: unknown })?.name
    const message = settled instanceof Error ? settled.message : String(settled)
    expect(name).not.toBe('AbortError')
    expect(message).toContain('https://x.test/data')
    expect(message).toMatch(ATTEMPTS_3)
    expect(message).toMatch(LIMIT_5_MS)
    expect(fetchImpl).toHaveBeenCalledTimes(3)
  })

  it('does not treat empty chunks as progress: a zero-byte trickle still times out', async () => {
    const encoder = new TextEncoder()
    const fetchImpl = vi.fn(
      async (_url: string | URL | Request, init?: RequestInit): Promise<Response> =>
        new Response(
          new ReadableStream({
            start(controller) {
              // A partial body, then an endless trickle of zero-byte reads
              // arriving faster than the deadline. Progress is measured in
              // bytes delivered: a deadline that treats these empty reads as
              // progress would keep this dead stream alive forever; a correct
              // idle deadline ignores them and still fires.
              controller.enqueue(encoder.encode('{"value":'))
              const ticker = setInterval(() => {
                try {
                  controller.enqueue(new Uint8Array(0))
                } catch {
                  clearInterval(ticker)
                }
              }, 2)
              init?.signal?.addEventListener(
                'abort',
                () => {
                  clearInterval(ticker)
                  controller.error(init.signal?.reason)
                },
                { once: true }
              )
            }
          })
        )
    )
    const engine = new ParserEngine({ fetchImpl, timeoutMs: 5, retries: 2, retryBackoffMs: 0 })
    const result = engine.call(urlDesc('https://x.test/data'), {}, {}).catch((err: unknown) => err)

    const settled = (await Promise.race([
      result,
      new Promise((resolve) => setTimeout(() => resolve('still pending'), 100))
    ])) as unknown

    expect(settled).not.toBe('still pending')
    const name = (settled as { name?: unknown })?.name
    const message = settled instanceof Error ? settled.message : String(settled)
    expect(name).not.toBe('AbortError')
    expect(message).toContain('https://x.test/data')
    expect(fetchImpl).toHaveBeenCalledTimes(3)
  })
})

describe('ParserEngine timeout on every kind of request', () => {
  // A body that sends a few bytes and then goes quiet, for any request.
  const stallingFetch = () =>
    vi.fn(
      async (_url: string | URL | Request, init?: RequestInit): Promise<Response> =>
        new Response(
          new ReadableStream({
            start(controller) {
              controller.enqueue(new TextEncoder().encode('partial'))
              init?.signal?.addEventListener('abort', () => controller.error(init.signal?.reason), {
                once: true
              })
            }
          })
        )
    )

  const settleWithin = async (call: Promise<unknown>): Promise<unknown> =>
    Promise.race([
      call.catch((err: unknown) => err),
      new Promise((resolve) => setTimeout(() => resolve('still pending'), 100))
    ])

  it('gives up on a stalled text response and reports the timeout', async () => {
    const fetchImpl = stallingFetch()
    const engine = new ParserEngine({ fetchImpl, timeoutMs: 5, retries: 2, retryBackoffMs: 0 })
    const desc: ToolDescriptor = {
      id: 't',
      connector: 'c',
      description: '',
      input: {},
      run: async (ctx) => ctx.fetchText('https://x.test/notes.txt')
    }
    const settled = await settleWithin(engine.call(desc, {}, {}))
    expect(settled).not.toBe('still pending')
    expect((settled as { name?: unknown })?.name).not.toBe('AbortError')
    expect(settled instanceof Error ? settled.message : String(settled)).toContain('https://x.test/notes.txt')
    expect(fetchImpl).toHaveBeenCalledTimes(3)
  })

  it('gives up on a stalled POST response and reports the timeout', async () => {
    const fetchImpl = stallingFetch()
    const engine = new ParserEngine({ fetchImpl, timeoutMs: 5, retries: 2, retryBackoffMs: 0 })
    const desc: ToolDescriptor = {
      id: 't',
      connector: 'c',
      description: '',
      input: {},
      run: async (ctx) => ctx.postJson('https://gql.test/api', { query: 'q' })
    }
    const settled = await settleWithin(engine.call(desc, {}, {}))
    expect(settled).not.toBe('still pending')
    expect((settled as { name?: unknown })?.name).not.toBe('AbortError')
    expect(settled instanceof Error ? settled.message : String(settled)).toContain('https://gql.test/api')
    expect(fetchImpl).toHaveBeenCalledTimes(3)
  })
})

describe('ParserEngine limits that stay the same', () => {
  it('still makes three tries in all by default (two retries)', async () => {
    const fetchImpl = vi.fn().mockResolvedValue({ ok: false, status: 503 } as Response)
    const engine = new ParserEngine({ fetchImpl, retryBackoffMs: 0 })
    await expect(engine.call(urlDesc('https://x.test'), {}, {})).rejects.toThrow(/HTTP 503/)
    expect(fetchImpl).toHaveBeenCalledTimes(3)
  })

  it('still allows each attempt 30 seconds by default', async () => {
    vi.useFakeTimers({ toFake: ['setTimeout', 'clearTimeout'] })
    try {
      let observedSignal: AbortSignal | undefined
      const fetchImpl = vi.fn(
        async (_url: string | URL | Request, init?: RequestInit): Promise<Response> =>
          new Promise((_, reject) => {
            observedSignal = init?.signal ?? undefined
            observedSignal?.addEventListener('abort', () => reject(observedSignal?.reason), {
              once: true
            })
          })
      )
      const engine = new ParserEngine({ fetchImpl, retries: 0, retryBackoffMs: 0 })
      const call = engine.call(urlDesc(), {}, {}).catch((err: unknown) => err)

      await vi.advanceTimersByTimeAsync(29_900)
      expect(observedSignal?.aborted).toBe(false)
      await vi.advanceTimersByTimeAsync(200)
      expect(observedSignal?.aborted).toBe(true)
      await call
    } finally {
      vi.useRealTimers()
    }
  })
})

describe('ParserEngine regression', () => {
  it('retries a transient 5xx up to the configured retries then surfaces an HTTP error', async () => {
    const fetchImpl = vi.fn().mockResolvedValue({ ok: false, status: 503 } as Response)
    const engine = new ParserEngine({ fetchImpl, retries: 2, retryBackoffMs: 0 })
    await expect(engine.call(urlDesc('https://x.test'), {}, {})).rejects.toThrow(/HTTP 503/)
    expect(fetchImpl).toHaveBeenCalledTimes(3) // 1 initial + 2 retries
  })

  it('retries a transient 5xx then succeeds', async () => {
    const fetchImpl = vi
      .fn()
      .mockResolvedValueOnce({ ok: false, status: 503 } as Response)
      .mockResolvedValueOnce(jsonResponse({ value: 7 }))
    const engine = new ParserEngine({ fetchImpl, retryBackoffMs: 0 })
    const desc: ToolDescriptor = {
      id: 't',
      connector: 'c',
      description: '',
      input: {},
      url: () => 'https://x.test',
      parse: (raw) => (raw as { value: number }).value
    }
    expect(await engine.call(desc, {}, {})).toBe(7)
    expect(fetchImpl).toHaveBeenCalledTimes(2)
  })

  it('does not retry a client error (4xx other than 429)', async () => {
    const fetchImpl = vi.fn().mockResolvedValue({ ok: false, status: 400 } as Response)
    const engine = new ParserEngine({ fetchImpl, retryBackoffMs: 0 })
    await expect(engine.call(urlDesc('https://x.test'), {}, {})).rejects.toThrow(/HTTP 400/)
    expect(fetchImpl).toHaveBeenCalledTimes(1)
  })

  it('postJson sends a POST with a JSON body and parses the response', async () => {
    const fetchImpl = vi.fn().mockResolvedValue(jsonResponse({ data: { ok: true } }))
    const engine = new ParserEngine({ fetchImpl })
    const desc: ToolDescriptor = {
      id: 't',
      connector: 'c',
      description: '',
      input: {},
      run: async (ctx) => ctx.postJson('https://gql.test/api', { query: 'q', variables: { a: 1 } })
    }
    const out = await engine.call(desc, {}, {})
    const init = fetchImpl.mock.calls[0][1] as RequestInit & { headers: Record<string, string> }
    expect(init.method).toBe('POST')
    expect(init.headers['content-type']).toBe('application/json')
    expect(JSON.parse(init.body as string)).toEqual({ query: 'q', variables: { a: 1 } })
    expect(out).toEqual({ data: { ok: true } })
  })

  it('sends a User-Agent header (some APIs 403 without one)', async () => {
    const fetchImpl = vi.fn().mockResolvedValue(jsonResponse({ ok: 1 }))
    const engine = new ParserEngine({ fetchImpl })
    await engine.call(urlDesc('https://example.test'), {}, {})
    const headers = (fetchImpl.mock.calls[0][1] as { headers: Record<string, string> }).headers
    expect(headers['user-agent']).toMatch(/OpenScience/)
  })

  it('redacts credentials from the URL in error messages', async () => {
    const fetchImpl = vi.fn().mockResolvedValue({ ok: false, status: 401 } as Response)
    const engine = new ParserEngine({ fetchImpl })
    let message = ''
    try {
      await engine.call(
        urlDesc('https://eutils.ncbi.nlm.nih.gov/entrez?email=a@b.com&api_key=SECRET'),
        {},
        {}
      )
    } catch (error) {
      message = error instanceof Error ? error.message : String(error)
    }
    expect(message).not.toContain('SECRET')
    expect(message).toContain('HTTP 401')
  })
})
