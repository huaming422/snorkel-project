// @ts-nocheck
import { describe, it, expect } from 'vitest';
import { getTestCases } from "./validationParams";
import {
  setupForDialect,
  teardownForDialect,
  collectionFixture,
} from "./jest_test_harness.js";
import { importSchema } from "../../../../../src/transfer/import/schema.js";

/**
 * Adapter: wraps importSchema to return { created, fieldsCreated }
 * by checking DB state before and after the call.
 */
async function runImport(db, record, fields) {
  const beforeColl = await db
    .selectFrom("_emdash_collections")
    .select("id")
    .where("id", "=", record.id)
    .executeTakeFirst();

  const beforeFields = await db
    .selectFrom("_emdash_fields")
    .select("id")
    .where("collection_id", "=", record.id)
    .execute();
  const beforeFieldIds = new Set(beforeFields.map((r) => r.id));

  await importSchema(db, { collections: [record], fields });

  const afterColl = await db
    .selectFrom("_emdash_collections")
    .select("id")
    .where("id", "=", record.id)
    .executeTakeFirst();

  const afterFields = await db
    .selectFrom("_emdash_fields")
    .select("id")
    .where("collection_id", "=", record.id)
    .execute();

  return {
    created: !beforeColl && !!afterColl,
    fieldsCreated: afterFields.filter((r) => !beforeFieldIds.has(r.id)).length,
  };
}

describe("rejects_divergent_stored_rows", () => {
  const cases = getTestCases();

  it.each(cases)("case $#", async ({ inputs, expected }) => {
    const ctx = await setupForDialect("sqlite");
    try {
      // Step 2: build fixture
      const fixture = collectionFixture(inputs.fixture_n);

      // Step 3: clean import first
      const first = await runImport(ctx.db, fixture.record, fixture.fields);
      expect(first.created).toBe(true);
      expect(first.fieldsCreated).toBe(expected.field_count);

      // Step 4: build divergent inputs
      let divergentRecord = fixture.record;
      let divergentFields = fixture.fields;

      if (inputs.target === "collection") {
        divergentRecord = { ...fixture.record, label: "Changed" };
        // divergentFields stays the same
      } else if (inputs.target === "field") {
        divergentRecord = fixture.record;
        divergentFields = [
          { ...fixture.fields[0], label: "Changed" },
          ...fixture.fields.slice(1),
        ];
      }

      // Step 5: divergent re-import must be rejected
      await expect(
        runImport(ctx.db, divergentRecord, divergentFields)
      ).rejects.toBeTruthy();

      // Step 6: stored row was NOT overwritten
      if (inputs.target === "collection") {
        const row = await ctx.db
          .selectFrom("_emdash_collections")
          .select("label")
          .where("id", "=", fixture.record.id)
          .executeTakeFirstOrThrow();
        expect(row.label).toBe(expected.stored_label);
      } else if (inputs.target === "field") {
        const row = await ctx.db
          .selectFrom("_emdash_fields")
          .select("label")
          .where("id", "=", fixture.fields[0].id)
          .executeTakeFirstOrThrow();
        expect(row.label).toBe(expected.stored_label);
      }

      // Step 7: no duplicate/extra collection created
      const allCollections = await ctx.db
        .selectFrom("_emdash_collections")
        .select("id")
        .execute();
      expect(allCollections.length).toBe(expected.collection_count_after);
    } finally {
      await teardownForDialect(ctx);
    }
  });
});
