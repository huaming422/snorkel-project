// @ts-nocheck
import { describe, it, expect } from 'vitest';
import { getTestCases } from "./validationParams";
import {
  setupForDialect,
  teardownForDialect,
  collectionFixture,
  collectionShape,
  withFaults,
} from "./jest_test_harness.js";
import { importSchema } from "../../../../../src/transfer/import/schema.js";

/**
 * Adapter: wraps importSchema to return { created, fieldsCreated }
 * by checking DB state before and after the call.
 */
async function runImport(db, record, fields) {
  const beforeColl = await db
    .selectFrom("_emdash_collections")
    .select("id")
    .where("id", "=", record.id)
    .executeTakeFirst();

  const beforeFields = await db
    .selectFrom("_emdash_fields")
    .select("id")
    .where("collection_id", "=", record.id)
    .execute();
  const beforeFieldIds = new Set(beforeFields.map((r) => r.id));

  await importSchema(db, { collections: [record], fields });

  const afterColl = await db
    .selectFrom("_emdash_collections")
    .select("id")
    .where("id", "=", record.id)
    .executeTakeFirst();

  const afterFields = await db
    .selectFrom("_emdash_fields")
    .select("id")
    .where("collection_id", "=", record.id)
    .execute();

  return {
    created: !beforeColl && !!afterColl,
    fieldsCreated: afterFields.filter((r) => !beforeFieldIds.has(r.id)).length,
  };
}

describe("idempotent_resumable_import", () => {
  const cases = getTestCases();

  it.each(cases)("case $#", async ({ inputs, expected }) => {
    if (inputs.mode === "noop_on_repeat") {
      const ctx = await setupForDialect("sqlite");
      try {
        const fixture = collectionFixture(inputs.fixture_n);

        // First import
        await runImport(ctx.db, fixture.record, fixture.fields);
        const before = await collectionShape(ctx.db, fixture);

        // Second import (repeat)
        const again = await runImport(ctx.db, fixture.record, fixture.fields);

        // EXPECTED: repeat reports nothing newly created
        expect(again.created).toBe(expected.second_created);
        expect(again.fieldsCreated).toBe(expected.second_field_count);

        // EXPECTED: shape is byte-identical after repeat
        const after = await collectionShape(ctx.db, fixture);
        expect(after).toEqual(before);
      } finally {
        await teardownForDialect(ctx);
      }
    } else if (inputs.mode === "resume_after_crash") {
      const ctx = await setupForDialect("sqlite");
      try {
        // Establish reference shape from a clean import
        const reference = collectionFixture(0);
        await runImport(ctx.db, reference.record, reference.fields);
        const expectedShape = await collectionShape(ctx.db, reference);

        const { db: faultyDb, faults } = withFaults(ctx.db);

        let crashes = 0;
        // Cap at a reasonable upper bound to avoid infinite loops if always crashing
        const MAX_ITERATIONS = 200;
        for (let n = 1; n <= MAX_ITERATIONS; n++) {
          const fixture = collectionFixture(n);
          faults.failAfter(n);
          let crashed = false;
          try {
            await runImport(faultyDb, fixture.record, fixture.fields);
            crashed = faults.crashed;
            faults.disarm();
            if (crashed) {
              // crash fired in the try path (via transformQuery on a later call)
              crashes++;
            } else {
              // No crash fired — we're done exercising crash points
              break;
            }
          } catch (error) {
            faults.disarm();
            expect(error.message).toContain("injected crash");
            crashes++;
          }
          // Resume against un-faulted db
          await runImport(ctx.db, fixture.record, fixture.fields);
          // EXPECTED: after resuming, shape matches clean import
          const shape = await collectionShape(ctx.db, fixture);
          expect(shape).toEqual(expectedShape);
        }

        // EXPECTED: crashes > min_crashes
        expect(crashes).toBeGreaterThan(expected.min_crashes);
      } finally {
        await teardownForDialect(ctx);
      }
    } else if (inputs.mode === "within_d1_budget") {
      const ctx = await setupForDialect("sqlite");
      try {
        const { db, faults } = withFaults(ctx.db);

        // Import narrow collection
        const narrow = collectionFixture(3);
        await runImport(db, narrow.record, narrow.fields);
        const narrowStatements = faults.executed;

        // Import wide collection
        const wide = collectionFixture(4, inputs.extra_fields);
        const beforeWide = faults.executed;
        await runImport(db, wide.record, wide.fields);
        const wideStatements = faults.executed - beforeWide;

        // EXPECTED: no single statement exceeds D1 bind-parameter ceiling
        expect(faults.maxParameters).toBeLessThanOrEqual(expected.max_parameters);

        // EXPECTED: narrow import within budget
        expect(narrowStatements).toBeLessThanOrEqual(expected.max_narrow_statements);

        // EXPECTED: wide import's statement count grows within budget
        expect(wideStatements).toBeLessThanOrEqual(
          narrowStatements + expected.wide_statement_slack
        );
      } finally {
        await teardownForDialect(ctx);
      }
    }
  });
});
