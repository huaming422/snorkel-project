// @ts-nocheck
import { describe, it, expect } from 'vitest';
import { getTestCases } from "./validationParams";
import {
  setupForDialect,
  teardownForDialect,
  collectionFixture,
} from "./jest_test_harness.js";
import { importSchema } from "../../../../../src/transfer/import/schema.js";

/**
 * Adapter: wraps importSchema to return { created, fieldsCreated }
 * by checking DB state before and after the call.
 */
async function runImport(db, record, fields) {
  const beforeColl = await db
    .selectFrom("_emdash_collections")
    .select("id")
    .where("id", "=", record.id)
    .executeTakeFirst();

  const beforeFields = await db
    .selectFrom("_emdash_fields")
    .select("id")
    .where("collection_id", "=", record.id)
    .execute();
  const beforeFieldIds = new Set(beforeFields.map((r) => r.id));

  await importSchema(db, { collections: [record], fields });

  const afterColl = await db
    .selectFrom("_emdash_collections")
    .select("id")
    .where("id", "=", record.id)
    .executeTakeFirst();

  const afterFields = await db
    .selectFrom("_emdash_fields")
    .select("id")
    .where("collection_id", "=", record.id)
    .execute();

  return {
    created: !beforeColl && !!afterColl,
    fieldsCreated: afterFields.filter((r) => !beforeFieldIds.has(r.id)).length,
  };
}

describe("validates_fields_before_write", () => {
  const cases = getTestCases();

  it.each(cases)("case $#", async ({ inputs, expected }) => {
    const ctx = await setupForDialect("sqlite");
    try {
      // Step 2: import a valid baseline collection first
      const base = collectionFixture(inputs.base_n);
      const ok = await runImport(ctx.db, base.record, base.fields);
      expect(ok.created).toBe(true);
      expect(ok.fieldsCreated).toBe(expected.field_count);

      // Step 3: construct the bad import
      let badRecord;
      let badFields;

      if (inputs.mode === "field_type_mismatch") {
        const bad = collectionFixture(inputs.bad_n);
        // Corrupt the first field: string/TEXT field gets INTEGER column type
        badFields = [
          { ...bad.fields[0], columnType: "INTEGER" },
          ...bad.fields.slice(1),
        ];
        badRecord = bad.record;
      } else if (inputs.mode === "slug_collision") {
        const bad = collectionFixture(inputs.bad_n);
        // Different collection id but slug collides with baseline
        badRecord = { ...bad.record, slug: base.record.slug };
        badFields = bad.fields;
      }

      // Step 4: attempt the bad import — must be rejected
      await expect(
        runImport(ctx.db, badRecord, badFields)
      ).rejects.toBeTruthy();

      // Step 5: nothing partial was left behind
      const allCollections = await ctx.db
        .selectFrom("_emdash_collections")
        .select(["id", "slug"])
        .execute();

      // EXPECTED: collection count after
      expect(allCollections.length).toBe(expected.collection_count_after);

      if (inputs.mode === "field_type_mismatch") {
        // The bad collection's id is absent
        const found = await ctx.db
          .selectFrom("_emdash_collections")
          .select("id")
          .where("id", "=", badRecord.id)
          .executeTakeFirst();
        expect(found).toBeUndefined();
      } else if (inputs.mode === "slug_collision") {
        // Baseline collection still owns the slug
        const row = await ctx.db
          .selectFrom("_emdash_collections")
          .select("id")
          .where("slug", "=", base.record.slug)
          .executeTakeFirst();
        expect(row?.id).toBe(base.record.id);
      }

      // EXPECTED: surviving slug equals the base collection's slug
      const survivingRows = await ctx.db
        .selectFrom("_emdash_collections")
        .select("slug")
        .execute();
      expect(survivingRows.length).toBe(1);
      expect(survivingRows[0].slug).toBe(expected.surviving_slug);
    } finally {
      await teardownForDialect(ctx);
    }
  });
});
