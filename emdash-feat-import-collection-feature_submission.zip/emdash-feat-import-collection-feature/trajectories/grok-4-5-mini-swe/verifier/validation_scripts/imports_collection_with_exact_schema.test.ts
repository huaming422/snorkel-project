// @ts-nocheck
import { describe, it, expect } from 'vitest';
import { getTestCases } from "./validationParams";
import {
  setupForDialect,
  teardownForDialect,
  collectionFixture,
  collectionShape,
  activateMediaUsageCapture,
} from "./jest_test_harness.js";
import { importSchema } from "../../../../../src/transfer/import/schema.js";

/**
 * Adapter: wraps importSchema to return { created, fieldsCreated }
 * by checking DB state before and after the call.
 */
async function runImport(db, record, fields) {
  const beforeColl = await db
    .selectFrom("_emdash_collections")
    .select("id")
    .where("id", "=", record.id)
    .executeTakeFirst();

  const beforeFields = await db
    .selectFrom("_emdash_fields")
    .select("id")
    .where("collection_id", "=", record.id)
    .execute();
  const beforeFieldIds = new Set(beforeFields.map((r) => r.id));

  await importSchema(db, { collections: [record], fields });

  const afterColl = await db
    .selectFrom("_emdash_collections")
    .select("id")
    .where("id", "=", record.id)
    .executeTakeFirst();

  const afterFields = await db
    .selectFrom("_emdash_fields")
    .select("id")
    .where("collection_id", "=", record.id)
    .execute();

  return {
    created: !beforeColl && !!afterColl,
    fieldsCreated: afterFields.filter((r) => !beforeFieldIds.has(r.id)).length,
  };
}

describe("imports_collection_with_exact_schema", () => {
  const cases = getTestCases();

  it.each(cases)("case $#", async ({ inputs, expected }) => {
    const ctx = await setupForDialect("sqlite");
    try {
      // Step 2: optionally activate media usage capture
      if (inputs.capture_active) {
        await activateMediaUsageCapture(ctx.db, { writersDrained: true });
      }

      // Step 3: build fixture
      const fixture = collectionFixture(inputs.fixture_n);

      // Step 4: run the import
      const result = await runImport(ctx.db, fixture.record, fixture.fields);

      // Step 5: EXPECTED result.created
      expect(result.created).toBe(expected.created);

      // Step 6: EXPECTED result.fieldsCreated
      expect(result.fieldsCreated).toBe(expected.field_count);

      // Step 7: read stored collection row
      const collection = await ctx.db
        .selectFrom("_emdash_collections")
        .selectAll()
        .where("slug", "=", fixture.record.slug)
        .executeTakeFirstOrThrow();

      // EXPECTED: collection.id === fixture.record.id (own id was written)
      expect(collection.id).toBe(fixture.record.id);

      // EXPECTED: search written disabled even though record had enabled=true
      expect(JSON.parse(collection.search_config).enabled).toBe(expected.search_enabled);

      // Step 8: read stored field rows
      const fields = await ctx.db
        .selectFrom("_emdash_fields")
        .select(["id", "slug"])
        .where("collection_id", "=", fixture.record.id)
        .orderBy("sort_order")
        .execute();

      // EXPECTED: exact field ids in order
      expect(fields.map((f) => f.id)).toEqual(fixture.fields.map((f) => f.id));

      // Step 9: snapshot the schema shape
      const shape = await collectionShape(ctx.db, fixture);

      // EXPECTED: required columns present (splitting "name:type" and taking name)
      const columnNames = shape.columns.map((c) => c.split(":")[0]);
      for (const col of expected.required_columns) {
        expect(columnNames).toContain(col);
      }

      // EXPECTED: required indexes present
      for (const idx of expected.required_indexes) {
        expect(shape.indexes).toContain(idx);
      }

      // EXPECTED: triggers match expectation
      expect(shape.triggers).toBe(expected.expect_triggers);
    } finally {
      await teardownForDialect(ctx);
    }
  });
});
