// @ts-nocheck
import { describe, it, expect } from "vitest";
import { getTestCases } from "./validationParams";
import {
  setupForDialect,
  teardownForDialect,
  collectionFixture,
} from "./jest_test_harness.js";
import { SchemaImporter } from "../../../../../src/transfer/import/schema.js";

/**
 * runImport: wraps SchemaImporter.importSchema and tracks created/fieldsCreated
 * by checking DB state before and after.
 */
async function runImport(db, record, fields) {
  const beforeCollection = await db
    .selectFrom("_emdash_collections")
    .select("id")
    .where("id", "=", record.id)
    .executeTakeFirst();
  const beforeFieldIds = beforeCollection
    ? (
        await db
          .selectFrom("_emdash_fields")
          .select("id")
          .where("collection_id", "=", record.id)
          .execute()
      ).map((f) => f.id)
    : [];

  const importer = new SchemaImporter(db);
  await importer.importSchema([record], fields);

  const afterCollection = await db
    .selectFrom("_emdash_collections")
    .select("id")
    .where("id", "=", record.id)
    .executeTakeFirst();
  const afterFields = await db
    .selectFrom("_emdash_fields")
    .select("id")
    .where("collection_id", "=", record.id)
    .execute();

  const created = !beforeCollection && !!afterCollection;
  const fieldsCreated = afterFields.filter((f) => !beforeFieldIds.includes(f.id)).length;

  return { created, fieldsCreated };
}

describe("rejects_divergent_stored_rows", () => {
  const cases = getTestCases();

  it.each(cases)("case %#", async ({ inputs, expected }) => {
    const ctx = await setupForDialect("sqlite");
    try {
      const fixture = collectionFixture(inputs.fixture_n);

      // Clean import first
      const first = await runImport(ctx.db, fixture.record, fixture.fields);

      // EXPECTED: first.created === true
      expect(first.created).toBe(true);

      // EXPECTED: first.fieldsCreated === expected.field_count
      expect(first.fieldsCreated).toBe(expected.field_count);

      // Build divergent version
      let divergentRecord = fixture.record;
      let divergentFields = fixture.fields;

      if (inputs.target === "collection") {
        divergentRecord = { ...fixture.record, label: "Changed" };
        // same fields
      } else if (inputs.target === "field") {
        // same record, first field's label changed
        divergentFields = [
          { ...fixture.fields[0], label: "Changed" },
          ...fixture.fields.slice(1),
        ];
      }

      // Re-import the divergent inputs and assert it is REJECTED
      await expect(
        runImport(ctx.db, divergentRecord, divergentFields)
      ).rejects.toBeTruthy();

      if (inputs.target === "collection") {
        // EXPECTED: row.label === expected.stored_label (original "Imported")
        const row = await ctx.db
          .selectFrom("_emdash_collections")
          .select("label")
          .where("id", "=", fixture.record.id)
          .executeTakeFirstOrThrow();
        expect(row.label).toBe(expected.stored_label);
      } else if (inputs.target === "field") {
        // EXPECTED: first field's label equals expected.stored_label
        const fieldRow = await ctx.db
          .selectFrom("_emdash_fields")
          .select("label")
          .where("id", "=", fixture.fields[0].id)
          .executeTakeFirstOrThrow();
        expect(fieldRow.label).toBe(expected.stored_label);
      }

      // EXPECTED: count of _emdash_collections rows equals expected.collection_count_after
      const { count } = await ctx.db
        .selectFrom("_emdash_collections")
        .select((eb) => eb.fn.countAll().as("count"))
        .executeTakeFirstOrThrow();
      expect(Number(count)).toBe(expected.collection_count_after);
    } finally {
      await teardownForDialect(ctx);
    }
  });
});
