// @ts-nocheck
import { describe, it, expect } from "vitest";
import { getTestCases } from "./validationParams";
import {
  setupForDialect,
  teardownForDialect,
  collectionFixture,
  collectionShape,
  activateMediaUsageCapture,
} from "./jest_test_harness.js";
import { SchemaImporter } from "../../../../../src/transfer/import/schema.js";

/**
 * runImport: wraps SchemaImporter.importSchema and tracks created/fieldsCreated
 * by checking DB state before and after.
 */
async function runImport(db, record, fields) {
  // Check before
  const beforeCollection = await db
    .selectFrom("_emdash_collections")
    .select("id")
    .where("id", "=", record.id)
    .executeTakeFirst();
  const beforeFieldIds = beforeCollection
    ? (
        await db
          .selectFrom("_emdash_fields")
          .select("id")
          .where("collection_id", "=", record.id)
          .execute()
      ).map((f) => f.id)
    : [];

  const importer = new SchemaImporter(db);
  await importer.importSchema([record], fields);

  // Check after
  const afterCollection = await db
    .selectFrom("_emdash_collections")
    .select("id")
    .where("id", "=", record.id)
    .executeTakeFirst();
  const afterFields = await db
    .selectFrom("_emdash_fields")
    .select("id")
    .where("collection_id", "=", record.id)
    .execute();

  const created = !beforeCollection && !!afterCollection;
  const fieldsCreated = afterFields.filter((f) => !beforeFieldIds.includes(f.id)).length;

  return { created, fieldsCreated };
}

describe("imports_collection_with_exact_schema", () => {
  const cases = getTestCases();

  it.each(cases)("case $#", async ({ inputs, expected }) => {
    const ctx = await setupForDialect("sqlite");
    try {
      if (inputs.capture_active) {
        await activateMediaUsageCapture(ctx.db, { writersDrained: true });
      }

      const fixture = collectionFixture(inputs.fixture_n);
      const result = await runImport(ctx.db, fixture.record, fixture.fields);

      // EXPECTED: result.created === expected.created
      expect(result.created).toBe(expected.created);

      // EXPECTED: result.fieldsCreated === expected.field_count
      expect(result.fieldsCreated).toBe(expected.field_count);

      // Read the stored collection row
      const collection = await ctx.db
        .selectFrom("_emdash_collections")
        .selectAll()
        .where("slug", "=", fixture.record.slug)
        .executeTakeFirstOrThrow();

      // EXPECTED: collection.id === fixture.record.id
      expect(collection.id).toBe(fixture.record.id);

      // EXPECTED: search_config is null (search disabled on import) and expected.search_enabled is false
      // search_config is stored as null when search is disabled
      expect(collection.search_config).toBeNull();
      expect(expected.search_enabled).toBe(false);

      // Read stored field rows
      const fields = await ctx.db
        .selectFrom("_emdash_fields")
        .select(["id", "slug"])
        .where("collection_id", "=", fixture.record.id)
        .orderBy("sort_order")
        .execute();

      // EXPECTED: fields.map(f => f.id) equals fixture.fields.map(f => f.id)
      expect(fields.map((f) => f.id)).toEqual(fixture.fields.map((f) => f.id));

      // Snapshot the schema shape
      const shape = await collectionShape(ctx.db, fixture);

      // EXPECTED: shape.columns.map(c => c.split(":")[0]) contains every entry of expected.required_columns
      const columnNames = shape.columns.map((c) => c.split(":")[0]);
      for (const col of expected.required_columns) {
        expect(columnNames).toContain(col);
      }

      // EXPECTED: shape.indexes contains every entry of expected.required_indexes
      for (const idx of expected.required_indexes) {
        expect(shape.indexes).toContain(idx);
      }

      // EXPECTED: shape.triggers === expected.expect_triggers
      expect(shape.triggers).toBe(expected.expect_triggers);
    } finally {
      await teardownForDialect(ctx);
    }
  });
});
