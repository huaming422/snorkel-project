// @ts-nocheck
import { describe, it, expect } from "vitest";
import { getTestCases } from "./validationParams";
import {
  setupForDialect,
  teardownForDialect,
  collectionFixture,
} from "./jest_test_harness.js";
import { SchemaImporter } from "../../../../../src/transfer/import/schema.js";

/**
 * runImport: wraps SchemaImporter.importSchema and tracks created/fieldsCreated
 * by checking DB state before and after.
 */
async function runImport(db, record, fields) {
  const beforeCollection = await db
    .selectFrom("_emdash_collections")
    .select("id")
    .where("id", "=", record.id)
    .executeTakeFirst();
  const beforeFieldIds = beforeCollection
    ? (
        await db
          .selectFrom("_emdash_fields")
          .select("id")
          .where("collection_id", "=", record.id)
          .execute()
      ).map((f) => f.id)
    : [];

  const importer = new SchemaImporter(db);
  await importer.importSchema([record], fields);

  const afterCollection = await db
    .selectFrom("_emdash_collections")
    .select("id")
    .where("id", "=", record.id)
    .executeTakeFirst();
  const afterFields = await db
    .selectFrom("_emdash_fields")
    .select("id")
    .where("collection_id", "=", record.id)
    .execute();

  const created = !beforeCollection && !!afterCollection;
  const fieldsCreated = afterFields.filter((f) => !beforeFieldIds.includes(f.id)).length;

  return { created, fieldsCreated };
}

describe("validates_fields_before_write", () => {
  const cases = getTestCases();

  it.each(cases)("case %#", async ({ inputs, expected }) => {
    const ctx = await setupForDialect("sqlite");
    try {
      // Import a VALID baseline collection first
      const base = collectionFixture(inputs.base_n);
      const ok = await runImport(ctx.db, base.record, base.fields);

      // EXPECTED: ok.created === true
      expect(ok.created).toBe(true);

      // EXPECTED: ok.fieldsCreated === expected.field_count
      expect(ok.fieldsCreated).toBe(expected.field_count);

      // Construct the BAD import
      let badRecord;
      let badFields;

      if (inputs.mode === "field_type_mismatch") {
        const bad = collectionFixture(inputs.bad_n);
        badRecord = bad.record;
        badFields = [
          { ...bad.fields[0], columnType: "INTEGER" },
          ...bad.fields.slice(1),
        ];

        // Attempt the bad import and assert it is REJECTED
        await expect(runImport(ctx.db, badRecord, badFields)).rejects.toBeTruthy();

        // EXPECTED: collection_count_after
        const { count } = await ctx.db
          .selectFrom("_emdash_collections")
          .select((eb) => eb.fn.countAll().as("count"))
          .executeTakeFirstOrThrow();
        expect(Number(count)).toBe(expected.collection_count_after);

        // For field_type_mismatch: bad collection's id is absent
        const found = await ctx.db
          .selectFrom("_emdash_collections")
          .select("id")
          .where("id", "=", bad.record.id)
          .executeTakeFirst();
        expect(found).toBeUndefined();

        // EXPECTED: surviving_slug equals the slug of the single surviving row
        const surviving = await ctx.db
          .selectFrom("_emdash_collections")
          .select("slug")
          .executeTakeFirstOrThrow();
        expect(surviving.slug).toBe(expected.surviving_slug);
      } else if (inputs.mode === "slug_collision") {
        const bad = collectionFixture(inputs.bad_n);
        badRecord = { ...bad.record, slug: base.record.slug };
        badFields = bad.fields;

        // Attempt the bad import and assert it is REJECTED
        await expect(runImport(ctx.db, badRecord, badFields)).rejects.toBeTruthy();

        // EXPECTED: collection_count_after
        const { count } = await ctx.db
          .selectFrom("_emdash_collections")
          .select((eb) => eb.fn.countAll().as("count"))
          .executeTakeFirstOrThrow();
        expect(Number(count)).toBe(expected.collection_count_after);

        // For slug_collision: baseline collection still owns the slug
        const slugRow = await ctx.db
          .selectFrom("_emdash_collections")
          .select(["id", "slug"])
          .where("slug", "=", base.record.slug)
          .executeTakeFirstOrThrow();
        expect(slugRow.id).toBe(base.record.id);

        // EXPECTED: surviving_slug equals the slug of the single surviving row
        expect(slugRow.slug).toBe(expected.surviving_slug);
      }
    } finally {
      await teardownForDialect(ctx);
    }
  });
});
