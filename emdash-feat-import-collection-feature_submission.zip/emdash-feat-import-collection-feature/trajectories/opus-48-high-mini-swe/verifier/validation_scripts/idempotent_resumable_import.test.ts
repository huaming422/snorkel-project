// @ts-nocheck
import { describe, it, expect } from "vitest";
import { getTestCases } from "./validationParams";
import {
  setupForDialect,
  teardownForDialect,
  collectionFixture,
  collectionShape,
  withFaults,
} from "./jest_test_harness.js";
import { SchemaImporter } from "../../../../../src/transfer/import/schema.js";

/**
 * runImport: wraps SchemaImporter.importSchema and tracks created/fieldsCreated
 * by checking DB state before and after.
 */
async function runImport(db, record, fields) {
  const beforeCollection = await db
    .selectFrom("_emdash_collections")
    .select("id")
    .where("id", "=", record.id)
    .executeTakeFirst();
  const beforeFieldIds = beforeCollection
    ? (
        await db
          .selectFrom("_emdash_fields")
          .select("id")
          .where("collection_id", "=", record.id)
          .execute()
      ).map((f) => f.id)
    : [];

  const importer = new SchemaImporter(db);
  await importer.importSchema([record], fields);

  const afterCollection = await db
    .selectFrom("_emdash_collections")
    .select("id")
    .where("id", "=", record.id)
    .executeTakeFirst();
  const afterFields = await db
    .selectFrom("_emdash_fields")
    .select("id")
    .where("collection_id", "=", record.id)
    .execute();

  const created = !beforeCollection && !!afterCollection;
  const fieldsCreated = afterFields.filter((f) => !beforeFieldIds.includes(f.id)).length;

  return { created, fieldsCreated };
}

describe("idempotent_resumable_import", () => {
  const cases = getTestCases();

  it.each(cases)("case $#", async ({ inputs, expected }) => {
    if (inputs.mode === "noop_on_repeat") {
      const ctx = await setupForDialect("sqlite");
      try {
        const fixture = collectionFixture(inputs.fixture_n);
        await runImport(ctx.db, fixture.record, fixture.fields);
        const before = await collectionShape(ctx.db, fixture);
        const again = await runImport(ctx.db, fixture.record, fixture.fields);

        // EXPECTED: again.created === expected.second_created (false)
        expect(again.created).toBe(expected.second_created);

        // EXPECTED: again.fieldsCreated === expected.second_field_count (0)
        expect(again.fieldsCreated).toBe(expected.second_field_count);

        // EXPECTED: await collectionShape(ctx.db, fixture) deep-equals before
        const after = await collectionShape(ctx.db, fixture);
        expect(after).toEqual(before);
      } finally {
        await teardownForDialect(ctx);
      }
    } else if (inputs.mode === "resume_after_crash") {
      const ctx = await setupForDialect("sqlite");
      try {
        // Establish reference shape from a clean import (fixture 0).
        // collectionShape normalizes all ids/slugs so fixtures with identical
        // field structure (same slugs, same column types) produce the same shape.
        const reference = collectionFixture(0);
        await runImport(ctx.db, reference.record, reference.fields);
        const expectedShape = await collectionShape(ctx.db, reference);

        const { db, faults } = withFaults(ctx.db);

        let crashes = 0;
        for (let n = 1; ; n++) {
          const fixture = collectionFixture(n);
          faults.failAfter(n);
          try {
            await runImport(db, fixture.record, fixture.fields);
            // If we reach here: check whether crash fired (it may have fired
            // and been caught inside the import itself, though that's unlikely).
            const crashed = faults.crashed;
            faults.disarm();
            if (!crashed) break;
          } catch (error) {
            faults.disarm();
            expect(error.message).toContain("injected crash");
          }
          crashes++;
          // Resume against the un-faulted db
          await runImport(ctx.db, fixture.record, fixture.fields);
          // EXPECTED: after resuming, shape matches clean import
          const shape = await collectionShape(ctx.db, fixture);
          expect(shape).toEqual(expectedShape);
        }

        // EXPECTED: crashes > expected.min_crashes
        expect(crashes).toBeGreaterThan(expected.min_crashes);
      } finally {
        await teardownForDialect(ctx);
      }
    } else if (inputs.mode === "within_d1_budget") {
      const ctx = await setupForDialect("sqlite");
      try {
        const { db, faults } = withFaults(ctx.db);

        // Import a narrow collection
        const narrow = collectionFixture(3);
        await runImport(db, narrow.record, narrow.fields);
        const narrowStatements = faults.executed;

        // Import a wide collection
        const wide = collectionFixture(4, inputs.extra_fields);
        const before = faults.executed;
        await runImport(db, wide.record, wide.fields);
        const wideStatements = faults.executed - before;

        // EXPECTED: faults.maxParameters <= expected.max_parameters
        expect(faults.maxParameters).toBeLessThanOrEqual(expected.max_parameters);

        // EXPECTED: narrowStatements <= expected.max_narrow_statements
        expect(narrowStatements).toBeLessThanOrEqual(expected.max_narrow_statements);

        // EXPECTED: wideStatements <= narrowStatements + expected.wide_statement_slack
        expect(wideStatements).toBeLessThanOrEqual(narrowStatements + expected.wide_statement_slack);
      } finally {
        await teardownForDialect(ctx);
      }
    }
  });
});
