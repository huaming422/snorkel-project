// @ts-nocheck
import { describe, it, expect } from "vitest";
import {
  setupForDialect,
  teardownForDialect,
  collectionFixture,
} from "./jest_test_harness.js";
import { importPortableSchema } from "../../../../../src/transfer/import/schema.js";
import { getTestCases } from "./validationParams";

/**
 * Adapter: wraps importPortableSchema (returns void) and computes
 * { created, fieldsCreated } by diffing the DB state before/after.
 */
async function runImport(db, record, fields) {
  const beforeCollection = await db
    .selectFrom("_emdash_collections")
    .select("id")
    .where("id", "=", record.id)
    .executeTakeFirst();
  const collectionExisted = !!beforeCollection;

  const beforeFieldIds = new Set(
    (
      await db
        .selectFrom("_emdash_fields")
        .select("id")
        .where("collection_id", "=", record.id)
        .execute()
    ).map((r) => r.id),
  );

  await importPortableSchema(db, { collections: [record], fields });

  const afterFieldIds = (
    await db
      .selectFrom("_emdash_fields")
      .select("id")
      .where("collection_id", "=", record.id)
      .execute()
  ).map((r) => r.id);

  const fieldsCreated = afterFieldIds.filter((id) => !beforeFieldIds.has(id)).length;

  return {
    created: !collectionExisted,
    fieldsCreated,
  };
}

describe("rejects_divergent_stored_rows", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    const ctx = await setupForDialect("sqlite");
    try {
      // Step 2: clean import first
      const fixture = collectionFixture(inputs.fixture_n);

      // Step 3: clean import
      const first = await runImport(ctx.db, fixture.record, fixture.fields);

      // EXPECTED: first.created === true and first.fieldsCreated === expected.field_count
      expect(first.created).toBe(true);
      expect(first.fieldsCreated).toBe(expected.field_count);

      // Step 4: build divergent version
      let divergentRecord = fixture.record;
      let divergentFields = fixture.fields;

      if (inputs.target === "collection") {
        divergentRecord = { ...fixture.record, label: "Changed" };
        // fields remain the same
      } else if (inputs.target === "field") {
        // same record, but first field's label changed
        divergentFields = [
          { ...fixture.fields[0], label: "Changed" },
          ...fixture.fields.slice(1),
        ];
      }

      // Step 5: re-import divergent inputs and assert it is REJECTED
      await expect(
        runImport(ctx.db, divergentRecord, divergentFields),
      ).rejects.toBeTruthy();

      // Step 6: stored row was NOT overwritten
      if (inputs.target === "collection") {
        const row = await ctx.db
          .selectFrom("_emdash_collections")
          .select("label")
          .where("id", "=", fixture.record.id)
          .executeTakeFirstOrThrow();
        // EXPECTED: row.label === expected.stored_label (the original "Imported")
        expect(row.label).toBe(expected.stored_label);
      } else if (inputs.target === "field") {
        const fieldRow = await ctx.db
          .selectFrom("_emdash_fields")
          .select("label")
          .where("id", "=", fixture.fields[0].id)
          .executeTakeFirstOrThrow();
        // EXPECTED: label equals expected.stored_label
        expect(fieldRow.label).toBe(expected.stored_label);
      }

      // Step 7: no duplicate/extra collection was created
      const countResult = await ctx.db
        .selectFrom("_emdash_collections")
        .select(ctx.db.fn.count("id").as("count"))
        .executeTakeFirstOrThrow();
      const count = Number(countResult.count);
      // EXPECTED: count equals expected.collection_count_after
      expect(count).toBe(expected.collection_count_after);
    } finally {
      await teardownForDialect(ctx);
    }
  });
});
