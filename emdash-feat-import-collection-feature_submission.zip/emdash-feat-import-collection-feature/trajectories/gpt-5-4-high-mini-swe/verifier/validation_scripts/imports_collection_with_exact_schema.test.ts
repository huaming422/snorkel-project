// @ts-nocheck
import { describe, it, expect } from "vitest";
import {
  setupForDialect,
  teardownForDialect,
  collectionFixture,
  collectionShape,
  activateMediaUsageCapture,
} from "./jest_test_harness.js";
import { importPortableSchema } from "../../../../../src/transfer/import/schema.js";
import { getTestCases } from "./validationParams";

/**
 * Adapter: wraps importPortableSchema (which returns void) and computes
 * { created, fieldsCreated } by diffing the DB state before/after.
 */
async function runImport(db, record, fields) {
  const beforeCollection = await db
    .selectFrom("_emdash_collections")
    .select("id")
    .where("id", "=", record.id)
    .executeTakeFirst();
  const collectionExisted = !!beforeCollection;

  const beforeFieldIds = new Set(
    (
      await db
        .selectFrom("_emdash_fields")
        .select("id")
        .where("collection_id", "=", record.id)
        .execute()
    ).map((r) => r.id),
  );

  await importPortableSchema(db, { collections: [record], fields });

  const afterFieldIds = (
    await db
      .selectFrom("_emdash_fields")
      .select("id")
      .where("collection_id", "=", record.id)
      .execute()
  ).map((r) => r.id);

  const fieldsCreated = afterFieldIds.filter((id) => !beforeFieldIds.has(id)).length;

  return {
    created: !collectionExisted,
    fieldsCreated,
  };
}

describe("imports_collection_with_exact_schema", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    const ctx = await setupForDialect("sqlite");
    try {
      // Step 2: optionally activate media usage capture
      if (inputs.capture_active) {
        await activateMediaUsageCapture(ctx.db, { writersDrained: true });
      }

      // Step 3: build fixture
      const fixture = collectionFixture(inputs.fixture_n);

      // Step 4: run import
      const result = await runImport(ctx.db, fixture.record, fixture.fields);

      // Step 5: EXPECTED: result.created === expected.created
      expect(result.created).toBe(expected.created);

      // Step 6: EXPECTED: result.fieldsCreated === expected.field_count
      expect(result.fieldsCreated).toBe(expected.field_count);

      // Step 7: read stored collection row directly
      const collection = await ctx.db
        .selectFrom("_emdash_collections")
        .selectAll()
        .where("slug", "=", fixture.record.slug)
        .executeTakeFirstOrThrow();

      // EXPECTED: collection.id === fixture.record.id
      expect(collection.id).toBe(fixture.record.id);

      // EXPECTED: JSON.parse(collection.search_config).enabled === expected.search_enabled (false)
      // Guard against null search_config to produce a clear failure rather than a TypeError
      expect(collection.search_config).not.toBeNull();
      expect(JSON.parse(collection.search_config).enabled).toBe(expected.search_enabled);

      // Step 8: read stored field rows
      const storedFields = await ctx.db
        .selectFrom("_emdash_fields")
        .select(["id", "slug"])
        .where("collection_id", "=", fixture.record.id)
        .orderBy("sort_order")
        .execute();

      // EXPECTED: fields.map(f => f.id) equals fixture.fields.map(f => f.id) (exact field ids, in order)
      expect(storedFields.map((f) => f.id)).toEqual(fixture.fields.map((f) => f.id));

      // Step 9: snapshot the schema shape
      const shape = await collectionShape(ctx.db, fixture);

      // EXPECTED: shape.columns.map(c => c.split(":")[0]) contains every entry of expected.required_columns
      const columnNames = shape.columns.map((c) => c.split(":")[0]);
      for (const col of expected.required_columns) {
        expect(columnNames).toContain(col);
      }

      // EXPECTED: shape.indexes contains every entry of expected.required_indexes
      for (const idx of expected.required_indexes) {
        expect(shape.indexes).toContain(idx);
      }

      // EXPECTED: shape.triggers === expected.expect_triggers
      expect(shape.triggers).toBe(expected.expect_triggers);
    } finally {
      await teardownForDialect(ctx);
    }
  });
});
