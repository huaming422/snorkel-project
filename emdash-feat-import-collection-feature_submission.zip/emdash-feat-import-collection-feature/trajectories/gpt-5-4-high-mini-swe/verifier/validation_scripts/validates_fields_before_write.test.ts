// @ts-nocheck
import { describe, it, expect } from "vitest";
import {
  setupForDialect,
  teardownForDialect,
  collectionFixture,
} from "./jest_test_harness.js";
import { importPortableSchema } from "../../../../../src/transfer/import/schema.js";
import { getTestCases } from "./validationParams";

/**
 * Adapter: wraps importPortableSchema (returns void) and computes
 * { created, fieldsCreated } by diffing the DB state before/after.
 */
async function runImport(db, record, fields) {
  const beforeCollection = await db
    .selectFrom("_emdash_collections")
    .select("id")
    .where("id", "=", record.id)
    .executeTakeFirst();
  const collectionExisted = !!beforeCollection;

  const beforeFieldIds = new Set(
    (
      await db
        .selectFrom("_emdash_fields")
        .select("id")
        .where("collection_id", "=", record.id)
        .execute()
    ).map((r) => r.id),
  );

  await importPortableSchema(db, { collections: [record], fields });

  const afterFieldIds = (
    await db
      .selectFrom("_emdash_fields")
      .select("id")
      .where("collection_id", "=", record.id)
      .execute()
  ).map((r) => r.id);

  const fieldsCreated = afterFieldIds.filter((id) => !beforeFieldIds.has(id)).length;

  return {
    created: !collectionExisted,
    fieldsCreated,
  };
}

describe("validates_fields_before_write", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    const ctx = await setupForDialect("sqlite");
    try {
      // Step 2: import a valid baseline collection first
      const base = collectionFixture(inputs.base_n);
      const ok = await runImport(ctx.db, base.record, base.fields);

      // EXPECTED: ok.created === true and ok.fieldsCreated === expected.field_count
      expect(ok.created).toBe(true);
      expect(ok.fieldsCreated).toBe(expected.field_count);

      // Step 3: construct the bad import
      let badRecord;
      let badFields;

      if (inputs.mode === "field_type_mismatch") {
        const bad = collectionFixture(inputs.bad_n);
        // corrupt its first field so its declared column type contradicts its field type
        // first field is a "string"/"TEXT" field, so "INTEGER" is a contradiction
        badFields = [{ ...bad.fields[0], columnType: "INTEGER" }, ...bad.fields.slice(1)];
        badRecord = bad.record;
      } else if (inputs.mode === "slug_collision") {
        const bad = collectionFixture(inputs.bad_n);
        // force slug to collide with the baseline
        badRecord = { ...bad.record, slug: base.record.slug };
        badFields = bad.fields;
      }

      // Step 4: attempt the bad import and assert it is REJECTED
      await expect(runImport(ctx.db, badRecord, badFields)).rejects.toBeTruthy();

      // Step 5: nothing partial was left behind

      // EXPECTED: number of rows in _emdash_collections equals expected.collection_count_after
      const countResult = await ctx.db
        .selectFrom("_emdash_collections")
        .select(ctx.db.fn.count("id").as("count"))
        .executeTakeFirstOrThrow();
      const count = Number(countResult.count);
      expect(count).toBe(expected.collection_count_after);

      if (inputs.mode === "field_type_mismatch") {
        const bad = collectionFixture(inputs.bad_n);
        // bad collection's id is absent
        const found = await ctx.db
          .selectFrom("_emdash_collections")
          .select("id")
          .where("id", "=", bad.record.id)
          .executeTakeFirst();
        expect(found).toBeUndefined();
      } else if (inputs.mode === "slug_collision") {
        // baseline collection still owns the slug
        const row = await ctx.db
          .selectFrom("_emdash_collections")
          .select("id")
          .where("slug", "=", base.record.slug)
          .executeTakeFirst();
        expect(row?.id).toBe(base.record.id);
      }

      // EXPECTED: expected.surviving_slug equals the slug of the single surviving _emdash_collections row
      const survivor = await ctx.db
        .selectFrom("_emdash_collections")
        .select("slug")
        .executeTakeFirstOrThrow();
      expect(survivor.slug).toBe(expected.surviving_slug);
    } finally {
      await teardownForDialect(ctx);
    }
  });
});
