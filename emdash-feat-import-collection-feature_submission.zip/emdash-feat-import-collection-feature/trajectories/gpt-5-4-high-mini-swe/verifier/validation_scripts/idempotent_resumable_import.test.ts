// @ts-nocheck
import { describe, it, expect } from "vitest";
import {
  setupForDialect,
  teardownForDialect,
  collectionFixture,
  collectionShape,
  withFaults,
} from "./jest_test_harness.js";
import { importPortableSchema } from "../../../../../src/transfer/import/schema.js";
import { getTestCases } from "./validationParams";

/**
 * Adapter: wraps importPortableSchema (returns void) and computes
 * { created, fieldsCreated } by diffing the DB state before/after.
 */
async function runImport(db, record, fields) {
  const beforeCollection = await db
    .selectFrom("_emdash_collections")
    .select("id")
    .where("id", "=", record.id)
    .executeTakeFirst();
  const collectionExisted = !!beforeCollection;

  const beforeFieldIds = new Set(
    (
      await db
        .selectFrom("_emdash_fields")
        .select("id")
        .where("collection_id", "=", record.id)
        .execute()
    ).map((r) => r.id),
  );

  await importPortableSchema(db, { collections: [record], fields });

  const afterFieldIds = (
    await db
      .selectFrom("_emdash_fields")
      .select("id")
      .where("collection_id", "=", record.id)
      .execute()
  ).map((r) => r.id);

  const fieldsCreated = afterFieldIds.filter((id) => !beforeFieldIds.has(id)).length;

  return {
    created: !collectionExisted,
    fieldsCreated,
  };
}

describe("idempotent_resumable_import", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    if (inputs.mode === "noop_on_repeat") {
      const ctx = await setupForDialect("sqlite");
      try {
        const fixture = collectionFixture(inputs.fixture_n);

        // First import
        await runImport(ctx.db, fixture.record, fixture.fields);

        const before = await collectionShape(ctx.db, fixture);

        // Second import
        const again = await runImport(ctx.db, fixture.record, fixture.fields);

        // EXPECTED: again.created === expected.second_created (false)
        expect(again.created).toBe(expected.second_created);

        // EXPECTED: again.fieldsCreated === expected.second_field_count (0)
        expect(again.fieldsCreated).toBe(expected.second_field_count);

        // EXPECTED: collectionShape deep-equals before
        const after = await collectionShape(ctx.db, fixture);
        expect(after).toEqual(before);
      } finally {
        await teardownForDialect(ctx);
      }
    } else if (inputs.mode === "resume_after_crash") {
      const ctx = await setupForDialect("sqlite");
      try {
        // Establish reference shape from a clean import (fixture 0)
        const reference = collectionFixture(0);
        await runImport(ctx.db, reference.record, reference.fields);
        const expectedShape = await collectionShape(ctx.db, reference);

        const { db: faultyDb, faults } = withFaults(ctx.db);

        let crashes = 0;

        for (let n = 1; ; n++) {
          const fixture = collectionFixture(n);
          faults.failAfter(n);

          let didCrash = false;
          try {
            await runImport(faultyDb, fixture.record, fixture.fields);
            // Capture crashed state BEFORE disarming (disarm() resets #dead)
            const crashed = faults.crashed;
            faults.disarm();
            if (!crashed) break;
            // Non-throwing crash path: crashed is true but no exception was thrown
            didCrash = true;
          } catch (error) {
            // Throwing crash path
            faults.disarm();
            expect(error.message).toContain("injected crash");
            didCrash = true;
          }

          // Increment crash counter for both throwing and non-throwing crash paths
          if (didCrash) {
            crashes++;
          }

          // Resume against the un-faulted db
          await runImport(ctx.db, fixture.record, fixture.fields);

          // EXPECTED: shape matches clean import after resume
          const resumedShape = await collectionShape(ctx.db, fixture);
          expect(resumedShape).toEqual(expectedShape);
        }

        // EXPECTED: crashes > expected.min_crashes
        expect(crashes).toBeGreaterThan(expected.min_crashes);
      } finally {
        await teardownForDialect(ctx);
      }
    } else if (inputs.mode === "within_d1_budget") {
      const ctx = await setupForDialect("sqlite");
      try {
        const { db: faultyDb, faults } = withFaults(ctx.db);

        // Import a narrow collection (fixture index 3) and record statement count
        // collectionFixture(3) uses slug "imported_3" and its own unique ids
        const narrow = collectionFixture(3);
        await runImport(faultyDb, narrow.record, narrow.fields);
        const narrowStatements = faults.executed;

        // Import a wide collection (fixture index 4, distinct from 3) and measure added statements
        // collectionFixture(4) uses slug "imported_4" and its own unique ids — no collision
        const wide = collectionFixture(4, inputs.extra_fields);
        const before = faults.executed;
        await runImport(faultyDb, wide.record, wide.fields);
        const wideStatements = faults.executed - before;

        // EXPECTED: faults.maxParameters <= expected.max_parameters
        expect(faults.maxParameters).toBeLessThanOrEqual(expected.max_parameters);

        // EXPECTED: narrowStatements <= expected.max_narrow_statements
        expect(narrowStatements).toBeLessThanOrEqual(expected.max_narrow_statements);

        // EXPECTED: wideStatements <= narrowStatements + expected.wide_statement_slack
        expect(wideStatements).toBeLessThanOrEqual(narrowStatements + expected.wide_statement_slack);
      } finally {
        await teardownForDialect(ctx);
      }
    }
  });
});
