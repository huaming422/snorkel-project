// @ts-nocheck
/**
 * Shared plumbing for the collection-import validation stories.
 *
 * The validation driver copies this file next to each generated story test
 * (into the `__validation__` directory under the configured test parent), so
 * the stories can import it as `./jest_test_harness.js`. Everything here is
 * framework plumbing — a query interceptor that counts statements and can
 * simulate a crash, a builder for the portable record/field inputs, a reader
 * that snapshots the stored shape of a materialized collection, and
 * re-exports of the repo's own per-dialect database setup. None of it touches
 * the code under test: the story bodies discover and drive that themselves.
 *
 * Relative specifiers assume this file runs from
 *   packages/core/tests/integration/transfer/import/__validation__/
 * which is where the driver places it.
 */

import { sql } from "kysely";

import { isPostgres, listTableColumns } from "../../../../../src/database/dialect-helpers.js";
import { verifyMediaUsageCaptureTriggers } from "../../../../../src/media/usage/capture-triggers.js";

export {
	describeEachDialect,
	setupForDialect,
	teardownForDialect,
} from "../../../../utils/test-db.js";
export { activateMediaUsageCapture } from "../../../../../src/media/usage/activation.js";
export { fixtureId } from "../../../../utils/transfer/golden-package.js";

import { fixtureId } from "../../../../utils/transfer/golden-package.js";

const T0 = "2026-01-01T00:00:00.000Z";

/**
 * A posts-like collection record plus its field records, carrying their own
 * ids and slug for fixture number `n`. The shape mirrors the pre-existing
 * portable `CollectionRecord` / `FieldRecord` package format (defined in
 * `src/transfer/format/kinds.ts`) — the input an import consumes, not
 * anything the solution defines. `searchConfig.enabled` is deliberately
 * `true` so a correct import can be seen forcing it off.
 */
export function collectionFixture(n, extraFields = 0) {
	const base = 10_000 + n * 1000;
	const id = fixtureId(base);
	const record = {
		kind: "collection",
		id,
		slug: `imported_${n}`,
		label: "Imported",
		labelSingular: "Imported",
		supports: ["drafts", "revisions", "search"],
		source: "manual",
		searchConfig: { enabled: true, weights: { title: 5 } },
		hasSeo: true,
		urlPattern: "/imported/{slug}",
		commentsEnabled: true,
		commentsModeration: "all",
		commentsClosedAfterDays: 30,
		commentsAutoApproveUsers: false,
		hidden: false,
		sortOrder: 3,
		adminConfig: { listColumns: ["title"] },
		titleField: "title",
		dateField: "published_at",
		routable: true,
		editLocking: false,
		navGroup: "Imports",
		createdAt: T0,
		updatedAt: T0,
	};
	const field = (offset, slug, type, columnType, extra = {}) => ({
		kind: "field",
		id: fixtureId(base + offset),
		collectionId: id,
		slug,
		label: slug,
		type,
		columnType,
		required: false,
		unique: false,
		sortOrder: offset,
		searchable: false,
		translatable: true,
		indexed: false,
		createdAt: T0,
		...extra,
	});
	const fields = [
		field(1, "title", "string", "TEXT", { required: true, searchable: true, indexed: true }),
		field(2, "content", "portableText", "JSON", { searchable: true }),
		field(3, "rating", "number", "REAL", { required: true, defaultValue: 2.5 }),
		field(4, "related", "reference", "TEXT", { indexed: true, options: { collection: "pages" } }),
	];
	for (let index = 0; index < extraFields; index++) {
		fields.push(field(10 + index, `extra_${index}`, "string", "TEXT"));
	}
	return { record, fields };
}

async function indexNames(db, table) {
	const rows = isPostgres(db)
		? await sql`
				SELECT indexname AS name FROM pg_indexes
				WHERE schemaname = current_schema() AND tablename = ${table}
			`.execute(db)
		: await sql`
				SELECT name FROM sqlite_master WHERE type = 'index' AND tbl_name = ${table}
			`.execute(db);
	return rows.rows.map((row) => row.name).filter((name) => !name.startsWith("sqlite_autoindex"));
}

/**
 * Snapshot the stored shape of an imported collection, with its slug and
 * field ids abstracted away so two fixtures with different numbers compare
 * equal when their schema shape matches. Reads only the pre-existing tables
 * `_emdash_collections`, `_emdash_fields`, `_emdash_media_usage_index_status`
 * and the collection's own `ec_<slug>` content table.
 */
export async function collectionShape(db, fixture) {
	const { record, fields } = fixture;
	const table = `ec_${record.slug}`;
	const normalize = (value) => {
		let text = value.replaceAll(record.slug, "<slug>").replaceAll(record.id, "<id>");
		for (const field of fields) text = text.replaceAll(field.id.toLowerCase(), `<${field.slug}>`);
		for (const field of fields) text = text.replaceAll(field.id, `<${field.slug}>`);
		return text;
	};
	const collection = await db
		.selectFrom("_emdash_collections")
		.selectAll()
		.where("id", "=", record.id)
		.executeTakeFirst();
	const storedFields = await db
		.selectFrom("_emdash_fields")
		.selectAll()
		.where("collection_id", "=", record.id)
		.orderBy("sort_order")
		.execute();
	const lifecycle = await db
		.selectFrom("_emdash_media_usage_index_status")
		.select(["collection_id", "capture_state", "cursor"])
		.where("scope_key", "=", record.slug)
		.executeTakeFirst();
	return {
		collection: collection ? normalize(JSON.stringify(collection)) : null,
		fields: storedFields.map((row) => normalize(JSON.stringify(row))),
		columns: (await listTableColumns(db, table)).map((column) => `${column.name}:${column.type}`),
		indexes: (await indexNames(db, table)).map(normalize).toSorted(),
		lifecycle: lifecycle ? normalize(JSON.stringify(lifecycle)) : null,
		triggers: await verifyMediaUsageCaptureTriggers(db, {
			collectionId: record.id,
			collectionSlug: record.slug,
		}),
	};
}

/**
 * Counts every executed statement and can simulate a crash: once armed with
 * `failAfter(n)`, the nth statement from now (and every later one) throws
 * "injected crash" until `disarm()`, so an import that swallows one error
 * cannot quietly carry on. Also records the largest bind-parameter count seen
 * on any single statement.
 */
export class FaultPlugin {
	executed = 0;
	maxParameters = 0;
	#failAfter = null;
	#dead = false;
	#compile = null;

	bindCompiler(db) {
		const executor = db.getExecutor();
		this.#compile = (node) => executor.compileQuery(node, { queryId: "fault" }).parameters.length;
	}

	/** Crash after the `n`th statement from now executes. */
	failAfter(n) {
		this.#failAfter = this.executed + n;
	}

	get crashed() {
		return this.#dead;
	}

	disarm() {
		this.#failAfter = null;
		this.#dead = false;
	}

	transformQuery(args) {
		if (this.#dead) throw new Error("injected crash");
		if (this.#compile) {
			this.maxParameters = Math.max(this.maxParameters, this.#compile(args.node));
		}
		return args.node;
	}

	async transformResult(args) {
		this.executed++;
		if (this.#failAfter !== null && this.executed >= this.#failAfter) {
			this.#failAfter = null;
			this.#dead = true;
			throw new Error("injected crash");
		}
		return args.result;
	}
}

/** Wrap a Kysely instance with a {@link FaultPlugin}; returns both. */
export function withFaults(db) {
	const faults = new FaultPlugin();
	const faulty = db.withPlugin(faults);
	faults.bindCompiler(db);
	return { db: faulty, faults };
}
