#!/usr/bin/env bash
# Environment bootstrap for the validation story scripts. Idempotent.
#
# The @emdash-cms/core vitest config resolves the package's own sources via the
# dev-source condition, so the integration tests under packages/core/tests run
# directly against packages/core/src — the solving author's edits are picked up
# from source with no prebuilt dist required. We therefore do NOT force a dist
# rebuild (that would be the wrong signal here); we only restore deps if an
# agent wiped them and build core defensively so any consumer that needs built
# artifacts still resolves, mirroring tests/test-setup.sh.

set -e

REPO_DIR="${REPO_DIR:-/repo/emdash}"
cd "$REPO_DIR"

# Sanity: the pinned toolchain is reachable. A missing runner is a loud setup
# failure, not a silently-skipped story.
node --version
pnpm --version
npx vitest --version

# Restore workspace deps if missing. The image bakes the full closure into the
# pnpm store at the base commit, so this is an offline no-op on a clean image;
# the online fallback only matters if an agent wiped node_modules.
if [ ! -d "node_modules/.pnpm" ]; then
    echo "[validation-setup] pnpm install (offline, frozen)..."
    if ! pnpm install --frozen-lockfile --offline > /tmp/validation-setup-install.log 2>&1; then
        echo "[validation-setup] offline install failed; retrying online..." >&2
        pnpm install --frozen-lockfile > /tmp/validation-setup-install.log 2>&1 \
            || { tail -60 /tmp/validation-setup-install.log >&2; exit 1; }
    fi
    tail -5 /tmp/validation-setup-install.log || true
fi

# Build @emdash-cms/core defensively (cheap on a tsdown incremental cache). The
# stories read source directly, so a failed optional build must not block them.
echo "[validation-setup] ensuring @emdash-cms/core is buildable (source-tested)..."
pnpm --filter @emdash-cms/core build > /tmp/validation-setup-build.log 2>&1 \
    || { echo "[validation-setup] core build skipped/failed (tests read source):" >&2; tail -20 /tmp/validation-setup-build.log >&2 || true; }

# Make workspace binaries available.
export PATH="$REPO_DIR/node_modules/.bin:$PATH"

# Loud smoke guard: the per-dialect setup these stories rely on must import and
# the vitest config must load. If this fails, fail setup rather than letting
# every story report a confusing "cannot find module".
if [ ! -f "packages/core/tests/utils/test-db.ts" ]; then
    echo "[validation-setup] FATAL: packages/core/tests/utils/test-db.ts missing" >&2
    exit 1
fi
if [ ! -f "packages/core/vitest.config.ts" ]; then
    echo "[validation-setup] FATAL: packages/core/vitest.config.ts missing" >&2
    exit 1
fi

echo "[validation-setup] ready: $REPO_DIR (node=$(node --version), pnpm=$(pnpm --version))"
