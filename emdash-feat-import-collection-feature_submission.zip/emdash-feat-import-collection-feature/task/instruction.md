## Task

EmDash is building a site-transfer feature: a whole site can be exported into a
portable package and later imported into a fresh target database, so a site can
be moved or cloned between environments. We're working on the import side, and
this is one step of it.

Build the step that stands up a site's schema in the target database from a
portable package. The package carries the collection and field definitions the
source site had; recreate them so the imported site comes up with the schema the
source defined: the collections, their fields, and the backing content table
each collection needs.

The target database may be Cloudflare D1, which has no multi-statement
transactions, so the step can't lean on a surrounding transaction to hold itself
together. D1 also caps the number of parameters each statement can bind and the
total number of statements per request, so multi-row writes must be split into
batches that stay within those limits.

Only the schema-writing step is in scope: the collections, their fields, each
collection's backing content table, and the system hooks each collection
registers on creation. Exporting a site, analyzing a package, and importing
content entries or media files live elsewhere in the transfer feature.

## User stories / requirements

- Importing a package into a fresh target database brings up exactly the collections and fields the package recorded, keeping the same ids, slugs, labels, column definitions, and ordering rather than minting new ones, creates each collection's backing content table, and registers the collection's system hooks. The imported collections come up with search left disabled.
- Running the import again after it has already finished changes nothing in the target. If a run is cut short partway through, running it again finishes the import and lands on the same final state an uninterrupted run would have reached. Each write stays within D1's per-statement parameter limit and the total number of statements per request.
- When the target already holds a collection or field whose stored definition does not match what the package carries, the import refuses to proceed instead of overwriting it or quietly accepting the difference.
- Before anything is written, the import checks the incoming collection and field definitions and refuses malformed input, or ids and slugs that collide with what is already in the target, leaving the database untouched when it refuses.
