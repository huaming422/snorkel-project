## Task

We want `mise run` to emit OpenTelemetry for the tasks it runs, so teams running mise in CI and on their own machines get the same traces and logs they already get from the rest of their toolchain. Today mise exports nothing for a task run, so this is net-new work.

Make it two independent switches, both off by default. One turns on trace export for a run; a separate one exports the tasks' stdout and stderr as log records. With neither enabled, nothing leaves the machine and task output passes through untouched. Trace export also needs an OTLP endpoint to be configured before anything goes out. Export is OTLP over HTTP and follows the OpenTelemetry spec's standard `OTEL_*` configuration and its protocol defaults.

Task execution itself stays as it is; this only adds export around the run. Everything you need is already in the image. The repo's `e2e/run_test` harness runs the compiled binary in isolation and is a good way to exercise this against a small local OTLP receiver.

## User stories / requirements

- With a trace endpoint configured but trace export left off, running tasks sends nothing to it. Task output is likewise exported only when the separate log-export switch is on; with it off, no log records leave the machine even while traces are flowing.
- With trace export on, a single `mise run` produces one trace: a root span for the whole run, a span covering the tool setup and install phase, and one span per task, each parented under the run span.
- When a task's command runs another `mise run`, the nested run joins the same trace as the outer one instead of starting its own, and its span sits under the task that launched it.
- When one task fails and mise stops the others, the task that actually failed is recorded as an error carrying its process exit code, while a sibling that mise stopped is recorded as succeeded but cancelled rather than failed. The run as a whole is recorded as an error.
- With log export on, every line a task prints is exported exactly once as a log record tied to the task that printed it, including output from a nested run that surfaces through the outer task.
