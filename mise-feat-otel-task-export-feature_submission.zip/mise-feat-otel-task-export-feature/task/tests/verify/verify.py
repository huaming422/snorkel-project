"""Behavioral verifier for mise-feat-otel-task-export.

Criterion (task.toml, level = behavioral_verifier, pass_to_pass):
    `compiles_clean` — the full workspace, including the `mise` crate with the
    new feature, builds `--locked` under the pinned toolchain with the committed
    lockfile, and the pre-existing test suite still compiles. The feature must
    not regress default behaviour.

This tests through the *build/test interface* only. It never imports or names any
module, type, or function the solution introduces (an `otel` module, a forwarder,
a claim protocol — all of which a valid alternative may structure or rename
freely). It asserts the two facts every correct solution must satisfy:

  1. `cargo build --locked --tests --workspace` succeeds — the new dependency
     closure resolves against the committed lockfile and the whole workspace
     (mise included) compiles offline, test binaries and all.
  2. A pre-existing, OTel-unrelated unit test still passes — proving the feature
     did not regress the baseline. We run one small, fast, long-standing test
     target by name rather than the entire suite (the full e2e suite is covered
     by the validation stories and would blow the verifier budget).

On the pre-fix / unchanged tree step 1 still succeeds (base compiles), so this is a
regression guard: it protects against a submission that breaks the build or the
lockfile, not a check that targets the feature itself (the validation stories cover
the feature behavior directly).
"""

import os
import subprocess

RUST_DIR = os.environ.get("MISE_REPO_DIR", "/repo/mise")

# cargo lives under /opt/cargo/bin in the image; ensure it is on PATH regardless
# of the shell the verifier runner used. Pin the baked toolchain + target dir.
_ENV = {
    **os.environ,
    "PATH": "/opt/cargo/bin:" + os.environ.get("PATH", ""),
    "CARGO_TARGET_DIR": os.environ.get("CARGO_TARGET_DIR", "/opt/cache/cargo-target"),
}


def _tail(proc, n=3000):
    return (proc.stdout[-n:] + "\n" + proc.stderr[-n:]).strip()


def test_workspace_builds_locked():
    """`cargo build --locked --tests --workspace` returns 0 (offline closure)."""
    assert os.path.isdir(RUST_DIR), f"repo workspace missing at {RUST_DIR}"

    proc = subprocess.run(
        ["cargo", "build", "--locked", "--tests", "--workspace"],
        cwd=RUST_DIR,
        env=_ENV,
        capture_output=True,
        text=True,
        timeout=1100,
    )
    assert proc.returncode == 0, (
        "cargo build --locked --tests --workspace failed "
        f"(exit {proc.returncode}). The workspace (mise crate included) must "
        "compile offline against the committed lockfile with the new dependency "
        "closure, test binaries and all.\n\n" + _tail(proc)
    )


def test_baseline_behaviour_not_regressed():
    """A pre-existing, OTel-unrelated unit test still passes.

    `config::settings` is a long-standing module with fast, self-contained unit
    tests present at the task base commit (before any otel work). Running it by
    path proves the feature did not break the baseline, without the cost of the
    whole suite. If the solution reorganised modules such that this exact filter
    matches nothing, cargo exits 0 having run zero tests — still a non-failure,
    which is the correct pass_to_pass signal (we are guarding against regressions,
    not asserting a particular module layout)."""
    proc = subprocess.run(
        ["cargo", "test", "--locked", "--bin", "mise", "config::settings", "--",
         "--test-threads", "1"],
        cwd=RUST_DIR,
        env=_ENV,
        capture_output=True,
        text=True,
        timeout=400,
    )
    assert proc.returncode == 0, (
        "pre-existing baseline tests regressed "
        f"(exit {proc.returncode}).\n\n" + _tail(proc)
    )
