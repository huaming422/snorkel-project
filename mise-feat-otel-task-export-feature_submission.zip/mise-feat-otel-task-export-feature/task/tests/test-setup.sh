#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# No services to start and no data to seed: the image bakes the full dependency
# closure at the base commit PLUS the oracle's new opentelemetry 0.33 crates
# (Dockerfile block 5b), so builds and the e2e stories run fully offline.
set -euo pipefail

# Make a cargo cache miss fail fast instead of hanging on a dead network during
# the offline agent/verifier phases. Scoped to this task's own cargo invocations.
export CARGO_NET_OFFLINE=true

echo "[test-setup] Rust:      $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo:     $(cargo --version 2>&1 | head -1)"
echo "[test-setup] python3:   $(python3 --version 2>&1 | head -1)"
echo "[test-setup] Repo root: /repo/mise"
echo "[test-setup] Setup complete."
