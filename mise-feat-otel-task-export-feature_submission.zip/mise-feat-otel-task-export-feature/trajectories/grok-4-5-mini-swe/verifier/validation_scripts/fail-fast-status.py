import sys
sys.path.insert(0, "/tests/validate")
from test_harness import OtlpCollector, run_mise

# Discovered from the implementation:
# - Trace opt-in env: MISE_TASK_OTEL_TRACES=1
# - Task span name: starts with "task " and has attribute mise.task.name
# - Exit code attribute: "mise.task.exit_code"
# - Cancellation attribute: "mise.task.cancelled" = True

TRACE_OPT_IN = "MISE_TASK_OTEL_TRACES"
ATTR_EXIT_CODE = "mise.task.exit_code"
ATTR_CANCELLED = "mise.task.cancelled"


def is_task_span(span):
    """Return True if this span represents an individual task."""
    return span["name"].startswith("task ")


def task_name_of(span):
    """Return the fixture task name this span represents."""
    attrs = span.get("attributes", {})
    if "mise.task.name" in attrs:
        return attrs["mise.task.name"]
    name = span["name"]
    if name.startswith("task "):
        return name[len("task "):]
    return None


def find_task_span(all_spans, task_name):
    """Find the span for a specific fixture task."""
    for s in all_spans:
        if is_task_span(s) and task_name_of(s) == task_name:
            return s
    return None


def test_fail_fast_status(inputs, expected):
    """Test fail-fast task status recording."""
    env = {TRACE_OPT_IN: "1"}

    with OtlpCollector() as col:
        proc = run_mise(inputs["task"], col, env=env, timeout=90)
        run_failed = 1 if proc.returncode != 0 else 0

        roots = col.root_spans()
        root_status = roots[0]["status_code"] if roots else -1

        all_spans = col.spans()

        # Find the failing task span
        failed_span = find_task_span(all_spans, inputs["failed_task"])
        if failed_span is not None:
            failed_task_status = failed_span["status_code"]
            ec = failed_span.get("attributes", {}).get(ATTR_EXIT_CODE)
            failed_task_exit_code = int(ec) if ec is not None else -1
        else:
            failed_task_status = -1
            failed_task_exit_code = -1

        # Find the sibling (stopped/cancelled) task span
        sibling_span = find_task_span(all_spans, inputs["sibling_task"])
        if sibling_span is not None:
            sibling_is_error = 1 if sibling_span["status_code"] == 2 else 0
            cancelled_val = sibling_span.get("attributes", {}).get(ATTR_CANCELLED)
            sibling_cancel_marked = 1 if cancelled_val else 0
        else:
            sibling_is_error = -1
            sibling_cancel_marked = 0

    assert run_failed == expected["run_failed"], (
        f"Expected run_failed={expected['run_failed']}, got {run_failed}"
    )
    assert root_status == expected["root_status"], (
        f"Expected root_status={expected['root_status']}, got {root_status}"
    )
    assert failed_task_status == expected["failed_task_status"], (
        f"Expected failed_task_status={expected['failed_task_status']}, got {failed_task_status}"
    )
    assert failed_task_exit_code == expected["failed_task_exit_code"], (
        f"Expected failed_task_exit_code={expected['failed_task_exit_code']}, got {failed_task_exit_code}"
    )
    assert sibling_is_error == expected["sibling_is_error"], (
        f"Expected sibling_is_error={expected['sibling_is_error']}, got {sibling_is_error}"
    )
    assert sibling_cancel_marked == expected["sibling_cancel_marked"], (
        f"Expected sibling_cancel_marked={expected['sibling_cancel_marked']}, got {sibling_cancel_marked}"
    )

    return {
        "run_failed": run_failed,
        "root_status": root_status,
        "failed_task_status": failed_task_status,
        "failed_task_exit_code": failed_task_exit_code,
        "sibling_is_error": sibling_is_error,
        "sibling_cancel_marked": sibling_cancel_marked,
    }
