import sys
sys.path.insert(0, "/tests/validate")
from test_harness import OtlpCollector, run_mise

# Discovered from the implementation:
# - Trace opt-in env: MISE_TASK_OTEL_TRACES=1
# - Log opt-in env:   MISE_TASK_OTEL_LOGS=1
# - Task span name: starts with "task " and has attribute mise.task.name

TRACE_OPT_IN = "MISE_TASK_OTEL_TRACES"
LOG_OPT_IN = "MISE_TASK_OTEL_LOGS"


def is_task_span(span):
    """Return True if this span represents an individual task."""
    return span["name"].startswith("task ")


def task_name_of(span):
    """Return the fixture task name this span represents."""
    attrs = span.get("attributes", {})
    if "mise.task.name" in attrs:
        return attrs["mise.task.name"]
    name = span["name"]
    if name.startswith("task "):
        return name[len("task "):]
    return None


def test_logs_once(inputs, expected):
    """Test that each output line is exported exactly once and attributed correctly."""
    env = {TRACE_OPT_IN: "1", LOG_OPT_IN: "1"}

    with OtlpCollector() as col:
        run_mise(inputs["task"], col, env=env)

        logs = col.log_records()
        bodies = [l["body"] for l in logs]
        from_inner_count = bodies.count("from-inner")

        # Build a map from span_id -> fixture task name
        all_spans = col.spans()
        span_id_to_task = {}
        for s in all_spans:
            if is_task_span(s):
                name = task_name_of(s)
                if name is not None:
                    span_id_to_task[s["span_id"]] = name

        attribution = inputs["attribution"]

        # Check exactly-once per known line and correct attribution
        all_once = True
        correctly_attributed = 0
        for line, task_name in attribution.items():
            count = bodies.count(line)
            if count != 1:
                all_once = False

            # Find the log record with this body
            matching = [l for l in logs if l["body"] == line]
            if matching:
                log_record = matching[0]
                span_id = log_record.get("span_id", "")
                owner_task = span_id_to_task.get(span_id)
                if owner_task == task_name:
                    correctly_attributed += 1

        each_known_line_once = 1 if all_once else 0

    assert from_inner_count == expected["from_inner_count"], (
        f"Expected from_inner_count={expected['from_inner_count']}, got {from_inner_count}"
    )
    assert each_known_line_once == expected["each_known_line_once"], (
        f"Expected each_known_line_once={expected['each_known_line_once']}, got {each_known_line_once}"
    )
    assert correctly_attributed == expected["correctly_attributed"], (
        f"Expected correctly_attributed={expected['correctly_attributed']}, got {correctly_attributed}"
    )

    return {
        "from_inner_count": from_inner_count,
        "each_known_line_once": each_known_line_once,
        "correctly_attributed": correctly_attributed,
    }
