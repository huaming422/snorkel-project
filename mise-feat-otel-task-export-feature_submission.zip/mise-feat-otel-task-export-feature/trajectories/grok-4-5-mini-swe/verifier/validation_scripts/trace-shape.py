import sys
sys.path.insert(0, "/tests/validate")
from test_harness import OtlpCollector, run_mise

# Discovered from the implementation:
# - Trace opt-in env: MISE_TASK_OTEL_TRACES=1
# - Root span name: starts with "mise run "
# - Setup span name: "tool setup"
# - Task span name: starts with "task " (and has attribute mise.task.name)

TRACE_OPT_IN = "MISE_TASK_OTEL_TRACES"


def is_setup_span(span):
    """Return True if this span represents the setup/tool-install phase."""
    return span["name"] == "tool setup"


def is_task_span(span):
    """Return True if this span represents an individual task."""
    return span["name"].startswith("task ")


def test_trace_shape(inputs, expected):
    """Test the shape of the exported trace tree."""
    env = {TRACE_OPT_IN: "1"}

    if inputs["protocol"] == "invalid":
        env["OTEL_EXPORTER_OTLP_PROTOCOL"] = "totally-not-a-real-protocol"
    # "default" -> add nothing extra

    with OtlpCollector() as col:
        run_mise(inputs["task"], col, env=env)

        cts = col.content_types("traces")
        ct = cts[0] if cts else ""
        content_type_kind = "json" if "json" in ct else ("protobuf" if "protobuf" in ct else "other")
        trace_signal_received = 1 if col.request_count("traces") >= 1 else 0

        if inputs["parse_tree"]:
            trace_count = len(col.trace_ids())
            roots = col.root_spans()
            root_count = len(roots)

            if not roots:
                setup_phase_present = 0
                task_under_root = -1
            else:
                root = roots[0]
                kids = col.children_of(root["span_id"])
                setup_phase_present = 1 if any(is_setup_span(k) for k in kids) else 0
                task_under_root = sum(1 for k in kids if is_task_span(k))
        else:
            trace_count = "__skip__"
            root_count = "__skip__"
            setup_phase_present = "__skip__"
            task_under_root = "__skip__"

    assert content_type_kind == expected["content_type_kind"], (
        f"Expected content_type_kind={expected['content_type_kind']}, got {content_type_kind}"
    )
    assert trace_signal_received == expected["trace_signal_received"], (
        f"Expected trace_signal_received={expected['trace_signal_received']}, got {trace_signal_received}"
    )

    if expected["trace_count"] != "__skip__":
        assert trace_count == expected["trace_count"], (
            f"Expected trace_count={expected['trace_count']}, got {trace_count}"
        )
    if expected["root_count"] != "__skip__":
        assert root_count == expected["root_count"], (
            f"Expected root_count={expected['root_count']}, got {root_count}"
        )
    if expected["setup_phase_present"] != "__skip__":
        assert setup_phase_present == expected["setup_phase_present"], (
            f"Expected setup_phase_present={expected['setup_phase_present']}, got {setup_phase_present}"
        )
    if expected["task_under_root"] != "__skip__":
        assert task_under_root == expected["task_under_root"], (
            f"Expected task_under_root={expected['task_under_root']}, got {task_under_root}"
        )

    return {
        "content_type_kind": content_type_kind,
        "trace_signal_received": trace_signal_received,
        "trace_count": trace_count,
        "root_count": root_count,
        "setup_phase_present": setup_phase_present,
        "task_under_root": task_under_root,
    }
