import sys
sys.path.insert(0, "/tests/validate")
from test_harness import OtlpCollector, run_mise

# Discovered from the implementation:
# - Trace opt-in env: MISE_TASK_OTEL_TRACES=1
# - Log opt-in env:   MISE_TASK_OTEL_LOGS=1

TRACE_OPT_IN = "MISE_TASK_OTEL_TRACES"
LOG_OPT_IN = "MISE_TASK_OTEL_LOGS"


def test_gating(inputs, expected):
    """Test that trace and log export are independently gated by their opt-ins."""
    env = {}
    if inputs["enable_traces"]:
        env[TRACE_OPT_IN] = "1"
    if inputs["enable_logs"]:
        env[LOG_OPT_IN] = "1"

    with OtlpCollector() as col:
        run_mise(inputs["task"], col, env=env)

        trace_count = len(col.trace_ids())
        log_record_count = len(col.log_records())

    if expected["trace_count"] != "__skip__":
        assert trace_count == expected["trace_count"], (
            f"Expected trace_count={expected['trace_count']}, got {trace_count}"
        )

    assert log_record_count == expected["log_record_count"], (
        f"Expected log_record_count={expected['log_record_count']}, got {log_record_count}"
    )

    return {"trace_count": trace_count, "log_record_count": log_record_count}
