import sys
sys.path.insert(0, "/tests/validate")
from test_harness import OtlpCollector, run_mise

# Discovered from the implementation:
# - Trace opt-in env: MISE_TASK_OTEL_TRACES=1
# - Root span name: starts with "mise run "
# - Task span name: starts with "task " and has attribute mise.task.name
# - Setup span name: "tool setup"

TRACE_OPT_IN = "MISE_TASK_OTEL_TRACES"

# Root sentinel values (empty parent = no parent)
_ROOT_PARENTS = {"", "0000000000000000", "00000000000000000000000000000000"}


def is_run_span(span):
    """Return True if this span is a run-role span (outer or nested mise run)."""
    return span["name"].startswith("mise run ")


def is_task_span(span):
    """Return True if this span represents an individual task."""
    return span["name"].startswith("task ")


def task_name_of(span):
    """Return the fixture task name this span represents (via attribute or name)."""
    attrs = span.get("attributes", {})
    if "mise.task.name" in attrs:
        return attrs["mise.task.name"]
    name = span["name"]
    if name.startswith("task "):
        return name[len("task "):]
    return None


def find_task_span(spans, task_name):
    """Find the span for a specific fixture task by name."""
    for s in spans:
        if is_task_span(s) and task_name_of(s) == task_name:
            return s
    return None


def test_nested_run_joins_trace(inputs, expected):
    """Test that a nested mise run joins the outer trace."""
    env = {TRACE_OPT_IN: "1"}

    with OtlpCollector() as col:
        run_mise(inputs["task"], col, env=env)

        all_spans = col.spans()
        trace_count = len(col.trace_ids())

        # Count run-role spans that have a non-empty parent (i.e., nested runs)
        non_root_run_spans = 0
        for s in all_spans:
            if is_run_span(s):
                pid = s.get("parent_span_id", "")
                if pid not in _ROOT_PARENTS:
                    non_root_run_spans += 1

        # Find the task spans for "b" (the launcher) and "inner"
        b_span = find_task_span(all_spans, "b")
        inner_span = find_task_span(all_spans, "inner")

        # Walk inner's ancestor chain to see if b_span appears
        inner_descendant_of_invoker = 0
        if b_span is not None and inner_span is not None:
            current = inner_span
            visited = set()
            while current is not None:
                sid = current["span_id"]
                if sid in visited:
                    break
                visited.add(sid)
                pid = current.get("parent_span_id", "")
                if pid in _ROOT_PARENTS:
                    break
                parent = col.span_by_id(pid)
                if parent is None:
                    break
                if parent["span_id"] == b_span["span_id"]:
                    inner_descendant_of_invoker = 1
                    break
                current = parent

        # Count task-role spans that are direct children of the root run span
        roots = col.root_spans()
        tasks_under_root = 0
        if roots:
            root = roots[0]
            kids = col.children_of(root["span_id"])
            tasks_under_root = sum(1 for k in kids if is_task_span(k))

    assert trace_count == expected["trace_count"], (
        f"Expected trace_count={expected['trace_count']}, got {trace_count}"
    )
    assert non_root_run_spans == expected["non_root_run_spans"], (
        f"Expected non_root_run_spans={expected['non_root_run_spans']}, got {non_root_run_spans}"
    )
    assert inner_descendant_of_invoker == expected["inner_descendant_of_invoker"], (
        f"Expected inner_descendant_of_invoker={expected['inner_descendant_of_invoker']}, got {inner_descendant_of_invoker}"
    )
    assert tasks_under_root == expected["tasks_under_root"], (
        f"Expected tasks_under_root={expected['tasks_under_root']}, got {tasks_under_root}"
    )

    return {
        "trace_count": trace_count,
        "non_root_run_spans": non_root_run_spans,
        "inner_descendant_of_invoker": inner_descendant_of_invoker,
        "tasks_under_root": tasks_under_root,
    }
