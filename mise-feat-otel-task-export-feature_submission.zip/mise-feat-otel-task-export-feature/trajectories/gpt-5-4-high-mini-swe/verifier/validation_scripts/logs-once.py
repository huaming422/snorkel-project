import sys
sys.path.insert(0, "/tests/validate")
from test_harness import OtlpCollector, run_mise

# Discovered opt-ins from submitted patch:
#   Trace export: MISE_OTEL_TRACES=1
#   Log export:   MISE_OTEL_TASK_LOGS=1
# Task span identified by: attribute "mise.task.name" = task.name

TRACE_OPT_IN = "MISE_OTEL_TRACES"
LOG_OPT_IN = "MISE_OTEL_TASK_LOGS"


def test_logs_once(inputs, expected):
    """Test that each output line is exported exactly once, tied to the correct task."""
    env = {TRACE_OPT_IN: "1", LOG_OPT_IN: "1"}

    with OtlpCollector() as col:
        run_mise(inputs["task"], col, env=env, timeout=90)

        logs = col.log_records()
        bodies = [l["body"] for l in logs]
        from_inner_count = bodies.count("from-inner")

        # Build map: span_id -> fixture task name
        all_spans = col.spans()
        span_to_task = {}
        for s in all_spans:
            attrs = s.get("attributes", {})
            task_name = attrs.get("mise.task.name")
            if task_name is not None:
                span_to_task[s["span_id"]] = task_name

        attribution = inputs["attribution"]
        each_known_line_once = 1
        correctly_attributed = 0

        for line, expected_task in attribution.items():
            # Check exactly-once
            count = bodies.count(line)
            if count != 1:
                each_known_line_once = 0

            # Check attribution: find the log record with this body
            matching_logs = [l for l in logs if l["body"] == line]
            if matching_logs:
                log = matching_logs[0]
                log_span_id = log.get("span_id")
                actual_task = span_to_task.get(log_span_id)
                if actual_task == expected_task:
                    correctly_attributed += 1
            # If no matching log or wrong task, don't increment correctly_attributed

    assert from_inner_count == expected["from_inner_count"], (
        f"Expected from_inner_count={expected['from_inner_count']}, got {from_inner_count}"
    )
    assert each_known_line_once == expected["each_known_line_once"], (
        f"Expected each_known_line_once={expected['each_known_line_once']}, "
        f"got {each_known_line_once}"
    )
    assert correctly_attributed == expected["correctly_attributed"], (
        f"Expected correctly_attributed={expected['correctly_attributed']}, "
        f"got {correctly_attributed}"
    )

    return {
        "from_inner_count": from_inner_count,
        "each_known_line_once": each_known_line_once,
        "correctly_attributed": correctly_attributed,
    }
