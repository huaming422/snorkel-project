import sys
sys.path.insert(0, "/tests/validate")
from test_harness import OtlpCollector, run_mise

# Discovered opt-ins from submitted patch:
#   Trace export: MISE_OTEL_TRACES=1
# Span roles:
#   Root run span: name = "mise run", no parent
#   Non-root run span (nested): name = "mise run", has a parent
#   Task span: name starts with "task " OR has "mise.task.name" attribute

TRACE_OPT_IN = "MISE_OTEL_TRACES"


def _is_run_span(span):
    """Return True if the span is a run-role span (mise run)."""
    return span["name"] == "mise run"


def _is_task_span(span):
    """Return True if the span is an individual task span."""
    if span["name"].startswith("task "):
        return True
    attrs = span.get("attributes", {})
    return "mise.task.name" in attrs


def _get_task_name(span):
    """Get the fixture task name from a span's attributes."""
    attrs = span.get("attributes", {})
    return attrs.get("mise.task.name", None)


def test_nested_run_joins_trace(inputs, expected):
    """Test that nested mise run joins the same trace as the outer run."""
    env = {TRACE_OPT_IN: "1"}

    with OtlpCollector() as col:
        run_mise(inputs["task"], col, env=env, timeout=90)

        trace_count = len(col.trace_ids())

        # Non-root run spans: run-role spans that have a non-empty parent.
        # Use bool() to uniformly handle None and empty string (the harness
        # normalises absent parent_span_id to "" which is falsy, so bool()
        # correctly distinguishes roots from non-roots).
        all_spans = col.spans()
        non_root_run_spans = sum(
            1 for s in all_spans
            if _is_run_span(s) and bool(s.get("parent_span_id"))
        )

        # Find the task span for fixture task "b" (the launcher)
        b_span = None
        inner_span = None
        for s in all_spans:
            task_name = _get_task_name(s)
            if task_name == "b":
                b_span = s
            elif task_name == "inner":
                inner_span = s

        # Walk inner's parent chain to check if b_span is an ancestor
        inner_descendant_of_invoker = 0
        if b_span is not None and inner_span is not None:
            current_parent_id = inner_span.get("parent_span_id")
            visited = set()
            while bool(current_parent_id) and current_parent_id not in visited:
                visited.add(current_parent_id)
                parent = col.span_by_id(current_parent_id)
                if parent is None:
                    break
                if parent["span_id"] == b_span["span_id"]:
                    inner_descendant_of_invoker = 1
                    break
                current_parent_id = parent.get("parent_span_id")

        # Count task spans under the root run span
        roots = col.root_spans()
        tasks_under_root = 0
        if roots:
            root = roots[0]
            kids = col.children_of(root["span_id"])
            tasks_under_root = sum(1 for k in kids if _is_task_span(k))

    assert trace_count == expected["trace_count"], (
        f"Expected trace_count={expected['trace_count']}, got {trace_count}"
    )
    assert non_root_run_spans == expected["non_root_run_spans"], (
        f"Expected non_root_run_spans={expected['non_root_run_spans']}, got {non_root_run_spans}"
    )
    assert inner_descendant_of_invoker == expected["inner_descendant_of_invoker"], (
        f"Expected inner_descendant_of_invoker={expected['inner_descendant_of_invoker']}, "
        f"got {inner_descendant_of_invoker}"
    )
    assert tasks_under_root == expected["tasks_under_root"], (
        f"Expected tasks_under_root={expected['tasks_under_root']}, got {tasks_under_root}"
    )

    return {
        "trace_count": trace_count,
        "non_root_run_spans": non_root_run_spans,
        "inner_descendant_of_invoker": inner_descendant_of_invoker,
        "tasks_under_root": tasks_under_root,
    }
