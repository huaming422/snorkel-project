import sys
sys.path.insert(0, "/tests/validate")
from test_harness import OtlpCollector, run_mise

# Discovered opt-ins from submitted patch:
#   Trace export: MISE_OTEL_TRACES=1
# Exit-code attribute: "process.exit.code"
# Cancellation marker: attribute "mise.cancelled" = True
# Task span identified by: attribute "mise.task.name" = task.name

TRACE_OPT_IN = "MISE_OTEL_TRACES"
EXIT_CODE_ATTR = "process.exit.code"
CANCELLED_ATTR = "mise.cancelled"


def _get_task_span(spans, task_name):
    """Find the task span for the given fixture task name."""
    for s in spans:
        attrs = s.get("attributes", {})
        if attrs.get("mise.task.name") == task_name:
            return s
    return None


def test_fail_fast_status(inputs, expected):
    """Test fail-fast: failed task is error, stopped sibling is cancelled not failed."""
    env = {TRACE_OPT_IN: "1"}

    with OtlpCollector() as col:
        proc = run_mise(inputs["task"], col, env=env, timeout=90)
        run_failed = 1 if proc.returncode != 0 else 0

        roots = col.root_spans()
        root_status = roots[0]["status_code"] if roots else -1

        all_spans = col.spans()

        # Find the failing task span
        failed_span = _get_task_span(all_spans, inputs["failed_task"])
        failed_task_status = failed_span["status_code"] if failed_span else -1
        failed_task_exit_code = -1
        if failed_span is not None:
            attrs = failed_span.get("attributes", {})
            ec = attrs.get(EXIT_CODE_ATTR)
            if ec is not None:
                failed_task_exit_code = int(ec)

        # Find the sibling task span (stopped by mise)
        sibling_span = _get_task_span(all_spans, inputs["sibling_task"])
        sibling_is_error = 0
        sibling_cancel_marked = 0
        if sibling_span is not None:
            sibling_is_error = 1 if sibling_span["status_code"] == 2 else 0
            attrs = sibling_span.get("attributes", {})
            cancelled_val = attrs.get(CANCELLED_ATTR)
            if cancelled_val is True or cancelled_val == "true" or cancelled_val == 1:
                sibling_cancel_marked = 1

    assert run_failed == expected["run_failed"], (
        f"Expected run_failed={expected['run_failed']}, got {run_failed}"
    )
    assert root_status == expected["root_status"], (
        f"Expected root_status={expected['root_status']}, got {root_status}"
    )
    assert failed_task_status == expected["failed_task_status"], (
        f"Expected failed_task_status={expected['failed_task_status']}, got {failed_task_status}"
    )
    assert failed_task_exit_code == expected["failed_task_exit_code"], (
        f"Expected failed_task_exit_code={expected['failed_task_exit_code']}, "
        f"got {failed_task_exit_code}"
    )
    assert sibling_is_error == expected["sibling_is_error"], (
        f"Expected sibling_is_error={expected['sibling_is_error']}, got {sibling_is_error}"
    )
    assert sibling_cancel_marked == expected["sibling_cancel_marked"], (
        f"Expected sibling_cancel_marked={expected['sibling_cancel_marked']}, "
        f"got {sibling_cancel_marked}"
    )

    return {
        "run_failed": run_failed,
        "root_status": root_status,
        "failed_task_status": failed_task_status,
        "failed_task_exit_code": failed_task_exit_code,
        "sibling_is_error": sibling_is_error,
        "sibling_cancel_marked": sibling_cancel_marked,
    }
