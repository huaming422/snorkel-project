import sys
sys.path.insert(0, "/tests/validate")
from test_harness import OtlpCollector, run_mise

# Discovery:
# Trace opt-in:  MISE_TASK_OTEL_TRACES=1
# Log opt-in:    MISE_TASK_OTEL_LOGS=1
# Task spans identified by: "mise.task.name" attribute OR span name "task {name}"
# Log records linked to task span via log["span_id"] == span["span_id"]

TRACE_OPT_IN = "MISE_TASK_OTEL_TRACES"
LOG_OPT_IN   = "MISE_TASK_OTEL_LOGS"


def _span_task_name(span):
    attrs = span.get("attributes", {})
    if "mise.task.name" in attrs:
        return attrs["mise.task.name"]
    if span["name"].startswith("task "):
        return span["name"][len("task "):]
    return None


def test_logs_once(inputs, expected):
    """inputs and expected are injected automatically — one call per test case."""
    with OtlpCollector() as col:
        env = {TRACE_OPT_IN: "1", LOG_OPT_IN: "1"}
        run_mise(inputs["task"], col, env=env)

        logs = col.log_records()
        bodies = [l["body"] for l in logs]
        from_inner_count = bodies.count("from-inner")

        # Build map from span_id -> fixture task name
        all_spans = col.spans()
        span_id_to_task = {}
        for s in all_spans:
            task_name = _span_task_name(s)
            if task_name is not None:
                span_id_to_task[s["span_id"]] = task_name

        attribution = inputs["attribution"]

        # Check each known line
        each_known_line_once = 1
        correctly_attributed = 0

        for line, expected_task in attribution.items():
            # Count occurrences of this line
            line_count = bodies.count(line)
            if line_count != 1:
                each_known_line_once = 0
                # Line appears 0 or >1 times — attribution cannot be correct
                # (either missing or duplicated); do NOT increment correctly_attributed
            else:
                # Find the log record for this line and check attribution
                matching_logs = [l for l in logs if l["body"] == line]
                log_span_id = matching_logs[0].get("span_id", "")
                actual_task = span_id_to_task.get(log_span_id, None)
                if actual_task == expected_task:
                    correctly_attributed += 1

    assert from_inner_count == expected["from_inner_count"], (
        f"Expected from_inner_count={expected['from_inner_count']}, got {from_inner_count}"
    )
    assert each_known_line_once == expected["each_known_line_once"], (
        f"Expected each_known_line_once={expected['each_known_line_once']}, got {each_known_line_once}"
    )
    assert correctly_attributed == expected["correctly_attributed"], (
        f"Expected correctly_attributed={expected['correctly_attributed']}, got {correctly_attributed}"
    )

    return {
        "from_inner_count": from_inner_count,
        "each_known_line_once": each_known_line_once,
        "correctly_attributed": correctly_attributed,
    }
