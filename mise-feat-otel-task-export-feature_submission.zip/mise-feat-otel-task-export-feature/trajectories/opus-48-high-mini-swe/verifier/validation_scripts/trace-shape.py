import sys
sys.path.insert(0, "/tests/validate")
from test_harness import OtlpCollector, run_mise

# Discovery:
# Trace opt-in: MISE_TASK_OTEL_TRACES=1
# Span role scheme (by name):
#   root/run span:   name == "mise run"
#   setup span:      name == "mise install"
#   task span:       name starts with "task " and has attribute "mise.task.name"

TRACE_OPT_IN = "MISE_TASK_OTEL_TRACES"


def _is_setup_span(span):
    """True if this span represents the setup/install phase."""
    return span["name"] == "mise install"


def _is_task_span(span):
    """True if this span represents an individual task."""
    return span["name"].startswith("task ") or "mise.task.name" in span.get("attributes", {})


def test_trace_shape(inputs, expected):
    """inputs and expected are injected automatically — one call per test case."""
    with OtlpCollector() as col:
        env = {TRACE_OPT_IN: "1"}

        # Apply protocol override if requested
        if inputs["protocol"] == "invalid":
            env["OTEL_EXPORTER_OTLP_PROTOCOL"] = "totally-not-a-real-protocol"
        # "default" -> add nothing extra

        run_mise(inputs["task"], col, env=env)

        # Wire encoding classification
        cts = col.content_types("traces")
        ct = cts[0] if cts else ""
        if "json" in ct:
            content_type_kind = "json"
        elif "protobuf" in ct:
            content_type_kind = "protobuf"
        else:
            content_type_kind = "other"

        trace_signal_received = 1 if col.request_count("traces") >= 1 else 0

        # Span tree inspection — only when parse_tree is true
        if inputs["parse_tree"]:
            trace_count = len(col.trace_ids())
            roots = col.root_spans()
            root_count = len(roots)

            if not roots:
                setup_phase_present = 0
                task_under_root = -1
            else:
                root = roots[0]
                kids = col.children_of(root["span_id"])
                setup_phase_present = 1 if any(_is_setup_span(k) for k in kids) else 0
                task_under_root = sum(1 for k in kids if _is_task_span(k))
        else:
            trace_count = "__skip__"
            root_count = "__skip__"
            setup_phase_present = "__skip__"
            task_under_root = "__skip__"

    # Assertions
    assert content_type_kind == expected["content_type_kind"], (
        f"Expected content_type_kind={expected['content_type_kind']}, got {content_type_kind}"
    )
    assert trace_signal_received == expected["trace_signal_received"], (
        f"Expected trace_signal_received={expected['trace_signal_received']}, got {trace_signal_received}"
    )
    if expected["trace_count"] != "__skip__":
        assert trace_count == expected["trace_count"], (
            f"Expected trace_count={expected['trace_count']}, got {trace_count}"
        )
    if expected["root_count"] != "__skip__":
        assert root_count == expected["root_count"], (
            f"Expected root_count={expected['root_count']}, got {root_count}"
        )
    if expected["setup_phase_present"] != "__skip__":
        assert setup_phase_present == expected["setup_phase_present"], (
            f"Expected setup_phase_present={expected['setup_phase_present']}, got {setup_phase_present}"
        )
    if expected["task_under_root"] != "__skip__":
        assert task_under_root == expected["task_under_root"], (
            f"Expected task_under_root={expected['task_under_root']}, got {task_under_root}"
        )

    return {
        "content_type_kind": content_type_kind,
        "trace_signal_received": trace_signal_received,
        "trace_count": trace_count,
        "root_count": root_count,
        "setup_phase_present": setup_phase_present,
        "task_under_root": task_under_root,
    }
