import sys
sys.path.insert(0, "/tests/validate")
from test_harness import OtlpCollector, run_mise

# Discovery:
# Trace opt-in: MISE_TASK_OTEL_TRACES=1
# Span role scheme (by name):
#   root/run span:   name == "mise run"
#   setup span:      name == "mise install"
#   task span:       name starts with "task " OR has attribute "mise.task.name"
# Task identification: span["attributes"]["mise.task.name"] OR "task {name}" span name

TRACE_OPT_IN = "MISE_TASK_OTEL_TRACES"

# These are the same sentinel values the harness uses to identify root spans
_ROOT_PARENTS = {"", "0000000000000000", "00000000000000000000000000000000"}


def _is_run_span(span):
    return span["name"] == "mise run"


def _is_task_span(span):
    return span["name"].startswith("task ") or "mise.task.name" in span.get("attributes", {})


def _span_task_name(span):
    attrs = span.get("attributes", {})
    if "mise.task.name" in attrs:
        return attrs["mise.task.name"]
    if span["name"].startswith("task "):
        return span["name"][len("task "):]
    return None


def test_nested_run_joins_trace(inputs, expected):
    """inputs and expected are injected automatically — one call per test case."""
    with OtlpCollector() as col:
        env = {TRACE_OPT_IN: "1"}
        run_mise(inputs["task"], col, env=env)

        trace_count = len(col.trace_ids())

        # non_root_run_spans: run-role spans with a non-empty / non-sentinel parent
        all_spans = col.spans()
        non_root_run_spans = sum(
            1 for s in all_spans
            if _is_run_span(s) and s.get("parent_span_id", "") not in _ROOT_PARENTS
        )

        # Find task span for "b" (the launcher) and "inner" (nested task)
        b_span = None
        inner_span = None
        for s in all_spans:
            if _span_task_name(s) == "b":
                b_span = s
            if _span_task_name(s) == "inner":
                inner_span = s

        # Walk inner's parent chain upward to find if b_span is an ancestor
        inner_descendant_of_invoker = 0
        if inner_span is not None and b_span is not None:
            current_span_id = inner_span.get("parent_span_id", "")
            visited = set()
            while current_span_id and current_span_id not in _ROOT_PARENTS:
                if current_span_id in visited:
                    break
                visited.add(current_span_id)
                if current_span_id == b_span["span_id"]:
                    inner_descendant_of_invoker = 1
                    break
                parent_span = col.span_by_id(current_span_id)
                if parent_span is None:
                    break
                current_span_id = parent_span.get("parent_span_id", "")

        # tasks_under_root: task-role spans that are direct children of the root run span
        roots = col.root_spans()
        tasks_under_root = 0
        if roots:
            root = roots[0]
            kids = col.children_of(root["span_id"])
            tasks_under_root = sum(1 for k in kids if _is_task_span(k))

    assert trace_count == expected["trace_count"], (
        f"Expected trace_count={expected['trace_count']}, got {trace_count}"
    )
    assert non_root_run_spans == expected["non_root_run_spans"], (
        f"Expected non_root_run_spans={expected['non_root_run_spans']}, got {non_root_run_spans}"
    )
    assert inner_descendant_of_invoker == expected["inner_descendant_of_invoker"], (
        f"Expected inner_descendant_of_invoker={expected['inner_descendant_of_invoker']}, got {inner_descendant_of_invoker}"
    )
    assert tasks_under_root == expected["tasks_under_root"], (
        f"Expected tasks_under_root={expected['tasks_under_root']}, got {tasks_under_root}"
    )

    return {
        "trace_count": trace_count,
        "non_root_run_spans": non_root_run_spans,
        "inner_descendant_of_invoker": inner_descendant_of_invoker,
        "tasks_under_root": tasks_under_root,
    }
