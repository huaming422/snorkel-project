import sys
sys.path.insert(0, "/tests/validate")
from test_harness import OtlpCollector, run_mise

# Discovery:
# Trace opt-in:      MISE_TASK_OTEL_TRACES=1
# Exit code attr:    "mise.task.exit_code"  (int/i64)
# Cancellation:      "mise.task.cancelled"  (bool true)
# Span role scheme:
#   root/run span:   name == "mise run"
#   task span:       name starts with "task " OR has "mise.task.name" attribute
# Task identification: "mise.task.name" attribute OR "task {name}" span name

TRACE_OPT_IN = "MISE_TASK_OTEL_TRACES"
EXIT_CODE_ATTR = "mise.task.exit_code"
CANCEL_ATTR = "mise.task.cancelled"


def _span_task_name(span):
    attrs = span.get("attributes", {})
    if "mise.task.name" in attrs:
        return attrs["mise.task.name"]
    if span["name"].startswith("task "):
        return span["name"][len("task "):]
    return None


def test_fail_fast_status(inputs, expected):
    """inputs and expected are injected automatically — one call per test case."""
    with OtlpCollector() as col:
        env = {TRACE_OPT_IN: "1"}
        proc = run_mise(inputs["task"], col, env=env, timeout=90)

        run_failed = 1 if proc.returncode != 0 else 0

        roots = col.root_spans()
        root_status = roots[0]["status_code"] if roots else -1

        all_spans = col.spans()

        # Find the span for the failing task
        failed_task_name = inputs["failed_task"]
        sibling_task_name = inputs["sibling_task"]

        failed_span = None
        sibling_span = None
        for s in all_spans:
            name = _span_task_name(s)
            if name == failed_task_name:
                failed_span = s
            elif name == sibling_task_name:
                sibling_span = s

        # Failed task observables
        if failed_span is not None:
            failed_task_status = failed_span["status_code"]
            exit_code_raw = failed_span.get("attributes", {}).get(EXIT_CODE_ATTR, None)
            failed_task_exit_code = int(exit_code_raw) if exit_code_raw is not None else -1
        else:
            failed_task_status = -1
            failed_task_exit_code = -1

        # Sibling task observables
        if sibling_span is not None:
            sibling_is_error = 1 if sibling_span["status_code"] == 2 else 0
            cancel_val = sibling_span.get("attributes", {}).get(CANCEL_ATTR, None)
            # cancel_val may be bool True or the string "true"
            if cancel_val is True or cancel_val == "true" or cancel_val == 1:
                sibling_cancel_marked = 1
            else:
                sibling_cancel_marked = 0
        else:
            # Sibling span not found — use 0 as sentinel (not -1) so the
            # assertion message reflects "sibling not found" rather than
            # implying it was an error span.
            sibling_is_error = 0
            sibling_cancel_marked = 0

    assert run_failed == expected["run_failed"], (
        f"Expected run_failed={expected['run_failed']}, got {run_failed}"
    )
    assert root_status == expected["root_status"], (
        f"Expected root_status={expected['root_status']}, got {root_status}"
    )
    assert failed_task_status == expected["failed_task_status"], (
        f"Expected failed_task_status={expected['failed_task_status']}, got {failed_task_status}"
    )
    assert failed_task_exit_code == expected["failed_task_exit_code"], (
        f"Expected failed_task_exit_code={expected['failed_task_exit_code']}, got {failed_task_exit_code}"
    )
    assert sibling_is_error == expected["sibling_is_error"], (
        f"Expected sibling_is_error={expected['sibling_is_error']}, got {sibling_is_error}"
    )
    assert sibling_cancel_marked == expected["sibling_cancel_marked"], (
        f"Expected sibling_cancel_marked={expected['sibling_cancel_marked']}, got {sibling_cancel_marked}"
    )

    return {
        "run_failed": run_failed,
        "root_status": root_status,
        "failed_task_status": failed_task_status,
        "failed_task_exit_code": failed_task_exit_code,
        "sibling_is_error": sibling_is_error,
        "sibling_cancel_marked": sibling_cancel_marked,
    }
