## Task

the watch-mode dev loop has gotten painful since the recent precompilation/caching rework.

with the serve/test watcher running, saving a single source file now kicks off the whole unit suite several times over for that one save instead of running it once. and some of those extra runs seem to execute against the previous version of the file i just saved, so the results don't even reflect what's on disk.

single-spec iteration regressed too. running one spec on its own is slower than it used to be, and an unrelated group of build-tooling tests gets pulled into the run. when one of those happens to fail it takes the whole thing down before my spec ever runs.

full runs from a clean checkout are fine and should stay that way. this is only the watch loop and single-file runs that are off. can you dig in and get them back to running once, against the current files, without that extra test group riding along?

## General instructions

- The code repo is at /repo/Prebid.js.
- You are inside of a Docker container with no network access. You may not be able to perform all operations you would normally be able to do on a local machine. The project's dependencies and toolchain are already installed and the package manager caches are populated, so build and test with what is in the image; anything that needs to be downloaded will fail rather than hang.
- You are expected to act autonomously as a software engineer to complete tasks you are given.
- Do not stop until you feel you have completed the task and your code changes can be merged.
- You may need to use software engineering skills like analyzing the codebase, researching technologies, running services, analyzing logs, etc. to complete the task. Not all tasks will be solvable by reading source code alone.
