// Behavioral verifier for the watch-mode / single-file dev-test regression.
//
// Tests THROUGH pre-existing, stable module interfaces that the repo's own
// `test/build-logic` mocha tier already imports — never through newly
// introduced helpers. This file is dropped into `test/build-logic/` at grade time so the
// `../../` specifiers resolve exactly as the repo's own specs do.
import { describe, it, before, after, beforeEach } from 'mocha';
import { expect } from 'chai';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { copyDeclarations, precompile } from '../../gulp.precompilation.js';
import helpers from '../../gulpHelpers.js';

const require = createRequire(import.meta.url);
const karmaConfMaker = require('../../karma.conf.maker.js');
const anymatch = require('anymatch');

// ── Criterion 1: the declaration-copy precompile writer compares CONTENTS, ──
// not mtime. Through the pre-existing `copyDeclarations` export. An
// mtime/`since`-only guard rewrites a byte-identical destination whenever the
// source looks newer; a content guard leaves it untouched.
describe('precompile declaration copy is content-idempotent', () => {
  const name = `zzWatchRerunsVerify${process.pid}`;
  const source = path.resolve('src', `${name}.ts`);
  const cached = path.resolve('.cache', 'ts', 'out', 'src', `${name}.d.ts`);
  const copied = helpers.getPrecompiledPath(path.join('src', `${name}.d.ts`));
  const past = new Date('2000-01-01T00:00:00Z');

  function seedCache() {
    fs.mkdirSync(path.dirname(cached), { recursive: true });
    fs.writeFileSync(cached, `export declare function ${name}(): number;\n`);
    fs.rmSync(copied, { force: true });
  }
  function seedCopied(contents) {
    fs.mkdirSync(path.dirname(copied), { recursive: true });
    fs.writeFileSync(copied, contents);
    fs.utimesSync(copied, past, past);
  }

  beforeEach(() => {
    // source is NEWER than the seeded destination: a pure mtime/`since` guard
    // would treat the destination as stale and rewrite it.
    fs.writeFileSync(source, `export function ${name}(): number { return 1; }\n`);
    seedCache();
  });
  after(() => {
    [source, cached, copied].forEach((f) => fs.rmSync(f, { force: true }));
  });

  it('does not rewrite a destination whose bytes already match', async () => {
    seedCopied(fs.readFileSync(cached));
    await copyDeclarations();
    expect(fs.statSync(copied).mtime.getTime()).to.equal(past.getTime());
  });

  it('overwrites a destination whose bytes differ', async () => {
    seedCopied(`export declare function ${name}(): string;\n`);
    await copyDeclarations();
    expect(fs.readFileSync(copied, 'utf8')).to.equal(fs.readFileSync(cached, 'utf8'));
  });
});

// ── Criterion 3: EVERY repeated precompile writer is content-idempotent ─────
// Through the pre-existing exported `precompile` task — the same task the watch
// loop re-runs on every save. A watch task precompiles again on each change,
// and anything watching the precompiled tree reacts to a write whether or not
// the bytes changed, so a writer that re-emits byte-identical output on an
// unchanged tree is what turns one save into several rebuilds. This drives all
// the repeated writers at once (not only the declaration copy) and names none
// of them: it precompiles an unchanged tree twice and asserts the outputs that
// feed the watched bundle keep their bytes — and mtime — the second time.
describe('repeated precompile over an unchanged tree rewrites nothing', function () {
  // a full precompile runs tsc + babel + webpack; two of them plus setup sit
  // well under this bound but far over mocha's 2s default.
  this.timeout(240000);

  const root = helpers.getPrecompiledPath();
  const past = new Date('2000-01-01T00:00:00Z');

  function runPrecompile() {
    return new Promise((resolve, reject) => {
      precompile()((err) => (err ? reject(err) : resolve()));
    });
  }
  function listFiles(dir) {
    try {
      return fs.readdirSync(dir).map((n) => path.join(dir, n)).filter((f) => fs.statSync(f).isFile());
    } catch {
      return [];
    }
  }

  it('leaves every watched-tree output untouched on a second precompile', async () => {
    // First precompile builds the tree from scratch.
    await runPrecompile();

    // The outputs that feed the watched webpack bundle and are re-emitted by a
    // repeated precompile: the generated build-options module and the creative
    // renderers. Resolve them through pre-existing path helpers / the customize
    // entrypoint, never through any symbol the fix may introduce.
    const { getBuildOptionsModule } = await import('../../customize/buildOptions.mjs');
    const targets = [getBuildOptionsModule(), ...listFiles(helpers.getCreativeRendererPath())]
      .filter((f) => fs.existsSync(f));
    expect(targets.length, 'first precompile should have produced the watched outputs').to.be.greaterThan(1);

    // Pin an old mtime so any rewrite on the second run is observable, and
    // record the bytes so a same-mtime rewrite could not slip through either.
    const before = targets.map((f) => {
      fs.utimesSync(f, past, past);
      return { file: f, bytes: fs.readFileSync(f) };
    });

    // Second precompile over the identical source tree: a content-idempotent
    // set of writers must not re-emit any of these files.
    await runPrecompile();

    const rewritten = before
      .filter(({ file, bytes }) =>
        !fs.existsSync(file) ||
        fs.statSync(file).mtime.getTime() !== past.getTime() ||
        !fs.readFileSync(file).equals(bytes))
      .map(({ file }) => path.relative(root, file));
    expect(
      rewritten,
      'a repeated precompile re-wrote unchanged watched-tree output(s): ' + rewritten.join(', '),
    ).to.deep.equal([]);
  });
});

// ── Criterion 2: watch-mode coalescing window ───────────────────────────────
// Through the `karma.conf.maker.js` factory export. Watch mode must set a
// coalescing window wide enough for a module and its separately-written source
// map to land in one rebuild (strictly > webpack's 20ms default) and keep
// source maps watched; single-run mode sets no watchOptions at all.
describe('karma webpack watch coalescing', () => {
  function watchOptions(watchMode) {
    return karmaConfMaker(false, false, watchMode, ['test/spec/a_spec.js'], null, 1, true)
      .webpack.watchOptions;
  }

  it('coalesces split writes in watch mode and keeps source maps watched', () => {
    const o = watchOptions(true);
    expect(o, 'watch mode should define webpack watchOptions').to.be.an('object');
    expect(o.aggregateTimeout, 'aggregateTimeout should be a number').to.be.a('number');
    // anti-coupling: the window must beat webpack's 20ms default, NOT equal a
    // specific chosen value.
    expect(o.aggregateTimeout).to.be.greaterThan(20);
    // The requirement is behavioral — a precompiled module's source map must
    // stay watched so a late-arriving `.map` still refreshes the bundle. Assert
    // that, not that `ignored` is literally unset: a fix that adds a defensible
    // `ignored: /node_modules/` (which does not un-watch `.map` files under the
    // precompiled tree) still satisfies the contract.
    if (o.ignored !== undefined) {
      const sampleMap = helpers.getPrecompiledPath(path.join('src', 'prebid.js.map'));
      expect(
        anymatch(o.ignored, sampleMap),
        'precompiled source maps must not be excluded from watching',
      ).to.equal(false);
    }
  });

  it('sets no watch options for a single run', () => {
    expect(watchOptions(false)).to.equal(undefined);
  });
});

// ── Criterion 4: single-file test-only excludes the build-logic suite ───────
// Through the gulp task registry. `test-only --file <spec>` must drop the
// build-logic suite from its series; a full `test-only` must keep it. argv is
// parsed once at gulpfile load, so each argv state is exercised in its own
// child process and the series membership is read from gulp.tree().
describe('single-file test-only task composition', () => {
  let probeFile;
  before(() => {
    probeFile = path.join(os.tmpdir(), `ssb_testonly_probe_${process.pid}.mjs`);
    fs.writeFileSync(probeFile, `
import { createRequire } from 'node:module';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
const gfile = path.resolve(process.cwd(), 'gulpfile.js');
const require = createRequire(gfile);
const gulp = require('gulp');
await import(pathToFileURL(gfile).href);
function collect(node, acc){ if(!node) return acc; if(node.label) acc.push(node.label); (node.nodes||[]).forEach(n=>collect(n,acc)); return acc; }
function find(nodes,label){ for(const n of nodes||[]){ if(n.label===label) return n; const r=find(n.nodes,label); if(r) return r; } return null; }
const to = find(gulp.tree({deep:true}).nodes, 'test-only');
process.stdout.write('INCLUDES:' + collect(to, []).includes('test-build-logic'));
`);
  });
  after(() => { if (probeFile) fs.rmSync(probeFile, { force: true }); });

  function includesBuildLogic(extraArgs) {
    const r = spawnSync(process.execPath, [probeFile, ...extraArgs], {
      cwd: process.cwd(), encoding: 'utf8', timeout: 120000,
    });
    const m = /INCLUDES:(true|false)/.exec(r.stdout || '');
    if (!m) throw new Error(`task-graph probe failed\nstdout:${r.stdout}\nstderr:${r.stderr}`);
    return m[1] === 'true';
  }

  it('omits the build-logic suite when a single spec file is selected', () => {
    expect(includesBuildLogic(['--file', 'test/spec/a_spec.js'])).to.equal(false);
  });

  it('keeps the build-logic suite for a full test-only run', () => {
    expect(includesBuildLogic([])).to.equal(true);
  });
});
