#!/usr/bin/env python3
"""Behavioral verifier for the watch-mode / single-file dev-test regression.

This verifier is NATIVE Node/mocha: the behavior under test lives in the repo's
gulp/webpack/karma build modules and is observable only from Node, through the
pre-existing `test/build-logic` mocha tier. This file is a THIN pytest shim that
runs under the isolated verifier interpreter (`VERIFIER_PYTHON`) and imports no
repository Python (there is none). It:

  1. copies the mocha spec (`watch_reruns_spec.mjs`, shipped beside this file)
     into the repo's own `test/build-logic/` directory, so the spec's `../../`
     module specifiers and repo-root cwd resolve exactly as the repo's existing
     build-logic specs do;
  2. runs it once via the repo's local mocha with the JSON reporter;
  3. maps each mocha `it()` result onto the task's behavioral criteria, so each
     criterion surfaces as its own named pytest case in the JUnit XML.

Each test below asserts a distinct criterion and fails loudly (with the mocha
failure message) when that criterion's mocha case(s) did not pass. An
unmodified pre-fix repo fails every fail-to-pass criterion here.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

REPO_DIR = Path(f"/repo/{os.environ.get('REPO_NAME', 'Prebid.js')}")
BUILD_LOGIC_DIR = REPO_DIR / "test" / "build-logic"
SPEC_SRC = Path(__file__).resolve().parent / "watch_reruns_spec.mjs"
# A collision-proof name in the repo's own build-logic dir; the `**/*_spec.mjs`
# glob the repo uses would also match it, but we invoke mocha on this file alone.
SPEC_DEST = BUILD_LOGIC_DIR / "ssb_verify_watch_reruns_spec.mjs"
MOCHA_BIN = REPO_DIR / "node_modules" / ".bin" / "mocha"

# mocha fullTitle -> the result bucket it belongs to. Every title the spec emits
# must appear here; an unmapped or missing title is treated as an infra failure
# so a silently-renamed/removed case can never vacuously pass.
TITLE_BUCKETS: dict[str, str] = {
    "precompile declaration copy is content-idempotent "
    "does not rewrite a destination whose bytes already match": "decl_idempotent",
    "precompile declaration copy is content-idempotent "
    "overwrites a destination whose bytes differ": "decl_idempotent",
    "repeated precompile over an unchanged tree rewrites nothing "
    "leaves every watched-tree output untouched on a second precompile": "repeated_writers",
    "karma webpack watch coalescing "
    "coalesces split writes in watch mode and keeps source maps watched": "watch_timeout",
    "karma webpack watch coalescing "
    "sets no watch options for a single run": "watch_timeout",
    "single-file test-only task composition "
    "omits the build-logic suite when a single spec file is selected": "single_file_excludes",
    "single-file test-only task composition "
    "keeps the build-logic suite for a full test-only run": "single_file_excludes",
}


def _run_mocha() -> dict:
    """Run the mocha spec once from the repo root and return parsed JSON."""
    if not MOCHA_BIN.exists():
        pytest.fail(f"mocha binary not found at {MOCHA_BIN}; repo deps not installed")
    BUILD_LOGIC_DIR.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(SPEC_SRC, SPEC_DEST)
    try:
        proc = subprocess.run(
            [str(MOCHA_BIN), str(SPEC_DEST.relative_to(REPO_DIR)), "--reporter", "json"],
            cwd=str(REPO_DIR),
            capture_output=True,
            text=True,
            timeout=600,
            check=False,
        )
    except subprocess.TimeoutExpired as e:  # pragma: no cover - infra failure
        pytest.fail(f"mocha timed out: {e}")
    finally:
        SPEC_DEST.unlink(missing_ok=True)

    stdout = proc.stdout or ""
    # mocha's JSON reporter prints a single JSON document to stdout; a build/
    # import error instead prints a stack trace, which we surface verbatim.
    start = stdout.find("{")
    if start == -1:
        pytest.fail(
            "mocha produced no JSON output (exit "
            f"{proc.returncode}).\nstdout:\n{stdout[-2000:]}\nstderr:\n{(proc.stderr or '')[-2000:]}"
        )
    try:
        return json.loads(stdout[start:])
    except json.JSONDecodeError as e:  # pragma: no cover - infra failure
        pytest.fail(f"could not parse mocha JSON: {e}\nstdout:\n{stdout[-2000:]}")


@pytest.fixture(scope="session")
def mocha_results() -> dict[str, list[str]]:
    """Map each criterion bucket -> list of failure messages (empty == all passed).

    A title present in neither passes nor failures (never ran) is recorded as a
    synthetic failure for its bucket so a disappeared case cannot pass silently.
    """
    report = _run_mocha()
    passed_titles = {t.get("fullTitle", "") for t in report.get("passes", [])}
    failed = {
        t.get("fullTitle", ""): ((t.get("err") or {}).get("message") or "assertion failed")
        for t in report.get("failures", [])
    }

    buckets: dict[str, list[str]] = {b: [] for b in set(TITLE_BUCKETS.values())}
    for title, bucket in TITLE_BUCKETS.items():
        if title in failed:
            buckets[bucket].append(f"{title} :: {failed[title].splitlines()[0]}")
        elif title not in passed_titles:
            buckets[bucket].append(f"{title} :: case never ran (spec changed or errored)")
    return buckets


def test_precompile_decl_idempotent(mocha_results):
    """Criterion: declaration-copy precompile does not rewrite a byte-identical
    destination (content comparison, not mtime), and overwrites a differing one."""
    failures = mocha_results["decl_idempotent"]
    assert not failures, "declaration-copy idempotency failed:\n" + "\n".join(failures)


def test_watch_aggregate_timeout(mocha_results):
    """Criterion: watch mode sets a coalescing window > webpack's 20ms default
    and keeps source maps watched; single-run mode sets no watchOptions."""
    failures = mocha_results["watch_timeout"]
    assert not failures, "watch coalescing-window behavior failed:\n" + "\n".join(failures)


def test_other_precompile_writers_idempotent(mocha_results):
    """Criterion: ALL the repeated precompile writers stay idempotent, not just
    the declaration copy. Runs the exported `precompile` task twice over an
    unchanged source tree and asserts no watched-tree output (the generated
    build-options module, the creative renderers) is re-emitted the second time
    — a fix that makes only one writer idempotent re-writes the others and
    fails here."""
    failures = mocha_results["repeated_writers"]
    assert not failures, "repeated-writer idempotency failed:\n" + "\n".join(failures)


def test_single_file_excludes_build_logic(mocha_results):
    """Criterion: `test-only --file <spec>` drops the build-logic suite from its
    series, while a full `test-only` keeps it."""
    failures = mocha_results["single_file_excludes"]
    assert not failures, "single-file build-logic exclusion failed:\n" + "\n".join(failures)
