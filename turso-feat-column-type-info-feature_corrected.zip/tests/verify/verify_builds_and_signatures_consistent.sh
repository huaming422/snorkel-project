#!/usr/bin/env bash
#
# Builds the turso_core and turso_sdk_kit crates with all features enabled,
# from the workspace root (/repo/turso). The C header, the FFI bindings and
# the exported C functions are checked against each other at compile time,
# so a disagreement between them fails this build.
#
# Exit codes:
#   0: both crates build
#   non-zero: cargo's exit status, with its error output above

set -euo pipefail

cd /repo/turso

cargo build -p turso_core -p turso_sdk_kit --all-features
