#!/usr/bin/env bash
#
# Structural verifier: confirms the whole feature integrates and the
# workspace still compiles after the agent's change.
#
# This feature spans six files across two crates that must stay mutually
# consistent:
#   * core/statement.rs: the new column-metadata accessor + its types
#   * core/lib.rs: the public re-export of those types
#   * sdk-kit/src/rsapi.rs: the safe Rust wrapper over the core accessor
#   * sdk-kit/src/capi.rs: the four `extern "C"` getters
#   * sdk-kit/src/bindings.rs: the bindgen-generated FFI declarations
#   * sdk-kit/turso.h: the hand-maintained C header
#
# sdk-kit has NO build.rs: bindings.rs is a committed, hand-regenerated
# artifact, and a `#[signature(c)]` attribute macro on each `extern "C"`
# getter asserts that getter's signature against its bindgen prototype at
# compile time. So if the agent adds the Rust API but leaves the header /
# bindings / getters inconsistent: a mismatched arg type, a wrong return
# type, a getter the bindings don't declare, the `turso_sdk_kit` crate
# fails to compile here. Any other build break (an unresolved re-export, a
# type error in the core accessor) also surfaces.
#
# We build the two crates the feature touches with all features enabled, the
# same feature set the image pre-warms, so the signature macro and every
# feature-gated path are exercised. The runner cwd is the repo dir
# (/repo/turso), which is the workspace root.
#
# Exit codes:
#   0: both crates build cleanly (signatures consistent)
#   non-zero: propagates the cargo build failure

set -euo pipefail

cd /repo/turso

cargo build -p turso_core -p turso_sdk_kit --all-features
