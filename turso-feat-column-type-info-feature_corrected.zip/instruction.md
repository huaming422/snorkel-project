## Task

Turso's experimental custom types, the ones you get from CREATE TYPE or CREATE DOMAIN once the custom-types flag is on, can't be read back off a prepared statement. get_column_decltype hands over the raw declared string, and for computed columns it has nothing, so the Postgres wire frontend we're putting on top can't describe its result columns.

I'd like a new accessor on a prepared statement that tells me, per result column, the declared type name, its array depth, the primitive underneath when the name points at a custom type or domain in the registry, and what kind of type it is: built-in, custom, domain, struct or union. Computed columns get a primitive worked out from the expression. Since it belongs with the rest of the custom-types work, which is still experimental, it should only answer on connections where that flag is on.

C callers need the same information through sdk-kit, one getter per field, with the kind as an integer. We'll be adding kinds on the Rust side later without wanting to touch sdk-kit every time, so a kind the C side hasn't been taught yet should come out as the no-information value, never as one of the existing numbers.

## User stories / requirements

- I select columns declared with built-in types, including array forms like INTEGER[] and TEXT[][]. Each one reports the declared name, its array depth, no base primitive, and the built-in kind.
- I select columns typed with a custom type, a domain, a struct or a union I registered. Each one reports the name I declared, the primitive underneath (structs and unions sit on blob), and a kind of its own, so I can tell all four apart.
- I run SELECT * over a table that mixes an array column, a plain column and a custom-typed column. Every position answers for its own column, and the custom one still resolves through the registry.
- I select computed expressions, over literals or over table columns. Integer with integer arithmetic stays integer, integer or real mixed with a real gives real, and anything else, a NUMERIC operand for one, gives numeric. Concatenation is text; bitwise operators, comparisons, AND/OR and rowid come back integer.
- When an expression gives nothing to go on, like a NULL or blob literal or randomblob(), I'm told there's no type information instead of getting a guess. A plain integer literal still reports integer.
- On a connection opened without the custom-types flag, asking for this information gets me an error or nothing at all, never a type.
- From C I get the declared name, the number of array dimensions, the base type and the kind, each from its own getter, and they match what the Rust accessor says. Every kind has its own integer, and a column with no type information gets a separate no-information value.
