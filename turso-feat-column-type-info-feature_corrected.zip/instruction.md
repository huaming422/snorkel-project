## Task

Turso's experimental custom types, the ones you get from CREATE TYPE or CREATE DOMAIN once the custom-types flag is on, can't be read back off a prepared statement. get_column_decltype hands over the raw declared string and has nothing for a computed column, so the Postgres wire frontend we're building on top has no way to describe its result columns. I'd like a prepared statement to tell me what type each result column has, both from Rust and from C through sdk-kit.

We'll keep adding kinds of type on the Rust side and don't want to edit sdk-kit every time we do, so a kind the C side hasn't been taught yet should come out as the no-information value, never as one of the existing numbers.

## User stories / requirements

- I select columns declared with built-in types, including array forms like INTEGER[] and TEXT[][]. Each one reports the declared name, its array depth, no base primitive, and the built-in kind.
- I select columns typed with a custom type, a domain, a struct or a union I registered. Each one reports the name I declared, the primitive underneath (structs and unions sit on blob), and a kind of its own, so I can tell all four apart.
- I run SELECT * over a table that mixes an array column, a plain column and a custom-typed column. Every position answers for its own column, and the custom one still resolves through the registry.
- I select computed expressions, over literals or over table columns. Integer with integer arithmetic stays integer, integer or real mixed with a real gives real, and anything else, a NUMERIC operand for one, gives numeric. Concatenation is text; bitwise operators, comparisons, AND/OR and rowid come back integer.
- When an expression gives nothing to go on, like a NULL or blob literal or randomblob(), I'm told there's no type information instead of getting a guess. A plain integer literal still reports integer.
- On a connection opened without the custom-types flag, asking for this information gets me an error or nothing at all, never a type.
- From C I get the declared name, the number of array dimensions, the base type and the kind, each from its own getter, and they match what the Rust accessor says. Every kind has its own integer, and a column with no type information gets a separate no-information value.
