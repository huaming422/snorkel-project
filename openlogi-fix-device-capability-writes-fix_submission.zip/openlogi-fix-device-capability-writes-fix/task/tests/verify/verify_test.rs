//! End-to-end checks for the device-write paths that configure a Logitech
//! mouse's SmartShift ratchet behaviour and pointer DPI.
//!
//! Every check drives a simulated mouse: a small HID++ device model that
//! implements the public [`RawHidChannel`] transport trait and is served to the
//! write layer through a public [`HidBackend`]. The model answers the HID++
//! feature calls the write paths make and records every report that reaches the
//! wire, so each test can assert on exactly what the app sent to the device and
//! on what the public call returned — without reaching into any private type.
//!
//! The device model is driven entirely through `openlogi_device::write`'s
//! public entry points (`set_dpi`, `set_smartshift`, `get_smartshift_status`);
//! it never constructs an internal channel or feature wrapper.

use std::error::Error;
use std::io;
use std::sync::{Arc, Mutex};

use hidpp::async_trait;
use hidpp::channel::{HidppChannel, RawHidChannel};
use tokio::sync::{Mutex as AsyncMutex, mpsc};

use openlogi_device::backend::{
    BackendError, HidBackend, HotplugEvent, HotplugStream, NodeId, NodeInfo, RawWriter,
};
use openlogi_device::{
    DeviceRoute, Dpi, SmartShiftAutoDisengage, SmartShiftMode, SmartShiftStatus,
    SmartShiftThreshold, TunableTorque, get_smartshift_status, set_dpi, set_smartshift,
};

// ---------------------------------------------------------------------------
// HID++ feature IDs and the self-addressed device index the simulated mouse
// answers on. These are the real wire constants Logitech devices use; the model
// has to speak them to be opened at all.
// ---------------------------------------------------------------------------

/// Enhanced SmartShift wheel feature.
const SMARTSHIFT_ENHANCED: u16 = 0x2111;
/// Original adjustable-DPI feature (flat list of values).
const ADJUSTABLE_DPI: u16 = 0x2201;
/// Extended adjustable-DPI feature (per-axis DPI plus lift-off distance).
const EXTENDED_DPI: u16 = 0x2202;

/// A directly-attached device answers HID++ on this index.
const SELF_INDEX: u8 = 0xff;

/// Vendor / product the test route addresses. The vendor is Logitech's; the
/// product is arbitrary — only that the route and the model agree on it.
const VENDOR: u16 = 0x046d;
const PRODUCT: u16 = 0x4123;

/// How the device model answers one HID++ feature call.
enum Reply {
    /// A short (7-byte) report carrying three payload bytes.
    Short([u8; 3]),
    /// A long (20-byte) report carrying up to sixteen payload bytes.
    Long([u8; 16]),
    /// A HID++ error reply with the given error-type code.
    Error(u8),
}

/// The handler a test supplies: given a resolved feature id, the function id,
/// and the request arguments, decide how the device answers.
type Handler = dyn Fn(u16, u8, &[u8; 16]) -> Reply + Send + Sync;

// ---------------------------------------------------------------------------
// Report framing helpers. Byte layout: [0]=report id, [1]=device index,
// [2]=feature index, [3]=(function<<4 | software id), [4..]=payload.
// ---------------------------------------------------------------------------

/// Build a normal reply that echoes the request's device index, feature index
/// and function/software-id byte, with `payload` placed after the header.
fn make_reply(request: &[u8], payload: &[u8], long: bool) -> Vec<u8> {
    let (report_id, len) = if long { (0x11u8, 20usize) } else { (0x10u8, 7usize) };
    let mut buf = vec![0u8; len];
    buf[0] = report_id;
    buf[1] = request[1];
    buf[2] = request[2];
    buf[3] = request[3];
    let room = len - 4;
    let copied = payload.len().min(room);
    buf[4..4 + copied].copy_from_slice(&payload[..copied]);
    buf
}

/// Build a HID++ error reply for `request`. The feature-index byte becomes
/// `0xff`, the real feature index moves into the function/software-id slot, the
/// original function/software-id byte lands first in the payload, and the error
/// code follows it.
fn make_error(request: &[u8], error_code: u8) -> Vec<u8> {
    let mut buf = vec![0u8; 7];
    buf[0] = 0x10;
    buf[1] = request[1];
    buf[2] = 0xff;
    buf[3] = request[2];
    buf[4] = request[3];
    buf[5] = error_code;
    buf[6] = 0;
    buf
}

// ---------------------------------------------------------------------------
// The simulated device: a transport that computes a reply for each report the
// write layer sends and records everything written.
// ---------------------------------------------------------------------------

struct ScriptedChannel {
    features: Arc<Vec<(u16, u8)>>,
    handler: Arc<Handler>,
    written: Arc<Mutex<Vec<Vec<u8>>>>,
    incoming_tx: mpsc::UnboundedSender<Vec<u8>>,
    incoming_rx: AsyncMutex<mpsc::UnboundedReceiver<Vec<u8>>>,
}

impl ScriptedChannel {
    /// Compute the device's reply to one outgoing report, or `None` to stay
    /// silent. Handles the protocol-version ping and root feature lookup
    /// itself; everything else is delegated to the test's handler.
    fn compute(&self, src: &[u8]) -> Option<Vec<u8>> {
        if src.len() < 4 {
            return None;
        }
        let feature_index = src[2];
        let function = src[3] >> 4;

        let mut args = [0u8; 16];
        let payload = &src[4..];
        let copied = payload.len().min(16);
        args[..copied].copy_from_slice(&payload[..copied]);

        // Root feature (index 0): protocol-version ping (function 1) and
        // getFeature (function 0).
        if feature_index == 0x00 {
            if function == 0x01 {
                // Report HID++ 2.0 so the device opens.
                return Some(make_reply(src, &[0x04, 0x00, 0x00], false));
            }
            if function == 0x00 {
                let wanted = (u16::from(args[0]) << 8) | u16::from(args[1]);
                let index = self
                    .features
                    .iter()
                    .find(|(id, _)| *id == wanted)
                    .map_or(0, |(_, index)| *index);
                // A zero index means "feature not present".
                return Some(make_reply(src, &[index, 0, 0], false));
            }
            return Some(make_error(src, 1));
        }

        // A feature-specific call. Resolve the index back to its id so the
        // handler can match on the id it knows.
        let resolved = self
            .features
            .iter()
            .find(|(_, index)| *index == feature_index)
            .map(|(id, _)| *id);
        let Some(id) = resolved else {
            return Some(make_error(src, 6));
        };

        match (self.handler)(id, function, &args) {
            Reply::Short(bytes) => Some(make_reply(src, &bytes, false)),
            Reply::Long(bytes) => Some(make_reply(src, &bytes, true)),
            Reply::Error(code) => Some(make_error(src, code)),
        }
    }
}

#[async_trait]
impl RawHidChannel for ScriptedChannel {
    fn vendor_id(&self) -> u16 {
        VENDOR
    }

    fn product_id(&self) -> u16 {
        PRODUCT
    }

    async fn write_report(&self, src: &[u8]) -> Result<usize, Box<dyn Error + Sync + Send>> {
        self.written.lock().unwrap().push(src.to_vec());
        if let Some(reply) = self.compute(src) {
            // The only sender is held by this channel, so this cannot fail
            // while the channel is alive.
            let _ = self.incoming_tx.send(reply);
        }
        Ok(src.len())
    }

    async fn read_report(&self, buf: &mut [u8]) -> Result<usize, Box<dyn Error + Sync + Send>> {
        let next = {
            let mut rx = self.incoming_rx.lock().await;
            rx.recv().await
        };
        let Some(report) = next else {
            // The sender has been dropped and no further report will arrive:
            // surface a disconnected transport error, matching how a real HID
            // read reports a device that has gone away.
            return Err(Box::new(io::Error::new(
                io::ErrorKind::BrokenPipe,
                "scripted HID channel is disconnected",
            )));
        };
        let len = report.len().min(buf.len());
        buf[..len].copy_from_slice(&report[..len]);
        Ok(len)
    }

    fn supports_short_long_hidpp(&self) -> Option<(bool, bool)> {
        Some((true, true))
    }

    async fn get_report_descriptor(
        &self,
        _buf: &mut [u8],
    ) -> Result<usize, Box<dyn Error + Sync + Send>> {
        unreachable!("the scripted device declares HID++ support directly")
    }
}

/// The backend the write layer enumerates and opens. Each open builds a fresh
/// channel that shares this backend's recorded-writes log and handler.
struct ScriptedBackend {
    features: Arc<Vec<(u16, u8)>>,
    handler: Arc<Handler>,
    written: Arc<Mutex<Vec<Vec<u8>>>>,
}

#[async_trait]
impl HidBackend for ScriptedBackend {
    async fn enumerate(&self) -> Result<Vec<NodeInfo>, BackendError> {
        Ok(vec![self.node()])
    }

    async fn enumerate_hidpp(&self) -> Result<Vec<NodeInfo>, BackendError> {
        Ok(vec![self.node()])
    }

    async fn open_hidpp(&self, _node: &NodeInfo) -> Result<Option<Arc<HidppChannel>>, BackendError> {
        let (incoming_tx, incoming_rx) = mpsc::unbounded_channel();
        let channel = ScriptedChannel {
            features: Arc::clone(&self.features),
            handler: Arc::clone(&self.handler),
            written: Arc::clone(&self.written),
            incoming_tx,
            incoming_rx: AsyncMutex::new(incoming_rx),
        };
        let channel = HidppChannel::from_raw_channel(channel)
            .await
            .map_err(|error| BackendError::Backend(format!("{error:?}")))?;
        Ok(Some(Arc::new(channel)))
    }

    async fn open_raw_writer(&self, _node: &NodeInfo) -> Result<Box<dyn RawWriter>, BackendError> {
        Err(BackendError::Disconnected)
    }

    fn watch(&self) -> Result<HotplugStream, BackendError> {
        Ok(Box::new(futures_lite::stream::empty::<HotplugEvent>()))
    }
}

impl ScriptedBackend {
    fn node(&self) -> NodeInfo {
        NodeInfo {
            id: NodeId::from("scripted-node".to_string()),
            vendor_id: VENDOR,
            product_id: PRODUCT,
            usage_page: 0xff00,
            usage_id: 0x0001,
            name: "scripted mouse".to_string(),
            manufacturer: None,
            serial_number: None,
        }
    }
}

/// Assemble a backend that exposes `features` (id → HID++ index) and answers
/// feature calls through `handler`. Returns the backend plus the shared log of
/// every report the write layer sends.
fn scripted_backend(
    features: Vec<(u16, u8)>,
    handler: impl Fn(u16, u8, &[u8; 16]) -> Reply + Send + Sync + 'static,
) -> (ScriptedBackend, Arc<Mutex<Vec<Vec<u8>>>>) {
    let written = Arc::new(Mutex::new(Vec::new()));
    let backend = ScriptedBackend {
        features: Arc::new(features),
        handler: Arc::new(handler),
        written: Arc::clone(&written),
    };
    (backend, written)
}

/// The route every test drives: a directly-attached device.
fn direct_route() -> DeviceRoute {
    DeviceRoute::Direct {
        vendor_id: VENDOR,
        product_id: PRODUCT,
    }
}

// ---------------------------------------------------------------------------
// Assertion helpers over the recorded reports.
// ---------------------------------------------------------------------------

/// The first recorded report sent to `feature_index` invoking `function`.
fn sent_report(written: &Arc<Mutex<Vec<Vec<u8>>>>, feature_index: u8, function: u8) -> Option<Vec<u8>> {
    written
        .lock()
        .unwrap()
        .iter()
        .find(|report| report.len() >= 4 && report[2] == feature_index && (report[3] >> 4) == function)
        .cloned()
}

/// Whether any report was sent to `feature_index` invoking `function`.
fn any_sent(written: &Arc<Mutex<Vec<Vec<u8>>>>, feature_index: u8, function: u8) -> bool {
    sent_report(written, feature_index, function).is_some()
}

// ---------------------------------------------------------------------------
// SmartShift: tunable torque is gated on the device's capability bit.
// ---------------------------------------------------------------------------

/// A device whose Enhanced SmartShift does not advertise tunable torque must
/// never receive a non-zero torque byte: the mode and threshold still apply,
/// but the torque field on the wire is the zero "do not change" sentinel.
#[tokio::test]
async fn smartshift_without_tunable_torque_sends_zero_torque() {
    // index 1 hosts Enhanced SmartShift.
    let (backend, written) = scripted_backend(vec![(SMARTSHIFT_ENHANCED, 0x01)], |_id, function, _args| {
        match function {
            // getCapabilities: the capability byte has the tunable-torque bit
            // clear.
            0 => Reply::Short([0x00, 0x00, 0x00]),
            // getRatchetControlMode: currently free-spin, threshold 20, no
            // torque. Free-spin differs from the ratchet we request, so the
            // write proceeds.
            1 => Reply::Short([0x01, 20, 0x00]),
            // setRatchetControlMode acknowledgement (ratchet mode echoed).
            2 => Reply::Short([0x02, 20, 0x00]),
            _ => Reply::Error(9),
        }
    });

    let desired = SmartShiftStatus {
        mode: SmartShiftMode::Ratchet,
        auto_disengage: SmartShiftAutoDisengage::Threshold(SmartShiftThreshold::try_new(20).unwrap()),
        tunable_torque: Some(TunableTorque::try_new(50).unwrap()),
    };

    let result = set_smartshift(&backend, &direct_route(), desired).await;
    assert!(result.is_ok(), "write should apply mode and threshold: {result:?}");

    let set = sent_report(&written, 0x01, 2).expect("a setRatchetControlMode report was sent");
    // Wire payload: [4]=mode, [5]=auto-disengage, [6]=tunable torque.
    assert_eq!(set[4], 0x02, "ratchet mode is written");
    assert_eq!(set[5], 20, "the requested threshold is written");
    assert_eq!(
        set[6], 0x00,
        "torque must be the zero sentinel when the device does not advertise it"
    );
}

/// When the SmartShift capability read itself fails, the write must fail rather
/// than guess a torque value — and no torque byte may reach the wire.
#[tokio::test]
async fn smartshift_capability_read_failure_fails_the_write() {
    let (backend, written) = scripted_backend(vec![(SMARTSHIFT_ENHANCED, 0x01)], |_id, function, _args| {
        match function {
            // getCapabilities fails outright.
            0 => Reply::Error(9),
            // getRatchetControlMode reports free-spin so a write is attempted.
            1 => Reply::Short([0x01, 20, 0x00]),
            // If the (unfixed) path ignores the failed read it would land here.
            2 => Reply::Short([0x02, 20, 50]),
            _ => Reply::Error(9),
        }
    });

    let desired = SmartShiftStatus {
        mode: SmartShiftMode::Ratchet,
        auto_disengage: SmartShiftAutoDisengage::Threshold(SmartShiftThreshold::try_new(20).unwrap()),
        tunable_torque: Some(TunableTorque::try_new(50).unwrap()),
    };

    let result = set_smartshift(&backend, &direct_route(), desired).await;
    assert!(
        result.is_err(),
        "a failed capability read must fail the write, not proceed: {result:?}"
    );

    // No ratchet write carrying a non-zero torque may have reached the device.
    let torque_write = sent_report(&written, 0x01, 2).filter(|report| report[6] != 0);
    assert!(
        torque_write.is_none(),
        "no torque byte may be written when the capability read failed",
    );
}

// ---------------------------------------------------------------------------
// DPI: per-axis DPI and lift-off distance are gated on the sensor's capability
// bits, not on the values a parameters read-back returns.
// ---------------------------------------------------------------------------

/// On an extended-DPI sensor that advertises neither an independent Y axis nor
/// lift-off control, a DPI write must send Y and lift-off as zero even when the
/// device's parameters read-back reported non-zero values for them.
#[tokio::test]
async fn dpi_without_axis_or_lod_capability_sends_zero_fields() {
    // index 3 hosts extended DPI; the original adjustable feature is absent.
    let (backend, written) = scripted_backend(vec![(EXTENDED_DPI, 0x03)], |_id, function, _args| {
        match function {
            // getSensorCapabilities: sensor echoed as 0, no capability bits set.
            1 => Reply::Short([0x00, 0x01, 0x00]),
            // getSensorDpiRanges (X): the supported values 1600, 800, 3200.
            2 => Reply::Long([
                0x00, 0x00, 0x00, // echoed sensor, direction, page
                0x06, 0x40, // 1600
                0x03, 0x20, // 800
                0x0c, 0x80, // 3200
                0x00, 0x00, // terminator
                0x00, 0x00, 0x00, 0x00, 0x00,
            ]),
            // getSensorDpiParameters: current X is 1600 and the device reports
            // a non-zero Y and a High lift-off even though it advertises
            // neither capability.
            5 => Reply::Long([
                0x00, // sensor
                0x06, 0x40, // dpi_x = 1600
                0x06, 0x40, // default_dpi_x
                0x06, 0x40, // dpi_y = 1600 (reported but not a capability)
                0x06, 0x40, // default_dpi_y
                0x03, // lod = High (reported but not a capability)
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            ]),
            // setSensorDpiParameters acknowledgement.
            6 => Reply::Short([0x00, 0x00, 0x00]),
            _ => Reply::Error(9),
        }
    });

    let result = set_dpi(&backend, &direct_route(), Dpi::new(1600)).await;
    assert!(result.is_ok(), "an in-range DPI write should succeed: {result:?}");

    // setSensorDpiParameters is a long report: [4]=sensor, [5..7]=dpi_x,
    // [7..9]=dpi_y, [9]=lift-off distance.
    let set = sent_report(&written, 0x03, 6).expect("a setSensorDpiParameters report was sent");
    assert_eq!([set[5], set[6]], [0x06, 0x40], "dpi_x carries the requested value");
    assert_eq!(
        [set[7], set[8]],
        [0x00, 0x00],
        "dpi_y must be zero when the sensor has no independent Y axis"
    );
    assert_eq!(
        set[9], 0x00,
        "lift-off distance must be zero when the sensor has no lift-off control"
    );
}

/// A requested DPI outside the device-reported supported list is rejected and
/// nothing is written — the value is not clamped onto the device.
#[tokio::test]
async fn dpi_outside_supported_list_is_rejected_without_writing() {
    // index 2 hosts the original adjustable DPI feature.
    let (backend, written) = scripted_backend(vec![(ADJUSTABLE_DPI, 0x02)], |_id, function, _args| {
        match function {
            // getSensorDpiList: supported values are 800, 1600, 3200.
            1 => Reply::Long([
                0x00, // echoed sensor
                0x03, 0x20, // 800
                0x06, 0x40, // 1600
                0x0c, 0x80, // 3200
                0x00, 0x00, // terminator
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            ]),
            // getSensorDpi read-back (only reached if a write happens).
            2 => Reply::Short([0x00, 0x13, 0x88]),
            // setSensorDpi acknowledgement.
            3 => Reply::Short([0x00, 0x00, 0x00]),
            _ => Reply::Error(9),
        }
    });

    // 5000 is not in {800, 1600, 3200}. The device must reject it and leave
    // the sensor untouched — the signals checked here are that the call
    // fails and that no setSensorDpi report reached the wire (a clamp, by
    // contrast, writes a nearest supported value and returns success). The
    // error's concrete type and message are the solution's to choose, so they
    // are not asserted here.
    let result = set_dpi(&backend, &direct_route(), Dpi::new(5000)).await;
    assert!(
        result.is_err(),
        "an unsupported DPI must be rejected, not written: {result:?}"
    );
    assert!(
        !any_sent(&written, 0x02, 3),
        "no setSensorDpi report may be written for an unsupported value"
    );
}

/// After the single re-write, a device that still reads back a different value
/// must surface a not-applied failure carrying the value the device kept — not
/// a silent success. A failed read-back (as opposed to a mismatch) still
/// succeeds.
#[tokio::test]
async fn dpi_readback_mismatch_fails_but_readback_error_succeeds() {
    // Case A: the device accepts the write but always reads back 800.
    let (backend, _written) = scripted_backend(vec![(ADJUSTABLE_DPI, 0x02)], |_id, function, _args| {
        match function {
            // getSensorDpiList: 800 and 1600 are both supported.
            1 => Reply::Long([
                0x00, 0x03, 0x20, // 800
                0x06, 0x40, // 1600
                0x00, 0x00, // terminator
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            ]),
            // getSensorDpi always reports 800, never the requested 1600.
            2 => Reply::Short([0x00, 0x03, 0x20]),
            // setSensorDpi acknowledgement.
            3 => Reply::Short([0x00, 0x00, 0x00]),
            _ => Reply::Error(9),
        }
    });

    // The signal checked here is that a write the device never actually
    // took is reported as a failure rather than a silent success. The concrete
    // error type and the way it carries the kept value are the solution's to
    // choose, so only the failure outcome is asserted here.
    let result = set_dpi(&backend, &direct_route(), Dpi::new(1600)).await;
    assert!(
        result.is_err(),
        "a persistent read-back mismatch must not be reported as success: {result:?}"
    );

    // Case B: the read-back itself errors. The acknowledged write stands.
    let (backend, _written) = scripted_backend(vec![(ADJUSTABLE_DPI, 0x02)], |_id, function, _args| {
        match function {
            1 => Reply::Long([
                0x00, 0x03, 0x20, // 800
                0x06, 0x40, // 1600
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            ]),
            // The read-back fails rather than reporting a value.
            2 => Reply::Error(4),
            3 => Reply::Short([0x00, 0x00, 0x00]),
            _ => Reply::Error(9),
        }
    });

    let result = set_dpi(&backend, &direct_route(), Dpi::new(1600)).await;
    assert!(
        result.is_ok(),
        "a failed read-back must leave the acknowledged write standing: {result:?}"
    );
}

// ---------------------------------------------------------------------------
// Value range: tunable torque is a 1..=100 percentage, and an out-of-range
// device reading surfaces as an error instead of being dropped.
// ---------------------------------------------------------------------------

/// `TunableTorque` accepts only `1..=100`, and a status reply whose torque byte
/// exceeds that range surfaces as an error rather than a dropped value.
#[tokio::test]
async fn tunable_torque_range_is_bounded_and_out_of_range_reading_errors() {
    // Construction bounds.
    assert!(TunableTorque::try_new(0).is_err(), "zero is not a torque level");
    assert!(
        TunableTorque::try_new(101).is_err(),
        "a value above 100 percent is out of range"
    );
    assert!(TunableTorque::try_new(1).is_ok(), "1 percent is the minimum level");
    assert!(TunableTorque::try_new(100).is_ok(), "100 percent is the maximum level");

    // A device status reply whose torque byte is 150 is not a defined level.
    let (backend, _written) = scripted_backend(vec![(SMARTSHIFT_ENHANCED, 0x01)], |_id, function, _args| {
        match function {
            // getRatchetControlMode: ratchet, threshold 20, torque byte 150.
            1 => Reply::Short([0x02, 20, 150]),
            _ => Reply::Error(9),
        }
    });

    let status = get_smartshift_status(&backend, &direct_route()).await;
    assert!(
        status.is_err(),
        "a torque reading above the defined range must error, not be dropped to none: {status:?}"
    );
}

// ---------------------------------------------------------------------------
// Capability reply integrity: a capabilities reply that echoes a different
// sensor than the one asked about must be rejected.
// ---------------------------------------------------------------------------

/// A sensor-capabilities reply tagged with a different sensor index than the
/// one queried must be rejected, and no DPI parameters may be written off the
/// mismatched reply.
#[tokio::test]
async fn sensor_capabilities_echo_mismatch_is_rejected() {
    let (backend, written) = scripted_backend(vec![(EXTENDED_DPI, 0x03)], |_id, function, _args| {
        match function {
            // getSensorCapabilities for sensor 0 answers tagged as sensor 1.
            1 => Reply::Short([0x01, 0x01, 0x03]),
            // getSensorDpiRanges (X): the requested value is supported.
            2 => Reply::Long([
                0x00, 0x00, 0x00, 0x06, 0x40, // 1600
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            ]),
            // getSensorDpiParameters (reached only if the mismatch is ignored).
            5 => Reply::Long([
                0x00, 0x06, 0x40, 0x06, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00,
            ]),
            6 => Reply::Short([0x00, 0x00, 0x00]),
            _ => Reply::Error(9),
        }
    });

    let result = set_dpi(&backend, &direct_route(), Dpi::new(1600)).await;
    assert!(
        result.is_err(),
        "a capabilities reply for the wrong sensor must be rejected: {result:?}"
    );
    assert!(
        !any_sent(&written, 0x03, 6),
        "no DPI parameters may be written off a mismatched capabilities reply"
    );
}
