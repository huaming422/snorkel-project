#!/usr/bin/env bash
# Test-setup for openlogi-fix-device-capability-writes. The image bakes the full
# dependency closure at the base commit and pre-warms `cargo test --no-run` for
# the whole workspace (minus openlogi-desktop), so the behavioral verifier only
# recompiles its injected integration test plus the touched libs. No services to
# start, no data to seed. The agent phase is offline; everything the solver needs
# to build and run the focused tests is already in the image.

set -euo pipefail

echo "[test-setup] Rust version:    $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:   $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root:  /repo/OpenLogi"
echo "[test-setup] Setup complete."
