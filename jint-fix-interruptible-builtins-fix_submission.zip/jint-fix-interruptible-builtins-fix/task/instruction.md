## Task

we embed the engine to run untrusted user scripts, and we lean on the configured execution limits (time, statement count, memory) to stop anything that runs away. that mostly works, but some of the big built-in string and array operations ignore those limits completely. feed one a large input and it hangs for a few seconds and then the whole host process falls over with an out-of-memory crash, instead of the script getting stopped with a catchable error. a script running in the sandbox shouldn't be able to take the host down like that. dig in and fix it.
