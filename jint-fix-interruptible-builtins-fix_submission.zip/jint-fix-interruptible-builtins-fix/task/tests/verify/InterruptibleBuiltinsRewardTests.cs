// Reward verifier for jint-fix-interruptible-builtins.
//
// This file is copied into the repo's Jint.Tests project by verify.py and run
// with `dotnet test --filter`. Every assertion is BEHAVIORAL: it exercises only
// the public `new Engine(...)` / `engine.Evaluate(...)` surface and the three
// catchable constraint exceptions (Jint.Runtime.*) plus JavaScriptException.
// It never references any implementation-private symbol introduced by the fix
// (constraint-check-interval constants, size-cap helpers, string-builder types,
// method signatures), so any valid fix that makes the bulk built-ins
// interruptible and converts the oversize case into a catchable error passes it,
// regardless of mechanism.
//
// Transcribed from the PR author's Jint.Tests/Runtime/ExecutionConstraintTests.cs
// additions (issue #2486). One method
// (SmallOperationsUnderGenerousBudgetComplete) is added for the
// small_input_no_false_limit pass_to_pass criterion.
//
// `Engine` (namespace Jint) resolves through the enclosing-namespace chain
// Jint.Tests.Reward -> Jint.Tests -> Jint, mirroring the maintainer's own file.

using Jint.Constraints;
using Jint.Runtime;

namespace Jint.Tests.Reward;

public class InterruptibleBuiltinsRewardTests
{
    // criterion: rangeerror_on_oversize_pad (fail_to_pass)
    // https://github.com/sebastienros/jint/issues/2486
    [Fact]
    public void ShouldThrowRangeErrorWhenPadStartExceedsMaxStringLength()
    {
        // The result length (2147483647) exceeds the maximum string size, so the
        // fix must convert a would-be uncatchable OutOfMemoryException into a
        // catchable JS error (RangeError, per spec StringPad) without any
        // constraints set.
        //
        // The assertion is message-agnostic on purpose: it checks the error TYPE
        // observable from script (`e instanceof RangeError`), not the exact
        // message text, so any valid fix is accepted regardless of the wording it
        // uses. We probe from inside a JS try/catch because an uncatchable CLR
        // OutOfMemoryException (the pre-fix behavior) is NOT a JS-catchable throw:
        // it propagates out of Evaluate rather than being caught here, so the
        // unfixed engine fails this test by never producing "rangeerror".
        var engine = new Engine();
        var result = engine.Evaluate(
            "try { 'x'.padStart(2147483647); 'no-throw'; }" +
            " catch (e) { (e instanceof RangeError) ? 'rangeerror' : ('other:' + (e && e.name)); }");
        Assert.Equal("rangeerror", result.AsString());
    }

    // criterion: mem_limit_interrupts_padend (fail_to_pass)
    // https://github.com/sebastienros/jint/issues/2486
    [Fact]
    public void ShouldLimitStringSizeForPadEnd()
    {
        // The result (536870911) is below the size cap, so it must be built
        // incrementally and the memory limit must be able to interrupt it instead
        // of allocating ~1 GB up front.
        var engine = new Engine(o => o.LimitMemory(4_000_000));
        Assert.Throws<MemoryLimitExceededException>(() => engine.Evaluate("'x'.padEnd(536870911, 'ab')"));
    }

    // criterion: mem_limit_interrupts_array_from (fail_to_pass)
    // https://github.com/sebastienros/jint/issues/2486
    [Fact]
    public void ShouldLimitArraySizeForArrayFrom()
    {
        var engine = new Engine(o => o.LimitMemory(4_000_000));
        Assert.Throws<MemoryLimitExceededException>(() => engine.Evaluate("Array.from({ length: 50000000 });"));
    }

    // criterion: stmt_limit_interrupts_array_ops (fail_to_pass) -- sort half
    [Fact]
    public void ShouldLimitArraySizeForSort()
    {
        // The element-collection loop in sort is interruptible: a low statement
        // budget aborts it.
        var engine = new Engine(o => o.MaxStatements(1_000));
        Assert.Throws<StatementsCountOverflowException>(() => engine.Evaluate("new Array(50000000).sort();"));
    }

    // criterion: stmt_limit_interrupts_array_ops (fail_to_pass) -- forEach half
    [Fact]
    public void ShouldLimitArraySizeForForEach()
    {
        // forEach over a huge (sparse) array must be interruptible even though the
        // callback never runs for holes. A sparse array is used so the guard
        // exercised is forEach's own loop, not fill's (fill on a dense 50M array
        // would trip the limit before forEach was ever reached).
        var engine = new Engine(o => o.MaxStatements(1_000));
        Assert.Throws<StatementsCountOverflowException>(() => engine.Evaluate("new Array(50000000).forEach(function () {});"));
    }

    // ADVISORY / INFORMATIONAL — NOT a correctness gate.
    // criterion: spec_compliant_fillstring_ordering (rubric, non-gating)
    //
    // This probe runs under dotnet test and its outcome lands in the TRX, but no
    // pytest assertion in verify.py consumes it, so it does not affect the f2p
    // correctness score. The fillString side-effect ordering it checks is a spec
    // nicety (ECMAScript StringPad) that is orthogonal to the OOM/interruptibility
    // contract base.md states; it is credited by the judge/rubric.json
    // "spec_compliant_fillstring_ordering" criterion rather than gated here.
    [Fact]
    public void PadStartEvaluatesFillStringAfterLengthCheck()
    {
        // Per spec (https://tc39.es/ecma262/#sec-stringpad) the fillString is
        // resolved only after the maxLength <= stringLength early return, so its
        // ToString side effect must not run here.
        var engine = new Engine();
        var result = engine.Evaluate(
            "var sideEffect = false;" +
            "var fill = { toString() { sideEffect = true; return '0'; } };" +
            "'abc'.padStart(2, fill);" +
            "sideEffect;");
        Assert.False(result.AsBoolean());
    }

    // criterion: join_releases_stack_after_interrupt (fail_to_pass)
    [Fact]
    public void JoinReleasesJoinStackWhenInterrupted()
    {
        // Regression: when a constraint interrupts a large join mid-loop, the
        // array must not be left on the engine's long-lived join stack -- otherwise
        // a later join of the same array would wrongly return "" via false
        // cyclic-reference detection.
        var engine = new Engine(o => o.MaxStatements(10_000_000));
        engine.Evaluate("var a = []; for (var i = 0; i < 20000; i++) a[i] = i;");

        var maxStatements = engine.Constraints.Find<MaxStatementsConstraint>()!;
        maxStatements.MaxStatements = 1;
        engine.Constraints.Reset();
        Assert.Throws<StatementsCountOverflowException>(() => engine.Evaluate("a.join(',')"));

        // With a generous budget the same array must join correctly (not the empty
        // string).
        maxStatements.MaxStatements = 10_000_000;
        engine.Constraints.Reset();
        Assert.StartsWith("0,1,2,3,", engine.Evaluate("a.join(',')").AsString());
    }

    // criterion: breadth_native_callbacks_interruptible (fail_to_pass) -- String.raw
    [Fact]
    public void ShouldLimitStringSizeForStringRaw()
    {
        var engine = new Engine(o => o.LimitMemory(4_000_000));
        Assert.Throws<MemoryLimitExceededException>(() => engine.Evaluate("String.raw({ raw: { length: 50000000 } });"));
    }

    // criterion: breadth_native_callbacks_interruptible (fail_to_pass) -- native string iterator
    [Fact]
    public void ShouldLimitArrayFromWithNativeIterator()
    {
        // Array.from over a native (statement-free) string iterator must be
        // interruptible via the shared iterator-protocol guard; the string iterator
        // runs no JS statements per element.
        var engine = new Engine(o => o.MaxStatements(10_000_000));
        engine.Evaluate("var s = 'x'; for (var i = 0; i < 17; i++) s += s;"); // 131072 chars

        var maxStatements = engine.Constraints.Find<MaxStatementsConstraint>()!;
        maxStatements.MaxStatements = 1;
        engine.Constraints.Reset();
        Assert.Throws<StatementsCountOverflowException>(() => engine.Evaluate("Array.from(s);"));
    }

    // criterion: breadth_native_callbacks_interruptible (fail_to_pass) -- Object.keys
    [Fact]
    public void ShouldLimitObjectKeysForLargeArray()
    {
        // Object.keys is a pure native enumeration with no JS callback to
        // self-throttle; it must be interruptible by the constraint check in
        // EnumerableOwnProperties.
        var engine = new Engine(o => o.MaxStatements(10_000_000));
        engine.Evaluate("var a = []; for (var i = 0; i < 30000; i++) a[i] = i;");

        var maxStatements = engine.Constraints.Find<MaxStatementsConstraint>()!;
        maxStatements.MaxStatements = 1;
        engine.Constraints.Reset();
        Assert.Throws<StatementsCountOverflowException>(() => engine.Evaluate("Object.keys(a);"));
    }

    // criterion: breadth_native_callbacks_interruptible (fail_to_pass) -- Map.forEach native callback
    [Fact]
    public void ShouldLimitMapForEachWithNativeCallback()
    {
        // A native (CLR) callback does not self-throttle via statement checks, so
        // Map.prototype.forEach must be interruptible by its own constraint check.
        var engine = new Engine(o => o.MaxStatements(10_000_000));
        engine.Evaluate("var m = new Map(); for (var i = 0; i < 30000; i++) m.set(i, i);");

        var maxStatements = engine.Constraints.Find<MaxStatementsConstraint>()!;
        maxStatements.MaxStatements = 1;
        engine.Constraints.Reset();
        Assert.Throws<StatementsCountOverflowException>(() => engine.Evaluate("m.forEach(Math.max);"));
    }

    // criterion: pad_correctness (pass_to_pass)
    [Fact]
    public void PadStartAndPadEndProduceCorrectResults()
    {
        var engine = new Engine();
        Assert.Equal("005", engine.Evaluate("'5'.padStart(3, '0')").AsString());
        Assert.Equal("500", engine.Evaluate("'5'.padEnd(3, '0')").AsString());
        Assert.Equal("ab", engine.Evaluate("'ab'.padStart(1)").AsString());
        Assert.Equal("    x", engine.Evaluate("'x'.padStart(5)").AsString());
        Assert.Equal("x    ", engine.Evaluate("'x'.padEnd(5)").AsString());
        // Empty fill string returns the input unchanged.
        Assert.Equal("x", engine.Evaluate("'x'.padEnd(5, '')").AsString());
        Assert.Equal("1231231abc", engine.Evaluate("'abc'.padStart(10, '123')").AsString());
        Assert.Equal("abc1231231", engine.Evaluate("'abc'.padEnd(10, '123')").AsString());
    }

    // criterion: small_input_no_false_limit (pass_to_pass)
    [Fact]
    public void SmallOperationsUnderGenerousBudgetComplete()
    {
        // Ordinary small operations under a generous statement budget must still
        // complete and return correct values -- guards against an over-correction
        // that checks on every iteration and trips the limit immediately.
        var engine = new Engine(o => o.MaxStatements(1_000_000));
        Assert.Equal("1231231abc", engine.Evaluate("'abc'.padStart(10, '123')").AsString());
        Assert.Equal("1,2,3", engine.Evaluate("[1, 2, 3].join(',')").AsString());
        Assert.Equal("x    ", engine.Evaluate("'x'.padEnd(5)").AsString());
    }
}
