#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier runs (set -euo pipefail inherited).
# Exports the import paths the repo backend expects and sanity-checks that the
# baked repo environment can import the modules under test. Must run with the
# network cut (smoke Check 3 sources it under `docker run --network none`).
#
# The repo venv at /opt/venv is already fully provisioned at image-build time
# (`uv sync --frozen --group dev`), and deerflow-harness / deerflow-extension-api
# are EDITABLE workspace members, so the backend source is imported live from
# /repo/deer-flow/backend. A fix that edits a file inside those editable
# packages is therefore picked up without any re-install. We deliberately do NOT
# re-run `uv sync` here: with the network cut it would try to rebuild the
# editable wheels (their build backend is not in the offline cache) and fail,
# even though the already-installed environment is correct and complete.
set -euo pipefail

REPO_DIR="/repo/deer-flow"
cd "$REPO_DIR/backend"

export REPO_NAME=deer-flow

# The backend test suite makes `app` and `deerflow` importable from any cwd via
# tests/conftest.py (sys.path inserts for backend/ and backend/scripts). The
# verifier is self-contained and sets its own sys.path, but export these too so
# a repo-native pytest invocation also resolves them.
export PYTHONPATH="${REPO_DIR}/backend:${REPO_DIR}/backend/scripts${PYTHONPATH:+:${PYTHONPATH}}"
export PYTHONIOENCODING=utf-8
export PYTHONUTF8=1

# Sanity: the baked repo venv can import the modules under test offline, and the
# editable source reflects whatever the submission changed under packages/.
/opt/venv/bin/python -c "import aiosqlite, sqlalchemy; import deerflow.persistence.user.model" \
    && echo "deer-flow verifier env ready"
