"""Behavioral checks for the account-creation failure-reporting fix.

Every check drives the pre-existing, stable public method
``SQLiteUserRepository.create_user`` against a real local (aiosqlite) engine
built through the repository's own persistence lifecycle
(``init_engine`` / ``get_session_factory`` / ``close_engine``), exactly as the
repo's own ``tests/test_auth.py`` does. Nothing here imports a helper the fix
may invent.

The checks assert only on pin-safe signals:
  * NEGATIVE: the failure must not blame an address that is not registered,
    and a non-identity failure must not be falsely attributed to the identity
    linkage. These reject the unfixed behavior and the stringify-the-wrapper
    trap without demanding any particular wording.
  * DATA-DRIVEN POSITIVE: a genuine email collision must still name the exact
    address the test supplied (runtime data the method echoes), guarding
    against an over-correction that lumps every write failure into one neutral
    message.
  * NON-DUPLICATE: a failure outside the duplicate-account contract (a NOT
    NULL / CHECK / foreign-key error) must say what actually went wrong -- it
    must not be blamed on an unregistered email nor dressed up as an "already
    exists" duplicate. Surfacing the original exception or translating it to an
    accurate, non-email failure both satisfy this floor; the exception type is
    the handler's choice, not a pinned requirement.
Whether a message names the real cause in the nicest words is judged
separately; these checks fix the behavioral floor, not the phrasing.

The non-local-backend branch is exercised by feeding a driver-shaped error
(whose structured constraint name lives one level down the cause chain,
mirroring how the async adapter re-wraps its driver error) through the same
``create_user`` via a patched commit, so the branch is tested through the
public method rather than by importing classification internals.
"""

from __future__ import annotations

import asyncio
import sqlite3
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from uuid import uuid4

import pytest

# ---------------------------------------------------------------------------
# Import context. This file runs out-of-tree (not under backend/tests), so the
# repo conftest that normally wires sys.path is not auto-loaded. Replicate the
# two inserts it performs, and pre-mock the one module the repo conftest guards
# against a circular import, before importing any ``app`` module. test-setup.sh
# also exports PYTHONPATH as a backstop.
# ---------------------------------------------------------------------------
_BACKEND = Path("/repo/deer-flow/backend")
for _p in (str(_BACKEND), str(_BACKEND / "scripts")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

if "deerflow.subagents.executor" not in sys.modules:
    from unittest.mock import MagicMock

    sys.modules["deerflow.subagents.executor"] = MagicMock()

from app.gateway.auth.models import User  # noqa: E402
from app.gateway.auth.repositories import sqlite as sqlite_repo  # noqa: E402
from app.gateway.auth.repositories.sqlite import SQLiteUserRepository  # noqa: E402
from deerflow.persistence.engine import (  # noqa: E402
    close_engine,
    get_session_factory,
    init_engine,
)
from sqlalchemy.exc import IntegrityError  # noqa: E402


def _driver_shaped_integrity_error(constraint_name: str, sqlstate: str = "23505") -> IntegrityError:
    """A commit-time IntegrityError shaped the way the async Postgres adapter
    delivers one: the directly-attached ``orig`` wrapper carries only the
    status code, while the real driver error that knows the constraint name is
    one level down the cause chain. A text-only classifier cannot see the
    constraint name here, so a driver-aware fix handles it while a
    string-matching one cannot. Built on a genuine ``IntegrityError`` so it flows
    through the real ``except`` branch unchanged.
    """
    wrapper = SimpleNamespace(pgcode=sqlstate, sqlstate=sqlstate)
    wrapper.__cause__ = SimpleNamespace(constraint_name=constraint_name)
    return IntegrityError("INSERT INTO users ...", {}, orig=wrapper)


def _run(scenario) -> None:
    """Run an async scenario with a fresh engine, always tearing it down."""
    asyncio.run(scenario())


def _assert_non_duplicate_cause_named(exc: BaseException, *, email: str) -> None:
    """Assert a non-duplicate failure (NOT NULL / CHECK / FK) says what
    actually went wrong, independent of the exception TYPE the handler chooses.

    The behavioral floor base.md states is: such a failure must not be blamed
    on the (unregistered) ``email``, must not be dressed up as an
    "already exists"/"already registered" duplicate, and must name the real
    cause. Propagating the original ``IntegrityError`` satisfies this (it
    carries the driver's column/constraint message); translating it to an
    accurate non-email failure satisfies it too (its text names the violated
    column/constraint). The exception type itself is the handler's choice and
    is deliberately not pinned.
    """
    message = str(exc)
    lowered = message.lower()
    assert email not in message, (
        f"non-duplicate failure misreported against an unregistered email: {message!r}"
    )
    assert "already registered" not in lowered and "already exists" not in lowered, (
        f"non-duplicate failure dressed up as an 'already exists' duplicate: {message!r}"
    )
    names_cause = isinstance(exc, IntegrityError) or any(
        token in lowered for token in ("system_role", "not null", "constraint")
    )
    assert names_cause, (
        f"non-duplicate failure does not name the real cause (column/constraint): {message!r}"
    )


# ── fail_to_pass: an SSO-identity collision is not blamed on an unrelated email


def test_oauth_identity_collision_not_blamed_on_email(tmp_path):
    async def _scenario() -> None:
        url = f"sqlite+aiosqlite:///{tmp_path}/scratch.db"
        await init_engine("sqlite", url=url, sqlite_dir=str(tmp_path))
        try:
            repo = SQLiteUserRepository(get_session_factory())
            first = User(
                email="linked-a@test.com",
                password_hash=None,
                system_role="user",
                oauth_provider="github",
                oauth_id="dup-123",
            )
            await repo.create_user(first)

            # Same (provider, oauth_id) pair, different email. The two logins
            # do not share an email, so an email-named error would be wrong --
            # which is exactly the reported misbehavior.
            second = User(
                email="linked-b@test.com",
                password_hash=None,
                system_role="user",
                oauth_provider="github",
                oauth_id="dup-123",
            )
            with pytest.raises(ValueError) as caught:
                await repo.create_user(second)
            message = str(caught.value)
            assert "linked-b@test.com" not in message, (
                f"identity collision misreported against an unrelated email: {message!r}"
            )
        finally:
            await close_engine()

    _run(_scenario)


# ── fail_to_pass: a duplicate primary key is attributed to neither email nor
#    the identity linkage (the stringify-the-wrapper trap produces the latter)


def test_duplicate_primary_key_not_misreported_as_oauth_or_email(tmp_path):
    async def _scenario() -> None:
        url = f"sqlite+aiosqlite:///{tmp_path}/scratch.db"
        await init_engine("sqlite", url=url, sqlite_dir=str(tmp_path))
        try:
            repo = SQLiteUserRepository(get_session_factory())
            shared_id = uuid4()
            await repo.create_user(
                User(id=shared_id, email="first@test.com", password_hash="h", system_role="user")
            )

            # Same id, different email: the pre-check clears the (different)
            # email, so the only rule the insert can violate is the primary
            # key -- never the identity index. Matching the wrapper's text would
            # falsely call this an identity conflict (the INSERT column list
            # names the identity columns); the unfixed handler falsely calls it
            # email.
            duplicate = User(
                id=shared_id, email="second@test.com", password_hash="h", system_role="user"
            )
            with pytest.raises(ValueError) as caught:
                await repo.create_user(duplicate)
            message = str(caught.value)
            assert "OAuth" not in message, (
                f"primary-key violation misreported as an identity/OAuth conflict: {message!r}"
            )
            assert "second@test.com" not in message, (
                f"primary-key violation misreported as an email conflict: {message!r}"
            )
        finally:
            await close_engine()

    _run(_scenario)


# ── fail_to_pass: a non-uniqueness failure names the real cause ──────────────


def test_non_uniqueness_failure_names_real_cause(tmp_path):
    async def _scenario() -> None:
        url = f"sqlite+aiosqlite:///{tmp_path}/scratch.db"
        await init_engine("sqlite", url=url, sqlite_dir=str(tmp_path))
        try:
            repo = SQLiteUserRepository(get_session_factory())
            # A NOT NULL violation is not an "already exists" condition. The
            # failure must say what actually went wrong: it must not be pinned
            # on the (unregistered) email, nor dressed up as an "already
            # exists"/"already registered" duplicate, and it must name the real
            # cause (the missing column / constraint). Surfacing the original
            # IntegrityError or translating it to an accurate non-email failure
            # both satisfy this floor -- the exception type is the handler's
            # choice, so assert the behavior, not the type.
            not_null = IntegrityError(
                "INSERT INTO users ...",
                {},
                orig=sqlite3.IntegrityError("NOT NULL constraint failed: users.system_role"),
            )
            with patch.object(sqlite_repo.AsyncSession, "commit", side_effect=not_null):
                with pytest.raises(Exception) as caught:
                    await repo.create_user(
                        User(email="x@test.com", password_hash="h", system_role="user")
                    )
            _assert_non_duplicate_cause_named(caught.value, email="x@test.com")
        finally:
            await close_engine()

    _run(_scenario)


# ── fail_to_pass: an email collision that races the pre-check still names the
#    supplied email (guards against an over-correction to a neutral fallback)


def test_email_race_still_reports_email(tmp_path):
    async def _scenario() -> None:
        url = f"sqlite+aiosqlite:///{tmp_path}/scratch.db"
        await init_engine("sqlite", url=url, sqlite_dir=str(tmp_path))
        try:
            repo = SQLiteUserRepository(get_session_factory())
            await repo.create_user(
                User(email="race@test.com", password_hash="h", system_role="user")
            )

            # Bypass the duplicate-email pre-check to simulate a second insert
            # racing past it; the email unique index then fires at commit and
            # the failure must still name the supplied email.
            racing = User(email="race@test.com", password_hash="h", system_role="user")
            with patch.object(sqlite_repo.AsyncSession, "scalar", return_value=None):
                with pytest.raises(ValueError, match="race@test.com"):
                    await repo.create_user(racing)
        finally:
            await close_engine()

    _run(_scenario)


# ── fail_to_pass: driver-shaped (non-local-backend) errors classify right ───


def test_postgres_shaped_exception_classified_through_create_user(tmp_path):
    async def _scenario() -> None:
        url = f"sqlite+aiosqlite:///{tmp_path}/scratch.db"
        await init_engine("sqlite", url=url, sqlite_dir=str(tmp_path))
        try:
            repo = SQLiteUserRepository(get_session_factory())

            def _make_user(email: str) -> User:
                return User(
                    email=email,
                    password_hash=None,
                    system_role="user",
                    oauth_provider="github",
                    oauth_id="pg-1",
                )

            # Identity-index constraint name on the cause chain: not blamed on
            # the (unrelated) email.
            with patch.object(
                sqlite_repo.AsyncSession,
                "commit",
                side_effect=_driver_shaped_integrity_error("idx_users_oauth_identity"),
            ):
                with pytest.raises(ValueError) as caught:
                    await repo.create_user(_make_user("pg-oauth@test.com"))
                assert "pg-oauth@test.com" not in str(caught.value), (
                    f"identity constraint misreported against the email: {caught.value!r}"
                )

            # Email-index constraint name: still names the supplied email.
            with patch.object(
                sqlite_repo.AsyncSession,
                "commit",
                side_effect=_driver_shaped_integrity_error("ix_users_email"),
            ):
                with pytest.raises(ValueError, match="pg-email@test.com"):
                    await repo.create_user(_make_user("pg-email@test.com"))

            # Some other unique constraint (primary key): attributed to neither
            # the identity linkage nor the (unregistered) email.
            with patch.object(
                sqlite_repo.AsyncSession,
                "commit",
                side_effect=_driver_shaped_integrity_error("users_pkey"),
            ):
                with pytest.raises(ValueError) as caught:
                    await repo.create_user(_make_user("pg-pk@test.com"))
                neutral = str(caught.value)
                assert "OAuth" not in neutral and "pg-pk@test.com" not in neutral, (
                    f"other unique constraint misattributed: {neutral!r}"
                )

            # A not-null status code (not a uniqueness violation) must say what
            # actually went wrong -- not blamed on the (unregistered) email and
            # not dressed up as an "already exists" duplicate. Either surfacing
            # the original error or translating it to an accurate non-email
            # failure satisfies the floor; the type is the handler's choice.
            with patch.object(
                sqlite_repo.AsyncSession,
                "commit",
                side_effect=_driver_shaped_integrity_error(
                    "users_system_role_not_null", sqlstate="23502"
                ),
            ):
                with pytest.raises(Exception) as caught:
                    await repo.create_user(_make_user("pg-notnull@test.com"))
                _assert_non_duplicate_cause_named(caught.value, email="pg-notnull@test.com")
        finally:
            await close_engine()

    _run(_scenario)


# ── pass_to_pass: happy path + ordinary duplicate-email pre-check unchanged ─


def test_happy_path_and_duplicate_email_precheck_unchanged(tmp_path):
    async def _scenario() -> None:
        url = f"sqlite+aiosqlite:///{tmp_path}/scratch.db"
        await init_engine("sqlite", url=url, sqlite_dir=str(tmp_path))
        try:
            repo = SQLiteUserRepository(get_session_factory())

            # Happy path: a fresh account is created and round-trips.
            created = await repo.create_user(
                User(
                    email="new@test.com",
                    password_hash="fakehash",
                    system_role="admin",
                    needs_setup=True,
                    token_version=3,
                )
            )
            assert created.needs_setup is True
            assert created.token_version == 3
            fetched = await repo.get_user_by_email("new@test.com")
            assert fetched is not None
            assert fetched.token_version == 3

            # Ordinary duplicate email is still rejected at the pre-check with
            # the email-specific message (unchanged behavior).
            with pytest.raises(ValueError, match="new@test.com"):
                await repo.create_user(
                    User(email="new@test.com", password_hash="h2", system_role="user")
                )
        finally:
            await close_engine()

    _run(_scenario)
