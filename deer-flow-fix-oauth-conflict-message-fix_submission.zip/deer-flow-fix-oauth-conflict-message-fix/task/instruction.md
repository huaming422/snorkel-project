## Task

We're getting confusing account-creation failures on the self-hosted gateway. Every so often creating a user blows up with "that email is already registered", except the email it names isn't registered to anyone. It's especially bad when two SSO logins turn out to be the same upstream person: those two logins don't even share an email, but we still get the "email already registered" error. And we've seen that same wording come back on create failures that have nothing to do with email at all.

It only happens when the account actually gets written, never on the earlier "is this email taken" check, so everyone keeps staring at the email field and can't tell what really collided. Can you dig in and make these failures actually say what went wrong instead of always blaming the email?

(There's an unrelated index-tuning note and a concurrency timing experiment floating around the same area; ignore those, not what this is about.)
