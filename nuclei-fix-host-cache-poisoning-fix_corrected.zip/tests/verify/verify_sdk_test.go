package nuclei_test

import (
	"context"
	"fmt"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"sync"
	"testing"

	nuclei "github.com/projectdiscovery/nuclei/v3/lib"
	"github.com/projectdiscovery/nuclei/v3/pkg/output"
	"github.com/stretchr/testify/require"
)

// This external test package exercises the embedded engine through its public
// SDK surface only (NewNucleiEngineCtx -> LoadTargets -> ExecuteCallbackWithCtx).
// It owns TestMain so it is the sole test file compiled into the package,
// insulating these assertions from any environment-gated TestMain the package
// otherwise ships.
func TestMain(m *testing.M) {
	os.Exit(m.Run())
}

// unresponsiveSkipMessage is the error text the engine puts on the skip event
// it emits for a template it doesn't run because the host was marked unresponsive.
const unresponsiveSkipMessage = "host was skipped as it was found unresponsive"

// singleThreadConcurrency pins every worker pool to one, except payload
// concurrency which is driven to two so a single template fans out its payloads
// in parallel. This mirrors a realistic embedded scan while keeping ordering
// deterministic enough to assert on match results across repeated runs.
func singleThreadConcurrency() nuclei.Concurrency {
	return nuclei.Concurrency{
		TemplateConcurrency:           1,
		HostConcurrency:               1,
		HeadlessHostConcurrency:       1,
		HeadlessTemplateConcurrency:   1,
		JavascriptTemplateConcurrency: 1,
		TemplatePayloadConcurrency:    2,
		ProbeConcurrency:              1,
	}
}

// TestVerifySDKBaseHostNotPoisoned drives a scan against a healthy local HTTP
// server with a corpus that also contains a template probing a guaranteed-closed
// custom port. A request to the closed port legitimately fails; that failure
// must stay attributed to the port that actually failed and must not cause the
// healthy base target to stop matching later templates in the same run. The
// callback here filters on match status (matcher-status reporting is left off),
// so the only event it should ever see is the healthy match — and it should see
// it on every run.
//
// The probe URL is built from {{Host}} (the bare host, no port) plus an explicit
// closed port, so the generated request is a well-formed URL pointing at a port
// that genuinely refuses connections. Using the port-bearing host variable would
// yield a doubled "host:port:port" authority that fails URL parsing as a template
// error rather than a real connection failure, so the network-level fault never
// occurs — the probe must resolve to an address a connection is actually
// attempted against for this scenario to exercise the behavior.
func TestVerifySDKBaseHostNotPoisoned(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = fmt.Fprint(w, "server-ok")
	}))
	defer ts.Close()

	// Bind a loopback TCP port and immediately release it to obtain an address
	// that is guaranteed to refuse connections for the duration of the test.
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	require.NoError(t, err)
	closedPort := ln.Addr().(*net.TCPAddr).Port
	require.NoError(t, ln.Close())

	tplDir := t.TempDir()
	closedPortTpl := fmt.Sprintf(`id: closed-port-parallel-probe
info:
  name: Closed Port Parallel Probe
  author: test
  severity: info
http:
  - method: GET
    path:
      - "http://{{Host}}:%d/probe?p={{val}}"
    threads: 2
    payloads:
      val:
        - "1"
        - "2"
    matchers:
      - type: word
        words:
          - "never-matches"
`, closedPort)
	healthyTpl := `id: healthy-base-target-match
info:
  name: Healthy Base Target Match
  author: test
  severity: high
http:
  - method: GET
    path:
      - "{{BaseURL}}/"
    matchers:
      - type: word
        words:
          - "server-ok"
`
	closedPortPath := filepath.Join(tplDir, "01-closed-port.yaml")
	healthyPath := filepath.Join(tplDir, "02-healthy.yaml")
	require.NoError(t, os.WriteFile(closedPortPath, []byte(closedPortTpl), 0o600))
	require.NoError(t, os.WriteFile(healthyPath, []byte(healthyTpl), 0o600))

	for run := 1; run <= 3; run++ {
		ne, err := nuclei.NewNucleiEngineCtx(
			context.Background(),
			nuclei.DisableUpdateCheck(),
			nuclei.WithTemplatesOrWorkflows(nuclei.TemplateSources{
				Templates: []string{closedPortPath, healthyPath},
			}),
			nuclei.WithConcurrency(singleThreadConcurrency()),
		)
		require.NoError(t, err)
		ne.Options().RestrictLocalNetworkAccess = false
		ne.Options().Timeout = 2
		ne.Options().Retries = 0

		ne.LoadTargets([]string{ts.URL}, false)

		var (
			mu         sync.Mutex
			matched    []string
			violations []*output.ResultEvent
		)
		err = ne.ExecuteCallbackWithCtx(context.Background(), func(event *output.ResultEvent) {
			mu.Lock()
			defer mu.Unlock()
			if !event.MatcherStatus || event.Error != "" {
				violations = append(violations, event)
			}
			matched = append(matched, event.TemplateID)
		})
		ne.Close()

		require.NoError(t, err, "run %d failed", run)
		require.Empty(t, violations, "callback must not receive non-matching or skip events while match-status reporting is off (run %d)", run)
		require.Equal(t, []string{"healthy-base-target-match"}, matched, "healthy base target must keep matching after the closed-port probe (run %d)", run)
	}
}

// TestVerifySDKCallbackRespectsMatcherStatus pins the callback contract from
// both sides. Against an unreachable target, a callback that has not opted into
// match-status reporting must receive no skip/error events at all; the same
// scan with reporting enabled must surface them.
//
// The target is a bound-then-released loopback port, i.e. a genuinely
// unresponsive host on a non-standard port. With reporting enabled the scan
// must not only surface events, it must surface the host-errors cache's own
// skip event ("host was skipped as it was found unresponsive") for that host:
// once the first template's request fails, the cache marks the host and the
// remaining templates are skip-reported instead of re-dialed.
func TestVerifySDKCallbackRespectsMatcherStatus(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	require.NoError(t, err)
	closedAddr := ln.Addr().String()
	require.NoError(t, ln.Close())

	tplDir := t.TempDir()
	for i := 1; i <= 3; i++ {
		tpl := fmt.Sprintf(`id: unreachable-check-%d
info:
  name: Unreachable Check %d
  author: test
  severity: info
http:
  - method: GET
    path:
      - "{{BaseURL}}/path-%d"
    matchers:
      - type: word
        words:
          - "ok"
`, i, i, i)
		require.NoError(t, os.WriteFile(filepath.Join(tplDir, fmt.Sprintf("0%d-tpl.yaml", i)), []byte(tpl), 0o600))
	}

	runScan := func(matcherStatus bool) []*output.ResultEvent {
		return scanUnreachable(t, tplDir, "http://"+closedAddr, matcherStatus)
	}

	require.Empty(t, runScan(false), "skip/error events must not reach the callback while match-status reporting is off")

	reported := runScan(true)
	require.NotEmpty(t, reported, "skip/error events must reach the callback once match-status reporting is enabled")

	// The unreachable host sits on a non-standard loopback port. Its failure is
	// still charged to the host-errors cache, so after the first template's
	// request fails the host is marked and every later template in the same scan
	// is skip-reported: at least one surfaced event is the cache's own skip
	// event, not only a per-request connection error.
	var skipEvents int
	for _, event := range reported {
		if event.Error == unresponsiveSkipMessage {
			skipEvents++
		}
	}
	require.NotZero(t, skipEvents, "a genuinely unresponsive host must still be charged to the host-errors cache and skip-reported once match-status reporting is on; got events %v", reported)
}

// scanUnreachable runs every template in tplDir against target with single
// worker pools, turning matcher-status reporting on through the SDK's own option
// when asked, and returns every event the result callback received.
func scanUnreachable(t *testing.T, tplDir, target string, matcherStatus bool) []*output.ResultEvent {
	t.Helper()
	opts := []nuclei.NucleiSDKOptions{
		nuclei.DisableUpdateCheck(),
		nuclei.WithTemplatesOrWorkflows(nuclei.TemplateSources{
			Templates: []string{tplDir},
		}),
		nuclei.WithConcurrency(nuclei.Concurrency{
			TemplateConcurrency:           1,
			HostConcurrency:               1,
			HeadlessHostConcurrency:       1,
			HeadlessTemplateConcurrency:   1,
			JavascriptTemplateConcurrency: 1,
			TemplatePayloadConcurrency:    1,
			ProbeConcurrency:              1,
		}),
	}
	if matcherStatus {
		opts = append(opts, nuclei.EnableMatcherStatus())
	}
	ne, err := nuclei.NewNucleiEngineCtx(context.Background(), opts...)
	require.NoError(t, err)
	ne.Options().RestrictLocalNetworkAccess = false
	ne.Options().Timeout = 1
	ne.Options().Retries = 0

	ne.LoadTargets([]string{target}, false)

	var (
		mu     sync.Mutex
		events []*output.ResultEvent
	)
	err = ne.ExecuteCallbackWithCtx(context.Background(), func(event *output.ResultEvent) {
		mu.Lock()
		defer mu.Unlock()
		events = append(events, event)
	})
	ne.Close()
	require.NoError(t, err)
	return events
}
