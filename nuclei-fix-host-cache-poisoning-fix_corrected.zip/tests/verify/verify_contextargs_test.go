package contextargs

import (
	"context"
	"testing"

	"github.com/stretchr/testify/require"
)

// TestVerifyGetCopyIfHostOutdatedSchemePort pins how a per-request copy of a
// scan input resolves its address. When a request URL points at a different
// port, the copy resolves to that port, and the original input stays
// untouched. Both cases pass on the base too.
//
// Assertions are on the resolved Address() of the updated context, not on any
// internal storage layout, so any implementation that derives the per-request
// address correctly is accepted.
func TestVerifyGetCopyIfHostOutdatedSchemePort(t *testing.T) {
	t.Run("same host and scheme leaves the base address untouched", func(t *testing.T) {
		ctx := NewWithInput(context.Background(), "http://127.0.0.1:3000")
		updated := GetCopyIfHostOutdated(ctx, "http://127.0.0.1:3000/api/v1")
		require.Equal(t, "127.0.0.1:3000", updated.MetaInput.Address(), "a same host, same scheme URL must keep the base address")
	})

	t.Run("custom port is attributed to the rewritten port and leaves the base unchanged", func(t *testing.T) {
		ctx := NewWithInput(context.Background(), "http://127.0.0.1:3000")
		updated := GetCopyIfHostOutdated(ctx, "http://127.0.0.1:8080/probe")
		require.Equal(t, "127.0.0.1:8080", updated.MetaInput.Address(), "updated context must resolve to the rewritten custom port")
		require.Equal(t, "127.0.0.1:3000", ctx.MetaInput.Address(), "the original base context must not be mutated")
	})
}
