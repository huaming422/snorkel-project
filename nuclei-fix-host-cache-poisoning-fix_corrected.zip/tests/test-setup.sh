#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# The image already baked the full Go module closure at the base commit
# (go mod download + go build of the verified packages). This step brings it
# online offline-first and only reaches the network if something is missing.
cd /repo/nuclei

export CGO_ENABLED=0
export GOFLAGS=-mod=mod

# Offline-first: satisfy the module graph from the baked module cache. The
# verifier compiles the repository tree plus fresh Go test files whose imports
# (net/http/httptest and the already-vendored nuclei packages) are all present
# in the baked module closure — no network needed. GOPROXY=off makes a cache
# miss fail fast instead of silently reaching a dead network.
export GOPROXY=off
go mod download && echo "[offline-first] go mod satisfied from image"
