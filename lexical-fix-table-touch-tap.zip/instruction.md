## Task

On touch devices, tapping a table cell sometimes selects multiple cells instead of placing the cursor where the user tapped. Another tap often just clears the selection. This happens most often when the table is the only content in the editor. The same table works normally with a mouse.

Please fix this so tapping a cell reliably places the cursor inside it, even when the finger moves slightly or lands near a cell border. Dragging inside one cell should select text in that cell, not a range of cells. Dragging across cells should select the range starting from where the drag began. Tapping one cell should not interfere with the next interaction. Mouse behavior should remain unchanged.
