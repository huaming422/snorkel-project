// @ts-nocheck
//
// Behavioral verifier for the touch tap-vs-drag table-selection bug.
//
// Tests drive ONLY pre-existing, stable public interfaces, so any
// behaviorally-correct fix is observable through the calling convention
// alone and no implementation detail (field names, constants, helper
// names, number of code sites) is pinned:
//   - buildEditorFromExtensions(...) + TableExtension  (editor construction,
//     wires the real pointer/selection handlers the way an app does)
//   - DOM PointerEvent dispatch on the rendered <td> elements  (input)
//   - editor.read() + $getSelection() + $isTableSelection()  (output)
//
// jsdom has no layout, so cells are placed on a synthetic grid and the cell
// under the pointer is resolved through a stubbed elementsFromPoint — the
// same technique the repo's own touch tests use.
//
// This file constructs its own PointerEvents and never relies on pointerId:
// a single-finger gesture is the whole fixture, and the image's jsdom
// PointerEvent mock carries no pointerId, which the correct behavior does
// not need.

import {buildEditorFromExtensions} from '@lexical/extension';
import {
  $createTableNodeWithDimensions,
  $isTableRowNode,
  $isTableSelection,
  TableExtension,
} from '@lexical/table';
import {
  $getNodeByKey,
  $getRoot,
  $getSelection,
  defineExtension,
  SELECTION_CHANGE_COMMAND,
} from 'lexical';
import {afterEach, beforeEach, describe, expect, test} from 'vitest';

describe('table touch tap vs drag selection', () => {
  const COLUMNS = 3;
  const ROWS = 3;
  const CELL_WIDTH = 100;
  const CELL_HEIGHT = 40;
  // Comfortably beyond any sane tap-slop threshold, so a move of this much is
  // unambiguously a drag.
  const DRAG_DISTANCE = 50;
  // Comfortably smaller than any sane threshold, so a move of this much is
  // still a tap. Real taps jitter by a few pixels.
  const JITTER = 3;

  const hadElementsFromPoint = 'elementsFromPoint' in document;
  const originalElementsFromPoint = document.elementsFromPoint;

  let editor;
  let container;
  /** The <td> elements, in row-major order. */
  let cells;
  /** Their node keys, in the same order. */
  let keys;
  /** The element the stubbed hit-test reports under the pointer. */
  let cellUnderPointer;

  beforeEach(() => {
    container = document.createElement('div');
    document.body.appendChild(container);
    editor = buildEditorFromExtensions(
      defineExtension({
        dependencies: [TableExtension],
        name: '@lexical/table/TouchTapVerify',
      }),
    );
    editor.setRootElement(container);

    // A table of empty cells as the sole content of the document — the
    // scenario where the symptom is most pronounced.
    keys = [];
    editor.update(
      () => {
        const tableNode = $createTableNodeWithDimensions(ROWS, COLUMNS, false);
        $getRoot().clear().append(tableNode);
        for (const rowNode of tableNode.getChildren()) {
          if ($isTableRowNode(rowNode)) {
            for (const cellNode of rowNode.getChildren()) {
              keys.push(cellNode.getKey());
            }
          }
        }
      },
      {discrete: true},
    );

    cells = Array.from(container.querySelectorAll('td'));
    expect(cells).toHaveLength(ROWS * COLUMNS);
    expect(keys).toHaveLength(ROWS * COLUMNS);

    cellUnderPointer = null;
    document.elementsFromPoint = () =>
      cellUnderPointer === null ? [] : [cellUnderPointer];
  });

  afterEach(() => {
    editor.dispose();
    document.body.removeChild(container);
    if (hadElementsFromPoint) {
      document.elementsFromPoint = originalElementsFromPoint;
    } else {
      delete document.elementsFromPoint;
    }
  });

  /** The centre of a cell on the synthetic grid. */
  function centerOf(index) {
    return {
      clientX: (index % COLUMNS) * CELL_WIDTH + CELL_WIDTH / 2,
      clientY: Math.floor(index / COLUMNS) * CELL_HEIGHT + CELL_HEIGHT / 2,
    };
  }

  function dispatchPointerEvent(cell, type, options) {
    cell.dispatchEvent(
      new PointerEvent(type, {
        bubbles: true,
        button: 0,
        buttons: 1,
        cancelable: true,
        pointerType: 'touch',
        ...options,
      }),
    );
  }

  /** Presses a finger down on the centre of a cell. */
  function pointerDown(index, pointerType = 'touch') {
    cellUnderPointer = cells[index];
    dispatchPointerEvent(cells[index], 'pointerdown', {
      pointerType,
      ...centerOf(index),
    });
  }

  /**
   * Moves the pointer by `dx` from where the gesture started and reports
   * `overIndex` as the cell underneath it.
   */
  function pointerMove(fromIndex, overIndex, dx, pointerType = 'touch') {
    cellUnderPointer = cells[overIndex];
    const from = centerOf(fromIndex);
    dispatchPointerEvent(cells[overIndex], 'pointermove', {
      clientX: from.clientX + dx,
      clientY: from.clientY,
      pointerType,
    });
  }

  function pointerUp(index, pointerType = 'touch') {
    dispatchPointerEvent(cells[index], 'pointerup', {
      buttons: 0,
      pointerType,
      ...centerOf(index),
    });
  }

  /** A tap: down, the micro pointermove that real taps produce, then up. */
  function touchTap(index) {
    pointerDown(index);
    pointerMove(index, index, JITTER);
    pointerUp(index);
  }

  /** A drag from one cell into another. */
  function touchDrag(fromIndex, toIndex) {
    pointerDown(fromIndex);
    pointerMove(fromIndex, toIndex, DRAG_DISTANCE);
    pointerUp(toIndex);
  }

  // editor.read() force-commits, flushing the updates the pointer handlers
  // queued before reading the selection they produced.
  function expectNoTableSelection() {
    editor.read(() => {
      expect($isTableSelection($getSelection())).toBe(false);
    });
  }

  function expectTableSelection(anchorIndex, focusIndex) {
    editor.read(() => {
      const selection = $getSelection();
      expect($isTableSelection(selection)).toBe(true);
      if ($isTableSelection(selection)) {
        expect(selection.anchor.getNode().getKey()).toBe(keys[anchorIndex]);
        expect(selection.focus.getNode().getKey()).toBe(keys[focusIndex]);
      }
    });
  }

  /**
   * Puts a collapsed caret at the start of a cell and lets the table's
   * SELECTION_CHANGE_COMMAND handler see it — what a touch device does
   * natively as a finger presses and drags. jsdom moves no caret of its own,
   * so the pointer-driven cases never reach that handler otherwise.
   */
  function moveCaretTo(index) {
    editor.update(
      () => {
        const cellNode = $getNodeByKey(keys[index]);
        expect(cellNode).not.toBe(null);
        cellNode.selectStart();
        editor.dispatchCommand(SELECTION_CHANGE_COMMAND, undefined);
      },
      {discrete: true},
    );
  }

  // A plain tap (down, a few-pixel move, up) must place a caret, not enter
  // table-selection mode.
  test('a tap with micro jitter places a caret, not a table selection', () => {
    touchTap(4);

    expectNoTableSelection();
  });

  // Repeated taps should independently place the caret in the tapped cell.
  test('consecutive taps on different cells do not create a table selection', () => {
    touchTap(0);
    touchTap(4);

    expectNoTableSelection();
  });

  // Small finger movement near a border should still count as a tap.
  test('a tap near a cell border does not create a table selection', () => {
    pointerDown(0);
    pointerMove(0, 1, JITTER);
    pointerUp(0);

    expectNoTableSelection();
  });

  // Small movement across a cell border should remain a tap when the
  // browser updates the caret during the same touch gesture.
  test('a near-border tap with a native caret update does not select cells', () => {
    moveCaretTo(4);
    pointerDown(0);
    pointerMove(0, 1, JITTER);
    moveCaretTo(1);
    pointerUp(0);

    expectNoTableSelection();
  });

  // A cross-cell touch drag should select the range from its starting cell.
  test('a touch drag across cells creates a table selection anchored at the start cell', () => {
    touchDrag(0, 1);

    expectTableSelection(0, 1);
  });

  // A drag after a tap should start from the new drag's starting cell.
  test('a touch drag after a tap anchors at the drag start cell, not the stale tap cell', () => {
    touchTap(0);
    touchDrag(4, 5);

    expectTableSelection(4, 5);
  });

  // A drag that stays within one cell is selecting text inside it, not
  // selecting cells.
  test('a touch drag within one cell does not create a table selection', () => {
    pointerDown(0);
    pointerMove(0, 0, DRAG_DISTANCE);
    pointerUp(0);

    expectNoTableSelection();
  });

  // A drag within one cell must not become a table selection even when
  // the browser updates the caret during the gesture.
  test('the native-caret path: a drag within one cell does not convert to a table selection', () => {
    // An earlier tap left the caret in cell 0.
    moveCaretTo(0);

    // The finger presses in cell 4 and drags without leaving it; the browser
    // moves the caret into cell 4 as it goes.
    pointerDown(4);
    pointerMove(4, 4, DRAG_DISTANCE);
    moveCaretTo(4);
    pointerUp(4);

    expectNoTableSelection();
  });

  // A genuine cross-cell drag should select cells even when the browser
  // updates the caret during the gesture.
  test('the native-caret path: a drag crossing cells converts to a table selection', () => {
    moveCaretTo(0);

    pointerDown(0);
    pointerMove(0, 1, DRAG_DISTANCE);
    moveCaretTo(1);

    editor.read(() => {
      expect($isTableSelection($getSelection())).toBe(true);
    });
  });

  // Mouse dragging across a border should select cells even over a small
  // distance, because touch movement tolerance must not affect the mouse.
  test('a short mouse drag across a cell border still selects cells', () => {
    pointerDown(0, 'mouse');
    pointerMove(0, 1, JITTER, 'mouse');
    pointerUp(1, 'mouse');

    expectTableSelection(0, 1);
  });

  // A longer mouse drag across cells should also retain its normal behavior.
  test('a mouse drag across cells still creates a table selection', () => {
    pointerDown(0, 'mouse');
    pointerMove(0, 1, DRAG_DISTANCE, 'mouse');
    pointerUp(1, 'mouse');

    expectTableSelection(0, 1);
  });
});
