#!/usr/bin/env bash
# Environment bootstrap for the verifier.
#
# Lexical's unit tests run against package SOURCE: vitest.config.mts aliases
# every `@lexical/*` import to `packages/*/src/index.ts` (via tsconfig.test.json
# paths), so a src/ edit is visible to the verifier immediately with NO build
# step. We only need node_modules present (baked at image build time).
#
# Sourced (not exec'd) by the harbor runner so env vars set here stay live for
# the verifier subprocess.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/lexical}"
export REPO_DIR
cd "$REPO_DIR"

# vitest must be resolvable from the workspace root. The dependency closure is
# baked into the image at the base commit (pnpm install --frozen-lockfile), so
# this is normally a no-op. Offline-first: only fall back to a reinstall if the
# binary is genuinely missing (e.g. a corrupted node_modules), and log it.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/ — " \
         "reinstalling from the lockfile." >&2
    pnpm install --frozen-lockfile --offline \
        || pnpm install --frozen-lockfile
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
