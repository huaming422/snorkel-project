## Task

we've been getting reports from folks doing semidefinite programming that the internal routine we use to factor symmetric matrices falls over on valid low-rank inputs. anything full rank and well conditioned factors fine; the trouble is specific to rank-deficient positive- and negative-semidefinite matrices.

on some of them it just bails with "Cholesky factorization failed" on a matrix that's a perfectly good PSD input, e.g. `[[1, 1, 0], [1, 1, 0], [0, 0, 1]]`.

dig into why rank-deficient semidefinite inputs break and fix it, so the routine returns a correct factorization for low-rank PSD and NSD inputs. a correct factorization is one that actually reconstructs the input matrix. genuinely indefinite matrices should still be rejected.
