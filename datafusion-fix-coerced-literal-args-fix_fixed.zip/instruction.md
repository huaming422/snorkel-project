## Task

After we moved to a newer DataFusion main build, some of our UDFs plan with the wrong result type.
Everything below worked a couple of weeks ago, and nothing changed on our side.

`select my_round(price, 2) from sales` used to give a Decimal128(10, 2) column.
It now gives Decimal128(38, 10), which is what `my_round` returns when it can't tell which scale it was given.
Negative scales broke the same way, so `my_round(price, -2)` comes back as Decimal128(38, 10) instead of Decimal128(10, 0).
`my_round(price, NULL)` used to plan as a column of nulls typed like `price`, and now it lands on Decimal128(38, 10) too.
When the scale comes from a column, as in `my_round(price, digits)`, Decimal128(38, 10) has always been the answer, and that should stay.

Our `my_fold` function broke at the same time.
`select my_fold(prices, p -> p * 1.5, 0) from sales` used to plan as Float64.
Now planning fails with our own "fallback does not match the lambda result" error.
Calling `my_round` inside the lambda, as in `my_fold(prices, p -> my_round(p, 2), 0)`, gets the wrong scale there as well.

One query is supposed to fail, and it should keep failing.
`my_round(price, 2147483648)` errors because that scale doesn't fit in the Int32 that `my_round` takes.
We don't mind whether the error shows up while planning or when the query runs, but the query must not run with some other scale.
