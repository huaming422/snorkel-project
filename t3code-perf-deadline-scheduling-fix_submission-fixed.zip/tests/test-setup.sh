#!/usr/bin/env bash
# test-setup.sh - environment bootstrap for the verifier.
#
# Sourced (not exec'd) by the harbor runner so env vars set here stay live for
# the verifier subprocess. The focused tests run through vite-plus (`vp`), which
# is resolved from the repo's own node_modules (baked at build time). Everything
# the implementation phase and the verifier need to build and run the focused tests is already in
# the image (the implementation phase is offline); this script only sanity-checks that closure
# and routes verifier infrastructure through the canonical venv.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/t3code}"
export REPO_DIR
cd "$REPO_DIR"

# Canonical grading runtime. tests/test.sh routes verifier infrastructure
# through this interpreter; export it for the verifier subprocess.
export VERIFIER_PYTHON="${VERIFIER_PYTHON:-/opt/tooling/venv/bin/python}"

# Sanity check: the vite-plus test runner must be resolvable from the repo.
# A failure here points at a corrupted node_modules from a bad image build -
# bailing now is clearer than a confusing "vp: command not found" later.
if ! [ -x node_modules/.bin/vp ]; then
    echo "test-setup.sh: vite-plus (vp) binary missing from node_modules/.bin/. " \
         "The image build is corrupt - the dependency closure was not baked." >&2
    exit 1
fi
