#!/usr/bin/env bash
# verify.sh - drives the focused @effect/vitest scheduling suite through the
# repo's own vite-plus runner.
#
# The suite imports sibling modules by relative path (./EffectOutbox.ts,
# ../persistence/Layers/Sqlite.ts, ...), so it has to run from inside the
# orchestration-v2 source directory, next to the modules as the submitted
# changes left them. We stage a copy there, run it,
# then remove it so the working tree is left exactly as found.
#
# Exit code is the signal: 0 iff every case passed. vite-plus exits non-zero on
# a failing assertion, a transpile/runtime error, or zero matched tests, each of
# which the shell runner reports as a failed verifier.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/t3code}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# The source file is deliberately NOT named verify*.test.ts: that glob is what
# the generic JS test runner discovers, and this suite must run ONLY through this
# shell driver (the repo's vite-plus), never a second time via npx jest/vitest.
SRC_TEST="${HERE}/effect_scheduling.spec.ts"
DEST_DIR="${REPO_DIR}/apps/server/src/orchestration-v2"
# Staged inside the repo tree (not under verify/) with a name that matches the
# repo's own *.test.ts suite glob so vite-plus picks it up.
DEST_TEST="${DEST_DIR}/effect_scheduling.generated.test.ts"
REL_TEST="apps/server/src/orchestration-v2/effect_scheduling.generated.test.ts"

if [ ! -f "${SRC_TEST}" ]; then
    echo "verify.sh: missing ${SRC_TEST}" >&2
    exit 1
fi
if [ ! -d "${DEST_DIR}" ]; then
    echo "verify.sh: expected source directory not found: ${DEST_DIR}" >&2
    exit 1
fi
if [ ! -x "${REPO_DIR}/node_modules/.bin/vp" ]; then
    echo "verify.sh: vite-plus (vp) not resolvable under ${REPO_DIR}/node_modules/.bin" >&2
    exit 1
fi

cleanup() {
    rm -f "${DEST_TEST}"
}
trap cleanup EXIT

cp "${SRC_TEST}" "${DEST_TEST}"

cd "${REPO_DIR}"
echo "verify.sh: running focused scheduling suite via vite-plus (${REL_TEST})"
# Foreground the runner; its stdout/stderr are captured by the harness. Guard
# the invocation so a non-zero exit is captured rather than tripping `set -e`.
status=0
node_modules/.bin/vp test run "${REL_TEST}" || status=$?

if [ "${status}" -eq 0 ]; then
    echo "verify.sh: scheduling suite passed"
else
    echo "verify.sh: scheduling suite failed (exit ${status})" >&2
fi
exit "${status}"
