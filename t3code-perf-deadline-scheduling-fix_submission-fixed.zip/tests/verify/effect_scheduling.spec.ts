import { assert, it } from "@effect/vitest";
import {
  CommandId,
  EventId,
  type ModelSelection,
  type OrchestrationV2AppThread,
  type OrchestrationV2DomainEvent,
  ProjectId,
  ProviderInstanceId,
  RunId,
  ThreadId,
} from "@t3tools/contracts";
import * as DateTime from "effect/DateTime";
import * as Deferred from "effect/Deferred";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Option from "effect/Option";
import * as Ref from "effect/Ref";
import * as TestClock from "effect/testing/TestClock";

import { SqlitePersistenceMemory } from "../persistence/Layers/Sqlite.ts";
import { layer as commandReceiptStoreLayer } from "./CommandReceiptStore.ts";
import {
  EffectOutboxV2,
  type EffectOutboxV2Shape,
  layer as effectOutboxLayer,
} from "./EffectOutbox.ts";
import {
  layerWithOptions as effectWorkerLayerWithOptions,
  OrchestrationEffectExecutionError,
  OrchestrationEffectExecutorV2,
  type OrchestrationEffectExecutorV2Shape,
  runDaemonWithOptions as runEffectWorkerDaemonWithOptions,
} from "./EffectWorker.ts";
import { EventSinkV2, layer as eventSinkLayer } from "./EventSink.ts";
import { layer as eventStoreLayer } from "./EventStore.ts";
import { layer as idAllocatorLayer } from "./IdAllocator.ts";
import { layer as projectionMaintenanceLayer } from "./ProjectionMaintenance.ts";
import { layer as projectionStoreLayer } from "./ProjectionStore.ts";

// ---------------------------------------------------------------------------
// Same layer composition as FoundationPersistence.test.ts. Each case builds
// one in-memory node:sqlite database with `Layer.fresh(TestLayer)`, so the
// command-write surface and the worker built inside the case share one durable
// outbox.
// ---------------------------------------------------------------------------
const databaseLayer = SqlitePersistenceMemory;
const eventStoreProvided = eventStoreLayer.pipe(Layer.provideMerge(databaseLayer));
const projectionStoreProvided = projectionStoreLayer.pipe(Layer.provideMerge(databaseLayer));
const storesProvided = Layer.mergeAll(databaseLayer, eventStoreProvided, projectionStoreProvided);
const eventSinkProvided = eventSinkLayer.pipe(Layer.provide(storesProvided));
const effectOutboxProvided = effectOutboxLayer.pipe(Layer.provide(databaseLayer));
const commandReceiptStoreProvided = commandReceiptStoreLayer.pipe(Layer.provide(databaseLayer));
const projectionMaintenanceProvided = projectionMaintenanceLayer.pipe(Layer.provide(storesProvided));

const TestLayer = Layer.mergeAll(
  storesProvided,
  eventSinkProvided,
  effectOutboxProvided,
  commandReceiptStoreProvided,
  idAllocatorLayer,
  projectionMaintenanceProvided,
);

const providerInstanceId = ProviderInstanceId.make("codex");
const modelSelection = {
  instanceId: providerInstanceId,
  model: "gpt-5.4",
} satisfies ModelSelection;

function makeThread(threadId: ThreadId, now: DateTime.Utc): OrchestrationV2AppThread {
  return {
    createdBy: "user",
    creationSource: "web",
    id: threadId,
    projectId: ProjectId.make(`project:${threadId}`),
    title: `Thread ${threadId}`,
    providerInstanceId,
    modelSelection,
    runtimeMode: "full-access",
    interactionMode: "default",
    branch: null,
    worktreePath: null,
    activeProviderThreadId: null,
    lineage: {
      parentThreadId: null,
      relationshipToParent: null,
      rootThreadId: threadId,
    },
    forkedFrom: null,
    createdAt: now,
    updatedAt: now,
    archivedAt: null,
    settledOverride: null,
    settledAt: null,
    deletedAt: null,
  };
}

function threadCreatedEvent(input: {
  readonly id: string;
  readonly thread: OrchestrationV2AppThread;
  readonly now: DateTime.Utc;
}): OrchestrationV2DomainEvent {
  return {
    id: EventId.make(input.id),
    type: "thread.created",
    threadId: input.thread.id,
    providerInstanceId,
    occurredAt: input.now,
    payload: input.thread,
  };
}

const executorLayer = (execute: OrchestrationEffectExecutorV2Shape["execute"]) =>
  Layer.succeed(OrchestrationEffectExecutorV2, OrchestrationEffectExecutorV2.of({ execute }));

// Counts performed effects. Payload content does not matter for scheduling.
const countingExecutor = (performed: Ref.Ref<number>) =>
  executorLayer(() => Ref.update(performed, (count) => count + 1));

// Wraps the outbox so every claim attempt is counted.
const countingClaims = (real: EffectOutboxV2Shape, claims: Ref.Ref<number>): EffectOutboxV2Shape => ({
  ...real,
  claimNext: (input) =>
    Ref.update(claims, (count) => count + 1).pipe(Effect.andThen(real.claimNext(input))),
});

const workerOn = (
  workerId: string,
  outbox: EffectOutboxV2Shape,
  executor: Layer.Layer<OrchestrationEffectExecutorV2>,
) =>
  effectWorkerLayerWithOptions({ workerId }).pipe(
    Layer.provide(Layer.merge(Layer.succeed(EffectOutboxV2, outbox), executor)),
  );

// Yields the scheduler (clock stays put) until the condition holds or the step
// budget runs out, so a case that never makes progress fails instead of hanging.
const settleUntil = (condition: Effect.Effect<boolean>, budget = 4_000): Effect.Effect<void> =>
  Effect.gen(function* () {
    let steps = 0;
    while (steps < budget && !(yield* condition)) {
      yield* Effect.yieldNow;
      steps += 1;
    }
  });

// A fixed number of scheduler turns, enough for forked executors to run their
// first claim and park.
const settleTurns = (turns = 64): Effect.Effect<void> =>
  Effect.gen(function* () {
    for (let i = 0; i < turns; i += 1) {
      yield* Effect.yieldNow;
    }
  });

const atLeast = (ref: Ref.Ref<number>, n: number) =>
  Ref.get(ref).pipe(Effect.map((value) => value >= n));

// ── An idle pool stays quiet ──────────────────────────────────────────────────
// Empty outbox, default pool size. Claim attempts over ten virtual seconds are
// bounded at one per executor per second. A slow safety check fits under that,
// a tens-per-second poll does not.
it.effect("keeps an idle executor pool quiet", () =>
  Effect.gen(function* () {
    const real = yield* EffectOutboxV2;
    const claims = yield* Ref.make(0);
    const performed = yield* Ref.make(0);

    yield* Effect.gen(function* () {
      yield* runEffectWorkerDaemonWithOptions().pipe(Effect.forkScoped);
      yield* settleUntil(atLeast(claims, 1));
      yield* settleTurns();
      const before = yield* Ref.get(claims);

      for (let i = 0; i < 10; i += 1) {
        yield* TestClock.adjust("1000 millis");
        yield* settleTurns();
      }
      const after = yield* Ref.get(claims);

      assert.equal(yield* Ref.get(performed), 0);
      assert.isAtMost(after - before, 40);
    }).pipe(
      Effect.provide(workerOn("idle-worker", countingClaims(real, claims), countingExecutor(performed))),
      Effect.scoped,
    );
  }).pipe(Effect.provide(Layer.fresh(TestLayer)), Effect.provide(TestClock.layer())),
);

// ── New work starts right away on an idle pool ───────────────────────────────
// The pool has been idle for a while, then a command commits one effect. It has
// to run without the clock moving.
it.effect("starts newly committed work on an idle pool right away", () =>
  Effect.gen(function* () {
    const eventSink = yield* EventSinkV2;
    const outbox = yield* EffectOutboxV2;
    const performed = yield* Ref.make(0);

    yield* Effect.gen(function* () {
      yield* runEffectWorkerDaemonWithOptions().pipe(Effect.forkScoped);
      yield* settleTurns();
      yield* TestClock.adjust("5 seconds");
      yield* settleTurns();

      const now = yield* DateTime.now;
      const commandId = CommandId.make("command:new-work");
      const threadId = ThreadId.make("thread:new-work");
      const result = yield* eventSink.commitCommand({
        commandId,
        threadId,
        commandType: "new-work.probe",
        acceptedAt: now,
        events: [threadCreatedEvent({ id: "event:new-work", thread: makeThread(threadId, now), now })],
        effects: [
          { id: "effect:new-work", commandId, threadId, request: { type: "terminal.cleanup" } },
        ],
      });
      assert.isTrue(result.committed);

      yield* settleUntil(atLeast(performed, 1));
      assert.equal(yield* Ref.get(performed), 1);
    }).pipe(Effect.provide(workerOn("new-work-worker", outbox, countingExecutor(performed))), Effect.scoped);
  }).pipe(Effect.provide(Layer.fresh(TestLayer)), Effect.provide(TestClock.layer())),
);

// ── A future-dated row runs at its time ──────────────────────────────────────
// Default daemon options. The row becomes due 30ms out and has to run within
// 5ms of that, which a fixed tens-of-milliseconds poll grid misses.
it.effect("performs a durable deadline at approximately its scheduled time", () =>
  Effect.gen(function* () {
    const outbox = yield* EffectOutboxV2;
    const performed = yield* Ref.make(0);
    const now = yield* DateTime.now;

    yield* outbox.enqueue([
      {
        id: "effect:deadline",
        commandId: CommandId.make("command:deadline"),
        threadId: ThreadId.make("thread:deadline"),
        request: { type: "terminal.cleanup" },
        availableAt: DateTime.add(now, { milliseconds: 30 }),
      },
    ]);

    yield* Effect.gen(function* () {
      yield* runEffectWorkerDaemonWithOptions({ concurrency: 1 }).pipe(Effect.forkScoped);
      yield* settleTurns();

      yield* TestClock.adjust("29 millis");
      yield* settleTurns();
      assert.equal(yield* Ref.get(performed), 0);

      yield* TestClock.adjust("6 millis");
      yield* settleUntil(atLeast(performed, 1));
      assert.equal(yield* Ref.get(performed), 1);
    }).pipe(Effect.provide(workerOn("deadline-worker", outbox, countingExecutor(performed))), Effect.scoped);
  }).pipe(Effect.provide(Layer.fresh(TestLayer)), Effect.provide(TestClock.layer())),
);

// ── A failed effect retries on its backoff schedule ──────────────────────────
// The first attempt fails, so the worker's own retry schedule puts the second
// attempt 100ms later. It has to happen then, not on a later safety check.
it.effect("runs a delayed retry when its backoff delay is up", () =>
  Effect.gen(function* () {
    const outbox = yield* EffectOutboxV2;
    const attempts = yield* Ref.make(0);
    const failFirst = executorLayer((effect) =>
      Ref.updateAndGet(attempts, (count) => count + 1).pipe(
        Effect.flatMap((attempt) =>
          attempt === 1
            ? Effect.fail(
                new OrchestrationEffectExecutionError({
                  effectId: effect.id,
                  effectType: effect.request.type,
                  cause: new Error("first attempt fails"),
                }),
              )
            : Effect.void,
        ),
      ),
    );

    yield* outbox.enqueue([
      {
        id: "effect:retry",
        commandId: CommandId.make("command:retry"),
        threadId: ThreadId.make("thread:retry"),
        request: { type: "terminal.cleanup" },
      },
    ]);

    yield* Effect.gen(function* () {
      yield* runEffectWorkerDaemonWithOptions({ concurrency: 1 }).pipe(Effect.forkScoped);
      yield* settleUntil(atLeast(attempts, 1));
      yield* settleTurns();
      assert.equal(yield* Ref.get(attempts), 1);

      yield* TestClock.adjust("90 millis");
      yield* settleTurns();
      assert.equal(yield* Ref.get(attempts), 1);

      yield* TestClock.adjust("15 millis");
      yield* settleUntil(atLeast(attempts, 2));
      assert.equal(yield* Ref.get(attempts), 2);

      const settled = yield* outbox.get("effect:retry");
      assert.isTrue(Option.isSome(settled));
      if (Option.isSome(settled)) assert.equal(settled.value.status, "succeeded");
    }).pipe(Effect.provide(workerOn("retry-worker", outbox, failFirst)), Effect.scoped);
  }).pipe(Effect.provide(Layer.fresh(TestLayer)), Effect.provide(TestClock.layer())),
);

// ── A due-but-blocked row does not cause a hot loop ──────────────────────────
// One thread has a running effect held elsewhere, so its second row is due but
// cannot be claimed. Claim attempts over a virtual second stay bounded.
it.effect("does not spin on a due row blocked by a running same-thread effect", () =>
  Effect.gen(function* () {
    const real = yield* EffectOutboxV2;
    const claims = yield* Ref.make(0);
    const performed = yield* Ref.make(0);
    const commandId = CommandId.make("command:blocked");
    const threadId = ThreadId.make("thread:blocked");

    yield* real.enqueue([
      { id: "effect:blocked:a", commandId, threadId, request: { type: "terminal.cleanup" } },
      { id: "effect:blocked:b", commandId, threadId, request: { type: "terminal.cleanup" } },
    ]);
    assert.isTrue(
      Option.isSome(yield* real.claimNext({ workerId: "setup", leaseDurationMs: 120_000 })),
    );

    yield* Effect.gen(function* () {
      yield* runEffectWorkerDaemonWithOptions({ concurrency: 1 }).pipe(Effect.forkScoped);
      yield* settleUntil(atLeast(claims, 1));
      yield* settleTurns();
      const before = yield* Ref.get(claims);

      yield* TestClock.adjust("1000 millis");
      yield* settleTurns();
      const after = yield* Ref.get(claims);

      assert.equal(yield* Ref.get(performed), 0);
      assert.isAtMost(after - before, 3);
    }).pipe(
      Effect.provide(workerOn("blocked-worker", countingClaims(real, claims), countingExecutor(performed))),
      Effect.scoped,
    );
  }).pipe(Effect.provide(Layer.fresh(TestLayer)), Effect.provide(TestClock.layer())),
);

// ── The next effect on a thread starts as soon as the one ahead is done ──────
// A long-running provider turn holds the thread while a second effect waits
// behind it and the rest of the pool sits idle. Once the turn finishes, or a
// command cancels it, the waiting effect runs without the clock moving.
const unblocksSameThreadWork = (finishBy: "completion" | "cancellation") =>
  Effect.gen(function* () {
    const eventSink = yield* EventSinkV2;
    const outbox = yield* EffectOutboxV2;
    const turnStarted = yield* Ref.make(0);
    const followUps = yield* Ref.make(0);
    const releaseTurn = yield* Deferred.make<void>();
    const commandId = CommandId.make(`command:unblock-${finishBy}`);
    const threadId = ThreadId.make(`thread:unblock-${finishBy}`);

    const executor = executorLayer((effect) =>
      effect.request.type === "provider-turn.start"
        ? Ref.update(turnStarted, (count) => count + 1).pipe(
            Effect.andThen(Deferred.await(releaseTurn)),
          )
        : Ref.update(followUps, (count) => count + 1),
    );

    // Ids sort so the provider turn is claimed first and the follow-up waits.
    yield* outbox.enqueue([
      {
        id: `effect:unblock-${finishBy}:a-turn`,
        commandId,
        threadId,
        request: { type: "provider-turn.start", runId: RunId.make(`run:unblock-${finishBy}`) },
      },
      {
        id: `effect:unblock-${finishBy}:b-follow-up`,
        commandId,
        threadId,
        request: { type: "terminal.cleanup" },
      },
    ]);

    yield* Effect.gen(function* () {
      yield* runEffectWorkerDaemonWithOptions({ concurrency: 2 }).pipe(Effect.forkScoped);
      yield* settleUntil(atLeast(turnStarted, 1));
      yield* settleTurns();
      yield* TestClock.adjust("5 seconds");
      yield* settleTurns();
      assert.equal(yield* Ref.get(followUps), 0);

      if (finishBy === "completion") {
        yield* Deferred.succeed(releaseTurn, undefined);
      } else {
        const now = yield* DateTime.now;
        const cancel = yield* eventSink.commitCommand({
          commandId: CommandId.make(`command:unblock-${finishBy}:cancel`),
          threadId,
          commandType: "unblock.cancel",
          acceptedAt: now,
          events: [
            threadCreatedEvent({
              id: `event:unblock-${finishBy}`,
              thread: makeThread(threadId, now),
              now,
            }),
          ],
          effects: [],
          cancelUnsettledEffects: {
            effectTypes: ["provider-turn.start"],
            reason: "stop the running turn",
          },
        });
        assert.isTrue(cancel.committed);
        assert.equal(cancel.cancelledEffectCount, 1);
      }

      yield* settleUntil(atLeast(followUps, 1));
      assert.equal(yield* Ref.get(followUps), 1);
    }).pipe(Effect.provide(workerOn(`unblock-${finishBy}-worker`, outbox, executor)), Effect.scoped);
  }).pipe(Effect.provide(Layer.fresh(TestLayer)), Effect.provide(TestClock.layer()));

it.effect("starts the next same-thread effect when the running one completes", () =>
  unblocksSameThreadWork("completion"),
);

it.effect("starts the next same-thread effect when the running one is cancelled", () =>
  unblocksSameThreadWork("cancellation"),
);

// ── Rows written without an in-process wakeup still get picked up ────────────
// A second outbox instance on the same database stands in for another server
// process: its writes reach the table but none of this process's wakeups. The
// row has to be performed within a minute of virtual time.
it.effect("picks up a row written by another process", () =>
  Effect.gen(function* () {
    const outbox = yield* EffectOutboxV2;
    const otherProcess = yield* EffectOutboxV2.pipe(Effect.provide(Layer.fresh(effectOutboxLayer)));
    const performed = yield* Ref.make(0);

    yield* Effect.gen(function* () {
      yield* runEffectWorkerDaemonWithOptions().pipe(Effect.forkScoped);
      yield* settleTurns();
      yield* TestClock.adjust("1 seconds");
      yield* settleTurns();

      yield* otherProcess.enqueue([
        {
          id: "effect:other-process",
          commandId: CommandId.make("command:other-process"),
          threadId: ThreadId.make("thread:other-process"),
          request: { type: "terminal.cleanup" },
        },
      ]);

      for (let i = 0; i < 60 && (yield* Ref.get(performed)) === 0; i += 1) {
        yield* TestClock.adjust("1000 millis");
        yield* settleTurns();
      }
      assert.equal(yield* Ref.get(performed), 1);
    }).pipe(Effect.provide(workerOn("local-worker", outbox, countingExecutor(performed))), Effect.scoped);
  }).pipe(Effect.provide(Layer.fresh(TestLayer)), Effect.provide(TestClock.layer())),
);

// ── Claim failures are spaced, not spun ──────────────────────────────────────
// Every claim attempt fails. Over a virtual second the pool retries at most a
// few times.
it.effect("spaces attempts when claiming keeps failing", () =>
  Effect.gen(function* () {
    const real = yield* EffectOutboxV2;
    const attempts = yield* Ref.make(0);
    const failing: EffectOutboxV2Shape = {
      ...real,
      claimNext: () =>
        Ref.update(attempts, (count) => count + 1).pipe(
          Effect.andThen(Effect.fail(new Error("simulated claim failure"))),
        ) as ReturnType<EffectOutboxV2Shape["claimNext"]>,
    };
    const performed = yield* Ref.make(0);

    yield* Effect.gen(function* () {
      yield* runEffectWorkerDaemonWithOptions({ concurrency: 1 }).pipe(Effect.forkScoped);
      yield* settleUntil(atLeast(attempts, 1));
      yield* settleTurns();
      const before = yield* Ref.get(attempts);

      yield* TestClock.adjust("1000 millis");
      yield* settleTurns();
      const after = yield* Ref.get(attempts);

      assert.isAtMost(after - before, 3);
    }).pipe(Effect.provide(workerOn("backoff-worker", failing, countingExecutor(performed))), Effect.scoped);
  }).pipe(Effect.provide(Layer.fresh(TestLayer)), Effect.provide(TestClock.layer())),
);

// ── Normal claim/execute/settle semantics stay intact ────────────────────────
// A pool of four claims a ready effect once, performs it, and marks it
// succeeded. It is not performed again later.
it.effect("claims and performs a ready effect exactly once", () =>
  Effect.gen(function* () {
    const outbox = yield* EffectOutboxV2;
    const performed = yield* Ref.make(0);
    const effectId = "effect:exactly-once";

    yield* outbox.enqueue([
      {
        id: effectId,
        commandId: CommandId.make("command:exactly-once"),
        threadId: ThreadId.make("thread:exactly-once"),
        request: { type: "terminal.cleanup" },
      },
    ]);

    yield* Effect.gen(function* () {
      yield* runEffectWorkerDaemonWithOptions({ concurrency: 4 }).pipe(Effect.forkScoped);
      yield* settleUntil(atLeast(performed, 1));
      assert.equal(yield* Ref.get(performed), 1);

      const settled = yield* outbox.get(effectId);
      assert.isTrue(Option.isSome(settled));
      if (Option.isSome(settled)) assert.equal(settled.value.status, "succeeded");

      yield* TestClock.adjust("500 millis");
      yield* settleTurns();
      assert.equal(yield* Ref.get(performed), 1);
    }).pipe(Effect.provide(workerOn("once-worker", outbox, countingExecutor(performed))), Effect.scoped);
  }).pipe(Effect.provide(Layer.fresh(TestLayer)), Effect.provide(TestClock.layer())),
);
