## Task

The orchestration server's effect executors never go quiet.
With nothing queued, the four of them keep firing claim queries, tens per second between them, and each one lands in the trace log.
Effects scheduled for later, retries included, don't start on time either.
They get noticed on the next poll tick, so they start late.
Slowing the poll down would cut the noise but push retries back even more, so that isn't the answer.

Here's what I'd like to end up with.

- With nothing claimable, the executors stay quiet, with at most an occasional safety check every few seconds.
- That holds when a thread's next effect is stuck behind one that's still running, too.
- An effect with a later start time, such as a retry after a failure, runs when that time comes.
- New work still starts right away.
- The next effect on a thread starts right away once the one ahead of it finishes or gets cancelled.
- Rows written by another server process never wake anything here, and they still need to get picked up within a minute.
- If the claim query itself keeps failing, back off instead of retrying in a tight loop.
- Claiming stays crash-safe and exactly-once across all four executors.
