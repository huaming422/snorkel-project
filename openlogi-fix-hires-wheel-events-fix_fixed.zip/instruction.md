## Task

Two problems with mice that have a hi-res wheel.

When a mouse has Smooth wheel turned on, OpenLogi turns wheel-movement reports into scrolling even when they arrive as short HID++ reports. Logi Options+ ignores a movement report that short, and OpenLogi should too.

Pressing the mode-shift button under the wheel switches it between ratchet and free-spin, but the SmartShift card in the desktop app keeps showing the old mode until you change the mode from inside the app. The card should follow the button, including when you press it while the app is still reading the current mode.

Track down what causes each of these and fix it.
