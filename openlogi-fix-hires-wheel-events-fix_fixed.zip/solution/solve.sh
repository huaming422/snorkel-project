#!/bin/bash
set -euo pipefail
cd /repo/${REPO_NAME:?REPO_NAME must be set}
git apply /solution/oracle.patch
echo "Fix applied via oracle.patch"
