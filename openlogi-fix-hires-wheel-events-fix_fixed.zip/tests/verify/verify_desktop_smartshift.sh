#!/usr/bin/env bash
#
# Behavioural verifier for the desktop app's SmartShift card (crate
# `openlogi-desktop`, binary target `openlogi-desktop`). The behaviour is
# observable only through the app's own state machine, which is private to the
# binary crate, so this verifier appends a `#[cfg(test)]` module to the
# crate's SmartShift state tests and runs it with `cargo test --bin`. A child
# module sees its ancestors' private items, so the added test drives the app
# through the SAME pre-existing entry points the crate's own state tests use.
#
# What is asserted is only what the user sees:
#
#   1. When the mouse reports a settings change it made on its own (its
#      `settings_revision` moves, which is how the device layer tells clients
#      a setting changed on the device), the app asks the mouse for its
#      SmartShift mode again, and the card then shows the mode that read
#      returns instead of the one it showed before.
#
#   2. The same holds when the change lands while a SmartShift read is still
#      out: the app asks again (before or after the earlier read answers), and
#      the card ends on the mode from after the press, even when the earlier
#      read answers last with the mode from before it.
#
# The tests never name how the re-read is triggered or how the old answer is
# set aside. They count the SmartShift read requests the app sends on its
# command channel and answer them, so any mechanism that issues a fresh read
# after the revision moves and keeps a late pre-change answer off the card
# passes (discarding the in-flight read, a generation token, and so on).
#
# gpui's TestAppContext runs headless (no display server), and the test steps
# the executor with `run_until_parked`, so it is deterministic.
#
# Mechanics: back up the source file, append the test module, run only the
# added tests by name, restore the original (even on failure), and fail if
# either test is missing from the run (a filter that matched nothing must not
# read as a pass) or did not report `ok`.

set -uo pipefail

# The checkout the suite grades lives at /repo/${REPO_NAME}; the runner exports
# REPO_NAME.
REPO="/repo/${REPO_NAME:?REPO_NAME must be set by the verifier runner}"
SMARTSHIFT="$REPO/crates/openlogi-desktop/src/state/tests/smartshift.rs"

MARK=__reward_device_reported_change_re_reads_smartshift
MARK_INFLIGHT=__reward_change_during_a_read_does_not_show_the_old_mode

restore() {
    [ -f "$SMARTSHIFT.rewardbak" ] && mv -f "$SMARTSHIFT.rewardbak" "$SMARTSHIFT"
}
trap restore EXIT

cp -p "$SMARTSHIFT" "$SMARTSHIFT.rewardbak"

cat >> "$SMARTSHIFT" <<'RUST'

#[cfg(test)]
mod __reward_verify_smartshift_reread {
    use std::sync::Arc;

    use gpui::AppContext as _;
    use openlogi_core::config::Config;
    use openlogi_core::device::DeviceInventory;
    use openlogi_core::hid::{
        DeviceRoute, SmartShiftAutoDisengage, SmartShiftMode, SmartShiftStatus,
        SmartShiftThreshold,
    };

    use crate::services::assets::AssetResolver;
    use crate::services::ipc::{Command, ReadSmartShift};
    use crate::state::tests::direct_inventory;
    use crate::state::{AppState, DeviceKey, Load, Sources};

    const UNIT_ID: [u8; 4] = [0xa3, 0x93, 0xca, 0xe0];

    fn status(mode: SmartShiftMode) -> SmartShiftStatus {
        SmartShiftStatus {
            mode,
            auto_disengage: SmartShiftAutoDisengage::Threshold(
                SmartShiftThreshold::from_rounded(12.0),
            ),
            tunable_torque: None,
        }
    }

    /// Answer every SmartShift read the app has queued with `status`, and
    /// return the routes they were asked on. Every other command is dropped.
    fn answer_smartshift_reads(
        receiver: &mut tokio::sync::mpsc::UnboundedReceiver<Command>,
        status: SmartShiftStatus,
    ) -> Vec<DeviceRoute> {
        std::iter::from_fn(|| receiver.try_recv().ok())
            .filter_map(|command| match command {
                Command::ReadSmartShift(ReadSmartShift { route, reply }) => {
                    let _ = reply.send(Ok(status));
                    Some(route)
                }
                _ => None,
            })
            .collect()
    }

    fn shown(cx: &gpui::TestAppContext, key: &DeviceKey) -> Load<Arc<SmartShiftStatus>> {
        cx.read(|cx| {
            AppState::try_read(cx)
                .expect("state installed")
                .smartshift_load_for(key)
        })
    }

    fn inventory_with_revision(revision: u64) -> DeviceInventory {
        let mut inventory = direct_inventory(UNIT_ID);
        inventory.paired[0].settings_revision = revision;
        inventory
    }

    /// Install `state` with live reads, as the app does, and let it read the
    /// selected mouse.
    fn install(state: AppState, cx: &mut gpui::TestAppContext) {
        cx.update(|cx| {
            let runtime: Arc<dyn swr_core::Runtime> = Arc::new(swr_gpui::GpuiRuntime::new(cx));
            let client = swr_core::SwrClient::builder().build(runtime.clone());
            let state = cx.new(|_| {
                let mut state = state;
                state.connect_device_reads(client, runtime);
                state
            });
            AppState::set_global(state, cx);
            AppState::load_current_device_reads(cx);
        });
        cx.run_until_parked();
    }

    /// The mouse flips its wheel mode itself (the mode-shift button) and
    /// reports it: the device layer moves the mouse's settings revision.
    fn report_device_side_change(cx: &mut gpui::TestAppContext, resolver: &AssetResolver) {
        cx.update(|cx| {
            AppState::update(cx, |state, _| {
                let _ = state.refresh_inventories(&[inventory_with_revision(1)], &[], resolver, &[]);
            });
        });
        cx.run_until_parked();
    }

    #[gpui::test]
    fn __reward_device_reported_change_re_reads_smartshift(cx: &mut gpui::TestAppContext) {
        let resolver = AssetResolver::new();
        let (commands, mut receiver) = tokio::sync::mpsc::unbounded_channel();
        let state = AppState::new(Sources {
            inventories: &[direct_inventory(UNIT_ID)],
            ..Sources::in_memory(Config::ephemeral(), &resolver, commands)
        });
        let key = state.current_record().expect("mouse").device_key();

        install(state, cx);

        let ratchet = status(SmartShiftMode::Ratchet);
        let first = answer_smartshift_reads(&mut receiver, ratchet);
        assert!(!first.is_empty(), "the app reads the selected mouse's SmartShift mode");
        cx.run_until_parked();
        assert_eq!(shown(cx, &key), Load::Ready(Arc::new(ratchet)));

        report_device_side_change(cx, &resolver);

        let freespin = status(SmartShiftMode::Free);
        let reread = answer_smartshift_reads(&mut receiver, freespin);
        assert!(
            !reread.is_empty(),
            "a settings change the mouse reports must make the app read SmartShift again; \
             otherwise the card keeps the mode it showed before the button was pressed",
        );
        assert!(
            reread.iter().all(|route| first.contains(route)),
            "the re-read must go to the same mouse",
        );
        cx.run_until_parked();
        assert_eq!(
            shown(cx, &key),
            Load::Ready(Arc::new(freespin)),
            "after the re-read answers, the card shows the mouse's new mode",
        );
    }

    #[gpui::test]
    fn __reward_change_during_a_read_does_not_show_the_old_mode(cx: &mut gpui::TestAppContext) {
        let resolver = AssetResolver::new();
        let (commands, mut receiver) = tokio::sync::mpsc::unbounded_channel();
        let state = AppState::new(Sources {
            inventories: &[direct_inventory(UNIT_ID)],
            ..Sources::in_memory(Config::ephemeral(), &resolver, commands)
        });
        let key = state.current_record().expect("mouse").device_key();
        install(state, cx);

        // The app has asked the mouse for its mode, and that read is still out
        // when the mouse reports the button press.
        let outstanding: Vec<ReadSmartShift> = std::iter::from_fn(|| receiver.try_recv().ok())
            .filter_map(|command| match command {
                Command::ReadSmartShift(read) => Some(read),
                _ => None,
            })
            .collect();
        assert!(!outstanding.is_empty(), "the app reads the selected mouse's SmartShift mode");
        report_device_side_change(cx, &resolver);

        // The read from before the press answers late, with the old mode. The
        // app may already have asked again or may ask once this answer is in.
        for read in outstanding {
            let _ = read.reply.send(Ok(status(SmartShiftMode::Ratchet)));
        }
        cx.run_until_parked();

        // Every read started after the press answers with the new mode.
        let freespin = status(SmartShiftMode::Free);
        let reread = answer_smartshift_reads(&mut receiver, freespin);
        assert!(
            !reread.is_empty(),
            "a press reported while a SmartShift read is still out must lead to a new read",
        );
        cx.run_until_parked();
        assert_eq!(
            shown(cx, &key),
            Load::Ready(Arc::new(freespin)),
            "the card must end on the mode from after the press, not the late answer to the \
             read from before it",
        );
    }
}
RUST

cd "$REPO" || exit 1

LOG=$(mktemp)
# Run only the added tests by name. Compiling the binary's test target still
# requires the agent's own code to build.
cargo test -p openlogi-desktop --bin openlogi-desktop "__reward_" -- --test-threads=1 2>&1 | tee "$LOG"
CARGO_STATUS=${PIPESTATUS[0]}

status=0
if [ "$CARGO_STATUS" -ne 0 ]; then
    echo "FAIL: cargo test exited $CARGO_STATUS" >&2
    status=1
fi
for mark in "$MARK" "$MARK_INFLIGHT"; do
    if ! grep -Eq "test .*${mark} \.\.\. ok" "$LOG"; then
        echo "FAIL: ${mark} did not run or did not pass" >&2
        status=1
    fi
done

rm -f "$LOG"
exit "$status"
