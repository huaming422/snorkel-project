//! Behavioural verifier for the hi-res wheel event decode.
//!
//! Tests through the PRE-EXISTING public entry point of the `0x2121`
//! hi-res wheel feature in the `openlogi-hidpp` crate (library name
//! `hidpp`):
//!
//!   * `hidpp::feature::hires_wheel::decode_event(&v20::Message, u8, u8)
//!      -> Option<HiResWheelEvent>`
//!   * `hidpp::feature::hires_wheel::{HiResWheelEvent, WheelRatchetState}`
//!   * `hidpp::protocol::v20::{Message, MessageHeader}`, `hidpp::nibble::U4`
//!
//! `decode_event` has a stable signature (feeding it a synthetic report is
//! exactly how the crate's own module tests exercise it). It is the public
//! decoder the smooth-wheel session calls on every diverted wheel report, so
//! it is where a short movement report turns into scroll input. The test
//! imports ONLY these pre-existing public items, nothing a fix would add.
//! A report that arrives in a SHORT frame carries three payload bytes on the
//! wire; the same report in a LONG frame carries sixteen. The
//! verifier observes what `decode_event` returns for each, never how the
//! implementation decides it.
//!
//! Decoupling rationale:
//!   * The short-frame case asserts only whether a movement decodes at all
//!     (`None` vs `WheelMovement(_)`). A short frame carries three payload
//!     bytes, fewer than a movement's five, so before the fix the missing
//!     bytes were filled with zeroes and the report still became a movement.
//!   * The ratchet case asserts the `RatchetSwitch` variant decodes from a
//!     short frame, the behaviour that a blanket "drop every short report"
//!     over-correction would break. It does not assert which byte the state
//!     came from.
//!   * The long-frame case is a regression guard: a full movement keeps
//!     decoding both of its deltas exactly as the crate's own decode test
//!     (`hires_wheel` module tests) expects, so a fix that drops or zeroes
//!     the horizontal delta instead of the short report fails.

use hidpp::feature::hires_wheel::{decode_event, HiResWheelEvent, WheelMovementData};
use hidpp::nibble::U4;
use hidpp::protocol::v20::{Message, MessageHeader};

const DEVICE_INDEX: u8 = 2;
const FEATURE_INDEX: u8 = 0x0e;

/// Movement event sub-id (function id 0) and ratchet-switch sub-id
/// (function id 1), as the wheel feature dispatches them. These are the
/// protocol's stable HID++ sub-ids, not fix-invented values.
const MOVEMENT_SUB_ID: u8 = 0;
const RATCHET_SUB_ID: u8 = 1;

fn header(function_id: u8) -> MessageHeader {
    MessageHeader {
        device_index: DEVICE_INDEX,
        feature_index: FEATURE_INDEX,
        function_id: U4::from_lo(function_id),
        // Zero software id: an unsolicited device broadcast, not a reply.
        software_id: U4::from_lo(0),
    }
}

/// A short HID++ 2.0 frame: three payload bytes on the wire.
fn short(function_id: u8, payload: [u8; 3]) -> Message {
    Message::Short(header(function_id), payload)
}

/// A long HID++ 2.0 frame: sixteen payload bytes on the wire. The first
/// `bytes` are set; the rest are zero, exactly as a real long report pads.
fn long(function_id: u8, bytes: &[u8]) -> Message {
    let mut payload = [0u8; 16];
    payload[..bytes.len()].copy_from_slice(bytes);
    Message::Long(header(function_id), payload)
}

/// Root-cause reproduction. A wheel MOVEMENT that arrives in a short frame
/// must be dropped rather than decoded from zero padding: a short frame
/// cannot carry all of a movement's bytes, so pre-fix the missing bytes were
/// read out of padding the device never sent and the report still became
/// scroll input. The identical movement in a long frame still decodes.
///
/// `[1, 0xff, 0xff]` is a complete low-resolution vertical move (resolution
/// bit clear, one period, deltaV = -1) - a payload that looks valid, so the
/// drop is about the wire length, not an unparsable body.
#[test]
fn a_short_movement_is_dropped_but_a_long_one_decodes() {
    assert_eq!(
        decode_event(&short(MOVEMENT_SUB_ID, [1, 0xff, 0xff]), DEVICE_INDEX, FEATURE_INDEX),
        None,
        "a wheel movement in a short frame must be dropped, not decoded from zero padding \
         (pre-fix it decoded as a movement with the missing bytes read as zeroes)",
    );

    assert!(
        matches!(
            decode_event(&long(MOVEMENT_SUB_ID, &[1, 0xff, 0xff]), DEVICE_INDEX, FEATURE_INDEX),
            Some(HiResWheelEvent::WheelMovement(_)),
        ),
        "the same movement in a long frame still carries its full payload and must decode",
    );
}

/// The drop is specific to the movement event, not a blanket rejection of
/// short frames. A ratchet-switch broadcast reads a single byte, so it still
/// decodes from a short frame. A fix that drops every short report (an
/// over-correction) would fail here.
#[test]
fn a_short_ratchet_switch_still_decodes() {
    assert!(
        matches!(
            decode_event(&short(RATCHET_SUB_ID, [1, 0, 0]), DEVICE_INDEX, FEATURE_INDEX),
            Some(HiResWheelEvent::RatchetSwitch(_)),
        ),
        "a ratchet switch reads one byte and must still decode from a short frame; only the \
         movement, which needs more bytes than a short frame carries, is dropped",
    );
}

/// Regression guard. A movement in a long frame carries all five of its
/// payload bytes and decodes both deltas, as before the fix. High resolution,
/// 3 periods, deltaV = +120, deltaH = -2 (the crate's own decode-test values).
#[test]
fn a_long_movement_keeps_both_deltas() {
    let mut body = [(1 << 4) | 3, 0, 0, 0, 0];
    body[1..3].copy_from_slice(&120i16.to_be_bytes());
    body[3..5].copy_from_slice(&(-2i16).to_be_bytes());
    let Some(HiResWheelEvent::WheelMovement(WheelMovementData {
        delta_vertical,
        delta_horizontal,
        ..
    })) = decode_event(&long(MOVEMENT_SUB_ID, &body), DEVICE_INDEX, FEATURE_INDEX)
    else {
        panic!("a movement in a long frame must still decode");
    };
    assert_eq!(
        (delta_vertical, delta_horizontal),
        (120, -2),
        "a full-length movement must keep decoding both of its deltas",
    );
}
