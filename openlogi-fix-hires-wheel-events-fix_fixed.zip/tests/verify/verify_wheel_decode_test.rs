//! Regression guard for the hi-res wheel event decode.
//!
//! Tests through the PRE-EXISTING public entry point of the `0x2121`
//! hi-res wheel feature in the `openlogi-hidpp` crate (library name
//! `hidpp`):
//!
//!   * `hidpp::feature::hires_wheel::decode_event(&v20::Message, u8, u8)
//!      -> Option<HiResWheelEvent>`
//!   * `hidpp::feature::hires_wheel::{HiResWheelEvent, WheelMovementData}`
//!   * `hidpp::protocol::v20::{Message, MessageHeader}`, `hidpp::nibble::U4`
//!
//! `decode_event` has a stable signature (feeding it a synthetic report is
//! exactly how the crate's own module tests exercise it). The test imports
//! ONLY these pre-existing public items, nothing a fix would add.
//!
//! The test passes on the unchanged code and must keep passing: a full-length
//! movement keeps decoding both of its deltas, exactly as the crate's own
//! `movement_carries_both_deltas` module test expects. Short reports are
//! checked in verify_device_events.sh.

use hidpp::feature::hires_wheel::{decode_event, HiResWheelEvent, WheelMovementData};
use hidpp::nibble::U4;
use hidpp::protocol::v20::{Message, MessageHeader};

const DEVICE_INDEX: u8 = 2;
const FEATURE_INDEX: u8 = 0x0e;

/// Movement event sub-id (function id 0), as the wheel feature dispatches
/// it. This is the protocol's stable HID++ sub-id, not a fix-invented value.
const MOVEMENT_SUB_ID: u8 = 0;

fn header(function_id: u8) -> MessageHeader {
    MessageHeader {
        device_index: DEVICE_INDEX,
        feature_index: FEATURE_INDEX,
        function_id: U4::from_lo(function_id),
        // Zero software id: an unsolicited device broadcast, not a reply.
        software_id: U4::from_lo(0),
    }
}

/// A long HID++ 2.0 frame: sixteen payload bytes on the wire. The first
/// `bytes` are set; the rest are zero, exactly as a real long report pads.
fn long(function_id: u8, bytes: &[u8]) -> Message {
    let mut payload = [0u8; 16];
    payload[..bytes.len()].copy_from_slice(bytes);
    Message::Long(header(function_id), payload)
}

/// A movement in a long frame decodes both deltas, as before. High
/// resolution, 3 periods, deltaV = +120, deltaH = -2 (the crate's own
/// decode-test values).
#[test]
fn a_long_movement_keeps_both_deltas() {
    let mut body = [(1 << 4) | 3, 0, 0, 0, 0];
    body[1..3].copy_from_slice(&120i16.to_be_bytes());
    body[3..5].copy_from_slice(&(-2i16).to_be_bytes());
    let Some(HiResWheelEvent::WheelMovement(WheelMovementData {
        delta_vertical,
        delta_horizontal,
        ..
    })) = decode_event(&long(MOVEMENT_SUB_ID, &body), DEVICE_INDEX, FEATURE_INDEX)
    else {
        panic!("a movement in a long frame must still decode");
    };
    assert_eq!(
        (delta_vertical, delta_horizontal),
        (120, -2),
        "a full-length movement must keep decoding both of its deltas",
    );
}
