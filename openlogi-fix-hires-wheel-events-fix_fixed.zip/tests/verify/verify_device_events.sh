#!/usr/bin/env bash
#
# Behavioural verifier for the device layer (crate `openlogi-device`). Two
# behaviours are checked here, both observable only from inside the crate (the
# smooth-wheel session's report handler, the event-index table, the
# subscription decoder and the revision counter are all crate-private), so this
# verifier appends `#[cfg(test)]` modules to the crate's own source and runs
# `cargo test --lib` over just those added tests. A child module sees its
# ancestors' private items, so the added tests drive the crate through the SAME
# entry points the crate's own unit tests use: no behaviour is imported, only
# exercised.
#
# The added tests assert BEHAVIOUR, never a particular internal shape:
#
#   1. With the main wheel diverted (what the per-mouse Smooth wheel option
#      does), a wheel-movement report that arrives as a short HID++ report does
#      not reach the dispatcher as scroll input, while the same movement in a
#      long report still does. The test arms the wheel through the session's
#      own arming code against a scripted mouse, feeds both reports to the
#      session's report handler, and asserts only the inputs it emits.
#
#   2. A device-reported wheel ratchet/free-spin switch on the `0x2121` index
#      is treated as a device-side settings change, like the other setting
#      broadcasts: it advances the device's settings-revision counter, and
#      the subscription reports it (any event source). The switch is sent as a
#      short report, so this also covers a short ratchet switch still being
#      recognized. A wheel MOVEMENT on the same index must NOT advance the
#      revision and must NOT be reported. The test asserts only the revision
#      counter and the decode result, so any structure with that behaviour
#      passes.
#
# Mechanics: back up the two source files, append the test modules, run only
# the added tests by name, restore the originals (even on failure), and fail if
# either added test is missing from the run (a filter that matched nothing must
# not read as a pass) or did not report `ok`.

set -uo pipefail

# The checkout the suite grades lives at /repo/${REPO_NAME}; the runner exports
# REPO_NAME. Derive the path from it so this verifier reads the same tree the
# patch was applied to, never a divergent hardcoded path.
REPO="/repo/${REPO_NAME:?REPO_NAME must be set by the verifier runner}"
GESTURE="$REPO/crates/openlogi-device/src/session/gesture.rs"
EVENTS="$REPO/crates/openlogi-device/src/inventory/events.rs"

MARK_SHORT=__reward_short_movement_report_does_not_scroll
MARK_RATCHET=__reward_ratchet_switch_bumps_revision

restore() {
    [ -f "$GESTURE.rewardbak" ] && mv -f "$GESTURE.rewardbak" "$GESTURE"
    [ -f "$EVENTS.rewardbak" ] && mv -f "$EVENTS.rewardbak" "$EVENTS"
}
trap restore EXIT

cp -p "$GESTURE" "$GESTURE.rewardbak"
cp -p "$EVENTS" "$EVENTS.rewardbak"

# --- a short movement report does not become scroll input ---------------------
cat >> "$GESTURE" <<'RUST'

#[cfg(test)]
mod __reward_verify_short_wheel_movement {
    use hidpp::device::Device;
    use hidpp::nibble::U4;

    use super::arm::arm_controls_into;
    use super::*;
    use crate::channel::scripted::{ScriptedRawHidChannel, scripted_channel};

    const DEVICE_INDEX: u8 = 0xff;
    /// Feature index the scripted mouse answers for `0x2121`.
    const HIRES: u8 = 3;

    /// A mouse whose only capturable feature is a `0x2121` wheel (multiplier
    /// 8, no extra capabilities) that applies and echoes every mode write.
    fn wheel_mouse() -> (ScriptedRawHidChannel, crate::replay::ReplayChannelHandle) {
        let mode = Arc::new(Mutex::new([0u8, 0x05, 0x07]));
        ScriptedRawHidChannel::with_dynamic_responder(move |request: &[u8]| {
            let mut response = vec![0; 20];
            response[..4].copy_from_slice(&request[..4]);
            response[0] = 0x11;
            let mut mode = mode.lock().unwrap();
            match (request[2], request[3] >> 4) {
                (0, 1) => response[4] = 4,
                (0, 0) => {
                    if u16::from_be_bytes([request[4], request[5]]) == 0x2121 {
                        response[4] = HIRES;
                    }
                }
                (HIRES, 0) => response[4] = 8,
                (HIRES, 1) => response[4..7].copy_from_slice(&*mode),
                (HIRES, 2) => {
                    mode.copy_from_slice(&request[4..7]);
                    response[4..7].copy_from_slice(&*mode);
                }
                _ => {}
            }
            Some(response)
        })
    }

    /// The same wheel movement (low resolution, one period, deltaV = -1, a
    /// complete vertical move) as a 3-byte short report or a 16-byte long one.
    fn movement(short: bool) -> v20::Message {
        let header = v20::MessageHeader {
            device_index: DEVICE_INDEX,
            feature_index: HIRES,
            function_id: U4::from_lo(0),
            // Zero software id: an unsolicited device broadcast, not a reply.
            software_id: U4::from_lo(0),
        };
        let body = [1, 0xff, 0xff];
        if short {
            v20::Message::Short(header, body)
        } else {
            let mut payload = [0u8; 16];
            payload[..3].copy_from_slice(&body);
            v20::Message::Long(header, payload)
        }
    }

    #[tokio::test]
    async fn __reward_short_movement_report_does_not_scroll() {
        let (raw, _handle) = wheel_mouse();
        let channel = scripted_channel(raw).await;
        let device = Device::new(channel.clone(), DEVICE_INDEX).await.unwrap();
        let spec = CaptureSpec {
            divert_main_wheel: Some(MainWheelDivert {
                resolution: None,
                inverted: None,
            }),
            ..CaptureSpec::default()
        };
        let mut armed = ArmedControls::default();
        arm_controls_into(&device, &channel, DEVICE_INDEX, &spec, &mut armed)
            .await
            .unwrap();
        assert!(armed.main_wheel.is_some(), "the main wheel is diverted");

        let capture = GestureCapture::new(armed);
        let (sink, mut inputs) = mpsc::unbounded_channel();
        let handler = capture.report_handler(DEVICE_INDEX, sink);

        handler(&movement(true));
        assert_eq!(
            std::iter::from_fn(|| inputs.try_recv().ok()).collect::<Vec<_>>(),
            Vec::<CapturedInput>::new(),
            "a wheel-movement report that arrives as a short report must not turn into scrolling",
        );

        handler(&movement(false));
        let scrolled = std::iter::from_fn(|| inputs.try_recv().ok()).collect::<Vec<_>>();
        assert!(
            matches!(
                scrolled.as_slice(),
                [CapturedInput::MainWheel { delta: -1, .. }]
            ),
            "the same movement in a long report must still scroll, got {scrolled:?}",
        );
    }
}
RUST

# --- a ratchet switch is a settings change; a movement is not ------------------
cat >> "$EVENTS" <<'RUST'

#[cfg(test)]
mod __reward_verify_wheel_settings_change {
    use hidpp::nibble::U4;
    use hidpp::protocol::v20;

    use super::*;

    fn mk_state() -> Arc<SubscriptionState> {
        let (notifier, _receiver) = event_channel();
        Arc::new(SubscriptionState {
            protocol: Some(ReceiverProtocol::Bolt),
            devices: RwLock::new(Vec::new()),
            receiver_snapshot_depth: AtomicUsize::new(0),
            notifier,
        })
    }

    /// Build an unsolicited broadcast (software id 0) from device index 1 on
    /// `feature_index` with the given event sub-id. `long` selects a 16-byte
    /// long report; otherwise a 3-byte short report.
    fn broadcast(feature_index: u8, sub_id: u8, body: [u8; 3], long: bool) -> HidppMessage {
        let header = v20::MessageHeader {
            device_index: 1,
            feature_index,
            function_id: U4::from_lo(sub_id),
            software_id: U4::from_lo(0),
        };
        if long {
            let mut payload = [0u8; 16];
            payload[..3].copy_from_slice(&body);
            v20::Message::Long(header, payload).into()
        } else {
            v20::Message::Short(header, body).into()
        }
    }

    #[test]
    fn __reward_ratchet_switch_bumps_revision() {
        let state = mk_state();
        let handle = EventSubscriptionHandle {
            state: Arc::clone(&state),
        };
        // A mouse whose feature table carries the hi-res wheel (`0x2121`) at
        // runtime table position 3 (0x0001, 0x0003, 0x2121).
        let features = EventFeatureIndices::from_feature_ids(&[0x0001, 0x0003, 0x2121]);
        handle.register_device(1, features);
        assert_eq!(handle.settings_revision(1), 0, "no broadcasts seen yet");

        // Ratchet/free-spin switch (sub-id 1): the mouse telling the host its
        // wheel mode flipped on-device. One byte of body, so it is carried by a
        // short report. This is a device-side settings change: it must advance
        // the revision so a client re-reads SmartShift, and it must be reported
        // so a reconciliation publishes that revision.
        let source = state.decode(broadcast(3, 1, [0, 0, 0], false), false);
        assert!(
            source.is_some(),
            "a wheel ratchet switch must be reported like the other device-side setting \
             changes, so a reconciliation publishes the new revision",
        );
        assert_eq!(
            handle.settings_revision(1),
            1,
            "a wheel ratchet switch on the 0x2121 index must be counted as a settings change \
             and advance settings_revision",
        );

        // Wheel MOVEMENT (sub-id 0) on the same index: ordinary scroll input,
        // not a setting. It must NOT advance the revision or be reported. A fix
        // that treats every wheel report as a settings change, or that requests
        // a reconciliation per scroll, fails here.
        let source = state.decode(broadcast(3, 0, [1, 0xff, 0xff], true), false);
        assert!(
            source.is_none(),
            "a wheel movement is input; reporting it would request a reconciliation on every scroll",
        );
        assert_eq!(
            handle.settings_revision(1),
            1,
            "a wheel movement is input, not a settings change, and must not advance \
             settings_revision",
        );
    }
}
RUST

cd "$REPO" || exit 1

LOG=$(mktemp)
# Run only the two added tests by name. Compiling the crate's test target still
# requires the agent's own code to build; running by name isolates grading to
# these behavioural assertions.
cargo test -p openlogi-device --lib "__reward_" -- --test-threads=1 2>&1 | tee "$LOG"
CARGO_STATUS=${PIPESTATUS[0]}

status=0
if [ "$CARGO_STATUS" -ne 0 ]; then
    echo "FAIL: cargo test exited $CARGO_STATUS" >&2
    status=1
fi
# A filter that matched nothing exits 0 but runs no tests: require each added
# test to have run and reported ok.
for mark in "$MARK_SHORT" "$MARK_RATCHET"; do
    if ! grep -Eq "test .*${mark} \.\.\. ok" "$LOG"; then
        echo "FAIL: ${mark} did not run or did not pass" >&2
        status=1
    fi
done

rm -f "$LOG"
exit "$status"
