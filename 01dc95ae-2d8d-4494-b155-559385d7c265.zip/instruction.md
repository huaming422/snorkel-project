## Task

Long sequences of add, remove, and replace operations through OPA's `json.patch` builtin create excessive heap allocations and memory pressure. This shows up in tools that repeatedly edit Rego AST or data documents, especially on larger workloads.

Reduce both heap allocation count and allocated bytes substantially across churn-heavy `json.patch` operations; a reduction of around one fifth on a representative workload is the target. Preserve the results of `json.patch`, `json.remove`, and `json.filter`, including values a caller retains across later calls. CPU time need not improve; unchanged wall clock time is fine.
