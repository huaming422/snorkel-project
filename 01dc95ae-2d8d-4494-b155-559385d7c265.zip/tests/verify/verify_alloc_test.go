// Copyright 2026 The OPA Authors.  All rights reserved.
// Use of this source code is governed by an Apache2
// license that can be found in the LICENSE file.

// Allocation and memory checks for the existing JSON-patch built-in entry point.
// The same-package tests call builtinJSONPatch and inspect its returned value.
//
// All identifiers carry a `vrfAlloc` prefix so this file composes cleanly with
// the package's own test files (which define e.g. runJSONPatchBenchmarkTest).
//
// The first workload adds and removes nested values; the second adds, replaces,
// and removes them. Both start with an empty object and must finish empty.
//
// The pinned image fixes the Go toolchain. The checks use allocations and bytes
// per operation, not elapsed time.
//
// Each workload is checked for its expected result before measurement.

package topdown

import (
	"context"
	"strconv"
	"testing"

	"github.com/open-policy-agent/opa/v1/ast"
)

// vrfAllocThreshold is the maximum allocs/op the churn workload may perform.
//
// Provenance: the pre-change implementation is measured (author-validated in the
// built image, go1.26.3) at about 20019 allocs/op for this workload; a
// passing reference measures about 12050. 16000 sits
// well below the baseline and comfortably above the reference result. It
// requires a substantial reduction on this workload without prescribing a
// particular reuse strategy. Smaller wins can still miss this pass line.
const vrfAllocThreshold = 16000
const vrfBytesThreshold = 600000
const vrfReplaceThreshold = 24000

// vrfAllocChurn is the number of add-then-remove pairs in the workload. 2000
// nested-composite inserts followed by 2000 removes is large enough that the
// measured allocation gap
// is unambiguous, while staying fast enough to measure many iterations.
const vrfAllocChurn = 2000

// vrfAllocBuildChurnPatches returns a json.patch operation array that adds
// vrfAllocChurn nested-composite values under distinct keys, then removes all of
// them in reverse order — the in-place "churn" pattern the task targets.
func vrfAllocBuildChurnPatches(m int, replace bool) *ast.Array {
 count := 2 * m
 if replace { count = 3 * m }
 out := make([]*ast.Term, 0, count)
	for i := 0; i < m; i++ {
		path := ast.StringTerm("/k" + strconv.Itoa(i))
		val := ast.ObjectTerm([2]*ast.Term{
			ast.StringTerm("inner"),
			ast.ArrayTerm(ast.InternedTerm(i), ast.InternedTerm(i+1)),
		})
		out = append(out, vrfAllocPatchOp("add", path, val))
		if replace {
			out = append(out, vrfAllocPatchOp("replace", path, ast.ObjectTerm([2]*ast.Term{ast.StringTerm("next"), ast.ArrayTerm(ast.InternedTerm(i+2))})))
		}
	}
	for i := m - 1; i >= 0; i-- {
		out = append(out, vrfAllocPatchOp("remove", ast.StringTerm("/k"+strconv.Itoa(i)), nil))
	}
	return ast.NewArray(out...)
}

// vrfAllocPatchOp builds one json.patch operation object {op, path[, value]}.
func vrfAllocPatchOp(op string, path, value *ast.Term) *ast.Term {
	pairs := [][2]*ast.Term{
		{ast.InternedTerm("op"), ast.InternedTerm(op)},
		{ast.InternedTerm("path"), path},
	}
	if value != nil {
		pairs = append(pairs, [2]*ast.Term{ast.InternedTerm("value"), value})
	}
	return ast.NewTerm(ast.NewObject(pairs...))
}

// vrfAllocCapture invokes builtinJSONPatch once and returns the patched term it
// yields through its iter callback (or a fatal error if the built-in fails).
func vrfAllocCapture(t *testing.T, operands []*ast.Term) *ast.Term {
	t.Helper()
	var got *ast.Term
	iter := func(res *ast.Term) error {
		got = res
		return nil
	}
	if err := builtinJSONPatch(BuiltinContext{Context: context.Background()}, operands, iter); err != nil {
		t.Fatalf("builtinJSONPatch returned error: %v", err)
	}
	if got == nil {
		t.Fatal("builtinJSONPatch did not yield a result term")
	}
	return got
}

// TestVerifyJSONPatchChurnAllocations measures repeated nested edits.
func TestVerifyJSONPatchChurnAllocations(t *testing.T) {
	source := ast.NewObject()
	patches := vrfAllocBuildChurnPatches(vrfAllocChurn, false)
	operands := []*ast.Term{ast.NewTerm(source), ast.NewTerm(patches)}

	// Correctness guard: adding then removing every key must round-trip back to
	// the empty object. A solution that wins on allocations by producing a wrong
	// or truncated result fails here instead of passing the gate.
	got := vrfAllocCapture(t, operands)
	want := ast.NewObject()
	if got.Value.Compare(want) != 0 {
		t.Fatalf("churn workload produced wrong result: got %v, want %v", got, want)
	}

	// Measure allocations/op for the built-in over the churn workload.
	res := testing.Benchmark(func(b *testing.B) {
		b.ReportAllocs()
		iter := func(*ast.Term) error { return nil }
		for b.Loop() {
			if err := builtinJSONPatch(BuiltinContext{Context: context.Background()}, operands, iter); err != nil {
				b.Fatalf("builtinJSONPatch returned error: %v", err)
			}
		}
	})

	allocs := res.AllocsPerOp()
	t.Logf("json.patch churn workload: %d allocs/op, %d B/op (threshold %d allocs/op)",
		allocs, res.AllocedBytesPerOp(), vrfAllocThreshold)

	if res.N == 0 {
		t.Fatal("benchmark did not run any iterations")
	}
	if allocs > vrfAllocThreshold {
		t.Fatalf("json.patch churn workload allocates too much: %d allocs/op exceeds threshold %d", allocs, vrfAllocThreshold)
	}
	if bytes := res.AllocedBytesPerOp(); bytes > vrfBytesThreshold {
		t.Fatalf("json.patch churn workload uses too much allocation memory: %d B/op exceeds threshold %d", bytes, vrfBytesThreshold)
	}
}

func TestVerifyJSONPatchReplaceChurnAllocations(t *testing.T) {
	operands := []*ast.Term{ast.NewTerm(ast.NewObject()), ast.NewTerm(vrfAllocBuildChurnPatches(vrfAllocChurn, true))}
	if got := vrfAllocCapture(t, operands); got.Value.Compare(ast.NewObject()) != 0 {
		t.Fatalf("replace churn produced wrong result: %v", got)
	}
	res := testing.Benchmark(func(b *testing.B) {
		iter := func(*ast.Term) error { return nil }
		for b.Loop() {
			if err := builtinJSONPatch(BuiltinContext{Context: context.Background()}, operands, iter); err != nil {
				b.Fatalf("builtinJSONPatch returned error: %v", err)
			}
		}
	})
	if res.N == 0 { t.Fatal("benchmark did not run any iterations") }
	if allocs := res.AllocsPerOp(); allocs > vrfReplaceThreshold {
		t.Fatalf("replace churn allocates too much: %d allocs/op exceeds threshold %d", allocs, vrfReplaceThreshold)
	}
}
