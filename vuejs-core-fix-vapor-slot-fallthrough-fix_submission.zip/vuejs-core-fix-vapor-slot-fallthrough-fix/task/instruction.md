## Task

We've got a mixed app running the vapor runtime and the classic virtual-DOM
runtime side by side, and slot cloning breaks across the boundary.

A virtual-DOM component renders a slot and clones the slotted child element to
add a couple of extras onto it: an extra attribute and a click handler. This is
the "as-child" pattern that libraries like Reka UI and Nuxt UI rely on. When
the slotted content comes from another virtual-DOM parent, those extras land on
the rendered element fine. But feed it the exact same content from a vapor
parent and they silently go missing: the element renders with the added
attribute gone and the click handler wrong, doing nothing. Same clone, same
content, only the parent runtime differs.

Both cases should come out identical. Whatever the clone adds should reach the
rendered element whether a vapor parent or a virtual-DOM parent produced the
slot content.

This is in the framework's interop, not application code, so fix it there.
Keep the public API shape as it is, and don't bend the project's own tests to
pass.
