#!/usr/bin/env bash
# test-setup.sh — environment bootstrap for the verifier. Sourced (not
# exec'd) by the harbor verifier runner so env vars stay alive for vitest.
#
# Idempotent. The Dockerfile already installs the full pnpm dependency
# closure (pnpm install --frozen-lockfile) at the base commit, so the
# install below is an offline no-op replay in the normal case; it only does
# real work if an agent erased node_modules. Vue core's unit tests run via
# vite-plus (vitest) directly against TypeScript source (aliased in
# vite.config.ts) — no per-package build or native binding is required for
# the runtime-vapor interop specs.

set -e

REPO_DIR="${REPO_DIR:-/repo/core}"
cd "$REPO_DIR"

node --version
pnpm --version

# Reinstall the workspace dependency closure only if an agent removed it.
# Offline-first: the pnpm store was warmed at build time, so --offline
# replays from /opt/cache/pnpm without touching the network.
if [ ! -d "node_modules/.pnpm" ]; then
    echo "[test-setup] pnpm install (offline, frozen)..."
    pnpm install --frozen-lockfile --offline > /tmp/test-setup-install.log 2>&1 \
        || { tail -40 /tmp/test-setup-install.log; exit 1; }
fi

# Make the workspace bin dir available (vitest, vp).
export PATH="$REPO_DIR/node_modules/.bin:$PATH"

echo "[test-setup] ready: $REPO_DIR (node=$(node --version), pnpm=$(pnpm --version))"
