"""Behavioural verifier for clone extras crossing the vapor/virtual-DOM slot
boundary.

The acceptance signal is a TypeScript spec
(`verify_slot_fallthrough.spec.ts`, shipped alongside this file) that mounts a
virtual-DOM "as-child" wrapper over slot content from both a virtual-DOM parent
and a vapor parent and asserts, through the live DOM, that the cloned extras
(attribute, class, style, listener) land identically in both cases. The spec
only runs under the repo's own test toolchain: it needs the jsdom environment,
the `toHaveBeenWarned` matcher, and the package aliases that the repo's vitest
project wires up via `scripts/setup-vitest.ts`.

So this module is a thin driver. It runs under the isolated verifier
interpreter (stdlib + pytest only — no repository imports), drops the spec into
the repo's interop test directory, invokes the repo's vitest scoped to the one
project that supplies that setup, parses the JSON report, and asserts every test
passed. The spec is removed again in a `finally` so the agent's working tree is
left untouched.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

REPO_DIR = Path(os.environ.get("REPO_DIR", "/repo/core"))

# The repo's interop specs live here; the project that runs them
# (`unit-jsdom`) includes `packages/.../runtime-vapor/**/*.spec.ts` with the
# jsdom environment and `scripts/setup-vitest.ts` loaded. The spec ships next
# to this file (the generator copies verify/ siblings into /tests/verify/).
SPEC_NAME = "verify_slot_fallthrough.spec.ts"
SPEC_SRC = Path(__file__).parent / SPEC_NAME
SPEC_DEST_DIR = REPO_DIR / "packages" / "runtime-vapor" / "__tests__"

# Scope vitest to the single spec, under the jsdom project that supplies the
# setup file. `--reporter=json` with `--outputFile` writes a machine-readable
# report outside the repo tree so it can never leak into a diff.
VITEST_PROJECT = "unit-jsdom"

# verify.toml's outer budget is 1800s; keep the child well under it.
VITEST_TIMEOUT_SEC = 1500


def _run(cmd: list[str], timeout: int) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=timeout,
        cwd=str(REPO_DIR),
        check=False,
    )


@pytest.fixture(scope="session")
def vitest_report() -> dict[str, object]:
    """Place the spec, run the repo's vitest once, return the parsed report."""
    assert SPEC_SRC.is_file(), (
        f"behavioural spec {SPEC_SRC} is missing — it must ship next to "
        f"verify.py so the driver can place it into the repo test tree."
    )
    assert SPEC_DEST_DIR.is_dir(), (
        f"expected the interop test directory at {SPEC_DEST_DIR}; the repo "
        f"layout changed or REPO_DIR ({REPO_DIR}) is wrong."
    )

    dest = SPEC_DEST_DIR / SPEC_NAME
    report_path = Path(__file__).parent / "_vitest_report.json"
    try:
        shutil.copy(SPEC_SRC, dest)

        # Run through the repo's local vitest binary so the vite-plus config,
        # jsdom environment, setup file, and package aliases all load. Target
        # the spec by path and scope to the single jsdom project.
        cmd = [
            "pnpm",
            "exec",
            "vitest",
            "run",
            str(dest.relative_to(REPO_DIR)),
            "--project",
            VITEST_PROJECT,
            "--reporter=json",
            f"--outputFile={report_path}",
        ]
        proc = _run(cmd, timeout=VITEST_TIMEOUT_SEC)

        parsed: dict[str, object] | None = None
        if report_path.is_file():
            try:
                parsed = json.loads(report_path.read_text())
            except (json.JSONDecodeError, OSError):
                parsed = None

        # Fallback: some vitest builds still emit the JSON document on stdout.
        if parsed is None:
            try:
                parsed = json.loads(proc.stdout)
            except json.JSONDecodeError:
                parsed = None

        assert isinstance(parsed, dict), (
            f"could not obtain a vitest JSON report (exit {proc.returncode}).\n"
            f"--- command ---\n{' '.join(cmd)}\n"
            f"--- stdout (tail) ---\n{proc.stdout[-3000:]}\n"
            f"--- stderr (tail) ---\n{proc.stderr[-3000:]}"
        )
        parsed["_returncode"] = proc.returncode
        parsed["_stdout_tail"] = proc.stdout[-4000:]
        parsed["_stderr_tail"] = proc.stderr[-4000:]
        return parsed
    finally:
        dest.unlink(missing_ok=True)
        report_path.unlink(missing_ok=True)


def _assertions(report: dict[str, object]) -> list[dict[str, object]]:
    """Flatten per-test results from the vitest JSON report."""
    out: list[dict[str, object]] = []
    for suite in report.get("testResults", []) or []:
        for a in suite.get("assertionResults", []) or []:
            out.append(a)
    return out


def test_spec_collected_and_ran(vitest_report: dict[str, object]) -> None:
    """The spec was discovered and produced test results.

    A zero-test run means the project filter matched nothing (the setup file
    never loaded) or the spec failed to collect — either way the signal is
    invalid and must not be read as success.
    """
    num_total = int(vitest_report.get("numTotalTests", 0) or 0)
    assert num_total > 0, (
        "vitest collected zero tests from the behavioural spec. The spec was "
        "not discovered by the jsdom project, or it failed to load.\n"
        f"--- stdout (tail) ---\n{vitest_report.get('_stdout_tail', '')}\n"
        f"--- stderr (tail) ---\n{vitest_report.get('_stderr_tail', '')}"
    )


def test_all_behaviours_pass(vitest_report: dict[str, object]) -> None:
    """Every behavioural case in the spec passes.

    The spec checks the vapor-parent render against the virtual-DOM-parent
    render for the same clone, so a failure here means the extras diverge
    across the boundary (missing attribute, missing listener, missing/wrong
    class or style) or the fix broke one of the boundary cases.
    """
    num_total = int(vitest_report.get("numTotalTests", 0) or 0)
    num_failed = int(vitest_report.get("numFailedTests", 0) or 0)
    num_passed = int(vitest_report.get("numPassedTests", 0) or 0)

    if num_failed:
        failed = [
            a.get("fullName") or a.get("title") or "<unnamed>"
            for a in _assertions(vitest_report)
            if a.get("status") != "passed"
        ]
        detail = "\n".join(f"  - {name}" for name in failed)
        pytest.fail(
            f"{num_failed}/{num_total} behavioural case(s) failed "
            f"(passed={num_passed}):\n{detail}\n"
            f"--- stdout (tail) ---\n{vitest_report.get('_stdout_tail', '')}\n"
            f"--- stderr (tail) ---\n{vitest_report.get('_stderr_tail', '')}"
        )

    assert num_passed == num_total, (
        f"expected all {num_total} cases to pass, got {num_passed}."
    )


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v", *sys.argv[1:]]))
