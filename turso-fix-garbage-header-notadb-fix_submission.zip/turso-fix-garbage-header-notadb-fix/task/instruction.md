## Task

opening a file that isn't a real database (a truncated download, a few hundred bytes of junk, a corrupt file) comes back as "out of memory". nothing is actually low on memory, so people burn time hunting for a phantom leak when the file was simply never a database to begin with. real sqlite rejects these cleanly with "file is not a database", and we should report them the same way. figure out why a non-database file ends up surfacing as an allocation failure and make us classify it the way sqlite does.
