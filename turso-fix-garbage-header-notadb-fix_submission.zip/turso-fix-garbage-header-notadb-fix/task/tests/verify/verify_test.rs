//! Behavioral checks for the "file is not a database" classification.
//!
//! The fail-to-pass checks craft a file that is not a valid database, open it
//! through the engine's public file-open API, and confirm the engine reports it
//! as `LimboError::NotADB` (SQLite result code 26, SQLITE_NOTADB). The same file
//! is opened with the bundled SQLite bindings first, pinning the reference
//! behavior: SQLite rejects every one of these files as "file is not a
//! database". The file-open API and the error variant both pre-date this work,
//! so these checks say nothing about how the header-reading path is structured
//! internally.
//!
//! The carve-out checks guard the opposite direction: a database opened through
//! a page codec, or with an encryption cipher configured, whose header read
//! comes up short must NOT be reclassified as `NotADB`. A codec may transform
//! the magic/header bytes and an encrypted header is not yet decryptable at
//! header-read time, so the plain "not a database" rules must not apply to those
//! paths — the short read is surfaced as-is. These checks drive the public open
//! API and assert the *absence* of `NotADB`; because they live in the
//! runner-injected verifier crate rather than agent-editable source, an
//! over-broad fix that flattens every short read to `NotADB` cannot neutralize
//! them by editing an in-tree test body.
//!
//! Note: short plain files with an otherwise-valid-looking header (good magic,
//! valid page-size, valid reserved byte) are correctly classified as `NotADB` by
//! real SQLite — it zero-fills the missing bytes and judges the resulting header.
//! No guard is added here for that case because the required outcome (NotADB)
//! matches the f2p tests, not a carve-out.

use std::path::Path;
use std::sync::Arc;

use turso_core::storage::database::DatabaseFile;
use turso_core::{
    Database, DatabaseOpts, EncryptionOpts, LimboError, OpenFlags, OpenOptions, PageCodec,
    PageCodecContext, PageCodecId, SqliteDialect,
};

/// Open a file through the engine's public, lazy-free file-open entry point
/// with no encryption (plain open). The header is read during this call, so a
/// bad header surfaces here.
fn open_through_public_api(path: &Path) -> turso_core::Result<Arc<Database>> {
    let io: Arc<dyn turso_core::IO + Send> = Arc::new(turso_core::PlatformIO::new().unwrap());
    Database::open_file_with_flags(
        io,
        path.to_str().unwrap(),
        OpenFlags::Create,
        DatabaseOpts::new(),
        None,
        Arc::new(SqliteDialect),
    )
}

/// Open a file through the engine's public file-open entry point with an
/// AES-256-GCM encryption cipher configured. Used to test the encryption
/// carve-out: an encrypted file must not be classified as `LimboError::NotADB`
/// even when it is truncated, because the engine cannot judge encrypted header
/// bytes with the plain-file rule before the key is applied.
fn open_encrypted(path: &Path) -> turso_core::Result<Arc<Database>> {
    let io: Arc<dyn turso_core::IO + Send> = Arc::new(turso_core::PlatformIO::new().unwrap());
    let enc = EncryptionOpts {
        cipher: "aes256gcm".to_string(),
        hexkey: "0".repeat(64),
    };
    Database::open_file_with_flags(
        io,
        path.to_str().unwrap(),
        OpenFlags::Create,
        DatabaseOpts::new(),
        Some(enc),
        Arc::new(SqliteDialect),
    )
}

/// Open a file through the public `OpenOptions` builder with a page codec
/// configured. Routes the header read down the codec branch, which must defer
/// the "not a database" judgement to the codec.
fn open_with_page_codec(path: &Path, codec: Arc<dyn PageCodec>) -> turso_core::Result<Arc<Database>> {
    let io: Arc<dyn turso_core::IO + Send> = Arc::new(turso_core::PlatformIO::new().unwrap());
    let file = io
        .open_file(path.to_str().unwrap(), OpenFlags::Create, false)
        .unwrap();
    let db_file = Arc::new(DatabaseFile::new(file));
    Database::open(
        io,
        path.to_str().unwrap(),
        OpenOptions::new(Arc::new(SqliteDialect))
            .storage(db_file)
            .flags(OpenFlags::Create)
            .page_codec(codec),
    )
}

/// Reference behavior: SQLite must refuse this file as "file is not a database"
/// (SQLITE_NOTADB). SQLite opens lazily, so a query forces the header read.
fn assert_sqlite_rejects_as_not_a_database(path: &Path) {
    let conn = rusqlite::Connection::open(path).unwrap();
    let err = conn
        .query_row("SELECT count(*) FROM sqlite_schema", [], |_| Ok(()))
        .unwrap_err();
    match err {
        rusqlite::Error::SqliteFailure(e, _) => assert_eq!(
            e.code,
            rusqlite::ErrorCode::NotADatabase,
            "sqlite reported {err:?} for {}",
            path.display()
        ),
        other => panic!("expected SQLITE_NOTADB from sqlite, got {other:?}"),
    }
}

/// The engine must agree with SQLite: this file is not a database.
fn assert_engine_reports_not_a_database(path: &Path) {
    match open_through_public_api(path) {
        Err(LimboError::NotADB) => {}
        Err(other) => panic!("expected NotADB for {}, got {other:?}", path.display()),
        Ok(_) => panic!(
            "expected NotADB for {}, got a successful open",
            path.display()
        ),
    }
}

/// A full-length file whose header is garbage (a kilobyte of zero bytes: no
/// SQLite magic, page-size field reads as zero) must come back as "file is not
/// a database", matching SQLite, instead of a corruption/allocation error
/// derived from the bogus page-size field.
#[test]
fn notadb_garbage_full_header() {
    let tmp_dir = tempfile::TempDir::new().unwrap();
    let path = tmp_dir.path().join("garbage.db");
    std::fs::write(&path, vec![0u8; 1050]).unwrap();

    assert_sqlite_rejects_as_not_a_database(&path);
    assert_engine_reports_not_a_database(&path);
}

/// A non-empty file shorter than the header, made of junk bytes with no SQLite
/// magic, must come back as "file is not a database" rather than a bare
/// short-read error. SQLite zero-fills the missing bytes and then rejects the
/// header, so the short junk file is classified the same way any other file is.
#[test]
fn notadb_short_junk() {
    let tmp_dir = tempfile::TempDir::new().unwrap();
    let path = tmp_dir.path().join("short-junk.db");
    std::fs::write(&path, vec![0x42u8; 100]).unwrap();

    assert_sqlite_rejects_as_not_a_database(&path);
    assert_engine_reports_not_a_database(&path);
}

/// A non-empty short file that DOES begin with the SQLite magic string but is
/// otherwise truncated must still come back as "file is not a database": its
/// page-size field is zero, so it fails the page-size rule. Presence of the
/// magic bytes alone does not make it a truncated real database.
#[test]
fn notadb_short_with_magic() {
    let tmp_dir = tempfile::TempDir::new().unwrap();
    let path = tmp_dir.path().join("short-with-magic.db");
    let mut bytes = b"SQLite format 3\0".to_vec();
    bytes.resize(100, 0);
    std::fs::write(&path, bytes).unwrap();

    assert_sqlite_rejects_as_not_a_database(&path);
    assert_engine_reports_not_a_database(&path);
}

/// An identity page codec: encodes/decodes a page to itself and keeps the
/// SQLite header fields visible. It stands in for any external page codec —
/// what matters is that the database is opened *through a codec*, which routes
/// header reading down the codec branch that must defer the "not a database"
/// judgement to the codec.
#[derive(Debug)]
struct IdentityPageCodec;

impl PageCodec for IdentityPageCodec {
    fn codec_id(&self) -> PageCodecId {
        PageCodecId::new(*b"identity-codec--")
    }

    fn required_reserved_bytes(&self) -> u8 {
        0
    }

    fn encode_page(
        &self,
        _context: PageCodecContext,
        input: &[u8],
        output: &mut [u8],
    ) -> turso_core::Result<()> {
        output.copy_from_slice(input);
        Ok(())
    }

    fn decode_page(
        &self,
        _context: PageCodecContext,
        input: &[u8],
        output: &mut [u8],
    ) -> turso_core::Result<()> {
        output.copy_from_slice(input);
        Ok(())
    }
}

/// Page-codec carve-out guard: a page-codec database whose header read comes up
/// short must NOT be reclassified as `LimboError::NotADB`.
///
/// A codec may transform the magic/header bytes, so a short codec read cannot be
/// judged as "not a database" — the short read is surfaced as-is. This is the
/// primary correctness trap the task names: a fix that maps every short read to
/// `NotADB` with no plain-header/codec gate breaks the codec path and fails
/// here.
///
/// This check runs entirely through the public open API inside the injected
/// verifier crate, so it cannot be neutralized by editing an in-tree test body.
/// It asserts the *absence* of `NotADB`, so it is agnostic to the exact
/// short-read/codec error an implementation surfaces.
#[test]
fn codec_short_header_not_classified_as_notadb() {
    let tmp_dir = tempfile::TempDir::new().unwrap();
    let path = tmp_dir.path().join("codec-short-header.db");
    // One byte: far shorter than the 512-byte header, so the header read comes
    // up short on the very first read.
    std::fs::write(&path, [0u8]).unwrap();

    let result = open_with_page_codec(&path, Arc::new(IdentityPageCodec));
    assert!(
        !matches!(result, Err(LimboError::NotADB)),
        "the page-codec short-header carve-out regressed: a short codec read was \
         reclassified as NotADB. A codec may transform the header bytes, so the short \
         read must be surfaced, not flattened to 'not a database'. Got: {result:?}"
    );
}

/// Encryption carve-out guard: a short file opened with an encryption cipher
/// configured must NOT be classified as `LimboError::NotADB`.
///
/// Encrypted database headers may carry a vendor prefix instead of the SQLite
/// magic string; the engine cannot judge them with the plain-file header rule
/// before the key is applied. An over-broad `NotADB` reclassification that does
/// not carve out the encrypted path would make a genuinely truncated encrypted
/// file report a misleading "file is not a database" error instead of the true
/// I/O / decryption error.
///
/// This test is tamper-proof: it calls only the public `open_file_with_flags`
/// API and asserts the *absence* of `NotADB`. An agent cannot pass this test by
/// editing in-tree unit tests or by returning `NotADB` for every short read.
#[test]
fn encrypted_short_file_not_classified_as_notadb() {
    let tmp_dir = tempfile::TempDir::new().unwrap();
    let path = tmp_dir.path().join("encrypted-short.db");
    // Write one byte — clearly shorter than any valid encrypted database header.
    std::fs::write(&path, [0xffu8]).unwrap();

    let result = open_encrypted(&path);
    assert!(
        !matches!(result, Err(LimboError::NotADB)),
        "a short file opened with an encryption cipher must not be classified as \
         LimboError::NotADB; got: {result:?}"
    );
}

