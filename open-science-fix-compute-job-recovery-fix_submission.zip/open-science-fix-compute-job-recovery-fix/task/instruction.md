## Task

after our last release, the remote compute jobs users run against their own SSH
host (Direct SSH) or a Slurm cluster started misbehaving in several ways at once:

- an input file whose name collides with one of the runner's bookkeeping files
  (say an input named like the exit-status or log file) clobbers it, corrupting
  the run: wrong exit status, or outputs never harvested.
- cancelling a job mid-dispatch can leave it stuck: the cancel never takes, and
  after an app restart the recovery pass doesn't notice a Direct SSH job actually
  launched on the remote, so it's retried or abandoned instead of reconciled.
- the per-session and per-provider caps admit too many jobs: one being cancelled
  isn't counted as active, so new jobs slip past.
- some finished jobs get harvested twice (outputs re-downloaded, remote workdir
  cleaned again), and one whose remote workdir is already gone wedges in a
  permanent un-harvested error state instead of being finalized.
- a transient hiccup while listing remote outputs or checking local free space
  permanently fails that harvest instead of retrying, losing recoverable jobs.

this all reproduces in-process, no live SSH or Slurm: you can build the job
lifecycle, repository, dispatcher, cancellation, and harvest pieces directly.
expect root causes spread across several modules and seams. dig in and make
staging, cancellation and recovery, concurrency accounting, and harvest correct
again.
