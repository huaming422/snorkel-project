/*
 * Copyright (c) The acados authors.
 *
 * This file is part of acados.
 *
 * The 2-Clause BSD License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.;
 */

// Behavioral checks for the Hessian-regularization symmetry bug.
//
// The symmetric stage Hessian is stored canonically as its lower triangle (a
// rank update writes only the lower triangle; the strict upper triangle may
// hold stale values). Every path that consumes that Hessian must therefore
// behave as if the upper triangle mirrors the lower one.
//
// These tests exercise the two public regularization/scaling paths that
// consume the stage Hessian WITHOUT first forcing symmetry at their own call
// site, so they observe the bug end-to-end:
//
//   1. Objective scaling (ocp_nlp_qpscaling, OBJECTIVE_GERSHGORIN). The
//      objective-scaling heuristic derives its eigenvalue bound straight from
//      the stored Hessian. A control block whose strict upper triangle holds
//      garbage must produce the scaling factor implied by the symmetric matrix
//      in the lower triangle. This is the path that separates a complete fix
//      from a partial one: it exercises
//      the shared numerical readers on a raw Hessian, so a fix confined to the
//      convexify regularizer (which only makes ITS own copy symmetric) leaves
//      this path reading the stale upper triangle and returning the wrong
//      factor. A complete fix -- in the shared readers, or applied at every
//      consuming call site including this one -- returns the correct factor.
//
//   2. The CONVEXIFY regularizer config. A stage control Hessian that becomes
//      indefinite only after the lower-triangular update must come back finite,
//      symmetric, and positive definite.
//
// The file keys only on OUTPUT VALUES observed through public config / memory
// interfaces (the qpscaling objective factor; the regularized control block).
// It references no symbol the fix introduces and inspects no source, so it
// admits every behaviorally-correct fix (shared-reader fix, scratch-buffer
// symmetrization, per-call-site symmetrization at all consumers) and rejects
// only solutions that leave a consuming path reading the stale upper triangle
// (base, and a convexify-local-only patch).

#include <algorithm>
#include <cmath>
#include <cstdlib>

#include "acados/utils/math.h"
#include "acados/utils/types.h"

#include "acados/ocp_qp/ocp_qp_common.h"
#include "acados/ocp_nlp/ocp_nlp_qpscaling.h"

#include "acados/ocp_nlp/ocp_nlp_reg_common.h"
#include "acados/ocp_nlp/ocp_nlp_reg_convexify.h"

#include "blasfeo_d_aux.h"
#include "blasfeo_d_aux_ext_dep.h"

#include "catch/include/catch.hpp"


namespace
{

// A 2x2 symmetric matrix [[1, -2], [-2, 1]] has eigenvalues -1 and 3. Encoded
// in the LOWER triangle of a control block, with a large inconsistent value in
// the strict upper triangle, its Gershgorin max-abs-eigenvalue estimate from
// the symmetric (lower) form is 1 + 2 = 3. A path that instead consumes the
// full stored matrix sees the garbage upper entry and estimates a much larger
// bound (1 + |garbage|), changing the derived objective scaling factor.
constexpr double kDiag = 1.0;
constexpr double kLowerOffDiag = -2.0;
constexpr double kUpperGarbage = 50.0;  // inconsistent strict-upper-triangle value

// Gershgorin max-abs estimate of the symmetric (lower-triangle) matrix.
constexpr double kSymMaxAbsEig = 3.0;   // 1 + |−2|
// Gershgorin max-abs estimate a full-matrix read would report instead.
constexpr double kStaleMaxAbsEig = 51.0;  // 1 + |50|

}  // namespace


// Primary separating check. Objective scaling reads the stored control Hessian
// through the shared numerical primitives without forcing symmetry first, so
// it observes the stale upper triangle unless the consuming path is fixed. We
// set the eigenvalue cap between the symmetric estimate (3) and the stale
// full-matrix estimate (51). With a correct read, the estimate (3) stays under
// the cap and the objective is left unscaled (factor 1). With a stale read, the
// estimate (51) exceeds the cap and the objective is scaled down (factor < 1,
// specifically cap/51). A convexify-only fix never touches this path, so it
// still reports the stale factor here and fails.
TEST_CASE("objective scaling reads the lower-triangular Hessian", "[reg_symmetry]")
{
    const int N = 0;  // single stage

    // QP dimensions: one stage, a 2x2 control block (nu=2), no states/bounds.
    void *dims_mem = std::malloc(ocp_qp_dims_calculate_size(N));
    ocp_qp_dims *qp_dim = ocp_qp_dims_assign(N, dims_mem);
    int nx = 0, nu = 2, nbx = 0, nbu = 0, ng = 0, ns = 0;
    ocp_qp_dims_set(NULL, qp_dim, 0, "nx", &nx);
    ocp_qp_dims_set(NULL, qp_dim, 0, "nu", &nu);
    ocp_qp_dims_set(NULL, qp_dim, 0, "nbx", &nbx);
    ocp_qp_dims_set(NULL, qp_dim, 0, "nbu", &nbu);
    ocp_qp_dims_set(NULL, qp_dim, 0, "ng", &ng);
    ocp_qp_dims_set(NULL, qp_dim, 0, "ns", &ns);

    void *in_mem = std::calloc(1, ocp_qp_in_calculate_size(qp_dim));
    ocp_qp_in *qp_in = ocp_qp_in_assign(qp_dim, in_mem);
    void *out_mem = std::calloc(1, ocp_qp_out_calculate_size(qp_dim));
    ocp_qp_out *qp_out = ocp_qp_out_assign(qp_dim, out_mem);

    // Control Hessian: symmetric matrix encoded in the lower triangle, garbage
    // in the strict upper triangle. Column-major blasfeo storage.
    blasfeo_dgese(nu + nx, nu + nx, 0.0, &qp_in->RSQrq[0], 0, 0);
    BLASFEO_DMATEL(&qp_in->RSQrq[0], 0, 0) = kDiag;
    BLASFEO_DMATEL(&qp_in->RSQrq[0], 1, 0) = kLowerOffDiag;  // lower, authoritative
    BLASFEO_DMATEL(&qp_in->RSQrq[0], 1, 1) = kDiag;
    BLASFEO_DMATEL(&qp_in->RSQrq[0], 0, 1) = kUpperGarbage;  // strict upper, stale

    // A non-trivial cost gradient so the objective-scaling heuristic is driven
    // purely by the eigenvalue cap, not by its small-gradient floor.
    blasfeo_dvecse(nu + nx, 0.0, &qp_in->rqz[0], 0);
    BLASFEO_DVECEL(&qp_in->rqz[0], 0) = 1.0;

    // qpscaling configured for Gershgorin objective scaling.
    void *qs_dims_mem = std::malloc(ocp_nlp_qpscaling_dims_calculate_size(N));
    ocp_nlp_qpscaling_dims *qs_dims = ocp_nlp_qpscaling_dims_assign(N, qs_dims_mem);

    void *qs_opts_mem = std::malloc(ocp_nlp_qpscaling_opts_calculate_size());
    void *qs_opts = ocp_nlp_qpscaling_opts_assign(qs_opts_mem);
    ocp_nlp_qpscaling_opts_initialize_default(qs_dims, qs_opts);
    qpscaling_scale_objective_type scale_obj = OBJECTIVE_GERSHGORIN;
    ocp_nlp_qpscaling_opts_set(qs_opts, "scale_objective", &scale_obj);
    // Cap strictly between the symmetric (3) and the stale-read (51) estimates.
    double ub_max_abs_eig = 10.0;
    ocp_nlp_qpscaling_opts_set(qs_opts, "ub_max_abs_eig", &ub_max_abs_eig);
    // Small gradient-norm floor so it never raises the factor above what the
    // eigenvalue cap selects for this data.
    double lb_grad = 1e-8;
    ocp_nlp_qpscaling_opts_set(qs_opts, "lb_norm_inf_grad_obj", &lb_grad);

    void *qs_mem_mem = std::malloc(
        ocp_nlp_qpscaling_memory_calculate_size(qs_dims, qs_opts, qp_dim));
    void *qs_mem = ocp_nlp_qpscaling_memory_assign(qs_dims, qs_opts, qp_dim, qs_mem_mem);

    ocp_nlp_qpscaling_precompute(qs_dims, qs_opts, qs_mem, qp_in, qp_out);
    ocp_nlp_qpscaling_scale_qp(qs_dims, qs_opts, qs_mem, qp_in);

    double obj_factor = -1.0;
    ocp_nlp_qpscaling_memory_get(qs_dims, qs_mem, "obj", 0, &obj_factor);

    const double expected_correct = 1.0;                 // estimate 3 < cap 10
    const double expected_stale = ub_max_abs_eig / kStaleMaxAbsEig;  // cap/51

    INFO("obj_factor=" << obj_factor
         << " correct=" << expected_correct << " stale=" << expected_stale);
    // With a lower-triangular read the estimate (3) is below the cap, so the
    // objective is left unscaled.
    CHECK(obj_factor == Approx(expected_correct).margin(1e-9));
    // And it is emphatically not the scaled-down factor a stale full-matrix
    // read would produce.
    CHECK(obj_factor > 0.5);

    std::free(qs_mem_mem);
    std::free(qs_opts_mem);
    std::free(qs_dims_mem);
    std::free(out_mem);
    std::free(in_mem);
    std::free(dims_mem);
}


// Guard (pass-to-pass): a genuinely symmetric, well-conditioned control block
// (consistent upper and lower triangles) whose eigenvalue bound sits under the
// cap must be left unscaled. This rejects any "fix" that distorts correct,
// already-symmetric inputs (e.g. forcing the estimate to a constant or zeroing
// a triangle in a way that changes the bound).
TEST_CASE("objective scaling leaves a symmetric Hessian unscaled", "[reg_symmetry]")
{
    const int N = 0;

    void *dims_mem = std::malloc(ocp_qp_dims_calculate_size(N));
    ocp_qp_dims *qp_dim = ocp_qp_dims_assign(N, dims_mem);
    int nx = 0, nu = 2, nbx = 0, nbu = 0, ng = 0, ns = 0;
    ocp_qp_dims_set(NULL, qp_dim, 0, "nx", &nx);
    ocp_qp_dims_set(NULL, qp_dim, 0, "nu", &nu);
    ocp_qp_dims_set(NULL, qp_dim, 0, "nbx", &nbx);
    ocp_qp_dims_set(NULL, qp_dim, 0, "nbu", &nbu);
    ocp_qp_dims_set(NULL, qp_dim, 0, "ng", &ng);
    ocp_qp_dims_set(NULL, qp_dim, 0, "ns", &ns);

    void *in_mem = std::calloc(1, ocp_qp_in_calculate_size(qp_dim));
    ocp_qp_in *qp_in = ocp_qp_in_assign(qp_dim, in_mem);
    void *out_mem = std::calloc(1, ocp_qp_out_calculate_size(qp_dim));
    ocp_qp_out *qp_out = ocp_qp_out_assign(qp_dim, out_mem);

    // Symmetric positive-definite [[2, 0.5], [0.5, 2]]; Gershgorin max-abs
    // estimate 2 + 0.5 = 2.5, which is under the cap.
    blasfeo_dgese(nu + nx, nu + nx, 0.0, &qp_in->RSQrq[0], 0, 0);
    BLASFEO_DMATEL(&qp_in->RSQrq[0], 0, 0) = 2.0;
    BLASFEO_DMATEL(&qp_in->RSQrq[0], 1, 0) = 0.5;
    BLASFEO_DMATEL(&qp_in->RSQrq[0], 1, 1) = 2.0;
    BLASFEO_DMATEL(&qp_in->RSQrq[0], 0, 1) = 0.5;  // consistent with lower

    blasfeo_dvecse(nu + nx, 0.0, &qp_in->rqz[0], 0);
    BLASFEO_DVECEL(&qp_in->rqz[0], 0) = 1.0;

    void *qs_dims_mem = std::malloc(ocp_nlp_qpscaling_dims_calculate_size(N));
    ocp_nlp_qpscaling_dims *qs_dims = ocp_nlp_qpscaling_dims_assign(N, qs_dims_mem);

    void *qs_opts_mem = std::malloc(ocp_nlp_qpscaling_opts_calculate_size());
    void *qs_opts = ocp_nlp_qpscaling_opts_assign(qs_opts_mem);
    ocp_nlp_qpscaling_opts_initialize_default(qs_dims, qs_opts);
    qpscaling_scale_objective_type scale_obj = OBJECTIVE_GERSHGORIN;
    ocp_nlp_qpscaling_opts_set(qs_opts, "scale_objective", &scale_obj);
    double ub_max_abs_eig = 10.0;
    ocp_nlp_qpscaling_opts_set(qs_opts, "ub_max_abs_eig", &ub_max_abs_eig);
    double lb_grad = 1e-8;
    ocp_nlp_qpscaling_opts_set(qs_opts, "lb_norm_inf_grad_obj", &lb_grad);

    void *qs_mem_mem = std::malloc(
        ocp_nlp_qpscaling_memory_calculate_size(qs_dims, qs_opts, qp_dim));
    void *qs_mem = ocp_nlp_qpscaling_memory_assign(qs_dims, qs_opts, qp_dim, qs_mem_mem);

    ocp_nlp_qpscaling_precompute(qs_dims, qs_opts, qs_mem, qp_in, qp_out);
    ocp_nlp_qpscaling_scale_qp(qs_dims, qs_opts, qs_mem, qp_in);

    double obj_factor = -1.0;
    ocp_nlp_qpscaling_memory_get(qs_dims, qs_mem, "obj", 0, &obj_factor);

    INFO("obj_factor=" << obj_factor);
    CHECK(obj_factor == Approx(1.0).margin(1e-9));

    std::free(qs_mem_mem);
    std::free(qs_opts_mem);
    std::free(qs_dims_mem);
    std::free(out_mem);
    std::free(in_mem);
    std::free(dims_mem);
}


// Second separating check, asserting the exact scaled factor. Here the cap (2)
// sits BELOW the symmetric eigenvalue estimate (3), so a correct lower-
// triangular read scales the objective down by exactly cap / 3. A stale full-
// matrix read instead sees 51 and scales by cap / 51 -- an order of magnitude
// smaller. Asserting the precise factor (not merely "scaled vs unscaled")
// rejects any solution that reads the stale triangle and any "fix" that forces
// the factor to a fixed constant.
TEST_CASE("objective scaling factor matches the symmetric eigenvalue bound", "[reg_symmetry]")
{
    const int N = 0;

    void *dims_mem = std::malloc(ocp_qp_dims_calculate_size(N));
    ocp_qp_dims *qp_dim = ocp_qp_dims_assign(N, dims_mem);
    int nx = 0, nu = 2, nbx = 0, nbu = 0, ng = 0, ns = 0;
    ocp_qp_dims_set(NULL, qp_dim, 0, "nx", &nx);
    ocp_qp_dims_set(NULL, qp_dim, 0, "nu", &nu);
    ocp_qp_dims_set(NULL, qp_dim, 0, "nbx", &nbx);
    ocp_qp_dims_set(NULL, qp_dim, 0, "nbu", &nbu);
    ocp_qp_dims_set(NULL, qp_dim, 0, "ng", &ng);
    ocp_qp_dims_set(NULL, qp_dim, 0, "ns", &ns);

    void *in_mem = std::calloc(1, ocp_qp_in_calculate_size(qp_dim));
    ocp_qp_in *qp_in = ocp_qp_in_assign(qp_dim, in_mem);
    void *out_mem = std::calloc(1, ocp_qp_out_calculate_size(qp_dim));
    ocp_qp_out *qp_out = ocp_qp_out_assign(qp_dim, out_mem);

    blasfeo_dgese(nu + nx, nu + nx, 0.0, &qp_in->RSQrq[0], 0, 0);
    BLASFEO_DMATEL(&qp_in->RSQrq[0], 0, 0) = kDiag;
    BLASFEO_DMATEL(&qp_in->RSQrq[0], 1, 0) = kLowerOffDiag;  // lower, authoritative
    BLASFEO_DMATEL(&qp_in->RSQrq[0], 1, 1) = kDiag;
    BLASFEO_DMATEL(&qp_in->RSQrq[0], 0, 1) = kUpperGarbage;  // strict upper, stale

    blasfeo_dvecse(nu + nx, 0.0, &qp_in->rqz[0], 0);
    BLASFEO_DVECEL(&qp_in->rqz[0], 0) = 1.0;

    void *qs_dims_mem = std::malloc(ocp_nlp_qpscaling_dims_calculate_size(N));
    ocp_nlp_qpscaling_dims *qs_dims = ocp_nlp_qpscaling_dims_assign(N, qs_dims_mem);

    void *qs_opts_mem = std::malloc(ocp_nlp_qpscaling_opts_calculate_size());
    void *qs_opts = ocp_nlp_qpscaling_opts_assign(qs_opts_mem);
    ocp_nlp_qpscaling_opts_initialize_default(qs_dims, qs_opts);
    qpscaling_scale_objective_type scale_obj = OBJECTIVE_GERSHGORIN;
    ocp_nlp_qpscaling_opts_set(qs_opts, "scale_objective", &scale_obj);
    // Cap below the symmetric estimate (3) so a correct read still scales,
    // by a factor determined by the symmetric bound.
    double ub_max_abs_eig = 2.0;
    ocp_nlp_qpscaling_opts_set(qs_opts, "ub_max_abs_eig", &ub_max_abs_eig);
    double lb_grad = 1e-8;
    ocp_nlp_qpscaling_opts_set(qs_opts, "lb_norm_inf_grad_obj", &lb_grad);

    void *qs_mem_mem = std::malloc(
        ocp_nlp_qpscaling_memory_calculate_size(qs_dims, qs_opts, qp_dim));
    void *qs_mem = ocp_nlp_qpscaling_memory_assign(qs_dims, qs_opts, qp_dim, qs_mem_mem);

    ocp_nlp_qpscaling_precompute(qs_dims, qs_opts, qs_mem, qp_in, qp_out);
    ocp_nlp_qpscaling_scale_qp(qs_dims, qs_opts, qs_mem, qp_in);

    double obj_factor = -1.0;
    ocp_nlp_qpscaling_memory_get(qs_dims, qs_mem, "obj", 0, &obj_factor);

    const double expected_correct = ub_max_abs_eig / kSymMaxAbsEig;   // 2/3
    const double expected_stale = ub_max_abs_eig / kStaleMaxAbsEig;   // 2/51

    INFO("obj_factor=" << obj_factor
         << " correct=" << expected_correct << " stale=" << expected_stale);
    CHECK(obj_factor == Approx(expected_correct).margin(1e-9));

    std::free(qs_mem_mem);
    std::free(qs_opts_mem);
    std::free(qs_dims_mem);
    std::free(out_mem);
    std::free(in_mem);
    std::free(dims_mem);
}


// End-to-end coverage through the public CONVEXIFY regularizer config
// interface. Mirrors the upstream regression: a stage control Hessian that
// becomes indefinite only after the lower-triangular update must come back
// finite, symmetric, and positive definite. Convexify consumes the shared
// eigen reader, so this exercises the fix through a real regularizer. It is a
// secondary check (a convexify-local-only patch also passes it); the
// objective-scaling test above is the primary separating check.
namespace
{

class ConvexifyFixture
{
 public:
    ConvexifyFixture()
    {
        config_memory_ = std::malloc(ocp_nlp_reg_config_calculate_size());
        config_ = static_cast<ocp_nlp_reg_config *>(ocp_nlp_reg_config_assign(config_memory_));
        ocp_nlp_reg_convexify_config_initialize_default(config_);

        constexpr int N = 1;
        dims_memory_ = std::malloc(config_->dims_calculate_size(N));
        dims_ = config_->dims_assign(N, dims_memory_);
        dims_->nx[0] = 1;
        dims_->nx[1] = 1;
        dims_->nu[0] = 2;
        dims_->nu[1] = 0;

        opts_memory_ = std::malloc(config_->opts_calculate_size());
        opts_ = config_->opts_assign(opts_memory_);
        config_->opts_initialize_default(config_, dims_, opts_);

        memory_memory_ = std::malloc(config_->memory_calculate_size(config_, dims_, opts_));
        memory_ = config_->memory_assign(config_, dims_, opts_, memory_memory_);

        blasfeo_allocate_dmat(4, 3, &RSQrq_[0]);
        blasfeo_allocate_dmat(2, 1, &RSQrq_[1]);
        blasfeo_allocate_dmat(4, 1, &BAbt_[0]);
        blasfeo_allocate_dvec(3, &rq_[0]);
        blasfeo_allocate_dvec(1, &rq_[1]);
        blasfeo_allocate_dvec(1, &b_[0]);

        blasfeo_dgese(4, 3, 0.0, &RSQrq_[0], 0, 0);
        blasfeo_dgese(2, 1, 0.0, &RSQrq_[1], 0, 0);
        blasfeo_dgese(4, 1, 0.0, &BAbt_[0], 0, 0);
        blasfeo_dvecse(3, 0.0, &rq_[0], 0);
        blasfeo_dvecse(1, 0.0, &rq_[1], 0);
        blasfeo_dvecse(1, 0.0, &b_[0], 0);

        // Construct a control Hessian that becomes indefinite after the
        // lower-triangular update. Convexify should detect and regularize it.
        const double delta = static_cast<ocp_nlp_reg_convexify_opts *>(opts_)->delta;
        BLASFEO_DMATEL(&RSQrq_[0], 0, 0) = 1.0;
        BLASFEO_DMATEL(&RSQrq_[0], 1, 1) = 1.0;
        BLASFEO_DMATEL(&RSQrq_[0], 2, 2) = 1.0;
        BLASFEO_DMATEL(&RSQrq_[1], 0, 0) = delta - 0.75;
        BLASFEO_DMATEL(&BAbt_[0], 0, 0) = 1.0;
        BLASFEO_DMATEL(&BAbt_[0], 1, 0) = 1.0;

        config_->memory_set_RSQrq_ptr(dims_, RSQrq_, memory_);
        config_->memory_set_rq_ptr(dims_, rq_, memory_);
        config_->memory_set_BAbt_ptr(dims_, BAbt_, memory_);
        config_->memory_set_b_ptr(dims_, b_, memory_);
    }

    ~ConvexifyFixture()
    {
        blasfeo_free_dvec(&b_[0]);
        blasfeo_free_dvec(&rq_[1]);
        blasfeo_free_dvec(&rq_[0]);
        blasfeo_free_dmat(&BAbt_[0]);
        blasfeo_free_dmat(&RSQrq_[1]);
        blasfeo_free_dmat(&RSQrq_[0]);
        std::free(memory_memory_);
        std::free(opts_memory_);
        std::free(dims_memory_);
        std::free(config_memory_);
    }

    void regularize() { config_->regularize(config_, dims_, opts_, memory_); }

    void regularize_lhs() { config_->regularize_lhs(config_, dims_, opts_, memory_); }

    void regularize_rhs() { config_->regularize_rhs(config_, dims_, opts_, memory_); }

    void check_control_hessian(const char *phase) const
    {
        const double r00 = BLASFEO_DMATEL(&RSQrq_[0], 0, 0);
        const double r10 = BLASFEO_DMATEL(&RSQrq_[0], 1, 0);
        const double r11 = BLASFEO_DMATEL(&RSQrq_[0], 1, 1);
        const double r01 = r10;  // only the lower triangle is stored

        INFO(phase);
        CHECK(std::isfinite(r00));
        CHECK(std::isfinite(r01));
        CHECK(std::isfinite(r10));
        CHECK(std::isfinite(r11));
        CHECK(r01 == Approx(r10).margin(1e-12));
        CHECK(r00 > 0.0);
        CHECK(r11 > 0.0);
        CHECK(r00 * r11 - r10 * r10 > 0.0);
    }

 private:
    void *config_memory_;
    void *dims_memory_;
    void *opts_memory_;
    void *memory_memory_;
    ocp_nlp_reg_config *config_;
    ocp_nlp_reg_dims *dims_;
    void *opts_;
    void *memory_;
    struct blasfeo_dmat RSQrq_[2];
    struct blasfeo_dmat BAbt_[1];
    struct blasfeo_dvec rq_[2];
    struct blasfeo_dvec b_[1];
};

}  // namespace


TEST_CASE("convexify regularizes a lower-indefinite control Hessian", "[reg_symmetry]")
{
    ConvexifyFixture fixture;

    SECTION("full regularization")
    {
        fixture.regularize();
        fixture.check_control_hessian("after regularize");
    }

    SECTION("split regularization")
    {
        fixture.regularize_lhs();
        fixture.check_control_hessian("after regularize_lhs");
        fixture.regularize_rhs();
        fixture.check_control_hessian("after regularize_rhs");
    }
}
