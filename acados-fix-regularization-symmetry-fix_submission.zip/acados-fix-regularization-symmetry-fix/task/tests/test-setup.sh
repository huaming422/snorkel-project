#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier runs (set -euo pipefail inherited).
# acados is a C/C++ CMake project; all dependencies (submodules incl. BLASFEO,
# Eigen at /opt/eigen, the bundled QP solvers) are baked into the image at the
# base commit and the build tree is warmed. There are no package-manager
# installs, no services to start, and no data to seed — the verifier's Catch2
# tests exercise pure numerical helpers. Nothing to do here but confirm the
# tree is where the verifier expects it.
cd /repo/acados
: # offline-first: dependency closure is already in the image (§1.5); no network needed.
