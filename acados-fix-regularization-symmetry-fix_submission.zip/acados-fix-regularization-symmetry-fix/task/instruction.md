## Task

we're seeing CONVEXIFY regularization misbehave in our SQP-RTI controller. on some problem data it hands back a control Hessian that's still asymmetric and indefinite, which is wrong, so the QP subproblem comes out ill-posed and the solve fails to converge: it either diverges or stalls. it's very data-dependent: most problems regularize fine, and the exact same data regularizes correctly in a reference setup, so the inputs themselves aren't the problem. my hunch is the other regularization modes are broken the same way, not just convexify. can you dig in and fix the root cause?
