#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
# This is a Rust task: the dependency closure is baked into the image at the
# base commit (block 7 ran `cargo fetch --locked && cargo build --locked
# --tests`). The grade phase must stay offline, so pin cargo to offline mode
# right after cd; a cache miss then fails fast instead of reaching crates.io.
cd /repo/typst

export CARGO_NET_OFFLINE=true

# No dependency install step (no new crates are introduced by any valid fix),
# no services to start, and no data to seed. The verifier drives the repo's own
# cargo build/test against the warm target cache.
echo "[test-setup] rust offline mode enabled; no services required"
