// @ts-nocheck
//
// Behavioural verifier for emdash-perf-taxonomy-small-terms.
//
// Drives the pre-existing, stable public loader entry point
// `emdashLoader().loadCollection({ filter })` against an in-memory SQLite DB
// built from the repo's own migrations (no ANALYZE — matching Cloudflare D1,
// which never maintains `sqlite_stat1`). The access path the stats-blind
// planner chooses is observed two ways, both through the loader:
//
//   * the emitted join operator captured from Kysely's query log
//     (`CROSS JOIN` pins the pivot as the outer table → a seek; plain `JOIN`
//     lets the planner drive from the content order index → a walk), and
//   * `EXPLAIN QUERY PLAN` run on the emitted SQL of the `picked` CTE.
//
// No solution-invented identifier is referenced for assertions (never a
// content-drive option, a sort-class helper, a size-probe param, or a
// large-term threshold constant). The checks are on the emitted SQL and the
// resulting plan shape alone, so any size-aware steering that produces the
// right access path for each term/sort/filter shape passes, regardless of
// internal names, helper factoring, threshold value, or how term size is
// measured. The large term is seeded with a locally-owned, safely-large count
// (see LARGE_TERM_SEED) rather than importing the implementation's threshold.
//
// Mirrors the repo's own `loader-taxonomy-pivot-plan.test.ts` harness, and
// adds an output-invariance block that compares the entries loadCollection()
// returns (ids + order) across shapes — the fix changes only the plan, never
// the results.

import { Kysely, SqliteDialect, sql } from "kysely";
import { afterEach, beforeEach, describe, expect, it } from "vitest";

import { NodeSqliteCompatDatabase as Database } from "#node-sqlite";

import { runMigrations } from "../../src/database/migrations/runner.js";
import { ContentRepository } from "../../src/database/repositories/content.js";
import { TaxonomyRepository } from "../../src/database/repositories/taxonomy.js";
import type { Database as DatabaseSchema } from "../../src/database/types.js";
import { emdashLoader, resetTaxonomyNamesCache } from "../../src/loader.js";
import { runWithContext } from "../../src/request-context.js";
import { SchemaRegistry } from "../../src/schema/registry.js";

// A count comfortably above any plausible large-term threshold the solution
// might choose (reference uses 200; alternatives may use 300/500). Seeded well
// clear of 500 so a term classifies as "large" under any of those thresholds.
// Owned by the verifier so no implementation symbol is imported for the
// assertion contract.
const LARGE_TERM_SEED = 800;

interface CapturedQuery {
	sql: string;
	parameters: readonly unknown[];
}

let sqlite: Database;
let db: Kysely<DatabaseSchema>;
let captured: CapturedQuery[];

beforeEach(async () => {
	captured = [];
	sqlite = new Database(":memory:");
	db = new Kysely<DatabaseSchema>({
		dialect: new SqliteDialect({ database: sqlite }),
		log(event) {
			if (event.level === "query") {
				captured.push({ sql: event.query.sql, parameters: event.query.parameters });
			}
		},
	});

	// Deliberately no ANALYZE: matches D1, which never maintains sqlite_stat1, so
	// the planner chooses access paths purely from the schema.
	await runMigrations(db);
	await db
		.updateTable("_emdash_taxonomy_def_groups")
		.set({ collections: JSON.stringify(["post"]) })
		.where("name", "in", ["category", "tag"])
		.execute();
	resetTaxonomyNamesCache();
	const registry = new SchemaRegistry(db);
	await registry.createCollection({ slug: "post", label: "Posts", labelSingular: "Post" });
	await registry.createField("post", { slug: "title", label: "Title", type: "string" });

	const anyDb = db as any;
	const content = new ContentRepository(anyDb);
	const tax = new TaxonomyRepository(anyDb);
	const term = await tax.create({ name: "category", slug: "news", label: "News", locale: "en" });
	// A small term: one tagged entry among many.
	for (let i = 0; i < 30; i++) {
		const post = await content.create({
			type: "post",
			slug: `post-${i}`,
			data: { title: `Post ${i}` },
			status: "published",
			locale: "en",
		});
		if (i === 0) await tax.attachToEntry("post", post.id, term.id);
	}
});

afterEach(async () => {
	await db.destroy();
});

/** Normalize application values captured from Kysely for direct driver binding. */
function bindable(p: unknown): unknown {
	if (typeof p === "boolean") return p ? 1 : 0;
	if (p instanceof Date) return p.toISOString();
	if (p === undefined) return null;
	return p;
}

function explain(query: CapturedQuery): string {
	const rows = sqlite
		.prepare(`EXPLAIN QUERY PLAN ${query.sql}`)
		.all(...query.parameters.map(bindable)) as { detail: string }[];
	return rows.map((r) => r.detail).join("\n");
}

/** The pivot-driven query is the one with the `picked` CTE. */
function pivotQueryPlan(): string {
	const query = captured.find((q) => q.sql.includes("picked"));
	expect(query, "expected the loader to emit a pivot-driven query").toBeDefined();
	return explain(query!);
}

/** The term lookup is the query that resolves the filter's slugs to translation groups. */
function termLookupPlan(): string {
	const query = captured.find((q) => q.sql.startsWith('select distinct "translation_group"'));
	expect(query, "expected the loader to emit a term lookup").toBeDefined();
	return explain(query!);
}

/**
 * Returns just the `picked` CTE plan (between `CO-ROUTINE picked` and `SCAN picked`),
 * or the whole plan when SQLite flattened the CTE into the outer query.
 */
function pickedCtePlan(plan: string): string {
	const start = plan.indexOf("CO-ROUTINE picked\n");
	if (start === -1) return plan;
	const end = plan.indexOf("\nSCAN picked", start);
	if (end === -1) return plan.slice(start);
	return plan.slice(start, end);
}

/** `picked` seeks the term's assignments on the pivot and sorts their content rows. */
function expectPivotSeek(plan: string): void {
	const picked = pickedCtePlan(plan);
	expect(picked).toContain("SEARCH ct USING COVERING INDEX idx_content_taxonomies_group_lookup");
	expect(picked).not.toMatch(/SEARCH r USING INDEX idx_ec_post_deleted_(published|created)_id/);
	expect(plan).not.toContain("SCAN r");
}

/** `picked` walks the content order index and stops at `LIMIT`, with no sort. */
function expectContentWalk(plan: string, orderIndex: string): void {
	const picked = pickedCtePlan(plan);
	expect(picked).toContain(`SEARCH r USING INDEX ${orderIndex} (deleted_at=?)`);
	expect(picked).not.toContain("USE TEMP B-TREE FOR ORDER BY");
	expect(plan).not.toContain("SCAN ct");
}

async function runLoad(
	where: Record<string, unknown>,
	extra: Record<string, unknown> = {},
): Promise<void> {
	captured = [];
	const loader = emdashLoader();
	await runWithContext({ editMode: false, db }, () =>
		loader.loadCollection!({
			filter: { type: "post", where: where as never, limit: 5, ...extra },
		}),
	);
}

/** Load through the public path and return the entry ids in result order. */
async function loadEntryIds(
	where: Record<string, unknown>,
	extra: Record<string, unknown> = {},
): Promise<string[]> {
	const loader = emdashLoader();
	const result = await runWithContext({ editMode: false, db }, () =>
		loader.loadCollection!({
			filter: { type: "post", where: where as never, limit: 5, ...extra },
		}),
	);
	return (result?.entries ?? []).map((e: { id: string }) => e.id);
}

// --- small term: seeks the pivot (fail_to_pass) -----------------------------
// The regressed build walks the `ec_*` order index for a small term under an
// indexed sort; the fix seeks the group-keyed pivot.

it("seeks a small term on the pivot for a published_at sort", async () => {
	await runLoad({ category: "news" }, { orderBy: { published_at: "desc" } });
	expectPivotSeek(pivotQueryPlan());
});

it("seeks a small term on the pivot for the default created_at sort", async () => {
	await runLoad({ category: "news" });
	expectPivotSeek(pivotQueryPlan());
});

it("seeks a small term and the requested content locale", async () => {
	await runLoad({ category: "news" }, { orderBy: { published_at: "desc" }, locale: "en" });
	const plan = pivotQueryPlan();
	expectPivotSeek(plan);
	expect(pickedCtePlan(plan)).toContain("idx_ec_post_del_tg_locale");
});

it("seeks a small term on the pivot for an updated_at sort", async () => {
	await runLoad({ category: "news" }, { orderBy: { updated_at: "desc" } });
	expectPivotSeek(pivotQueryPlan());
});

it("does not issue a separate size-probe round trip for a small term", async () => {
	await runLoad({ category: "news" }, { orderBy: { published_at: "desc" } });
	// Only the listing query (with `picked` CTE) should touch content_taxonomies
	// as a standalone round trip. A separate size-probe query would be an extra.
	const termLookups = captured.filter((q) => q.sql.startsWith('select distinct "translation_group"'));
	const listings = captured.filter((q) => q.sql.includes("picked"));
	expect(termLookups).toHaveLength(1);
	expect(listings).toHaveLength(1);
	const sizeProbes = captured.filter(
		(q) =>
			q !== termLookups[0] &&
			q !== listings[0] &&
			q.sql.includes("content_taxonomies"),
	);
	expect(sizeProbes, "separate size-probe round trip on content_taxonomies").toHaveLength(0);
});

// --- collection-scoped size (fail_to_pass) ----------------------------------
// A term that is large only in another collection must still seek for a listing
// in the collection where it is small.

it("seeks a term that is large only in another collection", async () => {
	const news = await db
		.selectFrom("taxonomies")
		.select("translation_group")
		.where("slug", "=", "news")
		.executeTakeFirstOrThrow();
	await sql`
		WITH RECURSIVE seq(i) AS (
			SELECT 1 UNION ALL SELECT i + 1 FROM seq WHERE i < ${LARGE_TERM_SEED}
		)
		INSERT INTO content_taxonomies (collection, entry_id, taxonomy_id)
		SELECT 'page', printf('page%04d', i), ${news.translation_group} FROM seq
	`.execute(db);
	await runLoad({ category: "news" }, { orderBy: { published_at: "desc" } });
	expectPivotSeek(pivotQueryPlan());
});

// --- a large term: walks (pass_to_pass) + gating (fail_to_pass) --------------

describe("a large term", () => {
	beforeEach(async () => {
		const tax = new TaxonomyRepository(db as any);
		const big = await tax.create({ name: "category", slug: "big", label: "Big", locale: "en" });
		const bigGroup = big.translationGroup ?? big.id;
		await sql`
			WITH RECURSIVE seq(i) AS (
				SELECT 1 UNION ALL SELECT i + 1 FROM seq WHERE i < ${LARGE_TERM_SEED}
			)
			INSERT INTO ec_post (id, slug, status, locale, translation_group, created_at, updated_at, published_at, title)
			SELECT printf('big%04d', i), printf('big-%04d', i), 'published', 'en', printf('big%04d', i),
				datetime('2024-01-01', printf('+%d minutes', i)),
				datetime('2024-01-01', printf('+%d minutes', i)),
				datetime('2024-01-01', printf('+%d minutes', i)),
				printf('Big %d', i)
			FROM seq
		`.execute(db);
		await sql`
			INSERT INTO content_taxonomies (collection, entry_id, taxonomy_id)
			SELECT 'post', translation_group, ${bigGroup} FROM ec_post WHERE id LIKE 'big%'
		`.execute(db);
		const featured = await tax.create({
			name: "tag",
			slug: "featured",
			label: "Featured",
			locale: "en",
		});
		await tax.attachToEntry("post", "big0001", featured.id);
	});

	it("walks the published_at index", async () => {
		await runLoad({ category: "big" }, { orderBy: { published_at: "desc" } });
		expectContentWalk(pivotQueryPlan(), "idx_ec_post_deleted_published_id");
	});

	it("walks the created_at index for the default sort", async () => {
		await runLoad({ category: "big" });
		expectContentWalk(pivotQueryPlan(), "idx_ec_post_deleted_created_id");
	});

	it("reads no pivot rows in the term lookup for a second slug", async () => {
		await runLoad({ category: ["big", "news"] });
		expect(termLookupPlan()).not.toContain("content_taxonomies");
	});

	it("is sought on the pivot when one slug names terms in two locales", async () => {
		const tax = new TaxonomyRepository(db as any);
		const other = await tax.create({ name: "category", slug: "big", label: "Groß", locale: "de" });
		await tax.attachToEntry("post", "big0002", other.id);
		await runLoad({ category: "big" });
		expectPivotSeek(pivotQueryPlan());
	});

	it.each([
		["an updated_at sort", { category: "big" }, { orderBy: { updated_at: "desc" } }],
		["a second slug", { category: ["big", "news"] }, {}],
		["a second taxonomy", { tag: "featured", category: "big" }, {}],
		["no limit", { category: "big" }, { limit: undefined }],
	])("is sought on the pivot with %s", async (_shape, where, extra) => {
		await runLoad(where, extra);
		expectPivotSeek(pivotQueryPlan());
	});

	// Supplementary: the plan-level assertions (expectPivotSeek / expectContentWalk)
	// are the authoritative behavioral checks. This test pins the SQL join keyword
	// as a secondary signal, since EXPLAIN QUERY PLAN can differ between D1 and
	// local SQLite for a plain JOIN.
	it("keeps the pivot as the outer table for a temp sort, and frees it for an indexed sort", async () => {
		const pickedJoin = () => {
			const query = captured.find((q) => q.sql.includes("picked"));
			expect(query, "expected the loader to emit a pivot-driven query").toBeDefined();
			return /content_taxonomies ct\s+(CROSS JOIN|JOIN) "ec_post" AS r/.exec(query!.sql)?.[1];
		};

		await runLoad({ category: "big" }, { orderBy: { updated_at: "desc" } });
		expect(pickedJoin()).toBe("CROSS JOIN");

		await runLoad({ category: "big" }, { orderBy: { title: "asc" } });
		expect(pickedJoin()).toBe("CROSS JOIN");

		await runLoad({ category: "big" }, { orderBy: { published_at: "desc" } });
		expect(pickedJoin()).toBe("JOIN");
	});
});

// --- output invariance (pass_to_pass) ---------------------------------------
// The fix changes only the query plan; the entries returned (and their order)
// must be identical for every term/sort/filter shape. Asserted through the
// public loadCollection() result, independent of the access path chosen.

describe("output is unchanged", () => {
	beforeEach(async () => {
		const content = new ContentRepository(db as any);
		const tax = new TaxonomyRepository(db as any);
		const topic = await tax.create({
			name: "category",
			slug: "topic",
			label: "Topic",
			locale: "en",
		});
		// Three tagged posts with explicit, distinct publish dates so order is
		// fully determined regardless of which access path produces the page.
		const dates = [
			["topic-a", "2024-03-01T00:00:00.000Z"],
			["topic-b", "2024-02-01T00:00:00.000Z"],
			["topic-c", "2024-01-01T00:00:00.000Z"],
		];
		for (const [slug, publishedAt] of dates) {
			const post = await content.create({
				type: "post",
				slug,
				data: { title: slug },
				status: "published",
				locale: "en",
				publishedAt,
			});
			await tax.attachToEntry("post", post.id, topic.id);
		}
	});

	it("returns the single tagged entry for a small term", async () => {
		expect(await loadEntryIds({ category: "news" })).toEqual(["post-0"]);
	});

	it("returns tagged entries newest-first for a published_at sort", async () => {
		expect(
			await loadEntryIds({ category: "topic" }, { orderBy: { published_at: "desc" } }),
		).toEqual(["topic-a", "topic-b", "topic-c"]);
	});

	it("returns the same order whether or not a limit is set", async () => {
		const limited = await loadEntryIds(
			{ category: "topic" },
			{ orderBy: { published_at: "desc" } },
		);
		const unlimited = await loadEntryIds(
			{ category: "topic" },
			{ orderBy: { published_at: "desc" }, limit: undefined },
		);
		expect(unlimited).toEqual(limited);
	});

	it("returns the same entry set for the default created_at sort", async () => {
		const ids = await loadEntryIds({ category: "topic" });
		expect([...ids].sort()).toEqual(["topic-a", "topic-b", "topic-c"]);
	});
});
