#!/usr/bin/env bash
# Verifier setup for emdash-perf-taxonomy-small-terms.
#
# The behavioral verifier runs the repo's own vitest suite (the taxonomy
# pivot-plan harness builds an in-memory SQLite DB through the repo migrations,
# drives emdashLoader().loadCollection(), and runs EXPLAIN QUERY PLAN). It needs
# only the repo's own dependencies, which the image baked at the base commit
# (`pnpm install --frozen-lockfile`, store warmed under /opt/cache/pnpm-dev).
#
# Offline-first: the agent phase is no-network, so the closure is already in the
# image. This runs in the verifier phase (network up) and must still succeed
# offline — a successful offline `pnpm install` is the expected path; the online
# retry is a logged fallback only.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/emdash}"
cd "$REPO_DIR"

node --version
pnpm --version

# Fail a cache miss fast instead of hanging on the network during the offline
# fold; the store was warmed at build time.
export npm_config_prefer_offline=true

if pnpm install --frozen-lockfile --offline > /tmp/verifier-pnpm.log 2>&1; then
    echo "[offline-first] pnpm install satisfied from image store"
else
    echo "[offline-first] offline install incomplete; retrying online" >&2
    tail -40 /tmp/verifier-pnpm.log >&2 || true
    pnpm install --frozen-lockfile > /tmp/verifier-pnpm.log 2>&1 \
        || { tail -80 /tmp/verifier-pnpm.log >&2; exit 1; }
fi

# The plan-test harness imports `emdashLoader().loadCollection()` from
# packages/core, which pulls in `@emdash-cms/admin/slugify`. That subpath export
# resolves to `packages/admin/dist/slugify.js`, so the admin package must be
# built before vitest can load the loader; without it vitest fails the suite
# with "Cannot find package '@emdash-cms/admin/slugify'". tsdown builds it
# offline from the warmed store in ~10s. Idempotent: skip if dist already built.
if [ ! -f packages/admin/dist/slugify.js ]; then
    echo "[test-setup] building @emdash-cms/admin (harness prerequisite)"
    pnpm --filter @emdash-cms/admin build > /tmp/verifier-admin-build.log 2>&1 \
        || { echo "[test-setup] admin build failed" >&2; tail -80 /tmp/verifier-admin-build.log >&2; exit 1; }
fi

echo "[test-setup] ready: $REPO_DIR (packages/core vitest, @emdash-cms/admin built)"
