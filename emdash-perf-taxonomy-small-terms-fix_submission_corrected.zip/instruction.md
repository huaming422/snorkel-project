## Task

we're getting reports that category and tag listing pages have gotten really slow. a listing filtered to a term that only has a few posts (a category or tag with just a handful of entries), sorted by publish date or created date, now takes ages and reads a huge amount from the database, where it used to come back instantly. listings on terms with lots of posts are still fine; it's specifically the small ones that fell off a cliff, and they hammer the database the whole time they're serving.

the same thing shows up against both the local database and the production one.

the posts that come back are correct: same entries, same order as before. it's purely the speed and the database load that regressed.

dig into what's making the small-term listings so expensive and get them fast again. whatever the fix is, it must not make the large-term listings slower than they are today.
