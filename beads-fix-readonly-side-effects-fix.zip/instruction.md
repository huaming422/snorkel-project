## Task

`--readonly` is supposed to make bd safe for sandboxes and audits that only look at a project, but a read-only run still changes things on disk. Both `bd list --readonly` and `bd config validate --readonly` can leave files under `.beads` different from how they found them. On a project set up to use a dolt server, a read-only `config validate` deleted stale leftover files that bd keeps in a shared scratch directory under `/tmp`, which an audit should only have looked at.

When `--readonly` is set, bd shouldn't create, change or delete anything, whether it's under `.beads` or in that shared state. If a command can't do its job without writing, it's fine for it to fail.

Without `--readonly`, `bd list`, `bd show` and the other read commands should keep working exactly as they do now, including how they set up and look after the local database.
