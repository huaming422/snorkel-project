//go:build cgo

package main

// These checks drive the compiled bd binary as a black box through its public
// surface only: the persistent --readonly flag, the read command `list`, and
// `config validate`. They never set an internal store-config field and never
// read program source. The shared subprocess helpers (buildEmbeddedBD, bdInit,
// bdCreate, bdEnv, bdCommand) and the package TestMain come from the package's
// existing //go:build cgo test files, which the runner compiles alongside this
// file.
//
// Each --readonly check sets up a project, plants state that the normal
// command lifecycle would change or remove, runs a command under --readonly,
// and asserts the state is exactly as it was. Exit status is only asserted
// where the command has everything it needs to succeed; a --readonly run that
// refuses is fine everywhere else. Each ordinary-read check runs the same
// setup without --readonly and asserts the normal upkeep still happens.
//
// The state these checks plant:
//   - the gitignored version-bookkeeping marker under .beads, seeded with an
//     old value so the normal lifecycle has a rewrite to do;
//   - the auto-export and auto-backup output under .beads, with both turned
//     on;
//   - an aged leftover in the shared circuit-breaker scratch directory under
//     /tmp, which the managed-server open path sweeps before it dials;
//   - an aged temporary fetch file in the local database's git remote cache,
//     which the database's normal upkeep removes;
//   - a project whose database has not been created in the local data
//     directory yet;
//   - a server-configured project with auto-start allowed, where trying to
//     start the server (there is no dolt binary in the image) takes a lock
//     under .beads.
//
// Server-configured checks that run a plain read are not parallel: a plain
// read sweeps every stale entry in the shared scratch directory, which would
// race the --readonly check that plants one there.

import (
	"bytes"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"io/fs"
	"os"
	"os/exec"
	"path/filepath"
	"reflect"
	"testing"
	"time"
)

// embeddedDataDirName is the subdirectory of .beads that holds the local
// embedded database. Its contents are the database engine's own files, which
// the engine may touch on any open, so tree snapshots skip it. Checks that
// care about it look at it directly.
const embeddedDataDirName = "embeddeddolt"

// versionMarkerName is the gitignored file under .beads that records the bd
// build that last ran in this project.
const versionMarkerName = ".local_version"

// staleMarker is a build value that differs from any real build, so the
// normal lifecycle has a concrete rewrite to perform.
const staleMarker = "0.0.1"

// requireEmbeddedEnabled skips when the offline embedded backend is not enabled
// for this run. The image sets it; a bare `go test` without it would skip.
func requireEmbeddedEnabled(t *testing.T) {
	t.Helper()
	if os.Getenv("BEADS_TEST_EMBEDDED_DOLT") != "1" {
		t.Skip("set BEADS_TEST_EMBEDDED_DOLT=1 to run the embedded read-only checks")
	}
}

// runBDRaw runs the bd binary in dir with the given args and returns stdout+stderr
// combined and the process error (nil on exit 0). Unlike bdCommand it never
// fatals, so callers can assert on both success and refusal.
func runBDRaw(t *testing.T, bd, dir string, args ...string) (string, error) {
	t.Helper()
	cmd := exec.Command(bd, args...)
	cmd.Dir = dir
	cmd.Env = bdEnv(dir)
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	err := cmd.Run()
	return stdout.String() + stderr.String(), err
}

// treeEntry captures mode plus a content fingerprint for one path.
type treeEntry struct {
	Mode   fs.FileMode
	SHA256 string
}

// snapshotTree walks root and fingerprints every entry (mode for all, content
// hash for regular files, link target hash for symlinks), skipping the local
// database's own subtree. Two snapshots compare equal only when everything
// under root outside the database engine's files is byte-for-byte identical.
func snapshotTree(t *testing.T, root string) map[string]treeEntry {
	t.Helper()
	out := make(map[string]treeEntry)
	if _, err := os.Lstat(root); os.IsNotExist(err) {
		return out
	} else if err != nil {
		t.Fatalf("stat snapshot root %s: %v", root, err)
	}
	err := filepath.WalkDir(root, func(path string, entryInfo fs.DirEntry, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		rel, err := filepath.Rel(root, path)
		if err != nil {
			return err
		}
		if entryInfo.IsDir() && rel == embeddedDataDirName {
			return filepath.SkipDir
		}
		info, err := os.Lstat(path)
		if err != nil {
			return err
		}
		entry := treeEntry{Mode: info.Mode()}
		switch {
		case info.Mode().IsRegular():
			data, err := os.ReadFile(path)
			if err != nil {
				return err
			}
			entry.SHA256 = fmt.Sprintf("%x", sha256.Sum256(data))
		case info.Mode()&os.ModeSymlink != 0:
			target, err := os.Readlink(path)
			if err != nil {
				return err
			}
			entry.SHA256 = fmt.Sprintf("%x", sha256.Sum256([]byte(target)))
		}
		out[rel] = entry
		return nil
	})
	if err != nil {
		t.Fatalf("snapshot %s: %v", root, err)
	}
	return out
}

// seedStaleMarker plants an older build value in the version-bookkeeping file so
// the normal lifecycle has a concrete rewrite to perform. init writes the
// current value, so without this the lifecycle has nothing to do.
func seedStaleMarker(t *testing.T, beadsDir string) string {
	t.Helper()
	markerPath := filepath.Join(beadsDir, versionMarkerName)
	if err := os.WriteFile(markerPath, []byte(staleMarker+"\n"), 0o600); err != nil {
		t.Fatalf("seed version marker: %v", err)
	}
	return markerPath
}

// readMarker returns the trimmed contents of the version-bookkeeping file.
func readMarker(t *testing.T, path string) string {
	t.Helper()
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read version marker: %v", err)
	}
	return string(bytes.TrimSpace(data))
}

// TestStrictReadOnlyLeavesManagedStateUntouched runs `list --readonly` on a
// seeded project whose version marker holds an old build value, and expects
// the read to succeed and every file under .beads (outside the database
// engine's own files) to be byte-for-byte unchanged, marker included.
func TestStrictReadOnlyLeavesManagedStateUntouched(t *testing.T) {
	requireEmbeddedEnabled(t)
	t.Parallel()

	bd := buildEmbeddedBD(t)
	dir, beadsDir, _ := bdInit(t, bd, "--prefix", "hm")
	bdCreate(t, bd, dir, "Seed issue")

	markerPath := seedStaleMarker(t, beadsDir)
	before := snapshotTree(t, beadsDir)

	out, err := runBDRaw(t, bd, dir, "list", "--readonly")
	if err != nil {
		t.Fatalf("read-only list of a seeded project should succeed, got error: %v\noutput:\n%s", err, out)
	}

	after := snapshotTree(t, beadsDir)
	if !reflect.DeepEqual(after, before) {
		t.Fatalf("read-only list changed files under .beads\nbefore: %#v\nafter:  %#v\noutput: %s", before, after, out)
	}
	if got := readMarker(t, markerPath); got != staleMarker {
		t.Fatalf("read-only list rewrote the version-bookkeeping marker: got %q, want %q", got, staleMarker)
	}
}

// TestClassifiedReadKeepsNormalMaintenance runs plain `list` (no --readonly)
// on the same kind of project and expects it to succeed and to refresh the
// old version marker, as an ordinary read does.
func TestClassifiedReadKeepsNormalMaintenance(t *testing.T) {
	requireEmbeddedEnabled(t)
	t.Parallel()

	bd := buildEmbeddedBD(t)
	dir, beadsDir, _ := bdInit(t, bd, "--prefix", "cr")
	bdCreate(t, bd, dir, "Seed issue")

	markerPath := seedStaleMarker(t, beadsDir)

	out, err := runBDRaw(t, bd, dir, "list")
	if err != nil {
		t.Fatalf("ordinary list of a seeded project should succeed, got error: %v\noutput:\n%s", err, out)
	}
	if got := readMarker(t, markerPath); got == staleMarker {
		t.Fatalf("ordinary list did not refresh the version-bookkeeping marker; marker still %q", got)
	}
}

// sharedHousekeepingDir is the process-global scratch directory where bd keeps
// circuit-breaker state for managed database servers. It is a fixed path the
// tool has always used. The checks plant a uniquely-named entry here and only
// ever inspect that one entry.
const sharedHousekeepingDir = "/tmp/beads-circuit"

// switchToManagedServerMode rewrites the freshly-initialized project metadata so
// the next invocation talks to a managed database server instead of the local
// embedded database. No server is running, so commands fail to connect.
func switchToManagedServerMode(t *testing.T, beadsDir string) {
	t.Helper()
	metaPath := filepath.Join(beadsDir, "metadata.json")
	data, err := os.ReadFile(metaPath)
	if err != nil {
		t.Fatalf("read project metadata: %v", err)
	}
	var meta map[string]any
	if err := json.Unmarshal(data, &meta); err != nil {
		t.Fatalf("parse project metadata: %v", err)
	}
	if got, _ := meta["dolt_mode"].(string); got != "embedded" {
		t.Fatalf("expected freshly-initialized project to default to embedded mode, got %q", got)
	}
	meta["dolt_mode"] = "server"
	out, err := json.MarshalIndent(meta, "", "  ")
	if err != nil {
		t.Fatalf("re-encode project metadata: %v", err)
	}
	if err := os.WriteFile(metaPath, out, 0o600); err != nil {
		t.Fatalf("write project metadata: %v", err)
	}
}

// plantStaleLeftover writes a uniquely-named circuit-breaker leftover into the
// shared scratch directory, aged well past the point where bd's housekeeping
// treats it as stale. The host, port and database in its name do not match
// the project under test, so only a sweep of stale entries would remove it.
func plantStaleLeftover(t *testing.T, tag string) string {
	t.Helper()
	if err := os.MkdirAll(sharedHousekeepingDir, 0o755); err != nil {
		t.Fatalf("prepare shared scratch dir: %v", err)
	}
	aged := time.Now().Add(-1 * time.Hour).UTC().Format(time.RFC3339)
	body := fmt.Sprintf(`{"state":"open","tripped_at":%q,"last_failure":%q}`, aged, aged)
	name := fmt.Sprintf("beads-dolt-circuit-vfy%s%d-59999-vfydb.json", tag, os.Getpid())
	path := filepath.Join(sharedHousekeepingDir, name)
	if err := os.WriteFile(path, []byte(body), 0o600); err != nil {
		t.Fatalf("plant stale leftover: %v", err)
	}
	t.Cleanup(func() { _ = os.Remove(path) })
	return path
}

// TestMutationFreeAuditLeavesLeftoverHousekeepingUntouched runs `list
// --readonly` on a server-configured project with no server up, after planting
// a stale circuit-breaker leftover in the shared scratch directory under /tmp,
// and expects the leftover to still be there. The command fails to connect;
// its exit status is not checked.
func TestMutationFreeAuditLeavesLeftoverHousekeepingUntouched(t *testing.T) {
	requireEmbeddedEnabled(t)
	t.Parallel()

	bd := buildEmbeddedBD(t)
	dir, beadsDir, _ := bdInit(t, bd, "--prefix", "cb")
	bdCreate(t, bd, dir, "Seed issue")
	switchToManagedServerMode(t, beadsDir)

	path := plantStaleLeftover(t, "ro")

	out, _ := runBDRaw(t, bd, dir, "list", "--readonly")

	if _, err := os.Stat(path); err != nil {
		t.Fatalf("read-only list deleted stale shared housekeeping state (%s): %v\noutput:\n%s", path, err, out)
	}
}

// TestClassifiedReadKeepsLeftoverHousekeeping runs plain `list` on the same
// kind of server-configured project and expects bd's usual sweep of stale
// circuit-breaker leftovers to remove the planted entry.
//
// Not parallel: the sweep removes every stale entry in the shared directory,
// including the one the --readonly check above plants. Running it before the
// parallel checks keeps the two apart.
func TestClassifiedReadKeepsLeftoverHousekeeping(t *testing.T) {
	requireEmbeddedEnabled(t)

	bd := buildEmbeddedBD(t)
	dir, beadsDir, _ := bdInit(t, bd, "--prefix", "cs")
	bdCreate(t, bd, dir, "Seed issue")
	switchToManagedServerMode(t, beadsDir)

	path := plantStaleLeftover(t, "rw")

	out, _ := runBDRaw(t, bd, dir, "list")

	if _, err := os.Stat(path); !os.IsNotExist(err) {
		t.Fatalf("ordinary list no longer sweeps stale shared housekeeping state (%s still present, stat error %v)\noutput:\n%s", path, err, out)
	}
}

// serverStartLockName is the lock file under .beads that bd takes when it
// tries to start the project's managed dolt server.
const serverStartLockName = "dolt-server.lock"

// autoStartEnv is bdEnv with server auto-start left at its default (on)
// instead of switched off. The image has no dolt binary, so a start attempt
// fails after taking its lock and the command exits with an error.
func autoStartEnv(dir string) []string {
	return envWithout(bdEnv(dir), "BEADS_DOLT_AUTO_START")
}

// runBDAutoStart is runBDRaw with server auto-start allowed.
func runBDAutoStart(t *testing.T, bd, dir string, args ...string) string {
	t.Helper()
	cmd := exec.Command(bd, args...)
	cmd.Dir = dir
	cmd.Env = autoStartEnv(dir)
	out, _ := cmd.CombinedOutput()
	return string(out)
}

// TestReadOnlyDoesNotStartServer runs `list --readonly` on a server-configured
// project with auto-start allowed and no server up, and expects .beads to be
// left exactly as it was: no attempt to start the server. The command fails to
// connect; its exit status is not checked.
//
// Not parallel, like the other server-configured checks that may sweep the
// shared scratch directory.
func TestReadOnlyDoesNotStartServer(t *testing.T) {
	requireEmbeddedEnabled(t)

	bd := buildEmbeddedBD(t)
	dir, beadsDir, _ := bdInit(t, bd, "--prefix", "sr")
	bdCreate(t, bd, dir, "Seed issue")
	switchToManagedServerMode(t, beadsDir)

	before := snapshotTree(t, beadsDir)

	out := runBDAutoStart(t, bd, dir, "list", "--readonly")

	after := snapshotTree(t, beadsDir)
	if !reflect.DeepEqual(after, before) {
		t.Fatalf("read-only list changed files under .beads\nbefore: %#v\nafter:  %#v\noutput: %s", before, after, out)
	}
}

// TestOrdinaryReadStillStartsServer runs plain `list` on the same kind of
// project and expects bd to still try to start the managed server, which
// leaves the server start lock under .beads.
func TestOrdinaryReadStillStartsServer(t *testing.T) {
	requireEmbeddedEnabled(t)

	bd := buildEmbeddedBD(t)
	dir, beadsDir, _ := bdInit(t, bd, "--prefix", "so")
	bdCreate(t, bd, dir, "Seed issue")
	switchToManagedServerMode(t, beadsDir)

	out := runBDAutoStart(t, bd, dir, "list")

	if _, err := os.Stat(filepath.Join(beadsDir, serverStartLockName)); err != nil {
		t.Fatalf("ordinary list no longer tries to start the managed server (no %s): %v\noutput:\n%s", serverStartLockName, err, out)
	}
}

// upkeepOutputNames are what bd's after-command upkeep writes under .beads
// when it runs: the auto-export JSONL snapshot and its throttle-state file,
// and the auto-backup directory.
var upkeepOutputNames = []string{"issues.jsonl", "export-state.json", "backup"}

// enableAfterCommandUpkeep turns on auto-export and auto-backup and records a
// remote so `config validate` runs to completion instead of refusing early.
// All three go through the public config surface. A file:// remote passes the
// tool's remote-URL validation.
func enableAfterCommandUpkeep(t *testing.T, bd, dir string) {
	t.Helper()
	bdCommand(t, bd, dir, "config", "set", "export.auto", "true")
	bdCommand(t, bd, dir, "config", "set", "backup.enabled", "true")
	bdCommand(t, bd, dir, "config", "set", "federation.remote", "file:///tmp/beads-vfy-remote")
}

// clearUpkeepOutput removes the export output, its throttle state and the
// backup directory (the setup commands above already ran the upkeep), so the
// next command that runs the upkeep is neither throttled nor skipped as
// unchanged.
func clearUpkeepOutput(t *testing.T, beadsDir string) {
	t.Helper()
	for _, name := range upkeepOutputNames {
		if err := os.RemoveAll(filepath.Join(beadsDir, name)); err != nil {
			t.Fatalf("clear upkeep output %s: %v", name, err)
		}
	}
}

// TestMutationFreeNonClassifiedCommandSkipsPostRunMaintenance runs `config
// validate --readonly` on a seeded project with auto-export and auto-backup
// turned on and no export or backup output yet, and expects .beads to be
// byte-for-byte unchanged with no export or backup written. `config validate`
// is not one of the list/show style read commands, so without --readonly it
// runs the same after-command upkeep as a write command. Exit status is not
// checked.
func TestMutationFreeNonClassifiedCommandSkipsPostRunMaintenance(t *testing.T) {
	requireEmbeddedEnabled(t)
	t.Parallel()

	bd := buildEmbeddedBD(t)
	dir, beadsDir, _ := bdInit(t, bd, "--prefix", "pm")
	bdCreate(t, bd, dir, "Seed issue")

	enableAfterCommandUpkeep(t, bd, dir)
	clearUpkeepOutput(t, beadsDir)

	before := snapshotTree(t, beadsDir)

	out, _ := runBDRaw(t, bd, dir, "config", "validate", "--readonly")

	after := snapshotTree(t, beadsDir)
	if !reflect.DeepEqual(after, before) {
		t.Fatalf("read-only config validate changed files under .beads\nbefore: %#v\nafter:  %#v\noutput: %s", before, after, out)
	}
	for _, name := range upkeepOutputNames {
		if _, err := os.Stat(filepath.Join(beadsDir, name)); err == nil {
			t.Fatalf("read-only config validate wrote %s\noutput:\n%s", name, out)
		}
	}
}

// projectDatabaseDir returns the project's database directory inside the
// local embedded data directory. A freshly initialized project has exactly one.
func projectDatabaseDir(t *testing.T, beadsDir string) string {
	t.Helper()
	dotDolt, err := filepath.Glob(filepath.Join(beadsDir, embeddedDataDirName, "*", ".dolt"))
	if err != nil || len(dotDolt) != 1 {
		t.Fatalf("expected exactly one database under %s, found %v (err %v)", filepath.Join(beadsDir, embeddedDataDirName), dotDolt, err)
	}
	return filepath.Dir(dotDolt[0])
}

// removeProjectDatabase deletes the project's database from the local data
// directory and leaves everything else in place, so the project's database
// has not been created on this machine yet.
func removeProjectDatabase(t *testing.T, beadsDir string) string {
	t.Helper()
	dbDir := projectDatabaseDir(t, beadsDir)
	if err := os.RemoveAll(dbDir); err != nil {
		t.Fatalf("remove project database: %v", err)
	}
	return dbDir
}

// TestReadOnlyDoesNotCreateMissingDatabase runs `list --readonly` on a project
// whose database has not been created in the local data directory yet and
// expects nothing to be created and .beads to be left exactly as it was.
// Refusing is fine, so exit status is not checked.
func TestReadOnlyDoesNotCreateMissingDatabase(t *testing.T) {
	requireEmbeddedEnabled(t)
	t.Parallel()

	bd := buildEmbeddedBD(t)
	dir, beadsDir, _ := bdInit(t, bd, "--prefix", "fc")
	bdCreate(t, bd, dir, "Seed issue")
	dbDir := removeProjectDatabase(t, beadsDir)

	before := snapshotTree(t, beadsDir)

	out, _ := runBDRaw(t, bd, dir, "list", "--readonly")

	if _, err := os.Lstat(dbDir); !os.IsNotExist(err) {
		t.Fatalf("read-only list created the project database at %s (stat error %v)\noutput:\n%s", dbDir, err, out)
	}
	after := snapshotTree(t, beadsDir)
	if !reflect.DeepEqual(after, before) {
		t.Fatalf("read-only list changed files under .beads\nbefore: %#v\nafter:  %#v\noutput: %s", before, after, out)
	}
}

// TestOrdinaryReadCreatesMissingDatabase runs plain `list` on the same kind of
// project and expects it to succeed and create the project database, as an
// ordinary read does on first use.
func TestOrdinaryReadCreatesMissingDatabase(t *testing.T) {
	requireEmbeddedEnabled(t)
	t.Parallel()

	bd := buildEmbeddedBD(t)
	dir, beadsDir, _ := bdInit(t, bd, "--prefix", "fo")
	bdCreate(t, bd, dir, "Seed issue")
	dbDir := removeProjectDatabase(t, beadsDir)

	out, err := runBDRaw(t, bd, dir, "list")
	if err != nil {
		t.Fatalf("ordinary list on a project whose database is missing locally should succeed, got error: %v\noutput:\n%s", err, out)
	}
	if info, err := os.Stat(dbDir); err != nil || !info.IsDir() {
		t.Fatalf("ordinary list did not create the project database at %s (stat error %v)\noutput:\n%s", dbDir, err, out)
	}
}

// plantStaleFetchFile writes an aged temporary fetch file into the project
// database's git remote cache. Interrupted fetches leave files like this
// behind, and the database's normal upkeep deletes the old ones.
func plantStaleFetchFile(t *testing.T, beadsDir string) string {
	t.Helper()
	cacheDir := filepath.Join(projectDatabaseDir(t, beadsDir), ".dolt", "git-remote-cache", "vfy-remote")
	if err := os.MkdirAll(cacheDir, 0o755); err != nil {
		t.Fatalf("prepare git remote cache: %v", err)
	}
	path := filepath.Join(cacheDir, "tmp_pack_vfy")
	if err := os.WriteFile(path, []byte("partial fetch"), 0o600); err != nil {
		t.Fatalf("plant stale fetch file: %v", err)
	}
	aged := time.Now().Add(-1 * time.Hour)
	if err := os.Chtimes(path, aged, aged); err != nil {
		t.Fatalf("age stale fetch file: %v", err)
	}
	return path
}

// TestReadOnlyKeepsStaleDatabaseLeftovers runs `list --readonly` on a seeded
// project with a stale temporary fetch file in the local database's git
// remote cache and expects the read to succeed and the file to still be there.
func TestReadOnlyKeepsStaleDatabaseLeftovers(t *testing.T) {
	requireEmbeddedEnabled(t)
	t.Parallel()

	bd := buildEmbeddedBD(t)
	dir, beadsDir, _ := bdInit(t, bd, "--prefix", "tr")
	bdCreate(t, bd, dir, "Seed issue")
	path := plantStaleFetchFile(t, beadsDir)

	out, err := runBDRaw(t, bd, dir, "list", "--readonly")
	if err != nil {
		t.Fatalf("read-only list of a seeded project should succeed, got error: %v\noutput:\n%s", err, out)
	}
	if _, err := os.Stat(path); err != nil {
		t.Fatalf("read-only list deleted a stale file under .beads (%s): %v\noutput:\n%s", path, err, out)
	}
}

// TestOrdinaryReadCleansStaleDatabaseLeftovers runs plain `list` on the same
// kind of project and expects the database's normal upkeep to remove the stale
// temporary fetch file.
func TestOrdinaryReadCleansStaleDatabaseLeftovers(t *testing.T) {
	requireEmbeddedEnabled(t)
	t.Parallel()

	bd := buildEmbeddedBD(t)
	dir, beadsDir, _ := bdInit(t, bd, "--prefix", "to")
	bdCreate(t, bd, dir, "Seed issue")
	path := plantStaleFetchFile(t, beadsDir)

	out, err := runBDRaw(t, bd, dir, "list")
	if err != nil {
		t.Fatalf("ordinary list of a seeded project should succeed, got error: %v\noutput:\n%s", err, out)
	}
	if _, err := os.Stat(path); !os.IsNotExist(err) {
		t.Fatalf("ordinary list no longer cleans stale temporary fetch files (%s still present, stat error %v)\noutput:\n%s", path, err, out)
	}
}
