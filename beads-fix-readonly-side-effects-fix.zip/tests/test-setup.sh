#!/usr/bin/env bash
# The image bakes the full dependency closure at the base commit (Go module +
# build caches warm, CGO_ENABLED=1, -tags gms_pure_go), so the Go verifier
# compiles and runs with no network and nothing to install here.
#
# Every verifier check drives a bd binary built from the repository against
# throwaway projects using the embedded database. The server-configured checks
# need no running dolt server: they only look at what bd does before it tries
# to connect. So no server is started here.
set -euo pipefail
echo "[test-setup] no-op for beads-fix-readonly-side-effects (deps baked into image)"
