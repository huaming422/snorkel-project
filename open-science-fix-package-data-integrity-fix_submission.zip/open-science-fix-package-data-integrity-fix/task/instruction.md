## Task

we've got a stack of user reports piling up that all smell like data loss, and i'm fairly sure they share a cause. the symptoms:

- installing or importing a Specialist package sometimes deletes a completely unrelated Skill the user never touched. it seems to land when an install gets interrupted partway through.
- reusing a Skill that's already installed quietly overwrites local edits the user made in the Skill editor.
- when a Marketplace install hits a problem during its cleanup, the app forgets which Skills it had disabled and loses any record that the install happened, and recovery doesn't bring them back.
- exporting a Specialist is flaky both directions: sometimes a valid export is wrongly blocked, sometimes the package it produces is silently missing a Skill on re-import.
- a pending-recovery record for the Marketplace sometimes just vanishes after an unrelated background refresh.

all of this is per-user on-disk state. dig into how the Specialist package install/export flow and the Marketplace install/recovery flow persist and recover that state, and stop the data loss.
