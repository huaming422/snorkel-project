## Task

Our upgrade notice only shows up in an interactive terminal, so anything that drives the CLI non-interactively (scripts, piped commands, agents) never finds out when a newer stable release is out. We want an explicit, machine-readable way to ask the CLI whether a newer stable release exists, so automation can read the answer and decide whether to upgrade. Keep this additive to the interactive upgrade notice rather than reworking it, and make sure the answer stays correct and honest when the release lookup can't complete.

## User stories / requirements

- Running the explicit status query prints a single machine-readable object describing the CLI's update status and exits successfully. The object always carries the installed version and an overall status, so a script can parse one line of output and act on it.
- When a newer stable release is known, the status says an update is available and names that latest stable version. A release that is only a pre-release does not count as an available update.
- When the available releases include a pre-release that sorts above every stable release, the status still names only the latest STABLE release as the update target; the pre-release is never offered as something to upgrade to.
- When the latest stable release can't be determined, the status reports that it is explicitly unknown, rather than claiming the CLI is already up to date.
- When a newer stable release was already known from an earlier successful lookup, it still shows up as an available update even if the current lookup attempt fails.
