## Task

The bead store keeps an optional versioned history: with it on, every edit to a bead records a version. That recording status gets corrupted when a bead takes a round trip off the main plane and back.

The move is routine: mark a bead ephemeral to pull it off the main plane, then make it persistent again or promote it to bring it back. Two things then go wrong, only while history is on.

A bead created before history was on has no versions and should stay silent. After going ephemeral and returning, it gets versioned anyway: a first version, then one on every later edit.

A bead that was already recording comes back with its version trail disturbed instead of continuing.

It is specific to the round trip. Beads that never leave the main plane are fine, and one genuinely created ephemeral records correctly when it first reaches the main plane. With history off, nothing changes.

Find why the round trip changes a bead's recording status and fix it: a silent bead stays silent, a recording one keeps going.
