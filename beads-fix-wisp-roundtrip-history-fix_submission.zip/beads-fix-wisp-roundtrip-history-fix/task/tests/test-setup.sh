#!/usr/bin/env bash
# All Go dependencies and the compiled test tree are baked into the image at
# the base commit (blocks 5 and 7). The agent and verifier phases are offline
# (GOPROXY=off), so nothing is fetched here.
set -euo pipefail
echo "[test-setup] no-op for beads-fix-wisp-roundtrip-history"
