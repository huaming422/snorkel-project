//go:build cgo

// External-package (embeddeddolt_test) verifier. It drives the full
// create -> enable-history -> demote -> arrive lifecycle entirely through the
// store's pre-existing public surface and observes the result ONLY through two
// stable read paths:
//
//   - storage.VersionLister.ListVersions(ctx, id) -- the recorded version trail
//     the dashboard and `bd` consume.
//   - the per-row participation column, read with a raw SELECT over a
//     short-lived OpenSQL connection (the same read the repo's own contract
//     fixtures use).
//
// It names NO helper, field, receiver, or sentinel the fix introduces: a move
// off the main plane and back is exercised purely as a sequence of guarded
// public operations, so any correct implementation -- whatever it calls its
// carrier, however it decomposes the carry/restore, whatever encoding it picks
// for "was legacy" -- passes, and any implementation that lets recording status
// change across the round trip fails.
//
// This file joins the package's existing _test harness: newTestEnv,
// skipUnlessEmbeddedDolt, and (*testEnv).queryScalar come from the sibling
// create_issue_test.go and test_fixture_test.go already in this directory.

package embeddeddolt_test

import (
	"context"
	"database/sql"
	"testing"

	"github.com/steveyegge/beads/internal/storage"
	"github.com/steveyegge/beads/internal/storage/embeddeddolt"
	"github.com/steveyegge/beads/internal/types"
	publicops "github.com/steveyegge/beads/issueops"
)

// epochStoreID is any store identifier. The epoch counter is per database, not
// per store id (the id appears only in a bump's error text -- see
// TestABumpUnderOneStoreIDMovesTheEpochSeenThroughEveryStoreID), so the exact
// string is immaterial; it only has to be non-empty.
const epochStoreID = "verify-store"

// mkActor is the actor string every operation runs under.
const mkActor = "actor"

// create makes an issue through the store's public CreateIssue, failing the
// test on error, and returns its generated id. ephemeral selects the plane the
// row is born on.
func create(t *testing.T, ctx context.Context, store *embeddeddolt.EmbeddedDoltStore, title string, ephemeral bool) string {
	t.Helper()
	issue := &types.Issue{
		Title:     title,
		IssueType: types.TypeTask,
		Status:    types.StatusOpen,
		Ephemeral: ephemeral,
	}
	if err := store.CreateIssue(ctx, issue, mkActor); err != nil {
		t.Fatalf("CreateIssue(%q, ephemeral=%v): %v", title, ephemeral, err)
	}
	if issue.ID == "" {
		t.Fatalf("CreateIssue(%q) did not generate an id", title)
	}
	return issue.ID
}

// setHistory toggles the versioned-history flag through the public configurer
// surface `bd serve` uses (the type assertion, never the concrete method set).
func setHistory(t *testing.T, store *embeddeddolt.EmbeddedDoltStore, enabled bool) {
	t.Helper()
	configurer, ok := any(store).(storage.VersionedHistoryConfigurer)
	if !ok {
		t.Fatalf("%T does not implement storage.VersionedHistoryConfigurer", store)
	}
	configurer.SetVersionedHistoryEnabled(enabled)
}

// movePersistence runs the guarded persistence-mode update `bd update
// --persistent` / `--ephemeral` runs: the one public plane move that reaches
// the main plane without creating the row there (persistent) or leaves it
// (ephemeral). Both demotion and the persistence-move arrival go through here.
func movePersistence(t *testing.T, ctx context.Context, store *embeddeddolt.EmbeddedDoltStore, id string, mode publicops.PersistenceMode) {
	t.Helper()
	ops, err := embeddeddolt.NewIssueOperations(store)
	if err != nil {
		t.Fatalf("NewIssueOperations: %v", err)
	}
	result, err := ops.Update(ctx, publicops.UpdateRequest{
		Actor:   mkActor,
		IssueID: id,
		Patch: publicops.IssuePatch{
			Persistence: publicops.Field[publicops.PersistenceMode]{Set: true, Value: mode},
		},
	})
	if err != nil {
		t.Fatalf("persistence move of %s to %v: %v", id, mode, err)
	}
	if !result.Changed {
		t.Fatalf("persistence move of %s to %v reported no change", id, mode)
	}
}

// demote marks id ephemeral through the guarded persistence move, then asserts
// the row actually landed in the wisps table. The precondition is checked, not
// assumed: a "demotion" that left the row on the issues plane would make the
// arrival a same-plane write, and the round trip would prove nothing.
func demote(t *testing.T, ctx context.Context, env *testEnv, id string) {
	t.Helper()
	movePersistence(t, ctx, env.store, id, publicops.PersistenceModeEphemeral)
	if !inWispsTable(t, ctx, env, id) {
		t.Fatalf("%s is not in the wisps table after its demotion: this case pins a round trip through the wisps plane, and the row never left the main plane", id)
	}
}

// editTitle performs an ordinary update-shaped edit through the public
// UpdateIssue -- a plain content change, the kind that mints a row's next
// version when (and only when) the row participates in history.
func editTitle(t *testing.T, ctx context.Context, store *embeddeddolt.EmbeddedDoltStore, id, title string) {
	t.Helper()
	if err := store.UpdateIssue(ctx, id, map[string]any{"title": title}, mkActor); err != nil {
		t.Fatalf("UpdateIssue(%s, title=%q): %v", id, title, err)
	}
}

// versionCount returns the length of the public recorded version trail for id,
// read through storage.VersionLister.ListVersions -- the observation interface,
// never a source identifier the fix defines.
func versionCount(t *testing.T, ctx context.Context, store *embeddeddolt.EmbeddedDoltStore, id string) int {
	t.Helper()
	lister, ok := any(store).(storage.VersionLister)
	if !ok {
		t.Fatalf("%T does not implement storage.VersionLister", store)
	}
	versions, err := lister.ListVersions(ctx, id)
	if err != nil {
		t.Fatalf("ListVersions(%s): %v", id, err)
	}
	return len(versions)
}

// participation returns the per-row participation value for id on the issues
// plane, read with a raw SELECT (NULL -> nil). This is what distinguishes a row
// that carried its recording status across the trip from one that was
// re-stamped or fenced; it is a pre-existing column, read the same way the
// repo's own fixtures read it.
func participation(t *testing.T, ctx context.Context, env *testEnv, id string) *int64 {
	t.Helper()
	var gen sql.NullInt64
	env.queryScalar(t, ctx, "SELECT participation_generation FROM issues WHERE id = ?", []any{id}, &gen)
	if !gen.Valid {
		return nil
	}
	return &gen.Int64
}

// inWispsTable reports whether a row for id currently sits in the wisps table.
func inWispsTable(t *testing.T, ctx context.Context, env *testEnv, id string) bool {
	t.Helper()
	var rows int
	env.queryScalar(t, ctx, "SELECT COUNT(*) FROM wisps WHERE id = ?", []any{id}, &rows)
	return rows > 0
}

// bumpEpoch advances the per-database epoch counter, the stressor that exposes
// a restore which re-derives participation from the current epoch instead of
// replaying the value the row carried.
func bumpEpoch(t *testing.T, ctx context.Context, store *embeddeddolt.EmbeddedDoltStore, reason string) {
	t.Helper()
	if _, err := store.BumpEpoch(ctx, epochStoreID, reason); err != nil {
		t.Fatalf("BumpEpoch(%q): %v", reason, err)
	}
}

// -- C1 ----------------------------------------------------------------------
// A row created before recording was enabled (legacy, no versions) stays legacy
// across a round trip whose arrival is the persistence move back to persistent:
// zero versions after the trip, and zero after a further ordinary edit.
func TestVerifyLegacyStaysLegacyAcrossPersistenceMove(t *testing.T) {
	skipUnlessEmbeddedDolt(t)
	env := newTestEnv(t, "wrtpm")
	ctx := t.Context()

	setHistory(t, env.store, false)
	id := create(t, ctx, env.store, "legacy-move", false)
	setHistory(t, env.store, true)

	if gen := participation(t, ctx, env, id); gen != nil {
		t.Fatalf("participation for %s = %d before the round trip, want NULL: this case cannot prove a legacy row stays legacy if the row was never legacy", id, *gen)
	}

	demote(t, ctx, env, id)
	movePersistence(t, ctx, env.store, id, publicops.PersistenceModePersistent)

	assertLegacy := func(after string) {
		t.Helper()
		if gen := participation(t, ctx, env, id); gen != nil {
			t.Errorf("participation for %s = %d after %s, want NULL: the row was legacy when demoted, and an ordinary write must not promote a legacy record", id, *gen, after)
		}
		if got := versionCount(t, ctx, env.store, id); got != 0 {
			t.Errorf("version count for %s = %d after %s, want 0: a legacy row records nothing, across a plane round trip too", id, got, after)
		}
	}
	assertLegacy("the round trip (persistence move)")

	editTitle(t, ctx, env.store, id, "legacy-move-edited")
	assertLegacy("an ordinary edit after the round trip")
}

// -- C2 ----------------------------------------------------------------------
// The same legacy-stays-legacy guarantee when the arrival is a promote instead
// of a persistence move (the two arrival paths mint at different sites).
func TestVerifyLegacyStaysLegacyAcrossPromote(t *testing.T) {
	skipUnlessEmbeddedDolt(t)
	env := newTestEnv(t, "wrtpr")
	ctx := t.Context()

	setHistory(t, env.store, false)
	id := create(t, ctx, env.store, "legacy-promote", false)
	setHistory(t, env.store, true)

	if gen := participation(t, ctx, env, id); gen != nil {
		t.Fatalf("participation for %s = %d before the round trip, want NULL", id, *gen)
	}

	demote(t, ctx, env, id)
	if err := env.store.PromoteFromEphemeral(ctx, id, mkActor); err != nil {
		t.Fatalf("PromoteFromEphemeral(%s): %v", id, err)
	}

	assertLegacy := func(after string) {
		t.Helper()
		if gen := participation(t, ctx, env, id); gen != nil {
			t.Errorf("participation for %s = %d after %s, want NULL: a promote back onto the main plane must not promote a legacy record to a participant", id, *gen, after)
		}
		if got := versionCount(t, ctx, env.store, id); got != 0 {
			t.Errorf("version count for %s = %d after %s, want 0", id, got, after)
		}
	}
	assertLegacy("the round trip (promote)")

	editTitle(t, ctx, env.store, id, "legacy-promote-edited")
	assertLegacy("an ordinary edit after the round trip")
}

// -- C3 ----------------------------------------------------------------------
// A participating row keeps its history across the round trip: version count
// rises by exactly one at the arrival (its next version, not a second first
// one), and by exactly one more on a subsequent edit. Its restored
// participation is the generation it carried, NOT a value derived from the
// current epoch -- an epoch bump between demotion and arrival must not change
// it. Both arrival paths are exercised.
func TestVerifyParticipatingKeepsHistoryAcrossRoundTrip(t *testing.T) {
	skipUnlessEmbeddedDolt(t)

	arrivals := []struct {
		name   string
		prefix string
		arrive func(t *testing.T, ctx context.Context, env *testEnv, id string)
	}{
		{
			name:   "persistence_move",
			prefix: "wrtkm",
			arrive: func(t *testing.T, ctx context.Context, env *testEnv, id string) {
				movePersistence(t, ctx, env.store, id, publicops.PersistenceModePersistent)
			},
		},
		{
			name:   "promote",
			prefix: "wrtkr",
			arrive: func(t *testing.T, ctx context.Context, env *testEnv, id string) {
				if err := env.store.PromoteFromEphemeral(ctx, id, mkActor); err != nil {
					t.Fatalf("PromoteFromEphemeral(%s): %v", id, err)
				}
			},
		},
	}

	for _, a := range arrivals {
		t.Run(a.name, func(t *testing.T) {
			env := newTestEnv(t, a.prefix)
			ctx := t.Context()

			setHistory(t, env.store, true)
			id := create(t, ctx, env.store, "participating-"+a.name, false)

			before := participation(t, ctx, env, id)
			if before == nil {
				t.Fatalf("participation for %s is NULL right after a create with history on: this case needs a participating row to start from", id)
			}
			beforeCount := versionCount(t, ctx, env.store, id)

			demote(t, ctx, env, id)
			if got := versionCount(t, ctx, env.store, id); got != beforeCount {
				t.Errorf("version count for %s went from %d to %d across its demotion, want unchanged: a wisp is never versioned", id, beforeCount, got)
			}

			// Stress a restore that follows the current epoch instead of
			// replaying the carried generation.
			bumpEpoch(t, ctx, env.store, "restore")

			a.arrive(t, ctx, env, id)

			after := participation(t, ctx, env, id)
			if after == nil {
				t.Errorf("participation for %s is NULL after the round trip, want %d: the row participated when demoted, and a NULL here fences it as legacy for good", id, *before)
			} else if *after != *before {
				t.Errorf("participation for %s = %d after the round trip, want %d: the row keeps the generation it carried, not one re-derived from the bumped epoch", id, *after, *before)
			}

			arrivedCount := versionCount(t, ctx, env.store, id)
			if arrivedCount != beforeCount+1 {
				t.Errorf("version count for %s went from %d to %d across the round trip, want exactly +1: the arrival mints the participating row's next version, not a second first one", id, beforeCount, arrivedCount)
			}

			editTitle(t, ctx, env.store, id, "participating-"+a.name+"-edited")
			if afterCount := versionCount(t, ctx, env.store, id); afterCount != arrivedCount+1 {
				t.Errorf("version count for %s went from %d to %d across an edit after the round trip, want exactly +1", id, arrivedCount, afterCount)
			}
		})
	}
}

// -- C4 (pass_to_pass) -------------------------------------------------------
// A row genuinely created as a wisp still starts recording when it first
// arrives on the main plane -- exactly one recorded version afterward. Both
// arrival paths. This guards against an over-broad "fence every arrival" fix.
func TestVerifyGenuineWispStartsRecording(t *testing.T) {
	skipUnlessEmbeddedDolt(t)

	arrivals := []struct {
		name   string
		prefix string
		arrive func(t *testing.T, ctx context.Context, env *testEnv, id string)
	}{
		{
			name:   "promote",
			prefix: "wrtgr",
			arrive: func(t *testing.T, ctx context.Context, env *testEnv, id string) {
				if err := env.store.PromoteFromEphemeral(ctx, id, mkActor); err != nil {
					t.Fatalf("PromoteFromEphemeral(%s): %v", id, err)
				}
			},
		},
		{
			name:   "persistence_move",
			prefix: "wrtgm",
			arrive: func(t *testing.T, ctx context.Context, env *testEnv, id string) {
				movePersistence(t, ctx, env.store, id, publicops.PersistenceModePersistent)
			},
		},
	}

	for _, a := range arrivals {
		t.Run(a.name, func(t *testing.T) {
			env := newTestEnv(t, a.prefix)
			ctx := t.Context()

			setHistory(t, env.store, true)
			id := create(t, ctx, env.store, "genuine-wisp-"+a.name, true)
			if !inWispsTable(t, ctx, env, id) {
				t.Fatalf("%s created ephemeral is not in the wisps table", id)
			}

			a.arrive(t, ctx, env, id)

			if got := versionCount(t, ctx, env.store, id); got != 1 {
				t.Errorf("version count for a genuine wisp %s after its first arrival = %d, want 1: a real first arrival must begin its history", id, got)
			}
		})
	}
}

// -- C5 (pass_to_pass) -------------------------------------------------------
// A demotion performed while versioned history is OFF carries nothing: the
// carry runs only under the flag. So a row demoted with history off is, once
// history is on, indistinguishable from a genuine wisp -- when it later arrives
// on the main plane it begins its history (one version), and a subsequent edit
// adds one more. A fix that carries regardless of the flag would instead stash
// a legacy sentinel during the history-off demotion, restore it on arrival, and
// fence the row as legacy (zero versions) -- so this case pins the flag guard.
//
// The row must still be on the wisps plane when history is turned on, so the
// arrival is a real wisp arrival: the whole point is that the history-off
// demotion left nothing behind for the history-on arrival to restore.
func TestVerifyCarryInertWithHistoryOff(t *testing.T) {
	skipUnlessEmbeddedDolt(t)
	env := newTestEnv(t, "wrtoff")
	ctx := t.Context()

	// Demote with history OFF: the carry, if any, must not run.
	setHistory(t, env.store, false)
	id := create(t, ctx, env.store, "history-off-demote", false)
	demote(t, ctx, env, id)

	// Turn history on with the row still on the wisps plane, then bring it back.
	// Nothing was carried, so this is a genuine first arrival.
	setHistory(t, env.store, true)
	movePersistence(t, ctx, env.store, id, publicops.PersistenceModePersistent)

	arrived := versionCount(t, ctx, env.store, id)
	if arrived != 1 {
		t.Errorf("version count for %s = %d after it arrived (demoted with history off, then returned with history on), want 1: a demotion made with the flag off carries nothing, so the arrival is a genuine wisp's first version -- a carry that ignored the flag would restore a legacy sentinel and fence this row to 0", id, arrived)
	}

	editTitle(t, ctx, env.store, id, "history-off-demote-edited")
	if got := versionCount(t, ctx, env.store, id); got != arrived+1 {
		t.Errorf("version count for %s went from %d to %d on an edit after it began recording, want +1: a genuine first arrival is a participant thereafter, not fenced as legacy", id, arrived, got)
	}
}
