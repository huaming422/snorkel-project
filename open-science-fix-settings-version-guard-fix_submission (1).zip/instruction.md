## Task

People who roll back to an older build of the Open Science desktop app are losing settings a newer build saved. They change one unrelated preference and a chunk of their configuration comes back at defaults. A few hit it with no change at all, after a crash or an interrupted update left them on the older build.

An older build shouldn't load or save settings that a newer build wrote. It should refuse them and leave what's on disk exactly as it was, so the next upgrade finds everything still there.
