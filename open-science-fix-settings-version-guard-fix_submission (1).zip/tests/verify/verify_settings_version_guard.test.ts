// Behavioural verifier for the settings persistence-safety fix.
//
// It exercises two pre-existing, stable interfaces and observes only
// user-visible outcomes — never the fix shape:
//
//   * `SettingsDocumentStore` (./document-store) — read()/mutate() of
//     settings.json. We assert on reject-vs-resolve, on the on-disk bytes,
//     and on the migrated result SHAPE. We never assert on the thrown
//     error's class or message text, because a valid solution may word or
//     type its rejection however it likes.
//
//   * `readDurableJsonFile` + `DurableJsonRecoveryBarrierError`
//     (../storage/durable-json-file) — the generic crash-recovery reader
//     and the pre-existing signalling type a decoder throws to mean "this
//     recognised leftover holds authoritative data I cannot interpret;
//     preserve it." The barrier type already ships in the pre-fix tree; the
//     verifier constructs it in its OWN decode to drive the reader, so the
//     assertions do not depend on the solution subclassing or re-messaging
//     anything.
//
// Every literal here is either repo-stable (the version constant, the
// recognised `<13-digit>-<seq>.tmp` suffix format) or harness-owned test
// fixture data. No implementation-invented symbol is imported.

import { mkdtemp, readFile, readdir, utimes, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { afterEach, describe, expect, it, vi } from 'vitest'

import { SETTINGS_FILE_VERSION } from '../../shared/settings'
import { SettingsDocumentStore } from './document-store'
import {
  DurableJsonRecoveryBarrierError,
  readDurableJsonFile
} from '../storage/durable-json-file'

// A version strictly greater than what this build supports — "a document a
// newer build wrote." Derived from the repo-stable constant, not hardcoded.
const FUTURE_VERSION = SETTINGS_FILE_VERSION + 1

const roots: string[] = []

afterEach(async () => {
  const { rm } = await import('node:fs/promises')
  await Promise.all(roots.splice(0).map((root) => rm(root, { force: true, recursive: true })))
  vi.clearAllMocks()
})

const makeRoot = async (): Promise<string> => {
  const root = await mkdtemp(join(tmpdir(), 'open-science-settings-guard-'))
  roots.push(root)
  return root
}

describe('settings version guard', () => {
  // Criterion: mutating a future-version document rejects, the update callback
  // never runs, and the on-disk bytes are left exactly as they were.
  it('rejects mutation of a future settings document without overwriting its fields', async () => {
    const root = await makeRoot()
    const settingsPath = join(root, 'settings.json')
    const futureContents = `${JSON.stringify({
      version: FUTURE_VERSION,
      providers: [],
      futurePreference: 'must-survive'
    })}\n`
    await writeFile(settingsPath, futureContents, 'utf8')

    const store = new SettingsDocumentStore(root)
    const update = vi.fn((settings) => ({ ...settings, notificationsEnabled: false }))

    await expect(store.mutate(update)).rejects.toThrow()
    expect(update).not.toHaveBeenCalled()
    await expect(readFile(settingsPath, 'utf8')).resolves.toBe(futureContents)
  })

  // Criterion: reading a future-version document rejects instead of returning
  // a silently downgraded object, and does not modify the file.
  it('rejects reading a future settings document and leaves it untouched', async () => {
    const root = await makeRoot()
    const settingsPath = join(root, 'settings.json')
    const futureContents = `${JSON.stringify({
      version: FUTURE_VERSION,
      providers: [],
      futurePreference: 'must-survive'
    })}\n`
    await writeFile(settingsPath, futureContents, 'utf8')

    await expect(new SettingsDocumentStore(root).read()).rejects.toThrow()
    await expect(readFile(settingsPath, 'utf8')).resolves.toBe(futureContents)
  })

  // Criterion: a released version-1 document migrates forward to the supported
  // version on read and keeps its active provider and active model (migration
  // runs through the normal sanitise pipeline, not a reset to defaults).
  it('migrates a version 1 document forward keeping active provider and model', async () => {
    const root = await makeRoot()
    await writeFile(
      join(root, 'settings.json'),
      JSON.stringify({
        version: 1,
        providers: [{ id: 'provider-1', type: 'custom', name: 'Provider', model: 'model-1' }],
        activeProviderId: 'provider-1'
      }),
      'utf8'
    )

    await expect(new SettingsDocumentStore(root).read()).resolves.toMatchObject({
      version: SETTINGS_FILE_VERSION,
      activeProviderId: 'provider-1',
      activeModel: 'model-1'
    })
  })

  it('keeps a future settings leftover when the settings file itself is missing', async () => {
    const root = await makeRoot()
    const temporaryName = 'settings.json.1700000000000-1.tmp'
    const futureContents = `${JSON.stringify({
      version: FUTURE_VERSION,
      providers: [],
      futurePreference: 'must-survive'
    })}\n`
    await writeFile(join(root, temporaryName), futureContents, 'utf8')

    await expect(new SettingsDocumentStore(root).read()).rejects.toThrow()
    await expect(readFile(join(root, temporaryName), 'utf8')).resolves.toBe(futureContents)
    expect(await readdir(root)).toEqual([temporaryName])
  })

  it('keeps a future settings leftover sitting beside an older settings file', async () => {
    const root = await makeRoot()
    const settingsPath = join(root, 'settings.json')
    const temporaryPath = `${settingsPath}.1700000000000-1.tmp`
    const primaryContents = `${JSON.stringify({ version: SETTINGS_FILE_VERSION, providers: [] })}\n`
    const futureContents = `${JSON.stringify({
      version: FUTURE_VERSION,
      providers: [],
      futurePreference: 'must-survive'
    })}\n`
    await writeFile(settingsPath, primaryContents, 'utf8')
    await writeFile(temporaryPath, futureContents, 'utf8')

    await new SettingsDocumentStore(root).read().then(
      () => undefined,
      () => undefined
    )

    await expect(readFile(settingsPath, 'utf8')).resolves.toBe(primaryContents)
    await expect(readFile(temporaryPath, 'utf8')).resolves.toBe(futureContents)
  })

  // A decode that recognises a newer-than-supported document and signals the
  // recovery barrier. This is the verifier's own callback — it drives the
  // generic reader without depending on the solution's decoder.
  const barrierDecode = (contents: string): { version: number } => {
    const value = JSON.parse(contents) as { version: number }
    if (value.version > SETTINGS_FILE_VERSION) {
      throw new DurableJsonRecoveryBarrierError('newer than supported')
    }
    return value
  }

  // Criterion: during recovery, a future-version recognised temp sitting beside
  // a valid older primary is NOT deleted. The data-preservation contract is
  // that the future temp survives untouched so a later upgrade can recover it.
  // Two defensible shapes satisfy this and we admit BOTH: surface the barrier
  // (recovery rejects), or recover the primary while cleaning only candidates
  // this build can decode (recovery resolves and skips the future temp). We
  // therefore assert only on the preserved bytes, not on reject-vs-resolve.
  it('preserves a future recovery-barrier temp beside a valid primary', async () => {
    const root = await makeRoot()
    const filePath = join(root, 'settings.json')
    const temporaryPath = `${filePath}.1700000000000-1.tmp`
    const primaryContents = '{"version":2}\n'
    const futureContents = '{"version":3}\n'
    await writeFile(filePath, primaryContents, 'utf8')
    await writeFile(temporaryPath, futureContents, 'utf8')

    // Drive recovery; a barrier-surfacing solution rejects, a skip-and-preserve
    // solution resolves. Either outcome is acceptable — swallow it and observe
    // the filesystem.
    await readDurableJsonFile(filePath, barrierDecode).then(
      () => undefined,
      () => undefined
    )

    await expect(readFile(filePath, 'utf8')).resolves.toBe(primaryContents)
    await expect(readFile(temporaryPath, 'utf8')).resolves.toBe(futureContents)
  })

  // Criterion: during missing-primary recovery, a decodable current-format temp
  // with a newer mtime must NOT be promoted ahead of an older future-format
  // temp; the barrier in the future temp aborts recovery and both are kept.
  it('preserves a future recovery-barrier temp that sorts behind a decodable temp', async () => {
    const root = await makeRoot()
    const filePath = join(root, 'settings.json')
    const currentTemporaryPath = `${filePath}.1700000001000-2.tmp`
    const futureTemporaryPath = `${filePath}.1700000000000-1.tmp`
    const currentContents = '{"version":2}\n'
    const futureContents = '{"version":3}\n'
    await writeFile(currentTemporaryPath, currentContents, 'utf8')
    await writeFile(futureTemporaryPath, futureContents, 'utf8')
    // Make the current-format temp the newest candidate so a newest-first
    // promotion loop would reach it before ever decoding the future temp.
    const now = new Date()
    await utimes(futureTemporaryPath, new Date(now.getTime() - 2_000), new Date(now.getTime() - 2_000))
    await utimes(currentTemporaryPath, new Date(now.getTime() - 1_000), new Date(now.getTime() - 1_000))

    await expect(readDurableJsonFile(filePath, barrierDecode)).rejects.toThrow()
    await expect(readFile(currentTemporaryPath, 'utf8')).resolves.toBe(currentContents)
    await expect(readFile(futureTemporaryPath, 'utf8')).resolves.toBe(futureContents)
    // Nothing was promoted to the primary and no candidate was swept: exactly
    // the two temps remain. Sorted so the check does not depend on readdir order.
    expect((await readdir(root)).sort()).toEqual([
      'settings.json.1700000000000-1.tmp',
      'settings.json.1700000001000-2.tmp'
    ])
  })

  // Pass-to-pass regression: pre-existing recovery behaviour is preserved —
  // a syntactically corrupt committed primary still fails and is not masked by
  // a valid temp, and a plain supported-version document round-trips through
  // read / mutate / write.
  it('preserves pre-existing recovery behavior (corrupt primary not masked; supported doc round-trips)', async () => {
    const corruptRoot = await makeRoot()
    const corruptPath = join(corruptRoot, 'settings.json')
    const corruptTempPath = `${corruptPath}.1700000000000-1.tmp`
    await writeFile(corruptPath, '{', 'utf8')
    await writeFile(corruptTempPath, '{"source":"temp"}\n', 'utf8')

    await expect(readDurableJsonFile(corruptPath, JSON.parse)).rejects.toBeInstanceOf(SyntaxError)
    await expect(readdir(corruptRoot)).resolves.toEqual([
      'settings.json',
      'settings.json.1700000000000-1.tmp'
    ])

    const roundTripRoot = await makeRoot()
    await writeFile(
      join(roundTripRoot, 'settings.json'),
      `${JSON.stringify({ version: SETTINGS_FILE_VERSION, providers: [] })}\n`,
      'utf8'
    )
    const store = new SettingsDocumentStore(roundTripRoot)
    await expect(store.read()).resolves.toMatchObject({ version: SETTINGS_FILE_VERSION, providers: [] })
    await expect(
      store.mutate((settings) => ({ ...settings, notificationsEnabled: false }))
    ).resolves.toMatchObject({ providers: [], notificationsEnabled: false })

    // A recognised temp this build CAN decode, sitting beside a valid primary,
    // is still swept away as crash residue. This rejects a blunt over-correction
    // that preserves every leftover temp without inspection; only a temp the
    // build cannot interpret may survive.
    const cleanupRoot = await makeRoot()
    const cleanupPrimary = join(cleanupRoot, 'settings.json')
    const cleanupTemp = `${cleanupPrimary}.1700000000000-1.tmp`
    await writeFile(cleanupPrimary, '{"source":"primary"}\n', 'utf8')
    await writeFile(cleanupTemp, '{"source":"temp"}\n', 'utf8')
    await expect(readDurableJsonFile(cleanupPrimary, JSON.parse)).resolves.toEqual({
      status: 'found',
      value: { source: 'primary' }
    })
    await expect(readdir(cleanupRoot)).resolves.toEqual(['settings.json'])
  })
})
