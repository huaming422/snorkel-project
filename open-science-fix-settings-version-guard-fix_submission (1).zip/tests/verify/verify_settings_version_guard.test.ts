// Exercises SettingsDocumentStore read()/mutate() on settings.json and the
// durable JSON reader's handling of leftover temp files. Assertions look only
// at resolve/reject outcomes and the bytes left on disk.

import { mkdtemp, readFile, readdir, utimes, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { afterEach, describe, expect, it, vi } from 'vitest'

import { SETTINGS_FILE_VERSION } from '../../shared/settings'
import { SettingsDocumentStore } from './document-store'
import {
  DurableJsonRecoveryBarrierError,
  readDurableJsonFile
} from '../storage/durable-json-file'

// A version strictly greater than what this build supports — "a document a
// newer build wrote." Derived from the repo-stable constant, not hardcoded.
const FUTURE_VERSION = SETTINGS_FILE_VERSION + 1

const roots: string[] = []

afterEach(async () => {
  const { rm } = await import('node:fs/promises')
  await Promise.all(roots.splice(0).map((root) => rm(root, { force: true, recursive: true })))
  vi.clearAllMocks()
})

const makeRoot = async (): Promise<string> => {
  const root = await mkdtemp(join(tmpdir(), 'open-science-settings-guard-'))
  roots.push(root)
  return root
}

describe('settings version guard', () => {
  // Mutating a future-version document rejects, the update callback never
  // runs, and the on-disk bytes are left exactly as they were.
  it('rejects mutation of a future settings document without overwriting its fields', async () => {
    const root = await makeRoot()
    const settingsPath = join(root, 'settings.json')
    const futureContents = `${JSON.stringify({
      version: FUTURE_VERSION,
      providers: [],
      futurePreference: 'must-survive'
    })}\n`
    await writeFile(settingsPath, futureContents, 'utf8')

    const store = new SettingsDocumentStore(root)
    const update = vi.fn((settings) => ({ ...settings, notificationsEnabled: false }))

    await expect(store.mutate(update)).rejects.toThrow()
    expect(update).not.toHaveBeenCalled()
    await expect(readFile(settingsPath, 'utf8')).resolves.toBe(futureContents)
  })

  // Reading a future-version document rejects and does not modify the file.
  it('rejects reading a future settings document and leaves it untouched', async () => {
    const root = await makeRoot()
    const settingsPath = join(root, 'settings.json')
    const futureContents = `${JSON.stringify({
      version: FUTURE_VERSION,
      providers: [],
      futurePreference: 'must-survive'
    })}\n`
    await writeFile(settingsPath, futureContents, 'utf8')

    await expect(new SettingsDocumentStore(root).read()).rejects.toThrow()
    await expect(readFile(settingsPath, 'utf8')).resolves.toBe(futureContents)
  })

  // A released version-1 document reads back at the supported version and
  // keeps its active provider and active model.
  it.each([
    [
      'a later version with only known fields',
      { version: FUTURE_VERSION + 1, providers: [], notificationsEnabled: true }
    ],
    [
      'new data inside a provider entry',
      {
        version: FUTURE_VERSION,
        providers: [
          {
            id: 'provider-1',
            type: 'custom',
            name: 'Provider',
            model: 'model-1',
            futureProviderSetting: 'must-survive'
          }
        ],
        activeProviderId: 'provider-1'
      }
    ]
  ])('refuses a newer settings document with %s', async (_label, document) => {
    const root = await makeRoot()
    const settingsPath = join(root, 'settings.json')
    const contents = `${JSON.stringify(document)}\n`
    await writeFile(settingsPath, contents, 'utf8')

    const store = new SettingsDocumentStore(root)
    const update = vi.fn((settings) => ({ ...settings, notificationsEnabled: false }))

    await expect(store.read()).rejects.toThrow()
    await expect(store.mutate(update)).rejects.toThrow()
    expect(update).not.toHaveBeenCalled()
    await expect(readFile(settingsPath, 'utf8')).resolves.toBe(contents)
  })

  it('migrates a version 1 document forward keeping active provider and model', async () => {
    const root = await makeRoot()
    await writeFile(
      join(root, 'settings.json'),
      JSON.stringify({
        version: 1,
        providers: [{ id: 'provider-1', type: 'custom', name: 'Provider', model: 'model-1' }],
        activeProviderId: 'provider-1'
      }),
      'utf8'
    )

    await expect(new SettingsDocumentStore(root).read()).resolves.toMatchObject({
      version: SETTINGS_FILE_VERSION,
      activeProviderId: 'provider-1',
      activeModel: 'model-1'
    })
  })

  it('keeps a future settings leftover when the settings file itself is missing', async () => {
    const root = await makeRoot()
    const temporaryName = 'settings.json.1700000000000-1.tmp'
    const futureContents = `${JSON.stringify({
      version: FUTURE_VERSION,
      providers: [],
      futurePreference: 'must-survive'
    })}\n`
    await writeFile(join(root, temporaryName), futureContents, 'utf8')

    await expect(new SettingsDocumentStore(root).read()).rejects.toThrow()
    await expect(readFile(join(root, temporaryName), 'utf8')).resolves.toBe(futureContents)
    expect(await readdir(root)).toEqual([temporaryName])
  })

  it('keeps a future settings leftover sitting beside an older settings file', async () => {
    const root = await makeRoot()
    const settingsPath = join(root, 'settings.json')
    const temporaryPath = `${settingsPath}.1700000000000-1.tmp`
    const primaryContents = `${JSON.stringify({ version: SETTINGS_FILE_VERSION, providers: [] })}\n`
    const futureContents = `${JSON.stringify({
      version: FUTURE_VERSION,
      providers: [],
      futurePreference: 'must-survive'
    })}\n`
    await writeFile(settingsPath, primaryContents, 'utf8')
    await writeFile(temporaryPath, futureContents, 'utf8')

    await new SettingsDocumentStore(root).read().then(
      () => undefined,
      () => undefined
    )

    await expect(readFile(settingsPath, 'utf8')).resolves.toBe(primaryContents)
    await expect(readFile(temporaryPath, 'utf8')).resolves.toBe(futureContents)
  })

  // Throws the recovery barrier for a document newer than this build supports.
  const barrierDecode = (contents: string): { version: number } => {
    const value = JSON.parse(contents) as { version: number }
    if (value.version > SETTINGS_FILE_VERSION) {
      throw new DurableJsonRecoveryBarrierError('newer than supported')
    }
    return value
  }

  // A future-version temp beside a valid primary must survive the read
  // unchanged; the read itself may resolve or reject.
  it('preserves a future recovery-barrier temp beside a valid primary', async () => {
    const root = await makeRoot()
    const filePath = join(root, 'settings.json')
    const temporaryPath = `${filePath}.1700000000000-1.tmp`
    const primaryContents = '{"version":2}\n'
    const futureContents = '{"version":3}\n'
    await writeFile(filePath, primaryContents, 'utf8')
    await writeFile(temporaryPath, futureContents, 'utf8')

    await readDurableJsonFile(filePath, barrierDecode).then(
      () => undefined,
      () => undefined
    )

    await expect(readFile(filePath, 'utf8')).resolves.toBe(primaryContents)
    await expect(readFile(temporaryPath, 'utf8')).resolves.toBe(futureContents)
  })

  // With no primary, a future-version temp must survive the read unchanged
  // even when a newer temp this build can decode is also present; the read
  // may resolve or reject.
  it('preserves a future recovery-barrier temp that sorts behind a decodable temp', async () => {
    const root = await makeRoot()
    const filePath = join(root, 'settings.json')
    const currentTemporaryPath = `${filePath}.1700000001000-2.tmp`
    const futureTemporaryPath = `${filePath}.1700000000000-1.tmp`
    const currentContents = '{"version":2}\n'
    const futureContents = '{"version":3}\n'
    await writeFile(currentTemporaryPath, currentContents, 'utf8')
    await writeFile(futureTemporaryPath, futureContents, 'utf8')
    const now = new Date()
    await utimes(futureTemporaryPath, new Date(now.getTime() - 2_000), new Date(now.getTime() - 2_000))
    await utimes(currentTemporaryPath, new Date(now.getTime() - 1_000), new Date(now.getTime() - 1_000))

    await readDurableJsonFile(filePath, barrierDecode).then(
      () => undefined,
      () => undefined
    )

    await expect(readFile(futureTemporaryPath, 'utf8')).resolves.toBe(futureContents)
    if ((await readdir(root)).includes('settings.json')) {
      await expect(readFile(filePath, 'utf8')).resolves.toBe(currentContents)
    }
  })

  // A syntactically corrupt primary still fails and is not masked by a valid
  // temp, and a supported-version document round-trips through read / mutate.
  it('preserves pre-existing recovery behavior (corrupt primary not masked; supported doc round-trips)', async () => {
    const corruptRoot = await makeRoot()
    const corruptPath = join(corruptRoot, 'settings.json')
    const corruptTempPath = `${corruptPath}.1700000000000-1.tmp`
    await writeFile(corruptPath, '{', 'utf8')
    await writeFile(corruptTempPath, '{"source":"temp"}\n', 'utf8')

    await expect(readDurableJsonFile(corruptPath, JSON.parse)).rejects.toBeInstanceOf(SyntaxError)
    await expect(readdir(corruptRoot)).resolves.toEqual([
      'settings.json',
      'settings.json.1700000000000-1.tmp'
    ])

    const roundTripRoot = await makeRoot()
    await writeFile(
      join(roundTripRoot, 'settings.json'),
      `${JSON.stringify({ version: SETTINGS_FILE_VERSION, providers: [] })}\n`,
      'utf8'
    )
    const store = new SettingsDocumentStore(roundTripRoot)
    await expect(store.read()).resolves.toMatchObject({ version: SETTINGS_FILE_VERSION, providers: [] })
    await expect(
      store.mutate((settings) => ({ ...settings, notificationsEnabled: false }))
    ).resolves.toMatchObject({ providers: [], notificationsEnabled: false })

    // A recognised temp this build can decode, beside a valid primary, is still
    // removed as crash residue.
    const cleanupRoot = await makeRoot()
    const cleanupPrimary = join(cleanupRoot, 'settings.json')
    const cleanupTemp = `${cleanupPrimary}.1700000000000-1.tmp`
    await writeFile(cleanupPrimary, '{"source":"primary"}\n', 'utf8')
    await writeFile(cleanupTemp, '{"source":"temp"}\n', 'utf8')
    await expect(readDurableJsonFile(cleanupPrimary, JSON.parse)).resolves.toEqual({
      status: 'found',
      value: { source: 'primary' }
    })
    await expect(readdir(cleanupRoot)).resolves.toEqual(['settings.json'])
  })
})
