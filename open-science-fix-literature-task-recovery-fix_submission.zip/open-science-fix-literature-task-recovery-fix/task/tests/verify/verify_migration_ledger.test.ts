import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import type { PrismaClient } from '@prisma/client'
import { afterEach, describe, expect, it } from 'vitest'

import { literatureItemInputSchema } from '../../shared/literature'
import {
  MIGRATION_MANIFEST,
  checksumMigrationPayload,
  migrateApplicationDatabase,
  verifyCurrentApplicationSchema
} from '../database/migration-service'
import { RUNTIME_SCHEMA_TABLES } from '../database/generated/runtime-schema'
import { createProjectDbClient } from '../projects/prisma-client'
import { LiteratureCatalog } from './catalog'

// The migration-ledger behavior is checked for INTERNAL consistency and backward compatibility
// only: a freshly migrated database records a ledger that matches the in-code manifest, each
// manifest entry's recorded checksum re-derives from its own snapshot, verifyCurrentApplicationSchema
// resolves, the manifest registers at least one migration beyond the frozen base set, and re-running
// migrations over a populated database preserves its existing data. No checksum literal, migration
// id, or solution-chosen table/column name is hardcoded; the schema change is required only to be
// additive and backward-compatible, not to take any particular physical shape.

// The migration ids present at the base revision. A solution must register at least one migration
// beyond this set (whatever its physical shape — a new table, an additive column, or otherwise),
// discovered by difference so no solution-chosen migration id is hardcoded.
const BASE_MIGRATION_IDS = new Set<string>([
  '0001_runtime_schema_baseline',
  '0002_project_agent_context',
  '0003_granted_local_roots',
  '0004_review_assessment_snapshots',
  '0005_project_preview_state_owner_fk',
  '0006_database_domain_constraints',
  '0007_notification_attention_metadata',
  '0008_database_json_constraints',
  '0009_vision_evidence',
  '0010_compute_password_auth',
  '0011_cross_resource_tags',
  '0012_tag_ordering',
  '0013_session_projection',
  '0014_review_query_indexes',
  '0015_session_model_call_usage',
  '0016_compute_job_sensitive_data_encryption',
  '0017_agent_memory_project_scope',
  '0018_session_auxiliary_turn_usage',
  '0019_session_usage_attribution',
  '0020_compute_job_analysis_state',
  '0021_compute_job_analysis_constraints',
  '0022_memory_global_content_unique',
  '0023_compute_job_operation',
  '0024_compute_job_file_evidence',
  '0025_managed_file_version_foundation',
  '0026_compute_job_remote_cleanup',
  '0027_project_session_defaults',
  '0028_database_numeric_and_null_constraints',
  '0029_compute_host_execution_mode',
  '0030_literature_foundation',
  '0031_project_archive_revision',
  '0032_permission_approval_summary',
  '0033_compute_job_harvest_retry',
  '0034_background_result_delivery',
  '0035_literature_pdf_provenance',
  '0036_content_verification_observation',
  '0037_literature_inbox_integrity',
  '0038_literature_search_text'
])

// The reference tables present at the base revision. If a solution DOES add a new table, it is
// discovered by difference here so the conditional owner-FK check can run without naming it; a
// solution that instead extends an existing table additively adds nothing to this set and is not
// required to introduce a new table.
const BASE_REFERENCE_TABLES = new Set<string>([
  'Project',
  'SessionNumberSequence',
  'Session',
  'SessionProjectionState',
  'PendingSessionReconciliation',
  'SessionTurnUsage',
  'SessionModelCallUsage',
  'SessionAuxiliaryTurnUsage',
  'SessionRun',
  'SessionArtifactRef',
  'PermissionGrant',
  'PermissionGrantSeed',
  'ProjectPreviewState',
  'UnreadTaskSession',
  'NotificationInboxItem',
  'Review',
  'Finding',
  'ProjectDeletionIntent',
  'ManagedFile',
  'ManagedFileSessionSync',
  'FileOriginSession',
  'ArtifactLineage',
  'UploadFile',
  'ContentBlob',
  'LiteratureItem',
  'LiteratureAttachment',
  'LiteratureAttachmentVersion',
  'LiteratureCreator',
  'LiteratureItemCreator',
  'LiteratureIdentifier',
  'LiteratureInboxCandidate',
  'LiteratureCandidateDiscovery',
  'LiteratureInboxPdf',
  'LiteratureSourceRecord',
  'LiteratureCollection',
  'LiteratureCollectionItem',
  'ProjectLiterature',
  'UploadVersion',
  'VisionEvidence',
  'ArtifactMessageSnapshot',
  'ArtifactVersion',
  'ArtifactLiteratureManifest',
  'ManagedFileVersionWriteOperation',
  'ArtifactVersionInput',
  'ReviewFindingDisposition',
  'ReviewScopeSnapshot',
  'ComputeJob',
  'ComputeJobOperation',
  'ComputeHost',
  'ComputeCredential',
  'ComputeAuthOperation',
  'GrantedLocalRoot',
  'Tag',
  'TagAssignment',
  'MemorySettings',
  'MemoryCategory',
  'MemoryEntry',
  'BackgroundResultDelivery'
])

type ManifestEntry = {
  id: string
  checksum: string
  statements: readonly string[]
  verifiers: Parameters<typeof checksumMigrationPayload>[2]
  operations?: Parameters<typeof checksumMigrationPayload>[3]
}

describe('Application migration ledger consistency', () => {
  let storageRoot: string | undefined
  let client: PrismaClient | undefined

  afterEach(async () => {
    await client?.$disconnect()
    if (storageRoot) await rm(storageRoot, { recursive: true, force: true })
  })

  const migrate = async (): Promise<PrismaClient> => {
    storageRoot = await mkdtemp(join(tmpdir(), 'literature-ledger-'))
    client = createProjectDbClient(storageRoot)
    await migrateApplicationDatabase(client)
    return client
  }

  // Each manifest entry's recorded checksum must equal the checksum recomputed from its own
  // immutable snapshot (the entry's id, statements, schema-check descriptors, and operations).
  // This catches a migration whose registered checksum drifted from its snapshot — without ever
  // naming a checksum value.
  it('records manifest checksums that re-derive from each migration snapshot', () => {
    for (const entry of MIGRATION_MANIFEST as readonly ManifestEntry[]) {
      const recomputed = checksumMigrationPayload(
        entry.id,
        entry.statements,
        entry.verifiers,
        entry.operations ?? []
      )
      expect(recomputed, `checksum for ${entry.id}`).toBe(entry.checksum)
    }
  })

  // A freshly migrated database records a ledger whose (id, checksum) rows match the in-code
  // manifest exactly and in order — proving schema/registration/ledger stay consistent.
  it('writes a ledger that matches the in-code migration manifest', async () => {
    const db = await migrate()
    const rows = await db.$queryRawUnsafe<Array<{ id: string; checksum: string }>>(
      'SELECT "id", "checksum" FROM "_open_science_migrations" ORDER BY "id"'
    )
    const manifest = (MIGRATION_MANIFEST as readonly ManifestEntry[]).map((entry) => ({
      id: entry.id,
      checksum: entry.checksum
    }))
    const sortedManifest = [...manifest].sort((a, b) => a.id.localeCompare(b.id))
    expect(rows).toEqual(sortedManifest)
  })

  // verifyCurrentApplicationSchema — which checks the runtime schema including the newly added
  // reference table — resolves on a freshly migrated database.
  it('passes the current runtime schema verification after migrating', async () => {
    const db = await migrate()
    await expect(verifyCurrentApplicationSchema(db)).resolves.toBeUndefined()
  })

  // The persistence change is additive: at least one migration is registered beyond the frozen base
  // set. This is required of any valid shape (a new table OR an additive column on an existing
  // table), and it is what distinguishes a real schema change from leaving the schema untouched.
  it('registers an additive migration beyond the base manifest', async () => {
    const addedMigrations = (MIGRATION_MANIFEST as readonly ManifestEntry[])
      .map((entry) => entry.id)
      .filter((id) => !BASE_MIGRATION_IDS.has(id))
    expect(
      addedMigrations.length,
      'at least one migration beyond the base manifest should be registered'
    ).toBeGreaterThanOrEqual(1)
  })

  // Backward compatibility: re-running migrations over a database already populated with field data
  // (the app-restart path) preserves that data and leaves the runtime schema verifiable. This is the
  // behavioral form of "additive and backward-compatible with databases already in the field": a
  // destructive or data-losing schema change fails here regardless of its physical shape.
  it('preserves existing field data when migrations are re-applied to a populated database', async () => {
    const db = await migrate()
    const catalog = new LiteratureCatalog(async () => db)
    await db.project.create({ data: { id: 'migration-ledger-project', name: 'Field' } })
    const seeded = await catalog.transact({
      kind: 'create-item',
      item: literatureItemInputSchema.parse({
        itemType: 'journalArticle',
        title: 'Field reference',
        identifiers: [{ scheme: 'doi', value: '10.9999/field' }]
      })
    })
    const before = (await catalog.get(seeded.id))!
    const itemsBefore = await db.literatureItem.count()

    // Re-apply the full manifest, exactly as a restart would.
    await migrateApplicationDatabase(db)

    expect(await db.literatureItem.count()).toBe(itemsBefore)
    expect(await catalog.get(seeded.id)).toEqual(before)
    await expect(verifyCurrentApplicationSchema(db)).resolves.toBeUndefined()
  })

  // Conditional guard: IF a solution adds a new reference table (discovered by difference, never
  // named), that table must carry a cascading foreign key to its owning reference — so deleting a
  // reference removes its dependent rows and the new table cannot orphan data. A solution that
  // extends an existing table instead adds no new table and skips this guard.
  it('gives any newly added reference table a cascading owner foreign key', async () => {
    const db = await migrate()
    const addedTable = [...RUNTIME_SCHEMA_TABLES].find((table) => !BASE_REFERENCE_TABLES.has(table))
    if (!addedTable) return

    const present = await db.$queryRawUnsafe<Array<{ name: string }>>(
      `SELECT "name" FROM "sqlite_schema" WHERE "type" = 'table' AND "name" = '${addedTable}'`
    )
    expect(present).toHaveLength(1)

    const foreignKeys = await db.$queryRawUnsafe<
      Array<{ table: string; from: string; to: string; on_delete: string }>
    >(`PRAGMA foreign_key_list('${addedTable}')`)
    const ownerFk = foreignKeys.find((fk) => fk.table === 'LiteratureItem')
    expect(ownerFk, 'a foreign key to the owning reference table').toBeTruthy()
    expect(ownerFk!.on_delete).toBe('CASCADE')
  })
})
