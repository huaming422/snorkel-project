import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import type { PrismaClient } from '@prisma/client'
import { afterEach, describe, expect, it, vi } from 'vitest'

import {
  literatureItemInputSchema,
  type LiteratureItemView,
  type LiteratureMetadataCompletionResult
} from '../../shared/literature'
import { migrateApplicationDatabase } from '../database/migration-service'
import { createProjectDbClient } from '../projects/prisma-client'
import { LiteratureCatalog } from './catalog'
import { LiteratureMetadataEnricher } from './metadata-enricher'

// Metadata-commit idempotency is observed only through the pre-existing public surface:
// LiteratureCatalog (real SQLite via createProjectDbClient + migrateApplicationDatabase) and
// LiteratureMetadataEnricher.applyReviewed(). applyReviewed internally derives the per-operation
// identity and threads it to the catalog, so these tests never reference any identity encoding,
// commit-evidence lookup, or storage shape by name — a fix that records its evidence in a new
// table, an additive column, or a raw write, and that reconciles in the catalog vs the enricher,
// is accepted.

// The writes Prisma can emit for a reference update. The atomicity probe counts these on a known-
// good apply and then fails the final one on a replay, which is the mechanism-agnostic way to ask
// "is the evidence part of the same durable write as the reference change?" without naming where
// the evidence lives.
const WRITE_OPERATIONS = new Set<string>([
  'create',
  'createMany',
  'createManyAndReturn',
  'update',
  'updateMany',
  'updateManyAndReturn',
  'upsert',
  'delete',
  'deleteMany',
  'executeRaw',
  'executeRawUnsafe',
  '$executeRaw',
  '$executeRawUnsafe'
])

// A content fingerprint of every application row, so a leaked change in ANY store (the reference,
// its source provenance, or whatever evidence the solution writes) is visible without naming a
// table. Prisma returns INTEGER columns as BigInt over raw SQL, so serialize those as strings.
const fingerprintDatabase = async (client: PrismaClient): Promise<string> => {
  const tables = await client.$queryRawUnsafe<Array<{ name: string }>>(
    "SELECT name FROM sqlite_schema WHERE type = 'table' " +
      "AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '_prisma_%' ORDER BY name"
  )
  const parts: string[] = []
  for (const { name } of tables) {
    const rows = await client.$queryRawUnsafe<Array<Record<string, unknown>>>(`SELECT * FROM "${name}"`)
    const serialized = rows
      .map((row) => JSON.stringify(row, (_key, value) => (typeof value === 'bigint' ? value.toString() : value)))
      .sort()
      .join('|')
    parts.push(`${name}=${rows.length}:${serialized}`)
  }
  return parts.join('\n')
}

const itemView = (view: LiteratureItemView): LiteratureItemView => structuredClone(view)

// Build a reviewed-metadata snapshot carrying its own review token, exactly as a renderer-driven
// review would. applyReviewed re-derives the merged item from source.rawMetadata, so the token is
// the only field load-bearing for operation identity.
const review = (
  current: LiteratureItemView,
  token: string
): LiteratureMetadataCompletionResult => ({
  mode: 'preview',
  reviewVersion: 1,
  provider: 'crossref',
  sourceUrl: 'https://crossref.org',
  item: itemView(current),
  filled: [],
  conflicts: [],
  reviewToken: token,
  source: {
    provider: 'crossref',
    externalId: '10.1234/example',
    sourceUrl: 'https://crossref.org',
    rawMetadata: { DOI: '10.1234/example', 'container-title': ['Committed journal'] }
  }
})

const seedItem = literatureItemInputSchema.parse({
  itemType: 'journalArticle',
  title: 'Original title',
  identifiers: [{ scheme: 'doi', value: '10.1234/example' }]
})

describe('Literature metadata commit idempotency', () => {
  let storageRoot: string | undefined
  let client: PrismaClient | undefined

  afterEach(async () => {
    await client?.$disconnect()
    if (storageRoot) await rm(storageRoot, { recursive: true, force: true })
  })

  const setup = async (): Promise<{ catalog: LiteratureCatalog; enricher: LiteratureMetadataEnricher }> => {
    storageRoot = await mkdtemp(join(tmpdir(), 'literature-receipt-'))
    client = createProjectDbClient(storageRoot)
    await migrateApplicationDatabase(client)
    await client.project.create({ data: { id: 'project-1', name: 'Research' } })
    const catalog = new LiteratureCatalog(async () => client!)
    const enricher = new LiteratureMetadataEnricher(
      catalog,
      vi.fn(async () => {
        throw new Error('network should not be used')
      }) as unknown as typeof fetch
    )
    return { catalog, enricher }
  }

  // Criterion 5 — replaying an already-committed operation (same review token, nothing else
  // touched the reference) returns success instead of a false version conflict, and does not
  // re-apply the metadata.
  it('reports success when replaying a metadata operation that already committed', async () => {
    const { catalog, enricher } = await setup()
    const created = await catalog.transact({ kind: 'create-item', item: seedItem })
    const before = (await catalog.get(created.id))!

    const snapshot = review(before, 'replay-operation')
    const first = await enricher.applyReviewed(snapshot, [])
    expect(first.mode).toBe('commit')

    const committed = (await catalog.get(created.id))!
    expect(committed.metadataRevision).toBeGreaterThan(before.metadataRevision)

    // Replay the identical operation; the reference is already at (or past) the committed state.
    const replay = await enricher.applyReviewed(snapshot, [])
    expect(replay.mode).toBe('commit')

    // No duplicate re-application: the reference is byte-for-byte what the first commit produced.
    const afterReplay = (await catalog.get(created.id))!
    expect(afterReplay.metadataRevision).toBe(committed.metadataRevision)
    expect(afterReplay.item.containerTitle).toBe(committed.item.containerTitle)
  })

  // Criterion 6 — an unrelated operation whose expected revision is stale and for which no prior
  // commit reconciles still conflicts. Making replay idempotent must not weaken this guard.
  it('still conflicts on a stale unrelated operation with no reconciling prior commit', async () => {
    const { catalog, enricher } = await setup()
    const created = await catalog.transact({ kind: 'create-item', item: seedItem })
    const before = (await catalog.get(created.id))!

    // Advance the reference out from under the review via an unrelated edit.
    await catalog.transact({
      kind: 'update-item',
      itemId: created.id,
      expectedMetadataRevision: before.metadataRevision,
      item: { ...before.item, title: 'Moved on' }
    })
    const current = (await catalog.get(created.id))!
    expect(current.metadataRevision).toBeGreaterThan(before.metadataRevision)

    // The review still carries the pre-edit revision and a fresh, never-committed token.
    const stale = review(before, 'unrelated-operation')
    await expect(enricher.applyReviewed(stale, [])).rejects.toThrow('Reference changed')
  })

  // Criterion 7 — the commit evidence is written in the same durable database write as the
  // reference metadata and its source provenance: if recording that evidence fails, the reference
  // change and the source record roll back with it (no committed metadata whose success went
  // unrecorded, no orphan source). This is probed without naming where the evidence lives: a
  // known-good apply establishes how many writes a successful commit emits, then a fresh apply is
  // interrupted at its FINAL write and the whole database is asserted unchanged. A solution that
  // records evidence atomically (last-in-transaction, in any store) rolls everything back; one that
  // records it in a later, separate write leaves the reference committed and fails here.
  it('rolls back the metadata change and its source when the commit evidence cannot be written', async () => {
    const { catalog } = await setup()
    const net = (): typeof fetch =>
      vi.fn(async () => {
        throw new Error('network should not be used')
      }) as unknown as typeof fetch

    // Discovery: a successful apply on one reference, counting the writes it emits.
    const discovery = await catalog.transact({ kind: 'create-item', item: seedItem })
    const discoveryBefore = (await catalog.get(discovery.id))!
    let writeCount = 0
    const counting = client!.$extends({
      query: {
        $allOperations({ operation, args, query }) {
          if (WRITE_OPERATIONS.has(operation)) writeCount += 1
          return query(args)
        }
      }
    })
    await new LiteratureMetadataEnricher(
      new LiteratureCatalog(async () => counting as unknown as PrismaClient),
      net()
    ).applyReviewed(review(discoveryBefore, 'discovery-operation'), [])
    const writesPerCommit = writeCount
    expect(writesPerCommit, 'a successful commit should emit at least one write').toBeGreaterThan(0)

    // Injection: a fresh reference, with the final write of its apply forced to fail. The evidence
    // write is the last thing a correct solution does inside the commit, so failing the final write
    // exercises the rollback boundary regardless of the evidence's storage shape.
    const target = await catalog.transact({ kind: 'create-item', item: seedItem })
    const targetBefore = (await catalog.get(target.id))!
    const fingerprintBefore = await fingerprintDatabase(client!)

    let seen = 0
    const failing = client!.$extends({
      query: {
        $allOperations({ operation, args, query }) {
          if (WRITE_OPERATIONS.has(operation)) {
            seen += 1
            if (seen === writesPerCommit) throw new Error('Commit evidence storage unavailable')
          }
          return query(args)
        }
      }
    })
    await expect(
      new LiteratureMetadataEnricher(
        new LiteratureCatalog(async () => failing as unknown as PrismaClient),
        net()
      ).applyReviewed(review(targetBefore, 'interrupted-operation'), [])
    ).rejects.toThrow()

    // Everything rolled back together: the reference is byte-for-byte unchanged and no new row
    // leaked into any store (no orphan source, no committed-without-evidence reference).
    expect(await catalog.get(targetBefore.id)).toEqual(targetBefore)
    expect(await fingerprintDatabase(client!)).toBe(fingerprintBefore)
  })
})
