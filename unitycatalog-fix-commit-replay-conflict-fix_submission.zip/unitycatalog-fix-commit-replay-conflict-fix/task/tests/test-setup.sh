#!/usr/bin/env bash
# test-setup.sh — prepares the repository for the graded test run.
#
# Runs with network available in normal use, but is written OFFLINE-FIRST so it
# also succeeds with networking disabled. The image already carries the full
# base + change-set dependency closure: the repo is cloned and rewound to the
# base commit, the sbt/coursier caches are warm from a base `Test/compile`, and
# the shared tooling virtualenv lives in /opt/tooling. Nothing here needs to
# reach the network.
#
# Responsibility: pin every package manager to offline mode so nothing in the
# graded run accidentally reaches the network. The behavioral test sources are
# staged into the sbt test tree by verify.sh itself at run time (it is the owner
# of its own sources and of the must-actually-run guard), so there is nothing to
# copy here.
#
# The repo lives at /repo/unitycatalog (see image/Dockerfile); the shell runner's
# cwd at grade time is /repo/unitycatalog.
set -euo pipefail

# --- Offline switches (belt-and-suspenders; the closure is already baked) ---
export UV_OFFLINE=1
export UV_NO_CACHE=0
export PIP_NO_INDEX=1
# sbt / coursier: resolve only from the warm local caches baked into the image.
export COURSIER_MODE="${COURSIER_MODE:-offline}"
export SBT_OPTS="${SBT_OPTS:-} -Dsbt.offline=true"

echo "test-setup: done (offline-ready)"
