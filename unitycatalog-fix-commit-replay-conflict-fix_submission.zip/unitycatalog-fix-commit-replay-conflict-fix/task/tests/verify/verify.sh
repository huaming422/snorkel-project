#!/usr/bin/env bash
# Entry point for the shell runner. Builds and runs the focused server-side suites that exercise
# the already-taken-version decision through the two public endpoints, fully offline against the
# dependency closure baked into the image. Exit 0 iff every selected case is actually executed and
# passes.
#
# This script is self-contained: it stages its own co-located JUnit sources into the server module's
# test tree (the sbt build only compiles sources under src/test), then runs them. It never assumes a
# separate setup step placed them, and it treats "zero cases executed" as a hard failure so a build
# that silently compiles no matching class can never be mistaken for a green run.
set -euo pipefail

REPO_DIR="/repo/unitycatalog"

# Directory holding this script and the JUnit sources shipped alongside it.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Fully-qualified classes to run, and the number of @Test cases we expect across them. The expected
# count is the guard: if the build compiles fewer (a source failed to stage, a class was renamed),
# the run fails instead of reporting a hollow success.
CLASSES=(
  "io.unitycatalog.server.sdk.deltacommits.PurgedCommitReplayRestTest"
  "io.unitycatalog.server.sdk.delta.PurgedCommitReplayDeltaTest"
)
EXPECTED_CASES=7

# --- Stage the shipped sources into the server module's Java test tree -------------------------
# sbt keys the compile layout off the on-disk directory, which must mirror each file's declared
# package. Copy is idempotent (cp -f), so running after any earlier staging step is harmless.
TEST_JAVA_ROOT="${REPO_DIR}/server/src/test/java"
staged=0
for src in "${SCRIPT_DIR}"/*.java; do
  [ -e "${src}" ] || continue
  pkg="$(grep -m1 -E '^[[:space:]]*package[[:space:]]+' "${src}" \
          | sed -E 's/^[[:space:]]*package[[:space:]]+([a-zA-Z0-9_.]+)[[:space:]]*;.*/\1/')"
  if [ -z "${pkg}" ]; then
    echo "verify: ${src} has no package declaration; cannot place it in the test tree" >&2
    exit 1
  fi
  dest_dir="${TEST_JAVA_ROOT}/$(echo "${pkg}" | tr '.' '/')"
  mkdir -p "${dest_dir}"
  cp -f "${src}" "${dest_dir}/"
  staged=$((staged + 1))
  echo "verify: staged $(basename "${src}") -> ${dest_dir}/"
done
if [ "${staged}" -eq 0 ]; then
  echo "verify: no JUnit sources found next to this script; nothing to run" >&2
  exit 1
fi

cd "$REPO_DIR"

# Keep the JVM build strictly offline; the image already warmed the Test/compile closure.
export SBT_OPTS="${SBT_OPTS:-} -Dsbt.offline=true"

# Run the focused suites, teeing the full build/test output so we can both surface it and inspect
# the sbt result summary for the number of cases that actually ran.
OUT_LOG="$(mktemp)"
set +e
build/sbt \
  -DsparkVersion=4.0.0 \
  -DdeltaVersion=4.3.1 \
  -J-Xmx4G \
  "set ThisBuild / offline := true" \
  "server/testOnly ${CLASSES[*]}" 2>&1 | tee "${OUT_LOG}"
sbt_status="${PIPESTATUS[0]}"
set -e

if [ "${sbt_status}" -ne 0 ]; then
  echo "verify: sbt exited non-zero (${sbt_status}); see output above" >&2
  rm -f "${OUT_LOG}"
  exit "${sbt_status}"
fi

# sbt's testing framework never fails a `testOnly` that matched zero classes, so a stale/misplaced
# source would otherwise read as success. Sum the per-suite result summaries and require that every
# expected case ran and that none failed or errored.
#
# Summary lines look like: "[info] Passed: Total 7, Failed 0, Errors 0, Passed 7".
if grep -qE "No tests to run" "${OUT_LOG}"; then
  echo "verify: sbt reported 'No tests to run' — the expected suites did not execute" >&2
  rm -f "${OUT_LOG}"
  exit 1
fi

totals="$(grep -oE "Passed: Total [0-9]+, Failed [0-9]+, Errors [0-9]+" "${OUT_LOG}" || true)"
if [ -z "${totals}" ]; then
  echo "verify: could not find an sbt test result summary; cannot confirm cases executed" >&2
  rm -f "${OUT_LOG}"
  exit 1
fi

sum_total=0
sum_failed=0
sum_errors=0
while IFS= read -r line; do
  [ -n "${line}" ] || continue
  t="$(echo "${line}" | sed -E 's/.*Total ([0-9]+).*/\1/')"
  f="$(echo "${line}" | sed -E 's/.*Failed ([0-9]+).*/\1/')"
  e="$(echo "${line}" | sed -E 's/.*Errors ([0-9]+).*/\1/')"
  sum_total=$((sum_total + t))
  sum_failed=$((sum_failed + f))
  sum_errors=$((sum_errors + e))
done <<< "${totals}"

rm -f "${OUT_LOG}"

echo "verify: executed ${sum_total} case(s), ${sum_failed} failed, ${sum_errors} errored (expected ${EXPECTED_CASES})"

if [ "${sum_failed}" -ne 0 ] || [ "${sum_errors}" -ne 0 ]; then
  echo "verify: one or more cases failed or errored" >&2
  exit 1
fi
if [ "${sum_total}" -ne "${EXPECTED_CASES}" ]; then
  echo "verify: expected ${EXPECTED_CASES} cases to run but ${sum_total} executed" >&2
  exit 1
fi

echo "verify: all ${sum_total} cases passed"
