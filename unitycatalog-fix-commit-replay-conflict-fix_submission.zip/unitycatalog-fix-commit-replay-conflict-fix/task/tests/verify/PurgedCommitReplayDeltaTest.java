package io.unitycatalog.server.sdk.delta;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import io.unitycatalog.client.ApiException;
import io.unitycatalog.client.delta.model.DeltaAddCommitUpdate;
import io.unitycatalog.client.delta.model.DeltaAssertEtag;
import io.unitycatalog.client.delta.model.DeltaAssertTableUUID;
import io.unitycatalog.client.delta.model.DeltaCommit;
import io.unitycatalog.client.delta.model.DeltaLoadTableResponse;
import io.unitycatalog.client.delta.model.DeltaSetLatestBackfilledVersionUpdate;
import io.unitycatalog.client.delta.model.DeltaStagingTableResponse;
import io.unitycatalog.client.delta.model.DeltaTableRequirement;
import io.unitycatalog.client.delta.model.DeltaTableUpdate;
import io.unitycatalog.client.delta.model.DeltaUpdateTableRequest;
import io.unitycatalog.server.base.ServerConfig;
import io.unitycatalog.server.base.catalog.CatalogOperations;
import io.unitycatalog.server.base.delta.DeltaBaseTableCRUDTestEnv;
import io.unitycatalog.server.base.schema.SchemaOperations;
import io.unitycatalog.server.sdk.catalog.SdkCatalogOperations;
import io.unitycatalog.server.sdk.schema.SdkSchemaOperations;
import io.unitycatalog.server.utils.TestUtils;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Behavior of the Delta update-table endpoint ({@code DeltaTablesApi.updateTable}) when a commit is
 * resent for a version that has already been backfilled and purged from the catalog's active
 * tracking. This is the second caller that reaches the already-taken-version decision; it must
 * agree with the coordinated-commit endpoint. Once purged, the version's original file name is no
 * longer tracked, so a safe resend can only be distinguished from a competing commit by comparing
 * the resent commit's file against the already-published commit for that version. The table lives
 * on a local {@code file://} location, and the published / staged commit files are placed by the
 * test (the catalog records commit rows but does not itself write those files).
 */
public class PurgedCommitReplayDeltaTest extends DeltaBaseTableCRUDTestEnv {

  @Override
  protected CatalogOperations createCatalogOperations(ServerConfig config) {
    return new SdkCatalogOperations(TestUtils.createApiClient(config));
  }

  @Override
  protected SchemaOperations createSchemaOperations(ServerConfig config) {
    return new SdkSchemaOperations(TestUtils.createApiClient(config));
  }

  // ---- driving helpers (same shape the endpoint's own suite uses) ----------

  private DeltaLoadTableResponse updateTable(Handle h, DeltaTableUpdate... updates)
      throws ApiException {
    DeltaUpdateTableRequest request = requestWith(h.tableId(), Optional.of(h.etag()), updates);
    return deltaTablesApi.updateTable(
        TestUtils.CATALOG_NAME, TestUtils.SCHEMA_NAME, h.name(), request);
  }

  private static DeltaUpdateTableRequest requestWith(
      UUID assertUuid, Optional<String> assertEtag, DeltaTableUpdate... updates) {
    List<DeltaTableRequirement> requirements = new ArrayList<>();
    requirements.add(new DeltaAssertTableUUID().uuid(assertUuid));
    assertEtag.ifPresent(etag -> requirements.add(new DeltaAssertEtag().etag(etag)));
    return new DeltaUpdateTableRequest().requirements(requirements).updates(List.of(updates));
  }

  private DeltaAddCommitUpdate addCommit(long version) {
    return new DeltaAddCommitUpdate()
        .commit(
            new DeltaCommit()
                .version(version)
                .timestamp(1700000000L + version)
                .fileName(String.format(Locale.ROOT, "%08d.json", version))
                .fileSize(1024L)
                .fileModificationTimestamp(1700000000L + version));
  }

  private String publishedRelPath(long version) {
    return String.format(Locale.ROOT, "_delta_log/%020d.json", version);
  }

  private String stagedRelPath(long version) {
    return String.format(Locale.ROOT, "_delta_log/_staged_commits/%08d.json", version);
  }

  private void writeTableFile(String storageLocation, String relativePath, byte[] content)
      throws IOException {
    Path path = Path.of(URI.create(storageLocation + "/" + relativePath));
    Files.createDirectories(path.getParent());
    Files.write(path, content);
  }

  private void deleteTablePath(String storageLocation, String relativePath) throws IOException {
    Files.delete(Path.of(URI.create(storageLocation + "/" + relativePath)));
  }

  private void createTableDir(String storageLocation, String relativePath) throws IOException {
    Files.createDirectories(Path.of(URI.create(storageLocation + "/" + relativePath)));
  }

  private static void assertHttpStatus(Executable executable, int expectedStatus) {
    ApiException ex = assertThrows(ApiException.class, executable);
    assertThat(ex.getCode())
        .as("unexpected HTTP status; body=%s", ex.getResponseBody())
        .isEqualTo(expectedStatus);
  }

  /**
   * Context record for the three content-based cases: the table handle pinned after backfill, its
   * storage location, and the already-committed v2 update object ready to be resent.
   */
  private record PurgedWorld(Handle h3, String loc, DeltaAddCommitUpdate commit2) {}

  /**
   * Stage + finalize a managed table, commit v1..v3, then backfill through v2 so that v1 and v2 are
   * purged from active tracking (leaving v3 as the latest). Returns the pinned handle, the storage
   * location, and the v2 commit object for resending.
   */
  private PurgedWorld drivePurgeOfV2(String tableName) throws ApiException {
    DeltaStagingTableResponse staging = createDeltaStaging(tableName);
    Handle h = createDeltaManaged(tableName, staging, Map.of());
    String loc = staging.getLocation();

    DeltaAddCommitUpdate commit2 = null;
    Handle cur = h;
    for (long v = 1; v <= 3; v++) {
      DeltaAddCommitUpdate commit = addCommit(v);
      if (v == 2) {
        commit2 = commit;
      }
      cur = cur.withEtag(updateTable(cur, commit).getMetadata().getEtag());
    }
    DeltaLoadTableResponse afterBackfill =
        updateTable(cur, new DeltaSetLatestBackfilledVersionUpdate().latestPublishedVersion(2L));
    Handle h3 = cur.withEtag(afterBackfill.getMetadata().getEtag());
    return new PurgedWorld(h3, loc, commit2);
  }

  // ---- cases --------------------------------------------------------------

  @Test
  public void purged_replay_identical_is_noop_success() throws Exception {
    PurgedWorld w = drivePurgeOfV2("tbl_replay_identical");
    byte[] content = "delta-commit-v2\n".getBytes(StandardCharsets.UTF_8);
    writeTableFile(w.loc(), publishedRelPath(2L), content);
    writeTableFile(w.loc(), stagedRelPath(2L), content);

    // Identical published and staged content: a safe resend, accepted as a no-op; version is
    // unchanged.
    DeltaLoadTableResponse replay = updateTable(w.h3(), w.commit2());
    assertThat(replay.getLatestTableVersion()).isEqualTo(3L);
  }

  @Test
  public void purged_conflict_differs_is_409() throws Exception {
    PurgedWorld w = drivePurgeOfV2("tbl_replay_conflict");
    writeTableFile(w.loc(), publishedRelPath(2L), "published\n".getBytes(StandardCharsets.UTF_8));
    writeTableFile(w.loc(), stagedRelPath(2L), "different\n".getBytes(StandardCharsets.UTF_8));

    // Staged content differs from what was already published: another writer won this version.
    assertHttpStatus(() -> updateTable(w.h3(), w.commit2()), 409);
  }

  @Test
  public void unreadable_commit_file_is_500_unknown() throws Exception {
    PurgedWorld w = drivePurgeOfV2("tbl_replay_unknown");
    writeTableFile(w.loc(), stagedRelPath(2L), "staged\n".getBytes(StandardCharsets.UTF_8));

    // The already-published commit for this version is absent, so the outcome cannot be determined;
    // it must be a retriable server error, never a false conflict.
    assertHttpStatus(() -> updateTable(w.h3(), w.commit2()), 500);

    // A published path that exists but cannot be read as a file (a directory stands in for a
    // non-not-found IO error) is equally undetermined: still a retriable server error.
    createTableDir(w.loc(), publishedRelPath(2L));
    assertHttpStatus(() -> updateTable(w.h3(), w.commit2()), 500);

    // Clean up the stand-in directory so the location is left in a consistent state.
    deleteTablePath(w.loc(), publishedRelPath(2L));
  }
}
