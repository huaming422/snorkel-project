package io.unitycatalog.server.sdk.deltacommits;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import io.unitycatalog.client.ApiException;
import io.unitycatalog.client.api.DeltaCommitsApi;
import io.unitycatalog.client.model.DeltaCommit;
import io.unitycatalog.client.model.DeltaCommitInfo;
import io.unitycatalog.client.model.DeltaCommitMetadataProperties;
import io.unitycatalog.client.model.DeltaGetCommits;
import io.unitycatalog.client.model.DeltaGetCommitsResponse;
import io.unitycatalog.client.model.DeltaMetadata;
import io.unitycatalog.client.model.TableInfo;
import io.unitycatalog.client.model.TableType;
import io.unitycatalog.server.base.ServerConfig;
import io.unitycatalog.server.base.catalog.CatalogOperations;
import io.unitycatalog.server.base.schema.SchemaOperations;
import io.unitycatalog.server.base.table.BaseTableCRUDTestEnv;
import io.unitycatalog.server.base.table.TableOperations;
import io.unitycatalog.server.sdk.catalog.SdkCatalogOperations;
import io.unitycatalog.server.sdk.schema.SdkSchemaOperations;
import io.unitycatalog.server.sdk.tables.SdkTableOperations;
import io.unitycatalog.server.service.delta.DeltaConsts.TableProperties;
import io.unitycatalog.server.utils.TestUtils;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Behavior of the coordinated-commit endpoint ({@code DeltaCommitsApi.commit}) when a commit is
 * resent for a version that has already been backfilled and purged from the catalog's active
 * tracking. Once purged, the version's original file name is no longer tracked, so a safe resend
 * can only be told apart from a competing commit by comparing the resent commit's file against the
 * already-published commit for that version. Everything is exercised through the stable SDK client;
 * the table lives on a local {@code file://} location, and the published / staged commit files are
 * placed by the test (the catalog records commit rows but does not itself write those files).
 */
public class PurgedCommitReplayRestTest extends BaseTableCRUDTestEnv {

  private DeltaCommitsApi deltaCommitsApi;
  private TableInfo tableInfo;

  @Override
  protected CatalogOperations createCatalogOperations(ServerConfig config) {
    return new SdkCatalogOperations(TestUtils.createApiClient(config));
  }

  @Override
  protected SchemaOperations createSchemaOperations(ServerConfig config) {
    return new SdkSchemaOperations(TestUtils.createApiClient(config));
  }

  @Override
  protected TableOperations createTableOperations(ServerConfig config) {
    return new SdkTableOperations(TestUtils.createApiClient(config));
  }

  @BeforeEach
  @Override
  public void setUp() {
    super.setUp();
    deltaCommitsApi = new DeltaCommitsApi(TestUtils.createApiClient(serverConfig));
    tableInfo =
        createTestingTable(
            TestUtils.TABLE_NAME, TableType.MANAGED, Optional.empty(), tableOperations);
  }

  // ---- fixtures -----------------------------------------------------------

  private DeltaMetadata metaWithTableId(String tableId) {
    return new DeltaMetadata()
        .properties(
            new DeltaCommitMetadataProperties()
                .properties(Map.of(TableProperties.UC_TABLE_ID, tableId)));
  }

  private DeltaCommit commitObject(long version) {
    long ts = 1700000000L + version;
    return new DeltaCommit()
        .tableId(tableInfo.getTableId())
        .tableUri(tableInfo.getStorageLocation())
        .commitInfo(
            new DeltaCommitInfo()
                .version(version)
                .fileName("file" + version)
                .fileSize(100L)
                .timestamp(ts)
                .fileModificationTimestamp(ts))
        .metadata(metaWithTableId(tableInfo.getTableId()));
  }

  private DeltaCommit backfillOnly(long latestBackfilledVersion) {
    return new DeltaCommit()
        .tableId(tableInfo.getTableId())
        .tableUri(tableInfo.getStorageLocation())
        .latestBackfilledVersion(latestBackfilledVersion);
  }

  /**
   * Commits v1..v4 then backfills through v4, which purges v2 and v3 from active tracking and keeps
   * v4 as the backfilled marker. The table's latest version is 4 afterwards. Returns the v2 commit
   * so callers can resend it.
   */
  private DeltaCommit drivePurgeOfV2AndV3() throws ApiException {
    DeltaCommit c2 = commitObject(2L);
    deltaCommitsApi.commit(commitObject(1L));
    deltaCommitsApi.commit(c2);
    deltaCommitsApi.commit(commitObject(3L));
    deltaCommitsApi.commit(commitObject(4L).latestBackfilledVersion(1L));
    deltaCommitsApi.commit(backfillOnly(4L));
    return c2;
  }

  private long latestTableVersion() throws ApiException {
    DeltaGetCommitsResponse resp =
        deltaCommitsApi.getCommits(
            new DeltaGetCommits()
                .tableId(tableInfo.getTableId())
                .tableUri(tableInfo.getStorageLocation())
                .startVersion(0L));
    return resp.getLatestTableVersion();
  }

  private String publishedRelPath(long version) {
    return String.format(Locale.ROOT, "_delta_log/%020d.json", version);
  }

  private void writeTableFile(String storageLocation, String relativePath, byte[] content)
      throws IOException {
    Path path = Path.of(URI.create(storageLocation + "/" + relativePath));
    Files.createDirectories(path.getParent());
    Files.write(path, content);
  }

  private static void assertHttpStatus(Executable executable, int expectedStatus) {
    ApiException ex = assertThrows(ApiException.class, executable);
    assertEquals(
        expectedStatus,
        ex.getCode(),
        "unexpected HTTP status; body=" + ex.getResponseBody());
  }

  // ---- cases --------------------------------------------------------------

  @Test
  public void purged_replay_identical_is_noop_success() throws Exception {
    DeltaCommit c2 = drivePurgeOfV2AndV3();
    String loc = tableInfo.getStorageLocation();
    byte[] content = "commit-body-v2\n".getBytes(StandardCharsets.UTF_8);
    writeTableFile(loc, publishedRelPath(2L), content);
    writeTableFile(loc, "_delta_log/_staged_commits/file2", content);

    // Identical published and staged content: a safe resend, so it succeeds as a no-op and the
    // table version is unchanged.
    deltaCommitsApi.commit(c2);
    assertEquals(4L, latestTableVersion());
  }

  @Test
  public void purged_conflict_differs_is_409() throws Exception {
    DeltaCommit c2 = drivePurgeOfV2AndV3();
    String loc = tableInfo.getStorageLocation();
    writeTableFile(
        loc, publishedRelPath(2L), "published-body-v2\n".getBytes(StandardCharsets.UTF_8));
    writeTableFile(
        loc,
        "_delta_log/_staged_commits/file2",
        "a-different-body\n".getBytes(StandardCharsets.UTF_8));

    // Staged content differs from what was already published: another writer won this version.
    assertHttpStatus(() -> deltaCommitsApi.commit(c2), 409);
  }

  @Test
  public void unreadable_commit_file_is_500_unknown() throws Exception {
    drivePurgeOfV2AndV3();
    // A settled version whose already-published commit cannot be read (none is present here) leaves
    // the outcome undetermined. That must surface as a retriable server error, not a false
    // conflict.
    DeltaCommit c3 = commitObject(3L);

    assertHttpStatus(() -> deltaCommitsApi.commit(c3), 500);
  }

  @Test
  public void path_traversal_filename_rejected_400() throws Exception {
    // A client-supplied file name that is not a single path segment could escape the staged-commit
    // directory the server derives from it, so it must be rejected up front.
    DeltaCommit bad = commitObject(1L);
    bad.getCommitInfo().setFileName("../escape.json");

    assertHttpStatus(() -> deltaCommitsApi.commit(bad), 400);
  }
}
