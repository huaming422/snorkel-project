## Task

coordinated commits are supposed to be idempotent on retry. when a writer loses the response to a commit it already landed and safely resends it, the catalog should recognize the resend and report success. that breaks once the version has been compacted out of the catalog's active tracking: a protocol-sanctioned resend comes back as a conflict, even though nobody else is competing for it.

a genuinely different commit racing for an already-taken version should still lose, so this isn't about loosening conflict detection. once a version has settled, the catalog can't tell a safe replay from a real collision.

dig into why the replay path falls over after a version is backfilled and fix it, so a resend of an already-settled commit is accepted idempotently while a conflicting commit for the same version is still rejected. keep both outcomes consistent across every commit entry point, since more than one path reaches that decision.

it's a server-side decision bug; nothing changes in the client SDK or wire protocol. you're offline with everything installed, so build and test with the existing tooling.
