## Task

Custom Connectors are the MCP servers people add themselves in Settings. We reviewed how the app handles them and found that it trusts too much of what users type in and what it loads from the settings file. These are the problems we ran into:

- Credentials and headers set up for a remote connector can reach the wrong server or travel over an unencrypted connection.
- When the app stores the result of signing in to a connector, it can roll back a change to the address or other settings that the user made a moment earlier.
- The prompt that asks the user to approve a call does not make it clear who is asking. It shows only a short, clipped piece of the call, and a huge call makes the prompt hard to use. Users need to be able to read the full call, shortened only when it is too large to display.
- Two connectors that look alike can be mixed up, and stored entries that are broken or ambiguous are still loaded and used.
- Credential lines typed into the form can be lost or replaced without any warning, and users can type in secrets before the app has confirmed it can keep them in secure storage.

Please fix these within the existing connector and settings code. Plain http is still fine for a connector on the same machine (localhost or 127.0.0.1). Environment variable names should follow the platform: on Windows two names that differ only in letter case count as the same name, while on macOS and Linux they are different names. Do not change the flow that recovers from a failed security update or the checks that validate each tool's arguments against its schema. Both stay as they are.
