#!/usr/bin/env bash
# Sourced (not exec'd) by the harbor runner, so env vars set here stay
# live for the verifier subprocess.
#
# open-science is a vitest project: `npx vitest run <file>` imports the
# TypeScript sources directly (no build / no dist step), so edits under
# src/ are visible immediately. The full dependency closure
# is baked into the image at the base commit (`npm ci` in the image
# build), so this task runs the connector unit tests fully offline — this
# script does no network installs on the happy path.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/open-science}"
export REPO_DIR
cd "$REPO_DIR"

# Sanity check: vitest must be resolvable from the repo root. A failure
# here means node_modules is missing/corrupt — surface it now rather than
# as a confusing "command not found" inside the verifier. The install is
# the logged online fallback; it is never expected to run because the
# image already baked node_modules offline.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest missing from node_modules/.bin/ — image" \
         "dependency closure looks incomplete; restoring offline-first." >&2
    # Offline-first: the image baked the npm cache at the base commit, so a
    # cache-only install should succeed without network; fall back to a
    # logged online install only if the offline restore cannot complete.
    npm ci --offline --prefer-offline > /tmp/test-setup-npm.log 2>&1 \
        || npm ci >> /tmp/test-setup-npm.log 2>&1 \
        || { echo "test-setup.sh: npm ci failed:" >&2; tail -40 /tmp/test-setup-npm.log >&2; exit 1; }
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR node=$(node --version) vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
