// @ts-nocheck
// @vitest-environment jsdom
//
// Interface under test: the approval prompt a user actually sees. We build the
// approval request with the real `createConnectorApplicationModule` from
// `src/main/connectors/application.ts` (the same test-double harness the
// repo's own application test uses), hand that request to the real settings
// store as a pending approval and render the real `ConnectorApprovalDialog`
// under jsdom. We assert only on text the dialog shows, never on field names
// in the request.
//
// Two custom connectors share the same display label. The prompt must let the
// user tell which one is asking: it has to show at least one detail that only
// the calling connector has (its name, its id or the host it sends to) and no
// detail that only the look-alike has. Which detail is shown is a free choice.
//
// The prompt must also let the user see the request. A small request must be
// readable in full, after opening any "show more" control the prompt offers.
// A huge request must still show part of the arguments but must be cut down
// so the prompt stays usable. The exact size limit is a free choice, so no
// minimum amount of the huge value is required.

import { afterEach, beforeEach, describe, it, expect, vi } from 'vitest'
import { act, createElement } from 'react'
import { createRoot } from 'react-dom/client'

import { createConnectorApplicationModule } from './application'
import { ConnectorApprovalDialog } from '../../renderer/src/pages/settings/ConnectorApprovalDialog'
import { createInitialSettingsState, useSettingsStore } from '@/stores/settings-store'

if (!Element.prototype.hasPointerCapture) {
  Element.prototype.hasPointerCapture = () => false
  Element.prototype.setPointerCapture = () => undefined
  Element.prototype.releasePointerCapture = () => undefined
}
if (!Element.prototype.scrollIntoView) {
  Element.prototype.scrollIntoView = () => undefined
}

const createHarness = () => {
  const settings = {
    getConnectors: vi.fn().mockResolvedValue({ customMcpServers: [] }),
    saveCustomServerOAuthState: vi.fn().mockResolvedValue(undefined),
    setCustomServerRuntimeProjectionProvider: vi.fn(),
    setCustomServerAuthenticator: vi.fn(),
    previewSkillArchive: vi.fn(),
    importSkillArchiveBatch: vi.fn(),
    scanRepoSkills: vi.fn().mockResolvedValue({ skills: [] }),
    importSkill: vi.fn()
  }
  const mcpClientManager = {
    listTools: vi.fn().mockResolvedValue([]),
    call: vi.fn(),
    authenticate: vi.fn().mockResolvedValue(undefined),
    cancelAuthentication: vi.fn().mockResolvedValue(undefined),
    close: vi.fn().mockResolvedValue(undefined),
    closeAll: vi.fn().mockResolvedValue(undefined)
  }
  const connectorApprovals = {
    request: vi.fn().mockResolvedValue('once'),
    respond: vi.fn(),
    getPending: vi.fn().mockReturnValue(null),
    pauseSession: vi.fn(),
    resumeSession: vi.fn()
  }
  const skillImportApprovals = {
    createCancellationGuard: vi
      .fn()
      .mockReturnValue({ signal: new AbortController().signal, isCancelled: () => false }),
    createSessionCancellationGuard: vi
      .fn()
      .mockReturnValue({ signal: new AbortController().signal, isCancelled: () => false }),
    request: vi.fn(),
    respond: vi.fn(),
    replayPending: vi.fn(),
    beginSessionTurn: vi.fn(),
    endSessionTurn: vi.fn(),
    allowSessionTurnAttachment: vi.fn(),
    cancelSession: vi.fn(),
    cancelAll: vi.fn()
  }
  const deps = {
    settings: settings as never,
    skillsDir: '/tmp/skills',
    openExternal: vi.fn(),
    notifyStatusChanged: vi.fn(),
    broadcastConnectorApproval: vi.fn(),
    replayConnectorApproval: vi.fn(),
    onConnectorApprovalSettled: vi.fn(),
    broadcastCredentialRequest: vi.fn(),
    replayCredentialRequest: vi.fn(),
    onCredentialRequestSettled: vi.fn(),
    broadcastSkillImportApproval: vi.fn(),
    onSkillImportSettled: vi.fn(),
    onSkillImportLifecycleSettled: vi.fn(),
    uploads: {} as never,
    fetchImpl: vi.fn() as never,
    resolveApiKey: vi.fn(),
    canRequestCredential: vi.fn().mockReturnValue(true),
    resolveSpecialistProfile: vi.fn().mockResolvedValue(undefined),
    mcpClientManager: mcpClientManager as never,
    connectorApprovals: connectorApprovals as never,
    skillImportApprovals: skillImportApprovals as never
  }
  return { settings, mcpClientManager, connectorApprovals, deps }
}

const callingServer = {
  id: 'server-id',
  name: 'stable-server',
  displayName: 'Lab records',
  transport: 'streamable_http',
  url: 'https://mcp.example.test/path',
  enabled: true
}
const lookAlikeServer = {
  id: 'other-id',
  name: 'other-server',
  displayName: 'Lab records',
  transport: 'streamable_http',
  url: 'https://other.example.test/path',
  enabled: true
}

const seedCustomServer = (settings, mcpClientManager) => {
  settings.getConnectors.mockResolvedValue({
    enabledIds: [],
    autoAllowIds: [],
    askToolIds: ['stable-server/lookup'],
    customMcpServers: [callingServer]
  })
  mcpClientManager.listTools.mockResolvedValue([
    { name: 'lookup', description: 'Look up a record', inputSchema: { type: 'object' } }
  ])
  mcpClientManager.call.mockResolvedValue({ ok: true })
}

// Runs a call that needs approval and returns the request the app produced.
const approvalRequestFor = async (args) => {
  const { settings, mcpClientManager, connectorApprovals, deps } = createHarness()
  seedCustomServer(settings, mcpClientManager)
  const module = await createConnectorApplicationModule(deps)
  await module.capability.runtimeSettings.refresh()
  await module.capability.connectorService.call('stable-server', 'lookup', args, {
    origin: 'internal'
  })
  const request = connectorApprovals.request.mock.calls[0]?.[0]
  await module.dispose?.()
  expect(request).toBeDefined()
  return request
}

let container
let root

beforeEach(() => {
  container = document.createElement('div')
  document.body.appendChild(container)
  root = createRoot(container)
})

afterEach(() => {
  act(() => root.unmount())
  container.remove()
  document.body.innerHTML = ''
})

const viewOf = (server) => ({
  id: server.id,
  name: server.name,
  displayName: server.displayName,
  transport: server.transport,
  url: server.url,
  enabled: true
})

// Shows the request in the real dialog and opens any control that reveals
// more of it. Returns the text the user can see.
const showPrompt = (request) => {
  useSettingsStore.setState({
    ...createInitialSettingsState(),
    customServers: [viewOf(callingServer), viewOf(lookAlikeServer)],
    pendingApprovals: [{ ...request, id: 'approval-1' }],
    respondApproval: vi.fn().mockResolvedValue(undefined)
  })
  act(() => root.render(createElement(ConnectorApprovalDialog)))
  const decisions = /^(deny|allow once|this session|this project|global)$/i
  const revealers = Array.from(document.body.querySelectorAll('button')).filter((button) => {
    const text = button.textContent?.trim() ?? ''
    return !decisions.test(text) && /show|more|full|expand|view|argument/i.test(text)
  })
  for (const button of revealers) act(() => button.click())
  return document.body.textContent ?? ''
}

describe('connector approval prompt', () => {
  it('shows which of two look-alike connectors is asking', async () => {
    const shown = showPrompt(await approvalRequestFor({ query: 'small' }))

    const ownDetails = ['stable-server', 'server-id', 'mcp.example.test']
    const lookAlikeDetails = ['other-server', 'other-id', 'other.example.test']
    expect(ownDetails.some((detail) => shown.includes(detail))).toBe(true)
    for (const detail of lookAlikeDetails) expect(shown).not.toContain(detail)
  })

  it('lets the user read a small request in full', async () => {
    const shown = showPrompt(await approvalRequestFor({ query: 'x'.repeat(400) }))

    // The whole argument is readable, not only a short cut-off preview.
    expect(shown).toContain('x'.repeat(400))
  })

  it('cuts a huge request down but still shows part of it', async () => {
    const args = { query: 'x'.repeat(70_000) }
    const shown = showPrompt(await approvalRequestFor(args))

    // Part of the request is still shown (its argument name), but the whole
    // 70,000-character value is not. How much is shown is a free choice.
    expect(shown).toContain('query')
    expect(shown).not.toContain('x'.repeat(70_000))
    expect(shown.length).toBeLessThan(JSON.stringify(args).length)
  })
})