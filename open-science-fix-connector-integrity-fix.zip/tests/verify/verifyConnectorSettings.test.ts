// @ts-nocheck
// @vitest-environment node
//
// Interface under test: the `ConnectorSettingsModule` owner together with the
// real `SettingsRepository`, both pre-existing exports of
// `src/main/settings/`. We drive them over a real temp settings.json (the
// repo's own connector-settings tests use exactly this setup) and assert on
// the durable record and on the public snapshot the owner returns. We never
// spy on or name any method the implementation introduces for compare-and-set
// writes; the OAuth-race case is expressed purely through the stable
// save/update/read methods and a timing gate on `getSettings`, which both a
// correct and code without this handling traverse.
//
// What each case checks:
//   - A settings file seeded with duplicate/clashing/invalid identities must
//     never let one of those records be used: any of them still shown in the
//     settings list is marked unavailable, and none of them reaches discovery.
//     Moving them out of the list (a quarantine) is also fine. A healthy record
//     in the same file stays available and routable, so dropping everything
//     does not pass.
//   - Adding or updating a remote connector whose credential names collide
//     (case-insensitively; env is Windows-only, headers everywhere) must be
//     refused before anything is encrypted or persisted.
//   - Adding a remote connector over non-loopback http must be refused before
//     persistence.
//   - An OAuth sign-in-state save that is delayed until after the user edits
//     the connector's URL/issuer must not overwrite that edit; a save that
//     races only a client-secret change must be discarded. Code without this handling
//     writes the connector record wholesale from the stale save and clobbers
//     the edit. A save with no edit in between must still be kept, so turning
//     sign-in saves off does not pass.

import { afterEach, describe, it, expect, vi } from 'vitest'
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

const keychain = vi.hoisted(() => ({ available: true, encryptedValues: [] as string[] }))

vi.mock('electron', () => ({
  safeStorage: {
    isEncryptionAvailable: () => keychain.available,
    encryptString: (plaintext: string) => {
      if (!keychain.available) throw new Error('Encryption is unavailable')
      keychain.encryptedValues.push(plaintext)
      return Buffer.from(`cipher:${plaintext}`, 'utf8')
    },
    decryptString: (buffer: Buffer) => {
      if (!keychain.available) throw new Error('Encryption is unavailable')
      return buffer.toString('utf8').slice('cipher:'.length)
    }
  },
  app: { getPath: () => '/home', getAppPath: () => '/home/no-such-app-root', isPackaged: false }
}))

const { ConnectorSettingsModule } = await import('./connector-settings')
const { SettingsRepository } = await import('./repository')
const { ALL_CONNECTOR_IDS } = await import('../connectors/registry')
const { selectEnabledCustomServers } = await import('../connectors/custom-mcp-bootstrap')

const originalPlatform = process.platform
const setPlatform = (platform: string): void => {
  Object.defineProperty(process, 'platform', { configurable: true, value: platform })
}

let dir: string
let repository: InstanceType<typeof SettingsRepository>
let service: InstanceType<typeof ConnectorSettingsModule>

const makeService = async (): Promise<void> => {
  keychain.available = true
  keychain.encryptedValues.length = 0
  dir = await mkdtemp(join(tmpdir(), 'osci-connector-settings-'))
  repository = new SettingsRepository(dir)
  service = new ConnectorSettingsModule(repository)
}

const addCustomServer = (request): Promise<unknown> =>
  service.addCustomServer({ ...request, displayName: request.displayName ?? request.name })

afterEach(async () => {
  setPlatform(originalPlatform)
  vi.restoreAllMocks()
  if (dir) await rm(dir, { recursive: true, force: true })
})

describe('persisted identity conflicts cannot be used', () => {
  it('keeps every clashing record out of use and leaves a healthy record usable', async () => {
    await makeService()
    const initial = await repository.getSettings()
    const bundledId = ALL_CONNECTOR_IDS[0]
    await writeFile(
      join(dir, 'settings.json'),
      JSON.stringify({
        ...initial,
        connectors: {
          enabledIds: [],
          autoAllowIds: [],
          customMcpServers: [
            { id: 'duplicate-id', name: 'duplicate-one', displayName: 'Duplicate one', transport: 'stdio', command: 'a', enabled: true },
            { id: 'duplicate-id', name: 'duplicate-two', displayName: 'Duplicate two', transport: 'stdio', command: 'b', enabled: true },
            { id: bundledId, name: 'built-in-id-collision', displayName: 'Built-in ID collision', transport: 'stdio', command: 'c', enabled: true },
            { id: 'cross-id', name: 'cross-name', displayName: 'Cross one', transport: 'stdio', command: 'd', enabled: true },
            { id: 'cross-name', name: 'cross-other', displayName: 'Cross two', transport: 'stdio', command: 'e', enabled: true },
            { id: 'Invalid ID', name: 'invalid-id-format', displayName: 'Invalid ID format', transport: 'stdio', command: 'f', enabled: true },
            { id: 'healthy-id', name: 'healthy-server', displayName: 'Healthy server', transport: 'stdio', command: 'g', enabled: true }
          ]
        }
      })
    )
    service = new ConnectorSettingsModule(new SettingsRepository(dir))

    const clashingNames = [
      'duplicate-one',
      'duplicate-two',
      'built-in-id-collision',
      'cross-name',
      'cross-other',
      'invalid-id-format'
    ]
    const snapshot = await service.listConnectors()
    for (const server of snapshot.customServers) {
      if (clashingNames.includes(server.name)) expect(server.availability).toBe('unavailable')
    }
    const healthy = snapshot.customServers.find((server) => server.name === 'healthy-server')
    expect(healthy).toBeDefined()
    expect(healthy?.availability).not.toBe('unavailable')

    const routable = selectEnabledCustomServers(await service.getConnectors())
    expect(routable.map((server) => server.name)).toEqual(['healthy-server'])
  })
})

describe('credential-name collisions are refused before persistence', () => {
  it.each([
    {
      label: 'Windows environment variables',
      platform: 'win32',
      request: { name: 'ambiguous-add-env', transport: 'stdio', command: 'npx', env: { API_TOKEN: 'first', api_token: 'second' } }
    },
    {
      label: 'HTTP headers',
      platform: 'darwin',
      request: { name: 'ambiguous-add-headers', transport: 'streamable_http', url: 'https://mcp.example.test', headers: { Authorization: 'first', authorization: 'second' } }
    }
  ])('refuses case-colliding $label on add', async ({ platform, request }) => {
    await makeService()
    setPlatform(platform)
    await expect(addCustomServer(request)).rejects.toThrow()
    expect(keychain.encryptedValues).toEqual([])
    expect((await repository.getSettings()).connectors?.customMcpServers ?? []).toEqual([])
  })

  it('keeps case-distinct environment variables acceptable on Unix', async () => {
    await makeService()
    setPlatform('darwin')
    await expect(
      addCustomServer({ name: 'case-distinct-add-env', transport: 'stdio', command: 'npx', env: { API_TOKEN: 'first', api_token: 'second' } })
    ).resolves.toBeDefined()
  })
})

describe('non-loopback http credentials are refused before persistence', () => {
  it('rejects a remote http endpoint with headers before writing', async () => {
    await makeService()
    await expect(
      addCustomServer({ name: 'remote-http-credentials', transport: 'streamable_http', url: 'http://example.com/mcp', headers: { Authorization: 'Bearer secret' } })
    ).rejects.toThrow()

    expect((await repository.getSettings()).connectors?.customMcpServers ?? []).toEqual([])
  })
})

describe('delayed OAuth save does not clobber a concurrent edit', () => {
  // Reproduce the stale-save window using only stable seams: the save reads the
  // connector record (one getSettings call) before it writes. We let that first
  // read observe the pre-edit record, hold the save open, run the edit to a
  // durable write, then release — so the save's own write lands after the edit.
  // Code without this handling writes the whole stale record back here and clobbers the
  // edit; a tree that commits the save under a compare-and-set discards it.
  //
  // Gate strategy: we intercept the first `getSettings` call inside the save
  // to introduce a synchronisation point. Implementations that use a mutation
  // queue instead of a direct `getSettings` read will never trigger the spy,
  // so we race `begun` with a short settled-promise timeout. When the timeout
  // wins, we release immediately and verify the result without an interleaved
  // edit (the queue's own serialisation guarantees the correct ordering).
  const gateSaveRead = () => {
    let release!: () => void
    const released = new Promise<void>((resolve) => {
      release = resolve
    })
    let started!: () => void
    const begun = new Promise<void>((resolve) => {
      started = resolve
    })
    const real = repository.getSettings.bind(repository)
    let calls = 0
    vi.spyOn(repository, 'getSettings').mockImplementation(async () => {
      calls += 1
      if (calls === 1) {
        const snapshot = await real()
        started()
        // Safety: if this getSettings call is dispatched from inside a mutation
        // queue that holds a write lock, pausing indefinitely would deadlock any
        // concurrent write (e.g. updateCustomServer) that needs the same lock.
        // A 150 ms window is more than enough for the test's interleave to run
        // (the begunOrImmediate timeout is 50 ms, plus a fast updateCustomServer);
        // after that the lock is released so the queue can drain and the tests
        // complete without the 600 s runner timeout.
        await Promise.race([released, new Promise<void>((r) => setTimeout(r, 150))])
        return snapshot
      }
      return real()
    })
    // Race begun with a microtask-yield timeout so implementations that do not
    // call getSettings inside saveCustomServerOAuthState do not hang.
    const begunOrImmediate = Promise.race([
      begun,
      new Promise<void>((r) => setTimeout(r, 50))
    ])
    return { release, begun: begunOrImmediate }
  }

  it('keeps a sign-in save when nothing changed in between', async () => {
    await makeService()
    const added = await addCustomServer({
      name: 'oauth-plain-save',
      transport: 'streamable_http',
      url: 'https://mcp.example.test/mcp',
      oauth: { authorizationServerUrl: 'https://auth.example.test' }
    })
    const id = added.customServers[0].id

    await service.saveCustomServerOAuthState(id, {
      tokens: { access_token: 'fresh-token', token_type: 'Bearer' }
    })

    const stored = (await repository.getSettings()).connectors?.customMcpServers?.[0]
    expect(stored?.oauthRef).toBeDefined()
    expect(stored?.url).toBe('https://mcp.example.test/mcp')
  })

  it('preserves a URL/issuer edit that lands during a stale sign-in save', async () => {
    await makeService()
    const added = await addCustomServer({
      name: 'oauth-config-race',
      transport: 'streamable_http',
      url: 'https://old.example/mcp',
      oauth: { authorizationServerUrl: 'https://old.example/oauth' }
    })
    const id = added.customServers[0].id
    const { release, begun } = gateSaveRead()

    const staleSave = service.saveCustomServerOAuthState(id, {
      tokens: { access_token: 'stale-token', token_type: 'Bearer' }
    })
    await begun
    await service.updateCustomServer({
      id,
      transport: 'streamable_http',
      url: 'https://new.example/mcp',
      oauth: { authorizationServerUrl: 'https://new.example/oauth' }
    })
    release()
    await staleSave

    const stored = (await repository.getSettings()).connectors?.customMcpServers?.[0]
    expect(stored?.url).toBe('https://new.example/mcp')
    expect(stored?.oauth?.authorizationServerUrl).toBe('https://new.example/oauth')
    expect(stored?.oauthRef).toBeUndefined()
  })

  it('discards a stale sign-in save when only the client secret changed', async () => {
    await makeService()
    const added = await addCustomServer({
      name: 'oauth-client-secret-race',
      transport: 'streamable_http',
      url: 'https://mcp.example.test',
      oauth: { authorizationServerUrl: 'https://auth.example.test', clientId: 'registered-client', clientSecret: 'old-client-secret' }
    })
    const id = added.customServers[0].id
    const { release, begun } = gateSaveRead()

    const staleSave = service.saveCustomServerOAuthState(id, {
      tokens: { access_token: 'stale-token', token_type: 'Bearer' }
    })
    await begun
    await service.updateCustomServer({
      id,
      transport: 'streamable_http',
      url: 'https://mcp.example.test',
      oauth: { authorizationServerUrl: 'https://auth.example.test', clientId: 'registered-client', clientSecret: 'new-client-secret' }
    })
    release()
    await staleSave

    const stored = (await repository.getSettings()).connectors?.customMcpServers?.[0]
    expect(stored?.oauthRef).toBeUndefined()
    expect((await service.getConnectors())?.customMcpServers?.[0].oauthClientSecret).toBe('new-client-secret')
  })
})
