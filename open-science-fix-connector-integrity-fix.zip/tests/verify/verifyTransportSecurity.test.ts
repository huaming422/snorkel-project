// @ts-nocheck
// @vitest-environment node
//
// Interface under test: `buildTransport` exported from
// `src/main/connectors/mcp-client-manager.ts`. This factory already exists in
// the tree and is the stable seam the renderer/runtime use to turn a stored
// remote Connector config into an SDK transport. We assert only observable
// behaviour of the transport it returns (what it refuses to build, and which
// requests reach the injected network stack), never any internal helper the
// implementation may add — a correct implementation is free to name its own
// predicates and fetch wrappers.
//
// The Electron `net.fetch` chokepoint is stubbed with a hoisted `netFetch`
// mock, mirroring how the repo's own transport tests drive the HTTP path
// without a live socket.
//
// Why a tree that still trusts the configured URL/headers scores lower here
// than a hardened one:
//   - A plain non-loopback http endpoint must be refused up front; an
//     https/loopback-http endpoint must be accepted. A tree that builds the
//     transport for http://example.com fails the refusal assertion.
//   - A redirect to a different https origin must drop the statically-configured
//     headers before the next hop leaves, for streamable HTTP and for SSE
//     connectors. The new origin is also https, so refusing only a downgrade to
//     plain http is not enough. A tree that forwards headers verbatim across
//     the hop fails the "no headers after cross-origin redirect" assertion.
//   - A redirect that stays on the configured secure origin must keep the
//     configured headers(streamable HTTP and SSE), so a blanket header
//     stripper does not pass.
//   - OAuth discovery may run against a different secure origin, and the
//     MCP server's static headers must not be sent to that authorization
//     server.

import { afterEach, describe, it, expect, vi } from 'vitest'
import { StreamableHTTPClientTransport } from '@modelcontextprotocol/sdk/client/streamableHttp.js'
import { UnauthorizedError } from '@modelcontextprotocol/sdk/client/auth.js'
import { buildTransport } from './mcp-client-manager'
import { PersistentOAuthClientProvider } from './oauth-client'

const { netFetch } = vi.hoisted(() => ({ netFetch: vi.fn() }))

vi.mock('electron', () => ({ net: { fetch: netFetch } }))
vi.mock('../logger', () => ({
  createLogger: () => ({ debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn() })
}))

afterEach(() => {
  vi.restoreAllMocks()
  netFetch.mockReset()
})

describe('custom connector transport URL acceptance', () => {
  it('builds a transport for an https remote endpoint', () => {
    const transport = buildTransport({
      id: 'srv-https',
      name: 'https-server',
      transport: 'streamable_http',
      url: 'https://mcp.example.test/mcp',
      headers: { Authorization: 'Bearer token' }
    })

    expect(transport).toBeInstanceOf(StreamableHTTPClientTransport)
  })

  it('builds a transport for a loopback http endpoint', () => {
    expect(() =>
      buildTransport({
        id: 'srv-loopback',
        name: 'loopback-server',
        transport: 'streamable_http',
        url: 'http://127.0.0.1:8080/mcp'
      })
    ).not.toThrow()

    expect(() =>
      buildTransport({
        id: 'srv-loopback-named',
        name: 'loopback-named-server',
        transport: 'sse',
        url: 'http://localhost:8080/sse'
      })
    ).not.toThrow()
  })

  it('refuses a non-loopback http endpoint before creating a client', () => {
    expect(() =>
      buildTransport({
        id: 'srv-cleartext',
        name: 'cleartext-server',
        transport: 'streamable_http',
        url: 'http://example.com/mcp',
        headers: { Authorization: 'Bearer secret' }
      })
    ).toThrow()

    expect(() =>
      buildTransport({
        id: 'srv-cleartext-sse',
        name: 'cleartext-sse-server',
        transport: 'sse',
        url: 'http://example.com/sse'
      })
    ).toThrow()
  })
})

describe('custom connector transport redirect handling', () => {
  it('does not forward configured headers across a redirect that leaves the origin', async () => {
    const redirectedHeaders: Headers[] = []
    netFetch.mockImplementation(async (input, init) => {
      const url = new URL(String(input))
      if (url.hostname === 'redirect.example.test') {
        redirectedHeaders.push(new Headers(init?.headers))
        return new Response(null, { status: 202 })
      }
      const location = 'https://redirect.example.test/mcp'
      if (init?.redirect === 'manual') {
        return new Response(null, { status: 302, headers: { location } })
      }
      return netFetch(new URL(location), init)
    })
    const transport = buildTransport({
      id: 'srv-redirect',
      name: 'redirect-server',
      transport: 'streamable_http',
      url: 'https://mcp.example.test',
      headers: { 'X-API-Key': 'secret' }
    })

    await transport.start()
    await transport
      .send({ jsonrpc: '2.0', method: 'notifications/initialized' })
      .catch(() => undefined)

    // Either the cross-origin hop is refused outright (no second request) or it
    // is attempted without the configured headers. A tree that carries the
    // headers to the new origin populates this list with the secret.
    for (const headers of redirectedHeaders) {
      expect(headers.get('X-API-Key')).toBeNull()
    }
    await transport.close().catch(() => undefined)
  })

  it('keeps configured headers on a redirect that stays on the secure origin', async () => {
    netFetch.mockReset()
    netFetch
      .mockResolvedValueOnce(
        new Response(null, { status: 307, headers: { location: '/redirected-mcp' } })
      )
      .mockResolvedValue(new Response(null, { status: 202 }))
    const transport = buildTransport({
      id: 'srv-same-origin-redirect',
      name: 'same-origin-redirect-server',
      transport: 'streamable_http',
      url: 'https://mcp.example.test',
      headers: { 'X-API-Key': 'secret' }
    })

    await transport.start()
    await transport.send({ jsonrpc: '2.0', method: 'notifications/initialized' })

    // The redirect is followed to the same secure origin (a second request is
    // issued to the Location target), and the configured header survives that
    // same-origin hop. We assert the observable outcome — a re-request to the
    // redirected same-origin URL still carrying the header — not how the
    // implementation chooses to perform the redirect.
    const sameOriginReRequest = netFetch.mock.calls.find(([input]) => {
      const url = new URL(String(input))
      return url.origin === 'https://mcp.example.test' && url.pathname === '/redirected-mcp'
    })
    expect(sameOriginReRequest).toBeDefined()
    expect(new Headers(sameOriginReRequest?.[1]?.headers).get('X-API-Key')).toBe('secret')
    await transport.close()
  })
})

const sseStream = (endpoint: string): Response => {
  const body = new ReadableStream({
    start(controller) {
      controller.enqueue(new TextEncoder().encode(`event: endpoint\ndata: ${endpoint}\n\n`))
    }
  })
  return new Response(body, { status: 200, headers: { 'content-type': 'text/event-stream' } })
}

describe('custom connector SSE redirect handling', () => {
  it('does not forward configured headers across an SSE redirect to another https origin', async () => {
    const redirectedHeaders: Headers[] = []
    netFetch.mockImplementation(async (input, init) => {
      const url = new URL(String(input))
      if (url.hostname === 'redirect.example.test') {
        redirectedHeaders.push(new Headers(init?.headers))
        return url.pathname === '/sse' ? sseStream('/messages') : new Response(null, { status: 202 })
      }
      const location = 'https://redirect.example.test/sse'
      if (init?.redirect === 'manual') {
        return new Response(null, { status: 302, headers: { location } })
      }
      return netFetch(new URL(location), init)
    })
    const transport = buildTransport({
      id: 'srv-sse-redirect',
      name: 'sse-redirect-server',
      transport: 'sse',
      url: 'https://mcp.example.test/sse',
      headers: { 'X-API-Key': 'secret' }
    })

    // Either the cross-origin hop is refused (start fails or never reaches the
    // other origin) or it is made without the configured headers.
    await transport.start().catch(() => undefined)
    for (const headers of redirectedHeaders) {
      expect(headers.get('X-API-Key')).toBeNull()
    }
    await transport.close().catch(() => undefined)
  })

  it('keeps configured headers on an SSE redirect that stays on the secure origin', async () => {
    netFetch.mockImplementation(async (input, init) => {
      const url = new URL(String(input))
      if (url.pathname === '/sse') {
        const location = '/sse-moved'
        if (init?.redirect === 'manual') {
          return new Response(null, { status: 307, headers: { location } })
        }
        return netFetch(new URL(location, url), init)
      }
      if (url.pathname === '/sse-moved') return sseStream('/messages')
      return new Response(null, { status: 202 })
    })
    const transport = buildTransport({
      id: 'srv-sse-same-origin',
      name: 'sse-same-origin-server',
      transport: 'sse',
      url: 'https://mcp.example.test/sse',
      headers: { 'X-API-Key': 'secret' }
    })

    await transport.start()
    await transport.send({ jsonrpc: '2.0', method: 'notifications/initialized' })

    const streamRequest = netFetch.mock.calls.find(([input]) => {
      const url = new URL(String(input))
      return url.origin === 'https://mcp.example.test' && url.pathname === '/sse-moved'
    })
    expect(streamRequest).toBeDefined()
    expect(new Headers(streamRequest?.[1]?.headers).get('X-API-Key')).toBe('secret')
    const messageRequest = netFetch.mock.calls.find(([input]) => {
      const url = new URL(String(input))
      return url.origin === 'https://mcp.example.test' && url.pathname === '/messages'
    })
    expect(messageRequest).toBeDefined()
    expect(new Headers(messageRequest?.[1]?.headers).get('X-API-Key')).toBe('secret')
    await transport.close()
  })
})

describe('custom connector OAuth discovery origin', () => {
  it('runs OAuth discovery on a different secure origin without the MCP static headers', async () => {
    netFetch.mockReset()
    const authorizationServerHeaders: Headers[] = []
    netFetch.mockImplementation(async (input, init) => {
      const url = new URL(String(input))
      if (url.origin === 'https://mcp.example.test' && url.pathname === '/mcp') {
        return new Response(null, { status: 401 })
      }
      if (
        url.origin === 'https://mcp.example.test' &&
        url.pathname.startsWith('/.well-known/oauth-protected-resource')
      ) {
        return new Response(null, { status: 404 })
      }
      if (
        url.origin === 'https://auth.example.test' &&
        url.pathname === '/.well-known/oauth-authorization-server'
      ) {
        authorizationServerHeaders.push(new Headers(init?.headers))
        return Response.json({
          issuer: 'https://auth.example.test',
          authorization_endpoint: 'https://auth.example.test/authorize',
          token_endpoint: 'https://auth.example.test/token',
          response_types_supported: ['code'],
          code_challenge_methods_supported: ['S256']
        })
      }
      throw new Error(`unexpected request to ${url}`)
    })
    const openExternal = vi.fn(async () => undefined)
    const provider = new PersistentOAuthClientProvider({
      serverId: 'srv-cross-origin-oauth',
      redirectUrl: 'http://127.0.0.1:4000/oauth/callback',
      config: {
        authorizationServerUrl: 'https://auth.example.test',
        clientId: 'registered-client'
      },
      openExternal
    })
    const transport = buildTransport(
      {
        id: 'srv-cross-origin-oauth',
        name: 'cross-origin-oauth-server',
        transport: 'streamable_http',
        url: 'https://mcp.example.test/mcp',
        headers: { 'X-API-Key': 'mcp-static-secret' },
        oauth: {
          authorizationServerUrl: 'https://auth.example.test',
          clientId: 'registered-client'
        }
      },
      provider
    )

    await transport.start()
    await expect(
      transport.send({ jsonrpc: '2.0', method: 'notifications/initialized' })
    ).rejects.toBeInstanceOf(UnauthorizedError)

    expect(openExternal).toHaveBeenCalledWith(
      expect.stringMatching(/^https:\/\/auth\.example\.test\/authorize\?/)
    )
    expect(authorizationServerHeaders).toHaveLength(1)
    expect(authorizationServerHeaders[0]?.get('X-API-Key')).toBeNull()
    await transport.close()
  })
})
