// @ts-nocheck
// @vitest-environment jsdom
//
// Interface under test: the real `ConnectorAddForm` component, rendered under
// jsdom and driven through the pre-existing `useSettingsStore` store, mirroring
// the repo's own add-form render test (native-setter input events, the trust
// checkbox, the advanced-settings disclosure). We assert on rendered text and
// the add button's disabled state, never on component internals.
//
// Note: the wording of any new validation message the implementation renders is a free
// implementation choice, so we never assert on message TEXT. We assert on the
// user-facing CONTRACT that is stable and pre-existing: the Add button's
// disabled state (canSubmit). Invalid or unsafe input must disable submission;
// valid input must leave it enabled.
//
// What each case checks:
//   - A malformed credential line must block submission (not be silently
//     dropped). A form without this handling drops it and leaves the button enabled.
//   - Duplicate credential names must block submission instead of being
//     overwritten; environment names collide case-insensitively only on
//     Windows, header names everywhere. The active platform is read from
//     `window.api.platform`, which the test overrides, matching the source.
//   - Static credentials must not be submittable before the app confirms secure
//     storage is available, for a local connector's environment variables and
//     for a remote connector's static headers. A form without this handling
//     permits submission. The same remote form stays submittable once secure
//     storage is confirmed, so blocking every submit does not pass.

import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'

import { ConnectorAddForm } from './ConnectorAddForm'
import { createInitialSettingsState, useSettingsStore } from '@/stores/settings-store'

if (!Element.prototype.hasPointerCapture) {
  Element.prototype.hasPointerCapture = (): boolean => false
  Element.prototype.setPointerCapture = (): void => undefined
  Element.prototype.releasePointerCapture = (): void => undefined
}
if (!Element.prototype.scrollIntoView) {
  Element.prototype.scrollIntoView = (): void => undefined
}

let container: HTMLDivElement
let root: Root

beforeEach(() => {
  useSettingsStore.setState({
    ...createInitialSettingsState(),
    encryptionAvailable: true,
    addCustomServer: vi.fn().mockResolvedValue(undefined)
  })
  container = document.createElement('div')
  document.body.appendChild(container)
  root = createRoot(container)
})

afterEach(() => {
  act(() => root.unmount())
  container.remove()
  document.body.innerHTML = ''
})

const setValue = (label: string, value: string): void => {
  const field = document.body.querySelector<HTMLInputElement | HTMLTextAreaElement>(
    `[aria-label="${label}"]`
  )
  const proto =
    field instanceof HTMLTextAreaElement
      ? window.HTMLTextAreaElement.prototype
      : window.HTMLInputElement.prototype
  const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set
  act(() => {
    setter?.call(field, value)
    field?.dispatchEvent(new Event('input', { bubbles: true }))
  })
}

const checkTrust = (): void => {
  const checkbox = document.body.querySelector<HTMLInputElement>(
    '[aria-label="I trust this connector"]'
  )
  act(() => checkbox?.click())
}

const addButton = (): HTMLButtonElement | undefined =>
  Array.from(document.body.querySelectorAll<HTMLButtonElement>('button')).find((button) =>
    ['Add connector', 'Add and sign in'].includes(button.textContent?.trim() ?? '')
  )

const advancedButton = (): HTMLButtonElement | null =>
  document.body.querySelector<HTMLButtonElement>(
    'button[aria-controls="connector-advanced-settings"]'
  )

const openAdvancedSettings = (): void => {
  const button = advancedButton()
  if (button?.getAttribute('aria-expanded') === 'false') act(() => button.click())
}

const selectOption = (label: string, option: string): void => {
  const trigger = document.body.querySelector<HTMLButtonElement>(`[aria-label="${label}"]`)
  act(() => {
    trigger?.dispatchEvent(new MouseEvent('pointerdown', { bubbles: true, button: 0 }))
    trigger?.dispatchEvent(new MouseEvent('click', { bubbles: true }))
  })
  const item = Array.from(document.body.querySelectorAll<HTMLElement>('[role="option"]')).find(
    (candidate) => candidate.textContent?.includes(option)
  )
  act(() => {
    item?.dispatchEvent(new MouseEvent('pointerup', { bubbles: true, button: 0 }))
    item?.dispatchEvent(new MouseEvent('click', { bubbles: true }))
  })
}

describe('ConnectorAddForm credential text handling', () => {
  it('reports a malformed header line instead of dropping it', () => {
    act(() => {
      root.render(<ConnectorAddForm initialTransport="remote" onDone={vi.fn()} onCancel={vi.fn()} />)
    })

    setValue('Display name', 'Remote memory')
    setValue('Server URL', 'https://mcp.example.test')
    openAdvancedSettings()
    selectOption('Authentication', 'Static headers')
    setValue('Headers', 'Authorization: Bearer secret\nBROKEN')
    checkTrust()

    // A malformed line must block submission rather than being silently dropped.
    expect(addButton()?.disabled).toBe(true)
  })

  it('reports duplicate environment names instead of overwriting them', () => {
    act(() => {
      root.render(<ConnectorAddForm initialTransport="local" onDone={vi.fn()} onCancel={vi.fn()} />)
    })

    setValue('Display name', 'Memory')
    openAdvancedSettings()
    setValue('Environment variables', 'API_TOKEN=first\nAPI_TOKEN=second')
    checkTrust()

    // A duplicate name must block submission rather than silently overwrite.
    expect(addButton()?.disabled).toBe(true)
  })

  it('reports duplicate header names instead of overwriting them', () => {
    act(() => {
      root.render(<ConnectorAddForm initialTransport="remote" onDone={vi.fn()} onCancel={vi.fn()} />)
    })

    setValue('Display name', 'Remote memory')
    setValue('Server URL', 'https://mcp.example.test')
    openAdvancedSettings()
    selectOption('Authentication', 'Static headers')
    setValue('Headers', 'Authorization: first\nAuthorization: second')
    checkTrust()

    // Case-insensitive header duplicate must block submission on every platform.
    expect(addButton()?.disabled).toBe(true)
  })
})

describe('ConnectorAddForm platform-sensitive credential names', () => {
  it('reports environment names that collide case-insensitively on Windows', () => {
    const originalApi = window.api
    window.api = { ...originalApi, platform: 'win32' } as Window['api']
    try {
      act(() => {
        root.render(<ConnectorAddForm initialTransport="local" onDone={vi.fn()} onCancel={vi.fn()} />)
      })

      setValue('Display name', 'Memory')
      openAdvancedSettings()
      setValue('Environment variables', 'API_TOKEN=first\napi_token=second')
      checkTrust()

      // On Windows these names collide case-insensitively and must block submit.
      expect(addButton()?.disabled).toBe(true)
    } finally {
      window.api = originalApi
    }
  })

  it('keeps case-distinct environment names valid on Unix', () => {
    const originalApi = window.api
    window.api = { ...originalApi, platform: 'darwin' } as Window['api']
    try {
      act(() => {
        root.render(<ConnectorAddForm initialTransport="local" onDone={vi.fn()} onCancel={vi.fn()} />)
      })

      setValue('Display name', 'Memory')
      openAdvancedSettings()
      setValue('Environment variables', 'API_TOKEN=first\napi_token=second')
      checkTrust()

      // On Unix these are distinct names: submission stays enabled.
      expect(addButton()?.disabled).toBe(false)
    } finally {
      window.api = originalApi
    }
  })
})

describe('ConnectorAddForm secure storage gate', () => {
  it('blocks static credential submission until secure storage is confirmed', () => {
    useSettingsStore.setState({ encryptionAvailable: false })
    act(() => {
      root.render(<ConnectorAddForm initialTransport="local" onDone={vi.fn()} onCancel={vi.fn()} />)
    })

    setValue('Display name', 'Local memory')
    openAdvancedSettings()
    setValue('Environment variables', 'API_TOKEN=secret')
    checkTrust()

    // Static secrets must not be submittable before secure storage is confirmed.
    expect(addButton()?.disabled).toBe(true)
  })

  it('blocks remote static headers until secure storage is confirmed', () => {
    useSettingsStore.setState({ encryptionAvailable: false })
    act(() => {
      root.render(<ConnectorAddForm initialTransport="remote" onDone={vi.fn()} onCancel={vi.fn()} />)
    })

    setValue('Display name', 'Remote memory')
    setValue('Server URL', 'https://mcp.example.test')
    openAdvancedSettings()
    selectOption('Authentication', 'Static headers')
    setValue('Headers', 'Authorization: Bearer secret')
    checkTrust()

    expect(addButton()?.disabled).toBe(true)
  })

  it('allows remote static headers once secure storage is confirmed', () => {
    useSettingsStore.setState({ encryptionAvailable: true })
    act(() => {
      root.render(<ConnectorAddForm initialTransport="remote" onDone={vi.fn()} onCancel={vi.fn()} />)
    })

    setValue('Display name', 'Remote memory')
    setValue('Server URL', 'https://mcp.example.test')
    openAdvancedSettings()
    selectOption('Authentication', 'Static headers')
    setValue('Headers', 'Authorization: Bearer secret')
    checkTrust()

    expect(addButton()?.disabled).toBe(false)
  })
})
