// @ts-nocheck
/**
 * Behavioral check for the embedded dashboard header's horizontal overflow.
 *
 * In an embed the page shows a stray horizontal scrollbar at narrower widths:
 * the sticky dashboard header is capped against a viewport-unit width, and a
 * viewport unit counts the scrollbar gutter, so the header runs a sliver past
 * the visible edge and the whole page scrolls sideways. A content-column width
 * that the grid track already knows does not include that gutter.
 *
 * This renders the real DashboardBuilder (its header carries the pre-existing
 * data-test="dashboard-header-wrapper") inside an embed and observes the style
 * rule the header emits via @emotion/jest's toHaveStyleRule. It asserts the
 * OBSERVABLE contract — the header is no longer capped by a viewport-unit width
 * that includes the gutter — not any particular replacement rule: a column-
 * relative cap (100%), a track-relative calc, or any non-viewport width all
 * satisfy it. The embed gate (isEmbedded) is stubbed true so an embed-scoped fix
 * is exercised in its embedded form.
 *
 * The scaffolding mirrors the repo's own DashboardBuilder.test.tsx, which renders
 * this same component and asserts the header's max-width through this same
 * interface, so the render is a known-good, deterministic one.
 */
import { mockAntdWithDesktopBreakpoint } from 'spec/helpers/mobileTestUtils';
import fetchMock from 'fetch-mock';
import { render } from 'spec/helpers/testing-library';

fetchMock.get('glob:*/csstemplateasyncmodelview/api/read', {});
fetchMock.put('glob:*/api/v1/dashboard/*', {});
fetchMock.post('glob:*/log/?*', {});

// Keep the breakpoint desktop so the header renders in its normal (non-mobile)
// form, matching the repo's own DashboardBuilder tests.
jest.mock('antd', () => mockAntdWithDesktopBreakpoint());

// isEmbedded is the pre-existing gate an embed-scoped header fix reads. jsdom's
// window.self === window.top, so the real gate returns false; stub it true so
// the embedded branch is the one under test. Harmless on a build that caps the
// header unconditionally — it simply has no gate to flip.
jest.mock('src/dashboard/util/isEmbedded', () => ({
  isEmbedded: jest.fn(() => true),
}));

jest.mock('src/dashboard/actions/dashboardState', () => ({
  ...jest.requireActual('src/dashboard/actions/dashboardState'),
  fetchFaveStar: jest.fn(),
  setActiveTab: jest.fn(),
  setDirectPathToChild: jest.fn(),
}));
jest.mock('src/components/ResizableSidebar/useStoredSidebarWidth');

// Mock the dependent subtrees the header does not need, matching the repo's own
// DashboardBuilder test, so the render stays focused and free of prop warnings.
jest.mock('@superset-ui/core/components/Select/Select', () => {
  const MockSelect = () => <div data-test="mock-select" />;
  MockSelect.displayName = 'MockSelect';
  return MockSelect;
});
jest.mock('@superset-ui/core/components/Select/AsyncSelect', () => {
  const MockAsyncSelect = () => <div data-test="mock-async-select" />;
  MockAsyncSelect.displayName = 'MockAsyncSelect';
  return MockAsyncSelect;
});
jest.mock('@superset-ui/core/components/PageHeaderWithActions', () => {
  const MockPageHeaderWithActions = () => (
    <div data-test="mock-page-header-with-actions" />
  );
  MockPageHeaderWithActions.displayName = 'MockPageHeaderWithActions';
  return {
    PageHeaderWithActions: MockPageHeaderWithActions,
  };
});
jest.mock(
  'src/dashboard/components/nativeFilters/FiltersConfigModal/FiltersConfigModal',
  () => {
    const MockFiltersConfigModal = () => (
      <div data-test="mock-filters-config-modal" />
    );
    MockFiltersConfigModal.displayName = 'MockFiltersConfigModal';
    return MockFiltersConfigModal;
  },
);
jest.mock('src/dashboard/components/BuilderComponentPane', () => {
  const MockBuilderComponentPane = () => (
    <div data-test="mock-builder-component-pane" />
  );
  MockBuilderComponentPane.displayName = 'MockBuilderComponentPane';
  return MockBuilderComponentPane;
});
jest.mock('src/dashboard/components/nativeFilters/FilterBar', () => {
  const MockFilterBar = () => <div data-test="mock-filter-bar" />;
  MockFilterBar.displayName = 'MockFilterBar';
  return MockFilterBar;
});
jest.mock('src/dashboard/containers/DashboardGrid', () => {
  const MockDashboardGrid = () => <div data-test="mock-dashboard-grid" />;
  MockDashboardGrid.displayName = 'MockDashboardGrid';
  return MockDashboardGrid;
});
jest.mock('src/dashboard/components/Header/HeadlessAutoRefresh', () => {
  const MockHeadlessAutoRefresh = () => (
    <div data-test="mock-headless-auto-refresh" />
  );
  MockHeadlessAutoRefresh.displayName = 'MockHeadlessAutoRefresh';
  return MockHeadlessAutoRefresh;
});
jest.mock('src/hooks/useIsMobile', () => ({
  ...jest.requireActual('src/hooks/useIsMobile'),
  useIsMobile: jest.fn().mockReturnValue(false),
}));

// eslint-disable-next-line import/first
import DashboardBuilder from 'src/dashboard/components/DashboardBuilder/DashboardBuilder';
// eslint-disable-next-line import/first
import useStoredSidebarWidth from 'src/components/ResizableSidebar/useStoredSidebarWidth';
// eslint-disable-next-line import/first
import {
  fetchFaveStar,
  setActiveTab,
} from 'src/dashboard/actions/dashboardState';
// eslint-disable-next-line import/first
import { dashboardLayout as undoableDashboardLayout } from 'spec/fixtures/mockDashboardLayout';
// eslint-disable-next-line import/first
import { storeWithState } from 'spec/fixtures/mockStore';
// eslint-disable-next-line import/first
import mockState from 'spec/fixtures/mockState';
// eslint-disable-next-line import/first
import * as useNativeFiltersModule from 'src/dashboard/components/DashboardBuilder/state';

beforeAll(() => {
  (fetchFaveStar as jest.Mock).mockReturnValue({ type: 'mock-action' });
  (setActiveTab as jest.Mock).mockReturnValue({ type: 'mock-action' });
  (useStoredSidebarWidth as jest.Mock).mockImplementation(() => [100, jest.fn()]);
});

afterAll(() => {
  (fetchFaveStar as jest.Mock).mockReset();
  (setActiveTab as jest.Mock).mockReset();
  (useStoredSidebarWidth as jest.Mock).mockReset();
});

// Render with the vertical filter bar present so the header is in the exact
// configuration the overflow was reported in (a header sharing the row with an
// open filter bar). The filter bar's own subtree is mocked above; this only
// drives DashboardBuilder's own layout decisions.
const renderBuilder = () => {
  const nativeFiltersSpy = jest
    .spyOn(useNativeFiltersModule, 'useNativeFilters')
    .mockReturnValue({
      showDashboard: true,
      missingInitialFilters: [],
      dashboardFiltersOpen: true,
      toggleDashboardFiltersOpen: jest.fn(),
      nativeFiltersEnabled: true,
      hasFilters: true,
    });
  const result = render(<DashboardBuilder />, {
    useRedux: true,
    store: storeWithState({
      ...mockState,
      dashboardLayout: undoableDashboardLayout,
    }),
    useDnd: true,
    useRouter: true,
    useTheme: true,
  });
  return { ...result, nativeFiltersSpy };
};

describe('embedded dashboard header width', () => {
  // fail_to_pass — the stray horizontal scrollbar. The header must not be capped
  // by a viewport-unit width (100vw), which includes the scrollbar gutter and
  // runs the header a sliver past the visible edge. Any non-viewport cap — a
  // column-relative 100%, a track-relative calc, etc. — is accepted.
  test('header is not capped by a viewport-unit width in an embed', () => {
    const { getByTestId, nativeFiltersSpy } = renderBuilder();

    const header = getByTestId('dashboard-header-wrapper');
    // A 100vw-based cap counts the scrollbar gutter and overflows; reject it
    // whatever the exact calc expression around it.
    expect(header).not.toHaveStyleRule('max-width', /100vw/);

    nativeFiltersSpy.mockRestore();
  });
});
