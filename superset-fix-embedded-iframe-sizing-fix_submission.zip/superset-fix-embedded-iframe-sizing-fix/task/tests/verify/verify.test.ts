// @ts-nocheck
/**
 * Behavioral checks for the embedded dashboard's content-height measurement.
 *
 * These exercise the pre-existing public `embeddedApi.getScrollSize()` export —
 * the call a host uses to size an auto-sizing iframe — and observe its return
 * value. They never import a newly introduced symbol, module, or constant. The
 * page is laid out with the `dashboard-grid` marker the live DashboardGrid
 * already renders (pre-existing), and the height sources are modeled with
 * Object.defineProperty because jsdom performs no real layout.
 *
 * Two geometry models are used:
 *
 *  - "filled": the dashboard is laid out and fills its frame. The measured body
 *    height tracks the current frame WHILE the fill constraints are present on
 *    the root/body/#app, and reveals a fixed, true content height only once those
 *    constraints are lifted (inline height:auto / min-height:0). A read that
 *    reports the frame it was handed therefore grows without bound as a host
 *    re-applies it; a read that lifts-then-measures reports the content and
 *    settles.
 *
 *  - "pre-layout": the grid has not mounted, so the body carries only chrome
 *    height — a small value, far below the frame. Reporting that would let a
 *    content-fit host collapse the embed with no recovery, so the reported value
 *    must be a frame-independent source instead (not the small body height).
 */

// Mock factories build their own jest.fn()s: jest.mock is hoisted above these
// declarations, so a factory closing over a const would read it uninitialized.
jest.mock('@apache-superset/core/utils', () => ({
  logging: { debug: jest.fn(), warn: jest.fn(), error: jest.fn() },
}));

jest.mock('../views/store', () => ({
  store: { dispatch: jest.fn(), getState: jest.fn(), subscribe: jest.fn() },
}));

// eslint-disable-next-line import/first
import { embeddedApi } from './api';

const { store: mockStore } = jest.requireMock('../views/store');
const mockGetState = mockStore.getState;

// Pre-existing marker the live DashboardGrid renders on its grid div; a mounted
// grid is the dashboard's "laid out" signal.
const GRID_CLASS = 'dashboard-grid';

const root = () => document.documentElement;
const body = () => document.body;
const appEl = () => document.getElementById('app') as HTMLElement;

function mountDom({ gridMounted = true }: { gridMounted?: boolean } = {}) {
  document.body.innerHTML = `
    <div id="app">
      <div class="dashboard">
        ${gridMounted ? `<div class="${GRID_CLASS}"></div>` : ''}
      </div>
    </div>`;
}

// A fill element counts as "lifted" once its inline height is auto/clear AND its
// inline min-height is 0/clear — exactly the neutralization a correct read does
// before measuring. Until then it is constraining the body to the frame.
function constraintsLifted(els: HTMLElement[]) {
  return els.every(el => {
    const h = el.style.height;
    const mh = el.style.minHeight;
    const hClear = h === '' || h === 'auto';
    const mhClear = mh === '' || mh === '0' || mh === '0px';
    return hClear && mhClear;
  });
}

/**
 * Lay out a dashboard that fills its frame. `frameRef.value` is the frame height
 * a host has imposed. body.scrollHeight tracks that frame while the fill
 * constraints are present and reveals `content` once they are lifted.
 */
function layOutFilled({
  content,
  frameRef,
  frameIndependent = 10000,
}: {
  content: number;
  frameRef: { value: number };
  frameIndependent?: number;
}) {
  mockGetState.mockReturnValue({ dashboardInfo: { id: 1 } });
  mountDom({ gridMounted: true });

  const fillEls = [root(), body(), appEl()];
  // Seed the fill constraints so the body fills its frame until a read lifts them.
  fillEls.forEach(el => {
    el.style.minHeight = '100vh';
  });

  Object.defineProperty(body(), 'scrollHeight', {
    configurable: true,
    get: () => (constraintsLifted(fillEls) ? content : frameRef.value),
  });
  Object.defineProperty(body(), 'scrollWidth', {
    configurable: true,
    get: () => 1000,
  });
  // A frame-independent source, distinct from both the frame and the content, so
  // if the early guard ever fired here it would be visibly wrong.
  Object.defineProperty(root(), 'clientHeight', {
    configurable: true,
    get: () => frameIndependent,
  });
}

/**
 * Lay out the pre-layout window: the grid is absent (or the store un-hydrated),
 * so the body has only a small chrome height. The frame-independent source
 * (clientHeight and innerHeight, stubbed to the same value so either may be
 * read) is distinct from that small body height.
 */
function layOutPreLayout({
  smallBody,
  frameIndependent,
  hydrated = true,
  gridMounted = true,
}: {
  smallBody: number;
  frameIndependent: number;
  hydrated?: boolean;
  gridMounted?: boolean;
}) {
  mockGetState.mockReturnValue(hydrated ? { dashboardInfo: { id: 1 } } : {});
  mountDom({ gridMounted });

  Object.defineProperty(body(), 'scrollHeight', {
    configurable: true,
    get: () => smallBody,
  });
  Object.defineProperty(body(), 'scrollWidth', {
    configurable: true,
    get: () => 1000,
  });
  Object.defineProperty(root(), 'clientHeight', {
    configurable: true,
    get: () => frameIndependent,
  });
  Object.defineProperty(window, 'innerHeight', {
    configurable: true,
    writable: true,
    value: frameIndependent,
  });
}

afterEach(() => {
  document.body.innerHTML = '';
  document.documentElement.removeAttribute('style');
  document.body.removeAttribute('style');
  jest.clearAllMocks();
});

describe('embeddedApi.getScrollSize reports a frame-independent content height', () => {
  // fail_to_pass — the core feedback loop. A host applies the reported height,
  // enlarging the frame, and polls again; the answer must describe the content,
  // not the enlarged frame, or the iframe never settles.
  test('getScrollSize reports content height independent of the frame', () => {
    const frameRef = { value: 800 };
    layOutFilled({ content: 1600, frameRef });

    const first = embeddedApi.getScrollSize().height;

    // The host grew the frame to the height just reported and polls again.
    frameRef.value = 2400;
    const second = embeddedApi.getScrollSize().height;

    // A frame-dependent read returns the (now larger) frame and diverges; a
    // correct read returns the fixed content height both times.
    expect(first).toBe(1600);
    expect(second).toBe(1600);
    expect(second).toBe(first);
  });

  // fail_to_pass — pre-layout guard, store not hydrated. Reporting the small body
  // height would let a content-fit host collapse the embed, so the value must be
  // frame-independent and must NOT be the body height.
  test('getScrollSize returns a frame-independent height before the dashboard hydrates', () => {
    layOutPreLayout({ smallBody: 120, frameIndependent: 650, hydrated: false });

    const height = embeddedApi.getScrollSize().height;

    expect(height).toBe(650);
    expect(height).not.toBe(120);
  });

  // fail_to_pass — pre-layout guard, grid not mounted. The chrome alone has
  // height, so a hydrated store is not sufficient; a mounted grid is the
  // "laid out" signal.
  test('getScrollSize returns a frame-independent height until the grid is mounted', () => {
    layOutPreLayout({ smallBody: 120, frameIndependent: 650, gridMounted: false });

    const height = embeddedApi.getScrollSize().height;

    expect(height).toBe(650);
    expect(height).not.toBe(120);
  });

  // fail_to_pass — the measurement temporarily mutates live inline styles to read
  // the content height and must restore every one it touched, leaving the running
  // page untouched.
  test('getScrollSize restores every inline style it lifts', () => {
    const frameRef = { value: 800 };
    layOutFilled({ content: 1600, frameRef });

    // Seed known inline values on top of the baseline the layout established.
    root().style.height = '100%';
    body().style.height = '';
    appEl().style.height = '100%';

    embeddedApi.getScrollSize();

    // height: restored to whatever each element had (100% / '' / 100%).
    expect(root().style.height).toBe('100%');
    expect(body().style.height).toBe('');
    expect(appEl().style.height).toBe('100%');
    // min-height: the layout seeded 100vh on every fill element; all restored.
    expect(root().style.minHeight).toBe('100vh');
    expect(body().style.minHeight).toBe('100vh');
    expect(appEl().style.minHeight).toBe('100vh');
  });

  // fail_to_pass — restoration must survive a throw during the read, so a failure
  // mid-measurement cannot leave the live layout permanently mutated.
  test('getScrollSize restores inline styles even if the read throws', () => {
    const frameRef = { value: 800 };
    layOutFilled({ content: 1600, frameRef });

    root().style.height = '100%';

    // Force the content read itself to throw.
    Object.defineProperty(body(), 'scrollHeight', {
      configurable: true,
      get: () => {
        throw new Error('measurement blew up');
      },
    });

    expect(() => embeddedApi.getScrollSize()).toThrow();

    // The seeded/baseline values are back despite the throw.
    expect(root().style.height).toBe('100%');
    expect(root().style.minHeight).toBe('100vh');
    expect(body().style.minHeight).toBe('100vh');
  });
});
