// @ts-nocheck
/**
 * Behavioral checks for the vertical filter bar's layout inside an embed.
 *
 * The bar is the pre-existing VerticalFilterBar component. These render it with
 * the embedded gate (isEmbedded) stubbed true and false and observe the style
 * rules it emits, via @emotion/jest's toHaveStyleRule. They assert the OBSERVABLE
 * contract — the bar is bounded to its content so the action buttons stay
 * reachable (embedded) versus the bar fills its frame as before (standalone) —
 * not any particular class name or flex expression. The embed gate is the only
 * control knob; the heavy filter children are mocked so the render stays focused
 * on the bar's own styling.
 */
import { render } from 'spec/helpers/testing-library';

// isEmbedded is the pre-existing gate every embed-specific branch reads; stub it
// so a single render exercises the embedded or standalone layout on demand.
jest.mock('src/dashboard/util/isEmbedded', () => ({
  isEmbedded: jest.fn(() => false),
}));

// Keep the render focused on the bar's own container styling: the filter list,
// header, and cross/url filter subtrees are unrelated to the layout contract and
// pull in large dependency graphs.
jest.mock(
  'src/dashboard/components/nativeFilters/FilterBar/Header',
  () => ({
    __esModule: true,
    default: () => null,
  }),
);
jest.mock(
  'src/dashboard/components/nativeFilters/FilterBar/FilterControls/FilterControls',
  () => ({
    __esModule: true,
    default: () => <div data-test="mock-filter-controls" />,
  }),
);
jest.mock(
  'src/dashboard/components/nativeFilters/FilterBar/CrossFilters/Vertical',
  () => ({
    __esModule: true,
    default: () => null,
  }),
);
jest.mock(
  'src/dashboard/components/nativeFilters/FilterBar/UrlFilters/Vertical',
  () => ({
    __esModule: true,
    default: () => null,
  }),
);

// eslint-disable-next-line import/first
import { stateWithoutNativeFilters } from 'spec/fixtures/mockStore';
// eslint-disable-next-line import/first
import { isEmbedded } from 'src/dashboard/util/isEmbedded';
// eslint-disable-next-line import/first
import VerticalFilterBar from 'src/dashboard/components/nativeFilters/FilterBar/Vertical';

// Reuse the pre-existing, complete dashboard fixture the sibling FilterBar tests
// use. It carries a valid `dashboardLayout` (the redux-undo { past, present,
// future } history shape) and the slice/datasource/dataMask slices the real
// store reducers expect, so building a live store from it does not crash — a
// hand-rolled partial state omits the undo-history arrays and blows up in the
// layout reducer. It is a stable test fixture, not a solution detail.
const initialState = stateWithoutNativeFilters;

const baseProps = {
  actions: null,
  canEdit: true,
  dataMaskSelected: {},
  filtersOpen: true,
  // One native filter so the initialized bar renders its filter-list wrapper.
  filterValues: [{ id: 'f1', name: 'Filter 1' }],
  chartCustomizationValues: [],
  height: 900,
  isInitialized: true,
  offset: 0,
  onSelectionChange: jest.fn(),
  onPendingCustomizationDataMaskChange: jest.fn(),
  toggleFiltersBar: jest.fn(),
  width: 320,
  mobileMode: false,
};

const renderBar = (overrides = {}) =>
  render(<VerticalFilterBar {...baseProps} {...overrides} />, {
    useRedux: true,
    useRouter: true,
    useTheme: true,
    initialState,
  });

// The open bar is the `.open` descendant of the filter-bar wrapper that the
// component always renders (the wrapper itself carries data-test="filter-bar";
// only the inner bar div is a descendant with the `open` class while the panel
// is open). Selecting it structurally — rather than by an embed-specific class —
// keeps the check agnostic to whatever marker a solution puts on the embedded
// variant.
const openBar = (container: HTMLElement) =>
  container.querySelector('[data-test="filter-bar"] .open');

afterEach(() => {
  (isEmbedded as jest.Mock).mockReturnValue(false);
  jest.clearAllMocks();
});

describe('vertical filter bar layout', () => {
  // pass_to_pass — standalone must not regress: the bar keeps its fill-the-frame
  // sizing (min-height: 100%) when not embedded.
  test('standalone bar keeps its full-height sizing', () => {
    (isEmbedded as jest.Mock).mockReturnValue(false);

    const { container } = renderBar();
    const bar = openBar(container);

    expect(bar).toBeTruthy();
    // Fills its frame as before.
    expect(bar).toHaveStyleRule('min-height', '100%');
  });

  // fail_to_pass — in an embed the bar is bounded to its content (it no longer
  // fills the frame) so the Apply/Clear buttons, which follow the filter list,
  // stay reachable rather than being pushed to the bottom of an oversized frame.
  test('embedded bar is bounded to its content, not the frame', () => {
    (isEmbedded as jest.Mock).mockReturnValue(true);

    const { container } = renderBar();
    const bar = openBar(container);

    expect(bar).toBeTruthy();
    // The fill-the-frame constraint is gone: the bar no longer stretches to the
    // frame height.
    expect(bar).not.toHaveStyleRule('min-height', '100%');
    // And it is capped so it never grows past the frame — any max-height value
    // satisfies "bounded"; the exact value/source is the solution's choice.
    expect(bar).toHaveStyleRule('max-height', /\S/);
  });
});
