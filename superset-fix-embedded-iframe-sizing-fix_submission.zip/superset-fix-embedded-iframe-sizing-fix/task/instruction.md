## Task

a customer embedding one of our dashboards in an auto-sizing iframe reports that the frame keeps growing on its own. their host measures the content height and resizes the iframe to match, but each measurement comes back larger than the last, so the frame never settles and just keeps stretching. this used to work fine and now it's clearly broken.

two more things show up on the same embedded dashboards. when there's a vertical filter bar, the apply and clear buttons get pushed far below the last filter, off the visible part of the frame, so you can't reach them. and a stray horizontal scrollbar shows up on the page when the filter bar is open at narrower widths, the whole thing scrolls sideways by a sliver.

this is all specific to the embedded case, the standalone dashboard behaves fine and should stay that way. dig in, find the root cause, and fix it.
