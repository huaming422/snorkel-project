#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# No services to start, no data to seed: the image pre-warms the cargo registry
# cache and compiles the workspace at the base commit, and the verifier /
# validation harness build from that cache. Fail fast offline on a cache miss.
cd /repo/turso
export CARGO_NET_OFFLINE=true

# Dependencies: offline-first against the image bake, logged online fallback.
# The base-commit lockfile (plus the serde/serde_json dev-deps the image added
# to tests/Cargo.toml) is already fetched into $CARGO_HOME; this is a no-op when
# the bake is fresh.
if cargo fetch --locked --offline > /tmp/test-setup-fetch.log 2>&1; then
    echo "[offline-first] cargo deps satisfied from image"
elif cargo fetch --locked >> /tmp/test-setup-fetch.log 2>&1; then
    echo "[test-setup] cargo deps fetched online (image bake was stale)"
else
    tail -40 /tmp/test-setup-fetch.log >&2; exit 1
fi

echo "[test-setup] Rust version:    $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:   $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root:  /repo/turso"
echo "[test-setup] Setup complete."
