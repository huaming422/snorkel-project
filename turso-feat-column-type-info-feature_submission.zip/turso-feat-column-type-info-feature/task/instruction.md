## Task

We're building out an experimental custom-type system in the engine (`CREATE TYPE` and `CREATE DOMAIN`, behind a feature flag), and the layers above us need richer result-column type information than the plain SQLite decltype string carries. The Postgres-wire frontend is the first consumer, and decltype alone isn't enough for it to describe a prepared statement's result columns.

We want a single, custom-type-aware way to ask a prepared statement for a result column's type metadata, available both in the core Rust API and through the sdk-kit C ABI, as part of the experimental custom-types surface. It's a new accessor that sits alongside the existing SQLite-compatible decltype path rather than replacing it.

## User stories / requirements

- Asking a prepared statement for the type metadata of a result column that comes from a table column declared with a built-in type reports the declared type name, the column's array depth, and a built-in classification, with no underlying base type. A column declared as an array reports its array dimensionality.
- When a result column comes from a table column whose declared type is a registered custom type, domain, struct, or union, the metadata resolves that declared name through the custom-type registry and reports the underlying base primitive along with the matching classification. A domain reports the primitive it resolves to as its base type.
- A `SELECT *` yields one result column per table column, and the metadata accessor resolves each expanded position to its own originating table column, reporting that column's individual declared name, array depth, base type, and classification. Star expansion is not a single opaque column.
- For a computed result column (for example `SELECT 1 + 1` or `SELECT a || b`), the metadata infers a primitive from the expression shape: arithmetic widens (two integers stay integer, any real operand gives real, else numeric); concatenation gives text; bitwise, comparison, and logical operators give integer; rowid gives integer.
- When no usable type can be worked out for a result column, the metadata reports that there is no information rather than guessing a type. A BLOB or NULL literal is one such case and yields no information.
- The metadata accessor is part of the experimental custom-types surface, so asking for type information on a connection that does not have the experimental custom-types feature enabled does not succeed.
- Through the sdk-kit C ABI, a caller reads each piece of the metadata with its own getter (declared name, array dimensions, base type, kind). The kind getter returns a stable integer classification plus a distinct no-information sentinel for columns with no type information. The other getters report the same values as the core accessor.
