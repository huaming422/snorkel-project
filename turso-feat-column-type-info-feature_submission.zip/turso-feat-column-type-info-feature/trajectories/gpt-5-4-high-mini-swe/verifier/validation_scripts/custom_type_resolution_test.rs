mod validation_params;
use validation_params::{get_validation_test_cases, TestCase};

use core_tester::common::TempDatabase;
use turso_core::{DatabaseOpts, ResultColumnTypeKind};

#[test]
fn test_custom_type_resolution() {
    let cases = get_validation_test_cases();

    // We'll collect (kind_str, kind_value) for cross-case check
    let mut observed_kinds: Vec<(String, ResultColumnTypeKind)> = Vec::new();

    for tc in &cases {
        let setup_stmts = tc.inputs["setup"].as_array().unwrap();
        let query = tc.inputs["query"].as_str().unwrap();
        let col_idx = tc.inputs["col_idx"].as_u64().unwrap() as usize;

        let expected_declared_name = tc.expected["declared_name"].as_str().unwrap();
        let expected_array_dimensions = tc.expected["array_dimensions"].as_u64().unwrap() as u32;
        let expected_base_type = tc.expected["base_type"].as_str().unwrap();
        let expected_kind_str = tc.expected["kind"].as_str().unwrap();

        // Create fresh database + connection with custom types enabled
        let opts = DatabaseOpts::new().with_custom_types(true);
        let db = TempDatabase::builder().with_opts(opts).build();
        let conn = db.connect_limbo();

        // Run each setup statement
        for stmt_sql in setup_stmts {
            let sql = stmt_sql.as_str().unwrap();
            conn.execute(sql).unwrap_or_else(|e| {
                panic!("case {}: setup failed for {:?}: {}", tc.name, sql, e)
            });
        }

        // Prepare the query and get metadata
        let stmt = conn.prepare(query).unwrap_or_else(|e| {
            panic!("case {}: prepare failed for {:?}: {}", tc.name, query, e)
        });

        let metadata = stmt
            .get_column_type_metadata(col_idx)
            .unwrap_or_else(|e| panic!("case {}: metadata lookup error: {}", tc.name, e))
            .unwrap_or_else(|| panic!("case {}: expected metadata to be present, got None", tc.name));

        // EXPECTED: declared_name (case-insensitive)
        assert_eq!(
            metadata.declared_name.to_lowercase(),
            expected_declared_name.to_lowercase(),
            "case {}: declared_name mismatch",
            tc.name
        );

        // EXPECTED: array_dimensions
        assert_eq!(
            metadata.array_dimensions,
            expected_array_dimensions,
            "case {}: array_dimensions mismatch",
            tc.name
        );

        // EXPECTED: base_type (should not be __none__ for custom type resolution)
        let base = metadata.base_type.as_deref().unwrap_or_else(|| {
            panic!("case {}: expected base_type {:?}, got None", tc.name, expected_base_type)
        });
        assert_eq!(
            base.to_lowercase(),
            expected_base_type.to_lowercase(),
            "case {}: base_type mismatch",
            tc.name
        );

        // EXPECTED: kind
        let expected_kind = match expected_kind_str {
            "builtin" => ResultColumnTypeKind::Builtin,
            "custom" => ResultColumnTypeKind::Custom,
            "domain" => ResultColumnTypeKind::Domain,
            "struct" => ResultColumnTypeKind::Struct,
            "union" => ResultColumnTypeKind::Union,
            other => panic!("case {}: unknown kind {:?}", tc.name, other),
        };
        assert_eq!(
            metadata.kind,
            expected_kind,
            "case {}: kind mismatch",
            tc.name
        );

        observed_kinds.push((expected_kind_str.to_string(), metadata.kind));
    }

    // CROSS-CASE: collect kinds for custom, domain, struct, union
    let custom_kind = observed_kinds.iter().find(|(s, _)| s == "custom").map(|(_, k)| *k);
    let domain_kind = observed_kinds.iter().find(|(s, _)| s == "domain").map(|(_, k)| *k);
    let struct_kind = observed_kinds.iter().find(|(s, _)| s == "struct").map(|(_, k)| *k);
    let union_kind = observed_kinds.iter().find(|(s, _)| s == "union").map(|(_, k)| *k);

    // All four must be present for a meaningful cross-case check
    if let (Some(ck), Some(dk), Some(sk), Some(uk)) = (custom_kind, domain_kind, struct_kind, union_kind) {
        // Pairwise distinct among custom, domain, struct, union
        assert_ne!(ck, dk, "custom and domain must differ");
        assert_ne!(ck, sk, "custom and struct must differ");
        assert_ne!(ck, uk, "custom and union must differ");
        assert_ne!(dk, sk, "domain and struct must differ");
        assert_ne!(dk, uk, "domain and union must differ");
        assert_ne!(sk, uk, "struct and union must differ");

        // None equals the builtin classification
        assert_ne!(ck, ResultColumnTypeKind::Builtin, "custom must differ from builtin");
        assert_ne!(dk, ResultColumnTypeKind::Builtin, "domain must differ from builtin");
        assert_ne!(sk, ResultColumnTypeKind::Builtin, "struct must differ from builtin");
        assert_ne!(uk, ResultColumnTypeKind::Builtin, "union must differ from builtin");
    }
}
