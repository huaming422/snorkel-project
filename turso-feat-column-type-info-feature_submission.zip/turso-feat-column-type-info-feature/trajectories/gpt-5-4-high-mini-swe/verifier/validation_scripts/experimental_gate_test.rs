mod validation_params;
use validation_params::{get_validation_test_cases, TestCase};

use core_tester::common::TempDatabase;
use turso_core::DatabaseOpts;

#[test]
fn test_experimental_gate() {
    let cases = get_validation_test_cases();

    for tc in &cases {
        let custom_types_enabled = tc.inputs["custom_types"].as_u64().unwrap() == 1;
        let setup_stmts = tc.inputs["setup"].as_array().unwrap();
        let query = tc.inputs["query"].as_str().unwrap();
        let col_idx = tc.inputs["col_idx"].as_u64().unwrap() as usize;

        let expected_outcome = tc.expected["outcome"].as_str().unwrap();

        // Create fresh database + connection
        let db = if custom_types_enabled {
            let opts = DatabaseOpts::new().with_custom_types(true);
            TempDatabase::builder().with_opts(opts).build()
        } else {
            TempDatabase::new_empty()
        };
        let conn = db.connect_limbo();

        // Run each setup statement
        for stmt_sql in setup_stmts {
            let sql = stmt_sql.as_str().unwrap();
            conn.execute(sql).unwrap_or_else(|e| {
                panic!("case {}: setup failed for {:?}: {}", tc.name, sql, e)
            });
        }

        // Prepare the query and ask for metadata
        let stmt = conn.prepare(query).unwrap_or_else(|e| {
            panic!("case {}: prepare failed for {:?}: {}", tc.name, query, e)
        });

        let result = stmt.get_column_type_metadata(col_idx);

        // EXPECTED: outcome
        match expected_outcome {
            "error" => {
                // The accessor must fail (return an error)
                assert!(
                    result.is_err(),
                    "case {}: expected an error when custom types not enabled, got Ok({:?})",
                    tc.name,
                    result.ok()
                );
            }
            "ok" => {
                // The accessor must succeed and report type information
                let metadata = result
                    .unwrap_or_else(|e| panic!("case {}: expected ok, got error: {}", tc.name, e))
                    .unwrap_or_else(|| panic!("case {}: expected info, got None", tc.name));
                // Just verify it succeeded - no further field assertions specified
                let _ = metadata;
            }
            other => panic!("case {}: unknown outcome {:?}", tc.name, other),
        }
    }
}
