mod validation_params;
use validation_params::{get_validation_test_cases, TestCase};

use turso_sdk_kit::capi;
use turso_sdk_kit::capi::c;
use turso_sdk_kit::capi::c::turso_result_column_type_kind_t;
use std::ffi::{CStr, CString};

// Integer values from the patch (bindings.rs, #[repr(i32)]):
// TURSO_RESULT_COLUMN_TYPE_KIND_ERROR = -2
// TURSO_RESULT_COLUMN_TYPE_KIND_NONE  = -1
// TURSO_RESULT_COLUMN_TYPE_KIND_BUILTIN = 0
// TURSO_RESULT_COLUMN_TYPE_KIND_CUSTOM  = 1
// TURSO_RESULT_COLUMN_TYPE_KIND_DOMAIN  = 2
// TURSO_RESULT_COLUMN_TYPE_KIND_STRUCT  = 3
// TURSO_RESULT_COLUMN_TYPE_KIND_UNION   = 4

fn kind_to_i32(k: turso_result_column_type_kind_t) -> i32 {
    k as i32
}

fn expected_kind_enum(kind_str: &str) -> turso_result_column_type_kind_t {
    match kind_str {
        "builtin" => turso_result_column_type_kind_t::TURSO_RESULT_COLUMN_TYPE_KIND_BUILTIN,
        "custom"  => turso_result_column_type_kind_t::TURSO_RESULT_COLUMN_TYPE_KIND_CUSTOM,
        "domain"  => turso_result_column_type_kind_t::TURSO_RESULT_COLUMN_TYPE_KIND_DOMAIN,
        "struct"  => turso_result_column_type_kind_t::TURSO_RESULT_COLUMN_TYPE_KIND_STRUCT,
        "union"   => turso_result_column_type_kind_t::TURSO_RESULT_COLUMN_TYPE_KIND_UNION,
        "none"    => turso_result_column_type_kind_t::TURSO_RESULT_COLUMN_TYPE_KIND_NONE,
        other     => panic!("unknown kind in test spec: {:?}", other),
    }
}

#[test]
fn test_c_abi_kind_contract() {
    let cases = get_validation_test_cases();

    // Collect kind integers per classification for CROSS-CASE check
    let mut builtin_int: Option<i32> = None;
    let mut custom_int:  Option<i32> = None;
    let mut domain_int:  Option<i32> = None;
    let mut struct_int:  Option<i32> = None;
    let mut union_int:   Option<i32> = None;
    let mut none_ints:   Vec<i32>    = Vec::new();

    for (case_idx, tc) in cases.iter().enumerate() {
        let custom_types_flag = tc.inputs["custom_types"].as_u64().unwrap() == 1;
        let setup_stmts = tc.inputs["setup"].as_array().unwrap();
        let query = tc.inputs["query"].as_str().unwrap();
        let col_idx = tc.inputs["col_idx"].as_u64().unwrap() as usize;

        let expected_kind_str = tc.expected["kind"].as_str().unwrap();
        let expected_array_dimensions = tc.expected["array_dimensions"].as_u64().unwrap() as u32;
        let expected_declared_name = tc.expected["declared_name"].as_str().unwrap();
        let expected_base_type = tc.expected["base_type"].as_str().unwrap();

        unsafe {
            // 1. Build sdk-kit database + connection via raw C ABI
            let path = CString::new(":memory:").unwrap();
            // Keep features_str alive for the duration of the config
            let features_str = CString::new("custom_types").unwrap();
            let config = c::turso_database_config_t {
                path: path.as_ptr(),
                experimental_features: if custom_types_flag {
                    features_str.as_ptr()
                } else {
                    std::ptr::null()
                },
                ..Default::default()
            };

            let mut db = std::ptr::null();
            let status = capi::turso_database_new(&config, &mut db, std::ptr::null_mut());
            assert_eq!(
                status,
                c::turso_status_code_t::TURSO_OK,
                "case {}: turso_database_new failed",
                case_idx
            );

            let status = capi::turso_database_open(db, std::ptr::null_mut());
            assert_eq!(
                status,
                c::turso_status_code_t::TURSO_OK,
                "case {}: turso_database_open failed",
                case_idx
            );

            let mut connection = std::ptr::null_mut();
            let status = capi::turso_database_connect(db, &mut connection, std::ptr::null_mut());
            assert_eq!(
                status,
                c::turso_status_code_t::TURSO_OK,
                "case {}: turso_database_connect failed",
                case_idx
            );

            // 2. Run each setup statement via raw C ABI
            for stmt_sql in setup_stmts {
                let sql_str = stmt_sql.as_str().unwrap();
                let sql_cstr = CString::new(sql_str).unwrap();
                let mut setup_stmt = std::ptr::null_mut();
                let status = capi::turso_connection_prepare_single(
                    connection,
                    sql_cstr.as_ptr(),
                    &mut setup_stmt,
                    std::ptr::null_mut(),
                );
                assert_eq!(
                    status,
                    c::turso_status_code_t::TURSO_OK,
                    "case {}: setup prepare_single failed for {:?}",
                    case_idx,
                    sql_str
                );
                let status = capi::turso_statement_execute(
                    setup_stmt,
                    std::ptr::null_mut(),
                    std::ptr::null_mut(),
                );
                assert_eq!(
                    status,
                    c::turso_status_code_t::TURSO_DONE,
                    "case {}: setup execute failed for {:?}",
                    case_idx,
                    sql_str
                );
                capi::turso_statement_deinit(setup_stmt);
            }

            // 3. Prepare query and obtain C statement pointer
            let query_cstr = CString::new(query).unwrap();
            let mut statement = std::ptr::null_mut();
            let status = capi::turso_connection_prepare_single(
                connection,
                query_cstr.as_ptr(),
                &mut statement,
                std::ptr::null_mut(),
            );
            assert_eq!(
                status,
                c::turso_status_code_t::TURSO_OK,
                "case {}: query prepare_single failed for {:?}",
                case_idx,
                query
            );

            // 4. EXPECTED: kind
            let kind_val = capi::turso_statement_column_type_kind(statement, col_idx);
            let kind_int = kind_to_i32(kind_val);
            let expected_kind = expected_kind_enum(expected_kind_str);
            let expected_int = kind_to_i32(expected_kind);
            assert_eq!(
                kind_int,
                expected_int,
                "case {}: kind integer mismatch for {:?} (got {}, want {})",
                case_idx,
                expected_kind_str,
                kind_int,
                expected_int
            );

            // Record for cross-case check
            match expected_kind_str {
                "builtin" => builtin_int = Some(kind_int),
                "custom"  => custom_int  = Some(kind_int),
                "domain"  => domain_int  = Some(kind_int),
                "struct"  => struct_int  = Some(kind_int),
                "union"   => union_int   = Some(kind_int),
                "none"    => none_ints.push(kind_int),
                _ => {}
            }

            // 5. EXPECTED: declared_name
            if expected_declared_name != "__skip__" {
                let dn_ptr = capi::turso_statement_column_type_declared_name(statement, col_idx);
                assert!(
                    !dn_ptr.is_null(),
                    "case {}: declared_name pointer is null, expected {:?}",
                    case_idx,
                    expected_declared_name
                );
                let dn_str = CStr::from_ptr(dn_ptr).to_str().unwrap();
                assert_eq!(
                    dn_str.to_lowercase(),
                    expected_declared_name.to_lowercase(),
                    "case {}: declared_name mismatch",
                    case_idx
                );
                capi::turso_str_deinit(dn_ptr);
            }

            // 6. EXPECTED: array_dimensions
            let dims = capi::turso_statement_column_type_array_dimensions(statement, col_idx);
            assert_eq!(
                dims,
                expected_array_dimensions,
                "case {}: array_dimensions mismatch",
                case_idx
            );

            // 7. EXPECTED: base_type
            if expected_base_type != "__skip__" {
                let bt_ptr = capi::turso_statement_column_type_base(statement, col_idx);
                assert!(
                    !bt_ptr.is_null(),
                    "case {}: base_type pointer is null, expected {:?}",
                    case_idx,
                    expected_base_type
                );
                let bt_str = CStr::from_ptr(bt_ptr).to_str().unwrap();
                assert_eq!(
                    bt_str.to_lowercase(),
                    expected_base_type.to_lowercase(),
                    "case {}: base_type mismatch",
                    case_idx
                );
                capi::turso_str_deinit(bt_ptr);
            }

            // 8. Free the C statement pointer
            capi::turso_statement_deinit(statement);

            // Free connection and database to avoid state leakage between cases
            capi::turso_connection_deinit(connection);
            capi::turso_database_deinit(db);
        }
    }

    // CROSS-CASE: assert kind integers for builtin, custom, domain, struct, union are pairwise distinct
    // and that none integers are distinct from all five classification integers.
    let bi = builtin_int.expect("no builtin case observed");
    let ci = custom_int.expect("no custom case observed");
    let di = domain_int.expect("no domain case observed");
    let si = struct_int.expect("no struct case observed");
    let ui = union_int.expect("no union case observed");

    assert_ne!(bi, ci, "builtin and custom must have distinct kind integers");
    assert_ne!(bi, di, "builtin and domain must have distinct kind integers");
    assert_ne!(bi, si, "builtin and struct must have distinct kind integers");
    assert_ne!(bi, ui, "builtin and union must have distinct kind integers");
    assert_ne!(ci, di, "custom and domain must have distinct kind integers");
    assert_ne!(ci, si, "custom and struct must have distinct kind integers");
    assert_ne!(ci, ui, "custom and union must have distinct kind integers");
    assert_ne!(di, si, "domain and struct must have distinct kind integers");
    assert_ne!(di, ui, "domain and union must have distinct kind integers");
    assert_ne!(si, ui, "struct and union must have distinct kind integers");

    for &ni in &none_ints {
        assert_ne!(ni, bi, "none sentinel must differ from builtin integer");
        assert_ne!(ni, ci, "none sentinel must differ from custom integer");
        assert_ne!(ni, di, "none sentinel must differ from domain integer");
        assert_ne!(ni, si, "none sentinel must differ from struct integer");
        assert_ne!(ni, ui, "none sentinel must differ from union integer");
    }
}
