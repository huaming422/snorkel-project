mod validation_params;
use validation_params::{get_validation_test_cases, TestCase};

use core_tester::common::TempDatabase;
use turso_core::DatabaseOpts;

#[test]
fn test_indeterminate_returns_none() {
    let cases = get_validation_test_cases();

    for tc in &cases {
        let setup_stmts = tc.inputs["setup"].as_array().unwrap();
        let query = tc.inputs["query"].as_str().unwrap();
        let col_idx = tc.inputs["col_idx"].as_u64().unwrap() as usize;

        let expected_outcome = tc.expected["outcome"].as_str().unwrap();
        let expected_primitive = tc.expected["primitive"].as_str().unwrap();

        // Create fresh database + connection with custom types enabled
        let opts = DatabaseOpts::new().with_custom_types(true);
        let db = TempDatabase::builder().with_opts(opts).build();
        let conn = db.connect_limbo();

        // Run each setup statement
        for stmt_sql in setup_stmts {
            let sql = stmt_sql.as_str().unwrap();
            conn.execute(sql).unwrap_or_else(|e| {
                panic!("case {}: setup failed for {:?}: {}", tc.name, sql, e)
            });
        }

        // Prepare the query - accessor must succeed (no error)
        let stmt = conn.prepare(query).unwrap_or_else(|e| {
            panic!("case {}: prepare failed for {:?}: {}", tc.name, query, e)
        });

        let result = stmt
            .get_column_type_metadata(col_idx)
            .unwrap_or_else(|e| panic!("case {}: metadata lookup error (should not error): {}", tc.name, e));

        // EXPECTED: outcome
        match expected_outcome {
            "none" => {
                // The accessor must report NO type information (None)
                assert!(
                    result.is_none(),
                    "case {}: expected no-info outcome (None), got Some({:?})",
                    tc.name,
                    result
                );
                // EXPECTED: primitive - "__skip__" for no-info cases, so we do not assert
                // (the spec says "when expected.primitive is __skip__, do not assert it")
                // We still verify the value is indeed __skip__ as documented in the spec
                assert_eq!(
                    expected_primitive,
                    "__skip__",
                    "case {}: expected primitive field to be __skip__ for no-info cases",
                    tc.name
                );
            }
            "info" => {
                // The accessor must report information
                let metadata = result.unwrap_or_else(|| {
                    panic!("case {}: expected info outcome, got None", tc.name)
                });

                // EXPECTED: primitive - assert the inferred primitive through declared_name surface
                // (discovered from patch: inferred_builtin puts primitive name in declared_name)
                if expected_primitive != "__skip__" {
                    assert_eq!(
                        metadata.declared_name.to_lowercase(),
                        expected_primitive.to_lowercase(),
                        "case {}: inferred primitive (declared_name) mismatch",
                        tc.name
                    );
                }
            }
            other => panic!("case {}: unknown outcome {:?}", tc.name, other),
        }
    }
}
