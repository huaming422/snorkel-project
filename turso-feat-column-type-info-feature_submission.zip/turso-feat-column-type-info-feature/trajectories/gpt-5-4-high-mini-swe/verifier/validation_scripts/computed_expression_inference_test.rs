mod validation_params;
use validation_params::{get_validation_test_cases, TestCase};

use core_tester::common::TempDatabase;
use turso_core::DatabaseOpts;

#[test]
fn test_computed_expression_inference() {
    let cases = get_validation_test_cases();

    for tc in &cases {
        let setup_stmts = tc.inputs["setup"].as_array().unwrap();
        let query = tc.inputs["query"].as_str().unwrap();
        let col_idx = tc.inputs["col_idx"].as_u64().unwrap() as usize;

        let expected_primitive = tc.expected["primitive"].as_str().unwrap();
        let expected_array_dimensions = tc.expected["array_dimensions"].as_u64().unwrap() as u32;
        let expected_base_type = tc.expected["base_type"].as_str().unwrap();

        // Create fresh database + connection with custom types enabled
        let opts = DatabaseOpts::new().with_custom_types(true);
        let db = TempDatabase::builder().with_opts(opts).build();
        let conn = db.connect_limbo();

        // Run each setup statement
        for stmt_sql in setup_stmts {
            let sql = stmt_sql.as_str().unwrap();
            conn.execute(sql).unwrap_or_else(|e| {
                panic!("case {}: setup failed for {:?}: {}", tc.name, sql, e)
            });
        }

        // Prepare the query and get metadata
        let stmt = conn.prepare(query).unwrap_or_else(|e| {
            panic!("case {}: prepare failed for {:?}: {}", tc.name, query, e)
        });

        // The accessor must succeed and return information (not no-info)
        let metadata = stmt
            .get_column_type_metadata(col_idx)
            .unwrap_or_else(|e| panic!("case {}: metadata lookup error: {}", tc.name, e))
            .unwrap_or_else(|| panic!("case {}: expected metadata to be present (got no-info)", tc.name));

        // EXPECTED: primitive - the implementation uses the declared-name surface:
        // inferred_builtin() puts the primitive name in `declared_name` with kind=Builtin.
        // Discovered from patch: ResultColumnTypeMetadata::inferred_builtin sets declared_name = canonical_type_name(ty).
        assert_eq!(
            metadata.declared_name.to_lowercase(),
            expected_primitive.to_lowercase(),
            "case {}: inferred primitive (declared_name) mismatch",
            tc.name
        );

        // EXPECTED: array_dimensions (0 for computed columns)
        assert_eq!(
            metadata.array_dimensions,
            expected_array_dimensions,
            "case {}: array_dimensions mismatch",
            tc.name
        );

        // EXPECTED: base_type - when "__none__", assert no base primitive
        if expected_base_type == "__none__" {
            assert!(
                metadata.base_type.is_none(),
                "case {}: expected no base_type, got {:?}",
                tc.name,
                metadata.base_type
            );
        } else {
            let base = metadata.base_type.as_deref().unwrap_or_else(|| {
                panic!("case {}: expected base_type {:?}, got None", tc.name, expected_base_type)
            });
            assert_eq!(
                base.to_lowercase(),
                expected_base_type.to_lowercase(),
                "case {}: base_type mismatch",
                tc.name
            );
        }
    }
}
