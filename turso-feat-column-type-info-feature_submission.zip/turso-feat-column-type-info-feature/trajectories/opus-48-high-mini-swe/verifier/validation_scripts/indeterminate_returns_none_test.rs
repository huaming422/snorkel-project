mod validation_params;
use validation_params::{get_validation_test_cases, TestCase};

#[test]
fn test_indeterminate_returns_none() {
    let cases = get_validation_test_cases();

    for tc in &cases {
        let setup = tc.inputs["setup"].as_array().unwrap();
        let query = tc.inputs["query"].as_str().unwrap();
        let col_idx = tc.inputs["col_idx"].as_u64().unwrap() as usize;

        let expected_outcome = tc.expected["outcome"].as_str().unwrap();
        let expected_primitive = tc.expected["primitive"].as_str().unwrap();

        // Build a fresh database with custom types enabled
        let opts = turso_core::DatabaseOpts::new().with_custom_types(true);
        let db = core_tester::common::TempDatabase::new_empty_with_opts(opts);
        let conn = db.connect_limbo();

        // Run setup statements
        for s in setup {
            let sql = s.as_str().unwrap();
            conn.execute(sql).unwrap_or_else(|e| panic!("case {}: setup '{}' failed: {:?}", tc.name, sql, e));
        }

        // Prepare query and get type metadata
        let stmt = conn.prepare(query).unwrap_or_else(|e| panic!("case {}: prepare '{}' failed: {:?}", tc.name, query, e));
        let meta_opt = stmt.get_column_type_metadata(col_idx);

        // EXPECTED: outcome
        match expected_outcome {
            "none" => {
                assert!(
                    meta_opt.is_none(),
                    "case {}: expected no type info (None), but got Some({:?}) for query '{}'",
                    tc.name, meta_opt, query
                );
                // EXPECTED: primitive - "__skip__" means don't assert primitive
                assert_eq!(expected_primitive, "__skip__", "case {}: expected_primitive should be '__skip__' for 'none' outcome", tc.name);
            }
            "info" => {
                let meta = meta_opt.unwrap_or_else(|| panic!("case {}: expected info, got None for query '{}'", tc.name, query));
                // EXPECTED: primitive - inferred primitive in declared_name
                assert_ne!(expected_primitive, "__skip__", "case {}: expected_primitive should not be '__skip__' for 'info' outcome", tc.name);
                assert_eq!(
                    meta.declared_name.to_lowercase(),
                    expected_primitive.to_lowercase(),
                    "case {}: inferred primitive mismatch: got '{}', expected '{}'",
                    tc.name, meta.declared_name, expected_primitive
                );
            }
            other => panic!("case {}: unexpected outcome '{}'", tc.name, other),
        }

        drop(stmt);
        conn.close().ok();
    }
}
