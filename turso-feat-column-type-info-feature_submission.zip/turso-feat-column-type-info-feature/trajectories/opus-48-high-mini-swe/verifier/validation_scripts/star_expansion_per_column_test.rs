mod validation_params;
use validation_params::{get_validation_test_cases, TestCase};

#[test]
fn test_star_expansion_per_column() {
    let cases = get_validation_test_cases();

    for tc in &cases {
        let setup = tc.inputs["setup"].as_array().unwrap();
        let query = tc.inputs["query"].as_str().unwrap();
        let col_idx = tc.inputs["col_idx"].as_u64().unwrap() as usize;

        let expected_declared_name = tc.expected["declared_name"].as_str().unwrap();
        let expected_array_dimensions = tc.expected["array_dimensions"].as_u64().unwrap() as u32;
        let expected_base_type = tc.expected["base_type"].as_str().unwrap();
        let expected_kind = tc.expected["kind"].as_str().unwrap();

        // Build a fresh database with custom types enabled
        let opts = turso_core::DatabaseOpts::new().with_custom_types(true);
        let db = core_tester::common::TempDatabase::new_empty_with_opts(opts);
        let conn = db.connect_limbo();

        // Run setup statements
        for s in setup {
            let sql = s.as_str().unwrap();
            conn.execute(sql).unwrap_or_else(|e| panic!("case {}: setup '{}' failed: {:?}", tc.name, sql, e));
        }

        // Prepare query (SELECT *) and get metadata for this expanded position
        let stmt = conn.prepare(query).unwrap_or_else(|e| panic!("case {}: prepare '{}' failed: {:?}", tc.name, query, e));
        let meta = stmt.get_column_type_metadata(col_idx).unwrap_or_else(|| panic!("case {}: get_column_type_metadata returned None at col {}, expected info", tc.name, col_idx));

        // EXPECTED: declared_name (case-insensitive)
        assert_eq!(
            meta.declared_name.to_lowercase(),
            expected_declared_name.to_lowercase(),
            "case {}: col {}: declared_name mismatch: got '{}', expected '{}'",
            tc.name, col_idx, meta.declared_name, expected_declared_name
        );

        // EXPECTED: array_dimensions
        assert_eq!(
            meta.array_dimensions,
            expected_array_dimensions,
            "case {}: col {}: array_dimensions mismatch: got {}, expected {}",
            tc.name, col_idx, meta.array_dimensions, expected_array_dimensions
        );

        // EXPECTED: base_type
        if expected_base_type == "__none__" {
            assert!(
                meta.base_type.is_none(),
                "case {}: col {}: expected no base_type, got {:?}",
                tc.name, col_idx, meta.base_type
            );
        } else {
            let actual_base = meta.base_type.as_deref().unwrap_or_else(|| panic!("case {}: col {}: expected base_type '{}', got None", tc.name, col_idx, expected_base_type));
            assert_eq!(
                actual_base.to_lowercase(),
                expected_base_type.to_lowercase(),
                "case {}: col {}: base_type mismatch: got '{}', expected '{}'",
                tc.name, col_idx, actual_base, expected_base_type
            );
        }

        // EXPECTED: kind
        let expected_variant = match expected_kind {
            "builtin" => turso_core::ColumnTypeKind::Builtin,
            "custom"  => turso_core::ColumnTypeKind::Custom,
            "domain"  => turso_core::ColumnTypeKind::Domain,
            "struct"  => turso_core::ColumnTypeKind::Struct,
            "union"   => turso_core::ColumnTypeKind::Union,
            other     => panic!("case {}: col {}: unexpected kind label '{}'", tc.name, col_idx, other),
        };
        assert_eq!(
            meta.kind,
            expected_variant,
            "case {}: col {}: kind mismatch: got {:?}, expected {:?} (label '{}')",
            tc.name, col_idx, meta.kind, expected_variant, expected_kind
        );

        drop(stmt);
        conn.close().ok();
    }
}
