mod validation_params;
use validation_params::{get_validation_test_cases, TestCase};

use std::collections::HashMap;
use std::ffi::CStr;

use turso_sdk_kit::capi;
use turso_sdk_kit::capi::c::turso_column_type_kind_t;
use turso_sdk_kit::rsapi::{TursoDatabase, TursoDatabaseConfig};

// Map label string to the C enum variant
fn label_to_c_kind(label: &str) -> turso_column_type_kind_t {
    match label {
        "none"     => turso_column_type_kind_t::TURSO_COLUMN_TYPE_KIND_NONE,
        "builtin"  => turso_column_type_kind_t::TURSO_COLUMN_TYPE_KIND_BUILTIN,
        "custom"   => turso_column_type_kind_t::TURSO_COLUMN_TYPE_KIND_CUSTOM,
        "domain"   => turso_column_type_kind_t::TURSO_COLUMN_TYPE_KIND_DOMAIN,
        "struct"   => turso_column_type_kind_t::TURSO_COLUMN_TYPE_KIND_STRUCT,
        "union"    => turso_column_type_kind_t::TURSO_COLUMN_TYPE_KIND_UNION,
        "inferred" => turso_column_type_kind_t::TURSO_COLUMN_TYPE_KIND_INFERRED,
        other      => panic!("unexpected kind label '{}'", other),
    }
}

#[test]
fn test_c_abi_kind_contract() {
    let cases = get_validation_test_cases();

    // Collect all observed integer discriminants per label (multiple test cases
    // may share the same label, e.g. two 'builtin' and two 'none' cases).
    // We collect into a Vec per label so we can verify consistency (all cases
    // with the same label must produce the same integer) before the
    // pairwise-distinctness check.
    let mut observed_ints_by_label: HashMap<String, Vec<u32>> = HashMap::new();

    for tc in &cases {
        let custom_types_enabled = tc.inputs["custom_types"].as_u64().unwrap() == 1;
        let setup = tc.inputs["setup"].as_array().unwrap();
        let query = tc.inputs["query"].as_str().unwrap();
        let col_idx = tc.inputs["col_idx"].as_u64().unwrap() as usize;

        let expected_kind_label = tc.expected["kind"].as_str().unwrap();
        let expected_array_dimensions = tc.expected["array_dimensions"].as_u64().unwrap() as u32;
        let expected_declared_name = tc.expected["declared_name"].as_str().unwrap();
        let expected_base_type = tc.expected["base_type"].as_str().unwrap();

        // Build sdk-kit database
        let experimental_features = if custom_types_enabled {
            Some("custom_types".to_string())
        } else {
            None
        };
        let db = TursoDatabase::new(TursoDatabaseConfig {
            path: ":memory:".to_string(),
            experimental_features,
            async_io: false,
            encryption: None,
            vfs: None,
            io: None,
            db_file: None,
        });
        db.open().unwrap_or_else(|e| panic!("case {}: db.open() failed: {:?}", tc.name, e));
        let conn = db.connect().unwrap_or_else(|e| panic!("case {}: db.connect() failed: {:?}", tc.name, e));

        // Run setup statements
        for s in setup {
            let sql = s.as_str().unwrap();
            let mut s_stmt = conn.prepare_single(sql).unwrap_or_else(|e| panic!("case {}: setup prepare '{}' failed: {:?}", tc.name, sql, e));
            s_stmt.execute(None).unwrap_or_else(|e| panic!("case {}: setup execute '{}' failed: {:?}", tc.name, sql, e));
        }

        // Prepare query and get C statement pointer
        let stmt_box = conn.prepare_single(query).unwrap_or_else(|e| panic!("case {}: prepare '{}' failed: {:?}", tc.name, query, e));
        let ptr = stmt_box.to_capi();

        // EXPECTED: kind - call kind getter and compare against expected enum variant
        let actual_kind = unsafe { capi::turso_statement_column_type_kind(ptr, col_idx) };
        let expected_kind_variant = label_to_c_kind(expected_kind_label);
        assert_eq!(
            actual_kind,
            expected_kind_variant,
            "case {}: kind mismatch for label '{}': got {:?}, expected {:?}",
            tc.name, expected_kind_label, actual_kind, expected_kind_variant
        );
        // Record discriminant (as u32) for cross-case check
        // Multiple test cases may share the same label; they must all produce
        // the same integer, so we collect all into a Vec.
        observed_ints_by_label
            .entry(expected_kind_label.to_string())
            .or_default()
            .push(actual_kind as u32);

        // EXPECTED: declared_name - skip if "__skip__"
        if expected_declared_name != "__skip__" {
            let dn_ptr = unsafe { capi::turso_statement_column_type_declared_name(ptr, col_idx) };
            assert!(!dn_ptr.is_null(), "case {}: declared_name getter returned null, expected '{}'", tc.name, expected_declared_name);
            let dn_str = unsafe { CStr::from_ptr(dn_ptr).to_str().unwrap() }.to_string();
            assert_eq!(
                dn_str.to_lowercase(),
                expected_declared_name.to_lowercase(),
                "case {}: declared_name mismatch: got '{}', expected '{}'",
                tc.name, dn_str, expected_declared_name
            );
            unsafe { capi::turso_str_deinit(dn_ptr) };
        }

        // EXPECTED: array_dimensions - always assert
        let actual_dims = unsafe { capi::turso_statement_column_type_array_dimensions(ptr, col_idx) };
        assert_eq!(
            actual_dims,
            expected_array_dimensions,
            "case {}: array_dimensions mismatch: got {}, expected {}",
            tc.name, actual_dims, expected_array_dimensions
        );

        // EXPECTED: base_type - skip if "__skip__"
        if expected_base_type != "__skip__" {
            let bt_ptr = unsafe { capi::turso_statement_column_type_base_type(ptr, col_idx) };
            assert!(!bt_ptr.is_null(), "case {}: base_type getter returned null, expected '{}'", tc.name, expected_base_type);
            let bt_str = unsafe { CStr::from_ptr(bt_ptr).to_str().unwrap() }.to_string();
            assert_eq!(
                bt_str.to_lowercase(),
                expected_base_type.to_lowercase(),
                "case {}: base_type mismatch: got '{}', expected '{}'",
                tc.name, bt_str, expected_base_type
            );
            unsafe { capi::turso_str_deinit(bt_ptr) };
        }

        // Free statement
        unsafe { capi::turso_statement_deinit(ptr) };
    }

    // Verify that all cases with the same label produced the same integer
    // (e.g., both 'builtin' cases and both 'none' cases must agree).
    for (label, ints) in &observed_ints_by_label {
        let first = ints[0];
        for &v in &ints[1..] {
            assert_eq!(
                first, v,
                "cross-case: all '{}' cases must produce the same C kind integer, but got {} and {}",
                label, first, v
            );
        }
    }

    // Derive a single representative integer per label for the pairwise check.
    let representative: HashMap<&str, u32> = observed_ints_by_label
        .iter()
        .map(|(k, vs)| (k.as_str(), vs[0]))
        .collect();

    // CROSS-CASE: verify pairwise distinctness of schema-column classifications
    let schema_labels = ["builtin", "custom", "domain", "struct", "union"];
    let mut schema_ints: Vec<(&str, u32)> = Vec::new();
    for label in &schema_labels {
        if let Some(&int_val) = representative.get(label) {
            schema_ints.push((label, int_val));
        }
    }

    // Pairwise distinct among schema classifications
    for i in 0..schema_ints.len() {
        for j in (i + 1)..schema_ints.len() {
            assert_ne!(
                schema_ints[i].1, schema_ints[j].1,
                "cross-case: C kind integers for '{}' and '{}' must be DISTINCT, but both are {}",
                schema_ints[i].0, schema_ints[j].0, schema_ints[i].1
            );
        }
    }

    // "none" sentinel must be distinct from all schema classifications
    if let Some(&none_int) = representative.get("none") {
        for (label, int_val) in &schema_ints {
            assert_ne!(
                none_int, *int_val,
                "cross-case: 'none' sentinel ({}) must be DISTINCT from '{}' classification ({})",
                none_int, label, int_val
            );
        }
    }
}
