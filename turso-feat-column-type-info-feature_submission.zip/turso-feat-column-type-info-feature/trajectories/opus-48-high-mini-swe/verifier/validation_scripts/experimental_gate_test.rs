mod validation_params;
use validation_params::{get_validation_test_cases, TestCase};

#[test]
fn test_experimental_gate() {
    let cases = get_validation_test_cases();

    for tc in &cases {
        let custom_types_enabled = tc.inputs["custom_types"].as_u64().unwrap() == 1;
        let setup = tc.inputs["setup"].as_array().unwrap();
        let query = tc.inputs["query"].as_str().unwrap();
        let col_idx = tc.inputs["col_idx"].as_u64().unwrap() as usize;

        let expected_outcome = tc.expected["outcome"].as_str().unwrap();

        let db;
        let conn;
        if custom_types_enabled {
            // Custom types ON: use new_empty_with_opts with custom types enabled
            let opts = turso_core::DatabaseOpts::new().with_custom_types(true);
            db = core_tester::common::TempDatabase::new_empty_with_opts(opts);
            conn = db.connect_limbo();
        } else {
            // Custom types OFF: use new_empty_with_opts with custom types disabled
            let opts = turso_core::DatabaseOpts::new();
            db = core_tester::common::TempDatabase::new_empty_with_opts(opts);
            conn = db.connect_limbo();
        }

        // Run setup statements
        for s in setup {
            let sql = s.as_str().unwrap();
            conn.execute(sql).unwrap_or_else(|e| panic!("case {}: setup '{}' failed: {:?}", tc.name, sql, e));
        }

        // Prepare query and call the accessor
        let stmt = conn.prepare(query).unwrap_or_else(|e| panic!("case {}: prepare '{}' failed: {:?}", tc.name, query, e));
        let meta_opt = stmt.get_column_type_metadata(col_idx);

        // EXPECTED: outcome
        match expected_outcome {
            "error" => {
                // The accessor returns None when custom types are disabled
                assert!(
                    meta_opt.is_none(),
                    "case {}: expected accessor to fail (return None), but got Some({:?}) when custom_types={}",
                    tc.name, meta_opt, custom_types_enabled
                );
            }
            "ok" => {
                assert!(
                    meta_opt.is_some(),
                    "case {}: expected accessor to succeed (return Some), but got None for query '{}'",
                    tc.name, query
                );
            }
            other => panic!("case {}: unexpected outcome '{}'", tc.name, other),
        }

        drop(stmt);
        conn.close().ok();
    }
}
