mod validation_params;
use validation_params::{get_validation_test_cases, TestCase};

use std::collections::HashMap;

#[test]
fn test_custom_type_resolution() {
    let cases = get_validation_test_cases();

    // Collect kinds for cross-case check
    let mut kinds_by_label: HashMap<String, turso_core::ColumnTypeKind> = HashMap::new();

    for tc in &cases {
        let setup = tc.inputs["setup"].as_array().unwrap();
        let query = tc.inputs["query"].as_str().unwrap();
        let col_idx = tc.inputs["col_idx"].as_u64().unwrap() as usize;

        let expected_declared_name = tc.expected["declared_name"].as_str().unwrap();
        let expected_array_dimensions = tc.expected["array_dimensions"].as_u64().unwrap() as u32;
        let expected_base_type = tc.expected["base_type"].as_str().unwrap();
        let expected_kind = tc.expected["kind"].as_str().unwrap();

        // Build a fresh database with custom types enabled (no path argument)
        let opts = turso_core::DatabaseOpts::new().with_custom_types(true);
        let db = core_tester::common::TempDatabase::new_empty_with_opts(opts);
        let conn = db.connect_limbo();

        // Run setup statements
        for s in setup {
            let sql = s.as_str().unwrap();
            conn.execute(sql).unwrap_or_else(|e| panic!("case {}: setup '{}' failed: {:?}", tc.name, sql, e));
        }

        // Prepare query and get type metadata
        let stmt = conn.prepare(query).unwrap_or_else(|e| panic!("case {}: prepare '{}' failed: {:?}", tc.name, query, e));
        let meta = stmt.get_column_type_metadata(col_idx).unwrap_or_else(|| panic!("case {}: get_column_type_metadata returned None, expected info", tc.name));

        // EXPECTED: declared_name (case-insensitive)
        assert_eq!(
            meta.declared_name.to_lowercase(),
            expected_declared_name.to_lowercase(),
            "case {}: declared_name mismatch: got '{}', expected '{}'",
            tc.name, meta.declared_name, expected_declared_name
        );

        // EXPECTED: array_dimensions
        assert_eq!(
            meta.array_dimensions,
            expected_array_dimensions,
            "case {}: array_dimensions mismatch: got {}, expected {}",
            tc.name, meta.array_dimensions, expected_array_dimensions
        );

        // EXPECTED: base_type
        if expected_base_type == "__none__" {
            assert!(
                meta.base_type.is_none(),
                "case {}: expected no base_type, got {:?}",
                tc.name, meta.base_type
            );
        } else {
            let actual_base = meta.base_type.as_deref().unwrap_or_else(|| panic!("case {}: expected base_type '{}', got None", tc.name, expected_base_type));
            assert_eq!(
                actual_base.to_lowercase(),
                expected_base_type.to_lowercase(),
                "case {}: base_type mismatch: got '{}', expected '{}'",
                tc.name, actual_base, expected_base_type
            );
        }

        // EXPECTED: kind - map label to variant
        let expected_variant = match expected_kind {
            "custom" => turso_core::ColumnTypeKind::Custom,
            "domain" => turso_core::ColumnTypeKind::Domain,
            "struct" => turso_core::ColumnTypeKind::Struct,
            "union"  => turso_core::ColumnTypeKind::Union,
            other    => panic!("case {}: unexpected kind label '{}'", tc.name, other),
        };
        assert_eq!(
            meta.kind,
            expected_variant,
            "case {}: kind mismatch: got {:?}, expected {:?} (label '{}')",
            tc.name, meta.kind, expected_variant, expected_kind
        );

        // Record for cross-case check (each label is unique across the 4 cases)
        kinds_by_label.insert(expected_kind.to_string(), meta.kind);

        drop(stmt);
        conn.close().ok();
    }

    // CROSS-CASE: the four classifications must be pairwise distinct
    let required_kinds = ["custom", "domain", "struct", "union"];
    let mut observed: Vec<turso_core::ColumnTypeKind> = Vec::new();
    for label in &required_kinds {
        if let Some(k) = kinds_by_label.get(*label) {
            observed.push(*k);
        }
    }
    // Verify we saw all four kinds (guards against silent deduplication)
    assert_eq!(
        observed.len(),
        required_kinds.len(),
        "Did not observe all four classification kinds; observed kinds for: {:?}",
        kinds_by_label.keys().collect::<Vec<_>>()
    );
    // Verify pairwise distinct
    for i in 0..observed.len() {
        for j in (i + 1)..observed.len() {
            assert_ne!(
                observed[i], observed[j],
                "cross-case: kinds for '{}' and '{}' must be DISTINCT, but both are {:?}",
                required_kinds[i], required_kinds[j], observed[i]
            );
        }
    }
    // Verify none of them equals Builtin
    for (label, kind) in &kinds_by_label {
        assert_ne!(
            *kind,
            turso_core::ColumnTypeKind::Builtin,
            "cross-case: kind for '{}' must NOT equal Builtin, got {:?}",
            label, kind
        );
    }
}
