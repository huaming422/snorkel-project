mod validation_params;
use validation_params::{get_validation_test_cases, TestCase};

// From the patch, computed columns use ColumnTypeKind::Inferred and put the
// inferred primitive name in the `declared_name` field.

#[test]
fn test_computed_expression_inference() {
    let cases = get_validation_test_cases();

    for tc in &cases {
        let setup = tc.inputs["setup"].as_array().unwrap();
        let query = tc.inputs["query"].as_str().unwrap();
        let col_idx = tc.inputs["col_idx"].as_u64().unwrap() as usize;

        let expected_primitive = tc.expected["primitive"].as_str().unwrap();
        let expected_array_dimensions = tc.expected["array_dimensions"].as_u64().unwrap() as u32;
        let expected_base_type = tc.expected["base_type"].as_str().unwrap();

        // Build a fresh database with custom types enabled
        let opts = turso_core::DatabaseOpts::new().with_custom_types(true);
        let db = core_tester::common::TempDatabase::new_empty_with_opts(opts);
        let conn = db.connect_limbo();

        // Run setup statements
        for s in setup {
            let sql = s.as_str().unwrap();
            conn.execute(sql).unwrap_or_else(|e| panic!("case {}: setup '{}' failed: {:?}", tc.name, sql, e));
        }

        // Prepare query and get type metadata
        let stmt = conn.prepare(query).unwrap_or_else(|e| panic!("case {}: prepare '{}' failed: {:?}", tc.name, query, e));
        let meta = stmt.get_column_type_metadata(col_idx).unwrap_or_else(|| panic!("case {}: get_column_type_metadata returned None, expected info for computed column '{}'", tc.name, query));

        // EXPECTED: primitive - from the patch, computed columns put the inferred
        // primitive name in declared_name (ColumnTypeKind::Inferred surface)
        assert_eq!(
            meta.declared_name.to_lowercase(),
            expected_primitive.to_lowercase(),
            "case {}: inferred primitive mismatch: got '{}', expected '{}' (query: '{}')",
            tc.name, meta.declared_name, expected_primitive, query
        );

        // EXPECTED: array_dimensions
        assert_eq!(
            meta.array_dimensions,
            expected_array_dimensions,
            "case {}: array_dimensions mismatch: got {}, expected {}",
            tc.name, meta.array_dimensions, expected_array_dimensions
        );

        // EXPECTED: base_type - should be __none__ (no base type for computed columns)
        assert_eq!(expected_base_type, "__none__", "case {}: test expects base_type='__none__'", tc.name);
        assert!(
            meta.base_type.is_none(),
            "case {}: expected no base_type for computed column, got {:?}",
            tc.name, meta.base_type
        );

        drop(stmt);
        conn.close().ok();
    }
}
