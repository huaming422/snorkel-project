mod validation_params;
use validation_params::get_validation_test_cases;

use std::sync::Arc;
use turso_core::DatabaseOpts;

fn connect_with_custom_types() -> (core_tester::common::TempDatabase, Arc<turso_core::Connection>) {
    let path = tempfile::TempDir::new().unwrap().keep().join("exp_gate_on.db");
    let opts = DatabaseOpts::new().with_custom_types(true);
    let db = core_tester::common::TempDatabase::new_with_existent_with_opts(&path, opts);
    let conn = db.connect_limbo();
    (db, conn)
}

fn connect_without_custom_types() -> (core_tester::common::TempDatabase, Arc<turso_core::Connection>) {
    // Custom types are off by default
    let path = tempfile::TempDir::new().unwrap().keep().join("exp_gate_off.db");
    let opts = DatabaseOpts::new();
    let db = core_tester::common::TempDatabase::new_with_existent_with_opts(&path, opts);
    let conn = db.connect_limbo();
    (db, conn)
}

#[test]
fn test_experimental_gate() {
    let cases = get_validation_test_cases();
    for tc in &cases {
        let custom_types_enabled = tc.inputs["custom_types"].as_u64().unwrap() == 1;

        let (_db, conn) = if custom_types_enabled {
            connect_with_custom_types()
        } else {
            connect_without_custom_types()
        };

        let setup = tc.inputs["setup"].as_array().unwrap();
        for stmt_val in setup {
            let stmt_sql = stmt_val.as_str().unwrap();
            conn.execute(stmt_sql).unwrap_or_else(|e| {
                panic!("case {}: setup statement '{}' failed: {}", tc.name, stmt_sql, e)
            });
        }

        let query = tc.inputs["query"].as_str().unwrap();
        let col_idx = tc.inputs["col_idx"].as_u64().unwrap() as usize;

        let stmt = conn.prepare(query).unwrap_or_else(|e| {
            panic!("case {}: prepare '{}' failed: {}", tc.name, query, e)
        });

        let result = stmt.get_column_type_info(col_idx);

        // EXPECTED: outcome
        let expected_outcome = tc.expected["outcome"].as_str().unwrap();
        if expected_outcome == "error" {
            assert!(
                result.is_err(),
                "case {}: expected an error (feature not enabled), but got Ok({:?})",
                tc.name,
                result.ok()
            );
        } else if expected_outcome == "ok" {
            let meta = result.unwrap_or_else(|e| {
                panic!("case {}: expected Ok but got error: {}", tc.name, e)
            });
            assert!(
                meta.has_information(),
                "case {}: expected information to be available, got NoInformation",
                tc.name
            );
        } else {
            panic!("case {}: unknown outcome '{}'", tc.name, expected_outcome);
        }
    }
}
