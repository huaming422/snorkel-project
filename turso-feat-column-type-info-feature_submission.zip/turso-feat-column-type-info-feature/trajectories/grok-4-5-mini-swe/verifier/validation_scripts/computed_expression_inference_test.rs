mod validation_params;
use validation_params::get_validation_test_cases;

use std::sync::Arc;
use turso_core::DatabaseOpts;

fn connect_with_custom_types() -> (core_tester::common::TempDatabase, Arc<turso_core::Connection>) {
    let path = tempfile::TempDir::new().unwrap().keep().join("computed_expr.db");
    let opts = DatabaseOpts::new().with_custom_types(true);
    let db = core_tester::common::TempDatabase::new_with_existent_with_opts(&path, opts);
    let conn = db.connect_limbo();
    (db, conn)
}

#[test]
fn test_computed_expression_inference() {
    let cases = get_validation_test_cases();
    for tc in &cases {
        let (_db, conn) = connect_with_custom_types();

        let setup = tc.inputs["setup"].as_array().unwrap();
        for stmt_val in setup {
            let stmt_sql = stmt_val.as_str().unwrap();
            conn.execute(stmt_sql).unwrap_or_else(|e| {
                panic!("case {}: setup statement '{}' failed: {}", tc.name, stmt_sql, e)
            });
        }

        let query = tc.inputs["query"].as_str().unwrap();
        let col_idx = tc.inputs["col_idx"].as_u64().unwrap() as usize;

        let stmt = conn.prepare(query).unwrap_or_else(|e| {
            panic!("case {}: prepare '{}' failed: {}", tc.name, query, e)
        });

        let meta = stmt.get_column_type_info(col_idx).unwrap_or_else(|e| {
            panic!("case {}: get_column_type_info({}) failed: {}", tc.name, col_idx, e)
        });

        // Information must be available (not the no-info outcome, not an error)
        assert!(
            meta.has_information(),
            "case {}: expected information to be available (not no-info), got NoInformation",
            tc.name
        );

        // EXPECTED: primitive — the implementation surfaces the inferred primitive in declared_type_name.
        // The submitted patch puts computed expressions' inferred primitive name into declared_type_name.
        let expected_primitive = tc.expected["primitive"].as_str().unwrap();
        let actual_primitive = meta.declared_type_name.as_deref().unwrap_or_else(|| {
            panic!(
                "case {}: declared_type_name is None, expected primitive '{}'",
                tc.name, expected_primitive
            )
        });
        assert_eq!(
            actual_primitive.to_lowercase(),
            expected_primitive.to_lowercase(),
            "case {}: inferred primitive mismatch (via declared_type_name surface)",
            tc.name
        );

        // EXPECTED: array_dimensions — always 0 for computed expressions
        let expected_array_dimensions = tc.expected["array_dimensions"].as_u64().unwrap() as u32;
        assert_eq!(
            meta.array_dimensions,
            expected_array_dimensions,
            "case {}: array_dimensions mismatch",
            tc.name
        );

        // EXPECTED: base_type — when "__none__", assert there is no base primitive
        let expected_base_type = tc.expected["base_type"].as_str().unwrap();
        if expected_base_type == "__none__" {
            assert!(
                meta.base_type_name.is_none(),
                "case {}: expected base_type_name to be None, got {:?}",
                tc.name,
                meta.base_type_name
            );
        }
    }
}
