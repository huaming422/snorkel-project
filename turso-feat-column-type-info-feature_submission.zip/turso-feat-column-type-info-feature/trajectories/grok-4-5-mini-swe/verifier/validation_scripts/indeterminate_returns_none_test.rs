mod validation_params;
use validation_params::get_validation_test_cases;

use std::sync::Arc;
use turso_core::{DatabaseOpts, ResultColumnTypeKind};

fn connect_with_custom_types() -> (core_tester::common::TempDatabase, Arc<turso_core::Connection>) {
    let path = tempfile::TempDir::new().unwrap().keep().join("indet_none.db");
    let opts = DatabaseOpts::new().with_custom_types(true);
    let db = core_tester::common::TempDatabase::new_with_existent_with_opts(&path, opts);
    let conn = db.connect_limbo();
    (db, conn)
}

#[test]
fn test_indeterminate_returns_none() {
    let cases = get_validation_test_cases();
    for tc in &cases {
        let (_db, conn) = connect_with_custom_types();

        let setup = tc.inputs["setup"].as_array().unwrap();
        for stmt_val in setup {
            let stmt_sql = stmt_val.as_str().unwrap();
            conn.execute(stmt_sql).unwrap_or_else(|e| {
                panic!("case {}: setup statement '{}' failed: {}", tc.name, stmt_sql, e)
            });
        }

        let query = tc.inputs["query"].as_str().unwrap();
        let col_idx = tc.inputs["col_idx"].as_u64().unwrap() as usize;

        let stmt = conn.prepare(query).unwrap_or_else(|e| {
            panic!("case {}: prepare '{}' failed: {}", tc.name, query, e)
        });

        // The accessor must succeed (no error)
        let meta = stmt.get_column_type_info(col_idx).unwrap_or_else(|e| {
            panic!("case {}: get_column_type_info({}) returned error: {}", tc.name, col_idx, e)
        });

        // EXPECTED: outcome
        let expected_outcome = tc.expected["outcome"].as_str().unwrap();
        if expected_outcome == "none" {
            // Must report NoInformation (no-info outcome)
            assert_eq!(
                meta.kind,
                ResultColumnTypeKind::NoInformation,
                "case {}: expected NoInformation outcome, got {:?}",
                tc.name,
                meta.kind
            );
        } else if expected_outcome == "info" {
            // Must have information available
            assert!(
                meta.has_information(),
                "case {}: expected information to be available, got NoInformation",
                tc.name
            );
        } else {
            panic!("case {}: unknown outcome '{}'", tc.name, expected_outcome);
        }

        // EXPECTED: primitive
        let expected_primitive = tc.expected["primitive"].as_str().unwrap();
        if expected_primitive != "__skip__" {
            // Assert the inferred primitive identity via declared_type_name surface
            let actual_primitive = meta.declared_type_name.as_deref().unwrap_or_else(|| {
                panic!(
                    "case {}: declared_type_name is None, expected primitive '{}'",
                    tc.name, expected_primitive
                )
            });
            assert_eq!(
                actual_primitive.to_lowercase(),
                expected_primitive.to_lowercase(),
                "case {}: inferred primitive mismatch",
                tc.name
            );
        }
    }
}
