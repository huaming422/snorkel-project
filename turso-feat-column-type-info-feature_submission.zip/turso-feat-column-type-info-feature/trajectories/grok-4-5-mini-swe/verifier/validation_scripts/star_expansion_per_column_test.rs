mod validation_params;
use validation_params::get_validation_test_cases;

use std::sync::Arc;
use turso_core::{DatabaseOpts, ResultColumnTypeKind};

fn connect_with_custom_types() -> (core_tester::common::TempDatabase, Arc<turso_core::Connection>) {
    let path = tempfile::TempDir::new().unwrap().keep().join("star_exp.db");
    let opts = DatabaseOpts::new().with_custom_types(true);
    let db = core_tester::common::TempDatabase::new_with_existent_with_opts(&path, opts);
    let conn = db.connect_limbo();
    (db, conn)
}

fn kind_from_label(label: &str) -> ResultColumnTypeKind {
    match label {
        "builtin" => ResultColumnTypeKind::Builtin,
        "custom"  => ResultColumnTypeKind::Custom,
        "domain"  => ResultColumnTypeKind::Domain,
        "struct"  => ResultColumnTypeKind::Struct,
        "union"   => ResultColumnTypeKind::Union,
        other     => panic!("unknown kind label: {}", other),
    }
}

#[test]
fn test_star_expansion_per_column() {
    let cases = get_validation_test_cases();
    for tc in &cases {
        let (_db, conn) = connect_with_custom_types();

        let setup = tc.inputs["setup"].as_array().unwrap();
        for stmt_val in setup {
            let stmt_sql = stmt_val.as_str().unwrap();
            conn.execute(stmt_sql).unwrap_or_else(|e| {
                panic!("case {}: setup statement '{}' failed: {}", tc.name, stmt_sql, e)
            });
        }

        let query = tc.inputs["query"].as_str().unwrap();
        let col_idx = tc.inputs["col_idx"].as_u64().unwrap() as usize;

        let stmt = conn.prepare(query).unwrap_or_else(|e| {
            panic!("case {}: prepare '{}' failed: {}", tc.name, query, e)
        });

        let meta = stmt.get_column_type_info(col_idx).unwrap_or_else(|e| {
            panic!("case {}: get_column_type_info({}) failed: {}", tc.name, col_idx, e)
        });

        // Must have information available (not NoInformation)
        assert!(
            meta.has_information(),
            "case {}: expected information to be available, got NoInformation",
            tc.name
        );

        // EXPECTED: declared_name
        let expected_declared_name = tc.expected["declared_name"].as_str().unwrap();
        let actual_declared_name = meta.declared_type_name.as_deref().unwrap_or_else(|| {
            panic!("case {}: declared_type_name is None, expected '{}'", tc.name, expected_declared_name)
        });
        assert_eq!(
            actual_declared_name.to_lowercase(),
            expected_declared_name.to_lowercase(),
            "case {}: declared_name mismatch",
            tc.name
        );

        // EXPECTED: array_dimensions
        let expected_array_dimensions = tc.expected["array_dimensions"].as_u64().unwrap() as u32;
        assert_eq!(
            meta.array_dimensions,
            expected_array_dimensions,
            "case {}: array_dimensions mismatch",
            tc.name
        );

        // EXPECTED: base_type
        let expected_base_type = tc.expected["base_type"].as_str().unwrap();
        if expected_base_type == "__none__" {
            assert!(
                meta.base_type_name.is_none(),
                "case {}: expected base_type_name to be None, got {:?}",
                tc.name,
                meta.base_type_name
            );
        } else {
            let actual_base_type = meta.base_type_name.as_deref().unwrap_or_else(|| {
                panic!("case {}: base_type_name is None, expected '{}'", tc.name, expected_base_type)
            });
            assert_eq!(
                actual_base_type.to_lowercase(),
                expected_base_type.to_lowercase(),
                "case {}: base_type mismatch",
                tc.name
            );
        }

        // EXPECTED: kind
        let expected_kind_label = tc.expected["kind"].as_str().unwrap();
        let expected_kind = kind_from_label(expected_kind_label);
        assert_eq!(
            meta.kind,
            expected_kind,
            "case {}: kind mismatch: expected {:?}, got {:?}",
            tc.name,
            expected_kind,
            meta.kind
        );
    }
}
