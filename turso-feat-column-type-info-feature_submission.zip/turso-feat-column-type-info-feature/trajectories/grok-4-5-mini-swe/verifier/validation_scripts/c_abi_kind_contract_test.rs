mod validation_params;
use validation_params::get_validation_test_cases;

use std::collections::HashMap;
use std::ffi::CStr;
use turso_sdk_kit::rsapi::{TursoDatabase, TursoDatabaseConfig};
use turso_sdk_kit::capi;
use turso_sdk_kit::capi::c::turso_type_kind_t;

fn kind_integer_from_label(label: &str) -> u32 {
    match label {
        "none"    => turso_type_kind_t::TURSO_TYPE_KIND_NO_INFORMATION as u32,
        "builtin" => turso_type_kind_t::TURSO_TYPE_KIND_BUILTIN as u32,
        "custom"  => turso_type_kind_t::TURSO_TYPE_KIND_CUSTOM as u32,
        "domain"  => turso_type_kind_t::TURSO_TYPE_KIND_DOMAIN as u32,
        "struct"  => turso_type_kind_t::TURSO_TYPE_KIND_STRUCT as u32,
        "union"   => turso_type_kind_t::TURSO_TYPE_KIND_UNION as u32,
        other     => panic!("unknown kind label: {}", other),
    }
}

#[test]
fn test_c_abi_kind_contract() {
    let cases = get_validation_test_cases();

    // Map from expected kind label to observed integer, for cross-case distinctness check
    let mut kind_integers: HashMap<String, Vec<u32>> = HashMap::new();

    for tc in &cases {
        let custom_types_enabled = tc.inputs["custom_types"].as_u64().unwrap() == 1;
        let col_idx = tc.inputs["col_idx"].as_u64().unwrap() as usize;

        let experimental_features = if custom_types_enabled {
            Some("custom_types".to_string())
        } else {
            None
        };

        let db = TursoDatabase::new(TursoDatabaseConfig {
            path: ":memory:".to_string(),
            experimental_features,
            async_io: false,
            encryption: None,
            vfs: None,
            io: None,
            db_file: None,
        });
        let open_result = db.open().unwrap_or_else(|e| {
            panic!("case {}: db.open() failed: {}", tc.name, e)
        });
        assert!(!open_result.is_io(), "case {}: db.open() returned IO, expected Done", tc.name);

        let conn = db.connect().unwrap_or_else(|e| {
            panic!("case {}: db.connect() failed: {}", tc.name, e)
        });

        // Run setup statements
        let setup = tc.inputs["setup"].as_array().unwrap();
        for stmt_val in setup {
            let stmt_sql = stmt_val.as_str().unwrap();
            let mut s = conn.prepare_single(stmt_sql).unwrap_or_else(|e| {
                panic!("case {}: prepare_single('{}') failed: {}", tc.name, stmt_sql, e)
            });
            s.execute(None).unwrap_or_else(|e| {
                panic!("case {}: execute('{}') failed: {}", tc.name, stmt_sql, e)
            });
        }

        // Prepare query and convert to C statement pointer (consumes the Box)
        let query = tc.inputs["query"].as_str().unwrap();
        let stmt = conn.prepare_single(query).unwrap_or_else(|e| {
            panic!("case {}: prepare_single('{}') failed: {}", tc.name, query, e)
        });
        // to_capi() consumes the Box; free the raw pointer later with turso_statement_deinit
        let stmt_ptr = stmt.to_capi();

        // Get column type info handle via the two-step C ABI
        let mut info_ptr: *mut capi::c::turso_column_type_info_t = std::ptr::null_mut();
        let mut error_ptr: *const std::ffi::c_char = std::ptr::null();
        let _status = unsafe {
            capi::turso_statement_column_type_info(
                stmt_ptr as *const capi::c::turso_statement_t,
                col_idx,
                &mut info_ptr,
                &mut error_ptr,
            )
        };

        // Free error string if set
        if !error_ptr.is_null() {
            unsafe { capi::turso_str_deinit(error_ptr) };
        }

        // EXPECTED: kind — call the kind getter (handles null info_ptr → returns NO_INFORMATION)
        let observed_kind_int: u32 = unsafe {
            capi::turso_column_type_info_kind(
                info_ptr as *const capi::c::turso_column_type_info_t
            )
        } as u32;

        let expected_kind_label = tc.expected["kind"].as_str().unwrap();
        let expected_kind_int = kind_integer_from_label(expected_kind_label);
        assert_eq!(
            observed_kind_int,
            expected_kind_int,
            "case {}: kind integer mismatch: label='{}' expected_int={}, got={}",
            tc.name, expected_kind_label, expected_kind_int, observed_kind_int
        );

        // Record for cross-case check
        kind_integers.entry(expected_kind_label.to_string()).or_default().push(observed_kind_int);

        // EXPECTED: array_dimensions — always call the getter (handles null → returns 0)
        let expected_array_dimensions = tc.expected["array_dimensions"].as_u64().unwrap() as u32;
        let actual_dims = unsafe {
            capi::turso_column_type_info_array_dimensions(
                info_ptr as *const capi::c::turso_column_type_info_t
            )
        };
        assert_eq!(
            actual_dims,
            expected_array_dimensions,
            "case {}: array_dimensions mismatch",
            tc.name
        );

        if !info_ptr.is_null() {
            // EXPECTED: declared_name — skip if "__skip__"
            let expected_declared_name = tc.expected["declared_name"].as_str().unwrap();
            if expected_declared_name != "__skip__" {
                let name_ptr = unsafe {
                    capi::turso_column_type_info_declared_name(
                        info_ptr as *const capi::c::turso_column_type_info_t
                    )
                };
                assert!(
                    !name_ptr.is_null(),
                    "case {}: declared_name pointer is null, expected '{}'",
                    tc.name, expected_declared_name
                );
                // Copy string before freeing pointer
                let actual_name = unsafe {
                    CStr::from_ptr(name_ptr).to_str().unwrap().to_string()
                };
                unsafe { capi::turso_str_deinit(name_ptr) };
                assert_eq!(
                    actual_name.to_lowercase(),
                    expected_declared_name.to_lowercase(),
                    "case {}: declared_name mismatch: expected '{}', got '{}'",
                    tc.name, expected_declared_name, actual_name
                );
            }

            // EXPECTED: base_type — skip if "__skip__"
            let expected_base_type = tc.expected["base_type"].as_str().unwrap();
            if expected_base_type != "__skip__" {
                let base_ptr = unsafe {
                    capi::turso_column_type_info_base_type(
                        info_ptr as *const capi::c::turso_column_type_info_t
                    )
                };
                assert!(
                    !base_ptr.is_null(),
                    "case {}: base_type pointer is null, expected '{}'",
                    tc.name, expected_base_type
                );
                // Copy string before freeing pointer
                let actual_base = unsafe {
                    CStr::from_ptr(base_ptr).to_str().unwrap().to_string()
                };
                unsafe { capi::turso_str_deinit(base_ptr) };
                assert_eq!(
                    actual_base.to_lowercase(),
                    expected_base_type.to_lowercase(),
                    "case {}: base_type mismatch: expected '{}', got '{}'",
                    tc.name, expected_base_type, actual_base
                );
            }

            // Free info handle
            unsafe { capi::turso_column_type_info_deinit(info_ptr) };
        }

        // Free statement pointer
        unsafe { capi::turso_statement_deinit(stmt_ptr as *const capi::c::turso_statement_t) };
    }

    // CROSS-CASE: assert kind integers for schema-column classifications are pairwise distinct,
    // and that the none sentinel is distinct from all five classification integers.
    let get_first = |label: &str| -> Option<u32> {
        kind_integers.get(label).and_then(|v| v.first().copied())
    };

    let schema_labels = ["builtin", "custom", "domain", "struct", "union"];
    // Collect observed schema-column classification integers (only those seen in this run)
    let observed_schema: Vec<(&str, u32)> = schema_labels.iter()
        .filter_map(|&label| get_first(label).map(|i| (label, i)))
        .collect();

    // Each pair must be distinct
    for i in 0..observed_schema.len() {
        for j in (i + 1)..observed_schema.len() {
            let (label_i, int_i) = observed_schema[i];
            let (label_j, int_j) = observed_schema[j];
            assert_ne!(
                int_i, int_j,
                "kind integers for '{}' ({}) and '{}' ({}) must be distinct",
                label_i, int_i, label_j, int_j
            );
        }
    }

    // None sentinel must be distinct from all five classification integers
    if let Some(none_int) = get_first("none") {
        for (label, class_int) in &observed_schema {
            assert_ne!(
                none_int, *class_int,
                "none sentinel ({}) must differ from '{}' classification ({})",
                none_int, label, class_int
            );
        }
    }
}
