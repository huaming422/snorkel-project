## Task

Codex tool calls don't render properly in the chat. Script runs, calls to other agents and web calls come up as blank or raw fallback cards, while the other providers' tools get readable ones. On script cards, Codex's own status and timing lines get mixed in with what the script printed, and a run that failed can't be told apart from one that succeeded.

Separately, Codex sometimes stops partway through a turn to ask the user a question, and there's currently no way to answer it from the chat.

## User stories / requirements

- Each script Codex runs gets one card showing the code it ran together with what it printed. A run that fails still shows its code and the error it printed. The card looks the same while the turn is streaming and after the conversation is opened again.
- When Codex messages another agent, gives it a follow-up task, lists the agents under a path or interrupts one, that call shows up as a readable card saying what it was about: the agent it targeted, the message it sent or the path it listed.
- One Codex web call can bundle several actions: searches, opening pages, finding text on a page, clicking a link, and kinds the chat doesn't know about yet. The call shows up as a single card that lists every one of those actions with its details, and none of them get dropped.
- When Codex pauses a turn to ask something, the chat shows the question and the choices it offers, not a bare line of assistant text or nothing at all. A question in a saved conversation still shows up as a question when that conversation is opened again.
- The user answers that question in the chat, by picking a choice or typing their own answer, from the main chat or from a side chat. The answer reaches the Codex turn of the chat the question came from, even when it starts with a slash, and a half-typed composer message is left alone.
- After a question has been answered, opening the conversation again later shows the answer that was given alongside the question.
- Answered questions from Codex's older built-in question tool still reload the way they do today, showing both the question and the answer that was given.
