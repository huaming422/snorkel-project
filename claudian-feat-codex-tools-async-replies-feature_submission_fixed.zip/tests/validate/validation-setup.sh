#!/usr/bin/env bash
# Environment bootstrap for the chat tool-rendering validation stories.
# Sourced (not exec'd) by the story runner so exported vars persist for the
# stories. Idempotent and offline-first, mirroring tests/test-setup.sh.
#
# NO dist/build step: the repo runs its suites through ts-jest, which transforms
# the TypeScript sources on the fly at test time (jest.config.js `transform` →
# ts-jest with tsconfig.jest.json). Edits under src/ are therefore picked up
# directly by every story run. There is no compiled artifact that could go
# stale, so no build step is needed here.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/claudian}"
cd "$REPO_DIR"

# Fail a cache miss fast instead of reaching for the registry during the
# offline fold. Same switch tests/test-setup.sh uses.
export npm_config_offline=true

# Toolchain sanity — pinned by the image (Node 24, npm, jest 30 via npx).
node --version
npm --version

# Dependencies: offline-first against the image bake (`npm ci` ran at the base
# commit; node_modules + /opt/cache/npm are warm), with a logged online
# fallback if node_modules was removed. --ignore-scripts skips the postinstall
# that only copies a dev .env.local.
if [ -d node_modules/.bin ] && [ -x node_modules/.bin/jest ]; then
    echo "[validation-setup] deps present from image bake"
elif npm ci --offline --ignore-scripts > /tmp/validation-setup-install.log 2>&1; then
    echo "[validation-setup] deps restored offline from image cache"
elif { unset npm_config_offline; npm ci --ignore-scripts >> /tmp/validation-setup-install.log 2>&1; }; then
    echo "[validation-setup] deps installed online (image bake was stale)"
else
    echo "[validation-setup] FATAL: dependency restore failed" >&2
    tail -40 /tmp/validation-setup-install.log >&2
    exit 1
fi

# Loud smoke guard: the stories render DOM cards under the `integration`
# (jsdom) jest project, so the jsdom environment and the testing-library/jsdom
# devDeps declared in package.json MUST resolve offline. If any is missing the
# whole story set would fail uniformly, so say so here, before any story runs,
# instead of letting a missing toolchain piece look like a broken change.
node -e "require.resolve('jest-environment-jsdom')" \
  || { echo '[validation-setup] FATAL: jest-environment-jsdom not resolvable (jsdom stories cannot run offline)' >&2; exit 1; }
node -e "require.resolve('jsdom')" \
  || { echo '[validation-setup] FATAL: jsdom not resolvable' >&2; exit 1; }
node -e "require.resolve('ts-jest')" \
  || { echo '[validation-setup] FATAL: ts-jest not resolvable (on-the-fly TS transform unavailable)' >&2; exit 1; }

# Confirm the integration project + jsdom docblock path actually boots: compile
# and run a trivial jsdom spec through the repo's own jest config. This proves
# the exact plumbing the stories rely on (ts-jest transform + jsdom env +
# setupWindow.ts DOM polyfills) is healthy offline. Non-fatal-to-skip only if
# the probe file cannot be written; a RUN failure IS fatal.
SMOKE_DIR="tests/integration/__validation_smoke__"
SMOKE_FILE="$SMOKE_DIR/env_smoke.test.ts"
mkdir -p "$SMOKE_DIR"
cat > "$SMOKE_FILE" <<'SMOKE'
/** @jest-environment jsdom */
// @ts-nocheck
test('jsdom + obsidian DOM polyfills are live', () => {
  const el = (document.body as any).createDiv();
  el.setText('ok');
  expect(el.textContent).toBe('ok');
});
SMOKE
if npx jest --testPathPatterns "$SMOKE_FILE" --no-cache --forceExit > /tmp/validation-setup-smoke.log 2>&1; then
    echo "[validation-setup] jsdom story environment OK"
    rm -rf "$SMOKE_DIR"
else
    echo "[validation-setup] FATAL: jsdom story environment smoke failed" >&2
    tail -60 /tmp/validation-setup-smoke.log >&2
    rm -rf "$SMOKE_DIR"
    exit 1
fi

export PATH="$REPO_DIR/node_modules/.bin:$PATH"
echo "[validation-setup] ready: $REPO_DIR (node=$(node --version))"
