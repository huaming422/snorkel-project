// @ts-nocheck
//
// Framework plumbing for the chat stories: a fake Codex app-server and real
// chat tabs.
//
// The only thing faked is the boundary the plugin talks to when it runs
// Codex: the `codex app-server` child process and its JSON-RPC transport.
// Everything above that boundary is the plugin's own code, unchanged: the
// Codex execution backend and session, the chat execution coordinator, the
// chat tab (transcript, composer, side chat) and the saved-session history
// service. A story drives a tab the way a user does and plays the app-server
// side of the conversation the way Codex does: it answers the requests the
// plugin sends, streams notifications for the running turn, and writes the
// thread's rollout file under its CODEX_HOME.
//
// Import everything from this file. Do not import plugin modules or
// '@/providers' directly in a story file: the app-server boundary is replaced
// when this file loads, and that has to happen before any plugin module does.
//
// What is here:
//   mountCodexChat()           an empty chat tab on the Codex provider
//   reopenSavedSession(recs)   a chat tab reopened on a saved Codex session
//   reopenServerSession(srv)   a chat tab reopened on the thread a fake
//                              app-server wrote
//   expandCards(root)          opens every collapsed card under `root`
//   waitUntil(check)           polls until `check()` returns a truthy value
//   textOf(root)               whitespace-collapsed text of a DOM subtree
// Tabs, DOM and fake servers are torn down after each test automatically.

export const mockCodexServers: any[] = [];
let mockThreadSeq = 0;

jest.mock('@/providers/codex/runtime/CodexAppServerProcess', () => ({
  CodexAppServerProcess: class {
    start() {}
    async shutdown() {}
    isAlive() { return true; }
    onExit() {}
    offExit() {}
  },
}));

jest.mock('@/providers/codex/runtime/codexAppServerSupport', () => {
  const actual = jest.requireActual('@/providers/codex/runtime/codexAppServerSupport');
  const target = { method: 'host-native', platformFamily: 'unix', platformOs: 'linux' };
  return {
    ...actual,
    resolveCodexAppServerLaunchSpec: async () => ({
      target,
      command: '/usr/local/bin/codex',
      args: ['app-server', '--listen', 'stdio://'],
      spawnCwd: '/vault',
      targetCwd: '/vault',
      env: { HOME: '/tmp' },
      pathMapper: {
        target,
        toTargetPath: value => value,
        toHostPath: value => value,
        mapTargetPathList: values => values,
        canRepresentHostPath: () => true,
      },
    }),
  };
});

jest.mock('@/providers/codex/runtime/CodexRPCTransport', () => {
  const actual = jest.requireActual('@/providers/codex/runtime/CodexRPCTransport');
  const fs = require('node:fs');
  const os = require('node:os');
  const path = require('node:path');
  const codexHome = fs.mkdtempSync(path.join(os.tmpdir(), 'fake-codex-home-'));
  const threads = new Map();
  let clock = 0;
  const stamp = () => new Date(Date.UTC(2026, 0, 1, 0, 0, clock++)).toISOString();

  const writeRollout = thread => {
    const lines = [{ type: 'session_meta', timestamp: stamp(), payload: { id: thread.id } }, ...thread.records.map(r => r.record)];
    fs.mkdirSync(path.dirname(thread.path), { recursive: true });
    fs.writeFileSync(thread.path, lines.map(line => JSON.stringify(line)).join('\n') + '\n');
  };
  const record = (thread, entry) => {
    thread.records.push({ turnId: thread.turns.at(-1)?.id ?? null, record: { timestamp: stamp(), ...entry } });
    writeRollout(thread);
  };
  const createThread = source => {
    const id = `thread-${++mockThreadSeq}`;
    const thread = {
      id,
      path: path.join(codexHome, 'sessions', '2026', '01', '01', `rollout-${id}.jsonl`),
      turns: source ? source.turns.map(turn => ({ ...turn })) : [],
      records: source ? source.records.map(entry => ({ ...entry })) : [],
    };
    threads.set(id, thread);
    writeRollout(thread);
    return thread;
  };
  const threadResult = thread => ({
    thread: {
      id: thread.id, path: thread.path, preview: '', ephemeral: false, status: { type: 'idle' },
      turns: thread.turns.map(turn => ({ id: turn.id, items: [], status: turn.status, error: null })),
      cwd: '/vault', cliVersion: '0.146.0', modelProvider: 'openai', source: 'app-server',
      createdAt: 0, lastActivityAt: 0, agentNickname: null, agentRole: null, gitInfo: null, name: null,
    },
    model: 'gpt-5.5', modelProvider: 'openai', serviceTier: null, cwd: '/vault',
    approvalPolicy: 'never', approvalsReviewer: 'user',
    sandbox: { type: 'readOnly', access: { type: 'fullAccess' }, networkAccess: false },
    reasoningEffort: 'medium',
  });
  const inputText = input => (Array.isArray(input) ? input : [])
    .map(part => (typeof part?.text === 'string' ? part.text : ''))
    .filter(Boolean)
    .join('\n');
  // Codex keeps a completed agent message in the rollout as an item_completed
  // event with a capitalised item type and its text as content parts.
  const persistedItem = item => {
    if (item?.type !== 'agentMessage') return item;
    const { type: _type, text, ...rest } = item;
    return { ...rest, type: 'AgentMessage', content: [{ type: 'Text', text: text ?? '' }] };
  };

  class FakeCodexAppServer {
    constructor() {
      this.notificationHandlers = new Map();
      this.serverRequestHandlers = new Map();
      /** Every request and notification the plugin sent, in order: { method, params }. */
      this.requests = [];
      this.thread = null;
      mockCodexServers.push(this);
    }
    get threadId() { return this.thread?.id ?? null; }
    get turnId() { return this.thread?.turns.at(-1)?.id ?? null; }
    /** Text of every turn/start and turn/steer input this server received, in order. */
    turnInputs() {
      return this.requests
        .filter(entry => entry.method === 'turn/start' || entry.method === 'turn/steer')
        .map(entry => inputText(entry.params?.input));
    }
    start() {}
    dispose() {}
    notify(method, params) { this.requests.push({ method, params, notification: true }); }
    onNotification(method, handler) { this.notificationHandlers.set(method, handler); }
    onServerRequest(method, handler) { this.serverRequestHandlers.set(method, handler); }
    async request(method, params = {}) {
      this.requests.push({ method, params });
      switch (method) {
        case 'initialize':
          return { userAgent: 'codex-test', codexHome, platformFamily: 'unix', platformOs: 'linux' };
        case 'thread/start':
          this.thread = createThread(null);
          return threadResult(this.thread);
        case 'thread/fork':
          this.thread = createThread(threads.get(params.threadId) ?? null);
          return threadResult(this.thread);
        case 'thread/resume':
        case 'thread/read': {
          this.thread = threads.get(params.threadId) ?? createThread(null);
          return threadResult(this.thread);
        }
        case 'thread/rollback': {
          const thread = threads.get(params.threadId) ?? this.thread;
          const removed = new Set(thread.turns.splice(Math.max(0, thread.turns.length - (params.numTurns ?? 0))).map(t => t.id));
          thread.records = thread.records.filter(entry => !removed.has(entry.turnId));
          writeRollout(thread);
          return threadResult(thread);
        }
        case 'turn/start': {
          const thread = threads.get(params.threadId) ?? this.thread;
          this.thread = thread;
          const turn = { id: `${thread.id}-turn-${thread.turns.length + 1}`, status: 'inProgress' };
          thread.turns.push(turn);
          record(thread, { type: 'event_msg', payload: { type: 'task_started', turn_id: turn.id } });
          record(thread, { type: 'response_item', payload: { type: 'message', role: 'user', content: [{ type: 'input_text', text: inputText(params.input) }] } });
          return { turn: { id: turn.id, items: [], status: 'inProgress', error: null } };
        }
        case 'turn/steer': {
          if (this.thread?.turns.at(-1)) {
            record(this.thread, { type: 'response_item', payload: { type: 'message', role: 'user', content: [{ type: 'input_text', text: inputText(params.input) }] } });
          }
          return { turnId: this.turnId };
        }
        default:
          return {};
      }
    }
    /** Send one app-server notification for this server's current thread and turn. */
    notifyPlugin(method, params = {}) {
      this.notificationHandlers.get(method)?.({ threadId: this.threadId, turnId: this.turnId, ...params });
    }
    /** Stream a thread item (item/started then item/completed) and keep it in the rollout. */
    emitItem(item) {
      this.notifyPlugin('item/started', { item: { ...item } });
      this.notifyPlugin('item/completed', { item });
      if (this.thread) record(this.thread, { type: 'event_msg', payload: { type: 'item_completed', item: persistedItem(item) } });
    }
    /** Stream a raw model response item (e.g. a custom_tool_call or its output) and keep it in the rollout. */
    emitRawItem(item) {
      this.notifyPlugin('rawResponseItem/completed', { item });
      if (this.thread) record(this.thread, { type: 'response_item', payload: item });
    }
    /** Finish the running turn. */
    completeTurn() {
      const turn = this.thread?.turns.at(-1);
      if (!turn || turn.status === 'completed') return;
      turn.status = 'completed';
      record(this.thread, { type: 'event_msg', payload: { type: 'task_complete', turn_id: turn.id } });
      this.notifyPlugin('turn/completed', { turn: { id: turn.id, items: [], status: 'completed', error: null } });
    }
  }
  return { ...actual, CodexRPCTransport: FakeCodexAppServer, fakeCodexHome: codexHome };
});

// ---------------------------------------------------------------------------
// Obsidian DOM helpers and globals the jsdom environment lacks.
// ---------------------------------------------------------------------------
function installDomHelpers(): void {
  const proto = HTMLElement.prototype as any;
  const add = (name, fn) => { if (!proto[name]) proto[name] = fn; };
  add('empty', function () { this.replaceChildren(); });
  add('addClass', function (...names) { this.classList.add(...names); });
  add('removeClass', function (...names) { this.classList.remove(...names); });
  add('hasClass', function (name) { return this.classList.contains(name); });
  add('toggleClass', function (names, on) {
    for (const name of Array.isArray(names) ? names : [names]) this.classList.toggle(name, on);
  });
  add('appendText', function (text) { this.appendChild(this.ownerDocument.createTextNode(text)); });
  add('setCssProps', function (props) { for (const [key, value] of Object.entries(props)) this.style.setProperty(key, value); });
  add('scrollIntoView', function () {});
  if (typeof globalThis.structuredClone !== 'function') {
    const v8 = require('node:v8');
    globalThis.structuredClone = value => v8.deserialize(v8.serialize(value));
  }
  if (!globalThis.ResizeObserver) {
    globalThis.ResizeObserver = class { observe() {} unobserve() {} disconnect() {} };
  }
  // The repo's obsidian mock renders markdown to nothing; show it as plain
  // text so message bubbles are visible in the transcript.
  const { MarkdownRenderer } = require('obsidian');
  MarkdownRenderer.renderMarkdown.mockImplementation(async (markdown, el) => {
    el.appendChild(el.ownerDocument.createTextNode(String(markdown ?? '')));
  });
}

const mountedTabs: any[] = [];

afterEach(async () => {
  const { destroyTab } = require('@/features/chat/tabs/TabLifecycle');
  for (const tab of mountedTabs.splice(0)) {
    try { await destroyTab(tab); } catch { /* teardown of a broken tab */ }
  }
  mockCodexServers.length = 0;
  document.body.replaceChildren();
});

function stubbed(explicit: Record<string, unknown>): any {
  return new Proxy(explicit, {
    get(target, key) {
      if (key in target || typeof key === 'symbol' || key === 'then') return target[key];
      return async () => undefined;
    },
  });
}

/** Poll until `check()` returns a truthy value; returns it. Throws after `timeoutMs`. */
export async function waitUntil<T>(check: () => T, timeoutMs = 10000): Promise<T> {
  const deadline = Date.now() + timeoutMs;
  for (;;) {
    const value = check();
    if (value) return value;
    if (Date.now() > deadline) throw new Error('waitUntil: condition not met in time');
    await new Promise(resolve => setTimeout(resolve, 10));
  }
}

/** Whitespace-collapsed text content of a DOM subtree. */
export function textOf(root: Element): string {
  return (root?.textContent ?? '').replace(/\s+/g, ' ').trim();
}

/** Click every collapsed card header (`aria-expanded="false"`) under `root` until none is left. */
export function expandCards(root: Element): void {
  for (let round = 0; round < 5; round += 1) {
    const collapsed = [...root.querySelectorAll('[aria-expanded="false"]')];
    if (collapsed.length === 0) return;
    for (const el of collapsed) (el as HTMLElement).click();
  }
}

// One app and provider host per story file: the plugin's provider workspace
// registry keeps the first host it sees, as the running plugin does.
let sharedHostState: any = null;
function sharedHost(App, ProviderExecutionLifecycleRegistry, fakeCodexHome): any {
  if (sharedHostState) return sharedHostState;
  const envText = `CODEX_HOME=${fakeCodexHome}`;
  const app = new App();
  Object.assign(app.vault.adapter, { basePath: '/vault' });
  Object.assign(app.vault, { on: () => ({}), offref: () => undefined, getFiles: () => [] });
  const lifecycleRegistry = new ProviderExecutionLifecycleRegistry();
  const settings = {
    model: 'gpt-5.5', effortLevel: 'medium', permissionMode: 'normal', settingsProvider: 'codex',
    savedProviderModel: { codex: 'gpt-5.5' }, savedProviderEffort: { codex: 'medium' },
    providerConfigs: {
      codex: {
        enabled: true,
        environmentVariables: envText,
        visibleModels: ['gpt-5.5'],
        discoveredModels: [{
          model: 'gpt-5.5', displayName: 'GPT-5.5', description: '',
          supportedReasoningEfforts: [{ value: 'medium', description: '' }], defaultReasoningEffort: 'medium',
          serviceTiers: [], defaultServiceTier: null, inputModalities: ['text', 'image'], isDefault: true,
        }],
      },
    },
  };
  const providerHost = stubbed({
    app, settings, executionLifecycleRegistry: lifecycleRegistry, storage: stubbed({}),
    getActiveEnvironmentVariables: () => envText,
    getEnvironmentVariablesForScope: () => envText,
    getResolvedProviderCliPath: async () => '/usr/local/bin/codex',
    mutateSettings: async mutation => { await mutation(settings); },
    mutateSettingsConditionally: async mutation => { await mutation(settings); },
    runProviderExecutionTransition: (ids, mutation, parent) => lifecycleRegistry.runTransition(ids, mutation, parent),
    notifyProviderChatOptionsChanged: () => undefined,
  });
  sharedHostState = { app, settings, providerHost, lifecycleRegistry, envText };
  return sharedHostState;
}

/**
 * Mount a chat tab on the Codex provider. Returns:
 *   tab         the plugin's tab runtime (its controllers, state and DOM)
 *   view        the tab's root element (transcript, composer, prompts, side chat)
 *   transcript  the main chat's message list
 *   composer    the main composer's text input
 *   sendMain(text)        send `text` as a main-chat message; resolves to
 *                         { server, done } once the turn has reached the fake
 *                         app-server. `done` settles when the turn finishes.
 *   startSideChat(text)   open a side chat with `text` as its first prompt;
 *                         resolves to { server, done } the same way.
 */
export async function mountCodexChat(options: { conversation?: any } = {}): Promise<any> {
  installDomHelpers();
  require('@/providers');
  const { App } = require('obsidian');
  const { createTabRuntime } = require('@/features/chat/tabs/TabRuntimeFactory');
  const { ProviderExecutionLifecycleRegistry } = require('@/core/execution');
  const { WarmExecutionPool } = require('@/features/chat/execution/WarmExecutionPool');
  const { fakeCodexHome } = require('@/providers/codex/runtime/CodexRPCTransport');

  const { app, settings, providerHost, lifecycleRegistry, envText } = sharedHost(App, ProviderExecutionLifecycleRegistry, fakeCodexHome);
  const conversation = options.conversation ?? {
    id: 'conversation-1', providerId: 'codex', selectedModel: 'gpt-5.5', messages: [], createdAt: 1, lastActivityAt: 1,
  };
  let intent = 0;
  const plugin = stubbed({
    app, settings, providerHost,
    getCommittedSettings: () => settings,
    getActiveEnvironmentVariables: () => envText,
    warmExecutionPool: new WarmExecutionPool(() => 5),
    chatModelSelection: { beginIntent: () => ++intent, commitIntent: async () => true },
    executionPersistence: {
      registerExecutionBinding: () => undefined,
      persistExecutionSnapshot: async () => true,
      releaseExecutionBinding: () => undefined,
      recordConversationActivity: async () => undefined,
      assertConversationExecutionAuthority: async () => undefined,
    },
    createConversation: async () => conversation,
    switchConversation: async () => conversation,
    getConversationById: async () => conversation,
    getCachedConversation: () => conversation,
    getConversationSummary: () => conversation,
    getConversationSync: () => conversation,
    getConversationList: () => [conversation],
    mutateSettings: async mutation => { await mutation(settings); },
    findConversationAcrossViews: () => null,
    getView: () => null,
    getAllViews: () => [],
  });

  const containerEl = document.body.appendChild(document.createElement('div'));
  const tab = await createTabRuntime({
    plugin,
    component: { addChild: () => undefined, register: () => undefined, registerDomEvent: () => undefined, registerEvent: () => undefined },
    containerEl,
    conversation,
    getProviderCatalogConfig: () => null,
    isRuntimeLive: () => true,
  });
  mountedTabs.push(tab);
  if (options.conversation) {
    await tab.controllers.conversationController.loadActive();
  } else {
    tab.state.messages = conversation.messages;
  }

  return {
    tab,
    view: containerEl,
    transcript: tab.dom.messagesEl,
    composer: tab.dom.inputEl,
    async sendMain(text: string) {
      const before = mockCodexServers.map(server => server.turnInputs().length);
      const done = tab.controllers.inputController.sendMessage({ content: text });
      const server = await waitUntil(() => mockCodexServers.find((candidate, index) =>
        candidate.turnInputs().length > (before[index] ?? 0) && candidate.turnInputs().some(input => input.includes(text))));
      return { server, done };
    },
    async startSideChat(text: string) {
      const known = new Set(mockCodexServers);
      const done = tab.controllers.sideChatController.handleCommandSubmission(text, []);
      const server = await waitUntil(() => mockCodexServers.find(candidate =>
        !known.has(candidate) && candidate.turnInputs().some(input => input.includes(text))));
      return { server, done };
    },
  };
}

function savedConversation(threadId: string, sessionFilePath: string): any {
  const path = require('node:path');
  return {
    id: `saved-${threadId}`, providerId: 'codex', selectedModel: 'gpt-5.5', sessionId: threadId,
    providerState: { threadId, sessionFilePath, transcriptRootPath: path.dirname(path.dirname(path.dirname(path.dirname(sessionFilePath)))) },
    messages: [], createdAt: 1, lastActivityAt: 1,
  };
}

async function reopen(conversation: any): Promise<any> {
  installDomHelpers();
  require('@/providers');
  const { ProviderRegistry } = require('@/core/providers/ProviderRegistry');
  const { fakeCodexHome } = require('@/providers/codex/runtime/CodexRPCTransport');
  const update = await ProviderRegistry.getConversationHistoryService('codex').hydrateConversationHistory(
    conversation,
    '/vault',
    { environment: { ...process.env, CODEX_HOME: fakeCodexHome }, hostPlatform: process.platform, vaultPath: '/vault' },
  );
  Object.assign(conversation, update ?? {});
  return mountCodexChat({ conversation });
}

/**
 * Write a saved Codex session and reopen it in a new chat tab. `records` are
 * rollout records exactly as Codex stores them ({ type, payload } objects such
 * as response_item and event_msg); the session_meta header and timestamps are
 * added here. Returns the same handle as mountCodexChat().
 */
export async function reopenSavedSession(records: any[]): Promise<any> {
  installDomHelpers();
  require('@/providers');
  const fs = require('node:fs');
  const path = require('node:path');
  const { fakeCodexHome } = require('@/providers/codex/runtime/CodexRPCTransport');
  const threadId = `saved-${mountedTabs.length}-${Date.now()}`;
  const sessionFilePath = path.join(fakeCodexHome, 'sessions', '2026', '01', '02', `rollout-${threadId}.jsonl`);
  fs.mkdirSync(path.dirname(sessionFilePath), { recursive: true });
  const lines = [{ type: 'session_meta', payload: { id: threadId } }, ...records].map((record, index) => JSON.stringify({
    timestamp: new Date(Date.UTC(2026, 0, 2, 0, 0, index)).toISOString(), ...record,
  }));
  fs.writeFileSync(sessionFilePath, lines.join('\n') + '\n');
  return reopen(savedConversation(threadId, sessionFilePath));
}

/** Reopen, in a new chat tab, the thread a fake app-server has been writing (its rollout file as it stands now). */
export async function reopenServerSession(server: any): Promise<any> {
  return reopen(savedConversation(server.threadId, server.thread.path));
}
