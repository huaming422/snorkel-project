/** @jest-environment jsdom */
// @ts-nocheck
//
// Script cards for Codex script runs, `exec_envelope_strip`.
//
// Codex records a script run as a native `exec` custom tool call whose input
// is the raw script source. Its result arrives with a few status lines in
// front of the script's own output (the repo's own history tests carry these
// records). A failed run is shown in a failed state, and whatever the script
// printed stays on the card, including a later "Output:" line or JSON that
// belongs to the output. Results of other tools are left as they are.
//
// Each case is rendered through the chat's card renderer, after reaching it
// the two ways a script run can: reloaded from a saved session, and streamed
// live from a Codex session whose app-server process is replaced by a fake
// transport. Only what the rendered card shows is read.

const mockServers: any[] = [];

jest.mock('@/providers/codex/runtime/CodexAppServerProcess', () => ({
  CodexAppServerProcess: class {
    start() {}
    async shutdown() {}
    isAlive() { return true; }
    onExit() {}
    offExit() {}
  },
}));

jest.mock('@/providers/codex/runtime/codexAppServerSupport', () => {
  const actual = jest.requireActual('@/providers/codex/runtime/codexAppServerSupport');
  const target = { method: 'host-native', platformFamily: 'unix', platformOs: 'linux' };
  return {
    ...actual,
    resolveCodexAppServerLaunchSpec: async () => ({
      target, command: '/usr/local/bin/codex', args: ['app-server'], spawnCwd: '/vault', targetCwd: '/vault',
      env: { HOME: '/tmp' },
      pathMapper: { target, toTargetPath: v => v, toHostPath: v => v, mapTargetPathList: v => v, canRepresentHostPath: () => true },
    }),
  };
});

jest.mock('@/providers/codex/runtime/CodexRPCTransport', () => {
  const actual = jest.requireActual('@/providers/codex/runtime/CodexRPCTransport');
  class FakeTransport {
    constructor() { this.handlers = new Map(); this.methods = []; mockServers.push(this); }
    start() {}
    dispose() {}
    notify() {}
    onNotification(method, handler) { this.handlers.set(method, handler); }
    onServerRequest() {}
    async request(method) {
      this.methods.push(method);
      if (method === 'initialize') return { userAgent: 'codex-test', codexHome: '/tmp/.codex', platformFamily: 'unix', platformOs: 'linux' };
      if (method === 'thread/start') {
        return {
          thread: { id: 'thread', path: '/tmp/.codex/sessions/rollout-thread.jsonl', preview: '', ephemeral: false, status: { type: 'idle' }, turns: [],
            cwd: '/vault', cliVersion: '0.146.0', modelProvider: 'openai', source: 'app-server', createdAt: 0, lastActivityAt: 0,
            agentNickname: null, agentRole: null, gitInfo: null, name: null },
          model: 'gpt-5.5', modelProvider: 'openai', serviceTier: null, cwd: '/vault', approvalPolicy: 'never', approvalsReviewer: 'user',
          sandbox: { type: 'readOnly', access: { type: 'fullAccess' }, networkAccess: false }, reasoningEffort: 'medium',
        };
      }
      if (method === 'turn/start') return { turn: { id: 'turn', items: [], status: 'inProgress', error: null } };
      return {};
    }
    emit(method, params) { this.handlers.get(method)?.({ threadId: 'thread', turnId: 'turn', ...params }); }
  }
  return { ...actual, CodexRPCTransport: FakeTransport };
});

import { CodexExecutionBackend } from '@/providers/codex/execution/CodexExecutionBackend';
import { parseCodexSessionContent } from '@/providers/codex/history/CodexHistoryStore';
import { renderStoredToolCall, renderToolCall, updateToolCallResult } from '@/features/chat/rendering/ToolCallRenderer';

const LF = '\n';
const SOURCE = "const notes = await vault.list('daily');\ntext(notes.join(', '));";

function installDomHelpers(): void {
  const proto = HTMLElement.prototype as any;
  const add = (name, fn) => { if (!proto[name]) proto[name] = fn; };
  add('empty', function () { this.replaceChildren(); });
  add('addClass', function (...c) { this.classList.add(...c); });
  add('removeClass', function (...c) { this.classList.remove(...c); });
  add('hasClass', function (c) { return this.classList.contains(c); });
  add('toggleClass', function (names, on) { for (const n of Array.isArray(names) ? names : [names]) this.classList.toggle(n, on); });
  add('appendText', function (t) { this.appendChild(this.ownerDocument.createTextNode(t)); });
  add('setCssProps', function (props) { for (const [k, v] of Object.entries(props)) this.style.setProperty(k, v); });
  add('scrollIntoView', function () {});
}

function host(): HTMLElement {
  installDomHelpers();
  return document.body.appendChild(document.createElement('div'));
}

function records(output: string, name = 'exec') {
  return name === 'exec'
    ? [
        { type: 'custom_tool_call', call_id: 'call-1', name: 'exec', input: SOURCE },
        { type: 'custom_tool_call_output', call_id: 'call-1', output },
      ]
    : [
        { type: 'function_call', call_id: 'call-1', name, arguments: JSON.stringify({ query: 'notes' }) },
        { type: 'function_call_output', call_id: 'call-1', output },
      ];
}

/** Reload the records as a saved session and render the one card it holds. */
function renderFromSavedSession(items: unknown[]): HTMLElement {
  const jsonl = items
    .map((payload, index) => JSON.stringify({
      type: 'response_item', timestamp: new Date(Date.UTC(2026, 0, 1, 0, 0, index)).toISOString(), payload,
    }))
    .join(LF);
  const tools = parseCodexSessionContent(jsonl).flatMap((message: any) => message.toolCalls ?? []);
  expect(tools).toHaveLength(1);
  return renderStoredToolCall(host(), tools[0], { initiallyExpanded: true });
}

/** Stream the records through a live Codex session and render the card as the chat does. */
async function renderFromLiveSession(items: unknown[]): Promise<HTMLElement> {
  const settings = {
    model: 'gpt-5.5', effortLevel: 'medium', serviceTier: 'default', permissionMode: 'normal', systemPrompt: '',
    mediaFolder: '', userName: '',
    providerConfigs: { codex: { enabled: true, discoveredModels: [{
      model: 'gpt-5.5', displayName: 'GPT-5.5', description: '', supportedReasoningEfforts: [{ value: 'medium', description: '' }],
      defaultReasoningEffort: 'medium', serviceTiers: [], defaultServiceTier: null, inputModalities: ['text'], isDefault: true,
    }] } },
  };
  const session = new CodexExecutionBackend({ settings } as any).createSession({
    lifecycle: 'persistent', nativePersistence: 'enabled', vaultWorkingDirectory: '/vault',
    interactionPort: { requestApproval: jest.fn(), askUserQuestion: jest.fn(), dismissInteraction: jest.fn() },
  });
  const run = session.execute({
    input: [{ type: 'text', text: 'Run the script' }],
    configuration: { systemInstructions: { kind: 'provider-default' }, model: 'gpt-5.5', reasoning: 'medium', permissionMode: 'normal' },
    toolPolicy: { kind: 'provider-default' },
    signal: new AbortController().signal,
  });
  for (let i = 0; i < 2000 && !mockServers.at(-1)?.methods.includes('turn/start'); i += 1) {
    await new Promise(resolve => setTimeout(resolve, 5));
  }
  const server = mockServers.at(-1);
  expect(server.methods).toContain('turn/start');
  for (const item of items) server.emit('rawResponseItem/completed', { item });
  server.emit('turn/completed', { turn: { id: 'turn', items: [], status: 'completed', error: null } });
  const events: any[] = [];
  for await (const event of run.events) events.push(event);
  await session.dispose();

  const started = events.filter(event => event.type === 'tool_started');
  expect(new Set(started.map(event => event.toolCallId)).size).toBe(1);
  const first = started[0];
  const latest = started.at(-1);
  const completed = events.filter(event => event.type === 'tool_completed' && event.toolCallId === first.toolCallId).at(-1);
  expect(completed).toBeTruthy();
  const elements = new Map<string, HTMLElement>();
  const block = renderToolCall(host(), {
    id: first.toolCallId, name: first.name, input: first.input, status: 'running',
  }, elements, { initiallyExpanded: true });
  updateToolCallResult(first.toolCallId, {
    id: first.toolCallId, name: latest.name, input: latest.input,
    status: completed.isError ? 'error' : 'completed', result: completed.content,
  }, elements);
  return block;
}

function textOf(root: Element): string {
  return (root?.textContent ?? '').replace(/\s+/g, ' ').trim();
}

const FAILURE_WORD = /\b(error|errored|fail|failed|failure)\b/i;

/**
 * Whether the card marks the run as failed anywhere other than in the
 * script's own printed output: an accessible label, title, status attribute
 * or class on any element, or visible text outside the element that shows
 * the printed output.
 */
function failureShown(card: HTMLElement, printed: string): boolean {
  for (const el of [card, ...card.querySelectorAll('*')]) {
    for (const attr of ['aria-label', 'title', 'data-status', 'class']) {
      const value = el.getAttribute(attr);
      if (value && FAILURE_WORD.test(value.replace(/[-_]+/g, ' '))) return true;
    }
  }
  const copy = card.cloneNode(true) as HTMLElement;
  const holders = [...copy.querySelectorAll('*')].filter(el => textOf(el).includes(printed));
  for (const el of holders.filter(el => !holders.some(other => other !== el && el.contains(other)))) el.remove();
  return FAILURE_WORD.test(textOf(copy));
}

afterEach(() => {
  document.body.replaceChildren();
  mockServers.length = 0;
});

describe.each([
  ['saved session', async (items: unknown[]) => renderFromSavedSession(items)],
  ['live session', renderFromLiveSession],
])('exec_envelope_strip (%s)', (_label, render) => {
  it('shows the output of a completed script run without marking it failed', async () => {
    const card = await render(records(['Script completed', 'Wall time 0.1 seconds', 'Output:', 'hello world'].join(LF)));
    expect(card.textContent).toContain('hello world');
    expect(failureShown(card, 'hello world')).toBe(false);
  });

  it('shows the output of a failed script run and marks the card as failed', async () => {
    const card = await render(records(['Script failed', 'Wall time 0.0 seconds', 'Output:', 'Traceback: boom'].join(LF)));
    expect(card.textContent).toContain('Traceback: boom');
    expect(failureShown(card, 'Traceback: boom')).toBe(true);
  });

  it('keeps a later "Output:" line and JSON that belong to the script output', async () => {
    const card = await render(records(['Script completed', 'Wall time 0.9 seconds', 'Output:', '{"result": 1}', 'Output:', 'second block'].join(LF)));
    expect(card.textContent).toContain('{"result": 1}');
    expect(card.textContent).toContain('Output:');
    expect(card.textContent).toContain('second block');
  });

  it('shows the first output of a script that is still running', async () => {
    const card = await render(records(['Script running with cell ID cell-42', 'Wall time 10.0 seconds', 'Output:', 'partial line 1'].join(LF)));
    expect(card.textContent).toContain('partial line 1');
    expect(failureShown(card, 'partial line 1')).toBe(false);
  });

  it('leaves the result of a tool that is not a script untouched', async () => {
    const raw = ['Script completed', 'Wall time 1.0 seconds', 'Output:', 'search hit'].join(LF);
    const card = await render(records(raw, 'notes_lookup'));
    expect(card.textContent).toContain('Wall time 1.0 seconds');
    expect(card.textContent).toContain('search hit');
  });
});
