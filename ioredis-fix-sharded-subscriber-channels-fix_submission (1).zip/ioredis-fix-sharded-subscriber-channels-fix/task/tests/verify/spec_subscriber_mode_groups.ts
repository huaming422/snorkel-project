// Behavioral checks for a single connection that mixes a regular (or pattern)
// subscription with a shard subscription. Redis counts regular channels and
// patterns in one group and shard channels in a separate group, so the count
// carried by one group's unsubscribe acknowledgement says nothing about the
// other group. Dropping the whole subscriber state on a single group's zero
// count silently tears down a still-active subscription.
//
// Everything is observed through the public single-connection pub/sub surface:
// the subscribe/unsubscribe methods, `redis.condition.subscriber` (the tracked
// subscription set) and `redis.mode`. No helper the fix may introduce is named.
import MockServer, { pubSubReply } from "../helpers/mock_server";
import { expect } from "chai";
import Redis from "../../lib/Redis";

const PROTOCOLS = [2, 3] as const;

PROTOCOLS.forEach((protocol, index) => {
  describe(`bug_b_group_isolation (RESP${protocol})`, function () {
    this.timeout(15000);

    const port = 17940 + index;
    let server: MockServer;
    let redis: Redis;

    beforeEach(() => {
      server = new MockServer(port, (argv) => {
        const name = String(argv[0]).toLowerCase();
        if (name === "info") {
          return "# Server\r\nredis_version:7.0.0\r\n";
        }
        // Each group reports its own remaining count: a (s)subscribe leaves 1,
        // an (s)unsubscribe leaves 0 for that group.
        if (name === "subscribe" || name === "ssubscribe") {
          return pubSubReply(protocol, name, argv[1], 1);
        }
        if (name === "unsubscribe" || name === "sunsubscribe") {
          return pubSubReply(protocol, name, argv[1], 0);
        }
        return "OK";
      });
    });

    afterEach(() => {
      if (redis && redis.status !== "end") {
        redis.disconnect();
      }
      server.disconnect();
    });

    it("keeps the regular subscription alive after a shard unsubscribe", async () => {
      redis = new Redis({ port, protocol });
      await redis.subscribe("regular");
      await redis.ssubscribe("shard");
      await redis.sunsubscribe("shard");

      const { subscriber } = redis.condition;
      // Still in subscriber mode: the regular subscription is untouched.
      expect(subscriber).to.not.equal(false);
      expect((subscriber as any).channels("subscribe")).to.eql(["regular"]);
      expect((subscriber as any).channels("ssubscribe")).to.eql([]);
    });

    it("leaves subscriber mode only once every kind is unsubscribed", async () => {
      redis = new Redis({ port, protocol });
      await redis.subscribe("regular");
      await redis.ssubscribe("shard");
      await redis.unsubscribe("regular");
      await redis.sunsubscribe("shard");

      expect(redis.condition.subscriber).to.equal(false);
      // `Redis#mode` reports the subscriber state under RESP2.
      if (protocol === 2) {
        expect(redis.mode).to.equal("normal");
      }
    });
  });
});
