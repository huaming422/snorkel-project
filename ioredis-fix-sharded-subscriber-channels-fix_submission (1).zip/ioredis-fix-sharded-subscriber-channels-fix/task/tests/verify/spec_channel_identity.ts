// Behavioral checks that shard-channel bookkeeping is byte-accurate and that an
// empty-string channel name is a real channel.
//
// Observation points, all pre-existing and stable:
//   - `ClusterSubscriberGroup#addChannels` / `#removeChannels` — the tightest
//     point for the byte-identity of the tracked channel set (return value +
//     residual membership). Used only for the pure-identity assertions.
//   - `SubscriptionSet#add` / `#del` / `#isEmpty` — byte-accurate membership of
//     the connection's own subscription set.
//   - The end-to-end Cluster shard subscribe/unsubscribe + slot-cache refresh
//     surface — proves an unsubscribed channel is not replayed to a new owner
//     after the slot topology changes.
//   - A single `Redis` connection's subscription set after an unsubscribe whose
//     acknowledgement carries an empty-string channel — proves an empty string
//     is treated as a channel rather than as "no channel".
import MockServer, { MockServerHandler, pushFrame } from "../helpers/mock_server";
import { expect } from "chai";
import { EventEmitter } from "events";
import { Socket } from "net";
import { Cluster } from "../../lib";
import Redis from "../../lib/Redis";
import SubscriptionSet from "../../lib/SubscriptionSet";
import ClusterSubscriberGroup from "../../lib/cluster/ClusterSubscriberGroup";

describe("bug_c_binary_safe_identity", function () {
  this.timeout(20000);

  describe("tracked shard channel set (unit)", () => {
    it("removes every copy of a channel with equal bytes", () => {
      const group = new ClusterSubscriberGroup(new EventEmitter(), {} as any);
      group.addChannels(["news{tag}", Buffer.from("news{tag}")]);
      group.addChannels([Buffer.from("news{tag}"), "control{tag}"]);

      // A byte-equal request removes the matching entries regardless of whether
      // they were tracked as strings or Buffers.
      expect(group.removeChannels([Buffer.from("news{tag}")])).to.equal(1);
      expect(group.removeChannels(["control{tag}"])).to.equal(0);
    });

    it("keeps distinct binary channels even when their UTF-8 strings match", () => {
      const group = new ClusterSubscriberGroup(new EventEmitter(), {} as any);
      const first = Buffer.concat([Buffer.from("{tag}"), Buffer.from([0xfe])]);
      const second = Buffer.concat([Buffer.from("{tag}"), Buffer.from([0xff])]);
      // Same UTF-8 rendering, different bytes.
      expect(first.toString()).to.equal(second.toString());
      group.addChannels([first, second]);

      expect(group.removeChannels([Buffer.from(first)])).to.equal(1);
      expect(group.removeChannels([first])).to.equal(1);
      expect(group.removeChannels([Buffer.from(second)])).to.equal(0);
    });

    it("leaves the set unchanged when an unsubscribe spans slots", () => {
      const group = new ClusterSubscriberGroup(new EventEmitter(), {} as any);
      group.addChannels([Buffer.from("news{tag}")]);

      expect(group.removeChannels(["news{tag}", "news{other}"])).to.equal(-1);
      expect(group.removeChannels(["news{tag}"])).to.equal(0);
    });
  });

  describe("subscription set membership (unit)", () => {
    it("tracks a channel named __proto__", () => {
      const set = new SubscriptionSet();
      set.add("subscribe", "__proto__");
      expect(set.isEmpty()).to.equal(false);
    });

    it("keeps binary channel names that share a UTF-8 rendering apart", () => {
      const set = new SubscriptionSet();
      // 0x80 and 0x81 are both invalid UTF-8 and render to the same string.
      set.add("subscribe", Buffer.from([0x80]));
      set.add("subscribe", Buffer.from([0x81]));
      set.del("unsubscribe", Buffer.from([0x80]));
      // The other distinct-byte channel must survive.
      expect(set.isEmpty()).to.equal(false);
    });
  });

  // End-to-end: an unsubscribed shard channel must not come back when the
  // cluster reshards and replays the tracked channel set to the new owner.
  for (const protocol of [2, 3] as const) {
    for (const [name, channel, removed] of [
      ["distinct buffers", Buffer.from("news{tag}"), Buffer.from("news{tag}")],
      ["string and buffer", "news{tag}", Buffer.from("news{tag}")],
      ["buffer and string", Buffer.from("news{tag}"), "news{tag}"],
    ] as const) {
      it(`does not replay an unsubscribed channel after moving slots (${name}, RESP${protocol})`, async () => {
        let ownerPort = 30001;
        const restored: string[] = [];
        const subscriptions = new WeakMap<Socket, Set<string>>();
        let controlRestored: () => void;
        const replayed = new Promise<void>((resolve) => {
          controlRestored = resolve;
        });
        const handler: MockServerHandler = (argv, socket, flags) => {
          if (argv[0] === "cluster" && argv[1] === "SLOTS") {
            return [[0, 16383, ["127.0.0.1", ownerPort]]];
          }
          if (argv[0] === "ssubscribe" || argv[0] === "sunsubscribe") {
            if (socket.localPort === 30002 && argv[0] === "ssubscribe") {
              restored.push(...argv.slice(1));
              if (argv.includes("control{tag}")) controlRestored();
            }
            const channels = subscriptions.get(socket) ?? new Set<string>();
            subscriptions.set(socket, channels);
            for (const ch of argv.slice(1)) {
              if (argv[0] === "ssubscribe") channels.add(ch);
              else channels.delete(ch);
              target.write(
                socket,
                protocol === 3
                  ? pushFrame(argv[0], ch, channels.size)
                  : [argv[0], ch, channels.size]
              );
            }
            flags.hang = true;
          }
        };
        new MockServer(30001, handler);
        const target = new MockServer(30002, handler);
        const cluster = new Cluster([{ port: 30001 }], {
          shardedSubscribers: true,
          redisOptions: { protocol },
        });

        try {
          expect(await cluster.ssubscribe(channel)).to.equal(1);
          expect(await cluster.ssubscribe("control{tag}")).to.equal(2);
          expect(await cluster.sunsubscribe(removed)).to.equal(1);

          // Move the slot to the other node and refresh the slot cache, which
          // replays the still-tracked channels to the new owner.
          ownerPort = 30002;
          await new Promise<void>((resolve, reject) => {
            cluster.refreshSlotsCache((err) => (err ? reject(err) : resolve()));
          });
          await replayed;
          // Only the channel that is still subscribed is replayed.
          expect(restored).to.eql(["control{tag}"]);
        } finally {
          cluster.disconnect();
        }
      });
    }
  }
});

describe("empty_channel_valid", function () {
  this.timeout(15000);

  // An empty-string channel is a real channel: an unsubscribe acknowledgement
  // whose channel element is "" must drop exactly that channel, leaving the
  // other regular subscription in place. (A reply element of null/undefined is
  // the only thing that means "no channel".)
  for (const protocol of [2, 3] as const) {
    it(`treats an empty-string channel as its own channel (RESP${protocol})`, async () => {
      const port = 17960 + protocol;
      // Track the live regular-channel membership so replies carry a truthful
      // remaining count for the group.
      const regular = new Set<string>();
      const server = new MockServer(port, (argv) => {
        const cmd = String(argv[0]).toLowerCase();
        if (cmd === "info") {
          return "# Server\r\nredis_version:7.0.0\r\n";
        }
        if (cmd === "subscribe") {
          regular.add(String(argv[1]));
          return protocol === 3
            ? pushFrame("subscribe", argv[1], regular.size)
            : ["subscribe", argv[1], regular.size];
        }
        if (cmd === "unsubscribe") {
          regular.delete(String(argv[1]));
          return protocol === 3
            ? pushFrame("unsubscribe", argv[1], regular.size)
            : ["unsubscribe", argv[1], regular.size];
        }
        return "OK";
      });

      const redis = new Redis({ port, protocol });
      try {
        await redis.subscribe(""); // the empty-string channel
        await redis.subscribe("other");
        // Unsubscribing the empty-string channel must remove exactly it.
        await redis.unsubscribe("");

        const { subscriber } = redis.condition;
        expect(subscriber).to.not.equal(false);
        expect((subscriber as any).channels("subscribe")).to.eql(["other"]);
      } finally {
        if (redis.status !== "end") redis.disconnect();
        server.disconnect();
      }
    });
  }
});
