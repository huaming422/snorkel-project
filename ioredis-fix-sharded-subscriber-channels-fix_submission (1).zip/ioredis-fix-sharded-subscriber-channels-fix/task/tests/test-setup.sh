#!/usr/bin/env bash
# Environment bootstrap for the verifier.
#
# Sourced (not exec'd) by the harbor runner so env vars set here stay live for
# the verifier subprocess.
#
# ioredis runs its test suite through ts-node in transpile-only mode (see the
# `test:js` script in package.json) — there is no separate build step to run
# before the focused tests. The image already bakes the full dependency closure
# with `npm ci` at the base commit, and a live Redis 7.4 is started
# automatically via the image's Node --require preload (/opt/boot-redis.cjs).
# So this script normally only verifies that node_modules is intact.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/ioredis}"
export REPO_DIR
cd "$REPO_DIR"

# Sanity check: mocha must be resolvable from node_modules. If it is missing the
# baked closure is corrupt — reinstall offline first, falling back to an online
# install only if the offline cache cannot satisfy it (logged, never silent).
if ! [ -x node_modules/.bin/mocha ]; then
    echo "test-setup.sh: mocha missing from node_modules/.bin/; reinstalling from cache." >&2
    if ! npm ci --offline --cache /opt/cache/npm > /tmp/npm-ci.log 2>&1; then
        echo "test-setup.sh: offline npm ci failed; retrying with network." >&2
        tail -40 /tmp/npm-ci.log >&2 || true
        npm ci --cache /opt/cache/npm > /tmp/npm-ci-online.log 2>&1 \
            || { tail -80 /tmp/npm-ci-online.log >&2; exit 1; }
    fi
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR mocha=$(node_modules/.bin/mocha --version 2>/dev/null || echo unknown)"
