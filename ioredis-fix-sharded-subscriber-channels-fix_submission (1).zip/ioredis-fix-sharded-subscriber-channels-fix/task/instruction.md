## Task

we're getting reports about sharded pub/sub misbehaving, and a few related things seem off.

on a cluster with sharded subscribers enabled, dropping every shard channel at once (a shard unsubscribe with no channel given) doesn't reliably take effect. the connection stays subscribed to its shard channels across the cluster even though we asked to drop all of them.

on a single connection running both a regular subscription and a shard subscription, unsubscribing the shard channel quietly breaks the regular one too. nobody touched that subscription, but it silently stops delivering.

and a shard channel that was already unsubscribed can come back after the cluster's slot topology changes, as if it had resubscribed itself.

these come down to how sharded subscriptions get tracked and torn down, so fixing that bookkeeping should do it rather than reworking the cluster command routing or connection layer. please dig in, reproduce each one, and get sharded subscribe/unsubscribe behaving.

you don't need a live redis cluster here. a sharded pub/sub test suite that runs without one already exists, so use it to reproduce and confirm.
