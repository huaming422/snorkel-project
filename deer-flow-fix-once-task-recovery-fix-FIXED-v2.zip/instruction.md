## Task

Whenever the backend restarts, a handful of our one-off scheduled tasks can end up in the wrong end state. The usual case is a task whose run had actually finished fine, but the restart happened before the task itself was updated, so it now shows as cancelled. There are two related problems that turn up around the same moments: a task sometimes takes the result of an older run instead of the one that happened last, and the task's run count drifts away from how many times it really launched.

Here's what we need to hold:

- When a restart finds a one-off task still marked as running, it should settle the task from what its most recent run did. A run that succeeded means completed, one that failed means failed, and one that was interrupted means cancelled. The task's error should be that run's own error (empty for a success), not a generic restart message. This applies both to a single instance coming back up and to an instance starting up alongside others.
- "Most recent" means the run that started last. Our instances' clocks don't always agree, so a later run can carry an earlier or identical timestamp, and it should still win.
- If the task has a run waiting in the queue, or another instance is still starting or running one for it, leave the task alone. That run will settle it when it finishes.
- A result that shows up late from an older run must never replace the result of a newer one.
- Each launch adds exactly one to the task's run count. If the write recording the launch on the task was lost, the count should be right once that run's completion comes in, and a completion that gets delivered twice must not count again.
- The same run outcome should leave the task in the same state no matter which path settles it: the normal completion or any of the recovery paths.
- With the scheduler enabled, if recovery fails during startup, the backend shouldn't carry on starting up and taking requests as if it had worked.
- Recurring tasks should work exactly as they do now, and so should a normal completion with no restart involved. Anything new you store to make this work stays internal and doesn't appear in the task or run data we hand back, and any schema change keeps the migration history on a single line.
