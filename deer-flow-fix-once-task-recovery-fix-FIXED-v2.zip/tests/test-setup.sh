#!/bin/bash
# Setup for the deer-flow-fix-once-task-recovery tests.
#
# The tests drive the scheduler service and its repositories in-process on the
# file-backed SQLite backend, so no services are started here.
#
# The image bakes a fully-resolved project environment at /opt/venv
# (uv sync --frozen --group dev at the starting commit), with the backend's own
# packages installed as editable workspace members, so edits under
# backend/packages/harness or backend/app are imported in place with no
# re-sync. The test phase has no network and the build reset the writable uv
# cache, so re-running uv sync here would try (and fail) to rebuild those
# workspace members from an empty cache; we deliberately do not sync. pytest
# runs with the baked interpreter directly (see verify.toml).

set -euo pipefail

export REPO_NAME=deer-flow
REPO_DIR="/repo/${REPO_NAME}"
VENV_PYTHON="/opt/venv/bin/python"

# Loud guard: the baked environment must exist and still import the persistence
# stack the tests depend on. If this fails the image is broken, so fail the
# setup rather than letting pytest emit a confusing collection error later.
if [ ! -x "${VENV_PYTHON}" ]; then
    echo "test-setup: baked project interpreter ${VENV_PYTHON} is missing" >&2
    exit 1
fi
if ! PYTHONPATH="${REPO_DIR}/backend" "${VENV_PYTHON}" - <<'PY'
import aiosqlite  # noqa: F401  (async SQLite driver the file-backed tests use)
import sqlalchemy  # noqa: F401
import deerflow.persistence.engine  # noqa: F401  (editable workspace member)
PY
then
    echo "test-setup: baked environment cannot import the persistence stack" >&2
    exit 1
fi
