"""Behavioral checks for once-task restart recovery, completion and run counting.

A one-shot ("once") scheduled task stays ``running`` after launch until the
completion hook settles it. If the backend goes down after a run finished but
before the parent task was settled, the restart has to settle it from what the
task's latest run actually did. These tests build the state such a crash leaves
behind (the occurrence row, the durable run it launched, and the parent that
points at that run) and then drive the public service entry points: service
start-up for restart recovery, in single-instance and multi-instance mode,
``handle_run_completion`` for completions, and ``dispatch_task`` for launches.
Assertions read the parent back through the repository and check status,
last_error and run_count only.

This file is collected outside the backend test tree, so the repo's own
conftest is not in scope; the setup block below reproduces only the import
plumbing that conftest would otherwise provide (sys.path + one circular-import
guard), mirroring the backend's own unit-test harness.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from unittest.mock import MagicMock

# --- Import plumbing (replaces the backend conftest, which is out of scope) ---
_REPO_NAME = os.environ.get("REPO_NAME", "deer-flow")
_BACKEND = Path(f"/repo/{_REPO_NAME}/backend")
for _p in (str(_BACKEND), str(_BACKEND / "scripts")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

# Break the subagents circular import exactly as the backend's own conftest
# does, so importing the scheduler service in isolation cannot deadlock on it.
if "deerflow.subagents.executor" not in sys.modules:
    _executor_mock = MagicMock()
    _executor_mock.SubagentExecutor = MagicMock
    _executor_mock.SubagentResult = MagicMock
    _executor_mock.SubagentStatus = MagicMock
    _executor_mock.MAX_CONCURRENT_SUBAGENTS = 3
    _executor_mock.get_background_task_result = MagicMock()
    sys.modules["deerflow.subagents.executor"] = _executor_mock

from datetime import UTC, datetime, timedelta  # noqa: E402
from unittest.mock import patch  # noqa: E402

import pytest  # noqa: E402
from sqlalchemy import update  # noqa: E402

from app.scheduler.service import ScheduledTaskService  # noqa: E402
from deerflow.config.database_config import DatabaseConfig  # noqa: E402
from deerflow.persistence.engine import (  # noqa: E402
    close_engine,
    get_session_factory,
    init_engine_from_config,
)
from deerflow.persistence.run import RunRepository  # noqa: E402
from deerflow.persistence.scheduled_task_runs import ScheduledTaskRunRepository  # noqa: E402
from deerflow.persistence.scheduled_task_runs.model import ScheduledTaskRunRow  # noqa: E402
from deerflow.persistence.scheduled_tasks import ScheduledTaskRepository  # noqa: E402
from deerflow.persistence.scheduled_tasks.model import ScheduledTaskRow  # noqa: E402
from deerflow.runtime.runs.manager import RunRecord  # noqa: E402
from deerflow.runtime.runs.schemas import DisconnectMode, RunStatus  # noqa: E402

_NOW = datetime(2026, 7, 15, 12, 0, 0, tzinfo=UTC)
_USER = "user-1"

# Fields the task and occurrence read-backs exposed at the starting commit.
_TASK_FIELDS = frozenset(
    {
        "assistant_id", "context_mode", "created_at", "id", "last_error", "last_run_at", "last_run_id",
        "last_thread_id", "lease_expires_at", "lease_owner", "next_run_at", "overlap_policy", "prompt",
        "run_count", "schedule_spec", "schedule_type", "status", "thread_id", "timezone", "title",
        "updated_at", "user_id",
    }
)
_OCCURRENCE_FIELDS = frozenset(
    {
        "attempt_count", "created_at", "error", "finished_at", "id", "lease_expires_at", "lease_owner",
        "run_id", "scheduled_for", "started_at", "status", "task_id", "thread_id", "trigger",
    }
)

# Durable run status a launched occurrence's run carries for each occurrence status.
_DURABLE_STATUS = {"success": "success", "failed": "error", "interrupted": "interrupted", "running": "running"}
_TERMINAL = {"success", "failed", "interrupted"}


# ---------------------------------------------------------------------------
# Setup helpers
# ---------------------------------------------------------------------------


async def _init_db(tmp_path) -> tuple[ScheduledTaskRepository, ScheduledTaskRunRepository]:
    """Bring up a fresh file-backed SQLite database and return both repos."""
    await init_engine_from_config(DatabaseConfig(backend="sqlite", sqlite_dir=str(tmp_path)))
    sf = get_session_factory()
    assert sf is not None
    return ScheduledTaskRepository(sf), ScheduledTaskRunRepository(sf)


async def _create_once_task(task_repo: ScheduledTaskRepository, *, task_id: str) -> dict:
    return await task_repo.create(
        task_id=task_id,
        user_id=_USER,
        thread_id=None,
        context_mode="fresh_thread_per_run",
        assistant_id=None,
        title="Once Task",
        prompt="do it",
        schedule_type="once",
        schedule_spec={"run_at": "2026-07-15T12:00:00Z"},
        timezone="UTC",
        next_run_at=None,
    )


async def _create_cron_task(task_repo: ScheduledTaskRepository, *, task_id: str) -> dict:
    return await task_repo.create(
        task_id=task_id,
        user_id=_USER,
        thread_id=None,
        context_mode="fresh_thread_per_run",
        assistant_id=None,
        title="Cron Task",
        prompt="do it daily",
        schedule_type="cron",
        schedule_spec={"cron": "0 9 * * *"},
        timezone="UTC",
        next_run_at=_NOW + timedelta(hours=1),
    )


async def _set_task_running(task_id: str) -> None:
    """Park a task in ``running`` with no lease, as a launched once task sits."""
    sf = get_session_factory()
    async with sf() as session:
        await session.execute(
            update(ScheduledTaskRow)
            .where(ScheduledTaskRow.id == task_id)
            .values(status="running", lease_owner=None, lease_expires_at=None, updated_at=_NOW)
        )
        await session.commit()


async def _put_durable_run(*, run_id: str, task_id: str, task_run_id: str, thread_id: str, status: str, error: str | None) -> None:
    """Write the durable run record a real launch leaves behind."""
    live = status in {"pending", "running"}
    await RunRepository(get_session_factory()).put(
        run_id,
        thread_id=thread_id,
        user_id=_USER,
        status=status,
        metadata={"scheduled_task_id": task_id, "scheduled_task_run_id": task_run_id, "scheduled_trigger": "scheduled"},
        error=error,
        owner_worker_id="peer-worker" if live else None,
        # A live run's owner is still renewing its lease.
        lease_expires_at=(datetime.now(UTC) + timedelta(hours=1)).isoformat() if live else None,
    )


async def _seed_occurrence(
    run_repo: ScheduledTaskRunRepository,
    *,
    task_id: str,
    task_run_id: str,
    status: str,
    error: str | None = None,
    thread_id: str = "thread-1",
    created_at: datetime | None = None,
) -> str | None:
    """Admit one occurrence; for a launched one, add its durable run and the
    launch bookkeeping the parent received. Returns the durable run id."""
    await run_repo.create(
        run_record_id=task_run_id,
        task_id=task_id,
        thread_id=thread_id,
        scheduled_for=created_at or _NOW,
        trigger="scheduled",
        status=status,
    )
    sf = get_session_factory()
    values: dict = {}
    if created_at is not None:
        values["created_at"] = created_at
    if status == "launching":
        # Claimed by another instance that is still starting it.
        values.update(lease_owner="peer-worker", lease_expires_at=datetime.now(UTC) + timedelta(hours=1))
    run_id = None
    durable = _DURABLE_STATUS.get(status)
    if durable is not None:
        run_id = f"run-{task_run_id}"
        await _put_durable_run(run_id=run_id, task_id=task_id, task_run_id=task_run_id, thread_id=thread_id, status=durable, error=error)
        started = created_at or _NOW
        values.update(run_id=run_id, started_at=started, error=error)
        if status in _TERMINAL:
            values["finished_at"] = started + timedelta(seconds=5)
    async with sf() as session:
        if values:
            await session.execute(update(ScheduledTaskRunRow).where(ScheduledTaskRunRow.id == task_run_id).values(**values))
        if run_id is not None:
            await session.execute(
                update(ScheduledTaskRow)
                .where(ScheduledTaskRow.id == task_id)
                .values(
                    status="running",
                    last_run_id=run_id,
                    last_thread_id=thread_id,
                    last_run_at=created_at or _NOW,
                    last_error=None,
                    run_count=ScheduledTaskRow.run_count + 1,
                    lease_owner=None,
                    lease_expires_at=None,
                )
            )
        await session.commit()
    return run_id


async def _get_task(task_repo: ScheduledTaskRepository, task_id: str) -> dict:
    task = await task_repo.get_internal(task_id)
    assert task is not None
    return task


def _service(task_repo, run_repo, *, multi_instance: bool = False, launch_run=None) -> ScheduledTaskService:
    async def _no_launch(**_kwargs):
        raise AssertionError("nothing should be launched here")

    return ScheduledTaskService(
        task_repo=task_repo,
        task_run_repo=run_repo,
        launch_run=launch_run or _no_launch,
        poll_interval_seconds=5,
        lease_seconds=120,
        max_concurrent_runs=3,
        multi_instance=multi_instance,
    )


async def _restart(task_repo, run_repo, *, multi_instance: bool) -> None:
    """Run the service's start-up recovery, then stop before any poll."""
    service = _service(task_repo, run_repo, multi_instance=multi_instance)
    await service.start()
    await service.stop()


def _completion_record(*, run_id: str, task_id: str, task_run_id: str, status, error: str | None = None, thread_id: str = "thread-1") -> RunRecord:
    return RunRecord(
        run_id=run_id,
        thread_id=thread_id,
        assistant_id=None,
        status=status,
        on_disconnect=DisconnectMode.continue_,
        metadata={"scheduled_task_id": task_id, "scheduled_task_run_id": task_run_id},
        user_id=_USER,
        error=error,
    )


_MODES = pytest.mark.parametrize("multi_instance", [False, True], ids=["single-instance", "multi-instance"])


# ---------------------------------------------------------------------------
# Restart recovery settles the parent from the latest run's outcome
# ---------------------------------------------------------------------------


@_MODES
@pytest.mark.parametrize(
    ("run_status", "run_error", "expected_status", "expected_error"),
    [
        ("success", None, "completed", None),
        ("failed", "boom", "failed", "boom"),
        ("interrupted", "user cancelled", "cancelled", "user cancelled"),
    ],
)
async def test_recovery_settles_parent_from_run_outcome(tmp_path, multi_instance, run_status, run_error, expected_status, expected_error):
    """The run finished and its occurrence was recorded, but the backend went
    down before the parent was settled. Recovery must mirror the run's
    outcome and carry the run's own error, not a generic restart message."""
    task_repo, run_repo = await _init_db(tmp_path)
    try:
        await _create_once_task(task_repo, task_id="task-outcome")
        await _seed_occurrence(run_repo, task_id="task-outcome", task_run_id="occ-outcome", status=run_status, error=run_error)

        await _restart(task_repo, run_repo, multi_instance=multi_instance)

        task = await _get_task(task_repo, "task-outcome")
        assert task["status"] == expected_status
        assert task["last_error"] == expected_error
    finally:
        await close_engine()


# ---------------------------------------------------------------------------
# A run that is still waiting or still live elsewhere is left alone
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("multi_instance", "active_status"),
    [(False, "queued"), (True, "queued"), (True, "launching"), (True, "running")],
    ids=["single-instance-queued", "multi-instance-queued", "multi-instance-launching", "multi-instance-running"],
)
async def test_recovery_leaves_active_occurrence_alone(tmp_path, multi_instance, active_status):
    """A queued occurrence, or one another live instance is still starting or
    running, must not be forced terminal by recovery."""
    task_repo, run_repo = await _init_db(tmp_path)
    try:
        await _create_once_task(task_repo, task_id="task-active")
        await _set_task_running("task-active")
        await _seed_occurrence(run_repo, task_id="task-active", task_run_id="occ-active", status=active_status)

        await _restart(task_repo, run_repo, multi_instance=multi_instance)

        task = await _get_task(task_repo, "task-active")
        assert task["status"] == "running"
    finally:
        await close_engine()


# ---------------------------------------------------------------------------
# "Latest" is the run that started most recently, whatever the clocks say
# ---------------------------------------------------------------------------


@_MODES
@pytest.mark.parametrize("older_clock_ahead_seconds", [30, 0], ids=["reversed-timestamps", "equal-timestamps"])
async def test_recovery_uses_most_recent_run_despite_clock_skew(tmp_path, multi_instance, older_clock_ahead_seconds):
    """An earlier run failed; the task was run again and the newer run
    succeeded just before the crash. The instance that admitted the older run
    had a clock equal to or ahead of the newer one, and the older id sorts
    last, so only the real start order picks the newer success."""
    task_repo, run_repo = await _init_db(tmp_path)
    try:
        await _create_once_task(task_repo, task_id="task-skew")
        await _seed_occurrence(
            run_repo,
            task_id="task-skew",
            task_run_id="task-run-ffffffffffffffffffffffffffffffff",
            status="failed",
            error="older failure",
            thread_id="thread-old",
            created_at=_NOW + timedelta(seconds=older_clock_ahead_seconds),
        )
        await _seed_occurrence(
            run_repo,
            task_id="task-skew",
            task_run_id="task-run-00000000000000000000000000000000",
            status="success",
            thread_id="thread-new",
            created_at=_NOW,
        )

        await _restart(task_repo, run_repo, multi_instance=multi_instance)

        task = await _get_task(task_repo, "task-skew")
        assert task["status"] == "completed"
        assert task["last_error"] is None
    finally:
        await close_engine()


# ---------------------------------------------------------------------------
# A late result from an older run cannot replace a newer one
# ---------------------------------------------------------------------------


async def test_late_older_completion_does_not_overwrite_newer_result(tmp_path):
    """The older run was written off as interrupted and the task ran again.
    The newer run succeeds; then the older run's own failure arrives late
    through the completion hook and must not replace the newer success."""
    task_repo, run_repo = await _init_db(tmp_path)
    try:
        await _create_once_task(task_repo, task_id="task-stale")
        old_run = await _seed_occurrence(run_repo, task_id="task-stale", task_run_id="occ-old", status="interrupted", error="lease lost", thread_id="thread-old")
        new_run = await _seed_occurrence(run_repo, task_id="task-stale", task_run_id="occ-new", status="running", thread_id="thread-new")

        service = _service(task_repo, run_repo)
        await service.handle_run_completion(
            _completion_record(run_id=new_run, task_id="task-stale", task_run_id="occ-new", status=RunStatus.success, thread_id="thread-new")
        )
        projected = await _get_task(task_repo, "task-stale")
        assert projected["status"] == "completed"
        assert projected["last_error"] is None

        await service.handle_run_completion(
            _completion_record(run_id=old_run, task_id="task-stale", task_run_id="occ-old", status=RunStatus.error, error="stale failure", thread_id="thread-old")
        )

        task = await _get_task(task_repo, "task-stale")
        assert task["status"] == "completed"
        assert task["last_error"] is None
    finally:
        await close_engine()


# ---------------------------------------------------------------------------
# Each launch is counted exactly once
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("bookkeeping_lost", [False, True], ids=["bookkeeping-saved", "bookkeeping-lost"])
async def test_launch_counted_exactly_once(tmp_path, bookkeeping_lost):
    """Launch a once task through the normal dispatch path, then deliver its
    completion twice. The launch counts once whether or not the parent's
    launch bookkeeping was saved, and the repeated completion adds nothing."""
    task_repo, run_repo = await _init_db(tmp_path)
    try:
        await _create_once_task(task_repo, task_id="task-count")
        launched: dict = {}

        async def _launch(*, thread_id, metadata, **_kwargs):
            run_id = "run-count"
            await _put_durable_run(
                run_id=run_id,
                task_id=metadata["scheduled_task_id"],
                task_run_id=metadata["scheduled_task_run_id"],
                thread_id=thread_id,
                status="running",
                error=None,
            )
            launched.update(run_id=run_id, thread_id=thread_id, task_run_id=metadata["scheduled_task_run_id"])
            return {"run_id": run_id, "thread_id": thread_id}

        service = _service(task_repo, run_repo, launch_run=_launch)
        task = await _get_task(task_repo, "task-count")
        if bookkeeping_lost:
            # The parent's post-launch write never lands.
            with patch.object(task_repo, "update_after_launch", side_effect=RuntimeError("database went away")):
                result = await service.dispatch_task(task, now=_NOW, trigger="manual")
        else:
            result = await service.dispatch_task(task, now=_NOW, trigger="manual")
        assert result["outcome"] == "launched"

        record = _completion_record(
            run_id=launched["run_id"],
            task_id="task-count",
            task_run_id=launched["task_run_id"],
            status=RunStatus.success,
            thread_id=launched["thread_id"],
        )
        await service.handle_run_completion(record)
        task = await _get_task(task_repo, "task-count")
        assert task["status"] == "completed"
        assert task["run_count"] == 1

        # A repeated delivery of the same completion must not count again.
        await service.handle_run_completion(record)
        task = await _get_task(task_repo, "task-count")
        assert task["status"] == "completed"
        assert task["run_count"] == 1
    finally:
        await close_engine()


# ---------------------------------------------------------------------------
# Read-backs and migrations keep their existing shape
# ---------------------------------------------------------------------------


async def test_read_backs_expose_no_new_fields(tmp_path):
    """Task and occurrence read-backs carry no fields beyond those they had at
    the starting commit."""
    task_repo, run_repo = await _init_db(tmp_path)
    try:
        await _create_once_task(task_repo, task_id="task-fields")
        await _seed_occurrence(run_repo, task_id="task-fields", task_run_id="occ-fields", status="running")

        reads = [
            await task_repo.get_internal("task-fields"),
            await task_repo.get("task-fields", user_id=_USER),
            *(await task_repo.list_by_user(_USER)),
        ]
        for task in reads:
            assert task is not None
            assert set(task.keys()) <= _TASK_FIELDS, sorted(set(task.keys()) - _TASK_FIELDS)
        occurrences = await run_repo.list_by_task("task-fields")
        assert occurrences
        for occurrence in occurrences:
            assert set(occurrence.keys()) <= _OCCURRENCE_FIELDS, sorted(set(occurrence.keys()) - _OCCURRENCE_FIELDS)
    finally:
        await close_engine()


def test_migration_tree_has_single_head():
    """The migration history exposes exactly one head revision.

    ``_get_head_revision`` raises if the tree has branched into multiple heads,
    so a successful call asserts the single-head invariant without pinning any
    specific revision id.
    """
    from deerflow.persistence.bootstrap import _get_head_revision

    head = _get_head_revision()
    assert isinstance(head, str) and head


# ---------------------------------------------------------------------------
# Behaviour that must not change
# ---------------------------------------------------------------------------


async def test_normal_once_completion_still_settles(tmp_path):
    """A plain successful completion still drives a once task to ``completed``."""
    task_repo, run_repo = await _init_db(tmp_path)
    try:
        await _create_once_task(task_repo, task_id="task-happy")
        run_id = await _seed_occurrence(run_repo, task_id="task-happy", task_run_id="occ-happy", status="running")

        service = _service(task_repo, run_repo)
        await service.handle_run_completion(
            _completion_record(run_id=run_id, task_id="task-happy", task_run_id="occ-happy", status=RunStatus.success)
        )

        task = await _get_task(task_repo, "task-happy")
        assert task["status"] == "completed"
        assert task["last_error"] is None
    finally:
        await close_engine()


@_MODES
async def test_recovery_leaves_cron_parent_running(tmp_path, multi_instance):
    """Recovery only settles once tasks; a recurring parent keeps its status."""
    task_repo, run_repo = await _init_db(tmp_path)
    try:
        await _create_cron_task(task_repo, task_id="task-cron")
        await _set_task_running("task-cron")

        await _restart(task_repo, run_repo, multi_instance=multi_instance)

        task = await _get_task(task_repo, "task-cron")
        assert task["status"] == "running"
    finally:
        await close_engine()
