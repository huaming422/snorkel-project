## Task

we've got data loss when people move an existing database over to mvcc. tables with an autoincrement primary key are the ones that break: right after the switch, new inserts start handing out ids from 1 again and quietly overwrite the rows that already had those ids. the inserts succeed, nothing errors, the old rows are just gone. databases that were on mvcc from the start are fine, it's only the ones that get switched over after they already have data. can you dig in and fix it so new ids keep climbing past what's already in the table instead of clobbering existing rows?
