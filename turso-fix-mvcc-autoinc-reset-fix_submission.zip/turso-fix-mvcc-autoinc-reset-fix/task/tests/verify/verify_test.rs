//! Behavioural verifier for `turso-fix-mvcc-autoinc-reset`.
//!
//! The bug: after an existing database with an `INTEGER PRIMARY KEY
//! AUTOINCREMENT` table is switched to the MVCC journal mode, the first
//! inserts after the switch restart id allocation at 1 and silently
//! overwrite the rows that already own those ids (data loss, no error).
//!
//! These tests observe the bug ONLY through turso's stable, pre-existing
//! public Rust API (`turso_core`): open a file database, run SQL through a
//! `Connection`, switch journal mode with `pragma_update`, and read ids
//! back. They never import or name any symbol the fix introduces or
//! refactors internally — correctness is judged purely on the observable
//! ids and row contents, which any valid fix must get right regardless of
//! how it persists the carried-over sequence.
//!
//! This file is self-contained: it is copied into
//! `tests/tests/verify_test.rs` and auto-discovered by cargo as the
//! `verify_test` integration target of the `core_tester` package. It does
//! not use `crate::common` or any sibling test module, so it only relies
//! on `turso_core`'s public surface plus `tempfile`.

use std::path::Path;
use std::sync::Arc;

use tempfile::TempDir;
use turso_core::{
    ConnectOpts, Connection, Database, DatabaseOpts, OpenFlags, PlatformIO, SqliteDialect,
};

/// Open the database file read-write (the normal WAL default on first open).
fn open_rw(path: &Path) -> Arc<Database> {
    let io = Arc::new(PlatformIO::new().unwrap());
    Database::open_file_with_flags(
        io,
        path.to_str().unwrap(),
        OpenFlags::default(),
        DatabaseOpts::new(),
        None,
        Arc::new(SqliteDialect),
    )
    .expect("open database read-write")
}

/// Open the database file read-only. A correct, idempotent sequence sync
/// must not need to write anything here, so a read-only open must succeed.
fn open_ro(path: &Path) -> Arc<Database> {
    let io = Arc::new(PlatformIO::new().unwrap());
    Database::open_file_with_flags(
        io,
        path.to_str().unwrap(),
        OpenFlags::ReadOnly,
        DatabaseOpts::new(),
        None,
        Arc::new(SqliteDialect),
    )
    .expect("a read-only open must not need to write")
}

fn connect(db: &Arc<Database>) -> Arc<Connection> {
    db.connect(ConnectOpts::new()).unwrap()
}

/// Read `(id, title)` for every row in `posts`, ordered by id. Inlined here
/// (the repo's `exec_rows` helper lives in a sibling test module that a
/// standalone integration target cannot import).
fn posts(conn: &Arc<Connection>) -> Vec<(i64, String)> {
    let mut stmt = conn
        .prepare("SELECT id, title FROM posts ORDER BY id")
        .unwrap();
    let mut rows = Vec::new();
    stmt.run_with_row_callback(|row| {
        rows.push((row.get::<i64>(0)?, row.get::<String>(1)?));
        Ok(())
    })
    .unwrap();
    rows
}

fn row(id: i64, title: &str) -> (i64, String) {
    (id, title.to_string())
}

/// Create `posts`, seed `a`,`b` in plain WAL mode (closing the session so the
/// rows are on disk), then return the path for the caller to open as MVCC.
fn seed_wal_db(tmp: &TempDir) -> std::path::PathBuf {
    let db_path = tmp.path().join("test.db");
    let db = open_rw(&db_path);
    let conn = connect(&db);
    conn.execute("CREATE TABLE posts (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT)")
        .unwrap();
    conn.execute("INSERT INTO posts (title) VALUES ('a'), ('b')")
        .unwrap();
    db_path
}

/// FAIL_TO_PASS (basic): right after switching an existing AUTOINCREMENT
/// database to MVCC, new inserts must continue past the prior max id instead
/// of restarting at 1 and clobbering existing rows.
///
/// On the unfixed build the carried-over sequence watermark is never
/// persisted, so the first post-switch insert reuses id 1 — `a` is replaced
/// and the ids no longer read `[1,2,3]`.
#[test]
fn autoincrement_ids_continue_after_switch_to_mvcc() {
    let tmp = TempDir::new().unwrap();
    let db_path = seed_wal_db(&tmp);

    let db = open_rw(&db_path);
    let conn = connect(&db);
    // Switch the existing database to MVCC, then insert through a fresh
    // connection (mirrors the user's reproduction: switch, then write).
    conn.pragma_update("journal_mode", "'mvcc'")
        .expect("switch existing database to mvcc");
    let writer = connect(&db);
    writer
        .execute("INSERT INTO posts (title) VALUES ('c')")
        .unwrap();

    assert_eq!(
        posts(&writer),
        vec![row(1, "a"), row(2, "b"), row(3, "c")],
        "after switching to MVCC, the insert must continue the sequence \
         (id 3) and keep the existing rows, not restart at 1 and overwrite them"
    );
}

/// FAIL_TO_PASS (non-basic): the carried-over sequence must be durable and
/// the sync must be idempotent. After the switch, reopening the database with
/// no intervening writes must keep the sequence intact, a read-only open must
/// succeed (the sync must not need to write on every open), and a later
/// insert must still climb rather than reset.
///
/// On the unfixed build the watermark was never committed, so after a reopen
/// the next insert restarts the sequence and overwrites an existing row.
#[test]
fn autoincrement_watermark_survives_reopen_and_readonly() {
    let tmp = TempDir::new().unwrap();
    let db_path = seed_wal_db(&tmp);

    // Switch to MVCC and do the first post-switch insert in this session.
    {
        let db = open_rw(&db_path);
        let conn = connect(&db);
        conn.pragma_update("journal_mode", "'mvcc'")
            .expect("switch existing database to mvcc");
        let writer = connect(&db);
        writer
            .execute("INSERT INTO posts (title) VALUES ('c')")
            .unwrap();
        assert_eq!(posts(&writer), vec![row(1, "a"), row(2, "b"), row(3, "c")]);
    }

    // Reopen a couple of times without writing anything; the data must stay.
    for _ in 0..2 {
        let db = open_rw(&db_path);
        let conn = connect(&db);
        assert_eq!(
            posts(&conn),
            vec![row(1, "a"), row(2, "b"), row(3, "c")],
            "reopening without writes must not disturb the rows or the sequence"
        );
    }

    // A read-only open must succeed and see the same rows: an idempotent sync
    // does not try to write on open. A fix that rewrites the sequence on every
    // open would make this read-only open fail.
    {
        let db = open_ro(&db_path);
        let conn = connect(&db);
        assert_eq!(
            posts(&conn),
            vec![row(1, "a"), row(2, "b"), row(3, "c")],
            "a read-only reopen must succeed and preserve the rows"
        );
    }

    // A further insert after all those reopens must still climb to id 4.
    {
        let db = open_rw(&db_path);
        let conn = connect(&db);
        conn.execute("INSERT INTO posts (title) VALUES ('d')")
            .unwrap();
        assert_eq!(
            posts(&conn),
            vec![row(1, "a"), row(2, "b"), row(3, "c"), row(4, "d")],
            "after reopening, the next insert must continue the sequence (id 4), \
             proving the carried-over watermark was persisted"
        );
    }
}

/// PASS_TO_PASS: a database that never switches to MVCC must still allocate
/// AUTOINCREMENT ids normally. Guards against a fix that "solves" the switch
/// case by breaking ordinary autoincrement. Passes on both builds.
#[test]
fn autoincrement_ids_monotonic_without_mvcc_switch() {
    let tmp = TempDir::new().unwrap();
    let db_path = tmp.path().join("test.db");

    let db = open_rw(&db_path);
    let conn = connect(&db);
    conn.execute("CREATE TABLE posts (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT)")
        .unwrap();
    conn.execute("INSERT INTO posts (title) VALUES ('a'), ('b'), ('c'), ('d'), ('e')")
        .unwrap();

    assert_eq!(
        posts(&conn),
        vec![
            row(1, "a"),
            row(2, "b"),
            row(3, "c"),
            row(4, "d"),
            row(5, "e"),
        ],
        "plain WAL autoincrement must allocate ids 1..5 in order"
    );
}
