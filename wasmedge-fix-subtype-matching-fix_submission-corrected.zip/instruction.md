## Task

We run WasmEdge embedded, with modules that rely on GC and typed function references, and its type checks get several cases wrong. Some modules that are fine get refused when we link them, and some that don't fit are let through and only go wrong once code runs. Function imports with ordinary signatures behave, which is why we didn't spot it sooner.

What we've hit so far:

- A tag import that declares a super type of the exported tag's type links.
- When module B takes a global, a table or a tag from A and exports it again, a module that imports it from B and declares exactly A's types fails with IncompatibleImportType.
- We put host functions into tables from the embedder side, and a host function's type is a plain final func type. Even so, `call_indirect` through a non-final `(sub (func))` type with the same params and results calls it, and so does `call_indirect` through a `(func)` declared inside a `rec` group with other types. `ref.test`, `ref.cast`, `br_on_cast` and `br_on_cast_fail` are off the other way: `ref.test (ref func)` gives 0 for the host function, and `ref.cast` to its exact type traps. Code compiled ahead of time or with the JIT gets the same wrong answers.
- Our own wasm functions go wrong too once the embedder puts them into a table. `ref.test` against the type a function was declared with, or against a super type of it, gives 0, and so does `ref.test (ref func)`; `ref.cast` to that type traps. It's the same whether the function comes from the module doing the test or from another module, and it happens in compiled code as well. `call_indirect` on them works.
- Where struct types refer to the same earlier struct type more than once, a few dozen levels are enough to stall us. A function import whose parameter type tops such a chain never finishes linking, and a module that declares two equal chains and passes a value of one as the other never finishes validating. Each extra level seems to double the time.

All of this has to follow the subtyping rules in the WebAssembly spec, and the same way everywhere a type gets matched: in the validator, in the interpreter, and in compiled code. Get the matching to do that.
