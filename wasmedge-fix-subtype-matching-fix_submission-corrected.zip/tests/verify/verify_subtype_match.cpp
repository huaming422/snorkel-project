// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: Copyright The WasmEdge Authors
//
// Type matching of imports, indirect calls and reference casts, checked
// through the embedder API: build a VM or an executor, register and load
// modules, validate, instantiate, execute, and compare the outcome or the
// error code with what the WebAssembly specification gives.
//
// Each byte array is a fixed encoding of the (module ...) source in the
// comment above it. The GC and typed function references proposals are on in
// the default Configure.

#include "common/spdlog.h"
#include "common/types.h"
#include "executor/executor.h"
#include "loader/loader.h"
#include "validator/validator.h"
#include "vm/vm.h"
#ifdef WASMEDGE_USE_LLVM
#include "llvm/compiler.h"
#include "llvm/jit.h"
#endif

#include <array>
#include <cstdint>
#include <functional>
#include <gtest/gtest.h>
#include <map>
#include <memory>
#include <string>
#include <variant>
#include <vector>

namespace {

using namespace WasmEdge;

/// Host function that does nothing.
class Nop : public Runtime::HostFunction<Nop> {
public:
  Expect<void> body(const Runtime::CallingFrame &) { return {}; }
};

/// Host function that adds one to its argument.
class AddOne : public Runtime::HostFunction<AddOne> {
public:
  Expect<uint32_t> body(const Runtime::CallingFrame &, uint32_t X) {
    return X + 1;
  }
};

// clang-format off

/// Binary Wasm module: exports a tag whose type has a super type.
///
/// (module
///   (type $super (sub (func)))
///   (type $sub (sub $super (func)))
///   (tag (export "t") (type $sub)))
std::array<WasmEdge::Byte, 34> TagSubTypeExportWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x0c, 0x02, 0x50,
    0x00, 0x60, 0x00, 0x00, 0x50, 0x01, 0x00, 0x60, 0x00, 0x00, 0x0d, 0x03,
    0x01, 0x00, 0x01, 0x07, 0x05, 0x01, 0x01, 0x74, 0x04, 0x00};

/// Binary Wasm module: imports the tag with its super type.
///
/// (module
///   (type $super (sub (func)))
///   (import "M" "t" (tag (type $super))))
std::array<WasmEdge::Byte, 26> TagSuperTypeImportWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x06, 0x01, 0x50,
    0x00, 0x60, 0x00, 0x00, 0x02, 0x08, 0x01, 0x01, 0x4d, 0x01, 0x74, 0x04,
    0x00, 0x00};

/// Binary Wasm module: imports the tag with an equivalent type.
///
/// (module
///   (type $super (sub (func)))
///   (type $sub (sub $super (func)))
///   (import "M" "t" (tag (type $sub))))
std::array<WasmEdge::Byte, 32> TagSubTypeImportWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x0c, 0x02, 0x50,
    0x00, 0x60, 0x00, 0x00, 0x50, 0x01, 0x00, 0x60, 0x00, 0x00, 0x02, 0x08,
    0x01, 0x01, 0x4d, 0x01, 0x74, 0x04, 0x00, 0x01};

/// Binary Wasm module: defines and exports a global, a table, and a tag.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (global (export "g") (ref null $s) (ref.null $s))
///   (table (export "t") 1 (ref null $s))
///   (tag (export "e") (type $ft)))
std::array<WasmEdge::Byte, 55> ReExportDefineWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x09, 0x02, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x04, 0x05, 0x01, 0x63, 0x00,
    0x00, 0x01, 0x0d, 0x03, 0x01, 0x00, 0x01, 0x06, 0x07, 0x01, 0x63, 0x00,
    0x00, 0xd0, 0x00, 0x0b, 0x07, 0x0d, 0x03, 0x01, 0x67, 0x03, 0x00, 0x01,
    0x74, 0x01, 0x00, 0x01, 0x65, 0x04, 0x00};

/// Binary Wasm module: imports them from A and exports them again. It
/// declares one type of its own ahead of the two it shares with A.
///
/// (module
///   (type $f (func))
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (import "A" "g" (global (ref null $s)))
///   (import "A" "t" (table 1 (ref null $s)))
///   (import "A" "e" (tag (type $ft)))
///   (export "g" (global 0))
///   (export "t" (table 0))
///   (export "e" (tag 0)))
std::array<WasmEdge::Byte, 64> ReExportForwardWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x0c, 0x03, 0x60,
    0x00, 0x00, 0x5f, 0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x02, 0x19,
    0x03, 0x01, 0x41, 0x01, 0x67, 0x03, 0x63, 0x01, 0x00, 0x01, 0x41, 0x01,
    0x74, 0x01, 0x63, 0x01, 0x00, 0x01, 0x01, 0x41, 0x01, 0x65, 0x04, 0x00,
    0x02, 0x07, 0x0d, 0x03, 0x01, 0x67, 0x03, 0x00, 0x01, 0x74, 0x01, 0x00,
    0x01, 0x65, 0x04, 0x00};

/// Binary Wasm module: imports the re-exported global.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (import "B" "g" (global (ref null $s))))
std::array<WasmEdge::Byte, 30> ReExportGlobalImportWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x09, 0x02, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x02, 0x09, 0x01, 0x01, 0x42,
    0x01, 0x67, 0x03, 0x63, 0x00, 0x00};

/// Binary Wasm module: imports the re-exported table.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (import "B" "t" (table 1 (ref null $s))))
std::array<WasmEdge::Byte, 31> ReExportTableImportWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x09, 0x02, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x02, 0x0a, 0x01, 0x01, 0x42,
    0x01, 0x74, 0x01, 0x63, 0x00, 0x00, 0x01};

/// Binary Wasm module: imports the re-exported tag.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (import "B" "e" (tag (type $ft))))
std::array<WasmEdge::Byte, 29> ReExportTagImportWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x09, 0x02, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x02, 0x08, 0x01, 0x01, 0x42,
    0x01, 0x65, 0x04, 0x00, 0x01};

/// Binary Wasm module: calls and tests the function in its table.
///
/// (module
///   (type $f (func))
///   (type $g (sub (func)))
///   (table (export "tab") 1 funcref)
///   (func (export "call_f") (call_indirect (type $f) (i32.const 0)))
///   (func (export "call_g") (call_indirect (type $g) (i32.const 0)))
///   (func (export "test_f") (result i32)
///     (ref.test (ref $f) (table.get 0 (i32.const 0))))
///   (func (export "test_g") (result i32)
///     (ref.test (ref $g) (table.get 0 (i32.const 0)))))
std::array<WasmEdge::Byte, 120> HostFuncTableWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x0d, 0x03, 0x60,
    0x00, 0x00, 0x50, 0x00, 0x60, 0x00, 0x00, 0x60, 0x00, 0x01, 0x7f, 0x03,
    0x05, 0x04, 0x00, 0x00, 0x02, 0x02, 0x04, 0x04, 0x01, 0x70, 0x00, 0x01,
    0x07, 0x2b, 0x05, 0x03, 0x74, 0x61, 0x62, 0x01, 0x00, 0x06, 0x63, 0x61,
    0x6c, 0x6c, 0x5f, 0x66, 0x00, 0x00, 0x06, 0x63, 0x61, 0x6c, 0x6c, 0x5f,
    0x67, 0x00, 0x01, 0x06, 0x74, 0x65, 0x73, 0x74, 0x5f, 0x66, 0x00, 0x02,
    0x06, 0x74, 0x65, 0x73, 0x74, 0x5f, 0x67, 0x00, 0x03, 0x0a, 0x25, 0x04,
    0x07, 0x00, 0x41, 0x00, 0x11, 0x00, 0x00, 0x0b, 0x07, 0x00, 0x41, 0x00,
    0x11, 0x01, 0x00, 0x0b, 0x09, 0x00, 0x41, 0x00, 0x25, 0x00, 0xfb, 0x14,
    0x00, 0x0b, 0x09, 0x00, 0x41, 0x00, 0x25, 0x00, 0xfb, 0x14, 0x01, 0x0b};

/// Binary Wasm module: exports a tag typed with the super type.
///
/// (module
///   (type $super (sub (func)))
///   (type $sub (sub $super (func)))
///   (tag (export "t") (type $super)))
std::array<WasmEdge::Byte, 34> TagSuperTypeExportWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x0c, 0x02, 0x50,
    0x00, 0x60, 0x00, 0x00, 0x50, 0x01, 0x00, 0x60, 0x00, 0x00, 0x0d, 0x03,
    0x01, 0x00, 0x00, 0x07, 0x05, 0x01, 0x01, 0x74, 0x04, 0x00};

/// Binary Wasm module: defines and exports two globals, a table and a tag.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (global (export "g") (ref null $s) (ref.null $s))
///   (global (export "gm") (mut (ref null $s)) (ref.null $s))
///   (table (export "t") 1 (ref null $s))
///   (tag (export "e") (type $ft)))
std::array<WasmEdge::Byte, 66> RexDefineWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x09, 0x02, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x04, 0x05, 0x01, 0x63, 0x00,
    0x00, 0x01, 0x0d, 0x03, 0x01, 0x00, 0x01, 0x06, 0x0d, 0x02, 0x63, 0x00,
    0x00, 0xd0, 0x00, 0x0b, 0x63, 0x00, 0x01, 0xd0, 0x00, 0x0b, 0x07, 0x12,
    0x04, 0x01, 0x67, 0x03, 0x00, 0x02, 0x67, 0x6d, 0x03, 0x01, 0x01, 0x74,
    0x01, 0x00, 0x01, 0x65, 0x04, 0x00};

/// Binary Wasm module: imports them from A and exports them again.
///
/// (module
///   (type $f (func))
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (import "A" "g" (global (ref null $s)))
///   (import "A" "gm" (global (mut (ref null $s))))
///   (import "A" "t" (table 1 (ref null $s)))
///   (import "A" "e" (tag (type $ft)))
///   (export "g" (global 0)) (export "gm" (global 1))
///   (export "t" (table 0)) (export "e" (tag 0)))
std::array<WasmEdge::Byte, 78> RexForwardWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x0c, 0x03, 0x60,
    0x00, 0x00, 0x5f, 0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x02, 0x22,
    0x04, 0x01, 0x41, 0x01, 0x67, 0x03, 0x63, 0x01, 0x00, 0x01, 0x41, 0x02,
    0x67, 0x6d, 0x03, 0x63, 0x01, 0x01, 0x01, 0x41, 0x01, 0x74, 0x01, 0x63,
    0x01, 0x00, 0x01, 0x01, 0x41, 0x01, 0x65, 0x04, 0x00, 0x02, 0x07, 0x12,
    0x04, 0x01, 0x67, 0x03, 0x00, 0x02, 0x67, 0x6d, 0x03, 0x01, 0x01, 0x74,
    0x01, 0x00, 0x01, 0x65, 0x04, 0x00};

/// Binary Wasm module: imports them from B and exports them once more.
///
/// (module
///   (type (func))
///   (type (func (param i32 i32)))
///   (type (struct))
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (import "B" "g" (global (ref null $s)))
///   (import "B" "gm" (global (mut (ref null $s))))
///   (import "B" "t" (table 1 (ref null $s)))
///   (import "B" "e" (tag (type $ft)))
///   (export "g" (global 0)) (export "gm" (global 1))
///   (export "t" (table 0)) (export "e" (tag 0)))
std::array<WasmEdge::Byte, 85> RexForwardTwiceWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x13, 0x05, 0x60,
    0x00, 0x00, 0x60, 0x02, 0x7f, 0x7f, 0x00, 0x5f, 0x00, 0x5f, 0x01, 0x7f,
    0x00, 0x60, 0x01, 0x7f, 0x00, 0x02, 0x22, 0x04, 0x01, 0x42, 0x01, 0x67,
    0x03, 0x63, 0x03, 0x00, 0x01, 0x42, 0x02, 0x67, 0x6d, 0x03, 0x63, 0x03,
    0x01, 0x01, 0x42, 0x01, 0x74, 0x01, 0x63, 0x03, 0x00, 0x01, 0x01, 0x42,
    0x01, 0x65, 0x04, 0x00, 0x04, 0x07, 0x12, 0x04, 0x01, 0x67, 0x03, 0x00,
    0x02, 0x67, 0x6d, 0x03, 0x01, 0x01, 0x74, 0x01, 0x00, 0x01, 0x65, 0x04,
    0x00};

/// Binary Wasm module: imports from B.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "B" "g" (global (ref null $s))))
std::array<WasmEdge::Byte, 38> RexGlobalFromBWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x09, 0x01, 0x01, 0x42, 0x01, 0x67, 0x03, 0x63,
    0x00, 0x00};

/// Binary Wasm module: imports from D.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "D" "g" (global (ref null $s))))
std::array<WasmEdge::Byte, 38> RexGlobalFromDWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x09, 0x01, 0x01, 0x44, 0x01, 0x67, 0x03, 0x63,
    0x00, 0x00};

/// Binary Wasm module: imports from B.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "B" "g" (global (ref null struct))))
std::array<WasmEdge::Byte, 38> RexGlobalAbstractFromBWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x09, 0x01, 0x01, 0x42, 0x01, 0x67, 0x03, 0x63,
    0x6b, 0x00};

/// Binary Wasm module: imports from D.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "D" "g" (global (ref null struct))))
std::array<WasmEdge::Byte, 38> RexGlobalAbstractFromDWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x09, 0x01, 0x01, 0x44, 0x01, 0x67, 0x03, 0x63,
    0x6b, 0x00};

/// Binary Wasm module: imports from B.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "B" "gm" (global (mut (ref null $s)))))
std::array<WasmEdge::Byte, 39> RexMutGlobalFromBWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x0a, 0x01, 0x01, 0x42, 0x02, 0x67, 0x6d, 0x03,
    0x63, 0x00, 0x01};

/// Binary Wasm module: imports from D.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "D" "gm" (global (mut (ref null $s)))))
std::array<WasmEdge::Byte, 39> RexMutGlobalFromDWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x0a, 0x01, 0x01, 0x44, 0x02, 0x67, 0x6d, 0x03,
    0x63, 0x00, 0x01};

/// Binary Wasm module: imports from B.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "B" "t" (table 1 (ref null $s))))
std::array<WasmEdge::Byte, 39> RexTableFromBWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x0a, 0x01, 0x01, 0x42, 0x01, 0x74, 0x01, 0x63,
    0x00, 0x00, 0x01};

/// Binary Wasm module: imports from D.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "D" "t" (table 1 (ref null $s))))
std::array<WasmEdge::Byte, 39> RexTableFromDWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x0a, 0x01, 0x01, 0x44, 0x01, 0x74, 0x01, 0x63,
    0x00, 0x00, 0x01};

/// Binary Wasm module: imports from B.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "B" "e" (tag (type $ft))))
std::array<WasmEdge::Byte, 37> RexTagFromBWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x08, 0x01, 0x01, 0x42, 0x01, 0x65, 0x04, 0x00,
    0x01};

/// Binary Wasm module: imports from D.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "D" "e" (tag (type $ft))))
std::array<WasmEdge::Byte, 37> RexTagFromDWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x08, 0x01, 0x01, 0x44, 0x01, 0x65, 0x04, 0x00,
    0x01};

/// Binary Wasm module: imports from B.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "B" "g" (global (ref null $o))))
std::array<WasmEdge::Byte, 38> RexGlobalOtherFromBWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x09, 0x01, 0x01, 0x42, 0x01, 0x67, 0x03, 0x63,
    0x02, 0x00};

/// Binary Wasm module: imports from D.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "D" "g" (global (ref null $o))))
std::array<WasmEdge::Byte, 38> RexGlobalOtherFromDWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x09, 0x01, 0x01, 0x44, 0x01, 0x67, 0x03, 0x63,
    0x02, 0x00};

/// Binary Wasm module: imports from A.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "A" "g" (global (ref null $o))))
std::array<WasmEdge::Byte, 38> RexGlobalOtherFromAWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x09, 0x01, 0x01, 0x41, 0x01, 0x67, 0x03, 0x63,
    0x02, 0x00};

/// Binary Wasm module: imports from B.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "B" "gm" (global (mut (ref null $o)))))
std::array<WasmEdge::Byte, 39> RexMutGlobalOtherFromBWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x0a, 0x01, 0x01, 0x42, 0x02, 0x67, 0x6d, 0x03,
    0x63, 0x02, 0x01};

/// Binary Wasm module: imports from D.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "D" "gm" (global (mut (ref null $o)))))
std::array<WasmEdge::Byte, 39> RexMutGlobalOtherFromDWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x0a, 0x01, 0x01, 0x44, 0x02, 0x67, 0x6d, 0x03,
    0x63, 0x02, 0x01};

/// Binary Wasm module: imports from A.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "A" "gm" (global (mut (ref null $o)))))
std::array<WasmEdge::Byte, 39> RexMutGlobalOtherFromAWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x0a, 0x01, 0x01, 0x41, 0x02, 0x67, 0x6d, 0x03,
    0x63, 0x02, 0x01};

/// Binary Wasm module: imports from B.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "B" "gm" (global (mut (ref null struct)))))
std::array<WasmEdge::Byte, 39> RexMutGlobalAbstractFromBWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x0a, 0x01, 0x01, 0x42, 0x02, 0x67, 0x6d, 0x03,
    0x63, 0x6b, 0x01};

/// Binary Wasm module: imports from D.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "D" "gm" (global (mut (ref null struct)))))
std::array<WasmEdge::Byte, 39> RexMutGlobalAbstractFromDWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x0a, 0x01, 0x01, 0x44, 0x02, 0x67, 0x6d, 0x03,
    0x63, 0x6b, 0x01};

/// Binary Wasm module: imports from A.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "A" "gm" (global (mut (ref null struct)))))
std::array<WasmEdge::Byte, 39> RexMutGlobalAbstractFromAWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x0a, 0x01, 0x01, 0x41, 0x02, 0x67, 0x6d, 0x03,
    0x63, 0x6b, 0x01};

/// Binary Wasm module: imports from B.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "B" "t" (table 1 (ref null $o))))
std::array<WasmEdge::Byte, 39> RexTableOtherFromBWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x0a, 0x01, 0x01, 0x42, 0x01, 0x74, 0x01, 0x63,
    0x02, 0x00, 0x01};

/// Binary Wasm module: imports from D.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "D" "t" (table 1 (ref null $o))))
std::array<WasmEdge::Byte, 39> RexTableOtherFromDWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x0a, 0x01, 0x01, 0x44, 0x01, 0x74, 0x01, 0x63,
    0x02, 0x00, 0x01};

/// Binary Wasm module: imports from A.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "A" "t" (table 1 (ref null $o))))
std::array<WasmEdge::Byte, 39> RexTableOtherFromAWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x0a, 0x01, 0x01, 0x41, 0x01, 0x74, 0x01, 0x63,
    0x02, 0x00, 0x01};

/// Binary Wasm module: imports from B.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "B" "t" (table 1 (ref null struct))))
std::array<WasmEdge::Byte, 39> RexTableAbstractFromBWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x0a, 0x01, 0x01, 0x42, 0x01, 0x74, 0x01, 0x63,
    0x6b, 0x00, 0x01};

/// Binary Wasm module: imports from D.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "D" "t" (table 1 (ref null struct))))
std::array<WasmEdge::Byte, 39> RexTableAbstractFromDWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x0a, 0x01, 0x01, 0x44, 0x01, 0x74, 0x01, 0x63,
    0x6b, 0x00, 0x01};

/// Binary Wasm module: imports from A.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "A" "t" (table 1 (ref null struct))))
std::array<WasmEdge::Byte, 39> RexTableAbstractFromAWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x0a, 0x01, 0x01, 0x41, 0x01, 0x74, 0x01, 0x63,
    0x6b, 0x00, 0x01};

/// Binary Wasm module: imports from B.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "B" "e" (tag (type $fo))))
std::array<WasmEdge::Byte, 37> RexTagOtherFromBWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x08, 0x01, 0x01, 0x42, 0x01, 0x65, 0x04, 0x00,
    0x03};

/// Binary Wasm module: imports from D.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "D" "e" (tag (type $fo))))
std::array<WasmEdge::Byte, 37> RexTagOtherFromDWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x08, 0x01, 0x01, 0x44, 0x01, 0x65, 0x04, 0x00,
    0x03};

/// Binary Wasm module: imports from A.
///
/// (module
///   (type $s (struct (field i32)))
///   (type $ft (func (param i32)))
///   (type $o (struct (field i64)))
///   (type $fo (func (param i64)))
///   (import "A" "e" (tag (type $fo))))
std::array<WasmEdge::Byte, 37> RexTagOtherFromAWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x11, 0x04, 0x5f,
    0x01, 0x7f, 0x00, 0x60, 0x01, 0x7f, 0x00, 0x5f, 0x01, 0x7e, 0x00, 0x60,
    0x01, 0x7e, 0x00, 0x02, 0x08, 0x01, 0x01, 0x41, 0x01, 0x65, 0x04, 0x00,
    0x03};

/// Binary Wasm module: checks the two host functions in its table.
///
/// (module
///   (type $f (func))
///   (type $g (sub (func)))
///   (type $r (func (result i32)))
///   (type $f2 (sub final (func)))
///   (type $fi (func (param i32) (result i32)))
///   (type $gi (sub (func (param i32) (result i32))))
///   (rec (type $fr (func)) (type (struct)))
///   (table (export "tab") 2 funcref)
///   (func (export "call_f") (result i32)
///     (call_indirect (type $f) (i32.const 0)) (i32.const 1))
///   (func (export "call_g") (result i32)
///     (call_indirect (type $g) (i32.const 0)) (i32.const 1))
///   (func (export "call_f2") (result i32)
///     (call_indirect (type $f2) (i32.const 0)) (i32.const 1))
///   (func (export "call_fr") (result i32)
///     (call_indirect (type $fr) (i32.const 0)) (i32.const 1))
///   (func (export "call_fi") (result i32)
///     (call_indirect (type $fi) (i32.const 41) (i32.const 1)))
///   (func (export "call_gi") (result i32)
///     (call_indirect (type $gi) (i32.const 41) (i32.const 1)))
///   (func (export "call_slot1_as_f") (result i32)
///     (call_indirect (type $f) (i32.const 1)) (i32.const 1))
///   (func (export "test_f") (result i32)
///     (ref.test (ref $f) (table.get 0 (i32.const 0))))
///   (func (export "test_g") (result i32)
///     (ref.test (ref $g) (table.get 0 (i32.const 0))))
///   (func (export "test_f2") (result i32)
///     (ref.test (ref $f2) (table.get 0 (i32.const 0))))
///   (func (export "test_func") (result i32)
///     (ref.test (ref func) (table.get 0 (i32.const 0))))
///   (func (export "test_null_f") (result i32)
///     (ref.test (ref null $f) (table.get 0 (i32.const 0))))
///   (func (export "test_fi") (result i32)
///     (ref.test (ref $fi) (table.get 0 (i32.const 1))))
///   (func (export "test_gi") (result i32)
///     (ref.test (ref $gi) (table.get 0 (i32.const 1))))
///   (func (export "cast_f") (result i32)
///     (drop (ref.cast (ref $f) (table.get 0 (i32.const 0)))) (i32.const 1))
///   (func (export "cast_g") (result i32)
///     (drop (ref.cast (ref $g) (table.get 0 (i32.const 0)))) (i32.const 1))
///   (func (export "brcast_f") (result i32)
///     (block $l (result (ref $f)) (br_on_cast $l funcref (ref $f) (table.get 0 (i32.const 0))) (return (i32.const 0))) (drop) (i32.const 1))
///   (func (export "brcast_g") (result i32)
///     (block $l (result (ref $g)) (br_on_cast $l funcref (ref $g) (table.get 0 (i32.const 0))) (return (i32.const 0))) (drop) (i32.const 1))
///   (func (export "brcastfail_f") (result i32)
///     (block $l (result funcref) (br_on_cast_fail $l funcref (ref $f) (table.get 0 (i32.const 0))) (return (i32.const 0))) (drop) (i32.const 1))
///   (func (export "brcastfail_g") (result i32)
///     (block $l (result funcref) (br_on_cast_fail $l funcref (ref $g) (table.get 0 (i32.const 0))) (return (i32.const 0))) (drop) (i32.const 1)))
std::array<WasmEdge::Byte, 570> HostFuncCastsWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x25, 0x07, 0x60,
    0x00, 0x00, 0x50, 0x00, 0x60, 0x00, 0x00, 0x60, 0x00, 0x01, 0x7f, 0x4f,
    0x00, 0x60, 0x00, 0x00, 0x60, 0x01, 0x7f, 0x01, 0x7f, 0x50, 0x00, 0x60,
    0x01, 0x7f, 0x01, 0x7f, 0x4e, 0x02, 0x60, 0x00, 0x00, 0x5f, 0x00, 0x03,
    0x15, 0x14, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02,
    0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x04, 0x04,
    0x01, 0x70, 0x00, 0x02, 0x07, 0xe3, 0x01, 0x15, 0x03, 0x74, 0x61, 0x62,
    0x01, 0x00, 0x06, 0x63, 0x61, 0x6c, 0x6c, 0x5f, 0x66, 0x00, 0x00, 0x06,
    0x63, 0x61, 0x6c, 0x6c, 0x5f, 0x67, 0x00, 0x01, 0x07, 0x63, 0x61, 0x6c,
    0x6c, 0x5f, 0x66, 0x32, 0x00, 0x02, 0x07, 0x63, 0x61, 0x6c, 0x6c, 0x5f,
    0x66, 0x72, 0x00, 0x03, 0x07, 0x63, 0x61, 0x6c, 0x6c, 0x5f, 0x66, 0x69,
    0x00, 0x04, 0x07, 0x63, 0x61, 0x6c, 0x6c, 0x5f, 0x67, 0x69, 0x00, 0x05,
    0x0f, 0x63, 0x61, 0x6c, 0x6c, 0x5f, 0x73, 0x6c, 0x6f, 0x74, 0x31, 0x5f,
    0x61, 0x73, 0x5f, 0x66, 0x00, 0x06, 0x06, 0x74, 0x65, 0x73, 0x74, 0x5f,
    0x66, 0x00, 0x07, 0x06, 0x74, 0x65, 0x73, 0x74, 0x5f, 0x67, 0x00, 0x08,
    0x07, 0x74, 0x65, 0x73, 0x74, 0x5f, 0x66, 0x32, 0x00, 0x09, 0x09, 0x74,
    0x65, 0x73, 0x74, 0x5f, 0x66, 0x75, 0x6e, 0x63, 0x00, 0x0a, 0x0b, 0x74,
    0x65, 0x73, 0x74, 0x5f, 0x6e, 0x75, 0x6c, 0x6c, 0x5f, 0x66, 0x00, 0x0b,
    0x07, 0x74, 0x65, 0x73, 0x74, 0x5f, 0x66, 0x69, 0x00, 0x0c, 0x07, 0x74,
    0x65, 0x73, 0x74, 0x5f, 0x67, 0x69, 0x00, 0x0d, 0x06, 0x63, 0x61, 0x73,
    0x74, 0x5f, 0x66, 0x00, 0x0e, 0x06, 0x63, 0x61, 0x73, 0x74, 0x5f, 0x67,
    0x00, 0x0f, 0x08, 0x62, 0x72, 0x63, 0x61, 0x73, 0x74, 0x5f, 0x66, 0x00,
    0x10, 0x08, 0x62, 0x72, 0x63, 0x61, 0x73, 0x74, 0x5f, 0x67, 0x00, 0x11,
    0x0c, 0x62, 0x72, 0x63, 0x61, 0x73, 0x74, 0x66, 0x61, 0x69, 0x6c, 0x5f,
    0x66, 0x00, 0x12, 0x0c, 0x62, 0x72, 0x63, 0x61, 0x73, 0x74, 0x66, 0x61,
    0x69, 0x6c, 0x5f, 0x67, 0x00, 0x13, 0x0a, 0x85, 0x02, 0x14, 0x09, 0x00,
    0x41, 0x00, 0x11, 0x00, 0x00, 0x41, 0x01, 0x0b, 0x09, 0x00, 0x41, 0x00,
    0x11, 0x01, 0x00, 0x41, 0x01, 0x0b, 0x09, 0x00, 0x41, 0x00, 0x11, 0x03,
    0x00, 0x41, 0x01, 0x0b, 0x09, 0x00, 0x41, 0x00, 0x11, 0x06, 0x00, 0x41,
    0x01, 0x0b, 0x09, 0x00, 0x41, 0x29, 0x41, 0x01, 0x11, 0x04, 0x00, 0x0b,
    0x09, 0x00, 0x41, 0x29, 0x41, 0x01, 0x11, 0x05, 0x00, 0x0b, 0x09, 0x00,
    0x41, 0x01, 0x11, 0x00, 0x00, 0x41, 0x01, 0x0b, 0x09, 0x00, 0x41, 0x00,
    0x25, 0x00, 0xfb, 0x14, 0x00, 0x0b, 0x09, 0x00, 0x41, 0x00, 0x25, 0x00,
    0xfb, 0x14, 0x01, 0x0b, 0x09, 0x00, 0x41, 0x00, 0x25, 0x00, 0xfb, 0x14,
    0x03, 0x0b, 0x09, 0x00, 0x41, 0x00, 0x25, 0x00, 0xfb, 0x14, 0x70, 0x0b,
    0x09, 0x00, 0x41, 0x00, 0x25, 0x00, 0xfb, 0x15, 0x00, 0x0b, 0x09, 0x00,
    0x41, 0x01, 0x25, 0x00, 0xfb, 0x14, 0x04, 0x0b, 0x09, 0x00, 0x41, 0x01,
    0x25, 0x00, 0xfb, 0x14, 0x05, 0x0b, 0x0c, 0x00, 0x41, 0x00, 0x25, 0x00,
    0xfb, 0x16, 0x00, 0x1a, 0x41, 0x01, 0x0b, 0x0c, 0x00, 0x41, 0x00, 0x25,
    0x00, 0xfb, 0x16, 0x01, 0x1a, 0x41, 0x01, 0x0b, 0x17, 0x00, 0x02, 0x64,
    0x00, 0x41, 0x00, 0x25, 0x00, 0xfb, 0x18, 0x01, 0x00, 0x70, 0x00, 0x1a,
    0x41, 0x00, 0x0f, 0x0b, 0x1a, 0x41, 0x01, 0x0b, 0x17, 0x00, 0x02, 0x64,
    0x01, 0x41, 0x00, 0x25, 0x00, 0xfb, 0x18, 0x01, 0x00, 0x70, 0x01, 0x1a,
    0x41, 0x00, 0x0f, 0x0b, 0x1a, 0x41, 0x01, 0x0b, 0x16, 0x00, 0x02, 0x70,
    0x41, 0x00, 0x25, 0x00, 0xfb, 0x19, 0x01, 0x00, 0x70, 0x00, 0x1a, 0x41,
    0x00, 0x0f, 0x0b, 0x1a, 0x41, 0x01, 0x0b, 0x16, 0x00, 0x02, 0x70, 0x41,
    0x00, 0x25, 0x00, 0xfb, 0x19, 0x01, 0x00, 0x70, 0x01, 0x1a, 0x41, 0x00,
    0x0f, 0x0b, 0x1a, 0x41, 0x01, 0x0b};

/// Binary Wasm module: exports a final and a non-final function type's functions.
///
/// (module
///   (type (struct))
///   (type $t (func (param i32) (result i32)))
///   (type $u (sub (func (param i32) (result i32))))
///   (func (export "f") (type $t) (i32.add (local.get 0) (i32.const 1)))
///   (func (export "u") (type $u) (i32.add (local.get 0) (i32.const 1))))
std::array<WasmEdge::Byte, 60> ModFuncExportWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x0f, 0x03, 0x5f,
    0x00, 0x60, 0x01, 0x7f, 0x01, 0x7f, 0x50, 0x00, 0x60, 0x01, 0x7f, 0x01,
    0x7f, 0x03, 0x03, 0x02, 0x01, 0x02, 0x07, 0x09, 0x02, 0x01, 0x66, 0x00,
    0x00, 0x01, 0x75, 0x00, 0x01, 0x0a, 0x11, 0x02, 0x07, 0x00, 0x20, 0x00,
    0x41, 0x01, 0x6a, 0x0b, 0x07, 0x00, 0x20, 0x00, 0x41, 0x01, 0x6a, 0x0b};

/// Binary Wasm module: checks the module functions in its table.
///
/// (module
///   (type $t (func (param i32) (result i32)))
///   (type $u (sub (func (param i32) (result i32))))
///   (type $r (func (result i32)))
///   (type $v (sub $u (func (param i32) (result i32))))
///   (type $w (func (param i64) (result i32)))
///   (table (export "tab") 3 funcref)
///   (func (export "g") (type $v) (i32.add (local.get 0) (i32.const 2)))
///   (func (export "test0_t") (result i32)
///     (ref.test (ref $t) (table.get 0 (i32.const 0))))
///   (func (export "test0_u") (result i32)
///     (ref.test (ref $u) (table.get 0 (i32.const 0))))
///   (func (export "test0_func") (result i32)
///     (ref.test (ref func) (table.get 0 (i32.const 0))))
///   (func (export "test0_w") (result i32)
///     (ref.test (ref $w) (table.get 0 (i32.const 0))))
///   (func (export "test1_u") (result i32)
///     (ref.test (ref $u) (table.get 0 (i32.const 1))))
///   (func (export "test1_t") (result i32)
///     (ref.test (ref $t) (table.get 0 (i32.const 1))))
///   (func (export "test2_u") (result i32)
///     (ref.test (ref $u) (table.get 0 (i32.const 2))))
///   (func (export "test2_v") (result i32)
///     (ref.test (ref $v) (table.get 0 (i32.const 2))))
///   (func (export "test2_t") (result i32)
///     (ref.test (ref $t) (table.get 0 (i32.const 2))))
///   (func (export "cast0_t") (result i32)
///     (drop (ref.cast (ref $t) (table.get 0 (i32.const 0)))) (i32.const 1))
///   (func (export "cast1_t") (result i32)
///     (drop (ref.cast (ref $t) (table.get 0 (i32.const 1)))) (i32.const 1))
///   (func (export "cast2_u") (result i32)
///     (drop (ref.cast (ref $u) (table.get 0 (i32.const 2)))) (i32.const 1))
///   (func (export "brcast0_t") (result i32)
///     (block $l (result (ref $t)) (br_on_cast $l funcref (ref $t) (table.get 0 (i32.const 0))) (return (i32.const 0))) (drop) (i32.const 1))
///   (func (export "brcastfail2_t") (result i32)
///     (block $l (result funcref) (br_on_cast_fail $l funcref (ref $t) (table.get 0 (i32.const 2))) (return (i32.const 0))) (drop) (i32.const 1))
///   (func (export "call0_t") (result i32)
///     (call_indirect (type $t) (i32.const 41) (i32.const 0)))
///   (func (export "call2_u") (result i32)
///     (call_indirect (type $u) (i32.const 40) (i32.const 2)))
///   (func (export "call1_t") (result i32)
///     (call_indirect (type $t) (i32.const 41) (i32.const 1))))
std::array<WasmEdge::Byte, 480> ModFuncTableWasm{
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x1e, 0x05, 0x60,
    0x01, 0x7f, 0x01, 0x7f, 0x50, 0x00, 0x60, 0x01, 0x7f, 0x01, 0x7f, 0x60,
    0x00, 0x01, 0x7f, 0x50, 0x01, 0x01, 0x60, 0x01, 0x7f, 0x01, 0x7f, 0x60,
    0x01, 0x7e, 0x01, 0x7f, 0x03, 0x13, 0x12, 0x03, 0x02, 0x02, 0x02, 0x02,
    0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02,
    0x02, 0x04, 0x04, 0x01, 0x70, 0x00, 0x03, 0x07, 0xc0, 0x01, 0x13, 0x03,
    0x74, 0x61, 0x62, 0x01, 0x00, 0x01, 0x67, 0x00, 0x00, 0x07, 0x74, 0x65,
    0x73, 0x74, 0x30, 0x5f, 0x74, 0x00, 0x01, 0x07, 0x74, 0x65, 0x73, 0x74,
    0x30, 0x5f, 0x75, 0x00, 0x02, 0x0a, 0x74, 0x65, 0x73, 0x74, 0x30, 0x5f,
    0x66, 0x75, 0x6e, 0x63, 0x00, 0x03, 0x07, 0x74, 0x65, 0x73, 0x74, 0x30,
    0x5f, 0x77, 0x00, 0x04, 0x07, 0x74, 0x65, 0x73, 0x74, 0x31, 0x5f, 0x75,
    0x00, 0x05, 0x07, 0x74, 0x65, 0x73, 0x74, 0x31, 0x5f, 0x74, 0x00, 0x06,
    0x07, 0x74, 0x65, 0x73, 0x74, 0x32, 0x5f, 0x75, 0x00, 0x07, 0x07, 0x74,
    0x65, 0x73, 0x74, 0x32, 0x5f, 0x76, 0x00, 0x08, 0x07, 0x74, 0x65, 0x73,
    0x74, 0x32, 0x5f, 0x74, 0x00, 0x09, 0x07, 0x63, 0x61, 0x73, 0x74, 0x30,
    0x5f, 0x74, 0x00, 0x0a, 0x07, 0x63, 0x61, 0x73, 0x74, 0x31, 0x5f, 0x74,
    0x00, 0x0b, 0x07, 0x63, 0x61, 0x73, 0x74, 0x32, 0x5f, 0x75, 0x00, 0x0c,
    0x09, 0x62, 0x72, 0x63, 0x61, 0x73, 0x74, 0x30, 0x5f, 0x74, 0x00, 0x0d,
    0x0d, 0x62, 0x72, 0x63, 0x61, 0x73, 0x74, 0x66, 0x61, 0x69, 0x6c, 0x32,
    0x5f, 0x74, 0x00, 0x0e, 0x07, 0x63, 0x61, 0x6c, 0x6c, 0x30, 0x5f, 0x74,
    0x00, 0x0f, 0x07, 0x63, 0x61, 0x6c, 0x6c, 0x32, 0x5f, 0x75, 0x00, 0x10,
    0x07, 0x63, 0x61, 0x6c, 0x6c, 0x31, 0x5f, 0x74, 0x00, 0x11, 0x0a, 0xd7,
    0x01, 0x12, 0x07, 0x00, 0x20, 0x00, 0x41, 0x02, 0x6a, 0x0b, 0x09, 0x00,
    0x41, 0x00, 0x25, 0x00, 0xfb, 0x14, 0x00, 0x0b, 0x09, 0x00, 0x41, 0x00,
    0x25, 0x00, 0xfb, 0x14, 0x01, 0x0b, 0x09, 0x00, 0x41, 0x00, 0x25, 0x00,
    0xfb, 0x14, 0x70, 0x0b, 0x09, 0x00, 0x41, 0x00, 0x25, 0x00, 0xfb, 0x14,
    0x04, 0x0b, 0x09, 0x00, 0x41, 0x01, 0x25, 0x00, 0xfb, 0x14, 0x01, 0x0b,
    0x09, 0x00, 0x41, 0x01, 0x25, 0x00, 0xfb, 0x14, 0x00, 0x0b, 0x09, 0x00,
    0x41, 0x02, 0x25, 0x00, 0xfb, 0x14, 0x01, 0x0b, 0x09, 0x00, 0x41, 0x02,
    0x25, 0x00, 0xfb, 0x14, 0x03, 0x0b, 0x09, 0x00, 0x41, 0x02, 0x25, 0x00,
    0xfb, 0x14, 0x00, 0x0b, 0x0c, 0x00, 0x41, 0x00, 0x25, 0x00, 0xfb, 0x16,
    0x00, 0x1a, 0x41, 0x01, 0x0b, 0x0c, 0x00, 0x41, 0x01, 0x25, 0x00, 0xfb,
    0x16, 0x00, 0x1a, 0x41, 0x01, 0x0b, 0x0c, 0x00, 0x41, 0x02, 0x25, 0x00,
    0xfb, 0x16, 0x01, 0x1a, 0x41, 0x01, 0x0b, 0x17, 0x00, 0x02, 0x64, 0x00,
    0x41, 0x00, 0x25, 0x00, 0xfb, 0x18, 0x01, 0x00, 0x70, 0x00, 0x1a, 0x41,
    0x00, 0x0f, 0x0b, 0x1a, 0x41, 0x01, 0x0b, 0x16, 0x00, 0x02, 0x70, 0x41,
    0x02, 0x25, 0x00, 0xfb, 0x19, 0x01, 0x00, 0x70, 0x00, 0x1a, 0x41, 0x00,
    0x0f, 0x0b, 0x1a, 0x41, 0x01, 0x0b, 0x09, 0x00, 0x41, 0x29, 0x41, 0x00,
    0x11, 0x00, 0x00, 0x0b, 0x09, 0x00, 0x41, 0x28, 0x41, 0x02, 0x11, 0x01,
    0x00, 0x0b, 0x09, 0x00, 0x41, 0x29, 0x41, 0x01, 0x11, 0x00, 0x00, 0x0b};

// clang-format on

/// The i32 a function returns, or the error code it stops with.
using Outcome = std::variant<uint32_t, ErrCode::Value>;

std::string describe(const Outcome &O) {
  if (std::holds_alternative<uint32_t>(O)) {
    return "returns " + std::to_string(std::get<uint32_t>(O));
  }
  return "fails with error 0x" +
         fmt::format("{:04x}", static_cast<uint32_t>(std::get<ErrCode::Value>(O)));
}

Outcome toOutcome(
    const Expect<std::vector<std::pair<ValVariant, ValType>>> &Res) {
  if (!Res) {
    return Res.error().getEnum();
  }
  if (Res->size() != 1) {
    return ErrCode::Value::FuncSigMismatch;
  }
  return Res->at(0).first.get<uint32_t>();
}

/// Links an importer against one registered exporter named "M".
Expect<void> linkWith(Span<const Byte> Exporter, Span<const Byte> Importer) {
  Configure Conf;
  VM::VM VM(Conf);
  EXPECTED_TRY(VM.registerModule("M", Exporter));
  EXPECTED_TRY(VM.loadWasm(Importer));
  EXPECTED_TRY(VM.validate());
  return VM.instantiate();
}

/// Links an importer against A, B (which forwards A) and D (which forwards B).
Expect<void> linkWithForwarders(Span<const Byte> Importer) {
  Configure Conf;
  VM::VM VM(Conf);
  EXPECTED_TRY(VM.registerModule("A", RexDefineWasm));
  EXPECTED_TRY(VM.registerModule("B", RexForwardWasm));
  EXPECTED_TRY(VM.registerModule("D", RexForwardTwiceWasm));
  EXPECTED_TRY(VM.loadWasm(Importer));
  EXPECTED_TRY(VM.validate());
  return VM.instantiate();
}
const std::map<std::string, Outcome, std::less<>> HostExpect{
    {"call_f", 1U},
    {"call_g", ErrCode::Value::IndirectCallTypeMismatch},
    {"call_f2", 1U},
    {"call_fr", ErrCode::Value::IndirectCallTypeMismatch},
    {"call_fi", 42U},
    {"call_gi", ErrCode::Value::IndirectCallTypeMismatch},
    {"call_slot1_as_f", ErrCode::Value::IndirectCallTypeMismatch},
    {"test_f", 1U},
    {"test_g", 0U},
    {"test_f2", 1U},
    {"test_func", 1U},
    {"test_null_f", 1U},
    {"test_fi", 1U},
    {"test_gi", 0U},
    {"cast_f", 1U},
    {"cast_g", ErrCode::Value::CastFailed},
    {"brcast_f", 1U},
    {"brcast_g", 0U},
    {"brcastfail_f", 0U},
    {"brcastfail_g", 1U},
};

const std::map<std::string, Outcome, std::less<>> ModExpect{
    {"test0_t", 1U},
    {"test0_u", 0U},
    {"test0_func", 1U},
    {"test0_w", 0U},
    {"test1_u", 1U},
    {"test1_t", 0U},
    {"test2_u", 1U},
    {"test2_v", 1U},
    {"test2_t", 0U},
    {"cast0_t", 1U},
    {"cast1_t", ErrCode::Value::CastFailed},
    {"cast2_u", 1U},
    {"brcast0_t", 1U},
    {"brcastfail2_t", 1U},
    {"call0_t", 42U},
    {"call2_u", 42U},
    {"call1_t", ErrCode::Value::IndirectCallTypeMismatch},
};

/// A tag import declaring a strict super type of the exported tag's type fails
/// to link with IncompatibleImportType, and one declaring an equivalent type in
/// another module links.
TEST(SubtypeMatch, TagImportMatchesBothWays) {
  // --- Part 1: the import declares the super type (must not link) ---
  {
    Configure Conf;
    VM::VM VM(Conf);
    ASSERT_TRUE(VM.registerModule("M", TagSubTypeExportWasm));
    ASSERT_TRUE(VM.loadWasm(TagSuperTypeImportWasm));
    ASSERT_TRUE(VM.validate());
    auto Res = VM.instantiate();
    ASSERT_FALSE(Res);
    EXPECT_EQ(Res.error(), ErrCode::Value::IncompatibleImportType);
  }

  // --- Part 2: the import declares an equivalent type (links) ---
  {
    Configure Conf;
    VM::VM VM(Conf);
    ASSERT_TRUE(VM.registerModule("M", TagSubTypeExportWasm));
    ASSERT_TRUE(VM.loadWasm(TagSubTypeImportWasm));
    ASSERT_TRUE(VM.validate());
    EXPECT_TRUE(VM.instantiate());
  }
}

/// A module importing a global, a table or a tag that B took from A and
/// exports again, and declaring A's types for it, validates and instantiates.
/// The loop runs one such importer for each of the three.
TEST(SubtypeMatch, ReExportedImportsMatch) {
  for (auto Wasm : {Span<const Byte>(ReExportGlobalImportWasm),
                    Span<const Byte>(ReExportTableImportWasm),
                    Span<const Byte>(ReExportTagImportWasm)}) {
    Configure Conf;
    VM::VM VM(Conf);
    ASSERT_TRUE(VM.registerModule("A", ReExportDefineWasm));
    ASSERT_TRUE(VM.registerModule("B", ReExportForwardWasm));
    ASSERT_TRUE(VM.loadWasm(Wasm));
    ASSERT_TRUE(VM.validate());
    EXPECT_TRUE(VM.instantiate());
  }
}

/// A host function () -> () in a table: call_indirect through the final `$f`
/// calls it and ref.test (ref $f) returns 1, while call_indirect through the
/// non-final `$g` traps and ref.test (ref $g) returns 0.
TEST(SubtypeMatch, HostFuncMatchesItsDefinedType) {
  Runtime::Instance::FunctionInstance HostFunc(std::make_unique<Nop>());
  Configure Conf;
  VM::VM VM(Conf);
  ASSERT_TRUE(VM.loadWasm(HostFuncTableWasm));
  ASSERT_TRUE(VM.validate());
  ASSERT_TRUE(VM.instantiate());
  auto *TabInst = VM.getActiveModule()->findTableExports("tab");
  ASSERT_NE(TabInst, nullptr);
  ASSERT_TRUE(TabInst->setRefAddr(0, RefVariant(&HostFunc)));

  EXPECT_TRUE(VM.execute("call_f"));
  auto CallRes = VM.execute("call_g");
  ASSERT_FALSE(CallRes);
  EXPECT_EQ(CallRes.error(), ErrCode::Value::IndirectCallTypeMismatch);

  auto TestRes = VM.execute("test_f");
  ASSERT_TRUE(TestRes);
  ASSERT_EQ(TestRes->size(), 1U);
  EXPECT_EQ(TestRes->at(0).first.get<uint32_t>(), 1U);
  TestRes = VM.execute("test_g");
  ASSERT_TRUE(TestRes);
  ASSERT_EQ(TestRes->size(), 1U);
  EXPECT_EQ(TestRes->at(0).first.get<uint32_t>(), 0U);
}


/// A tag import declaring a strict sub type of the exported tag's type fails
/// to link as well.
TEST(SubtypeMatch, TagImportRejectsStrictSubType) {
  auto Res = linkWith(TagSuperTypeExportWasm, TagSubTypeImportWasm);
  ASSERT_FALSE(Res) << "a tag import declaring a strict sub type linked";
  EXPECT_EQ(Res.error(), ErrCode::Value::IncompatibleImportType);
}

/// Globals, tables and tags that A exports and B, then D, export again link
/// when the importer declares A's types, through one forwarder or two,
/// including a const global imported with an abstract super type of its type.
TEST(SubtypeMatch, ReExportedImportsMatchEveryKind) {
  const std::vector<Span<const Byte>> Importers{
       Span<const Byte>(RexGlobalFromBWasm),
       Span<const Byte>(RexGlobalFromDWasm),
       Span<const Byte>(RexGlobalAbstractFromBWasm),
       Span<const Byte>(RexGlobalAbstractFromDWasm),
       Span<const Byte>(RexMutGlobalFromBWasm),
       Span<const Byte>(RexMutGlobalFromDWasm),
       Span<const Byte>(RexTableFromBWasm),
       Span<const Byte>(RexTableFromDWasm),
       Span<const Byte>(RexTagFromBWasm),
       Span<const Byte>(RexTagFromDWasm)};
  for (size_t I = 0; I < Importers.size(); I++) {
    auto Res = linkWithForwarders(Importers[I]);
    EXPECT_TRUE(Res) << "importer " << I << " did not link: error 0x"
                     << std::hex << (Res ? 0U : static_cast<uint32_t>(Res.error().getEnum()));
  }
}

/// An importer declaring another type, or a super type for a mutable global or
/// a table, fails to link with IncompatibleImportType, whether it imports from
/// A or from a forwarder.
TEST(SubtypeMatch, ReExportedImportsStillChecked) {
  const std::vector<Span<const Byte>> Importers{
       Span<const Byte>(RexGlobalOtherFromAWasm),
       Span<const Byte>(RexGlobalOtherFromBWasm),
       Span<const Byte>(RexGlobalOtherFromDWasm),
       Span<const Byte>(RexMutGlobalOtherFromAWasm),
       Span<const Byte>(RexMutGlobalOtherFromBWasm),
       Span<const Byte>(RexMutGlobalOtherFromDWasm),
       Span<const Byte>(RexMutGlobalAbstractFromAWasm),
       Span<const Byte>(RexMutGlobalAbstractFromBWasm),
       Span<const Byte>(RexMutGlobalAbstractFromDWasm),
       Span<const Byte>(RexTableOtherFromAWasm),
       Span<const Byte>(RexTableOtherFromBWasm),
       Span<const Byte>(RexTableOtherFromDWasm),
       Span<const Byte>(RexTableAbstractFromAWasm),
       Span<const Byte>(RexTableAbstractFromBWasm),
       Span<const Byte>(RexTableAbstractFromDWasm),
       Span<const Byte>(RexTagOtherFromAWasm),
       Span<const Byte>(RexTagOtherFromBWasm),
       Span<const Byte>(RexTagOtherFromDWasm)};
  for (size_t I = 0; I < Importers.size(); I++) {
    auto Res = linkWithForwarders(Importers[I]);
    ASSERT_FALSE(Res) << "importer " << I << " linked with a mismatched type";
    EXPECT_EQ(Res.error(), ErrCode::Value::IncompatibleImportType)
        << "importer " << I;
  }
}

/// Runs the exports named in Names under the interpreter, with Nop in slot 0
/// and AddOne in slot 1 of the table, and lists every outcome that differs
/// from HostExpect.
std::string runHostFuncs(const std::vector<std::string> &Names) {
  Runtime::Instance::FunctionInstance F0(std::make_unique<Nop>());
  Runtime::Instance::FunctionInstance F1(std::make_unique<AddOne>());
  Configure Conf;
  VM::VM VM(Conf);
  if (!VM.loadWasm(HostFuncCastsWasm) || !VM.validate() || !VM.instantiate()) {
    return "the module did not load, validate and instantiate";
  }
  auto *Tab = VM.getActiveModule()->findTableExports("tab");
  if (Tab == nullptr || !Tab->setRefAddr(0, RefVariant(&F0)) ||
      !Tab->setRefAddr(1, RefVariant(&F1))) {
    return "the host functions could not be put into the table";
  }
  std::string Wrong;
  for (const auto &Name : Names) {
    const auto &Exp = HostExpect.at(Name);
    const auto Got = toOutcome(VM.execute(Name));
    if (Got != Exp) {
      Wrong += Name + " " + describe(Got) + ", expected: " + describe(Exp) + "; ";
    }
  }
  return Wrong;
}

/// ref.test, ref.cast, br_on_cast and br_on_cast_fail on a host function in a
/// table: (ref func), (ref null $f) and (ref $f) succeed, (ref $g) doesn't.
TEST(SubtypeMatch, HostFuncCastsFollowItsDefinedType) {
  if (const auto Wrong = runHostFuncs({"test_func", "test_null_f", "cast_f", "cast_g", "brcast_f", "brcast_g", "brcastfail_f", "brcastfail_g"}); !Wrong.empty()) {
    ADD_FAILURE() << Wrong;
  }
}

/// call_indirect and ref.test on host functions go through (sub final (func))
/// and an exact i32 -> i32 type, and fail through a non-final type with the same
/// signature, a (func) inside a rec group of two, or another signature.
TEST(SubtypeMatch, HostFuncTypeIdentity) {
  if (const auto Wrong = runHostFuncs({"call_f2", "call_fr", "call_fi", "call_gi", "call_slot1_as_f", "test_f2", "test_fi", "test_gi"}); !Wrong.empty()) {
    ADD_FAILURE() << Wrong;
  }
}

#ifdef WASMEDGE_USE_LLVM
/// Parses, validates and compiles a module with the LLVM JIT.
std::shared_ptr<AST::Module> compileToJIT(const Configure &Conf,
                                          Span<const Byte> Bytes) {
  Loader::Loader LoaderEngine(Conf, &Executor::Executor::Intrinsics);
  Validator::Validator ValidatorEngine(Conf);
  auto ModOrErr = LoaderEngine.parseModule(Bytes);
  if (!ModOrErr) {
    return nullptr;
  }
  std::shared_ptr<AST::Module> Mod{std::move(*ModOrErr)};
  if (!ValidatorEngine.validate(*Mod)) {
    return nullptr;
  }
  LLVM::Compiler Compiler(Conf);
  if (!Compiler.checkConfigure()) {
    return nullptr;
  }
  auto Data = Compiler.compile(*Mod);
  if (!Data) {
    return nullptr;
  }
  LLVM::JIT JIT(Conf);
  auto Exec = JIT.load(std::move(*Data));
  if (!Exec) {
    return nullptr;
  }
  if (!LoaderEngine.loadExecutable(*Mod, std::move(*Exec))) {
    return nullptr;
  }
  return Mod;
}
#endif

/// Compiled code gives every host function check the same outcome as the
/// interpreter.
TEST(SubtypeMatch, CompiledCodeMatchesHostFuncs) {
#ifndef WASMEDGE_USE_LLVM
  FAIL() << "this build has no LLVM compiler";
#else
  Configure Conf;
  auto Mod = compileToJIT(Conf, HostFuncCastsWasm);
  ASSERT_NE(Mod, nullptr) << "the module did not compile";
  Runtime::Instance::FunctionInstance F0(std::make_unique<Nop>());
  Runtime::Instance::FunctionInstance F1(std::make_unique<AddOne>());
  Executor::Executor ExecEngine(Conf);
  Runtime::StoreManager Store;
  auto InstOrErr = ExecEngine.instantiateModule(Store, *Mod);
  ASSERT_TRUE(InstOrErr);
  auto Inst = std::move(*InstOrErr);
  auto *Tab = Inst->findTableExports("tab");
  ASSERT_NE(Tab, nullptr);
  ASSERT_TRUE(Tab->setRefAddr(0, RefVariant(&F0)));
  ASSERT_TRUE(Tab->setRefAddr(1, RefVariant(&F1)));
  std::string Wrong;
  for (const auto &[Name, Exp] : HostExpect) {
    const auto *Func = Inst->findFuncExports(Name);
    ASSERT_NE(Func, nullptr) << Name;
    ASSERT_TRUE(Func->isCompiledFunction()) << Name << " is not compiled";
    const auto Got = toOutcome(ExecEngine.invoke(Func, {}, {}));
    if (Got != Exp) {
      Wrong += Name + " " + describe(Got) + ", expected: " + describe(Exp) + "; ";
    }
  }
  if (!Wrong.empty()) {
    ADD_FAILURE() << "compiled: " << Wrong;
  }
#endif
}

/// Puts M's "f" (type $t) into slot 0, M's "u" (type $u) into slot 1 and N's
/// own "g" (type $v, a sub type of $u) into slot 2 of N's table, from the
/// embedder side, runs each export of N and lists every outcome that differs
/// from ModExpect.
template <typename RunT>
std::string checkModuleFuncs(const Runtime::Instance::ModuleInstance &M,
                             const Runtime::Instance::ModuleInstance &N,
                             RunT &&Run) {
  auto *Tab = N.findTableExports("tab");
  const auto *F = M.findFuncExports("f");
  const auto *U = M.findFuncExports("u");
  const auto *G = N.findFuncExports("g");
  if (Tab == nullptr || F == nullptr || U == nullptr || G == nullptr ||
      !Tab->setRefAddr(0, RefVariant(F)) || !Tab->setRefAddr(1, RefVariant(U)) ||
      !Tab->setRefAddr(2, RefVariant(G))) {
    return "the module functions could not be put into the table";
  }
  std::string Wrong;
  for (const auto &[Name, Exp] : ModExpect) {
    const auto Got = Run(N, Name);
    if (Got != Exp) {
      Wrong += Name + " " + describe(Got) + ", expected: " + describe(Exp) + "; ";
    }
  }
  return Wrong;
}

/// ref.test, ref.cast, br_on_cast and br_on_cast_fail on module functions the
/// embedder put into a table: each is its declared type and that type's super
/// types, and no other type; call_indirect is checked alongside.
TEST(SubtypeMatch, ModuleFuncRefsFollowTheirDefinedType) {
  Configure Conf;
  VM::VM VM(Conf);
  ASSERT_TRUE(VM.registerModule("M", ModFuncExportWasm));
  ASSERT_TRUE(VM.loadWasm(ModFuncTableWasm));
  ASSERT_TRUE(VM.validate());
  ASSERT_TRUE(VM.instantiate());
  const auto *M = VM.getStoreManager().findModule("M");
  ASSERT_NE(M, nullptr);
  const auto Wrong = checkModuleFuncs(
      *M, *VM.getActiveModule(),
      [&](const Runtime::Instance::ModuleInstance &, const std::string &Name) {
        return toOutcome(VM.execute(Name));
      });
  if (!Wrong.empty()) {
    ADD_FAILURE() << Wrong;
  }
}

/// The same module function checks give the same outcomes in compiled code.
TEST(SubtypeMatch, CompiledCodeMatchesModuleFuncRefs) {
#ifndef WASMEDGE_USE_LLVM
  FAIL() << "this build has no LLVM compiler";
#else
  Configure Conf;
  auto MMod = compileToJIT(Conf, ModFuncExportWasm);
  ASSERT_NE(MMod, nullptr) << "M did not compile";
  auto NMod = compileToJIT(Conf, ModFuncTableWasm);
  ASSERT_NE(NMod, nullptr) << "N did not compile";
  Executor::Executor ExecEngine(Conf);
  Runtime::StoreManager Store;
  auto MInstOrErr = ExecEngine.registerModule(Store, *MMod, "M");
  ASSERT_TRUE(MInstOrErr);
  auto MInst = std::move(*MInstOrErr);
  auto NInstOrErr = ExecEngine.instantiateModule(Store, *NMod);
  ASSERT_TRUE(NInstOrErr);
  auto NInst = std::move(*NInstOrErr);
  bool AllCompiled = true;
  const auto Wrong = checkModuleFuncs(
      *MInst, *NInst,
      [&](const Runtime::Instance::ModuleInstance &N, const std::string &Name) {
        const auto *Func = N.findFuncExports(Name);
        if (Func == nullptr || !Func->isCompiledFunction()) {
          AllCompiled = false;
          return Outcome(ErrCode::Value::Terminated);
        }
        return toOutcome(ExecEngine.invoke(Func, {}, {}));
      });
  ASSERT_TRUE(AllCompiled) << "an export of N is not compiled";
  if (!Wrong.empty()) {
    ADD_FAILURE() << "compiled: " << Wrong;
  }
#endif
}

/// Appends an unsigned LEB128 number.
void appendU32(std::vector<Byte> &Out, uint32_t V) {
  do {
    Byte B = V & 0x7FU;
    V >>= 7;
    Out.push_back(V ? (B | 0x80U) : B);
  } while (V);
}

/// Appends a type index as a heap type, a signed LEB128 number.
void appendHeapIdx(std::vector<Byte> &Out, uint32_t V) {
  while (V >= 0x40U) {
    Out.push_back(static_cast<Byte>((V & 0x7FU) | 0x80U));
    V >>= 7;
  }
  Out.push_back(static_cast<Byte>(V));
}

/// Appends a section with its id and size.
void appendSection(std::vector<Byte> &Out, Byte Id,
                   const std::vector<Byte> &Payload) {
  Out.push_back(Id);
  appendU32(Out, static_cast<uint32_t>(Payload.size()));
  Out.insert(Out.end(), Payload.begin(), Payload.end());
}

/// Appends the struct chain c_0 .. c_Depth at type index Base:
///   (type $c_0 (struct (field i32)))     when Bottom is true, else (struct)
///   (type $c_i (struct (field (ref null $c_(i-1))) (field (ref null $c_(i-1)))))
/// Every struct refers to the one below it twice.
void appendChain(std::vector<Byte> &Types, uint32_t Base, uint32_t Depth,
                 bool Bottom) {
  if (Bottom) {
    Types.insert(Types.end(), {0x5F, 0x01, 0x7F, 0x00});
  } else {
    Types.insert(Types.end(), {0x5F, 0x00});
  }
  for (uint32_t I = 1; I <= Depth; I++) {
    Types.insert(Types.end(), {0x5F, 0x02});
    for (int F = 0; F < 2; F++) {
      Types.push_back(0x63);
      appendHeapIdx(Types, Base + I - 1);
      Types.push_back(0x00);
    }
  }
}

/// Exporter: one chain and (func (export "f") (param (ref null $c_Depth))).
/// Importer: its own chain and (import "M" "f" (func (param (ref null $c_Depth)))).
std::vector<Byte> deepChainModule(uint32_t Depth, bool Exporter, bool Bottom) {
  std::vector<Byte> Types;
  appendU32(Types, Depth + 2);
  appendChain(Types, 0, Depth, Bottom);
  Types.insert(Types.end(), {0x60, 0x01, 0x63});
  appendHeapIdx(Types, Depth);
  Types.push_back(0x00);
  std::vector<Byte> Out{0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00};
  appendSection(Out, 0x01, Types);
  if (Exporter) {
    std::vector<Byte> Funcs{0x01};
    appendU32(Funcs, Depth + 1);
    appendSection(Out, 0x03, Funcs);
    appendSection(Out, 0x07, {0x01, 0x01, 'f', 0x00, 0x00});
    appendSection(Out, 0x0A, {0x01, 0x02, 0x00, 0x0B});
  } else {
    std::vector<Byte> Imports{0x01, 0x01, 'M', 0x01, 'f', 0x00};
    appendU32(Imports, Depth + 1);
    appendSection(Out, 0x02, Imports);
  }
  return Out;
}

/// Two chains in one module, $a_0 .. $a_Depth and $b_0 .. $b_Depth, and
///   (func (param (ref null $a_Depth)) (result (ref null $b_Depth))
///     (local.get 0))
/// The chains are equal unless SecondBottom gives $b_0 a field.
std::vector<Byte> twinChainModule(uint32_t Depth, bool SecondBottom) {
  std::vector<Byte> Types;
  appendU32(Types, 2 * Depth + 3);
  appendChain(Types, 0, Depth, false);
  appendChain(Types, Depth + 1, Depth, SecondBottom);
  Types.insert(Types.end(), {0x60, 0x01, 0x63});
  appendHeapIdx(Types, Depth);
  Types.insert(Types.end(), {0x01, 0x63});
  appendHeapIdx(Types, 2 * Depth + 1);
  std::vector<Byte> Out{0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00};
  appendSection(Out, 0x01, Types);
  std::vector<Byte> Funcs{0x01};
  appendU32(Funcs, 2 * Depth + 2);
  appendSection(Out, 0x03, Funcs);
  appendSection(Out, 0x0A, {0x01, 0x04, 0x00, 0x20, 0x00, 0x0B});
  return Out;
}

constexpr uint32_t ChainDepth = 48;

/// A function import whose parameter type tops a 48-level struct chain links
/// against an equal chain in another module, and an import whose chain
/// differs at the bottom is rejected.
TEST(SubtypeMatch, DeepTypeGraphsLinkPromptly) {
  const auto Exporter = deepChainModule(ChainDepth, true, false);
  const auto Equal = deepChainModule(ChainDepth, false, false);
  const auto Other = deepChainModule(ChainDepth, false, true);
  auto Res = linkWith(Exporter, Equal);
  EXPECT_TRUE(Res) << "the equal chain did not link";
  Res = linkWith(Exporter, Other);
  ASSERT_FALSE(Res) << "the chain with another bottom type linked";
  EXPECT_EQ(Res.error(), ErrCode::Value::IncompatibleImportType);
}

/// A module passing a value of one 48-level struct chain as an equal chain
/// declared next to it validates, and fails when the second chain differs at
/// the bottom.
TEST(SubtypeMatch, DeepTypeGraphsValidatePromptly) {
  {
    Configure Conf;
    VM::VM VM(Conf);
    const auto Mod = twinChainModule(ChainDepth, false);
    ASSERT_TRUE(VM.loadWasm(Mod));
    EXPECT_TRUE(VM.validate()) << "the equal chains did not validate";
  }
  {
    Configure Conf;
    VM::VM VM(Conf);
    const auto Mod = twinChainModule(ChainDepth, true);
    ASSERT_TRUE(VM.loadWasm(Mod));
    auto Res = VM.validate();
    ASSERT_FALSE(Res) << "the chain with another bottom type validated";
    EXPECT_EQ(Res.error(), ErrCode::Value::TypeCheckFailed);
  }
}

} // namespace
GTEST_API_ int main(int argc, char **argv) {
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
