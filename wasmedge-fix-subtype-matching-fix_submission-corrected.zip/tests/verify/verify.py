"""Behavioral checks for wasmedge-fix-subtype-matching.

This file runs under VERIFIER_PYTHON (/opt/tooling/venv) and imports no
repository Python (WasmEdge has no Python test harness). It drives a C++ gtest
binary that goes through the embedder API: the VM, and for compiled code the
loader, validator, LLVM compiler, JIT and executor the repository's own LLVM
tests use. Each pytest test below reports one gtest case.

Build: the gtest source is copied into the repository's test tree as an in-tree
CMake target, so it compiles with the repository's flags and links the same
wasmedgeVM target as the repository's regression tests. Building it recompiles
whatever translation units changed in the working tree. The image configured
build/ with WASMEDGE_BUILD_TESTS=ON and has the whole toolchain, so configure
and build need no network.

Run: every gtest case runs in a process of its own with a time limit, so a case
that hangs or crashes is reported as failed and the other cases still run. A
build that fails is reported as every case failing, with the compiler's output.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

REPO = Path(os.environ.get("REPO_DIR", "/repo/WasmEdge"))
BUILD = REPO / "build"
LLVM_DIR = "/usr/lib/llvm-18/lib/cmake/llvm"

# Where this file and its sibling C++ source are at run time.
VERIFY_DIR = Path(__file__).resolve().parent
GTEST_SRC = VERIFY_DIR / "verify_subtype_match.cpp"

# In-repo injection points.
TEST_SUBDIR = REPO / "test" / "executor"
INJECTED_SRC = TEST_SUBDIR / "verify_subtype_match.cpp"
CMAKELISTS = TEST_SUBDIR / "CMakeLists.txt"
TARGET = "wasmedgeSubtypeMatchVerify"
BINARY = BUILD / "test" / "executor" / TARGET
GTEST_JSON = Path("/tmp/subtype_match_gtest.json")
BUILD_LOG = Path("/tmp/subtype_match_build.log")

MARKER = "# >>> subtype-match regression target"
CMAKE_BLOCK = f"""
{MARKER} (auto-generated; do not edit)
wasmedge_add_executable({TARGET}
  verify_subtype_match.cpp
)
target_link_libraries({TARGET}
  PRIVATE
  ${{GTEST_BOTH_LIBRARIES}}
  wasmedgeVM
)
# <<< subtype-match regression target
"""

# gtest case -> time limit in seconds. The two deep type graph cases get the
# shorter limit: a case that hasn't linked or validated its modules by then is
# reported as failed.
CASES = {
    "SubtypeMatch.TagImportMatchesBothWays": 300,
    "SubtypeMatch.TagImportRejectsStrictSubType": 300,
    "SubtypeMatch.ReExportedImportsMatch": 300,
    "SubtypeMatch.ReExportedImportsMatchEveryKind": 300,
    "SubtypeMatch.ReExportedImportsStillChecked": 300,
    "SubtypeMatch.HostFuncMatchesItsDefinedType": 300,
    "SubtypeMatch.HostFuncCastsFollowItsDefinedType": 300,
    "SubtypeMatch.HostFuncTypeIdentity": 300,
    "SubtypeMatch.CompiledCodeMatchesHostFuncs": 300,
    "SubtypeMatch.ModuleFuncRefsFollowTheirDefinedType": 300,
    "SubtypeMatch.CompiledCodeMatchesModuleFuncRefs": 300,
    "SubtypeMatch.DeepTypeGraphsLinkPromptly": 120,
    "SubtypeMatch.DeepTypeGraphsValidatePromptly": 120,
}


def _run(cmd: list[str], log, cwd: Path | None = None) -> int:
    log.write(f"\n$ {' '.join(cmd)}\n")
    log.flush()
    proc = subprocess.run(
        cmd,
        cwd=str(cwd) if cwd else None,
        stdout=log,
        stderr=subprocess.STDOUT,
        text=True,
        check=False,
    )
    return proc.returncode


def _parallelism() -> str:
    return os.environ.get("CMAKE_BUILD_PARALLEL_LEVEL", str(os.cpu_count() or 4))


def _tail(path: Path, n: int = 120) -> str:
    try:
        lines = path.read_text(errors="replace").splitlines()
    except OSError:
        return ""
    return "\n".join(lines[-n:])


def _first_error(path: Path) -> str:
    try:
        lines = path.read_text(errors="replace").splitlines()
    except OSError:
        return ""
    for i, line in enumerate(lines):
        if "error:" in line or "Error " in line:
            return "\n".join(lines[i:i + 6])
    return "\n".join(lines[-6:])


def _short(failure: str) -> str:
    """A gtest failure without its file path line and without line breaks."""
    lines = [ln.strip() for ln in failure.splitlines()]
    if lines and lines[0].startswith(str(REPO)):
        lines[0] = "line " + lines[0].rsplit(":", 1)[-1] + ":"
    return " ".join(ln for ln in lines if ln and ln != "Failed")


def _run_case(full: str, limit: int) -> tuple[bool, str]:
    """Run one gtest case; return (passed, failure text)."""
    if GTEST_JSON.exists():
        GTEST_JSON.unlink()
    try:
        proc = subprocess.run(
            [str(BINARY), f"--gtest_filter={full}",
             f"--gtest_output=json:{GTEST_JSON}"],
            capture_output=True,
            text=True,
            timeout=limit,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return False, f"{full} did not finish within {limit} s"
    print(f"===== {full} (rc={proc.returncode})")
    print(proc.stdout[-4000:])
    if proc.stderr:
        print(proc.stderr[-2000:])
    if not GTEST_JSON.exists():
        return False, f"{full} ended with rc={proc.returncode} and no result: " + proc.stdout[-300:]
    data = json.loads(GTEST_JSON.read_text())
    for suite in data.get("testsuites", []):
        for tc in suite.get("testsuite", []):
            if f"{suite.get('name', '')}.{tc.get('name', '')}" != full:
                continue
            failures = tc.get("failures") or []
            if failures:
                return False, " | ".join(_short(f.get("failure", "")) for f in failures)
            if tc.get("result", "COMPLETED") != "COMPLETED" or tc.get("status", "RUN") != "RUN":
                return False, f"{full} did not run to completion ({tc.get('result')})"
            return True, ""
    return False, f"{full} is not in the gtest output"


@pytest.fixture(scope="session")
def gtest_results() -> dict[str, tuple[bool, str]]:
    """Inject the in-tree target, build it offline, run every case.

    Returns gtest full name -> (passed, failure text). Raises on a missing
    source, repository or configure step. A compile error in the working tree
    is reported as every case failing, with the compiler's first error.
    """
    assert GTEST_SRC.is_file(), f"missing gtest source: {GTEST_SRC}"
    assert REPO.is_dir(), f"repo not found: {REPO}"

    env_path = os.environ.get("LD_LIBRARY_PATH", "")
    os.environ["LD_LIBRARY_PATH"] = f"{BUILD / 'lib' / 'api'}:{env_path}"

    with BUILD_LOG.open("w") as log:
        # 1. Copy the C++ source in and register the target (idempotent).
        shutil.copyfile(GTEST_SRC, INJECTED_SRC)
        cml = CMAKELISTS.read_text()
        if MARKER not in cml:
            CMAKELISTS.write_text(cml.rstrip() + "\n" + CMAKE_BLOCK)

        # 2. Configure (offline: _deps were populated when the image configured
        #    build/ with WASMEDGE_BUILD_TESTS=ON; a rerun is incremental).
        rc = _run(
            [
                "cmake", "-S", str(REPO), "-B", str(BUILD),
                "-DCMAKE_BUILD_TYPE=Release",
                "-DWASMEDGE_BUILD_TESTS=ON",
                f"-DLLVM_DIR={LLVM_DIR}",
            ],
            log,
        )
        if rc != 0:
            pytest.fail(
                f"cmake configure failed (rc={rc}); see {BUILD_LOG}:\n"
                + _tail(BUILD_LOG),
                pytrace=False,
            )

        # 3. Build the target, which recompiles every translation unit of
        #    wasmedgeVM that changed in the working tree.
        build_rc = _run(
            ["cmake", "--build", str(BUILD), "--target", TARGET,
             "--parallel", _parallelism()],
            log,
        )

    if build_rc != 0 or not BINARY.is_file():
        print(f"[verify] build failed (rc={build_rc})")
        print(_tail(BUILD_LOG))
        reason = f"the build failed (rc={build_rc}): " + _first_error(BUILD_LOG)
        return {full: (False, reason) for full in CASES}

    # 4. Run each case in its own process.
    return {full: _run_case(full, limit) for full, limit in CASES.items()}


def _check(results, full: str, what: str) -> None:
    passed, why = results[full]
    assert passed, f"{why[:600]} [{what}]"


def test_tag_import_matches_both_ways(gtest_results):
    """A tag import declaring a strict super type of the exported tag's type is
    rejected at link time (IncompatibleImportType); an equivalent type links."""
    _check(gtest_results, "SubtypeMatch.TagImportMatchesBothWays",
           "a super-type tag import must fail to link and an equivalent one link")


def test_tag_import_rejects_strict_subtype(gtest_results):
    """A tag import declaring a strict sub type of the exported tag's type is
    rejected at link time as well."""
    _check(gtest_results, "SubtypeMatch.TagImportRejectsStrictSubType",
           "a sub-type tag import must fail to link")


def test_reexported_imports_match(gtest_results):
    """A global, table or tag that B takes from A and exports again links in a
    third module that declares A's types for it."""
    _check(gtest_results, "SubtypeMatch.ReExportedImportsMatch",
           "forwarded global, table and tag imports must link")


def test_reexported_imports_match_every_kind(gtest_results):
    """The same through one or two forwarders, for a mutable global too, and
    for a const global imported with an abstract super type."""
    _check(gtest_results, "SubtypeMatch.ReExportedImportsMatchEveryKind",
           "every matching forwarded import must link")


def test_reexported_imports_still_checked(gtest_results):
    """A forwarded global, table or tag imported with another type, or with a
    super type where the import is invariant, fails to link."""
    _check(gtest_results, "SubtypeMatch.ReExportedImportsStillChecked",
           "mismatched forwarded imports must fail to link")


def test_hostfunc_matches_defined_type(gtest_results):
    """A host function in a table matches its own final func type in
    call_indirect and ref.test, and not a non-final type of the same shape."""
    _check(gtest_results, "SubtypeMatch.HostFuncMatchesItsDefinedType",
           "call_f/test_f succeed, call_g traps IndirectCallTypeMismatch, test_g is 0")


def test_hostfunc_casts_follow_defined_type(gtest_results):
    """ref.test, ref.cast, br_on_cast and br_on_cast_fail see a host function
    with its own final func type."""
    _check(gtest_results, "SubtypeMatch.HostFuncCastsFollowItsDefinedType",
           "casts and branches on a host function follow its own type")


def test_hostfunc_type_identity(gtest_results):
    """A host function matches only a type equal to its own."""
    _check(gtest_results, "SubtypeMatch.HostFuncTypeIdentity",
           "a host function matches only a type equal to its own")


def test_compiled_code_matches_hostfuncs(gtest_results):
    """JIT-compiled code gives the host function checks the interpreter's
    outcomes."""
    _check(gtest_results, "SubtypeMatch.CompiledCodeMatchesHostFuncs",
           "compiled call_indirect, ref.test, ref.cast and br_on_cast on host functions")


def test_module_func_refs_follow_defined_type(gtest_results):
    """Module functions put into a table from the embedder side are their
    declared type, and its super types, to ref.test, ref.cast, br_on_cast and
    br_on_cast_fail."""
    _check(gtest_results, "SubtypeMatch.ModuleFuncRefsFollowTheirDefinedType",
           "casts and branches on module functions in a table follow their types")


def test_compiled_code_matches_module_func_refs(gtest_results):
    """JIT-compiled code gives the module function checks the interpreter's
    outcomes."""
    _check(gtest_results, "SubtypeMatch.CompiledCodeMatchesModuleFuncRefs",
           "compiled ref.test, ref.cast and br_on_cast on module functions in a table")


def test_deep_type_graphs_link(gtest_results):
    """A function import typed with a 48-level struct chain links against an
    equal chain, and one that differs at the bottom is rejected."""
    _check(gtest_results, "SubtypeMatch.DeepTypeGraphsLinkPromptly",
           "linking an import whose type tops a deep struct chain")


def test_deep_type_graphs_validate(gtest_results):
    """Two equal 48-level struct chains in one module are equal to the
    validator, and two that differ at the bottom are not."""
    _check(gtest_results, "SubtypeMatch.DeepTypeGraphsValidatePromptly",
           "validating a module with two deep struct chains")
