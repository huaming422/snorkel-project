#!/usr/bin/env bash
# Sourced by tests/test.sh before the checks run (set -euo pipefail inherited).
#
# The working tree may change any C++ source of the runtime, so the in-image
# build/ tree is brought up to date first. The image configured build/ with
# WASMEDGE_BUILD_TESTS=ON and holds the whole toolchain (LLVM/LLD 18,
# gtest/gmock, boost and the rest), so this rebuild is incremental and needs no
# network.
cd /repo/WasmEdge

# Everything the build needs is in the image; nothing is fetched here.
export CMAKE_BUILD_PARALLEL_LEVEL="${CMAKE_BUILD_PARALLEL_LEVEL:-4}"

# Incremental rebuild of the shared library. The image's configured build/ is
# reused, so only changed translation units recompile. If the configured tree
# is missing, it's configured once from the LLVM package in the image, offline.
if [ ! -f build/CMakeCache.txt ]; then
    echo "[test-setup] build/ not configured; configuring from baked toolchain"
    cmake -S . -B build -DCMAKE_BUILD_TYPE=Release \
        -DWASMEDGE_BUILD_TESTS=ON \
        -DLLVM_DIR=/usr/lib/llvm-18/lib/cmake/llvm \
        > /tmp/test-setup-configure.log 2>&1 \
        || { echo "[test-setup] configure failed"; tail -80 /tmp/test-setup-configure.log >&2; }
fi

# A working tree that doesn't compile is not a reason to stop here: this file is
# sourced, so an exit would end the whole run before the checks write a result.
# The checks build their own target and report the compiler's error.
echo "[test-setup] rebuilding libwasmedge against the current working tree"
if cmake --build build --target wasmedge_shared > /tmp/test-setup-build.log 2>&1; then
    echo "[test-setup] libwasmedge rebuilt from working tree"
else
    echo "[test-setup] libwasmedge did not build; the checks report the error"
    tail -40 /tmp/test-setup-build.log >&2
fi

# The unit/regression binaries dlopen the freshly built shared library; the
# image already exports LD_LIBRARY_PATH=/repo/WasmEdge/build/lib/api, re-assert
# it here so a sourced subshell inherits it even if the environment was reset.
export LD_LIBRARY_PATH="/repo/WasmEdge/build/lib/api:${LD_LIBRARY_PATH:-}"

# No services to start and no data to seed: the gtest cases run in-process
# through the VM and executor embedder API.
echo "[test-setup] ready"
