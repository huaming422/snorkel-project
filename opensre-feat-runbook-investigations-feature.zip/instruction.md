## Task

During an incident OpenSRE writes its own guidance from scratch. Most teams already keep runbooks in a Git repository and would rather the agent follow those. Let operators register the sources they trust, and let the agent load the matching runbook while it investigates, either from a link carried in the alert payload or by looking the alert up in a catalog of runbooks.

Some names are fixed because operators and the agent call them. The CLI gets a top level command group whose name contains `runbook`, with `add`, `list`, `remove` and `verify` subcommands. The interactive shell gets a slash command whose name contains `runbook` and runs the same subcommands, so `list` there prints what the CLI prints. The agent gets a tool whose registered name contains `runbook`, reachable on its chat or action tool surface and registered as read-only, because loading a runbook informs the investigation and changes nothing. Everything else about the design is up to you.

## User stories / requirements

- A catalog entry matches on alert name, service and required labels, and is skipped when a required label is missing or different on the incident. Alert name outranks service alone, and more required labels outrank fewer at the same level. A tie at the top is ambiguous and names both entries; no match finds nothing.
- Given only an incident's alert identity, the agent's runbook tool picks the best entry across all configured sources and returns its content, the entry, the source and why it matched. Only that runbook's document is read. A tie, even across sources, names the tied entries and reads nothing; no match loads nothing.
- The tool also takes a runbook link and loads it only when the link points inside a registered source. A link on another host or in another repository is refused, with no fallback to matching the alert identity. When reading the runbook fails, the result says so without the provider's error text.
- Operators add, list, remove and verify runbook sources from the command line. Adding a taken name fails and leaves the existing source unchanged, a removed source drops out of the list, and an empty list says no sources are configured. Verify really reads from the source and exits non-zero when that read fails.
