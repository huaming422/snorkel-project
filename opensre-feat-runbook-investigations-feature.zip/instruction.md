## Task

OpenSRE makes up its own guidance when it works an incident, but most teams already keep runbooks in Git and want the agent to follow those. Let operators register the runbook sources they trust, and let the agent load the right runbook mid-investigation, either from a link that came with the alert or by looking the alert up in a source's catalog.

Operators will manage sources with an `opensre runbooks` command group (`add`, `list`, `remove`, `verify`) and a matching `/runbooks` command in the interactive shell. The agent gets its own tool for loading runbooks. Keep runbook in that tool's name so it is easy to spot, put it on the agent's chat or action surface, and register it as read-only, since it only looks things up. The rest of the design is yours.

## User stories / requirements

- A catalog entry applies only when every alert name, service and label it sets agrees with the incident; a missing label is a mismatch. Alert name outranks service alone, and more required labels outrank fewer at the same level. A tie at the top is ambiguous and names the tied entries; no match picks nothing.
- Given only an incident's alert identity, the agent's runbook tool picks the best entry across all configured sources and returns its content, the entry, the source and why it matched. Only that runbook's document is read. A tie, even across sources, names the tied entries and reads nothing; no match loads nothing.
- Given a runbook link, the tool loads it only if it leads into a registered source; anything leading elsewhere, whether by host, by repository (even under the same owner) or by a path that climbs out, is refused with no fallback to alert matching. A failed read says so, without the provider's error text.
- Operators add, list, remove and verify runbook sources from the command line. Adding a taken name fails without touching the existing source, remove drops only that source from the list, and an empty list says nothing is configured. Verify reads the source itself, not just the hosting service, and exits non-zero when it can't.
- The runbook slash command in the interactive shell takes the same subcommands and arguments as the CLI group and has the same effect, so a source added or removed there is added or removed for the CLI too, and its list and verify print what the CLI prints.
