#!/usr/bin/env bash
# Environment for the runbook stories.
#
# The image already installed every dependency into /opt/venv, so nothing is
# installed here. This activates that venv, moves to the repo and imports the
# existing modules the stories use, failing fast if any of them is broken.
# Nothing needs the network; UV_OFFLINE=1 makes any stray resolve fail loudly.

set -euo pipefail

export UV_OFFLINE=1

REPO=/repo/opensre
VENV=/opt/venv

if [ ! -x "${VENV}/bin/python" ]; then
    echo "FATAL: expected repo venv at ${VENV} (installed in the image); not found." >&2
    exit 1
fi

# shellcheck disable=SC1091
. "${VENV}/bin/activate"
cd "${REPO}"

# Import only modules that exist before the change. A failure here means the
# image or venv is broken.
python - <<'PY'
import sys
sys.path.insert(0, "/repo/opensre")

# Tool registry.
from tools.registry import get_registered_tool_map
tool_map = get_registered_tool_map("chat")
assert isinstance(tool_map, dict) and tool_map, "chat tool registry is empty/broken"

# Click CLI app and its test runner.
from surfaces.cli.app import cli  # noqa: F401
from click.testing import CliRunner  # noqa: F401

# Interactive shell slash command table and session type.
from surfaces.interactive_shell.command_registry import SLASH_COMMANDS  # noqa: F401
from surfaces.interactive_shell.runtime import Session  # noqa: F401

# Agent tool context type and local settings store.
from core.tool import AgentToolContext  # noqa: F401
from config import local_settings  # noqa: F401
assert hasattr(local_settings, "paths"), "config.local_settings.paths missing"

print("opensre runbook-investigation validation env OK")
PY
