"""Helpers for the runbook validation stories.

Everything the runbook feature adds (its value types, matcher, tool function,
source configuration and CLI group) is named by the change under test, so this
module imports none of it at load time. It only offers:

  * accessors for interfaces that exist before the change: the tool registry,
    the Click CLI app, the agent tool context and the local settings home;
  * small, name-free plumbing: a recording fake source, an installer that swaps
    callables the change exposes, and a recorder for faked remote reads.

Usage from a story script::

    import sys
    sys.path.insert(0, "/tests/validate")
    import test_harness as th
"""

from __future__ import annotations

import importlib
import inspect
import sys
from typing import Any, Callable, Iterable

# Repository root inside the image.
REPO = "/repo/opensre"

# Surfaces whose tools the single turn agent receives (see
# core/agent_harness/tools/action_tools.py in the repository).
AGENT_SURFACES = ("chat", "action")


def _ensure_repo_on_path() -> None:
    if REPO not in sys.path:
        sys.path.insert(0, REPO)


# --------------------------------------------------------------------------- #
# Tool registry
# --------------------------------------------------------------------------- #
def get_runbook_tools() -> list[Any]:
    """Every registered tool the agent can reach whose name contains "runbook".

    Looks at both agent surfaces and de-duplicates by registration name.
    """
    _ensure_repo_on_path()
    from tools.registry import get_registered_tool_map

    found: dict[str, Any] = {}
    for surface in AGENT_SURFACES:
        for name, tool in get_registered_tool_map(surface).items():
            if "runbook" in name.lower():
                found.setdefault(name, tool)
    return list(found.values())


def _is_read_only(tool: Any) -> bool:
    level = getattr(tool, "side_effect_level", None)
    return getattr(level, "value", level) == "read_only"


def get_runbook_guidance_tool() -> Any:
    """The runbook tool the agent calls to load a runbook.

    If several registered tools carry the noun, prefer a read-only one. Raises
    AssertionError when none is registered.
    """
    matches = get_runbook_tools()
    assert matches, "No tool whose name contains 'runbook' is registered for the agent."
    preferred = [t for t in matches if _is_read_only(t)]
    return (preferred or matches)[0]


def runbook_tool_callable() -> Callable[..., Any]:
    """The registered tool's underlying callable (``RegisteredTool.run``)."""
    return get_runbook_guidance_tool().run


def runbook_tool_module() -> Any:
    """Import the module that defines the runbook tool (from ``origin_module``)."""
    _ensure_repo_on_path()
    tool = get_runbook_guidance_tool()
    module_path = getattr(tool, "origin_module", "") or getattr(tool.run, "__module__", "")
    assert module_path, "Cannot tell which module defines the runbook tool."
    return importlib.import_module(module_path)


def call_runbook_tool(**kwargs: Any) -> Any:
    """Call the runbook tool the way the agent would.

    Adds ``context=make_agent_context()`` only when the tool takes a runtime
    context and the caller did not pass one, so tools without a context
    parameter are called without it.
    """
    tool = get_runbook_guidance_tool()
    fn = tool.run
    try:
        params = inspect.signature(fn).parameters
    except (TypeError, ValueError):
        params = {}
    takes_context = getattr(tool, "accepts_runtime_context", False) or "context" in params
    if takes_context and "context" not in kwargs:
        kwargs["context"] = make_agent_context()
    if not takes_context:
        kwargs.pop("context", None)
    return fn(**kwargs)


def import_from(module_path: str, *names: str) -> Any:
    """Import ``names`` from ``module_path``; one name returns the object itself."""
    _ensure_repo_on_path()
    module = importlib.import_module(module_path)
    objs = tuple(getattr(module, n) for n in names)
    return objs[0] if len(objs) == 1 else objs


# --------------------------------------------------------------------------- #
# Agent tool context
# --------------------------------------------------------------------------- #
def make_agent_context(**resolved_integrations: Any) -> Any:
    """Build an ``AgentToolContext`` with GitHub marked connected by default."""
    _ensure_repo_on_path()
    from core.tool import AgentToolContext

    integrations = resolved_integrations or {"github": {"connection_verified": True}}
    return AgentToolContext(resolved_integrations=integrations)


# --------------------------------------------------------------------------- #
# Click CLI and local settings home
# --------------------------------------------------------------------------- #
def cli_app() -> Any:
    """The Click CLI group (``surfaces.cli.app.cli``)."""
    _ensure_repo_on_path()
    from surfaces.cli.app import cli

    return cli


def cli_runner() -> Any:
    """A Click ``CliRunner``."""
    from click.testing import CliRunner

    return CliRunner()


def runbook_cli_group_names() -> list[str]:
    """Top level CLI command names that contain "runbook"."""
    import click

    app = cli_app()
    ctx = click.Context(app)
    return [n for n in app.list_commands(ctx) if "runbook" in n.lower()]


def isolate_home(monkeypatch: Any, tmp_path: Any) -> None:
    """Point every OpenSRE home lookup at ``tmp_path``.

    Sets ``OPENSRE_HOME`` and ``HOME`` for code that reads the environment and
    patches ``config.local_settings.paths.OPENSRE_HOME_DIR`` for code that reads
    the resolved path, so each case starts with nothing configured.
    """
    _ensure_repo_on_path()
    from config import local_settings

    monkeypatch.setenv("OPENSRE_HOME", str(tmp_path))
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(local_settings.paths, "OPENSRE_HOME_DIR", tmp_path)


# --------------------------------------------------------------------------- #
# Name-free plumbing
# --------------------------------------------------------------------------- #
class RecordingFakeSource:
    """An in-memory runbook source that records what it was asked to read.

    Its four operations (``verify``, ``resolve_reference``, ``fetch_catalog``,
    ``fetch_document``) are a common shape for a source object. If the change
    names or splits these operations differently, subclass and adapt; keep the
    recording attributes. The catalog, reference and document values are the
    change's own types, built by the story and only stored here.
    """

    def __init__(
        self,
        *,
        provider: str = "github",
        catalog: Any | None = None,
        accepted_url: str = "",
        reference: Any | None = None,
        document: Any | None = None,
        document_error: BaseException | None = None,
        catalog_error: BaseException | None = None,
    ) -> None:
        self.provider = provider
        self.catalog = catalog
        self.accepted_url = accepted_url
        self.reference = reference
        self.document = document
        self.document_error = document_error
        self.catalog_error = catalog_error
        self.fetched_reference: Any | None = None
        self.fetch_document_calls = 0
        self.fetch_catalog_calls = 0
        self.resolve_calls: list[str] = []

    def verify(self) -> tuple[bool, str]:
        return True, "ok"

    def resolve_reference(self, url: str) -> Any | None:
        self.resolve_calls.append(url)
        if url != self.accepted_url:
            return None
        return self.reference

    def fetch_catalog(self) -> Any:
        self.fetch_catalog_calls += 1
        if self.catalog_error is not None:
            raise self.catalog_error
        if self.catalog is None:
            raise RuntimeError("catalog unavailable")
        return self.catalog

    def fetch_document(self, reference: Any) -> Any:
        self.fetch_document_calls += 1
        if self.document_error is not None:
            raise self.document_error
        self.fetched_reference = reference
        assert self.document is not None, "RecordingFakeSource has no document to return"
        return self.document


class RemoteReadRecorder:
    """A stand-in for whatever call the change uses to read remote content.

    Call it like the function it replaces. Every call is appended to ``calls``
    as ``(args, kwargs)``. ``respond`` (optional) receives the same arguments
    and returns the value to hand back; ``error`` (optional) is raised instead.
    """

    def __init__(
        self,
        respond: Callable[..., Any] | None = None,
        *,
        error: BaseException | None = None,
    ) -> None:
        self.respond = respond
        self.error = error
        self.calls: list[tuple[tuple[Any, ...], dict[str, Any]]] = []

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        self.calls.append((args, kwargs))
        if self.error is not None:
            raise self.error
        if self.respond is None:
            raise AssertionError("RemoteReadRecorder has no response configured")
        return self.respond(*args, **kwargs)

    def mentions(self, text: str) -> bool:
        """True when ``text`` appears in any recorded call's arguments."""
        return any(text in repr(call) for call in self.calls)


def install_sources(
    monkeypatch: Any,
    module: Any,
    configs: Iterable[Any],
    resolver: Callable[[Any], Any | None],
    *,
    load_attr: str,
    resolve_attr: str,
) -> None:
    """Swap the callables a module uses to list configured sources and build them.

    ``load_attr`` names the module attribute that returns the configured
    sources; ``resolve_attr`` names the one that turns a config into a live
    source. Both names come from reading the change. ``resolver(config)``
    returns the fake for that config; any extra arguments the real resolver
    takes are ignored.
    """
    cfg_tuple = tuple(configs)
    monkeypatch.setattr(module, load_attr, lambda *_a, **_k: cfg_tuple)
    monkeypatch.setattr(module, resolve_attr, lambda config, *_a, **_k: resolver(config))


def result_text(result: Any) -> str:
    """``str(result)``, for checking that a value appears nowhere in a result."""
    return str(result)
