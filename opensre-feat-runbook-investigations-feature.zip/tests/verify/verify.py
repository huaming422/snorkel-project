"""Checks for the runbook feature in opensre.

1. The existing CLI app and tool registry still load (these hold before and
   after the change).
2. A tool whose registered name contains "runbook" is reachable by the agent,
   which receives the tools of both the "chat" and "action" surfaces, and that
   tool is registered as read-only.
3. The interactive shell has a slash command whose name contains "runbook",
   and running it with "list" prints what the CLI's runbook "list" prints for
   the same (empty) home directory.

Names are found by the "runbook" noun, never by a fixed symbol. Runs under the
repository interpreter (/opt/venv), see verify.toml.
"""

from __future__ import annotations

import os
import re
import subprocess
import sys

REPO = "/repo/opensre"
if REPO not in sys.path:
    sys.path.insert(0, REPO)

import pytest  # noqa: E402

PYTHON = sys.executable
AGENT_SURFACES = ("chat", "action")


# --------------------------------------------------------------------------- #
# Existing surfaces keep working
# --------------------------------------------------------------------------- #
def test_cli_app_still_imports_and_responds_to_help() -> None:
    from click.testing import CliRunner

    from surfaces.cli.app import cli

    result = CliRunner().invoke(cli, ["--help"])
    assert result.exit_code == 0, (
        f"`cli --help` should exit 0. exit_code={result.exit_code}\noutput:\n{result.output}"
    )


def test_chat_tool_registry_still_builds() -> None:
    from tools.registry import get_registered_tool_map

    tool_map = get_registered_tool_map("chat")
    assert isinstance(tool_map, dict)
    assert tool_map, "The chat tool registry should still list its existing tools."


# --------------------------------------------------------------------------- #
# The agent can reach a read-only runbook tool
# --------------------------------------------------------------------------- #
def _runbook_agent_tools() -> list:
    from tools.registry import get_registered_tool_map

    found: dict = {}
    for surface in AGENT_SURFACES:
        for name, tool in get_registered_tool_map(surface).items():
            if "runbook" in name.lower():
                found.setdefault(name, tool)
    return list(found.values())


def _is_read_only(tool) -> bool:
    level = getattr(tool, "side_effect_level", None)
    return getattr(level, "value", level) == "read_only"


def test_runbook_tool_is_reachable_by_the_agent() -> None:
    assert _runbook_agent_tools(), (
        "No registered tool whose name contains 'runbook' on the chat or action surface."
    )


def test_runbook_tool_is_read_only() -> None:
    matches = _runbook_agent_tools()
    assert matches, "No runbook tool registered for the agent."
    assert any(_is_read_only(t) for t in matches), (
        "The runbook tool should be registered with side_effect_level read_only. Found: "
        + ", ".join(f"{t.name}={getattr(t, 'side_effect_level', None)}" for t in matches)
    )


# --------------------------------------------------------------------------- #
# Shell parity: "/<runbook command> list" prints what the CLI prints
# --------------------------------------------------------------------------- #
_ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")

_CLI_GROUP_SCRIPT = """
import sys
sys.path.insert(0, "/repo/opensre")
import click
from surfaces.cli.app import cli
names = [n for n in cli.list_commands(click.Context(cli)) if "runbook" in n.lower()]
print("\\n".join(names))
"""

_SHELL_SCRIPT = """
import sys
sys.path.insert(0, "/repo/opensre")
from rich.console import Console
from surfaces.interactive_shell.command_registry import SLASH_COMMANDS
from surfaces.interactive_shell.runtime import Session
names = [n for n in SLASH_COMMANDS if "runbook" in n.lower()]
cmd = SLASH_COMMANDS[names[0]]
console = Console(record=True, width=300, color_system=None, force_terminal=False)
cmd.handler(Session(), console, ["list"])
sys.stdout.write("\\n<<<SHELL-OUTPUT>>>\\n" + console.export_text())
"""


def _norm(text: str) -> str:
    return " ".join(_ANSI.sub("", text).split()).lower()


def _child_env(home: str) -> dict:
    env = dict(os.environ)
    env.update(
        {
            "OPENSRE_HOME": home,
            "HOME": home,
            "NO_COLOR": "1",
            "COLUMNS": "300",
            "PYTHONPATH": REPO,
        }
    )
    return env


def test_shell_runbook_command_lists_like_the_cli(tmp_path) -> None:
    from surfaces.interactive_shell.command_registry import SLASH_COMMANDS

    slash = [n for n in SLASH_COMMANDS if "runbook" in n.lower()]
    assert slash, (
        "No interactive-shell slash command whose name contains 'runbook'. "
        f"Registered: {sorted(SLASH_COMMANDS)}"
    )

    home = str(tmp_path)
    env = _child_env(home)

    groups = subprocess.run(
        [PYTHON, "-c", _CLI_GROUP_SCRIPT], cwd=REPO, env=env,
        capture_output=True, text=True, timeout=120,
    )
    names = [n for n in groups.stdout.split() if n]
    assert names, f"No CLI command group whose name contains 'runbook'.\n{groups.stderr[-2000:]}"

    cli_run = subprocess.run(
        [PYTHON, "-m", "surfaces.cli", names[0], "list"], cwd=REPO, env=env,
        capture_output=True, text=True, timeout=120,
    )
    assert cli_run.returncode == 0, (
        f"`{names[0]} list` should exit 0 on an empty home.\n{cli_run.stdout}\n{cli_run.stderr[-2000:]}"
    )
    cli_text = _norm(cli_run.stdout)
    assert cli_text, f"`{names[0]} list` printed nothing on an empty home."

    shell_run = subprocess.run(
        [PYTHON, "-c", _SHELL_SCRIPT], cwd=REPO, env=env,
        capture_output=True, text=True, timeout=180,
    )
    assert "<<<SHELL-OUTPUT>>>" in shell_run.stdout, (
        f"Running the {slash[0]} slash command failed.\n{shell_run.stdout[-2000:]}\n{shell_run.stderr[-3000:]}"
    )
    shell_text = _norm(shell_run.stdout.split("<<<SHELL-OUTPUT>>>", 1)[1])
    assert cli_text in shell_text, (
        f"`{slash[0]} list` in the shell should print what `{names[0]} list` prints.\n"
        f"CLI: {cli_text!r}\nshell: {shell_text!r}"
    )


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q"]))
