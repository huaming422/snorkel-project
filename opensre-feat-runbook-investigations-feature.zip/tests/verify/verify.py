"""Checks for the runbook feature in opensre.

1. The existing CLI app and tool registry still load (these hold before and
   after the change).
2. A tool whose registered name contains "runbook" is reachable by the agent,
   which receives the tools of both the "chat" and "action" surfaces, and that
   tool is registered as read-only.

The tool is found by the "runbook" noun, never by a fixed symbol. The shell
slash command and the CLI group are covered by the validation stories. Runs
under the repository interpreter (/opt/venv), see verify.toml.
"""

from __future__ import annotations

import sys

REPO = "/repo/opensre"
if REPO not in sys.path:
    sys.path.insert(0, REPO)

import pytest  # noqa: E402

AGENT_SURFACES = ("chat", "action")


# --------------------------------------------------------------------------- #
# Existing surfaces keep working
# --------------------------------------------------------------------------- #
def test_cli_app_still_imports_and_responds_to_help() -> None:
    from click.testing import CliRunner

    from surfaces.cli.app import cli

    result = CliRunner().invoke(cli, ["--help"])
    assert result.exit_code == 0, (
        f"`cli --help` should exit 0. exit_code={result.exit_code}\noutput:\n{result.output}"
    )


def test_chat_tool_registry_still_builds() -> None:
    from tools.registry import get_registered_tool_map

    tool_map = get_registered_tool_map("chat")
    assert isinstance(tool_map, dict)
    assert tool_map, "The chat tool registry should still list its existing tools."


# --------------------------------------------------------------------------- #
# The agent can reach a read-only runbook tool
# --------------------------------------------------------------------------- #
def _runbook_agent_tools() -> list:
    from tools.registry import get_registered_tool_map

    found: dict = {}
    for surface in AGENT_SURFACES:
        for name, tool in get_registered_tool_map(surface).items():
            if "runbook" in name.lower():
                found.setdefault(name, tool)
    return list(found.values())


def _is_read_only(tool) -> bool:
    level = getattr(tool, "side_effect_level", None)
    return getattr(level, "value", level) == "read_only"


def test_runbook_tool_is_reachable_by_the_agent() -> None:
    assert _runbook_agent_tools(), (
        "No registered tool whose name contains 'runbook' on the chat or action surface."
    )


def test_runbook_tool_is_read_only() -> None:
    matches = _runbook_agent_tools()
    assert matches, "No runbook tool registered for the agent."
    assert any(_is_read_only(t) for t in matches), (
        "The runbook tool should be registered with side_effect_level read_only. Found: "
        + ", ".join(f"{t.name}={getattr(t, 'side_effect_level', None)}" for t in matches)
    )


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q"]))
