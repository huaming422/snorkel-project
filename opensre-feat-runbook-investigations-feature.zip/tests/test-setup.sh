#!/usr/bin/env bash
# Shell setup before the checks run. Sourced, not executed, so the exported
# PATH and VIRTUAL_ENV stay set afterwards. The image already ran `uv sync`
# into /opt/venv with the dev group, so this is normally a fast no-op.
set -u

REPO=/repo/opensre
cd "$REPO" || { echo "test-setup: $REPO missing" >&2; return 1 2>/dev/null || exit 1; }

export PATH="/usr/local/bin:$PATH"   # uv

# Keep uv offline: every dependency is already in the image, so a cache miss
# should fail fast instead of trying the network.
export UV_OFFLINE=1

# Re-check the venv against uv.lock from the local cache, with no downloads.
export VIRTUAL_ENV=/opt/venv UV_PROJECT_ENVIRONMENT=/opt/venv
uv sync --frozen --all-extras --group dev --offline 2>&1 | tail -3 || true

if [ -d "/opt/venv" ]; then
    export VIRTUAL_ENV=/opt/venv
    export PATH="/opt/venv/bin:$PATH"
fi

# The existing modules the runbook feature plugs into should import cleanly.
python -c "import config.local_settings; import core.tool; import tools.registry; import surfaces.cli.app" \
    && echo "test-setup: opensre importable" \
    || echo "test-setup: WARNING opensre import failed" >&2
