## Task

some of our analytic queries are slow. the common thread is a WHERE clause that uses OR to combine conditions on columns from two different joined tables, roughly `(a.x = ... AND b.y = ...) OR (a.x = ... AND b.y = ...)`. these run far slower than simpler shapes of the same query. the planner seems to get its row estimates wrong and settle on a bad join order, reading far more rows than it should, as if putting the conditions behind an OR stops it from trimming either table before the join.

it's just as slow on databases we've never analyzed, so it isn't about missing stored stats, and it should speed up in that case too.

this is about how the planner estimates and picks plans, not how rows get executed, so results must come back identical, same rows and same semantics. keep it a broad planner improvement rather than something pinned to one query or table. can you dig in and get these choosing sensible plans?
