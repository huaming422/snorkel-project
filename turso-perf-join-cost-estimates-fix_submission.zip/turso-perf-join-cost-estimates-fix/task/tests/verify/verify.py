"""Behavioral verifier for turso-perf-join-cost-estimates.

Each criterion is realized by a `.sqltest` corpus shipped alongside this file. A
corpus asserts the planner's *decision* (plan shape via `expect pattern`, or
result rows via `expect`) — never a free cost/row-estimate number, so any valid
costing arithmetic that reaches the same decision passes.

This harness is deliberately self-contained: it only shells out to the
pre-built sqltest conformance runner (warmed by tests/test-setup.sh) and parses
its JSON. It imports NO repository Python, so it runs cleanly under the shared
VERIFIER_PYTHON interpreter with no `[pytest] command` override needed.

Criterion -> corpus -> named tests mapping (task.toml order):
  1 or_implied_in_filter_used         (F2P)  c1_implied_in_filter.sqltest
  2 or_filter_results_unchanged       (P2P)  c2_results_unchanged.sqltest
  3 outer_join_no_separate_filter     (P2P)  c3_outer_join_safe.sqltest
  4 two_cols_one_table_respects_index (F2P)  c4_two_cols_one_table.sqltest
  5 unique_seek_cardinality_cap       (F2P)  c5_unique_seek_cap.sqltest
      (observes the probe-side-selectivity rule through the join ORDER: an
       indexed build key must not under-cost the hash join into existence)
  6 hash_join_without_stats           (F2P)  c6_hash_join_no_stats.sqltest
      (observes the same rule through the per-input ESTIMATE on the hash join)
"""

import json
import os
import subprocess
from pathlib import Path

import pytest

# Repo root: the task container clones turso to /repo/turso (see Dockerfile /
# test-setup.sh). Allow an override for local/Modal reruns.
REPO_ROOT = Path(os.environ.get("TURSO_REPO_ROOT", "/repo/turso"))
SQLTEST_MANIFEST = REPO_ROOT / "testing" / "sqltest" / "Cargo.toml"
# Corpora ship alongside this file in tests/verify/ (sbgen copies verify/ files
# flat; it does not recurse into subdirectories).
CORPORA_DIR = Path(__file__).resolve().parent

# Generous per-corpus ceiling; each corpus is a handful of in-memory queries.
# The whole stack stays well under the verifier wall-clock budget.
RUN_TIMEOUT_SEC = 240


def _run_corpus(corpus_name):
    """Run one .sqltest corpus through the native (in-process) Rust backend.

    Returns (summary_dict, results_by_name) where results_by_name maps a test
    name to its outcome string ("passed" / "failed" / "error" / "skipped").
    Raises AssertionError with captured output on a runner/build failure so the
    verifier surfaces infra problems instead of silently green.
    """
    corpus_path = CORPORA_DIR / corpus_name
    assert corpus_path.is_file(), f"missing corpus {corpus_path}"

    cmd = [
        "cargo",
        "run",
        "--quiet",
        "--manifest-path",
        str(SQLTEST_MANIFEST),
        "--bin",
        "sqltest",
        "--",
        "run",
        str(corpus_path),
        "--backend",
        "rust",
        "-o",
        "json",
    ]

    proc = subprocess.run(
        cmd,
        cwd=str(REPO_ROOT),
        capture_output=True,
        text=True,
        timeout=RUN_TIMEOUT_SEC,
    )

    # sqltest exit codes: 0 = all pass/skip, 1 = a test failed OR a hard error,
    # 2 = bad args. We parse JSON regardless and judge per-test; exit code 2
    # (or unparseable output) is an infra failure.
    stdout = proc.stdout or ""
    try:
        payload = json.loads(stdout)
    except json.JSONDecodeError:
        raise AssertionError(
            f"sqltest produced no parseable JSON for {corpus_name} "
            f"(exit {proc.returncode}).\n"
            f"--- stdout ---\n{stdout[-4000:]}\n"
            f"--- stderr ---\n{(proc.stderr or '')[-4000:]}"
        )

    results_by_name = {}
    for f in payload.get("files", []):
        for r in f.get("results", []):
            results_by_name[r.get("name")] = {
                "outcome": r.get("outcome"),
                "reason": r.get("reason"),
            }

    summary = payload.get("summary", {})
    return summary, results_by_name


def _assert_all_pass(corpus_name, expected_tests):
    summary, results = _run_corpus(corpus_name)

    missing = [t for t in expected_tests if t not in results]
    assert not missing, (
        f"{corpus_name}: expected tests not found in runner output: {missing}. "
        f"Saw: {sorted(results)}"
    )

    failures = []
    for t in expected_tests:
        outcome = results[t]["outcome"]
        if outcome != "passed":
            failures.append(f"{t}: outcome={outcome} reason={results[t]['reason']}")
    assert not failures, f"{corpus_name} had non-passing tests:\n" + "\n".join(failures)

    # Defensive: the runner's own summary must agree there were no failures.
    assert summary.get("failed", 0) == 0, (
        f"{corpus_name}: runner summary reports failures: {summary}"
    )


def test_or_implied_in_filter_used():
    """Criterion 1, fail_to_pass.

    An OR-of-AND condition pinning columns on two joined tables to the same
    small value set now lets the planner narrow the indexed table before the
    join (an index SEARCH on the OR-referenced column appears) instead of
    scanning it. An unchanged planner leaves the SCAN and fails the plan-shape
    pattern.
    """
    _assert_all_pass(
        "c1_implied_in_filter.sqltest",
        [
            "implied-in-narrows-indexed-join-table",
            "implied-in-narrows-through-parens",
        ],
    )


def test_or_filter_results_unchanged():
    """Criterion 2, pass_to_pass.

    The implied narrowing never changes result rows, across negative numbers,
    collated text, blob/integer mixes, and NULL keys. A solution that alters
    outputs (dropped OR safety, NULL copied into an implied filter) fails.
    """
    _assert_all_pass(
        "c2_results_unchanged.sqltest",
        [
            "or-join-negative-numbers-keep-results",
            "or-join-text-collation-keep-results",
            "or-join-blob-and-integer-keep-results",
            "or-join-null-key-keep-results",
            "or-join-rejects-cross-combinations",
        ],
    )


def test_outer_join_no_separate_filter():
    """Criterion 3, pass_to_pass.

    An OR attached to a LEFT/OUTER join still emits the NULL-extended rows. A
    naive hoist of a standalone per-table filter across the outer join drops
    those rows and fails this result check.
    """
    _assert_all_pass(
        "c3_outer_join_safe.sqltest",
        ["outer-join-or-keeps-unmatched-left-rows"],
    )


def test_two_cols_one_table_respects_index():
    """Criterion 4, fail_to_pass.

    With both OR-referenced columns on one table: narrowing is added only for
    the column that solely starts an index (SCAN -> SEARCH on that column); a
    compound index over both columns keeps the two correlated compound searches
    (MULTI-INDEX OR over the compound index) rather than a wide single-column
    search. An unchanged planner fails both plan-shape patterns.
    """
    _assert_all_pass(
        "c4_two_cols_one_table.sqltest",
        [
            "two-cols-single-index-narrows-on-indexed-column",
            "two-cols-compound-index-keeps-correlated-searches",
        ],
    )


def test_unique_seek_cardinality_cap():
    """Criterion 5, fail_to_pass (plan-order surface of the probe-side rule).

    The join-key selectivity used to cost a hash join is taken from the probe
    side only. When the BUILD side of the join key carries a secondary index,
    its much smaller indexed selectivity must not shrink the estimated probe
    fan-out. The slow behavior multiplied the probe cardinality by the MINIMUM
    of build- and probe-side selectivities, so an indexed build key made the
    hash join look artificially cheap and the planner picked it. Once the
    fan-out is costed from the probe side alone, the hash join is correctly seen
    as more expensive and the planner chooses the nested index search instead (a
    better join order): `SEARCH b USING INTEGER PRIMARY KEY -> SEARCH c USING
    ... INDEX`. An unchanged planner selects a HASH JOIN on `c` and fails the
    asserted plan shape.
    """
    _assert_all_pass(
        "c5_unique_seek_cap.sqltest",
        ["indexed-build-key-does-not-undercount-probe-fanout"],
    )


def test_hash_join_without_stats():
    """Criterion 6, fail_to_pass.

    With no ANALYZE statistics, the joined fan-out of a hash join is estimated
    from the probe rows actually scanned (probe-side selectivity only). When the
    build-side join key carries a secondary index, its indexed selectivity is far
    smaller than the probe-side one; the slow behavior multiplied the probe
    cardinality by the MINIMUM of the two, under-counting the fan-out. The fixed
    engine uses the probe-side selectivity alone, so the HASH JOIN node on the
    middle table carries the probe-driven per-input estimate (100000). An
    unchanged planner reports the smaller, under-counted estimate and fails the
    asserted plan/estimate.
    """
    _assert_all_pass(
        "c6_hash_join_no_stats.sqltest",
        ["hash-join-without-stats-estimates-probe-fanout"],
    )


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v"]))
