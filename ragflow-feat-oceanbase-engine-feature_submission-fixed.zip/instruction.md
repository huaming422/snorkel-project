## Task

The Go server can't run on OceanBase or SeekDB yet.
Starting it with DOC_ENGINE=oceanbase stops with `get environments error: not implemented: oceanbase`, and DOC_ENGINE=seekdb fails with `get environments error: invalid doc engine: seekdb`.
Anyone on those databases still has to run the Python services.
Please add an OceanBase document engine on the Go side that serves SeekDB as well.
Use the MySQL driver that's already in go.mod for both instead of adding a new client.
The Python connector stays as it is, because it's the reference for how existing data is laid out.
Picking either engine has to carry through to everything that uses the document engine.
Retrieval ranking, memory messages (forgetting one included), document metadata edits and the SQL chat flow all need to handle it.
There's no OceanBase or SeekDB server here and no network.
Unit tests should mock the SQL layer, and anything that needs a live server should skip when there isn't one configured.

## User stories / requirements

- Setting DOC_ENGINE to oceanbase or seekdb is accepted at startup and connects with that engine's existing section in service_conf.yaml.
  If the section sets scheme to mysql, host, port, user and password come from the mysql section and only db_name comes from the engine's own config.
  With DB_TYPE=oceanbase, the main database connection takes its settings from the oceanbase section.
- The Go engine can open a database the Python connector already created for OceanBase or SeekDB and use it without a migration.
  It uses the same table names, columns and index names, and stores array, JSON and vector values in the same form, so rows written from Go read back correctly in Python and the other way round.
  Tenant or document ids that aren't safe SQL identifiers are refused before any SQL is built.
  Metadata filters that use ≠ or not in have to keep giving the same results on multi-valued fields, so they aren't pushed down to the database as SQL.
- When the SeekDB server's version supports index refresh, a write blocks until the refresh finishes, so rows it just wrote can be searched immediately.
  OceanBase, and SeekDB versions older than that, return from writes straight away.
- Looking up chunk vectors for citations on an OceanBase or SeekDB dataset queries the engine for them, so citations get the real vectors instead of zeros.
