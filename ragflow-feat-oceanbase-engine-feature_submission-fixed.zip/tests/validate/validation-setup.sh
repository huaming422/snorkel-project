#!/usr/bin/env bash
# Validation environment setup for the SQL document-engine family stories.
#
# Runs after tests/test-setup.sh has prepared the Go toolchain and before the
# test runner writes its test files. The task image already baked the full Go
# module closure at the base commit and pre-compiled the touched packages under
# CGO_ENABLED=0 (internal/common/libm_purego.go is the non-cgo math fallback, so
# no native static libraries are needed). This script only keeps the environment
# stable against user changes and against a freshly spawned shell that did not
# inherit the image ENV. Every step works offline.
set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/ragflow}"

# Pin the baked toolchain even if the harness scrubbed PATH, and never let `go`
# try to download a different toolchain (there is no network at test time).
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

# All stories compile as pure-Go sqlmock / in-memory unit tests, so force CGO off
# to select the purego math fallback and avoid any native toolchain requirement.
export CGO_ENABLED="${CGO_ENABLED:-0}"
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"
export GOFLAGS="${GOFLAGS:--mod=mod}"
export GOCACHE="${GOCACHE:-/root/.cache/go-build}"
export GOMODCACHE="${GOMODCACHE:-/root/go/pkg/mod}"
mkdir -p "$GOCACHE" "$GOMODCACHE"

cd "$REPO_DIR"

# The image already ran the module download at build time, so the closure is in
# the module cache. Resolve offline first (GOPROXY=off), which is the normal path
# with no network, and only fall back to a logged online attempt if that cannot
# satisfy the graph (a no-op without network). The go-test driver reports the
# real compile status either way, so a failure here is tolerated.
if ! GOPROXY=off go mod download 2>/tmp/gomod-offline.log; then
    echo "validation-setup.sh: offline module resolution incomplete; trying online fallback" >&2
    go mod download || true
fi

# Warm the build cache for the packages the stories target so the graded test
# runs do not pay a cold compile. `go build` (NOT `go vet`): this base commit
# carries a pre-existing vet nit in an unrelated test file
# (internal/service/nlp/synonym_test.go copies a sync/atomic value) and `go vet`
# compiles _test.go files, which would spuriously surface that nit. `|| true`
# keeps a half-finished tree from aborting setup.
CGO_ENABLED=0 go build \
    ./internal/engine \
    ./internal/engine/oceanbase \
    ./internal/server/config \
    ./internal/service/chunk \
    >/dev/null 2>&1 || true

echo "validation-setup.sh: Go toolchain ready (CGO_ENABLED=$CGO_ENABLED, GOTOOLCHAIN=$GOTOOLCHAIN)."
