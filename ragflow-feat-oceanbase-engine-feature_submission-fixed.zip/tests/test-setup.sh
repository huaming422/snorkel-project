#!/usr/bin/env bash
#
# Sourced (not exec'd, so exported env sticks) before the Go verifier runs. The
# image already baked the full Go module closure at the base commit and compiled
# the touched packages under CGO_ENABLED=0 (internal/common/libm_purego.go is the
# non-cgo math fallback, so no native static libraries are needed). This script
# only keeps the environment stable against user changes and against a freshly
# spawned shell that didn't inherit the image ENV. It works offline and fetches
# nothing.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/ragflow}"
cd "$REPO_DIR"

# The OceanBase/SeekDB engine, config, and service tests are pure go-sqlmock
# unit tests that compile without CGO. Force CGO off so the purego math fallback
# is selected and no office_oxide / rag_tokenizer static libs are required.
export CGO_ENABLED=0

# Pin the toolchain to the baked one even if the harness scrubs PATH, and never
# let `go` try to download a different toolchain (there is no network at test time).
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac
export GOTOOLCHAIN=local
export GOFLAGS="${GOFLAGS:-} -mod=mod"

# Write a small setter into the engine package so the retrieval verifier can
# set the process-wide engine type next to its spy engine. Retrieval code may
# read the type from the engine instance or from engine.GetEngineType(). In a
# running server both come from engine.Get(), so the verifier sets both and
# either way of reading it works.
#
# The file is written here, not baked into the image, so it lands after the
# implementation change is applied, goes away with the container, and is never
# part of the tree the implementation is written against. The setter name is
# long and specific so it won't clash with anything a change adds.
SEAM_FILE="${REPO_DIR}/internal/engine/zz_verify_engine_type_seam.go"
cat > "$SEAM_FILE" <<'GOEOF'
// Test-only helper written by tests/test-setup.sh. Not part of the product.
package engine

// SetEngineTypeForVerify sets the process-wide engine type that
// GetEngineType returns. Only the retrieval verifier calls it.
func SetEngineTypeForVerify(t string) { engineType = t }
GOEOF

# Warm the build cache for the packages the verifiers target, so the timed
# `go test` run doesn't pay a cold compile. We use `go build`, NOT `go vet`:
# this base commit carries a PRE-EXISTING vet nit in an unrelated test file
# (internal/service/nlp/synonym_test.go copies a sync/atomic value), and `go vet`
# compiles _test.go files, so a vet warm-up would spuriously log that nit. The
# module closure is already present; `|| true` keeps a half-finished tree from
# aborting setup (the verifier reports the real compile status).
CGO_ENABLED=0 go build \
    ./internal/engine \
    ./internal/engine/oceanbase \
    ./internal/server/config \
    ./internal/service \
    ./internal/service/chunk \
    ./internal/service/nlp \
    ./internal/service/document \
    >/dev/null 2>&1 || true

echo "test-setup.sh: ready (CGO_ENABLED=$CGO_ENABLED, GOTOOLCHAIN=$GOTOOLCHAIN)"
