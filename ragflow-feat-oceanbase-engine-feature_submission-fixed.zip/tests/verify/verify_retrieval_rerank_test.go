// Copyright 2026 The InfiniFlow Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Contract checked here: Retrieval() picks its scoring path from the engine
// family. The second-pass KNNScores call is an Elasticsearch API, so an
// OceanBase or SeekDB engine must never reach it, while an Elasticsearch
// engine still does.
//
// Retrieval can learn the engine type from the engine instance it was built
// with or from the process-wide engine type. In a running server both come
// from engine.Get(), so the test sets both to the same value. The setter for
// the process-wide value is written into the engine package by
// tests/test-setup.sh and is not part of the product.
//
// The spy's Search() returns one chunk with no "doc_id", so
// PruneDeletedChunks returns early and no database is touched.

package nlp

import (
	"context"
	"testing"

	"ragflow/internal/dao"
	"ragflow/internal/engine"
	enginetypes "ragflow/internal/engine/types"

	"gorm.io/gorm"
)

// rerankSpyEngine records whether KNNScores was called and returns one canned
// chunk from Search. Methods that retrieval does not use are no-ops.
type rerankSpyEngine struct {
	engineTypeName  string
	knnScoresCalled bool
	searchChunks    []map[string]interface{}
}

func (e *rerankSpyEngine) GetType() string { return e.engineTypeName }

func (e *rerankSpyEngine) Search(_ context.Context, req *enginetypes.SearchRequest) (*enginetypes.SearchResult, error) {
	chunks := e.searchChunks
	if chunks == nil {
		chunks = []map[string]interface{}{}
	}
	return &enginetypes.SearchResult{
		Chunks: chunks,
		Total:  int64(len(chunks)),
	}, nil
}

func (e *rerankSpyEngine) KNNScores(_ context.Context, _ []map[string]interface{}, _ []float64, _ int) (map[string]interface{}, error) {
	e.knnScoresCalled = true
	return nil, nil
}

func (e *rerankSpyEngine) GetScores(_ map[string]interface{}) map[string]float64 { return nil }

func (e *rerankSpyEngine) GetChunkIDs(chunks []map[string]interface{}) []string {
	ids := make([]string, len(chunks))
	for i := range chunks {
		ids[i] = "rerankspy-chunk-" + string(rune('0'+i))
	}
	return ids
}

func (e *rerankSpyEngine) GetFields(_ []map[string]interface{}, _ []string) map[string]map[string]interface{} {
	m := make(map[string]map[string]interface{}, len(e.searchChunks))
	for i, c := range e.searchChunks {
		m["rerankspy-chunk-"+string(rune('0'+i))] = c
	}
	return m
}

func (e *rerankSpyEngine) CreateChunkStore(context.Context, string, string, int, string) error {
	return nil
}
func (e *rerankSpyEngine) InsertChunks(_ context.Context, _ []map[string]interface{}, _, _ string) ([]string, error) {
	return nil, nil
}
func (e *rerankSpyEngine) UpdateChunks(context.Context, map[string]interface{}, map[string]interface{}, string, string) error {
	return nil
}
func (e *rerankSpyEngine) DeleteChunks(context.Context, map[string]interface{}, string, string) (int64, error) {
	return 0, nil
}
func (e *rerankSpyEngine) GetChunk(context.Context, string, string, []string) (interface{}, error) {
	return nil, nil
}
func (e *rerankSpyEngine) DropChunkStore(context.Context, string, string) error { return nil }
func (e *rerankSpyEngine) ChunkStoreExists(context.Context, string, string) (bool, error) {
	return true, nil
}
func (e *rerankSpyEngine) CreateMetadataStore(context.Context, string) error { return nil }
func (e *rerankSpyEngine) InsertMetadata(_ context.Context, _ []map[string]interface{}, _ string) ([]string, error) {
	return nil, nil
}
func (e *rerankSpyEngine) UpdateMetadata(context.Context, string, string, map[string]interface{}, string) error {
	return nil
}
func (e *rerankSpyEngine) DeleteMetadata(context.Context, map[string]interface{}, string) (int64, error) {
	return 0, nil
}
func (e *rerankSpyEngine) DeleteMetadataKeys(context.Context, string, string, []string, string) error {
	return nil
}
func (e *rerankSpyEngine) DropMetadataStore(context.Context, string) error { return nil }
func (e *rerankSpyEngine) MetadataStoreExists(context.Context, string) (bool, error) {
	return true, nil
}
func (e *rerankSpyEngine) SearchMetadata(_ context.Context, _ *enginetypes.SearchMetadataRequest) (*enginetypes.SearchMetadataResult, error) {
	return nil, nil
}
func (e *rerankSpyEngine) IndexDocument(context.Context, string, string, interface{}) error {
	return nil
}
func (e *rerankSpyEngine) DeleteDocument(context.Context, string, string) error { return nil }
func (e *rerankSpyEngine) BulkIndex(context.Context, string, []interface{}) (interface{}, error) {
	return nil, nil
}
func (e *rerankSpyEngine) GetAggregation([]map[string]interface{}, string) []map[string]interface{} {
	return nil
}
func (e *rerankSpyEngine) GetHighlight([]map[string]interface{}, []string, string) map[string]string {
	return nil
}
func (e *rerankSpyEngine) RunSQL(context.Context, string, string, []string, string) ([]map[string]interface{}, error) {
	return nil, nil
}
func (e *rerankSpyEngine) Ping(context.Context) error { return nil }
func (e *rerankSpyEngine) Close() error               { return nil }
func (e *rerankSpyEngine) SupportsPageRank() bool     { return false }
func (e *rerankSpyEngine) FilterDocIdsByMetaPushdown(_ context.Context, _ *gorm.DB, _ []string, _ []map[string]interface{}, _ string) []string {
	return nil
}

// TestVerifyOceanBaseRetrievalRerank runs one keyword-only retrieval per
// engine type and checks whether the Elasticsearch second-pass KNN call was
// made.
func TestVerifyOceanBaseRetrievalRerank(t *testing.T) {
	// Search() parses the question through the global query builder when no
	// embedding model is set. InitQueryBuilder is guarded by sync.Once and
	// accepts an empty wordnet dir.
	_ = InitQueryBuilder("")

	cases := []struct {
		engineType string
		wantKNN    bool
	}{
		{engineType: "oceanbase", wantKNN: false},
		{engineType: "seekdb", wantKNN: false},
		{engineType: "elasticsearch", wantKNN: true},
	}

	for _, tc := range cases {
		t.Run(tc.engineType, func(t *testing.T) {
			engine.SetEngineTypeForVerify(tc.engineType)
			t.Cleanup(func() { engine.SetEngineTypeForVerify("") })

			// q_3_vec matches a 3-dim query vector. No "doc_id", so pruning
			// exits before any database call.
			spy := &rerankSpyEngine{
				engineTypeName: tc.engineType,
				searchChunks: []map[string]interface{}{{
					"content_ltks": "oceanbase test chunk",
					"q_3_vec":      []float64{0.1, 0.2, 0.3},
				}},
			}
			svc := NewRetrievalService(spy, dao.NewDocumentDAO())

			one := 1
			thresh := 0.0
			vsw := 0.5
			agg := false
			rankFea := map[string]float64{}
			req := &RetrievalRequest{
				Question:               "test oceanbase routing",
				TenantIDs:              []string{"t1"},
				KbIDs:                  []string{"kb1"},
				Page:                   1,
				PageSize:               1,
				Top:                    &one,
				SimilarityThreshold:    &thresh,
				VectorSimilarityWeight: &vsw,
				RankFeature:            &rankFea,
				Aggs:                   &agg,
			}

			if _, err := svc.Retrieval(context.Background(), req); err != nil {
				t.Fatalf("Retrieval() error = %v", err)
			}
			if spy.knnScoresCalled != tc.wantKNN {
				t.Errorf("engine %q: KNNScores called = %t, want %t", tc.engineType, spy.knnScoresCalled, tc.wantKNN)
			}
		})
	}
}
