// Copyright 2026 The InfiniFlow Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Contract checked here: deleting some or all of a document's metadata hands
// the document engine a usable context. A SQL engine runs these deletes
// through database/sql, and database/sql panics on a nil context, so the stub
// below refuses a nil one the same way. The test also checks that each delete
// reaches the engine once, scoped to the right document, dataset and tenant.

package document

import (
	"context"
	"errors"
	"reflect"
	"testing"

	"github.com/glebarez/sqlite"
	"gorm.io/gorm"

	"ragflow/internal/dao"
	"ragflow/internal/entity"
	"ragflow/internal/service"
)

// docMetaCtxEngine embeds the package's no-op engine stub and records the two
// metadata delete calls.
type docMetaCtxEngine struct {
	fakeChatDocEngine

	keysCalls  int
	keysNilCtx bool
	keysDocID  string
	keysKbID   string
	keysList   []string
	keysTenant string

	allCalls  int
	allNilCtx bool
	allCond   map[string]interface{}
	allTenant string
}

func (e *docMetaCtxEngine) GetType() string { return "oceanbase" }

func (e *docMetaCtxEngine) DeleteMetadataKeys(ctx context.Context, docID, kbID string, keys []string, tenantID string) error {
	e.keysCalls++
	e.keysDocID, e.keysKbID, e.keysList, e.keysTenant = docID, kbID, keys, tenantID
	if ctx == nil {
		e.keysNilCtx = true
		return errors.New("nil context passed to the document engine")
	}
	return ctx.Err()
}

func (e *docMetaCtxEngine) DeleteMetadata(ctx context.Context, condition map[string]interface{}, tenantID string) (int64, error) {
	e.allCalls++
	e.allCond, e.allTenant = condition, tenantID
	if ctx == nil {
		e.allNilCtx = true
		return 0, errors.New("nil context passed to the document engine")
	}
	return 1, ctx.Err()
}

// docMetaCtxStore swaps in an in-memory store holding one dataset and one
// document, and restores the global handle on cleanup.
func docMetaCtxStore(t *testing.T) {
	t.Helper()

	db, err := gorm.Open(sqlite.Open(":memory:"), &gorm.Config{TranslateError: true})
	if err != nil {
		t.Fatalf("open in-memory store: %v", err)
	}
	if err := db.AutoMigrate(&entity.Knowledgebase{}, &entity.Document{}); err != nil {
		t.Fatalf("migrate: %v", err)
	}
	original := dao.DB
	dao.DB = db
	t.Cleanup(func() { dao.DB = original })

	valid := string(entity.StatusValid)
	if err := db.Create(&entity.Knowledgebase{
		ID:         "kb-meta-1",
		TenantID:   "tenant-meta-1",
		Name:       "metadata kb",
		EmbdID:     "embd-1",
		CreatedBy:  "user-1",
		Permission: string(entity.TenantPermissionMe),
		Status:     &valid,
	}).Error; err != nil {
		t.Fatalf("seed dataset: %v", err)
	}
	if err := db.Create(&entity.Document{
		ID:           "doc-meta-1",
		KbID:         "kb-meta-1",
		ParserID:     "naive",
		ParserConfig: entity.JSONMap{},
		SourceType:   "local",
		Type:         "pdf",
		CreatedBy:    "user-1",
		Suffix:       "pdf",
	}).Error; err != nil {
		t.Fatalf("seed document: %v", err)
	}
}

func docMetaCtxService(stub *docMetaCtxEngine) *DocumentService {
	return &DocumentService{
		documentDAO: dao.NewDocumentDAO(),
		metadataSvc: service.NewMetadataServiceForTest(dao.NewKnowledgebaseDAO(), stub),
		docEngine:   stub,
	}
}

func TestVerifyDocumentMetadataDeletesReachEngine(t *testing.T) {
	t.Run("delete_keys", func(t *testing.T) {
		docMetaCtxStore(t)
		stub := &docMetaCtxEngine{}
		svc := docMetaCtxService(stub)

		if err := svc.DeleteDocumentMetadata(context.Background(), "doc-meta-1", []string{"author"}); err != nil {
			t.Fatalf("DeleteDocumentMetadata() error = %v", err)
		}
		if stub.keysCalls != 1 {
			t.Fatalf("engine key-delete calls = %d, want 1", stub.keysCalls)
		}
		if stub.keysNilCtx {
			t.Fatalf("engine key-delete received a nil context")
		}
		if stub.keysDocID != "doc-meta-1" || stub.keysKbID != "kb-meta-1" || stub.keysTenant != "tenant-meta-1" {
			t.Fatalf("engine key-delete scope = (doc %q, kb %q, tenant %q), want (doc-meta-1, kb-meta-1, tenant-meta-1)",
				stub.keysDocID, stub.keysKbID, stub.keysTenant)
		}
		if !reflect.DeepEqual(stub.keysList, []string{"author"}) {
			t.Fatalf("engine key-delete keys = %v, want [author]", stub.keysList)
		}
	})

	t.Run("delete_all", func(t *testing.T) {
		docMetaCtxStore(t)
		stub := &docMetaCtxEngine{}
		svc := docMetaCtxService(stub)

		if err := svc.DeleteDocumentAllMetadata(context.Background(), "doc-meta-1"); err != nil {
			t.Fatalf("DeleteDocumentAllMetadata() error = %v", err)
		}
		if stub.allCalls != 1 {
			t.Fatalf("engine metadata-delete calls = %d, want 1", stub.allCalls)
		}
		if stub.allNilCtx {
			t.Fatalf("engine metadata-delete received a nil context")
		}
		if stub.allTenant != "tenant-meta-1" {
			t.Fatalf("engine metadata-delete tenant = %q, want tenant-meta-1", stub.allTenant)
		}
		targetsDoc := false
		for _, v := range stub.allCond {
			if v == "doc-meta-1" {
				targetsDoc = true
			}
		}
		if !targetsDoc {
			t.Fatalf("engine metadata-delete condition = %#v, want it scoped to doc-meta-1", stub.allCond)
		}
	})
}
