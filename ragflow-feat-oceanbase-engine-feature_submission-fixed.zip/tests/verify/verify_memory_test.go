//
//  Copyright 2026 The InfiniFlow Authors. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

// Contract checked here: MemoryService.ForgetMessage builds the update it hands
// to the document engine, and the companion fields in it depend on the engine.
// The message table the Python OceanBase connector creates has a forget_at
// column and no forget_at_flt column, so for oceanbase and seekdb the update
// carries forget_at only. Elasticsearch and Infinity keep the numeric
// forget_at_flt field. Every engine gets the same target document and scope.
// Names in this file are prefixed so they stay apart from the package suite.

package service

import (
	"context"
	"testing"

	"github.com/glebarez/sqlite"
	"gorm.io/gorm"

	"ragflow/internal/dao"
	"ragflow/internal/entity"
)

// companionRecorder is a storage backend stub whose reported type is
// configurable and which captures the single update ForgetMessage issues. It
// embeds the package's full backend stub so it satisfies the storage interface
// regardless of methods unrelated to this behavior.
type companionRecorder struct {
	fakeChatDocEngine
	reportedType string
	updateValue  map[string]interface{}
	updateCond   map[string]interface{}
	updateBase   string
	updateID     string
}

func (r *companionRecorder) GetType() string { return r.reportedType }

func (r *companionRecorder) UpdateChunks(_ context.Context, condition, newValue map[string]interface{}, baseName, datasetID string) error {
	r.updateCond = condition
	r.updateValue = newValue
	r.updateBase = baseName
	r.updateID = datasetID
	return nil
}

// companionMemoryStore stands up an isolated in-memory relational store with
// just the memory table, seeds one owner-scoped memory, and restores the global
// handle on cleanup.
func companionMemoryStore(t *testing.T) {
	t.Helper()

	db, err := gorm.Open(sqlite.Open(":memory:"), &gorm.Config{TranslateError: true})
	if err != nil {
		t.Fatalf("open in-memory store: %v", err)
	}
	if err := db.AutoMigrate(&entity.Memory{}); err != nil {
		t.Fatalf("migrate memory table: %v", err)
	}

	original := dao.DB
	dao.DB = db
	t.Cleanup(func() { dao.DB = original })

	if err := db.Create(&entity.Memory{
		ID:          "memory-1",
		Name:        "Companion field memory",
		TenantID:    "user-1",
		MemoryType:  dao.MemoryTypeRaw,
		StorageType: "table",
		EmbdID:      "embd",
		LLMID:       "llm",
		Permissions: string(entity.TenantPermissionMe),
		MemorySize:  MemorySizeLimit,
	}).Error; err != nil {
		t.Fatalf("seed memory: %v", err)
	}
}

func TestVerifyForgetMessageCompanionFieldByEngineFamily(t *testing.T) {
	t.Setenv("ES_INDEX_PREFIX", "")

	cases := []struct {
		engineType    string
		wantCompanion bool
	}{
		{engineType: "elasticsearch", wantCompanion: true},
		{engineType: "infinity", wantCompanion: true},
		{engineType: "oceanbase", wantCompanion: false},
		{engineType: "seekdb", wantCompanion: false},
	}

	for _, tc := range cases {
		t.Run(tc.engineType, func(t *testing.T) {
			companionMemoryStore(t)

			recorder := &companionRecorder{reportedType: tc.engineType}
			service := NewMemoryService()
			service.docEngine = recorder

			if err := service.ForgetMessage(context.Background(), "user-1", "memory-1", 42); err != nil {
				t.Fatalf("ForgetMessage() error = %v", err)
			}

			// The forget update must target the owner's memory message document
			// regardless of engine family.
			if recorder.updateCond["id"] != "memory-1_42" {
				t.Fatalf("update condition = %#v, want id=memory-1_42", recorder.updateCond)
			}
			if recorder.updateBase != "memory_user-1" {
				t.Fatalf("update base = %q, want memory_user-1", recorder.updateBase)
			}
			if recorder.updateID != "memory-1" {
				t.Fatalf("update scope = %q, want memory-1", recorder.updateID)
			}

			// The human-readable forget timestamp is always written.
			if forgetAt, ok := recorder.updateValue["forget_at"].(string); !ok || forgetAt == "" {
				t.Fatalf("forget_at = %#v, want non-empty string", recorder.updateValue["forget_at"])
			}

			// The numeric companion timestamp is written only for engines whose
			// message schema carries that column.
			_, hasCompanion := recorder.updateValue["forget_at_flt"]
			if hasCompanion != tc.wantCompanion {
				t.Fatalf("forget_at_flt present = %t, want %t", hasCompanion, tc.wantCompanion)
			}
		})
	}
}
