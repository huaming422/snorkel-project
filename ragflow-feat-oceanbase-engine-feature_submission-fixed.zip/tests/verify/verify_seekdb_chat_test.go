// Copyright 2026 The InfiniFlow Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Contract checked here: the SQL chat flow passes docEngine.GetType() straight
// into its prompt builders. OceanBase and SeekDB share one SQL dialect and
// one JSON-backed chunk table layout, so for the same table, question and
// fields a "seekdb" engine gets exactly what "oceanbase" gets: the generation
// prompts, the row-count shortcut and both repair prompts. None of these may
// fall back to the Elasticsearch column template.

package service

import (
	"testing"
)

func TestVerifySeekDBChatPathWiring(t *testing.T) {
	const table = "ragflow_doc_t1"
	fieldMap := map[string]interface{}{
		"chunk_data": nil,
		"kb_id":      nil,
	}

	// Generation prompts, including the row-count shortcut.
	for _, question := range []string{"show me the data", "how many rows are in the dataset"} {
		seekSys, seekUser, seekOverride := buildSQLPrompts("seekdb", table, question, fieldMap)
		obSys, obUser, obOverride := buildSQLPrompts("oceanbase", table, question, fieldMap)
		esSys, _, _ := buildSQLPrompts("elasticsearch", table, question, fieldMap)

		if seekSys != obSys {
			t.Errorf("question %q: seekdb system prompt differs from oceanbase.\nseekdb:    %q\noceanbase: %q",
				question, seekdbChatTruncate(seekSys, 120), seekdbChatTruncate(obSys, 120))
		}
		if seekUser != obUser {
			t.Errorf("question %q: seekdb user prompt differs from oceanbase.\nseekdb:    %q\noceanbase: %q",
				question, seekdbChatTruncate(seekUser, 120), seekdbChatTruncate(obUser, 120))
		}
		if seekOverride != obOverride {
			t.Errorf("question %q: seekdb row-count override = %q, oceanbase = %q", question, seekOverride, obOverride)
		}
		if seekSys == esSys {
			t.Errorf("question %q: seekdb got the Elasticsearch system prompt", question)
		}
	}

	// Repair prompts used after a bad first SQL attempt.
	col := expectedDocNameColumn("seekdb")
	if obCol := expectedDocNameColumn("oceanbase"); col != obCol {
		t.Errorf("doc name column for seekdb = %q, oceanbase = %q", col, obCol)
	}

	question := "list the rows"
	prevSQL := "SELECT kb_id FROM " + table
	seekMissing := buildMissingColumnsRepairPrompt("seekdb", table, question, prevSQL, col, fieldMap)
	obMissing := buildMissingColumnsRepairPrompt("oceanbase", table, question, prevSQL, col, fieldMap)
	esMissing := buildMissingColumnsRepairPrompt("elasticsearch", table, question, prevSQL, col, fieldMap)
	if seekMissing != obMissing {
		t.Errorf("missing-columns repair prompt for seekdb differs from oceanbase.\nseekdb:    %q\noceanbase: %q",
			seekdbChatTruncate(seekMissing, 120), seekdbChatTruncate(obMissing, 120))
	}
	if seekMissing == esMissing {
		t.Errorf("missing-columns repair prompt for seekdb is the Elasticsearch one")
	}

	errMsg := "Unknown column 'docnm_kwd'"
	seekExec := buildExecutionErrorRepairPrompt("seekdb", table, question, errMsg, fieldMap)
	obExec := buildExecutionErrorRepairPrompt("oceanbase", table, question, errMsg, fieldMap)
	esExec := buildExecutionErrorRepairPrompt("elasticsearch", table, question, errMsg, fieldMap)
	if seekExec != obExec {
		t.Errorf("execution-error repair prompt for seekdb differs from oceanbase.\nseekdb:    %q\noceanbase: %q",
			seekdbChatTruncate(seekExec, 120), seekdbChatTruncate(obExec, 120))
	}
	if seekExec == esExec {
		t.Errorf("execution-error repair prompt for seekdb is the Elasticsearch one")
	}
}

// seekdbChatTruncate shortens long prompts in failure output. The prefix keeps
// it apart from the package's own truncate helper.
func seekdbChatTruncate(s string, maxLen int) string {
	if len(s) <= maxLen {
		return s
	}
	return s[:maxLen] + "..."
}
