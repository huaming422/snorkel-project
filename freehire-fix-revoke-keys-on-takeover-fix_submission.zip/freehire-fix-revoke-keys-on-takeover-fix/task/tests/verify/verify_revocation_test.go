//go:build integration

// Checks for the account-takeback credential story: a key the previous holder
// made before a takeback (an OAuth seizure of an unverified account, or a
// mailed-code password reset) must stop working afterward, while an ordinary
// sign-out-everywhere must leave keys working. Each check drives the real
// account repository against a live Postgres (one cloned database per test via
// the testdb harness) and reads liveness back through the pre-existing
// key-authentication query, so it holds for any fix that takes keys away on a
// takeback — a single data-modifying statement, an explicit transaction, or a
// repository-layer step around the existing query — and does not care how the
// key stops authenticating (removed, expired, or otherwise).
//
// Run with: go test -tags=integration ./internal/accounts/
package accounts_test

import (
	"context"
	"errors"
	"testing"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/strelov1/freehire/internal/accounts"
	"github.com/strelov1/freehire/internal/db"
	"github.com/strelov1/freehire/internal/testdb"
)

// chkPool hands this check its own migrated database, independent of any sibling
// helper in the package.
func chkPool(t *testing.T) *pgxpool.Pool {
	t.Helper()
	return testdb.Pool(t)
}

// chkRepo builds the real account repository over the test pool — the same type
// the OAuth and recovery flows drive in production.
func chkRepo(pool *pgxpool.Pool) *accounts.QueriesRepository {
	return accounts.NewQueriesRepository(db.New(pool), pool)
}

// chkSeedUser inserts an account with an explicit verified state and returns its
// id. Done by hand rather than through a sign-up path so the check controls the
// starting state exactly.
func chkSeedUser(t *testing.T, pool *pgxpool.Pool, email string, verified bool) int64 {
	t.Helper()
	var id int64
	if err := pool.QueryRow(context.Background(),
		`INSERT INTO users (email, password_hash, email_verified) VALUES ($1, 'seeded-hash', $2) RETURNING id`,
		email, verified).Scan(&id); err != nil {
		t.Fatalf("seed account %s: %v", email, err)
	}
	return id
}

// chkSeedKey stores a never-expiring, full-scope key row directly for the user,
// as a holder would already have one on record. Seeding the row rather than
// going through the create path keeps this independent of how a key is minted.
func chkSeedKey(t *testing.T, pool *pgxpool.Pool, userID int64, hash string) {
	t.Helper()
	if _, err := pool.Exec(context.Background(),
		`INSERT INTO api_keys (user_id, name, token_hash, token_prefix, scope, expires_at)
		 VALUES ($1, 'seeded key', $2, 'fh_chk', 'full', NULL)`,
		userID, hash); err != nil {
		t.Fatalf("seed api key for %d: %v", userID, err)
	}
}

// chkKeyAuthenticates reports whether the key with this hash still authenticates,
// read through the pre-existing key-authentication query. A key that was removed
// or has otherwise stopped being valid resolves to no row.
func chkKeyAuthenticates(t *testing.T, q *db.Queries, hash string) bool {
	t.Helper()
	_, err := q.AuthenticateAPIKey(context.Background(), hash)
	if err == nil {
		return true
	}
	if errors.Is(err, pgx.ErrNoRows) {
		return false
	}
	t.Fatalf("authenticate key: %v", err)
	return false
}

// TestVerifySeizureRevokesTheHoldersAPIKey covers keys_revoked_on_seizure
// (fail_to_pass): a key that authenticates before an unverified account is seized
// must no longer authenticate once the proven owner takes it over.
func TestVerifySeizureRevokesTheHoldersAPIKey(t *testing.T) {
	pool := chkPool(t)
	ctx := context.Background()
	repo := chkRepo(pool)
	q := db.New(pool)

	const email = "chk-seize@example.test"
	const hash = "chk-seize-key-hash"
	// The previous holder registered the address but never proved it, and holds a key.
	userID := chkSeedUser(t, pool, email, false)
	chkSeedKey(t, pool, userID, hash)

	if !chkKeyAuthenticates(t, q, hash) {
		t.Fatal("seeded key did not authenticate before the seizure — setup is wrong")
	}

	// The proven owner arrives with a provider-verified identity, seizing the account.
	if _, err := repo.LinkOrCreateByEmail(ctx, "google", "google-chk-seize", email); err != nil {
		t.Fatalf("seize via LinkOrCreateByEmail: %v", err)
	}

	if chkKeyAuthenticates(t, q, hash) {
		t.Error("the key still authenticates after the seizure: the previous holder keeps bearer access to an account they lost the password and sessions to")
	}
}

// TestVerifyPasswordResetRevokesTheAccountsAPIKey covers keys_revoked_on_reset
// (fail_to_pass): a key that authenticates before a password reset must no longer
// authenticate afterward.
func TestVerifyPasswordResetRevokesTheAccountsAPIKey(t *testing.T) {
	pool := chkPool(t)
	ctx := context.Background()
	repo := chkRepo(pool)
	q := db.New(pool)

	const email = "chk-reset@example.test"
	const hash = "chk-reset-key-hash"
	// An owner recovering the account; whoever knew the old password may have a key.
	userID := chkSeedUser(t, pool, email, true)
	chkSeedKey(t, pool, userID, hash)

	if !chkKeyAuthenticates(t, q, hash) {
		t.Fatal("seeded key did not authenticate before the reset — setup is wrong")
	}

	if _, err := repo.ResetPassword(ctx, userID, "fresh-hash"); err != nil {
		t.Fatalf("reset password: %v", err)
	}

	if chkKeyAuthenticates(t, q, hash) {
		t.Error("the key still authenticates after the password reset: whoever held the old password keeps programmatic access after recovery")
	}
}

// TestVerifySeizureIsScopedToTheSeizedAccount covers revocation_scoped_to_account
// (fail_to_pass): seizing one account must take away its own key and leave a
// different account's key working.
func TestVerifySeizureIsScopedToTheSeizedAccount(t *testing.T) {
	pool := chkPool(t)
	ctx := context.Background()
	repo := chkRepo(pool)
	q := db.New(pool)

	const seizedEmail = "chk-scope-seized@example.test"
	const bystanderEmail = "chk-scope-bystander@example.test"
	const seizedHash = "chk-scope-doomed-hash"
	const bystanderHash = "chk-scope-innocent-hash"

	seizedID := chkSeedUser(t, pool, seizedEmail, false)
	bystanderID := chkSeedUser(t, pool, bystanderEmail, true)
	chkSeedKey(t, pool, seizedID, seizedHash)
	chkSeedKey(t, pool, bystanderID, bystanderHash)

	if !chkKeyAuthenticates(t, q, seizedHash) || !chkKeyAuthenticates(t, q, bystanderHash) {
		t.Fatal("seeded keys did not both authenticate before the seizure — setup is wrong")
	}

	if _, err := repo.LinkOrCreateByEmail(ctx, "google", "google-chk-scope", seizedEmail); err != nil {
		t.Fatalf("seize via LinkOrCreateByEmail: %v", err)
	}

	if chkKeyAuthenticates(t, q, seizedHash) {
		t.Error("the seized account's key still authenticates after its seizure")
	}
	if !chkKeyAuthenticates(t, q, bystanderHash) {
		t.Error("a bystander account's key stopped authenticating: the revocation is not scoped to the seized account")
	}
}

// TestVerifyOrdinarySessionRevocationKeepsAPIKeys covers
// keys_survive_ordinary_session_revocation (pass_to_pass): an ordinary
// sign-out-everywhere (a token-version bump with no takeback) must leave the
// account's keys authenticating. This is the guard against the tempting wrong fix
// of making key authentication depend on the session generation — that fix would
// make keys die on every ordinary revocation and fail here.
func TestVerifyOrdinarySessionRevocationKeepsAPIKeys(t *testing.T) {
	pool := chkPool(t)
	ctx := context.Background()
	q := db.New(pool)

	const email = "chk-session@example.test"
	const hash = "chk-session-key-hash"
	userID := chkSeedUser(t, pool, email, true)
	chkSeedKey(t, pool, userID, hash)

	if !chkKeyAuthenticates(t, q, hash) {
		t.Fatal("seeded key did not authenticate before the bump — setup is wrong")
	}

	// An ordinary "sign out everywhere": advance the session generation only.
	if _, err := q.BumpUserTokenVersion(ctx, userID); err != nil {
		t.Fatalf("bump token version: %v", err)
	}

	if !chkKeyAuthenticates(t, q, hash) {
		t.Error("the key stopped authenticating after an ordinary session revocation: a long-lived key must outlast a sign-out-everywhere")
	}
}

// TestVerifySelfServicePasswordChangeKeepsAPIKeys covers
// keys_survive_self_service_password_change (pass_to_pass): when the account's
// own holder changes a password they already know — a routine rotation, not a
// takeback — the account's own sessions are revoked but its API keys must keep
// working. Only a takeback (an unverified-account seizure or a mailed-code reset)
// takes keys away. This is the guard against the over-broad wrong fix of revoking
// keys at every session-revoking credential operation — folding the deletion into
// a shared "revoke sessions" step, or adding it to the known-password change —
// which would strand a user's own long-lived integrations on an everyday password
// rotation. A fix that revokes keys only on the takeback paths leaves this check
// green; one that over-revokes on an ordinary password change fails it. It drives
// the same account repository the known-password-change flow uses in production
// and reads liveness back through the pre-existing key-authentication query, so it
// holds for any fix regardless of how or where the takeback revocation is wired.
func TestVerifySelfServicePasswordChangeKeepsAPIKeys(t *testing.T) {
	pool := chkPool(t)
	ctx := context.Background()
	repo := chkRepo(pool)
	q := db.New(pool)

	const email = "chk-pwchange@example.test"
	const hash = "chk-pwchange-key-hash"
	userID := chkSeedUser(t, pool, email, true)
	chkSeedKey(t, pool, userID, hash)

	if !chkKeyAuthenticates(t, q, hash) {
		t.Fatal("seeded key did not authenticate before the password change — setup is wrong")
	}

	// The account's own holder rotates a password they already know — the known-
	// password change path, which revokes the account's sessions but is not a takeback.
	if _, err := repo.SetPassword(ctx, userID, "chk-pwchange-fresh-hash"); err != nil {
		t.Fatalf("change password: %v", err)
	}

	if !chkKeyAuthenticates(t, q, hash) {
		t.Error("the key stopped authenticating after a routine password change: a self-service password rotation revokes the account's sessions but must leave its own long-lived keys working — only a takeback (seizure/reset) revokes keys")
	}
}
