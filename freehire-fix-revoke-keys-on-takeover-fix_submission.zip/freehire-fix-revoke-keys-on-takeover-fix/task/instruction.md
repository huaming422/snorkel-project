## Task

account takebacks are broken, and it's a security hole.

freehire lets an operator take back an account that someone registered against an email they don't own (a seizure). a seizure clears the account's password and kills its active login sessions, so the previous holder should be locked out. an ordinary password reset should do the same.

it doesn't. after a seizure, and after a password reset, the previous holder can still get in: an API key they made earlier keeps authenticating. it still works on routes that accept an API key or a session, so they go on reading the account's data (inbox, individual emails) even though the password was wiped and sessions revoked. the one credential the takeback was meant to kill is the one that survives.

a related hole: an account whose email was never verified can still create one of these keys.

figure out why a seized or reset account's old API key still works, and fix it so a takeback or password reset stops every credential the previous holder was issued, API keys included.
