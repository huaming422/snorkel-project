## Task

We're getting reports that some popups land in the wrong place. When a component is told
to render its popup into a custom container that's an ancestor or a later sibling of the
popup, and the popup is open from the start or kept mounted, the popup shows up at the top
of the page (in the document body, or the nearest parent portal) instead of inside the
container the app asked for, and it stays stuck there.

It only goes wrong when that container isn't on the page yet at the moment the popup first
goes looking for it. Pass a container that's already attached, or a plain DOM node, and
everything lands where it should. We've seen it across Dialog, AlertDialog,
Drawer, Menu, Tooltip, PreviewCard, Popover, Select, and Toast, whenever a custom
container is in play.

Dig in and make these popups render inside the container the app points them at. The cases
that place correctly today, no custom container, a container that's already attached, a
direct DOM node, are fine as they are and shouldn't change.
