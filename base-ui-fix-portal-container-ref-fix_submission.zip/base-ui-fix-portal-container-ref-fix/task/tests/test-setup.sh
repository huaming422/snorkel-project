#!/usr/bin/env bash
# tests/test-setup.sh — prepare the base-ui workspace so the TypeScript
# verifier (vitest, jsdom) can run. Sourced by the harbor runner, so env vars
# set here stay live for the verifier subprocess.
#
# The image build already ran `pnpm install --frozen-lockfile` against the
# pre-fetched store, so node_modules is warm. `@base-ui/react` and
# `@base-ui/utils` resolve their subpath exports straight to `src/*` (see
# packages/react/package.json "exports": e.g. "./menu": "./src/menu/index.ts"),
# so the agent's src/ edits are picked up with no build step. The checks below
# are fast no-ops in normal operation and only do work if an agent edit wiped
# node_modules.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/base-ui}"
export REPO_DIR
cd "$REPO_DIR"

# The verifier must run in jsdom; the real suite selects it via VITEST_ENV.
export VITEST_ENV=jsdom
export TZ=UTC

# The harbor JS runner parses verify.toml under the canonical verifier venv
# (/opt/tooling/venv, Python 3.12) whose tomllib is built in — no extra install.

# Sanity: vitest must be resolvable from the workspace root. A missing binary
# means the image's node_modules was damaged by an agent edit; replay the
# offline install from the warm store (network-free) to restore it.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest missing from node_modules/.bin; replaying offline install." >&2
    pnpm install --frozen-lockfile --offline >/tmp/test-setup-install.log 2>&1 \
        || { tail -40 /tmp/test-setup-install.log >&2; exit 1; }
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR VITEST_ENV=$VITEST_ENV vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
