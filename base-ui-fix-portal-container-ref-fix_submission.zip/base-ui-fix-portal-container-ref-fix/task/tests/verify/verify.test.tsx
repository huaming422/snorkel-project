// @ts-nocheck
// @vitest-environment jsdom
//
// Behavioural verifier for the popup-placement regression.
//
// Everything here is exercised through the library's public surface: the
// `FloatingPortal` / `FloatingPortalLite` components and their `container`
// prop, plus `Menu.Root` / `Menu.Portal` and the public `onOpenChangeComplete`
// callback. We observe DOM placement (which element the popup lands inside) and
// mount counts via a child ref. We deliberately do NOT import or name any of
// the resolution-mechanism internals (a factory, a pending-resolver ref, a
// state counter): those are one valid shape among many.
//
// Placement is asserted through `waitFor` rather than a bare post-render read,
// so the verifier accepts any mechanism that settles the placement before the
// suite's polling window closes — a microtask-batched retry, a timer/animation-
// frame retry, or a plain state bump all qualify. The only hard structural
// requirement is behavioural: the popup must end up inside the intended
// container, must never pass through the page fallback on the way there, and
// must mount its content exactly once.
//
// Why these cases separate a correct fix from the broken state: before the
// fix, a custom container whose ref is still empty when the layer first reads
// it falls back to document.body (or the parent portal) and never revisits the
// decision, so the ancestor/sibling/nesting/replacement/clear cases all land in
// the wrong place and never recover. The empty-ref fallback case and the
// already-attached timing are preserved behaviour and stay green either way.

import { describe, expect, test, vi } from 'vitest';
import * as React from 'react';
import { screen, waitFor } from '@mui/internal-test-utils';
import { useIsoLayoutEffect } from '@base-ui/utils/useIsoLayoutEffect';
import { createRenderer } from '#test-utils';
import { Menu } from '@base-ui/react/menu';
import { FloatingPortal } from './FloatingPortal';
import { FloatingPortalLite } from './FloatingPortalLite';

describe.each([
  { name: 'FloatingPortal', Portal: FloatingPortal },
  { name: 'FloatingPortalLite', Portal: FloatingPortalLite },
])('$name container resolution', ({ Portal }) => {
  const { render: renderPortal } = createRenderer();

  test.each([
    { ancestor: true },
    { ancestor: false },
  ])(
    'resolves a ref attached later in the commit (ancestor=$ancestor)',
    async ({ ancestor }) => {
      const parents = new Set<ParentNode | null>();
      function Test() {
        const container = React.useRef<HTMLDivElement>(null);
        const content = (
          <Portal
            container={container}
            ref={(node) => {
              if (node) {
                parents.add(node.parentNode);
              }
            }}
          >
            <div data-testid="content" />
          </Portal>
        );
        return ancestor ? (
          <div ref={container} data-testid="container">
            {content}
          </div>
        ) : (
          <React.Fragment>
            {content}
            <div ref={container} data-testid="container" />
          </React.Fragment>
        );
      }

      // strict:false — StrictMode effect replay can mask the wrong initial placement.
      await renderPortal(<Test />, { strict: false });

      const container = screen.getByTestId('container');
      // Case 1 & 2: an ancestor or later-sibling ref resolves into that element.
      await waitFor(() => expect(container).toContainElement(screen.getByTestId('content')));
      // Case 3: the popup is never observed in the fallback, even momentarily —
      // the only parent the portal element ever had is the intended container.
      expect(parents).toEqual(new Set([container]));
    },
  );

  test('lands in the final container and mounts once when the ref is replaced', async () => {
    const mounts: boolean[] = [];

    function Child() {
      const node = React.useRef<HTMLDivElement>(null);
      useIsoLayoutEffect(() => {
        mounts.push(node.current?.isConnected ?? false);
      }, []);
      return <div ref={node} data-testid="content" />;
    }

    function Test() {
      const container = React.useRef<HTMLDivElement>(null);
      const [step, setStep] = React.useState(0);

      useIsoLayoutEffect(() => {
        if (step < 2) {
          setStep(step + 1);
        }
      }, [step]);

      const containerId = step < 2 ? 'first' : 'second';
      return (
        <React.Fragment>
          <Portal container={container} data-testid="portal">
            <Child />
          </Portal>
          <div key={containerId} ref={container} data-testid={containerId} />
        </React.Fragment>
      );
    }

    await renderPortal(<Test />, { strict: false });

    // Case 4: content ends up in the final container and the child mounted
    // exactly once, while connected.
    await waitFor(() =>
      expect(screen.getByTestId('portal').parentElement).toBe(screen.getByTestId('second')),
    );
    expect(mounts).toEqual([true]);
  });

  test('mounts deeply nested portals inside their own ancestor refs', async () => {
    function Nested({ remaining }: { remaining: number }) {
      const container = React.useRef<HTMLDivElement>(null);
      return (
        <div ref={container} data-testid="nested-container">
          <Portal container={container} data-testid="nested-portal">
            {remaining > 1 ? <Nested remaining={remaining - 1} /> : <div data-testid="leaf" />}
          </Portal>
        </div>
      );
    }

    await renderPortal(<Nested remaining={18} />, { strict: false });

    // Case 5: every level of a deep nesting lands in its own container.
    await waitFor(() => expect(screen.getByTestId('leaf')).toBeInTheDocument());
    expect(screen.getAllByTestId('nested-portal').map((node) => node.parentElement)).toEqual(
      screen.getAllByTestId('nested-container'),
    );
  });

  test.each([{ nested: false }, { nested: true }])(
    'keeps the default fallback when a ref stays empty (nested=$nested)',
    async ({ nested }) => {
      const container = React.createRef<HTMLDivElement>();
      const content = (
        <Portal container={container} data-testid="portal">
          <div data-testid="content" />
        </Portal>
      );

      await renderPortal(
        nested ? <FloatingPortal data-testid="parent">{content}</FloatingPortal> : content,
      );

      // Case 6 (preserved behaviour): a ref that never attaches keeps the
      // document.body fallback (or the parent portal when nested).
      const fallback = nested ? screen.getByTestId('parent') : document.body;
      await waitFor(() => expect(fallback).toContainElement(screen.getByTestId('content')));
      expect(screen.getByTestId('portal').parentElement).toBe(fallback);
    },
  );

  test.each([{ clear: false }, { clear: true }])(
    'resolves or clears a queued check when the container prop changes (clear=$clear)',
    async ({ clear }) => {
      function Test() {
        const firstContainer = React.useRef<HTMLDivElement>(null);
        const secondContainer = React.useRef<HTMLDivElement>(null);
        const [step, setStep] = React.useState(0);

        useIsoLayoutEffect(() => {
          if (step < 2) {
            setStep(step + 1);
          }
        }, [step]);

        const nextContainer = clear ? null : secondContainer.current;
        return (
          <React.Fragment>
            <Portal container={step < 2 ? firstContainer : nextContainer} data-testid="portal">
              <div data-testid="content" />
            </Portal>
            <div ref={firstContainer} data-testid="first" />
            <div ref={secondContainer} data-testid="second" />
          </React.Fragment>
        );
      }

      await renderPortal(<Test />, { strict: false });

      // Case 7: switching the container away must not drop content into the
      // stale first container; clearing to null leaves nothing placed, while a
      // real second container receives the content.
      await waitFor(() =>
        expect(screen.queryByTestId('portal')?.parentElement ?? null).toBe(
          clear ? null : screen.getByTestId('second'),
        ),
      );
      expect(screen.getByTestId('first')).toBeEmptyDOMElement();
    },
  );
});

describe('Menu with a custom container ref', () => {
  const { render: renderMenu } = createRenderer();

  test.each([
    { controlled: false, keepMounted: false },
    { controlled: true, keepMounted: false },
    { controlled: false, keepMounted: true },
  ])(
    'renders an initially-open menu inside an ancestor ref (controlled=$controlled, keepMounted=$keepMounted)',
    async ({ controlled, keepMounted }) => {
      function Test() {
        const container = React.useRef<HTMLDivElement>(null);
        return (
          <div ref={container} data-testid="container">
            <Menu.Root defaultOpen={!controlled} open={controlled ? true : undefined}>
              <Menu.Trigger>Open menu</Menu.Trigger>
              <Menu.Portal container={container} keepMounted={keepMounted} data-testid="portal">
                <Menu.Positioner>
                  <Menu.Popup>
                    <Menu.Item>Item</Menu.Item>
                  </Menu.Popup>
                </Menu.Positioner>
              </Menu.Portal>
            </Menu.Root>
          </div>
        );
      }

      await renderMenu(<Test />, { strict: false });

      // Case 8a: role="menu" lands inside the ancestor container.
      await waitFor(() =>
        expect(screen.getByTestId('container')).toContainElement(screen.getByRole('menu')),
      );
      await waitFor(() => expect(screen.getByRole('menu')).toHaveFocus());
    },
  );

  test('completes initial opening once when a later update replaces the container ref', async () => {
    const completed = vi.fn();

    function TestMenu() {
      const container = React.useRef<HTMLDivElement>(null);
      const [step, setStep] = React.useState(0);

      useIsoLayoutEffect(() => {
        if (step < 2) {
          setStep(step + 1);
        }
      }, [step]);

      const containerId = step < 2 ? 'first' : 'second';
      return (
        <React.Fragment>
          <Menu.Root defaultOpen onOpenChangeComplete={completed}>
            <Menu.Trigger>Toggle</Menu.Trigger>
            <Menu.Portal container={container}>
              <Menu.Positioner>
                <Menu.Popup>
                  <Menu.Item>Item</Menu.Item>
                </Menu.Popup>
              </Menu.Positioner>
            </Menu.Portal>
          </Menu.Root>
          <div key={containerId} ref={container} data-testid={containerId} />
        </React.Fragment>
      );
    }

    await renderMenu(<TestMenu />, { strict: false });

    // Case 8b: the menu lands in the final container and opening completes
    // exactly once (sibling portals still batch into a single commit).
    await waitFor(() =>
      expect(screen.getByTestId('second')).toContainElement(screen.getByRole('menu')),
    );
    expect(completed).toHaveBeenCalledExactlyOnceWith(true);
  });
});
