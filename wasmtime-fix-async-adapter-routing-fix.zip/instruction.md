## Task

We're seeing crashes and incorrect results in programs that use Wasmtime's async
support for the WebAssembly component model. The failures appear after separate
components are composed: a call passes through a generated adapter, with an
`async`-typed function on one side of the call. Programs whose calls have no
async involvement still run correctly. Please investigate the setup and
execution of these calls, identify the defect, and repair it.
