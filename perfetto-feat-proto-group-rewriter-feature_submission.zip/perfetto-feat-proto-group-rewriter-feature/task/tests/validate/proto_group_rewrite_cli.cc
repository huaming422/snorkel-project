// proto_group_rewrite_cli.cc — reward-owned validation harness (NOT in the
// agent repo). Compiled by validation-setup.sh against the AGENT's public
// contract only:
//
//   #include "src/tracing/service/proto_group_rewriter.h"
//   perfetto::tracing_v2::ProtoGroupRewriter
//   perfetto::tracing_v2::RewriteResult { kRewritten, kUnchanged,
//                                         kMalformedInput, kGroupTooLarge }
//   RewriteResult Rewrite(const Slices& input, std::optional<Slice>* output);
//
// It names NO internal symbol, so EVERY valid implementation links against it.
//
// I/O contract (harness-owned — a pure test fixture the agent never reads or
// defines; stable across all solutions):
//
//   stdin  : line 1 = N (slice count, decimal).
//            next N lines = one slice each, lowercase hex (may be empty for a
//            zero-length slice — though the contract uses non-empty slices,
//            the harness tolerates empties by representing them as "").
//   stdout : line 1 = one of UNCHANGED | REWRITTEN | MALFORMED | TOO_LARGE
//            line 2 = for REWRITTEN only, the rewritten output bytes as
//                     lowercase hex (empty line if zero-length). For
//                     UNCHANGED/MALFORMED/TOO_LARGE no second line is written
//                     (output is, by contract, unset/untouched).
//   exit   : always 0 on a well-formed invocation; the result is on stdout.
//            exit 2 only on harness misuse (unreadable input / bad hex).

#include "src/tracing/service/proto_group_rewriter.h"

#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <optional>
#include <string>
#include <vector>

#include "perfetto/ext/tracing/core/slice.h"

namespace {

bool HexToBytes(const std::string& hex, std::vector<uint8_t>* out) {
  if (hex.size() % 2 != 0)
    return false;
  out->clear();
  out->reserve(hex.size() / 2);
  auto nibble = [](char c, int* v) -> bool {
    if (c >= '0' && c <= '9') { *v = c - '0'; return true; }
    if (c >= 'a' && c <= 'f') { *v = c - 'a' + 10; return true; }
    if (c >= 'A' && c <= 'F') { *v = c - 'A' + 10; return true; }
    return false;
  };
  for (size_t i = 0; i < hex.size(); i += 2) {
    int hi, lo;
    if (!nibble(hex[i], &hi) || !nibble(hex[i + 1], &lo))
      return false;
    out->push_back(static_cast<uint8_t>((hi << 4) | lo));
  }
  return true;
}

std::string BytesToHex(const uint8_t* data, size_t size) {
  static const char* kHex = "0123456789abcdef";
  std::string s;
  s.reserve(size * 2);
  for (size_t i = 0; i < size; ++i) {
    s.push_back(kHex[data[i] >> 4]);
    s.push_back(kHex[data[i] & 0x0f]);
  }
  return s;
}

}  // namespace

int main() {
  using perfetto::Slice;
  using perfetto::Slices;
  using perfetto::tracing_v2::ProtoGroupRewriter;
  using perfetto::tracing_v2::RewriteResult;

  std::string first;
  if (!std::getline(std::cin, first)) {
    std::fprintf(stderr, "cli: missing slice count on line 1\n");
    return 2;
  }
  // Perfetto compiles with -fno-exceptions, so parse with strtol (no stol/throw).
  errno = 0;
  char* end = nullptr;
  long n = std::strtol(first.c_str(), &end, 10);
  if (end == first.c_str() || *end != '\0' || errno != 0) {
    std::fprintf(stderr, "cli: slice count is not a number: %s\n", first.c_str());
    return 2;
  }
  if (n < 0) {
    std::fprintf(stderr, "cli: negative slice count\n");
    return 2;
  }

  // Own the backing storage for the lifetime of the Rewrite() call; Slice is a
  // (pointer,size) view, so the vectors must outlive |slices|.
  std::vector<std::vector<uint8_t>> storage;
  storage.reserve(static_cast<size_t>(n));
  Slices slices;
  for (long i = 0; i < n; ++i) {
    std::string line;
    if (!std::getline(std::cin, line)) {
      std::fprintf(stderr, "cli: expected %ld slices, got %ld\n", n, i);
      return 2;
    }
    // Strip a trailing CR if the input used CRLF.
    if (!line.empty() && line.back() == '\r')
      line.pop_back();
    std::vector<uint8_t> bytes;
    if (!HexToBytes(line, &bytes)) {
      std::fprintf(stderr, "cli: bad hex on slice %ld: %s\n", i, line.c_str());
      return 2;
    }
    storage.push_back(std::move(bytes));
    slices.emplace_back(storage.back().data(), storage.back().size());
  }

  ProtoGroupRewriter rewriter;
  std::optional<Slice> output;
  RewriteResult result = rewriter.Rewrite(slices, &output);

  switch (result) {
    case RewriteResult::kUnchanged:
      std::printf("UNCHANGED\n");
      break;
    case RewriteResult::kRewritten: {
      std::printf("REWRITTEN\n");
      const uint8_t* data =
          output.has_value() ? static_cast<const uint8_t*>(output->start)
                             : nullptr;
      size_t size = output.has_value() ? output->size : 0;
      std::string hex = BytesToHex(data, size);
      std::printf("%s\n", hex.c_str());
      break;
    }
    case RewriteResult::kMalformedInput:
      std::printf("MALFORMED\n");
      break;
    case RewriteResult::kGroupTooLarge:
      std::printf("TOO_LARGE\n");
      break;
  }
  return 0;
}
