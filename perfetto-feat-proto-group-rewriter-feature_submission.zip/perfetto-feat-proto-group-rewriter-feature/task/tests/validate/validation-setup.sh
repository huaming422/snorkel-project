#!/usr/bin/env bash
# validation-setup.sh — sourced by /tests/test.sh (Stage 4) BEFORE the
# validation agent runs, only when validate/validation_spec.toml is present.
#
# Builds the reward-owned CLI harness (`proto_group_rewrite_cli`) that the
# pytest stories drive. The harness compiles against ONLY the agent's pinned
# public contract (src/tracing/service/proto_group_rewriter.h via the
# `:service` source_set a correct solution wires the rewriter into), so every
# valid implementation links — no coupling to any internal name or GN target
# the agent chose.
#
# HARDENING (REWARDS.md §"Setup hardening standard"):
#   * set -euo pipefail; pin the hermetic toolchain ahead of PATH; echo versions.
#   * build to a FIXED absolute path (PGR_CLI) and export it for the stories.
#   * `test -x` loud-fail guard; end-of-script one-shot smoke invocation.
#   * idempotent (safe to re-source).
#
# EMPTY-SUBMISSION SAFETY: this script is SOURCED under `set -euo pipefail`,
# but test.sh guards the source with `|| true`, so a plain non-zero is
# tolerated. We go further: the recoverable build-failure path uses `return 0`
# (never `exit`), so a submission that does not provide a compilable rewriter
# (e.g. an empty patch) simply leaves NO harness binary. The validation agent then finds
# the CLI missing and every story fails → validation_score = 0.0 (a clean
# zero), NOT an invalidated trial. Only genuine infra defects (missing GN out
# dir, missing harness source) fail loud via `return`/non-zero.
set -euo pipefail

REPO=/repo/perfetto
cd "${REPO}"

OUT=out/dist
CLI_SRC_DIR=src/tracing/service
CLI_SRC_NAME=proto_group_rewrite_cli.cc
BUILD_GN="${CLI_SRC_DIR}/BUILD.gn"
HARNESS_SRC=/tests/validate/${CLI_SRC_NAME}
# Ninja target name for the harness. GN emits a phony alias equal to the
# target name (same mechanism that lets `ninja perfetto_unittests` work). The
# target is defined in src/tracing/service/BUILD.gn — a file GN already loads
# (the service + unittests targets live there) — so GN emits a ninja rule for
# it even though nothing depends on it. A target in an isolated, unreferenced
# directory would never be parsed by `gn gen`.
CLI_NINJA_TARGET="proto_group_rewrite_cli"

# Fixed, absolute path the stories invoke. Exported so the pytest subprocess
# (which inherits test.sh's environment) can read it.
export PGR_CLI="${REPO}/${OUT}/proto_group_rewrite_cli"

# ── Pin the hermetic toolchain ahead of PATH + echo versions ────────────────
# Perfetto ships a hermetic clang/libc++; tools/ninja and tools/gn dispatch to
# the baked buildtools. Put the repo tools dir first so `tools/*` resolves even
# if the agent mutated PATH.
export PATH="${REPO}/tools:${PATH}"
echo "validation-setup: toolchain versions:"
( tools/gn --version 2>&1 | sed 's/^/  gn: /' ) || true
( tools/ninja --version 2>&1 | sed 's/^/  ninja: /' ) || true

# ── Sanity: baked GN out dir (built at image time) — infra invariant ────────
if [ ! -f "${OUT}/args.gn" ]; then
    echo "validation-setup: ${OUT}/args.gn missing — image built incorrectly" >&2
    return 1 2>/dev/null || exit 1
fi
if [ ! -f "${HARNESS_SRC}" ]; then
    echo "validation-setup: harness source ${HARNESS_SRC} missing — asset not shipped" >&2
    return 1 2>/dev/null || exit 1
fi

# ── Stage the harness source into the service dir ───────────────────────────
cp -f "${HARNESS_SRC}" "${CLI_SRC_DIR}/${CLI_SRC_NAME}"

# ── Inject the executable target into src/tracing/service/BUILD.gn ──────────
# This file is already loaded by GN (it defines :service and the unittests
# target), so GN emits a ninja rule for our target even though nothing depends
# on it. A target in a fresh, unreferenced directory would never be parsed.
# Idempotent: marker-guarded. The target depends only on :service (into which
# a correct solution wires the agent's rewriter) + default_deps — no coupling
# to the agent's internal target name. :service's public_deps expose
# ext/tracing/core (slice.h) and ext/base, which the harness includes.
CLI_MARKER="# proto-group-rewrite validation harness (reward-owned, injected by validation-setup.sh)"
if ! grep -qF "${CLI_MARKER}" "${BUILD_GN}"; then
    cat >> "${BUILD_GN}" <<GN

${CLI_MARKER}
executable("proto_group_rewrite_cli") {
  testonly = true
  sources = [ "${CLI_SRC_NAME}" ]
  deps = [
    ":service",
    "../../../gn:default_deps",
  ]
}
GN
    echo "validation-setup: injected harness target into ${BUILD_GN}"
else
    echo "validation-setup: harness target already present (idempotent re-run)"
fi

echo "validation-setup: regenerating GN graph for the harness target..."
if ! tools/gn gen "${OUT}" --args='is_debug=true' > /tmp/val-gn.log 2>&1; then
    echo "validation-setup: gn gen failed (submission may not build):" >&2
    tail -n 120 /tmp/val-gn.log >&2
    echo "validation-setup: continuing with no harness; stories will fail → score 0.0" >&2
    return 0 2>/dev/null || exit 0
fi

# Remove any stale harness so a failed build leaves NO binary.
rm -f "${PGR_CLI}"

echo "validation-setup: building proto_group_rewrite_cli..."
if ! tools/ninja -C "${OUT}" "${CLI_NINJA_TARGET}" > /tmp/val-ninja.log 2>&1; then
    echo "validation-setup: harness build failed (agent rewriter did not compile/link):" >&2
    tail -n 160 /tmp/val-ninja.log >&2
    echo "validation-setup: continuing with no harness; stories will fail → score 0.0" >&2
    return 0 2>/dev/null || exit 0
fi

# ── Loud guard: the binary must exist and be executable ─────────────────────
if [ ! -x "${PGR_CLI}" ]; then
    echo "validation-setup: ${PGR_CLI} missing/non-exec after build" >&2
    echo "validation-setup: continuing with no harness; stories will fail → score 0.0" >&2
    return 0 2>/dev/null || exit 0
fi

# ── End-of-script one-shot smoke: prove the harness runs on a known input ───
# Empty group {0x0b,0x04} → REWRITTEN, output 0a00 (contract's worked example).
# This is a harness liveness check, not a correctness gate; on mismatch we warn
# but still proceed (the stories make the authoritative assertions).
_smoke_out="$(printf '1\n0b04\n' | "${PGR_CLI}" 2>/tmp/val-smoke.err || true)"
if printf '%s' "${_smoke_out}" | head -1 | grep -q '^REWRITTEN$'; then
    echo "validation-setup: harness smoke OK ($(printf '%s' "${_smoke_out}" | tr '\n' ' '))"
else
    echo "validation-setup: harness smoke did not return REWRITTEN (got: $(printf '%s' "${_smoke_out}" | tr '\n' ' ')); stories will adjudicate" >&2
fi

echo "validation-setup: ready — PGR_CLI=${PGR_CLI}"
