## Task

We're bringing up the SMB v2 producer path, and the packets it reassembles use
the proto-group framing: nested messages delimited by a start-group tag and a
bare end byte instead of a length prefix. Everything downstream parses only
standard length-delimited protobuf, so we need a component in the tracing
service that turns one reassembled proto-group packet into the equivalent
length-delimited protobuf on readback.

Build it as a standalone rewriter and wire it into the service's build. Scope
stays there: the rewriter and its GN wiring, not the TraceBufferV2 integration,
loss and gap accounting, or stats plumbing.

The input is one already-reassembled packet, given as an ordered list of
non-empty byte slices (the existing `Slices` / `Slice` types); it can span
several slices. The public shape is fixed, since a C++ caller compiles against
it:

```cpp
// src/tracing/service/proto_group_rewriter.{h,cc}
namespace perfetto::tracing_v2 {

enum class RewriteResult {
  kRewritten,       // *output owns the rewritten packet
  kUnchanged,       // *output left unset; the caller keeps the input slices
  kMalformedInput,  // *output left untouched
  kGroupTooLarge,   // *output left untouched
};

class ProtoGroupRewriter {
 public:
  static constexpr size_t kMaxNestingDepth = 1024;
  RewriteResult Rewrite(const Slices& input, std::optional<Slice>* output);
};

}  // namespace perfetto::tracing_v2
```

The internal design is yours.

## User stories / requirements

- When the service reads back a reassembled packet that uses the proto-group framing, it is converted into the equivalent standard length-delimited packet, so a downstream consumer parses the same fields and values. The conversion is unaffected by how the reassembled packet was split into fragments. A packet that contains no groups is passed through unchanged and the caller keeps the original.
- When a reassembled packet is malformed or structurally invalid, the conversion reports a well-defined failure and produces no output, rather than crashing or handing back a half-converted packet. A genuinely well-formed packet on the same path is still accepted — the rejection is precise, not blanket.
- When a packet nests groups deeper than the supported limit, the conversion rejects it at the defined bound and produces no output; packets nested up to the limit convert normally.
