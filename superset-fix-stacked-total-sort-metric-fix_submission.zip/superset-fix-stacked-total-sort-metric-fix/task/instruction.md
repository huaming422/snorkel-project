## Task

on our stacked time-series bar charts, the total we show on top of each bar is coming out too big. it only goes wrong when the chart is sorted by a metric that isn't one of the bars being displayed. sort by one of the shown metrics, or turn sorting off, and the totals come out right again.

can you dig into the frontend chart behavior and fix it so the total on each bar always matches the sum of the segments actually stacked?
