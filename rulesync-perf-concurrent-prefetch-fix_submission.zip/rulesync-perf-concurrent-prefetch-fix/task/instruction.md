## Task

we're getting reports that `rulesync install` crawls for anyone with a lot of github-hosted sources in their config. a run with a dozen or so sources spends almost all of its wall-clock stuck waiting on the network, working through the sources one after another while the machine otherwise sits idle. can you make install noticeably faster for these multi-source setups?

whatever you change, installing the same config has to keep producing byte-for-byte identical curated files, the same first-declared-source-wins behavior when two sources offer a skill or rule of the same name, and the same lockfile ordering it does today.
