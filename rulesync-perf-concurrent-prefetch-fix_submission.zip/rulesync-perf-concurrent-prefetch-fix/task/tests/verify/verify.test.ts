// @ts-nocheck
//
// Behavioral checks for making `rulesync install` fetch its GitHub-hosted
// sources ahead of the order-sensitive serial pass, measured entirely at the
// public `resolveAndFetchSources` boundary with a fully mocked `GitHubClient`.
// This mirrors how the repo's own `src/lib/sources.test.ts` observes the
// installer, so any shape of the speed-up passes: a subclass client, a wrapper
// client, in-flight sharing folded into `GitHubClient` itself, a different
// bounded-concurrency helper, or differently named internal symbols. Nothing
// here imports a name the change may invent.
//
// The mock stack below is copied from the repo's `src/lib/sources.test.ts`
// setup so the function under test runs with no real network or disk.

import { join } from "node:path";

import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import {
  FETCH_CONCURRENCY_LIMIT,
  RULESYNC_CURATED_RULES_RELATIVE_DIR_PATH,
  RULESYNC_CURATED_SKILLS_RELATIVE_DIR_PATH,
} from "../constants/rulesync-paths.js";
import { createMockLogger } from "../test-utils/mock-logger.js";
import { setupTestDirectory } from "../test-utils/test-directories.js";
import {
  directoryExists,
  fileExists,
  listSubdirectoryNames,
  readFileContent,
  removeDirectoryStrict as removeDirectory,
  removeFileStrict as removeFile,
  writeFileContent,
} from "../utils/file.js";
import { resolveAndFetchSources } from "./sources.js";

let mockClientInstance: any;

vi.mock("./github-client.js", () => ({
  GitHubClient: class MockGitHubClient {
    static resolveToken = vi.fn().mockReturnValue(undefined);

    getDefaultBranch(...args: any[]) {
      return mockClientInstance.getDefaultBranch(...args);
    }
    listDirectory(...args: any[]) {
      return mockClientInstance.listDirectory(...args);
    }
    getFileContent(...args: any[]) {
      return mockClientInstance.getFileContent(...args);
    }
    resolveRefToSha(...args: any[]) {
      return mockClientInstance.resolveRefToSha(...args);
    }
    listExecutablePaths(...args: any[]) {
      return mockClientInstance.listExecutablePaths(...args);
    }
  },
  GitHubClientError: class GitHubClientError extends Error {
    statusCode?: number;
    constructor(message: string, statusCode?: number) {
      super(message);
      this.statusCode = statusCode;
    }
  },
  logGitHubAuthHints: vi.fn(),
}));

vi.mock("../utils/file.js", async (importOriginal) => {
  const actual = await importOriginal<typeof import("../utils/file.js")>();
  const directoryExistsMock = vi.fn();
  return {
    ...actual,
    applyFileMode: vi.fn(),
    directoryExists: directoryExistsMock,
    directoryExistsStrict: directoryExistsMock,
    fileExists: vi.fn(),
    listSubdirectoryNames: vi.fn(),
    readFileContent: vi.fn(),
    removeDirectoryStrict: vi.fn(),
    removeFileStrict: vi.fn(),
    writeFileContent: vi.fn(),
    assertDirectoryIfExists: vi.fn(),
    assertTreeContainsNoSymlinks: vi.fn(),
    assertWritablePathInsideRoot: vi.fn(),
  };
});

vi.mock("./git-client.js", () => ({
  GitClientError: class GitClientError extends Error {
    constructor(message: string, cause?: unknown) {
      super(message);
      this.name = "GitClientError";
      this.cause = cause;
    }
  },
  validateGitUrl: vi.fn(),
  validateRef: vi.fn(),
  checkGitAvailable: vi.fn(),
  resetGitCheck: vi.fn(),
  resolveDefaultRef: vi.fn(),
  resolveRefToSha: vi.fn(),
  fetchSkillFiles: vi.fn(),
}));

vi.mock("./npm-client.js", async (importOriginal) => {
  const actual = await importOriginal<typeof import("./npm-client.js")>();
  return {
    ...actual,
    fetchPackument: vi.fn(),
    fetchTarball: vi.fn(),
    getPackumentVersionDist: vi.fn(),
    resolveNpmToken: vi.fn(),
    resolvePackumentVersion: vi.fn(),
    verifyTarballIntegrity: vi.fn(),
  };
});

vi.mock("./npm-tar.js", async (importOriginal) => {
  const actual = await importOriginal<typeof import("./npm-tar.js")>();
  return {
    ...actual,
    extractPackageTarball: vi.fn(),
  };
});

vi.mock("./sources-lock.js", async (importOriginal) => {
  const actual = await importOriginal<typeof import("./sources-lock.js")>();
  return {
    ...actual,
    readLockFile: vi.fn().mockResolvedValue({ lockfileVersion: 1, sources: {} }),
    writeLockFile: vi.fn().mockResolvedValue(undefined),
  };
});

vi.mock("./npm-sources-lock.js", async (importOriginal) => {
  const actual = await importOriginal<typeof import("./npm-sources-lock.js")>();
  return {
    ...actual,
    readNpmLockFile: vi.fn().mockResolvedValue({ lockfileVersion: 1, sources: {} }),
    writeNpmLockFile: vi.fn().mockResolvedValue(undefined),
  };
});

const logger = createMockLogger();
const delay = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

describe("resolveAndFetchSources — faster multi-source install", () => {
  let testDir: string;
  let cleanup: () => Promise<void>;

  beforeEach(async () => {
    ({ testDir, cleanup } = await setupTestDirectory());
    vi.spyOn(process, "cwd").mockReturnValue(testDir);

    mockClientInstance = {
      getDefaultBranch: vi.fn().mockResolvedValue("main"),
      resolveRefToSha: vi.fn().mockResolvedValue("abc123def456"),
      listDirectory: vi.fn().mockResolvedValue([]),
      getFileContent: vi.fn().mockResolvedValue("file content"),
      listExecutablePaths: vi.fn().mockResolvedValue({ paths: new Set(), truncated: false }),
    };

    vi.mocked(directoryExists).mockResolvedValue(false);
    vi.mocked(fileExists).mockResolvedValue(false);
    vi.mocked(listSubdirectoryNames).mockResolvedValue([]);
    vi.mocked(readFileContent).mockResolvedValue("");
    vi.mocked(removeDirectory).mockResolvedValue(undefined);
    vi.mocked(removeFile).mockResolvedValue(undefined);
    vi.mocked(writeFileContent).mockResolvedValue(undefined);
  });

  afterEach(async () => {
    await cleanup();
    vi.clearAllMocks();
  });

  // ── Determinism boundary ────────────────────────────────────────────────
  // Same curated writes, first-declared-source-wins collisions, and lockfile
  // key order as the strictly one-at-a-time installer — even when the later
  // sources answer the network first. Holds for any speed-up that leaves the
  // write / collision / lockfile-merge pass in declared order; a change that
  // lets the writing pass itself run out of order breaks it.
  it("writes, resolves collisions, and locks in declared order even when later sources answer first", async () => {
    const { writeLockFile } = await import("./sources-lock.js");
    // repo-a answers slowest and repo-c fastest, so the network settles in the
    // reverse of the declared order.
    const latency: Record<string, number> = { "repo-a": 30, "repo-b": 15, "repo-c": 0 };
    mockClientInstance.listDirectory.mockImplementation(
      async (_owner: string, repo: string, path: string) => {
        await delay(latency[repo] ?? 0);
        if (path === "skills") {
          return [
            { name: "shared", path: "skills/shared", type: "dir" },
            { name: `${repo}-only`, path: `skills/${repo}-only`, type: "dir" },
          ];
        }
        return [{ name: "SKILL.md", path: `${path}/SKILL.md`, type: "file", size: 10 }];
      },
    );
    mockClientInstance.getFileContent.mockImplementation(
      async (_owner: string, repo: string, path: string) => {
        await delay(latency[repo] ?? 0);
        return `${path} from ${repo}`;
      },
    );

    const result = await resolveAndFetchSources({
      logger,
      sources: [{ source: "org/repo-a" }, { source: "org/repo-b" }, { source: "org/repo-c" }],
      projectRoot: testDir,
    });

    expect(result.failedSourceCount).toBe(0);
    expect(result.fetchedSkillCount).toBe(4);
    const curatedDir = join(testDir, RULESYNC_CURATED_SKILLS_RELATIVE_DIR_PATH);
    expect(vi.mocked(writeFileContent).mock.calls).toEqual([
      [join(curatedDir, "shared", "SKILL.md"), "skills/shared/SKILL.md from repo-a"],
      [join(curatedDir, "repo-a-only", "SKILL.md"), "skills/repo-a-only/SKILL.md from repo-a"],
      [join(curatedDir, "repo-b-only", "SKILL.md"), "skills/repo-b-only/SKILL.md from repo-b"],
      [join(curatedDir, "repo-c-only", "SKILL.md"), "skills/repo-c-only/SKILL.md from repo-c"],
    ]);
    expect(logger.warn).toHaveBeenCalledWith(
      expect.stringContaining('Skipping duplicate skill "shared" from org/repo-b'),
    );
    const writtenLock = vi.mocked(writeLockFile).mock.calls[0]?.[0].lock;
    expect(Object.keys(writtenLock?.sources ?? {})).toEqual([
      "org/repo-a",
      "org/repo-b",
      "org/repo-c",
    ]);
    expect(Object.keys(writtenLock?.sources["org/repo-a"]?.skills ?? {}).toSorted()).toEqual([
      "repo-a-only",
      "shared",
    ]);
  });

  // ── The content downloads actually run ahead of the writes ──────────────
  // In the same reverse-latency world, the last-declared source is fully
  // downloaded before the first curated file is written. A strictly serial
  // installer cannot do this: it only reaches the last source after it has
  // already written the first. Fails the one-at-a-time baseline; passes any
  // change that warms the file contents before the writing pass.
  it("downloads source file contents ahead of the first write", async () => {
    const latency: Record<string, number> = { "repo-a": 30, "repo-b": 15, "repo-c": 0 };
    mockClientInstance.listDirectory.mockImplementation(
      async (_owner: string, repo: string, path: string) => {
        await delay(latency[repo] ?? 0);
        if (path === "skills") {
          return [{ name: `${repo}-only`, path: `skills/${repo}-only`, type: "dir" }];
        }
        return [{ name: "SKILL.md", path: `${path}/SKILL.md`, type: "file", size: 10 }];
      },
    );
    mockClientInstance.getFileContent.mockImplementation(
      async (_owner: string, repo: string, path: string) => {
        await delay(latency[repo] ?? 0);
        return `${path} from ${repo}`;
      },
    );

    await resolveAndFetchSources({
      logger,
      sources: [{ source: "org/repo-a" }, { source: "org/repo-b" }, { source: "org/repo-c" }],
      projectRoot: testDir,
    });

    const lastRepoCDownload = Math.max(
      ...vi
        .mocked(mockClientInstance.getFileContent)
        .mock.calls.map((call: unknown[], index: number) => ({ repo: call[1], index }))
        .filter(({ repo }: { repo: unknown }) => repo === "repo-c")
        .map(
          ({ index }: { index: number }) =>
            mockClientInstance.getFileContent.mock.invocationCallOrder[index],
        ),
    );
    expect(lastRepoCDownload).toBeLessThan(
      vi.mocked(writeFileContent).mock.invocationCallOrder[0]!,
    );
  });

  // ── Each file downloaded once; claimed names not re-downloaded ──────────
  // The warm-up must not duplicate a download the writing pass also makes, and
  // the copies of a name an earlier source already took are never listed or
  // downloaded. A warm-up that double-fetches or ignores the claim order shows
  // up as an inflated request count.
  it("downloads each retained file once and skips a name an earlier source already took", async () => {
    mockClientInstance.listDirectory.mockImplementation(
      async (_owner: string, repo: string, path: string) => {
        if (path === "skills") {
          return [
            { name: "shared", path: "skills/shared", type: "dir" },
            { name: `${repo}-only`, path: `skills/${repo}-only`, type: "dir" },
          ];
        }
        return [{ name: "SKILL.md", path: `${path}/SKILL.md`, type: "file", size: 10 }];
      },
    );
    mockClientInstance.getFileContent.mockImplementation(
      async (_owner: string, repo: string, path: string) => `${path} from ${repo}`,
    );

    const result = await resolveAndFetchSources({
      logger,
      sources: [{ source: "org/repo-a" }, { source: "org/repo-b" }, { source: "org/repo-c" }],
      projectRoot: testDir,
    });

    expect(result.failedSourceCount).toBe(0);
    // shared (repo-a) + repo-a-only + repo-b-only + repo-c-only = 4 downloads.
    // The repo-b / repo-c copies of `shared` are neither listed nor downloaded.
    expect(mockClientInstance.getFileContent).toHaveBeenCalledTimes(4);
    expect(mockClientInstance.listDirectory).not.toHaveBeenCalledWith(
      "org",
      "repo-b",
      "skills/shared",
      expect.anything(),
      expect.anything(),
    );
    expect(mockClientInstance.listDirectory).not.toHaveBeenCalledWith(
      "org",
      "repo-c",
      "skills/shared",
      expect.anything(),
      expect.anything(),
    );
  });

  // ── Several sources at once, but bounded ────────────────────────────────
  // With far more sources than any sane in-flight cap, more than one source is
  // worked at a time (so the one-at-a-time baseline fails: it only ever has a
  // single source active), yet the number of sources and the number of
  // requests in flight both stay bounded below the totals — an unbounded
  // fan-out would let every source and every request run at once. The request
  // ceiling is the repo's own shared FETCH_CONCURRENCY_LIMIT; the source
  // ceiling is only required to be a real bound below the total, not a
  // specific number the change is free to choose.
  it("works several sources at once while keeping sources and requests in flight bounded", async () => {
    const sourceCount = 12;
    const filesPerSkill = FETCH_CONCURRENCY_LIMIT + 5;
    const activeSources = new Set<string>();
    let maxActiveSources = 0;
    let requestsInFlight = 0;
    let maxRequestsInFlight = 0;
    const track = async <T>(work: () => Promise<T>): Promise<T> => {
      requestsInFlight += 1;
      maxRequestsInFlight = Math.max(maxRequestsInFlight, requestsInFlight);
      try {
        await delay(2);
        return await work();
      } finally {
        requestsInFlight -= 1;
      }
    };
    const remainingFiles = new Map<string, number>();
    mockClientInstance.getDefaultBranch.mockImplementation(async (_owner: string, repo: string) => {
      activeSources.add(repo);
      maxActiveSources = Math.max(maxActiveSources, activeSources.size);
      remainingFiles.set(repo, filesPerSkill);
      return track(async () => "main");
    });
    mockClientInstance.listDirectory.mockImplementation(
      async (_owner: string, repo: string, path: string) =>
        track(async () => {
          if (path === "skills") {
            return [{ name: `skill-${repo}`, path: `skills/skill-${repo}`, type: "dir" }];
          }
          return Array.from({ length: filesPerSkill }, (_, index) => ({
            name: `file-${index}.md`,
            path: `${path}/file-${index}.md`,
            type: "file",
            size: 10,
          }));
        }),
    );
    mockClientInstance.getFileContent.mockImplementation(
      async (_owner: string, repo: string, path: string) =>
        track(async () => {
          const remaining = (remainingFiles.get(repo) ?? 0) - 1;
          remainingFiles.set(repo, remaining);
          if (remaining === 0) {
            activeSources.delete(repo);
          }
          return path;
        }),
    );

    const result = await resolveAndFetchSources({
      logger,
      sources: Array.from({ length: sourceCount }, (_, index) => ({ source: `org/repo-${index}` })),
      projectRoot: testDir,
    });

    expect(result.failedSourceCount).toBe(0);
    // More than one source worked at a time, but strictly fewer than all of
    // them: a genuine bound, not serial and not unbounded.
    expect(maxActiveSources).toBeGreaterThan(1);
    expect(maxActiveSources).toBeLessThan(sourceCount);
    // Requests share the repo's own ceiling, and more than one runs at a time.
    expect(maxRequestsInFlight).toBeGreaterThan(1);
    expect(maxRequestsInFlight).toBeLessThanOrEqual(FETCH_CONCURRENCY_LIMIT);
    expect(mockClientInstance.getFileContent).toHaveBeenCalledTimes(sourceCount * filesPerSkill);
  });

  // ── The source bound survives a sibling request failing mid-flight ──────
  // One skill listing per source throws while that source's healthy skill is
  // still being listed. More than one source is still worked at a time and the
  // count never runs away past a bound. The one-at-a-time baseline keeps a
  // single source active and so fails the "more than one" check.
  it("keeps the active-source count bounded when a sibling request fails mid-flight", async () => {
    const sourceCount = 12;
    const inFlightByRepo = new Map<string, number>();
    let maxActiveSources = 0;
    const track = async <T>(repo: string, work: () => Promise<T>): Promise<T> => {
      inFlightByRepo.set(repo, (inFlightByRepo.get(repo) ?? 0) + 1);
      const active = [...inFlightByRepo.values()].filter((count) => count > 0).length;
      maxActiveSources = Math.max(maxActiveSources, active);
      try {
        return await work();
      } finally {
        inFlightByRepo.set(repo, (inFlightByRepo.get(repo) ?? 1) - 1);
      }
    };
    const { GitHubClientError } = await import("./github-client.js");
    mockClientInstance.listDirectory.mockImplementation(
      async (_owner: string, repo: string, path: string) =>
        track(repo, async () => {
          if (path === "skills") {
            return [
              { name: `bad-${repo}`, path: `skills/bad-${repo}`, type: "dir" },
              { name: `good-${repo}`, path: `skills/good-${repo}`, type: "dir" },
            ];
          }
          if (path.startsWith("skills/bad-")) {
            throw new GitHubClientError("Server Error", 500);
          }
          await delay(15);
          return [{ name: "SKILL.md", path: `${path}/SKILL.md`, type: "file", size: 10 }];
        }),
    );
    mockClientInstance.getFileContent.mockImplementation(
      async (_owner: string, repo: string, path: string) =>
        track(repo, async () => {
          await delay(5);
          return path;
        }),
    );

    const result = await resolveAndFetchSources({
      logger,
      sources: Array.from({ length: sourceCount }, (_, index) => ({ source: `org/repo-${index}` })),
      projectRoot: testDir,
    });

    expect(result.failedSourceCount).toBe(sourceCount);
    expect(maxActiveSources).toBeGreaterThan(1);
    expect(maxActiveSources).toBeLessThan(sourceCount);
  });

  // ── A failed ahead-of-time request is reported once, with its hint ──────
  // A request that fails during the warm-up must surface exactly the one
  // failure line and the one auth hint the installer emits today, and must not
  // be retried by the writing pass. Guards the held-rejection contract: a
  // warm-up that drops rejected requests would make the writing pass ask again
  // (a second call), and a warm-up that reports on its own would double-log.
  it("reports a failed ahead-of-time request once, with its auth hint, without retrying", async () => {
    const { GitHubClientError, logGitHubAuthHints } = await import("./github-client.js");
    const error = new GitHubClientError("Forbidden", 403);
    mockClientInstance.listDirectory.mockImplementation(
      async (_owner: string, _repo: string, path: string) => {
        if (path === "skills") {
          return [{ name: "my-skill", path: "skills/my-skill", type: "dir" }];
        }
        return [{ name: "SKILL.md", path: `${path}/SKILL.md`, type: "file", size: 10 }];
      },
    );
    mockClientInstance.getFileContent.mockRejectedValue(error);

    const result = await resolveAndFetchSources({
      logger,
      sources: [{ source: "org/repo" }],
      projectRoot: testDir,
    });

    expect(result.failedSourceCount).toBe(1);
    expect(mockClientInstance.getFileContent).toHaveBeenCalledTimes(1);
    const failures = vi
      .mocked(logger.error)
      .mock.calls.filter(([message]) => String(message).includes("Failed to fetch source"));
    expect(failures).toEqual([['Failed to fetch source "org/repo": Error: Forbidden']]);
    expect(logGitHubAuthHints).toHaveBeenCalledTimes(1);
    expect(logGitHubAuthHints).toHaveBeenCalledWith({ error, logger });
  });

  // ── Name-claim order across transports: an earlier git source by name ───
  // A git-transport source, declared first, selects `shared` and `team-rule`
  // by name. The later GitHub source's copies of those names are never listed
  // or downloaded; only its own distinct names are. Guards that the warm-up
  // honours what an earlier non-GitHub source will claim.
  it("does not fetch a name an earlier git source selects by name", async () => {
    const { resolveDefaultRef, fetchSkillFiles } = await import("./git-client.js");
    vi.mocked(resolveDefaultRef).mockResolvedValue({ ref: "main", sha: "a".repeat(40) });
    vi.mocked(fetchSkillFiles).mockImplementation(async ({ skillsPath }) =>
      skillsPath === "rules"
        ? [{ relativePath: "team-rule.md", content: "# team rule from git", size: 20 }]
        : [{ relativePath: "shared/SKILL.md", content: "shared from git", size: 20 }],
    );
    mockClientInstance.listDirectory.mockImplementation(
      async (_owner: string, _repo: string, path: string) => {
        if (path === "skills") {
          return [
            { name: "shared", path: "skills/shared", type: "dir" },
            { name: "github-only", path: "skills/github-only", type: "dir" },
          ];
        }
        if (path === "rules") {
          return [
            { name: "team-rule.md", path: "rules/team-rule.md", type: "file", size: 10 },
            { name: "github-rule.md", path: "rules/github-rule.md", type: "file", size: 10 },
          ];
        }
        return [{ name: "SKILL.md", path: `${path}/SKILL.md`, type: "file", size: 10 }];
      },
    );
    mockClientInstance.getFileContent.mockImplementation(
      async (_owner: string, _repo: string, path: string) => `${path} from github`,
    );

    const result = await resolveAndFetchSources({
      logger,
      sources: [
        {
          source: "https://example.com/team/assets.git",
          transport: "git",
          skills: ["shared"],
          rules: ["team-rule"],
        },
        { source: "org/repo", skills: ["*"], rules: ["*"] },
      ],
      projectRoot: testDir,
    });

    expect(result.failedSourceCount).toBe(0);
    expect(result.fetchedSkillCount).toBe(2);
    expect(result.fetchedRuleCount).toBe(2);
    expect(mockClientInstance.listDirectory).not.toHaveBeenCalledWith(
      "org",
      "repo",
      "skills/shared",
      expect.anything(),
      expect.anything(),
    );
    const downloadedPaths = vi
      .mocked(mockClientInstance.getFileContent)
      .mock.calls.map((call: unknown[]) => call[2]);
    expect(downloadedPaths.toSorted()).toEqual([
      "rules/github-rule.md",
      "skills/github-only/SKILL.md",
    ]);
  });

  // ── An earlier wildcard git source may take any name ────────────────────
  // When the earlier git source selects by wildcard, which names it takes is
  // only known once the writing pass has run it, so the GitHub source's files
  // are fetched after that, and `shared`, which the git source took, is never
  // fetched. A warm-up that charged ahead regardless would download `shared`.
  it("waits for an earlier wildcard git source before fetching names it might take", async () => {
    const { resolveDefaultRef, fetchSkillFiles } = await import("./git-client.js");
    vi.mocked(resolveDefaultRef).mockResolvedValue({ ref: "main", sha: "a".repeat(40) });
    vi.mocked(fetchSkillFiles).mockResolvedValue([
      { relativePath: "shared/SKILL.md", content: "shared from git", size: 20 },
    ]);
    mockClientInstance.listDirectory.mockImplementation(
      async (_owner: string, _repo: string, path: string) => {
        if (path === "skills") {
          return [
            { name: "shared", path: "skills/shared", type: "dir" },
            { name: "github-only", path: "skills/github-only", type: "dir" },
          ];
        }
        return [{ name: "SKILL.md", path: `${path}/SKILL.md`, type: "file", size: 10 }];
      },
    );

    const result = await resolveAndFetchSources({
      logger,
      sources: [
        { source: "https://example.com/team/skills.git", transport: "git" },
        { source: "org/repo" },
      ],
      projectRoot: testDir,
    });

    expect(result.failedSourceCount).toBe(0);
    expect(result.fetchedSkillCount).toBe(2);
    const gitFetchOrder = vi.mocked(fetchSkillFiles).mock.invocationCallOrder[0]!;
    expect(mockClientInstance.getFileContent).toHaveBeenCalledTimes(1);
    expect(mockClientInstance.getFileContent).toHaveBeenCalledWith(
      "org",
      "repo",
      "skills/github-only/SKILL.md",
      expect.anything(),
    );
    expect(mockClientInstance.getFileContent.mock.invocationCallOrder[0]).toBeGreaterThan(
      gitFetchOrder,
    );
  });

  // ── An earlier GitLab source claims no name ─────────────────────────────
  // A GitLab source is rejected by the writing pass without taking any name,
  // so the later GitHub source's content is fetched by the warm-up BEFORE that
  // rejection is reported. The one-at-a-time baseline can only fetch the GitHub
  // content during its own later turn, after it has already logged the GitLab
  // failure, so the content fetch lands after the error there.
  it("fetches ahead of an earlier gitlab source, which claims no name", async () => {
    mockClientInstance.listDirectory.mockImplementation(
      async (_owner: string, _repo: string, path: string) => {
        if (path === "skills") {
          return [{ name: "shared", path: "skills/shared", type: "dir" }];
        }
        return [{ name: "SKILL.md", path: `${path}/SKILL.md`, type: "file", size: 10 }];
      },
    );

    const result = await resolveAndFetchSources({
      logger,
      sources: [{ source: "gitlab:org/repo" }, { source: "org/repo" }],
      projectRoot: testDir,
    });

    expect(result.failedSourceCount).toBe(1);
    expect(result.fetchedSkillCount).toBe(1);
    expect(mockClientInstance.getFileContent).toHaveBeenCalledTimes(1);
    expect(mockClientInstance.getFileContent.mock.invocationCallOrder[0]).toBeLessThan(
      vi.mocked(logger.error).mock.invocationCallOrder.at(-1)!,
    );
  });

  // ── Pre-existing single-source behavior is unchanged ────────────────────
  // A single GitHub source still installs its one skill file to the curated
  // tree. Holds on both the one-at-a-time installer and any speed-up.
  it("still installs a single GitHub source's skill file", async () => {
    mockClientInstance.listDirectory.mockImplementation(
      async (_owner: string, _repo: string, path: string) => {
        if (path === "skills") {
          return [{ name: "my-skill", path: "skills/my-skill", type: "dir" }];
        }
        if (path === "skills/my-skill") {
          return [{ name: "SKILL.md", path: "skills/my-skill/SKILL.md", type: "file", size: 100 }];
        }
        return [];
      },
    );
    mockClientInstance.getFileContent.mockResolvedValue("# My Skill\nContent here.");

    const result = await resolveAndFetchSources({
      logger,
      sources: [{ source: "https://github.com/org/repo" }],
      projectRoot: testDir,
    });

    expect(result.fetchedSkillCount).toBe(1);
    expect(result.sourcesProcessed).toBe(1);
    expect(writeFileContent).toHaveBeenCalledWith(
      join(testDir, RULESYNC_CURATED_SKILLS_RELATIVE_DIR_PATH, "my-skill", "SKILL.md"),
      "# My Skill\nContent here.",
    );
  });

  // ── Pre-existing reuse-from-lock behavior is unchanged ──────────────────
  // When the resolved SHA matches the lockfile and the curated skills are on
  // disk, no listing happens and nothing is newly fetched. Holds on both the
  // one-at-a-time installer and any speed-up: a warm-up must respect the same
  // reuse decision and not list a source it can skip.
  it("still skips re-fetching a source whose SHA matches the lockfile", async () => {
    const { readLockFile } = await import("./sources-lock.js");
    const curatedDir = join(testDir, RULESYNC_CURATED_SKILLS_RELATIVE_DIR_PATH);
    vi.mocked(readLockFile).mockResolvedValue({
      lockfileVersion: 1,
      sources: {
        "https://github.com/org/repo": {
          resolvedRef: "locked-sha-123",
          skills: { "cached-skill": { integrity: "sha256-cached" } },
          skillSelection: ["*"],
          skillsPath: "skills",
        },
      },
    });
    mockClientInstance.resolveRefToSha.mockResolvedValue("locked-sha-123");
    vi.mocked(directoryExists).mockImplementation(async (path: string) => {
      if (path === join(curatedDir, "cached-skill")) return true;
      return false;
    });

    const result = await resolveAndFetchSources({
      logger,
      sources: [{ source: "https://github.com/org/repo" }],
      projectRoot: testDir,
    });

    expect(mockClientInstance.listDirectory).not.toHaveBeenCalled();
    expect(result.fetchedSkillCount).toBe(0);
    expect(result.sourcesProcessed).toBe(1);
    expect(removeDirectory).not.toHaveBeenCalled();
  });
});
