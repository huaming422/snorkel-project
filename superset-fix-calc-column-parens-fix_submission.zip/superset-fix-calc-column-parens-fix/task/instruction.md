## Task

one of our datasets has a boolean calculated column whose expression uses an
`OR`, something like `state = 'CA' OR state = 'NY'`. when a chart uses that
column as a series dimension with a series limit (top-N) set, it comes back
with the wrong groups: the top-N it picks and the rows it then joins back to
that selection don't line up with what the expression actually evaluates to, so
the chart shows data for the wrong series.

a plain physical-column series chart on the same dataset is fine, and the same
calculated column used in a filter returns correct results. it's specifically a
calculated column driving a top-N series that goes wrong. this is in the
backend SQL generation for calculated columns. dig in and fix it.
