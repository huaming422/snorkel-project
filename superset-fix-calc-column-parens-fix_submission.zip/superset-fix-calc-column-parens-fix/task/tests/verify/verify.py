"""Behavioral checks for calculated-column SQL compilation in Superset.

A calculated (expression) dataset column is one defined by a SQL expression
rather than a physical table column. When the expression contains a bare
low-precedence boolean operator (e.g. ``OR``), compiling it into surrounding
SQL without surrounding grouping lets that operator leak into the precedence of
whatever clause the column feeds — so a boolean calculated column used as a
series (top-N) dimension selects the wrong groups and joins back the wrong rows.

These checks drive the dataset query builder through its pre-existing public
surface — ``SqlaTable.get_sqla_query(...).sqla_query`` compiled to SQL text,
plus ``_get_top_groups`` — and assert only the *behavioral* properties of the
emitted SQL: that a bare low-precedence operator cannot leak into a comparison
context (the series-limit JOIN ON and top-N prequery predicates), that an adhoc
reference to a saved calculated column stays grouped in a filter, that physical
columns are left untouched, and that a trailing single-line comment does not
produce invalid SQL. They never assert parenthesization in clauses where it does
not change the
result (SELECT/GROUP BY/ORDER BY projection, a ``COUNT(DISTINCT …)`` argument),
so any shape of the correctness fix (group via an AST node or by string, at the
converter or at each comparison site, with any/no helper) is accepted on equal
terms; only the observable SQL semantics are asserted.

The file is self-contained: it rebuilds a minimal application context, an
in-memory SQLite session, and a ``database`` fixture equivalent to the repo's
own ``tests/unit_tests/models/helpers_test.py`` rather than importing them, so
it can be collected from outside the repo test tree. It runs under the project
interpreter (see verify.toml) because it imports Superset source.
"""

from __future__ import annotations

import importlib
import os
from contextlib import contextmanager
from typing import Any, Iterator

import pytest
from pytest_mock import MockerFixture
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm.session import Session
from sqlalchemy.pool import StaticPool

# The example boolean expression used throughout: a bare ``OR`` is the
# low-precedence operator whose leakage is the defect under test. This literal
# is a check-owned fixture value, chosen here to construct the scenario.
CALC_EXPR = "state = 'CA' OR state = 'NY'"


# --------------------------------------------------------------------------- #
# Application context + in-memory SQLite session (mirrors the repo conftest).
# --------------------------------------------------------------------------- #
@pytest.fixture(scope="module")
def app() -> Iterator[Any]:
    from superset.app import SupersetApp
    from superset.extensions import appbuilder
    from superset.initialization import SupersetAppInitializer

    flask_app = SupersetApp(__name__)
    flask_app.config.from_object("superset.config")
    flask_app.config["SQLALCHEMY_DATABASE_URI"] = (
        os.environ.get("SUPERSET__SQLALCHEMY_DATABASE_URI") or "sqlite://"
    )
    flask_app.config["WTF_CSRF_ENABLED"] = False
    flask_app.config["PREVENT_UNSAFE_DB_CONNECTIONS"] = False
    flask_app.config["TESTING"] = True
    flask_app.config["RATELIMIT_ENABLED"] = False
    flask_app.config["CACHE_CONFIG"] = {}
    flask_app.config["DATA_CACHE_CONFIG"] = {}
    flask_app.config["SERVER_NAME"] = "example.com"
    flask_app.config["APPLICATION_ROOT"] = "/"
    flask_app.config["PREFERRED_URL_SCHEME"] = "http"

    # ``appbuilder`` is a singleton; clear registered views so a repeat init in
    # the same process does not double-register routes.
    appbuilder.baseviews = []
    SupersetAppInitializer(flask_app).init_app()
    with flask_app.app_context():
        import superset.views.base

        importlib.reload(superset.views.base)

    yield flask_app


@pytest.fixture(autouse=True)
def app_context(app: Any) -> Iterator[None]:
    # Model construction and ``get_sqla_query`` touch app-context-bound config.
    with app.app_context():
        yield


@pytest.fixture
def session(mocker: MockerFixture) -> Session:
    engine = create_engine("sqlite://")
    session_factory = sessionmaker(bind=engine)
    in_memory_session = session_factory()
    in_memory_session.remove = lambda: None  # Flask calls db.session.remove()

    patched = mocker.patch("superset.security.SupersetSecurityManager.session")
    patched.return_value = in_memory_session
    patched.get_bind.return_value = engine
    patched.query = in_memory_session.query
    mocker.patch("superset.db.session", in_memory_session)
    return in_memory_session


@pytest.fixture
def database(mocker: MockerFixture, session: Session) -> Any:
    from superset.connectors.sqla.models import SqlaTable
    from superset.models.core import Database

    SqlaTable.metadata.create_all(session.get_bind())

    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    database = Database(database_name="db", sqlalchemy_uri="sqlite://")

    connection = engine.raw_connection()
    connection.execute("CREATE TABLE t (a INTEGER, b TEXT)")
    connection.execute("INSERT INTO t VALUES (1, 'Alice')")
    connection.execute("INSERT INTO t VALUES (NULL, 'Bob')")
    connection.commit()

    @contextmanager
    def mock_get_sqla_engine(catalog=None, schema=None, **kwargs):
        yield engine

    mocker.patch.object(database, "get_sqla_engine", new=mock_get_sqla_engine)
    return database


# --------------------------------------------------------------------------- #
# Helpers.
# --------------------------------------------------------------------------- #
def _calc_table(database: Any) -> Any:
    """A table with a boolean/OR calculated column and a ``count`` metric."""
    from superset.connectors.sqla.models import SqlaTable, SqlMetric, TableColumn

    return SqlaTable(
        database=database,
        schema=None,
        table_name="t",
        columns=[
            TableColumn(column_name="a", type="INTEGER"),
            TableColumn(
                column_name="is_ca_or_ny",
                expression=CALC_EXPR,
                type="BOOLEAN",
            ),
        ],
        metrics=[SqlMetric(metric_name="count", expression="COUNT(*)")],
    )


def _compile(database: Any, sqla_query: Any) -> str:
    with database.get_sqla_engine() as engine:
        return str(
            sqla_query.sqla_query.compile(
                dialect=engine.dialect,
                compile_kwargs={"literal_binds": True},
            )
        )


# --------------------------------------------------------------------------- #
# Checks.
# --------------------------------------------------------------------------- #
def test_physical_column_is_not_parenthesized(
    database: Any,
) -> None:
    """Only expression (calculated) columns are grouped; a physical column is
    emitted unchanged. Guards against hoisting the grouping outside the
    ``if expression:`` branch of the converters."""
    table = _calc_table(database)

    sqla_query = table.get_sqla_query(
        columns=["a"],
        metrics=[],
        extras={},
        is_timeseries=False,
    )
    sql = _compile(database, sqla_query)

    assert "a AS a" in sql, f"Physical column should be selected as-is. SQL: {sql}"
    assert "(a)" not in sql, f"Physical column must not be grouped. SQL: {sql}"


def test_calculated_column_series_limit_join_on_is_parenthesized(
    database: Any,
) -> None:
    """The core correctness property: when a boolean/OR calculated column is a
    series (top-N) dimension, the series-limit JOIN ON predicate compares the
    grouped expression (``(<expr>) = <inner col>``). Without grouping it
    mis-parses as ``state = 'CA' OR (state = 'NY' = <inner col>)``, changing the
    join membership."""
    table = _calc_table(database)

    sqla_query = table.get_sqla_query(
        groupby=["is_ca_or_ny"],
        metrics=["count"],
        series_columns=["is_ca_or_ny"],
        series_limit=10,
        extras={},
        is_timeseries=False,
    )
    sql = _compile(database, sqla_query)

    assert f"({CALC_EXPR}) = is_ca_or_ny__" in sql, (
        f"Series-limit JOIN ON should compare the grouped expression. SQL: {sql}"
    )
    assert "OR state = 'NY' = is_ca_or_ny__" not in sql, (
        f"Series-limit JOIN ON must not emit the bare, mis-parsing form. SQL: {sql}"
    )


def test_calculated_column_top_groups_predicate_is_parenthesized(
    database: Any,
) -> None:
    """The series top-N prequery predicate built by ``_get_top_groups``
    (``<groupby expr> == value``) must group the calculated expression, so
    ``(<expr>) = <value>`` is produced rather than the bare mis-parsing form."""
    import pandas as pd

    from superset.connectors.sqla.models import TableColumn

    table = _calc_table(database)
    calc_col = next(c for c in table.columns if c.column_name == "is_ca_or_ny")
    assert isinstance(calc_col, TableColumn)

    gby_obj = table.convert_tbl_column_to_sqla_col(tbl_column=calc_col)
    df = pd.DataFrame({"is_ca_or_ny": [1]})

    predicate = table._get_top_groups(
        df,
        ["is_ca_or_ny"],
        {"is_ca_or_ny": gby_obj},
        {"is_ca_or_ny": calc_col},
    )

    with database.get_sqla_engine() as engine:
        sql = str(
            predicate.compile(
                dialect=engine.dialect,
                compile_kwargs={"literal_binds": True},
            )
        )

    assert f"({CALC_EXPR}) = 1" in sql, (
        f"Top-N prequery predicate should be grouped. SQL: {sql}"
    )
    assert "OR state = 'NY' = 1" not in sql, (
        f"Top-N prequery predicate must not emit the bare form. SQL: {sql}"
    )


def test_calculated_column_reference_adhoc_filter_stays_grouped(
    database: Any,
) -> None:
    """A WHERE filter whose ``col`` is an adhoc column referencing a saved
    calculated column (``isColumnReference=True``) keeps the boolean expression
    grouped, so the bare low-precedence operator cannot leak into the comparison.
    Any grouped form is accepted (one or more outer parens are semantically
    identical); only the bare, mis-parsing form is rejected."""
    table = _calc_table(database)

    sqla_query = table.get_sqla_query(
        columns=["a"],
        filter=[
            {
                "col": {
                    "label": "is_ca_or_ny",
                    "sqlExpression": "is_ca_or_ny",
                    "isColumnReference": True,
                },
                "op": "==",
                "val": 1,
            },
        ],
        metrics=[],
        extras={},
        is_timeseries=False,
    )
    sql = _compile(database, sqla_query)

    assert f"({CALC_EXPR})" in sql, (
        f"Adhoc calc-column-reference filter should keep the expression grouped. "
        f"SQL: {sql}"
    )
    assert "OR state = 'NY' = 1" not in sql, (
        f"Adhoc calc-column-reference filter must not emit the bare, mis-parsing "
        f"form. SQL: {sql}"
    )


def test_calculated_column_with_trailing_comment_stays_valid_sql(
    database: Any,
) -> None:
    """A calculated column whose expression ends in a single-line comment must
    compile to valid SQL: whatever rewrite groups the expression, a closing
    paren must never land *after* a ``--``/``#`` comment marker on the same line
    (where the comment would swallow it, leaving an unclosed paren). This asserts
    the behavioral outcome — the SQL stays parseable — not any particular rewrite
    (a trailing newline, comment stripping, or another safe form all pass)."""
    from superset.connectors.sqla.models import SqlaTable, SqlMetric, TableColumn

    table = SqlaTable(
        database=database,
        schema=None,
        table_name="t",
        columns=[
            TableColumn(column_name="a", type="INTEGER"),
            TableColumn(
                column_name="is_ca_or_ny",
                expression=f"{CALC_EXPR} -- coasts",
                type="BOOLEAN",
            ),
        ],
        metrics=[SqlMetric(metric_name="count", expression="COUNT(*)")],
    )

    sqla_query = table.get_sqla_query(
        columns=["is_ca_or_ny"],
        metrics=[],
        extras={},
        is_timeseries=False,
    )
    sql = _compile(database, sqla_query)

    for line in sql.splitlines():
        for marker in ("--", "#"):
            if marker in line:
                after_comment = line.split(marker, 1)[1]
                assert ")" not in after_comment, (
                    f"A closing paren must not be swallowed by a trailing "
                    f"{marker!r} comment (it would leave an unclosed paren and "
                    f"invalid SQL). SQL: {sql}"
                )
