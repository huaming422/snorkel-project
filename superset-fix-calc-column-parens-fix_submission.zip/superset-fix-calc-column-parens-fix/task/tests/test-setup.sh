#!/usr/bin/env bash
# test-setup.sh — runs once (verifier phase, network allowlisted to the model
# gateway only) before the verifier.
#
# The image already baked Superset plus its full pinned dependency closure
# (requirements/development.txt, including pytest + pytest-mock + pandas) into
# /repo/superset/.venv at the pre-fix commit. There is NOTHING to install here:
# verify.py imports Superset repo code and runs the focused unit checks under
# that project venv. This script just makes the project interpreter the default
# `python`/`python3`/`pytest` and smoke-tests that the import chain resolves.
set -euo pipefail

REPO=/repo/superset
VENV="$REPO/.venv"

# Fail fast and offline: a cache miss should error, not hang on a dead network.
export UV_OFFLINE=1

# Put the baked project venv first on PATH so `python`, `python3` and `pytest`
# resolve to the Superset interpreter that has the repo installed editable.
export PATH="$VENV/bin:$PATH"
export VIRTUAL_ENV="$VENV"

echo "[test-setup] using project venv: $VENV"
"$VENV/bin/python" --version

echo "[test-setup] smoke-testing the Superset import chain + plugins"
# Superset model classes (Database, SqlaTable) are bound to an initialized
# application context (encrypted_field_factory refuses to build columns before
# init_app), so a bare module-level import fails. Build a minimal app and enter
# its context first — the same bootstrap verify.py performs in its own fixtures.
cd "$REPO"
"$VENV/bin/python" - <<'PY'
import sqlalchemy
from sqlalchemy.sql.elements import Grouping  # sqlalchemy grouping node; must exist
import pytest, pytest_mock, pandas, numpy  # noqa: F401

from superset.app import SupersetApp
from superset.extensions import appbuilder
from superset.initialization import SupersetAppInitializer

app = SupersetApp(__name__)
app.config.from_object("superset.config")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite://"
app.config["WTF_CSRF_ENABLED"] = False
app.config["TESTING"] = True
app.config["RATELIMIT_ENABLED"] = False
app.config["CACHE_CONFIG"] = {}
app.config["DATA_CACHE_CONFIG"] = {}
app.config["PREVENT_UNSAFE_DB_CONNECTIONS"] = False
appbuilder.baseviews = []
SupersetAppInitializer(app).init_app()
with app.app_context():
    from superset.connectors.sqla.models import SqlaTable, SqlMetric, TableColumn  # noqa: F401
    from superset.models.sql_lab import Query  # noqa: F401
print("[test-setup] imports OK; sqlalchemy", sqlalchemy.__version__)
PY

echo "[test-setup] done"
