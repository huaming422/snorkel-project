#!/usr/bin/env bash
# Verifier-phase setup for beads-fix-server-mode-inference.
#
# The image already carries the full Go dependency closure at the base commit
# (GOMODCACHE warm, build tree compiled in image block 7) and the reference fix
# introduces no new modules, so there is nothing to install here. The exports
# below make any accidental cache miss fail fast instead of hanging against a
# network that the offline agent phase does not have (AUTHORING.md §1.5):
# GOPROXY=off forbids module downloads, GOFLAGS=-mod=mod keeps the build
# working against the warm module cache without demanding go.sum network checks.
set -euo pipefail

export GOFLAGS=-mod=mod
export GOPROXY=off
export GOTOOLCHAIN=local

echo "[test-setup] beads-fix-server-mode-inference: deps baked into image; Go offline switches set"
