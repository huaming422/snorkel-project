// Contract test for the server-lifecycle resolver, the default-config port
// builder, and the connect-failure messaging.
//
// Injected into internal/doltserver as `package doltserver` so it compiles
// alongside the package's existing in-package tests and drives the behavior
// through the pre-existing, exported surface only:
//   - ResolveServerMode(beadsDir) ServerMode   (vs ServerModeExternal /
//     ServerModeOwned / ServerModeEmbedded)
//   - DefaultConfig(beadsDir) *Config           (asserting .Port vs
//     configfile.DefaultDoltServerPort)
//   - EnsureRunningDetailed(beadsDir) (int, bool, error)   (asserting the
//     returned error text for a remote server)
// Inputs are supplied through the BEADS_DOLT_SERVER_HOST / BEADS_DOLT_SERVER_MODE
// environment variables and a per-workspace config written with the
// pre-existing configfile.Config{...}.Save(dir). No internal helper introduced
// by a fix is referenced by name; the port-file path reuses the package's own
// pre-existing portPath helper (as the package's existing tests do).
//
// Subtests are sequential (no t.Parallel): they drive process-global env/config.

package doltserver

import (
	"os"
	"strings"
	"testing"

	"github.com/steveyegge/beads/internal/config"
	"github.com/steveyegge/beads/internal/configfile"
)

// clearModeEnv clears every environment variable that steers mode/port
// resolution so each case starts from a known-empty ambient state.
func clearModeEnv(t *testing.T) {
	t.Helper()
	t.Setenv("BEADS_DOLT_SHARED_SERVER", "")
	t.Setenv("BEADS_DOLT_SERVER_MODE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	t.Setenv("BEADS_DOLT_PORT", "")
	t.Setenv("BEADS_DOLT_AUTO_START", "")
	config.ResetForTesting()
	t.Cleanup(config.ResetForTesting)
}

// TestVerifyLifecycleResolverHostInference covers the server-lifecycle
// resolver: a host-inferred remote server must classify as externally managed
// (not bd-owned), while localhost and explicit-embedded workspaces keep their
// owned/embedded classification. Includes a metadata-less workspace to prove
// inference does not depend on a metadata file existing. (criterion C2)
func TestVerifyLifecycleResolverHostInference(t *testing.T) {
	t.Run("remote_struct_host_is_external", func(t *testing.T) {
		clearModeEnv(t)
		dir := t.TempDir()
		if err := (&configfile.Config{DoltServerHost: "10.0.0.5"}).Save(dir); err != nil {
			t.Fatal(err)
		}
		if mode := ResolveServerMode(dir); mode != ServerModeExternal {
			t.Errorf("ResolveServerMode = %v, want ServerModeExternal for a remote host", mode)
		}
	})

	t.Run("remote_env_host_metadata_less_is_external", func(t *testing.T) {
		// No metadata.json written: inference must still run from the env host.
		clearModeEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "192.0.2.10")
		dir := t.TempDir()
		if mode := ResolveServerMode(dir); mode != ServerModeExternal {
			t.Errorf("ResolveServerMode = %v, want ServerModeExternal for a metadata-less remote-env workspace", mode)
		}
	})

	t.Run("localhost_host_is_owned", func(t *testing.T) {
		clearModeEnv(t)
		dir := t.TempDir()
		if err := (&configfile.Config{DoltServerHost: "127.0.0.1"}).Save(dir); err != nil {
			t.Fatal(err)
		}
		if mode := ResolveServerMode(dir); mode != ServerModeOwned {
			t.Errorf("ResolveServerMode = %v, want ServerModeOwned for a localhost host", mode)
		}
	})

	t.Run("explicit_embedded_metadata_is_embedded", func(t *testing.T) {
		clearModeEnv(t)
		dir := t.TempDir()
		if err := (&configfile.Config{DoltMode: configfile.DoltModeEmbedded}).Save(dir); err != nil {
			t.Fatal(err)
		}
		if mode := ResolveServerMode(dir); mode != ServerModeEmbedded {
			t.Errorf("ResolveServerMode = %v, want ServerModeEmbedded for explicit embedded metadata", mode)
		}
	})
}

// TestVerifyLifecycleResolverPrecedence covers the precedence/gate cases at the
// lifecycle-resolver level: a runtime remote env host beats stale embedded
// metadata, an empty env host is ignored (not suppression), an explicit
// localhost env value suppresses a lower-priority remote host, and proxied
// workspaces are exempt. (criterion C4, resolver half)
func TestVerifyLifecycleResolverPrecedence(t *testing.T) {
	t.Run("remote_env_host_beats_embedded_metadata", func(t *testing.T) {
		clearModeEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "192.0.2.10")
		dir := t.TempDir()
		if err := (&configfile.Config{DoltMode: configfile.DoltModeEmbedded}).Save(dir); err != nil {
			t.Fatal(err)
		}
		if mode := ResolveServerMode(dir); mode != ServerModeExternal {
			t.Errorf("ResolveServerMode = %v, want ServerModeExternal: remote env host must beat stale embedded metadata", mode)
		}
	})

	t.Run("empty_env_host_not_suppression", func(t *testing.T) {
		clearModeEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "")
		dir := t.TempDir()
		if err := (&configfile.Config{DoltServerHost: "10.0.0.5"}).Save(dir); err != nil {
			t.Fatal(err)
		}
		if mode := ResolveServerMode(dir); mode != ServerModeExternal {
			t.Errorf("ResolveServerMode = %v, want ServerModeExternal: empty env host must not mask the remote metadata host", mode)
		}
	})

	t.Run("explicit_localhost_env_suppresses_metadata_host", func(t *testing.T) {
		clearModeEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "localhost")
		dir := t.TempDir()
		if err := (&configfile.Config{DoltServerHost: "10.0.0.5"}).Save(dir); err != nil {
			t.Fatal(err)
		}
		if mode := ResolveServerMode(dir); mode != ServerModeOwned {
			t.Errorf("ResolveServerMode = %v, want ServerModeOwned: explicit localhost env must suppress the remote metadata host", mode)
		}
	})

	t.Run("proxied_metadata_not_reclassified_external", func(t *testing.T) {
		clearModeEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "192.0.2.10")
		dir := t.TempDir()
		if err := (&configfile.Config{DoltMode: configfile.DoltModeProxiedServer}).Save(dir); err != nil {
			t.Fatal(err)
		}
		if mode := ResolveServerMode(dir); mode == ServerModeExternal {
			t.Errorf("ResolveServerMode = %v, want a non-external mode: a proxied workspace must not be reclassified external by a remote env host", mode)
		}
	})
}

// TestVerifyDefaultConfigPortForExternalHost covers the default-config port
// builder: for a host-inferred external server with no resolved port source it
// must dial the documented default port (not 0), and must not reuse a stale
// bd-owned local port-file entry. Asserted through the pre-existing
// configfile.DefaultDoltServerPort constant, not any fix-introduced port
// source. (criterion C5)
func TestVerifyDefaultConfigPortForExternalHost(t *testing.T) {
	t.Run("host_inferred_external_no_port_uses_default", func(t *testing.T) {
		clearModeEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "192.0.2.10")
		dir := t.TempDir()
		cfg := DefaultConfig(dir)
		if cfg.Port != configfile.DefaultDoltServerPort {
			t.Errorf("DefaultConfig.Port = %d, want %d for a host-inferred external server with no port configured",
				cfg.Port, configfile.DefaultDoltServerPort)
		}
	})

	t.Run("stale_local_port_file_not_reused_for_remote_host", func(t *testing.T) {
		clearModeEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "192.0.2.10")
		dir := t.TempDir()
		// A leftover bd-owned local port-file (bookkeeping for a local server)
		// must not be paired with a remote host.
		if err := os.WriteFile(portPath(dir), []byte("45123"), 0o600); err != nil {
			t.Fatal(err)
		}
		cfg := DefaultConfig(dir)
		if cfg.Port != configfile.DefaultDoltServerPort {
			t.Errorf("DefaultConfig.Port = %d, want %d: a stale local port file must not be used to dial a remote host",
				cfg.Port, configfile.DefaultDoltServerPort)
		}
	})
}

// TestVerifyUnreachableHintForRemoteHost covers the connect-failure messaging:
// for a non-localhost external server the unreachable error must name the
// external host and must NOT advise running the local start command.
//
// Both the pre-fix and post-fix trees are driven into the External /
// not-running branch with BEADS_DOLT_SERVER_MODE=1 and a remote host, so no
// real server is started on either tree; the only behavioral difference under
// test is the hint text. (criterion C6)
func TestVerifyUnreachableHintForRemoteHost(t *testing.T) {
	clearModeEnv(t)
	t.Setenv("BEADS_DOLT_SERVER_MODE", "1")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "192.0.2.10")
	dir := t.TempDir()

	_, started, err := EnsureRunningDetailed(dir)
	if err == nil {
		t.Fatal("EnsureRunningDetailed: err = nil, want an unreachable-server error for a remote external server")
	}
	if started {
		t.Error("EnsureRunningDetailed: startedByUs = true, want false for an externally-managed server")
	}
	msg := err.Error()
	if !strings.Contains(msg, "192.0.2.10") {
		t.Errorf("unreachable error must name the external host 192.0.2.10; got: %s", msg)
	}
	if strings.Contains(msg, "bd dolt start") {
		t.Errorf("unreachable error for a remote server must not advise the local 'bd dolt start' command; got: %s", msg)
	}
}

// TestVerifyPreservedModeBehaviorDoltserver is the doltserver-package half of
// the regression guard: localhost defaults, explicit-embedded metadata, and
// explicit-port (externally managed) workspaces must resolve exactly as before
// host inference existed. (criterion C7)
func TestVerifyPreservedModeBehaviorDoltserver(t *testing.T) {
	t.Run("localhost_default_is_owned", func(t *testing.T) {
		clearModeEnv(t)
		dir := t.TempDir()
		if mode := ResolveServerMode(dir); mode != ServerModeOwned {
			t.Errorf("ResolveServerMode = %v, want ServerModeOwned for a default localhost workspace", mode)
		}
	})

	t.Run("explicit_embedded_metadata_is_embedded", func(t *testing.T) {
		clearModeEnv(t)
		dir := t.TempDir()
		if err := (&configfile.Config{DoltMode: configfile.DoltModeEmbedded}).Save(dir); err != nil {
			t.Fatal(err)
		}
		if mode := ResolveServerMode(dir); mode != ServerModeEmbedded {
			t.Errorf("ResolveServerMode = %v, want ServerModeEmbedded", mode)
		}
	})

	t.Run("explicit_port_metadata_is_external", func(t *testing.T) {
		clearModeEnv(t)
		dir := t.TempDir()
		if err := (&configfile.Config{DoltServerPort: 3307}).Save(dir); err != nil {
			t.Fatal(err)
		}
		if mode := ResolveServerMode(dir); mode != ServerModeExternal {
			t.Errorf("ResolveServerMode = %v, want ServerModeExternal for an explicit-port workspace", mode)
		}
	})

	t.Run("explicit_server_mode_env_is_external", func(t *testing.T) {
		clearModeEnv(t)
		t.Setenv("BEADS_DOLT_SERVER_MODE", "1")
		dir := t.TempDir()
		if mode := ResolveServerMode(dir); mode != ServerModeExternal {
			t.Errorf("ResolveServerMode = %v, want ServerModeExternal under explicit server-mode env", mode)
		}
	})
}
