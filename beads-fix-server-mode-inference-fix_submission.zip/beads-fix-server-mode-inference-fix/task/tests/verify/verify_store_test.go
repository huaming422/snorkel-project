// Contract test for the PRIMARY data-path connect-failure hint.
//
// Injected into internal/storage/dolt as `package dolt` so it compiles
// alongside the package's existing in-package tests and drives the behavior
// through the pre-existing, unexported-but-in-package entry point that a normal
// remote data command actually reaches:
//   - newServerMode(ctx, *Config) (*DoltStore, error)   (asserting the
//     returned connect-failure error text for a remote server)
//
// This is the parallel surface to the internal/doltserver EnsureRunningDetailed
// hint already covered by verify_doltserver_test.go's
// TestVerifyUnreachableHintForRemoteHost. For a non-localhost server,
// auto-start is gated off (the open never routes through EnsureRunningDetailed),
// so the hint a normal `bd` data command prints comes from this path instead.
// A fix that only corrects the EnsureRunningDetailed hint still leaves this
// path advising the local start command for a remote host.
//
// Inputs are supplied entirely through the pre-existing exported Config struct
// fields (ServerHost / ServerPort / Path / AutoStart) — the same fields the
// package's own port_provenance_test.go drives newServerMode with. No internal
// helper introduced by a fix is referenced by name. BEADS_TEST_MODE=1 disables
// the real circuit breaker so no state files are touched (matching
// port_provenance_test.go's baseAutoStartCfg).

package dolt

import (
	"context"
	"strings"
	"testing"
)

// TestVerifyStoreUnreachableHintForRemoteHost covers the primary data-path
// connect-failure messaging: when a normal store open targets a non-localhost
// server that is unreachable, the error must name the external host and must
// NOT advise running the local start command. AutoStart is enabled so that, on
// an unfixed tree, the host does not merely disable auto-start but falls through
// to the generic "Try: bd dolt start" hint — the exact wrong advice base.md
// names, emitted on the path a remote command actually hits. (criterion C6,
// primary store surface)
func TestVerifyStoreUnreachableHintForRemoteHost(t *testing.T) {
	// A non-localhost host that nothing listens on: TEST-NET-1 (RFC 5737) is a
	// documented non-routable range, and port 1 has no listener, so the dial
	// fails well within the fail-fast timeout and no real server is contacted.
	const remoteHost = "192.0.2.10"

	// Disable the real circuit breaker (no state files) exactly as the
	// package's own auto-start tests do.
	t.Setenv("BEADS_TEST_MODE", "1")

	cfg := &Config{
		Database:   "beads",
		Path:       t.TempDir(),
		ServerHost: remoteHost,
		ServerPort: 1,
		// AutoStart is on, but the remote host gates auto-start off anyway;
		// the open therefore surfaces the connect-failure hint directly.
		AutoStart: true,
	}

	_, err := newServerMode(context.Background(), cfg)
	if err == nil {
		t.Fatal("newServerMode: err = nil, want an unreachable-server error for a remote external server")
	}
	msg := err.Error()
	if !strings.Contains(msg, remoteHost) {
		t.Errorf("unreachable error must name the external host %s; got: %s", remoteHost, msg)
	}
	if strings.Contains(msg, "bd dolt start") {
		t.Errorf("unreachable error for a remote server must not advise the local 'bd dolt start' command; got: %s", msg)
	}
}
