// Contract test for storage-mode resolution on the loaded workspace config.
//
// Injected into internal/configfile as `package configfile` so it compiles
// alongside the package's existing in-package tests and drives the behavior
// through the pre-existing, exported predicates only:
//   - (*Config).IsDoltServerMode() bool
//   - (*Config).GetDoltMode() string      (vs DoltModeServer / DoltModeEmbedded)
//   - (*Config).IsDoltProxiedServerMode() bool
// Host and mode inputs are supplied through the pre-existing struct fields
// (Backend, DoltServerHost, DoltMode) and the three documented sources with a
// defined precedence: the BEADS_DOLT_SERVER_HOST environment variable, the
// per-workspace config struct, and the user-global config.yaml (dolt.host /
// dolt.mode). No internal helper introduced by a fix is referenced by name.
//
// The subtests are sequential (no t.Parallel): several drive the process-global
// config.yaml layer, which is reset between cases.

package configfile

import (
	"os"
	"path/filepath"
	"testing"

	"github.com/steveyegge/beads/internal/config"
)

// resetGlobalConfig clears any process-global config.yaml state so a case that
// does not establish its own config.yaml observes an empty user-global layer.
func resetGlobalConfig(t *testing.T) {
	t.Helper()
	config.ResetForTesting()
	t.Cleanup(config.ResetForTesting)
}

// initGlobalConfigYAML writes a config.yaml into a temp dir and points the
// loader at it through BEADS_DIR, mirroring how the user-global layer is read.
func initGlobalConfigYAML(t *testing.T, body string) {
	t.Helper()
	dir := t.TempDir()
	if err := os.WriteFile(filepath.Join(dir, "config.yaml"), []byte(body), 0o600); err != nil {
		t.Fatal(err)
	}
	t.Setenv("BEADS_DIR", dir)
	if err := config.Initialize(); err != nil {
		t.Fatalf("config.Initialize: %v", err)
	}
	t.Cleanup(config.ResetForTesting)
}

// TestVerifyStorageModeHostInference covers the storage-mode predicate: a
// configured non-localhost host (via env var, the per-workspace config struct,
// or config.yaml, following the effective-host precedence) must report server
// mode; localhost and empty hosts must report embedded. (criterion C1)
func TestVerifyStorageModeHostInference(t *testing.T) {
	t.Run("env_host_ipv4_infers_server", func(t *testing.T) {
		resetGlobalConfig(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "192.0.2.10")
		cfg := &Config{Backend: BackendDolt}
		if !cfg.IsDoltServerMode() {
			t.Error("IsDoltServerMode() = false, want true for a remote env host")
		}
	})

	t.Run("env_host_name_infers_server", func(t *testing.T) {
		resetGlobalConfig(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "dolt-primary.internal.example.com")
		cfg := &Config{Backend: BackendDolt}
		if !cfg.IsDoltServerMode() {
			t.Error("IsDoltServerMode() = false, want true for a remote env hostname")
		}
	})

	t.Run("config_struct_host_infers_server", func(t *testing.T) {
		resetGlobalConfig(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "")
		cfg := &Config{Backend: BackendDolt, DoltServerHost: "10.0.0.5"}
		if !cfg.IsDoltServerMode() {
			t.Error("IsDoltServerMode() = false, want true for a remote per-workspace host")
		}
	})

	t.Run("config_yaml_host_infers_server", func(t *testing.T) {
		// No env host set: the config.yaml fallback layer must infer by itself.
		t.Setenv("BEADS_DOLT_SERVER_HOST", "")
		initGlobalConfigYAML(t, "dolt.host: 100.64.0.1\n")
		cfg := &Config{Backend: BackendDolt}
		if !cfg.IsDoltServerMode() {
			t.Error("IsDoltServerMode() = false, want true for a remote config.yaml host")
		}
	})

	t.Run("env_host_localhost_stays_embedded", func(t *testing.T) {
		resetGlobalConfig(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "localhost")
		cfg := &Config{Backend: BackendDolt}
		if cfg.IsDoltServerMode() {
			t.Error("IsDoltServerMode() = true, want false for a localhost env host")
		}
	})

	t.Run("env_host_loopback_ip_stays_embedded", func(t *testing.T) {
		resetGlobalConfig(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "127.0.0.1")
		cfg := &Config{Backend: BackendDolt}
		if cfg.IsDoltServerMode() {
			t.Error("IsDoltServerMode() = true, want false for a 127.0.0.1 env host")
		}
	})

	t.Run("env_host_all_zeros_treated_local", func(t *testing.T) {
		// 0.0.0.0 classifies as local for inference purposes.
		resetGlobalConfig(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "0.0.0.0")
		cfg := &Config{Backend: BackendDolt}
		if cfg.IsDoltServerMode() {
			t.Error("IsDoltServerMode() = true, want false for a 0.0.0.0 env host")
		}
	})

	t.Run("empty_host_stays_embedded", func(t *testing.T) {
		resetGlobalConfig(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "")
		cfg := &Config{Backend: BackendDolt}
		if cfg.IsDoltServerMode() {
			t.Error("IsDoltServerMode() = true, want false with no configured host")
		}
	})

	t.Run("config_struct_host_localhost_stays_embedded", func(t *testing.T) {
		resetGlobalConfig(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "")
		cfg := &Config{Backend: BackendDolt, DoltServerHost: "localhost"}
		if cfg.IsDoltServerMode() {
			t.Error("IsDoltServerMode() = true, want false for a localhost per-workspace host")
		}
	})
}

// TestVerifyEffectiveModeGetter covers the effective-mode getter: it must
// report the server mode string when host inference selects server mode but no
// explicit mode is persisted (today it reports embedded). (criterion C3)
func TestVerifyEffectiveModeGetter(t *testing.T) {
	t.Run("remote_env_host_no_mode_reports_server", func(t *testing.T) {
		resetGlobalConfig(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "192.0.2.10")
		cfg := &Config{Backend: BackendDolt}
		if got := cfg.GetDoltMode(); got != DoltModeServer {
			t.Errorf("GetDoltMode() = %q, want %q for a remote host with no persisted mode", got, DoltModeServer)
		}
	})

	t.Run("remote_struct_host_no_mode_reports_server", func(t *testing.T) {
		resetGlobalConfig(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "")
		cfg := &Config{Backend: BackendDolt, DoltServerHost: "10.0.0.5"}
		if got := cfg.GetDoltMode(); got != DoltModeServer {
			t.Errorf("GetDoltMode() = %q, want %q for a remote host with no persisted mode", got, DoltModeServer)
		}
	})

	t.Run("localhost_no_mode_reports_embedded", func(t *testing.T) {
		resetGlobalConfig(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "")
		cfg := &Config{Backend: BackendDolt, DoltServerHost: "localhost"}
		if got := cfg.GetDoltMode(); got != DoltModeEmbedded {
			t.Errorf("GetDoltMode() = %q, want %q for a localhost host with no persisted mode", got, DoltModeEmbedded)
		}
	})
}

// TestVerifyInferencePrecedenceAndGates covers the precedence and gate cases:
// a non-empty env host decides alone (a remote value wins over stale embedded
// metadata; an explicit localhost value suppresses lower-priority hosts; an
// empty env value is ignored, not suppression); an explicit persisted mode
// disables host inference; proxied mode is exempt; and the effective-host
// precedence (env > per-workspace struct > config.yaml) is honored so a
// lower-priority host cannot flip the mode. (criterion C4)
func TestVerifyInferencePrecedenceAndGates(t *testing.T) {
	t.Run("empty_env_not_suppression_struct_host_wins", func(t *testing.T) {
		// An EMPTY env value is "no signal": the remote per-workspace host
		// stays effective and still infers server mode.
		resetGlobalConfig(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "")
		cfg := &Config{Backend: BackendDolt, DoltServerHost: "10.0.0.5"}
		if !cfg.IsDoltServerMode() {
			t.Error("IsDoltServerMode() = false, want true: empty env host must not mask the remote per-workspace host")
		}
	})

	t.Run("explicit_localhost_env_suppresses_remote_struct_host", func(t *testing.T) {
		// An explicit localhost env value deliberately suppresses inference
		// from lower-priority hosts.
		resetGlobalConfig(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "localhost")
		cfg := &Config{Backend: BackendDolt, DoltServerHost: "10.0.0.5"}
		if cfg.IsDoltServerMode() {
			t.Error("IsDoltServerMode() = true, want false: explicit localhost env must suppress the lower-priority remote host")
		}
	})

	t.Run("remote_env_beats_stale_embedded_metadata", func(t *testing.T) {
		// Runtime env host beats a stale persisted embedded mode.
		resetGlobalConfig(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "192.0.2.10")
		cfg := &Config{Backend: BackendDolt, DoltMode: DoltModeEmbedded}
		if !cfg.IsDoltServerMode() {
			t.Error("IsDoltServerMode() = false, want true: a remote env host must win over stale embedded metadata")
		}
	})

	t.Run("explicit_embedded_metadata_wins_over_struct_host", func(t *testing.T) {
		// An explicit persisted mode is the operator's stated intent and
		// disables host inference from a persisted host.
		resetGlobalConfig(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "")
		cfg := &Config{Backend: BackendDolt, DoltMode: DoltModeEmbedded, DoltServerHost: "10.0.0.5"}
		if cfg.IsDoltServerMode() {
			t.Error("IsDoltServerMode() = true, want false: explicit embedded mode must win over a persisted remote host")
		}
	})

	t.Run("proxied_mode_not_reclassified_by_env_host", func(t *testing.T) {
		// Proxied-server workspaces are exempt; server mode and proxied mode
		// are mutually exclusive.
		resetGlobalConfig(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "192.0.2.10")
		cfg := &Config{Backend: BackendDolt, DoltMode: DoltModeProxiedServer}
		if cfg.IsDoltServerMode() {
			t.Error("IsDoltServerMode() = true, want false for a proxied-server workspace with a remote env host")
		}
		if !cfg.IsDoltProxiedServerMode() {
			t.Error("IsDoltProxiedServerMode() = false, want true for a proxied-server workspace")
		}
	})

	t.Run("struct_localhost_masks_config_yaml_remote_host", func(t *testing.T) {
		// Effective-host precedence: a higher-priority localhost per-workspace
		// host must mask a lower-priority remote config.yaml host that the
		// dialer would ignore.
		t.Setenv("BEADS_DOLT_SERVER_HOST", "")
		initGlobalConfigYAML(t, "dolt.host: 100.64.0.1\n")
		cfg := &Config{Backend: BackendDolt, DoltServerHost: "localhost"}
		if cfg.IsDoltServerMode() {
			t.Error("IsDoltServerMode() = true, want false: a localhost per-workspace host must mask the remote config.yaml host")
		}
	})

	t.Run("remote_env_host_wins_over_config_yaml_embedded_mode", func(t *testing.T) {
		// Env-host inference runs ahead of the config.yaml mode layer.
		t.Setenv("BEADS_DOLT_SERVER_HOST", "192.0.2.10")
		initGlobalConfigYAML(t, "dolt.mode: embedded\n")
		cfg := &Config{Backend: BackendDolt}
		if !cfg.IsDoltServerMode() {
			t.Error("IsDoltServerMode() = false, want true: a remote env host must win over config.yaml dolt.mode: embedded")
		}
	})

	t.Run("config_yaml_embedded_mode_wins_over_config_yaml_host", func(t *testing.T) {
		// An explicit config.yaml mode disables inference from the config.yaml
		// host.
		t.Setenv("BEADS_DOLT_SERVER_HOST", "")
		initGlobalConfigYAML(t, "dolt.mode: embedded\ndolt.host: 100.64.0.1\n")
		cfg := &Config{Backend: BackendDolt}
		if cfg.IsDoltServerMode() {
			t.Error("IsDoltServerMode() = true, want false: explicit config.yaml dolt.mode: embedded must win over dolt.host inference")
		}
	})
}

// TestVerifyPreservedModeBehaviorConfigfile is the configfile-package half of
// the regression guard: localhost defaults and explicit persisted modes must
// resolve exactly as before host inference existed. (criterion C7)
func TestVerifyPreservedModeBehaviorConfigfile(t *testing.T) {
	t.Run("localhost_default_is_embedded", func(t *testing.T) {
		resetGlobalConfig(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "")
		cfg := &Config{Backend: BackendDolt}
		if cfg.IsDoltServerMode() {
			t.Error("IsDoltServerMode() = true, want false for a default localhost workspace")
		}
		if got := cfg.GetDoltMode(); got != DoltModeEmbedded {
			t.Errorf("GetDoltMode() = %q, want %q for a default workspace", got, DoltModeEmbedded)
		}
	})

	t.Run("explicit_embedded_metadata_is_embedded", func(t *testing.T) {
		resetGlobalConfig(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "")
		cfg := &Config{Backend: BackendDolt, DoltMode: DoltModeEmbedded}
		if cfg.IsDoltServerMode() {
			t.Error("IsDoltServerMode() = true, want false for explicit embedded metadata")
		}
		if got := cfg.GetDoltMode(); got != DoltModeEmbedded {
			t.Errorf("GetDoltMode() = %q, want %q", got, DoltModeEmbedded)
		}
	})

	t.Run("explicit_server_metadata_is_server", func(t *testing.T) {
		resetGlobalConfig(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "")
		cfg := &Config{Backend: BackendDolt, DoltMode: DoltModeServer}
		if !cfg.IsDoltServerMode() {
			t.Error("IsDoltServerMode() = false, want true for explicit server metadata")
		}
		if got := cfg.GetDoltMode(); got != DoltModeServer {
			t.Errorf("GetDoltMode() = %q, want %q", got, DoltModeServer)
		}
	})

	t.Run("shared_server_env_is_server", func(t *testing.T) {
		resetGlobalConfig(t)
		t.Setenv("BEADS_DOLT_SERVER_HOST", "")
		t.Setenv("BEADS_DOLT_SHARED_SERVER", "1")
		cfg := &Config{Backend: BackendDolt}
		if !cfg.IsDoltServerMode() {
			t.Error("IsDoltServerMode() = false, want true under shared-server mode")
		}
	})
}
