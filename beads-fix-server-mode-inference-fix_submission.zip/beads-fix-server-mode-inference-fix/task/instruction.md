## Task

we've had reports that pointing beads at a Dolt server on another machine goes sideways. if someone sets just the server host to a remote address and changes nothing else, the CLI quietly reads and writes a local database instead of the remote server, so their writes seem to vanish or the data ends up looking split across two stores.

and when that configured server is unreachable, the error tells them to start a local server, which is the wrong advice for a server they're running on another box.

dig in and fix it.
