#!/usr/bin/env bash
# Environment bootstrap for the test run.
#
# claudian is tested with ts-jest, which transforms TypeScript on the fly, so
# there is no dist/ build step: a src/ edit is visible to jest immediately. The
# image build already ran `npm ci` at the base commit (Dockerfile step 7), so
# the full dependency closure, including ts-jest and jest, is present. This
# script only re-asserts that closure and, where a system python3 lacks a TOML
# parser, tries to add one.
#
# Sourced (not exec'd) by the test runner so env vars set here stay live for
# the test subprocess.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/claudian}"
export REPO_DIR
cd "$REPO_DIR"

# The test runner reads verify.toml via tomllib (Python 3.11+) or tomli
# (<=3.10). In this image it runs on its own Python 3.12 (/opt/tooling/venv,
# which has tomllib), and the image has no system python3, so this block is a
# no-op here. It is kept for an image that does ship an older python3: without
# a parser, verify.toml is silently dropped and the runner falls back to an
# invocation that does not match this repo's jest setup. Without network access
# the install fails, which is tolerated (|| true).
if ! python3 -c "import tomllib" >/dev/null 2>&1 && \
   ! python3 -c "import tomli"   >/dev/null 2>&1; then
    python3 -m pip install --quiet "tomli==2.0.1" \
        || python3 -m pip install --break-system-packages --quiet "tomli==2.0.1" \
        || true
fi

# Sanity check: jest and ts-jest must be resolvable from the workspace. A
# failure here points at a corrupted node_modules — bailing now with a clear
# message beats a confusing "jest: not found" inside the runner. The reinstall
# is offline-first: npm ci reuses the warm cache baked into the image.
if ! [ -x node_modules/.bin/jest ] || ! [ -d node_modules/ts-jest ]; then
    echo "test-setup.sh: jest/ts-jest missing from node_modules. Re-running npm ci." >&2
    npm ci --prefer-offline --no-audit --cache /opt/cache/npm
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR jest=$(node_modules/.bin/jest --version 2>/dev/null || echo unknown)"
