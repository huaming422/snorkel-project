package pdf

import (
	"testing"

	pdftype "ragflow/internal/deepdoc/parser/pdf/type"
)

// TestMatchCharsToBoxes_FullyContainedSmallOvershoot — fail_to_pass.
//
// A small glyph (h=8.1) whose top rises ~0.65pt above a tall box's edge has an
// overlap ratio of ~0.92 (NOT >= 0.95). It is still an inline glyph of that box
// (sub-point detection noise), so the deferred inline-glyph path must absorb
// it. Pre-fix the acceptance bound is 0.95, so the glyph is rejected and its
// character goes missing from the extracted text; post-fix (bound relaxed into
// the ~0.88..0.95 range) it is kept.
func TestMatchCharsToBoxes_FullyContainedSmallOvershoot(t *testing.T) {
	box := ocrDetectBox{
		box: pdftype.TextBox{X0: 70, X1: 763, Top: 494, Bottom: 528.7},
		x0:  70, y0: 494, x1: 763, y1: 528.7,
	}
	boxes := []ocrDetectBox{box}
	chars := []pdftype.TextChar{
		{Text: "在", X0: 100, X1: 112, Top: 500, Bottom: 512},       // normal, h=12
		{Text: "①", X0: 100, X1: 108, Top: 493.35, Bottom: 501.45}, // h=8.1, top 0.65pt above box -> overlap ~0.92
	}
	got := matchCharsToBoxes(boxes, chars)
	if len(got) != 1 {
		t.Fatalf("expected 1 box group, got %d", len(got))
	}
	found := false
	for _, c := range got[0] {
		if c.Text == "①" {
			found = true
		}
	}
	if !found {
		t.Errorf("small glyph with 0.92 overlap (0.6pt top overshoot) must be kept as inline content, got %+v", got[0])
	}
}

// A glyph that only partly overlaps a text box must not be kept as inline text,
// even when the box also contains a normal character.
func TestMatchCharsToBoxes_PartialOverlapHeightFiltered(t *testing.T) {
	box := ocrDetectBox{
		box: pdftype.TextBox{X0: 0, X1: 90, Top: 0, Bottom: 40},
		x0:  0, y0: 0, x1: 90, y1: 40,
	}
	boxes := []ocrDetectBox{box}
	// The normal character makes the box eligible for deferred glyphs.
	// The small 'x' overlaps only 3 of its 5 points and should stay out.
	chars := []pdftype.TextChar{
		{X0: 20, X1: 50, Top: 5, Bottom: 35, Text: "在"},
		{X0: 5, X1: 12, Top: -2, Bottom: 3, Text: "x"},
	}
	got := matchCharsToBoxes(boxes, chars)
	if len(got) != 1 {
		t.Fatalf("expected 1 box group, got %d", len(got))
	}
	foundNormal := false
	for _, c := range got[0] {
		if c.Text == "在" {
			foundNormal = true
		}
		if c.Text == "x" {
			t.Errorf("partial-overlap glyph must not be kept, got %+v", got[0])
		}
	}
	if !foundNormal {
		t.Errorf("normal text was lost: %+v", got[0])
	}
}
