## Task

Some PDFs produce corrupted extracted text even though parsing finishes without an error. Scanned pages and documents with irregular indentation, such as tables of contents and footnotes, are especially affected. Characters are sometimes missing or repeated, and lines can appear out of order.

Find and fix the problem in PDF parsing rather than cleaning up the extracted text afterward. Documents that already extract correctly should keep working.
