// Behavioral verifier for datafusion-fix-coerced-literal-args.
//
// Injected by the rust runner into datafusion/core/tests/ and run with
//   cargo test --test verify_test --manifest-path=datafusion/core/Cargo.toml
// (package name `datafusion`). It drives a real SessionContext plan+execute so
// the type-coercion analyzer pass actually runs, and observes the per-argument
// constant metadata from inside a custom ScalarUDFImpl's return-field hook.
//
// Everything imported here is pre-existing public API at the base commit. No
// internal helper introduced by any particular fix is referenced; each test
// asserts the VALUES handed to the return-field hook (and one SQL error),
// never where in the pipeline they were produced, so any correct
// decomposition of the fix satisfies them.

use std::sync::Arc;

use arrow::array::{Int16Array, RecordBatch};
use arrow::datatypes::{DataType, Field, FieldRef, Schema};

use datafusion::prelude::{SessionContext, col};

use datafusion_common::types::{NativeType, logical_int16, logical_int32};
use datafusion_common::{Result, assert_contains};
use datafusion_expr::{
    ColumnarValue, ReturnFieldArgs, ScalarFunctionArgs, ScalarUDF, ScalarUDFImpl,
    Signature, TypeSignatureClass, Volatility,
};
use datafusion_expr_common::signature::Coercion;

/// What the custom function expects of the constant-argument slot it is handed
/// for argument 0 when its return field is being resolved.
#[derive(Debug, PartialEq, Eq, Hash)]
enum ConstantExpectation {
    /// The slot must be populated and its value's type must equal the resolved
    /// field type for the same argument.
    PresentAndTypeMatches,
    /// The slot must be empty (the argument is not a genuine constant).
    Absent,
    /// Make no claim about the slot (used where the slot legitimately changes
    /// across planning stages, e.g. a literal that cannot take the coerced
    /// type and is therefore carried as an expression).
    Unchecked,
}

/// A custom scalar function whose signature coerces its single argument to a
/// narrower integer type, and whose return-field hook checks the constant it is
/// handed against the resolved argument field type. A violated expectation
/// panics, which fails the planning call and thus the test.
#[derive(Debug, PartialEq, Eq, Hash)]
struct ContractUdf {
    name: &'static str,
    expectation: ConstantExpectation,
    signature: Signature,
}

impl ContractUdf {
    fn new(
        name: &'static str,
        expectation: ConstantExpectation,
        target: TypeSignatureClass,
        default_native: NativeType,
    ) -> Self {
        Self {
            name,
            expectation,
            signature: Signature::coercible(
                vec![Coercion::new_implicit(
                    target,
                    vec![TypeSignatureClass::Numeric],
                    default_native,
                )],
                Volatility::Immutable,
            ),
        }
    }

    fn to_int16(name: &'static str, expectation: ConstantExpectation) -> Self {
        Self::new(
            name,
            expectation,
            TypeSignatureClass::Native(logical_int16()),
            NativeType::Int16,
        )
    }

    fn to_int32(name: &'static str, expectation: ConstantExpectation) -> Self {
        Self::new(
            name,
            expectation,
            TypeSignatureClass::Native(logical_int32()),
            NativeType::Int32,
        )
    }
}

impl ScalarUDFImpl for ContractUdf {
    fn name(&self) -> &str {
        self.name
    }

    fn signature(&self) -> &Signature {
        &self.signature
    }

    fn return_type(&self, _arg_types: &[DataType]) -> Result<DataType> {
        // return_field_from_args is implemented; this path is not taken.
        unreachable!("return_field_from_args is implemented for {}", self.name)
    }

    fn return_field_from_args(&self, args: ReturnFieldArgs) -> Result<FieldRef> {
        assert_eq!(
            args.arg_fields.len(),
            1,
            "{} should receive exactly one argument field",
            self.name
        );
        assert_eq!(
            args.scalar_arguments.len(),
            1,
            "{} should receive exactly one constant-argument slot",
            self.name
        );

        match self.expectation {
            ConstantExpectation::PresentAndTypeMatches => {
                let scalar = args.scalar_arguments[0].unwrap_or_else(|| {
                    panic!(
                        "{}: a plain literal argument was reported as not a \
                         constant",
                        self.name
                    )
                });
                assert_eq!(
                    &scalar.data_type(),
                    args.arg_fields[0].data_type(),
                    "{}: the constant's type disagrees with the resolved \
                     argument field type",
                    self.name
                );
            }
            ConstantExpectation::Absent => {
                assert!(
                    args.scalar_arguments[0].is_none(),
                    "{}: a non-literal argument was reported as a constant",
                    self.name
                );
            }
            ConstantExpectation::Unchecked => {}
        }

        Ok(Field::new(self.name, args.arg_fields[0].data_type().clone(), true).into())
    }

    fn invoke_with_args(&self, args: ScalarFunctionArgs) -> Result<ColumnarValue> {
        Ok(args.args[0].clone())
    }
}

/// A plain integer literal passed where the signature coerces that argument to
/// a narrower integer type is reported to the return-field hook as a present
/// constant whose value type equals the resolved (coerced) field type.
///
/// Pre-fix the coercion pass rewrites the literal into an expression cast, so
/// the hook is told the constant is absent — this test fails there.
#[tokio::test]
async fn literal_matches_coerced_field() -> Result<()> {
    let ctx = SessionContext::new();
    let udf: ScalarUDF =
        ContractUdf::to_int16("literal_match_udf", ConstantExpectation::PresentAndTypeMatches)
            .into();
    ctx.register_udf(udf);

    ctx.sql("select literal_match_udf(1)")
        .await?
        .collect()
        .await?;

    Ok(())
}

/// A NULL literal passed to a coercing argument is reported as a present,
/// coerced-type-typed null (not an untyped null and not absent).
///
/// Pre-fix the NULL is also rewritten into an expression cast and reported as
/// absent — this test fails there.
#[tokio::test]
async fn typed_null_matches_coerced_field() -> Result<()> {
    let ctx = SessionContext::new();
    let udf: ScalarUDF =
        ContractUdf::to_int16("typed_null_udf", ConstantExpectation::PresentAndTypeMatches)
            .into();
    ctx.register_udf(udf);

    ctx.sql("select typed_null_udf(NULL)")
        .await?
        .collect()
        .await?;

    Ok(())
}

/// A column (non-constant) argument is reported to the return-field hook as not
/// a constant, both before and after the fix. Guards against a fix that
/// over-eagerly materializes non-constants into constants.
#[tokio::test]
async fn column_argument_reported_as_none() -> Result<()> {
    let ctx = SessionContext::new();
    let udf: ScalarUDF =
        ContractUdf::to_int16("column_arg_udf", ConstantExpectation::Absent).into();
    let udf_clone = udf.clone();
    ctx.register_udf(udf);

    let batch = RecordBatch::try_new(
        Arc::new(Schema::new(vec![Field::new("a", DataType::Int16, false)])),
        vec![Arc::new(Int16Array::from(vec![1_i16, 2, 3]))],
    )?;
    ctx.read_batch(batch)?
        .select(vec![udf_clone.call(vec![col("a")])])?
        .collect()
        .await?;

    Ok(())
}

/// The second argument to arrow_cast, written as a cast rather than a genuine
/// constant string, must keep being rejected rather than being treated as a
/// constant type argument. This is the SQL-observable guard that a user-written
/// cast is still handled as an expression (not unwrapped into a constant): a
/// change that recursively unwraps casts into constants makes this stop
/// erroring.
///
/// (A per-UDF "a bare `cast(const as T)` argument is reported as not a
/// constant" check cannot be observed through this public query path: a cast of
/// a literal is constant-folded into a plain literal before the return-field
/// hook runs at physical planning, so such an argument is reported as a genuine
/// constant regardless of how argument coercion is implemented. This arrow_cast
/// type-argument query is the honest public-interface observable for the
/// explicit-cast-stays-an-expression contract.)
#[tokio::test]
async fn arrow_cast_requires_literal_type_arg() -> Result<()> {
    let ctx = SessionContext::new();

    let planned = ctx.sql("select arrow_cast(1, cast('Utf8' as varchar))").await;
    let outcome = match planned {
        Err(e) => Err(e),
        Ok(df) => df.collect().await,
    };

    let err = outcome
        .expect_err("a cast type argument to arrow_cast must not be accepted as a constant");
    assert_contains!(err.to_string(), "second argument");

    Ok(())
}

/// A literal whose value cannot take the coerced argument type (here an
/// out-of-range integer) must be preserved so that EXECUTION yields an error,
/// the same as before the fix: planning must not error early, and the fix must
/// not fold a wrong value that would let collection succeed.
#[tokio::test]
async fn invalid_literal_value_preserved() -> Result<()> {
    let ctx = SessionContext::new();
    let udf: ScalarUDF =
        ContractUdf::to_int32("overflow_literal_udf", ConstantExpectation::Unchecked).into();
    ctx.register_udf(udf);

    // 2147483648 == i32::MAX + 1: a valid Int64 literal that cannot take Int32.
    let planned = ctx.sql("select overflow_literal_udf(2147483648)").await;
    let df = planned.expect("planning must not raise an early cast error");

    assert!(
        df.collect().await.is_err(),
        "an out-of-range literal must still fail at execution, not be folded to \
         a valid value"
    );

    Ok(())
}
