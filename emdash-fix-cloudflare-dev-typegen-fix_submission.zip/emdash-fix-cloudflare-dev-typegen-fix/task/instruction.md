## Task

running the CMS in local dev under the Cloudflare adapter (`@astrojs/cloudflare`), editing the content schema while the dev server is up no longer refreshes the generated editor types.

normally `emdash-env.d.ts` regenerates during `astro dev` so the types track the live schema. but if I add a collection, or a field to an existing one, through the admin after the server is already running, the file never picks it up. it stays frozen at whatever the schema was when `astro dev` first started. the generation at startup is correct; it's only edits made after that go stale. restarting the dev server regenerates the file fine, so the data is intact; only the live refresh fails.

this only happens under the Cloudflare adapter. the plain Node / SQLite local setup refreshes the types the moment the schema changes, same flow, no restart needed.

the fix belongs in `@emdash-cms/core`. dig in and sort it out.
