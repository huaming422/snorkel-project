#!/usr/bin/env bash
# Environment bootstrap for the TypeScript checks.
#
# Sourced (not exec'd) by the harbor runner, so env vars set here stay live for
# the test subprocess.
#
# The image already carries the full dependency closure baked offline at the
# base commit (pnpm store warm, node_modules installed with --frozen-lockfile).
# The checks run vitest, which transforms the TypeScript sources on the fly —
# no dist/ build step is required, and nothing new needs to be fetched. This
# script only asserts the toolchain is present and makes a cache miss fail fast
# instead of hanging against the cut network.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/emdash}"
export REPO_DIR
cd "$REPO_DIR"

# Fail fast on any accidental network reach during grading instead of retrying
# against the (offline) network.
export npm_config_offline=true

# Shared grading infrastructure runs under the canonical /opt/tooling venv.
export VERIFIER_PYTHON="${VERIFIER_PYTHON:-/opt/tooling/venv/bin/python}"

# Sanity check: the core package's vitest binary must be resolvable. A failure
# here points at a corrupted node_modules — bail now rather than surfacing a
# confusing "vitest: command not found" later. Offline-first: reinstall only
# falls back to the warm store, which the image already holds.
if ! [ -x node_modules/.bin/vitest ] && ! [ -x packages/core/node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing; reinstalling from the warm store." >&2
    pnpm install --frozen-lockfile --offline
fi

# Stage the scratch package the behavioral checks run from. They start a Vite
# dev server with the Cloudflare plugin, which must resolve vite@8,
# @cloudflare/vite-plugin and vitest. The labeler app already carries that exact
# closure, so the scratch package borrows its installed modules by symlink and
# ships a tiny vitest config that selects the copied test file. The runner copies
# the test file into this same directory and runs vitest with it as the cwd.
SCRATCH="$REPO_DIR/.verify-dtg"
BORROW_MODULES="$REPO_DIR/apps/labeler/node_modules"
if ! [ -d "$BORROW_MODULES" ]; then
    echo "test-setup.sh: expected module closure missing at $BORROW_MODULES" >&2
    exit 1
fi
mkdir -p "$SCRATCH"
ln -sfn "$BORROW_MODULES" "$SCRATCH/node_modules"
cat > "$SCRATCH/vitest.config.ts" <<'VITEST'
import { defineConfig } from "vitest/config";

export default defineConfig({
	test: { include: ["verify*.test.ts"], watch: false, fileParallelism: false },
});
VITEST

# Fail-loud guard: the plugin the checks depend on must be resolvable from the
# scratch package, or they would fail for an environment reason that reads like a
# wrong answer.
if ! [ -e "$SCRATCH/node_modules/@cloudflare/vite-plugin" ]; then
    echo "test-setup.sh: @cloudflare/vite-plugin not resolvable from $SCRATCH" >&2
    exit 1
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR node=$(node --version 2>/dev/null || echo unknown)"
