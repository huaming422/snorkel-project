import { describe, it, expect, vi, beforeAll, afterEach } from "vitest";
import { createServer, type Plugin, type ViteDevServer } from "vite";
import { cloudflare } from "@cloudflare/vite-plugin";
import { writeFileSync } from "node:fs";
import { resolve } from "node:path";

// The runner copies this file into the scratch package dir and runs vitest with
// that dir as the working directory. Its parent is the repository root, which
// holds the package under test. Everything is loaded by absolute path from
// there, so the test imports no suite-local sources.
const SCRATCH = process.cwd();
const REPO = resolve(SCRATCH, "..");
const ASTRO = REPO + "/packages/core/src/astro";
const DEV_TYPEGEN = ASTRO + "/dev-typegen.ts";
const MIDDLEWARE = ASTRO + "/middleware.ts";

// A no-op Astro logger that satisfies the integration's `astro:server:setup`
// signature. The shape mirrors AstroIntegrationLogger (an object with level
// methods, a fork factory, a label, and options).
const logger: any = {
	info() {},
	warn() {},
	error() {},
	debug() {},
	fork: () => logger,
	label: "verify",
	options: {} as any,
};

// Keys present on the shared object before any server run, so each case can be
// returned to that baseline afterward without assuming any specific key name.
let baselineGlobals: Set<string>;

// Build-time environment the worker's SSR bundle normally receives from the
// Astro integration's build. The real emdash request middleware
// (`astro/middleware.ts`) imports a fixed set of `virtual:emdash/*` modules the
// integration generates at build time, plus the heavy `emdash-runtime` hub,
// which in this repo is published as TypeScript source that would be compiled
// by that build. This dev harness loads `middleware.ts` straight from source
// into the worker realm, so it supplies the same two things the build would:
//
//   - the `virtual:emdash/*` modules (config is `null`, so the request takes
//     middleware's no-configuration fast path: it wraps `next()` in the real
//     request-context frame and runs the real response finalizer, with no
//     runtime or database);
//   - a stand-in for `emdash-runtime` — the runtime hub drags unbuilt
//     workspace packages at module-eval but is never instantiated on the
//     no-config path and is not part of the dev-typegen signal path at all.
//
// Nothing here touches the dev-typegen trigger, the request-context module, the
// integration's server-setup wiring, or the response finalizer — those stay the
// real sources a fix changes, so the worker runs the fix's actual
// request-pipeline behavior.
function emdashBuildEnv(): Plugin {
	const virtual: Record<string, string> = {
		"astro:middleware": `export const defineMiddleware = (fn) => fn;`,
		"virtual:emdash/build": `export const buildTime = undefined;`,
		"virtual:emdash/config": `export default null;`,
		"virtual:emdash/dialect":
			`export const createCoalescingDialect = () => null;` +
			`export const createDialect = () => null;` +
			`export const createRequestScopedDb = () => null;`,
		"virtual:emdash/media-providers": `export const mediaProviders = [];`,
		"virtual:emdash/plugins": `export const plugins = [];`,
		"virtual:emdash/sandbox-runner": `export const createSandboxRunner = () => null;`,
		"virtual:emdash/sandboxed-plugins": `export const sandboxedPlugins = [];`,
		"virtual:emdash/scheduler": `export const createScheduler = () => null;`,
		"virtual:emdash/storage": `export const createStorage = () => null;`,
		"virtual:emdash/wait-until": `export const waitUntil = undefined;`,
	};
	const runtimeStub = `export const DB_INIT_DEADLINE_MS = 0; export class EmDashRuntime {}`;
	return {
		name: "emdash-build-env",
		enforce: "pre",
		resolveId(id) {
			if (id in virtual) return "\0emdash-virtual:" + id;
			if (id.endsWith("/emdash-runtime.js") || id.endsWith("/emdash-runtime.ts")) {
				return "\0emdash-runtime";
			}
			return null;
		},
		load(id) {
			if (id.startsWith("\0emdash-virtual:")) return virtual[id.slice("\0emdash-virtual:".length)];
			if (id === "\0emdash-runtime") return runtimeStub;
			return null;
		},
	};
}

beforeAll(() => {
	baselineGlobals = new Set(Reflect.ownKeys(globalThis).map(String));

	writeFileSync(
		resolve(SCRATCH, "wrangler.json"),
		JSON.stringify({
			name: "cfworker",
			main: "worker.js",
			compatibility_date: "2026-05-14",
			compatibility_flags: ["nodejs_compat"],
		}),
	);

	// The worker fixture drives the dev-typegen trigger the way the running app
	// does: a request to `/trigger` runs the schema-mutation trigger INSIDE
	// emdash's real request middleware. `onRequest` establishes the request
	// context the fix's trigger code runs under and finalizes the response the
	// fix's response code can observe, so whatever realm-crossing transport the
	// fix chooses (a module hot-channel signal, a request-origin loopback back
	// to the Node dev server, a signal piggybacked on the response) sees exactly
	// the surfaces the real app gives it. The path is a plain app route, NOT a
	// schema API route, so a fix cannot pass by merely sniffing Node-visible
	// schema traffic — the signal has to leave the worker realm.
	writeFileSync(
		resolve(SCRATCH, "worker.js"),
		`import onRequest from ${JSON.stringify(MIDDLEWARE)};\n` +
			`import { refreshDevTypes } from ${JSON.stringify(DEV_TYPEGEN)};\n` +
			`export default {\n` +
			`  async fetch(req) {\n` +
			`    const url = new URL(req.url);\n` +
			`    if (url.pathname === "/trigger") {\n` +
			`      const ctx = {\n` +
			`        request: req,\n` +
			`        url,\n` +
			`        locals: {},\n` +
			`        cookies: { get: () => undefined },\n` +
			`        isPrerendered: false,\n` +
			`      };\n` +
			`      return await onRequest(ctx, async () => {\n` +
			`        refreshDevTypes();\n` +
			`        return new Response("triggered");\n` +
			`      });\n` +
			`    }\n` +
			`    return new Response("ok");\n` +
			`  },\n` +
			`};\n`,
	);
});

// Drive the real integration's server-setup hook so the host side is wired
// exactly the way a correct change requires, while standing a spy in for the
// pre-existing debounced refresh factory. This reads through the stable public
// surface only (the `emdash()` integration and the long-standing
// `createDebouncedTypegenRefresh` factory) and names nothing the change adds.
async function wireHostAndSpyRefresh(server: ViteDevServer) {
	const integrationDevTypegen: any = await import(ASTRO + "/integration/dev-typegen.ts");
	const integrationIndex: any = await import(ASTRO + "/integration/index.ts");

	const refresher = vi.fn();
	vi.spyOn(integrationDevTypegen, "createDebouncedTypegenRefresh").mockReturnValue(refresher);

	const integration = integrationIndex.emdash({});
	await integration.hooks["astro:server:setup"]!({ server, logger } as any);
	return refresher;
}

// Poll until the refresher has been called at least `atLeast` times or the
// deadline passes. Transports settle asynchronously (a hot-channel round trip,
// a loopback fetch, a response flushing through the Node stack), so wait for the
// observable outcome instead of a fixed sleep.
async function waitForCalls(fn: ReturnType<typeof vi.fn>, atLeast: number, timeoutMs = 8000) {
	const deadline = Date.now() + timeoutMs;
	while (fn.mock.calls.length < atLeast && Date.now() < deadline) {
		await new Promise((r) => setTimeout(r, 25));
	}
}

// In a real Astro + Cloudflare dev server, the emdash integration's
// server-setup endpoints are registered during Astro's own configureServer
// pass, which runs BEFORE the Cloudflare adapter appends its SSR catch-all
// dispatcher. So a dev-server endpoint the integration registers is matched
// ahead of the worker fall-through, and only requests with no explicit host
// handler reach the worker. This harness wires the host after createServer
// (which has already placed the adapter catch-all), so restore that ordering:
// move every middleware registered after the built-in baseline to the front,
// preserving relative order. This is transport-neutral — it knows nothing of
// which endpoint path (if any) the fix registered; it only re-establishes the
// real-app invariant that integration routes precede the SSR fall-through.
function hoistHostMiddlewares(server: ViteDevServer, baseline: WeakSet<object>) {
	const stack = (server.middlewares as any).stack as Array<{ handle: object }>;
	const host: typeof stack = [];
	const builtin: typeof stack = [];
	for (const entry of stack) (baseline.has(entry.handle) ? builtin : host).push(entry);
	stack.length = 0;
	stack.push(...host, ...builtin);
}

describe("dev typegen refresh", () => {
	let server: ViteDevServer | undefined;

	afterEach(async () => {
		try {
			await server?.close();
		} catch {}
		server = undefined;
		// Return the shared object to its pre-run baseline so the next case starts
		// clean, without assuming which key (if any) the host registered under.
		for (const k of Reflect.ownKeys(globalThis).map(String)) {
			if (!baselineGlobals.has(k)) Reflect.deleteProperty(globalThis as any, k);
		}
		vi.restoreAllMocks();
	});

	it("a refresh raised inside the Cloudflare worker realm reaches the host exactly once", async () => {
		server = await createServer({
			root: SCRATCH,
			configFile: false,
			logLevel: "error",
			appType: "custom",
			mode: "development",
			server: { port: 5330, strictPort: true, host: "127.0.0.1", ws: true, watch: null },
			plugins: [
				emdashBuildEnv(),
				cloudflare({
					configPath: resolve(SCRATCH, "wrangler.json"),
					persistState: false,
					remote: false,
					inspectorPort: false,
				}),
			],
		});

		// Snapshot the built-in vite/cloudflare middlewares before any host wiring.
		const baseline = new WeakSet<object>(
			((server.middlewares as any).stack as Array<{ handle: object }>).map((m) => m.handle),
		);

		const refresher = await wireHostAndSpyRefresh(server);
		await server.listen();
		// The host wiring runs an initial generation once the server is up; wait
		// for it, then isolate the triggered path so the assertion measures only
		// what the worker-realm refresh caused.
		await waitForCalls(refresher, 1);
		// Restore real-app routing: integration endpoints ahead of the SSR catch-all.
		hoistHostMiddlewares(server, baseline);
		expect(
			refresher.mock.calls.length,
			"host should run an initial type generation on startup",
		).toBeGreaterThanOrEqual(1);
		refresher.mockClear();

		// One schema-mutation request into the worker. Whatever realm-crossing
		// transport the fix uses, the host refresher must fire exactly once.
		await fetch("http://127.0.0.1:5330/trigger");
		await waitForCalls(refresher, 1);

		expect(
			refresher.mock.calls.length,
			"a worker-realm refresh must reach the host exactly once (0 = the signal never crossed the realm boundary)",
		).toBe(1);
	}, 120000);

	it("with hot messaging off, a same-realm refresh reaches the host exactly once", async () => {
		const trigger: any = await import(DEV_TYPEGEN);

		// A plain node dev server (no Cloudflare plugin): the trigger runs in the
		// same realm as the host, and the module graph defines no hot channel, so
		// this exercises the same-realm path the integration must keep working.
		server = await createServer({
			root: SCRATCH,
			configFile: false,
			logLevel: "error",
			appType: "custom",
			mode: "development",
			server: { port: 5331, strictPort: true, host: "127.0.0.1", ws: true, watch: null },
		});

		const refresher = await wireHostAndSpyRefresh(server);
		await server.listen();
		await waitForCalls(refresher, 1);
		expect(
			refresher.mock.calls.length,
			"host should run an initial type generation on startup",
		).toBeGreaterThanOrEqual(1);
		refresher.mockClear();

		trigger.refreshDevTypes();
		await waitForCalls(refresher, 1);

		expect(
			refresher.mock.calls.length,
			"a same-realm refresh must still reach the host exactly once when HMR is off",
		).toBe(1);
	}, 120000);
});
