#!/usr/bin/env bash
# Behavioural verifier for the host-collection element-write family.
#
# There is no native .NET test runner in the grading infrastructure, so this
# shell script is the runner: it drops the fixture that ships beside it into the
# public-surface test project, builds and runs that one fixture on the fast .NET
# 8 leg, and returns the suite's own pass/fail as this script's exit code.
#
#   exit 0  -> the whole fixture passed
#   exit !=0 -> the build failed, or any case in the fixture failed
#
# The fixture is placed into Jint.Tests.PublicInterface on purpose: that project
# compiles against Jint's published surface only, so the fixture can observe the
# behaviour through the public API and nothing else. The project globs **/*.cs by
# SDK default, so a copied-in file is compiled with no project edit.
set -uo pipefail

REPO="/repo/jint"
PROJ_DIR="${REPO}/Jint.Tests.PublicInterface"
PROJ="${PROJ_DIR}/Jint.Tests.PublicInterface.csproj"
FIXTURE_SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/HostCollectionElementWriteBehaviorTests.cs"
FIXTURE_DST="${PROJ_DIR}/HostCollectionElementWriteBehaviorTests.cs"
FILTER="HostCollectionElementWriteBehaviorTests"
LOG="/tmp/verify-dotnet.log"

export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1
export NUGET_PACKAGES="${NUGET_PACKAGES:-/opt/nuget/packages}"

if [[ ! -f "${FIXTURE_SRC}" ]]; then
    echo "[verify] fixture source not found at ${FIXTURE_SRC}" >&2
    exit 1
fi
if [[ ! -f "${PROJ}" ]]; then
    echo "[verify] test project not found at ${PROJ}" >&2
    exit 1
fi

# Place the fixture, then make sure it is removed again whatever happens, so a
# candidate's own clone is left as it was found.
cp "${FIXTURE_SRC}" "${FIXTURE_DST}"
cleanup() { rm -f "${FIXTURE_DST}"; }
trap cleanup EXIT

cd "${REPO}"

# Build and run only this fixture on the net8.0 leg (the net10.0 leg triggers an
# unrelated published-surface baseline cross-build that is slow and not needed
# here). A build error and a test failure both have to be non-zero; dotnet test
# returns non-zero for either, which is exactly the signal this script forwards.
dotnet test "${PROJ}" \
    -f net8.0 \
    -c Release \
    --filter "FullyQualifiedName~${FILTER}" \
    > "${LOG}" 2>&1
status=$?

if [[ ${status} -ne 0 ]]; then
    echo "[verify] dotnet test failed (exit ${status}); tail of ${LOG}:" >&2
    tail -80 "${LOG}" >&2
fi

exit ${status}
