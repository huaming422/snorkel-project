## Task

`bd config unset <key>` is lying about what it does. For some keys it prints
that it unset the setting and exits clean, but the value is still live right
afterward: `bd config get` and `bd config list` hand back the same thing as
before. This used to be reliable, and it bit us because someone unset a setting,
saw the success message, and the setting quietly stuck around.

It's not every key. It seems to depend on which key it is and how the value was
written into the config, so some cases clear fine and others only pretend to.
Figure out which cases are wrong and why, and make `unset` actually clear the
setting and report honestly about whether it did.

This is about how `unset` reports and carries out the clear. It's not a new
command or a change to the config schema.
