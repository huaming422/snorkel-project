//go:build cgo

// Subprocess-driven checks for `bd config unset`, exercised exactly the way the
// repo's own tests in this package do: build the tool once, run it as a child
// process, and read its stdout / stderr / exit status and the resulting
// config.yaml bytes. Nothing here imports the internal unset helpers, so a
// solution that restores honest reporting and safe refusal passes regardless of
// how it is structured inside the package.
//
// The checks assert BEHAVIOR, not wording or mechanism: a cleared key is
// verified by the live key line being gone from config.yaml (whether the
// implementation comments the line out or removes it), a refusal by a non-zero
// exit plus an untouched file, and honest reporting by the absence of the one
// false "(in config.yaml)" cleared-location claim the symptom is about. The
// exact success/no-op wording and the location string the command appends are
// the implementer's choice and are never asserted.
//
// Two tiers:
//   - YAML-only keys reach the YAML-only route without opening a workspace or a
//     database, so those cases need only a temp .beads/config.yaml and BEADS_DIR.
//   - Other keys reach the workspace-backed route and need a real `bd init`
//     workspace (embedded, in-process, offline).
//
// Reused helpers (buildEmbeddedBD, bdEnv, bdInit, runCommandBuffers) come from
// the package's existing test files; this file is injected into cmd/bd/.
package main

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

// cfg runs `bd config <args...>` with the given working dir and environment and
// returns stdout, stderr and the process exit code. Unlike bdConfig it does not
// fail the test on a non-zero exit, because the refusal cases exit non-zero on
// purpose.
func cfg(t *testing.T, bd, dir string, env []string, args ...string) (stdout, stderr string, code int) {
	t.Helper()
	cmd := exec.Command(bd, append([]string{"config"}, args...)...)
	cmd.Dir = dir
	cmd.Env = env
	outBuf, errBuf, err := runCommandBuffers(t, cmd)
	code = 0
	if err != nil {
		if exitErr, ok := err.(*exec.ExitError); ok {
			code = exitErr.ExitCode()
		} else {
			t.Fatalf("bd config %s: could not run: %v\nstderr:\n%s", strings.Join(args, " "), err, errBuf.String())
		}
	}
	return outBuf.String(), errBuf.String(), code
}

// yamlOnlyWorkspace writes a standalone .beads/config.yaml with the given body
// and returns the working dir and the environment (BEADS_DIR pointed at it) that
// routes a YAML-only unset straight at that file — no workspace, no database.
func yamlOnlyWorkspace(t *testing.T, bd, body string) (dir, configPath string, env []string) {
	t.Helper()
	home := t.TempDir()
	beadsDir := filepath.Join(home, ".beads")
	if err := os.MkdirAll(beadsDir, 0o755); err != nil {
		t.Fatalf("mkdir .beads: %v", err)
	}
	configPath = filepath.Join(beadsDir, "config.yaml")
	if err := os.WriteFile(configPath, []byte(body), 0o600); err != nil {
		t.Fatalf("write config.yaml: %v", err)
	}
	env = append(bdEnv(home), "BEADS_DIR="+beadsDir)
	return home, configPath, env
}

func readBytes(t *testing.T, path string) []byte {
	t.Helper()
	b, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read %s: %v", path, err)
	}
	return b
}

// topLevelKeyLive reports whether key appears as a live (uncommented) top-level
// entry in content: a line that begins at column zero with `key:`. A commented
// form ("# key: ...") starts with '#', and a nested same-named key is indented,
// so both are excluded. This is how the checks confirm a key is or is not still
// in effect without caring whether a clear comments the line out or deletes it.
func topLevelKeyLive(content, key string) bool {
	for _, ln := range strings.Split(content, "\n") {
		if strings.HasPrefix(ln, key+":") || strings.HasPrefix(ln, key+" :") {
			return true
		}
	}
	return false
}

// claimsClearedConfigYaml reports whether output carries the parenthesized
// cleared-location claim the symptom is about: `Unset <key> (in config.yaml)`.
// The honest no-op message ("... was not set in config.yaml") has no parens, so
// this matches only the false success claim, not any honest mention of the file.
func claimsClearedConfigYaml(output string) bool {
	return strings.Contains(output, "(in config.yaml)")
}

// TestVerifyConfigUnsetYAMLOnly covers every case that resolves through the
// YAML-only route: no workspace or database is created.
func TestVerifyConfigUnsetYAMLOnly(t *testing.T) {
	bd := buildEmbeddedBD(t)

	// An unset of a key the file does not contain must not announce a write it
	// never made. A broken command prints the cleared-location claim
	// unconditionally; an honest command reports that no clear happened. The
	// exact wording is the implementer's choice, so this asserts the ABSENCE of
	// the false cleared-location claim plus a clean exit and an untouched file.
	t.Run("crit_yaml_noop_reports_not_set", func(t *testing.T) {
		_, configPath, env := yamlOnlyWorkspace(t, bd, "issue_prefix: vp\nexport.auto: true\n")
		before := readBytes(t, configPath)

		stdout, _, code := cfg(t, bd, filepath.Dir(configPath), env, "unset", "backup.enabled")
		if code != 0 {
			t.Fatalf("unset of an absent yaml-only key should exit 0, got %d\nstdout:\n%s", code, stdout)
		}
		if claimsClearedConfigYaml(stdout) {
			t.Errorf("unset of a key the file never held falsely claimed a config.yaml write:\n%s", stdout)
		}
		if got := readBytes(t, configPath); string(got) != string(before) {
			t.Errorf("a no-op unset rewrote config.yaml:\nbefore: %q\nafter:  %q", before, got)
		}
	})

	// A present YAML-only key must actually be cleared: afterward it is no longer
	// a live top-level entry. This protects against an over-correction that
	// reports every unset as a no-op and stops clearing real keys. Clearing is
	// confirmed behaviorally (key no longer live), independent of whether the
	// implementation comments the line out or removes it.
	t.Run("crit_yaml_present_key_comments_out", func(t *testing.T) {
		_, configPath, env := yamlOnlyWorkspace(t, bd, "issue_prefix: vp\nbackup.enabled: true\n")

		stdout, _, code := cfg(t, bd, filepath.Dir(configPath), env, "unset", "backup.enabled")
		if code != 0 {
			t.Fatalf("unset of a present yaml-only key should exit 0, got %d\nstdout:\n%s", code, stdout)
		}
		if topLevelKeyLive(string(readBytes(t, configPath)), "backup.enabled") {
			t.Errorf("present key is still live after unset:\n%s", readBytes(t, configPath))
		}
	})

	// A second present-key case on a different YAML-only key: a normal present
	// key still unsets cleanly. Reinforces that honest reporting narrows the
	// success claim without regressing the actual clear.
	t.Run("crit_present_yaml_key_still_unsets", func(t *testing.T) {
		_, configPath, env := yamlOnlyWorkspace(t, bd, "issue_prefix: vp\nrouting.mode: auto\n")

		stdout, _, code := cfg(t, bd, filepath.Dir(configPath), env, "unset", "routing.mode")
		if code != 0 {
			t.Fatalf("unset of a present yaml-only key should exit 0, got %d\nstdout:\n%s", code, stdout)
		}
		if topLevelKeyLive(string(readBytes(t, configPath)), "routing.mode") {
			t.Errorf("present key is still live after unset:\n%s", readBytes(t, configPath))
		}
	})

	// A no-op unset on a CRLF file must leave the bytes identical. A broken
	// change-detection compares the editor's output (which normalizes CRLF to LF
	// as its first act) against the raw bytes, so on a CRLF file the two always
	// differ: every unset looks like a change, rewrites the whole file to LF, and
	// reports a success that never happened.
	t.Run("crit_crlf_absent_key_untouched", func(t *testing.T) {
		body := "issue_prefix: vp\r\nexport.auto: true\r\n"
		_, configPath, env := yamlOnlyWorkspace(t, bd, body)

		stdout, _, code := cfg(t, bd, filepath.Dir(configPath), env, "unset", "backup.enabled")
		if code != 0 {
			t.Fatalf("no-op unset on a CRLF file should exit 0, got %d\nstdout:\n%s", code, stdout)
		}
		if got := string(readBytes(t, configPath)); got != body {
			t.Errorf("a no-op unset rewrote a CRLF file:\ngot:  %q\nwant: %q", got, body)
		}
		if claimsClearedConfigYaml(stdout) {
			t.Errorf("no-op unset on a CRLF file falsely claimed a write:\n%s", stdout)
		}
	})

	// Unsetting a single-segment top-level key must not reach into a same-named
	// key nested under another section. A flat line matcher with no
	// top-level-indent check comments out the nested `  no-push:` line — a key
	// the caller never named. The nested line must survive unchanged.
	t.Run("crit_nested_key_not_falsely_matched", func(t *testing.T) {
		body := "issue_prefix: vp\nsomesection:\n  no-push: true\n"
		_, configPath, env := yamlOnlyWorkspace(t, bd, body)

		stdout, _, code := cfg(t, bd, filepath.Dir(configPath), env, "unset", "no-push")
		if code != 0 {
			t.Fatalf("unset of an absent top-level key should exit 0, got %d\nstdout:\n%s", code, stdout)
		}
		if after := string(readBytes(t, configPath)); !strings.Contains(after, "  no-push: true") {
			t.Errorf("unset of the top-level key disturbed a nested same-named key:\n%s", after)
		}
	})

	// A key whose value continues on the lines beneath it (a nested mapping or a
	// list) cannot be unset by commenting its one line out without orphaning the
	// rest and leaving a file that no longer parses. The command must refuse
	// (non-zero exit) and leave the file untouched rather than edit the line and
	// exit 0 as a naive line editor would.
	t.Run("crit_refuses_mapping_valued_key", func(t *testing.T) {
		cases := []struct {
			name, body, key string
		}{
			{"mapping_nested", "directory:\n  labels:\n    a: x\n", "directory.labels"},
			{"list_nested", "sync:\n  remotes:\n    - a\n    - b\n", "sync.remotes"},
			{"list_own_indent", "routing:\n  extra:\n  - x\n", "routing.extra"},
		}
		for _, tc := range cases {
			t.Run(tc.name, func(t *testing.T) {
				_, configPath, env := yamlOnlyWorkspace(t, bd, tc.body)
				before := readBytes(t, configPath)

				stdout, stderr, code := cfg(t, bd, filepath.Dir(configPath), env, "unset", tc.key)
				if code == 0 {
					t.Errorf("unset of %q (value continues below) should have been refused; exited 0\nstdout:\n%s", tc.key, stdout)
				}
				if got := readBytes(t, configPath); string(got) != string(before) {
					t.Errorf("a refused unset of %q still rewrote config.yaml:\nbefore: %q\nafter:  %q\nstderr:\n%s",
						tc.key, before, got, stderr)
				}
			})
		}
	})
}

// TestVerifyConfigUnsetDB covers the cases that resolve through the
// workspace-backed route and need a real `bd init` workspace. Embedded storage
// runs in-process and offline.
func TestVerifyConfigUnsetDB(t *testing.T) {
	bd := buildEmbeddedBD(t)

	// A key the workspace carries but that is not a YAML-only key: a broken clear
	// removes only the workspace layer, so the value stays effective from
	// config.yaml while the command reports success. A correct clear reaches the
	// config.yaml layer too, so the key is no longer a live top-level entry. This
	// asserts on the config.yaml bytes rather than on `bd config get`, because
	// once the workspace row is gone the merged read already reports "not set"
	// whether or not the file layer was cleared.
	t.Run("crit_db_key_clears_yaml_layer", func(t *testing.T) {
		dir, beadsDir, _ := bdInit(t, bd, "--prefix", "tc")
		configPath := filepath.Join(beadsDir, "config.yaml")
		original := readBytes(t, configPath)
		if topLevelKeyLive(string(original), "no-hooks") {
			t.Skip("fresh config.yaml already carries no-hooks; probe needs a key it does not")
		}

		if _, _, code := cfg(t, bd, dir, bdEnv(dir), "set", "no-hooks", "true"); code != 0 {
			t.Fatalf("config set no-hooks true exited %d", code)
		}
		if err := os.WriteFile(configPath, append(original, []byte("no-hooks: true\n")...), 0o600); err != nil {
			t.Fatalf("append no-hooks to config.yaml: %v", err)
		}

		_, _, code := cfg(t, bd, dir, bdEnv(dir), "unset", "no-hooks")
		if code != 0 {
			t.Fatalf("unset of a workspace-backed key also in config.yaml should exit 0, got %d", code)
		}
		if topLevelKeyLive(string(readBytes(t, configPath)), "no-hooks") {
			t.Errorf("config.yaml layer was not cleared; key is still live:\n%s", readBytes(t, configPath))
		}
	})

	// A workspace-backed key with a non-empty default that config.yaml does NOT
	// carry: the unset must exit cleanly, must not rewrite config.yaml (it had
	// nothing to clear there), and must not claim a config.yaml write. The exact
	// location wording the command appends is the implementer's choice and is not
	// asserted; this checks only the behavioral facts any honest implementation
	// shares — no false config.yaml claim, no file rewrite.
	t.Run("crit_db_key_reports_database_only", func(t *testing.T) {
		dir, beadsDir, _ := bdInit(t, bd, "--prefix", "tc")
		configPath := filepath.Join(beadsDir, "config.yaml")
		before := readBytes(t, configPath)
		if topLevelKeyLive(string(before), "no-hooks") {
			t.Skip("fresh config.yaml already carries no-hooks; probe needs a key it does not")
		}

		if _, _, code := cfg(t, bd, dir, bdEnv(dir), "set", "no-hooks", "true"); code != 0 {
			t.Fatalf("config set no-hooks true exited %d", code)
		}

		stdout, _, code := cfg(t, bd, dir, bdEnv(dir), "unset", "no-hooks")
		if code != 0 {
			t.Fatalf("unset of a database-only key should exit 0, got %d\nstdout:\n%s", code, stdout)
		}
		if claimsClearedConfigYaml(stdout) {
			t.Errorf("unset claimed a config.yaml write for a key that was never written there:\n%s", stdout)
		}
		if got := readBytes(t, configPath); string(got) != string(before) {
			t.Errorf("unset rewrote config.yaml though it had nothing to clear there:\nbefore: %q\nafter:  %q", before, got)
		}
	})

	// With no project config.yaml at all, a workspace-backed unset of a defaulted
	// key still succeeds and does not recreate config.yaml. This protects against
	// a regression where a fix pre-checks the merged config value, believes there
	// is a config.yaml layer to clear, and then errors after the workspace row is
	// already gone.
	t.Run("crit_db_key_no_project_yaml_succeeds", func(t *testing.T) {
		dir, beadsDir, _ := bdInit(t, bd, "--prefix", "tc")
		configPath := filepath.Join(beadsDir, "config.yaml")

		if _, _, code := cfg(t, bd, dir, bdEnv(dir), "set", "no-hooks", "true"); code != 0 {
			t.Fatalf("config set no-hooks true exited %d", code)
		}
		if err := os.Remove(configPath); err != nil {
			t.Fatalf("remove config.yaml: %v", err)
		}

		stdout, stderr, code := cfg(t, bd, dir, bdEnv(dir), "unset", "no-hooks")
		if code != 0 {
			t.Fatalf("unset with no project config.yaml should exit 0, got %d\nstdout:\n%s\nstderr:\n%s", code, stdout, stderr)
		}
		if _, err := os.Stat(configPath); !os.IsNotExist(err) {
			t.Errorf("unset recreated config.yaml (stat err=%v)", err)
		}
		if claimsClearedConfigYaml(stdout) {
			t.Errorf("unset claimed a config.yaml write though none exists:\n%s", stdout)
		}
	})

	// A single-segment key whose value is a block scalar reaches the YAML layer
	// through the workspace-backed route (which clears every key's YAML layer),
	// and commenting its one key line out would orphan the indented body. An
	// unsupported-shape check that skips single-segment keys corrupts this
	// silently and exits 0; a correct command refuses with a non-zero exit and
	// leaves the file untouched.
	t.Run("crit_single_segment_block_scalar_refused", func(t *testing.T) {
		dir, beadsDir, _ := bdInit(t, bd, "--prefix", "tc")
		configPath := filepath.Join(beadsDir, "config.yaml")
		original := readBytes(t, configPath)
		if err := os.WriteFile(configPath, append(original, []byte("notes: |\n  line one\n  line two\n")...), 0o600); err != nil {
			t.Fatalf("append notes block scalar to config.yaml: %v", err)
		}
		seeded := readBytes(t, configPath)

		stdout, stderr, code := cfg(t, bd, dir, bdEnv(dir), "unset", "notes")
		if code == 0 {
			t.Errorf("unset of a single-segment block-scalar key should have been refused; exited 0\nstdout:\n%s", stdout)
		}
		if got := readBytes(t, configPath); string(got) != string(seeded) {
			t.Errorf("a refused unset of a block-scalar key still rewrote config.yaml:\nbefore: %q\nafter:  %q\nstderr:\n%s",
				seeded, got, stderr)
		}
	})
}
