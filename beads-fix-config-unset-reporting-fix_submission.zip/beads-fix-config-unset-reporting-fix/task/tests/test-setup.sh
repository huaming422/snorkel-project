#!/usr/bin/env bash
# Sourced by the verifier runner before tests execute. Everything the verifier
# needs is baked into the image at the base commit: the Go 1.26.10 toolchain,
# the complete module cache (`go mod download`), a prewarmed build cache
# (`go build ./...`), and the embedded-dolt build inputs (CGO + gms_pure_go).
# The verifier compiles `bd` with `go build -tags gms_pure_go` and drives it as
# a subprocess, so there is nothing to install here — the offline agent phase
# already carries the full dependency closure.
set -euo pipefail

cd /repo/beads

export GOFLAGS="${GOFLAGS:--mod=mod}"
export CGO_ENABLED="1"
export GOTOOLCHAIN="local"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
mkdir -p "$GOCACHE" "$GOMODCACHE"

echo "[test-setup] beads-fix-config-unset-reporting: Go env exported; deps are image-baked (no-op install)."
