#!/usr/bin/env bash
# Behavioral verifier for jint-fix-label-accessible-names.
#
# The repo is C# and the runner registry has no .NET runner, so .NET is routed
# through this shell verifier: it stages the authored test class into the
# Jint.Tests.Browser project and runs `dotnet test` filtered to just that class.
# Exit 0 = every authored test passed; non-zero propagates the build/test failure.
#
# The authored class lives beside this script (staged read-only into /tests/verify/,
# where the solving author cannot see or edit it) and is copied into the project so
# the project's default compile glob picks it up. It rides only pre-existing, stable
# boundaries — the in-process DOM-eval fixture's `labels`/`control` accessors, the
# accessible-name computation, in-process click activation, and the checked-in
# binding pin diffed against the emitter — so any restructuring that keeps those
# answers correct passes.
#
# The image baked the net10.0 build of Jint.Tests.Browser at the base commit, so the
# compile is incremental and the NuGet cache is warm; --no-restore keeps it offline.
set -uo pipefail

REPO_NAME="${REPO_NAME:-jint}"
REPO_DIR="/repo/${REPO_NAME}"
PROJECT="Jint.Tests.Browser"
STAGE_DIR="${REPO_DIR}/${PROJECT}/Verify"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_NOLOGO=1 DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1

cd "${REPO_DIR}" || { echo "FAIL: repo dir ${REPO_DIR} missing" >&2; exit 2; }

# Stage the authored test class where the project's compile glob will pick it up.
mkdir -p "${STAGE_DIR}"
cp "${HERE}/LabelAccessibleNameVerifyTests.cs" "${STAGE_DIR}/LabelAccessibleNameVerifyTests.cs" \
    || { echo "FAIL: could not stage authored test class" >&2; exit 2; }

cleanup() { rm -rf "${STAGE_DIR}"; }
trap cleanup EXIT

FILTER="FullyQualifiedName~Jint.Tests.Browser.Verify.LabelAccessibleNameVerifyTests"

echo "[verify] dotnet test ${PROJECT} -c Release -f net10.0 --filter ${FILTER}"
dotnet test "${PROJECT}/${PROJECT}.csproj" \
    -c Release -f net10.0 --no-restore \
    --filter "${FILTER}" \
    --logger "console;verbosity=normal"
status=$?

if [ "${status}" -eq 0 ]; then
    echo "PASS: label/name association behaves correctly across all shapes"
else
    echo "FAIL: dotnet test exited ${status}" >&2
fi
exit "${status}"
