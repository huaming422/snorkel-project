using AngleSharp.Css.Dom;
using AngleSharp.Dom;
using Jint.Browser.Accessibility;
using Jint.Browser.BindingGenerator;
using Jint.Tests.Browser;
using Jint.Tests.Browser.Accessibility;

namespace Jint.Tests.Browser.Verify;

// This test namespace sits under Jint.Tests.Browser, so the bare name `Browser` binds to that
// namespace rather than to the type. The alias belongs inside the namespace declaration, where it
// wins that lookup.
using Browser = global::Jint.Browser.Browser;

// Exercises HTML's label/labelable-control association the way the script-visible
// DOM, the accessible-name computation and label click activation all read it.
// Every assertion rides a pre-existing, stable boundary: the JS `labels`/`control`
// accessors over the in-process DOM-eval fixture, the accessible-name computation
// over its own fixture, in-process click activation, and the checked-in binding
// pin diffed against the emitter. Nothing here names the browser layer's private
// association helpers, so any restructuring that keeps the observable answers
// correct is accepted.
public sealed class LabelAccessibleNameVerifyTests
{
    // One page covering the ordinary association shapes: explicit for/id (including
    // a hidden one), a control with several labels in tree order, a wrapping label,
    // and an empty `for` that associates with nothing.
    private const string Page = """
        <!doctype html>
        <html><body>
        <label id="first" for="named">First</label>
        <label id="hidden" for="named" hidden>Hidden</label>
        <input id="named">
        <label id="second" for="named">Second</label>
        <label id="wrapped">Wrapped <input id="inside"></label>
        <label id="empty" for="">Not wrapped <input id="not-associated"></label>
        <label id="area-label" for="area">Message</label>
        <textarea id="area"></textarea>
        <label id="sel-label">Choice <select id="sel"></select></label>
        <label id="btn-label" for="btn">Go</label>
        <button id="btn"></button>
        <label id="meter-label" for="mtr">Load</label>
        <meter id="mtr"></meter>
        <label id="out-label" for="out">Result</label>
        <output id="out"></output>
        <label id="prog-label" for="prg">Progress</label>
        <progress id="prg"></progress>
        </body></html>
        """;

    // A labelable control answers every label whose labeled control it is — those
    // naming it with `for` AND the one wrapping it — in document order, and an empty
    // `for` names nothing.
    [Test]
    public void LabelsReturnsExplicitAndWrappingLabelsInTreeOrder()
    {
        using var fixture = DomTestFixture.Create(Page);

        fixture.Text("""
            (function () {
              const explicit = Array.from(document.getElementById('named').labels, x => x.id).join(',');
              const wrapped = Array.from(document.getElementById('inside').labels, x => x.id).join(',');
              const empty = document.getElementById('not-associated').labels.length;
              const textarea = Array.from(document.getElementById('area').labels, x => x.id).join(',');
              const select = Array.from(document.getElementById('sel').labels, x => x.id).join(',');
              const button = Array.from(document.getElementById('btn').labels, x => x.id).join(',');
              const meter = Array.from(document.getElementById('mtr').labels, x => x.id).join(',');
              const output = Array.from(document.getElementById('out').labels, x => x.id).join(',');
              const progress = Array.from(document.getElementById('prg').labels, x => x.id).join(',');
              return [explicit, wrapped, empty, textarea, select, button, meter, output, progress].join('|');
            })()
            """).Should().Be("first,hidden,second|wrapped|0|area-label|sel-label|btn-label|meter-label|out-label|prog-label");
    }

    // A label answers the control it labels: the `for` target, otherwise the first
    // labelable descendant, otherwise nothing.
    [Test]
    public void LabelControlUsesForOrTheFirstLabelableDescendant()
    {
        using var fixture = DomTestFixture.Create(Page);

        fixture.Text("""
            (function () {
              return [
                document.getElementById('first').control.id,
                document.getElementById('wrapped').control.id,
                String(document.getElementById('empty').control),
              ].join('|');
            })()
            """).Should().Be("named|inside|null");
    }

    // The labels collection is live: it re-answers after a `for` is re-pointed on
    // the same reference, dropping the label that moved away in tree order.
    [Test]
    public void LabelsIsALiveNodeList()
    {
        using var fixture = DomTestFixture.Create(Page);

        fixture.Text("""
            (function () {
              const input = document.getElementById('named');
              const labels = input.labels;
              const before = labels.length;
              document.getElementById('second').htmlFor = 'inside';
              return [before, labels.length, labels.item(1).id].join('|');
            })()
            """).Should().Be("3|2|hidden");
    }

    // A non-labelable control — a hidden input — answers a null labels collection
    // rather than an empty one.
    [Test]
    public void AHiddenInputHasNoLabelsNodeList()
    {
        using var fixture = DomTestFixture.Create(Page);

        fixture.Text("""
            (function () {
              const input = document.createElement('input');
              input.type = 'hidden';
              return String(input.labels);
            })()
            """).Should().Be("null");
    }

    // The accessible name of a control named only by its associated labels is that
    // label text, in tree order, and a hidden label that is the direct target of
    // the association still contributes.
    [Test]
    public void AccessibleNameReadsAssociatedLabelTextIncludingHiddenReferences()
    {
        NameOf("<label for=t>Full name</label><input id=t>").Should().Be("Full name");
        NameOf("<label for=t>A</label><label for=t>B</label><input id=t>").Should().Be("A B");
        NameOf("<label>Full name <input id=t></label>").Should().Be("Full name");
        NameOf("<label for=t hidden>Hidden</label><label for=t>Visible</label><input id=t>")
            .Should().Be("Hidden Visible");
    }

    // An explicit ARIA name still wins over associated-label text — the fallback is
    // consulted only when nothing above it named the control.
    [Test]
    public void AriaNamePrecedenceOverAssociatedLabelIsPreserved()
    {
        NameOf("<label for=t>Native</label><input id=t aria-label='ARIA label'>")
            .Should().Be("ARIA label");
        NameOf("<span id=a hidden>Referenced</span><label for=t>Native</label>"
             + "<input id=t aria-labelledby=a aria-label='ARIA label'>")
            .Should().Be("Referenced");
    }

    // Clicking inside a label forwards activation to the control it labels, for both
    // the wrapping and the `for` spellings, and a label whose only descendant is a
    // non-labelable control forwards nothing.
    [Test]
    public async Task ClickingInsideALabelForwardsToTheControlItLabels()
    {
        await using var browser = new Browser();
        var page = await browser.NewPageAsync();
        await page.SetContentAsync(
            "<label id='wrapping'><input id='inner' type='checkbox'><span id='text'>text</span></label>"
            + "<label id='naming' for='outer'>text</label><input id='outer' type='checkbox'>"
            + "<label id='hiddenOnly'><input type='hidden'><span id='hiddenText'>text</span></label>");

        (await page.EvaluateAsync<string>(
            """
            (() => {
              const seen = [];
              for (const id of ['inner', 'outer']) {
                document.getElementById(id).addEventListener('click', e => seen.push(id + ':' + e.isTrusted));
              }

              document.getElementById('text').click();
              document.getElementById('naming').click();
              document.getElementById('hiddenText').click();

              return seen.join(',') + '|' + document.getElementById('inner').checked + document.getElementById('outer').checked;
            })()
            """))
            .Should().Be("inner:false,outer:false|truetrue");
    }

    // The checked-in generated bindings must equal what the emitter produces from
    // the override table and the pinned assemblies, so the association wiring is
    // made through the generator's inputs rather than by editing the generated file.
    [Test]
    public void TheCheckedInBindingsMatchTheEmitter()
    {
        var result = BindingGenerator.Run(new BindingGeneratorOptions
        {
            CoreAssembly = typeof(IElement).Assembly.Location,
            CssAssembly = typeof(ICssStyleDeclaration).Assembly.Location,
            OverridesPath = RepositoryPaths.OverridesPath,
        });

        var differences = new List<string>();

        foreach (var (name, expected) in result.Files)
        {
            var path = System.IO.Path.Combine(RepositoryPaths.GeneratedDirectory, name);
            var actual = System.IO.File.Exists(path)
                ? RepositoryPaths.NormalizeNewlines(System.IO.File.ReadAllText(path))
                : null;

            if (!string.Equals(actual, expected, StringComparison.Ordinal))
            {
                differences.Add(actual is null ? name + " is missing" : name + " differs");
            }
        }

        differences.Should().BeEmpty(
            "the checked-in generated bindings must equal what the emitter produces from the override table");
    }

    private static string NameOf(string html)
    {
        using var document = PageFixture.Parse(html);
        var element = document.GetElementById("t")!;
        var computation = new AccessibleName(new ElementVisibility(useComputedStyle: true));
        return computation.Compute(element, AccessibleName.ResolveRole(element));
    }
}
