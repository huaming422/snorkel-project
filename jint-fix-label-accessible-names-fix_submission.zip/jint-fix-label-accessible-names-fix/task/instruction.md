## Task

our page automation picks form controls by accessibility role *and* accessible name, and it's started missing textboxes whose name comes from a `<label>`. a control that a label points at, or that a label wraps, no longer comes back from a role-and-name query, even though the label text is sitting right there on the page. names that come from somewhere other than a label still resolve fine, and this all used to work. dig into why label-based names stopped resolving in the browser/accessibility layer and fix the root cause.
