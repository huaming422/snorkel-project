## Task

Teams running dbt commands in Prefect tasks are seeing timeouts behave incorrectly: some tasks hang, while others retry before the previous attempt's warehouse queries have ended, leading to overlapping writes and lock contention. Fix the integration so a timed-out run reaches its final state promptly and a retry does not overlap the prior attempt. The same behavior should hold for the dbt commands supported by the integration, not only one command type.
