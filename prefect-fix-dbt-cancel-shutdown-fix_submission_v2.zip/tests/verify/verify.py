"""Behavioral verifier for prefect-fix-dbt-cancel-shutdown.

Every check exercises the dbt integration through its pre-existing public
surface only:

  * ``PrefectDbtRunner().invoke([...])`` — the top-level command entry point.
  * ``NodeTaskTracker`` — the per-node waiter machinery
    (``start_task`` / ``wait_for_node_completion`` / ``get_node_status`` /
    ``set_node_status``), all present before this change.
  * ``prefect.task(timeout_seconds=...)`` — a real Prefect timeout driving a
    ``TimedOut`` state.
  * ``prefect._internal.concurrency.cancellation.CancelledError`` — the
    ``BaseException`` Prefect delivers on timeout/cancellation, constructed
    directly and also returned inside a mocked dbt result.

The command runner is always driven with a mocked ``dbtRunner`` so no real
dbt project, warehouse, or credentials are needed. No implementation-internal
helper, module, or attribute introduced by a solution is referenced — the
behaviour is observed, not the mechanism, so any correct approach passes.
"""

from __future__ import annotations

import contextlib
import os
import threading
import time
from pathlib import Path
from unittest.mock import Mock, patch

import pytest

from prefect import task
from prefect._internal.concurrency.cancellation import CancelledError
from prefect.settings import (
    PREFECT_API_SERVICES_TRIGGERS_ENABLED,
    temporary_settings,
)
from prefect.states import StateType
from prefect.testing.utilities import prefect_test_harness

from prefect_dbt.core.runner import FAILURE_STATUSES, PrefectDbtRunner
from prefect_dbt.core.settings import PrefectDbtSettings
from prefect_dbt.core._tracker import NodeTaskTracker


# ---------------------------------------------------------------------------
# Test harness / fixtures
# ---------------------------------------------------------------------------
# The command runner constructs a Prefect client and (for the timeout check)
# runs a real Prefect task, both of which need the ephemeral in-process
# server. Stand it up once for the whole module. This mirrors the integration
# suite's own session-scoped harness; the verifier runs standalone so it
# provides the harness itself rather than relying on the suite's conftest.
@pytest.fixture(scope="session", autouse=True)
def _prefect_server():
    with temporary_settings({PREFECT_API_SERVICES_TRIGGERS_ENABLED: False}):
        with prefect_test_harness(server_startup_timeout=60):
            yield


@pytest.fixture
def mock_dbt_runner_class():
    """Patch the dbt runner the command path instantiates.

    The returned class mock's ``.return_value.invoke`` is where each test
    installs the dbt result (or blocking behaviour) it wants to observe.
    """
    with patch("prefect_dbt.core.runner.dbtRunner") as mock_class:
        mock_class.return_value = Mock()
        yield mock_class


@pytest.fixture
def mock_settings_context_manager():
    """Mock the profiles-dir resolution so no profiles.yml is required."""
    with patch.object(PrefectDbtSettings, "resolve_profiles_yml") as mock_cm:
        mock_cm.return_value.__enter__.return_value = "/profiles/dir"
        yield mock_cm


class _HeartbeatDbtRunner:
    """Spawn-safe dbt stand-in whose background work is externally observable."""

    def __init__(self, callbacks=None):
        self.callbacks = callbacks or []

    def invoke(self, args):
        heartbeat_path = Path(os.environ["VERIFY_DBT_HEARTBEAT_PATH"])
        stop_path = Path(os.environ["VERIFY_DBT_STOP_PATH"])

        def _warehouse_work():
            while not stop_path.exists():
                heartbeat_path.write_text(str(time.time_ns()))
                time.sleep(0.02)

        worker = threading.Thread(target=_warehouse_work, daemon=True)
        worker.start()
        while worker.is_alive():
            time.sleep(0.01)
        return Mock(success=False, exception=CancelledError())


# ---------------------------------------------------------------------------
# Criterion 1 — a cancellation encoded in the dbt result propagates unchanged.
# ---------------------------------------------------------------------------
def test_returned_cancellation_propagates_unchanged(
    mock_dbt_runner_class, mock_settings_context_manager
):
    """dbt reports an interrupted run by returning an unsuccessful result whose
    ``exception`` is a ``BaseException`` that is not an ``Exception`` (here,
    Prefect's ``CancelledError``).

    That exact exception must come back out of the top-level command entry
    point — not be swallowed or re-wrapped in another error type — so the
    surrounding Prefect task actually sees the cancellation.
    """
    error = CancelledError()
    mock_dbt_runner_class.return_value.invoke.return_value = Mock(
        success=False, exception=error
    )

    with pytest.raises(CancelledError) as raised:
        PrefectDbtRunner().invoke(["run"])

    assert raised.value is error


# ---------------------------------------------------------------------------
# Criterion 3 — node waiters are woken and errored when dbt is cancelled.
# ---------------------------------------------------------------------------
def test_returned_cancellation_wakes_and_errors_incomplete_nodes(
    mock_dbt_runner_class, mock_settings_context_manager
):
    """A node task started from a ``NodeStart`` blocks waiting for the matching
    finished event. When dbt is cancelled that event never arrives on its own,
    so the command path must wake every still-pending node waiter and mark the
    node errored — otherwise the waiter (and the task run behind it) hangs.

    Observed purely through the public tracker interface: the waiter unblocks,
    and the node's recorded status becomes ``error``.
    """
    tracker = NodeTaskTracker()
    tracker.start_task("model.a", Mock())

    woke = threading.Event()

    def _wait_for_node():
        # Pre-existing waiter entry point; blocks until the node's event fires.
        tracker.wait_for_node_completion("model.a")
        woke.set()

    waiter = threading.Thread(target=_wait_for_node, daemon=True)
    waiter.start()

    error = CancelledError()
    mock_dbt_runner_class.return_value.invoke.return_value = Mock(
        success=False, exception=error
    )

    try:
        # The command path builds its own tracker; hand it the one whose node
        # waiter we are observing.
        with patch(
            "prefect_dbt.core.runner.NodeTaskTracker", return_value=tracker
        ):
            with pytest.raises(CancelledError) as raised:
                PrefectDbtRunner().invoke(["run"])

        assert raised.value is error
        assert woke.wait(2), "node waiter was never woken after cancellation"

        # The woken node must land in a failure status (details: waiters are
        # "woken and failed"). Accept any of the integration's pre-existing
        # failure statuses rather than pinning one specific value, so a solution
        # that fails the node with a different dbt failure status still passes.
        status = tracker.get_node_status("model.a")
        assert status is not None, "node status was never recorded"
        node_status = status["event_data"]["node_info"]["node_status"]
        assert node_status in FAILURE_STATUSES, (
            f"expected a failure status after cancellation, got {node_status!r}"
        )
    finally:
        # Release the waiter if it is still blocked (e.g. the behaviour under
        # test was absent), using the pre-existing status setter.
        tracker.set_node_status(
            "model.a", {"node_info": {"node_status": "error"}}, "verify cleanup"
        )
        waiter.join(5)


# ---------------------------------------------------------------------------
# Criterion 2 — a task timeout stops dbt before the task resolves, and runner
# state is reset only after the dbt work has finished.
# ---------------------------------------------------------------------------
def test_task_timeout_stops_dbt_and_resets_runner_state(
    mock_settings_context_manager, tmp_path
):
    """Wrap a blocking dbt command in a ``@task(timeout_seconds=...)``.

    When the timeout fires the task must resolve ``TimedOut`` *and* the dbt
    work underneath must actually have unwound (its blocking call returned, so
    its ``finally`` ran) before the state resolves. A pre-fix runner marks the
    task timed out while its dbt worker keeps running in the background, so a
    retry overlaps a still-running attempt.

    The simulated invocation starts separate warehouse work. Interrupting only
    the task-side call leaves that work alive, which models the original overlap
    bug. The check accepts any shutdown design that stops the work before the
    timed-out state is returned.
    """
    from dbt.adapters.factory import FACTORY

    heartbeat_path = tmp_path / "dbt-heartbeat"
    stop_path = tmp_path / "stop-dbt"

    runner = PrefectDbtRunner()

    # Leave enough startup time for valid process-isolated implementations.
    @task(timeout_seconds=8.0)
    def run_dbt():
        runner.invoke(["run"])

    class _FakeConnectionManager:
        def cancel_open(self):
            stop_path.touch()
            return []

    class _FakeAdapter:
        def __init__(self):
            self.connections = _FakeConnectionManager()

        @staticmethod
        def type():
            return "fake"

        @staticmethod
        def is_cancelable():
            return True

        @contextlib.contextmanager
        def connection_named(self, name, *args, **kwargs):
            yield

        def cancel_open_connections(self):
            stop_path.touch()
            return []

    try:
        with (
            patch("prefect_dbt.core.runner.dbtRunner", _HeartbeatDbtRunner),
            patch.object(runner, "_build_dbt_hook_selection_cache", return_value={}),
            patch.dict(FACTORY.adapters, {"fake": _FakeAdapter()}, clear=True),
            patch.dict(
                os.environ,
                {
                    "VERIFY_DBT_HEARTBEAT_PATH": str(heartbeat_path),
                    "VERIFY_DBT_STOP_PATH": str(stop_path),
                },
            ),
        ):
            state = run_dbt(return_state=True)

        assert state.name == "TimedOut"
        assert state.type == StateType.FAILED
        assert heartbeat_path.exists(), "simulated dbt work never started"
        heartbeat_after_timeout = heartbeat_path.read_text()
        time.sleep(0.2)
        assert heartbeat_path.read_text() == heartbeat_after_timeout, (
            "dbt work survived after the task resolved"
        )
    finally:
        stop_path.touch()



# ---------------------------------------------------------------------------
# Pass-to-pass — the happy path and ordinary-failure path are
# unchanged.
# ---------------------------------------------------------------------------
def test_successful_run_returns_result(
    mock_dbt_runner_class, mock_settings_context_manager
):
    """A successful dbt result is returned from the command entry point as-is."""
    result = Mock(success=True, exception=None)
    mock_dbt_runner_class.return_value.invoke.return_value = result

    returned = PrefectDbtRunner().invoke(["run"])

    assert returned is result


def test_ordinary_failure_still_raises_valueerror(
    mock_dbt_runner_class, mock_settings_context_manager
):
    """An ordinary dbt failure — an unsuccessful result whose ``exception`` is a
    regular ``Exception`` — still surfaces as the existing ``ValueError`` with
    the failing command in its message, exactly as before.
    """
    mock_dbt_runner_class.return_value.invoke.return_value = Mock(
        success=False, exception=RuntimeError("boom")
    )

    with pytest.raises(ValueError) as raised:
        PrefectDbtRunner().invoke(["run"])

    assert "run" in str(raised.value)
