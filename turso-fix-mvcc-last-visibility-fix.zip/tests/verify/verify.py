# Black-box checks for reverse-order scans under the experimental MVCC backend.
# Each scenario drives the prebuilt `tursodb` CLI over a temp database file.
# A reopen is a fresh process on the same file, so the rows come back from the
# main database file. Concurrent rowid allocation is checked separately in
# verify_mvcc_concurrent_rowid_test.rs, since it needs two connections.

import os
import subprocess
import tempfile
from pathlib import Path

import pytest

_PROC_TIMEOUT = 60


def _find_tursodb() -> str:
    override = os.environ.get("TURSODB_BIN")
    if override and Path(override).is_file():
        return override

    candidates = []
    cargo_target = os.environ.get("CARGO_TARGET_DIR")
    if cargo_target:
        candidates.append(Path(cargo_target) / "release" / "tursodb")
    repo = Path("/repo") / os.environ.get("REPO_NAME", "turso")
    candidates.append(repo / "target" / "release" / "tursodb")
    candidates.append(Path("/opt/cache/cargo-target/release/tursodb"))

    for c in candidates:
        if c.is_file():
            return str(c)
    raise AssertionError(
        "tursodb CLI binary not found; looked in: "
        + ", ".join(str(c) for c in candidates)
        + " (test-setup.sh should have built turso_cli --release)"
    )


_BIN_CACHE: list[str] = []


def _bin() -> str:
    # Resolved lazily so a missing binary fails each test, not collection.
    if not _BIN_CACHE:
        _BIN_CACHE.append(_find_tursodb())
    return _BIN_CACHE[0]


def _run(db_path: Path, sql: str, *, mvcc: bool) -> str:
    # A crash or an engine error fails the test instead of reading as no rows.
    flags = ["-q", "-m", "list"]
    if mvcc:
        flags.append("--experimental-mvcc")
    proc = subprocess.run(
        [_bin(), str(db_path), *flags],
        input=sql.encode(),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=_PROC_TIMEOUT,
        check=False,
    )
    stdout = proc.stdout.decode()
    stderr = proc.stderr.decode()

    if proc.returncode != 0:
        raise AssertionError(
            f"tursodb exited {proc.returncode}\nSQL:\n{sql}\n"
            f"STDOUT:\n{stdout}\nSTDERR:\n{stderr}"
        )
    if "Error:" in stdout or "Error:" in stderr:
        raise AssertionError(
            f"tursodb reported an error\nSQL:\n{sql}\n"
            f"STDOUT:\n{stdout}\nSTDERR:\n{stderr}"
        )
    return stdout


def _section(stdout: str, name: str) -> list[str]:
    # Rows printed between the `@name@` and `@/name@` marker lines.
    open_m, close_m = f"@{name}@", f"@/{name}@"
    rows: list[str] = []
    capturing = False
    for raw in stdout.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line == open_m:
            capturing = True
            continue
        if line == close_m:
            capturing = False
            continue
        if capturing:
            rows.append(line)
    return rows


def _mark(name: str, select_sql: str) -> str:
    return f"SELECT '@{name}@';\n{select_sql}\nSELECT '@/{name}@';\n"


@pytest.fixture()
def db_path():
    with tempfile.TemporaryDirectory() as d:
        yield Path(d) / "t.db"


def test_mvcc_delete_desc_no_phantom(db_path):
    _run(
        db_path,
        "CREATE TABLE t (x INTEGER PRIMARY KEY);\n"
        "INSERT INTO t VALUES (1);\n"
        "PRAGMA wal_checkpoint(TRUNCATE);\n",
        mvcc=True,
    )
    out = _run(
        db_path,
        "DELETE FROM t WHERE x = 1;\n"
        + _mark("desc", "SELECT x FROM t ORDER BY x DESC;")
        + _mark("asc", "SELECT x FROM t ORDER BY x ASC;"),
        mvcc=True,
    )
    desc = _section(out, "desc")
    asc = _section(out, "asc")
    assert desc == [], f"reverse-order scan returned a deleted row: {desc!r}"
    assert asc == [], f"forward scan returned a deleted row: {asc!r}"


def test_mvcc_scans_agree_with_live_set(db_path):
    _run(
        db_path,
        "CREATE TABLE t (x INTEGER PRIMARY KEY);\n"
        "INSERT INTO t VALUES (1), (2), (3), (5), (8), (9);\n"
        "PRAGMA wal_checkpoint(TRUNCATE);\n",
        mvcc=True,
    )
    # The highest rows are deleted, both reopened ones and a new one, and the
    # surviving new rows sit below the old maximum.
    out = _run(
        db_path,
        "DELETE FROM t WHERE x = 9;\n"
        "DELETE FROM t WHERE x = 8;\n"
        "DELETE FROM t WHERE x = 2;\n"
        "INSERT INTO t VALUES (4), (7), (12);\n"
        "DELETE FROM t WHERE x = 12;\n"
        + _mark("asc", "SELECT x FROM t ORDER BY x ASC;")
        + _mark("desc", "SELECT x FROM t ORDER BY x DESC;"),
        mvcc=True,
    )
    live_sorted = ["1", "3", "4", "5", "7"]
    asc = _section(out, "asc")
    desc = _section(out, "desc")
    assert asc == live_sorted, f"ASC scan disagrees with live set: {asc!r}"
    assert desc == list(reversed(live_sorted)), (
        f"DESC scan disagrees with live set: {desc!r}"
    )


def test_non_mvcc_path_unaffected(db_path):
    _run(
        db_path,
        "CREATE TABLE t (x INTEGER PRIMARY KEY);\n"
        "INSERT INTO t VALUES (1), (2), (3);\n"
        "PRAGMA wal_checkpoint(TRUNCATE);\n",
        mvcc=False,
    )
    out = _run(
        db_path,
        "DELETE FROM t WHERE x = 2;\n"
        + _mark("asc", "SELECT x FROM t ORDER BY x ASC;")
        + _mark("desc", "SELECT x FROM t ORDER BY x DESC;"),
        mvcc=False,
    )
    asc = _section(out, "asc")
    desc = _section(out, "desc")
    assert asc == ["1", "3"], f"non-MVCC ASC scan wrong: {asc!r}"
    assert desc == ["3", "1"], f"non-MVCC DESC scan wrong: {desc!r}"
