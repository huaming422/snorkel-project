// Two connections insert in overlapping BEGIN CONCURRENT transactions with
// auto-assigned rowids. Both must commit, and the rows must keep distinct rowids.

use std::path::PathBuf;
use std::sync::Arc;
use turso_core::{Connection, Database, PlatformIO, StepResult, Value};

fn db_path(name: &str) -> PathBuf {
    let dir = std::env::temp_dir().join(format!("verify-mvcc-{}-{name}", std::process::id()));
    let _ = std::fs::remove_dir_all(&dir);
    std::fs::create_dir_all(&dir).unwrap();
    dir.join("t.db")
}

fn open(path: &PathBuf) -> Arc<Database> {
    let io = Arc::new(PlatformIO::new().unwrap());
    Database::open_file(io, path.to_str().unwrap(), true).unwrap()
}

fn rows(conn: &Arc<Connection>, sql: &str) -> Vec<Vec<Value>> {
    let mut stmt = conn.query(sql).unwrap().unwrap();
    let mut out = Vec::new();
    loop {
        match stmt.step().unwrap() {
            StepResult::Row => out.push(stmt.row().unwrap().get_values().cloned().collect()),
            StepResult::IO => stmt.run_once().unwrap(),
            StepResult::Done => break,
            other => panic!("unexpected step result {other:?}"),
        }
    }
    out
}

fn assert_overlapping_inserts_commit(db: &Arc<Database>) {
    let c1 = db.connect().unwrap();
    let c2 = db.connect().unwrap();
    c1.execute("BEGIN CONCURRENT").unwrap();
    c2.execute("BEGIN CONCURRENT").unwrap();
    c1.execute("INSERT INTO t (v) VALUES ('first')").unwrap();
    c2.execute("INSERT INTO t (v) VALUES ('second')").unwrap();
    c1.execute("COMMIT").unwrap();
    c2.execute("COMMIT").unwrap();

    let got = rows(&db.connect().unwrap(), "SELECT rowid, v FROM t WHERE v IN ('first', 'second')");
    let ids: Vec<&Value> = got.iter().map(|r| &r[0]).collect();
    assert_eq!(got.len(), 2, "expected both inserted rows, got {got:?}");
    assert_ne!(ids[0], ids[1], "both transactions got the same rowid: {got:?}");
}

#[test]
fn concurrent_inserts_get_distinct_rowids() {
    let db = open(&db_path("empty"));
    db.connect().unwrap().execute("CREATE TABLE t (id INTEGER PRIMARY KEY, v TEXT)").unwrap();
    assert_overlapping_inserts_commit(&db);
}

#[test]
fn concurrent_inserts_after_checkpoint_reopen_delete() {
    let path = db_path("reopen");
    {
        let db = open(&path);
        let conn = db.connect().unwrap();
        conn.execute("CREATE TABLE t (id INTEGER PRIMARY KEY, v TEXT)").unwrap();
        conn.execute("INSERT INTO t (v) VALUES ('a'), ('b'), ('c')").unwrap();
        conn.execute("PRAGMA wal_checkpoint(TRUNCATE)").unwrap();
        conn.close().unwrap();
    }
    let db = open(&path);
    db.connect().unwrap().execute("DELETE FROM t WHERE id = 3").unwrap();
    assert_overlapping_inserts_commit(&db);
}
