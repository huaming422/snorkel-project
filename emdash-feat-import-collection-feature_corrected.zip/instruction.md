## Task

We're adding site transfer to EmDash: export a whole site to a portable package, then bring that package up in another database. Exporting, analyzing a package, and importing entries or media files belong to other pieces. This piece is the first thing an import does, writing a package's schema into the target.

The caller has already read the package. It hands this step one collection's record plus that collection's field records, in the shapes the package format defines, and it may call again for the same collection at any time. Targets can run on Cloudflare D1, which has no transactions.

## User stories / requirements

- A fresh target ends up holding the collection and its fields just as the package recorded them: ids, slugs, labels, every other column and the field order. The one exception is search, which comes up switched off whatever the package says, because a later stage turns it on.
- Each content table matches what the normal create path builds for those fields, including column defaults and indexes on indexed fields. The app sees the collection immediately and can manage it normally, for example by deleting an indexed field. The step tells its caller whether it created the collection and how many fields it added.
- On a target with media-usage tracking active, an imported collection ends up tracked like a normally created one, with its capture triggers in place, its tracking state fully active, and normal deletion working. With tracking inactive none of that appears. A slug whose previous collection is still being deleted gets refused.
- Calling again after a finished import changes nothing, tracking state included, and reports nothing new. If a run dies after any statement, calling again completes it and lands on exactly what an uninterrupted run leaves, with tracking active or inactive, and for collections too wide for one insert statement.
- No statement binds more than 100 parameters. Importing one collection takes at most 150 statements, the budget one unit of transfer work gets, even with a couple of hundred fields and on a repeat call.
- Before writing the import refuses, leaving the database untouched: records the package format rejects, bad or reserved slugs, duplicate field ids or slugs, a field from another collection, a column type contradicting its field type, indexes on unindexable types, ids or slugs held elsewhere, and any stored row or table disagreeing with the package.
