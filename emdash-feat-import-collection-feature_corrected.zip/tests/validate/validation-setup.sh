#!/usr/bin/env bash
# Environment bootstrap for the story scripts. Idempotent.
#
# The @emdash-cms/core vitest config resolves the package's own sources through the
# dev-source condition, so tests under packages/core/tests run directly against
# packages/core/src with no prebuilt dist. Dependencies are restored only if
# node_modules is gone, and core is built so that any consumer of built artifacts
# still resolves, mirroring tests/test-setup.sh.

set -e

REPO_DIR="${REPO_DIR:-/repo/emdash}"
cd "$REPO_DIR"

# Sanity: the pinned toolchain is reachable. vitest is a dependency of the core
# package, not of the workspace root, so it is looked up from there.
node --version
pnpm --version
(cd packages/core && npx vitest --version)

# Restore workspace deps if missing. The image bakes the full closure into the
# pnpm store at the base commit, so this is an offline no-op on a clean image;
# the online fallback only matters if node_modules was removed.
if [ ! -d "node_modules/.pnpm" ]; then
    echo "[validation-setup] pnpm install (offline, frozen)..."
    if ! pnpm install --frozen-lockfile --offline > /tmp/validation-setup-install.log 2>&1; then
        echo "[validation-setup] offline install failed; retrying online..." >&2
        pnpm install --frozen-lockfile > /tmp/validation-setup-install.log 2>&1 \
            || { tail -60 /tmp/validation-setup-install.log >&2; exit 1; }
    fi
    tail -5 /tmp/validation-setup-install.log || true
fi

# Build @emdash-cms/core (cheap on a tsdown incremental cache). The stories read
# source directly, so a failed build does not block them.
echo "[validation-setup] ensuring @emdash-cms/core is buildable (source-tested)..."
pnpm --filter @emdash-cms/core build > /tmp/validation-setup-build.log 2>&1 \
    || { echo "[validation-setup] core build skipped/failed (tests read source):" >&2; tail -20 /tmp/validation-setup-build.log >&2 || true; }

# Make workspace binaries available.
export PATH="$REPO_DIR/node_modules/.bin:$PATH"

# The per-dialect setup and the vitest config the stories rely on have to exist.
if [ ! -f "packages/core/tests/utils/test-db.ts" ]; then
    echo "[validation-setup] FATAL: packages/core/tests/utils/test-db.ts missing" >&2
    exit 1
fi
if [ ! -f "packages/core/vitest.config.ts" ]; then
    echo "[validation-setup] FATAL: packages/core/vitest.config.ts missing" >&2
    exit 1
fi

echo "[validation-setup] ready: $REPO_DIR (node=$(node --version), pnpm=$(pnpm --version))"
