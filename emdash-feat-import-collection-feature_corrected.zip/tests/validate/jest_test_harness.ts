// @ts-nocheck
/**
 * Shared plumbing for the collection-import stories.
 *
 * The driver copies this file next to each story test, into the `__validation__`
 * directory under the configured test parent, so a story imports it as
 * `./jest_test_harness.js`. It holds a query interceptor that counts statements and
 * stops a run partway, builders for the portable record inputs, and readers for what
 * a target database holds afterwards. The import entry point itself is not used here:
 * each story file reaches it through its own `runImport`.
 *
 * Relative specifiers assume this file runs from
 *   packages/core/tests/integration/transfer/import/__validation__/
 */

import { sql } from "kysely";

import { isPostgres, listTableColumns } from "../../../../../src/database/dialect-helpers.js";
import { verifyMediaUsageCaptureTriggers } from "../../../../../src/media/usage/capture-triggers.js";
import { processDueMediaUsageCollectionDeletions } from "../../../../../src/media/usage/collection-deletion-processor.js";
import { filterToRegisteredCollections } from "../../../../../src/schema/collection-slugs-cache.js";
import { SchemaRegistry } from "../../../../../src/schema/registry.js";
import { FIELD_TYPE_TO_COLUMN } from "../../../../../src/schema/types.js";
import { decodeRow } from "../../../../../src/transfer/format/column-codec.js";
import { getPortableTableSpec } from "../../../../../src/transfer/format/columns.js";
import { setupForDialect, teardownForDialect } from "../../../../utils/test-db.js";

export {
	describeEachDialect,
	setupForDialect,
	teardownForDialect,
} from "../../../../utils/test-db.js";
export { activateMediaUsageCapture } from "../../../../../src/media/usage/activation.js";
export { fixtureId } from "../../../../utils/transfer/golden-package.js";

import { fixtureId } from "../../../../utils/transfer/golden-package.js";

const T0 = "2026-01-01T00:00:00.000Z";

/**
 * A posts-like collection record plus its field records, carrying their own ids and
 * slug for fixture number `n`. The shape is the portable `CollectionRecord` /
 * `FieldRecord` format defined in `src/transfer/format/kinds.ts`. `searchConfig.enabled`
 * is `true` on the input.
 */
export function collectionFixture(n, extraFields = 0) {
	const base = 10_000 + n * 1000;
	const id = fixtureId(base);
	const record = {
		kind: "collection",
		id,
		slug: `imported_${n}`,
		label: "Imported",
		labelSingular: "Imported",
		supports: ["drafts", "revisions", "search"],
		source: "manual",
		searchConfig: { enabled: true, weights: { title: 5 } },
		hasSeo: true,
		urlPattern: "/imported/{slug}",
		commentsEnabled: true,
		commentsModeration: "all",
		commentsClosedAfterDays: 30,
		commentsAutoApproveUsers: false,
		hidden: false,
		sortOrder: 3,
		adminConfig: { listColumns: ["title"] },
		titleField: "title",
		dateField: "published",
		routable: true,
		editLocking: false,
		navGroup: "Imports",
		createdAt: T0,
		updatedAt: T0,
	};
	const field = (offset, slug, type, columnType, extra = {}) => ({
		kind: "field",
		id: fixtureId(base + offset),
		collectionId: id,
		slug,
		label: slug,
		type,
		columnType,
		required: false,
		unique: false,
		sortOrder: offset,
		searchable: false,
		translatable: true,
		indexed: false,
		createdAt: T0,
		...extra,
	});
	const fields = [
		field(1, "title", "string", "TEXT", { required: true, searchable: true, indexed: true }),
		field(2, "content", "portableText", "JSON", { searchable: true }),
		field(3, "rating", "number", "REAL", { required: true, defaultValue: 2.5 }),
		field(4, "related", "reference", "TEXT", { indexed: true, options: { collection: "pages" } }),
		field(5, "published", "datetime", "TEXT"),
	];
	for (let index = 0; index < extraFields; index++) {
		fields.push(field(10 + index, `extra_${index}`, "string", "TEXT"));
	}
	return { record, fields };
}

/**
 * A second record with different values in every column the first one sets, and one
 * field per field type `FIELD_TYPE_TO_COLUMN` knows.
 */
export function everyTypeFixture(n) {
	const base = 10_000 + n * 1000;
	const id = fixtureId(base);
	const record = {
		kind: "collection",
		id,
		slug: `every_type_${n}`,
		label: "Every type",
		labelSingular: "One of every type",
		description: "Holds one field of each type",
		icon: "grid",
		supports: ["drafts"],
		source: "template:blog",
		searchConfig: { enabled: false, weights: { f_string: 2, f_text: 1 } },
		hasSeo: false,
		urlPattern: "/every/{slug}",
		commentsEnabled: false,
		commentsModeration: "first_time",
		commentsClosedAfterDays: 7,
		commentsAutoApproveUsers: true,
		hidden: true,
		sortOrder: 11,
		adminConfig: { listColumns: ["f_string", "f_integer"], nested: { a: [1, { b: null }] } },
		titleField: "f_string",
		dateField: "f_datetime",
		routable: false,
		editLocking: true,
		navGroup: "Other",
		createdAt: "2025-03-04T05:06:07.000Z",
		updatedAt: "2025-08-09T10:11:12.000Z",
	};
	const fields = Object.entries(FIELD_TYPE_TO_COLUMN).map(([type, columnType], index) => ({
		kind: "field",
		id: fixtureId(base + 1 + index),
		collectionId: id,
		slug: `f_${type.toLowerCase()}`,
		label: `Field ${type}`,
		type,
		columnType,
		required: type === "integer" || type === "json",
		unique: type === "slug",
		// Stored order deliberately runs against the id order.
		sortOrder: 100 - index,
		searchable: type === "text",
		translatable: index % 2 === 0,
		indexed: type === "string" || type === "integer",
		widget: type === "string" ? "core:input" : undefined,
		createdAt: "2025-03-04T05:06:07.000Z",
		...(type === "integer" ? { defaultValue: 7 } : {}),
		...(type === "json" ? { defaultValue: { on: true } } : {}),
		...(type === "select" ? { validation: { options: ["a", "b"] } } : {}),
		...(type === "reference" ? { options: { collection: "pages" } } : {}),
		...(type === "blocks" ? { validation: { blocks: [] } } : {}),
		...(type === "repeater"
			? { validation: { subFields: [{ slug: "line", label: "Line", type: "string" }] } }
			: {}),
	}));
	for (const field of fields) if (field.widget === undefined) delete field.widget;
	return { record, fields };
}

/** Fixture lookup by name, so story params can name which record to import. */
export function fixtureNamed(name, n, extraFields = 0) {
	return name === "every_type" ? everyTypeFixture(n) : collectionFixture(n, extraFields);
}

function withoutKeys(value, keys) {
	const copy = { ...value };
	for (const key of keys) delete copy[key];
	return copy;
}

/** The stored collection row, read back as record properties (NULL columns omitted). */
export async function storedCollectionRecord(db, id) {
	const row = await db
		.selectFrom("_emdash_collections")
		.selectAll()
		.where("id", "=", id)
		.executeTakeFirst();
	if (!row) return undefined;
	return withoutKeys(decodeRow(db, getPortableTableSpec("_emdash_collections").columns, row), [
		"searchConfig",
	]);
}

/** The stored field rows of a collection in `sort_order`, read back as record properties. */
export async function storedFieldRecords(db, collectionId) {
	const rows = await db
		.selectFrom("_emdash_fields")
		.selectAll()
		.where("collection_id", "=", collectionId)
		.orderBy("sort_order")
		.execute();
	const { columns } = getPortableTableSpec("_emdash_fields");
	return rows.map((row) => decodeRow(db, columns, row));
}

/** What `storedCollectionRecord` should give back for a fixture's record. */
export function expectedCollectionRecord(fixture) {
	return withoutKeys(fixture.record, ["kind", "searchConfig"]);
}

/** What `storedFieldRecords` should give back for a fixture's fields. */
export function expectedFieldRecords(fixture) {
	return fixture.fields
		.map((field) => withoutKeys(field, ["kind"]))
		.toSorted((a, b) => a.sortOrder - b.sortOrder);
}

/**
 * The stored search setting. `off` is true when the row has no setting or `enabled` is
 * false, and no search index table exists for the collection.
 */
export async function storedSearchState(db, id) {
	const { search_config: config, slug } = await db
		.selectFrom("_emdash_collections")
		.select(["search_config", "slug"])
		.where("id", "=", id)
		.executeTakeFirstOrThrow();
	const index = await sql`SELECT name FROM sqlite_master WHERE name = ${`_emdash_fts_${slug}`}`.execute(db);
	const disabled = config === null || JSON.parse(config).enabled === false;
	return { off: disabled && index.rows.length === 0 };
}

function normalizeIndexSql(text, table) {
	return text
		.replace(/^CREATE\s+(UNIQUE\s+)?INDEX\s+(IF\s+NOT\s+EXISTS\s+)?\S+\s+ON\s+\S+\s*/i, (_, unique) =>
			unique ? "unique " : "",
		)
		.replaceAll(table, "<table>")
		.replaceAll('"', "")
		.replaceAll(/\s+/g, "")
		.toLowerCase();
}

/**
 * A content table's definition, free of index names: columns with type, NOT NULL,
 * default and primary key, then one normalized entry per index or unique constraint.
 */
export async function contentTableDefinition(db, slug) {
	const table = `ec_${slug}`;
	const columns = await sql`SELECT name, type, "notnull" AS required, dflt_value AS dflt, pk FROM pragma_table_info(${table}) ORDER BY name`.execute(db);
	const indexes = await sql`SELECT sql FROM sqlite_master WHERE type = 'index' AND tbl_name = ${table} AND sql IS NOT NULL`.execute(db);
	const constraints = await sql`SELECT il.name AS name, group_concat(ii.name) AS columns FROM pragma_index_list(${table}) AS il JOIN pragma_index_info(il.name) AS ii WHERE il.origin = 'u' GROUP BY il.name`.execute(db);
	return {
		columns: columns.rows.map((column) => ({
			...column,
			type: String(column.type).toLowerCase(),
			dflt: column.dflt === null ? null : String(column.dflt).replaceAll(/\s+/g, ""),
		})),
		indexes: [
			...indexes.rows.map((row) => normalizeIndexSql(row.sql, table)),
			...constraints.rows.map((row) => `constraint:${row.columns}`),
		].toSorted(),
	};
}

/** The definition the normal create path builds for a fixture's slug and fields, on a fresh database. */
export async function normalTableDefinition(fixture) {
	const ctx = await setupForDialect("sqlite");
	try {
		await new SchemaRegistry(ctx.db).createSeedCollection(
			{ slug: fixture.record.slug, label: fixture.record.label },
			fixture.fields.map((field) => ({
				slug: field.slug,
				label: field.label,
				type: field.type,
				required: field.required,
				unique: field.unique,
				defaultValue: field.defaultValue,
				validation: field.validation,
				options: field.options,
				sortOrder: field.sortOrder,
				searchable: field.searchable,
				indexed: field.indexed,
				translatable: field.translatable,
			})),
		);
		return await contentTableDefinition(ctx.db, fixture.record.slug);
	} finally {
		await teardownForDialect(ctx);
	}
}

/** Every schema object in the database plus the collection, field and tracking rows. */
export async function databaseSnapshot(db) {
	const objects = await sql`SELECT type, name, tbl_name, sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type, name`.execute(db);
	const rows = async (table, key) =>
		db.selectFrom(table).selectAll().orderBy(key).execute();
	return {
		objects: objects.rows,
		collections: await rows("_emdash_collections", "id"),
		fields: await rows("_emdash_fields", "id"),
		tracking: await rows("_emdash_media_usage_index_status", "scope_key"),
		deletions: await rows("_emdash_media_usage_collection_deletions", "collection_id"),
	};
}

/** Back-dates a collection's tracking row, so any later rewrite of it shows in a snapshot. */
export async function ageTrackingRow(db, slug) {
	await db
		.updateTable("_emdash_media_usage_index_status")
		.set({ updated_at: "2001-01-01T00:00:00.000Z" })
		.where("scope_key", "=", slug)
		.execute();
}

/** Deletes a collection the normal way, so with tracking active it sits in the deletion queue. */
export async function deleteCollectionNormally(db, slug) {
	await new SchemaRegistry(db).deleteCollection(slug, { force: true });
}

/**
 * Runs the real deletion processor until only the queue row's last step remains: the
 * collection row, table and tracking row are gone, and the slug is still in the queue.
 */
export async function runDeletionToLastStep(db, slug) {
	const keepQueueRow = {
		transformQuery: ({ node }) => {
			const table = node.from?.froms?.[0]?.table?.identifier?.name;
			if (node.kind === "DeleteQueryNode" && table === "_emdash_media_usage_collection_deletions") {
				throw new Error("last step held back");
			}
			return node;
		},
		transformResult: async ({ result }) => result,
	};
	for (let tick = 0; tick < 50; tick++) {
		const row = await db
			.selectFrom("_emdash_media_usage_collection_deletions")
			.select("phase")
			.where("collection_slug", "=", slug)
			.executeTakeFirstOrThrow();
		if (row.phase === "finalize") break;
		await processDueMediaUsageCollectionDeletions(db.withPlugin(keepQueueRow)).catch(() => undefined);
	}
	const { phase } = await db
		.selectFrom("_emdash_media_usage_collection_deletions")
		.select("phase")
		.where("collection_slug", "=", slug)
		.executeTakeFirstOrThrow();
	if (phase !== "finalize") throw new Error(`Deletion stopped in phase ${phase}`);
}

/** Which of `slugs` the app's shared collection cache knows; the first call fills the cache. */
export async function cachedCollectionSlugs(db, slugs) {
	return [...(await filterToRegisteredCollections(db, slugs))];
}

/** Leaves a content table for `fixture` holding only the first of its field columns. */
export async function plantNarrowTable(db, fixture) {
	const table = `ec_${fixture.record.slug}`;
	const column = fixture.fields[0].slug;
	await sql`CREATE TABLE ${sql.ref(table)} (id TEXT PRIMARY KEY, slug TEXT, ${sql.ref(column)} TEXT)`.execute(db);
}

/** Removes a field through the registry, the way the admin UI does. */
export async function deleteFieldNormally(db, slug, fieldSlug) {
	await new SchemaRegistry(db).deleteField(slug, fieldSlug);
}

/** Field slugs in the order the registry reports them for a collection. */
export async function registryFieldSlugs(db, slug) {
	const collection = await new SchemaRegistry(db).getCollectionWithFields(slug);
	return collection?.fields.map((field) => field.slug);
}

function replaceField(fields, index, changes) {
	return fields.map((field, position) => (position === index ? { ...field, ...changes } : field));
}

const extraField = (fixture, id) => ({
	...fixture.fields[1],
	id,
	slug: "brand_new",
	label: "Brand new",
	sortOrder: 99,
	indexed: false,
	required: false,
	searchable: false,
});

/**
 * The input a refusal case attempts. `base` is the fixture already imported into the
 * target, `fresh` is a fixture with ids and a slug the target has never seen.
 */
export function refusalInput(mode, base, fresh) {
	const newId = fixtureId(90_000 + Number(fresh.record.slug.replace(/\D/g, "")));
	const onBase = (recordChanges, fields = base.fields) => ({
		record: { ...base.record, ...recordChanges },
		fields,
	});
	const onFresh = (recordChanges, fields = fresh.fields) => ({
		record: { ...fresh.record, ...recordChanges },
		fields,
	});
	switch (mode) {
		// Stored rows that differ from the package.
		case "stored_collection_label":
			return onBase({ label: "Changed" });
		case "stored_collection_json":
			return onBase({ adminConfig: { listColumns: ["content"] } });
		case "stored_collection_flag":
			return onBase({ hasSeo: !base.record.hasSeo });
		case "stored_title_field":
			return onBase({ titleField: "content" });
		case "stored_date_field_absent": {
			const { dateField: _unused, ...record } = base.record;
			return { record, fields: base.fields };
		}
		case "stored_field_label":
			return onBase({}, replaceField(base.fields, 0, { label: "Changed" }));
		case "stored_field_json":
			return onBase({}, replaceField(base.fields, 3, { options: { collection: "posts" } }));
		case "stored_field_flag":
			return onBase({}, replaceField(base.fields, 0, { required: false }));
		case "stored_field_order":
			return onBase({}, replaceField(base.fields, 0, { sortOrder: 77 }));
		case "stored_field_type":
			return onBase({}, replaceField(base.fields, 0, { type: "number", columnType: "REAL" }));
		case "package_lacks_stored_field":
			return onBase({}, base.fields.slice(1));
		case "package_adds_field":
			return onBase({}, [...base.fields, extraField(base, newId)]);
		case "field_slug_other_id_with_new_field":
			return onBase({}, [
				...replaceField(base.fields, 0, { id: newId }),
				extraField(base, fixtureId(91_000 + Number(fresh.record.slug.replace(/\D/g, "")))),
			]);
		case "table_lacks_field_columns":
			return onFresh({});
		// Ids and slugs another collection already holds.
		case "collection_slug_held":
			return onFresh({ slug: base.record.slug });
		case "collection_id_held":
			return {
				record: { ...fresh.record, id: base.record.id },
				fields: fresh.fields.map((field) => ({ ...field, collectionId: base.record.id })),
			};
		case "field_id_held":
			return onFresh({}, replaceField(fresh.fields, 1, { id: base.fields[0].id }));
		// Input that is wrong on its own.
		case "collection_slug_invalid":
			return onFresh({ slug: "Not A Slug" });
		case "collection_slug_reserved":
			return onFresh({ slug: "content" });
		case "field_slug_invalid":
			return onFresh({}, replaceField(fresh.fields, 1, { slug: "Not A Slug" }));
		case "field_slug_reserved":
			return onFresh({}, replaceField(fresh.fields, 1, { slug: "status" }));
		case "field_slug_reserved_not_a_column":
			return onFresh({}, replaceField(fresh.fields, 1, { slug: "terms" }));
		case "field_slug_duplicate":
			return onFresh({}, replaceField(fresh.fields, 1, { slug: fresh.fields[0].slug }));
		case "field_id_duplicate":
			return onFresh({}, replaceField(fresh.fields, 1, { id: fresh.fields[0].id }));
		case "field_of_other_collection":
			return onFresh({}, replaceField(fresh.fields, 1, { collectionId: base.record.id }));
		case "column_type_contradicts":
			return onFresh({}, replaceField(fresh.fields, 0, { columnType: "INTEGER" }));
		case "field_type_unknown":
			return onFresh({}, replaceField(fresh.fields, 0, { type: "hologram" }));
		case "index_on_unindexable_type":
			return onFresh({}, replaceField(fresh.fields, 1, { indexed: true }));
		case "collection_label_missing": {
			const { label: _unused, ...record } = fresh.record;
			return { record, fields: fresh.fields };
		}
		case "collection_flag_not_boolean":
			return onFresh({ hasSeo: "yes" });
		case "collection_order_not_integer":
			return onFresh({ sortOrder: "first" });
		case "field_label_missing": {
			const { label: _unused, ...field } = fresh.fields[1];
			return { record: fresh.record, fields: [fresh.fields[0], field, ...fresh.fields.slice(2)] };
		}
		case "field_order_not_integer":
			return onFresh({}, replaceField(fresh.fields, 2, { sortOrder: "last" }));
		default:
			throw new Error(`Unknown refusal mode ${mode}`);
	}
}

async function indexNames(db, table) {
	const rows = isPostgres(db)
		? await sql`
				SELECT indexname AS name FROM pg_indexes
				WHERE schemaname = current_schema() AND tablename = ${table}
			`.execute(db)
		: await sql`
				SELECT name FROM sqlite_master WHERE type = 'index' AND tbl_name = ${table}
			`.execute(db);
	return rows.rows.map((row) => row.name).filter((name) => !name.startsWith("sqlite_autoindex"));
}

/**
 * Snapshot the stored shape of an imported collection, with its slug and
 * field ids abstracted away so two fixtures with different numbers compare
 * equal when their schema shape matches. Reads only the pre-existing tables
 * `_emdash_collections`, `_emdash_fields`, `_emdash_media_usage_index_status`
 * and the collection's own `ec_<slug>` content table.
 */
export async function collectionShape(db, fixture) {
	const { record, fields } = fixture;
	const table = `ec_${record.slug}`;
	const normalize = (value) => {
		let text = value.replaceAll(record.slug, "<slug>").replaceAll(record.id, "<id>");
		for (const field of fields) text = text.replaceAll(field.id.toLowerCase(), `<${field.slug}>`);
		for (const field of fields) text = text.replaceAll(field.id, `<${field.slug}>`);
		return text;
	};
	const collection = await db
		.selectFrom("_emdash_collections")
		.selectAll()
		.where("id", "=", record.id)
		.executeTakeFirst();
	const storedFields = await db
		.selectFrom("_emdash_fields")
		.selectAll()
		.where("collection_id", "=", record.id)
		.orderBy("sort_order")
		.execute();
	const lifecycle = await db
		.selectFrom("_emdash_media_usage_index_status")
		.select(["collection_id", "capture_state", "cursor"])
		.where("scope_key", "=", record.slug)
		.executeTakeFirst();
	return {
		collection: collection ? normalize(JSON.stringify(collection)) : null,
		fields: storedFields.map((row) => normalize(JSON.stringify(row))),
		columns: (await listTableColumns(db, table)).map((column) => `${column.name}:${column.type}`),
		indexes: (await indexNames(db, table)).map(normalize).toSorted(),
		lifecycle: lifecycle ? normalize(JSON.stringify(lifecycle)) : null,
		triggers: await verifyMediaUsageCaptureTriggers(db, {
			collectionId: record.id,
			collectionSlug: record.slug,
		}),
	};
}

/**
 * Counts every executed statement and can simulate a crash: once armed with
 * `failAfter(n)`, the nth statement from now (and every later one) throws
 * "injected crash" until `disarm()`, so an import that swallows one error
 * cannot quietly carry on. Also records the largest bind-parameter count seen
 * on any single statement.
 */
export class FaultPlugin {
	executed = 0;
	maxParameters = 0;
	#failAfter = null;
	#dead = false;
	#compile = null;

	bindCompiler(db) {
		const executor = db.getExecutor();
		this.#compile = (node) => executor.compileQuery(node, { queryId: "fault" }).parameters.length;
	}

	/** Crash after the `n`th statement from now executes. */
	failAfter(n) {
		this.#failAfter = this.executed + n;
	}

	get crashed() {
		return this.#dead;
	}

	disarm() {
		this.#failAfter = null;
		this.#dead = false;
	}

	transformQuery(args) {
		if (this.#dead) throw new Error("injected crash");
		if (this.#compile) {
			this.maxParameters = Math.max(this.maxParameters, this.#compile(args.node));
		}
		return args.node;
	}

	async transformResult(args) {
		this.executed++;
		if (this.#failAfter !== null && this.executed >= this.#failAfter) {
			this.#failAfter = null;
			this.#dead = true;
			throw new Error("injected crash");
		}
		return args.result;
	}
}

/**
 * Gives a Kysely instance D1's answer to transactions: the callback runs directly
 * against the database, so a statement that ran stays applied when a later one fails.
 * This is the same path the repo's `withTransaction` takes on D1.
 */
function withoutTransactions(db) {
	const proxy = new Proxy(db, {
		get(target, key) {
			if (key === "transaction") {
				return () => ({ execute: (callback) => callback(proxy) });
			}
			const value = Reflect.get(target, key, target);
			return typeof value === "function" ? value.bind(target) : value;
		},
	});
	return proxy;
}

/** Wrap a Kysely instance with a {@link FaultPlugin}; returns both. */
export function withFaults(db) {
	const faults = new FaultPlugin();
	const faulty = withoutTransactions(db.withPlugin(faults));
	faults.bindCompiler(db);
	return { db: faulty, faults };
}
