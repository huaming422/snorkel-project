// @ts-nocheck
/**
 * The repo's own suites for the schema registry and media-usage activation, run
 * together from one file. Each import registers that file's tests here.
 */
import "../../unit/schema/registry.test.js";
import "../../unit/schema/collection-title-date-fields.test.js";
import "../../unit/schema/seed-fingerprint.test.js";
import "../database/media-usage-activation.test.js";
