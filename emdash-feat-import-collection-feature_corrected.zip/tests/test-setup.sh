#!/usr/bin/env bash
# Sourced (not exec'd) so env vars stay alive for vitest. Idempotent. The
# dependency closure is baked into the image, so nothing here needs a network
# unless node_modules was removed.

set -e

REPO_DIR="${REPO_DIR:-/repo/emdash}"
cd "$REPO_DIR"

node --version
pnpm --version

# Install workspace deps if missing. The image bakes the full closure into the
# pnpm store at the base commit, so this is an offline no-op on a clean image;
# the online fallback only matters if node_modules was removed.
if [ ! -d "node_modules/.pnpm" ]; then
    echo "[test-setup] pnpm install (offline, frozen)..."
    if ! pnpm install --frozen-lockfile --offline > /tmp/test-setup-install.log 2>&1; then
        echo "[test-setup] offline install failed; retrying online..." >&2
        pnpm install --frozen-lockfile > /tmp/test-setup-install.log 2>&1 \
            || { tail -60 /tmp/test-setup-install.log >&2; exit 1; }
    fi
    tail -5 /tmp/test-setup-install.log || true
fi

# @emdash-cms/core's vitest config resolves the package's own sources via the
# dev-source condition, so the integration/unit tests under packages/core/tests
# run directly against packages/core/src with no prebuilt dist required. If a
# consumer package needs built artifacts we build core defensively (cheap on a
# tsdown incremental cache); a failed build does not block the suite that reads
# source directly.
echo "[test-setup] ensuring @emdash-cms/core is buildable (source-tested)..."
pnpm --filter @emdash-cms/core build > /tmp/test-setup-build.log 2>&1 \
    || { echo "[test-setup] core build skipped/failed (tests read source):" >&2; tail -20 /tmp/test-setup-build.log >&2 || true; }

# Make workspace binaries available.
export PATH="$REPO_DIR/node_modules/.bin:$PATH"

echo "[test-setup] ready: $REPO_DIR (node=$(node --version), pnpm=$(pnpm --version))"
