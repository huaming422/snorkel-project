#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# Investigation/performance task: no services and no data seeding. This only
# brings the baked build up to date (offline-first) so the verifiers can measure
# the interpreter built from the working tree. No assertion logic lives here.
cd /repo/RustPython

# Fail fast on a cache miss instead of reaching for a dead network. The image
# baked the full crate closure (CARGO_HOME warm) and pre-built both the test
# profile and the release `rustpython` binary; this switch keeps a grade-time
# rebuild from trying to hit crates.io. Set it here, never in image ENV
# (the test harness installs its own tooling with the network up before the
# checks run).
export CARGO_NET_OFFLINE=true

# Release binary: the deterministic callgrind measurement runs the release
# `rustpython` built from the working tree, implementation changes included.
# Offline-first against the image bake, logged online fallback if the bake was
# stale. Check the exit status directly; never pipe to `tail`, which would mask it.
if cargo build --locked --release --bin rustpython > /tmp/test-setup-build.log 2>&1; then
    echo "[offline-first] release rustpython build satisfied from image"
elif CARGO_NET_OFFLINE=false cargo build --locked --release --bin rustpython >> /tmp/test-setup-build.log 2>&1; then
    echo "[test-setup] release rustpython rebuilt online (image bake was stale)"
else
    tail -40 /tmp/test-setup-build.log >&2
    exit 1
fi

# valgrind (callgrind) is baked into the image's apt layer; no lazy install.
command -v valgrind > /dev/null || { echo "valgrind missing from image" >&2; exit 1; }
