#!/usr/bin/env bash
# Python attribute and method resolution keeps returning what the interpreter
# returns today once access sites are warm: a class method or class attribute
# shadowed after warm-up, attributes deleted or added (directly or through the
# dict's own methods), __dict__ replaced or cleared, dicts with holes, instances
# that share an access site but hold different names, instances whose __dict__
# is a dict subclass with overridden lookup and store methods, and a store whose
# replaced value has a finalizer that reads the same object.
#
# Runs the built `rustpython` interpreter over a snippet of self-asserting
# scenarios and passes iff it exits 0 and prints the success sentinel. Every
# scenario is ordinary Python run through the normal attribute-access path; none
# of them depends on how a warm access is made cheaper. The run is capped at
# SCENARIO_TIMEOUT seconds (a few seconds is normal), so an access that
# deadlocks fails here with the name of the scenario it was in instead of
# hanging until the runner's own timeout.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SNIPPET="${SCRIPT_DIR}/correctness_scenarios.py"

BIN=""
for cand in \
    "${CARGO_TARGET_DIR:-}/release/rustpython" \
    "/repo/RustPython/target/release/rustpython" \
    "$(pwd)/target/release/rustpython"; do
    if [[ -n "${cand}" && -x "${cand}" ]]; then BIN="${cand}"; break; fi
done
if [[ -z "${BIN}" ]]; then
    echo "FAIL: release rustpython binary not found (expected under CARGO_TARGET_DIR/release)" >&2
    exit 1
fi
echo "interpreter: ${BIN}"

SCENARIO_TIMEOUT=300
OUT="$(mktemp /tmp/correctness.XXXXXX.log)"
RC=0
timeout "${SCENARIO_TIMEOUT}" "${BIN}" "${SNIPPET}" >"${OUT}" 2>&1 || RC=$?
if [[ "${RC}" -eq 124 ]]; then
    echo "FAIL: scenarios did not finish within ${SCENARIO_TIMEOUT}s; the last 'running' line names the scenario that hung" >&2
    tail -40 "${OUT}" >&2
    rm -f "${OUT}"
    exit 1
fi
if [[ "${RC}" -ne 0 ]]; then
    echo "FAIL: attribute/method-resolution scenarios did not all pass" >&2
    tail -40 "${OUT}" >&2
    rm -f "${OUT}"
    exit 1
fi
if ! grep -qx "ok" "${OUT}"; then
    echo "FAIL: scenarios ran without the expected success sentinel" >&2
    tail -40 "${OUT}" >&2
    rm -f "${OUT}"
    exit 1
fi
rm -f "${OUT}"
echo "PASS: attribute and method resolution preserved across shadowing, key changes, __dict__ replacement, holes, shared access sites, dict subclass loads and stores, and finalizers during stores"
exit 0
