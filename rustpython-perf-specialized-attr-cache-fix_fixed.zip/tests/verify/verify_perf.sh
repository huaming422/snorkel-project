#!/usr/bin/env bash
# Once an object's attribute set has stopped changing, warm attribute reads,
# method calls and value stores must stop paying a per-access instance-dict hash
# and probe.
#
# Measurement is a DETERMINISTIC work count, never wall-clock. We run the built
# `rustpython` interpreter over a fixed warm attribute-access workload under
# callgrind (valgrind's call-graph simulator, reproducible across runs) at two
# sizes N1 < N2 and read two numbers from each run:
#
#   * how many times the program calls the instance dict's hash/probe routine
#     (`Dict::lookup`, the probe every keyed dict access goes through at the
#     base commit), and
#   * the total number of guest instructions executed (callgrind's Ir total).
#
# Both signals are SLOPES, not absolute counts:
#   calls_delta  = calls(N2) - calls(N1)
#   ir_per_pass  = (Ir(N2) - Ir(N1)) / (N2 - N1)
# Taking the difference of two runs of the SAME workload cancels everything
# that does not repeat per pass (start-up, imports, warm-up, one-time
# specialization), so both numbers describe only the marginal cost of a warm
# pass over the 64 objects.
#
# The call slope decides. A warm access that still probes the instance dict
# makes calls_delta grow with N2 - N1 (320 calls per pass at the base commit,
# five accesses per object), while an access that can tell the attribute set is
# unchanged keeps it flat.
#
# The call count only means something while the probe routine is visible to
# callgrind as a function of its own. Start-up and imports alone call it tens of
# thousands of times, so a run that shows (almost) no calls at all means the
# routine was inlined into its callers or renamed, and the call slope would read
# zero even if every warm access still probes. In that case the instruction
# slope decides instead. Measured with valgrind 3.18.1 on the image's release
# build:
#   base commit                          ir_per_pass ~ 436,800
#   base commit, probe forced inline     ir_per_pass ~ 427,700 (0 lookup calls)
#   the five per-access probes removed   ir_per_pass ~ 416,500
# MAX_IR_PER_PASS sits between the last two, so hiding the probe from the counter
# is not enough; the per-pass work has to go down by about as much as removing
# the probes saves.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKLOAD="${SCRIPT_DIR}/perf_workload.py"
COUNTER="${SCRIPT_DIR}/count_calls.py"

# Fix the string-hash seed so the instance-dict probe sequence is identical from
# run to run; combined with callgrind's simulated (noise-free) counting this makes
# the measured counts reproducible.
export PYTHONHASHSEED=0

# Two steady-state sizes. Both are far past the adaptive-specialization warmup
# (the workload warms every access site for 400 rounds first), so every measured
# pass is steady state.
N1=4000
N2=8000
# Bound on the growth in hash/probe calls between N1 and N2. A warm access that
# still probes adds 64 calls per pass per access site (256,000 over 4,000
# passes); 50,000 admits any guard that only re-probes occasionally.
MAX_DELTA=50000
# Fewest lookup calls the N1 run must show for the call count to be trusted.
# Start-up and imports alone make tens of thousands of them.
MIN_VISIBLE_CALLS=1000
# Bound on the instructions executed per warm pass, used only when the probe
# routine is not visible (see the header).
MAX_IR_PER_PASS=422000

# Locate the release interpreter built from the working tree (test-setup.sh
# built it offline-first). CARGO_TARGET_DIR is set image-wide; fall back to the
# in-repo target/ if it was overridden.
BIN=""
for cand in \
    "${CARGO_TARGET_DIR:-}/release/rustpython" \
    "/repo/RustPython/target/release/rustpython" \
    "$(pwd)/target/release/rustpython"; do
    if [[ -n "${cand}" && -x "${cand}" ]]; then BIN="${cand}"; break; fi
done
if [[ -z "${BIN}" ]]; then
    echo "FAIL: release rustpython binary not found (expected under CARGO_TARGET_DIR/release)" >&2
    exit 1
fi
echo "interpreter: ${BIN}"

command -v valgrind >/dev/null || { echo "FAIL: valgrind missing" >&2; exit 1; }

# Prime the interpreter's bytecode cache (Lib/__pycache__) with one short native
# run of the same workload. Without it, whichever measured run comes first also
# compiles the standard-library modules it imports, which inflates that run
# alone and skews both slopes. A failure here is reported by the measured runs.
"${BIN}" "${WORKLOAD}" 50 >/dev/null 2>&1 || true

# Regex for the instance-dict lookup/probe routine. Matches every
# monomorphization of rustpython_vm::dict_inner::Dict::lookup, whether callgrind
# prints the symbol mangled (thin-LTO local symbols carry a `.llvm.<n>` suffix
# that valgrind does not demangle, giving ...dict_inner...6lookup17h...) or
# demangled (rustpython_vm::dict_inner::Dict<T>::lookup). It is used only as a
# COUNT TARGET; the behavior under test is driven entirely through the normal
# Python attribute-access path.
LOOKUP_RE='dict_inner.*(6lookup|::lookup(?![_0-9A-Za-z]))'

run_measure() {
    # $1 = N ; echoes "<lookup calls> <total Ir>" for that run.
    local n="$1" out res
    out="$(mktemp /tmp/callgrind.XXXXXX.out)"
    res="$(mktemp /tmp/workload.XXXXXX.txt)"
    # --cache-sim/--branch-sim off: only call counts and instruction totals are
    # needed, and turning the simulators off keeps the run fast. valgrind exits
    # with the interpreter's own status, and the workload prints one integer
    # when it finishes, so a crashed or truncated run cannot be measured.
    if ! valgrind --tool=callgrind \
        --callgrind-out-file="${out}" \
        --cache-sim=no --branch-sim=no --dump-line=no \
        "${BIN}" "${WORKLOAD}" "${n}" >"${res}" 2>/dev/null \
        || ! grep -qE '^-?[0-9]+$' "${res}"; then
        echo "FAIL: workload did not run to completion under callgrind for N=${n}" >&2
        head -c 2000 "${res}" >&2
        rm -f "${out}" "${res}"
        exit 1
    fi
    local c ir
    c="$(python3 "${COUNTER}" "${out}" "${LOOKUP_RE}")"
    ir="$(awk '/^(summary|totals):/ {print $2; exit}' "${out}")"
    rm -f "${out}" "${res}"
    if ! [[ "${c}" =~ ^[0-9]+$ ]]; then
        echo "FAIL: could not parse lookup count for N=${n} (got '${c}')" >&2
        exit 1
    fi
    if ! [[ "${ir}" =~ ^[0-9]+$ ]]; then
        echo "FAIL: could not parse instruction total for N=${n} (got '${ir}')" >&2
        exit 1
    fi
    echo "${c} ${ir}"
}

# Plain assignments, so a failed measurement stops the script under set -e.
M1="$(run_measure "${N1}")"
M2="$(run_measure "${N2}")"
read -r C1 IR1 <<<"${M1}"
read -r C2 IR2 <<<"${M2}"
DELTA=$(( C2 - C1 ))
IR_PER_PASS=$(( (IR2 - IR1) / (N2 - N1) ))

echo "lookup calls: N=${N1} -> ${C1} ; N=${N2} -> ${C2} ; delta=${DELTA} (bound ${MAX_DELTA})"
echo "instructions: N=${N1} -> ${IR1} ; N=${N2} -> ${IR2} ; per pass=${IR_PER_PASS}"

if (( C1 >= MIN_VISIBLE_CALLS )); then
    if (( DELTA < MAX_DELTA )); then
        echo "PASS: steady-state attribute access does not scale dict hash/probe calls with iteration count (delta ${DELTA} < ${MAX_DELTA})"
        exit 0
    fi
    echo "FAIL: dict hash/probe calls grow with iteration count (delta ${DELTA} >= ${MAX_DELTA}); warm accesses still probe the instance dict" >&2
    exit 1
fi

# The probe routine never showed up as a call, so the call slope cannot tell a
# removed probe from a hidden one. Judge the warm pass by its total work.
echo "lookup routine not visible as a call (${C1} < ${MIN_VISIBLE_CALLS} calls in the N=${N1} run); using the instruction bound ${MAX_IR_PER_PASS}"
if (( IR_PER_PASS < MAX_IR_PER_PASS )); then
    echo "PASS: a warm pass executes ${IR_PER_PASS} < ${MAX_IR_PER_PASS} instructions"
    exit 0
fi
echo "FAIL: a warm pass still executes ${IR_PER_PASS} >= ${MAX_IR_PER_PASS} instructions; the per-access lookup work has not gone away" >&2
exit 1
