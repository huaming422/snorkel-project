# Steady-state attribute/method-access workload for the deterministic
# work-counter verifier.
#
# This is a plain Python program run by the built `rustpython` interpreter under
# callgrind. It builds many instances that share one attribute layout, warms the
# access sites well past the adaptive-specialization threshold, and then executes
# a long steady-state loop that reads attributes, calls a method, and does
# value-only attribute stores, all on an unchanging key set.
#
# The access count N (number of steady-state outer iterations) is taken from
# argv[1]. The verifier runs this at two values of N and measures how the
# instance-dict hash/probe call count grows per outer iteration: a warmed-up
# access that still probes the dict on every access grows that count linearly in
# N; an access that recognizes the layout is unchanged keeps it flat. The loop
# body is identical across both runs, so everything except the per-access work
# cancels in the difference.
#
# Everything here is observable public Python: classes, instance attributes,
# method calls, value reassignment. Nothing about the measurement is encoded in
# the program.

import sys


def build(count):
    class Point:
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

        def kind(self):
            return self.a

    return [Point() for _ in range(count)]


def warm(objs, rounds):
    # Run every access site far past the point where it settles, so the
    # measured loop below is entirely steady state. Includes a value-only
    # store so the store access site warms too.
    total = 0
    for _ in range(rounds):
        for o in objs:
            o.a = o.a + 1
            total += o.a + o.b + o.c + o.kind()
    return total


def measure(objs, n):
    acc = 0
    i = 0
    while i < n:
        for o in objs:
            acc += o.a + o.b + o.kind()   # attribute reads + a method call
            o.a = acc & 255               # value-only store (key set unchanged)
        i += 1
    return acc


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 100000
    objs = build(64)
    warmed = warm(objs, 400)
    result = measure(objs, n)
    # Print so the work is observable and the loop cannot be optimized away.
    print(warmed + result)


main()
