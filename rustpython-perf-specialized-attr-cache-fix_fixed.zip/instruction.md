## Task

Hot Python loops over many objects of one class run slow on RustPython, and they stay slow after warm-up.
The case we keep hitting is a list of instances of one class that all carry the same attributes, where every pass reads a couple of attributes, calls a method and writes a new value into an attribute the object already has.
Nobody adds or removes attributes inside the loop.
Only the values change.
Still, once the loop is warm, each of those reads, calls and writes pays the same per-access overhead on every pass, as if the interpreter had learned nothing from the passes before it.
Please find where that repeated cost comes from and take it off the warm path.

Treat this as a pure speed change.
Every attribute read, write and method call must behave exactly as it does today, before and after warm-up.
That includes an instance attribute hiding a class attribute or method, attributes that appear or go away once the loop is already warm, and a `__dict__` that gets replaced or edited through its own dict methods.
Objects whose `__dict__` is a dict subclass must also keep going through the subclass's overridden methods, as they do today.

## General instructions

- The code repo is at /repo/RustPython.
- You are inside of a Docker container with no network access. You may not be able to perform all operations you would normally be able to do on a local machine. The project's dependencies and toolchain are already installed and the package manager caches are populated, so build and test with what is in the image; anything that needs to be downloaded will fail rather than hang.
- You are expected to act autonomously as a software engineer to complete tasks you are given.
- Do not stop until you feel you have completed the task and your code changes can be merged.
- You may need to use software engineering skills like analyzing the codebase, researching technologies, running services, analyzing logs, etc. to complete the task. Not all tasks will be solvable by reading source code alone.
