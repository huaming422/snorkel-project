#!/usr/bin/env bash
# Pre-build the `wast` integration-test binary so the verifier's first
# `cargo test --test wast` only has to re-link and run the new fixtures.
# The image already compiled this target at the base commit (image block 10);
# this is an offline no-op when the target/ cache is warm.
set -euo pipefail

cd /repo/wasmtime

# Compile (but do not run) the wast test harness and its dependencies.
cargo test --no-run --locked -p wasmtime-cli --test wast \
    > /tmp/wast-build.log 2>&1 || { tail -80 /tmp/wast-build.log; exit 1; }

echo "wast test binary ready"
