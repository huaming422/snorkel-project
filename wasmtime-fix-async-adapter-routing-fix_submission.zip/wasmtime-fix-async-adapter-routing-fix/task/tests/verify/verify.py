"""Behavioral checks for composed-component async calls in Wasmtime.

These checks drive a set of bundled ``.wast`` test programs through
Wasmtime's own component-model test runner (the pre-existing ``wast``
integration-test target in the ``wasmtime-cli`` crate). Each ``.wast``
program composes separate components so that calls cross through the
adapters Wasmtime generates, with at least one side using the async
calling convention or an async-typed function. The embedded
``assert_return`` / ``assert_trap`` directives encode the correct
observable behavior: a program only passes when the composed call runs
and produces the expected result or trap.

The runner discovers ``.wast`` programs from disk at run time (no
recompile of the test binary needed to add programs), so these checks
drop the bundled programs into the component-model test directories and
then run the existing ``wast`` target. We assert the CraneliftNative
trial for each program passes; the Winch trial is intentionally ignored
because Winch does not support the component-model async path.

The checks never import repository internals: they drive the public
``cargo test`` command only, so any behaviorally-correct change that
makes these composed calls run correctly will pass regardless of how it
is structured internally.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
from pathlib import Path

import pytest


# Repository checkout inside the task container.
REPO_DIR = Path("/repo/wasmtime")

# Directory holding the bundled `.wast` programs (shipped flat next to
# this file) that we stage into the repo's test tree before running.
BUNDLE_DIR = Path(__file__).resolve().parent

# Component-model test directories the runner scans. Both pre-exist in
# the repo at the base commit; this is the stable, repo-owned layout the
# `wast` target already walks via `find_tests`.
ASYNC_DIR = REPO_DIR / "tests/misc_testsuite/component-model/async"
THREAD_DIR = REPO_DIR / "tests/misc_testsuite/component-model/thread-transparency"

# Each bundled program -> the repo directory it must live in to be
# discovered. The async programs land under the async directory; the one
# thread-transparency program lands under its own directory. The repo
# path each program ends up at is used (as a suffix) to pin the exact
# CraneliftNative trial when parsing runner output, so that programs with
# overlapping basenames (e.g. `variant-second-call` vs
# `default-flags-variant-second-call`) are never confused.
PROGRAMS = {
    "default-flags-sync-cancel.wast": ASYNC_DIR,
    "default-flags-variant-second-call.wast": ASYNC_DIR,
    "sync-callee-exit-drops-fiber.wast": ASYNC_DIR,
    "sync-lower-async-typed-entry-checks.wast": ASYNC_DIR,
    "sync-task-exit.wast": ASYNC_DIR,
    "threading-and-yields.wast": ASYNC_DIR,
    "variant-second-call.wast": ASYNC_DIR,
    "reentrancy.wast": THREAD_DIR,
}

# `cargo test --no-run` build ceiling. The container pre-compiled the
# `wast` target at the base commit; an accepted change only forces an
# incremental recompile of the touched crates plus a relink, which is a
# few minutes at most. The ceiling is generous so a cold relink never
# trips it, while the whole set still finishes well inside budget.
BUILD_TIMEOUT_SEC = 1500

# Per-program run ceiling. Running a single `.wast` program is a couple
# of CraneliftNative/Winch trials and completes in seconds; this is only
# a backstop against a hang.
RUN_TIMEOUT_SEC = 180

# Pretty-format libtest line: `test <name> ... <status>`.
_TRIAL_RE = re.compile(r"^test (?P<name>.+?) \.\.\. (?P<status>ok|FAILED|ignored)\b")


def _cargo_env() -> dict:
    """Environment for cargo, mirroring the image's baked toolchain paths."""
    env = {**os.environ}
    env.setdefault("CARGO_HOME", "/opt/cache/cargo")
    env.setdefault("RUSTUP_HOME", "/opt/rustup")
    env.setdefault("CARGO_TARGET_DIR", "/opt/cache/cargo-target")
    env["PATH"] = f"{env['CARGO_HOME']}/bin:" + env.get("PATH", "")
    return env


def _tail(text: str, n: int = 120) -> str:
    return "\n".join(text.splitlines()[-n:])


@pytest.fixture(scope="session")
def staged_and_built() -> None:
    """Stage the bundled programs and compile the `wast` target once.

    Copying the programs into the component-model test directories is all
    the setup the runner needs — it reads them from disk at run time.
    Compiling here (without running) pays the one-time build cost of the
    submitted change up front, so each per-program check below just runs
    the already-built binary.
    """
    # Stage every bundled program into its repo directory, overwriting any
    # same-named file already present so the intended program is the one
    # that runs.
    for name, dest_dir in PROGRAMS.items():
        src = BUNDLE_DIR / name
        assert src.is_file(), f"bundled program missing from checks package: {name}"
        dest_dir.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dest_dir / name)

    # Build (do not run) the component-model `.wast` target. A failure here
    # means the submitted change does not compile against the existing
    # component-model test binary.
    proc = subprocess.run(
        ["cargo", "test", "--no-run", "--locked", "-p", "wasmtime-cli", "--test", "wast"],
        cwd=str(REPO_DIR),
        capture_output=True,
        text=True,
        timeout=BUILD_TIMEOUT_SEC,
        env=_cargo_env(),
        check=False,
    )
    if proc.returncode != 0:
        raise AssertionError(
            "building the component-model `wast` target failed "
            f"(exit {proc.returncode}); the submitted change does not compile.\n"
            f"--- cargo stdout (tail) ---\n{_tail(proc.stdout)}\n"
            f"--- cargo stderr (tail) ---\n{_tail(proc.stderr)}"
        )


def _run_program(basename: str) -> str:
    """Run the `wast` target filtered to one program; return stdout+stderr."""
    proc = subprocess.run(
        [
            "cargo", "test", "--locked", "-p", "wasmtime-cli", "--test", "wast",
            "--", "--format", "pretty", "--test-threads", "1", basename,
        ],
        cwd=str(REPO_DIR),
        capture_output=True,
        text=True,
        timeout=RUN_TIMEOUT_SEC,
        env=_cargo_env(),
        check=False,
    )
    return proc.stdout + "\n" + proc.stderr


def _cranelift_status(output: str, dest_dir: Path, basename: str) -> str | None:
    """Status of the CraneliftNative trial for this exact program, or None.

    Matches on the program's full repo-path suffix so that overlapping
    basenames never cross-match.
    """
    suffix = f"{dest_dir.name}/{basename}"
    for line in output.splitlines():
        m = _TRIAL_RE.match(line.strip())
        if not m:
            continue
        # The runner right-pads trial names with spaces to align the status
        # column, so a shorter name running alongside a longer one in the same
        # filtered batch picks up trailing spaces; strip them before matching
        # the program's path suffix.
        name = m.group("name").strip()
        if name.startswith("CraneliftNative/") and name.endswith(suffix):
            return m.group("status")
    return None


@pytest.mark.parametrize("basename,dest_dir", list(PROGRAMS.items()))
def test_composed_async_program_runs_correctly(
    staged_and_built: None, basename: str, dest_dir: Path
) -> None:
    """The composed-component async program runs and asserts correctly.

    Passes only when the CraneliftNative trial for this program reports
    `ok`, i.e. every `assert_return` / `assert_trap` directive in the
    program held. A crash, wrong result, or unexpected trap surfaces as
    a `FAILED` trial here.
    """
    output = _run_program(basename)
    status = _cranelift_status(output, dest_dir, basename)

    assert status is not None, (
        f"no CraneliftNative trial found for {dest_dir.name}/{basename}; "
        "the program was not discovered or did not run.\n"
        f"--- runner output (tail) ---\n{_tail(output)}"
    )
    assert status == "ok", (
        f"CraneliftNative trial for {dest_dir.name}/{basename} reported "
        f"'{status}', expected 'ok': the composed async call did not run "
        "correctly.\n"
        f"--- runner output (tail) ---\n{_tail(output)}"
    )
