## Task

Some programs that drive the WebAssembly component model through Wasmtime's
async support crash or come back with wrong results instead of running
correctly. It shows up once separate components are wired together, so calls
cross through the adapters Wasmtime generates to bridge them, and one side of
such a call involves an `async`-typed function. Calls where nothing on either
side is async run fine. Dig into how these cross-component calls get set up and
executed, find what's broken, and fix it so they run correctly.
