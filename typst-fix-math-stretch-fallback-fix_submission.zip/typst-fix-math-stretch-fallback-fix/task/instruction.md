## Task

We're getting reports that equations look broken with certain math fonts. When the equation font is set to STIX Two Math, stretchy elements come out far too short: they stay at their small base size instead of growing to span the content they should cover. A delimiter around a fraction with a tall subscript, a square root over tall content, a wide accent like `hat`, they all stay small, so the element visibly doesn't fit what it encloses.

A minimal repro:

```typ
#show math.equation: set text(font: "STIX Two Math")
$ lr(a / b|)_sqrt(c / d) $
```

The `|` and the radical should grow to span the tall fraction, but they don't.

The telling part is that it's font-specific. The same documents render fine with New Computer Modern Math, and the same equations come out correct in LaTeX. It only goes wrong with certain math fonts; others render the same equations correctly. Can you dig in and fix it so these elements stretch correctly?
