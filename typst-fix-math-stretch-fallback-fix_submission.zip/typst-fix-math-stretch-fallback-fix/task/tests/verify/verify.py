"""Behavioral verifier for typst-fix-math-stretch-fallback.

Runs the four assertion-only cases in the sibling ``verify_stretch_fallback.typ``
through typst's own test harness and asserts each passes. The harness is the
only place the test world (120pt page, 10pt font) and the bundled STIX Two Math
font exist, so behavior is exercised there rather than by importing repo code.

This file shells out via ``subprocess`` only; it imports no repository code, so
it runs under ``VERIFIER_PYTHON`` with no ``[pytest] command`` override.

Why the direct ``cargo test`` form (not the ``cargo testit`` wrapper): the
wrapper swallows the test process's exit code (exits 0 even when a test fails),
so it cannot gate a reward. ``cargo test --workspace --test tests`` returns a
non-zero exit when the named test fails and 0 when it passes.
"""

from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

import pytest

# Grade-time layout: REPO_DIR is cwd (/repo/typst); this file lives in /tests/verify/.
REPO_DIR = Path(os.environ.get("REPO_DIR", os.getcwd()))
SUITE_DIR = REPO_DIR / "tests" / "suite" / "math"
VERIFY_TYP = Path(__file__).resolve().parent / "verify_stretch_fallback.typ"
INJECTED_TYP = SUITE_DIR / "verify_stretch_fallback.typ"

# cargo test timeout per named test (generous: first invocation builds the suite).
PER_TEST_TIMEOUT = 1800

# (criterion key in task.toml, harness test name in the .typ file)
CRITERIA = [
    ("stretch_fallback_delimiter", "verify-stretch-fallback-delimiter"),
    ("stretch_fallback_explicit", "verify-stretch-fallback-explicit"),
    ("no_fallback_when_sufficient", "verify-no-fallback-when-sufficient"),
    ("accent_flattened_fallback", "verify-accent-flattened-fallback"),
]


@pytest.fixture(scope="module", autouse=True)
def inject_verifier_typ():
    """Copy the verifier .typ into the math suite for the test session, remove after."""
    assert VERIFY_TYP.is_file(), f"verifier .typ missing: {VERIFY_TYP}"
    assert SUITE_DIR.is_dir(), f"math suite dir missing: {SUITE_DIR}"
    shutil.copyfile(VERIFY_TYP, INJECTED_TYP)
    try:
        yield
    finally:
        INJECTED_TYP.unlink(missing_ok=True)


def _run_harness_test(test_name: str) -> subprocess.CompletedProcess:
    env = {**os.environ, "CARGO_NET_OFFLINE": "true"}
    cmd = [
        "cargo", "test", "--workspace", "--test", "tests", "--locked", "--offline",
        "--", "--exact", test_name, "--stages", "render", "--no-report",
    ]
    return subprocess.run(
        cmd,
        cwd=str(REPO_DIR),
        env=env,
        capture_output=True,
        text=True,
        timeout=PER_TEST_TIMEOUT,
        check=False,
    )


@pytest.mark.parametrize("criterion,test_name", CRITERIA, ids=[c for c, _ in CRITERIA])
def test_stretch_fallback(criterion: str, test_name: str):
    proc = _run_harness_test(test_name)
    assert proc.returncode == 0, (
        f"[{criterion}] harness test {test_name!r} failed "
        f"(exit {proc.returncode}).\n"
        f"--- stdout ---\n{proc.stdout[-4000:]}\n"
        f"--- stderr ---\n{proc.stderr[-4000:]}"
    )
