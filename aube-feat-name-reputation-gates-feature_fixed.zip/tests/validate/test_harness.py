"""Shared helpers for the aube-feat-name-reputation-gates validation stories.

Every story shells out to the prebuilt `aube` CLI binary in a subprocess and
inspects the exit status plus combined stdout+stderr, so there is no shared
in-process state. This file exists because the build validator expects
`test_harness.py` alongside `validation_spec.toml`; stories import the small
helpers below (binary path, per-run project scaffolding, the add runners) so
each story file stays short.

The CLI is driven at its natural boundary: `aube add <name>` run in a throwaway
project directory, either with no controlling terminal (`run_add`) or attached
to a pseudo-terminal that answers one yes/no prompt (`run_add_tty`). The add
reputation checks only engage for names that resolve through the public
registry, and this phase has no route to it, so each run points `aube` at a
warmed, on-disk metadata+content snapshot baked into the image
(`/opt/aube-warm`, see the image build). The two real-world names the stories
install (`lodash`, `left-pad`) were resolved and installed into that snapshot
at build time; a per-run private COPY of it lets the CLI resolve and install
them with no network, and their registry metadata (including the first-publish
time) is read from that cache. `AUBE_FETCH_RETRIES=0` makes any name that is
NOT in the snapshot fail fast rather than retry-looping against the unreachable
registry.

Nothing here encodes the solution's internal symbol names, error-code
constants, message wording, or the name of the new recency-window setting;
those are implementation choices the submitted patch is free to make. A story
asserts observable outcomes (did the add succeed or was it refused, did it get
as far as resolving the name) and, where a refusal must be told apart from an
unrelated resolve failure, the presence of a real-world package name or of a
setting token the story DISCOVERS from the submitted patch.
"""

from __future__ import annotations

import datetime as _dt
import fcntl
import glob
import json
import os
import pty
import re
import select
import shutil
import subprocess
import tempfile
import termios
import time
import uuid

# Prebuilt aube binary. validation-setup.sh (re)builds it from the submitted
# edits before the stories run. CARGO_TARGET_DIR is pinned image-wide in the
# Dockerfile.
AUBE_BIN: str = "/opt/cache/cargo-target/debug/aube"

# Image-baked warm snapshot: a full-packument metadata cache + content store for
# the fixed real-world names the stories install, resolved+installed at build
# time while the registry was reachable (see the image Dockerfile, step "7b").
# Each run copies these into a throwaway project's private cache/store so no add
# can leak trust into a later case.
WARM_CACHE_SRC: str = "/opt/aube-warm/cache"
WARM_STORE_SRC: str = "/opt/aube-warm/store"

# First-publish time of `lodash` on the public registry (its packument's
# `time.created`, a fixed historical fact also present in the warm snapshot).
LODASH_CREATED: str = "2012-04-23T16:37:11.912Z"

# Base environment shared by every add invocation. These mirror the repository's
# own bats harness (test/test_helper/common_setup.bash), which turns OFF the
# unrelated public-API gates (OSV advisories + weekly-downloads) so a story
# exercises exactly the reputation check it targets. Both names are
# PRE-EXISTING settings in the base repo (grep `AUBE_ADVISORY_CHECK` /
# `AUBE_LOW_DOWNLOAD_THRESHOLD`), so pinning them here is not coupling to the
# submitted patch. `AUBE_FETCH_RETRIES=0` (also pre-existing: grep
# `AUBE_FETCH_RETRIES` / the `fetchRetries` setting) makes any name absent from
# the warm snapshot fail fast instead of retry-looping against the unreachable
# registry. The new recency-window setting is deliberately NOT set here: its name
# is the submitted patch's choice, so a story that needs it passes it through
# `env_overrides` (or `.npmrc`) after discovering it from the patch.
BASE_ENV: dict[str, str] = {
    "AUBE_ADVISORY_CHECK": "off",
    "AUBE_LOW_DOWNLOAD_THRESHOLD": "0",
    "AUBE_FETCH_RETRIES": "0",
    # Keep aube non-interactive and quiet; no TTY is attached in subprocess mode,
    # which on its own routes the gates to their refuse-without-asking branch.
    "CI": "1",
    "NO_COLOR": "1",
    "AUBE_UPDATE_NOTIFIER": "false",
}


def new_project(npmrc: str | None = None) -> str:
    """Create a throwaway project dir with a minimal package.json + private caches.

    A fresh directory per case keeps each add independent: a name added (or
    trusted via the lockfile) in one case can never leak trust into another. The
    image-baked warm metadata+content snapshot is copied in under private
    `cache/` and `store/` dirs. Optionally drops an `.npmrc` (used to set
    project-scoped settings such as the allow-list or the recency window) into
    the project root.
    """
    root = tempfile.mkdtemp(prefix="aube_rep_gate_")
    name = f"fixture-{uuid.uuid4().hex[:8]}"
    with open(os.path.join(root, "package.json"), "w", encoding="utf-8") as fh:
        fh.write(
            '{\n'
            f'  "name": "{name}",\n'
            '  "version": "1.0.0",\n'
            '  "private": true\n'
            '}\n'
        )
    if npmrc is not None:
        write_npmrc(root, npmrc)
    shutil.copytree(WARM_CACHE_SRC, os.path.join(root, "cache"))
    shutil.copytree(WARM_STORE_SRC, os.path.join(root, "store"))
    return root


def write_npmrc(project: str, npmrc: str) -> None:
    """Replace the project's `.npmrc` with `npmrc`."""
    with open(os.path.join(project, ".npmrc"), "w", encoding="utf-8") as fh:
        fh.write(npmrc)


def make_local_package(project: str, dirname: str, name: str) -> str:
    """Create a dependency-free package folder inside `project`.

    The folder gets a package.json whose `name` is `name` (version 1.0.0) and an
    `index.js`. Returns the add spec for it (`file:./<dirname>`), which installs
    from that folder rather than from any registry.
    """
    pkg_dir = os.path.join(project, dirname)
    os.makedirs(pkg_dir, exist_ok=True)
    with open(os.path.join(pkg_dir, "package.json"), "w", encoding="utf-8") as fh:
        json.dump({"name": name, "version": "1.0.0", "main": "index.js"}, fh)
    with open(os.path.join(pkg_dir, "index.js"), "w", encoding="utf-8") as fh:
        fh.write("module.exports = 1;\n")
    return f"file:./{dirname}"


def seed_package(
    project: str,
    name: str,
    *,
    first_published: str | None = None,
    no_dates: bool = False,
) -> None:
    """Make `name` installable offline in `project` as a copy of `lodash`.

    Writes a cached registry packument for `name` into the project's private
    metadata cache, plus a content-store index entry, both cloned from the
    image-baked `lodash` entries (same versions and tarball contents). After
    this, `aube add <name>` in that project resolves and installs with no
    network, exactly like a real package whose metadata aube already cached.

      - `first_published`: ISO-8601 UTC time (`...Z`). Every entry of the
        packument's `time` map (`created`, `modified`, each version) is set to
        it, so the registry metadata says the name and all of its versions
        were first published then.
      - `no_dates`: drop the packument's `time` map entirely, so the registry
        metadata carries no publish dates at all.
      - neither: keep lodash's real dates (first published in 2012).
    """
    encoded = name.replace("/", "__")
    (src,) = glob.glob(os.path.join(project, "cache", "packuments-full-v1", "*", "lodash.json"))
    with open(src, encoding="utf-8") as fh:
        entry = json.load(fh)
    packument = entry["packument"]
    packument["name"] = name
    packument["_id"] = name
    if no_dates:
        packument.pop("time", None)
    elif first_published is not None:
        packument["time"] = {key: first_published for key in packument["time"]}
    with open(os.path.join(os.path.dirname(src), f"{encoded}.json"), "w", encoding="utf-8") as fh:
        json.dump(entry, fh)
    for index in glob.glob(os.path.join(project, "store", "v1", "index", "*", "lodash@*.json")):
        version_suffix = os.path.basename(index)[len("lodash"):]
        shutil.copy(index, os.path.join(os.path.dirname(index), encoded + version_suffix))


def days_ago(days: float) -> str:
    """ISO-8601 UTC timestamp (`...Z`) for `days` days before now."""
    then = _dt.datetime.now(_dt.timezone.utc) - _dt.timedelta(days=days)
    return then.strftime("%Y-%m-%dT%H:%M:%S.000Z")


def minutes_since(iso_timestamp: str) -> int:
    """Whole minutes between `iso_timestamp` (UTC, `...Z`) and now."""
    then = _dt.datetime.fromisoformat(iso_timestamp.replace("Z", "+00:00"))
    now = _dt.datetime.now(_dt.timezone.utc)
    return int((now - then).total_seconds() // 60)


_ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")
_WRAP = re.compile(r"[ \t]*\r?\n[ \t]*(?:│[ \t]*)?")


def mentions(result: dict, token: str) -> bool:
    """True when `token` appears in a run's output, ignoring case, hyphens
    and underscores.

    Terminal escape codes are stripped first, and the line wrapping aube's
    error renderer applies (a newline plus an indented `│` gutter) is undone
    both with and without a joining space, so a name or setting that the
    renderer split across two lines still counts. Dropping `-` and `_` lets a
    setting key match however it is spelled (`someKey`, `some-key`,
    `SOME_KEY`).
    """
    text = _ANSI.sub("", result["out_raw"])
    needle = _plain(token)
    return any(
        needle in _plain(candidate)
        for candidate in (text, _WRAP.sub(" ", text), _WRAP.sub("", text))
    )


def _plain(text: str) -> str:
    return text.lower().replace("-", "").replace("_", "")


def _env(project: str, env_overrides: dict[str, str] | None) -> dict[str, str]:
    env = {**os.environ, **BASE_ENV}
    # Point aube at the project's private metadata cache + content store (the
    # copied warm snapshot) and an isolated HOME, so nothing reads or writes a
    # shared cache.
    home = os.path.join(project, "home")
    os.makedirs(home, exist_ok=True)
    env["HOME"] = home
    env["AUBE_CACHE_DIR"] = os.path.join(project, "cache")
    env["XDG_CACHE_HOME"] = os.path.join(project, "cache")
    env["AUBE_STORE_DIR"] = os.path.join(project, "store")
    if env_overrides:
        env.update(env_overrides)
    return env


def _result(returncode: int | None, combined: str, **extra) -> dict:
    return {
        "returncode": returncode,
        "out": combined.lower(),
        "out_raw": combined,
        **extra,
    }


def run_add(
    package: str,
    *,
    extra_args: list[str] | None = None,
    npmrc: str | None = None,
    env_overrides: dict[str, str] | None = None,
    project: str | None = None,
    timeout: int = 180,
) -> dict:
    """Run `aube add <package>` with no terminal attached and return a result dict.

    Parameters:
      - `extra_args`:    extra CLI args appended after the package (e.g. the
                         pre-existing bypass flag).
      - `npmrc`:         contents of an `.npmrc` to drop in the project root
                         (e.g. the allow-list, or the recency-window key).
      - `env_overrides`: extra environment variables merged on top of BASE_ENV
                         (e.g. the recency-window environment variable the patch
                         defines; discover its name from the submitted patch).
      - `project`:       an existing dir from `new_project()` to run in, so a
                         second add sees what the first one wrote (its
                         lockfile). Omitted: a fresh project per call.

    Keys in the returned dict:
      - "returncode": process exit code (0 == the add was accepted)
      - "out":        combined stdout+stderr, lower-cased for substring checks
      - "out_raw":    combined stdout+stderr, original case
    """
    if project is None:
        project = new_project(npmrc=npmrc)
    elif npmrc is not None:
        write_npmrc(project, npmrc)
    env = _env(project, env_overrides)
    argv = [AUBE_BIN, "add", package, *(extra_args or [])]
    proc = subprocess.run(
        argv,
        cwd=project,
        stdin=subprocess.DEVNULL,
        capture_output=True,
        text=True,
        timeout=timeout,
        env=env,
        check=False,
    )
    return _result(proc.returncode, (proc.stdout or "") + (proc.stderr or ""))


def _attach_controlling_tty() -> None:
    # Runs in the child after stdin/stdout/stderr point at the pty slave: start
    # a new session and make the slave its controlling terminal, as a login
    # shell would.
    os.setsid()
    fcntl.ioctl(0, termios.TIOCSCTTY, 0)


def run_add_tty(
    package: str,
    answer: str,
    *,
    extra_args: list[str] | None = None,
    npmrc: str | None = None,
    env_overrides: dict[str, str] | None = None,
    project: str | None = None,
    timeout: int = 180,
    quiet_secs: float = 1.5,
) -> dict:
    """Run `aube add <package>` at a pseudo-terminal and answer one prompt.

    stdin, stdout and stderr are all the pty, and `CI` is not set, so aube sees
    an interactive session. Once aube has printed something and then gone quiet
    for `quiet_secs` while still running (it is waiting for input), `answer`
    plus a newline is typed once. Output is collected until the process exits.
    `extra_args`, `npmrc`, `env_overrides` and `project` work as in `run_add`.

    Returns the same keys as `run_add`, plus:
      - "answered": True when the answer was typed (the process waited for
                    input); False when it exited without waiting.
    The returncode is None when the process was still running at `timeout`
    and had to be killed.
    """
    if project is None:
        project = new_project(npmrc=npmrc)
    elif npmrc is not None:
        write_npmrc(project, npmrc)
    env = _env(project, env_overrides)
    env.pop("CI", None)
    env["TERM"] = "xterm"
    argv = [AUBE_BIN, "add", package, *(extra_args or [])]
    master, slave = pty.openpty()
    proc = subprocess.Popen(
        argv,
        cwd=project,
        stdin=slave,
        stdout=slave,
        stderr=slave,
        env=env,
        preexec_fn=_attach_controlling_tty,
    )
    os.close(slave)
    chunks: list[bytes] = []
    answered = False
    deadline = time.monotonic() + timeout
    last_output = time.monotonic()
    killed = False
    while True:
        ready, _, _ = select.select([master], [], [], 0.2)
        if ready:
            try:
                data = os.read(master, 65536)
            except OSError:
                data = b""
            if data:
                chunks.append(data)
                last_output = time.monotonic()
                continue
            if proc.poll() is not None:
                break
        if proc.poll() is not None:
            # The process exited: drain what is left in the pty, then stop.
            while select.select([master], [], [], 0.1)[0]:
                try:
                    data = os.read(master, 65536)
                except OSError:
                    break
                if not data:
                    break
                chunks.append(data)
            break
        now = time.monotonic()
        if not answered and chunks and now - last_output >= quiet_secs:
            os.write(master, (answer + "\n").encode())
            answered = True
            last_output = now
        if now > deadline:
            proc.kill()
            killed = True
            break
    proc.wait()
    os.close(master)
    combined = b"".join(chunks).decode("utf-8", errors="replace")
    return _result(None if killed else proc.returncode, combined, answered=answered)
