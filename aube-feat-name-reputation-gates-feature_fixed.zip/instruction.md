## Task

`aube add` already pushes back on risky packages before it installs them, and we want it to catch two more kinds of npm names.
The first is a name that looks like a typo or lookalike of a well-known package.
The second is a name that only showed up on the public registry very recently.
Both checks should behave like the low-downloads check that's already there, both in how they ask or refuse and in which names they leave alone.

The recency window should be a new aube setting, counted in minutes.
On a machine that can't reach the registry, a package aube has looked up before should still be judged by its real first-publish date.

## User stories / requirements

- With no terminal, `aube add` refuses a near miss of a well-known package, same-scope ones for scoped packages included, and the error names the package it resembles. An exact well-known name isn't a near miss of itself. An unrelated name, or a scoped name whose last part only matches an unscoped well-known name, goes through.
- With no terminal, `aube add` refuses a name first published inside the recency window and allows an older one. If the registry can't confirm the first-publish date, the add is refused and the error names the window setting. The window works from both `.npmrc` and the environment, and `0` turns the check off.
- A name that either new check would flag is not stopped by them when it's already in the project's lockfile, matches `allowedUnpopularPackages`, or is installed from a local folder. Passing `--allow-low-downloads` also lets it through for that one command.
- When `aube add` runs at a terminal, a near miss or a name first published inside the window gets a yes/no prompt instead of an immediate failure, and the lookalike prompt names the package it resembles. Answering yes carries on with the add and answering no stops it.
