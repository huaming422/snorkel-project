## Task

Our MCP chart tools are silently ignoring the time-grain override. When an
automated caller fetches a saved time-series chart's data or SQL and passes
`extra_form_data={"time_grain_sqla": "P1M"}` to roll it up by month, the tool
just hands back the chart's saved grain: same row counts and timestamps as a
call with no override, and no error raised. The caller has no way to know its
request got dropped. We're seeing the same silent drop when a dashboard
time-grain filter is pointed at one of those time-axis charts.

This used to work. Dig in and fix the root cause so a grain override actually
re-aggregates the returned data, for both the MCP tool path and the dashboard
filter path. Charts that aren't time-axis charts should keep behaving exactly
as they do today.
