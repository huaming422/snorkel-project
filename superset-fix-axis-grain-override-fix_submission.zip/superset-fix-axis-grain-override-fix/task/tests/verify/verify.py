# Behavioral verifier for superset-fix-axis-grain-override.
#
# Runs under the repo venv (see verify.toml [pytest] command) so it can import
# superset. It is self-contained: the shared runner invokes it with cwd
# /repo/superset but does NOT collect the repo's own tests/unit_tests/conftest.py,
# so this file builds its own Superset app context and executes real SQLite
# queries. Behavior is proven by executed buckets / compiled SQL truncation,
# never by an echoed payload field.
#
# Test surfaces are all pre-existing, stable public entry points:
#   - superset.mcp_service.chart.chart_helpers.merge_extra_form_data_filters_into_query
#   - superset.charts.data.dashboard_filter_context.apply_dashboard_filter_context
#   - superset.connectors.sqla.models.SqlaTable.adhoc_column_to_sqla / get_query_result
#   - superset.common.query_object.QueryObject
# No internal helper added by the fix is imported or named — any fix that lands
# the override grain on the temporal axis column (by any decomposition) passes.
#
# Literals used as expectations are stable facts of Superset's query contract:
#   - ISO-8601 grain tokens P1D / P1M / P1W (frontend grain vocabulary)
#   - the columnType tag that adhoc_column_to_sqla gates truncation on, read
#     straight from superset/connectors/sqla/models.py
#   - the SQLite truncation substrings "start of month" / "start of day", read
#     from superset/db_engine_specs/sqlite.py
from __future__ import annotations

import os
from contextlib import contextmanager
from datetime import datetime, timedelta
from typing import Any

import pandas as pd
import pytest
from sqlalchemy import create_engine
from sqlalchemy.pool import StaticPool

# ---------------------------------------------------------------------------
# App-context bootstrap (session-scoped). Mirrors tests/unit_tests/conftest.py's
# `app` + autouse `app_context` fixtures, which are not collected here because
# the runner points pytest at this file alone.
# ---------------------------------------------------------------------------


@pytest.fixture(scope="session")
def _app():
    from superset.app import SupersetApp
    from superset.extensions import appbuilder
    from superset.initialization import SupersetAppInitializer

    app = SupersetApp(__name__)
    app.config.from_object("superset.config")
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite://"
    app.config["WTF_CSRF_ENABLED"] = False
    app.config["PREVENT_UNSAFE_DB_CONNECTIONS"] = False
    app.config["TESTING"] = True
    app.config["RATELIMIT_ENABLED"] = False
    app.config["CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["TALISMAN_ENABLED"] = False
    app.config["SERVER_NAME"] = "example.com"
    app.config["APPLICATION_ROOT"] = "/"
    appbuilder.baseviews = []
    SupersetAppInitializer(app).init_app()
    return app


@pytest.fixture(autouse=True)
def app_context(_app):
    with _app.app_context():
        yield


# ---------------------------------------------------------------------------
# Dataset + payload helpers (transcribed from the PR's regression suite).
# ---------------------------------------------------------------------------

# 90 consecutive days starting 2024-01-01: 90 daily buckets span 3 months.
_START = datetime(2024, 1, 1)
_DAYS = 90


def _events_dataset(mocker) -> Any:
    """An executable in-memory SQLite dataset with one row per day."""
    from superset.connectors.sqla.models import SqlaTable, TableColumn
    from superset.models.core import Database

    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
        future=True,
    )
    connection = engine.raw_connection()
    connection.execute("CREATE TABLE events (ts TIMESTAMP, val INTEGER)")
    connection.executemany(
        "INSERT INTO events VALUES (?, 1)",
        [
            ((_START + timedelta(days=offset)).strftime("%Y-%m-%d %H:%M:%S"),)
            for offset in range(_DAYS)
        ],
    )
    connection.commit()

    database = Database(database_name="db", sqlalchemy_uri="sqlite://")

    @contextmanager
    def mock_get_sqla_engine(catalog=None, schema=None, **kwargs):  # noqa: ANN001
        yield engine

    mocker.patch.object(database, "get_sqla_engine", new=mock_get_sqla_engine)
    mocker.patch(
        "superset.connectors.sqla.models.security_manager.get_guest_rls_filters",
        return_value=[],
    )
    mocker.patch(
        "superset.connectors.sqla.models.security_manager.is_guest_user",
        return_value=False,
    )

    return SqlaTable(
        database=database,
        schema=None,
        table_name="events",
        main_dttm_col="ts",
        columns=[
            TableColumn(column_name="ts", is_dttm=True, type="TIMESTAMP"),
            TableColumn(column_name="val", type="INTEGER"),
        ],
    )


def _saved_query(time_grain: str) -> dict[str, Any]:
    """The query payload a saved Generic Chart Axes chart stores."""
    base_axis: dict[str, Any] = {
        "sqlExpression": "ts",
        "label": "ts",
        "isColumnReference": True,
        "columnType": "BASE_AXIS",
        "timeGrain": time_grain,
    }
    return {
        "columns": [base_axis],
        "metrics": [
            {"expressionType": "SQL", "sqlExpression": "COUNT(*)", "label": "ct"}
        ],
        "filters": [],
        "extras": {"time_grain_sqla": time_grain},
        "row_limit": 1000,
    }


def _buckets(table: Any, query: dict[str, Any]) -> list[pd.Timestamp]:
    """Execute a query payload and return its temporal buckets."""
    from superset.common.query_object import QueryObject

    query_object = QueryObject(
        datasource=table,
        metrics=query["metrics"],
        columns=query["columns"],
        filters=query["filters"],
        granularity=query.get("granularity"),
        is_timeseries=False,
        extras=query["extras"],
        row_limit=query["row_limit"],
    )
    return table.get_query_result(query_object).df["ts"].tolist()


@pytest.fixture
def _no_datasource_engine_lookup(mocker):
    """Keep the MCP merge helper from attempting a real datasource lookup."""
    mocker.patch(
        "superset.mcp_service.chart.chart_helpers.resolve_datasource_engine",
        return_value="base",
    )


def _merge_mcp(query: dict[str, Any], extra_form_data: dict[str, Any]) -> None:
    from superset.mcp_service.chart.chart_helpers import (
        merge_extra_form_data_filters_into_query,
    )

    merge_extra_form_data_filters_into_query(query, extra_form_data, 1, "table")


# ---------------------------------------------------------------------------
# fail_to_pass — the override must change EXECUTED data, not an echoed field.
# ---------------------------------------------------------------------------


@pytest.mark.usefixtures("_no_datasource_engine_lookup")
def test_mcp_override_reaggregates_monthly(mocker):
    """Daily saved grain overridden to monthly returns the 3 months, not 90 days."""
    table = _events_dataset(mocker)

    baseline = _buckets(table, _saved_query("P1D"))
    assert len(baseline) == _DAYS, baseline

    overridden = _saved_query("P1D")
    _merge_mcp(overridden, {"time_grain_sqla": "P1M"})
    monthly = _buckets(table, overridden)

    assert monthly != baseline
    assert monthly == [
        pd.Timestamp("2024-01-01"),
        pd.Timestamp("2024-02-01"),
        pd.Timestamp("2024-03-01"),
    ], monthly


@pytest.mark.usefixtures("_no_datasource_engine_lookup")
def test_mcp_override_refines_daily(mocker):
    """The override works in the refining direction: monthly refined to daily."""
    table = _events_dataset(mocker)

    assert len(_buckets(table, _saved_query("P1M"))) == 3

    overridden = _saved_query("P1M")
    _merge_mcp(overridden, {"time_grain_sqla": "P1D"})
    assert len(_buckets(table, overridden)) == _DAYS


@pytest.mark.parametrize("axis_index", [0, 1])
@pytest.mark.parametrize("non_axis_grain", [None, "P1W"])
def test_grain_follows_base_axis_any_position(axis_index, non_axis_grain):
    """Grain follows the BASE_AXIS column by tag, not list position; non-axis untouched."""
    from copy import deepcopy

    from superset.charts.data.dashboard_filter_context import (
        apply_dashboard_filter_context,
    )
    from superset.connectors.sqla.models import SqlaTable, TableColumn
    from superset.models.core import Database

    non_axis: dict[str, Any] = {
        "sqlExpression": "val",
        "label": "val",
        "isColumnReference": True,
    }
    if non_axis_grain is not None:
        non_axis["timeGrain"] = non_axis_grain
    axis: dict[str, Any] = {
        "sqlExpression": "ts",
        "label": "ts",
        "isColumnReference": True,
        "columnType": "BASE_AXIS",
        "timeGrain": "P1D",
    }
    columns = [deepcopy(non_axis)]
    columns.insert(axis_index, axis)
    query_context: dict[str, Any] = {
        "queries": [{"columns": columns, "extras": {"time_grain_sqla": "P1D"}}]
    }

    apply_dashboard_filter_context(query_context, {"time_grain_sqla": "P1M"})

    # Re-read the resulting columns rather than the local references: a valid
    # fix may rebuild and reassign the list instead of mutating dicts in place.
    result_columns = query_context["queries"][0]["columns"]
    result_axis = [c for c in result_columns if c.get("columnType") == "BASE_AXIS"]
    result_non_axis = [c for c in result_columns if c.get("columnType") != "BASE_AXIS"]
    assert len(result_axis) == 1, result_columns
    assert len(result_non_axis) == 1, result_columns

    table = SqlaTable(
        database=Database(database_name="db", sqlalchemy_uri="sqlite://"),
        table_name="events",
        columns=[TableColumn(column_name="ts", is_dttm=True, type="TIMESTAMP")],
    )
    sql_column, _ = table.adhoc_column_to_sqla(result_axis[0])
    sql = str(sql_column.compile(compile_kwargs={"literal_binds": True}))
    assert "start of month" in sql, sql

    # The non-axis column must be byte-for-byte unchanged (no grain written onto it).
    assert result_non_axis[0] == non_axis


@pytest.mark.usefixtures("_no_datasource_engine_lookup")
def test_non_axis_columns_untouched():
    """Only the BASE_AXIS entry gains the grain; sibling adhoc columns do not."""
    query: dict[str, Any] = {
        "columns": [
            {"sqlExpression": "UPPER(country)", "label": "country"},
            {
                "sqlExpression": "ts",
                "label": "ts",
                "columnType": "BASE_AXIS",
                "timeGrain": "P1D",
            },
        ],
        "filters": [],
    }

    _merge_mcp(query, {"time_grain_sqla": "P1M"})

    # Identify columns by tag, not position, so a list-rebuilding fix is accepted.
    result_columns = query["columns"]
    axis = [c for c in result_columns if c.get("columnType") == "BASE_AXIS"]
    non_axis = [c for c in result_columns if c.get("columnType") != "BASE_AXIS"]
    assert len(axis) == 1 and len(non_axis) == 1, result_columns
    assert axis[0]["timeGrain"] == "P1M"
    assert "timeGrain" not in non_axis[0]


@pytest.mark.usefixtures("_no_datasource_engine_lookup")
def test_dashboard_path_honors_override(mocker):
    """Independent entry point: the dashboard filter path must also re-aggregate.

    The temporal axis sits at index 1 behind a non-axis column, so a fix that
    writes the grain onto the first column (the pre-fix dashboard behavior)
    leaves the axis at its saved daily grain and the query returns 90 rows.
    """
    from superset.charts.data.dashboard_filter_context import (
        apply_dashboard_filter_context,
    )

    table = _events_dataset(mocker)

    overridden = _saved_query("P1D")
    # Prepend a non-axis constant column so the axis is no longer columns[0].
    overridden["columns"].insert(
        0, {"sqlExpression": "1", "label": "constant"}
    )
    query_context = {"queries": [overridden]}
    apply_dashboard_filter_context(query_context, {"time_grain_sqla": "P1M"})

    monthly = _buckets(table, overridden)
    assert monthly == [
        pd.Timestamp("2024-01-01"),
        pd.Timestamp("2024-02-01"),
        pd.Timestamp("2024-03-01"),
    ], monthly


# ---------------------------------------------------------------------------
# pass_to_pass — behavior that must be preserved.
# ---------------------------------------------------------------------------


@pytest.mark.usefixtures("_no_datasource_engine_lookup")
def test_no_override_preserves_saved_grain(mocker):
    """A request with no grain override leaves the saved axis grain untouched."""
    table = _events_dataset(mocker)

    query = _saved_query("P1D")
    _merge_mcp(query, {"time_range": "No filter"})

    assert query["columns"][0]["timeGrain"] == "P1D"
    assert query["extras"]["time_grain_sqla"] == "P1D"
    assert len(_buckets(table, query)) == _DAYS


@pytest.mark.usefixtures("_no_datasource_engine_lookup")
def test_no_base_axis_uses_extras(mocker):
    """Queries without a BASE_AXIS column still carry the override in extras."""
    query: dict[str, Any] = {
        "columns": [
            {"sqlExpression": "UPPER(country)", "label": "country"},
        ],
        "filters": [],
        "extras": {},
    }

    _merge_mcp(query, {"time_grain_sqla": "P1M"})

    assert query["extras"]["time_grain_sqla"] == "P1M"
    assert "timeGrain" not in query["columns"][0]
