#!/usr/bin/env bash
# test-setup.sh — runs once before the verifier phase.
#
# The repo's dependency closure is already baked into /repo/superset/.venv at
# image-build time (see image/Dockerfile), so this is an offline no-op in the
# common case: it confirms the repo venv exists and that the editable superset
# package imports under a minimal app context. A logged online fallback
# re-installs the pinned development requirements only if the venv is missing.

set -euo pipefail

REPO=/repo/superset
VENV="$REPO/.venv"
cd "$REPO"

# Prefer the baked repo venv; only reach the network if it is somehow absent.
if [ ! -x "$VENV/bin/python" ]; then
    echo "[test-setup] repo venv missing — rebuilding (online fallback)"
    /opt/tooling/uv/uv venv --managed-python --python 3.11 "$VENV"
    /opt/tooling/uv/uv pip install --python "$VENV/bin/python" \
        -r requirements/development.txt
fi

echo "[test-setup] smoke-testing superset imports under app context"
"$VENV/bin/python" - <<'PY'
from superset.app import SupersetApp
from superset.extensions import appbuilder
from superset.initialization import SupersetAppInitializer

app = SupersetApp(__name__)
app.config.from_object("superset.config")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite://"
app.config["WTF_CSRF_ENABLED"] = False
app.config["TESTING"] = True
app.config["RATELIMIT_ENABLED"] = False
app.config["CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
app.config["DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
app.config["TALISMAN_ENABLED"] = False
appbuilder.baseviews = []
SupersetAppInitializer(app).init_app()
with app.app_context():
    from superset.mcp_service.chart.chart_helpers import (
        merge_extra_form_data_filters_into_query,  # noqa: F401
    )
    from superset.charts.data.dashboard_filter_context import (
        apply_dashboard_filter_context,  # noqa: F401
    )
    print("[test-setup] imports OK")
PY

echo "[test-setup] done"
