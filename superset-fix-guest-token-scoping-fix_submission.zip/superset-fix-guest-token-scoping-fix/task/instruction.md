## Task

Security review found a way for guests to read data that was never shared with them through our embedded dashboards. A guest viewing an embedded dashboard holds a short-lived token scoping them to that dashboard's charts, and to exactly the data those charts show. By tampering with the data requests the embedded charts send, a guest can make the server hand back more:

- Adding annotation layers the saved chart was never configured with, which the server resolves and returns instead of refusing, exposing annotation sources the guest was never granted.
- Asking for the raw underlying rows of the full dataset, every column, rather than the aggregated result the chart shows.
- Separately, the page served before any guest token is presented leaks the dashboard's title and description to anyone who requests that URL.

Find and fix each so a guest is held to exactly what the shared charts expose and the pre-login page reveals no dashboard metadata. Don't weaken the limits that already hold or block legitimate guest views. It's all in the Python backend.
