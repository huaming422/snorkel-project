# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

"""Behavioral verifier for superset-fix-guest-token-scoping.

Two mechanisms are checked, each through a PRE-EXISTING, STABLE interface the
solution is not free to rename, relocate, or fold away:

  * the guest-token tamper guard ......... ``superset.security.manager
                                            .query_context_modified`` — the
    function ``raise_for_access`` calls for a guest; returning True is what
    raises the 403. The existing unit-test module imports it directly, which
    fixes it as the intended seam. Every tamper case drives this function with
    a constructed query context and asserts only the returned bool.
  * the pre-token embedded page ........... ``GET /embedded/<uuid>`` rendered by
    ``EmbeddedView.embedded`` — exercised over a Flask test client against a
    seeded embedded dashboard, asserting the title/description text is absent
    from the response body.

The guard's internal helpers (whatever a solution ends up naming them, and
whether it keeps the flat comparator chain or any other structure) are NEVER
imported: the task contract explicitly permits renaming/relocating/inlining
them, so their effect is observed only through the two interfaces above. No
assertion reads a log message, a helper name, or any ``_``-prefixed symbol.

Runs under the minimal app that tests/test-setup.sh bootstraps; the
module-scoped ``app`` fixture mirrors tests/unit_tests/conftest.py. The
database is file-backed rather than ``sqlite://`` so the embedded-page test's
seeded rows stay visible to the request handler across connections.

Uses ``pytest-mock`` (``mocker``) for the tamper cases, matching the repo's
own security unit tests; it is part of the baked dependency closure.
"""

from __future__ import annotations

import json
import os
import tempfile
from types import SimpleNamespace
from typing import Any, Iterator

import pytest
from pytest_mock import MockerFixture

# ---------------------------------------------------------------------------
# App bootstrap (minimal app, mirrors tests/unit_tests/conftest.py)
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def app() -> Iterator[Any]:
    """A minimal Superset app, mirroring the repo's unit-test ``app`` fixture.

    File-backed SQLite (not ``sqlite://``) so rows seeded for the embedded-page
    test are visible to the request handler, which resolves the embedded
    dashboard on its own session/connection.
    """
    from superset.app import SupersetApp
    from superset.extensions import appbuilder
    from superset.initialization import SupersetAppInitializer

    fd, dbfile = tempfile.mkstemp(suffix=".db")
    os.close(fd)

    # Use the ``superset.app`` import name (as the real ``create_app`` factory
    # does), NOT this test module's ``__name__``: Flask derives ``root_path``
    # from the import name, and the embedded view renders ``superset/spa.html``
    # from the ``superset/templates`` folder under that root. Passing this
    # module's name would point Jinja at the tests directory and 500 on a
    # missing template.
    app = SupersetApp("superset.app")
    app.config.from_object("superset.config")
    app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{dbfile}"
    app.config["WTF_CSRF_ENABLED"] = False
    app.config["TESTING"] = True
    app.config["RATELIMIT_ENABLED"] = False
    app.config["CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["FILTER_STATE_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["EXPLORE_FORM_DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["GLOBAL_ASYNC_QUERIES_REDIS_CONFIG"] = None
    app.config["TALISMAN_ENABLED"] = False
    app.config["PREVENT_UNSAFE_DB_CONNECTIONS"] = False
    app.config["SERVER_NAME"] = "example.com"
    app.config["APPLICATION_ROOT"] = "/"

    appbuilder.baseviews = []
    SupersetAppInitializer(app).init_app()
    try:
        yield app
    finally:
        if os.path.exists(dbfile):
            try:
                os.unlink(dbfile)
            except OSError:
                pass


@pytest.fixture(autouse=True)
def _app_context(app: Any) -> Iterator[None]:
    """Push an application context around every test, as the repo's autouse
    ``app_context`` fixture does — the tamper guard reads the app's db session
    on the chartless native-filter path."""
    with app.app_context():
        yield


# ---------------------------------------------------------------------------
# Shared data: a stored metric the chart is saved with (repo's stored_metrics
# fixture), reused across the tamper cases so a legitimate replay carries a
# term the guard recognises.
# ---------------------------------------------------------------------------

STORED_METRICS = [
    {
        "column": None,
        "expressionType": "SQL",
        "hasCustomLabel": False,
        "label": "COUNT(*) + 1",
        "sqlExpression": "COUNT(*) + 1",
    },
]

# A native annotation layer the stored chart carries. Identity is
# (sourceType, value); name is cosmetic.
STORED_LAYER = {
    "annotationType": "INTERVAL",
    "sourceType": "NATIVE",
    "value": 1,
    "name": "Incidents",
}


def _query_context_modified() -> Any:
    """The guard under test, resolved fresh from the module so a solution that
    re-exports or relocates it within the public module still resolves."""
    from superset.security.manager import query_context_modified

    return query_context_modified


def _query_object(**kwargs: Any) -> Any:
    """A real ``QueryObject`` built from the given attrs, matching how the
    repo's own security tests construct queries for this guard."""
    from superset.common.query_object import QueryObject

    return QueryObject(**kwargs)


def _native_filter_ctx(
    mocker: MockerFixture,
    queries: list[Any],
    *,
    native_filter_id: str | None = "F1",
    dashboard_id: int | None = 10,
    dataset_id: int = 20,
    targets: list[Any] | None = None,
) -> Any:
    """Build a native-filter query context (no slice_) plus the patched
    dashboard lookup it resolves against — the repo's own ``_native_filter_ctx``
    helper, reproduced so the chartless native-filter path can be driven."""
    if targets is None:
        targets = [{"datasetId": dataset_id, "column": {"name": "region"}}]
    qc = mocker.MagicMock()
    qc.slice_ = None
    qc.form_data = {
        "type": "NATIVE_FILTER",
        "native_filter_id": native_filter_id,
        "dashboardId": dashboard_id,
    }
    qc.datasource.data = {"id": dataset_id}
    qc.queries = queries
    dash = mocker.MagicMock()
    dash.json_metadata = json.dumps(
        {
            "native_filter_configuration": [
                {"id": "F1", "targets": targets, "controlValues": {}}
            ]
        }
    )
    query_chain = mocker.patch("superset.db.session.query")
    query_chain.return_value.filter.return_value.one_or_none.return_value = dash
    return qc


# ===========================================================================
# Mechanism 1a — annotation-layer tamper. Driven through query_context_modified.
# A request may replay the layers the stored chart carries; injecting one the
# chart was never saved with is tampering. Identity is (sourceType, value); the
# cosmetic keys (name, styling) are not identity.
# ===========================================================================


def test_anno_allows_stored(mocker: MockerFixture) -> None:
    """Replaying the chart's own stored annotation layer is not tampering."""
    query_context_modified = _query_context_modified()

    qc = mocker.MagicMock()
    qc.slice_.id = 42
    qc.slice_.query_context = None
    qc.result_type = None
    qc.slice_.params_dict = {
        "metrics": STORED_METRICS,
        "annotation_layers": [STORED_LAYER],
    }
    qc.form_data = {
        "slice_id": 42,
        "metrics": STORED_METRICS,
        "annotation_layers": [STORED_LAYER],
    }
    qc.queries = [
        _query_object(metrics=STORED_METRICS, annotation_layers=[STORED_LAYER])
    ]
    assert not query_context_modified(qc)


def test_anno_blocks_injected(mocker: MockerFixture) -> None:
    """A layer whose (sourceType, value) identity is absent from the stored
    chart's current params is tampering — native layers resolve every
    annotation of the referenced layer id with no further access check."""
    query_context_modified = _query_context_modified()

    injected = {**STORED_LAYER, "value": 2}
    qc = mocker.MagicMock()
    qc.slice_.id = 42
    qc.slice_.query_context = None
    qc.result_type = None
    qc.slice_.params_dict = {"metrics": STORED_METRICS}
    qc.form_data = {
        "slice_id": 42,
        "metrics": STORED_METRICS,
        "annotation_layers": [injected],
    }
    qc.queries = [
        _query_object(metrics=STORED_METRICS, annotation_layers=[injected])
    ]
    assert query_context_modified(qc)


def test_anno_identity_semantics(mocker: MockerFixture) -> None:
    """Identity is (sourceType, value): a cosmetic-only difference (name) with
    the same identity is allowed."""
    query_context_modified = _query_context_modified()

    # Same identity, different cosmetic name → allowed.
    cosmetic = {**STORED_LAYER, "name": "Renamed by request"}
    qc = mocker.MagicMock()
    qc.slice_.id = 42
    qc.slice_.query_context = None
    qc.result_type = None
    qc.slice_.params_dict = {
        "metrics": STORED_METRICS,
        "annotation_layers": [STORED_LAYER],
    }
    qc.form_data = {
        "slice_id": 42,
        "metrics": STORED_METRICS,
        "annotation_layers": [cosmetic],
    }
    qc.queries = [
        _query_object(metrics=STORED_METRICS, annotation_layers=[cosmetic])
    ]
    assert not query_context_modified(qc)


# ===========================================================================
# Mechanism 1b — row-expanding result types. Driven through
# query_context_modified. The samples/drill_detail preparers rewrite a query to
# every datasource column AFTER the access check, so the guard must reject a
# request that flips a query's effective result type to one the stored chart
# does not render at that position — on the chart path and the chartless
# native-filter / Drill By paths — while leaving Drill to Detail proper alone.
# ===========================================================================


def test_rt_blocks_expanding(mocker: MockerFixture) -> None:
    """Flipping a query's effective result type to samples/drill_detail (via the
    top-level default or the per-query value) when the stored chart does not
    carry it is tampering; replaying the chart's own stored type is not."""
    from superset.common.chart_data import ChartDataResultType

    query_context_modified = _query_context_modified()

    qc = mocker.MagicMock()
    qc.slice_.id = 42
    qc.slice_.query_context = None
    qc.slice_.params_dict = {"metrics": STORED_METRICS}
    qc.form_data = {"slice_id": 42, "metrics": STORED_METRICS}
    qc.queries = [_query_object(metrics=STORED_METRICS)]

    # Top-level result type rewritten to samples → tampering.
    qc.result_type = ChartDataResultType.SAMPLES
    assert query_context_modified(qc)

    # Per-query result type rewritten to drill_detail → tampering.
    qc.result_type = ChartDataResultType.FULL
    qc.queries[0].result_type = ChartDataResultType.DRILL_DETAIL
    assert query_context_modified(qc)

    # The chart's own (non-expanding) result type is not tampering.
    qc.queries[0].result_type = None
    assert not query_context_modified(qc)


def test_rt_positional(mocker: MockerFixture) -> None:
    """Result type is compared per query position: a chart storing samples at
    query[1] does NOT license requesting samples at query[0], even though
    samples is used somewhere on the chart. Replaying each query's own stored
    type in order is allowed."""
    from superset.common.chart_data import ChartDataResultType

    query_context_modified = _query_context_modified()

    qc = mocker.MagicMock()
    qc.slice_.id = 42
    qc.slice_.params_dict = {"metrics": STORED_METRICS}
    qc.slice_.query_context = json.dumps(
        {
            "result_type": "full",
            "queries": [
                {"metrics": STORED_METRICS, "result_type": "full"},
                {"metrics": STORED_METRICS, "result_type": "samples"},
            ],
        }
    )
    qc.form_data = {"slice_id": 42, "metrics": STORED_METRICS}
    qc.result_type = ChartDataResultType.FULL

    # Each query replaying its own stored type, in stored order → allowed.
    qc.queries = [
        _query_object(metrics=STORED_METRICS, result_type=ChartDataResultType.FULL),
        _query_object(
            metrics=STORED_METRICS, result_type=ChartDataResultType.SAMPLES
        ),
    ]
    assert not query_context_modified(qc)

    # samples requested at index 0 — a position the chart never renders raw —
    # is tampering, even though samples is the stored type of query[1].
    qc.queries = [
        _query_object(
            metrics=STORED_METRICS, result_type=ChartDataResultType.SAMPLES
        ),
        _query_object(metrics=STORED_METRICS, result_type=ChartDataResultType.FULL),
    ]
    assert query_context_modified(qc)

    # Neither the query nor the context names a result type: nothing resolves to
    # a row-expanding type → not tampering.
    qc.result_type = None
    qc.queries = [
        _query_object(metrics=STORED_METRICS),
        _query_object(metrics=STORED_METRICS),
    ]
    assert not query_context_modified(qc)


def test_rt_chartless_paths(mocker: MockerFixture) -> None:
    """The row-expanding guard also covers the chartless paths: a native-filter
    request (otherwise limited to its target column) and a Drill By request
    (slice_id sentinel 0 + a source chart_id) asking for a row-expanding result
    type are both tampering — those preparers return every column, bypassing the
    target-column / drillable-dimension allowlists."""
    query_context_modified = _query_context_modified()

    # Native-filter path: target column only, but a row-expanding type.
    for rt in ("samples", "drill_detail"):
        query = SimpleNamespace(
            columns=["region"], metrics=[], groupby=[], result_type=rt
        )
        qc = _native_filter_ctx(mocker, [query])
        assert query_context_modified(qc), f"native-filter {rt} not rejected"

    # Drill By path: slice_id 0 sentinel + a source chart_id, row-expanding type.
    for rt in ("samples", "drill_detail"):
        query = SimpleNamespace(
            columns=[], metrics=[], groupby=["region"], result_type=rt
        )
        qc = mocker.MagicMock()
        qc.slice_ = None
        qc.form_data = {
            "dashboardId": 10,
            "slice_id": 0,
            "chart_id": 5,
            "groupby": ["region"],
        }
        qc.queries = [query]
        assert query_context_modified(qc), f"Drill By {rt} not rejected"


def test_rt_allows_drill_to_detail(mocker: MockerFixture) -> None:
    """Drill to Detail proper (no slice_id / chart_id at all) is NOT rejected
    for a row-expanding result type: it is legitimately meant to expose a full
    dataset attached to the dashboard and is governed by raise_for_access."""
    query_context_modified = _query_context_modified()

    query = SimpleNamespace(
        columns=[], metrics=[], groupby=[], result_type="drill_detail"
    )
    qc = mocker.MagicMock()
    qc.slice_ = None
    qc.form_data = {"dashboardId": 10}
    qc.queries = [query]
    assert not query_context_modified(qc)


# ===========================================================================
# No-over-block regression — a legitimate replay of exactly what the stored
# chart renders (its metrics, its own stored annotation layer, its own stored
# result types) must still pass both mechanisms.
# ===========================================================================


def test_no_overblock(mocker: MockerFixture) -> None:
    """A request replaying only the stored chart's metrics, its own stored
    annotation layer, and its own stored result type is not tampering."""
    from superset.common.chart_data import ChartDataResultType

    query_context_modified = _query_context_modified()

    qc = mocker.MagicMock()
    qc.slice_.id = 42
    qc.slice_.query_context = json.dumps(
        {
            "result_type": "full",
            "queries": [{"metrics": STORED_METRICS, "result_type": "full"}],
        }
    )
    qc.slice_.params_dict = {
        "metrics": STORED_METRICS,
        "annotation_layers": [STORED_LAYER],
    }
    qc.form_data = {
        "slice_id": 42,
        "metrics": STORED_METRICS,
        "annotation_layers": [STORED_LAYER],
    }
    qc.result_type = ChartDataResultType.FULL
    qc.queries = [
        _query_object(
            metrics=STORED_METRICS,
            annotation_layers=[STORED_LAYER],
            result_type=ChartDataResultType.FULL,
        )
    ]
    assert not query_context_modified(qc)


# ===========================================================================
# Mechanism 2 — pre-token embedded page metadata leak. Driven through
# GET /embedded/<uuid> over a Flask test client against a seeded embedded
# dashboard. The page renders before any guest token is presented and the
# Referer / Sec-Fetch-Dest checks are browser cooperation only, so anything
# rendered here is effectively public: the title and description must not appear
# in the response body.
# ===========================================================================

_DASH_TITLE = "Quarterly Revenue Confidential Board Report"
_DASH_DESCRIPTION = "internal-only dashboard description"


def _seed_embedded_dashboard(app: Any) -> str:
    """Seed one embeddable dashboard carrying a title and description, and
    return its embedded uuid."""
    from superset.daos.dashboard import EmbeddedDashboardDAO
    from superset.extensions import db
    from superset.models.dashboard import Dashboard

    with app.app_context():
        Dashboard.metadata.create_all(db.engine)
        dash = Dashboard(
            dashboard_title=_DASH_TITLE,
            slug="confidential-embedded",
            description=_DASH_DESCRIPTION,
        )
        db.session.add(dash)
        db.session.commit()
        embedded = EmbeddedDashboardDAO.upsert(dash, [])
        db.session.add(dash)
        db.session.commit()
        return str(embedded.uuid)


def test_embedded_no_metadata_leak(app: Any) -> None:
    """The pre-token embedded page does not disclose the dashboard title or
    description in its response body."""
    from superset.extensions import feature_flag_manager as ffm

    uuid = _seed_embedded_dashboard(app)

    with app.app_context():
        flags = ffm._feature_flags  # noqa: SLF001 - documented backing store
        had = "EMBEDDED_SUPERSET" in flags
        prev = flags.get("EMBEDDED_SUPERSET")
        flags["EMBEDDED_SUPERSET"] = True
        try:
            client = app.test_client()
            response = client.get(f"/embedded/{uuid}")
        finally:
            if had:
                flags["EMBEDDED_SUPERSET"] = prev
            else:
                flags.pop("EMBEDDED_SUPERSET", None)

    assert response.status_code == 200, (
        f"embedded page did not render (status {response.status_code}); nothing "
        "can be concluded about the leak"
    )
    assert _DASH_TITLE.encode() not in response.data, (
        "the pre-token embedded page discloses the dashboard title"
    )
    assert _DASH_DESCRIPTION.encode() not in response.data, (
        "the pre-token embedded page discloses the dashboard description"
    )
