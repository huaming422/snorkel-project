#!/usr/bin/env bash
# test-setup.sh — runs once before verify/verify.py in the verifier phase.
#
# The image already baked Superset's full pinned dependency closure
# (requirements/development.txt) at the base commit, so this script is an
# offline no-op in the common case: it re-runs the editable install only to
# pick up any pyproject/entry-point metadata the agent's patch may have
# touched, then smoke-tests that the security-manager import chain loads
# inside a minimal Flask app context.
#
# The verifier for this task is unit-test level (pytest functions that mock
# the QueryContext / Slice and call query_context_modified) plus an
# integration-level check of the embedded view's rendered HTML — neither
# needs Postgres/Redis or loaded example data. No service bring-up here.
set -euo pipefail

REPO=/repo/superset
cd "$REPO"

# Force uv/pip offline: the closure is already baked. A cache miss should fail
# fast rather than hang against the cut network.
export UV_OFFLINE=1 UV_NO_INDEX=1 UV_CACHE_DIR=/opt/uv-cache

echo "[test-setup] ensuring superset editable metadata is current (offline)"
# The image already installed the project editable at the base commit, and the
# build backend (setuptools==84.0.0, wheel) is on the system interpreter — not
# in the offline wheel cache. So pass --no-build-isolation: a default
# build-isolated reinstall would try to provision a fresh PEP 517 build env
# from the cut network/empty cache and fail on `setuptools>=84.0.0`. Agents on
# this task only edit in-tree .py source (served live by the baked editable
# install and the sys.path insert below), so this reinstall only refreshes
# entry-point/metadata if pyproject changed; treat it as best-effort rather
# than a hard gate on the offline build backend.
uv pip install --python /usr/bin/python3.11 --system --offline --no-build-isolation -e . \
    > /tmp/test-setup.log 2>&1 \
    || { echo "[test-setup] editable refresh skipped (offline, baked install in use):"; tail -40 /tmp/test-setup.log; }

echo "[test-setup] bootstrapping minimal app + smoke-testing imports"
python3 - <<'PY'
import sys
sys.path.insert(0, "/repo/superset")

from superset.app import SupersetApp
from superset.extensions import appbuilder
from superset.initialization import SupersetAppInitializer

app = SupersetApp(__name__)
app.config.from_object("superset.config")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite://"
app.config["WTF_CSRF_ENABLED"] = False
app.config["TESTING"] = True
app.config["RATELIMIT_ENABLED"] = False
app.config["CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
app.config["DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
app.config["FILTER_STATE_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
app.config["EXPLORE_FORM_DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
app.config["GLOBAL_ASYNC_QUERIES_REDIS_CONFIG"] = None
app.config["TALISMAN_ENABLED"] = False
app.config["PREVENT_UNSAFE_DB_CONNECTIONS"] = False
appbuilder.baseviews = []
SupersetAppInitializer(app).init_app()
with app.app_context():
    from superset.security.manager import query_context_modified  # noqa: F401
    print("[test-setup] imports OK")
PY

echo "[test-setup] done"
