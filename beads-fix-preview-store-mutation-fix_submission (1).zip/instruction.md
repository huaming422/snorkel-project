## Task

`bd migrate --inspect` and `bd create --dry-run` are meant to be previews: they report what would happen and change nothing. Lately, using one on a real workspace sometimes leaves the store modified afterwards. Its history has new commits in it, the schema has been migrated, and the cached version marker in `.beads` has been rewritten.

A preview should leave every workspace it touches exactly as it found it. That includes a `--proxied-server` workspace, and another repo the preview only reads from, such as one passed with `--repo`. The previews still need to work and show what they would do, including on a workspace that hasn't caught up with the installed bd yet.
