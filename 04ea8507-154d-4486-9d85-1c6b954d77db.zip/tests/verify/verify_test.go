//
//  Copyright 2026 The InfiniFlow Authors. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

// Route-registration gate for the document partial-update endpoint.
//
// This file is injected into internal/router and runs as a native `go test`.
// It constructs the production router through its public constructor + Setup
// and inspects the registered route table. It asserts ONLY the stable,
// instruction-level contract: that a PATCH route exists at the structural
// location
//
//     /api/v1/datasets/<param>/documents/<param>
//
// It deliberately does NOT reference any symbol the implementation introduces
// (no handler-method name, no service type, no DAO), does NOT care how the
// route is grouped or which helper registers it, and does NOT care what the
// two path parameters are named. Any of the blueprint's valid alternatives
// (a registration helper, a different grouping, different param names, a
// map-decode handler) satisfies it, because the check is purely "does a PATCH
// verb resolve at this path shape in the final route table". The behavioral
// contract (ownership, counter guard, rename, reparse, enable) is exercised
// by the validation stories, which drive the update capability end to end and
// assert persisted state; this gate's sole job is to catch a feature that
// compiles but was never wired into the router.
//
// Construction uses all-nil handlers. Setup only forms method *values* and
// *returns* middleware closures during registration (it never invokes a
// handler), so a nil receiver never dereferences — the same pattern the
// repo's own route tests (TestAgentRoutes_AllElevenRegistered,
// TestAdminRuntimeRoutes_Registered) already rely on. The route table is read
// with engine.Routes(), which never calls a handler, so there is no request
// path that could deref a nil service.
package router_test

import (
	"strings"
	"testing"

	"github.com/gin-gonic/gin"

	"ragflow/internal/router"
)

// isParamSegment reports whether a gin path segment is a wildcard capture
// (":name" or "*name"), i.e. the implementation may use any parameter name.
func isParamSegment(seg string) bool {
	return strings.HasPrefix(seg, ":") || strings.HasPrefix(seg, "*")
}

// matchesDatasetDocumentPath reports whether a gin route path is the
// structural shape /api/v1/datasets/<param>/documents/<param>. The static
// segments are fixed by the published API contract; the two capture segments
// may carry any parameter name.
func matchesDatasetDocumentPath(path string) bool {
	segs := strings.Split(strings.Trim(path, "/"), "/")
	want := []struct {
		literal string
		param   bool
	}{
		{"api", false},
		{"v1", false},
		{"datasets", false},
		{"", true}, // dataset identifier (any param name)
		{"documents", false},
		{"", true}, // document identifier (any param name)
	}
	if len(segs) != len(want) {
		return false
	}
	for i, w := range want {
		if w.param {
			if !isParamSegment(segs[i]) {
				return false
			}
			continue
		}
		if segs[i] != w.literal {
			return false
		}
	}
	return true
}

// TestDocumentPatchRouteRegistered asserts the production router wires a PATCH
// verb at /api/v1/datasets/:*/documents/:* . Fails when the endpoint is
// unimplemented or defined but never registered (the exact regression this
// gate guards against).
func TestDocumentPatchRouteRegistered(t *testing.T) {
	gin.SetMode(gin.TestMode)

	// All handlers nil: Setup forms method values / returns middleware
	// closures but never invokes a handler during registration, so nil
	// receivers are never dereferenced.
	r := router.NewRouter(
		nil, nil, nil, nil, nil,
		nil, nil, nil, nil, nil,
		nil, nil, nil, nil, nil,
		nil, nil, nil, nil, nil,
		nil, nil, nil, nil, nil,
	)

	engine := gin.New()
	r.Setup(engine)

	for _, ri := range engine.Routes() {
		if ri.Method == "PATCH" && matchesDatasetDocumentPath(ri.Path) {
			return // contract satisfied
		}
	}

	var patchRoutes []string
	for _, ri := range engine.Routes() {
		if ri.Method == "PATCH" {
			patchRoutes = append(patchRoutes, ri.Path)
		}
	}
	t.Fatalf("no PATCH route at /api/v1/datasets/<param>/documents/<param> was registered; "+
		"PATCH routes present: %v", patchRoutes)
}
