#!/usr/bin/env bash
#
# Compile + regression gate for the document partial-update feature.
#
# Two independent halves, both alternative-implementation-safe (they import
# no symbol the solving change introduces):
#
#   1. Cross-layer compile gate. The capability spans four packages that must
#      stay mutually consistent — the route layer, the request/response layer,
#      the update logic, and the data-access layer. Building all four together
#      proves the new interface method, its call sites, and the route wiring
#      agree on one signature. A solution that implements the logic but leaves
#      a layer referencing an old shape fails here. `go build` names only
#      pre-existing package import paths, never a task-introduced identifier,
#      so every valid decomposition compiles.
#
#   2. Pre-existing-behavior regression. The surrounding document behaviors
#      that shipped before this change (read, download, delete, stop-parse,
#      ownership scoping, artifact/preview helpers) must stay green. These
#      test names predate the feature and live in the repo's own committed
#      suite, so pinning them is a stable-fact regression guard, not a couple
#      to new implementation identifiers. The new behaviors are exercised by the
#      validation stories, not here.
#
# The service package is CGO-linked (it transitively pulls the prebuilt
# tokenizer static lib + the office_oxide FFI lib), so the baked CGO env is
# re-asserted defensively; tests/test-setup.sh has already cd'd into the repo,
# warmed the module cache offline-first, and confirmed the static lib exists.
set -euo pipefail

export GOFLAGS="${GOFLAGS:--mod=mod}"
export GOPROXY="${GOPROXY:-off}"
export CGO_ENABLED="${CGO_ENABLED:-1}"
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"
export CGO_CFLAGS="${CGO_CFLAGS:--I/root/.office_oxide/include/office_oxide_c}"
export CGO_LDFLAGS="${CGO_LDFLAGS:--L/root/.office_oxide/lib -loffice_oxide -Wl,-rpath,/root/.office_oxide/lib}"
export LD_LIBRARY_PATH="${LD_LIBRARY_PATH:-/usr/lib64:/root/.office_oxide/lib}"
export PATH="/usr/local/go/bin:${PATH}"

# (1) Cross-layer compile gate — all four layers build together.
go build ./internal/router/... ./internal/handler/... ./internal/service/... ./internal/dao/...

# (2) Pre-existing document behaviors stay green. The -run filter names only
# tests that exist in the baseline repo (before this feature); it never names
# a test for the new capability.
go test ./internal/service/ -count=1 -timeout=600s -run \
  'TestDeleteDocumentFull|TestDeleteDocuments|TestDeleteDocument_|TestStopParseDocuments|TestResolveDocAndKB|TestDeleteDocRecordWithCounters|TestCleanupFileReferences|TestArtifactHelpers|TestGetDocumentArtifact|TestGetDocumentPreview|TestDownloadDocument'
