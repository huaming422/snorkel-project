## Task

The Go API can create and read dataset documents, but it has no way to edit an existing one. The product already offers that capability in Python. Bring the Go backend up to the same public behavior.

Add partial document editing at `PATCH /api/v1/datasets/:dataset_id/documents/:document_id`.

Work in `/repo/ragflow`. This is an offline environment with the module cache, build dependencies, and CGO setup already available; `go build ./internal/...` compiles.

## User stories / requirements

- Through the PATCH route, accept any combination of `name`, `chunk_method`, `parser_id`, `parser_config`, `pipeline_id`, `meta_fields`, `enabled`, `chunk_count`, `token_count`, and `progress`. Leave omitted fields unchanged; evaluate supplied zero and empty values under their field rules. Return the updated document in the existing JSON API shape.
- Authenticate the request and restrict edits to documents in datasets owned by the caller. Refuse an update from a caller who does not own the dataset without changing the document.
- Treat chunk, token, and progress values as system maintained. Accept matching or zero values without overwriting stored nonzero values; refuse other changes. Refuse unsupported chunking methods for a document type. Metadata values may be scalars or lists of scalars, but not nested objects.
- Check a proposed document name before changing either record. Reject an empty name, one over 255 bytes, an extension change, or a name already used by another document in the dataset. For a valid rename, update both the document and its linked file.
- When the parsing or chunking plan changes, queue the document for processing again and reset its parse progress and derived counts. Subtract this document's cleared counts from its dataset totals while retaining other documents' counts. If multiple plan fields arrive together, apply only the highest priority field: `pipeline_id` before `parser_id` before `chunk_method`.
- Merge supplied parser settings into the document's current `parser_config`, retaining unrelated settings and adding new ones. Handle RAPTOR specially: remove its block if the supplied configuration leaves it out, and retain it if the supplied configuration includes it.
- Make the document status reflect `enabled` in both directions. Switching it off reads as disabled; switching it back on reads as enabled.
