#!/usr/bin/env bash
# Sourced (not exec'd) by the harbor runner so any env vars set here stay live
# for the verifier subprocess.
#
# The internal unit tests run straight off `packages/typegpu/src`. The
# `unplugin-typegpu` vite plugin and the package's own vitest.config.mts
# resolve source without a build because TEST_BUILT is unset, so user changes
# under src/ are picked up by the test runner with no rebuild step.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/TypeGPU}"
export REPO_DIR
cd "$REPO_DIR"

# vitest has to resolve from the workspace root. If it doesn't, node_modules
# from the image build is broken, and an offline reinstall from the warmed pnpm
# store beats a confusing "vitest not found" later on.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/." \
         "Reinstalling from the frozen lockfile." >&2
    pnpm install --frozen-lockfile --offline
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
