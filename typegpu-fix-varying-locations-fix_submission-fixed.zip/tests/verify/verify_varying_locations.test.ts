// @ts-nocheck
// Varying-location checks for render pipelines.
//
// Every case builds a pipeline through the public API (tgpu.vertexFn,
// tgpu.fragmentFn, 'use gpu' closures, root.createRenderPipeline) and reads the
// WGSL that tgpu.resolve produces. Struct roles come from the entry points in
// that WGSL: the struct returned by the @vertex fn is the vertex output, the
// struct taken by the @fragment fn is the fragment input, and the struct taken
// by the @vertex fn is the vertex input.
//
// The contract checked here:
//   - a varying used by both stages has one location, the same on both sides
//   - an explicit pin (including 0) is kept on both sides
//   - no two members of one IO struct share a location
//   - vertex attribute inputs are numbered from the attribute layout
//   - pins that force two varyings onto one location make resolution throw
//   - the same varying pinned differently on the two stages makes resolution
//     throw, and the message names the varying and both locations
// Auto-assigned numbers are only compared against each other, so any
// numbering that keeps the stages in agreement is accepted.

import { describe, expect } from 'vitest';
import { it } from 'typegpu-testing-utility';
import { tgpu, d } from 'typegpu';

// Split on commas that are not nested inside (...) or <...>, so attribute
// arguments like @interpolate(flat, either) stay in one piece.
function splitTopLevel(text) {
  const parts = [];
  let depth = 0;
  let current = '';
  for (const ch of text) {
    if (ch === '(' || ch === '<') depth++;
    if (ch === ')' || ch === '>') depth--;
    if (ch === ',' && depth === 0) {
      parts.push(current);
      current = '';
      continue;
    }
    current += ch;
  }
  if (current.trim() !== '') parts.push(current);
  return parts;
}

// Reads one struct member or entry parameter, e.g. "@location(2) color: vec4f".
function readMember(part) {
  const name = part.match(/(\w+)\s*:/);
  if (!name) return undefined;
  const loc = part.match(/@location\(\s*(\d+)\s*\)/);
  const type = part.slice(part.indexOf(name[0]) + name[0].length).trim();
  return { name: name[1], type, location: loc ? Number(loc[1]) : undefined };
}

// struct name -> { member name -> location }, builtins left out.
function parseStructs(code) {
  const structs = {};
  for (const [, structName, body] of code.matchAll(/struct\s+(\w+)\s*\{([^}]*)\}/g)) {
    const members = {};
    for (const part of splitTopLevel(body)) {
      const member = readMember(part);
      if (member && member.location !== undefined) members[member.name] = member.location;
    }
    structs[structName] = members;
  }
  return structs;
}

// Located inputs of an entry point, whether they come in a struct or as
// separate parameters.
function locatedParams(params, structs) {
  const result = {};
  for (const part of splitTopLevel(params ?? '')) {
    const member = readMember(part);
    if (!member) continue;
    if (member.location !== undefined) {
      result[member.name] = member.location;
    } else if (structs[member.type]) {
      Object.assign(result, structs[member.type]);
    }
  }
  return result;
}

function stageIO(code) {
  const structs = parseStructs(code);
  const vertex = code.match(/@vertex\s+fn\s+\w+\s*\(([\s\S]*?)\)\s*->\s*(\w+)/);
  const fragment = code.match(/@fragment\s+fn\s+\w+\s*\(([\s\S]*?)\)\s*->/);
  return {
    vertexIn: vertex ? locatedParams(vertex[1], structs) : {},
    vertexOut: vertex ? (structs[vertex[2]] ?? {}) : {},
    fragmentIn: fragment ? locatedParams(fragment[1], structs) : {},
  };
}

function expectShared(io, keys) {
  for (const key of keys) {
    expect(io.vertexOut[key], `vertex output location of "${key}"`).toBeTypeOf('number');
    expect(io.fragmentIn[key], `fragment input location of "${key}"`).toBe(io.vertexOut[key]);
  }
}

function expectDistinct(members, label) {
  const values = Object.values(members);
  expect(new Set(values).size, `${label} has a repeated location: ${JSON.stringify(members)}`).toBe(
    values.length,
  );
}

function messageOfThrow(fn) {
  try {
    fn();
  } catch (err) {
    return String(err && err.message !== undefined ? err.message : err);
  }
  throw new Error('expected the call to throw, but it returned normally');
}

describe('a shared varying gets the same location on both stages', () => {
  it('shelled vertex + shelled fragment', ({ root }) => {
    const vertex = tgpu.vertexFn({
      out: {
        pos: d.builtin.position,
        color: d.vec4f,
        normal: d.location(6, d.vec4f),
      },
    })`/* vertex impl */`;
    const fragment = tgpu.fragmentFn({
      in: { color: d.location(5, d.vec4f), normal: d.vec4f },
      out: d.vec4f,
    })`{ return in.color + in.normal; }`;

    const pipeline = root.createRenderPipeline({
      vertex,
      fragment,
      targets: { format: 'rgba8unorm' },
    });

    const io = stageIO(tgpu.resolve([pipeline]));
    expectShared(io, ['color', 'normal']);
    expect(io.vertexOut.color).toBe(5);
    expect(io.vertexOut.normal).toBe(6);
    expectDistinct(io.vertexOut, 'vertex output');
  });

  it('shelled vertex + shellless fragment', ({ root }) => {
    const vertex = tgpu.vertexFn({
      out: {
        pos: d.builtin.position,
        color: d.vec4f,
        normal: d.location(6, d.vec4f),
      },
    })`/* vertex impl */`;

    const pipeline = root.createRenderPipeline({
      vertex,
      fragment: ({ color, normal }) => {
        'use gpu';
        return color + normal;
      },
      targets: { format: 'rgba8unorm' },
    });

    const io = stageIO(tgpu.resolve([pipeline]));
    expectShared(io, ['color', 'normal']);
    expect(io.vertexOut.normal).toBe(6);
    expectDistinct(io.vertexOut, 'vertex output');
  });

  it('shellless vertex + shelled fragment', ({ root }) => {
    const fragment = tgpu.fragmentFn({
      in: { color: d.location(5, d.vec4f), normal: d.vec4f },
      out: d.vec4f,
    })`{ return in.color + in.normal; }`;

    const pipeline = root.createRenderPipeline({
      vertex: () => {
        'use gpu';
        return { $position: d.vec4f(0, 0, 0, 1), color: d.vec4f(1), normal: d.vec4f(1) };
      },
      fragment,
      targets: { format: 'rgba8unorm' },
    });

    const io = stageIO(tgpu.resolve([pipeline]));
    expectShared(io, ['color', 'normal']);
    expect(io.vertexOut.color).toBe(5);
    expectDistinct(io.vertexOut, 'vertex output');
    expectDistinct(io.fragmentIn, 'fragment input');
  });

  it('shellless vertex + shelled fragment, keys declared in a different order', ({ root }) => {
    const fragment = tgpu.fragmentFn({
      in: { color: d.vec4f, normal: d.vec4f },
      out: d.vec4f,
    })`{ return in.color + in.normal; }`;

    const pipeline = root.createRenderPipeline({
      vertex: () => {
        'use gpu';
        return { $position: d.vec4f(0, 0, 0, 1), normal: d.vec4f(1), color: d.vec4f(2) };
      },
      fragment,
      targets: { format: 'rgba8unorm' },
    });

    const io = stageIO(tgpu.resolve([pipeline]));
    expectShared(io, ['color', 'normal']);
    expectDistinct(io.vertexOut, 'vertex output');
    expectDistinct(io.fragmentIn, 'fragment input');
  });
});

describe('a varying pinned to location 0 stays at 0', () => {
  it('pin on the fragment input reaches the vertex output', ({ root }) => {
    const fragment = tgpu.fragmentFn({
      in: { color: d.vec4f, normal: d.location(0, d.vec4f) },
      out: d.vec4f,
    })`{ return in.color + in.normal; }`;

    const pipeline = root.createRenderPipeline({
      vertex: () => {
        'use gpu';
        return { $position: d.vec4f(0, 0, 0, 1), color: d.vec4f(1), normal: d.vec4f(1) };
      },
      fragment,
      targets: { format: 'rgba8unorm' },
    });

    const io = stageIO(tgpu.resolve([pipeline]));
    expect(io.vertexOut.normal).toBe(0);
    expect(io.fragmentIn.normal).toBe(0);
    expectShared(io, ['color']);
    expectDistinct(io.vertexOut, 'vertex output');
  });

  it('a vertex-only varying ahead of the pinned one does not push it off 0', ({ root }) => {
    // `extra` is emitted by the vertex stage only and comes first, so it is
    // numbered before `normal` is reached.
    const fragment = tgpu.fragmentFn({
      in: { color: d.vec4f, normal: d.location(0, d.vec4f) },
      out: d.vec4f,
    })`{ return in.color + in.normal; }`;

    const pipeline = root.createRenderPipeline({
      vertex: () => {
        'use gpu';
        return {
          $position: d.vec4f(0, 0, 0, 1),
          extra: d.vec4f(3),
          color: d.vec4f(1),
          normal: d.vec4f(2),
        };
      },
      fragment,
      targets: { format: 'rgba8unorm' },
    });

    const io = stageIO(tgpu.resolve([pipeline]));
    expect(io.vertexOut.normal).toBe(0);
    expect(io.fragmentIn.normal).toBe(0);
    expectShared(io, ['color']);
    expect(io.vertexOut.extra).toBeTypeOf('number');
    expectDistinct(io.vertexOut, 'vertex output');
    expectDistinct(io.fragmentIn, 'fragment input');
  });
});

describe('auto-numbered varyings stay off pinned slots', () => {
  it('a vertex-only varying does not land on a slot pinned for a later varying', ({ root }) => {
    // `normal` is pinned to 1 on the fragment side and `color` is auto-matched.
    // `extra` comes first on the vertex side and must not reuse either slot.
    const fragment = tgpu.fragmentFn({
      in: { color: d.vec4f, normal: d.location(1, d.vec4f) },
      out: d.vec4f,
    })`{ return in.color + in.normal; }`;

    const pipeline = root.createRenderPipeline({
      vertex: () => {
        'use gpu';
        return {
          $position: d.vec4f(0, 0, 0, 1),
          extra: d.vec4f(3),
          color: d.vec4f(1),
          normal: d.vec4f(2),
        };
      },
      fragment,
      targets: { format: 'rgba8unorm' },
    });

    const io = stageIO(tgpu.resolve([pipeline]));
    expect(io.vertexOut.normal).toBe(1);
    expect(io.fragmentIn.normal).toBe(1);
    expectShared(io, ['color']);
    expect(io.vertexOut.extra).toBeTypeOf('number');
    expectDistinct(io.vertexOut, 'vertex output');
    expectDistinct(io.fragmentIn, 'fragment input');
  });
});

describe('vertex attribute inputs keep their attribute-layout numbering', () => {
  it('a fragment pin on a varying does not renumber the attribute of the same name', ({
    root,
  }) => {
    const vertexLayout = tgpu.vertexLayout(d.arrayOf(d.vec4f));
    const fragment = tgpu.fragmentFn({
      in: { color: d.location(5, d.vec4f) },
      out: d.vec4f,
    })`{ return in.color; }`;

    const pipeline = root.createRenderPipeline({
      attribs: { color: vertexLayout.attrib },
      vertex: ({ color }) => {
        'use gpu';
        return { $position: d.vec4f(), color };
      },
      fragment,
      targets: { format: 'rgba8unorm' },
    });

    const io = stageIO(tgpu.resolve([pipeline]));
    // single attribute in the layout, so it sits at 0
    expect(io.vertexIn.color).toBe(0);
    expect(io.vertexOut.color).toBe(5);
    expect(io.fragmentIn.color).toBe(5);
  });
});

describe('pins that force two varyings onto one location are rejected', () => {
  it('vertex pins one varying and the fragment pins another to the same slot', ({ root }) => {
    expect(() => {
      const vertex = tgpu.vertexFn({
        out: {
          pos: d.builtin.position,
          foo: d.location(1, d.vec4f),
          bar: d.vec4f,
        },
      })`/* vertex impl */`;
      const fragment = tgpu.fragmentFn({
        in: { bar: d.location(1, d.vec4f) },
        out: d.vec4f,
      })`{ return in.bar; }`;
      const pipeline = root.createRenderPipeline({
        vertex,
        fragment,
        targets: { format: 'rgba8unorm' },
      });
      tgpu.resolve([pipeline]);
    }).toThrow();
  });

  it('cross pins put both varyings on the same slot in each struct', ({ root }) => {
    expect(() => {
      const vertex = tgpu.vertexFn({
        out: {
          pos: d.builtin.position,
          a: d.location(2, d.vec4f),
          b: d.vec4f,
        },
      })`/* vertex impl */`;
      const fragment = tgpu.fragmentFn({
        in: { a: d.vec4f, b: d.location(2, d.vec4f) },
        out: d.vec4f,
      })`{ return in.a + in.b; }`;
      const pipeline = root.createRenderPipeline({
        vertex,
        fragment,
        targets: { format: 'rgba8unorm' },
      });
      tgpu.resolve([pipeline]);
    }).toThrow();
  });
});

describe('the same varying pinned differently on each stage is rejected', () => {
  it('resolution throws and the message names the varying and both locations', ({ root }) => {
    const message = messageOfThrow(() => {
      const vertexMain = tgpu.vertexFn({
        out: {
          foo: d.vec3f,
          bar: d.location(0, d.vec3f),
        },
      })(() => ({
        foo: d.vec3f(),
        bar: d.vec3f(),
      }));

      const fragmentMain = tgpu.fragmentFn({
        in: {
          bar: d.location(1, d.vec3f),
        },
        out: d.vec4f,
      })(() => d.vec4f());

      const pipeline = root.createRenderPipeline({
        vertex: vertexMain,
        fragment: fragmentMain,
        targets: { format: 'r8unorm' },
      });
      tgpu.resolve([pipeline]);
    });

    // vertex output pins `bar` to 0, fragment input pins it to 1
    expect(message).toMatch(/\bbar\b/);
    expect(message).toMatch(/\b0\b/);
    expect(message).toMatch(/\b1\b/);
  });
});
