## Task

Render pipelines are producing WGSL where a varying used by both stages gets one `@location` on the vertex output and a different one on the fragment input, so the shader won't link.
An easy way to hit it is a `'use gpu'` vertex that returns `{ $position, normal, color }` feeding a `tgpu.fragmentFn` whose input is declared as `{ color, normal }`.
We need it fixed for shelled `tgpu.vertexFn` and `tgpu.fragmentFn` functions, `'use gpu'` functions, and any mix of the two.
A varying pinned to location 0 doesn't always stay there and ends up in some other slot.
When the vertex function takes attributes, the fragment's pins leak into the attribute inputs, so a `color` attribute shows up at `@location(5)` just because the fragment pinned its `color` input to 5.
Attribute inputs should keep the numbering their attribute layout gives them.
If pins on the two stages force two different varyings onto the same location, resolving the pipeline should throw instead of emitting a struct with a repeated location.
When both stages pin the same varying to different locations, we log a warning and still hand back the broken WGSL.
That should throw too, and the error should name the varying and both locations.
