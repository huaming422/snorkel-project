## Task

deriving type definitions is broken for a common generic shape. if a generic struct has a field whose type requires the struct's type parameter to satisfy a trait bound, `#[derive(Type)]` fails to compile: the compiler says the parameter doesn't satisfy that bound, even though the struct declares it.

smallest repro: a wrapper struct parameterized by a bounded type, used as a field in another struct carrying the same bound. the same structs without the bound derive fine, so it's specifically the bounded case that falls over.

dig in and fix it so these derives compile. the output still needs to be generic, with the parameter described abstractly rather than pinned to the concrete type the repro instantiates with. the same root cause reaches neighbouring shapes that should also compile: the bound as a `where` clause, the bounded parameter behind a reference or inside a collection, and a lifetime parameter alongside it.

two documented gaps you can leave alone: two distinct bounded parameters instantiated with the same concrete type may collapse to one generic in the output, and a bound requiring a parameter to outlive `'static` stays unsupported.

offline box, so work with what's vendored and keep the fix in the existing code.
