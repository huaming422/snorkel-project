## Task

Multi-turn runs have started going wrong for agents that keep their history in OpenAI's Conversations store, which didn't used to happen. A new conversation's first turn is fine. Once the assistant has replied even once, though, carrying on with the conversation gets confused or incorrect answers from the model, and the conversation the server reports drifts away from the one our UI shows.

Only Conversations-backed sessions are affected. A conversation that so far has only user turns behaves, and so do our in-memory sessions.

If we capture the request for a resumed turn, the earlier assistant replies in it don't look the way a reply produced in the same run would. Tool calls in the history keep lining up with their results today, and that has to keep working. Some of our apps pass their own session input callback and see the same problem. Whatever changes, each turn should still save only its own new items to the conversation, in those apps too.

The UI draws from the stored history and lets people delete single items from it, so that history needs to read back the same as it does now. Can you track this down?
