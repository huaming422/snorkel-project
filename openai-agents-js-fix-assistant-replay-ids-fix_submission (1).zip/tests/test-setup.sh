#!/usr/bin/env bash
# Environment bootstrap for the verifier. Sourced (not exec'd) so env
# vars set here stay live for the verifier subprocess.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/openai-agents-js}"
export REPO_DIR
cd "$REPO_DIR"

# js.py reads verify.toml via tomllib (Python 3.11+) or tomli (3.10).
# The Ubuntu 22.04 base image ships 3.10 with neither, so verify.toml
# is silently dropped and the runner falls back to its jest default,
# which fails on a vitest repo. Install tomli==2.0.1 defensively.
if ! python3 -c "import tomllib" >/dev/null 2>&1 && \
   ! python3 -c "import tomli"   >/dev/null 2>&1; then
    python3 -m pip install --quiet "tomli==2.0.1" \
        || python3 -m pip install --break-system-packages --quiet "tomli==2.0.1" \
        || true
fi

# vitest must be resolvable from the workspace root; a miss means a
# corrupted node_modules. Reinstall now instead of failing later with
# a confusing "command not found". --offline because the agent phase is
# no-network; the image baked the pnpm store at the base commit.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/. " \
         "The image build is corrupt — re-running pnpm install (offline)." >&2
    pnpm install --frozen-lockfile --offline --ignore-scripts
fi

# The agents-core verifier imports prepareInputItemsWithSession directly
# from packages/agents-core/src/runner/sessionPersistence.ts via a
# relative path, so an agent edit to agents-core source is visible to
# vitest without any rebuild. The agents-openai verifier, however,
# constructs OpenAIConversationsSession from agents-openai source, which
# resolves `@openai/agents-core` through node's module resolution to the
# compiled packages/agents-core/dist. Rebuild the two relevant packages'
# dist so that cross-package imports reflect the agent's edits. tsc-multi
# is incremental (*.tsbuildinfo), so this is a near-noop when nothing
# changed. Run tsc-multi directly — NOT `pnpm build` — to avoid the
# lifecycle `prebuild` step that regenerates tracked src/metadata.ts.
echo "test-setup.sh: rebuilding agents-core + agents-openai dist..."
pnpm exec tsc-multi --maxWorkers 1

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR node=$(node --version) vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
