// @ts-nocheck
//
// These checks drive a real run through the public runner API and observe the
// input the model actually receives, so the behaviour is checked without
// naming any symbol the change might introduce and without depending on where
// in the run path the fix lives:
//
//   - `Runner.run(agent, input, { session })` from `@openai/agents-core` runs
//     one turn against a recording model that captures each request's `input`
//     and returns a canned assistant reply. A `sessionInputCallback` passed to
//     the Runner exercises the callback path.
//   - `OpenAIConversationsSession` (packages/agents-openai) is the real
//     Conversations-backed session. Its stored history is supplied by
//     overriding `getItems()` with a fixed list, and `addItems()` is replaced
//     by a recorder, so no network or API-conversion path is involved. A plain
//     `MemorySession` covers a session that does not rewrite history.
//
// A lone function_call with no matching result would be pruned as an orphan,
// so the tool scenarios seed a function_call together with its
// function_call_result.

import { describe, it, expect, vi } from 'vitest';
import { Agent, MemorySession, Runner } from '@openai/agents-core';
import { OpenAIConversationsSession } from '../src/memory/openaiConversationsSession';

const MODEL_REPLY_TEXT = 'model reply for this turn';

class RecordingModel {
  requests = [];

  async getResponse(request) {
    this.requests.push(request);
    return {
      usage: { requests: 1, inputTokens: 0, outputTokens: 0, totalTokens: 0 },
      output: [
        {
          type: 'message',
          role: 'assistant',
          status: 'completed',
          content: [{ type: 'output_text', text: MODEL_REPLY_TEXT }],
        },
      ],
      responseId: 'resp-test',
    };
  }

  async *getStreamedResponse() {
    throw new Error('streaming is not used by these checks');
  }
}

function conversationsClient() {
  // Minimal client surface so constructing the session never reaches the
  // network. getItems()/addItems() are overridden per test, so these are only
  // placeholders.
  return {
    conversations: {
      items: { list: vi.fn(), create: vi.fn(), delete: vi.fn() },
      create: vi.fn(),
      delete: vi.fn(),
    },
  };
}

function recordPersisted(session) {
  const persisted = [];
  session.addItems = async (items) => {
    persisted.push(...items);
  };
  return persisted;
}

function conversationsSession(history) {
  const session = new OpenAIConversationsSession({
    client: conversationsClient(),
    conversationId: 'conv-test',
  });
  session.getItems = async () => history.map((item) => structuredClone(item));
  const persisted = recordPersisted(session);
  return { session, persisted };
}

async function runTurn(session, input, runnerOptions = {}) {
  const model = new RecordingModel();
  const runner = new Runner({
    ...runnerOptions,
    modelProvider: { getModel: async () => model },
  });
  await runner.run(new Agent({ name: 'verify-agent', model }), input, {
    session,
  });
  expect(model.requests).toHaveLength(1);
  return model.requests[0].input;
}

const textOf = (item) =>
  typeof item.content === 'string'
    ? item.content
    : (item.content ?? []).map((part) => part.text ?? '').join('');

// Persisted items other than the model's own reply for this turn.
const persistedTurnInput = (persisted) =>
  persisted.filter((item) => textOf(item) !== MODEL_REPLY_TEXT);

const userHistory = () => ({
  id: 'conv-user',
  type: 'message',
  role: 'user',
  content: 'user history',
  providerData: { server: 'metadata' },
});
const assistantHistory = () => ({
  id: 'conv-assistant',
  type: 'message',
  role: 'assistant',
  status: 'completed',
  content: [{ type: 'output_text', text: 'assistant history' }],
  providerData: { server: 'metadata' },
});
const functionCall = (callId) => ({
  id: 'conv-call',
  type: 'function_call',
  name: 'lookup',
  callId,
  arguments: '{}',
  status: 'completed',
});
const functionCallResult = (callId) => ({
  id: 'conv-output',
  type: 'function_call_result',
  name: 'lookup',
  callId,
  output: 'ok',
  status: 'completed',
});
const strippedAssistant = () => ({
  type: 'message',
  role: 'assistant',
  status: 'completed',
  content: [{ type: 'output_text', text: 'assistant history' }],
});
const newUserTurn = { type: 'message', role: 'user', content: 'new' };

describe('verify', () => {
  // The model receives the stored history with the assistant reply's replay
  // metadata removed and every other history item unchanged, followed by the
  // new turn. The run persists only the new turn (plus the model's reply);
  // stored history is not persisted again. No-callback path.
  it('core_model_input_rewrite', async () => {
    const { session, persisted } = conversationsSession([
      userHistory(),
      assistantHistory(),
      functionCall('call-history'),
      functionCallResult('call-history'),
    ]);

    const modelInput = await runTurn(session, 'new');

    expect(modelInput).toEqual([
      userHistory(),
      strippedAssistant(),
      functionCall('call-history'),
      functionCallResult('call-history'),
      newUserTurn,
    ]);
    expect(persistedTurnInput(persisted)).toEqual([newUserTurn]);
  });

  // When a session input callback returns a combined list in which it has
  // itself already removed the same assistant replay metadata, that history
  // item is still recognised as stored history and is not persisted again.
  it('callback_dedup_matching', async () => {
    const { session, persisted } = conversationsSession([assistantHistory()]);

    const modelInput = await runTurn(session, [{ ...newUserTurn }], {
      sessionInputCallback: (history, newItems) => {
        // Strip the same replay metadata the session strips for model input,
        // then return history + new input combined.
        const {
          id: _id,
          providerData: _providerData,
          provider_data: _providerDataSnake,
          ...historyCopy
        } = history[0];
        return [historyCopy, { ...newItems[0] }];
      },
    });

    expect(modelInput).toEqual([strippedAssistant(), newUserTurn]);
    // The stripped history item is matched to stored history, so only the
    // new turn is persisted.
    expect(persistedTurnInput(persisted)).toEqual([newUserTurn]);
  });

  // A session input callback that passes the stored history through untouched
  // still results in the assistant reply reaching the model without its replay
  // metadata: the callback path is covered as well as the no-callback path.
  it('callback_passthrough_still_rewritten', async () => {
    const { session, persisted } = conversationsSession([
      userHistory(),
      assistantHistory(),
    ]);

    const modelInput = await runTurn(session, [{ ...newUserTurn }], {
      sessionInputCallback: (history, newItems) => [...history, ...newItems],
    });

    expect(modelInput).toEqual([userHistory(), strippedAssistant(), newUserTurn]);
    expect(persistedTurnInput(persisted)).toEqual([newUserTurn]);
  });

  // The rewrite is scoped to assistant messages. User-message ids and
  // tool call / tool output ids reach the model intact.
  it('tool_user_ids_preserved', async () => {
    const { session } = conversationsSession([
      userHistory(),
      assistantHistory(),
      functionCall('call-1'),
      functionCallResult('call-1'),
    ]);

    const [preparedUser, preparedAssistant, preparedCall, preparedResult] =
      await runTurn(session, 'new');

    expect(preparedUser).toEqual(userHistory());
    expect(preparedAssistant.id).toBeUndefined();
    expect(preparedAssistant.providerData).toBeUndefined();
    expect(preparedAssistant.role).toBe('assistant');
    expect(preparedCall).toEqual(functionCall('call-1'));
    expect(preparedResult).toEqual(functionCallResult('call-1'));
  });

  // Both camelCase and snake_case provider metadata on an assistant history
  // item are removed from what the model receives; user messages and
  // function-call items are unchanged.
  it('openai_assistant_only_strip', async () => {
    const { session } = conversationsSession([
      userHistory(),
      {
        ...assistantHistory(),
        providerData: { server: 'camel' },
        provider_data: { server: 'snake' },
      },
      functionCall('call-1'),
      functionCallResult('call-1'),
    ]);

    const [preparedUser, preparedAssistant, preparedCall, preparedResult] =
      await runTurn(session, 'new');

    expect(preparedUser).toEqual(userHistory());
    expect(preparedAssistant).toEqual(strippedAssistant());
    expect(preparedCall).toEqual(functionCall('call-1'));
    expect(preparedResult).toEqual(functionCallResult('call-1'));
  });

  // A session that does not rewrite history (MemorySession) still sends its
  // stored history verbatim, ids and provider metadata included.
  it('regular_session_passthrough', async () => {
    const session = new MemorySession('sess-1');
    const memoryAssistant = {
      id: 'h1',
      type: 'message',
      role: 'assistant',
      status: 'completed',
      content: [{ type: 'output_text', text: 'x' }],
      providerData: { server: 'metadata' },
    };
    const memoryUser = {
      id: 'h2',
      type: 'message',
      role: 'user',
      content: 'u',
      providerData: { server: 'metadata' },
    };
    await session.addItems([memoryAssistant, memoryUser]);

    const modelInput = await runTurn(session, 'new');

    expect(modelInput).toEqual([memoryAssistant, memoryUser, newUserTurn]);
  });

  // The read path stays intact: OpenAIConversationsSession.getItems() returns
  // stored items with their ids preserved for every role, so UI rendering and
  // per-item deletion keep working. A fixed conversations list drives
  // getItems() directly.
  it('persist_shape_unchanged', async () => {
    const storedUser = {
      id: 'conv-user',
      type: 'message',
      role: 'user',
      content: [{ type: 'input_text', text: 'user history' }],
    };
    const storedAssistant = {
      id: 'conv-assistant',
      type: 'message',
      role: 'assistant',
      status: 'completed',
      content: [{ type: 'output_text', text: 'assistant history' }],
    };
    const listFn = vi.fn(() => ({
      async *[Symbol.asyncIterator]() {
        yield storedUser;
        yield storedAssistant;
      },
    }));
    const client = {
      conversations: {
        items: { list: listFn, create: vi.fn(), delete: vi.fn() },
        create: vi.fn(),
        delete: vi.fn(),
      },
    };
    const session = new OpenAIConversationsSession({
      client,
      conversationId: 'conv-test',
    });

    const items = await session.getItems();
    const readUser = items.find((item) => item.role === 'user');
    const readAssistant = items.find((item) => item.role === 'assistant');

    expect(readUser.id).toBe('conv-user');
    expect(readAssistant.id).toBe('conv-assistant');
  });
});
