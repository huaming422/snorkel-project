#!/usr/bin/env bash
# Environment bootstrap for the verifier, sourced (not exec'd) by the harbor
# runner so exported env vars stay live for the verifier subprocess.
#
# The image already carries the full npm workspace install and the pre-built
# packages/* dist/ dirs (data-provider, data-schemas, api). This script makes a
# source edit under packages/<pkg>/src visible to any CROSS-package importer by
# rebuilding the affected packages. Within one package, the package's Jest
# config transforms TypeScript source directly (moduleNameMapper ~ -> src), so
# same-package tests see src/ edits without a rebuild.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/LibreChat}"
export REPO_DIR
cd "$REPO_DIR"

# The verifier runs offline; its uv/pip-based infrastructure (if any) must not
# reach the network. Keep npm offline so a cache miss fails fast instead of
# hanging on a dead network.
export npm_config_offline=true
export npm_config_audit=false
export npm_config_fund=false

# Sanity: the jest binary must be resolvable from the workspace root install.
if ! [ -x node_modules/.bin/jest ]; then
    echo "test-setup.sh: jest binary missing from node_modules/.bin/. " \
         "node_modules may be corrupted." >&2
    exit 1
fi

# Rebuild the library packages so their dist/ reflects any src/ change the
# solving agent made. Turbo/npm cache-hit unchanged packages quickly. The fix
# surfaces in packages/api (the model matcher) and is observed through
# packages/data-schemas (pricing injects the api matcher), both of which depend
# on librechat-data-provider's built types.
echo "test-setup.sh: rebuilding library packages (data-provider, data-schemas, api)..."
npm run build:data-provider
npm run build:data-schemas
npm run build:api

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR node=$(node --version)"
