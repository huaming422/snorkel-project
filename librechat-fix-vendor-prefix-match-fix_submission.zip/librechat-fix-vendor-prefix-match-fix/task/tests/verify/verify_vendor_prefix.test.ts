/**
 * Behavioral checks for vendor-prefixed (`vendor/model`) model-id resolution.
 *
 * Everything is asserted through the library's stable public entry points:
 *   - `getModelMaxTokens(modelName, endpoint, endpointTokenConfig?)` from
 *     `@librechat/api` for the context-window surface, and
 *   - `getValueKey` / `getMultiplier` built by `createTxMethods(...)` from
 *     `@librechat/data-schemas`, wired with the SAME production matcher the app
 *     injects (`findMatchingPattern` from `@librechat/api`), for the pricing
 *     surface.
 *
 * Neither surface is a new interface and neither signature changes; only the
 * resolved values move. Asserting one level above the matcher keeps these checks
 * agnostic to where the resolution is corrected (inside the matcher or in its
 * callers) and to any helper names a solution introduces.
 */
import { EModelEndpoint } from 'librechat-data-provider';
import { createTxMethods, tokenValues } from '@librechat/data-schemas';
import type { EndpointTokenConfig } from '~/types';
import { matchModelName, findMatchingPattern, getModelMaxTokens } from './tokens';

/**
 * Wire the pricing methods with the real model-lookup functions, mirroring the
 * production wiring (api/models) and the package's own pricing spec. The pricing
 * package owns no matcher of its own — it receives this one by injection — so
 * this is what proves a single corrected matcher fixes billing as well.
 */
const { getValueKey, getMultiplier } = createTxMethods(
  // The pricing methods never touch the mongoose connection for these lookups.
  {} as typeof import('mongoose'),
  {
    matchModelName: (model: string, endpoint?: string) =>
      matchModelName(model, endpoint as EModelEndpoint),
    findMatchingPattern: (model: string, values) =>
      findMatchingPattern(model, values as Record<string, number>) ?? undefined,
  },
);

describe('vendor-prefixed model resolution', () => {
  it('context window resolves to the model segment, not the vendor prefix', () => {
    // The model segment's window must win over the vendor segment's window.
    expect(getModelMaxTokens('moonshotai/kimi-k2', EModelEndpoint.openAI)).toBe(262144);
    // A second spelling of the same prefixed id — a single added data row would
    // not satisfy both forms.
    expect(getModelMaxTokens('moonshot/kimi-k2', EModelEndpoint.openAI)).toBe(262144);
  });

  it('pricing resolves to the model segment via the injected production matcher', () => {
    expect(getValueKey('moonshotai/kimi-k2')).toBe('kimi-k2');
    expect(getMultiplier({ model: 'moonshotai/kimi-k2', tokenType: 'prompt' })).toBe(
      tokenValues['kimi-k2'].prompt,
    );
    expect(getMultiplier({ model: 'moonshotai/kimi-k2', tokenType: 'prompt' })).not.toBe(
      tokenValues['moonshot'].prompt,
    );
  });

  it('a prefixed id whose segment has no key falls back to the prefix match', () => {
    // `v1-8k` is not a standalone key, so the whole-id / prefix match must still
    // apply rather than collapsing to no match.
    expect(getModelMaxTokens('moonshot/v1-8k', EModelEndpoint.openAI)).toBe(
      getModelMaxTokens('moonshot', EModelEndpoint.openAI),
    );
  });

  it('a vendor-keyed override entry still wins over a bare key', () => {
    const config: EndpointTokenConfig = {
      'openrouter/foo': { prompt: 1, completion: 2, context: 900000, output: 1 },
      foo: { prompt: 1, completion: 2, context: 1000, output: 1 },
    } as EndpointTokenConfig;
    // A key that carries the vendor is the most specific answer and is kept.
    expect(getModelMaxTokens('openrouter/foo', EModelEndpoint.custom, config)).toBe(900000);
    expect(getModelMaxTokens('openrouter/foo-latest', EModelEndpoint.custom, config)).toBe(900000);
    // No vendor-keyed override matches, so the bare key applies.
    expect(getModelMaxTokens('other/foo-latest', EModelEndpoint.custom, config)).toBe(1000);
  });

  it('dot-separated and unprefixed ids are unchanged', () => {
    expect(getModelMaxTokens('moonshot.kimi-k2-thinking', EModelEndpoint.bedrock)).toBe(262144);
    expect(getModelMaxTokens('us.anthropic.claude-3-5-sonnet-20241022-v2:0')).toBe(200000);
    expect(getModelMaxTokens('kimi-k2', EModelEndpoint.openAI)).toBe(262144);
  });
});
