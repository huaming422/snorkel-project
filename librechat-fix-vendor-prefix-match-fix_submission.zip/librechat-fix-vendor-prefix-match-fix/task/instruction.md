## Task

Operators on OpenAI-compatible and OpenRouter-style gateways report two problems
that only hit a model referenced by its vendor-prefixed id, the `vendor/model`
form. The same model by its bare id, or by a dot-separated id like `vendor.model`
or `region.vendor.model`, is fine.

First, context falls off a cliff. Once a long conversation plus its tool output
grows large enough, the assistant answers as if the history had been wiped and
only the latest system message survived. It happens at roughly half the advertised
window, well before anything needs trimming. Drop the prefix and the model holds
its history to the expected point.

Second, those same prefixed ids get billed a higher per-token rate than the model
without the prefix. The two track together: however a prefixed id is sized, it is
priced the same way.

The bare and dot-separated ids are correct and must stay that way; only the slash
form is wrong. Fix the root cause so a `vendor/model` id resolves to the same
context window and price as the underlying model. Validate through the existing
model-lookup and pricing entry points.
