// Plugin MCP server placeholders, observed through two stable interfaces
// composed together:
//   - the public MCPServersRegistry store/read methods, and
//   - the placeholder resolver processMCPEnv (~/utils/env).
//
// A plugin-contributed server declares a ${VAR} header. After the config makes
// a store-and-read round trip through the registry, processMCPEnv returns that
// header LITERAL (the plugin never receives the host env value), while an
// operator-authored server's own ${VAR} still expands.
//
// Setup mirrors the sibling suite __tests__/MCPServersRegistry.test.ts verbatim:
// the MCPServerInspector mock (no real connections), the mongoose-free
// ServerConfigsDB mock whose add echoes { serverName, config }, the singleton
// reset in beforeEach, and the Date.now stub that pins the clock.

import type * as t from '~/mcp/types';
import { MCPServersRegistry } from '~/mcp/registry/MCPServersRegistry';
import { MCPServerInspector } from '~/mcp/registry/MCPServerInspector';
import { processMCPEnv } from '~/utils/env';

// Mock MCPServerInspector to avoid actual server connections.
jest.mock('~/mcp/registry/MCPServerInspector');

// Mock ServerConfigsDB to avoid the mongoose dependency; add echoes back what it
// is given so the stored provenance is whatever the registry decided to persist.
jest.mock('~/mcp/registry/db/ServerConfigsDB', () => ({
  ServerConfigsDB: jest.fn().mockImplementation(() => ({
    get: jest.fn().mockResolvedValue(undefined),
    getAll: jest.fn().mockResolvedValue({}),
    add: jest
      .fn()
      .mockImplementation(async (serverName: string, config: t.ParsedServerConfig) => ({
        serverName,
        config,
      })),
    update: jest.fn().mockResolvedValue(undefined),
    remove: jest.fn().mockResolvedValue(undefined),
    reset: jest.fn().mockResolvedValue(undefined),
  })),
}));

const FIXED_TIME = 1699564800000;
const originalDateNow = Date.now;
Date.now = jest.fn(() => FIXED_TIME);

const mockMongoose = {} as typeof import('mongoose');

// A full parsed config the inspector can echo for operator-tier cases.
const baseParsedConfig: t.ParsedServerConfig = {
  type: 'stdio',
  command: 'node',
  args: ['tools.js'],
  requiresOAuth: false,
  updatedAt: FIXED_TIME,
};

// A plugin-contributed server: marked as plugin-sourced, with a placeholder in
// an outbound header that processMCPEnv returns untouched for a plugin server.
const PLUGIN_SECRET_VAR = 'TEST_PLUGIN_SECRET';
const PLUGIN_SECRET_VALUE = 'host-secret-value';
const pluginConfig: t.ParsedServerConfig = {
  source: 'plugin',
  type: 'streamable-http',
  url: 'https://plugin.example.com/mcp',
  headers: { Authorization: `Bearer \${${PLUGIN_SECRET_VAR}}` },
};

// An operator server with its own placeholder; its header MUST still resolve.
const OPERATOR_SECRET_VAR = 'TEST_OPERATOR_SECRET';
const OPERATOR_SECRET_VALUE = 'operator-secret-value';

// The Authorization header each boot inspection of one server would connect
// with. The real inspector opens its connection through MCPConnectionFactory,
// which runs processMCPEnv over the config the inspector is handed.
function inspectedHeaders(serverName: string): (string | undefined)[] {
  return jest
    .mocked(MCPServerInspector.inspect)
    .mock.calls.filter(([name]) => name === serverName)
    .map(
      ([, rawConfig]) =>
        (processMCPEnv({ options: rawConfig }) as t.StreamableHTTPOptions).headers
          ?.Authorization,
    );
}

describe('plugin provenance (security: plugin placeholders stay literal)', () => {
  let registry: MCPServersRegistry;

  beforeAll(() => {
    jest.useFakeTimers();
    jest.setSystemTime(new Date(FIXED_TIME));
  });

  afterAll(() => {
    Date.now = originalDateNow;
  });

  beforeEach(async () => {
    (MCPServersRegistry as unknown as { instance: undefined }).instance = undefined;
    MCPServersRegistry.createInstance(mockMongoose);
    registry = MCPServersRegistry.getInstance();

    jest
      .spyOn(MCPServerInspector, 'inspect')
      .mockImplementation(async (_serverName: string, rawConfig: t.MCPOptions) => {
        return {
          ...baseParsedConfig,
          ...rawConfig,
          requiresOAuth: false,
        } as unknown as t.ParsedServerConfig;
      });

    await registry.reset();
  });

  // Store a plugin server through the public add path, read it back, and run
  // the config through the same resolver the runtime uses. With the env var set
  // to a sentinel, the header still comes back as the plugin's literal text.
  it('leaves a plugin-authored header literal after a full registry round trip', async () => {
    process.env[PLUGIN_SECRET_VAR] = PLUGIN_SECRET_VALUE;
    try {
      await registry.addServer('plugin_server', pluginConfig, 'CACHE');
      const stored = await registry.getServerConfig('plugin_server');
      expect(stored).toBeDefined();

      const runtimeConfig = processMCPEnv({ options: stored! }) as t.StreamableHTTPOptions;

      // Observable security property: the plugin receives its own literal text.
      expect(runtimeConfig.headers?.Authorization).toBe(`Bearer \${${PLUGIN_SECRET_VAR}}`);
      expect(runtimeConfig.headers?.Authorization).not.toContain(PLUGIN_SECRET_VALUE);
    } finally {
      delete process.env[PLUGIN_SECRET_VAR];
    }
  });

  // Entry point 2: the recovery stub written when inspection fails must also
  // keep the plugin's placeholder literal through the resolver.
  it('keeps a plugin header literal through the inspection-failure recovery stub', async () => {
    process.env[PLUGIN_SECRET_VAR] = PLUGIN_SECRET_VALUE;
    try {
      const result = await registry.addServerStub('plugin_server', pluginConfig, 'CACHE');

      const runtimeConfig = processMCPEnv({
        options: result.config,
      }) as t.StreamableHTTPOptions;

      expect(runtimeConfig.headers?.Authorization).toBe(`Bearer \${${PLUGIN_SECRET_VAR}}`);
      expect(runtimeConfig.headers?.Authorization).not.toContain(PLUGIN_SECRET_VALUE);
    } finally {
      delete process.env[PLUGIN_SECRET_VAR];
    }
  });

  // An operator server whose boot inspection failed gets the same recovery stub
  // and still resolves its own placeholder against the environment.
  it('still resolves an operator server placeholder through the inspection-failure recovery stub', async () => {
    process.env[OPERATOR_SECRET_VAR] = OPERATOR_SECRET_VALUE;
    try {
      const operatorConfig: t.MCPOptions = {
        type: 'streamable-http',
        url: 'https://operator.example.com/mcp',
        headers: { Authorization: `Bearer \${${OPERATOR_SECRET_VAR}}` },
      };
      const result = await registry.addServerStub('operator_server', operatorConfig, 'CACHE');

      const runtimeConfig = processMCPEnv({
        options: result.config,
      }) as t.StreamableHTTPOptions;

      expect(runtimeConfig.headers?.Authorization).toBe(`Bearer ${OPERATOR_SECRET_VALUE}`);
    } finally {
      delete process.env[OPERATOR_SECRET_VAR];
    }
  });

  // What the boot inspection connects with. Every config the inspector is
  // handed for the plugin server keeps the header literal, whether the server
  // is added to the cache tier or lazily initialized in the config tier (that
  // inspection connects before it can fail). An operator server inspected the
  // same way still connects with its own placeholder resolved.
  it.each([
    ['cache-tier add', 'cache', false],
    ['config-tier lazy initialization, inspection succeeds', 'config', false],
    ['config-tier lazy initialization, inspection fails', 'config', true],
  ] as const)(
    'never hands the boot inspection a resolved plugin header (%s)',
    async (_label, tier, inspectionFails) => {
      process.env[PLUGIN_SECRET_VAR] = PLUGIN_SECRET_VALUE;
      process.env[OPERATOR_SECRET_VAR] = OPERATOR_SECRET_VALUE;
      try {
        if (inspectionFails) {
          jest
            .spyOn(MCPServerInspector, 'inspect')
            .mockRejectedValue(new Error('connection refused'));
        }
        const operatorConfig: t.MCPOptions = {
          type: 'streamable-http',
          url: 'https://operator.example.com/mcp',
          headers: { Authorization: `Bearer \${${OPERATOR_SECRET_VAR}}` },
        };
        if (tier === 'cache') {
          await registry.addServer('plugin_server', pluginConfig, 'CACHE');
          await registry.addServer('operator_server', operatorConfig, 'CACHE');
        } else {
          await registry.ensureConfigServers({
            plugin_server: pluginConfig,
            operator_server: operatorConfig,
          });
        }

        for (const header of inspectedHeaders('plugin_server')) {
          expect(header).toBe(`Bearer \${${PLUGIN_SECRET_VAR}}`);
        }

        const operatorHeaders = inspectedHeaders('operator_server');
        expect(operatorHeaders.length).toBeGreaterThan(0);
        for (const header of operatorHeaders) {
          expect(header).toBe(`Bearer ${OPERATOR_SECRET_VALUE}`);
        }
      } finally {
        delete process.env[PLUGIN_SECRET_VAR];
        delete process.env[OPERATOR_SECRET_VAR];
      }
    },
  );

  // Config-tier lazy initialization, when inspection succeeds and when it fails
  // and a recovery stub is returned. A plugin-marked config that comes back from
  // it must keep its header literal; leaving it out of the config tier is fine
  // too. An operator config server in the same pass still comes back and
  // resolves its own placeholder.
  it.each([
    ['inspection succeeds', false],
    ['inspection fails', true],
  ])(
    'never resolves a plugin header through config-tier lazy initialization (%s)',
    async (_label, inspectionFails) => {
      process.env[PLUGIN_SECRET_VAR] = PLUGIN_SECRET_VALUE;
      process.env[OPERATOR_SECRET_VAR] = OPERATOR_SECRET_VALUE;
      try {
        if (inspectionFails) {
          jest
            .spyOn(MCPServerInspector, 'inspect')
            .mockRejectedValue(new Error('connection refused'));
        }
        const operatorConfig: t.MCPOptions = {
          type: 'streamable-http',
          url: 'https://operator.example.com/mcp',
          headers: { Authorization: `Bearer \${${OPERATOR_SECRET_VAR}}` },
        };
        const result = await registry.ensureConfigServers({
          plugin_server: pluginConfig,
          operator_config_server: operatorConfig,
        });

        const pluginEntry = result.plugin_server;
        const pluginHeader = pluginEntry
          ? (processMCPEnv({ options: pluginEntry }) as t.StreamableHTTPOptions).headers
              ?.Authorization
          : `Bearer \${${PLUGIN_SECRET_VAR}}`;
        expect(pluginHeader).toBe(`Bearer \${${PLUGIN_SECRET_VAR}}`);

        const operatorEntry = result.operator_config_server;
        expect(operatorEntry).toBeDefined();
        const operatorRuntime = processMCPEnv({
          options: operatorEntry,
        }) as t.StreamableHTTPOptions;
        expect(operatorRuntime.headers?.Authorization).toBe(`Bearer ${OPERATOR_SECRET_VALUE}`);
      } finally {
        delete process.env[PLUGIN_SECRET_VAR];
        delete process.env[OPERATOR_SECRET_VAR];
      }
    },
  );

  // An ordinary operator cache-tier server still has its own placeholder
  // expanded against the environment.
  it('still resolves an operator cache-tier server placeholder against the environment', async () => {
    process.env[OPERATOR_SECRET_VAR] = OPERATOR_SECRET_VALUE;
    try {
      const operatorConfig: t.MCPOptions = {
        type: 'streamable-http',
        url: 'https://operator.example.com/mcp',
        headers: { Authorization: `Bearer \${${OPERATOR_SECRET_VAR}}` },
      };
      await registry.addServer('operator_server', operatorConfig, 'CACHE');
      const stored = await registry.getServerConfig('operator_server');
      expect(stored).toBeDefined();

      const runtimeConfig = processMCPEnv({ options: stored! }) as t.StreamableHTTPOptions;

      expect(runtimeConfig.headers?.Authorization).toBe(`Bearer ${OPERATOR_SECRET_VALUE}`);
    } finally {
      delete process.env[OPERATOR_SECRET_VAR];
    }
  });

  // Negative invariant: a server a user creates is handled as that user's
  // server even when its config claims a plugin made it. Observe that the
  // DB-sourced entry is NOT returned verbatim: its own placeholder expands
  // against the environment.
  it('never lets a user/DB-tier config claim plugin handling', async () => {
    process.env[PLUGIN_SECRET_VAR] = PLUGIN_SECRET_VALUE;
    try {
      const result = await registry.addServer('forged_server', pluginConfig, 'DB', 'user-1');

      // The stored config is resolved like any user-tier server: its header
      // placeholder is expanded.
      const runtimeConfig = processMCPEnv({
        options: result.config,
      }) as t.StreamableHTTPOptions;

      expect(runtimeConfig.headers?.Authorization).toBe(`Bearer ${PLUGIN_SECRET_VALUE}`);
    } finally {
      delete process.env[PLUGIN_SECRET_VAR];
    }
  });

  // Negative invariant: an operator Config override that uses a plugin server's
  // name still resolves the operator's own placeholder. Observed through the
  // read path that returns every server, composed with processMCPEnv.
  it('keeps an operator config override resolving its own placeholder over a plugin base', async () => {
    process.env[OPERATOR_SECRET_VAR] = OPERATOR_SECRET_VALUE;
    try {
      const pluginBase: t.ParsedServerConfig = {
        source: 'plugin',
        type: 'streamable-http',
        url: 'https://plugin.example.com/mcp',
        requiresOAuth: false,
      };
      await registry['cacheConfigsRepo'].add('shared', pluginBase);

      const override: t.ParsedServerConfig = {
        source: 'config',
        type: 'streamable-http',
        url: 'https://operator.example.com/mcp',
        headers: { Authorization: `Bearer \${${OPERATOR_SECRET_VAR}}` },
        requiresOAuth: false,
      };

      const all = await registry.getAllServerConfigs('user-1', { shared: override });
      expect(all.shared).toBeDefined();

      const runtimeConfig = processMCPEnv({ options: all.shared }) as t.StreamableHTTPOptions;

      // The operator's own placeholder resolves.
      expect(runtimeConfig.headers?.Authorization).toBe(`Bearer ${OPERATOR_SECRET_VALUE}`);
    } finally {
      delete process.env[OPERATOR_SECRET_VAR];
    }
  });

  // The same override read through the single-server path: the effective config
  // for that one name also resolves the operator's own placeholder.
  it('keeps an operator config override resolving its own placeholder in a single-server read', async () => {
    process.env[OPERATOR_SECRET_VAR] = OPERATOR_SECRET_VALUE;
    try {
      const pluginBase: t.ParsedServerConfig = {
        source: 'plugin',
        type: 'streamable-http',
        url: 'https://plugin.example.com/mcp',
        requiresOAuth: false,
      };
      await registry['cacheConfigsRepo'].add('shared', pluginBase);

      const override: t.ParsedServerConfig = {
        source: 'config',
        type: 'streamable-http',
        url: 'https://operator.example.com/mcp',
        headers: { Authorization: `Bearer \${${OPERATOR_SECRET_VAR}}` },
        requiresOAuth: false,
      };

      const effective = await registry.getServerConfig('shared', 'user-1', { shared: override });
      expect(effective).toBeDefined();

      const runtimeConfig = processMCPEnv({ options: effective! }) as t.StreamableHTTPOptions;

      expect(runtimeConfig.headers?.Authorization).toBe(`Bearer ${OPERATOR_SECRET_VALUE}`);
    } finally {
      delete process.env[OPERATOR_SECRET_VAR];
    }
  });
});
