## Task

Dalfox misses executable reflections on targets that strip quotes and angle
brackets from input. Extend verification to cover JavaScript execution sinks.

Use localhost targets for checks; dependencies are available offline.

## User stories / requirements

- When a parameter is reflected into a JavaScript timer or exec call that runs a string of code, and the server has stripped the quote and angle-bracket characters so no breakout is possible, the scanner still reports it as Verified (`[V]`).
- When a parameter is concatenated into a navigation assignment that forms a `javascript:` URL, the scanner reports it as Verified (`[V]`).
- The same holds for the other JavaScript execution sinks in this class: string-taking eval and function constructors, the interval timer, and the navigation methods and `href` assignments that build a `javascript:` URL. A parameter reflected into any of these comes back Verified (`[V]`).
- When a parameter only lands as inert data inside a function call within a `javascript:` URL, with its surrounding quote never closed so nothing executes, the scanner does not report it as Verified; no finding of type `V` appears for it.
- A classic reflection that Dalfox already confirms by breaking out of a quote or tag keeps coming back as Verified (`[V]`). Reflections into ordinary strings that do not execute remain unverified.
