"""Compile gate for dalfox-feat-js-exec-sink.

Behavioral verification lives in the validation suite: the new exec-sink
escalation is observable only by running the built `dalfox` binary against a
localhost target and reading the finding `type`. This check is a minimal
`cargo check` compile gate over the whole `dalfox` crate, so an edit that
doesn't type-check is caught here before validation wastes time on a doomed
binary build.

Stays implementation-agnostic: it does not import or name any module the change
touches, does not grep for the new detection helpers / context field / sink
list, and does not run `cargo test` (so it is insensitive to test-name
presence). Any compiling solution, whatever it names its internals, passes;
only a non-compiling workspace fails.
"""

from __future__ import annotations

import os
import subprocess
import textwrap


# Repository directory inside the task container (pre-existing, stable).
REPO_DIR = "/repo/dalfox"

# A cold check of this crate is a few minutes; the image pre-builds the
# workspace at the base commit, so an incremental check after the agent's
# edits is typically well under a minute. 10 minutes is generous headroom.
CHECK_TIMEOUT_SEC = 600


def _cargo_env() -> dict[str, str]:
    """Environment with the image's Rust toolchain + cargo dirs on PATH.

    Mirrors the Dockerfile ENV (RUSTUP_HOME=/opt/rustup, CARGO_HOME=/opt/cargo,
    CARGO_TARGET_DIR=/opt/cache/cargo-target). The Modal sandbox starts a fresh
    shell per phase, so these are re-exported rather than inherited.
    """
    env = {**os.environ}
    env.setdefault("RUSTUP_HOME", "/opt/rustup")
    env.setdefault("CARGO_HOME", "/opt/cargo")
    env.setdefault("CARGO_TARGET_DIR", "/opt/cache/cargo-target")
    env["PATH"] = f"{env['CARGO_HOME']}/bin:" + env.get("PATH", "")
    return env


def test_workspace_compiles() -> None:
    """The agent's edits must still ``cargo check`` cleanly.

    Runs ``cargo check --locked --message-format=short`` in /repo/dalfox. The
    whole crate is checked (no ``-p`` filter) because the feature spans
    parameter analysis, payload generation, and the AST verifier, and a valid
    solution may touch any of them. ``--locked`` keeps the pre-baked lockfile
    authoritative so the check does not try to re-resolve dependencies.

    On failure, dumps the last 200 lines of stdout + stderr so the failure
    mode is visible in the verifier log without flooding the judge prompt.
    """
    cmd = ["cargo", "check", "--locked", "--message-format=short"]

    result = subprocess.run(
        cmd,
        cwd=REPO_DIR,
        capture_output=True,
        text=True,
        timeout=CHECK_TIMEOUT_SEC,
        env=_cargo_env(),
        check=False,
    )

    if result.returncode == 0:
        return

    def _tail(text: str, n: int = 200) -> str:
        return "\n".join(text.splitlines()[-n:])

    msg = textwrap.dedent(
        f"""\
        cargo check failed (exit {result.returncode}).
        The agent's edits produced a workspace that no longer type-checks.
        Common causes:
          - A non-exhaustive match after extending an enum
          - A trait impl missing a method or an added method's body
          - Borrow-checker / lifetime mismatches in the new code
          - A broken signature on an edited function

        --- cargo check stdout (last 200 lines) ---
        {_tail(result.stdout)}

        --- cargo check stderr (last 200 lines) ---
        {_tail(result.stderr)}
        """
    )
    raise AssertionError(msg)
