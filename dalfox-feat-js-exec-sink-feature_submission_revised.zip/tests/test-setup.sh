#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# Rust-only task: the image baked the full crate dependency closure and a warm
# cargo target at the base commit (image/Dockerfile blocks 5-7), so this step is
# an offline no-op in the common case; the online branch only fires if the bake
# went stale.
cd /repo/dalfox

# Cut the network for cargo first, so a cache miss fails fast instead of
# silently reaching crates.io (AUTHORING.md §test-setup.sh).
export CARGO_NET_OFFLINE=true

# Dependencies + build: offline-first against the image bake, logged online
# fallback. `cargo build --locked --tests` compiles the dalfox binary and the
# test harnesses the verifier drives; the offline branch reuses the warm target
# dir, the online branch re-fetches if the lockfile moved under the agent.
if cargo build --locked --tests > /tmp/test-setup-build.log 2>&1; then
    echo "[offline-first] cargo build satisfied from image cache"
elif CARGO_NET_OFFLINE=false cargo build --locked --tests >> /tmp/test-setup-build.log 2>&1; then
    echo "[test-setup] cargo build fetched online (image bake was stale)"
else
    tail -60 /tmp/test-setup-build.log >&2; exit 1
fi

# No services to seed: validation stories spin up their own in-process HTTP
# servers reflecting a parameter into each JS exec sink, then drive the dalfox
# CLI against localhost (default flags make no outbound calls). No assertion
# logic here.
