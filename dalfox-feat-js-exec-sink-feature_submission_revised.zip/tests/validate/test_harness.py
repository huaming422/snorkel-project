"""Shared test harness for dalfox-feat-js-exec-sink validation stories.

The feature under test is observable only by running the built `dalfox`
scanner against a live target and reading the finding `type` it reports.
Every story therefore:

  1. starts a localhost HTTP server (`reflecting_server()`) that reflects the
     `q` parameter back inside a `<script>` body, imitating a target that
     *strips* the quote and angle-bracket characters (so a classic
     quote-breakout payload cannot work);
  2. points the scanner at one of that server's routes (`scan(url)`), running
     the prebuilt binary with the same flag set the repo's own integration
     suite uses; and
  3. asserts on whether a Verified (`type == "V"`) finding came back
     (`has_verified(findings)`).

The fixtures use standard JavaScript execution sinks and the public scanner
CLI. They require only the Python standard library.
"""

from __future__ import annotations

import contextlib
import http.server
import json
import os
import subprocess
import tempfile
import threading
import urllib.parse


# The scanner binary that validation-setup.sh (re)builds from the agent's
# edits. CARGO_TARGET_DIR points the build here in the task image.
BIN: str = "/opt/cache/cargo-target/debug/dalfox"

# Remove quote and angle-bracket characters to model a target on which
# ordinary quote and tag breakouts are unavailable.
STRIP_CHARS: tuple[str, ...] = ('"', "'", "<", ">")


def strip_breakout(value: str) -> str:
    """Drop every quote/angle-bracket char, imitating a sanitising target."""
    for ch in STRIP_CHARS:
        value = value.replace(ch, "")
    return value


# Route -> (HTML template with a `{p}` placeholder, strip_breakout?).
#
# The exec-sink routes reflect the (stripped) parameter straight into a
# JavaScript code-execution position: a string-taking timer/eval/function
# call, or a navigation that builds a `javascript:` URL. Because the quotes
# are stripped, the only thing that can execute is a bare, breakout-free
# payload — which is exactly the class the feature must verify.
#
# The `/safe/...` routes are the false-positive guards: inert data inside a
# `javascript:` function call (quote never closed -> not executable), and a
# plain non-exec reflection (console.log / var). The `/js/breakout-dq` route
# reflects input *raw* (no stripping) so the pre-existing quote-breakout
# verification path still applies — the regression anchor.
ROUTES: dict[str, tuple[str, bool]] = {
    # --- executable exec sinks (quotes stripped; bare payload executes) ---
    "/js/exec-sink/set-timeout": (
        '<!DOCTYPE html><html><body>'
        '<script>setTimeout("{p}", 100);</script></body></html>',
        True,
    ),
    "/js/exec-sink/set-interval": (
        '<!DOCTYPE html><html><body>'
        '<script>setInterval("{p}", 100);</script></body></html>',
        True,
    ),
    "/js/exec-sink/eval": (
        '<!DOCTYPE html><html><body>'
        '<script>eval("{p}");</script></body></html>',
        True,
    ),
    "/js/exec-sink/function": (
        '<!DOCTYPE html><html><body>'
        '<script>Function("{p}")();</script></body></html>',
        True,
    ),
    "/js/exec-sink/location-js": (
        '<!DOCTYPE html><html><body>'
        '<script>location = "javascript:" + "{p}";</script></body></html>',
        True,
    ),
    "/js/exec-sink/location-href": (
        '<!DOCTYPE html><html><body>'
        '<script>location.href = "javascript:" + "{p}";</script></body></html>',
        True,
    ),
    "/js/exec-sink/location-assign": (
        '<!DOCTYPE html><html><body>'
        '<script>location.assign("javascript:" + "{p}");</script></body></html>',
        True,
    ),
    # --- false-positive guards (must NOT verify) ---
    "/safe/unclosed-quote": (
        '<!DOCTYPE html><html><body>'
        '<script>location = "javascript:foo(\'" + "{p}" + "\')";</script>'
        '</body></html>',
        True,
    ),
    "/safe/benign-non-exec": (
        '<!DOCTYPE html><html><body>'
        '<script>console.log("{p}"); var safe = "{p}";</script></body></html>',
        True,
    ),
    # --- regression anchor: classic quote-breakout (input reflected raw) ---
    "/js/breakout-dq": (
        '<!DOCTYPE html><html><body>'
        '<script>var search = "{p}"; console.log(search);</script></body></html>',
        False,
    ),
}


class _ReflectHandler(http.server.BaseHTTPRequestHandler):
    """Reflect the `q` parameter into the route's template (optionally stripped)."""

    def log_message(self, *_args) -> None:  # silence per-request stderr noise
        return

    def _serve(self, write_body: bool) -> None:
        parsed = urllib.parse.urlparse(self.path)
        template, do_strip = ROUTES.get(
            parsed.path, ("<!DOCTYPE html><html><body>{p}</body></html>", True)
        )
        params = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        raw = params.get("q", [""])[0]
        value = strip_breakout(raw) if do_strip else raw
        body = template.replace("{p}", value).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if write_body:
            self.wfile.write(body)

    def do_GET(self) -> None:
        self._serve(write_body=True)

    def do_HEAD(self) -> None:
        self._serve(write_body=False)


@contextlib.contextmanager
def reflecting_server():
    """Context manager yielding the `host:port` of a running reflecting server.

    Threaded so the scanner's concurrent workers are all served. The server is
    torn down on exit. Binds an ephemeral port on loopback, so parallel stories
    never collide.
    """
    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _ReflectHandler)
    server.daemon_threads = True
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        host, port = server.server_address[0], server.server_address[1]
        yield f"{host}:{port}"
    finally:
        server.shutdown()
        server.server_close()


def target_url(addr: str, route: str, seed: str = "test") -> str:
    """Build the scan target URL for a route on a running reflecting server."""
    return f"http://{addr}{route}?q={seed}"


# Scan flags mirror the repo's own integration suite (`base_scan_args`):
# single localhost target, all mining/extra-reflection probes off, AST
# analysis off, small worker pool, JSON output. No remote-payload, wordlist,
# or blind-OOB flags — everything stays offline on loopback.
_SCAN_FLAGS: tuple[str, ...] = (
    "--input-type", "url",
    "--format", "json",
    "--silence",
    "--no-color",
    "--skip-mining",
    "--skip-mining-dict",
    "--skip-mining-dom",
    "--skip-reflection-header",
    "--skip-reflection-cookie",
    "--skip-reflection-path",
    "--skip-ast-analysis",
    "--workers", "5",
    "--max-concurrent-targets", "5",
)


def scan(url: str, timeout: int = 120) -> list:
    """Run `dalfox scan <url> --format json -o <file>` and return findings.

    Writes findings to a temp file (`-o`) and parses them, mirroring the repo's
    integration harness which reads the output file rather than stdout (stdout
    is suppressed by `--silence`). A successful scan with no output returns
    an empty list. Process failures and malformed output fail the test.
    """
    fd, out_path = tempfile.mkstemp(prefix="dalfox_", suffix=".json")
    os.close(fd)
    try:
        cmd = [BIN, "scan", url, *_SCAN_FLAGS, "-o", out_path]
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        if result.returncode != 0:
            raise AssertionError(
                f"dalfox exited {result.returncode} for {url}: "
                f"{result.stderr[-2000:]}"
            )
        with open(out_path, encoding="utf-8") as fh:
            text = fh.read().strip()
        if not text:
            return []
        data = json.loads(text)
        if isinstance(data, dict) and "findings" in data:
            findings = data["findings"]
            if findings is None:
                return []
        elif isinstance(data, list):
            findings = data
        else:
            raise AssertionError(f"Unexpected dalfox JSON shape for {url}")
        if not isinstance(findings, list) or not all(
            isinstance(finding, dict) and isinstance(finding.get("type"), str)
            for finding in findings
        ):
            raise AssertionError(f"Malformed dalfox findings for {url}")
        return findings
    finally:
        with contextlib.suppress(FileNotFoundError):
            os.remove(out_path)


def finding_types(findings: list) -> list:
    """Return the `type` tag of every finding (missing/odd shapes ignored)."""
    types = []
    for f in findings:
        if isinstance(f, dict):
            t = f.get("type")
            if isinstance(t, str):
                types.append(t)
    return types


def has_verified(findings: list) -> bool:
    """True iff any finding is Verified (`type == "V"`)."""
    return "V" in finding_types(findings)
