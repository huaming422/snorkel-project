#!/usr/bin/env bash
# Validation setup: runs after the agent applies its edits, before stories run.
# One job: rebuild the `dalfox` scanner binary from the agent's edited sources
# so the validation stories drive the solution-under-test and not a stale
# artifact. The image baked a pre-fix build under $CARGO_TARGET_DIR, so this is
# incremental — only touched crates recompile + relink.
#
# No fixtures to stage: each story starts its own in-process localhost
# reflecting server (test_harness.py) and needs nothing on disk but the binary.
# Idempotent: re-running just re-checks the (already-built) binary.
set -euo pipefail

REPO=/repo/dalfox

# Re-export the image's Rust environment. The Modal sandbox starts a fresh
# shell per phase, so inherit-or-default each one (mirrors the Dockerfile ENV).
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export PATH="$CARGO_HOME/bin:$PATH"

# The binary the harness drives (test_harness.BIN must match this path).
BIN="$CARGO_TARGET_DIR/debug/dalfox"

echo "validation-setup: rustc=$(rustc --version 2>&1 | head -1)"
echo "validation-setup: cargo=$(cargo --version 2>&1 | head -1)"

# Step 1: Rebuild dalfox with the agent's edits applied (incremental, offline).
# --locked keeps the pre-baked lockfile authoritative (no dependency re-resolve,
# no network). Build the binary target only — tests are not needed here.
echo "validation-setup: rebuilding dalfox (incremental, --locked)..."
( cd "$REPO" && cargo build --locked --bin dalfox 2>&1 | tail -8 )

# Step 2: Loud guard — if the binary is missing the stories would all fail with
# the same opaque error; surface it here instead.
test -x "$BIN" || {
    echo "ERROR: dalfox binary missing at $BIN after cargo build" >&2
    exit 1
}

# Step 3: Smoke — prove the freshly built binary actually runs.
echo "validation-setup: dalfox built at $BIN"
"$BIN" --version 2>&1 | head -1

echo "validation-setup: done."
