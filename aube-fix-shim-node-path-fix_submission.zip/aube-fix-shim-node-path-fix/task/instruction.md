## Task

one of our users hit a broken CLI after installing a project's deps with aube. the project depends on a package that ships a command-line program, and when they run that program it blows up trying to load another package that got pulled into the dependency tree for it. the package is right there in the install, the program just can't find it at runtime.

the same project installed with pnpm works fine. the program runs there and resolves everything it needs.

so something about the executable entry aube writes for a dependency's CLI is leaving that program unable to find a package it depends on. reproduce it, work out why aube's entry behaves differently from what pnpm produces, and fix it so the program can load everything it needs. the fix needs to hold across aube's other install layouts and keep the settings that govern how these entries get created behaving as documented.
