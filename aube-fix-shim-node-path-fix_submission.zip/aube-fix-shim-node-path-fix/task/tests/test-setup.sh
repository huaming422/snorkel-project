#!/usr/bin/env bash
# Environment bootstrap for the verifier.
#
# The behavioural grade runs `aube install` against the committed offline
# Verdaccio registry and inspects the executable entries it writes into a
# fixture's node_modules/.bin/. The agent's fix lives in Rust source, so the
# aube binary that the tests invoke must be rebuilt from the (possibly edited)
# working tree before the behavioural run — otherwise the tests would exercise
# the pre-built base binary and never see the fix.
#
# Sourced (not exec'd) by the harbor runner so env vars set here stay live for
# the verifier subprocess.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/aube}"
export REPO_DIR
cd "$REPO_DIR"

# The image bakes the full dependency closure at the base commit (block 7) and
# the agent phase is offline, so build offline-first. A locked/offline build is
# a cache hit on an unchanged tree and recompiles only the crates the agent
# touched. If an offline build somehow misses a source (e.g. the agent added a
# dependency — not expected for this task), fall back to a networked build, the
# one place test-setup.sh is allowed network.
echo "test-setup.sh: building aube from the working tree (offline-first)..."
if ! cargo build --locked --offline --bin aube > /tmp/aube-build.log 2>&1; then
    echo "test-setup.sh: offline build failed; retrying with network." >&2
    tail -40 /tmp/aube-build.log >&2 || true
    cargo build --locked --bin aube > /tmp/aube-build.log 2>&1 \
        || { echo "test-setup.sh: aube build failed." >&2; tail -80 /tmp/aube-build.log >&2; exit 1; }
fi

# Put the freshly built binary on PATH ahead of anything else, mirroring the
# repo's own bats harness (test/test_helper/common_setup.bash prepends
# target/debug). The behavioural verifier resolves `aube` from here.
# The Dockerfile sets CARGO_TARGET_DIR=/opt/cache/cargo-target so cargo
# places the binary there rather than in ${REPO_DIR}/target; honour it.
CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-${REPO_DIR}/target}"
export PATH="${CARGO_TARGET_DIR}/debug:${PATH}"

# Sanity check: the binary must be runnable.
if ! aube --version > /tmp/aube-version.log 2>&1; then
    echo "test-setup.sh: aube binary not runnable after build." >&2
    cat /tmp/aube-version.log >&2 || true
    exit 1
fi

# Sanity check: the offline-registry tooling baked into the image must be
# present (the behavioural tests serve packages from test/registry/storage with
# no uplinks; verdaccio and GNU parallel are baked in the Dockerfile).
command -v verdaccio >/dev/null 2>&1 \
    || { echo "test-setup.sh: verdaccio not found on PATH (image build problem)." >&2; exit 1; }
command -v parallel >/dev/null 2>&1 \
    || { echo "test-setup.sh: GNU parallel not found on PATH (image build problem)." >&2; exit 1; }

# Start the offline Verdaccio registry here, before pytest runs, using the
# same approach as the repo's own test/registry/start.bash and
# test/setup_suite.bash. Starting it here ensures the Node.js JIT has time
# to warm up (which can take >30 s on a cold VM) without racing against
# pytest's per-test timeout. The verify.py fixture detects the registry is
# already up (via _registry_up()) and reuses it.
VERDACCIO_PORT="${VERDACCIO_PORT:-4873}"
REGISTRY_CONFIG="$REPO_DIR/test/registry/config.yaml"
export AUBE_TEST_REGISTRY="http://localhost:${VERDACCIO_PORT}"

if ! curl -s "${AUBE_TEST_REGISTRY}/" >/dev/null 2>&1; then
    echo "test-setup.sh: starting offline Verdaccio registry..."

    # Verdaccio 6 refuses to start under root without `allowRoot: true`.
    # The grading container runs as root, so extend the upstream config with
    # that setting (and a self-contained storage path) via a temp wrapper.
    VERDACCIO_STORAGE="$REPO_DIR/test/registry/storage"
    VERDACCIO_WRAP_CFG="/tmp/verdaccio-grader.yaml"
    cat > "$VERDACCIO_WRAP_CFG" <<EOCFG
# Grader-only wrapper — extends the repo config for a root container.
storage: ${VERDACCIO_STORAGE}
allowRoot: true

packages:
  '**':
    access: \$all
    publish: \$all

log:
  type: stdout
  format: pretty
  level: error

web:
  enable: false
EOCFG

    verdaccio --config "$VERDACCIO_WRAP_CFG" --listen "$VERDACCIO_PORT" \
        > /tmp/verdaccio-startup.log 2>&1 &
    VERDACCIO_PID=$!
    export VERDACCIO_PID

    # Poll for up to 120 s.
    retries=240
    while ! curl -s "${AUBE_TEST_REGISTRY}/" >/dev/null 2>&1; do
        retries=$((retries - 1))
        if [ "$retries" -le 0 ]; then
            echo "test-setup.sh: Verdaccio did not start within 120 s." >&2
            echo "=== verdaccio log ===" >&2
            tail -50 /tmp/verdaccio-startup.log >&2 || true
            kill "$VERDACCIO_PID" 2>/dev/null || true
            exit 1
        fi
        # Check if verdaccio exited early
        if ! kill -0 "$VERDACCIO_PID" 2>/dev/null; then
            echo "test-setup.sh: Verdaccio process exited prematurely." >&2
            echo "=== verdaccio log ===" >&2
            cat /tmp/verdaccio-startup.log >&2 || true
            exit 1
        fi
        sleep 0.5
    done
    echo "test-setup.sh: Verdaccio up at ${AUBE_TEST_REGISTRY} (PID $VERDACCIO_PID)"
else
    echo "test-setup.sh: Verdaccio already running at ${AUBE_TEST_REGISTRY}"
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR aube=$(aube --version 2>/dev/null || echo unknown)"
