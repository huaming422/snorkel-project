"""Behavioral grade for the relative-length cascade defect in the headless-browser layer.

The grade is a .NET one: there is no native .NET runner in the harness, so this pytest module is a thin
driver that runs the repo's own test project once and maps its results back to one pytest test per grade
criterion. It runs under VERIFIER_PYTHON (stdlib only — no repository imports, no third-party packages) and
shells out to the SDK that the image baked.

What it does, once per session:
  1. Injects a self-contained NUnit fixture (``CascadeRenderDeviceVerify.cs``, shipped beside this file)
     into the repo's existing browser test project. The fixture asserts observable page/DevTools behavior
     only — it never names a type the solution introduces, so any faithful fix passes it and the unpatched
     tree fails it.
  2. Runs ``dotnet test`` filtered to that fixture, against the warm offline NuGet cache, rebuilding the
     engine with whatever change the submission made.
  3. Parses the TRX result file into a {method-name -> passed} map.

Each ``test_*`` below is the executable form of one criterion: it asserts the matching fixture method both
ran and passed. On the pre-fix tree the box-query and computed-style methods throw out of the engine, so
those criteria fail — that is the fail_to_pass signal.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

import pytest

REPO_DIR = Path(f"/repo/{os.environ.get('REPO_NAME', 'jint')}")
TEST_PROJECT = REPO_DIR / "Jint.Tests.Browser" / "Jint.Tests.Browser.csproj"
# Where the injected fixture lands inside the test project. A subdirectory the project does not already use,
# so nothing it ships is disturbed; default compile globbing picks the file up.
FIXTURE_SRC = Path(__file__).resolve().parent / "CascadeRenderDeviceVerify.cs"
FIXTURE_DEST_DIR = REPO_DIR / "Jint.Tests.Browser" / "Verifiers"
FIXTURE_DEST = FIXTURE_DEST_DIR / "CascadeRenderDeviceVerify.cs"

RESULTS_DIR = Path("/logs/verifier/dotnet")
TRX_PATH = RESULTS_DIR / "cascade_verify.trx"

FIXTURE_TYPE = "CascadeRenderDeviceVerify"
# Single target framework keeps the run to one build + one pass. net10.0 is the repo's current TFM and what
# CI's baseline leg uses; the filter restricts to this fixture so unrelated suites never load.
TARGET_FRAMEWORK = "net10.0"
# Generous: a cold rebuild of the engine + test project under the task's 4 CPUs is minutes, well inside the
# task's verifier timeout, and far under the 20-minute reward-stack budget.
DOTNET_TIMEOUT_SEC = 1500


def _run_dotnet_test() -> tuple[int, str]:
    """Inject the fixture, run the filtered test project, return (exit_code, combined_output)."""
    FIXTURE_DEST_DIR.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(FIXTURE_SRC, FIXTURE_DEST)

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    if TRX_PATH.exists():
        TRX_PATH.unlink()

    env = {
        **os.environ,
        "DOTNET_CLI_TELEMETRY_OPTOUT": "1",
        "DOTNET_NOLOGO": "1",
        "DOTNET_SKIP_FIRST_TIME_EXPERIENCE": "1",
        # Bound the NUnit worker pool to the declared CPUs rather than the host core count.
        "NUNIT_NUMBER_OF_TEST_WORKERS": os.environ.get("NUNIT_NUMBER_OF_TEST_WORKERS", "4"),
    }

    cmd = [
        "dotnet", "test", str(TEST_PROJECT),
        "-f", TARGET_FRAMEWORK,
        "--no-restore",
        "-c", "Release",
        "--filter", f"FullyQualifiedName~{FIXTURE_TYPE}",
        "--logger", f"trx;LogFileName={TRX_PATH.name}",
        "--results-directory", str(RESULTS_DIR),
        "--", "NUnit.NumberOfTestWorkers=4",
    ]

    proc = subprocess.run(
        cmd,
        cwd=str(REPO_DIR),
        capture_output=True,
        text=True,
        timeout=DOTNET_TIMEOUT_SEC,
        check=False,
    )
    return proc.returncode, proc.stdout + "\n" + proc.stderr


def _parse_trx(trx_path: Path) -> dict[str, bool]:
    """Map each executed test's method name to whether it passed.

    NUnit TRX ``testName`` is the fully-qualified method, optionally with parametrized-case arguments
    appended (``...media_rule_agrees_with_matchmedia(1280,"absolute")``). We key on the bare method name and
    fold a method's cases together: a method passes only if every one of its cases passed.
    """
    ns = {"t": "http://microsoft.com/schemas/VisualStudio/TeamTest/2010"}
    tree = ET.parse(str(trx_path))  # noqa: S314 - our own SDK's output, not untrusted
    root = tree.getroot()

    results: dict[str, bool] = {}
    for utr in root.findall(".//t:UnitTestResult", ns):
        raw_name = utr.get("testName", "")
        outcome = utr.get("outcome", "")
        method = raw_name.split("(", 1)[0].rsplit(".", 1)[-1].strip()
        if not method:
            continue
        passed = outcome == "Passed"
        results[method] = results.get(method, True) and passed
    return results


@pytest.fixture(scope="session")
def dotnet_results() -> dict[str, bool]:
    """Run the .NET grade once and hand every test the parsed per-method outcome map."""
    if not TEST_PROJECT.exists():
        pytest.fail(f"test project not found at {TEST_PROJECT}; image/repo layout is wrong")

    try:
        code, output = _run_dotnet_test()
    except subprocess.TimeoutExpired:
        pytest.fail(f"dotnet test timed out after {DOTNET_TIMEOUT_SEC}s")

    if not TRX_PATH.exists():
        # No result file means the build or the run never produced one — a compile break in the submission,
        # a missing SDK, a filter that matched nothing. Surface the tail so the failure is diagnosable.
        pytest.fail(
            "dotnet test produced no TRX result file "
            f"(exit {code}). Tail of output:\n{output[-3000:]}"
        )

    results = _parse_trx(TRX_PATH)
    if not results:
        pytest.fail(
            "the cascade fixture produced zero test results — the filter matched nothing or the fixture "
            f"failed to compile.\nTail of output:\n{output[-3000:]}"
        )
    # Stash the output tail for per-criterion failure messages.
    results["__output_tail__"] = output[-2000:]  # type: ignore[assignment]
    return results


def _assert_method(results: dict[str, bool], method: str) -> None:
    tail = results.get("__output_tail__", "")
    assert method in results, (
        f"criterion method '{method}' never ran (not in the .NET results). "
        f"Output tail:\n{tail}"
    )
    assert results[method] is True, (
        f"criterion method '{method}' ran but did not pass. Output tail:\n{tail}"
    )


# ── One pytest test per grade criterion ────────────────────────────────────────────────────────────────

def test_relative_length_resolves(dotnet_results):
    """getComputedStyle of a relative length resolves against the viewport instead of throwing."""
    _assert_method(dotnet_results, "relative_length_resolves")


def test_box_query_survives_relative_length(dotnet_results):
    """A box query on a page with a percentage-width rule returns a real rect; a hidden sibling has none."""
    _assert_method(dotnet_results, "box_query_survives_relative_length")


def test_media_rule_agrees_with_matchmedia(dotnet_results):
    """A style-sheet @media dimension query and matchMedia read the same viewport and agree."""
    _assert_method(dotnet_results, "media_rule_agrees_with_matchmedia")


def test_emulation_moves_cascade(dotnet_results):
    """setDeviceMetricsOverride moves what the cascade computes AND what matchMedia answers."""
    _assert_method(dotnet_results, "emulation_moves_cascade")
