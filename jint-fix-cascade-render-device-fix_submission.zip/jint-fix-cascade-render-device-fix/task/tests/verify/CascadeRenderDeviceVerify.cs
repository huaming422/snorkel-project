using System.Text.Json;
using Jint.Browser;
using Jint.Tests.Browser.DevTools;

namespace Jint.Tests.Browser.Verifiers;

// Alias so the bare name binds to the type rather than the enclosing namespace.
using BrowserEngine = global::Jint.Browser.Browser;

/// <summary>
/// Behavioral grade for the relative-length cascade defect, written entirely against the pre-existing,
/// stable page-script surface (<c>getComputedStyle</c>, <c>getBoundingClientRect</c>, <c>matchMedia</c>)
/// and the DevTools Emulation domain. Nothing here names a type the solution introduces: each test asserts
/// what a page can observe, so any faithful fix passes and the unpatched tree fails.
/// </summary>
/// <remarks>
/// One fixture, one behavior per method, each method the executable form of a single grade criterion. The
/// method names are the criterion keys the Python driver filters on and maps back to pass/fail.
/// </remarks>
[NonParallelizable]
public sealed class CascadeRenderDeviceVerify
{
    // The page a SetContentAsync produces is html > head, body > …, head is not rendered, and the row height
    // is a fixed 16px, so a rendered element's box is arithmetic on tree order. Mirrors the layout suite.
    private const int Row = 16;

    private static async Task<string> Read(Page page, string property)
        => await page.EvaluateAsync<string>(
            "getComputedStyle(document.getElementById('t')).getPropertyValue('" + property + "')")
           ?? "";

    private static async Task<string> Rect(Page page, string expression)
        => await page.EvaluateAsync<string>(
            $"(() => {{ const r = ({expression}).getBoundingClientRect(); return [r.x, r.y, r.width, r.height].join(','); }})()")
           ?? "";

    /// <summary>
    /// relative_length_resolves — every relative length resolves against the page viewport for the six
    /// properties an author writes them on, instead of aborting the whole computed-style call.
    /// </summary>
    [Test]
    public async Task relative_length_resolves()
    {
        await using var browser = new BrowserEngine();
        var page = await browser.NewPageAsync();

        // A percentage is horizontal for every property in AngleSharp's model, so a height row answers the
        // width number too. These are the page's own viewport (1280x720, 16px root), fixed by the engine.
        (string Value, string Expected)[] lengths =
        [
            ("100%", "1280px"),
            ("50%", "640px"),
            ("calc(100% - 10px)", "1270px"),
            ("2em", "32px"),
            ("2rem", "32px"),
            ("10vw", "128px"),
            ("10vh", "72px"),
        ];

        foreach (var property in new[] { "width", "height", "min-width", "margin-left", "padding-left", "font-size" })
        {
            foreach (var (value, expected) in lengths)
            {
                await page.SetContentAsync($"<style>#t {{ {property}: {value} }}</style><div id='t'>g</div>");

                (await Read(page, property))
                    .Should().Be(expected, "{0}: {1} resolves against the viewport", property, value);
            }
        }

        page.Errors.Should().BeEmpty();
    }

    /// <summary>
    /// box_query_survives_relative_length — a box query on a page carrying a <c>width: 100%</c> rule returns
    /// a real rect and does not throw; a sibling <c>display: none</c> element has no box. This is the same
    /// root cause the client symptom rides, reproduced in-process with no external driver.
    /// </summary>
    [Test]
    public async Task box_query_survives_relative_length()
    {
        await using var browser = new BrowserEngine();
        var page = await browser.NewPageAsync();

        await page.SetContentAsync(
            """
            <style>
              .form-control { width: 100%; display: block }
              #hidden { display: none }
            </style>
            <input id="SiteName" class="form-control" type="text">
            <div id="hidden">gone</div>
            """);

        // html, body, input: the input is the third rendered element; the hidden div is not one.
        (await Rect(page, "document.getElementById('SiteName')"))
            .Should().Be($"0,{2 * Row},1280,{Row}");
        (await Rect(page, "document.getElementById('hidden')"))
            .Should().Be("0,0,0,0", "display: none takes the box away");

        (await page.EvaluateAsync<string>("getComputedStyle(document.getElementById('SiteName')).width"))
            .Should().Be("1280px", "the declared 100% resolves against the viewport");

        page.Errors.Should().BeEmpty();
    }

    /// <summary>
    /// keyword_and_unconvertible_unit_no_throw — <c>auto</c> (a keyword, not a length) answers where it
    /// parses and is dropped where it does not, and a unit the engine cannot convert (<c>ch</c>) produces no
    /// CLR exception: the whole cascade is refused, nothing throws, and the resolved values still answer.
    /// </summary>
    [Test]
    public async Task keyword_and_unconvertible_unit_no_throw()
    {
        await using var browser = new BrowserEngine();
        var page = await browser.NewPageAsync();

        foreach (var (property, expected) in new[]
        {
            ("width", "auto"),
            ("height", "auto"),
            ("margin-left", "auto"),
            ("min-width", ""),
            ("padding-left", ""),
            ("font-size", ""),
        })
        {
            await page.SetContentAsync($"<style>#t {{ {property}: auto }}</style><div id='t'>g</div>");
            (await Read(page, property)).Should().Be(expected, "{0}: auto", property);
        }

        // `ch` is a unit the engine still cannot convert even with the viewport device present, so this is
        // the guard's own case: no cascade at all, resolved values answering, nothing thrown.
        await page.SetContentAsync("<style>#t { width: 20ch; visibility: hidden }</style><div id='t'>g</div>");

        (await page.EvaluateAsync<string>(
            """
            (() => {
              try { return getComputedStyle(document.getElementById('t')).visibility }
              catch (e) { return 'threw: ' + e }
            })()
            """))
            .Should().Be("visible", "a cascade the engine cannot compute takes its own visibility: hidden with it");

        (await Read(page, "width"))
            .Should().Be("1280px", "the flat box model answers where the cascade could not");

        page.Errors.Should().BeEmpty();
    }

    /// <summary>
    /// latch_only_before_first_answer — a per-element unconvertible unit (<c>width: 20ch</c>) that refuses to
    /// compute must not disable <c>display: none</c> / <c>visibility: hidden</c> handling for the rest of the
    /// tree walk: the refusal is about that element's own declarations, not the whole page. A sibling hidden
    /// element after the refusing one still has no box.
    /// </summary>
    [Test]
    public async Task latch_only_before_first_answer()
    {
        await using var browser = new BrowserEngine();
        var page = await browser.NewPageAsync();

        await page.SetContentAsync(
            """
            <style>
              #odd { width: 20ch }
              #gone { display: none }
              #shown { display: block }
            </style>
            <div id="odd">odd</div>
            <div id="gone">gone</div>
            <div id="shown">shown</div>
            """);

        // The refusing element itself answers from the flat box model and does not throw.
        (await page.EvaluateAsync<string>("getComputedStyle(document.getElementById('odd')).width"))
            .Should().Be("1280px", "the flat box model answers the element the cascade refused");

        // Crucially, the page's display:none rule is still honoured for a *later* element: the refusal did
        // not latch the cascade off for the rest of the walk.
        (await Rect(page, "document.getElementById('gone')"))
            .Should().Be("0,0,0,0", "display: none still takes the box away after an unconvertible-unit refusal");
        (await Rect(page, "document.getElementById('shown')"))
            .Should().NotBe("0,0,0,0", "a visible element after the refusal still has a box");

        page.Errors.Should().BeEmpty();
    }

    /// <summary>
    /// media_rule_agrees_with_matchmedia — a style-sheet <c>@media</c> dimension query and
    /// <c>matchMedia</c> read the same viewport and agree, across two viewport widths.
    /// </summary>
    [TestCase(1280, "absolute")]
    [TestCase(400, "relative")]
    public async Task media_rule_agrees_with_matchmedia(int width, string expected)
    {
        await using var browser = new BrowserEngine(new BrowserOptions { Viewport = new Viewport(width, 720) });
        var page = await browser.NewPageAsync();

        await page.SetContentAsync(
            """
            <style>
              #t { position: relative }
              @media (min-width: 600px) { #t { position: absolute } }
            </style>
            <div id="t">g</div>
            """);

        (await Read(page, "position")).Should().Be(expected);

        (await page.EvaluateAsync<bool>("matchMedia('(min-width: 600px)').matches"))
            .Should().Be(expected == "absolute", "the page's own matchMedia reads the same viewport");

        page.Errors.Should().BeEmpty();
    }

    /// <summary>
    /// emulation_moves_cascade — <c>Emulation.setDeviceMetricsOverride</c> moves what the cascade computes
    /// AND what <c>matchMedia</c> answers, on the same already-built document, through the DevTools domain.
    /// </summary>
    [Test]
    public async Task emulation_moves_cascade()
    {
        await using var session = await PageSession.CreateAsync();
        var attachment = await session.OpenPageAsync();

        await SetContentAsync(
            session,
            attachment,
            """
            <style>
              #t { width: 50%; position: relative }
              @media (max-width: 600px) { #t { position: absolute } }
            </style>
            <div id="t">g</div>
            """);

        const string width = "getComputedStyle(document.getElementById('t')).width";
        const string position = "getComputedStyle(document.getElementById('t')).position";

        (await Text(session, attachment, width)).Should().Be("640px", "half of the 1280px the page opened with");
        (await Text(session, attachment, position)).Should().Be("relative");
        (await Flag(session, attachment, "matchMedia('(max-width: 600px)').matches")).Should().BeFalse();

        await session.ResultAsync(
            "Emulation.setDeviceMetricsOverride",
            """{"width":390,"height":844,"deviceScaleFactor":3,"mobile":true}""",
            attachment);

        (await Text(session, attachment, width)).Should().Be("195px", "the same document, against the emulated viewport");
        (await Text(session, attachment, position)).Should().Be("absolute", "the @media rule is active now");
        (await Flag(session, attachment, "matchMedia('(max-width: 600px)').matches")).Should().BeTrue();
    }

    // ── DevTools helpers (copied shape from EmulationDomainTests) ───────────────────────────────────────
    private static async Task SetContentAsync(PageSession session, string attachment, string html)
    {
        var payload = JsonSerializer.Serialize(new Dictionary<string, string>
        {
            ["frameId"] = await FrameAsync(session, attachment).ConfigureAwait(false),
            ["html"] = html,
        });

        await session.ResultAsync("Page.setDocumentContent", payload, attachment).ConfigureAwait(false);
    }

    private static async Task<string> FrameAsync(PageSession session, string attachment)
    {
        var tree = await session.ResultAsync("Page.getFrameTree", null, attachment).ConfigureAwait(false);
        return tree.GetProperty("frameTree").GetProperty("frame").GetProperty("id").GetString()!;
    }

    private static async Task<bool> Flag(PageSession session, string attachment, string expression)
        => (await session.EvaluateAsync(expression, attachment)).GetProperty("value").GetBoolean();

    private static async Task<string> Text(PageSession session, string attachment, string expression)
        => (await session.EvaluateAsync(expression, attachment)).GetProperty("value").GetString()!;
}
