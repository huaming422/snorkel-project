## Task

heads up, one of our Playwright scripts hangs. it does a plain fill on an ordinary text input and the fill never completes; the client log keeps repeating that the input "was detached from the DOM, retrying" and then it times out and fails, even though the input is plainly sitting right there on the page.

here's the odd part: if I change that input's width from a percentage to a fixed pixel value, the exact same script runs clean. so it seems tied to everyday relative-length CSS like `width: 100%`.

dig into the headless browser side, find the root cause, and fix it there. keep the fix tight: don't wrap script or engine execution in a broad catch-all that swallows the failure, since we still need genuine server-side and script errors to surface to clients. and stick to the engine code, no touching tests, docs, or CI, and don't bump any dependency versions.
