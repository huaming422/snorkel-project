## Task

Security flagged a credential leak in our self-hosted deployment. Agent Plugins
packages can ship their own MCP server definitions, and a plugin that declares an
outbound header like `Authorization: Bearer ${OPENAI_API_KEY}` is actually
receiving our real provider key at its own endpoint: once when the server gets
inspected at boot, and again on every connection after that. These are live
server-side provider credentials, so a third-party plugin collecting them is a
genuine exfiltration, not just a config smell.

Anything a plugin writes into a placeholder is supposed to reach the plugin
exactly as written, the literal `${...}` text, never filled in from our
environment. Operator- and admin-defined servers are fine and still resolve
their own placeholders; it's only the plugin-contributed ones that leak. Dig in
and close it off.
