// Behavioral verifier for librechat-fix-plugin-mcp-provenance.
//
// Observes the security property through two pre-existing, stable interfaces
// composed together, never through internal symbols the fix may invent:
//   - the public MCPServersRegistry store/read methods, and
//   - the unchanged placeholder resolver processMCPEnv (~/utils/env).
//
// A plugin-contributed server declares a ${VAR} header. After the config makes
// a full store-and-read round trip through the registry, processMCPEnv must
// return that header LITERAL (the plugin never receives the host env value),
// while an operator-authored server's own ${VAR} still expands. The marker's
// internal field name is never asserted as the primary signal — only the
// observable resolve/no-resolve outcome — so any structurally different fix
// (inlined branches, a single guard at the repository add layer, differently
// named helpers) passes on identical external behavior.
//
// Setup mirrors the sibling suite __tests__/MCPServersRegistry.test.ts verbatim:
// the MCPServerInspector mock (no real connections), the mongoose-free
// ServerConfigsDB mock whose add echoes { serverName, config }, the singleton
// reset in beforeEach, and the Date.now fixed-time stub.

import type * as t from '~/mcp/types';
import { MCPServersRegistry } from '~/mcp/registry/MCPServersRegistry';
import { MCPServerInspector } from '~/mcp/registry/MCPServerInspector';
import { processMCPEnv } from '~/utils/env';

// Mock MCPServerInspector to avoid actual server connections.
jest.mock('~/mcp/registry/MCPServerInspector');

// Mock ServerConfigsDB to avoid the mongoose dependency; add echoes back what it
// is given so the stored provenance is whatever the registry decided to persist.
jest.mock('~/mcp/registry/db/ServerConfigsDB', () => ({
  ServerConfigsDB: jest.fn().mockImplementation(() => ({
    get: jest.fn().mockResolvedValue(undefined),
    getAll: jest.fn().mockResolvedValue({}),
    add: jest
      .fn()
      .mockImplementation(async (serverName: string, config: t.ParsedServerConfig) => ({
        serverName,
        config,
      })),
    update: jest.fn().mockResolvedValue(undefined),
    remove: jest.fn().mockResolvedValue(undefined),
    reset: jest.fn().mockResolvedValue(undefined),
  })),
}));

const FIXED_TIME = 1699564800000;
const originalDateNow = Date.now;
Date.now = jest.fn(() => FIXED_TIME);

const mockMongoose = {} as typeof import('mongoose');

// A full parsed config the inspector can echo for operator-tier cases.
const baseParsedConfig: t.ParsedServerConfig = {
  type: 'stdio',
  command: 'node',
  args: ['tools.js'],
  requiresOAuth: false,
  updatedAt: FIXED_TIME,
};

// A plugin-contributed server: marked as plugin-sourced, with a placeholder in
// an outbound header. If provenance survives the round trip, processMCPEnv
// returns this header untouched; if it is lost, the host env value leaks in.
const PLUGIN_SECRET_VAR = 'TEST_PLUGIN_SECRET';
const PLUGIN_SECRET_VALUE = 'host-secret-value';
const pluginConfig: t.ParsedServerConfig = {
  source: 'plugin',
  type: 'streamable-http',
  url: 'https://plugin.example.com/mcp',
  headers: { Authorization: `Bearer \${${PLUGIN_SECRET_VAR}}` },
};

// An operator server with its own placeholder; its header MUST still resolve.
const OPERATOR_SECRET_VAR = 'TEST_OPERATOR_SECRET';
const OPERATOR_SECRET_VALUE = 'operator-secret-value';

describe('plugin provenance (security: plugin placeholders stay literal)', () => {
  let registry: MCPServersRegistry;

  beforeAll(() => {
    jest.useFakeTimers();
    jest.setSystemTime(new Date(FIXED_TIME));
  });

  afterAll(() => {
    Date.now = originalDateNow;
  });

  beforeEach(async () => {
    (MCPServersRegistry as unknown as { instance: undefined }).instance = undefined;
    MCPServersRegistry.createInstance(mockMongoose);
    registry = MCPServersRegistry.getInstance();

    jest
      .spyOn(MCPServerInspector, 'inspect')
      .mockImplementation(async (_serverName: string, rawConfig: t.MCPOptions) => {
        return {
          ...baseParsedConfig,
          ...rawConfig,
          requiresOAuth: false,
        } as unknown as t.ParsedServerConfig;
      });

    await registry.reset();
  });

  // The core security case. Store a plugin server through the public add path,
  // read it back, and run the config through the same resolver the runtime uses.
  // With the env var set to a sentinel, a dropped marker would expand the header
  // to that sentinel; a preserved marker leaves it literal.
  it('leaves a plugin-authored header literal after a full registry round trip', async () => {
    process.env[PLUGIN_SECRET_VAR] = PLUGIN_SECRET_VALUE;
    try {
      await registry.addServer('plugin_server', pluginConfig, 'CACHE');
      const stored = await registry.getServerConfig('plugin_server');
      expect(stored).toBeDefined();

      const runtimeConfig = processMCPEnv({ options: stored! }) as t.StreamableHTTPOptions;

      // Observable security property: the plugin receives its own literal text.
      expect(runtimeConfig.headers?.Authorization).toBe(`Bearer \${${PLUGIN_SECRET_VAR}}`);
      expect(runtimeConfig.headers?.Authorization).not.toContain(PLUGIN_SECRET_VALUE);
    } finally {
      delete process.env[PLUGIN_SECRET_VAR];
    }
  });

  // Entry point 2: the recovery stub written when inspection fails must also
  // keep the plugin's placeholder literal through the resolver.
  it('keeps a plugin header literal through the inspection-failure recovery stub', async () => {
    process.env[PLUGIN_SECRET_VAR] = PLUGIN_SECRET_VALUE;
    try {
      const result = await registry.addServerStub('plugin_server', pluginConfig, 'CACHE');

      const runtimeConfig = processMCPEnv({
        options: result.config,
      }) as t.StreamableHTTPOptions;

      expect(runtimeConfig.headers?.Authorization).toBe(`Bearer \${${PLUGIN_SECRET_VAR}}`);
      expect(runtimeConfig.headers?.Authorization).not.toContain(PLUGIN_SECRET_VALUE);
    } finally {
      delete process.env[PLUGIN_SECRET_VAR];
    }
  });

  // Entry point 3: config-tier lazy initialization is a distinct store/re-tag
  // path; a fix that misses it leaks here. Observe through the resolver again.
  it('keeps a plugin header literal through config-tier lazy initialization', async () => {
    process.env[PLUGIN_SECRET_VAR] = PLUGIN_SECRET_VALUE;
    try {
      const result = await registry.ensureConfigServers({ plugin_server: pluginConfig });
      const entry = result.plugin_server;
      expect(entry).toBeDefined();

      const runtimeConfig = processMCPEnv({ options: entry }) as t.StreamableHTTPOptions;

      expect(runtimeConfig.headers?.Authorization).toBe(`Bearer \${${PLUGIN_SECRET_VAR}}`);
      expect(runtimeConfig.headers?.Authorization).not.toContain(PLUGIN_SECRET_VALUE);
    } finally {
      delete process.env[PLUGIN_SECRET_VAR];
    }
  });

  // Negative control (pass_to_pass): an ordinary operator cache-tier server must
  // still have its own placeholder expanded. Proves the fix does not over-broaden
  // and disable resolution for legitimate operator servers. Passes pre- and
  // post-fix; guards against a fix that makes everything resolve-nothing.
  it('still resolves an operator cache-tier server placeholder against the environment', async () => {
    process.env[OPERATOR_SECRET_VAR] = OPERATOR_SECRET_VALUE;
    try {
      const operatorConfig: t.MCPOptions = {
        type: 'streamable-http',
        url: 'https://operator.example.com/mcp',
        headers: { Authorization: `Bearer \${${OPERATOR_SECRET_VAR}}` },
      };
      await registry.addServer('operator_server', operatorConfig, 'CACHE');
      const stored = await registry.getServerConfig('operator_server');
      expect(stored).toBeDefined();

      const runtimeConfig = processMCPEnv({ options: stored! }) as t.StreamableHTTPOptions;

      expect(runtimeConfig.headers?.Authorization).toBe(`Bearer ${OPERATOR_SECRET_VALUE}`);
    } finally {
      delete process.env[OPERATOR_SECRET_VAR];
    }
  });

  // Negative invariant: a user/DB-tier write must never carry the no-resolve
  // treatment, even when the incoming config declares the plugin marker — or a
  // user could use it to dodge the sandboxed placeholder rules. Observe that the
  // DB-sourced entry WOULD resolve (i.e. is NOT returned verbatim): its own
  // placeholder expands against the environment.
  it('never lets a user/DB-tier config claim plugin no-resolve treatment', async () => {
    process.env[PLUGIN_SECRET_VAR] = PLUGIN_SECRET_VALUE;
    try {
      const result = await registry.addServer('forged_server', pluginConfig, 'DB', 'user-1');

      // The stored config is resolved like any user-tier server: the header the
      // config tried to smuggle in as "plugin, resolve nothing" is expanded.
      const runtimeConfig = processMCPEnv({
        options: result.config,
      }) as t.StreamableHTTPOptions;

      expect(runtimeConfig.headers?.Authorization).toBe(`Bearer ${PLUGIN_SECRET_VALUE}`);
    } finally {
      delete process.env[PLUGIN_SECRET_VAR];
    }
  });

  // Negative invariant: an operator Config override shadowing a same-name plugin
  // base keeps its OWN trusted provenance and still resolves the operator's own
  // placeholder. Inheriting the plugin's no-resolve treatment would silently
  // break the operator's server. Observed through the overlay read path composed
  // with processMCPEnv.
  it('keeps an operator config override resolving its own placeholder over a plugin base', async () => {
    process.env[OPERATOR_SECRET_VAR] = OPERATOR_SECRET_VALUE;
    try {
      const pluginBase: t.ParsedServerConfig = {
        source: 'plugin',
        type: 'streamable-http',
        url: 'https://plugin.example.com/mcp',
        requiresOAuth: false,
      };
      await registry['cacheConfigsRepo'].add('shared', pluginBase);

      const override: t.ParsedServerConfig = {
        source: 'config',
        type: 'streamable-http',
        url: 'https://operator.example.com/mcp',
        headers: { Authorization: `Bearer \${${OPERATOR_SECRET_VAR}}` },
        requiresOAuth: false,
      };

      const all = await registry.getAllServerConfigs('user-1', { shared: override });
      expect(all.shared).toBeDefined();

      const runtimeConfig = processMCPEnv({ options: all.shared }) as t.StreamableHTTPOptions;

      // The operator's own placeholder resolves — the override did not inherit
      // the plugin base's no-resolve treatment.
      expect(runtimeConfig.headers?.Authorization).toBe(`Bearer ${OPERATOR_SECRET_VALUE}`);
    } finally {
      delete process.env[OPERATOR_SECRET_VAR];
    }
  });
});
