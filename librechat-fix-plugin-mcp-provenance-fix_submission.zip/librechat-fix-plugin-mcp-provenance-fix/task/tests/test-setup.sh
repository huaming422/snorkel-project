#!/usr/bin/env bash
# Verifier-phase setup. The image already bakes the full npm dependency closure
# (npm ci) and the built workspace packages the jest suite imports
# (packages/data-provider/dist, packages/data-schemas/dist) at the base commit,
# so there is nothing to install here. The jest run resolves `packages/api/src`
# directly via babel + moduleNameMapper and needs no `packages/api/dist`.
#
# Make npm fail fast instead of hitting a dead network if any cache miss sneaks
# in (the agent phase is offline; the verifier phase reaches only the gateway).
set -euo pipefail

export npm_config_offline=true
export npm_config_audit=false
export npm_config_fund=false

echo "[test-setup] npm offline mode set; dependency closure is prebaked in the image."
