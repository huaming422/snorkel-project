// HTML Copy in Markdown — content script
// Injected on demand by the popup. Handles: resolving CSS/XPath selectors,
// highlighting matches on the page, and converting matched nodes to Markdown
// or serialising them as HTML.
(() => {
  if (window.__html2mdLoaded) return;
  window.__html2mdLoaded = true;

  const OVERLAY_ID = '__html2md_overlay__';
  const ACCENT = '#2f6feb';

  /* ------------------------------------------------------------------ */
  /* Selector resolution                                                 */
  /* ------------------------------------------------------------------ */

  // Path-style expressions (/, //, ./, ../, (...)), id(...), or a call to a
  // top-level XPath function such as count(...), string(...), concat(...).
  const XPATH_FUNCS = 'id|count|string|boolean|number|sum|concat|normalize-space|name|local-name|namespace-uri|contains|starts-with|substring|substring-before|substring-after|string-length|translate|not|true|false|lang|floor|ceiling|round|position|last';
  const XPATH_RE = new RegExp('^\\s*(\\/|\\(|\\.\\.?\\/|\\*\\/|(?:' + XPATH_FUNCS + ')\\s*\\()');

  function looksLikeXPath(sel) {
    return XPATH_RE.test(sel);
  }

  function isXPath(sel, mode) {
    if (mode === 'xpath') return true;
    if (mode === 'css') return false;
    return looksLikeXPath(sel);
  }

  // Returns { nodes: Node[], scalar: string|null, kind: 'css'|'xpath' }
  function resolve(selector, mode) {
    const sel = (selector || '').trim();
    if (!sel) return { nodes: [], scalar: null, kind: 'css' };

    if (isXPath(sel, mode)) {
      let result;
      try {
        result = document.evaluate(sel, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
      } catch (e) {
        // A TYPE_ERR means the expression yields a scalar (string/number/boolean).
        // Re-evaluate with ANY_TYPE; a real syntax error will throw again here.
        result = document.evaluate(sel, document, null, XPathResult.ANY_TYPE, null);
      }
      switch (result.resultType) {
        case XPathResult.NUMBER_TYPE:
          return { nodes: [], scalar: String(result.numberValue), kind: 'xpath' };
        case XPathResult.STRING_TYPE:
          return { nodes: [], scalar: result.stringValue, kind: 'xpath' };
        case XPathResult.BOOLEAN_TYPE:
          return { nodes: [], scalar: String(result.booleanValue), kind: 'xpath' };
        case XPathResult.ORDERED_NODE_SNAPSHOT_TYPE:
        case XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE: {
          const nodes = [];
          for (let i = 0; i < result.snapshotLength; i++) nodes.push(result.snapshotItem(i));
          return { nodes, scalar: null, kind: 'xpath' };
        }
        default: {
          const nodes = [];
          let n;
          while ((n = result.iterateNext())) nodes.push(n);
          return { nodes, scalar: null, kind: 'xpath' };
        }
      }
    }

    return { nodes: Array.from(document.querySelectorAll(sel)), scalar: null, kind: 'css' };
  }

  /* ------------------------------------------------------------------ */
  /* Highlighting                                                         */
  /* ------------------------------------------------------------------ */

  let tracked = [];
  let rafPending = false;
  let listening = false;

  function container() {
    let c = document.getElementById(OVERLAY_ID);
    if (!c) {
      c = document.createElement('div');
      c.id = OVERLAY_ID;
      Object.assign(c.style, {
        position: 'fixed', inset: '0', pointerEvents: 'none',
        zIndex: '2147483647', margin: '0', padding: '0'
      });
      document.documentElement.appendChild(c);
    }
    return c;
  }

  function rectsFor(node) {
    if (node.nodeType === Node.ELEMENT_NODE) return [node.getBoundingClientRect()];
    if (node.nodeType === Node.TEXT_NODE) {
      const r = document.createRange();
      r.selectNodeContents(node);
      return Array.from(r.getClientRects());
    }
    if (node.nodeType === Node.ATTRIBUTE_NODE && node.ownerElement) {
      return [node.ownerElement.getBoundingClientRect()];
    }
    return [];
  }

  function draw() {
    rafPending = false;
    const c = container();
    c.textContent = '';
    if (!tracked.length) return;

    const vw = window.innerWidth, vh = window.innerHeight;
    let index = 0;
    for (const { node, label } of tracked) {
      index++;
      const rects = rectsFor(node).filter(r => r.width > 0 || r.height > 0);
      rects.forEach((r, i) => {
        if (r.bottom < 0 || r.right < 0 || r.top > vh || r.left > vw) return;
        const box = document.createElement('div');
        Object.assign(box.style, {
          position: 'absolute', boxSizing: 'border-box', borderRadius: '2px',
          left: r.left + 'px', top: r.top + 'px',
          width: r.width + 'px', height: r.height + 'px',
          background: 'rgba(47,111,235,.18)',
          outline: '2px solid ' + ACCENT, outlineOffset: '-1px'
        });
        if (i === 0) {
          const tag = document.createElement('div');
          tag.textContent = (label ? label + '  ' : '') + index + ' / ' + tracked.length;
          Object.assign(tag.style, {
            position: 'absolute', left: '0', top: '-18px', padding: '1px 6px',
            font: '600 11px/16px system-ui, sans-serif', color: '#fff',
            background: ACCENT, borderRadius: '3px 3px 0 0', whiteSpace: 'nowrap'
          });
          if (r.top < 18) tag.style.top = '0';
          box.appendChild(tag);
        }
        c.appendChild(box);
      });
    }
  }

  function schedule() {
    if (rafPending) return;
    rafPending = true;
    requestAnimationFrame(draw);
  }

  // Accepts [{ node, label }] or plain Node[].
  function setTracked(list) {
    const nodes = (list || []).map(x => (x && x.node) ? x : { node: x, label: '' }).filter(x => x.node);
    tracked = nodes;
    if (nodes.length && !listening) {
      listening = true;
      window.addEventListener('scroll', schedule, true);
      window.addEventListener('resize', schedule);
    } else if (!nodes.length && listening) {
      listening = false;
      window.removeEventListener('scroll', schedule, true);
      window.removeEventListener('resize', schedule);
    }
    if (!nodes.length) {
      const c = document.getElementById(OVERLAY_ID);
      if (c) c.remove();
      return;
    }
    revealFirst(nodes[0].node);
    draw();
  }

  function revealFirst(node) {
    const el = node.nodeType === Node.ELEMENT_NODE ? node
      : (node.parentElement || node.ownerElement || null);
    if (!el) return;
    const r = el.getBoundingClientRect();
    const visible = r.bottom > 0 && r.top < window.innerHeight && r.right > 0 && r.left < window.innerWidth;
    if (!visible) el.scrollIntoView({ block: 'center', inline: 'nearest' });
  }

  /* ------------------------------------------------------------------ */
  /* HTML → Markdown                                                      */
  /* ------------------------------------------------------------------ */

  const SKIP = new Set([
    'script', 'style', 'noscript', 'template', 'svg', 'canvas', 'iframe', 'object',
    'embed', 'video', 'audio', 'select', 'textarea', 'map', 'head', 'meta', 'link', 'title'
  ]);

  const BLOCK = new Set([
    'address', 'article', 'aside', 'blockquote', 'body', 'caption', 'center', 'dd',
    'details', 'dialog', 'div', 'dl', 'dt', 'fieldset', 'figcaption', 'figure',
    'footer', 'form', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'header', 'hr', 'html',
    'li', 'main', 'nav', 'ol', 'p', 'pre', 'section', 'summary', 'table', 'tbody',
    'td', 'tfoot', 'th', 'thead', 'tr', 'ul'
  ]);

  const isBlockNode = n => !!n && n.nodeType === Node.ELEMENT_NODE && BLOCK.has(n.localName);

  function isHidden(el) {
    if (el.hidden) return true;
    const view = el.ownerDocument && el.ownerDocument.defaultView;
    if (!view) return false;
    const cs = view.getComputedStyle(el);
    return cs.display === 'none' || cs.visibility === 'hidden';
  }

  function escapeText(s) {
    return s.replace(/([\\`*_\[\]<])/g, '\\$1');
  }

  function cleanUrl(u) {
    return u.replace(/ /g, '%20').replace(/\(/g, '%28').replace(/\)/g, '%29');
  }

  // Collapse interior space runs on prose lines (never inside fenced code),
  // blank out whitespace-only lines, and squeeze 3+ newlines to 2.
  function normalise(s) {
    let inFence = false;
    const lines = s.replace(/\r/g, '').split('\n').map(line => {
      if (/^\s*`{3,}/.test(line)) { inFence = !inFence; return line; }
      if (inFence) return line;
      if (!/\S/.test(line)) return '';
      return line.replace(/(?<=\S) {2,}(?=\S)/g, ' ');
    });
    return lines.join('\n').replace(/\n{3,}/g, '\n\n');
  }

  const block = s => { s = s.trim(); return s ? '\n\n' + s + '\n\n' : ''; };
  const children = (el, ctx) => Array.from(el.childNodes).map(n => conv(n, ctx)).join('');
  const blockInner = (el, ctx) => normalise(children(el, ctx)).trim();
  const inline = (el, ctx) => children(el, ctx).replace(/\s*\n\s*/g, ' ').trim();

  function wrap(s, marker) {
    const m = s.match(/^(\s*)([\s\S]*?)(\s*)$/);
    if (!m || !m[2]) return s ? ' ' : '';
    return m[1] + marker + m[2] + marker + m[3];
  }

  function convText(node) {
    let t = node.nodeValue;
    const parent = node.parentNode;
    const parentIsBlock = isBlockNode(parent);
    const prev = node.previousSibling, next = node.nextSibling;

    if (!/\S/.test(t)) {
      if (isBlockNode(prev) || isBlockNode(next)) return '';
      if (parentIsBlock && (!prev || !next)) return '';
      return ' ';
    }
    t = t.replace(/\s+/g, ' ');
    if (isBlockNode(prev) || (parentIsBlock && !prev)) t = t.replace(/^\s+/, '');
    if (isBlockNode(next) || (parentIsBlock && !next)) t = t.replace(/\s+$/, '');
    return escapeText(t);
  }

  function inlineCode(el) {
    const t = el.textContent.replace(/\s+/g, ' ').trim();
    if (!t) return '';
    let ticks = '`';
    while (t.includes(ticks)) ticks += '`';
    const pad = (t.startsWith('`') || t.endsWith('`')) ? ' ' : '';
    return ticks + pad + t + pad + ticks;
  }

  function codeBlock(el) {
    let lang = '';
    const cands = [el, el.querySelector(':scope > code')].filter(Boolean);
    for (const n of cands) {
      const cls = typeof n.className === 'string' ? n.className : '';
      const m = cls.match(/(?:^|\s)(?:language|lang)-([\w+#.-]+)/);
      if (m) { lang = m[1]; break; }
    }
    const text = el.textContent.replace(/\n$/, '');
    let fence = '```';
    while (text.includes(fence)) fence += '`';
    return block(fence + lang + '\n' + text + '\n' + fence);
  }

  function link(el, ctx) {
    const href = el.getAttribute('href');
    const text = children(el, ctx).replace(/\s*\n\s*/g, ' ').trim();
    if (!href || /^\s*javascript:/i.test(href)) return text;
    let url;
    try { url = new URL(href, document.baseURI).href; } catch { url = href; }
    const title = el.getAttribute('title');
    const t = title ? ' "' + title.replace(/"/g, '\\"') + '"' : '';
    return '[' + (text || url) + '](' + cleanUrl(url) + t + ')';
  }

  function image(el) {
    const src = el.currentSrc || el.src || el.getAttribute('data-src') || '';
    if (!src) return '';
    const alt = (el.getAttribute('alt') || '').replace(/\s+/g, ' ').trim();
    const title = el.getAttribute('title');
    const t = title ? ' "' + title.replace(/"/g, '\\"') + '"' : '';
    return '![' + alt + '](' + cleanUrl(src) + t + ')';
  }

  function list(el, ctx) {
    const ordered = el.localName === 'ol';
    let n = parseInt(el.getAttribute('start'), 10);
    if (!Number.isFinite(n)) n = 1;
    const items = [];
    for (const li of el.children) {
      if (li.localName !== 'li') continue;
      if (isHidden(li)) continue;
      const marker = ordered ? (n++) + '. ' : '- ';
      let inner = blockInner(li, ctx);
      const cb = li.querySelector(':scope > input[type=checkbox], :scope > * > input[type=checkbox]');
      if (cb) inner = (cb.checked ? '[x] ' : '[ ] ') + inner;
      const lines = inner.split('\n');
      const pad = ' '.repeat(marker.length);
      items.push(marker + lines[0] + lines.slice(1).map(l => '\n' + (l ? pad + l : '')).join(''));
    }
    const body = items.join('\n');
    if (!body) return '';
    const nested = el.parentElement && el.parentElement.localName === 'li';
    return nested ? '\n' + body + '\n' : block(body);
  }

  function table(el, ctx) {
    const rows = Array.from(el.rows).filter(r => !isHidden(r));
    if (!rows.length) return '';
    const grid = rows.map(r => Array.from(r.cells).map(c => inline(c, ctx).replace(/\|/g, '\\|')));
    const cols = Math.max(...grid.map(r => r.length));
    if (!cols) return '';
    const padRow = r => { while (r.length < cols) r.push(''); return r; };
    const line = r => '| ' + padRow(r).join(' | ') + ' |';
    const [head, ...body] = grid;
    const out = [line(head), '| ' + Array(cols).fill('---').join(' | ') + ' |', ...body.map(line)];
    const cap = el.caption ? inline(el.caption, ctx) : '';
    return block((cap ? cap + '\n\n' : '') + out.join('\n'));
  }

  function conv(node, ctx) {
    if (node.nodeType === Node.TEXT_NODE) return convText(node);
    if (node.nodeType !== Node.ELEMENT_NODE) return '';
    const el = node;
    const tag = el.localName;
    if (SKIP.has(tag)) return '';
    if (ctx.depth > 0 && isHidden(el)) return '';
    const c = { depth: ctx.depth + 1 };

    switch (tag) {
      case 'h1': case 'h2': case 'h3': case 'h4': case 'h5': case 'h6': {
        const text = inline(el, c);
        return text ? block('#'.repeat(+tag[1]) + ' ' + text) : '';
      }
      case 'br': return '  \n';
      case 'hr': return block('---');
      case 'strong': case 'b': return wrap(children(el, c), '**');
      case 'em': case 'i': case 'cite': case 'dfn': case 'var': return wrap(children(el, c), '*');
      case 'del': case 's': case 'strike': return wrap(children(el, c), '~~');
      case 'code': case 'kbd': case 'samp': case 'tt': return inlineCode(el);
      case 'pre': return codeBlock(el);
      case 'a': return link(el, c);
      case 'img': return image(el);
      case 'ul': case 'ol': return list(el, c);
      case 'q': return '"' + children(el, c) + '"';
      case 'input': {
        const type = (el.getAttribute('type') || 'text').toLowerCase();
        if (['checkbox', 'radio', 'hidden', 'submit', 'button', 'file', 'password', 'image', 'reset'].includes(type)) return '';
        return el.value ? escapeText(el.value) : '';
      }
      case 'blockquote': {
        const inner = blockInner(el, c);
        return inner ? block(inner.split('\n').map(l => l ? '> ' + l : '>').join('\n')) : '';
      }
      case 'table': return table(el, c);
      case 'dt': { const t = inline(el, c); return t ? block('**' + t + '**') : ''; }
      case 'dd': return block(children(el, c));
      default:
        return BLOCK.has(tag) ? block(children(el, c)) : children(el, c);
    }
  }

  function toMarkdown(node) {
    if (!node) return '';
    if (node.nodeType === Node.TEXT_NODE) return escapeText(node.nodeValue.replace(/\s+/g, ' ').trim());
    if (node.nodeType === Node.ATTRIBUTE_NODE) return node.value;
    if (node.nodeType === Node.DOCUMENT_NODE) node = node.documentElement;
    if (node.nodeType !== Node.ELEMENT_NODE) return '';
    return normalise(conv(node, { depth: 0 })).trim();
  }

  /* ------------------------------------------------------------------ */
  /* HTML output                                                          */
  /* ------------------------------------------------------------------ */

  // Elements that never belong in a copied fragment.
  const HTML_STRIP = new Set(['script', 'noscript', 'template']);
  const HTML_STRIP_SEL = Array.from(HTML_STRIP).join(',');
  // Attributes holding one URL; made absolute so pasted HTML still resolves.
  const URL_ATTRS = ['href', 'src', 'poster', 'action', 'formaction', 'cite'];
  const KEEP_URL_RE = /^\s*(?:javascript|data|blob):/i;

  function escapeHtml(s) {
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function absoluteUrl(u) {
    if (!u || KEEP_URL_RE.test(u)) return u;
    try { return new URL(u, document.baseURI).href; } catch { return u; }
  }

  function absolutise(el) {
    for (const attr of URL_ATTRS) {
      const v = el.getAttribute(attr);
      if (v !== null) el.setAttribute(attr, absoluteUrl(v));
    }
    const srcset = el.getAttribute('srcset');
    if (srcset) {
      el.setAttribute('srcset', srcset.split(',').map(part => {
        const m = part.trim().match(/^(\S+)(\s+\S+)?$/);
        return m ? absoluteUrl(m[1]) + (m[2] || '') : part.trim();
      }).join(', '));
    }
  }

  // Serialise a node as HTML source. Scripts and templates are dropped and
  // URLs are made absolute; everything else is kept as it appears in the page.
  function toHtml(node) {
    if (!node) return '';
    if (node.nodeType === Node.TEXT_NODE) return escapeHtml(node.nodeValue.replace(/\s+/g, ' ').trim());
    if (node.nodeType === Node.ATTRIBUTE_NODE) return node.value;
    if (node.nodeType === Node.DOCUMENT_NODE) node = node.documentElement;
    if (node.nodeType !== Node.ELEMENT_NODE) return '';
    if (HTML_STRIP.has(node.localName)) return '';
    const clone = node.cloneNode(true);
    clone.querySelectorAll(HTML_STRIP_SEL).forEach(el => el.remove());
    absolutise(clone);
    clone.querySelectorAll('*').forEach(absolutise);
    return clone.outerHTML.trim();
  }

  /* ------------------------------------------------------------------ */
  /* Conversion entry points                                              */
  /* ------------------------------------------------------------------ */

  const CONVERTERS = { markdown: toMarkdown, html: toHtml };
  const normaliseFormat = f => (f === 'html' ? 'html' : 'markdown');

  function convertSelection(selector, mode, format) {
    format = normaliseFormat(format);
    const { nodes, scalar, kind } = resolve(selector, mode);
    if (scalar !== null) return { output: scalar, format, count: 0, scalar: true, kind };
    const parts = nodes.map(CONVERTERS[format]).filter(Boolean);
    return { output: parts.join('\n\n'), format, count: nodes.length, scalar: false, kind };
  }

  // Strip Chrome's "Failed to execute 'x' on 'Document': " prefix from DOM errors.
  function cleanError(e) {
    const m = (e && e.message) || String(e);
    return m.replace(/^Failed to execute '\w+' on '\w+':\s*/, '');
  }

  // Normalise the message payload to [{ selector, label }].
  // Accepts `items: [{selector,label}]`, `selectors: string[]`, or legacy `selector: string`.
  function itemList(msg) {
    let list;
    if (Array.isArray(msg.items)) list = msg.items;
    else if (Array.isArray(msg.selectors)) list = msg.selectors.map(s => ({ selector: s }));
    else list = [{ selector: msg.selector }];
    return list
      .map(it => ({ selector: ((it && it.selector) || '').trim(), label: ((it && it.label) || '').trim() }))
      .filter(it => it.selector);
  }

  // Resolve every item; an invalid selector throws with the selector named.
  function resolveMany(items, mode) {
    return items.map(it => {
      try {
        return { selector: it.selector, label: it.label || '', ...resolve(it.selector, mode) };
      } catch (e) {
        const err = new Error(cleanError(e));
        err.selector = it.selector;
        err.label = it.label || '';
        throw err;
      }
    });
  }

  // opts.format: 'markdown' (default) or 'html'.
  // opts.labelHeadings: emit a level-2 heading with the label ("## Label" or
  // "<h2>Label</h2>") before each labelled item's output.
  function convertMany(items, mode, opts = {}) {
    const format = normaliseFormat(opts.format);
    const convert = CONVERTERS[format];
    const heading = label => (format === 'html' ? '<h2>' + escapeHtml(label) + '</h2>' : '## ' + label);
    const parts = [];
    const perSelector = [];
    let count = 0;
    for (const r of resolveMany(items, mode)) {
      const scalar = r.scalar !== null;
      const body = scalar ? [r.scalar] : r.nodes.map(convert).filter(Boolean);
      if (!scalar) count += r.nodes.length;
      if (opts.labelHeadings && r.label && body.length) parts.push(heading(r.label));
      parts.push(...body);
      perSelector.push({ selector: r.selector, label: r.label, count: r.nodes.length, scalar, kind: r.kind });
    }
    return { output: parts.join('\n\n'), format, count, perSelector };
  }

  /* ------------------------------------------------------------------ */
  /* Messaging                                                            */
  /* ------------------------------------------------------------------ */

  const hasRuntime = typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage;

  if (hasRuntime) {
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      try {
        switch (msg && msg.type) {
          case 'ping':
            sendResponse({ ok: true });
            break;
          case 'highlight': {
            const results = resolveMany(itemList(msg), msg.mode);
            const entries = [];
            const perSelector = results.map(r => {
              for (const node of r.nodes) entries.push({ node, label: r.label });
              return { selector: r.selector, label: r.label, count: r.nodes.length, scalar: r.scalar !== null, kind: r.kind };
            });
            setTracked(entries);
            sendResponse({ ok: true, count: entries.length, perSelector });
            break;
          }
          case 'clear':
            setTracked([]);
            sendResponse({ ok: true });
            break;
          case 'copy': {
            const r = convertMany(itemList(msg), msg.mode, { labelHeadings: !!msg.labelHeadings, format: msg.format });
            sendResponse({ ok: true, ...r });
            break;
          }
          default:
            sendResponse({ ok: false, error: 'Unknown message' });
        }
      } catch (e) {
        setTracked([]);
        sendResponse({ ok: false, error: cleanError(e), selector: e && e.selector, label: e && e.label });
      }
      return false;
    });

    // The popup opens a port while it is visible; when it closes, drop highlights.
    chrome.runtime.onConnect.addListener(port => {
      if (port.name !== 'html2md-popup') return;
      port.onDisconnect.addListener(() => setTracked([]));
    });
  }

  // Exposed for debugging / testing outside the extension context.
  window.__html2md = { resolve, resolveMany, toMarkdown, toHtml, convertSelection, convertMany, highlight: setTracked };
})();
