// HTML Copy in Markdown — popup logic (multiple labelled selectors)
const $ = id => document.getElementById(id);
const rowsEl = $('rows');
const rowTpl = $('row-tpl');
const addBtn = $('add');
const copyAllBtn = $('copy-all');
const headingsChk = $('label-headings');
const status = $('status');
const modeInputs = Array.from(document.querySelectorAll('input[name=mode]'));
const formatInputs = Array.from(document.querySelectorAll('input[name=format]'));

let tabId = null;
let ready = false;
let hoverKey = null;          // which thing is hovered: a row element or 'all'
let highlightTimer = null;
let saveTimer = null;

/* ---------- helpers ---------- */

const mode = () => (modeInputs.find(r => r.checked) || modeInputs[0]).value;
const format = () => (formatInputs.find(r => r.checked) || formatInputs[0]).value;
const formatName = () => (format() === 'html' ? 'HTML' : 'Markdown');

function setStatus(text, kind = '') {
  status.textContent = text;
  status.className = 'status' + (kind ? ' ' + kind : '');
}

const plural = (n, word) => n + ' ' + word + (n === 1 ? '' : 's');

function rows() {
  return Array.from(rowsEl.querySelectorAll('.row'));
}

function itemOf(row) {
  return {
    label: row.querySelector('.label').value.trim(),
    selector: row.querySelector('.selector').value.trim()
  };
}

function allItems() {
  return rows().map(itemOf).filter(it => it.selector);
}

function describe(it) {
  return it.label ? '"' + it.label + '"' : it.selector;
}

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function restrictedUrl(url) {
  if (!url) return true;
  return /^(chrome|chrome-extension|chrome-search|edge|about|devtools|view-source):/i.test(url)
    || /^https:\/\/chromewebstore\.google\.com\//i.test(url)
    || /^https:\/\/chrome\.google\.com\/webstore/i.test(url);
}

async function ensureContent() {
  if (ready) return;
  const tab = await activeTab();
  if (!tab) throw new Error('No active tab found.');
  if (restrictedUrl(tab.url)) throw new Error('Chrome does not allow extensions on this page.');
  tabId = tab.id;

  let alive = false;
  try {
    const r = await chrome.tabs.sendMessage(tabId, { type: 'ping' });
    alive = !!(r && r.ok);
  } catch { /* not injected yet */ }

  if (!alive) {
    await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
  }
  // Keep a port open so the page clears its highlight when the popup closes.
  chrome.tabs.connect(tabId, { name: 'html2md-popup' });
  ready = true;
}

async function send(msg) {
  await ensureContent();
  const r = await chrome.tabs.sendMessage(tabId, msg);
  if (!r) throw new Error('No response from the page.');
  if (!r.ok) {
    const where = r.label ? '"' + r.label + '"' : (r.selector ? r.selector : '');
    throw new Error((where ? where + ': ' : '') + (r.error || 'Unknown error'));
  }
  return r;
}

async function writeClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    return;
  } catch { /* fall through */ }
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.style.position = 'fixed';
  ta.style.opacity = '0';
  document.body.appendChild(ta);
  ta.select();
  const ok = document.execCommand('copy');
  ta.remove();
  if (!ok) throw new Error('Clipboard write failed.');
}

function flash(btn) {
  btn.classList.add('done');
  clearTimeout(btn._doneTimer);
  btn._doneTimer = setTimeout(() => btn.classList.remove('done'), 1500);
}

// Tooltips name the output format so it is clear what a click puts on the clipboard.
function labelCopyButton(btn, name = formatName()) {
  btn.title = 'Copy this selector as ' + name + ' (Enter)';
  btn.setAttribute('aria-label', 'Copy this selector as ' + name);
}

function applyFormat() {
  const name = formatName();
  rows().forEach(row => labelCopyButton(row.querySelector('.copy'), name));
  copyAllBtn.title = 'Copy every selector\'s matches as one ' + name + ' document (Ctrl+Enter). Hover to highlight all.';
}

/* ---------- persistence ---------- */

function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    chrome.storage.local.set({
      items: rows().map(r => ({
        label: r.querySelector('.label').value,
        selector: r.querySelector('.selector').value
      })),
      mode: mode(),
      format: format(),
      labelHeadings: headingsChk.checked
    });
  }, 150);
}

/* ---------- highlight / copy ---------- */

function summarise(perSelector, total) {
  const used = perSelector.filter(p => p.count || p.scalar);
  if (perSelector.length === 1) {
    const p = perSelector[0];
    const kind = p.kind === 'xpath' ? 'XPath' : 'CSS';
    if (p.scalar) return [kind + ' expression returns a value, not elements. Copy to get it.', 'warn'];
    if (!p.count) return ['No match for ' + describe(p) + '.', 'warn'];
    return [plural(p.count, kind + ' match') + ' highlighted' + (p.label ? ' for "' + p.label + '"' : '') + '.', ''];
  }
  if (!used.length) return ['No matches for any selector.', 'warn'];
  const parts = perSelector.map(p => describe(p) + ' ' + (p.scalar ? 'value' : p.count));
  return [plural(total, 'match') + ' across ' + plural(perSelector.length, 'selector') + ': ' + parts.join(', '), used.length < perSelector.length ? 'warn' : ''];
}

async function highlight(items) {
  if (!items.length) {
    try { await send({ type: 'clear' }); } catch { /* ignore */ }
    setStatus('Type a CSS or XPath selector, then hover its box to preview.');
    return;
  }
  try {
    const r = await send({ type: 'highlight', items, mode: mode() });
    const [text, kind] = summarise(r.perSelector, r.count);
    setStatus(text, kind);
  } catch (e) {
    setStatus(e.message, 'err');
  }
}

function scheduleHighlight() {
  clearTimeout(highlightTimer);
  highlightTimer = setTimeout(() => {
    if (hoverKey === 'all') highlight(allItems());
    else if (hoverKey) { const it = itemOf(hoverKey); highlight(it.selector ? [it] : []); }
  }, 120);
}

async function clearHighlight() {
  try { await send({ type: 'clear' }); } catch { /* ignore */ }
}

async function copy(items, btn, withHeadings) {
  if (!items.length) {
    setStatus('Enter a selector first.', 'warn');
    return;
  }
  try {
    const r = await send({ type: 'copy', items, mode: mode(), format: format(), labelHeadings: !!withHeadings });
    const anyScalar = r.perSelector.some(p => p.scalar);
    if (!r.count && !anyScalar) {
      setStatus('No match for ' + (items.length === 1 ? describe(items[0]) : 'any selector') + '. Nothing copied.', 'warn');
      return;
    }
    await writeClipboard(r.output);
    const what = items.length === 1
      ? (r.perSelector[0].scalar ? 'expression result' : plural(r.count, 'element'))
      : plural(r.count, 'element') + ' from ' + plural(items.length, 'selector');
    setStatus('Copied ' + what + ' as ' + formatName() + ' (' + r.output.length.toLocaleString() + ' chars).', 'ok');
    flash(btn);
  } catch (e) {
    setStatus(e.message, 'err');
  }
}

/* ---------- rows ---------- */

function updateButtons() {
  copyAllBtn.disabled = allItems().length === 0;
}

function addRow(data = {}, focus = false) {
  const row = rowTpl.content.firstElementChild.cloneNode(true);
  const label = row.querySelector('.label');
  const selector = row.querySelector('.selector');
  const copyBtn = row.querySelector('.copy');
  const removeBtn = row.querySelector('.remove');
  const field = row.querySelector('.field');

  label.value = data.label || '';
  selector.value = data.selector || '';
  labelCopyButton(copyBtn);

  field.addEventListener('mouseenter', () => { hoverKey = row; scheduleHighlight(); });
  field.addEventListener('mouseleave', () => {
    if (hoverKey === row) hoverKey = null;
    clearTimeout(highlightTimer);
    clearHighlight();
  });

  selector.addEventListener('input', () => { save(); updateButtons(); if (hoverKey === row) scheduleHighlight(); });
  label.addEventListener('input', () => { save(); if (hoverKey === row) scheduleHighlight(); });

  const onEnter = e => {
    if (e.key !== 'Enter') return;
    e.preventDefault();
    if (e.ctrlKey || e.metaKey) copy(allItems(), copyAllBtn, headingsChk.checked);
    else { const it = itemOf(row); copy(it.selector ? [it] : [], copyBtn, false); }
  };
  selector.addEventListener('keydown', onEnter);
  label.addEventListener('keydown', onEnter);

  copyBtn.addEventListener('click', () => { const it = itemOf(row); copy(it.selector ? [it] : [], copyBtn, false); });

  removeBtn.addEventListener('click', () => {
    if (rows().length === 1) {
      label.value = '';
      selector.value = '';
      selector.focus();
    } else {
      const next = row.nextElementSibling || row.previousElementSibling;
      row.remove();
      if (next) next.querySelector('.selector').focus();
    }
    if (hoverKey === row) { hoverKey = null; clearHighlight(); }
    save();
    updateButtons();
  });

  rowsEl.appendChild(row);
  if (focus) selector.focus();
  updateButtons();
  return row;
}

/* ---------- wiring ---------- */

addBtn.addEventListener('click', () => { addRow({}, true); save(); });

copyAllBtn.addEventListener('mouseenter', () => { hoverKey = 'all'; scheduleHighlight(); });
copyAllBtn.addEventListener('mouseleave', () => {
  if (hoverKey === 'all') hoverKey = null;
  clearTimeout(highlightTimer);
  clearHighlight();
});
copyAllBtn.addEventListener('click', () => copy(allItems(), copyAllBtn, headingsChk.checked));

headingsChk.addEventListener('change', save);

modeInputs.forEach(r => r.addEventListener('change', () => {
  save();
  if (hoverKey) scheduleHighlight();
}));

formatInputs.forEach(r => r.addEventListener('change', () => {
  save();
  applyFormat();
}));

document.addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter' && !e.target.closest('.row')) {
    e.preventDefault();
    copy(allItems(), copyAllBtn, headingsChk.checked);
  }
});

window.addEventListener('pagehide', () => { if (hoverKey) clearHighlight(); });

(async function init() {
  const saved = await chrome.storage.local.get(['items', 'selector', 'mode', 'format', 'labelHeadings']);
  let items = Array.isArray(saved.items) ? saved.items : [];
  // Migrate the single-selector format from earlier versions.
  if (!items.length && typeof saved.selector === 'string' && saved.selector) items = [{ selector: saved.selector }];
  if (!items.length) items = [{}];
  items.forEach(it => addRow(it));
  const m = modeInputs.find(r => r.value === saved.mode);
  if (m) m.checked = true;
  const f = formatInputs.find(r => r.value === saved.format);
  if (f) f.checked = true;
  applyFormat();
  headingsChk.checked = !!saved.labelHeadings;
  const first = rowsEl.querySelector('.selector');
  if (first) { first.focus(); first.select(); }
  // Prime the content script now so the first hover is instant.
  ensureContent().catch(e => setStatus(e.message, 'err'));
})();
