# HTML Copy in Markdown

A Chrome extension (Manifest V3) that copies part of any web page as Markdown
or as HTML source. Type a **CSS** or **XPath** selector, hover the input to see
the matching elements highlighted on the page, then press the copy button (or
Enter) to put the Markdown or HTML on your clipboard.

## Install (unpacked)

1. Open `chrome://extensions` in Chrome.
2. Turn on **Developer mode** (top right).
3. Click **Load unpacked** and pick this folder.
4. Pin the **MD** icon from the extensions menu if you like.

No build step is needed. There are no external dependencies.

## Use

1. Open the page you want to copy from and click the **MD** toolbar icon.
2. Pick a selector type: **Auto** (default), **CSS**, or **XPath**.
   In Auto mode, anything starting with `/`, `(`, `./`, `../`, or an XPath
   function call such as `id(`, `count(`, `string(` is treated as XPath;
   everything else is CSS. Auto lets you mix both kinds in one list.
3. Pick an output format next to **Copy as**: **Markdown** (default) or
   **HTML**. HTML copies the matched elements' source instead of converting
   them (see *HTML output* below).
4. Each row has an optional **Label** and a **selector**, for example
   `article.post`, `main > h2`, `//table[1]`, or `//div[@id='content']//p`.
   Click **Add selector** for more rows; the **×** at the end removes a row.
5. **Hover** a selector box: every match is outlined on the page with a
   `Label n / total` badge, and the first match scrolls into view. Hovering
   **Copy all** highlights the matches of every row. Move the mouse away to
   clear the highlight.
6. **Copy one row**: click the copy icon inside its box, or press **Enter**
   while in that row.
   **Copy all rows**: click **Copy all** or press **Ctrl+Enter**. Output is in
   row order, each row's matches in document order, separated by blank lines.
   Tick **Use labels as headings** to start each labelled row's output with a
   `## Label` heading (`<h2>Label</h2>` when copying as HTML).

Rows, labels, selector type, output format, and the headings option are
remembered between popups.

### XPath extras

- Expressions that return text or attribute nodes (`//h1/text()`,
  `//a/@href`) copy their values, one per paragraph.
- Scalar expressions (`count(//li)`, `string(//title)`) copy the result as
  plain text.

## What gets converted

| HTML | Markdown |
| --- | --- |
| `h1`–`h6` | `#` … `######` headings |
| `p`, `div`, `section`, … | paragraphs separated by blank lines |
| `strong`/`b`, `em`/`i`, `del`/`s` | `**bold**`, `*italic*`, `~~strike~~` |
| `code` | `` `inline` `` (backtick-safe) |
| `pre` (`language-xxx` class) | fenced block with language |
| `a`, `img` | `[text](absolute-url "title")`, `![alt](src)` |
| `ul`, `ol` (`start` honoured), nested lists, checkbox items | `-` / `1.` lists, `[x]` / `[ ]` |
| `blockquote` | `> ` prefixed lines |
| `table` (with `caption`) | pipe table, header row + separator |
| `hr`, `br` | `---`, hard line break |
| `dl` / `dt` / `dd` | bold term, definition paragraph |

`script`, `style`, `svg`, `iframe`, `video`, form controls, and anything hidden
(`hidden` attribute, `display: none`, `visibility: hidden`) are skipped.
Markdown-significant characters in text (`* _ \` [ ] < \`) are escaped.

## HTML output

With **Copy as HTML**, each matched element is copied as its HTML source
(`outerHTML`) with two adjustments:

- `script`, `noscript`, and `template` elements are removed.
- URLs in `href`, `src`, `srcset`, `poster`, `action`, `formaction`, and
  `cite` are made absolute, so links and images still resolve after pasting.

Nothing else is changed: hidden elements, inline styles, classes, and other
attributes are kept exactly as they appear in the page. Text nodes from XPath
copy their text HTML-escaped; attribute nodes and scalar results copy their
plain value. The clipboard receives the source as plain text, ready to paste
into an editor.

## Files

| File | Purpose |
| --- | --- |
| `manifest.json` | Extension manifest (permissions: `activeTab`, `scripting`, `storage`) |
| `popup.html` / `popup.css` / `popup.js` | Toolbar popup: selector-type and output-format switches, labelled selector rows (each with an embedded copy button), Add / Copy all, status line |
| `content.js` | Injected on demand: resolves selectors, draws the highlight overlay, converts matches to Markdown or serialises them as HTML |
| `icons/` | Toolbar icons |
| `test-page.html` | Sample page covering every supported element; open it locally to try the extension |

## Limitations

- The extension works on the active tab's top frame only; content inside
  cross-origin iframes is not reachable.
- Chrome blocks extensions on `chrome://` pages, the Web Store, and similar
  internal pages. The popup reports this.
- Very large selections (thousands of elements) convert synchronously and may
  take a moment.
