// src/parser.ts
var HEADING = /^(#{1,6})\s+(.+?)\s*#*\s*$/;
var FENCE = /^(```|~~~)\s*([\w+-]*)\s*$/;
var OPTION = /^(?:[-*+]\s+|\d+[.)]\s+)?\[([ xX])\]\s+(.+)$/;
var BULLET = /^(?:[-*+]|\d+[.)])\s+(.+)$/;
var BOLD_LINE = /^(?:\*\*|__)(.+?)(?:\*\*|__)\s*(\(.*?\))?\s*:?\s*$/;
var KV = /^(?:[-*+]\s+|\d+[.)]\s+)?(?:\*\*|__)?([^:*_\s][^:]{0,60}?)(?:\*\*|__)?\s*:\s*(.*)$/;
var TABLE_ROW = /^\|(.+)\|\s*$/;
var TABLE_SEP = /^\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/;
function cleanKey(k) {
  return k.replace(/^[\s*_`]+|[\s*_`]+$/g, "").trim();
}
function splitAliases(rawKey) {
  const parts = rawKey.split(/\s+\/\s+/).map(cleanKey).filter(Boolean);
  const key = parts.shift() || cleanKey(rawKey);
  const seen = /* @__PURE__ */ new Set([key.toLowerCase()]);
  const aliases = parts.filter((p) => !seen.has(p.toLowerCase()) && seen.add(p.toLowerCase()));
  return { key, aliases };
}
function optionFromText(text, checked) {
  const t = text.trim();
  const bold = /^(?:\*\*|__)(.+?)(?:\*\*|__)/.exec(t);
  const label = t.replace(/\*\*|__|`/g, "").replace(/\s+/g, " ").trim();
  return { label, short: bold ? bold[1].trim() : label.replace(/\s*\(.*\)\s*$/, "").trim(), checked };
}
function looksLikeKey(rawKey, isBullet) {
  const key = splitAliases(rawKey).key;
  if (!key || key.length > (isBullet ? 80 : 40)) return false;
  if (/[.,;!?]/.test(key)) return false;
  if (!isBullet && key.split(/\s+/).length > 5) return false;
  return true;
}
function parseMarkdown(md2) {
  const lines = md2.replace(/\r\n?/g, "\n").split("\n");
  const items = [];
  const headingStack = [];
  const state = { current: null };
  let sawTitle = false;
  const cur = () => state.current;
  const flush = () => {
    const b = state.current;
    if (!b) return;
    state.current = null;
    const hasAnswer = b.answerLines !== null && b.answerLines.join("\n").trim() !== "";
    const hasOptions = b.options.length > 0;
    const desc = b.descLines.join("\n").trim();
    let answer = hasAnswer ? b.answerLines.join("\n").replace(/\s+$/, "") : void 0;
    let description = desc;
    if (!hasAnswer && !hasOptions && desc && !b.isHeading) {
      answer = desc;
      description = "";
    }
    if (answer === void 0 && !hasOptions) return;
    items.push({
      index: items.length,
      title: b.title,
      aliases: b.aliases,
      path: b.path.join(" > "),
      description,
      answer,
      options: hasOptions ? b.options : void 0
    });
  };
  const start = (rawTitle, isHeading, level, path) => {
    flush();
    const { key, aliases } = splitAliases(rawTitle);
    const b = { title: key, aliases, path, descLines: [], answerLines: null, options: [], isHeading, level };
    state.current = b;
    return b;
  };
  const pathFor = () => headingStack.map((h) => h.title);
  const childPath = (b) => b ? b.isHeading ? [...b.path, b.title] : b.path : pathFor();
  const childLevel = (b) => b ? b.level + 1 : 1;
  for (let i = 0; i < lines.length; i++) {
    const raw = lines[i];
    const line = raw.trim();
    const fence = FENCE.exec(line);
    if (fence) {
      const marker = fence[1];
      const body = [];
      i++;
      while (i < lines.length && lines[i].trim() !== marker) body.push(lines[i++].replace(/\s+$/, ""));
      const indents = body.filter((l) => l.trim()).map((l) => l.length - l.trimStart().length);
      const minIndent = indents.length ? Math.min(...indents) : 0;
      const text = body.map((l) => l.slice(minIndent)).join("\n");
      let b = cur() ?? start("Answer", false, 1, pathFor());
      let lastIdx = b.descLines.length - 1;
      while (lastIdx >= 0 && b.descLines[lastIdx] === "") lastIdx--;
      if (lastIdx >= 0) {
        const last = b.descLines[lastIdx];
        const short = last.length <= 80 && !/[.!?]$/.test(last);
        const used = b.answerLines !== null || b.options.length > 0;
        if (short && used) {
          b.descLines.splice(lastIdx);
          b = start(last.replace(/:\s*$/, ""), false, childLevel(b), childPath(b));
        }
      }
      b.answerLines = b.answerLines ? [...b.answerLines, "", ...text.split("\n")] : text.split("\n");
      continue;
    }
    if (line === "") {
      const c2 = cur();
      if (c2 && c2.descLines.length) c2.descLines.push("");
      continue;
    }
    const h = HEADING.exec(line);
    if (h) {
      const level = h[1].length;
      const title = h[2].trim();
      if (level === 1 && !sawTitle && items.length === 0 && !cur()) {
        sawTitle = true;
        continue;
      }
      flush();
      while (headingStack.length && headingStack[headingStack.length - 1].level >= level) headingStack.pop();
      start(title, true, level, pathFor());
      headingStack.push({ level, title });
      continue;
    }
    const opt = OPTION.exec(line);
    if (opt) {
      (cur() ?? start("Options", false, 1, pathFor())).options.push(optionFromText(opt[2], opt[1] !== " "));
      continue;
    }
    const bold = BOLD_LINE.exec(line);
    if (bold) {
      const c2 = cur();
      start(bold[1].trim(), false, childLevel(c2), childPath(c2));
      continue;
    }
    if (TABLE_SEP.test(line)) continue;
    const table = TABLE_ROW.exec(line);
    if (table) {
      const cells = table[1].split("|").map((c2) => c2.trim());
      if (cells.length >= 2 && cells[0] && cells[1]) {
        const key = cleanKey(cells[0]);
        const value = cells[1].replace(/^`(.*)`$/, "$1");
        const header = /^(key|field|name|question)$/i.test(key) && /^(value|answer)$/i.test(value);
        if (!header) {
          const c2 = cur();
          const b = start(key, false, childLevel(c2), childPath(c2));
          b.answerLines = [value];
          flush();
        }
      }
      continue;
    }
    const isBullet = /^(?:[-*+]|\d+[.)])\s+/.test(line);
    const kv = KV.exec(line);
    if (kv && looksLikeKey(cleanKey(kv[1]), isBullet)) {
      const key = cleanKey(kv[1]);
      let value = kv[2].trim().replace(/^`(.*)`$/, "$1");
      const c2 = cur();
      const path = childPath(c2), level = childLevel(c2);
      if (value === "" || value === "|" || value === ">") {
        const parts = [];
        const baseIndent = raw.length - raw.trimStart().length;
        while (i + 1 < lines.length) {
          const next = lines[i + 1];
          const nt = next.trim();
          if (nt === "") {
            if (parts.length) parts.push("");
            i++;
            continue;
          }
          const ni = next.length - next.trimStart().length;
          if (ni <= baseIndent || HEADING.test(nt)) break;
          parts.push(nt);
          i++;
        }
        while (parts.length && parts[parts.length - 1] === "") parts.pop();
        value = parts.join("\n");
        if (!value) {
          start(key, false, level, path);
          continue;
        }
      }
      const b = start(key, false, level, path);
      b.answerLines = value.split("\n");
      flush();
      continue;
    }
    const bullet = BULLET.exec(line);
    if (bullet) {
      (cur() ?? start("Options", false, 1, pathFor())).options.push(optionFromText(bullet[1], false));
      continue;
    }
    const c = cur();
    if (!c) start(line.replace(/:\s*$/, ""), false, 1, pathFor());
    else c.descLines.push(line);
  }
  flush();
  return items;
}
async function hashString(s) {
  if (typeof crypto !== "undefined" && crypto.subtle) {
    const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
    return Array.from(new Uint8Array(buf).slice(0, 8), (b) => b.toString(16).padStart(2, "0")).join("");
  }
  let h = 0;
  for (let i = 0; i < s.length; i++) h = h * 31 + s.charCodeAt(i) | 0;
  return (h >>> 0).toString(16);
}
async function buildProfile(md2) {
  return { hash: await hashString(md2), items: parseMarkdown(md2) };
}

// src/types.ts
var DEFAULT_SETTINGS = { overwrite: false, semantic: true, fillChoices: false };
var STORAGE_KEYS = {
  markdown: "markdown",
  profile: "profile",
  profileEmbeddings: "profileEmbeddings",
  settings: "settings",
  modelStatus: "modelStatus",
  lastResult: "lastResult"
};

// src/options.ts
var EXAMPLE = `# Questions to answer

## Submitter Questions

### What is your analysis of the task you downloaded above?

Select the option that best describes the task you reviewed.

- [x] **Fixable** (The task has issues but you can correct all of them)
- [ ] **Valid as-is** (The task is valid without changes)
- [ ] **Suspected too easy** (The task may not be challenging enough)

**Task Type** (required)

- [ ] Feature
- [x] Fix

### Files Changed - List every file you changed.
For each file, include: file path, what changed, why you changed it

\`\`\`
task/instruction.md
Rewritten in symptom and goal language.

task/tests/verify/verify.py
Added one regression test.
\`\`\`

### Instructions - Required confirmations
You must select all for the task to be valid

[x] instruction.md was fully rewritten.
[x] The rewrite preserves the same technical meaning.

Findings (optional)
\`\`\`
The old prompt leaked the root cause; the new one states the symptom only.
\`\`\`

Edits made (optional)
\`\`\`
Full rewrite, see Files Changed.
\`\`\`

### How long (in minutes) did it take you to complete this entire submission?

\`\`\`
240
\`\`\`

## Profile-style answers also work
- First Name: Jane
- Email: jane.doe@example.com
- Newsletter: no
`;
var $ = (id) => document.getElementById(id);
var md = $("md");
var saveStatus = $("saveStatus");
var count = $("count");
var previewBody = document.querySelector("#preview tbody");
var semantic = $("semantic");
var overwrite = $("overwrite");
var fillChoices = $("fillChoices");
var modelStatus = $("modelStatus");
var modelBar = $("modelBar");
function renderPreview(profile) {
  previewBody.replaceChildren();
  const items = profile?.items ?? [];
  count.textContent = items.length ? `(${items.length})` : "(none)";
  for (const it of items) {
    const tr = document.createElement("tr");
    const ctx = document.createElement("td");
    ctx.className = "ctx";
    ctx.textContent = it.path;
    const key = document.createElement("td");
    key.textContent = it.title + (it.aliases.length ? ` / ${it.aliases.join(" / ")}` : "");
    const val = document.createElement("td");
    val.className = "val";
    if (it.options) {
      val.textContent = it.options.map((o) => `${o.checked ? "\u2611" : "\u2610"} ${o.short || o.label}`).join("\n") + (it.answer ? `
${it.answer}` : "");
    } else {
      val.textContent = it.answer ?? "";
    }
    tr.append(ctx, key, val);
    previewBody.append(tr);
  }
}
function renderModel(s) {
  const st = s ?? { state: "idle" };
  modelStatus.className = "status" + (st.state === "ready" ? " ok" : st.state === "error" ? " err" : "");
  const label = { idle: "not loaded", loading: "loading", ready: "ready", error: "error" }[st.state];
  modelStatus.textContent = `Model: ${label}${st.message ? ` \u2013 ${st.message}` : ""}`;
  modelBar.style.width = st.state === "loading" ? `${st.progress ?? 0}%` : st.state === "ready" ? "100%" : "0";
}
async function saveSettings() {
  const s = { semantic: semantic.checked, overwrite: overwrite.checked, fillChoices: fillChoices.checked };
  await chrome.storage.local.set({ [STORAGE_KEYS.settings]: s });
}
async function save() {
  const text = md.value;
  const profile = await buildProfile(text);
  await chrome.storage.local.set({ [STORAGE_KEYS.markdown]: text, [STORAGE_KEYS.profile]: profile });
  renderPreview(profile);
  saveStatus.className = "status ok";
  saveStatus.textContent = `Saved ${profile.items.length} answer${profile.items.length === 1 ? "" : "s"}.`;
  setTimeout(() => saveStatus.textContent = "", 3e3);
  if (profile.items.length && semantic.checked) {
    chrome.runtime.sendMessage({ target: "background", type: "profile-saved" }).catch(() => {
    });
  }
}
var previewTimer;
md.addEventListener("input", () => {
  clearTimeout(previewTimer);
  previewTimer = setTimeout(async () => renderPreview(await buildProfile(md.value)), 200);
});
$("save").addEventListener("click", () => void save());
$("example").addEventListener("click", () => {
  if (md.value.trim() && !confirm("Replace the current text with the example?")) return;
  md.value = EXAMPLE;
  md.dispatchEvent(new Event("input"));
});
semantic.addEventListener("change", () => void saveSettings());
overwrite.addEventListener("change", () => void saveSettings());
fillChoices.addEventListener("change", () => void saveSettings());
$("warm").addEventListener("click", async () => {
  const btn = $("warm");
  btn.disabled = true;
  try {
    const res = await chrome.runtime.sendMessage({ target: "background", type: "warm-up" });
    if (res?.error) renderModel({ state: "error", message: res.error });
  } finally {
    btn.disabled = false;
  }
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes[STORAGE_KEYS.modelStatus]) renderModel(changes[STORAGE_KEYS.modelStatus].newValue);
});
(async () => {
  const r = await chrome.storage.local.get([STORAGE_KEYS.markdown, STORAGE_KEYS.profile, STORAGE_KEYS.settings, STORAGE_KEYS.modelStatus]);
  md.value = r[STORAGE_KEYS.markdown] || "";
  const stored = r[STORAGE_KEYS.profile];
  renderPreview(stored?.items ? stored : md.value ? await buildProfile(md.value) : null);
  const s = { ...DEFAULT_SETTINGS, ...r[STORAGE_KEYS.settings] || {} };
  semantic.checked = s.semantic;
  overwrite.checked = s.overwrite;
  fillChoices.checked = s.fillChoices;
  renderModel(r[STORAGE_KEYS.modelStatus]);
})();
