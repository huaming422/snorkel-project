"use strict";
(() => {
  // src/fieldUtils.ts
  var SKIP_INPUT_TYPES = /* @__PURE__ */ new Set(["hidden", "password", "submit", "button", "reset", "image", "file", "color", "range", "search"]);
  var CONTROL_SEL = 'input, textarea, select, [contenteditable="true"], [contenteditable=""], [role="textbox"], [role="combobox"], [role="checkbox"], [role="radio"], [role="switch"]';
  var TEXT_CONTROL_SEL = 'input:not([type=checkbox]):not([type=radio]):not([type=hidden]), textarea, select, [contenteditable="true"], [contenteditable=""], [role="textbox"], [role="combobox"]';
  function clean(s) {
    return (s || "").replace(/<[^>]+>/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&#39;|&apos;/g, "'").replace(/&quot;/g, '"').replace(/&nbsp;/g, " ").replace(/\s+/g, " ").replace(/^[\s:*•·-]+|[\s:*•·-]+$/g, "").trim();
  }
  function isVisible(el) {
    if (!el.isConnected) return false;
    if (el.getClientRects().length === 0) return false;
    const style = getComputedStyle(el);
    return style.visibility !== "hidden" && style.display !== "none" && style.opacity !== "0";
  }
  function elementText(el) {
    const clone = el.cloneNode(true);
    clone.querySelectorAll('input, select, textarea, button, script, style, svg, [role="toolbar"]').forEach((n) => n.remove());
    return clean(clone.textContent);
  }
  function labelsFor(el) {
    const out = [];
    let node = el;
    for (let d = 0; d < 6 && node; d++, node = node.parentElement) {
      if (node.id) {
        for (const l of Array.from(document.querySelectorAll("label[for]"))) {
          if (l.htmlFor === node.id) out.push(l);
        }
      }
    }
    return out;
  }
  function labelOf(el) {
    const parts = [];
    const native = el;
    if (native.labels) for (const l of Array.from(native.labels)) parts.push(elementText(l));
    else for (const l of labelsFor(el)) parts.push(elementText(l));
    if (!parts.length) {
      const wrapping = el.closest("label");
      if (wrapping) parts.push(elementText(wrapping));
    }
    const aria = el.getAttribute("aria-label");
    if (aria) parts.push(clean(aria));
    const by = el.getAttribute("aria-labelledby");
    if (by) for (const id of by.split(/\s+/)) {
      const n = document.getElementById(id);
      if (n) parts.push(elementText(n));
    }
    const seen = /* @__PURE__ */ new Set();
    return parts.filter((p) => p && !seen.has(p.toLowerCase()) && seen.add(p.toLowerCase())).join(" ");
  }
  function nearbyText(el) {
    let node = el;
    for (let depth = 0; depth < 4 && node; depth++) {
      let sib = node.previousSibling;
      let hops = 0;
      while (sib && hops < 4) {
        let text = "";
        if (sib.nodeType === Node.TEXT_NODE) text = sib.textContent || "";
        else if (sib.nodeType === Node.ELEMENT_NODE) {
          const e = sib;
          if (!e.matches("input, select, textarea, button, script, style, svg, br, hr") && !e.querySelector(CONTROL_SEL)) text = e.innerText || e.textContent || "";
        }
        const c = clean(text);
        if (c && c.length <= 120) return c;
        sib = sib.previousSibling;
        hops++;
      }
      node = node.parentElement;
      if (node && node.matches("form, body, fieldset, table, ul, ol")) break;
    }
    const legend = el.closest("fieldset")?.querySelector(":scope > legend");
    return legend ? clean(legend.textContent).slice(0, 120) : "";
  }
  function groupLabelCandidates(container, before) {
    return Array.from(container.querySelectorAll('label, legend, h1, h2, h3, h4, h5, h6, [role="heading"]')).filter(
      (l) => !l.querySelector(CONTROL_SEL) && !l.contains(before) && (l.compareDocumentPosition(before) & Node.DOCUMENT_POSITION_FOLLOWING) !== 0
    );
  }
  function groupContainer(el) {
    let node = el.parentElement;
    for (let d = 0; d < 8 && node && node !== document.body; d++, node = node.parentElement) {
      if (node.querySelector(TEXT_CONTROL_SEL)) return null;
      const cands = groupLabelCandidates(node, el);
      if (cands.length) return { container: node, label: elementText(cands[0]) };
    }
    return null;
  }
  function descriptionOf(el, labelText) {
    const container = el.closest('[data-testid^="field"], [class*="field"], [class*="form-group"], [class*="question"], fieldset, li') || el.parentElement?.parentElement;
    if (!container) return "";
    const clone = container.cloneNode(true);
    clone.querySelectorAll(`${CONTROL_SEL}, label, legend, button, [role="toolbar"], script, style, svg`).forEach((n) => n.remove());
    let text = clean(clone.textContent);
    if (labelText) text = text.replace(labelText, " ");
    text = clean(text);
    return text.length > 400 ? "" : text;
  }
  function kindOfNative(el) {
    if (el instanceof HTMLTextAreaElement) return "textarea";
    if (el instanceof HTMLSelectElement) return "select";
    const type = (el.type || "text").toLowerCase();
    if (SKIP_INPUT_TYPES.has(type)) return null;
    if (type === "checkbox") return "checkbox";
    if (type === "radio") return "radiogroup";
    if (type === "date" || type === "month" || type === "datetime-local") return "date";
    return "text";
  }
  function selectIsEmpty(el) {
    if (el.selectedIndex < 0) return true;
    const opt = el.options[el.selectedIndex];
    return !opt || opt.value === "" || el.selectedIndex === 0;
  }
  function isChecked(el) {
    if (el instanceof HTMLInputElement) return el.checked;
    return el.getAttribute("aria-checked") === "true" || el.getAttribute("aria-pressed") === "true" || el.getAttribute("data-state") === "checked";
  }
  function pointerSequence(el) {
    const rect = el.getBoundingClientRect();
    const init = { bubbles: true, cancelable: true, composed: true, clientX: rect.left + rect.width / 2, clientY: rect.top + rect.height / 2, button: 0, buttons: 1 };
    el.dispatchEvent(new PointerEvent("pointerdown", { ...init, pointerId: 1, pointerType: "mouse", isPrimary: true }));
    el.dispatchEvent(new MouseEvent("mousedown", init));
    el.dispatchEvent(new PointerEvent("pointerup", { ...init, buttons: 0, pointerId: 1, pointerType: "mouse", isPrimary: true }));
    el.dispatchEvent(new MouseEvent("mouseup", { ...init, buttons: 0 }));
    el.dispatchEvent(new MouseEvent("click", { ...init, buttons: 0, detail: 1 }));
  }
  async function toggle(el) {
    const before = isChecked(el);
    const settle = () => new Promise((r) => setTimeout(r, 30));
    const changed = async () => {
      await settle();
      return isChecked(el) !== before;
    };
    if (el instanceof HTMLInputElement) {
      el.click();
      if (await changed()) return true;
      el.checked = !before;
      fire(el, ["input", "change"]);
      return isChecked(el) !== before;
    }
    el.click();
    if (await changed()) return true;
    pointerSequence(el);
    if (await changed()) return true;
    const card = el.closest('label, button, [class*="cursor-pointer"]') || el.parentElement;
    if (card && card !== el) {
      pointerSequence(card);
      if (await changed()) return true;
    }
    el.focus();
    el.dispatchEvent(new KeyboardEvent("keydown", { key: " ", code: "Space", bubbles: true, cancelable: true }));
    el.dispatchEvent(new KeyboardEvent("keyup", { key: " ", code: "Space", bubbles: true, cancelable: true }));
    if (await changed()) return true;
    el.setAttribute("aria-checked", String(!before));
    fire(el, ["change"]);
    return isChecked(el) !== before;
  }
  function optionLabel(el) {
    if (el instanceof HTMLInputElement) return labelOf(el) || clean(el.value);
    const aria = el.getAttribute("aria-label");
    return clean(aria) || elementText(el) || labelOf(el);
  }
  function richTextIsEmpty(el) {
    return clean(el.textContent) === "";
  }
  function collectFields(root, overwrite) {
    const fields = [];
    const targets = [];
    const groups = /* @__PURE__ */ new Map();
    const seen = /* @__PURE__ */ new Set();
    const push = (d, t) => {
      fields.push({ ...d, index: fields.length });
      targets.push(t);
    };
    const all = Array.from(root.querySelectorAll(CONTROL_SEL));
    for (const el of all) {
      if (seen.has(el)) continue;
      if (!isVisible(el)) continue;
      if (el.closest('[role="toolbar"]')) continue;
      if (el.disabled || el.getAttribute("aria-disabled") === "true") continue;
      if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || el instanceof HTMLSelectElement) {
        const kind = kindOfNative(el);
        if (!kind || el.readOnly) continue;
        if (kind === "radiogroup" || kind === "checkbox") {
          const input = el;
          if (kind === "radiogroup") {
            const key = `radio::${input.form && (input.form.id || input.form.name) || ""}::${input.name || input.id}`;
            const g = groups.get(key) || { kind: "radiogroup", label: "", els: [], first: input };
            g.els.push(input);
            groups.set(key, g);
            continue;
          }
          const gc = groupContainer(input);
          if (gc) {
            const g = groups.get(gc.container) || { kind: "checkgroup", label: gc.label, els: [], first: input };
            g.els.push(input);
            groups.set(gc.container, g);
            continue;
          }
          if (!overwrite && input.checked) continue;
          const label2 = labelOf(input);
          push({ kind: "checkbox", label: label2, description: "", placeholder: "", name: input.name, id: input.id, autocomplete: "", nearby: label2 ? "" : nearbyText(input), options: [label2], checked: [input.checked] }, { kind: "control", el: input });
          continue;
        }
        if (!overwrite) {
          if (kind === "select" && !selectIsEmpty(el)) continue;
          if (kind !== "select" && el.value.trim() !== "") continue;
        }
        const label = labelOf(el);
        const d = {
          kind,
          label,
          description: descriptionOf(el, label),
          placeholder: clean(el.getAttribute("placeholder") || el.getAttribute("title")),
          name: el.name || "",
          id: el.id || "",
          autocomplete: el.getAttribute("autocomplete") || "",
          nearby: label ? "" : nearbyText(el)
        };
        if (kind === "select") d.options = Array.from(el.options).map((o) => clean(o.textContent)).filter(Boolean).slice(0, 300);
        push(d, { kind: "control", el });
        continue;
      }
      const role = el.getAttribute("role");
      if (role === "checkbox" || role === "radio" || role === "switch") {
        const gc = groupContainer(el);
        if (gc) {
          const g = groups.get(gc.container) || { kind: role === "radio" ? "radiogroup" : "checkgroup", label: gc.label, els: [], first: el };
          g.els.push(el);
          groups.set(gc.container, g);
        } else {
          if (!overwrite && isChecked(el)) continue;
          const label = optionLabel(el);
          push({ kind: "checkbox", label, description: "", placeholder: "", name: "", id: el.id, autocomplete: "", nearby: label ? "" : nearbyText(el), options: [label], checked: [isChecked(el)] }, { kind: "group", els: [el] });
        }
        continue;
      }
      if (role === "combobox" && !(el instanceof HTMLInputElement)) {
        const label = labelOf(el);
        const current = clean(el.textContent);
        if (!overwrite && current && !/^(select|choose|pick)/i.test(current)) continue;
        push({ kind: "combobox", label, description: descriptionOf(el, label), placeholder: current, name: "", id: el.id, autocomplete: "", nearby: label ? "" : nearbyText(el) }, { kind: "combobox", el });
        continue;
      }
      if (el.isContentEditable || role === "textbox") {
        if (el.closest('[contenteditable="true"]') !== el && el.closest('[contenteditable="true"]')) continue;
        if (!overwrite && !richTextIsEmpty(el)) continue;
        const label = labelOf(el);
        push({ kind: "richtext", label, description: descriptionOf(el, label), placeholder: clean(el.getAttribute("data-placeholder") || el.getAttribute("aria-placeholder")), name: "", id: el.id, autocomplete: "", nearby: label ? "" : nearbyText(el) }, { kind: "richtext", el });
        seen.add(el);
        continue;
      }
    }
    for (const g of groups.values()) {
      const checked = g.els.map(isChecked);
      if (!overwrite && checked.some(Boolean)) continue;
      let label = g.label;
      const first = g.first;
      if (!label) {
        const legend = first.closest("fieldset")?.querySelector(":scope > legend");
        const rg = first.closest('[role="radiogroup"], [role="group"]');
        const by = rg?.getAttribute("aria-labelledby");
        label = legend ? clean(legend.textContent) : by ? clean(document.getElementById(by)?.textContent) : clean(rg?.getAttribute("aria-label"));
      }
      push(
        {
          kind: g.kind,
          label,
          description: descriptionOf(first, label),
          placeholder: "",
          name: first instanceof HTMLInputElement ? first.name : "",
          id: "",
          autocomplete: first.getAttribute("autocomplete") || "",
          nearby: label ? "" : nearbyText(first.closest('fieldset, [role="radiogroup"], [role="group"]') || first.parentElement || first),
          options: g.els.map(optionLabel),
          checked
        },
        { kind: "group", els: g.els }
      );
    }
    return { fields, targets };
  }
  function fire(el, names) {
    for (const n of names) {
      const ev = n === "focus" || n === "blur" ? new FocusEvent(n) : new Event(n, { bubbles: true, cancelable: true });
      el.dispatchEvent(ev);
    }
  }
  function highlight(target) {
    const els = target.kind === "group" ? target.els : [target.el];
    for (const el of els) {
      const prev = el.style.outline, prevOffset = el.style.outlineOffset;
      el.style.outline = "2px solid #2563eb";
      el.style.outlineOffset = "1px";
      setTimeout(() => {
        el.style.outline = prev;
        el.style.outlineOffset = prevOffset;
      }, 2500);
    }
  }
  function showToast(message, kind = "info") {
    const id = "md-autofill-toast";
    document.getElementById(id)?.remove();
    const div = document.createElement("div");
    div.id = id;
    div.textContent = message;
    Object.assign(div.style, {
      position: "fixed",
      right: "16px",
      bottom: "16px",
      zIndex: "2147483647",
      background: kind === "error" ? "#b91c1c" : "#1e293b",
      color: "#fff",
      padding: "10px 14px",
      borderRadius: "8px",
      font: "13px/1.4 system-ui, sans-serif",
      boxShadow: "0 4px 16px rgba(0,0,0,.25)",
      maxWidth: "360px",
      pointerEvents: "none"
    });
    (document.body || document.documentElement).appendChild(div);
    setTimeout(() => div.remove(), kind === "error" ? 7e3 : 4e3);
  }

  // src/checkall.ts
  if (!window.__mdAutofillListening) {
    window.__mdAutofillListening = true;
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg?.target !== "content") return;
      if (msg.type === "summary" && window === window.top) {
        const { filled = 0, total = 0 } = msg;
        const verb = msg.action === "clear" ? "cleared" : msg.action === "check-all" ? "checked" : "filled";
        const noun = msg.action === "check-all" ? "boxes" : "fields";
        showToast(total === 0 ? `MD Autofill: no ${noun} found on this page.` : `MD Autofill: ${verb} ${filled} of ${total} ${noun}.`);
      }
    });
  }
  async function run() {
    if (window.__mdAutofillChecking) return;
    window.__mdAutofillChecking = true;
    let checked = 0;
    let total = 0;
    try {
      const collected = collectFields(document, true);
      for (let i = 0; i < collected.fields.length; i++) {
        const f = collected.fields[i];
        if (f.kind !== "checkbox" && f.kind !== "checkgroup") continue;
        const t = collected.targets[i];
        const els = t.kind === "group" ? t.els : [t.el];
        for (const el of els) {
          total++;
          if (isChecked(el)) continue;
          try {
            if (await toggle(el)) {
              checked++;
              highlight({ kind: "group", els: [el] });
            } else {
              console.warn("[MD Autofill] checkbox did not react to click", el);
            }
          } catch (err) {
            console.warn("[MD Autofill] failed to check", el, err);
          }
        }
      }
      await chrome.runtime.sendMessage({ target: "background", type: "frame-result", filled: checked, total, assignments: [], unmatched: [] });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      if (window === window.top) showToast(`MD Autofill: ${message}`, "error");
      try {
        await chrome.runtime.sendMessage({ target: "background", type: "frame-result", filled: checked, total, assignments: [], unmatched: [], error: message });
      } catch {
      }
    } finally {
      window.__mdAutofillChecking = false;
    }
  }
  void run();
})();
