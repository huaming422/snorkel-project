// src/types.ts
var DEFAULT_SETTINGS = { overwrite: false, semantic: true, fillChoices: false };
var STORAGE_KEYS = {
  markdown: "markdown",
  profile: "profile",
  profileEmbeddings: "profileEmbeddings",
  settings: "settings",
  modelStatus: "modelStatus",
  lastResult: "lastResult"
};

// src/popup.ts
var $ = (id) => document.getElementById(id);
var fillBtn = $("fill");
var overwrite = $("overwrite");
var profileEl = $("profile");
var modelEl = $("model");
var bar = $("bar");
var resultEl = $("result");
var summary = $("summary");
var list = $("list");
function renderModel(s) {
  const st = s ?? { state: "idle" };
  const label = { idle: "not loaded", loading: `loading ${st.progress ?? 0}%`, ready: "ready", error: "error" }[st.state];
  modelEl.textContent = `Model: ${label}`;
  modelEl.className = st.state === "ready" ? "ok" : st.state === "error" ? "err" : "";
  modelEl.title = st.message || "";
  bar.style.width = st.state === "loading" ? `${st.progress ?? 0}%` : "0";
}
function renderResult(r) {
  if (!r) {
    resultEl.hidden = true;
    return;
  }
  resultEl.hidden = false;
  const when = new Date(r.time).toLocaleTimeString();
  const verb = r.action === "clear" ? "Cleared" : r.action === "check-all" ? "Checked" : "Filled";
  const noun = r.action === "check-all" ? "boxes" : "fields";
  summary.textContent = r.error ? `Error (${when}): ${r.error}` : `${verb} ${r.filled} of ${r.total} ${noun} (${when})`;
  summary.className = r.error ? "err" : "";
  list.replaceChildren();
  for (const a of r.assignments.slice(0, 40)) {
    const li = document.createElement("li");
    const m = document.createElement("span");
    m.className = "m";
    m.textContent = `${a.method} ${a.score.toFixed(2)}`;
    const f = document.createElement("span");
    f.className = "f";
    f.textContent = a.fieldText.split(" | ")[0] || a.fieldText;
    const shown = a.value !== void 0 ? a.value : (a.optionStates || []).map((s, i) => s === true ? `\u2611${i + 1}` : s === false ? `\u2610${i + 1}` : "").filter(Boolean).join(" ");
    const k = document.createElement("span");
    k.className = "k";
    k.textContent = `\u2190 ${a.key}: ${shown.length > 40 ? shown.slice(0, 40) + "\u2026" : shown}`;
    li.append(m, f, k);
    list.append(li);
  }
  const wrap = $("unmatchedWrap");
  const ul = $("unmatched");
  ul.replaceChildren();
  const un = r.unmatched || [];
  wrap.hidden = un.length === 0;
  for (const u of un.slice(0, 20)) {
    const li = document.createElement("li");
    const f = document.createElement("span");
    f.className = "f";
    f.textContent = u.fieldText.split(" | ")[0] || u.fieldText;
    li.append(f);
    if (u.bestKey) {
      const k = document.createElement("span");
      k.className = "k";
      k.textContent = `closest: ${u.bestKey} (${(u.bestScore ?? 0).toFixed(2)})`;
      li.append(k);
    }
    ul.append(li);
  }
}
fillBtn.addEventListener("click", async () => {
  fillBtn.disabled = true;
  fillBtn.textContent = "Filling\u2026";
  try {
    const r = await chrome.runtime.sendMessage({ target: "background", type: "fill" });
    if (r && "assignments" in r) renderResult(r);
    else renderResult({ url: "", time: Date.now(), filled: 0, total: 0, assignments: [], unmatched: [], error: r && "error" in r ? r.error : "No response from the extension. Reload it at chrome://extensions and reload the page." });
  } finally {
    fillBtn.disabled = false;
    fillBtn.textContent = "Fill this page";
  }
});
var clearBtn = $("clear");
clearBtn.addEventListener("click", async () => {
  if (!confirm("Clear every field on this page? Text fields and rich-text editors are emptied, checkboxes unchecked and selects reset.")) return;
  clearBtn.disabled = true;
  clearBtn.textContent = "Clearing\u2026";
  try {
    const r = await chrome.runtime.sendMessage({ target: "background", type: "clear" });
    if (r && "assignments" in r) renderResult(r);
    else renderResult({ url: "", time: Date.now(), action: "clear", filled: 0, total: 0, assignments: [], unmatched: [], error: r && "error" in r ? r.error : "No response from the extension. Reload it at chrome://extensions and reload the page." });
  } finally {
    clearBtn.disabled = false;
    clearBtn.textContent = "Clear this page";
  }
});
var checkAllBtn = $("checkAll");
checkAllBtn.addEventListener("click", async () => {
  checkAllBtn.disabled = true;
  checkAllBtn.textContent = "Checking\u2026";
  try {
    const r = await chrome.runtime.sendMessage({ target: "background", type: "check-all" });
    if (r && "assignments" in r) renderResult(r);
    else renderResult({ url: "", time: Date.now(), action: "check-all", filled: 0, total: 0, assignments: [], unmatched: [], error: r && "error" in r ? r.error : "No response from the extension. Reload it at chrome://extensions and reload the page." });
  } finally {
    checkAllBtn.disabled = false;
    checkAllBtn.textContent = "Check all boxes";
  }
});
var fillChoices = $("fillChoices");
async function patchSettings(patch) {
  const r = await chrome.storage.local.get(STORAGE_KEYS.settings);
  const s = { ...DEFAULT_SETTINGS, ...r[STORAGE_KEYS.settings] || {}, ...patch };
  await chrome.storage.local.set({ [STORAGE_KEYS.settings]: s });
}
overwrite.addEventListener("change", () => void patchSettings({ overwrite: overwrite.checked }));
fillChoices.addEventListener("change", () => void patchSettings({ fillChoices: fillChoices.checked }));
$("options").addEventListener("click", (e) => {
  e.preventDefault();
  void chrome.runtime.openOptionsPage();
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes[STORAGE_KEYS.modelStatus]) renderModel(changes[STORAGE_KEYS.modelStatus].newValue);
  if (changes[STORAGE_KEYS.lastResult]) renderResult(changes[STORAGE_KEYS.lastResult].newValue);
});
(async () => {
  const r = await chrome.storage.local.get([STORAGE_KEYS.profile, STORAGE_KEYS.settings, STORAGE_KEYS.modelStatus, STORAGE_KEYS.lastResult]);
  const profile = r[STORAGE_KEYS.profile];
  const n = profile?.items?.length ?? 0;
  profileEl.textContent = n ? `Markdown: ${n} answers` : "Markdown: none (click Edit profile)";
  profileEl.className = n ? "" : "err";
  fillBtn.disabled = !n;
  const s = { ...DEFAULT_SETTINGS, ...r[STORAGE_KEYS.settings] || {} };
  overwrite.checked = s.overwrite;
  fillChoices.checked = s.fillChoices;
  renderModel(r[STORAGE_KEYS.modelStatus]);
  renderResult(r[STORAGE_KEYS.lastResult]);
})();
