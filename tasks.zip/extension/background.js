// src/matcher.ts
var ACCEPT_THRESHOLD = 0.5;
var MUTUAL_MARGIN = 0.1;
var AUTOCOMPLETE_MAP = {
  "given-name": ["first name", "given name", "forename"],
  "additional-name": ["middle name"],
  "family-name": ["last name", "surname", "family name"],
  name: ["full name", "name"],
  "honorific-prefix": ["title", "prefix", "salutation"],
  email: ["email", "e-mail", "email address"],
  tel: ["phone", "telephone", "mobile", "phone number", "mobile number", "cell"],
  "tel-national": ["phone", "mobile"],
  "street-address": ["street", "address", "street address", "address line 1"],
  "address-line1": ["street", "address", "address line 1", "street address"],
  "address-line2": ["address line 2", "apartment", "apt", "suite"],
  "address-level2": ["city", "town"],
  "address-level1": ["state", "province", "region", "county"],
  "postal-code": ["zip", "zip code", "postcode", "postal code"],
  country: ["country"],
  "country-name": ["country"],
  organization: ["company", "organization", "organisation", "employer"],
  "organization-title": ["job title", "title", "position", "role"],
  bday: ["date of birth", "birthday", "dob", "birth date"],
  url: ["website", "url", "homepage", "portfolio"],
  username: ["username", "user name"],
  nickname: ["nickname"],
  sex: ["gender", "sex"],
  language: ["language"]
};
var SYNONYMS = {
  surname: "lastname",
  lastname: "lastname",
  family: "last",
  forename: "firstname",
  firstname: "firstname",
  given: "first",
  "e-mail": "email",
  mail: "email",
  telephone: "phone",
  tel: "phone",
  mobile: "phone",
  cell: "phone",
  cellphone: "phone",
  zip: "postcode",
  zipcode: "postcode",
  postal: "postcode",
  organisation: "company",
  organization: "company",
  employer: "company",
  firm: "company",
  town: "city",
  province: "state",
  region: "state",
  dob: "birthdate",
  birthday: "birthdate",
  birth: "birthdate",
  website: "url",
  homepage: "url",
  position: "jobtitle",
  role: "jobtitle",
  addr: "address",
  street: "address"
};
var STOP = /* @__PURE__ */ new Set([
  "the",
  "your",
  "a",
  "an",
  "of",
  "please",
  "enter",
  "type",
  "required",
  "optional",
  "field",
  "input",
  "and",
  "or",
  "in",
  "to",
  "for",
  "label",
  "form",
  "number",
  "no",
  "current",
  "primary",
  "user",
  "customer",
  "applicant",
  "candidate",
  "contact",
  "data",
  "fields",
  "info",
  "details",
  "txt",
  "fld",
  // function words that would otherwise dilute token overlap
  "do",
  "does",
  "did",
  "us",
  "tell",
  "you",
  "we",
  "me",
  "my",
  "our",
  "is",
  "are",
  "be",
  "it",
  "this",
  "that",
  "these",
  "those",
  "with",
  "on",
  "at",
  "as",
  "by",
  "from",
  "have",
  "has",
  "had",
  "any",
  "all",
  "if"
]);
function humanize(s) {
  return (s || "").replace(/[\[\]_\-./:]+/g, " ").replace(/([a-z0-9])([A-Z])/g, "$1 $2").replace(/\s+/g, " ").trim().toLowerCase();
}
function normalize(s) {
  return humanize(s).replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
}
function tokens(s) {
  const out = [];
  for (const t of normalize(s).split(" ")) {
    if (!t) continue;
    const canon = SYNONYMS[t] ?? t;
    if (STOP.has(canon)) continue;
    out.push(canon);
  }
  const merged = [];
  for (let i = 0; i < out.length; i++) {
    const a = out[i], b = out[i + 1];
    if (a === "first" && b === "name") {
      merged.push("firstname");
      i++;
      continue;
    }
    if (a === "last" && b === "name") {
      merged.push("lastname");
      i++;
      continue;
    }
    if (a === "full" && b === "name") {
      merged.push("fullname");
      i++;
      continue;
    }
    if (a === "job" && b === "title") {
      merged.push("jobtitle");
      i++;
      continue;
    }
    if (a === "postcode" && b === "code") {
      merged.push("postcode");
      i++;
      continue;
    }
    if (a === "birthdate" && b === "date") {
      merged.push("birthdate");
      i++;
      continue;
    }
    if (a === "date" && b === "birthdate") {
      merged.push("birthdate");
      i++;
      continue;
    }
    if (a === "email" && b === "address") {
      merged.push("email");
      i++;
      continue;
    }
    if (a === "phone" && b === "number") {
      merged.push("phone");
      i++;
      continue;
    }
    merged.push(a);
  }
  return merged;
}
function dice(a, b) {
  if (!a.length || !b.length) return 0;
  const sa = new Set(a), sb = new Set(b);
  let inter = 0;
  for (const t of sa) if (sb.has(t)) inter++;
  return 2 * inter / (sa.size + sb.size);
}
function labelSim(a, b) {
  const na = normalize(a), nb = normalize(b);
  if (!na || !nb) return 0;
  if (na === nb) return 1;
  const ta = tokens(a), tb = tokens(b);
  if (!ta.length || !tb.length) return 0;
  if (ta.join(" ") === tb.join(" ")) return 0.97;
  let score = dice(ta, tb);
  const [short, long] = ta.length <= tb.length ? [ta, tb] : [tb, ta];
  if (short.every((t) => long.includes(t))) {
    const ratio = short.length / long.length;
    score = Math.max(score, short.length >= 2 ? 0.85 : long.length <= 2 ? 0.85 : long.length === 3 ? 0.6 : 0.45 + 0.3 * ratio);
  }
  if (na.length >= 6 && nb.length >= 6 && (na.includes(nb) || nb.includes(na))) score = Math.max(score, 0.8);
  return score;
}
function fieldCandidates(f) {
  const parts = [f.label, f.placeholder, f.nearby, humanize(f.name), humanize(f.id)].map((s) => (s || "").trim());
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const p of parts) {
    const n = normalize(p);
    if (!n || seen.has(n)) continue;
    seen.add(n);
    out.push(p);
  }
  return out;
}
function fieldText(f) {
  return fieldCandidates(f).join(" | ").slice(0, 200);
}
function fieldEmbedText(f) {
  const c = fieldCandidates(f);
  return c.slice(0, 2).join(", ").slice(0, 160) || "field";
}
function itemEmbedText(it) {
  return it.title.slice(0, 160);
}
function itemKey(it) {
  return it.path ? `${it.path} > ${it.title}` : it.title;
}
function cosine(a, b) {
  let dot = 0, na = 0, nb = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    na += a[i] * a[i];
    nb += b[i] * b[i];
  }
  return na && nb ? dot / Math.sqrt(na * nb) : 0;
}
function lexicalSim(f, it) {
  const names = [it.title, ...it.aliases || []];
  const ac = (f.autocomplete || "").toLowerCase().split(/\s+/).find((t) => AUTOCOMPLETE_MAP[t]);
  if (ac) {
    const wanted = AUTOCOMPLETE_MAP[ac].map((w) => tokens(w).join(" "));
    if (names.some((n) => wanted.includes(tokens(n).join(" ")))) return { score: 1, method: "autocomplete" };
  }
  let best = 0;
  const cands = fieldCandidates(f);
  cands.forEach((c, ci) => {
    const weight = ci === 0 ? 1 : 0.95;
    for (const n of names) best = Math.max(best, labelSim(c, n) * weight);
    if (it.path) best = Math.max(best, labelSim(c, `${it.path.split(" > ").pop()} ${it.title}`) * 0.9 * weight);
  });
  if (f.description && it.description) best = Math.min(1, best + 0.1 * labelSim(f.description, it.description));
  const method = best >= 0.97 ? "exact" : "fuzzy";
  return { score: Math.round(best * 1e3) / 1e3, method };
}
function buildSimMatrix(fields, items, fieldVecs, itemVecs) {
  return fields.map(
    (f, fi) => items.map((it, ii) => {
      const lex = lexicalSim(f, it);
      if (fieldVecs && itemVecs && fieldVecs[fi] && itemVecs[ii]) {
        const cos = Math.round(cosine(fieldVecs[fi], itemVecs[ii]) * 1e3) / 1e3;
        if (cos > lex.score) return { score: cos, method: "semantic" };
      }
      return lex;
    })
  );
}
function align(fields, items, sim, threshold = ACCEPT_THRESHOLD) {
  const n = fields.length, m = items.length;
  const fieldOf = /* @__PURE__ */ new Map();
  const usedItems = /* @__PURE__ */ new Set();
  const bestFor = (row) => {
    let b = -1, bs = -1, second = -1;
    row.forEach((c, i) => {
      if (c.score > bs) {
        second = bs;
        bs = c.score;
        b = i;
      } else if (c.score > second) second = c.score;
    });
    return { idx: b, score: bs, second };
  };
  const itemBest = [];
  for (let ii = 0; ii < m; ii++) itemBest.push(bestFor(fields.map((_, fi) => sim[fi][ii])));
  for (let fi = 0; fi < n; fi++) {
    const fb = bestFor(sim[fi]);
    if (fb.idx < 0 || fb.score < threshold) continue;
    const ib = itemBest[fb.idx];
    const fieldClear = fb.score - fb.second >= MUTUAL_MARGIN || fb.second < threshold;
    const itemClear = ib.idx === fi && (ib.score - ib.second >= MUTUAL_MARGIN || ib.second < threshold);
    if (fieldClear && itemClear) {
      fieldOf.set(fi, { ii: fb.idx, score: fb.score, method: sim[fi][fb.idx].method });
      usedItems.add(fb.idx);
    }
  }
  const freeF = [...Array(n).keys()].filter((fi) => !fieldOf.has(fi));
  const freeI = [...Array(m).keys()].filter((ii) => !usedItems.has(ii));
  if (freeF.length && freeI.length) {
    const F = freeF.length, I = freeI.length;
    const dp = Array.from({ length: F + 1 }, () => new Array(I + 1).fill(0));
    for (let a2 = 1; a2 <= F; a2++) {
      for (let b2 = 1; b2 <= I; b2++) {
        const s = sim[freeF[a2 - 1]][freeI[b2 - 1]].score;
        dp[a2][b2] = Math.max(dp[a2 - 1][b2], dp[a2][b2 - 1], s >= threshold ? dp[a2 - 1][b2 - 1] + s : -1);
      }
    }
    let a = F, b = I;
    while (a > 0 && b > 0) {
      const s = sim[freeF[a - 1]][freeI[b - 1]].score;
      if (s >= threshold && dp[a][b] === dp[a - 1][b - 1] + s) {
        const fi = freeF[a - 1], ii = freeI[b - 1];
        const cell = sim[fi][ii];
        fieldOf.set(fi, { ii, score: cell.score, method: cell.method === "exact" ? "order" : cell.method });
        usedItems.add(ii);
        a--;
        b--;
      } else if (dp[a - 1][b] >= dp[a][b - 1]) a--;
      else b--;
    }
  }
  const unmatched = [];
  for (let fi = 0; fi < n; fi++) {
    if (fieldOf.has(fi)) continue;
    const fb = bestFor(sim[fi]);
    if (fb.idx >= 0 && fb.score >= threshold) {
      fieldOf.set(fi, { ii: fb.idx, score: fb.score, method: sim[fi][fb.idx].method });
    } else {
      unmatched.push({ index: fields[fi].index, fieldText: fieldText(fields[fi]), bestKey: fb.idx >= 0 ? itemKey(items[fb.idx]) : void 0, bestScore: fb.idx >= 0 ? fb.score : void 0 });
    }
  }
  const pairs = [...fieldOf.entries()].map(([fi, v]) => ({ fi, ii: v.ii, score: v.score, method: v.method })).sort((x, y) => x.fi - y.fi);
  return { pairs, unmatched };
}
function matchOption(pageOptions, label, short) {
  let best = -1, bestScore = 0;
  pageOptions.forEach((po, i) => {
    const s = Math.max(labelSim(po, label), labelSim(po, short) * 0.95, normalize(po).startsWith(normalize(short)) && short.length >= 3 ? 0.9 : 0);
    if (s > bestScore) {
      bestScore = s;
      best = i;
    }
  });
  return bestScore >= 0.6 ? best : -1;
}
function truthy(v) {
  const s = v.trim().toLowerCase();
  if (["yes", "y", "true", "1", "on", "checked", "x", "\u2713", "\u2714"].includes(s)) return true;
  if (["no", "n", "false", "0", "off", "unchecked", ""].includes(s)) return false;
  return null;
}
function toAssignment(field, item, score, method) {
  const base = { index: field.index, itemIndex: item.index, score, method, fieldText: fieldText(field), key: itemKey(item) };
  const opts = item.options || [];
  const checkedOpts = opts.filter((o) => o.checked);
  switch (field.kind) {
    case "checkgroup":
    case "radiogroup": {
      const pageOpts = field.options || [];
      if (!pageOpts.length) return null;
      const states = new Array(pageOpts.length).fill(void 0);
      if (opts.length) {
        if (!checkedOpts.length) return null;
        let any = false;
        for (const o of opts) {
          const pi = matchOption(pageOpts, o.label, o.short);
          if (pi < 0) continue;
          states[pi] = field.kind === "radiogroup" ? o.checked ? true : states[pi] : o.checked;
          if (o.checked) any = true;
        }
        if (!any) return null;
        if (field.kind === "checkgroup") {
          for (let i = 0; i < states.length; i++) if (states[i] === void 0) states[i] = false;
        }
      } else if (item.answer) {
        const t = truthy(item.answer);
        if (t !== null && pageOpts.length === 1) {
          states[0] = t;
        } else {
          const pi = matchOption(pageOpts, item.answer, item.answer);
          if (pi < 0) return null;
          states[pi] = true;
          if (field.kind === "checkgroup") {
            for (let i = 0; i < states.length; i++) if (states[i] === void 0) states[i] = false;
          }
        }
      } else return null;
      return { ...base, optionStates: states };
    }
    case "checkbox": {
      let want = null;
      if (item.answer) want = truthy(item.answer);
      else if (opts.length) want = checkedOpts.length > 0;
      if (want === null) return null;
      return { ...base, optionStates: [want] };
    }
    case "select":
    case "combobox": {
      const value = checkedOpts[0]?.label ?? item.answer;
      if (!value) return null;
      return { ...base, value };
    }
    default: {
      const value = item.answer ?? (checkedOpts.length ? checkedOpts.map((o) => o.label).join(", ") : void 0);
      if (value === void 0 || value === "") return null;
      return { ...base, value };
    }
  }
}

// src/parser.ts
var HEADING = /^(#{1,6})\s+(.+?)\s*#*\s*$/;
var FENCE = /^(```|~~~)\s*([\w+-]*)\s*$/;
var OPTION = /^(?:[-*+]\s+|\d+[.)]\s+)?\[([ xX])\]\s+(.+)$/;
var BULLET = /^(?:[-*+]|\d+[.)])\s+(.+)$/;
var BOLD_LINE = /^(?:\*\*|__)(.+?)(?:\*\*|__)\s*(\(.*?\))?\s*:?\s*$/;
var KV = /^(?:[-*+]\s+|\d+[.)]\s+)?(?:\*\*|__)?([^:*_\s][^:]{0,60}?)(?:\*\*|__)?\s*:\s*(.*)$/;
var TABLE_ROW = /^\|(.+)\|\s*$/;
var TABLE_SEP = /^\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/;
function cleanKey(k) {
  return k.replace(/^[\s*_`]+|[\s*_`]+$/g, "").trim();
}
function splitAliases(rawKey) {
  const parts = rawKey.split(/\s+\/\s+/).map(cleanKey).filter(Boolean);
  const key = parts.shift() || cleanKey(rawKey);
  const seen = /* @__PURE__ */ new Set([key.toLowerCase()]);
  const aliases = parts.filter((p) => !seen.has(p.toLowerCase()) && seen.add(p.toLowerCase()));
  return { key, aliases };
}
function optionFromText(text, checked) {
  const t = text.trim();
  const bold = /^(?:\*\*|__)(.+?)(?:\*\*|__)/.exec(t);
  const label = t.replace(/\*\*|__|`/g, "").replace(/\s+/g, " ").trim();
  return { label, short: bold ? bold[1].trim() : label.replace(/\s*\(.*\)\s*$/, "").trim(), checked };
}
function looksLikeKey(rawKey, isBullet) {
  const key = splitAliases(rawKey).key;
  if (!key || key.length > (isBullet ? 80 : 40)) return false;
  if (/[.,;!?]/.test(key)) return false;
  if (!isBullet && key.split(/\s+/).length > 5) return false;
  return true;
}
function parseMarkdown(md) {
  const lines = md.replace(/\r\n?/g, "\n").split("\n");
  const items = [];
  const headingStack = [];
  const state = { current: null };
  let sawTitle = false;
  const cur = () => state.current;
  const flush = () => {
    const b = state.current;
    if (!b) return;
    state.current = null;
    const hasAnswer = b.answerLines !== null && b.answerLines.join("\n").trim() !== "";
    const hasOptions = b.options.length > 0;
    const desc = b.descLines.join("\n").trim();
    let answer = hasAnswer ? b.answerLines.join("\n").replace(/\s+$/, "") : void 0;
    let description = desc;
    if (!hasAnswer && !hasOptions && desc && !b.isHeading) {
      answer = desc;
      description = "";
    }
    if (answer === void 0 && !hasOptions) return;
    items.push({
      index: items.length,
      title: b.title,
      aliases: b.aliases,
      path: b.path.join(" > "),
      description,
      answer,
      options: hasOptions ? b.options : void 0
    });
  };
  const start = (rawTitle, isHeading, level, path) => {
    flush();
    const { key, aliases } = splitAliases(rawTitle);
    const b = { title: key, aliases, path, descLines: [], answerLines: null, options: [], isHeading, level };
    state.current = b;
    return b;
  };
  const pathFor = () => headingStack.map((h) => h.title);
  const childPath = (b) => b ? b.isHeading ? [...b.path, b.title] : b.path : pathFor();
  const childLevel = (b) => b ? b.level + 1 : 1;
  for (let i = 0; i < lines.length; i++) {
    const raw = lines[i];
    const line = raw.trim();
    const fence = FENCE.exec(line);
    if (fence) {
      const marker = fence[1];
      const body = [];
      i++;
      while (i < lines.length && lines[i].trim() !== marker) body.push(lines[i++].replace(/\s+$/, ""));
      const indents = body.filter((l) => l.trim()).map((l) => l.length - l.trimStart().length);
      const minIndent = indents.length ? Math.min(...indents) : 0;
      const text = body.map((l) => l.slice(minIndent)).join("\n");
      let b = cur() ?? start("Answer", false, 1, pathFor());
      let lastIdx = b.descLines.length - 1;
      while (lastIdx >= 0 && b.descLines[lastIdx] === "") lastIdx--;
      if (lastIdx >= 0) {
        const last = b.descLines[lastIdx];
        const short = last.length <= 80 && !/[.!?]$/.test(last);
        const used = b.answerLines !== null || b.options.length > 0;
        if (short && used) {
          b.descLines.splice(lastIdx);
          b = start(last.replace(/:\s*$/, ""), false, childLevel(b), childPath(b));
        }
      }
      b.answerLines = b.answerLines ? [...b.answerLines, "", ...text.split("\n")] : text.split("\n");
      continue;
    }
    if (line === "") {
      const c2 = cur();
      if (c2 && c2.descLines.length) c2.descLines.push("");
      continue;
    }
    const h = HEADING.exec(line);
    if (h) {
      const level = h[1].length;
      const title = h[2].trim();
      if (level === 1 && !sawTitle && items.length === 0 && !cur()) {
        sawTitle = true;
        continue;
      }
      flush();
      while (headingStack.length && headingStack[headingStack.length - 1].level >= level) headingStack.pop();
      start(title, true, level, pathFor());
      headingStack.push({ level, title });
      continue;
    }
    const opt = OPTION.exec(line);
    if (opt) {
      (cur() ?? start("Options", false, 1, pathFor())).options.push(optionFromText(opt[2], opt[1] !== " "));
      continue;
    }
    const bold = BOLD_LINE.exec(line);
    if (bold) {
      const c2 = cur();
      start(bold[1].trim(), false, childLevel(c2), childPath(c2));
      continue;
    }
    if (TABLE_SEP.test(line)) continue;
    const table = TABLE_ROW.exec(line);
    if (table) {
      const cells = table[1].split("|").map((c2) => c2.trim());
      if (cells.length >= 2 && cells[0] && cells[1]) {
        const key = cleanKey(cells[0]);
        const value = cells[1].replace(/^`(.*)`$/, "$1");
        const header = /^(key|field|name|question)$/i.test(key) && /^(value|answer)$/i.test(value);
        if (!header) {
          const c2 = cur();
          const b = start(key, false, childLevel(c2), childPath(c2));
          b.answerLines = [value];
          flush();
        }
      }
      continue;
    }
    const isBullet = /^(?:[-*+]|\d+[.)])\s+/.test(line);
    const kv = KV.exec(line);
    if (kv && looksLikeKey(cleanKey(kv[1]), isBullet)) {
      const key = cleanKey(kv[1]);
      let value = kv[2].trim().replace(/^`(.*)`$/, "$1");
      const c2 = cur();
      const path = childPath(c2), level = childLevel(c2);
      if (value === "" || value === "|" || value === ">") {
        const parts = [];
        const baseIndent = raw.length - raw.trimStart().length;
        while (i + 1 < lines.length) {
          const next = lines[i + 1];
          const nt = next.trim();
          if (nt === "") {
            if (parts.length) parts.push("");
            i++;
            continue;
          }
          const ni = next.length - next.trimStart().length;
          if (ni <= baseIndent || HEADING.test(nt)) break;
          parts.push(nt);
          i++;
        }
        while (parts.length && parts[parts.length - 1] === "") parts.pop();
        value = parts.join("\n");
        if (!value) {
          start(key, false, level, path);
          continue;
        }
      }
      const b = start(key, false, level, path);
      b.answerLines = value.split("\n");
      flush();
      continue;
    }
    const bullet = BULLET.exec(line);
    if (bullet) {
      (cur() ?? start("Options", false, 1, pathFor())).options.push(optionFromText(bullet[1], false));
      continue;
    }
    const c = cur();
    if (!c) start(line.replace(/:\s*$/, ""), false, 1, pathFor());
    else c.descLines.push(line);
  }
  flush();
  return items;
}
async function hashString(s) {
  if (typeof crypto !== "undefined" && crypto.subtle) {
    const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
    return Array.from(new Uint8Array(buf).slice(0, 8), (b) => b.toString(16).padStart(2, "0")).join("");
  }
  let h = 0;
  for (let i = 0; i < s.length; i++) h = h * 31 + s.charCodeAt(i) | 0;
  return (h >>> 0).toString(16);
}
async function buildProfile(md) {
  return { hash: await hashString(md), items: parseMarkdown(md) };
}

// src/types.ts
var DEFAULT_SETTINGS = { overwrite: false, semantic: true, fillChoices: false };
var STORAGE_KEYS = {
  markdown: "markdown",
  profile: "profile",
  profileEmbeddings: "profileEmbeddings",
  settings: "settings",
  modelStatus: "modelStatus",
  lastResult: "lastResult"
};

// src/background.ts
var OFFSCREEN_URL = "offscreen.html";
var FILL_TIMEOUT_MS = 5 * 60 * 1e3;
async function getProfile() {
  const r = await chrome.storage.local.get(STORAGE_KEYS.profile);
  return r[STORAGE_KEYS.profile] || null;
}
async function getSettings() {
  const r = await chrome.storage.local.get(STORAGE_KEYS.settings);
  return { ...DEFAULT_SETTINGS, ...r[STORAGE_KEYS.settings] || {} };
}
async function setModelStatus(status) {
  await chrome.storage.local.set({ [STORAGE_KEYS.modelStatus]: status });
}
var creatingOffscreen = null;
async function ensureOffscreen() {
  const contexts = await chrome.runtime.getContexts({
    contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT],
    documentUrls: [chrome.runtime.getURL(OFFSCREEN_URL)]
  });
  if (contexts.length) return;
  if (!creatingOffscreen) {
    creatingOffscreen = chrome.offscreen.createDocument({
      url: OFFSCREEN_URL,
      reasons: [chrome.offscreen.Reason.WORKERS],
      justification: "Runs a local text-embedding model (Transformers.js) to match form fields to Markdown questions."
    }).finally(() => {
      creatingOffscreen = null;
    });
  }
  await creatingOffscreen;
}
async function embed(texts) {
  if (!texts.length) return [];
  await ensureOffscreen();
  const res = await chrome.runtime.sendMessage({ target: "offscreen", type: "embed", texts });
  if (!res) throw new Error("The model host did not respond.");
  if ("error" in res) throw new Error(res.error);
  return res.vectors;
}
async function warmUp() {
  await ensureOffscreen();
  const res = await chrome.runtime.sendMessage({ target: "offscreen", type: "warm-up" });
  if (res?.error) throw new Error(res.error);
}
async function getProfileEmbeddings(profile) {
  const r = await chrome.storage.local.get(STORAGE_KEYS.profileEmbeddings);
  const cached = r[STORAGE_KEYS.profileEmbeddings];
  if (cached && cached.hash === profile.hash && cached.vectors?.length === profile.items.length) return cached;
  const vectors = await embed(profile.items.map(itemEmbedText));
  const result = { hash: profile.hash, vectors };
  await chrome.storage.local.set({ [STORAGE_KEYS.profileEmbeddings]: result });
  return result;
}
async function handleMatch(fields) {
  const profile = await getProfile();
  if (!profile || !profile.items.length) throw new Error("No Markdown saved. Open the extension options and paste your form.");
  const settings = await getSettings();
  let fieldVecs;
  let itemVecs;
  if (settings.semantic && fields.length) {
    try {
      itemVecs = (await getProfileEmbeddings(profile)).vectors;
      fieldVecs = await embed(fields.map(fieldEmbedText));
    } catch (err) {
      console.warn("[MD Autofill] semantic matching unavailable, using lexical only:", err);
    }
  }
  const sim = buildSimMatrix(fields, profile.items, fieldVecs, itemVecs);
  const { pairs, unmatched } = align(fields, profile.items, sim);
  const assignments = [];
  for (const p of pairs) {
    const a = toAssignment(fields[p.fi], profile.items[p.ii], p.score, p.method);
    if (a) assignments.push(a);
    else unmatched.push({ index: fields[p.fi].index, fieldText: fields[p.fi].label || fieldEmbedText(fields[p.fi]), bestKey: `${profile.items[p.ii].title} (no usable answer)`, bestScore: p.score });
  }
  unmatched.sort((a, b) => a.index - b.index);
  console.groupCollapsed(`[MD Autofill] matched ${assignments.length} of ${fields.length} fields`);
  for (const a of assignments) console.log(`${a.method.padEnd(12)} ${a.score.toFixed(2)}  "${a.fieldText.split(" | ")[0]}"  <-  "${a.key}"`);
  for (const u of unmatched) console.log(`unmatched    ${u.bestScore?.toFixed(2) ?? "    "}  "${u.fieldText}"  (closest: "${u.bestKey ?? "-"}")`);
  console.groupEnd();
  return { assignments, unmatched };
}
var ACTION_SCRIPT = { fill: "content.js", clear: "clear.js", "check-all": "checkall.js" };
var pendingFills = /* @__PURE__ */ new Map();
function finishIfDone(p) {
  if (p.expected === null || p.results.length < p.expected) return;
  clearTimeout(p.timer);
  pendingFills.delete(p.tabId);
  const filled = p.results.reduce((n, r) => n + r.filled, 0);
  const total = p.results.reduce((n, r) => n + r.total, 0);
  const assignments = p.results.flatMap((r) => r.assignments);
  const unmatched = p.results.flatMap((r) => r.unmatched || []);
  const error = p.results.find((r) => r.error)?.error;
  const result = { url: p.url, time: Date.now(), action: p.action, filled, total, assignments, unmatched, error };
  void chrome.storage.local.set({ [STORAGE_KEYS.lastResult]: result });
  chrome.tabs.sendMessage(p.tabId, { target: "content", type: "summary", action: p.action, filled, total }, { frameId: 0 }).catch(() => {
  });
  p.resolve(result);
}
async function runOnActiveTab(action) {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  const url = tab?.url || "";
  const fail = (error) => {
    const r = { url, time: Date.now(), action, filled: 0, total: 0, assignments: [], unmatched: [], error };
    void chrome.storage.local.set({ [STORAGE_KEYS.lastResult]: r });
    return r;
  };
  if (!tab?.id) return fail("No active tab.");
  if (url && !/^(https?|file):/.test(url)) return fail("This page cannot be filled (browser or extension page).");
  if (action === "fill") {
    const profile = await getProfile();
    if (!profile || !profile.items.length) return fail("No Markdown saved. Open the options page and paste your form.");
  }
  if (pendingFills.has(tab.id)) return fail("Another action is already running on this tab.");
  const tabId = tab.id;
  return new Promise((resolve) => {
    const p = {
      tabId,
      url,
      action,
      expected: null,
      results: [],
      resolve,
      timer: setTimeout(() => {
        if (!p.results.length) p.results.push({ filled: 0, total: 0, assignments: [], unmatched: [], error: "Timed out waiting for the page." });
        p.expected = p.results.length;
        finishIfDone(p);
      }, FILL_TIMEOUT_MS)
    };
    pendingFills.set(tabId, p);
    chrome.scripting.executeScript({ target: { tabId, allFrames: true }, files: [ACTION_SCRIPT[action]] }).then((injected) => {
      p.expected = Math.max(1, injected.length);
      finishIfDone(p);
    }).catch((err) => {
      clearTimeout(p.timer);
      pendingFills.delete(tabId);
      resolve(fail(`Could not access this page: ${err instanceof Error ? err.message : String(err)}`));
    });
  });
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.target !== "background") return;
  const respond = (p) => {
    p.then(sendResponse).catch((err) => sendResponse({ error: err instanceof Error ? err.message : String(err) }));
    return true;
  };
  switch (msg.type) {
    case "fill":
      return respond(runOnActiveTab("fill"));
    case "clear":
      return respond(runOnActiveTab("clear"));
    case "check-all":
      return respond(runOnActiveTab("check-all"));
    case "match":
      return respond(handleMatch(msg.fields));
    case "frame-result": {
      const tabId = sender.tab?.id;
      const p = tabId !== void 0 ? pendingFills.get(tabId) : void 0;
      if (p) {
        p.results.push({ filled: msg.filled, total: msg.total, assignments: msg.assignments || [], unmatched: msg.unmatched || [], error: msg.error });
        finishIfDone(p);
      }
      sendResponse({ ok: true });
      return;
    }
    case "model-progress":
      void setModelStatus(msg.status);
      sendResponse({ ok: true });
      return;
    case "warm-up":
      return respond(warmUp().then(() => ({ ok: true })));
    case "profile-saved":
      return respond(
        (async () => {
          const profile = await getProfile();
          const settings = await getSettings();
          if (profile && profile.items.length && settings.semantic) await getProfileEmbeddings(profile);
          return { ok: true };
        })()
      );
    default:
      return;
  }
});
chrome.commands.onCommand.addListener((command) => {
  if (command === "fill-form") void runOnActiveTab("fill");
});
chrome.runtime.onInstalled.addListener(() => void setModelStatus({ state: "idle" }));
chrome.runtime.onStartup.addListener(() => void setModelStatus({ state: "idle" }));
globalThis.__mdAutofillDebug = {
  fillActiveTab: () => runOnActiveTab("fill"),
  clearActiveTab: () => runOnActiveTab("clear"),
  checkAllActiveTab: () => runOnActiveTab("check-all"),
  buildProfile,
  warmUp
};
