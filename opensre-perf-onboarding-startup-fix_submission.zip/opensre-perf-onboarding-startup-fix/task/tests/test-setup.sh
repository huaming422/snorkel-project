#!/usr/bin/env bash
# test-setup.sh — sourced before the verifier runs.
# Prepares the opensre Python environment for behavioral testing. The full
# dependency closure is baked into /opt/venv at image build (block 7:
# `uv sync --frozen --all-extras --group dev`), so this runs offline-first.
set -euo pipefail

cd /repo/opensre

# The task's own uv sees offline mode; harbor's `uv tool install` at trial prep
# (network still up) is unaffected because this is scoped to this script only.
export UV_OFFLINE=1
export UV_PROJECT_ENVIRONMENT=/opt/venv
export VIRTUAL_ENV=/opt/venv
export PATH="/opt/venv/bin:${PATH}"

# Keep the test run free of telemetry / external reporting side effects.
export OPENSRE_SENTRY_DISABLED="${OPENSRE_SENTRY_DISABLED:-1}"
export OPENSRE_NO_TELEMETRY="${OPENSRE_NO_TELEMETRY:-1}"

# Reconcile the venv against the locked closure. --frozen never resolves against
# the network; with UV_OFFLINE set a cache miss fails fast instead of hanging.
uv sync --frozen --all-extras --group dev --offline

echo "[test-setup] opensre test env ready"
