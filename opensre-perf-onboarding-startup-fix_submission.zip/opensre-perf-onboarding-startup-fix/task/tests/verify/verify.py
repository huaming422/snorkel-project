"""Behavioral verifiers for the onboarding/first-turn startup speed-ups.

Three independent prongs, each tested THROUGH a pre-existing, stable public
interface — never by importing an internal helper or checking a created file
path, so a rename/inline/relocate of the implementation still passes:

  A. The local coding-agent launch gives the Codex subprocess a fresh, minimal
     CODEX_HOME on the hosted route under the agent's own sandbox, leaves the
     user's real home alone otherwise, keeps the OS ``HOME`` intact, and cleans
     up — observed in the environment handed to ``subprocess.Popen`` via
     ``codex_backend.run()``.
  D. The session reasoning effort is active during an action-turn model call
     (MAX maps to the runtime ``xhigh``) — observed by reading
     ``get_active_reasoning_effort`` from inside a fake LLM driven through the
     production turn stack (``run_harness_turn`` -> ``HeadlessAgent.handle`` ->
     ``dispatch_chat_turn`` -> ``orchestrator.run_turn`` -> the real
     ``execute_actions`` -> ``ActionTurnRunner`` -> ``_run_action_turn`` ->
     model), the exact path every production REPL ``/effort`` turn flows
     through, so effort installed anywhere from the turn boundary down is seen.
  B. When the onboarding demo menu is offered, the first-turn work (LLM client
     build + credit prefetch) runs in the background, and a client-build failure
     does not stop the credit prefetch — observed by driving ``run_repl_async``
     with the REAL ``offer_demo`` (so a warm-up placed inside it fires just as
     one placed after it does) and watching the shared client builder
     ``core.llm.factory.get_llm`` and the ``prefetch_hosted_credits`` step get
     called off the launch path. The client build is watched at ``get_llm``
     rather than one of its wrappers, so a warm routing through
     ``default_llm_factory`` (``return get_llm(LLMRole.AGENT)``) or a direct
     ``get_llm(LLMRole.AGENT)`` is seen either way.

All interfaces below (``codex_backend.run``, ``run_harness_turn``,
``run_repl_async``) and every symbol imported at module scope exist in the
repository before the fix, so collection never depends on the solution.
"""

from __future__ import annotations

import asyncio
import io
import os
import tempfile
import time
from pathlib import Path
from types import SimpleNamespace
from typing import Any
from unittest.mock import MagicMock, patch

import pytest
from rich.console import Console

# ── Pre-existing public interfaces under test ──────────────────────────────
import core.llm.factory as llm_factory
import core.llm.hosted_credits as hosted_credits
import surfaces.interactive_shell.command_registry.choice_prompt as choice_prompt
import surfaces.interactive_shell.main as main_entrypoint
import surfaces.interactive_shell.runtime.slash_adapter as slash_adapter
import surfaces.interactive_shell.runtime.startup.demo_picker as demo_picker
from config.llm_reasoning_effort import ReasoningEffort, get_active_reasoning_effort
from core.llm.types import AgentLLMResponse
from integrations.coding_agent import codex_backend
from surfaces.interactive_shell.runtime.core.state import ReplState
from surfaces.interactive_shell.session import Session
from tests.core.agent.orchestration.action_execution_test_harness import (
    FakeActionLLM,
    no_tool_response,
)
from tests.shared.harness_turn_driver import run_harness_turn

# ``CODEX_HOME`` is the environment variable the ``codex`` CLI itself reads for
# its config/plugins/skills directory — an external, stable fact of that tool,
# not a value this task's solution invents.
_CODEX_HOME = "CODEX_HOME"
# A signed-in OpenSRE account's hosted OpenAI credentials, shaped like the
# repo's own coding-agent tests use.
_HOSTED = {"OPENAI_API_KEY": "osre_pat_secret", "OPENAI_BASE_URL": "https://app.test/api/llm/v1"}

# Repo mock targets, mirrored from tests/integrations/test_coding_agent.py.
_POPEN = "integrations.llm_cli.agent_exec.subprocess.Popen"
_GIT_RUN = "integrations.git.local.subprocess.run"


# ── Shared coding-agent test doubles (from the repo's own suite) ────────────
def _git_run_side_effect(cmd: list[str], **_: object) -> MagicMock:
    """A git stand-in: report a clean git checkout with one modified file."""
    sub = cmd[1]  # only git calls reach subprocess.run
    if sub == "rev-parse":
        return MagicMock(returncode=0, stdout="true\n", stderr="")
    if sub == "status":
        if "-z" in cmd:
            return MagicMock(returncode=0, stdout=" M foo.py\0", stderr="")
        return MagicMock(returncode=0, stdout=" M foo.py\n", stderr="")
    if sub == "diff":
        return MagicMock(returncode=0, stdout="diff --git a/foo.py b/foo.py\n", stderr="")
    return MagicMock(returncode=0, stdout="", stderr="")


class _FakePopen:
    """Minimal ``subprocess.Popen`` stand-in that completes immediately."""

    def __init__(self, *, stdout: str = "done\n", returncode: int = 0) -> None:
        self.stdin = io.StringIO()
        self.stdout = io.StringIO(stdout)
        self.stderr = io.StringIO("")
        self.returncode = returncode

    def poll(self) -> int:
        return self.returncode

    def wait(self, timeout: float | None = None) -> int:  # noqa: ARG002
        return self.returncode


def _spawn_recording_codex_home(seen: dict[str, Any]):
    """A Popen stand-in that reads the Codex home while the agent would run."""

    def _spawn(_argv: list[str], **kwargs: object) -> _FakePopen:
        env = kwargs["env"]
        assert isinstance(env, dict)
        seen["env"] = dict(env)
        seen["env_home"] = env.get("HOME", "")
        home = env.get(_CODEX_HOME)
        if home:
            seen["codex_home"] = home
        return _FakePopen()

    return _spawn


# ───────────────────────────── Prong A ────────────────────────────────────
@patch(_POPEN)
@patch(_GIT_RUN, side_effect=_git_run_side_effect)
@patch("integrations.coding_agent.codex_backend._resolve_binary", return_value="/usr/bin/codex")
def test_hosted_run_uses_isolated_minimal_home(
    _mock_resolve: MagicMock,
    _mock_git: MagicMock,
    mock_popen: MagicMock,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Hosted route + agent sandbox: Codex gets a fresh minimal home, HOME kept, home removed."""
    seen: dict[str, Any] = {}
    mock_popen.side_effect = _spawn_recording_codex_home(seen)
    monkeypatch.setenv(_CODEX_HOME, str(tmp_path / "personal-codex"))
    monkeypatch.setattr(
        "integrations.coding_agent.codex_backend.hosted_openai_subprocess_env", lambda: _HOSTED
    )

    codex_backend.run("fix", workspace=str(tmp_path), model="gpt-5.6-sol", timeout_sec=60)

    codex_home = seen.get("codex_home")
    # A fresh isolated directory, not the user's personal one. This is the
    # format-independent behavioural core of the isolation: the hosted route
    # must NOT drive Codex against the operator's personal home. WHAT the fresh
    # home is seeded with (which surfaces its config disables, and in which key
    # spelling) is a free solution choice the codex CLI honours in several
    # shapes, so it is judged by the ``codex_minimal_config_quality`` rubric
    # criterion rather than pinned here.
    assert codex_home and codex_home != str(tmp_path / "personal-codex")
    # The real HOME is deliberately preserved for git / gh credentials.
    assert seen["env_home"] == os.environ["HOME"]
    # The temporary home is cleaned up after the run (no on-disk leak).
    assert not Path(codex_home).exists()


@patch(_POPEN)
@patch(_GIT_RUN, side_effect=_git_run_side_effect)
@patch("integrations.coding_agent.codex_backend._resolve_binary", return_value="/usr/bin/codex")
def test_signed_out_run_keeps_the_users_codex_home(
    _mock_resolve: MagicMock,
    _mock_git: MagicMock,
    mock_popen: MagicMock,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Signed-out users rely on their own ~/.codex (auth.json, custom providers)."""
    seen: dict[str, Any] = {}
    mock_popen.side_effect = _spawn_recording_codex_home(seen)
    user_home = str(tmp_path / "user-codex")
    monkeypatch.setenv(_CODEX_HOME, user_home)
    # No hosted account on this route.
    monkeypatch.setattr(
        "integrations.coding_agent.codex_backend.hosted_openai_subprocess_env", lambda: None
    )

    codex_backend.run("fix", workspace=str(tmp_path), model=None, timeout_sec=60)

    assert seen.get("codex_home") == user_home


@patch(_POPEN)
@patch(_GIT_RUN, side_effect=_git_run_side_effect)
@patch("integrations.coding_agent.codex_backend._resolve_binary", return_value="/usr/bin/codex")
def test_host_sandbox_does_not_swap_the_codex_home(
    _mock_resolve: MagicMock,
    _mock_git: MagicMock,
    mock_popen: MagicMock,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The host sandbox's gateway home is already clean; it is not isolated."""
    seen: dict[str, Any] = {}
    mock_popen.side_effect = _spawn_recording_codex_home(seen)
    monkeypatch.setenv("CODING_AGENT_SANDBOX", "host")
    monkeypatch.delenv(_CODEX_HOME, raising=False)
    monkeypatch.setattr(
        "integrations.coding_agent.codex_backend.hosted_openai_subprocess_env", lambda: _HOSTED
    )

    codex_backend.run("fix", workspace=str(tmp_path), model=None, timeout_sec=60)

    assert _CODEX_HOME not in seen["env"]


@patch(_POPEN)
@patch(_GIT_RUN, side_effect=_git_run_side_effect)
@patch("integrations.coding_agent.codex_backend._resolve_binary", return_value="/usr/bin/codex")
def test_run_degrades_when_no_isolated_home_can_be_made(
    _mock_resolve: MagicMock,
    _mock_git: MagicMock,
    mock_popen: MagicMock,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If the temp home cannot be created the run still completes with the default home."""

    def _no_tempdir(*_args: object, **_kwargs: object) -> str:
        raise OSError("read-only file system")

    seen: dict[str, Any] = {}
    mock_popen.side_effect = _spawn_recording_codex_home(seen)
    monkeypatch.delenv(_CODEX_HOME, raising=False)
    # Patch the global mkdtemp object so this is agnostic to which module owns it.
    monkeypatch.setattr(tempfile, "mkdtemp", _no_tempdir)
    monkeypatch.setattr(
        "integrations.coding_agent.codex_backend.hosted_openai_subprocess_env", lambda: _HOSTED
    )

    result = codex_backend.run("fix", workspace=str(tmp_path), model=None, timeout_sec=60)

    assert result.success is True
    # No isolated home was injected; the default (unset here) applies.
    assert _CODEX_HOME not in seen["env"]


# ───────────────────────────── Prong D ────────────────────────────────────
class _EffortLLM(FakeActionLLM):
    """Records the reasoning effort that is active when the model is invoked."""

    seen: list[str | None]

    def invoke(
        self,
        messages: list[dict[str, Any]],
        *,
        system: str | None = None,
        tools: list[dict[str, Any]] | None = None,
    ) -> AgentLLMResponse:
        self.seen.append(get_active_reasoning_effort())
        return super().invoke(messages, system=system, tools=tools)


# The composition root resolves the action LLM from these two bindings; a turn
# driven through the production stack reads ``headless_build.default_llm_factory``
# (the one ``build_shell_agent`` / ``HeadlessAgent`` wire), while the direct
# single-stage entry reads ``action_turn.default_llm_factory``. Patch both — the
# unused one is never read — exactly as the repo's own action-turn suite does
# (tests/core/agent/orchestration/test_agent_actions.py::_patch_action_llm_factory).
_ACTION_LLM_FACTORY_PATCHES = (
    "core.agent_harness.turns.headless_build.default_llm_factory",
    "surfaces.interactive_shell.runtime.action_turn.default_llm_factory",
)


def _effort_seen_for(
    effort: ReasoningEffort | None, monkeypatch: pytest.MonkeyPatch
) -> list[str | None]:
    """Drive one real production turn and report the effort active at the model call.

    The turn runs through the full production path a REPL ``/effort`` turn takes:
    ``run_harness_turn`` -> ``HeadlessAgent.handle`` -> ``dispatch_chat_turn`` ->
    ``orchestrator.run_turn`` -> ``_run_turn`` -> the REAL ``execute_actions`` ->
    ``ActionTurnRunner`` -> ``_run_action_turn`` -> the fake model. No stage is
    replaced, so the effort is observed wherever a solution installs it — at the
    action driver (the oracle), at the orchestrator, or at the turn runner — as
    long as it is active during the model call, while a stored-but-never-applied
    effort still yields the provider default.
    """
    llm = _EffortLLM([no_tool_response("Hello.")])
    llm.seen = []
    for target in _ACTION_LLM_FACTORY_PATCHES:
        monkeypatch.setattr(target, lambda: llm)
    # ``_run_turn`` imports ``prefetch_hosted_credits`` locally from its source
    # module each call, so patch it there to keep the turn offline.
    monkeypatch.setattr("core.llm.hosted_credits.prefetch_hosted_credits", lambda: None)
    session = Session()
    session.reasoning_effort = effort
    run_harness_turn("hello", session, Console(file=io.StringIO()), is_tty=False)
    return llm.seen


def test_session_effort_reaches_the_turns_model_call(monkeypatch: pytest.MonkeyPatch) -> None:
    """``/effort`` set on the session is active during the action-turn model call."""
    # The env override would otherwise mask the session value.
    monkeypatch.delenv("OPENSRE_REASONING_EFFORT", raising=False)

    with monkeypatch.context() as m:
        assert _effort_seen_for(ReasoningEffort.LOW, m) == ["low"]
    with monkeypatch.context() as m:
        # MAX is the user-facing alias; the runtime maps it to xhigh.
        assert _effort_seen_for(ReasoningEffort.MAX, m) == ["xhigh"]
    with monkeypatch.context() as m:
        # Without a session choice (and no env override) the provider default applies.
        assert _effort_seen_for(None, m) == [None]


# ───────────────────────────── Prong B ────────────────────────────────────
class _Controller:
    def __init__(self, *_args: object, **_kwargs: object) -> None:
        return

    async def start_interactive_shell(self) -> None:
        return


class _SessionStore:
    def open_store(self, _session: object) -> None:
        return

    def refresh_from_storage(self, _session: object) -> None:
        return

    def close(self, _session: object) -> None:
        return


def _boot_repl(monkeypatch: pytest.MonkeyPatch) -> None:
    """Drive run_repl_async with its heavy collaborators stubbed (repo's own recipe)."""
    monkeypatch.setattr(main_entrypoint, "identify_saved_github_username", lambda: None)
    monkeypatch.setattr(
        main_entrypoint,
        "create_repl_runtime",
        lambda **_kwargs: SimpleNamespace(session=Session(), state=ReplState(), inbox=None),
    )
    monkeypatch.setattr(main_entrypoint, "InteractiveShellController", _Controller)
    monkeypatch.setattr(main_entrypoint.SessionManager, "for_session", lambda _s: _SessionStore())


def _offerable(monkeypatch: pytest.MonkeyPatch) -> None:
    """Make the REAL ``offer_demo`` enter the onboarding skill and return True.

    Mirrors the repo's own ``tests/.../test_demo_picker.py::_offerable`` so the
    production ``offer_demo`` runs for real — a warm-up placed *inside* it (fired
    when the menu is offered) therefore triggers, not only one wired after it.
    """
    monkeypatch.setattr(demo_picker, "is_test_run", lambda: False)
    monkeypatch.setattr(demo_picker, "is_onboarding_enabled", lambda: True)
    monkeypatch.setattr(demo_picker, "repl_tty_interactive", lambda: True)
    monkeypatch.setattr(demo_picker, "capture_onboarding_demo_prompted", lambda: None)
    monkeypatch.setattr(demo_picker, "merge_in_progress", lambda _cwd: False)
    monkeypatch.setattr(choice_prompt, "repl_tty_interactive", lambda: True)
    monkeypatch.setattr(slash_adapter, "repl_tty_interactive", lambda: True)


def _wait_until(predicate: Any, timeout: float = 3.0) -> None:
    """Poll ``predicate`` up to ``timeout`` seconds; the warm-up runs off-thread.

    A background warm-up need not complete before ``run_repl_async`` returns:
    the oracle joins its thread at teardown, but a daemon thread with no join
    (a valid alternative) may still be finishing. Polling tolerates both.
    """
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return
        time.sleep(0.01)


def test_offering_the_demo_warms_both_first_turn_steps_in_the_background(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Offering the menu warms the first-turn client build and the credit read off the launch path."""
    ran: list[str] = []
    _boot_repl(monkeypatch)
    _offerable(monkeypatch)
    # Watch the shared client builder, so a warm through ``default_llm_factory``
    # (``return get_llm(LLMRole.AGENT)``) or a direct ``get_llm(LLMRole.AGENT)``
    # is seen alike. The warm need not be wired after ``offer_demo`` — one placed
    # inside the real ``offer_demo`` fires here too.
    monkeypatch.setattr(llm_factory, "get_llm", lambda *_a, **_k: ran.append("client"))
    monkeypatch.setattr(hosted_credits, "prefetch_hosted_credits", lambda: ran.append("credits"))

    assert asyncio.run(main_entrypoint.run_repl_async()) == 0

    _wait_until(lambda: "client" in ran and "credits" in ran)
    assert "client" in ran and "credits" in ran


def test_credit_prefetch_still_runs_after_a_client_build_failure(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A failure building the LLM client does not prevent the credit prefetch."""
    ran: list[str] = []
    _boot_repl(monkeypatch)
    _offerable(monkeypatch)

    def _failing_client(*_a: object, **_k: object) -> None:
        ran.append("client")
        raise RuntimeError("Missing LLM credentials.")

    monkeypatch.setattr(llm_factory, "get_llm", _failing_client)
    monkeypatch.setattr(hosted_credits, "prefetch_hosted_credits", lambda: ran.append("credits"))

    assert asyncio.run(main_entrypoint.run_repl_async()) == 0

    # Both steps are attempted and the credit read is not skipped by the client
    # failure; the warm-up isolates each step. Order is a free solution choice
    # (credits-first or client-first), so it is not pinned.
    _wait_until(lambda: "client" in ran and "credits" in ran)
    assert "client" in ran and "credits" in ran
