## Task

spending time in our interactive shell and a few startup things feel off.

when i launch the shell and pick the first item on the onboarding demo menu, that first model turn hangs for a beat before anything comes back. later turns are fine; it's only the first one that drags.

separately, running the local coding agent to repair CI is way slower than the same model going through our hosted gateway. same model, very different wall-clock, so the local path seems to do a pile of extra work before it even starts.

and `/effort` looks broken: i set it and the model behaves exactly as before, like the setting never reaches the model.

can you dig in and make the onboarding first turn and the local coding-agent launch fast, and get `/effort` actually honored? the outputs look correct, so this is about speed on those two paths plus `/effort` taking effect. aside from `/effort` starting to work, nothing a user sees should change, and the pytest suite should stay green.
