## Task

heads up, we're getting intermittent reports that `bd init` can permanently brick a shared dolt sql-server. it only shows up under concurrent load, several inits hitting the same server at once, and when it happens it dies partway through the initial schema setup. a lone init against an idle server is always fine.

the worst part is it never recovers on its own. once a workspace gets wedged like this, every later open of it fails the exact same way.

can you dig in and make init robust here? it should hold up when several inits land on the same server at once, and a workspace whose setup got interrupted partway should be able to recover instead of staying stuck for good.
