// Behavioral verifier — half 1 of 2: driver-connection-poisoning drain.
//
// Criterion: drain_connection_poisoning (fail_to_pass, basic_functionality).
//
// WHAT THIS PROVES, AND HOW IT SEPARATES A CORRECT FIX FROM AN UNFIXED TREE
//
// The bug's first root cause is an error-path asymmetry in go-sql-driver/mysql:
// a stored-procedure CALL issued via ExecContext leaves its result set(s) unread
// on the wire when the call errors mid-body, poisoning the pinned migration
// connection for every following statement ("busy buffer" -> "driver: bad
// connection"). The fix routes those CALL sites through a result-set-draining
// Query path instead (QueryContext + Close, which drains on both the success and
// the error path).
//
// go-sqlmock matches ExpectExec ONLY against ExecContext, and ExpectQuery ONLY
// against QueryContext. So if we drive the real schema.MigrateUp entry point
// against a sqlmock DBConn whose CALL DOLT_* sites are wired as ExpectQuery, the
// pre-fix code (which calls ExecContext) leaves those expectations unmet and the
// run fails with an "unexpected Exec" / "unfulfilled expectations" error, while
// the fixed code (QueryContext) satisfies them and the pass completes.
//
// This is a pure behavioral separator through the pre-existing public
// interface (schema.MigrateUp + schema.DBConn). It names NONE of the solution's
// invented symbols, so it admits
// every valid alternative: inlined drain, a shared helper, a switch-based
// dispatch, always-drain, etc. — anything that reaches a draining Query path for
// the CALL sites passes; anything still on ExecContext fails.
//
// It runs in package `schema` so it can reference pre-existing package symbols
// (doltIgnorePatterns, MigrateUp, LatestVersion, DBConn). All helper names are
// prefixed `vdrain` to avoid colliding with the package's own *_test.go files,
// which remain compiled alongside this file (this file defines no TestMain).

package schema

import (
	"context"
	"regexp"
	"testing"

	"github.com/DATA-DOG/go-sqlmock"
)

// TestDrainConnectionPoisoning_CallSitesUseQueryPath drives the MigrateUp
// no-migration-work short-circuit, whose only side-effecting writes are the
// scoped dolt_ignore seed commit: CALL DOLT_ADD('dolt_ignore') followed by
// CALL DOLT_COMMIT('-m', 'schema: seed dolt_ignore patterns'). Both are wired as
// ExpectQuery here. Pre-fix commitSeededDoltIgnore issues them via ExecContext
// (expectations unmet -> MigrateUp returns a sqlmock error). Post-fix it issues
// them via the draining Query path (expectations met -> clean run).
//
// Using the no-work path keeps the mocked statement sequence minimal and stable:
// it exercises the exact CALL-site dispatch the fix changes, nothing more.
func TestDrainConnectionPoisoning_CallSitesUseQueryPath(t *testing.T) {
	db, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("create sql mock: %v", err)
	}
	defer db.Close()

	// Seed re-assertion runs unconditionally before the work-needed check. Model
	// an under-seeded database: every INSERT IGNORE reports RowsAffected=1, so
	// seedChanged is true and MigrateUp must commit the seed on the short-circuit.
	for _, pattern := range doltIgnorePatterns {
		mock.ExpectExec(regexp.QuoteMeta("INSERT IGNORE INTO dolt_ignore VALUES (?, true)")).
			WithArgs(pattern).
			WillReturnResult(sqlmock.NewResult(0, 1))
	}

	// migrationWorkNeeded: both cursors already at latest, both content_hash
	// columns present, custom-type/status tables seeded -> no migration work, so
	// MigrateUp takes the short-circuit after committing the seed.
	vdrainExpectScalar(mock, "SELECT COALESCE(MAX(version), 0) FROM schema_migrations", "version", LatestVersion())
	vdrainExpectScalar(mock, "SELECT COALESCE(MAX(version), 0) FROM ignored_schema_migrations", "version", LatestIgnoredVersion())
	vdrainExpectContentHashColumn(mock)
	vdrainExpectContentHashColumn(mock)
	vdrainExpectScalar(mock, "SELECT COUNT(*) FROM custom_types", "count", 1)
	vdrainExpectScalar(mock, "SELECT COUNT(*) FROM custom_statuses", "count", 1)

	// THE KEY SEPARATOR: the two scoped-seed-commit CALL sites, wired as queries.
	// Pre-fix ExecContext leaves these unmet; post-fix Query satisfies them.
	mock.ExpectQuery(regexp.QuoteMeta("CALL DOLT_ADD('dolt_ignore')")).
		WillReturnRows(sqlmock.NewRows([]string{"status"}))
	mock.ExpectQuery(regexp.QuoteMeta("CALL DOLT_COMMIT('-m', 'schema: seed dolt_ignore patterns')")).
		WillReturnRows(sqlmock.NewRows([]string{"hash"}))

	applied, err := MigrateUp(context.Background(), db)
	if err != nil {
		t.Fatalf("MigrateUp() error = %v (pre-fix the CALL sites use ExecContext, "+
			"so the ExpectQuery expectations for CALL DOLT_ADD/DOLT_COMMIT go unmet; "+
			"the fix must route stored-procedure CALL sites through a result-set-"+
			"draining Query path)", err)
	}
	if applied != 0 {
		t.Fatalf("MigrateUp() applied = %d, want 0 (no-work short-circuit)", applied)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet SQL expectations — the scoped dolt_ignore seed commit must "+
			"reach CALL DOLT_ADD/DOLT_COMMIT via the draining Query path, not "+
			"ExecContext: %v", err)
	}
}

// TestDrainConnectionPoisoning_MigrationApplyCommitUsesQueryPath closes the
// coverage gap the sibling above leaves open. That test drives the MigrateUp
// no-work short-circuit, whose only CALL sites are the dolt_ignore seed commit.
// The migration-APPLY commit path — the per-step DOLT_ADD/DOLT_COMMIT that runs
// after each numbered migration applies — is a SEPARATE set of CALL sites on the
// same pinned connection, and it is exactly where a mid-migration transient
// leaves a result set unread on the wire. A fix that drains only the seed-commit
// site but leaves the apply-commit site on ExecContext still bricks the pinned
// connection under concurrent load while reproducing the identical symptom, yet
// would pass the seed-only test. This test forces the apply-commit CALL sites
// onto a draining Query path so that partial fix fails.
//
// commitMigrationStep is the pre-existing (base-commit) function that runs the
// per-migration atomic commit: it force-stages the tables a migration dirtied
// (always including the cursor table) via CALL DOLT_ADD('-f', ?) and then issues
// CALL DOLT_COMMIT('-m', ?). Both CALL sites are driver-poisoning sites the fix
// must route through a result-set-draining Query path, and every documented
// alternative implementation keeps that routing (only the drain mechanism's
// shape varies). We call it directly with an empty "before" snapshot and a
// no-dirty-tables status, so the staged set collapses to exactly the cursor
// table: one DOLT_ADD followed by one DOLT_COMMIT, wired here as ExpectQuery.
// Pre-fix both run via ExecContext (expectations unmet -> error); post-fix both
// run via the draining Query path (expectations met -> clean run). It names no
// solution-invented symbol and asserts only the behavioral outcome (do the
// apply-commit CALL sites reach QueryContext?), so it admits every alternative.
func TestDrainConnectionPoisoning_MigrationApplyCommitUsesQueryPath(t *testing.T) {
	db, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("create sql mock: %v", err)
	}
	defer db.Close()

	// commitMigrationStep first re-reads the dirty working set (dolt_status,
	// ignored-excluded) to decide what to stage alongside the cursor row. Return
	// nothing dirty, so the staged set is exactly the cursor table.
	dirtyStatusQuery := `(?s)SELECT s\.table_name, s\.staged\s+FROM dolt_status s\s+WHERE NOT EXISTS`
	mock.ExpectQuery(dirtyStatusQuery).
		WillReturnRows(sqlmock.NewRows([]string{"table_name", "staged"}))

	// THE KEY SEPARATOR: the two apply-commit CALL sites, wired as queries.
	// Pre-fix ExecContext leaves these unmet; post-fix the draining Query path
	// satisfies them.
	mock.ExpectQuery(regexp.QuoteMeta("CALL DOLT_ADD('-f', ?)")).
		WithArgs(mainSource.cursorTable).
		WillReturnRows(sqlmock.NewRows([]string{"status"}))
	mock.ExpectQuery(regexp.QuoteMeta("CALL DOLT_COMMIT('-m', ?)")).
		WithArgs(sqlmock.AnyArg()).
		WillReturnRows(sqlmock.NewRows([]string{"hash"}))

	// dirtyBeforeStep nil: nothing was dirty before this step, so the "after"
	// snapshot (empty) adds no extra tables — the staged set is just the cursor.
	if err := commitMigrationStep(context.Background(), db, mainSource.cursorTable,
		"0001_test_migration.up.sql", nil); err != nil {
		t.Fatalf("commitMigrationStep() error = %v (pre-fix the per-migration "+
			"DOLT_ADD/DOLT_COMMIT run via ExecContext, so the ExpectQuery "+
			"expectations go unmet; the fix must route the migration-apply CALL "+
			"sites — not only the seed-commit sites — through a result-set-"+
			"draining Query path)", err)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet SQL expectations — the per-migration apply commit must "+
			"reach CALL DOLT_ADD/DOLT_COMMIT via the draining Query path, not "+
			"ExecContext: %v", err)
	}
}

// vdrainExpectScalar mocks a single-row scalar SELECT.
func vdrainExpectScalar(mock sqlmock.Sqlmock, query, column string, value any) {
	mock.ExpectQuery(regexp.QuoteMeta(query)).
		WillReturnRows(sqlmock.NewRows([]string{column}).AddRow(value))
}

// vdrainExpectContentHashColumn mocks the idempotent content_hash-column probe
// (a single-table SHOW COLUMNS) reporting the column already present.
func vdrainExpectContentHashColumn(mock sqlmock.Sqlmock) {
	rows := sqlmock.NewRows([]string{"Field", "Type", "Null", "Key", "Default", "Extra"}).
		AddRow("content_hash", "char(64)", "YES", "", nil, "")
	mock.ExpectQuery(`SHOW COLUMNS FROM \w+ LIKE 'content_hash'`).
		WillReturnRows(rows)
}
