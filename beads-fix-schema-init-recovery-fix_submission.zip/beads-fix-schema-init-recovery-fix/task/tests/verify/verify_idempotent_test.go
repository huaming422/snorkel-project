//go:build integration && !windows

// Behavioral verifier — half 2 of 2: frozen-migration replay idempotency, driven
// end-to-end against a REAL offline Dolt sql-server (no Docker, no network).
//
// Criteria:
//   - idempotent_0040_recovery (fail_to_pass, basic_functionality)
//   - idempotent_0041_recovery (fail_to_pass)
//   - no_overcorrection        (pass_to_pass, basic_functionality)
//
// WHAT THIS PROVES, AND HOW IT SEPARATES A CORRECT FIX FROM AN UNFIXED TREE
//
// The bug's second root cause is two frozen, content-hashed migrations whose
// shipped bytes are NOT idempotent: 0040 bare-INSERTs dolt_nonlocal_tables rows
// (replay -> "duplicate primary key given: [wisps]"), and 0041 DELETEs them and
// self-commits without --skip-empty (replay over an empty table -> "nothing to
// commit"). When a transient interrupts a migration after its side effect
// committed but before its schema_migrations version row recorded, the init
// retry loop re-runs the whole migration and the non-idempotent body bricks the
// database permanently.
//
// The fix heals these via version-keyed pre-migration repairs (NOT by editing
// the frozen SQL), so re-init recovers to the latest schema version. We forge the
// exact partial-brick on-disk state the PR author reproduced, then drive the
// pre-existing public init path (initSchemaOnDB -> schema.MigrateUpWithLock) and
// assert recovery to schema.LatestVersion(). Pre-fix each forged state bricks and
// the re-init errors; post-fix it recovers.
//
// The verifier names NONE of the solution's invented symbols (preMigrationRepairs,
// repairPartial0040NonlocalInsert, drainCall, …). It tests THROUGH the pre-existing
// initSchemaOnDB / schema.LatestVersion interface, so it admits every blueprint
// alternative (keyed-map vs switch dispatch, inlined drain, repairs co-located in
// schema.go, delete-only/insert-only repair variants): all reach LatestVersion.
//
// OFFLINE SERVER. The repo's package-`dolt` TestMain boots Dolt via testcontainers
// (Docker), unavailable here. This file owns its OWN TestMain that boots the baked
// dolt v2.2.0 binary directly with doltserver.Start (exec.LookPath "dolt"),
// modeled on internal/storage/dolt/initschema_multiprocess_test.go. Because this
// verify file defines TestMain, the Go runner stashes every sibling *_test.go in
// the package before running, so this file must be fully self-contained.

package dolt

import (
	"context"
	"database/sql"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"testing"
	"time"

	_ "github.com/go-sql-driver/mysql"
	"github.com/steveyegge/beads/internal/doltserver"
	"github.com/steveyegge/beads/internal/storage/doltutil"
	"github.com/steveyegge/beads/internal/storage/schema"
)

// vidxServerPort is the MySQL-protocol port of the offline dolt server booted by
// TestMain, or 0 if no server is available (tests skip).
var vidxServerPort int

// TestMain boots a single offline dolt sql-server for all tests in this file,
// against the baked dolt binary. Mirrors initschema_multiprocess_test.go's
// in-process server start, minus Docker. If the dolt binary is absent the server
// is simply not started and every test skips (vidxServerPort stays 0) rather than
// failing — but in the task image the binary is baked on PATH, so it starts.
func TestMain(m *testing.M) {
	code := func() int {
		doltPath, err := exec.LookPath("dolt")
		if err != nil {
			fmt.Fprintln(os.Stderr, "verify: dolt binary not on PATH; idempotency tests will skip")
			return m.Run()
		}

		tmpDir, err := os.MkdirTemp("", "vidx-beads-")
		if err != nil {
			fmt.Fprintf(os.Stderr, "verify: mkdtemp: %v\n", err)
			return 1
		}
		defer os.RemoveAll(tmpDir)

		beadsDir := filepath.Join(tmpDir, ".beads")
		doltDir := filepath.Join(beadsDir, "dolt")
		if err := os.MkdirAll(doltDir, 0o700); err != nil {
			fmt.Fprintf(os.Stderr, "verify: mkdir dolt: %v\n", err)
			return 1
		}

		// dolt refuses to init/commit without an author identity. Configure one in
		// the per-run DOLT_ROOT_PATH before init, exactly as the repo's own offline
		// server tests do (internal/doltserver/lifecycle_integration_test.go's
		// configureDoltTestIdentity). HOME and DOLT_ROOT_PATH both point at the temp
		// dir so the --global config stays scoped to this run.
		doltEnv := append(os.Environ(), "HOME="+tmpDir, "DOLT_ROOT_PATH="+tmpDir)
		for _, args := range [][]string{
			{"config", "--global", "--add", "user.name", "beads-verify"},
			{"config", "--global", "--add", "user.email", "beads@verify"},
		} {
			cfgCmd := exec.Command(doltPath, args...)
			cfgCmd.Env = doltEnv
			if out, err := cfgCmd.CombinedOutput(); err != nil {
				fmt.Fprintf(os.Stderr, "verify: dolt %v: %v\n%s\n", args, err, out)
				return 1
			}
		}

		initCmd := exec.Command(doltPath, "init")
		initCmd.Dir = doltDir
		initCmd.Env = doltEnv
		if out, err := initCmd.CombinedOutput(); err != nil {
			fmt.Fprintf(os.Stderr, "verify: dolt init: %v\n%s\n", err, out)
			return 1
		}

		// Boot a local, process-owned server (no shared server, no Docker).
		// doltserver.Start launches the sql-server subprocess with cmd.Env =
		// os.Environ(), and that server performs commits during migration, so it
		// needs the same author identity + root path. Export HOME/DOLT_ROOT_PATH
		// into the process env (not just the local exec env above) so the server
		// resolves the identity we just configured.
		os.Setenv("HOME", tmpDir)
		os.Setenv("DOLT_ROOT_PATH", tmpDir)
		os.Setenv("BEADS_DOLT_SHARED_SERVER", "0")
		os.Setenv("BEADS_DOLT_AUTO_START", "1")
		os.Setenv("BEADS_TEST_MODE", "1")
		os.Setenv("BEADS_TEST_PDEATHSIG", "1")

		state, err := doltserver.Start(beadsDir)
		if err != nil {
			fmt.Fprintf(os.Stderr, "verify: doltserver.Start: %v\n", err)
			return 1
		}
		defer func() { _ = doltserver.Stop(beadsDir) }()
		vidxServerPort = state.Port

		return m.Run()
	}()
	os.Exit(code)
}

// vidxFreshDB creates a brand-new database on the offline server and returns an
// open *sql.DB scoped to it. Each test gets its own database for isolation.
func vidxFreshDB(ctx context.Context, t *testing.T) *sql.DB {
	t.Helper()
	if vidxServerPort == 0 {
		t.Skip("no offline Dolt server available (dolt binary not baked?)")
	}

	rootDSN := doltutil.ServerDSN{Host: "127.0.0.1", Port: vidxServerPort, User: "root"}.String()
	rootDB, err := sql.Open("mysql", rootDSN)
	if err != nil {
		t.Fatalf("open root connection: %v", err)
	}
	defer rootDB.Close()

	dbName := "vidx_" + strconv.FormatInt(time.Now().UnixNano(), 36) + "_" + strconv.Itoa(vidxServerPort)
	if _, err := rootDB.ExecContext(ctx, "CREATE DATABASE IF NOT EXISTS `"+dbName+"`"); err != nil {
		t.Fatalf("create database %q: %v", dbName, err)
	}

	dbDSN := doltutil.ServerDSN{Host: "127.0.0.1", Port: vidxServerPort, User: "root", Database: dbName}.String()
	db, err := sql.Open("mysql", dbDSN)
	if err != nil {
		t.Fatalf("open db connection: %v", err)
	}
	db.SetMaxOpenConns(4)
	t.Cleanup(func() { _ = db.Close() })
	// DROP is intentionally skipped: rapid drop cycles can destabilise the server
	// and the per-run temp dir is removed by TestMain anyway.
	return db
}

// vidxInitSchema runs the pre-existing init path (pin a connection, read the db
// name, schema.MigrateUpWithLock) end-to-end — the same sequence as the repo's
// internal initSchemaOnDB, but expressed through the exported schema API so this
// verifier depends on no unexported store symbol.
func vidxInitSchema(ctx context.Context, db *sql.DB) (int, error) {
	conn, err := db.Conn(ctx)
	if err != nil {
		return 0, fmt.Errorf("pin connection: %w", err)
	}
	defer conn.Close()

	var dbName string
	if err := conn.QueryRowContext(ctx, "SELECT DATABASE()").Scan(&dbName); err != nil {
		return 0, fmt.Errorf("read database name: %w", err)
	}
	return schema.MigrateUpWithLock(ctx, conn, dbName)
}

func vidxSchemaVersion(ctx context.Context, t *testing.T, db *sql.DB) int {
	t.Helper()
	var got int
	if err := db.QueryRowContext(ctx, "SELECT COALESCE(MAX(version), 0) FROM schema_migrations").Scan(&got); err != nil {
		t.Fatalf("read schema version: %v", err)
	}
	return got
}

func vidxContext(t *testing.T) (context.Context, context.CancelFunc) {
	t.Helper()
	return context.WithTimeout(context.Background(), 4*time.Minute)
}

// TestSchemaInitRecoversFromPartial0040 forges the partial-0040 brick (a frozen
// dolt_nonlocal_tables row committed, the schema_migrations cursor rewound below
// 40) and asserts re-init recovers to LatestVersion(). Pre-fix the replay of
// 0040's bare INSERT dies on "duplicate primary key given: [wisps]".
func TestSchemaInitRecoversFromPartial0040(t *testing.T) {
	ctx, cancel := vidxContext(t)
	defer cancel()

	db := vidxFreshDB(ctx, t)

	// 1. Fully initialize to latest.
	if _, err := vidxInitSchema(ctx, db); err != nil {
		t.Fatalf("initial init: %v", err)
	}
	latest := schema.LatestVersion()
	if got := vidxSchemaVersion(ctx, t, db); got < latest {
		t.Fatalf("after initial init schema version = %d, want >= %d", got, latest)
	}

	// 2. Forge the partial-0040 state: rewind the cursor below 40 and leave a
	//    COMMITTED frozen nonlocal row (the side effect 0040's CALL DOLT_COMMIT
	//    committed before the transient). It must be committed, not merely staged:
	//    an uncommitted row would trip the separate dirty-table guard before the
	//    replay is reached.
	if _, err := db.ExecContext(ctx, "DELETE FROM schema_migrations WHERE version >= 40"); err != nil {
		t.Fatalf("rewind schema_migrations below 40: %v", err)
	}
	if _, err := db.ExecContext(ctx,
		"INSERT IGNORE INTO dolt_nonlocal_tables (table_name, target_ref, options) VALUES ('wisps', 'main', 'immediate')"); err != nil {
		t.Fatalf("re-add committed nonlocal row: %v", err)
	}
	if _, err := db.ExecContext(ctx,
		"CALL DOLT_COMMIT('-Am', 'forge partial 0040: committed nonlocal row, version row absent')"); err != nil {
		t.Fatalf("commit forged partial 0040 state: %v", err)
	}

	// 3. Re-init. THE BRICK: pre-fix this dies replaying 0040's non-idempotent
	//    INSERT; post-fix the heal clears the stray row so the frozen body replays
	//    cleanly and the chain reaches latest.
	if _, err := vidxInitSchema(ctx, db); err != nil {
		t.Fatalf("re-init after forged partial 0040 (this is the brick the fix must heal): %v", err)
	}
	if got := vidxSchemaVersion(ctx, t, db); got < latest {
		t.Fatalf("after recovery schema version = %d, want >= %d", got, latest)
	}
}

// TestSchemaInitRecoversFromPartial0041 forges the partial-0041 state (cursor at
// 40, dolt_nonlocal_tables already empty and committed) and asserts re-init
// recovers. Pre-fix the replay of 0041's DELETE over an empty table dies on
// "nothing to commit".
func TestSchemaInitRecoversFromPartial0041(t *testing.T) {
	ctx, cancel := vidxContext(t)
	defer cancel()

	db := vidxFreshDB(ctx, t)

	// 1. Fully initialize. After 0041 runs, dolt_nonlocal_tables is empty — the
	//    exact table state a partial 0041 leaves behind.
	if _, err := vidxInitSchema(ctx, db); err != nil {
		t.Fatalf("initial init: %v", err)
	}
	latest := schema.LatestVersion()
	if got := vidxSchemaVersion(ctx, t, db); got < latest {
		t.Fatalf("after initial init schema version = %d, want >= %d", got, latest)
	}

	// 2. Forge the partial-0041 state: rewind the cursor to 40 (0040 recorded,
	//    0041 not) with the nonlocal table already empty and committed.
	if _, err := db.ExecContext(ctx, "DELETE FROM schema_migrations WHERE version >= 41"); err != nil {
		t.Fatalf("rewind schema_migrations to 40: %v", err)
	}
	if _, err := db.ExecContext(ctx,
		"CALL DOLT_COMMIT('-Am', 'forge partial 0041: cursor at 40, nonlocal table empty', '--skip-empty')"); err != nil {
		t.Fatalf("commit forged partial 0041 state: %v", err)
	}

	// 3. Re-init. THE BRICK: pre-fix this dies replaying 0041's DELETE over an
	//    empty table ("nothing to commit"); post-fix the heal restores the rows so
	//    the frozen DELETE+COMMIT has a real diff and the chain reaches latest.
	if _, err := vidxInitSchema(ctx, db); err != nil {
		t.Fatalf("re-init after forged partial 0041 (this is the brick the fix must heal): %v", err)
	}
	if got := vidxSchemaVersion(ctx, t, db); got < latest {
		t.Fatalf("after recovery schema version = %d, want >= %d", got, latest)
	}
}

// TestFreshInitReachesLatestNoOvercorrection is the pass_to_pass guard against
// over-correction: a clean fresh init on an idle server must still reach
// LatestVersion() with no spurious failures. It passes both pre- and post-fix
// (the heal must be a strict no-op on the common, non-partial path), so a
// solution that makes the repairs fire destructively on a healthy database — or
// otherwise breaks the normal init — fails here.
func TestFreshInitReachesLatestNoOvercorrection(t *testing.T) {
	ctx, cancel := vidxContext(t)
	defer cancel()

	db := vidxFreshDB(ctx, t)

	if _, err := vidxInitSchema(ctx, db); err != nil {
		t.Fatalf("fresh init on idle server must succeed: %v", err)
	}
	latest := schema.LatestVersion()
	if got := vidxSchemaVersion(ctx, t, db); got < latest {
		t.Fatalf("fresh init schema version = %d, want >= %d", got, latest)
	}

	// Re-running init on an already-current database must also be a clean no-op
	// (idempotent steady state), not an over-correction that errors or regresses.
	applied, err := vidxInitSchema(ctx, db)
	if err != nil {
		t.Fatalf("re-init on a current database must be a clean no-op: %v", err)
	}
	if applied != 0 {
		t.Fatalf("re-init on a current database applied = %d migrations, want 0", applied)
	}
	if got := vidxSchemaVersion(ctx, t, db); got < latest {
		t.Fatalf("after no-op re-init schema version = %d, want >= %d", got, latest)
	}
}
