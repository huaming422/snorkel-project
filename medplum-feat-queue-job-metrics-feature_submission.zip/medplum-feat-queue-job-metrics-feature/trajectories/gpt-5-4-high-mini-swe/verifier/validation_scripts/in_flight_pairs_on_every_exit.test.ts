// @ts-nocheck
import { metrics } from '@opentelemetry/api';
import { Worker, DelayedError } from 'bullmq';
import { vi } from 'vitest';
import { getTestCases } from './validationParams';
import { loadTestConfig } from '../config/loader';
import * as contextModule from '../context';
import { initDownloadWorker } from '../workers/download';
import { initDispatchWorker } from '../workers/dispatch';
import { initSubscriptionWorker } from '../workers/subscription';

process.env.OTLP_METRICS_ENDPOINT = 'http://localhost:4318/v1/metrics';

// metric name -> list of recorded deltas/values
const records = new Map();
const observers = new Map();

function put(name, value) {
  if (!records.has(name)) records.set(name, []);
  records.get(name).push(value);
}
function syncInstrument(name) {
  const rec = (value) => put(name, value);
  return { add: rec, record: rec };
}
function obsInstrument(name) {
  return {
    addCallback: (cb) => {
      if (!observers.has(name)) observers.set(name, []);
      observers.get(name).push(cb);
    },
    removeCallback: () => undefined,
  };
}
function pollObservers() {
  for (const [name, cbs] of observers) {
    for (const cb of cbs) {
      try { cb({ observe: (v) => put(name, v) }); } catch { /* ignore */ }
    }
  }
}

beforeAll(() => {
  vi.spyOn(metrics, 'getMeter').mockReturnValue({
    createCounter: (n) => syncInstrument(n),
    createUpDownCounter: (n) => syncInstrument(n),
    createGauge: (n) => syncInstrument(n),
    createHistogram: (n) => syncInstrument(n),
    createObservableGauge: (n) => obsInstrument(n),
    createObservableCounter: (n) => obsInstrument(n),
    createObservableUpDownCounter: (n) => obsInstrument(n),
  });
});

beforeEach(() => {
  records.clear();
  observers.clear();
});

afterEach(() => {
  vi.restoreAllMocks();
});

describe('in_flight_pairs_on_every_exit', () => {
  const cases = getTestCases();
  it.each(cases)('case %#', async ({ inputs, expected }) => {
    const config = await loadTestConfig();

    const initFor = (q) =>
      q === 'download' ? initDownloadWorker :
      q === 'dispatch' ? initDispatchWorker :
      initSubscriptionWorker;

    vi.spyOn(contextModule, 'tryRunInRequestContext').mockImplementation(async () => {
      pollObservers();
      if (inputs.outcome === 'reject') throw new Error('job blew up');
      if (inputs.outcome === 'delayed') throw new DelayedError('deferred');
      return undefined;
    });

    const callsBefore = vi.mocked(Worker).mock.calls.length;
    initFor(inputs.queue)(config, { workerEnabled: true });
    const calls = vi.mocked(Worker).mock.calls;
    expect(calls.length).toBeGreaterThan(callsBefore);
    const wrapped = calls[calls.length - 1][1];

    const job = { id: 'job-1', data: {} };
    await wrapped(job, 'token-1', new AbortController().signal).then(
      () => undefined,
      () => undefined,
    );
    pollObservers(); // after settle: observe the in-flight level back at zero

    const norm = (s) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
    const token = norm(inputs.queue);

    function levelSeries(values) {
      if (values.some((v) => v < 0)) {
        let running = 0;
        return values.map((d) => (running += d));
      }
      return values;
    }

    let peak;
    let final;
    for (const [name, values] of records) {
      if (!norm(name).includes(token)) continue;
      const levels = levelSeries(values);
      const localPeak = Math.max(0, ...levels);
      const localFinal = levels[levels.length - 1];
      // The in-flight metric is the one that rose above zero and came back
      if (localPeak > 0 && localFinal < localPeak) {
        peak = localPeak;
        final = localFinal;
      }
    }

    expect(peak).toBe(expected.in_flight_peak);
    expect(final).toBe(expected.in_flight_net);
  });
});
