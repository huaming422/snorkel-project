// @ts-nocheck
import { metrics } from '@opentelemetry/api';
import { vi } from 'vitest';
import { getTestCases } from './validationParams';
import { loadTestConfig } from '../config/loader';
import { heartbeat } from '../heartbeat';
import * as databaseModule from '../database';
import * as subscriptionModule from '../workers/subscription';
import * as cronModule from '../workers/cron';
import * as downloadModule from '../workers/download';
import * as batchModule from '../workers/batch';
import * as setAccountsModule from '../workers/set-accounts';
import { queueRegistry } from '../workers/utils';
import {
  cleanupOtelHeartbeat,
  initOtelHeartbeat,
} from '../otel/otel';

process.env.OTLP_METRICS_ENDPOINT = 'http://localhost:4318/v1/metrics';

// metric name -> list of recorded values
const records = new Map();
const observers = new Map();

function put(name, value) {
  if (!records.has(name)) records.set(name, []);
  records.get(name).push(value);
}
function syncInstrument(name) {
  const rec = (value) => put(name, value);
  return { add: rec, record: rec };
}
function obsInstrument(name) {
  return {
    addCallback: (cb) => {
      if (!observers.has(name)) observers.set(name, []);
      observers.get(name).push(cb);
    },
    removeCallback: () => undefined,
  };
}
function pollObservers() {
  for (const [name, cbs] of observers) {
    for (const cb of cbs) {
      try { cb({ observe: (v) => put(name, v) }); } catch { /* ignore */ }
    }
  }
}

beforeAll(() => {
  vi.spyOn(metrics, 'getMeter').mockReturnValue({
    createCounter: (n) => syncInstrument(n),
    createUpDownCounter: (n) => syncInstrument(n),
    createGauge: (n) => syncInstrument(n),
    createHistogram: (n) => syncInstrument(n),
    createObservableGauge: (n) => obsInstrument(n),
    createObservableCounter: (n) => obsInstrument(n),
    createObservableUpDownCounter: (n) => obsInstrument(n),
  });
});

beforeEach(() => {
  records.clear();
  observers.clear();
});

afterEach(() => {
  cleanupOtelHeartbeat();
  vi.restoreAllMocks();
});

describe('active_count_in_queue_health_heartbeat', () => {
  const cases = getTestCases();
  it.each(cases)('case %#', async ({ inputs, expected }) => {
    const config = await loadTestConfig();

    const mkQueue = (active) => ({
      getWaitingCount: vi.fn().mockResolvedValue(inputs.waiting),
      getDelayedCount: vi.fn().mockResolvedValue(inputs.delayed),
      getActiveCount: vi.fn().mockResolvedValue(active),
    });
    const qA = mkQueue(inputs.active_a);
    const qB = mkQueue(inputs.active_b);

    // The new implementation uses queueRegistry.entries() to get queues.
    // Bind SubscriptionQueue to qA and CronQueue to qB so they get distinct active values.
    vi.spyOn(queueRegistry, 'entries').mockReturnValue([
      ['SubscriptionQueue', qA as never],
      ['CronQueue', qB as never],
    ] as never);

    // Also spy the individual module getters for compatibility in case the old code path is hit
    vi.spyOn(subscriptionModule, 'getSubscriptionQueue').mockReturnValue(qA as never);
    vi.spyOn(cronModule, 'getCronQueue').mockReturnValue(qB as never);
    vi.spyOn(downloadModule, 'getDownloadQueue').mockReturnValue(qA as never);
    vi.spyOn(batchModule, 'getBatchQueue').mockReturnValue(qA as never);
    vi.spyOn(setAccountsModule, 'getSetAccountsQueue').mockReturnValue(qA as never);
    vi.spyOn(databaseModule, 'getDatabasePool').mockImplementation(() => ({ query: async () => undefined }));

    cleanupOtelHeartbeat();
    initOtelHeartbeat();
    heartbeat.dispatchEvent({ type: 'heartbeat' });
    await new Promise((r) => setTimeout(r, 0));
    pollObservers();
    cleanupOtelHeartbeat();

    const norm = (s) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
    // Active gauge: recorded name containing a queue token AND "active"
    const activeValueFor = (token) => {
      for (const [name, values] of records) {
        const n = norm(name);
        if (n.includes(norm(token)) && n.includes('active')) return values[values.length - 1];
      }
      return undefined;
    };

    // The broker active count is consulted for each heartbeat queue.
    expect(qA.getActiveCount).toHaveBeenCalled();
    expect(qB.getActiveCount).toHaveBeenCalled();

    // Each queue's active count is published under its own active metric name.
    expect(activeValueFor('subscription')).toBe(expected.active_subscription);
    expect(activeValueFor('cron')).toBe(expected.active_cron);

    // The active gauge is added ALONGSIDE the pre-existing waiting/delayed gauges
    const anyWithBoth = (metricWord, value) => {
      for (const [name, values] of records) {
        if (norm(name).includes(metricWord) && values.includes(value)) return true;
      }
      return false;
    };
    expect(anyWithBoth('waiting', inputs.waiting)).toBe(expected.waiting_still_recorded === 'present');
    expect(anyWithBoth('delayed', inputs.delayed)).toBe(expected.delayed_still_recorded === 'present');
  });
});
