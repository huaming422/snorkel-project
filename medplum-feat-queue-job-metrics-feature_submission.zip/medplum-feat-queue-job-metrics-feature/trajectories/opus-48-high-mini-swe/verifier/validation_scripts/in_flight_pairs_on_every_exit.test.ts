// @ts-nocheck
import { metrics } from '@opentelemetry/api';
import { vi } from 'vitest';
import { getTestCases } from './validationParams';
import { Worker, DelayedError } from 'bullmq';
import { loadTestConfig } from '../config/loader';
import { initDownloadWorker } from '../workers/download';
import { initDispatchWorker } from '../workers/dispatch';
import { initSubscriptionWorker } from '../workers/subscription';
import * as contextModule from '../context';

process.env.OTLP_METRICS_ENDPOINT = 'http://localhost:4318/v1/metrics';

// metric name -> list of recorded deltas/values, from whichever instrument kind the solution picked.
const records = new Map();
const observers = new Map(); // name -> observable callbacks (polled on demand)

function put(name, value) {
  if (!records.has(name)) records.set(name, []);
  records.get(name).push(value);
}
function syncInstrument(name) {
  const rec = (value) => put(name, value);
  return { add: rec, record: rec };
}
function obsInstrument(name) {
  return {
    addCallback: (cb) => {
      if (!observers.has(name)) observers.set(name, []);
      observers.get(name).push(cb);
    },
    removeCallback: () => undefined,
  };
}
function pollObservers() {
  for (const [name, cbs] of observers) {
    for (const cb of cbs) {
      try { cb({ observe: (v) => put(name, v) }); } catch { /* ignore */ }
    }
  }
}

beforeAll(() => {
  vi.spyOn(metrics, 'getMeter').mockReturnValue({
    createCounter: (n) => syncInstrument(n),
    createUpDownCounter: (n) => syncInstrument(n),
    createGauge: (n) => syncInstrument(n),
    createHistogram: (n) => syncInstrument(n),
    createObservableGauge: (n) => obsInstrument(n),
    createObservableCounter: (n) => obsInstrument(n),
    createObservableUpDownCounter: (n) => obsInstrument(n),
  });
});

beforeEach(() => { records.clear(); observers.clear(); });

describe('in_flight_pairs_on_every_exit', () => {
  const cases = getTestCases();
  it.each(cases)('case %#', async ({ inputs, expected }) => {
    const config = await loadTestConfig();

    const initFor = (q) =>
      q === 'download' ? initDownloadWorker :
      q === 'dispatch' ? initDispatchWorker :
      initSubscriptionWorker;

    // Control settling at the pre-existing context boundary the processor runs the job
    // body through.
    vi.spyOn(contextModule, 'tryRunInRequestContext').mockImplementation(async () => {
      pollObservers();
      if (inputs.outcome === 'reject') throw new Error('job blew up');
      if (inputs.outcome === 'delayed') throw new DelayedError('deferred');
      return undefined;
    });

    // Build the worker; bullmq's Worker is globally mocked, so the processor it was
    // constructed with (already wrapped by the solution's instrumentation) is the
    // second constructor argument on the mock's last call.
    const callsBefore = vi.mocked(Worker).mock.calls.length;
    initFor(inputs.queue)(config, { workerEnabled: true });
    const calls = vi.mocked(Worker).mock.calls;
    expect(calls.length).toBeGreaterThan(callsBefore);
    const wrapped = calls[calls.length - 1][1];

    const job = { id: 'job-1', data: {} };
    // All exit paths must pair; a throw/defer must not strand the in-flight count.
    await wrapped(job, 'token-1', new AbortController().signal).then(
      () => undefined,
      () => undefined,
    );
    pollObservers(); // after settle: observe the in-flight level back at zero

    // Find the per-queue in-flight metric: a recorded name carrying the queue token
    // that moved UP and then came back DOWN. Reconstruct the in-flight LEVEL over
    // time, then read its peak level and its final level.
    const norm = (s) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
    const token = norm(inputs.queue);

    // An instrument records either signed deltas (+1 then -1) or absolute levels
    // (1 then 0). Convert either to a level series:
    //  - if any recorded value is negative, they are deltas -> level = cumulative sum;
    //  - otherwise they are absolute levels -> level = the values themselves.
    function levelSeries(values) {
      if (values.some((v) => v < 0)) {
        let running = 0;
        return values.map((d) => (running += d));
      }
      return values;
    }

    let peak;
    let final;
    for (const [name, values] of records) {
      if (!norm(name).includes(token)) continue;
      const levels = levelSeries(values);
      const localPeak = Math.max(0, ...levels);
      const localFinal = levels[levels.length - 1];
      // The in-flight metric is the one that rose above zero and came back — it both
      // goes up and comes down (the completed counter only ever rises).
      if (localPeak > 0 && localFinal < localPeak) {
        peak = localPeak;
        final = localFinal;
      }
    }

    expect(peak).toBe(expected.in_flight_peak);   // EXPECTED: in_flight_peak — rose to one
    expect(final).toBe(expected.in_flight_net);   // EXPECTED: in_flight_net — returned to zero

    vi.restoreAllMocks();
  });
});
