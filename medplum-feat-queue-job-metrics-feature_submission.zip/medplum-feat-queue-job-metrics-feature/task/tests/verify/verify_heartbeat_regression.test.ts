// @ts-nocheck
// SPDX-License-Identifier: Apache-2.0
//
// Pass-to-pass regression verifier — the queue-health heartbeat keeps emitting its
// pre-existing per-queue waiting/delayed gauges.
//
// Criterion (task.toml, pass_to_pass): the pre-existing server test suite still
// passes (no regression from the new gauge firing inside the globally-mocked
// heartbeat). This asserts ONLY behavior that exists at the base commit, so it
// passes on the unmodified baseline AND on a correct solution. It guards against a
// solution that breaks the existing heartbeat while adding the new metric -- e.g. by
// throwing when the shared bullmq mock lacks a newly-needed getter.
//
// Interface under test: the pre-existing, stable `initOtelHeartbeat()` export,
// driven exactly as the repo's own otel tests drive it (mocked queue getters,
// stubbed database pool, a dispatched heartbeat event). The OTel meter is spied so
// recordings are observed by metric NAME across instrument kinds.

import { sleep } from '@medplum/core';
import { metrics } from '@opentelemetry/api';
import { vi } from 'vitest';
import * as databaseModule from './database';
import { heartbeat } from './heartbeat';
import { cleanupOtelHeartbeat, initOtelHeartbeat } from './otel/otel';
import * as batchModule from './workers/batch';
import * as cronModule from './workers/cron';
import * as downloadModule from './workers/download';
import * as setAccountsModule from './workers/set-accounts';
import * as subscriptionModule from './workers/subscription';

process.env.OTLP_METRICS_ENDPOINT = 'http://localhost:4318/v1/metrics';

const recordsByName = new Map();
function instrumentFor(name) {
  const rec = (...callArgs) => {
    if (!recordsByName.has(name)) {
      recordsByName.set(name, []);
    }
    recordsByName.get(name).push(callArgs);
  };
  return { add: rec, record: rec };
}

// A queue mock that answers every count getter the heartbeat might read. Returning
// a value for getActiveCount too keeps the mock valid for a solution that reads it,
// without this test asserting anything about active (that is a validation story).
function createMockQueue() {
  return {
    getWaitingCount: vi.fn().mockResolvedValue(5),
    getDelayedCount: vi.fn().mockResolvedValue(3),
    getActiveCount: vi.fn().mockResolvedValue(2),
  };
}

function mockQueueGetters(queue) {
  vi.spyOn(subscriptionModule, 'getSubscriptionQueue').mockReturnValue(queue);
  vi.spyOn(cronModule, 'getCronQueue').mockReturnValue(queue);
  vi.spyOn(downloadModule, 'getDownloadQueue').mockReturnValue(queue);
  vi.spyOn(batchModule, 'getBatchQueue').mockReturnValue(queue);
  vi.spyOn(setAccountsModule, 'getSetAccountsQueue').mockReturnValue(queue);
}

const norm = (s) => s.toLowerCase().replace(/[^a-z0-9]/g, '');

describe('queue-health heartbeat — waiting/delayed regression', () => {
  let queue;

  beforeAll(() => {
    vi.spyOn(metrics, 'getMeter').mockReturnValue({
      createCounter: (name) => instrumentFor(name),
      createUpDownCounter: (name) => instrumentFor(name),
      createGauge: (name) => instrumentFor(name),
      createHistogram: (name) => instrumentFor(name),
      createObservableGauge: () => ({ addCallback: () => undefined, removeCallback: () => undefined }),
    });
  });

  beforeEach(() => {
    recordsByName.clear();
    queue = createMockQueue();
    mockQueueGetters(queue);
    cleanupOtelHeartbeat();
  });

  afterAll(() => {
    cleanupOtelHeartbeat();
    vi.restoreAllMocks();
  });

  test('a heartbeat reads waiting and delayed counts for the five heartbeat queues', async () => {
    const getDatabasePoolSpy = vi
      .spyOn(databaseModule, 'getDatabasePool')
      .mockImplementation(() => ({ query: async () => undefined }));

    initOtelHeartbeat();
    heartbeat.dispatchEvent({ type: 'heartbeat' });
    await sleep(0);

    expect(getDatabasePoolSpy).toHaveBeenCalled();
    // Pre-existing contract: five Redis-backed queues, each read once per heartbeat.
    expect(queue.getWaitingCount).toHaveBeenCalledTimes(5);
    expect(queue.getDelayedCount).toHaveBeenCalledTimes(5);

    // The waiting/delayed gauges are still published, carrying the mocked values.
    const names = [...recordsByName.keys()];
    const waiting = names.filter((n) => norm(n).includes(norm('waiting')));
    const delayed = names.filter((n) => norm(n).includes(norm('delayed')));
    expect(waiting.length).toBeGreaterThan(0);
    expect(delayed.length).toBeGreaterThan(0);

    const waitingValues = waiting.flatMap((n) => recordsByName.get(n).map((args) => args[0]));
    const delayedValues = delayed.flatMap((n) => recordsByName.get(n).map((args) => args[0]));
    expect(waitingValues).toContain(5);
    expect(delayedValues).toContain(3);

    cleanupOtelHeartbeat();
    getDatabasePoolSpy.mockRestore();
  });
});
