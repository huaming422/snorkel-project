// @ts-nocheck
// SPDX-License-Identifier: Apache-2.0
//
// Behavioral verifier — processor arity preservation (framework-mandated).
//
// Criterion (task.toml): "The wrapped processor preserves BullMQ's three-parameter
// arity so the abort signal is still supplied, and forwards all three arguments."
// BullMQ branches on `processor.length >= 3` to decide whether to construct and
// pass an abort signal to the job processor; an instrumentation layer that reduces
// the processor to two declared parameters silently disables job cancellation.
// This is a framework convention with no defensible alternative, so it is asserted
// deterministically here rather than in an adaptive validation story.
//
// Interface under test: the pre-existing, stable exported worker initializers
// (`init<Name>Worker`, signature `(config, options?) => {...}`, unchanged by the
// change under test). `bullmq` is globally mocked by the server package's
// `test.setup.ts` (`Worker` is a `vi.fn()`), so the processor the initializer
// handed to `new Worker(...)` is recoverable from the mock's call record — no
// Redis, no Postgres, no live job execution. The instrumentation helper is never
// imported by name.

import { Worker } from 'bullmq';
import { vi } from 'vitest';
import { loadTestConfig } from './config/loader';
import { initCronWorker } from './workers/cron';
import { initSubscriptionWorker } from './workers/subscription';

// The recording helpers are no-ops unless a metrics endpoint is configured; set it
// so a correct solution's instrumentation is live while the workers are built.
process.env.OTLP_METRICS_ENDPOINT = 'http://localhost:4318/v1/metrics';

/** The processor function the initializer passed as `new Worker(queueName, processor, opts)`. */
function captureProcessor(init, config) {
  const before = vi.mocked(Worker).mock.calls.length;
  init(config, { workerEnabled: true });
  const calls = vi.mocked(Worker).mock.calls;
  if (calls.length <= before) {
    throw new Error('worker initializer did not construct a Worker');
  }
  // new Worker(queueName, processor, opts) — processor is the second argument.
  return calls[calls.length - 1][1];
}

describe('queue job metrics — processor arity', () => {
  let cronProcessor;
  let subscriptionProcessor;

  beforeAll(async () => {
    const config = await loadTestConfig();
    cronProcessor = captureProcessor(initCronWorker, config);
    subscriptionProcessor = captureProcessor(initSubscriptionWorker, config);
  });

  test('the instrumented processor still declares three parameters (abort signal preserved)', () => {
    expect(typeof cronProcessor).toBe('function');
    // BullMQ reads `processor.length >= 3` to decide whether to supply the abort
    // signal; a two-parameter (or rest-param, length 0) wrapper drops below 3 and
    // disables cancellation. We assert exactly BullMQ's own threshold so any valid
    // signal-preserving arity passes and only a cancellation-breaking one fails.
    expect(cronProcessor.length).toBeGreaterThanOrEqual(3);
  });

  test('arity is preserved across more than one instrumented worker', () => {
    expect(typeof subscriptionProcessor).toBe('function');
    expect(cronProcessor.length).toBeGreaterThanOrEqual(3);
    expect(subscriptionProcessor.length).toBeGreaterThanOrEqual(3);
  });
});
