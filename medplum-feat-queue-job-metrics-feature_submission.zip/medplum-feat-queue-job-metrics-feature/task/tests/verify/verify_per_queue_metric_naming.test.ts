// @ts-nocheck
// SPDX-License-Identifier: Apache-2.0
//
// Behavioral verifier — per-queue metric naming AND consistent coverage.
//
// Two criteria (task.toml), both deterministic structural-behavioral properties:
//
//  1. "Per-queue metrics carry the queue in the metric name (one name per queue),
//     consistent with the existing waiting/delayed reporting." -> driving two
//     different workers' processors records the in-flight series under two
//     DISTINCT, queue-identifying metric NAMES (not one shared name distinguished
//     only by an attribute). Per-queue-in-name is pinned-but-fair: the repo's
//     pre-existing waiting/delayed gauges already name metrics per queue.
//
//  2. "The in-flight/completed instrumentation is applied consistently across the
//     worker queues, not just one or two." The canonical change wraps EIGHT
//     workers; a valid solution may wrap more. We assert the eight are covered and
//     deliberately do NOT assert the two the canonical change leaves out
//     (reindex, post-deploy-migration), so wrapping-more passes and wrapping-more
//     is never required.
//
// Interface under test: the pre-existing, stable exported worker initializers.
// `bullmq.Worker` is globally mocked, so the processor each initializer built is
// recoverable from the mock's call record; the OTel meter is spied so instrument
// activity is observed BY METRIC NAME across every instrument kind. This makes the
// observation instrument-agnostic: an UpDownCounter (`.add`), a server-maintained
// gauge (`.record`), a counter, or a histogram all register under their name, so
// any instrument that produces a rise-on-start/fall-on-settle per-queue series is
// admitted. The instrumentation helper is never imported by name.

import { metrics } from '@opentelemetry/api';
import { Worker } from 'bullmq';
import { vi } from 'vitest';
import { loadTestConfig } from './config/loader';
import { initBatchWorker } from './workers/batch';
import { initCronWorker } from './workers/cron';
import { initDataWarehouseSyncWorker } from './workers/data-warehouse-sync';
import { initDispatchWorker } from './workers/dispatch';
import { initDownloadWorker } from './workers/download';
import { initLambdaCleanerWorker } from './workers/lambda-cleaner';
import { initSetAccountsWorker } from './workers/set-accounts';
import { initSubscriptionWorker } from './workers/subscription';

// Recording helpers are no-ops unless a metrics endpoint is configured.
process.env.OTLP_METRICS_ENDPOINT = 'http://localhost:4318/v1/metrics';

// metric name -> array of recorded call-args, populated by whichever instrument
// kind the solution chose. Instruments are memoized by otel per name, so a single
// stable recorder per name captures every movement regardless of instrument kind.
const recordsByName = new Map();
// name -> observable-gauge/counter callbacks, invoked on demand so a polled
// (callback-read) in-flight instrument is admitted alongside synchronous ones.
const observableCallbacks = new Map();

function recordUnder(name, ...callArgs) {
  if (!recordsByName.has(name)) {
    recordsByName.set(name, []);
  }
  recordsByName.get(name).push(callArgs);
}

// Synchronous instruments (Counter.add, UpDownCounter.add, Gauge.record,
// Histogram.record): the same recorder keyed by metric name.
function instrumentFor(name) {
  const rec = (...callArgs) => recordUnder(name, ...callArgs);
  return { add: rec, record: rec };
}

// Observable instruments (createObservable{Gauge,Counter,UpDownCounter}): capture
// registered callbacks so an "atomic integer read by a gauge callback" design still
// registers. Invoked after the processor is driven; the callback observes the
// maintained in-flight value, recorded under whatever name(s) it observes.
function observableFor(name) {
  return {
    addCallback: (cb) => {
      if (!observableCallbacks.has(name)) {
        observableCallbacks.set(name, []);
      }
      observableCallbacks.get(name).push(cb);
    },
    removeCallback: () => undefined,
  };
}

function pollObservables() {
  for (const [name, cbs] of observableCallbacks) {
    for (const cb of cbs) {
      try {
        // ObservableResult.observe(value, attributes) -> record by creation name.
        cb({ observe: (value) => recordUnder(name, value) });
      } catch {
        // A fragile callback must never break the verifier.
      }
    }
  }
}

// The eight queues the canonical change instruments. We assert coverage of these
// and NOT of reindex / post-deploy-migration (left unwrapped by the canonical
// change — requiring them would reject a valid solution).
const INSTRUMENTED_WORKERS = [
  { token: 'subscription', init: initSubscriptionWorker },
  { token: 'cron', init: initCronWorker },
  { token: 'download', init: initDownloadWorker },
  { token: 'dispatch', init: initDispatchWorker },
  { token: 'batch', init: initBatchWorker },
  { token: 'set-accounts', init: initSetAccountsWorker },
  { token: 'data-warehouse-sync', init: initDataWarehouseSyncWorker },
  { token: 'lambda-cleaner', init: initLambdaCleanerWorker },
];

const norm = (s) => s.toLowerCase().replace(/[^a-z0-9]/g, '');

/** Build the worker and return the processor it passed to `new Worker(...)`. */
function captureProcessor(init, config) {
  const before = vi.mocked(Worker).mock.calls.length;
  init(config, { workerEnabled: true });
  const calls = vi.mocked(Worker).mock.calls;
  if (calls.length <= before) {
    throw new Error('worker initializer did not construct a Worker');
  }
  return calls[calls.length - 1][1];
}

/**
 * Drive the captured processor and return the metric names that received a
 * recording. The instrumentation records the in-flight "job started" movement
 * SYNCHRONOUSLY, before awaiting the inner job body, so we never await the
 * returned promise (the real inner body needs a database and will reject — that
 * is fine and exercises the "pairs on throw" path). We swallow the rejection.
 */
function namesRecordedWhileDriving(processor) {
  recordsByName.clear();
  const job = { id: 'verify-job', data: {} };
  const signal = new AbortController().signal;
  let settled;
  try {
    settled = processor(job, 'verify-token', signal);
  } catch {
    settled = undefined; // synchronous throw: the start-movement still landed
  }
  if (settled && typeof settled.then === 'function') {
    settled.then(
      () => undefined,
      () => undefined
    );
  }
  // Read any polled (observable-callback) instruments at this mid-flight point,
  // where a maintained in-flight value is non-zero.
  pollObservables();
  return [...recordsByName.keys()];
}

describe('queue job metrics — per-queue naming and coverage', () => {
  let config;

  beforeAll(async () => {
    config = await loadTestConfig();
    // The data-warehouse-sync worker only constructs its Worker when its sync
    // feature is operationally configured (enabled + a valid destination);
    // otherwise `initDataWarehouseSyncWorker` returns before `new Worker(...)` and
    // we could never observe its instrumentation. Enabling it is pre-existing repo
    // config (a harness-owned test fixture), not a coupling to the change under
    // test — every other worker ignores this field. A local destination needs no
    // AWS/Redis and keeps the construction purely in-process (the scheduler refresh
    // it kicks off is fire-and-forget and error-swallowed).
    config.dataWarehouse = {
      enabled: true,
      cron: '0 0 * * *',
      destination: 'local',
      localBasePath: '/tmp/dw-verify',
    };
    // Install BEFORE any instrument is created (otel memoizes the meter on first
    // use). Each create* returns a recorder keyed by the metric name.
    vi.spyOn(metrics, 'getMeter').mockReturnValue({
      createCounter: (name) => instrumentFor(name),
      createUpDownCounter: (name) => instrumentFor(name),
      createGauge: (name) => instrumentFor(name),
      createHistogram: (name) => instrumentFor(name),
      createObservableGauge: (name) => observableFor(name),
      createObservableCounter: (name) => observableFor(name),
      createObservableUpDownCounter: (name) => observableFor(name),
    });
  });

  test('two different workers record the in-flight series under distinct, queue-identifying names', () => {
    const cronNames = namesRecordedWhileDriving(captureProcessor(initCronWorker, config));
    const subscriptionNames = namesRecordedWhileDriving(captureProcessor(initSubscriptionWorker, config));

    // Each worker records at least one metric whose name carries its own queue
    // token — proving per-queue identity lives in the NAME, not a shared name
    // plus a queue attribute (which would record both under one name).
    const cronOwn = cronNames.filter((n) => norm(n).includes(norm('cron')));
    const subOwn = subscriptionNames.filter((n) => norm(n).includes(norm('subscription')));
    expect(cronOwn.length).toBeGreaterThan(0);
    expect(subOwn.length).toBeGreaterThan(0);

    // A shared-name-with-attribute design would make these identical; they differ.
    expect(new Set(cronOwn)).not.toEqual(new Set(subOwn));
    for (const n of cronOwn) {
      expect(norm(n).includes(norm('subscription'))).toBe(false);
    }
  });

  test('the in-flight instrumentation covers all eight canonically-wrapped worker queues', () => {
    const uncovered = [];
    for (const { token, init } of INSTRUMENTED_WORKERS) {
      const names = namesRecordedWhileDriving(captureProcessor(init, config));
      const matched = names.some((n) => norm(n).includes(norm(token)));
      if (!matched) {
        uncovered.push(token);
      }
    }
    expect(uncovered).toStrictEqual([]);
  });
});
