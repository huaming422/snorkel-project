// @ts-nocheck
// SPDX-License-Identifier: Apache-2.0
//
// Behavioral verifier — the asynchronous batch queue reports a running total of
// individual bundle entries processed.
//
// Criterion (task.toml / base.md para 3): "For the asynchronous batch queue
// specifically, also surface a running total of individual bundle entries
// processed." The per-queue job metrics (in-flight/completed) count whole jobs;
// the batch queue additionally has a sub-job unit of work — the individual bundle
// entry — and the change under test emits one metric movement per entry processed
// along the re-entrant batch path. A solution that wraps the batch worker for the
// shared job metrics but never counts the entries still passes every other
// verifier and story, so this entry-level total is asserted here deterministically
// rather than left to the (correctness-irrelevant) rubric.
//
// Interface under test: the pre-existing, stable `initBatchWorker` initializer and
// the re-entrant `execBatchJob` loop it drives. `bullmq.Worker` is globally mocked
// (see test.setup.ts), so the processor the initializer handed to `new Worker(...)`
// is recoverable from the mock's call record (same capture pattern as
// verify_job_metrics_arity.test.ts). The re-entrant loop's durable collaborators
// (checkpoint store, system repo, batch processor, async-job executor, binary
// upload, authenticated context) are neutralized so the loop runs a fixed number
// of entries entirely in process — no Postgres, no Redis, no object storage — while
// the real entry-counting instrumentation fires. The OTel meter is spied so the
// recording is observed BY METRIC NAME across every instrument kind, exactly like
// verify_per_queue_metric_naming.test.ts; the counting helper and its metric name
// are never imported by name, and the batch metric is matched by semantic token
// containment ('batch' + 'entr'), admitting any instrument and any such name.

import { metrics } from '@opentelemetry/api';
import { BatchProcessor } from '@medplum/fhir-router';
import { Worker } from 'bullmq';
import { vi } from 'vitest';
import { loadTestConfig } from './config/loader';
import * as contextModule from './context';
import * as binaryModule from './fhir/binary';
import { AsyncJobExecutor } from './fhir/operations/utils/asyncjobexecutor';
import * as accessPolicyModule from './fhir/accesspolicy';
import * as repoModule from './fhir/repo';
import { BatchCheckpointStore } from './fhir/batch/checkpoint-store';
import * as meModule from './auth/me';
import { initBatchWorker } from './workers/batch';

// Recording helpers are no-ops unless a metrics endpoint is configured.
process.env.OTLP_METRICS_ENDPOINT = 'http://localhost:4318/v1/metrics';

// The number of bundle entries the mocked re-entrant batch processes. The entry
// counter must advance by exactly this.
const ENTRY_COUNT = 3;

// metric name -> array of recorded call-args, populated by whichever instrument
// kind the solution chose. Instruments are memoized per name by otel, so one stable
// recorder per name captures every movement regardless of instrument kind.
const recordsByName = new Map();
const observableCallbacks = new Map();

function recordUnder(name, ...callArgs) {
  if (!recordsByName.has(name)) {
    recordsByName.set(name, []);
  }
  recordsByName.get(name).push(callArgs);
}

// Synchronous instruments (Counter.add, UpDownCounter.add, Gauge.record,
// Histogram.record): the same recorder keyed by metric name.
function instrumentFor(name) {
  const rec = (...callArgs) => recordUnder(name, ...callArgs);
  return { add: rec, record: rec };
}

// Observable instruments: capture registered callbacks so an "atomic integer read
// by a gauge callback" design still registers; invoked after the loop is driven.
function observableFor(name) {
  return {
    addCallback: (cb) => {
      if (!observableCallbacks.has(name)) {
        observableCallbacks.set(name, []);
      }
      observableCallbacks.get(name).push(cb);
    },
    removeCallback: () => undefined,
  };
}

function pollObservables() {
  for (const [name, cbs] of observableCallbacks) {
    for (const cb of cbs) {
      try {
        cb({ observe: (value) => recordUnder(name, value) });
      } catch {
        // A fragile callback must never break the verifier.
      }
    }
  }
}

const norm = (s) => s.toLowerCase().replace(/[^a-z0-9]/g, '');

/** The processor `initBatchWorker` passed to `new Worker(queueName, processor, opts)`. */
function captureBatchProcessor(config) {
  const before = vi.mocked(Worker).mock.calls.length;
  initBatchWorker(config, { workerEnabled: true });
  const calls = vi.mocked(Worker).mock.calls;
  if (calls.length <= before) {
    throw new Error('initBatchWorker did not construct a Worker');
  }
  // new Worker(queueName, processor, opts) — processor is the second argument.
  return calls[calls.length - 1][1];
}

describe('queue job metrics — batch entries processed', () => {
  let config;
  let processor;

  beforeAll(async () => {
    config = await loadTestConfig();

    // Install the meter spy BEFORE any instrument is created (otel memoizes the
    // meter and each instrument on first use). Every create* returns a recorder
    // keyed by the metric name, so the observation is instrument-agnostic.
    vi.spyOn(metrics, 'getMeter').mockReturnValue({
      createCounter: (name) => instrumentFor(name),
      createUpDownCounter: (name) => instrumentFor(name),
      createGauge: (name) => instrumentFor(name),
      createHistogram: (name) => instrumentFor(name),
      createObservableGauge: (name) => observableFor(name),
      createObservableCounter: (name) => observableFor(name),
      createObservableUpDownCounter: (name) => observableFor(name),
    });

    // Neutralize the re-entrant loop's durable collaborators so execBatchJob runs a
    // fixed number of entries in process. None of these are the change under test:
    // the counting instrumentation is what fires between them.

    // Run the authenticated-context callback directly (no repo/redis/login setup).
    vi.spyOn(contextModule, 'runInAuthenticatedContext').mockImplementation(
      async (_authState, _requestId, _traceId, _options, fn) => fn()
    );

    // A system repo whose AsyncJob read is always active (so the loop proceeds) and
    // whose clone() is itself (AsyncJobExecutor's constructor clones it).
    const fakeSystemRepo = {
      readResource: vi.fn().mockImplementation(async (_type, id) => ({
        resourceType: 'AsyncJob',
        id,
        status: 'accepted',
      })),
      clone() {
        return fakeSystemRepo;
      },
    };
    vi.spyOn(repoModule, 'getShardSystemRepo').mockReturnValue(fakeSystemRepo);

    // The submitting user's repo is only used to assemble/upload the result binary.
    const fakeUserRepo = {
      clone() {
        return fakeUserRepo;
      },
    };
    vi.spyOn(meModule, 'getUserConfiguration').mockResolvedValue({});
    vi.spyOn(accessPolicyModule, 'getRepoForLogin').mockResolvedValue(fakeUserRepo);
    vi.spyOn(binaryModule, 'uploadBinaryData').mockResolvedValue({ resourceType: 'Binary', id: 'verify-binary' });

    // Durable checkpoint store: all reads/writes are no-ops; assembly reads back no
    // chunks (results come from this run's memory, which we leave empty).
    vi.spyOn(BatchCheckpointStore.prototype, 'loadInputBundle').mockResolvedValue({
      resourceType: 'Bundle',
      type: 'batch',
      entry: Array.from({ length: ENTRY_COUNT }, () => ({
        request: { method: 'POST', url: 'Patient' },
        resource: { resourceType: 'Patient' },
      })),
    });
    vi.spyOn(BatchCheckpointStore.prototype, 'saveInitialState').mockResolvedValue(undefined);
    vi.spyOn(BatchCheckpointStore.prototype, 'loadInitialState').mockResolvedValue(undefined);
    vi.spyOn(BatchCheckpointStore.prototype, 'saveResultChunk').mockResolvedValue(undefined);
    vi.spyOn(BatchCheckpointStore.prototype, 'loadAllResults').mockResolvedValue({});
    vi.spyOn(BatchCheckpointStore.prototype, 'cleanup').mockResolvedValue(undefined);

    // The AsyncJob is completed/failed through the executor; make those no-ops.
    vi.spyOn(AsyncJobExecutor.prototype, 'completeJob').mockResolvedValue(undefined);
    vi.spyOn(AsyncJobExecutor.prototype, 'failJob').mockResolvedValue(undefined);

    // Drive the real re-entrant processor over exactly ENTRY_COUNT entries without a
    // live FHIR router / Postgres: preprocess yields an initial state with an
    // ENTRY_COUNT-entry bundle, and the one-at-a-time cursor advances that many times.
    let processed = 0;
    const initialState = {
      bundle: {
        resourceType: 'Bundle',
        type: 'batch',
        entry: Array.from({ length: ENTRY_COUNT }, () => ({})),
      },
      bundleInfo: {},
      resolvedIdentities: Object.create(null),
      preprocessResults: Object.create(null),
    };
    vi.spyOn(BatchProcessor.prototype, 'preprocess').mockImplementation(async () => {
      processed = 0;
      return initialState;
    });
    vi.spyOn(BatchProcessor.prototype, 'hasMoreEntries').mockImplementation(() => processed < ENTRY_COUNT);
    vi.spyOn(BatchProcessor.prototype, 'processNextEntry').mockImplementation(async () => {
      processed++;
    });
    vi.spyOn(BatchProcessor.prototype, 'getPosition').mockImplementation(() => processed);
    vi.spyOn(BatchProcessor.prototype, 'takePendingResults').mockImplementation(() => null);

    processor = captureBatchProcessor(config);
  });

  afterAll(() => {
    vi.restoreAllMocks();
  });

  test('the batch queue records a running total of individual bundle entries processed', async () => {
    recordsByName.clear();
    observableCallbacks.clear();

    // A re-entrant batch job (ReentrantBatchJobData: has asyncJobId, no asyncJob).
    // Checkpoint thresholds are pushed out of reach so the only checkpoint is the
    // final one, keeping the in-process run fully deterministic.
    const job = {
      id: 'verify-batch-job',
      name: 'BatchJobData',
      queueName: 'BatchQueue',
      token: 'verify-token',
      data: {
        asyncJobId: 'verify-async-job',
        authState: { login: { id: 'l' }, project: { id: 'p' }, membership: { id: 'm' } },
        checkpointEntries: ENTRY_COUNT + 1000,
        checkpointIntervalMs: 3_600_000,
      },
      async updateData(newData) {
        this.data = newData;
      },
      moveToDelayed: vi.fn().mockResolvedValue(undefined),
    };

    const signal = new AbortController().signal;
    await processor(job, 'verify-token', signal);
    pollObservables();

    // A metric whose name carries both the batch queue and the entry/entries
    // semantic token — matched by containment so no specific name is pinned and any
    // instrument kind is admitted. Nothing else recorded here contains both tokens
    // (the shared in-flight/completed job metrics carry 'batch' but not 'entr').
    const entryMetricNames = [...recordsByName.keys()].filter(
      (n) => norm(n).includes('batch') && norm(n).includes('entr')
    );
    expect(entryMetricNames.length).toBeGreaterThan(0);

    // "Advanced by exactly N": accept either a per-entry/bulk increment whose deltas
    // sum to ENTRY_COUNT (a counter/up-down counter), or a running value that reaches
    // ENTRY_COUNT (a gauge set to the running total). Both express the same total.
    let sumOfDeltas = 0;
    let maxValue = 0;
    for (const name of entryMetricNames) {
      for (const args of recordsByName.get(name)) {
        const v = Number(args[0]) || 0;
        sumOfDeltas += v;
        maxValue = Math.max(maxValue, v);
      }
    }
    expect(sumOfDeltas === ENTRY_COUNT || maxValue === ENTRY_COUNT).toBe(true);
  });
});
