#!/usr/bin/env bash
# test-setup.sh — environment bootstrap for the verifier.
# Sourced (not exec'd) by the harbor verifier runner so env vars stay alive
# for vitest.
#
# Idempotent. The Dockerfile already ran `npm ci` to bake the full dependency
# closure at the base commit; we re-run it as a guard only if an agent erased
# node_modules. The two target test files are pure unit tests (bullmq is mocked
# globally via src/__mocks__/bullmq.ts and the DB pool is stubbed), so no
# Postgres or Redis service is required.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/medplum}"
cd "$REPO_DIR"

# Keep the task's own npm offline; the Dockerfile warmed /root/.npm at build.
# (Do NOT set this in the image ENV — harbor's `uv tool install` at trial prep
# needs the network that is actually up then.)
export npm_config_cache=/root/.npm

node --version
npm --version

# Restore workspace deps only if an agent removed them (no-op otherwise).
if [ ! -d "node_modules" ] || [ ! -d "packages/server/node_modules" ]; then
    echo "[test-setup] node_modules missing — restoring with npm ci (offline)..."
    { npm ci --no-audit --no-fund --offline > /tmp/npm-ci.log 2>&1 \
        && echo "[offline-first] npm ci satisfied from image cache"; } \
      || { echo "[test-setup] offline npm ci failed; retrying online"; npm ci --no-audit --no-fund; }
fi

export PATH="$REPO_DIR/node_modules/.bin:$PATH"

echo "[test-setup] ready: $REPO_DIR (node=$(node --version), npm=$(npm --version))"
