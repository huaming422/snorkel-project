## Task

We want better operational visibility into the server's background job queues. Right now we can see that the queues exist but not how hard each one is working: operators can't tell, per queue, how loaded it is at the moment or how much work a given server process is actually getting through. Let's add that as telemetry on top of the job system we already run. Nothing here is broken; it's a reporting gap we want to close.

Export this as raw counts and let whatever observability backend we point it at derive rates and throughput over whatever window it cares about. The server itself shouldn't be computing rates. Keep it consistent with how the existing metrics behave: when there's no metrics endpoint configured, recording stays a no-op, same as today.

However you hook into a worker to capture these numbers, don't break job cancellation. The queue library decides whether to supply a job's abort signal from how many parameters the processing function declares, so anything you put in front of a worker's processor must still take and forward all three arguments — the job, its token, and the abort signal.

For the asynchronous batch queue specifically, also surface a running total of individual bundle entries processed.

No dashboards, alerting, or rate math on our side, just the raw metric series.

## User stories / requirements

- For each worker queue, the server reports how many jobs this process currently has in flight: the count rises when a job starts and falls when it settles, even if it throws. It stays balanced whether a job succeeds, fails, or is handed back for a later attempt, so an idle queue reads zero.
- For each worker queue, the server reports a running count of jobs whose work finished normally. A job that fails, or that is deferred to a later attempt, does not advance this count; only an attempt that runs all the way through does.
- The periodic queue-health telemetry reports, per queue, how many jobs the broker currently considers active, alongside and reported the same way as the waiting and delayed counts already published for those same queues.
