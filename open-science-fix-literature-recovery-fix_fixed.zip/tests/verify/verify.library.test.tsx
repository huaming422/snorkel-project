// @vitest-environment jsdom
import { act, cleanup, fireEvent, render, screen, waitFor, within } from '@testing-library/react'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import type {
  LiteratureCatalogSearchPage,
  LiteratureCatalogSearchRequest,
  LiteratureInboxCandidateView,
  LiteratureItemInput,
  LiteratureItemView
} from '../../../../shared/literature'
import type { Project } from '../../../../shared/projects'
import { useNavigationStore } from '@/stores/navigation-store'
import type { PreviewFileItem } from '@/stores/preview-workbench-store'
import { createInitialProjectState, useProjectStore } from '@/stores/project-store'
import { createInitialTagState, useTagStore } from '@/stores/tag-store'
import { LiteratureLibraryPage } from './LiteratureLibraryPage'

// jsdom lacks the pointer/scroll APIs the menu primitives call into.
if (!Element.prototype.scrollIntoView) {
  Element.prototype.scrollIntoView = (): void => undefined
}
if (!Element.prototype.hasPointerCapture) {
  Element.prototype.hasPointerCapture = (): boolean => false
  Element.prototype.setPointerCapture = (): void => undefined
  Element.prototype.releasePointerCapture = (): void => undefined
}

const { extractLiteraturePdfDraft, completeLiteraturePdfDraft, filePreviewRenderCount } =
  vi.hoisted(() => ({
    extractLiteraturePdfDraft: vi.fn(),
    completeLiteraturePdfDraft: vi.fn(),
    filePreviewRenderCount: { value: 0 }
  }))

// Keep the heavyweight PDF metadata + preview modules out of the component tree.
vi.mock('./literature-pdf-metadata', () => ({
  extractLiteraturePdfDraft,
  completeLiteraturePdfDraft
}))

vi.mock('../workspace/FilePreviewDialog', () => ({
  FilePreviewDialog: ({
    item,
    allowReadingContext,
    onReadWithAgent,
    onClose
  }: {
    item?: PreviewFileItem
    allowReadingContext?: boolean
    onReadWithAgent?: (item: PreviewFileItem) => void
    onClose: () => void
  }) => {
    filePreviewRenderCount.value += 1
    return item ? (
      <div
        data-testid="literature-pdf-preview"
        data-allow-reading-context={String(allowReadingContext)}
      >
        {`${item.title} · ${item.path}`}
        <button type="button" onClick={() => onClose()}>
          Close PDF
        </button>
        {onReadWithAgent ? (
          <button type="button" onClick={() => onReadWithAgent(item)}>
            Read with agent
          </button>
        ) : null}
      </div>
    ) : null
  }
}))

const inboxPage: LiteratureCatalogSearchPage = {
  entries: [
    {
      id: 'candidate-1',
      state: 'pending',
      candidate: {
        item: {
          itemType: 'journalArticle',
          title: 'Corrective Retrieval Augmented Generation',
          abstract: 'A corrective retrieval method.',
          issuedText: '2024',
          issuedYear: 2024,
          containerTitle: 'arXiv',
          shortTitle: '',
          language: 'en',
          rights: '',
          url: '',
          extra: '',
          typeFields: {},
          creators: [
            { nameMode: 'person', givenName: 'Shi-Qi', familyName: 'Yan', creatorType: 'author' }
          ],
          identifiers: [{ scheme: 'doi', value: '10.0000/example', isPrimary: true }]
        },
        source: {
          provider: 'Agent search',
          sourceUrl: 'https://example.test/paper',
          rawMetadata: {}
        },
        origin: { kind: 'agent', projectId: 'project-1', sessionId: 'session-1' }
      },
      createdAt: 1,
      updatedAt: 1
    }
  ]
}

const libraryItem: LiteratureItemView = {
  id: 'item-1',
  item: (inboxPage.entries[0] as LiteratureInboxCandidateView).candidate.item,
  attachments: [],
  projectIds: [],
  collectionIds: [],
  metadataRevision: 1,
  createdAt: 1,
  updatedAt: 1
}

const createLibraryItem = (index: number): LiteratureItemView => ({
  ...libraryItem,
  id: `item-${index}`,
  item: {
    ...libraryItem.item,
    title: `Reference ${index}`,
    issuedYear: 2024 - (index % 5)
  },
  metadataRevision: index + 1,
  createdAt: index + 1,
  updatedAt: index + 1
})

const openMenu = async (trigger: Element): Promise<void> => {
  act(() => {
    trigger.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }))
  })
  await act(async () => {
    await Promise.resolve()
  })
}

const openReferenceDetail = async (trigger: Element): Promise<HTMLElement> => {
  fireEvent.click(trigger)
  const dialog = screen.getByRole('dialog')
  await waitFor(() => expect(within(dialog).queryByRole('status')).toBeNull())
  return dialog
}

describe('LiteratureLibraryPage recovery behavior', () => {
  const search = vi.fn()
  const get = vi.fn()
  const formatReferences = vi.fn()
  const citationStyles = vi.fn()
  const completeMetadata = vi.fn()
  const fullText = vi.fn()
  const importRecords = vi.fn()
  const transact = vi.fn().mockResolvedValue({ kind: 'item', id: 'item-1', state: 'present' })
  const importPdf = vi.fn()
  const stageLocalFile = vi.fn()
  const claimLocalFile = vi.fn().mockResolvedValue(undefined)
  const deleteUpload = vi.fn().mockResolvedValue(undefined)
  const filterPdfContextCandidates = vi.fn()
  const createProjectApi = vi.fn()
  const startPdfReadingConversation = vi.fn()
  const startPdfReadingConversations = vi.fn(() => true)
  const startLiteratureReviewConversation = vi.fn(() => true)
  const saveBlobFile = vi.fn()

  beforeEach(() => {
    window.localStorage.clear()
    window.sessionStorage.clear()
    useNavigationStore.setState({
      view: 'library',
      activeProjectId: undefined,
      pendingLiteratureItemId: undefined,
      pendingLiteratureProjectId: undefined,
      pendingLiteratureCollectionId: undefined,
      startPdfReadingConversation,
      startPdfReadingConversations,
      startLiteratureReviewConversation
    })
    useProjectStore.setState({
      ...createInitialProjectState(),
      projects: [
        {
          id: 'project-1',
          name: 'Retrieval research',
          description: '',
          isExample: false,
          createdAt: 1,
          updatedAt: 1
        }
      ],
      isLoaded: true
    })
    useTagStore.setState({
      ...createInitialTagState(),
      status: 'ready',
      revision: 1,
      tags: [{ id: 'tag-favorite', systemKey: 'favorite', createdAt: 1, updatedAt: 1 }],
      assignments: [
        {
          tagId: 'tag-favorite',
          resourceType: 'literature.item',
          resourceId: libraryItem.id,
          createdAt: 1
        }
      ]
    })
    search.mockImplementation((request: { scope: string }) =>
      Promise.resolve(request.scope === 'inbox' ? inboxPage : { entries: [] })
    )
    filterPdfContextCandidates.mockImplementation(
      (request: { sources: readonly { sourceKind: string; sourceVersionId: string }[] }) =>
        Promise.resolve({ sources: request.sources, pendingAttachmentIds: [] })
    )
    createProjectApi.mockResolvedValue({
      id: 'reading-project',
      name: 'Reading project',
      description: '',
      agentContext: '',
      isExample: false,
      createdAt: 2,
      updatedAt: 2
    } satisfies Project)
    startPdfReadingConversation.mockReturnValue(true)
    saveBlobFile.mockResolvedValue({ saved: true, filePath: '/tmp/references.bib' })
    get.mockResolvedValue(undefined)
    formatReferences.mockResolvedValue({
      references: [
        {
          itemId: libraryItem.id,
          inText: '(Yan, 2024)',
          reference: 'Yan, S.-Q. (2024). Corrective Retrieval Augmented Generation.'
        }
      ],
      exports: {
        bibtex: '@article{item-1, title = {Corrective Retrieval Augmented Generation}}',
        ris: 'TY  - JOUR\nTI  - Corrective Retrieval Augmented Generation\nER  -'
      }
    })
    citationStyles.mockResolvedValue({
      styles: [
        { id: 'apa', title: 'APA Style 7th edition', source: 'built-in' },
        { id: 'mla', title: 'Modern Language Association 9th edition', source: 'built-in' },
        { id: 'vancouver', title: 'Vancouver', source: 'built-in' }
      ]
    })
    importRecords.mockImplementation((request: { mode: 'commit' | 'preview' }) =>
      Promise.resolve({
        format: 'bibtex',
        items: [libraryItem.item],
        entries: [
          {
            index: 0,
            title: libraryItem.item.title,
            status: 'ready',
            warnings: [],
            item: libraryItem.item
          }
        ],
        errors: [],
        truncated: false,
        scannedEntries: 1,
        ...(request.mode === 'commit'
          ? { imported: { itemIds: [libraryItem.id], createdCount: 1, reusedCount: 0 } }
          : {})
      })
    )
    completeLiteraturePdfDraft.mockImplementation(async (draft: LiteratureItemInput) => draft)
    extractLiteraturePdfDraft.mockImplementation((_file: File, fallback: LiteratureItemInput) =>
      Promise.resolve(fallback)
    )
    completeMetadata.mockImplementation((request: { mode: 'commit' | 'preview' }) => {
      const completedItem = {
        ...libraryItem,
        metadataRevision: request.mode === 'commit' ? 2 : 1,
        item: {
          ...libraryItem.item,
          containerTitle: 'Journal of Retrieval',
          typeFields: { volume: '12', issue: '3', pages: '44-58' }
        }
      }
      return Promise.resolve({
        mode: request.mode,
        provider: 'crossref',
        sourceUrl: 'https://api.crossref.org/works/10.0000%2Fexample',
        item: completedItem,
        filled: [
          { field: 'journal', value: 'Journal of Retrieval' },
          { field: 'volume', value: '12' },
          { field: 'issue', value: '3' },
          { field: 'pages', value: '44-58' }
        ],
        conflicts:
          request.mode === 'preview'
            ? [
                {
                  field: 'title',
                  currentValue: 'Corrective Retrieval Augmented Generation',
                  value: 'Corrective RAG'
                }
              ]
            : []
      })
    })
    Object.defineProperty(navigator, 'clipboard', {
      configurable: true,
      value: { writeText: vi.fn().mockResolvedValue(undefined) }
    })
    Object.defineProperty(window, 'api', {
      configurable: true,
      value: {
        platform: 'darwin',
        saveBlobFile,
        literature: {
          lookupMetadata: vi.fn(async () => libraryItem.item),
          jobs: vi.fn(async () => ({ jobs: [], summaries: [] })),
          search,
          transact,
          get,
          completeMetadata,
          fullText,
          citationStyles,
          formatDocument: vi.fn(),
          formatReferences,
          importPdf,
          importRecords
        },
        uploads: {
          stageLocalFile,
          claimLocalFile,
          deleteUpload,
          finalizeSession: vi.fn(),
          beginTransfer: vi.fn(),
          appendTransfer: vi.fn(),
          getTransferStatus: vi.fn(),
          finishTransfer: vi.fn(),
          abortTransfer: vi.fn()
        } as unknown as Window['api']['uploads'],
        sessions: {
          filterPdfContextCandidates
        } as unknown as Window['api']['sessions'],
        projects: {
          create: createProjectApi
        } as unknown as Window['api']['projects'],
        tags: {
          snapshot: vi.fn().mockResolvedValue({
            revision: 1,
            tags: [{ id: 'tag-favorite', systemKey: 'favorite', createdAt: 1, updatedAt: 1 }],
            assignments: [
              {
                tagId: 'tag-favorite',
                resourceType: 'literature.item',
                resourceId: libraryItem.id,
                createdAt: 1
              }
            ]
          }),
          create: vi.fn(),
          update: vi.fn(),
          delete: vi.fn(),
          reorder: vi.fn(),
          setAssignment: vi.fn(),
          onChanged: vi.fn(() => () => undefined)
        } as unknown as Window['api']['tags']
      } satisfies Partial<Window['api']>
    })
  })

  afterEach(() => {
    cleanup()
    vi.clearAllMocks()
    vi.unstubAllGlobals()
  })

  // A failed initial load must settle into a retryable error rather than spinning
  // forever or claiming the list is empty — and a retry must recover.
  it('surfaces a retryable error after a failed initial load and recovers on retry', async () => {
    search.mockImplementation((request: LiteratureCatalogSearchRequest) =>
      request.scope === 'inbox' && request.limit !== 1
        ? Promise.reject(new Error('Inbox unavailable'))
        : Promise.resolve({ entries: [], totalCount: 0 })
    )
    render(<LiteratureLibraryPage />)
    await act(async () => {})
    expect(
      search.mock.calls.some(([request]) => request.scope === 'inbox' && request.limit !== 1)
    ).toBe(true)
    expect(screen.queryByText('Literature could not be loaded.')).not.toBeNull()
    expect(screen.queryByText('Loading…')).toBeNull()
    expect(screen.queryByText('Inbox is clear')).toBeNull()
    search.mockImplementation((request: LiteratureCatalogSearchRequest) =>
      Promise.resolve(request.scope === 'inbox' ? inboxPage : { entries: [] })
    )
    fireEvent.click(screen.getByRole('button', { name: 'Retry' }))
    await screen.findByText(libraryItem.item.title)
    expect(screen.queryByText('Literature could not be loaded.')).toBeNull()
  })

  // Collection navigation must page all the way through; nothing past the first
  // page may be stranded.
  it('makes every collection reachable when navigation spans multiple pages', async () => {
    const collections = Array.from({ length: 101 }, (_, index) => ({
      id: `collection-${index + 1}`,
      name: `Collection ${index + 1}`,
      description: '',
      itemCount: 0,
      createdAt: 1,
      updatedAt: 1
    }))
    search.mockImplementation((request: LiteratureCatalogSearchRequest) => {
      const offset = request.offset ?? 0
      return Promise.resolve(
        request.scope === 'collections'
          ? {
              entries: collections.slice(offset, offset + 100),
              totalCount: 101,
              nextOffset: offset === 0 ? 100 : undefined
            }
          : { entries: [], totalCount: 0 }
      )
    })
    render(<LiteratureLibraryPage />)
    fireEvent.click(await screen.findByRole('button', { name: 'Show all collections' }))
    await act(async () => {})
    expect(screen.queryByRole('button', { name: 'Collection 100' })).not.toBeNull()
    expect(screen.queryByRole('button', { name: 'Collection 101' })).not.toBeNull()
  })

  // Edits typed into the metadata form must not be discarded while a save is in
  // flight: either the form is locked so nothing new can be typed, or what was
  // typed during the save is still there once the save completes.
  it('prevents metadata edits from being lost while a save is in flight', async () => {
    search.mockImplementation((request: LiteratureCatalogSearchRequest) =>
      Promise.resolve(request.scope === 'library' ? { entries: [libraryItem] } : { entries: [] })
    )
    get.mockResolvedValue(libraryItem)
    let finish: () => void = () => {}
    transact.mockImplementationOnce(
      () =>
        new Promise((resolve) => {
          finish = () => resolve({ kind: 'item', id: libraryItem.id, state: 'present' })
        })
    )
    render(<LiteratureLibraryPage />)
    fireEvent.click(screen.getByRole('button', { name: 'All references' }))
    await openReferenceDetail(await screen.findByText(libraryItem.item.title))
    await openMenu(screen.getByRole('button', { name: 'More actions' }))
    fireEvent.click(screen.getByRole('menuitem', { name: 'Edit metadata' }))
    const title = screen.getByLabelText('Title') as HTMLInputElement
    fireEvent.change(title, { target: { value: 'Submitted title' } })
    fireEvent.click(screen.getByRole('button', { name: 'Save' }))
    expect((screen.getByRole('button', { name: 'Save' }) as HTMLButtonElement).disabled).toBe(true)
    const locked = title.matches(':disabled') || title.readOnly
    if (!locked) fireEvent.change(title, { target: { value: 'New unsaved title' } })
    expect(title.value).toBe(locked ? 'Submitted title' : 'New unsaved title')
    get.mockResolvedValue({
      ...libraryItem,
      metadataRevision: 2,
      item: { ...libraryItem.item, title: 'Submitted title' }
    })
    await act(async () => finish())
    expect(transact).toHaveBeenCalledTimes(1)
    expect(
      locked ||
        (screen.queryByLabelText('Title') as HTMLInputElement | null)?.value === 'New unsaved title'
    ).toBe(true)
  })

  // When a later lifecycle batch fails, the already-committed references must be
  // reflected, the unresolved stragglers stay selected, the failure is reported,
  // and retrying re-attempts only what is left, not the whole original selection.
  // Retrying may go through a Retry button or by repeating the action on the
  // remaining selection; a Retry that re-sends nothing leaves the selection path.
  it('refreshes committed references and retries only the stragglers after a partial failure', async () => {
    let items = Array.from({ length: 201 }, (_, index) => createLibraryItem(index))
    search.mockImplementation((request: LiteratureCatalogSearchRequest) => {
      if (request.scope !== 'library') return Promise.resolve({ entries: [] })
      const offset = request.offset ?? 0
      const limit = request.limit ?? 100
      return Promise.resolve({
        entries: items.slice(offset, offset + limit),
        totalCount: items.length,
        nextOffset: offset + limit < items.length ? offset + limit : undefined
      })
    })
    transact
      .mockImplementationOnce(async (command) => {
        items = items.filter(({ id }) => !command.itemIds.includes(id))
        return { kind: 'item', id: command.itemIds[0], state: 'deleted' }
      })
      .mockRejectedValueOnce(new Error('A later batch is unavailable.'))
    render(<LiteratureLibraryPage />)
    fireEvent.click(screen.getByRole('button', { name: 'All references' }))
    await screen.findByText('Reference 0')
    fireEvent.click(screen.getByLabelText('Select all references'))
    fireEvent.click(screen.getByRole('button', { name: 'Select all matching references 201' }))
    const toolbar = (): HTMLElement =>
      document.querySelector<HTMLElement>('[data-slot="literature-selection-toolbar"]')!
    const alertsBefore = screen.queryAllByRole('alert').length
    await openMenu(within(toolbar()).getByRole('button', { name: 'More actions' }))
    fireEvent.click(screen.getByRole('menuitem', { name: 'Move to Trash' }))
    await act(async () => {})
    // Exactly the first bounded batch committed; the second was attempted and failed.
    expect(items).toHaveLength(1)
    expect(
      transact.mock.calls.filter(([command]) => command.kind === 'set-item-lifecycle')
    ).toHaveLength(2)
    // The list reflects reality: committed rows gone, untouched rows retained.
    expect(screen.queryByText('Reference 0')).toBeNull()
    expect(screen.queryByText('Reference 200')).not.toBeNull()
    // Only the single straggler stays selected, and the failure is shown.
    expect(screen.queryByText('1 selected')).not.toBeNull()
    expect(screen.queryAllByRole('alert').length).toBeGreaterThan(alertsBefore)
    transact.mockImplementationOnce(async (command) => {
      items = items.filter(({ id }) => !command.itemIds.includes(id))
      return { kind: 'item', id: command.itemIds[0], state: 'deleted' }
    })
    const lifecycleCalls = (): number =>
      transact.mock.calls.filter(([command]) => command.kind === 'set-item-lifecycle').length
    const callsBeforeRetry = lifecycleCalls()
    const retry = screen.queryAllByRole('button', { name: /retry/i })[0]
    if (retry) {
      fireEvent.click(retry)
      await act(async () => {})
    }
    if (lifecycleCalls() === callsBeforeRetry) {
      await openMenu(within(toolbar()).getByRole('button', { name: 'More actions' }))
      fireEvent.click(screen.getByRole('menuitem', { name: 'Move to Trash' }))
      await act(async () => {})
    }
    // Retrying re-attempts only the leftover reference, and it then applies.
    expect(transact).toHaveBeenLastCalledWith({
      kind: 'set-item-lifecycle',
      itemIds: ['item-200'],
      state: 'deleted'
    })
    expect(items).toHaveLength(0)
    // Recovery clears the partial-failure surface.
    expect(screen.queryAllByRole('alert').length).toBeLessThanOrEqual(alertsBefore)
  })

  // Project and collection counts must track only visible references through a
  // Trash and Restore round-trip, including dropping to zero.
  it('refreshes project and collection counts through delete and restore, including zero', async () => {
    let deleted = false
    search.mockImplementation((request: LiteratureCatalogSearchRequest) => {
      if (request.scope === 'project-counts')
        return Promise.resolve({
          entries: deleted ? [] : [{ projectId: 'project-1', itemCount: 1 }]
        })
      if (request.scope === 'collections')
        return Promise.resolve({
          entries: [
            {
              id: 'collection-reading',
              name: 'Reading',
              description: '',
              itemCount: deleted ? 0 : 1,
              createdAt: 1,
              updatedAt: 1
            }
          ]
        })
      if (request.scope === 'library') {
        const visible = (request.lifecycle === 'deleted') === deleted
        return Promise.resolve({
          entries: visible ? [libraryItem] : [],
          totalCount: visible ? 1 : 0
        })
      }
      return Promise.resolve({ entries: [] })
    })
    render(<LiteratureLibraryPage />)
    fireEvent.click(screen.getByRole('button', { name: 'All references' }))
    for (const [action, expectedCount] of [
      ['Move to Trash', '0'],
      ['Restore', '1']
    ] as const) {
      const row = (await screen.findByText(libraryItem.item.title)).closest('tr')!
      await openMenu(within(row).getByRole('button', { name: 'More actions' }))
      transact.mockImplementationOnce(async () => {
        deleted = !deleted
        return { kind: 'item', id: libraryItem.id, state: deleted ? 'deleted' : 'active' }
      })
      fireEvent.click(screen.getByRole('menuitem', { name: action }))
      await act(async () => {})
      expect(
        within(screen.getByRole('button', { name: 'Retrieval research' })).getByText(expectedCount)
      ).not.toBeNull()
      expect(
        within(screen.getByRole('button', { name: 'Reading' })).getByText(expectedCount)
      ).not.toBeNull()
      if (deleted) fireEvent.click(screen.getByRole('button', { name: 'Trash' }))
    }
  })

  // A failed continuation page surfaces a retryable error, and retry restores
  // full reachability of the collection list.
  it('surfaces a retryable error when a collection continuation page fails and recovers on retry', async () => {
    const collections = Array.from({ length: 101 }, (_, index) => ({
      id: `c-${index}`,
      name: `Collection ${index}`,
      description: '',
      itemCount: 0,
      createdAt: 1,
      updatedAt: 1
    }))
    let fail = true
    search.mockImplementation((request: LiteratureCatalogSearchRequest) => {
      if (request.scope !== 'collections') return Promise.resolve({ entries: [] })
      if (request.offset === 100 && fail) return Promise.reject(new Error('Page unavailable'))
      return Promise.resolve({
        entries: collections.slice(request.offset ?? 0, (request.offset ?? 0) + 100),
        nextOffset: request.offset === 100 ? undefined : 100,
        totalCount: 101
      })
    })
    render(<LiteratureLibraryPage />)
    await act(async () => {})
    expect(screen.getByText('Literature could not be loaded.')).not.toBeNull()
    fail = false
    fireEvent.click(screen.getByRole('button', { name: 'Retry' }))
    fireEvent.click(await screen.findByRole('button', { name: 'Show all collections' }))
    expect(screen.getByRole('button', { name: 'Collection 100' })).not.toBeNull()
  })
})
