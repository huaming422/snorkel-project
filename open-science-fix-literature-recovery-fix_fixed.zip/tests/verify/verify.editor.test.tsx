// @vitest-environment jsdom
import { cleanup, fireEvent, render, screen } from '@testing-library/react'
import { afterEach, describe, expect, it, vi } from 'vitest'

import { literatureItemInputSchema } from '../../../../shared/literature'
import { LiteratureMetadataEditor } from './LiteratureMetadataEditor'

afterEach(cleanup)

describe('LiteratureMetadataEditor save locking', () => {
  // While a save is in flight the draft-editing controls are either all locked
  // (disabled or read-only, not just dimmed) or all left editable; locking only
  // some of them leaves the rest open to edits that the save then drops. A
  // submitted draft is retained across a failed save, and the form is editable
  // again once saving ends. Save and Cancel are not draft-editing controls, and
  // neither is a disclosure toggle that only shows or hides a group of fields.
  it('locks all or none of the draft-editing controls while saving and retains the draft after failure', () => {
    const item = literatureItemInputSchema.parse({
      itemType: 'journalArticle',
      title: 'Original',
      typeFields: { volume: '1' },
      creators: [{ nameMode: 'person', givenName: 'A', familyName: 'B', creatorType: 'author' }],
      identifiers: [{ scheme: 'doi', value: '10.1234/example', isPrimary: true }]
    })
    const onSave = vi.fn()
    const props = { item, onSave, onCancel: vi.fn() }
    const { container, rerender } = render(<LiteratureMetadataEditor {...props} saving={false} />)
    fireEvent.change(screen.getByLabelText('Title'), { target: { value: 'Draft title' } })
    fireEvent.click(screen.getByRole('button', { name: 'Save' }))
    expect(onSave).toHaveBeenCalledWith(expect.objectContaining({ title: 'Draft title' }))
    rerender(<LiteratureMetadataEditor {...props} saving />)
    const submitControls = [
      screen.getByRole('button', { name: 'Save' }),
      screen.getByRole('button', { name: 'Cancel' })
    ]
    const controls = [...container.querySelectorAll('input, textarea, button')].filter(
      (control) =>
        !control.matches('[aria-expanded]:not([role="combobox"])') &&
        !submitControls.includes(control as HTMLElement)
    )
    expect(controls.length).toBeGreaterThan(15)
    const locked = (control: Element): boolean =>
      control.matches(':disabled') ||
      (control.matches('textarea, input:not([type="radio"]):not([type="checkbox"])') &&
        (control as HTMLInputElement).readOnly)
    const lockedCount = controls.filter(locked).length
    if (lockedCount > 0) {
      expect(
        controls.filter((control) => !locked(control)).map((control) => control.outerHTML)
      ).toEqual([])
    }
    rerender(<LiteratureMetadataEditor {...props} saving={false} error="Save failed" />)
    expect((screen.getByLabelText('Title') as HTMLInputElement).value).toBe('Draft title')
    expect(screen.getByRole('alert').textContent).toBe('Save failed')
    expect(screen.getByRole('button', { name: 'Add author' }).matches(':disabled')).toBe(false)
    expect(screen.getByRole('combobox', { name: 'Reference type' }).matches(':disabled')).toBe(false)
  })
})
