## Task

Several things in the References library misbehave, and I'd like them sorted out together.

If loading references fails, the list can sit on its spinner indefinitely, or it shows the empty-state message ("Inbox is clear" and similar) as though there were simply nothing there. A failed load should end in an error with a Retry, and retrying should bring the list back once the data is reachable again. The sidebar's collection list is the same: when part of it can't be fetched, show the error and let people retry.

Moving a large selection to Trash, or restoring one, can stop partway. When that happens the screen should show what actually changed, keep only the references that didn't go through selected, make it clear that something failed, and let the person retry just those. Whatever the app reports as not done has to really be untouched in the library, not half changed.

Someone editing a reference's metadata who keeps typing while the save is still running loses what they typed.

The project and collection counts in the sidebar still include references sitting in Trash. Trashing the last reference in a project or collection should take its count to zero, and restoring it should bring the count back.

Anyone with more than a hundred collections can't get to the ones past the hundredth.
