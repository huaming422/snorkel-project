## Task

Opening a file that isn't a database fails with the wrong error. A kilobyte of zeros, a hundred bytes of junk, or a database whose header got damaged comes back as a corrupt database with an invalid page size, or as a short read on page 1, and some of them even open. SQLite says "file is not a database" (SQLITE_NOTADB) for every one of these files, and turso should report them the same way. A real database that was only cut short is still a damaged database, not a foreign file, and SQLite does not call it "not a database" either.
