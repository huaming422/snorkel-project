#!/usr/bin/env bash
# Test-setup for turso-fix-garbage-header-notadb.
#
# The image (block 7) already ran `cargo build --workspace --lib --tests` at the
# base commit, so the registry is fully populated and the target dir is warm.
# This script pre-warms the two crates the verifier touches so a verify cycle
# only recompiles the injected integration test plus whatever the agent changed
# in `turso_core`:
#   - turso_core  : the library the fix lives in
#   - core_tester : the workspace test crate (package at /repo/turso/tests),
#                   a normal consumer of turso_core that already depends on
#                   rusqlite + tempfile — where the behavioral integration test
#                   is hosted.
#
# Offline-first: the dependency closure is baked into the image, so the build
# runs with the network sealed. CARGO_NET_OFFLINE keeps cargo from reaching out;
# a logged online fallback covers the (not expected) case of a cache miss.

set -euo pipefail

cd /repo/turso

echo "[test-setup] Rust version:   $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:  $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root: /repo/turso"

export CARGO_NET_OFFLINE=true

warm() {
    cargo build --locked --offline -p turso_core \
        && cargo build --locked --offline -p core_tester --tests
}

if ! warm > /tmp/test-setup-warm.log 2>&1; then
    echo "[test-setup] offline pre-warm hit a cache miss; retrying online" >&2
    tail -40 /tmp/test-setup-warm.log >&2 || true
    unset CARGO_NET_OFFLINE
    cargo build --locked -p turso_core
    cargo build --locked -p core_tester --tests
fi

echo "[test-setup] Setup complete."
