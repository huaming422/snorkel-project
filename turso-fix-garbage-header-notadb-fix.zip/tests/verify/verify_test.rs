//! Behavioral checks for the "file is not a database" classification.
//!
//! The not-a-database checks build a file that is not a valid database, open it
//! through the engine's public file-open API, and confirm the engine reports it
//! as `LimboError::NotADB` (SQLite result code 26, SQLITE_NOTADB). The same file
//! is opened with the bundled SQLite bindings first, pinning the reference
//! behavior: SQLite rejects every one of these files as "file is not a
//! database". The file-open API and the error variant both pre-date this work,
//! so these checks say nothing about how the header-reading path is structured
//! internally.
//!
//! The other checks guard the opposite direction, where the engine must NOT
//! answer "not a database":
//!   * a real SQLite database cut short (a truncated copy). SQLite reports these
//!     as malformed, not as "not a database", and the engine's own
//!     short-read test expects the short read to be surfaced;
//!   * a database opened through a page codec, whose header bytes the codec may
//!     transform, so a short codec read is surfaced as-is;
//!   * an encrypted database. It must still open with its key, and a truncated
//!     copy of it is a damaged database, not a foreign file.
//! These assert the absence of `NotADB` rather than one exact error, so any
//! reasonable way of surfacing the damage passes.

use std::path::Path;
use std::sync::Arc;

use turso_core::storage::database::DatabaseFile;
use turso_core::{
    CipherMode, Connection, Database, DatabaseOpts, EncryptionKey, EncryptionOpts, LimboError,
    OpenFlags, OpenOptions, PageCodec, PageCodecContext, PageCodecId, SqliteDialect,
};

const HEXKEY: &str = "b1bbfda4f589dc9daaf004fe21111e00dc00c98237102f5c7002a5669fc76327";

/// Open a file through the engine's public file-open entry point with no
/// encryption (plain open). The header is read during this call, so a bad
/// header surfaces here.
fn open_through_public_api(path: &Path) -> turso_core::Result<Arc<Database>> {
    let io: Arc<dyn turso_core::IO + Send> = Arc::new(turso_core::PlatformIO::new().unwrap());
    Database::open_file_with_flags(
        io,
        path.to_str().unwrap(),
        OpenFlags::Create,
        DatabaseOpts::new(),
        None,
        Arc::new(SqliteDialect),
    )
}

/// Open a file through the public file-open entry point with an AEGIS-256
/// cipher and a fixed key configured.
fn open_encrypted(
    io: Arc<dyn turso_core::IO + Send>,
    path: &Path,
) -> turso_core::Result<Arc<Database>> {
    let enc = EncryptionOpts {
        cipher: "aegis256".to_string(),
        hexkey: HEXKEY.to_string(),
    };
    Database::open_file_with_flags(
        io,
        path.to_str().unwrap(),
        OpenFlags::Create,
        DatabaseOpts::new().with_encryption(true),
        Some(enc),
        Arc::new(SqliteDialect),
    )
}

/// Open an encrypted file and connect with its cipher and key set on the
/// connection.
fn connect_encrypted(
    io: Arc<dyn turso_core::IO + Send>,
    path: &Path,
) -> turso_core::Result<Arc<Connection>> {
    let db = open_encrypted(io, path)?;
    let conn = db.connect()?;
    conn.set_encryption_cipher(CipherMode::Aegis256)?;
    conn.set_encryption_key(EncryptionKey::from_hex_string(HEXKEY)?)?;
    Ok(conn)
}

/// Open a file through the public `OpenOptions` builder with a page codec
/// configured. Routes the header read down the codec branch.
fn open_with_page_codec(path: &Path, codec: Arc<dyn PageCodec>) -> turso_core::Result<Arc<Database>> {
    let io: Arc<dyn turso_core::IO + Send> = Arc::new(turso_core::PlatformIO::new().unwrap());
    let file = io
        .open_file(path.to_str().unwrap(), OpenFlags::Create, false)
        .unwrap();
    let db_file = Arc::new(DatabaseFile::new(file));
    Database::open(
        io,
        path.to_str().unwrap(),
        OpenOptions::new(Arc::new(SqliteDialect))
            .storage(db_file)
            .flags(OpenFlags::Create)
            .page_codec(codec),
    )
}

/// Read the schema through a connection, returning the first error.
fn read_schema(conn: &Arc<Connection>) -> turso_core::Result<()> {
    if let Some(mut stmt) = conn.query("SELECT count(*) FROM sqlite_schema")? {
        stmt.run_with_row_callback(|_| Ok(()))?;
    }
    Ok(())
}

/// Open, connect and read the schema of a plain file, returning the first
/// error any step reports. Damage may surface at open, at connect or at the
/// first read, depending on how a fix is built, so every step is tried.
fn open_connect_and_read(path: &Path) -> turso_core::Result<()> {
    let db = open_through_public_api(path)?;
    let conn = db.connect()?;
    read_schema(&conn)
}

/// The SQLite result code for opening this file and reading its schema, or
/// `None` when SQLite reads it without an error. SQLite opens lazily, so the
/// query forces the header read.
fn sqlite_error_code(path: &Path) -> Option<rusqlite::ErrorCode> {
    let conn = rusqlite::Connection::open(path).unwrap();
    match conn.query_row("SELECT count(*) FROM sqlite_schema", [], |_| Ok(())) {
        Ok(()) => None,
        Err(rusqlite::Error::SqliteFailure(e, _)) => Some(e.code),
        Err(other) => panic!("unexpected rusqlite error {other:?} for {}", path.display()),
    }
}

/// Reference behavior: SQLite must refuse this file as "file is not a database"
/// (SQLITE_NOTADB).
fn assert_sqlite_rejects_as_not_a_database(path: &Path) {
    assert_eq!(
        sqlite_error_code(path),
        Some(rusqlite::ErrorCode::NotADatabase),
        "sqlite did not report SQLITE_NOTADB for {}",
        path.display()
    );
}

/// The engine must agree with SQLite: this file is not a database. The answer
/// may come at open, at connect or at the first read of the schema.
fn assert_engine_reports_not_a_database(path: &Path) {
    match open_connect_and_read(path) {
        Err(LimboError::NotADB) => {}
        Err(other) => panic!("expected NotADB for {}, got {other:?}", path.display()),
        Ok(()) => panic!(
            "expected NotADB for {}, but it opened and its schema was read",
            path.display()
        ),
    }
}

/// Build a real SQLite database with the bundled SQLite: one table with a few
/// dozen rows, at the given page size, in rollback-journal mode so every page
/// is in the main file.
fn write_sqlite_database(path: &Path, page_size: u32) -> Vec<u8> {
    let conn = rusqlite::Connection::open(path).unwrap();
    conn.execute_batch(&format!(
        "PRAGMA page_size = {page_size};
         CREATE TABLE notes (id INTEGER PRIMARY KEY, body TEXT);"
    ))
    .unwrap();
    for i in 0..400 {
        conn.execute(
            "INSERT INTO notes (body) VALUES (?1)",
            [format!("note number {i}, kept for the weekly review")],
        )
        .unwrap();
    }
    drop(conn);
    std::fs::read(path).unwrap()
}

/// A full-length file whose header is garbage (a kilobyte of zero bytes: no
/// SQLite magic, page-size field reads as zero) must come back as "file is not
/// a database", matching SQLite, instead of a corruption/allocation error
/// derived from the bogus page-size field.
#[test]
fn notadb_garbage_full_header() {
    let tmp_dir = tempfile::TempDir::new().unwrap();
    let path = tmp_dir.path().join("garbage.db");
    std::fs::write(&path, vec![0u8; 1050]).unwrap();

    assert_sqlite_rejects_as_not_a_database(&path);
    assert_engine_reports_not_a_database(&path);
}

/// A non-empty file shorter than the header, made of junk bytes with no SQLite
/// magic, must come back as "file is not a database" rather than a bare
/// short-read error. SQLite zero-fills the missing bytes and then rejects the
/// header, so the short junk file is classified the same way any other file is.
#[test]
fn notadb_short_junk() {
    let tmp_dir = tempfile::TempDir::new().unwrap();
    let path = tmp_dir.path().join("short-junk.db");
    std::fs::write(&path, vec![0x42u8; 100]).unwrap();

    assert_sqlite_rejects_as_not_a_database(&path);
    assert_engine_reports_not_a_database(&path);
}

/// A non-empty short file that DOES begin with the SQLite magic string but is
/// otherwise empty must still come back as "file is not a database": its
/// page-size field is zero, so it fails the page-size rule. Presence of the
/// magic bytes alone does not make it a database.
#[test]
fn notadb_short_with_magic() {
    let tmp_dir = tempfile::TempDir::new().unwrap();
    let path = tmp_dir.path().join("short-with-magic.db");
    let mut bytes = b"SQLite format 3\0".to_vec();
    bytes.resize(100, 0);
    std::fs::write(&path, bytes).unwrap();

    assert_sqlite_rejects_as_not_a_database(&path);
    assert_engine_reports_not_a_database(&path);
}

/// A full-length file with the SQLite magic whose page-size field is not a
/// power of two (a real database with that one field damaged). SQLite rejects
/// it as "file is not a database"; the engine must agree rather than report a
/// corruption error derived from the bad page size. The magic alone does not
/// decide this file.
#[test]
fn notadb_full_header_bad_page_size() {
    let tmp_dir = tempfile::TempDir::new().unwrap();
    let source = tmp_dir.path().join("source.db");
    let mut bytes = write_sqlite_database(&source, 4096);
    bytes[16..18].copy_from_slice(&1000u16.to_be_bytes());
    let path = tmp_dir.path().join("bad-page-size.db");
    std::fs::write(&path, &bytes).unwrap();

    assert_sqlite_rejects_as_not_a_database(&path);
    assert_engine_reports_not_a_database(&path);
}

/// A full-length file with the SQLite magic and a valid 512-byte page size,
/// but a reserved-space byte of 255, leaving 257 usable bytes per page. SQLite
/// needs at least 480 usable bytes and rejects the file as "file is not a
/// database"; the engine must agree.
#[test]
fn notadb_full_header_too_little_usable_space() {
    let tmp_dir = tempfile::TempDir::new().unwrap();
    let source = tmp_dir.path().join("source.db");
    let mut bytes = write_sqlite_database(&source, 512);
    bytes[20] = 255;
    let path = tmp_dir.path().join("reserved-space.db");
    std::fs::write(&path, &bytes).unwrap();

    assert_sqlite_rejects_as_not_a_database(&path);
    assert_engine_reports_not_a_database(&path);
}

/// A real SQLite database cut short is a damaged database, not a foreign file.
/// SQLite reports these copies as malformed (SQLITE_CORRUPT), never as
/// SQLITE_NOTADB, and the engine's own short-read test expects a database cut
/// to 50 bytes to surface its short read. So the engine must not answer
/// "not a database" for them. The cut points sit inside the 100-byte header,
/// past the header but inside the first page, and past the first page.
#[test]
fn truncated_real_database_not_classified_as_notadb() {
    let tmp_dir = tempfile::TempDir::new().unwrap();
    let source = tmp_dir.path().join("source.db");
    let bytes = write_sqlite_database(&source, 4096);
    assert!(bytes.len() > 8192, "the source database is too small");

    for cut in [50usize, 300, 6000] {
        let path = tmp_dir.path().join(format!("truncated-{cut}.db"));
        std::fs::write(&path, &bytes[..cut]).unwrap();

        let sqlite_code = sqlite_error_code(&path);
        assert_ne!(
            sqlite_code,
            Some(rusqlite::ErrorCode::NotADatabase),
            "sqlite reported SQLITE_NOTADB for a database cut to {cut} bytes"
        );

        let result = open_connect_and_read(&path);
        assert!(
            !matches!(result, Err(LimboError::NotADB)),
            "a real database cut to {cut} bytes was reported as not a database; \
             it is a damaged database. Got: {result:?}"
        );
    }
}

/// An identity page codec: encodes/decodes a page to itself and keeps the
/// SQLite header fields visible. It stands in for any external page codec.
/// What matters is that the database is opened through a codec, which routes
/// header reading down the codec branch.
#[derive(Debug)]
struct IdentityPageCodec;

impl PageCodec for IdentityPageCodec {
    fn codec_id(&self) -> PageCodecId {
        PageCodecId::new(*b"identity-codec--")
    }

    fn required_reserved_bytes(&self) -> u8 {
        0
    }

    fn encode_page(
        &self,
        _context: PageCodecContext,
        input: &[u8],
        output: &mut [u8],
    ) -> turso_core::Result<()> {
        output.copy_from_slice(input);
        Ok(())
    }

    fn decode_page(
        &self,
        _context: PageCodecContext,
        input: &[u8],
        output: &mut [u8],
    ) -> turso_core::Result<()> {
        output.copy_from_slice(input);
        Ok(())
    }
}

/// A page-codec database whose header read comes up short must NOT be
/// reclassified as `LimboError::NotADB`. A codec may transform the header
/// bytes, so the short read is surfaced as-is, as the engine's own codec test
/// (`page_codec_reopen_reports_short_header_read`) expects.
#[test]
fn codec_short_header_not_classified_as_notadb() {
    let tmp_dir = tempfile::TempDir::new().unwrap();
    let path = tmp_dir.path().join("codec-short-header.db");
    // One byte: far shorter than the header, so the header read comes up short
    // on the very first read.
    std::fs::write(&path, [0u8]).unwrap();

    let result = open_with_page_codec(&path, Arc::new(IdentityPageCodec));
    assert!(
        !matches!(result, Err(LimboError::NotADB)),
        "a short page-codec read was reported as not a database. A codec may \
         transform the header bytes, so the short read must be surfaced. Got: {result:?}"
    );
}

/// Write an encrypted database through the engine: one table, one row, then
/// close everything so the next open reads the file from disk.
fn write_encrypted_database(path: &Path) {
    let io: Arc<dyn turso_core::IO + Send> = Arc::new(turso_core::PlatformIO::new().unwrap());
    let conn = connect_encrypted(io.clone(), path).unwrap();
    conn.execute("CREATE TABLE secrets (id INTEGER PRIMARY KEY, body TEXT)")
        .unwrap();
    conn.execute("INSERT INTO secrets (body) VALUES ('kept')")
        .unwrap();
    conn.query("PRAGMA wal_checkpoint(TRUNCATE)").unwrap();
    for c in conn.cacheflush().unwrap() {
        io.wait_for_completion(c).unwrap();
    }
    conn.close().unwrap();
}

/// Count the rows of `secrets` in an encrypted database opened with its key.
fn count_encrypted_rows(path: &Path) -> turso_core::Result<i64> {
    let io: Arc<dyn turso_core::IO + Send> = Arc::new(turso_core::PlatformIO::new().unwrap());
    let conn = connect_encrypted(io, path)?;
    let mut count = None;
    if let Some(mut stmt) = conn.query("SELECT count(*) FROM secrets")? {
        stmt.run_with_row_callback(|row| {
            count = Some(row.get::<i64>(0)?);
            Ok(())
        })?;
    }
    conn.close()?;
    Ok(count.expect("count(*) returned no row"))
}

/// An encrypted database carries the engine's own encrypted-file prefix where
/// a plain file has the SQLite magic. It must keep opening with its key and
/// reading its rows; a fix that judges every header as plain SQLite would turn
/// it into "not a database".
#[test]
fn encrypted_database_still_opens_with_its_key() {
    let tmp_dir = tempfile::TempDir::new().unwrap();
    let path = tmp_dir.path().join("encrypted.db");
    write_encrypted_database(&path);

    let copy = tmp_dir.path().join("encrypted-copy.db");
    std::fs::copy(&path, &copy).unwrap();
    match count_encrypted_rows(&copy) {
        Ok(n) => assert_eq!(n, 1, "the encrypted database lost its row"),
        Err(err) => panic!("the encrypted database no longer opens with its key: {err:?}"),
    }
}

/// A truncated copy of an encrypted database, opened with its key, is a
/// damaged database, not a foreign file: its header still starts with the
/// engine's encrypted-file prefix. The engine must not answer "not a
/// database" for it.
#[test]
fn truncated_encrypted_database_not_classified_as_notadb() {
    let tmp_dir = tempfile::TempDir::new().unwrap();
    let path = tmp_dir.path().join("encrypted.db");
    write_encrypted_database(&path);
    let bytes = std::fs::read(&path).unwrap();

    for cut in [50usize, 300] {
        let copy = tmp_dir.path().join(format!("encrypted-truncated-{cut}.db"));
        std::fs::write(&copy, &bytes[..cut]).unwrap();
        let io: Arc<dyn turso_core::IO + Send> =
            Arc::new(turso_core::PlatformIO::new().unwrap());
        let result = connect_encrypted(io, &copy).and_then(|conn| read_schema(&conn));
        assert!(
            !matches!(result, Err(LimboError::NotADB)),
            "an encrypted database cut to {cut} bytes was reported as not a \
             database. Got: {result:?}"
        );
    }
}
