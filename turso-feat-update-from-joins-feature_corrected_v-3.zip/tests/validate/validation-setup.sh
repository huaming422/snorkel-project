#!/usr/bin/env bash
#
# SOURCED by tests/test.sh (`source /tests/validate/validation-setup.sh || true`)
# AFTER VERIFIER_PYTHON is exported and AFTER tests/test-setup.sh has already
# built + sanity-checked the engine binaries. Its only job is to bring the
# validation surface online and surface a readable diagnostic if something is
# off. The stories themselves are pytest files the driver runs under
# VERIFIER_PYTHON, driving SQL through the baked `tursodb` CLI via
# /tests/validate/test_harness.py (SQL text in -> parsed rows out).
#
# This file is `source`d, so it must not call `exit`. An `exit` here
# terminates test.sh before any reward file is written (RewardFileNotFoundError
# for the whole trial) and the caller's `|| true` cannot catch it. Any hard stop
# uses `return`, which the caller's `|| true` absorbs; the real failure then
# surfaces through run_validate.py's sanctioned infra-failure path (exit 2 +
# validation_results.json) instead of nuking the trial. Preflight problems here
# are therefore warned loudly but never fatal.
#
# Idempotent and safe to run on a warm container.

REPO_DIR="${REPO_DIR:-/repo/turso}"

# The image compiled the workspace at the base commit with CARGO_NET_OFFLINE so
# any cache miss fails fast rather than reaching a registry. Keep that posture in
# case the engine needs a (re)build below.
export CARGO_NET_OFFLINE="${CARGO_NET_OFFLINE:-true}"

# Binaries land under CARGO_TARGET_DIR (the image sets it to
# /opt/cache/cargo-target), not /repo/turso/target. The harness resolves tursodb
# via this same variable, so make sure it is exported for the pytest children.
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
TARGET_DIR="$CARGO_TARGET_DIR"

# test-setup.sh is supposed to have built tursodb already. If it is somehow
# absent, try one offline-first build here, then warn (never exit) so the
# downstream validation path can report the infra failure cleanly.
if [[ ! -x "$TARGET_DIR/debug/tursodb" ]]; then
    echo "[validation-setup] tursodb missing under $TARGET_DIR/debug; attempting build" >&2
    if [[ -d "$REPO_DIR" ]]; then
        if ( cd "$REPO_DIR" && cargo build --package turso_cli --offline ) > /tmp/validation-setup-tursodb.log 2>&1; then
            echo "[validation-setup] tursodb built from image bake"
        elif ( cd "$REPO_DIR" && cargo build --package turso_cli ) >> /tmp/validation-setup-tursodb.log 2>&1; then
            echo "[validation-setup] tursodb built online (image bake was stale)"
        else
            echo "[validation-setup] WARNING: tursodb failed to build:" >&2
            tail -40 /tmp/validation-setup-tursodb.log >&2
        fi
    fi
fi

if [[ ! -x "$TARGET_DIR/debug/tursodb" ]]; then
    echo "[validation-setup] WARNING: tursodb binary still not found under $TARGET_DIR/debug; validation stories will fail and run_validate.py will report it" >&2
fi

# The validation driver runs the pytest stories under VERIFIER_PYTHON
# (pytest_driver.py uses sys.executable, i.e. the interpreter test.sh invokes
# run_validate.py with). pytest lives in the image's /opt/tooling verifier venv,
# NOT in the system python3. Check the SAME interpreter the stories will use.
PYBIN="${VERIFIER_PYTHON:-python3}"
if ! "$PYBIN" -c 'import pytest' 2>/dev/null; then
    echo "[validation-setup] WARNING: pytest not importable under $PYBIN; the image's verifier venv is expected to provide it" >&2
fi

# Fail-soft smoke check: confirm the harness can locate the binary it shells out
# to, so a broken image yields one readable line instead of every story erroring
# identically. Non-fatal, warnings only.
"$PYBIN" - <<'PY' || true
import os, sys
sys.path.insert(0, "/tests/validate")
try:
    import test_harness
except Exception as exc:  # pragma: no cover - only trips on a broken image
    print(f"[validation-setup] WARNING: cannot import test_harness: {exc}", file=sys.stderr)
    raise SystemExit(0)
tursodb = test_harness._resolve_tursodb()
if not (os.path.isfile(tursodb) and os.access(tursodb, os.X_OK)):
    print(f"[validation-setup] WARNING: test_harness resolved tursodb to {tursodb!r}, "
          "which is not an executable file", file=sys.stderr)
else:
    print(f"[validation-setup] ready: test_harness -> {tursodb}")
PY
