## Task

specta-serde is meant to reject, at export time, any type whose serde attributes describe a shape serde can't actually round-trip, so you hear about it on export rather than when a value blows up later. A few shapes slip through: they export `Ok` through `specta_typescript::Typescript::default().export(&types, specta_serde::Format)` but should come back `Err`.

- `#[serde(flatten)]` on a field that serializes as a sequence, tuple, or scalar (a `Vec<_>`, a tuple, a plain integer) exports fine, then fails at runtime with `serde_json` reporting "can only flatten structs and maps". The shapes serde does flatten stay valid: maps, structs, `Option` of those, and enums, untagged ones like `serde_json::Value` included.

- a `#[serde(with = ...)]`, `serialize_with`, or `deserialize_with` attribute on a tuple struct or newtype struct field is silently accepted and the pre-codec type exported. A named struct field already rejects it unless the field carries a `#[specta(type = ...)]` override; tuple and newtype fields should match.

- an untagged enum nested in an internally-tagged enum, when rejected, reports an error naming the outer enum and blaming it for a variant that only exists on the inner one.

The cases that already work are correct; take them as the reference. Expect net-new rejections of genuinely invalid types plus the one corrected message. dig in and fix.
