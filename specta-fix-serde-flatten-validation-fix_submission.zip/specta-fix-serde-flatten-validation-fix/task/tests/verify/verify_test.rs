//! Behavioural verifier for `specta-fix-serde-flatten-validation`.
//!
//! Every test observes the PRE-EXISTING, stable public surface for turning a
//! registered type into an exported schema:
//!
//!   * `specta_typescript::Typescript::default().export(&types, specta_serde::Format)`
//!     — returns `Err` for a type whose serde attributes describe a shape serde
//!     cannot actually (de)serialise, `Ok` otherwise.
//!   * `specta_serde::PhasesFormat` — the split serialize/deserialize variant,
//!     used where a shape is only live in one direction.
//!   * `specta::Format::map_type` / `map_types` — the lower-level per-datatype
//!     entry the exporters call, used where the TypeScript lowering's unrelated
//!     numeric policy would interfere with observing validation alone.
//!
//! Decoupling rationale (why this is a fair, pre-existing-interface verifier):
//!
//!   * Nothing the fix invents is imported or named. The tests register plain
//!     derived types and read only `Result::is_ok` / `is_err` and the public
//!     `Display` text of the returned error. No internal module, function,
//!     error variant, or field is referenced.
//!   * Invalid cases assert `is_err` plus a human-facing substring that
//!     describes the observable serde contract ("flatten", "Unsupported serde
//!     attribute", a field path, a type name). Pre-fix these types export `Ok`,
//!     so the assertion fails by VALUE, not by a compile error — the file
//!     compiles against both trees.
//!   * Valid cases assert `is_ok`. They are controls: a solution that
//!     over-rejects a shape serde genuinely supports fails them. They pass on
//!     both trees, so they never manufacture a false negative.
//!   * Error-message substrings are the serde-level wording a user would read,
//!     chosen so the deciding cases differ in observable output between a
//!     broken and a correct implementation, never an implementation-internal
//!     string.

use std::collections::HashMap;
use std::marker::PhantomData;

use serde::{Deserialize, Serialize};
use specta::{Type, Types};
use specta_typescript::Typescript;

// A named-field struct is the canonical flattenable shape; reused as the valid
// inner payload throughout.
#[derive(Type, Serialize, Deserialize, Clone)]
#[specta(collect = false)]
struct Addr {
    id: i32,
}

// ---------------------------------------------------------------------------
// Flatten target validation — rejected shapes (sequence / tuple / scalar).
// ---------------------------------------------------------------------------

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenSeq {
    head: i32,
    #[serde(flatten)]
    extra: Vec<u8>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenTuple {
    head: i32,
    #[serde(flatten)]
    extra: (u8, u8),
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenScalar {
    head: i32,
    #[serde(flatten)]
    extra: u32,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct PairPayload(i32, i32);

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenTupleStruct {
    head: i32,
    #[serde(flatten)]
    extra: PairPayload,
}

#[test]
fn flatten_of_sequence_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<FlattenSeq>(),
            specta_serde::Format,
        )
        .expect_err("a flattened sequence cannot round-trip and must be rejected at export");
    let msg = err.to_string();
    assert!(msg.contains("flatten"), "error should mention flatten: {msg}");
    assert!(
        msg.contains(".extra"),
        "error should point at the offending field path: {msg}"
    );
}

#[test]
fn flatten_of_tuple_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<FlattenTuple>(),
            specta_serde::Format,
        )
        .expect_err("a flattened tuple serialises as a sequence and must be rejected");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );
}

#[test]
fn flatten_of_scalar_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<FlattenScalar>(),
            specta_serde::Format,
        )
        .expect_err("a flattened scalar cannot merge into the surrounding map");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );
}

#[test]
fn flatten_of_tuple_struct_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<FlattenTupleStruct>(),
            specta_serde::Format,
        )
        .expect_err("a tuple struct serialises as a sequence and must be rejected when flattened");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );
}

// ---------------------------------------------------------------------------
// Flatten target validation — accepted shapes (struct / Option / map / enums).
// These are controls: serde genuinely flattens them, so a correct fix must not
// start rejecting them.
// ---------------------------------------------------------------------------

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenNamedStruct {
    head: i32,
    #[serde(flatten)]
    extra: Addr,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenOptionStruct {
    head: i32,
    #[serde(flatten)]
    extra: Option<Addr>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenMap {
    head: i32,
    #[serde(flatten)]
    extra: HashMap<String, String>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(untagged)]
enum UntaggedBody {
    L { a: i32 },
    #[allow(dead_code)]
    R { b: i32 },
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenUntaggedEnum {
    head: i32,
    #[serde(flatten)]
    extra: UntaggedBody,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
enum ExternalBody {
    A { x: i32 },
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenExternalEnum {
    head: i32,
    #[serde(flatten)]
    extra: ExternalBody,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(tag = "k")]
enum InternalBody {
    A { x: i32 },
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenInternalEnum {
    head: i32,
    #[serde(flatten)]
    extra: InternalBody,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(tag = "k", content = "c")]
enum AdjacentBody {
    A { x: i32 },
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenAdjacentEnum {
    head: i32,
    #[serde(flatten)]
    extra: AdjacentBody,
}

fn assert_exports_ok<T: Type>(context: &str) {
    Typescript::default()
        .export(&Types::default().register::<T>(), specta_serde::Format)
        .unwrap_or_else(|err| panic!("{context} should export cleanly, got: {err}"));
}

#[test]
fn flatten_of_named_struct_is_accepted() {
    assert_exports_ok::<FlattenNamedStruct>("flatten of a named struct");
}

#[test]
fn flatten_of_option_struct_is_accepted() {
    assert_exports_ok::<FlattenOptionStruct>("flatten of an Option<struct>");
}

#[test]
fn flatten_of_map_is_accepted() {
    assert_exports_ok::<FlattenMap>("flatten of a map");
}

#[test]
fn flatten_of_untagged_enum_is_accepted() {
    assert_exports_ok::<FlattenUntaggedEnum>("flatten of an untagged enum");
}

#[test]
fn flatten_of_external_enum_is_accepted() {
    assert_exports_ok::<FlattenExternalEnum>("flatten of an externally tagged enum");
}

#[test]
fn flatten_of_internal_enum_is_accepted() {
    assert_exports_ok::<FlattenInternalEnum>("flatten of an internally tagged enum");
}

#[test]
fn flatten_of_adjacent_enum_is_accepted() {
    assert_exports_ok::<FlattenAdjacentEnum>("flatten of an adjacently tagged enum");
}

// ---------------------------------------------------------------------------
// Codec attribute on an unnamed (tuple/newtype) struct field.
// ---------------------------------------------------------------------------

mod wire_codec {
    use serde::{Deserialize, Deserializer, Serializer};

    pub fn serialize<S>(value: &u32, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        serializer.collect_str(value)
    }

    pub fn deserialize<'de, D>(deserializer: D) -> Result<u32, D::Error>
    where
        D: Deserializer<'de>,
    {
        String::deserialize(deserializer)?
            .parse()
            .map_err(serde::de::Error::custom)
    }
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct NewtypeCodecNoOverride(#[serde(with = "wire_codec")] u32);

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct NewtypeCodecWithOverride(
    #[specta(type = String)]
    #[serde(with = "wire_codec")]
    u32,
);

#[test]
fn codec_on_newtype_field_without_override_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<NewtypeCodecNoOverride>(),
            specta_serde::Format,
        )
        .expect_err(
            "a codec that changes the wire type on an unnamed field must be rejected unless the \
             field carries a type override, just like a named-struct field already is",
        );
    assert!(
        err.to_string().contains("Unsupported serde attribute"),
        "unexpected error: {err}"
    );
}

#[test]
fn codec_on_newtype_field_with_override_is_accepted() {
    let ts = Typescript::default()
        .export(
            &Types::default().register::<NewtypeCodecWithOverride>(),
            specta_serde::Format,
        )
        .expect("a type override satisfies the codec guard");
    assert!(
        ts.contains("string"),
        "the override type should be exported, got: {ts}"
    );
}

// A codec on an unnamed field after a skipped field is still rejected: the
// skip does not let the codec slip through the guard.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct NewtypeCodecAfterSkipped(#[serde(skip)] u32, #[serde(with = "wire_codec")] u32);

#[test]
fn codec_on_newtype_field_after_a_skipped_field_is_rejected() {
    Typescript::default()
        .export(
            &Types::default().register::<NewtypeCodecAfterSkipped>(),
            specta_serde::Format,
        )
        .expect_err("the codec field is still rejected after a skipped field");
}

// ---------------------------------------------------------------------------
// Misattributed error: an untagged enum nested in an internally tagged enum.
// The reported error must name the inner type and its variant, not blame the
// outer container for a variant it does not have.
// ---------------------------------------------------------------------------

#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(untagged)]
enum PrimPayload {
    P(u32),
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(tag = "k")]
enum TaggedOuter {
    X(PrimPayload),
}

#[test]
fn nested_untagged_enum_error_names_the_inner_type() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<TaggedOuter>(),
            specta_serde::Format,
        )
        .expect_err("an untagged scalar payload cannot be merged with an internal tag");
    let msg = err.to_string();
    assert!(
        msg.contains("PrimPayload"),
        "error should name the inner untagged type, not only the outer enum: {msg}"
    );
    assert!(
        msg.contains("variant 'P'"),
        "error should name the inner enum's variant, not a variant of the outer enum: {msg}"
    );
}

// ---------------------------------------------------------------------------
// Wire-shape fidelity: newtype delegation, generic substitution, transparent
// nesting, conversion/phase liveness, skip liveness, and termination.
// ---------------------------------------------------------------------------

// A single-field tuple struct is a newtype: serde delegates straight to the
// inner value, so flattening it is exactly as valid as flattening that value.
#[derive(Type, Serialize)]
#[specta(collect = false)]
struct NewtypeOfStruct(Addr);

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct NewtypeOfScalar(u32);

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenNewtypeStruct {
    head: i32,
    #[serde(flatten)]
    extra: NewtypeOfStruct,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenNewtypeScalar {
    head: i32,
    #[serde(flatten)]
    extra: NewtypeOfScalar,
}

#[test]
fn flatten_of_newtype_around_struct_is_accepted() {
    assert_exports_ok::<FlattenNewtypeStruct>("flatten of a newtype wrapping a struct");
}

#[test]
fn flatten_of_newtype_around_scalar_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<FlattenNewtypeScalar>(),
            specta_serde::Format,
        )
        .expect_err("newtype delegation exposes the scalar, which serde cannot flatten");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );
}

// A reference to a generic type carries concrete arguments, so the flatten
// target's real shape is knowable and must be substituted in.
#[derive(Type, Serialize)]
#[specta(collect = false)]
struct GenericNewtype<T>(T);

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenGenericSeq {
    head: i32,
    #[serde(flatten)]
    extra: GenericNewtype<Vec<u8>>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenGenericStruct {
    head: i32,
    #[serde(flatten)]
    extra: GenericNewtype<Addr>,
}

#[test]
fn flatten_of_generic_newtype_over_sequence_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<FlattenGenericSeq>(),
            specta_serde::Format,
        )
        .expect_err("the concrete argument is a sequence, so the flatten target is a sequence");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );
}

#[test]
fn flatten_of_generic_newtype_over_struct_is_accepted() {
    assert_exports_ok::<FlattenGenericStruct>("flatten of a generic newtype over a struct");
}

// The same syntactic generic reference reached under two different outer
// instantiations in one walk must be validated against each; walk order must
// not let a good instantiation mask a bad one.
#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenGenericField<T> {
    head: i32,
    #[serde(flatten)]
    body: T,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct OuterOf<T> {
    inner: FlattenGenericField<T>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct TwoSubstitutionsGoodFirst {
    good: OuterOf<Addr>,
    bad: OuterOf<Vec<u8>>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct TwoSubstitutionsBadFirst {
    bad: OuterOf<Vec<u8>>,
    good: OuterOf<Addr>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct TwoSubstitutionsGoodOnly {
    good: OuterOf<Addr>,
}

#[test]
fn flatten_generic_reached_under_two_substitutions_rejects_the_bad_one() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<TwoSubstitutionsGoodFirst>(),
            specta_serde::Format,
        )
        .expect_err("the struct instantiation seen first must not mask the sequence one");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );

    let err = Typescript::default()
        .export(
            &Types::default().register::<TwoSubstitutionsBadFirst>(),
            specta_serde::Format,
        )
        .expect_err("the sequence instantiation must be rejected regardless of walk order");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );
}

#[test]
fn flatten_generic_reached_under_one_good_substitution_is_accepted() {
    assert_exports_ok::<TwoSubstitutionsGoodOnly>("flatten of a generic under one struct arg");
}

// Transparent wrappers delegate straight through; nested ones still resolve to
// the innermost real shape.
#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(transparent)]
struct TransparentInner(Vec<u8>);

#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(transparent)]
struct TransparentOuter(TransparentInner);

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenTransparentSeq {
    head: i32,
    #[serde(flatten)]
    extra: TransparentOuter,
}

#[test]
fn flatten_of_nested_transparent_wrappers_around_sequence_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<FlattenTransparentSeq>(),
            specta_serde::Format,
        )
        .expect_err("transparent wrappers still resolve to a sequence");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );
}

// Conversion attributes replace the declared shape with a wire shape per
// direction. A one-directional conversion leaves the opposite direction on the
// raw declared shape, which must still be checked.
#[derive(Type, Serialize, Deserialize, Clone)]
#[specta(collect = false)]
struct ConversionWire {
    id: String,
}

#[derive(Type, Serialize, Deserialize, Clone)]
#[specta(collect = false)]
#[serde(into = "ConversionWire")]
struct IntoOnlyScalar(u32);

impl From<IntoOnlyScalar> for ConversionWire {
    fn from(value: IntoOnlyScalar) -> Self {
        Self {
            id: value.0.to_string(),
        }
    }
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenIntoOnly {
    head: i32,
    #[serde(flatten)]
    extra: IntoOnlyScalar,
}

#[test]
fn flatten_of_into_only_conversion_checks_the_raw_deserialize_shape() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<FlattenIntoOnly>(),
            specta_serde::PhasesFormat,
        )
        .expect_err("serialize uses a struct wire, but deserialize uses the raw scalar newtype");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );
}

// An explicit phase override holds both phase shapes; the live phase must be
// looked inside rather than trusting the wrapper.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenPhasedSeq {
    head: i32,
    #[serde(flatten)]
    #[specta(type = specta_serde::Phased<Vec<String>, Addr>)]
    extra: HashMap<String, String>,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenPhasedMap {
    head: i32,
    #[serde(flatten)]
    #[specta(type = specta_serde::Phased<HashMap<String, String>, Addr>)]
    extra: HashMap<String, String>,
}

#[test]
fn flatten_of_phased_override_with_a_sequence_phase_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<FlattenPhasedSeq>(),
            specta_serde::PhasesFormat,
        )
        .expect_err("the serialize phase is a sequence, which cannot be flattened");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );
}

#[test]
fn flatten_of_phased_override_with_map_and_struct_phases_is_accepted() {
    Typescript::default()
        .export(
            &Types::default().register::<FlattenPhasedMap>(),
            specta_serde::PhasesFormat,
        )
        .expect("both phases are map/struct shaped, so the flatten is valid both ways");
}

// Skip liveness: a field skipped in a direction never flattens in that
// direction, so its shape there is irrelevant and must not be rejected.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenOneSidedSkipSeq {
    head: i32,
    #[serde(flatten, skip_serializing, default)]
    extra: Vec<u8>,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenBothSidedSkipSeq {
    head: i32,
    #[serde(flatten, skip_serializing, skip_deserializing, default)]
    extra: Vec<u8>,
}

#[test]
fn flatten_of_one_sided_skip_is_rejected_on_its_live_direction() {
    // The field is skipped only on serialize, so the deserialize phase still
    // flattens a live sequence — the split formatter must reject it there.
    let err = Typescript::default()
        .export(
            &Types::default().register::<FlattenOneSidedSkipSeq>(),
            specta_serde::PhasesFormat,
        )
        .expect_err("the deserialize phase flattens a live sequence");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );
}

#[test]
fn one_sided_skip_dead_direction_is_not_required_flattenable() {
    // Rendering only the serialize phase (where the field is skipped) must not
    // reject: the sequence shape is unreachable in that direction. Exercised
    // through `map_type` on an anonymous wrapper so the registered-definition
    // fast path does not short-circuit the check.
    use specta::Format as _;
    use specta::datatype::{DataType, Reference};

    let mut types = Types::default();
    let dt = FlattenOneSidedSkipSeq::definition(&mut types);
    let DataType::Reference(Reference::Named(reference)) = &dt else {
        panic!("expected a named reference for the registered type");
    };
    let ty = types
        .get(reference)
        .and_then(|ndt| ndt.ty.clone())
        .expect("the definition should be registered");

    specta_serde::PhasesFormat
        .map_type(&types, &DataType::Nullable(Box::new(ty)))
        .map(|_| ())
        .expect("the serialize phase never renders the skip-serializing sequence");
}

#[test]
fn flatten_of_fully_skipped_sequence_is_accepted() {
    assert_exports_ok::<FlattenBothSidedSkipSeq>("flatten of a sequence skipped in both directions");
}

// Termination: resolving a self-recursive generic flatten target must not hang.
#[derive(Type, Serialize)]
#[specta(collect = false)]
struct SelfRecursiveGeneric<T>(Box<SelfRecursiveGeneric<T>>, PhantomData<T>);

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenSelfRecursiveGeneric {
    head: i32,
    #[serde(flatten)]
    extra: SelfRecursiveGeneric<Addr>,
}

/// Runs `f` on a worker thread and panics if it does not finish in `timeout`,
/// turning an infinite-recursion regression into a test failure rather than a
/// hung verifier.
fn with_timeout<T: Send + 'static>(
    timeout: std::time::Duration,
    f: impl FnOnce() -> T + Send + 'static,
) -> T {
    let (tx, rx) = std::sync::mpsc::channel();
    std::thread::spawn(move || {
        let _ = tx.send(f());
    });
    rx.recv_timeout(timeout)
        .expect("operation timed out — likely an infinite-recursion regression")
}

#[test]
fn flatten_of_self_recursive_generic_terminates() {
    // The outcome (accept/reject) is not asserted — only that resolution
    // terminates. A correct implementation guards the cycle; a regression that
    // recurses forever fails here instead of hanging the whole verifier.
    let _ = with_timeout(std::time::Duration::from_secs(10), || {
        Typescript::default().export(
            &Types::default().register::<FlattenSelfRecursiveGeneric>(),
            specta_serde::Format,
        )
    });
}
