"""Compile check for mise-feat-declarative-system-files.

The feature's behavior is observable only by running the built `mise` binary
against fixture configs in an isolated HOME, so all behavioral checks live in
the validation suite. This check is a minimal compile pass over the whole
workspace: an edit that does not type-check is caught here before the
validation phase wastes time building a doomed binary.

Stays implementation-agnostic: it compiles the workspace through the
pre-existing, stable `cargo` build interface. No import of feature-specific
modules, no grep for the new engine / mode strings / state words, and no
`cargo test` (so it is insensitive to which test names a solution adds).
"""

from __future__ import annotations

import os
import subprocess
import textwrap


# Repository directory inside the task container (see image/Dockerfile).
REPO_DIR = "/repo/mise"

# A cold `--locked` workspace check at the base commit is a few minutes; the
# image pre-builds `--locked --tests --workspace`, so with a warm target cache
# this is typically well under a minute. 15 minutes is generous headroom and
# keeps the check inside its allotted runtime.
CHECK_TIMEOUT_SEC = 900


def _repo_env() -> dict[str, str]:
    """Toolchain env matching the task image, resilient to a fresh shell.

    ``tests/test-setup.sh`` already exports these before the verifier runs, but
    defaulting them here keeps the check runnable in isolation. ``--locked``
    plus offline cargo matches the baked registry closure (the change adds no
    new dependencies).
    """
    env = {**os.environ}
    env.setdefault("CARGO_HOME", "/opt/cargo")
    env.setdefault("RUSTUP_HOME", "/opt/rustup")
    env.setdefault("CARGO_TARGET_DIR", "/opt/cache/cargo-target")
    env.setdefault("CARGO_NET_OFFLINE", "true")
    env["PATH"] = f"{env['CARGO_HOME']}/bin:" + env.get("PATH", "")
    return env


def test_workspace_compiles() -> None:
    """The whole workspace must still ``cargo check`` cleanly after the edits.

    Runs ``cargo check --locked --workspace --message-format=short`` in
    /repo/mise. On failure, dumps the last 200 lines of stdout + stderr so the
    failure mode is visible in the verifier log without flooding the judge
    prompt.
    """
    cmd = [
        "cargo",
        "check",
        "--locked",
        "--workspace",
        "--message-format=short",
    ]

    result = subprocess.run(
        cmd,
        cwd=REPO_DIR,
        capture_output=True,
        text=True,
        timeout=CHECK_TIMEOUT_SEC,
        env=_repo_env(),
        check=False,
    )

    if result.returncode == 0:
        return

    def _tail(text: str, n: int = 200) -> str:
        return "\n".join(text.splitlines()[-n:])

    msg = textwrap.dedent(
        f"""\
        cargo check failed (exit {result.returncode}).
        The submitted source changes produced a workspace that no longer type-checks.
        Common causes:
          - Missing match arm after extending an exhaustive enum
          - Missing trait method on an extended trait impl
          - A new module not declared (or declared twice)
          - Broken Cargo.toml / feature gating
          - Borrow-checker or lifetime mismatches in the new code

        --- cargo check stdout (last 200 lines) ---
        {_tail(result.stdout)}

        --- cargo check stderr (last 200 lines) ---
        {_tail(result.stderr)}
        """
    )
    raise AssertionError(msg)
