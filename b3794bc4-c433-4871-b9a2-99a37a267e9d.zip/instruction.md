## Task

Extend `mise system` so a trusted, experimental config can declare dotfiles alongside the OS packages and defaults it already manages. The new `[system.files]` table maps each destination on the machine to a source in the declaring config and a handling mode. `mise system install` should bring those destinations into line with the declaration on every run, doing nothing when they already match; `mise system status` should show their current state. Integrate both operations into the existing system commands, keep `[tools]` behavior intact, and apply the same trust and experimental rules used by other `[system]` settings.

## User stories / requirements

- Each entry needs one of four modes: `symlink` (the default) links its source as a whole; `symlink-each` links individual files into a directory that can retain unmanaged files; `copy` materializes content and adds directory contents recursively; `template` renders through mise's template engine. Template output keeps the source permissions, including after those permissions change.
- For every entry, `mise system status` shows `applied`, `missing`, `differs (reason)`, or `source missing`. Provide a status check that exits non-zero if any entry is out of its declared state, plus machine-readable output for scripts.
- Applying leaves conflicts intact and fails with their paths: a real file blocking a link or directory, or a directory where a file belongs. An override replaces them. `copy` and `template` update changed content without it and replace symlinks at file targets, including dangling links.
- A dry run previews the apply operation without changing the filesystem or triggering template side effects.
- Warn and skip entries with unknown modes or relative target paths while continuing the run. Show a missing source in status and report it as an apply error. If several entries have different problems, report them in the same apply run.
