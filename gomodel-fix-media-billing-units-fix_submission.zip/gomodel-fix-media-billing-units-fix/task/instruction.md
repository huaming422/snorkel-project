## Task

Finance has been reconciling our usage/cost log, the per-request record of tokens
and the dollar cost we compute for each call, and the media numbers don't add up.

It's the media endpoints specifically: image generation and edits, and audio
transcription and translation. Depending on the provider and the shape of the
response, some of those calls get costed too high, some too low, and some land on
the log with no cost at all. Plain text and chat completions reconcile fine. Only
the media rows are wrong, and in more than one way.

The proxying, routing, and auth are behaving, and we trust what the providers send
back. The problem is in how we account for it: the cost we record per media call.

Dig into how media costs get computed, work out why the amounts come out wrong
across these responses, and fix it so each call is costed for exactly what it should
be charged, once, at the right rate. When we genuinely can't work out a cost, the
record should say so instead of quietly logging zero.
