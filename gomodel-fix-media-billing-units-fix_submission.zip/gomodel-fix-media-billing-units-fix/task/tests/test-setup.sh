#!/usr/bin/env bash
# All Go dependencies and the build/module caches are baked into the image at the
# base commit (see image/Dockerfile steps 8-10); the verifier compiles an
# in-package test under internal/server with -tags=contract against that warm
# cache. Nothing to fetch at verifier time, and no container image is pulled.
set -euo pipefail
echo "[test-setup] no-op for gomodel-fix-media-billing-units (deps baked into image)"
