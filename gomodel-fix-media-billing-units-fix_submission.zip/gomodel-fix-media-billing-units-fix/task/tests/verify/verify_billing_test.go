// Behavioral verifier for the media usage/cost accounting fix.
//
// These tests drive the real server services (audioService, imageService) end
// to end with the package's own mock provider and capturing usage logger, then
// inspect the *usage.UsageEntry those services hand to the logger. They assert
// only the recorded dollar amount (with tolerance) and whether the row carries
// a cost-calculation note — never a field name, a note's exact wording, or an
// internal helper, so any correct accounting fix is accepted regardless of how
// it is structured.
//
// Why this layer: the services turn a provider response plus the uploaded file
// into the recorded entry. That path is where the amounts are observable to an
// operator reviewing the log, and the service method signatures are stable, so
// the tests hold whatever route a fix takes through the lower layers.

package server

import (
	"bytes"
	"fmt"
	"mime/multipart"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/labstack/echo/v5"

	"github.com/enterpilot/gomodel/internal/core"
	"github.com/enterpilot/gomodel/internal/usage"
)

// costTol is the absolute tolerance for recorded-dollar comparisons. The
// amounts under test differ between a correct and an incorrect accounting by
// far more than this, so the bound only absorbs float rounding.
const costTol = 1e-6

// newAudioMock builds an audio provider whose transcription and translation
// both return body, supporting model for routing.
func newAudioMock(model, body string) *audioMockProvider {
	resp := &core.AudioResponse{ContentType: "application/json", Data: []byte(body)}
	return &audioMockProvider{
		mockProvider:      &mockProvider{supportedModels: []string{model}},
		transcriptionResp: resp,
		translationResp:   resp,
	}
}

// newAudioUpload builds a multipart speech-to-text request carrying audio under
// the given endpoint. It omits transcription-only form fields so the same
// builder works for both the transcription and translation endpoints.
func newAudioUpload(endpoint, model, filename string, audio []byte) (*echo.Context, *httptest.ResponseRecorder) {
	var buf bytes.Buffer
	w := multipart.NewWriter(&buf)
	_ = w.WriteField("model", model)
	part, _ := w.CreateFormFile("file", filename)
	_, _ = part.Write(audio)
	_ = w.Close()

	req := httptest.NewRequest(http.MethodPost, endpoint, &buf)
	req.Header.Set("Content-Type", w.FormDataContentType())
	rec := httptest.NewRecorder()
	return echo.New().NewContext(req, rec), rec
}

// captureAudio runs one speech-to-text call and returns the recorded entry.
// translation selects the translation endpoint/method.
func captureAudio(t *testing.T, translation bool, model, body, filename string, audio []byte, pricing *core.ModelPricing) *usage.UsageEntry {
	t.Helper()
	var captured *usage.UsageEntry
	logger := &capturingUsageLogger{config: usage.Config{Enabled: true}, captured: &captured}
	svc := &audioService{
		provider:        newAudioMock(model, body),
		usageLogger:     logger,
		pricingResolver: &mockPricingResolver{pricing: pricing},
	}

	endpoint := "/v1/audio/transcriptions"
	c, rec := newAudioUpload(endpoint, model, filename, audio)
	call := svc.CreateTranscription
	if translation {
		endpoint = "/v1/audio/translations"
		c, rec = newAudioUpload(endpoint, model, filename, audio)
		call = svc.CreateTranslation
	}

	if err := call(c); err != nil {
		t.Fatalf("audio call returned error: %v", err)
	}
	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200 (body: %s)", rec.Code, rec.Body.String())
	}
	if captured == nil {
		t.Fatal("expected a usage entry to be written")
	}
	return captured
}

// captureImageEdit runs one image-edit call and returns the recorded entry.
// resp is the provider's image response; model routes the request.
func captureImageEdit(t *testing.T, model string, resp *core.ImageGenerationResponse, pricing *core.ModelPricing) *usage.UsageEntry {
	t.Helper()
	var captured *usage.UsageEntry
	logger := &capturingUsageLogger{config: usage.Config{Enabled: true}, captured: &captured}
	mock := newImageEditMock()
	mock.supportedModels = []string{model}
	mock.imageResp = resp
	svc := &imageService{
		provider:        mock,
		usageLogger:     logger,
		pricingResolver: &mockPricingResolver{pricing: pricing},
	}
	c, rec := newImageEditRequest(t, [][2]string{{"model", model}, {"prompt", "x"}}, catPNG)

	if err := svc.CreateImageEdit(c); err != nil {
		t.Fatalf("CreateImageEdit returned error: %v", err)
	}
	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200 (body: %s)", rec.Code, rec.Body.String())
	}
	if captured == nil {
		t.Fatal("expected a usage entry to be written")
	}
	return captured
}

func assertCostNear(t *testing.T, label string, got *float64, want float64) {
	t.Helper()
	if got == nil {
		t.Fatalf("%s: recorded cost is unset, want %.6f", label, want)
	}
	if diff := *got - want; diff > costTol || diff < -costTol {
		t.Fatalf("%s: recorded cost = %.9f, want %.9f (±%g)", label, *got, want, costTol)
	}
}

// --- fail_to_pass -----------------------------------------------------------

// TestVerifyAudioDurationBilled: a speech-to-text response that reports no usage
// is still costed from the uploaded audio's own duration, for both the
// transcription and translation endpoints. A 2.5s WAV at a per-second input rate
// must record 2.5 × rate.
func TestVerifyAudioDurationBilled(t *testing.T) {
	const seconds = 2.5
	const perSecond float64 = 0.01
	wav := wavBytes(24000, 1, 16, seconds)
	pricing := &core.ModelPricing{PerSecondInput: new(perSecond)}

	for _, tc := range []struct {
		name        string
		translation bool
	}{
		{"transcription", false},
		{"translation", true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			entry := captureAudio(t, tc.translation, "gpt-4o-transcribe", `{"text":"hi"}`, "speech.wav", wav, pricing)
			assertCostNear(t, tc.name, entry.TotalCost, seconds*perSecond)
		})
	}
}

// TestVerifyAudioNotDoubleCharged: a transcription response that reports token
// usage AND a seconds field is charged once — on its tokens — not also by the
// audio duration. With an input-token rate and a per-second rate both
// configured, the recorded cost is the token cost alone.
func TestVerifyAudioNotDoubleCharged(t *testing.T) {
	const inputTokens = 1_000_000
	const inputPerMtok = 2.5 // => token cost 2.5
	const perSecond = 0.01   // 9s would add 0.09 if double-charged
	body := fmt.Sprintf(`{"text":"hi","usage":{"input_tokens":%d,"seconds":9}}`, inputTokens)
	pricing := &core.ModelPricing{
		InputPerMtok:   new(inputPerMtok),
		PerSecondInput: new(perSecond),
	}

	entry := captureAudio(t, false, "gpt-4o-transcribe", body, "speech.wav", wavBytes(24000, 1, 16, 2.5), pricing)
	assertCostNear(t, "audio tokens only", entry.TotalCost, float64(inputTokens)*inputPerMtok/1_000_000)
}

// TestVerifyAudioUnmeasurableFlagged: when a transcription reports no usage and
// the uploaded audio's duration cannot be measured, the row is flagged with a
// non-empty cost-calculation note and the cost is left unset — not a silent
// zero. The upload uses an unsupported container signature.
func TestVerifyAudioUnmeasurableFlagged(t *testing.T) {
	pricing := &core.ModelPricing{PerSecondInput: new(0.01)}
	unmeasurable := []byte("OggS\x00\x02unsupported-container-bytes")

	entry := captureAudio(t, false, "gpt-4o-transcribe", `{"text":"hi"}`, "speech.ogg", unmeasurable, pricing)
	if entry.CostsCalculationCaveat == "" {
		t.Fatalf("expected a non-empty cost-calculation note for an unmeasurable upload, got empty (cost=%v)", entry.TotalCost)
	}
	if entry.TotalCost != nil {
		t.Fatalf("cost should be left unset when the duration is unmeasurable, got %.9f", *entry.TotalCost)
	}
}

// TestVerifyImageNotDoubleCharged: an image response that reports billable
// output tokens AND is configured with a flat per-image rate is charged once —
// on its tokens — not also per image. With input/output token rates and a
// per-image rate configured, the recorded cost is the token cost alone.
func TestVerifyImageNotDoubleCharged(t *testing.T) {
	const inputTokens = 50
	const outputTokens = 1000
	const inputPerMtok = 5.0
	const outputPerMtok = 40.0
	const perImage = 0.167 // would add on top if double-charged
	resp := &core.ImageGenerationResponse{
		Data:  []core.ImageData{{B64JSON: "aGk="}},
		Usage: &core.ImageUsage{InputTokens: inputTokens, OutputTokens: outputTokens, TotalTokens: inputTokens + outputTokens},
	}
	pricing := &core.ModelPricing{
		InputPerMtok:  new(inputPerMtok),
		OutputPerMtok: new(outputPerMtok),
		PerImage:      new(perImage),
	}

	entry := captureImageEdit(t, "gpt-image-1", resp, pricing)
	want := float64(inputTokens)*inputPerMtok/1_000_000 + float64(outputTokens)*outputPerMtok/1_000_000
	assertCostNear(t, "image tokens only", entry.TotalCost, want)
}

// --- pass_to_pass (regression guards) ---------------------------------------

// TestVerifyDalleStillBilledPerImage: a per-image model that reports no token
// usage keeps costing count × per-image. Two returned images at a per-image
// rate record twice that rate. Holds before and after the fix.
func TestVerifyDalleStillBilledPerImage(t *testing.T) {
	const perImage = 0.04
	resp := &core.ImageGenerationResponse{
		Data: []core.ImageData{{B64JSON: "aGk="}, {B64JSON: "aGk="}},
	}
	pricing := &core.ModelPricing{PerImage: new(perImage)}

	entry := captureImageEdit(t, "dall-e-2", resp, pricing)
	assertCostNear(t, "dall-e per-image", entry.TotalCost, 2*perImage)
}

// TestVerifyAudioTokenBilledUnchanged: a transcription that reports token usage
// and no seconds, priced only by an input-token rate, still costs the token
// amount. Holds before and after the fix.
func TestVerifyAudioTokenBilledUnchanged(t *testing.T) {
	const inputTokens = 1_000_000
	const inputPerMtok = 2.5
	body := fmt.Sprintf(`{"text":"hi","usage":{"input_tokens":%d}}`, inputTokens)
	pricing := &core.ModelPricing{InputPerMtok: new(inputPerMtok)}

	entry := captureAudio(t, false, "gpt-4o-transcribe", body, "speech.wav", wavBytes(24000, 1, 16, 2.5), pricing)
	assertCostNear(t, "audio token billed", entry.TotalCost, float64(inputTokens)*inputPerMtok/1_000_000)
}
