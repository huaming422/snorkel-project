## Task

We want `aube add` to push back on two more classes of risky npm names before it installs them, alongside the supply-chain checks it already runs. One class is names that look like typos or lookalikes of well-known packages; the other is names that were first registered on the public registry very recently. Both new checks should behave like the reputation checks already in place: prompt for confirmation when someone is running interactively, and refuse with a clear error when there is nobody to ask. Both should also honour the same trust and allow-list exemptions, and the same bypass flag, that the current reputation checks respect.

## User stories / requirements

- Running `aube add` non-interactively on a name that is a near miss of a well-known package refuses the add; the well-known name itself, an unrelated name, or a scoped name whose last segment merely coincides with an unscoped well-known name all go through. The existing low-reputation bypass flag also lets a near-miss through.
- Running `aube add` on a name first published very recently refuses the add; a long-established name goes through. If the registry can't confirm when the name was first published, the add is refused rather than waved through. A configurable recency window sets what counts as too recent; zero turns the check off.
- When someone runs `aube add` on a name that matches the workspace's unpopular-package allow-list, the add succeeds even though the name would otherwise be challenged by one of the new checks.
