"""Shared helpers for the aube-feat-name-reputation-gates validation stories.

Every story shells out to the prebuilt `aube` CLI binary in a non-interactive
subprocess and inspects the exit status plus combined stdout+stderr, so there is
no shared in-process state. This file exists because the build validator expects
`test_harness.py` alongside `validation_spec.toml`; stories import the small
helpers below (binary path, per-run project scaffolding, the add runner) so each
story file stays short.

The CLI is driven at its natural boundary: `aube add <name>` run in a throwaway
project directory with no controlling terminal. The add reputation checks only
engage for names that resolve through the public registry, and this phase has no
route to it — so each run points `aube` at a warmed, on-disk metadata+content
snapshot baked into the image (`/opt/aube-warm`, see the image build). The two
real-world names the stories use (`lodash`, `left-pad`) were resolved and
installed into that snapshot at build time; a per-run private COPY of it lets the
CLI resolve and install them with no network, and the checks read their registry
metadata (including first-publish time) straight from it. `AUBE_FETCH_RETRIES=0`
makes any name that is NOT in the snapshot fail fast rather than retry-looping
against the unreachable registry.

Nothing here encodes the solution's internal symbol names, error-code constants,
message wording, or the name of the new recency-window setting — those are
implementation choices the submitted patch is free to make. A story asserts
observable outcomes (did the add succeed or was it refused) and, where a refusal
must be told apart from an unrelated resolve failure, the presence of a
real-world package name or of a setting token the story DISCOVERS from the
submitted patch.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import uuid

# Prebuilt aube binary. validation-setup.sh (re)builds it from the agent's edits
# before the stories run. CARGO_TARGET_DIR is pinned image-wide in the Dockerfile.
AUBE_BIN: str = "/opt/cache/cargo-target/debug/aube"

# Image-baked warm snapshot: a full-packument metadata cache + content store for
# the fixed real-world names the stories drive, resolved+installed at build time
# while the registry was reachable (see the image Dockerfile, step "7b"). Each run
# copies these into a throwaway project's private cache/store so no add can leak
# trust into a later case, and so the offline reputation checks read their
# registry metadata from the snapshot rather than the (unreachable) network.
WARM_CACHE_SRC: str = "/opt/aube-warm/cache"
WARM_STORE_SRC: str = "/opt/aube-warm/store"

# Base environment shared by every add invocation. These mirror the repository's
# own bats harness (test/test_helper/common_setup.bash), which turns OFF the
# unrelated public-API gates (OSV advisories + weekly-downloads) so a story
# exercises exactly the one reputation check it targets. Both names are
# PRE-EXISTING settings in the base repo (grep `AUBE_ADVISORY_CHECK` /
# `AUBE_LOW_DOWNLOAD_THRESHOLD`), so pinning them here is not coupling to the
# submitted patch. `AUBE_FETCH_RETRIES=0` (also pre-existing: grep
# `AUBE_FETCH_RETRIES` / the `fetchRetries` setting) makes any name absent from
# the warm snapshot fail fast instead of retry-looping against the unreachable
# registry. The new recency-window setting is deliberately NOT set here: its name
# is the submitted patch's choice, so a story that needs it passes it through
# `env_overrides` (or `.npmrc`) after discovering it from the patch.
BASE_ENV: dict[str, str] = {
    "AUBE_ADVISORY_CHECK": "off",
    "AUBE_LOW_DOWNLOAD_THRESHOLD": "0",
    "AUBE_FETCH_RETRIES": "0",
    # Keep aube non-interactive and quiet; no TTY is attached in subprocess mode,
    # which on its own routes the gates to their refuse-in-CI branch.
    "CI": "1",
    "NO_COLOR": "1",
    "AUBE_UPDATE_NOTIFIER": "false",
}


def new_project(npmrc: str | None = None) -> str:
    """Create a throwaway project dir with a minimal package.json + private caches.

    A fresh directory per case keeps each add independent: a name added (or
    trusted via the lockfile) in one case can never leak trust into another. The
    image-baked warm metadata+content snapshot is copied in under private
    `cache/` and `store/` dirs so the offline reputation checks resolve against
    it. Optionally drops an `.npmrc` (used to set workspace-scoped settings such
    as the allow-list, or the recency window if the patch reads it from npmrc)
    into the project root.
    """
    root = tempfile.mkdtemp(prefix="aube_rep_gate_")
    name = f"fixture-{uuid.uuid4().hex[:8]}"
    with open(os.path.join(root, "package.json"), "w", encoding="utf-8") as fh:
        fh.write(
            '{\n'
            f'  "name": "{name}",\n'
            '  "version": "1.0.0",\n'
            '  "private": true\n'
            '}\n'
        )
    if npmrc is not None:
        with open(os.path.join(root, ".npmrc"), "w", encoding="utf-8") as fh:
            fh.write(npmrc)
    # Private per-run copy of the baked warm snapshot (metadata cache + content
    # store), so resolves/installs are offline and runs stay independent.
    shutil.copytree(WARM_CACHE_SRC, os.path.join(root, "cache"))
    shutil.copytree(WARM_STORE_SRC, os.path.join(root, "store"))
    return root


def run_add(
    package: str,
    *,
    extra_args: list[str] | None = None,
    npmrc: str | None = None,
    env_overrides: dict[str, str] | None = None,
    timeout: int = 180,
) -> dict:
    """Run `aube add <package>` non-interactively and return a result dict.

    Resolves/installs against the per-run private copy of the image-baked warm
    snapshot (no network). Parameters:
      - `extra_args`:    extra CLI args appended after the package (e.g. the
                         pre-existing bypass flag).
      - `npmrc`:         contents of an `.npmrc` to drop in the project root
                         (e.g. the allow-list, or the recency-window key if the
                         patch reads it from npmrc).
      - `env_overrides`: extra environment variables merged on top of BASE_ENV
                         (e.g. the recency-window environment variable the patch
                         defines — discover its name from the submitted patch).

    Keys in the returned dict:
      - "returncode": process exit code (0 == the add was accepted)
      - "out":        combined stdout+stderr, lower-cased for substring checks
      - "out_raw":    combined stdout+stderr, original case
    """
    root = new_project(npmrc=npmrc)
    env = {**os.environ, **BASE_ENV}
    # Point aube at the throwaway project's private metadata cache + content store
    # (the copied warm snapshot) and an isolated HOME, so nothing reads or writes
    # a shared cache and every resolve is offline.
    home = os.path.join(root, "home")
    os.makedirs(home, exist_ok=True)
    env["HOME"] = home
    env["AUBE_CACHE_DIR"] = os.path.join(root, "cache")
    env["XDG_CACHE_HOME"] = os.path.join(root, "cache")
    env["AUBE_STORE_DIR"] = os.path.join(root, "store")
    if env_overrides:
        env.update(env_overrides)
    argv = [AUBE_BIN, "add", package]
    if extra_args:
        argv.extend(extra_args)
    proc = subprocess.run(
        argv,
        cwd=root,
        capture_output=True,
        text=True,
        timeout=timeout,
        env=env,
        check=False,
    )
    combined = (proc.stdout or "") + (proc.stderr or "")
    return {
        "returncode": proc.returncode,
        "out": combined.lower(),
        "out_raw": combined,
    }
