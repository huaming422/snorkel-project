## Task

one of our mise tasks won't start. it declares the tool it needs under `tools`, and the only reason it ever runs is that another task points at it from a `run` list entry (not through `depends`). when we kick off that parent task, the child fails immediately with its tool's binary reported "not found". the tool just never gets installed.

the odd part: that same child task works fine on its own. run it directly by name and the tool installs and it goes green. wire it up through `depends` and it's also fine. it's only the tasks that get reached through a `run` reference that come up missing their tools. can you dig in and get the `run`-reference path installing tools the way running a task directly or pulling it in through `depends` already does?
