#!/usr/bin/env bash
# Sourced inside the isolated environment. Behaviour: `--skip-tools` must still
# suppress installation for a task reached only through a `run` reference — the
# referenced task runs, but its declared tool is not installed. The child's own
# command is a plain `echo`, so it produces output whether or not the tool was
# installed; the deciding check is that no install directory for the child's
# tool version was created.

cat <<EOF >mise.toml
[tasks.deferred-check]
tools = { tiny = "2.0.0" }
run = 'echo deferred ran'

[tasks.deferred-parent]
run = [{ task = "deferred-check" }]
EOF

assert "mise run --skip-tools deferred-parent" "deferred ran"
assert_fail "test -d '$MISE_DATA_DIR/installs/tiny/2.0.0'"
