#!/usr/bin/env bash
# Sourced inside the isolated environment. Behaviour: when the referenced task
# name in a `run` entry is produced at run time (rendered from a variable), the
# same late-install path must apply, so the runtime-resolved child's tool is
# installed before it runs.

cat <<EOF >mise.toml
[tasks.templated-child]
tools = { tiny = "2" }
run = "rtx-tiny"

[tasks.templated-parent]
env = { CHILD = "templated-child" }
run = [{ task = "{{ env.CHILD }}" }]
EOF

assert "mise run templated-parent" "rtx-tiny: v2.1.0 args:"
