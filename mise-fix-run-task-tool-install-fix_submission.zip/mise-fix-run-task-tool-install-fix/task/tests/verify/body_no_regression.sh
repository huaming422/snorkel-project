#!/usr/bin/env bash
# Sourced inside the isolated environment. Behaviour (regression guard): running
# a task directly, or pulling a tool-bearing task in through `depends`, must
# still install the tool and work — the up-front graph install path is
# unchanged. `mise run b` installs `a`'s and `b`'s tools (a via depends, b
# directly) and runs both; a direct `mise run a` installs and runs on its own.

cat <<EOF >mise.toml
[tasks.a]
tools = { tiny = "1" }
run = "rtx-tiny"
[tasks.b]
depends = ["a"]
tools = { tiny = "2" }
run = "rtx-tiny"
EOF

assert "mise run b" "rtx-tiny: v1.0.1 args:
rtx-tiny: v2.1.0 args:"

assert "mise run a" "rtx-tiny: v1.0.1 args:"
