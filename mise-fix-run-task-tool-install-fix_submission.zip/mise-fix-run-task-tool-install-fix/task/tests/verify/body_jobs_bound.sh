#!/usr/bin/env bash
# Sourced inside the isolated environment. Behaviour: deferred installs for
# injected tasks must respect the task concurrency limit. With `--jobs 1`, two
# concurrently-launched parents that each inject a tool-installing child must not
# run their installs overlapping. The dummy installer (via its staged test-only
# hook) claims a lock for the duration of each install and records an overlap
# marker if a second install starts while the first holds it; under a correct
# fix that honours the jobs limit, no overlap marker appears and both installs
# complete (each prints the dummy tool's output).

cat <<EOF >mise.toml
[tasks.install-one]
tools = { dummy = "1.0.0" }
run = "dummy"

[tasks.install-two]
tools = { dummy = "2.0.0" }
run = "dummy"

[tasks.install-one-parent]
run = [{ task = "install-one" }]

[tasks.install-two-parent]
run = [{ task = "install-two" }]
EOF

install_gate="$HOME/deferred-install-gate"
assert_contains \
  "DUMMY_INSTALL_GATE_DIR='$install_gate' mise run --jobs 1 install-one-parent ::: install-two-parent" \
  "This is Dummy"
assert_fail "test -e '$install_gate.overlap'"
