#!/usr/bin/env bash
# Criterion: a task reached only through a `run` reference has its task-local
# tool installed before it runs. Exits 0 iff the scenario's assertions pass.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"
source "$HERE/scenario_common.sh"
staged="$(prepare_plugins)"
SCENARIO_PLUGIN_DIR="$staged" bash "$HERE/run_scenario.sh" "$HERE/body_injected.sh"
