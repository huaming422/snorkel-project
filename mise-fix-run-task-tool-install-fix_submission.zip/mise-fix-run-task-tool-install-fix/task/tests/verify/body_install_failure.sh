#!/usr/bin/env bash
# Sourced inside the isolated environment. Behaviour: a failed late install for
# an injected task must surface as that task's failure and, under
# `--continue-on-error`, must not abort sibling tasks that are already running.
# The injected child requests a dummy version the installer rejects, so its late
# install fails; a sibling sleeps briefly then prints a marker. The overall run
# must fail, yet the sibling's marker must still appear in the output.

cat <<EOF >mise.toml
[tasks.install-failure]
tools = { dummy = "other-dummy" }
run = "echo should-not-run"

[tasks.install-failure-parent]
run = [{ task = "install-failure" }]

[tasks.install-sibling]
run = "sleep 0.2; echo sibling-completed"
EOF

assert_fail_contains \
  "mise run --continue-on-error install-failure-parent ::: install-sibling 2>&1" \
  "sibling-completed"
