#!/usr/bin/env bash
# Sourced inside the isolated environment (assert helpers already loaded, cwd is
# the isolated workdir). Headline behaviour: a tool-bearing task reached only
# because a parent references it from a `run` entry must have its tool installed
# before it starts, so the child's command produces the tool's output.

cat <<EOF >mise.toml
[tasks.child]
tools = { tiny = "1" }
run = "rtx-tiny"

[tasks.parent]
run = [{ task = "child" }]
EOF

assert "mise run parent" "rtx-tiny: v1.0.1 args:"
