#!/usr/bin/env bash
# Criterion (regression guard): direct run and `depends`-pulled tool-bearing
# tasks still install their tools and work. Exits 0 iff the scenario's
# assertions pass.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"
source "$HERE/scenario_common.sh"
staged="$(prepare_plugins)"
SCENARIO_PLUGIN_DIR="$staged" bash "$HERE/run_scenario.sh" "$HERE/body_no_regression.sh"
