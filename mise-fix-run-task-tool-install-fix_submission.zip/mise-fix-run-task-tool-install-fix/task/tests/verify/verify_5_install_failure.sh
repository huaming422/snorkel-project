#!/usr/bin/env bash
# Criterion: a failed late install for an injected task surfaces as that task's
# failure and, under `--continue-on-error`, does not abort already-running
# siblings. Exits 0 iff the scenario's assertions pass.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"
source "$HERE/scenario_common.sh"
staged="$(prepare_plugins)"
SCENARIO_PLUGIN_DIR="$staged" bash "$HERE/run_scenario.sh" "$HERE/body_install_failure.sh"
