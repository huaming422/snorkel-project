#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# Prepares the mise e2e harness to run OFFLINE against the agent's tree.
#
# No assertion logic here — this only brings the baked dependency closure online
# and builds the current (agent-edited) mise binary so the verifier can exercise
# `mise run` end-to-end. The reward stage's verifier wires up the actual e2e
# scenarios; see /state/author/blueprint.md "Test Infrastructure References" for
# the harness details it must honor (tiny-plugin symlink + MISE_USE_VERSIONS_HOST=0).
cd /repo/mise

# Offline switch for this task's own cargo invocations. Set here, never as image
# ENV (an image-wide cargo offline switch would also break harbor's network-up
# trial prep). The image warmed the full workspace dependency closure at build,
# so an offline build succeeds from the cargo cache.
export CARGO_NET_OFFLINE=true

# Build the mise binary offline-first from the image's warm cache; log an online
# fallback only if the bake was stale. The e2e harness resolves the binary at
# $CARGO_TARGET_DIR/debug/mise, so it must exist and reflect the agent's edits.
if cargo build --locked --offline -p mise > /tmp/test-setup-build.log 2>&1; then
    echo "[offline-first] mise binary built from warm cargo cache"
elif cargo build --locked -p mise >> /tmp/test-setup-build.log 2>&1; then
    echo "[test-setup] mise binary built online (image bake was stale)"
else
    tail -60 /tmp/test-setup-build.log >&2; exit 1
fi

# Confirm the runnable binary is present for the e2e harness.
test -x "${CARGO_TARGET_DIR:-target}/debug/mise"
