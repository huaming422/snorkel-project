// Behavioral verifier for the do-only workflow-registration defect.
//
// It drives the public, pre-existing builder entry point
// zigflow.NewWorkflow with a recording worker.Worker and asserts on the SET
// of workflow names that get registered (membership and absence), plus the
// deterministic duplicate-name build error. This is the exact path the
// production worker wiring uses, runs fully offline (no Temporal server), and
// references no identifier introduced by the fix — so it compiles and FAILS
// (not errors) on the unfixed baseline and PASSES once the behavior is
// corrected.
//
// Each Test* function maps to one test_criteria key (noted in its doc
// comment). The runner joins all func Test* names into its -run regex, so one
// function per shape is the discovery contract.

package zigflow_test

import (
	"strings"
	"testing"

	"github.com/nexus-rpc/sdk-go/nexus"
	"github.com/zigflow/zigflow/pkg/cloudevents"
	"github.com/zigflow/zigflow/pkg/zigflow"
	"github.com/zigflow/zigflow/pkg/zigflow/tasks"
	"go.temporal.io/sdk/activity"
	"go.temporal.io/sdk/workflow"
)

// registrationProbeWorker637 captures the workflow names registered during a build. It
// satisfies the full worker.Worker interface; only RegisterWorkflowWithOptions
// carries observable signal. The rest are inert so the builder can call them
// freely.
type registrationProbeWorker637 struct{ names []string }

func (r *registrationProbeWorker637) RegisterWorkflowWithOptions(_ any, opts workflow.RegisterOptions) {
	r.names = append(r.names, opts.Name)
}
func (r *registrationProbeWorker637) RegisterWorkflow(_ any)                                           {}
func (r *registrationProbeWorker637) RegisterActivity(_ any)                                           {}
func (r *registrationProbeWorker637) RegisterActivityWithOptions(_ any, _ activity.RegisterOptions)    {}
func (r *registrationProbeWorker637) RegisterDynamicActivity(_ any, _ activity.DynamicRegisterOptions) {}
func (r *registrationProbeWorker637) RegisterDynamicWorkflow(_ any, _ workflow.DynamicRegisterOptions) {}
func (r *registrationProbeWorker637) RegisterNexusService(_ *nexus.Service)                            {}
func (r *registrationProbeWorker637) Run(_ <-chan interface{}) error                                   { return nil }
func (r *registrationProbeWorker637) Start() error                                                     { return nil }
func (r *registrationProbeWorker637) Stop()                                                            {}

// buildRegistrationNames637 parses a YAML document and drives the whole build pipeline,
// returning the set of registered workflow names and any build error.
func buildRegistrationNames637(t *testing.T, yamlDoc string) ([]string, error) {
	t.Helper()
	doc, err := zigflow.LoadFromBytes([]byte(yamlDoc))
	if err != nil {
		t.Fatalf("LoadFromBytes: %v", err)
	}
	emitter, err := cloudevents.Load("", nil, doc)
	if err != nil {
		t.Fatalf("cloudevents.Load: %v", err)
	}
	rec := &registrationProbeWorker637{}
	err = zigflow.NewWorkflow(rec, doc, nil, emitter, nil, &tasks.TaskOpts{})
	return rec.names, err
}

func hasRegistrationName637(names []string, want string) bool {
	for _, n := range names {
		if n == want {
			return true
		}
	}
	return false
}

// buildRegistrationNamesOK637 builds and fails the test on any build error. Used by every
// register/not-register case; only the duplicate-name case expects an error.
func buildRegistrationNamesOK637(t *testing.T, yamlDoc string) []string {
	t.Helper()
	names, err := buildRegistrationNames637(t, yamlDoc)
	if err != nil {
		t.Fatalf("NewWorkflow returned an unexpected build error: %v", err)
	}
	return names
}

// ---------------------------------------------------------------------------
// crit_fork_branch (fail_to_pass)
// A fork branch made only of do tasks runs as its own child workflow and must
// be registered under its generated child-workflow name
// (workflow_fork_<fork>_<branch>). Unfixed: never registered, branch hangs.
// ---------------------------------------------------------------------------

const forkDoOnly637 = `
document:
  dsl: 1.0.0
  taskQueue: fork-do-only-branch
  workflowType: workflow
  version: 0.0.1
do:
  - parallel:
      fork:
        branches:
          - left:
              do:
                - inner:
                    do:
                      - mark:
                          set:
                            left: true
          - right:
              set:
                right: true
  - after:
      set:
        done: true
`

func TestForkDoOnlyBranchRegistered(t *testing.T) {
	names := buildRegistrationNamesOK637(t, forkDoOnly637)
	want := "workflow_fork_parallel_left"
	if !hasRegistrationName637(names, want) {
		t.Fatalf("expected child-workflow %q registered for the do-only fork branch; got %v", want, names)
	}
}

// ---------------------------------------------------------------------------
// crit_fork_compete_loser (fail_to_pass)
// A competing-fork (compete: true) branch of only do tasks is likewise
// registered, so the losing branch still has a resolvable workflow type.
// ---------------------------------------------------------------------------

const forkCompeteDoOnlyLoser637 = `
document:
  dsl: 1.0.0
  taskQueue: fork-compete-do-only-loser
  workflowType: workflow
  version: 0.0.1
do:
  - race:
      fork:
        compete: true
        branches:
          - fast:
              set:
                won: true
          - slow:
              do:
                - inner:
                    do:
                      - pause:
                          set:
                            slow: true
  - after:
      set:
        done: true
`

func TestForkCompeteDoOnlyLoserRegistered(t *testing.T) {
	names := buildRegistrationNamesOK637(t, forkCompeteDoOnlyLoser637)
	want := "workflow_fork_race_slow"
	if !hasRegistrationName637(names, want) {
		t.Fatalf("expected competing-fork loser branch %q registered; got %v", want, names)
	}
}

// ---------------------------------------------------------------------------
// crit_switch_target (fail_to_pass)
// A do-only list that a `switch ... then:` in the same list redirects to is
// registered under its task name (a switch runs its target as a child
// workflow).
// ---------------------------------------------------------------------------

const switchTarget637 = `
document:
  dsl: 1.0.0
  taskQueue: switch-to-do-only
  workflowType: workflow
  version: 0.0.1
do:
  - check:
      switch:
        - always:
            then: group
  - group:
      do:
        - inner:
            do:
              - mark:
                  set:
                    reached: true
`

func TestSwitchTargetDoOnlyRegistered(t *testing.T) {
	names := buildRegistrationNamesOK637(t, switchTarget637)
	if !hasRegistrationName637(names, "group") {
		t.Fatalf("expected switch redirect target %q registered; got %v", "group", names)
	}
}

// ---------------------------------------------------------------------------
// crit_switch_leading_do_only (fail_to_pass)
// A leading inline do-only list that is ALSO the target of a switch in the
// same list is registered, even though it also runs inline before the first
// non-do task. Covered in two shapes: bare, and wrapped in a `try`.
// ---------------------------------------------------------------------------

const switchLeadingDoOnly637 = `
document:
  dsl: 1.0.0
  taskQueue: switch-to-leading-do-only
  workflowType: workflow
  version: 0.0.1
do:
  - group:
      do:
        - inner:
            do:
              - mark:
                  set:
                    reached: true
  - check:
      switch:
        - always:
            then: group
`

const switchLeadingDoOnlyInTry637 = `
document:
  dsl: 1.0.0
  taskQueue: switch-to-leading-do-only-in-try
  workflowType: workflow
  version: 0.0.1
do:
  - attempt:
      try:
        - group:
            do:
              - inner:
                  do:
                    - mark:
                        set:
                          reached: true
        - check:
            switch:
              - always:
                  then: group
      catch:
        do:
          - recovered:
              set:
                caught: true
`

func TestSwitchLeadingDoOnlyRegistered(t *testing.T) {
	t.Run("bare", func(t *testing.T) {
		names := buildRegistrationNamesOK637(t, switchLeadingDoOnly637)
		if !hasRegistrationName637(names, "group") {
			t.Fatalf("expected leading do-only redirect target %q registered; got %v", "group", names)
		}
	})
	t.Run("in_try", func(t *testing.T) {
		names := buildRegistrationNamesOK637(t, switchLeadingDoOnlyInTry637)
		if !hasRegistrationName637(names, "group") {
			t.Fatalf("expected leading do-only redirect target %q (inside try) registered; got %v", "group", names)
		}
	})
}

// ---------------------------------------------------------------------------
// crit_top_level_multi (fail_to_pass)
// In a top-level document whose do list holds only do-task entries, each entry
// is registered as its own workflow AND the top-level list's own name is NOT
// registered.
// ---------------------------------------------------------------------------

const topLevelMulti637 = `
document:
  dsl: 1.0.0
  taskQueue: multi-workflow-do-only
  workflowType: ignored
  version: 0.0.1
do:
  - workflow1:
      do:
        - phase:
            do:
              - mark:
                  set:
                    one: true
  - workflow2:
      do:
        - mark:
            set:
              two: true
`

func TestTopLevelMultiWorkflowRegistered(t *testing.T) {
	names := buildRegistrationNamesOK637(t, topLevelMulti637)
	for _, want := range []string{"workflow1", "workflow2"} {
		if !hasRegistrationName637(names, want) {
			t.Fatalf("expected top-level workflow %q registered; got %v", want, names)
		}
	}
	// The document's top-level list is a set of separate workflows, not a
	// workflow of its own: its own name must not appear.
	if hasRegistrationName637(names, "ignored") {
		t.Fatalf("top-level document list name %q must NOT be registered; got %v", "ignored", names)
	}
}

// ---------------------------------------------------------------------------
// crit_inline_not_registered (pass_to_pass)
// A do-only list that runs purely inline (a leading group of steps that is not
// a redirect target) is NOT registered. Guards against an over-broad fix that
// registers every do-only list. Passes on the baseline and must stay passing.
// ---------------------------------------------------------------------------

const inlineNotRegistered637 = `
document:
  dsl: 1.0.0
  taskQueue: inline-do-only
  workflowType: workflow
  version: 0.0.1
do:
  - group:
      do:
        - inner:
            do:
              - mark:
                  set:
                    reached: true
  - after:
      set:
        done: true
`

func TestInlineDoOnlyListNotRegistered(t *testing.T) {
	names := buildRegistrationNamesOK637(t, inlineNotRegistered637)
	if hasRegistrationName637(names, "group") {
		t.Fatalf("inline leading do-only group %q must NOT be registered; got %v", "group", names)
	}
}

// ---------------------------------------------------------------------------
// crit_duplicate_name_error (fail_to_pass)
// When two task lists claim the same workflow name, building the document
// reports a clear conflict instead of proceeding or panicking.
// ---------------------------------------------------------------------------

const duplicateName637 = `
document:
  dsl: 1.0.0
  taskQueue: dup
  workflowType: ignored
  version: 0.0.1
do:
  - report:
      do:
        - gather:
            do:
              - collect:
                  set:
                    collect: true
  - daily:
      do:
        - report:
            do:
              - summarise:
                  set:
                    summarise: true
`

func TestDuplicateWorkflowNameReportsConflict(t *testing.T) {
	_, err := buildRegistrationNames637(t, duplicateName637)
	if err == nil {
		t.Fatalf("expected a deterministic duplicate-name build error, got nil")
	}
	msg := err.Error()
	// Require the shared workflow name and enough context to identify the
	// nested claimant, without prescribing error vocabulary or path syntax.
	lower := strings.ToLower(msg)
	if !strings.Contains(lower, "report") || !strings.Contains(lower, "daily") {
		t.Fatalf("duplicate workflow name error should identify report and daily: %s", msg)
	}
}
