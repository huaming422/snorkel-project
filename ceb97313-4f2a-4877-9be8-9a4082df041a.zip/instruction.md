## Task

Some Zigflow workflows start but then remain stuck. Their worker logs contain
Temporal's "unable to find workflow type" error. We see this with documents
whose parts run on their own, including parallel `fork` branches, `switch`
redirects elsewhere in the document, and files defining multiple workflows.
Straight sequential workflows still finish.

Find the cause and make the affected documents complete. Keep sequential steps
and inline groups working as they do now. If two workflows in one document
share a name, report the conflict clearly during setup instead of crashing.
