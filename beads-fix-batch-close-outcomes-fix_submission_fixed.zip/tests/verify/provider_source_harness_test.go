package httpapi

// Test-only infrastructure for driving the many-issue batch-close endpoint down
// its PROVIDER seam with a caller-supplied result. It is injected into
// internal/httpapi at verify time by test-setup.sh (it is not part of the
// repository) and consumed only by the provider-source cases in verify_test.go.
//
// Why it is needed: the endpoint obtains its closer two ways. When no
// unit-of-work provider is configured it uses a directly-configured role, which
// the pre-existing harness (newBatchCloseServer) can seed with any result. When
// a provider IS configured, the server builds the closer over the provider
// itself (timedProvider.BatchCloser -> uow.NewBatchCloser), and that built
// closer cannot emit the miscounted or contentless shapes under test: it writes
// one outcome per item, each with a row or an error. So there is no in-tree way
// to exercise a malformed result on the provider branch. The seam below lets
// the provider hand the provider-built closer a stub to answer from (see
// batchcloser_testseam.go.txt and test-setup.sh); no production provider
// implements it, so production behavior is unchanged.

import "github.com/steveyegge/beads/issueops"

// providerBatchCloseSource is a unit-of-work provider (it embeds the package's
// fakeProvider, so it satisfies uow.UnitOfWorkProvider and drives the server's
// provider branch) whose batch-close answers come from a stub the test supplies.
type providerBatchCloseSource struct {
	fakeProvider
	closer issueops.BatchCloser
}

// overrideBatchCloserForTest is the hook timedProvider.BatchCloserOverrideForTest
// forwards to. Present only on this test type.
func (p *providerBatchCloseSource) overrideBatchCloserForTest() issueops.BatchCloser {
	return p.closer
}

// newProviderBatchCloseSource wraps a seeded role closer in a provider so a
// case can POST against the real endpoint on the provider seam and still
// control the result the closer returns.
func newProviderBatchCloseSource(closer issueops.BatchCloser) *providerBatchCloseSource {
	return &providerBatchCloseSource{closer: closer}
}
