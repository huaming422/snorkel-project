package httpapi

// Test-only infrastructure for driving the many-issue batch-close endpoint down
// its PROVIDER seam with a caller-supplied result. It is injected into
// internal/httpapi at verify time by test-setup.sh (it is not part of the
// repository) and consumed only by the provider-path cases in verify_test.go.
//
// Why it is needed: the endpoint obtains its closer two ways. When no
// unit-of-work provider is configured it uses a directly-configured role, which
// the pre-existing harness (newBatchCloseServer) can seed with any result. When
// a provider IS configured, the server builds the closer over the provider
// itself (timedProvider.BatchCloser -> uow.NewBatchCloser), and that built
// closer is correct by construction: it cannot emit the miscounted or
// contentless shapes under test. There is therefore no
// in-tree way to exercise a malformed result on the provider branch, so the
// seam below lets a provider hand the server a stub closer of the test's
// choosing. The timedProvider.BatchCloser accessor consults this override
// (added by the same test-setup.sh step) only for a provider that implements
// it; no production provider does, so production behavior is unchanged.

import "github.com/steveyegge/beads/issueops"

// providerBatchCloseSource is a unit-of-work provider (it embeds the package's
// fakeProvider, so it satisfies uow.UnitOfWorkProvider and drives the server's
// provider branch) whose batch-close role is a stub the test supplies.
type providerBatchCloseSource struct {
	fakeProvider
	closer issueops.BatchCloser
}

// overrideBatchCloserForTest is the hook timedProvider.BatchCloser looks for:
// when the provider implements it, the server uses this closer instead of the
// one it would build over the provider. Present only on this test type.
func (p *providerBatchCloseSource) overrideBatchCloserForTest() issueops.BatchCloser {
	return p.closer
}

// newProviderBatchCloseSource wraps a seeded role closer in a provider so a
// case can POST against the real endpoint on the provider seam and still
// control the result the closer returns.
func newProviderBatchCloseSource(closer issueops.BatchCloser) *providerBatchCloseSource {
	return &providerBatchCloseSource{closer: closer}
}
