package httpapi

// Behavioral checks for the many-issue batch-close custom method, driven
// through the real HTTP endpoint over the pre-existing in-package harness
// (newBatchCloseServer / roleBatchCloser / rolesConfig). Every assertion is a
// wire-observable fact: HTTP status, the `code` vocabulary, and the presence or
// absence of `outcomes` / `issue` / `already_closed` / `issue_id` in the
// decoded body.
//
// The endpoint obtains its closer two ways, and the request cannot tell them
// apart: a directly-configured role when no unit-of-work provider is set, and a
// provider-built role when one is. Every case below runs down both. The
// provider-source harness is test-only infrastructure, injected alongside this
// file (see test-setup.sh); it exists because a real provider-built closer
// cannot itself emit the malformed shapes under test.

import (
	"fmt"
	"net/http"
	"testing"

	"github.com/steveyegge/beads/issueops"
)

// itemWant is what one requested item may come back as when a malformed result
// is answered with a 200.
type itemWant int

const (
	// wantRefusedInternally: the result holds nothing that can be vouched for
	// as this item's answer, so it must come back as an `internal` refusal with
	// no row.
	wantRefusedInternally itemWant = iota
	// wantLandedOrRefused: the result reports a close with its row. The item may
	// keep that answer, or be refused as `internal` like the rest of the batch.
	wantLandedOrRefused
	// wantNotFoundOrRefused: the result reports a typed `not_found` refusal. The
	// item may keep it, or be refused as `internal` like the rest of the batch.
	wantNotFoundOrRefused
)

// verifyUntrustedResultAnswer checks the answer to a request whose closer
// reported a result that cannot be passed on as it stands. Two answers are
// accepted:
//
//   - a problem document: 500 with the `internal` code and no `outcomes`;
//   - a 200 carrying exactly one outcome per requested item, in request order,
//     each echoing the requested id, where every item in wants follows its
//     itemWant.
func verifyUntrustedResultAnswer(t *testing.T, resp *http.Response, ids []string, wants []itemWant) {
	t.Helper()
	status := resp.StatusCode
	body := decodeBody(t, resp)
	switch status {
	case http.StatusInternalServerError:
		if body["code"] != string(CodeInternal) {
			t.Errorf("code = %v, want %s", body["code"], CodeInternal)
		}
		if _, present := body["outcomes"]; present {
			t.Errorf("a 500 still carried a per-item array: %v", body)
		}
	case http.StatusOK:
		raw, ok := body["outcomes"].([]any)
		if !ok {
			t.Fatalf("outcomes = %#v, want an array", body["outcomes"])
		}
		if len(raw) != len(ids) {
			t.Fatalf("got %d outcomes for %d requested items: a client reading them by position "+
				"credits results to the wrong issues: %v", len(raw), len(ids), raw)
		}
		for i, entry := range raw {
			outcome, ok := entry.(map[string]any)
			if !ok {
				t.Fatalf("outcomes[%d] = %#v, want an object", i, entry)
			}
			if outcome["issue_id"] != ids[i] {
				t.Errorf("outcomes[%d].issue_id = %v, want %q", i, outcome["issue_id"], ids[i])
			}
			code, refused := outcome["code"]
			_, hasRow := outcome["issue"]
			_, hasClosedFlag := outcome["already_closed"]
			internal := refused && code == string(CodeInternal) && !hasRow && !hasClosedFlag
			switch wants[i] {
			case wantRefusedInternally:
				if !internal {
					t.Errorf("outcomes[%d] = %v, want an %s refusal with no row and no "+
						"already_closed: nothing in the result can be vouched for as this item's answer",
						i, outcome, CodeInternal)
				}
			case wantLandedOrRefused:
				landed := !refused && hasRow
				if !landed && !internal {
					t.Errorf("outcomes[%d] = %v, want the closed item with its row, or an %s "+
						"refusal with no row", i, outcome, CodeInternal)
				}
			case wantNotFoundOrRefused:
				notFound := refused && code == string(CodeNotFound) && !hasRow
				if !notFound && !internal {
					t.Errorf("outcomes[%d] = %v, want its %s refusal, or an %s refusal, with no row",
						i, outcome, CodeNotFound, CodeInternal)
				}
			}
		}
	default:
		t.Fatalf("status = %d, want 500 or 200: %v", status, body)
	}
}

// closerSource builds a server whose batch-close role answers with closer.
type closerSource struct {
	name  string
	serve func(t *testing.T, closer *roleBatchCloser) *testServer
}

// closerSources are the two ways the endpoint obtains its closer.
var closerSources = []closerSource{
	{"configured role", newBatchCloseServer},
	{"provider", newProviderBatchCloseServer},
}

// newProviderBatchCloseServer binds a server whose closer comes from the
// PROVIDER source rather than a directly-configured role, and hands that source
// the supplied closer so a case can still drive a malformed result down it.
// providerBatchCloseSource is defined in the injected provider-source harness
// (see test-setup.sh).
func newProviderBatchCloseServer(t *testing.T, closer *roleBatchCloser) *testServer {
	t.Helper()
	return newTestServer(t, Config{Provider: newProviderBatchCloseSource(closer)})
}

// requireCloserReached fails the case when a request never reached the supplied
// closer, so a case cannot pass on a server that answered without it.
func requireCloserReached(t *testing.T, closer *roleBatchCloser, requests int) {
	t.Helper()
	if got := len(closer.closeBatchRequests()); got < requests {
		t.Fatalf("the supplied closer saw %d requests, want at least %d: the endpoint did not answer from "+
			"it, so this case checked nothing (on the provider source, test-setup.sh could not "+
			"install its seam)", got, requests)
	}
}

type untrustedCase struct {
	name     string
	body     string
	ids      []string
	outcomes []issueops.CloseOutcome
	wants    []itemWant
}

// A result whose outcome count does not match the request cannot be walked
// against the caller's items: read by position, one item's answer would be
// reported under another item's id. Both the short and the long mismatch are
// covered.
var miscountedCases = []untrustedCase{
	{
		name: "fewer outcomes than items",
		body: `{"actor":"alice","items":[{"id":"bd-1"},{"id":"bd-2"}]}`,
		ids:  []string{"bd-1", "bd-2"},
		outcomes: []issueops.CloseOutcome{
			{IssueID: "bd-1", Issue: closedIssue("bd-1"), Changed: true},
		},
		wants: []itemWant{wantRefusedInternally, wantRefusedInternally},
	},
	{
		name: "more outcomes than items",
		body: `{"actor":"alice","items":[{"id":"bd-1"},{"id":"bd-2"}]}`,
		ids:  []string{"bd-1", "bd-2"},
		outcomes: []issueops.CloseOutcome{
			{IssueID: "bd-1", Issue: closedIssue("bd-1"), Changed: true},
			{IssueID: "bd-2", Issue: closedIssue("bd-2"), Changed: true},
			{IssueID: "bd-3", Issue: closedIssue("bd-3"), Changed: true},
		},
		wants: []itemWant{wantRefusedInternally, wantRefusedInternally},
	},
}

// An outcome carrying neither an issue row nor a refusal error has no honest
// wire shape: without a `code` it reads as a success, and there is no row
// behind it. That holds whatever its Changed flag says (unchanged, it reads as
// an idempotent re-close) and wherever it sits in the array.
var contentlessCases = []untrustedCase{
	{
		name: "empty entry after a landed close",
		body: `{"actor":"alice","items":[{"id":"bd-1"},{"id":"bd-2"}]}`,
		ids:  []string{"bd-1", "bd-2"},
		outcomes: []issueops.CloseOutcome{
			{IssueID: "bd-1", Issue: closedIssue("bd-1"), Changed: true},
			{IssueID: "bd-2", Changed: true},
		},
		wants: []itemWant{wantLandedOrRefused, wantRefusedInternally},
	},
	{
		name: "unchanged empty entry ahead of a landed close and a refusal",
		body: `{"actor":"alice","items":[{"id":"bd-1"},{"id":"bd-2"},{"id":"bd-3"}]}`,
		ids:  []string{"bd-1", "bd-2", "bd-3"},
		outcomes: []issueops.CloseOutcome{
			{IssueID: "bd-1", Changed: false},
			{IssueID: "bd-2", Issue: closedIssue("bd-2"), Changed: true},
			{IssueID: "bd-3", Err: fmt.Errorf("get: %w", issueops.ErrNotFound)},
		},
		wants: []itemWant{wantRefusedInternally, wantLandedOrRefused, wantNotFoundOrRefused},
	},
}

func runUntrustedCases(t *testing.T, src closerSource, cases []untrustedCase) {
	t.Helper()
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			closer := &roleBatchCloser{result: issueops.CloseBatchResult{Outcomes: tc.outcomes}}
			ts := src.serve(t, closer)

			resp := ts.batchClose(t, tc.body)
			requireCloserReached(t, closer, 1)
			verifyUntrustedResultAnswer(t, resp, tc.ids, tc.wants)
		})
	}
}

func TestVerifyBatchCloseDoesNotAnswerFromAMiscountedResult(t *testing.T) {
	runUntrustedCases(t, closerSources[0], miscountedCases)
}

func TestVerifyBatchCloseDoesNotAnswerFromAMiscountedResultFromProvider(t *testing.T) {
	runUntrustedCases(t, closerSources[1], miscountedCases)
}

func TestVerifyBatchCloseDoesNotPassOnAContentlessOutcome(t *testing.T) {
	runUntrustedCases(t, closerSources[0], contentlessCases)
}

func TestVerifyBatchCloseDoesNotPassOnAContentlessOutcomeFromProvider(t *testing.T) {
	runUntrustedCases(t, closerSources[1], contentlessCases)
}

// A one-item batch whose only outcome is contentless, from a closer that hands
// back the same prepared result for two requests, gets an accepted answer, and
// the same status, both times.
func TestVerifyBatchCloseAnswersARepeatedContentlessResultAlike(t *testing.T) {
	for _, src := range closerSources {
		t.Run(src.name, func(t *testing.T) {
			closer := &roleBatchCloser{result: issueops.CloseBatchResult{
				Outcomes: []issueops.CloseOutcome{{IssueID: "bd-1", Changed: true}},
			}}
			ts := src.serve(t, closer)

			const body = `{"actor":"alice","items":[{"id":"bd-1"}]}`
			statuses := make([]int, 0, 2)
			for attempt := 1; attempt <= 2; attempt++ {
				resp := ts.batchClose(t, body)
				requireCloserReached(t, closer, attempt)
				statuses = append(statuses, resp.StatusCode)
				verifyUntrustedResultAnswer(t, resp, []string{"bd-1"}, []itemWant{wantRefusedInternally})
			}
			if statuses[0] != statuses[1] {
				t.Errorf("statuses = %v: the same result was answered differently the second time", statuses)
			}
		})
	}
}

// A well-formed result, one outcome per requested item, each carrying a closed
// record or a typed refusal, projects the 200 body it always has, from either
// source.
func TestVerifyBatchClosePreservesWellFormedResult(t *testing.T) {
	for _, src := range closerSources {
		t.Run(src.name, func(t *testing.T) {
			closer := &roleBatchCloser{result: issueops.CloseBatchResult{
				Outcomes: []issueops.CloseOutcome{
					{IssueID: "bd-1", Issue: closedIssue("bd-1"), Changed: true},
					{IssueID: "bd-missing", Err: fmt.Errorf("get: %w", issueops.ErrNotFound)},
				},
			}}
			ts := src.serve(t, closer)

			resp := ts.batchClose(t, `{"actor":"alice","items":[{"id":"bd-1"},{"id":"bd-missing"}]}`)
			requireCloserReached(t, closer, 1)
			if resp.StatusCode != http.StatusOK {
				t.Fatalf("status = %d, want 200: %s", resp.StatusCode, readAll(t, resp))
			}
			outcomes := outcomesOf(t, resp)
			if len(outcomes) != 2 {
				t.Fatalf("outcomes = %v, want one per requested item", outcomes)
			}
			// The success keeps its row and carries no refusal code.
			if _, present := outcomes[0]["code"]; present {
				t.Errorf("the successful item carries a code: %v", outcomes[0])
			}
			if _, present := outcomes[0]["issue"]; !present {
				t.Errorf("the successful item lost its row: %v", outcomes[0])
			}
			if outcomes[0]["already_closed"] != false {
				t.Errorf("already_closed = %v, want false for an item this batch closed", outcomes[0]["already_closed"])
			}
			// The typed refusal keeps its code and carries no row.
			if outcomes[1]["code"] != string(CodeNotFound) {
				t.Errorf("code = %v, want %s for a not-found refusal", outcomes[1]["code"], CodeNotFound)
			}
			if _, present := outcomes[1]["issue"]; present {
				t.Errorf("a refusal carried an issue row: %v", outcomes[1])
			}
		})
	}
}
