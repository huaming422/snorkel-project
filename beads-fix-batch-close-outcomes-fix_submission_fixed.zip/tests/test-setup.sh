#!/bin/bash
# Setup for the beads-fix-batch-close-outcomes verifier.
#
# The verifier is a native Go test added to internal/httpapi. The Go toolchain,
# the module cache and a build cache warmed at the base commit are baked into
# the image (environment/Dockerfile blocks 3, 6, 7), so nothing is fetched here.
#
# This step also installs test-only provider-seam infrastructure that lets the
# verifier drive the batch-close endpoint's PROVIDER branch with a malformed
# result. It is applied HERE, after the working tree under test has been
# committed (test.sh commits it before sourcing this script), so none of it is
# part of the change being tested.
#
# Why it is needed: the endpoint obtains its closer two ways: a directly
# configured role (no unit-of-work provider), or one the server builds over the
# provider (the path a real server/shared-server deployment runs on). The
# pre-existing harness can only seed a result on the DIRECT path; the
# provider-built closer writes one outcome per item, each with a row or an
# error, so it cannot itself emit the miscounted or contentless shapes under
# test. The pieces below give the verifier a provider seam it can feed a
# malformed result:
#
#   1. A provider-source harness file (providerBatchCloseSource) copied into the
#      httpapi package so the verifier can bind a server on the provider seam.
#   2. A seam helper (batchcloser_testseam.go) adding
#      timedProvider.BatchCloserOverrideForTest, plus a guarded hand-off at the
#      top of the provider-built closer's CloseBatch in
#      internal/storage/uow/batch_closer.go: when the provider it was built over
#      supplies a test closer, the request goes to that closer instead of a unit
#      of work. No production provider supplies one, so production behavior is
#      unchanged.
#
# The hand-off sits in the innermost closer, below anything the endpoint wraps
# around it, so it holds however the endpoint and timedProvider's accessor are
# arranged. claim.go is not touched. If the CloseBatch signature cannot be
# found, the hand-off is skipped with a warning, and every provider-source case
# fails with a message saying its closer was never reached.
#
# Every step is a text operation on the working tree as it stands, and step 2b
# is idempotent.

set -euo pipefail

export REPO_NAME=beads
REPO_DIR="/repo/beads"
PKG_DIR="$REPO_DIR/internal/httpapi"

cd "$REPO_DIR"

# Confirm the toolchain and module cache are present and usable offline. `go
# version` resolves entirely from the baked toolchain; no network is touched.
go version

# 1. Provider-source harness, next to the package's own test files. It is a
#    `_test.go` file, so it compiles only under `go test` and ships no
#    production symbol. The runner leaves pre-existing *_test.go in place (the
#    verifier defines no TestMain), so it compiles alongside verify_test.go.
cp /tests/verify/provider_source_harness_test.go "$PKG_DIR/provider_source_harness_test.go"

# 2a. Seam helper (a real .go file; the method it adds returns nil for every
#     production provider and a closer only for the test provider).
cp /tests/verify/batchcloser_testseam.go.txt "$PKG_DIR/batchcloser_testseam.go"

# 2b. Hand-off at the top of the provider-built closer's CloseBatch, matched on
#     the method's signature (any receiver and parameter names) rather than its
#     body.
python3 - <<'PY'
import re
import sys

path = "/repo/beads/internal/storage/uow/batch_closer.go"
src = open(path).read()

if "BatchCloserOverrideForTest" in src:
    print("provider-seam hand-off already present; skipping")
    sys.exit(0)

signature = re.compile(
    r"^func \((\w+) \*batchCloser\) CloseBatch\((\w+) context\.Context, (\w+) "
    r"publicops\.CloseBatchRequest\) \(publicops\.CloseBatchResult, error\) \{\n",
    re.MULTILINE,
)
match = signature.search(src)
if match is None:
    print("WARNING: uow batchCloser.CloseBatch signature not found; provider-seam "
          "hand-off not installed (provider-source cases will report an unreached closer)",
          file=sys.stderr)
    sys.exit(0)

recv, ctx, req = match.groups()
handoff = (
    f"\tif src, ok := {recv}.provider.(interface {{\n"
    f"\t\tBatchCloserOverrideForTest() publicops.BatchCloser\n"
    f"\t}}); ok {{\n"
    f"\t\tif stub := src.BatchCloserOverrideForTest(); stub != nil {{\n"
    f"\t\t\treturn stub.CloseBatch({ctx}, {req})\n"
    f"\t\t}}\n"
    f"\t}}\n"
)
src = src[:match.end()] + handoff + src[match.end():]
open(path, "w").write(src)
print("provider-seam hand-off installed in internal/storage/uow/batch_closer.go")
PY
