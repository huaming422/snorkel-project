## Task

`POST /v0/beads/issues:batchClose` sometimes answers 200 with an `outcomes` array clients can't use. Clients walk it by position against the items they sent. In the bad responses, either the array doesn't have one entry per requested item, so results end up matched to the wrong issues, or an entry has neither a `code` nor an `issue`, which reads as a close that worked with nothing to show for it. The status says success, so nothing downstream notices.

A client shouldn't be able to take either of those for a real answer. Clients act on this endpoint's status codes and per-item `code` values the way its API document describes, and that has to keep holding.
