## Task

Some `POST /v0/beads/issues:batchClose` calls come back 200 with an `outcomes` list that doesn't match the request. Callers read `outcomes` in order against the items they sent, so these answers get applied to the wrong issues or recorded as closes that never produced an issue.

We've seen two versions. In one, `outcomes` has fewer or more entries than the request had items. In the other, the count is right but one entry has its `issue_id` and no `code` or `issue`, which a caller reads as a successful close with no issue to show for it.

Callers shouldn't be able to mistake either of these for a normal answer.
