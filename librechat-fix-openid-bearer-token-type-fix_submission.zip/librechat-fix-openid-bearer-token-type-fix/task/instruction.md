## Task

a couple of Entra/Azure AD customers are escalating: after they sign in with OpenID, their agent actions and MCP tool calls intermittently fail with `AADSTS240002 - Input id_token cannot be used as 'assertion'`, and some users get bounced back to re-authenticate right after logging in. it only seems to hit deployments that aren't running a persistent session store, and it's recent. dig in and fix it.
