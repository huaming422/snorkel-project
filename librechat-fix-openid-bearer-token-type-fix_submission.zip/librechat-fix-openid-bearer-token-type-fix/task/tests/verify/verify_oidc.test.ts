// @ts-nocheck
//
// Credential-placeholder resolution checks for the @librechat/api token
// utilities.
//
// Interface under test: `resolveHeaders` from ./env — a pre-existing export of
// the package. The file is copied into packages/api/src/utils, so `./env`
// resolves the agent's edited source (babel-jest transpiles the TS directly; no
// dist rebuild needed for this surface). We assert only on observable results:
// the resolved header string, or that an actionable re-auth error is raised. No
// internal helper, field list, or regex constant is imported or named, so a fix
// that threads an allowlist, adds a single-field resolver, or splits the
// credential pattern any other way passes identically.

import { resolveHeaders } from './env';

// The OpenID JWT strategy stores a federated-token bundle with no access_token
// when it cannot identify the inbound bearer as one; an ID token with its own
// expiry is still present. This models that post-authentication state.
function accessTokenlessOpenIDUser(idTokenExp: number): { user: any; idToken: string } {
  const idToken = `header.${Buffer.from(
    JSON.stringify({ sub: 'oidc-sub-456', exp: idTokenExp }),
  ).toString('base64')}.signature`;
  const user = {
    id: 'user-123',
    provider: 'openid',
    openidId: 'oidc-sub-456',
    email: 'test@example.com',
    name: 'Test User',
    federatedTokens: { id_token: idToken, refresh_token: 'stored-refresh-token' },
  };
  return { user, idToken };
}

const validSeconds = Math.floor(Date.now() / 1000) + 3600;

describe('OpenID placeholder resolution with no usable access token', () => {
  it('resolves an ID-token credential placeholder on the ID token\'s own expiry', () => {
    const { user, idToken } = accessTokenlessOpenIDUser(validSeconds);

    const resolved = resolveHeaders({
      headers: { Authorization: 'Bearer {{LIBRECHAT_OPENID_ID_TOKEN}}' },
      user,
      stripUnresolved: true,
    });

    expect(resolved.Authorization).toBe(`Bearer ${idToken}`);
  });

  it('still raises an actionable re-auth error for an access-token placeholder', () => {
    const { user } = accessTokenlessOpenIDUser(validSeconds);

    expect(() =>
      resolveHeaders({
        headers: { Authorization: 'Bearer {{LIBRECHAT_OPENID_ACCESS_TOKEN}}' },
        user,
      }),
    ).toThrow('re-authentication is required to resolve {{LIBRECHAT_OPENID_ACCESS_TOKEN}}');
  });

  it('keeps identity-metadata placeholders literal (not resolved as credentials)', () => {
    const { user } = accessTokenlessOpenIDUser(validSeconds);

    const resolved = resolveHeaders({
      headers: { 'X-User-Id': '{{LIBRECHAT_OPENID_USER_ID}}' },
      user,
    });

    expect(resolved['X-User-Id']).toBe('{{LIBRECHAT_OPENID_USER_ID}}');
  });
});
