## Task

We did a hardening pass on user-added Custom Connectors and found places
where the handling trusts input it shouldn't, whether typed in or loaded
back from saved settings.

A few things we've actually seen go wrong: a remote connector's credentials
or headers end up going to a server other than the one it was configured
for, or over a plain non-encrypted connection. Saving a connector's sign-in
state quietly undoes an address or settings change the user just made. The
approval prompt doesn't make clear which connector is asking, and a very
large request from one makes it unusable. Two look-alike connectors
get crossed, and bad or ambiguous saved entries still get picked up and
used. Typed-in credential lines get silently dropped or overwritten, and
secrets can be entered before the app knows it can store them securely.

Please dig in and tighten up the Custom Connector integrity boundaries so
these stop. It all lives within how connectors and their settings are
already handled. Leave the security-update recovery flow and per-tool
argument schema validation alone; those are out of scope here.
