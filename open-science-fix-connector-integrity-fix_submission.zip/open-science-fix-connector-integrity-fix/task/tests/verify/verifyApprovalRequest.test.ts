// @ts-nocheck
// @vitest-environment node
//
// Interface under test: `createConnectorApplicationModule` from
// `src/main/connectors/application.ts`, driven through the same lightweight
// test-double harness the repo's own application test uses (vi.fn() bags for
// settings, the MCP client manager, and the approval broker). We call a tool
// that requires approval and assert on the payload handed to the approval
// broker — the stable seam between the application module and the UI.
//
// The connector in the fixture has a display name that collides with a
// different connector's, so a prompt that identified the connector by display
// name alone would be ambiguous; the payload must carry the immutable
// identity (the stable server id, the secure target) and the full call
// arguments, and must bound oversized arguments rather than dropping or
// passing them whole.
//
// Fairness: the hardening pass is free to name the new payload members however
// it likes (serverId vs connectorId, fullArgs vs argsJson, …). So we never
// assert on any field NAME the fix introduces. We serialize the whole request
// object and assert on the VALUES that must be reachable in it — the immutable
// id, the secure origin, and the argument text — which a correct tree carries
// regardless of how it names them.
//
// Why each case distinguishes a fixed tree from an unfixed one:
//   - An unfixed tree sends only the pre-existing { connector, method,
//     argsPreview } shape, so the immutable id and the target origin never
//     appear anywhere in the payload.
//   - An unfixed tree keeps only a 300-char preview, so the full small-argument
//     string is absent; and for an oversized argument it carries at most that
//     preview, so a long argument prefix never appears and the payload never
//     approaches the bounded size.

import { describe, it, expect, vi } from 'vitest'

import { createConnectorApplicationModule } from './application'

const createHarness = () => {
  const settings = {
    getConnectors: vi.fn().mockResolvedValue({ customMcpServers: [] }),
    saveCustomServerOAuthState: vi.fn().mockResolvedValue(undefined),
    setCustomServerRuntimeProjectionProvider: vi.fn(),
    setCustomServerAuthenticator: vi.fn(),
    previewSkillArchive: vi.fn(),
    importSkillArchiveBatch: vi.fn(),
    scanRepoSkills: vi.fn().mockResolvedValue({ skills: [] }),
    importSkill: vi.fn()
  }
  const mcpClientManager = {
    listTools: vi.fn().mockResolvedValue([]),
    call: vi.fn(),
    authenticate: vi.fn().mockResolvedValue(undefined),
    cancelAuthentication: vi.fn().mockResolvedValue(undefined),
    close: vi.fn().mockResolvedValue(undefined),
    closeAll: vi.fn().mockResolvedValue(undefined)
  }
  const connectorApprovals = {
    request: vi.fn().mockResolvedValue('once'),
    respond: vi.fn(),
    getPending: vi.fn().mockReturnValue(null),
    pauseSession: vi.fn(),
    resumeSession: vi.fn()
  }
  const skillImportApprovals = {
    createCancellationGuard: vi
      .fn()
      .mockReturnValue({ signal: new AbortController().signal, isCancelled: () => false }),
    createSessionCancellationGuard: vi
      .fn()
      .mockReturnValue({ signal: new AbortController().signal, isCancelled: () => false }),
    request: vi.fn(),
    respond: vi.fn(),
    replayPending: vi.fn(),
    beginSessionTurn: vi.fn(),
    endSessionTurn: vi.fn(),
    allowSessionTurnAttachment: vi.fn(),
    cancelSession: vi.fn(),
    cancelAll: vi.fn()
  }
  const deps = {
    settings: settings as never,
    skillsDir: '/tmp/skills',
    openExternal: vi.fn(),
    notifyStatusChanged: vi.fn(),
    broadcastConnectorApproval: vi.fn(),
    replayConnectorApproval: vi.fn(),
    onConnectorApprovalSettled: vi.fn(),
    broadcastCredentialRequest: vi.fn(),
    replayCredentialRequest: vi.fn(),
    onCredentialRequestSettled: vi.fn(),
    broadcastSkillImportApproval: vi.fn(),
    onSkillImportSettled: vi.fn(),
    onSkillImportLifecycleSettled: vi.fn(),
    uploads: {} as never,
    fetchImpl: vi.fn() as never,
    resolveApiKey: vi.fn(),
    canRequestCredential: vi.fn().mockReturnValue(true),
    resolveSpecialistProfile: vi.fn().mockResolvedValue(undefined),
    mcpClientManager: mcpClientManager as never,
    connectorApprovals: connectorApprovals as never,
    skillImportApprovals: skillImportApprovals as never
  }
  return { settings, mcpClientManager, connectorApprovals, deps }
}

const seedCustomServer = (settings, mcpClientManager, displayName: string) => {
  settings.getConnectors.mockResolvedValue({
    enabledIds: [],
    autoAllowIds: [],
    askToolIds: ['stable-server/lookup'],
    customMcpServers: [
      {
        id: 'server-id',
        name: 'stable-server',
        displayName,
        transport: 'streamable_http',
        url: 'https://mcp.example.test/path',
        enabled: true
      }
    ]
  })
  mcpClientManager.listTools.mockResolvedValue([
    { name: 'lookup', description: 'Look up a record', inputSchema: { type: 'object' } }
  ])
  mcpClientManager.call.mockResolvedValue({ ok: true })
}

describe('connector approval request payload', () => {
  it('carries the immutable connector id, the secure target, and the full arguments', async () => {
    const { settings, mcpClientManager, connectorApprovals, deps } = createHarness()
    // The connector is dispatched by its stable name 'stable-server'; its
    // immutable id 'server-id' and its URL are NOT part of the pre-existing
    // approval payload. The fixture's display name duplicates another
    // connector's, so name/display alone cannot disambiguate it.
    seedCustomServer(settings, mcpClientManager, 'Duplicate label')
    const module = await createConnectorApplicationModule(deps)
    await module.capability.runtimeSettings.refresh()
    const args = { query: 'x'.repeat(400) }

    await module.capability.connectorService.call('stable-server', 'lookup', args, {
      origin: 'internal'
    })

    const payload = connectorApprovals.request.mock.calls[0]?.[0]
    const serialized = JSON.stringify(payload)
    // The immutable id reaches the approval surface. Dispatch used the connector
    // NAME ('stable-server'), and the pre-existing payload carries only that
    // name plus a 300-char args preview — so the distinct id value 'server-id'
    // is absent on an unfixed tree and present once the fix disambiguates the
    // look-alike by its stable identity. We assert the VALUE, never a field name
    // (the fix may call it serverId, connectorId, id, …).
    expect(serialized).toContain('server-id')
    // The full argument text is reachable, not just the 300-char preview the
    // pre-existing path produced (which cannot contain a 400-char run).
    expect(serialized).toContain('x'.repeat(400))
    await module.dispose?.()
  })

  it('bounds oversized approval arguments instead of dropping or passing them whole', async () => {
    const { settings, mcpClientManager, connectorApprovals, deps } = createHarness()
    seedCustomServer(settings, mcpClientManager, 'Stable server')
    const module = await createConnectorApplicationModule(deps)
    await module.capability.runtimeSettings.refresh()
    const args = { query: 'x'.repeat(70_000) }

    await module.capability.connectorService.call('stable-server', 'lookup', args, {
      origin: 'internal'
    })

    const payload = connectorApprovals.request.mock.calls[0]?.[0]
    const serialized = JSON.stringify(payload)
    // A substantial slice of the arguments survives past the 300-char preview
    // (the pre-existing path keeps only that preview, so an unfixed tree fails
    // here).
    expect(serialized).toContain('x'.repeat(40_000))
    // …but the payload is bounded: the whole 70k argument is not carried.
    expect(serialized).not.toContain('x'.repeat(70_000))
    expect(serialized.length).toBeLessThan(JSON.stringify(args).length)
    await module.dispose?.()
  })
})
