// @ts-nocheck
// @vitest-environment node
//
// Interface under test: `selectEnabledCustomServers` exported from
// `src/main/connectors/custom-mcp-bootstrap.ts`. This is the pre-existing
// discovery/route-projection seam: given the stored connectors block it
// returns the servers that may actually be exposed and dispatched. Runtime
// discovery and skill-doc sync both consume it, so a stored record that this
// function returns is a record the app will route to.
//
// We assert only the membership of its result for given stored inputs. We do
// not import or name any predicate the hardening pass might introduce (secure
// URL checks, credential-name collision checks); those are observable purely
// through whether a record survives projection.
//
// Why each case distinguishes a fixed tree from an unfixed one:
//   - A persisted non-loopback http remote must be dropped from discovery even
//     while it is still marked enabled. A tree that routes it keeps it in the
//     result and fails here.
//   - Records whose id/name collide with each other, with a bundled connector
//     id, or across the id/name boundary, and records with an invalid id, must
//     all be dropped (they stay visible elsewhere but are never routable). A
//     tree that still returns a colliding record fails here.
//   - Credential names that collide case-insensitively are ambiguous on
//     Windows for environment variables and everywhere for headers; such
//     records must be dropped on the colliding platform and kept where the
//     collision is not ambiguous. The active platform is driven via
//     `process.platform`, matching the repo's own bootstrap tests.

import { afterEach, describe, it, expect } from 'vitest'
import { selectEnabledCustomServers } from './custom-mcp-bootstrap'
import { ALL_CONNECTOR_IDS } from './registry'

const stdioServer = {
  id: 'srv-stdio',
  name: 'stdio-server',
  displayName: 'Stdio Server',
  transport: 'stdio',
  command: 'npx',
  enabled: true
}
const remoteServer = {
  id: 'srv-remote',
  name: 'remote-server',
  displayName: 'Remote Server',
  transport: 'streamable_http',
  url: 'https://mcp.example.test/mcp',
  enabled: true
}

const connectorsOf = (customMcpServers) => ({
  enabledIds: [],
  autoAllowIds: [],
  customMcpServers
})

const originalPlatform = process.platform
const withPlatform = (platform, fn) => {
  Object.defineProperty(process, 'platform', { configurable: true, value: platform })
  try {
    fn()
  } finally {
    Object.defineProperty(process, 'platform', { configurable: true, value: originalPlatform })
  }
}

afterEach(() => {
  Object.defineProperty(process, 'platform', { configurable: true, value: originalPlatform })
})

describe('custom connector discovery baseline', () => {
  it('returns a healthy secure remote and stdio server', () => {
    const selected = selectEnabledCustomServers(connectorsOf([stdioServer, remoteServer]))
    expect(selected.map((server) => server.id).sort()).toEqual(['srv-remote', 'srv-stdio'])
  })
})

describe('custom connector discovery excludes insecure transports', () => {
  it('drops a persisted non-loopback http remote even while it is enabled', () => {
    const insecureRemote = {
      ...remoteServer,
      url: 'http://example.com/mcp',
      headers: { Authorization: 'Bearer secret' }
    }

    expect(selectEnabledCustomServers(connectorsOf([insecureRemote]))).toEqual([])
  })

  it('keeps a loopback http remote routable', () => {
    const loopbackRemote = { ...remoteServer, id: 'srv-loopback', name: 'loopback', url: 'http://127.0.0.1:9000/mcp' }
    expect(selectEnabledCustomServers(connectorsOf([loopbackRemote]))).toHaveLength(1)
  })
})

describe('custom connector discovery excludes conflicting identities', () => {
  it('drops both records when two share an id', () => {
    const a = { ...stdioServer, id: 'dup-id', name: 'dup-one' }
    const b = { ...stdioServer, id: 'dup-id', name: 'dup-two' }
    expect(selectEnabledCustomServers(connectorsOf([a, b]))).toEqual([])
  })

  it('drops a record whose id collides with a bundled connector id', () => {
    const bundledId = ALL_CONNECTOR_IDS[0]
    const collider = { ...stdioServer, id: bundledId, name: 'built-in-id-collision' }
    expect(selectEnabledCustomServers(connectorsOf([collider]))).toEqual([])
  })

  it('drops records that collide across the id/name boundary', () => {
    const a = { ...stdioServer, id: 'cross-id', name: 'cross-name' }
    const b = { ...stdioServer, id: 'cross-name', name: 'cross-other' }
    expect(selectEnabledCustomServers(connectorsOf([a, b]))).toEqual([])
  })

  it('drops a record whose id is not a valid resource id', () => {
    const invalid = { ...stdioServer, id: 'Invalid ID', name: 'invalid-id-format' }
    expect(selectEnabledCustomServers(connectorsOf([invalid]))).toEqual([])
  })
})

describe('custom connector discovery and credential-name collisions', () => {
  it('drops environment-variable names that collide only on Windows', () => {
    const ambiguousEnvironment = {
      ...stdioServer,
      id: 'ambiguous-environment',
      name: 'ambiguous-environment',
      env: { API_TOKEN: 'first', api_token: 'second' }
    }
    withPlatform('win32', () => {
      expect(selectEnabledCustomServers(connectorsOf([ambiguousEnvironment]))).toEqual([])
    })
  })

  it('keeps case-distinct environment variables runnable on Unix', () => {
    const caseDistinctEnvironment = {
      ...stdioServer,
      id: 'case-distinct-environment',
      name: 'case-distinct-environment',
      env: { API_TOKEN: 'first', api_token: 'second' }
    }
    withPlatform('darwin', () => {
      expect(selectEnabledCustomServers(connectorsOf([caseDistinctEnvironment]))).toEqual([
        caseDistinctEnvironment
      ])
    })
  })

  it('drops header names that collide case-insensitively on every platform', () => {
    const ambiguousHeaders = {
      ...remoteServer,
      id: 'ambiguous-headers',
      name: 'ambiguous-headers',
      headers: { Authorization: 'first', authorization: 'second' }
    }
    withPlatform('darwin', () => {
      expect(selectEnabledCustomServers(connectorsOf([ambiguousHeaders]))).toEqual([])
    })
  })
})
