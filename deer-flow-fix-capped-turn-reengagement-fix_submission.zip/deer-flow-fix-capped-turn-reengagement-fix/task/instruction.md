## Task

The lead agent has a bad failure mode when it writes long documents.

Ask it to produce a big piece of writing with its file-writing tool and the model
sometimes hits its hard output-token cap partway through that tool call. The
response comes back truncated and the tool call unusable. That part's expected;
what's broken is next.

Instead of stopping, the agent re-fires the model on the same oversized request,
hits the same cap, and repeats this around three times, wasting a model call each
time and piling up truncated garbage.

It used to handle this cleanly: a turn cut off at the cap mid tool-call would end,
surfacing a single "the model ran out of output room" style notice and keeping any
partial text already returned.

This lives in the middleware that post-processes each model response before the
graph decides whether to continue. The agent rightly nudges itself onward when it
stops with work unfinished, and that must stay intact. Scope the fix to turns cut
off at the cap with a suppressed tool call, not every length limit.
