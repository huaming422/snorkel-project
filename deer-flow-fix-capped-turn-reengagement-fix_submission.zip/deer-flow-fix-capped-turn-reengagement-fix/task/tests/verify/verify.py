"""Behavioral checks for the capped-turn re-engagement fix.

All assertions go through pre-existing, stable public surfaces of the harness
middleware layer:

  * ``TodoMiddleware().after_model(state, runtime)``
  * ``ModelLengthFinishReasonMiddleware()._apply(state, runtime)`` / ``.after_model``
  * ``deerflow.agents.middlewares.model_response.append_visible_text``
  * the composed ``create_agent(...).invoke(...)`` graph

None of these are introduced by the fix; the fix only corrects their behavior.
Content checks use substring membership on ``str(content)`` (never exact
equality) so a concatenation fix and a content-block-list fix both satisfy
them. The replacement marker key is the one the length middleware already
stamps in both pre- and post-fix code.
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import MagicMock

# The harness ``deerflow.agents.__init__`` chain reaches ``deerflow.subagents``
# -> ``.executor`` -> back into ``deerflow.agents.thread_state`` at import time,
# which deadlocks a cold import of the middleware modules. The repo's own test
# suite breaks this by pre-seeding a stand-in for the executor module before any
# middleware import runs; this verifier collects from outside the repo tree, so
# it reproduces that same seeding here rather than relying on the repo conftest
# being on the collection path.
_executor_stub = MagicMock()
_executor_stub.SubagentExecutor = MagicMock
_executor_stub.SubagentResult = MagicMock
_executor_stub.SubagentStatus = MagicMock
_executor_stub.MAX_CONCURRENT_SUBAGENTS = 3
_executor_stub.get_background_task_result = MagicMock()
sys.modules.setdefault("deerflow.subagents.executor", _executor_stub)

# Make ``deerflow`` importable regardless of the pytest working directory: the
# package is editable-installed under the project venv, but add the source root
# too so collection is robust if the editable install is not active.
_HARNESS_SRC = Path("/repo/deer-flow/backend/packages/harness")
if _HARNESS_SRC.is_dir() and str(_HARNESS_SRC) not in sys.path:
    sys.path.insert(0, str(_HARNESS_SRC))

from langchain.agents import create_agent  # noqa: E402
from langchain_core.language_models.fake_chat_models import (  # noqa: E402
    FakeMessagesListChatModel,
)
from langchain_core.messages import AIMessage, HumanMessage  # noqa: E402
from pydantic import PrivateAttr  # noqa: E402

from deerflow.agents.middlewares.model_length_finish_reason_middleware import (  # noqa: E402
    ModelLengthFinishReasonMiddleware,
)
from deerflow.agents.middlewares.model_response import append_visible_text  # noqa: E402
from deerflow.agents.middlewares.todo_middleware import TodoMiddleware  # noqa: E402
from deerflow.agents.thread_state import ThreadState  # noqa: E402

# Shipped notice fragment — part of the pre-existing length-cap constant, never
# renamed by the fix; matched as a substring so any surrounding wording passes.
_NOTICE_FRAGMENT = "output limit"
# The channel the two middlewares already use to communicate a force-ended turn.
_TERMINATION_MARKER = "model_length_termination"


# --- helpers mirrored from the repo's own middleware test suite --------------


def _make_runtime():
    runtime = MagicMock()
    runtime.context = {"thread_id": "test-thread", "run_id": "test-run"}
    return runtime


def _incomplete_todos():
    return [
        {"status": "completed", "content": "Step 1"},
        {"status": "in_progress", "content": "Step 2"},
        {"status": "pending", "content": "Step 3"},
    ]


def _todo_completion_reminders(messages):
    return [
        m
        for m in messages
        if isinstance(m, HumanMessage) and getattr(m, "name", None) == "todo_completion_reminder"
    ]


def _capped_write_file_message(content="nit"):
    """An assistant turn cut off at the output cap mid ``write_file`` call."""
    return AIMessage(
        content=content,
        tool_calls=[
            {
                "name": "write_file",
                "id": "call_truncated",
                "args": {
                    "path": "/mnt/user-data/outputs/report.md",
                    "content": "# Deep Research\n| ext4 | jbd2 | Every 5s |",
                },
            }
        ],
        response_metadata={"finish_reason": "length", "model_name": "deepseek-v4-pro"},
    )


class _CapturingFakeMessagesListChatModel(FakeMessagesListChatModel):
    """Records each batch of messages the graph sends to the model."""

    _seen_messages: list[list] = PrivateAttr(default_factory=list)

    @property
    def seen_messages(self) -> list[list]:
        return self._seen_messages

    def bind_tools(self, tools, *, tool_choice=None, **kwargs):
        return self

    def _generate(self, messages, stop=None, run_manager=None, **kwargs):
        self._seen_messages.append(list(messages))
        return super()._generate(messages, stop=stop, run_manager=run_manager, **kwargs)


# --- criterion: capped_turn_terminates_cleanly -------------------------------


def test_todo_stands_down_on_length_cap():
    """After the length middleware terminalizes a capped write_file turn,
    TodoMiddleware must stand down (return None) instead of re-engaging."""
    length_mw = ModelLengthFinishReasonMiddleware()
    runtime = _make_runtime()

    applied = length_mw._apply({"messages": [_capped_write_file_message()]}, runtime)
    assert applied is not None, "length middleware should rewrite a capped tool-call turn"
    replacement = applied["messages"][0]
    assert replacement.additional_kwargs.get(_TERMINATION_MARKER), (
        "length middleware must stamp the force-ended-turn marker"
    )

    state = {"messages": [replacement], "todos": _incomplete_todos()}
    assert TodoMiddleware().after_model(state, _make_runtime()) is None, (
        "todo middleware must not re-engage a force-ended length-capped turn"
    )


# --- criterion: partial_text_preserved_with_notice ---------------------------


def test_append_visible_text_preserves_string_content():
    """The shared helper must keep non-empty string content alongside the
    appended notice, not replace it with the notice alone."""
    message = AIMessage(content="nit")
    result = append_visible_text(message, "The model reached its output limit.")
    rendered = str(result)
    assert "nit" in rendered, "original string fragment must survive"
    assert _NOTICE_FRAGMENT in rendered, "appended notice must be present"


def test_notice_appended_with_string_fragment():
    """Through the length middleware: a string-content capped turn yields a
    replacement whose content carries BOTH the partial fragment and the notice."""
    length_mw = ModelLengthFinishReasonMiddleware()
    applied = length_mw._apply(
        {"messages": [_capped_write_file_message(content="nit")]}, _make_runtime()
    )
    assert applied is not None
    replacement = applied["messages"][0]
    assert replacement.tool_calls == [], "truncated tool call must be suppressed"
    rendered = str(replacement.content)
    assert "nit" in rendered, "partial text fragment must be preserved"
    assert _NOTICE_FRAGMENT in rendered, "truncation notice must be appended"


# --- criterion: guard_is_narrow ----------------------------------------------


def test_pure_text_cap_without_marker_still_reengages():
    """A pure-text length cap with NO suppression marker is healthy unfinished
    work — todos must still re-engage the model."""
    state = {
        "messages": [
            AIMessage(
                content="partial answer",
                response_metadata={"finish_reason": "length"},
            )
        ],
        "todos": _incomplete_todos(),
    }
    result = TodoMiddleware().after_model(state, _make_runtime())
    assert result is not None and result.get("jump_to") == "model", (
        "a length cap without the termination marker must still re-engage"
    )


def test_ordinary_incomplete_todos_still_reengage():
    """An ordinary clean stop with incomplete todos must still re-engage."""
    state = {
        "messages": [AIMessage(content="I'm done!")],
        "todos": _incomplete_todos(),
    }
    result = TodoMiddleware().after_model(state, _make_runtime())
    assert result is not None and result.get("jump_to") == "model", (
        "ordinary incomplete-todo turns must keep nudging the agent to continue"
    )


# --- end-to-end graph: capped_turn_terminates_cleanly + guard_is_narrow ------


def test_length_capped_write_file_single_model_call():
    """The composed graph must call the model exactly once (not loop back into
    the same cap), inject no completion reminder, and leave the final message
    carrying both the partial text and the notice."""
    todo_mw = TodoMiddleware()
    model = _CapturingFakeMessagesListChatModel(
        responses=[_capped_write_file_message(content="nit")]
    )

    graph = create_agent(
        model=model,
        tools=[],
        middleware=[todo_mw, ModelLengthFinishReasonMiddleware()],
        state_schema=ThreadState,
    )

    result = graph.invoke(
        {
            "messages": [("user", "write the report")],
            "todos": [{"content": "Phase 9: Synthesis and final report writing", "status": "in_progress"}],
        },
        context={"thread_id": "cap-thread", "run_id": "cap-run"},
    )

    assert len(model.seen_messages) == 1, (
        f"model must be called exactly once, was called {len(model.seen_messages)}x"
    )
    for batch in model.seen_messages:
        assert _todo_completion_reminders(batch) == [], "no completion reminder may be injected"

    final_ai = result["messages"][-1]
    assert final_ai.additional_kwargs.get(_TERMINATION_MARKER), (
        "final message must carry the force-ended-turn marker"
    )
    rendered = str(final_ai.content)
    assert "nit" in rendered, "final content must preserve the partial fragment"
    assert _NOTICE_FRAGMENT in rendered, "final content must carry the truncation notice"
