#!/bin/bash
# Verifier setup for deer-flow-fix-capped-turn-reengagement.
#
# The agent phase is offline and the image already carries the repo's full
# dependency closure (langchain / langgraph / pydantic) baked at the base
# commit (image/Dockerfile step 10). This script refreshes the project venv
# offline-first — the agent may have edited pyproject.toml — and exports the
# env the backend pytest suite expects. Everything needed is already in
# /opt/cache/uv, so the sync resolves without network.

set -euo pipefail

REPO_DIR="/repo/deer-flow"
cd "$REPO_DIR/backend"

# Fail fast on a cache miss instead of hanging on a dead network, but fall back
# to an online resolve (verifier phase keeps the model-gateway allowlist; a plain
# re-sync only matters locally where the network is up).
export UV_OFFLINE=1
if ! uv sync --frozen --group dev > /tmp/verifier-sync.log 2>&1; then
  echo "offline uv sync failed; retrying online" >&2
  unset UV_OFFLINE
  uv sync --frozen --group dev > /tmp/verifier-sync.log 2>&1 || { tail -50 /tmp/verifier-sync.log >&2; exit 1; }
fi

export REPO_NAME=deer-flow
export PYTHONPATH=.
export PYTHONIOENCODING=utf-8
export PYTHONUTF8=1
