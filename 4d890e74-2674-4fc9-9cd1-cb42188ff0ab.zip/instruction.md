## Task

The component model's async runtime has three failures reachable through normal
guest and embedder activity. Please investigate and correct each one.

A component stream can make the host panic on a zero-item read or write when
the guest supplies a pointer outside linear memory. The transfer should finish
without touching that pointer. The stream and future operations share transfer
machinery, but a future read or write does not expose a zero-item count to a
guest. An embedder can
also trigger a host panic by dropping an async component call's future after
the call has been scheduled, including after backpressure releases it, but
before the call runs. This needs to be safe throughout that interval.

Finally, on some result-returning paths, guest code can call out to a host
import while the host is still lowering values. Those calls must be rejected
during lowering, and ordinary import calls must work again afterward.
