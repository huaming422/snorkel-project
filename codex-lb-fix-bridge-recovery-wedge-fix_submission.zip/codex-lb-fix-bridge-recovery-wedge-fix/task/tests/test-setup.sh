#!/usr/bin/env bash
# test-setup.sh — sourced before the verifier runs (network: verifier allowlist).
#
# The full dependency closure for the codex-lb unit suite is baked into the
# project venv at /opt/venv during the image build (uv sync --frozen --all-extras
# --group dev, plus pytest/pytest-timeout). No dependency is installed here: the
# agent phase is offline and the oracle introduces no new packages, so everything
# the focused tests import is already present.
#
# The verifier exercises the HTTP-bridge recovery and anchor-poison behavior
# THROUGH pre-existing module-level interfaces imported from the project venv:
#   - app.modules.proxy.service._http_bridge_should_attempt_local_previous_response_recovery
#   - ProxyService._fail_http_bridge_reader_and_maybe_retire
#   - ProxyService._retire_stale_pending_http_bridge_session
# All of these exist at the base commit; the verifier drives them with the repo's
# own in-tree test fixtures (SimpleNamespace / AsyncMock stubs), so no database,
# no network, and no services are required.
set -euo pipefail

# Keep any uv touchpoint offline-first: the closure is already warm in the venv,
# so a cache miss should fail fast rather than reach a dead network.
export UV_OFFLINE=1

# Fail fast if the modules under test cannot be imported from the project venv.
/opt/venv/bin/python -c "
from app.modules.proxy import service as proxy_service
from app.modules.proxy._service.http_bridge import retry_circuit, upstream_events, request_submit, helpers
assert hasattr(proxy_service, '_http_bridge_should_attempt_local_previous_response_recovery')
assert hasattr(proxy_service.ProxyService, '_fail_http_bridge_reader_and_maybe_retire')
assert hasattr(proxy_service.ProxyService, '_retire_stale_pending_http_bridge_session')
print('test-setup imports OK')
"
