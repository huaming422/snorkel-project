"""Behavioral verifier for the bridge recovery/cooldown self-heal wedge.

Context
-------
Anchored responses-bridge sessions were getting stuck behind the retry
circuit's cooldown forever: an interrupted session re-injected its stored
durable anchor on every attempt, kept failing eventlessly, and never gave up
on the bad anchor. Two independent gaps combined to cause it, and the fix has
two matching halves; this module exercises each half through the module-level
interfaces that already exist at the base commit.

Interfaces under test (all pre-existing and stable — the fix changes their
bodies, never their names or caller-visible signatures):

  * ``proxy_service._http_bridge_should_attempt_local_previous_response_recovery(exc)``
    — module-level predicate; returns whether an interrupted session should
    attempt in-place anchored recovery for a given upstream rejection.
  * ``ProxyService._fail_http_bridge_reader_and_maybe_retire(session, *, error_code, ...)``
    — the reader-failure path (callers waiting on the session).
  * ``ProxyService._retire_stale_pending_http_bridge_session(session, *, detail, ...)``
    — the shared retirement boundary (session retires with nobody waiting).

Everything is asserted on OBSERVABLE side effects:

  * the predicate's boolean return, and
  * whether the session clears its stored durable continuity, observable as
    ``_durable_bridge.rebind_session_account(..., clear_continuity=True)``, plus
    the pre-existing ``durable_anchor_poison_clear_failed`` telemetry the
    waiter path already emits when a clear cannot be confirmed.

Nothing here imports any helper the fix might add, nor asserts any internal
detail string — a valid fix is free to inline, rename, or restructure the
classification and give-up logic however it likes.

The give-up threshold is read from settings at runtime; it is never hardcoded,
so retuning the setting (which the fix must not do) would not silently pass.

The tests mirror the repository's own in-tree unit-test construction patterns
for these interfaces (service built on a ``nullcontext`` stub, sessions built
with ``SimpleNamespace``/``AsyncMock`` doubles), so they need no database,
network, or running services.
"""

from __future__ import annotations

import asyncio
import logging
import os
import tempfile
from collections import deque
from contextlib import nullcontext
from types import SimpleNamespace
from typing import Any, cast
from unittest.mock import AsyncMock

# Importing the service package pulls in the database-session module, which
# reads settings at import time. This verifier runs outside the repository's
# own test tree (its ``conftest.py`` is not loaded), so point the database at a
# throwaway sqlite file and disable the background schedulers/bridge up front —
# the same import-time environment the repository's unit tests establish. The
# focused tests below stub the durable coordinator and never touch a database.
os.environ.setdefault(
    "CODEX_LB_DATABASE_URL",
    f"sqlite+aiosqlite:///{tempfile.mkdtemp(prefix='codex-lb-verify-')}/codex-lb.db",
)
for _flag in (
    "CODEX_LB_USAGE_REFRESH_ENABLED",
    "CODEX_LB_MODEL_REGISTRY_ENABLED",
    "CODEX_LB_STICKY_SESSION_CLEANUP_ENABLED",
    "CODEX_LB_HTTP_RESPONSES_SESSION_BRIDGE_ENABLED",
    "CODEX_LB_QUOTA_PLANNER_SCHEDULER_ENABLED",
    "CODEX_LB_AUTOMATIONS_SCHEDULER_ENABLED",
):
    os.environ.setdefault(_flag, "false")

import anyio  # noqa: E402
import pytest  # noqa: E402

# Pre-existing modules only. ``proxy_module`` owns the error type; the error
# codes/classes exercised below are the repository's own stable vocabulary.
import app.core.clients.proxy as proxy_module  # noqa: E402
from app.db.models import AccountStatus  # noqa: E402
from app.modules.proxy import service as proxy_service  # noqa: E402


# --------------------------------------------------------------------------- #
# Runtime facts read from the codebase (never a solution choice)
# --------------------------------------------------------------------------- #
def _poison_threshold() -> int:
    """Consecutive-failure give-up threshold, read from settings at runtime.

    This is an existing configuration default; the fix must leave it as-is, so
    the verifier derives its loop counts from it rather than hardcoding a value.
    """
    return proxy_service.get_settings().http_responses_session_bridge_anchor_poison_failure_threshold


# --------------------------------------------------------------------------- #
# Test fixtures — mirror the repo's in-tree bridge-session construction
# --------------------------------------------------------------------------- #
def _make_bridge_session(
    *,
    key_value: str,
    with_pending: bool = True,
) -> "proxy_service._HTTPBridgeSession":
    """Build a hard-affinity bridge session with one eventless pending owner.

    The default affinity kind (``session_header``) is a hard key, which is the
    precondition for the retry circuit to accumulate strikes — the same
    construction the repository's own bridge unit tests use.
    """
    session_key = proxy_service._HTTPBridgeSessionKey("session_header", key_value, None)
    pending: "deque[proxy_service._WebSocketRequestState]" = deque()
    if with_pending:
        pending.append(_make_eventless_owner())
    return proxy_service._HTTPBridgeSession(
        key=session_key,
        headers={"x-codex-session-id": key_value},
        affinity=proxy_service._AffinityPolicy(
            key=key_value,
            kind=proxy_service.StickySessionKind.CODEX_SESSION,
        ),
        request_model="gpt-5.2",
        account=cast(
            Any,
            SimpleNamespace(
                id="acc-bridge",
                chatgpt_account_id="workspace-bridge",
                status=AccountStatus.ACTIVE,
                plan_type="plus",
            ),
        ),
        upstream=cast(Any, SimpleNamespace(close=AsyncMock())),
        upstream_control=proxy_service._WebSocketUpstreamControl(),
        pending_requests=pending,
        pending_lock=anyio.Lock(),
        response_create_gate=asyncio.Semaphore(1),
        queued_request_count=1 if with_pending else 0,
        last_used_at=1.0,
        idle_ttl_seconds=120.0,
    )


def _make_eventless_owner() -> "proxy_service._WebSocketRequestState":
    """A pending request that has seen zero response events (the wedge shape)."""
    return proxy_service._WebSocketRequestState(
        request_id="req-eventless-owner",
        model="gpt-5.6-sol",
        service_tier=None,
        reasoning_effort="high",
        api_key_reservation=None,
        started_at=-10_000.0,
        transport="http",
        response_create_gate=asyncio.Semaphore(0),
        response_create_gate_acquired=True,
        awaiting_response_created=True,
        response_create_sent_at=100.0,
        event_queue=asyncio.Queue(),
    )


def _durable_bridge_double(*, clear_succeeds: bool) -> SimpleNamespace:
    """Stand-in for the durable-continuity coordinator.

    ``rebind_session_account`` is the fenced write that clears the stored
    anchor; its return models whether the fenced clear was confirmed.
    """
    return SimpleNamespace(
        lookup_retry_circuit=AsyncMock(return_value=None),
        persist_retry_circuit=AsyncMock(),
        rebind_session_account=AsyncMock(return_value=clear_succeeds),
    )


def _new_service() -> "proxy_service.ProxyService":
    return proxy_service.ProxyService(cast(Any, nullcontext()))


# --------------------------------------------------------------------------- #
# 1. Recovery-gate classification (must break on the unfixed code)
# --------------------------------------------------------------------------- #
def test_gate_normalizes_type_only_and_terse_frames() -> None:
    """The recovery gate must route genuine previous-response rejections into
    anchored recovery even when the frame carries its classifiable identity
    somewhere other than the obvious ``code`` slot.

    Two production frames that an interrupted session actually receives:

      * a terse, parameterless invalid-previous-response rejection whose only
        signal is its wording, and
      * a rejection whose classifiable identity rides in ``type`` with no
        ``code``.

    Both must be recognized as recoverable (return ``True``). An unrelated
    rejection with no previous-response signal must still return ``False``, so
    the gate has not simply been widened to accept everything.

    Pre-fix: the gate reads a raw code with no fallback, so both recoverable
    frames return ``False`` and the session feeds the retry circuit instead of
    recovering.
    """
    gate = proxy_service._http_bridge_should_attempt_local_previous_response_recovery

    terse_parameterless = proxy_module.ProxyResponseError(
        400,
        {
            "error": {
                "type": "invalid_request_error",
                "message": "Invalid `previous_response_id`.",
            }
        },
    )
    type_only_not_found = proxy_module.ProxyResponseError(
        404,
        {
            "error": {
                "type": "previous_response_not_found",
                "message": "Previous response with id 'resp_prev_anchor' not found.",
            }
        },
    )
    unrelated = proxy_module.ProxyResponseError(
        400,
        {
            "error": {
                "type": "invalid_request_error",
                "code": "invalid_request_error",
                "message": "Invalid request payload",
                "param": "previous_response_id",
            }
        },
    )

    assert gate(terse_parameterless) is True, (
        "A terse parameterless invalid-previous-response rejection must route "
        "into anchored recovery; it was classified as generic transport instead."
    )
    assert gate(type_only_not_found) is True, (
        "A previous-response-not-found rejection whose identity rides in the "
        "frame's type must route into anchored recovery."
    )
    assert gate(unrelated) is False, (
        "An unrelated rejection with no previous-response signal must not be "
        "treated as recoverable."
    )


# --------------------------------------------------------------------------- #
# 2. Reader path (waiter present) self-heals on the eventless class (must break on the unfixed code)
# --------------------------------------------------------------------------- #
@pytest.mark.asyncio
async def test_reader_path_poisons_on_stream_incomplete(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """On the reader/admission-waiter path, repeated same-anchor eventless
    failures of the production wedge class must eventually give up on the bad
    anchor and clear stored durable continuity.

    The repository already poisons the anchor for one eventless class on this
    path; the wedge class seen in production (an eventless incomplete stream)
    must be treated the same way. Drive ``threshold`` consecutive reader
    failures with a waiter present and assert the durable clear
    (``rebind_session_account(..., clear_continuity=True)``) is awaited exactly
    once and retirement happens on the threshold-th failure.

    Pre-fix: this class never poisons on the reader path, so the clear never
    fires and the session retires every time without self-healing.
    """
    threshold = _poison_threshold()
    service = _new_service()
    session = _make_bridge_session(key_value="bridge-reader-stream-incomplete")
    session.admission_waiter_count = 1
    session.durable_session_id = "durable-reader-stream-incomplete"
    session.durable_owner_epoch = 3
    durable_bridge = _durable_bridge_double(clear_succeeds=True)
    service._durable_bridge = durable_bridge


    monkeypatch.setattr(service, "_fail_pending_websocket_requests", AsyncMock())
    monkeypatch.setattr(service, "_retire_stale_pending_http_bridge_session", AsyncMock())

    for failure_number in range(1, threshold + 1):
        retired = await service._fail_http_bridge_reader_and_maybe_retire(
            session,
            error_code="stream_incomplete",
            error_message="Upstream websocket closed before response.completed",
        )
        assert retired is (failure_number == threshold), (
            f"Reader failure #{failure_number} reported retired={retired}; "
            f"retirement must happen only on failure #{threshold}."
        )

    assert durable_bridge.rebind_session_account.await_count == 1, (
        "Repeated same-anchor eventless reader failures must clear the poisoned "
        "durable anchor exactly once at the give-up threshold; it was cleared "
        f"{durable_bridge.rebind_session_account.await_count} time(s)."
    )
    clear_call = durable_bridge.rebind_session_account.await_args
    assert clear_call.kwargs.get("clear_continuity") is True, (
        "The anchor give-up must clear durable continuity "
        "(clear_continuity=True)."
    )
    assert clear_call.kwargs.get("session_id") == "durable-reader-stream-incomplete"
    assert clear_call.kwargs.get("owner_epoch") == 3


# --------------------------------------------------------------------------- #
# 3. Waiterless retirement self-heals at threshold (must break on the unfixed code)
# --------------------------------------------------------------------------- #
@pytest.mark.asyncio
async def test_waiterless_retirement_poisons_at_threshold(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The production wedge retires with NOBODY waiting on the session, so the
    give-up must also fire at the shared retirement boundary — not only on the
    reader/admission-waiter path.

    Retire the same anchored durable key eventlessly ``threshold`` times (a
    fresh session object each time, as production does — only the durable
    identity is shared) and assert the poisoned durable anchor is cleared
    exactly once with ``clear_continuity=True``.

    Pre-fix: the retirement boundary recorded circuit strikes but discarded the
    consecutive-failure count, so the give-up never fired here and a waiterless
    session cooled down forever.
    """
    threshold = _poison_threshold()
    service = _new_service()
    durable_bridge = _durable_bridge_double(clear_succeeds=True)
    service._durable_bridge = durable_bridge


    monkeypatch.setattr(service, "_close_http_bridge_session_bounded", AsyncMock())

    for _failure_number in range(threshold):
        session = _make_bridge_session(key_value="bridge-waiterless-retire")
        session.durable_session_id = "durable-waiterless-retire"
        session.durable_owner_epoch = 5
        await service._retire_stale_pending_http_bridge_session(
            session,
            detail="stream_incomplete",
        )

    assert durable_bridge.rebind_session_account.await_count == 1, (
        "A wedged anchored session failing without waiters must clear its "
        "poisoned durable anchor at the give-up threshold via the shared "
        "retirement boundary; it was cleared "
        f"{durable_bridge.rebind_session_account.await_count} time(s)."
    )
    clear_call = durable_bridge.rebind_session_account.await_args
    assert clear_call.kwargs.get("clear_continuity") is True
    assert clear_call.kwargs.get("session_id") == "durable-waiterless-retire"
    assert clear_call.kwargs.get("owner_epoch") == 5


# --------------------------------------------------------------------------- #
# 4. Unconfirmed clear is re-attempted and stays visible (must break on the unfixed code)
# --------------------------------------------------------------------------- #
@pytest.mark.asyncio
async def test_failed_waiterless_clear_is_reattempted(
    caplog: pytest.LogCaptureFixture,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A durable clear that cannot be confirmed (the fenced write does not take
    effect) must not silently drop the self-heal: the next eligible eventless
    failure at/above threshold must re-attempt the clear, and each failed clear
    must stay visible in the pre-existing poison-clear telemetry.

    Drive ``threshold + 1`` waiterless eventless retirements with the fenced
    clear always returning "not confirmed". The give-up logic should fire at
    the threshold-th failure and again at the next one, so the clear is
    attempted twice and the ``durable_anchor_poison_clear_failed`` event (the
    same telemetry the waiter path already emits) appears twice.

    Pre-fix: the waiterless path never clears at all, so there are zero attempts
    and zero telemetry lines.
    """
    threshold = _poison_threshold()
    service = _new_service()
    durable_bridge = _durable_bridge_double(clear_succeeds=False)
    service._durable_bridge = durable_bridge


    monkeypatch.setattr(service, "_close_http_bridge_session_bounded", AsyncMock())

    with caplog.at_level(logging.INFO):
        for _failure_number in range(threshold + 1):
            session = _make_bridge_session(key_value="bridge-waiterless-clear-retry")
            session.durable_session_id = "durable-waiterless-clear-retry"
            session.durable_owner_epoch = 5
            await service._retire_stale_pending_http_bridge_session(
                session,
                detail="stream_incomplete",
            )

    assert durable_bridge.rebind_session_account.await_count == 2, (
        "An unconfirmed durable clear must be re-attempted on the next eligible "
        "eventless failure at/above threshold; the clear was attempted "
        f"{durable_bridge.rebind_session_account.await_count} time(s) instead "
        "of 2."
    )
    failed_clear_lines = caplog.text.count("event=durable_anchor_poison_clear_failed")
    assert failed_clear_lines == 2, (
        "Each unconfirmed clear must remain visible in the poison-clear "
        f"telemetry; saw {failed_clear_lines} failed-clear log line(s) "
        "instead of 2."
    )


# --------------------------------------------------------------------------- #
# 5. clean_close never poisons (must keep passing before and after the fix)
# --------------------------------------------------------------------------- #
@pytest.mark.asyncio
async def test_clean_close_never_poisons(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A cleanly closed connection is not a wedge: no matter how many times a
    session retires with a clean-close retry classification, the give-up logic
    must never clear the durable anchor.

    Retire the same anchored durable key ``threshold`` times with a clean-close
    retry classification and assert the durable clear is never awaited. This
    passes both pre- and post-fix, and rejects any fix that would force
    self-heal by letting clean closes poison the anchor.
    """
    threshold = _poison_threshold()
    service = _new_service()
    durable_bridge = _durable_bridge_double(clear_succeeds=True)
    service._durable_bridge = durable_bridge


    monkeypatch.setattr(service, "_close_http_bridge_session_bounded", AsyncMock())

    for _failure_number in range(threshold):
        session = _make_bridge_session(key_value="bridge-clean-close")
        session.durable_session_id = "durable-clean-close"
        session.durable_owner_epoch = 6
        await service._retire_stale_pending_http_bridge_session(
            session,
            detail="stream_incomplete",
            retry_circuit_detail="clean_close",
        )

    durable_bridge.rebind_session_account.assert_not_awaited()
