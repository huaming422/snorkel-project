## Task

some of our codex sessions are getting permanently stuck behind the "cooling down" 503. once one of them hits a mid-turn interruption it never comes back on its own; every retry just keeps it cooling down. these used to recover by themselves and now they don't. the only way we've found to free a wedged session is to manually wipe the bridge's state tables in the db. we've also seen a different kind of hang that looks unrelated, but this is specifically about the sessions stuck cooling down that never self-heal. can you dig in and fix it?
