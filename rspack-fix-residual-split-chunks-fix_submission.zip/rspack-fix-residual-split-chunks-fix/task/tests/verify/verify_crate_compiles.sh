#!/usr/bin/env bash
#
# Structural verifier: the code-splitting optimization crate and its consumers
# must still compile after the change. The fix spans several files in the crate
# with a shared invariant on how module-to-chunk membership is tracked; a partial
# change that leaves that tracking inconsistent fails to compile. Names no symbol,
# so it accepts any internal decomposition.
#
# `cargo check` on the one crate reuses the warm target cache; no network needed.

set -euo pipefail

cd /repo/rspack

cargo check -p rspack_plugin_split_chunks
