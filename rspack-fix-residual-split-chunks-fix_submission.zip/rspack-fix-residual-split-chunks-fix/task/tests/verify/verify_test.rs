//! Behavioural verifier for `rspack-fix-residual-split-chunks`.
//!
//! Drives the pure-Rust compilation pipeline through the PRE-EXISTING public
//! builder (`Compiler::builder()`, the same harness `crates/rspack/tests/basic.rs`
//! uses) and registers the code-splitting optimization plugin by hand through its
//! PUBLIC crate API. The behaviour under test — which output chunks still carry a
//! copy of a shared module after optimization — is observed through the public
//! chunk-graph accessors. Nothing here imports the internal data structures the
//! fix introduces (they are `pub(crate)` / private), so the check rests purely on
//! the OBSERVED CHUNK COMPOSITION, never on the solution's internal model.
//!
//! Scenario (mirrors the upstream reproduction): `Foo`, `Bar`, `Other`, and a
//! second copy of `Other` all import the same `util` module via dynamic imports,
//! so each lands in its own async chunk. A fifth chunk, `Extra`, together with the
//! two `Other` chunks shares a SEPARATE `helper` module, so `helper` spans a wider
//! chunk-set (`Other`/`Other2`/`Extra`) than `util` (`Other`/`Other2`) — the two
//! shared modules therefore form distinct candidate groups rather than collapsing
//! into one, which is the condition under which the lower-priority residual
//! hand-off is actually exercised. A high-priority cache group is restricted to the
//! `Foo`/`Bar` chunks and lifts `util` out of those two; a lower-priority group
//! covers everything. The question is whether the copies of `util` left in the
//! `Other`/`Other2` chunks get pulled into a shared chunk by the lower-priority
//! group, or stay duplicated inline.
//!
//! Decoupling rationale for each assertion's shape:
//!   * Only PRE-EXISTING public symbols are imported — `rspack::builder`,
//!     `rspack_core`, and the published `rspack_plugin_split_chunks` crate root.
//!     The fix's new internal types are never named.
//!   * The check keys on the COUNT of chunks carrying `util` plus whether any
//!     leaf (entry-named) chunk still carries it — concrete observable values, not
//!     a bare boolean and not the identity of any solution-chosen chunk. The
//!     high-priority destination is pinned to the name the TEST configures
//!     (`shared_util`), which is a harness input, not a solution choice.
//!   * `residual_lower_priority` asserts the leftover copies are consolidated:
//!     exactly two chunks carry `util` (the configured high-priority one plus one
//!     residual shared chunk) and no leaf chunk retains an inline copy. Pre-fix the
//!     residual copies are never extracted, so the `Other`/`Other2` leaf chunks
//!     keep their inline `util` and the assertion fails by VALUE.
//!   * `no_residual_when_fully_consumed` is the guard in the opposite direction:
//!     when the high-priority group covers every chunk that imports `util`, exactly
//!     one chunk carries it and no spurious residual chunk appears. This holds both
//!     before and after the fix, rejecting an over-eager "always split" change.
//!   * `reuse_existing_chunk_preserved` guards a pre-existing behavior the fix must
//!     keep intact: when a high-priority group can reuse an already-existing chunk
//!     that consists of exactly the shared module as its destination, `util` is
//!     consolidated there and a lower-priority group must not re-claim it into a
//!     separate chunk. It holds on the pre-fix base; a change that ties the reused
//!     destination to actual module movement forms a spurious `lower_util` chunk and
//!     fails by VALUE. (Only the published `reuse_existing_chunk` `CacheGroup` field
//!     is used — the reuse decision is a harness input, not a solution choice.)


use rspack::builder::Builder as _;
use rspack_core::{Compiler, Mode, PluginExt};
use rspack_paths::Utf8PathBuf;
use rspack_plugin_split_chunks::{
  CacheGroup, CacheGroupTest, ChunkFilter, ChunkNameGetter, FallbackCacheGroup, PluginOptions,
  SplitChunksPlugin, SplitChunkSizes, create_all_chunk_filter, create_default_module_layer_filter,
  create_default_module_type_filter,
};

/// On-disk fixture: several leaf modules import one shared `util` module, and the
/// entry dynamically imports each leaf under a stable `webpackChunkName` so the
/// async chunks are named `Foo` / `Bar` / `Other` / `Other2` / `Extra` (the names
/// a chunk-name-regex filter keys on). `Other` is imported twice (`./Other` and
/// `./Other?1`) to produce two distinct chunks that share `util`. A separate
/// `helper` module is shared across a DIFFERENT, wider set of chunks
/// (`Other` / `Other2` / `Extra`) than `util` (`Other` / `Other2`), so the two
/// shared modules form distinct candidate groups — the configuration under which
/// the lower-priority residual hand-off is exercised.
fn write_fixture() -> Utf8PathBuf {
  let unique = format!(
    "rspack-residual-split-{}-{}",
    std::process::id(),
    std::time::SystemTime::now()
      .duration_since(std::time::UNIX_EPOCH)
      .map(|d| d.as_nanos())
      .unwrap_or(0)
  );
  let dir = std::env::temp_dir().join(unique);
  std::fs::create_dir_all(&dir).expect("create fixture dir");

  let write = |name: &str, body: &str| {
    std::fs::write(dir.join(name), body).unwrap_or_else(|e| panic!("write {name}: {e}"));
  };

  write("util.js", "export default \"util\";\n");
  write("helper.js", "export default \"helper\";\n");
  write(
    "Foo.js",
    "import util from \"./util\";\nexport default `Foo:${util}`;\n",
  );
  write(
    "Bar.js",
    "import util from \"./util\";\nexport default `Bar:${util}`;\n",
  );
  write(
    "Other.js",
    "import util from \"./util\";\nimport helper from \"./helper\";\nexport default `Other:${util}:${helper}`;\n",
  );
  write(
    "Extra.js",
    "import helper from \"./helper\";\nexport default `Extra:${helper}`;\n",
  );
  write(
    "index.js",
    r#"Promise.all([
  import(/* webpackChunkName: "Foo" */ "./Foo"),
  import(/* webpackChunkName: "Bar" */ "./Bar"),
  import(/* webpackChunkName: "Other" */ "./Other"),
  import(/* webpackChunkName: "Other2" */ "./Other?1"),
  import(/* webpackChunkName: "Extra" */ "./Extra"),
]).then((mods) => mods.map((m) => m.default));
"#,
  );

  Utf8PathBuf::from_path_buf(dir).expect("fixture path is utf8")
}

/// Build a `CacheGroup` filling every field from the construction reference
/// (`raw_split_chunks` normalization defaults), varying only what each scenario
/// needs. `min_size` is zero so the tiny fixture modules are never size-filtered.
fn cache_group(
  key: &str,
  name: ChunkNameGetter,
  priority: f64,
  min_chunks: u32,
  test: CacheGroupTest,
  chunk_filter: ChunkFilter,
) -> CacheGroup {
  CacheGroup {
    key: key.to_string(),
    chunk_filter,
    test,
    r#type: create_default_module_type_filter(),
    layer: create_default_module_layer_filter(),
    name,
    priority,
    min_size: SplitChunkSizes::default(),
    min_size_reduction: SplitChunkSizes::default(),
    enforce_size_threshold: SplitChunkSizes::default(),
    reuse_existing_chunk: false,
    min_chunks,
    id_hint: key.to_string(),
    max_initial_requests: f64::INFINITY,
    max_async_requests: f64::INFINITY,
    max_async_size: SplitChunkSizes::default(),
    max_initial_size: SplitChunkSizes::default(),
    filename: None,
    automatic_name_delimiter: "~".to_string(),
    used_exports: false,
  }
}

fn fallback_cache_group() -> FallbackCacheGroup {
  FallbackCacheGroup {
    chunks_filter: create_all_chunk_filter(),
    min_size: SplitChunkSizes::default(),
    max_async_size: SplitChunkSizes::default(),
    max_initial_size: SplitChunkSizes::default(),
    automatic_name_delimiter: "~".to_string(),
  }
}

fn util_regex() -> CacheGroupTest {
  CacheGroupTest::RegExp(
    rspack_regex::RspackRegex::new("util\\.js$").expect("valid util test regex"),
  )
}

/// Restrict a cache group to only the chunks whose names match `pattern`
/// (e.g. `^(Foo|Bar)$`). `ChunkFilter::Regex` tests the chunk's name.
fn name_filter(pattern: &str) -> ChunkFilter {
  ChunkFilter::Regex(rspack_regex::RspackRegex::new(pattern).expect("valid chunk-name regex"))
}

/// The four dynamically-imported leaf chunk names in this fixture.
const LEAF_CHUNK_NAMES: [&str; 4] = ["Foo", "Bar", "Other", "Other2"];

/// Compile the fixture with the given cache groups and report, for the
/// `util` module: how many chunks carry it, and the names of any LEAF chunks
/// (Foo/Bar/Other/Other2) that still carry it inline. A leaf chunk carrying
/// `util` means that copy was never deduplicated into a shared chunk.
struct UtilPlacement {
  util_chunk_count: usize,
  leaf_chunks_with_util: Vec<String>,
  shared_util_present: bool,
}

async fn compile_and_inspect(high_priority_chunk_pattern: &str) -> UtilPlacement {
  let fixture = write_fixture();

  let high = cache_group(
    "shared_util",
    ChunkNameGetter::String("shared_util".to_string()),
    100.0,
    2,
    util_regex(),
    name_filter(high_priority_chunk_pattern),
  );
  let default_group = cache_group(
    "default",
    ChunkNameGetter::Disabled,
    0.0,
    2,
    CacheGroupTest::Enabled,
    create_all_chunk_filter(),
  );

  let options = PluginOptions {
    cache_groups: vec![high, default_group],
    fallback_cache_group: fallback_cache_group(),
    hide_path_info: None,
  };

  let mut compiler = Compiler::builder()
    .context(fixture.clone())
    .entry("main", "./index.js")
    .mode(Mode::Development)
    .target(vec!["web".to_string(), "es2015".to_string()])
    .plugin(SplitChunksPlugin::new(options).boxed())
    .build()
    .expect("compiler builds");

  compiler.build().await.expect("compilation succeeds");

  let errors: Vec<_> = compiler.compilation.get_errors().collect();
  assert!(errors.is_empty(), "compilation emitted errors: {errors:?}");

  let artifact = &compiler.compilation.build_chunk_graph_artifact;
  let chunk_graph = &artifact.chunk_graph;

  let mut util_chunk_count = 0usize;
  let mut leaf_chunks_with_util: Vec<String> = Vec::new();

  for (ukey, chunk) in artifact.chunk_by_ukey.iter() {
    let carries_util = chunk_graph
      .get_chunk_modules_identifier(ukey)
      .iter()
      .any(|id| id.as_str().replace('\\', "/").ends_with("/util.js"));
    if !carries_util {
      continue;
    }
    util_chunk_count += 1;
    if let Some(name) = chunk.name() {
      if LEAF_CHUNK_NAMES.contains(&name) {
        leaf_chunks_with_util.push(name.to_string());
      }
    }
  }
  leaf_chunks_with_util.sort();

  let shared_util_present = artifact.named_chunks.contains_key("shared_util");

  // Best-effort cleanup; a leftover temp dir is harmless.
  let _ = std::fs::remove_dir_all(fixture.as_std_path());

  UtilPlacement {
    util_chunk_count,
    leaf_chunks_with_util,
    shared_util_present,
  }
}

/// fail_to_pass — A high-priority cache group that lifts `util` out of only the
/// `Foo`/`Bar` chunks must leave the residual copies (in `Other`/`Other2`)
/// available for the lower-priority group to consolidate into a shared chunk.
///
/// Post-fix: `util` ends up in exactly two chunks — the configured `shared_util`
/// chunk plus one residual shared chunk — and no leaf chunk keeps an inline copy.
/// Pre-fix: the residual copies are never extracted, so `Other` and `Other2`
/// retain their inline `util` (three chunks carry it, two of them leaves) and
/// this fails by value.
#[tokio::test(flavor = "multi_thread")]
async fn residual_lower_priority() {
  use rspack_tasks::within_compiler_context_for_testing;
  within_compiler_context_for_testing(async move {
    let placement = compile_and_inspect("^(Foo|Bar)$").await;

    assert!(
      placement.shared_util_present,
      "the high-priority `shared_util` chunk should always form (util is shared by Foo and Bar)"
    );
    assert!(
      placement.leaf_chunks_with_util.is_empty(),
      "after the fix no leaf chunk should keep an inline copy of util, but these still do: {:?} \
       (pre-fix the Other/Other2 residual copies are never deduplicated)",
      placement.leaf_chunks_with_util
    );
    assert_eq!(
      placement.util_chunk_count, 2,
      "util should land in exactly two chunks — the high-priority `shared_util` chunk plus one \
       residual shared chunk for the Other/Other2 copies — but found {} chunk(s) carrying util",
      placement.util_chunk_count
    );
  })
  .await;
}

/// pass_to_pass — When the high-priority group covers EVERY chunk that imports
/// `util`, there is nothing left for a lower-priority group to consolidate, so no
/// spurious residual chunk should appear: `util` lands in exactly one chunk and no
/// leaf chunk retains it. This holds both before and after the fix and rejects an
/// over-eager change that always forms a residual chunk.
#[tokio::test(flavor = "multi_thread")]
async fn no_residual_when_fully_consumed() {
  use rspack_tasks::within_compiler_context_for_testing;
  within_compiler_context_for_testing(async move {
    let placement = compile_and_inspect("^(Foo|Bar|Other|Other2)$").await;

    assert!(
      placement.shared_util_present,
      "the high-priority `shared_util` chunk should form when util is shared across all leaves"
    );
    assert!(
      placement.leaf_chunks_with_util.is_empty(),
      "no leaf chunk should retain an inline copy of util when the high-priority group covers \
       every importer, but these do: {:?}",
      placement.leaf_chunks_with_util
    );
    assert_eq!(
      placement.util_chunk_count, 1,
      "when the high-priority group consumes all of util's chunk edges, util should land in \
       exactly one shared chunk (no residual split), but found {} chunk(s) carrying util",
      placement.util_chunk_count
    );
  })
  .await;
}

/// On-disk fixture for the reuse-existing-chunk case: `Foo` and `Bar` both import
/// a shared `util` module, and the entry ALSO dynamically imports `util` directly
/// under the stable name `ReusableUtil`, so a chunk that already consists of
/// exactly `util` pre-exists. A high-priority cache group whose destination can
/// reuse that existing `ReusableUtil` chunk should consolidate `util` there, and
/// a lower-priority group named `lower_util` must not then pull `util` back out
/// into a separate chunk.
fn write_reuse_fixture() -> Utf8PathBuf {
  let unique = format!(
    "rspack-reuse-existing-{}-{}",
    std::process::id(),
    std::time::SystemTime::now()
      .duration_since(std::time::UNIX_EPOCH)
      .map(|d| d.as_nanos())
      .unwrap_or(0)
  );
  let dir = std::env::temp_dir().join(unique);
  std::fs::create_dir_all(&dir).expect("create reuse fixture dir");

  let write = |name: &str, body: &str| {
    std::fs::write(dir.join(name), body).unwrap_or_else(|e| panic!("write {name}: {e}"));
  };

  write("util.js", "export default \"util\";\n");
  write(
    "Foo.js",
    "import util from \"./util\";\nexport default `Foo:${util}`;\n",
  );
  write(
    "Bar.js",
    "import util from \"./util\";\nexport default `Bar:${util}`;\n",
  );
  write(
    "index.js",
    r#"Promise.all([
  import(/* webpackChunkName: "Foo" */ "./Foo"),
  import(/* webpackChunkName: "Bar" */ "./Bar"),
  import(/* webpackChunkName: "ReusableUtil" */ "./util"),
]).then((mods) => mods.map((m) => m.default));
"#,
  );

  Utf8PathBuf::from_path_buf(dir).expect("reuse fixture path is utf8")
}

/// Like `cache_group`, but lets the scenario set `reuse_existing_chunk`. Kept
/// separate so the two primary tests above keep their `reuse_existing_chunk: false`
/// construction unchanged.
fn reuse_cache_group(
  key: &str,
  name: ChunkNameGetter,
  priority: f64,
  min_chunks: u32,
  test: CacheGroupTest,
  chunk_filter: ChunkFilter,
  reuse_existing_chunk: bool,
) -> CacheGroup {
  CacheGroup {
    key: key.to_string(),
    chunk_filter,
    test,
    r#type: create_default_module_type_filter(),
    layer: create_default_module_layer_filter(),
    name,
    priority,
    min_size: SplitChunkSizes::default(),
    min_size_reduction: SplitChunkSizes::default(),
    enforce_size_threshold: SplitChunkSizes::default(),
    reuse_existing_chunk,
    min_chunks,
    id_hint: key.to_string(),
    max_initial_requests: f64::INFINITY,
    max_async_requests: f64::INFINITY,
    max_async_size: SplitChunkSizes::default(),
    max_initial_size: SplitChunkSizes::default(),
    filename: None,
    automatic_name_delimiter: "~".to_string(),
    used_exports: false,
  }
}

/// pass_to_pass — A pre-existing split-chunks behavior that must be preserved: when
/// a high-priority cache group can REUSE an already-existing chunk that already
/// consists of exactly the shared module (`ReusableUtil`), the module is
/// consolidated into that reused chunk and a lower-priority group must NOT then
/// move it back out into its own chunk. This holds on the pre-fix base (the reused
/// destination owns `util`, no `lower_util` forms) and the fix must keep it holding
/// — the reused destination is recorded independently of whether any module was
/// physically moved into it. A change that ties the reused-destination record to
/// source movement lets the lower-priority group re-claim `util`, forming a
/// spurious `lower_util` chunk; this test fails by value in that case.
#[tokio::test(flavor = "multi_thread")]
async fn reuse_existing_chunk_preserved() {
  use rspack_tasks::within_compiler_context_for_testing;
  within_compiler_context_for_testing(async move {
    let fixture = write_reuse_fixture();

    // High-priority group for `util`, scoped to the Foo/Bar/ReusableUtil chunks,
    // allowed to reuse the pre-existing `ReusableUtil` chunk as its destination.
    let high = reuse_cache_group(
      "high_reuse",
      ChunkNameGetter::Disabled,
      100.0,
      2,
      util_regex(),
      name_filter("^(Foo|Bar|ReusableUtil)$"),
      true,
    );
    // Lower-priority group that would, if `util` were still available, pull it into
    // a separately-named `lower_util` chunk.
    let lower = reuse_cache_group(
      "lower_util",
      ChunkNameGetter::String("lower_util".to_string()),
      0.0,
      1,
      util_regex(),
      create_all_chunk_filter(),
      false,
    );

    let options = PluginOptions {
      cache_groups: vec![high, lower],
      fallback_cache_group: fallback_cache_group(),
      hide_path_info: None,
    };

    let mut compiler = Compiler::builder()
      .context(fixture.clone())
      .entry("main", "./index.js")
      .mode(Mode::Development)
      .target(vec!["web".to_string(), "es2015".to_string()])
      .plugin(SplitChunksPlugin::new(options).boxed())
      .build()
      .expect("compiler builds");

    compiler.build().await.expect("compilation succeeds");

    let errors: Vec<_> = compiler.compilation.get_errors().collect();
    assert!(errors.is_empty(), "compilation emitted errors: {errors:?}");

    let artifact = &compiler.compilation.build_chunk_graph_artifact;
    let chunk_graph = &artifact.chunk_graph;

    let mut util_chunk_count = 0usize;
    for (ukey, _chunk) in artifact.chunk_by_ukey.iter() {
      let carries_util = chunk_graph
        .get_chunk_modules_identifier(ukey)
        .iter()
        .any(|id| id.as_str().replace('\\', "/").ends_with("/util.js"));
      if carries_util {
        util_chunk_count += 1;
      }
    }

    let reusable_present = artifact.named_chunks.contains_key("ReusableUtil");
    let lower_util_present = artifact.named_chunks.contains_key("lower_util");

    let reusable_carries_util = artifact
      .named_chunks
      .get("ReusableUtil")
      .map(|ukey| {
        chunk_graph
          .get_chunk_modules_identifier(ukey)
          .iter()
          .any(|id| id.as_str().replace('\\', "/").ends_with("/util.js"))
      })
      .unwrap_or(false);

    let _ = std::fs::remove_dir_all(fixture.as_std_path());

    assert!(
      reusable_present,
      "the pre-existing `ReusableUtil` chunk (entry imports util directly) should always exist"
    );
    assert!(
      !lower_util_present,
      "no `lower_util` chunk should form: once the high-priority group reuses `ReusableUtil` as \
       util's home, the lower-priority group has nothing left to consolidate. A spurious \
       `lower_util` means the reused destination was tied to source movement and util was \
       re-claimed."
    );
    assert!(
      reusable_carries_util,
      "`util` should be consolidated into the reused `ReusableUtil` chunk, but that chunk no \
       longer carries it"
    );
    assert_eq!(
      util_chunk_count, 1,
      "util should land in exactly one chunk (the reused `ReusableUtil`), but found {} chunk(s) \
       carrying util",
      util_chunk_count
    );
  })
  .await;
}
