#!/usr/bin/env bash
# Test-setup for rspack-fix-residual-split-chunks. The image bakes the full
# dependency closure at the base commit: `cargo fetch --locked` populated
# CARGO_HOME (/opt/cache/cargo) and `cargo test --no-run` warmed the shared
# target dir (/opt/cache/cargo-target) for the Rust unit suite. No services to
# start, no data to seed.
#
# The behavioral verifier is an integration test hosted in the `crates/rspack`
# crate and needs the code-splitting optimization crate reachable from that
# crate's test target. That crate is already a workspace member, is present in
# Cargo.lock and the warm cargo cache, and is already declared under the
# workspace root's [workspace.dependencies], so adding it as a dev-dependency
# pulls nothing from the network. We append it here (idempotently) so the wiring
# is in place before any verifier runs.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/rspack}"
MANIFEST="${REPO_DIR}/crates/rspack/Cargo.toml"

echo "[test-setup] Rust version:    $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:   $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root:  ${REPO_DIR}"
echo "[test-setup] Cargo home:      ${CARGO_HOME:-<unset>}"
echo "[test-setup] Target dir:      ${CARGO_TARGET_DIR:-<unset>}"

if [ ! -f "${MANIFEST}" ]; then
  echo "[test-setup] ERROR: ${MANIFEST} not found" >&2
  exit 1
fi

# Add the optimization crate as a dev-dependency of crates/rspack if it is not
# already declared there. `{ workspace = true }` resolves against the root's
# [workspace.dependencies] entry, so the lockfile is untouched.
if ! grep -qE '^[[:space:]]*rspack_plugin_split_chunks[[:space:]]*=' "${MANIFEST}"; then
  if grep -qE '^\[dev-dependencies\]' "${MANIFEST}"; then
    awk '
      /^\[dev-dependencies\]/ && !inserted {
        print
        print "rspack_plugin_split_chunks = { workspace = true }"
        inserted = 1
        next
      }
      { print }
    ' "${MANIFEST}" > "${MANIFEST}.tmp" && mv "${MANIFEST}.tmp" "${MANIFEST}"
  else
    printf '\n[dev-dependencies]\nrspack_plugin_split_chunks = { workspace = true }\n' >> "${MANIFEST}"
  fi
  echo "[test-setup] Added rspack_plugin_split_chunks dev-dependency to crates/rspack."
else
  echo "[test-setup] rspack_plugin_split_chunks dev-dependency already present."
fi

echo "[test-setup] Setup complete."
