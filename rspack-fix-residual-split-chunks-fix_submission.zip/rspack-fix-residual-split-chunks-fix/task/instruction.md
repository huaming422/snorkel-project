## Task

a project that leans on rspack's `splitChunks` is shipping duplicated code. the config has several cache groups at different priorities, and a module that several chunks share only gets half-deduplicated: a higher-priority cache group lifts that shared module out of some of the chunks that use it, and the copies left behind, in the other chunks that use the very same module, never make it into a shared chunk. they just sit there duplicated in the output.

single-group setups dedupe fine, so something about how the overlapping cache groups hand off to each other is broken. you can reproduce by building a small multi-chunk project that shares a module and checking which output chunks still carry a copy. dig into the split-chunks optimization and fix it so those leftover copies get deduplicated too.
