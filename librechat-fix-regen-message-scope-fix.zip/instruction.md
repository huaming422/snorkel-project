## Task

Once a response in a LibreChat conversation has been regenerated a few times, the artifact side panel starts opening on its own for the wrong response.

While a response is regenerating, the panel pops open on a preview (HTML, React, Markdown) that belongs to an older, already finished branch instead of staying with the response being generated. An older response that still had a pending preview can also open the panel when that preview finishes resolving while another response is generating.

Only the response being generated should open the panel automatically. That includes a preview that finishes resolving right after its stream ends, and it applies anywhere a response's files are shown. It should hold when the same file appears under more than one response, and when the message row on screen switches between branches (regenerating, or paging through siblings). Older responses' previews stay closed until someone clicks them.

Separately, when a regeneration fails, the failed attempt shows up as a detached message instead of under the turn it was regenerating. That happens whether the request is rejected before anything streams back or it fails partway through (the connection drops, or the server sends back an error). The rejection itself is expected. The failed attempt just needs to stay attached to its original turn.

Can you track these down and fix them?
