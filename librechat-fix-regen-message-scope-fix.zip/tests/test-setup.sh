#!/usr/bin/env bash
# Sourced (not exec'd) by the harbor runner so env vars and any background
# process state stays alive for the verifier.
#
# pipefail is critical: without it, `cmd | tail` masks a failing cmd behind a
# successful tail, which would silently skip the online fallback path.
set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/LibreChat}"
cd "$REPO_DIR"

# ---------------------------------------------------------------- #
# Dependencies                                                     #
# ---------------------------------------------------------------- #
# The image already baked the FULL dependency closure at the base commit
# (npm ci + the workspace package builds that the client jest suite resolves:
# librechat-data-provider, @librechat/client, @librechat/data-schemas). The
# agent phase runs no-network (agent_offline=true), so nothing here may be
# required for the agent — this script runs only in the verifier phase (which
# has network) as a belt-and-suspenders check plus an online fallback in the
# rare case a dependency is missing.

ensure_deps() {
    # node_modules is baked; only (re)install if it somehow went missing.
    if [ -d "$REPO_DIR/node_modules" ] && [ -d "$REPO_DIR/client/node_modules" ]; then
        echo "[test-setup] dependency closure present (baked in image)"
        return 0
    fi
    echo "[test-setup] node_modules missing; attempting offline install..."
    if npm ci --prefer-offline --no-audit --no-fund 2>&1 | tail -20; then
        echo "[test-setup] offline-preferred install succeeded"
    else
        echo "[test-setup] offline install failed; retrying online..."
        npm ci --no-audit --no-fund 2>&1 | tail -30
    fi
}

ensure_built_workspace_packages() {
    # The client jest suite resolves the compiled dist/ of these workspace
    # packages via moduleNameMapper. They are built in the image; rebuild only
    # if a dist/ is absent.
    for pkg_dir in \
        "packages/data-provider/dist" \
        "packages/client/dist" \
        "packages/data-schemas/dist"; do
        if [ ! -d "$REPO_DIR/$pkg_dir" ]; then
            echo "[test-setup] $pkg_dir missing; rebuilding workspace packages..."
            npm run build:data-provider 2>&1 | tail -10 || true
            npm run build:data-schemas 2>&1 | tail -10 || true
            npm run build:client-package 2>&1 | tail -10 || true
            break
        fi
    done
}

ensure_deps
ensure_built_workspace_packages

# Sanity: the verifier needs jest runnable from the client workspace.
( cd "$REPO_DIR/client" && npx jest --version >/dev/null 2>&1 ) \
    || echo "[test-setup] WARNING: npx jest not runnable from client/"

echo "[test-setup] ready: $REPO_DIR (node=$(node -v 2>/dev/null), npm=$(npm -v 2>/dev/null))"
