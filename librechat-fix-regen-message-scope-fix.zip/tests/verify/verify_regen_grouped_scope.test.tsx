/**
 * A response with several tool calls renders their files once, in a shared
 * row under the tool group. A rich-preview file in that row follows the same
 * rule as any other artifact card: it opens the side panel only for the
 * response that is generating. A prior response shown while another one
 * regenerates keeps its panel closed; the generating response still opens.
 *
 * The real attachment row and artifact card render inside ContentParts, and
 * the outcome is read from the panel state in `~/store` (selected artifact id
 * and visibility).
 */
import React from 'react';
import { RecoilRoot, useRecoilValue } from 'recoil';
import { ContentTypes } from 'librechat-data-provider';
import { render } from '@testing-library/react';
import type { MutableSnapshot } from 'recoil';
import type { TAttachment, TMessageContentParts } from 'librechat-data-provider';
import ContentParts from '~/components/Chat/Messages/Content/ContentParts';
import {
  MessagesViewContext,
  type MessagesViewContextValue,
} from '~/Providers/MessagesViewContext';
import store from '~/store';

jest.mock('~/hooks', () => ({
  useLocalize: () => (key: string, values?: Record<string | number, string>) => {
    if (key === 'com_ui_ran_n_actions') {
      return `Ran ${values?.[0]} actions`;
    }
    if (key === 'com_ui_running_n_actions') {
      return `Running ${values?.[0]} actions`;
    }
    if (key === 'com_ui_n_of_n_actions_failed') {
      return `${values?.[0]}/${values?.[1]} failed`;
    }
    return key;
  },
  useExpandCollapse: (isExpanded: boolean) => ({
    style: { display: 'grid', gridTemplateRows: isExpanded ? '1fr' : '0fr' },
    ref: { current: null },
  }),
  useLazyCollapseBody: jest.requireActual('~/hooks/Messages/useLazyCollapseBody').default,
  useProgress: (initial: number) => (initial >= 1 ? 1 : initial),
  scheduleMessageContentLayoutReconcile: jest.fn(() => jest.fn()),
  /* The files here are already resolved, so the preview poll has nothing to do. */
  useAttachmentPreviewSync: () => ({ status: 'ready', previewError: undefined, isPolling: false }),
}));

jest.mock('~/hooks/MCP', () => {
  const mcpServerNames: string[] = [];
  return {
    useMCPIconMap: () => new Map(),
    useMCPServerNames: () => mcpServerNames,
  };
});

jest.mock('~/components/Chat/Messages/Content/ToolOutput', () => ({
  StackedToolIcons: () => <span data-testid="stacked-icons" />,
  getMCPServerName: () => '',
  ToolIcon: () => <span data-testid="tool-icon" />,
  getToolIconType: () => 'mcp',
  isError: () => false,
}));

jest.mock('~/components/Chat/Messages/Content/ToolCallInfo', () => ({
  __esModule: true,
  default: () => <div data-testid="tool-call-info" />,
}));

jest.mock('~/components/Chat/Messages/Content/ProgressText', () => ({
  __esModule: true,
  default: ({ onClick, finishedText }: { onClick?: () => void; finishedText?: string }) => (
    <div data-testid="progress-text" onClick={onClick}>
      {finishedText}
    </div>
  ),
}));

jest.mock('lucide-react', () => ({
  ...jest.requireActual('lucide-react'),
  ChevronDown: () => <span>{'chevron'}</span>,
  TriangleAlert: () => <span>{'alert'}</span>,
  Users: () => <span>{'users'}</span>,
}));

jest.mock('@librechat/client', () => ({
  useMediaQuery: () => false,
  Button: ({
    children,
    variant: _variant,
    size: _size,
    ...props
  }: React.ComponentProps<'button'> & { variant?: string; size?: string }) => (
    <button {...props}>{children}</button>
  ),
}));

jest.mock('~/components/Chat/Messages/Content/Parts', () => ({
  StreamingThoughtPeek: ({ text }: { text: string }) => (
    <div data-testid="streaming-thought-peek">{text}</div>
  ),
  /* The real attachment row, so a rich-preview file renders its real card. */
  AttachmentGroup: jest.requireActual('~/components/Chat/Messages/Content/Parts/Attachment')
    .AttachmentGroup,
  ExecuteCode: () => <div data-testid="execute-code" />,
  ImageGen: () => <div data-testid="image-gen" />,
  AgentUpdate: () => <div data-testid="agent-update" />,
  EmptyText: () => <div data-testid="empty-text" />,
  Reasoning: () => <div data-testid="reasoning" />,
  ReasoningCompact: () => <div data-testid="compact-reasoning" />,
  Summary: () => <div data-testid="summary" />,
  Text: ({ text }: { text?: string }) => <div data-testid="text">{text}</div>,
  MemoryCall: ({ attachments }: { attachments?: TAttachment[] }) => (
    <div data-testid="memory-call" data-count={attachments?.length ?? 0} />
  ),
}));

jest.mock('~/components/Chat/Messages/Content/Parts/LogLink', () => ({
  useAttachmentLink: () => ({ handleDownload: jest.fn() }),
}));

jest.mock('~/components/Chat/Input/Files/FileContainer', () => ({
  __esModule: true,
  default: ({ file, displayName }: { file: { filename?: string }; displayName?: string }) => (
    <div data-testid="file-container">{displayName ?? file.filename ?? ''}</div>
  ),
}));

jest.mock('~/components/Chat/Input/Files/FilePreview', () => ({
  __esModule: true,
  default: () => <div data-testid="file-preview" />,
}));

jest.mock('~/components/Messages/Content/Mermaid/Mermaid', () => ({
  __esModule: true,
  default: ({ children }: { children: string }) => <div data-testid="mermaid-render">{children}</div>,
}));

jest.mock('~/components/Chat/Messages/Content/MemoryArtifacts', () => ({
  __esModule: true,
  default: () => <div data-testid="memory-artifacts" />,
}));

jest.mock('~/components/Chat/Messages/Content/WebSearch', () => ({
  __esModule: true,
  default: ({ attachments }: { attachments?: TAttachment[] }) => (
    <div data-testid="web-search" data-count={attachments?.length ?? 0} />
  ),
}));

jest.mock('~/components/Chat/Messages/Content/RetrievalCall', () => ({
  __esModule: true,
  default: () => <div data-testid="retrieval-call" />,
}));

jest.mock('~/components/Chat/Messages/Content/AgentHandoff', () => ({
  __esModule: true,
  default: () => <div data-testid="agent-handoff" />,
}));

jest.mock('~/components/Chat/Messages/Content/CodeAnalyze', () => ({
  __esModule: true,
  default: () => <div data-testid="code-analyze" />,
}));

jest.mock('~/components/Chat/Messages/Content/Image', () => ({
  __esModule: true,
  default: () => <div data-testid="image" />,
}));

jest.mock('~/components/Chat/Messages/Content/Container', () => ({
  __esModule: true,
  default: ({ children }: { children?: React.ReactNode }) => <div>{children}</div>,
}));

jest.mock('~/components/Chat/Messages/Content/SiblingHeader', () => ({
  __esModule: true,
  default: ({ agentId }: { agentId?: string }) => (
    <div data-testid="sibling-header" data-agent-id={agentId} />
  ),
}));

jest.mock('~/utils', () => {
  const actual = jest.requireActual('~/utils');
  return {
    ...actual,
    cn: (...classes: Array<string | false | null | undefined>) => classes.filter(Boolean).join(' '),
    logger: { log: jest.fn(), warn: jest.fn(), error: jest.fn() },
  };
});

const MCP_DELIMITER = '_mcp_';
const ACTIVE_ELSEWHERE = 'active-response';

const makeMcpToolCall = (id: string): TMessageContentParts =>
  ({
    type: ContentTypes.TOOL_CALL,
    [ContentTypes.TOOL_CALL]: {
      id,
      name: `getTinyImage${MCP_DELIMITER}Everything`,
      args: '{}',
      output: 'file_returned',
    },
  }) as unknown as TMessageContentParts;

/** A resolved HTML file: renders as a rich-preview card in the shared row. */
const htmlAttachment = (owner: string, toolCallId: string): TAttachment =>
  ({
    file_id: 'grouped-report',
    filename: 'report.html',
    filepath: '/files/report.html',
    type: 'text/html',
    text: '<h1>report</h1>',
    messageId: owner,
    toolCallId,
    conversationId: 'c1',
  }) as unknown as TAttachment;

const imageAttachment = (owner: string, toolCallId: string): TAttachment =>
  ({
    filename: 'tiny.png',
    filepath: '/files/tiny.png',
    width: 16,
    height: 16,
    messageId: owner,
    toolCallId,
    conversationId: 'c1',
  }) as unknown as TAttachment;

interface PanelSnapshot {
  visibility: boolean;
  currentArtifactId: string | null;
  artifactIds: string[];
}

const StateProbe = ({ onSnapshot }: { onSnapshot: (snap: PanelSnapshot) => void }) => {
  const visibility = useRecoilValue(store.artifactsVisibility);
  const currentArtifactId = useRecoilValue(store.currentArtifactId);
  const artifacts = useRecoilValue(store.artifactsState);
  React.useEffect(() => {
    onSnapshot({ visibility, currentArtifactId, artifactIds: Object.keys(artifacts ?? {}) });
  });
  return null;
};

/**
 * Render one response's content while a turn is in flight. `isLive` says
 * whether this response is the one generating: when it is, the props
 * ContentParts receives, and the conversation's latest message id, all name
 * this response; otherwise another response is the active one.
 */
function renderResponse(messageId: string, isLive: boolean): PanelSnapshot {
  let snapshot: PanelSnapshot = { visibility: false, currentArtifactId: null, artifactIds: [] };
  const initializeState = (snap: MutableSnapshot) => {
    snap.set(store.isSubmittingFamily(0), true);
    snap.set(store.artifactsVisibility, false);
  };
  render(
    <RecoilRoot initializeState={initializeState}>
      <StateProbe onSnapshot={(next) => (snapshot = next)} />
      <MessagesViewContext.Provider
        value={{ latestMessageId: isLive ? messageId : ACTIVE_ELSEWHERE } as MessagesViewContextValue}
      >
        <ContentParts
          messageId={messageId}
          conversationId="c1"
          isCreatedByUser={false}
          isLast={isLive}
          isSubmitting={true}
          isLatestMessage={isLive}
          showThinking={false}
          content={[makeMcpToolCall('t1'), makeMcpToolCall('t2')]}
          attachments={[htmlAttachment(messageId, 't1'), imageAttachment(messageId, 't2')]}
        />
      </MessagesViewContext.Provider>
    </RecoilRoot>,
  );
  return snapshot;
}

describe('grouped tool-call files and the artifact panel', () => {
  it('keeps the panel closed for a prior response shown while another response regenerates', () => {
    const snapshot = renderResponse('previous-response', false);
    // The card still registers, so an explicit click can open it.
    expect(snapshot.artifactIds).toContain('tool-artifact-grouped-report');
    expect(snapshot.currentArtifactId).toBeNull();
    expect(snapshot.visibility).toBe(false);
  });

  it('opens the panel for the response that is generating', () => {
    const snapshot = renderResponse('live-response', true);
    expect(snapshot.currentArtifactId).toBe('tool-artifact-grouped-report');
    expect(snapshot.visibility).toBe(true);
  });
});
