/**
 * Deferred previews and the artifact panel. A file whose preview is still
 * pending is polled by `useAttachmentPreviewSync` (its `useFilePreview` query
 * is mocked here to step from pending to ready). When the preview resolves for
 * the response that is generating, that response's card opens the panel even
 * if it mounts after streaming has ended.
 *
 * Each case steps a preview to ready, mounts a real card, and reads the panel
 * state (selected artifact id and visibility).
 *
 *   - A card whose owning response differs from the one that resolved the
 *     preview must NOT auto-open (a prior answer reusing the same file id).
 *   - A card whose owning response matches the resolved one MUST still open,
 *     even after streaming has ended and nothing is submitting.
 *   - A prior response's own pending preview that resolves while a different
 *     response is generating must NOT open the panel, including when the row
 *     that polls it was showing the generating response before.
 */
import React from 'react';
import { RecoilRoot, useRecoilValue, useSetRecoilState } from 'recoil';
import { act, render } from '@testing-library/react';
import type { MutableSnapshot } from 'recoil';
import type { TAttachment, TFile, TAttachmentMetadata, TFilePreview } from 'librechat-data-provider';
import Attachment from '~/components/Chat/Messages/Content/Parts/Attachment';
import { MessageContext } from '~/Providers/MessageContext';
import {
  MessagesViewContext,
  type MessagesViewContextValue,
} from '~/Providers/MessagesViewContext';
import useAttachmentPreviewSync from '~/hooks/Files/useAttachmentPreviewSync';
import store from '~/store';

/* Control the producer's upstream preview query so a test can step the file
 * from pending to ready and fire the resolution edge. */
let currentPreview: TFilePreview | undefined;
const mockUseFilePreview = jest.fn();
jest.mock('~/data-provider', () => ({
  useFilePreview: (...args: unknown[]) => mockUseFilePreview(...args),
}));

jest.mock('~/hooks', () => ({
  useLocalize:
    () =>
    (key: string): string =>
      key,
  useAttachmentPreviewSync: () => ({ status: 'ready', previewError: undefined, isPolling: false }),
  useExpandCollapse: (isExpanded: boolean) => ({
    style: { display: 'grid', gridTemplateRows: isExpanded ? '1fr' : '0fr' },
    ref: { current: null },
  }),
}));

jest.mock('~/components/Chat/Messages/Content/Parts/LogLink', () => ({
  useAttachmentLink: () => ({ handleDownload: jest.fn() }),
}));

jest.mock('~/components/Chat/Input/Files/FileContainer', () => ({
  __esModule: true,
  default: ({ file, displayName }: { file: { filename?: string }; displayName?: string }) => (
    <div data-testid="file-container">{displayName ?? file.filename ?? ''}</div>
  ),
}));

jest.mock('~/components/Chat/Input/Files/FilePreview', () => ({
  __esModule: true,
  default: () => <div data-testid="file-preview" />,
}));

jest.mock('~/components/Chat/Messages/Content/Image', () => ({
  __esModule: true,
  default: ({ altText }: { altText?: string }) => <img alt={altText ?? ''} data-testid="image" />,
}));

jest.mock('~/components/Messages/Content/Mermaid/Mermaid', () => ({
  __esModule: true,
  default: ({ children }: { children: string }) => <div data-testid="mermaid-render">{children}</div>,
}));

jest.mock('~/utils', () => ({
  ...jest.requireActual('~/utils'),
  cn: (...classes: Array<string | false | null | undefined>) => classes.filter(Boolean).join(' '),
  getFileType: () => ({ paths: [], color: '', title: 'Artifact' }),
  logger: { log: jest.fn(), warn: jest.fn(), error: jest.fn() },
  isArtifactRoute: () => false,
}));

type AttachmentFixture = TFile & TAttachmentMetadata;

const fileId = 'shared-preview';
const liveResponseId = 'live-response';

/** The pending file the producer polls (same file id as the rendered card). */
const pendingAttachment = (owner: string): AttachmentFixture =>
  ({
    user: 'user-1',
    object: 'file',
    bytes: 1024,
    embedded: false,
    usage: 0,
    file_id: fileId,
    filename: 'chart.html',
    filepath: '/uploads/chart.html',
    type: 'text/html',
    messageId: owner,
    toolCallId: 'tc-1',
    status: 'pending',
  }) as AttachmentFixture;

/** The resolved rich-preview the card renders (routes to a panel artifact). */
const resolvedCardAttachment = (owner: string): TAttachment =>
  ({
    file_id: fileId,
    filename: 'chart.html',
    filepath: '/uploads/chart.html',
    text: '<h1>resolved</h1>',
    type: 'text/html',
    messageId: owner,
  }) as TAttachment;

interface PanelSnapshot {
  visibility: boolean;
  currentArtifactId: string | null;
  artifactIds: string[];
}

const StateProbe = ({ onSnapshot }: { onSnapshot: (snap: PanelSnapshot) => void }) => {
  const visibility = useRecoilValue(store.artifactsVisibility);
  const currentArtifactId = useRecoilValue(store.currentArtifactId);
  const artifacts = useRecoilValue(store.artifactsState);
  React.useEffect(() => {
    onSnapshot({ visibility, currentArtifactId, artifactIds: Object.keys(artifacts ?? {}) });
  });
  return null;
};

/* Lets a case end the stream after the preview resolves and before the card
 * mounts, so the card mounts with nothing submitting. */
let setGlobalSubmitting: ((v: boolean) => void) | null = null;
const SubmitBridge = () => {
  setGlobalSubmitting = useSetRecoilState(store.isSubmittingFamily(0));
  return null;
};

/* The preview-sync producer for the response that owns the pending file. */
const Producer = ({ owner }: { owner: string }) => {
  useAttachmentPreviewSync(pendingAttachment(owner));
  return null;
};

/**
 * Step a preview from pending→ready on the response `producerOwners` ends
 * with, then mount a card owned by `cardOwner` and return the resulting panel
 * state. Earlier entries in `producerOwners` are responses the same polling
 * row showed while the file was still pending.
 */
function runScenario(
  cardOwner: string,
  producerOwners: string[] = [liveResponseId],
): PanelSnapshot {
  currentPreview = { file_id: fileId, status: 'pending' };
  mockUseFilePreview.mockReset();
  mockUseFilePreview.mockImplementation(() => ({ data: currentPreview, isFetching: false }));

  let snapshot: PanelSnapshot = { visibility: false, currentArtifactId: null, artifactIds: [] };
  const onSnapshot = (next: PanelSnapshot) => {
    snapshot = next;
  };

  const initializeState = (snap: MutableSnapshot) => {
    // The live response is streaming when its preview starts resolving.
    snap.set(store.isSubmittingFamily(0), true);
    snap.set(store.artifactsVisibility, false);
  };

  // The live response is the conversation's latest message throughout,
  // supplied through MessagesViewContext as the app does.
  const cardIsLive = cardOwner === liveResponseId;
  const Tree = ({ showCard, producerOwner }: { showCard: boolean; producerOwner: string }) => (
    <MessagesViewContext.Provider
      value={{ latestMessageId: liveResponseId } as MessagesViewContextValue}
    >
      <StateProbe onSnapshot={onSnapshot} />
      <SubmitBridge />
      {/* Every liveness channel agrees on the producer's response: context
       * isSubmitting + isLatestMessage, and whether it is the active
       * latestMessageId. Only the live response's resolution is fresh. */}
      <MessageContext.Provider
        value={{
          messageId: producerOwner,
          isExpanded: true,
          isSubmitting: producerOwner === liveResponseId,
          isLatestMessage: producerOwner === liveResponseId,
        }}
      >
        <Producer owner={producerOwner} />
      </MessageContext.Provider>
      {showCard && (
        <MessageContext.Provider
          value={{
            messageId: cardOwner,
            isExpanded: true,
            isSubmitting: false,
            isLatestMessage: cardIsLive,
          }}
        >
          <Attachment attachment={resolvedCardAttachment(cardOwner)} />
        </MessageContext.Provider>
      )}
    </MessagesViewContext.Provider>
  );

  const finalProducer = producerOwners[producerOwners.length - 1];
  const { rerender } = render(
    <RecoilRoot initializeState={initializeState}>
      <Tree showCard={false} producerOwner={producerOwners[0]} />
    </RecoilRoot>,
  );
  // The same row moves on to each later response while the file is pending.
  for (const owner of producerOwners.slice(1)) {
    rerender(
      <RecoilRoot initializeState={initializeState}>
        <Tree showCard={false} producerOwner={owner} />
      </RecoilRoot>,
    );
  }

  // Fire the pending→ready edge for the final owner's preview.
  act(() => {
    currentPreview = {
      file_id: fileId,
      status: 'ready',
      text: '<h1>resolved</h1>',
      textFormat: 'html',
    };
  });
  rerender(
    <RecoilRoot initializeState={initializeState}>
      <Tree showCard={false} producerOwner={finalProducer} />
    </RecoilRoot>,
  );

  // Streaming has ended by the time the card mounts.
  act(() => {
    setGlobalSubmitting?.(false);
  });

  // Mount the card owned by `cardOwner`.
  rerender(
    <RecoilRoot initializeState={initializeState}>
      <Tree showCard={true} producerOwner={finalProducer} />
    </RecoilRoot>,
  );

  return snapshot;
}

describe('deferred-preview auto-open scoping', () => {
  it('still auto-opens the card when the resolved preview belongs to its own response', () => {
    const snapshot = runScenario(liveResponseId);
    expect(snapshot.currentArtifactId).toBe('tool-artifact-shared-preview');
    expect(snapshot.visibility).toBe(true);
  });

  it('does not auto-open a card from a different response that reuses the same file id', () => {
    const snapshot = runScenario('previous-response');
    // The card mounted and registered, so it can still be opened by a click.
    expect(snapshot.artifactIds).toContain('tool-artifact-shared-preview');
    expect(snapshot.currentArtifactId).toBeNull();
    expect(snapshot.visibility).toBe(false);
  });

  it('does not auto-open a prior response whose own pending preview resolves while another response generates', () => {
    const snapshot = runScenario('previous-response', ['previous-response']);
    // The card mounted and registered, so it can still be opened by a click.
    expect(snapshot.artifactIds).toContain('tool-artifact-shared-preview');
    expect(snapshot.currentArtifactId).toBeNull();
    expect(snapshot.visibility).toBe(false);
  });

  it('does not auto-open a prior response whose preview resolves on a row reused from the generating response', () => {
    const snapshot = runScenario('previous-response', [liveResponseId, 'previous-response']);
    // The card mounted and registered, so it can still be opened by a click.
    expect(snapshot.artifactIds).toContain('tool-artifact-shared-preview');
    expect(snapshot.currentArtifactId).toBeNull();
    expect(snapshot.visibility).toBe(false);
  });

  it('still auto-opens the generating response whose preview resolves on a row reused from a prior response', () => {
    const snapshot = runScenario(liveResponseId, ['previous-response', liveResponseId]);
    expect(snapshot.currentArtifactId).toBe('tool-artifact-shared-preview');
    expect(snapshot.visibility).toBe(true);
  });
});
