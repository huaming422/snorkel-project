/**
 * The artifacts panel's auto-selection effect advances to the newest artifact
 * when a turn finishes. During a regeneration, a historical sibling artifact
 * (owned by a different, older response) can sort last by update time; the
 * selection must stay anchored to the live response and not jump onto that
 * sibling. Observed through the public `setCurrentArtifactId` state setter.
 */
import { renderHook } from '@testing-library/react';
import type { Artifact } from '~/common';

jest.mock('~/Providers', () => ({
  useArtifactsContext: jest.fn(),
}));

jest.mock('~/utils', () => ({
  ...jest.requireActual('~/utils'),
  logger: {
    log: jest.fn(),
  },
}));

jest.mock('~/store', () => ({
  __esModule: true,
  default: {
    artifactsState: { key: 'artifactsState' },
    currentArtifactId: { key: 'currentArtifactId' },
    artifactsVisibility: { key: 'artifactsVisibility' },
  },
}));

jest.mock('recoil', () => {
  const actualRecoil = jest.requireActual('recoil');
  return {
    ...actualRecoil,
    useRecoilValue: jest.fn(),
    useRecoilState: jest.fn(),
    useResetRecoilState: jest.fn(),
  };
});

import { useArtifactsContext } from '~/Providers';
import { useRecoilValue, useRecoilState, useResetRecoilState } from 'recoil';
import useArtifacts from '~/hooks/Artifacts/useArtifacts';

describe('useArtifacts owner-scoped auto-selection', () => {
  const mockResetArtifacts = jest.fn();
  const mockResetCurrentArtifactId = jest.fn();
  const mockSetCurrentArtifactId = jest.fn();

  const createArtifact = (partial: Partial<Artifact>): Artifact => ({
    id: 'artifact-1',
    title: 'Test Artifact',
    type: 'application/vnd.react',
    content: 'const App = () => <div>Test</div>',
    messageId: 'msg-1',
    lastUpdateTime: 1000,
    ...partial,
  });

  const defaultContext = {
    isSubmitting: false,
    latestMessageId: 'msg-1',
    latestMessageText: '',
    conversationId: 'conv-1',
  };

  beforeEach(() => {
    jest.clearAllMocks();
    jest.useFakeTimers();

    (useArtifactsContext as jest.Mock).mockReturnValue(defaultContext);
    (useRecoilValue as jest.Mock).mockReturnValue({});
    (useRecoilState as jest.Mock).mockReturnValue([null, mockSetCurrentArtifactId]);
    (useResetRecoilState as jest.Mock).mockImplementation((atom) => {
      if (atom?.key === 'artifactsState') {
        return mockResetArtifacts;
      }
      if (atom?.key === 'currentArtifactId') {
        return mockResetCurrentArtifactId;
      }
      return jest.fn();
    });
  });

  afterEach(() => {
    jest.useRealTimers();
  });

  it('auto-selects the latest artifact on mount (unchanged baseline)', () => {
    const artifacts = {
      'artifact-1': createArtifact({ id: 'artifact-1', lastUpdateTime: 1000 }),
      'artifact-2': createArtifact({ id: 'artifact-2', lastUpdateTime: 2000 }),
    };
    (useRecoilValue as jest.Mock).mockReturnValue(artifacts);

    renderHook(() => useArtifacts());

    expect(mockSetCurrentArtifactId).toHaveBeenCalledWith('artifact-2');
  });

  it('does not select a historical sibling artifact when regeneration begins', () => {
    const selected = createArtifact({
      id: 'selected',
      messageId: 'original-response',
      lastUpdateTime: 1000,
    });
    const historical = createArtifact({
      id: 'historical',
      messageId: 'previous-sibling',
      lastUpdateTime: 2000,
      content: 'old preview',
    });
    (useRecoilValue as jest.Mock).mockReturnValue({ selected });
    (useRecoilState as jest.Mock).mockReturnValue(['selected', mockSetCurrentArtifactId]);
    const { rerender } = renderHook(() => useArtifacts());
    mockSetCurrentArtifactId.mockClear();

    (useArtifactsContext as jest.Mock).mockReturnValue({
      ...defaultContext,
      isSubmitting: true,
      latestMessageId: 'original-response_',
    });
    (useRecoilValue as jest.Mock).mockReturnValue({ selected, historical });
    rerender();

    expect(mockSetCurrentArtifactId).not.toHaveBeenCalled();
  });
});
