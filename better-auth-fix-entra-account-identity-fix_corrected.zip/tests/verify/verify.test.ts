// @ts-nocheck
//
// Microsoft Entra ID account identity across both Microsoft sign-in paths.
//
// Both paths are driven end to end through the public sign-in flow and the
// stored account rows are read back through the adapter:
//   - the built-in `microsoft` social provider through
//     `client.signIn.social({ provider: "microsoft", idToken })` and
//     `client.linkSocial(...)` for a signed-in user.
//   - the generic-oauth `microsoftEntraId(...)` helper registered with
//     `genericOAuth`, signed in through `signIn.social` and the OAuth callback
//     route, with the Entra discovery document, signing keys, token response
//     and Graph userinfo served locally.
//
// A changed app registration shows up as a new per-application `sub` for the
// same person, while `oid` and `tid` stay the same. Where the stored
// identifier may take more than one form, the assertions check that it
// contains the token's directory object id and is not the per-application
// subject, so a bare id or a `{tenant}:{id}` composite both pass.

import { exportJWK, generateKeyPair, SignJWT } from "jose";
import { HttpResponse, http } from "msw";
import { setupServer } from "msw/node";
import {
	afterAll,
	afterEach,
	beforeAll,
	describe,
	expect,
	it,
} from "vitest";
import { createAuthClient } from "./client";
import { genericOAuth } from "./plugins/generic-oauth";
import { microsoftEntraId } from "./plugins/generic-oauth/providers/microsoft-entra-id";
import { getTestInstance } from "./test-utils/test-instance";

const mswServer = setupServer();

beforeAll(() => {
	mswServer.listen({ onUnhandledRequest: "bypass" });
});
afterEach(() => {
	mswServer.resetHandlers();
});
afterAll(() => {
	mswServer.close();
});

// One RSA key pair serves as the Entra signing key for both paths.
const rsaKeyPair = await generateKeyPair("RS256");
const rsaJwk = await exportJWK(rsaKeyPair.publicKey);
const msKid = "verify-microsoft-kid";
rsaJwk.kid = msKid;
rsaJwk.alg = "RS256";
rsaJwk.use = "sig";

const ENTRA_JWKS_URL =
	"https://login.microsoftonline.com/common/discovery/v2.0/keys";
const GRAPH_PHOTO_URL = "https://graph.microsoft.com/v1.0/me/photos/*";
const GRAPH_USERINFO_URL = "https://graph.microsoft.com/oidc/userinfo";

const VERIFY_TENANT_ID = "12345678-1234-1234-1234-123456789012";
const VERIFY_TENANT_ISSUER = `https://login.microsoftonline.com/${VERIFY_TENANT_ID}/v2.0`;
const VERIFY_TENANT_JWKS_URL = `https://login.microsoftonline.com/${VERIFY_TENANT_ID}/discovery/v2.0/keys`;
const VERIFY_HELPER_CLIENT_ID = "verify-ms-client-id";

// A signed built-in-provider ID token. Its issuer names its own tenant and its
// audience is the configured clientId.
async function signBuiltinIdToken(
	clientId: string,
	claims: Record<string, unknown>,
) {
	const tid = (claims.tid as string) ?? "verify-tenant";
	return new SignJWT({
		ver: "2.0",
		tid,
		preferred_username: claims.email,
		...claims,
	})
		.setProtectedHeader({ alg: "RS256", kid: msKid })
		.setIssuedAt()
		.setNotBefore(Math.floor(Date.now() / 1000) - 60)
		.setIssuer(`https://login.microsoftonline.com/${tid}/v2.0`)
		.setAudience(clientId)
		.setExpirationTime("1h")
		.sign(rsaKeyPair.privateKey);
}

// A signed ID token as the configured tenant would issue it to the generic
// helper's app registration.
async function signVerifyTenantIdToken(claims: Record<string, unknown>) {
	return new SignJWT({
		ver: "2.0",
		tid: VERIFY_TENANT_ID,
		preferred_username: claims.email,
		...claims,
	})
		.setProtectedHeader({ alg: "RS256", kid: msKid })
		.setIssuedAt()
		.setNotBefore(Math.floor(Date.now() / 1000) - 60)
		.setIssuer(VERIFY_TENANT_ISSUER)
		.setAudience(VERIFY_HELPER_CLIENT_ID)
		.setExpirationTime("1h")
		.sign(rsaKeyPair.privateKey);
}

function serveBuiltinKeys() {
	mswServer.use(
		http.get(ENTRA_JWKS_URL, async () => HttpResponse.json({ keys: [rsaJwk] })),
		http.get(
			GRAPH_PHOTO_URL,
			async () => new HttpResponse(null, { status: 404 }),
		),
	);
}

// Serves the tenant's discovery document, signing keys and Graph userinfo.
// Graph answers with the `sub` of whichever token was handed out last.
function serveVerifyTenant(graphProfile: () => Record<string, unknown>) {
	mswServer.use(
		http.get(
			`${VERIFY_TENANT_ISSUER}/.well-known/openid-configuration`,
			() =>
				HttpResponse.json({
					issuer: VERIFY_TENANT_ISSUER,
					authorization_endpoint: `https://login.microsoftonline.com/${VERIFY_TENANT_ID}/oauth2/v2.0/authorize`,
					token_endpoint: `https://login.microsoftonline.com/${VERIFY_TENANT_ID}/oauth2/v2.0/token`,
					userinfo_endpoint: GRAPH_USERINFO_URL,
					jwks_uri: VERIFY_TENANT_JWKS_URL,
					id_token_signing_alg_values_supported: ["RS256"],
					response_types_supported: ["code", "id_token", "code id_token"],
					subject_types_supported: ["pairwise"],
					scopes_supported: ["openid", "profile", "email", "offline_access"],
				}),
		),
		http.get(VERIFY_TENANT_JWKS_URL, () =>
			HttpResponse.json({ keys: [rsaJwk] }),
		),
		http.get(GRAPH_USERINFO_URL, () => HttpResponse.json(graphProfile())),
		http.get(GRAPH_PHOTO_URL, () => new HttpResponse(null, { status: 404 })),
	);
}

// One better-auth instance with the generic helper registered. `signIn(claims)`
// starts the flow through signIn.social, answers the token request with the
// given claims (carrying the nonce from the authorization URL when there is
// one) and calls the OAuth callback route. The tenant endpoints are served for
// every sign-in, and Graph reports the same `sub` and profile as the token.
async function createVerifyHelperInstance(options: Record<string, unknown> = {}) {
	let pendingClaims: Record<string, unknown> = {};
	let authorizationNonce: string | undefined;
	serveVerifyTenant(() => ({
		sub: pendingClaims.sub,
		email: pendingClaims.email,
		name: pendingClaims.name,
	}));
	const { auth, customFetchImpl, cookieSetter } = await getTestInstance(
		{
			...options,
			plugins: [
				genericOAuth({
					config: [
						{
							...microsoftEntraId({
								clientId: VERIFY_HELPER_CLIENT_ID,
								clientSecret: "verify-ms-client-secret",
								tenantId: VERIFY_TENANT_ID,
							}),
							getToken: async () => ({
								accessToken: "verify-ms-access-token",
								idToken: await signVerifyTenantIdToken(
									authorizationNonce
										? { ...pendingClaims, nonce: authorizationNonce }
										: pendingClaims,
								),
								tokenType: "Bearer",
							}),
						},
					],
				}),
			],
		},
		{ disableTestUser: true },
	);
	const client = createAuthClient({
		baseURL: "http://localhost:3000",
		fetchOptions: { customFetchImpl },
	});
	const ctx = await auth.$context;

	async function signIn(claims: Record<string, unknown>) {
		pendingClaims = claims;
		const headers = new Headers();
		const res = await client.signIn.social({
			provider: "microsoft-entra-id",
			callbackURL: "http://localhost:3000/dashboard",
			newUserCallbackURL: "http://localhost:3000/new_user",
			fetchOptions: { onSuccess: cookieSetter(headers) },
		});
		expect(res.data?.url).toBeTruthy();
		const authorizationURL = new URL(res.data.url);
		authorizationNonce =
			authorizationURL.searchParams.get("nonce") || undefined;
		const state = authorizationURL.searchParams.get("state");
		const redirectURI = authorizationURL.searchParams.get("redirect_uri");
		expect(state).toBeTruthy();
		expect(redirectURI).toBeTruthy();

		const callback = new URL(redirectURI);
		callback.searchParams.set("code", "verify-authorization-code");
		callback.searchParams.set("state", state);
		const callbackRes = await customFetchImpl(callback.toString(), {
			method: "GET",
			headers,
			redirect: "manual",
		});
		return callbackRes.headers.get("location") || "";
	}

	async function entraAccounts() {
		return ctx.adapter.findMany({
			model: "account",
			where: [{ field: "providerId", value: "microsoft-entra-id" }],
		});
	}

	return { auth, ctx, signIn, entraAccounts };
}

async function storedProviderAccountId(ctx, userId: string, providerId: string) {
	const accounts = await ctx.internalAdapter.findAccounts(userId);
	return accounts.find((a) => a.providerId === providerId)?.providerAccountId;
}

describe("account_id_is_stable_oid_builtin", () => {
	it("persists the account id from the stable directory object id, not the pairwise subject", async () => {
		const clientId = "verify-builtin-stable";
		const oid = "stable-oid-aaaa1111";
		const sub = "pairwise-sub-bbbb2222";

		const idToken = await signBuiltinIdToken(clientId, {
			sub,
			oid,
			tid: "verify-tenant-stable",
			email: "stable-user@outlook.com",
			name: "Stable User",
		});
		serveBuiltinKeys();

		const { auth, client } = await getTestInstance(
			{
				socialProviders: {
					microsoft: { clientId, clientSecret: "verify-builtin-secret" },
				},
			},
			{ disableTestUser: true },
		);

		const res = await client.signIn.social({
			provider: "microsoft",
			callbackURL: "/callback",
			idToken: { token: idToken },
		});

		expect(res.error).toBeFalsy();
		expect(res.data?.redirect).toBe(false);

		const ctx = await auth.$context;
		const accountId = await storedProviderAccountId(
			ctx,
			res.data.user.id,
			"microsoft",
		);
		expect(accountId).toBeTruthy();
		expect(accountId).toContain(oid);
		expect(accountId).not.toBe(sub);
	}, 60_000);
});

describe("returning_user_same_account_builtin", () => {
	it("signs the same person back into the same user after their per-application subject changes", async () => {
		const clientId = "verify-builtin-returning";
		const oid = "stable-oid-iiii9999";
		const claims = {
			oid,
			tid: "verify-tenant-returning",
			email: "returning-user@outlook.com",
			name: "Returning User",
		};
		serveBuiltinKeys();

		const { auth, client } = await getTestInstance(
			{
				socialProviders: {
					microsoft: { clientId, clientSecret: "verify-returning-secret" },
				},
			},
			{ disableTestUser: true },
		);

		const first = await client.signIn.social({
			provider: "microsoft",
			callbackURL: "/callback",
			idToken: {
				token: await signBuiltinIdToken(clientId, {
					...claims,
					sub: "pairwise-sub-before-0001",
				}),
			},
		});
		expect(first.error).toBeFalsy();

		const second = await client.signIn.social({
			provider: "microsoft",
			callbackURL: "/callback",
			idToken: {
				token: await signBuiltinIdToken(clientId, {
					...claims,
					sub: "pairwise-sub-after-0002",
				}),
			},
		});
		expect(second.error).toBeFalsy();
		expect(second.data.user.id).toBe(first.data.user.id);

		const ctx = await auth.$context;
		const users = await ctx.adapter.findMany({ model: "user" });
		expect(users).toHaveLength(1);
		const accounts = await ctx.adapter.findMany({
			model: "account",
			where: [{ field: "providerId", value: "microsoft" }],
		});
		expect(accounts).toHaveLength(1);
	}, 60_000);
});

describe("account_id_is_stable_oid_generic", () => {
	it("persists the account id from the stable directory object id, not the pairwise subject", async () => {
		const oid = "stable-oid-cccc3333";
		const sub = "pairwise-sub-dddd4444";
		const { ctx, signIn, entraAccounts } = await createVerifyHelperInstance();

		const location = await signIn({
			sub,
			oid,
			email: "generic-user@example.com",
			name: "Generic User",
		});

		expect(location).not.toContain("error=");
		const accounts = await entraAccounts();
		expect(accounts).toHaveLength(1);
		const accountId = await storedProviderAccountId(
			ctx,
			accounts[0].userId,
			"microsoft-entra-id",
		);
		expect(accountId).toBeTruthy();
		expect(accountId).toContain(oid);
		expect(accountId).not.toBe(sub);
	}, 60_000);
});

describe("returning_user_same_account_generic", () => {
	it("signs the same person back into the same user after their per-application subject changes", async () => {
		const claims = {
			oid: "stable-oid-jjjj0000",
			email: "generic-returning@example.com",
			name: "Generic Returning",
		};
		const { ctx, signIn, entraAccounts } = await createVerifyHelperInstance();

		const firstLocation = await signIn({
			...claims,
			sub: "pairwise-sub-before-0003",
		});
		expect(firstLocation).not.toContain("error=");
		const secondLocation = await signIn({
			...claims,
			sub: "pairwise-sub-after-0004",
		});
		expect(secondLocation).not.toContain("error=");

		const users = await ctx.adapter.findMany({ model: "user" });
		expect(users).toHaveLength(1);
		const accounts = await entraAccounts();
		expect(accounts).toHaveLength(1);
		expect(accounts[0].userId).toBe(users[0].id);
	}, 60_000);
});

describe("reject_token_without_oid_builtin", () => {
	it.each([
		["missing", undefined],
		["blank", " \t"],
	])("rejects an ID-token sign-in when oid is %s and creates no account row", async (_label, oid) => {
		const clientId = "verify-builtin-no-oid";
		const idToken = await signBuiltinIdToken(clientId, {
			sub: "pairwise-sub-eeee5555",
			oid,
			tid: "verify-tenant-no-oid",
			email: "no-oid@outlook.com",
			name: "No Oid User",
		});
		serveBuiltinKeys();

		const { auth, client } = await getTestInstance(
			{
				socialProviders: {
					microsoft: { clientId, clientSecret: "verify-no-oid-secret" },
				},
			},
			{ disableTestUser: true },
		);

		const res = await client.signIn.social({
			provider: "microsoft",
			callbackURL: "/callback",
			idToken: { token: idToken },
		});

		expect(res.error).toBeTruthy();
		expect(res.error?.status).toBeGreaterThanOrEqual(400);
		expect(res.error?.status).toBeLessThan(500);

		const ctx = await auth.$context;
		const accounts = await ctx.adapter.findMany({
			model: "account",
			where: [{ field: "providerId", value: "microsoft" }],
		});
		expect(accounts).toHaveLength(0);
	}, 60_000);
});

describe("reject_token_without_oid_generic", () => {
	it.each([
		["missing", undefined],
		["not a string", 123],
		["blank", " \t"],
	])("fails the sign-in when oid is %s and creates no account row", async (_label, oid) => {
		const { signIn, entraAccounts } = await createVerifyHelperInstance();

		const location = await signIn({
			sub: "pairwise-sub-ffff6666",
			oid,
			email: "legacy@example.com",
			name: "Legacy User",
		});

		expect(location).toContain("error=");
		expect(await entraAccounts()).toHaveLength(0);
	}, 60_000);
});

describe("link_only_with_oid_builtin", () => {
	it.each([
		["has an oid", "stable-oid-kkkk1212", true],
		["has no oid", undefined, false],
	])("links Microsoft to a signed-in user only when the token %s", async (_label, oid, linked) => {
		const clientId = "verify-builtin-link";
		serveBuiltinKeys();
		const { auth, client, testUser, signInWithTestUser } =
			await getTestInstance({
				socialProviders: {
					microsoft: { clientId, clientSecret: "verify-link-secret" },
				},
				account: {
					accountLinking: { enabled: true, trustedProviders: ["microsoft"] },
				},
			});
		const { headers, user } = await signInWithTestUser();

		const res = await client.linkSocial(
			{
				provider: "microsoft",
				callbackURL: "/callback",
				idToken: {
					token: await signBuiltinIdToken(clientId, {
						sub: "pairwise-sub-link-1313",
						oid,
						tid: "verify-tenant-link",
						email: testUser.email,
						name: testUser.name,
					}),
				},
			},
			{ headers },
		);

		const ctx = await auth.$context;
		const accounts = await ctx.adapter.findMany({
			model: "account",
			where: [{ field: "providerId", value: "microsoft" }],
		});
		if (linked) {
			expect(res.error).toBeFalsy();
			expect(accounts).toHaveLength(1);
			expect(accounts[0].userId).toBe(user.id);
			const accountId = await storedProviderAccountId(
				ctx,
				user.id,
				"microsoft",
			);
			expect(accountId).toContain(oid);
			expect(accountId).not.toBe("pairwise-sub-link-1313");
		} else {
			expect(res.error).toBeTruthy();
			expect(accounts).toHaveLength(0);
		}
	}, 60_000);
});

describe("link_only_with_oid_generic", () => {
	it.each([
		["has an oid", "stable-oid-llll1414", true],
		["has no oid", undefined, false],
	])("attaches a sign-in to the existing user with that email only when the token %s", async (_label, oid, linked) => {
		const email = "existing-user@example.com";
		const { auth, ctx, signIn, entraAccounts } =
			await createVerifyHelperInstance({
				account: {
					accountLinking: {
						enabled: true,
						trustedProviders: ["microsoft-entra-id"],
					},
				},
			});
		const existing = await auth.api.signUpEmail({
			body: { email, password: "verify-password-1515", name: "Existing User" },
		});
		await ctx.internalAdapter.updateUser(existing.user.id, {
			emailVerified: true,
		});

		const location = await signIn({
			sub: "pairwise-sub-link-1616",
			oid,
			email,
			name: "Existing User",
		});

		const accounts = await entraAccounts();
		if (linked) {
			expect(location).not.toContain("error=");
			expect(accounts).toHaveLength(1);
			expect(accounts[0].userId).toBe(existing.user.id);
			const accountId = await storedProviderAccountId(
				ctx,
				existing.user.id,
				"microsoft-entra-id",
			);
			expect(accountId).toContain(oid);
			expect(accountId).not.toBe("pairwise-sub-link-1616");
		} else {
			expect(location).toContain("error=");
			expect(accounts).toHaveLength(0);
		}
	}, 60_000);
});
