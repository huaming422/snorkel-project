#!/usr/bin/env bash
# test-setup.sh is the environment bootstrap for the verifier.
#
# Sourced (not exec'd) by the harbor runner so env vars set here stay live for
# the vitest subprocess. Idempotent.
#
# Why rebuilds are needed: the BUILT-IN microsoft provider is imported by tests
# through `@better-auth/core/social-providers`, whose package export resolves to
# the BUILT `dist/`, NOT raw `src/`; the root vitest config's dev-source SSR
# condition is not inherited by the per-package `defineProject` configs
# (verified empirically; see repo notes). dist/ was pre-built at the starting
# commit in the image, so it is STALE after the agent edits `packages/core/src`.
# We rebuild @better-auth/core (and the main package it feeds) so the verifier
# tests the agent's actual code. Turbo input-hashing makes an unchanged rebuild
# a few seconds.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/better-auth}"
export REPO_DIR
cd "$REPO_DIR"

node --version
pnpm --version

# Install workspace deps if missing (offline replay of the baked store;
# the image already installed the frozen closure at the base commit).
if [ ! -d "node_modules/.pnpm" ]; then
    echo "[test-setup] pnpm install (offline, frozen)..."
    pnpm install --frozen-lockfile --ignore-scripts --offline
fi

# verify.toml is read by harbor's runners/js.py under VERIFIER_PYTHON
# (the canonical /opt/tooling venv, Python 3.12), whose stdlib has `tomllib` and
# no `tomli` backfill is needed here.

# ALWAYS rebuild @better-auth/core + the main package so dist/ reflects the
# agent's edits to the built-in microsoft provider and any shared types the
# generic-oauth helper consumes.
echo "[test-setup] rebuilding affected workspace packages (picks up agent edits)..."
pnpm --filter @better-auth/core \
     --filter better-auth \
     build

# Build the rest of the workspace if any dist is missing (covers a fresh
# node_modules after an agent reinstall).
need_build=0
for pkg_json in packages/*/package.json; do
    pkg_dir=$(dirname "$pkg_json")
    if [ ! -d "$pkg_dir/dist" ] && [ -f "$pkg_dir/tsconfig.json" ]; then
        need_build=1
        break
    fi
done
if [ "$need_build" = "1" ]; then
    echo "[test-setup] building all workspace packages..."
    pnpm build
fi

# Rebuild better-sqlite3 native binding if missing (an agent pnpm install can
# erase the binary getTestInstance's in-memory SQLite relies on).
if ! ls node_modules/.pnpm/better-sqlite3*/node_modules/better-sqlite3/build/Release/better_sqlite3.node >/dev/null 2>&1; then
    echo "[test-setup] rebuilding better-sqlite3..."
    pnpm --filter better-auth rebuild better-sqlite3 || true
fi

export PATH="$REPO_DIR/node_modules/.bin:$PATH"

echo "[test-setup] ready: REPO_DIR=$REPO_DIR node=$(node --version) vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
