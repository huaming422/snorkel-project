#!/usr/bin/env bash
# test-setup.sh — sourced before the Go verifier runs.
#
# This task's entire dependency closure is baked into the image at build time
# (block 5 warms the module cache from the authoring commit; block 7 downloads
# this base commit's modules and compiles the full unit-test tree with
# CGO_ENABLED=1). The agent phase runs with no network, so there is nothing to
# install here — this script only exports the build environment the verifier's
# `go test` invocation needs and does a fast offline sanity compile of the
# package under test so a broken edit surfaces here rather than mid-verifier.
#
# Sourced (not exec'd) by the harbor runner, so the exports below stay live for
# the verifier subprocess.
set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/beads}"
export REPO_DIR
cd "$REPO_DIR"

# The repo's tests build with the pure-Go go-mysql-server engine (no CGO, no
# ICU) — the Makefile pins BUILD_TAGS := gms_pure_go. Keep the toolchain pinned
# to the baked Go (no network toolchain download) and the module cache offline.
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"
export GOFLAGS="${GOFLAGS:--mod=mod}"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"
export CGO_ENABLED="${CGO_ENABLED:-0}"

# Offline sanity: compile (vet-free, no run) the package the verifier exercises.
# -run '^$' matches no test, so this just proves cmd/bd and its test files still
# build against the agent's edits using the baked module cache.
echo "test-setup: offline compile check of ./cmd/bd (tags gms_pure_go)..."
if ! go test -tags gms_pure_go -count=1 -run '^$' ./cmd/bd > /tmp/test-setup-build.log 2>&1; then
    echo "test-setup: ./cmd/bd failed to compile — see below" >&2
    tail -60 /tmp/test-setup-build.log >&2
    exit 1
fi

echo "test-setup: ready. REPO_DIR=$REPO_DIR go=$(go version 2>/dev/null | awk '{print $3}')"
