// Behavioral checks for which Dolt server port the two server-clone callers
// dial, driven through the stable in-package entry points cloneFromRemote
// (the `bd bootstrap` auto path) and cloneFromRemoteWithMode (the general
// path, here with the `bd init --server --external` clone mode).
//
// The idea is the one from the issue: a workspace can name its server port in
// more than one place, and when two places disagree the clone can land on a
// different server than the commands that run afterward. We stage exactly that
// disagreement — a workspace config file naming one port and a legacy
// environment variable naming another — point the clone at ports with nothing
// listening, and read which port the "dolt server unreachable at host:port"
// error names. That port is the one the clone actually dialed, with no live
// server required.
//
// This file is self-contained on purpose: it brings its own environment
// isolation and config helpers and its own closed-port allocator, so it does
// not depend on any other test file in the package and compiles with the
// repository's pure-Go tag and CGO disabled.
package main

import (
	"fmt"
	"net"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"testing"

	"github.com/steveyegge/beads/internal/config"
	"github.com/steveyegge/beads/internal/configfile"
)

// isolateCloneEndpointEnv clears every variable that names a Dolt server
// endpoint, its credentials or its mode, and isolates HOME (the shared-server
// directory, user config and credentials file all live there), so only what
// the test writes chooses the endpoint. The config singleton is reset before
// and after the test.
func isolateCloneEndpointEnv(t *testing.T) {
	t.Helper()
	home := t.TempDir()
	t.Setenv("HOME", home)
	t.Setenv("USERPROFILE", home)
	t.Setenv("XDG_CONFIG_HOME", filepath.Join(home, ".config"))
	t.Setenv("BEADS_SHARED_SERVER_DIR", filepath.Join(home, "shared-server"))
	for _, name := range []string{
		"BEADS_DOLT_SERVER_MODE", "BEADS_DOLT_SHARED_SERVER", "BEADS_DOLT_SERVER_HOST",
		"BEADS_DOLT_SERVER_PORT", "BEADS_DOLT_PORT", "BEADS_DOLT_SERVER_SOCKET",
		"BEADS_DOLT_DATA_DIR", "BEADS_DOLT_SERVER_DATABASE", "BEADS_DOLT_SERVER_USER",
		"BEADS_DOLT_SERVER_TLS", "BEADS_DOLT_PASSWORD", "BEADS_CREDENTIALS_FILE",
		"BD_DOLT_PORT", "BD_DOLT_SHARED_SERVER", "BD_DOLT_HOST", "BD_DOLT_MODE",
	} {
		t.Setenv(name, "")
	}
	config.ResetForTesting()
	t.Cleanup(config.ResetForTesting)
}

// writeConfigFile writes body to path, creating parent directories.
func writeConfigFile(t *testing.T, path, body string) {
	t.Helper()
	if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, []byte(body), 0o600); err != nil {
		t.Fatal(err)
	}
}

// loadWorkspaceConfig makes beadsDir's config.yaml the one the store reads its
// port from, exactly as a command running in that workspace loads it.
func loadWorkspaceConfig(t *testing.T, beadsDir string) {
	t.Helper()
	t.Setenv("BEADS_DIR", beadsDir)
	config.ResetForTesting()
	if err := config.Initialize(); err != nil {
		t.Fatalf("config.Initialize: %v", err)
	}
}

// refusedLoopbackPort returns a loopback TCP port that is allocated and then
// immediately closed, so a dial against it fails fast with connection refused
// instead of reaching a live server.
func refusedLoopbackPort(t *testing.T) int {
	t.Helper()
	l, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("allocate loopback port: %v", err)
	}
	port := l.Addr().(*net.TCPAddr).Port
	if err := l.Close(); err != nil {
		t.Fatalf("close loopback port: %v", err)
	}
	return port
}

// stageDisagreeingWorkspace builds a server-mode workspace whose port is named
// two ways that disagree: the workspace config file names configured, and the
// legacy BEADS_DOLT_PORT environment variable names legacy. Both ports are
// closed, so whichever one a clone dials fails fast and names itself in the
// error. The returned cfg is what bootstrap carries into the clone; it names
// the server host but no port of its own, so the port comes entirely from the
// two staged sources.
func stageDisagreeingWorkspace(t *testing.T) (beadsDir string, configured, legacy int, cfg *configfile.Config) {
	t.Helper()
	isolateCloneEndpointEnv(t)

	configured = refusedLoopbackPort(t)
	legacy = refusedLoopbackPort(t)
	for legacy == configured {
		legacy = refusedLoopbackPort(t)
	}
	t.Setenv("BEADS_DOLT_PORT", strconv.Itoa(legacy))

	beadsDir = filepath.Join(t.TempDir(), ".beads")
	writeConfigFile(t, filepath.Join(beadsDir, "config.yaml"), fmt.Sprintf("dolt.port: %d\n", configured))

	cfg = &configfile.Config{
		Backend:        configfile.BackendDolt,
		DoltMode:       configfile.DoltModeServer,
		DoltServerHost: "127.0.0.1",
		DoltDatabase:   "clone_port",
	}
	if err := cfg.Save(beadsDir); err != nil {
		t.Fatal(err)
	}
	loadWorkspaceConfig(t, beadsDir)
	return beadsDir, configured, legacy, cfg
}

// unreachableWant is the substring the clone's connection-refused error carries
// when it dialed 127.0.0.1:port.
func unreachableWant(port int) string {
	return "dolt server unreachable at " + net.JoinHostPort("127.0.0.1", strconv.Itoa(port))
}

const nonexistentRemote = "file:///nonexistent/remote"

// TestVerifyBootstrapClonesThroughDialConfigPort pins the port the `bd
// bootstrap` auto clone dials when the workspace config file and the legacy
// environment variable name different ports. Later commands in this workspace
// connect on the config file's port, so a bootstrap that reports success must
// have cloned there too — otherwise it lands on one server and the next command
// looks at another. The clone must dial the config file's port; dialing the
// legacy environment port instead is the reported failure.
func TestVerifyBootstrapClonesThroughDialConfigPort(t *testing.T) {
	beadsDir, configured, _, cfg := stageDisagreeingWorkspace(t)

	err := cloneFromRemote(t.Context(), beadsDir, nonexistentRemote, "clone_port", cfg)
	if err == nil {
		t.Fatal("clone succeeded with no server running")
	}
	if want := unreachableWant(configured); !strings.Contains(err.Error(), want) {
		t.Errorf("bootstrap clone error = %v, want it to name %s (the port later commands dial)", err, want)
	}
}

// TestVerifyInitCloneKeepsLegacyPortOrder pins the port the `bd init --server
// --external` clone dials for the same disagreeing workspace. That path opens
// its own store with the environment-first order immediately after cloning, so
// its clone follows that order and stays on the legacy environment port — a
// deliberately different resolution than the auto bootstrap path. A change that
// routes both callers through the same workspace rule would move this clone to
// the config file's port and break init; this holds it on the legacy port.
func TestVerifyInitCloneKeepsLegacyPortOrder(t *testing.T) {
	beadsDir, _, legacy, _ := stageDisagreeingWorkspace(t)

	initCfg := initTimeCloneConfig(true /*serverMode*/, "" /*host*/, 0 /*port*/, "" /*socket*/, "" /*user*/, "clone_port")
	err := cloneFromRemoteWithMode(t.Context(), beadsDir, nonexistentRemote, "clone_port", initCfg, remoteCloneExternalServer)
	if err == nil {
		t.Fatal("clone succeeded with no server running")
	}
	if want := unreachableWant(legacy); !strings.Contains(err.Error(), want) {
		t.Errorf("init clone error = %v, want it to name %s (its own environment-first port)", err, want)
	}
}
