## Task

Cloning a server-mode workspace with `bd bootstrap` prints a success line and
exits 0, but the very next `bd` command (`bd list`, say) turns around and fails,
claiming the database isn't there or can't be found on the server. It's not
consistent: some workspace setups hit it and others sail through, and a
workspace that only configures its server in one place never trips it. Cloning
the same workspace the `bd init` way doesn't reproduce it at all. Right before
bootstrap exits there's a non-fatal warning about the post-clone step, easy to
wave off.

The ordinary commands are already landing in the right place, so a bootstrap
that reports success should clone into that same server and be immediately
usable by everything else. Dig in and fix it.
