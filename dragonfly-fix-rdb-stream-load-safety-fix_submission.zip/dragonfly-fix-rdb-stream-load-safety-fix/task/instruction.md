## Task

We've got a nasty one in the serialized-value loader. Clients load a serialized value into a key with RESTORE, and we also load serialized data on startup from a snapshot and from a master during replication. Some crafted stream values, malformed or inconsistent but still decodable enough to reach the loader, take the server down when we load them. Others slip through and leave the key in a broken, memory-unsafe state that faults on a later operation.

It takes almost nothing to hit: a single RESTORE of the bad value does it, so any client that can reach the server can trigger it, including on the default config where we require no auth. A hostile master can push the same thing over replication.

I want loading a stream value to reject malformed or inconsistent stream data cleanly: the server stays up and we never store a corrupt key. Well-formed streams keep loading and behaving exactly as they do now, including ones with consumer groups and ones whose entries don't all share the same field set.

The fix belongs in how we validate and assemble a stream value as it loads, not in the commands that read a stream afterward, and not in refusing stream RESTORE or snapshot loading wholesale. Loading of everything else well-formed stays untouched.

To repro: source at `/repo/dragonfly`, built binary at `/repo/dragonfly/build-dbg/dragonfly` (also on PATH as `dragonfly` and `$DRAGONFLY_PATH`). `cd /repo/dragonfly/build-dbg && ninja dragonfly` rebuilds in under a minute. The repo's C++ unit tests for the load path live under `src/server/`.
