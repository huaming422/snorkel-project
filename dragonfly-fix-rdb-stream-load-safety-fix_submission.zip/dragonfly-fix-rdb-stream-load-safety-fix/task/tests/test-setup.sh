#!/usr/bin/env bash
# test-setup.sh — sourced before the verifier runs.
#
# Performs the incremental rebuild after the agent's edits. The image pre-built
# dragonfly at /repo/dragonfly/build-dbg/dragonfly (with ccache populated), so
# this incremental rebuild typically completes in under a minute even with
# several .cc edits.
set -euo pipefail

cd /repo/dragonfly

# Ensure ccache is on the compiler PATH for incremental rebuilds. /usr/lib/ccache
# contains symlinked compilers (gcc, g++, cc, c++) that transparently dispatch
# to ccache.
export PATH="/usr/lib/ccache:${PATH}"
export CCACHE_DIR="${CCACHE_DIR:-/var/cache/ccache}"

# Incremental rebuild: ninja recomputes the dependency graph and rebuilds only
# the translation units the agent touched, then re-links the dragonfly binary.
echo "test-setup: incremental rebuild of dragonfly..."
( cd build-dbg && ninja dragonfly )

# Verify the binary still exists and runs. A fatal compile error would have
# killed the ninja invocation above; this is a belt-and-suspenders check that
# the link succeeded.
if [ ! -x build-dbg/dragonfly ]; then
    echo "test-setup: build-dbg/dragonfly missing or non-executable" >&2
    exit 1
fi
build-dbg/dragonfly --version || {
    echo "test-setup: dragonfly binary failed --version check" >&2
    exit 1
}

# Re-export DRAGONFLY_PATH (in case the verifier env doesn't inherit the
# image-time ENV setting) and refresh the convenience symlink.
export DRAGONFLY_PATH="/repo/dragonfly/build-dbg/dragonfly"
ln -sf "$DRAGONFLY_PATH" /usr/local/bin/dragonfly

echo "test-setup: ready."
