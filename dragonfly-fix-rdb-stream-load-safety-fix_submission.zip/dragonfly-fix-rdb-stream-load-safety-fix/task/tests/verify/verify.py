"""Behavioral verifier for dragonfly-fix-rdb-stream-load-safety.

Tests through the pre-existing RESP TCP server — the highest-level public
surface on which the defect is observable. The verifier is implementation-
agnostic: it spawns the dragonfly binary on a free port, opens a raw socket,
and drives it with hand-encoded RESP. It inspects only replies and server
liveness, so it is blind to C++ identifiers, file layout, and the internal
structure of any fix. Any load-time hardening that rejects the inconsistent
serialized stream values and keeps loading the well-formed ones passes,
regardless of where the fix lives or what it is named.

A serialized value handed to RESTORE is fed straight into the loader with
full integrity checking. The malformed-stream cases build such a value by
hand (mirroring the serialization the server itself emits) so that it is
structurally decodable yet internally inconsistent. The positive controls
build their values the honest way: XADD / XGROUP then DUMP, and RESTORE the
dump back.

The verifier imports only the Python standard library plus pytest, so it runs
directly under the canonical verifier interpreter with no repository code on
the path.

Expected behavior (per malformed case):
  * post-fix: RESTORE replies an error, the key is not created (EXISTS -> 0),
    and the server still answers PING on a fresh connection.
  * pre-fix (accepted corruption): RESTORE replies +OK and EXISTS -> 1.
  * pre-fix (crash): the walk runs off the end during the load and the server
    process dies; the fresh-connection PING fails.
Each spawns its own server so a crash in one case cannot bleed into another.
"""

from __future__ import annotations

import os
import socket
import struct
import subprocess
import time

import pytest


DRAGONFLY_BINARY = os.environ.get(
    "DRAGONFLY_PATH", "/repo/dragonfly/build-dbg/dragonfly"
)
HOST = "127.0.0.1"


# ── RDB / listpack serialization (stable repo format constants) ─────────────
# Every constant below is fixed by the on-disk RDB and listpack formats the
# server reads; none is a choice a fix could change. Sources in the repo:
#   RDB_TYPE_STREAM_LISTPACKS=15, RDB_SER_VERSION=9, length-encoding bit tags
#   (src/redis/rdb.h); CRC64-jones poly + reflected table, vector
#   crc64("123456789")==0xe9c6d914c4b8d9ca (src/redis/crc64.c); listpack
#   header LP_HDR_SIZE=6 / LP_EOF=0xFF and integer encodings
#   (src/redis/listpack.c); stream item flags (src/redis/stream.h).

RDB_TYPE_STREAM_LISTPACKS = 15
RDB_SER_VERSION = 9

STREAM_ITEM_FLAG_DELETED = 1
STREAM_ITEM_FLAG_SAMEFIELDS = 2


def _append_len(out: bytearray, value: int) -> None:
    """Packed unsigned length, mirroring WritePackedUInt (big-endian tags)."""
    if value < (1 << 6):
        out.append(value & 0xFF)  # RDB_6BITLEN
    elif value < (1 << 14):
        out.append(((value >> 8) & 0xFF) | (1 << 6))  # RDB_14BITLEN
        out.append(value & 0xFF)
    elif value <= 0xFFFFFFFF:
        out.append(0x80)  # RDB_32BITLEN
        out += struct.pack(">I", value)
    else:
        out.append(0x81)  # RDB_64BITLEN
        out += struct.pack(">Q", value)


def _append_string(out: bytearray, data: bytes) -> None:
    _append_len(out, len(data))
    out += data


# CRC64-jones: reflected, init 0, no final xor (matches src/redis/crc64.c).
def _crc64_table() -> list[int]:
    poly = 0x95AC9329AC4BC9B5  # reflect(0xad93d23594c935a9, 64)
    table = []
    for n in range(256):
        c = n
        for _ in range(8):
            c = (c >> 1) ^ poly if (c & 1) else (c >> 1)
        table.append(c & 0xFFFFFFFFFFFFFFFF)
    return table


_CRC64_TABLE = _crc64_table()


def _crc64(data: bytes, crc: int = 0) -> int:
    for b in data:
        crc = _CRC64_TABLE[(crc ^ b) & 0xFF] ^ (crc >> 8)
        crc &= 0xFFFFFFFFFFFFFFFF
    return crc


def _wrap_dump_footer(body: bytes) -> bytes:
    """Append the DUMP footer: 2-byte LE version + 8-byte LE CRC64."""
    out = bytearray(body)
    out += struct.pack("<H", RDB_SER_VERSION)
    out += struct.pack("<Q", _crc64(bytes(out)))
    return bytes(out)


# ── Minimal listpack encoder (integers only — enough for stream headers) ────

def _lp_encode_integer(v: int) -> bytes:
    """Element bytes for an integer, mirroring lpEncodeIntegerGetType +
    the trailing back-length. The back-length encodes the element-encoding
    byte count (not counting the back-length itself)."""
    if 0 <= v <= 127:
        enc = bytes([v])
    elif -4096 <= v <= 4095:
        u = v + (1 << 13) if v < 0 else v
        enc = bytes([(u >> 8) | 0xC0, u & 0xFF])  # LP_ENCODING_13BIT_INT
    elif -32768 <= v <= 32767:
        u = v + (1 << 16) if v < 0 else v
        enc = bytes([0xF1, u & 0xFF, (u >> 8) & 0xFF])  # 16BIT
    elif -8388608 <= v <= 8388607:
        u = v + (1 << 24) if v < 0 else v
        enc = bytes([0xF2, u & 0xFF, (u >> 8) & 0xFF, (u >> 16) & 0xFF])  # 24BIT
    elif -2147483648 <= v <= 2147483647:
        u = v + (1 << 32) if v < 0 else v
        enc = bytes([0xF3, u & 0xFF, (u >> 8) & 0xFF, (u >> 16) & 0xFF, (u >> 24) & 0xFF])  # 32BIT
    else:
        u = v & 0xFFFFFFFFFFFFFFFF
        enc = bytes([0xF4]) + struct.pack("<Q", u)  # 64BIT
    return enc + _lp_encode_backlen(len(enc))


def _lp_encode_backlen(length: int) -> bytes:
    """Variable-length back-pointer, mirroring lpEncodeBacklen (7 bits/byte,
    high bit set on all but the most-significant, big-endian order)."""
    if length <= 127:
        return bytes([length])
    if length < 16383:
        return bytes([length >> 7, (length & 127) | 128])
    if length < 2097151:
        return bytes([length >> 14, ((length >> 7) & 127) | 128, (length & 127) | 128])
    if length < 268435455:
        return bytes([
            length >> 21,
            ((length >> 14) & 127) | 128,
            ((length >> 7) & 127) | 128,
            (length & 127) | 128,
        ])
    return bytes([
        length >> 28,
        ((length >> 21) & 127) | 128,
        ((length >> 14) & 127) | 128,
        ((length >> 7) & 127) | 128,
        (length & 127) | 128,
    ])


def _build_listpack(integers: list[int]) -> bytes:
    """A listpack whose elements are the given integers. Header is a 32-bit LE
    total-byte count, a 16-bit LE element count, then the elements, then LP_EOF.
    (LP_HDR_SIZE = 6.)"""
    body = bytearray()
    for v in integers:
        body += _lp_encode_integer(v)
    total = 6 + len(body) + 1  # header + body + LP_EOF
    out = bytearray()
    out += struct.pack("<I", total)
    out += struct.pack("<H", len(integers) & 0xFFFF)
    out += body
    out.append(0xFF)  # LP_EOF
    return bytes(out)


# ── Stream DUMP payload builders ────────────────────────────────────────────

def _build_cgroup_stream_dump(global_pel, consumers) -> bytes:
    """Stream value with an empty body and one consumer group whose global PEL
    and per-consumer PELs are exactly as given. ``global_pel`` is a list of
    16-byte ids; ``consumers`` is a list of (name, [16-byte ids]).

    Mirrors the serialization the loader reads: empty stream body, then the
    consumer-group block (name, last id, global PEL entries each with a
    delivery time + count, then consumers each with a seen time + their PEL
    id list)."""
    p = bytearray()
    p.append(RDB_TYPE_STREAM_LISTPACKS)
    _append_len(p, 0)  # listpack node count: empty body
    _append_len(p, 0)  # stream_len
    _append_len(p, 0)  # last_id.ms
    _append_len(p, 0)  # last_id.seq

    _append_len(p, 1)  # one consumer group
    _append_string(p, b"g")  # group name
    _append_len(p, 0)  # group last_id.ms
    _append_len(p, 0)  # group last_id.seq

    _append_len(p, len(global_pel))
    for pid in global_pel:
        p += pid  # 16 raw id bytes
        p += struct.pack("<Q", 0)  # delivery_time
        _append_len(p, 0)  # delivery_count

    _append_len(p, len(consumers))
    for name, pel in consumers:
        _append_string(p, name)
        p += struct.pack("<Q", 0)  # seen_time
        _append_len(p, len(pel))
        for pid in pel:
            p += pid

    return _wrap_dump_footer(bytes(p))


def _build_listpack_stream_dump(count, deleted, num_master_fields, record_flags=None) -> bytes:
    """One-node stream whose master-entry listpack declares the given counts.
    When ``record_flags`` is set, a single record (no fields) is appended so
    the declared deleted-count can be made to disagree with the flags present.
    Mirrors the master-entry listpack layout:
    [valid-count, deleted-count, num-master-fields, 0 terminator, ...records]."""
    ints = [count, deleted, num_master_fields, 0]
    if record_flags is not None:
        assert num_master_fields == 0
        ints += [record_flags, 0, 0, 3]  # flags, ms delta, seq delta, lp-count
    lp_blob = _build_listpack(ints)

    p = bytearray()
    p.append(RDB_TYPE_STREAM_LISTPACKS)
    _append_len(p, 1)  # one listpack node
    _append_string(p, b"\x01" * 16)  # 16-byte master id
    _append_string(p, lp_blob)
    _append_len(p, 0)  # stream_len
    _append_len(p, 0)  # last_id.ms
    _append_len(p, 0)  # last_id.seq
    _append_len(p, 0)  # consumer-group count

    return _wrap_dump_footer(bytes(p))


# ── RESP encoding + dragonfly process helpers ───────────────────────────────

def _encode_resp(*args: object) -> bytes:
    """Encode an array of bulk strings. ``bytes`` args pass through verbatim so
    binary DUMP payloads survive intact."""
    parts = []
    for a in args:
        parts.append(a if isinstance(a, (bytes, bytearray)) else str(a).encode())
    header = f"*{len(parts)}\r\n".encode()
    body = b"".join(b"$" + str(len(a)).encode() + b"\r\n" + bytes(a) + b"\r\n" for a in parts)
    return header + body


def _pick_free_port() -> int:
    s = socket.socket()
    try:
        s.bind(("", 0))
        return s.getsockname()[1]
    finally:
        s.close()


def _wait_until_listening(port: int, *, timeout_sec: float = 20.0) -> None:
    """Poll until dragonfly accepts a connection AND answers PING with PONG
    (dragonfly replies -LOADING to commands until its dataset load finishes)."""
    ping = b"*1\r\n$4\r\nPING\r\n"
    deadline = time.monotonic() + timeout_sec
    while time.monotonic() < deadline:
        try:
            s = socket.socket()
            s.settimeout(0.5)
            s.connect((HOST, port))
        except OSError:
            time.sleep(0.05)
            continue
        try:
            s.sendall(ping)
            s.settimeout(1.0)
            if s.recv(64).startswith(b"+PONG\r\n"):
                s.close()
                return
        except OSError:
            pass
        finally:
            try:
                s.close()
            except OSError:
                pass
        time.sleep(0.05)
    raise RuntimeError(
        f"dragonfly did not become command-ready on port {port} within {timeout_sec}s"
    )


def _spawn_dragonfly(port: int) -> subprocess.Popen:
    if not os.path.isfile(DRAGONFLY_BINARY) or not os.access(DRAGONFLY_BINARY, os.X_OK):
        raise RuntimeError(f"dragonfly binary missing or not executable at {DRAGONFLY_BINARY}")
    proc = subprocess.Popen(
        [
            DRAGONFLY_BINARY,
            f"--port={port}",
            "--proactor_threads=2",
            "--logtostderr",
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    try:
        _wait_until_listening(port)
    except Exception:
        _kill(proc)
        raise
    return proc


def _kill(proc: subprocess.Popen, *, timeout_sec: float = 5.0) -> None:
    if proc.poll() is not None:
        return
    proc.terminate()
    try:
        proc.wait(timeout=timeout_sec)
    except subprocess.TimeoutExpired:
        proc.kill()
        try:
            proc.wait(timeout=timeout_sec)
        except subprocess.TimeoutExpired:
            pass


@pytest.fixture
def dragonfly_port():
    port = _pick_free_port()
    proc = _spawn_dragonfly(port)
    try:
        yield port
    finally:
        _kill(proc)


def _read_reply(sock: socket.socket) -> bytes:
    """Read one complete RESP reply. Handles the reply types this verifier
    uses: simple string (+), error (-), integer (:), and bulk string ($),
    including a bulk payload (DUMP output) split across TCP segments or
    containing CRLF bytes."""
    buf = bytearray()

    def _recv_line() -> bytes:
        # Accumulate until the next CRLF; return the bytes up to and incl. it.
        while b"\r\n" not in bytes(buf):
            chunk = sock.recv(65536)
            if not chunk:
                return bytes(buf)
            buf.extend(chunk)
        idx = bytes(buf).index(b"\r\n") + 2
        line = bytes(buf[:idx])
        del buf[:idx]
        return line

    first = _recv_line()
    if not first or first[:1] != b"$":
        return first
    try:
        length = int(first[1:].strip())
    except ValueError:
        return first
    if length < 0:  # null bulk string ($-1)
        return first
    need = length + 2  # payload + trailing CRLF
    while len(buf) < need:
        chunk = sock.recv(65536)
        if not chunk:
            break
        buf.extend(chunk)
    return first + bytes(buf[:need])


def _command(port: int, *args: object, timeout_sec: float = 5.0) -> bytes:
    """Open a fresh connection, send one command, return the full reply.

    A fresh connection per command is deliberate: a malformed load may have
    crashed the server or dropped the prior connection, and a brand-new
    connect is the cleanest liveness probe."""
    s = socket.socket()
    s.settimeout(timeout_sec)
    s.connect((HOST, port))
    try:
        s.sendall(_encode_resp(*args))
        return _read_reply(s)
    finally:
        try:
            s.close()
        except OSError:
            pass


def _server_alive(port: int) -> bool:
    """A fresh-connection PING -> PONG proves the process survived the load."""
    try:
        return _command(port, "PING").startswith(b"+PONG\r\n")
    except OSError:
        return False


def _restore_is_rejected(port: int, key: str, payload: bytes) -> tuple[bool, bytes, bytes, bool]:
    """Drive one malformed RESTORE. Returns (rejected, restore_reply,
    exists_reply, alive). ``rejected`` is the full post-fix contract: the
    RESTORE reply is not +OK, the key is absent, and the server is still up."""
    try:
        restore_reply = _command(port, "RESTORE", key, "0", payload)
    except OSError as exc:
        # The connection dropped mid-RESTORE: the load crashed the server. That
        # is the pre-fix failure mode, so it is NOT a clean rejection.
        return (False, f"<connection error: {exc}>".encode(), b"<n/a>", _server_alive(port))

    alive = _server_alive(port)
    if not alive:
        return (False, restore_reply, b"<server down>", False)

    exists_reply = _command(port, "EXISTS", key)
    is_error = not restore_reply.startswith(b"+OK\r\n")
    not_created = exists_reply.startswith(b":0\r\n")
    return (is_error and not_created, restore_reply, exists_reply, alive)


# A 16-byte stream id, raw bytes as stored in the PEL.
_ID_A = b"A" * 16
_ID_B = b"B" * 16


# ── fail_to_pass: malformed stream values must be rejected on load ──────────

def test_pel_shared_entry_rejected(dragonfly_port: int):
    """Two consumers both claim the same global-PEL entry. A vulnerable loader
    accepts it and shares one bookkeeping structure across both consumer PELs,
    double-freeing it on teardown. The fix must reject it at load."""
    payload = _build_cgroup_stream_dump([_ID_A], [(b"c1", [_ID_A]), (b"c2", [_ID_A])])
    rejected, restore, exists, alive = _restore_is_rejected(dragonfly_port, "shared", payload)
    assert rejected, (
        f"shared-PEL-entry stream was not safely rejected: "
        f"RESTORE reply={restore!r} EXISTS={exists!r} server_alive={alive}"
    )


def test_pel_unclaimed_entry_rejected(dragonfly_port: int):
    """A global-PEL entry that no consumer claims leaves a dangling owner
    pointer for later stream commands to dereference. Reject it at load."""
    payload = _build_cgroup_stream_dump([_ID_A], [(b"c1", [])])
    rejected, restore, exists, alive = _restore_is_rejected(dragonfly_port, "unclaimed", payload)
    assert rejected, (
        f"unclaimed-PEL-entry stream was not safely rejected: "
        f"RESTORE reply={restore!r} EXISTS={exists!r} server_alive={alive}"
    )


def test_listpack_fieldcount_overflow_rejected(dragonfly_port: int):
    """The master entry declares far more fields than the listpack holds. A
    vulnerable loader walks off the end during stream iteration and crashes.
    The fix must reject it, and the server must survive."""
    payload = _build_listpack_stream_dump(0, 0, 1000)
    rejected, restore, exists, alive = _restore_is_rejected(dragonfly_port, "overflow", payload)
    assert alive, (
        f"server did not survive loading a stream with an inflated field count "
        f"(it crashed during the load): RESTORE reply={restore!r}"
    )
    assert rejected, (
        f"inflated-field-count stream was not safely rejected: "
        f"RESTORE reply={restore!r} EXISTS={exists!r} server_alive={alive}"
    )


def test_listpack_sum_overflow_rejected(dragonfly_port: int):
    """The declared valid + deleted record counts are chosen so their signed
    sum overflows. A fix that sums them as a signed value wraps negative and
    skips validation entirely; a correct fix rejects the value."""
    payload = _build_listpack_stream_dump((1 << 63) - 1, 1, 0)
    rejected, restore, exists, alive = _restore_is_rejected(dragonfly_port, "sumovf", payload)
    assert alive, (
        f"server did not survive loading a stream with overflowing counts: "
        f"RESTORE reply={restore!r}"
    )
    assert rejected, (
        f"count-sum-overflow stream was not safely rejected: "
        f"RESTORE reply={restore!r} EXISTS={exists!r} server_alive={alive}"
    )


def test_listpack_deleted_mismatch_rejected(dragonfly_port: int):
    """The master entry declares zero deleted records, but the one record
    present carries the deleted flag. The counts disagree; reject the value."""
    payload = _build_listpack_stream_dump(
        1, 0, 0, record_flags=STREAM_ITEM_FLAG_SAMEFIELDS | STREAM_ITEM_FLAG_DELETED
    )
    rejected, restore, exists, alive = _restore_is_rejected(
        dragonfly_port, "deleted-mismatch", payload
    )
    assert alive, (
        f"server did not survive loading a stream with a deleted-count "
        f"mismatch: RESTORE reply={restore!r}"
    )
    assert rejected, (
        f"deleted-count-mismatch stream was not safely rejected: "
        f"RESTORE reply={restore!r} EXISTS={exists!r} server_alive={alive}"
    )


# ── fail_to_pass: validation must also run on the non-deep file-load path ────
#
# RESTORE loads a client-supplied value with full ("deep") integrity checking.
# A snapshot read at startup — and a stream pushed by a master over replication
# — loads WITHOUT the deep flag, yet both are reachable by an attacker on a
# no-authentication deployment. A fix that only tightens the deep/RESTORE path
# leaves these paths exposed. This case drives a load through the file path by
# writing a crafted RDB snapshot to disk and pointing a fresh server at it, so
# it is blind to the deep flag and only a fix that validates on every load path
# passes it. The payload is the deterministic deleted-count-mismatch value (the
# shallow check accepts and STORES it); the inflated-field-count value is avoided
# here because its out-of-bounds walk crashes only intermittently on this path.


def _build_rdb_snapshot_file(dump_payload: bytes, key: str) -> bytes:
    """Wrap a stream value (the body of a DUMP payload) in a minimal legacy RDB
    file: the ``REDIS<ver>`` magic, a SELECTDB-0 opcode, one key/value pair, the
    EOF opcode, and the 8-byte trailing checksum. The DUMP payload is the object
    type byte, the serialized body, and a 10-byte footer (2-byte version +
    8-byte CRC); the RDB file reuses the type byte and body and supplies its own
    key string and file-level footer. The loader's checksum step reads but does
    not verify the trailing 8 bytes, so a zero checksum loads."""
    type_byte = dump_payload[0:1]
    body = dump_payload[1:-10]  # strip the DUMP type byte and 10-byte footer
    obj = bytearray()
    obj += type_byte
    _append_string(obj, key.encode())
    obj += body

    out = bytearray()
    out += b"REDIS%04d" % RDB_SER_VERSION  # magic + version, e.g. b"REDIS0009"
    out += b"\xfe\x00"                      # RDB_OPCODE_SELECTDB, db 0
    out += obj
    out += b"\xff"                          # RDB_OPCODE_EOF
    out += b"\x00" * 8                      # trailing checksum (read, not verified)
    return bytes(out)


def _spawn_dragonfly_with_snapshot(port: int, directory: str, dbfilename: str) -> subprocess.Popen:
    """Spawn a server that loads a snapshot from disk at startup. ``--dir`` +
    ``--dbfilename`` point it at the crafted file; the legacy RDB format is
    selected so the hand-built REDIS-magic file is the one that gets read."""
    if not os.path.isfile(DRAGONFLY_BINARY) or not os.access(DRAGONFLY_BINARY, os.X_OK):
        raise RuntimeError(f"dragonfly binary missing or not executable at {DRAGONFLY_BINARY}")
    return subprocess.Popen(
        [
            DRAGONFLY_BINARY,
            f"--port={port}",
            "--proactor_threads=2",
            f"--dir={directory}",
            f"--dbfilename={dbfilename}",
            "--df_snapshot_format=false",
            "--logtostderr",
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def _wait_until_loaded(port: int, key: str, *, timeout_sec: float = 30.0) -> bytes:
    """Poll EXISTS until the startup load has finished. While the dataset is
    loading, non-PING commands reply ``-LOADING``; once the load completes
    (whether the crafted value was stored or rejected) the state flips to ACTIVE
    and EXISTS returns an integer. Returns that final EXISTS reply. Raises if the
    load never finishes (or the process died, dropping the connection)."""
    deadline = time.monotonic() + timeout_sec
    last: bytes = b"<no reply>"
    while time.monotonic() < deadline:
        try:
            reply = _command(port, "EXISTS", key)
        except OSError as exc:
            last = f"<connection error: {exc}>".encode()
            time.sleep(0.1)
            continue
        last = reply
        if reply[:1] == b":":  # integer reply -> load finished, state ACTIVE
            return reply
        time.sleep(0.1)
    raise RuntimeError(
        f"dragonfly did not finish loading on port {port} within {timeout_sec}s "
        f"(last EXISTS reply: {last!r})"
    )


def test_nondeep_file_load_path_rejected(tmp_path):
    """The crafted value is loaded through the non-deep snapshot-file path, not
    RESTORE. A fix gated behind the deep/RESTORE integrity flag leaves this path
    unvalidated: the shallow check accepts the deleted-count-mismatch value and
    stores the corrupt key (EXISTS -> 1). A fix that validates on every load path
    rejects it, so the key is never created (EXISTS -> 0), and the server stays
    up either way."""
    key = "nondeep-dm"
    dbfilename = "corrupt.rdb"
    payload = _build_listpack_stream_dump(
        1, 0, 0, record_flags=STREAM_ITEM_FLAG_SAMEFIELDS | STREAM_ITEM_FLAG_DELETED
    )
    (tmp_path / dbfilename).write_bytes(_build_rdb_snapshot_file(payload, key))

    port = _pick_free_port()
    proc = _spawn_dragonfly_with_snapshot(port, str(tmp_path), dbfilename)
    try:
        exists_reply = _wait_until_loaded(port, key)
        alive = _server_alive(port)
    finally:
        _kill(proc)

    assert alive, (
        "server did not survive loading a crafted stream snapshot through the "
        "non-deep file-load path (it crashed during load)"
    )
    assert exists_reply.startswith(b":0\r\n"), (
        "a crafted stream value was stored through the non-deep file-load path: "
        f"the deleted-count-mismatch key was created (EXISTS={exists_reply!r}). "
        "Load-time stream validation must run on every load path, not only the "
        "deep/RESTORE path."
    )


# ── pass_to_pass: well-formed streams must still load and round-trip ────────

def test_wellformed_consumer_group_roundtrips(dragonfly_port: int):
    """A hand-built stream with a valid single-owner consumer group must still
    load: RESTORE replies +OK and the key exists. Also check a two-consumer /
    two-entry group where each entry has exactly one owner."""
    port = dragonfly_port

    one = _build_cgroup_stream_dump([_ID_A], [(b"c1", [_ID_A])])
    reply = _command(port, "RESTORE", "ok1", "0", one)
    assert reply.startswith(b"+OK\r\n"), f"well-formed group rejected: {reply!r}"
    assert _command(port, "EXISTS", "ok1").startswith(b":1\r\n"), "well-formed group key missing"

    two = _build_cgroup_stream_dump([_ID_A, _ID_B], [(b"c1", [_ID_A]), (b"c2", [_ID_B])])
    reply = _command(port, "RESTORE", "ok2", "0", two)
    assert reply.startswith(b"+OK\r\n"), f"well-formed two-consumer group rejected: {reply!r}"
    assert _command(port, "EXISTS", "ok2").startswith(b":1\r\n"), "two-consumer group key missing"

    assert _server_alive(port), "server did not survive loading well-formed consumer groups"


def test_wellformed_stream_roundtrips(dragonfly_port: int):
    """A real stream built with XADD — mixing entries that share a field set
    with entries that introduce new fields — must DUMP and RESTORE intact,
    preserving its length. This exercises the server's own serialization
    through the same load path."""
    port = dragonfly_port

    # Empty-body control first: the truthful-counts master entry must load.
    safe = _build_listpack_stream_dump(0, 0, 0)
    reply = _command(port, "RESTORE", "safe", "0", safe)
    assert reply.startswith(b"+OK\r\n"), f"well-formed empty stream rejected: {reply!r}"
    assert _command(port, "EXISTS", "safe").startswith(b":1\r\n"), "empty stream key missing"

    for args in (
        ("XADD", "s", "1-1", "a", "1", "b", "2"),   # fields {a, b}
        ("XADD", "s", "2-1", "a", "3", "b", "4"),   # same fields
        ("XADD", "s", "3-1", "c", "5"),             # new field set
    ):
        reply = _command(port, *args)
        assert reply.startswith(b"$") or reply.startswith(b"+"), f"XADD failed: {reply!r}"

    dump = _command(port, "DUMP", "s")
    # Parse the bulk-string DUMP reply: $<len>\r\n<payload>\r\n
    assert dump.startswith(b"$"), f"DUMP did not return a bulk string: {dump!r}"
    header, _, rest = dump.partition(b"\r\n")
    blob_len = int(header[1:])
    payload = rest[:blob_len]
    assert len(payload) == blob_len, "truncated DUMP payload"

    assert _command(port, "DEL", "s").startswith(b":1\r\n"), "DEL of the dumped key failed"

    reply = _command(port, "RESTORE", "s", "0", payload)
    assert reply.startswith(b"+OK\r\n"), f"RESTORE of a real stream dump failed: {reply!r}"
    assert _command(port, "XLEN", "s").startswith(b":3\r\n"), "restored stream lost entries"

    assert _server_alive(port), "server did not survive the well-formed round-trip"
