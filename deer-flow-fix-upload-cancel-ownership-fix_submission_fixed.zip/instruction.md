## Task

Cancelling an upload to a thread sometimes leaves debris. The cancels in question are a client disconnecting mid-upload, the gateway aborting in-flight requests during a shutdown, or a disconnect followed by a shutdown abort. Completed uploads never show it, and only some of the cancelled ones do, depending on timing.

What turns up afterwards is files belonging to the cancelled request in the thread's uploads directory, and in the system temp dir as well on instances with document conversion enabled. lsof against the gateway lists upload files it still has open. Where uploads are synced into the sandbox instead of mounted, upload requests that finished long ago are still holding their sandboxes. Separately, the error dashboard shows some cancelled uploads, and a few that were rejected as too large, as 500s.

Please make cancelled uploads stop leaving these behind and stop ending in 500s.
