## Task

Cancelled uploads to a thread don't always clean up after themselves. By cancelled I mean the client drops the connection partway through, or the server aborts the request on shutdown. Uploads that run to completion are fine, and it depends on timing, so most cancels look clean.

After a batch of cancelled uploads we find leftovers from those requests in the thread's uploads directory, and in the system temp dir when document conversion is on, and lsof on the gateway shows some upload files still open. On deployments where uploads are synced into the sandbox instead of mounted, some sandboxes stay held by upload requests that ended long ago. The error dashboard also has a handful of cancelled uploads, plus a few rejected as too large, recorded as 500s.

Can you get cancelled uploads to stop leaving things behind, and track down where those 500s come from?
