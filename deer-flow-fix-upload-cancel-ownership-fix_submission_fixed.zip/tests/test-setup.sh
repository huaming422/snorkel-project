#!/usr/bin/env bash
# Container setup for the verifier. Sourced (not exec'd) by the harbor runner so
# the exported VIRTUAL_ENV/PATH persist into the verifier subprocess. The
# verifier imports repository Python (app.gateway..., deerflow.utils...), so it
# must run under the project venv the image built at /opt/venv — NOT the
# isolated /opt/tooling verifier venv (which lacks fastapi/httpx and the repo
# packages).
set -u

REPO=/repo/deer-flow
cd "$REPO/backend" || { echo "test-setup: $REPO/backend missing" >&2; return 1 2>/dev/null || exit 1; }

# uv and the project venv the image prepared (block 10). Point uv at /opt/venv so
# `uv sync` resolves against the already-installed tree rather than creating a new
# one, and make that interpreter the default python/pytest the verifier invokes.
export UV_PROJECT_ENVIRONMENT=/opt/venv
export VIRTUAL_ENV=/opt/venv
export PATH="/opt/venv/bin:/usr/local/bin:$PATH"

# Build/verify the venv. The image already ran `uv sync --frozen --group dev`, so
# the offline resolve below is usually a fast no-op (no downloads). If uv decides
# the editable workspace packages need a rebuild, it needs the hatchling build
# backend: the runtime cache (/home/dev/.cache/uv) lacks it, but the image's warm
# cache (/opt/cache/uv) has it, so retry offline against that. The upload code
# needs no new dependency, so the venv the image built is already complete. No
# sync failure may abort the sourcing test.sh (it runs under set -e): the import
# check below decides.
if uv sync --frozen --group dev --offline; then
    echo "test-setup: offline dependency sync ok"
elif UV_CACHE_DIR=/opt/cache/uv uv sync --frozen --group dev --offline; then
    echo "test-setup: offline dependency sync ok (image cache)"
elif uv sync --frozen --group dev; then
    echo "test-setup: dependency sync ok (network)"
else
    echo "test-setup: sync failed, using the venv the image built" >&2
fi

# Sanity: the modules under test (and the test infra they need) must import
# cleanly before any verifier runs.
python -c "import app.gateway.routers.uploads; import app.gateway.upload_ingestion; import deerflow.utils.file_io; import httpx" \
    && echo "test-setup: upload modules importable" \
    || echo "test-setup: WARNING upload module import failed" >&2
