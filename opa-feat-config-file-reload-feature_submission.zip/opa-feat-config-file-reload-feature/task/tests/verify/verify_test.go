// Copyright 2026 The OPA Authors.  All rights reserved.
// Use of this source code is governed by an Apache2
// license that can be found in the LICENSE file.

// This verifier exercises the behavior that a config hot-reload must get
// right but that is invisible at /v1/config: when the operator edits only the
// `services` block (say, repointing a service at a new URL), the long-running
// components that talk to that service have to start using the new client,
// even though their own plugin configuration is byte-for-byte unchanged. A
// downloader (or log uploader) caches the rest client it was built with, so a
// naive reload that only diffs each plugin's own config would keep talking to
// the old endpoint.
//
// It drives ONLY pre-existing, stable public surface of the bundle plugin:
//   - plugins.New / Manager.Reconfigure  (register services on the manager)
//   - bundle.New / Plugin.Start          (build the plugin + its downloaders)
//   - plugins.Plugin.Reconfigure         (the interface reconfigure hook)
//   - Plugin.Trigger                     (manual poll)
// and observes which HTTP endpoint the download actually reaches via two
// counting httptest servers. It never references any symbol introduced by the
// change (no new runtime reload functions, no new plugin fields or helpers),
// and it lives in the external `bundle_test` package so it cannot touch
// unexported internals.
//
// All helper names carry a `_svcrepickup` suffix so the file composes with the
// package's existing *_test.go files without colliding.

package bundle_test

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"sync/atomic"
	"testing"

	bundleplugin "github.com/open-policy-agent/opa/v1/plugins/bundle"
	"github.com/open-policy-agent/opa/v1/config"
	"github.com/open-policy-agent/opa/v1/download"
	"github.com/open-policy-agent/opa/v1/plugins"
	inmem "github.com/open-policy-agent/opa/v1/storage/inmem/test"
)

// countingServer_svcrepickup answers every bundle request with 304 Not
// Modified — enough to record which endpoint the downloader talked to without
// building a real bundle.
func countingServer_svcrepickup(t *testing.T) (*httptest.Server, *atomic.Int64) {
	t.Helper()
	var hits atomic.Int64
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		hits.Add(1)
		w.WriteHeader(http.StatusNotModified)
	}))
	t.Cleanup(ts.Close)
	return ts, &hits
}

func servicesJSON_svcrepickup(url string) []byte {
	return []byte(fmt.Sprintf(`{"acme": {"url": %q}}`, url))
}

// newPlugin_svcrepickup builds a manager pointed at `url`, a single
// manually-triggered bundle served by service "acme", and starts the plugin so
// its downloader is live. Returns the plugin, the manager, and the bundle
// config for later reconfigure calls.
func newPlugin_svcrepickup(t *testing.T, url string) (*bundleplugin.Plugin, *plugins.Manager, *bundleplugin.Config) {
	t.Helper()

	manager, err := plugins.New(nil, "test-instance-id", inmem.New())
	if err != nil {
		t.Fatalf("new manager: %v", err)
	}
	if err := manager.Reconfigure(&config.Config{Services: servicesJSON_svcrepickup(url)}); err != nil {
		t.Fatalf("configure manager with first service: %v", err)
	}

	trigger := plugins.TriggerManual
	cfg := &bundleplugin.Config{
		Bundles: map[string]*bundleplugin.Source{
			"b": {
				Service:  "acme",
				Resource: "/bundles/b.tar.gz",
				Config:   download.Config{Trigger: &trigger},
			},
		},
	}

	plugin := bundleplugin.New(cfg, manager)
	t.Cleanup(func() { plugin.Stop(context.Background()) })

	// Start builds a downloader per bundle from the manager's current clients.
	// With a manual trigger it starts no background polling, so the only
	// requests are the ones we drive with Trigger below.
	if err := plugin.Start(context.Background()); err != nil {
		t.Fatalf("start plugin: %v", err)
	}

	return plugin, manager, cfg
}

// TestServiceRepointReachesNewEndpoint_svcrepickup is the behavior under test:
// after the manager is reconfigured to move service "acme" to a second URL and
// the plugin is reconfigured with its SAME bundle config, a manual trigger
// must reach the second endpoint, not the first.
func TestServiceRepointReachesNewEndpoint_svcrepickup(t *testing.T) {
	first, firstHits := countingServer_svcrepickup(t)
	second, secondHits := countingServer_svcrepickup(t)

	plugin, manager, cfg := newPlugin_svcrepickup(t, first.URL)

	// Baseline: the download reaches the first endpoint.
	if err := plugin.Trigger(context.Background()); err != nil {
		t.Fatalf("initial trigger: %v", err)
	}
	if firstHits.Load() == 0 {
		t.Fatalf("expected the first endpoint to be polled before the repoint, got first=%d second=%d",
			firstHits.Load(), secondHits.Load())
	}
	baselineSecond := secondHits.Load()

	// Repoint service "acme" to the second endpoint. The plugin's own bundle
	// config is unchanged — only the service moved.
	if err := manager.Reconfigure(&config.Config{Services: servicesJSON_svcrepickup(second.URL)}); err != nil {
		t.Fatalf("reconfigure manager to second service: %v", err)
	}
	plugin.Reconfigure(context.Background(), cfg)

	// The next trigger must now reach the second endpoint.
	if err := plugin.Trigger(context.Background()); err != nil {
		t.Fatalf("trigger after repoint: %v", err)
	}
	if secondHits.Load() <= baselineSecond {
		t.Errorf("expected the download to move to the second endpoint after the service was repointed, "+
			"got first=%d second=%d (baseline second=%d)",
			firstHits.Load(), secondHits.Load(), baselineSecond)
	}
}

// TestUnchangedServiceDoesNotForceRebuild_svcrepickup is the converse guard:
// re-registering the SAME service URL and reconfiguring with the SAME bundle
// config must not restart the downloader. A spurious restart drops the
// downloader's cached etag and would re-download every bundle in full, so an
// implementation that rebuilds unconditionally is not correct. We prove "no
// restart" behaviorally: after an unchanged reconfigure the next trigger still
// succeeds and still talks to the same single endpoint (no second endpoint
// exists to leak to), and the download path keeps working.
func TestUnchangedServiceDoesNotForceRebuild_svcrepickup(t *testing.T) {
	only, onlyHits := countingServer_svcrepickup(t)

	plugin, manager, cfg := newPlugin_svcrepickup(t, only.URL)

	if err := plugin.Trigger(context.Background()); err != nil {
		t.Fatalf("initial trigger: %v", err)
	}
	afterFirst := onlyHits.Load()
	if afterFirst == 0 {
		t.Fatalf("expected the endpoint to be polled at least once, got %d", afterFirst)
	}

	// Re-register the identical service URL and reconfigure with the identical
	// bundle config: nothing material changed.
	if err := manager.Reconfigure(&config.Config{Services: servicesJSON_svcrepickup(only.URL)}); err != nil {
		t.Fatalf("reconfigure manager with same service: %v", err)
	}
	plugin.Reconfigure(context.Background(), cfg)

	// The downloader is still live and still reaches the same endpoint.
	if err := plugin.Trigger(context.Background()); err != nil {
		t.Fatalf("trigger after no-op reconfigure: %v", err)
	}
	if onlyHits.Load() <= afterFirst {
		t.Errorf("expected the downloader to keep working against the same endpoint after a no-op reconfigure, "+
			"got hits before=%d after=%d", afterFirst, onlyHits.Load())
	}
}
