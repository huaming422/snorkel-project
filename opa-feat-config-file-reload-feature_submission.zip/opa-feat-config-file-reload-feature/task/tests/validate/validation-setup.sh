#!/usr/bin/env bash
#
# Validation env setup, run after tests/test-setup.sh. Must be IDEMPOTENT:
# it may be sourced more than once (once by the verifier harness, once by the
# validator). It only re-exports the Go toolchain knobs the go-test driver
# needs and makes sure the module cache is reachable; it builds nothing.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/opa}"
cd "$REPO_DIR"

# Mirror the image's Go environment (same values as tests/test-setup.sh).
# GOTOOLCHAIN=local keeps `go` from trying to fetch a newer toolchain on a
# cold run; GOFLAGS=-mod=mod matches the module mode the repo builds under;
# GOPROXY=off keeps the offline cache authoritative.
export CGO_ENABLED="${CGO_ENABLED:-1}"
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"
export GOFLAGS="${GOFLAGS:--mod=mod}"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"
export GOPROXY="${GOPROXY:-off}"

mkdir -p "$GOMODCACHE" "$GOCACHE"

# Make `go` reachable even if the harness scrubbed PATH.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

# No-op on the intact pre-warmed cache; recovers a wiped one. Tolerate
# failure here — `go test` surfaces anything genuinely missing, loudly.
go mod download 2>/dev/null || true

# Loud smoke guard: fail early with a clear message if the toolchain or the
# runtime package the stories compile against is not actually present.
if ! go version >/dev/null 2>&1; then
    echo "validation-setup.sh: FATAL: go toolchain not on PATH" >&2
    exit 1
fi
if [[ ! -d "$REPO_DIR/v1/runtime" ]]; then
    echo "validation-setup.sh: FATAL: v1/runtime package dir missing at $REPO_DIR" >&2
    exit 1
fi

echo "validation-setup.sh: ready (go=$(go version | awk '{print $3}'), CGO_ENABLED=$CGO_ENABLED, GOFLAGS=$GOFLAGS)"
