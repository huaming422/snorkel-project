#!/usr/bin/env bash
#
# Sourced (not exec'd, so exported env sticks) before the verifier runs. The
# Dockerfile already cloned opa at the task base commit, warmed the Go module
# and build caches, and compiled the unit-test tree. This restores the env the
# verifier's `go test` needs even if the agent's edits or a `git clean` touched
# PATH or the module settings. Dependencies are baked into the image, so this
# does no network resolution for the task's own build.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/opa}"
cd "$REPO_DIR"

# Mirror the image's Go env. GOTOOLCHAIN=local stops `go` from trying to fetch a
# newer toolchain on a cold run; GOFLAGS=-mod=mod matches the module mode the
# repo builds under. CGO stays enabled as in the environment image.
export CGO_ENABLED=1
export GOTOOLCHAIN=local
export GOFLAGS=-mod=mod
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"

# Agent phase is offline and the module cache is complete; make a cache miss
# fail fast instead of hanging on a dead network during the verifier build.
export GOPROXY="${GOPROXY:-off}"

# Make `go` reachable even if the harness scrubbed PATH.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

# No Python packages are installed here: the verifier infrastructure runs from
# the canonical /opt/tooling venv (pytest and friends are baked there), and the
# task's own tests are Go. Keeping this script free of any dependency-resolving
# command keeps the agent phase fully offline.

echo "test-setup.sh: ready (go=$(go version 2>/dev/null | awk '{print $3}'), GOPROXY=$GOPROXY)"
