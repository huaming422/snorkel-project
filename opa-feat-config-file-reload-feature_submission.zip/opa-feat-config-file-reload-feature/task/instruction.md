## Task

Right now `opa run --watch` only live-reloads the policy and data files the server was started with. The config file passed with `--config-file` is read once at start-up and never looked at again while the server keeps running.

We want `--watch` to cover the config file too: while the server is up, notice when its config file changes on disk and apply the new configuration to the already-running components without restarting the process. Some settings can be changed safely on a live server and some can't, so the intent is to apply whatever can be applied live and cleanly refuse whatever can't, rather than leaving the server in a half-changed state.

This includes the connection details for the services OPA talks to: when the file repoints an existing service at a new URL or rotated credential, the components already using it (the bundle downloader and decision-log uploader) must switch to the new connection live, even when nothing else about them changed.

Everything happens inside the running `opa run` server: the operator edits the config file and watches the result through the server's existing HTTP API.

## User stories / requirements

- When the running server's config file is edited to add a label and switch on a component that wasn't enabled before, the server picks up the edit without a restart, and the running configuration it reports back reflects both the new label and the newly-enabled component.
- When the config file is edited to change a setting that only takes effect at start-up, the edit is refused and the server keeps running with its previous configuration unchanged.
- When the config file is edited to change or remove one of the server's labels, the edit is refused and the previous labels stay in effect.
- When an edit removes the config section for a component that is currently running, the edit is refused and the component keeps running with its previous configuration.
- After an edit has been refused, editing the config file back to its previous contents brings the server back cleanly, with no error and the original configuration in effect.
- When a tool replaces the config file by first emptying it and then writing the new contents, the server does not act on the momentarily-empty file; only the final, complete configuration takes effect.
- When the server is set up to obtain its configuration through discovery, edits to the local config file are not hot-reloaded, since the discovered configuration is what drives the running components.
- When the config file is edited to point an existing service at a new URL, the running server applies the change in place, and the running configuration it reports back shows the service's new connection details rather than the old ones.
