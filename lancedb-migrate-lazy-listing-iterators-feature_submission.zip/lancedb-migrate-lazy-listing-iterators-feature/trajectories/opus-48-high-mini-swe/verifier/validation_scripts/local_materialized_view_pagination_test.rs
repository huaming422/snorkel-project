mod validation_params;

use arrow_array::record_batch;
use futures::TryStreamExt;
use lancedb::pagination::ListRequest;
use validation_params::{get_validation_test_cases, TestCase};

#[tokio::test]
async fn test_local_materialized_view_pagination() {
    let cases = get_validation_test_cases();
    for tc in &cases {
        let views_input: Vec<String> = tc.inputs["views"]
            .as_array()
            .expect("views array")
            .iter()
            .map(|v| v.as_str().unwrap().to_string())
            .collect();
        let page_limit = tc.inputs["page_limit"].as_u64().expect("page_limit") as u32;

        // Connect to fresh in-process backend
        let conn = lancedb::connect("memory://").execute().await.unwrap();

        // Seed source table
        let batch = record_batch!(("x", Int32, [1, 2])).unwrap();
        conn.create_table("src", batch).execute().await.unwrap();

        // Create each materialized view
        for view_name in &views_input {
            conn.create_materialized_view(view_name.as_str(), "src")
                .execute()
                .await
                .unwrap();
        }

        // List materialized views with the specified page size
        let request = ListRequest::default().page_size(page_limit);
        let stream = conn.list_materialized_views(request).await.unwrap();
        let mut collected: Vec<String> = stream.try_collect().await.unwrap();

        // EXPECTED: view_count
        let expected_count = tc.expected["view_count"].as_u64().expect("view_count") as usize;
        assert_eq!(
            collected.len(), expected_count,
            "case {}: view_count mismatch", tc.name
        );

        // EXPECTED: views_sorted
        let expected_sorted: Vec<String> = tc.expected["views_sorted"]
            .as_array()
            .expect("views_sorted array")
            .iter()
            .map(|v| v.as_str().unwrap().to_string())
            .collect();
        collected.sort();
        assert_eq!(
            collected, expected_sorted,
            "case {}: views_sorted mismatch", tc.name
        );
    }
}
