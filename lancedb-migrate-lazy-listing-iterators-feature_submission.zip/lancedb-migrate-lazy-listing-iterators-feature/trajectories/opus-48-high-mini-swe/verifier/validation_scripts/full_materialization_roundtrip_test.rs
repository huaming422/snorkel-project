mod listing_mock;
mod validation_params;

use futures::TryStreamExt;
use lancedb::pagination::ListRequest;
use validation_params::{get_validation_test_cases, TestCase};

#[tokio::test]
async fn test_full_materialization_roundtrip() {
    let cases = get_validation_test_cases();
    for tc in &cases {
        let pages = tc.inputs["pages"].as_array().expect("pages array");
        let page_limit = tc.inputs["page_limit"].as_u64().expect("page_limit") as u32;

        let mut responses: Vec<(u16, String)> = Vec::new();
        for page in pages {
            let items: Vec<String> = page["items"]
                .as_array()
                .expect("items array")
                .iter()
                .map(|v| v.as_str().unwrap().to_string())
                .collect();
            let token = page["token"].as_str().unwrap_or("");
            let body = listing_mock::views_body(&items, token);
            responses.push((200, body));
        }

        let server = listing_mock::MockServer::start(responses).await;

        let db = lancedb::connect("db://dummy")
            .api_key("fake-key")
            .region("us-east-1")
            .host_override(&server.base_url())
            .execute()
            .await
            .unwrap();

        let namespace = vec!["team".to_string()];
        let request = ListRequest::default().page_size(page_limit);

        // Build the listing but DON'T consume it yet
        let stream = db.list_views(&namespace, request).await.unwrap();

        // Record request count before consuming
        let requests_before_collect = server.request_count();

        // Drain the whole sequence in one call
        let collected: Vec<String> = stream.try_collect().await.unwrap();

        // EXPECTED: requests_before_collect
        let expected_before = tc.expected["requests_before_collect"]
            .as_u64()
            .expect("requests_before_collect") as usize;
        assert_eq!(
            requests_before_collect, expected_before,
            "case {}: requests_before_collect mismatch", tc.name
        );

        // EXPECTED: items
        let expected_items: Vec<String> = tc.expected["items"]
            .as_array()
            .expect("expected items array")
            .iter()
            .map(|v| v.as_str().unwrap().to_string())
            .collect();
        assert_eq!(
            collected, expected_items,
            "case {}: items mismatch", tc.name
        );
    }
}
