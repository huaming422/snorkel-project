mod listing_mock;
mod validation_params;

use futures::TryStreamExt;
use lancedb::pagination::ListRequest;
use validation_params::get_validation_test_cases;

#[tokio::test]
async fn test_jobs_not_truncated_past_cap() {
    let cases = get_validation_test_cases();
    for tc in &cases {
        let num_pages = tc.inputs["num_pages"].as_u64().expect("num_pages") as usize;

        // Build scripted pages: page i carries job id = i.to_string()
        // and token = (i+1).to_string() except last which has empty token
        let mut responses: Vec<(u16, String)> = Vec::new();
        for i in 0..num_pages {
            let id = i.to_string();
            let token = if i + 1 < num_pages {
                (i + 1).to_string()
            } else {
                String::new()
            };
            let body = listing_mock::jobs_body(&[id], &token);
            responses.push((200, body));
        }

        let server = listing_mock::MockServer::start(responses).await;

        // Connect using the public builder
        let db = lancedb::connect("db://dummy")
            .api_key("fake-key")
            .region("us-east-1")
            .host_override(&server.base_url())
            .execute()
            .await
            .unwrap();

        // Call the job listing method with default request
        let mut stream = db.list_jobs(ListRequest::default()).await.unwrap();

        // Record before first pull
        let requests_before_first = server.request_count();

        // Pull first job
        let first_job = stream.try_next().await.unwrap().expect("first job");
        let requests_after_first = server.request_count();

        // Drain remaining
        let mut all_jobs = vec![first_job];
        while let Some(job) = stream.try_next().await.unwrap() {
            all_jobs.push(job);
        }

        // EXPECTED: requests_before_first
        let expected_before = tc.expected["requests_before_first"]
            .as_u64()
            .expect("requests_before_first") as usize;
        assert_eq!(
            requests_before_first, expected_before,
            "case {}: requests_before_first mismatch", tc.name
        );

        // EXPECTED: requests_after_first
        let expected_after_first = tc.expected["requests_after_first"]
            .as_u64()
            .expect("requests_after_first") as usize;
        assert_eq!(
            requests_after_first, expected_after_first,
            "case {}: requests_after_first mismatch", tc.name
        );

        // EXPECTED: count
        let expected_count = tc.expected["count"].as_u64().expect("count") as usize;
        assert_eq!(
            all_jobs.len(), expected_count,
            "case {}: count mismatch", tc.name
        );

        // EXPECTED: last_job_id
        let expected_last = tc.expected["last_job_id"]
            .as_str()
            .expect("last_job_id");
        let last_job = all_jobs.last().expect("at least one job");
        assert_eq!(
            last_job.job_id, expected_last,
            "case {}: last_job_id mismatch", tc.name
        );
    }
}
