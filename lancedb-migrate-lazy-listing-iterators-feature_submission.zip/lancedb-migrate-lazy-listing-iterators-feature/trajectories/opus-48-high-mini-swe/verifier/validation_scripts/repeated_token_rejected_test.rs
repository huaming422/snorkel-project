mod listing_mock;
mod validation_params;

use futures::TryStreamExt;
use lancedb::pagination::ListRequest;
use validation_params::{get_validation_test_cases, TestCase};

#[tokio::test]
async fn test_repeated_token_rejected() {
    let cases = get_validation_test_cases();
    for tc in &cases {
        let pages = tc.inputs["pages"].as_array().expect("pages array");

        let mut responses: Vec<(u16, String)> = Vec::new();
        for page in pages {
            let items: Vec<String> = page["items"]
                .as_array()
                .expect("items array")
                .iter()
                .map(|v| v.as_str().unwrap().to_string())
                .collect();
            let token = page["token"].as_str().unwrap_or("");
            let body = listing_mock::views_body(&items, token);
            responses.push((200, body));
        }

        let server = listing_mock::MockServer::start(responses).await;

        let db = lancedb::connect("db://dummy")
            .api_key("fake-key")
            .region("us-east-1")
            .host_override(&server.base_url())
            .execute()
            .await
            .unwrap();

        let namespace = vec!["team".to_string()];
        let stream = db
            .list_views(&namespace, ListRequest::default())
            .await
            .unwrap();

        // Pull items one at a time until error or end
        let mut outcome = "end";
        let mut stream = stream;
        loop {
            match stream.try_next().await {
                Err(_) => {
                    outcome = "error";
                    break;
                }
                Ok(None) => {
                    outcome = "end";
                    break;
                }
                Ok(Some(_)) => {
                    // Keep consuming
                }
            }
        }

        // EXPECTED: outcome
        let expected_outcome = tc.expected["outcome"].as_str().expect("outcome");
        assert_eq!(
            outcome, expected_outcome,
            "case {}: outcome mismatch", tc.name
        );

        // EXPECTED: total_requests
        let expected_total = tc.expected["total_requests"]
            .as_u64()
            .expect("total_requests") as usize;
        assert_eq!(
            server.request_count(), expected_total,
            "case {}: total_requests mismatch", tc.name
        );
    }
}
