mod listing_mock;
mod validation_params;

use futures::TryStreamExt;
use lancedb::pagination::ListRequest;
use validation_params::get_validation_test_cases;

#[tokio::test]
async fn test_empty_pages_and_resume() {
    let cases = get_validation_test_cases();
    for tc in &cases {
        let pages = tc.inputs["pages"].as_array().expect("pages array");
        let page_limit = tc.inputs["page_limit"].as_u64().expect("page_limit") as u32;

        // start_token: if null or "__none__", don't set it
        let start_token_raw = &tc.inputs["start_token"];
        let start_token: Option<String> = if start_token_raw.is_null() {
            None
        } else if let Some(s) = start_token_raw.as_str() {
            if s == "__none__" {
                None
            } else {
                Some(s.to_string())
            }
        } else {
            None
        };

        let mut responses: Vec<(u16, String)> = Vec::new();
        for page in pages {
            let items: Vec<String> = page["items"]
                .as_array()
                .expect("items array")
                .iter()
                .map(|v| v.as_str().unwrap().to_string())
                .collect();
            let token = page["token"].as_str().unwrap_or("");
            let body = listing_mock::secrets_body(&items, token);
            responses.push((200, body));
        }

        let server = listing_mock::MockServer::start(responses).await;

        let db = lancedb::connect("db://dummy")
            .api_key("fake-key")
            .region("us-east-1")
            .host_override(&server.base_url())
            .execute()
            .await
            .unwrap();

        let namespace = vec!["team".to_string()];
        let mut request = ListRequest::default().page_size(page_limit);
        if let Some(tok) = start_token {
            request = request.start_page_token(tok);
        }

        let stream = db.list_secrets(&namespace, request).await.unwrap();
        let collected: Vec<String> = stream.try_collect().await.unwrap();

        // EXPECTED: items
        let expected_items: Vec<String> = tc.expected["items"]
            .as_array()
            .expect("expected items array")
            .iter()
            .map(|v| v.as_str().unwrap().to_string())
            .collect();
        assert_eq!(
            collected, expected_items,
            "case {}: items mismatch", tc.name
        );

        // EXPECTED: total_requests
        let expected_total = tc.expected["total_requests"]
            .as_u64()
            .expect("total_requests") as usize;
        assert_eq!(
            server.request_count(), expected_total,
            "case {}: total_requests mismatch", tc.name
        );

        // EXPECTED: first_request_token
        // If the expected value is "__skip__", skip this check.
        // Otherwise, parse the first recorded request's query string and assert
        // the page_token parameter equals the expected value.
        let first_request_token_expected = tc.expected["first_request_token"]
            .as_str()
            .expect("first_request_token");
        if first_request_token_expected != "__skip__" {
            let requests = server.requests();
            let first_req = requests.first().expect("at least one request");
            let query = &first_req.query;
            // Parse query string: key=value&key=value
            let page_token_value = query
                .split('&')
                .find_map(|part| {
                    let mut kv = part.splitn(2, '=');
                    let key = kv.next().unwrap_or("");
                    let val = kv.next().unwrap_or("");
                    if key == "page_token" {
                        Some(val.to_string())
                    } else {
                        None
                    }
                })
                .unwrap_or_default();
            assert_eq!(
                page_token_value, first_request_token_expected,
                "case {}: first_request_token mismatch", tc.name
            );
        }
    }
}
