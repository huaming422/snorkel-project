mod listing_mock;
mod validation_params;

use futures::TryStreamExt;
use lancedb::pagination::ListRequest;
use validation_params::get_validation_test_cases;

#[tokio::test]
async fn test_lazy_fetch_one_page_at_a_time() {
    let cases = get_validation_test_cases();
    for tc in &cases {
        // Build scripted pages from inputs.pages
        let pages = tc.inputs["pages"].as_array().expect("pages array");
        let page_limit = tc.inputs["page_limit"].as_u64().expect("page_limit") as u32;

        let mut responses: Vec<(u16, String)> = Vec::new();
        for page in pages {
            let items: Vec<String> = page["items"]
                .as_array()
                .expect("items array")
                .iter()
                .map(|v| v.as_str().unwrap().to_string())
                .collect();
            let token = page["token"].as_str().unwrap_or("");
            let body = listing_mock::secrets_body(&items, token);
            responses.push((200, body));
        }

        let server = listing_mock::MockServer::start(responses).await;

        // Connect using the public builder
        let db = lancedb::connect("db://dummy")
            .api_key("fake-key")
            .region("us-east-1")
            .host_override(&server.base_url())
            .execute()
            .await
            .unwrap();

        // Call the secret listing method with page size and namespace
        let namespace = vec!["team".to_string()];
        let request = ListRequest::default().page_size(page_limit);
        let stream = db.list_secrets(&namespace, request).await.unwrap();

        // Record request count before pulling anything
        let requests_before_first = server.request_count();

        // Pull items one at a time
        let mut collected_items: Vec<String> = Vec::new();
        let mut requests_after_each: Vec<usize> = Vec::new();
        let mut stream = stream;

        while let Some(item) = stream.try_next().await.unwrap() {
            collected_items.push(item);
            requests_after_each.push(server.request_count());
        }

        // EXPECTED: items
        let expected_items: Vec<String> = tc.expected["items"]
            .as_array()
            .expect("expected items array")
            .iter()
            .map(|v| v.as_str().unwrap().to_string())
            .collect();
        assert_eq!(
            collected_items, expected_items,
            "case {}: items mismatch", tc.name
        );

        // EXPECTED: requests_before_first
        let expected_before = tc.expected["requests_before_first"]
            .as_u64()
            .expect("requests_before_first") as usize;
        assert_eq!(
            requests_before_first, expected_before,
            "case {}: requests_before_first mismatch", tc.name
        );

        // EXPECTED: requests_after_each
        let expected_after_each: Vec<usize> = tc.expected["requests_after_each"]
            .as_array()
            .expect("requests_after_each array")
            .iter()
            .map(|v| v.as_u64().unwrap() as usize)
            .collect();
        assert_eq!(
            requests_after_each, expected_after_each,
            "case {}: requests_after_each mismatch", tc.name
        );
    }
}
