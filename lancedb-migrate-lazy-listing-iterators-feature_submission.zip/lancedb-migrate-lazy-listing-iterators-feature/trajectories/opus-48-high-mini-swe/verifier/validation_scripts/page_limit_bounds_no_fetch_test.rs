mod listing_mock;
mod validation_params;

use futures::TryStreamExt;
use lancedb::pagination::ListRequest;
use validation_params::get_validation_test_cases;

#[tokio::test]
async fn test_page_limit_bounds_no_fetch() {
    let cases = get_validation_test_cases();
    for tc in &cases {
        let pages = tc.inputs["pages"].as_array().expect("pages array");
        // page_limit comes as u64 from JSON
        let page_limit_u64 = tc.inputs["page_limit"].as_u64().expect("page_limit");

        let mut responses: Vec<(u16, String)> = Vec::new();
        for page in pages {
            let items: Vec<String> = page["items"]
                .as_array()
                .expect("items array")
                .iter()
                .map(|v| v.as_str().unwrap().to_string())
                .collect();
            let token = page["token"].as_str().unwrap_or("");
            let body = listing_mock::jobs_body(&items, token);
            responses.push((200, body));
        }

        let server = listing_mock::MockServer::start(responses).await;

        let db = lancedb::connect("db://dummy")
            .api_key("fake-key")
            .region("us-east-1")
            .host_override(&server.base_url())
            .execute()
            .await
            .unwrap();

        // page_size is u32; cast from u64, validating > i32::MAX via ListRequest::validate
        let page_size_u32 = page_limit_u64 as u32;
        let request = ListRequest::default().page_size(page_size_u32);

        // Call the job listing method; the stream itself or first item may error
        let stream_result = db.list_jobs(request).await;

        let outcome: &str;
        let first_item_val: Option<String>;

        match stream_result {
            Err(_) => {
                outcome = "error";
                first_item_val = None;
            }
            Ok(mut stream) => {
                match stream.try_next().await {
                    Err(_) => {
                        outcome = "error";
                        first_item_val = None;
                    }
                    Ok(None) => {
                        outcome = "end";
                        first_item_val = None;
                    }
                    Ok(Some(job)) => {
                        outcome = "ok";
                        first_item_val = Some(job.job_id.clone());
                    }
                }
            }
        }

        // EXPECTED: outcome
        let expected_outcome = tc.expected["outcome"].as_str().expect("outcome");
        assert_eq!(
            outcome, expected_outcome,
            "case {}: outcome mismatch (page_limit={})", tc.name, page_limit_u64
        );

        // EXPECTED: requests_after
        let expected_requests = tc.expected["requests_after"]
            .as_u64()
            .expect("requests_after") as usize;
        assert_eq!(
            server.request_count(), expected_requests,
            "case {}: requests_after mismatch (page_limit={})", tc.name, page_limit_u64
        );

        // EXPECTED: first_item
        // If "__skip__", skip this assertion; otherwise assert the yielded job's
        // job_id equals expected.first_item.
        let expected_first_item = tc.expected["first_item"].as_str().expect("first_item");
        if expected_first_item != "__skip__" {
            let actual_first = first_item_val.as_deref().unwrap_or("");
            assert_eq!(
                actual_first, expected_first_item,
                "case {}: first_item mismatch", tc.name
            );
        }
    }
}
