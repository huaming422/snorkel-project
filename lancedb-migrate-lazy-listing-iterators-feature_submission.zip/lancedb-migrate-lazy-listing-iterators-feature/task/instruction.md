## Task

We want the connection-level list APIs (secrets, views, functions, jobs, and
materialized views) to return a lazy, paginated iterator rather than eagerly
fetching the entire result set before they return. Along with that, drop the
arbitrary per-call page cap so large result sets come back complete, and keep a
simple one-call way to collect the whole thing for callers who still want the
eager behavior.

Scope this to the Rust core and the Rust binding crates (the napi and pyo3
wrappers); the higher-level language wrappers sitting on top of the bindings
are out of scope. Leave the per-page request and response contract with the
server as it is: this changes when pages are fetched, not how each one is
requested. No manifest or dependency changes should be needed, since
everything required is already in the tree.

## User stories / requirements

- When a caller lists a resource, nothing is fetched from the server until they start consuming the iterator, and each further page is fetched only once they consume past the previous one. Reading just the first page's worth of results triggers a single server request, not a walk of the whole sequence.
- When a caller lists jobs over a history that spans well over a hundred pages, the iterator walks all the way to the end and returns every job, with no arbitrary page cap cutting the results short.
- When a page comes back with no items but a continuation token, the iterator keeps fetching rather than stopping. When the caller supplies a starting page token, the first fetch continues from that token instead of from the beginning.
- When a caller asks for a page size of zero, or one larger than a signed 32-bit integer can hold, the listing fails with an invalid-input error and no server request is made for that page size.
- When the server hands back the same continuation token it was just given, the iterator fails with an error instead of looping forever.
- When a caller lists materialized views against the local, non-remote backend, the requested page size is honored and the full set of views comes back, collectible in a single pass.
- When a caller collects a whole multi-page listing in one call, they get back the complete, ordered set that the old eager API would have returned.
- When a caller lists functions, nothing is fetched from the server until they start consuming the iterator, and each further page is fetched only once they consume past the previous one; collecting the whole listing in one call still yields every function across all pages, in order. A page that comes back with no functions but a continuation token is walked through rather than treated as the end.
