#!/usr/bin/env bash
# Compilation gate for the lazy-listing migration.
#
# This is the structural half of the reward stack: it asserts the whole
# workspace plus the remote-feature build of the core crate still compile
# after the migration. It imports no names the solution introduces, so it
# admits every valid internal shape (hand-rolled stream, generator-based,
# renamed module/types); it only fails a migration left half-done, where the
# new streaming signatures are in place but some caller or binding crate was
# not carried along.
#
#   * `cargo build --locked --tests` over the whole workspace proves every
#     member (core plus the napi / pyo3 wrapper crates) and every in-tree
#     test target still type-checks against the new public signatures.
#   * `cargo build --locked --tests --features remote -p lancedb` proves the
#     remote client code path, which the behavioral stories drive, also
#     compiles.
#
# The pre-fix tree already compiles both ways, so this check only becomes
# meaningful once the agent changes the public list_* signatures: an
# incomplete migration (unupdated callers, binding crates still pointing at
# the old return types) fails to build and fails this gate.
#
# The image pre-builds `cargo build --locked --tests` at the base commit, so
# the default-feature build is incremental; the remote-feature build pays a
# one-time cold compile of the remote module. Exit non-zero propagates the
# first cargo failure.
set -euo pipefail

# Pin the toolchain the image baked, ahead of anything on PATH, and keep
# cargo off the network: the image carries the full dependency closure.
export RUSTUP_TOOLCHAIN="${RUSTUP_TOOLCHAIN:-1.97.0}"
export CARGO_TERM_COLOR="${CARGO_TERM_COLOR:-never}"
export CARGO_NET_OFFLINE="${CARGO_NET_OFFLINE:-true}"

cd /repo/lancedb

echo "[verify_build] workspace test build (default features)"
cargo build --locked --tests

echo "[verify_build] lancedb test build (--features remote)"
cargo build --locked --tests --features remote -p lancedb

echo "[verify_build] ok"
