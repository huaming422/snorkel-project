#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (inherits set -euo pipefail).
#
# No services to start and no data to seed: the reward stack is a set of Rust
# integration tests plus a workspace build check. The image already baked the
# full dependency closure at the pre-fix base commit (`cargo fetch --locked`
# + `cargo build --locked --tests`), so this script's only job is to pin the
# cargo build to offline mode — a cache miss must fail fast instead of
# reaching for crates.io, which is cut during grading.
cd /repo/lancedb

# Offline switch for the task's own cargo (NOT image-wide ENV — see
# AUTHORING.md §1.5: an image-wide uv/cargo offline switch would break the
# agent-harness `uv tool install` at trial prep while the network is still
# up). CARGO_NET_OFFLINE makes any un-warmed fetch fail immediately.
export CARGO_NET_OFFLINE=true

# Offline-first verification that the dependency closure is present. The
# image warmed it; this confirms nothing needs the network. `cargo fetch
# --locked --offline` is a no-op when the cache is complete and errors out
# loudly if the bake was stale, in which case we log the online fallback.
if cargo fetch --locked --offline > /tmp/test-setup-fetch.log 2>&1; then
    echo "[offline-first] cargo dependency closure satisfied from image"
elif cargo fetch --locked >> /tmp/test-setup-fetch.log 2>&1; then
    echo "[test-setup] cargo deps fetched online (image bake was stale)"
else
    tail -40 /tmp/test-setup-fetch.log >&2; exit 1
fi

echo "[test-setup] Rust version:   $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:  $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root: /repo/lancedb"
echo "[test-setup] Setup complete."
