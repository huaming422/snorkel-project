#!/usr/bin/env bash
# Runs (sourced) AFTER the agent's solution has been applied to /repo/lancedb,
# BEFORE run_validate.py. It:
#   1. Pins the Rust toolchain the image baked (1.97.0).
#   2. Restores the canonical Cargo.lock so a stray lockfile edit cannot drift
#      the dependency set the stories compile against.
#   3. Stages the shared loopback HTTP mock as a module beside the generated
#      story tests, so each story can `mod listing_mock;`.
#   4. Warms the integration-test build for both the default and remote feature
#      sets, and fails loudly if either the workspace or the remote-feature
#      build is broken (a broken env must error the trial, never score 0).
#
# The staging happens before run_validate.py takes its pre-validation checkpoint
# (test.sh sources this script first), so the mock module is part of the
# baseline and is not seen as an integrity violation.
set -euo pipefail

REPO=/repo/lancedb
CRATE="$REPO/rust/lancedb"
MOCK_SRC=/tests/validate/listing_mock.rs

echo "[validation-setup] pinning Rust toolchain 1.97.0"
export RUSTUP_TOOLCHAIN=1.97.0
export CARGO_TERM_COLOR=never
# Keep cargo off the network: the image baked the full dependency closure.
export CARGO_NET_OFFLINE=true

cd "$REPO"

# 1. Restore the canonical lockfile if the checkout left it modified.
if git -C "$REPO" rev-parse --verify HEAD >/dev/null 2>&1; then
  if ! git -C "$REPO" diff --quiet -- Cargo.lock 2>/dev/null; then
    echo "[validation-setup] restoring canonical Cargo.lock"
    git -C "$REPO" checkout -- Cargo.lock || true
  fi
fi

# 2. Stage the shared mock as a submodule directory beside the story tests.
#    A bare `tests/listing_mock.rs` would be picked up by cargo as its own
#    integration-test target; `tests/listing_mock/mod.rs` is a plain module the
#    story files include with `mod listing_mock;`.
echo "[validation-setup] staging shared listing mock into tests/"
mkdir -p "$CRATE/tests/listing_mock"
if [[ ! -f "$MOCK_SRC" ]]; then
  echo "[validation-setup] FATAL: shared mock not found at $MOCK_SRC" >&2
  exit 1
fi
cp "$MOCK_SRC" "$CRATE/tests/listing_mock/mod.rs"

# 3. Loud build smoke guard. Compile the crate's test targets for the default
#    feature set and for the remote feature set. If either fails to build, the
#    agent's solution left the tree uncompilable; surface it now with the tail
#    of the log rather than letting every story read as a silent failure.
echo "[validation-setup] warming workspace test build (default features)"
if ! cargo build --locked --tests > /tmp/vsetup-build-default.log 2>&1; then
  echo "[validation-setup] FATAL: workspace test build failed" >&2
  tail -120 /tmp/vsetup-build-default.log >&2
  exit 1
fi

echo "[validation-setup] warming lancedb test build (--features remote)"
if ! cargo build --locked --tests --features remote -p lancedb > /tmp/vsetup-build-remote.log 2>&1; then
  echo "[validation-setup] FATAL: lancedb remote-feature test build failed" >&2
  tail -120 /tmp/vsetup-build-remote.log >&2
  exit 1
fi

echo "[validation-setup] ready"
