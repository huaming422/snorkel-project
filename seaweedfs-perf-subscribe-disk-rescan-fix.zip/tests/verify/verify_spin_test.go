package weed_server

// Behavioral checks for the aggregated metadata-subscribe loop, driven entirely
// through the package's own end-to-end test helpers (newSubscribeHarness, startAggregator,
// subscribeAggregated, reportPeersAt, appendAggregated, waitForEvents,
// waitForFlushedFiles, tsAt) and the pre-existing filer.FilerStore interface.
//
// The behavior under test is the persisted-log disk pass cadence: a subscriber
// whose start position sits past the end of the local persisted log must not
// re-list the system log directory on every wake, yet it must still deliver its
// backlog the moment peer progress admits it, and a held on-disk entry must
// still be re-read and released when the flush watermark or the settled horizon
// reaches it. Work is observed by wrapping the store in a counting shim that
// tallies listings on the system log dir, and delivery is observed on the
// subscriber's own stream.
//
// Every delivery bound below is vrfPromptDelivery. The loop's own wake after a
// watermark moves is tens of milliseconds, so the bound leaves wide headroom on
// a loaded machine; it fails a loop that waits for a timed re-probe or a fixed
// sleep before it looks again. The listing bound in the first check fits a
// re-probe about once a second or slower, so no fixed period passes both
// bounds without re-reading when a watermark moves.
//
// No symbol introduced by the change is referenced: any shape that produces the
// same observable cadence and delivery passes.

import (
	"context"
	"fmt"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"github.com/seaweedfs/seaweedfs/weed/filer"
	"github.com/seaweedfs/seaweedfs/weed/pb/filer_pb"
	"github.com/seaweedfs/seaweedfs/weed/util"
)

// vrfPromptDelivery bounds how long after a release an entry may take to reach
// the subscriber.
const vrfPromptDelivery = 500 * time.Millisecond

// vrfCountingStore wraps a filer.FilerStore and counts directory listings that
// target the system log dir: the repeated work a parked subscriber performs
// when it re-runs the persisted-log pass. Every other store call passes through
// unchanged, so the loop behaves exactly as with the real store.
type vrfCountingStore struct {
	filer.FilerStore
	logLists *atomic.Int64
}

func (s *vrfCountingStore) ListDirectoryPrefixedEntries(ctx context.Context, dirPath util.FullPath, startFileName string, includeStartFile bool, limit int64, prefix string, eachEntryFunc filer.ListEachEntryFunc) (lastFileName string, err error) {
	if strings.HasPrefix(string(dirPath), filer.SystemLogDir) {
		s.logLists.Add(1)
	}
	return s.FilerStore.ListDirectoryPrefixedEntries(ctx, dirPath, startFileName, includeStartFile, limit, prefix, eachEntryFunc)
}

// vrfWaitFirstListing returns once the subscriber's first persisted-log pass
// has listed the log dir, so a measurement window starts after it on any
// machine speed.
func vrfWaitFirstListing(t *testing.T, lists *atomic.Int64) {
	t.Helper()
	for deadline := time.Now().Add(3 * time.Second); time.Now().Before(deadline); {
		if lists.Load() > 0 {
			return
		}
		time.Sleep(5 * time.Millisecond)
	}
	t.Fatal("the subscriber never listed the persisted log")
}

// vrfAfterNextPass returns just after the subscriber's next persisted-log
// pass has finished, or after a few seconds if it makes none. Releasing an
// entry right then means a loop that only finds it on a timed re-probe waits
// a whole re-probe period, whatever that period is.
func vrfAfterNextPass(lists *atomic.Int64) {
	start := lists.Load()
	for deadline := time.Now().Add(3 * time.Second); time.Now().Before(deadline) && lists.Load() == start; {
		time.Sleep(time.Millisecond)
	}
	for last, deadline := lists.Load(), time.Now().Add(3*time.Second); time.Now().Before(deadline); {
		time.Sleep(50 * time.Millisecond)
		now := lists.Load()
		if now == last {
			return
		}
		last = now
	}
}

// vrfDeliveredPromptly waits for want and fails if it arrived later than
// vrfPromptDelivery after releasedAt.
func vrfDeliveredPromptly(t *testing.T, r *runningSubscribe, want []int64, releasedAt time.Time, what string) {
	t.Helper()
	waitForEvents(t, r, want, time.Until(releasedAt)+3*time.Second)
	late := time.Since(releasedAt)
	t.Logf("%s arrived %v after its release", what, late.Round(time.Millisecond))
	if late > vrfPromptDelivery {
		t.Fatalf("%s arrived %v after its release, want within %v", what, late.Round(time.Millisecond), vrfPromptDelivery)
	}
}

// vrfWritePeerLogFile lands one event in the shared store the way another
// filer's flush does: a minute file under the system log dir carrying that
// filer's own id suffix. Nothing on this filer's local buffer moves.
func vrfWritePeerLogFile(t *testing.T, h *subscribeHarness, tsNs int64) {
	t.Helper()
	entry := testEvent(tsNs, fmt.Sprintf("p-%d", tsNs))
	body, err := entry.MarshalVT()
	if err != nil {
		t.Fatalf("marshal peer entry: %v", err)
	}
	data := make([]byte, 4, 4+len(body))
	util.Uint32toBytes(data, uint32(len(body)))
	data = append(data, body...)

	at := time.Unix(0, tsNs).UTC()
	fullpath := util.FullPath(fmt.Sprintf("%s/%04d-%02d-%02d/%02d-%02d.%s", filer.SystemLogDir,
		at.Year(), at.Month(), at.Day(), at.Hour(), at.Minute(), "0000beef"))
	file := &filer.Entry{
		FullPath: fullpath,
		Attr:     filer.Attr{Crtime: time.Now(), Mtime: time.Now(), Mode: 0644},
		Chunks: []*filer_pb.FileChunk{{
			FileId:       h.vol.put(data),
			Size:         uint64(len(data)),
			ModifiedTsNs: time.Now().UnixNano(),
		}},
	}
	if err := h.f.CreateEntry(context.Background(), file, nil, false, false, nil, false, 255); err != nil {
		t.Fatalf("write peer log file %s: %v", fullpath, err)
	}
}

// TestVerify_AggregatedNoPersistedRescanAfterStart parks a subscriber past the
// end of the persisted log with the peers' watermarks stuck at the old tail, and
// asserts two things: the persisted-log listings stay at a few passes per
// window instead of climbing with every wake (the idle subscriber is
// not burning the disk pass on every wake), and once peer progress advances
// through the held ring entries the previously-parked subscriber promptly
// delivers that backlog, from the ring, without another listing storm. A loop
// that re-lists on every wake fails the listing bound; a loop that throttles
// itself with a sleep long enough to pass that bound fails the delivery bound.
func TestVerify_AggregatedNoPersistedRescanAfterStart(t *testing.T) {
	h := newSubscribeHarness(t)

	lists := &atomic.Int64{}
	h.f.SetStore(&vrfCountingStore{FilerStore: h.f.GetStore(), logLists: lists})

	// Persisted log ends at T1: one flushed window, nothing after.
	h.append(h.tsAt(0, 0))
	h.append(h.tsAt(0, 1))
	h.f.LocalMetaLogBuffer.ForceFlush()
	waitForFlushedFiles(t, h, h.tsAt(0, 1))

	// Client cursor sits just past the last persisted entry.
	cursor := h.tsAt(0, 1) + int64(time.Millisecond)

	ma := h.startAggregator()

	// Aggregated ring holds only much newer entries (peer events).
	recent := time.Now().UnixNano()
	h.appendAggregated(recent)
	h.appendAggregated(recent + int64(time.Millisecond))

	// Peers' watermarks are stuck at the old log tail: nothing new is admitted.
	reportPeersAt(ma, h.tsAt(0, 1), h.tsAt(0, 1))

	r := h.subscribeAggregated(cursor)

	// Warm up: the first pass plus the cursor-move re-read after the gap
	// machinery re-arms the cursor are legitimate.
	vrfWaitFirstListing(t, lists)
	time.Sleep(150 * time.Millisecond)

	// One pass lists the day dir and the day's files. Over two seconds the
	// unfixed loop lists more than sixty times; a loop that only looks again
	// when something moved, or on a re-probe about once a second or slower,
	// stays within three passes.
	const window, maxLists = 2 * time.Second, 6
	before := lists.Load()
	time.Sleep(window)
	got := lists.Load() - before
	t.Logf("%d persisted-log listings in %v while parked", got, window)
	if got > maxLists {
		t.Fatalf("%d persisted-log listings in %v while parked, want at most %d; the disk pass re-ran on every wake", got, window, maxLists)
	}

	// On a live cluster the peers' delivery watermark climbs with every event
	// they stream. Climbing below the held ring entries, it wakes the parked
	// read but admits nothing on disk, so it is no reason to list the log.
	stepBase := recent - int64(time.Minute)
	before = lists.Load()
	for i, deadline := 1, time.Now().Add(window); time.Now().Before(deadline); i++ {
		reportPeersAt(ma, stepBase+int64(i)*int64(time.Millisecond), h.tsAt(0, 1))
		time.Sleep(5 * time.Millisecond)
	}
	got = lists.Load() - before
	t.Logf("%d persisted-log listings in %v of delivery-only progress", got, window)
	if got > maxLists {
		t.Fatalf("%d persisted-log listings in %v of delivery-only progress, want at most %d; delivery progress re-ran the disk pass", got, window, maxLists)
	}

	// Peer progress through the held entries releases the read: the held events
	// are delivered promptly and without another persisted-log pass.
	lists.Store(0)
	released := time.Now()
	reportPeersAt(ma, recent+int64(time.Millisecond), h.tsAt(0, 1))
	vrfDeliveredPromptly(t, r, []int64{recent, recent + int64(time.Millisecond)}, released, "the held ring backlog")
	if got := lists.Load(); got > 4 {
		t.Fatalf("%d listings while draining held entries; delivery should come from the ring", got)
	}
}

// TestVerify_AggregatedDiskHoldReleasesOnFlush pins that each hold parks on its
// own watermark. A persisted-log read is held by what the peers have FLUSHED,
// and peers advance their DELIVERY watermark on every event they stream. A loop
// that treats delivery progress as a reason to re-read the disk would re-list a
// day of log files per delivery advance and re-park on the same entry; a loop
// that skips the disk pass outright while a hold is pending would never deliver
// the held entry at all, and one that waits for a timed re-probe delivers it
// late. The held on-disk entry must sit quiet under delivery-only progress and
// arrive promptly once the flush watermark reaches it.
func TestVerify_AggregatedDiskHoldReleasesOnFlush(t *testing.T) {
	h := newSubscribeHarness(t)
	prevRetry := unflushedGapRetryInterval
	unflushedGapRetryInterval = 500 * time.Millisecond
	t.Cleanup(func() { unflushedGapRetryInterval = prevRetry })

	// Recent enough that the settled horizon does not take the hold over.
	onDisk := time.Now().Add(-30 * time.Second).UnixNano()
	h.append(onDisk)
	h.f.LocalMetaLogBuffer.ForceFlush()
	waitForFlushedFiles(t, h, onDisk)

	ma := h.startAggregator()
	// Flushed below the entry on disk, delivered well past it: only the disk
	// pass is held.
	reportPeersAt(ma, time.Now().UnixNano(), onDisk-int64(time.Second))
	r := h.subscribeAggregated(onDisk - int64(5*time.Second))
	assertNoEventsFor(t, r, 200*time.Millisecond)

	holdsBefore := heldReads("disk")
	start := time.Now()
	for deadline := start.Add(time.Second); time.Now().Before(deadline); {
		reportPeersAt(ma, time.Now().UnixNano(), 0)
		time.Sleep(2 * time.Millisecond)
	}
	holds, elapsed := heldReads("disk")-holdsBefore, time.Since(start)

	t.Logf("%v of delivery-only progress produced %d disk holds", elapsed, holds)
	if maxHolds := int(elapsed/unflushedGapRetryInterval) + 2; holds > maxHolds {
		t.Fatalf("held on disk %d times in %v, want at most %d: delivery progress cannot release a flush hold",
			holds, elapsed, maxHolds)
	}

	// The flush watermark reaching the entry is what delivers it.
	released := time.Now()
	reportPeersAt(ma, 0, onDisk)
	vrfDeliveredPromptly(t, r, []int64{onDisk}, released, "the flush-held disk entry")
}

// TestVerify_AggregatedDiskHoldReleasesOnSettledHorizon covers the other way a
// disk hold ends. The peers' flush watermark never moves here; the entry is
// released only because it ages past the settled horizon, the liveness escape
// for a stalled peer. Nothing a watermark signals changes, so the loop has to
// keep re-reading while the hold is pending, and the entry must arrive promptly
// once the horizon passes it, not on some later timed re-probe.
func TestVerify_AggregatedDiskHoldReleasesOnSettledHorizon(t *testing.T) {
	h := newSubscribeHarness(t)
	prevHorizon := metadataGapSettledHorizon
	metadataGapSettledHorizon = 3 * time.Second
	t.Cleanup(func() { metadataGapSettledHorizon = prevHorizon })

	onDisk := time.Now().Add(-500 * time.Millisecond).UnixNano()
	h.append(onDisk)
	h.f.LocalMetaLogBuffer.ForceFlush()
	waitForFlushedFiles(t, h, onDisk)

	ma := h.startAggregator()
	// Both peers stalled a minute back: only the horizon can admit the entry.
	stalled := onDisk - int64(time.Minute)
	reportPeersAt(ma, stalled, stalled)
	r := h.subscribeAggregated(onDisk - int64(5*time.Second))

	released := time.Unix(0, onDisk+int64(metadataGapSettledHorizon))
	if quiet := time.Until(released) - 200*time.Millisecond; quiet > 0 {
		assertNoEventsFor(t, r, quiet)
	}
	vrfDeliveredPromptly(t, r, []int64{onDisk}, released, "the horizon-held disk entry")
}

// TestVerify_AggregatedPeerFlushDeliversDiskBacklog covers a disk backlog that
// only another filer produced. The subscriber is parked past the local log's
// end with newer ring entries held by the delivery watermark; then a peer
// flushes an event into the shared store and both peer watermarks move up to
// it. The local buffer never flushes, so only the peers' progress tells the
// loop that the persisted log now holds something for this subscriber. The
// event must arrive promptly and in order, ahead of the still-held ring entries.
func TestVerify_AggregatedPeerFlushDeliversDiskBacklog(t *testing.T) {
	h := newSubscribeHarness(t)

	lists := &atomic.Int64{}
	h.f.SetStore(&vrfCountingStore{FilerStore: h.f.GetStore(), logLists: lists})

	h.append(h.tsAt(0, 0))
	h.append(h.tsAt(0, 1))
	h.f.LocalMetaLogBuffer.ForceFlush()
	waitForFlushedFiles(t, h, h.tsAt(0, 1))
	cursor := h.tsAt(0, 1) + int64(time.Millisecond)

	ma := h.startAggregator()
	recent := time.Now().UnixNano()
	h.appendAggregated(recent)
	h.appendAggregated(recent + int64(time.Millisecond))
	reportPeersAt(ma, h.tsAt(0, 1), h.tsAt(0, 1))

	r := h.subscribeAggregated(cursor)
	vrfWaitFirstListing(t, lists)
	assertNoEventsFor(t, r, 300*time.Millisecond)
	vrfAfterNextPass(lists)

	// Inside the settled horizon, so only the peers' watermarks admit it, and
	// below the ring entries, which stay held.
	peerTs := recent - int64(30*time.Second)
	vrfWritePeerLogFile(t, h, peerTs)
	released := time.Now()
	reportPeersAt(ma, peerTs, peerTs)
	vrfDeliveredPromptly(t, r, []int64{peerTs}, released, "the peer-flushed disk event")
}

// TestVerify_NormalStreamingBacklogThenLiveExactlyOnce confirms a subscriber
// whose start position is within the persisted log still receives every
// historical and live event, in order, exactly once. Timestamps are 1ms-adjacent
// across every boundary (window to window on disk, and disk to retained memory),
// so a cursor error of even one entry at any handoff shows up as a hole or a
// duplicate. A fix that gates the disk pass too aggressively would drop or
// reorder backlog here.
func TestVerify_NormalStreamingBacklogThenLiveExactlyOnce(t *testing.T) {
	h := newSubscribeHarness(t)

	ts := func(i int) int64 { return h.base + int64(i)*int64(time.Millisecond) }

	var want []int64
	n := 0
	for w := 0; w < 3; w++ {
		for i := 0; i < 3; i++ {
			want = append(want, ts(n))
			h.append(ts(n))
			n++
		}
		h.f.LocalMetaLogBuffer.ForceFlush() // adjacent-timestamp window boundary on disk
	}
	// A retained, unflushed tail starting 1ms after the flushed content ends.
	for i := 0; i < 3; i++ {
		want = append(want, ts(n))
		h.append(ts(n))
		n++
	}

	r := h.subscribe(0, nil)
	waitForEvents(t, r, want, 5*time.Second)

	// Live tail on top.
	live := []int64{ts(n), ts(n + 1)}
	for _, l := range live {
		h.append(l)
	}
	waitForEvents(t, r, append(append([]int64(nil), want...), live...), 5*time.Second)
}
