// @ts-nocheck
//
// Native vitest behavioural tests for vuejs-core-fix-vapor-dynamic-refs.
//
// Every test drives only pre-existing, stable public entry points of the
// runtime-vapor package (re-exported from `../../src`):
//   - createTemplateRefSetter()      the ref-apply closure
//   - createDynamicComponent()       `<component :is>` in Vapor
//   - defineVaporComponent()         Vapor child components
//   - defineVaporAsyncComponent()    async wrapper
//   - vaporInteropPlugin (via makeInteropRender) for vdom interop
// plus the public `useTemplateRef` / `watchEffect` / `ref` from
// `@vue/runtime-dom`. No fix-introduced internal symbol is imported. These
// are the exact interfaces the maintainers' own specs exercise, so the
// behavioural contract is observable through the calling convention alone.
//
// File copied by the JS runner into
// packages/runtime-vapor/__tests__/dom/, so the relative imports below
// resolve the same way the repo's own dom/templateRef.spec.ts does.
//
// Every assertion is behavioural: it observes ref.value identity, function-ref
// call arguments, rendered html, or dev-warning state through the public
// calling convention. No test reads an internal fix field, so any correct
// re-apply design — the onUpdated-array + WeakMap de-dup, a dedicated
// single-field update hook, etc. — is accepted on equal terms.

import {
  createComponent,
  createDynamicComponent,
  createTemplateRefSetter,
  defineVaporComponent,
  insert,
  renderEffect,
  template,
} from '../../src'
import { makeInteropRender, makeRender } from '../_utils'
import {
  type ShallowRef,
  defineComponent,
  h,
  nextTick,
  ref,
  shallowRef,
  useTemplateRef,
  watchEffect,
} from '@vue/runtime-dom'
import { defineVaporAsyncComponent } from '../../src/apiDefineAsyncComponent'
import type { VaporComponent } from '../../src/component'

const define = makeRender()
const defineInterop = makeInteropRender()
const timeout = (n = 0) => new Promise(r => setTimeout(r, n))

describe('vapor dynamic/async template refs', () => {
  // ── Criterion 1 (basic_functionality) ──────────────────────────────────
  // Switching the inner component of a dynamic component updates the bound
  // ref to the NEW child's exposed value; calling through the ref runs the
  // new child's method. Pre-change, the ref is applied once at bind time and
  // never re-applied on switch, so `refKey.value.setMsg()` still targets
  // Child1 and `msg` stays 'one'.
  test('dynamic component ref updates to the new child on switch', async () => {
    const msg = ref('')
    const Child1 = defineVaporComponent({
      setup(_, { expose }) {
        expose({ setMsg: () => (msg.value = 'one') })
        return template(`<div>1`)()
      },
    })
    const Child2 = defineVaporComponent({
      setup(_, { expose }) {
        expose({ setMsg: () => (msg.value = 'two') })
        return template(`<div>2`)()
      },
    })

    const view = shallowRef(Child1)
    const refKey = ref<any>(null)

    const { html } = define({
      setup() {
        const setRef = createTemplateRefSetter()
        const n0 = createDynamicComponent(() => view.value) as any
        setRef(n0, refKey)
        return n0
      },
    }).render()

    expect(refKey.value).toBeDefined()
    expect(html()).toBe('<div>1</div><!--dynamic-component-->')
    refKey.value.setMsg()
    expect(msg.value).toBe('one')

    view.value = Child2
    await nextTick()
    expect(html()).toBe('<div>2</div><!--dynamic-component-->')
    refKey.value.setMsg()
    expect(msg.value).toBe('two')
  })

  // ── Criterion 2 ──────────────────────────────────────────────────
  // A useTemplateRef-bound ref reactively reflects each dynamic switch,
  // observed through a watchEffect, including switching back to the first
  // child. Pre-change the watchEffect only ever sees 'one'.
  test('useTemplateRef reflects each dynamic-component switch', async () => {
    const One = defineVaporComponent({
      setup(_, { expose }) {
        expose({ name: 'one' })
        return template('<div>one</div>')()
      },
    })
    const Two = defineVaporComponent({
      setup(_, { expose }) {
        expose({ name: 'two' })
        return template('<div>two</div>')()
      },
    })

    const views: VaporComponent[] = [One, Two]
    const view = ref(0)
    const refNames: string[] = []
    let compRef: ShallowRef

    const { html } = define({
      setup() {
        compRef = useTemplateRef('compRef')
        watchEffect(() => {
          const value = compRef.value as { name?: string } | null
          if (value?.name) refNames.push(value.name)
        })
        const setRef = createTemplateRefSetter()
        const n0 = createDynamicComponent(() => views[view.value]) as any
        setRef(n0, compRef, false, 'compRef')
        return n0
      },
    }).render()

    await nextTick()
    const one = compRef!.value
    expect(one).toMatchObject({ name: 'one' })
    expect(html()).toBe('<div>one</div><!--dynamic-component-->')

    view.value = 1
    await nextTick()
    const two = compRef!.value
    expect(two).toMatchObject({ name: 'two' })
    expect(two).not.toBe(one)
    expect(html()).toBe('<div>two</div><!--dynamic-component-->')

    view.value = 0
    await nextTick()
    expect(compRef!.value).toMatchObject({ name: 'one' })
    expect(compRef!.value).not.toBe(two)
    expect(refNames).toContain('two')
  })

  // ── Criterion 3 ──────────────────────────────────────────────────
  // Repeated ref application inside a renderEffect must register EXACTLY ONE
  // deferred re-apply, not one per re-run. Observed behaviourally: a single
  // bound function ref is re-applied by forcing the renderEffect to re-run
  // several times (without switching the child), then the child is switched
  // ONCE. The deferred re-apply must fire a bounded number of times for that
  // single switch — a null cleanup of the old branch plus the new child —
  // regardless of how many times the renderEffect previously re-ran. The
  // naive fix that pushes a fresh handler per re-run accumulates, so the one
  // switch fans the function ref out N-fold. Pre-change there is no deferred
  // re-apply at all, so the switch never re-invokes the ref.
  test('dynamic component registers exactly one re-apply handler', async () => {
    const One = defineVaporComponent({
      setup: () => template('<div>one</div>')(),
    })
    const Two = defineVaporComponent({
      setup: () => template('<div>two</div>')(),
    })

    const views: VaporComponent[] = [One, Two]
    const view = ref(0)
    const bump = ref(0)
    const fnRef = vi.fn()
    let frag: any

    define({
      setup() {
        const setRef = createTemplateRefSetter()
        frag = createDynamicComponent(() => views[view.value]) as any
        renderEffect(() => {
          // Track `bump` (not `view`) so re-runs come from here, and the child
          // switch below exercises only the deferred re-apply path.
          bump.value
          setRef(frag, fnRef as any)
        })
        return frag
      },
    }).render()

    // Force the renderEffect to re-run several times with the SAME bound ref.
    // Correct de-dup keeps exactly one deferred re-apply handler; the naive
    // push-per-run bug accumulates one per re-run.
    bump.value++
    await nextTick()
    bump.value++
    await nextTick()
    bump.value++
    await nextTick()
    const beforeSwitch = fnRef.mock.calls.length

    // One child switch: the deferred re-apply fires once (null cleanup of the
    // old branch + the new child), independent of the prior re-run count.
    view.value = 1
    await nextTick()
    const switchCalls = fnRef.mock.calls.length - beforeSwitch

    // The re-apply must fire for the switch (so the ref tracks the new child)…
    expect(switchCalls).toBeGreaterThan(0)
    // …but not fan out with the number of prior renderEffect re-runs. A single
    // deferred re-apply yields a null cleanup + one new value (2 calls); the
    // accumulating bug produces one re-apply per prior re-run (>= 8 here).
    expect(switchCalls).toBeLessThanOrEqual(3)
  })

  // ── Criterion 4 ──────────────────────────────────────────────────
  // When the bound ref OBJECT itself switches (refA -> refB), the old ref is
  // nulled, only the active ref holds the value, and tracking transfers to the
  // new ref: a SUBSEQUENT child switch re-applies to refB (not the detached
  // refA). Pre-change, the deferred re-apply is not re-registered against the
  // new ref, so after the later child switch refB keeps the pre-switch child
  // and never advances to the new one.
  test('rebinding the ref object transfers tracking to the new ref', async () => {
    const One = defineVaporComponent({
      setup(_, { expose }) {
        expose({ name: 'one' })
        return template('<div>one</div>')()
      },
    })
    const Two = defineVaporComponent({
      setup(_, { expose }) {
        expose({ name: 'two' })
        return template('<div>two</div>')()
      },
    })

    const views: VaporComponent[] = [One, Two]
    const view = ref(0)
    const useA = ref(true)
    const refA = ref<any>(null)
    const refB = ref<any>(null)

    define({
      setup() {
        const setRef = createTemplateRefSetter()
        const n0 = createDynamicComponent(() => views[view.value]) as any
        renderEffect(() => {
          setRef(n0, useA.value ? refA : refB)
        })
        return n0
      },
    }).render()

    await nextTick()
    expect(refA.value).toMatchObject({ name: 'one' })
    expect(refB.value).toBe(null)

    // Rebind the ref object refA -> refB (child still One): the old ref is
    // nulled and the active ref holds the current value.
    useA.value = false
    await nextTick()
    expect(refA.value).toBe(null)
    expect(refB.value).toMatchObject({ name: 'one' })

    // A later child switch must re-apply to the now-active refB; the detached
    // refA must stay null.
    view.value = 1
    await nextTick()
    expect(refA.value).toBe(null)
    expect(refB.value).toMatchObject({ name: 'two' })
  })

  // ── Criterion 5 ──────────────────────────────────────────────────
  // A function ref on a dynamic component is invoked with `null` to clean up
  // the old branch before receiving the new value, and swapping the function
  // ref itself clears the old callback with null. Pre-change neither cleanup
  // happens (never called with null) and the switch does not re-invoke.
  test('dynamic component function ref cleans up with null on switch', async () => {
    const One = defineVaporComponent({
      setup(_, { expose }) {
        expose({ name: 'one' })
        return template('<div>one</div>')()
      },
    })
    const Two = defineVaporComponent({
      setup(_, { expose }) {
        expose({ name: 'two' })
        return template('<div>two</div>')()
      },
    })

    const views: VaporComponent[] = [One, Two]
    const view = ref(0)
    const fnRef = vi.fn()

    define({
      setup() {
        const setRef = createTemplateRefSetter()
        const n0 = createDynamicComponent(() => views[view.value]) as any
        setRef(n0, fnRef as any)
        return n0
      },
    }).render()

    expect(fnRef).toHaveBeenCalledTimes(1)
    expect(fnRef.mock.calls[0][0]).toMatchObject({ name: 'one' })

    view.value = 1
    await nextTick()

    const callArgs = fnRef.mock.calls.map(args => args[0])
    expect(callArgs).toContain(null)
    expect(fnRef.mock.calls[fnRef.mock.calls.length - 1][0]).toMatchObject({
      name: 'two',
    })
  })

  test('dynamic component function ref cleans up previous callback when the ref changes', async () => {
    const One = defineVaporComponent({
      setup(_, { expose }) {
        expose({ name: 'one' })
        return template('<div>one</div>')()
      },
    })

    const useA = ref(true)
    const fnA = vi.fn()
    const fnB = vi.fn()

    define({
      setup() {
        const setRef = createTemplateRefSetter()
        const n0 = createDynamicComponent(() => One) as any
        renderEffect(() => {
          setRef(n0, useA.value ? (fnA as any) : (fnB as any))
        })
        return n0
      },
    }).render()

    expect(fnA.mock.calls[fnA.mock.calls.length - 1][0]).toMatchObject({
      name: 'one',
    })
    expect(fnB).toHaveBeenCalledTimes(0)

    useA.value = false
    await nextTick()

    const fnAArgs = fnA.mock.calls.map(args => args[0])
    expect(fnAArgs).toContain(null)
    expect(fnB.mock.calls[fnB.mock.calls.length - 1][0]).toMatchObject({
      name: 'one',
    })
  })

  // ── Criterion 5b: ref-for sibling preservation ───────────────────
  // ref-for on dynamic components: updating one branch keeps the sibling's
  // value instead of wiping the whole array. Pre-change the ref-for cleanup on
  // the DynamicFragment path does not scope to a single branch.
  test('dynamic ref_for keeps sibling refs when one branch updates', async () => {
    const One = defineVaporComponent({
      setup(_, { expose }) {
        expose({ name: 'one' })
        return template('<div>one</div>')()
      },
    })
    const Two = defineVaporComponent({
      setup(_, { expose }) {
        expose({ name: 'two' })
        return template('<div>two</div>')()
      },
    })

    const views: VaporComponent[] = [One, Two]
    const view = ref(0)
    const listRef = ref<any[]>([])

    define({
      setup() {
        return { listRef }
      },
      render() {
        const n0 = template('<div></div>')() as Element
        const setRef = createTemplateRefSetter()
        const n1 = createDynamicComponent(() => views[view.value]) as any
        const n2 = createDynamicComponent(() => One) as any
        setRef(n1, listRef as any, true)
        setRef(n2, listRef as any, true)
        insert(n1, n0 as ParentNode)
        insert(n2, n0 as ParentNode)
        return n0
      },
    }).render()

    await nextTick()
    expect(listRef.value).toHaveLength(2)
    expect(listRef.value.filter(i => i?.name === 'one')).toHaveLength(2)

    view.value = 1
    await nextTick()
    expect(listRef.value).toHaveLength(2)
    expect(listRef.value.filter(i => i?.name === 'one')).toHaveLength(1)
    expect(listRef.value.some(i => i?.name === 'two')).toBe(true)
  })

  // ── Criterion 6: vdom interop ────────────────────────────────────
  // A dynamic component that renders a vdom (interop) child resolves the ref
  // to the vdom child's exposed value, and cleans up the old ref when the
  // bound target switches. Pre-change the interop branch never fires for the
  // exposed-value case, so the ref comes back undefined/null.
  test('dynamic component resolves a vdom interop child ref', async () => {
    const vdomRef = ref<any>(null)
    const VdomChild = defineComponent({
      setup(_, { expose }) {
        expose({ name: 'vdomChild' })
        return () => h('div', 'vdom child')
      },
    })

    const VaporChild = defineVaporComponent({
      setup() {
        return { vdomRef }
      },
      render() {
        const setRef = createTemplateRefSetter()
        const n0 = createDynamicComponent(() => VdomChild)
        setRef(n0, vdomRef, false, 'vdomRef')
        return n0
      },
    })

    defineInterop({
      setup() {
        return () => h(VaporChild as any)
      },
    }).render()

    await nextTick()
    expect(vdomRef.value).toBeDefined()
    expect(vdomRef.value.name).toBe('vdomChild')
  })

  test('dynamic vdom interop child ref cleans up the old ref on switch', async () => {
    const VdomChild = defineComponent({
      setup(_, { expose }) {
        expose({ name: 'vdomChild' })
        return () => h('div', 'vdom child')
      },
    })

    const useA = ref(true)
    const refA = ref<any>(null)
    const refB = ref<any>(null)

    const VaporChild = defineVaporComponent({
      setup() {
        const setRef = createTemplateRefSetter()
        const n0 = createDynamicComponent(() => VdomChild)
        renderEffect(() => {
          setRef(n0, useA.value ? refA : refB, false, 'vdomRef')
        })
        return n0
      },
    })

    defineInterop({
      setup() {
        return () => h(VaporChild as any)
      },
    }).render()

    await nextTick()
    expect(refA.value).toBeDefined()
    expect(refA.value.name).toBe('vdomChild')
    expect(refB.value).toBe(null)

    useA.value = false
    await nextTick()
    expect(refA.value).toBe(null)
    expect(refB.value).toBeDefined()
    expect(refB.value.name).toBe('vdomChild')
  })

  // ── Criterion 7: null/undefined key, no warning ──────────────────
  // A dynamic ref whose key becomes null/undefined clears the old ref value
  // and does NOT emit the "Invalid template ref type:" dev warning; a valid
  // key re-binds. Pre-change a null key falls through to the warn() branch and
  // does not clear. The unasserted-warning guard in setup-vitest.ts would
  // additionally throw on any stray warn.
  test('null/undefined dynamic ref key clears without warning', async () => {
    const t0 = template('<div></div>')
    const el = ref(null)
    const refKey = ref<any>('foo')

    const { render } = define({
      setup() {
        return { foo: el }
      },
      render() {
        const n0 = t0()
        const setRef = createTemplateRefSetter()
        renderEffect(() => {
          setRef(n0 as Element, refKey.value)
        })
        return n0
      },
    })

    const { host } = render()
    expect(el.value).toBe(host.children[0])

    refKey.value = null
    await nextTick()
    expect(el.value).toBe(null)
    expect('Invalid template ref type:').not.toHaveBeenWarned()

    refKey.value = 'foo'
    await nextTick()
    expect(el.value).toBe(host.children[0])

    refKey.value = undefined
    await nextTick()
    expect(el.value).toBe(null)
    expect('Invalid template ref type:').not.toHaveBeenWarned()
  })

  // ── Criterion 8: async wrapper forwarding ────────────────────────
  // A ref forwarded to an async wrapper is applied to the inner instance once
  // resolved, and does not retain stale callbacks when the bound ref target
  // changes AFTER resolution. Pre-change the resolved inner instance is applied
  // only to the ref captured at register time, so a post-resolve ref switch
  // leaks the inner instance into the wrong ref and never clears the old one.
  //
  // (A pre-resolve ref switch is intentionally NOT a separate case: the old
  // capture-at-register indirection already overwrote its single captured ref
  // on each re-register, so that scenario resolves correctly on both the pre-
  // and post-change code and so cannot tell them apart. The post-resolve case
  // below is the behavior that is actually broken pre-change.)
  test('async wrapper ref forwarding drops stale callbacks after resolve', async () => {
    let resolve: (comp: VaporComponent) => void
    const Foo = defineVaporAsyncComponent(
      () =>
        new Promise(r => {
          resolve = r as any
        }),
    )

    const refA = ref<any>(null)
    const refB = ref<any>(null)
    const useA = ref(true)
    const root = document.createElement('div')

    const { mount } = define({
      setup() {
        return { refA, refB, useA }
      },
      render() {
        const setTemplateRef = createTemplateRefSetter()
        const n0 = createComponent(Foo, null, null, true)
        renderEffect(() => {
          setTemplateRef(n0, useA.value ? 'refA' : 'refB')
        })
        return n0
      },
    }).create()

    mount(root)
    expect(refA.value).toBe(null)
    expect(refB.value).toBe(null)

    resolve!({
      setup: (props, { expose }) => {
        expose({ id: 'foo' })
        return template('resolved')()
      },
    })
    await timeout()

    expect(root.innerHTML).toBe('resolved<!--async component-->')
    expect(refA.value.id).toBe('foo')
    expect(refB.value).toBe(null)

    useA.value = false
    await nextTick()
    expect(refA.value).toBe(null)
    expect(refB.value.id).toBe('foo')
  })

  // ── Criterion 9: static refs still work ──────────────────────────
  // Ordinary element and component template refs must still resolve to the
  // host element / exposed value — the fix must not regress the base path.
  test('plain element and component refs still resolve (regression guard)', async () => {
    const elRef = ref<any>(null)
    const childRef = ref<any>(null)

    const Child = defineVaporComponent({
      setup(_, { expose }) {
        expose({ name: 'child' })
        return template('<span>child</span>')()
      },
    })

    const { host } = define({
      setup() {
        return { elRef, childRef }
      },
      render() {
        const setRef = createTemplateRefSetter()
        const n0 = template('<div></div>')() as Element
        const n1 = createComponent(Child)
        setRef(n0, elRef, false, 'elRef')
        setRef(n1 as any, childRef, false, 'childRef')
        insert(n1, n0 as ParentNode)
        return n0
      },
    }).render()

    await nextTick()
    expect(elRef.value).toBe(host.children[0])
    expect(childRef.value).toMatchObject({ name: 'child' })
  })
})
