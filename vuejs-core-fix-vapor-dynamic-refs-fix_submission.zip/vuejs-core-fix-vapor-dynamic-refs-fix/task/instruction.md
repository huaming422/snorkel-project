## Task

in vapor mode, template refs on dynamic components are broken. bind a ref to a `<component :is="...">` and read it back through `useTemplateRef` (or a plain ref, or a function ref): the moment the dynamic component switches to a different child, the ref still points at the old one, so reading it gives the previous component's exposed api instead of the new child's.

it gets worse. if the dynamic component renders an ordinary, non-vapor child, the ref comes back `undefined`. when the ref's key legitimately goes `null` or `undefined`, we log a bogus "invalid template ref" warning in dev even though there's nothing to point at. and switching the child, or which ref is bound, leaves the old ref holding its stale value; nothing clears it.

plain static refs are fine, it's specifically the dynamic and async ones that fall over. dig into how vapor applies template refs for dynamic and async components and make them track the current child, clear the old value on every switch, and stop warning on empty keys. how users declare refs shouldn't change.
