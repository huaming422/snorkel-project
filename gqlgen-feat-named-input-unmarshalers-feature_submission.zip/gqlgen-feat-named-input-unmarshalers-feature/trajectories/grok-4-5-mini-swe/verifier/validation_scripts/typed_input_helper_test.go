package singlefile

import (
	"context"
	"strings"
	"testing"

	"github.com/99designs/gqlgen/client"
	"github.com/99designs/gqlgen/graphql/handler"
	"github.com/stretchr/testify/require"
)

func TestTh2TypedInputHelper(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			targetInput := tc.Inputs["target_input"].(string)
			rawVal := tc.Inputs["raw"]

			// Read expected values
			errorSubstring := tc.Expected["error_substring"].(string)
			keptFieldsRaw := tc.Expected["kept_fields"].([]interface{})
			absentFieldsRaw := tc.Expected["absent_fields"].([]interface{})
			keptFields := make([]string, len(keptFieldsRaw))
			for i, v := range keptFieldsRaw {
				keptFields[i] = v.(string)
			}
			absentFields := make([]string, len(absentFieldsRaw))
			for i, v := range absentFieldsRaw {
				absentFields[i] = v.(string)
			}

			var capturedOut map[string]any
			var capturedErr error

			resolvers := &Stub{}
			resolvers.QueryResolver.DefaultScalar = func(ctx context.Context, arg string) (string, error) {
				switch targetInput {
				case "SearchFilters":
					capturedOut, capturedErr = UnmarshalSearchFilters(ctx, rawVal)
				case "DirectiveInput":
					capturedOut, capturedErr = UnmarshalDirectiveInput(ctx, rawVal)
				default:
					t.Errorf("unknown target_input: %s", targetInput)
				}
				return arg, nil
			}
			srv := handler.NewDefaultServer(NewExecutableSchema(Config{Resolvers: resolvers}))
			var resp struct{ DefaultScalar string }
			postErr := client.New(srv).Post(`query { defaultScalar(arg: "hi") }`, &resp)
			require.NoError(t, postErr, "server request must succeed")

			// Assert error
			switch errorSubstring {
			case "__skip__":
				require.NoError(t, capturedErr, "expected no error")
			case "__any__":
				require.Error(t, capturedErr, "expected some error")
			default:
				require.Error(t, capturedErr, "expected a non-nil error")
				require.True(t, strings.Contains(capturedErr.Error(), errorSubstring),
					"error %q must contain %q", capturedErr.Error(), errorSubstring)
			}

			// Assert kept_fields
			for _, k := range keptFields {
				_, present := capturedOut[k]
				require.True(t, present, "field %q must be present in result %v", k, capturedOut)
			}
			// Assert absent_fields
			for _, k := range absentFields {
				_, present := capturedOut[k]
				require.False(t, present, "field %q must NOT be present in result %v", k, capturedOut)
			}
		})
	}
}
