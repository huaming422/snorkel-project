package singlefile

import (
	"context"
	"strings"
	"sync"
	"testing"

	"github.com/99designs/gqlgen/client"
	"github.com/99designs/gqlgen/graphql"
	"github.com/99designs/gqlgen/graphql/handler"
	"github.com/stretchr/testify/require"
)

func TestNm1NamedInputUnmarshal(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			inputName := tc.Inputs["input_name"].(string)
			// raw may be nil (driver converts "__null__" to JSON null → Go nil)
			rawVal := tc.Inputs["raw"]
			useReqCtx := tc.Inputs["use_request_context"].(string)
			parallel := int(tc.Inputs["parallel"].(float64))

			// Read expected values — every key is always present.
			errorSubstring := tc.Expected["error_substring"].(string)
			keptFieldsRaw := tc.Expected["kept_fields"].([]interface{})
			absentFieldsRaw := tc.Expected["absent_fields"].([]interface{})
			keptFields := make([]string, len(keptFieldsRaw))
			for i, v := range keptFieldsRaw {
				keptFields[i] = v.(string)
			}
			absentFields := make([]string, len(absentFieldsRaw))
			for i, v := range absentFieldsRaw {
				absentFields[i] = v.(string)
			}

			if useReqCtx == "no" {
				// Call directly with context.Background() — no named unmarshal map installed.
				var out map[string]any
				err := graphql.UnmarshalNamedInputFromContext(context.Background(), inputName, rawVal, &out)
				nm1AssertError(t, err, errorSubstring)
				nm1AssertFields(t, out, keptFields, absentFields)
				return
			}

			// useReqCtx == "yes": drive from inside a running resolver.
			type result struct {
				out map[string]any
				err error
			}

			if parallel <= 1 {
				// Single request: use the shared resolver-capture pattern.
				var captured result
				resolvers := &Stub{}
				resolvers.QueryResolver.DefaultScalar = func(ctx context.Context, arg string) (string, error) {
					var out map[string]any
					err := graphql.UnmarshalNamedInputFromContext(ctx, inputName, rawVal, &out)
					captured = result{out: out, err: err}
					return arg, nil
				}
				srv := handler.NewDefaultServer(NewExecutableSchema(Config{Resolvers: resolvers}))
				var resp struct{ DefaultScalar string }
				postErr := client.New(srv).Post(`query { defaultScalar(arg: "hi") }`, &resp)
				require.NoError(t, postErr, "server request must succeed")

				nm1AssertError(t, captured.err, errorSubstring)
				nm1AssertFields(t, captured.out, keptFields, absentFields)
			} else {
				// parallel > 1: fire that many concurrent requests, each through the same
				// server, and assert every result satisfies the case's expectations.
				var mu sync.Mutex
				var results []result
				var wg sync.WaitGroup

				resolvers := &Stub{}
				resolvers.QueryResolver.DefaultScalar = func(ctx context.Context, arg string) (string, error) {
					var out map[string]any
					err := graphql.UnmarshalNamedInputFromContext(ctx, inputName, rawVal, &out)
					mu.Lock()
					results = append(results, result{out: out, err: err})
					mu.Unlock()
					return arg, nil
				}
				srv := handler.NewDefaultServer(NewExecutableSchema(Config{Resolvers: resolvers}))
				c := client.New(srv)

				for i := 0; i < parallel; i++ {
					wg.Add(1)
					go func() {
						defer wg.Done()
						var resp struct{ DefaultScalar string }
						_ = c.Post(`query { defaultScalar(arg: "hi") }`, &resp)
					}()
				}
				wg.Wait()

				require.Len(t, results, parallel, "all parallel requests must complete")
				for _, r := range results {
					nm1AssertError(t, r.err, errorSubstring)
					nm1AssertFields(t, r.out, keptFields, absentFields)
				}
			}
		})
	}
}

// nm1AssertError checks the error against the sentinel or substring.
// "__skip__" → require NO error.
// "__any__"  → require SOME error (any message).
// otherwise  → require non-nil error whose message contains the substring.
func nm1AssertError(t *testing.T, err error, errorSubstring string) {
	t.Helper()
	switch errorSubstring {
	case "__skip__":
		require.NoError(t, err, "expected no error")
	case "__any__":
		require.Error(t, err, "expected some error")
	default:
		require.Error(t, err, "expected a non-nil error")
		require.True(t, strings.Contains(err.Error(), errorSubstring),
			"error %q must contain %q", err.Error(), errorSubstring)
	}
}

// nm1AssertFields checks that each kept field is present and each absent field is not.
func nm1AssertFields(t *testing.T, out map[string]any, keptFields, absentFields []string) {
	t.Helper()
	for _, k := range keptFields {
		_, present := out[k]
		require.True(t, present, "field %q must be present in result %v", k, out)
	}
	for _, k := range absentFields {
		_, present := out[k]
		require.False(t, present, "field %q must NOT be present in result %v", k, out)
	}
}
