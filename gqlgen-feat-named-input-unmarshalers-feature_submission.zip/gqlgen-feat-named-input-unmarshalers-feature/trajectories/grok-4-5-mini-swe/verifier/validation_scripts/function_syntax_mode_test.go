package usefunctionsyntaxforexecutioncontext

import (
	"context"
	"testing"

	"github.com/99designs/gqlgen/client"
	"github.com/99designs/gqlgen/graphql"
	"github.com/99designs/gqlgen/graphql/handler"
	"github.com/stretchr/testify/require"
)

func TestFs4FunctionSyntaxMode(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			rawVal := tc.Inputs["raw"]

			// Handle __null__ sentinel
			if rawStr, ok := rawVal.(string); ok && rawStr == "__null__" {
				rawVal = nil
			}

			expectedName := tc.Expected["expected_name"].(string)

			var capturedGot CreateUserInput
			var capturedErr error
			resolverRan := false

			resolvers := &Stub{}
			resolvers.QueryResolver.ListUsers = func(ctx context.Context, filter *UserFilter) ([]*User, error) {
				resolverRan = true
				var got CreateUserInput
				err := graphql.UnmarshalNamedInputFromContext(ctx, "CreateUserInput", rawVal, &got)
				capturedGot = got
				capturedErr = err
				return nil, nil
			}

			srv := handler.NewDefaultServer(NewExecutableSchema(Config{
				Resolvers: resolvers,
				Directives: DirectiveRoot{
					Log: func(ctx context.Context, obj any, next graphql.Resolver, message *string) (any, error) {
						return next(ctx)
					},
				},
			}))

			var resp struct {
				ListUsers []struct{ Name string }
			}
			postErr := client.New(srv).Post(`query { listUsers { name } }`, &resp)
			require.NoError(t, postErr, "server request must succeed")
			require.True(t, resolverRan, "resolver must have run")
			require.NoError(t, capturedErr, "UnmarshalNamedInputFromContext must not error")
			require.Equal(t, expectedName, capturedGot.Name, "Name field mismatch")
		})
	}
}
