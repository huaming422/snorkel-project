package rpumcheck

import (
	"context"
	"testing"

	"github.com/99designs/gqlgen/client"
	"github.com/99designs/gqlgen/graphql"
	"github.com/99designs/gqlgen/graphql/handler"
	"github.com/stretchr/testify/require"
)

func TestRp3PointerReturnMode(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		t.Run(tc.Name, func(t *testing.T) {
			// raw may be nil: the driver converts "__null__" → JSON null → Go nil.
			rawVal := tc.Inputs["raw"]

			// expected_name is always a string.
			// "__nil__" means out.Name must be nil (absent/zero-value pointer field).
			// Any other string is the expected *string value.
			expectedName := tc.Expected["expected_name"].(string)

			var capturedOut SearchFilters
			var capturedErr error
			resolverRan := false

			// The generated stub's Search takes `filters SearchFilters` (value, not pointer).
			resolvers := &Stub{}
			resolvers.QueryResolver.Search = func(ctx context.Context, filters SearchFilters) (string, error) {
				resolverRan = true
				// Declare var out SearchFilters (value) so that assignUnmarshalResult must
				// adapt the *SearchFilters the pointer-return-mode unmarshaler returns.
				var out SearchFilters
				err := graphql.UnmarshalNamedInputFromContext(ctx, "SearchFilters", rawVal, &out)
				capturedOut = out
				capturedErr = err
				return "ok", nil
			}
			srv := handler.NewDefaultServer(NewExecutableSchema(Config{Resolvers: resolvers}))
			var resp struct{ Search string }
			// The query always supplies {name:"x"} so the resolver always runs.
			postErr := client.New(srv).Post(`query { search(filters: {name: "x"}) }`, &resp)
			require.NoError(t, postErr, "server request must succeed")
			require.True(t, resolverRan, "resolver must have run")

			// The unmarshal call inside the resolver must not error (and must not panic).
			require.NoError(t, capturedErr, "UnmarshalNamedInputFromContext must not error")

			// EXPECTED: expected_name
			if expectedName == "__nil__" {
				// Absent / nil raw input → pointer field must be nil (zero value).
				t.Log("rawVal is nil; verifying out.Name is nil (zero-value pointer)")
				require.Nil(t, capturedOut.Name, "Name pointer must be nil for absent input")
			} else {
				require.NotNil(t, capturedOut.Name, "Name pointer must be non-nil")
				require.Equal(t, expectedName, *capturedOut.Name, "Name value mismatch")
			}
		})
	}
}
