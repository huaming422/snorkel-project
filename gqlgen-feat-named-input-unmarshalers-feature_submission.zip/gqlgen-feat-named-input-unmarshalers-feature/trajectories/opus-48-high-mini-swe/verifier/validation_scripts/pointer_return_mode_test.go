package rpumcheck

import (
	"context"
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/99designs/gqlgen/client"
	"github.com/99designs/gqlgen/graphql"
	"github.com/99designs/gqlgen/graphql/handler"
)

func TestRp3PointerReturnMode(t *testing.T) {
	type rp3Case struct {
		name         string
		rawInput     any
		expectedName string // "__nil__" means expect nil pointer; else expect *Name == expectedName
	}

	cases := []rp3Case{
		{
			name:         "named_bob",
			rawInput:     map[string]any{"name": "bob"},
			expectedName: "bob",
		},
		{
			name:         "null_input",
			rawInput:     nil,
			expectedName: "__nil__",
		},
	}

	for _, tc := range cases {
		tc := tc
		t.Run(tc.name, func(t *testing.T) {
			rawInput := tc.rawInput
			expectedName := tc.expectedName

			var capturedOut SearchFilters
			var capturedErr error
			resolverRan := false

			resolvers := &Stub{}
			resolvers.QueryResolver.Search = func(ctx context.Context, filters SearchFilters) (string, error) {
				resolverRan = true
				var out SearchFilters
				err := graphql.UnmarshalInputFromContextByName(ctx, "SearchFilters", rawInput, &out)
				capturedOut = out
				capturedErr = err
				return "ok", nil
			}

			srv := handler.NewDefaultServer(NewExecutableSchema(Config{Resolvers: resolvers}))
			var resp struct{ Search string }
			require.NoError(t, client.New(srv).Post(`query { search(filters: {name: "x"}) }`, &resp))
			require.True(t, resolverRan, "resolver must have run")

			// Require no error
			require.NoError(t, capturedErr, "expected no error unmarshaling by name")

			// Assert expected_name
			if expectedName == "__nil__" {
				require.Nil(t, capturedOut.Name, "expected Name pointer to be nil for absent/null input")
			} else {
				require.NotNil(t, capturedOut.Name, "expected Name pointer to be non-nil")
				require.Equal(t, expectedName, *capturedOut.Name, "expected Name value to equal %q", expectedName)
			}
		})
	}
}
