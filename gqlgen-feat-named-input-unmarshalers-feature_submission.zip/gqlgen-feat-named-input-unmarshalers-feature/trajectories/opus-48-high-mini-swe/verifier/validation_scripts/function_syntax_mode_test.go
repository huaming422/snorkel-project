package usefunctionsyntaxforexecutioncontext

import (
	"context"
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/99designs/gqlgen/client"
	"github.com/99designs/gqlgen/graphql"
	"github.com/99designs/gqlgen/graphql/handler"
)

func TestFs4FunctionSyntaxMode(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			rawInput := tc.Inputs["raw"]
			expectedName := tc.Expected["expected_name"].(string)

			// Handle sentinel: "__null__" means nil raw
			if s, ok := rawInput.(string); ok && s == "__null__" {
				rawInput = nil
			}

			var capturedGot CreateUserInput
			var capturedErr error
			resolverRan := false

			resolvers := &Stub{}
			resolvers.QueryResolver.ListUsers = func(ctx context.Context, filter *UserFilter) ([]*User, error) {
				resolverRan = true
				var got CreateUserInput
				err := graphql.UnmarshalInputFromContextByName(ctx, "CreateUserInput", rawInput, &got)
				capturedGot = got
				capturedErr = err
				return nil, nil
			}

			srv := handler.NewDefaultServer(NewExecutableSchema(Config{
				Resolvers: resolvers,
				Directives: DirectiveRoot{
					Log: func(ctx context.Context, _ any, next graphql.Resolver, _ *string) (any, error) {
						return next(ctx)
					},
				},
			}))

			var resp struct {
				ListUsers []struct{ Name string }
			}
			require.NoError(t, client.New(srv).Post(`query { listUsers { name } }`, &resp))
			require.True(t, resolverRan, "resolver must have run")

			// Require no error
			require.NoError(t, capturedErr, "expected no error")

			// Assert expected_name
			require.Equal(t, expectedName, capturedGot.Name, "expected CreateUserInput.Name to equal %q", expectedName)
		})
	}
}
