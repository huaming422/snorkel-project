package singlefile

import (
	"context"
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/99designs/gqlgen/client"
	"github.com/99designs/gqlgen/graphql/handler"
)

func TestTh2TypedInputHelper(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			targetInput := tc.Inputs["target_input"].(string)
			rawInput := tc.Inputs["raw"]

			errorSubstring := tc.Expected["error_substring"].(string)

			keptFieldsRaw := tc.Expected["kept_fields"].([]interface{})
			keptFields := make([]string, len(keptFieldsRaw))
			for i, f := range keptFieldsRaw {
				keptFields[i] = f.(string)
			}

			absentFieldsRaw := tc.Expected["absent_fields"].([]interface{})
			absentFields := make([]string, len(absentFieldsRaw))
			for i, f := range absentFieldsRaw {
				absentFields[i] = f.(string)
			}

			// Handle sentinel: "__null__" means nil raw
			if s, ok := rawInput.(string); ok && s == "__null__" {
				rawInput = nil
			}

			var capturedOut map[string]any
			var capturedErr error

			resolvers := &Stub{}
			resolvers.QueryResolver.DefaultScalar = func(ctx context.Context, arg string) (string, error) {
				switch targetInput {
				case "SearchFilters":
					v, err := UnmarshalSearchFilters(ctx, rawInput)
					capturedOut = v
					capturedErr = err
				case "DirectiveInput":
					v, err := UnmarshalDirectiveInput(ctx, rawInput)
					capturedOut = v
					capturedErr = err
				default:
					t.Errorf("unknown target_input: %s", targetInput)
				}
				return arg, nil
			}
			srv := handler.NewDefaultServer(NewExecutableSchema(Config{Resolvers: resolvers}))
			var resp struct{ DefaultScalar string }
			require.NoError(t, client.New(srv).Post(`query { defaultScalar(arg: "hi") }`, &resp))

			// Assert error
			if errorSubstring == "__skip__" {
				require.NoError(t, capturedErr, "expected no error")
			} else if errorSubstring == "__any__" {
				require.Error(t, capturedErr, "expected some error")
			} else {
				require.Error(t, capturedErr)
				require.Contains(t, capturedErr.Error(), errorSubstring)
			}

			// Assert kept fields
			for _, field := range keptFields {
				_, present := capturedOut[field]
				require.True(t, present, "expected field %q to be present in result %v", field, capturedOut)
			}

			// Assert absent fields
			for _, field := range absentFields {
				_, present := capturedOut[field]
				require.False(t, present, "expected field %q to be absent from result %v", field, capturedOut)
			}
		})
	}
}
