package singlefile

import (
	"context"
	"sync"
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/99designs/gqlgen/client"
	"github.com/99designs/gqlgen/graphql"
	"github.com/99designs/gqlgen/graphql/handler"
)

func TestNm1NamedInputUnmarshal(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			inputName := tc.Inputs["input_name"].(string)
			rawInput := tc.Inputs["raw"]
			useRequestContext := tc.Inputs["use_request_context"].(string)
			parallel := int(tc.Inputs["parallel"].(float64))

			errorSubstring := tc.Expected["error_substring"].(string)

			keptFieldsRaw := tc.Expected["kept_fields"].([]interface{})
			keptFields := make([]string, len(keptFieldsRaw))
			for i, f := range keptFieldsRaw {
				keptFields[i] = f.(string)
			}

			absentFieldsRaw := tc.Expected["absent_fields"].([]interface{})
			absentFields := make([]string, len(absentFieldsRaw))
			for i, f := range absentFieldsRaw {
				absentFields[i] = f.(string)
			}

			// Handle sentinel: "__null__" means nil raw
			if s, ok := rawInput.(string); ok && s == "__null__" {
				rawInput = nil
			}

			nm1Assert := func(t *testing.T, out map[string]any, err error) {
				t.Helper()
				if errorSubstring == "__skip__" {
					require.NoError(t, err, "expected no error")
				} else if errorSubstring == "__any__" {
					require.Error(t, err, "expected some error")
				} else {
					require.Error(t, err, "expected an error")
					require.Contains(t, err.Error(), errorSubstring, "error message should contain %q", errorSubstring)
				}
				for _, field := range keptFields {
					_, present := out[field]
					require.True(t, present, "expected field %q to be present in result %v", field, out)
				}
				for _, field := range absentFields {
					_, present := out[field]
					require.False(t, present, "expected field %q to be absent from result %v", field, out)
				}
			}

			if useRequestContext == "no" {
				// Call directly with context.Background() — no live request
				var out map[string]any
				err := graphql.UnmarshalInputFromContextByName(context.Background(), inputName, rawInput, &out)
				nm1Assert(t, out, err)
				return
			}

			// useRequestContext == "yes": drive from resolver
			if parallel <= 1 {
				var capturedOut map[string]any
				var capturedErr error

				resolvers := &Stub{}
				resolvers.QueryResolver.DefaultScalar = func(ctx context.Context, arg string) (string, error) {
					var out map[string]any
					err := graphql.UnmarshalInputFromContextByName(ctx, inputName, rawInput, &out)
					capturedOut = out
					capturedErr = err
					return arg, nil
				}
				srv := handler.NewDefaultServer(NewExecutableSchema(Config{Resolvers: resolvers}))
				var resp struct{ DefaultScalar string }
				_ = client.New(srv).Post(`query { defaultScalar(arg: "hi") }`, &resp)
				nm1Assert(t, capturedOut, capturedErr)
				return
			}

			// parallel > 1: run that many concurrent requests
			type nm1ConcResult struct {
				out map[string]any
				err error
			}
			var results []nm1ConcResult
			var mu sync.Mutex
			var wg sync.WaitGroup

			resolvers := &Stub{}
			resolvers.QueryResolver.DefaultScalar = func(ctx context.Context, arg string) (string, error) {
				var out map[string]any
				err := graphql.UnmarshalInputFromContextByName(ctx, inputName, rawInput, &out)
				mu.Lock()
				results = append(results, nm1ConcResult{out: out, err: err})
				mu.Unlock()
				return arg, nil
			}
			srv := handler.NewDefaultServer(NewExecutableSchema(Config{Resolvers: resolvers}))
			c := client.New(srv)

			for i := 0; i < parallel; i++ {
				wg.Add(1)
				go func() {
					defer wg.Done()
					var resp struct{ DefaultScalar string }
					_ = c.Post(`query { defaultScalar(arg: "hi") }`, &resp)
				}()
			}
			wg.Wait()

			mu.Lock()
			allResults := results
			mu.Unlock()

			require.Equal(t, parallel, len(allResults), "expected exactly %d results from %d concurrent requests", parallel, parallel)
			for _, res := range allResults {
				nm1Assert(t, res.out, res.err)
			}
		})
	}
}
