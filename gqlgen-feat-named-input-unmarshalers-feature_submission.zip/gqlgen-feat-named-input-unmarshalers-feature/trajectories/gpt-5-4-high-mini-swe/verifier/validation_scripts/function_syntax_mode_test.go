package usefunctionsyntaxforexecutioncontext

import (
	"context"
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/99designs/gqlgen/client"
	"github.com/99designs/gqlgen/graphql"
	"github.com/99designs/gqlgen/graphql/handler"
)

// fs4TestCase holds one inline test case for the function_syntax_mode story.
type fs4TestCase struct {
	name         string
	raw          interface{}
	expectedName string
}

func TestFs4FunctionSyntaxMode(t *testing.T) {
	// Two inline test cases from the validation spec.
	cases := []fs4TestCase{
		{
			name:         "with raw input object",
			raw:          map[string]interface{}{"name": "bob"},
			expectedName: "bob",
		},
		{
			name:         "with null input gives zero value",
			raw:          nil, // __null__ sentinel → nil
			expectedName: "",
		},
	}

	for _, tc := range cases {
		tc := tc
		t.Run(tc.name, func(t *testing.T) {
			fs4RunCase(t, tc)
		})
	}
}

func fs4RunCase(t *testing.T, tc fs4TestCase) {
	t.Helper()

	var capturedGot CreateUserInput
	var capturedErr error
	resolverRan := false

	resolvers := &Stub{}
	resolvers.QueryResolver.ListUsers = func(ctx context.Context, filter *UserFilter) ([]*User, error) {
		resolverRan = true
		var got CreateUserInput
		err := graphql.UnmarshalInputByNameFromContext(ctx, "CreateUserInput", tc.raw, &got)
		capturedGot = got
		capturedErr = err
		return nil, nil
	}

	srv := handler.NewDefaultServer(NewExecutableSchema(Config{
		Resolvers: resolvers,
		Directives: DirectiveRoot{
			Log: func(ctx context.Context, obj any, next graphql.Resolver, message *string) (any, error) {
				return next(ctx)
			},
		},
	}))

	var resp struct {
		ListUsers []struct {
			Name string
		}
	}
	postErr := client.New(srv).Post(`query { listUsers { name } }`, &resp)
	require.NoError(t, postErr)
	require.True(t, resolverRan, "resolver must have run")
	require.NoError(t, capturedErr)
	require.Equal(t, tc.expectedName, capturedGot.Name)
}
