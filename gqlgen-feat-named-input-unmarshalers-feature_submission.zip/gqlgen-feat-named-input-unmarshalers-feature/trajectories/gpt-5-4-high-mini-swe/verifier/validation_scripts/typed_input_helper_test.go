package singlefile

import (
	"context"
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/99designs/gqlgen/client"
	"github.com/99designs/gqlgen/graphql/handler"
)

func TestTh2TypedInputHelper(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			th2RunCase(t, tc.Inputs, tc.Expected)
		})
	}
}

func th2RunCase(t *testing.T, inputs map[string]interface{}, expected map[string]interface{}) {
	t.Helper()

	targetInput := inputs["target_input"].(string)
	rawInput := inputs["raw"]

	// Handle __null__ sentinel
	if rawStr, ok := rawInput.(string); ok && rawStr == "__null__" {
		rawInput = nil
	}

	errorSubstring := expected["error_substring"].(string)
	keptFieldsRaw := expected["kept_fields"].([]interface{})
	absentFieldsRaw := expected["absent_fields"].([]interface{})

	keptFields := make([]string, len(keptFieldsRaw))
	for i, v := range keptFieldsRaw {
		keptFields[i] = v.(string)
	}
	absentFields := make([]string, len(absentFieldsRaw))
	for i, v := range absentFieldsRaw {
		absentFields[i] = v.(string)
	}

	var capturedResult map[string]any
	var capturedErr error

	resolvers := &Stub{}
	resolvers.QueryResolver.DefaultScalar = func(ctx context.Context, arg string) (string, error) {
		switch targetInput {
		case "SearchFilters":
			result, err := UnmarshalSearchFiltersFromContext(ctx, rawInput)
			capturedResult = result
			capturedErr = err
		case "DirectiveInput":
			result, err := UnmarshalDirectiveInputFromContext(ctx, rawInput)
			capturedResult = result
			capturedErr = err
		default:
			t.Errorf("unknown target_input: %s", targetInput)
		}
		return arg, nil
	}

	srv := handler.NewDefaultServer(NewExecutableSchema(Config{Resolvers: resolvers}))
	var resp struct{ DefaultScalar string }
	postErr := client.New(srv).Post(`query { defaultScalar(arg: "hi") }`, &resp)
	require.NoError(t, postErr)

	if errorSubstring == "__skip__" {
		require.NoError(t, capturedErr)
	} else {
		require.Error(t, capturedErr)
	}

	for _, f := range keptFields {
		require.Contains(t, capturedResult, f, "expected field %q in result for %s", f, targetInput)
	}
	for _, f := range absentFields {
		require.NotContains(t, capturedResult, f, "unexpected field %q in result for %s", f, targetInput)
	}
}
