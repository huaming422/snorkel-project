package rpumcheck

import (
	"context"
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/99designs/gqlgen/client"
	"github.com/99designs/gqlgen/graphql"
	"github.com/99designs/gqlgen/graphql/handler"
)

func TestRp3PointerReturnMode(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			rp3RunCase(t, tc.Inputs, tc.Expected)
		})
	}
}

func rp3RunCase(t *testing.T, inputs map[string]interface{}, expected map[string]interface{}) {
	t.Helper()

	rawInput := inputs["raw"]

	// Handle __null__ sentinel
	if rawStr, ok := rawInput.(string); ok && rawStr == "__null__" {
		rawInput = nil
	}

	expectedName := expected["expected_name"].(string)

	var capturedOut SearchFilters
	var capturedErr error
	resolverRan := false

	resolvers := &Stub{}
	resolvers.QueryResolver.Search = func(ctx context.Context, filters SearchFilters) (string, error) {
		resolverRan = true
		var out SearchFilters
		err := graphql.UnmarshalInputByNameFromContext(ctx, "SearchFilters", rawInput, &out)
		capturedOut = out
		capturedErr = err
		return "ok", nil
	}

	srv := handler.NewDefaultServer(NewExecutableSchema(Config{Resolvers: resolvers}))
	var resp struct{ Search string }
	postErr := client.New(srv).Post(`query { search(filters: {name: "x"}) }`, &resp)
	require.NoError(t, postErr)
	require.True(t, resolverRan, "resolver must have run")

	require.NoError(t, capturedErr)

	if expectedName == "__nil__" {
		require.Nil(t, capturedOut.Name, "expected Name pointer to be nil")
	} else {
		require.NotNil(t, capturedOut.Name, "expected Name pointer to be non-nil")
		require.Equal(t, expectedName, *capturedOut.Name)
	}
}
