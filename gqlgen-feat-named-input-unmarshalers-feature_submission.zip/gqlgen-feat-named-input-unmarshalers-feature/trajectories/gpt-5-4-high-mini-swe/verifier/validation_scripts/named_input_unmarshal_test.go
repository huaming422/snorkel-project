package singlefile

import (
	"context"
	"strings"
	"sync"
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/99designs/gqlgen/client"
	"github.com/99designs/gqlgen/graphql"
	"github.com/99designs/gqlgen/graphql/handler"
)

// nm1TestCase holds one inline test case for the named_input_unmarshal story.
type nm1TestCase struct {
	name             string
	inputName        string
	raw              interface{}
	useRequestCtx    bool
	parallel         int
	errorSubstring   string
	keptFields       []string
	absentFields     []string
}

func TestNm1NamedInputUnmarshal(t *testing.T) {
	// Six inline test cases from the validation spec.
	cases := []nm1TestCase{
		{
			name:           "SearchFilters keeps only its own field",
			inputName:      "SearchFilters",
			raw:            map[string]interface{}{"category": "books", "newField": "legacy"},
			useRequestCtx:  true,
			parallel:       1,
			errorSubstring: "__skip__",
			keptFields:     []string{"category"},
			absentFields:   []string{"newField"},
		},
		{
			name:           "DirectiveInput keeps only its own field",
			inputName:      "DirectiveInput",
			raw:            map[string]interface{}{"category": "books", "newField": "legacy"},
			useRequestCtx:  true,
			parallel:       1,
			errorSubstring: "__skip__",
			keptFields:     []string{"newField"},
			absentFields:   []string{"category"},
		},
		{
			name:           "unknown input name gives error containing NoSuchInput",
			inputName:      "NoSuchInput",
			raw:            map[string]interface{}{"category": "books"},
			useRequestCtx:  true,
			parallel:       1,
			errorSubstring: "NoSuchInput",
			keptFields:     []string{},
			absentFields:   []string{"category"},
		},
		{
			name:           "null input gives zero value no error",
			inputName:      "SearchFilters",
			raw:            nil, // __null__ sentinel → nil
			useRequestCtx:  true,
			parallel:       1,
			errorSubstring: "__skip__",
			keptFields:     []string{},
			absentFields:   []string{"category", "newField"},
		},
		{
			name:           "outside live request reports error",
			inputName:      "SearchFilters",
			raw:            map[string]interface{}{"category": "books"},
			useRequestCtx:  false,
			parallel:       1,
			errorSubstring: "__any__",
			keptFields:     []string{},
			absentFields:   []string{"category"},
		},
		{
			name:           "concurrent requests each resolve correctly",
			inputName:      "SearchFilters",
			raw:            map[string]interface{}{"category": "books", "newField": "legacy"},
			useRequestCtx:  true,
			parallel:       50,
			errorSubstring: "__skip__",
			keptFields:     []string{"category"},
			absentFields:   []string{"newField"},
		},
	}

	for _, tc := range cases {
		tc := tc
		t.Run(tc.name, func(t *testing.T) {
			nm1RunCase(t, tc)
		})
	}
}

func nm1RunCase(t *testing.T, tc nm1TestCase) {
	t.Helper()

	if !tc.useRequestCtx {
		// Call directly with context.Background() — must report an error
		var out map[string]any
		err := graphql.UnmarshalInputByNameFromContext(context.Background(), tc.inputName, tc.raw, &out)
		nm1AssertError(t, err, tc.errorSubstring)
		for _, f := range tc.keptFields {
			require.Contains(t, out, f, "expected field %q in out", f)
		}
		for _, f := range tc.absentFields {
			require.NotContains(t, out, f, "unexpected field %q in out", f)
		}
		return
	}

	// use_request_context == true
	if tc.parallel <= 1 {
		var capturedOut map[string]any
		var capturedErr error

		resolvers := &Stub{}
		resolvers.QueryResolver.DefaultScalar = func(ctx context.Context, arg string) (string, error) {
			var out map[string]any
			err := graphql.UnmarshalInputByNameFromContext(ctx, tc.inputName, tc.raw, &out)
			capturedOut = out
			capturedErr = err
			return arg, nil
		}
		srv := handler.NewDefaultServer(NewExecutableSchema(Config{Resolvers: resolvers}))
		var resp struct{ DefaultScalar string }
		postErr := client.New(srv).Post(`query { defaultScalar(arg: "hi") }`, &resp)
		require.NoError(t, postErr)

		nm1AssertError(t, capturedErr, tc.errorSubstring)
		for _, f := range tc.keptFields {
			require.Contains(t, capturedOut, f, "expected field %q in out", f)
		}
		for _, f := range tc.absentFields {
			require.NotContains(t, capturedOut, f, "unexpected field %q in out", f)
		}
		return
	}

	// parallel > 1: run that many concurrent requests
	type result struct {
		out map[string]any
		err error
	}
	var mu sync.Mutex
	var collectedResults []result

	resolvers := &Stub{}
	resolvers.QueryResolver.DefaultScalar = func(ctx context.Context, arg string) (string, error) {
		var out map[string]any
		err := graphql.UnmarshalInputByNameFromContext(ctx, tc.inputName, tc.raw, &out)
		mu.Lock()
		collectedResults = append(collectedResults, result{out, err})
		mu.Unlock()
		return arg, nil
	}
	srv := handler.NewDefaultServer(NewExecutableSchema(Config{Resolvers: resolvers}))

	var wg sync.WaitGroup
	for j := 0; j < tc.parallel; j++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			var resp struct{ DefaultScalar string }
			_ = client.New(srv).Post(`query { defaultScalar(arg: "hi") }`, &resp)
		}()
	}
	wg.Wait()

	mu.Lock()
	got := collectedResults
	mu.Unlock()

	require.Len(t, got, tc.parallel, "expected %d results from concurrent requests", tc.parallel)

	for _, r := range got {
		nm1AssertError(t, r.err, tc.errorSubstring)
		for _, f := range tc.keptFields {
			require.Contains(t, r.out, f, "expected field %q in out", f)
		}
		for _, f := range tc.absentFields {
			require.NotContains(t, r.out, f, "unexpected field %q in out", f)
		}
	}
}

func nm1AssertError(t *testing.T, err error, errorSubstring string) {
	t.Helper()
	switch errorSubstring {
	case "__skip__":
		require.NoError(t, err)
	case "__any__":
		require.Error(t, err)
	default:
		require.Error(t, err)
		require.True(t, strings.Contains(err.Error(), errorSubstring),
			"expected error containing %q, got %q", errorSubstring, err.Error())
	}
}
