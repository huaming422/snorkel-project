// Backward-compatibility guard for the pre-existing context-based input
// unmarshal surface.
//
// This file exercises ONLY the stable exported surface that already exists on
// an unmodified checkout: the call that builds a map of unmarshalers keyed by
// their produced Go type, the call that installs that map on a context, and
// the call that unmarshals a raw object out of that context into a caller's
// value. The task adds a new name-based way to do the same thing, but the old
// surface must keep its signatures and behaviour so existing callers are
// unaffected — that is all this file asserts.
//
// It deliberately references NONE of the symbols the change introduces (the
// name-based entry point, any index/descriptor type, the generated typed
// helpers, the shape-absorption helper, or the deprecated shim's internals).
// Those are implementation choices a valid solution may structure, name, or
// split differently. Only the observable round-trip through the three stable
// calls is checked here, so this passes on an unmodified checkout and on every
// correct solution alike (pass_to_pass).
//
// The file is injected into /repo/gqlgen/graphql and compiles together with
// the package's existing *_test.go files, so its top-level identifiers carry a
// file-unique `depCompat` prefix to avoid colliding with them.
package graphql

import (
	"context"
	"testing"
)

// depCompatInput is a throwaway input model owned entirely by this test; the
// unmarshaler below is keyed on its Go type by the map-building call.
type depCompatInput struct {
	Label string
	Count int
}

// depCompatUnmarshal mimics a generated unmarshaler's shape: it takes the
// request context and the raw decoded object and returns the typed value. The
// map-building call keys it by its first return type (depCompatInput).
func depCompatUnmarshal(_ context.Context, raw any) (depCompatInput, error) {
	obj, _ := raw.(map[string]any)
	out := depCompatInput{}
	if s, ok := obj["label"].(string); ok {
		out.Label = s
	}
	if n, ok := obj["count"].(int); ok {
		out.Count = n
	}
	return out, nil
}

// TestDepCompatContextRoundTrip asserts the stable three-call path still works
// end to end: build a map holding one unmarshaler, install it on a context,
// then unmarshal a raw object out of that context into a caller's value and
// get the caller's data back.
func TestDepCompatContextRoundTrip(t *testing.T) {
	unmarshalers := BuildUnmarshalerMap(depCompatUnmarshal)
	ctx := WithUnmarshalerMap(context.Background(), unmarshalers)

	var got depCompatInput
	if err := UnmarshalInputFromContext(ctx, map[string]any{"label": "widget", "count": 3}, &got); err != nil {
		t.Fatalf("UnmarshalInputFromContext returned an unexpected error: %v", err)
	}
	if got.Label != "widget" || got.Count != 3 {
		t.Fatalf("round-trip mismatch: got %+v, want {Label:widget Count:3}", got)
	}
}

// TestDepCompatEmptyContextErrors asserts the stable failure mode is preserved:
// unmarshaling out of a context that never had a map installed reports an error
// rather than panicking or silently succeeding. The exact message text is not
// asserted (a solution may own its wording); only that a non-nil error comes
// back.
func TestDepCompatEmptyContextErrors(t *testing.T) {
	var got depCompatInput
	if err := UnmarshalInputFromContext(context.Background(), map[string]any{"label": "x"}, &got); err == nil {
		t.Fatalf("expected an error when no unmarshaler map is installed on the context, got nil")
	}
}
