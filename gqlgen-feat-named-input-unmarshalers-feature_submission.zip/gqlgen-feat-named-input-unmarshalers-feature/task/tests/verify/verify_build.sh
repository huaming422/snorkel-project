#!/usr/bin/env bash
# Whole-tree compilation gate.
#
# The change spans the runtime support package, the code-generation templates,
# and the generator configuration, and then regenerates produced code across
# the repo's fixtures and examples. A solution that edits the generator but
# leaves the regenerated output stale (or inconsistent with the new templates)
# stops the tree from compiling. This gate asserts that both Go modules in the
# checkout still build cleanly.
#
# It imports no task-introduced names, so it is alternative-implementation
# safe; the behavioural checks live in the validation stories and the
# compatibility guard in verify_test.go. This passes on an unmodified checkout
# and on a correct solution (pass_to_pass).
#
# Modules in this checkout:
#   * the root module (github.com/99designs/gqlgen) — runtime package,
#     templates, config, and every regenerated testserver/plugin fixture;
#   * the _examples module, which has a local `replace => ../` back to root, so
#     building it compiles the examples against the solution's own runtime.
# (There is no _proptests module at this commit.)
set -euo pipefail

export GOFLAGS="${GOFLAGS:--mod=mod}"
export CGO_ENABLED="${CGO_ENABLED:-1}"
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"
export GOPROXY="${GOPROXY:-off}"

echo "== building root module (github.com/99designs/gqlgen) =="
cd /repo/gqlgen
go build ./...

echo "== building _examples module (replace => ../) =="
cd /repo/gqlgen/_examples
go build ./...

echo "== build gate passed =="
