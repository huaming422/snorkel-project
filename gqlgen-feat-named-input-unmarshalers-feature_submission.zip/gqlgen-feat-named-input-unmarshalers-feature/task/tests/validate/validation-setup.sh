#!/usr/bin/env bash
# Sourced once before the validation stories run.
#
# Two jobs:
#   1. Export a deterministic, offline Go environment (the image bakes Go
#      1.26.9 and warm module caches for the root and _examples modules at the
#      base commit; nothing here needs the network).
#   2. Materialise a small follow-schema package that exercises the
#      pointer-returning input-unmarshal mode, by running the checkout's OWN
#      code generator over a schema that turns that mode on. The package is
#      generated INTO the repo here, before the validation integrity snapshot
#      is taken, so the stories may compile against it while the trial itself
#      makes no repo edits.
#
# The generated package lives at codegen/testserver/rpumcheck. Its three source
# files (schema, generator config, resolver root) are fixtures owned by this
# setup — the submission never reads them; it only has to generate compiling
# code from them. If the submission's pointer-return code generation is broken,
# generation or the resulting build fails and the pointer-return story cannot
# compile, which is the intended signal.

set -euo pipefail

cd /repo/gqlgen

export GOFLAGS="-mod=mod"
export CGO_ENABLED="1"
export GOTOOLCHAIN="local"
export GOPROXY="${GOPROXY:-off}"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
mkdir -p "$GOCACHE" "$GOMODCACHE"

# Belt-and-suspenders: the caches are already warm from the image build, but a
# no-op download keeps the root module's deps resolvable even if a cache path
# shifted. Offline (GOPROXY=off) so this cannot reach out; failures here are
# non-fatal because the real toolchain check is the generation + build below.
go mod download || true

# --- Generate the pointer-return fixture package -------------------------
FIX_DIR="codegen/testserver/rpumcheck"
rm -rf "$FIX_DIR"
mkdir -p "$FIX_DIR"

cat > "$FIX_DIR/schema.graphql" <<'GRAPHQL'
type Query {
  search(filters: SearchFilters!): String!
  legacy(filters: LegacyFilters!): String!
}

input SearchFilters {
  name: String
  limit: Int
}

input LegacyFilters {
  name: String
}
GRAPHQL

# return_pointers_in_unmarshalinput and skip_validation are long-standing
# gqlgen config keys; this turns the pointer-return mode on for the generator.
cat > "$FIX_DIR/gqlgen.yml" <<'YAML'
schema:
  - "*.graphql"
skip_validation: true
return_pointers_in_unmarshalinput: true
exec:
  layout: follow-schema
  dir: .
  package: rpumcheck
model:
  filename: models-gen.go
  package: rpumcheck
resolver:
  layout: follow-schema
  dir: .
  package: rpumcheck
  type: Resolver
omit_complexity: true
YAML

cat > "$FIX_DIR/resolver.go" <<'GO'
package rpumcheck

// Dependency-injection root for the generated server. Hand-written and kept
// across regeneration.

type Resolver struct{}
GO

echo "== generating pointer-return fixture (rpumcheck) with the checkout's generator =="
# Mirrors how every testserver package is produced:
#   go:generate go run ../../../testdata/gqlgen.go -config gqlgen.yml -stub stub.go
# LoadConfig chdir's into the config's directory, so run from the fixture dir.
gen_log="$(mktemp)"
if ( cd "$FIX_DIR" && go run ../../../testdata/gqlgen.go -config gqlgen.yml -stub stub.go ) > "$gen_log" 2>&1; then
  echo "== fixture generated =="
else
  echo "!! pointer-return fixture generation FAILED — pointer-return story will not compile" >&2
  tail -80 "$gen_log" >&2 || true
fi

# Loud smoke guard: prove the generated package actually builds. On a correct
# solution this prints the ready marker; on a broken pointer-return
# implementation it prints the failing build output and the story that targets
# this package fails to compile (the signal we want).
echo "== building generated pointer-return fixture =="
build_log="$(mktemp)"
if go build ./"$FIX_DIR"/... > "$build_log" 2>&1; then
  echo "== rpumcheck builds — validation environment ready =="
else
  echo "!! rpumcheck did NOT build:" >&2
  tail -80 "$build_log" >&2 || true
fi
