# Sourced by the Staff-Bench verifier runner before tests execute.
#
# Inherits the image's Go toolchain (Go 1.26.9) and the pre-downloaded module
# caches for all three modules (root, _examples, _proptests), baked at the base
# commit in the Dockerfile. The reward harness runs `go build` / `go test` /
# `go generate` across these modules; some packages pull in CGO.
#
# Container setup is minimal — everything heavy lives in the Dockerfile. We only
# export environment so subsequent Go invocations behave deterministically and
# offline.

set -euo pipefail

cd /repo/gqlgen

export GOFLAGS="-mod=mod"
export CGO_ENABLED="1"
export GOTOOLCHAIN="local"
export GOPROXY="${GOPROXY:-off}"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
mkdir -p "$GOCACHE" "$GOMODCACHE"
