## Task

When a resolver unmarshals a GraphQL input object out of the request context,
gqlgen picks which unmarshaler to run from the Go type the caller hands it. That
falls apart as soon as two inputs share a Go type, and plenty do: every
map-backed input lands on `map[string]interface{}`. Ask for one of those and you
can quietly get a different input's unmarshaler, with nothing to tell them apart.

We want a resolver to unmarshal an input and reliably get back the one it asked
for, picked out unambiguously, plus a convenient typed way to do the same from
generated code. The requirements below spell out the behavior.

This work sits in the code generation internals: the runtime support package,
the templates, and the generator's configuration. Once the generator changes,
regenerate the produced code across the fixtures and examples.

The library is published, so keep this additive: the existing public API keeps
its signatures and behavior. In particular the exported calls that build an
unmarshaler map, install it on a context, and unmarshal an input back out of
that context — `BuildUnmarshalerMap`, `WithUnmarshalerMap`, and
`UnmarshalInputFromContext` — keep working exactly as they do today. The
repository should still build, and regenerating should leave the generated code
unchanged. You work offline against the cached modules, using the usual Go
commands.

## User stories / requirements

- From inside a resolver, a caller unmarshals a GraphQL input by naming the one it wants and gets back that input's data even when several inputs share a Go type. Naming a nonexistent input yields a clear error rather than a panic or wrong input, and unmarshaling outside a live request reports no input context.
- Generated code offers a typed helper per input object, so a resolver names an input once and gets its own Go value back in one call, with shared-Go-type inputs each resolving to their own.
- A schema generated with the option that returns pointers from input unmarshaling builds cleanly and round-trips an input through its typed helper, with an absent input coming back as a pointer to the zero value. The caller's target works whether the unmarshaler yields a value or a pointer.
- A schema generated with the option that uses function syntax for the execution context can unmarshal an input by name from a resolver and return that input's data without panicking.
