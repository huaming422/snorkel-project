"""Behavioral verifier for wgpu-fix-render-target-init-tracking.

Drives the project's own GPU test suite through the public ``wgpu``
device/queue/render-pass API and texture readback. It creates 3D and
depth/stencil textures, renders into specific depth slices, copies the whole
texture to a buffer, and asserts the untouched regions read back zero. The
behavior under test is observable only at that surface, so these checks never
import or name any of the crate's internal types: a correct solution can rename
internal symbols, change parameter plumbing, or pick per-slice tracking instead
of whole-volume initialization and still pass.

Observing the fault requires a backend that exposes real uninitialized memory.
The image builds Mesa's CPU Vulkan adapter (llvmpipe) and sets
LVP_POISON_MEMORY=true so freshly-allocated memory is filled with a non-zero
pattern; a zero-filling backend cannot reproduce the fault. The GPU suite uses a
one-test-per-process harness, so the binary is run single-threaded.

The directed test sources (the readback helper, the WGSL copy shader, and the
GPU test module) are shipped alongside this file and overlaid onto the repo at
grade time, so a submission that deletes or weakens those tests is graded
against the pristine versions regardless.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
from pathlib import Path

import pytest

REPO = Path(f"/repo/{os.environ.get('REPO_NAME', 'wgpu')}")

# The GPU suite's one-test-per-process harness aborts if more than one test runs
# in a process, so it is driven single-threaded. A cold compile of the GPU test
# binary against the submission's changed crate dominates the wall clock; the
# filtered suite itself runs in a couple of seconds.
CARGO_TIMEOUT_SEC = 1500

# Overlay targets inside the test crate. Keeping the readback helper and copy
# shader in sync with the directed tests is what lets the tests observe
# per-subresource contents; overlaying all three keeps the graded tests pristine.
OVERLAY = {
    "zero_init.rs": "tests/tests/wgpu-gpu/zero_init.rs",
    "image.rs": "tests/src/image.rs",
    "copy_texture_to_buffer.wgsl": "tests/src/copy_texture_to_buffer.wgsl",
}

# Each behavioral case names the observable property it pins. The names are the
# GPU test functions as libtest reports them (module-qualified, lowercased).
TARGET_CASES = {
    "slice_init": "zero_init::render_pass_store_to_3d_depth_slice_inits_other_slices",
    "slice_discard": "zero_init::discarding_3d_depth_slice_preserves_other_slices",
    "multi_slice": "zero_init::discarding_3d_depth_slice_alongside_another_slice_in_same_pass",
    "ds_divergent": "zero_init::discarding_both_depth_and_stencil_with_diverging_load_ops",
}

# libtest line: "test [running] [Vulkan/llvmpipe .../0] zero_init::name ... ok"
_RESULT_RE = re.compile(r"^test\s+(.+?)\s+\.\.\.\s+(ok|FAILED|ignored)\s*$", re.MULTILINE)


def _overlay_directed_tests() -> None:
    here = Path(__file__).resolve().parent
    for src_name, repo_rel in OVERLAY.items():
        src = here / src_name
        dst = REPO / repo_rel
        if not src.is_file():
            raise AssertionError(f"missing directed-test source {src}")
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)


def _run_suite() -> dict[str, str]:
    """Build and run the GPU zero-init suite once; return {case_name: status}.

    A case name maps to the last-seen status for that name. Names are matched by
    the module-qualified suffix (the runtime prefixes a backend/adapter tag).
    """
    _overlay_directed_tests()

    env = dict(os.environ)
    # The grade-time network reaches the model gateway only, not crates.io, and
    # the agent phase ran offline — so every crate the test binary needs is
    # already in the image's warm cargo cache. Build offline so a cache miss
    # fails loudly here instead of hanging on an unreachable registry. A logic
    # fix in wgpu-core does not touch Cargo.lock, so --locked + offline resolves.
    env["CARGO_NET_OFFLINE"] = "true"
    # The poison backend is set as an image ENV; assert it so a misconfigured
    # image fails loudly here instead of silently reading back zeros.
    if env.get("LVP_POISON_MEMORY") != "true":
        env["LVP_POISON_MEMORY"] = "true"

    # Build and run the whole zero_init module in one process. The correct
    # cases and the four previously-broken cases run together, so the fix is
    # judged by observable readback, not by which tests were selected.
    cmd = [
        "cargo",
        "test",
        "--locked",
        "-p",
        "wgpu-test",
        "--test",
        "wgpu-gpu",
        "--",
        "zero_init",
        "--test-threads=1",
    ]
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(REPO),
            env=env,
            capture_output=True,
            text=True,
            timeout=CARGO_TIMEOUT_SEC,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise AssertionError(
            f"GPU suite timed out after {CARGO_TIMEOUT_SEC}s (build + run)"
        ) from exc

    combined = (proc.stdout or "") + "\n" + (proc.stderr or "")
    results: dict[str, str] = {}
    for m in _RESULT_RE.finditer(combined):
        full_name, status = m.group(1).strip(), m.group(2)
        # Strip the runtime "[running] [backend/adapter/idx] " prefix, keeping
        # the module-qualified name the directed tests declare.
        key = full_name
        idx = full_name.find("zero_init::")
        if idx != -1:
            key = full_name[idx:]
        results[key] = status

    if not results:
        tail = combined[-3000:]
        raise AssertionError(
            f"GPU suite produced no parseable test results (exit {proc.returncode}). "
            f"Tail of output:\n{tail}"
        )
    return results


@pytest.fixture(scope="session")
def suite() -> dict[str, str]:
    return _run_suite()


def _assert_case_passed(results: dict[str, str], name: str) -> None:
    status = results.get(name)
    if status is None:
        ran = ", ".join(sorted(results)[:40])
        raise AssertionError(f"case {name!r} did not run. Cases seen: {ran}")
    assert status == "ok", f"case {name!r} reported {status}, expected ok"


def test_slice_init(suite: dict[str, str]) -> None:
    """Rendering into one depth slice of a 3D color texture leaves the other
    slices reading back zero rather than uninitialized memory."""
    _assert_case_passed(suite, TARGET_CASES["slice_init"])


def test_slice_discard(suite: dict[str, str]) -> None:
    """A depth slice left discarded reads back zero after submission, while a
    sibling slice that was written keeps its data."""
    _assert_case_passed(suite, TARGET_CASES["slice_discard"])


def test_multi_slice(suite: dict[str, str]) -> None:
    """Several depth slices of one 3D texture attached to the same pass are each
    tracked, with no uninitialized readback."""
    _assert_case_passed(suite, TARGET_CASES["multi_slice"])


def test_ds_divergent(suite: dict[str, str]) -> None:
    """A depth/stencil attachment that clears one aspect and loads the other with
    both stores discarded still reinitializes the discarded sub-resource."""
    _assert_case_passed(suite, TARGET_CASES["ds_divergent"])


def test_existing_init_unchanged(suite: dict[str, str]) -> None:
    """The pre-existing zero-initialization cases (2D textures, array layers, mip
    levels, buffers) keep passing: the fix must not regress them."""
    targets = set(TARGET_CASES.values())
    others = {name: st for name, st in suite.items() if name not in targets}
    assert others, "no pre-existing zero_init cases ran — suite did not execute"
    failed = sorted(name for name, st in others.items() if st == "FAILED")
    assert not failed, f"pre-existing zero_init cases regressed: {failed}"
