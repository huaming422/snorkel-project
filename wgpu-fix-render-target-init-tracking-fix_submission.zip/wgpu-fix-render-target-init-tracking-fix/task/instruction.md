## Task

we're getting flaky, garbage readback from render targets, and i've got two cases that reproduce it.

render into a single depth slice of a 3d color texture, then copy the whole texture out and read it back. the slices we never wrote come back wrong, full of junk, and it's different every run. those untouched regions are documented to read back zero.

separately, a depth/stencil attachment where one aspect is cleared and the other is loaded comes back the same way, uninitialized contents where we'd expect zeros.

dig into the root cause and fix it so untouched regions of a render target read back zero like they're supposed to. don't paper over it by unconditionally zero-filling every texture, and leave the existing tests as they are.
