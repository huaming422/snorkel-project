// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

// Behavioral checks for how the host iptables manager selects WireGuard
// tunnel traffic when installing its encryption-related rule groups.
//
// These checks live in package iptables (white-box) so they can build an
// unexported *manager with a SharedConfig and drive the two pre-existing
// installer methods directly, substituting a recording fake at the manager's
// command interface (ip4tables / ip6tables). They assert on the argument
// lists the manager asks the command interface to run — membership and
// substring, order-independent — rather than on an exact ordered script, so
// they hold regardless of how a solution structures the WireGuard branch
// (separate installer methods, a combined installer, or an inline branch) and
// regardless of comment wording or insert flag (-A vs -I).
//
// The symbols here are prefixed wgv* to avoid colliding with the package's
// own iptables_test.go, which defines its own mock in the same package.

package iptables

import (
	"strings"
	"testing"
)

// wgvListenPort is the UDP port the WireGuard tunnel device listens on. It is
// a fixed property of the WireGuard transport (the kernel/peer configuration),
// so the selector that uniquely identifies still-encrypted tunnel packets must
// match this destination port. Mirrors pkg/wireguard/types.ListenPort.
const wgvListenPort = "51871"

// wgvRecorder is a fake command interface (iptablesInterface) that records
// every argument list it is asked to run, instead of shelling out.
type wgvRecorder struct {
	prog string
	cmds []string
}

func (r *wgvRecorder) getProg() string  { return r.prog }
func (r *wgvRecorder) getIpset() string { return "" }
func (r *wgvRecorder) getMode() string  { return "" }

func (r *wgvRecorder) runProgOutput(args []string) (string, error) {
	r.cmds = append(r.cmds, strings.Join(args, " "))
	return "", nil
}

func (r *wgvRecorder) runProg(args []string) error {
	r.cmds = append(r.cmds, strings.Join(args, " "))
	return nil
}

// wgvNewManager builds a manager wired to two recording fakes, one per family.
func wgvNewManager(cfg SharedConfig) (*manager, *wgvRecorder, *wgvRecorder) {
	ip4 := &wgvRecorder{prog: "iptables"}
	ip6 := &wgvRecorder{prog: "ip6tables"}
	m := &manager{
		haveSocketMatch: true,
		sharedCfg:       cfg,
		ip4tables:       ip4,
		ip6tables:       ip6,
	}
	return m, ip4, ip6
}

// wgvContainsAll reports whether some recorded command contains every substring.
func wgvContainsAll(cmds []string, subs ...string) bool {
	for _, c := range cmds {
		ok := true
		for _, s := range subs {
			if !strings.Contains(c, s) {
				ok = false
				break
			}
		}
		if ok {
			return true
		}
	}
	return false
}

// wgvAnyContains reports whether any recorded command contains the substring.
func wgvAnyContains(cmds []string, sub string) bool {
	for _, c := range cmds {
		if strings.Contains(c, sub) {
			return true
		}
	}
	return false
}

// TestVerifyWireguardNoTrackProtoPort: with WireGuard enabled, the raw-table
// conntrack-control (NOTRACK) rules must select the encrypted tunnel traffic
// by protocol+port (UDP, destination port = WireGuard listen port), not by the
// decrypt/encrypt packet mark. Driving the no-track install path must emit, for
// each enabled family, raw-table rules on the pre-routing and output raw chains
// that match udp + the listen port and carry the CT --notrack target, and must
// emit no mark-based rule for the WireGuard case.
func TestVerifyWireguardNoTrackProtoPort(t *testing.T) {
	m, ip4, ip6 := wgvNewManager(SharedConfig{
		EnableIPv4:      true,
		EnableIPv6:      true,
		EnableWireguard: true,
	})

	if err := m.addCiliumNoTrackEncryptionRules(); err != nil {
		t.Fatalf("addCiliumNoTrackEncryptionRules returned error: %v", err)
	}

	for _, rec := range []*wgvRecorder{ip4, ip6} {
		if len(rec.cmds) == 0 {
			t.Errorf("%s: no commands emitted for the WireGuard no-track case", rec.prog)
			continue
		}
		if !wgvContainsAll(rec.cmds, "-t raw", ciliumPreRawChain, "udp", "--dport "+wgvListenPort, "--notrack") {
			t.Errorf("%s: expected a raw-table %s NOTRACK rule matching udp --dport %s; got: %v",
				rec.prog, ciliumPreRawChain, wgvListenPort, rec.cmds)
		}
		if !wgvContainsAll(rec.cmds, "-t raw", ciliumOutputRawChain, "udp", "--dport "+wgvListenPort, "--notrack") {
			t.Errorf("%s: expected a raw-table %s NOTRACK rule matching udp --dport %s; got: %v",
				rec.prog, ciliumOutputRawChain, wgvListenPort, rec.cmds)
		}
		if wgvAnyContains(rec.cmds, "-m mark") {
			t.Errorf("%s: WireGuard no-track rules must not select by packet mark; got: %v", rec.prog, rec.cmds)
		}
	}
}

// TestVerifyWireguardAcceptProtoPort: with WireGuard enabled, the filter-table
// ACCEPT exemption rules must likewise select WireGuard traffic by protocol+port
// on the input and output chains, not by packet mark. Driving the accept install
// path must emit, for each enabled family, filter-table ACCEPT rules on the input
// and output chains matching udp + the listen port, and no mark-based rule.
func TestVerifyWireguardAcceptProtoPort(t *testing.T) {
	m, ip4, ip6 := wgvNewManager(SharedConfig{
		EnableIPv4:      true,
		EnableIPv6:      true,
		EnableWireguard: true,
	})

	if err := m.addCiliumAcceptEncryptionRules(); err != nil {
		t.Fatalf("addCiliumAcceptEncryptionRules returned error: %v", err)
	}

	for _, rec := range []*wgvRecorder{ip4, ip6} {
		if len(rec.cmds) == 0 {
			t.Errorf("%s: no commands emitted for the WireGuard accept case", rec.prog)
			continue
		}
		if !wgvContainsAll(rec.cmds, "-t filter", ciliumOutputChain, "udp", "--dport "+wgvListenPort, "ACCEPT") {
			t.Errorf("%s: expected a filter-table %s ACCEPT rule matching udp --dport %s; got: %v",
				rec.prog, ciliumOutputChain, wgvListenPort, rec.cmds)
		}
		if !wgvContainsAll(rec.cmds, "-t filter", ciliumInputChain, "udp", "--dport "+wgvListenPort, "ACCEPT") {
			t.Errorf("%s: expected a filter-table %s ACCEPT rule matching udp --dport %s; got: %v",
				rec.prog, ciliumInputChain, wgvListenPort, rec.cmds)
		}
		if wgvAnyContains(rec.cmds, "-m mark") {
			t.Errorf("%s: WireGuard accept rules must not select by packet mark; got: %v", rec.prog, rec.cmds)
		}
	}
}

// TestVerifyIPSecMarkRulesPreserved: the non-WireGuard (IPSec) encryption path
// must keep selecting by packet mark. With IPSec enabled and WireGuard off, both
// installers must still emit the mark-based rules (decrypt 0x*d00 and encrypt
// 0x*e00 against the route-mark mask) and must not emit the WireGuard proto+port
// selector. Guards against an over-correction that strips mark matching from the
// still-correct IPSec path. Holds on both the pre-change and post-change code.
func TestVerifyIPSecMarkRulesPreserved(t *testing.T) {
	m, ip4, ip6 := wgvNewManager(SharedConfig{
		EnableIPv4:  true,
		EnableIPv6:  true,
		EnableIPSec: true,
	})

	if err := m.addCiliumNoTrackEncryptionRules(); err != nil {
		t.Fatalf("addCiliumNoTrackEncryptionRules returned error: %v", err)
	}
	if err := m.addCiliumAcceptEncryptionRules(); err != nil {
		t.Fatalf("addCiliumAcceptEncryptionRules returned error: %v", err)
	}

	all := append(append([]string{}, ip4.cmds...), ip6.cmds...)
	if len(all) == 0 {
		t.Fatalf("no commands emitted for the IPSec encryption case")
	}

	if !wgvAnyContains(all, "-m mark --mark 0x00000d00/0x00000f00") {
		t.Errorf("IPSec decrypt-mark rule missing; got: %v", all)
	}
	if !wgvAnyContains(all, "-m mark --mark 0x00000e00/0x00000f00") {
		t.Errorf("IPSec encrypt-mark rule missing; got: %v", all)
	}
	if wgvAnyContains(all, "--dport "+wgvListenPort) {
		t.Errorf("IPSec path must not emit the WireGuard proto+port selector; got: %v", all)
	}
}
