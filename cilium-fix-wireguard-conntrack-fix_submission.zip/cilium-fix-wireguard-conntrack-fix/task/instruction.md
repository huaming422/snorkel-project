## Task

heads up: on our WireGuard-encrypted clusters, traffic coming in over
the tunnel (after it's been decrypted) seems to be skipping conntrack
entirely. our host firewall rules that match on connection state
(`--ctstate NEW,RELATED,ESTABLISHED`) stopped matching that traffic, so
nodes with a default-DROP policy are silently dropping legit decrypted
packets. we're also seeing SNAT to the node address misbehave for traffic
that goes over the tunnel, with nothing there to drive the translation. this
used to work and broke after a recent change to how WireGuard packets get
handled.

you can reproduce this with a focused Go unit test in the host iptables
manager; that package builds and tests offline in this environment. the
BPF datapath side is part of the picture too, but it won't compile or run
here, so you'll need to reason about that part from the source.

can you dig in and get decrypted tunnel traffic tracked again, so the
ctstate rules and SNAT behave like they used to?
