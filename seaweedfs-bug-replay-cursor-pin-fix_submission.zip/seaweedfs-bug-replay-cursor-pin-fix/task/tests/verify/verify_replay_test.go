package dailyrun

// End-to-end tests for the daily-replay cursor-advance behavior. Every test
// drives the package-internal runShard / validate entrypoints and observes
// only their stable, externally-meaningful outputs: which objects the delete
// client saw, where the persisted cursor landed, and whether config
// validation errored. Nothing here names any helper the fix may add, so a
// solution that inlines the long-lived-rule filter and one that factors it
// behind a snapshot method both pass: the assertions gate on the meta-log
// drain's observable behavior, not on its internal shape.
//
// Helpers reused from sibling test files in this package: recordingClient /
// .seenObjects (process_matches_test.go), memPersister / newMemPersister
// (walker_recovery_test.go), stubSiblingLister / validatableConfig
// (walker_interval_test.go), plus Cursor / Config from the package itself.

import (
	"context"
	"testing"
	"time"

	"github.com/seaweedfs/seaweedfs/weed/pb/filer_pb"
	"github.com/seaweedfs/seaweedfs/weed/s3api/s3lifecycle"
	"github.com/seaweedfs/seaweedfs/weed/s3api/s3lifecycle/engine"
	"github.com/seaweedfs/seaweedfs/weed/s3api/s3lifecycle/reader"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// vrPut builds a meta-log PUT event for key whose object was last modified at
// (runNow - age); the drain reads that mtime to decide whether the matching
// rule is already due.
func vrPut(runNow time.Time, bucket, key string, age time.Duration) *reader.Event {
	at := runNow.Add(-age)
	return &reader.Event{
		TsNs:   at.UnixNano(),
		Bucket: bucket,
		Key:    key,
		NewEntry: &filer_pb.Entry{
			Name:       key,
			Attributes: &filer_pb.FuseAttributes{Mtime: at.Unix(), FileSize: 1},
		},
	}
}

// vrSeedCursor saves a cursor whose rule-set and promoted hashes match the
// snapshot under the given retention, so runShard takes the steady-state
// drain path (no recovery rewind, no cold-start floor) and the test observes
// the drain's own cursor handling. startTsNs is the replay floor.
func vrSeedCursor(t *testing.T, p *memPersister, snap *engine.Snapshot, shardID int, startTsNs int64, retention time.Duration, runNowT time.Time) {
	t.Helper()
	require.NoError(t, p.Save(context.Background(), shardID, Cursor{
		TsNs:         startTsNs,
		RuleSetHash:  engine.ReplayContentHash(snap),
		PromotedHash: engine.PromotedHash(snap, retention),
		LastWalkedNs: runNowT.UnixNano(),
	}))
}

// TestVerify_CursorAdvancesPastWalkBoundRule: a bucket carries a short (3d)
// and a long (30d) expiration rule under an 8-day meta-log retention window.
// The long rule can never come due inside the replay window, so its matching
// event must not hold the per-shard cursor: the cursor has to advance all the
// way to the last short-rule PUT. In the broken behavior, the long rule's
// not-yet-due match pins the cursor at the first short PUT and it never moves
// forward.
func TestVerify_CursorAdvancesPastWalkBoundRule(t *testing.T) {
	bucket := "b1"
	shortRule := &s3lifecycle.Rule{ID: "short", Status: s3lifecycle.StatusEnabled, Prefix: "short/", ExpirationDays: 3}
	longRule := &s3lifecycle.Rule{ID: "long", Status: s3lifecycle.StatusEnabled, Prefix: "long/", ExpirationDays: 30}
	e := engine.New()
	e.Compile([]engine.CompileInput{{Bucket: bucket, Rules: []*s3lifecycle.Rule{shortRule, longRule}}},
		engine.CompileOptions{PriorStates: map[s3lifecycle.ActionKey]engine.PriorState{
			{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(shortRule), ActionKind: s3lifecycle.ActionKindExpirationDays}: {BootstrapComplete: true},
			{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(longRule), ActionKind: s3lifecycle.ActionKindExpirationDays}:  {BootstrapComplete: true},
		}})
	snap := e.Snapshot()
	for _, a := range snap.AllActions() {
		snap.MarkActive(a.Key)
	}

	runNow := time.Unix(1_700_000_000, 0).UTC()
	retention := s3lifecycle.DaysToDuration(8)
	startTsNs := runNow.Add(-retention).UnixNano()
	p := newMemPersister()
	vrSeedCursor(t, p, snap, 0, startTsNs, retention, runNow)

	// A due short PUT, then a (not-yet-due) long PUT sandwiched before the
	// final due short PUT. If the long match pins the cursor, it freezes at
	// short/a instead of reaching short/b.
	events := make(chan *reader.Event, 3)
	events <- vrPut(runNow, bucket, "short/a", s3lifecycle.DaysToDuration(7))
	events <- vrPut(runNow, bucket, "long/a", s3lifecycle.DaysToDuration(6))
	last := vrPut(runNow, bucket, "short/b", s3lifecycle.DaysToDuration(5))
	events <- last
	close(events)

	client := &recordingClient{}
	cfg := Config{Persister: p, Client: client, Lister: stubSiblingLister{}, RetentionWindow: retention}
	require.NoError(t, runShard(context.Background(), cfg, snap, runNow, 0, events, nil))

	got, _, err := p.Load(context.Background(), 0)
	require.NoError(t, err)
	assert.Equal(t, last.TsNs, got.TsNs,
		"cursor must advance past the walk-bound rule's event to the last due short PUT")
	assert.ElementsMatch(t, []string{"short/a", "short/b"}, client.seenObjects(),
		"both due short-rule objects must dispatch; the long-rule object must not")
}

// TestVerify_WalkBoundAndDisabledRulesExcludedFromDrain: the meta-log drain's
// routing set must drop long-TTL rules (which are served by the separate walk
// path) and disabled rules, while keeping short-TTL rules. The long event
// arrives first: if it were still in the drain's routing set its not-yet-due
// match would pin the cursor at the replay floor and the later short event
// could never move it. The disabled rule's object must never dispatch.
func TestVerify_WalkBoundAndDisabledRulesExcludedFromDrain(t *testing.T) {
	bucket := "b2"
	shortRule := &s3lifecycle.Rule{ID: "short", Status: s3lifecycle.StatusEnabled, Prefix: "short/", ExpirationDays: 3}
	longRule := &s3lifecycle.Rule{ID: "long", Status: s3lifecycle.StatusEnabled, Prefix: "long/", ExpirationDays: 30}
	offRule := &s3lifecycle.Rule{ID: "off", Status: s3lifecycle.StatusDisabled, Prefix: "off/", ExpirationDays: 4}
	e := engine.New()
	e.Compile([]engine.CompileInput{{Bucket: bucket, Rules: []*s3lifecycle.Rule{shortRule, longRule, offRule}}},
		engine.CompileOptions{PriorStates: map[s3lifecycle.ActionKey]engine.PriorState{
			{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(shortRule), ActionKind: s3lifecycle.ActionKindExpirationDays}: {BootstrapComplete: true},
			{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(longRule), ActionKind: s3lifecycle.ActionKindExpirationDays}:  {BootstrapComplete: true},
		}})
	snap := e.Snapshot()
	for _, a := range snap.AllActions() {
		snap.MarkActive(a.Key)
	}

	runNow := time.Unix(1_700_000_000, 0).UTC()
	retention := s3lifecycle.DaysToDuration(8)
	startTsNs := runNow.Add(-retention).UnixNano()
	p := newMemPersister()
	vrSeedCursor(t, p, snap, 0, startTsNs, retention, runNow)

	// Long event first (would pin at the replay floor), then a disabled-rule
	// object (must never dispatch), then the due short event last. The cursor
	// may only reach the short event if the walk-bound and disabled events are
	// kept out of the drain and so never pin it.
	events := make(chan *reader.Event, 3)
	events <- vrPut(runNow, bucket, "long/a", s3lifecycle.DaysToDuration(7))
	events <- vrPut(runNow, bucket, "off/a", s3lifecycle.DaysToDuration(6))
	shortEv := vrPut(runNow, bucket, "short/a", s3lifecycle.DaysToDuration(5))
	events <- shortEv
	close(events)

	client := &recordingClient{}
	cfg := Config{Persister: p, Client: client, Lister: stubSiblingLister{}, RetentionWindow: retention}
	require.NoError(t, runShard(context.Background(), cfg, snap, runNow, 0, events, nil))

	got, _, err := p.Load(context.Background(), 0)
	require.NoError(t, err)
	assert.Equal(t, shortEv.TsNs, got.TsNs,
		"an earlier walk-bound event must not pin the cursor; it advances to the retained short rule's event")
	assert.ElementsMatch(t, []string{"short/a"}, client.seenObjects(),
		"only the retained short-TTL rule dispatches; long-TTL and disabled rules are excluded from the drain")
}

// TestVerify_ScanOnlyRuleRehabilitatedButBootstrapGated: a short rule locked
// to scan-only mode after its bootstrap already completed must still dispatch
// through the drain (it rejoins the event-driven replay set). A second short
// rule whose bootstrap never completed must stay inactive: the drain must not
// fire a rule whose one-time rendezvous has not run. In the broken behavior
// the scan-only rule is silently skipped by the router and never dispatches.
func TestVerify_ScanOnlyRuleRehabilitatedButBootstrapGated(t *testing.T) {
	bucket := "b3"
	ready := &s3lifecycle.Rule{ID: "ready", Status: s3lifecycle.StatusEnabled, Prefix: "ready/", ExpirationDays: 3}
	pending := &s3lifecycle.Rule{ID: "pending", Status: s3lifecycle.StatusEnabled, Prefix: "pending/", ExpirationDays: 4}
	readyKey := s3lifecycle.ActionKey{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(ready), ActionKind: s3lifecycle.ActionKindExpirationDays}
	pendingKey := s3lifecycle.ActionKey{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(pending), ActionKind: s3lifecycle.ActionKindExpirationDays}
	e := engine.New()
	e.Compile([]engine.CompileInput{{Bucket: bucket, Rules: []*s3lifecycle.Rule{ready, pending}}},
		engine.CompileOptions{PriorStates: map[s3lifecycle.ActionKey]engine.PriorState{
			readyKey:   {BootstrapComplete: true, Mode: engine.ModeScanOnly},
			pendingKey: {Mode: engine.ModeScanOnly}, // demoted before bootstrap finished
		}})
	snap := e.Snapshot()
	// Mirror the operator hint that the completed-bootstrap rule is live.
	// The pending rule is deliberately left un-marked so a drain that
	// force-activates every rule it rehabilitates would wrongly fire it.
	snap.MarkActive(readyKey)

	runNow := time.Unix(1_700_000_000, 0).UTC()
	retention := s3lifecycle.DaysToDuration(8)
	startTsNs := runNow.Add(-retention).UnixNano()
	p := newMemPersister()
	vrSeedCursor(t, p, snap, 0, startTsNs, retention, runNow)

	events := make(chan *reader.Event, 2)
	events <- vrPut(runNow, bucket, "ready/a", s3lifecycle.DaysToDuration(5))
	events <- vrPut(runNow, bucket, "pending/a", s3lifecycle.DaysToDuration(5))
	close(events)

	client := &recordingClient{}
	cfg := Config{Persister: p, Client: client, Lister: stubSiblingLister{}, RetentionWindow: retention}
	require.NoError(t, runShard(context.Background(), cfg, snap, runNow, 0, events, nil))

	assert.ElementsMatch(t, []string{"ready/a"}, client.seenObjects(),
		"the completed-bootstrap scan-only rule must dispatch; the pre-bootstrap rule must stay inactive")
}

// TestVerify_RetentionWindowWithoutWalkerRejected: a configured retention
// window hands long-TTL rules to the walk path; without a walker those rules
// lose their only dispatch path while the drain cursor still advances past
// their events. Config validation must reject that combination, and must
// accept it once a walker is supplied (and when no retention window is
// configured). In the broken behavior validation accepts retention with no
// walker silently.
func TestVerify_RetentionWindowWithoutWalkerRejected(t *testing.T) {
	cfg := validatableConfig()
	cfg.RetentionWindow = 24 * time.Hour
	cfg.Walker = nil
	require.Error(t, validate(cfg),
		"a retention window with no walker must be rejected")

	cfg.Walker = func(context.Context, *engine.Snapshot, []int) error { return nil }
	require.NoError(t, validate(cfg),
		"a retention window with a walker is valid")

	cfg.Walker = nil
	cfg.RetentionWindow = 0
	require.NoError(t, validate(cfg),
		"no retention window is valid regardless of the walker")
}

// TestVerify_NoRetentionWindowReplayUnchanged: with no retention window
// configured, nothing is handed to the walk path, so a plain short expiration
// rule still dispatches its due object through replay and the cursor advances,
// identical to the original behavior. This guards against an over-broad change
// that drops rules from the drain even when no retention window is set.
func TestVerify_NoRetentionWindowReplayUnchanged(t *testing.T) {
	bucket := "b4"
	shortRule := &s3lifecycle.Rule{ID: "short", Status: s3lifecycle.StatusEnabled, Prefix: "short/", ExpirationDays: 3}
	e := engine.New()
	e.Compile([]engine.CompileInput{{Bucket: bucket, Rules: []*s3lifecycle.Rule{shortRule}}},
		engine.CompileOptions{PriorStates: map[s3lifecycle.ActionKey]engine.PriorState{
			{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(shortRule), ActionKind: s3lifecycle.ActionKindExpirationDays}: {BootstrapComplete: true},
		}})
	snap := e.Snapshot()
	for _, a := range snap.AllActions() {
		snap.MarkActive(a.Key)
	}

	runNow := time.Unix(1_700_000_000, 0).UTC()
	// Floor the replay window well before the object so a due (age > TTL)
	// object still lands inside the scan window. With no retention window the
	// drain's own fallback promotes nothing, so this mirrors legacy behavior.
	startTsNs := runNow.Add(-s3lifecycle.DaysToDuration(10)).UnixNano()
	p := newMemPersister()
	// Seed the promoted hash with the drain's unconfigured fallback (the
	// largest active TTL) so the steady-state drain path is taken rather than
	// a recovery rewind.
	require.NoError(t, p.Save(context.Background(), 0, Cursor{
		TsNs:         startTsNs,
		RuleSetHash:  engine.ReplayContentHash(snap),
		PromotedHash: engine.PromotedHash(snap, engine.MaxEffectiveTTL(snap)),
		LastWalkedNs: runNow.UnixNano(),
	}))

	events := make(chan *reader.Event, 1)
	due := vrPut(runNow, bucket, "short/a", s3lifecycle.DaysToDuration(5))
	events <- due
	close(events)

	client := &recordingClient{}
	cfg := Config{Persister: p, Client: client, Lister: stubSiblingLister{}} // RetentionWindow unset
	require.NoError(t, runShard(context.Background(), cfg, snap, runNow, 0, events, nil))

	assert.ElementsMatch(t, []string{"short/a"}, client.seenObjects(),
		"with no retention window the short rule still dispatches through replay")
	got, _, err := p.Load(context.Background(), 0)
	require.NoError(t, err)
	assert.Equal(t, due.TsNs, got.TsNs,
		"with no retention window the cursor advances past the dispatched event as before")
}
