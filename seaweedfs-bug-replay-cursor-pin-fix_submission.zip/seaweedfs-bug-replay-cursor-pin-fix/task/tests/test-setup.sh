#!/usr/bin/env bash
# Runtime setup for the verifier phase. Must run with the network cut: the
# smoke gate's offline fold sources this inside `docker run --network none`.
# The Go module closure is already baked into the image at build time (§1.5);
# this only re-asserts it is satisfiable offline and fails fast on a miss.
set -euo pipefail

cd /repo/seaweedfs

# Offline switches right after cd so a cache miss fails fast instead of
# reaching for a dead registry. These mirror what the image baked via
# `go env -w`; exporting them here also covers the offline-fold probe.
export GOFLAGS=-mod=mod
export GOPROXY=off
export GOTOOLCHAIN=local
export CGO_ENABLED=0

# Dependencies: offline-first against the image bake, logged online fallback.
if GOFLAGS=-mod=mod GOPROXY=off go mod download > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] go mod satisfied from image"
elif go mod download >> /tmp/test-setup-install.log 2>&1; then
    echo "[test-setup] go mod installed online (image bake was stale)"
else
    tail -40 /tmp/test-setup-install.log >&2; exit 1
fi
