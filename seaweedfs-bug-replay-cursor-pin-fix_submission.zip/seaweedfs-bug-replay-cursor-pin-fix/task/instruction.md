## Task

hey, the daily S3 lifecycle cleanup is wedged on a couple of our buckets. the
per-shard replay progress marker just stops advancing and never recovers on its
own, the "how far behind" number creeps up about a day every day, and every pass
re-reads the same chunk of the change log from that stuck spot and re-issues
deletes we already did, which is chewing through the cluster delete rate limit.
the pass itself still reports success, so nothing's throwing; it only shows up as
the stuck marker and the wasted re-deletes.

it only seems to hit buckets that mix a short-lived expiration policy with a much
longer-lived one at the same time, with the change-log retention sitting
somewhere between the two lifetimes. a bucket with just one such policy is fine.
the change-log reader, the delete client, and the S3 API all look healthy; it's
the daily replay that's stuck.

can you reproduce the stuck progress, get to the root cause, and fix it so the
replay keeps advancing while the right objects still get expired?
