#!/usr/bin/env bash
# Environment bootstrap for the verifier.
#
# rulesync is a pure TypeScript project run through vitest, which transpiles
# `.ts` on the fly — there is no dist/ build step a source edit must be
# propagated through, so the verifier test imports the repository source
# directly (`./shared-config-gateway.js` specifiers are resolved by vitest's
# TS loader). The dependency closure is baked into the image at the base
# commit (jsonc-parser, es-toolkit, vitest, …), so this script does no
# network install; it only sanity-checks that the toolchain is intact.
#
# Sourced (not exec'd) by the harbor runner so any env vars set here stay live
# for the verifier subprocess.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/rulesync}"
export REPO_DIR
cd "$REPO_DIR"

# harbor reads verify.toml through the baked verifier venv (VERIFIER_PYTHON →
# /opt/tooling/venv, Python 3.12) whose stdlib has tomllib, so no toml reader
# needs installing here — the reader is guaranteed present at grade time.

# Sanity check: vitest must be resolvable from the repo root. A failure here
# points at a corrupted node_modules; reinstall from the frozen lockfile
# (offline-first — the pnpm store is warm in the image).
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/. " \
         "Re-running pnpm install (offline, from warm store)." >&2
    pnpm install --frozen-lockfile --ignore-scripts --offline
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
