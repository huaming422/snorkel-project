// @ts-nocheck

import { describe, it, expect } from "vitest";
import { parse as parseJsonc, parseTree, findNodeAtLocation, type ParseError } from "jsonc-parser";

import {
  applySharedConfigPatch,
  parseSharedConfig,
  stringifySharedConfig,
} from "./shared-config-gateway.js";
import { CopilotMcp } from "../mcp/copilot-mcp.js";
import { KiloMcp } from "../mcp/kilo-mcp.js";
import { OpencodeMcp } from "../mcp/opencode-mcp.js";
import { OpencodePermissions } from "../permissions/opencode-permissions.js";

function readJsonc(text: string): any {
  const errors: ParseError[] = [];
  const value = parseJsonc(text, errors, { allowTrailingComma: true });
  expect(errors).toEqual([]);
  return value;
}

function outsideValues(text: string, paths: (string | number)[][]): string {
  const root = parseTree(text, [], { allowTrailingComma: true })!;
  const spans = paths.map((path) => {
    const node = findNodeAtLocation(root, path);
    expect(node).toBeDefined();
    return { offset: node!.offset, length: node!.length };
  }).sort((a, b) => b.offset - a.offset);
  let result = text;
  for (const span of spans) {
    result = result.slice(0, span.offset) + "<changed-value>" + result.slice(span.offset + span.length);
  }
  return result;
}

function retainedArrayPrefix(text: string, path: (string | number)[], count: number): string {
  const root = parseTree(text, [], { allowTrailingComma: true })!;
  const array = findNodeAtLocation(root, path)!;
  expect(array.type).toBe("array");
  const last = array.children![count - 1];
  expect(last).toBeDefined();
  return text.slice(array.offset, last.offset + last.length);
}

function validatesContent(
  Cls: new (p: {
    relativeDirPath: string;
    relativeFilePath: string;
    fileContent: string;
    validate: boolean;
  }) => { validate: () => { success: boolean } },
  relativeFilePath: string,
  fileContent: string,
): boolean {
  try {
    const reader = new Cls({
      relativeDirPath: ".",
      relativeFilePath,
      fileContent,
      validate: false,
    });
    return reader.validate().success === true;
  } catch {
    return false;
  }
}

describe("comments survive a regenerate that changes a value", () => {
  it("keeps the top-of-file comment on .vscode/mcp.json and still writes the new servers", () => {
    const existingContent = [
      "// For more info, visit https://aka.ms/vscode-add-mcp",
      "{",
      '  "servers": {',
      '    "old": { "type": "stdio", "command": "old-bin" }',
      "  }",
      "}",
      "",
    ].join("\n");

    const result = applySharedConfigPatch({
      fileKey: ".vscode/mcp.json",
      feature: "mcp",
      existingContent,
      patch: { servers: { fresh: { type: "stdio", command: "fresh-bin" } } },
    });

    expect(result).toContain("// For more info, visit https://aka.ms/vscode-add-mcp");
    expect(readJsonc(result)).toEqual({
      servers: { fresh: { type: "stdio", command: "fresh-bin" } },
    });
  });

  it("also preserves comments on opencode.json", () => {
    const existingContent = [
      "{",
      "  // the project's MCP servers",
      '  "mcp": {',
      '    "old": { "type": "local", "command": ["old-bin"] }',
      "  }",
      "}",
      "",
    ].join("\n");

    const result = applySharedConfigPatch({
      fileKey: "opencode.json",
      feature: "mcp",
      existingContent,
      patch: { mcp: { fresh: { type: "local", command: ["fresh-bin"] } } },
    });

    expect(result).toContain("// the project's MCP servers");
    expect(readJsonc(result).mcp).toEqual({
      fresh: { type: "local", command: ["fresh-bin"] },
    });
  });
});

describe("a regenerate that computes identical content is byte-for-byte unchanged", () => {
  it("returns existingContent exactly when the patch yields the same servers", () => {
    const existingContent = [
      "// hand-written header",
      "{",
      "",
      '  // the primary server',
      '  "servers": {',
      '    "primary": { "type": "stdio", "command": "serve" }',
      "  }",
      "}",
      "",
    ].join("\n");

    const result = applySharedConfigPatch({
      fileKey: ".vscode/mcp.json",
      feature: "mcp",
      existingContent,
      patch: { servers: { primary: { type: "stdio", command: "serve" } } },
    });

    expect(result).toBe(existingContent);
  });
});

describe("a nested one-key change leaves sibling keys and their comments intact", () => {
  it("rewrites only the changed server, preserving the untouched sibling's comment and bytes", () => {
    const existingContent = [
      "{",
      '  "servers": {',
      "    // alpha is the untouched sibling",
      '    "alpha": { "type": "stdio", "command": "alpha-bin" },',
      "    // beta will change",
      '    "beta": { "type": "stdio", "command": "beta-old" }',
      "  }",
      "}",
      "",
    ].join("\n");

    const result = applySharedConfigPatch({
      fileKey: ".vscode/mcp.json",
      feature: "mcp",
      existingContent,
      patch: {
        servers: {
          alpha: { type: "stdio", command: "alpha-bin" }, // unchanged
          beta: { type: "stdio", command: "beta-new" }, // changed
        },
      },
    });

    expect(result).toContain("// alpha is the untouched sibling");
    expect(result).toContain("// beta will change");
    expect(result).toContain('    "alpha": { "type": "stdio", "command": "alpha-bin" },');
    const parsed = readJsonc(result);
    expect(parsed.servers.alpha).toEqual({ type: "stdio", command: "alpha-bin" });
    expect(parsed.servers.beta).toEqual({ type: "stdio", command: "beta-new" });
  });
});

describe("edits match the file's own indentation and line ending", () => {
  it("preserves 4-space indentation on untouched lines and does not reflow them to 2 spaces", () => {
    const existingContent = [
      "{",
      '    "servers": {',
      '        "alpha": {',
      '            "type": "stdio",',
      '            "command": "alpha-bin"',
      "        },",
      '        "beta": {',
      '            "type": "stdio",',
      '            "command": "beta-old"',
      "        }",
      "    }",
      "}",
      "",
    ].join("\n");

    const result = applySharedConfigPatch({
      fileKey: ".vscode/mcp.json",
      feature: "mcp",
      existingContent,
      patch: {
        servers: {
          alpha: { type: "stdio", command: "alpha-bin" }, // unchanged
          beta: { type: "stdio", command: "beta-new" }, // changed
        },
      },
    });

    expect(result).toContain('\n            "command": "alpha-bin"');
    expect(readJsonc(result).servers.beta.command).toBe(
      "beta-new",
    );
  });

  it("preserves tab indentation on untouched lines", () => {
    const existingContent = [
      "{",
      '\t"servers": {',
      '\t\t"alpha": {',
      '\t\t\t"type": "stdio",',
      '\t\t\t"command": "alpha-bin"',
      "\t\t},",
      '\t\t"beta": {',
      '\t\t\t"type": "stdio",',
      '\t\t\t"command": "beta-old"',
      "\t\t}",
      "\t}",
      "}",
      "",
    ].join("\n");

    const result = applySharedConfigPatch({
      fileKey: ".vscode/mcp.json",
      feature: "mcp",
      existingContent,
      patch: {
        servers: {
          alpha: { type: "stdio", command: "alpha-bin" },
          beta: { type: "stdio", command: "beta-new" },
        },
      },
    });

    expect(result).toContain('\n\t\t\t"command": "alpha-bin"');
    expect(readJsonc(result).servers.beta.command).toBe(
      "beta-new",
    );
  });

  it("keeps CRLF line endings when a value changes", () => {
    const existingContent =
      [
        "// crlf file",
        "{",
        '  "servers": {',
        '    "primary": { "type": "stdio", "command": "old-bin" }',
        "  }",
        "}",
      ].join("\r\n") + "\r\n";

    const result = applySharedConfigPatch({
      fileKey: ".vscode/mcp.json",
      feature: "mcp",
      existingContent,
      patch: { servers: { primary: { type: "stdio", command: "new-bin" } } },
    });

    expect(result).toContain("\r\n");
    expect(result.replaceAll("\r\n", "")).not.toMatch(/[\r\n]/);
    expect(result).toContain("// crlf file");
    expect(readJsonc(result).servers.primary.command).toBe(
      "new-bin",
    );
  });
});

describe("unparsable / non-object / empty JSONC falls back to the whole-document writer", () => {
  const patch = { mcp: { srv: { type: "local", command: ["run"] } } };

  it("empty content produces the merged document", () => {
    const result = applySharedConfigPatch({
      fileKey: "opencode.json",
      feature: "mcp",
      existingContent: "   \n  ",
      patch,
    });
    expect(readJsonc(result)).toEqual({ mcp: patch.mcp });
  });

  it("non-object root (array) → no throw, file states the merged mcp", () => {
    const result = applySharedConfigPatch({
      fileKey: "opencode.json",
      feature: "mcp",
      existingContent: "[1, 2, 3]",
      patch,
    });
    const parsed = readJsonc(result);
    expect(parsed.mcp).toEqual(patch.mcp);
    expect(Array.isArray(parsed)).toBe(false);
  });

  it("unparsable content → no throw, file states the merged mcp", () => {
    const result = applySharedConfigPatch({
      fileKey: "opencode.json",
      feature: "mcp",
      existingContent: '{ "mcp": { "oops" ',
      patch,
    });
    const parsed = readJsonc(result);
    expect(parsed.mcp).toEqual(patch.mcp);
  });
});

describe("pollution-key / duplicate-key documents fall back and drop pollution keys", () => {
  it("drops a root-level __proto__ and writes the whole document", () => {
    const existingContent = [
      "{",
      '  "mcp": { "existing": { "type": "local", "command": ["old"] } },',
      '  "__proto__": { "polluted": true }',
      "}",
      "",
    ].join("\n");

    const result = applySharedConfigPatch({
      fileKey: "opencode.json",
      feature: "mcp",
      existingContent,
      patch: { mcp: { fresh: { type: "local", command: ["new"] } } },
    });

    expect(result).not.toContain("__proto__");
    expect(result).not.toContain("polluted");
    const parsed = readJsonc(result);
    expect(parsed.mcp).toEqual({ fresh: { type: "local", command: ["new"] } });
    expect(Object.prototype.hasOwnProperty.call(parsed, "polluted")).toBe(false);
  });

  it("retains the effective last-wins value of a duplicated unmanaged key", () => {
    const existingContent = [
      "{",
      '  "mcp": { "existing": { "type": "local", "command": ["old"] } },',
      '  "theme": "light",',
      '  "theme": "dark"',
      "}",
      "",
    ].join("\n");

    const result = applySharedConfigPatch({
      fileKey: "opencode.json",
      feature: "mcp",
      existingContent,
      patch: { mcp: { fresh: { type: "local", command: ["new"] } } },
    });

    const parsed = readJsonc(result);
    expect(parsed.mcp).toEqual({ fresh: { type: "local", command: ["new"] } });
    expect(parsed.theme).toBe("dark");
  });
});

describe("large JSONC updates preserve untouched text and complete promptly", () => {
  it.each([
    { count: 2000, commandLength: 0 },
    { count: 1, commandLength: 210_000 },
  ])("preserves authored text with $count changed servers and $commandLength command padding", ({ count, commandLength }) => {
    const base: Record<string, unknown> = {};
    const next: Record<string, unknown> = {};
    const padding = "x".repeat(commandLength);
    for (let i = 0; i < count; i += 1) {
      base[`srv${i}`] = { type: "local", command: [`old-${i}`] };
      next[`srv${i}`] = { type: "local", command: [`new-${i}${padding}`] };
    }
    const keep = { type: "local", command: ["keep"] };
    next.keep = keep;
    const prefix = '// authored header\n{\n  "zebra": 1,\n\n  "mcp": {\n' +
      '    // unchanged server\n    "keep" : { "type": "local", "command": ["keep"] },\n';
    const suffix = '\n  },\n\n  // final setting\n  "alpha" : 2\n}\n';
    const entries = Object.entries(base).map(([key, value]) =>
      `    ${JSON.stringify(key)}: ${JSON.stringify(value)}`).join(",\n");
    const existingContent = prefix + entries + suffix;

    const started = Date.now();
    const result = applySharedConfigPatch({
      fileKey: "opencode.json",
      feature: "mcp",
      existingContent,
      patch: { mcp: next },
    });
    const elapsedMs = Date.now() - started;

    expect(elapsedMs).toBeLessThan(120_000);
    expect(result.startsWith(prefix)).toBe(true);
    expect(result.endsWith(suffix)).toBe(true);
    const parsed = readJsonc(result);
    expect(Object.keys(parsed.mcp)).toHaveLength(count + 1);
    expect(parsed.mcp).toEqual(next);
    expect(parsed.zebra).toBe(1);
    expect(parsed.alpha).toBe(2);
    expect(applySharedConfigPatch({
      fileKey: "opencode.json", feature: "mcp", existingContent: result,
      patch: { mcp: next },
    })).toBe(result);
  });
});

describe("readers accept JSONC comments but still reject malformed content", () => {
  const commentedCopilot = [
    "// For more info, visit https://aka.ms/vscode-add-mcp",
    "{",
    '  "servers": { "s": { "type": "stdio", "command": "c" } }',
    "}",
  ].join("\n");

  it("CopilotMcp reads server data from commented content", () => {
    const reader = new CopilotMcp({
      relativeDirPath: ".vscode",
      relativeFilePath: "mcp.json",
      fileContent: commentedCopilot,
      validate: false,
    });
    expect(reader.getJson().servers).toEqual({ s: { type: "stdio", command: "c" } });
  });

  it("CopilotMcp still throws on genuinely malformed content", () => {
    expect(
      () =>
        new CopilotMcp({
          relativeDirPath: ".vscode",
          relativeFilePath: "mcp.json",
          fileContent: '{ "servers": { "s": ',
          validate: false,
        }),
    ).toThrow();
  });

  it("KiloMcp accepts commented content and rejects malformed", () => {
    expect(validatesContent(KiloMcp, "kilo.jsonc", '{ /* kilo config */ "mcp": {} }')).toBe(true);
    expect(validatesContent(KiloMcp, "kilo.jsonc", "{ not valid ")).toBe(false);
  });

  it("OpencodeMcp accepts commented content and rejects malformed", () => {
    expect(validatesContent(OpencodeMcp, "opencode.jsonc", '{ /* opencode */ "mcp": {} }')).toBe(
      true,
    );
    expect(validatesContent(OpencodeMcp, "opencode.jsonc", '{ "mcp": ')).toBe(false);
  });

  it("OpencodePermissions accepts commented content and rejects malformed", () => {
    expect(
      validatesContent(
        OpencodePermissions,
        "opencode.jsonc",
        '{ // perms\n "permission": { "bash": "ask" } }',
      ),
    ).toBe(true);
    expect(validatesContent(OpencodePermissions, "opencode.jsonc", '{ "permission": ')).toBe(false);
  });
});

describe("non-JSONC formats stay whole-document re-serialized", () => {
  it("a YAML file is re-serialized whole (its comment is not preserved)", () => {
    const existingContent = ["# my goose config", "extensions:", "  old:", "    type: stdio", ""].join(
      "\n",
    );

    const result = applySharedConfigPatch({
      fileKey: ".config/goose/config.yaml",
      feature: "mcp",
      existingContent,
      patch: { extensions: { fresh: { type: "stdio" } } },
    });

    expect(result).toBe(
      stringifySharedConfig({ format: "yaml", document: { extensions: { fresh: { type: "stdio" } } } }),
    );
    expect(result).not.toContain("# my goose config");
  });
});

describe("pre-existing behaviour is not regressed", () => {
  it("parseSharedConfig still treats empty/whitespace as an empty document in every format", () => {
    expect(parseSharedConfig({ format: "jsonc", fileContent: "" })).toEqual({});
    expect(parseSharedConfig({ format: "json", fileContent: "  \n" })).toEqual({});
    expect(parseSharedConfig({ format: "yaml", fileContent: "" })).toEqual({});
  });

  it("a plain (comment-free) JSON merge still produces the merged document", () => {
    const existingContent = '{\n  "servers": {\n    "a": { "type": "stdio", "command": "a" }\n  }\n}\n';
    const result = applySharedConfigPatch({
      fileKey: ".vscode/mcp.json",
      feature: "mcp",
      existingContent,
      patch: { servers: { b: { type: "stdio", command: "b" } } },
    });
    expect(readJsonc(result)).toEqual({
      servers: { b: { type: "stdio", command: "b" } },
    });
  });

  it("a comment-free reader file still validates", () => {
    expect(validatesContent(OpencodeMcp, "opencode.json", '{ "mcp": {} }')).toBe(true);
  });
});

describe("untouched text during changed writes", () => {
  it("keeps blank lines and authored key order around an updated value", () => {
    const prefix = '{\n  "zebra": 1,\n\n  // server list\n  "servers": { "s": { "command": "';
    const suffix = '" } },\n\n  "alpha": 2\n}\n';
    const result = applySharedConfigPatch({
      fileKey: ".vscode/mcp.json", feature: "mcp",
      existingContent: prefix + 'old' + suffix,
      patch: { servers: { s: { command: "new" } } },
    });
    expect(result.startsWith(prefix)).toBe(true);
    expect(result.endsWith(suffix)).toBe(true);
    expect(readJsonc(result)).toEqual({ zebra: 1, servers: { s: { command: "new" } }, alpha: 2 });
  });

  it("keeps an unchanged sibling's note when a neighboring server is removed or inserted", () => {
    const existingContent = [
      '{', '  "servers": {',
      '    "retired": { "command": "old" },',
      '    // the retained server',
      '    "keep": { "command": "keep" } // keep this note',
      '  }', '}', '',
    ].join('\n');
    const result = applySharedConfigPatch({
      fileKey: ".vscode/mcp.json", feature: "mcp", existingContent,
      patch: { servers: { keep: { command: "keep" }, fresh: { command: "new" } } },
    });
    expect(readJsonc(result)).toEqual({ servers: { keep: { command: "keep" }, fresh: { command: "new" } } });
    expect(result).toContain('    // the retained server\n    "keep": { "command": "keep" }');
    const keepLine = result.split('\n').find((line) => line.includes('"keep":'))!;
    expect(keepLine).toContain('// keep this note');
  });

  it("preserves comments through literal dotted-key writes and retraction", () => {
    const existingContent = '// amp config\n{\n  "editor": true,\n  "amp.mcpServers": { "old": { "command": "old" } }\n}\n';
    const updated = applySharedConfigPatch({
      fileKey: ".amp/settings.json", feature: "mcp", existingContent,
      patch: { "amp.mcpServers": { fresh: { command: "new" } } },
    });
    expect(readJsonc(updated)).toEqual({ editor: true, "amp.mcpServers": { fresh: { command: "new" } } });
    expect(updated).toContain('// amp config\n{\n  "editor": true,');
    const removed = applySharedConfigPatch({
      fileKey: ".amp/settings.json", feature: "mcp", existingContent: updated,
      patch: { "amp.mcpServers": undefined },
    });
    expect(readJsonc(removed)).toEqual({ editor: true });
    expect(removed).toContain('// amp config');
    expect(removed).toContain('  "editor": true');
  });
});

describe("existing format and rejection policies", () => {
  it("retains TOML values and whole-document serialization", () => {
    const result = applySharedConfigPatch({
      fileKey: ".codex/config.toml", feature: "mcp",
      existingContent: '# local note\nmodel = "chosen"\n[mcp_servers.old]\ncommand = "old"\n',
      patch: { mcp_servers: { fresh: { command: "new" } } },
    });
    const document = { model: "chosen", mcp_servers: { fresh: { command: "new" } } };
    expect(parseSharedConfig({ format: "toml", fileContent: result })).toEqual(document);
    expect(result).toBe(stringifySharedConfig({ format: "toml", document }));
    expect(result).not.toContain('# local note');
  });

  it("refuses malformed or array-root VS Code content", () => {
    for (const existingContent of ['{ "servers": ', '[1, 2]']) {
      expect(() => applySharedConfigPatch({
        fileKey: ".vscode/mcp.json", feature: "mcp", existingContent,
        patch: { servers: {} },
      })).toThrow();
    }
  });
});

describe("same-length JSONC array updates retain unchanged element text", () => {
  it.each(["\n", "\r\n"])("keeps command argument notes and spelling with %j line endings", (eol) => {
    const existingContent = [
      '// server command', '{', '  "mcp": { "s": { "type": "local", "command": [',
      '    "n\\u006fde", // executable',
      '',
      '    /* selected script */ "old.js",',
      '    "--keep" // stable option',
      '  ] } }', '}', '',
    ].join(eol);
    const patch = { mcp: { s: { type: "local", command: ["node", "new-script.js", "--keep"] } } };
    const result = applySharedConfigPatch({ fileKey: "opencode.json", feature: "mcp", existingContent, patch });
    expect(readJsonc(result)).toEqual(patch);
    const changed = [["mcp", "s", "command", 1]];
    expect(outsideValues(result, changed)).toBe(outsideValues(existingContent, changed));
    expect(applySharedConfigPatch({ fileKey: "opencode.json", feature: "mcp", existingContent: result, patch })).toBe(result);
    expect(new OpencodeMcp({ relativeDirPath: ".", relativeFilePath: "opencode.json", fileContent: result, validate: false }).validate().success).toBe(true);
  });

  it("retains nested array and object text when scalar fields change", () => {
    const existingContent = [
      '{ "servers": { "s": { "command": "node", "options": [',
      '  { "mode" : "keep", /* object note */ "limit": 7 },',
      '  [ /* list note */ "stable", { "value": "old", "keep" : true } ]',
      '] } } }',
    ].join('\n');
    const patch = { servers: { s: { command: "node", options: [
      { mode: "keep", limit: 11 }, ["stable", { value: "new", keep: true }],
    ] } } };
    const result = applySharedConfigPatch({ fileKey: ".vscode/mcp.json", feature: "mcp", existingContent, patch });
    expect(readJsonc(result)).toEqual(patch);
    const changed = [["servers", "s", "options", 0, "limit"], ["servers", "s", "options", 1, 1, "value"]];
    expect(outsideValues(result, changed)).toBe(outsideValues(existingContent, changed));
    expect(applySharedConfigPatch({ fileKey: ".vscode/mcp.json", feature: "mcp", existingContent: result, patch })).toBe(result);
  });

  it("retains object notes through field insertion and removal inside nested arrays", () => {
    const existingContent = [
      '{ "servers": { "s": { "command": "node", "options": [',
      '  { "stable" : true },',
      '  [{',
      '    "retired": 1,',
      '    // retained field',
      '    "keep" : "yes" // field note',
      '  }]',
      '] } } }',
    ].join('\n');
    const patch = { servers: { s: { command: "node", options: [
      { stable: true }, [{ keep: "yes", fresh: { enabled: true } }],
    ] } } };
    const result = applySharedConfigPatch({ fileKey: ".vscode/mcp.json", feature: "mcp", existingContent, patch });
    expect(readJsonc(result)).toEqual(patch);
    expect(result).toContain('  { "stable" : true },');
    expect(result).toContain('    // retained field\n    "keep" : "yes"');
    expect(result.split('\n').find((line) => line.includes('"keep"'))).toContain('// field note');
    expect(applySharedConfigPatch({ fileKey: ".vscode/mcp.json", feature: "mcp", existingContent: result, patch })).toBe(result);
  });

  it("preserves stable positions beside type changes and still writes resized arrays", () => {
    const existingContent = '{ "servers": { "s": { "options": [ /* keep */ "stable", "old", { "old": true } ] } } }';
    const patch = { servers: { s: { options: ["stable", { fresh: true }, null] } } };
    const result = applySharedConfigPatch({ fileKey: ".vscode/mcp.json", feature: "mcp", existingContent, patch });
    expect(readJsonc(result)).toEqual(patch);
    expect(result).toContain('[ /* keep */ "stable",');
    expect(applySharedConfigPatch({ fileKey: ".vscode/mcp.json", feature: "mcp", existingContent: result, patch })).toBe(result);
    for (const options of [[], ["stable"], ["stable", "one", "two", "three"]]) {
      const resizedPatch = { servers: { s: { options } } };
      const resized = applySharedConfigPatch({ fileKey: ".vscode/mcp.json", feature: "mcp", existingContent: result, patch: resizedPatch });
      expect(readJsonc(resized)).toEqual(resizedPatch);
      expect(applySharedConfigPatch({ fileKey: ".vscode/mcp.json", feature: "mcp", existingContent: resized, patch: resizedPatch })).toBe(resized);
    }
  });
});

describe("appending JSONC array values keeps retained entries and their notes", () => {
  it.each(["\n", "\r\n"])("preserves annotated command arguments with %j line endings", (eol) => {
    const existingContent = [
      '{', '  "mcp": { "s": { "type": "local", "command": [',
      '    "n\\u006fde", // executable',
      '    "serve" // script to keep',
      '  ] } }', '}', '',
    ].join(eol);
    const patch = { mcp: { s: { type: "local", command: ["node", "serve", "--verbose"] } } };
    const result = applySharedConfigPatch({ fileKey: "opencode.json", feature: "mcp", existingContent, patch });
    expect(readJsonc(result)).toEqual(patch);
    expect(retainedArrayPrefix(result, ["mcp", "s", "command"], 2)).toBe(
      retainedArrayPrefix(existingContent, ["mcp", "s", "command"], 2),
    );
    expect(result).toContain('    "n\\u006fde", // executable' + eol);
    expect(result).toContain('    "serve", // script to keep' + eol);
    expect(result.indexOf('// script to keep')).toBeLessThan(result.indexOf('"--verbose"'));
    expect(result).toContain(eol);
    expect(applySharedConfigPatch({ fileKey: "opencode.json", feature: "mcp", existingContent: result, patch })).toBe(result);
  });

  it("preserves a nested array prefix when its parent array keeps its length", () => {
    const existingContent = '{ "servers": { "s": { "options": [ [ /* first */ "keep" ], "other" ] } } }';
    const patch = { servers: { s: { options: [["keep", "added"], "other"] } } };
    const result = applySharedConfigPatch({ fileKey: ".vscode/mcp.json", feature: "mcp", existingContent, patch });
    expect(readJsonc(result)).toEqual(patch);
    expect(retainedArrayPrefix(result, ["servers", "s", "options", 0], 1)).toBe(
      retainedArrayPrefix(existingContent, ["servers", "s", "options", 0], 1),
    );
    expect(result).toContain('"other" ]');
    expect(result.indexOf('"keep"')).toBeLessThan(result.indexOf('"added"'));
  });

  it("keeps an inline block note on the original final argument", () => {
    const existingContent = '{ "mcp": { "s": { "type": "local", "command": [ "node" /* executable */ ] } } }';
    const patch = { mcp: { s: { type: "local", command: ["node", "serve"] } } };
    const result = applySharedConfigPatch({ fileKey: "opencode.json", feature: "mcp", existingContent, patch });
    expect(readJsonc(result)).toEqual(patch);
    expect(retainedArrayPrefix(result, ["mcp", "s", "command"], 1)).toBe(
      retainedArrayPrefix(existingContent, ["mcp", "s", "command"], 1),
    );
    expect(result).toMatch(/"node"(?:,\s*\/\* executable \*\/|\s*\/\* executable \*\/,)\s*"serve"/);
  });
});
