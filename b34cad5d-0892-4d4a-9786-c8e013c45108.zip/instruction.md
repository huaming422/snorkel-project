## Task

Regenerating rulesync configs removes hand-written comments, blank lines and key order from JSONC files, even when the generated values have not changed. In `.vscode/mcp.json`, the comment created by VS Code's "MCP: Add Server" command disappears on the next run. Preserve the text outside changed values, including unchanged nested entries, and leave a no-op regeneration byte-for-byte unchanged.

The regenerated files must remain readable with comments, while readers must still reject malformed input. Retain existing invalid-file handling and removal of prototype-pollution keys. Files with duplicate or unsafe keys may be normalized, but duplicate unmanaged keys must retain their effective last-wins value. Leave YAML and TOML behavior unchanged.

When a JSONC array keeps its length, preserve the text of unchanged positions and unchanged fields inside object elements, including their comments. This also applies to nested arrays and to updates that add or remove fields inside an element. When values are appended without changing existing positions, preserve the text and notes on those positions too. Other length-changing arrays may be replaced as complete values.
