## Task

we're getting reports that on touch devices, tapping a cell in a table to place the cursor often fails. instead of a caret landing in the cell they tapped, a multi-cell selection across the table sometimes lights up. a following tap clears that stray selection, so from the user's side the taps look broken, like they do nothing. it's most noticeable when a table is the only content in the editor. the same tables behave fine with a mouse, so this is specific to touch input.

tapping a cell on touch should reliably place the caret in that cell, while dragging a finger across cells should still select the range it covers. mouse selection should stay exactly as it is today. dig in and fix the touch behavior.
