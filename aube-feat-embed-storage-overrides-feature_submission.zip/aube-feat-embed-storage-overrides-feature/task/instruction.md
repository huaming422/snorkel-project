## Task

We want a program that embeds aube as an in-process install engine to aim a single install or add at storage it picks for that one call: its own cache directory, its own store directory, and its own choice about whether to use the shared global virtual store. It should be able to do that without touching any process-wide or on-disk configuration.

Add two entry points to the `aube::embed` facade, `install_with_overrides` and `add_with_overrides`, that take the same inputs as `install` and `add` plus a per-call storage override value. That value is the public API you are delivering: each of those three choices is an optional field, and an unset field keeps the call's normal behavior.

`install`, `add`, and the standalone CLI stay exactly as they are today.

## User stories / requirements

- A host running one install with storage overrides reads and writes only at those locations, overriding the ambient environment and project or user configuration, and affects that call alone. Turning the global virtual store off materializes packages inside the project, not a shared global store. Paths are honored exactly, even when not valid UTF-8.
- When a host adds a dependency to a project with storage overrides, both the add and the install it triggers use the host-chosen storage locations and materialization policy for that one call.
- A stored file's recorded location survives being written out and read back completely unchanged, even when that location is a path the operating system permits but that is not valid UTF-8.
- Storage overrides affect only the single call they are passed to and do not leak to any concurrent or later call. A plain install running at the same time as an overridden install resolves against its own ambient storage, not the override's host store.
