#!/usr/bin/env bash
#
# Structural verifier — confirms the whole feature integrates and the two
# library targets still compile after the change.
#
# Threading a per-call storage override through the settings/storage
# resolution path ripples into every consumer of that path (store open,
# cache-dir and store-dir resolution, the global-virtual-store decision, the
# warm probe, and the add path), and the new store-index serde plus any new
# add-options field force their callers to update. If the new facade entry
# points are added but a storage-resolution consumer, an add-options caller,
# or a store-index user is left inconsistent, the library build breaks here.
#
# We check the library targets only (NOT `--tests`): the crate's own test
# targets pull in extra dev tooling unrelated to this feature, and the lib
# check is what proves the feature's call sites are consistent. The image
# pre-warms `cargo check -p aube -p aube-store`, so a warm run is quick; the
# `[shell]` timeout in verify.toml covers a cold target dir with margin.
#
# The runner cwd is the repository dir; the workspace root is /repo/aube.
#
# Exit codes:
#   0        — both crates check cleanly
#   non-zero — propagates the cargo failure

set -euo pipefail

cd /repo/aube

cargo check -p aube -p aube-store
