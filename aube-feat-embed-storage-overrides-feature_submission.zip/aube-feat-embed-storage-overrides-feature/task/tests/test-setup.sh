#!/usr/bin/env bash
# No services to start, no data to seed: the image pre-warms the cargo
# registry/store cache and builds the workspace at the base commit, and the
# verifier is self-contained. Grade time runs offline.
set -euo pipefail

echo "[test-setup] Rust version:    $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:   $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Node version:    $(node --version 2>&1 | head -1)"
echo "[test-setup] Workspace root:  /repo/aube"
echo "[test-setup] Setup complete."
