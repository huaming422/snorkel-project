// @ts-nocheck
//
// Behavioral verifier for the preview-tooling fix, driven entirely through the
// server's own MCP server test harness: it stands up the preview toolkit layer
// against a fake browser broker, calls the registered tools, and inspects the
// returned content blocks + structured output. Every interface imported here is
// pre-existing and stable in the pre-fix tree (the MCP server namespace, the
// invocation-context service, the fake broker, and the server-config service +
// its test layer). No symbol the fix introduces is imported.
//
// FAIRNESS NOTES (why the assertions look behavioral rather than literal):
//   * The agent-visible text budget is checked against the MCP client's
//     documented single-result cap (~25k tokens ≈ 100 KB at ~4 bytes/token),
//     not against any particular internal budget constant. Any fix that keeps
//     the text under the client ceiling passes, whether it bounds at 50 KB,
//     60 KB, or elsewhere.
//   * Per-field caps (visible text, element names, log-window size) are asserted
//     as "much smaller than the oversized input / newest-kept", never as the
//     reference's exact numbers.
//   * The saved-screenshot location is anchored on the pre-existing server-owned
//     base directory (`config.baseDir`); the path field and the evaluate wrapper
//     key are discovered by value, so alternative field/dir names round-trip.
//   * The save-failure tag is discovered from the envelope; only its stable
//     surrounding shape ({ _tag, operation, failureCount }) and its being a
//     distinct screenshot/save error are asserted.

import { expect, it } from "@effect/vitest";
import * as NodeServices from "@effect/platform-node/NodeServices";
import { EnvironmentId, PreviewTabId, ProviderInstanceId, ThreadId } from "@t3tools/contracts";
import * as Deferred from "effect/Deferred";
import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Layer from "effect/Layer";
import * as Schema from "effect/Schema";
import * as Stream from "effect/Stream";
import { McpSchema, McpServer } from "effect/unstable/ai";

import * as ServerConfig from "../config.ts";
import * as McpHttpServer from "./McpHttpServer.ts";
import * as McpInvocationContext from "./McpInvocationContext.ts";
import * as PreviewAutomationBroker from "./PreviewAutomationBroker.ts";

// The MCP client replaces an over-budget tool result with a truncation notice
// when a single result exceeds ~25k tokens; ~4 bytes/token gives the byte cap
// the agent-visible snapshot text must stay under. This is the external client
// constraint, not the fix's chosen internal budget.
const AGENT_OUTPUT_CEILING_BYTES = 100_000;

const environmentId = EnvironmentId.make("environment-mcp-test");
const threadId = ThreadId.make("thread-mcp-test");
const decodeJsonText = Schema.decodeUnknownSync(Schema.fromJsonString(Schema.Unknown));

const invocation = {
  environmentId,
  threadId,
  providerSessionId: "provider-session-mcp-test",
  providerInstanceId: ProviderInstanceId.make("codex"),
  capabilities: new Set(["preview"] as const),
  issuedAt: 1,
};

const client = McpSchema.McpServerClient.of({
  clientId: 1,
  clientCapabilities: {},
  clientInfo: { name: "mcp-test", version: "1.0.0" },
  protocolVersion: "2025-06-18",
  initializePayload: {
    protocolVersion: "2025-06-18",
    capabilities: {},
    clientInfo: { name: "mcp-test", version: "1.0.0" },
  },
  getClient: Effect.die("unused"),
});

// Post-fix layer: the preview toolkit over the MCP server, the fake broker, and
// the server-config test layer (scoped temp base dir). All four provides exist
// pre-fix, so this layer also stands up the unfixed server for pass-to-pass.
const TestLayer = McpHttpServer.PreviewToolkitRegistrationLive.pipe(
  Layer.provideMerge(McpServer.McpServer.layer),
  Layer.provideMerge(PreviewAutomationBroker.layer),
  Layer.provideMerge(ServerConfig.layerTest(process.cwd(), { prefix: "t3-mcp-http-server-test-" })),
  Layer.provideMerge(NodeServices.layer),
);

const snapshotResult = {
  url: "http://example.test/",
  title: "Example",
  loading: false,
  visibleText: "Example",
  interactiveElements: [],
  accessibilityTree: {},
  consoleEntries: [],
  networkEntries: [],
  actionTimeline: [],
  screenshot: {
    mimeType: "image/png",
    data: Buffer.from("png").toString("base64"),
    width: 10,
    height: 5,
  },
};

/** Answers every broker request on a fresh host with `result`, collecting the
 * forwarded request inputs so the caller can assert what the browser received. */
const serveResult = (clientId: string, result: unknown) =>
  Effect.gen(function* () {
    const broker = yield* PreviewAutomationBroker.PreviewAutomationBroker;
    const connected = yield* Deferred.make<void>();
    const inputs: Array<unknown> = [];
    const events = yield* broker.connect({ clientId, environmentId });
    yield* Stream.runForEach(events, (event) => {
      if (event.type === "connected") return Deferred.succeed(connected, undefined);
      inputs.push(event.request.input);
      return broker.respond({
        clientId,
        connectionId: event.connectionId,
        requestId: event.request.requestId,
        ok: true,
        result,
      });
    }).pipe(Effect.forkScoped);
    yield* Deferred.await(connected);
    return inputs;
  });

const callTool = (name: string, args: Record<string, unknown>) =>
  Effect.gen(function* () {
    const server = yield* McpServer.McpServer;
    return yield* server
      .callTool({ name, arguments: args })
      .pipe(
        Effect.provideService(McpInvocationContext.McpInvocationContext, invocation),
        Effect.provideService(McpSchema.McpServerClient, client),
      );
  });

const callSnapshot = (args: Record<string, unknown>) => callTool("preview_snapshot", args);

const textBlocks = (content: ReadonlyArray<{ readonly type: string; readonly text?: string }>) =>
  content.filter((block) => block.type === "text");

// Depth-agnostic saved-path discovery: collect every string value at any depth
// that points under the server-owned base directory. The fix is free to surface
// the path as a top-level field or nested under the screenshot metadata (both
// shapes round-trip), so the location is discovered by value, never pinned to a
// particular key or nesting depth.
const collectStringsUnder = (value: unknown, prefix: string): ReadonlyArray<string> => {
  if (typeof value === "string") return value.startsWith(prefix) ? [value] : [];
  if (Array.isArray(value)) return value.flatMap((entry) => collectStringsUnder(entry, prefix));
  if (value !== null && typeof value === "object") {
    return Object.values(value as Record<string, unknown>).flatMap((entry) =>
      collectStringsUnder(entry, prefix),
    );
  }
  return [];
};

// Oversized snapshot modeled on the real failure: several interactive elements
// each carrying the whole on-page text as their name, a big accessibility tree,
// a long visible text, and a stack of console entries.
const pageText = "/Users/dev/Code/project\nassistant · 79 threads\n".repeat(600);
const oversizedElement = (name: string, index: number) => ({
  tag: "div",
  role: "presentation",
  name,
  selector: `div:nth-of-type(${index})`,
  x: 0,
  y: 0,
  width: 10,
  height: 10,
});
const oversizedSnapshot = {
  ...snapshotResult,
  visibleText: pageText,
  interactiveElements: [
    oversizedElement(pageText, 1),
    oversizedElement(pageText, 2),
    oversizedElement(pageText, 3),
    oversizedElement("Continue", 4),
  ],
  accessibilityTree: { nodes: Array.from({ length: 2_000 }, (_, i) => ({ nodeId: `${i}` })) },
  consoleEntries: Array.from({ length: 100 }, (_, i) => ({
    level: "log",
    text: `entry ${i}`,
    timestamp: "t",
  })),
};

// ---------------------------------------------------------------------------
// Oversized snapshot -> bounded agent-visible text while structuredContent stays
// complete.
// ---------------------------------------------------------------------------
it.effect(
  "bounds the agent-visible snapshot text under the client output ceiling while keeping structuredContent complete",
  () =>
    Effect.scoped(
      Effect.gen(function* () {
        yield* serveResult("mcp-bounded-client", oversizedSnapshot);
        const snapshot = yield* callSnapshot({ includeImage: false });

        expect(snapshot.isError).toBe(false);
        const [text] = textBlocks(snapshot.content);
        const body = text?.text ?? "";
        expect(Buffer.byteLength(body, "utf8")).toBeLessThanOrEqual(AGENT_OUTPUT_CEILING_BYTES);

        // The machine-readable channel stays whole: the full accessibility tree
        // and the untrimmed visible text survive on structuredContent.
        expect(snapshot.structuredContent).toMatchObject({
          accessibilityTree: oversizedSnapshot.accessibilityTree,
          visibleText: oversizedSnapshot.visibleText,
        });
      }),
    ).pipe(Effect.provide(TestLayer)),
);

// ---------------------------------------------------------------------------
// Bounded text drops the accessibility tree, caps text and names, keeps the
// newest log entries, and a notice names what was trimmed.
// ---------------------------------------------------------------------------
it.effect(
  "drops the accessibility tree, caps text and names, and keeps the newest log entries in the bounded text",
  () =>
    Effect.scoped(
      Effect.gen(function* () {
        yield* serveResult("mcp-bounded-fields-client", oversizedSnapshot);
        const snapshot = yield* callSnapshot({ includeImage: false });

        expect(snapshot.isError).toBe(false);
        const [text, notice] = snapshot.content;
        const parsed = decodeJsonText(text?.type === "text" ? text.text : "") as {
          readonly accessibilityTree?: unknown;
          readonly visibleText: string;
          readonly interactiveElements: ReadonlyArray<{ readonly name: string }>;
          readonly consoleEntries: ReadonlyArray<{ readonly text: string }>;
        };

        // Accessibility tree dropped from the bounded text: the big tree is gone,
        // so the serialized tree is either absent entirely (reference omits the
        // key) or collapsed to a tiny marker (e.g. null, { truncated: true }, or
        // an omitted-flag notice). Either way it no longer carries the 2k-node
        // payload — assert the serialized tree is absent or far smaller than any
        // real tree would be.
        const serializedTree =
          parsed.accessibilityTree === undefined
            ? ""
            : JSON.stringify(parsed.accessibilityTree);
        expect(serializedTree.length).toBeLessThan(200);
        expect(parsed.visibleText.length).toBeLessThan(oversizedSnapshot.visibleText.length / 2);
        expect(parsed.interactiveElements).toHaveLength(4);
        expect(parsed.interactiveElements[0]?.name.length).toBeLessThan(
          oversizedSnapshot.interactiveElements[0].name.length / 2,
        );
        expect(parsed.interactiveElements[3]?.name).toBe("Continue");

        // Newest console entries kept, oldest shed — the contract behavior, not
        // a specific window size: the list shrinks, the newest entry survives,
        // and the oldest is gone. (Reference keeps 40; any newest-N slice passes.)
        const keptTexts = parsed.consoleEntries.map((entry) => entry.text);
        expect(parsed.consoleEntries.length).toBeLessThanOrEqual(80);
        expect(parsed.consoleEntries.length).toBeLessThan(oversizedSnapshot.consoleEntries.length);
        expect(keptTexts[keptTexts.length - 1]).toBe("entry 99");
        expect(keptTexts).not.toContain("entry 0");

        // The notice tells the agent what was dropped and that console entries
        // were shed, with a count.
        const noticeText = notice?.type === "text" ? notice.text : "";
        expect(noticeText).toContain("accessibilityTree");
        expect(noticeText).toMatch(/console/i);
        expect(noticeText).toMatch(/\d+/);
      }),
    ).pipe(Effect.provide(TestLayer)),
);

// ---------------------------------------------------------------------------
// When whole lists must be shed to fit, the log/timeline lists go before the
// interactive-element locators.
// ---------------------------------------------------------------------------
it.effect("sheds log lists before interactive-element locators when every list is oversized", () =>
  Effect.scoped(
    Effect.gen(function* () {
      const long = "x".repeat(2_000);
      const fullLists = {
        ...snapshotResult,
        interactiveElements: Array.from({ length: 20 }, (_, i) => ({
          tag: "button",
          role: "button",
          name: `Button ${i}`,
          selector: `#button-${i}`,
          x: 0,
          y: 0,
          width: 10,
          height: 10,
        })),
        consoleEntries: Array.from({ length: 200 }, () => ({
          level: long,
          text: long,
          timestamp: long,
          source: long,
        })),
        networkEntries: Array.from({ length: 200 }, () => ({
          url: long,
          method: long,
          status: 200,
          failed: false,
          errorText: long,
          timestamp: long,
        })),
        actionTimeline: Array.from({ length: 200 }, () => ({
          id: long,
          action: long,
          status: "succeeded",
          startedAt: long,
          completedAt: long,
          error: long,
        })),
      };
      yield* serveResult("mcp-full-lists-client", fullLists);
      const snapshot = yield* callSnapshot({ includeImage: false });

      const [text, notice] = snapshot.content;
      const body = text?.type === "text" ? text.text : "";
      expect(Buffer.byteLength(body, "utf8")).toBeLessThanOrEqual(AGENT_OUTPUT_CEILING_BYTES);
      const parsed = decodeJsonText(body) as {
        readonly interactiveElements: ReadonlyArray<unknown>;
        readonly consoleEntries: ReadonlyArray<unknown>;
        readonly networkEntries: ReadonlyArray<unknown>;
        readonly actionTimeline: ReadonlyArray<unknown>;
      };

      // Locators survive untouched; the log/timeline lists take the cut. The
      // oversized log strings force shedding past the newest-N window, so the
      // combined log count drops below even three full windows (reference 3×40).
      expect(parsed.interactiveElements).toHaveLength(20);
      const combinedLogs =
        parsed.consoleEntries.length + parsed.networkEntries.length + parsed.actionTimeline.length;
      expect(combinedLogs).toBeLessThan(120);

      // The notice reports shedding a log/timeline list, and never reports
      // shedding the interactive-element locators.
      const noticeText = notice?.type === "text" ? notice.text : "";
      expect(noticeText).toMatch(/actionTimeline|networkEntries|consoleEntries/);
      expect(noticeText).not.toMatch(/\d+ of \d+ interactiveElements/);
    }),
  ).pipe(Effect.provide(TestLayer)),
);

// ---------------------------------------------------------------------------
// Evaluate results are wrapped in a JSON object so arrays/primitives round-trip;
// the declared output schema is an object.
// ---------------------------------------------------------------------------
it.effect("returns evaluate results wrapped in a JSON object so arrays round-trip", () =>
  Effect.scoped(
    Effect.gen(function* () {
      const arrayResult = ["Connect", "Continue"];
      yield* serveResult("mcp-evaluate-client", arrayResult);
      const server = yield* McpServer.McpServer;

      const evaluated = yield* callTool("preview_evaluate", { expression: "buttons()" });
      expect(evaluated.isError).toBe(false);

      // structuredContent is a single-key JSON object wrapping the array; the
      // wrapper key is discovered, not pinned.
      const sc = evaluated.structuredContent;
      expect(typeof sc === "object" && sc !== null && !Array.isArray(sc)).toBe(true);
      const keys = Object.keys(sc as Record<string, unknown>);
      expect(keys).toHaveLength(1);
      expect((sc as Record<string, unknown>)[keys[0]!]).toEqual(arrayResult);

      // The text block carries the same object (round-trips via JSON).
      const [content, ...rest] = evaluated.content;
      expect(rest).toHaveLength(0);
      expect(content?.type).toBe("text");
      expect(decodeJsonText(content?.type === "text" ? content.text : "")).toEqual(sc);

      // The tool declares an object output schema.
      const evaluateTool = server.tools.find(({ tool }) => tool.name === "preview_evaluate");
      expect(evaluateTool?.tool.outputSchema).toMatchObject({ type: "object" });
    }),
  ).pipe(Effect.provide(TestLayer)),
);

// ---------------------------------------------------------------------------
// The save option persists the PNG under a server-owned config location and
// returns its path; the save flag never reaches the browser; a snapshot without
// the option returns no path.
// ---------------------------------------------------------------------------
it.effect(
  "persists the screenshot under the server state directory and returns its path without forwarding the save flag",
  () =>
    Effect.scoped(
      Effect.gen(function* () {
        const config = yield* ServerConfig.ServerConfig;
        const fileSystem = yield* FileSystem.FileSystem;
        const inputs = yield* serveResult("mcp-save-client", snapshotResult);

        const snapshot = yield* callSnapshot({ save: true });
        expect(snapshot.isError).toBe(false);

        // The server-only save flag is stripped before the request is forwarded.
        expect(inputs).toHaveLength(1);
        expect(inputs[0]).not.toHaveProperty("save");

        // Discover the saved-path field by value: the one string anywhere on
        // structuredContent that points under the server-owned base directory
        // (stateDir and any other config-derived location both live under it),
        // found at any nesting depth so a top-level path field or a path nested
        // under the screenshot metadata both round-trip.
        const structured = snapshot.structuredContent as Record<string, unknown>;
        const savedPaths = collectStringsUnder(structured, config.baseDir);
        expect(savedPaths).toHaveLength(1);
        const screenshotPath = savedPaths[0]!;

        // The file exists at that path and decodes to the PNG bytes.
        expect(Buffer.from(yield* fileSystem.readFile(screenshotPath)).toString()).toBe("png");

        // The agent-visible text mentions the path.
        const text = textBlocks(snapshot.content).find((block) =>
          (block.text ?? "").includes(screenshotPath),
        );
        expect(text).toBeDefined();

        // Without the save option, no path is returned anywhere in the envelope.
        const unsaved = yield* callSnapshot({});
        const unsavedStructured = unsaved.structuredContent as Record<string, unknown>;
        const unsavedPaths = collectStringsUnder(unsavedStructured, config.baseDir);
        expect(unsavedPaths).toHaveLength(0);
      }),
    ).pipe(Effect.provide(TestLayer)),
);

// ---------------------------------------------------------------------------
// A failed save surfaces as a typed, tagged error.
// ---------------------------------------------------------------------------
it.effect("surfaces a tagged error when the screenshot cannot be saved", () =>
  Effect.scoped(
    Effect.gen(function* () {
      const config = yield* ServerConfig.ServerConfig;
      const fileSystem = yield* FileSystem.FileSystem;

      // Replace the server-owned base directory with a regular file so any
      // attempt to create the artifacts location or write the screenshot under a
      // config-derived path fails, regardless of where the fix roots it.
      yield* fileSystem.remove(config.baseDir, { recursive: true });
      yield* fileSystem.writeFileString(config.baseDir, "");

      yield* serveResult("mcp-save-failure-client", snapshotResult);
      const snapshot = yield* callSnapshot({ save: true });

      expect(snapshot.isError).toBe(true);

      // The structured error keeps the pre-existing failure envelope shape and
      // carries a distinct, screenshot/save-specific tag (not a leaked generic
      // automation error). The tag is discovered, not pinned.
      const error = (snapshot.structuredContent as { readonly error?: Record<string, unknown> })
        ?.error;
      expect(error).toBeDefined();
      expect(error).toMatchObject({ operation: "snapshot", failureCount: 1 });
      const tag = error?._tag;
      expect(typeof tag).toBe("string");
      expect(tag).not.toBe("PreviewAutomationExecutionError");
      expect(tag).not.toBe("AiError");
      expect(tag as string).toMatch(/screenshot|save/i);

      // The failure text names that tag.
      const text = textBlocks(snapshot.content)
        .map((block) => block.text ?? "")
        .join("\n");
      expect(text).toContain(tag as string);
    }),
  ).pipe(Effect.provide(TestLayer)),
);

// ---------------------------------------------------------------------------
// An ordinary snapshot still returns its normal content (text + image) with
// complete structured metadata and no saved path. This holds on the server both
// before and after the fix.
// ---------------------------------------------------------------------------
it.effect("returns an ordinary snapshot unchanged", () =>
  Effect.scoped(
    Effect.gen(function* () {
      const config = yield* ServerConfig.ServerConfig;
      yield* serveResult("mcp-normal-client", snapshotResult);

      const snapshot = yield* callSnapshot({});
      expect(snapshot.isError).toBe(false);

      // Complete structured metadata, no saved path field. The server routes the
      // raw screenshot bytes into the image content block, so the structured
      // channel carries the screenshot's metadata (mimeType/width/height) without
      // the base64 payload — a stable property of the server on both sides of the
      // fix. Everything else round-trips untouched.
      const { screenshot: expectedShot, ...expectedRest } = snapshotResult;
      const { data: _rawBytes, ...expectedShotMeta } = expectedShot;
      expect(snapshot.structuredContent).toEqual({
        ...expectedRest,
        screenshot: expectedShotMeta,
      });
      const structured = snapshot.structuredContent as Record<string, unknown>;
      const paths = Object.values(structured).filter(
        (value) => typeof value === "string" && value.startsWith(config.baseDir),
      );
      expect(paths).toHaveLength(0);

      // A text rendering and the requested image are both present.
      expect(snapshot.content.some((block) => block.type === "text")).toBe(true);
      expect(snapshot.content.some((block) => block.type === "image")).toBe(true);
    }),
  ).pipe(Effect.provide(TestLayer)),
);
