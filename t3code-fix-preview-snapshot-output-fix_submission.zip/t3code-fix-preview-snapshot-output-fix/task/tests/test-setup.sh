#!/usr/bin/env bash
# test-setup.sh — environment bootstrap for the verifier.
#
# The server package's tests import TypeScript source directly through vite
# (apps/server has vite.config.ts; imports resolve `.ts` files, not a built
# dist/), so the submitted source edit is visible without any rebuild step.
# There is deliberately NO workspace build here: the monorepo also holds the
# Electron desktop and mobile packages, which are not installed in this image,
# so a full `pnpm build` would fail on them. The server dependency closure was
# baked offline at the base commit (filtered `pnpm install --frozen-lockfile
# --filter t3... --ignore-scripts`), so the guarded install below is a no-op on
# a healthy image.
#
# The grading infrastructure (js.py, which reads verify.toml) runs under the
# canonical /opt/tooling verifier interpreter (Python 3.12), which has tomllib
# in the standard library — no tomli shim is needed here.
#
# Sourced (not exec'd) by the harbor runner so env vars set here stay live for
# the verifier subprocess.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/t3code}"
export REPO_DIR
cd "$REPO_DIR"

# Sanity check: the server workspace node_modules must be present. A missing
# node_modules points at a corrupt image layer; restore the filtered closure
# (frozen lockfile, offline-first, no postinstall scripts) rather than fail with
# a confusing "vitest: command not found" later. Filtered to the `t3` server
# package and its workspace dependencies so the desktop/mobile packages stay
# untouched.
if ! [ -d node_modules ] || ! [ -d apps/server/node_modules ]; then
    echo "test-setup.sh: server node_modules missing — restoring filtered closure." >&2
    pnpm install --frozen-lockfile --prefer-offline --filter t3... --ignore-scripts
fi

# The server package drives its test suite through the vite-plus CLI (the `vp`
# bin), and the test runner that actually executes the suite is pulled in as a
# transitive dependency installed under a content-hashed pnpm store path with no
# top-level bin link. The shared grading runner launches the suite by the plain
# runner name on PATH, so without a stable link that launch resolves to nothing.
# Install a tiny forwarding shim at the stable bin location that locates the real
# CLI entry in the pnpm store at call time (hash-independent) and execs it, so
# the launch resolves regardless of the exact pinned build string. Idempotent.
RUNNER_BIN="node_modules/.bin/vitest"
if [ ! -x "$RUNNER_BIN" ]; then
    mkdir -p node_modules/.bin
    cat > "$RUNNER_BIN" <<'SHIM'
#!/bin/sh
# Forward to the test runner CLI resolved from the pnpm store at call time.
CLI=$(ls -d "$(pwd)"/node_modules/.pnpm/vitest@*/node_modules/vitest/vitest.mjs 2>/dev/null | head -1)
if [ -z "$CLI" ]; then
    CLI=$(ls -d "${REPO_DIR:-/repo/t3code}"/node_modules/.pnpm/vitest@*/node_modules/vitest/vitest.mjs 2>/dev/null | head -1)
fi
if [ -z "$CLI" ]; then
    echo "vitest shim: could not locate the runner CLI in the pnpm store" >&2
    exit 127
fi
exec node "$CLI" "$@"
SHIM
    chmod +x "$RUNNER_BIN"
    echo "test-setup.sh: installed runner shim at $RUNNER_BIN" >&2
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR node=$(node --version 2>/dev/null || echo unknown)"
