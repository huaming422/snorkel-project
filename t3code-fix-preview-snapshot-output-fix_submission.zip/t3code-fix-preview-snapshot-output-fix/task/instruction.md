## Task

hey, the assistant's preview browser has basically stopped being useful. this came out of a real session where it was trying to verify a UI change in the preview and couldn't show the result. when it takes a snapshot of a page, the result keeps coming back as just a truncation notice with nothing in it, so it loses all the page locators and can't point at anything. happens every time on pages with a lot of content on screen.

couple more things from the same session: when it evaluates an expression against the page and the expression returns a list or a plain value instead of an object, the call gets rejected as a malformed result. and there's no way for it to hang onto a screenshot it just took, the image only exists in that one result and shows up as unavailable afterward. it used to be able to do all of this. dig into the preview tooling and get all three sorted.
