// Behavioral check for the write-handler initialization path on the file
// inode. Exercises the pre-existing exported method
// FileInode.InitBufferedWriteHandlerIfEligible through the repo's own mock and fake
// buckets, asserting observable results rather than any internal identifier or
// guard syntax.
//
// Contract under test (observable at this interface):
//   - A zonal bucket opened for append must start the handler at the mount's
//     own object size, and repeated append/close/reopen rounds must succeed.
//   - A regional bucket (append) OR an overwrite open on a zonal bucket must
//     STILL issue that metadata read, so ordinary writes are unaffected.
//   - Existing objects outside rapid append keep their current open behavior.
//
// The suite here is independent of the package's other suites; it rebuilds its
// own non-local inode through the exported constructor and in-package helpers
// so it never depends on another suite's run order.

package inode

import (
	"context"
	"fmt"
	"math"
	"testing"
	"time"

	"github.com/googlecloudplatform/gcsfuse/v3/cfg"
	"github.com/googlecloudplatform/gcsfuse/v3/internal/contentcache"
	"github.com/googlecloudplatform/gcsfuse/v3/internal/fs/gcsfuse_errors"
	"github.com/googlecloudplatform/gcsfuse/v3/internal/gcsx"
	"github.com/googlecloudplatform/gcsfuse/v3/internal/storage/fake"
	"github.com/googlecloudplatform/gcsfuse/v3/internal/storage/gcs"
	storagemock "github.com/googlecloudplatform/gcsfuse/v3/internal/storage/mock"
	"github.com/googlecloudplatform/gcsfuse/v3/internal/storage/storageutil"
	"github.com/googlecloudplatform/gcsfuse/v3/internal/util"
	"github.com/jacobsa/fuse/fuseops"
	"github.com/jacobsa/timeutil"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	"github.com/stretchr/testify/suite"
	"golang.org/x/sync/semaphore"
)

type VrfRapidAppendInodeTest struct {
	suite.Suite
	ctx    context.Context
	bucket *storagemock.TestifyMockBucket
	clock  timeutil.SimulatedClock
	in     *FileInode
}

// TestVrfRapidAppendInodeSuite is the single top-level entry point the Go
// runner discovers to build its -run filter.
func TestVrfRapidAppendInodeSuite(t *testing.T) {
	suite.Run(t, new(VrfRapidAppendInodeTest))
}

func (t *VrfRapidAppendInodeTest) SetupTest() {
	t.ctx = context.Background()
	t.clock.SetTime(time.Date(2012, 8, 15, 22, 56, 0, 0, time.Local))
}

func (t *VrfRapidAppendInodeTest) TearDownTest() {
	if t.in != nil {
		t.in.Unlock()
	}
}

// buildNonLocalRapidAppendInode creates and locks a non-local (GCS-backed)
// inode over the current mock bucket, configured for rapid appends and with
// the temp-file content cleared so the handler-init path is reachable.
func (t *VrfRapidAppendInodeTest) buildNonLocalRapidAppendInode() {
	name := NewFileName(NewRootName(""), fileName)
	syncerBucket := gcsx.NewSyncerBucket(
		1, // Append threshold
		ChunkTransferTimeoutSecs,
		".gcsfuse_tmp/",
		t.bucket)

	object, err := storageutil.CreateObject(t.ctx, t.bucket, fileName, []byte{})
	require.NoError(t.T(), err)
	backingObj := storageutil.ConvertObjToMinObject(object)

	t.in = NewFileInode(
		fileInodeID,
		name,
		backingObj,
		fuseops.InodeAttributes{Uid: uid, Gid: gid, Mode: fileMode},
		&syncerBucket,
		false, // localFileCache
		contentcache.New("", &t.clock),
		&t.clock,
		false, // localFile -> non-local, so the handler-init path runs
		&cfg.Config{},
		semaphore.NewWeighted(math.MaxInt64),
		nil)

	err = t.in.CreateEmptyTempFile(t.ctx)
	require.NoError(t.T(), err)
	t.in.Lock()

	// Clear the temp-file content so handler initialization is eligible, and
	// turn on rapid appends.
	t.in.content = nil
	t.in.config.Write = *getWriteConfigWithEnabledRapidAppends()
}

// Zonal + append: the handler starts at the mount's object size.
func (t *VrfRapidAppendInodeTest) TestZonalAppendInitKeepsMountSizeOverStaleServerSize() {
	cases := []struct {
		name         string
		local, stale uint64
		metaGen      int64
		mode         util.OpenMode
	}{
		{"read-write", 10, 4, 1, util.NewOpenMode(util.ReadWrite, util.O_APPEND)},
		{"write-only large", 5<<30 + 10, 5 << 30, 3, util.NewOpenMode(util.WriteOnly, util.O_APPEND)},
	}
	for _, tc := range cases {
		t.Run(tc.name, func() {
			t.bucket = new(storagemock.TestifyMockBucket)
			t.bucket.On("BucketType").Return(gcs.BucketType{Zonal: true})
			t.bucket.On("CreateObject", t.ctx, mock.AnythingOfType("*gcs.CreateObjectRequest")).
				Return(&gcs.Object{Name: fileName, Size: tc.local, Generation: 1, MetaGeneration: tc.metaGen}, nil)
			t.bucket.On("StatObject", t.ctx, mock.AnythingOfType("*gcs.StatObjectRequest")).
				Return(&gcs.MinObject{Name: fileName, Size: tc.stale, Generation: 1, MetaGeneration: tc.metaGen},
					&gcs.ExtendedObjectAttributes{}, nil).Maybe()
			t.buildNonLocalRapidAppendInode()
			defer func() { t.in.Unlock(); t.in = nil }()

			initialized, err := t.in.InitBufferedWriteHandlerIfEligible(t.ctx, tc.mode)

			require.NoError(t.T(), err)
			require.True(t.T(), initialized)
			assert.Equal(t.T(), int64(tc.local), t.in.bwh.WriteFileInfo().TotalSize)
		})
	}
}

// Zonal + overwrite: ordinary (non-append) opens must STILL read latest object
// metadata from the server.
func (t *VrfRapidAppendInodeTest) TestZonalOverwriteInitReadsLatestObject() {
	t.bucket = new(storagemock.TestifyMockBucket)
	t.bucket.On("BucketType").Return(gcs.BucketType{Zonal: true})
	t.bucket.On("CreateObject", t.ctx, mock.AnythingOfType("*gcs.CreateObjectRequest")).
		Return(&gcs.Object{Name: fileName, Size: 0, Generation: 1, MetaGeneration: 1}, nil)
	t.bucket.On("StatObject", t.ctx, mock.AnythingOfType("*gcs.StatObjectRequest")).
		Return(&gcs.MinObject{Name: fileName, Size: 0, Generation: 1, MetaGeneration: 1},
			&gcs.ExtendedObjectAttributes{}, nil)

	t.buildNonLocalRapidAppendInode()

	initialized, err := t.in.InitBufferedWriteHandlerIfEligible(
		t.ctx, util.NewOpenMode(util.WriteOnly, 0))

	require.NoError(t.T(), err)
	assert.True(t.T(), initialized)
	// The server metadata read is required here.
	t.bucket.AssertCalled(t.T(), "StatObject", mock.Anything, mock.Anything)
}

// Regional + append: regional buckets must STILL read latest object metadata,
// regardless of the append mode.
func (t *VrfRapidAppendInodeTest) TestRegionalAppendInitReadsLatestObject() {
	t.bucket = new(storagemock.TestifyMockBucket)
	t.bucket.On("BucketType").Return(gcs.BucketType{Zonal: false})
	t.bucket.On("CreateObject", t.ctx, mock.AnythingOfType("*gcs.CreateObjectRequest")).
		Return(&gcs.Object{Name: fileName, Size: 0, Generation: 1, MetaGeneration: 1}, nil)
	t.bucket.On("StatObject", t.ctx, mock.AnythingOfType("*gcs.StatObjectRequest")).
		Return(&gcs.MinObject{Name: fileName, Size: 0, Generation: 1, MetaGeneration: 1},
			&gcs.ExtendedObjectAttributes{}, nil)

	t.buildNonLocalRapidAppendInode()

	initialized, err := t.in.InitBufferedWriteHandlerIfEligible(
		t.ctx, util.NewOpenMode(util.ReadWrite, util.O_APPEND))

	require.NoError(t.T(), err)
	assert.True(t.T(), initialized)
	// The server metadata read is required here.
	t.bucket.AssertCalled(t.T(), "StatObject", mock.Anything, mock.Anything)
}

// staleStatBucket: StatObject reports at most staleSize; append writers must start at the real size.
type staleStatBucket struct {
	gcs.Bucket
	staleSize uint64
}

func (b *staleStatBucket) StatObject(ctx context.Context, req *gcs.StatObjectRequest) (*gcs.MinObject, *gcs.ExtendedObjectAttributes, error) {
	m, ext, err := b.Bucket.StatObject(ctx, req)
	if err == nil && m.Size > b.staleSize {
		m.Size = b.staleSize
	}
	return m, ext, err
}

func (b *staleStatBucket) CreateAppendableObjectWriter(ctx context.Context, req *gcs.CreateObjectChunkWriterRequest) (gcs.Writer, error) {
	m, _, err := b.Bucket.StatObject(ctx, &gcs.StatObjectRequest{Name: req.Name})
	if err != nil {
		return nil, err
	}
	if uint64(req.Offset) != m.Size {
		return nil, fmt.Errorf("takeover offset %d does not match object size %d", req.Offset, m.Size)
	}
	return b.Bucket.CreateAppendableObjectWriter(ctx, req)
}

// Zonal: open for append, write, close, five times on one inode.
func (t *VrfRapidAppendInodeTest) TestZonalAppendReopenLoop() {
	inner := fake.NewFakeBucket(&t.clock, "some_bucket", gcs.BucketType{Zonal: true})
	initial := "lychee"
	object, err := storageutil.CreateObject(t.ctx, inner, fileName, []byte(initial))
	require.NoError(t.T(), err)
	object.Finalized = time.Time{}
	bkt := &staleStatBucket{Bucket: inner, staleSize: uint64(len(initial))}
	syncerBucket := gcsx.NewSyncerBucket(1, ChunkTransferTimeoutSecs, ".gcsfuse_tmp/", bkt)
	t.in = NewFileInode(
		fileInodeID,
		NewFileName(NewRootName(""), fileName),
		storageutil.ConvertObjToMinObject(object),
		fuseops.InodeAttributes{Uid: uid, Gid: gid, Mode: fileMode},
		&syncerBucket,
		false,
		contentcache.New("", &t.clock),
		&t.clock,
		false,
		&cfg.Config{Write: *getWriteConfigWithEnabledRapidAppends()},
		semaphore.NewWeighted(math.MaxInt64),
		nil)
	t.in.Lock()

	want := initial
	for i := 0; i < 5; i++ {
		t.in.RegisterFileHandle(false)
		initialized, err := t.in.InitBufferedWriteHandlerIfEligible(t.ctx, AppendMode)
		require.NoError(t.T(), err, "round %d", i+1)
		require.True(t.T(), initialized, "round %d", i+1)
		_, err = t.in.Write(t.ctx, []byte("juice"), int64(len(want)), AppendMode)
		require.NoError(t.T(), err, "round %d", i+1)
		require.NoError(t.T(), t.in.Flush(t.ctx), "round %d", i+1)
		t.in.DeRegisterFileHandle(false)
		want += "juice"
	}

	contents, err := storageutil.ReadObject(t.ctx, inner, fileName)
	require.NoError(t.T(), err)
	assert.Equal(t.T(), want, string(contents))
}

// Regional append and zonal overwrite: a newer server generation is reported.
func (t *VrfRapidAppendInodeTest) TestInitReportsNewerServerGeneration() {
	cases := []struct {
		name  string
		zonal bool
		mode  util.OpenMode
	}{
		{"regional append", false, util.NewOpenMode(util.ReadWrite, util.O_APPEND)},
		{"zonal overwrite", true, util.NewOpenMode(util.WriteOnly, 0)},
	}
	for _, tc := range cases {
		t.Run(tc.name, func() {
			t.bucket = new(storagemock.TestifyMockBucket)
			t.bucket.On("BucketType").Return(gcs.BucketType{Zonal: tc.zonal})
			t.bucket.On("CreateObject", t.ctx, mock.AnythingOfType("*gcs.CreateObjectRequest")).
				Return(&gcs.Object{Name: fileName, Size: 4, Generation: 1, MetaGeneration: 1}, nil)
			t.bucket.On("StatObject", t.ctx, mock.AnythingOfType("*gcs.StatObjectRequest")).
				Return(&gcs.MinObject{Name: fileName, Size: 9, Generation: 2, MetaGeneration: 1},
					&gcs.ExtendedObjectAttributes{}, nil)
			t.buildNonLocalRapidAppendInode()
			defer func() { t.in.Unlock(); t.in = nil }()

			_, err := t.in.InitBufferedWriteHandlerIfEligible(t.ctx, tc.mode)

			var clobbered *gcsfuse_errors.FileClobberedError
			assert.ErrorAs(t.T(), err, &clobbered)
		})
	}
}

// Existing non-empty objects outside rapid append open without error and use staged writes.
func (t *VrfRapidAppendInodeTest) TestInitOnExistingObjects() {
	cases := []struct {
		name      string
		zonal     bool
		finalized bool
		mode      util.OpenMode
	}{
		{"regional append", false, false, util.NewOpenMode(util.ReadWrite, util.O_APPEND)},
		{"zonal overwrite", true, false, util.NewOpenMode(util.WriteOnly, 0)},
		{"zonal append to finalized object", true, true, util.NewOpenMode(util.WriteOnly, util.O_APPEND)},
	}
	for _, tc := range cases {
		t.Run(tc.name, func() {
			var finalized time.Time
			if tc.finalized {
				finalized = time.Date(2012, 8, 15, 22, 56, 0, 0, time.UTC)
			}
			t.bucket = new(storagemock.TestifyMockBucket)
			t.bucket.On("BucketType").Return(gcs.BucketType{Zonal: tc.zonal})
			t.bucket.On("CreateObject", t.ctx, mock.AnythingOfType("*gcs.CreateObjectRequest")).
				Return(&gcs.Object{Name: fileName, Size: 4, Generation: 1, MetaGeneration: 1, Finalized: finalized}, nil)
			t.bucket.On("StatObject", t.ctx, mock.AnythingOfType("*gcs.StatObjectRequest")).
				Return(&gcs.MinObject{Name: fileName, Size: 4, Generation: 1, MetaGeneration: 1, Finalized: finalized},
					&gcs.ExtendedObjectAttributes{}, nil).Maybe()
			t.buildNonLocalRapidAppendInode()
			defer func() { t.in.Unlock(); t.in = nil }()

			initialized, err := t.in.InitBufferedWriteHandlerIfEligible(t.ctx, tc.mode)

			require.NoError(t.T(), err)
			assert.False(t.T(), initialized)
		})
	}
}
