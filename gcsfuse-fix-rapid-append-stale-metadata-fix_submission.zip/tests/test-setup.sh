#!/usr/bin/env bash
# test-setup.sh — sourced before the verifier runs.
#
# Go task: the dependency closure (module cache + build cache) was baked at
# the base commit during the image build, so nothing needs to be fetched here.
# The verifier compiles and runs the focused unit tests itself with `go test`.
set -euo pipefail

cd /repo/gcsfuse

# Force the Go toolchain offline so a stray cache miss fails fast instead of
# hanging against the (absent) network during the no-network agent phase and
# the allowlist verifier phase. GOFLAGS=-mod=mod matches the image ENV.
export GOFLAGS=-mod=mod
export GOPROXY=off
export GOTOOLCHAIN=local

# Sanity check: the two packages the verifier exercises must compile against
# the warm cache with no network. A failure here surfaces a missing prebake
# rather than letting the verifier report a confusing test error.
go build ./internal/fs/inode/... ./internal/storage/... >/tmp/test-setup-build.log 2>&1 \
    || { echo "test-setup: offline build probe failed" >&2; tail -40 /tmp/test-setup-build.log >&2; exit 1; }

echo "test-setup: ready."
