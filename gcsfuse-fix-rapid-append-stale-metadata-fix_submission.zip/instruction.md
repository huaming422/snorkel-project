## Task

I'm using gcsfuse with rapid appends enabled on a zonal bucket. From a single mount, I keep looping through the same steps on the same file: I open it for appending, write some data, close it, and then open it again. But the loop fails partway through, usually on the second or third round.

If I open the file, append to it once, and then close it, I don't run into the failure. It only happens when I keep reopening it in the loop. The only thing writing to that file is my mount, and I don't run into problems with regional buckets or ordinary overwrites.
