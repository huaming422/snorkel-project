## Task

rapid appends are broken on zonal buckets. turn rapid appends on, then loop open-in-append, write, close, reopen on the same file from a single mount, and it falls over partway through, usually after the second or third round. a one-shot open-append-close on its own is totally fine; it's only the repeated reopen cycle that errors out. and this mount is the only writer, nothing else is touching the file. since we're the sole writer, our own view of the file should always be good enough to keep appending, so this used to hold up and now it doesn't.

leave the ordinary paths alone: regular writes and overwrites (non-rapid, on regional buckets) need to behave exactly as they do today. this is isolated to the rapid-append-on-a-zonal-bucket flow.

one caution: don't paper over genuine conflicts. if a caller really is writing against a stale or concurrently-modified object, that still needs to surface the way it does now. the goal is to stop a lone writer's append loop from tripping over itself, not real conflict detection.

can you dig in and fix it?
