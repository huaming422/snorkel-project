// Behavioral check for the write-handler initialization path on the file
// inode. Exercises the pre-existing exported method
// FileInode.InitBufferedWriteHandlerIfEligible through the repo's own mock
// bucket, asserting the OBSERVABLE server-call pattern (whether a latest-object
// metadata read is issued) rather than any internal identifier or guard syntax.
//
// Contract under test (observable at this interface):
//   - A zonal bucket opened for append must initialize the handler WITHOUT
//     issuing a latest-object metadata read to the server (it reuses the
//     mount's cached object view).
//   - A regional bucket (append) OR an overwrite open on a zonal bucket must
//     STILL issue that metadata read, so ordinary writes are unaffected.
//
// The suite here is independent of the package's other suites; it rebuilds its
// own non-local inode through the exported constructor and in-package helpers
// so it never depends on another suite's run order.

package inode

import (
	"context"
	"math"
	"testing"
	"time"

	"github.com/googlecloudplatform/gcsfuse/v3/cfg"
	"github.com/googlecloudplatform/gcsfuse/v3/internal/contentcache"
	"github.com/googlecloudplatform/gcsfuse/v3/internal/gcsx"
	"github.com/googlecloudplatform/gcsfuse/v3/internal/storage/gcs"
	storagemock "github.com/googlecloudplatform/gcsfuse/v3/internal/storage/mock"
	"github.com/googlecloudplatform/gcsfuse/v3/internal/storage/storageutil"
	"github.com/googlecloudplatform/gcsfuse/v3/internal/util"
	"github.com/jacobsa/fuse/fuseops"
	"github.com/jacobsa/timeutil"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	"github.com/stretchr/testify/suite"
	"golang.org/x/sync/semaphore"
)

type VrfRapidAppendInodeTest struct {
	suite.Suite
	ctx    context.Context
	bucket *storagemock.TestifyMockBucket
	clock  timeutil.SimulatedClock
	in     *FileInode
}

// TestVrfRapidAppendInodeSuite is the single top-level entry point the Go
// runner discovers to build its -run filter.
func TestVrfRapidAppendInodeSuite(t *testing.T) {
	suite.Run(t, new(VrfRapidAppendInodeTest))
}

func (t *VrfRapidAppendInodeTest) SetupTest() {
	t.ctx = context.Background()
	t.clock.SetTime(time.Date(2012, 8, 15, 22, 56, 0, 0, time.Local))
}

func (t *VrfRapidAppendInodeTest) TearDownTest() {
	if t.in != nil {
		t.in.Unlock()
	}
}

// buildNonLocalRapidAppendInode creates and locks a non-local (GCS-backed)
// inode over the current mock bucket, configured for rapid appends and with
// the temp-file content cleared so the handler-init path is reachable.
func (t *VrfRapidAppendInodeTest) buildNonLocalRapidAppendInode() {
	name := NewFileName(NewRootName(""), fileName)
	syncerBucket := gcsx.NewSyncerBucket(
		1, // Append threshold
		ChunkTransferTimeoutSecs,
		".gcsfuse_tmp/",
		t.bucket)

	object, err := storageutil.CreateObject(t.ctx, t.bucket, fileName, []byte{})
	require.NoError(t.T(), err)
	backingObj := storageutil.ConvertObjToMinObject(object)

	t.in = NewFileInode(
		fileInodeID,
		name,
		backingObj,
		fuseops.InodeAttributes{Uid: uid, Gid: gid, Mode: fileMode},
		&syncerBucket,
		false, // localFileCache
		contentcache.New("", &t.clock),
		&t.clock,
		false, // localFile -> non-local, so the handler-init path runs
		&cfg.Config{},
		semaphore.NewWeighted(math.MaxInt64),
		nil)

	err = t.in.CreateEmptyTempFile(t.ctx)
	require.NoError(t.T(), err)
	t.in.Lock()

	// Clear the temp-file content so handler initialization is eligible, and
	// turn on rapid appends.
	t.in.content = nil
	t.in.config.Write = *getWriteConfigWithEnabledRapidAppends()
}

// Zonal + append: the handler must initialize WITHOUT a server metadata read.
func (t *VrfRapidAppendInodeTest) TestZonalAppendInitSkipsLatestObjectRead() {
	t.bucket = new(storagemock.TestifyMockBucket)
	t.bucket.On("BucketType").Return(gcs.BucketType{Zonal: true})
	t.bucket.On("CreateObject", t.ctx, mock.AnythingOfType("*gcs.CreateObjectRequest")).
		Return(&gcs.Object{Name: fileName, Size: 0, Generation: 1, MetaGeneration: 1}, nil)

	t.buildNonLocalRapidAppendInode()

	initialized, err := t.in.InitBufferedWriteHandlerIfEligible(
		t.ctx, util.NewOpenMode(util.ReadWrite, util.O_APPEND))

	require.NoError(t.T(), err)
	assert.True(t.T(), initialized)
	// The server metadata read must not happen on this path.
	t.bucket.AssertNotCalled(t.T(), "StatObject", mock.Anything, mock.Anything)
}

// Zonal + overwrite: ordinary (non-append) opens must STILL read latest object
// metadata from the server.
func (t *VrfRapidAppendInodeTest) TestZonalOverwriteInitReadsLatestObject() {
	t.bucket = new(storagemock.TestifyMockBucket)
	t.bucket.On("BucketType").Return(gcs.BucketType{Zonal: true})
	t.bucket.On("CreateObject", t.ctx, mock.AnythingOfType("*gcs.CreateObjectRequest")).
		Return(&gcs.Object{Name: fileName, Size: 0, Generation: 1, MetaGeneration: 1}, nil)
	t.bucket.On("StatObject", t.ctx, mock.AnythingOfType("*gcs.StatObjectRequest")).
		Return(&gcs.MinObject{Name: fileName, Size: 0, Generation: 1, MetaGeneration: 1},
			&gcs.ExtendedObjectAttributes{}, nil)

	t.buildNonLocalRapidAppendInode()

	initialized, err := t.in.InitBufferedWriteHandlerIfEligible(
		t.ctx, util.NewOpenMode(util.WriteOnly, 0))

	require.NoError(t.T(), err)
	assert.True(t.T(), initialized)
	// The server metadata read is required here.
	t.bucket.AssertCalled(t.T(), "StatObject", mock.Anything, mock.Anything)
}

// Regional + append: regional buckets must STILL read latest object metadata,
// regardless of the append mode.
func (t *VrfRapidAppendInodeTest) TestRegionalAppendInitReadsLatestObject() {
	t.bucket = new(storagemock.TestifyMockBucket)
	t.bucket.On("BucketType").Return(gcs.BucketType{Zonal: false})
	t.bucket.On("CreateObject", t.ctx, mock.AnythingOfType("*gcs.CreateObjectRequest")).
		Return(&gcs.Object{Name: fileName, Size: 0, Generation: 1, MetaGeneration: 1}, nil)
	t.bucket.On("StatObject", t.ctx, mock.AnythingOfType("*gcs.StatObjectRequest")).
		Return(&gcs.MinObject{Name: fileName, Size: 0, Generation: 1, MetaGeneration: 1},
			&gcs.ExtendedObjectAttributes{}, nil)

	t.buildNonLocalRapidAppendInode()

	initialized, err := t.in.InitBufferedWriteHandlerIfEligible(
		t.ctx, util.NewOpenMode(util.ReadWrite, util.O_APPEND))

	require.NoError(t.T(), err)
	assert.True(t.T(), initialized)
	// The server metadata read is required here.
	t.bucket.AssertCalled(t.T(), "StatObject", mock.Anything, mock.Anything)
}
