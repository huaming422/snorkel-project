// Behavioral check for the stat-cache wrapper's takeover-writer path.
// Exercises the pre-existing public gcs.Bucket method
// CreateAppendableObjectWriter as implemented by the fast-stat caching layer,
// built through the pre-existing exported constructor caching.NewFastStatBucket.
//
// Contract under test (observable at this interface):
//   - When the wrapped bucket's CreateAppendableObjectWriter fails with a
//     precondition error, the caching layer must EVICT the stat-cache record
//     for the object name (so a later attempt re-reads fresh metadata).
//   - The caching layer must still PROPAGATE that error to its caller; eviction
//     must not swallow it.
//
// The wrapped bucket and the stat cache are minimal stand-ins that embed the
// pre-existing repo interfaces and record only the calls this behavior depends
// on, so the test asserts observable effects, not any internal identifier.

package caching_test

import (
	"errors"
	"testing"
	"time"

	"github.com/googlecloudplatform/gcsfuse/v3/internal/cache/metadata"
	"github.com/googlecloudplatform/gcsfuse/v3/internal/storage/caching"
	"github.com/googlecloudplatform/gcsfuse/v3/internal/storage/gcs"
	"github.com/jacobsa/timeutil"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"golang.org/x/net/context"
)

const vrfPrimaryCacheTTL = time.Second
const vrfNegativeCacheTTL = 5 * time.Second
const vrfIsTypeCacheDeprecated = false

// vrfRecordingStatCache embeds the pre-existing StatCache interface and records
// the names passed to Erase. Any method other than Erase is left to the
// embedded (nil) interface; this behavior never calls one.
type vrfRecordingStatCache struct {
	metadata.StatCache
	erased []string
}

func (c *vrfRecordingStatCache) Erase(name string) {
	c.erased = append(c.erased, name)
}

// vrfStubBucket embeds the pre-existing gcs.Bucket interface and drives
// CreateAppendableObjectWriter to a caller-supplied (writer, error) result.
// Only that one method is used by this behavior.
type vrfStubBucket struct {
	gcs.Bucket
	retWriter gcs.Writer
	retErr    error
	calls     int
}

func (b *vrfStubBucket) CreateAppendableObjectWriter(
	_ context.Context, _ *gcs.CreateObjectChunkWriterRequest) (gcs.Writer, error) {
	b.calls++
	return b.retWriter, b.retErr
}

func vrfNewCachingBucketOverStub(cache metadata.StatCache, wrapped gcs.Bucket) gcs.Bucket {
	var clock timeutil.SimulatedClock
	clock.SetTime(time.Date(2015, 4, 5, 2, 15, 0, 0, time.Local))
	return caching.NewFastStatBucket(
		vrfPrimaryCacheTTL,
		cache,
		&clock,
		wrapped,
		vrfNegativeCacheTTL,
		vrfIsTypeCacheDeprecated)
}

func vrfAppendableRequest(name string) *gcs.CreateObjectChunkWriterRequest {
	return &gcs.CreateObjectChunkWriterRequest{
		CreateObjectRequest: gcs.CreateObjectRequest{Name: name},
	}
}

// Precondition error from the wrapped bucket -> the stale record for the object
// name is evicted AND the error is still propagated.
func TestVrfCachingEvictsAndPropagatesOnPreconditionError(t *testing.T) {
	const name = "taco"
	cache := &vrfRecordingStatCache{}
	wrapped := &vrfStubBucket{
		retWriter: nil,
		retErr:    &gcs.PreconditionError{Err: errors.New("precondition failed")},
	}
	bucket := vrfNewCachingBucketOverStub(cache, wrapped)

	_, err := bucket.CreateAppendableObjectWriter(context.TODO(), vrfAppendableRequest(name))

	// Eviction of the record for this object name.
	require.Equal(t, []string{name}, cache.erased,
		"expected the stat-cache record for %q to be evicted exactly once", name)
	// Error still reaches the caller (eviction does not swallow it).
	require.Error(t, err)
	assert.Contains(t, err.Error(), "precondition failed")
	var precondErr *gcs.PreconditionError
	assert.True(t, errors.As(err, &precondErr),
		"propagated error should still carry the precondition error")
}

// No precondition error -> no eviction. Guards against evicting on every call,
// which would defeat the cache for the ordinary (non-divergent) path.
func TestVrfCachingDoesNotEvictWithoutPreconditionError(t *testing.T) {
	const name = "burrito"
	cache := &vrfRecordingStatCache{}
	wrapped := &vrfStubBucket{retWriter: nil, retErr: nil}
	bucket := vrfNewCachingBucketOverStub(cache, wrapped)

	_, err := bucket.CreateAppendableObjectWriter(context.TODO(), vrfAppendableRequest(name))

	require.NoError(t, err)
	assert.Empty(t, cache.erased,
		"no stat-cache eviction should happen when the wrapped call succeeds")
	assert.Equal(t, 1, wrapped.calls)
}
