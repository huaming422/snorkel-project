// Behavioral verifier for datafusion-perf-skip-fully-matched.
//
// This is a STANDALONE external integration-test target: the rust runner copies
// it into datafusion/core/tests/ and compiles it against the PUBLIC `datafusion`
// crate API only. It therefore must not reference any crate-private symbol the
// reference solution touches (no `split_runs`, no run-splitting field, no new
// per-run struct, no decoder internals). Everything is observed through
// pre-existing, stable public interfaces:
//
//   * `datafusion::test_util::parquet::{TestParquetFile, ParquetScanOptions}`
//     — builds a physical scan and exposes its `MetricsSet`.
//   * `MetricsSet::sum_by_name(...)` + `MetricValue::{PruningMetrics, Count}`
//     — the summary metrics EXPLAIN ANALYZE renders. These metric NAMES are
//     pre-existing (`page_index_pages_pruned`, `pushdown_rows_matched`,
//     `row_groups_pruned_statistics`, `predicate_cache_inner_records`) and are
//     NOT coupled to the reference fix.  Any brand-new metric the fix may add
//     is deliberately never referenced.
//   * The public SQL path (`register_parquet` + `SessionContext::sql`) for the
//     LIMIT / reverse-order / multi-column correctness guards.
//
// SCORING: investigation/performance task — the native-verifier reward is
// all-or-nothing (run_verify all_pass = passed == total). A correct fix makes
// EVERY test below GREEN; an unfixed / pre-fix tree makes the two metric-drop
// f2p tests RED. The remaining five are correctness guards that pass on BOTH
// the fixed and the pre-fix build (pure-performance change) and exist to REJECT
// worse solutions that over-return rows, break ordering, panic on multi-column
// predicates, or rip out fully-matched detection.
//
// MIXED-RG fixture design for the two f2p tests:
//   The fixture has exactly TWO row groups:
//     RG0 = [1, 2, 3]  — filter `a >= 3` does NOT fully match; RowFilter runs
//     RG1 = [4, 5, 6]  — filter `a >= 3` FULLY matches; RowFilter/page-index
//                        should be skipped by a correct fix
//
//   This mixed structure means:
//   - A whole-file skip (row_filter=None only when ALL scanned RGs are fully
//     matched) does NOT fire here, because RG0 is not fully matched.
//     Such an approach behaves identically to the pre-fix case on this fixture.
//   - A per-RG skip (the correct behavior from base.md) fires for RG1 only.
//
//   Observable: `predicate_cache_inner_records`
//     Pre-fix: RowFilter evaluated over BOTH groups -> 6 rows cached (all rows
//              from both groups pass through the cache).
//     Per-RG skip (oracle / any correct per-RG implementation): RowFilter
//              evaluated for RG0 only -> 3 rows cached.
//     Whole-file skip: same as pre-fix -> 6 rows.
//
//   The CONTROL in each f2p test uses a file where NO group is fully matched,
//   confirming the pipeline is live on this build (cache > 0).
//
// See also: Self-baselining design (so the f2p tests can never vacuously pass
// on an unfixed build): each test asserts BOTH a CONTROL fixture (not fully
// matched, cache > 0) AND a SUBJECT fixture (has a fully-matched RG, cache
// drops to subject_count on a correct fix). On a pre-fix build the SUBJECT
// assertion FAILS because the FM group still runs through the cache.

use arrow::array::{ArrayRef, AsArray, Int32Array};
use arrow::datatypes::Int32Type;
use arrow::record_batch::RecordBatch;
use datafusion::physical_plan::collect;
use datafusion::physical_plan::metrics::{MetricValue, MetricsSet};
use datafusion::prelude::{
    col, lit, Expr, ParquetReadOptions, SessionContext,
};
use datafusion::test_util::parquet::{ParquetScanOptions, TestParquetFile};
use parquet::file::properties::{EnabledStatistics, WriterProperties};
use std::sync::Arc;
use tempfile::TempDir;

// ---------------------------------------------------------------------------
// Fixture helpers
// ---------------------------------------------------------------------------

/// Writer properties that force multiple small data pages (so page-index work
/// is measurable) and page-level statistics (so page pruning has something to
/// evaluate). `max_rg` controls row-group splitting within the single batch.
fn props(max_rg: usize) -> WriterProperties {
    WriterProperties::builder()
        .set_max_row_group_row_count(Some(max_rg))
        .set_statistics_enabled(EnabledStatistics::Page)
        .set_data_page_row_count_limit(2)
        .set_write_batch_size(2)
        .build()
}

/// Build a one-column (`a: Int32`) parquet file from `values`, splitting into
/// row groups of at most `max_rg` rows.
fn write_single_col(dir: &TempDir, name: &str, values: &[i32], max_rg: usize) -> TestParquetFile {
    let a: ArrayRef = Arc::new(Int32Array::from(values.to_vec()));
    let batch = RecordBatch::try_from_iter(vec![("a", a)]).unwrap();
    TestParquetFile::try_new(dir.path().join(name), props(max_rg), vec![batch]).unwrap()
}

/// Build a two-column (`a`, `b`: Int32) parquet file; `b[i] == a[i]`.
fn write_two_col(dir: &TempDir, name: &str, values: &[i32], max_rg: usize) -> TestParquetFile {
    let a: ArrayRef = Arc::new(Int32Array::from(values.to_vec()));
    let b: ArrayRef = Arc::new(Int32Array::from(values.to_vec()));
    let batch = RecordBatch::try_from_iter(vec![("a", a), ("b", b)]).unwrap();
    TestParquetFile::try_new(dir.path().join(name), props(max_rg), vec![batch]).unwrap()
}

fn scan_opts(pushdown: bool, page_index: bool) -> ParquetScanOptions {
    ParquetScanOptions {
        pushdown_filters: pushdown,
        reorder_filters: false,
        enable_page_index: page_index,
    }
}

/// Run a physical scan of `file` with `filter`, returning the collected rows and
/// the parquet node's metrics. Mirrors `tests/parquet/filter_pushdown.rs`.
async fn scan_with_metrics(
    file: &TestParquetFile,
    filter: &Expr,
    opts: ParquetScanOptions,
) -> (Vec<RecordBatch>, MetricsSet) {
    let ctx = SessionContext::new_with_config(opts.config());
    let exec = file.create_scan(&ctx, Some(filter.clone())).await.unwrap();
    let result = collect(exec.clone(), ctx.task_ctx()).await.unwrap();
    let metrics = TestParquetFile::parquet_metrics(&exec).expect("found parquet metrics");
    (result, metrics)
}

/// `fully_matched()` count for a `PruningMetrics` metric.
fn pruning_fully_matched(metrics: &MetricsSet, name: &str) -> usize {
    match metrics.sum_by_name(name) {
        Some(MetricValue::PruningMetrics { pruning_metrics, .. }) => pruning_metrics.fully_matched(),
        Some(other) => panic!("metric '{name}' is not a PruningMetrics: {other:?}"),
        None => panic!("metric '{name}' not found in\n\n{metrics:#?}"),
    }
}

/// `total()` count for a `PruningMetrics` metric (pruned + matched + fully_matched).
fn pruning_total(metrics: &MetricsSet, name: &str) -> usize {
    match metrics.sum_by_name(name) {
        Some(MetricValue::PruningMetrics { pruning_metrics, .. }) => {
            pruning_metrics.pruned() + pruning_metrics.matched() + pruning_metrics.fully_matched()
        }
        Some(other) => panic!("metric '{name}' is not a PruningMetrics: {other:?}"),
        None => panic!("metric '{name}' not found in\n\n{metrics:#?}"),
    }
}

/// `usize` value of a plain `Count` metric.
fn count_value(metrics: &MetricsSet, name: &str) -> usize {
    match metrics.sum_by_name(name) {
        Some(MetricValue::Count { count, .. }) => count.value(),
        Some(other) => panic!("metric '{name}' is not a Count: {other:?}"),
        None => panic!("metric '{name}' not found in\n\n{metrics:#?}"),
    }
}

/// `usize` value of a `Gauge` metric (pre-existing metrics like
/// `predicate_cache_inner_records` are stored as gauges, not counts).
fn gauge_value(metrics: &MetricsSet, name: &str) -> usize {
    match metrics.sum_by_name(name) {
        Some(MetricValue::Gauge { gauge, .. }) => gauge.value() as usize,
        Some(other) => panic!("metric '{name}' is not a Gauge: {other:?}"),
        None => panic!("metric '{name}' not found in\n\n{metrics:#?}"),
    }
}

/// Flatten column `col_idx` of a batch list into a `Vec<i32>` (no nulls).
fn column_i32(batches: &[RecordBatch], col_idx: usize) -> Vec<i32> {
    let mut out = Vec::new();
    for b in batches {
        let a = b.column(col_idx).as_primitive::<Int32Type>();
        for i in 0..a.len() {
            out.push(a.value(i));
        }
    }
    out
}

fn sorted(mut v: Vec<i32>) -> Vec<i32> {
    v.sort();
    v
}

/// Register `file` as `table` in a context configured with `opts`, run `sql`,
/// and return column 0 of the result as a `Vec<i32>` (in the query's row order).
async fn sql_col0(file: &TestParquetFile, table: &str, sql: &str, opts: ParquetScanOptions) -> Vec<i32> {
    let ctx = SessionContext::new_with_config(opts.config());
    let path = file.path().to_str().unwrap().to_string();
    ctx.register_parquet(table, &path, ParquetReadOptions::default())
        .await
        .unwrap();
    let df = ctx.sql(sql).await.unwrap();
    let batches = df.collect().await.unwrap();
    column_i32(&batches, 0)
}

// ---------------------------------------------------------------------------
// Criterion 1 (f2p): the RowFilter is not evaluated for a fully-matched RG.
//
// Observable: `predicate_cache_inner_records`
//   This pre-existing metric counts the total number of record evaluations
//   going through the predicate cache (inner: before deduplication). When the
//   RowFilter is skipped for a fully-matched row group, those rows bypass the
//   cache entirely, so the count drops.
//
// Fixture: MIXED two-RG file — [1,2,3](RG0, not FM) + [4,5,6](RG1, FM).
//   CONTROL: a file where NO row group is fully matched (RG [1,2,3] alone).
//     predicate_cache_inner_records > 0  (proves RowFilter/cache is live)
//   SUBJECT: the mixed file above.
//     Pre-fix:                        cache = 6  (RowFilter runs over BOTH groups)
//     Per-RG skip (shared metrics):   cache = 3  (RowFilter skips RG1; oracle approach)
//     Per-RG skip (separate metrics): cache = 0  (RowFilter skips RG1; separate
//       per-stream ArrowReaderMetrics — last-writer-wins Gauge reads FM run's 0)
//     Whole-file skip:                cache = 6  (not all RGs fully matched -> no skip)
//
// This discriminates (assert: cache < 6):
//   - Accepts: any genuine per-RG RowFilter skip, regardless of metrics architecture
//     (cache=3 shared-metrics or cache=0 separate-metrics, both are < 6)
//   - REJECTS: grok-style whole-file-only skip (cache stays at 6)
//   - REJECTS: predicate-cache auto-size fix (RowFilter still runs: cache = 6)
//   - REJECTS: pre-fix (RowFilter still runs: cache = 6)
// ---------------------------------------------------------------------------
#[tokio::test]
async fn row_filter_skipped_for_fully_matched_row_group() {
    let dir = TempDir::new_in(".").unwrap();
    let opts = scan_opts(true, true);
    let filter = col("a").gt_eq(lit(3));

    // CONTROL: single RG [1,2,3], no row is fully matched (filter `a >= 3`
    // only matches row 3). The RowFilter runs; predicate_cache_inner_records > 0.
    let control = write_single_col(&dir, "rf_control.parquet", &[1, 2, 3], 1024);
    let (c_rows, c_metrics) = scan_with_metrics(&control, &filter, opts).await;
    let control_cache = gauge_value(&c_metrics, "predicate_cache_inner_records");
    assert!(
        control_cache > 0,
        "RowFilter/predicate cache not live: control predicate_cache_inner_records==0 \
         (pushdown pipeline not active on this build). Metrics:\n{c_metrics:#?}"
    );
    assert_eq!(sorted(column_i32(&c_rows, 0)), vec![3]);

    // SUBJECT: MIXED two-RG file [1,2,3](RG0, not FM) + [4,5,6](RG1, FM).
    // With a correct per-RG fix the RowFilter is skipped for RG1 only;
    // predicate_cache_inner_records is < 6 (the pre-fix / whole-file-skip value).
    // It may be 3 (shared ArrowReaderMetrics across decoder runs — oracle approach)
    // or 0 (separate per-stream ArrowReaderMetrics — also a valid per-RG architecture,
    //        where the last-writer-wins Gauge is written by the FM run which saw 0
    //        inner records). Both are distinct per-RG-skip outcomes; pre-fix / whole-
    //        file-only skip keeps the gauge at exactly 6 (both RGs ran the filter).
    // Without the fix (or with a whole-file-only skip) it stays at 6.
    let mixed = write_single_col(&dir, "rf_mixed.parquet", &[1, 2, 3, 4, 5, 6], 3);
    let (m_rows, m_metrics) = scan_with_metrics(&mixed, &filter, opts).await;
    let mixed_cache = gauge_value(&m_metrics, "predicate_cache_inner_records");
    assert!(
        mixed_cache < 6,
        "fully-matched row group RG1=[4,5,6] still ran its rows through the RowFilter \
         (predicate_cache_inner_records={mixed_cache}, expected < 6 — RG1 is fully \
         matched and must be skipped). A correct per-RG implementation may yield \
         cache=3 (shared ArrowReaderMetrics) or cache=0 (separate per-stream metrics); \
         both are valid. Whole-file-only skip or pre-fix yields exactly 6. \
         Metrics:\n{m_metrics:#?}"
    );
    // Results must still be correct.
    assert_eq!(sorted(column_i32(&m_rows, 0)), vec![3, 4, 5, 6]);
}

// ---------------------------------------------------------------------------
// Criterion 2 (f2p): page-index pruning is not run for a fully-matched RG.
//
// Observable: `page_index_pages_pruned` total (pruned + matched + fully_matched).
// When page-index evaluation is skipped for a FM row group, that group contributes
// 0 pages to page_index_pages_pruned. A correct fix skips both the RowFilter AND
// the page-index evaluation for FM row groups.
//
// Fixture: two separate single-RG files.
//   CONTROL: single RG [1,2,3] with filter `a >= 3` — NOT fully matched.
//     Page-index runs: page_index_pages_pruned total > 0.
//     (Proves the page-index pipeline is live in this build.)
//   SUBJECT: single RG [4,5,6] with filter `a >= 3` — FULLY matched.
//     Pre-fix:           page-index runs → page_index_pages_pruned total > 0
//     Per-RG skip (fix): page-index skipped for FM → total == 0
//     Whole-file skip:   depends on implementation; per-RG also implies page skip
//
// Self-baselining: CONTROL proves page-index runs (total > 0) on the same binary,
// so if SUBJECT gives total == 0 it is because FM detection fired and page-index
// was skipped — not because the fixture is empty or the metric missing.
// ---------------------------------------------------------------------------
#[tokio::test]
async fn page_index_skipped_for_fully_matched_row_group() {
    let dir = TempDir::new_in(".").unwrap();
    let filter = col("a").gt_eq(lit(3));
    let opts = scan_opts(true, true);

    // CONTROL: single RG [1,2,3], NOT fully matched by `a >= 3`.
    // Page-index runs over this group; total must be > 0 to prove the metric is live.
    let control = write_single_col(&dir, "pi_control.parquet", &[1, 2, 3], 3);
    let (c_rows, c_metrics) = scan_with_metrics(&control, &filter, opts).await;
    let control_total = pruning_total(&c_metrics, "page_index_pages_pruned");
    assert!(
        control_total > 0,
        "page-index pipeline is not live on this build: page_index_pages_pruned==0 for \
         a non-fully-matched row group (control [1,2,3]). \
         Metrics:\n{c_metrics:#?}"
    );
    assert_eq!(sorted(column_i32(&c_rows, 0)), vec![3]);

    // SUBJECT: single RG [4,5,6], FULLY matched by `a >= 3`.
    // With the fix, page-index evaluation is skipped for FM row groups, so
    // page_index_pages_pruned must be 0 — no pages go through the page-index path.
    // Without the fix, page-index still runs and contributes matched/fully_matched
    // pages → total > 0.
    let subject = write_single_col(&dir, "pi_subject.parquet", &[4, 5, 6], 3);
    let (s_rows, s_metrics) = scan_with_metrics(&subject, &filter, opts).await;
    let subject_total = pruning_total(&s_metrics, "page_index_pages_pruned");
    assert_eq!(
        subject_total, 0,
        "page-index evaluation still ran for the fully-matched row group [4,5,6]: \
         page_index_pages_pruned total={subject_total} (expected 0 — FM row group \
         must be skipped entirely by the page-index path). \
         Metrics:\n{s_metrics:#?}"
    );
    // Results must still be correct (all 3 rows returned since filter `a >= 3`
    // passes all of [4,5,6]).
    assert_eq!(sorted(column_i32(&s_rows, 0)), vec![4, 5, 6]);
}

// ---------------------------------------------------------------------------
// Criterion 3 (p2p, basic): query results are byte-for-byte identical with and
// without pushdown, and match the expected set (pure-performance change).
// ---------------------------------------------------------------------------
#[tokio::test]
async fn results_identical_with_and_without_pushdown() {
    let dir = TempDir::new_in(".").unwrap();
    // 3 row groups: [1,2,3] [4,5,6] [7,1,2]; RG1 is fully matched by `a >= 3`.
    let file = write_single_col(&dir, "results.parquet", &[1, 2, 3, 4, 5, 6, 7, 1, 2], 3);

    let cases: Vec<(Expr, Vec<i32>)> = vec![
        (col("a").gt_eq(lit(3)), vec![3, 4, 5, 6, 7]),
        (col("a").gt(lit(4)), vec![5, 6, 7]),
        (col("a").lt(lit(3)), vec![1, 1, 2, 2]),
        (col("a").eq(lit(2)), vec![2, 2]),
    ];

    for (filter, expected) in cases {
        let (rows_pd, _m1) = scan_with_metrics(&file, &filter, scan_opts(true, true)).await;
        let (rows_no, _m2) = scan_with_metrics(&file, &filter, scan_opts(false, false)).await;
        let got_pd = sorted(column_i32(&rows_pd, 0));
        let got_no = sorted(column_i32(&rows_no, 0));
        assert_eq!(got_pd, expected, "pushdown result mismatch for {filter:?}");
        assert_eq!(
            got_pd, got_no,
            "pushdown vs no-pushdown results diverged for {filter:?}"
        );
    }
}

// ---------------------------------------------------------------------------
// Criterion 4 (f2p): a global LIMIT is enforced across the ENTIRE scan even when
// a fully-matched row group sits between filtered groups. This is the PR's own
// regression (limit_pruning.slt): `WHERE a >= 3 ORDER BY a LIMIT 4` -> [3,4,5,6]
// over the 3-row-group file. A worse split-decoder implementation that applies
// the limit PER RUN (instead of across the combined stream) drops rows that
// belong in the global top-k; the final result is then missing rows that the
// top-k operator cannot recover, so the vector mismatches. Passes with the fix
// AND on a pre-fix tree (single decoder, correct global limit); REJECTS a
// broken split. Expected rows are exact, so the assertion is order-sensitive.
// ---------------------------------------------------------------------------
#[tokio::test]
async fn global_limit_enforced_across_split_scan() {
    let dir = TempDir::new_in(".").unwrap();
    // [1,2,3] [4,5,6] [7,1,2] -> `a >= 3` spans all three groups; RG1 fully matched.
    let file = write_single_col(&dir, "limit.parquet", &[1, 2, 3, 4, 5, 6, 7, 1, 2], 3);
    let got = sql_col0(
        &file,
        "t_limit",
        "SELECT a FROM t_limit WHERE a >= 3 ORDER BY a LIMIT 4",
        scan_opts(true, true),
    )
    .await;
    assert_eq!(
        got,
        vec![3, 4, 5, 6],
        "global LIMIT across a split scan over-returned or reordered rows"
    );
}

// ---------------------------------------------------------------------------
// Criterion 5 (p2p): reverse (descending) ordering is preserved across the scan
// when it is split by fully-matched runs.
// ---------------------------------------------------------------------------
#[tokio::test]
async fn reverse_order_preserved_across_split_scan() {
    let dir = TempDir::new_in(".").unwrap();
    let file = write_single_col(&dir, "reverse.parquet", &[1, 2, 3, 4, 5, 6, 7, 1, 2], 3);
    let got = sql_col0(
        &file,
        "t_rev",
        "SELECT a FROM t_rev WHERE a >= 3 ORDER BY a DESC",
        scan_opts(true, true),
    )
    .await;
    assert_eq!(
        got,
        vec![7, 6, 5, 4, 3],
        "reverse-ordered scan did not preserve global descending order"
    );
}

// ---------------------------------------------------------------------------
// Criterion 6 (p2p): a multi-column page-pruning predicate does not panic and
// returns correct rows.
// ---------------------------------------------------------------------------
#[tokio::test]
async fn multi_column_page_predicate_does_not_panic() {
    let dir = TempDir::new_in(".").unwrap();
    let file = write_two_col(&dir, "multicol.parquet", &[1, 2, 3, 4, 5, 6, 7, 1, 2], 3);
    let got = sql_col0(
        &file,
        "t_mc",
        "SELECT a FROM t_mc WHERE a >= 3 AND b >= 3 ORDER BY a",
        scan_opts(true, true),
    )
    .await;
    assert_eq!(
        got,
        vec![3, 4, 5, 6, 7],
        "multi-column predicate scan returned wrong rows (or the scan panicked)"
    );
}

// ---------------------------------------------------------------------------
// Criterion 7 (p2p): fully-matched detection via row-group statistics still
// works and is not regressed / reimplemented away.
// ---------------------------------------------------------------------------
#[tokio::test]
async fn fully_matched_detection_still_works() {
    let dir = TempDir::new_in(".").unwrap();
    // [1,2,3] [4,5,6] [7,1,2]; only RG1 ([4,5,6]) is fully matched by `a >= 3`.
    let file = write_single_col(&dir, "detect.parquet", &[1, 2, 3, 4, 5, 6, 7, 1, 2], 3);
    let filter = col("a").gt_eq(lit(3));
    let (_rows, metrics) = scan_with_metrics(&file, &filter, scan_opts(true, true)).await;
    let fully_matched = pruning_fully_matched(&metrics, "row_groups_pruned_statistics");
    assert_eq!(
        fully_matched, 1,
        "row-group fully-matched detection regressed: \
         row_groups_pruned_statistics.fully_matched()={fully_matched}, expected 1. \
         Metrics:\n{metrics:#?}"
    );
}
