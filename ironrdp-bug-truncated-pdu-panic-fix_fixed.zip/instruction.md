## Task

heads up, our RDP message decoders fall over on bad input from the peer. if the other end sends a message that's cut off partway through, decoding panics and takes the whole connection down instead of rejecting the message. that's reachable straight from untrusted input, so a remote peer can crash us whenever it likes.

a cut-off message should come back as a decode error, not a panic, and not as a successful decode of half a message. can you dig in and fix that? don't overcorrect though: messages that decode fine today, including short ones that legitimately leave out optional trailing bytes, should keep decoding.
