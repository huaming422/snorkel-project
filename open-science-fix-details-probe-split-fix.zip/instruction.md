## Task

A remote compute host's Details / instructions document now reports a conflict when someone saves it for the first time after running a resource probe. To reproduce it, add a host, probe its resources, and save its details. The save says the document changed, although that host has no previously saved document. Saving immediately after adding the host worked before this regression.

The Settings UI shows the problem in the usual host workflow. It also affects the agent-facing compute API: an agent can read the host's details, then have its save rejected using that read as the starting point. Restore a working first read-then-save flow for both callers, while retaining genuine conflict protection for competing edits.

Keep the repair focused on the Details document and its save behavior. Probe observations must remain available. SSH connections, authentication, scratch paths, and the resource probe itself are outside this issue.
