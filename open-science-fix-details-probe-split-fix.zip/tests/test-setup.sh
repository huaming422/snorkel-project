#!/usr/bin/env bash
# Environment bootstrap for the verifier.
#
# Sourced (not exec'd) by the harbor runner so any env vars set here stay live
# for the verifier subprocess.
#
# open-science is a plain npm project (no pnpm workspaces). The full dependency
# closure is baked into the image at the base commit (image step 10 runs
# `npm ci`, whose postinstall runs `prisma generate`), so everything below is
# normally a no-op; the online branches exist only as a logged fallback for a
# corrupted node_modules.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/open-science}"
export REPO_DIR
cd "$REPO_DIR"

# Sanity: vitest must be resolvable from node_modules. If it is missing the
# baked install is corrupt — restore it offline-first from the image's warm npm
# cache, falling back to an online install only if that cannot be satisfied.
# This is the single dependency-resolving command in this script ([sync]).
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/; restoring (offline-first)." >&2
    npm ci --offline || { echo "test-setup.sh: offline restore failed; retrying online." >&2; npm ci; }
fi

# The repo's `pretest` hook (check-prisma-client.mjs) requires a generated Prisma
# client, and the real-SQLite compute tests migrate against it. `npm ci`'s
# postinstall already runs `prisma generate`, so this only fires if the generated
# client is absent (e.g. after a bare node_modules restore).
if ! [ -f node_modules/.prisma/client/schema.prisma ]; then
    echo "test-setup.sh: generating Prisma client." >&2
    npx prisma generate
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR node=$(node --version 2>/dev/null || echo unknown) vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
