"""Behavioral verifier for trino-fix-identical-domain-pushdown.

The three related breakages are all observable at two pre-existing, stable
interfaces, each with an upstream JUnit test class that exercises it:

  * ``io.trino.sql.planner.DomainTranslator`` — the planner surface that
    extracts a ``TupleDomain`` (for connector pushdown) from an IR predicate.
    Exercised by ``TestDomainTranslator`` through its public
    ``assertPredicate*`` helpers. Symptom 2 (null-safe equality over a
    coercion) and symptom 3 (boolean-valued null-safe equality) surface here.

  * ``io.trino.plugin.jdbc.DefaultQueryBuilder`` — the base-JDBC query builder
    that generates the remote SQL string for a pushed-down join. Exercised by
    ``TestDefaultJdbcQueryBuilder`` against an in-memory H2 database. Symptom 1
    (the stray non-SQL operator glyph in a legacy join) surfaces here.

This verifier is implementation-agnostic. It drives those two upstream test
classes through Maven surefire and reads the externally-observable results
(extracted domains and generated SQL) — never the solution's internal
structure. Any fix that makes those interfaces behave correctly passes,
whatever file it lives in, however it decomposes the work, and whatever it
names any helper it introduces.

The test methods that exercise the fixed behavior are the ones the upstream work
added to those two classes. They are NOT part of what the solving agent is
handed; this
verifier applies them to the working tree at grade time (``verifier_tests.patch``,
see ``_apply_test_patch``) so the agent never sees the exact assertions. The
agent edits only production source, so the patch (which touches only the two
test files) applies cleanly on top of any valid solution.

The verifier shells out to the repo's Maven wrapper; it imports no repository
Python (Trino is a Java project), so it runs under the shared VERIFIER_PYTHON
with no repo-native pytest command.
"""

from __future__ import annotations

import os
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

import pytest

REPO = Path(os.environ.get("REPO_DIR", "/repo/trino"))
JAVA_HOME = os.environ.get("JAVA_HOME", "/opt/jdk25")

# The verifier-owned test patch lives next to this file. It adds the upstream
# upstream test methods that exercise the fixed behavior to the two offline
# test classes.
PATCH_PATH = Path(__file__).resolve().parent / "verifier_tests.patch"

# Fully-qualified names of the two pre-existing test classes we drive, with the
# module each lives in and the surefire report that module emits.
DOMAIN_TRANSLATOR_CLASS = "io.trino.sql.planner.TestDomainTranslator"
QUERY_BUILDER_CLASS = "io.trino.plugin.jdbc.TestDefaultJdbcQueryBuilder"

SUREFIRE_REPORTS = {
    DOMAIN_TRANSLATOR_CLASS: REPO / "core/trino-main/target/surefire-reports",
    QUERY_BUILDER_CLASS: REPO / "plugin/trino-base-jdbc/target/surefire-reports",
}

# Maven flags shared by the reinstall and the test run. Offline (-o): the image
# baked the full dependency closure + compiled reactor, so no network is used.
# The static-analysis checks and the git-commit-id plugin are irrelevant to the
# focused tests and only slow the build.
COMMON_MVN_FLAGS = [
    "-o",
    "-B",
    "-Dair.check.skip-all=true",
    "-Dmaven.gitcommitid.skip=true",
]

# A single Maven invocation (reinstall then test) is comfortably a couple of
# minutes on a warm image; bound the subprocess well under the pytest timeout.
MVN_TIMEOUT_SEC = 850


def _mvn_env() -> dict:
    env = {**os.environ}
    env["JAVA_HOME"] = JAVA_HOME
    env["PATH"] = f"{JAVA_HOME}/bin:{env.get('PATH', '')}"
    return env


def _run(cmd: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(
        cmd,
        cwd=str(REPO),
        env=_mvn_env(),
        capture_output=True,
        text=True,
        timeout=MVN_TIMEOUT_SEC,
        check=False,
    )


def _apply_test_patch() -> None:
    """Apply the verifier-owned test patch to the working tree, idempotently.

    Genuine infrastructure failures (missing repo, missing patch, a patch that
    neither applies nor is already applied) raise, which invalidates the trial
    rather than scoring it. A clean or already-applied patch is a no-op.
    """
    if not REPO.is_dir():
        raise RuntimeError(f"repo not found at {REPO}")
    if not PATCH_PATH.is_file():
        raise RuntimeError(f"verifier test patch not found at {PATCH_PATH}")

    # Already applied? (patch reverses cleanly) → nothing to do.
    reverse_check = subprocess.run(
        ["git", "apply", "--reverse", "--check", str(PATCH_PATH)],
        cwd=str(REPO),
        capture_output=True,
        text=True,
        check=False,
    )
    if reverse_check.returncode == 0:
        return

    forward_check = subprocess.run(
        ["git", "apply", "--check", str(PATCH_PATH)],
        cwd=str(REPO),
        capture_output=True,
        text=True,
        check=False,
    )
    if forward_check.returncode != 0:
        raise RuntimeError(
            "verifier_tests.patch does not apply to the working tree and is not "
            f"already applied:\n{forward_check.stderr}"
        )

    applied = subprocess.run(
        ["git", "apply", str(PATCH_PATH)],
        cwd=str(REPO),
        capture_output=True,
        text=True,
        check=False,
    )
    if applied.returncode != 0:
        raise RuntimeError(f"failed to apply verifier_tests.patch:\n{applied.stderr}")


def _reinstall_edited_modules() -> subprocess.CompletedProcess:
    """Republish the agent's edits so downstream modules test against them.

    ``plugin/trino-base-jdbc`` compiles and tests against the ``trino-spi``
    *artifact* in the local Maven repository, not reactor source — so after an
    edit to ``JoinCondition.java`` the stale artifact (still carrying the bad
    glyph) would be used unless ``trino-spi`` is reinstalled first. Reinstalling
    ``trino-main`` too keeps the planner artifact consistent. Idempotent: a
    no-op reinstall when nothing changed is cheap.
    """
    return _run(
        ["./mvnw", *COMMON_MVN_FLAGS, "-pl", "core/trino-spi,core/trino-main",
         "-am", "install", "-DskipTests",
         "-Dmaven.javadoc.skip=true", "-Dmaven.source.skip=true", "-T2C"]
    )


def _clean_surefire_reports() -> None:
    """Delete any pre-existing surefire reports for the two target classes.

    The image bake warms the Maven test-execution cache by running these two
    classes once at build time; that leaves stale ``TEST-*.xml`` reports in the
    modules' ``surefire-reports`` dirs. If a later Maven invocation skips a
    module (e.g. the reactor bans a downstream module after an upstream test
    failure), ``_parse_surefire`` would otherwise read the stale report and
    score a run that never happened this trial. Removing the specific report
    files first makes "module did not run" observable as an absent report.
    """
    for fq, reports_dir in SUREFIRE_REPORTS.items():
        xml = reports_dir / f"TEST-{fq}.xml"
        try:
            xml.unlink()
        except FileNotFoundError:
            pass
        # Surefire also writes a per-method <class>.txt summary; clear it too so
        # no stale trace lingers next to a fresh run.
        txt = reports_dir / f"{fq}.txt"
        try:
            txt.unlink()
        except FileNotFoundError:
            pass


def _run_test_class(module: str, simple_class: str) -> subprocess.CompletedProcess:
    """Run one test class in its own module, in isolation.

    The two classes are run as SEPARATE Maven invocations rather than one
    combined ``-pl a,b`` reactor: a combined run aborts (and *skips* the
    second module) as soon as the first module has a test failure, which on a
    broken solution would prevent the jdbc symptom from ever being exercised —
    masking a genuine failure as an absent report. Independent invocations let
    each symptom be observed on its own regardless of the other's outcome.
    """
    return _run(
        ["./mvnw", *COMMON_MVN_FLAGS, "-pl", module, "test",
         f"-Dtest={simple_class}", "-DfailIfNoTests=false"]
    )


def _parse_surefire(reports_dir: Path, fq_class: str) -> dict[str, bool]:
    """Return {method_name: passed} for one test class, or {} if no report."""
    xml = reports_dir / f"TEST-{fq_class}.xml"
    if not xml.is_file():
        return {}
    root = ET.parse(str(xml)).getroot()  # noqa: S314 — trusted local surefire output
    results: dict[str, bool] = {}
    for tc in root.findall("testcase"):
        name = tc.get("name", "")
        # Strip any surefire parametrization suffix, e.g. "method[1]".
        base = name.split("[", 1)[0]
        failed = tc.find("failure") is not None or tc.find("error") is not None
        # A class can list a method more than once (parametrized). It passes
        # only if every execution passed.
        results[base] = results.get(base, True) and not failed
    return results


class _Outcome:
    """Collected result of the one Maven run, shared across the pytest cases."""

    def __init__(self) -> None:
        _apply_test_patch()
        # Remove stale baked reports BEFORE running so a module that is skipped
        # this trial can never be scored from a previous (build-time) report.
        _clean_surefire_reports()
        self.reinstall = _reinstall_edited_modules()
        # Run each class in its own module invocation so one module's failure
        # cannot skip the other (see _run_test_class).
        self.test_run_dt = _run_test_class(
            "core/trino-main", DOMAIN_TRANSLATOR_CLASS.rsplit(".", 1)[-1]
        )
        self.test_run_qb = _run_test_class(
            "plugin/trino-base-jdbc", QUERY_BUILDER_CLASS.rsplit(".", 1)[-1]
        )
        self.by_class = {
            fq: _parse_surefire(reports, fq)
            for fq, reports in SUREFIRE_REPORTS.items()
        }

    def _tail(self) -> str:
        parts = []
        if self.reinstall.returncode != 0:
            parts.append("REINSTALL stdout tail:\n" + self.reinstall.stdout[-2500:])
            parts.append("REINSTALL stderr tail:\n" + self.reinstall.stderr[-1500:])
        parts.append("TestDomainTranslator (trino-main) stdout tail:\n"
                     + self.test_run_dt.stdout[-3000:])
        parts.append("TestDefaultJdbcQueryBuilder (trino-base-jdbc) stdout tail:\n"
                     + self.test_run_qb.stdout[-3000:])
        parts.append("TEST stderr tail (jdbc):\n" + self.test_run_qb.stderr[-1200:])
        return "\n\n".join(parts)

    def method(self, fq_class: str, method: str) -> bool:
        """True iff the named method ran and passed.

        A method absent from the surefire report means it never ran (a compile
        failure in the solution, or the suite aborting) — treated as a failure,
        with the Maven output attached so the reason is visible.
        """
        results = self.by_class.get(fq_class, {})
        if method not in results:
            pytest.fail(
                f"{fq_class}.{method} did not run (no surefire result). The "
                f"solution likely fails to compile or the suite aborted before "
                f"reaching it.\n\n{self._tail()}"
            )
        return results[method]

    def class_results(self, fq_class: str) -> dict[str, bool]:
        return self.by_class.get(fq_class, {})


@pytest.fixture(scope="session")
def outcome() -> _Outcome:
    return _Outcome()


def test_legacy_join_sql(outcome: _Outcome) -> None:
    """Criterion legacy_join_sql (fail_to_pass).

    A legacy (non-complex) JDBC join pushdown of an ``IS NOT DISTINCT FROM``
    condition must generate valid remote SQL. Pre-fix the base query builder
    splices a stray non-SQL glyph where the operator belongs and H2 rejects the
    statement with a syntax error; post-fix the generated SQL reads
    ``IS NOT DISTINCT FROM`` and the join runs. Observed through
    ``TestDefaultJdbcQueryBuilder`` against in-memory H2.
    """
    assert outcome.method(QUERY_BUILDER_CLASS, "testBuildJoinSqlLegacy"), (
        "legacy IS NOT DISTINCT FROM join pushdown still produces invalid "
        f"remote SQL.\n\n{outcome._tail()}"
    )


def test_coerced_cast_identical(outcome: _Outcome) -> None:
    """Criterion coerced_cast_identical (fail_to_pass).

    Null-safe equality over a coercion must extract the correct domain: a
    literal that round-trips through the cast constrains the column to that one
    value (its negation to the complement, null included); a literal the cast
    can never produce makes the predicate always-false (its negation
    always-true). Pre-fix a non-round-tripping literal drops the predicate or
    matches a rounded value. Observed through ``TestDomainTranslator``.
    """
    assert outcome.method(DOMAIN_TRANSLATOR_CLASS, "testIdenticalOverCoercedCast"), (
        "IS NOT DISTINCT FROM over a coerced cast extracts the wrong domain.\n\n"
        f"{outcome._tail()}"
    )
    # The varchar-cast-to-date case gains an IDENTICAL assertion covering the
    # same coercion semantics on a different type.
    assert outcome.method(DOMAIN_TRANSLATOR_CLASS, "testPredicateWithVarcharCastToDate"), (
        "IS NOT DISTINCT FROM over a varchar-to-date cast extracts the wrong "
        f"domain.\n\n{outcome._tail()}"
    )


def test_boolean_constant_identical(outcome: _Outcome) -> None:
    """Criterion boolean_constant_identical (fail_to_pass).

    ``(condition) IS NOT DISTINCT FROM <boolean constant>`` must extract the
    domain of ``condition`` itself (for TRUE/FALSE), and its negation the
    complement — but only when that domain is exact, constrains a single column,
    and does not drop NaN; otherwise the predicate is kept unrewritten. The one
    test method covers every edge case (double negation, multi-column operand,
    always-false operand, partial domains, NaN-typed columns, null boolean
    literal, both-constant). Pre-fix none of this is handled. Observed through
    ``TestDomainTranslator``.
    """
    assert outcome.method(DOMAIN_TRANSLATOR_CLASS, "testFromIdenticalToBooleanConstant"), (
        "IS NOT DISTINCT FROM against a boolean constant is not translated "
        f"correctly.\n\n{outcome._tail()}"
    )


def test_no_regression(outcome: _Outcome) -> None:
    """Criterion no_regression (pass_to_pass).

    The whole pre-existing ``TestDomainTranslator`` and
    ``TestDefaultJdbcQueryBuilder`` suites must stay green — the fix must not
    regress EQUAL / NOT_EQUAL domain extraction, symbol-side IDENTICAL handling,
    or join SQL for other operators. Asserts both suites actually ran a
    plausible number of cases and that none failed.
    """
    dt = outcome.class_results(DOMAIN_TRANSLATOR_CLASS)
    qb = outcome.class_results(QUERY_BUILDER_CLASS)

    assert dt, (
        "TestDomainTranslator produced no surefire results — the suite did not "
        f"run.\n\n{outcome._tail()}"
    )
    assert qb, (
        "TestDefaultJdbcQueryBuilder produced no surefire results — the suite "
        f"did not run.\n\n{outcome._tail()}"
    )
    # Guard against a vacuous pass: the known pre-existing cases must be present.
    assert "testBuildJoinSqlLegacy" in qb
    assert "testFromBasicComparisons" in dt or len(dt) >= 20, (
        f"TestDomainTranslator ran unexpectedly few cases ({len(dt)}).\n\n"
        f"{outcome._tail()}"
    )

    failed = [f"{DOMAIN_TRANSLATOR_CLASS}.{m}" for m, ok in dt.items() if not ok]
    failed += [f"{QUERY_BUILDER_CLASS}.{m}" for m, ok in qb.items() if not ok]
    assert not failed, (
        "regression: these pre-existing or new cases failed: "
        f"{', '.join(sorted(failed))}\n\n{outcome._tail()}"
    )
