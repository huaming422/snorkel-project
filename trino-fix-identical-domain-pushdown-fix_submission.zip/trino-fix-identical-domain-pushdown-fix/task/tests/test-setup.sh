#!/usr/bin/env bash
# test-setup.sh — sourced before the verifier runs.
#
# The image baked the full Maven dependency closure and the compiled reactor for
# core/trino-main and plugin/trino-base-jdbc (and their upstream modules) into
# ~/.m2 and the per-module target/ dirs at the base commit. This script reinstalls
# the modules the agent may have edited so the installed artifacts reflect the
# agent's source, then leaves the tree ready for the offline focused test run.
#
# Everything here runs OFFLINE (-o): no network is required or used.
set -euo pipefail

cd /repo/trino

export JAVA_HOME="${JAVA_HOME:-/opt/jdk25}"
export PATH="${JAVA_HOME}/bin:${PATH}"

java -version 2>&1 | head -1

# Reinstall the library modules whose compiled artifacts the connector tests
# depend on (trino-spi carries JoinCondition; trino-main carries DomainTranslator).
# Reinstalling republishes the agent's edits into ~/.m2 so downstream modules
# (plugin/trino-base-jdbc) compile and test against them. Quality/style checks
# and the git-commit-id plugin are skipped — they are irrelevant to the focused
# tests and only slow the rebuild.
echo "test-setup: offline reinstall of trino-spi and trino-main..."
./mvnw -o -B -pl core/trino-spi,core/trino-main -am install -DskipTests \
    -Dair.check.skip-all=true -Dmaven.gitcommitid.skip=true \
    -Dmaven.javadoc.skip=true -Dmaven.source.skip=true -T2C \
    > /tmp/test-setup.log 2>&1 || { tail -120 /tmp/test-setup.log; exit 1; }

echo "test-setup: ready."
