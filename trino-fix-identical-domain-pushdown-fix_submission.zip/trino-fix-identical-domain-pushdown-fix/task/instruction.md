## Task

Several related things have broken around `IS NOT DISTINCT FROM` (null-safe
equality) in the query engine. They surfaced separately but look connected, and
want fixing together:

- With complex join pushdown off, a join on `a IS NOT DISTINCT FROM b` against a
  JDBC database like PostgreSQL fails at the remote end with a SQL syntax error:
  the SQL we generate has a stray non-SQL character where the operator belongs.

- `CAST(col AS <wider type>) IS NOT DISTINCT FROM <literal>` returns wrong rows. A
  literal that can't survive the cast is treated as always matching, so the filter
  silently vanishes; an impossible predicate matches a wrong, rounded-off value
  instead of nothing.

- `(<condition>) IS NOT DISTINCT FROM TRUE` (and the FALSE and negated forms) no
  longer pushes down to the connector, though the equivalent
  `col IS NULL OR NOT (<condition>)` phrasing still does, so the null-safe form
  makes scans do needless work.

Fix this in the engine, not in any single connector; turning off pushdown to hide
a symptom is not a fix.

Source is at `/repo/trino` (`JAVA_HOME=/opt/jdk25`, `./mvnw`); relevant modules are
prebuilt, so focused tests run offline with `-o`. Find the common cause and fix all
three.
