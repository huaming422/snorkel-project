## Task

heads up, the url status-check mode has been reporting wrong results and running slower than it should, and it used to work fine. the normal url gathering side is totally healthy, so the wrong results are something specific to how we check and time the status of each url. the sluggishness feels broader than that though, like it might be creeping into other spots that go out and hit urls too, not just the status check. can you dig in, figure out what's going on, and fix it?
