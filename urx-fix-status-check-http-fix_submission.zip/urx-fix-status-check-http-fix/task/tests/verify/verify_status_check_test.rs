// Behavioral verifier for the urx status-check HTTP fixes.
//
// urx is a binary-only crate (no library target), so this integration test
// exercises the ONLY stable public surface: the compiled `urx` CLI, launched
// via `std::process::Command::new(env!("CARGO_BIN_EXE_urx"))`. Nothing here
// imports crate internals — a correct fix may restructure the client builder
// or the retry loop any way it likes; these checks assert only CLI-observable
// behavior.
//
// Everything runs offline under loopback (127.0.0.1), which is up even under
// `--network none`. The redirect origin is a hand-rolled HTTP/1.1 server on a
// std thread (no async runtime needed in the test); the "unreachable" timing
// checks aim at a closed loopback port that refuses immediately.
//
// Covers:
//   c1 — a redirecting URL under --check-status is reported with its OWN 3xx
//        status, and the redirect target is never fetched.
//   c2 — --include-status 30x keeps a redirecting URL in the output.
//   c4 — --retries 0 does not sleep after the only (failing) attempt
//        (status-checker path).
//   c5 — the same no-backoff behavior holds on the --extract-links path
//        (the backoff fix must land in BOTH testers).
//   c6 — the complement of c1: on the --extract-links path a redirect IS still
//        followed (its target is fetched and its link surfaces), so the
//        redirect-not-following fix must be scoped to the status check and not
//        applied to the shared client every provider and the extractor use.

use std::io::{Read, Write};
use std::net::TcpListener;
use std::process::Command;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};

/// A loopback HTTP/1.1 origin: `GET /redir` answers with `status` + a
/// `Location: /final` header; any other path (notably `/final`) answers `200`
/// with a small HTML page carrying one absolute `<a href>`. Returns the bound
/// port and a counter of how many times `/final` was fetched — in a status
/// check the redirect must NOT be followed, so that stays 0; on the link
/// extraction path the redirect IS followed, so `/final` is fetched and its
/// link surfaces.
fn start_redirect_server(status: u16, reason: &str) -> (u16, Arc<AtomicUsize>) {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind loopback origin");
    let port = listener.local_addr().expect("local addr").port();
    let final_hits = Arc::new(AtomicUsize::new(0));
    let final_hits_thread = Arc::clone(&final_hits);
    let status_line = format!("HTTP/1.1 {status} {reason}\r\n");

    std::thread::spawn(move || {
        for stream in listener.incoming() {
            let mut stream = match stream {
                Ok(s) => s,
                Err(_) => continue,
            };
            let mut buf = [0u8; 1024];
            let n = stream.read(&mut buf).unwrap_or(0);
            let req = String::from_utf8_lossy(&buf[..n]);
            // First token of the request line after the method is the path.
            let path = req
                .lines()
                .next()
                .and_then(|l| l.split_whitespace().nth(1))
                .unwrap_or("/")
                .to_string();

            let response = if path.starts_with("/redir") {
                // Redirect response: zero-length body, close the connection so
                // the client sees a clean end without chunked/keep-alive games.
                format!(
                    "{status_line}Location: /final\r\nContent-Length: 0\r\nConnection: close\r\n\r\n"
                )
            } else {
                if path.starts_with("/final") {
                    final_hits_thread.fetch_add(1, Ordering::SeqCst);
                }
                // A tiny HTML page with one absolute link, so an extraction run
                // that reaches /final has something to emit.
                let body =
                    "<html><body><a href=\"http://example.com/found\">link</a></body></html>";
                format!(
                    "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",
                    body.len(),
                    body
                )
            };
            let _ = stream.write_all(response.as_bytes());
            let _ = stream.flush();
        }
    });

    (port, final_hits)
}

/// Write `contents` to a `urls.txt` under a fresh temp dir; returns the dir
/// (keep it alive for the file's lifetime) and the file path.
fn urls_file(contents: &str) -> (tempfile::TempDir, std::path::PathBuf) {
    let dir = tempfile::tempdir().expect("temp dir");
    let path = dir.path().join("urls.txt");
    std::fs::write(&path, contents).expect("write urls file");
    (dir, path)
}

/// A loopback port that is guaranteed closed: bind :0, record the port, drop
/// the listener. Connecting there fails immediately (connection refused) with
/// no network wait — the clean way to probe the retry/back-off timing.
fn closed_loopback_port() -> u16 {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind to reserve port");
    let port = listener.local_addr().expect("local addr").port();
    drop(listener);
    port
}

fn run_urx(args: &[&str]) -> (std::process::Output, Duration) {
    let start = Instant::now();
    let output = Command::new(env!("CARGO_BIN_EXE_urx"))
        .args(args)
        // Disable ANSI coloring so stdout assertions are on plain text.
        .env("NO_COLOR", "1")
        .output()
        .expect("urx should run");
    let elapsed = start.elapsed();
    (output, elapsed)
}

#[test]
fn c1_redirect_reported_not_followed() {
    let (port, final_hits) = start_redirect_server(301, "Moved Permanently");
    let url = format!("http://127.0.0.1:{port}/redir");
    let (_dir, path) = urls_file(&format!("{url}\n"));

    let (output, _) = run_urx(&[
        "--files",
        path.to_str().unwrap(),
        "--check-status",
        "--no-progress",
    ]);
    let stdout = String::from_utf8_lossy(&output.stdout);

    // The checked URL must be reported with its own redirect status (301),
    // never the 200 of the page it points at. Anchor on the bracketed status
    // field (`{url} [{status}]`) so a random loopback port that happens to
    // contain "200"/"301" in its digits can't skew the match.
    assert!(
        stdout.contains("[301"),
        "status line should report the redirect's own 301 status; stdout was: {stdout:?}"
    );
    assert!(
        !stdout.contains("[200"),
        "status check must not report the followed target's 200; stdout was: {stdout:?}"
    );
    // And the redirect target must never be fetched.
    assert_eq!(
        final_hits.load(Ordering::SeqCst),
        0,
        "the redirect target /final must not be fetched by a status check"
    );
}

#[test]
fn c2_include_status_30x_matches_redirect() {
    let (port, _final_hits) = start_redirect_server(302, "Found");
    let url = format!("http://127.0.0.1:{port}/redir");
    let (_dir, path) = urls_file(&format!("{url}\n"));

    let (output, _) = run_urx(&[
        "--files",
        path.to_str().unwrap(),
        "--check-status",
        "--include-status",
        "30x",
        "--no-progress",
    ]);
    let stdout = String::from_utf8_lossy(&output.stdout);

    // Pre-fix the followed redirect resolves to 200, which 30x never matches,
    // so output is empty. Post-fix the 302 surfaces and passes the filter.
    assert!(
        stdout.contains(&url) && stdout.contains("[302"),
        "--include-status 30x should keep the redirecting URL with its 302 status; stdout was: {stdout:?}"
    );
}

#[test]
fn c4_no_backoff_when_no_retries() {
    let port = closed_loopback_port();
    let url = format!("http://127.0.0.1:{port}/nope");
    let (_dir, path) = urls_file(&format!("{url}\n"));

    let (output, elapsed) = run_urx(&[
        "--files",
        path.to_str().unwrap(),
        "--check-status",
        "--retries",
        "0",
        "--no-progress",
    ]);
    let stdout = String::from_utf8_lossy(&output.stdout);

    // Guard against a vacuous pass: the status-check path must actually have
    // run and surfaced the unresolved URL (no --include-status allowlist, so a
    // failed check is kept with a "Status check failed" marker).
    assert!(
        stdout.contains(&url),
        "the status check must have run and emitted the unreachable URL; stdout was: {stdout:?}"
    );
    // With retries disabled there must be no ~500ms back-off after the sole
    // failed attempt. Pre-fix ~520-570ms; post-fix ~60ms. 400ms sits well
    // clear of both.
    assert!(
        elapsed < Duration::from_millis(400),
        "--retries 0 must not sleep after the only attempt, took {elapsed:?}"
    );
}

#[test]
fn c5_backoff_both_sites_link_extractor() {
    let port = closed_loopback_port();
    let url = format!("http://127.0.0.1:{port}/nope");
    let (_dir, path) = urls_file(&format!("{url}\n"));

    let (output, elapsed) = run_urx(&[
        "--files",
        path.to_str().unwrap(),
        "--extract-links",
        "--retries",
        "0",
        "--no-progress",
    ]);
    let stdout = String::from_utf8_lossy(&output.stdout);

    // Vacuous-pass guard: the extract-links path ran and emitted the URL.
    assert!(
        stdout.contains(&url),
        "the extract-links path must have run and emitted the URL; stdout was: {stdout:?}"
    );
    // The back-off fix must also land in the link-extractor loop, not just the
    // status-checker one.
    assert!(
        elapsed < Duration::from_millis(400),
        "--retries 0 on the extract-links path must not sleep, took {elapsed:?}"
    );
}

#[test]
fn c6_extract_links_follows_redirects() {
    // Complement of c1: the status check must NOT follow a redirect, but the
    // link-extraction path still must. A redirect-not-following change has to be
    // scoped to the status checker; an over-correction that disables redirect
    // following for every HTTP client (the shared builder) silently regresses
    // the gathering side this task is told stays healthy. /redir -> 301 ->
    // /final (200, HTML with one link); a scoped fix reaches /final and emits
    // its link, a global disable sees the bare 301 (non-success) and extracts
    // nothing.
    let (port, final_hits) = start_redirect_server(301, "Moved Permanently");
    let url = format!("http://127.0.0.1:{port}/redir");
    let (_dir, path) = urls_file(&format!("{url}\n"));

    let (output, _) = run_urx(&[
        "--files",
        path.to_str().unwrap(),
        "--extract-links",
        "--no-progress",
    ]);
    let stdout = String::from_utf8_lossy(&output.stdout);

    // The extractor must have followed /redir through to /final and fetched it.
    assert!(
        final_hits.load(Ordering::SeqCst) >= 1,
        "the extract-links path must follow the redirect and fetch /final; stdout was: {stdout:?}"
    );
    // And the link that only exists on /final must surface in the output — proof
    // the followed page was actually parsed, not just fetched.
    assert!(
        stdout.contains("http://example.com/found"),
        "the link extracted from the redirect target must appear in output; stdout was: {stdout:?}"
    );
}
