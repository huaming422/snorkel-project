#!/usr/bin/env bash
# test-setup.sh — sourced before the verifier runs (this phase HAS network).
# Pre-builds the `urx` binary and its test harness so the injected Rust
# integration verifier can locate the compiled binary via
# `env!("CARGO_BIN_EXE_urx")` without paying a cold compile inside its own
# timeout. The image already baked the full dependency closure at the base
# commit (cargo registry + git deps warm, incl. the `mockito` dev-dep), so the
# offline build below is the fast path; the online fallback only runs if the
# agent's work somehow invalidated the cache.
set -euo pipefail

cd /repo/urx

# The toolchain is pinned by the image (RUSTUP_TOOLCHAIN=${RUST_VERSION}); a
# repo rust-toolchain.toml does not float it.

# Offline-first: build the binary and compile test targets from the warm cache.
# `--tests` makes cargo compile the dev-dependency graph (mockito, etc.) too, so
# the verifier's own `cargo test` is a near no-op.
if cargo build --locked --offline --tests > /tmp/urx-setup-build.log 2>&1; then
    echo "test-setup: offline build OK"
else
    echo "test-setup: offline build failed; retrying online" >&2
    tail -40 /tmp/urx-setup-build.log >&2 || true
    cargo build --locked --tests > /tmp/urx-setup-build-online.log 2>&1 || {
        echo "test-setup: online build also failed" >&2
        tail -80 /tmp/urx-setup-build-online.log >&2
        exit 1
    }
fi

# Sanity: the binary the verifier drives must exist.
ls -la "${CARGO_TARGET_DIR:-/repo/urx/target}/debug/urx"
