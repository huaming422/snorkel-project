## Task

We're tightening up the component-model async runtime and keep running into
host-side crashes that ordinary guests and embedders can trigger.

Three separate things are going wrong. Zero-length reads and writes on component
streams and futures can panic the host when the supplied pointer happens to be
out of range. A zero-length transfer touches no memory, so it should just be a
harmless no-op. Dropping the future returned by an async component call can also
panic the host if the call has already been queued to run (say, after being
released from backpressure) but hasn't actually executed yet. And on a couple of
result-returning paths, guest code can re-enter the component while the host is
still lowering values back out, which is re-entry that's supposed to be
forbidden during that window.

All three are reachable from ordinary guest and embedder usage. Dig in and fix
all three.
