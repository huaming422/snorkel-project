## Task

Right now the .NET client only opens a local, in-process Turso database. We want the same provider to also connect to a hosted Turso database over HTTP, so an app can run SQL against a remote server instead of a local file. Remote access should speak the Turso/libSQL Hrana HTTP pipeline protocol at its `/v2/pipeline` endpoint; follow that protocol as specified.

Everything remote has to come through the provider's existing ADO.NET surface, the ordinary connection, command, transaction, batch, and data-reader types, so code already written against the provider keeps working once it points at a remote database. Don't add a separate client API just for remote use.

Keep the work in the managed .NET client library. Leave the native engine, the drop-in SQLite-compatibility layer, and the ORM integration alone.

## User stories / requirements

- Opening a connection on a remote Turso URL and running a parameterized statement reads the returned columns and rows back through the ordinary data reader, where a null column value reads back as a database null. The single-value variant returns the first column of the first row; the no-result variant returns the affected-row count.
- Before any network work, a remote connection checks its URL, transport, and options together and reports a clear error on an inconsistent combination: an auth token needs an HTTPS URL unless the host is loopback, and a TLS setting that contradicts the URL scheme is rejected. Local-only and remote-only options are mutually exclusive.
- Beginning a transaction on a remote connection and committing or rolling it back drives its statements over one continued server session. A SQL error while the transaction is open leaves that session intact, so a follow-up rollback still reaches it; a transport failure instead invalidates the connection so it can no longer be used.
- A remote connection can create a batch of several commands, send them together, and read each command's result set in turn. Batching is offered only on remote connections.
