// Behavioral fixtures for the remote Turso ADO.NET surface.
//
// These drive the provider's public, pre-existing ADO.NET types
// (TursoConnection / TursoCommand / DbBatch / DbDataReader /
// DbTransaction) against a loopback mock HTTP server that stands in for a
// hosted Turso server speaking the Hrana pipeline protocol. Nothing here
// references any internal remote type: the whole point is to observe the
// behavior a consumer sees through the standard surface.
//
// Each story method runs its scenarios, records the observed values it can
// reach through the public surface, and writes them as JSON to the path in
// the TURSO_VALIDATION_OUT environment variable. The Python runner reads
// that file and compares the observed values against the fixed expected
// values from the spec. Scenarios are wrapped so that one failing scenario
// still lets the others report, and a thrown error is recorded as the
// observed exception type rather than aborting the whole run.

using System.Data;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using Turso.Raw.Public;

namespace Turso.Tests.Validation;

// The class name deliberately avoids the story keywords (Execute / Validation /
// Transaction / Batch) so a method-name test filter selects exactly one story
// method and never the whole class.
public class RemoteBehaviorStories
{
    [Test]
    public void RemoteExecuteStory()
    {
        var cases = new Dictionary<string, Dictionary<string, object?>>();

        // case_0: a parameterized statement is sent to the pipeline endpoint
        // and the returned columns and rows read back through the reader. The
        // response carries a trailing close entry the client must tolerate.
        cases["case_0"] = Capture(() =>
        {
            const string responseJson = """
                {
                  "results": [
                    {
                      "type": "ok",
                      "response": {
                        "type": "execute",
                        "result": {
                          "cols": [
                            { "name": "n", "decltype": "INTEGER" },
                            { "name": "name", "decltype": "TEXT" }
                          ],
                          "rows": [
                            [
                              { "type": "integer", "value": "42" },
                              { "type": "text", "value": "alice" }
                            ]
                          ],
                          "affected_row_count": 0,
                          "last_insert_rowid": null
                        }
                      }
                    },
                    { "type": "ok", "response": { "type": "close" } }
                  ]
                }
                """;

            using var server = new MockRemoteServer(responseJson);
            using var connection = new TursoConnection(
                $"Data Source={server.Url};Auth Token=secret");
            connection.Open();

            using var command = connection.CreateCommand();
            command.CommandText = "SELECT ?, :name";
            var positional = command.CreateParameter();
            positional.Value = 42;
            command.Parameters.Add(positional);
            var named = command.CreateParameter();
            named.ParameterName = ":name";
            named.Value = "alice";
            command.Parameters.Add(named);

            var observed = new Dictionary<string, object?>();
            using (var reader = command.ExecuteReader())
            {
                observed["field_count"] = reader.FieldCount;
                reader.Read();
                observed["int_value"] = reader.GetInt64(0);
                observed["text_value"] = reader.GetString(1);
            }

            using var document = JsonDocument.Parse(server.RequestBody);
            var requests = document.RootElement.GetProperty("requests");
            observed["request_path"] = server.RequestUri?.AbsolutePath;
            observed["auth_header"] = server.Authorization;
            observed["arg0_value"] = requests[0].GetProperty("stmt")
                .GetProperty("args")[0].GetProperty("value").GetString();
            observed["named_arg_name"] = requests[0].GetProperty("stmt")
                .GetProperty("named_args")[0].GetProperty("name").GetString();
            observed["scalar_value"] = "__skip__";
            observed["want_rows"] = "__skip__";
            observed["affected_rows"] = "__skip__";
            observed["null_kind"] = "__skip__";
            return observed;
        });

        // case_1: the single-value variant returns the first column of the
        // first row, and a read requests rows.
        cases["case_1"] = Capture(() =>
        {
            const string responseJson = """
                {
                  "results": [
                    {
                      "type": "ok",
                      "response": {
                        "type": "execute",
                        "result": {
                          "cols": [ { "name": "value", "decltype": "INTEGER" } ],
                          "rows": [ [ { "type": "integer", "value": "123" } ] ],
                          "affected_row_count": 0,
                          "last_insert_rowid": null
                        }
                      }
                    },
                    { "type": "ok", "response": { "type": "close" } }
                  ]
                }
                """;

            using var server = new MockRemoteServer(responseJson);
            using var connection = new TursoConnection($"Data Source={server.Url}");
            connection.Open();

            using var command = connection.CreateCommand();
            command.CommandText = "SELECT $value";
            var p = command.CreateParameter();
            p.ParameterName = "$value";
            p.Value = 123;
            command.Parameters.Add(p);

            var scalar = command.ExecuteScalar();

            using var document = JsonDocument.Parse(server.RequestBody);
            var stmt = document.RootElement.GetProperty("requests")[0].GetProperty("stmt");

            var observed = new Dictionary<string, object?>
            {
                ["int_value"] = "__skip__",
                ["text_value"] = "__skip__",
                ["field_count"] = "__skip__",
                ["request_path"] = "__skip__",
                ["auth_header"] = "__skip__",
                ["arg0_value"] = "__skip__",
                ["named_arg_name"] = stmt.GetProperty("named_args")[0].GetProperty("name").GetString(),
                ["scalar_value"] = Convert.ToInt64(scalar),
                ["want_rows"] = stmt.GetProperty("want_rows").GetBoolean() ? "true" : "false",
                ["affected_rows"] = "__skip__",
                ["null_kind"] = "__skip__",
            };
            return observed;
        });

        // case_2: the no-result variant returns the affected-row count.
        cases["case_2"] = Capture(() =>
        {
            const string responseJson = """
                {
                  "results": [
                    {
                      "type": "ok",
                      "response": {
                        "type": "execute",
                        "result": {
                          "cols": [],
                          "rows": [],
                          "affected_row_count": 5,
                          "last_insert_rowid": null
                        }
                      }
                    },
                    { "type": "ok", "response": { "type": "close" } }
                  ]
                }
                """;

            using var server = new MockRemoteServer(responseJson);
            using var connection = new TursoConnection($"Data Source={server.Url}");
            connection.Open();

            using var command = connection.CreateCommand();
            command.CommandText = "DELETE FROM t";
            var affected = command.ExecuteNonQuery();

            return new Dictionary<string, object?>
            {
                ["int_value"] = "__skip__",
                ["text_value"] = "__skip__",
                ["field_count"] = "__skip__",
                ["request_path"] = "__skip__",
                ["auth_header"] = "__skip__",
                ["arg0_value"] = "__skip__",
                ["named_arg_name"] = "__skip__",
                ["scalar_value"] = "__skip__",
                ["want_rows"] = "__skip__",
                ["affected_rows"] = affected,
                ["null_kind"] = "__skip__",
            };
        });

        // case_3: a null column reads back as DBNull, not an empty string.
        cases["case_3"] = Capture(() =>
        {
            const string responseJson = """
                {
                  "results": [
                    {
                      "type": "ok",
                      "response": {
                        "type": "execute",
                        "result": {
                          "cols": [ { "name": "maybe", "decltype": "TEXT" } ],
                          "rows": [ [ { "type": "null" } ] ],
                          "affected_row_count": 0,
                          "last_insert_rowid": null
                        }
                      }
                    },
                    { "type": "ok", "response": { "type": "close" } }
                  ]
                }
                """;

            using var server = new MockRemoteServer(responseJson);
            using var connection = new TursoConnection($"Data Source={server.Url}");
            connection.Open();

            using var command = connection.CreateCommand();
            command.CommandText = "SELECT maybe FROM t";

            string nullKind;
            using (var reader = command.ExecuteReader())
            {
                reader.Read();
                nullKind = reader.IsDBNull(0) ? "DBNull" : $"not-null:{reader.GetValue(0)}";
            }

            return new Dictionary<string, object?>
            {
                ["int_value"] = "__skip__",
                ["text_value"] = "__skip__",
                ["field_count"] = "__skip__",
                ["request_path"] = "__skip__",
                ["auth_header"] = "__skip__",
                ["arg0_value"] = "__skip__",
                ["named_arg_name"] = "__skip__",
                ["scalar_value"] = "__skip__",
                ["want_rows"] = "__skip__",
                ["affected_rows"] = "__skip__",
                ["null_kind"] = nullKind,
            };
        });

        Emit(cases);
    }

    [Test]
    public void RemoteValidationStory()
    {
        var cases = new Dictionary<string, Dictionary<string, object?>>();

        // case_0: a loopback http URL with an auth token is a valid combination,
        // so the connection reaches the open state, and no native library is
        // required to get there.
        cases["case_0"] = Capture(() =>
        {
            using var connection = new TursoConnection("Data Source=http://localhost:8080;Auth Token=secret");
            connection.Open();
            var state = connection.State.ToString();
            connection.Close();
            return new Dictionary<string, object?>
            {
                ["opened"] = "true",
                ["state"] = state,
            };
        });

        // case_1: an embedded-replica remote connection does not reach the open
        // state (the option combination is refused).
        cases["case_1"] = CaptureReject(
            "Data Source=libsql://example.turso.io;Auth Token=secret;Replica Path=replica.db");

        // case_2: a TLS flag that contradicts the URL scheme does not open.
        cases["case_2"] = CaptureReject("Data Source=http://example.com:8080;Tls=True");

        // case_3: an auth token over a non-loopback cleartext URL does not open.
        cases["case_3"] = CaptureReject("Data Source=http://example.com;Auth Token=secret");

        // case_4: a local data source paired with a remote-only option does not open.
        cases["case_4"] = CaptureReject("Data Source=:memory:;Auth Token=secret");

        Emit(cases);
    }

    [Test]
    public void RemoteTransactionStory()
    {
        var cases = new Dictionary<string, Dictionary<string, object?>>();

        const string okExecuteBaton1 = """
            { "baton": "stream.1", "results": [ { "type": "ok", "response": {
              "type": "execute", "result": { "cols": [], "rows": [],
              "affected_row_count": 0, "last_insert_rowid": null } } } ] }
            """;
        const string okExecuteBaton2 = """
            { "baton": "stream.2", "results": [ { "type": "ok", "response": {
              "type": "execute", "result": { "cols": [], "rows": [],
              "affected_row_count": 0, "last_insert_rowid": null } } } ] }
            """;
        const string okExecuteBaton3 = """
            { "baton": "stream.3", "results": [ { "type": "ok", "response": {
              "type": "execute", "result": { "cols": [], "rows": [],
              "affected_row_count": 0, "last_insert_rowid": null } } } ] }
            """;
        const string closeResponse = """
            { "results": [ { "type": "ok", "response": { "type": "close" } } ] }
            """;
        const string errorBaton2 = """
            { "baton": "stream.2", "results": [ { "type": "error", "error": {
              "message": "no such table: missing", "code": "SQLITE_ERROR" } } ] }
            """;

        // case_0: begin then commit ride one continued session - the first
        // request opens the session without a carried baton, and a later
        // request echoes the baton the server returned on that first response.
        // (The number of round trips is left to the implementation; only the
        // observable baton continuity is recorded.)
        cases["case_0"] = Capture(() =>
        {
            using var server = new MockRemoteServer(okExecuteBaton1, okExecuteBaton2, closeResponse);
            using var connection = new TursoConnection($"Data Source={server.Url}");
            connection.Open();

            using var transaction = connection.BeginTransaction();
            transaction.Commit();

            return new Dictionary<string, object?>
            {
                ["opener_has_baton"] = FirstRequestHasBaton(server) ? "true" : "false",
                ["session_baton_continued"] = AnyRequestEchoesBaton(server, "stream.1") ? "true" : "false",
                ["error_baton_reused"] = "__skip__",
                ["final_state_is_open"] = "__skip__",
            };
        });

        // case_1: a SQL error returned while the transaction is open keeps the
        // session open so a follow-up rollback still targets it - a request
        // after the error echoes the baton the error response carried.
        cases["case_1"] = Capture(() =>
        {
            using var server = new MockRemoteServer(okExecuteBaton1, errorBaton2, okExecuteBaton3, closeResponse);
            using var connection = new TursoConnection($"Data Source={server.Url}");
            connection.Open();

            using var transaction = connection.BeginTransaction();
            using var command = connection.CreateCommand();
            command.Transaction = transaction;
            command.CommandText = "SELECT * FROM missing";
            try
            {
                command.ExecuteNonQuery();
            }
            catch
            {
                // The SQL error is expected; this case asserts the session
                // survives it, not the exception shape.
            }

            transaction.Rollback();

            return new Dictionary<string, object?>
            {
                ["opener_has_baton"] = "__skip__",
                ["session_baton_continued"] = "__skip__",
                ["error_baton_reused"] = AnyRequestEchoesBaton(server, "stream.2") ? "true" : "false",
                ["final_state_is_open"] = "__skip__",
            };
        });

        // case_2: a transport failure during the transaction invalidates the
        // whole connection rather than leaving a half-open session - the
        // connection must not remain in the open state afterwards. (Whether it
        // becomes closed or broken is left to the implementation.)
        cases["case_2"] = Capture(() =>
        {
            using var server = new MockRemoteServer(okExecuteBaton1, "not json");
            using var connection = new TursoConnection($"Data Source={server.Url}");
            connection.Open();

            using var transaction = connection.BeginTransaction();
            try
            {
                transaction.Commit();
            }
            catch
            {
                // The transport failure is expected; this case asserts the
                // connection is invalidated, not the exception shape.
            }

            return new Dictionary<string, object?>
            {
                ["opener_has_baton"] = "__skip__",
                ["session_baton_continued"] = "__skip__",
                ["error_baton_reused"] = "__skip__",
                ["final_state_is_open"] = connection.State == ConnectionState.Open ? "true" : "false",
            };
        });

        Emit(cases);
    }

    [Test]
    public void RemoteBatchStory()
    {
        var cases = new Dictionary<string, Dictionary<string, object?>>();

        // case_0: a batch serializes its commands into one request and each
        // command's result set is readable in turn.
        cases["case_0"] = Capture(() =>
        {
            const string responseJson = """
                {
                  "results": [
                    {
                      "type": "ok",
                      "response": {
                        "type": "batch",
                        "result": {
                          "step_results": [
                            {
                              "cols": [ { "name": "n", "decltype": "INTEGER" } ],
                              "rows": [ [ { "type": "integer", "value": "7" } ] ],
                              "affected_row_count": 0,
                              "last_insert_rowid": null
                            },
                            {
                              "cols": [],
                              "rows": [],
                              "affected_row_count": 2,
                              "last_insert_rowid": "3"
                            }
                          ],
                          "step_errors": [null, null]
                        }
                      }
                    },
                    { "type": "ok", "response": { "type": "close" } }
                  ]
                }
                """;

            using var server = new MockRemoteServer(responseJson);
            using var connection = new TursoConnection($"Data Source={server.Url}");
            connection.Open();

            using var batch = connection.CreateBatch();

            var select = batch.CreateBatchCommand();
            select.CommandText = "SELECT 7";
            batch.BatchCommands.Add(select);

            var insert = batch.CreateBatchCommand();
            insert.CommandText = "INSERT INTO t VALUES ('alice')";
            batch.BatchCommands.Add(insert);

            long firstStep;
            int recordsAffected;
            using (var reader = batch.ExecuteReader())
            {
                reader.Read();
                firstStep = reader.GetInt64(0);
                reader.NextResult();
                reader.Read();
                recordsAffected = reader.RecordsAffected;
            }

            using var document = JsonDocument.Parse(server.RequestBody);
            var requests = document.RootElement.GetProperty("requests");
            var steps = requests[0].GetProperty("batch").GetProperty("steps");

            return new Dictionary<string, object?>
            {
                ["first_step_value"] = firstStep,
                ["records_affected"] = recordsAffected,
                ["request_type"] = requests[0].GetProperty("type").GetString(),
                ["step_count"] = steps.GetArrayLength(),
                ["remote_can_create_batch"] = "__skip__",
                ["local_can_create_batch"] = "__skip__",
                ["step_error_surfaced"] = "__skip__",
            };
        });

        // case_1: batch creation is offered only on remote connections - a
        // remote connection advertises it, a local one does not.
        cases["case_1"] = Capture(() =>
        {
            using var remote = new TursoConnection("Data Source=https://example.turso.io");
            using var local = new TursoConnection("Data Source=:memory:");

            return new Dictionary<string, object?>
            {
                ["first_step_value"] = "__skip__",
                ["records_affected"] = "__skip__",
                ["request_type"] = "__skip__",
                ["step_count"] = "__skip__",
                ["remote_can_create_batch"] = remote.CanCreateBatch ? "true" : "false",
                ["local_can_create_batch"] = local.CanCreateBatch ? "true" : "false",
                ["step_error_surfaced"] = "__skip__",
            };
        });

        // case_2: a per-step server error is surfaced to the caller rather than
        // silently swallowed, and the server's error text reaches the caller.
        cases["case_2"] = Capture(() =>
        {
            const string responseJson = """
                {
                  "results": [
                    {
                      "type": "ok",
                      "response": {
                        "type": "batch",
                        "result": {
                          "step_results": [ null ],
                          "step_errors": [ { "message": "no such table: t", "code": "SQLITE_ERROR" } ]
                        }
                      }
                    },
                    { "type": "ok", "response": { "type": "close" } }
                  ]
                }
                """;

            using var server = new MockRemoteServer(responseJson);
            using var connection = new TursoConnection($"Data Source={server.Url}");
            connection.Open();

            using var batch = connection.CreateBatch();
            var cmd = batch.CreateBatchCommand();
            cmd.CommandText = "INSERT INTO t VALUES (1)";
            batch.BatchCommands.Add(cmd);

            var surfaced = "false";
            try
            {
                batch.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                surfaced = ex.Message.Contains("no such table: t") ? "true" : "raised-without-message";
            }

            return new Dictionary<string, object?>
            {
                ["first_step_value"] = "__skip__",
                ["records_affected"] = "__skip__",
                ["request_type"] = "__skip__",
                ["step_count"] = "__skip__",
                ["remote_can_create_batch"] = "__skip__",
                ["local_can_create_batch"] = "__skip__",
                ["step_error_surfaced"] = surfaced,
            };
        });

        Emit(cases);
    }

    // Runs one scenario and records its observed values, or the type name of
    // whatever error it raised so the runner can compare against the fixed
    // expected value instead of aborting the whole story.
    private static Dictionary<string, object?> Capture(Func<Dictionary<string, object?>> scenario)
    {
        try
        {
            return scenario();
        }
        catch (Exception ex)
        {
            return new Dictionary<string, object?> { ["error"] = ex.GetType().Name + ": " + ex.Message };
        }
    }

    // Whether the first request the server received opened the session without
    // carrying a baton (an opener has nothing to continue yet).
    private static bool FirstRequestHasBaton(MockRemoteServer server)
    {
        if (server.RequestBodies.Count == 0)
            return false;
        using var doc = JsonDocument.Parse(server.RequestBodies[0]);
        return doc.RootElement.TryGetProperty("baton", out var baton)
               && baton.ValueKind == JsonValueKind.String
               && !string.IsNullOrEmpty(baton.GetString());
    }

    // Whether any request the server received carried the given baton value,
    // i.e. the client continued the session the server established rather than
    // starting a fresh one. The number and ordering of requests is left to the
    // implementation; only the continuity is observed.
    private static bool AnyRequestEchoesBaton(MockRemoteServer server, string baton)
    {
        foreach (var body in server.RequestBodies)
        {
            using var doc = JsonDocument.Parse(body);
            if (doc.RootElement.TryGetProperty("baton", out var value)
                && value.ValueKind == JsonValueKind.String
                && value.GetString() == baton)
            {
                return true;
            }
        }

        return false;
    }

    // A validation scenario that is expected to reject an inconsistent option
    // combination: the connection must not reach the open state. Whether the
    // rejection fires at construction time or at open time, and the exact
    // exception shape, are left to the implementation, so only the observable
    // outcome (did it open) is recorded.
    private static Dictionary<string, object?> CaptureReject(string connectionString)
    {
        var observed = new Dictionary<string, object?>
        {
            ["opened"] = "false",
            ["state"] = "__skip__",
        };
        try
        {
            using var connection = new TursoConnection(connectionString);
            connection.Open();
            observed["opened"] = "true";
            observed["state"] = connection.State.ToString();
            connection.Close();
        }
        catch
        {
            observed["opened"] = "false";
        }
        return observed;
    }

    private static void Emit(Dictionary<string, Dictionary<string, object?>> cases)
    {
        var outPath = Environment.GetEnvironmentVariable("TURSO_VALIDATION_OUT");
        if (string.IsNullOrEmpty(outPath))
            throw new InvalidOperationException("TURSO_VALIDATION_OUT is not set.");

        var json = JsonSerializer.Serialize(cases, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(outPath, json);
    }

    // Loopback HTTP server that captures each request (method, path,
    // Authorization header, JSON body) and replies with a canned response.
    // Pure test scaffolding: it never touches the provider internals.
    private sealed class MockRemoteServer : IDisposable
    {
        private readonly CancellationTokenSource _cancellation = new();
        private readonly TcpListener _listener;
        private readonly Queue<string> _responseJson;
        private readonly Task _serverTask;

        public MockRemoteServer(params string[] responseJson)
        {
            _responseJson = new Queue<string>(responseJson);
            _listener = new TcpListener(IPAddress.Loopback, port: 0);
            _listener.Start();

            var endpoint = (IPEndPoint)_listener.LocalEndpoint;
            Url = new Uri($"http://127.0.0.1:{endpoint.Port}");
            _serverTask = Task.Run(AcceptLoopAsync);
        }

        public Uri Url { get; }

        public Uri? RequestUri { get; private set; }

        public string? Authorization { get; private set; }

        public string RequestBody { get; private set; } = "";

        public List<string> RequestBodies { get; } = new();

        public void Dispose()
        {
            _cancellation.Cancel();
            _listener.Stop();
            _cancellation.Dispose();
        }

        private async Task AcceptLoopAsync()
        {
            try
            {
                while (!_cancellation.IsCancellationRequested)
                {
                    using var client = await _listener.AcceptTcpClientAsync(_cancellation.Token);
                    await HandleClientAsync(client);
                }
            }
            catch (OperationCanceledException)
            {
            }
            catch (ObjectDisposedException)
            {
            }
        }

        private async Task HandleClientAsync(TcpClient client)
        {
            if (_responseJson.Count == 0)
                throw new InvalidOperationException("No canned HTTP response is available.");

            await using var stream = client.GetStream();
            using var reader = new StreamReader(stream, Encoding.ASCII, leaveOpen: true);

            var requestLine = await reader.ReadLineAsync()
                              ?? throw new InvalidOperationException("HTTP request did not include a request line.");
            var requestParts = requestLine.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (requestParts.Length < 2)
                throw new InvalidOperationException($"Invalid HTTP request line: {requestLine}");

            var contentLength = 0;
            while (await reader.ReadLineAsync() is { Length: > 0 } headerLine)
            {
                var separatorIndex = headerLine.IndexOf(':');
                if (separatorIndex < 0)
                    continue;

                var name = headerLine[..separatorIndex];
                var value = headerLine[(separatorIndex + 1)..].Trim();
                if (name.Equals("Content-Length", StringComparison.OrdinalIgnoreCase))
                    contentLength = int.Parse(value, System.Globalization.CultureInfo.InvariantCulture);
                else if (name.Equals("Authorization", StringComparison.OrdinalIgnoreCase))
                    Authorization = value;
                else if (name.Equals("Host", StringComparison.OrdinalIgnoreCase))
                    RequestUri = new Uri($"{Url.Scheme}://{value}{requestParts[1]}");
            }

            RequestUri ??= new Uri(Url, requestParts[1]);

            if (contentLength > 0)
            {
                var buffer = new char[contentLength];
                var read = 0;
                while (read < buffer.Length)
                {
                    var count = await reader.ReadAsync(buffer.AsMemory(read, buffer.Length - read));
                    if (count == 0)
                        break;

                    read += count;
                }

                RequestBody = new string(buffer, 0, read);
            }

            RequestBodies.Add(RequestBody);

            var body = Encoding.UTF8.GetBytes(_responseJson.Dequeue());
            var headers = Encoding.ASCII.GetBytes(
                $"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: {body.Length}\r\nConnection: close\r\n\r\n");
            await stream.WriteAsync(headers);
            await stream.WriteAsync(body);
        }
    }
}
