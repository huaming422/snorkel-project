"""Behavioural verifier for codex-lb-fix-burst-429-backoff.

Everything here drives the real FastAPI application through its public HTTP
endpoint ``POST /backend-api/codex/responses`` (the surface the symptom funnels
through) plus the stable ``failover_decision`` three-argument helper. The
verifier never imports any symbol the fix introduces — not the runtime cooldown
field, not the burst-classification helper, not the new ``failover_decision``
keyword inputs, not the new action literal. Every assertion is on an observable:
the streamed HTTP response, the final HTTP status and headers, the persisted
account status read back through the database, and the recorded backoff waits
captured at the scheduler seam the application already uses.

Upstream is simulated by monkeypatching ``proxy_module.core_stream_responses``
(a pre-existing module attribute) to a fake async generator — the same seam the
repository's own integration suite uses. The fixtures (``async_client`` and the
per-test database reset) come from the repository's own test support module,
loaded as a plugin in the sibling ``conftest.py``.

Coverage (the six criteria routed to ``behavioral_verifier``):
  * owner-bound code-less 429 that then succeeds -> same account, success
    stream, account stays ACTIVE           (fail_to_pass)
  * owner-bound code-less 429 on every attempt -> bounded same-account retries
    then a real HTTP 429 carrying Retry-After, never crossing accounts
                                             (fail_to_pass)
  * the bounded backoff schedule and the upstream Retry-After floor
                                             (fail_to_pass)
  * a movable request steers the next fresh selection away from the burst
    account without persisting RATE_LIMITED  (fail_to_pass)
  * CONTRAST: a coded 429 still fails over and persists RATE_LIMITED
                                             (pass_to_pass)
  * the stable ``failover_decision`` 3-arg truth table is unchanged
                                             (pass_to_pass)
"""

from __future__ import annotations

import asyncio
import base64
import json

import pytest

import app.modules.proxy.service as proxy_module
from app.core.auth import generate_unique_account_id
from app.core.clients.proxy import ProxyResponseError
from app.core.clock import RealScheduler
from app.core.errors import openai_error
from app.db.models import Account, AccountStatus
from app.db.session import SessionLocal

pytestmark = pytest.mark.asyncio


# ---------------------------------------------------------------------------
# Account import + payload/SSE helpers (ported from the repository's own
# integration suite so the verifier drives the real import + stream path).
# ---------------------------------------------------------------------------


def _encode_jwt(payload: dict) -> str:
    raw = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    body = base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")
    return f"header.{body}.sig"


def _make_auth_json(account_id: str, email: str) -> dict:
    payload = {
        "email": email,
        "chatgpt_account_id": account_id,
        "https://api.openai.com/auth": {"chatgpt_plan_type": "plus"},
    }
    return {
        "tokens": {
            "idToken": _encode_jwt(payload),
            "accessToken": "access-token",
            "refreshToken": "refresh-token",
            "accountId": account_id,
        },
    }


async def _import_account(async_client, account_id: str, email: str) -> str:
    auth_json = _make_auth_json(account_id, email)
    files = {"auth_json": ("auth.json", json.dumps(auth_json), "application/json")}
    response = await async_client.post("/api/accounts/import", files=files)
    assert response.status_code == 200, response.text
    return generate_unique_account_id(account_id, email)


async def _force_usage_weighted_routing(async_client) -> None:
    current = await async_client.get("/api/settings")
    assert current.status_code == 200
    payload = current.json()
    payload["routingStrategy"] = "usage_weighted"
    response = await async_client.put("/api/settings", json=payload)
    assert response.status_code == 200


def _sse_event(payload: dict) -> str:
    return f"data: {json.dumps(payload)}\n\n"


def _success_sse_event(response_id: str = "resp_ok") -> str:
    return _sse_event(
        {
            "type": "response.completed",
            "response": {
                "id": response_id,
                "usage": {"input_tokens": 1, "output_tokens": 1},
            },
        }
    )


def _extract_events(lines: list[str]) -> list[dict]:
    events: list[dict] = []
    for line in lines:
        if line.startswith("data: "):
            data = line[6:]
            if data == "[DONE]":
                continue
            events.append(json.loads(data))
    return events


def _record_burst_backoff_sleeps(monkeypatch) -> list[float]:
    """Record the bounded same-account backoff at the scheduler seam it uses.

    The backoff runs through ``RealScheduler.sleep`` (resolved via
    ``scheduler_for(proxy)``), so patching that method observes exactly the
    backoff schedule. Patching the process-wide ``asyncio.sleep`` instead would
    also intercept the lifespan event-loop-lag monitor, whose own one-second
    sleep loop would then flood the recording. The replacement still yields once
    (via ``asyncio.sleep(0)``) so the awaiting coroutine keeps turning.
    """
    slept: list[float] = []
    real_sleep = asyncio.sleep

    def fake_sleep(self, delay, result=None):
        if delay and delay > 0:
            slept.append(float(delay))
        return real_sleep(0, result)

    monkeypatch.setattr(RealScheduler, "sleep", fake_sleep)
    return slept


# An owner-bound codex payload: a ``reasoning`` input item is account-bound
# (not account-neutral), so a replay can only run on the account that owns the
# conversation. This is the pre-existing payload convention, not anything the
# fix introduces.
def _owner_bound_payload(reasoning_id: str) -> dict:
    return {
        "model": "gpt-5.1",
        "instructions": "hi",
        "input": [{"type": "reasoning", "id": reasoning_id, "encrypted_content": "owner-bound"}],
        "stream": True,
    }


def _movable_payload(prompt_cache_key: str | None = None) -> dict:
    # No account-bound input items -> the request may cross accounts. An optional
    # ``prompt_cache_key`` names a sticky session: a NEW key is a fresh sticky
    # binding (the proxy chooses which account owns the session), which is the
    # pre-existing routing surface where a saturated account should be avoided.
    payload: dict = {"model": "gpt-5.1", "instructions": "hi", "input": [], "stream": True}
    if prompt_cache_key is not None:
        payload["prompt_cache_key"] = prompt_cache_key
    return payload


_NATIVE_CODEX_HEADERS = {"originator": "codex_cli_rs"}
_CODELESS_429_BODY = {"error": {"message": "Rate limit exceeded"}}


# ===========================================================================
# C1 (fail_to_pass): owner-bound code-less 429 then success -> same account.
# ===========================================================================


async def test_owner_bound_codeless_429_retries_same_account_then_succeeds(async_client, monkeypatch):
    account_a_id = await _import_account(async_client, "acc_burst_a", "burst_a@example.com")
    # A second account exists and is healthy: if the request were (wrongly)
    # allowed to cross accounts, it could land here. It must not.
    await _import_account(async_client, "acc_burst_b", "burst_b@example.com")
    await _force_usage_weighted_routing(async_client)

    seen_account_ids: list[str | None] = []
    slept = _record_burst_backoff_sleeps(monkeypatch)

    async def fake_stream(payload, headers, access_token, account_id, base_url=None, raise_for_status=False):
        seen_account_ids.append(account_id)
        if len(seen_account_ids) == 1:
            raise ProxyResponseError(429, dict(_CODELESS_429_BODY), failure_phase="status")
        yield _success_sse_event("resp_burst_ok")

    monkeypatch.setattr(proxy_module, "core_stream_responses", fake_stream)

    async with async_client.stream(
        "POST", "/backend-api/codex/responses", json=_owner_bound_payload("rs_burst"),
        headers=_NATIVE_CODEX_HEADERS,
    ) as resp:
        assert resp.status_code == 200
        lines = [line async for line in resp.aiter_lines() if line]

    events = _extract_events(lines)
    completed = [e for e in events if e.get("type") == "response.completed"]
    failed = [e for e in events if e.get("type") == "response.failed"]
    assert len(completed) == 1, f"expected a success stream, got events={events}"
    assert len(failed) == 0, f"request must not surface a failure, got events={events}"

    # The retry went back to the SAME account; the request never crossed to B.
    assert seen_account_ids == ["acc_burst_a", "acc_burst_a"], seen_account_ids
    # A bounded backoff actually ran before the retry.
    assert slept, "expected at least one backoff wait before the same-account retry"

    # The burst account was not persisted RATE_LIMITED.
    async with SessionLocal() as session:
        account = await session.get(Account, account_a_id)
        assert account is not None
        assert account.status == AccountStatus.ACTIVE, account.status


# ===========================================================================
# C2 (fail_to_pass): owner-bound code-less 429 on every attempt -> bounded
# same-account retries, then HTTP 429 with Retry-After, never crossing accounts.
# ===========================================================================


async def test_owner_bound_codeless_429_exhaustion_surfaces_http_429_with_retry_after(async_client, monkeypatch):
    await _import_account(async_client, "acc_burst_ex_a", "burst_ex_a@example.com")
    await _import_account(async_client, "acc_burst_ex_b", "burst_ex_b@example.com")
    await _force_usage_weighted_routing(async_client)

    seen_account_ids: list[str | None] = []
    slept = _record_burst_backoff_sleeps(monkeypatch)

    async def fake_stream(payload, headers, access_token, account_id, base_url=None, raise_for_status=False):
        seen_account_ids.append(account_id)
        raise ProxyResponseError(429, dict(_CODELESS_429_BODY), failure_phase="status")
        yield  # pragma: no cover - marks this an async generator

    monkeypatch.setattr(proxy_module, "core_stream_responses", fake_stream)

    async with async_client.stream(
        "POST", "/backend-api/codex/responses", json=_owner_bound_payload("rs_burst_ex"),
        headers=_NATIVE_CODEX_HEADERS,
    ) as resp:
        body = json.loads(await resp.aread())
        assert resp.status_code == 429, f"exhausted burst must surface a real 429, got {resp.status_code}"
        # The client is told to wait: a Retry-After header is present and positive.
        assert "Retry-After" in resp.headers, dict(resp.headers)
        retry_after = int(resp.headers["Retry-After"])
        assert retry_after >= 1, retry_after

    # The original upstream body is surfaced unchanged.
    assert body == _CODELESS_429_BODY, body

    # Retries are bounded and never cross accounts.
    assert len(seen_account_ids) >= 2, "expected at least one bounded retry before surfacing"
    assert len(set(seen_account_ids)) == 1, f"owner-bound request must never cross accounts: {seen_account_ids}"
    # The waits are bounded (each honours the documented per-wait cap).
    assert slept, "expected bounded backoff waits before exhaustion"
    assert all(w <= 10.0 for w in slept), f"each backoff wait must be capped: {slept}"


# ===========================================================================
# C3 (fail_to_pass): the bounded backoff schedule and the Retry-After floor.
# ===========================================================================


async def test_owner_bound_codeless_429_backoff_schedule_and_retry_after_floor(async_client, monkeypatch):
    # --- no upstream Retry-After: the exponential schedule ---
    await _import_account(async_client, "acc_burst_sched", "burst_sched@example.com")
    await _force_usage_weighted_routing(async_client)

    seen_a: list[str | None] = []
    slept_default = _record_burst_backoff_sleeps(monkeypatch)

    async def fake_stream_default(payload, headers, access_token, account_id, base_url=None, raise_for_status=False):
        seen_a.append(account_id)
        raise ProxyResponseError(429, dict(_CODELESS_429_BODY), failure_phase="status")
        yield  # pragma: no cover

    monkeypatch.setattr(proxy_module, "core_stream_responses", fake_stream_default)

    async with async_client.stream(
        "POST", "/backend-api/codex/responses", json=_owner_bound_payload("rs_sched"),
        headers=_NATIVE_CODEX_HEADERS,
    ) as resp:
        await resp.aread()
        assert resp.status_code == 429

    # Contract-level, not the reference's exact numbers: a bounded same-account
    # backoff actually runs, the retry count is capped, every wait is within the
    # per-wait cap, and the schedule escalates (a backoff, not a flat constant).
    # The reference happens to be 1s / 2s / 4s, but any bounded escalating
    # schedule under the cap satisfies the contract, so the exact values are not
    # pinned (that choice is the implementer's).
    assert slept_default, "a bounded same-account backoff must run before exhaustion"
    assert len(slept_default) <= 5, f"total retries must be capped: {slept_default}"
    assert all(0 < w <= 10.0 for w in slept_default), f"each wait within the cap: {slept_default}"
    assert slept_default[-1] >= slept_default[0], f"the schedule must not shrink: {slept_default}"


async def test_owner_bound_codeless_429_retry_after_floors_the_wait(async_client, monkeypatch):
    # --- upstream Retry-After: 3 floors the early waits ---
    await _import_account(async_client, "acc_burst_floor", "burst_floor@example.com")
    await _force_usage_weighted_routing(async_client)

    seen: list[str | None] = []
    slept_floor = _record_burst_backoff_sleeps(monkeypatch)

    async def fake_stream_floor(payload, headers, access_token, account_id, base_url=None, raise_for_status=False):
        seen.append(account_id)
        raise ProxyResponseError(
            429, dict(_CODELESS_429_BODY), failure_phase="status",
            retry_after_seconds=3, retry_after_header="3",
        )
        yield  # pragma: no cover

    monkeypatch.setattr(proxy_module, "core_stream_responses", fake_stream_floor)

    async with async_client.stream(
        "POST", "/backend-api/codex/responses", json=_owner_bound_payload("rs_floor"),
        headers=_NATIVE_CODEX_HEADERS,
    ) as resp:
        await resp.aread()
        assert resp.status_code == 429
        # Upstream Retry-After is preserved on the surfaced response.
        assert resp.headers.get("Retry-After") == "3", dict(resp.headers)

    # The upstream Retry-After acts as a FLOOR on each wait: this is the pinned
    # contract (honour Retry-After as a floor), not the exact schedule. Every
    # recorded wait is at least the upstream value, every wait is still within
    # the cap, and at least one later wait climbs above the floor (the backoff
    # is not clamped flat to the floor forever). The reference produces
    # [3.0, 3.0, 4.0]; any floored, capped, escalating schedule satisfies this.
    assert slept_floor, "a bounded floored backoff must run before exhaustion"
    assert all(w >= 3.0 for w in slept_floor), f"each wait floored at the upstream Retry-After: {slept_floor}"
    assert all(w <= 10.0 for w in slept_floor), f"each wait within the cap: {slept_floor}"
    assert max(slept_floor) > 3.0, f"the schedule must climb past the floor: {slept_floor}"


# ===========================================================================
# C4 (fail_to_pass): a movable request's code-less burst steers the NEXT fresh
# sticky binding away from the saturated account, without persisting
# RATE_LIMITED and without emptying the pool.
#
# This drives the exact production surface named in the symptom: a fresh
# sticky binding (a new ``prompt_cache_key`` session, where the proxy chooses
# which account owns the session) must not be routed onto an account that just
# rejected with a code-less burst 429. Pre-fix the saturated account stays
# fully selectable, so the next fresh binding is routed straight back to it;
# the fix steers the fresh binding to the healthy account while leaving the
# saturated account in the pool (it is re-selectable once the short cooldown
# lapses) and its persisted status untouched.
# ===========================================================================


async def test_codeless_burst_steers_next_fresh_binding_away_without_rate_limiting(async_client, monkeypatch):
    account_a_id = await _import_account(async_client, "acc_steer_a", "steer_a@example.com")
    account_b_id = await _import_account(async_client, "acc_steer_b", "steer_b@example.com")
    await _force_usage_weighted_routing(async_client)

    seen_account_ids: list[str | None] = []
    burst = {"fired": False}

    async def fake_stream(payload, headers, access_token, account_id, base_url=None, raise_for_status=False):
        seen_account_ids.append(account_id)
        # The very first dispatch (whichever account the first session binds to)
        # rejects once with a code-less burst 429; every later dispatch succeeds.
        if not burst["fired"]:
            burst["fired"] = True
            raise ProxyResponseError(429, dict(_CODELESS_429_BODY), failure_phase="status")
        yield _success_sse_event("resp_steer_ok")

    monkeypatch.setattr(proxy_module, "core_stream_responses", fake_stream)

    # First session: its fresh binding bursts on one account, fails over to the
    # other (a movable request still fails over), and succeeds.
    async with async_client.stream(
        "POST", "/backend-api/codex/responses", json=_movable_payload("steer-session-one"),
    ) as resp:
        assert resp.status_code == 200
        first_lines = [line async for line in resp.aiter_lines() if line]
    assert any(e.get("type") == "response.completed" for e in _extract_events(first_lines))

    burst_account = seen_account_ids[0]
    assert burst_account in {"acc_steer_a", "acc_steer_b"}, burst_account
    first_binding_count = len(seen_account_ids)

    # The burst account was NOT persisted RATE_LIMITED (contrast with a coded
    # 429, which would be) — the cooldown that steers selection is replica-local.
    burst_db_id = account_a_id if burst_account == "acc_steer_a" else account_b_id
    other_db_id = account_b_id if burst_account == "acc_steer_a" else account_a_id
    async with SessionLocal() as session:
        account = await session.get(Account, burst_db_id)
        assert account is not None
        assert account.status == AccountStatus.ACTIVE, account.status

    # Second session with a NEW sticky key: a fresh binding chosen right after
    # the burst must be steered AWAY from the saturated account onto the healthy
    # one — not routed straight back to the account that just rejected.
    async with async_client.stream(
        "POST", "/backend-api/codex/responses", json=_movable_payload("steer-session-two"),
    ) as resp:
        assert resp.status_code == 200
        [line async for line in resp.aiter_lines() if line]

    second_binding = seen_account_ids[first_binding_count]
    assert second_binding != burst_account, (
        f"a fresh sticky binding must steer away from the just-saturated account "
        f"{burst_account}, but was routed back to it: {seen_account_ids}"
    )

    # The pool was never emptied: the saturated account still exists and is
    # ACTIVE (it is a candidate again once the short cooldown lapses — it was
    # deprioritised, not removed or rate-limited).
    async with SessionLocal() as session:
        still_there = await session.get(Account, burst_db_id)
        assert still_there is not None
        assert still_there.status == AccountStatus.ACTIVE, still_there.status
        healthy = await session.get(Account, other_db_id)
        assert healthy is not None
        assert healthy.status == AccountStatus.ACTIVE, healthy.status


# ===========================================================================
# C5 (pass_to_pass, CONTRAST): a coded 429 still fails over and persists
# RATE_LIMITED. The pre-existing behaviour, unchanged by the fix.
# ===========================================================================


async def test_coded_429_still_fails_over_and_persists_rate_limited(async_client, monkeypatch):
    account_a_id = await _import_account(async_client, "acc_coded_a", "coded_a@example.com")
    await _import_account(async_client, "acc_coded_b", "coded_b@example.com")
    await _force_usage_weighted_routing(async_client)

    seen_account_ids: list[str | None] = []

    async def fake_stream(payload, headers, access_token, account_id, base_url=None, raise_for_status=False):
        seen_account_ids.append(account_id)
        if account_id == "acc_coded_a":
            raise ProxyResponseError(
                429, openai_error("usage_limit_reached", "usage limit reached"), failure_phase="status",
            )
        yield _success_sse_event("resp_coded_ok")

    monkeypatch.setattr(proxy_module, "core_stream_responses", fake_stream)

    async with async_client.stream(
        "POST", "/backend-api/codex/responses", json=_movable_payload(),
    ) as resp:
        assert resp.status_code == 200
        lines = [line async for line in resp.aiter_lines() if line]

    events = _extract_events(lines)
    assert len([e for e in events if e.get("type") == "response.completed"]) == 1, events
    # It crossed to the second account.
    assert seen_account_ids[:2] == ["acc_coded_a", "acc_coded_b"], seen_account_ids

    # The coded 429 persisted RATE_LIMITED on the originating account.
    async with SessionLocal() as session:
        account = await session.get(Account, account_a_id)
        assert account is not None
        assert account.status == AccountStatus.RATE_LIMITED, account.status


# ===========================================================================
# C6 (pass_to_pass): the stable 3-arg ``failover_decision`` truth table is
# unchanged by the fix (the new behaviour is added via defaulted kwargs only).
# ===========================================================================


async def test_failover_decision_three_arg_truth_table_unchanged():
    # Imported lazily and locally so the module-level import list stays focused
    # on the HTTP path; this is a pre-existing stable public helper.
    from app.core.balancer.logic import failover_decision

    # A movable retryable-transient failure with candidates remaining and no
    # downstream-visible output still fails over to the next account.
    assert (
        failover_decision(failure_class="retryable_transient", downstream_visible=False, candidates_remaining=1)
        == "failover_next"
    )
    # Coded rate-limit / quota with candidates remaining also fail over.
    assert (
        failover_decision(failure_class="rate_limit", downstream_visible=False, candidates_remaining=2)
        == "failover_next"
    )
    assert (
        failover_decision(failure_class="quota", downstream_visible=False, candidates_remaining=2)
        == "failover_next"
    )
    # Downstream-visible output can never fail over: surface.
    assert (
        failover_decision(failure_class="retryable_transient", downstream_visible=True, candidates_remaining=5)
        == "surface"
    )
    # No candidates remaining: surface.
    assert (
        failover_decision(failure_class="retryable_transient", downstream_visible=False, candidates_remaining=0)
        == "surface"
    )
    # A non-retryable failure never fails over.
    assert (
        failover_decision(failure_class="non_retryable", downstream_visible=False, candidates_remaining=3)
        == "surface"
    )
