"""Test harness for mcap-feat-remote-scan-opt-in.

This task uses the subprocess driver: each story shells out to the prebuilt
`mcap` CLI binary and asserts on exit code + combined stdout/stderr, so there is
no shared Python state to speak of. This module exists to hold the two pieces of
test infrastructure every remote story needs:

  * the path to the built `mcap` binary and the staged-fixture root, and
  * a local HTTP server that honours byte-range requests, so a story can serve a
    real (or crafted) `.mcap` blob at a `http://127.0.0.1:<port>/...` URL and
    drive the CLI's remote-input path against it.

The HTTP server is a pure test fixture: the CLI reads it, nothing in the
solution defines or depends on its shape, so the harness owns it outright. It
advertises `Accept-Ranges: bytes`, answers a `Range: bytes=a-b` request with a
`206 Partial Content` + `Content-Range: bytes a-b/total`, and answers a
range-less request with a `200 OK` full body, the contract the CLI's range
reader probes for (a `bytes=0-0` probe returns `206` + the total size).

The server also counts the body bytes it sends, starting from zero for each
`serve_dir()`, so a story can tell a command that was refused up front from one
that downloaded the file first (`served_bytes(base)`, compared with
`probe_allowance(path)`).

`mcap_messages(path)` reads the messages of an MCAP file whose chunks are
uncompressed, in pure Python, so a story can check what a command wrote without
trusting the binary under test.

Stories import `MCAP_BIN`, `FIXTURES_ROOT`, `fixture_path`, `merged_env`,
`serve_dir`, `served_bytes`, `probe_allowance` and `mcap_messages` from here. The opt-in flag's spelling is NOT
defined here: it is the implementation's choice, so each story discovers it
(see validation_spec.toml's instructions).
"""

from __future__ import annotations

import contextlib
import http.server
import os
import re
import struct
import threading
import urllib.parse
from typing import Iterator


# The prebuilt mcap binary that validation-setup.sh (re)builds from the agent's
# edits. The crate's target dir is redirected to /opt/cache/cargo-target by the
# image, with a fallback to the in-tree target/ path.
def _resolve_mcap_bin() -> str:
    candidates = [
        "/opt/cache/cargo-target/debug/mcap",
        "/repo/mcap/rust/target/debug/mcap",
        "/repo/mcap/rust/cli/target/debug/mcap",
    ]
    for c in candidates:
        if os.path.isfile(c) and os.access(c, os.X_OK):
            return c
    # Fall back to the first candidate; validation-setup.sh guarantees it
    # exists, and a clear FileNotFound at subprocess time beats a silent "".
    return candidates[0]


MCAP_BIN: str = _resolve_mcap_bin()

# Root of staged fixtures (real repo fixtures + crafted blobs). Created by
# validation-setup.sh.
FIXTURES_ROOT: str = "/tmp/mcap_fixtures"


def fixture_path(name: str) -> str:
    """Absolute path to a staged fixture file under FIXTURES_ROOT."""
    return os.path.join(FIXTURES_ROOT, name)


def merged_env() -> dict:
    """os.environ with the image's Rust toolchain paths defaulted in.

    The binary itself needs no special env, but defaulting the toolchain paths
    keeps a story robust if it ever shells out to cargo for a sanity check.
    """
    env = {**os.environ}
    env.setdefault("CARGO_HOME", "/opt/cargo")
    env.setdefault("RUSTUP_HOME", "/opt/rustup")
    env["PATH"] = f"{env['CARGO_HOME']}/bin:" + env.get("PATH", "")
    return env


# Body bytes sent by each running server, keyed by its port.
_SERVED: dict[int, int] = {}
_SERVED_LOCK = threading.Lock()


def served_bytes(base: str) -> int:
    """Total body bytes the server at ``base`` (as yielded by ``serve_dir``) has sent."""
    port = int(base.rsplit(":", 1)[1])
    with _SERVED_LOCK:
        return _SERVED.get(port, 0)


def _count(port: int, n: int) -> None:
    with _SERVED_LOCK:
        _SERVED[port] = _SERVED.get(port, 0) + n


class _RangeRequestHandler(http.server.BaseHTTPRequestHandler):
    """Serve files from ``self.server.root`` with HTTP byte-range support."""

    # Silence per-request logging so story stdout stays clean.
    def log_message(self, *args) -> None:  # noqa: D401, ANN002
        return

    def _resolve(self) -> str | None:
        parsed = urllib.parse.urlparse(self.path)
        rel = urllib.parse.unquote(parsed.path).lstrip("/")
        root = os.path.abspath(self.server.root)  # type: ignore[attr-defined]
        full = os.path.abspath(os.path.join(root, rel))
        if not (full == root or full.startswith(root + os.sep)):
            return None
        return full if os.path.isfile(full) else None

    def do_GET(self) -> None:  # noqa: N802
        path = self._resolve()
        if path is None:
            self.send_error(404, "not found")
            return
        total = os.path.getsize(path)

        rng = self.headers.get("Range")
        if rng:
            m = re.match(r"\s*bytes=(\d+)-(\d*)\s*$", rng)
            if m:
                start = int(m.group(1))
                end = int(m.group(2)) if m.group(2) else total - 1
                if end > total - 1:
                    end = total - 1
                if start > end or start >= total:
                    self.send_response(416)
                    self.send_header("Content-Range", f"bytes */{total}")
                    self.send_header("Connection", "close")
                    self.end_headers()
                    return
                length = end - start + 1
                # Read only the requested window so a large (possibly sparse)
                # fixture never has to be slurped whole into memory.
                with open(path, "rb") as fh:
                    fh.seek(start)
                    chunk = fh.read(length)
                self.send_response(206)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Accept-Ranges", "bytes")
                self.send_header("Content-Range", f"bytes {start}-{end}/{total}")
                self.send_header("Content-Length", str(len(chunk)))
                self.send_header("Connection", "close")
                self.end_headers()
                self.wfile.write(chunk)
                _count(self.server.server_address[1], len(chunk))
                return

        # Range-less request: full body, but still advertise range support.
        with open(path, "rb") as fh:
            data = fh.read()
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(total))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(data)
        _count(self.server.server_address[1], len(data))


@contextlib.contextmanager
def serve_dir(root: str = FIXTURES_ROOT) -> Iterator[str]:
    """Serve ``root`` over a range-capable HTTP server on 127.0.0.1.

    Yields the base URL (``http://127.0.0.1:<port>``). Build a per-file URL as
    ``f"{base}/{name}"`` and optionally append a ``?query`` string. The server
    runs on a background daemon thread and is shut down on context exit.
    """
    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _RangeRequestHandler)
    server.root = os.path.abspath(root)  # type: ignore[attr-defined]
    # A reused port starts from zero, so earlier traffic never counts here.
    with _SERVED_LOCK:
        _SERVED[server.server_address[1]] = 0
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        host, port = server.server_address[0], server.server_address[1]
        yield f"http://{host}:{port}"
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)


_MAGIC = bytes([0x89, 0x4D, 0x43, 0x41, 0x50, 0x30, 0x0D, 0x0A])


def _records(buf: bytes, pos: int, end: int) -> Iterator[tuple[int, bytes]]:
    while pos + 9 <= end:
        op = buf[pos]
        (length,) = struct.unpack_from("<Q", buf, pos + 1)
        body = buf[pos + 9 : pos + 9 + length]
        yield op, body
        pos += 9 + length


def _string(body: bytes, pos: int) -> tuple[str, int]:
    (n,) = struct.unpack_from("<I", body, pos)
    return body[pos + 4 : pos + 4 + n].decode(), pos + 4 + n


def mcap_messages(path: str) -> list[tuple[str, int, bytes]]:
    """Every message in an MCAP file as ``(topic, log_time, data)``, in file order.

    Reads the data section only, descending into chunks. Raises ValueError on a
    compressed chunk, so write outputs with no chunk compression before reading
    them back.
    """
    with open(path, "rb") as fh:
        buf = fh.read()
    if buf[:8] != _MAGIC:
        raise ValueError(f"{path} is not an MCAP file")
    topics: dict[int, str] = {}
    out: list[tuple[str, int, bytes]] = []

    def visit(op: int, body: bytes) -> None:
        if op == 0x04:  # Channel
            (cid,) = struct.unpack_from("<H", body, 0)
            topic, _ = _string(body, 4)
            topics[cid] = topic
        elif op == 0x05:  # Message
            cid, _seq, log_time, _pub = struct.unpack_from("<HIQQ", body, 0)
            out.append((topics[cid], log_time, body[22:]))
        elif op == 0x06:  # Chunk
            compression, pos = _string(body, 28)
            (size,) = struct.unpack_from("<Q", body, pos)
            if compression:
                raise ValueError(f"{path} has {compression!r} chunks")
            inner = body[pos + 8 : pos + 8 + size]
            for iop, ibody in _records(inner, 0, len(inner)):
                visit(iop, ibody)

    for op, body in _records(buf, 8, len(buf) - 8):
        if op == 0x02:  # Footer: the summary section starts here
            break
        visit(op, body)
    return out


def probe_allowance(path: str) -> int:
    """Body bytes a remote command may read from ``path`` before refusing.

    That is the trailing summary section, footer and magic of an MCAP file (or
    nothing for any other file), plus 64 bytes for a size or magic probe.
    Anything past this means the command started downloading the file body.
    """
    size = os.path.getsize(path)
    with open(path, "rb") as fh:
        head = fh.read(8)
        fh.seek(max(size - 37, 0))
        tail = fh.read(37)
    if head != _MAGIC or len(tail) != 37 or tail[0] != 0x02 or tail[-8:] != _MAGIC:
        return 64
    (summary_start,) = struct.unpack_from("<Q", tail, 9)
    start = summary_start if summary_start else size - 37
    return size - start + 64
