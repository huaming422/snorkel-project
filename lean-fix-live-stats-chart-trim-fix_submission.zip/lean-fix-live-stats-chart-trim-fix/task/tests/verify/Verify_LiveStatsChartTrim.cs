/*
 * Behavioral checks for the live result handler's periodic chart maintenance.
 *
 * The core check drives a long live session through the pre-existing public
 * Sample path, runs the pre-existing private periodic-maintenance entry point
 * (Update) by reflection, and then reads the public StatisticsResults() surface
 * — the exact thing that reads 0% in the symptom report — to confirm the live
 * risk statistics stay computable. It never references any member the fix may or
 * may not introduce; it goes through Sample + Update + StatisticsResults + the
 * pre-existing private _next* schedule fields, all of which exist before the fix.
 * Driving history through Sample (rather than hand-appending chart points) means
 * any design that keeps the statistics correct — retaining the history inside the
 * chart series, down-sampling it, or holding it in a separate buffer — is scored
 * the same way: by whether StatisticsResults() stays non-zero over a long run.
 *
 * The two regression checks confirm the pre-existing behavior the fix must not
 * disturb: ordinary (non-statistics) chart series are still trimmed to the short
 * recent window, and a second maintenance pass is a no-op.
 *
 * Important: the maintenance reassigns each series' Values list to a freshly
 * built list, so any list reference captured before the pass is stale after it.
 * Every assertion re-reads the list from Charts AFTER the pass via Points().
 */

using System;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using NUnit.Framework;
using QuantConnect.Packets;
using QuantConnect.Interfaces;
using QuantConnect.Algorithm;
using QuantConnect.Statistics;
using QuantConnect.Securities;
using QuantConnect.Data.UniverseSelection;
using QuantConnect.Lean.Engine.Results;
using QuantConnect.Lean.Engine.DataFeeds;
using QuantConnect.Tests.Engine.DataFeeds;
using QuantConnect.Lean.Engine.TransactionHandlers;
using QuantConnect.Tests.Common.Data.UniverseSelection;

namespace QuantConnect.Tests.Engine.Results
{
    [TestFixture]
    public class Verify_LiveStatsChartTrim
    {
        private const BindingFlags Flags = BindingFlags.NonPublic | BindingFlags.Instance;

        // A subclass that neutralizes the background maintenance thread (its loop
        // body is a pre-existing protected method) so the test can drive the
        // periodic maintenance deterministically rather than racing a timer.
        private class QuietHandler : LiveTradingResultHandler
        {
            protected override void Run()
            {
                // Intentionally idle: the test invokes the maintenance pass directly.
            }
        }

        private static void SetField(LiveTradingResultHandler handler, string name, object value)
        {
            var field = typeof(LiveTradingResultHandler).GetField(name, Flags);
            Assert.IsNotNull(field, $"Expected pre-existing field {name} on the live result handler.");
            field.SetValue(handler, value);
        }

        private static DateTime GetDateField(LiveTradingResultHandler handler, string name)
        {
            var field = typeof(LiveTradingResultHandler).GetField(name, Flags);
            Assert.IsNotNull(field, $"Expected pre-existing field {name} on the live result handler.");
            return (DateTime)field.GetValue(handler);
        }

        // Builds a fully-initialized live result handler with a locked stub
        // algorithm, mirroring the existing LiveTradingResultHandlerTests setup.
        // The stub algorithm is handed back so a test can move the portfolio value
        // between samples and produce a real performance series.
        private static QuietHandler BuildHandler(out IDisposable[] disposables, out QCAlgorithm algorithm)
        {
            var api = new Api.Api();
            var messaging = new QuantConnect.Messaging.Messaging();
            disposables = new IDisposable[] { api, messaging };

            var handler = new QuietHandler();
            handler.Initialize(new(new LiveNodePacket(), messaging, api, new BacktestingTransactionHandler(), null));

            var algo = new AlgorithmStub(createDataManager: false);
            algo.SetFinishedWarmingUp();
            var dataManager = new DataManagerStub(new NoopDataFeed(), algo);
            algo.SubscriptionManager.SetDataManager(dataManager);
            // extendedMarketHours makes the live handler sample on every call rather
            // than only during the equity's regular session, so a test can seed a
            // dense daily history deterministically regardless of wall-clock date.
            var aapl = algo.AddEquity("AAPL", extendedMarketHours: true);
            // Risk-statistic generation needs the trading-days-per-year setting; it is
            // normally set by the setup handler. Without it, statistics generation
            // throws internally and returns an empty result regardless of history.
            algo.Settings.TradingDaysPerYear = 252;
            algo.PostInitialize();
            handler.SetAlgorithm(algo, 100000);
            handler.OnSecuritiesChanged(SecurityChangesTests.AddedNonInternal(aapl));

            // The maintenance loop only runs for a locked (fully-initialized) algorithm.
            algo.SetLocked();
            algorithm = algo;
            return handler;
        }

        // Drives one daily sample through the public Sample path after moving the
        // portfolio value, so equity/return/benchmark accumulate a real series.
        private static void SampleDay(LiveTradingResultHandler handler, QCAlgorithm algo, DateTime time, decimal cashDelta)
        {
            algo.Portfolio.CashBook["USD"].AddAmount(cashDelta);
            algo.Portfolio.InvalidateTotalPortfolioValue();
            algo.SetDateTime(time);
            handler.Sample(time);
        }

        // Runs exactly one periodic-maintenance pass with only the chart-maintenance
        // branch due, then confirms that branch actually executed.
        private static void DriveMaintenance(LiveTradingResultHandler handler)
        {
            var now = DateTime.UtcNow;

            // Enter the maintenance body; keep the date bookkeeping branch quiet.
            SetField(handler, "_nextUpdate", now.AddHours(-1));
            SetField(handler, "_currentUtcDate", now.Date);

            // Push every other periodic branch into the future so only the
            // chart-maintenance branch fires this pass (avoids the heavy storage
            // and remote-API branches).
            foreach (var name in new[]
            {
                "_nextChartsUpdate", "_nextLogStoreUpdate", "_nextStatisticsUpdate",
                "_nextStatusUpdate", "_nextInsightStoreUpdate"
            })
            {
                SetField(handler, name, now.AddYears(1));
            }

            // Make the chart-maintenance branch due now.
            SetField(handler, "_nextChartTrimming", now.AddHours(-1));

            var update = typeof(LiveTradingResultHandler).GetMethod("Update", Flags);
            Assert.IsNotNull(update, "Expected pre-existing private Update() on the live result handler.");
            update.Invoke(handler, null);

            // The maintenance body swallows its own exceptions, so an early failure
            // would silently skip the chart-maintenance branch and leave the series
            // untouched. The branch reschedules its own next run on completion; use
            // that reschedule as proof the branch actually ran this pass.
            Assert.Greater(GetDateField(handler, "_nextChartTrimming"), now.AddMinutes(5),
                "The periodic chart-maintenance branch did not run this pass.");
        }

        // Always re-reads the current Values list from Charts (the maintenance
        // reassigns it, so a reference captured earlier would be stale).
        private static List<ISeriesPoint> Points(LiveTradingResultHandler handler, string chartKey, string seriesKey)
        {
            Assert.IsTrue(handler.Charts.ContainsKey(chartKey), $"Missing chart {chartKey}.");
            Assert.IsTrue(handler.Charts[chartKey].Series.ContainsKey(seriesKey), $"Missing series {seriesKey}.");
            return handler.Charts[chartKey].Series[seriesKey].Values;
        }

        private static void Dispose(IDisposable[] disposables, LiveTradingResultHandler handler)
        {
            try { handler.Exit(); } catch { /* best effort */ }
            foreach (var d in disposables)
            {
                try { d.Dispose(); } catch { /* best effort */ }
            }
        }

        [Test]
        public void LiveStatisticsStayComputableOverALongSession()
        {
            var handler = BuildHandler(out var disposables, out var algo);
            try
            {
                var now = DateTime.UtcNow;

                // Sample a daily session going back well beyond the short recent
                // window, moving the portfolio value each day so the equity/return
                // path has real variance (otherwise every risk metric is trivially
                // zero regardless of the trim). Stays within the last ~2 years so a
                // design that caps retained history at two years keeps all of it.
                var deltas = new[] { 1500m, -800m, 2200m, -500m, 1800m, -1200m, 2600m };
                var step = 0;
                for (var day = 400; day >= 3; day -= 2)
                {
                    SampleDay(handler, algo, now.AddDays(-day), deltas[step % deltas.Length]);
                    step++;
                }
                // A couple of samples inside the recent window so every design has a
                // populated recent region; the discriminating signal is the depth of
                // history behind it, not whether the recent window exists.
                SampleDay(handler, algo, now.AddHours(-5), 1300m);
                SampleDay(handler, algo, now.AddHours(-1), -900m);

                // Sanity: before any trim the statistics are non-zero. If this fails
                // the seeding did not produce a real performance series and the test
                // below would be vacuous.
                var statsBefore = handler.StatisticsResults();
                Assert.AreNotEqual(0m, statsBefore.TotalPerformance.PortfolioStatistics.AnnualStandardDeviation,
                    "Precondition: the seeded session did not produce a non-zero statistics baseline.");

                DriveMaintenance(handler);

                // After the periodic maintenance has run over a long session, the
                // live risk statistics must still be computed from the retained
                // history rather than collapsing to zero. This is the symptom the
                // ticket reports: the probabilistic Sharpe ratio and the other
                // equity/return/benchmark-derived metrics read 0%.
                var statsAfter = handler.StatisticsResults();
                var stats = statsAfter.TotalPerformance.PortfolioStatistics;

                Assert.AreNotEqual(0m, stats.AnnualStandardDeviation,
                    "The live risk statistics lost their history after maintenance: "
                    + "annual standard deviation collapsed to zero.");
                Assert.AreNotEqual(0m, stats.ProbabilisticSharpeRatio,
                    "The probabilistic Sharpe ratio collapsed to zero after a long session.");
            }
            finally
            {
                Dispose(disposables, handler);
            }
        }

        [Test]
        public void RetainedStatisticsHistoryIsMemoryBounded()
        {
            var handler = BuildHandler(out var disposables, out var algo);
            try
            {
                var now = DateTime.UtcNow;

                // Seed a long session whose OLD region (behind the short recent
                // window) carries many intraday samples per calendar day. A design
                // that keeps the statistics correct simply by never trimming the
                // statistics series retains every one of these intraday points, so
                // its retained history grows without bound as the session ages. A
                // design that bounds memory — down-sampling the old region to a
                // coarse (e.g. daily) resolution, capping the retained count, or
                // holding the history in a separate bounded store while the chart
                // series stay trimmed — retains dramatically fewer.
                var deltas = new[] { 1500m, -800m, 2200m, -500m, 1800m, -1200m, 2600m, -1600m };
                var step = 0;
                const int oldestDay = 134;
                const int newestOldDay = 5;     // well behind the ~2-day recent window
                const int intradayPerDay = 24;  // dense intraday sampling per calendar day
                var seededOldDays = 0;
                for (var day = oldestDay; day >= newestOldDay; day--)
                {
                    // Anchor every intraday sample of a day on the same calendar
                    // date (09:00 + a few minutes) so a per-day down-sample collapses
                    // them into one point; the whole span stays inside ~2 years.
                    var dayStart = now.Date.AddDays(-day).AddHours(9);
                    for (var i = 0; i < intradayPerDay; i++)
                    {
                        SampleDay(handler, algo, dayStart.AddMinutes(2 * i), deltas[step % deltas.Length]);
                        step++;
                    }
                    seededOldDays++;
                }

                // A populated recent window (last ~2 days) so every design keeps
                // full-resolution recent history; the discriminating signal is the
                // depth retained BEHIND this window, not the window itself.
                SampleDay(handler, algo, now.AddHours(-30), 1300m);
                SampleDay(handler, algo, now.AddHours(-5), -900m);
                SampleDay(handler, algo, now.AddHours(-1), 1700m);

                DriveMaintenance(handler);

                // A memory-bounded design must still stay correct, not trade
                // correctness for small memory: the live risk statistics are still
                // computed after maintenance over the long session.
                var stats = handler.StatisticsResults().TotalPerformance.PortfolioStatistics;
                Assert.AreNotEqual(0m, stats.AnnualStandardDeviation,
                    "The live risk statistics collapsed to zero after maintenance over a long session.");

                // Count the history retained in each statistics series BEHIND the
                // recent window. Full intraday retention over the seeded span is
                // ~seededOldDays * intradayPerDay points; any memory-bounded shape
                // retains far fewer — roughly one point per day when down-sampled, a
                // capped count, or none when the history lives in a separate store.
                // The cap is deliberately generous: an order of magnitude above a
                // daily down-sample and well below unbounded intraday retention, so
                // it accepts every bounded design and pins no specific algorithm.
                var oldRegionBoundary = now.AddDays(-3);
                var fullIntradayRetention = seededOldDays * intradayPerDay; // ~3120
                const int memoryCap = 1500;

                foreach (var (chartKey, seriesKey) in new[]
                {
                    (BaseResultsHandler.StrategyEquityKey, BaseResultsHandler.EquityKey),
                    (BaseResultsHandler.StrategyEquityKey, BaseResultsHandler.ReturnKey),
                    (BaseResultsHandler.BenchmarkKey, BaseResultsHandler.BenchmarkKey),
                })
                {
                    var retainedOld = Points(handler, chartKey, seriesKey)
                        .Count(p => p.Time < oldRegionBoundary);
                    Assert.Less(retainedOld, memoryCap,
                        $"The statistics series {chartKey}->{seriesKey} retained {retainedOld} points "
                        + $"behind the recent window out of ~{fullIntradayRetention} seeded; the retained "
                        + "statistics history is not memory-bounded over a long-running session.");
                }
            }
            finally
            {
                Dispose(disposables, handler);
            }
        }

        [Test]
        public void NonStatisticsSeriesTrimmedToRecentWindow()
        {
            var handler = BuildHandler(out var disposables, out _);
            try
            {
                var now = DateTime.UtcNow;

                var chart = new Chart("CustomDiagnostics");
                chart.Series.Add("CustomMetric", new Series("CustomMetric", SeriesType.Line, 0));
                handler.Charts["CustomDiagnostics"] = chart;
                var custom = Points(handler, "CustomDiagnostics", "CustomMetric");

                // Points spanning ~10 days back; only those within the recent
                // window (~2 days) should survive.
                for (var day = 10; day >= 3; day--)
                {
                    custom.Add(new ChartPoint(now.AddDays(-day), day));
                }
                custom.Add(new ChartPoint(now.AddHours(-1), 0));

                DriveMaintenance(handler);

                custom = Points(handler, "CustomDiagnostics", "CustomMetric");

                var olderThanAWeek = now.AddDays(-7);
                Assert.IsFalse(custom.Any(v => v.Time < olderThanAWeek),
                    "A non-statistics series kept points from more than a week ago.");
                Assert.IsTrue(custom.Any(v => v.Time > now.AddHours(-2)),
                    "A non-statistics series dropped its most recent point.");
            }
            finally
            {
                Dispose(disposables, handler);
            }
        }

        [Test]
        public void RepeatedMaintenanceIsIdempotent()
        {
            var handler = BuildHandler(out var disposables, out var algo);
            try
            {
                var now = DateTime.UtcNow;

                // Seed a long daily session through the public Sample path.
                var deltas = new[] { 1500m, -800m, 2200m, -500m, 1800m };
                var step = 0;
                for (var day = 60; day >= 3; day--)
                {
                    SampleDay(handler, algo, now.AddDays(-day), deltas[step % deltas.Length]);
                    step++;
                }
                SampleDay(handler, algo, now.AddHours(-1), 1000m);

                DriveMaintenance(handler);

                // Snapshot the statistics series the handler reports after the first
                // pass, reading them through the public StatisticsResults() surface.
                var firstPass = Describe(handler.StatisticsResults());

                DriveMaintenance(handler);

                var secondPass = Describe(handler.StatisticsResults());

                Assert.AreEqual(firstPass, secondPass,
                    "A second maintenance pass changed the live statistics.");
            }
            finally
            {
                Dispose(disposables, handler);
            }
        }

        // A stable string describing the risk statistics, used to compare two
        // maintenance passes without depending on any internal representation.
        private static string Describe(StatisticsResults results)
        {
            var s = results.TotalPerformance.PortfolioStatistics;
            return string.Join("|",
                s.ProbabilisticSharpeRatio,
                s.SharpeRatio,
                s.AnnualStandardDeviation,
                s.AnnualVariance,
                s.ValueAtRisk99);
        }

        private class NoopDataFeed : IDataFeed
        {
            public bool IsActive { get; }

            public void Initialize(
                IAlgorithm algorithm,
                AlgorithmNodePacket job,
                IResultHandler resultHandler,
                IMapFileProvider mapFileProvider,
                IFactorFileProvider factorFileProvider,
                IDataProvider dataProvider,
                IDataFeedSubscriptionManager subscriptionManager,
                IDataFeedTimeProvider dataFeedTimeProvider,
                IDataChannelProvider dataChannelProvider)
            {
            }

            public Subscription CreateSubscription(SubscriptionRequest request) => null;

            public void RemoveSubscription(Subscription subscription) { }

            public void Exit() { }
        }
    }
}
