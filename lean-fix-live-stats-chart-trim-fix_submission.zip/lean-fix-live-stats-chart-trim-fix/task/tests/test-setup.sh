#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
#
# The verifier for this task is a dotnet test driven by the shell runner
# (verify.sh). The image baked the full NuGet dependency closure at the base
# commit (quantconnect/lean foundation image + a Release build of
# QuantConnect.Lean.sln warmed ~/.nuget/packages), so the verifier's compile of
# the Tests project resolves entirely from the image with no network.
cd /repo/Lean

# Force NuGet / dotnet fully offline so a cache miss fails fast here instead of
# silently reaching a registry during grading. (The build/agent phases are
# no-network anyway; this makes the intent explicit and catches a stale bake.)
export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1

# Warm/validate the restore offline against the baked NuGet cache. The in-repo
# LocalPackages source was registered at image-build time; restore must succeed
# with --no-cache off (use the warm global cache) and no network.
if dotnet restore QuantConnect.Lean.sln --source "$HOME/.nuget/packages" \
        --source /repo/Lean/LocalPackages > /tmp/test-setup-restore.log 2>&1; then
    echo "[offline-first] NuGet restore satisfied from image bake"
elif dotnet restore QuantConnect.Lean.sln >> /tmp/test-setup-restore.log 2>&1; then
    echo "[test-setup] NuGet restore completed online (image bake was stale)"
else
    tail -60 /tmp/test-setup-restore.log >&2; exit 1
fi

# No services to start, no data to seed: the task is an in-process unit-level
# behavior of the live result handler. No assertion logic lives here.
