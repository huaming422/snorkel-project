## Task

Heads up: on our long-running live algos the risk statistics (the probabilistic
Sharpe ratio and the other live performance metrics) end up reading 0%. They look
right early in the session, then collapse to zero and stay stuck there for the rest
of the run. A restart brings them back for a while, but they're soon wrong again and
drift back to zero. Can you dig in and figure out why the live stats are no longer
correct over a long session, and fix it so they stay right?
