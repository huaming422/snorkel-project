#!/usr/bin/env bash
#
# Validation environment setup for the single-rendered-table migration.
#
# Runs after tests/test-setup.sh, which already asserted the Go test runtime.
# Both validation stories exercise pure-Go internal packages (the parser tree
# and the ingestion chunker) through the go-test driver, so this script only
# re-asserts the same offline Go runtime defensively — nothing extra is
# needed. The image bakes a warm module + build/test cache and the cl100k
# tiktoken table, so `go test` runs fully offline; this is a near-no-op that
# recovers a scrubbed env or a wiped cache layer.
#
# Must be IDEMPOTENT — it may be sourced more than once.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/ragflow}"
cd "$REPO_DIR"

# The task builds and tests with cgo disabled and a pinned local toolchain;
# re-assert for a freshly-spawned shell that did not inherit the image ENV.
export CGO_ENABLED=0
export GOTOOLCHAIN=local
export GOFLAGS=-mod=mod
export GOPATH="${GOPATH:-/opt/go}"
export GOMODCACHE="${GOMODCACHE:-/opt/go/pkg/mod}"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"

# Create the caches up-front in case the agent wiped the pre-warmed layer.
mkdir -p "$GOMODCACHE" "$GOCACHE"

# Make `go` reachable even if the harness scrubbed PATH.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/opt/go/bin:$PATH ;;
esac

# No-op on the image's pre-warmed module cache; recovers a wiped layer.
# Offline-first: the agent phase has no network, so never reach the proxy.
GOPROXY=off go mod download 2>/dev/null || true

# Loud smoke guard: the two story packages must compile before any story
# runs, so a broken build fails here with a clear message instead of as an
# opaque per-story compile error. `go build` is a no-op on a warm cache.
if ! GOPROXY=off go build ./internal/parser/parser/... ./internal/ingestion/component/chunker/... >/dev/null 2>&1; then
    echo "validation-setup.sh: WARNING: story packages did not build cleanly" >&2
fi

echo "validation-setup.sh: ready (CGO_ENABLED=$CGO_ENABLED, GOTOOLCHAIN=$GOTOOLCHAIN, GOFLAGS=$GOFLAGS)"
