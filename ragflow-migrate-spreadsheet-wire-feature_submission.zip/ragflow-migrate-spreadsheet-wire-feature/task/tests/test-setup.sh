#!/usr/bin/env bash
#
# Sourced (not exec'd) by the verifier harness before `go test` runs, so the
# env we set persists for the runner. Re-asserts the Go test runtime
# defensively in case agent edits touched the environment. The image bakes the
# full Go module cache, a warm build/test cache, and the cl100k tiktoken table,
# so everything the solving agent and the verifier need is already present
# offline — this script is a near-no-op that only recovers a scrubbed env/layer.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/ragflow}"
cd "$REPO_DIR"

# The task builds and tests with cgo disabled and a pinned local toolchain.
# Needed by a freshly-spawned shell that didn't inherit the image ENV.
export CGO_ENABLED=0
export GOTOOLCHAIN=local
export GOFLAGS=-mod=mod
export GOPATH="${GOPATH:-/opt/go}"
export GOMODCACHE="${GOMODCACHE:-/opt/go/pkg/mod}"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"

# Make `go` reachable even if the harness scrubbed PATH.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/opt/go/bin:$PATH ;;
esac

# The verifier harness drives the Go verifier through its Python runner; pytest
# and the rest of the verifier stack are already baked into the canonical
# /opt/tooling venv ($VERIFIER_PYTHON), so no install is needed here. Assert its
# presence loudly instead of silently installing an unpinned copy.
if ! "${VERIFIER_PYTHON:-python3}" -c 'import pytest' 2>/dev/null; then
    echo "test-setup.sh: WARNING: pytest not importable via VERIFIER_PYTHON=${VERIFIER_PYTHON:-python3}" >&2
fi

# No-op on the image's pre-warmed module cache; recovers a wiped layer.
# Offline-first: the agent phase has no network, so never reach the proxy.
GOPROXY=off go mod download 2>/dev/null || true

echo "test-setup.sh: ready (CGO_ENABLED=$CGO_ENABLED, GOTOOLCHAIN=$GOTOOLCHAIN, GOFLAGS=$GOFLAGS)"
