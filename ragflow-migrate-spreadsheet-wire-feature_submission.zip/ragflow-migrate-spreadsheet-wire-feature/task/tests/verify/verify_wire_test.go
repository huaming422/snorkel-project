//
//  Copyright 2026 The InfiniFlow Authors. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

// Behavioral verifier for the single-rendered-table migration.
//
// Everything here is asserted on OBSERVABLE output only:
//   - the table chunker is driven through its public constructor
//     (NewTableChunker) and the runtime Component contract
//     (Component.Invoke → out["chunks"]);
//   - the index-write boundary is driven through the exported
//     indexdoc.ProcessChunksForPipeline, and only the index fields it writes
//     (position_int / page_num_int / top_int) are inspected.
//
// No reference-private helper name, internal function, or intermediate
// positions representation is referenced. The three alternative
// implementations the contract allows (different helper/function/file names;
// one position writer with a mode argument vs. two; positions emitted as an
// integer matrix vs. a flat grouped-by-five array) are all observable-equivalent
// at these entry points, so each one passes this file unchanged.
package chunker

import (
	"context"
	"testing"
	"time"

	"ragflow/internal/ingestion/task/indexdoc"
)

// verifyFixedTime is a deterministic timestamp for the index-write boundary;
// ProcessChunksForPipeline only formats it into bookkeeping fields the position
// assertions never read.
func verifyFixedTime() time.Time {
	return time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC)
}

// verifyTableChunks drives the table chunker through its public constructor and
// the runtime Component contract, returning the emitted chunk maps.
func verifyTableChunks(t *testing.T, inputs map[string]any) []map[string]any {
	t.Helper()
	comp, err := NewTableChunker(nil)
	if err != nil {
		t.Fatalf("NewTableChunker: %v", err)
	}
	out, err := comp.Invoke(context.Background(), nil, inputs)
	if err != nil {
		t.Fatalf("TableChunker.Invoke: %v", err)
	}
	if e, ok := out["_ERROR"]; ok && e != nil {
		t.Fatalf("TableChunker reported input error: %v", e)
	}
	chunks, ok := out["chunks"].([]map[string]any)
	if !ok {
		t.Fatalf("out[\"chunks\"] = %T, want []map[string]any", out["chunks"])
	}
	return chunks
}

// verifyText returns a chunk's text field as a string.
func verifyText(t *testing.T, chunk map[string]any) string {
	t.Helper()
	s, ok := chunk["text"].(string)
	if !ok {
		t.Fatalf("chunk text = %T, want string (chunk=%#v)", chunk["text"], chunk)
	}
	return s
}

// verifyNoPositions asserts a chunk carries no per-row position tuples — the
// key is either absent or an empty matrix. It accepts either the chunker's
// decoded [][]float64 shape or an absent key, without pinning any intermediate
// representation.
func verifyNoPositions(t *testing.T, chunk map[string]any, context string) {
	t.Helper()
	v, ok := chunk["positions"]
	if !ok || v == nil {
		return
	}
	if m, ok := v.([][]float64); ok {
		if len(m) != 0 {
			t.Fatalf("%s: chunk carries positions %v, want none", context, m)
		}
		return
	}
	t.Fatalf("%s: chunk carries positions %v (%T), want none", context, v, v)
}

// verifyOwnTuple asserts a chunk carries exactly one 5-field position tuple and
// returns it. positions on a chunker-emitted chunk decode as [][]float64.
func verifyOwnTuple(t *testing.T, chunk map[string]any, context string) []float64 {
	t.Helper()
	v, ok := chunk["positions"]
	if !ok || v == nil {
		t.Fatalf("%s: chunk carries no positions, want its own tuple", context)
	}
	m, ok := v.([][]float64)
	if !ok {
		t.Fatalf("%s: positions = %T, want [][]float64", context, v)
	}
	if len(m) != 1 {
		t.Fatalf("%s: chunk carries %d position tuples, want exactly its own one: %v", context, len(m), m)
	}
	if len(m[0]) != 5 {
		t.Fatalf("%s: position tuple has %d fields, want 5: %v", context, len(m[0]), m[0])
	}
	return m[0]
}

// ---------------------------------------------------------------------------
// Criterion 2: the table chunker expands one rendered table into one chunk per
// data row (repeating the column names), keeps a header-only table whole, and
// drops an all-empty data row.
// ---------------------------------------------------------------------------

func TestVerifyTableChunkerExpandsRenderedTableRows(t *testing.T) {
	// A rendered table: header row, two data rows (the second has an empty
	// cell), and one all-empty data row.
	table := "<table><caption>orders</caption>\n" +
		"<tr><th>ID</th><th>Status</th></tr>\n" +
		"<tr><td>A-1</td><td>paid</td></tr>\n" +
		"<tr><td>A-2</td><td></td></tr>\n" +
		"<tr><td></td><td></td></tr>\n" +
		"</table>\n"
	chunks := verifyTableChunks(t, map[string]any{
		"name":          "orders.xlsx",
		"output_format": "json",
		"json": []map[string]any{
			{"text": table, "doc_type_kwd": "table", "ck_type": "table"},
		},
	})

	// One chunk per non-empty DATA row: the two populated rows expand, the
	// all-empty row produces nothing.
	if len(chunks) != 2 {
		t.Fatalf("got %d chunks, want one per non-empty data row (2)", len(chunks))
	}
	// Each chunk's text repeats the column names with that row's values;
	// an empty cell is omitted from the row's record.
	if got := verifyText(t, chunks[0]); got != "- ID: A-1\n- Status: paid" {
		t.Fatalf("chunk0 text = %q, want the first data row's field:value record", got)
	}
	if got := verifyText(t, chunks[1]); got != "- ID: A-2" {
		t.Fatalf("chunk1 text = %q, want the second data row with its empty cell dropped", got)
	}
}

func TestVerifyTableChunkerKeepsHeaderOnlyTableWhole(t *testing.T) {
	// A table whose only row is the header has nothing to expand: the whole
	// rendered markup stays a single chunk.
	table := "<table><caption>t</caption>\n<tr><th>A</th><th>B</th></tr>\n</table>\n"
	chunks := verifyTableChunks(t, map[string]any{
		"name":          "template.xlsx",
		"output_format": "json",
		"json": []map[string]any{
			{"text": table, "doc_type_kwd": "table", "ck_type": "table"},
		},
	})
	if len(chunks) != 1 {
		t.Fatalf("got %d chunks, want the header-only table kept whole (1)", len(chunks))
	}
	if got := verifyText(t, chunks[0]); got != table {
		t.Fatalf("header-only chunk text = %q, want the whole rendered markup", got)
	}
}

// ---------------------------------------------------------------------------
// Criterion 4: an expanded row chunk carries exactly its own single position
// tuple, and only when the item has spreadsheet identity AND a row-aligned
// matrix; a misaligned or non-spreadsheet payload gets no per-row positions,
// and a pre-upgrade per-row record passes through as one chunk with none.
// ---------------------------------------------------------------------------

func TestVerifyRowChunkCarriesOnlyItsOwnPositionTuple(t *testing.T) {
	// Row-aligned matrix: one 5-field tuple per rendered row (header included).
	table := "<table><caption>orders</caption>\n" +
		"<tr><th>ID</th><th>Status</th></tr>\n" +
		"<tr><td>A-1</td><td>paid</td></tr>\n" +
		"<tr><td>A-2</td><td>due</td></tr>\n" +
		"</table>\n"
	chunks := verifyTableChunks(t, map[string]any{
		"name":          "orders.xlsx",
		"output_format": "json",
		"json": []map[string]any{
			{
				"text":         table,
				"doc_type_kwd": "table",
				"ck_type":      "table",
				"sheet_index":  1,
				"positions": [][]float64{
					{1, 1, 1, 1, 2}, // header row tuple
					{1, 2, 2, 1, 2}, // first data row tuple
					{1, 3, 3, 1, 2}, // second data row tuple
				},
			},
		},
	})
	if len(chunks) != 2 {
		t.Fatalf("got %d chunks, want one per data row (2)", len(chunks))
	}
	first := verifyOwnTuple(t, chunks[0], "data row 0")
	second := verifyOwnTuple(t, chunks[1], "data row 1")
	// Each chunk holds its OWN row's tuple, not the header's and not the
	// whole matrix. The two data rows differ in their second field.
	if first[1] != 2 {
		t.Fatalf("data row 0 tuple = %v, want the row-2 coordinate (not the header's)", first)
	}
	if second[1] != 3 {
		t.Fatalf("data row 1 tuple = %v, want the row-3 coordinate", second)
	}
}

func TestVerifyMisalignedMatrixYieldsNoRowPositions(t *testing.T) {
	// A spreadsheet item whose matrix count does not match the row count is
	// not row-aligned: no row chunk may inherit a tuple, or every row would
	// locate to the same coordinate.
	table := "<table><tr><th>ID</th></tr><tr><td>a</td></tr><tr><td>b</td></tr></table>"
	chunks := verifyTableChunks(t, map[string]any{
		"name":          "sheet.csv",
		"output_format": "json",
		"json": []map[string]any{
			{
				"text":         table,
				"doc_type_kwd": "table",
				"ck_type":      "table",
				"sheet_index":  1,
				"positions":    [][]float64{{1, 1, 2, 1, 1}}, // one whole-table tuple, 3 rows
			},
		},
	})
	if len(chunks) != 2 {
		t.Fatalf("got %d chunks, want one per data row (2)", len(chunks))
	}
	for i, c := range chunks {
		verifyNoPositions(t, c, "misaligned matrix chunk")
		_ = i
	}
}

func TestVerifyNonSpreadsheetPayloadYieldsNoRowPositions(t *testing.T) {
	// A payload without spreadsheet identity must never have its five-field
	// matrix read as per-row tuples, even when the count happens to align:
	// PDF layout boxes live in the same field with a different vocabulary.
	table := "<table><tr><th>ID</th></tr><tr><td>a</td></tr><tr><td>b</td></tr></table>"
	chunks := verifyTableChunks(t, map[string]any{
		"name":          "document.docx",
		"output_format": "json",
		"json": []map[string]any{
			{
				"text":         table,
				"doc_type_kwd": "table",
				"ck_type":      "table",
				"positions":    [][]float64{{1, 1, 1, 1, 1}, {1, 2, 2, 1, 1}, {1, 3, 3, 1, 1}},
			},
		},
	})
	if len(chunks) != 2 {
		t.Fatalf("got %d chunks, want one per data row (2)", len(chunks))
	}
	for _, c := range chunks {
		verifyNoPositions(t, c, "non-spreadsheet chunk")
	}
}

func TestVerifyLegacyRecordPassesThroughUnchanged(t *testing.T) {
	// A pre-upgrade per-row record (plain field:value text, not rendered table
	// markup) has nothing to expand: it stays one chunk with no fabricated
	// positions.
	record := "- name: Alice\n- age: 30"
	chunks := verifyTableChunks(t, map[string]any{
		"name":          "legacy.csv",
		"output_format": "json",
		"json": []map[string]any{
			{"text": record, "doc_type_kwd": "table"},
		},
	})
	if len(chunks) != 1 {
		t.Fatalf("got %d chunks, want the legacy record passed through as one", len(chunks))
	}
	if got := verifyText(t, chunks[0]); got != record {
		t.Fatalf("legacy chunk text = %q, want it unchanged", got)
	}
	verifyNoPositions(t, chunks[0], "legacy record")
}

// ---------------------------------------------------------------------------
// Criterion 3: the index-write boundary stores a spreadsheet chunk's
// coordinates in the cell-range field (position_int) only, leaves the
// page-number and top-offset fields untouched, still populates all three for a
// PDF chunk, and drops a position array whose length is not a multiple of five.
// ---------------------------------------------------------------------------

func verifyHasKey(chunk map[string]any, key string) bool {
	v, ok := chunk[key]
	return ok && v != nil
}

func TestVerifySpreadsheetChunkStoresCellRangeFieldOnly(t *testing.T) {
	// A chunk carrying spreadsheet identity: its row index already lives in
	// top_int, and its coordinates must land in position_int only.
	chunk := map[string]any{
		"text":        "- ID: A-1\n- Status: paid",
		"sheet_index": 1,
		"top_int":     []int{41},
		"positions":   [][]float64{{1, 42, 42, 1, 3}},
	}
	if _, err := indexdoc.ProcessChunksForPipeline([]map[string]any{chunk}, "doc-1", "orders.xlsx", verifyFixedTime()); err != nil {
		t.Fatalf("ProcessChunksForPipeline: %v", err)
	}
	if !verifyHasKey(chunk, "position_int") {
		t.Fatalf("spreadsheet chunk missing position_int: %#v", chunk)
	}
	if verifyHasKey(chunk, "page_num_int") {
		t.Fatalf("spreadsheet chunk populated page_num_int %v, want it left untouched", chunk["page_num_int"])
	}
	// The pre-existing row index in top_int must survive unclobbered.
	top, ok := chunk["top_int"].([]int)
	if !ok || len(top) != 1 || top[0] != 41 {
		t.Fatalf("spreadsheet chunk top_int = %v, want the row index [41] preserved", chunk["top_int"])
	}
}

func TestVerifyPDFChunkStoresAllCoordinateFields(t *testing.T) {
	// A chunk with no spreadsheet identity is a PDF layout box: page_num_int,
	// top_int, and position_int are all populated.
	chunk := map[string]any{
		"text":      "a paragraph",
		"positions": [][]float64{{2, 10, 20, 30, 40}},
	}
	if _, err := indexdoc.ProcessChunksForPipeline([]map[string]any{chunk}, "doc-2", "report.pdf", verifyFixedTime()); err != nil {
		t.Fatalf("ProcessChunksForPipeline: %v", err)
	}
	for _, key := range []string{"page_num_int", "top_int", "position_int"} {
		if !verifyHasKey(chunk, key) {
			t.Fatalf("PDF chunk missing %s: %#v", key, chunk)
		}
	}
	// Page numbers are already 1-indexed at the parser boundary: the stored
	// page must equal the input page, with no second +1.
	page, ok := chunk["page_num_int"].([]int)
	if !ok || len(page) != 1 || page[0] != 2 {
		t.Fatalf("PDF chunk page_num_int = %v, want [2] (no double increment)", chunk["page_num_int"])
	}
}

func TestVerifyMalformedPositionArrayIsDropped(t *testing.T) {
	// A position array whose flattened length is not a multiple of five is
	// malformed and must be dropped, never reinterpreted.
	chunk := map[string]any{
		"text":      "a paragraph",
		"positions": [][]float64{{1, 2, 3}},
	}
	if _, err := indexdoc.ProcessChunksForPipeline([]map[string]any{chunk}, "doc-3", "report.pdf", verifyFixedTime()); err != nil {
		t.Fatalf("ProcessChunksForPipeline: %v", err)
	}
	for _, key := range []string{"page_num_int", "top_int", "position_int"} {
		if verifyHasKey(chunk, key) {
			t.Fatalf("malformed positions produced %s = %v, want it dropped", key, chunk[key])
		}
	}
}
