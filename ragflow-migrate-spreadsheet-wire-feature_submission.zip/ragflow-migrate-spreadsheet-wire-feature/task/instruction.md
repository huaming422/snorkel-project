## Task

Our table ingestion carries every parsed table in two forms at once: an intermediate per-row record representation and a rendered table. The producers that emit tables (csv, xls, xlsx, pdf, and the html/markdown paths), the chunkers that consume them, the index-write boundary, and the file preview each treat those two shapes a little differently, and keeping them in sync is brittle.

Let's collapse the table path onto a single representation: one rendered table that downstream consumers read back row by row, with a positions matrix aligned to it. Once everything reads tables from the rendered form, drop the per-row record representation entirely. This spans both the parser tree and the ingestion chunker and index tree, so every producer, consumer, the index-write boundary, and the file preview agree on the one representation.

Keep the parsers' and chunkers' public entry points intact with the same exported signatures, and keep the behavior-parity notes against the reference Python implementation holding. Don't touch behavior outside the table path. Build is Go 1.27 with cgo off, and the dependencies you need are already in place.

## User stories / requirements

- Parsing a spreadsheet yields one rendered table per sheet: a header row followed by one row per source data row, in document order, with cell and caption text safely escaped. The old per-row record fields no longer appear in the parsed output, and consumers read each table back from its rendered markup.
- When a table is larger than the chunk token budget, it is split across multiple chunks. Each part carries the table's header and only the position entries for the rows that part actually contains, never the whole table's positions.
