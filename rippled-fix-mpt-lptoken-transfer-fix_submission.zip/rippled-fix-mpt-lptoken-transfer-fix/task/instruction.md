## Task

An AMM pool can be formed from a Multi-Purpose Token (MPT) once the relevant MPT-AMM functionality is active, and liquidity providers receive that pool's LPTokens for their share. An MPT issuer controls whether their token may be transferred between third parties.

That restriction is leaking. When a pool's MPT forbids third-party transfers, its LPTokens can still move between non-issuer holders, both as ordinary payments and as the funding asset of an offer, letting holders route exposure around the restriction.

The ledger already closes the analogous hole for a frozen pool asset: once the asset is frozen, that pool's LPTokens become non-spendable, so a holder can neither pay them to another holder nor use them to fund an offer. Make LPToken movement respect a pool MPT's transferability the same way, blocking movement between non-issuer holders whenever the MPT forbids third-party transfer.

Keep transfers that involve the MPT's issuer permitted, since the issuer still seeds and receives LPTokens. Do not introduce a new amendment; the behavior rides the existing MPT-AMM functionality gate and stays inactive when that functionality is off.
