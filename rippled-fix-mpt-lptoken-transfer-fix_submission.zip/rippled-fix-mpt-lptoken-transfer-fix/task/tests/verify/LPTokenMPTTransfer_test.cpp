// Behavioral check for AMM LPToken movement honouring a pool MPT's
// transferability. Written for the reward stage; it is independent of the
// pre-existing LPTokenTransfer suite and is filtered under its own suite name.
//
// Everything here goes through the public jtx transaction-submission interface
// (Env / pay / offer) and asserts on the engine result code and the order book
// via expectOffers. It never links or names any internal helper, so any
// implementation that produces the right observable behaviour passes regardless
// of how it is factored.

#include <test/jtx/AMM.h>
#include <test/jtx/AMMTest.h>
#include <test/jtx/Env.h>
#include <test/jtx/TestHelpers.h>
#include <test/jtx/amount.h>
#include <test/jtx/mpt.h>
#include <test/jtx/offer.h>
#include <test/jtx/pay.h>
#include <test/jtx/ter.h>
#include <test/jtx/trust.h>
#include <test/jtx/txflags.h>

#include <xrpl/beast/unit_test/suite.h>
#include <xrpl/protocol/Feature.h>
#include <xrpl/protocol/TER.h>
#include <xrpl/protocol/TxFlags.h>

#include <cstdint>

namespace xrpl::test {

class LPTokenMPTTransfer_test : public jtx::AMMTest
{
    // A direct LPToken payment between two non-issuer holders must be blocked
    // when a pool asset is an MPT without CanTransfer, and must settle with the
    // MPT-native authorization failure (tecNO_AUTH) rather than a retryable
    // code. With CanTransfer set it goes through. Issuer-involving transfers are
    // always permitted (the issuer seeds the pool). Both pool-asset orderings
    // are exercised.
    void
    testDirectPayment(FeatureBitset features)
    {
        testcase("MPT LPToken direct payment");

        using namespace jtx;

        // An MPT can only be an AMM pool asset once featureMPTokensV2 is active,
        // so the behaviour is only reachable with V2 present.
        if (!features[featureMPTokensV2])
            return;

        auto run = [&](std::uint32_t mptFlags, bool poolXrpToBtc) {
            Env env{*this, features};
            env.fund(XRP(30'000), gw_, alice_, bob_);
            env.close();

            // gw is the MPT issuer; it may seed the pool regardless of whether
            // the MPT permits third-party transfers.
            MPT const btc = MPTTester(
                {.env = env,
                 .issuer = gw_,
                 .holders = {alice_},
                 .pay = 1'000,
                 .flags = mptFlags});

            auto const asset1 = poolXrpToBtc ? XRP(10'000) : btc(10'000);
            auto const asset2 = poolXrpToBtc ? btc(10'000) : XRP(10'000);
            AMM const amm(env, gw_, asset1, asset2);
            auto const lpIssue = amm.lptIssue();

            env.trust(STAmount{lpIssue, 100'000}, alice_);
            env.trust(STAmount{lpIssue, 100'000}, bob_);
            env.close();

            // Issuer-involving transfer is always allowed, even without
            // CanTransfer: gw (the pool MPT's issuer) seeds alice with LPTokens.
            env(pay(gw_, alice_, STAmount{lpIssue, 1'000}));
            env.close();

            if ((mptFlags & tfMPTCanTransfer) != 0u)
            {
                // Pool MPT permits transfers: holder-to-holder LPToken payment
                // succeeds.
                env(pay(alice_, bob_, STAmount{lpIssue, 100}));
            }
            else
            {
                // Pool MPT forbids third-party transfers: the redeem hop against
                // the AMM blocks the LPToken payment with tecNO_AUTH.
                env(pay(alice_, bob_, STAmount{lpIssue, 100}), Ter(tecNO_AUTH));
            }
            env.close();
        };

        // Without CanTransfer: blocked. With CanTransfer: allowed. Both
        // pool-asset orderings.
        run(tfMPTCanTrade, true);
        run(tfMPTCanTrade, false);
        run(tfMPTCanTrade | tfMPTCanTransfer, true);
        run(tfMPTCanTrade | tfMPTCanTransfer, false);
    }

    // Parity with the frozen-pool-asset order-book behaviour: a non-transferable
    // pool MPT makes the LPToken un-spendable, so a sell offer cannot be funded
    // (tecUNFUNDED_OFFER, no offer created) — the same outcome as freezing a
    // pool asset. With CanTransfer the offer is created normally. Both
    // pool-asset orderings are exercised.
    void
    testOffer(FeatureBitset features)
    {
        testcase("MPT LPToken offer funding");

        using namespace jtx;

        if (!features[featureMPTokensV2])
            return;

        auto run = [&](std::uint32_t mptFlags, bool poolXrpToBtc) {
            Env env{*this, features};
            env.fund(XRP(30'000), gw_, carol_);
            env.close();

            MPT const btc = MPTTester(
                {.env = env,
                 .issuer = gw_,
                 .holders = {carol_},
                 .pay = 1'000,
                 .flags = mptFlags});

            auto const asset1 = poolXrpToBtc ? XRP(10'000) : btc(10'000);
            auto const asset2 = poolXrpToBtc ? btc(10'000) : XRP(10'000);
            AMM const amm(env, gw_, asset1, asset2);
            auto const lpIssue = amm.lptIssue();

            env.trust(STAmount{lpIssue, 100'000}, carol_);
            env.close();

            // gw (the pool MPT issuer) seeds carol with LPTokens; issuer
            // involving transfers are always allowed.
            env(pay(gw_, carol_, STAmount{lpIssue, 1'000}));
            env.close();

            if ((mptFlags & tfMPTCanTransfer) != 0u)
            {
                // Spendable LPToken: the sell offer is created.
                env(offer(carol_, XRP(10), STAmount{lpIssue, 10}),
                    Txflags(tfPassive));
                env.close();
                BEAST_EXPECT(expectOffers(env, carol_, 1));
            }
            else
            {
                // Un-spendable LPToken: the sell offer is unfunded and not
                // created, exactly as a frozen pool asset would make it.
                env(offer(carol_, XRP(10), STAmount{lpIssue, 10}),
                    Txflags(tfPassive),
                    Ter(tecUNFUNDED_OFFER));
                env.close();
                BEAST_EXPECT(expectOffers(env, carol_, 0));
            }
        };

        run(tfMPTCanTrade, true);
        run(tfMPTCanTrade, false);
        run(tfMPTCanTrade | tfMPTCanTransfer, true);
        run(tfMPTCanTrade | tfMPTCanTransfer, false);
    }

public:
    void
    run() override
    {
        FeatureBitset const all{jtx::testableAmendments()};

        testDirectPayment(all);
        testOffer(all);
    }
};

BEAST_DEFINE_TESTSUITE(LPTokenMPTTransfer, app, xrpl);

}  // namespace xrpl::test
