#!/usr/bin/env bash
#
# Behavioral verifier for rippled-fix-mpt-lptoken-transfer.
#
# Compiles a self-contained beast unit-test suite into xrpld alongside the
# candidate's libxrpl changes, then exercises AMM LPToken movement through the
# public jtx transaction-submission interface:
#
#   * LPTokenMPTTransfer  — the new behaviour: a pool MPT without CanTransfer
#     must block holder-to-holder LPToken payments and sell-offers, permit them
#     with CanTransfer, and always permit issuer-involving transfers; both
#     pool-asset orderings.
#   * LPTokenTransfer      — the pre-existing suite, re-run as a regression
#     guard (frozen-asset parity and ordinary IOU/XRP pools unchanged).
#
# The suite is copied into the repo's auto-globbed test tree
# (src/test/*.cpp is pulled into xrpld via CONFIGURE_DEPENDS), so no build
# wiring is touched. Exit code: zero only if both suites pass. The runner cwd
# is the repo dir (/repo/rippled).

set -euo pipefail

REPO="/repo/rippled"
BUILD="${REPO}/build"
SUITE_SRC="/tests/verify/LPTokenMPTTransfer_test.cpp"
SUITE_DST="${REPO}/src/test/app/LPTokenMPTTransfer_test.cpp"

cd "${REPO}"

echo "[verify] toolchain: $(cc --version 2>&1 | head -1)"
echo "[verify] build dir: $([ -d "${BUILD}" ] && echo present || echo MISSING)"

if [ ! -d "${BUILD}" ]; then
    echo "[verify] FATAL: expected pre-configured build dir at ${BUILD}" >&2
    exit 2
fi

# Install the behavioral suite into the auto-globbed test tree.
cp "${SUITE_SRC}" "${SUITE_DST}"
echo "[verify] installed suite -> ${SUITE_DST}"

# Size the build to available memory: xrpld's link step is memory-heavy, and the
# container is capped at a few GB. Allow ~1 job per 2 GB, clamped to the CPU
# count, floor of 1.
CPUS="$(nproc)"
MEM_KB="$(awk '/MemTotal/ {print $2}' /proc/meminfo)"
JOBS_BY_MEM=$(( MEM_KB / (2 * 1024 * 1024) ))
JOBS="${CPUS}"
if [ "${JOBS_BY_MEM}" -lt "${JOBS}" ]; then JOBS="${JOBS_BY_MEM}"; fi
if [ "${JOBS}" -lt 1 ]; then JOBS=1; fi
echo "[verify] building xrpld with ${JOBS} job(s) (cpus=${CPUS})"

# Re-run configure so the new test .cpp is picked up by the CONFIGURE_DEPENDS
# glob, then build the xrpld target (recompiles changed libxrpl TUs + the suite
# and relinks).
cmake -S . -B build -G Ninja \
    -DCMAKE_TOOLCHAIN_FILE="${BUILD}/generators/conan_toolchain.cmake" \
    -DCMAKE_BUILD_TYPE=Release -Dxrpld=ON -Dtests=ON
cmake --build build --target xrpld --parallel "${JOBS}"

XRPLD="${BUILD}/xrpld"
if [ ! -x "${XRPLD}" ]; then
    echo "[verify] FATAL: xrpld binary not built at ${XRPLD}" >&2
    exit 2
fi

status=0

echo "[verify] running new behavioral suite: LPTokenMPTTransfer"
if ! "${XRPLD}" --unittest=LPTokenMPTTransfer --unittest-jobs 1; then
    echo "[verify] FAIL: LPTokenMPTTransfer" >&2
    status=1
fi

echo "[verify] running regression suite: LPTokenTransfer"
if ! "${XRPLD}" --unittest=LPTokenTransfer --unittest-jobs 1; then
    echo "[verify] FAIL: LPTokenTransfer (regression)" >&2
    status=1
fi

if [ "${status}" -eq 0 ]; then
    echo "[verify] all suites passed"
fi
exit "${status}"
