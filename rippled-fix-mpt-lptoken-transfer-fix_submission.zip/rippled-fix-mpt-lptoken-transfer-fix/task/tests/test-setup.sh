#!/usr/bin/env bash
# Setup for rippled-fix-mpt-lptoken-transfer.
#
# No services to start and no data to seed. The image already bakes the full
# Conan dependency closure at the base commit and a configured Ninja build dir
# at /repo/rippled/build (with xrpld / xrpl_tests / xrpld_tests built once), so
# the agent phase runs fully offline: incremental rebuilds cache-hit every
# third-party dependency and only recompile changed translation units.
#
# The verifier (reward stage) compiles its own beast unit-test suite into the
# xrpld binary and runs it via `xrpld --unittest=<SuiteName>`; everything it
# needs is already in the image. This script only reports the toolchain so a
# failed environment is obvious in the logs.
set -euo pipefail

echo "[test-setup] gcc:       $(gcc --version 2>&1 | head -1)"
echo "[test-setup] cmake:     $(cmake --version 2>&1 | head -1)"
echo "[test-setup] conan:     $(conan --version 2>&1 | head -1)"
echo "[test-setup] repo:      /repo/rippled"
echo "[test-setup] build dir: $([ -d /repo/rippled/build ] && echo present || echo MISSING)"
echo "[test-setup] xrpld bin: $([ -x /repo/rippled/build/xrpld ] && echo present || echo MISSING)"
echo "[test-setup] Setup complete."
