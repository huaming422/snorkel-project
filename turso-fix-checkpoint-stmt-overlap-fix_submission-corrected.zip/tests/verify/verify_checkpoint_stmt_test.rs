#![cfg(feature = "io_memory_yield")]

//! Explicit checkpoints and statements that are paused on the same connection.
//!
//! The cases use only the public `turso_core` API: `Connection::checkpoint`,
//! `PRAGMA wal_checkpoint`, prepared statements stepped by hand, the
//! incremental blob handle, and `MemoryYieldIO`, which hands every
//! asynchronous I/O back to the test so a statement can be left paused at a
//! chosen point. They look at the error a checkpoint or a statement returns,
//! the rows a paused statement produces once it resumes, and
//! `PRAGMA integrity_check`.

use std::sync::Arc;

use turso_core::{
    CheckpointMode, Connection, Database, DatabaseOpts, LimboError, MemoryYieldIO, OpenFlags,
    SqliteDialect, Statement, StepResult, IO,
};

fn open_conn(io: Arc<MemoryYieldIO>, path: &str) -> Arc<Connection> {
    Database::open_file(io, path, Arc::new(SqliteDialect))
        .unwrap()
        .connect()
        .unwrap()
}

fn integrity_check(conn: &Arc<Connection>) -> Vec<String> {
    conn.prepare("PRAGMA integrity_check")
        .unwrap()
        .run_collect_rows()
        .unwrap()
        .into_iter()
        .map(|row| row[0].to_string())
        .collect()
}

fn ids(conn: &Arc<Connection>, sql: &str) -> Vec<i64> {
    conn.prepare(sql)
        .unwrap()
        .run_collect_rows()
        .unwrap()
        .into_iter()
        .map(|row| row[0].as_int().unwrap())
        .collect()
}

fn passive() -> CheckpointMode {
    CheckpointMode::Passive {
        upper_bound_inclusive: None,
    }
}

/// A WAL database with page size 512 and a free list: five 50 KB rows are
/// written, three are deleted, and the WAL is truncated. Inserting another
/// 50 KB row then reads and writes many pages, so the INSERT stops for I/O
/// many times.
fn seed_freelist_db(io: &Arc<MemoryYieldIO>, path: &str) {
    let conn = open_conn(io.clone(), path);
    conn.execute("PRAGMA page_size=512").unwrap();
    conn.execute("PRAGMA journal_mode = 'wal'").unwrap();
    conn.execute("CREATE TABLE t(id INTEGER PRIMARY KEY, b BLOB)")
        .unwrap();
    conn.execute(
        "INSERT INTO t VALUES
         (1, zeroblob(50000)),
         (2, zeroblob(50000)),
         (3, zeroblob(50000)),
         (4, zeroblob(50000)),
         (5, zeroblob(50000))",
    )
    .unwrap();
    conn.execute("DELETE FROM t WHERE id IN (2,3,4)").unwrap();
    conn.execute("PRAGMA wal_checkpoint(TRUNCATE)").unwrap();
}

/// The free-list database plus 50 small rows written by a second connection,
/// half of them rewritten, so the rows sit in the WAL and a scan of `t` reads
/// many pages.
fn seed_rows_db(io: &Arc<MemoryYieldIO>, path: &str) {
    seed_freelist_db(io, path);
    let writer = open_conn(io.clone(), path);
    for id in 10..60 {
        writer
            .execute(&format!("INSERT INTO t VALUES ({id}, zeroblob(700))"))
            .unwrap();
    }
    writer
        .execute("UPDATE t SET b = zeroblob(800) WHERE id >= 30")
        .unwrap();
}

/// Steps `stmt` and lets I/O complete until the `target_io`-th time it
/// returns `StepResult::IO`; that I/O is left pending. Returns false if the
/// statement finished first.
fn park_at_io(io: &Arc<MemoryYieldIO>, stmt: &mut Statement, target_io: usize) -> bool {
    let mut io_count = 0;
    loop {
        match stmt.step().unwrap() {
            StepResult::IO => {
                io_count += 1;
                if io_count == target_io {
                    return true;
                }
                io.step().unwrap();
            }
            StepResult::Done => return false,
            StepResult::Yield => {}
            other => panic!("unexpected step result while parking: {other:?}"),
        }
    }
}

/// Runs a statement that returns no rows to the end.
fn finish(io: &Arc<MemoryYieldIO>, stmt: &mut Statement, context: &str) {
    loop {
        match stmt
            .step()
            .unwrap_or_else(|err| panic!("{context}: resumed statement failed: {err}"))
        {
            StepResult::IO => io.step().unwrap(),
            StepResult::Done => return,
            StepResult::Yield => {}
            other => panic!("{context}: unexpected step result: {other:?}"),
        }
    }
}

/// Reads rows from a single-column integer query into `out`, stopping after
/// `limit` rows (`None` reads to the end).
fn read_rows(
    io: &Arc<MemoryYieldIO>,
    stmt: &mut Statement,
    out: &mut Vec<i64>,
    limit: Option<usize>,
    context: &str,
) {
    loop {
        if limit.is_some_and(|n| out.len() == n) {
            return;
        }
        match stmt
            .step()
            .unwrap_or_else(|err| panic!("{context}: SELECT failed: {err}"))
        {
            StepResult::Row => out.push(stmt.row().unwrap().get::<i64>(0).unwrap()),
            StepResult::IO => io.step().unwrap(),
            StepResult::Yield => {}
            StepResult::Done => return,
            other => panic!("{context}: unexpected SELECT step result: {other:?}"),
        }
    }
}

fn pragma_checkpoint(conn: &Arc<Connection>, mode: &str) -> turso_core::Result<()> {
    conn.prepare(&format!("PRAGMA wal_checkpoint({mode})"))?
        .run_collect_rows()
        .map(|_| ())
}

fn expect_in_progress(result: turso_core::Result<()>, context: &str) {
    match result {
        Ok(()) => panic!("{context}: expected StatementsInProgress, the call succeeded"),
        Err(err) => assert!(
            matches!(err, LimboError::StatementsInProgress(_)),
            "{context}: expected StatementsInProgress, got {err:?}"
        ),
    }
}

/// Every checkpoint mode, by the name `PRAGMA wal_checkpoint` takes.
const MODES: [&str; 4] = ["PASSIVE", "FULL", "RESTART", "TRUNCATE"];

/// The two explicit checkpoint entry points.
const ENTRIES: [&str; 2] = ["api", "pragma"];

fn api_mode(mode: &str) -> CheckpointMode {
    match mode {
        "PASSIVE" => passive(),
        "FULL" => CheckpointMode::Full,
        "RESTART" => CheckpointMode::Restart,
        "TRUNCATE" => CheckpointMode::Truncate {
            upper_bound_inclusive: None,
        },
        other => panic!("unknown checkpoint mode {other}"),
    }
}

/// Runs one explicit checkpoint: `Connection::checkpoint` for "api",
/// `PRAGMA wal_checkpoint(<mode>)` for "pragma".
fn checkpoint_via(conn: &Arc<Connection>, entry: &str, mode: &str) -> turso_core::Result<()> {
    if entry == "api" {
        conn.checkpoint(api_mode(mode)).map(|_| ())
    } else {
        pragma_checkpoint(conn, mode)
    }
}

/// For every checkpoint mode, an INSERT is left paused at each of its I/O
/// points in turn and the checkpoint is run through `entry` on the same
/// connection. It returns `StatementsInProgress`; the INSERT then runs to the
/// end and the table holds rows 1, 5 and 100.
fn paused_insert_sweep(entry: &str) {
    for mode in MODES {
        for target_io in 1..=512 {
            let io = Arc::new(MemoryYieldIO::new());
            let temp_dir = tempfile::TempDir::new().unwrap();
            let path = temp_dir
                .path()
                .join(format!("{entry}-{mode}-checkpoint-{target_io}.db"));
            let path = path.to_str().unwrap();

            seed_freelist_db(&io, path);
            let conn = open_conn(io.clone(), path);
            let mut stmt = conn
                .prepare("INSERT INTO t VALUES (100, zeroblob(50000))")
                .unwrap();
            if !park_at_io(&io, &mut stmt, target_io) {
                assert!(target_io > 1, "the INSERT never stopped for I/O");
                break;
            }

            let context =
                format!("{entry} {mode} checkpoint with the INSERT paused at I/O {target_io}");
            expect_in_progress(checkpoint_via(&conn, entry, mode), &context);
            finish(&io, &mut stmt, &context);
            drop(stmt);

            assert_eq!(
                ids(&conn, "SELECT id FROM t ORDER BY id"),
                vec![1, 5, 100],
                "{context}: wrong rows"
            );
            assert_eq!(integrity_check(&conn), vec!["ok"], "{context}");
        }
    }
}

/// `Connection::checkpoint` in every mode against an INSERT paused at each
/// of its I/O points.
#[test]
fn test_checkpoint_api_rejects_suspended_statement_and_keeps_it_resumable() {
    paused_insert_sweep("api");
}

/// `PRAGMA wal_checkpoint` in every mode against an INSERT paused at each of
/// its I/O points.
#[test]
fn test_wal_checkpoint_pragma_rejects_suspended_statement_and_keeps_it_resumable() {
    paused_insert_sweep("pragma");
}

/// A SELECT over `t` is left paused after it has returned 1, 5 or 20 rows,
/// and each checkpoint entry point is tried in every mode.
/// Every attempt returns `StatementsInProgress`, and the SELECT then returns
/// exactly the rows it returns when nothing interrupts it.
#[test]
fn test_checkpoint_rejected_while_select_is_parked_between_rows() {
    for (entry, mode) in ENTRIES
        .iter()
        .flat_map(|entry| MODES.iter().map(move |mode| (*entry, *mode)))
    {
        for rows_before in [1, 5, 20] {
            let io = Arc::new(MemoryYieldIO::new());
            let temp_dir = tempfile::TempDir::new().unwrap();
            let path = temp_dir.path().join("parked-select.db");
            let path = path.to_str().unwrap();
            seed_rows_db(&io, path);

            let conn = open_conn(io.clone(), path);
            let expected = ids(&conn, "SELECT id FROM t ORDER BY id");
            let context = format!("{entry} {mode} checkpoint after {rows_before} SELECT rows");

            let mut select = conn.prepare("SELECT id FROM t ORDER BY id").unwrap();
            let mut got = Vec::new();
            read_rows(&io, &mut select, &mut got, Some(rows_before), &context);
            assert_eq!(got.len(), rows_before, "{context}: SELECT ended early");

            expect_in_progress(checkpoint_via(&conn, entry, mode), &context);

            read_rows(&io, &mut select, &mut got, None, &context);
            drop(select);
            assert_eq!(got, expected, "{context}: the resumed SELECT returned different rows");
            assert_eq!(integrity_check(&conn), vec!["ok"], "{context}");
        }
    }
}

/// A SELECT that joins a `pragma_table_info` table-valued function with `t`
/// is left paused after its first row, while the table-valued function's own
/// statement is still open. Both checkpoint entry points, in every mode,
/// return `StatementsInProgress`, and the SELECT then returns every row.
#[test]
fn test_checkpoint_rejected_while_select_with_pragma_function_is_parked() {
    for (entry, mode) in ENTRIES
        .iter()
        .flat_map(|entry| MODES.iter().map(move |mode| (*entry, *mode)))
    {
        let io = Arc::new(MemoryYieldIO::new());
        let temp_dir = tempfile::TempDir::new().unwrap();
        let path = temp_dir.path().join("parked-pragma-function.db");
        let path = path.to_str().unwrap();
        seed_rows_db(&io, path);

        let conn = open_conn(io.clone(), path);
        let sql = "SELECT t.id FROM pragma_table_info('t') p, t";
        let mut expected = ids(&conn, sql);
        expected.sort_unstable();
        let context = format!("{entry} {mode} checkpoint with a pragma_table_info join paused");

        let mut select = conn.prepare(sql).unwrap();
        let mut got = Vec::new();
        read_rows(&io, &mut select, &mut got, Some(1), &context);

        expect_in_progress(checkpoint_via(&conn, entry, mode), &context);

        read_rows(&io, &mut select, &mut got, None, &context);
        drop(select);
        got.sort_unstable();
        assert_eq!(got, expected, "{context}: the resumed SELECT returned different rows");
        conn.execute("PRAGMA wal_checkpoint(PASSIVE)").unwrap();
    }
}

/// `PRAGMA wal_checkpoint(PASSIVE)` is stepped until it is waiting on I/O
/// while it copies frames. An INSERT, a SELECT and an UPDATE are then
/// prepared on the same connection; the first step of each returns
/// `StatementsInProgress`. The checkpoint is then finished, and the same
/// three statements run normally.
#[test]
fn test_suspended_checkpoint_rejects_new_statement() {
    let new_statements = [
        "INSERT INTO t VALUES (100, zeroblob(50000))",
        "SELECT count(*) FROM t",
        "UPDATE t SET b = zeroblob(10) WHERE id = 5",
    ];
    let io = Arc::new(MemoryYieldIO::new());
    let temp_dir = tempfile::TempDir::new().unwrap();
    let path = temp_dir.path().join("checkpoint-before-insert.db");
    let path = path.to_str().unwrap();

    seed_freelist_db(&io, path);
    // A second connection rewrites a large row, so the WAL has frames for the
    // checkpoint below to copy.
    open_conn(io.clone(), path)
        .execute("UPDATE t SET b = zeroblob(51000) WHERE id = 1")
        .unwrap();

    let conn = open_conn(io.clone(), path);
    let mut checkpoint = conn.prepare("PRAGMA wal_checkpoint(PASSIVE)").unwrap();
    loop {
        match checkpoint.step().unwrap() {
            StepResult::IO if checkpoint.get_pager().is_checkpointing() => break,
            StepResult::IO => io.step().unwrap(),
            StepResult::Yield => {}
            other => panic!("checkpoint completed before it waited on I/O: {other:?}"),
        }
    }

    for sql in new_statements {
        let mut stmt = conn.prepare(sql).unwrap();
        let err = stmt
            .step()
            .expect_err("first step of a new statement while the checkpoint waits on I/O");
        assert!(
            matches!(err, LimboError::StatementsInProgress(_)),
            "{sql}: unexpected error: {err:?}"
        );
    }

    loop {
        match checkpoint.step().unwrap() {
            StepResult::IO => io.step().unwrap(),
            StepResult::Row | StepResult::Yield => {}
            StepResult::Done => break,
            other => panic!("unexpected checkpoint result: {other:?}"),
        }
    }
    drop(checkpoint);
    assert!(!conn.get_pager().is_checkpointing());

    for sql in new_statements {
        conn.prepare(sql)
            .unwrap()
            .run_collect_rows()
            .unwrap_or_else(|err| panic!("{sql} after the checkpoint finished: {err}"));
    }
    assert_eq!(ids(&conn, "SELECT id FROM t ORDER BY id"), vec![1, 5, 100]);
    assert_eq!(integrity_check(&conn), vec!["ok"]);
}

/// A blob handle on row 1 is opened and read, then left open between reads.
/// `PRAGMA wal_checkpoint` and `Connection::checkpoint` both succeed. The
/// next read of the handle returns the next four bytes or
/// `BlobHandleExpired`. After the handle is closed, `Connection::checkpoint`
/// succeeds again.
#[test]
fn test_open_blob_handle_does_not_block_explicit_checkpoints() {
    let io = Arc::new(MemoryYieldIO::new());
    let temp_dir = tempfile::TempDir::new().unwrap();
    let path = temp_dir.path().join("blob-checkpoint.db");
    let path = path.to_str().unwrap();

    seed_freelist_db(&io, path);
    write_blob_payload(&io, path);

    let conn = open_conn(io.clone(), path);
    let mut blob = conn.blob_open("t", "b", 1, false).unwrap();
    let mut buf = [0u8; 4];
    blob.read(0, &mut buf).unwrap();
    assert_eq!(buf, [0x00, 0x11, 0x22, 0x33]);

    pragma_checkpoint(&conn, "PASSIVE")
        .expect("PRAGMA wal_checkpoint with an open blob handle");
    conn.checkpoint(passive())
        .expect("Connection::checkpoint with an open blob handle");

    match blob.read(4, &mut buf) {
        Ok(()) => assert_eq!(buf, [0x44, 0x55, 0x66, 0x77], "blob read returned wrong bytes"),
        Err(err) => assert!(
            matches!(err, LimboError::BlobHandleExpired),
            "blob read after the checkpoints: {err:?}"
        ),
    }
    blob.close().unwrap();

    conn.checkpoint(passive())
        .expect("Connection::checkpoint after the blob handle is closed");
    assert_eq!(integrity_check(&conn), vec!["ok"]);
}

/// Two blob handles, on rows 1 and 5, are opened and read, then left open
/// between reads. Both checkpoint entry points succeed. After one handle is
/// closed they succeed again, and again after the second is closed.
#[test]
fn test_two_open_blob_handles_do_not_block_explicit_checkpoints() {
    let io = Arc::new(MemoryYieldIO::new());
    let temp_dir = tempfile::TempDir::new().unwrap();
    let path = temp_dir.path().join("two-blobs-checkpoint.db");
    let path = path.to_str().unwrap();

    seed_freelist_db(&io, path);
    write_blob_payload(&io, path);

    let conn = open_conn(io.clone(), path);
    let mut first = conn.blob_open("t", "b", 1, false).unwrap();
    let mut second = conn.blob_open("t", "b", 5, false).unwrap();
    let mut buf = [0u8; 4];
    first.read(0, &mut buf).unwrap();
    assert_eq!(buf, [0x00, 0x11, 0x22, 0x33]);
    second.read(0, &mut buf).unwrap();
    assert_eq!(buf, [0, 0, 0, 0]);

    let checkpoint_both = |open: &str| {
        pragma_checkpoint(&conn, "PASSIVE")
            .unwrap_or_else(|err| panic!("PRAGMA wal_checkpoint with {open}: {err:?}"));
        conn.checkpoint(passive())
            .unwrap_or_else(|err| panic!("Connection::checkpoint with {open}: {err:?}"));
    };
    checkpoint_both("two handles open");
    first.close().unwrap();
    checkpoint_both("one handle open");
    second.close().unwrap();

    conn.checkpoint(passive())
        .expect("Connection::checkpoint after both blob handles are closed");
    assert_eq!(integrity_check(&conn), vec!["ok"]);
}

/// A blob handle is open on row 1 and an INSERT is left paused at its tenth
/// I/O. Both checkpoint entry points, in every mode, return
/// `StatementsInProgress`, and the INSERT then runs to the end.
#[test]
fn test_open_blob_handle_does_not_hide_a_paused_statement() {
    let io = Arc::new(MemoryYieldIO::new());
    let temp_dir = tempfile::TempDir::new().unwrap();
    let path = temp_dir.path().join("blob-and-insert.db");
    let path = path.to_str().unwrap();

    seed_freelist_db(&io, path);
    write_blob_payload(&io, path);

    let conn = open_conn(io.clone(), path);
    let mut blob = conn.blob_open("t", "b", 1, false).unwrap();
    let mut buf = [0u8; 4];
    blob.read(0, &mut buf).unwrap();

    let mut insert = conn
        .prepare("INSERT INTO t VALUES (100, zeroblob(50000))")
        .unwrap();
    assert!(park_at_io(&io, &mut insert, 10), "the INSERT never stopped for I/O");

    for entry in ENTRIES {
        for mode in MODES {
            expect_in_progress(
                checkpoint_via(&conn, entry, mode),
                &format!("{entry} {mode} checkpoint with a blob handle open and an INSERT paused"),
            );
        }
    }
    finish(&io, &mut insert, "INSERT next to an open blob handle");
    drop(insert);
    blob.close().unwrap();

    assert_eq!(ids(&conn, "SELECT id FROM t ORDER BY id"), vec![1, 5, 100]);
    assert_eq!(integrity_check(&conn), vec!["ok"]);
}

/// Writes a 16-byte pattern into row 1's blob.
fn write_blob_payload(io: &Arc<MemoryYieldIO>, path: &str) {
    let conn = open_conn(io.clone(), path);
    conn.execute("UPDATE t SET b = x'00112233445566778899aabbccddeeff' WHERE id = 1")
        .unwrap();
}

/// After a checkpoint (either entry point, every mode) returned
/// `StatementsInProgress` for a paused INSERT and the INSERT has finished,
/// `Connection::checkpoint` on the idle connection succeeds.
#[test]
fn test_rejected_checkpoint_leaves_clean_state() {
    let combos: Vec<(&str, &str)> = ENTRIES
        .iter()
        .flat_map(|entry| MODES.iter().map(move |mode| (*entry, *mode)))
        .collect();
    for target_io in 1..=512 {
        let (entry, mode) = combos[target_io % combos.len()];
        let io = Arc::new(MemoryYieldIO::new());
        let temp_dir = tempfile::TempDir::new().unwrap();
        let path = temp_dir
            .path()
            .join(format!("clean-state-{target_io}.db"));
        let path = path.to_str().unwrap();

        seed_freelist_db(&io, path);
        let conn = open_conn(io.clone(), path);
        let mut stmt = conn
            .prepare("INSERT INTO t VALUES (100, zeroblob(50000))")
            .unwrap();
        if !park_at_io(&io, &mut stmt, target_io) {
            assert!(target_io > 1, "the INSERT never stopped for I/O");
            break;
        }

        let context =
            format!("{entry} {mode} checkpoint with the INSERT paused at I/O {target_io}");
        expect_in_progress(checkpoint_via(&conn, entry, mode), &context);
        finish(&io, &mut stmt, &context);
        drop(stmt);

        conn.checkpoint(passive())
            .unwrap_or_else(|err| panic!("{context}: idle checkpoint failed: {err}"));
        assert_eq!(
            ids(&conn, "SELECT id FROM t ORDER BY id"),
            vec![1, 5, 100],
            "{context}: wrong rows"
        );
        assert_eq!(integrity_check(&conn), vec!["ok"], "{context}");
    }
}

fn open_conn_with_attach(io: Arc<MemoryYieldIO>, path: &str) -> Arc<Connection> {
    Database::open_file_with_flags(
        io,
        path,
        OpenFlags::Create,
        DatabaseOpts::new().with_attach(true),
        None,
        Arc::new(SqliteDialect),
    )
    .unwrap()
    .connect()
    .unwrap()
}

/// Opens a WAL database (page size 512) with table `t`, optionally attaches a
/// second database `aux` with table `u`, and empties the WAL.
fn seed_commit_db(io: &Arc<MemoryYieldIO>, path: &str, aux: Option<&str>) -> Arc<Connection> {
    let conn = open_conn_with_attach(io.clone(), path);
    conn.execute("PRAGMA page_size=512").unwrap();
    conn.execute("PRAGMA journal_mode = 'wal'").unwrap();
    conn.execute("CREATE TABLE t(id INTEGER PRIMARY KEY, b BLOB)")
        .unwrap();
    conn.execute("INSERT INTO t VALUES (1, zeroblob(2000))").unwrap();
    if let Some(aux) = aux {
        conn.execute(&format!("ATTACH '{aux}' AS aux")).unwrap();
        conn.execute("CREATE TABLE aux.u(id INTEGER PRIMARY KEY, v TEXT)")
            .unwrap();
        conn.execute("INSERT INTO aux.u VALUES (1, 'one')").unwrap();
    }
    conn.execute("PRAGMA wal_checkpoint(TRUNCATE)").unwrap();
    conn
}

/// Writes a 600 KB row (more than 1000 WAL frames at page size 512, so the
/// COMMIT runs the automatic checkpoint) and, with `aux`, a row of `aux.u`, in
/// one transaction, then steps COMMIT until it waits on the `target_io`-th
/// I/O of that automatic checkpoint. Returns `None` once the COMMIT finishes
/// before that point.
fn park_commit_in_autocheckpoint(
    io: &Arc<MemoryYieldIO>,
    conn: &Arc<Connection>,
    aux: bool,
    target_io: usize,
) -> Option<Statement> {
    conn.execute("BEGIN").unwrap();
    conn.execute("INSERT INTO t VALUES (2, zeroblob(600000))")
        .unwrap();
    if aux {
        conn.execute("INSERT INTO aux.u VALUES (2, 'two')").unwrap();
    }
    let mut commit = conn.prepare("COMMIT").unwrap();
    let mut io_count = 0;
    loop {
        match commit.step().unwrap() {
            StepResult::IO => {
                if commit.get_pager().is_checkpointing() {
                    io_count += 1;
                    if io_count == target_io {
                        return Some(commit);
                    }
                }
                io.step().unwrap();
            }
            StepResult::Done => return None,
            StepResult::Yield => {}
            other => panic!("unexpected COMMIT step result: {other:?}"),
        }
    }
}

fn check_committed(conn: &Arc<Connection>, aux: bool, context: &str) {
    assert_eq!(
        ids(conn, "SELECT id FROM t ORDER BY id"),
        vec![1, 2],
        "{context}: rows of t"
    );
    if aux {
        assert_eq!(
            ids(conn, "SELECT id FROM aux.u ORDER BY id"),
            vec![1, 2],
            "{context}: rows of aux.u"
        );
    }
    assert_eq!(integrity_check(conn), vec!["ok"], "{context}");
}

/// A COMMIT is left waiting on each I/O of its automatic checkpoint in turn,
/// with and without an attached database written in the same transaction.
/// `Connection::checkpoint` and `PRAGMA wal_checkpoint` on that connection, in
/// every mode, return `StatementsInProgress`; the COMMIT then finishes and
/// both rows are there.
#[test]
fn test_checkpoint_rejected_while_commit_runs_its_automatic_checkpoint() {
    for (entry, aux, mode) in [("api", false), ("pragma", false), ("api", true), ("pragma", true)]
        .iter()
        .flat_map(|(entry, aux)| MODES.iter().map(move |mode| (*entry, *aux, *mode)))
    {
        for target_io in 1..=64 {
            let io = Arc::new(MemoryYieldIO::new());
            let temp_dir = tempfile::TempDir::new().unwrap();
            let path = temp_dir.path().join("commit.db");
            let aux_path = temp_dir.path().join("aux.db");
            let conn = seed_commit_db(
                &io,
                path.to_str().unwrap(),
                aux.then(|| aux_path.to_str().unwrap()),
            );
            let Some(mut commit) = park_commit_in_autocheckpoint(&io, &conn, aux, target_io)
            else {
                assert!(target_io > 1, "the COMMIT never checkpointed");
                break;
            };
            let context = format!(
                "{entry} {mode} checkpoint, attached database {aux}, COMMIT waiting on checkpoint I/O {target_io}"
            );
            expect_in_progress(checkpoint_via(&conn, entry, mode), &context);
            finish(&io, &mut commit, &context);
            drop(commit);
            check_committed(&conn, aux, &context);
        }
    }
}

/// A SELECT runs to the end and is kept; a COMMIT that also wrote to an
/// attached database is then left waiting on each I/O of its automatic
/// checkpoint in turn. Dropping the finished SELECT leaves the COMMIT able to
/// finish, with both rows there.
#[test]
fn test_dropping_finished_statement_leaves_parked_commit_alone() {
    for target_io in 1..=64 {
        let io = Arc::new(MemoryYieldIO::new());
        let temp_dir = tempfile::TempDir::new().unwrap();
        let path = temp_dir.path().join("commit.db");
        let aux_path = temp_dir.path().join("aux.db");
        let conn = seed_commit_db(&io, path.to_str().unwrap(), Some(aux_path.to_str().unwrap()));

        let mut finished = conn.prepare("SELECT count(*) FROM t").unwrap();
        loop {
            match finished.step().unwrap() {
                StepResult::IO => io.step().unwrap(),
                StepResult::Done => break,
                StepResult::Row | StepResult::Yield => {}
                other => panic!("unexpected SELECT step result: {other:?}"),
            }
        }

        let Some(mut commit) = park_commit_in_autocheckpoint(&io, &conn, true, target_io) else {
            assert!(target_io > 1, "the COMMIT never checkpointed");
            break;
        };
        let context = format!("finished SELECT dropped, COMMIT waiting on checkpoint I/O {target_io}");
        drop(finished);
        finish(&io, &mut commit, &context);
        drop(commit);
        check_committed(&conn, true, &context);
    }
}

/// `PRAGMA wal_checkpoint(PASSIVE)` is left waiting on each I/O of its frame
/// copy in turn and then dropped. Afterwards an INSERT runs, both checkpoint
/// entry points succeed, and the table holds rows 1, 5 and 100.
#[test]
fn test_dropped_checkpoint_leaves_connection_usable() {
    for target_io in 1..=64 {
        let io = Arc::new(MemoryYieldIO::new());
        let temp_dir = tempfile::TempDir::new().unwrap();
        let path = temp_dir.path().join("dropped-checkpoint.db");
        let path = path.to_str().unwrap();
        seed_freelist_db(&io, path);
        open_conn(io.clone(), path)
            .execute("UPDATE t SET b = zeroblob(51000) WHERE id = 1")
            .unwrap();

        let conn = open_conn(io.clone(), path);
        let mut checkpoint = conn.prepare("PRAGMA wal_checkpoint(PASSIVE)").unwrap();
        let mut io_count = 0;
        let parked = loop {
            match checkpoint.step().unwrap() {
                StepResult::IO if checkpoint.get_pager().is_checkpointing() => {
                    io_count += 1;
                    if io_count == target_io {
                        break true;
                    }
                    io.step().unwrap();
                }
                StepResult::IO => io.step().unwrap(),
                StepResult::Row | StepResult::Yield => {}
                StepResult::Done => break false,
                other => panic!("unexpected checkpoint step result: {other:?}"),
            }
        };
        if !parked {
            assert!(target_io > 1, "the checkpoint never waited on I/O");
            break;
        }
        drop(checkpoint);

        let context = format!("checkpoint dropped at I/O {target_io}");
        conn.execute("INSERT INTO t VALUES (100, zeroblob(3000))")
            .unwrap_or_else(|err| panic!("{context}: INSERT failed: {err}"));
        conn.checkpoint(passive())
            .unwrap_or_else(|err| panic!("{context}: Connection::checkpoint failed: {err}"));
        pragma_checkpoint(&conn, "TRUNCATE")
            .unwrap_or_else(|err| panic!("{context}: PRAGMA wal_checkpoint failed: {err}"));
        assert_eq!(ids(&conn, "SELECT id FROM t ORDER BY id"), vec![1, 5, 100], "{context}");
        assert_eq!(integrity_check(&conn), vec!["ok"], "{context}");
    }
}
