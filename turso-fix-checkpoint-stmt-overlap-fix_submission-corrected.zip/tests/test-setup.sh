#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
#
# Offline-first: the image already holds every dependency of the workspace and
# a warm `cargo build --locked --workspace --lib --tests --all-features`. This
# step must not reach the network, so the offline switch is exported right
# after cd and a cache miss fails fast instead of waiting on a registry that
# can't be reached.
cd /repo/turso

export CARGO_NET_OFFLINE=true

# Pre-warm the core_tester test crate so the verifier's first `cargo test`
# pays only for compiling the newly-injected verify test binary, not the whole
# workspace. --no-run compiles tests without executing them. The verifier needs
# the io_memory_yield feature (MemoryYieldIO) to suspend a statement at an exact
# I/O boundary. Offline-first against the image bake, with a logged online
# fallback in case the bake was stale.
if cargo test --locked --offline -p core_tester --features io_memory_yield --no-run \
        > /tmp/test-setup-build.log 2>&1; then
    echo "[offline-first] core_tester test binaries built from image cache"
elif cargo test --locked -p core_tester --features io_memory_yield --no-run \
        >> /tmp/test-setup-build.log 2>&1; then
    echo "[test-setup] core_tester test binaries built online (image bake was stale)"
else
    # The test run's own cargo test reports a tree that doesn't compile.
    # Leaving this sourced script with a non-zero exit would end test.sh
    # before the verifier runs at all.
    tail -80 /tmp/test-setup-build.log >&2
    echo "[test-setup] core_tester test binaries did not build; the test run reports the errors" >&2
fi
