## Task

we're getting reports that for tools backed by a code-forge repo, `mise ls-remote <tool>` lists versions that then can't be installed. take one of them, run `mise install <tool>@<that-version>`, and it fails saying it couldn't find an installable file ("No matching asset found"). these aren't drafts or pre-releases; they look like normal published releases sitting alongside the ones that do install.

it leaks into `mise latest <tool>` too: latest can land on one of these dud versions, so even asking for the newest version can hand you something that won't install.

the list should only advertise versions that can actually be installed, and `ls-remote` and `latest` need to agree about what's available. dig into how mise decides which remote versions to advertise and resolve for forge-backed tools, and fix it there, not in the lower-level machinery that downloads a file or picks which file to grab.

one constraint: the versions listed for a tool can't depend on the OS or CPU architecture mise is running on. a list or lockfile produced on one machine has to still resolve on another.
