#!/usr/bin/env bash
#
# Behavioral verifier (fail_to_pass) for the subtle cross-layer part of the
# mise-fix-skip-assetless-releases task: the bounded release paging.
#
# mise pages through the forge releases API only until it has seen a published,
# non-draft, non-prerelease ("stable") release, then stops. If an uninstallable
# release is the first stable one, a fix that merely drops uninstallable
# releases from the final list still stops paging on it and never reaches the
# installable release on the next page, so the listing comes back empty. A
# correct fix treats only an INSTALLABLE stable release as a stopping point, so
# it keeps paging to the installable one.
#
# Observed only through `mise ls-remote` output. Names no source file, internal
# function, or release field. A fix that recomputes the stop condition at any
# layer, under any name, passes.
#
# Standalone script: stands up its own isolated mise dirs and a python3 stdlib
# HTTP stand-in that paginates via a Link: rel="next" header, exactly as the
# real forge API does.

set -uo pipefail

MISE_BIN=""
for cand in \
    "${MISE_E2E_BIN:-}" \
    "${CARGO_TARGET_DIR:-/opt/cache/cargo-target}/debug/mise" \
    "/repo/mise/target/debug/mise" \
    "$(command -v mise 2>/dev/null || true)"; do
    if [[ -n "$cand" && -x "$cand" ]]; then
        MISE_BIN="$cand"
        break
    fi
done
[[ -n "$MISE_BIN" ]] || { echo "FAIL: could not locate a built mise binary" >&2; exit 1; }
echo "using mise binary: $MISE_BIN" >&2

WORK="$(mktemp -d "${TMPDIR:-/tmp}/mise-verify-page.XXXXXX")"
cleanup() {
    [[ -n "${SERVER_PID:-}" ]] && kill "$SERVER_PID" 2>/dev/null || true
    rm -rf "$WORK" 2>/dev/null || true
}
trap cleanup EXIT

export HOME="$WORK/home"
export MISE_DATA_DIR="$HOME/.local/share/mise"
export MISE_CACHE_DIR="$HOME/.cache/mise"
export MISE_CONFIG_DIR="$HOME/.config/mise"
export MISE_STATE_DIR="$HOME/.local/state/mise"
export MISE_SYSTEM_DIR="$WORK/etc/mise"
export MISE_TMP_DIR="$WORK/tmp"
mkdir -p "$HOME" "$MISE_DATA_DIR" "$MISE_CACHE_DIR" "$MISE_CONFIG_DIR" \
         "$MISE_STATE_DIR" "$MISE_SYSTEM_DIR" "$MISE_TMP_DIR"
export MISE_YES=1
export MISE_EXPERIMENTAL=1
export MISE_USE_VERSIONS_HOST=0
export MISE_USE_VERSIONS_HOST_TRACK=0
unset MISE_GITHUB_TOKEN GITHUB_TOKEN MISE_LIST_ALL_VERSIONS 2>/dev/null || true

# Stand-in that paginates: page 1 carries only a stable release that has
# nothing to install; page 2 carries the installable stable release. A
# `Link: rel="next"` header points page 1 at page 2, as the real API does.
PORT_FILE="$WORK/port"
python3 - "$PORT_FILE" <<'PY' &
import http.server
import json
import socketserver
import sys
from urllib.parse import urlparse, parse_qs

port_file = sys.argv[1]

STABLE_UNINSTALLABLE = {
    "tag_name": "v1.0.0",
    "draft": False,
    "prerelease": False,
    "created_at": "2026-01-01T00:00:00Z",
    "published_at": "2026-01-01T00:00:00Z",
    "assets": [],
}

STABLE_INSTALLABLE = {
    "tag_name": "v2.0.0",
    "draft": False,
    "prerelease": False,
    "created_at": "2026-02-01T00:00:00Z",
    "published_at": "2026-02-01T00:00:00Z",
    "assets": [
        {
            "name": "tool-x86_64-unknown-linux-gnu.tar.gz",
            "browser_download_url": "https://example.invalid/tool.tar.gz",
            "url": "https://example.invalid/api/tool.tar.gz",
        }
    ],
}


class Handler(http.server.BaseHTTPRequestHandler):
    def reply(self, payload, link=None):
        body = json.dumps(payload).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        if link is not None:
            self.send_header("Link", link)
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        qs = parse_qs(parsed.query)
        page = qs.get("page", ["1"])[0]
        host = self.headers.get("Host", "127.0.0.1")
        if path.endswith("/releases/latest"):
            # Repo "latest" is the uninstallable stable release.
            self.reply(STABLE_UNINSTALLABLE)
        elif path.endswith("/releases"):
            if page == "1":
                nxt = f"http://{host}{path}?per_page=100&page=2"
                self.reply([STABLE_UNINSTALLABLE], link=f'<{nxt}>; rel="next"')
            else:
                self.reply([STABLE_INSTALLABLE])
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, *args):
        pass


socketserver.TCPServer.allow_reuse_address = True
with socketserver.TCPServer(("127.0.0.1", 0), Handler) as httpd:
    with open(port_file, "w") as fh:
        fh.write(str(httpd.server_address[1]))
    httpd.serve_forever()
PY
SERVER_PID=$!

for _ in $(seq 1 60); do
    [[ -s "$PORT_FILE" ]] && break
    kill -0 "$SERVER_PID" 2>/dev/null || { echo "FAIL: stand-in server exited early" >&2; exit 1; }
    sleep 0.5
done
PORT="$(cat "$PORT_FILE" 2>/dev/null || true)"
[[ -n "$PORT" ]] || { echo "FAIL: stand-in server did not report a port" >&2; exit 1; }
echo "stand-in forge API on 127.0.0.1:$PORT" >&2

TOOL="github:acme/tool[api_url=http://127.0.0.1:$PORT]"
fail() { echo "FAIL: $*" >&2; exit 1; }

LIST_OUT="$("$MISE_BIN" ls-remote --no-versions-host "$TOOL" 2>/dev/null)" \
    || fail "\`mise ls-remote\` exited non-zero"
echo "ls-remote output:" >&2
echo "$LIST_OUT" >&2

# fail_to_pass: paging must reach the installable release on page 2 even though
# the first stable release it saw (v1.0.0, on page 1) is uninstallable. A
# listing-only fix stops on v1.0.0, then filters it out, leaving no 2.0.0.
grep -qx "2.0.0" <<<"$LIST_OUT" \
    || fail "paging stopped on the uninstallable stable release; installable 2.0.0 never reached"

# The uninstallable stable release is not advertised.
if grep -qx "1.0.0" <<<"$LIST_OUT"; then
    fail "uninstallable release 1.0.0 is still listed by ls-remote"
fi

echo "PASS: paging reaches the installable stable release past an uninstallable one, which is filtered out" >&2
exit 0
