#!/usr/bin/env bash
#
# Behavioral verifier (fail_to_pass) for the direct-URL exemption and cache
# separation of the mise-fix-skip-assetless-releases task.
#
# A tool configured with per-platform direct download URLs can install a
# release that carries no forge assets, so for that tool those releases must
# stay listed and resolvable. And the exempted listing must NOT reuse the
# filtered listing that an earlier, unexempted query for the same repo + API
# URL populated — otherwise the exemption silently returns the filtered set.
#
# Observed only through `mise ls-remote` / `mise latest`. Names no source file,
# internal function, cache key, or release field. Any fix that keeps the
# exempted release listed and keeps the two listings from colliding passes,
# regardless of how the exemption and cache partitioning are implemented.
#
# Standalone script: isolated mise dirs + a python3 stdlib HTTP stand-in. Runs
# BOTH the unexempted and the exempted query in one process against one cache
# dir, so the cache-reuse hazard is actually exercised.

set -uo pipefail

MISE_BIN=""
for cand in \
    "${MISE_E2E_BIN:-}" \
    "${CARGO_TARGET_DIR:-/opt/cache/cargo-target}/debug/mise" \
    "/repo/mise/target/debug/mise" \
    "$(command -v mise 2>/dev/null || true)"; do
    if [[ -n "$cand" && -x "$cand" ]]; then
        MISE_BIN="$cand"
        break
    fi
done
[[ -n "$MISE_BIN" ]] || { echo "FAIL: could not locate a built mise binary" >&2; exit 1; }
echo "using mise binary: $MISE_BIN" >&2

WORK="$(mktemp -d "${TMPDIR:-/tmp}/mise-verify-direct.XXXXXX")"
cleanup() {
    [[ -n "${SERVER_PID:-}" ]] && kill "$SERVER_PID" 2>/dev/null || true
    rm -rf "$WORK" 2>/dev/null || true
}
trap cleanup EXIT

export HOME="$WORK/home"
export MISE_DATA_DIR="$HOME/.local/share/mise"
export MISE_CACHE_DIR="$HOME/.cache/mise"
export MISE_CONFIG_DIR="$HOME/.config/mise"
export MISE_STATE_DIR="$HOME/.local/state/mise"
export MISE_SYSTEM_DIR="$WORK/etc/mise"
export MISE_TMP_DIR="$WORK/tmp"
WORKDIR="$WORK/workdir"
mkdir -p "$HOME" "$MISE_DATA_DIR" "$MISE_CACHE_DIR" "$MISE_CONFIG_DIR" \
         "$MISE_STATE_DIR" "$MISE_SYSTEM_DIR" "$MISE_TMP_DIR" "$WORKDIR"
export MISE_YES=1
export MISE_EXPERIMENTAL=1
export MISE_USE_VERSIONS_HOST=0
export MISE_USE_VERSIONS_HOST_TRACK=0
# Trust the config we are about to write.
export MISE_TRUSTED_CONFIG_PATHS="$WORKDIR"
unset MISE_GITHUB_TOKEN GITHUB_TOKEN MISE_LIST_ALL_VERSIONS 2>/dev/null || true

# Stand-in: installable v2.0.0 plus uninstallable v3.0.0, with v3.0.0 served as
# the repo "latest". prerelease=true in the config makes `mise latest` resolve
# against the listing path rather than the "latest" shortcut.
PORT_FILE="$WORK/port"
python3 - "$PORT_FILE" <<'PY' &
import http.server
import json
import socketserver
import sys

port_file = sys.argv[1]

INSTALLABLE = {
    "tag_name": "v2.0.0",
    "draft": False,
    "prerelease": False,
    "created_at": "2026-02-01T00:00:00Z",
    "published_at": "2026-02-01T00:00:00Z",
    "assets": [
        {
            "name": "tool-x86_64-unknown-linux-gnu.tar.gz",
            "browser_download_url": "https://example.invalid/tool.tar.gz",
            "url": "https://example.invalid/api/tool.tar.gz",
        }
    ],
}

UNINSTALLABLE = {
    "tag_name": "v3.0.0",
    "draft": False,
    "prerelease": False,
    "created_at": "2026-03-01T00:00:00Z",
    "published_at": "2026-03-01T00:00:00Z",
    "assets": [],
}


class Handler(http.server.BaseHTTPRequestHandler):
    def reply(self, payload):
        body = json.dumps(payload).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = self.path.split("?")[0]
        if path.endswith("/releases/latest"):
            self.reply(UNINSTALLABLE)
        elif path.endswith("/releases"):
            self.reply([UNINSTALLABLE, INSTALLABLE])
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, *args):
        pass


socketserver.TCPServer.allow_reuse_address = True
with socketserver.TCPServer(("127.0.0.1", 0), Handler) as httpd:
    with open(port_file, "w") as fh:
        fh.write(str(httpd.server_address[1]))
    httpd.serve_forever()
PY
SERVER_PID=$!

for _ in $(seq 1 60); do
    [[ -s "$PORT_FILE" ]] && break
    kill -0 "$SERVER_PID" 2>/dev/null || { echo "FAIL: stand-in server exited early" >&2; exit 1; }
    sleep 0.5
done
PORT="$(cat "$PORT_FILE" 2>/dev/null || true)"
[[ -n "$PORT" ]] || { echo "FAIL: stand-in server did not report a port" >&2; exit 1; }
echo "stand-in forge API on 127.0.0.1:$PORT" >&2

cd "$WORKDIR"
fail() { echo "FAIL: $*" >&2; exit 1; }

# Step 1 — unexempted query for the plain tool. This populates the cache with
# the FILTERED listing (uninstallable release removed). Asserting the filtered
# behavior here also keeps step 2 honest: it proves the exempted result in
# step 2 is not just the generic listing.
UNEXEMPT_TOOL="github:acme/tool[api_url=http://127.0.0.1:$PORT]"
UNEXEMPT_OUT="$("$MISE_BIN" ls-remote --no-versions-host "$UNEXEMPT_TOOL" 2>/dev/null)" \
    || fail "unexempted \`mise ls-remote\` exited non-zero"
echo "unexempted ls-remote:" >&2; echo "$UNEXEMPT_OUT" >&2
grep -qx "2.0.0" <<<"$UNEXEMPT_OUT" \
    || fail "installable 2.0.0 missing from the unexempted listing"
if grep -qx "3.0.0" <<<"$UNEXEMPT_OUT"; then
    fail "unexempted listing still advertises the uninstallable 3.0.0"
fi

# Step 2 — configure per-platform direct URLs for the same repo + API URL. The
# tool can now install the asset-less release, so it must stay listed, and the
# exempted listing must not reuse the filtered cache entry from step 1.
cat > "$WORKDIR/mise.toml" <<EOF
[tools."github:acme/tool"]
version = "latest"
api_url = "http://127.0.0.1:$PORT"
prerelease = true

[tools."github:acme/tool".platforms]
linux-x64 = { url = "https://example.invalid/tool-linux-x64.tar.gz" }
linux-arm64 = { url = "https://example.invalid/tool-linux-arm64.tar.gz" }
macos-x64 = { url = "https://example.invalid/tool-macos-x64.tar.gz" }
macos-arm64 = { url = "https://example.invalid/tool-macos-arm64.tar.gz" }
EOF

CONFIGURED_TOOL="github:acme/tool"
EXEMPT_OUT="$("$MISE_BIN" ls-remote --no-versions-host "$CONFIGURED_TOOL" 2>/dev/null)" \
    || fail "exempted \`mise ls-remote\` exited non-zero"
echo "exempted ls-remote:" >&2; echo "$EXEMPT_OUT" >&2

# fail_to_pass: the asset-less release stays listed for the direct-URL tool,
# and did not inherit the filtered cache from step 1.
grep -qx "3.0.0" <<<"$EXEMPT_OUT" \
    || fail "direct-URL tool dropped the installable-via-URL release 3.0.0 (lost exemption or reused filtered cache)"
# The installable release is of course still listed too (over-correction guard).
grep -qx "2.0.0" <<<"$EXEMPT_OUT" \
    || fail "direct-URL tool listing lost the asset-bearing release 2.0.0"

# fail_to_pass: `mise latest` for the exempted tool resolves to the newest
# listed version, which is now the direct-URL-installable 3.0.0.
LATEST_OUT="$("$MISE_BIN" latest "$CONFIGURED_TOOL" 2>/dev/null | tr -d '[:space:]')" \
    || fail "exempted \`mise latest\` exited non-zero"
echo "exempted latest: '$LATEST_OUT'" >&2
[[ "$LATEST_OUT" == "3.0.0" ]] \
    || fail "exempted \`mise latest\` resolved to '$LATEST_OUT', expected 3.0.0"

echo "PASS: direct-URL tool keeps its asset-less release listed and resolvable, with no cache collision" >&2
exit 0
