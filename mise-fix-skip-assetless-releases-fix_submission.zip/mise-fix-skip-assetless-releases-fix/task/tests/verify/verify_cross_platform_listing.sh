#!/usr/bin/env bash
#
# Behavioral verifier (fail_to_pass) guarding the cross-platform constraint of
# the mise-fix-skip-assetless-releases task: the advertised versions for a tool
# must not depend on the OS or CPU architecture mise happens to be running on. A
# listing produced on one machine has to still resolve on another.
#
# A fix that advertises only releases carrying an asset for the CURRENT
# host/platform looks correct on the host that ran the other verifiers (it still
# drops the truly-empty release and keeps the host-matching one), but it makes
# the listing host-dependent: on a different OS/arch the same release would
# vanish. That is the exact forbidden fix the task narrative names.
#
# This script stands up a stand-in forge API whose only published stable release
# carries a SINGLE asset built for a platform that is NEITHER the CI host's OS
# nor its CPU architecture (aarch64-apple-darwin -- not Linux, not x86_64). The
# release is installable in principle (it has an uploaded asset), so an
# emptiness-based filter -- the reference implementation and every valid
# alternative -- keeps it listed. A current-platform-match filter has no asset
# matching the running host and drops it. Because the kept release has ONLY a
# non-host asset, this separation holds regardless of which host runs this
# script.
#
# Observed only through `mise ls-remote` / `mise latest` output. Names no source
# file, internal function, cache key, or release field -- any fix that keeps the
# listing host-independent passes, however it is implemented.
#
# Standalone script: isolated mise dirs + a python3 stdlib HTTP stand-in, polled
# for readiness, in the same shape as the other verify scripts.

set -uo pipefail

# ---------------------------------------------------------------------------
# Locate the built mise binary (debug build warmed by the image).
# ---------------------------------------------------------------------------
MISE_BIN=""
for cand in \
    "${MISE_E2E_BIN:-}" \
    "${CARGO_TARGET_DIR:-/opt/cache/cargo-target}/debug/mise" \
    "/repo/mise/target/debug/mise" \
    "$(command -v mise 2>/dev/null || true)"; do
    if [[ -n "$cand" && -x "$cand" ]]; then
        MISE_BIN="$cand"
        break
    fi
done
[[ -n "$MISE_BIN" ]] || { echo "FAIL: could not locate a built mise binary" >&2; exit 1; }
echo "using mise binary: $MISE_BIN" >&2

# ---------------------------------------------------------------------------
# Isolated, throwaway mise environment (no shared state, no network host).
# ---------------------------------------------------------------------------
WORK="$(mktemp -d "${TMPDIR:-/tmp}/mise-verify-xplat.XXXXXX")"
cleanup() {
    [[ -n "${SERVER_PID:-}" ]] && kill "$SERVER_PID" 2>/dev/null || true
    rm -rf "$WORK" 2>/dev/null || true
}
trap cleanup EXIT

export HOME="$WORK/home"
export MISE_DATA_DIR="$HOME/.local/share/mise"
export MISE_CACHE_DIR="$HOME/.cache/mise"
export MISE_CONFIG_DIR="$HOME/.config/mise"
export MISE_STATE_DIR="$HOME/.local/state/mise"
export MISE_SYSTEM_DIR="$WORK/etc/mise"
export MISE_TMP_DIR="$WORK/tmp"
mkdir -p "$HOME" "$MISE_DATA_DIR" "$MISE_CACHE_DIR" "$MISE_CONFIG_DIR" \
         "$MISE_STATE_DIR" "$MISE_SYSTEM_DIR" "$MISE_TMP_DIR"
export MISE_YES=1
export MISE_EXPERIMENTAL=1
export MISE_USE_VERSIONS_HOST=0
export MISE_USE_VERSIONS_HOST_TRACK=0
unset MISE_GITHUB_TOKEN GITHUB_TOKEN MISE_LIST_ALL_VERSIONS 2>/dev/null || true

# ---------------------------------------------------------------------------
# Forge-API stand-in: one published, non-draft, non-prerelease release whose
# ONLY asset targets a platform that is neither this host's OS nor its arch.
# aarch64-apple-darwin is non-Linux and non-x86_64, so no current-host-match
# filter can match it on any CI host this suite runs on.
# ---------------------------------------------------------------------------
PORT_FILE="$WORK/port"
python3 - "$PORT_FILE" <<'PY' &
import http.server
import json
import socketserver
import sys

port_file = sys.argv[1]

# Single stable release. Installable in principle (has an uploaded asset), but
# the asset targets a non-host platform. Emptiness-based filtering keeps it;
# current-platform-match filtering drops it.
NON_HOST_PLATFORM = {
    "tag_name": "v4.0.0",
    "draft": False,
    "prerelease": False,
    "created_at": "2026-04-01T00:00:00Z",
    "published_at": "2026-04-01T00:00:00Z",
    "assets": [
        {
            "name": "tool-aarch64-apple-darwin.tar.gz",
            "browser_download_url": "https://example.invalid/tool-aarch64-apple-darwin.tar.gz",
            "url": "https://example.invalid/api/tool-aarch64-apple-darwin.tar.gz",
        }
    ],
}


class Handler(http.server.BaseHTTPRequestHandler):
    def reply(self, payload):
        body = json.dumps(payload).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = self.path.split("?")[0]
        if path.endswith("/releases/latest"):
            self.reply(NON_HOST_PLATFORM)
        elif path.endswith("/releases"):
            self.reply([NON_HOST_PLATFORM])
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, *args):
        pass


socketserver.TCPServer.allow_reuse_address = True
with socketserver.TCPServer(("127.0.0.1", 0), Handler) as httpd:
    with open(port_file, "w") as fh:
        fh.write(str(httpd.server_address[1]))
    httpd.serve_forever()
PY
SERVER_PID=$!

# Wait for the server to publish its port.
for _ in $(seq 1 60); do
    [[ -s "$PORT_FILE" ]] && break
    kill -0 "$SERVER_PID" 2>/dev/null || { echo "FAIL: stand-in server exited early" >&2; exit 1; }
    sleep 0.5
done
PORT="$(cat "$PORT_FILE" 2>/dev/null || true)"
[[ -n "$PORT" ]] || { echo "FAIL: stand-in server did not report a port" >&2; exit 1; }
echo "stand-in forge API on 127.0.0.1:$PORT" >&2

TOOL="github:acme/tool[api_url=http://127.0.0.1:$PORT]"
fail() { echo "FAIL: $*" >&2; exit 1; }

# ---------------------------------------------------------------------------
# Assertion: the release stays listed even though its only asset targets a
# non-host platform. A host-independent (emptiness-based) filter keeps it; a
# current-platform-match filter drops it regardless of which host runs this.
# ---------------------------------------------------------------------------
LIST_OUT="$("$MISE_BIN" ls-remote --no-versions-host "$TOOL" 2>/dev/null)" \
    || fail "\`mise ls-remote\` exited non-zero"
echo "ls-remote output:" >&2
echo "$LIST_OUT" >&2

grep -qx "4.0.0" <<<"$LIST_OUT" \
    || fail "release 4.0.0 (asset only for a non-host platform) is missing from ls-remote; the listing depends on the running host's OS/arch"

# `mise latest` must agree: with the release listed, latest resolves to it
# rather than reporting nothing on a non-host architecture.
LATEST_OUT="$("$MISE_BIN" latest "$TOOL" 2>/dev/null | tr -d '[:space:]')" \
    || fail "\`mise latest\` exited non-zero"
echo "latest output: '$LATEST_OUT'" >&2
[[ "$LATEST_OUT" == "4.0.0" ]] \
    || fail "\`mise latest\` resolved to '$LATEST_OUT', expected 4.0.0 (listing is host-dependent)"

echo "PASS: a release whose only asset targets a non-host platform stays listed and resolvable; the listing is host-independent" >&2
exit 0
