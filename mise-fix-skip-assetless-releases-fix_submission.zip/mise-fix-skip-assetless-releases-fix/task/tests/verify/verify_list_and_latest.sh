#!/usr/bin/env bash
#
# Behavioral verifier (fail_to_pass + pass_to_pass guard) for the
# mise-fix-skip-assetless-releases task.
#
# Covers three test_criteria through the pre-existing `mise` CLI:
#   * `mise ls-remote` lists the installable release and omits the
#     uninstallable one (criterion 1, fail_to_pass).
#   * `mise latest` agrees with the filtered listing instead of taking the
#     forge "latest" shortcut to the uninstallable release (criterion 2,
#     fail_to_pass).
#   * the installable release is ALWAYS listed, in every scenario, so the
#     fix did not "solve" the symptom by emptying/short-circuiting the
#     listing (criterion 5, pass_to_pass guard — asserted first on every
#     query so nothing can pass vacuously).
#
# The behavior is observed only through `mise ls-remote` / `mise latest`
# output. Nothing here names a source file, an internal function, or a
# release field that mise reads — an alternative fix that filters at a
# different layer, inlines its helpers, or renames anything still passes.
#
# This is a standalone script (the repo's own e2e harness guards on an
# environment it builds itself); it stands up its own isolated mise dirs and
# a python3 stdlib HTTP stand-in for the forge releases API, exactly the way
# the repo's e2e/backend tests do, and drives the built `mise` binary.

set -uo pipefail

# ---------------------------------------------------------------------------
# Locate the built mise binary (debug build warmed by the image).
# ---------------------------------------------------------------------------
MISE_BIN=""
for cand in \
    "${MISE_E2E_BIN:-}" \
    "${CARGO_TARGET_DIR:-/opt/cache/cargo-target}/debug/mise" \
    "/repo/mise/target/debug/mise" \
    "$(command -v mise 2>/dev/null || true)"; do
    if [[ -n "$cand" && -x "$cand" ]]; then
        MISE_BIN="$cand"
        break
    fi
done
if [[ -z "$MISE_BIN" ]]; then
    echo "FAIL: could not locate a built mise binary" >&2
    exit 1
fi
echo "using mise binary: $MISE_BIN" >&2

# ---------------------------------------------------------------------------
# Isolated, throwaway mise environment (no shared state, no network host).
# ---------------------------------------------------------------------------
WORK="$(mktemp -d "${TMPDIR:-/tmp}/mise-verify-list.XXXXXX")"
cleanup() {
    [[ -n "${SERVER_PID:-}" ]] && kill "$SERVER_PID" 2>/dev/null || true
    rm -rf "$WORK" 2>/dev/null || true
}
trap cleanup EXIT

export HOME="$WORK/home"
export MISE_DATA_DIR="$HOME/.local/share/mise"
export MISE_CACHE_DIR="$HOME/.cache/mise"
export MISE_CONFIG_DIR="$HOME/.config/mise"
export MISE_STATE_DIR="$HOME/.local/state/mise"
export MISE_SYSTEM_DIR="$WORK/etc/mise"
export MISE_TMP_DIR="$WORK/tmp"
mkdir -p "$HOME" "$MISE_DATA_DIR" "$MISE_CACHE_DIR" "$MISE_CONFIG_DIR" \
         "$MISE_STATE_DIR" "$MISE_SYSTEM_DIR" "$MISE_TMP_DIR"
export MISE_YES=1
export MISE_EXPERIMENTAL=1
# Keep every lookup on our local stand-in; never consult the hosted
# version-metadata service or real forge APIs.
export MISE_USE_VERSIONS_HOST=0
export MISE_USE_VERSIONS_HOST_TRACK=0
unset MISE_GITHUB_TOKEN GITHUB_TOKEN 2>/dev/null || true

# ---------------------------------------------------------------------------
# Forge-API stand-in: a published, non-draft, non-prerelease release that has
# an installable asset (v2.0.0) and one that has nothing to install (v3.0.0).
# The repo's "latest" endpoint returns the uninstallable one, so a fix that
# leaves the latest shortcut alone resolves `mise latest` to it.
# ---------------------------------------------------------------------------
PORT_FILE="$WORK/port"
python3 - "$PORT_FILE" <<'PY' &
import http.server
import json
import socketserver
import sys

port_file = sys.argv[1]

INSTALLABLE = {
    "tag_name": "v2.0.0",
    "draft": False,
    "prerelease": False,
    "created_at": "2026-02-01T00:00:00Z",
    "published_at": "2026-02-01T00:00:00Z",
    "assets": [
        {
            "name": "tool-x86_64-unknown-linux-gnu.tar.gz",
            "browser_download_url": "https://example.invalid/tool.tar.gz",
            "url": "https://example.invalid/api/tool.tar.gz",
        }
    ],
}

UNINSTALLABLE = {
    "tag_name": "v3.0.0",
    "draft": False,
    "prerelease": False,
    "created_at": "2026-03-01T00:00:00Z",
    "published_at": "2026-03-01T00:00:00Z",
    "assets": [],
}


class Handler(http.server.BaseHTTPRequestHandler):
    def reply(self, payload):
        body = json.dumps(payload).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = self.path.split("?")[0]
        if path.endswith("/releases/latest"):
            self.reply(UNINSTALLABLE)
        elif path.endswith("/releases"):
            self.reply([UNINSTALLABLE, INSTALLABLE])
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, *args):
        pass


socketserver.TCPServer.allow_reuse_address = True
with socketserver.TCPServer(("127.0.0.1", 0), Handler) as httpd:
    with open(port_file, "w") as fh:
        fh.write(str(httpd.server_address[1]))
    httpd.serve_forever()
PY
SERVER_PID=$!

# Wait for the server to publish its port.
for _ in $(seq 1 60); do
    [[ -s "$PORT_FILE" ]] && break
    kill -0 "$SERVER_PID" 2>/dev/null || { echo "FAIL: stand-in server exited early" >&2; exit 1; }
    sleep 0.5
done
PORT="$(cat "$PORT_FILE" 2>/dev/null || true)"
if [[ -z "$PORT" ]]; then
    echo "FAIL: stand-in server did not report a port" >&2
    exit 1
fi
echo "stand-in forge API on 127.0.0.1:$PORT" >&2

TOOL="github:acme/tool[api_url=http://127.0.0.1:$PORT]"

# ---------------------------------------------------------------------------
# Assertions.
# ---------------------------------------------------------------------------
fail() { echo "FAIL: $*" >&2; exit 1; }

LIST_OUT="$("$MISE_BIN" ls-remote --no-versions-host "$TOOL" 2>/dev/null)" \
    || fail "\`mise ls-remote\` exited non-zero"
echo "ls-remote output:" >&2
echo "$LIST_OUT" >&2

# pass_to_pass guard (criterion 5): the installable release is always listed.
# Asserted FIRST so the omission check below cannot pass on an empty listing.
grep -qx "2.0.0" <<<"$LIST_OUT" \
    || fail "installable release 2.0.0 missing from ls-remote (over-correction / empty listing)"

# fail_to_pass (criterion 1): the uninstallable release is omitted.
if grep -qx "3.0.0" <<<"$LIST_OUT"; then
    fail "uninstallable release 3.0.0 is still listed by ls-remote"
fi

# fail_to_pass (criterion 2): `mise latest` agrees with the filtered listing
# rather than taking the forge "latest" shortcut to the uninstallable release.
LATEST_OUT="$("$MISE_BIN" latest "$TOOL" 2>/dev/null | tr -d '[:space:]')" \
    || fail "\`mise latest\` exited non-zero"
echo "latest output: '$LATEST_OUT'" >&2
[[ "$LATEST_OUT" == "2.0.0" ]] \
    || fail "\`mise latest\` resolved to '$LATEST_OUT', expected 2.0.0"

echo "PASS: ls-remote filters the uninstallable release, keeps the installable one, and latest agrees" >&2
exit 0
