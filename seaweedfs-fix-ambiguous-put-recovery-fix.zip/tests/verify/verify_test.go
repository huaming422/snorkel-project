package s3api

// Behavioral checks for the routed-PUT recovery decision, exercised through the
// stable in-package entry points (*S3ApiServer).putToFiler and
// (*S3ApiServer).objectTxnOnFiler. Every fake and helper here is uniquely named
// (arp* / TestVerify*) so the file coexists with the package's own test
// infrastructure without redeclaration, and it reads no source and names no
// internal of the change under test — it asserts only on observable results
// (the returned s3err.ErrorCode, the backup filer's call count, whether a
// stored entry survived).

import (
	"context"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"sync/atomic"
	"testing"

	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/proto"

	"github.com/seaweedfs/seaweedfs/weed/cluster"
	"github.com/seaweedfs/seaweedfs/weed/pb"
	"github.com/seaweedfs/seaweedfs/weed/pb/filer_pb"
	"github.com/seaweedfs/seaweedfs/weed/pb/volume_server_pb"
	"github.com/seaweedfs/seaweedfs/weed/s3api/s3_constants"
	"github.com/seaweedfs/seaweedfs/weed/s3api/s3err"
	"github.com/seaweedfs/seaweedfs/weed/wdclient"
)

// ---------------------------------------------------------------------------
// Fake volume server: serves the two volume-server calls a PUT makes — chunk
// upload/GET over HTTP and a HEAD existence probe — plus a gRPC BatchDelete
// that records which fids were reclaimed. Self-contained; no overlap with the
// package's own fake.
// ---------------------------------------------------------------------------

type arpVolume struct {
	volume_server_pb.UnimplementedVolumeServerServer
	httpAddr string
	grpcPort uint32

	mu      sync.Mutex
	deleted []string
	stored  map[string][]byte
}

func (v *arpVolume) BatchDelete(_ context.Context, req *volume_server_pb.BatchDeleteRequest) (*volume_server_pb.BatchDeleteResponse, error) {
	v.mu.Lock()
	defer v.mu.Unlock()
	resp := &volume_server_pb.BatchDeleteResponse{}
	for _, fid := range req.FileIds {
		v.deleted = append(v.deleted, fid)
		resp.Results = append(resp.Results, &volume_server_pb.DeleteResult{FileId: fid, Status: http.StatusAccepted})
	}
	return resp, nil
}

func (v *arpVolume) deletedFids() []string {
	v.mu.Lock()
	defer v.mu.Unlock()
	return append([]string(nil), v.deleted...)
}

func startARPVolume(t *testing.T) *arpVolume {
	t.Helper()
	v := &arpVolume{stored: map[string][]byte{}}
	upload := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		fid := strings.TrimPrefix(r.URL.Path, "/")
		switch r.Method {
		case http.MethodGet:
			v.mu.Lock()
			data, ok := v.stored[fid]
			v.mu.Unlock()
			if !ok {
				w.WriteHeader(http.StatusNotFound)
				return
			}
			w.Write(data)
		case http.MethodHead:
			// The existence probe used when a recovery must confirm the
			// uploaded chunks still survive before re-committing.
			v.mu.Lock()
			_, ok := v.stored[fid]
			v.mu.Unlock()
			if !ok {
				w.WriteHeader(http.StatusNotFound)
				return
			}
			w.WriteHeader(http.StatusOK)
		default:
			data, _ := io.ReadAll(r.Body)
			v.mu.Lock()
			v.stored[fid] = data
			v.mu.Unlock()
			w.Header().Set("Content-MD5", r.Header.Get("Content-MD5"))
			w.WriteHeader(http.StatusCreated)
			io.WriteString(w, `{"size":1}`)
		}
	}))
	t.Cleanup(upload.Close)
	v.httpAddr = strings.TrimPrefix(upload.URL, "http://")

	lis, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	grpcSrv := grpc.NewServer()
	volume_server_pb.RegisterVolumeServerServer(grpcSrv, v)
	go grpcSrv.Serve(lis)
	t.Cleanup(grpcSrv.Stop)
	v.grpcPort = uint32(lis.Addr().(*net.TCPAddr).Port)
	return v
}

// ---------------------------------------------------------------------------
// Fake filer: a programmable SeaweedFiler that reproduces the ambiguous-route
// incident. The routed transaction can report an error while having applied
// (or not applied) its mutation, and can swap in a concurrent write as it
// commits. CreateEntry honours the write condition the recovery sends and
// counts how many times it actually stored an entry, so a test can tell a
// re-commit from a refusal. Entry.Extended is stored and returned verbatim, so
// any per-write identity marker a fix stamps rides through transparently — the
// fake neither sets nor inspects any particular marker key.
// ---------------------------------------------------------------------------

type arpFiler struct {
	filer_pb.UnimplementedSeaweedFilerServer
	volume *arpVolume

	mu      sync.Mutex
	entries map[string]*filer_pb.Entry
	nextKey uint64

	// Routed-transaction behaviour.
	txnErr     error            // error the ObjectTransaction reports
	txnNoApply bool             // true: the transaction did not apply its mutation
	supersede  *filer_pb.Entry  // once: a concurrent write swapped in as the txn commits

	// Fallback-create behaviour.
	createErr error // transport error the CreateEntry reports (after honouring the condition)

	// Hooks to land a racing write at the worst moment.
	beforeCreate func()
	beforeLookup func()

	// Observations.
	stores int                      // successful CreateEntry stores
	conds  []*filer_pb.WriteCondition
}

func (f *arpFiler) AssignVolume(context.Context, *filer_pb.AssignVolumeRequest) (*filer_pb.AssignVolumeResponse, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.nextKey++
	return &filer_pb.AssignVolumeResponse{
		FileId: fmt.Sprintf("3,%016x%08x", f.nextKey, uint32(f.nextKey)),
		Count:  1,
		Location: &filer_pb.Location{
			Url:       f.volume.httpAddr,
			PublicUrl: f.volume.httpAddr,
			GrpcPort:  f.volume.grpcPort,
		},
	}, nil
}

// arpConditionOK mirrors the filer's own clause evaluation for the condition
// kinds an ambiguous-route recovery can emit. An unconditional create always
// passes; an unrecognised clause is treated as unsatisfiable so a test never
// silently accepts a create it did not model.
func arpConditionOK(cond *filer_pb.WriteCondition, current *filer_pb.Entry) bool {
	for _, c := range cond.GetClauses() {
		switch c.Kind {
		case filer_pb.WriteCondition_IF_NOT_EXISTS:
			if current != nil {
				return false
			}
		case filer_pb.WriteCondition_IF_ENTRY_EQUAL:
			if (current == nil) != (c.ExpectedEntry == nil) {
				return false
			}
			if current != nil && !proto.Equal(current, c.ExpectedEntry) {
				return false
			}
		default:
			return false
		}
	}
	return true
}

func (f *arpFiler) CreateEntry(_ context.Context, req *filer_pb.CreateEntryRequest) (*filer_pb.CreateEntryResponse, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.beforeCreate != nil {
		f.beforeCreate()
	}
	f.conds = append(f.conds, req.Condition)
	key := req.Directory + "/" + req.Entry.Name
	if !arpConditionOK(req.Condition, f.entries[key]) {
		return &filer_pb.CreateEntryResponse{Error: "precondition failed", ErrorCode: filer_pb.FilerError_PRECONDITION_FAILED}, nil
	}
	entry := proto.Clone(req.Entry).(*filer_pb.Entry)
	filer_pb.BeforeEntrySerialization(entry.Chunks)
	f.entries[key] = entry
	f.stores++
	if f.createErr != nil {
		return nil, f.createErr
	}
	return &filer_pb.CreateEntryResponse{}, nil
}

func (f *arpFiler) LookupDirectoryEntry(_ context.Context, req *filer_pb.LookupDirectoryEntryRequest) (*filer_pb.LookupDirectoryEntryResponse, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.beforeLookup != nil {
		f.beforeLookup()
	}
	if entry, ok := f.entries[req.Directory+"/"+req.Name]; ok {
		out := proto.Clone(entry).(*filer_pb.Entry)
		filer_pb.AfterEntryDeserialization(out.Chunks)
		return &filer_pb.LookupDirectoryEntryResponse{Entry: out}, nil
	}
	return &filer_pb.LookupDirectoryEntryResponse{}, nil
}

func (f *arpFiler) ObjectTransaction(_ context.Context, req *filer_pb.ObjectTransactionRequest) (*filer_pb.ObjectTransactionResponse, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	if !f.txnNoApply {
		for _, m := range req.Mutations {
			if m.Type == filer_pb.ObjectMutation_PUT {
				entry := proto.Clone(m.Entry).(*filer_pb.Entry)
				filer_pb.BeforeEntrySerialization(entry.Chunks)
				f.entries[m.Directory+"/"+m.Entry.Name] = entry
			}
		}
	}
	if f.supersede != nil {
		f.entries[req.LockKey] = f.supersede
		f.supersede = nil
	}
	return &filer_pb.ObjectTransactionResponse{}, f.txnErr
}

func (f *arpFiler) LookupVolume(_ context.Context, req *filer_pb.LookupVolumeRequest) (*filer_pb.LookupVolumeResponse, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	resp := &filer_pb.LookupVolumeResponse{LocationsMap: map[string]*filer_pb.Locations{}}
	for _, vid := range req.VolumeIds {
		resp.LocationsMap[vid] = &filer_pb.Locations{Locations: []*filer_pb.Location{{
			Url:       f.volume.httpAddr,
			PublicUrl: f.volume.httpAddr,
			GrpcPort:  f.volume.grpcPort,
		}}}
	}
	return resp, nil
}

func (f *arpFiler) storeCount() int {
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.stores
}

func (f *arpFiler) entryAt(key string) *filer_pb.Entry {
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.entries[key]
}

// arpReplayProbe only observes transaction delivery. Keeping this probe in the
// injected verifier avoids depending on mutable repository test helpers.
type arpReplayProbe struct {
	filer_pb.UnimplementedSeaweedFilerServer
	err   error
	calls int32
}

func (f *arpReplayProbe) ObjectTransaction(_ context.Context, _ *filer_pb.ObjectTransactionRequest) (*filer_pb.ObjectTransactionResponse, error) {
	atomic.AddInt32(&f.calls, 1)
	return &filer_pb.ObjectTransactionResponse{}, f.err
}

// ---------------------------------------------------------------------------
// Harness wiring.
// ---------------------------------------------------------------------------

// startARPFiler serves impl on a random localhost port and returns the S3-style
// filer address whose ToGrpcAddress resolves back to that port.
func startARPFiler(t *testing.T, impl filer_pb.SeaweedFilerServer) pb.ServerAddress {
	t.Helper()
	lis, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	srv := grpc.NewServer()
	filer_pb.RegisterSeaweedFilerServer(srv, impl)
	go srv.Serve(lis)
	t.Cleanup(srv.Stop)
	port := lis.Addr().(*net.TCPAddr).Port
	return pb.ServerAddress(fmt.Sprintf("127.0.0.1:1.%d", port))
}

// newARPServer builds an S3 gateway pointed at the given filers and makes writes
// route to the first one via the per-key ring owner, so a PUT exercises the
// routed-write path and its ambiguous-recovery fallback.
func newARPServer(t *testing.T, filerAddrs ...pb.ServerAddress) *S3ApiServer {
	t.Helper()
	dialOption := grpc.WithTransportCredentials(insecure.NewCredentials())
	s3a := &S3ApiServer{
		option: &S3ApiServerOption{
			Filers:         filerAddrs,
			GrpcDialOption: dialOption,
			BucketsPath:    "/buckets",
		},
		filerClient: wdclient.NewFilerClient(filerAddrs, dialOption, ""),
	}
	s3a.objectWriteLockClient = cluster.NewLockClient(s3a.option.GrpcDialOption, filerAddrs[0])
	s3a.objectWriteLockClient.SetRing([]pb.ServerAddress{filerAddrs[0]}, 1)
	return s3a
}

// arpPut drives a PUT of body through putToFiler with the stable 10-arg
// signature and returns the observable result code.
func arpPut(s3a *S3ApiServer, body string) s3err.ErrorCode {
	r := httptest.NewRequest(http.MethodPut, "/b/o", nil)
	_, code, _ := s3a.putToFiler(r, "/buckets/b/o", strings.NewReader(body), "b", "o", 1, 0, nil, false, "")
	return code
}

func arpChunkEntry(size uint64, fid string) *filer_pb.Entry {
	return &filer_pb.Entry{
		Name:       "o",
		Attributes: &filer_pb.FuseAttributes{FileSize: size},
		Chunks:     []*filer_pb.FileChunk{{FileId: fid, Size: size}},
	}
}

// ---------------------------------------------------------------------------
// Keeps the newer write — a routed PUT commits, its response is lost, and a
// concurrent client retry supersedes the entry (its cleanup reclaimed this
// write's chunks). Recovery must refuse rather than re-commit the stale entry
// over the newer write. Chunk lists alone cannot tell this write's commit from
// a superseded one when the stored entry carries no chunks to compare, so the
// zero-byte variant is the revealing case: an unconditional fallback create
// would overwrite the newer write.
// ---------------------------------------------------------------------------

func TestVerifyAmbiguousKeepsNewerWrite(t *testing.T) {
	volume := startARPVolume(t)
	newer := arpChunkEntry(11, "3,00000000000000bb0000000b")
	filerImpl := &arpFiler{
		volume:    volume,
		entries:   map[string]*filer_pb.Entry{},
		supersede: newer,
		txnErr:    status.Error(codes.Unavailable, "owner restarted mid-write"),
	}
	s3a := newARPServer(t, startARPFiler(t, filerImpl))

	// A refusal is any non-success result: the write must not be reported as
	// having landed when a newer write now holds the key. The specific code is
	// a fix's choice; what matters is that success is not claimed.
	if code := arpPut(s3a, ""); code == s3err.ErrNone {
		t.Fatalf("putToFiler = ErrNone, want refusal once a newer write is found")
	}
	if n := filerImpl.storeCount(); n != 0 {
		t.Fatalf("recovery re-committed the stale entry %d times", n)
	}
	got := filerImpl.entryAt("/buckets/b/o")
	if got == nil || len(got.Chunks) == 0 || got.Chunks[0].FileId != newer.Chunks[0].FileId {
		t.Fatalf("the newer write's entry was clobbered: %+v", got)
	}
	if d := volume.deletedFids(); len(d) != 0 {
		t.Fatalf("chunks were deleted during recovery: %v", d)
	}
}

// ---------------------------------------------------------------------------
// Recovery loses the race — the routed PUT never committed; recovery finds the
// key absent, but a concurrent write lands before the fallback create takes
// effect. The create must serialize against that racer (evaluated under the
// owner's path lock) and refuse, not overwrite the race winner.
// ---------------------------------------------------------------------------

func TestVerifyRecoveryLosesRace(t *testing.T) {
	volume := startARPVolume(t)
	newer := arpChunkEntry(11, "3,00000000000000bb0000000b")
	filerImpl := &arpFiler{
		volume:     volume,
		entries:    map[string]*filer_pb.Entry{},
		txnNoApply: true,
		txnErr:     status.Error(codes.Unavailable, "response lost"),
	}
	// A racing write lands inside the fallback create's critical section,
	// after recovery observed the key absent.
	filerImpl.beforeCreate = func() {
		filerImpl.entries["/buckets/b/o"] = newer
		filerImpl.beforeCreate = nil
	}
	s3a := newARPServer(t, startARPFiler(t, filerImpl))

	// Refusal is observable as "not success"; the particular error code a fix
	// returns here is its own choice and is not asserted.
	if code := arpPut(s3a, "hello world"); code == s3err.ErrNone {
		t.Fatalf("putToFiler = ErrNone, want refusal after losing the create race")
	}
	if n := filerImpl.storeCount(); n != 0 {
		t.Fatalf("the raced recovery create stored %d entries", n)
	}
	got := filerImpl.entryAt("/buckets/b/o")
	if got == nil || len(got.Chunks) == 0 || got.Chunks[0].FileId != newer.Chunks[0].FileId {
		t.Fatalf("the racing write's entry was clobbered: %+v", got)
	}
}

// ---------------------------------------------------------------------------
// Empty PUT that landed — a zero-byte PUT committed on the owner and only its
// response was lost. The stored entry is this write's own (it carries whatever
// identity the write stamped), so recovery must confirm success rather than
// fail a write that landed, and must not store a second copy.
// ---------------------------------------------------------------------------

func TestVerifyEmptyPutLanded(t *testing.T) {
	volume := startARPVolume(t)
	filerImpl := &arpFiler{
		volume:  volume,
		entries: map[string]*filer_pb.Entry{},
		// Apply the mutation (the commit landed) but report the response as lost.
		txnErr: status.Error(codes.Unavailable, "response lost after commit"),
	}
	s3a := newARPServer(t, startARPFiler(t, filerImpl))

	if code := arpPut(s3a, ""); code != s3err.ErrNone {
		t.Fatalf("putToFiler = %v, want success — the stored empty entry is this write's own commit", code)
	}
	if n := filerImpl.storeCount(); n != 0 {
		t.Fatalf("recovery re-committed an already-stored entry %d times", n)
	}
}

// ---------------------------------------------------------------------------
// Empty PUT over a foreign entry — a zero-byte PUT's response was lost before it
// committed; the key already holds an older empty object. Matching metadata
// (etag, size) cannot prove the stored entry is this write's commit, and a
// foreign identity marker proves it is not. Recovery must refuse rather than
// claim or overwrite it.
// ---------------------------------------------------------------------------

func TestVerifyEmptyPutForeignEntry(t *testing.T) {
	volume := startARPVolume(t)
	foreign := &filer_pb.Entry{
		Name:       "o",
		Attributes: &filer_pb.FuseAttributes{Mime: "application/octet-stream"},
		Extended: map[string][]byte{
			s3_constants.ExtETagKey: []byte("\"d41d8cd98f00b204e9800998ecf8427e\""),
			// A marker left by a different write. Keyed on a name no real write
			// stamps, so a correct fix cannot mistake it for its own identity.
			"x-arp-foreign-write-marker": []byte("another-write"),
		},
	}
	filerImpl := &arpFiler{
		volume:     volume,
		txnNoApply: true,
		txnErr:     status.Error(codes.Unavailable, "response lost before commit"),
		entries:    map[string]*filer_pb.Entry{"/buckets/b/o": foreign},
	}
	s3a := newARPServer(t, startARPFiler(t, filerImpl))

	// The refusal is observed as a non-success result; the specific code is a
	// fix's own choice and is not pinned.
	if code := arpPut(s3a, ""); code == s3err.ErrNone {
		t.Fatalf("putToFiler = ErrNone, want refusal when the stored empty entry is not this write's")
	}
	if n := filerImpl.storeCount(); n != 0 {
		t.Fatalf("recovery committed over an unverifiable empty entry %d times", n)
	}
	got := filerImpl.entryAt("/buckets/b/o")
	if got == nil || string(got.GetExtended()["x-arp-foreign-write-marker"]) != "another-write" {
		t.Fatalf("the older object's entry was replaced: %+v", got)
	}
}

// ---------------------------------------------------------------------------
// No replay after send — a transaction whose response was lost on the
// owner must NOT be re-sent to a backup filer: a lost response is
// indistinguishable from a commit, so a replay could re-apply the mutation. The
// owner returns Unavailable after a possible commit; the backup must see zero
// calls. Exercised through the stable objectTxnOnFiler.
// ---------------------------------------------------------------------------

func TestVerifyTxnNoReplayAfterSend(t *testing.T) {
	owner := &arpReplayProbe{err: status.Error(codes.Unavailable, "response lost")}
	ownerAddr := startARPFiler(t, owner)
	backup := &arpReplayProbe{}
	backupAddr := startARPFiler(t, backup)

	dialOption := grpc.WithTransportCredentials(insecure.NewCredentials())
	s3a := &S3ApiServer{
		option:      &S3ApiServerOption{GrpcDialOption: dialOption},
		filerClient: wdclient.NewFilerClient([]pb.ServerAddress{ownerAddr, backupAddr}, dialOption, ""),
	}
	req := &filer_pb.ObjectTransactionRequest{LockKey: "/buckets/b/o", RouteKey: "s3.object.write:/buckets/b/o"}

	if _, err := s3a.objectTxnOnFiler(ownerAddr, req); err == nil {
		t.Fatal("expected the lost response to surface as an error")
	}
	if got := atomic.LoadInt32(&backup.calls); got != 0 {
		t.Fatalf("backup filer calls = %d — replayed a possibly-committed transaction", got)
	}
}

// ---------------------------------------------------------------------------
// Normal PUT still succeeds — an ordinary, unambiguous PUT to an absent key
// still creates the object and returns success. Guards against a blanket-refuse
// shortcut that would satisfy the refusal cases while dropping legitimate
// writes.
// ---------------------------------------------------------------------------

func TestVerifyNormalPutSucceeds(t *testing.T) {
	volume := startARPVolume(t)
	filerImpl := &arpFiler{
		volume:  volume,
		entries: map[string]*filer_pb.Entry{},
		// No txnErr: the routed transaction commits cleanly.
	}
	s3a := newARPServer(t, startARPFiler(t, filerImpl))

	if code := arpPut(s3a, "hello world"); code != s3err.ErrNone {
		t.Fatalf("unambiguous PUT = %v, want success", code)
	}
	if filerImpl.entryAt("/buckets/b/o") == nil {
		t.Fatal("the object was not created by a normal PUT")
	}
}

// A routed transaction that did not apply can still be recovered when the
// entry is absent and its uploaded chunk remains available.
func TestVerifyAbsentRoutedPutRecovers(t *testing.T) {
	volume := startARPVolume(t)
	filerImpl := &arpFiler{
		volume:     volume,
		entries:    map[string]*filer_pb.Entry{},
		txnNoApply: true,
		txnErr:     status.Error(codes.Unavailable, "response lost before commit"),
	}
	s3a := newARPServer(t, startARPFiler(t, filerImpl))
	if code := arpPut(s3a, "hello world"); code != s3err.ErrNone {
		t.Fatalf("recoverable routed PUT = %v, want success", code)
	}
	if n := filerImpl.storeCount(); n != 1 {
		t.Fatalf("recovery stored %d entries, want one", n)
	}
	if got := filerImpl.entryAt("/buckets/b/o"); got == nil || len(got.Chunks) == 0 {
		t.Fatalf("recovery left no object data: %+v", got)
	}
}
