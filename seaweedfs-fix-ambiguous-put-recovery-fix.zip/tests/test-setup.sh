#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# The image baked the full module closure at the base commit plus a warm build
# cache, so this must run with the network cut (the smoke gate's offline fold
# sources it inside `docker run --network none`). Export Go's offline switches
# right after cd so a cache miss fails fast instead of reaching a proxy.
cd /repo/seaweedfs
export GOFLAGS=-mod=mod GOPROXY=off

# Dependencies: offline-first against the image bake, logged online fallback.
if go mod download > /tmp/test-setup-godl.log 2>&1; then
    echo "[offline-first] go mod satisfied from image"
elif GOPROXY= GOFLAGS= go mod download >> /tmp/test-setup-godl.log 2>&1; then
    echo "[test-setup] go mod downloaded online (image bake was stale)"
else
    tail -40 /tmp/test-setup-godl.log >&2; exit 1
fi

# No services and no data seeding: the s3api recovery tests stand up their own
# in-process fake filers (httptest + in-process gRPC). No assertion logic here.
