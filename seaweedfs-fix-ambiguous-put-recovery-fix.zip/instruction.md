## Task

Our S3 gateway writes objects through a filer. For read after write consistency, it sometimes sends a PUT to the filer that owns that key. Those routed PUTs have an intermittent data loss problem. When the gateway gets no definite answer about whether a write landed, it attempts recovery. Afterward, an object the client stored may be missing or may contain another write's data. PUTs that receive a clear result do not show the problem.

Investigate and repair the gateway's write and recovery path. Recovery must protect an existing write when another writer has taken the key, while still completing a write that can safely be recovered. Keep the S3 protocol behavior clients rely on and the filer's serialized entry format as they are.
