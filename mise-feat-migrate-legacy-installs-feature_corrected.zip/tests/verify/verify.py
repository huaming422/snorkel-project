"""Behavioral verifier for mise-feat-migrate-legacy-installs.

Two implementation-agnostic gates, both through pre-existing stable interfaces:

  1. Compile gate: the agent's edits build the `mise` binary offline with the
     committed lockfile (`cargo build --locked --offline --bin mise`). This also
     exercises the repo's own `command_effects.rs` `#[test]`-backed coverage
     (the build fails if a new subcommand has no registered command-effect), so
     a half-wired command cannot pass.

  2. Registration gate: the built binary answers
     `mise installs migrate --help` with exit 0, so the command exists under
     the pre-existing `mise installs` group and parses.

Deliberately NOT tested here (left to the validation stories + rubric):
behavior of the migration itself. This file imports no repository code, greps
for no new symbol names, and never runs a named `cargo test`; it only drives
the stable build + CLI surface, so any implementation that compiles and
registers the command passes both gates.
"""

import os
import subprocess

# Pre-existing, stable locations baked by the image Dockerfile.
REPO_DIR = "/repo/mise"
# The image sets CARGO_TARGET_DIR=/opt/cache/cargo-target; the binary lands in
# <target>/debug/mise. Honour the env so a local override still resolves.
TARGET_DIR = os.environ.get("CARGO_TARGET_DIR", os.path.join(REPO_DIR, "target"))
MISE_BIN = os.path.join(TARGET_DIR, "debug", "mise")

# A clean incremental build off the warm image cache is minutes; give generous
# head-room for a cold sandbox.
BUILD_TIMEOUT_SEC = 1500
HELP_TIMEOUT_SEC = 120


def _toolchain_env():
    """os.environ plus the Rust toolchain paths + offline switch the image bakes.

    The sandbox starts a fresh shell per phase, so the Dockerfile's ENV
    lines are not inherited automatically; mirror test-setup.sh.
    """
    env = dict(os.environ)
    env.setdefault("RUSTUP_HOME", "/opt/rustup")
    env.setdefault("CARGO_HOME", "/opt/cargo")
    env.setdefault("CARGO_TARGET_DIR", "/opt/cache/cargo-target")
    env.setdefault("RUSTUP_TOOLCHAIN", "1.99.0")
    # No new crates are introduced; the rebuild must resolve against the warm
    # cache with no network.
    env["CARGO_NET_OFFLINE"] = "true"
    cargo_bin = os.path.join(env["CARGO_HOME"], "bin")
    env["PATH"] = cargo_bin + os.pathsep + env.get("PATH", "")
    return env


def _tail(text, n=200):
    lines = (text or "").splitlines()
    return "\n".join(lines[-n:])


def test_mise_binary_compiles():
    """`cargo build --locked --offline --bin mise` succeeds with the edits applied."""
    env = _toolchain_env()
    proc = subprocess.run(
        ["cargo", "build", "--locked", "--offline", "--bin", "mise"],
        cwd=REPO_DIR,
        env=env,
        capture_output=True,
        text=True,
        timeout=BUILD_TIMEOUT_SEC,
        check=False,
    )
    assert proc.returncode == 0, (
        "cargo build --locked --offline --bin mise failed "
        f"(exit {proc.returncode}).\n"
        f"--- stdout (tail) ---\n{_tail(proc.stdout)}\n"
        f"--- stderr (tail) ---\n{_tail(proc.stderr)}"
    )
    assert os.path.isfile(MISE_BIN), f"mise binary not found at {MISE_BIN} after build"
    assert os.access(MISE_BIN, os.X_OK), f"mise binary at {MISE_BIN} is not executable"


def test_installs_migrate_help_is_registered():
    """`mise installs migrate --help` exits 0, so the command is wired up."""
    env = _toolchain_env()
    # MISE_EXPERIMENTAL=1 mirrors how the command surface is reached in the e2e
    # suite; --help resolution must not require network or a data dir.
    env["MISE_EXPERIMENTAL"] = "1"
    assert os.path.isfile(MISE_BIN), (
        f"mise binary missing at {MISE_BIN}; run the compile gate first"
    )
    proc = subprocess.run(
        [MISE_BIN, "installs", "migrate", "--help"],
        cwd=REPO_DIR,
        env=env,
        capture_output=True,
        text=True,
        timeout=HELP_TIMEOUT_SEC,
        check=False,
    )
    assert proc.returncode == 0, (
        "`mise installs migrate --help` did not exit 0 "
        f"(exit {proc.returncode}); the command is not registered under the "
        "`mise installs` group.\n"
        f"--- stdout (tail) ---\n{_tail(proc.stdout)}\n"
        f"--- stderr (tail) ---\n{_tail(proc.stderr)}"
    )
