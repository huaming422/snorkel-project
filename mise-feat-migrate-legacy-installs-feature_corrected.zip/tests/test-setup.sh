#!/usr/bin/env bash
# Verifier-side setup: runs before verify.py, with network available. The image
# already installed the Rust toolchain, warmed the cargo registry, and built the
# `mise` binary at the base commit; this just re-exports toolchain paths (the
# sandbox starts a fresh shell per phase), forces cargo offline for the task's
# own rebuild, and sanity-checks that the baked artifacts are present.
set -euo pipefail

# Re-export the Rust toolchain paths baked by the image Dockerfile.
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export RUSTUP_TOOLCHAIN="${RUSTUP_TOOLCHAIN:-1.99.0}"
export PATH="$CARGO_HOME/bin:$PATH"

# The dependency closure is warm in the image; no new crates are introduced, so
# the verifier's rebuild must run offline against the baked cache.
export CARGO_NET_OFFLINE=true

# Sanity: the toolchain must be present.
rustc --version >/dev/null 2>&1 || {
    echo "ERROR: rustc not found on PATH (CARGO_HOME=$CARGO_HOME)" >&2
    exit 1
}
cargo --version >/dev/null 2>&1 || {
    echo "ERROR: cargo not found on PATH" >&2
    exit 1
}

# Sanity: the mise binary was built into the image at the base commit.
if [ ! -x "$CARGO_TARGET_DIR/debug/mise" ]; then
    echo "ERROR: baked mise binary missing at $CARGO_TARGET_DIR/debug/mise" >&2
    exit 1
fi

# The verifier Python stack is baked into the isolated /opt/tooling venv; the
# runner invokes it via VERIFIER_PYTHON. Expose it for test.sh/verify.py.
export VERIFIER_PYTHON="${VERIFIER_PYTHON:-/opt/tooling/venv/bin/python}"
"$VERIFIER_PYTHON" -c "import pytest" >/dev/null 2>&1 || {
    echo "ERROR: verifier venv missing pytest at $VERIFIER_PYTHON" >&2
    exit 1
}

echo "test-setup: rustc=$(rustc --version), cargo=$(cargo --version | head -1), mise=baked, verifier_python=$VERIFIER_PYTHON"
