## Task

Anything I installed before turning on the identity install layout still sits in an ordinary `installs/<tool>/<version>/` folder. Newer installs each go into a hashed directory holding its own `.mise-install.toml`, and the `installs/<tool>/<version>` entry just links there. The old ones work fine, but right now the only way to bring one over is to uninstall it and install it again myself.

I'd like a `mise installs migrate` command in the `mise installs` group that does that for me. Run bare, it picks up every eligible legacy install. Passing `TOOL@VERSION` arguments limits it to those, matched against what's installed the way `mise uninstall` matches. `--dry-run` (or `-n`) just shows what it would do.

Moving or copying the old directory into place isn't good enough. Tools write their own install path into shebangs, virtualenvs and package-manager files, so every migrated version has to be a fresh install of that same version, made at its new location.

It rewrites real installs on disk, so I need to be able to kill it halfway through without wrecking anything.

## User stories / requirements

- After I migrate one legacy version, `mise where` points at a hashed directory containing `.mise-install.toml`, and the tool still runs through the old `installs/<tool>/<version>` path. Whatever I'd put in the old directory myself is gone, since the version got installed fresh. The versions I left out are still legacy.
- `mise installs migrate --dry-run` lists the versions it would migrate, respects any `TOOL@VERSION` filters I pass, and leaves everything on disk the way it was.
- When the migration works, the legacy directory is replaced. When it fails (the backend won't install that version, say), the command exits non-zero, the old directory is still there untouched and usable, and nothing from the attempt is left behind.
- If I kill a migration while it's reinstalling, running `mise installs migrate` again finishes the job: the version is in the identity layout with its receipt, the tool works through the old path, and nothing from the killed run is left over.
