#!/usr/bin/env bash
#
# Sourced (not exec'd) before the verifier's `go test`, so env we set persists
# for the runner. The Dockerfile already baked the Go toolchain, the module
# cache and the build cache at the base commit; we re-assert defensively in
# case the agent's edits or a wiped layer disturbed the environment.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/freehire}"
cd "$REPO_DIR"

# Make `go` reachable even if the harness scrubbed PATH.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

# The ingest unit tests are pure Go (httptest loopback, in-memory doubles); no
# cgo, no services, no datastore. Keep the toolchain pinned and local.
export CGO_ENABLED=0
export GOTOOLCHAIN=local

# Offline-first: the agent phase is no-network and the image carries the whole
# dependency closure at the base commit. Fail fast on a cache miss instead of
# hanging against a dead proxy. (These are task-local exports, not image ENV.)
export GOFLAGS=-mod=mod
export GOPROXY=off

# Belt-and-suspenders module materialisation. Warm cache → no-op; a wiped layer
# recovers from the module cache without the network. A single resolve attempt
# (offline); do not add a second, online resolve — the agent phase has no net.
go mod download 2>/dev/null || true

echo "test-setup.sh: ready (CGO_ENABLED=$CGO_ENABLED, GOFLAGS=$GOFLAGS, GOPROXY=$GOPROXY)"
