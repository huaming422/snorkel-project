// Package-internal (white-box) verifier for the per-host 429 backoff and the
// SmartRecruiters hydration change. It lives in `package sources` for the same
// reason the repo's own http_test.go does: an *httptest* loopback server can
// only be wired into a *Client by reaching its unexported transport field, which
// an external package cannot do.
//
// ALTERNATIVE-PROOFING (binding, task.toml `alternative_implementations`): the
// per-host backoff may be ANY data layout (two maps, one struct-per-host map, a
// sync.Map), its escalation may be a shift OR an explicit multiply, and every
// identifier it introduces may be renamed (including to non-English). A verifier
// that named the reference's `hostBackoff` type, its `newHostBackoff`
// constructor, its `refused`/`served`/`wait` methods, the `backoff` field, or
// inspected `b.until`/`b.streak` would FAIL TO COMPILE against such a valid
// alternative — a catastrophic false negative. So this file never references any
// symbol the fix introduces. It constructs the client through the pre-existing
// `NewClient()` constructor (which wires whatever backoff the solution built,
// under whatever name) and touches ONLY pre-existing, stable fields the base
// tree already has — `httpClient`, `maxRetries`, `retryDelay` — then observes
// the backoff purely as wall-clock timing through the public `GetJSON` path.
//
// BASE-AGNOSTIC TIMING: the backoff's base hold is a solution-chosen tuning
// value (the reference uses 1s; another valid fix may pick a different hundreds-
// of-ms-to-seconds value). So the timing assertions below are RELATIVE wherever a
// value could legitimately differ (a later hold is ~2x an earlier one; a reset
// returns to ~the first hold; a burst stays within a small multiple of one step)
// and use only a small absolute floor (50ms) to separate "a hold exists" from
// the no-backoff base tree, whose retries are paced by the tiny `retryDelay` this
// file sets. Every margin is >= ~0.5x the hold, robust to scheduler jitter.
package sources

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"
)

// vrRecorder records the wall-clock time of each request a stub server receives,
// tagged by a caller-supplied label, so a test can reason about when the client
// actually sent each attempt. All fields guarded by mu.
type vrRecorder struct {
	mu   sync.Mutex
	hits map[string][]time.Time
}

func newVRRecorder() *vrRecorder { return &vrRecorder{hits: map[string][]time.Time{}} }

func (r *vrRecorder) record(tag string) {
	r.mu.Lock()
	r.hits[tag] = append(r.hits[tag], time.Now())
	r.mu.Unlock()
}

func (r *vrRecorder) times(tag string) []time.Time {
	r.mu.Lock()
	defer r.mu.Unlock()
	out := make([]time.Time, len(r.hits[tag]))
	copy(out, r.hits[tag])
	return out
}

func (r *vrRecorder) count(tag string) int {
	r.mu.Lock()
	defer r.mu.Unlock()
	return len(r.hits[tag])
}

// vrClient builds the production client, then swaps in the loopback transport and
// pins the retry budget — all pre-existing fields. The direct-vs-fallback branch
// in Client.do keys off `client == c.httpClient`; NewClient leaves refusalClient
// nil, so every attempt stays on the direct egress and the hold is observable
// end to end. retryDelay is set tiny so that on the base (no-backoff) tree the
// inter-attempt gap collapses to ~0 — any real per-host hold then stands out.
func vrClient(t *testing.T, transport *http.Client, maxRetries int) *Client {
	t.Helper()
	c := NewClient()
	c.httpClient = transport
	c.maxRetries = maxRetries
	c.retryDelay = time.Millisecond
	return c
}

// gapFloor separates "a per-host hold exists" from the base tree's ~1ms retry
// pacing. Any backoff that meaningfully paces a rate-limited host uses a hold far
// above this; the base tree cannot clear it.
const gapFloor = 50 * time.Millisecond

// TestHostWide429HoldsLaterRequestsToTheSameHost is the workable cascade: once a
// direct-egress 429 is drawn from a host, a LATER request to that same host must
// wait out the hold even though it was never itself refused, while a request to a
// different host is untouched.
//
// Determinism: the hold is ARMED first by a lone request (maxRetries=0: it fires
// once, draws the 429, records the refusal, and returns — no retry to muddy the
// timing). ONLY THEN are the two probe requests launched, so there is no race over
// whether the hold exists when they check it. The same-host probe must be held
// ~base; the other-host probe must not be held at all.
func TestVRHostWide429HoldsLaterRequestsToTheSameHost(t *testing.T) {
	rec := newVRRecorder()
	refusing := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		rec.record("refusing")
		w.WriteHeader(http.StatusTooManyRequests)
	}))
	defer refusing.Close()
	healthy := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		rec.record("healthy")
		_, _ = w.Write([]byte(`{"ok":true}`))
	}))
	defer healthy.Close()

	c := vrClient(t, refusing.Client(), 0)
	var out struct {
		OK bool `json:"ok"`
	}

	// Arm the host-wide hold with a single refused request (its 429 is expected;
	// maxRetries=0 means it returns right after recording the refusal).
	_ = c.GetJSON(context.Background(), refusing.URL+"/arm", &out)
	if rec.count("refusing") != 1 {
		t.Fatalf("arming request made %d hits, want 1", rec.count("refusing"))
	}

	// Now probe both hosts concurrently. The same-host probe should wait out the
	// hold; the other-host probe should sail through.
	launch := time.Now()
	var sameHit, otherHit time.Time
	var wg sync.WaitGroup
	wg.Add(2)
	go func() {
		defer wg.Done()
		_ = c.GetJSON(context.Background(), refusing.URL+"/probe", &out)
		hits := rec.times("refusing")
		sameHit = hits[len(hits)-1]
	}()
	go func() {
		defer wg.Done()
		_ = c.GetJSON(context.Background(), healthy.URL+"/probe", &out)
		otherHit = rec.times("healthy")[0]
	}()
	wg.Wait()

	if held := sameHit.Sub(launch); held < gapFloor {
		t.Errorf("a later request to the refused host went out %v after a prior 429; a host-wide hold must delay it (want >= %v). "+
			"A per-request Retry-After that delays only the request that drew the 429 leaves this at ~0.", held, gapFloor)
	}
	if delayed := otherHit.Sub(launch); delayed >= gapFloor {
		t.Errorf("a request to an unrelated host was delayed %v; a hold on one host must not pace another (want < %v)", delayed, gapFloor)
	}
}

// TestHost429HoldEscalatesOnConsecutiveRefusals: each refusal that arrives after
// the previous hold expired lengthens the next hold (the reference doubles it).
// Through the client, a single request to an always-429 host retries under the
// hold, so the gaps between its successive attempts ARE the successive holds. A
// later hold must be materially longer than the earlier one; on the base tree the
// gaps are the fixed ~1ms retryDelay (ratio ~1), which fails the check.
func TestVRHost429HoldEscalatesOnConsecutiveRefusals(t *testing.T) {
	rec := newVRRecorder()
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		rec.record("h")
		w.WriteHeader(http.StatusTooManyRequests)
	}))
	defer srv.Close()

	// 3 attempts → 2 inter-attempt gaps (= 2 successive holds). delay=0 after a
	// 429 in the fix means the gap is the hold alone.
	c := vrClient(t, srv.Client(), 2)
	var out any
	_ = c.GetJSON(context.Background(), srv.URL+"/p", &out)

	hits := rec.times("h")
	if len(hits) < 3 {
		t.Fatalf("host saw %d attempts, want 3 (initial + two retries under escalating holds)", len(hits))
	}
	gap1 := hits[1].Sub(hits[0])
	gap2 := hits[2].Sub(hits[1])
	if gap1 < gapFloor {
		t.Fatalf("first retry came %v after the refusal; a per-host hold must pace it (want >= %v)", gap1, gapFloor)
	}
	// Doubling (or any escalation) makes the second hold clearly longer than the
	// first. 1.4x sits comfortably below a true 2x (leaving margin for scheduler
	// jitter inflating the first gap) and far above a non-escalating 1.0x. Reject
	// a fixed-length (non-escalating) hold, which is not the fix.
	if gap2 < gap1*7/5 {
		t.Errorf("second hold %v was not materially longer than the first %v (want >= 1.4x); consecutive refusals must escalate the hold", gap2, gap1)
	}
}

// TestHost429HoldResetsAfterASuccess: a served (2xx) response resets the
// escalation so a later refusal starts from the base hold again, not from where
// the streak left off. First request draws two refusals (escalating base then
// ~2*base) and then succeeds, resetting the streak; a second request then draws
// one refusal whose hold must be back at ~base — not the ~4*base the streak would
// have reached had the success not reset it.
func TestVRHost429HoldResetsAfterASuccess(t *testing.T) {
	var mu sync.Mutex
	// Per-request-path refusal budgets: the "warm" path 429s twice then 200s
	// (building and then resetting a streak); the "probe" path 429s once then
	// 200s (its single hold reveals where the streak stands).
	refusalsLeft := map[string]int{"/warm": 2, "/probe": 1}
	rec := newVRRecorder()
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		rec.record(r.URL.Path)
		mu.Lock()
		left := refusalsLeft[r.URL.Path]
		if left > 0 {
			refusalsLeft[r.URL.Path] = left - 1
		}
		mu.Unlock()
		if left > 0 {
			w.WriteHeader(http.StatusTooManyRequests)
			return
		}
		_, _ = w.Write([]byte(`{"ok":true}`))
	}))
	defer srv.Close()

	c := vrClient(t, srv.Client(), 3)
	var out any
	if err := c.GetJSON(context.Background(), srv.URL+"/warm", &out); err != nil {
		t.Fatalf("warm request did not recover: %v", err)
	}
	warm := rec.times("/warm")
	if len(warm) < 3 {
		t.Fatalf("warm path saw %d attempts, want 3 (two refusals then success)", len(warm))
	}
	firstHold := warm[1].Sub(warm[0])  // ~base
	secondHold := warm[2].Sub(warm[1]) // ~2*base (escalated)
	if firstHold < gapFloor {
		t.Fatalf("warm first hold %v below floor %v — no per-host hold present", firstHold, gapFloor)
	}

	// Separate the probe from the warm hold in time so the probe's single refusal
	// DETERMINISTICALLY arrives after any residual warm hold has expired (making it
	// an escalating refusal, not a burst inside a running hold). Without this the
	// probe refusal lands right at the warm hold's expiry, and whether it escalates
	// is a race — which would let a no-reset implementation slip through.
	time.Sleep(secondHold + gapFloor)

	if err := c.GetJSON(context.Background(), srv.URL+"/probe", &out); err != nil {
		t.Fatalf("probe request did not recover: %v", err)
	}
	probe := rec.times("/probe")
	if len(probe) < 2 {
		t.Fatalf("probe path saw %d attempts, want 2 (one refusal then success)", len(probe))
	}
	probeHold := probe[1].Sub(probe[0])
	// After the 2xx reset the streak is back to zero, so the probe's refusal must
	// hold ~base again (≈ firstHold). An implementation that does NOT reset on a
	// success continues the streak and holds ~2x the warm SECOND hold (~4*base),
	// far above the 2x-base ceiling here. (Allowing up to 2*firstHold absorbs
	// jitter while still rejecting the un-reset ~4x.)
	if probeHold > 2*firstHold {
		t.Errorf("after a success the next refusal held %v; want ~the base hold %v (a 2xx must reset the escalation streak), not a continuation toward %v",
			probeHold, firstHold, secondHold)
	}
}

// TestHost429BurstCountsAsOneStep: many refusals that all arrive while one hold
// is already running are a single burst (every in-flight worker drew its 429 at
// the same instant) and must escalate the hold ONCE, not once per refusal.
// Counting each would jump the first hold to the cap. Through the client: a
// baseline single-request hold (one step) is measured, then 8 concurrent
// requests hit an always-429 host; the gap between their first and second rounds
// of attempts is the hold the burst produced, which must stay within a small
// multiple of one step — not explode toward the cap.
func TestVRHost429BurstCountsAsOneStep(t *testing.T) {
	// Baseline: a lone request's first hold == one escalation step == ~base.
	recBase := newVRRecorder()
	baseSrv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		recBase.record("h")
		w.WriteHeader(http.StatusTooManyRequests)
	}))
	defer baseSrv.Close()
	cBase := vrClient(t, baseSrv.Client(), 1)
	var out any
	_ = cBase.GetJSON(context.Background(), baseSrv.URL+"/p", &out)
	bh := recBase.times("h")
	if len(bh) < 2 {
		t.Fatalf("baseline host saw %d attempts, want 2", len(bh))
	}
	oneStep := bh[1].Sub(bh[0])
	if oneStep < gapFloor {
		t.Fatalf("baseline hold %v below floor %v — no per-host hold present", oneStep, gapFloor)
	}

	// Burst: `workers` concurrent requests, each retrying once, against an
	// always-429 host. A server-side barrier holds every round-0 request until all
	// `workers` have arrived, then releases them together — a genuine simultaneous
	// burst (every in-flight worker drawing its 429 at the same instant), not a
	// scheduler-dependent stagger. They then wait out the single hold the burst
	// armed and fire their retries ~together (round 1), which are NOT barriered.
	const workers = 8
	recB := newVRRecorder()
	var bmu sync.Mutex
	arrived := 0
	gate := make(chan struct{})
	burstSrv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		recB.record("h")
		bmu.Lock()
		arrived++
		cur := arrived
		bmu.Unlock()
		if cur <= workers { // round 0: wait for the whole burst to assemble
			if cur == workers {
				close(gate)
			}
			<-gate
		}
		w.WriteHeader(http.StatusTooManyRequests)
	}))
	defer burstSrv.Close()
	cB := vrClient(t, burstSrv.Client(), 1)
	var wg sync.WaitGroup
	for range workers {
		wg.Add(1)
		go func() {
			defer wg.Done()
			var o any
			_ = cB.GetJSON(context.Background(), burstSrv.URL+"/p", &o)
		}()
	}
	wg.Wait()

	hits := recB.times("h")
	if len(hits) != workers*2 {
		t.Fatalf("burst host saw %d attempts, want %d (8 workers x 2 attempts)", len(hits), workers*2)
	}
	// Sorted by arrival: the first `workers` hits are round 0, the next `workers`
	// are round 1. The inter-round hold is the gap from the last round-0 hit to
	// the first round-1 hit.
	roundGap := hits[workers].Sub(hits[workers-1])
	// One step (correct): roundGap ~= oneStep. Per-refusal escalation (the bug):
	// 8 refusals jump the hold to base<<8 or the cap — many times one step. A 3x
	// ceiling admits normal jitter and at most one extra doubling while rejecting
	// the runaway.
	if roundGap > oneStep*3 {
		t.Errorf("after a burst of %d simultaneous refusals the hold was %v, more than 3x one step (%v); "+
			"a simultaneous burst must count as ONE escalation, not one per refusal", workers, roundGap, oneStep)
	}
}

// TestHost429RetryAfterFeedsTheHostWideHold: the server's Retry-After is honored
// host-wide (not merely for the request that drew the 429). A request draws a 429
// carrying Retry-After: 2s; a LATER request to the same host — which never itself
// saw a Retry-After — must still be held for about those 2 seconds.
//
// Determinism: the hold is armed by a lone maxRetries=0 request that records the
// refusal and returns immediately WITHOUT waiting out its own hold (a retrying
// request would sleep the 2s itself and leave the hold expired before the probe
// runs). The probe is launched right after, while the ~2s hold is live. The base
// tree honors Retry-After per request only, so its probe is not held.
func TestVRHost429RetryAfterFeedsTheHostWideHold(t *testing.T) {
	const retryAfter = 2 * time.Second
	rec := newVRRecorder()
	var mu sync.Mutex
	served := 0
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		rec.record("h")
		mu.Lock()
		n := served
		served++
		mu.Unlock()
		if n == 0 {
			// Only the very first attempt is refused, and it names a long
			// Retry-After. Everything after is healthy, so the only thing that can
			// delay a later request is the host-wide hold the hint fed.
			w.Header().Set("Retry-After", "2")
			w.WriteHeader(http.StatusTooManyRequests)
			return
		}
		_, _ = w.Write([]byte(`{"ok":true}`))
	}))
	defer srv.Close()

	var out any
	// Arm: a non-retrying request draws the Retry-After:2 refusal, records the
	// host-wide hold, and returns at once (it does not sleep the hold itself).
	armClient := vrClient(t, srv.Client(), 0)
	_ = armClient.GetJSON(context.Background(), srv.URL+"/arm", &out)
	if rec.count("h") != 1 {
		t.Fatalf("arming request made %d hits, want 1", rec.count("h"))
	}

	// Probe the same host on a client sharing nothing but the transport — the hold
	// lives on neither client object but is observed through the backoff the fix
	// attaches to NewClient(); so the probe must run on the SAME client that armed
	// it. Reuse armClient, now with a retry budget, and time its next hit.
	armClient.maxRetries = 2
	launch := time.Now()
	if err := armClient.GetJSON(context.Background(), srv.URL+"/probe", &out); err != nil {
		t.Fatalf("probe request did not recover: %v", err)
	}
	all := rec.times("h")
	probeHit := all[1] // the second hit overall is the probe's first attempt
	held := probeHit.Sub(launch)
	// The hint was 2s; allow wide slack (>= 1.5s) for jitter. The base tree, which
	// paces only the request that drew the refusal, leaves this near 0.
	if held < retryAfter*3/4 {
		t.Errorf("a later request to the refused host went out %v after a Retry-After: 2s refusal; "+
			"the hint must pace the whole host, not only the request that drew it (want >= %v)", held, retryAfter*3/4)
	}
}

// ---- SmartRecruiters hydration (HydratingSource.FetchNew) ----

// vrJSONGetter is a self-contained JSONGetter stub (not the repo's routedHTTP,
// which lives in a test file the solution may edit). It decodes a canned JSON
// body chosen by a substring of the request URL into v.
type vrJSONGetter struct {
	routes map[string]string // url-substring -> JSON body
	err    error             // if non-nil, every GetJSON fails with it
}

func (g vrJSONGetter) GetJSON(_ context.Context, url string, v any) error {
	if g.err != nil {
		return g.err
	}
	for sub, body := range g.routes {
		if strings.Contains(url, sub) {
			return json.Unmarshal([]byte(body), v)
		}
	}
	return fmt.Errorf("vrJSONGetter: no route for %s", url)
}

// TestSmartRecruitersFetchNewSkipsDetailForSeenPostings drives SmartRecruiters
// through the pre-existing HydratingSource interface: a seen posting must come
// back as a liveness refresh carrying the listing's identity and costing NO
// detail request, while a new posting is fully hydrated from its detail. The
// detail route for the seen posting returns a DIFFERENT title so that, if the
// adapter wrongly fetched it, the posting would not be a SeenRefresh and the
// assertion would catch it.
func TestVRSmartRecruitersFetchNewSkipsDetailForSeenPostings(t *testing.T) {
	listing := `{"totalFound":2,"content":[` +
		`{"id":"P1","name":"  Backend Engineer  ","releasedDate":"2024-06-11T15:19:46.134Z","location":{"city":"Berlin","country":"de"}},` +
		`{"id":"P2","name":"Frontend Engineer","releasedDate":"2024-06-11T15:19:46.134Z","location":{"city":"Paris","country":"fr"}}` +
		`]}`
	p2detail := `{"postingUrl":"https://jobs.smartrecruiters.com/Acme/P2","jobAd":{"sections":{"jobDescription":{"text":"<p>do the job.</p>"}}}}`
	// A sentinel body for P1's detail: if the adapter requests it for the SEEN
	// posting, P1 would hydrate (SeenRefresh=false) and the check below fails.
	p1detail := `{"postingUrl":"https://jobs.smartrecruiters.com/Acme/P1","jobAd":{"sections":{"jobDescription":{"text":"should not be fetched"}}}}`
	fake := vrJSONGetter{routes: map[string]string{
		"postings?":    listing,
		"/postings/P2": p2detail,
		"/postings/P1": p1detail,
	}}

	src, ok := NewSmartRecruiters(fake).(HydratingSource)
	if !ok {
		t.Fatal("SmartRecruiters must implement HydratingSource (FetchNew) so a seen posting costs no detail request")
	}
	jobs, err := src.FetchNew(context.Background(), CompanyEntry{
		Company: "Acme", Provider: "smartrecruiters", Board: "Acme",
	}, func(id string) bool { return id == "P1" })
	if err != nil {
		t.Fatalf("FetchNew: %v", err)
	}
	byID := map[string]Job{}
	for _, j := range jobs {
		byID[j.ExternalID] = j
	}
	if len(byID) != 2 {
		t.Fatalf("got %d jobs, want 2: %+v", len(byID), jobs)
	}

	seen := byID["P1"]
	if !seen.SeenRefresh || seen.Unreadable {
		t.Errorf("seen posting P1 = %+v; want a SeenRefresh (liveness-only) with no detail request", seen)
	}
	if seen.Title != "Backend Engineer" {
		t.Errorf("seen posting Title = %q; want the listing's trimmed name %q", seen.Title, "Backend Engineer")
	}
	if seen.Company != "Acme" {
		t.Errorf("seen posting Company = %q; want the board's company %q", seen.Company, "Acme")
	}

	fresh := byID["P2"]
	if fresh.SeenRefresh || fresh.Unreadable {
		t.Fatalf("new posting P2 = %+v; want a fully hydrated posting", fresh)
	}
	if !strings.Contains(fresh.Description, "do the job.") {
		t.Errorf("new posting Description = %q; want the hydrated detail body", fresh.Description)
	}
	if fresh.URL != "https://jobs.smartrecruiters.com/Acme/P2" {
		t.Errorf("new posting URL = %q; want the detail's postingUrl", fresh.URL)
	}
}

// TestSmartRecruitersFetchNewPropagatesAListingError: a listing-level failure
// still aborts FetchNew, exactly as it aborts Fetch (the full-board-listing
// guarantee holds on the hydrating path too).
func TestVRSmartRecruitersFetchNewPropagatesAListingError(t *testing.T) {
	fake := vrJSONGetter{err: fmt.Errorf("listing boom")}
	src, ok := NewSmartRecruiters(fake).(HydratingSource)
	if !ok {
		t.Fatal("SmartRecruiters must implement HydratingSource")
	}
	if _, err := src.FetchNew(context.Background(), CompanyEntry{Board: "acme"}, func(string) bool { return false }); err == nil {
		t.Fatal("FetchNew returned nil error despite a listing failure; a listing error must abort the crawl")
	}
}
