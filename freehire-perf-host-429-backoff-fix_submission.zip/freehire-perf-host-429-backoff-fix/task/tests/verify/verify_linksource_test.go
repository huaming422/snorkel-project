// White-box verifier for the link-resolution slug fix, driven through the
// exported linksource.ResolveOnBoard. SmartRecruiters writes a posting's id at
// the FRONT of the last URL path segment (".../<company>/<id>-<title-slug>"), so
// the id is never a whole segment. When the adapter hydrates, a seen predicate
// that matches only a WHOLE segment calls the linked posting "seen", hands back a
// URL-less liveness refresh, and loses the link. The fix matches a segment that
// is the id OR begins with "<id>-", so the pasted posting is hydrated instead.
//
// ALTERNATIVE-PROOFING (binding, task.toml `alternative_implementations`): the
// slug matcher may be written as `seg==id || HasPrefix(seg, id+"-")`, a regexp
// `^<id>(-|$)`, or a manual scan — under any identifier names. This file never
// names the matcher (the reference calls it `segmentNamesID`); it exercises the
// behavior only through ResolveOnBoard, so any correct matcher passes and the
// whole-segment-only base behavior fails.
//
// ResolveOnBoard namespaces the returned ExternalID by board
// (externalid.Namespace), so the assertions are on Title / SeenRefresh / which
// postings the board hydrated — never the raw id.
package linksource

import (
	"context"
	"slices"
	"testing"

	"github.com/strelov1/freehire/internal/ingest/sources"
)

// vrHydratingBoard is a self-contained HydratingSource double (not the repo's
// fakeHydratingBoard, which lives in a test file the solution may edit). It
// returns a liveness-only SeenRefresh for every posting its seen predicate
// reports seen, and records — in `hydrated` — the ids it was asked to hydrate
// (those the predicate reported new). This mirrors how a real hydrating adapter
// spends a detail request only on a posting the catalogue does not hold.
type vrHydratingBoard struct {
	provider string
	jobs     []sources.Job
	hydrated []string
}

func (f *vrHydratingBoard) Provider() string { return f.provider }

func (f *vrHydratingBoard) Fetch(_ context.Context, _ sources.CompanyEntry) ([]sources.Job, error) {
	return f.jobs, nil
}

func (f *vrHydratingBoard) FetchNew(_ context.Context, _ sources.CompanyEntry, seen func(externalID string) bool) ([]sources.Job, error) {
	out := make([]sources.Job, 0, len(f.jobs))
	for _, j := range f.jobs {
		if seen(j.ExternalID) {
			// Liveness refresh: identity only, no URL/description, flagged
			// SeenRefresh — exactly what a whole-segment-only match would wrongly
			// hand back for the linked posting.
			out = append(out, sources.Job{ExternalID: j.ExternalID, Title: j.Title, SeenRefresh: true})
			continue
		}
		f.hydrated = append(f.hydrated, j.ExternalID)
		out = append(out, j)
	}
	return out, nil
}

// TestResolveOnBoardResolvesAnIDPrefixedSlugSegment: a pasted URL whose last
// segment is "<id>-<title-slug>" must resolve to the hydrated target posting, not
// to a URL-less refresh. The board hydrates only that one posting. A whole-
// segment-only seen predicate would call the target seen (its id is never a whole
// segment of the URL), hydrate the OTHER posting, and return the target as a
// SeenRefresh — which this test rejects.
func TestVRResolveOnBoardResolvesAnIDPrefixedSlugSegment(t *testing.T) {
	board := &vrHydratingBoard{
		provider: "smartrecruiters",
		jobs: []sources.Job{
			{ExternalID: "744000011111111", URL: "https://jobs.smartrecruiters.com/Acme/744000011111111-junior-go", Title: "Junior Go"},
			{ExternalID: "744000022222222", URL: "https://jobs.smartrecruiters.com/Acme/744000022222222-senior-go", Title: "Senior Go"},
		},
	}
	reg := map[string]sources.Source{"smartrecruiters": board}

	raw := "https://jobs.smartrecruiters.com/Acme/744000022222222-senior-go"
	job, ok, err := ResolveOnBoard(context.Background(), reg, "smartrecruiters", "Acme", raw)
	if err != nil || !ok {
		t.Fatalf("ResolveOnBoard = (ok %v, err %v); want the linked vacancy resolved", ok, err)
	}
	if job.SeenRefresh {
		t.Errorf("resolved posting is a SeenRefresh; want the hydrated target, not a URL-less refresh")
	}
	if job.Title != "Senior Go" {
		t.Errorf("resolved Title = %q; want %q", job.Title, "Senior Go")
	}
	if want := []string{"744000022222222"}; !slices.Equal(board.hydrated, want) {
		t.Errorf("board hydrated %v; want only the linked posting %v", board.hydrated, want)
	}
}

// TestResolveOnBoardMatchesAnIDPrefixedSegmentWithAStaleSlug: a SmartRecruiters
// slug follows the title, so a link pasted before the title was edited carries an
// OLD slug after the right id. The id still names the posting, so the link must
// resolve even though the stored posting's URL carries a different slug.
func TestVRResolveOnBoardMatchesAnIDPrefixedSegmentWithAStaleSlug(t *testing.T) {
	board := &vrHydratingBoard{
		provider: "smartrecruiters",
		jobs: []sources.Job{
			{ExternalID: "744000022222222", URL: "https://jobs.smartrecruiters.com/Acme/744000022222222-staff-go", Title: "Staff Go"},
		},
	}
	reg := map[string]sources.Source{"smartrecruiters": board}

	// The pasted link's slug ("senior-go") is stale; the stored posting's is
	// "staff-go". The id in front of both is the same, and it is what resolves.
	raw := "https://jobs.smartrecruiters.com/Acme/744000022222222-senior-go"
	job, ok, err := ResolveOnBoard(context.Background(), reg, "smartrecruiters", "Acme", raw)
	if err != nil || !ok {
		t.Fatalf("ResolveOnBoard = (ok %v, err %v); want the posting matched by the id in front of the stale slug", ok, err)
	}
	if job.Title != "Staff Go" {
		t.Errorf("resolved Title = %q; want %q", job.Title, "Staff Go")
	}
	if job.SeenRefresh {
		t.Errorf("resolved posting is a SeenRefresh; want the hydrated target")
	}
}

// TestResolveOnBoardDoesNotMatchAnEmptyIDAgainstASlugSegment is the empty-id
// guard: a posting whose ExternalID is "" must not be matched by a URL segment
// (an unguarded HasPrefix(seg, ""+"-") or a bare prefix test would let any
// segment name an identity-less posting). Here the only stored posting has an
// empty id and a URL that does NOT match the raw link, so the resolve must come
// back empty rather than wrongly returning the id-less posting.
func TestVRResolveOnBoardDoesNotMatchAnEmptyIDAgainstASlugSegment(t *testing.T) {
	board := &vrHydratingBoard{
		provider: "smartrecruiters",
		jobs: []sources.Job{
			{ExternalID: "", URL: "https://jobs.smartrecruiters.com/Acme/other-posting", Title: "No ID"},
		},
	}
	reg := map[string]sources.Source{"smartrecruiters": board}

	raw := "https://jobs.smartrecruiters.com/Acme/744000022222222-senior-go"
	_, ok, err := ResolveOnBoard(context.Background(), reg, "smartrecruiters", "Acme", raw)
	if err != nil {
		t.Fatalf("ResolveOnBoard error: %v", err)
	}
	if ok {
		t.Errorf("ResolveOnBoard matched an empty-id posting against a slug segment; the matcher must require a non-empty id")
	}
}
