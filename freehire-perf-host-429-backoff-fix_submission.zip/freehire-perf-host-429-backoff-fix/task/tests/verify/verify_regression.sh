#!/usr/bin/env bash
# pass_to_pass regression guard (test criterion: "the existing sources and
# linksource unit suites still pass at the fix — no regression").
#
# The fix touches internal/ingest/sources (the shared HTTP client + the
# SmartRecruiters adapter) and internal/ingest/linksource (link resolution).
# The authoritative regression surface is those two packages' own stock unit
# suites: URL normalization, every other provider adapter, the retry/refusal
# flow, and the existing link-resolution cases. An over-broad change to the
# client's retry path or to the slug matcher flips one of those pre-existing
# tests.
#
# This runs the repo's OWN suites by PACKAGE PATH only — it never names any
# identifier the fix introduces (the per-host backoff type, FetchNew,
# segmentNamesID, etc.), so it is layout-agnostic and cannot leak the design.
#
# The native Go verifier (verify_test.go / verify_linksource_test.go) is a
# SEPARATE runner injected under a -run filter; it is not part of this suite,
# and the harness runs each verify file's runner in isolation, so this stock
# run and the injected verifier do not interfere.
#
# Env mirrors tests/test-setup.sh: offline, cgo off, local toolchain. The
# ingest tests are pure (httptest loopback + in-memory doubles), so this is
# fast and needs no services or datastore.
set -euo pipefail

export GOFLAGS="${GOFLAGS:--mod=mod}"
export CGO_ENABLED="${CGO_ENABLED:-0}"
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"
export GOPROXY="${GOPROXY:-off}"

REPO_DIR="${REPO_DIR:-/repo/freehire}"
cd "$REPO_DIR"

# Make `go` reachable even if the harness scrubbed PATH.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

go test -count=1 ./internal/ingest/sources/... ./internal/ingest/linksource/...

echo "verify_regression.sh: internal/ingest/sources + internal/ingest/linksource stock suites pass (no regression)."
