// @ts-nocheck
//
// Behavioural suite for the provider wire-format translation layer.
//
// Every assertion drives one of the four loopback bridges
// (ChatProviderCompatibilityBridge, NativeResponsesCompatibilityProxy,
// ResponsesBridge, the xAI OAuth bridge) over its public HTTP surface,
// against a mocked upstream `fetch`. The app's own usage normalizer reads
// one HTTP response, and the native proxy gets the xAI settings the app
// gives it.
//
// No internal helper is imported or named. Captured wire payloads come from
// the pre-existing fixtures module. Fully offline: loopback TCP + stubbed fetch.

import { afterEach, describe, expect, it, vi } from 'vitest'
import { ChatProviderCompatibilityBridge } from './chat-provider-compatibility'
import { NativeResponsesCompatibilityProxy } from './native-responses-compatibility'
import { normalizeOpenAiChatModelStepUsage } from './openai-chat-usage'
import {
  CAPTURED_TOOL_IMAGE_PNG_BASE64,
  CLAUDE_CODE_TOOL_IMAGE_REQUEST_FIXTURE,
  CODEX_NATIVE_TOOL_IMAGE_REQUEST_FIXTURE
} from './provider-tool-image-wire.test-fixtures'
import { ResponsesBridge } from './responses-bridge'
import { createXaiOAuthProviderBridge } from './xai-oauth-provider-bridge'
import { xaiNativeResponsesTargetFields } from './xai-protocol'

type Json = Record<string, unknown>

const bridges: { close(): Promise<void> }[] = []
afterEach(async () => {
  await Promise.all(bridges.splice(0).map((bridge) => bridge.close()))
})

const post = async (
  bridge: { start(): Promise<{ baseUrl: string; token: string }>; close(): Promise<void> },
  path: string,
  body: Json
): Promise<Response> => {
  if (!bridges.includes(bridge)) bridges.push(bridge)
  const connection = await bridge.start()
  return fetch(`${connection.baseUrl}${path}`, {
    method: 'POST',
    headers: { authorization: `Bearer ${connection.token}`, 'content-type': 'application/json' },
    body: JSON.stringify(body)
  })
}

// Minimal SSE reader: split on blank line, collect the joined `data:` payload
// per event, JSON.parse it (drop the terminal sentinel and comments).
const sse = (body: string): ReturnType<typeof JSON.parse>[] =>
  body.split(/\r?\n\r?\n/).flatMap((event) => {
    const data = event
      .split(/\r?\n/)
      .filter((line) => line.startsWith('data:'))
      .map((line) => line.slice(5).replace(/^ /, ''))
      .join('\n')
    return !data || data === '[DONE]' ? [] : [JSON.parse(data)]
  })

const responsePayload = {
  id: 'resp_report',
  status: 'completed',
  output: [{ type: 'message', content: [{ type: 'output_text', text: 'partial' }] }],
  usage: { input_tokens: 12, input_tokens_details: { cached_tokens: 5 }, output_tokens: 2 }
}

const xai = (
  wire: 'anthropic' | 'openai',
  upstream: typeof fetch
): ReturnType<typeof createXaiOAuthProviderBridge> =>
  createXaiOAuthProviderBridge(
    [{ id: 'active', model: 'grok-test' }],
    'active',
    wire,
    async () => 'test-token',
    upstream
  )

const chat = (payload: Json): ChatProviderCompatibilityBridge =>
  new ChatProviderCompatibilityBridge(
    { wire: 'anthropic', endpoint: 'https://provider.example/v1/messages', model: 'test-model' },
    async () => Response.json(payload)
  )

const textRequest = { messages: [{ role: 'user', content: 'Continue' }] }

// The native Responses proxy set up the way the app sets it up for an xAI subscription.
const nativeXai = (provider: typeof fetch): NativeResponsesCompatibilityProxy =>
  new NativeResponsesCompatibilityProxy(
    {
      baseUrl: 'https://provider.example/v1',
      model: 'test',
      ...xaiNativeResponsesTargetFields('xai-subscription', async () => 'test-key')
    },
    provider
  )

const sentBody = (provider: { mock: { calls: unknown[][] } }): Json =>
  JSON.parse(String((provider.mock.calls[0]?.[1] as RequestInit | undefined)?.body))

// An upstream result the bridge can't pass on is a server-side error (5xx),
// never a 2xx success and never a 4xx that blames the client's request.
const expectServerError = (response: Response): void => {
  expect(response.status).toBeGreaterThanOrEqual(500)
  expect(response.status).toBeLessThan(600)
}

// Only traverse structured values: a base64 string hidden inside JSON text is
// NOT an image part. Walk objects/arrays and collect typed image nodes.
const imageParts = (value: unknown): Json[] => {
  if (Array.isArray(value)) return value.flatMap(imageParts)
  if (value === null || typeof value !== 'object') return []
  const part = value as Json
  return part.type === 'input_image' || part.type === 'image_url'
    ? [part]
    : Object.values(part).flatMap(imageParts)
}

describe('provider protocol semantics', () => {
  it('R01 preserves a captured Codex tool image as a multimodal part over HTTP', async () => {
    const upstream = vi.fn<typeof fetch>(async () =>
      Response.json({
        id: 'chat-report',
        choices: [{ message: { content: 'ok' }, finish_reason: 'stop' }]
      })
    )
    const bridge = new ResponsesBridge(
      { baseUrl: 'https://provider.example/v1', model: 'test' },
      upstream
    )
    const response = await post(bridge, '/responses', {
      ...CODEX_NATIVE_TOOL_IMAGE_REQUEST_FIXTURE,
      stream: false
    })
    expect(response.status).toBe(200)
    await response.text()
    const sent = JSON.parse(String(upstream.mock.calls[0]?.[1]?.body))
    // The image survives as a structured image part carrying the captured PNG.
    expect(imageParts(sent)).toHaveLength(1)
    expect(JSON.stringify(imageParts(sent))).toContain(CAPTURED_TOOL_IMAGE_PNG_BASE64)
    // The tool-result text + call id are retained.
    expect(sent.messages).toContainEqual(
      expect.objectContaining({ role: 'tool', tool_call_id: 'call_fixture_1' })
    )
    // And the image is NOT merely stringified into the tool message content.
    expect(
      sent.messages
        .filter((message: Json) => message.role === 'tool')
        .some((message: Json) => String(message.content).includes(CAPTURED_TOOL_IMAGE_PNG_BASE64))
    ).toBe(false)
  })

  it('R01 preserves a captured Claude tool image through the xAI HTTP bridge', async () => {
    const upstream = vi.fn<typeof fetch>(async () => Response.json(responsePayload))
    const response = await post(xai('anthropic', upstream), '/v1/messages', {
      ...CLAUDE_CODE_TOOL_IMAGE_REQUEST_FIXTURE,
      max_tokens: 128
    })
    expect(response.status).toBe(200)
    await response.text()
    const sent = JSON.parse(String(upstream.mock.calls[0]?.[1]?.body))
    expect(imageParts(sent)).toHaveLength(1)
    expect(JSON.stringify(imageParts(sent))).toContain(CAPTURED_TOOL_IMAGE_PNG_BASE64)
    expect(sent.input).toContainEqual(
      expect.objectContaining({ type: 'function_call_output', call_id: 'toolu_fixture_1' })
    )
  })

  it('R01 keeps parallel tool results grouped and associates their images', async () => {
    const image = (name: string): Json => ({
      type: 'input_image',
      image_url: `https://example.test/${name}.png`,
      detail: 'high'
    })
    const upstream = vi.fn<typeof fetch>(async () =>
      Response.json({
        id: 'chat-parallel',
        choices: [{ message: { content: 'ok' }, finish_reason: 'stop' }]
      })
    )
    const response = await post(
      new ResponsesBridge({ baseUrl: 'https://provider.example/v1', model: 'test' }, upstream),
      '/responses',
      {
        stream: false,
        input: [
          { type: 'function_call', call_id: 'call_parallel_alpha', name: 'first', arguments: '{}' },
          { type: 'function_call', call_id: 'call_parallel_beta', name: 'second', arguments: '{}' },
          {
            type: 'function_call_output',
            call_id: 'call_parallel_alpha',
            output: [{ type: 'input_text', text: 'first result' }, image('alpha')]
          },
          {
            type: 'function_call_output',
            call_id: 'call_parallel_beta',
            output: [{ type: 'input_text', text: 'second result' }, image('beta')]
          },
          { type: 'message', role: 'assistant', content: 'I see both images.' }
        ]
      }
    )
    expect(response.status).toBe(200)
    await response.text()
    const messages = sentBody(upstream).messages as Json[]
    // Both tool results reach the provider, in order, each with its call id and its text.
    expect(messages.filter((message) => message.role === 'tool')).toMatchObject([
      { tool_call_id: 'call_parallel_alpha' },
      { tool_call_id: 'call_parallel_beta' }
    ])
    const toolText = (message: Json): string =>
      typeof message.content === 'string'
        ? message.content
        : Array.isArray(message.content)
          ? message.content
              .filter((part: Json) => part?.type === 'text')
              .map((part: Json) => part.text)
              .join('')
          : ''
    const tools = messages.filter((message) => message.role === 'tool')
    expect(toolText(tools[0])).toContain('first result')
    expect(toolText(tools[1])).toContain('second result')
    // Both images reach the provider as image parts, wherever the bridge places
    // them, in the order of the calls that returned them.
    expect(imageParts(messages)).toHaveLength(2)
    expect(imageParts(messages)).toMatchObject([
      { type: 'image_url', image_url: { url: 'https://example.test/alpha.png', detail: 'high' } },
      { type: 'image_url', image_url: { url: 'https://example.test/beta.png', detail: 'high' } }
    ])
  })

  it('R01 preserves URL-source images in Claude tool results and their association', async () => {
    const upstream = vi.fn<typeof fetch>(async () => Response.json(responsePayload))
    const response = await post(xai('anthropic', upstream), '/v1/messages', {
      max_tokens: 128,
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'tool_result',
              tool_use_id: 'url_call',
              content: [
                { type: 'text', text: 'image result' },
                { type: 'image', source: { type: 'url', url: 'https://example.test/tool.png' } }
              ]
            },
            { type: 'tool_result', tool_use_id: 'other_call', content: 'other result' }
          ]
        }
      ]
    })
    expect(response.status).toBe(200)
    await response.text()
    const sent = sentBody(upstream)
    const input = sent.input as Json[]
    // Both results stay together, in order, each with its call id and its text.
    const first = input.findIndex((item) => item.type === 'function_call_output')
    expect(input.slice(first, first + 2)).toMatchObject([
      { type: 'function_call_output', call_id: 'url_call' },
      { type: 'function_call_output', call_id: 'other_call' }
    ])
    const outputText = (output: unknown): string =>
      typeof output === 'string'
        ? output
        : Array.isArray(output)
          ? output
              .filter((part: Json) => part?.type === 'input_text' || part?.type === 'text')
              .map((part: Json) => part.text)
              .join('')
          : ''
    expect(outputText(input[first].output)).toBe('image result')
    expect(outputText(input[first + 1].output)).toBe('other result')
    // The URL image reaches xAI as one image part.
    expect(imageParts(sent)).toHaveLength(1)
    expect(imageParts(sent)[0]).toMatchObject({
      type: 'input_image',
      image_url: 'https://example.test/tool.png'
    })
  })

  it.each([false, true])(
    'R02 Chat length cutoff is reported as incomplete over Responses HTTP (stream=%s)',
    async (stream) => {
      const completion = {
        id: 'chat-length',
        choices: [{ message: { content: 'partial' }, finish_reason: 'length' }]
      }
      const upstream = vi.fn<typeof fetch>(async () =>
        stream
          ? new Response(
              `data: ${JSON.stringify({ choices: [{ delta: { content: 'partial' }, finish_reason: 'length' }] })}\n\ndata: [DONE]\n\n`,
              { headers: { 'content-type': 'text/event-stream' } }
            )
          : Response.json(completion)
      )
      const response = await post(
        new ResponsesBridge({ baseUrl: 'https://provider.example/v1', model: 'test' }, upstream),
        '/responses',
        { input: 'continue', stream }
      )
      expect(response.status).toBe(200)
      const result = stream ? sse(await response.text()).at(-1)?.response : await response.json()
      expect(result).toMatchObject({ status: 'incomplete' })
    }
  )

  it.each([false, true])(
    'R02 Chat length cutoff maps to the max-output-tokens reason (stream=%s)',
    async (stream) => {
      const upstream = async (): Promise<Response> =>
        stream
          ? new Response(
              'data: {"choices":[{"delta":{"content":"partial"},"finish_reason":"length"}]}\n\ndata: [DONE]\n\n',
              { headers: { 'content-type': 'text/event-stream' } }
            )
          : Response.json({ choices: [{ message: { content: 'partial' }, finish_reason: 'length' }] })
      const response = await post(
        new ResponsesBridge({ baseUrl: 'https://provider.example/v1', model: 'test' }, upstream),
        '/responses',
        { input: 'continue', stream }
      )
      expect(response.status).toBe(200)
      const payload = stream ? sse(await response.text()).at(-1)?.response : await response.json()
      expect(payload).toMatchObject({
        status: 'incomplete',
        incomplete_details: { reason: 'max_output_tokens' },
        output: [{ status: 'incomplete' }]
      })
    }
  )

  it.each(['anthropic', 'openai'] as const)(
    'R02 Responses incomplete (length) preserves truncation for %s',
    async (wire) => {
      const response = await post(
        xai(wire, async () =>
          Response.json({
            ...responsePayload,
            status: 'incomplete',
            incomplete_details: { reason: 'max_output_tokens' }
          })
        ),
        wire === 'anthropic' ? '/v1/messages' : '/v1/chat/completions',
        textRequest
      )
      expect(response.status).toBe(200)
      const payload = await response.json()
      expect(wire === 'anthropic' ? payload.stop_reason : payload.choices[0].finish_reason).toBe(
        wire === 'anthropic' ? 'max_tokens' : 'length'
      )
    }
  )

  it('R02 Messages max_tokens preserves truncation in the Chat HTTP output', async () => {
    const response = await post(
      chat({ content: [{ type: 'text', text: 'partial' }], stop_reason: 'max_tokens' }),
      '/v1/chat/completions',
      textRequest
    )
    expect(response.status).toBe(200)
    expect((await response.json()).choices[0].finish_reason).toBe('length')
  })

  it.each([false, true])(
    'R02 truncation overrides a tool-call completion (Messages stream=%s)',
    async (stream) => {
      const response = await post(
        xai('anthropic', async () =>
          Response.json({
            ...responsePayload,
            status: 'incomplete',
            incomplete_details: { reason: 'max_output_tokens' },
            output: [
              { type: 'function_call', call_id: 'truncated', name: 'get_time', arguments: '{}' }
            ]
          })
        ),
        '/v1/messages',
        { ...textRequest, stream }
      )
      expect(response.status).toBe(200)
      const stopReason = stream
        ? sse(await response.text()).find((event) => event.type === 'message_delta')?.delta
            .stop_reason
        : (await response.json()).stop_reason
      expect(stopReason).toBe('max_tokens')
    }
  )

  it.each(['anthropic', 'openai'] as const)('R02 retains content filtering for %s', async (wire) => {
    const response = await post(
      xai(wire, async () =>
        Response.json({
          ...responsePayload,
          status: 'incomplete',
          incomplete_details: { reason: 'content_filter' }
        })
      ),
      wire === 'anthropic' ? '/v1/messages' : '/v1/chat/completions',
      textRequest
    )
    expect(response.status).toBe(200)
    const payload = await response.json()
    expect(wire === 'anthropic' ? payload.stop_reason : payload.choices[0].finish_reason).toBe(
      wire === 'anthropic' ? 'refusal' : 'content_filter'
    )
  })

  it.each([
    { wire: 'anthropic', reason: 'content_filter', expected: 'refusal', stream: false },
    { wire: 'anthropic', reason: 'content_filter', expected: 'refusal', stream: true },
    { wire: 'openai', reason: 'max_output_tokens', expected: 'length', stream: false },
    { wire: 'openai', reason: 'content_filter', expected: 'content_filter', stream: false },
    { wire: 'openai', reason: 'content_filter', expected: 'content_filter', stream: true }
  ] as const)(
    'R02 a $reason reply that ends on a tool call stays $expected ($wire, stream=$stream)',
    async ({ wire, reason, expected, stream }) => {
      const response = await post(
        xai(wire, async () =>
          Response.json({
            ...responsePayload,
            status: 'incomplete',
            incomplete_details: { reason },
            output: [
              { type: 'function_call', call_id: 'cut', name: 'get_time', arguments: '{}' }
            ]
          })
        ),
        wire === 'anthropic' ? '/v1/messages' : '/v1/chat/completions',
        { ...textRequest, stream }
      )
      expect(response.status).toBe(200)
      const reasons = stream
        ? sse(await response.text())
            .map((event) =>
              wire === 'anthropic' ? event.delta?.stop_reason : event.choices?.[0]?.finish_reason
            )
            .filter(Boolean)
        : [
            wire === 'anthropic'
              ? (await response.json()).stop_reason
              : (await response.json()).choices[0].finish_reason
          ]
      expect(reasons).toEqual([expected])
    }
  )

  it.each(['failed', 'cancelled', 'in_progress', 'unrecognized'])(
    'R02 rejects an explicit %s Responses result with a server error',
    async (status) => {
      const response = await post(
        xai('openai', async () => Response.json({ ...responsePayload, status })),
        '/v1/chat/completions',
        textRequest
      )
      expectServerError(response)
      expect(await response.json()).toHaveProperty('error')
    }
  )

  it.each(['failed', 'cancelled', 'in_progress', 'unrecognized'])(
    'R02 rejects an explicit %s Responses result for a Messages client',
    async (status) => {
      const response = await post(
        xai('anthropic', async () => Response.json({ ...responsePayload, status })),
        '/v1/messages',
        { ...textRequest, stream: status === 'in_progress' }
      )
      expectServerError(response)
      expect(response.headers.get('content-type')).toContain('application/json')
      expect(await response.json()).toHaveProperty('error')
    }
  )

  it.each(['anthropic', 'openai'] as const)(
    'R02 a Responses result with no status still comes back as an answer (%s)',
    async (wire) => {
      const { status: _omitted, ...withoutStatus } = responsePayload
      const response = await post(
        xai(wire, async () => Response.json(withoutStatus)),
        wire === 'anthropic' ? '/v1/messages' : '/v1/chat/completions',
        textRequest
      )
      expect(response.status).toBe(200)
      const payload = await response.json()
      expect(wire === 'anthropic' ? payload.stop_reason : payload.choices[0].finish_reason).toBe(
        wire === 'anthropic' ? 'end_turn' : 'stop'
      )
    }
  )

  it.each([false, true])(
    'R02 does not turn an unknown Messages stop reason into success (stream=%s)',
    async (stream) => {
      const response = await post(
        chat({ content: [{ type: 'text', text: 'partial' }], stop_reason: 'unexpected' }),
        '/v1/chat/completions',
        { ...textRequest, stream }
      )
      expectServerError(response)
      expect(await response.json()).toHaveProperty('error')
    }
  )

  it.each([
    { stopReason: 'max_tokens', finishReason: 'length' },
    { stopReason: 'refusal', finishReason: 'content_filter' },
    { stopReason: undefined, finishReason: 'stop' }
  ])(
    'R02 a streamed Chat reply keeps the Messages stop reason $stopReason as $finishReason',
    async ({ stopReason, finishReason }) => {
      const response = await post(
        chat({
          content: [{ type: 'text', text: 'partial' }],
          ...(stopReason ? { stop_reason: stopReason } : {})
        }),
        '/v1/chat/completions',
        { ...textRequest, stream: true }
      )
      expect(response.status).toBe(200)
      const reasons = sse(await response.text())
        .map((chunk) => chunk.choices?.[0]?.finish_reason)
        .filter(Boolean)
      expect(reasons).toEqual([finishReason])
    }
  )

  it.each([false, true])(
    'R02 Chat content_filter is reported as filtered over Responses HTTP (stream=%s)',
    async (stream) => {
      const upstream = async (): Promise<Response> =>
        stream
          ? new Response(
              'data: {"choices":[{"delta":{"content":"partial"},"finish_reason":"content_filter"}]}\n\ndata: [DONE]\n\n',
              { headers: { 'content-type': 'text/event-stream' } }
            )
          : Response.json({
              choices: [{ message: { content: 'partial' }, finish_reason: 'content_filter' }]
            })
      const response = await post(
        new ResponsesBridge({ baseUrl: 'https://provider.example/v1', model: 'test' }, upstream),
        '/responses',
        { input: 'continue', stream }
      )
      expect(response.status).toBe(200)
      const payload = stream ? sse(await response.text()).at(-1)?.response : await response.json()
      expect(payload).toMatchObject({
        status: 'incomplete',
        incomplete_details: { reason: 'content_filter' },
        output: [{ status: 'incomplete' }]
      })
    }
  )

  it.each([false, true])(
    'R02 a Chat reply with no finish reason still completes over Responses HTTP (stream=%s)',
    async (stream) => {
      const upstream = async (): Promise<Response> =>
        stream
          ? new Response('data: {"choices":[{"delta":{"content":"done"}}]}\n\ndata: [DONE]\n\n', {
              headers: { 'content-type': 'text/event-stream' }
            })
          : Response.json({ choices: [{ message: { content: 'done' } }] })
      const response = await post(
        new ResponsesBridge({ baseUrl: 'https://provider.example/v1', model: 'test' }, upstream),
        '/responses',
        { input: 'continue', stream }
      )
      expect(response.status).toBe(200)
      const payload = stream ? sse(await response.text()).at(-1)?.response : await response.json()
      expect(payload).toMatchObject({ status: 'completed', output: [{ status: 'completed' }] })
    }
  )

  it('R03 sums cached input totals and stays normalizable over HTTP', async () => {
    const response = await post(
      chat({
        content: [],
        stop_reason: 'end_turn',
        usage: {
          input_tokens: 3,
          cache_read_input_tokens: 10,
          cache_creation_input_tokens: 4,
          output_tokens: 2
        }
      }),
      '/v1/chat/completions',
      textRequest
    )
    expect(response.status).toBe(200)
    const payload = await response.json()
    // prompt_tokens = uncached(3) + cache-read(10) + cache-write(4) = 17.
    expect
      .soft(payload.usage)
      .toMatchObject({ prompt_tokens: 17, total_tokens: 19, completion_tokens: 2 })
    expect(normalizeOpenAiChatModelStepUsage(payload.usage)).toEqual({
      inputTokens: 3,
      cachedReadTokens: 10,
      cachedWriteTokens: 4,
      cacheTokens: 14,
      outputTokens: 2
    })
  })

  it('R04 emits a final usage chunk only when the caller opts in', async () => {
    const bridge = xai('openai', async () => Response.json(responsePayload))
    const json = await post(bridge, '/v1/chat/completions', textRequest)
    expect(json.status).toBe(200)
    const payload = await json.json()
    expect(payload.usage).toMatchObject({
      prompt_tokens: 12,
      prompt_tokens_details: { cached_tokens: 5 }
    })
    const response = await post(bridge, '/v1/chat/completions', {
      ...textRequest,
      stream: true,
      stream_options: { include_usage: true }
    })
    expect(response.status).toBe(200)
    const body = await response.text()
    expect(body).toContain('data: [DONE]')
    // Exactly one chunk carries usage, and it matches the JSON usage.
    const usageChunks = sse(body).filter((chunk) => chunk.usage)
    expect(usageChunks).toHaveLength(1)
    expect(usageChunks[0].usage).toEqual(payload.usage)
  })

  it.each([undefined, false])('R04 stays opt-out when usage is not requested (%s)', async (includeUsage) => {
    const response = await post(
      xai('openai', async () => Response.json(responsePayload)),
      '/v1/chat/completions',
      {
        ...textRequest,
        stream: true,
        ...(includeUsage === undefined ? {} : { stream_options: { include_usage: includeUsage } })
      }
    )
    expect(response.status).toBe(200)
    expect(sse(await response.text()).filter((chunk) => chunk.usage)).toEqual([])
  })

  it('R05 preserves two tool calls with a stable index for the Responses adapter', async () => {
    const response = await post(
      chat({
        content: [
          { type: 'tool_use', id: 'call_a', name: 'first', input: { a: 1 } },
          { type: 'tool_use', id: 'call_b', name: 'second', input: { b: 2 } }
        ],
        stop_reason: 'tool_use'
      }),
      '/v1/chat/completions',
      { ...textRequest, stream: true }
    )
    expect(response.status).toBe(200)
    const body = await response.text()
    const calls = sse(body).flatMap((chunk) => chunk.choices?.[0]?.delta?.tool_calls ?? [])
    expect.soft(calls.map((call) => call.index)).toEqual([0, 1])
    // The same stream, served by a Chat provider behind the Responses bridge.
    const converted = await post(
      new ResponsesBridge(
        { baseUrl: 'https://provider.example/v1', model: 'test' },
        async () => new Response(body, { headers: { 'content-type': 'text/event-stream' } })
      ),
      '/responses',
      { input: 'continue', stream: true }
    )
    expect(converted.status).toBe(200)
    expect(
      sse(await converted.text())
        .at(-1)
        ?.response.output.filter((item: Json) => item.type === 'function_call')
    ).toMatchObject([
      { call_id: 'call_a', name: 'first', arguments: '{"a":1}' },
      { call_id: 'call_b', name: 'second', arguments: '{"b":2}' }
    ])
  })

  it.each(['incomplete', 'completed'])(
    'R06 rejects invalid tool arguments with a server error instead of emitting an empty call (%s)',
    async (status) => {
      const response = await post(
        xai('anthropic', async () =>
          Response.json({
            ...responsePayload,
            status,
            incomplete_details: status === 'incomplete' ? { reason: 'max_output_tokens' } : null,
            output: [
              {
                type: 'function_call',
                call_id: 'call_bad',
                name: 'read_file',
                arguments: '{"path":'
              }
            ]
          })
        ),
        '/v1/messages',
        textRequest
      )
      const payload = await response.json()
      expect
        .soft(payload.content?.filter((part: Json) => part.type === 'tool_use') ?? [])
        .toEqual([])
      expectServerError(response)
      expect(payload).toHaveProperty('error')
    }
  )

  it.each(['null', '[]', '42', '"text"', undefined])(
    'R06 rejects non-object or missing arguments before any SSE (%s)',
    async (arguments_) => {
      const response = await post(
        xai('anthropic', async () =>
          Response.json({
            ...responsePayload,
            output: [{ type: 'function_call', call_id: 'bad', name: 'run', arguments: arguments_ }]
          })
        ),
        '/v1/messages',
        { ...textRequest, stream: true }
      )
      expectServerError(response)
      expect(response.headers.get('content-type')).toContain('application/json')
      expect(await response.json()).toHaveProperty('error')
    }
  )

  it('R06 control preserves a legitimate empty-object call', async () => {
    const response = await post(
      xai('anthropic', async () =>
        Response.json({
          ...responsePayload,
          output: [{ type: 'function_call', call_id: 'call_ok', name: 'get_time', arguments: '{}' }]
        })
      ),
      '/v1/messages',
      textRequest
    )
    expect(response.status).toBe(200)
    expect(await response.json()).toMatchObject({
      content: [{ type: 'tool_use', input: {} }],
      stop_reason: 'tool_use'
    })
  })

  it.each([
    { multiline: false, crlf: false },
    { multiline: true, crlf: false },
    { multiline: true, crlf: true }
  ])(
    'R07 restores tool identity across a complete SSE event (multiline=$multiline, crlf=$crlf)',
    async ({ multiline, crlf }) => {
      const upstream = vi.fn<typeof fetch>(async (_, init) => {
        const request = JSON.parse(String(init?.body))
        const item = {
          type: 'function_call',
          id: 'fc_a',
          call_id: 'call_a',
          name: request.tools[0].name,
          arguments: '{}'
        }
        const prefix = '{"type":"response.output_item.done",'
        const suffix = `"output_index":0,"item":${JSON.stringify(item)}}`
        const body = `: heartbeat\nevent: response.output_item.done\nid: event-1\nretry: 1500\ndata: ${prefix}${multiline ? '\ndata: ' : ''}${suffix}\n\nevent: unknown\ndata: not-json\n\ndata: [DONE]\n\n`
        const bytes = new TextEncoder().encode(crlf ? body.replaceAll('\n', '\r\n') : body)
        return new Response(
          new ReadableStream({
            start(controller) {
              // Chunk across field names and CRLF boundaries, not only events.
              for (let index = 0; index < bytes.length; index += 7)
                controller.enqueue(bytes.slice(index, index + 7))
              controller.close()
            }
          }),
          { headers: { 'content-type': 'text/event-stream' } }
        )
      })
      const response = await post(
        new NativeResponsesCompatibilityProxy(
          { baseUrl: 'https://provider.example/v1', model: 'test' },
          upstream
        ),
        '/responses',
        {
          input: 'lookup',
          stream: true,
          tools: [
            {
              type: 'namespace',
              name: 'mcp__audit',
              tools: [
                { type: 'function', name: 'lookup', parameters: { type: 'object', properties: {} } }
              ]
            }
          ]
        }
      )
      expect(response.status).toBe(200)
      const body = await response.text()
      // Comments, id/retry lines, and unknown events pass through unchanged,
      // each with the line ending it came with, the rewritten event included.
      const eol = crlf ? '\r\n' : '\n'
      expect(body).toContain(`: heartbeat${eol}`)
      expect(body).toContain(`id: event-1${eol}`)
      expect(body).toContain(`retry: 1500${eol}`)
      expect(body).toContain(`event: unknown${eol}data: not-json${eol}${eol}`)
      if (crlf) expect(body).not.toMatch(/[^\r]\n/)
      // The multi-line data is joined at the event boundary and tool identity
      // is restored.
      expect(sse(body.split('event: unknown')[0])[0].item).toMatchObject({
        name: 'lookup',
        namespace: 'mcp__audit',
        call_id: 'call_a'
      })
    }
  )

  it.each(['native', 'anthropic', 'chat'])(
    'R08 preserves nested business schema names and null constraints (%s)',
    async (wire) => {
      const schema = {
        type: 'object',
        properties: {
          safety_identifier: { type: 'string' },
          external_web_access: { type: 'boolean' },
          prompt_cache_retention: { type: 'string' },
          nullable: { const: null }
        },
        required: ['safety_identifier', 'nullable'],
        additionalProperties: false
      }
      const original = structuredClone(schema)
      const upstream = vi.fn<typeof fetch>(async () => Response.json(responsePayload))
      const response =
        wire === 'native'
          ? await post(nativeXai(upstream), '/responses', {
              input: 'Continue',
              stream: false,
              safety_identifier: 'metadata',
              tools: [{ type: 'function', name: 'audit', parameters: schema }]
            })
          : wire === 'anthropic'
            ? await post(xai('anthropic', upstream), '/v1/messages', {
                ...textRequest,
                max_tokens: 128,
                tools: [{ name: 'audit', input_schema: schema }]
              })
            : await post(xai('openai', upstream), '/v1/chat/completions', {
                ...textRequest,
                tools: [{ type: 'function', function: { name: 'audit', parameters: schema } }]
              })
      expect(response.status).toBe(200)
      await response.text()
      const sent = sentBody(upstream)
      // Only top-level metadata is stripped; the nested schema reaches xAI unchanged.
      expect(sent).not.toHaveProperty('safety_identifier')
      expect(sent.tools).toEqual([expect.objectContaining({ parameters: original })])
    }
  )

  it('R08 strips only top-level metadata and leaves tool output opaque', async () => {
    const data = {
      safety_identifier: null,
      external_web_access: false,
      prompt_cache_retention: 'business'
    }
    const tool = {
      type: 'function',
      name: 'audit',
      parameters: {
        type: 'object',
        properties: { value: { enum: [null, 'present'], default: null } }
      }
    }
    const upstream = vi.fn<typeof fetch>(async () => Response.json(responsePayload))
    const response = await post(nativeXai(upstream), '/responses', {
      stream: false,
      prompt_cache_retention: '24h',
      safety_identifier: 'wire',
      external_web_access: true,
      previous_response_id: null,
      metadata: data,
      input: [
        { type: 'function_call', call_id: 'a', name: 'audit', arguments: '{}' },
        { type: 'function_call_output', call_id: 'a', output: data }
      ],
      additional_tools: [tool]
    })
    expect(response.status).toBe(200)
    await response.text()
    const sent = sentBody(upstream)
    for (const key of [
      'prompt_cache_retention',
      'safety_identifier',
      'external_web_access',
      'previous_response_id',
      'additional_tools'
    ]) {
      expect(sent).not.toHaveProperty(key)
    }
    expect(sent.metadata).toEqual(data)
    expect(sent.tools).toContainEqual(tool)
    expect(sent.input).toContainEqual(
      expect.objectContaining({ type: 'function_call_output', call_id: 'a', output: data })
    )
  })
})
