## Task

The bridges that translate between Chat Completions, Anthropic Messages and Responses traffic have piled up bug reports, and all of it worked a few releases ago:

- A tool that returns an image doesn't get that image to the model. Codex talking to a Chat provider through the Responses bridge sees it turned into JSON text inside the tool message, and Claude Code talking to xAI loses it, whether it's inline base64 or a URL.
- Replies the provider stopped early look finished. When a Chat provider stops on `length` or `content_filter`, the Responses bridge reports the reply and its message as `completed`. Streamed, the reply does say incomplete, but its message still says `completed`, and a `length` stop gets `length` as the reason, which the Responses API doesn't have (it uses `max_output_tokens`). A truncated or filtered xAI reply reaches Claude Code as `end_turn`, or as `tool_use` when it ends on a tool call, and Chat clients get `stop`, or `tool_calls` when it ends on one. The Chat bridge in front of Claude turns `max_tokens` and `refusal` into `stop` too.
- Replies that never finished look fine as well. An xAI result whose status is `failed`, `cancelled`, `in_progress` or something we don't recognize comes through as a normal answer instead of failing the request, and so does a Claude stop reason we don't recognize. On a streamed reply the stream has already started by then. Some providers send no status or stop reason at all, and those still have to work.
- Token counts are wrong around the prompt cache. The Chat bridge in front of Claude leaves cache reads and writes out of `prompt_tokens`, and the cache writes vanish from our own step usage. The xAI bridge ignores `stream_options.include_usage`, so a streamed Chat reply never carries usage.
- When Claude makes two tool calls in one reply and the Chat bridge streams it, a Responses client reading that stream ends up with one merged call.
- Tool arguments from xAI that aren't a JSON object (broken JSON, `null`, an array, a number, a string, or no arguments at all) reach Claude Code as `{}` or as the bad value instead of failing the request, and on a streamed reply the stream has already started by then.
- On the native Responses proxy, a tool call event whose JSON spans several `data:` lines arrives without its namespaced tool name. Comments, `id:` and `retry:` lines, and events we don't know have to pass through as they are, CRLF included.
- Requests going to xAI lose more than the unsupported top-level fields we mean to drop. Tool schemas, tool results and request metadata arrive with parts missing.

Everything reproduces against a fake upstream with no network. Work out what's behind each one and fix it, with every conversion path still working.
