// Behavioral checks for 16-bit integer handling that are independent of any
// backend's generated source. They drive naga's public front-end and validator
// APIs and assert on returned error variants. When a tree does not understand
// 16-bit integers, the `enable wgpu_int16;` directive and the `i16`/`u16` types
// are unknown, `parse_str` returns an error, and the `.expect(...)` in the
// helper panics so the test fails; when 16-bit support is present, parsing
// succeeds and the validator reaches the specific rejection each test asserts.
//
// Capabilities::all() is used deliberately so the tests never name the
// feature's own capability flag — they assert observable rejection behaviour,
// not an internal constant.

use naga::front::wgsl::parse_str;
use naga::valid::{Capabilities, Validator, ValidationFlags};

/// Parse `src` and validate it with every capability enabled, returning the
/// validation error. Panics (failing the test) if parsing fails or if
/// validation unexpectedly succeeds.
#[track_caller]
fn validation_error(src: &str) -> naga::valid::ValidationError {
    let module = parse_str(src).expect("source should parse");
    Validator::new(ValidationFlags::all(), Capabilities::all())
        .validate(&module)
        .expect_err("module should fail validation")
        .into_inner()
}

/// A 16-bit atomic is not a legal atomic payload: the atomic-width check must
/// reject a 2-byte scalar rather than accept it. Both the unsigned and signed
/// forms are rejected with an invalid-atomic-width type error carrying the
/// 2-byte width.
#[test]
fn atomic_16bit_rejected() {
    for src in [
        "enable wgpu_int16; @group(0) @binding(0) var<storage, read_write> a: atomic<u16>;",
        "enable wgpu_int16; @group(0) @binding(0) var<storage, read_write> a: atomic<i16>;",
    ] {
        let err = validation_error(src);
        assert!(
            matches!(
                err,
                naga::valid::ValidationError::Type {
                    source: naga::valid::TypeError::InvalidAtomicWidth(_, 2),
                    ..
                }
            ),
            "expected an invalid-atomic-width rejection for a 2-byte atomic, got: {err:?}",
        );
    }
}

/// A 16-bit scalar is not a legal immediate (push-constant) payload: a global
/// in the immediate address space whose type is or contains a 16-bit scalar is
/// rejected with an invalid-scalar immediate error. Scalar, vector, and
/// struct-member forms are all rejected.
#[test]
fn immediate_16bit_rejected() {
    for src in [
        "enable wgpu_int16; var<immediate> input: i16;",
        "enable wgpu_int16; var<immediate> input: u16;",
        "enable wgpu_int16; var<immediate> input: vec2<i16>;",
        "enable wgpu_int16; struct S { a: u16 }; var<immediate> input: S;",
    ] {
        let err = validation_error(src);
        assert!(
            matches!(
                err,
                naga::valid::ValidationError::GlobalVariable {
                    source: naga::valid::GlobalVariableError::InvalidImmediateType(
                        naga::valid::ImmediateError::InvalidScalar(_),
                    ),
                    ..
                }
            ),
            "expected an invalid-scalar immediate rejection for a 16-bit immediate, got: {err:?}",
        );
    }
}
