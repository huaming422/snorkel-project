## Task

We want naga to understand 16-bit integers in shaders. Today you can't declare an `i16` or `u16` (or a vector like `vec2<i16>`) in WGSL and carry it through the compiler; we'd like that to work end to end.

Put it behind two gates, both required: a compiler capability turned on at validation time, and a WGSL source directive `enable wgpu_int16;` that a shader declares to opt in. Both must be present to use 16-bit integers.

This runs the length of the translation path: the IR type system, WGSL parsing, validation, constant evaluation, and codegen for every backend we emit (SPIR-V, Metal, HLSL, GLSL, and the WGSL round-trip). Each backend should emit its own native 16-bit representation rather than widening back to 32-bit.

A few things are deliberately out of scope, so please don't build them: 16-bit vertex-buffer and texture formats (shaders keep seeing 32-bit there), HLSL struct padding for sub-4-byte gaps, a WGSL literal suffix for 16-bit (values use `i16(…)`/`u16(…)`), `i16`/`u16` as switch selectors, 16-bit push-constants and immediates, 16-bit atomics, and GL/GLES device-feature reporting. Of those, 16-bit atomics and immediates are invalid rather than merely unsupported: reject them outright instead of quietly accepting them.

Keep the work inside the naga crate, as a new integer width alongside the existing 32-bit, 64-bit, and f16 types.

## User stories / requirements

- A WGSL shader that uses i16 or u16 without declaring `enable wgpu_int16;` fails to parse. The same shader with the enable directive present parses successfully.
- The validator only accepts i16/u16 types when the 16-bit integer capability is enabled; validating a module that uses them without it fails with a missing-capability error that names the 16-bit integer feature. With the capability enabled, a module using i16/u16 scalars and vectors validates cleanly.
- Generating SPIR-V for a module that stores an i16/u16 value in a storage buffer emits a 16-bit integer type and declares the SPIR-V capabilities required for 16-bit integers and for 16-bit storage-buffer access.
- Generating Metal for an i16/u16 module emits Metal's native 16-bit integer types with correctly-typed 16-bit literals, and the result is valid MSL, including bitcasts that don't trip C++ integer promotion into a size mismatch.
- Generating HLSL for an i16/u16 module emits HLSL's native 16-bit integer types, and a 16-bit bitcast uses a form that is valid for 16-bit types rather than the 32-bit-only reinterpret path.
- Generating GLSL for an i16/u16 module emits GLSL's own native 16-bit integer type for a 16-bit scalar rather than widening it back to a 32-bit integer.
- Emitting WGSL again for an i16/u16 module reproduces the `enable wgpu_int16;` opt-in directive the 16-bit types require, and the regenerated WGSL parses again cleanly.
- A const expression over 16-bit integers, including arithmetic and using a u16 value as an array index, evaluates to the correct result at compile time.
