## Task

The usage dashboard time-series, the quota planner's demand bins, and the per-API-key trend charts are all computed by scanning `request_logs` on every read. That gets slower as the table grows, and once retention prunes old rows, the numbers for those windows are gone.

Make these statistics permanent, so a past window's numbers stay correct after its raw rows are pruned. Endpoints, response shapes, and the frontend stay as they are.

Distinct conversation counts, report medians, calendar/timezone day aggregation, and the lifetime usage-summary read are out of scope and stay computed from raw logs.

## User stories / requirements

- The usage dashboard reads (the time-series at every bucket grain, the total-activity summaries, the top error code, and the earliest activity timestamp) return the same values as a full scan of the raw logs, both while a window's raw rows are still there and after they have been pruned. Once a window's raw rows are gone, its earliest activity timestamp only has to be right to the hour.
- The quota planner's demand bins match a full raw scan exactly, before and after a window's raw rows are pruned, including bins where one group of requests drives one demand component while a different group drives another in the same bin.
- The per-API-key trend buckets match a full raw scan before and after a window's raw rows are pruned, across older windows and the most recent activity that is still only in the raw logs.
- Capturing statistics runs incrementally in the background and is safe to repeat: running it again, resuming later, or rebuilding it from scratch while the raw rows still exist never changes what the reads return. Before anything has been captured, the reads return today's values from the raw logs, with nothing to switch on. A captured window takes the same space whether it held a few requests or thousands of identical ones.
- Retention never removes a raw row whose statistics have not been captured yet, so no retention pass loses a window's numbers, and a window whose raw rows were pruned still reports correct statistics.
- After an account is soft-deleted, hard-deleted, or merged into another account, the statistics show what the raw logs would: a soft-deleted account's history still appears under the deleted-account view, a hard-deleted account's history is gone, and a merged account's history moves onto the surviving account.
