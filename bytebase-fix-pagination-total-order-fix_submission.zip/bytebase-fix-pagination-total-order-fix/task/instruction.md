## Task

Operators report that paging through lists gives inconsistent results from one
page to the next. Some entries that exist never show up on any page, and others
appear on more than one page. It's most visible on the issues list, especially
the default "My Issues" view that spans every project a user belongs to, but
it's been seen on other paginated lists too.

The data isn't changing underneath them. Walking the same list page by page
over a static dataset still drops and repeats rows. Pull the whole list in one
shot with no paging and it looks correct; the problem only surfaces once
results get split into pages.

Figure out why paged reads fail and fix it so that reading an affected list
page by page returns every row exactly once, no gaps and no duplicates, even
when many rows look identical under the displayed ordering. A caller that asks
for a specific ordering still gets it, and the lists read as they do now
(filters, the most-recent-first default, search relevance) apart from being
stable across pages.
