#!/usr/bin/env bash
# Container setup for the verifier. Sourced (not exec'd) by the harbor runner so
# the exported VIRTUAL_ENV/PATH persist into the verifier subprocess. The
# verifier imports repository Python (app.gateway..., deerflow.utils...), so it
# must run under the project venv the image built at /opt/venv — NOT the
# isolated /opt/tooling verifier venv (which lacks fastapi/httpx and the repo
# packages).
set -u

REPO=/repo/deer-flow
cd "$REPO/backend" || { echo "test-setup: $REPO/backend missing" >&2; return 1 2>/dev/null || exit 1; }

# uv and the project venv the image prepared (block 10). Point uv at /opt/venv so
# `uv sync` resolves against the already-installed tree rather than creating a new
# one, and make that interpreter the default python/pytest the verifier invokes.
export UV_PROJECT_ENVIRONMENT=/opt/venv
export VIRTUAL_ENV=/opt/venv
export PATH="/opt/venv/bin:/usr/local/bin:$PATH"

# Build/verify the venv. The image already ran `uv sync --frozen --group dev`, so
# the offline resolve below is a fast no-op on a normal trial (no downloads). The
# oracle introduces no new dependency, so offline must succeed; the online retry
# is a logged fallback for a cold cache only (one resolve attempt, offline-first).
if uv sync --frozen --group dev --offline; then
    echo "test-setup: offline dependency sync ok"
else
    echo "test-setup: offline sync incomplete, retrying with network" >&2
    uv sync --frozen --group dev
fi

# Sanity: the modules under test (and the test infra they need) must import
# cleanly before any verifier runs.
python -c "import app.gateway.routers.uploads; import app.gateway.upload_ingestion; import deerflow.utils.file_io; import httpx" \
    && echo "test-setup: upload modules importable" \
    || echo "test-setup: WARNING upload module import failed" >&2
