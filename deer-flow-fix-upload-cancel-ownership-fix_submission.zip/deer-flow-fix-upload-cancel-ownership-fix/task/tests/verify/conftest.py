"""Import + context setup for the isolated upload-cancellation suite.

This verifier runs from ``/tests/verify/`` (the runner's cwd is the repo root,
``/repo/deer-flow``), so the repository's own ``backend/tests/conftest.py`` is
not auto-collected. Re-create the three things that suite needs:

  1. ``backend`` and ``backend/tests`` on ``sys.path`` so ``import app``,
     ``import deerflow`` and ``import _router_auth_helpers`` resolve.
  2. A stub for ``deerflow.subagents.executor`` injected before any test module
     triggers the import — the production package has a known circular import
     (``subagents.__init__`` -> ``.executor`` -> ``agents.thread_state`` -> ...
     -> ``subagents.executor``) that only resolves when the executor module is
     already present in ``sys.modules``.
  3. A default user bound on the request contextvar, mirroring the repository
     suite's autouse fixture (uploads resolve a per-user bucket).
"""

from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

_BACKEND = Path("/repo/deer-flow/backend")
for candidate in (_BACKEND, _BACKEND / "tests"):
    entry = str(candidate)
    if candidate.exists() and entry not in sys.path:
        sys.path.insert(0, entry)

# Break the production circular import before any `from app...` import runs.
if "deerflow.subagents.executor" not in sys.modules:
    _executor_mock = MagicMock()
    _executor_mock.SubagentExecutor = MagicMock
    _executor_mock.SubagentResult = MagicMock
    _executor_mock.SubagentStatus = MagicMock
    _executor_mock.MAX_CONCURRENT_SUBAGENTS = 3
    _executor_mock.get_background_task_result = MagicMock()
    sys.modules["deerflow.subagents.executor"] = _executor_mock


@pytest.fixture(autouse=True)
def _auto_user_context():
    """Bind a default user on the contextvar uploads read for path resolution."""
    try:
        from deerflow.runtime.user_context import reset_current_user, set_current_user
    except ImportError:
        yield
        return
    token = set_current_user(SimpleNamespace(id="verify-user", email="verify@local"))
    try:
        yield
    finally:
        reset_current_user(token)
