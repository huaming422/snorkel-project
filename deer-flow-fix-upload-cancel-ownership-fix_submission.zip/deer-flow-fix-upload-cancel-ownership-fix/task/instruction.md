## Task

when a file upload gets cancelled (a client drops the connection mid-upload, or the server aborts the request while it's still in flight), the thread's uploads directory is left in a mess.

a few things we've seen: hidden partial staging files pile up and never get cleaned out; every so often a file from a half-finished upload lands in the directory as a published file, looking like it succeeded even though the request failed; and once in a while a staged file is left with its handle still open.

it only shows up on cancellation. uploads that run all the way through are fine. it's timing-dependent, so it comes and goes.

a cancelled upload should leave the uploads directory exactly as it found it, and it shouldn't touch files that other requests put there. dig in and fix it.
