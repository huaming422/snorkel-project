## Task

we're getting connections corrupted when they run an explicit checkpoint while one of their own statements is still in flight. depending on timing it panics, drops a write, or comes back with the wrong rows. it's intermittent and a pain to reproduce: it only bites when the checkpoint lands while a statement on that same connection is suspended partway through its work, paused at an i/o boundary, so the vast majority of checkpoints are completely fine. this used to be safe, and a recent change is what made that overlap destructive.

dig in, work out why checkpointing a connection that has an in-flight statement corrupts it, and get the two to coordinate safely again. a checkpoint on a connection with nothing else running on it should still go through cleanly.
