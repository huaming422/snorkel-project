#![cfg(feature = "io_memory_yield")]

//! Behavioral verifier for turso-fix-checkpoint-stmt-overlap.
//!
//! Every test exercises only the pre-existing, stable public surface of
//! `turso_core`, so the file compiles unchanged against both the broken and
//! the repaired tree and the difference shows up as a runtime behavior, not a
//! build error:
//!
//!   * `Connection::checkpoint(CheckpointMode)` and `PRAGMA wal_checkpoint`
//!     (driven through `Connection::prepare(...).run_collect_rows()`) — the two
//!     explicit-checkpoint entry points.
//!   * `Connection::blob_open` / `Blob::read` / `Blob::close` — the incremental
//!     blob handle.
//!   * `LimboError::StatementsInProgress` and `LimboError::BlobHandleExpired` —
//!     both already present in `core/error.rs`.
//!   * `MemoryYieldIO` + `StepResult::{IO, Done, Yield, Row}` + `io.step()` —
//!     the in-memory yielding I/O (feature `io_memory_yield`) used to park a
//!     statement at an exact asynchronous I/O boundary.
//!
//! None of the fix's internal machinery (the activity flag, the counters, the
//! guard type, the blob-handle marker) is named or imported: a correct
//! solution is free to structure those however it likes. The tests only watch
//! what a caller can see — the rejection signal, the suspended statement
//! staying resumable, the final rows, `PRAGMA integrity_check`, and that an
//! open blob handle never forces a checkpoint to be refused.

use std::sync::Arc;

use turso_core::{
    CheckpointMode, Connection, Database, LimboError, MemoryYieldIO, SqliteDialect, StepResult, IO,
};

fn open_conn(io: Arc<MemoryYieldIO>, path: &str) -> Arc<Connection> {
    Database::open_file(io, path, Arc::new(SqliteDialect))
        .unwrap()
        .connect()
        .unwrap()
}

fn integrity_check(conn: &Arc<Connection>) -> Vec<String> {
    conn.prepare("PRAGMA integrity_check")
        .unwrap()
        .run_collect_rows()
        .unwrap()
        .into_iter()
        .map(|row| row[0].to_string())
        .collect()
}

fn ids(conn: &Arc<Connection>, sql: &str) -> Vec<i64> {
    conn.prepare(sql)
        .unwrap()
        .run_collect_rows()
        .unwrap()
        .into_iter()
        .map(|row| row[0].as_int().unwrap())
        .collect()
}

/// Seeds a small WAL database with a free list (rows inserted then some
/// deleted, then truncated) so that a following large INSERT has to walk
/// several pages and therefore yields at many asynchronous I/O boundaries —
/// giving each sweep below a genuine mid-execution point to park at.
fn seed_freelist_db(io: &Arc<MemoryYieldIO>, path: &str) {
    let conn = open_conn(io.clone(), path);
    conn.execute("PRAGMA page_size=512").unwrap();
    conn.execute("PRAGMA journal_mode = 'wal'").unwrap();
    conn.execute("CREATE TABLE t(id INTEGER PRIMARY KEY, b BLOB)")
        .unwrap();
    conn.execute(
        "INSERT INTO t VALUES
         (1, zeroblob(50000)),
         (2, zeroblob(50000)),
         (3, zeroblob(50000)),
         (4, zeroblob(50000)),
         (5, zeroblob(50000))",
    )
    .unwrap();
    conn.execute("DELETE FROM t WHERE id IN (2,3,4)").unwrap();
    conn.execute("PRAGMA wal_checkpoint(TRUNCATE)").unwrap();
}

/// Criterion 1 — the direct `Connection::checkpoint` API.
///
/// With one of the connection's own statements parked mid-execution, the
/// checkpoint API must refuse to run (running it would pull the suspended
/// statement's cursors and cached pages out from under it) and report
/// `StatementsInProgress`. The parked statement then resumes to completion
/// with exactly the rows it would have produced undisturbed, and the database
/// reports `integrity_check` = ok.
#[test]
fn test_checkpoint_api_rejects_suspended_statement_and_keeps_it_resumable() {
    for target_io in 1..=512 {
        let io = Arc::new(MemoryYieldIO::new());
        let temp_dir = tempfile::TempDir::new().unwrap();
        let path = temp_dir
            .path()
            .join(format!("api-checkpoint-{target_io}.db"));
        let path = path.to_str().unwrap();

        seed_freelist_db(&io, path);
        let conn = open_conn(io.clone(), path);
        let mut stmt = conn
            .prepare("INSERT INTO t VALUES (100, zeroblob(50000))")
            .unwrap();

        let mut io_count = 0;
        let suspended = loop {
            match stmt.step().unwrap() {
                StepResult::IO => {
                    io_count += 1;
                    if io_count == target_io {
                        break true;
                    }
                    io.step().unwrap();
                }
                StepResult::Done => break false,
                StepResult::Yield => {}
                other => panic!("unexpected INSERT step result: {other:?}"),
            }
        };
        if !suspended {
            assert!(
                target_io > 1,
                "INSERT completed without yielding at an I/O boundary"
            );
            break;
        }

        let err = conn
            .checkpoint(CheckpointMode::Passive {
                upper_bound_inclusive: None,
            })
            .expect_err("Connection::checkpoint must refuse a suspended statement");
        assert!(
            matches!(err, LimboError::StatementsInProgress(_)),
            "target_io={target_io}: unexpected checkpoint error: {err:?}"
        );

        loop {
            match stmt
                .step()
                .unwrap_or_else(|err| panic!("target_io={target_io}: resumed INSERT failed: {err}"))
            {
                StepResult::IO => io.step().unwrap(),
                StepResult::Done => break,
                StepResult::Yield => {}
                other => panic!("unexpected resumed INSERT step result: {other:?}"),
            }
        }
        drop(stmt);

        assert_eq!(
            ids(&conn, "SELECT id FROM t ORDER BY id"),
            vec![1, 5, 100],
            "target_io={target_io}: resumed INSERT produced the wrong rows"
        );
        assert_eq!(
            integrity_check(&conn),
            vec!["ok"],
            "target_io={target_io}: database corrupted after the sequence"
        );
    }
}

/// Criterion 2 — the in-statement entry point, `PRAGMA wal_checkpoint`.
///
/// The same guarantee must hold when the checkpoint is requested through the
/// PRAGMA rather than the API: with a statement parked mid-execution, the
/// PRAGMA is rejected with `StatementsInProgress` and the parked statement
/// stays resumable, finishing with the correct rows and a clean
/// `integrity_check`.
#[test]
fn test_wal_checkpoint_pragma_rejects_suspended_statement_and_keeps_it_resumable() {
    for target_io in 1..=512 {
        let io = Arc::new(MemoryYieldIO::new());
        let temp_dir = tempfile::TempDir::new().unwrap();
        let path = temp_dir
            .path()
            .join(format!("pragma-checkpoint-{target_io}.db"));
        let path = path.to_str().unwrap();

        seed_freelist_db(&io, path);
        let conn = open_conn(io.clone(), path);
        let mut stmt = conn
            .prepare("INSERT INTO t VALUES (100, zeroblob(50000))")
            .unwrap();

        let mut io_count = 0;
        let suspended = loop {
            match stmt.step().unwrap() {
                StepResult::IO => {
                    io_count += 1;
                    if io_count == target_io {
                        break true;
                    }
                    io.step().unwrap();
                }
                StepResult::Done => break false,
                StepResult::Yield => {}
                other => panic!("unexpected INSERT step result: {other:?}"),
            }
        };
        if !suspended {
            assert!(
                target_io > 1,
                "INSERT completed without yielding at an I/O boundary"
            );
            break;
        }

        let err = conn
            .prepare("PRAGMA wal_checkpoint(PASSIVE)")
            .unwrap()
            .run_collect_rows()
            .expect_err("PRAGMA wal_checkpoint must refuse a suspended statement");
        assert!(
            matches!(err, LimboError::StatementsInProgress(_)),
            "target_io={target_io}: unexpected checkpoint error: {err:?}"
        );

        loop {
            match stmt
                .step()
                .unwrap_or_else(|err| panic!("target_io={target_io}: resumed INSERT failed: {err}"))
            {
                StepResult::IO => io.step().unwrap(),
                StepResult::Done => break,
                StepResult::Yield => {}
                other => panic!("unexpected resumed INSERT step result: {other:?}"),
            }
        }
        drop(stmt);

        assert_eq!(
            ids(&conn, "SELECT id FROM t ORDER BY id"),
            vec![1, 5, 100],
            "target_io={target_io}: resumed INSERT produced the wrong rows"
        );
        assert_eq!(
            integrity_check(&conn),
            vec!["ok"],
            "target_io={target_io}: database corrupted after the sequence"
        );
    }
}

/// Criterion 3 — the coordination holds in the other direction too.
///
/// A `PRAGMA wal_checkpoint` can itself suspend across its own I/O. While it
/// is parked, a freshly prepared statement on the same connection must not be
/// allowed to start: its first step is rejected with `StatementsInProgress`.
/// Once the checkpoint finishes and nothing else is running, a normal INSERT
/// on the connection succeeds again.
#[test]
fn test_suspended_checkpoint_rejects_new_statement() {
    let io = Arc::new(MemoryYieldIO::new());
    let temp_dir = tempfile::TempDir::new().unwrap();
    let path = temp_dir.path().join("checkpoint-before-insert.db");
    let path = path.to_str().unwrap();

    seed_freelist_db(&io, path);
    // A large UPDATE on a separate connection grows the WAL so the checkpoint
    // below has real work to do and parks on its own I/O.
    open_conn(io.clone(), path)
        .execute("UPDATE t SET b = zeroblob(51000) WHERE id = 1")
        .unwrap();

    let conn = open_conn(io.clone(), path);
    let mut checkpoint = conn.prepare("PRAGMA wal_checkpoint(PASSIVE)").unwrap();
    loop {
        match checkpoint.step().unwrap() {
            StepResult::IO if checkpoint.get_pager().is_checkpointing() => break,
            StepResult::IO => io.step().unwrap(),
            StepResult::Yield => {}
            other => panic!("checkpoint completed before it could suspend: {other:?}"),
        }
    }

    let mut insert = conn
        .prepare("INSERT INTO t VALUES (100, zeroblob(50000))")
        .unwrap();
    let err = insert
        .step()
        .expect_err("a suspended checkpoint must refuse a new statement");
    assert!(
        matches!(err, LimboError::StatementsInProgress(_)),
        "unexpected INSERT error: {err:?}"
    );
    drop(insert);

    loop {
        match checkpoint.step().unwrap() {
            StepResult::IO => io.step().unwrap(),
            StepResult::Row | StepResult::Yield => {}
            StepResult::Done => break,
            other => panic!("unexpected checkpoint result: {other:?}"),
        }
    }
    drop(checkpoint);
    assert!(!conn.get_pager().is_checkpointing());

    // With the checkpoint done and the connection idle, a normal write works.
    conn.execute("INSERT INTO t VALUES (100, zeroblob(50000))")
        .unwrap();
    assert_eq!(integrity_check(&conn), vec!["ok"]);
}

/// Criterion 4 — an open incremental blob handle must NOT block a checkpoint.
///
/// A blob handle keeps a backing statement parked on its row for the whole
/// time it is open, but between blob operations it is just sitting there, and
/// SQLite checkpoints fine with open blob handles. So both explicit-checkpoint
/// entry points must succeed while a blob handle is live. After the checkpoint
/// clears the page cache, the next blob read either succeeds or fails cleanly
/// with `BlobHandleExpired` — it must never be refused as
/// `StatementsInProgress`, and must never return wrong bytes. Once the handle
/// is closed, a fresh idle checkpoint still succeeds, proving the handle's
/// accounting was balanced rather than permanently charged.
#[test]
fn test_open_blob_handle_does_not_block_explicit_checkpoints() {
    let io = Arc::new(MemoryYieldIO::new());
    let temp_dir = tempfile::TempDir::new().unwrap();
    let path = temp_dir.path().join("blob-checkpoint.db");
    let path = path.to_str().unwrap();

    seed_freelist_db(&io, path);
    conn_exec_blob_payload(&io, path);

    let conn = open_conn(io.clone(), path);
    let mut blob = conn.blob_open("t", "b", 1, false).unwrap();
    let mut buf = [0u8; 4];
    blob.read(0, &mut buf).unwrap();
    assert_eq!(buf, [0x00, 0x11, 0x22, 0x33]);

    conn.prepare("PRAGMA wal_checkpoint(PASSIVE)")
        .unwrap()
        .run_collect_rows()
        .expect("PRAGMA wal_checkpoint must run with an open blob handle");
    conn.checkpoint(CheckpointMode::Passive {
        upper_bound_inclusive: None,
    })
    .expect("Connection::checkpoint must run with an open blob handle");

    match blob.read(4, &mut buf) {
        Ok(()) => assert_eq!(buf, [0x44, 0x55, 0x66, 0x77], "blob read returned wrong bytes"),
        Err(err) => assert!(
            matches!(err, LimboError::BlobHandleExpired),
            "a blob read after a checkpoint must only fail with BlobHandleExpired, got: {err:?}"
        ),
    }
    blob.close().unwrap();

    // The handle released its accounting on close, so an idle checkpoint runs.
    conn.checkpoint(CheckpointMode::Passive {
        upper_bound_inclusive: None,
    })
    .expect("idle checkpoint after closing the blob handle must succeed");
    assert_eq!(integrity_check(&conn), vec!["ok"]);
}

/// Writes a known 16-byte pattern into row 1's blob column so the blob-handle
/// read assertions above have a fixed value to check.
fn conn_exec_blob_payload(io: &Arc<MemoryYieldIO>, path: &str) {
    let conn = open_conn(io.clone(), path);
    conn.execute("UPDATE t SET b = x'00112233445566778899aabbccddeeff' WHERE id = 1")
        .unwrap();
}

/// Criterion 5 — a refused checkpoint leaves nothing behind.
///
/// After a checkpoint has been rejected because a statement was parked, that
/// rejection must not strand any half-started checkpoint state on the
/// connection. Once the parked statement is finished and the connection is
/// idle, a brand-new explicit checkpoint has to run to completion normally.
#[test]
fn test_rejected_checkpoint_leaves_clean_state() {
    for target_io in 1..=512 {
        let io = Arc::new(MemoryYieldIO::new());
        let temp_dir = tempfile::TempDir::new().unwrap();
        let path = temp_dir
            .path()
            .join(format!("clean-state-{target_io}.db"));
        let path = path.to_str().unwrap();

        seed_freelist_db(&io, path);
        let conn = open_conn(io.clone(), path);
        let mut stmt = conn
            .prepare("INSERT INTO t VALUES (100, zeroblob(50000))")
            .unwrap();

        let mut io_count = 0;
        let suspended = loop {
            match stmt.step().unwrap() {
                StepResult::IO => {
                    io_count += 1;
                    if io_count == target_io {
                        break true;
                    }
                    io.step().unwrap();
                }
                StepResult::Done => break false,
                StepResult::Yield => {}
                other => panic!("unexpected INSERT step result: {other:?}"),
            }
        };
        if !suspended {
            assert!(
                target_io > 1,
                "INSERT completed without yielding at an I/O boundary"
            );
            break;
        }

        let err = conn
            .checkpoint(CheckpointMode::Passive {
                upper_bound_inclusive: None,
            })
            .expect_err("Connection::checkpoint must refuse a suspended statement");
        assert!(
            matches!(err, LimboError::StatementsInProgress(_)),
            "target_io={target_io}: unexpected checkpoint error: {err:?}"
        );

        loop {
            match stmt
                .step()
                .unwrap_or_else(|err| panic!("target_io={target_io}: resumed INSERT failed: {err}"))
            {
                StepResult::IO => io.step().unwrap(),
                StepResult::Done => break,
                StepResult::Yield => {}
                other => panic!("unexpected resumed INSERT step result: {other:?}"),
            }
        }
        drop(stmt);

        // Nothing is running now; a fresh checkpoint must go through cleanly.
        conn.checkpoint(CheckpointMode::Passive {
            upper_bound_inclusive: None,
        })
        .unwrap_or_else(|err| panic!("target_io={target_io}: idle checkpoint failed: {err}"));

        assert_eq!(
            ids(&conn, "SELECT id FROM t ORDER BY id"),
            vec![1, 5, 100],
            "target_io={target_io}: wrong rows after the sequence"
        );
        assert_eq!(
            integrity_check(&conn),
            vec!["ok"],
            "target_io={target_io}: database corrupted after the sequence"
        );
    }
}
