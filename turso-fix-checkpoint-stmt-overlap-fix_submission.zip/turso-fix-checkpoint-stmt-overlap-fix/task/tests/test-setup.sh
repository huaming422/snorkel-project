#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
#
# Offline-first: the image baked the full dependency closure at the base commit
# (cargo fetch + a warm `cargo build --locked --workspace --lib --tests
# --all-features`). This step must not reach the network — export the offline
# switch right after cd so a cache miss fails fast instead of hanging on a dead
# registry during the smoke gate's `docker run --network none` fold.
cd /repo/turso

export CARGO_NET_OFFLINE=true

# Pre-warm the core_tester test crate so the verifier's first `cargo test`
# pays only for compiling the newly-injected verify test binary, not the whole
# workspace. --no-run compiles tests without executing them. The verifier needs
# the io_memory_yield feature (MemoryYieldIO) to suspend a statement at an exact
# I/O boundary. Offline-first against the image bake, with a logged online
# fallback in case the bake was stale.
if cargo test --locked --offline -p core_tester --features io_memory_yield --no-run \
        > /tmp/test-setup-build.log 2>&1; then
    echo "[offline-first] core_tester test binaries built from image cache"
elif cargo test --locked -p core_tester --features io_memory_yield --no-run \
        >> /tmp/test-setup-build.log 2>&1; then
    echo "[test-setup] core_tester test binaries built online (image bake was stale)"
else
    tail -80 /tmp/test-setup-build.log >&2
    exit 1
fi
