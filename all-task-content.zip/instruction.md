## Task

We've seen non-equi joins return the wrong rows when DataFusion is run with a constrained memory pool. Repeating the same query with more memory gives the expected result, while the constrained run can finish successfully with rows missing or duplicated.

This has shown up across several non-equi join types. Please track down why the constrained run can report success with a different result and fix the inconsistency.
