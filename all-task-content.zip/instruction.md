## Task

Our automation runs the same Dalfox scans through the CLI, the HTTP service, and the MCP interface. The CLI behaves reliably, but the two service interfaces have become inconsistent with it.

We have seen scans start for bare hostnames and unsupported URL schemes, and mistyped numeric options are quietly replaced by defaults. Those requests should be rejected instead of appearing to run normally. We have also seen targets that could not be contacted recorded as completed scans with no findings, making them indistinguishable from targets that were actually checked. An HTTP response of any status still means the target was contacted; a transport failure does not.

There are a few other operational symptoms. MCP scans configured with a blind-XSS callback do not produce the expected callback-bearing traffic. Progress remains at zero throughout a running scan and only changes when it finishes. Rarely, scans submitted close together receive the same identifier and one replaces the other.

Please restore consistent behavior across the HTTP and MCP interfaces without changing the established CLI behavior.
