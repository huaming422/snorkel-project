#!/usr/bin/env bash
# Test-setup for datafusion-fix-nlj-spill-correctness. The image pre-warms the
# cargo registry + build cache for the crate under change
# (`datafusion-physical-plan --tests`) and the core `memory_limit` integration
# test target. No services to start, no data to seed — the verifier runs cargo
# tests against the in-process DataFusion engine.

set -euo pipefail

echo "[test-setup] Rust version:    $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:   $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root:  /repo/datafusion"
echo "[test-setup] Setup complete."
