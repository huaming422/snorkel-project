// Behavioral verifier for memory-limited non-equi nested-loop joins.
//
// The test is injected into `datafusion/core/tests/` and exercises only public
// APIs. It compares constrained and ample-memory row sets for single-partition
// execution, checks multi-partition behavior, preserves working spill paths,
// and covers the empty-left-input case.

use std::sync::Arc;

use arrow::array::{Int32Array, RecordBatch};
use arrow::datatypes::{DataType, Field, Schema};

use datafusion::datasource::memory::MemorySourceConfig;
use datafusion::execution::runtime_env::RuntimeEnvBuilder;
use datafusion::physical_plan::common::collect;
use datafusion::physical_plan::expressions::{BinaryExpr, Column, Literal};
use datafusion::physical_plan::joins::NestedLoopJoinExec;
use datafusion::physical_plan::joins::utils::{ColumnIndex, JoinFilter};
use datafusion::physical_plan::repartition::RepartitionExec;
use datafusion::physical_plan::{ExecutionPlan, Partitioning, PhysicalExpr};
use datafusion::prelude::{SessionConfig, SessionContext};
use datafusion_common::{DataFusionError, JoinSide, JoinType, ScalarValue};
use datafusion_execution::TaskContext;
use datafusion_expr::Operator;

// ===========================================================================
// Memory-limited row-set equality through the public SQL interface.
// ===========================================================================

/// Deterministic table with repeated keys and a mix of matching and non-matching
/// rows, so constrained and ample executions can be compared exactly.
fn table(rows: usize, value_column: &str, seed: u64) -> RecordBatch {
    let mut state = seed;
    let mut next = || {
        state = state
            .wrapping_mul(6364136223846793005)
            .wrapping_add(1442695040888963407);
        state >> 33
    };
    let schema = Arc::new(Schema::new(vec![
        Field::new("k", DataType::Int32, true),
        Field::new(value_column, DataType::Int32, true),
    ]));
    let keys: Vec<Option<i32>> = (0..rows).map(|_| Some((next() % 10) as i32)).collect();
    let values: Vec<Option<i32>> = (0..rows).map(|_| Some((next() % 60) as i32)).collect();
    RecordBatch::try_new(
        schema,
        vec![
            Arc::new(Int32Array::from(keys)),
            Arc::new(Int32Array::from(values)),
        ],
    )
    .unwrap()
}

/// Run `sql`, optionally under a memory limit, returning the sorted rows as
/// `|`-joined cell strings.
async fn run_sql(sql: &str, memory_limit: Option<usize>) -> Vec<String> {
    let config = SessionConfig::new()
        .with_target_partitions(1)
        .with_batch_size(16);
    let runtime = match memory_limit {
        Some(bytes) => RuntimeEnvBuilder::new()
            .with_memory_limit(bytes, 1.0)
            .build_arc()
            .unwrap(),
        None => RuntimeEnvBuilder::new().build_arc().unwrap(),
    };
    let ctx = SessionContext::new_with_config_rt(config, runtime);
    ctx.register_batch("l", table(200, "v", 11)).unwrap();
    ctx.register_batch("r", table(90, "w", 16)).unwrap();

    let batches = ctx.sql(sql).await.unwrap().collect().await.unwrap();
    let mut rows = vec![];
    for batch in &batches {
        for row in 0..batch.num_rows() {
            let cells: Vec<String> = (0..batch.num_columns())
                .map(|col| {
                    ScalarValue::try_from_array(batch.column(col), row)
                        .unwrap()
                        .to_string()
                })
                .collect();
            rows.push(cells.join("|"));
        }
    }
    rows.sort();
    rows
}

/// A constrained non-equi `LEFT JOIN` must return the same rows as the
/// ample-memory execution.
#[tokio::test(flavor = "multi_thread")]
async fn left_join_spill_rowset_matches_ample() {
    let sql = "SELECT l.k, r.w FROM l LEFT JOIN r ON l.v > r.w";

    let ample = run_sql(sql, None).await;
    let limited = run_sql(sql, Some(64)).await;

    assert!(!ample.is_empty(), "expected the query to produce rows");
    assert_eq!(
        limited,
        ample,
        "memory-limited LEFT JOIN returned {} rows instead of {}",
        limited.len(),
        ample.len()
    );
}

/// Compare constrained and ample executions for join shapes whose output is
/// especially sensitive to missing or extra unmatched rows.
#[tokio::test(flavor = "multi_thread")]
async fn anti_and_full_join_spill_rowset_matches_ample() {
    let anti = "SELECT l.k, l.v FROM l WHERE NOT EXISTS (SELECT 1 FROM r WHERE l.v > r.w)";
    let ample_anti = run_sql(anti, None).await;
    let limited_anti = run_sql(anti, Some(64)).await;
    assert!(
        !ample_anti.is_empty(),
        "expected the LEFT ANTI query to match some rows"
    );
    assert_eq!(
        limited_anti,
        ample_anti,
        "memory-limited LEFT ANTI returned {} rows instead of {}",
        limited_anti.len(),
        ample_anti.len()
    );

    let full = "SELECT l.k, r.w FROM l FULL JOIN r ON l.v > r.w";
    let ample_full = run_sql(full, None).await;
    let limited_full = run_sql(full, Some(64)).await;
    assert!(
        !ample_full.is_empty(),
        "expected the FULL JOIN query to produce rows"
    );
    assert_eq!(
        limited_full,
        ample_full,
        "memory-limited FULL JOIN returned {} rows instead of {}",
        limited_full.len(),
        ample_full.len()
    );
}

/// A join whose left input is empty must still finish cleanly under a tight
/// memory limit and return the same empty row set as the ample-memory run.
#[tokio::test(flavor = "multi_thread")]
async fn empty_left_input_join_finishes_cleanly() {
    async fn run_empty_left(memory_limit: Option<usize>) -> Vec<String> {
        let config = SessionConfig::new()
            .with_target_partitions(1)
            .with_batch_size(16);
        let runtime = match memory_limit {
            Some(bytes) => RuntimeEnvBuilder::new()
                .with_memory_limit(bytes, 1.0)
                .build_arc()
                .unwrap(),
            None => RuntimeEnvBuilder::new().build_arc().unwrap(),
        };
        let ctx = SessionContext::new_with_config_rt(config, runtime);
        ctx.register_batch("l", table(0, "v", 11)).unwrap();
        ctx.register_batch("r", table(90, "w", 16)).unwrap();
        let batches = ctx
            .sql("SELECT l.k, r.w FROM l LEFT JOIN r ON l.v > r.w")
            .await
            .unwrap()
            .collect()
            .await
            .unwrap();
        let mut rows = vec![];
        for batch in &batches {
            for row in 0..batch.num_rows() {
                let cells: Vec<String> = (0..batch.num_columns())
                    .map(|col| {
                        ScalarValue::try_from_array(batch.column(col), row)
                            .unwrap()
                            .to_string()
                    })
                    .collect();
                rows.push(cells.join("|"));
            }
        }
        rows.sort();
        rows
    }

    let ample = run_empty_left(None).await;
    let limited = run_empty_left(Some(64)).await;
    assert_eq!(
        limited, ample,
        "empty-left join disagreed between ample ({}) and limited ({}) pools",
        ample.len(),
        limited.len()
    );
}

// ===========================================================================
// Multi-partition behavior under a tight pool, through the public plan API.
// ===========================================================================

/// Three-row int table `(a, b, c)` as a single-partition, multi-batch source.
fn mem_table(a: (&str, &[i32]), b: (&str, &[i32]), c: (&str, &[i32])) -> Arc<dyn ExecutionPlan> {
    assert_eq!(a.1.len(), b.1.len());
    assert_eq!(a.1.len(), c.1.len());
    let schema = Arc::new(Schema::new(vec![
        Field::new(a.0, DataType::Int32, false),
        Field::new(b.0, DataType::Int32, false),
        Field::new(c.0, DataType::Int32, false),
    ]));
    let batches = (0..a.1.len())
        .map(|row| {
            RecordBatch::try_new(
                Arc::clone(&schema),
                vec![
                    Arc::new(Int32Array::from(vec![a.1[row]])),
                    Arc::new(Int32Array::from(vec![b.1[row]])),
                    Arc::new(Int32Array::from(vec![c.1[row]])),
                ],
            )
            .unwrap()
        })
        .collect::<Vec<_>>();
    MemorySourceConfig::try_new_exec(&[batches], schema, None).unwrap()
}

fn build_left() -> Arc<dyn ExecutionPlan> {
    mem_table(("a1", &[5, 9, 11]), ("b1", &[5, 8, 8]), ("c1", &[50, 90, 110]))
}

fn build_right() -> Arc<dyn ExecutionPlan> {
    mem_table(("a2", &[12, 2, 10]), ("b2", &[10, 2, 10]), ("c2", &[40, 80, 100]))
}

/// Non-equi filter `left.b1 != 8 AND right.b2 != 10` over the intermediate
/// columns, producing both matching and non-matching combinations.
fn prepare_filter() -> JoinFilter {
    let column_indices = vec![
        ColumnIndex { index: 1, side: JoinSide::Left },
        ColumnIndex { index: 1, side: JoinSide::Right },
    ];
    let intermediate_schema = Schema::new(vec![
        Field::new("x", DataType::Int32, true),
        Field::new("x", DataType::Int32, true),
    ]);
    let left_filter = Arc::new(BinaryExpr::new(
        Arc::new(Column::new("x", 0)),
        Operator::NotEq,
        Arc::new(Literal::new(ScalarValue::Int32(Some(8)))),
    )) as Arc<dyn PhysicalExpr>;
    let right_filter = Arc::new(BinaryExpr::new(
        Arc::new(Column::new("x", 1)),
        Operator::NotEq,
        Arc::new(Literal::new(ScalarValue::Int32(Some(10)))),
    )) as Arc<dyn PhysicalExpr>;
    let expr = Arc::new(BinaryExpr::new(left_filter, Operator::And, right_filter))
        as Arc<dyn PhysicalExpr>;
    JoinFilter::new(expr, column_indices, Arc::new(intermediate_schema))
}

/// Build an NLJ whose right input has `partition_count` partitions and
/// collect every output partition. Returns the join's result, or the error if
/// execution fails (e.g. a clean `ResourcesExhausted`).
async fn multi_partition_collect(
    join_type: JoinType,
    context: Arc<TaskContext>,
    partition_count: usize,
) -> datafusion::error::Result<Vec<RecordBatch>> {
    let left = build_left();
    let right = Arc::new(RepartitionExec::try_new(
        build_right(),
        Partitioning::RoundRobinBatch(partition_count),
    )?) as Arc<dyn ExecutionPlan>;

    let join =
        NestedLoopJoinExec::try_new(left, right, Some(prepare_filter()), &join_type, None)?;

    let mut batches = vec![];
    for i in 0..partition_count {
        let stream = join.execute(i, Arc::clone(&context))?;
        batches.extend(collect(stream).await?);
    }
    Ok(batches)
}

fn task_ctx_with_limit(bytes: usize) -> Arc<TaskContext> {
    let runtime = RuntimeEnvBuilder::new()
        .with_memory_limit(bytes, 1.0)
        .build_arc()
        .unwrap();
    Arc::new(TaskContext::default().with_runtime(runtime))
}

fn ample_task_ctx() -> Arc<TaskContext> {
    let runtime = RuntimeEnvBuilder::new().build_arc().unwrap();
    Arc::new(TaskContext::default().with_runtime(runtime))
}

fn sorted_rows(batches: &[RecordBatch]) -> Vec<String> {
    let mut rows = vec![];
    for batch in batches {
        for row in 0..batch.num_rows() {
            let cells = (0..batch.num_columns())
                .map(|column| {
                    ScalarValue::try_from_array(batch.column(column), row)
                        .unwrap()
                        .to_string()
                })
                .collect::<Vec<_>>();
            rows.push(cells.join("|"));
        }
    }
    rows.sort();
    rows
}

const LEFT_EMISSION_JOIN_TYPES: [JoinType; 5] = [
    JoinType::Left,
    JoinType::LeftSemi,
    JoinType::LeftAnti,
    JoinType::LeftMark,
    JoinType::Full,
];

/// Ample-memory execution must produce the same rows whether the right input
/// has one partition or several.
#[tokio::test(flavor = "multi_thread")]
async fn left_emission_multi_partition_ample_matches_single_partition() {
    for join_type in LEFT_EMISSION_JOIN_TYPES {
        let single = multi_partition_collect(join_type, ample_task_ctx(), 1)
            .await
            .unwrap();
        let multi = multi_partition_collect(join_type, ample_task_ctx(), 4)
            .await
            .unwrap();
        assert_eq!(
            sorted_rows(&multi),
            sorted_rows(&single),
            "ample-memory {join_type:?} returned different rows with four probe partitions"
        );
    }
}

/// With a single right-input partition and multiple input batches, a 64-byte pool
/// must still produce exactly the ample-memory row set.
#[tokio::test(flavor = "multi_thread")]
async fn left_emission_single_partition_tight_pool_matches_ample() {
    for join_type in LEFT_EMISSION_JOIN_TYPES {
        let ample = multi_partition_collect(join_type, ample_task_ctx(), 1)
            .await
            .unwrap();
        let limited = multi_partition_collect(join_type, task_ctx_with_limit(64), 1)
            .await
            .unwrap_or_else(|error| {
                panic!(
                    "single-partition {join_type:?} must succeed under the 64-byte pool: {error}"
                )
            });
        assert_eq!(
            sorted_rows(&limited),
            sorted_rows(&ample),
            "memory-limited single-partition {join_type:?} returned the wrong rows"
        );
    }
}

/// Under a tight pool, a multi-partition left-emission join may either return
/// the exact ample-memory rows or reject execution with resource exhaustion.
#[tokio::test(flavor = "multi_thread")]
async fn left_emission_multi_partition_is_correct_or_rejected_cleanly() {
    for join_type in LEFT_EMISSION_JOIN_TYPES {
        let expected = multi_partition_collect(join_type, ample_task_ctx(), 4)
            .await
            .unwrap();
        match multi_partition_collect(join_type, task_ctx_with_limit(100), 4).await {
            Ok(actual) => assert_eq!(
                sorted_rows(&actual),
                sorted_rows(&expected),
                "memory-limited multi-partition {join_type:?} returned the wrong rows"
            ),
            Err(error)
                if matches!(
                    error.find_root(),
                    DataFusionError::ResourcesExhausted(_)
                ) => {}
            Err(error) => panic!(
                "memory-limited multi-partition {join_type:?} failed with an unexpected error: {error}"
            ),
        }
    }
}

/// Regression guard: `Inner` and right-oriented join types must still complete
/// under the tight pool with multiple right-input partitions and match ample results.
#[tokio::test(flavor = "multi_thread")]
async fn right_emission_multi_partition_still_spills() {
    let fallback = [
        JoinType::Inner,
        JoinType::Right,
        JoinType::RightSemi,
        JoinType::RightAnti,
        JoinType::RightMark,
    ];
    for join_type in fallback {
        let expected = multi_partition_collect(join_type, ample_task_ctx(), 4)
            .await
            .unwrap();
        let result = multi_partition_collect(join_type, task_ctx_with_limit(100), 4).await;
        assert!(
            result.is_ok(),
            "{join_type:?} with a multi-partition probe under a 100-byte pool must \
             still succeed via the spill path, but it failed: {:?}",
            result.as_ref().err()
        );
        assert_eq!(
            sorted_rows(&result.unwrap()),
            sorted_rows(&expected),
            "memory-limited multi-partition {join_type:?} returned the wrong rows"
        );
    }
}
