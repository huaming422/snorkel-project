//! Integration coverage for Dalfox's HTTP and MCP interfaces.
//!
//! The tests exercise the compiled binary through public protocols and local
//! mock targets. Assertions focus on response status, job state, request
//! traffic, and progress values rather than internal helper structure.

use std::net::{Ipv4Addr, SocketAddr};
use std::process::Stdio;
use std::time::Duration;

use axum::{Router, response::Html, routing::get};
use serde_json::{Value, json};
use tokio::io::{AsyncBufReadExt, AsyncWriteExt, BufReader};
use tokio::time::{sleep, timeout};

// ---------------------------------------------------------------------------
// Shared helpers
// ---------------------------------------------------------------------------

/// Absolute path to the compiled `dalfox` binary under test.
fn dalfox_bin() -> &'static str {
    env!("CARGO_BIN_EXE_dalfox")
}

/// Build a percent-encoded query string `?k=v&...`. reqwest is built without
/// the `serde_urlencoded` feature (the crate pins `default-features = false`),
/// so `RequestBuilder::query` is unavailable; `urlencoding` is a normal crate
/// dependency, so we assemble the query ourselves and append it to the path.
fn qs(pairs: &[(&str, &str)]) -> String {
    let mut s = String::from("?");
    for (i, (k, v)) in pairs.iter().enumerate() {
        if i > 0 {
            s.push('&');
        }
        s.push_str(&urlencoding::encode(k));
        s.push('=');
        s.push_str(&urlencoding::encode(v));
    }
    s
}

/// Grab a currently-free TCP port by binding to :0 and dropping the listener.
/// Used to pick a server port and to synthesize a definitely-closed port for
/// the unreachable test.
fn free_port() -> u16 {
    let l = std::net::TcpListener::bind((Ipv4Addr::LOCALHOST, 0)).expect("bind :0 for free port");
    let p = l.local_addr().expect("local_addr").port();
    drop(l);
    p
}

/// A reqwest client. `ensure_crypto_provider` installs ring as the rustls
/// default provider (the crate pins `rustls-no-provider`), which the client
/// builder requires even for plain-http requests.
fn http_client() -> reqwest::Client {
    dalfox::ensure_crypto_provider();
    reqwest::Client::builder()
        .timeout(Duration::from_secs(15))
        .build()
        .expect("build reqwest client")
}

/// Spawn a local axum mock target. `path_router` lets each test shape the
/// routes (reflecting handler, 404, slow handler, ...). Returns the bound
/// address and the serve task's JoinHandle (kept alive by the caller).
async fn spawn_mock(router: Router) -> (SocketAddr, tokio::task::JoinHandle<()>) {
    let listener = tokio::net::TcpListener::bind((Ipv4Addr::LOCALHOST, 0))
        .await
        .expect("bind mock target");
    let addr = listener.local_addr().expect("mock local_addr");
    let handle = tokio::spawn(async move {
        let _ = axum::serve(listener, router).await;
    });
    (addr, handle)
}

/// A running `dalfox server`, bound to `127.0.0.1:port`, with no api-key
/// (auth disabled). Killed on drop.
struct ServerProc {
    child: tokio::process::Child,
    port: u16,
}

impl ServerProc {
    async fn start() -> ServerProc {
        let port = free_port();
        let child = tokio::process::Command::new(dalfox_bin())
            .arg("server")
            .arg("-H")
            .arg("127.0.0.1")
            .arg("-p")
            .arg(port.to_string())
            .stdin(Stdio::null())
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .kill_on_drop(true)
            .spawn()
            .expect("spawn dalfox server");
        let sp = ServerProc { child, port };
        sp.wait_until_up().await;
        sp
    }

    fn base(&self) -> String {
        format!("http://127.0.0.1:{}", self.port)
    }

    /// Poll GET /health until the server answers (or time out loudly).
    async fn wait_until_up(&self) {
        let client = http_client();
        let url = format!("http://127.0.0.1:{}/health", self.port);
        let deadline = std::time::Instant::now() + Duration::from_secs(30);
        loop {
            if let Ok(resp) = client.get(&url).send().await
                && resp.status().is_success()
            {
                return;
            }
            if std::time::Instant::now() > deadline {
                panic!("dalfox server did not become healthy on port {}", self.port);
            }
            sleep(Duration::from_millis(100)).await;
        }
    }
}

impl Drop for ServerProc {
    fn drop(&mut self) {
        let _ = self.child.start_kill();
    }
}

/// Reflecting handler: echoes every query param value into the HTML body so
/// dalfox's discovery classifies each as a reflecting parameter (giving a
/// non-trivial params_total).
async fn reflect_handler(
    axum::extract::RawQuery(q): axum::extract::RawQuery,
) -> Html<String> {
    let raw = q.unwrap_or_default();
    // Reflect the raw query string AND each decoded value, unencoded, so the
    // marker-based reflection probe sees its marker echoed back.
    let mut body = String::from("<!DOCTYPE html><html><body>");
    body.push_str("<div>");
    body.push_str(&raw);
    body.push_str("</div>");
    for pair in raw.split('&') {
        if let Some((_k, v)) = pair.split_once('=') {
            let decoded = v.replace('+', " ");
            let decoded = percent_decode(&decoded);
            body.push_str("<p>");
            body.push_str(&decoded);
            body.push_str("</p>");
        }
    }
    body.push_str("</body></html>");
    Html(body)
}

/// Minimal percent-decode good enough to echo scanner markers back verbatim.
fn percent_decode(s: &str) -> String {
    let bytes = s.as_bytes();
    let mut out = Vec::with_capacity(bytes.len());
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'%' && i + 2 < bytes.len() {
            if let (Some(h), Some(l)) =
                (hex_val(bytes[i + 1]), hex_val(bytes[i + 2]))
            {
                out.push(h * 16 + l);
                i += 3;
                continue;
            }
        }
        out.push(bytes[i]);
        i += 1;
    }
    String::from_utf8_lossy(&out).into_owned()
}

fn hex_val(b: u8) -> Option<u8> {
    match b {
        b'0'..=b'9' => Some(b - b'0'),
        b'a'..=b'f' => Some(b - b'a' + 10),
        b'A'..=b'F' => Some(b - b'A' + 10),
        _ => None,
    }
}

/// Parse the `data` object out of the server's `{code,msg,data}` envelope.
fn envelope_data(v: &Value) -> Option<&Value> {
    v.get("data")
}

// ---------------------------------------------------------------------------
// HTTP scan endpoints reject unsupported target forms.
// ---------------------------------------------------------------------------
#[tokio::test]
async fn scheme_reject_400_on_server_scan_endpoints() {
    let server = ServerProc::start().await;
    let client = http_client();
    let bad_targets = ["notaurl", "file:///etc/passwd", "ftp://example.com/x"];

    for bad in bad_targets {
        // POST /scan with a JSON body.
        let resp = client
            .post(format!("{}/scan", server.base()))
            .json(&json!({ "url": bad }))
            .send()
            .await
            .expect("POST /scan");
        assert_eq!(
            resp.status().as_u16(),
            400,
            "POST /scan with non-http url {:?} must be 400, got {}",
            bad,
            resp.status()
        );
        let body: Value = resp.json().await.expect("POST /scan json");
        assert!(
            envelope_data(&body).and_then(|d| d.get("scan_id")).is_none(),
            "POST /scan {:?} must not mint a scan_id, body={}",
            bad,
            body
        );

        // GET /scan?url=<bad>.
        let resp = client
            .get(format!("{}/scan{}", server.base(), qs(&[("url", bad)])))
            .send()
            .await
            .expect("GET /scan");
        assert_eq!(
            resp.status().as_u16(),
            400,
            "GET /scan with non-http url {:?} must be 400, got {}",
            bad,
            resp.status()
        );
        let body: Value = resp.json().await.expect("GET /scan json");
        assert!(
            envelope_data(&body).and_then(|d| d.get("scan_id")).is_none(),
            "GET /scan {:?} must not mint a scan_id, body={}",
            bad,
            body
        );
    }

    // Valid HTTP schemes remain accepted regardless of letter case.
    let good_targets = [
        format!("http://127.0.0.1:{}/?q=1", free_port()),
        format!("HTTP://127.0.0.1:{}/?q=1", free_port()),
    ];
    for good in good_targets {
        let resp = client
            .post(format!("{}/scan", server.base()))
            .json(&json!({ "url": good }))
            .send()
            .await
            .expect("POST /scan good");
        assert_ne!(
            resp.status().as_u16(),
            400,
            "POST /scan with a valid HTTP URL must not be 400"
        );
        let body: Value = resp.json().await.expect("good json");
        assert!(
            envelope_data(&body)
                .and_then(|d| d.get("scan_id"))
                .and_then(|s| s.as_str())
                .is_some(),
            "POST /scan with a valid HTTP URL must mint a scan_id, body={}",
            body
        );
    }

    // Rejected requests must not create jobs.
    let list = client
        .get(format!("{}/scans", server.base()))
        .send()
        .await
        .expect("GET /scans")
        .json::<Value>()
        .await
        .expect("scans json");
    let scans = find_scan_array(&list);
    assert_eq!(
        scans.len(),
        2,
        "exactly two valid jobs should exist; rejected submissions must create none. list={}",
        list
    );
}

/// The /scans payload nests the job array somewhere under `data`; find the
/// first array of objects that look like scan entries.
fn find_scan_array(v: &Value) -> Vec<Value> {
    fn walk(v: &Value, out: &mut Vec<Value>) {
        match v {
            Value::Array(a) => {
                if a.iter().all(|e| e.is_object())
                    && a.iter().any(|e| {
                        e.get("scan_id").is_some()
                            || e.get("id").is_some()
                            || e.get("status").is_some()
                    })
                {
                    out.extend(a.iter().cloned());
                } else {
                    for e in a {
                        walk(e, out);
                    }
                }
            }
            Value::Object(m) => {
                for (_k, val) in m {
                    walk(val, out);
                }
            }
            _ => {}
        }
    }
    let mut out = Vec::new();
    walk(v, &mut out);
    out
}

// ---------------------------------------------------------------------------
// Numeric query options reject malformed values.
// ---------------------------------------------------------------------------
#[tokio::test]
async fn numeric_query_400_on_get_scan() {
    let server = ServerProc::start().await;
    let client = http_client();
    let good_url = format!("http://127.0.0.1:{}/?q=1", free_port());

    // Unparseable numeric -> 400, no job.
    let resp = client
        .get(format!(
            "{}/scan{}",
            server.base(),
            qs(&[("url", good_url.as_str()), ("worker", "abc")])
        ))
        .send()
        .await
        .expect("GET /scan worker=abc");
    assert_eq!(
        resp.status().as_u16(),
        400,
        "GET /scan with worker=abc must be 400, got {}",
        resp.status()
    );
    let body: Value = resp.json().await.expect("json");
    assert!(
        envelope_data(&body).and_then(|d| d.get("scan_id")).is_none(),
        "worker=abc must not mint a scan_id, body={}",
        body
    );

    // Control A: valid numeric -> not 400 (starts a scan).
    let resp = client
        .get(format!(
            "{}/scan{}",
            server.base(),
            qs(&[("url", good_url.as_str()), ("worker", "5")])
        ))
        .send()
        .await
        .expect("GET /scan worker=5");
    assert_ne!(
        resp.status().as_u16(),
        400,
        "GET /scan with worker=5 must not be 400, got {}",
        resp.status()
    );

    // Control B: absent numeric -> not 400.
    let resp = client
        .get(format!(
            "{}/scan{}",
            server.base(),
            qs(&[("url", good_url.as_str())])
        ))
        .send()
        .await
        .expect("GET /scan no worker");
    assert_ne!(
        resp.status().as_u16(),
        400,
        "GET /scan with no worker must not be 400, got {}",
        resp.status()
    );
}

// ---------------------------------------------------------------------------
// Server jobs distinguish connection failure from an HTTP response.
// ---------------------------------------------------------------------------
#[tokio::test]
async fn unreachable_errors_on_server_with_4xx_reachable_control() {
    let server = ServerProc::start().await;
    let client = http_client();

    // --- Unreachable: a closed local port. ---
    let closed = free_port();
    let unreachable_url = format!("http://127.0.0.1:{}/?q=1", closed);
    let scan_id = post_scan_get_id(&client, &server, &unreachable_url).await;
    let status = poll_terminal_status(&client, &server, &scan_id, Duration::from_secs(45)).await;
    // A connection failure is an error and includes a useful message; exact
    // wording is intentionally not prescribed.
    assert_eq!(
        status.0, "error",
        "unreachable target must end in `error`, not `{}` (scan_id={})",
        status.0, scan_id
    );
    assert!(
        status.1.as_deref().map(|m| !m.trim().is_empty()).unwrap_or(false),
        "an errored unreachable job must carry a non-empty error_message, got {:?}",
        status.1
    );

    // --- Positive control: a 404 mock is reachable. ---
    let router = Router::new().fallback(|| async {
        (axum::http::StatusCode::NOT_FOUND, Html("<html>not found</html>"))
    });
    let (addr, _mock) = spawn_mock(router).await;
    let reachable_url = format!("http://{}/?q=1", addr);
    let scan_id = post_scan_get_id(&client, &server, &reachable_url).await;
    let status = poll_terminal_status(&client, &server, &scan_id, Duration::from_secs(45)).await;
    assert_ne!(
        status.0, "error",
        "a 404-returning target is reachable and must NOT error on reachability; \
         got status={} msg={:?} (scan_id={})",
        status.0, status.1, scan_id
    );
}

/// POST /scan and return the minted scan_id (fails loudly otherwise).
async fn post_scan_get_id(client: &reqwest::Client, server: &ServerProc, url: &str) -> String {
    let body: Value = client
        .post(format!("{}/scan", server.base()))
        .json(&json!({
            "url": url,
            "options": { "skip_mining": true, "skip_ast_analysis": true }
        }))
        .send()
        .await
        .expect("POST /scan")
        .json()
        .await
        .expect("POST /scan json");
    envelope_data(&body)
        .and_then(|d| d.get("scan_id"))
        .and_then(|s| s.as_str())
        .unwrap_or_else(|| panic!("no scan_id in POST /scan response: {}", body))
        .to_string()
}

/// Poll GET /scan/{id} until the job reaches a terminal state
/// (done | error | cancelled) or the deadline fires. Returns
/// (status_string, error_message).
async fn poll_terminal_status(
    client: &reqwest::Client,
    server: &ServerProc,
    scan_id: &str,
    budget: Duration,
) -> (String, Option<String>) {
    let deadline = std::time::Instant::now() + budget;
    let url = format!("{}/scan/{}", server.base(), scan_id);
    loop {
        if let Ok(resp) = client.get(&url).send().await
            && let Ok(body) = resp.json::<Value>().await
        {
            let data = envelope_data(&body).cloned().unwrap_or(Value::Null);
            if let Some(status) = data.get("status").and_then(|s| s.as_str()) {
                if matches!(status, "done" | "error" | "cancelled") {
                    let msg = data
                        .get("error_message")
                        .and_then(|m| m.as_str())
                        .map(|s| s.to_string());
                    return (status.to_string(), msg);
                }
            }
        }
        if std::time::Instant::now() > deadline {
            panic!("scan {} did not reach a terminal state within budget", scan_id);
        }
        sleep(Duration::from_millis(150)).await;
    }
}

// ---------------------------------------------------------------------------
// Server progress changes while a scan is still running.
// ---------------------------------------------------------------------------
#[tokio::test]
async fn live_progress_params_tested_climbs_midscan() {
    let server = ServerProc::start().await;
    let client = http_client();

    // Slow reflecting target: every param reflects (so discovery yields a
    // non-trivial params_total) and each response is delayed so the scan
    // takes long enough to observe intermediate progress.
    async fn slow_reflect(
        axum::extract::RawQuery(q): axum::extract::RawQuery,
    ) -> Html<String> {
        sleep(Duration::from_millis(120)).await;
        reflect_handler(axum::extract::RawQuery(q)).await
    }
    let router = Router::new()
        .route("/", get(slow_reflect))
        .route("/{*rest}", get(slow_reflect));
    let (addr, _mock) = spawn_mock(router).await;

    // Many query params -> many reflecting params -> many worker completions.
    // A small worker count makes intermediate progress reliably observable.
    let n_params = 9u64;
    let params: Vec<String> = (0..n_params).map(|i| format!("p{}=v{}", i, i)).collect();
    let target = format!("http://{}/?{}", addr, params.join("&"));

    // Submit with worker=3 and parameter discovery ON (so each query param is
    // probed and counted toward params_total), mining OFF (so params_total is
    // the deterministic 9 reflected query params, not an expanded mined set).
    let body: Value = client
        .post(format!("{}/scan", server.base()))
        .json(&json!({
            "url": target,
            "options": {
                "worker": 3,
                "skip_mining": true,
                "skip_discovery": false,
                "skip_ast_analysis": true,
                "encoders": ["none"]
            }
        }))
        .send()
        .await
        .expect("POST /scan live-progress")
        .json()
        .await
        .expect("POST /scan json");
    let scan_id = envelope_data(&body)
        .and_then(|d| d.get("scan_id"))
        .and_then(|s| s.as_str())
        .unwrap_or_else(|| panic!("no scan_id in live-progress POST: {}", body))
        .to_string();

    // Poll quickly; record the max intermediate (0 < tested < total) sighting.
    let mut saw_intermediate = false;
    let mut last_seen = (0u64, 0u64); // (tested, total)
    let deadline = std::time::Instant::now() + Duration::from_secs(45);
    loop {
        let body: Value = match client
            .get(format!("{}/scan/{}", server.base(), scan_id))
            .send()
            .await
        {
            Ok(r) => r.json().await.unwrap_or(Value::Null),
            Err(_) => Value::Null,
        };
        let data = envelope_data(&body).cloned().unwrap_or(Value::Null);
        let status = data
            .get("status")
            .and_then(|s| s.as_str())
            .unwrap_or("")
            .to_string();
        if let Some(progress) = data.get("progress") {
            let tested = progress
                .get("params_tested")
                .and_then(|x| x.as_u64())
                .unwrap_or(0);
            let total = progress
                .get("params_total")
                .and_then(|x| x.as_u64())
                .unwrap_or(0);
            last_seen = (tested, total);
            if total > 0 && tested > 0 && tested < total && status == "running" {
                saw_intermediate = true;
                break;
            }
        }
        if matches!(status.as_str(), "done" | "error" | "cancelled") {
            break;
        }
        if std::time::Instant::now() > deadline {
            break;
        }
        sleep(Duration::from_millis(25)).await;
    }

    assert!(
        saw_intermediate,
        "expected a mid-scan poll with 0 < params_tested < params_total; \
         last observed (tested,total)={:?}",
        last_seen
    );
}

// ---------------------------------------------------------------------------
// MCP blind-XSS configuration produces callback-bearing scan traffic.
// ---------------------------------------------------------------------------
#[tokio::test]
async fn mcp_blind_dispatch_increases_target_requests() {
    use std::sync::Arc;
    use std::sync::atomic::{AtomicU64, Ordering};

    // Reflecting target that counts every inbound request.
    let counter = Arc::new(AtomicU64::new(0));
    let c2 = counter.clone();
    async fn counting_reflect(
        axum::extract::State(cnt): axum::extract::State<Arc<AtomicU64>>,
        axum::extract::RawQuery(q): axum::extract::RawQuery,
    ) -> Html<String> {
        cnt.fetch_add(1, Ordering::Relaxed);
        reflect_handler(axum::extract::RawQuery(q)).await
    }
    let router = Router::new()
        .route("/", get(counting_reflect))
        .route("/{*rest}", get(counting_reflect))
        .with_state(c2);
    let (addr, _mock) = spawn_mock(router).await;
    let target = format!("http://{}/?a=1&b=2&c=3", addr);

    // Run a scan WITHOUT a callback, record the target hit count.
    let before_no = counter.load(Ordering::Relaxed);
    run_mcp_scan_to_completion(&target, None).await;
    let without = counter.load(Ordering::Relaxed) - before_no;

    // Run an identical scan WITH a blind callback URL.
    let before_yes = counter.load(Ordering::Relaxed);
    run_mcp_scan_to_completion(&target, Some("http://callback.invalid/hook")).await;
    let with = counter.load(Ordering::Relaxed) - before_yes;

    assert!(
        with > without,
        "MCP scan with blind_callback_url must issue more target requests than without; \
         with={} without={}",
        with,
        without
    );
}

/// Drive one `dalfox mcp` scan over stdio JSON-RPC to completion, against the
/// given target, optionally with a blind callback URL. Returns when the job
/// reaches a terminal state (or a generous timeout fires).
async fn run_mcp_scan_to_completion(target: &str, blind: Option<&str>) {
    let mut mcp = McpProc::start().await;
    mcp.initialize().await;

    let mut scan_params = json!({
        "target": target,
        // Keep the scan small & fast but still exercise the blind path:
        "skip_mining": true,
        "skip_discovery": false,
        "skip_ast_analysis": true,
        "encoders": ["none"],
        "timeout": 10
    });
    if let Some(cb) = blind {
        scan_params["blind_callback_url"] = json!(cb);
    }

    let res = mcp.call_tool("scan_with_dalfox", scan_params).await;
    let scan_id = extract_tool_json(&res)
        .and_then(|v| v.get("scan_id").and_then(|s| s.as_str()).map(String::from))
        .unwrap_or_else(|| panic!("scan_with_dalfox returned no scan_id: {:?}", res));

    // Poll get_results_dalfox until terminal.
    let deadline = std::time::Instant::now() + Duration::from_secs(45);
    loop {
        let res = mcp
            .call_tool("get_results_dalfox", json!({ "scan_id": scan_id }))
            .await;
        if let Some(v) = extract_tool_json(&res)
            && let Some(status) = v.get("status").and_then(|s| s.as_str())
            && matches!(status, "done" | "error" | "cancelled")
        {
            break;
        }
        if std::time::Instant::now() > deadline {
            break;
        }
        sleep(Duration::from_millis(150)).await;
    }
    mcp.shutdown().await;
}

// ---------------------------------------------------------------------------
// Minimal hand-rolled MCP (rmcp) stdio JSON-RPC client.
// ---------------------------------------------------------------------------
// rmcp's stdio transport is newline-delimited JSON (one object per line), and
// its server does not gate tool calls on the `initialized` notification. We
// send an `initialize` request, read its response, then issue `tools/call`
// requests and read responses by matching the JSON-RPC `id`.
struct McpProc {
    child: tokio::process::Child,
    stdin: tokio::process::ChildStdin,
    stdout: BufReader<tokio::process::ChildStdout>,
    next_id: i64,
}

impl McpProc {
    async fn start() -> McpProc {
        let mut child = tokio::process::Command::new(dalfox_bin())
            .arg("mcp")
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .kill_on_drop(true)
            .spawn()
            .expect("spawn dalfox mcp");
        let stdin = child.stdin.take().expect("mcp stdin");
        let stdout = BufReader::new(child.stdout.take().expect("mcp stdout"));
        McpProc {
            child,
            stdin,
            stdout,
            next_id: 1,
        }
    }

    async fn send(&mut self, msg: &Value) {
        let mut line = serde_json::to_string(msg).expect("serialize jsonrpc");
        line.push('\n');
        self.stdin
            .write_all(line.as_bytes())
            .await
            .expect("write mcp frame");
        self.stdin.flush().await.expect("flush mcp frame");
    }

    /// Read newline-delimited JSON frames until one with the given id arrives.
    /// Notifications and mismatched-id frames are skipped.
    async fn recv_response(&mut self, want_id: i64) -> Value {
        let budget = Duration::from_secs(30);
        let read = async {
            loop {
                let mut line = String::new();
                let n = self
                    .stdout
                    .read_line(&mut line)
                    .await
                    .expect("read mcp line");
                if n == 0 {
                    panic!("mcp stdout closed before response id={}", want_id);
                }
                let trimmed = line.trim();
                if trimmed.is_empty() {
                    continue;
                }
                let v: Value = match serde_json::from_str(trimmed) {
                    Ok(v) => v,
                    Err(_) => continue, // non-JSON log line; ignore
                };
                if v.get("id").and_then(|x| x.as_i64()) == Some(want_id) {
                    return v;
                }
            }
        };
        timeout(budget, read)
            .await
            .unwrap_or_else(|_| panic!("timed out waiting for mcp response id={}", want_id))
    }

    async fn initialize(&mut self) {
        let id = self.next_id;
        self.next_id += 1;
        self.send(&json!({
            "jsonrpc": "2.0",
            "id": id,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": { "name": "verify-harness", "version": "0.0.0" }
            }
        }))
        .await;
        let _ = self.recv_response(id).await;
        // Best-effort: send the initialized notification (server does not gate
        // on it, but a well-behaved client sends it).
        self.send(&json!({
            "jsonrpc": "2.0",
            "method": "notifications/initialized"
        }))
        .await;
    }

    async fn call_tool(&mut self, name: &str, arguments: Value) -> Value {
        let id = self.next_id;
        self.next_id += 1;
        self.send(&json!({
            "jsonrpc": "2.0",
            "id": id,
            "method": "tools/call",
            "params": { "name": name, "arguments": arguments }
        }))
        .await;
        self.recv_response(id).await
    }

    async fn shutdown(&mut self) {
        let _ = self.child.start_kill();
    }
}

impl Drop for McpProc {
    fn drop(&mut self) {
        let _ = self.child.start_kill();
    }
}

/// A tools/call response wraps the tool's JSON output as text in
/// `result.content[0].text`. Parse and return it as a Value.
fn extract_tool_json(resp: &Value) -> Option<Value> {
    let text = resp
        .get("result")?
        .get("content")?
        .as_array()?
        .iter()
        .find_map(|c| c.get("text").and_then(|t| t.as_str()))?;
    serde_json::from_str::<Value>(text).ok()
}

// ---------------------------------------------------------------------------
// MCP jobs distinguish connection failure from a clean scan.
// ---------------------------------------------------------------------------
#[tokio::test]
async fn unreachable_errors_on_mcp() {
    let closed = free_port();
    let unreachable = format!("http://127.0.0.1:{}/?q=1", closed);

    let mut mcp = McpProc::start().await;
    mcp.initialize().await;

    let res = mcp
        .call_tool(
            "scan_with_dalfox",
            json!({
                "target": unreachable,
                "skip_mining": true,
                "skip_ast_analysis": true,
                "encoders": ["none"],
                "timeout": 5
            }),
        )
        .await;
    let scan_id = extract_tool_json(&res)
        .and_then(|v| v.get("scan_id").and_then(|s| s.as_str()).map(String::from))
        .unwrap_or_else(|| panic!("scan_with_dalfox returned no scan_id: {:?}", res));

    let deadline = std::time::Instant::now() + Duration::from_secs(45);
    let mut terminal: Option<(String, Option<String>)> = None;
    loop {
        let res = mcp
            .call_tool("get_results_dalfox", json!({ "scan_id": scan_id }))
            .await;
        if let Some(v) = extract_tool_json(&res)
            && let Some(status) = v.get("status").and_then(|s| s.as_str())
            && matches!(status, "done" | "error" | "cancelled")
        {
            let msg = v
                .get("error_message")
                .and_then(|m| m.as_str())
                .map(String::from);
            terminal = Some((status.to_string(), msg));
            break;
        }
        if std::time::Instant::now() > deadline {
            break;
        }
        sleep(Duration::from_millis(150)).await;
    }
    mcp.shutdown().await;

    let (status, msg) = terminal.expect("MCP scan did not reach a terminal state");
    // Exact error wording is intentionally not prescribed.
    assert_eq!(
        status, "error",
        "unreachable target over MCP must end in `error`, not `{}`",
        status
    );
    assert!(
        msg.as_deref().map(|m| !m.trim().is_empty()).unwrap_or(false),
        "an errored unreachable MCP job must carry a non-empty error_message, got {:?}",
        msg
    );
}

// ---------------------------------------------------------------------------
// MCP progress changes while a scan is still running.
// ---------------------------------------------------------------------------
// A slow local target and small worker count make intermediate values
// observable through the public results call.
#[tokio::test]
async fn mcp_live_progress_climbs_midscan() {
    // Slow reflecting target: every param reflects (non-trivial params_total)
    // and each response is delayed so the scan lasts long enough to observe
    // intermediate progress.
    async fn slow_reflect(
        axum::extract::RawQuery(q): axum::extract::RawQuery,
    ) -> Html<String> {
        sleep(Duration::from_millis(120)).await;
        reflect_handler(axum::extract::RawQuery(q)).await
    }
    let router = Router::new()
        .route("/", get(slow_reflect))
        .route("/{*rest}", get(slow_reflect));
    let (addr, _mock) = spawn_mock(router).await;

    let n_params = 9u64;
    let params: Vec<String> = (0..n_params).map(|i| format!("p{}=v{}", i, i)).collect();
    let target = format!("http://{}/?{}", addr, params.join("&"));

    let mut mcp = McpProc::start().await;
    mcp.initialize().await;

    // Submit with a small worker count and parameter discovery ON (so each
    // query param is probed and counted toward params_total), mining OFF (so
    // params_total is the deterministic 9 reflected query params). The MCP
    // scan schema spells the worker-count field `workers`.
    let res = mcp
        .call_tool(
            "scan_with_dalfox",
            json!({
                "target": target,
                "workers": 3,
                "skip_mining": true,
                "skip_discovery": false,
                "skip_ast_analysis": true,
                "encoders": ["none"]
            }),
        )
        .await;
    let scan_id = extract_tool_json(&res)
        .and_then(|v| v.get("scan_id").and_then(|s| s.as_str()).map(String::from))
        .unwrap_or_else(|| panic!("scan_with_dalfox returned no scan_id: {:?}", res));

    // Poll get_results_dalfox quickly; record the first intermediate
    // (0 < tested < total, status "running") sighting.
    let mut saw_intermediate = false;
    let mut last_seen = (0u64, 0u64); // (tested, total)
    let deadline = std::time::Instant::now() + Duration::from_secs(45);
    loop {
        let res = mcp
            .call_tool("get_results_dalfox", json!({ "scan_id": scan_id }))
            .await;
        let v = extract_tool_json(&res).unwrap_or(Value::Null);
        let status = v
            .get("status")
            .and_then(|s| s.as_str())
            .unwrap_or("")
            .to_string();
        if let Some(progress) = v.get("progress") {
            let tested = progress
                .get("params_tested")
                .and_then(|x| x.as_u64())
                .unwrap_or(0);
            let total = progress
                .get("params_total")
                .and_then(|x| x.as_u64())
                .unwrap_or(0);
            last_seen = (tested, total);
            if total > 0 && tested > 0 && tested < total && status == "running" {
                saw_intermediate = true;
                break;
            }
        }
        if matches!(status.as_str(), "done" | "error" | "cancelled") {
            break;
        }
        if std::time::Instant::now() > deadline {
            break;
        }
        sleep(Duration::from_millis(25)).await;
    }
    mcp.shutdown().await;

    assert!(
        saw_intermediate,
        "expected a mid-scan get_results_dalfox poll with 0 < params_tested < params_total; \
         last observed (tested,total)={:?}",
        last_seen
    );
}
