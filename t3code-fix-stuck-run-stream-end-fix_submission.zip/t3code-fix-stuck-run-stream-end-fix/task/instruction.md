## Task

we've had a delegated provider run get permanently stuck in `running`. the provider's session had effectively ended and its event activity went quiet, but the run never settled to a finished or failed state. it just sat there in `running` for hours, and the provider thread that had been driving it never went back to idle.

when a provider's event stream ends without the run ever reaching a real terminal, that run should be failed and finalized so it can't linger in `running`, and the thread driving it should return to idle.

a couple of things have to keep holding. a graceful shutdown must stay safe: if a run's session is torn down as part of a normal server shutdown, it must not be force-failed. leave it so that restart recovery takes ownership. and runs that end legitimately, reaching a real terminal on their own, must still settle the way they do today.

the problem is somewhere in how the server's run orchestration consumes a provider's event stream and decides when a run is finished. dig in and fix it.
