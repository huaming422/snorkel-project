## Task

attribute access and method calls are slower than they should be on hot code: tight loops that read the same attributes and call the same methods across lots of instances of the same class. once the interpreter has warmed up and those access sites have settled, each access still redoes work it no longer needs once an instance's layout has stopped changing, and that shows up as steady-state slowness.

can you dig into the hot attribute- and method-access path and get it back to what a warmed-up access should cost?

behavior has to stay exactly the same. attribute and method lookup, an instance attribute shadowing a class one, deleting attributes, reassigning `__dict__`, and dict-subclass instances all have to resolve identically to the way they do now. this is purely a speed fix; nothing about the observable results should change.

## General instructions

- The code repo is at /repo/RustPython.
- You are inside of a Docker container with no network access. You may not be able to perform all operations you would normally be able to do on a local machine. The project's dependencies and toolchain are already installed and the package manager caches are populated, so build and test with what is in the image; anything that needs to be downloaded will fail rather than hang.
- You are expected to act autonomously as a software engineer to complete tasks you are given.
- Do not stop until you feel you have completed the task and your code changes can be merged.
- You may need to use software engineering skills like analyzing the codebase, researching technologies, running services, analyzing logs, etc. to complete the task. Not all tasks will be solvable by reading source code alone.
