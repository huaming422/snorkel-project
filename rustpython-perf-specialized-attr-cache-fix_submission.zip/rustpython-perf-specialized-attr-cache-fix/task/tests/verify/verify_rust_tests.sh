#!/usr/bin/env bash
# C3 (pass_to_pass): the rustpython-vm crate's own unit-test suite must stay
# green. This is the broad crate-level regression net standard for Rust
# performance tasks — it catches collateral breakage in the VM crate from a
# fast-but-wrong steady-state access cache that the 6 hand-authored Python
# correctness scenarios would miss (e.g. a change that keeps the Python-visible
# attribute scenarios correct but regresses a dict/frame/bytecode invariant the
# crate's own tests assert).
#
# The fix touches crates/vm/src/{frame.rs,dict_inner.rs,builtins/dict.rs}, so
# `cargo test -p rustpython-vm --lib` is the most directly impacted suite. Runs
# green on BOTH the unmodified and the fixed crate (measured: 50/50 passing on
# each), so it never gates a legitimate O(1) fix — it only fails a solution that
# breaks a VM invariant.
set -euo pipefail

# The ShellRunner spawns each verifier as a fresh `bash verify*.sh` subprocess,
# so test-setup.sh's exports do not carry over — set the offline switch here, the
# same way verify_perf.sh/verify_correctness.sh locate the binary themselves. The
# image baked the full crate closure in CARGO_HOME and pre-built the test profile,
# so the test-profile rebuild of the agent's modified crate is incremental and
# needs no network.
export CARGO_NET_OFFLINE="${CARGO_NET_OFFLINE:-true}"

# Honor the image-wide CARGO_TARGET_DIR (the pre-warmed cache at
# /opt/cache/cargo-target); fall back to it explicitly if a solution unset it.
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"

# Pin the hash seed for deterministic test behavior, matching the other verifiers.
export PYTHONHASHSEED=0

REPO_DIR=""
for cand in \
    "/repo/RustPython" \
    "$(pwd)"; do
    if [[ -n "${cand}" && -f "${cand}/Cargo.toml" ]]; then REPO_DIR="${cand}"; break; fi
done
if [[ -z "${REPO_DIR}" ]]; then
    echo "FAIL: RustPython workspace root not found (expected /repo/RustPython)" >&2
    exit 1
fi
cd "${REPO_DIR}"
echo "workspace: ${REPO_DIR}"
echo "cargo target dir: ${CARGO_TARGET_DIR}"

LOG="$(mktemp /tmp/vm-crate-tests.XXXXXX.log)"

# Offline-first against the image bake; logged online fallback only if the bake
# was stale (mirrors tests/test-setup.sh). Capture exit status directly — never
# pipe to tail, which would mask it.
if cargo test -p rustpython-vm --lib --no-fail-fast > "${LOG}" 2>&1; then
    RC=0
elif CARGO_NET_OFFLINE=false cargo test -p rustpython-vm --lib --no-fail-fast >> "${LOG}" 2>&1; then
    echo "[verify_rust_tests] rebuilt test profile online (image bake was stale)"
    RC=0
else
    RC=1
fi

# Aggregate every `test result: …` summary (cargo emits one per test binary).
# Require: the command succeeded, at least one summary line, zero failures, and a
# positive pass count (guards against a silent compile failure that produces no
# tests).
SUMMARIES="$(grep -E '^test result:' "${LOG}" || true)"
TOTAL_FAILED="$(echo "${SUMMARIES}" | grep -oE '[0-9]+ failed' | grep -oE '[0-9]+' | awk '{s+=$1} END {print s+0}')"
TOTAL_PASSED="$(echo "${SUMMARIES}" | grep -oE '[0-9]+ passed' | grep -oE '[0-9]+' | awk '{s+=$1} END {print s+0}')"

if [[ "${RC}" -ne 0 ]]; then
    echo "FAIL: cargo test -p rustpython-vm --lib exited non-zero" >&2
    echo "${SUMMARIES}" >&2
    tail -60 "${LOG}" >&2
    rm -f "${LOG}"
    exit 1
fi
if [[ -z "${SUMMARIES}" ]]; then
    echo "FAIL: no 'test result:' summary lines — did the vm crate test binary fail to compile?" >&2
    tail -60 "${LOG}" >&2
    rm -f "${LOG}"
    exit 1
fi
if [[ "${TOTAL_FAILED}" -ne 0 ]]; then
    echo "FAIL: ${TOTAL_FAILED} rustpython-vm unit test(s) FAILED — a VM invariant regressed" >&2
    echo "${SUMMARIES}" >&2
    grep -E '^test .* FAILED$' "${LOG}" | head -40 >&2 || true
    tail -40 "${LOG}" >&2
    rm -f "${LOG}"
    exit 1
fi
if [[ "${TOTAL_PASSED}" -le 0 ]]; then
    echo "FAIL: expected at least one rustpython-vm unit test to pass; saw zero" >&2
    tail -60 "${LOG}" >&2
    rm -f "${LOG}"
    exit 1
fi

rm -f "${LOG}"
echo "PASS: rustpython-vm crate unit tests green (${TOTAL_PASSED} passed, ${TOTAL_FAILED} failed)"
exit 0
