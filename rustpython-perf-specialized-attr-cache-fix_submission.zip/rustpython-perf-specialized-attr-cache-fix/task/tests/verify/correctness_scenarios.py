# Attribute/method-resolution semantics that must be preserved regardless of any
# steady-state access optimization. Run by the built `rustpython` interpreter;
# every check is a plain Python assertion about observable behavior. The program
# exits 0 only if all scenarios resolve exactly as stock Python semantics require.
#
# These scenarios are exactly the cases where an over-eager steady-state cache
# would go wrong: shadowing a class member after the access site is warm, deleting
# keys, replacing or clearing __dict__, holey dicts, shared same-shape instances
# where only one is mutated, and an instance whose __dict__ is a dict subclass
# whose lookup override must keep being consulted. They pass on an unoptimized
# interpreter and must keep passing on an optimized one.


class MethodHolder:
    def m(self):
        return "method"


def method_shadowed_after_specialization():
    obj = MethodHolder()
    obj.pad = 1
    for _ in range(300):
        assert obj.m() == "method"
    # Shadow the class method with an instance attribute after warmup.
    obj.m = lambda: "instance"
    assert obj.m() == "instance"
    del obj.m
    assert obj.m() == "method"
    obj.__dict__["m"] = lambda: "dict"
    assert obj.m() == "dict"
    del obj.__dict__["m"]
    assert obj.m() == "method"


def method_with_value_only_updates():
    obj = MethodHolder()
    obj.pad = 0
    for i in range(500):
        obj.pad = i  # value-only updates: the key set never changes
        assert obj.m() == "method"


class Plain:
    pass


def load_hint_survives_key_churn():
    obj = Plain()
    obj.a = 1
    obj.b = 2
    obj.x = "first"
    for _ in range(300):
        assert obj.x == "first"
    del obj.a
    del obj.b
    assert obj.x == "first"
    del obj.x
    try:
        obj.x
    except AttributeError:
        pass
    else:
        raise AssertionError("expected AttributeError after deleting attribute")
    obj.x = "second"
    assert obj.x == "second"


def store_hint_survives_dict_replacement():
    obj = Plain()
    obj.v = 0
    for i in range(500):
        obj.v = i
        assert obj.v == i
    obj.__dict__ = {"v": "fresh"}
    for i in range(300):
        obj.v = i
        assert obj.v == i
    obj.__dict__.clear()
    obj.v = "back"
    assert obj.v == "back"


class ShapedCounter:
    def __init__(self):
        self.a = 1
        self.b = 2

    def m(self):
        return "method"


def shape_sharing_shadow_one_instance():
    objs = [ShapedCounter() for _ in range(30)]
    for _ in range(300):
        for o in objs:
            assert o.m() == "method"
    objs[13].m = lambda: "thirteen"
    for i, o in enumerate(objs):
        expected = "thirteen" if i == 13 else "method"
        assert o.m() == expected
    del objs[13].m
    for o in objs:
        assert o.m() == "method"


class TrackingDict(dict):
    # A dict subclass that records every lookup routed through its overridden
    # mapping protocol. Instances used as an object's __dict__ must have their
    # overrides consulted on every attribute access — that is current behavior
    # and must be preserved. The call counters live in instance attributes, not
    # dict items, so reading them never re-enters the overrides.
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.getitem_calls = 0
        self.missing_calls = 0

    def __getitem__(self, key):
        self.getitem_calls += 1
        return super().__getitem__(key)

    def __missing__(self, key):
        self.missing_calls += 1
        raise KeyError(key)


def dict_subclass_resolution():
    import sys

    class Dummy:
        pass

    obj = Dummy()
    d = TrackingDict({"x": 42})
    obj.__dict__ = d
    warmup = 500
    for _ in range(warmup):
        assert obj.x == 42
    # On the reference interpreter every attribute read on an instance whose
    # __dict__ is a dict subclass goes through that subclass's __getitem__,
    # including after the access site has specialized. A steady-state fast path
    # that reads the raw entry storage directly would stop consulting the
    # override: the value could still look right by coincidence, but the
    # override would be silently bypassed. The guard is scoped to RustPython
    # because this is RustPython's resolution semantics; other interpreters
    # route dict-subclass __dict__ lookups differently.
    if sys.implementation.name == "rustpython":
        assert d.getitem_calls >= warmup


def holey_dict_falls_back():
    class Holey:
        def m(self):
            return "g"

    def call_m(obj):
        # one access site shared by both instances
        return obj.m()

    g1, g2 = Holey(), Holey()
    for o in (g1, g2):
        o.x = 1
        o.y = 2
        o.z = 3
        del o.y  # leaves a hole in the entries
    for _ in range(300):
        assert call_m(g1) == "g"
        assert call_m(g2) == "g"
    g2.m = lambda: "g2"
    assert call_m(g1) == "g"
    assert call_m(g2) == "g2"


def main():
    method_shadowed_after_specialization()
    method_with_value_only_updates()
    load_hint_survives_key_churn()
    store_hint_survives_dict_replacement()
    shape_sharing_shadow_one_instance()
    dict_subclass_resolution()
    holey_dict_falls_back()
    print("ok")


main()
