#!/usr/bin/env python3
"""Count calls to functions matching a regex in a callgrind output file.

Deterministic work-counter helper for the steady-state attribute-access
verifier. Callgrind (valgrind's call-graph simulator) emits bit-for-bit
deterministic counts across hosts and runs, so counting how many times the
instance-dict hash/probe path is *called* over a warm attribute-access loop is
a stable signal, with no wall-clock, CPU-frequency, or scheduler noise.

callgrind file format (the subset we parse):
  * `fn=(ID) NAME`   — defines ID -> NAME (NAME present on first mention only)
  * `cfn=(ID) NAME`  — names the *callee* of the following `calls=` line; later
                       references may be bare `cfn=(ID)` (ID-only back-ref)
  * `calls=N ...`    — N calls from the current function into the named callee

A correct parser MUST resolve the ID->NAME table, because callgrind prints the
name once and thereafter refers to the function by numeric ID alone. Summing
`calls=` lines whose resolved callee name matches the regex gives the total
inbound call count to the targeted function family.

Usage:
    count_calls.py <callgrind-out-file> <callee-name-regex>
Prints a single integer (total matching call count) to stdout.
"""

from __future__ import annotations

import re
import sys


def _resolve(token_rest: str, id2name: dict[str, str]) -> str:
    """Resolve a `(ID) NAME` / `(ID)` / `NAME` token to a function name,
    learning the ID->NAME mapping as a side effect."""
    m = re.match(r"\((\d+)\)\s*(.*)", token_rest)
    if m:
        fid, name = m.group(1), m.group(2).strip()
        if name:
            id2name[fid] = name
            return name
        return id2name.get(fid, "")
    return token_rest.strip()


def main() -> int:
    if len(sys.argv) != 3:
        print("usage: count_calls.py <callgrind-out> <callee-regex>", file=sys.stderr)
        return 2
    out_path, pattern_src = sys.argv[1], sys.argv[2]
    pat = re.compile(pattern_src)
    id2name: dict[str, str] = {}
    total = 0
    cur_callee: str | None = None
    with open(out_path, encoding="utf-8", errors="replace") as f:
        for line in f:
            if line.startswith("fn="):
                _resolve(line[3:].strip(), id2name)
            elif line.startswith("cfn="):
                cur_callee = _resolve(line[4:].strip(), id2name)
            elif line.startswith("calls="):
                if cur_callee and pat.search(cur_callee):
                    total += int(line.split()[0].split("=")[1])
                cur_callee = None
    print(total)
    return 0


if __name__ == "__main__":
    sys.exit(main())
