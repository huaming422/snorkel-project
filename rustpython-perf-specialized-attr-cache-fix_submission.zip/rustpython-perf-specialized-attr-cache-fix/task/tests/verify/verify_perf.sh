#!/usr/bin/env bash
# C1 (fail_to_pass): steady-state specialized attribute/method access must stop
# paying a per-access instance-dict hash-and-probe once an object's layout has
# stabilized.
#
# Measurement is a DETERMINISTIC work count, never wall-clock. We run the built
# `rustpython` interpreter over a fixed warm attribute-access workload under
# callgrind (valgrind's call-graph simulator — bit-for-bit reproducible across
# hosts and runs) at two sizes N1 < N2, and count how many times the hot path
# calls down into the instance dict's hash/probe routine (`Dict::lookup`, the
# pre-existing lookup entry point the specialized handlers lean on).
#
# The signal is the SLOPE, not the absolute count:
#   delta = calls(N2) - calls(N1)
# A warmed-up access that still probes the dict on every access scales that count
# linearly with the number of steady-state iterations, so delta is large
# (~O(N2-N1)). A fix that recognizes the layout is unchanged and skips the probe
# keeps the count flat, so delta ~ 0 regardless of how the fix is encoded. Taking
# the difference of two runs of the SAME workload cancels the one-time warmup
# floor, so the test keys only on the marginal per-access cost — the exact thing
# the task asks to remove — and does not care about any fix's fixed startup cost.
#
# Calibrated unfixed-vs-fixed (valgrind 3.18.1, release binary):
#   unfixed:            delta ~ 1,280,000   (~320 probe-calls / iteration)
#   fixed (any valid):  delta ~ 6           (~0.0015 / iteration)
# The pass bound sits deep in that gap with >25x margin below the unfixed count
# and >8000x margin above a real fix.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKLOAD="${SCRIPT_DIR}/perf_workload.py"
COUNTER="${SCRIPT_DIR}/count_calls.py"

# Fix the string-hash seed so the instance-dict probe sequence is identical from
# run to run; combined with callgrind's simulated (noise-free) counting this makes
# the measured counts reproducible. The slope test already cancels the one-time
# warmup floor, so this only removes residual jitter well below the pass bound.
export PYTHONHASHSEED=0

# Two steady-state sizes. Both are far past the adaptive-specialization warmup
# (the access sites settle after ~17 executions; the workload warms 400 rounds),
# so every measured iteration is steady state.
N1=4000
N2=8000
# Pass bound on the per-run growth in hash/probe calls between N1 and N2.
# The unfixed path grows by ~1.28M; any valid fix grows by a few. 50_000 gives
# >25x margin below the unfixed count and >8000x above a fix, admitting any O(1)
# encoding.
MAX_DELTA=50000

# Locate the release interpreter the agent's source built (test-setup.sh built it
# offline-first). CARGO_TARGET_DIR is set image-wide; fall back to the in-repo
# target/ if a solution overrode it.
BIN=""
for cand in \
    "${CARGO_TARGET_DIR:-}/release/rustpython" \
    "/repo/RustPython/target/release/rustpython" \
    "$(pwd)/target/release/rustpython"; do
    if [[ -n "${cand}" && -x "${cand}" ]]; then BIN="${cand}"; break; fi
done
if [[ -z "${BIN}" ]]; then
    echo "FAIL: release rustpython binary not found (expected under CARGO_TARGET_DIR/release)" >&2
    exit 1
fi
echo "interpreter: ${BIN}"

command -v valgrind >/dev/null || { echo "FAIL: valgrind missing" >&2; exit 1; }

# Regex for the instance-dict lookup/probe routine. Matches every
# monomorphization of rustpython_vm::dict_inner::Dict::lookup in the mangled
# callgrind symbol names (…dict_inner…Dict…lookup…). This is the pre-existing
# hash/probe entry point; it is used only as a COUNT TARGET — the behavior under
# test is driven entirely through the normal Python attribute-access path.
LOOKUP_RE='dict_inner.*6lookup'

run_count() {
    # $1 = N ; echoes the lookup call count for that run.
    local n="$1" out
    out="$(mktemp /tmp/callgrind.XXXXXX.out)"
    # --cache-sim/--branch-sim off: we only need call counts, and turning the
    # simulators off keeps the run fast and the counts purely structural.
    valgrind --tool=callgrind \
        --callgrind-out-file="${out}" \
        --cache-sim=no --branch-sim=no --dump-line=no \
        "${BIN}" "${WORKLOAD}" "${n}" >/dev/null 2>/dev/null
    local c
    c="$(python3 "${COUNTER}" "${out}" "${LOOKUP_RE}")"
    rm -f "${out}"
    if ! [[ "${c}" =~ ^[0-9]+$ ]]; then
        echo "FAIL: could not parse lookup count for N=${n} (got '${c}')" >&2
        exit 1
    fi
    echo "${c}"
}

C1="$(run_count "${N1}")"
C2="$(run_count "${N2}")"
DELTA=$(( C2 - C1 ))

echo "lookup calls: N=${N1} -> ${C1} ; N=${N2} -> ${C2} ; delta=${DELTA} (bound ${MAX_DELTA})"

if (( DELTA < MAX_DELTA )); then
    echo "PASS: steady-state attribute access does not scale dict hash/probe calls with iteration count (delta ${DELTA} < ${MAX_DELTA})"
    exit 0
else
    echo "FAIL: dict hash/probe calls grow with iteration count (delta ${DELTA} >= ${MAX_DELTA}) — specialized access still probes the instance dict on every access" >&2
    exit 1
fi
