#!/usr/bin/env bash
# C2 (pass_to_pass): Python attribute/method-resolution semantics must be
# preserved across the cases where an over-eager steady-state access cache would
# go wrong — shadowing a class member after warmup, attribute deletion, __dict__
# replacement/clear, holey dicts, and shared same-shape instances where only one
# is mutated.
#
# Runs the built `rustpython` interpreter over a snippet of self-asserting
# scenarios and passes iff it exits 0 and prints the success sentinel. This runs
# green on BOTH the unoptimized and the optimized interpreter: it guards against a
# "fast but wrong" optimization (which would break one of these resolutions) and
# against any regression in the unmodified interpreter.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SNIPPET="${SCRIPT_DIR}/correctness_scenarios.py"

BIN=""
for cand in \
    "${CARGO_TARGET_DIR:-}/release/rustpython" \
    "/repo/RustPython/target/release/rustpython" \
    "$(pwd)/target/release/rustpython"; do
    if [[ -n "${cand}" && -x "${cand}" ]]; then BIN="${cand}"; break; fi
done
if [[ -z "${BIN}" ]]; then
    echo "FAIL: release rustpython binary not found (expected under CARGO_TARGET_DIR/release)" >&2
    exit 1
fi
echo "interpreter: ${BIN}"

OUT="$(mktemp /tmp/correctness.XXXXXX.log)"
if ! "${BIN}" "${SNIPPET}" >"${OUT}" 2>&1; then
    echo "FAIL: attribute/method-resolution scenarios did not all pass" >&2
    tail -40 "${OUT}" >&2
    rm -f "${OUT}"
    exit 1
fi
if ! grep -qx "ok" "${OUT}"; then
    echo "FAIL: scenarios ran without the expected success sentinel" >&2
    tail -40 "${OUT}" >&2
    rm -f "${OUT}"
    exit 1
fi
rm -f "${OUT}"
echo "PASS: attribute and method resolution preserved across shadowing, deletion, __dict__ replacement, holes, and shared same-shape instances"
exit 0
