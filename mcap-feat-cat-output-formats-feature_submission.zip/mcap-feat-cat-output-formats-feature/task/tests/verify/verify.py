"""Behavioral compile-and-contract gate for mcap-feat-cat-output-formats.

Two things are checked, both through pre-existing stable interfaces (the cargo
build and the program's own clap-generated ``--help`` text), never by importing
or naming any symbol the solution introduces:

1. The CLI package builds. The feature changes several internal signatures
   (the cat subcommand's return type, the command-context constructor, the
   timestamp renderer), so a build that still compiles is the floor for every
   other reward artifact — the validation stories cannot run against a binary
   that does not link.

2. The new user-facing option surface is registered. A bare "it compiles"
   check would also pass on the unmodified codebase, so this gate additionally
   runs ``--help`` and asserts the public contract options announced in the
   task description are present: a ``--format`` option on ``cat`` offering the
   tabular and json-lines modes, and a global ``--time-format`` option offering
   its documented modes. These spellings are the user-facing contract (stated
   in the task description), not implementation names, so asserting them is
   fair to any valid implementation while failing the unmodified program.

The gate asserts only the presence of the contract-level option vocabulary; it
does not pin internal identifiers, help wording, or data-path behavior (that is
the validation stories' job).
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

import pytest

REPO_DIR = Path(f"/repo/{os.environ.get('REPO_NAME', 'mcap')}")
CLI_PACKAGE = "mcap-cli"
CAT_SUBCOMMAND = "cat"


def _run(cmd: list[str], *, timeout: int) -> subprocess.CompletedProcess:
    return subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=timeout,
        cwd=str(REPO_DIR),
        check=False,
    )


def _build() -> subprocess.CompletedProcess:
    """Build the CLI package offline against the committed lockfile."""
    return _run(
        [
            "cargo",
            "build",
            "-p",
            CLI_PACKAGE,
            "--locked",
            "--offline",
        ],
        timeout=840,
    )


@pytest.fixture(scope="module")
def built() -> subprocess.CompletedProcess:
    proc = _build()
    assert proc.returncode == 0, (
        f"`cargo build -p {CLI_PACKAGE} --locked --offline` failed (exit "
        f"{proc.returncode}). The feature changes internal signatures across "
        "the CLI crate; the package must still compile.\n"
        f"--- stderr tail ---\n{proc.stderr[-3000:]}"
    )
    return proc


def _help_text(built: subprocess.CompletedProcess, *args: str) -> str:
    """Run the freshly built program with a help flag and return stdout+stderr.

    Resolves the binary from the shared cargo target dir so we exercise the
    artifact `built` just produced rather than rebuilding.
    """
    target = Path(os.environ.get("CARGO_TARGET_DIR", str(REPO_DIR / "target")))
    binary = target / "debug" / "mcap"
    assert binary.exists(), f"built `mcap` binary not found at {binary}"
    proc = _run([str(binary), *args, "--help"], timeout=120)
    return proc.stdout + "\n" + proc.stderr


def test_cli_package_builds(built: subprocess.CompletedProcess) -> None:
    """The CLI package compiles with the feature applied."""
    assert built.returncode == 0


def test_cat_exposes_format_option(built: subprocess.CompletedProcess) -> None:
    """`mcap cat --help` advertises the new --format option and its machine modes."""
    help_text = _help_text(built, CAT_SUBCOMMAND).lower()
    assert "--format" in help_text, (
        "`mcap cat --help` does not mention a --format option. The task adds a "
        "--format option to the cat subcommand."
    )
    # The two machine-output modes named in the contract. `text` is the default
    # and may be implied rather than listed, so it is not required here.
    for mode in ("csv", "ndjson"):
        assert mode in help_text, (
            f"`mcap cat --help` does not advertise the '{mode}' output mode of "
            "--format."
        )


def test_global_time_format_option(built: subprocess.CompletedProcess) -> None:
    """`mcap --help` advertises the global --time-format option and its modes."""
    help_text = _help_text(built).lower()
    assert "--time-format" in help_text, (
        "`mcap --help` does not mention a global --time-format option. The task "
        "adds --time-format spanning cat, info, and list."
    )
    for mode in ("rfc3339", "seconds", "nanoseconds"):
        assert mode in help_text, (
            f"`mcap --help` does not advertise the '{mode}' mode of "
            "--time-format."
        )
