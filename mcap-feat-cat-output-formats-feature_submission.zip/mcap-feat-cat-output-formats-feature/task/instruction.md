## Task

We want real output-format control on `mcap cat`, plus uniform timestamps across the tool.

Give `cat` a `--format` option with three values: `text` (today's human-readable output, and the default), `ndjson` (one JSON object per message, newline-delimited), and `csv` (one row per message). CSV export runs on a single topic via the existing topic selection; each row leads with the metadata columns `log_time`, `publish_time`, and `sequence`, then the payload's fields flattened into columns. Columns come from the first message, so no schema is required.

`--json` becomes a deprecated alias for `--format=ndjson`: it prints a deprecation notice and can't be combined with `--format`.

Add a global `--time-format` flag spanning `cat`, `info`, and `list`, with modes `auto` (the readable default), `rfc3339`, `seconds`, and `nanoseconds`.

Exit status should track the outcome: a clean run exits 0; a run that finishes but drops data, such as CSV columns a later message no longer fits under the first message's shape, exits with a warning status; a genuine error, such as an absent topic, exits with an error status.

## User stories / requirements

- When a recording's messages on one topic all share the same payload shape, exporting that topic as a comma-separated table produces a leading block of record-metadata columns followed by one column per payload field, with one row for every message and a clean, successful run.
- The table's columns are fixed from the first exported message without scanning ahead, so a later message carrying a field the first one lacked cannot add a column; that field's data is dropped, the run reports the loss on its error channel, and it finishes with the warning exit status.
- A structured payload is flattened into columns deterministically: nested object fields become dotted column names in sorted key order, array elements become index-suffixed columns in numeric order, and a null value yields an empty cell. The same payload always produces the same header regardless of field order.
- When two payload fields would flatten to the same column name, or a payload field would flatten to the name of one of the record-metadata columns, the table keeps a single column of that name, drops the duplicate value as data loss, and finishes with the warning exit status.
- Exporting a topic that does not exist in the recording is a user error and stops with the error exit status, while a topic that exists but has no messages in the selected range is benign: it warns, produces no table, and still finishes successfully. The two are never conflated.
- Tabular export is defined for exactly one topic, so a request that names no topic and a request that names more than one are both refused before any table is produced, each stopping with a non-zero exit and no output.
- In the machine-oriented tabular output, timestamp columns are rendered as full RFC3339 UTC strings with nanosecond precision under the default time format, for both small (near-epoch) and real wall-clock times — the machine format does not fall back to a numeric rendering the way human output can.
- A single global time-format option governs how timestamps are rendered across the inspection subcommands. In its default mode, human-readable summaries show near-epoch times as plain decimal seconds rather than a misleading calendar date; selecting an explicit integer-nanoseconds mode renders the very same timestamps as whole nanosecond counts everywhere.
- The global time-format option reaches the `list` subcommand: the chunk-index timestamps shown by `list chunks` change mode when `--time-format` is supplied, rendering near-epoch start times as decimal seconds in the default mode and as whole nanosecond counts in the explicit nanoseconds mode.
- The old opt-in JSON switch keeps working as a synonym for the newline-delimited JSON format and still emits one JSON object per message, but it now also prints a deprecation notice; combining it with an explicit output-format selection is rejected as a conflicting-arguments usage error with no output produced.
- Newline-delimited JSON output decodes message payloads according to the channel's message encoding: a JSON-encoded channel is decoded and emitted as one JSON object per message, whereas a channel whose encoding the tool cannot decode stops with an error rather than emitting garbage.
