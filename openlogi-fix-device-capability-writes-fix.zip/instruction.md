## Task

A few people have reported mouse settings going wrong on some Logitech models. The common models are fine.

After a SmartShift change in the app, the scroll wheel ends up with a ratchet strength nobody picked, even on models that don't have a strength setting at all. It happens on mode switches, on sensitivity changes, and when saved settings get reapplied after the mouse reconnects. DPI has the same problem: after a DPI change the pointer acts as if a separate Y-axis DPI or a lift-off distance was also applied, which the user never set and the model doesn't support.

There's a second DPI issue. On some models a DPI change shows no error, but the pointer speed doesn't change and the mouse keeps its old value. One way to hit it is a DPI from a saved profile, or from another mouse's settings, that this model doesn't list.

Find out why we're sending these mice settings they don't support, and fix it. The app shouldn't apply anything the user didn't choose. A DPI the mouse doesn't list should be refused with an error, not written and not swapped for a nearby value. If the mouse reads back a different DPI after the write, report that as a failure instead of a success.

While you're in there: ratchet strength is a percentage of the wheel's maximum force, so only 1 to 100 is valid. Treat anything outside that range as an error, whether it comes from a saved config or from the mouse's own status, instead of accepting it or reading it as no strength.
