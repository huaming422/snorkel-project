#!/usr/bin/env bash
# Test setup. The image bakes the full dependency closure at the base commit and
# pre-warms `cargo test --no-run` for the whole workspace (minus
# openlogi-desktop), so a test run only recompiles the injected integration test
# plus any changed crates. No services to start, no data to seed, and nothing
# here needs the network.

set -euo pipefail

echo "[test-setup] Rust version:    $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:   $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root:  /repo/OpenLogi"
echo "[test-setup] Setup complete."
