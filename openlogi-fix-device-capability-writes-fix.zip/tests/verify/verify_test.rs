//! End-to-end checks for the device-write paths that configure a Logitech
//! mouse's SmartShift ratchet behaviour and pointer DPI.
//!
//! Every check drives a simulated mouse: a small HID++ device model that
//! implements the public [`RawHidChannel`] transport trait and is served to the
//! write layer through a public [`HidBackend`]. The model answers the HID++
//! feature calls the write paths make and records every report that reaches the
//! wire, so each test can assert on exactly what the app sent to the device and
//! on what the public call returned — without reaching into any private type.
//!
//! The device model is driven entirely through `openlogi_device::write`'s
//! public entry points (`set_dpi`, `set_smartshift`, `toggle_smartshift`,
//! `set_smartshift_sensitivity`, `get_smartshift_status`) and the public
//! `SmartShiftStatus` serde format a saved config loads through; it never
//! constructs an internal channel or feature wrapper.

use std::error::Error;
use std::io;
use std::sync::{Arc, Mutex};

use hidpp::async_trait;
use hidpp::channel::{HidppChannel, RawHidChannel};
use tokio::sync::{Mutex as AsyncMutex, mpsc};

use openlogi_device::backend::{
    BackendError, HidBackend, HotplugEvent, HotplugStream, NodeId, NodeInfo, RawWriter,
};
use openlogi_device::{
    DeviceRoute, Dpi, SmartShiftAutoDisengage, SmartShiftMode, SmartShiftStatus,
    SmartShiftThreshold, TunableTorque, get_smartshift_status, set_dpi, set_smartshift,
    set_smartshift_sensitivity, toggle_smartshift,
};

// ---------------------------------------------------------------------------
// HID++ feature IDs and the self-addressed device index the simulated mouse
// answers on. These are the real wire constants Logitech devices use; the model
// has to speak them to be opened at all.
// ---------------------------------------------------------------------------

/// Enhanced SmartShift wheel feature.
const SMARTSHIFT_ENHANCED: u16 = 0x2111;
/// Original adjustable-DPI feature (flat list of values).
const ADJUSTABLE_DPI: u16 = 0x2201;
/// Extended adjustable-DPI feature (per-axis DPI plus lift-off distance).
const EXTENDED_DPI: u16 = 0x2202;

/// A directly-attached device answers HID++ on this index.
const SELF_INDEX: u8 = 0xff;

/// Vendor / product the test route addresses. The vendor is Logitech's; the
/// product is arbitrary — only that the route and the model agree on it.
const VENDOR: u16 = 0x046d;
const PRODUCT: u16 = 0x4123;

/// HID++ 2.0 error codes the device model answers with.
const ERR_BUSY: u8 = 8;
const ERR_UNSUPPORTED: u8 = 9;

/// Lift-off distance wire values.
const LOD_NOT_SUPPORTED: u8 = 0x00;
const LOD_MEDIUM: u8 = 0x02;

/// How the device model answers one HID++ feature call.
enum Reply {
    /// A short (7-byte) report carrying three payload bytes.
    Short([u8; 3]),
    /// A long (20-byte) report carrying up to sixteen payload bytes.
    Long([u8; 16]),
    /// A HID++ error reply with the given error-type code.
    Error(u8),
}

/// The handler a test supplies: given a resolved feature id, the function id,
/// and the request arguments, decide how the device answers.
type Handler = dyn Fn(u16, u8, &[u8; 16]) -> Reply + Send + Sync;

// ---------------------------------------------------------------------------
// Report framing helpers. Byte layout: [0]=report id, [1]=device index,
// [2]=feature index, [3]=(function<<4 | software id), [4..]=payload.
// ---------------------------------------------------------------------------

/// Build a normal reply that echoes the request's device index, feature index
/// and function/software-id byte, with `payload` placed after the header.
fn make_reply(request: &[u8], payload: &[u8], long: bool) -> Vec<u8> {
    let (report_id, len) = if long { (0x11u8, 20usize) } else { (0x10u8, 7usize) };
    let mut buf = vec![0u8; len];
    buf[0] = report_id;
    buf[1] = request[1];
    buf[2] = request[2];
    buf[3] = request[3];
    let room = len - 4;
    let copied = payload.len().min(room);
    buf[4..4 + copied].copy_from_slice(&payload[..copied]);
    buf
}

/// Build a HID++ error reply for `request`. The feature-index byte becomes
/// `0xff`, the real feature index moves into the function/software-id slot, the
/// original function/software-id byte lands first in the payload, and the error
/// code follows it.
fn make_error(request: &[u8], error_code: u8) -> Vec<u8> {
    let mut buf = vec![0u8; 7];
    buf[0] = 0x10;
    buf[1] = request[1];
    buf[2] = 0xff;
    buf[3] = request[2];
    buf[4] = request[3];
    buf[5] = error_code;
    buf[6] = 0;
    buf
}

// ---------------------------------------------------------------------------
// The simulated device: a transport that computes a reply for each report the
// write layer sends and records everything written.
// ---------------------------------------------------------------------------

struct ScriptedChannel {
    features: Arc<Vec<(u16, u8)>>,
    handler: Arc<Handler>,
    written: Arc<Mutex<Vec<Vec<u8>>>>,
    incoming_tx: mpsc::UnboundedSender<Vec<u8>>,
    incoming_rx: AsyncMutex<mpsc::UnboundedReceiver<Vec<u8>>>,
}

impl ScriptedChannel {
    /// Compute the device's reply to one outgoing report, or `None` to stay
    /// silent. Handles the protocol-version ping and root feature lookup
    /// itself; everything else is delegated to the test's handler.
    fn compute(&self, src: &[u8]) -> Option<Vec<u8>> {
        if src.len() < 4 {
            return None;
        }
        let feature_index = src[2];
        let function = src[3] >> 4;

        let mut args = [0u8; 16];
        let payload = &src[4..];
        let copied = payload.len().min(16);
        args[..copied].copy_from_slice(&payload[..copied]);

        // Root feature (index 0): protocol-version ping (function 1) and
        // getFeature (function 0).
        if feature_index == 0x00 {
            if function == 0x01 {
                // Report HID++ 2.0 so the device opens.
                return Some(make_reply(src, &[0x04, 0x00, 0x00], false));
            }
            if function == 0x00 {
                let wanted = (u16::from(args[0]) << 8) | u16::from(args[1]);
                let index = self
                    .features
                    .iter()
                    .find(|(id, _)| *id == wanted)
                    .map_or(0, |(_, index)| *index);
                // A zero index means "feature not present".
                return Some(make_reply(src, &[index, 0, 0], false));
            }
            return Some(make_error(src, 1));
        }

        // A feature-specific call. Resolve the index back to its id so the
        // handler can match on the id it knows.
        let resolved = self
            .features
            .iter()
            .find(|(_, index)| *index == feature_index)
            .map(|(id, _)| *id);
        let Some(id) = resolved else {
            return Some(make_error(src, 6));
        };

        match (self.handler)(id, function, &args) {
            Reply::Short(bytes) => Some(make_reply(src, &bytes, false)),
            Reply::Long(bytes) => Some(make_reply(src, &bytes, true)),
            Reply::Error(code) => Some(make_error(src, code)),
        }
    }
}

#[async_trait]
impl RawHidChannel for ScriptedChannel {
    fn vendor_id(&self) -> u16 {
        VENDOR
    }

    fn product_id(&self) -> u16 {
        PRODUCT
    }

    async fn write_report(&self, src: &[u8]) -> Result<usize, Box<dyn Error + Sync + Send>> {
        self.written.lock().unwrap().push(src.to_vec());
        if let Some(reply) = self.compute(src) {
            // The only sender is held by this channel, so this cannot fail
            // while the channel is alive.
            let _ = self.incoming_tx.send(reply);
        }
        Ok(src.len())
    }

    async fn read_report(&self, buf: &mut [u8]) -> Result<usize, Box<dyn Error + Sync + Send>> {
        let next = {
            let mut rx = self.incoming_rx.lock().await;
            rx.recv().await
        };
        let Some(report) = next else {
            // The sender has been dropped and no further report will arrive:
            // surface a disconnected transport error, matching how a real HID
            // read reports a device that has gone away.
            return Err(Box::new(io::Error::new(
                io::ErrorKind::BrokenPipe,
                "scripted HID channel is disconnected",
            )));
        };
        let len = report.len().min(buf.len());
        buf[..len].copy_from_slice(&report[..len]);
        Ok(len)
    }

    fn supports_short_long_hidpp(&self) -> Option<(bool, bool)> {
        Some((true, true))
    }

    async fn get_report_descriptor(
        &self,
        _buf: &mut [u8],
    ) -> Result<usize, Box<dyn Error + Sync + Send>> {
        unreachable!("the scripted device declares HID++ support directly")
    }
}

/// The backend the write layer enumerates and opens. Each open builds a fresh
/// channel that shares this backend's recorded-writes log and handler.
struct ScriptedBackend {
    features: Arc<Vec<(u16, u8)>>,
    handler: Arc<Handler>,
    written: Arc<Mutex<Vec<Vec<u8>>>>,
}

#[async_trait]
impl HidBackend for ScriptedBackend {
    async fn enumerate(&self) -> Result<Vec<NodeInfo>, BackendError> {
        Ok(vec![self.node()])
    }

    async fn enumerate_hidpp(&self) -> Result<Vec<NodeInfo>, BackendError> {
        Ok(vec![self.node()])
    }

    async fn open_hidpp(&self, _node: &NodeInfo) -> Result<Option<Arc<HidppChannel>>, BackendError> {
        let (incoming_tx, incoming_rx) = mpsc::unbounded_channel();
        let channel = ScriptedChannel {
            features: Arc::clone(&self.features),
            handler: Arc::clone(&self.handler),
            written: Arc::clone(&self.written),
            incoming_tx,
            incoming_rx: AsyncMutex::new(incoming_rx),
        };
        let channel = HidppChannel::from_raw_channel(channel)
            .await
            .map_err(|error| BackendError::Backend(format!("{error:?}")))?;
        Ok(Some(Arc::new(channel)))
    }

    async fn open_raw_writer(&self, _node: &NodeInfo) -> Result<Box<dyn RawWriter>, BackendError> {
        Err(BackendError::Disconnected)
    }

    fn watch(&self) -> Result<HotplugStream, BackendError> {
        Ok(Box::new(futures_lite::stream::empty::<HotplugEvent>()))
    }
}

impl ScriptedBackend {
    fn node(&self) -> NodeInfo {
        NodeInfo {
            id: NodeId::from("scripted-node".to_string()),
            vendor_id: VENDOR,
            product_id: PRODUCT,
            usage_page: 0xff00,
            usage_id: 0x0001,
            name: "scripted mouse".to_string(),
            manufacturer: None,
            serial_number: None,
        }
    }
}

/// Assemble a backend that exposes `features` (id → HID++ index) and answers
/// feature calls through `handler`. Returns the backend plus the shared log of
/// every report the write layer sends.
fn scripted_backend(
    features: Vec<(u16, u8)>,
    handler: impl Fn(u16, u8, &[u8; 16]) -> Reply + Send + Sync + 'static,
) -> (ScriptedBackend, Arc<Mutex<Vec<Vec<u8>>>>) {
    let written = Arc::new(Mutex::new(Vec::new()));
    let backend = ScriptedBackend {
        features: Arc::new(features),
        handler: Arc::new(handler),
        written: Arc::clone(&written),
    };
    (backend, written)
}

/// The route every test drives: a directly-attached device.
fn direct_route() -> DeviceRoute {
    DeviceRoute::Direct {
        vendor_id: VENDOR,
        product_id: PRODUCT,
    }
}

// ---------------------------------------------------------------------------
// Assertion helpers over the recorded reports.
// ---------------------------------------------------------------------------

/// Every recorded report sent to `feature_index` invoking `function`, in the
/// order they were sent.
fn sent_reports(written: &Arc<Mutex<Vec<Vec<u8>>>>, feature_index: u8, function: u8) -> Vec<Vec<u8>> {
    written
        .lock()
        .unwrap()
        .iter()
        .filter(|report| report.len() >= 4 && report[2] == feature_index && (report[3] >> 4) == function)
        .cloned()
        .collect()
}

/// The first recorded report sent to `feature_index` invoking `function`.
fn sent_report(written: &Arc<Mutex<Vec<Vec<u8>>>>, feature_index: u8, function: u8) -> Option<Vec<u8>> {
    sent_reports(written, feature_index, function).into_iter().next()
}

/// Whether any report was sent to `feature_index` invoking `function`.
fn any_sent(written: &Arc<Mutex<Vec<Vec<u8>>>>, feature_index: u8, function: u8) -> bool {
    sent_report(written, feature_index, function).is_some()
}

// ---------------------------------------------------------------------------
// Device-model payload builders.
// ---------------------------------------------------------------------------

/// A `getSensorDpiList` (0x2201) reply: echoed sensor 0, then each value as a
/// big-endian word, then the zero end-of-list word.
fn adjustable_dpi_list(values: &[u16]) -> [u8; 16] {
    let mut payload = [0u8; 16];
    for (i, value) in values.iter().enumerate() {
        payload[1 + 2 * i..3 + 2 * i].copy_from_slice(&value.to_be_bytes());
    }
    payload
}

/// A `getSensorDpiRanges` (0x2202) reply for page 0 of the X direction: echoed
/// sensor, direction and page, then each value as a big-endian word, then the
/// zero end-of-list word.
fn extended_dpi_ranges(values: &[u16]) -> [u8; 16] {
    let mut payload = [0u8; 16];
    for (i, value) in values.iter().enumerate() {
        payload[3 + 2 * i..5 + 2 * i].copy_from_slice(&value.to_be_bytes());
    }
    payload
}

/// A `getSensorDpiParameters` (0x2202) reply for sensor 0: the current X DPI
/// (also reported as the default X), the given Y DPI (also the default Y), and
/// the lift-off distance.
fn extended_dpi_parameters(dpi_x: u16, dpi_y: u16, lod: u8) -> [u8; 16] {
    let mut payload = [0u8; 16];
    payload[1..3].copy_from_slice(&dpi_x.to_be_bytes());
    payload[3..5].copy_from_slice(&dpi_x.to_be_bytes());
    payload[5..7].copy_from_slice(&dpi_y.to_be_bytes());
    payload[7..9].copy_from_slice(&dpi_y.to_be_bytes());
    payload[9] = lod;
    payload
}

/// A 0x2202 sensor whose capability byte is `capabilities` and whose supported
/// X values are `supported`. It reports a Y DPI of 800 and a Medium lift-off,
/// starts at 800 DPI, and takes whatever X a parameters write carries. Returns
/// the handler and the sensor's current X DPI.
fn extended_sensor(
    capabilities: u8,
    supported: &'static [u16],
) -> (impl Fn(u16, u8, &[u8; 16]) -> Reply + Send + Sync + 'static, Arc<Mutex<u16>>) {
    let current_x = Arc::new(Mutex::new(800u16));
    let state = Arc::clone(&current_x);
    let handler = move |_id: u16, function: u8, args: &[u8; 16]| match function {
        // getSensorCapabilities: sensor 0, one DPI level, the capability byte.
        1 => Reply::Short([0x00, 0x01, capabilities]),
        // getSensorDpiRanges (X).
        2 => Reply::Long(extended_dpi_ranges(supported)),
        // getSensorDpiParameters.
        5 => Reply::Long(extended_dpi_parameters(*state.lock().unwrap(), 800, LOD_MEDIUM)),
        // setSensorDpiParameters: the sensor takes the written X.
        6 => {
            *state.lock().unwrap() = u16::from_be_bytes([args[1], args[2]]);
            Reply::Short([0x00, 0x00, 0x00])
        }
        _ => Reply::Error(ERR_UNSUPPORTED),
    };
    (handler, current_x)
}

// ---------------------------------------------------------------------------
// SmartShift: a torque level reaches only a wheel that supports one.
// ---------------------------------------------------------------------------

/// A config apply to a wheel without tunable torque, whose status reply carries
/// a torque byte of 40, applies the mode and threshold and sends the zero
/// "do not change" sentinel in the torque field.
#[tokio::test]
async fn smartshift_without_tunable_torque_sends_zero_torque() {
    // index 1 hosts Enhanced SmartShift.
    let (backend, written) = scripted_backend(vec![(SMARTSHIFT_ENHANCED, 0x01)], |_id, function, args| {
        match function {
            // getCapabilities: the tunable-torque bit is clear.
            0 => Reply::Short([0x00, 0x00, 0x00]),
            // getRatchetControlMode: free-spin, threshold 20, torque byte 40.
            // Free-spin differs from the ratchet we request, so a write is due.
            1 => Reply::Short([0x01, 20, 40]),
            // setRatchetControlMode acknowledgement (echoes what was written).
            2 => Reply::Short([args[0], args[1], args[2]]),
            _ => Reply::Error(ERR_UNSUPPORTED),
        }
    });

    let desired = SmartShiftStatus {
        mode: SmartShiftMode::Ratchet,
        auto_disengage: SmartShiftAutoDisengage::Threshold(SmartShiftThreshold::try_new(20).unwrap()),
        tunable_torque: Some(TunableTorque::try_new(50).unwrap()),
    };

    let result = set_smartshift(&backend, &direct_route(), desired).await;
    assert!(result.is_ok(), "write should apply mode and threshold: {result:?}");

    let set = sent_report(&written, 0x01, 2).expect("a setRatchetControlMode report was sent");
    // Wire payload: [4]=mode, [5]=auto-disengage, [6]=tunable torque.
    assert_eq!(set[4], 0x02, "ratchet mode is written");
    assert_eq!(set[5], 20, "the requested threshold is written");
    assert_eq!(
        set[6], 0x00,
        "a wheel without tunable torque must get the zero torque sentinel"
    );
}

/// A config apply to a wheel with tunable torque, whose status reply carries a
/// torque byte of 0, sends the requested torque level.
#[tokio::test]
async fn smartshift_with_tunable_torque_writes_the_requested_torque() {
    let (backend, written) = scripted_backend(vec![(SMARTSHIFT_ENHANCED, 0x01)], |_id, function, args| {
        match function {
            // getCapabilities: tunable torque (bit 0), default threshold 20,
            // default torque 30.
            0 => Reply::Short([0x01, 20, 30]),
            // getRatchetControlMode: free-spin, threshold 20, torque byte 0.
            1 => Reply::Short([0x01, 20, 0x00]),
            // setRatchetControlMode acknowledgement (echoes what was written).
            2 => Reply::Short([args[0], args[1], args[2]]),
            _ => Reply::Error(ERR_UNSUPPORTED),
        }
    });

    let desired = SmartShiftStatus {
        mode: SmartShiftMode::Ratchet,
        auto_disengage: SmartShiftAutoDisengage::Threshold(SmartShiftThreshold::try_new(20).unwrap()),
        tunable_torque: Some(TunableTorque::try_new(50).unwrap()),
    };

    let result = set_smartshift(&backend, &direct_route(), desired).await;
    assert!(result.is_ok(), "write should succeed: {result:?}");

    let set = sent_report(&written, 0x01, 2).expect("a setRatchetControlMode report was sent");
    assert_eq!(set[4], 0x02, "ratchet mode is written");
    assert_eq!(set[5], 20, "the requested threshold is written");
    assert_eq!(set[6], 50, "a wheel with tunable torque receives the requested level");
}

/// When the wheel's capability read fails, whether it has tunable torque is
/// unknown, so no torque level may reach the wire. The call may fail, or it may
/// apply mode and threshold with the zero "do not change" torque.
#[tokio::test]
async fn smartshift_capability_read_failure_never_pushes_torque() {
    let (backend, written) = scripted_backend(vec![(SMARTSHIFT_ENHANCED, 0x01)], |_id, function, args| {
        match function {
            // getCapabilities fails outright.
            0 => Reply::Error(ERR_UNSUPPORTED),
            // getRatchetControlMode reports free-spin, so a write is due.
            1 => Reply::Short([0x01, 20, 0x00]),
            // setRatchetControlMode acknowledgement (echoes what was written).
            2 => Reply::Short([args[0], args[1], args[2]]),
            _ => Reply::Error(ERR_UNSUPPORTED),
        }
    });

    let desired = SmartShiftStatus {
        mode: SmartShiftMode::Ratchet,
        auto_disengage: SmartShiftAutoDisengage::Threshold(SmartShiftThreshold::try_new(20).unwrap()),
        tunable_torque: Some(TunableTorque::try_new(50).unwrap()),
    };

    let result = set_smartshift(&backend, &direct_route(), desired).await;

    let writes = sent_reports(&written, 0x01, 2);
    assert!(
        writes.iter().all(|report| report[6] == 0),
        "no torque level may be written while tunable-torque support is unknown \
         (call returned {result:?})",
    );
    if result.is_ok() {
        assert!(
            writes.iter().any(|report| report[4] == 0x02 && report[5] == 20),
            "a write reported as successful must have applied the requested mode and threshold",
        );
    }
}

/// A wheel without tunable torque in ratchet mode, threshold 20, whose status
/// reply carries a torque byte of 40.
fn wheel_without_tunable_torque(_id: u16, function: u8, args: &[u8; 16]) -> Reply {
    match function {
        // getCapabilities: tunable-torque bit clear.
        0 => Reply::Short([0x00, 20, 0x00]),
        // getRatchetControlMode.
        1 => Reply::Short([0x02, 20, 40]),
        // setRatchetControlMode acknowledgement (echoes what was written).
        2 => Reply::Short([args[0], args[1], args[2]]),
        _ => Reply::Error(ERR_UNSUPPORTED),
    }
}

/// A mode toggle and a sensitivity change on a wheel without tunable torque
/// write their own field and send no torque level.
#[tokio::test]
async fn smartshift_toggle_and_sensitivity_send_no_torque_to_a_wheel_without_it() {
    // Mode toggle: ratchet becomes free-spin.
    let (backend, written) = scripted_backend(vec![(SMARTSHIFT_ENHANCED, 0x01)], wheel_without_tunable_torque);
    let toggled = toggle_smartshift(&backend, &direct_route()).await;
    assert!(toggled.is_ok(), "the toggle should succeed: {toggled:?}");
    let writes = sent_reports(&written, 0x01, 2);
    assert!(
        writes.iter().any(|report| report[4] == 0x01),
        "the toggle writes free-spin mode"
    );
    assert!(
        writes.iter().all(|report| report[6] == 0),
        "a mode toggle must not write a torque level to a wheel without tunable torque"
    );

    // Sensitivity change: threshold 20 becomes 30.
    let (backend, written) = scripted_backend(vec![(SMARTSHIFT_ENHANCED, 0x01)], wheel_without_tunable_torque);
    let threshold = SmartShiftAutoDisengage::Threshold(SmartShiftThreshold::try_new(30).unwrap());
    let changed = set_smartshift_sensitivity(&backend, &direct_route(), threshold).await;
    assert!(changed.is_ok(), "the sensitivity change should succeed: {changed:?}");
    let writes = sent_reports(&written, 0x01, 2);
    assert!(
        writes.iter().any(|report| report[5] == 30),
        "the sensitivity change writes the new threshold"
    );
    assert!(
        writes.iter().all(|report| report[6] == 0),
        "a sensitivity change must not write a torque level to a wheel without tunable torque"
    );
}

/// When the first SmartShift write is refused with a transient Busy error and
/// the write is retried, neither attempt sends a torque level to a wheel
/// without tunable torque.
#[tokio::test]
async fn smartshift_retry_after_a_transient_error_sends_no_torque_to_a_wheel_without_it() {
    let attempts = Arc::new(Mutex::new(0u32));
    let seen = Arc::clone(&attempts);
    let (backend, written) = scripted_backend(vec![(SMARTSHIFT_ENHANCED, 0x01)], move |_id, function, args| {
        match function {
            // getCapabilities: tunable-torque bit clear.
            0 => Reply::Short([0x00, 20, 0x00]),
            // getRatchetControlMode: free-spin, threshold 20, torque byte 40.
            1 => Reply::Short([0x01, 20, 40]),
            // setRatchetControlMode: Busy the first time, accepted after that.
            2 => {
                let mut count = seen.lock().unwrap();
                *count += 1;
                if *count == 1 {
                    Reply::Error(ERR_BUSY)
                } else {
                    Reply::Short([args[0], args[1], args[2]])
                }
            }
            _ => Reply::Error(ERR_UNSUPPORTED),
        }
    });

    let desired = SmartShiftStatus {
        mode: SmartShiftMode::Ratchet,
        auto_disengage: SmartShiftAutoDisengage::Threshold(SmartShiftThreshold::try_new(20).unwrap()),
        tunable_torque: Some(TunableTorque::try_new(50).unwrap()),
    };

    let result = set_smartshift(&backend, &direct_route(), desired).await;
    assert!(result.is_ok(), "the retried write should succeed: {result:?}");

    let writes = sent_reports(&written, 0x01, 2);
    assert!(writes.len() >= 2, "the Busy write is retried ({} attempts)", writes.len());
    assert!(
        writes.iter().all(|report| report[6] == 0),
        "no attempt may write a torque level to a wheel without tunable torque"
    );
    assert!(
        writes.last().is_some_and(|report| report[4] == 0x02 && report[5] == 20),
        "the retry applies the requested mode and threshold"
    );
}

// ---------------------------------------------------------------------------
// DPI: a Y-axis DPI or a lift-off distance reaches only a sensor that supports
// it, and a DPI change either takes effect or fails.
// ---------------------------------------------------------------------------

/// On an extended-DPI sensor that supports neither an independent Y axis nor
/// lift-off control, and whose parameters reply carries a Y of 1600 and a High
/// lift-off, a DPI write sends Y and lift-off as zero.
#[tokio::test]
async fn dpi_without_axis_or_lod_capability_sends_zero_fields() {
    // index 3 hosts extended DPI; the original adjustable feature is absent.
    let (backend, written) = scripted_backend(vec![(EXTENDED_DPI, 0x03)], |_id, function, _args| {
        match function {
            // getSensorCapabilities: sensor 0, no capability bits set.
            1 => Reply::Short([0x00, 0x01, 0x00]),
            // getSensorDpiRanges (X): the supported values 1600, 800, 3200.
            2 => Reply::Long(extended_dpi_ranges(&[1600, 800, 3200])),
            // getSensorDpiParameters: X 1600, Y 1600, lift-off High.
            5 => Reply::Long(extended_dpi_parameters(1600, 1600, 0x03)),
            // setSensorDpiParameters acknowledgement.
            6 => Reply::Short([0x00, 0x00, 0x00]),
            _ => Reply::Error(ERR_UNSUPPORTED),
        }
    });

    let result = set_dpi(&backend, &direct_route(), Dpi::new(1600)).await;
    assert!(result.is_ok(), "a supported DPI write should succeed: {result:?}");

    // setSensorDpiParameters is a long report: [4]=sensor, [5..7]=dpi_x,
    // [7..9]=dpi_y, [9]=lift-off distance.
    let set = sent_report(&written, 0x03, 6).expect("a setSensorDpiParameters report was sent");
    assert_eq!([set[5], set[6]], [0x06, 0x40], "dpi_x carries the requested value");
    assert_eq!(
        [set[7], set[8]],
        [0x00, 0x00],
        "dpi_y must be zero when the sensor has no independent Y axis"
    );
    assert_eq!(
        set[9], LOD_NOT_SUPPORTED,
        "lift-off distance must be zero when the sensor has no lift-off control"
    );
}

/// On an extended-DPI sensor that supports both an independent Y axis and
/// lift-off control, a DPI write keeps Y locked to the requested X value and
/// writes the current lift-off distance back unchanged.
#[tokio::test]
async fn dpi_with_axis_and_lod_capability_locks_y_and_keeps_lod() {
    // Capability byte 0x03: independent Y axis (bit 0) and lift-off (bit 1).
    let (handler, current_x) = extended_sensor(0x03, &[800, 1600]);
    let (backend, written) = scripted_backend(vec![(EXTENDED_DPI, 0x03)], handler);

    let result = set_dpi(&backend, &direct_route(), Dpi::new(1600)).await;
    assert!(result.is_ok(), "a supported DPI write should succeed: {result:?}");

    let set = sent_report(&written, 0x03, 6).expect("a setSensorDpiParameters report was sent");
    assert_eq!([set[5], set[6]], [0x06, 0x40], "dpi_x carries the requested value");
    assert_eq!(
        [set[7], set[8]],
        [0x06, 0x40],
        "dpi_y stays locked to the requested value on a sensor with an independent Y axis"
    );
    assert_eq!(
        set[9], LOD_MEDIUM,
        "the current lift-off distance is written back on a sensor with lift-off control"
    );
    assert_eq!(*current_x.lock().unwrap(), 1600, "the sensor took the new DPI");
}

/// On an extended-DPI sensor that supports only one of the two optional
/// fields, a DPI write sends that field and sends the other as zero: an
/// independent-Y-only sensor gets Y locked to X and no lift-off, and a
/// lift-off-only sensor gets its lift-off written back and no Y.
#[tokio::test]
async fn dpi_with_one_capability_bit_sends_only_that_field() {
    // (capability byte, expected Y on the wire, expected lift-off on the wire)
    let cases: [(u8, u16, u8); 2] = [
        // Independent Y axis only.
        (0x01, 1600, LOD_NOT_SUPPORTED),
        // Lift-off control only.
        (0x02, 0, LOD_MEDIUM),
    ];
    for (capabilities, expected_y, expected_lod) in cases {
        let (handler, current_x) = extended_sensor(capabilities, &[800, 1600]);
        let (backend, written) = scripted_backend(vec![(EXTENDED_DPI, 0x03)], handler);

        let result = set_dpi(&backend, &direct_route(), Dpi::new(1600)).await;
        assert!(
            result.is_ok(),
            "capability byte {capabilities:#04x}: a supported DPI write should succeed: {result:?}"
        );

        let set = sent_report(&written, 0x03, 6).expect("a setSensorDpiParameters report was sent");
        assert_eq!(
            [set[5], set[6]],
            [0x06, 0x40],
            "capability byte {capabilities:#04x}: dpi_x carries the requested value"
        );
        assert_eq!(
            u16::from_be_bytes([set[7], set[8]]),
            expected_y,
            "capability byte {capabilities:#04x}: wrong dpi_y on the wire"
        );
        assert_eq!(
            set[9], expected_lod,
            "capability byte {capabilities:#04x}: wrong lift-off distance on the wire"
        );
        assert_eq!(*current_x.lock().unwrap(), 1600, "the sensor took the new DPI");
    }
}

/// A 0x2201 sensor that lists 800, 1600 and 3200 and currently reports 1600.
fn adjustable_sensor_800_1600_3200(_id: u16, function: u8, _args: &[u8; 16]) -> Reply {
    match function {
        // getSensorDpiList.
        1 => Reply::Long(adjustable_dpi_list(&[800, 1600, 3200])),
        // getSensorDpi.
        2 => Reply::Short([0x00, 0x06, 0x40]),
        // setSensorDpi acknowledgement.
        3 => Reply::Short([0x00, 0x00, 0x00]),
        _ => Reply::Error(ERR_UNSUPPORTED),
    }
}

/// A requested DPI that the sensor does not list (below the list, between two
/// listed values, or above the list) is refused on both DPI features: the call
/// fails and no DPI write reaches the wire, so neither the requested value nor
/// a nearby listed value is written. Any error value is acceptable.
#[tokio::test]
async fn dpi_outside_supported_list_is_rejected_without_writing() {
    for requested in [400u16, 1000, 5000] {
        // 0x2201 at index 2.
        let (backend, written) = scripted_backend(vec![(ADJUSTABLE_DPI, 0x02)], adjustable_sensor_800_1600_3200);
        let result = set_dpi(&backend, &direct_route(), Dpi::new(requested)).await;
        assert!(
            result.is_err(),
            "0x2201: DPI {requested} is not listed and must be refused: {result:?}"
        );
        assert!(
            !any_sent(&written, 0x02, 3),
            "0x2201: no setSensorDpi report may be written for unlisted DPI {requested}"
        );

        // 0x2202 at index 3.
        let (handler, current_x) = extended_sensor(0x00, &[800, 1600, 3200]);
        let (backend, written) = scripted_backend(vec![(EXTENDED_DPI, 0x03)], handler);
        let result = set_dpi(&backend, &direct_route(), Dpi::new(requested)).await;
        assert!(
            result.is_err(),
            "0x2202: DPI {requested} is not listed and must be refused: {result:?}"
        );
        assert!(
            !any_sent(&written, 0x03, 6),
            "0x2202: no setSensorDpiParameters report may be written for unlisted DPI {requested}"
        );
        assert_eq!(*current_x.lock().unwrap(), 800, "0x2202: the sensor keeps its DPI");
    }
}

/// After the single re-write, a sensor that still reads back a different value
/// makes the call fail instead of reporting success, on both DPI features. A
/// read-back that itself fails leaves the acknowledged write standing. Any
/// error value is acceptable for the mismatch.
#[tokio::test]
async fn dpi_readback_mismatch_fails_but_readback_error_succeeds() {
    // 0x2201, case A: the sensor accepts the write but always reads back 800.
    let (backend, _written) = scripted_backend(vec![(ADJUSTABLE_DPI, 0x02)], |_id, function, _args| {
        match function {
            // getSensorDpiList: 800 and 1600 are listed.
            1 => Reply::Long(adjustable_dpi_list(&[800, 1600])),
            // getSensorDpi always reports 800, never the requested 1600.
            2 => Reply::Short([0x00, 0x03, 0x20]),
            // setSensorDpi acknowledgement.
            3 => Reply::Short([0x00, 0x00, 0x00]),
            _ => Reply::Error(ERR_UNSUPPORTED),
        }
    });
    let result = set_dpi(&backend, &direct_route(), Dpi::new(1600)).await;
    assert!(
        result.is_err(),
        "0x2201: a persistent read-back mismatch must not be reported as success: {result:?}"
    );

    // 0x2201, case B: the read-back itself errors.
    let (backend, _written) = scripted_backend(vec![(ADJUSTABLE_DPI, 0x02)], |_id, function, _args| {
        match function {
            1 => Reply::Long(adjustable_dpi_list(&[800, 1600])),
            // The read-back fails rather than reporting a value.
            2 => Reply::Error(4),
            3 => Reply::Short([0x00, 0x00, 0x00]),
            _ => Reply::Error(ERR_UNSUPPORTED),
        }
    });
    let result = set_dpi(&backend, &direct_route(), Dpi::new(1600)).await;
    assert!(
        result.is_ok(),
        "0x2201: a failed read-back must leave the acknowledged write standing: {result:?}"
    );

    // 0x2202, case A: the sensor acknowledges parameter writes but its X DPI
    // stays at 800.
    let (backend, written) = scripted_backend(vec![(EXTENDED_DPI, 0x03)], |_id, function, _args| {
        match function {
            1 => Reply::Short([0x00, 0x01, 0x00]),
            2 => Reply::Long(extended_dpi_ranges(&[800, 1600])),
            5 => Reply::Long(extended_dpi_parameters(800, 0, LOD_NOT_SUPPORTED)),
            6 => Reply::Short([0x00, 0x00, 0x00]),
            _ => Reply::Error(ERR_UNSUPPORTED),
        }
    });
    let result = set_dpi(&backend, &direct_route(), Dpi::new(1600)).await;
    assert!(
        any_sent(&written, 0x03, 6),
        "0x2202: the listed DPI is written before the mismatch is seen"
    );
    assert!(
        result.is_err(),
        "0x2202: a persistent read-back mismatch must not be reported as success: {result:?}"
    );

    // 0x2202, case B: once a parameters write has been sent, the parameters
    // read fails.
    let wrote = Arc::new(Mutex::new(false));
    let seen = Arc::clone(&wrote);
    let (backend, _written) = scripted_backend(vec![(EXTENDED_DPI, 0x03)], move |_id, function, _args| {
        match function {
            1 => Reply::Short([0x00, 0x01, 0x00]),
            2 => Reply::Long(extended_dpi_ranges(&[800, 1600])),
            5 => {
                if *seen.lock().unwrap() {
                    Reply::Error(4)
                } else {
                    Reply::Long(extended_dpi_parameters(800, 0, LOD_NOT_SUPPORTED))
                }
            }
            6 => {
                *seen.lock().unwrap() = true;
                Reply::Short([0x00, 0x00, 0x00])
            }
            _ => Reply::Error(ERR_UNSUPPORTED),
        }
    });
    let result = set_dpi(&backend, &direct_route(), Dpi::new(1600)).await;
    assert!(*wrote.lock().unwrap(), "0x2202: the listed DPI is written");
    assert!(
        result.is_ok(),
        "0x2202: a failed read-back must leave the acknowledged write standing: {result:?}"
    );
}

// ---------------------------------------------------------------------------
// Ratchet strength is a 1..=100 percentage, from a saved config and from the
// wheel itself.
// ---------------------------------------------------------------------------

/// A wheel with tunable torque in free-spin mode, threshold 20, torque 30.
fn wheel_with_tunable_torque(_id: u16, function: u8, args: &[u8; 16]) -> Reply {
    match function {
        // getCapabilities: tunable torque, default threshold 20, default 30.
        0 => Reply::Short([0x01, 20, 30]),
        // getRatchetControlMode.
        1 => Reply::Short([0x01, 20, 30]),
        // setRatchetControlMode acknowledgement (echoes what was written).
        2 => Reply::Short([args[0], args[1], args[2]]),
        _ => Reply::Error(ERR_UNSUPPORTED),
    }
}

/// A saved SmartShift status loads with a strength of 1 or 100, and one with a
/// strength above 100 is refused: either loading it fails, or applying it fails
/// without that strength reaching the wheel.
#[tokio::test]
async fn tunable_torque_outside_1_to_100_from_a_saved_config_is_refused() {
    // Serialize a valid status with a distinctive strength (77) to find which
    // field of the saved form carries it.
    let template = SmartShiftStatus {
        mode: SmartShiftMode::Ratchet,
        auto_disengage: SmartShiftAutoDisengage::Threshold(SmartShiftThreshold::try_new(20).unwrap()),
        tunable_torque: Some(TunableTorque::try_new(77).unwrap()),
    };
    let saved = serde_json::to_value(template).expect("a SmartShift status serializes");
    let key = saved
        .as_object()
        .and_then(|fields| fields.iter().find(|(_, value)| **value == serde_json::json!(77)))
        .map(|(key, _)| key.clone())
        .expect("the saved status carries the strength as a field");
    let with_strength = |level: u8| {
        let mut value = saved.clone();
        value[&key] = serde_json::json!(level);
        value
    };

    for level in [1u8, 100] {
        let loaded: SmartShiftStatus = serde_json::from_value(with_strength(level))
            .unwrap_or_else(|error| panic!("a saved strength of {level} must load: {error}"));
        assert_eq!(
            loaded.tunable_torque,
            Some(TunableTorque::try_new(level).unwrap()),
            "a saved strength of {level} loads unchanged"
        );
    }

    for level in [101u8, 150, 255] {
        let Ok(loaded) = serde_json::from_value::<SmartShiftStatus>(with_strength(level)) else {
            // Refused when the saved status is loaded.
            continue;
        };
        // Loaded anyway: applying it must be refused, and that strength must
        // not reach the wheel.
        let (backend, written) = scripted_backend(vec![(SMARTSHIFT_ENHANCED, 0x01)], wheel_with_tunable_torque);
        let result = set_smartshift(&backend, &direct_route(), loaded).await;
        assert!(
            result.is_err(),
            "a saved strength of {level} must be refused, not applied: {result:?}"
        );
        assert!(
            sent_reports(&written, 0x01, 2).iter().all(|report| report[6] != level),
            "a saved strength of {level} must not be written to the wheel"
        );
    }
}

/// A wheel with tunable torque whose status reply carries a strength above 100
/// makes the status read fail rather than report no strength; a strength of 1
/// or 100 reads back as that level.
#[tokio::test]
async fn tunable_torque_reading_outside_1_to_100_is_an_error() {
    for byte in [1u8, 100, 101, 127, 128, 200, 255] {
        let (backend, _written) = scripted_backend(vec![(SMARTSHIFT_ENHANCED, 0x01)], move |_id, function, _args| {
            match function {
                // getCapabilities: tunable torque.
                0 => Reply::Short([0x01, 20, 50]),
                // getRatchetControlMode: ratchet, threshold 20, the strength byte.
                1 => Reply::Short([0x02, 20, byte]),
                _ => Reply::Error(ERR_UNSUPPORTED),
            }
        });

        let status = get_smartshift_status(&backend, &direct_route()).await;
        if byte <= 100 {
            let status = status.unwrap_or_else(|error| panic!("a strength of {byte} must read back: {error:?}"));
            assert_eq!(
                status.tunable_torque,
                Some(TunableTorque::try_new(byte).unwrap()),
                "a strength of {byte} reads back as that level"
            );
        } else {
            assert!(
                status.is_err(),
                "a strength byte of {byte} must make the read fail, not read as no strength: {status:?}"
            );
        }
    }
}
