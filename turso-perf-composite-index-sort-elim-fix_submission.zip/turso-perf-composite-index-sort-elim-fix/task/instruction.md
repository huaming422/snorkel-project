## Task

on a turso database with a composite (multi-column) index, a query that pins the leading index column(s) with an equality filter and orders by the remaining columns of that same index is far slower than it should be. the answers are correct, only the latency is wrong. on a large table one of these takes hundreds of milliseconds where the same pattern on sqlite finishes in microseconds, a ~7,000x gap. tiny tables hide it; the cost grows with the rows touched, avoidable per-row work on every such query.

make these fast and confirm the win by measurement, without changing what any query returns. `EXPLAIN QUERY PLAN` shows how one actually runs.

be conservative. plenty of queries look like the slow one but their requested order isn't actually guaranteed by the index, and those must keep behaving exactly as today, extra ordering work and all. speed up only the provably safe cases. and keep the fix in how the engine plans and runs queries; you can't add an index, rewrite the query, or change the schema to dodge it.
