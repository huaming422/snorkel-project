#!/usr/bin/env bash
# No services to start and no data to seed. The image already carries the full
# offline dependency closure for the agent phase: the base commit's crate
# registry cache is warm (`cargo fetch --locked`) and the workspace is
# pre-built (`cargo build --locked --workspace --lib --tests`), so the agent's
# and verifier's first build is incremental. Prefer offline so a cache miss
# fails fast rather than hanging on a severed network.
set -euo pipefail

export CARGO_NET_OFFLINE=true

echo "[test-setup] Rust version:    $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:   $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root:  /repo/turso"
echo "[test-setup] CARGO_NET_OFFLINE=${CARGO_NET_OFFLINE}"
echo "[test-setup] Setup complete."
