#!/usr/bin/env bash
# Structural verifier (criterion 8, cross-module consistency): the constraint-model
# change must be applied consistently across the optimizer so the workspace still
# compiles and the pre-existing optimizer unit tests continue to pass. This is a
# guard against a half-applied type change — it exercises the constraint /
# access-method selection call sites through the repo's own unit tests, which are
# pre-existing and not authored here. The image pre-builds the workspace, so this
# run is incremental.
set -euo pipefail

cd /repo/turso

# Run the pre-existing optimizer unit tests. A half-applied change to the
# constraint model fails to compile this crate (reported as a test failure) or
# breaks one of these tests; a consistent change keeps them all green both before
# and after the fix.
cargo test -p turso_core translate::optimizer -- --test-threads=1
