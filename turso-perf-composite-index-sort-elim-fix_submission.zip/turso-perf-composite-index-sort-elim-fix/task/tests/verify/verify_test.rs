// Behavioral verifier for turso-perf-composite-index-sort-elim.
//
// Tests run through the pre-existing public interface used by the repo's own
// integration tests (`core_tester::common::TempDatabase` + a raw
// `turso_core::Connection`): build a schema and composite index, insert rows in
// deliberately non-sorted order, then observe behavior two ways:
//   1. `EXPLAIN QUERY PLAN` plan text (whether an ORDER BY sort step appears).
//   2. Result row order from the same SELECT.
// No optimizer internals are imported and no implementation-invented symbol is
// referenced. The plan annotations asserted here ("USE SORTER FOR ORDER BY",
// "SEARCH ... USING INDEX ...") are stable, pre-existing EXPLAIN QUERY PLAN
// output, not anything the fix introduces.
//
// fail_to_pass functions assert the sort is ABSENT for provably safe shapes:
// they fail on the unfixed base (which still emits the sort) and pass once the
// fix lands. pass_to_pass functions assert the sort is RETAINED for shapes whose
// ordering is not guaranteed by the index: they pass both before and after the
// fix and reject any over-eager "always eliminate" solution.

use std::sync::Arc;

use core_tester::common::TempDatabase;
use turso_core::Connection;

/// Rows of `EXPLAIN QUERY PLAN <sql>`, one string per plan step (detail column).
fn eqp(conn: &Arc<Connection>, sql: &str) -> anyhow::Result<Vec<String>> {
    let mut stmt = conn.prepare(format!("EXPLAIN QUERY PLAN {sql}"))?;
    let mut plans = Vec::new();
    stmt.run_with_row_callback(|row| {
        plans.push(row.get::<String>(3)?);
        Ok(())
    })?;
    Ok(plans)
}

/// Result rows of `<sql>`, each rendered as its column values joined by '|'.
/// NULL renders as the empty string (turso's Value Display), matching the way a
/// NULL-extended outer-join row is observed.
fn rows(conn: &Arc<Connection>, sql: &str) -> anyhow::Result<Vec<String>> {
    let mut stmt = conn.prepare(sql)?;
    let mut out = Vec::new();
    stmt.run_with_row_callback(|row| {
        let line = row
            .get_values()
            .map(|v| v.to_string())
            .collect::<Vec<_>>()
            .join("|");
        out.push(line);
        Ok(())
    })?;
    Ok(out)
}

/// True if any plan step is an ORDER BY sort (normal sorter or the LIMIT heap).
fn has_sorter(plans: &[String]) -> bool {
    plans.iter().any(|p| {
        p.contains("USE SORTER FOR ORDER BY") || p.contains("USE TEMP B-TREE FOR ORDER BY")
    })
}

/// True if any plan step contains `needle`.
fn plan_has(plans: &[String], needle: &str) -> bool {
    plans.iter().any(|p| p.contains(needle))
}

// -------------------------------------------------------------------------
// fail_to_pass: sort is eliminated for provably safe shapes.
// -------------------------------------------------------------------------

/// Criterion 0: equality on the single leading index column, ORDER BY the
/// remaining index columns in the index's declared direction.
#[test]
fn f2p_eq_prefix_order_suffix() -> anyhow::Result<()> {
    let _ = env_logger::try_init();
    let db = TempDatabase::new_empty();
    let conn = db.connect_limbo();
    conn.execute(
        "CREATE TABLE articles (id INTEGER PRIMARY KEY, status TEXT NOT NULL, \
         category TEXT NOT NULL, published_at TEXT NOT NULL, title TEXT NOT NULL)",
    )?;
    conn.execute("CREATE INDEX idx_articles_scp ON articles(status, category, published_at DESC)")?;
    for stmt in ARTICLES_ROWS {
        conn.execute(stmt)?;
    }

    let sql = "SELECT id, category, published_at FROM articles \
               WHERE status = 'published' ORDER BY category, published_at DESC";
    let plans = eqp(&conn, sql)?;
    assert!(
        !has_sorter(&plans),
        "expected no sort step for eq-prefix ORDER BY suffix, got {plans:?}"
    );
    assert!(
        plan_has(&plans, "idx_articles_scp") && plan_has(&plans, "(status=?)"),
        "expected the composite index seek on status, got {plans:?}"
    );
    assert_eq!(
        rows(&conn, sql)?,
        vec![
            "10|art|2024-06-15",
            "2|art|2024-03-01",
            "5|art|2024-01-05",
            "9|science|2024-07-01",
            "6|science|2024-04-12",
            "3|tech|2024-06-10",
            "8|tech|2024-03-22",
            "1|tech|2024-01-15",
        ]
    );
    Ok(())
}

/// Criterion 1: equality on the full leading prefix with ORDER BY on the last
/// index column, and an equality-pinned ORDER BY column with explicit direction.
#[test]
fn f2p_full_prefix_and_pinned_order_column() -> anyhow::Result<()> {
    let _ = env_logger::try_init();
    let db = TempDatabase::new_empty();
    let conn = db.connect_limbo();
    conn.execute(
        "CREATE TABLE articles (id INTEGER PRIMARY KEY, status TEXT NOT NULL, \
         category TEXT NOT NULL, published_at TEXT NOT NULL, title TEXT NOT NULL)",
    )?;
    conn.execute("CREATE INDEX idx_articles_scp ON articles(status, category, published_at DESC)")?;
    for stmt in ARTICLES_ROWS {
        conn.execute(stmt)?;
    }

    // (a) two equalities, ORDER BY the trailing column.
    let sql_a = "SELECT id, published_at FROM articles \
                 WHERE status = 'published' AND category = 'tech' ORDER BY published_at DESC";
    let plans_a = eqp(&conn, sql_a)?;
    assert!(
        !has_sorter(&plans_a),
        "expected no sort step for full-prefix eq, got {plans_a:?}"
    );
    assert!(
        plan_has(&plans_a, "(status=? AND category=?)"),
        "expected the two-column index seek, got {plans_a:?}"
    );
    assert_eq!(
        rows(&conn, sql_a)?,
        vec!["3|2024-06-10", "8|2024-03-22", "1|2024-01-15"]
    );

    // (b) the pinned column itself appears in ORDER BY with a direction; since it
    // is held constant by the equality, that direction is irrelevant.
    let sql_b = "SELECT id, status, category, published_at FROM articles \
                 WHERE status = 'published' ORDER BY status DESC, category, published_at DESC";
    let plans_b = eqp(&conn, sql_b)?;
    assert!(
        !has_sorter(&plans_b),
        "expected no sort step when the ORDER BY leads with the pinned column, got {plans_b:?}"
    );
    assert_eq!(
        rows(&conn, sql_b)?,
        vec![
            "10|published|art|2024-06-15",
            "2|published|art|2024-03-01",
            "5|published|art|2024-01-05",
            "9|published|science|2024-07-01",
            "6|published|science|2024-04-12",
            "3|published|tech|2024-06-10",
            "8|published|tech|2024-03-22",
            "1|published|tech|2024-01-15",
        ]
    );
    Ok(())
}

/// Criterion 2: expression index whose middle column is an expression; the
/// constant prefix lets the ORDER BY on the expression + suffix be satisfied,
/// including when the ordering arises from GROUP BY.
#[test]
fn f2p_expression_index() -> anyhow::Result<()> {
    let _ = env_logger::try_init();
    let db = TempDatabase::new_empty();
    let conn = db.connect_limbo();
    conn.execute(
        "CREATE TABLE expr_articles (id INTEGER PRIMARY KEY, status TEXT NOT NULL, \
         title TEXT NOT NULL, score INTEGER NOT NULL)",
    )?;
    conn.execute(
        "CREATE INDEX idx_expr_articles ON expr_articles(status, lower(title), score DESC)",
    )?;
    for stmt in [
        "INSERT INTO expr_articles VALUES (1, 'active',   'Beta',  7)",
        "INSERT INTO expr_articles VALUES (2, 'active',   'alpha', 3)",
        "INSERT INTO expr_articles VALUES (3, 'active',   'ALPHA', 9)",
        "INSERT INTO expr_articles VALUES (4, 'active',   'gamma', 1)",
        "INSERT INTO expr_articles VALUES (5, 'inactive', 'alpha', 8)",
        "INSERT INTO expr_articles VALUES (6, 'active',   'beta',  2)",
    ] {
        conn.execute(stmt)?;
    }

    // (a) ORDER BY the indexed expression and the trailing column.
    let sql_a = "SELECT id, lower(title), score FROM expr_articles \
                 WHERE status = 'active' ORDER BY lower(title), score DESC";
    let plans_a = eqp(&conn, sql_a)?;
    assert!(
        !has_sorter(&plans_a),
        "expected no sort step for expression-index eq-prefix, got {plans_a:?}"
    );
    assert!(
        plan_has(&plans_a, "idx_expr_articles") && plan_has(&plans_a, "(status=?)"),
        "expected the expression index seek, got {plans_a:?}"
    );
    assert_eq!(
        rows(&conn, sql_a)?,
        vec!["3|alpha|9", "2|alpha|3", "1|beta|7", "6|beta|2", "4|gamma|1"]
    );

    // (b) same prefix skip via GROUP BY on the indexed expression.
    let sql_b = "SELECT lower(title), COUNT(*), MAX(score) FROM expr_articles \
                 WHERE status = 'active' GROUP BY lower(title) ORDER BY lower(title)";
    let plans_b = eqp(&conn, sql_b)?;
    assert!(
        !has_sorter(&plans_b),
        "expected no sort step for GROUP BY on the expression prefix, got {plans_b:?}"
    );
    assert_eq!(
        rows(&conn, sql_b)?,
        vec!["alpha|2|9", "beta|2|7", "gamma|1|1"]
    );
    Ok(())
}

/// Criterion 3: a rowid-table secondary index implicitly ends with rowid, so a
/// pinned index can additionally satisfy a trailing ORDER BY on the rowid alias.
#[test]
fn f2p_rowid_suffix_tiebreak() -> anyhow::Result<()> {
    let _ = env_logger::try_init();
    let db = TempDatabase::new_empty();
    let conn = db.connect_limbo();
    conn.execute(
        "CREATE TABLE ro (id INTEGER PRIMARY KEY, customer_id INTEGER NOT NULL, note TEXT NOT NULL)",
    )?;
    conn.execute("CREATE INDEX idx_ro_customer ON ro(customer_id)")?;
    // Insert out of rowid order so a missing tie-break sort would misorder.
    for stmt in [
        "INSERT INTO ro VALUES (8, 300, 'c')",
        "INSERT INTO ro VALUES (6, 300, 'a')",
        "INSERT INTO ro VALUES (5, 200, 'x')",
        "INSERT INTO ro VALUES (7, 300, 'b')",
    ] {
        conn.execute(stmt)?;
    }

    let sql = "SELECT customer_id, id FROM ro WHERE customer_id = 300 ORDER BY customer_id, id";
    let plans = eqp(&conn, sql)?;
    assert!(
        !has_sorter(&plans),
        "expected no sort step for pinned prefix + trailing rowid, got {plans:?}"
    );
    assert!(
        plan_has(&plans, "idx_ro_customer") && plan_has(&plans, "(customer_id=?)"),
        "expected the index seek on customer_id, got {plans:?}"
    );
    assert_eq!(rows(&conn, sql)?, vec!["300|6", "300|7", "300|8"]);
    Ok(())
}

/// Criterion 4: a LEFT JOIN whose ORDER BY references only the preserved (left)
/// table, with the left table's leading index column pinned by equality.
#[test]
fn f2p_left_join_order_left_only() -> anyhow::Result<()> {
    let _ = env_logger::try_init();
    let db = TempDatabase::new_empty();
    let conn = db.connect_limbo();
    setup_outer_left_order(&conn)?;

    let sql = "SELECT o.customer_id, o.id FROM lhs_orders o \
               LEFT JOIN rhs_items i ON i.order_id = o.id AND i.product = 'x' \
               WHERE o.customer_id = 300 ORDER BY o.customer_id, o.id";
    let plans = eqp(&conn, sql)?;
    assert!(
        !has_sorter(&plans),
        "expected no sort step for LEFT JOIN ordered by the left table only, got {plans:?}"
    );
    assert!(
        plan_has(&plans, "idx_lhs_customer") && plan_has(&plans, "(customer_id=?)"),
        "expected the left-table index seek, got {plans:?}"
    );
    // Outer row id=6 matches two right rows (duplicated), id=7 matches none.
    assert_eq!(rows(&conn, sql)?, vec!["300|6", "300|6", "300|7"]);
    Ok(())
}

// -------------------------------------------------------------------------
// pass_to_pass: sort is retained where ordering is not guaranteed.
// -------------------------------------------------------------------------

/// Criterion 5: the sort MUST be kept for (a) a range constraint on the prefix,
/// (b) no equality prefix with a non-leading ORDER BY, (c) all index columns
/// pinned but ORDER BY on a non-index column.
#[test]
fn p2p_retention_range_noneq_nonindex() -> anyhow::Result<()> {
    let _ = env_logger::try_init();
    let db = TempDatabase::new_empty();
    let conn = db.connect_limbo();
    conn.execute(
        "CREATE TABLE articles (id INTEGER PRIMARY KEY, status TEXT NOT NULL, \
         category TEXT NOT NULL, published_at TEXT NOT NULL, title TEXT NOT NULL)",
    )?;
    conn.execute("CREATE INDEX idx_articles_scp ON articles(status, category, published_at DESC)")?;
    for stmt in ARTICLES_ROWS {
        conn.execute(stmt)?;
    }

    // (a) range on the prefix column.
    let sql_a = "SELECT id, status, category FROM articles \
                 WHERE status >= 'draft' AND status <= 'published' ORDER BY category, id";
    let plans_a = eqp(&conn, sql_a)?;
    assert!(
        has_sorter(&plans_a),
        "range prefix must keep the sort, got {plans_a:?}"
    );
    assert_eq!(
        rows(&conn, sql_a)?,
        vec![
            "2|published|art",
            "5|published|art",
            "7|draft|art",
            "10|published|art",
            "6|published|science",
            "9|published|science",
            "1|published|tech",
            "3|published|tech",
            "4|draft|tech",
            "8|published|tech",
        ]
    );

    // (b) no equality, ORDER BY a non-leading column over a full scan.
    let sql_b = "SELECT id, published_at FROM articles ORDER BY published_at DESC";
    let plans_b = eqp(&conn, sql_b)?;
    assert!(
        has_sorter(&plans_b),
        "full scan with non-leading ORDER BY must keep the sort, got {plans_b:?}"
    );

    // (c) all index columns pinned, ORDER BY a non-index column.
    let sql_c = "SELECT id, title FROM articles \
                 WHERE status = 'published' AND category = 'tech' AND published_at = '2024-03-22' \
                 ORDER BY title";
    let plans_c = eqp(&conn, sql_c)?;
    assert!(
        has_sorter(&plans_c),
        "ORDER BY a non-index column must keep the sort, got {plans_c:?}"
    );
    assert_eq!(rows(&conn, sql_c)?, vec!["8|Theta"]);
    Ok(())
}

/// Criterion 6(a): an equality whose value depends on an outer row in a
/// nested-loop join is not a query-global constant, so the sort is kept.
#[test]
fn p2p_join_dependent_eq_keeps_sort() -> anyhow::Result<()> {
    let _ = env_logger::try_init();
    let db = TempDatabase::new_empty();
    let conn = db.connect_limbo();
    conn.execute(
        "CREATE TABLE orders (id INTEGER PRIMARY KEY, customer_id INTEGER NOT NULL, \
         order_date TEXT NOT NULL, amount REAL NOT NULL)",
    )?;
    conn.execute("CREATE INDEX idx_orders_cust_date ON orders(customer_id, order_date DESC)")?;
    conn.execute(
        "CREATE TABLE items (id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL, \
         product TEXT NOT NULL, qty INTEGER NOT NULL)",
    )?;
    conn.execute("CREATE INDEX idx_items_order ON items(order_id, product)")?;
    for stmt in [
        "INSERT INTO orders VALUES (1, 100, '2024-03-01', 50.0)",
        "INSERT INTO orders VALUES (2, 100, '2024-01-15', 30.0)",
        "INSERT INTO orders VALUES (3, 100, '2024-06-10', 80.0)",
        "INSERT INTO orders VALUES (4, 200, '2024-02-20', 45.0)",
        "INSERT INTO orders VALUES (5, 200, '2024-05-05', 60.0)",
        "INSERT INTO items VALUES (1, 1, 'Widget', 2)",
        "INSERT INTO items VALUES (2, 1, 'Gadget', 1)",
        "INSERT INTO items VALUES (3, 2, 'Widget', 5)",
        "INSERT INTO items VALUES (4, 3, 'Bolt', 10)",
        "INSERT INTO items VALUES (5, 3, 'Widget', 3)",
        "INSERT INTO items VALUES (6, 4, 'Gadget', 7)",
        "INSERT INTO items VALUES (7, 5, 'Bolt', 4)",
    ] {
        conn.execute(stmt)?;
    }

    // items' index leads with order_id, pinned only by the join (join-dependent):
    // ORDER BY i.product cannot be satisfied globally, so the sort stays.
    let sql = "SELECT o.id, i.product, i.qty FROM orders o JOIN items i ON o.id = i.order_id \
               WHERE o.customer_id = 100 ORDER BY i.product, i.qty";
    let plans = eqp(&conn, sql)?;
    assert!(
        has_sorter(&plans),
        "join-dependent equality must not be skipped; sort must stay, got {plans:?}"
    );
    assert_eq!(
        rows(&conn, sql)?,
        vec!["3|Bolt|10", "1|Gadget|1", "1|Widget|2", "3|Widget|3", "2|Widget|5"]
    );
    Ok(())
}

/// Criterion 6(b): a LEFT JOIN whose ORDER BY references the nullable right
/// table keeps the sort, because NULL-extended rows must sort ahead of matches.
#[test]
fn p2p_left_join_nullable_right_keeps_sort() -> anyhow::Result<()> {
    let _ = env_logger::try_init();
    let db = TempDatabase::new_empty();
    let conn = db.connect_limbo();
    conn.execute("CREATE TABLE lhs_groups (id INTEGER PRIMARY KEY, grp INTEGER NOT NULL)")?;
    conn.execute(
        "CREATE TABLE rhs_names (id INTEGER PRIMARY KEY, lhs_id INTEGER NOT NULL, \
         tag TEXT NOT NULL, name TEXT NOT NULL, score INTEGER NOT NULL)",
    )?;
    conn.execute("CREATE INDEX idx_rhs_names ON rhs_names(tag, lower(name), score DESC)")?;
    for stmt in [
        "INSERT INTO lhs_groups VALUES (1, 1)",
        "INSERT INTO lhs_groups VALUES (2, 1)",
        "INSERT INTO rhs_names VALUES (1, 1, 'keep', 'Alice', 9)",
        "INSERT INTO rhs_names VALUES (2, 1, 'keep', 'alice', 3)",
        "INSERT INTO rhs_names VALUES (3, 1, 'skip', 'Bob', 8)",
    ] {
        conn.execute(stmt)?;
    }

    let sql = "SELECT l.id, lower(r.name), r.score FROM lhs_groups l \
               LEFT JOIN rhs_names r ON r.lhs_id = l.id AND r.tag = 'keep' \
               WHERE l.grp = 1 ORDER BY lower(r.name), r.score DESC";
    let plans = eqp(&conn, sql)?;
    assert!(
        has_sorter(&plans),
        "ORDER BY the nullable right table must keep the sort, got {plans:?}"
    );
    // The NULL-extended row (group 2, no 'keep' match) sorts ahead of the matches.
    assert_eq!(rows(&conn, sql)?, vec!["2||", "1|alice|9", "1|alice|3"]);
    Ok(())
}

/// Criterion 7: an equality under one collation does not make an ORDER BY over
/// the same column under a different collation constant, so the sort is kept.
#[test]
fn p2p_collation_mismatch_keeps_sort() -> anyhow::Result<()> {
    let _ = env_logger::try_init();
    let db = TempDatabase::new_empty();
    let conn = db.connect_limbo();
    conn.execute(
        "CREATE TABLE collated_values (a TEXT COLLATE NOCASE NOT NULL, \
         b TEXT COLLATE RTRIM NOT NULL, c TEXT COLLATE BINARY NOT NULL, UNIQUE(a, b, c))",
    )?;
    for stmt in [
        "INSERT INTO collated_values VALUES ('a', 'aa', '1')",
        "INSERT INTO collated_values VALUES ('A', 'zz', '1')",
        "INSERT INTO collated_values VALUES ('a', 'mm', '2')",
        "INSERT INTO collated_values VALUES ('A', 'yy', '2')",
    ] {
        conn.execute(stmt)?;
    }

    // a = 'a' under NOCASE matches both 'a' and 'A'; ORDER BY a COLLATE BINARY
    // must still distinguish them, so the leading term is not constant.
    let sql = "SELECT a, b, c FROM collated_values WHERE a = 'a' \
               ORDER BY a COLLATE BINARY ASC, b COLLATE RTRIM ASC, c ASC, rowid ASC";
    let plans = eqp(&conn, sql)?;
    assert!(
        has_sorter(&plans),
        "collation mismatch must keep the sort, got {plans:?}"
    );
    assert_eq!(
        rows(&conn, sql)?,
        vec!["A|yy|2", "A|zz|1", "a|aa|1", "a|mm|2"]
    );
    Ok(())
}

// -------------------------------------------------------------------------
// Shared fixtures.
// -------------------------------------------------------------------------

/// The 10 articles rows, inserted out of sorted order so a missing sort surfaces
/// as a wrong row order.
const ARTICLES_ROWS: [&str; 10] = [
    "INSERT INTO articles VALUES (1, 'published', 'tech',    '2024-01-15', 'Alpha')",
    "INSERT INTO articles VALUES (2, 'published', 'art',     '2024-03-01', 'Beta')",
    "INSERT INTO articles VALUES (3, 'published', 'tech',    '2024-06-10', 'Gamma')",
    "INSERT INTO articles VALUES (4, 'draft',     'tech',    '2024-02-20', 'Delta')",
    "INSERT INTO articles VALUES (5, 'published', 'art',     '2024-01-05', 'Epsilon')",
    "INSERT INTO articles VALUES (6, 'published', 'science', '2024-04-12', 'Zeta')",
    "INSERT INTO articles VALUES (7, 'draft',     'art',     '2024-05-30', 'Eta')",
    "INSERT INTO articles VALUES (8, 'published', 'tech',    '2024-03-22', 'Theta')",
    "INSERT INTO articles VALUES (9, 'published', 'science', '2024-07-01', 'Iota')",
    "INSERT INTO articles VALUES (10,'published', 'art',     '2024-06-15', 'Kappa')",
];

fn setup_outer_left_order(conn: &Arc<Connection>) -> anyhow::Result<()> {
    conn.execute("CREATE TABLE lhs_orders (id INTEGER PRIMARY KEY, customer_id INTEGER NOT NULL)")?;
    conn.execute("CREATE INDEX idx_lhs_customer ON lhs_orders(customer_id)")?;
    conn.execute(
        "CREATE TABLE rhs_items (id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL, \
         product TEXT NOT NULL, qty INTEGER NOT NULL)",
    )?;
    conn.execute("CREATE INDEX idx_rhs_product_qty ON rhs_items(product, qty)")?;
    for stmt in [
        "INSERT INTO lhs_orders VALUES (6, 300)",
        "INSERT INTO lhs_orders VALUES (7, 300)",
        "INSERT INTO rhs_items VALUES (8, 6, 'x', 2)",
        "INSERT INTO rhs_items VALUES (9, 6, 'x', 1)",
        "INSERT INTO rhs_items VALUES (10, 6, 'y', 9)",
    ] {
        conn.execute(stmt)?;
    }
    Ok(())
}
