## Task

We run user JavaScript in Jint with time, statement, and memory limits. Some large built-in operations still run for several seconds and then crash the host with an out-of-memory error instead of giving the script a catchable failure. An untrusted script must not be able to bring down its host this way.

Please track this down across the affected string and array operations, iterators, object enumeration, and collection callbacks. The configured limits need to interrupt long-running work. A pad request for a string beyond the supported size should give JavaScript a catchable RangeError even without a configured limit. After an interruption, the same engine should still produce correct results on later operations. Keep normal small-input behavior intact.
