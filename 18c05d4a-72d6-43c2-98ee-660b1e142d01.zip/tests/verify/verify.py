"""Behavioral verifier for jint-fix-interruptible-builtins.

Runs under the isolated verifier interpreter (VERIFIER_PYTHON =
/opt/tooling/venv/bin/python). It imports NO repository code — it only shells
out to the repo's own `dotnet test`. Because there is no Python-side repo
import, verify.toml needs no `[pytest] command` override.

Design
------
There is no native C#/.NET verifier runner in ssb_lib, so this Python verifier
drives the repo toolchain directly:

1. A session-scoped fixture copies the xunit test file
   (InterruptibleBuiltinsRewardTests.cs, shipped alongside this file in
   /tests/verify/) into the repo's Jint.Tests project and runs
   `dotnet test ... --filter FullyQualifiedName~InterruptibleBuiltinsRewardTests`
   once, with a TRX logger. The build is incremental and offline (the image
   baked the NuGet closure and a warm Release build; test-setup.sh re-asserted
   the offline restore).
2. The TRX outcomes are parsed into {method_name: passed}.
3. Each pytest gate checks its mapped xunit methods. Grouped gates require all
   mapped methods to pass.

The assertions use public Engine and Evaluate behavior. They do not inspect a
particular check interval or helper name.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

import pytest

REPO_DIR = Path(f"/repo/{os.environ.get('REPO_NAME', 'jint')}")
VERIFY_DIR = Path(__file__).resolve().parent
TEST_CS_NAME = "InterruptibleBuiltinsRewardTests.cs"
# Place the test inside the Jint.Tests project so the SDK's default compile glob
# picks it up. Runtime/ is where the project's constraint tests already live.
DEST_CS = REPO_DIR / "Jint.Tests" / "Runtime" / TEST_CS_NAME
TRX_PATH = REPO_DIR / "Jint.Tests" / "reward_results.trx"
TEST_PROJECT = "Jint.Tests/Jint.Tests.csproj"
FILTER = "FullyQualifiedName~InterruptibleBuiltinsRewardTests"
# Build and native tests have a 780-second inner timeout.
DOTNET_TIMEOUT = 780


@pytest.fixture(scope="session")
def outcomes() -> dict[str, bool]:
    """Compile and run the native tests once; return {method_name: passed}."""
    src = VERIFY_DIR / TEST_CS_NAME
    if not src.exists():
        pytest.fail(f"verifier asset missing: {src}", pytrace=False)
    if not REPO_DIR.exists():
        pytest.fail(f"repo dir not found: {REPO_DIR}", pytrace=False)

    DEST_CS.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, DEST_CS)
    if TRX_PATH.exists():
        TRX_PATH.unlink()

    env = {
        **os.environ,
        "DOTNET_CLI_TELEMETRY_OPTOUT": "1",
        "DOTNET_SKIP_FIRST_TIME_EXPERIENCE": "1",
        "DOTNET_NOLOGO": "1",
        "NUGET_PACKAGES": os.environ.get("NUGET_PACKAGES", "/opt/cache/nuget"),
    }
    cmd = [
        "dotnet", "test", TEST_PROJECT,
        "-c", "Release", "--no-restore",
        "--filter", FILTER,
        "--logger", f"trx;LogFileName={TRX_PATH.name}",
        "--results-directory", str(TRX_PATH.parent),
    ]
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(REPO_DIR),
            env=env,
            capture_output=True,
            text=True,
            timeout=DOTNET_TIMEOUT,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:  # infra/perf problem, not a wrong answer
        pytest.fail(f"dotnet test timed out after {DOTNET_TIMEOUT}s: {exc}", pytrace=False)

    if not TRX_PATH.exists():
        # No TRX => the suite never ran (build break or toolchain failure). Surface
        # the tail of both streams so the cause is visible in runner logs.
        tail = (proc.stdout or "")[-3000:] + "\n--- stderr ---\n" + (proc.stderr or "")[-3000:]
        pytest.fail(
            f"dotnet test produced no TRX (exit {proc.returncode}); build or run failed:\n{tail}",
            pytrace=False,
        )

    results = _parse_trx(TRX_PATH)
    if not results:
        tail = (proc.stdout or "")[-3000:]
        pytest.fail(f"TRX parsed but held zero results (exit {proc.returncode}):\n{tail}", pytrace=False)
    return results


def _parse_trx(path: Path) -> dict[str, bool]:
    """Map each UnitTestResult to {bare_method_name: passed}."""
    root = ET.parse(str(path)).getroot()  # noqa: S314
    # TRX elements are namespaced; match on the local tag name.
    out: dict[str, bool] = {}
    for el in root.iter():
        if el.tag.rsplit("}", 1)[-1] != "UnitTestResult":
            continue
        name = el.get("testName") or ""
        outcome = (el.get("outcome") or "").strip().lower()
        if not name:
            continue
        # testName may be fully qualified; reduce to the bare method name.
        method = name.rsplit(".", 1)[-1].strip()
        out[method] = outcome == "passed"
    return out


def _assert_pass(outcomes: dict[str, bool], *methods: str) -> None:
    missing = [m for m in methods if m not in outcomes]
    assert not missing, f"xunit method(s) not found in TRX (did they fail to compile?): {missing}"
    failed = [m for m in methods if not outcomes[m]]
    assert not failed, f"xunit method(s) did not pass: {failed}"


# Large-operation behavior

def test_rangeerror_on_oversize_pad(outcomes):
    _assert_pass(outcomes, "ShouldThrowRangeErrorWhenPadStartExceedsMaxStringLength", "OversizePadRequestsThrowRangeError")


def test_mem_limit_interrupts_padend(outcomes):
    _assert_pass(outcomes, "ShouldLimitStringSizeForPadEnd", "PadEndNearSizeBoundaryDoesNotCrashHost")


def test_mem_limit_interrupts_array_from(outcomes):
    _assert_pass(outcomes, "ShouldLimitArraySizeForArrayFrom")


def test_stmt_limit_interrupts_array_ops(outcomes):
    # sort's collection loop AND forEach's own loop must both be interruptible.
    _assert_pass(outcomes, "ShouldLimitArraySizeForSort", "ShouldLimitArraySizeForForEach")


def test_join_releases_stack_after_interrupt(outcomes):
    _assert_pass(outcomes, "JoinReleasesJoinStackWhenInterrupted", "ToLocaleStringRecoversAfterInterruption")


def test_breadth_native_callbacks_interruptible(outcomes):
    # Sampled from the sweep beyond the three issue repros: String.raw,
    # native-iterator Array.from, Object.keys enumeration, Map.forEach native cb.
    _assert_pass(
        outcomes,
        "ShouldLimitStringSizeForStringRaw",
        "ShouldLimitArrayFromWithNativeIterator",
        "ShouldLimitObjectKeysForLargeArray",
        "ShouldLimitMapForEachWithNativeCallback",
        "ShouldInterruptSetForEachWithNativeCallback",
    )


# Ordinary-input behavior

def test_timeout_interrupts_large_sort(outcomes):
    _assert_pass(outcomes, "TimeoutInterruptsLargeSort")


def test_pad_correctness(outcomes):
    _assert_pass(outcomes, "PadStartAndPadEndProduceCorrectResults")


def test_small_input_no_false_limit(outcomes):
    _assert_pass(outcomes, "SmallOperationsUnderGenerousBudgetComplete")
