// Public Engine behavior checks for long built-in operations.
using Jint.Constraints;
using Jint.Runtime;

namespace Jint.Tests.Reward;

public class InterruptibleBuiltinsRewardTests
{
    [Fact]
    public void ShouldThrowRangeErrorWhenPadStartExceedsMaxStringLength()
    {
        // Oversize requests must be catchable from JavaScript.
        var engine = new Engine();
        var result = engine.Evaluate(
            "try { 'x'.padStart(2147483647); 'no-throw'; }" +
            " catch (e) { (e instanceof RangeError) ? 'rangeerror' : ('other:' + (e && e.name)); }");
        Assert.Equal("rangeerror", result.AsString());
    }

    [Fact]
    public void OversizePadRequestsThrowRangeError()
    {
        var engine = new Engine();
        foreach (var request in new[] { "'x'.padStart(1200000000)", "'x'.padEnd(1200000000)", "'x'.padStart(2147483648)" })
        {
            var script = $"try {{ {request}; 'no-throw'; }} catch (e) {{ e instanceof RangeError ? 'rangeerror' : 'other'; }}";
            Assert.Equal("rangeerror", engine.Evaluate(script).AsString());
        }
    }

    [Fact]
    public void ShouldLimitStringSizeForPadEnd()
    {
        // This representable request must remain interruptible by the memory limit.
        var engine = new Engine(o => o.LimitMemory(4_000_000));
        Assert.Throws<MemoryLimitExceededException>(() => engine.Evaluate("'x'.padEnd(500000000, 'ab')"));
    }

    [Fact]
    public void PadEndNearSizeBoundaryDoesNotCrashHost()
    {
        var engine = new Engine(o => o.LimitMemory(4_000_000));
        try
        {
            var result = engine.Evaluate("try { 'x'.padEnd(536870911, 'ab'); 'no-throw'; } catch (e) { e instanceof RangeError ? 'rangeerror' : 'other'; }");
            Assert.Equal("rangeerror", result.AsString());
        }
        catch (MemoryLimitExceededException)
        {
            // A supported size can instead reach the configured memory limit.
        }
    }

    [Fact]
    public void ShouldLimitArraySizeForArrayFrom()
    {
        var engine = new Engine(o => o.LimitMemory(4_000_000));
        Assert.Throws<MemoryLimitExceededException>(() => engine.Evaluate("Array.from({ length: 50000000 });"));
    }

    [Fact]
    public void ShouldLimitArraySizeForSort()
    {
        // A low statement budget aborts this operation.
        var engine = new Engine(o => o.MaxStatements(1_000));
        Assert.Throws<StatementsCountOverflowException>(() => engine.Evaluate("new Array(50000000).sort();"));
    }

    [Fact]
    public void ShouldLimitArraySizeForForEach()
    {
        // The sparse array has no callback work that can consume the budget.
        var engine = new Engine(o => o.MaxStatements(1_000));
        Assert.Throws<StatementsCountOverflowException>(() => engine.Evaluate("new Array(50000000).forEach(function () {});"));
    }

    // Fill conversion follows the early return for an already long enough string.
    [Fact]
    public void PadStartEvaluatesFillStringAfterLengthCheck()
    {
        // Per spec (https://tc39.es/ecma262/#sec-stringpad) the fillString is
        // resolved only after the maxLength <= stringLength early return, so its
        // ToString side effect must not run here.
        var engine = new Engine();
        var result = engine.Evaluate(
            "var sideEffect = false;" +
            "var fill = { toString() { sideEffect = true; return '0'; } };" +
            "'abc'.padStart(2, fill);" +
            "sideEffect;");
        Assert.False(result.AsBoolean());
    }

    [Fact]
    public void JoinReleasesJoinStackWhenInterrupted()
    {
        // A later operation on the same array must still return its contents.
        var engine = new Engine(o => o.MaxStatements(10_000_000));
        engine.Evaluate("var a = []; for (var i = 0; i < 20000; i++) a[i] = i;");

        var maxStatements = engine.Constraints.Find<MaxStatementsConstraint>()!;
        maxStatements.MaxStatements = 1;
        engine.Constraints.Reset();
        Assert.Throws<StatementsCountOverflowException>(() => engine.Evaluate("a.join(',')"));

        // Retry on the same engine and array with a larger budget.
        maxStatements.MaxStatements = 10_000_000;
        engine.Constraints.Reset();
        Assert.StartsWith("0,1,2,3,", engine.Evaluate("a.join(',')").AsString());
    }

    [Fact]
    public void ShouldLimitStringSizeForStringRaw()
    {
        var engine = new Engine(o => o.LimitMemory(4_000_000));
        Assert.Throws<MemoryLimitExceededException>(() => engine.Evaluate("String.raw({ raw: { length: 50000000 } });"));
    }

    [Fact]
    public void ShouldLimitArrayFromWithNativeIterator()
    {
        // Native string iteration has no script statements per element.
        var engine = new Engine(o => o.MaxStatements(10_000_000));
        engine.Evaluate("var s = 'x'; for (var i = 0; i < 17; i++) s += s;"); // 131072 chars

        var maxStatements = engine.Constraints.Find<MaxStatementsConstraint>()!;
        maxStatements.MaxStatements = 1;
        engine.Constraints.Reset();
        Assert.Throws<StatementsCountOverflowException>(() => engine.Evaluate("Array.from(s);"));
    }

    [Fact]
    public void ShouldLimitObjectKeysForLargeArray()
    {
        // Object.keys is a pure native enumeration with no JS callback to
        // self-throttle; it must be interruptible during enumeration.
        var engine = new Engine(o => o.MaxStatements(10_000_000));
        engine.Evaluate("var a = []; for (var i = 0; i < 30000; i++) a[i] = i;");

        var maxStatements = engine.Constraints.Find<MaxStatementsConstraint>()!;
        maxStatements.MaxStatements = 1;
        engine.Constraints.Reset();
        Assert.Throws<StatementsCountOverflowException>(() => engine.Evaluate("Object.keys(a);"));
    }

    [Fact]
    public void ShouldLimitMapForEachWithNativeCallback()
    {
        // The native callback has no script statements of its own.
        var engine = new Engine(o => o.MaxStatements(10_000_000));
        engine.Evaluate("var m = new Map(); for (var i = 0; i < 30000; i++) m.set(i, i);");

        var maxStatements = engine.Constraints.Find<MaxStatementsConstraint>()!;
        maxStatements.MaxStatements = 1;
        engine.Constraints.Reset();
        Assert.Throws<StatementsCountOverflowException>(() => engine.Evaluate("m.forEach(Math.max);"));
    }

    [Fact]
    public void ShouldInterruptSetForEachWithNativeCallback()
    {
        var engine = new Engine(o => o.MaxStatements(10_000_000));
        engine.Evaluate("var s = new Set(); for (var i = 0; i < 30000; i++) s.add(i);");
        var limit = engine.Constraints.Find<MaxStatementsConstraint>()!;
        limit.MaxStatements = 1;
        engine.Constraints.Reset();
        Assert.Throws<StatementsCountOverflowException>(() => engine.Evaluate("s.forEach(Math.max);"));
    }

    [Fact]
    public void ToLocaleStringRecoversAfterInterruption()
    {
        var engine = new Engine(o => o.MaxStatements(10_000_000));
        engine.Evaluate("var a = []; for (var i = 0; i < 20000; i++) a[i] = i;");
        var limit = engine.Constraints.Find<MaxStatementsConstraint>()!;
        limit.MaxStatements = 1;
        engine.Constraints.Reset();
        Assert.Throws<StatementsCountOverflowException>(() => engine.Evaluate("a.toLocaleString()"));
        limit.MaxStatements = 10_000_000;
        engine.Constraints.Reset();
        Assert.StartsWith("0,1,2,3,", engine.Evaluate("a.join(',')").AsString());
    }

    [Fact]
    public void TimeoutInterruptsLargeSort()
    {
        var engine = new Engine(o => o.TimeoutInterval(TimeSpan.FromMilliseconds(20)));
        Assert.Throws<TimeoutException>(() => engine.Evaluate("new Array(50000000).sort();"));
    }

    [Fact]
    public void PadStartAndPadEndProduceCorrectResults()
    {
        var engine = new Engine();
        Assert.Equal("005", engine.Evaluate("'5'.padStart(3, '0')").AsString());
        Assert.Equal("500", engine.Evaluate("'5'.padEnd(3, '0')").AsString());
        Assert.Equal("ab", engine.Evaluate("'ab'.padStart(1)").AsString());
        Assert.Equal("    x", engine.Evaluate("'x'.padStart(5)").AsString());
        Assert.Equal("x    ", engine.Evaluate("'x'.padEnd(5)").AsString());
        // Empty fill string returns the input unchanged.
        Assert.Equal("x", engine.Evaluate("'x'.padEnd(5, '')").AsString());
        Assert.Equal("1231231abc", engine.Evaluate("'abc'.padStart(10, '123')").AsString());
        Assert.Equal("abc1231231", engine.Evaluate("'abc'.padEnd(10, '123')").AsString());
    }

    [Fact]
    public void SmallOperationsUnderGenerousBudgetComplete()
    {
        // Ordinary small operations under a generous statement budget must still
        // complete and return correct values.
        var engine = new Engine(o => o.MaxStatements(1_000_000));
        Assert.Equal("1231231abc", engine.Evaluate("'abc'.padStart(10, '123')").AsString());
        Assert.Equal("1,2,3", engine.Evaluate("[1, 2, 3].join(',')").AsString());
        Assert.Equal("x    ", engine.Evaluate("'x'.padEnd(5)").AsString());
    }
}
