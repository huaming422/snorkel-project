#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
# No assertion logic here — just bring the baked NuGet closure online so the
# verifier's `dotnet test` is an offline, incremental compile.
cd /repo/jint

# Offline switches: a NuGet cache miss must fail fast instead of reaching the
# network. The image baked the full package closure at the base commit
# (Directory.Packages.props is centrally pinned), so a restore here resolves entirely from /opt/cache/nuget.
export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1
export DOTNET_NOLOGO=1
export NUGET_PACKAGES=/opt/cache/nuget

# Dependencies: offline-first against the image bake, logged online fallback.
# A single dependency-resolving command per ecosystem (the elif is the same
# command retried online, not a second independent resolve).
if dotnet restore Jint.Tests/Jint.Tests.csproj --source /opt/cache/nuget \
        > /tmp/test-setup-restore.log 2>&1; then
    echo "[offline-first] NuGet closure satisfied from image"
elif dotnet restore Jint.Tests/Jint.Tests.csproj >> /tmp/test-setup-restore.log 2>&1; then
    echo "[test-setup] NuGet restored online (image bake was stale)"
else
    tail -60 /tmp/test-setup-restore.log >&2; exit 1
fi
