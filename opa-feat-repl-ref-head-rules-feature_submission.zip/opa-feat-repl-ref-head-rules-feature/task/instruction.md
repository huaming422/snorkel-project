## Task

OPA's interactive REPL, the prompt from `opa run`, lets you define a rule by
typing an assignment such as `a := 1` and query it by typing `a`. That works
when you assign a whole value at once.

What it won't do yet is let you build a document one key at a time. Type an
assignment targeting a single key or a dotted path, such as `a[0] := 1` or
`p.q.r := 1`, and the prompt treats the line as a query: nothing is stored, and
asking for the value afterwards comes back undefined. Inside a policy file this
is ordinary, so the prompt refusing it is a surprise.

We would like to close that gap, for both key and dotted-path assignment, and
have `unset` follow the same shape so you can drop an individual key or path by
naming it.

One boundary to hold onto: statements rooted at `data` or `input`, such as
`data.foo.bar = 1`, ask whether the store already holds that value, and must
keep evaluating as queries rather than quietly becoming definitions.

## User stories / requirements

- In an interactive `opa run` session, defining a document key by key (for example `a[0] := 1` then `a[1] := 2`) and then querying `a` returns a document that holds both keys.
- In an interactive `opa run` session, after building up a document key by key, removing one key by naming it leaves the document's other keys in place, and the later query of the name reflects the removal.
