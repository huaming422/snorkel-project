// Behavioral checks for interactive ref-head rule definitions in the Rego REPL.
//
// Everything is observed through the PRE-EXISTING, STABLE public surface:
//
//	repl.New(store, "", &buf, "", 0, "").WithStderrWriter(&buf)
//	(*REPL).OneShot(ctx, line)
//
// and the exact text the REPL prints to that buffer. This file lives in an
// external `repl_test` package and NEVER references internal helpers, head
// fields, or parser flags — only the observable REPL output a user sees at the
// prompt. Implementations are free to factor the ref-extraction, the
// document-already-defined check, and the rego-v1 body exemption however they
// like; these checks care only about the printed behavior.
package repl_test

import (
	"bytes"
	"context"
	"testing"

	"github.com/open-policy-agent/opa/v1/repl"
	"github.com/open-policy-agent/opa/v1/storage/inmem"
)

// newRepl builds a REPL over a fresh in-memory store that writes both its
// normal output and its stderr into the single buffer the checks read.
func newRepl(buf *bytes.Buffer) *repl.REPL {
	return repl.New(inmem.New(), "", buf, "", 0, "").WithStderrWriter(buf)
}

// expectExact drives one line and asserts the buffer holds exactly want.
func expectExact(t *testing.T, r *repl.REPL, buf *bytes.Buffer, line, want string) {
	t.Helper()
	buf.Reset()
	if err := r.OneShot(context.Background(), line); err != nil {
		t.Fatalf("%q: unexpected error: %v", line, err)
	}
	if got := buf.String(); got != want {
		t.Fatalf("%q: expected output %#v but got %#v", line, want, got)
	}
}

// expectError drives one line and asserts it fails and defines nothing.
func expectError(t *testing.T, r *repl.REPL, buf *bytes.Buffer, line string) {
	t.Helper()
	buf.Reset()
	if err := r.OneShot(context.Background(), line); err == nil {
		t.Fatalf("%q: expected an error but got output: %q", line, buf.String())
	}
}

// Assigning to a numeric or string key defines a partial-object rule whose
// name is the full ref, and querying the name shows the single-key document.
func TestVerifyPartialObjectDefine(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)

	expectExact(t, r, &buf, `a[0] := 1`,
		"Rule 'a[0]' defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r, &buf, `a`, "{\n  \"0\": 1\n}\n")

	var buf2 bytes.Buffer
	r2 := newRepl(&buf2)
	expectExact(t, r2, &buf2, `a["foo"] := "bar"`,
		"Rule 'a.foo' defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r2, &buf2, `a`, "{\n  \"foo\": \"bar\"\n}\n")
}

// Distinct keys accumulate in one document; re-assigning a key replaces only
// that key (and prints a re-defined line); assigning the whole name replaces
// the entire document with the new value.
func TestVerifyKeysAccumulateAndReplace(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)

	expectExact(t, r, &buf, `a[0] := 1`,
		"Rule 'a[0]' defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r, &buf, `a[1] := 2`,
		"Rule 'a[1]' defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r, &buf, `a`, "{\n  \"0\": 1,\n  \"1\": 2\n}\n")

	expectExact(t, r, &buf, `a[0] := 3`,
		"Rule 'a[0]' re-defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r, &buf, `a`, "{\n  \"0\": 3,\n  \"1\": 2\n}\n")

	expectExact(t, r, &buf, `a := 2`,
		"Rule 'a' re-defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r, &buf, `a`, "2\n")
}

// Dotted ref heads build a nested document; assigning sibling dotted paths
// accumulates under the shared prefix.
func TestVerifyDottedRefDefine(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)

	expectExact(t, r, &buf, `p.q.r := 1`,
		"Rule 'p.q.r' defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r, &buf, `p.q.s := 2`,
		"Rule 'p.q.s' defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r, &buf, `p`, "{\n  \"q\": {\n    \"r\": 1,\n    \"s\": 2\n  }\n}\n")
}

// Statements rooted at a root document stay queries: they evaluate (to
// undefined here) and leave the module with no rules. This behavior holds on
// an unmodified tree and must keep holding for a correct implementation.
func TestVerifyDataInputStayQueries(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)
	expectExact(t, r, &buf, `data.foo.bar = 1`, "undefined\n")
	expectExact(t, r, &buf, `show`, "no rules defined\n")

	var buf2 bytes.Buffer
	r2 := newRepl(&buf2)
	expectExact(t, r2, &buf2, `input.foo.bar = 1`, "undefined\n")
	expectExact(t, r2, &buf2, `show`, "no rules defined\n")
}

// An equality statement about an already-defined document is a query, not a
// re-definition: it reports truth, undefinedness, or enumerates matching keys,
// and never re-defines the rule.
func TestVerifyEqAboutDefinedIsQuery(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)

	expectExact(t, r, &buf, `p.q.r := 1`,
		"Rule 'p.q.r' defined in package repl. Type 'show' to see rules.\n")
	expectExact(t, r, &buf, `p.q.r = 1`, "true\n")
	expectExact(t, r, &buf, `p.q.r = 2`, "undefined\n")
	expectExact(t, r, &buf, `p.q[i] = 1`,
		"┌─────┐\n│  i  │\n├─────┤\n│ \"r\" │\n└─────┘\n")
}

// An assignment whose key is an unbound variable is unsafe: it errors and
// defines nothing. Safety is unchanged by the feature and must stay enforced.
func TestVerifyUnsafeKeyRejected(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)
	expectError(t, r, &buf, `a[i] := 1`)
}

// The unset command identifies rules by ref: unsetting a key leaves the other
// keys, unsetting a prefix removes everything under it, and unsetting an
// already-removed ref warns. A non-ground selector matches no concrete rule, so
// it must leave surviving rules intact (whether it errors or warns is the
// implementation's call).
func TestVerifyUnsetByRef(t *testing.T) {
	var buf bytes.Buffer
	r := newRepl(&buf)

	for _, line := range []string{`a[0] := 1`, `a[1] := 2`, `foo.bar.baz if true`} {
		buf.Reset()
		if err := r.OneShot(context.Background(), line); err != nil {
			t.Fatalf("%q: unexpected error: %v", line, err)
		}
	}

	// Unsetting one key leaves the rest of the document in place.
	buf.Reset()
	if err := r.OneShot(context.Background(), `unset a[0]`); err != nil {
		t.Fatalf("unset a[0]: unexpected error: %v", err)
	}
	expectExact(t, r, &buf, `a`, "{\n  \"1\": 2\n}\n")

	// Unsetting a prefix removes all rules under it; after clearing every rule
	// show prints just the package line.
	buf.Reset()
	if err := r.OneShot(context.Background(), `unset a`); err != nil {
		t.Fatalf("unset a: unexpected error: %v", err)
	}
	if err := r.OneShot(context.Background(), `unset foo.bar.baz`); err != nil {
		t.Fatalf("unset foo.bar.baz: unexpected error: %v", err)
	}
	expectExact(t, r, &buf, `show`, "package repl\n")

	// Unsetting an already-removed ref warns rather than erring.
	expectExact(t, r, &buf, `unset foo.bar.baz`,
		"warning: no matching rules in current module\n")

	// A non-ground unset selector sits outside the remove-by-ref contract: the
	// only guarantee is that it must not remove or corrupt a surviving rule.
	// Define a fresh key, attempt the non-ground unset, and accept either
	// outcome the REPL may reasonably choose for an argument that matches no
	// concrete rule — a hard error, or the pre-existing no-match warning — so
	// long as the surviving key is left intact and unchanged.
	expectExact(t, r, &buf, `a[0] := 1`,
		"Rule 'a[0]' defined in package repl. Type 'show' to see rules.\n")
	buf.Reset()
	_ = r.OneShot(context.Background(), `unset a[x]`)
	expectExact(t, r, &buf, `a`, "{\n  \"0\": 1\n}\n")
}
