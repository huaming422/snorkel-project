#!/usr/bin/env bash
#
# Sourced by the Staff-Bench verifier runner before tests execute (sourced, not
# exec'd, so exported env sticks).
#
# Everything heavy lives in the Dockerfile: the Go toolchain (1.27.2), the warm
# module cache (GOMODCACHE=/opt/cache/go) and the warm build cache
# (GOCACHE=/opt/cache/go-build), both resolved at the pre-fix commit. The oracle
# does not change go.mod/go.sum, so the module graph is already complete offline.
# This script only pins the environment the Go verifier and the `opa run`
# validation story need, and rebuilds the module/build caches' export paths if an
# agent `git clean -fdx` disturbed PATH.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/opa}"
cd "$REPO_DIR"

# Deterministic Go toolchain behavior. GOTOOLCHAIN=local keeps `go` from trying
# to fetch a newer toolchain (go.mod declares `go 1.25.0`; the installed 1.27.2
# satisfies it). These mirror the image ENV and are re-exported in case the
# harness scrubbed the environment.
export GOFLAGS="${GOFLAGS:--mod=mod}"
export CGO_ENABLED="${CGO_ENABLED:-1}"
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"
export GOPATH="${GOPATH:-/root/go}"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"
mkdir -p "$GOMODCACHE" "$GOCACHE"

# Make `go` reachable even if the harness scrubbed PATH.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

# The Python verifier orchestrator (if used) needs pytest; it is baked into the
# isolated /opt/tooling venv, so this is normally a no-op. The verifier routes
# through VERIFIER_PYTHON; no second ad-hoc install here.

echo "test-setup.sh: ready (go $(go version 2>/dev/null | awk '{print $3}'), GOMODCACHE=$GOMODCACHE)"
