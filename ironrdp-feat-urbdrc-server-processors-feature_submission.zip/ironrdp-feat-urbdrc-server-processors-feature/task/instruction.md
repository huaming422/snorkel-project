## Task

The `ironrdp-rdpeusb` crate does MS-RDPEUSB USB-device redirection, but only the client half ships today. We want the server side: URBDRC server processors so an application can drive USB redirection from the server end, mirroring the client processors the crate already has. That means a control-side processor and a per-device processor.

Wire them into the DVC server stack through the pre-existing `DvcProcessor` and `DvcServerProcessor` traits, the same ones the client side implements. The public surface should mirror the client's: a control-server type with its backend trait and a per-device-server type with its backend trait, so an application drives the server and takes device I/O completions through those backends.

While you're in here, pull the backend-facing I/O data model, the request types and the completion-result types, into something shared by both client and server. Treat it as a real system boundary worth designing well, not server-specific types bolted on beside the client's.

Follow the MS-RDPEUSB specification for the message sequencing rather than inventing the flow. Keep the work inside the crate, and leave the client's observable wire behavior unchanged.

## User stories / requirements

- On a fresh connection the control server kicks off the RDPEUSB capability exchange and channel setup itself, answering each step with the right response until it reaches a ready state. Starting it is what emits the initial capability request, and once ready it hands off provisioning of a device channel to its backend.
- When the per-device server is told a device has been added, it registers that device with its backend and sends the setup messages that ready it for I/O, doing so only once even if the same addition repeats. Each I/O request it then issues gets its own identifier and stays outstanding until the matching completion comes back, which is delivered to the backend callback waiting on it. A no-acknowledgement OUT transfer instead leaves nothing outstanding, because no completion is coming.
