#!/usr/bin/env bash
# Validation environment setup for ironrdp-feat-urbdrc-server-processors.
#
# Runs after tests/test-setup.sh and before the validation agent writes its
# story test files. The cargo-test driver injects, alongside each story's test
# file, a `validation_params.rs` helper into `crates/ironrdp-rdpeusb/tests/`.
# That helper uses `serde` (derive) and `serde_json` to parse the immutable
# params file, and the story tests themselves read expected values via
# `serde_json`. `ironrdp-rdpeusb` declares NEITHER as a dependency, and an
# integration test under `tests/` only sees the crate's normal dependencies
# plus its DEV-dependencies — so we add serde + serde_json as dev-deps here.
#
# The crate's normal deps (ironrdp-core / ironrdp-pdu / ironrdp-dvc /
# ironrdp-str) are already visible to an integration test, so nothing else is
# needed: the stories build and decode PDUs through those existing crates.
#
# Internet is enabled for validation setup, and serde_json 1.0.150 + serde are
# already pinned in the workspace Cargo.lock, so resolution is offline-safe and
# trivial. Idempotent: safe to re-run; preserves any dev-deps already declared.
set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/ironrdp}"
cd "$REPO_DIR"

# Honor the image's canonical toolchain/cache locations (match the Dockerfile),
# falling back only if the environment did not already set them.
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export PATH="$CARGO_HOME/bin:$PATH"

CARGO_MANIFEST="crates/ironrdp-rdpeusb/Cargo.toml"
if [ ! -f "$CARGO_MANIFEST" ]; then
  # Should never happen — the crate exists at the base commit — but fail loud
  # rather than silently skip, so a broken checkout surfaces here.
  echo "validation-setup.sh: FATAL: $CARGO_MANIFEST not found in $REPO_DIR" >&2
  exit 1
fi

# Preferred path: `cargo add` edits the manifest cleanly and leaves any existing
# dev-dependencies untouched. Fall back to an idempotent text append if
# `cargo add` is unavailable or fails (e.g. offline-registry edge cases).
added_via_cargo=1
cargo add --quiet --dev --package ironrdp-rdpeusb serde --features derive 2>/dev/null || added_via_cargo=0
if [ "$added_via_cargo" = "1" ]; then
  cargo add --quiet --dev --package ironrdp-rdpeusb serde_json 2>/dev/null || added_via_cargo=0
fi

if [ "$added_via_cargo" != "1" ]; then
  echo "validation-setup.sh: 'cargo add' unavailable/failed; appending dev-deps to $CARGO_MANIFEST."
  if ! grep -q '^\[dev-dependencies\]' "$CARGO_MANIFEST"; then
    printf '\n[dev-dependencies]\n' >> "$CARGO_MANIFEST"
  fi
  grep -q '^serde ' "$CARGO_MANIFEST" || echo 'serde = { version = "1", features = ["derive"] }' >> "$CARGO_MANIFEST"
  grep -q '^serde_json ' "$CARGO_MANIFEST" || echo 'serde_json = "1"' >> "$CARGO_MANIFEST"
fi

echo "validation-setup.sh: serde + serde_json dev-deps ensured on ironrdp-rdpeusb."

# Warm the crate's test build so the first story compiles fast. The lib sets
# `test = false`, but integration tests under tests/ still build; `--tests`
# compiles the crate (and its dev-deps) in test configuration, caching the
# heavy workspace build before the validation agent's per-story cargo runs.
cargo build -p ironrdp-rdpeusb --tests

echo "validation-setup.sh: ironrdp-rdpeusb test build warmed."
