#!/usr/bin/env bash
# Verifier-side setup: runs before the verifier. The image already installed the
# Rust toolchain, warmed the cargo registry, and pre-built the workspace at the
# base commit; this just re-exports the toolchain paths (a fresh shell per phase
# does not inherit the Dockerfile's ENV) and confirms the toolchain is present.
set -euo pipefail

# Match the environment image's layout (see image/Dockerfile block 0/3).
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export PATH="$CARGO_HOME/bin:$PATH"

# Sanity check: the toolchain must be present (baked into the image).
rustc --version >/dev/null 2>&1 || {
    echo "ERROR: rustc not found on PATH (CARGO_HOME=$CARGO_HOME)" >&2
    exit 1
}
cargo --version >/dev/null 2>&1 || {
    echo "ERROR: cargo not found on PATH" >&2
    exit 1
}

echo "test-setup: rustc=$(rustc --version), cargo=$(cargo --version | head -1)"
