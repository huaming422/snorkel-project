#!/usr/bin/env bash
# Environment bootstrap for the verifier. Sourced (not exec'd) so env
# vars set here stay live for the verifier subprocess.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/core}"
export REPO_DIR
cd "$REPO_DIR"

# The runner parses verify.toml via tomllib. The canonical verifier venv
# (VERIFIER_PYTHON=/opt/tooling/venv/bin/python, Python 3.12) ships tomllib in
# the stdlib, so no install is needed there. If the runner ever falls back to a
# pre-3.11 system python3 that lacks both tomllib and tomli, verify.toml would
# be dropped and the vitest runner config lost - warn loudly so that failure
# mode is diagnosable rather than silent.
if ! python3 -c "import tomllib" >/dev/null 2>&1 && \
   ! python3 -c "import tomli"   >/dev/null 2>&1; then
    echo "test-setup.sh: WARNING - system python3 lacks tomllib/tomli; " \
         "verify.toml may be ignored. Verifier runs under VERIFIER_PYTHON " \
         "(/opt/tooling/venv, Python 3.12) which has tomllib." >&2
fi

# vitest must be resolvable from the workspace root. The image bakes the full
# frozen-lockfile install, so this is present offline; a miss means a corrupted
# node_modules. Reinstall offline-first (store is warm at /opt/cache/pnpm) and
# log the online fallback.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/ - " \
         "node_modules looks corrupt; reinstalling from the frozen lockfile." >&2
    pnpm install --frozen-lockfile --offline \
        || { echo "test-setup.sh: offline reinstall failed; retrying online." >&2; \
             pnpm install --frozen-lockfile; }
fi

# ---------------------------------------------------------------------------
# Standalone, auto-discovered vitest config for the verifier.
#
# The JS runner runs `npx vitest run <verify.test.ts>` from REPO_DIR/.verifier-run
# with NO --config and NO --environment flag, so vitest auto-loads the config it
# finds walking up from that cwd. The repo's ROOT vitest.config.ts uses a
# `projects` array whose only vapor-matching project (`unit-jsdom`) includes
# `*.spec.ts` ONLY; a `verify*.test.ts` matches no project there and discovers
# zero tests (scored as an infra failure). We therefore drop a single-config
# vitest.config.ts in REPO_DIR/.verifier-run that:
#   - sets `root` back to REPO_DIR so setupFiles + package sources resolve,
#   - reuses the repo's shared @vue/* -> packages/*/src aliases (scripts/aliases.js),
#   - runs under jsdom with globals + scripts/setup-vitest.ts (registers the
#     `toHaveBeenWarned` matcher the null-key test asserts, and the afterEach
#     that throws on any stray console.warn),
#   - replays the root config's __DEV__/__TEST__/... define block (runtime-vapor
#     source is guarded by these compile-time flags),
#   - includes only packages/runtime-vapor/**/*.test.ts; the repo's own specs
#     are *.spec.ts, so this glob matches nothing but the injected verifier,
#     and the runner's positional path narrows it to exactly that file.
# Idempotent: only written if absent.
# ---------------------------------------------------------------------------
mkdir -p "$REPO_DIR/.verifier-run"
if [ ! -f "$REPO_DIR/.verifier-run/vitest.config.ts" ]; then
    cat > "$REPO_DIR/.verifier-run/vitest.config.ts" <<'EOF'
import { fileURLToPath } from 'node:url'
import { defineConfig } from 'vitest/config'
import { entries } from '../scripts/aliases.js'

const repoRoot = fileURLToPath(new URL('..', import.meta.url))

export default defineConfig({
  define: {
    __DEV__: true,
    __TEST__: true,
    __VERSION__: '"test"',
    __BROWSER__: false,
    __GLOBAL__: false,
    __ESM_BUNDLER__: true,
    __ESM_BROWSER__: false,
    __CJS__: true,
    __SSR__: true,
    __BENCHMARK__: false,
    __FEATURE_OPTIONS_API__: true,
    __FEATURE_SUSPENSE__: true,
    __FEATURE_PROD_DEVTOOLS__: false,
    __FEATURE_PROD_HYDRATION_MISMATCH_DETAILS__: false,
    __COMPAT__: true,
  },
  resolve: {
    alias: entries,
  },
  test: {
    root: repoRoot,
    globals: true,
    environment: 'jsdom',
    pool: 'threads',
    setupFiles: 'scripts/setup-vitest.ts',
    sequence: {
      hooks: 'list',
    },
    include: ['packages/runtime-vapor/**/*.test.ts'],
  },
})
EOF
fi

# runtime-vapor specs import directly from the package source (../../src) and
# @vue/runtime-dom via the shared aliases, so no dist/ rebuild is needed for the
# implementation change to be visible to the verifier.

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
