## Task

In Vapor mode, template refs on a `<component :is="...">` don't follow the component when it changes.
Bind a string ref, a `useTemplateRef` ref or a function ref, switch `is` to another component, and the ref still holds the first child's exposed value.
If the dynamic component renders a regular non-Vapor component, the ref comes back `undefined` instead of that component's exposed value.
Async components hit the same problems, including when the bound ref changes after the component has loaded.

Whenever the child or the bound ref changes, the old target should be cleared before the new value lands.
A ref goes back to `null`, and a function ref gets called with `null`.
One switch should give a function ref that cleanup call and the new child, no matter how many times the parent re-rendered before it.
For refs inside `v-for`, only the entry for the component that switched should change, and the other entries stay put.

A dynamic `:ref` whose value turns `null` or `undefined` logs an "Invalid template ref type" warning in dev today.
It shouldn't warn at all, it should just clear whatever that ref pointed at before, on plain elements as well as components.

Static refs work fine today and need to keep working, and the way refs are declared in templates stays the same.
