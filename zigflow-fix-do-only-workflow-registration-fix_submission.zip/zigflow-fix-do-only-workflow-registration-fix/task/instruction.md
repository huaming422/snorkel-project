## Task

We run a lot of our automation as zigflow workflows, and some of them just hang
and never finish. It happens when a workflow has parts that run on their own: a
`fork` with parallel branches, a `switch` that redirects to another part of the
document, or a file that defines more than one workflow. The plain top-to-bottom
sequences run fine, but these ones start and then sit there, and the worker logs
show a Temporal error about being "unable to find workflow type".

Can you dig into why these workflows hang and get them running to completion the
way the simple sequences already do?
