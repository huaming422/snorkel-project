#!/usr/bin/env bash
#
# Verifier environment bootstrap. Sourced (not exec'd) by the harbor runner so
# any env we export stays live for the verifier subprocess. The image already
# bakes the full module + build cache at the pre-fix commit, so this is a
# near-noop on a warm image and only re-materialises a wiped layer.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/zigflow}"
cd "$REPO_DIR"

# Make `go` reachable even if the harness scrubbed PATH, and re-assert the
# build env the image set (a freshly-spawned shell may not inherit image ENV).
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac
export GOFLAGS=-mod=mod
export GOTOOLCHAIN=local
export CGO_ENABLED=1

# The verifier harness glue runs under VERIFIER_PYTHON (the canonical
# /opt/tooling/venv), which already carries pytest and the verifier pins baked
# into the image — nothing to install here.

# Offline-first module fetch. The image pre-warmed the module cache at the
# pre-fix commit and the fix introduces no new dependency, so this resolves
# entirely from cache with the network off. The online path is a logged
# fallback only for a wiped-layer recovery.
if ! GOPROXY=off go mod download 2>/dev/null; then
    echo "test-setup.sh: offline module fetch missed cache; retrying online" >&2
    go mod download || echo "test-setup.sh: WARNING go mod download failed" >&2
fi

# Prewarm the package under test so the verifier's first `go test` is fast.
GOPROXY=off go build ./pkg/zigflow/... 2>/dev/null || true

echo "test-setup.sh: ready (GOFLAGS=$GOFLAGS, GOTOOLCHAIN=$GOTOOLCHAIN)"
