## Task

long conversations are getting stuck during history compaction. once a conversation has been chaining its responses through one upstream account, and that account is shut out for exceeding its usage limits, the next request to compact its history fails outright: the client gets a rate-limit / unavailable error instead of a compacted history, and retrying keeps hitting that same exhausted account until its limit resets. the client is stuck right when it needs to shrink its history.

ordinary turns don't behave this way: when the account that owned the prior turn is unavailable, a normal turn carries on against a healthy account. it's specifically compaction that can't do that.

make an affected compaction request recover on its own and continue on a healthy account, rather than failing until the exhausted account's quota resets. recovery has to be safe: a conversation must never move onto a different account where that could mishandle or corrupt its continuity, and where it can't be done safely the request should still fail. keep this scoped to compaction; don't rework account selection, retry, or failover elsewhere.
