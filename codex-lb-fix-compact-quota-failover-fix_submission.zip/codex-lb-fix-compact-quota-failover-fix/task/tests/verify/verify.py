"""Behavioral verifier for the compaction account-recovery fix.

Everything is exercised end-to-end through the public compaction endpoint
(``POST /backend-api/codex/responses/compact``) over the repository's own
``async_client`` fixture. The only internal surfaces touched are the same
pre-existing seams the repository's integration suite already uses:

* ``app.modules.proxy.service.core_compact_responses`` — the module-level
  upstream-call function every compaction test monkeypatches to record which
  account each send targets and with what payload.
* ``ProxyService._resolve_websocket_previous_response_owner`` — monkeypatched
  to pin a resolved previous-response owner.
* ``ProxyService._resolve_compact_turn_state_owner`` — monkeypatched to add a
  second ownership pin for the additional-pin case.
* ``Account.status`` set directly on the row, plus the account-selection cache
  invalidation, to mark an account usage-limited.

No symbol introduced by the fix is imported or referenced. Recovery is observed
purely as an outcome: the HTTP status, the ordered sequence of accounts the
upstream send targeted, and whether the replayed payload still carries the
previous-response anchor. This keeps the verifier neutral about HOW the fix is
structured (inline vs helpers, gate ordering, internal reason strings).
"""

from __future__ import annotations

import base64
import json
import logging
from datetime import timezone
from typing import cast

import pytest

import app.modules.proxy.service as proxy_module
from app.core.auth import generate_unique_account_id
from app.core.clients.proxy import ProxyResponseError
from app.core.errors import openai_error
from app.core.openai.models import CompactResponsePayload
from app.core.utils.time import utcnow
from app.db.models import Account, AccountStatus
from app.db.session import SessionLocal
from app.modules.api_keys.repository import ApiKeysRepository
from app.modules.api_keys.service import ApiKeyCreateData, ApiKeysService
from app.modules.proxy.account_cache import get_account_selection_cache

pytestmark = pytest.mark.integration

COMPACT_URL = "/backend-api/codex/responses/compact"

# A self-contained, account-neutral full resend: user turn, the prior
# assistant output, then the fresh client turn that asks for compaction. This
# is the shape a client that holds its own full local history would send when
# abandoning an unavailable owner.
_NEUTRAL_FULL_RESEND_INPUT: list[dict[str, object]] = [
    {"role": "user", "content": "hello"},
    {"role": "assistant", "content": [{"type": "output_text", "text": "hi there"}]},
    {"role": "user", "content": "please compact"},
]


def _encode_jwt(payload: dict) -> str:
    raw = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    body = base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")
    return f"header.{body}.sig"


def _make_auth_json(account_id: str, email: str, *, plan_type: str = "plus") -> dict:
    payload = {
        "email": email,
        "chatgpt_account_id": account_id,
        "https://api.openai.com/auth": {"chatgpt_plan_type": plan_type},
    }
    return {
        "tokens": {
            "idToken": _encode_jwt(payload),
            "accessToken": "access-token",
            "refreshToken": "refresh-token",
            "accountId": account_id,
        },
    }


async def _import_account(async_client, *, email: str, raw_account_id: str) -> str:
    auth_json = _make_auth_json(raw_account_id, email)
    files = {"auth_json": ("auth.json", json.dumps(auth_json), "application/json")}
    response = await async_client.post("/api/accounts/import", files=files)
    assert response.status_code == 200, response.text
    return generate_unique_account_id(raw_account_id, email)


async def _mark_account_status(account_id: str, status: AccountStatus) -> None:
    async with SessionLocal() as session:
        account = await session.get(Account, account_id)
        assert account is not None
        account.status = status
        if status in (AccountStatus.RATE_LIMITED, AccountStatus.QUOTA_EXCEEDED):
            account.reset_at = int(utcnow().replace(tzinfo=timezone.utc).timestamp()) + 3600
        await session.commit()
    get_account_selection_cache().invalidate()


async def _create_api_key(*, name: str, assigned_account_ids: list[str] | None = None) -> tuple[str, str]:
    async with SessionLocal() as session:
        service = ApiKeysService(ApiKeysRepository(session))
        created = await service.create_key(
            ApiKeyCreateData(name=name, allowed_models=None, assigned_account_ids=assigned_account_ids)
        )
    return created.id, created.key


def _pin_previous_response_owner(monkeypatch, owner_account_id: str) -> None:
    async def fake_owner(self, *, previous_response_id, api_key, session_id=None, surface, **kwargs):
        del self, previous_response_id, api_key, session_id, surface, kwargs
        return owner_account_id

    monkeypatch.setattr(proxy_module.ProxyService, "_resolve_websocket_previous_response_owner", fake_owner)


def _recording_compact(
    calls: list[tuple[str | None, dict[str, object], dict[str, str]]],
    *,
    fail_accounts_with: dict[str, ProxyResponseError] | None = None,
):
    async def fake_compact(payload, headers, access_token, account_id):
        del access_token
        calls.append((account_id, cast(dict[str, object], payload.to_payload()), dict(headers)))
        if fail_accounts_with and account_id in fail_accounts_with:
            raise fail_accounts_with[account_id]
        return CompactResponsePayload.model_validate({"object": "response.compaction", "output": []})

    return fake_compact


def _usage_limit_429() -> ProxyResponseError:
    return ProxyResponseError(
        429,
        {
            "error": {
                "type": "usage_limit_reached",
                "message": "limit reached",
                "plan_type": "plus",
                "resets_at": int(utcnow().replace(tzinfo=timezone.utc).timestamp()) + 3600,
            }
        },
    )


def _targeted_accounts(
    calls: list[tuple[str | None, dict[str, object], dict[str, str]]],
) -> list[str | None]:
    return [account_id for account_id, _payload, _headers in calls]


# --------------------------------------------------------------------------- #
# Recovery cases: these FAIL on unmodified code (the request wedges on the     #
# dead owner) and PASS only once the compaction path gains selection-time      #
# account-neutral replay recovery.                                             #
# --------------------------------------------------------------------------- #


async def test_selection_time_quota_loss_recovers_on_other_account(async_client, monkeypatch):
    """Owner usage-exhausted at selection time: the request drops the anchor and
    replays the verified full resend on the healthy account. This case uses the
    quota-exhausted persisted status (its sibling recovery cases use the
    rate-limited status), so both usage-exhaustion states are load-bearing across
    the suite — a solution that recovers for only one of them cannot pass."""
    owner_account_id = await _import_account(
        async_client, email="compact-quota-owner@example.com", raw_account_id="acc_quota_owner"
    )
    await _import_account(async_client, email="compact-quota-alt@example.com", raw_account_id="acc_quota_alt")
    # The upstream send records the account's raw upstream identifier, which the
    # import carries through verbatim — distinct from the de-duplicated database
    # id used to pin/mark the owner.
    alt_upstream_id = "acc_quota_alt"
    await _mark_account_status(owner_account_id, AccountStatus.QUOTA_EXCEEDED)
    _pin_previous_response_owner(monkeypatch, owner_account_id)

    calls: list[tuple[str | None, dict[str, object], dict[str, str]]] = []
    monkeypatch.setattr(proxy_module, "core_compact_responses", _recording_compact(calls))

    response = await async_client.post(
        COMPACT_URL,
        json={
            "model": "gpt-5.1",
            "instructions": "hi",
            "input": _NEUTRAL_FULL_RESEND_INPUT,
            "previous_response_id": "resp_quota_anchor",
        },
    )

    assert response.status_code == 200, response.text
    # Exactly one upstream send, and it landed on the OTHER account.
    assert _targeted_accounts(calls) == [alt_upstream_id]
    replay_payload = calls[0][1]
    assert "previous_response_id" not in replay_payload
    assert replay_payload["input"] == _NEUTRAL_FULL_RESEND_INPUT


async def test_in_request_quota_429_recovers_on_other_account(async_client, monkeypatch):
    """Owner healthy at selection time but 429s mid-request: the owner is
    excluded and the verified full resend recovers on the other account."""
    owner_account_id = await _import_account(
        async_client, email="compact-429-owner@example.com", raw_account_id="acc_429_owner"
    )
    await _import_account(async_client, email="compact-429-alt@example.com", raw_account_id="acc_429_alt")
    # Raw upstream identifiers: what the upstream send records and what the
    # in-request failure injection is keyed by.
    owner_upstream_id = "acc_429_owner"
    alt_upstream_id = "acc_429_alt"
    _pin_previous_response_owner(monkeypatch, owner_account_id)

    calls: list[tuple[str | None, dict[str, object], dict[str, str]]] = []
    monkeypatch.setattr(
        proxy_module,
        "core_compact_responses",
        _recording_compact(calls, fail_accounts_with={owner_upstream_id: _usage_limit_429()}),
    )

    response = await async_client.post(
        COMPACT_URL,
        json={
            "model": "gpt-5.1",
            "instructions": "hi",
            "input": _NEUTRAL_FULL_RESEND_INPUT,
            "previous_response_id": "resp_429_anchor",
        },
    )

    assert response.status_code == 200, response.text
    # Owner was tried first (carrying the anchor), then the healthy account
    # received the anchor-free full resend.
    assert _targeted_accounts(calls) == [owner_upstream_id, alt_upstream_id]
    owner_payload, replay_payload = calls[0][1], calls[1][1]
    assert owner_payload["previous_response_id"] == "resp_429_anchor"
    assert "previous_response_id" not in replay_payload
    assert replay_payload["input"] == owner_payload["input"]


async def test_plain_prompt_cache_request_still_recovers(async_client, monkeypatch):
    """A request carrying an advisory prompt-cache locality hint still recovers:
    the soft cache key must not be treated as a hard account binding."""
    owner_account_id = await _import_account(
        async_client, email="compact-cache-owner@example.com", raw_account_id="acc_cache_owner"
    )
    await _import_account(async_client, email="compact-cache-alt@example.com", raw_account_id="acc_cache_alt")
    alt_upstream_id = "acc_cache_alt"
    await _mark_account_status(owner_account_id, AccountStatus.RATE_LIMITED)
    _pin_previous_response_owner(monkeypatch, owner_account_id)

    calls: list[tuple[str | None, dict[str, object], dict[str, str]]] = []
    monkeypatch.setattr(proxy_module, "core_compact_responses", _recording_compact(calls))

    response = await async_client.post(
        COMPACT_URL,
        json={
            "model": "gpt-5.1",
            "instructions": "hi",
            "input": _NEUTRAL_FULL_RESEND_INPUT,
            "previous_response_id": "resp_cache_anchor",
            "prompt_cache_key": "cache-locality-hint-123",
        },
    )

    assert response.status_code == 200, response.text
    assert _targeted_accounts(calls) == [alt_upstream_id]
    replay_payload = calls[0][1]
    assert "previous_response_id" not in replay_payload


# --------------------------------------------------------------------------- #
# Must-stay-owner-bound cases: recovery must NOT over-trigger. Each asserts    #
# zero cross-account sends. (These pass on unmodified code too — their job is  #
# to reject over-broad "fixes" that move history when it is unsafe.)           #
# --------------------------------------------------------------------------- #


async def test_post_selection_401_stays_owner_bound(async_client, monkeypatch):
    """A post-selection authentication (401) failure is a non-quota loss: the
    owner's auth failure surfaces unchanged and nothing crosses accounts."""
    owner_account_id = await _import_account(
        async_client, email="compact-401-owner@example.com", raw_account_id="acc_401_owner"
    )
    await _import_account(async_client, email="compact-401-alt@example.com", raw_account_id="acc_401_alt")
    owner_upstream_id = "acc_401_owner"
    _pin_previous_response_owner(monkeypatch, owner_account_id)

    async def fake_ensure_fresh(self, account, *, force=False, timeout_seconds=None):
        del self, force, timeout_seconds
        return account

    monkeypatch.setattr(proxy_module.ProxyService, "_ensure_fresh_with_budget", fake_ensure_fresh)

    calls: list[tuple[str | None, dict[str, object], dict[str, str]]] = []
    unauthorized = ProxyResponseError(401, openai_error("unauthorized", "token rejected"))
    monkeypatch.setattr(
        proxy_module,
        "core_compact_responses",
        _recording_compact(calls, fail_accounts_with={owner_upstream_id: unauthorized}),
    )

    response = await async_client.post(
        COMPACT_URL,
        json={
            "model": "gpt-5.1",
            "instructions": "hi",
            "input": _NEUTRAL_FULL_RESEND_INPUT,
            "previous_response_id": "resp_401_anchor",
        },
    )

    assert response.status_code == 401
    # Every send targeted the owner; the request never moved to the alt account.
    assert set(_targeted_accounts(calls)) == {owner_upstream_id}


async def test_delta_without_retained_output_stays_owner_bound(async_client, monkeypatch):
    """A multi-item history that does not retain prior assistant output cannot
    be proven a full resend, so it is never sent to another account."""
    owner_account_id = await _import_account(
        async_client, email="compact-delta-owner@example.com", raw_account_id="acc_delta_owner"
    )
    await _import_account(async_client, email="compact-delta-alt@example.com", raw_account_id="acc_delta_alt")
    await _mark_account_status(owner_account_id, AccountStatus.RATE_LIMITED)
    _pin_previous_response_owner(monkeypatch, owner_account_id)

    calls: list[tuple[str | None, dict[str, object], dict[str, str]]] = []
    monkeypatch.setattr(proxy_module, "core_compact_responses", _recording_compact(calls))

    response = await async_client.post(
        COMPACT_URL,
        json={
            "model": "gpt-5.1",
            "instructions": "hi",
            "input": [
                {"role": "user", "content": "first delta turn"},
                {"role": "user", "content": "second delta turn"},
            ],
            "previous_response_id": "resp_delta_anchor",
        },
    )

    assert response.status_code >= 400
    assert calls == []


async def test_account_scoped_history_stays_owner_bound(async_client, monkeypatch):
    """A history carrying account-scoped (encrypted-compaction) state fails the
    account-neutral replay gate and never crosses accounts."""
    owner_account_id = await _import_account(
        async_client, email="compact-scoped-owner@example.com", raw_account_id="acc_scoped_owner"
    )
    await _import_account(async_client, email="compact-scoped-alt@example.com", raw_account_id="acc_scoped_alt")
    await _mark_account_status(owner_account_id, AccountStatus.RATE_LIMITED)
    _pin_previous_response_owner(monkeypatch, owner_account_id)

    calls: list[tuple[str | None, dict[str, object], dict[str, str]]] = []
    monkeypatch.setattr(proxy_module, "core_compact_responses", _recording_compact(calls))

    response = await async_client.post(
        COMPACT_URL,
        json={
            "model": "gpt-5.1",
            "instructions": "hi",
            "input": [
                {"type": "compaction", "encrypted_content": "enc_owner_scoped_state"},
                *_NEUTRAL_FULL_RESEND_INPUT,
            ],
            "previous_response_id": "resp_scoped_anchor",
        },
    )

    assert response.status_code >= 400
    assert calls == []


async def test_session_identity_stays_owner_bound(async_client, monkeypatch):
    """A session identity on the request can bind continuity that still names
    the lost owner; without rebinding machinery the request stays owner-bound."""
    owner_account_id = await _import_account(
        async_client, email="compact-session-owner@example.com", raw_account_id="acc_session_owner"
    )
    await _import_account(async_client, email="compact-session-alt@example.com", raw_account_id="acc_session_alt")
    await _mark_account_status(owner_account_id, AccountStatus.RATE_LIMITED)
    _pin_previous_response_owner(monkeypatch, owner_account_id)

    calls: list[tuple[str | None, dict[str, object], dict[str, str]]] = []
    monkeypatch.setattr(proxy_module, "core_compact_responses", _recording_compact(calls))

    response = await async_client.post(
        COMPACT_URL,
        json={
            "model": "gpt-5.1",
            "instructions": "hi",
            "input": _NEUTRAL_FULL_RESEND_INPUT,
            "previous_response_id": "resp_session_anchor",
        },
        headers={"session_id": "sid-compact-session-bound"},
    )

    assert response.status_code >= 400
    assert calls == []


async def test_non_quota_status_stays_owner_bound(async_client, monkeypatch):
    """An owner unselectable for a non-quota reason (operator pause) keeps the
    existing fail-closed surface; recovery requires a quota-caused loss."""
    owner_account_id = await _import_account(
        async_client, email="compact-paused-owner@example.com", raw_account_id="acc_paused_owner"
    )
    await _import_account(async_client, email="compact-paused-alt@example.com", raw_account_id="acc_paused_alt")
    await _mark_account_status(owner_account_id, AccountStatus.PAUSED)
    _pin_previous_response_owner(monkeypatch, owner_account_id)

    calls: list[tuple[str | None, dict[str, object], dict[str, str]]] = []
    monkeypatch.setattr(proxy_module, "core_compact_responses", _recording_compact(calls))

    response = await async_client.post(
        COMPACT_URL,
        json={
            "model": "gpt-5.1",
            "instructions": "hi",
            "input": _NEUTRAL_FULL_RESEND_INPUT,
            "previous_response_id": "resp_paused_anchor",
        },
    )

    assert response.status_code >= 400
    assert calls == []


async def test_policy_skip_stays_owner_bound_despite_quota_status(async_client, monkeypatch):
    """An owner the selector skips for routing policy (API-key assignment
    scope) stays owner-bound even when its status is coincidentally
    usage-limited: policy, not quota, caused the selection loss."""
    owner_account_id = await _import_account(
        async_client, email="compact-policy-owner@example.com", raw_account_id="acc_policy_owner"
    )
    alt_account_id = await _import_account(
        async_client, email="compact-policy-alt@example.com", raw_account_id="acc_policy_alt"
    )
    await _mark_account_status(owner_account_id, AccountStatus.RATE_LIMITED)
    _pin_previous_response_owner(monkeypatch, owner_account_id)

    settings_resp = await async_client.put(
        "/api/settings",
        json={"totpRequiredOnLogin": False, "apiKeyAuthEnabled": True},
    )
    assert settings_resp.status_code == 200
    _key_id, key = await _create_api_key(
        name="compact-policy-scope-key",
        assigned_account_ids=[alt_account_id],
    )

    calls: list[tuple[str | None, dict[str, object], dict[str, str]]] = []
    monkeypatch.setattr(proxy_module, "core_compact_responses", _recording_compact(calls))

    response = await async_client.post(
        COMPACT_URL,
        json={
            "model": "gpt-5.1",
            "instructions": "hi",
            "input": _NEUTRAL_FULL_RESEND_INPUT,
            "previous_response_id": "resp_policy_anchor",
        },
        headers={"authorization": f"Bearer {key}"},
    )

    assert response.status_code >= 400
    assert calls == []


async def test_additional_turn_state_pin_stays_owner_bound_and_records_fail_closed(
    async_client, monkeypatch, caplog
):
    """A previous-response pin accompanied by a turn-state pin on the same owner
    stays owner-bound (recovery never activates for additional owner pins), and
    the unavailable owner still records the existing continuity fail-closed
    outcome rather than silently skipping the recording."""
    owner_account_id = await _import_account(
        async_client, email="compact-multipin-owner@example.com", raw_account_id="acc_multipin_owner"
    )
    await _import_account(async_client, email="compact-multipin-alt@example.com", raw_account_id="acc_multipin_alt")
    await _mark_account_status(owner_account_id, AccountStatus.RATE_LIMITED)
    _pin_previous_response_owner(monkeypatch, owner_account_id)

    async def fake_turn_state_owner(self, *, turn_state, api_key, fail_on_missing=True):
        del self, turn_state, api_key, fail_on_missing
        return owner_account_id

    monkeypatch.setattr(proxy_module.ProxyService, "_resolve_compact_turn_state_owner", fake_turn_state_owner)

    calls: list[tuple[str | None, dict[str, object], dict[str, str]]] = []
    monkeypatch.setattr(proxy_module, "core_compact_responses", _recording_compact(calls))

    with caplog.at_level(logging.INFO):
        response = await async_client.post(
            COMPACT_URL,
            json={
                "model": "gpt-5.1",
                "instructions": "hi",
                "input": _NEUTRAL_FULL_RESEND_INPUT,
                "previous_response_id": "resp_multipin_anchor",
            },
            headers={"x-codex-turn-state": "ts-multipin-owner-bound"},
        )

    assert response.status_code >= 400
    assert calls == []
    # The fail-closed accounting uses the pre-existing, stable surface/reason
    # contract — assert on that, not on any internal blocked-reason string.
    assert "continuity_fail_closed surface=compact reason=owner_account_unavailable" in caplog.text
