#!/usr/bin/env bash
# All required deps for the focused verifier packages are baked into the image:
#   - Go 1.26.6 toolchain at /usr/local/go (GOTOOLCHAIN=local)
#   - the module cache is warm (`go mod download` ran at build time)
#   - the weed/admin/dash + weed/admin/maintenance test binaries were compiled
#     once at build time, so their build cache is hot
#   - CGO_ENABLED=0 — the admin maintenance packages need no cgo
# The agent phase is offline (agent_offline = true); nothing here reaches the
# network. This script is a no-op kept for harbor's test.sh contract.
set -euo pipefail
echo "[test-setup] no-op for seaweedfs-fix-cancelled-task-files (deps baked into image)"
