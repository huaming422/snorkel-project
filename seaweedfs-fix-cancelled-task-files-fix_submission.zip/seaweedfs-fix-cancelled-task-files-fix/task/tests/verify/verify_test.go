// Behavioral checks for the admin maintenance task-state persistence lifecycle.
//
// Every assertion is on observable disk state: the number of per-task `.pb`
// state files left under <dataDir>/tasks/. The checks drive the system through
// the package's pre-existing exported entry points only —
// NewConfigPersistence / SaveTaskState / CleanupCompletedTasks on the
// persistence side, and NewMaintenanceQueue / SetPersistence / AddTask /
// CancelPendingTasksByType / NewMaintenanceManager / GetQueue / CancelTask on
// the queue+manager side. No internal helper, field, or mutex introduced by a
// fix is named here, so any restructuring that produces the same observable
// disk behavior is accepted.
package dash

import (
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/seaweedfs/seaweedfs/weed/admin/maintenance"
)

// vfyCountTaskStateFiles returns the number of regular `.pb` task-state files
// under <dir>/tasks. A missing directory counts as zero.
func vfyCountTaskStateFiles(t *testing.T, dir string) int {
	t.Helper()
	entries, err := os.ReadDir(filepath.Join(dir, TasksSubdir))
	if os.IsNotExist(err) {
		return 0
	}
	if err != nil {
		t.Fatalf("read tasks dir: %v", err)
	}
	count := 0
	for _, entry := range entries {
		if !entry.IsDir() && filepath.Ext(entry.Name()) == ".pb" {
			count++
		}
	}
	return count
}

// TestVerifyCancelScanCycleNoFileLeak -> cancel_scan_cycle_no_file_leak (f2p).
//
// The scan cycle cancels all pending tasks of a type each pass and re-detects
// them. A cancelled task reaches a terminal state, so its persisted file must
// be dropped rather than rewritten with a terminal status. Over repeated
// add-then-cancel cycles the tasks directory must therefore stay empty; the
// pre-fix path rewrites one terminal file per cycle, so the count climbs.
func TestVerifyCancelScanCycleNoFileLeak(t *testing.T) {
	dir := t.TempDir()
	cp := NewConfigPersistence(dir)

	queue := maintenance.NewMaintenanceQueue(nil)
	queue.SetPersistence(cp)

	const cycles = 3
	for cycle := 0; cycle < cycles; cycle++ {
		queue.AddTask(&maintenance.MaintenanceTask{
			ID:       fmt.Sprintf("scan_cycle_%d", cycle),
			Type:     "erasure_coding",
			VolumeID: uint32(cycle + 1),
			Server:   "server1",
		})
		if cancelled := queue.CancelPendingTasksByType("erasure_coding"); cancelled != 1 {
			t.Fatalf("cycle %d: cancelled %d pending tasks, want 1", cycle, cancelled)
		}
	}

	if n := vfyCountTaskStateFiles(t, dir); n != 0 {
		t.Errorf("%d task-state files on disk after %d add+cancel cycles, want 0 "+
			"(a cancelled task is terminal; its file must be removed, not rewritten)", n, cycles)
	}
}

// TestVerifyManualCancelRemovesFile -> manual_cancel_removes_file (f2p).
//
// Cancelling a pending task from the operator/UI path must also drop its
// persisted file, so a restart cannot resurrect the cancelled task as pending.
// The pre-fix UI path only mutates in-memory state and leaves the file behind.
func TestVerifyManualCancelRemovesFile(t *testing.T) {
	dir := t.TempDir()
	cp := NewConfigPersistence(dir)

	manager := maintenance.NewMaintenanceManager(nil, nil, cp)
	queue := manager.GetQueue()
	queue.SetPersistence(cp)

	queue.AddTask(&maintenance.MaintenanceTask{
		ID:       "manual_cancel_1",
		Type:     "vacuum",
		VolumeID: 7,
		Server:   "server1",
	})
	if n := vfyCountTaskStateFiles(t, dir); n != 1 {
		t.Fatalf("%d task-state files after adding one pending task, want 1", n)
	}

	if err := manager.CancelTask("manual_cancel_1"); err != nil {
		t.Fatalf("CancelTask on a pending task returned error: %v", err)
	}
	if n := vfyCountTaskStateFiles(t, dir); n != 0 {
		t.Errorf("%d task-state files on disk after cancelling via the operator path, want 0 "+
			"(the cancelled task's file must be removed, not left for a restart to resurrect)", n)
	}
}

// TestVerifyRetentionBoundsCancelledFiles -> retention_bounds_cancelled_files (f2p).
//
// On-disk retention must count cancelled task files toward the retention bound,
// so cancelled files (for example written by an older build) are bounded rather
// than exempt. Pre-fix retention only recognises completed/failed as terminal,
// so cancelled files accumulate past the bound unchecked. Each seeded cancelled
// task carries a completion timestamp, matching what the real cancel paths write
// when they reach the terminal state, so the retention bound is exercised on the
// state the system actually produces rather than on a synthetic one.
func TestVerifyRetentionBoundsCancelledFiles(t *testing.T) {
	dir := t.TempDir()
	cp := NewConfigPersistence(dir)

	const extra = 5
	base := time.Now().Add(-time.Hour)
	for i := 0; i < MaxCompletedTasks+extra; i++ {
		cancelledAt := base.Add(time.Duration(i) * time.Minute)
		if err := cp.SaveTaskState(&maintenance.MaintenanceTask{
			ID:          fmt.Sprintf("old_cancelled_%02d", i),
			Type:        "erasure_coding",
			Status:      maintenance.TaskStatusCancelled,
			CompletedAt: &cancelledAt,
		}); err != nil {
			t.Fatalf("seed cancelled task %d: %v", i, err)
		}
	}
	if n := vfyCountTaskStateFiles(t, dir); n != MaxCompletedTasks+extra {
		t.Fatalf("%d cancelled task files seeded, want %d", n, MaxCompletedTasks+extra)
	}

	if err := cp.CleanupCompletedTasks(); err != nil {
		t.Fatalf("CleanupCompletedTasks: %v", err)
	}
	if n := vfyCountTaskStateFiles(t, dir); n > MaxCompletedTasks {
		t.Errorf("%d cancelled task files remain after retention, want at most %d "+
			"(cancelled is terminal and must count toward the retention bound)", n, MaxCompletedTasks)
	}
}

// TestVerifyLivePendingTaskPersisted -> live_pending_task_persisted (p2p).
//
// Anti reward-hack guard: cancelling one task must delete precisely that task's
// file and nothing else. A solution that "fixes" the leak by clearing the whole
// tasks directory (or disabling persistence) on cancel passes the leak checks
// but destroys the persisted state of other still-pending tasks — which this
// check rejects. It passes on both the pre-fix and a correct implementation;
// only an over-broad or persistence-disabling solution fails it.
func TestVerifyLivePendingTaskPersisted(t *testing.T) {
	dir := t.TempDir()
	cp := NewConfigPersistence(dir)

	queue := maintenance.NewMaintenanceQueue(nil)
	queue.SetPersistence(cp)

	queue.AddTask(&maintenance.MaintenanceTask{
		ID:       "live_cancelled",
		Type:     "erasure_coding",
		VolumeID: 1,
		Server:   "server1",
	})
	queue.AddTask(&maintenance.MaintenanceTask{
		ID:       "live_survivor",
		Type:     "vacuum",
		VolumeID: 2,
		Server:   "server1",
	})
	if n := vfyCountTaskStateFiles(t, dir); n != 2 {
		t.Fatalf("%d task-state files after adding two pending tasks, want 2 "+
			"(each added pending task must be persisted)", n)
	}

	if cancelled := queue.CancelPendingTasksByType("erasure_coding"); cancelled != 1 {
		t.Fatalf("cancelled %d pending tasks of the first type, want 1", cancelled)
	}

	// The unrelated, still-pending task's file must survive and still describe a
	// pending task — cancelling one task must not disturb another's persisted
	// state.
	survivor, err := cp.LoadTaskState("live_survivor")
	if err != nil {
		t.Fatalf("the still-pending task's state file must survive cancelling an unrelated task, "+
			"but loading it failed: %v", err)
	}
	if survivor.Status != maintenance.TaskStatusPending {
		t.Errorf("surviving task persisted with status %q, want %q",
			survivor.Status, maintenance.TaskStatusPending)
	}
}

// TestVerifyCompletedFailedPersistenceIntact -> completed_failed_persistence_intact (p2p).
//
// Regression guard: normal completed-task persistence and its retention bound
// must be unchanged. Completed tasks are still written and still bounded by the
// retention limit, and the most recent one is retained. A solution that makes
// retention delete everything (or stops persisting terminal tasks) fails here.
func TestVerifyCompletedFailedPersistenceIntact(t *testing.T) {
	dir := t.TempDir()
	cp := NewConfigPersistence(dir)

	const extra = 5
	base := time.Now().Add(-time.Hour)
	newestID := fmt.Sprintf("completed_%02d", MaxCompletedTasks+extra-1)
	for i := 0; i < MaxCompletedTasks+extra; i++ {
		completedAt := base.Add(time.Duration(i) * time.Minute)
		if err := cp.SaveTaskState(&maintenance.MaintenanceTask{
			ID:          fmt.Sprintf("completed_%02d", i),
			Type:        "erasure_coding",
			Status:      maintenance.TaskStatusCompleted,
			CompletedAt: &completedAt,
		}); err != nil {
			t.Fatalf("seed completed task %d: %v", i, err)
		}
	}
	if n := vfyCountTaskStateFiles(t, dir); n != MaxCompletedTasks+extra {
		t.Fatalf("%d completed task files seeded, want %d", n, MaxCompletedTasks+extra)
	}

	if err := cp.CleanupCompletedTasks(); err != nil {
		t.Fatalf("CleanupCompletedTasks: %v", err)
	}

	n := vfyCountTaskStateFiles(t, dir)
	if n > MaxCompletedTasks {
		t.Errorf("%d completed task files remain after retention, want at most %d", n, MaxCompletedTasks)
	}
	if n == 0 {
		t.Errorf("retention removed every completed task file; completed tasks must still be persisted and bounded, not wiped")
	}
	if _, err := cp.LoadTaskState(newestID); err != nil {
		t.Errorf("the most recently completed task %q must be retained by retention, but loading it failed: %v", newestID, err)
	}
}
