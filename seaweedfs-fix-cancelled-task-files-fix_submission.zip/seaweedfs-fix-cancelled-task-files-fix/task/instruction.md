## Task

we're running a SeaweedFS admin server with the maintenance system enabled, and the directory where it persists scheduled-task state keeps growing without bound. during normal scan cycles the per-task state files pile up continuously, thousands a day, to the point where we're worried about running the data volume out of inodes. restarting the admin server clears the backlog, but while it stays up the count only ever climbs. diagnose the root cause and fix it so the on-disk task state stops leaking.
