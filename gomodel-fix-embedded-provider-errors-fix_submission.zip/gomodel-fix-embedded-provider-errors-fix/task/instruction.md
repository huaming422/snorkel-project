## Task

heads up, some of our upstream providers occasionally answer with an HTTP 200 whose body is actually an error payload, and the gateway happily treats those as successful responses. callers get a 200 with no usable choices, failover and retries never fire, the breaker stays closed, and the bad response even gets cached and served again on later requests. these should fail over the way any other provider error does. dig in and make the gateway treat these embedded-error responses as the real failures they are.
