#!/usr/bin/env bash
# All required deps for the focused tests are baked into the image at the base
# commit: Go 1.27.3 toolchain, the full module cache (go.mod/go.sum closure,
# including github.com/tidwall/gjson and its transitive deps match/pretty), and
# a prewarmed go-build cache for internal/llmclient + internal/core. The oracle
# introduces no new module. Nothing to install at verifier time; the agent phase
# is no-network and needs nothing beyond what the image carries.
set -euo pipefail
echo "[test-setup] no-op for gomodel-fix-embedded-provider-errors"
