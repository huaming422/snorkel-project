// Behavioral checks for the gateway client's handling of upstream responses
// that carry an HTTP 200 status but an error payload in the body.
//
// Everything is driven through the client's pre-existing stable public surface
// — New(DefaultConfig(provider, url), ...) then Do / DoRaw / DoStream against an
// in-process net/http/httptest server — which is exactly how the package's own
// client_test.go exercises the client. Classification outcomes are observed via
// the caller-facing *core.GatewayError (StatusCode / Type / Message) and via the
// readability and byte-fidelity of the stream returned by DoStream. No internal
// detection helper or sentinel is referenced by name, so any implementation that
// produces the correct observable behavior passes equally.
//
// In-package test (package llmclient) so clients compile exactly like the repo's
// own tests. All identifiers are vrf-prefixed to compose with the package's
// existing test files.
package llmclient

import (
	"context"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"sync/atomic"
	"testing"
	"time"

	"github.com/enterpilot/gomodel/internal/core"
)

// vrfStreamDeadline bounds any stream operation that a correct fix completes
// promptly. A fix that instead waits for the response to end before handing the
// stream back blocks here, so the bound turns that hang into a fast, clean test
// failure attributed to a named check rather than a whole-suite timeout.
const vrfStreamDeadline = 15 * time.Second

// vrfFastRetry returns a config whose retry backoff is negligible and
// deterministic, so retry-count assertions run fast without timing flakiness.
func vrfFastRetry(providerName, baseURL string, maxRetries int) Config {
	cfg := DefaultConfig(providerName, baseURL)
	cfg.Retry.MaxRetries = maxRetries
	cfg.Retry.InitialBackoff = time.Millisecond
	cfg.Retry.MaxBackoff = time.Millisecond
	cfg.Retry.JitterFactor = 0
	return cfg
}

// vrfJSONServer returns a server that answers every request with status 200,
// Content-Type application/json, and the given body, counting the hits.
func vrfJSONServer(body string, hits *atomic.Int32) *httptest.Server {
	return httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if hits != nil {
			hits.Add(1)
		}
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(body))
	}))
}

// vrfDoStreamWithin calls DoStream and fails the test if it does not return
// within the deadline — the signature of a fix that drains the body to EOF
// before returning.
func vrfDoStreamWithin(t *testing.T, c *Client, req Request) (io.ReadCloser, error) {
	t.Helper()
	type outcome struct {
		stream io.ReadCloser
		err    error
	}
	ch := make(chan outcome, 1)
	go func() {
		s, err := c.DoStream(context.Background(), req)
		ch <- outcome{s, err}
	}()
	select {
	case o := <-ch:
		return o.stream, o.err
	case <-time.After(vrfStreamDeadline):
		t.Fatalf("DoStream did not return within %v; a live stream must be handed back without waiting for the body to end", vrfStreamDeadline)
		return nil, nil
	}
}

// vrfReadAllWithin reads the stream to completion within the deadline, failing
// fast if the read blocks (e.g. the server is holding the connection open and
// the reader is waiting for bytes that were buffered during inspection).
func vrfReadAllWithin(t *testing.T, stream io.Reader) []byte {
	t.Helper()
	type outcome struct {
		body []byte
		err  error
	}
	ch := make(chan outcome, 1)
	go func() {
		b, err := io.ReadAll(stream)
		ch <- outcome{b, err}
	}()
	select {
	case o := <-ch:
		if o.err != nil {
			t.Fatalf("reading returned stream: %v", o.err)
		}
		return o.body
	case <-time.After(vrfStreamDeadline):
		t.Fatalf("reading the returned stream did not complete within %v", vrfStreamDeadline)
		return nil
	}
}

// --- fail_to_pass: a 200 carrying a bare error body is a failure ---

// TestVrfEmbeddedErrorBufferedMapsToError covers crit_embedded_maps_to_error.
// A 200 whose body is a bare {"error":...} object must reach the caller as an
// error from the buffered path, not as a successful response. MaxRetries=0 keeps
// the single attempt fast and deterministic regardless of the mapped status.
func TestVrfEmbeddedErrorBufferedMapsToError(t *testing.T) {
	server := vrfJSONServer(`{"error":{"message":"boom"}}`, nil)
	defer server.Close()

	cfg := vrfFastRetry("test", server.URL, 0)
	client := New(cfg, nil)

	resp, err := client.DoRaw(context.Background(), Request{Method: http.MethodGet, Endpoint: "/test"})
	if err == nil {
		t.Fatalf("DoRaw returned no error for a 200 bare-error body; got response %+v", resp)
	}
	if resp != nil {
		t.Errorf("DoRaw returned a non-nil response alongside the error: %+v", resp)
	}
	var gatewayErr *core.GatewayError
	if !errors.As(err, &gatewayErr) {
		t.Fatalf("expected a *core.GatewayError, got %T: %v", err, err)
	}
}

// TestVrfEmbeddedErrorStatusPreserved covers crit_embedded_status_preserved: a
// status carried in error.code (400-599) becomes the resulting status, while a
// body with no usable code maps to 502. A fix that always returns 502 fails the
// preserved-429 case.
func TestVrfEmbeddedErrorStatusPreserved(t *testing.T) {
	cases := []struct {
		name       string
		body       string
		wantStatus int
		wantType   core.ErrorType
	}{
		{
			name:       "code 429 preserved as rate limit",
			body:       `{"error":{"message":"slow down","code":429}}`,
			wantStatus: http.StatusTooManyRequests,
			wantType:   core.ErrorTypeRateLimit,
		},
		{
			name:       "no code maps to bad gateway",
			body:       `{"error":{"message":"boom"}}`,
			wantStatus: http.StatusBadGateway,
			wantType:   core.ErrorTypeProvider,
		},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			server := vrfJSONServer(tc.body, nil)
			defer server.Close()

			client := New(vrfFastRetry("test", server.URL, 0), nil)

			_, err := client.DoRaw(context.Background(), Request{Method: http.MethodGet, Endpoint: "/test"})
			var gatewayErr *core.GatewayError
			if !errors.As(err, &gatewayErr) {
				t.Fatalf("expected a *core.GatewayError, got %T: %v", err, err)
			}
			if gatewayErr.StatusCode != tc.wantStatus {
				t.Errorf("StatusCode = %d, want %d", gatewayErr.StatusCode, tc.wantStatus)
			}
			if gatewayErr.Type != tc.wantType {
				t.Errorf("Type = %q, want %q", gatewayErr.Type, tc.wantType)
			}
		})
	}
}

// TestVrfEmbeddedRetryableRetries covers crit_embedded_retryable_retries: a
// retryable embedded status drives the normal retry machinery (the upstream
// sees more than one attempt), while a non-retryable embedded status returns
// after a single attempt. This proves the mapped status flows through the same
// resilience path a genuine error status would.
func TestVrfEmbeddedRetryableRetries(t *testing.T) {
	t.Run("retryable status retries to exhaustion", func(t *testing.T) {
		var hits atomic.Int32
		server := vrfJSONServer(`{"error":{"message":"overloaded","code":503}}`, &hits)
		defer server.Close()

		client := New(vrfFastRetry("test", server.URL, 2), nil)

		_, err := client.DoRaw(context.Background(), Request{Method: http.MethodGet, Endpoint: "/test"})
		var gatewayErr *core.GatewayError
		if !errors.As(err, &gatewayErr) {
			t.Fatalf("expected a *core.GatewayError, got %T: %v", err, err)
		}
		if gatewayErr.StatusCode != http.StatusServiceUnavailable {
			t.Errorf("final StatusCode = %d, want %d", gatewayErr.StatusCode, http.StatusServiceUnavailable)
		}
		if got := hits.Load(); got != 3 {
			t.Errorf("upstream attempts = %d, want 3 (initial + 2 retries)", got)
		}
	})

	t.Run("non-retryable status returns immediately", func(t *testing.T) {
		var hits atomic.Int32
		server := vrfJSONServer(`{"error":{"message":"teapot","code":418}}`, &hits)
		defer server.Close()

		client := New(vrfFastRetry("test", server.URL, 2), nil)

		_, err := client.DoRaw(context.Background(), Request{Method: http.MethodGet, Endpoint: "/test"})
		var gatewayErr *core.GatewayError
		if !errors.As(err, &gatewayErr) {
			t.Fatalf("expected a *core.GatewayError, got %T: %v", err, err)
		}
		if gatewayErr.StatusCode != http.StatusTeapot {
			t.Errorf("StatusCode = %d, want %d", gatewayErr.StatusCode, http.StatusTeapot)
		}
		if got := hits.Load(); got != 1 {
			t.Errorf("upstream attempts = %d, want 1 (non-retryable status must not retry)", got)
		}
	})
}

// TestVrfStreamEmbeddedFails covers crit_stream_embedded_fails: a 200 stream
// answered with a buffered application/json error object must make DoStream
// return an error and no readable stream, so stream failover can react.
func TestVrfStreamEmbeddedFails(t *testing.T) {
	t.Run("buffered error body, connection closes", func(t *testing.T) {
		server := vrfJSONServer(`{"error":{"message":"stream boom","code":500}}`, nil)
		defer server.Close()

		client := New(DefaultConfig("test", server.URL), nil)

		stream, err := vrfDoStreamWithin(t, client, Request{Method: http.MethodPost, Endpoint: "/stream"})
		if err == nil {
			if stream != nil {
				_ = stream.Close()
			}
			t.Fatal("DoStream returned no error for a buffered 200 error body")
		}
		if stream != nil {
			t.Errorf("DoStream returned a non-nil reader alongside the error")
		}
		var gatewayErr *core.GatewayError
		if !errors.As(err, &gatewayErr) {
			t.Fatalf("expected a *core.GatewayError, got %T: %v", err, err)
		}
		if gatewayErr.StatusCode != http.StatusInternalServerError {
			t.Errorf("StatusCode = %d, want %d", gatewayErr.StatusCode, http.StatusInternalServerError)
		}
	})

	t.Run("error detected without waiting for the body to end", func(t *testing.T) {
		// The server flushes a complete error object and then holds the body
		// open. A correct fix classifies from the bytes already in hand and
		// returns the error at once; the deadline guard turns an end-of-body
		// wait into a fast failure.
		release := make(chan struct{})
		server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Type", "application/json")
			_, _ = w.Write([]byte(`{"error":{"message":"upstream down","code":503}}`))
			if f, ok := w.(http.Flusher); ok {
				f.Flush()
			}
			select {
			case <-release:
			case <-time.After(vrfStreamDeadline + 5*time.Second):
			}
		}))
		// Register server.Close() first so it runs LAST: the release channel
		// closes before the server shuts down, so the handler has already
		// unblocked and Close never waits on the held-open connection.
		defer server.Close()
		defer close(release)

		client := New(DefaultConfig("test", server.URL), nil)

		stream, err := vrfDoStreamWithin(t, client, Request{Method: http.MethodPost, Endpoint: "/stream"})
		if err == nil {
			if stream != nil {
				_ = stream.Close()
			}
			t.Fatal("DoStream returned no error for a held-open 200 error body")
		}
		var gatewayErr *core.GatewayError
		if !errors.As(err, &gatewayErr) {
			t.Fatalf("expected a *core.GatewayError, got %T: %v", err, err)
		}
		if gatewayErr.StatusCode != http.StatusServiceUnavailable {
			t.Errorf("StatusCode = %d, want %d", gatewayErr.StatusCode, http.StatusServiceUnavailable)
		}
	})
}

// --- pass_to_pass: over-correction guards (pass on both base and a valid fix) ---

// TestVrfResourceBodyPassthrough covers crit_resource_body_passthrough: a 200
// body that carries a resource member must be returned as success even when it
// also carries an error member, and ordinary success bodies must be untouched.
// A fix that triggers on any "error" key breaks the resource case.
func TestVrfResourceBodyPassthrough(t *testing.T) {
	t.Run("resource body with error member passes through", func(t *testing.T) {
		body := `{"id":"resp_1","object":"response","choices":null,"error":{"message":"stored failure"}}`
		server := vrfJSONServer(body, nil)
		defer server.Close()

		client := New(DefaultConfig("test", server.URL), nil)

		resp, err := client.DoRaw(context.Background(), Request{Method: http.MethodGet, Endpoint: "/test"})
		if err != nil {
			t.Fatalf("DoRaw returned an error for a resource body carrying an error member: %v", err)
		}
		if resp == nil || string(resp.Body) != body {
			t.Fatalf("resource body altered or missing.\n got: %q\nwant: %q", vrfRespBodyString(resp), body)
		}
	})

	t.Run("ordinary success body passes through", func(t *testing.T) {
		body := `{"id":"x","object":"chat.completion","choices":[{"message":{"content":"hi"}}]}`
		server := vrfJSONServer(body, nil)
		defer server.Close()

		client := New(DefaultConfig("test", server.URL), nil)

		resp, err := client.DoRaw(context.Background(), Request{Method: http.MethodGet, Endpoint: "/test"})
		if err != nil {
			t.Fatalf("DoRaw returned an error for an ordinary success body: %v", err)
		}
		if resp == nil || string(resp.Body) != body {
			t.Fatalf("success body altered or missing.\n got: %q\nwant: %q", vrfRespBodyString(resp), body)
		}
	})
}

// TestVrfStreamGenuinePassthrough covers crit_stream_genuine_passthrough: a
// genuine stream must be returned readable with its bytes intact and without
// waiting for the body to end. A fix that drains the stream to EOF to inspect it
// hangs on the held-open case and is caught by the deadline guards.
func TestVrfStreamGenuinePassthrough(t *testing.T) {
	t.Run("sse stream passes through", func(t *testing.T) {
		body := "data: {\"choices\":[{\"delta\":{\"content\":\"hi\"}}]}\n\n"
		server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Type", "text/event-stream")
			_, _ = w.Write([]byte(body))
		}))
		defer server.Close()

		client := New(DefaultConfig("test", server.URL), nil)

		stream, err := vrfDoStreamWithin(t, client, Request{Method: http.MethodPost, Endpoint: "/stream"})
		if err != nil {
			t.Fatalf("DoStream returned an error for an SSE stream: %v", err)
		}
		defer stream.Close()
		if got := vrfReadAllWithin(t, stream); string(got) != body {
			t.Errorf("SSE stream altered.\n got: %q\nwant: %q", string(got), body)
		}
	})

	t.Run("non-object json array passes through", func(t *testing.T) {
		// A leading '[' (array-framed JSON, e.g. a chunked completion array)
		// under application/json is not an error object; it must stream through
		// byte-for-byte with any inspected prefix replayed.
		body := "  [{\"candidates\":[{\"content\":\"a\"}]},\n{\"candidates\":[{\"content\":\"b\"}]}]"
		server := vrfJSONServer(body, nil)
		defer server.Close()

		client := New(DefaultConfig("test", server.URL), nil)

		stream, err := vrfDoStreamWithin(t, client, Request{Method: http.MethodPost, Endpoint: "/stream"})
		if err != nil {
			t.Fatalf("DoStream returned an error for an array-framed JSON body: %v", err)
		}
		defer stream.Close()
		if got := vrfReadAllWithin(t, stream); string(got) != body {
			t.Errorf("array-framed JSON altered.\n got: %q\nwant: %q", string(got), body)
		}
	})

	t.Run("buffered non-error json chunk passes through", func(t *testing.T) {
		body := `{"id":"x","object":"chat.completion.chunk","choices":[{"delta":{"content":"hi"}}]}`
		server := vrfJSONServer(body, nil)
		defer server.Close()

		client := New(DefaultConfig("test", server.URL), nil)

		stream, err := vrfDoStreamWithin(t, client, Request{Method: http.MethodPost, Endpoint: "/stream"})
		if err != nil {
			t.Fatalf("DoStream returned an error for a non-error JSON chunk: %v", err)
		}
		defer stream.Close()
		if got := vrfReadAllWithin(t, stream); string(got) != body {
			t.Errorf("JSON chunk altered by inspection.\n got: %q\nwant: %q", string(got), body)
		}
	})

	t.Run("open connection returns first object without waiting for eof", func(t *testing.T) {
		// The server flushes a complete non-error object then holds the body
		// open, only sending more after DoStream has returned. A fix that waits
		// for EOF deadlocks and is caught by the deadline guards.
		streamReturned := make(chan struct{})
		first := `{"choices":[{"delta":{"content":"Hi"}}]}` + "\n"
		second := `{"choices":[{"delta":{"content":"!"}}]}` + "\n"
		server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Type", "application/json")
			_, _ = w.Write([]byte(first))
			if f, ok := w.(http.Flusher); ok {
				f.Flush()
			}
			select {
			case <-streamReturned:
			case <-time.After(vrfStreamDeadline + 5*time.Second):
			}
			_, _ = w.Write([]byte(second))
		}))
		defer server.Close()

		client := New(DefaultConfig("test", server.URL), nil)

		stream, err := vrfDoStreamWithin(t, client, Request{Method: http.MethodPost, Endpoint: "/stream"})
		if err != nil {
			t.Fatalf("DoStream returned an error for a live JSON trickle: %v", err)
		}
		defer stream.Close()
		close(streamReturned)
		if got := vrfReadAllWithin(t, stream); string(got) != first+second {
			t.Errorf("live stream altered.\n got: %q\nwant: %q", string(got), first+second)
		}
	})
}

// TestVrfNoRegressionNormalSuccess covers crit_no_regression_normal_success:
// ordinary successful responses still succeed and genuine non-2xx errors still
// surface as errors with their status preserved.
func TestVrfNoRegressionNormalSuccess(t *testing.T) {
	t.Run("ordinary success unmarshals", func(t *testing.T) {
		server := vrfJSONServer(`{"id":"x","choices":[{"message":{"content":"hi"}}]}`, nil)
		defer server.Close()

		client := New(DefaultConfig("test", server.URL), nil)

		var result struct {
			ID string `json:"id"`
		}
		if err := client.Do(context.Background(), Request{Method: http.MethodGet, Endpoint: "/test"}, &result); err != nil {
			t.Fatalf("Do returned an error for an ordinary success: %v", err)
		}
		if result.ID != "x" {
			t.Errorf("result.ID = %q, want %q", result.ID, "x")
		}
	})

	t.Run("genuine 500 preserves status", func(t *testing.T) {
		server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusInternalServerError)
			_, _ = w.Write([]byte(`{"error":{"message":"down"}}`))
		}))
		defer server.Close()

		client := New(vrfFastRetry("test", server.URL, 0), nil)

		_, err := client.DoRaw(context.Background(), Request{Method: http.MethodGet, Endpoint: "/test"})
		var gatewayErr *core.GatewayError
		if !errors.As(err, &gatewayErr) {
			t.Fatalf("expected a *core.GatewayError, got %T: %v", err, err)
		}
		if gatewayErr.StatusCode != http.StatusInternalServerError {
			t.Errorf("StatusCode = %d, want %d", gatewayErr.StatusCode, http.StatusInternalServerError)
		}
	})
}

func vrfRespBodyString(resp *Response) string {
	if resp == nil {
		return "<nil response>"
	}
	return string(resp.Body)
}
