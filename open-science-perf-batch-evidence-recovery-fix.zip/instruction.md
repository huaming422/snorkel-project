## Task

Launching the desktop app gets slower the more history a workspace holds, even on a clean restart with nothing new to process. During launch the process list shows a burst of short-lived helper processes, about two for every past session, and the full session history is read from disk twice.

The number of helpers launch starts, processes and threads counted together, should no longer go up with every session. A clean restart of a workspace with sixteen sessions spread over two projects should start no more than two. After a crash, a project with 130 sessions, most of them left with half-finished work, should start no more than 16, and all of that half-finished work must still be cleaned up. On a normal launch the session history should be read once; if that read could not account for every session, those sessions still have to be recovered.

If the app is quit while launch is still recovering old sessions, recovery should stop where it is: the session it was on and every session after it stay exactly as they were.

Keep the on-disk format as it is and don't add a migration.
