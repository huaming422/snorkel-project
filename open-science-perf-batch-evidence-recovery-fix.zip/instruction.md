## Task

Launching the desktop app gets slower the more history a workspace holds, even on a clean restart with nothing new to process. During launch the process list shows a burst of short-lived helper processes, about two for every past session, and every session file is opened three times.

Launch should stop starting more helpers for every session it has to look at, counting both helper processes and helper threads. A clean restart of a workspace with sixteen sessions spread over two projects should start no more than two. After a crash, a project with 130 sessions, most of them left with half-finished work, should start no more than 16, and all of that half-finished work must still be cleaned up. Every launch should keep clearing out stored file copies that no session uses any more, as it does today. On a clean restart each session file should be opened no more than twice, while a session whose title was still being generated when the app last stopped still gets recovered, and a damaged session file must not stop the other sessions from being recovered.

If the app is quit while launch is still recovering old sessions, recovery should stop where it is: the session it was on and every session after it stay exactly as they were.

Keep the on-disk format as it is and don't add a migration.
