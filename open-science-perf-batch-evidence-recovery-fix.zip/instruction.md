## Task

Launching the desktop app gets slower the more history a workspace holds, even on a clean restart with nothing new to process. During launch the process list shows a burst of short-lived helper processes, about two for every past session that saved compute job output, and every session file is opened three times.

For sessions whose compute jobs ran to the end, the number of helpers started at launch should no longer grow with the number of sessions; helper processes and helper threads both count. A clean restart of a workspace with sixteen sessions spread over two projects, each holding one saved compute job result, should start no more than two. If the app went down while 117 of a 130-session project's compute jobs had finished but were still saving their output, and the other 13 had saved theirs, the next launch should start no more than 16, and all of that half-saved output must still be cleaned up. Every launch should keep clearing out stored file copies that no session uses any more, as it does today.

On a clean restart each session file with nothing to recover should be opened no more than twice and left as it is. A session whose title was still being generated when the app last stopped must still get recovered, and a damaged session file must not stop the other sessions from being recovered.

If the app is quit while launch is still recovering old sessions, recovery should stop where it is: the session it was on and every session after it stay exactly as they were.

Session files and saved job output must keep the layout and fields they are stored with today: what the current version wrote must still load, and what the new version writes must look the same, so the current version can still read it.
