#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier runs (set -euo pipefail inherited).
# This task's verifier is a vitest suite over the main-process TypeScript; no
# services, DB, or network are needed to observe the behavior. The image baked the
# full dependency closure at the base commit (`npm ci`) into node_modules, and the
# container runs with the network cut, so no dependency can be added or changed. The baked tree is therefore the complete closure when this script runs,
# and it must run with the network cut.
cd /repo/open-science

export npm_config_offline=true
export npm_config_update_notifier=false
export npm_config_fund=false
export npm_config_audit=false
# Point npm at the bake-time package cache for any offline install below. Step 11
# of the image repoints npm_config_cache at an empty per-user dir; the warm cache
# the base-commit install populated lives at /opt/cache/npm, so a genuine offline
# reinstall resolves from it instead of missing and reaching for the registry.
[ -d /opt/cache/npm ] && export npm_config_cache=/opt/cache/npm

# Trust the baked dependency tree. `npm ci` unconditionally deletes and rebuilds
# node_modules; with the per-user cache empty its offline pass misses and it falls
# back to a multi-minute online reinstall that blows the verifier time budget on a
# 4-CPU runner. node_modules is already the complete closure here (gitignored, so
# the base checkpoint never carried it; nothing in the offline container
# could have changed it), and npm writes node_modules/.package-lock.json only after a clean
# install completes, so presence of that sentinel is a reliable "tree is ready"
# marker. When it is present, skip the reinstall entirely and run off the baked
# tree. Only if the tree is somehow absent do we rebuild it offline from the
# warm cache (logged online fallback for a truly stale bake).
if [ -f node_modules/.package-lock.json ]; then
    echo "[test-setup] using baked node_modules (install sentinel present); no reinstall"
elif npm ci --prefer-offline > /tmp/test-setup-install.log 2>&1; then
    echo "[test-setup] node_modules restored offline from the bake cache"
elif { unset npm_config_offline; npm ci > /tmp/test-setup-install.log 2>&1; }; then
    echo "[test-setup] deps installed online (image bake was stale)"
else
    echo "[test-setup] dependency install failed:" >&2
    tail -40 /tmp/test-setup-install.log >&2
    exit 1
fi

# No background services, no data seeding, no assertion logic here; the verifier
# drives the recovery entry point in-process over temporary storage directories it
# creates itself.
