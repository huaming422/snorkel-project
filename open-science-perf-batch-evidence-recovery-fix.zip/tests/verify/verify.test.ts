// @ts-nocheck
// Behavioral verifier for startup recovery of Compute file evidence and for Session details
// recovery during shutdown. Evidence recovery is driven through the exported entry point
// reconcileComputeJobFileEvidence(storageRoot, jobs) over a temporary storage directory. Two
// things are observed: how many helpers (child processes of any kind, or worker threads) a
// startup pass launches as recorded history grows, and that recovered history stays intact on
// disk. No request payload or internal call is inspected.

import { createHash } from 'node:crypto'
import { existsSync } from 'node:fs'
import { mkdir, mkdtemp, readFile, readdir, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it, vi } from 'vitest'

// Helpers are counted on Node's own builtin objects before any module under test loads, so the
// count holds however a module reaches them (ESM import, require, createRequire, or a dependency
// such as cross-spawn). Every asynchronous child process (spawn, fork, exec, execFile) goes
// through ChildProcess.prototype.spawn; synchronous launches and worker threads are wrapped at
// their exports, and syncBuiltinESMExports() carries the wrappers to ESM importers.
const helpers = vi.hoisted(() => {
  const state = { launches: 0 }
  const childProcess = process.getBuiltinModule('node:child_process')
  const workerThreads = process.getBuiltinModule('node:worker_threads')
  const originalChildSpawn = childProcess.ChildProcess.prototype.spawn
  childProcess.ChildProcess.prototype.spawn = function (...args) {
    state.launches += 1
    return originalChildSpawn.apply(this, args)
  }
  for (const name of ['spawnSync', 'execSync', 'execFileSync']) {
    const original = childProcess[name]
    childProcess[name] = (...args) => {
      state.launches += 1
      return original(...args)
    }
  }
  const OriginalWorker = workerThreads.Worker
  workerThreads.Worker = class CountedWorker extends OriginalWorker {
    constructor(...args) {
      state.launches += 1
      super(...args)
    }
  }
  process.getBuiltinModule('node:module').syncBuiltinESMExports()
  return state
})
const launches = () => helpers.launches
const resetLaunches = () => {
  helpers.launches = 0
}

import {
  beginComputeJobFileEvidence,
  publishComputeJobFileEvidence,
  reconcileComputeJobFileEvidence,
  startWorkingFileObservation
} from './notebook/working-file-observer'
import { createSessionDetailsOwner } from './session-details/owner'

// A launch starts from a fresh process: the measured recovery pass runs on a newly loaded copy of
// the module, so nothing kept in module state by the fixture writes carries over.
const coldRecovery = async (storageRoot: string, jobs: readonly any[]) => {
  vi.resetModules()
  const fresh = await import('./notebook/working-file-observer')
  resetLaunches()
  return fresh.reconcileComputeJobFileEvidence(storageRoot, jobs)
}

type Job = Parameters<typeof reconcileComputeJobFileEvidence>[1][number]

const projectId = 'project-batch'
const sharedBytes = 'shared immutable scientific input\n'
let storageRoot: string

const evidenceDir = (): string => join(storageRoot, 'execution-file-evidence')
const sessionRoot = (project: string, sessionId: string): string =>
  join(evidenceDir(), project, sessionId)

const setup = async (): Promise<void> => {
  storageRoot = await mkdtemp(join(tmpdir(), 'os-compute-batch-recovery-'))
  await writeFile(join(storageRoot, 'input.csv'), sharedBytes)
}

const begin = async (sessionId: string, jobId: string, project = projectId): Promise<Job> => {
  await beginComputeJobFileEvidence({
    storageRoot,
    projectId: project,
    sessionId,
    jobId,
    producerRunId: 'run-producer',
    inputs: [
      { localPath: join(storageRoot, 'input.csv'), dstFilename: 'input.csv', label: 'input.csv' }
    ]
  })
  return {
    project_id: project,
    session_id: sessionId,
    job_id: jobId,
    producer_run_id: 'run-producer',
    status: 'running',
    submitted_at: 1,
    harvested_at: undefined
  }
}

const publish = async (sessionId: string, jobId: string, project = projectId): Promise<Job> => {
  const job = await begin(sessionId, jobId, project)
  return {
    ...job,
    status: 'success',
    harvested_at: 2,
    file_evidence: await publishComputeJobFileEvidence({
      storageRoot,
      projectId: project,
      sessionId,
      jobId,
      producerRunId: 'run-producer',
      outputs: []
    })
  }
}

const readEvidence = async (job: Job): Promise<Buffer> =>
  readFile(join(storageRoot, job.file_evidence!.storageKey!))

const expectSharedBlob = async (job: Job): Promise<void> => {
  const sidecar = JSON.parse((await readEvidence(job)).toString()) as {
    relations: Array<{ generation?: { contentStorageKey: string } }>
  }
  const keys = sidecar.relations.flatMap(({ generation }) =>
    generation ? [generation.contentStorageKey] : []
  )
  expect(keys.length).toBeGreaterThan(0)
  for (const key of keys) {
    expect(await readFile(join(storageRoot, key), 'utf8')).toBe(sharedBytes)
  }
  expect(
    createHash('sha256')
      .update(await readEvidence(job))
      .digest('hex')
  ).toBe(job.file_evidence!.checksum)
  // The Project's content-addressed pool keeps the blob while a committed result links it.
  const pooled = `sha256-${createHash('sha256').update(sharedBytes).digest('hex')}`
  expect(await readFile(join(evidenceDir(), job.project_id, 'blobs', pooled), 'utf8')).toBe(
    sharedBytes
  )
}

// A content-addressed blob that no Session links to any more, as a cleanup interrupted after the
// Session side was removed leaves behind. Startup recovery removes such blobs today.
const plantUnreferencedBlob = async (project: string): Promise<string> => {
  const bytes = `unreferenced blob for ${project}\n`
  const name = `sha256-${createHash('sha256').update(bytes).digest('hex')}`
  const path = join(evidenceDir(), project, 'blobs', name)
  await writeFile(path, bytes)
  return path
}

afterEach(async () => {
  vi.unstubAllEnvs()
  if (storageRoot) await rm(storageRoot, { recursive: true, force: true })
})

// Building a 130-Session fixture launches a few hundred evidence writes on its own.
describe('reconcileComputeJobFileEvidence', { timeout: 120_000 }, () => {
  // A clean restart of a workspace whose Sessions were all recovered on an earlier launch. Two
  // Projects with eight Sessions each must not cost more than one helper per Project, and the
  // pass must still clear an unreferenced blob from each Project's pool.
  it('keeps a clean restart to at most one helper per Project', async () => {
    await setup()
    const jobs: Job[] = []
    for (const project of ['project-a', 'project-b']) {
      for (let index = 0; index < 8; index++) {
        jobs.push(await publish(`session-${index}`, `job-${index}`, project))
      }
    }
    expect(await reconcileComputeJobFileEvidence(storageRoot, jobs)).toEqual({
      removedStagingEntries: 0,
      removedActivityEntries: 0
    })
    const unreferenced = [
      await plantUnreferencedBlob('project-a'),
      await plantUnreferencedBlob('project-b')
    ]

    expect(await coldRecovery(storageRoot, jobs)).toEqual({
      removedStagingEntries: 0,
      removedActivityEntries: 0
    })
    expect(launches()).toBeLessThanOrEqual(2)
    for (const path of unreferenced) expect(existsSync(path)).toBe(false)
    for (const job of jobs) await expectSharedBlob(job)
  })

  // A restart after a crash: one Project with 130 Sessions, most of them holding an abandoned
  // staging entry, and every tenth one a committed result linking the same content blob. The
  // number of helpers must stay far below the Session count while every abandoned entry is
  // reclaimed and every committed result keeps its evidence and the shared blob.
  it('keeps crash recovery of a large Project to a few helpers', async () => {
    await setup()
    const jobs: Job[] = []
    const committed: Job[] = []
    for (let index = 0; index < 130; index++) {
      if (index % 10 === 9) {
        const job = await publish(`session-${index}`, `job-${index}`)
        committed.push(job)
        jobs.push(job)
      } else {
        const job = await begin(`session-${index}`, `job-${index}`)
        job.status = 'error'
        jobs.push(job)
      }
    }
    const committedBytes = await Promise.all(committed.map(readEvidence))

    expect(await coldRecovery(storageRoot, jobs)).toEqual({
      removedStagingEntries: 117,
      removedActivityEntries: 0
    })
    expect(launches()).toBeLessThanOrEqual(16)
    for (const job of jobs) {
      if (job.status === 'error') {
        expect(await readdir(sessionRoot(projectId, job.session_id))).toEqual([])
      }
    }
    for (const [index, job] of committed.entries()) {
      expect(await readEvidence(job)).toEqual(committedBytes[index])
      await expectSharedBlob(job)
    }

    expect(await coldRecovery(storageRoot, jobs)).toEqual({
      removedStagingEntries: 0,
      removedActivityEntries: 0
    })
    expect(launches()).toBeLessThanOrEqual(16)
    for (const job of committed) await expectSharedBlob(job)
  })

  // An abandoned Session listed first and a committed Session listed last share one blob, with
  // 63 recorded Sessions between them that have nothing on disk.
  it('keeps a blob shared by an abandoned and a committed Session far apart in the catalog', async () => {
    await setup()
    const orphan = await begin('session-first', 'job-orphan')
    orphan.status = 'error'
    const committed = await publish('session-last', 'job-retained')
    const jobs: Job[] = [
      orphan,
      ...Array.from({ length: 63 }, (_, index): Job => ({
        project_id: projectId,
        session_id: `session-padding-${index}`,
        job_id: `job-padding-${index}`,
        status: 'running',
        submitted_at: 1,
        harvested_at: undefined
      })),
      committed
    ]

    expect(await reconcileComputeJobFileEvidence(storageRoot, jobs)).toEqual({
      removedStagingEntries: 1,
      removedActivityEntries: 0
    })
    expect(await readdir(sessionRoot(projectId, 'session-first'))).toEqual([])
    await expectSharedBlob(committed)

    expect(await reconcileComputeJobFileEvidence(storageRoot, jobs)).toEqual({
      removedStagingEntries: 0,
      removedActivityEntries: 0
    })
    await expectSharedBlob(committed)
  })

  // An unsafe target in a later Session is never acted on: recovery may stop with an error or
  // leave that Session for a later launch, but nothing outside the root, the unsafe receipt and
  // retained evidence stay as they were, and recovery succeeds once the receipt is repaired.
  it('leaves an unsafe Session target untouched and retries cleanly once repaired', async () => {
    await setup()
    const committed = await publish('session-first', 'job-retained')
    const bad = await begin('session-later', 'job-bad')
    bad.status = 'error'
    const receiptPath = join(sessionRoot(projectId, bad.session_id), 'receipt-job-bad.json')
    const validReceipt = await readFile(receiptPath)
    const outsidePath = join(storageRoot, 'outside', 'keep.txt')
    await mkdir(join(storageRoot, 'outside'))
    await writeFile(outsidePath, 'outside data')
    const corrupt = { ...JSON.parse(validReceipt.toString()), stagingName: '../../outside' }
    await writeFile(receiptPath, JSON.stringify(corrupt))
    const committedBytes = await readEvidence(committed)

    await reconcileComputeJobFileEvidence(storageRoot, [committed, bad]).catch(() => undefined)
    expect(await readFile(outsidePath, 'utf8')).toBe('outside data')
    expect(await readFile(receiptPath, 'utf8')).toBe(JSON.stringify(corrupt))
    expect(await readEvidence(committed)).toEqual(committedBytes)
    await expectSharedBlob(committed)

    await writeFile(receiptPath, validReceipt)
    expect(await reconcileComputeJobFileEvidence(storageRoot, [committed, bad])).toEqual({
      removedStagingEntries: 1,
      removedActivityEntries: 0
    })
    expect(await readdir(sessionRoot(projectId, bad.session_id))).toEqual([])
    expect(await readEvidence(committed)).toEqual(committedBytes)
    expect(await readFile(outsidePath, 'utf8')).toBe('outside data')
  })

  // Over a mixed workspace, recovery removes exactly the abandoned staging and activity entries,
  // keeps committed, live and Notebook evidence, and leaves a job that may still publish alone.
  it('removes exactly the abandoned entries while retaining committed, live, and notebook evidence', async () => {
    await setup()
    const committed = await publish('session-committed', 'job-committed')
    const live = await begin('session-live', 'job-live')
    await begin('session-orphan', 'job-orphan')
    await writeFile(join(storageRoot, 'input.csv'), 'uncommitted orphan bytes')
    await publish('session-uncommitted', 'job-uncommitted')
    await writeFile(join(storageRoot, 'input.csv'), sharedBytes)
    const cancelled = await begin('session-cancelled', 'job-cancelled')
    cancelled.cancellation_status = 'cancelled'
    cancelled.submitted_at = undefined
    const harvested = await begin('session-harvested', 'job-harvested')
    harvested.status = 'success'
    harvested.harvested_at = 2

    const notebookRoot = join(storageRoot, 'notebook')
    const dataRoot = join(notebookRoot, 'data')
    await mkdir(dataRoot, { recursive: true })
    await writeFile(join(dataRoot, 'input.csv'), sharedBytes)
    const observation = await startWorkingFileObservation(
      {
        dataRoot,
        notebookSessionRoot: notebookRoot,
        runId: 'run-notebook',
        fileEvidenceStorageRoot: storageRoot,
        fileEvidenceRoot: sessionRoot(projectId, 'session-notebook'),
        fileEvidenceStoragePrefix: `execution-file-evidence/${projectId}/session-notebook`
      },
      {
        watchDirectory: () => {
          throw Object.assign(new Error('watch unavailable'), { code: 'ENOSPC' })
        }
      }
    )
    const notebook = await observation.finish()
    const notebookPath = join(storageRoot, notebook.fileEvidence.storageKey!)
    const notebookBytes = await readFile(notebookPath)
    const committedBytes = await readEvidence(committed)
    const liveCapturePath = join(
      sessionRoot(projectId, live.session_id),
      'staging-job-live',
      'capture.json'
    )
    const liveCapture = await readFile(liveCapturePath)
    const jobs = [committed, live, cancelled, harvested]

    expect(await reconcileComputeJobFileEvidence(storageRoot, jobs)).toEqual({
      removedStagingEntries: 3,
      removedActivityEntries: 1
    })
    for (const name of ['orphan', 'uncommitted', 'cancelled', 'harvested']) {
      expect(await readdir(sessionRoot(projectId, `session-${name}`))).toEqual([])
    }
    expect(await readdir(sessionRoot(projectId, committed.session_id))).not.toContain(
      'receipt-job-committed.json'
    )
    expect(await readFile(liveCapturePath)).toEqual(liveCapture)
    expect(await readFile(notebookPath)).toEqual(notebookBytes)
    expect(await readdir(sessionRoot(projectId, 'session-notebook'))).toContain(
      'receipt-run-notebook.json'
    )
    expect(await readEvidence(committed)).toEqual(committedBytes)
    await expectSharedBlob(committed)

    expect(await reconcileComputeJobFileEvidence(storageRoot, jobs)).toEqual({
      removedStagingEntries: 0,
      removedActivityEntries: 0
    })
    expect(await readFile(liveCapturePath)).toEqual(liveCapture)
    expect(await readFile(notebookPath)).toEqual(notebookBytes)
    expect(await readEvidence(committed)).toEqual(committedBytes)
    await expectSharedBlob(committed)
  })
})

// Session details recovery at launch, driven through createSessionDetailsOwner's start() and
// shutdown(). The in-memory store follows the persistence contract: a mutation that leaves the
// Session alone returns undefined, a write returns the saved Session.
const deferred = <T>() => {
  let resolve!: (value: T) => void
  const promise = new Promise<T>((resolvePromise) => {
    resolve = resolvePromise
  })
  return { promise, resolve }
}

const baseSession = (id: string, overrides = {}) => ({
  id,
  projectId: 'project-1',
  revision: 1,
  title: 'Fallback title',
  description: 'Fallback description',
  sessionDetailsSource: 'fallback',
  sessionDetailsGeneration: {
    status: 'queued',
    sourceMessageId: 'message-1',
    requestId: 'request-1',
    queuedAt: 10
  },
  cwd: '/private/project',
  status: 'idle',
  messages: [
    {
      id: 'message-1',
      role: 'user',
      content: 'ignored historical content',
      parts: [{ type: 'text', text: 'Investigate' }],
      status: 'complete',
      eventIds: [],
      createdAt: 10,
      updatedAt: 10
    }
  ],
  createdAt: 1,
  updatedAt: 10,
  ...overrides
})

const runningGeneration = {
  status: 'running',
  sourceMessageId: 'message-1',
  requestId: 'request-1',
  queuedAt: 10,
  startedAt: 11,
  frameworkId: 'codex',
  model: 'model-1',
  reasoningEffort: 'low'
}
const branchSource = { sessionId: 'parent', headMessageId: 'message-1' }

const sessionFixtures = {
  running: (id: string) => baseSession(id, { sessionDetailsGeneration: { ...runningGeneration } }),
  'invalid-running': (id: string) =>
    baseSession(id, { sessionDetailsGeneration: { ...runningGeneration }, branchSource }),
  branch: (id: string) => baseSession(id, { branchSource })
}

class MemorySessions {
  readonly records = new Map<string, any>()
  writes: Array<{ id: string; afterShutdown: boolean }> = []
  shutdownStarted = false

  constructor(sessions: any[]) {
    for (const session of sessions) this.records.set(session.id, structuredClone(session))
  }

  async listSessions() {
    return [...this.records.values()].map((session) => structuredClone(session))
  }

  async mutateSession(project: string, sessionId: string, mutation: (session: any) => any) {
    const current = this.records.get(sessionId)
    if (!current || current.projectId !== project) return undefined
    const result = mutation(structuredClone(current))
    if (result.kind === 'unchanged') return undefined
    const saved = { ...result.session, revision: current.revision + 1 }
    this.records.set(sessionId, saved)
    this.writes.push({ id: sessionId, afterShutdown: this.shutdownStarted })
    return structuredClone(saved)
  }
}

const ownerHarness = (sessions: any[]) => {
  const store = new MemorySessions(sessions)
  const generate = vi.fn(async () => ({
    stopReason: 'end_turn',
    output: '{"title":"Generated","description":"Generated summary"}'
  }))
  const publishSession = vi.fn()
  let timestamp = 100
  const owner = createSessionDetailsOwner({
    inference: { generate },
    targets: {
      resolve: async () => ({
        mode: 'admitted',
        frameworkId: 'codex',
        providerId: 'provider-1',
        model: 'model-1',
        reasoningEffort: 'low'
      })
    },
    sessions: store,
    lifecycle: { publish: publishSession },
    log: { info: vi.fn(), warn: vi.fn() },
    now: () => timestamp++,
    shutdownCleanupMs: 0
  })
  return { owner, store, generate, publishSession }
}

// Blocks the first store mutation of startup until released, so shutdown can begin while
// startup recovery is in flight.
const blockFirstMutation = (store: MemorySessions) => {
  const entered = deferred<void>()
  const release = deferred<void>()
  const mutate = store.mutateSession.bind(store)
  let first = true
  store.mutateSession = async (...args) => {
    if (first) {
      first = false
      entered.resolve()
      await release.promise
    }
    return mutate(...args)
  }
  return { entered, release }
}

describe('session details recovery at launch', () => {
  it.each(['invalid-running', 'branch'] as const)(
    'writes nothing after shutdown begins while recovering a %s Session',
    async (kind) => {
      const session = sessionFixtures[kind]('session-1')
      const { owner, store, generate, publishSession } = ownerHarness([session])
      const { entered, release } = blockFirstMutation(store)

      const startup = owner.start()
      await Promise.race([entered.promise, startup.catch(() => undefined)])
      store.shutdownStarted = true
      await owner.shutdown()
      release.resolve()
      await startup.catch(() => undefined)

      expect(store.writes.filter((write) => write.afterShutdown)).toEqual([])
      expect(store.records.get('session-1')).toEqual(session)
      expect(generate).not.toHaveBeenCalled()
      expect(publishSession).not.toHaveBeenCalled()
    }
  )

  // A queued Session is valid when launch lists it but loses its source message before its
  // admission write runs; shutdown begins in between.
  it('writes nothing after shutdown begins while admitting a queued Session', async () => {
    const session = baseSession('session-1')
    const { owner, store, generate, publishSession } = ownerHarness([session])
    const { entered, release } = blockFirstMutation(store)

    const startup = owner.start()
    await Promise.race([entered.promise, startup.catch(() => undefined)])
    const invalidated = {
      ...store.records.get('session-1'),
      messages: [{ ...session.messages[0], id: 'replacement-message' }]
    }
    store.records.set('session-1', invalidated)
    store.shutdownStarted = true
    await owner.shutdown()
    release.resolve()
    await startup.catch(() => undefined)

    expect(store.writes.filter((write) => write.afterShutdown)).toEqual([])
    expect(store.records.get('session-1')).toEqual(invalidated)
    expect(generate).not.toHaveBeenCalled()
    expect(publishSession).not.toHaveBeenCalled()
  })

  it('stops recovering later Sessions once shutdown begins', async () => {
    const sessions = [
      sessionFixtures.running('session-1'),
      sessionFixtures['invalid-running']('session-2'),
      sessionFixtures.branch('session-3')
    ]
    const { owner, store, generate, publishSession } = ownerHarness(sessions)
    const { entered, release } = blockFirstMutation(store)

    const startup = owner.start()
    await Promise.race([entered.promise, startup.catch(() => undefined)])
    store.shutdownStarted = true
    await owner.shutdown()
    release.resolve()
    await startup.catch(() => undefined)

    expect(store.writes.filter((write) => write.afterShutdown)).toEqual([])
    for (const session of sessions) expect(store.records.get(session.id)).toEqual(session)
    expect(generate).not.toHaveBeenCalled()
    expect(publishSession).not.toHaveBeenCalled()
  })

  // Without a shutdown, the same Sessions are recovered at launch: stale authority is cleared
  // from the invalid running and branched Sessions.
  it('still recovers stale Sessions when no shutdown happens', async () => {
    const sessions = [
      sessionFixtures['invalid-running']('session-2'),
      sessionFixtures.branch('session-3')
    ]
    const { owner, store, generate } = ownerHarness(sessions)

    await owner.start()

    // Each stale Session is written, and its stale generation (running, or queued on a branch)
    // is no longer left in that state.
    for (const session of sessions) {
      const saved = store.records.get(session.id)
      expect(saved).not.toEqual(session)
      expect(saved.sessionDetailsGeneration?.status).not.toBe(
        session.sessionDetailsGeneration.status
      )
    }
    expect([...new Set(store.writes.map((write) => write.id))].sort()).toEqual([
      'session-2',
      'session-3'
    ])
    expect(generate).not.toHaveBeenCalled()
    await owner.shutdown()
  })
})
