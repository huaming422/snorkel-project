// @ts-nocheck
// Behavioral verifier for what a whole application launch costs. It runs the real application
// composition (registerIpcHandlers, every module's start()) in-process with the Electron API
// stubbed, over a temporary data root. Session files are written as the bytes the app stores today,
// and Compute history is written through the app's job store and evidence writers. Two things are
// counted on Node's builtin objects, so the counts hold however a module reaches them: helpers
// (child processes of any kind, or worker threads) and opens of Session files. What a launch leaves
// on disk is compared with the layout stored today. No internal call or module is inspected.

import { createHash } from 'node:crypto'
import { existsSync } from 'node:fs'
import { mkdir, mkdtemp, readFile, readdir, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it, vi } from 'vitest'

// Helpers are counted on Node's own builtin objects before any module under test loads, so the
// count holds however a module reaches them (ESM import, require, createRequire, or a dependency
// such as cross-spawn). Every asynchronous child process (spawn, fork, exec, execFile) goes
// through ChildProcess.prototype.spawn; synchronous launches and worker threads are wrapped at
// their exports, and syncBuiltinESMExports() carries the wrappers to ESM importers.
const helpers = vi.hoisted(() => {
  const state = { launches: 0 }
  const childProcess = process.getBuiltinModule('node:child_process')
  const workerThreads = process.getBuiltinModule('node:worker_threads')
  const originalChildSpawn = childProcess.ChildProcess.prototype.spawn
  childProcess.ChildProcess.prototype.spawn = function (...args) {
    state.launches += 1
    return originalChildSpawn.apply(this, args)
  }
  for (const name of ['spawnSync', 'execSync', 'execFileSync']) {
    const original = childProcess[name]
    childProcess[name] = (...args) => {
      state.launches += 1
      return original(...args)
    }
  }
  const OriginalWorker = workerThreads.Worker
  workerThreads.Worker = class CountedWorker extends OriginalWorker {
    constructor(...args) {
      state.launches += 1
      super(...args)
    }
  }
  process.getBuiltinModule('node:module').syncBuiltinESMExports()
  return state
})
const launches = () => helpers.launches
const resetLaunches = () => {
  helpers.launches = 0
}

const env = vi.hoisted(() => {
  // Answers any property or call; awaiting it yields undefined.
  const stub = (): any => {
    const cache = new Map()
    return new Proxy(function () {}, {
      get(_t, prop) {
        if (prop === 'then') return undefined
        if (prop === Symbol.toPrimitive) return () => ''
        if (prop === Symbol.iterator) return function* () {}
        if (!cache.has(prop)) cache.set(prop, stub())
        return cache.get(prop)
      },
      apply: () => stub(),
      construct: () => stub()
    })
  }
  const reads = { counting: false, paths: new Map<string, number>() }
  const fs = process.getBuiltinModule('node:fs')
  const note = (target: unknown) => {
    if (!reads.counting) return
    const path =
      typeof target === 'string'
        ? target
        : target instanceof URL
          ? target.pathname
          : Buffer.isBuffer(target)
            ? target.toString()
            : ''
    if (/\/sessions\/[^/]+\/[^/]+\.json$/.test(path)) {
      reads.paths.set(path, (reads.paths.get(path) ?? 0) + 1)
    }
  }
  const wrap = (owner: any, name: string) => {
    const original = owner[name]
    owner[name] = function (target: unknown, ...rest: unknown[]) {
      note(target)
      return original.call(this, target, ...rest)
    }
  }
  for (const name of ['open', 'openSync', 'readFile', 'readFileSync', 'createReadStream']) wrap(fs, name)
  for (const name of ['open', 'readFile']) wrap(fs.promises, name)
  process.getBuiltinModule('node:module').syncBuiltinESMExports()
  return { dir: '', stub, reads }
})

// The packaged app runs this module inside a worker thread; under test it is never started.
vi.mock('./session-package/inspection-worker-entry?nodeWorker', () => ({
  default: () => env.stub()
}))
vi.mock('electron-updater', () => ({ autoUpdater: env.stub(), default: { autoUpdater: env.stub() } }))
vi.mock('electron', () => {
  const noop = () => undefined
  const emitter = { on: noop, once: noop, off: noop, removeListener: noop, removeAllListeners: noop, emit: noop }
  const app = {
    ...emitter,
    getPath: () => env.dir,
    setPath: noop,
    getVersion: () => '0.0.0',
    getName: () => 'open-science',
    getLocale: () => 'en-US',
    getSystemLocale: () => 'en-US',
    getPreferredSystemLanguages: () => ['en-US'],
    isPackaged: false,
    isReady: () => true,
    whenReady: async () => undefined,
    getAppPath: () => process.cwd(),
    quit: noop,
    exit: noop,
    requestSingleInstanceLock: () => true,
    setAppUserModelId: noop,
    dock: undefined
  }
  const ipcMain = { ...emitter, handle: noop, handleOnce: noop, removeHandler: noop }
  class BrowserWindow {
    static getAllWindows() {
      return []
    }
    static getFocusedWindow() {
      return null
    }
    static fromWebContents() {
      return null
    }
  }
  return {
    default: { app, ipcMain },
    app,
    ipcMain,
    BrowserWindow,
    shell: { openExternal: async () => undefined, openPath: async () => '', showItemInFolder: noop },
    dialog: {
      showOpenDialog: async () => ({ canceled: true, filePaths: [] }),
      showSaveDialog: async () => ({ canceled: true }),
      showMessageBox: async () => ({ response: 0 })
    },
    nativeTheme: { ...emitter, shouldUseDarkColors: false, themeSource: 'system' },
    protocol: { handle: noop, unhandle: noop, registerSchemesAsPrivileged: noop, isProtocolHandled: () => false },
    session: { defaultSession: env.stub(), fromPartition: () => env.stub() },
    webContents: { getAllWebContents: () => [], fromId: () => undefined },
    safeStorage: {
      isEncryptionAvailable: () => false,
      encryptString: (value: string) => Buffer.from(value),
      decryptString: (value: Buffer) => value.toString()
    },
    powerMonitor: { ...emitter },
    powerSaveBlocker: { start: () => 1, stop: noop, isStarted: () => false },
    Notification: class {
      static isSupported() {
        return false
      }
      show() {}
      on() {}
    },
    Menu: { setApplicationMenu: noop, buildFromTemplate: () => ({ popup: noop }) },
    nativeImage: { createFromPath: () => ({ isEmpty: () => true }), createEmpty: () => ({ isEmpty: () => true }) },
    clipboard: { writeText: noop, readText: () => '' },
    screen: { ...emitter, getPrimaryDisplay: () => ({ workAreaSize: { width: 1, height: 1 } }) },
    systemPreferences: { ...emitter },
    utilityProcess: { fork: () => ({ ...emitter, postMessage: noop, kill: () => true }) },
    net: { fetch: async () => new Response('') },
    crashReporter: { start: noop },
    Tray: env.stub(),
    globalShortcut: env.stub(),
    autoUpdater: env.stub(),
    desktopCapturer: env.stub(),
    MessageChannelMain: env.stub()
  }
})

// One application launch on a freshly loaded module graph, the way a new process starts.
const launch = async () => {
  vi.resetModules()
  const { registerIpcHandlers } = await import('./ipc')
  const runtime = await registerIpcHandlers({
    mainEntryPath: join(process.cwd(), 'out/main/index.js'),
    settingsStore: undefined,
    headless: true
  })
  return runtime
}

const message = {
  id: 'message-1',
  role: 'user',
  content: 'Investigate',
  parts: [{ type: 'text', text: 'Investigate' }],
  status: 'complete',
  eventIds: [],
  createdAt: 10,
  updatedAt: 10
}

// A Session file exactly as the app stores it today.
const sessionBytes = (projectId: string, id: string, extra: Record<string, unknown> = {}) => {
  const root = `root-frame-${id}`
  const branch = `message-branch-${id}`
  const segment = `runtime-segment-${id}`
  const file = {
    version: 2,
    session: {
      id,
      projectId,
      title: `Session ${id}`,
      ...extra,
      cwd: '',
      status: 'idle',
      messages: [message],
      createdAt: 1,
      updatedAt: 1,
      revision: 1,
      conversationGraph: {
        schemaVersion: 1,
        rootFrameId: root,
        activeFrameId: root,
        frames: [
          {
            id: root,
            originBindingState: 'root',
            kind: 'root',
            status: 'completed',
            activeBranchId: branch,
            createdAt: 1,
            completedAt: 1
          }
        ],
        branches: [
          { id: branch, agentFrameId: root, headMessageId: 'message-1', createdAt: 1, updatedAt: 1 }
        ],
        messages: [
          {
            ...message,
            agentFrameId: root,
            introducedOnBranchId: branch,
            revisionRootMessageId: 'message-1',
            runtimeSegmentId: segment
          }
        ],
        activities: [],
        activityGroups: [],
        runtimeSegments: [{ id: segment, agentFrameId: root, frameworkId: 'claude-code', startedAt: 1 }]
      },
      activities: []
    }
  }
  return `${JSON.stringify(file, null, 2)}\n`
}

// session-stale's title generation was still running when the app stopped.
const interrupted = {
  title: 'Fallback title',
  description: 'Fallback description',
  sessionDetailsSource: 'fallback',
  sessionDetailsGeneration: {
    status: 'running',
    sourceMessageId: 'message-1',
    requestId: 'request-1',
    queuedAt: 10,
    startedAt: 11,
    frameworkId: 'codex',
    model: 'model-1',
    reasoningEffort: 'low'
  }
}

// A first launch creates the data root; then the Projects are registered and every Session file
// is written as stored bytes, not through the code under test.
const seedWorkspace = async (count: number, projects = ['project-1']) => {
  env.dir = await mkdtemp(join(tmpdir(), 'os-launch-history-'))
  const first = await launch()
  await first.dispose()
  const { resolveConfigRoot } = await import('./storage-root')
  const configRoot = resolveConfigRoot()
  const { getProjectDbClient } = await import('./projects/prisma-client')
  const client = await getProjectDbClient(configRoot)
  const sessionFile = (id: string, projectId = projects[0]) =>
    join(configRoot, 'sessions', projectId, `${id}.json`)
  for (const projectId of projects) {
    await client.project.create({ data: { id: projectId, name: `History ${projectId}` } })
    await mkdir(join(configRoot, 'sessions', projectId), { recursive: true })
    for (let index = 0; index < count; index++) {
      const id = `session-${index}`
      await writeFile(sessionFile(id, projectId), sessionBytes(projectId, id))
    }
  }
  await reinterrupt(configRoot, projects[0])
  return { configRoot, sessionFile }
}

const reinterrupt = async (configRoot: string, projectId = 'project-1') => {
  await writeFile(
    join(configRoot, 'sessions', projectId, 'session-stale.json'),
    sessionBytes(projectId, 'session-stale', interrupted)
  )
}

// Fields of a Session file as the app writes it today when it recovers an interrupted title
// generation, at the top level and inside "session".
const SESSION_FILE_KEYS = ['session', 'version']
const SESSION_KEYS = [
  'id', 'projectId', 'revision', 'title', 'cwd', 'status', 'permissionProfile', 'autoReviewEnabled',
  'memoryEnabled', 'delegationPolicy', 'messages', 'createdAt', 'updatedAt', 'description',
  'sessionDetailsSource', 'conversationGraph', 'activities', 'sessionDetailsGeneration', 'number'
]

// The stored layout of a committed Compute result today: the receipt the evidence writers leave
// and the published evidence file.
const RECEIPT_KEYS = [
  'schemaVersion', 'phase', 'receiptName', 'stagingName', 'finalName', 'activityId',
  'activityKind', 'parentActivityId', 'evidenceId', 'storageKeyPrefix', 'ownershipToken',
  'stagingIdentity', 'captureChecksum', 'finalIdentity'
]
const EVIDENCE_KEYS = [
  'schemaVersion', 'evidenceId', 'activityId', 'activityKind', 'parentActivityId', 'state',
  'observedRoots', 'initialViewState', 'managedRootsFinalState', 'fileReads', 'externalPaths',
  'writerAttribution', 'reasonCodes', 'scientificOutputs', 'relations'
]
const keysOf = async (path: string) => Object.keys(JSON.parse(await readFile(path, 'utf8'))).sort()

// Values a committed result's receipt and evidence file carry today for a given job.
const expectStoredResult = async (
  dataRoot: string,
  job: { projectId: string; sessionId: string; jobId: string },
  withReceipt: boolean
) => {
  const sessionDir = join(dataRoot, 'execution-file-evidence', job.projectId, job.sessionId)
  const identity = {
    activityId: job.jobId,
    activityKind: 'compute-job',
    parentActivityId: 'run-producer',
    evidenceId: `execution-file-evidence-${job.jobId}`
  }
  if (withReceipt) {
    const receiptPath = join(sessionDir, `receipt-${job.jobId}.json`)
    expect(await keysOf(receiptPath)).toEqual([...RECEIPT_KEYS].sort())
    expect(JSON.parse(await readFile(receiptPath, 'utf8'))).toMatchObject({
      schemaVersion: 1,
      phase: 'published',
      receiptName: `receipt-${job.jobId}.json`,
      stagingName: `staging-${job.jobId}`,
      finalName: `activity-${job.jobId}`,
      storageKeyPrefix: `execution-file-evidence/${job.projectId}/${job.sessionId}`,
      ...identity
    })
  }
  const evidencePath = join(sessionDir, `activity-${job.jobId}`, 'evidence.json')
  expect(await keysOf(evidencePath)).toEqual([...EVIDENCE_KEYS].sort())
  expect(JSON.parse(await readFile(evidencePath, 'utf8'))).toMatchObject({ schemaVersion: 1, ...identity })
}

const sharedBytes = 'shared immutable scientific input\n'
const blobName = (bytes: string) => `sha256-${createHash('sha256').update(bytes).digest('hex')}`

// Writes Compute history through the app's job store and evidence writers. A committed job has a
// published result; a half-saved job finished on the host, but its output was still being saved
// into the Session when the app went down.
const seedJobs = async (
  configRoot: string,
  jobs: Array<{ projectId: string; sessionId: string; jobId: string; committed: boolean; bytes: string }>
) => {
  const { resolveDataRoot } = await import('./storage-root')
  const dataRoot = resolveDataRoot()
  await mkdir(dataRoot, { recursive: true })
  const { getProjectDbClient } = await import('./projects/prisma-client')
  const { ComputeJobRepository } = await import('./compute/job-repository')
  const repository = new ComputeJobRepository(() => getProjectDbClient(configRoot))
  const evidence = await import('./notebook/working-file-observer')
  const input = join(env.dir, 'input.csv')
  for (const job of jobs) {
    await writeFile(input, job.bytes)
    await repository.create({
      id: job.jobId,
      providerId: 'provider-1',
      shape: 'direct_ssh',
      sessionId: job.sessionId,
      projectId: job.projectId,
      intent: 'analysis',
      command: 'run',
      commandHash: 'hash',
      producerRunId: 'run-producer',
      allowUnencryptedPersistence: true,
      initialStatus: 'running'
    })
    const request = {
      storageRoot: dataRoot,
      projectId: job.projectId,
      sessionId: job.sessionId,
      jobId: job.jobId,
      producerRunId: 'run-producer'
    }
    await evidence.beginComputeJobFileEvidence({
      ...request,
      inputs: [{ localPath: input, dstFilename: 'input.csv', label: 'input.csv' }]
    })
    if (job.committed) {
      const fileEvidence = await evidence.publishComputeJobFileEvidence({ ...request, outputs: [] })
      await repository.update(job.jobId, { status: 'success', harvestedAt: new Date(2), fileEvidence })
      await expectStoredResult(dataRoot, job, true)
    } else {
      await repository.update(job.jobId, { status: 'success', harvestedAt: new Date(2) })
      // A half-saved output's receipt as stored today: still capturing, no final folder yet.
      const receiptPath = join(dataRoot, 'execution-file-evidence', job.projectId, job.sessionId, `receipt-${job.jobId}.json`)
      expect(await keysOf(receiptPath)).toEqual(RECEIPT_KEYS.filter((key) => key !== 'finalIdentity').sort())
      expect(JSON.parse(await readFile(receiptPath, 'utf8'))).toMatchObject({
        schemaVersion: 1,
        phase: 'capturing',
        receiptName: `receipt-${job.jobId}.json`,
        stagingName: `staging-${job.jobId}`,
        finalName: `activity-${job.jobId}`,
        activityId: job.jobId,
        activityKind: 'compute-job',
        parentActivityId: 'run-producer',
        evidenceId: `execution-file-evidence-${job.jobId}`,
        storageKeyPrefix: `execution-file-evidence/${job.projectId}/${job.sessionId}`
      })
    }
  }
  return dataRoot
}

const committedEvidence = (dataRoot: string, job: { projectId: string; sessionId: string; jobId: string }) =>
  join(dataRoot, 'execution-file-evidence', job.projectId, job.sessionId, `activity-${job.jobId}`, 'evidence.json')

const stagingLeft = async (dataRoot: string, projectId: string) => {
  const projectRoot = join(dataRoot, 'execution-file-evidence', projectId)
  let left = 0
  for (const session of await readdir(projectRoot)) {
    if (session === 'blobs' || session.startsWith('.')) continue
    for (const entry of await readdir(join(projectRoot, session))) {
      if (entry.startsWith('staging-')) left++
    }
  }
  return left
}

const staleStatusAfter = async (configRoot: string) =>
  JSON.parse(await readFile(join(configRoot, 'sessions', 'project-1', 'session-stale.json'), 'utf8'))
    .session.sessionDetailsGeneration?.status

afterEach(async () => {
  env.reads.counting = false
  env.reads.paths.clear()
  resetLaunches()
  // Each test seeds its own directory; cleanup is best effort because disposed owners may still
  // be finishing a background write.
  if (env.dir) {
    await rm(env.dir, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 }).catch(
      () => undefined
    )
  }
})

describe('launch reads of the recorded Session history', { timeout: 240_000 }, () => {
  // Today every Session file is opened three times per launch. A relaunch must open each file at
  // most twice, leave the files it has nothing to recover untouched, and still recover the Session
  // whose title generation was cut off, writing it back in today's layout.
  it('opens each Session file at most twice per launch and still recovers stale Sessions', async () => {
    const { configRoot, sessionFile } = await seedWorkspace(6)
    // The app has run once since these Sessions were written, so the measured launch is a clean
    // restart; that launch also recovers session-stale, so it is written again as interrupted.
    const warm = await launch()
    await warm.dispose()
    expect(await staleStatusAfter(configRoot)).not.toBe('running')
    await reinterrupt(configRoot)

    const ids = ['session-0', 'session-1', 'session-2', 'session-3', 'session-4', 'session-5']
    const before = await Promise.all(ids.map((id) => readFile(sessionFile(id), 'utf8')))
    env.reads.paths.clear()
    env.reads.counting = true
    const runtime = await launch()
    await runtime.dispose()
    env.reads.counting = false

    // Only Sessions with nothing to recover are bounded: recovering session-stale rewrites it,
    // and it cannot be recovered without being read.
    for (const [index, id] of ids.entries()) {
      expect(env.reads.paths.get(sessionFile(id)) ?? 0, `${id} opens`).toBeLessThanOrEqual(2)
      expect(await readFile(sessionFile(id), 'utf8'), `${id} bytes`).toBe(before[index])
    }
    expect(env.reads.paths.get(sessionFile('session-stale')) ?? 0).toBeGreaterThanOrEqual(1)
    expect(await staleStatusAfter(configRoot)).not.toBe('running')
    expect(await keysOf(sessionFile('session-stale'))).toEqual(SESSION_FILE_KEYS)
    const stored = JSON.parse(await readFile(sessionFile('session-stale'), 'utf8'))
    expect(stored.version).toBe(2)
    expect(Object.keys(stored.session).sort()).toEqual([...SESSION_KEYS].sort())
  })

  // A damaged Session file in the history must not stop launch from recovering the others.
  it('still recovers stale Sessions when another Session file is damaged', async () => {
    const { configRoot, sessionFile } = await seedWorkspace(3)
    await writeFile(sessionFile('session-1'), '{ "id": "session-1", ')

    const runtime = await launch()
    await runtime.dispose()

    expect(await staleStatusAfter(configRoot)).not.toBe('running')
  })
})

describe('launch helpers for recorded Compute history', { timeout: 300_000 }, () => {
  // A clean restart of two Projects with eight Sessions each, every Session holding one saved
  // Compute result, starts at most two helpers, still clears a stored file copy no Session uses,
  // and leaves every saved result as stored.
  it('keeps a clean restart to at most two helpers', async () => {
    const projects = ['project-a', 'project-b']
    const { configRoot } = await seedWorkspace(0, projects)
    const jobs = projects.flatMap((projectId) =>
      Array.from({ length: 8 }, (_, index) => ({
        projectId,
        sessionId: `session-${index}`,
        jobId: `job-${projectId}-${index}`,
        committed: true,
        bytes: sharedBytes
      }))
    )
    const dataRoot = await seedJobs(configRoot, jobs)
    const warm = await launch()
    await warm.dispose()
    const unreferenced = []
    for (const projectId of projects) {
      const bytes = `no Session uses this copy in ${projectId}\n`
      const path = join(dataRoot, 'execution-file-evidence', projectId, 'blobs', blobName(bytes))
      await writeFile(path, bytes)
      unreferenced.push(path)
    }
    const stored = await Promise.all(jobs.map((job) => readFile(committedEvidence(dataRoot, job))))

    resetLaunches()
    const runtime = await launch()
    await runtime.dispose()

    expect(launches()).toBeLessThanOrEqual(2)
    for (const path of unreferenced) expect(existsSync(path)).toBe(false)
    for (const [index, job] of jobs.entries()) {
      expect(await readFile(committedEvidence(dataRoot, job))).toEqual(stored[index])
      await expectStoredResult(dataRoot, job, false)
    }
    for (const projectId of projects) {
      const pooled = join(dataRoot, 'execution-file-evidence', projectId, 'blobs', blobName(sharedBytes))
      expect(await readFile(pooled, 'utf8')).toBe(sharedBytes)
    }
  })

  // The app went down while 117 of a Project's 130 Sessions were still saving the output of a
  // finished Compute job. The next launch starts at most 16 helpers, clears every half-saved
  // output and every stored file copy only that output used, and keeps the 13 saved results.
  // Each half-saved output staged its own bytes, so reclaiming any one of them frees a blob.
  it('keeps the launch after a crash to at most 16 helpers', async () => {
    const { configRoot } = await seedWorkspace(0)
    const jobs = Array.from({ length: 130 }, (_, index) => {
      const committed = index % 10 === 9
      return {
        projectId: 'project-1',
        sessionId: `session-${index}`,
        jobId: `job-${index}`,
        committed,
        bytes: committed ? sharedBytes : `output only job-${index} staged\n`
      }
    })
    const dataRoot = await seedJobs(configRoot, jobs)
    const pool = join(dataRoot, 'execution-file-evidence', 'project-1', 'blobs')
    const halfSavedOnly = jobs
      .filter((job) => job.bytes !== sharedBytes)
      .map((job) => join(pool, blobName(job.bytes)))
    for (const path of halfSavedOnly) expect(existsSync(path)).toBe(true)
    const committed = jobs.filter((job) => job.committed)
    const stored = await Promise.all(committed.map((job) => readFile(committedEvidence(dataRoot, job))))
    expect(await stagingLeft(dataRoot, 'project-1')).toBe(117)

    resetLaunches()
    const runtime = await launch()
    // Recovery may finish after start-up returns; wait for it before shutting down.
    for (let waited = 0; waited < 120_000 && (await stagingLeft(dataRoot, 'project-1')) > 0; waited += 250) {
      await new Promise((resolve) => setTimeout(resolve, 250))
    }
    // With this much history other launch work can still be settling; the app's own one-second
    // disposal limit is not what this test measures. Helpers are counted once shutdown is done.
    await runtime.dispose().catch(() => undefined)

    expect(launches()).toBeLessThanOrEqual(16)
    expect(await stagingLeft(dataRoot, 'project-1')).toBe(0)
    for (const path of halfSavedOnly) expect(existsSync(path)).toBe(false)
    for (const [index, job] of committed.entries()) {
      expect(await readFile(committedEvidence(dataRoot, job))).toEqual(stored[index])
      await expectStoredResult(dataRoot, job, false)
    }
    expect(await readFile(join(pool, blobName(sharedBytes)), 'utf8')).toBe(sharedBytes)
  })
})
