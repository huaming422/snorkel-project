// @ts-nocheck
// Behavioral verifier for how often a launch reads the recorded Session history. It runs the
// real application composition (registerIpcHandlers, every module's start()) in-process with the
// Electron API stubbed, over a temporary data root seeded through the repository's own writers.
// Every open or read of a Session file is counted on Node's builtin fs objects, so the count holds
// however the history is loaded. No internal call or module is inspected.

import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it, vi } from 'vitest'

const env = vi.hoisted(() => {
  // Answers any property or call; awaiting it yields undefined.
  const stub = (): any => {
    const cache = new Map()
    return new Proxy(function () {}, {
      get(_t, prop) {
        if (prop === 'then') return undefined
        if (prop === Symbol.toPrimitive) return () => ''
        if (prop === Symbol.iterator) return function* () {}
        if (!cache.has(prop)) cache.set(prop, stub())
        return cache.get(prop)
      },
      apply: () => stub(),
      construct: () => stub()
    })
  }
  const reads = { counting: false, paths: new Map<string, number>() }
  const fs = process.getBuiltinModule('node:fs')
  const note = (target: unknown) => {
    if (!reads.counting) return
    const path =
      typeof target === 'string'
        ? target
        : target instanceof URL
          ? target.pathname
          : Buffer.isBuffer(target)
            ? target.toString()
            : ''
    if (/\/sessions\/[^/]+\/[^/]+\.json$/.test(path)) {
      reads.paths.set(path, (reads.paths.get(path) ?? 0) + 1)
    }
  }
  const wrap = (owner: any, name: string) => {
    const original = owner[name]
    owner[name] = function (target: unknown, ...rest: unknown[]) {
      note(target)
      return original.call(this, target, ...rest)
    }
  }
  for (const name of ['open', 'openSync', 'readFile', 'readFileSync', 'createReadStream']) wrap(fs, name)
  for (const name of ['open', 'readFile']) wrap(fs.promises, name)
  process.getBuiltinModule('node:module').syncBuiltinESMExports()
  return { dir: '', stub, reads }
})

// The packaged app runs this module inside a worker thread; under test it is never started.
vi.mock('./session-package/inspection-worker-entry?nodeWorker', () => ({
  default: () => env.stub()
}))
vi.mock('electron-updater', () => ({ autoUpdater: env.stub(), default: { autoUpdater: env.stub() } }))
vi.mock('electron', () => {
  const noop = () => undefined
  const emitter = { on: noop, once: noop, off: noop, removeListener: noop, removeAllListeners: noop, emit: noop }
  const app = {
    ...emitter,
    getPath: () => env.dir,
    setPath: noop,
    getVersion: () => '0.0.0',
    getName: () => 'open-science',
    getLocale: () => 'en-US',
    getSystemLocale: () => 'en-US',
    getPreferredSystemLanguages: () => ['en-US'],
    isPackaged: false,
    isReady: () => true,
    whenReady: async () => undefined,
    getAppPath: () => process.cwd(),
    quit: noop,
    exit: noop,
    requestSingleInstanceLock: () => true,
    setAppUserModelId: noop,
    dock: undefined
  }
  const ipcMain = { ...emitter, handle: noop, handleOnce: noop, removeHandler: noop }
  class BrowserWindow {
    static getAllWindows() {
      return []
    }
    static getFocusedWindow() {
      return null
    }
    static fromWebContents() {
      return null
    }
  }
  return {
    default: { app, ipcMain },
    app,
    ipcMain,
    BrowserWindow,
    shell: { openExternal: async () => undefined, openPath: async () => '', showItemInFolder: noop },
    dialog: {
      showOpenDialog: async () => ({ canceled: true, filePaths: [] }),
      showSaveDialog: async () => ({ canceled: true }),
      showMessageBox: async () => ({ response: 0 })
    },
    nativeTheme: { ...emitter, shouldUseDarkColors: false, themeSource: 'system' },
    protocol: { handle: noop, unhandle: noop, registerSchemesAsPrivileged: noop, isProtocolHandled: () => false },
    session: { defaultSession: env.stub(), fromPartition: () => env.stub() },
    webContents: { getAllWebContents: () => [], fromId: () => undefined },
    safeStorage: {
      isEncryptionAvailable: () => false,
      encryptString: (value: string) => Buffer.from(value),
      decryptString: (value: Buffer) => value.toString()
    },
    powerMonitor: { ...emitter },
    powerSaveBlocker: { start: () => 1, stop: noop, isStarted: () => false },
    Notification: class {
      static isSupported() {
        return false
      }
      show() {}
      on() {}
    },
    Menu: { setApplicationMenu: noop, buildFromTemplate: () => ({ popup: noop }) },
    nativeImage: { createFromPath: () => ({ isEmpty: () => true }), createEmpty: () => ({ isEmpty: () => true }) },
    clipboard: { writeText: noop, readText: () => '' },
    screen: { ...emitter, getPrimaryDisplay: () => ({ workAreaSize: { width: 1, height: 1 } }) },
    systemPreferences: { ...emitter },
    utilityProcess: { fork: () => ({ ...emitter, postMessage: noop, kill: () => true }) },
    net: { fetch: async () => new Response('') },
    crashReporter: { start: noop },
    Tray: env.stub(),
    globalShortcut: env.stub(),
    autoUpdater: env.stub(),
    desktopCapturer: env.stub(),
    MessageChannelMain: env.stub()
  }
})

// One application launch on a freshly loaded module graph, the way a new process starts.
const launch = async () => {
  vi.resetModules()
  const { registerIpcHandlers } = await import('./ipc')
  const runtime = await registerIpcHandlers({
    mainEntryPath: join(process.cwd(), 'out/main/index.js'),
    settingsStore: undefined,
    headless: true
  })
  return runtime
}

const message = {
  id: 'message-1',
  role: 'user',
  content: 'Investigate',
  parts: [{ type: 'text', text: 'Investigate' }],
  status: 'complete',
  eventIds: [],
  createdAt: 10,
  updatedAt: 10
}

// Seeds a workspace through the app's own writers: a first launch creates the data root, then
// one Project and its Sessions are written with the repository, as the app saves them.
const seedWorkspace = async (count: number) => {
  env.dir = await mkdtemp(join(tmpdir(), 'os-launch-history-'))
  const first = await launch()
  await first.dispose()
  const { resolveConfigRoot } = await import('./storage-root')
  const configRoot = resolveConfigRoot()
  const { getProjectDbClient } = await import('./projects/prisma-client')
  const client = await getProjectDbClient(configRoot)
  await client.project.create({ data: { id: 'project-1', name: 'History' } })
  const { SessionRepository } = await import('./session-persistence/repository')
  const repository = new SessionRepository(configRoot)
  for (let index = 0; index < count; index++) {
    await repository.saveSession({
      id: `session-${index}`,
      projectId: 'project-1',
      title: `Session ${index}`,
      cwd: '',
      status: 'idle',
      messages: [message],
      createdAt: 1,
      updatedAt: 1
    })
  }
  await reinterrupt(configRoot)
  return { configRoot, sessionFile: (id: string) => join(configRoot, 'sessions', 'project-1', `${id}.json`) }
}

// Writes session-stale as a Session whose title generation was still running when the app stopped.
const reinterrupt = async (configRoot: string) => {
  const { SessionRepository } = await import('./session-persistence/repository')
  await new SessionRepository(configRoot).saveSession({
    id: 'session-stale',
    projectId: 'project-1',
    title: 'Fallback title',
    description: 'Fallback description',
    sessionDetailsSource: 'fallback',
    sessionDetailsGeneration: {
      status: 'running',
      sourceMessageId: 'message-1',
      requestId: 'request-1',
      queuedAt: 10,
      startedAt: 11,
      frameworkId: 'codex',
      model: 'model-1',
      reasoningEffort: 'low'
    },
    cwd: '',
    status: 'idle',
    messages: [message],
    createdAt: 1,
    updatedAt: 1
  })
}

const staleStatusAfter = async (configRoot: string) => {
  const { SessionRepository } = await import('./session-persistence/repository')
  const saved = await new SessionRepository(configRoot).loadSession('project-1', 'session-stale')
  return saved?.sessionDetailsGeneration?.status
}

afterEach(async () => {
  env.reads.counting = false
  env.reads.paths.clear()
  // Each test seeds its own directory; cleanup is best effort because disposed owners may still
  // be finishing a background write.
  if (env.dir) {
    await rm(env.dir, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 }).catch(
      () => undefined
    )
  }
})

describe('launch reads of the recorded Session history', { timeout: 240_000 }, () => {
  // Today every Session file is opened three times per launch; two of those are the same full
  // catalog load. A relaunch must open each file at most twice and still recover the Session
  // whose title generation was cut off.
  it('opens each Session file at most twice per launch and still recovers stale Sessions', async () => {
    const { configRoot, sessionFile } = await seedWorkspace(6)
    // The app has run once since these Sessions were written, so the measured launch is a clean
    // restart; that launch also recovers session-stale, so it is written again as interrupted.
    const warm = await launch()
    await warm.dispose()
    expect(await staleStatusAfter(configRoot)).toBe('failed')
    await reinterrupt(configRoot)

    env.reads.paths.clear()
    env.reads.counting = true
    const runtime = await launch()
    env.reads.counting = false
    await runtime.dispose()

    // Only Sessions with nothing to recover are counted: recovering session-stale rewrites it.
    const ids = ['session-0', 'session-1', 'session-2', 'session-3', 'session-4', 'session-5']
    for (const id of ids) {
      const opened = env.reads.paths.get(sessionFile(id)) ?? 0
      expect(opened, `${id} opens`).toBeGreaterThanOrEqual(1)
      expect(opened, `${id} opens`).toBeLessThanOrEqual(2)
    }
    expect(await staleStatusAfter(configRoot)).toBe('failed')
  })

  // A damaged Session file in the history must not stop launch from recovering the others.
  it('still recovers stale Sessions when another Session file is damaged', async () => {
    const { configRoot, sessionFile } = await seedWorkspace(3)
    await writeFile(sessionFile('session-1'), '{ "id": "session-1", ')

    const runtime = await launch()
    await runtime.dispose()

    expect(await staleStatusAfter(configRoot)).toBe('failed')
  })
})
