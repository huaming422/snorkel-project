## Task

Some codex sessions on the HTTP responses bridge never get out of the "cooling down" 503. It starts with a turn that gets interrupted partway through. From then on every attempt for that session fails again and the cooldown just keeps getting longer. Deleting only the retry-circuit rows doesn't help, the cooldown is back within a couple of requests. What frees the session is wiping its stored bridge state in the db, so it stops trying to continue from the old previous response. Sessions like this used to recover by themselves.

What we see in the logs for a stuck session:

- Most of the failures are `stream_incomplete` with zero response events, and by then usually no client is waiting on the session anymore. Some are idle timeouts with zero response events.
- Right after the interruption, upstream sometimes rejects the session's previous response with a frame that has no `code`: either the not-found identity is only in `type` (`"type": "previous_response_not_found"`), or it's just the bare message ``Invalid `previous_response_id`.`` with no code or param. Those go down the generic transport-failure path instead of the recovery we do for the same rejection when it does have a code.

What we expect:

- A previous-response rejection gets the same recovery whichever of those shapes it comes in. Other invalid-request errors stay as they are.
- Once a session has failed `CODEX_LB_HTTP_RESPONSES_SESSION_BRIDGE_ANCHOR_POISON_FAILURE_THRESHOLD` times in a row (default 7, leave it at that) with no response events, whether the stream ended incomplete or went idle, the bridge gives up on the stored continuation and wipes it, so the next turn starts fresh. That should happen on the failure that reaches the threshold, whether or not a client is waiting. It's the same wipe the bridge already does when it gives up after idle timeouts while a client is waiting. If a client is waiting, that failure is also the one that retires the session, not an earlier one.
- If the wipe doesn't take effect (another owner fenced the write), the next such failure tries again, and every attempt that doesn't take effect is logged as `durable_anchor_poison_clear_failed`.
- Clean upstream closes (close code 1000 before any response event) and failures where response events did come back never count toward giving up.

There's also a separate hang where an operation gets recorded but never receives a status. Leave that one alone, this is only about the sessions stuck cooling down.
