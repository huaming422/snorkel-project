"""Behavioral checks for HTTP responses-bridge sessions that stay cooling down.

An anchored bridge session that keeps failing without a single response event
has to give up on its stored previous-response continuation once the
configured number of consecutive failures is reached, whether or not a client
is waiting on the session at that moment. Upstream rejections of the previous
response have to reach in-place recovery whatever shape the error frame has.

Everything is driven through code paths the service already uses at runtime:

  * ``proxy_service._http_bridge_should_attempt_local_previous_response_recovery(exc)``,
    the predicate the bridge consults when an interrupted session gets an
    upstream rejection;
  * ``ProxyService._fail_http_bridge_reader_and_maybe_retire(session, ...)``,
    the reader-failure path every upstream stream failure goes through, with
    and without a client waiting on the session;
  * ``ProxyService._retire_stale_pending_http_bridge_session(session, ...)``,
    called only the way the reader path itself calls it on a clean close.

Outcomes are read from observable effects only: the predicate's boolean, the
fenced durable write that wipes stored continuity
(``rebind_session_account(..., clear_continuity=True)`` on the durable
coordinator), the reader path's "retired" result, and the
``durable_anchor_poison_clear_failed`` log event operators already alert on.
No helper or detail string a solution might add is imported or asserted.

The give-up threshold is read from settings at runtime; one guard checks that
its default is unchanged.

Sessions are built the way the repository's own bridge unit tests build them
(service on a ``nullcontext`` stub, ``SimpleNamespace``/``AsyncMock`` doubles),
so no database, network or running service is needed.
"""

from __future__ import annotations

import asyncio
import logging
import os
import tempfile
from collections import deque
from contextlib import nullcontext
from types import SimpleNamespace
from typing import Any, cast
from unittest.mock import AsyncMock

# Importing the service package pulls in the database-session module, which
# reads settings at import time. This file runs outside the repository's own
# test tree (its ``conftest.py`` is not loaded), so point the database at a
# throwaway sqlite file and disable the background schedulers/bridge up front,
# the same import-time environment the repository's unit tests establish. The
# tests below stub the durable coordinator and never touch a database.
os.environ.setdefault(
    "CODEX_LB_DATABASE_URL",
    f"sqlite+aiosqlite:///{tempfile.mkdtemp(prefix='codex-lb-verify-')}/codex-lb.db",
)
for _flag in (
    "CODEX_LB_USAGE_REFRESH_ENABLED",
    "CODEX_LB_MODEL_REGISTRY_ENABLED",
    "CODEX_LB_STICKY_SESSION_CLEANUP_ENABLED",
    "CODEX_LB_HTTP_RESPONSES_SESSION_BRIDGE_ENABLED",
    "CODEX_LB_QUOTA_PLANNER_SCHEDULER_ENABLED",
    "CODEX_LB_AUTOMATIONS_SCHEDULER_ENABLED",
):
    os.environ.setdefault(_flag, "false")

import anyio  # noqa: E402
import pytest  # noqa: E402

# Pre-existing modules only. ``proxy_module`` owns the error type; the error
# codes and failure kinds used below are the repository's own vocabulary.
import app.core.clients.proxy as proxy_module  # noqa: E402
from app.db.models import AccountStatus  # noqa: E402
from app.modules.proxy import service as proxy_service  # noqa: E402


def _give_up_threshold() -> int:
    """Consecutive-failure give-up threshold, read from settings at runtime."""
    return proxy_service.get_settings().http_responses_session_bridge_anchor_poison_failure_threshold


# --------------------------------------------------------------------------- #
# Doubles: mirror the repo's in-tree bridge-session construction
# --------------------------------------------------------------------------- #
def _make_bridge_session(
    *,
    key_value: str,
    durable_session_id: str,
    owner_epoch: int,
    response_events: int = 0,
) -> "proxy_service._HTTPBridgeSession":
    """A hard-affinity (``session_header``) bridge session with one pending owner.

    Hard keys are the ones the retry circuit accumulates strikes for, the same
    construction the repository's own bridge unit tests use. The session holds
    the durable identity of an anchored conversation.
    """
    session_key = proxy_service._HTTPBridgeSessionKey("session_header", key_value, None)
    pending: "deque[proxy_service._WebSocketRequestState]" = deque([_make_owner(response_events)])
    session = proxy_service._HTTPBridgeSession(
        key=session_key,
        headers={"x-codex-session-id": key_value},
        affinity=proxy_service._AffinityPolicy(
            key=key_value,
            kind=proxy_service.StickySessionKind.CODEX_SESSION,
        ),
        request_model="gpt-5.2",
        account=cast(
            Any,
            SimpleNamespace(
                id="acc-bridge",
                chatgpt_account_id="workspace-bridge",
                status=AccountStatus.ACTIVE,
                plan_type="plus",
            ),
        ),
        upstream=cast(Any, SimpleNamespace(close=AsyncMock())),
        upstream_control=proxy_service._WebSocketUpstreamControl(),
        pending_requests=pending,
        pending_lock=anyio.Lock(),
        response_create_gate=asyncio.Semaphore(1),
        queued_request_count=1,
        last_used_at=1.0,
        idle_ttl_seconds=120.0,
    )
    session.durable_session_id = durable_session_id
    session.durable_owner_epoch = owner_epoch
    return session


def _make_owner(response_events: int) -> "proxy_service._WebSocketRequestState":
    """The pending request the failure lands on; eventless unless told otherwise."""
    state = proxy_service._WebSocketRequestState(
        request_id="req-bridge-owner",
        model="gpt-5.6-sol",
        service_tier=None,
        reasoning_effort="high",
        api_key_reservation=None,
        started_at=-10_000.0,
        transport="http",
        response_create_gate=asyncio.Semaphore(0),
        response_create_gate_acquired=True,
        awaiting_response_created=response_events == 0,
        response_create_sent_at=100.0,
        event_queue=asyncio.Queue(),
    )
    state.response_event_count = response_events
    return state


def _durable_bridge_double(*, clear_succeeds: bool) -> SimpleNamespace:
    """Stand-in for the durable-continuity coordinator.

    ``rebind_session_account`` is the fenced write that wipes stored
    continuity; its return models whether the fenced write took effect.
    """
    return SimpleNamespace(
        lookup_retry_circuit=AsyncMock(return_value=None),
        persist_retry_circuit=AsyncMock(return_value=None),
        clear_retry_circuit=AsyncMock(),
        rebind_session_account=AsyncMock(return_value=clear_succeeds),
    )


def _new_service(
    monkeypatch: pytest.MonkeyPatch,
    *,
    clear_succeeds: bool = True,
) -> tuple["proxy_service.ProxyService", SimpleNamespace]:
    service = proxy_service.ProxyService(cast(Any, nullcontext()))
    durable_bridge = _durable_bridge_double(clear_succeeds=clear_succeeds)
    service._durable_bridge = durable_bridge
    # Process effects only: failing the pending callers and closing the upstream
    # socket are the same doubles the repository's reader-path tests install.
    monkeypatch.setattr(service, "_fail_pending_websocket_requests", AsyncMock())
    monkeypatch.setattr(service, "_close_http_bridge_session_bounded", AsyncMock())
    return service, durable_bridge


def _continuity_wipes(durable_bridge: SimpleNamespace) -> list[Any]:
    return [
        call
        for call in durable_bridge.rebind_session_account.await_args_list
        if call.kwargs.get("clear_continuity") is True
    ]


async def _fail_unattended(
    service: "proxy_service.ProxyService",
    *,
    key_value: str,
    durable_session_id: str,
    owner_epoch: int,
    error_code: str,
    times: int,
    response_events: int = 0,
    upstream_close_code: int | None = None,
) -> None:
    """Fail the same conversation ``times`` times with nobody waiting on it.

    Each failure arrives on a fresh session object for the same bridge key and
    durable identity, as it does in production after every retirement.
    """
    for _ in range(times):
        session = _make_bridge_session(
            key_value=key_value,
            durable_session_id=durable_session_id,
            owner_epoch=owner_epoch,
            response_events=response_events,
        )
        await service._fail_http_bridge_reader_and_maybe_retire(
            session,
            error_code=error_code,
            error_message="Upstream websocket closed before response.completed",
            upstream_close_code=upstream_close_code,
            response_events_seen=response_events,
        )


# --------------------------------------------------------------------------- #
# Previous-response rejections reach in-place recovery
# --------------------------------------------------------------------------- #
def test_previous_response_rejections_reach_recovery_whatever_their_shape() -> None:
    """Two rejection frames an interrupted session receives from upstream:

      * a terse, parameterless ``Invalid `previous_response_id`.`` rejection
        with no ``code``, and
      * a not-found rejection whose identity is only in ``type``.

    Both are previous-response rejections and must route into in-place
    recovery (``True``). Two neighbours must keep their answer: an unrelated
    invalid request (``False``) and the coded not-found frame (``True``).
    """
    gate = proxy_service._http_bridge_should_attempt_local_previous_response_recovery

    terse_parameterless = proxy_module.ProxyResponseError(
        400,
        {"error": {"type": "invalid_request_error", "message": "Invalid `previous_response_id`."}},
    )
    type_only_not_found = proxy_module.ProxyResponseError(
        404,
        {
            "error": {
                "type": "previous_response_not_found",
                "message": "Previous response with id 'resp_prev_anchor' not found.",
            }
        },
    )
    coded_not_found = proxy_module.ProxyResponseError(
        404,
        {
            "error": {
                "type": "invalid_request_error",
                "code": "previous_response_not_found",
                "message": "Previous response with id 'resp_prev_anchor' not found.",
            }
        },
    )
    unrelated = proxy_module.ProxyResponseError(
        400,
        {
            "error": {
                "type": "invalid_request_error",
                "code": "invalid_request_error",
                "message": "Invalid request payload",
                "param": "previous_response_id",
            }
        },
    )

    assert gate(terse_parameterless) is True, (
        "A terse parameterless invalid-previous-response rejection must route "
        "into in-place recovery; it was treated as a transport failure instead."
    )
    assert gate(type_only_not_found) is True, (
        "A previous-response-not-found rejection whose identity is only in the "
        "frame's type must route into in-place recovery."
    )
    assert gate(coded_not_found) is True
    assert gate(unrelated) is False, (
        "An unrelated rejection with no previous-response signal must not be treated as recoverable."
    )


# --------------------------------------------------------------------------- #
# Giving up on the stored continuation
# --------------------------------------------------------------------------- #
async def test_waiting_client_session_gives_up_after_repeated_incomplete_streams(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """With a client waiting on the session, ``threshold`` consecutive eventless
    incomplete streams must wipe the stored continuity exactly once, on the
    threshold-th failure, and only that failure retires the session.
    """
    threshold = _give_up_threshold()
    service, durable_bridge = _new_service(monkeypatch)
    monkeypatch.setattr(service, "_retire_stale_pending_http_bridge_session", AsyncMock())
    session = _make_bridge_session(
        key_value="bridge-waiting-incomplete",
        durable_session_id="durable-waiting-incomplete",
        owner_epoch=3,
    )
    session.admission_waiter_count = 1

    for failure_number in range(1, threshold + 1):
        retired = await service._fail_http_bridge_reader_and_maybe_retire(
            session,
            error_code="stream_incomplete",
            error_message="Upstream websocket closed before response.completed",
        )
        assert retired is (failure_number == threshold), (
            f"Reader failure #{failure_number} reported retired={retired}; with a "
            f"client waiting, only failure #{threshold} may retire the session."
        )

    wipes = _continuity_wipes(durable_bridge)
    assert len(wipes) == 1, (
        "Repeated eventless incomplete streams with a client waiting must wipe the "
        f"stored continuity exactly once at the threshold; it was wiped {len(wipes)} time(s)."
    )
    assert wipes[0].kwargs.get("session_id") == "durable-waiting-incomplete"
    assert wipes[0].kwargs.get("owner_epoch") == 3


async def test_unattended_session_gives_up_after_repeated_incomplete_streams(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The reported wedge: the stream ends incomplete with no response events and
    nobody is waiting on the session any more. ``threshold`` such failures in a
    row must wipe the stored continuity exactly once, under the session's own
    durable identity and owner epoch; ``threshold - 1`` must not.
    """
    threshold = _give_up_threshold()
    service, durable_bridge = _new_service(monkeypatch)

    await _fail_unattended(
        service,
        key_value="bridge-unattended-incomplete",
        durable_session_id="durable-unattended-incomplete",
        owner_epoch=5,
        error_code="stream_incomplete",
        times=threshold - 1,
    )
    assert _continuity_wipes(durable_bridge) == [], (
        f"Stored continuity was wiped before the configured threshold of {threshold} failures."
    )

    await _fail_unattended(
        service,
        key_value="bridge-unattended-incomplete",
        durable_session_id="durable-unattended-incomplete",
        owner_epoch=5,
        error_code="stream_incomplete",
        times=1,
    )
    wipes = _continuity_wipes(durable_bridge)
    assert len(wipes) == 1, (
        "A session failing eventlessly with nobody waiting must wipe its stored "
        f"continuity once the threshold is reached; it was wiped {len(wipes)} time(s)."
    )
    assert wipes[0].kwargs.get("session_id") == "durable-unattended-incomplete"
    assert wipes[0].kwargs.get("owner_epoch") == 5


async def test_unattended_session_gives_up_after_repeated_idle_timeouts(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The other eventless failure kind: the upstream stream goes idle with no
    response events, again with nobody waiting. ``threshold`` in a row must
    wipe the stored continuity exactly once.
    """
    threshold = _give_up_threshold()
    service, durable_bridge = _new_service(monkeypatch)

    await _fail_unattended(
        service,
        key_value="bridge-unattended-idle",
        durable_session_id="durable-unattended-idle",
        owner_epoch=7,
        error_code="stream_idle_timeout",
        times=threshold,
    )

    wipes = _continuity_wipes(durable_bridge)
    assert len(wipes) == 1, (
        "Repeated eventless idle timeouts with nobody waiting must wipe the stored "
        f"continuity once at the threshold; it was wiped {len(wipes)} time(s)."
    )
    assert wipes[0].kwargs.get("session_id") == "durable-unattended-idle"
    assert wipes[0].kwargs.get("owner_epoch") == 7


async def test_unconfirmed_wipe_is_retried_and_logged(
    caplog: pytest.LogCaptureFixture,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When the fenced write does not take effect, the next eligible failure must
    try again, and each unconfirmed attempt must show up as a
    ``durable_anchor_poison_clear_failed`` event. ``threshold + 1`` unattended
    failures therefore give two attempts and two events.
    """
    threshold = _give_up_threshold()
    service, durable_bridge = _new_service(monkeypatch, clear_succeeds=False)

    with caplog.at_level(logging.INFO):
        await _fail_unattended(
            service,
            key_value="bridge-unattended-retry",
            durable_session_id="durable-unattended-retry",
            owner_epoch=5,
            error_code="stream_incomplete",
            times=threshold + 1,
        )

    attempts = len(_continuity_wipes(durable_bridge))
    assert attempts == 2, (
        "An unconfirmed wipe must be attempted again on the next eligible failure; "
        f"it was attempted {attempts} time(s) instead of 2."
    )
    failed_events = caplog.text.count("event=durable_anchor_poison_clear_failed")
    assert failed_events == 2, (
        "Each unconfirmed wipe must be logged as durable_anchor_poison_clear_failed; "
        f"saw {failed_events} such event(s) instead of 2."
    )


# --------------------------------------------------------------------------- #
# Failures that must never count (pass on the original code as well)
# --------------------------------------------------------------------------- #
async def test_clean_closes_never_wipe_stored_continuity(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A cleanly closed upstream socket (close code 1000, before any response
    event) is not a wedge. Neither ``threshold`` clean closes on the reader
    path nor ``threshold`` clean-close retirements may wipe stored continuity.
    """
    threshold = _give_up_threshold()
    service, durable_bridge = _new_service(monkeypatch)

    await _fail_unattended(
        service,
        key_value="bridge-clean-close-reader",
        durable_session_id="durable-clean-close-reader",
        owner_epoch=6,
        error_code="stream_incomplete",
        upstream_close_code=1000,
        times=threshold,
    )
    for _ in range(threshold):
        session = _make_bridge_session(
            key_value="bridge-clean-close-retire",
            durable_session_id="durable-clean-close-retire",
            owner_epoch=6,
        )
        await service._retire_stale_pending_http_bridge_session(
            session,
            detail="stream_incomplete",
            retry_circuit_detail="clean_close",
        )

    assert _continuity_wipes(durable_bridge) == [], "Clean closes must never wipe stored continuity."


def test_give_up_threshold_default_is_unchanged() -> None:
    """The configured default of 7 consecutive failures stays as it is (no
    environment override is set for this run, so this reads the default)."""
    assert "CODEX_LB_HTTP_RESPONSES_SESSION_BRIDGE_ANCHOR_POISON_FAILURE_THRESHOLD" not in os.environ
    assert _give_up_threshold() == 7, (
        f"The give-up threshold default changed to {_give_up_threshold()}; it must stay 7."
    )


async def test_failures_after_response_events_never_wipe_stored_continuity(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A session that got response events back is not stuck on a dead
    continuation. ``threshold`` incomplete streams that each saw response
    events, with nobody waiting, must not wipe stored continuity.
    """
    threshold = _give_up_threshold()
    service, durable_bridge = _new_service(monkeypatch)

    await _fail_unattended(
        service,
        key_value="bridge-eventful",
        durable_session_id="durable-eventful",
        owner_epoch=8,
        error_code="stream_incomplete",
        response_events=2,
        times=threshold,
    )

    assert _continuity_wipes(durable_bridge) == [], "Failures that saw response events must not wipe stored continuity."
