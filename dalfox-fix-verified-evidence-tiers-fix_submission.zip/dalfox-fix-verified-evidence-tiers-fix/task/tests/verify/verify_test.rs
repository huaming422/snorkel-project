// Behavioral verifier for dalfox-fix-verified-evidence-tiers.
//
// Both defects change the *tier* a reflected-XSS finding is reported at, and
// that tier is only observable by running a full scan against a reflecting
// server and reading the emitted finding's `"type"` field. So every scenario
// drives the real public scan entry point `dalfox::cmd::scan::run_scan` against
// an in-process axum server that reflects attacker input, then asserts on the
// JSON findings' `"type"` ("V" = DOM-verified, "R" = reflected, "I" = info).
//
// Design constraints honoured here (see task blueprint):
//   * Tests ONLY the pre-existing public API `run_scan(&ScanArgs)` plus the
//     emitted findings JSON. No fix-site helper is imported — alternative
//     implementations may restructure those private helpers freely.
//   * Scan markers (`dlx`/`xld` + 8 hex) embed a per-process random nonce, so
//     the verifier NEVER hardcodes marker text. Each scenario relies only on
//     the scanner's own internal consistency within a single run.
//   * `base_scan_args()` is copied verbatim from the repo's
//     `tests/scan_run_paths_test.rs`, then tuned to the deterministic
//     single-finding recipe (one query param, mining/AST/WAF-probe skipped,
//     one worker, one encoder, deep_scan off) so a tier assertion is stable.

use dalfox::cmd::scan::{ScanArgs, run_scan};

use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{SystemTime, UNIX_EPOCH};

use axum::Router;
use axum::extract::{Query, State};
use axum::response::Html;
use axum::routing::get;
use tokio::net::TcpListener;

/// `run_scan` resets a process-wide request counter on entry, so overlapping
/// scans in the same process race. The runner already forces
/// `--test-threads=1`, but this lock keeps the suite correct under a plain
/// `cargo test` as well.
static SCAN_LOCK: tokio::sync::Mutex<()> = tokio::sync::Mutex::const_new(());

/// Verbatim copy of `base_scan_args()` from `tests/scan_run_paths_test.rs`
/// (the repo's canonical self-contained scan integration test).
fn base_scan_args() -> ScanArgs {
    ScanArgs {
        insecure: Some(true),
        detect_outdated_libs: false,
        input_type: "url".to_string(),
        format: "json".to_string(),
        output: None,
        include_request: false,
        include_response: false,
        include_all: false,
        no_color: false,
        silence: true,
        dry_run: false,
        stream_findings: false,
        poc_type: "plain".to_string(),
        limit: None,
        limit_result_type: "all".to_string(),
        only_poc: vec![],
        baseline: None,
        param: vec![],
        data: None,
        headers: vec![],
        cookies: vec![],
        method: "GET".to_string(),
        user_agent: None,
        cookie_from_raw: None,
        session_check: None,
        session_check_url: None,
        include_url: vec![],
        exclude_url: vec![],
        ignore_param: vec![],
        out_of_scope: vec![],
        out_of_scope_file: None,
        only_discovery: false,
        skip_discovery: false,
        skip_reflection_header: false,
        skip_reflection_cookie: false,
        skip_reflection_path: false,
        mining_dict_word: None,
        remote_wordlists: vec![],
        skip_mining: false,
        skip_mining_dict: false,
        skip_mining_dom: false,
        timeout: 10,
        scan_timeout: 0,
        delay: 0,
        proxy: None,
        follow_redirects: false,
        ignore_return: vec![],
        workers: 10,
        max_concurrent_targets: 10,
        max_targets_per_host: 100,
        encoders: vec!["url".to_string(), "html".to_string()],
        remote_payloads: vec![],
        custom_blind_xss_payload: None,
        blind_callback_url: None,
        oob: Default::default(),
        custom_payload: None,
        only_custom_payload: false,
        inject_marker: None,
        custom_alert_value: "1".to_string(),
        custom_alert_type: "none".to_string(),
        skip_xss_scanning: false,
        deep_scan: false,
        sxss: false,
        sxss_url: None,
        sxss_method: "GET".to_string(),
        sxss_retries: 3,
        skip_ast_analysis: false,
        analyze_external_js: false,
        hpp: false,
        waf_bypass: "off".to_string(),
        skip_waf_probe: true,
        force_waf: None,
        waf_evasion: false,
        rate_limit: 0,
        retries: 0,
        retry_delay: 1000,
        waf_min_confidence: 0.0,
        targets: vec![],
        max_payloads_per_param: 0,
        ..Default::default()
    }
}

/// Deterministic single-finding recipe on top of `base_scan_args()`: scan one
/// explicitly-provided query param with discovery/mining/AST/WAF-probe noise
/// suppressed, one worker, one encoder, and `deep_scan` off so the
/// first-hit-per-param dedup collapses the result to a single finding per param.
fn scan_args_for(target: &str, output: &str) -> ScanArgs {
    let mut args = base_scan_args();
    args.targets = vec![target.to_string()];
    args.output = Some(output.to_string());
    args.skip_mining = true;
    args.skip_mining_dict = true;
    args.skip_mining_dom = true;
    args.skip_ast_analysis = true;
    args.skip_waf_probe = true;
    args.workers = 1;
    args.deep_scan = false;
    args.encoders = vec!["url".to_string()];
    args.silence = true;
    args
}

fn unique_output_path() -> PathBuf {
    static COUNTER: AtomicU64 = AtomicU64::new(0);
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("system time")
        .as_nanos();
    let n = COUNTER.fetch_add(1, Ordering::Relaxed);
    let mut path = std::env::temp_dir();
    path.push(format!(
        "dalfox-verify-{}-{}-{}.json",
        std::process::id(),
        nanos,
        n
    ));
    path
}

/// Server reflection shape. Takes the raw query value, returns the full HTML
/// page body the mock server serves.
type PageFn = fn(&str) -> String;

async fn reflect_handler(
    State(page): State<PageFn>,
    Query(params): Query<HashMap<String, String>>,
) -> Html<String> {
    let input = params.get("q").cloned().unwrap_or_default();
    Html(page(&input))
}

/// Stand up a local axum server whose single `/` route reflects the `q` param
/// through `page`. Returns the base URL and a handle the caller aborts.
async fn spawn_server(page: PageFn) -> (String, tokio::task::JoinHandle<()>) {
    let app = Router::new().route("/", get(reflect_handler)).with_state(page);
    let listener = TcpListener::bind("127.0.0.1:0").await.expect("bind");
    let addr = listener.local_addr().expect("addr");
    let handle = tokio::spawn(async move {
        let _ = axum::serve(listener, app).await;
    });
    (format!("http://{}/", addr), handle)
}

/// Run one scan against `page`, returning the emitted findings array.
async fn scan_findings(page: PageFn) -> Vec<serde_json::Value> {
    let _guard = SCAN_LOCK.lock().await;
    let (base, handle) = spawn_server(page).await;
    let output = unique_output_path();
    let target = format!("{}?q=1", base);
    let args = scan_args_for(&target, &output.to_string_lossy());

    run_scan(&args).await;
    handle.abort();

    let content = std::fs::read_to_string(&output).expect("scan output file should exist");
    let _ = std::fs::remove_file(&output);
    let parsed: serde_json::Value =
        serde_json::from_str(&content).expect("scan output should be valid JSON");
    parsed["findings"]
        .as_array()
        .cloned()
        .unwrap_or_default()
}

fn has_verified(findings: &[serde_json::Value]) -> bool {
    findings
        .iter()
        .any(|f| f.get("type").and_then(|t| t.as_str()) == Some("V"))
}

fn type_summary(findings: &[serde_json::Value]) -> Vec<String> {
    findings
        .iter()
        .map(|f| {
            f.get("type")
                .and_then(|t| t.as_str())
                .unwrap_or("?")
                .to_string()
        })
        .collect()
}

// ── Reflection shapes ─────────────────────────────────────────────────────

/// Defect 1 context. The input lands inside a pre-existing *double-quoted*
/// `style` attribute value; angle brackets are HTML-encoded so no tag-forming
/// payload can break out, leaving the bare attribute-injection payload (which
/// carries no `<`/`>`) as the only breakout. Its injected `on*=` handler is
/// swallowed by the quoted style value while a trailing `id=`/`class=` marker
/// still tokenizes onto the live `<p>` — a marker on an element that executes
/// nothing. This is the shape the PR observed (xssmaze `/inlinestyle/level2`).
fn page_swallowed_handler(input: &str) -> String {
    let safe = input
        .replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;");
    format!(
        "<html><body><p style=\"background-image: url('{}')\">text</p></body></html>",
        safe
    )
}

/// Defect 2 context. The input is reflected into the body with its letter case
/// normalized — here the whole reflected value is upper-cased (a Rails-style
/// `upcase`/`titleize` template filter; xssmaze `/casemanip/*`). Every special
/// character still reflects raw, so the sink is completely unfiltered. But the
/// scanner's exact-case probe-marker lookup (`str::find` of the `dlx`/`xld`
/// markers) misses the up-cased markers, reads the probe as "nothing reflected
/// / all specials filtered", and mutes the entire angle/quote-bearing payload
/// set — demoting a trivially-exploitable sink to the reflected tier.
///
/// Whole-value upper-case is the shape that reproduces the defect: upper-casing
/// only the first character leaves the rest of the markers and payload lowercase
/// and the breakout still fires (confirmed empirically against the pre-fix
/// scanner). The element/attribute names a breakout forms are HTML
/// case-insensitive, and the fix's DOM-side marker match is ASCII-case-folded,
/// so the post-fix scan still reaches tier V under this transform.
fn page_casefold(input: &str) -> String {
    format!(
        "<html><body><div>{}</div></body></html>",
        input.to_ascii_uppercase()
    )
}

/// Legitimate DOM-verified context: input reflected raw into a plain body, so a
/// genuine `<svg onload=…>` breakout forms a real executing element carrying
/// both its handler and its marker. Must stay "V" under any correct fix.
fn page_raw_body(input: &str) -> String {
    format!("<html><body><div>{}</div></body></html>", input)
}

/// Ordinary reflecting page (no handler-swallow, no case-normalization): the
/// input is echoed into page text. The scan must still surface *some* finding.
fn page_basic_reflection(input: &str) -> String {
    format!(
        "<html><body><h1>Results</h1><p>You searched for: {}</p></body></html>",
        input
    )
}

/// JS-sink tokens and executable-URL protocols the scanner recognizes. Matching
/// the scanner's own sink vocabulary is intentional: `page_structural_marker`
/// neutralizes exactly these so that *no* payload carrying an executable sink can
/// reach tier V, leaving a sinkless structural marker as the only DOM-verifiable
/// route. (These are long-standing XSS sink names the scanner already matches on;
/// a drift in the scanner's vocabulary would at worst let one extra payload
/// through, which does not weaken the assertion below.)
const SINK_TOKENS: &[&str] = &[
    "alert",
    "prompt",
    "confirm",
    "print",
    "eval",
    "setTimeout",
    "setInterval",
    "Function",
    "writeln",
    "write",
    "insertAdjacentHTML",
    "setHTMLUnsafe",
    "parseHTMLUnsafe",
    "innerHTML",
    "outerHTML",
    "srcdoc",
    "javascript:",
    "vbscript:",
    "data:text/html",
    "location",
    "href",
];

/// Case-insensitively blunt the first byte of every executable-sink token in the
/// reflected input, iterating to a fixed point. Tag/attribute/marker structure is
/// otherwise preserved, so a reflected payload that lands a `class=`/`id=` marker
/// on a real element with NO surviving executable sink still parses into that
/// element — the sinkless *structural marker* that must keep presence-only DOM
/// evidence.
fn defang_sinks(input: &str) -> String {
    let mut s = input.to_string();
    loop {
        let lower = s.to_ascii_lowercase();
        let mut hit: Option<usize> = None;
        for tok in SINK_TOKENS {
            if let Some(p) = lower.find(&tok.to_ascii_lowercase()) {
                hit = Some(match hit {
                    Some(h) => h.min(p),
                    None => p,
                });
            }
        }
        match hit {
            // Tokens are ASCII, so byte index `p` is a char boundary.
            Some(p) => {
                let mut v = s.into_bytes();
                v[p] = b'_';
                s = String::from_utf8(v).expect("ASCII edit preserves UTF-8");
            }
            None => break,
        }
    }
    s
}

/// Legitimate *structural-marker* DOM-verified context. The input is reflected
/// into a plain body, but every executable-sink token is neutralized first, so no
/// payload's handler/script/url survives as a sink. A scanner payload that still
/// tokenizes its `class=`/`id=` marker onto a real element therefore DOM-verifies
/// purely on presence-only structural evidence (base-href / DOM-clobbering style
/// markers). This is the [V] an over-broad defect-1 fix would wrongly destroy —
/// whether by disabling marker evidence wholesale or by demanding a surviving
/// sink on *every* marker element. Must stay "V" under any correct fix.
fn page_structural_marker(input: &str) -> String {
    format!(
        "<html><head></head><body><div>{}</div></body></html>",
        defang_sinks(input)
    )
}

// ── Scenarios ─────────────────────────────────────────────────────────────

/// fail_to_pass (defect 1): a handler swallowed into a pre-existing quoted
/// attribute value must NOT be reported as DOM-verified. The input is still
/// reflected, so a finding exists — it must simply not be "V".
#[tokio::test]
async fn swallowed_handler_injection_not_dom_verified() {
    let findings = scan_findings(page_swallowed_handler).await;
    assert!(
        !findings.is_empty(),
        "the input is reflected, so the scan should still report a finding (just not V); \
         got no findings at all"
    );
    assert!(
        !has_verified(&findings),
        "the injected on*-handler is absorbed into the pre-existing quoted style value and \
         never fires, so no finding may be tier V; got types {:?}",
        type_summary(&findings)
    );
}

/// fail_to_pass (defect 2): when the server reflects input with its letter case
/// normalized, a trivially-exploitable sink must still reach DOM-verified
/// instead of being muted to a weak tier.
#[tokio::test]
async fn casefold_reflection_reaches_dom_verified() {
    let findings = scan_findings(page_casefold).await;
    assert!(
        has_verified(&findings),
        "the sink reflects every special char raw (only letter-case is normalized), so a \
         breakout executes and the finding must reach tier V; got types {:?}",
        type_summary(&findings)
    );
}

/// pass_to_pass (FN guard): a genuine breakout that forms a real executing
/// element with its handler intact stays DOM-verified. Guards against an
/// over-broad defect-1 fix that disables marker evidence wholesale.
#[tokio::test]
async fn genuine_breakout_still_dom_verified() {
    let findings = scan_findings(page_raw_body).await;
    assert!(
        has_verified(&findings),
        "a real breakout forming an executing element with a surviving sink must stay tier V; \
         got types {:?}",
        type_summary(&findings)
    );
}

/// pass_to_pass: an ordinary reflecting page still produces a finding. Guards
/// against a defect-2 fix that breaks the basic reflected-detection pipeline.
#[tokio::test]
async fn basic_reflection_still_detected() {
    let findings = scan_findings(page_basic_reflection).await;
    assert!(
        !findings.is_empty(),
        "an ordinary reflected input must still yield at least one finding; got none"
    );
}

/// pass_to_pass (FN guard): a sinkless *structural* marker must keep its
/// presence-only DOM evidence and stay tier V. No executable sink survives in the
/// reflection, so the only route to V is the marker-presence path. This guards the
/// senior-decision regression the blueprint calls out: an over-broad defect-1 fix
/// that disables marker evidence wholesale — or demands a surviving sink on every
/// marker element — would wrongly demote this legitimate [V] to R. (The companion
/// `genuine_breakout_still_dom_verified` guards the opposite direction, where a
/// sink DOES survive; together they pin both edges of the marker-evidence gate.)
#[tokio::test]
async fn structural_marker_still_dom_verified() {
    let findings = scan_findings(page_structural_marker).await;
    assert!(
        has_verified(&findings),
        "a reflected payload that lands its class/id marker on a real element must stay tier V \
         on structural (presence-only) evidence even when no executable sink survives; \
         got types {:?}",
        type_summary(&findings)
    );
}
