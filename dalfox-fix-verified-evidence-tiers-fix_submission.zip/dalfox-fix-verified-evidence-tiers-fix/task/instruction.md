## Task

the scanner's reflected-xss tiers are coming out wrong in two directions and i'd like both tracked down. some scans tag findings as DOM-verified (the strong [V] tier) even when the injected event handler never actually fires, so we're reporting verified hits that are flat-out incorrect. separately, when a target reflects our input back with its letter case changed, those come back under-reported, a weak [R] or nothing at all, where a verified finding is clearly warranted. dig in and fix the tiers so what each finding reports lines up with what the payload can actually do.
