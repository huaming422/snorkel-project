## Task

Customers who run our surveys in Arabic, Hebrew and Persian say masked text questions are close to unusable. On phone, date, numeric and currency masks the pieces of the value show up out of order, and the cursor lands in the wrong place as people type. The same surveys in a left-to-right language look fine.

A few of our masks really are written in a right-to-left script, meaning the text the mask itself shows has Arabic or Hebrew letters in it: fixed text in a pattern, a separator, the words around a currency amount, or the placeholder letters a date mask gets from its locale. Those read correctly today, so don't push them the other way. Having no such letters makes a mask an ordinary one, even when it contains Arabic-Indic digits or uses the Arabic decimal and thousands marks. Those are still numbers, and they get scrambled like the rest.

Separately, people on Arabic and Persian keyboards type their digits into a masked field and the digits disappear. Nothing appears, and nothing gets saved. However those digits arrive (typed, pasted or autofilled), every mask type should take them and turn them into plain 0-9, both in the field and in the saved answer.
