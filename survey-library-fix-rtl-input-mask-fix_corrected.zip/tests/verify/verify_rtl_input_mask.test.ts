// @ts-nocheck
//
// Masked text questions in right-to-left surveys, and Arabic-Indic digits typed
// into masked fields. Everything runs through the question model, the input
// element adapter and a real <input> in jsdom. Script letters and foreign digits
// are built from code points so this file stays plain ASCII.

import * as fs from "fs";
import * as path from "path";
import * as sass from "sass";

import { InputElementAdapter } from "../../src/mask/input_element_adapter";
import { InputMaskNumeric } from "../../src/mask/mask_numeric";
import { InputMaskPattern } from "../../src/mask/mask_pattern";
import { InputMaskCurrency } from "../../src/mask/mask_currency";
import { InputMaskDateTime } from "../../src/mask/mask_datetime";
import { QuestionTextModel } from "../../src/question_text";
import { SurveyModel } from "../../src/survey";
import { surveyLocalization } from "../../src/surveyStrings";

import "../../src/localization/arabic";
import "../../src/localization/hebrew";
import "../../src/localization/persian";

import { afterAll, beforeAll, describe, test, expect } from "vitest";

const SLOW = 60000;

const ai = (text: string): string => text.replace(/[0-9]/g, (d: string) => String.fromCharCode(0x0660 + Number(d)));
const eai = (text: string): string => text.replace(/[0-9]/g, (d: string) => String.fromCharCode(0x06F0 + Number(d)));
const DIGIT_BLOCKS: Array<[string, (text: string) => string]> = [["Arabic-Indic", ai], ["extended Arabic-Indic", eai]];

const chars = (...codes: Array<number>): string => String.fromCharCode(...codes);
const AR_YEH = chars(0x064a);
const HE_ALEF = chars(0x05d0);
const FA_PEH = chars(0x067e);
const AR_WORD = chars(0x0645, 0x062d, 0x0644, 0x064a);
const SAUDI_RIYAL = chars(0x0631) + "." + chars(0x0633);
const AR_DECIMAL = chars(0x066b);
const AR_THOUSANDS = chars(0x066c);
const CYRILLIC_DE = chars(0x0414);
const RTL_LOCALES = ["ar", "he", "fa"];

// The default theme compiled to CSS, for fields that take their direction from a class.
let themeCss = "";
beforeAll(() => {
  try {
    themeCss = sass.compile(path.resolve(__dirname, "../../src/default-theme/default.fontless.scss"), { quietDeps: true, logger: sass.Logger.silent }).css;
  } catch {
    themeCss = "";
  }
}, SLOW);

const splitSelectors = (selectorList: string): Array<string> => {
  const result: Array<string> = [];
  let depth = 0;
  let current = "";
  selectorList.split("").forEach(ch => {
    depth += ch === "(" ? 1 : ch === ")" ? -1 : 0;
    if (ch === "," && depth === 0) {
      result.push(current);
      current = "";
    } else {
      current += ch;
    }
  });
  return result.concat(current).map(selector => selector.trim()).filter(selector => !!selector);
};
const specificity = (selector: string): number => {
  const count = (pattern: RegExp): number => (selector.match(pattern) || []).length;
  return count(/#[\w-]+/g) * 10000 + count(/\.[\w-]+|\[[^\]]*\]|:(?!:|not\b|is\b|where\b)[\w-]+/g) * 100 + count(/(?:^|[\s>+~(])[a-zA-Z][\w-]*/g);
};
// jsdom has no :dir(), so it is settled here from the direction of the survey around the field.
const matchesField = (input: any, selector: string, surveyDirection: string): boolean => {
  if (selector.indexOf("::") > -1) return false;
  const other = surveyDirection === "rtl" ? "ltr" : "rtl";
  if (selector.indexOf(":dir(" + other + ")") > -1) return false;
  const plain = selector.split(":dir(" + surveyDirection + ")").join("").trim();
  try {
    return input.matches(plain || "*");
  } catch {
    return false;
  }
};
// The theme's verdict for a field in place: the winning rule on the input, or else on the
// nearest element around it, since direction is inherited.
const directionFromTheme = (input: any, surveyDirection: string, outermost: any): string | undefined => {
  for (let element = input; !!element && element !== outermost; element = element.parentElement) {
    const direction = winningThemeDirection(element, surveyDirection);
    if (!!direction) return direction;
  }
  return undefined;
};
const winningThemeDirection = (input: any, surveyDirection: string): string | undefined => {
  let result: string | undefined = undefined;
  let best = -1;
  const css = themeCss.replace(/\/\*[\s\S]*?\*\//g, "");
  for (const rule of css.matchAll(/([^{}]+)\{([^{}]*)\}/g)) {
    const declared = rule[2].match(/(?:^|;|\s)direction:\s*([a-z-]+)/);
    const plaintext = /(?:^|;|\s)unicode-bidi:\s*plaintext/.test(rule[2]);
    if (!declared && !plaintext) continue;
    splitSelectors(rule[1]).filter(selector => matchesField(input, selector, surveyDirection)).forEach(selector => {
      if (specificity(selector) >= best) {
        best = specificity(selector);
        result = plaintext ? "auto" : declared[1];
      }
    });
  }
  return result;
};

const classList = (q: any): Array<string> => (q.getControlClass() || "").split(/\s+/).filter((c: string) => !!c);

const newQuestion = (locale: string, element: any): any => {
  const survey = new SurveyModel({ locale: locale, elements: [Object.assign({ type: "text", name: "q1" }, element)] });
  return survey.getQuestionByName("q1");
};

// What the three renderers bind to the input element.
const RENDERERS = ["survey-react-ui/src/reactquestion_text.tsx", "survey-vue3-ui/src/Text.vue", "survey-angular-ui/src/questions/text.component.html"]
  .map(file => fs.readFileSync(path.resolve(__dirname, "../../../", file), "utf8"));

const directionFromObject = (owner: any): string | undefined => {
  for (let proto = Object.getPrototypeOf(owner); !!proto && proto !== Object.prototype; proto = Object.getPrototypeOf(proto)) {
    for (const name of Object.getOwnPropertyNames(proto)) {
      if (name === "constructor" || !RENDERERS.every(source => source.indexOf(name) > -1)) continue;
      const descriptor = Object.getOwnPropertyDescriptor(proto, name);
      const isMethod = typeof descriptor.value === "function" && descriptor.value.length === 0;
      if (!descriptor.get && !isMethod) continue;
      let value: any = undefined;
      try {
        value = isMethod ? owner[name]() : owner[name];
      } catch {
        continue;
      }
      if (value === "ltr" || value === "rtl" || (value === "auto" && /dir/i.test(name))) return value;
    }
  }
  return undefined;
};
const directionFromModel = (q: any): string | undefined => directionFromObject(q) || (!!q.maskSettings ? directionFromObject(q.maskSettings) : undefined);

const RTL_LETTER = /[\p{Script=Hebrew}\p{Script=Arabic}\p{Script=Syriac}\p{Script=Thaana}\p{Script=Nko}]/u;
// dir="auto" and unicode-bidi: plaintext take the direction from the first strong character shown.
const resolveAuto = (text: string): string => {
  const firstLetter = (text || "").match(/\p{L}/u);
  return "auto:" + (!!firstLetter && RTL_LETTER.test(firstLetter[0]) ? "rtl" : "ltr");
};

// The direction a rendered field ends up with: the question's input style, the
// attribute or style on the element once the question is attached to it, a model
// property or method the renderers bind, or the theme's rules for the field inside
// the elements the renderers put around it.
const renderedDirection = (q: any, locale: string): string | undefined => {
  const surveyDirection = surveyLocalization.localeDirections[locale] || "ltr";
  const wrapper = document.createElement("div");
  const input = document.createElement("input");
  wrapper.setAttribute("dir", surveyDirection);
  input.className = classList(q).join(" ");
  const chain = [q.survey.getRootCss(), q.getRootCss(), q.cssContent, q.getRootClass()];
  const parent = chain.reduce((outer: any, className: string) => {
    const element = document.createElement("div");
    element.className = className || "";
    outer.appendChild(element);
    return element;
  }, wrapper);
  parent.appendChild(input);
  document.body.appendChild(wrapper);
  q.afterRenderQuestionElement(input);
  const style = q.inputStyle || {};
  const fromStyle = style.direction;
  const resolvesItself = style.unicodeBidi === "plaintext" || input.style.unicodeBidi === "plaintext" || input.getAttribute("dir") === "auto";
  const fromElement = input.getAttribute("dir") || input.style.direction;
  const shownText = input.value;
  const fromTheme = directionFromTheme(input, surveyDirection, wrapper);
  q.beforeDestroyQuestionElement(input);
  wrapper.remove();
  if (resolvesItself) return resolveAuto(shownText);
  if (!!fromStyle) return fromStyle;
  if (!!fromElement) return fromElement;
  const fromModel = directionFromModel(q);
  if (fromModel === "auto") return resolveAuto(q.inputValue);
  if (!!fromModel) return fromModel;
  return fromTheme === "auto" ? resolveAuto(shownText) : fromTheme;
};

const directionOf = (locale: string, element: any): string | undefined => renderedDirection(newQuestion(locale, element), locale);

const LEFT_TO_RIGHT = ["ltr", "auto:ltr"];
const NOT_FORCED = ["", "auto", "rtl", "inherit", "unset", "auto:ltr", "auto:rtl"];
const expectLtrInEveryRtlLocale = (element: any, label: string): void => {
  RTL_LOCALES.forEach(locale => {
    expect(LEFT_TO_RIGHT, label + " in locale " + locale).toContain(directionOf(locale, element));
  });
};
const expectNotForcedInEveryRtlLocale = (element: any, label: string): void => {
  RTL_LOCALES.forEach(locale => {
    expect(NOT_FORCED, label + " in locale " + locale).toContain(directionOf(locale, element) ?? "");
  });
};

describe("masked input direction in a right-to-left survey", () => {
  // jsdom doesn't derive a computed direction from dir, so it is supplied from the nearest dir.
  const computedStyle = window.getComputedStyle;
  beforeAll(() => {
    document.documentElement.setAttribute("dir", "rtl");
    window.getComputedStyle = (element: any, pseudo?: any): any => {
      const style = computedStyle.call(window, element, pseudo);
      const host = element.closest("[dir]");
      Object.defineProperty(style, "direction", { value: element.style.direction || (!!host ? host.getAttribute("dir") : "ltr") });
      return style;
    };
  });
  afterAll(() => {
    document.documentElement.removeAttribute("dir");
    window.getComputedStyle = computedStyle;
  });

  test("a phone pattern runs left to right", () => {
    expectLtrInEveryRtlLocale({ maskType: "pattern", maskSettings: { pattern: "+1 (999) 999-9999" } }, "phone pattern");
    expectLtrInEveryRtlLocale({ maskType: "pattern", maskSettings: { pattern: "999-99-99" } }, "digit groups");
    expectLtrInEveryRtlLocale({ maskType: "pattern", maskSettings: { pattern: "aaa-999" } }, "a pattern of letter and digit slots");
  });

  test("a date mask runs left to right", () => {
    expectLtrInEveryRtlLocale({ maskType: "datetime", maskSettings: { pattern: "dd/mm/yyyy" } }, "dd/mm/yyyy");
    expectLtrInEveryRtlLocale({ maskType: "datetime", maskSettings: { pattern: "mm-dd-yyyy HH:MM" } }, "date and time");
    expectLtrInEveryRtlLocale({ maskType: "datetime" }, "a date mask with the locale's own format");
  }, SLOW);

  test("numeric and currency masks run left to right and keep their alignment", () => {
    RTL_LOCALES.forEach(locale => {
      const numeric = newQuestion(locale, { maskType: "numeric" });
      expect(LEFT_TO_RIGHT, "numeric in " + locale).toContain(renderedDirection(numeric, locale));
      expect(numeric.inputStyle.textAlign, "numeric alignment in " + locale).toBe("right");

      const currency = newQuestion(locale, { maskType: "currency", maskSettings: { prefix: "$ " } });
      expect(LEFT_TO_RIGHT, "currency with a latin prefix in " + locale).toContain(renderedDirection(currency, locale));
      expect(currency.inputStyle.textAlign, "currency alignment in " + locale).toBe("right");

      const suffixed = newQuestion(locale, { maskType: "currency", maskSettings: { suffix: " USD" } });
      expect(LEFT_TO_RIGHT, "currency with a latin suffix in " + locale).toContain(renderedDirection(suffixed, locale));

      const leftAligned = newQuestion(locale, { maskType: "numeric", inputTextAlignment: "left" });
      expect(LEFT_TO_RIGHT, "numeric aligned left in " + locale).toContain(renderedDirection(leftAligned, locale));
      expect(leftAligned.inputStyle.textAlign, "an explicit alignment in " + locale).toBe("left");
    });
  });

  test("Arabic-Indic digits in a pattern do not make it a right-to-left mask", () => {
    expectLtrInEveryRtlLocale({ maskType: "pattern", maskSettings: { pattern: ai("12") + "-99" } }, "Arabic-Indic literal digits");
    expectLtrInEveryRtlLocale({ maskType: "pattern", maskSettings: { pattern: eai("34") + "-99" } }, "extended Arabic-Indic literal digits");
  });

  test("the Arabic decimal and thousands marks do not make a mask right-to-left", () => {
    const separators = { decimalSeparator: AR_DECIMAL, thousandsSeparator: AR_THOUSANDS };
    expectLtrInEveryRtlLocale({ maskType: "numeric", maskSettings: separators }, "numeric");
    expectLtrInEveryRtlLocale({ maskType: "currency", maskSettings: Object.assign({ prefix: "$ " }, separators) }, "currency with a latin prefix");
  });

  test("a pattern with Arabic or Hebrew letters in it is not forced left to right", () => {
    expectNotForcedInEveryRtlLocale({ maskType: "pattern", maskSettings: { pattern: "999 " + AR_YEH + " 999" } }, "an Arabic letter");
    expectNotForcedInEveryRtlLocale({ maskType: "pattern", maskSettings: { pattern: "999 " + HE_ALEF + " 999" } }, "a Hebrew letter");
    expectNotForcedInEveryRtlLocale({ maskType: "pattern", maskSettings: { pattern: "999 " + AR_WORD + " 999" } }, "an Arabic word");
    expectNotForcedInEveryRtlLocale({ maskType: "pattern", maskSettings: { pattern: "999 " + FA_PEH + " 999" } }, "a letter used in Persian");
    expectNotForcedInEveryRtlLocale({ maskType: "pattern", maskSettings: { pattern: "\\" + AR_YEH + "999" } }, "an escaped Arabic letter");

    expectLtrInEveryRtlLocale({ maskType: "pattern", maskSettings: { pattern: "999 x 999" } }, "a latin letter");
    expectLtrInEveryRtlLocale({ maskType: "pattern", maskSettings: { pattern: "999 " + CYRILLIC_DE + " 999" } }, "a cyrillic letter");
  });

  test("a numeric mask with a letter for a separator is not forced left to right", () => {
    expectNotForcedInEveryRtlLocale({ maskType: "numeric", maskSettings: { decimalSeparator: AR_YEH } }, "an Arabic decimal letter");
    expectNotForcedInEveryRtlLocale({ maskType: "numeric", maskSettings: { thousandsSeparator: HE_ALEF } }, "a Hebrew thousands letter");
    expectLtrInEveryRtlLocale({ maskType: "numeric", maskSettings: { decimalSeparator: ",", thousandsSeparator: "." } }, "punctuation separators");
  });

  test("a currency mask with Arabic or Hebrew letters around the amount or for a separator is not forced left to right", () => {
    expectNotForcedInEveryRtlLocale({ maskType: "currency", maskSettings: { prefix: AR_YEH } }, "an Arabic prefix");
    expectNotForcedInEveryRtlLocale({ maskType: "currency", maskSettings: { suffix: HE_ALEF } }, "a Hebrew suffix");
    expectNotForcedInEveryRtlLocale({ maskType: "currency", maskSettings: { suffix: " " + SAUDI_RIYAL } }, "an Arabic currency name after the amount");
    expectNotForcedInEveryRtlLocale({ maskType: "currency", maskSettings: { prefix: SAUDI_RIYAL + " " } }, "an Arabic currency name before the amount");
    expectNotForcedInEveryRtlLocale({ maskType: "currency", maskSettings: { prefix: "$ ", decimalSeparator: AR_YEH } }, "an Arabic decimal letter beside a latin prefix");
    expectNotForcedInEveryRtlLocale({ maskType: "currency", maskSettings: { suffix: " USD", thousandsSeparator: HE_ALEF } }, "a Hebrew thousands letter beside a latin suffix");
  });

  test("a date mask with a letter for a separator is not forced left to right", () => {
    expectNotForcedInEveryRtlLocale({ maskType: "datetime", maskSettings: { pattern: "dd " + AR_YEH + " mm" } }, "an Arabic separator");
    expectNotForcedInEveryRtlLocale({ maskType: "datetime", maskSettings: { pattern: "dd " + HE_ALEF + " mm" } }, "a Hebrew separator");
  }, SLOW);

  test("a date mask whose placeholders are Arabic or Hebrew letters is not forced left to right", () => {
    const arabic = surveyLocalization.locales["ar"];
    const hebrew = surveyLocalization.locales["he"];
    arabic.maskPlaceholderDay = AR_YEH;
    hebrew.maskPlaceholderYear = HE_ALEF;
    try {
      const arabicMask = newQuestion("ar", { maskType: "datetime", maskSettings: { pattern: "dd/mm/yyyy" } });
      expect(arabicMask.inputValue, "the field shows the locale's day letter").toBe(AR_YEH + AR_YEH + "/mm/yyyy");
      expect(NOT_FORCED, "an Arabic day placeholder").toContain(renderedDirection(arabicMask, "ar") ?? "");

      const hebrewMask = newQuestion("he", { maskType: "datetime", maskSettings: { pattern: "dd/mm/yyyy" } });
      expect(hebrewMask.inputValue, "the field shows the locale's year letter").toBe("dd/mm/" + HE_ALEF.repeat(4));
      expect(NOT_FORCED, "a Hebrew year placeholder").toContain(renderedDirection(hebrewMask, "he") ?? "");
    } finally {
      delete arabic.maskPlaceholderDay;
      delete hebrew.maskPlaceholderYear;
    }
    expect(LEFT_TO_RIGHT, "the same mask with latin placeholders").toContain(directionOf("ar", { maskType: "datetime", maskSettings: { pattern: "dd/mm/yyyy" } }));
  }, SLOW);

  test("an input with no mask keeps its direction", () => {
    RTL_LOCALES.forEach(locale => {
      expect(["", "rtl", "auto", "inherit", "unset", "auto:ltr", "auto:rtl"], "no mask in " + locale).toContain(directionOf(locale, {}) ?? "");
      expect(newQuestion(locale, { maskType: "none" }).inputStyle.textAlign, "no alignment in " + locale).toBeUndefined();
    });
  });
});

const fire = (input: any, data: string | null, inputType: string): void => {
  input.dispatchEvent(new InputEvent("beforeinput", { data: data, inputType: inputType, bubbles: true, cancelable: true }));
};
const typeInto = (input: any, text: string): void => {
  text.split("").forEach(ch => fire(input, ch, "insertText"));
};
const withInput = (mask: any, value: any, body: (input: any) => void): void => {
  const input = document.createElement("input");
  document.body.appendChild(input);
  const adapter = new InputElementAdapter(mask, input, value);
  input.focus();
  input.setSelectionRange(0, 0);
  try {
    body(input);
  } finally {
    adapter.dispose();
    input.remove();
  }
};
const patternMask = (pattern: string): any => {
  const mask = new InputMaskPattern();
  mask.pattern = pattern;
  return mask;
};
const dateMask = (pattern: string): any => {
  const mask = new InputMaskDateTime();
  mask.pattern = pattern;
  return mask;
};
const currencyMask = (): any => {
  const mask = new InputMaskCurrency();
  mask.prefix = "$ ";
  return mask;
};

const pathCases = (spell: (text: string) => string): Array<[string, any, string, string, any]> => [
  ["pattern", patternMask("999-99-99"), spell("1234567"), "123-45-67", "1234567"],
  ["date", dateMask("mm/dd/yyyy"), spell("12/25/2000"), "12/25/2000", "2000-12-25"],
  ["numeric", new InputMaskNumeric(), spell("123456.78"), "123,456.78", 123456.78],
  ["currency", currencyMask(), spell("1234.5"), "$ 1,234.5", 1234.5]
];

const questionPathCases = (spell: (text: string) => string): Array<[any, string, any, string]> => [
  [{ maskType: "pattern", maskSettings: { pattern: "999-99-99" } }, spell("1234567"), "1234567", "123-45-67"],
  [{ maskType: "datetime", maskSettings: { pattern: "mm/dd/yyyy" } }, spell("12/25/2000"), "2000-12-25", "12/25/2000"],
  [{ maskType: "numeric" }, spell("123456.78"), 123456.78, "123,456.78"],
  [{ maskType: "currency", maskSettings: { prefix: "$ " } }, spell("1234.5"), 1234.5, "$ 1,234.5"]
];

const expectSurveyData = (element: any, shown: string, stored: any, enter: (input: any) => void): void => {
  const q = newQuestion("ar", element);
  const input = document.createElement("input");
  document.body.appendChild(input);
  q.afterRenderQuestionElement(input);
  input.focus();
  input.setSelectionRange(0, 0);
  enter(input);
  expect(input.value, element.maskType + ": the field").toBe(shown);
  q.onBlur({ target: input });
  expect(q.survey.getValue("q1"), element.maskType + ": the survey's data").toBe(stored);
  q.beforeDestroyQuestionElement(input);
  input.remove();
};

// A question whose change handler the framework bound before the mask attached, as the
// renderers do, and an element that never had focus.
const expectAutofill = (element: any, text: string, stored: any, shown: string): void => {
  const q = newQuestion("ar", element);
  const input = document.createElement("input");
  document.body.appendChild(input);
  input.addEventListener("change", q.onChange);
  q.afterRenderQuestionElement(input);
  input.value = text;
  input.dispatchEvent(new Event("change", { bubbles: true }));
  expect(input.value, element.maskType + ": the field").toBe(shown);
  expect(q.survey.getValue("q1"), element.maskType + ": the survey's data").toBe(stored);
  q.beforeDestroyQuestionElement(input);
  input.remove();
};
const autofillCases = (spell: (text: string) => string): Array<[any, string, any, string]> => [
  [{ maskType: "pattern", maskSettings: { pattern: "999-99-99" } }, spell("123-45-67"), "1234567", "123-45-67"],
  [{ maskType: "datetime", maskSettings: { pattern: "mm/dd/yyyy" } }, spell("12/25/2000"), "2000-12-25", "12/25/2000"],
  [{ maskType: "numeric" }, spell("1234.5"), 1234.5, "1,234.5"],
  [{ maskType: "currency", maskSettings: { prefix: "$ " } }, spell("1234.5"), 1234.5, "$ 1,234.5"]
];

describe("Arabic-Indic digits in a masked field", () => {
  test.each(DIGIT_BLOCKS)("%s digits typed into a pattern mask", (_name, spell) => {
    const mask = patternMask("+1 (999) 999-9999");
    withInput(mask, "", (input) => {
      typeInto(input, spell("555"));
      expect(input.value, "half typed").toBe("+1 (555) ___-____");
      expect(input.selectionStart, "the caret follows the digits").toBe(9);
      typeInto(input, spell("1234567"));
      expect(input.value, "complete").toBe("+1 (555) 123-4567");
      expect(mask.getUnmaskedValue(input.value), "the value").toBe("15551234567");
    });
  });

  test.each(DIGIT_BLOCKS)("%s digits typed into a date mask", (_name, spell) => {
    const mask = dateMask("mm/dd/yyyy");
    withInput(mask, "", (input) => {
      typeInto(input, spell("1225"));
      expect(input.value, "half typed").toBe("12/25/yyyy");
      typeInto(input, spell("2000"));
      expect(input.value, "complete").toBe("12/25/2000");
      expect(mask.getUnmaskedValue(input.value), "the value").toBe("2000-12-25");
    });
  });

  test.each(DIGIT_BLOCKS)("%s digits typed into a numeric mask", (_name, spell) => {
    const mask = new InputMaskNumeric();
    withInput(mask, "", (input) => {
      typeInto(input, spell("1234.5"));
      expect(input.value, "grouped").toBe("1,234.5");
      expect(mask.getUnmaskedValue(input.value), "the value").toBe(1234.5);
    });
  });

  test.each(DIGIT_BLOCKS)("%s digits typed into a currency mask", (_name, spell) => {
    const mask = currencyMask();
    withInput(mask, "", (input) => {
      typeInto(input, spell("1234.5"));
      expect(input.value, "with its prefix").toBe("$ 1,234.5");
      expect(mask.getUnmaskedValue(input.value), "the value").toBe(1234.5);
    });
  });

  test.each(DIGIT_BLOCKS)("%s digits pasted in one go", (_name, spell) => {
    pathCases(spell).forEach(([label, mask, text, shown, stored]) => {
      withInput(mask, "", (input) => {
        fire(input, text, "insertFromPaste");
        expect(input.value, label).toBe(shown);
        expect(mask.getUnmaskedValue(input.value), label + " value").toBe(stored);
      });
    });
  });

  test.each(DIGIT_BLOCKS)("%s digits that reach the field without a keystroke", (_name, spell) => {
    pathCases(spell).forEach(([label, mask, text, shown, stored]) => {
      withInput(mask, "", (input) => {
        input.value = text;
        input.dispatchEvent(new Event("change"));
        expect(input.value, label).toBe(shown);
        expect(mask.getUnmaskedValue(input.value), label + " value").toBe(stored);
      });
    });
  });

  test.each(DIGIT_BLOCKS)("%s digits entered into a pattern that has such digits in its fixed text", (_name, spell) => {
    const pattern = spell("12") + "-99";
    const mask = patternMask(pattern);
    withInput(mask, "", (input) => {
      typeInto(input, spell("34"));
      expect(input.value, "typed").toBe(spell("12") + "-34");
      expect(mask.getUnmaskedValue(input.value), "typed value").toBe("34");
    });
    const change = (text: string): void => {
      withInput(mask, "", (input) => {
        input.value = text;
        input.dispatchEvent(new Event("change"));
        expect(input.value, "without a keystroke: " + text).toBe(spell("12") + "-56");
        expect(mask.getUnmaskedValue(input.value), "the value of " + text).toBe("56");
      });
    };
    change(spell("12-56"));
    change(spell("56"));
  });

  test("a digit replacing a selection or going in the middle of a value", () => {
    withInput(patternMask("999-99"), "12345", (input) => {
      input.setSelectionRange(1, 2);
      typeInto(input, ai("9"));
      expect(input.value, "the selected digit is replaced").toBe("193-45");
      expect(input.selectionStart, "the caret after the replacement").toBe(2);

      input.setSelectionRange(1, 1);
      typeInto(input, eai("0"));
      expect(input.value, "a digit inserted in the middle").toBe("109-34");
    });
  });

  test("a slot that takes letters or digits", () => {
    const mask = patternMask("###");
    withInput(mask, "", (input) => {
      typeInto(input, "a" + ai("5") + eai("7"));
      expect(input.value, "the field").toBe("a57");
      expect(mask.getUnmaskedValue(input.value), "the value").toBe("a57");
    });
  });

  test.each(DIGIT_BLOCKS)("%s digits typed into a question end up in the survey's data", (_name, spell) => {
    const cases: Array<[any, string, any, string]> = [
      [{ maskType: "pattern", maskSettings: { pattern: "+1 (999) 999-9999" } }, "5551234567", "15551234567", "+1 (555) 123-4567"],
      [{ maskType: "datetime", maskSettings: { pattern: "mm/dd/yyyy" } }, "12252000", "2000-12-25", "12/25/2000"],
      [{ maskType: "numeric" }, "1234.5", 1234.5, "1,234.5"],
      [{ maskType: "currency", maskSettings: { prefix: "$ " } }, "1234.5", 1234.5, "$ 1,234.5"]
    ];
    cases.forEach(([element, digits, stored, shown]) => {
      expectSurveyData(element, shown, stored, (input) => typeInto(input, spell(digits)));
    });
  });

  test.each(DIGIT_BLOCKS)("%s digits pasted into a question end up in the survey's data", (_name, spell) => {
    questionPathCases(spell).forEach(([element, text, stored, shown]) => {
      expectSurveyData(element, shown, stored, (input) => fire(input, text, "insertFromPaste"));
    });
  });

  test.each(DIGIT_BLOCKS)("%s digits that reach a question without a keystroke end up in the survey's data", (_name, spell) => {
    questionPathCases(spell).forEach(([element, text, stored, shown]) => {
      expectSurveyData(element, shown, stored, (input) => {
        input.value = text;
        input.dispatchEvent(new Event("change"));
      });
    });
  });

  test.each(DIGIT_BLOCKS)("%s digits autofilled into an untouched question are saved without leaving the field", (_name, spell) => {
    autofillCases(spell).forEach(([element, text, stored, shown]) => {
      expectAutofill(element, text, stored, shown);
    });
  });

  test("a deletion after Arabic-Indic digits, and a letter in a digit slot", () => {
    withInput(patternMask("999"), "", (input) => {
      typeInto(input, ai("5") + eai("7"));
      expect(input.value, "typed digits").toBe("57_");

      typeInto(input, AR_YEH);
      expect(input.value, "a letter does not enter a digit slot").toBe("57_");

      input.setSelectionRange(2, 2);
      fire(input, null, "deleteContentBackward");
      expect(input.value, "backspace removes the digit before the caret").toBe("5__");
    });
  });
});

describe("masks without foreign digits", () => {
  test("ascii masking round-trips across mask types", () => {
    const pattern = patternMask("+1 (999) 999-9999");
    withInput(pattern, "", (input) => {
      typeInto(input, "5551234567");
      expect(input.value, "pattern").toBe("+1 (555) 123-4567");
      expect(pattern.getUnmaskedValue(input.value), "pattern value").toBe("15551234567");
    });

    const numeric = new InputMaskNumeric();
    expect(numeric.getMaskedValue(1234.5), "numeric masked").toBe("1,234.5");
    expect(numeric.getUnmaskedValue("1,234.5"), "numeric unmasked").toBe(1234.5);

    const date = dateMask("mm/dd/yyyy");
    withInput(date, "", (input) => {
      typeInto(input, "12252000");
      expect(date.getUnmaskedValue(input.value), "date value").toBe("2000-12-25");
    });
  });

  test("a pattern with Arabic-Indic digits in its fixed text keeps a full ascii entry", () => {
    const mask = patternMask(ai("12") + "-99");
    withInput(mask, "", (input) => {
      input.value = ai("12") + "-56";
      input.dispatchEvent(new Event("change"));
      expect(input.value, "the field").toBe(ai("12") + "-56");
      expect(mask.getUnmaskedValue(input.value), "the value").toBe("56");
    });
  });

  test("ascii autofilled into an untouched question is saved without leaving the field", () => {
    autofillCases((text: string) => text).forEach(([element, text, stored, shown]) => {
      expectAutofill(element, text, stored, shown);
    });
  });

  test("a text question with no mask keeps the digits it is given", () => {
    const q = newQuestion("ar", {});
    const input = document.createElement("input");
    document.body.appendChild(input);
    input.addEventListener("change", q.onChange);
    q.afterRenderQuestionElement(input);
    input.value = ai("12");
    input.dispatchEvent(new Event("change", { bubbles: true }));
    expect(q.survey.getValue("q1"), "the survey's data").toBe(ai("12"));
    q.onBlur({ target: input });
    expect(q.survey.getValue("q1"), "the survey's data after a blur").toBe(ai("12"));
    q.beforeDestroyQuestionElement(input);
    input.remove();
  });

  test("letter slots take letters and leave Arabic-Indic digits and Arabic letters out", () => {
    withInput(patternMask("aaa"), "", (input) => {
      typeInto(input, "b" + ai("5") + AR_YEH + "c");
      expect(input.value, "only the latin letters land").toBe("bc_");
    });
  });

  test("alignment is kept and removing the mask clears its style", () => {
    const q = new QuestionTextModel("q1");
    q.maskType = "numeric";
    expect(q.inputStyle.textAlign, "numeric right-aligns").toBe("right");
    q.maskType = "currency";
    expect(q.inputStyle.textAlign, "currency right-aligns").toBe("right");
    q.maskType = "none";
    expect(q.inputStyle.textAlign, "no mask, no alignment").toBeUndefined();
    expect(q.inputStyle.direction, "no mask, no direction").toBeUndefined();
    expect(q.inputStyle.width, "no mask, width as before").toBe("");
  });

  test("masked fields in a left-to-right survey keep their alignment and direction", () => {
    const numeric = newQuestion("en", { maskType: "numeric" });
    expect(numeric.inputStyle.textAlign, "numeric alignment").toBe("right");
    expect(["", "auto", "inherit", "unset", ...LEFT_TO_RIGHT], "numeric direction").toContain(renderedDirection(numeric, "en") ?? "");
    expect(["", "auto", "inherit", "unset", ...LEFT_TO_RIGHT], "pattern direction").toContain(directionOf("en", { maskType: "pattern", maskSettings: { pattern: "+1 (999) 999-9999" } }) ?? "");
  });
});
