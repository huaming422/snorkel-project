#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
#
# The image baked the survey-core dependency closure at the base commit
# (Dockerfile block 10, `npm ci`). No manifest or lockfile changes after that, so
# nothing new needs fetching. This script makes those baked deps available to
# vitest. It can run with the network cut, so every install here must resolve
# from the image cache.

REPO_DIR="${REPO_DIR:-/repo/survey-library}"
export REPO_DIR
cd "$REPO_DIR/packages/survey-core"

# Make a cache miss fail fast instead of reaching for the registry.
export npm_config_offline=true

# harbor's js runner reads verify.toml via tomllib (3.11+) or tomli (<=3.10).
# The base image ships Python 3.10 with neither; without tomli, verify.toml is
# silently dropped and the runner falls back to its `npx jest` default, which
# fails because survey-core uses vitest. The tooling venv (3.12) has tomllib,
# so this is a defensive install for the system python the runner may use.
if ! python3 -c "import tomllib" >/dev/null 2>&1 && \
   ! python3 -c "import tomli"   >/dev/null 2>&1; then
    {
        python3 -m pip install --quiet "tomli==2.0.1" \
            || python3 -m pip install --break-system-packages --quiet "tomli==2.0.1" \
            || true
    } >/dev/null 2>&1
fi

# Dependencies: offline-first against the image bake, logged online fallback.
if [ -x node_modules/.bin/vitest ]; then
    echo "[offline-first] survey-core deps satisfied from image (vitest present)"
elif npm ci --offline > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] survey-core deps restored from npm cache"
elif npm ci >> /tmp/test-setup-install.log 2>&1; then
    echo "[test-setup] survey-core deps installed online (image bake was stale)"
else
    tail -40 /tmp/test-setup-install.log >&2; exit 1
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
