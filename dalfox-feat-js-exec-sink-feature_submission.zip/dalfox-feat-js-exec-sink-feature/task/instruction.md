## Task

Dalfox marks a reflected parameter Verified (`[V]`) only when it can craft a payload that breaks out of the surrounding quotes or tag. That misses a real class of executable reflections. When a target escapes or strips the quote characters but still feeds the parameter into a JavaScript execution sink, say a call that runs a string as code or a navigation that builds a `javascript:` URL, the input runs as code with no breakout at all, and the scanner currently reports nothing verified for it.

We want Dalfox to catch this: a reflection that reaches a JavaScript execution sink should come back Verified too.

Everything runs offline here. The full dependency closure is baked in, so `cargo build --locked` works with no network and there are no new crates to pull. Point the scanner at a localhost target when you exercise it.

## User stories / requirements

- When a parameter is reflected into a JavaScript timer or exec call that runs a string of code, and the server has stripped the quote and angle-bracket characters so no breakout is possible, the scanner still reports it as Verified (`[V]`), driven by a payload that executes without closing any quote.
- When a parameter is concatenated into a navigation assignment that forms a `javascript:` URL, the scanner reports it as Verified (`[V]`).
- The same holds for the other JavaScript execution sinks in this class: string-taking eval and function constructors, the interval timer, and the navigation methods and `href` assignments that build a `javascript:` URL. A parameter reflected into any of these comes back Verified (`[V]`).
- When a parameter only lands as inert data inside a function call within a `javascript:` URL, with its surrounding quote never closed so nothing executes, the scanner does not report it as Verified; no finding of type `V` appears for it.
- A classic reflection that Dalfox already confirms by breaking out of a quote or tag keeps coming back as Verified (`[V]`).
