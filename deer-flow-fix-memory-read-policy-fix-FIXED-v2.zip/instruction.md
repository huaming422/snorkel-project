## Task

our lead agent can be hooked up to a memory store under a rule that no answer goes out without the background we hold for that user. in that mode a lookup that doesn't succeed is supposed to end the turn with an error.

in practice the turn keeps going and the model answers blind. with one of the stores this happens on an ordinary failed lookup (can't connect, or the store refuses). with all of them it happens when a lookup runs past the injection deadline and the memory just gets skipped while the request carries on as if nothing were wrong.

setups that allow missing memory work fine and shouldn't change, and neither should anything with memory or injection switched off. only the demanding setups are being ignored. fix that for failed lookups and for the deadline alike. the stores don't all name the demanding mode the same way in their config, and stores that live outside this repo and use the plain fail_closed value are covered too.

also, the deadline has to be met even when every worker thread is already busy. the turn mustn't hang around waiting for a free one.
