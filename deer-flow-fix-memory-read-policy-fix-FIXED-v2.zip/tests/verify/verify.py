"""Behavioral checks for strict ("required") memory-read enforcement.

Every check drives the real memory backends and the two places where the lead
agent loads memory (the prompt assembly and the dynamic-context injection),
using the same backend settings an operator would write in the config file.
Nothing here depends on the name of a helper, an error class, or how a fix
splits its work between the backends and the host code:

  * backend reads:   OpenVikingMemoryManager / Mem0Manager / HonchoMemoryManager
  * prompt assembly: deerflow.agents.lead_agent.prompt._get_memory_context
  * injection path:  DynamicContextMiddleware.before_agent / .abefore_agent

A strict setup is one where the config says a failed read must stop the turn:
``failure_policy.read`` is ``raise`` for OpenViking and ``fail_closed`` for mem0,
honcho and third-party backends. A tolerant setup is ``fail_open`` (or nothing).
Strict means the call raises, whatever the exception type; tolerant means the
turn goes on with no memory.
"""

from __future__ import annotations

import asyncio
import copy
import socket
import sys
import threading
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path
from types import SimpleNamespace
from typing import Any
from unittest import mock
from unittest.mock import MagicMock

import pytest

# Import isolation: the production code has an import cycle through
# ``deerflow.subagents``. The backend test suite breaks it by registering a
# stand-in for the executor module before anything imports it; this file runs
# outside that suite, so the same stand-in is installed here. ``setdefault``
# keeps a real module if one is already loaded.
_executor_stub = MagicMock()
_executor_stub.SubagentExecutor = MagicMock
_executor_stub.SubagentResult = MagicMock
_executor_stub.SubagentStatus = MagicMock
_executor_stub.MAX_CONCURRENT_SUBAGENTS = 3
_executor_stub.get_background_task_result = MagicMock()
sys.modules.setdefault("deerflow.subagents.executor", _executor_stub)

from deerflow.agents.lead_agent import prompt as prompt_module  # noqa: E402
from deerflow.agents.memory import (  # noqa: E402
    MemoryManager,
    MemoryManagerError,
    reset_memory_manager,
)
from deerflow.agents.memory.backends.honcho.client import HonchoRequestError  # noqa: E402
from deerflow.agents.memory.backends.honcho.honcho_manager import HonchoMemoryManager  # noqa: E402
from deerflow.agents.memory.backends.mem0.client import Mem0APIError  # noqa: E402
from deerflow.agents.memory.backends.mem0.mem0_manager import Mem0Manager  # noqa: E402
from deerflow.agents.memory.backends.openviking.openviking_manager import (  # noqa: E402
    OpenVikingMemoryManager,
)
from deerflow.agents.memory.manager import _scan_backends  # noqa: E402
from deerflow.agents.middlewares.dynamic_context_middleware import (  # noqa: E402
    DynamicContextMiddleware,
)
from deerflow.config.memory_config import MemoryConfig  # noqa: E402
from langchain_core.documents import Document  # noqa: E402
from langchain_core.messages import HumanMessage  # noqa: E402
from pydantic import PrivateAttr  # noqa: E402

pytestmark = pytest.mark.filterwarnings("ignore::DeprecationWarning")

DEADLINE = "deerflow.agents.middlewares.dynamic_context_middleware._INJECT_TIMEOUT_SECONDS"
GET_MANAGER = "deerflow.agents.memory.get_memory_manager"
RESOLVE_USER = "deerflow.agents.middlewares.dynamic_context_middleware.resolve_runtime_user_id"


@pytest.fixture(autouse=True)
def _isolate_memory_singleton():
    """Keep the process-global manager and backend registry cache clean per test."""
    reset_memory_manager()
    yield
    reset_memory_manager()


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------
def _memory_config(manager_class: str, backend_config: dict[str, Any]) -> MemoryConfig:
    return MemoryConfig(manager_class=manager_class, backend_config=backend_config)


def _app_config(manager_class: str, backend_config: dict[str, Any]) -> SimpleNamespace:
    return SimpleNamespace(memory=_memory_config(manager_class, backend_config))


def _exception_chain(exc: BaseException) -> list[BaseException]:
    seen: set[int] = set()
    out: list[BaseException] = []
    cur: BaseException | None = exc
    while cur is not None and id(cur) not in seen:
        seen.add(id(cur))
        out.append(cur)
        cur = cur.__cause__ or cur.__context__
    return out


# ---------------------------------------------------------------------------
# OpenViking test doubles (offline). The "unreachable" cases use the real
# integration against a refused socket.
# ---------------------------------------------------------------------------
_ACTOR_PEER: ContextVar[str | None] = ContextVar("verify_actor_peer", default=None)


@contextmanager
def _use_actor_peer(peer_id: str | None):
    token = _ACTOR_PEER.set(peer_id)
    try:
        yield
    finally:
        _ACTOR_PEER.reset(token)


class _CommitPolicy:
    def __init__(self, *, mode: str, pending_token_threshold: int = 8_000):
        self.mode = mode
        self.pending_token_threshold = pending_token_threshold


class _PartialWriteError(RuntimeError):
    def __init__(self, consumed: int, *, commit_pending: bool = False) -> None:
        super().__init__("partial")
        self.input_messages_consumed = consumed
        self.commit_pending = commit_pending


class _Client:
    supports_request_actor_peer = True

    def __init__(self, **kwargs: Any):
        self.kwargs = kwargs
        self.closed = False
        self.healthy = True

    def health(self) -> bool:
        return self.healthy

    def close(self) -> None:
        self.closed = True


class _Recorder:
    def __init__(self, *, commit_policy, url, api_key, timeout, extra_headers) -> None:
        self.commit_policy = commit_policy
        self.connection = {"url": url, "api_key": api_key, "timeout": timeout, "extra_headers": extra_headers}
        self._client = _Client(**self.connection)
        self.closed = False

    @property
    def client(self) -> _Client:
        return self._client

    def close(self) -> None:
        self.closed = True
        self._client.close()


class _Retriever:
    def __init__(self, *, client: _Client, **kwargs: Any):
        self.client = client
        self.kwargs = kwargs
        self.limit = kwargs["limit"]
        self.filter = None
        self.session_id = kwargs.get("session_id")
        self.target_uri = kwargs.get("target_uri", "")
        self.calls: list[dict[str, Any]] = []

    def __copy__(self) -> "_Retriever":
        copied = type(self)(client=self.client, **self.kwargs)
        copied.calls = self.calls
        copied.limit = self.limit
        copied.filter = copy.deepcopy(self.filter)
        copied.session_id = self.session_id
        copied.target_uri = copy.deepcopy(self.target_uri)
        return copied

    def invoke(self, query: str) -> list[Document]:
        self.calls.append({"query": query, "actor_peer": _ACTOR_PEER.get()})
        return [Document(page_content="Prefers concise answers.", metadata={})]


_OFFICIAL_INTEGRATION = {
    "OpenVikingCommitPolicy": _CommitPolicy,
    "OpenVikingPartialWriteError": _PartialWriteError,
    "OpenVikingRetriever": _Retriever,
    "OpenVikingSessionRecorder": _Recorder,
    "use_actor_peer": _use_actor_peer,
}


@pytest.fixture
def official_integration(monkeypatch: pytest.MonkeyPatch) -> None:
    import deerflow.agents.memory.backends.openviking.openviking_manager as module

    monkeypatch.setattr(module, "_load_official_integration", lambda: dict(_OFFICIAL_INTEGRATION))


@pytest.fixture
def unreachable_url():
    # A bound-but-not-listening socket gives a fast connection refusal.
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as reserved:
        reserved.bind(("127.0.0.1", 0))
        host, port = reserved.getsockname()
        yield f"http://{host}:{port}"


def _ov_backend_config(tmp_path: Path, **overrides: Any) -> dict[str, Any]:
    config: dict[str, Any] = {
        "base_url": "http://openviking:1933",
        "storage_path": str(tmp_path),
        "owner_user_id": "alice",
        "startup_policy": "warn",
        "retrieval": {
            "top_k": 4,
            "max_injection_chars": 1_000,
            "injection_query": "profile preferences and prior decisions",
        },
    }
    config.update(overrides)
    return config


def _ov_manager(backend_config: dict[str, Any], monkeypatch: pytest.MonkeyPatch) -> OpenVikingMemoryManager:
    monkeypatch.setenv("OPENVIKING_API_KEY", "user-key")
    return OpenVikingMemoryManager.from_config(backend_config)


# ---------------------------------------------------------------------------
# mem0 / honcho doubles
# ---------------------------------------------------------------------------
def _mem0_manager(backend_config: dict[str, Any], monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("MEM0_API_KEY", "test-key")
    mgr = Mem0Manager(backend_config=backend_config, mode="middleware")

    class _FakeMem0Client:
        def __init__(self) -> None:
            self.error: Exception | None = None
            self.list_results: list[dict] = []

        def list_memories(self, **_kw):
            if self.error is not None:
                raise self.error
            return self.list_results

        def close(self):
            pass

    fake = _FakeMem0Client()
    mgr._client = fake
    return mgr, fake


def _honcho_manager(backend_config: dict[str, Any]):
    mgr = HonchoMemoryManager.from_config({"base_url": "http://honcho.test", **backend_config})

    class _FakeHonchoClient:
        def __init__(self) -> None:
            self.raise_on: str | None = None
            self.representation_text = "likes concise answers"

        def _maybe_raise(self, name):
            if self.raise_on == name:
                raise HonchoRequestError(name)

        def working_representation(self, ws, pid, *, max_conclusions=25):
            self._maybe_raise("representation")
            return self.representation_text

        def close(self):
            pass

    fake = _FakeHonchoClient()
    mgr._client = fake
    return mgr, fake


# Strict and tolerant spellings of the read policy, per backend, exactly as the
# operator writes them under ``backend_config.failure_policy.read``.
POLICIES = {
    "openviking": {"strict": "raise", "open": "fail_open"},
    "mem0": {"strict": "fail_closed", "open": "fail_open"},
    "honcho": {"strict": "fail_closed", "open": "fail_open"},
}
BACKENDS = list(POLICIES)


def _failing_backend(
    backend: str,
    kind: str,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    unreachable_url: str,
) -> tuple[Any, dict[str, Any], str]:
    """A real manager of ``backend`` whose reads fail, plus the backend config it
    was built from and the user id to read for."""
    policy = {"read": POLICIES[backend][kind]}
    if backend == "openviking":
        cfg = _ov_backend_config(tmp_path, base_url=unreachable_url, timeout_seconds=0.1, failure_policy=policy)
        return _ov_manager(cfg, monkeypatch), cfg, "alice"
    if backend == "mem0":
        cfg = {"failure_policy": policy}
        mgr, fake = _mem0_manager(cfg, monkeypatch)
        fake.error = Mem0APIError("down")
        return mgr, cfg, "u1"
    cfg = {"failure_policy": policy}
    mgr, fake = _honcho_manager(cfg)
    fake.raise_on = "representation"
    return mgr, cfg, "u1"


# ===========================================================================
# 1. A failed read at the prompt-assembly call site: strict stops the turn,
#    tolerant carries on with no memory.
# ===========================================================================
@pytest.mark.parametrize("kind", ["strict", "open"])
@pytest.mark.parametrize("backend", BACKENDS)
def test_failed_read_follows_the_read_policy(
    backend: str,
    kind: str,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    unreachable_url: str,
) -> None:
    manager, cfg, user_id = _failing_backend(backend, kind, tmp_path, monkeypatch, unreachable_url)
    monkeypatch.setattr(GET_MANAGER, lambda: manager)
    app_config = _app_config(backend, cfg)

    if kind == "strict":
        with pytest.raises(Exception):
            prompt_module._get_memory_context("research", app_config=app_config, user_id=user_id)
    else:
        assert prompt_module._get_memory_context("research", app_config=app_config, user_id=user_id) == ""


@pytest.mark.asyncio
@pytest.mark.parametrize("kind", ["strict", "open"])
async def test_openviking_async_read_follows_the_read_policy(
    kind: str, tmp_path: Path, monkeypatch: pytest.MonkeyPatch, unreachable_url: str
) -> None:
    manager, _cfg, user_id = _failing_backend("openviking", kind, tmp_path, monkeypatch, unreachable_url)
    if kind == "strict":
        with pytest.raises(Exception):
            await manager.aget_context(user_id, agent_name="research")
    else:
        assert await manager.aget_context(user_id, agent_name="research") == ""


@pytest.mark.parametrize("backend", BACKENDS)
def test_healthy_read_under_strict_policy_still_returns_memory(
    backend: str, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A strict setup only stops the turn when the read fails; a read that works
    still injects the memory block."""
    policy = {"read": POLICIES[backend]["strict"]}
    if backend == "openviking":
        import deerflow.agents.memory.backends.openviking.openviking_manager as module

        monkeypatch.setattr(module, "_load_official_integration", lambda: dict(_OFFICIAL_INTEGRATION))
        cfg = _ov_backend_config(tmp_path, failure_policy=policy)
        manager, user_id, expected = _ov_manager(cfg, monkeypatch), "alice", "Prefers concise answers"
    elif backend == "mem0":
        cfg = {"failure_policy": policy}
        manager, fake = _mem0_manager(cfg, monkeypatch)
        fake.list_results = [{"id": "m1", "memory": "likes concise answers"}]
        user_id, expected = "u1", "likes concise answers"
    else:
        cfg = {"failure_policy": policy}
        manager, _fake = _honcho_manager(cfg)
        user_id, expected = "u1", "likes concise answers"
    monkeypatch.setattr(GET_MANAGER, lambda: manager)

    block = prompt_module._get_memory_context("research", app_config=_app_config(backend, cfg), user_id=user_id)
    assert expected in block


# ===========================================================================
# 2. The same failure through the injection path the lead agent really uses.
# ===========================================================================
@pytest.mark.parametrize("kind", ["strict", "open"])
def test_injection_path_follows_the_read_policy_when_the_read_fails(
    kind: str, tmp_path: Path, monkeypatch: pytest.MonkeyPatch, unreachable_url: str
) -> None:
    manager, cfg, user_id = _failing_backend("mem0", kind, tmp_path, monkeypatch, unreachable_url)
    monkeypatch.setattr(GET_MANAGER, lambda: manager)
    monkeypatch.setattr(RESOLVE_USER, lambda runtime: user_id)
    middleware = DynamicContextMiddleware(app_config=_app_config("mem0", cfg))
    state = {"messages": [HumanMessage("answer this", id="message-1")]}

    if kind == "strict":
        with pytest.raises(Exception):
            middleware.before_agent(state, None)
    else:
        middleware.before_agent(state, None)


# ===========================================================================
# 3. OpenViking scope mismatch (the read is for a user the key does not belong
#    to): strict stops the turn before any retrieval; tolerant carries on.
# ===========================================================================
@pytest.mark.parametrize("kind", ["strict", "open"])
def test_scope_mismatch_follows_the_read_policy(
    kind: str, tmp_path: Path, monkeypatch: pytest.MonkeyPatch, official_integration: None
) -> None:
    cfg = _ov_backend_config(tmp_path, failure_policy={"read": POLICIES["openviking"][kind]})
    manager = _ov_manager(cfg, monkeypatch)
    monkeypatch.setattr(GET_MANAGER, lambda: manager)
    monkeypatch.setattr(RESOLVE_USER, lambda runtime: "bob")
    middleware = DynamicContextMiddleware(app_config=_app_config("openviking", cfg))
    state = {"messages": [HumanMessage("answer this", id="message-1")]}

    if kind == "strict":
        with pytest.raises(Exception):
            middleware.before_agent(state, None)
    else:
        middleware.before_agent(state, None)
    assert manager._retriever.calls == []


# ===========================================================================
# 4. Prompt-assembly behavior that must not change.
# ===========================================================================
def _throwing_manager(exc: BaseException) -> SimpleNamespace:
    def _boom(*_a, **_k):
        raise exc

    return SimpleNamespace(get_context=_boom)


def test_prompt_swallows_ordinary_manager_error_without_fail_closed(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(GET_MANAGER, lambda: _throwing_manager(MemoryManagerError("down")))
    assert prompt_module._get_memory_context("research", app_config=_app_config("noop", {}), user_id="user-1") == ""


def test_prompt_swallows_unexpected_error_under_fail_open(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(GET_MANAGER, lambda: _throwing_manager(RuntimeError("down")))
    cfg = {"failure_policy": {"read": "fail_open"}}
    assert prompt_module._get_memory_context("research", app_config=_app_config("noop", cfg), user_id="user-1") == ""


def test_prompt_keeps_legacy_fail_closed_manager_error(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(GET_MANAGER, lambda: _throwing_manager(MemoryManagerError("down")))
    cfg = {"failure_policy": {"read": "fail_closed"}}
    with pytest.raises(MemoryManagerError, match="down"):
        prompt_module._get_memory_context("research", app_config=_app_config("noop", cfg), user_id="user-1")


def test_prompt_returns_empty_when_memory_is_disabled(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(GET_MANAGER, lambda: _throwing_manager(MemoryManagerError("down")))
    disabled = SimpleNamespace(
        memory=SimpleNamespace(
            enabled=False,
            injection_enabled=False,
            backend_config={"failure_policy": {"read": "fail_closed"}},
        )
    )
    assert prompt_module._get_memory_context("research", app_config=disabled, user_id="user-1") == ""


def test_tolerant_defaults_still_swallow_backend_read_errors(monkeypatch: pytest.MonkeyPatch) -> None:
    mem0, mem0_fake = _mem0_manager({}, monkeypatch)
    mem0_fake.error = Mem0APIError("transient")
    assert mem0.get_context("u1") == ""

    honcho, honcho_fake = _honcho_manager({})
    honcho_fake.raise_on = "representation"
    assert honcho.get_context("u1") == ""


# ===========================================================================
# 5. The injection deadline. Each case runs a read that outlives the deadline.
#    Strict: the request fails. Tolerant: it returns None and the turn goes on.
#    Either way the request must come back by itself, without waiting for the
#    worker, even when the worker pool is already full.
# ===========================================================================
async def _settle(call, limit: float = 0.25) -> tuple[BaseException | None, Any]:
    """Run ``call`` and require it to finish within ``limit`` seconds.

    Returns ``(exception, result)``. A call that is still pending at ``limit`` is
    cancelled and reported as a failure, so a hung request can never be mistaken
    for a raised error.
    """
    task = asyncio.ensure_future(call)
    done, _ = await asyncio.wait({task}, timeout=limit)
    if not done:
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)
        pytest.fail(f"the request was still waiting {limit}s after the injection deadline")
    exc = task.exception()
    return exc, (None if exc is not None else task.result())


def _timeout_middleware(backend: str, kind: str) -> DynamicContextMiddleware:
    cfg: dict[str, Any] = {"failure_policy": {"read": POLICIES[backend][kind]}}
    if backend == "openviking":
        cfg["owner_user_id"] = "alice"
    return DynamicContextMiddleware(app_config=_app_config(backend, cfg))


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("kind", "already_full"),
    [
        pytest.param("strict", False, id="strict-read_occupies_worker"),
        pytest.param("strict", True, id="strict-pool_already_full"),
        pytest.param("open", False, id="open-read_occupies_worker"),
    ],
)
@pytest.mark.parametrize("backend", BACKENDS)
async def test_injection_deadline_follows_the_read_policy(
    monkeypatch: pytest.MonkeyPatch, backend: str, kind: str, already_full: bool
) -> None:
    monkeypatch.setenv("OPENVIKING_API_KEY", "test-key")
    monkeypatch.setenv("MEM0_API_KEY", "test-key")
    await asyncio.to_thread(_scan_backends)
    mw = _timeout_middleware(backend, kind)
    entered, release, finished = threading.Event(), threading.Event(), threading.Event()
    executor = ThreadPoolExecutor(max_workers=1)
    loop = asyncio.get_running_loop()

    def occupy_worker(*_args):
        entered.set()
        release.wait(timeout=2)
        finished.set()

    try:
        with mock.patch.object(loop, "_default_executor", executor):
            if already_full:
                executor.submit(occupy_worker)
                while not entered.is_set():
                    await asyncio.sleep(0)
            with (
                mock.patch.object(mw, "_inject", side_effect=occupy_worker) as inject,
                mock.patch(DEADLINE, 0.01),
            ):
                exc, result = await _settle(
                    mw.abefore_agent({"messages": [HumanMessage(content="hi", id="m1")]}, SimpleNamespace(context={}))
                )
                if kind == "strict":
                    assert exc is not None, "a strict read policy must stop the turn at the injection deadline"
                else:
                    assert exc is None, f"a tolerant read policy must not fail the turn: {exc!r}"
                    assert result is None
                # The request resolved before its worker finished, and nothing was
                # queued behind a full pool.
                assert not finished.is_set()
                assert inject.call_count == (0 if already_full else 1)
    finally:
        release.set()
        await asyncio.to_thread(executor.shutdown, wait=True, cancel_futures=True)


@pytest.mark.asyncio
async def test_strict_policy_without_a_timeout_injects_normally(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OPENVIKING_API_KEY", "test-key")
    mw = _timeout_middleware("openviking", "strict")
    with mock.patch.object(mw, "_inject", return_value=None) as inject:
        result = await mw.abefore_agent({"messages": [HumanMessage(content="hi", id="m1")]}, SimpleNamespace(context={}))
    assert result is None
    assert inject.call_count == 1


@pytest.mark.asyncio
@pytest.mark.parametrize("disabled_field", ["enabled", "injection_enabled"])
async def test_disabled_memory_degrades_at_the_deadline_without_injection(
    monkeypatch: pytest.MonkeyPatch, disabled_field: str
) -> None:
    """With memory or injection turned off nothing is read, so even a strict
    setup carries on, and nothing is injected, while the worker pool is full."""
    monkeypatch.setenv("OPENVIKING_API_KEY", "test-key")
    cfg = _memory_config("openviking", {"failure_policy": {"read": "raise"}, "owner_user_id": "alice"})
    setattr(cfg, disabled_field, False)
    mw = DynamicContextMiddleware(app_config=SimpleNamespace(memory=cfg))
    executor = ThreadPoolExecutor(max_workers=1)
    release = threading.Event()
    try:
        with (
            mock.patch.object(asyncio.get_running_loop(), "_default_executor", executor),
            mock.patch.object(mw, "_inject") as inject,
            mock.patch(DEADLINE, 0.01),
        ):
            executor.submit(release.wait, 2)  # fill the single worker
            exc, result = await _settle(mw.abefore_agent({}, SimpleNamespace(context={})))
            assert exc is None
            assert result is None
            inject.assert_not_called()
    finally:
        release.set()
        await asyncio.to_thread(executor.shutdown, wait=True, cancel_futures=True)


# ===========================================================================
# 6. Backends that come from outside the repo and use the plain fail_closed
#    setting: strict at the deadline, tolerant otherwise.
# ===========================================================================
class _OutsideBackend(MemoryManager):
    """A third-party backend that adds no policy handling of its own."""

    _release: threading.Event = PrivateAttr(default_factory=threading.Event)
    _finished: threading.Event = PrivateAttr(default_factory=threading.Event)

    @classmethod
    def from_config(cls, backend_config, *, mode="middleware", **host_hooks):
        return cls(backend_config=backend_config, mode=mode)

    def add(self, thread_id, messages, **kwargs):
        pass

    def get_context(self, user_id, **kwargs):
        try:
            self._release.wait(timeout=2)
            return "Late memory context"
        finally:
            self._finished.set()


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("read_config", "strict"),
    [
        pytest.param({"failure_policy": {"read": "fail_closed"}}, True, id="fail_closed"),
        pytest.param({"failure_policy": {"read": "fail_open"}}, False, id="fail_open"),
        pytest.param({}, False, id="no_policy"),
    ],
)
async def test_outside_backend_deadline_follows_fail_closed(read_config: dict, strict: bool) -> None:
    cfg = _memory_config(f"{__name__}:_OutsideBackend", read_config)
    backend = _OutsideBackend.from_config(cfg.backend_config)
    mw = DynamicContextMiddleware(app_config=SimpleNamespace(memory=cfg))
    executor = ThreadPoolExecutor(max_workers=1)
    try:
        with (
            mock.patch.object(asyncio.get_running_loop(), "_default_executor", executor),
            mock.patch(GET_MANAGER, return_value=backend),
            mock.patch(DEADLINE, 0.01),
        ):
            exc, result = await _settle(
                mw.abefore_agent({"messages": [HumanMessage(content="hi", id="m1")]}, SimpleNamespace(context={}))
            )
            if strict:
                assert exc is not None
            else:
                assert exc is None
                assert result is None
            assert not backend._finished.is_set()
    finally:
        backend._release.set()
        await asyncio.to_thread(executor.shutdown, wait=True, cancel_futures=True)
    assert backend._finished.is_set()
