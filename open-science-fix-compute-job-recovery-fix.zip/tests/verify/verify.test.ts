// @ts-nocheck
//
// Behavioral verifier for the compute-job recovery regressions.
//
// Every case drives the compute subsystem through its PRE-EXISTING, stable
// public interfaces and asserts on OBSERVABLE OUTCOMES — persisted repository
// rows, returned admission decisions, probe-call counts, and the database
// CHECK constraint's accept/reject behavior. No implementation-introduced
// symbol is imported (in particular there is no dependency on any specific
// retryable-error class): a fix that signals "retry rather than finalize"
// by any means, and relaxes the harvest-payload constraint by any append-only
// migration, passes.
//
// Interfaces used (all present at the base commit):
//   resolveInputs, dispatchJob, ComputeJobCancellationOwner/Reaper,
//   DispatchTracker, ConcurrencyManager, harvestJob, JobHarvestScheduler,
//   JobPoller, createComputeJobRuntime, ComputeHostRepository,
//   createMigratedComputeTestDatabase, migrateApplicationDatabase.

import { execFile } from 'node:child_process'
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { promisify } from 'node:util'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import type { ComputeJob } from '../../shared/compute'
import { createMigratedComputeTestDatabase } from './compute-integration.test-support'
import {
  ComputeJobCancellationOwner,
  ComputeJobCancellationReaper
} from './compute-job-cancellation-owner'
import { resolveInputs } from './compute-job-workflow-owner'
import { ConcurrencyManager } from './concurrency-manager'
import type { ComputeConnectionBroker, ComputeConnectionLease } from './connection-broker'
import { DispatchTracker } from './dispatch-tracker'
import { harvestJob, type HarvestDeps } from './harvest-engine'
import { dispatchJob } from './job-dispatcher'
import { JobHarvestScheduler } from './job-harvest-scheduler'
import { JobPoller } from './job-poller'
import { createComputeJobRuntime } from './job-runtime'
import { ComputeHostRepository } from './repository'
import { createProjectDbClient } from '../projects/prisma-client'
import { MIGRATION_MANIFEST, migrateApplicationDatabase } from '../database/migration-service'
import { visionEvidenceMigration } from '../database/migrations/0009-vision-evidence'
import { applySqliteMigrationOperations } from '../database/sqlite-schema-migrations'

const deferred = <T = void>(): {
  promise: Promise<T>
  resolve: (value: T | PromiseLike<T>) => void
} => {
  let resolve!: (value: T | PromiseLike<T>) => void
  const promise = new Promise<T>((done) => {
    resolve = done
  })
  return { promise, resolve }
}
const success = (stdout = ''): Awaited<ReturnType<ComputeConnectionLease['run']>> => ({
  stdout,
  stderr: '',
  exitCode: 0,
  timedOut: false,
  truncated: false
})
const shell = async (
  command: string
): Promise<Awaited<ReturnType<ComputeConnectionLease['run']>>> => {
  try {
    const { stdout, stderr } = await promisify(execFile)('bash', ['-c', command])
    return { ...success(stdout), stderr }
  } catch (error) {
    const result = error as { code: number; stdout: string; stderr: string }
    return { ...success(result.stdout), stderr: result.stderr, exitCode: result.code }
  }
}
const broker = (
  run: ComputeConnectionLease['run'],
  download: ComputeConnectionLease['download'] = vi.fn(async () => ({
    exitCode: 0,
    stderr: '',
    timedOut: false,
    bytesWritten: 0,
    exceeded: false
  }))
): ComputeConnectionBroker => ({
  acquire: vi.fn(async () => ({ run, upload: vi.fn(), download })),
  beginHostDeletion: vi.fn(async () => undefined),
  abortHostDeletion: vi.fn(),
  completeHostDeletion: vi.fn()
})

describe('Compute Job recovery behavior', () => {
  let db: Awaited<ReturnType<typeof createMigratedComputeTestDatabase>>
  let hosts: ComputeHostRepository
  const scope = { projectId: 'project-1', sessionId: 'session-1', providerId: 'ssh:recovery' }
  const createJob = async (
    status: 'submitted' | 'running' | 'success' = 'success',
    id = 'job-1',
    inputManifest?: string
  ): Promise<ComputeJob> => {
    await db.repositories.jobs.create({
      id,
      ...scope,
      shape: 'direct_ssh',
      intent: 'recovery',
      command: 'echo generated-command',
      commandHash: 'hash',
      initialStatus: status,
      allowUnencryptedPersistence: true,
      remoteWorkdir:
        process.platform === 'win32'
          ? `/scratch/.openscience/jobs/${id}`
          : join(db.storageRoot, '.openscience', 'jobs', id),
      inputManifest
    })
    return (await db.repositories.jobs.get(id))!
  }
  const deps = (connectionBroker = broker(vi.fn(async () => success()))): HarvestDeps => ({
    storageRoot: db.storageRoot,
    jobRepository: db.repositories.jobs,
    hostRepository: hosts,
    connectionBroker,
    getFreeDiskBytesFn: async () => 10 ** 12
  })
  beforeEach(async () => {
    db = await createMigratedComputeTestDatabase('compute-job-recovery-')
    hosts = new ComputeHostRepository(() => Promise.resolve(db.client))
    await hosts.create({ sshAlias: 'recovery' })
    await hosts.updateConcurrencyLimit(scope.providerId, 1)
  })
  afterEach(async () => {
    await db.dispose()
  })

  // Criterion 1 — reserved-name collision rejected in BOTH paths.
  // (a) input resolution: a destination name that collides with a runner
  //     control/log file must be rejected. Only stable, pre-existing control
  //     and log file names are asserted (no implementation-added names). The
  //     assertion is that resolution REJECTS (any error) — the rejection
  //     message is solution-chosen, so no message substring is pinned.
  it.each(['command.sh', 'launcher.sh', 'exit_code', 'job.pid', 'stdout', 'stderr'])(
    'rejects reserved upload destination %s at input resolution',
    async (name) => {
      await expect(
        resolveInputs([{ src: 'data.txt', dst_filename: name }], db.storageRoot, undefined)
      ).rejects.toThrow()
    }
  )

  // (a-pass) a benign destination name still resolves to a single upload entry,
  //     so a guard that rejects every input (not just reserved ones) fails here.
  it('still resolves a non-reserved upload destination', async () => {
    const resolved = await resolveInputs(
      [{ src: 'data.txt', dst_filename: 'data.csv' }],
      db.storageRoot,
      undefined
    )
    expect(resolved.entries).toHaveLength(1)
    expect(resolved.entries[0]).toMatchObject({ kind: 'upload', dstFilename: 'data.csv' })
  })

  // (b) dispatcher staging: a stored manifest (built independently of input
  //     resolution) whose destination collides with a runner control/log file
  //     must never overwrite that control file, and the job must fail dispatch
  //     rather than launch. A reserved destination (`launcher.sh`) appears
  //     ALONGSIDE a benign one (`data.csv`) so a pre-fix run stages — and thus
  //     clobbers — the control file. The assertion is specifically that the
  //     RESERVED destination is never symlinked and no launch (nohup) occurs,
  //     and the job ends in `error`. It does NOT require zero symlinks: a fix
  //     that validates each entry inside the staging loop (and so stages the
  //     benign input before rejecting the reserved one) still protects the
  //     control file and still passes, as does one that validates the whole
  //     manifest up front. The generic error status is asserted without pinning
  //     a specific error code (the code is a pre-existing dispatch detail).
  it('never overwrites a control file named by a stored manifest and fails dispatch', async () => {
    await createJob(
      'submitted',
      'job-1',
      JSON.stringify([
        { kind: 'symlink', remotePath: '/original/data.csv', dstFilename: 'data.csv', label: 'data.csv' },
        { kind: 'symlink', remotePath: '/original/script', dstFilename: 'launcher.sh', label: 'script' }
      ])
    )
    const run = vi.fn<ComputeConnectionLease['run']>(async () => success())
    await dispatchJob('job-1', {
      connectionBroker: broker(run),
      hostRepository: hosts,
      jobRepository: db.repositories.jobs,
      dispatchTracker: new DispatchTracker()
    })
    // The reserved control file must never be the target of a symlink, and the
    // job must never launch.
    expect(
      run.mock.calls.some(
        ([command]) => command.includes('ln -s') && command.includes('launcher.sh')
      )
    ).toBe(false)
    expect(run.mock.calls.some(([command]) => command.includes('nohup'))).toBe(false)
    expect((await db.repositories.jobs.get('job-1'))?.status).toBe('error')
  })

  // Criterion 2 — cancellation reconciles against real dispatch/launch state.
  it('completes cancellation when the launch response arrives after the cancel request', async () => {
    const job = await createJob('submitted')
    const launchEntered = deferred()
    const launchResponse = deferred<ReturnType<typeof success>>()
    const run = vi.fn<ComputeConnectionLease['run']>(async (command) => {
      if (command.includes('nohup setsid')) {
        launchEntered.resolve()
        return launchResponse.promise
      }
      if (command.includes('OPEN_SCIENCE_DISPATCH_RECOVERY_V1')) {
        return success('OPEN_SCIENCE_DISPATCH_RECOVERY_V1\nworkdir:1\nexit_code:\npid:4242\ncwd_match:1')
      }
      return success(command.includes('kill -TERM') ? 'terminated' : 'absent')
    })
    const connectionBroker = broker(run)
    const dispatching = dispatchJob(job.job_id, {
      connectionBroker,
      hostRepository: hosts,
      jobRepository: db.repositories.jobs,
      dispatchTracker: new DispatchTracker()
    })
    await launchEntered.promise
    const owner = new ComputeJobCancellationOwner(db.repositories.operations, db.repositories.jobs)
    await owner.request(job.job_id, scope)
    launchResponse.resolve(success('4242'))
    await dispatching
    const reaper = new ComputeJobCancellationReaper(
      db.repositories.operations,
      db.repositories.jobs,
      connectionBroker,
      { retryDelayMs: () => 0 }
    )
    for (let attempt = 0; attempt < 3; attempt++) await reaper.runOnce()
    expect(await db.repositories.jobs.findNonTerminal()).toEqual([])
    expect(await owner.status(job.job_id, scope)).toMatchObject({
      cancellation_status: 'cancelled'
    })
  })

  it('does not confirm a missing launch while dispatch is still in flight', async () => {
    const job = await createJob('submitted')
    const owner = new ComputeJobCancellationOwner(db.repositories.operations, db.repositories.jobs)
    await owner.request(job.job_id, scope)
    const tracker = new DispatchTracker()
    tracker.begin(job.job_id)
    const connectionBroker = broker(vi.fn(async () => success('')))
    const reaper = new ComputeJobCancellationReaper(
      db.repositories.operations,
      db.repositories.jobs,
      connectionBroker,
      { dispatchTracker: tracker }
    )
    await reaper.runOnce()
    expect(connectionBroker.acquire).not.toHaveBeenCalled()
    expect((await owner.status(job.job_id, scope)).cancellation_status).toBe('cancelling')
    tracker.end(job.job_id)
  })

  // Criterion 3 — Direct SSH recovery branches on probed launch evidence.
  it.each(['not_started', 'running', 'pending'] as const)(
    'recovers cancellation after restart with %s launch evidence',
    async (evidence) => {
      const job = await createJob('submitted')
      const owner = new ComputeJobCancellationOwner(db.repositories.operations, db.repositories.jobs)
      await owner.request(job.job_id, scope)
      const observation =
        evidence === 'not_started'
          ? 'workdir:0\nexit_code:\npid:\ncwd_match:0'
          : evidence === 'running'
            ? 'workdir:1\nexit_code:\npid:4242\ncwd_match:1'
            : 'workdir:1\nexit_code:\npid:\ncwd_match:0'
      let remoteCancellationAttempted = false
      const run = vi.fn<ComputeConnectionLease['run']>(async (command) => {
        if (command.includes('OPEN_SCIENCE_DISPATCH_RECOVERY_V1')) {
          return success(`OPEN_SCIENCE_DISPATCH_RECOVERY_V1\n${observation}`)
        }
        remoteCancellationAttempted = true
        return success('absent')
      })
      const reaper = new ComputeJobCancellationReaper(
        db.repositories.operations,
        db.repositories.jobs,
        broker(run)
      )
      await reaper.runOnce()
      expect((await owner.status(job.job_id, scope)).cancellation_status).toBe(
        evidence === 'pending' ? 'cancelling' : 'cancelled'
      )
      expect(
        run.mock.calls.some(([command]) => command.includes('OPEN_SCIENCE_DISPATCH_RECOVERY_V1'))
      ).toBe(true)
      if (evidence === 'running') expect(remoteCancellationAttempted).toBe(true)
    }
  )

  // Criterion 4 — concurrency counts a cancel-pending job as active.
  it.each(['session', 'provider'])(
    'keeps the %s concurrency limit occupied until remote cancellation is confirmed',
    async (limit) => {
      await createJob('running')
      const jobs = db.repositories.jobs
      const manager = new ConcurrencyManager(jobs, hosts, vi.fn())
      if (limit === 'session') {
        await manager.setSessionLimit(scope.sessionId, 1)
        await hosts.updateConcurrencyLimit(scope.providerId, 10)
      }
      await new ComputeJobCancellationOwner(db.repositories.operations, jobs).request('job-1', scope)
      expect.soft(await jobs.countActiveBySession(scope.sessionId)).toBe(1)
      expect.soft(await jobs.countActiveByProvider(scope.providerId)).toBe(1)
      const admitted = await manager.admit(scope, async (initialStatus) => {
        await jobs.create({
          id: 'job-2',
          ...scope,
          shape: 'direct_ssh',
          intent: 'second job',
          command: 'true',
          commandHash: 'hash',
          initialStatus,
          allowUnencryptedPersistence: true
        })
      })
      expect.soft(await jobs.countActiveBySession(scope.sessionId)).toBe(1)
      expect.soft(await jobs.countActiveByProvider(scope.providerId)).toBe(1)
      expect(admitted).toBe('queued')
    }
  )

  // Criterion 5 — a no-launch cancellation finalizes the job cleanly.
  it('finishes harvest and makes notification ready when cancellation proves no launch occurred', async () => {
    const job = await createJob('submitted')
    await db.repositories.jobs.update(job.job_id, { submittedAt: new Date() })
    await new ComputeJobCancellationOwner(db.repositories.operations, db.repositories.jobs).request(
      job.job_id,
      scope
    )
    const confirmed = deferred()
    const run = vi.fn<ComputeConnectionLease['run']>(async (command) =>
      command.includes('OPEN_SCIENCE_DISPATCH_RECOVERY_V1')
        ? success('OPEN_SCIENCE_DISPATCH_RECOVERY_V1\nworkdir:0\nexit_code:\npid:\ncwd_match:0')
        : { ...success(), exitCode: 1, stderr: 'No such file or directory' }
    )
    const runtime = createComputeJobRuntime(
      {
        computeService: {
          handleJobUpdated: vi.fn(),
          handleJobCancellationConfirmed: async () => confirmed.resolve(),
          startQueueReconciliation: vi.fn(),
          stopQueueReconciliation: vi.fn(async () => undefined)
        },
        hostRepository: hosts,
        jobRepository: db.repositories.jobs,
        operationRepository: db.repositories.operations,
        connectionBroker: broker(run),
        storageRoot: db.storageRoot
      },
      {
        broadcast: vi.fn(),
        createPoller: () => ({
          start: () => undefined,
          stop: async () => undefined,
          pause: async () => undefined,
          resume: () => undefined
        })
      }
    )
    await runtime.start()
    try {
      await confirmed.promise
      const persisted = (await db.repositories.jobs.get(job.job_id))!
      expect.soft(persisted.harvested_at).toBeTruthy()
      expect.soft(persisted.harvest_error).toBeUndefined()
      expect.soft(persisted.remote_cleanup_disposition).toBe('cleaned')
      expect.soft(await db.repositories.jobs.findTerminalUnharvested()).toEqual([])
      expect
        .soft((await db.repositories.jobs.findNotificationReadyUnnotified()).map((row) => row.job_id))
        .toContain(job.job_id)
      expect(
        run.mock.calls.some(([command]) => command.includes('OPEN_SCIENCE_DISPATCH_RECOVERY_V1'))
      ).toBe(true)
    } finally {
      await runtime.stop()
    }
  })

  // Criterion 6 — harvest is idempotent: cancellation-completion and the
  // periodic poller scan share a single in-flight harvest per job.
  it('shares harvest execution between cancellation completion and the periodic scan', async () => {
    const job = await createJob('running')
    await db.repositories.jobs.update(job.job_id, {
      submittedAt: new Date(),
      remoteHandle: JSON.stringify({
        pid: 4242,
        workdir: job.remote_workdir,
        exit_code_path: `${job.remote_workdir}/exit_code`,
        stdout_path: `${job.remote_workdir}/stdout`,
        stderr_path: `${job.remote_workdir}/stderr`
      })
    })
    await new ComputeJobCancellationOwner(db.repositories.operations, db.repositories.jobs).request(
      job.job_id,
      scope
    )
    const entered = deferred()
    const release = deferred()
    const harvest = vi.fn(async () => {
      entered.resolve()
      await release.promise
    })
    let poller!: JobPoller
    const runtime = createComputeJobRuntime(
      {
        computeService: {
          handleJobUpdated: vi.fn(),
          handleJobCancellationConfirmed: vi.fn(async () => undefined),
          startQueueReconciliation: vi.fn(),
          stopQueueReconciliation: vi.fn(async () => undefined)
        },
        hostRepository: hosts,
        jobRepository: db.repositories.jobs,
        operationRepository: db.repositories.operations,
        connectionBroker: broker(vi.fn(async () => success('absent'))),
        storageRoot: db.storageRoot
      },
      {
        harvest,
        broadcast: vi.fn(),
        createPoller: (pollerDeps) => {
          poller = new JobPoller(pollerDeps)
          return {
            start: () => undefined,
            stop: () => poller.stop(),
            pause: () => poller.pause(),
            resume: () => poller.resume()
          }
        }
      }
    )
    await runtime.start()
    try {
      await entered.promise
      await poller.tick()
      expect(harvest).toHaveBeenCalledTimes(1)
    } finally {
      release.resolve()
      await runtime.stop()
    }
  })

  // Criterion 7 — transient harvest failures are retried, not finalized.
  // (a) an unreadable remote workdir throws an enumeration error and leaves
  //     the job terminal-unharvested (never a silent successful empty harvest).
  it.skipIf(process.platform === 'win32')(
    'does not report an unreadable remote workdir as a successful empty harvest',
    async () => {
      const job = await createJob()
      const run = vi.fn<ComputeConnectionLease['run']>((command) => shell(command))
      const failure = await harvestJob(job, deps(broker(run))).catch((error: unknown) => error)
      expect(failure).toBeInstanceOf(Error)
      const persisted = (await db.repositories.jobs.get(job.job_id))!
      expect.soft(persisted.harvest_error).toBeTruthy()
      expect.soft(persisted.harvested_at).toBeUndefined()
      expect(
        (await db.repositories.jobs.findTerminalUnharvested()).map((row) => row.job_id)
      ).toContain(job.job_id)
    }
  )

  // (b) a transient local free-space query failure leaves the job retryable;
  //     a second attempt clears the error and empties the unharvested set.
  it('retries harvest after a transient local free-space query failure', async () => {
    const job = await createJob()
    const getFreeDiskBytesFn = vi
      .fn()
      .mockRejectedValueOnce(new Error('temporary filesystem failure'))
      .mockResolvedValue(10 ** 12)
    const harvestDeps = { ...deps(), getFreeDiskBytesFn }
    await harvestJob(job, harvestDeps).catch(() => undefined)
    const pending = await db.repositories.jobs.findTerminalUnharvested()
    expect.soft((await db.repositories.jobs.get(job.job_id))?.harvested_at).toBeUndefined()
    expect(pending.map((row) => row.job_id)).toContain(job.job_id)
    await harvestJob(pending[0]!, harvestDeps)
    expect((await db.repositories.jobs.get(job.job_id))?.harvest_error).toBeUndefined()
    expect(await db.repositories.jobs.findTerminalUnharvested()).toEqual([])
  })

  // (c) the scheduler backs off a transient harvest failure and retries only
  //     after the backoff elapses. The REAL harvest function is wired into the
  //     scheduler, so the implementation emits whatever retry signal it uses
  //     and its own scheduler interprets it — no error class is imported or
  //     asserted. The backoff is observed behaviorally: a re-schedule inside
  //     the window makes no new harvest attempt, while one past the window
  //     retries and finalizes the job. `getFreeDiskBytesFn` (a legitimate
  //     harvest dependency) rejects once, then counts attempts.
  it('backs off a transient harvest failure and retries after the delay elapses', async () => {
    const job = await createJob()
    const getFreeDiskBytesFn = vi
      .fn()
      .mockRejectedValueOnce(new Error('temporary filesystem failure'))
      .mockResolvedValue(10 ** 12)
    const harvestDeps = { ...deps(), getFreeDiskBytesFn }
    let now = 0
    const scheduler = new JobHarvestScheduler(
      (scheduled) => harvestJob(scheduled, harvestDeps),
      () => now
    )

    // First attempt hits the transient failure: the job must remain
    // terminal-unharvested rather than being finalized.
    await scheduler.schedule(job)
    await scheduler.waitForIdle()
    expect.soft((await db.repositories.jobs.get(job.job_id))?.harvested_at).toBeUndefined()
    expect(
      (await db.repositories.jobs.findTerminalUnharvested()).map((row) => row.job_id)
    ).toContain(job.job_id)
    const attemptsAfterFailure = getFreeDiskBytesFn.mock.calls.length

    // A re-schedule inside the backoff window makes no new harvest attempt.
    await scheduler.schedule(job)
    await scheduler.waitForIdle()
    expect(getFreeDiskBytesFn.mock.calls.length).toBe(attemptsAfterFailure)
    expect.soft((await db.repositories.jobs.get(job.job_id))?.harvested_at).toBeUndefined()

    // Once the window elapses, the next schedule retries and finalizes.
    now = 60_000
    await scheduler.schedule(job)
    await scheduler.waitForIdle()
    expect(getFreeDiskBytesFn.mock.calls.length).toBeGreaterThan(attemptsAfterFailure)
    expect((await db.repositories.jobs.get(job.job_id))?.harvest_error).toBeUndefined()
    expect(await db.repositories.jobs.findTerminalUnharvested()).toEqual([])
  })

  // Criterion 8 — the harvest-payload CHECK is relaxed by an APPEND-ONLY forward
  // migration. This is observed on a LEGACY database, not a fresh one: a fresh DB
  // builds its ComputeJob table from the current generated schema, so relaxing
  // only the generated DDL (with no applied migration) would already let a fresh
  // DB persist a pending harvest error — a change that leaves every existing
  // production database broken. The contract requires that a legacy database
  // migrated forward and a freshly-migrated database CONVERGE on the same relaxed
  // schema. So this case stands up a legacy DB at the last pre-existing migration
  // tip (`0032_permission_approval_summary`), seeds historical + pending rows and
  // a cancel operation BEFORE migrating, then drives the full ledger via
  // `migrateApplicationDatabase` (which ends by verifying the live schema against
  // the generated schema — forcing migration ⇄ generated-schema consistency in
  // BOTH directions). It then asserts the rebuild preserved every row, operation,
  // and every existing index (rejecting a drop/recreate that loses data), the
  // pending harvest-error state is now representable, the genuine invariant still
  // holds, foreign keys are intact, and re-running is a no-op (append-only).
  // The migration is referenced only by the stable pre-existing tip id; the
  // agent's forward-migration id/shape is never named, so any append-only
  // relaxation passes.
  it('relaxes the harvest-payload constraint via an append-only forward migration that preserves a legacy database', async () => {
    const root = await mkdtemp(join(tmpdir(), 'harvest-constraint-migration-'))
    const client = createProjectDbClient(root)
    try {
      // Build a legacy database by replaying the migration ledger up to the last
      // migration that existed before this fix, so the forward migration under
      // test is the only one `migrateApplicationDatabase` still has to apply.
      const prefix = MIGRATION_MANIFEST.slice(
        0,
        MIGRATION_MANIFEST.findIndex((entry) => entry.id === '0032_permission_approval_summary') + 1
      )
      await client.$executeRawUnsafe('PRAGMA foreign_keys = OFF')
      for (const migration of prefix) {
        for (const statement of migration.statements) await client.$executeRawUnsafe(statement)
        if ('operations' in migration) {
          await client.$transaction((transaction) =>
            applySqliteMigrationOperations(transaction, migration.operations)
          )
        }
      }
      await client.$transaction((transaction) =>
        applySqliteMigrationOperations(transaction, visionEvidenceMigration.operations)
      )
      await client.$executeRawUnsafe('PRAGMA foreign_keys = ON')
      await client.$executeRawUnsafe(`CREATE TABLE "_open_science_migrations" (
        "id" TEXT NOT NULL PRIMARY KEY, "checksum" TEXT NOT NULL,
        "appliedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT "_open_science_migrations_checksum_check" CHECK (length("checksum") = 64 AND "checksum" NOT GLOB '*[^0-9a-f]*')
      )`)
      for (const migration of prefix) {
        await client.$executeRawUnsafe(
          'INSERT INTO "_open_science_migrations" (id, checksum) VALUES (?, ?)',
          migration.id,
          migration.checksum
        )
      }

      // Seed a historical finalized job, a pending job, and a cancel operation
      // BEFORE the forward migration runs, so the rebuild must copy real rows.
      for (const id of ['pending', 'historical']) {
        await client.$executeRawUnsafe(
          `INSERT INTO "ComputeJob" (id, "providerId", shape, "sessionId", "projectId", intent, command, "commandHash", status)
           VALUES (?, 'ssh:test', 'direct_ssh', 'session', 'project', 'research', 'true', 'hash', 'success')`,
          id
        )
      }
      await client.$executeRawUnsafe(
        `UPDATE "ComputeJob" SET "harvestedAt" = 123, "harvestError" = 'old error', "leftOnRemote" = '[]' WHERE id = 'historical'`
      )
      await client.$executeRawUnsafe(
        `INSERT INTO "ComputeJobOperation" (id, "jobId", kind, "updatedAt") VALUES ('operation', 'pending', 'cancel', 456)`
      )
      const jobsBefore = await client.$queryRawUnsafe('SELECT * FROM "ComputeJob" ORDER BY id')
      const operationsBefore = await client.$queryRawUnsafe('SELECT * FROM "ComputeJobOperation"')
      const indexesBefore = await client.$queryRawUnsafe(
        `SELECT name, sql FROM sqlite_master WHERE type = 'index' AND tbl_name = 'ComputeJob' ORDER BY name`
      )

      // Drive the full ledger forward. A fresh DB and this migrated legacy DB
      // must converge: migrateApplicationDatabase verifies the live schema
      // against the generated schema at the end, so a relaxed generated schema
      // with no applied migration (or the reverse) fails here.
      await migrateApplicationDatabase(client, { databasePath: join(root, 'open-science.db') })

      // Every existing row and operation is preserved, along with each old index.
      expect(await client.$queryRawUnsafe('SELECT * FROM "ComputeJob" ORDER BY id')).toEqual(
        jobsBefore
      )
      expect(await client.$queryRawUnsafe('SELECT * FROM "ComputeJobOperation"')).toEqual(
        operationsBefore
      )
      const indexesAfter = await client.$queryRawUnsafe(
        `SELECT name, sql FROM sqlite_master WHERE type = 'index' AND tbl_name = 'ComputeJob' ORDER BY name`
      )
      for (const oldIndex of indexesBefore) expect(indexesAfter).toContainEqual(oldIndex)

      // A pending harvest-error state (harvestError set, harvestedAt NULL) is
      // now representable...
      await expect(
        client.$executeRawUnsafe(
          `UPDATE "ComputeJob" SET "harvestError" = 'harvest pending: Local free-space check failed.' WHERE id = 'pending'`
        )
      ).resolves.toBe(1)
      // ...but the genuine invariant still holds: leftOnRemote set without a
      // harvestedAt remains rejected.
      await expect(
        client.$executeRawUnsafe(`UPDATE "ComputeJob" SET "leftOnRemote" = '[]' WHERE id = 'pending'`)
      ).rejects.toThrow(/CHECK constraint failed/)

      // Foreign keys are intact and the ledger is append-only and convergent.
      expect(await client.$queryRawUnsafe('PRAGMA foreign_key_check')).toEqual([])
      await expect(migrateApplicationDatabase(client)).resolves.toMatchObject({ applied: [] })
    } finally {
      await client.$disconnect()
      await rm(root, { recursive: true, force: true, maxRetries: 5, retryDelay: 200 })
    }
  })
})
