#!/usr/bin/env bash
# Environment bootstrap for the verifier.
#
# Sourced (not exec'd) by the harbor runner, so env vars set here stay live for
# the verifier subprocess. The image already ran `npm ci` at the base commit
# (which runs the repo's postinstall: `prisma generate`), so the dependency
# closure and the generated Prisma client are baked in. This script is
# offline-first: it only reaches the network if something is actually missing,
# and it logs loudly when it does.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/open-science}"
export REPO_DIR
cd "$REPO_DIR"

# vitest runs the TypeScript suite directly (no dist build step for src/main).
# Sanity-check that node_modules survived image build; a corrupted tree is
# better caught here than as a confusing "vitest: not found" later.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/." \
         "node_modules looks corrupted; reinstalling from the lockfile." >&2
    # Offline-first: the image warmed the npm cache at the base commit, so a
    # cache-only install should succeed without the network. Fall back to an
    # online install (logged) only if the cache is incomplete.
    npm ci --offline \
        || { echo "test-setup.sh: offline npm ci failed; retrying online (needs network)." >&2; npm ci; }
fi

# The compute tests exercise the SQLite/Prisma repository, so the generated
# Prisma client must match prisma/schema.prisma. `prisma generate` is offline
# (it reads the local schema and writes node_modules/.prisma); the image warmed
# it during postinstall. Re-run only if the client is absent or stale — the
# repo ships scripts/check-prisma-client.mjs for exactly this fingerprint test,
# and the agent's fix may introduce a schema migration that regenerates it.
if ! node scripts/check-prisma-client.mjs >/dev/null 2>&1; then
    echo "test-setup.sh: Prisma client missing or out of date; regenerating (offline)." >&2
    npx --no-install prisma generate \
        > /tmp/prisma-generate.log 2>&1 \
        || { echo "test-setup.sh: prisma generate failed:" >&2; tail -40 /tmp/prisma-generate.log >&2; exit 1; }
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR node=$(node --version) vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
