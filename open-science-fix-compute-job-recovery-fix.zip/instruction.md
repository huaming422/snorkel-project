## Task

Remote compute jobs have become unreliable since the latest release. Users see
the problems with both Direct SSH hosts and Slurm clusters:

- A staged input can have the same name as a file the runner uses to track the
  job, such as its exit status or log file. The input overwrites that file, and
  the job then reports an incorrect exit status or never harvests its outputs.
- A cancellation requested while a job is being dispatched may never complete.
  After the app restarts, recovery can also miss a Direct SSH job that did launch
  remotely, leaving it to be retried or abandoned rather than reconciled.
- Session and provider concurrency limits allow another job through while a
  cancellation is pending, even though the cancelling job still occupies a slot.
- A completed job can have its outputs downloaded and remote workdir cleaned up
  twice. If that workdir is already absent, the job can instead remain stuck
  with an unharvested error rather than reach its final state.
- A temporary failure to list remote outputs or check available local disk space
  leaves a recoverable harvest permanently failed instead of allowing a retry.

These failures can be reproduced inside the job lifecycle, repository,
dispatcher, cancellation, and harvest components. A live SSH host or Slurm
cluster is unnecessary. Investigate the interacting regressions and restore
correct input staging, cancellation and restart recovery, admission limits, and
harvest behavior for both new and existing jobs.
