//! AUTOINCREMENT ids across a switch of an existing database to MVCC.
//!
//! Every scenario goes through turso_core's public Rust API only: open a
//! database file, run SQL on a `Connection`, switch the journal mode with
//! `PRAGMA journal_mode = 'mvcc'`, close and reopen the file, and read the
//! rows back. The expected ids follow SQLite's AUTOINCREMENT contract: the
//! next id comes after the largest id the table ever handed out (its
//! `sqlite_sequence` entry), deleted ids are never handed out again, and a
//! table that never got a row starts at 1.
//!
//! The file is copied into `core/tests/` and built as the `verify_test`
//! integration test of the `turso_core` package, so turso_core is compiled
//! with its default features only, the way a plain dependency on it builds.
//! It uses nothing but turso_core's public surface plus `tempfile`.

use std::path::{Path, PathBuf};
use std::sync::mpsc::{self, RecvTimeoutError};
use std::sync::Arc;
use std::thread;
use std::time::Duration;

use tempfile::TempDir;
use turso_core::{
    ConnectOpts, Connection, Database, DatabaseOpts, OpenFlags, PlatformIO, SqliteDialect,
};

/// How long one check may take. Each finishes in well under a second, so a
/// check that runs this long is stuck (an open or a statement that never
/// returns) and fails on its own instead of stalling every check after it.
const CHECK_LIMIT: Duration = Duration::from_secs(45);

/// Run one check on its own thread and fail it if it has not finished within
/// `CHECK_LIMIT`. A failed assertion inside the check fails it as usual.
fn bounded(check: impl FnOnce() + Send + 'static) {
    let (done_tx, done_rx) = mpsc::channel();
    let handle = thread::spawn(move || {
        check();
        let _ = done_tx.send(());
    });
    match done_rx.recv_timeout(CHECK_LIMIT) {
        Ok(()) | Err(RecvTimeoutError::Disconnected) => {
            if let Err(panic) = handle.join() {
                std::panic::resume_unwind(panic);
            }
        }
        Err(RecvTimeoutError::Timeout) => panic!(
            "the check did not finish within {} s; an open or a statement never returned",
            CHECK_LIMIT.as_secs()
        ),
    }
}

/// Open the database file read-write.
fn open_rw(path: &Path) -> Arc<Database> {
    let io = Arc::new(PlatformIO::new().unwrap());
    Database::open_file_with_flags(
        io,
        path.to_str().unwrap(),
        OpenFlags::default(),
        DatabaseOpts::new(),
        None,
        Arc::new(SqliteDialect),
    )
    .expect("open database read-write")
}

/// Open the database file read-only.
fn open_ro(path: &Path) -> Arc<Database> {
    let io = Arc::new(PlatformIO::new().unwrap());
    Database::open_file_with_flags(
        io,
        path.to_str().unwrap(),
        OpenFlags::ReadOnly,
        DatabaseOpts::new(),
        None,
        Arc::new(SqliteDialect),
    )
    .expect("open database read-only")
}

fn connect(db: &Arc<Database>) -> Arc<Connection> {
    db.connect(ConnectOpts::new()).unwrap()
}

fn exec(conn: &Arc<Connection>, sql: &str) {
    conn.execute(sql)
        .unwrap_or_else(|e| panic!("`{sql}` failed: {e}"));
}

fn switch_to_mvcc(conn: &Arc<Connection>) {
    conn.pragma_update("journal_mode", "'mvcc'")
        .expect("switch the existing database to mvcc");
}

/// Read `(id, text)` for every row of `table`, ordered by id.
fn rows(conn: &Arc<Connection>, table: &str) -> Vec<(i64, String)> {
    let mut stmt = conn
        .prepare(format!("SELECT * FROM {table} ORDER BY 1"))
        .unwrap();
    let mut out = Vec::new();
    stmt.run_with_row_callback(|row| {
        out.push((row.get::<i64>(0)?, row.get::<String>(1)?));
        Ok(())
    })
    .unwrap();
    out
}

fn row(id: i64, text: &str) -> (i64, String) {
    (id, text.to_string())
}

fn db_file(tmp: &TempDir) -> PathBuf {
    tmp.path().join("test.db")
}

/// Size in bytes of the MVCC log next to the database file (`<file>-log`),
/// 0 when there is none.
fn log_len(db_path: &Path) -> u64 {
    let mut log = db_path.as_os_str().to_owned();
    log.push("-log");
    std::fs::metadata(PathBuf::from(log))
        .map(|m| m.len())
        .unwrap_or(0)
}

/// Create `posts` in plain WAL mode, run `setup` in that session, then close
/// it so the rows are on disk before the switch.
fn seed_wal_db(tmp: &TempDir, setup: &[&str]) -> PathBuf {
    let db_path = db_file(tmp);
    let db = open_rw(&db_path);
    let conn = connect(&db);
    exec(
        &conn,
        "CREATE TABLE posts (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT)",
    );
    for sql in setup {
        exec(&conn, sql);
    }
    db_path
}

/// Right after the switch, an insert from another connection continues past
/// the existing ids and leaves the existing rows alone.
#[test]
fn autoincrement_ids_continue_after_switch_to_mvcc() {
    bounded(|| {
        let tmp = TempDir::new().unwrap();
        let db_path = seed_wal_db(&tmp, &["INSERT INTO posts (title) VALUES ('a'), ('b')"]);

        let db = open_rw(&db_path);
        let conn = connect(&db);
        switch_to_mvcc(&conn);
        let writer = connect(&db);
        exec(&writer, "INSERT INTO posts (title) VALUES ('c')");

        assert_eq!(
            rows(&writer, "posts"),
            vec![row(1, "a"), row(2, "b"), row(3, "c")],
            "after switching to MVCC, the insert must get id 3 and keep rows 1 and 2"
        );
    });
}

/// The connection that ran the switch inserts next. The row it gets and the
/// rows that were there must still be there after the database is reopened,
/// and the insert after the reopen continues the count.
#[test]
fn insert_on_the_switching_connection_continues_and_survives_reopen() {
    bounded(|| {
        let tmp = TempDir::new().unwrap();
        let db_path = seed_wal_db(&tmp, &["INSERT INTO posts (title) VALUES ('a'), ('b')"]);

        {
            let db = open_rw(&db_path);
            let conn = connect(&db);
            switch_to_mvcc(&conn);
            exec(&conn, "INSERT INTO posts (title) VALUES ('c')");
            assert_eq!(
                rows(&conn, "posts"),
                vec![row(1, "a"), row(2, "b"), row(3, "c")],
                "the connection that switched must get id 3 and keep rows 1 and 2"
            );
        }

        let db = open_rw(&db_path);
        let conn = connect(&db);
        assert_eq!(
            rows(&conn, "posts"),
            vec![row(1, "a"), row(2, "b"), row(3, "c")],
            "the row inserted right after the switch must still be there after a reopen"
        );
        exec(&conn, "INSERT INTO posts (title) VALUES ('d')");
        assert_eq!(
            rows(&conn, "posts"),
            vec![row(1, "a"), row(2, "b"), row(3, "c"), row(4, "d")],
            "after the reopen the next insert must get id 4"
        );
    });
}

/// After the switch and one insert: two reopens with no writes keep the rows
/// and add nothing to the MVCC log, a read-only open works, and the next insert
/// still continues the count.
#[test]
fn ids_keep_counting_after_reopens_and_a_read_only_open() {
    bounded(|| {
        let tmp = TempDir::new().unwrap();
        let db_path = seed_wal_db(&tmp, &["INSERT INTO posts (title) VALUES ('a'), ('b')"]);

        {
            let db = open_rw(&db_path);
            let conn = connect(&db);
            switch_to_mvcc(&conn);
            let writer = connect(&db);
            exec(&writer, "INSERT INTO posts (title) VALUES ('c')");
            assert_eq!(
                rows(&writer, "posts"),
                vec![row(1, "a"), row(2, "b"), row(3, "c")]
            );
        }
        let log_before_reopens = log_len(&db_path);

        for _ in 0..2 {
            let db = open_rw(&db_path);
            let conn = connect(&db);
            assert_eq!(
                rows(&conn, "posts"),
                vec![row(1, "a"), row(2, "b"), row(3, "c")],
                "reopening without writes must keep the rows"
            );
        }
        assert!(
            log_len(&db_path) <= log_before_reopens,
            "reopening without writes must not add anything to the MVCC log"
        );

        {
            let db = open_ro(&db_path);
            let conn = connect(&db);
            assert_eq!(
                rows(&conn, "posts"),
                vec![row(1, "a"), row(2, "b"), row(3, "c")],
                "a read-only open must succeed and show the same rows"
            );
        }

        let db = open_rw(&db_path);
        let conn = connect(&db);
        exec(&conn, "INSERT INTO posts (title) VALUES ('d')");
        assert_eq!(
            rows(&conn, "posts"),
            vec![row(1, "a"), row(2, "b"), row(3, "c"), row(4, "d")],
            "after the reopens the next insert must get id 4"
        );
    });
}

/// The connection that ran the switch stays open and does nothing else. It
/// must not keep a transaction open: a TRUNCATE checkpoint from another
/// connection goes through instead of reporting the database as busy.
#[test]
fn the_switching_connection_is_left_idle_so_a_checkpoint_goes_through() {
    bounded(|| {
        let tmp = TempDir::new().unwrap();
        let db_path = seed_wal_db(&tmp, &["INSERT INTO posts (title) VALUES ('a'), ('b')"]);

        let db = open_rw(&db_path);
        let switching = connect(&db);
        switch_to_mvcc(&switching);
        let other = connect(&db);
        exec(&other, "INSERT INTO posts (title) VALUES ('c')");

        let mut stmt = other.prepare("PRAGMA wal_checkpoint(TRUNCATE)").unwrap();
        let mut busy = Vec::new();
        stmt.run_with_row_callback(|row| {
            busy.push(row.get::<i64>(0)?);
            Ok(())
        })
        .unwrap_or_else(|e| {
            panic!("a checkpoint after the switch must not fail while the switching connection is idle: {e}")
        });
        assert_eq!(busy, vec![0], "the checkpoint must not report the database as busy");
        assert_eq!(
            rows(&other, "posts"),
            vec![row(1, "a"), row(2, "b"), row(3, "c")],
            "the rows must be intact after the checkpoint"
        );
        drop(switching);
    });
}

/// The session that switches writes nothing. Reopens (which add nothing to the
/// MVCC log), a read-only open and the first insert in a later session still
/// see the count carried over.
#[test]
fn switch_without_writes_then_reopen_read_only_and_insert_later() {
    bounded(|| {
        let tmp = TempDir::new().unwrap();
        let db_path = seed_wal_db(&tmp, &["INSERT INTO posts (title) VALUES ('a'), ('b')"]);

        {
            let db = open_rw(&db_path);
            let conn = connect(&db);
            switch_to_mvcc(&conn);
        }
        let log_before_reopens = log_len(&db_path);

        for _ in 0..2 {
            let db = open_rw(&db_path);
            let conn = connect(&db);
            assert_eq!(
                rows(&conn, "posts"),
                vec![row(1, "a"), row(2, "b")],
                "reopening without writes must keep the rows"
            );
        }
        assert!(
            log_len(&db_path) <= log_before_reopens,
            "reopening without writes must not add anything to the MVCC log"
        );

        {
            let db = open_ro(&db_path);
            let conn = connect(&db);
            assert_eq!(
                rows(&conn, "posts"),
                vec![row(1, "a"), row(2, "b")],
                "a read-only open must succeed and show the same rows"
            );
        }

        let db = open_rw(&db_path);
        let conn = connect(&db);
        exec(&conn, "INSERT INTO posts (title) VALUES ('c')");
        assert_eq!(
            rows(&conn, "posts"),
            vec![row(1, "a"), row(2, "b"), row(3, "c")],
            "the first insert after the switch, in a later session, must get id 3"
        );
    });
}

/// A table that held exactly one row (id 1) before the switch hands out 2 next.
#[test]
fn a_table_whose_only_row_is_id_1_continues_at_2() {
    bounded(|| {
        let tmp = TempDir::new().unwrap();
        let db_path = seed_wal_db(&tmp, &["INSERT INTO posts (title) VALUES ('a')"]);

        let db = open_rw(&db_path);
        let conn = connect(&db);
        switch_to_mvcc(&conn);
        let writer = connect(&db);
        exec(&writer, "INSERT INTO posts (title) VALUES ('b')");
        assert_eq!(
            rows(&writer, "posts"),
            vec![row(1, "a"), row(2, "b")],
            "the insert after the switch must get id 2 and keep row 1"
        );
    });
}

/// Ids 4 and 5 were handed out and then deleted before the switch. They are
/// never handed out again: the next inserts get 6, then 7 after a reopen.
#[test]
fn ids_of_rows_deleted_before_the_switch_are_not_reused() {
    bounded(|| {
        let tmp = TempDir::new().unwrap();
        let db_path = seed_wal_db(
            &tmp,
            &[
                "INSERT INTO posts (title) VALUES ('a'), ('b'), ('c'), ('d'), ('e')",
                "DELETE FROM posts WHERE id >= 4",
            ],
        );

        {
            let db = open_rw(&db_path);
            let conn = connect(&db);
            switch_to_mvcc(&conn);
            let writer = connect(&db);
            exec(&writer, "INSERT INTO posts (title) VALUES ('f')");
            assert_eq!(
                rows(&writer, "posts"),
                vec![row(1, "a"), row(2, "b"), row(3, "c"), row(6, "f")],
                "ids 4 and 5 were already used, so the insert after the switch must get id 6"
            );
        }

        let db = open_rw(&db_path);
        let conn = connect(&db);
        exec(&conn, "INSERT INTO posts (title) VALUES ('g')");
        assert_eq!(
            rows(&conn, "posts"),
            vec![row(1, "a"), row(2, "b"), row(3, "c"), row(6, "f"), row(7, "g")],
            "after a reopen the next insert must get id 7"
        );
    });
}

/// Several tables switch together. Each AUTOINCREMENT table keeps its own
/// count (including one whose name needs quoting), an AUTOINCREMENT table that
/// never had a row starts at 1, and a plain INTEGER PRIMARY KEY table still
/// continues after its largest id. The same holds in a later session.
#[test]
fn every_table_keeps_its_own_count_across_the_switch() {
    bounded(|| {
        let tmp = TempDir::new().unwrap();
        let db_path = seed_wal_db(
            &tmp,
            &[
                "CREATE TABLE \"Blog Tags\" (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT)",
                "CREATE TABLE drafts (id INTEGER PRIMARY KEY AUTOINCREMENT, body TEXT)",
                "CREATE TABLE notes (id INTEGER PRIMARY KEY, body TEXT)",
                "INSERT INTO posts (title) VALUES ('a'), ('b')",
                "INSERT INTO \"Blog Tags\" (name) VALUES ('t1'), ('t2'), ('t3'), ('t4'), ('t5')",
                "INSERT INTO notes (body) VALUES ('n1'), ('n2'), ('n3')",
            ],
        );
        let tags = "\"Blog Tags\"";

        {
            let db = open_rw(&db_path);
            let conn = connect(&db);
            switch_to_mvcc(&conn);
            let writer = connect(&db);
            exec(&writer, "INSERT INTO posts (title) VALUES ('c')");
            exec(&writer, "INSERT INTO \"Blog Tags\" (name) VALUES ('t6')");
            exec(&writer, "INSERT INTO drafts (body) VALUES ('d1')");
            exec(&writer, "INSERT INTO notes (body) VALUES ('n4')");
            assert_eq!(
                rows(&writer, "posts"),
                vec![row(1, "a"), row(2, "b"), row(3, "c")],
                "posts must continue at 3"
            );
            assert_eq!(
                rows(&writer, tags),
                vec![
                    row(1, "t1"),
                    row(2, "t2"),
                    row(3, "t3"),
                    row(4, "t4"),
                    row(5, "t5"),
                    row(6, "t6"),
                ],
                "the tags table must continue at 6, from its own count"
            );
            assert_eq!(
                rows(&writer, "drafts"),
                vec![row(1, "d1")],
                "an AUTOINCREMENT table that never had a row must start at 1"
            );
            assert_eq!(
                rows(&writer, "notes"),
                vec![row(1, "n1"), row(2, "n2"), row(3, "n3"), row(4, "n4")],
                "a plain INTEGER PRIMARY KEY table must continue after its largest id"
            );
        }

        let db = open_rw(&db_path);
        let conn = connect(&db);
        exec(&conn, "INSERT INTO posts (title) VALUES ('d')");
        exec(&conn, "INSERT INTO \"Blog Tags\" (name) VALUES ('t7')");
        exec(&conn, "INSERT INTO drafts (body) VALUES ('d2')");
        assert_eq!(
            rows(&conn, "posts"),
            vec![row(1, "a"), row(2, "b"), row(3, "c"), row(4, "d")],
            "after a reopen posts must continue at 4"
        );
        assert_eq!(
            rows(&conn, tags),
            vec![
                row(1, "t1"),
                row(2, "t2"),
                row(3, "t3"),
                row(4, "t4"),
                row(5, "t5"),
                row(6, "t6"),
                row(7, "t7"),
            ],
            "after a reopen the tags table must continue at 7"
        );
        assert_eq!(
            rows(&conn, "drafts"),
            vec![row(1, "d1"), row(2, "d2")],
            "after a reopen drafts must continue at 2"
        );
    });
}

/// Set the header's read and write versions to 255 (MVCC), the state a
/// switch leaves when it did not carry the AUTOINCREMENT counters across.
fn mark_header_as_mvcc(db_path: &Path) {
    let mut bytes = std::fs::read(db_path).unwrap();
    bytes[18] = 255;
    bytes[19] = 255;
    std::fs::write(db_path, bytes).unwrap();
}

/// A database whose header already says MVCC, but whose counters never made
/// it across, gets them on open: a later session's insert continues the count.
#[test]
fn database_already_marked_mvcc_gets_its_counters_on_open() {
    bounded(|| {
        let tmp = TempDir::new().unwrap();
        let db_path = seed_wal_db(
            &tmp,
            &[
                "INSERT INTO posts (title) VALUES ('a'), ('b')",
                "PRAGMA wal_checkpoint(TRUNCATE)",
            ],
        );
        mark_header_as_mvcc(&db_path);

        {
            let db = open_rw(&db_path);
            let conn = connect(&db);
            assert_eq!(rows(&conn, "posts"), vec![row(1, "a"), row(2, "b")]);
        }

        let db = open_rw(&db_path);
        let conn = connect(&db);
        exec(&conn, "INSERT INTO posts (title) VALUES ('c')");
        assert_eq!(
            rows(&conn, "posts"),
            vec![row(1, "a"), row(2, "b"), row(3, "c")],
            "the insert must get id 3 and keep rows 1 and 2"
        );
    });
}

/// A database that never switches keeps allocating AUTOINCREMENT ids normally.
#[test]
fn autoincrement_ids_monotonic_without_mvcc_switch() {
    bounded(|| {
        let tmp = TempDir::new().unwrap();
        let db_path = seed_wal_db(
            &tmp,
            &["INSERT INTO posts (title) VALUES ('a'), ('b'), ('c'), ('d'), ('e')"],
        );
        let db = open_rw(&db_path);
        let conn = connect(&db);
        exec(&conn, "INSERT INTO posts (title) VALUES ('f')");
        assert_eq!(
            rows(&conn, "posts"),
            vec![
                row(1, "a"),
                row(2, "b"),
                row(3, "c"),
                row(4, "d"),
                row(5, "e"),
                row(6, "f"),
            ],
            "plain WAL autoincrement must allocate ids 1..6 in order"
        );
    });
}

/// A database that is in MVCC mode before its tables exist keeps counting
/// across a reopen.
#[test]
fn database_in_mvcc_mode_from_the_start_keeps_counting_after_reopen() {
    bounded(|| {
        let tmp = TempDir::new().unwrap();
        let db_path = db_file(&tmp);
        {
            let db = open_rw(&db_path);
            let conn = connect(&db);
            switch_to_mvcc(&conn);
            exec(
                &conn,
                "CREATE TABLE posts (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT)",
            );
            exec(&conn, "INSERT INTO posts (title) VALUES ('a'), ('b')");
        }

        let db = open_rw(&db_path);
        let conn = connect(&db);
        exec(&conn, "INSERT INTO posts (title) VALUES ('c')");
        assert_eq!(
            rows(&conn, "posts"),
            vec![row(1, "a"), row(2, "b"), row(3, "c")],
            "the insert after the reopen must get id 3"
        );
    });
}
