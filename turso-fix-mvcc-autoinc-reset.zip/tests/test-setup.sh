#!/usr/bin/env bash
# Sourced by tests/test.sh before the Rust checks run (set -euo pipefail inherited).
# Must run with the network cut: the image baked the full dependency closure at
# the base commit (cargo registry + git deps warm under CARGO_HOME, target dir
# rebuilt at the base in block 7). We only need to make cargo prefer that cache.
cd /repo/turso

# Force offline right away so a cache miss fails fast instead of hitting crates.io.
export CARGO_NET_OFFLINE=true

# Dependencies: offline-first against the image bake, logged online fallback.
if cargo fetch --locked --offline > /tmp/test-setup-fetch.log 2>&1; then
    echo "[offline-first] cargo deps satisfied from image cache"
elif cargo fetch --locked >> /tmp/test-setup-fetch.log 2>&1; then
    echo "[test-setup] cargo deps fetched online (image bake was stale)"
else
    tail -40 /tmp/test-setup-fetch.log >&2; exit 1
fi

# No services to start and no data to seed: the Rust checks drive everything
# through the turso_core library API. No assertion logic here.
