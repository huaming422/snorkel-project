package chunker

// Behavioral verifier for the Go TokenChunker hard-cap expansion path.
//
// Drives mergeUnits (the pre-existing, stable in-package entry point) on an
// oversized text unit carrying a known PDF position payload and populated item
// metadata, and asserts that EVERY expanded piece inherits the source unit's
// positions AND its item metadata — not only the head piece. This path counts
// tokens through the real tokenizer (tokenizeStr -> tokenizer.NumTokensFromString),
// so the image bakes the BPE table; the fixtures mirror that real sizing.
//
// Self-contained: builds its own schema.ChunkDoc fixtures and reads only
// exported/observable chunk state. Test names use a unique prefix so they do
// not collide with the package's existing Test functions.

import (
	"strings"
	"testing"

	"ragflow/internal/ingestion/component/schema"
)

// TestVerifyTokenHardcap_EveryPieceKeepsPositions asserts that when an oversized
// text unit is expanded into several pieces, every piece carries the source
// unit's PDF position payload (a Plan-A implementation that keeps positions on
// the head piece only fails here).
func TestVerifyTokenHardcap_EveryPieceKeepsPositions(t *testing.T) {
	const target = 30
	body := strings.Repeat("word ", 100)
	pos := []byte(`[{"page":1}]`)

	got := mergeUnits([]schema.ChunkDoc{
		{Text: body, CKType: "text", TKNums: intPtr(tokenizeStr(body)), PDFPositions: pos},
	}, target, 0, "")

	if len(got) < 2 {
		t.Fatalf("want >=2 pieces from the oversized unit, got %d", len(got))
	}
	for i := range got {
		if string(got[i].PDFPositions) != string(pos) {
			t.Errorf("piece %d PDFPositions = %q, want the source payload %q", i, got[i].PDFPositions, pos)
		}
	}
}

// TestVerifyTokenHardcap_EveryPieceCarriesMetadata asserts that every expanded
// piece inherits the full source item metadata (page number, img id, layout,
// image, tags, chunk order) built from a clone of the source unit — not only
// the head piece.
func TestVerifyTokenHardcap_EveryPieceCarriesMetadata(t *testing.T) {
	const target = 30
	body := strings.Repeat("word ", 100)
	unit := schema.ChunkDoc{
		Text:          body,
		DocType:       "text",
		CKType:        "text",
		TKNums:        intPtr(tokenizeStr(body)),
		PDFPositions:  []byte(`[{"page":1}]`),
		Mom:           "parent-id",
		ImgID:         "img-1",
		Layout:        "text",
		Image:         "raw-image",
		PageNumber:    intPtr(3),
		TagKwd:        []string{"t1"},
		ChunkOrderInt: intPtr(7),
	}

	got := mergeUnits([]schema.ChunkDoc{unit}, target, 0, "\n")
	if len(got) < 2 {
		t.Fatalf("oversized unit must be split, got %d piece(s)", len(got))
	}
	for i, ck := range got {
		if ck.Mom != "parent-id" || ck.ImgID != "img-1" || ck.Layout != "text" || ck.Image != "raw-image" {
			t.Errorf("piece %d lost item metadata: Mom=%q ImgID=%q Layout=%q Image=%q", i, ck.Mom, ck.ImgID, ck.Layout, ck.Image)
		}
		if ck.PageNumber == nil || *ck.PageNumber != 3 {
			t.Errorf("piece %d lost PageNumber: %#v", i, ck.PageNumber)
		}
		if len(ck.TagKwd) != 1 || ck.TagKwd[0] != "t1" {
			t.Errorf("piece %d lost TagKwd: %#v", i, ck.TagKwd)
		}
		if ck.ChunkOrderInt == nil || *ck.ChunkOrderInt != 7 {
			t.Errorf("piece %d lost ChunkOrderInt: %#v", i, ck.ChunkOrderInt)
		}
		if len(ck.PDFPositions) == 0 {
			t.Errorf("piece %d must carry the source positions", i)
		}
	}
}

// TestVerifyTokenHardcap_SplitInvariantsPreserved guards that the position
// carry-forward does not disturb the split itself on the token path. It holds
// on BOTH the unfixed and fixed code.
//   - lossless: the concatenated piece text reproduces the source exactly;
//   - ceiling: every text piece is within the token target;
//   - atomic: a non-text (table) unit is never split.
func TestVerifyTokenHardcap_SplitInvariantsPreserved(t *testing.T) {
	const target = 30
	body := strings.Repeat("word ", 100)

	got := mergeUnits([]schema.ChunkDoc{
		{Text: body, CKType: "text", TKNums: intPtr(tokenizeStr(body))},
	}, target, 0, "")
	if len(got) < 2 {
		t.Fatalf("want >=2 pieces, got %d", len(got))
	}
	// Lossless: concatenating the pieces reproduces the source text.
	var joined strings.Builder
	for _, ck := range got {
		joined.WriteString(ck.Text)
	}
	if joined.String() != body {
		t.Errorf("lossless check failed:\n got=%q\nwant=%q", joined.String(), body)
	}
	// Ceiling: every text piece is within the token target.
	for i, ck := range got {
		if n := tokenizeStr(ck.Text); n > target {
			t.Errorf("piece %d exceeds token target: tokens=%d (target=%d)", i, n, target)
		}
	}

	// Atomic: a non-text unit (e.g. a table) is never split.
	table := strings.Repeat("col ", 100)
	gotTable := mergeUnits([]schema.ChunkDoc{
		{Text: table, CKType: "table", TKNums: intPtr(tokenizeStr(table))},
	}, target, 0, "")
	if len(gotTable) != 1 {
		t.Fatalf("non-text unit must stay atomic, got %d pieces", len(gotTable))
	}
	if gotTable[0].Text != table {
		t.Errorf("atomic table text changed:\n got=%q\nwant=%q", gotTable[0].Text, table)
	}
}
