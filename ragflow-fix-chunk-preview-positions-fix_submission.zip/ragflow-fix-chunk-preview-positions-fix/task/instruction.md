## Task

we parse a lot of PDFs with the built-in book and paper chunk methods, and the
chunk list used to show a little page thumbnail on every chunk. lately most of
them come up blank. only the first chunk of a longer passage shows a preview
and the rest have none, and clicking those blank ones doesn't jump to or
highlight anything in the source document either. the chunk text itself is
right and complete, it's just the preview image and the page highlight that go
missing. short chunks seem fine; it's the longer passages that get broken into
several pieces where this shows up, and only the first piece keeps its preview.
this used to work on every chunk. can you dig into why the later pieces lose
their preview and highlight and fix it, without changing the chunk text?
