## Task

A cluster of reports about the first-run setup wizard breaking for new users.

Setup gets stuck on the "prepare environment" step even when the machine is ready. If the agent the wizard first reaches for has no runtime installed and the installer sources are unreachable, the step stays blocked, even though a different compatible coding agent is already installed and the system and storage checks pass.

On the "configure a model provider" step, start a provider test and go back before it finishes and the late result wrongly throws you forward onto the notebook runtime page instead of leaving you where you navigated. And once a provider has saved, going back and continuing again fires another create, so you get a duplicate instead of reusing the one already saved.

There's also a localization gap: when the chosen provider isn't compatible with the selected agent, the message telling the user to pick a compatible provider or switch agents stays in English even when the interface is in another language.

Keep the happy path intact: a successful test still advances, and setup completes only when the user finishes. This is all front-end flow and text; no new stored data or schema, and existing duplicates don't need cleanup.
