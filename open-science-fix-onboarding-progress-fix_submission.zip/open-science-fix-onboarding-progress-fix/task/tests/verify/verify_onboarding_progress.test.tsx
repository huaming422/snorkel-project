// @vitest-environment jsdom
// @ts-nocheck
//
// Drives the real first-run setup wizard through its rendered DOM and the
// pre-existing settings store actions. Every assertion reads observable
// surfaces only — which section is mounted, whether Continue is enabled, the
// arguments the store's save action received, whether the switch/install
// actions ran, and the alert text — never any internal helper, ref, or draft
// shape. The host inspection uses the real runEnvironmentCheck with injected
// probes, exactly as the shipped step tests do.
import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { fireEvent } from '@testing-library/react'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import { runEnvironmentCheck } from '../../../../main/settings/environment-check'
import type { AgentFrameworkId, EnvironmentCheckResult } from '../../../../shared/settings'
import { i18next } from '@/i18n'
import { useSettingsStore } from '@/stores/settings-store'
import { OnboardingWizard } from './OnboardingWizard'
import {
  clickButton,
  fillRequiredProviderFields,
  findButton,
  readyClaudeState,
  resetOnboardingStores,
  selectOption,
  stubWindowApi
} from './onboarding-test-utils'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true

let container: HTMLDivElement
let root: Root

beforeEach(() => {
  resetOnboardingStores()
  stubWindowApi()
  container = document.createElement('div')
  document.body.appendChild(container)
  root = createRoot(container)
})

afterEach(async () => {
  act(() => root.unmount())
  container.remove()
  document.body.innerHTML = ''
  delete (window as unknown as { api?: unknown }).api
  await i18next.changeLanguage('en')
})

const renderWizard = async (): Promise<void> => {
  await act(async () => root.render(<OnboardingWizard />))
}

const section = (label: string): Element | null =>
  container.querySelector(`section[aria-label="${label}"]`)

const goToProvider = async (): Promise<void> => {
  readyClaudeState()
  await renderWizard()
  await clickButton(/^continue$/i)
  await clickButton(/^continue$/i)
  await clickButton(/^continue$/i)
  expect(section('Configure model')).not.toBeNull()
  await fillRequiredProviderFields(container)
}

// Builds a host inspection where the targeted framework has no runtime and the
// installer sources are unreachable, so the only way forward is an installed
// alternative agent. Uses the real runEnvironmentCheck with injected host and
// network probes (no real host access) and wires setAgentFramework /
// checkEnvironment to re-run the real check against whatever framework is
// active — mirroring how the shipped store actions behave.
const configureUnavailableRegistries = async (
  failure?: 'storage' | 'system' | 'no-runtime',
  alternative: AgentFrameworkId = 'opencode',
  selected: AgentFrameworkId = 'claude-code'
): Promise<void> => {
  const frameworks = [
    { id: selected, label: selected, runtime: { found: false } },
    { id: alternative, label: alternative, runtime: { found: failure !== 'no-runtime' } }
  ]
  const probeRegistry = vi.fn().mockRejectedValue(new Error('Installation source unreachable'))
  const inspect = (agentFrameworkId: AgentFrameworkId): Promise<EnvironmentCheckResult> =>
    runEnvironmentCheck({
      storageRoot: '/fixture/data',
      agentFrameworkId,
      frameworks,
      encryptionAvailable: true,
      deps: {
        platform: 'darwin',
        architecture: 'arm64',
        verifyStorage: async () => {
          if (failure === 'storage') throw new Error('Permission denied')
        },
        resolveManagedPlatform: () => {
          if (failure === 'system') throw new Error('Unsupported system')
          return { key: 'darwin-arm64' }
        },
        findPython: async () => undefined,
        detectAvx2: () => true,
        probeRegistry,
        now: () => 1
      }
    })
  const environmentCheck = await inspect(selected)
  expect(probeRegistry).toHaveBeenCalledTimes(2)
  expect(environmentCheck).toMatchObject({ ready: false, canAutoInstall: false })
  expect(environmentCheck.checks.find((check) => check.id === 'install-network')?.status).toBe(
    'failed'
  )
  if (failure !== 'no-runtime') {
    expect(
      environmentCheck.checks.find((check) => check.label === `${alternative} runtime`)?.status
    ).toBe('passed')
  }
  useSettingsStore.setState({
    agentFrameworkId: selected,
    environmentCheck,
    agentFrameworks: frameworks.map(({ id, label }) => ({
      id,
      displayName: label,
      supportsSkills: true
    })),
    preflight: {
      claudeReady: alternative === 'claude-code' && failure !== 'no-runtime',
      opencodeReady: alternative === 'opencode' && failure !== 'no-runtime',
      codexReady: alternative === 'codex' && failure !== 'no-runtime',
      codebuddyReady: alternative === 'codebuddy' && failure !== 'no-runtime',
      agentFrameworkId: selected,
      agentReady: false,
      activeProviderReady: false
    },
    setAgentFramework: vi.fn(async (agentFrameworkId: AgentFrameworkId) => {
      useSettingsStore.setState({ agentFrameworkId })
    }),
    checkEnvironment: vi.fn(async () => {
      const result = await inspect(useSettingsStore.getState().agentFrameworkId)
      useSettingsStore.setState({ environmentCheck: result })
      return result
    })
  })
}

describe('Onboarding setup-progress behaviors', () => {
  // Switch-before-continue: with the targeted framework's
  // runtime missing and installers unreachable, the wizard switches to the
  // installed alternative, re-runs the check for it, and opens Continue.
  it.each(['claude-code', 'codex', 'codebuddy'] as const)(
    'checks the installed %s alternative before continuing',
    async (alternative) => {
      await configureUnavailableRegistries(
        undefined,
        alternative,
        alternative === 'claude-code' ? 'opencode' : 'claude-code'
      )
      await renderWizard()
      expect(useSettingsStore.getState().setAgentFramework).toHaveBeenCalledWith(alternative)
      expect(useSettingsStore.getState().environmentCheck).toMatchObject({
        ready: true,
        agentFrameworkId: alternative
      })
      expect(findButton(/^continue$/i)?.disabled).toBe(false)
    }
  )

  // An installed Codex adapter below the supported ACP version
  // is not an eligible alternative.
  it('does not select an unsupported Codex adapter as an installed alternative', async () => {
    await configureUnavailableRegistries(undefined, 'codex')
    useSettingsStore.setState({ codex: { version: '0.0.1' } })
    await renderWizard()
    expect(useSettingsStore.getState().setAgentFramework).not.toHaveBeenCalled()
    expect(findButton(/^continue$/i)?.disabled).toBe(true)
  })

  // Continue stays disabled until the re-check for the newly
  // selected framework resolves, and the one-time switch survives Back.
  it('waits for the selected alternative check and preserves the selection on Back', async () => {
    await configureUnavailableRegistries()
    const inspect = useSettingsStore.getState().checkEnvironment
    const pending = Promise.withResolvers<void>()
    useSettingsStore.setState({
      checkEnvironment: vi.fn(async () => {
        await pending.promise
        return inspect()
      })
    })
    await renderWizard()
    expect(useSettingsStore.getState().agentFrameworkId).toBe('opencode')
    expect(findButton(/^continue$/i)?.disabled).toBe(true)
    await act(async () => pending.resolve())
    expect(findButton(/^continue$/i)?.disabled).toBe(false)
    await clickButton(/^continue$/i)
    await clickButton(/^back$/i)
    expect(useSettingsStore.getState().setAgentFramework).toHaveBeenCalledOnce()
  })

  // No install action: the alternative is used as-is; no install
  // flow is triggered.
  it('allows setup with an installed alternative when installation sources are unreachable', async () => {
    await configureUnavailableRegistries()
    await renderWizard()

    expect(section('Prepare environment')).not.toBeNull()
    expect(findButton(/^continue$/i)?.disabled).toBe(false)
    await clickButton(/^continue$/i)
    expect(section('Choose data location')).not.toBeNull()
    await clickButton(/^continue$/i)
    expect(useSettingsStore.getState().setAgentFramework).toHaveBeenCalledWith('opencode')
    expect(useSettingsStore.getState().installOpencode).not.toHaveBeenCalled()
    expect(useSettingsStore.getState().installClaude).not.toHaveBeenCalled()
  })

  // The substitution only covers a missing agent runtime: a
  // failed host gate (storage/system) or no installed alternative keeps setup
  // blocked on the environment step.
  it.each(['storage', 'system', 'no-runtime'] as const)(
    'keeps setup blocked when the remaining requirement is %s',
    async (failure) => {
      await configureUnavailableRegistries(failure)
      await renderWizard()
      expect(findButton(/^continue$/i)?.disabled).toBe(true)
      await clickButton(/^continue$/i)
      expect(section('Prepare environment')).not.toBeNull()
    }
  )

  // A provider test resolving after two Backs must not navigate
  // forward; the user stays where they went and onboarding does not complete.
  it('preserves the current location step when a provider test succeeds after Back', async () => {
    const pending =
      Promise.withResolvers<
        Awaited<ReturnType<ReturnType<typeof useSettingsStore.getState>['saveAndActivateProvider']>>
      >()
    const save = vi.fn().mockReturnValue(pending.promise)
    useSettingsStore.setState({ saveAndActivateProvider: save })
    await goToProvider()
    await clickButton(/test & continue/i)
    expect(save).toHaveBeenCalledOnce()
    await clickButton(/^back$/i)
    await clickButton(/^back$/i)
    expect(section('Choose data location')).not.toBeNull()

    await act(async () => {
      pending.resolve({ providerId: 'saved-1', validation: { ok: true, category: 'ok' } })
    })

    expect.soft(section('Choose data location')).not.toBeNull()
    expect.soft(section('Notebook runtime (optional)')).toBeNull()
    expect(useSettingsStore.getState().completeOnboarding).not.toHaveBeenCalled()
  })

  // Re-submitting an already-saved provider updates it: the
  // second request carries the saved id (first had none).
  it('updates the saved provider identity after returning from Notebook', async () => {
    const save = vi.fn().mockResolvedValue({
      providerId: 'saved-1',
      validation: { ok: true, category: 'ok' }
    })
    useSettingsStore.setState({ saveAndActivateProvider: save })
    await goToProvider()
    await clickButton(/test & continue/i)
    expect(section('Notebook runtime (optional)')).not.toBeNull()
    expect(save.mock.calls[0][0].id).toBeUndefined()
    await clickButton(/^back$/i)
    await clickButton(/test & continue/i)

    expect(save).toHaveBeenCalledTimes(2)
    expect(save.mock.calls[1][0]).toMatchObject({ ...save.mock.calls[0][0], id: 'saved-1' })
    expect(section('Notebook runtime (optional)')).not.toBeNull()
  })

  // A provider page remounted after Back/Continue is not
  // navigated by its earlier test, and the next submit reuses the saved id and
  // requires the existing entity.
  it('keeps a remounted provider page open when its previous test completes', async () => {
    const pending = Promise.withResolvers<{
      providerId: string
      validation: { ok: true; category: 'ok' }
    }>()
    const save = vi
      .fn()
      .mockReturnValueOnce(pending.promise)
      .mockResolvedValue({
        providerId: 'saved-1',
        validation: { ok: true, category: 'ok' }
      })
    useSettingsStore.setState({ saveAndActivateProvider: save })
    await goToProvider()
    await clickButton(/test & continue/i)
    await clickButton(/^back$/i)
    await clickButton(/^continue$/i)
    await act(async () => {
      pending.resolve({ providerId: 'saved-1', validation: { ok: true, category: 'ok' } })
    })
    expect(section('Configure model')).not.toBeNull()
    await clickButton(/test & continue/i)
    expect(save.mock.calls[1][0]).toMatchObject({ id: 'saved-1', requireExisting: true })
    expect(section('Notebook runtime (optional)')).not.toBeNull()
  })

  // After a validation failure the committed identity is reused:
  // even with edited connection fields, the re-submit updates the same id.
  it('reuses the committed identity after failed validation and edited connection fields', async () => {
    const save = vi.fn().mockResolvedValue({
      providerId: 'saved-1',
      validation: { ok: false, category: 'network' }
    })
    useSettingsStore.setState({ saveAndActivateProvider: save })
    await goToProvider()
    await clickButton(/test & continue/i)
    expect(section('Configure model')).not.toBeNull()
    await act(async () => {
      fireEvent.change(container.querySelector('#provider-base-url')!, {
        target: { value: 'https://replacement.example' }
      })
    })
    await clickButton(/test & continue/i)
    expect(save.mock.calls[1][0]).toMatchObject({
      id: 'saved-1',
      requireExisting: true,
      baseUrl: 'https://replacement.example'
    })
  })

  // Changing the provider kind detaches the saved identity: the
  // next create carries no id.
  it('starts a new identity after changing provider kind and returning to custom', async () => {
    await goToProvider()
    await clickButton(/test & continue/i)
    await clickButton(/^back$/i)
    await selectOption('Provider type', 'Anthropic')
    expect(container.querySelector('[aria-label="Provider type"]')?.textContent).toContain(
      'Anthropic'
    )
    await selectOption('Provider type', 'Custom Gateway')
    await fillRequiredProviderFields(container)
    await clickButton(/test & continue/i)
    const save = vi.mocked(useSettingsStore.getState().saveAndActivateProvider)
    expect(save).toHaveBeenCalledTimes(2)
    expect(save.mock.calls[1][0].id).toBeUndefined()
  })

  // A late save response for an abandoned kind must not attach its
  // id to the new draft — the fresh create still carries no id.
  it('does not attach a late saved identity to a new provider draft', async () => {
    const pending = Promise.withResolvers<{
      providerId: string
      validation: { ok: true; category: 'ok' }
    }>()
    const save = vi
      .fn()
      .mockReturnValueOnce(pending.promise)
      .mockResolvedValue({
        providerId: 'saved-2',
        validation: { ok: true, category: 'ok' }
      })
    useSettingsStore.setState({ saveAndActivateProvider: save })
    await goToProvider()
    await clickButton(/test & continue/i)
    await clickButton(/^back$/i)
    await clickButton(/^continue$/i)
    await selectOption('Provider type', 'Anthropic')
    expect(container.querySelector('[aria-label="Provider type"]')?.textContent).toContain(
      'Anthropic'
    )
    await selectOption('Provider type', 'Custom Gateway')
    await fillRequiredProviderFields(container)
    await act(async () => {
      pending.resolve({ providerId: 'saved-1', validation: { ok: true, category: 'ok' } })
    })
    expect(section('Configure model')).not.toBeNull()
    await clickButton(/test & continue/i)
    expect(save.mock.calls[1][0].id).toBeUndefined()
  })

  // A confirmed "Provider no longer exists." clears the saved id;
  // the failing request required the existing entity, and only a later explicit
  // retry creates a new one.
  it('requires the saved entity to exist and starts a new one only on an explicit retry', async () => {
    const save = vi
      .fn()
      .mockResolvedValueOnce({ providerId: 'saved-1', validation: { ok: true, category: 'ok' } })
      .mockRejectedValueOnce(new Error('Provider no longer exists.'))
      .mockResolvedValueOnce({ providerId: 'saved-2', validation: { ok: true, category: 'ok' } })
    useSettingsStore.setState({ saveAndActivateProvider: save })
    await goToProvider()
    await clickButton(/test & continue/i)
    await clickButton(/^back$/i)
    await clickButton(/test & continue/i)
    expect(save.mock.calls[1][0]).toMatchObject({ id: 'saved-1', requireExisting: true })
    expect(section('Configure model')).not.toBeNull()
    expect(container.querySelector('[role="alert"]')?.textContent).toContain(
      'Provider no longer exists.'
    )
    await clickButton(/test & continue/i)
    expect(save.mock.calls[2][0].id).toBeUndefined()
  })

  // The incompatibility guidance is localized to the ACTIVE UI
  // language (framework name interpolated) and never left in English. Checked
  // across two shipped locales from different script families, because the
  // guidance must be localized for every shipped locale, not just one — an
  // untranslated locale falls back to the English string and must be rejected.
  // Per the contract, the assertion is "names the framework and is non-English"
  // rather than any specific translation literal, so any localization key that
  // interpolates the framework is accepted.
  it.each([
    { language: 'zh-Hans', testLabel: /测试并继续/ },
    { language: 'de', testLabel: /testen und fortfahren/i }
  ])('localizes the incompatible-provider guidance in $language', async ({ language, testLabel }) => {
    await goToProvider()
    await clickButton(/^back$/i)
    await act(async () => {
      const state = useSettingsStore.getState()
      useSettingsStore.setState({
        agentFrameworkId: 'codex',
        agentFrameworks: [
          {
            id: 'codex',
            displayName: 'Codex',
            supportedApiTypes: ['responses'],
            supportsSkills: true
          }
        ],
        preflight: {
          ...state.preflight,
          agentFrameworkId: 'codex',
          agentReady: true,
          codexReady: true
        },
        environmentCheck: { ...state.environmentCheck!, agentFrameworkId: 'codex' }
      })
    })
    await clickButton(/^continue$/i)
    expect(section('Configure model')).not.toBeNull()
    await act(async () => i18next.changeLanguage(language))
    await clickButton(testLabel)

    expect(useSettingsStore.getState().saveAndActivateProvider).not.toHaveBeenCalled()
    const alertText = container.querySelector('[role="alert"]')?.textContent ?? ''
    // The guidance interpolates the framework name...
    expect(alertText).toContain('Codex')
    // ...carries localized prose beyond just the interpolated name...
    expect(alertText.replace('Codex', '').trim().length).toBeGreaterThan(0)
    // ...and is NOT the English string (which is what the unfixed/partial
    // localization renders, directly or via the English fallback).
    expect(alertText).not.toContain("This provider isn't compatible")
  })

  // Happy path: a current successful test advances to the
  // notebook step and onboarding completes only on an explicit Finish.
  it('advances on a current successful test and finishes only on explicit Finish', async () => {
    await goToProvider()
    await clickButton(/test & continue/i)
    expect(section('Notebook runtime (optional)')).not.toBeNull()
    expect(useSettingsStore.getState().completeOnboarding).not.toHaveBeenCalled()
    await clickButton(/^finish$/i)
    expect(useSettingsStore.getState().completeOnboarding).toHaveBeenCalledOnce()
  })
})
