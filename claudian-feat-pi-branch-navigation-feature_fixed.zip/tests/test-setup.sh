#!/usr/bin/env bash
# test-setup.sh - environment bootstrap for the verifier / validation driver.
# Sourced (not exec'd) by the harbor runner so exported env vars and PATH stay
# alive for the Jest run that follows.
#
# This script is idempotent. The image already ran `npm ci` from this commit's
# lockfile with the npm cache warmed at the base commit (see image/Dockerfile
# blocks 5 and 7), so in the normal case this is a near no-op. We re-guard the
# install in case a user change deleted node_modules, and we run it
# offline-first with a logged online fallback (the image is built with network;
# the implementation step is no-network but the dependency closure is already
# baked, so the offline path always succeeds).

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/claudian}"
cd "$REPO_DIR"

node --version
npm --version

# Restore node_modules only if a user change removed it. Prefer the warm npm cache
# (offline); fall back to a normal networked install with a surfaced log.
if [ ! -d "node_modules" ] || [ ! -d "node_modules/.bin" ]; then
    echo "[test-setup] node_modules missing - restoring with npm ci (offline-first)..."
    if npm ci --offline --cache /opt/cache/npm > /tmp/npm-ci-offline.log 2>&1; then
        tail -3 /tmp/npm-ci-offline.log
    else
        echo "[test-setup] offline npm ci failed; retrying online:"
        tail -40 /tmp/npm-ci-offline.log || true
        npm ci --cache /opt/cache/npm > /tmp/npm-ci-online.log 2>&1 \
            || { tail -80 /tmp/npm-ci-online.log; exit 1; }
        tail -3 /tmp/npm-ci-online.log
    fi
fi

# Make the repo's local bin available to the runner.
export PATH="$REPO_DIR/node_modules/.bin:$PATH"

echo "[test-setup] ready: $REPO_DIR (node=$(node --version), npm=$(npm --version))"
