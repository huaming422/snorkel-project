// Tests for how the reverse dialer pairs each Dial with the connection the
// device dials back for it.
//
// Every case goes through the package's exported surface (NewDialer, Dial,
// Close, Done and ConnHandler) and through the JSON control protocol a device
// speaks on the control connection. No unexported name is used, so the per-dial
// state can live in any container and a late connection can be closed wherever
// the code chooses. Everything runs under -race.

package revdial_test

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"runtime"
	"runtime/debug"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/gorilla/websocket"
	"github.com/shellhub-io/shellhub/pkg/clock"
	"github.com/shellhub-io/shellhub/pkg/revdial"
	"github.com/shellhub-io/shellhub/pkg/uuid"
	"github.com/shellhub-io/shellhub/pkg/wsconnadapter"
	log "github.com/sirupsen/logrus"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

const (
	verifyConnPath    = "/ssh/revdial"
	verifyControlPath = "/control"
)

// verifyControlMessage has the wire shape of the control protocol the server
// and the device exchange (command, connPath, err).
type verifyControlMessage struct {
	Command  string `json:"command,omitempty"`
	ConnPath string `json:"connPath,omitempty"`
	Err      string `json:"err,omitempty"`
}

// verifyAgent plays the device: it reads conn-ready announcements off the
// control connection, dials websockets back into ConnHandler, and can report a
// failed pick-up.
type verifyAgent struct {
	t     *testing.T
	ctl   net.Conn
	wsURL string
	ready chan string
}

// verifyControl builds the control connection for a dialer. A real websocket
// has the timing of production, and a net.Pipe makes each write wait for the
// device to read it, which fixes the order of events.
type verifyControl func(t *testing.T, mux *http.ServeMux, wsURL string) (serverConn net.Conn, agentConn net.Conn)

func verifyWebsocketControl(t *testing.T, mux *http.ServeMux, wsURL string) (net.Conn, net.Conn) {
	t.Helper()

	accepted := make(chan net.Conn, 1)

	mux.HandleFunc(verifyControlPath, func(w http.ResponseWriter, r *http.Request) {
		conn, err := (&websocket.Upgrader{}).Upgrade(w, r, nil)
		if err != nil {
			t.Errorf("the control connection could not be upgraded: %v", err)

			return
		}

		accepted <- wsconnadapter.New(conn)
	})

	peer, _, err := websocket.DefaultDialer.DialContext(t.Context(), wsURL+verifyControlPath, nil) //nolint:bodyclose // gorilla/websocket documents that the handshake response body need not be closed.
	require.NoError(t, err)

	return <-accepted, wsconnadapter.New(peer)
}

func verifyPipeControl(*testing.T, *http.ServeMux, string) (net.Conn, net.Conn) {
	return net.Pipe()
}

func verifyQuietLogger() *log.Entry {
	logger := log.New()
	logger.SetOutput(io.Discard)

	return log.NewEntry(logger)
}

func verifyNewDialer(t *testing.T) (*revdial.Dialer, *verifyAgent) {
	t.Helper()

	return verifyNewDialerOver(t, verifyWebsocketControl)
}

func verifyNewDialerOver(t *testing.T, ctl verifyControl) (*revdial.Dialer, *verifyAgent) {
	t.Helper()

	return verifyNewDialerWith(t, ctl, verifyQuietLogger(), revdial.ConnHandler(websocket.Upgrader{}))
}

func verifyNewDialerWith(t *testing.T, ctl verifyControl, logger *log.Entry, connHandler http.Handler) (*revdial.Dialer, *verifyAgent) {
	t.Helper()

	mux := http.NewServeMux()
	mux.Handle(verifyConnPath, connHandler)

	srv := httptest.NewServer(mux)
	t.Cleanup(srv.Close)

	wsURL := "ws" + strings.TrimPrefix(srv.URL, "http")

	serverCtl, agentCtl := ctl(t, mux, wsURL)

	t.Cleanup(func() {
		_ = serverCtl.Close()
		_ = agentCtl.Close()
	})

	d := revdial.NewDialer(logger, serverCtl, verifyConnPath, clock.New())
	// Close runs on its own goroutine so that a Close that waits for someone to
	// read Done() can't hold up the rest of the test binary. These cases never
	// read Done().
	t.Cleanup(func() { go func() { _ = d.Close() }() })

	a := &verifyAgent{
		t:     t,
		ctl:   agentCtl,
		wsURL: wsURL,
		ready: make(chan string, 1024),
	}

	go a.readControl()

	return d, a
}

func (a *verifyAgent) readControl() {
	reader := bufio.NewReader(a.ctl)

	for {
		line, err := reader.ReadBytes('\n')
		if err != nil {
			return
		}

		var msg verifyControlMessage
		if err := json.Unmarshal(line, &msg); err != nil {
			return
		}

		if msg.Command == "conn-ready" {
			a.ready <- msg.ConnPath
		}
	}
}

func (a *verifyAgent) awaitConnReady() (string, bool) {
	select {
	case path := <-a.ready:
		return path, true
	case <-time.After(5 * time.Second):
		return "", assert.Fail(a.t, "the server never announced a connection to pick up")
	}
}

func (a *verifyAgent) dialBack(ctx context.Context, path string) (net.Conn, bool) {
	conn, _, err := websocket.DefaultDialer.DialContext(ctx, a.wsURL+path, nil) //nolint:bodyclose // gorilla/websocket documents that the handshake response body need not be closed.
	if err != nil {
		a.t.Errorf("the device could not dial back %s: %v", path, err)

		return nil, false
	}

	adapter := wsconnadapter.New(conn)
	a.t.Cleanup(func() { _ = adapter.Close() })

	return adapter, true
}

func (a *verifyAgent) failPickup(path string, reason string) bool {
	line, err := json.Marshal(verifyControlMessage{Command: "pickup-failed", ConnPath: path, Err: reason})
	if err == nil {
		_, err = a.ctl.Write(append(line, '\n'))
	}

	if err != nil {
		a.t.Errorf("the device could not report a failed pick-up: %v", err)

		return false
	}

	return true
}

func verifyDialWithin(t *testing.T, d *revdial.Dialer, timeout time.Duration) (net.Conn, error) {
	t.Helper()

	ctx, cancel := context.WithTimeout(t.Context(), timeout)
	defer cancel()

	return d.Dial(ctx)
}

// verifyHeldLog is a logrus hook. Once hold is called, every entry the dialer
// logs waits until release is closed or until three seconds after the hold
// began, whichever comes first. It stands in for a log sink that's slow to write
// on a box short of CPU.
type verifyHeldLog struct {
	until   atomic.Int64
	release chan struct{}
}

func (h *verifyHeldLog) hold() { h.until.Store(time.Now().Add(3 * time.Second).UnixNano()) }

func (h *verifyHeldLog) stop() { h.until.Store(0) }

func (h *verifyHeldLog) Levels() []log.Level { return log.AllLevels }

func (h *verifyHeldLog) Fire(*log.Entry) error {
	left := time.Until(time.Unix(0, h.until.Load()))
	if left <= 0 {
		return nil
	}

	select {
	case <-h.release:
	case <-time.After(left):
	}

	return nil
}

var (
	verifyCollectionMu    sync.Mutex
	verifyCollectionHolds int
	verifyCollectionPct   int
)

// verifyHoldCollection turns off automatic garbage collection until the test
// ends. A connection nobody references is closed by its finalizer at the next
// collection, which would make a dropped connection look closed during a read.
func verifyHoldCollection(t *testing.T) {
	t.Helper()

	verifyCollectionMu.Lock()
	if verifyCollectionHolds == 0 {
		verifyCollectionPct = debug.SetGCPercent(-1)
	}
	verifyCollectionHolds++
	verifyCollectionMu.Unlock()

	t.Cleanup(func() {
		verifyCollectionMu.Lock()
		verifyCollectionHolds--
		if verifyCollectionHolds == 0 {
			debug.SetGCPercent(verifyCollectionPct)
		}
		verifyCollectionMu.Unlock()
	})
}

// TestVerifyWaitingDialSurvivesAStaleFailure: one dial gives up, a second dial
// starts, and the device then reports that it couldn't pick up the first
// dial's connection before it dials back the second one. The second dial has to
// get its connection. The control connection is a net.Pipe, so the failure
// report is read before the dial-back arrives.
func TestVerifyWaitingDialSurvivesAStaleFailure(t *testing.T) {
	t.Parallel()

	d, a := verifyNewDialerOver(t, verifyPipeControl)

	gaveUp, cancel := context.WithCancel(t.Context())

	abandoned := make(chan error, 1)
	go func() {
		_, err := d.Dial(gaveUp)
		abandoned <- err
	}()

	stalePath, ok := a.awaitConnReady()
	require.True(t, ok)

	cancel()
	require.ErrorIs(t, <-abandoned, context.Canceled)

	agentDone := make(chan struct{})
	go func() {
		defer close(agentDone)

		path, ok := a.awaitConnReady()
		if !ok || !a.failPickup(stalePath, "stale") {
			return
		}

		a.dialBack(t.Context(), path)
	}()

	conn, err := verifyDialWithin(t, d, 5*time.Second)
	<-agentDone

	require.NoError(t, err, "a failure for a dial that gave up must not fail the one still waiting")
	require.NotNil(t, conn)
	_ = conn.Close()
}

// TestVerifyCloseReturnsWithNoDoneReceiver: a dialer that nothing watches is
// closed. Close has to return, and Done() has to read as closed by then or
// within a second after.
func TestVerifyCloseReturnsWithNoDoneReceiver(t *testing.T) {
	t.Parallel()

	serverCtl, agentCtl := net.Pipe()
	t.Cleanup(func() { _ = agentCtl.Close() })

	d := revdial.NewDialer(verifyQuietLogger(), serverCtl, verifyConnPath, clock.New())

	closed := make(chan struct{})
	go func() {
		_ = d.Close()
		close(closed)
	}()

	select {
	case <-closed:
	case <-time.After(5 * time.Second):
		require.FailNow(t, "Close must return even when nothing is receiving on Done")
	}

	deadline := time.After(time.Second)

	for {
		select {
		case _, open := <-d.Done():
			if !open {
				return
			}
		case <-deadline:
			require.FailNow(t, "Done must be closed once Close returned")
		}
	}
}

// TestVerifyDialReportsItsOwnPickupFailure: the device reports that it couldn't
// pick up the connection of the dial that's waiting. That dial returns the
// device's reason as its error.
func TestVerifyDialReportsItsOwnPickupFailure(t *testing.T) {
	t.Parallel()

	d, a := verifyNewDialer(t)

	go func() {
		if path, ok := a.awaitConnReady(); ok {
			a.failPickup(path, "the device could not reach the server")
		}
	}()

	conn, err := verifyDialWithin(t, d, 5*time.Second)

	require.ErrorContains(t, err, "the device could not reach the server")
	assert.Nil(t, conn)
}

// TestVerifyEachConcurrentDialGetsItsOwnConn: 16 dials run at once over a real
// websocket, and the device dials back each one and writes its path on it.
// Every dial gets a connection, and no two dials get the same one.
func TestVerifyEachConcurrentDialGetsItsOwnConn(t *testing.T) {
	t.Parallel()

	d, a := verifyNewDialer(t)

	const dials = 16

	go func() {
		for range dials {
			path, ok := a.awaitConnReady()
			if !ok {
				return
			}

			conn, ok := a.dialBack(t.Context(), path)
			if !ok {
				return
			}

			go func() {
				_, _ = conn.Write([]byte(path))
			}()
		}
	}()

	var wg sync.WaitGroup

	received := make(chan string, dials)
	failures := make(chan error, dials)

	for range dials {
		wg.Go(func() {
			conn, err := verifyDialWithin(t, d, 10*time.Second)
			if err != nil {
				failures <- err

				return
			}

			defer func() { _ = conn.Close() }()

			if err := conn.SetReadDeadline(time.Now().Add(10 * time.Second)); err != nil { //nolint:forbidigo // a deadline needs the wall clock
				failures <- err

				return
			}

			buf := make([]byte, 256)
			n, err := conn.Read(buf)
			if err != nil {
				failures <- err

				return
			}

			received <- string(buf[:n])
		})
	}

	wg.Wait()
	close(failures)
	close(received)

	for err := range failures {
		require.NoError(t, err, "every dial must get a connection or its own error")
	}

	paths := make(map[string]bool)
	for path := range received {
		assert.False(t, paths[path], "two dials received the same connection: %s", path)
		paths[path] = true
	}

	assert.Len(t, paths, dials, "every dial must end up holding a distinct connection")
}

// TestVerifyAbandonedDialBackIsClosed: a dial is cancelled, and the device then
// dials back the connection it was asked for. The server has to close that
// connection, so a read on the device's end fails with an error that isn't a
// timeout.
func TestVerifyAbandonedDialBackIsClosed(t *testing.T) {
	t.Parallel()
	verifyHoldCollection(t)

	d, a := verifyNewDialer(t)

	ctx, cancel := context.WithCancel(t.Context())

	dialed := make(chan error, 1)
	go func() {
		_, err := d.Dial(ctx)
		dialed <- err
	}()

	path, ok := a.awaitConnReady()
	require.True(t, ok)

	cancel()

	select {
	case err := <-dialed:
		require.ErrorIs(t, err, context.Canceled)
	case <-time.After(5 * time.Second):
		require.FailNow(t, "a cancelled dial must return")
	}

	late, ok := a.dialBack(t.Context(), path)
	require.True(t, ok)

	require.NoError(t, late.SetReadDeadline(time.Now().Add(5*time.Second))) //nolint:forbidigo // a deadline needs the wall clock

	_, err := late.Read(make([]byte, 1))

	require.Error(t, err)

	if netErr, ok := errors.AsType[net.Error](err); ok {
		assert.False(t, netErr.Timeout(), "a connection nobody claims must be closed, not left hanging")
	}
}

// TestVerifyDialBackLandingAsTheDialGivesUpIsClosed: the device's connection
// reaches the server while the dial is paused in a log call, and the dial is
// cancelled before it resumes. When the dial then gives up, the server has to
// close that connection. A dial that takes the connection instead is fine, so
// the case runs up to 12 times to see the dial give up at least once.
func TestVerifyDialBackLandingAsTheDialGivesUpIsClosed(t *testing.T) {
	t.Parallel()
	verifyHoldCollection(t)

	for range 12 {
		if verifyGiveUpWithADialBackWaiting(t) {
			return
		}
	}
}

func verifyGiveUpWithADialBackWaiting(t *testing.T) bool {
	t.Helper()

	held := &verifyHeldLog{release: make(chan struct{})}

	logger := log.New()
	logger.SetOutput(io.Discard)
	logger.SetLevel(log.TraceLevel)
	logger.AddHook(held)

	handled := make(chan struct{})

	var once sync.Once

	connHandler := revdial.ConnHandler(websocket.Upgrader{})
	watched := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer once.Do(func() { close(handled) })

		connHandler.ServeHTTP(w, r)
	})

	d, a := verifyNewDialerWith(t, verifyWebsocketControl, log.NewEntry(logger), watched)

	held.hold()
	defer held.stop()

	ctx, cancel := context.WithCancel(t.Context())
	defer cancel()

	type outcome struct {
		conn net.Conn
		err  error
	}

	dialed := make(chan outcome, 1)
	go func() {
		conn, err := d.Dial(ctx)
		dialed <- outcome{conn: conn, err: err}
	}()

	path, ok := a.awaitConnReady()
	require.True(t, ok)

	late, ok := a.dialBack(t.Context(), path)
	require.True(t, ok)

	select {
	case <-handled:
	case <-time.After(time.Second):
	}

	cancel()
	close(held.release)

	var r outcome
	select {
	case r = <-dialed:
	case <-time.After(5 * time.Second):
		require.FailNow(t, "a cancelled dial must return")
	}

	if r.err == nil {
		_ = r.conn.Close()

		return false
	}

	require.ErrorIs(t, r.err, context.Canceled)

	require.NoError(t, late.SetReadDeadline(time.Now().Add(5*time.Second))) //nolint:forbidigo // a deadline needs the wall clock

	_, err := late.Read(make([]byte, 1))

	require.Error(t, err)

	if netErr, ok := errors.AsType[net.Error](err); ok {
		assert.False(t, netErr.Timeout(), "a connection the dial gave up on must be closed, not left hanging")
	}

	return true
}

// TestVerifyQuickDialBackReachesABusyDial: the device dials back over a real
// websocket the moment it reads the announcement. Every log entry the dialer
// writes is held until the server has handled that dial-back, or for three
// seconds at most. The dial has to get the connection.
func TestVerifyQuickDialBackReachesABusyDial(t *testing.T) {
	t.Parallel()

	held := &verifyHeldLog{release: make(chan struct{})}

	logger := log.New()
	logger.SetOutput(io.Discard)
	logger.SetLevel(log.TraceLevel)
	logger.AddHook(held)

	var once sync.Once

	connHandler := revdial.ConnHandler(websocket.Upgrader{})
	handled := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer once.Do(func() { close(held.release) })

		connHandler.ServeHTTP(w, r)
	})

	d, a := verifyNewDialerWith(t, verifyWebsocketControl, log.NewEntry(logger), handled)

	held.hold()
	t.Cleanup(held.stop)

	agentDone := make(chan struct{})
	go func() {
		defer close(agentDone)

		if path, ok := a.awaitConnReady(); ok {
			a.dialBack(t.Context(), path)
		}
	}()

	conn, err := verifyDialWithin(t, d, 10*time.Second)
	held.stop()
	<-agentDone

	require.NoError(t, err, "a device that dials back right away must reach the dial that asked for it")
	require.NotNil(t, conn)
	_ = conn.Close()
}

// verifyMemPipe is one direction of an in-memory connection. Writes never
// block, and reads wait for data or for the pipe to close.
type verifyMemPipe struct {
	mu     sync.Mutex
	cond   *sync.Cond
	buf    bytes.Buffer
	closed bool
}

func newVerifyMemPipe() *verifyMemPipe {
	p := &verifyMemPipe{}
	p.cond = sync.NewCond(&p.mu)

	return p
}

func (p *verifyMemPipe) write(b []byte) (int, error) {
	p.mu.Lock()
	defer p.mu.Unlock()

	if p.closed {
		return 0, net.ErrClosed
	}

	p.buf.Write(b)
	p.cond.Broadcast()

	return len(b), nil
}

func (p *verifyMemPipe) read(b []byte) (int, error) {
	p.mu.Lock()
	defer p.mu.Unlock()

	for p.buf.Len() == 0 && !p.closed {
		p.cond.Wait()
	}

	if p.buf.Len() == 0 {
		return 0, io.EOF
	}

	return p.buf.Read(b)
}

func (p *verifyMemPipe) close() {
	p.mu.Lock()
	defer p.mu.Unlock()

	p.closed = true
	p.cond.Broadcast()
}

type verifyMemAddr struct{}

func (verifyMemAddr) Network() string { return "memory" }
func (verifyMemAddr) String() string  { return "memory" }

// verifyMemConn is one end of an in-memory connection. onWrite, when set, sees
// every write before it's stored.
type verifyMemConn struct {
	in, out *verifyMemPipe
	onWrite func([]byte)
}

func newVerifyMemConnPair() (*verifyMemConn, *verifyMemConn) {
	a, b := newVerifyMemPipe(), newVerifyMemPipe()

	return &verifyMemConn{in: a, out: b}, &verifyMemConn{in: b, out: a}
}

func (c *verifyMemConn) Read(b []byte) (int, error) { return c.in.read(b) }

func (c *verifyMemConn) Write(b []byte) (int, error) {
	if c.onWrite != nil {
		c.onWrite(b)
	}

	return c.out.write(b)
}

func (c *verifyMemConn) Close() error {
	c.in.close()
	c.out.close()

	return nil
}

func (c *verifyMemConn) LocalAddr() net.Addr              { return verifyMemAddr{} }
func (c *verifyMemConn) RemoteAddr() net.Addr             { return verifyMemAddr{} }
func (c *verifyMemConn) SetDeadline(time.Time) error      { return nil }
func (c *verifyMemConn) SetReadDeadline(time.Time) error  { return nil }
func (c *verifyMemConn) SetWriteDeadline(time.Time) error { return nil }

// verifyHijackWriter is an http.ResponseWriter whose connection can be taken
// over, so a websocket upgrade can run on an in-memory connection.
type verifyHijackWriter struct {
	header http.Header
	conn   net.Conn
}

func (w *verifyHijackWriter) Header() http.Header         { return w.header }
func (w *verifyHijackWriter) Write(b []byte) (int, error) { return len(b), nil }

func (w *verifyHijackWriter) WriteHeader(int) {}

func (w *verifyHijackWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	return w.conn, bufio.NewReadWriter(bufio.NewReader(w.conn), bufio.NewWriter(w.conn)), nil
}

// verifyAnswer plays a device that dials back the moment it reads conn-ready:
// it upgrades a websocket to connPath through ConnHandler on an in-memory
// connection, on the calling goroutine.
func verifyAnswer(connHandler http.Handler, connPath string) {
	req := httptest.NewRequest(http.MethodGet, "http://revdial.test"+connPath, nil)
	req.Header.Set("Connection", "Upgrade")
	req.Header.Set("Upgrade", "websocket")
	req.Header.Set("Sec-WebSocket-Version", "13")
	req.Header.Set("Sec-WebSocket-Key", "dGhlIHNhbXBsZSBub25jZQ==")

	server, _ := newVerifyMemConnPair()

	connHandler.ServeHTTP(&verifyHijackWriter{header: http.Header{}, conn: server}, req)
}

// verifyGateControl is a control connection that can hold the server's next
// write. While the gate is shut, a write waits until it opens. Every
// conn-ready line the server writes goes to onConnReady as it was written, on
// the server's own goroutine.
type verifyGateControl struct {
	conn        *verifyMemConn
	peer        *verifyMemConn
	mu          sync.Mutex
	gate        chan struct{}
	pending     []byte
	onConnReady func(line []byte)
}

func newVerifyGateControl(t *testing.T, onConnReady func([]byte)) *verifyGateControl {
	t.Helper()

	c := &verifyGateControl{onConnReady: onConnReady}
	c.conn, c.peer = newVerifyMemConnPair()
	c.conn.onWrite = c.written

	t.Cleanup(func() {
		c.open()
		_ = c.conn.Close()
		_ = c.peer.Close()
	})

	return c
}

func (c *verifyGateControl) shut() {
	c.mu.Lock()
	defer c.mu.Unlock()

	if c.gate == nil {
		c.gate = make(chan struct{})
	}
}

func (c *verifyGateControl) open() {
	c.mu.Lock()
	gate := c.gate
	c.gate = nil
	c.mu.Unlock()

	if gate != nil {
		close(gate)
	}
}

func (c *verifyGateControl) written(b []byte) {
	c.mu.Lock()
	gate := c.gate
	c.mu.Unlock()

	if gate != nil {
		<-gate
	}

	c.pending = append(c.pending, b...)

	for {
		i := bytes.IndexByte(c.pending, '\n')
		if i < 0 {
			return
		}

		if bytes.Contains(c.pending[:i], []byte(`"conn-ready"`)) {
			c.onConnReady(bytes.Clone(c.pending[:i]))
		}

		c.pending = c.pending[i+1:]
	}
}

// verifyConnPathOf reads the connPath out of a conn-ready line.
func verifyConnPathOf(line []byte) string {
	var msg verifyControlMessage
	_ = json.Unmarshal(line, &msg)

	return msg.ConnPath
}

// verifyIDs hands out predictable identifiers through the repository's own
// uuid.Set hook and remembers them in the order they went out.
type verifyIDs struct {
	mu     sync.Mutex
	issued []string
}

func (v *verifyIDs) Generate() string {
	v.mu.Lock()
	defer v.mu.Unlock()

	id := fmt.Sprintf("00000000-0000-4000-8000-%012d", len(v.issued)+1)
	v.issued = append(v.issued, id)

	return id
}

func (v *verifyIDs) all() []string {
	v.mu.Lock()
	defer v.mu.Unlock()

	return append([]string(nil), v.issued...)
}

// verifySettle yields until no other goroutine of the test binary is runnable,
// so every dial started before it has gone as far as it can.
func verifySettle(t *testing.T) {
	t.Helper()

	buf := make([]byte, 32<<20)

	for range 5000 {
		runtime.Gosched()

		n := runtime.Stack(buf, true)
		if n < len(buf) && !bytes.Contains(buf[:n], []byte("[runnable")) {
			return
		}
	}

	require.FailNow(t, "the dials never came to rest")
}

// verifyQueueRoom counts the announcements a dialer takes while its first
// control write is held. It starts limit dials, cancels them all, lets the
// write go and counts the conn-ready messages the server then writes.
func verifyQueueRoom(t *testing.T, limit int) int {
	t.Helper()

	var announced atomic.Int64

	ctl := newVerifyGateControl(t, func([]byte) { announced.Add(1) })
	ctl.shut()

	d := revdial.NewDialer(verifyQuietLogger(), ctl.conn, verifyConnPath, clock.New())
	t.Cleanup(func() { go func() { _ = d.Close() }() })

	ctx, cancel := context.WithCancel(t.Context())

	var wg sync.WaitGroup

	for range limit {
		wg.Go(func() { _, _ = d.Dial(ctx) })
	}

	verifySettle(t)
	cancel()
	wg.Wait()

	ctl.open()
	verifySettle(t)

	return int(announced.Load())
}

// TestVerifyAnswerOnOneCPUReachesItsDial: a gateway with one CPU opens more
// sessions at once than the dialer's announcement queue holds, to a device
// that answers the moment it can. The case first counts how many announcements
// the queue takes. Identifiers come from the repository's uuid.Set hook, so the
// case knows each dial's id as it's made. A first dial shows the shape of a
// connection path. The server is then held in a write while the queue fills and
// 64 more dials wait to announce, and the device answers those 64 ids right
// away. Every other conn-ready is answered inside the server's own write of
// it. Every dial has to get its connection.
func TestVerifyAnswerOnOneCPUReachesItsDial(t *testing.T) {
	defer runtime.GOMAXPROCS(runtime.GOMAXPROCS(1))
	verifyHoldCollection(t)

	const limit = 4096

	room := verifyQueueRoom(t, limit)
	if room >= limit {
		t.Logf("the dialer took all %d announcements without making a dial wait", limit)

		return
	}

	ids := &verifyIDs{}
	uuid.Set(t, ids)

	connHandler := revdial.ConnHandler(websocket.Upgrader{})

	var (
		mu       sync.Mutex
		seen     []string
		answered = map[string]bool{}
	)

	ctl := newVerifyGateControl(t, func(line []byte) {
		connPath := verifyConnPathOf(line)

		mu.Lock()
		seen = append(seen, connPath)
		skip := answered[connPath]
		mu.Unlock()

		if !skip {
			verifyAnswer(connHandler, connPath)
		}
	})

	d := revdial.NewDialer(verifyQuietLogger(), ctl.conn, verifyConnPath, clock.New())
	t.Cleanup(func() { go func() { _ = d.Close() }() })

	ctx, cancel := context.WithTimeout(t.Context(), 10*time.Second)
	defer cancel()

	scout, err := d.Dial(ctx)
	require.NoError(t, err, "a single dial must get the connection the device dials back")
	_ = scout.Close()

	mu.Lock()
	require.NotEmpty(t, seen, "the server never wrote a conn-ready for the first dial")
	scoutPath := seen[0]
	mu.Unlock()

	scoutID := ""
	if issued := ids.all(); len(issued) > 0 {
		scoutID = issued[0]
	}

	dials := room + 65
	results := make(chan error, dials)

	dial := func() {
		conn, err := d.Dial(ctx)
		if err == nil {
			_ = conn.Close()
		}

		results <- err
	}

	ctl.shut()

	go dial()

	verifySettle(t)

	for range dials - 1 {
		go dial()
	}

	verifySettle(t)

	if issued := ids.all(); scoutID != "" && len(issued) == dials+1 && strings.Contains(scoutPath, scoutID) {
		for _, id := range issued[len(issued)-64:] {
			connPath := strings.Replace(scoutPath, scoutID, id, 1)

			mu.Lock()
			answered[connPath] = true
			mu.Unlock()

			go verifyAnswer(connHandler, connPath)
		}

		verifySettle(t)
	} else {
		t.Logf("the dials' identifiers don't come from uuid.Generate, so each conn-ready is answered as the server writes it")
	}

	runtime.Gosched()
	ctl.open()
	verifySettle(t)

	failed := 0

	var firstErr error

	for range dials {
		if err := <-results; err != nil {
			failed++

			if firstErr == nil {
				firstErr = err
			}
		}
	}

	require.Zerof(t, failed, "%d of %d dials never got the connection the device dialed back at once (the queue took %d); the first error: %v", failed, dials, room, firstErr)
}
