// Tests for how the reverse dialer pairs each Dial with the connection the
// device dials back for it.
//
// Every case goes through the package's exported surface (NewDialer, Dial,
// Close, Done and ConnHandler) and through the JSON control protocol a device
// speaks on the control connection. No unexported name is used, so the per-dial
// state can live in any container and a late connection can be closed wherever
// the code chooses. Everything runs under -race.

package revdial_test

import (
	"bufio"
	"context"
	"encoding/json"
	"errors"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"runtime/debug"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/gorilla/websocket"
	"github.com/shellhub-io/shellhub/pkg/clock"
	"github.com/shellhub-io/shellhub/pkg/revdial"
	"github.com/shellhub-io/shellhub/pkg/wsconnadapter"
	log "github.com/sirupsen/logrus"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

const (
	verifyConnPath    = "/ssh/revdial"
	verifyControlPath = "/control"
)

// verifyControlMessage has the wire shape of the control protocol the server
// and the device exchange (command, connPath, err).
type verifyControlMessage struct {
	Command  string `json:"command,omitempty"`
	ConnPath string `json:"connPath,omitempty"`
	Err      string `json:"err,omitempty"`
}

// verifyAgent plays the device: it reads conn-ready announcements off the
// control connection, dials websockets back into ConnHandler, and can report a
// failed pick-up.
type verifyAgent struct {
	t     *testing.T
	ctl   net.Conn
	wsURL string
	ready chan string
}

// verifyControl builds the control connection for a dialer. A real websocket
// has the timing of production, and a net.Pipe makes each write wait for the
// device to read it, which fixes the order of events.
type verifyControl func(t *testing.T, mux *http.ServeMux, wsURL string) (serverConn net.Conn, agentConn net.Conn)

func verifyWebsocketControl(t *testing.T, mux *http.ServeMux, wsURL string) (net.Conn, net.Conn) {
	t.Helper()

	accepted := make(chan net.Conn, 1)

	mux.HandleFunc(verifyControlPath, func(w http.ResponseWriter, r *http.Request) {
		conn, err := (&websocket.Upgrader{}).Upgrade(w, r, nil)
		if err != nil {
			t.Errorf("the control connection could not be upgraded: %v", err)

			return
		}

		accepted <- wsconnadapter.New(conn)
	})

	peer, _, err := websocket.DefaultDialer.DialContext(t.Context(), wsURL+verifyControlPath, nil) //nolint:bodyclose // gorilla/websocket documents that the handshake response body need not be closed.
	require.NoError(t, err)

	return <-accepted, wsconnadapter.New(peer)
}

func verifyPipeControl(*testing.T, *http.ServeMux, string) (net.Conn, net.Conn) {
	return net.Pipe()
}

func verifyQuietLogger() *log.Entry {
	logger := log.New()
	logger.SetOutput(io.Discard)

	return log.NewEntry(logger)
}

func verifyNewDialer(t *testing.T) (*revdial.Dialer, *verifyAgent) {
	t.Helper()

	return verifyNewDialerOver(t, verifyWebsocketControl)
}

func verifyNewDialerOver(t *testing.T, ctl verifyControl) (*revdial.Dialer, *verifyAgent) {
	t.Helper()

	return verifyNewDialerWith(t, ctl, verifyQuietLogger(), revdial.ConnHandler(websocket.Upgrader{}))
}

func verifyNewDialerWith(t *testing.T, ctl verifyControl, logger *log.Entry, connHandler http.Handler) (*revdial.Dialer, *verifyAgent) {
	t.Helper()

	mux := http.NewServeMux()
	mux.Handle(verifyConnPath, connHandler)

	srv := httptest.NewServer(mux)
	t.Cleanup(srv.Close)

	wsURL := "ws" + strings.TrimPrefix(srv.URL, "http")

	serverCtl, agentCtl := ctl(t, mux, wsURL)

	t.Cleanup(func() {
		_ = serverCtl.Close()
		_ = agentCtl.Close()
	})

	d := revdial.NewDialer(logger, serverCtl, verifyConnPath, clock.New())
	// Close runs on its own goroutine so that a Close that waits for someone to
	// read Done() can't hold up the rest of the test binary. These cases never
	// read Done().
	t.Cleanup(func() { go func() { _ = d.Close() }() })

	a := &verifyAgent{
		t:     t,
		ctl:   agentCtl,
		wsURL: wsURL,
		ready: make(chan string, 1024),
	}

	go a.readControl()

	return d, a
}

func (a *verifyAgent) readControl() {
	reader := bufio.NewReader(a.ctl)

	for {
		line, err := reader.ReadBytes('\n')
		if err != nil {
			return
		}

		var msg verifyControlMessage
		if err := json.Unmarshal(line, &msg); err != nil {
			return
		}

		if msg.Command == "conn-ready" {
			a.ready <- msg.ConnPath
		}
	}
}

func (a *verifyAgent) awaitConnReady() (string, bool) {
	select {
	case path := <-a.ready:
		return path, true
	case <-time.After(5 * time.Second):
		return "", assert.Fail(a.t, "the server never announced a connection to pick up")
	}
}

func (a *verifyAgent) dialBack(ctx context.Context, path string) (net.Conn, bool) {
	conn, _, err := websocket.DefaultDialer.DialContext(ctx, a.wsURL+path, nil) //nolint:bodyclose // gorilla/websocket documents that the handshake response body need not be closed.
	if err != nil {
		a.t.Errorf("the device could not dial back %s: %v", path, err)

		return nil, false
	}

	adapter := wsconnadapter.New(conn)
	a.t.Cleanup(func() { _ = adapter.Close() })

	return adapter, true
}

func (a *verifyAgent) failPickup(path string, reason string) bool {
	line, err := json.Marshal(verifyControlMessage{Command: "pickup-failed", ConnPath: path, Err: reason})
	if err == nil {
		_, err = a.ctl.Write(append(line, '\n'))
	}

	if err != nil {
		a.t.Errorf("the device could not report a failed pick-up: %v", err)

		return false
	}

	return true
}

func verifyDialWithin(t *testing.T, d *revdial.Dialer, timeout time.Duration) (net.Conn, error) {
	t.Helper()

	ctx, cancel := context.WithTimeout(t.Context(), timeout)
	defer cancel()

	return d.Dial(ctx)
}

// verifyHeldLog is a logrus hook. Once hold is called, every entry the dialer
// logs waits until release is closed or until three seconds after the hold
// began, whichever comes first. It stands in for a log sink that's slow to write
// on a box short of CPU.
type verifyHeldLog struct {
	until   atomic.Int64
	release chan struct{}
}

func (h *verifyHeldLog) hold() { h.until.Store(time.Now().Add(3 * time.Second).UnixNano()) }

func (h *verifyHeldLog) stop() { h.until.Store(0) }

func (h *verifyHeldLog) Levels() []log.Level { return log.AllLevels }

func (h *verifyHeldLog) Fire(*log.Entry) error {
	left := time.Until(time.Unix(0, h.until.Load()))
	if left <= 0 {
		return nil
	}

	select {
	case <-h.release:
	case <-time.After(left):
	}

	return nil
}

var (
	verifyCollectionMu    sync.Mutex
	verifyCollectionHolds int
	verifyCollectionPct   int
)

// verifyHoldCollection turns off automatic garbage collection until the test
// ends. A connection nobody references is closed by its finalizer at the next
// collection, which would make a dropped connection look closed during a read.
func verifyHoldCollection(t *testing.T) {
	t.Helper()

	verifyCollectionMu.Lock()
	if verifyCollectionHolds == 0 {
		verifyCollectionPct = debug.SetGCPercent(-1)
	}
	verifyCollectionHolds++
	verifyCollectionMu.Unlock()

	t.Cleanup(func() {
		verifyCollectionMu.Lock()
		verifyCollectionHolds--
		if verifyCollectionHolds == 0 {
			debug.SetGCPercent(verifyCollectionPct)
		}
		verifyCollectionMu.Unlock()
	})
}

// TestVerifyWaitingDialSurvivesAStaleFailure: one dial gives up, a second dial
// starts, and the device then reports that it couldn't pick up the first
// dial's connection before it dials back the second one. The second dial has to
// get its connection. The control connection is a net.Pipe, so the failure
// report is read before the dial-back arrives.
func TestVerifyWaitingDialSurvivesAStaleFailure(t *testing.T) {
	t.Parallel()

	d, a := verifyNewDialerOver(t, verifyPipeControl)

	gaveUp, cancel := context.WithCancel(t.Context())

	abandoned := make(chan error, 1)
	go func() {
		_, err := d.Dial(gaveUp)
		abandoned <- err
	}()

	stalePath, ok := a.awaitConnReady()
	require.True(t, ok)

	cancel()
	require.ErrorIs(t, <-abandoned, context.Canceled)

	agentDone := make(chan struct{})
	go func() {
		defer close(agentDone)

		path, ok := a.awaitConnReady()
		if !ok || !a.failPickup(stalePath, "stale") {
			return
		}

		a.dialBack(t.Context(), path)
	}()

	conn, err := verifyDialWithin(t, d, 5*time.Second)
	<-agentDone

	require.NoError(t, err, "a failure for a dial that gave up must not fail the one still waiting")
	require.NotNil(t, conn)
	_ = conn.Close()
}

// TestVerifyCloseReturnsWithNoDoneReceiver: a dialer that nothing watches is
// closed. Close has to return, and Done() has to read as closed by then or
// within a second after.
func TestVerifyCloseReturnsWithNoDoneReceiver(t *testing.T) {
	t.Parallel()

	serverCtl, agentCtl := net.Pipe()
	t.Cleanup(func() { _ = agentCtl.Close() })

	d := revdial.NewDialer(verifyQuietLogger(), serverCtl, verifyConnPath, clock.New())

	closed := make(chan struct{})
	go func() {
		_ = d.Close()
		close(closed)
	}()

	select {
	case <-closed:
	case <-time.After(5 * time.Second):
		require.FailNow(t, "Close must return even when nothing is receiving on Done")
	}

	deadline := time.After(time.Second)

	for {
		select {
		case _, open := <-d.Done():
			if !open {
				return
			}
		case <-deadline:
			require.FailNow(t, "Done must be closed once Close returned")
		}
	}
}

// TestVerifyDialReportsItsOwnPickupFailure: the device reports that it couldn't
// pick up the connection of the dial that's waiting. That dial returns the
// device's reason as its error.
func TestVerifyDialReportsItsOwnPickupFailure(t *testing.T) {
	t.Parallel()

	d, a := verifyNewDialer(t)

	go func() {
		if path, ok := a.awaitConnReady(); ok {
			a.failPickup(path, "the device could not reach the server")
		}
	}()

	conn, err := verifyDialWithin(t, d, 5*time.Second)

	require.ErrorContains(t, err, "the device could not reach the server")
	assert.Nil(t, conn)
}

// TestVerifyEachConcurrentDialGetsItsOwnConn: 16 dials run at once over a real
// websocket, and the device dials back each one and writes its path on it.
// Every dial gets a connection, and no two dials get the same one.
func TestVerifyEachConcurrentDialGetsItsOwnConn(t *testing.T) {
	t.Parallel()

	d, a := verifyNewDialer(t)

	const dials = 16

	go func() {
		for range dials {
			path, ok := a.awaitConnReady()
			if !ok {
				return
			}

			conn, ok := a.dialBack(t.Context(), path)
			if !ok {
				return
			}

			go func() {
				_, _ = conn.Write([]byte(path))
			}()
		}
	}()

	var wg sync.WaitGroup

	received := make(chan string, dials)
	failures := make(chan error, dials)

	for range dials {
		wg.Go(func() {
			conn, err := verifyDialWithin(t, d, 10*time.Second)
			if err != nil {
				failures <- err

				return
			}

			defer func() { _ = conn.Close() }()

			if err := conn.SetReadDeadline(time.Now().Add(10 * time.Second)); err != nil { //nolint:forbidigo // a deadline needs the wall clock
				failures <- err

				return
			}

			buf := make([]byte, 256)
			n, err := conn.Read(buf)
			if err != nil {
				failures <- err

				return
			}

			received <- string(buf[:n])
		})
	}

	wg.Wait()
	close(failures)
	close(received)

	for err := range failures {
		require.NoError(t, err, "every dial must get a connection or its own error")
	}

	paths := make(map[string]bool)
	for path := range received {
		assert.False(t, paths[path], "two dials received the same connection: %s", path)
		paths[path] = true
	}

	assert.Len(t, paths, dials, "every dial must end up holding a distinct connection")
}

// TestVerifyAbandonedDialBackIsClosed: a dial is cancelled, and the device then
// dials back the connection it was asked for. The server has to close that
// connection, so a read on the device's end fails with an error that isn't a
// timeout.
func TestVerifyAbandonedDialBackIsClosed(t *testing.T) {
	t.Parallel()
	verifyHoldCollection(t)

	d, a := verifyNewDialer(t)

	ctx, cancel := context.WithCancel(t.Context())

	dialed := make(chan error, 1)
	go func() {
		_, err := d.Dial(ctx)
		dialed <- err
	}()

	path, ok := a.awaitConnReady()
	require.True(t, ok)

	cancel()

	select {
	case err := <-dialed:
		require.ErrorIs(t, err, context.Canceled)
	case <-time.After(5 * time.Second):
		require.FailNow(t, "a cancelled dial must return")
	}

	late, ok := a.dialBack(t.Context(), path)
	require.True(t, ok)

	require.NoError(t, late.SetReadDeadline(time.Now().Add(5*time.Second))) //nolint:forbidigo // a deadline needs the wall clock

	_, err := late.Read(make([]byte, 1))

	require.Error(t, err)

	if netErr, ok := errors.AsType[net.Error](err); ok {
		assert.False(t, netErr.Timeout(), "a connection nobody claims must be closed, not left hanging")
	}
}

// TestVerifyDialBackLandingAsTheDialGivesUpIsClosed: the device's connection
// reaches the server while the dial is paused in a log call, and the dial is
// cancelled before it resumes. When the dial then gives up, the server has to
// close that connection. A dial that takes the connection instead is fine, so
// the case runs up to 12 times to see the dial give up at least once.
func TestVerifyDialBackLandingAsTheDialGivesUpIsClosed(t *testing.T) {
	t.Parallel()
	verifyHoldCollection(t)

	for range 12 {
		if verifyGiveUpWithADialBackWaiting(t) {
			return
		}
	}
}

func verifyGiveUpWithADialBackWaiting(t *testing.T) bool {
	t.Helper()

	held := &verifyHeldLog{release: make(chan struct{})}

	logger := log.New()
	logger.SetOutput(io.Discard)
	logger.SetLevel(log.TraceLevel)
	logger.AddHook(held)

	handled := make(chan struct{})

	var once sync.Once

	connHandler := revdial.ConnHandler(websocket.Upgrader{})
	watched := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer once.Do(func() { close(handled) })

		connHandler.ServeHTTP(w, r)
	})

	d, a := verifyNewDialerWith(t, verifyWebsocketControl, log.NewEntry(logger), watched)

	held.hold()
	defer held.stop()

	ctx, cancel := context.WithCancel(t.Context())
	defer cancel()

	type outcome struct {
		conn net.Conn
		err  error
	}

	dialed := make(chan outcome, 1)
	go func() {
		conn, err := d.Dial(ctx)
		dialed <- outcome{conn: conn, err: err}
	}()

	path, ok := a.awaitConnReady()
	require.True(t, ok)

	late, ok := a.dialBack(t.Context(), path)
	require.True(t, ok)

	select {
	case <-handled:
	case <-time.After(time.Second):
	}

	cancel()
	close(held.release)

	var r outcome
	select {
	case r = <-dialed:
	case <-time.After(5 * time.Second):
		require.FailNow(t, "a cancelled dial must return")
	}

	if r.err == nil {
		_ = r.conn.Close()

		return false
	}

	require.ErrorIs(t, r.err, context.Canceled)

	require.NoError(t, late.SetReadDeadline(time.Now().Add(5*time.Second))) //nolint:forbidigo // a deadline needs the wall clock

	_, err := late.Read(make([]byte, 1))

	require.Error(t, err)

	if netErr, ok := errors.AsType[net.Error](err); ok {
		assert.False(t, netErr.Timeout(), "a connection the dial gave up on must be closed, not left hanging")
	}

	return true
}

// TestVerifyQuickDialBackReachesABusyDial: the device dials back over a real
// websocket the moment it reads the announcement. Every log entry the dialer
// writes is held until the server has handled that dial-back, or for three
// seconds at most. The dial has to get the connection.
func TestVerifyQuickDialBackReachesABusyDial(t *testing.T) {
	t.Parallel()

	held := &verifyHeldLog{release: make(chan struct{})}

	logger := log.New()
	logger.SetOutput(io.Discard)
	logger.SetLevel(log.TraceLevel)
	logger.AddHook(held)

	var once sync.Once

	connHandler := revdial.ConnHandler(websocket.Upgrader{})
	handled := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer once.Do(func() { close(held.release) })

		connHandler.ServeHTTP(w, r)
	})

	d, a := verifyNewDialerWith(t, verifyWebsocketControl, log.NewEntry(logger), handled)

	held.hold()
	t.Cleanup(held.stop)

	agentDone := make(chan struct{})
	go func() {
		defer close(agentDone)

		if path, ok := a.awaitConnReady(); ok {
			a.dialBack(t.Context(), path)
		}
	}()

	conn, err := verifyDialWithin(t, d, 10*time.Second)
	held.stop()
	<-agentDone

	require.NoError(t, err, "a device that dials back right away must reach the dial that asked for it")
	require.NotNil(t, conn)
	_ = conn.Close()
}
