// Test for how long DialTo waits on a device that holds a v1 tunnel and never
// dials a stream back.
//
// The test is an external package (dialer_test) and uses only the exported
// surface: NewManager, NewKey, the Manager's Connections store, the Dialer's
// Manager field, DialTo, ErrUnreachable, ErrNoConnection and SSHOpenTarget. The
// limit on the wait can be a constant, a literal, a field or a setting. The test
// reads none of them. It waits for DialTo to return and checks the error. Runs
// under -race.

package dialer_test

import (
	"io"
	"net"
	"testing"
	"time"

	"github.com/shellhub-io/shellhub/pkg/clock"
	"github.com/shellhub-io/shellhub/pkg/revdial"
	dialer "github.com/shellhub-io/shellhub/server/ssh/pkg/dialer"
	log "github.com/sirupsen/logrus"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// verifyDialDeadline is how long the test waits for DialTo to give up. A limit
// of up to a minute or so returns in time, even on a slow box under the race
// detector. A DialTo that never gives up runs into it.
const verifyDialDeadline = 90 * time.Second

func TestVerifyDialToGivesUpOnADeviceThatNeverAnswers(t *testing.T) {
	// The device's side of the control pipe is drained but never dials a stream
	// back: the device holds the tunnel and the exchange never completes.
	serverCtl, agentCtl := net.Pipe()
	go func() { _, _ = io.Copy(io.Discard, agentCtl) }()

	logger := log.New()
	logger.SetOutput(io.Discard)

	tunnel := revdial.NewDialer(log.NewEntry(logger), serverCtl, "/ssh/revdial", clock.New())

	manager := dialer.NewManager(clock.New())
	manager.Connections.Store(dialer.NewKey("tenant", "device"), tunnel)

	d := &dialer.Dialer{Manager: manager}

	type outcome struct {
		conn net.Conn
		err  error
	}

	// The caller's context has no deadline and is never cancelled, the way an SSH
	// session's context is while its client waits, so only DialTo itself can
	// end the call.
	done := make(chan outcome, 1)
	go func() {
		conn, err := d.DialTo(t.Context(), "tenant", "device", dialer.SSHOpenTarget{SessionID: "session"})
		done <- outcome{conn: conn, err: err}
	}()

	select {
	case r := <-done:
		// The tunnel is closed on its own goroutine once DialTo has returned,
		// so a Close that waits for someone to read Done() can't hold up this
		// test, which checks DialTo alone. If DialTo is still waiting, the test
		// fails below and leaves the tunnel alone. No t.Cleanup is registered
		// for the same reason.
		go func() { _ = tunnel.Close() }()
		_ = serverCtl.Close()
		_ = agentCtl.Close()

		require.ErrorIs(t, r.err, dialer.ErrUnreachable,
			"a device that holds a tunnel but never answers must be reported unreachable")
		require.NotErrorIs(t, r.err, dialer.ErrNoConnection,
			"the device is present; it must not be reported as holding no tunnel")
		assert.Nil(t, r.conn)
	case <-time.After(verifyDialDeadline):
		require.FailNow(t, "DialTo must give up on a device that never dials a stream back, not hang the caller")
	}
}
