#!/usr/bin/env bash
# Sourced by tests/test.sh before the verify files run.
#
# The image holds the module cache for both Go modules the verify files build:
# the root module github.com/shellhub-io/shellhub (pkg/revdial) and the nested
# .../server module (server/ssh/pkg/dialer). This script exports the Go
# environment again and runs go mod download per module with the proxy off,
# which only checks the cache.
#
# test.sh runs under set -euo pipefail and sources this file, so nothing here
# may fail: a command that does would end test.sh before any test ran. When a
# module can't be found in the cache, the script logs it and goes on, and go
# test then reports what's missing.

cd /repo/shellhub

# Keep the image's cache locations (GOMODCACHE=/opt/cache/go,
# GOCACHE=/opt/cache/go-build). Defaults are set only if the environment was
# reset.
export GOFLAGS="-mod=mod"
export CGO_ENABLED="1"
export GOTOOLCHAIN="local"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"
mkdir -p "$GOMODCACHE" "$GOCACHE"

for mod in . server; do
    log="/tmp/gomod_${mod//\//_}.log"
    if ! ( cd "/repo/shellhub/$mod" && GOPROXY=off GOFLAGS=-mod=mod go mod download ) > "$log" 2>&1; then
        echo "[test-setup] WARN: module '$mod' needs something the cache doesn't hold; go test will report it" >&2
        cat "$log" >&2 || true
    fi
done

echo "[test-setup] Go environment ready (root and server modules, from the cache)"
