## Task

SSH to devices still running the v1 agent breaks every now and then. For each session we open, the server asks the device, over the link it keeps open to us, to dial a new connection back. Nearly always that's fine. Once in a while, though, the SSH client sits there for roughly three minutes before giving up with an EOF during the handshake. Since the gateway moved to smaller machines with less CPU we see it far more often, and our v1 connection job in CI keeps failing on that same stall.

A few other things show up on v1 at the same time. If a device connects but never completes its side, the caller waits indefinitely, with no error. Sometimes the wrong session gets the failure notice. Stale connections pile up. Shutting down a device's dialer can hang, too.

Please track down what's behind all this and get it fixed, so v1 sessions stop stalling and failing at random and a silent device is reported unreachable quickly.
