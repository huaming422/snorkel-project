## Task

We want to give repositories a credential that works over HTTPS. Today a repository can hand automation a credential that only works over SSH, so anything that reaches a repository over HTTPS has no credential of its own and has to borrow a full user account.

Add a per-repository credential that is presented as the password on an HTTPS Git request. It should be issuable as either read-only or read/write, cover both plain Git and Git LFS, and let an operator rotate its secret in place. These credentials should be manageable from the repository settings screen as well as the repository's REST API.

## User stories / requirements

- When a holder presents one of these credentials over HTTPS, it works only against the single repository it belongs to and only up to the level it was granted. A read-only credential can fetch from that repository but is refused when it tries to push; a read/write credential can both fetch and push.
- The credential authenticates Git and LFS access to its own repository, but it does not stand in for the repository's owner. Presenting it does not let the holder act as that user or reach anything outside the one repository it was issued for.
- When a credential is created, its secret value is shown once at that moment and cannot be read back afterward. The secret can later be replaced with a fresh value while the credential keeps the same name and the same access level.
- Git LFS transfers made with one of these credentials follow the same limits as plain Git: they stay confined to the single repository, and a read-only credential can download LFS objects but cannot upload them.
- These credentials can be listed, created, and removed through the repository's REST API, and that management is available only to an administrator of the repository.
