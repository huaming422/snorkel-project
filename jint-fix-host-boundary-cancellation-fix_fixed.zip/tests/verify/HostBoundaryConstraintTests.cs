// Behavioral checks for prompt time/cancellation enforcement when a script's
// time is spent inside host (CLR) callbacks. Every assertion drives the
// pre-existing public Jint.Engine / Jint.Options / TypeReference API; nothing
// here references any internal engine symbol, so the checks do not depend on
// how the engine change is structured.
//
// Two groups:
//   stopping checks:  a token cancelled, or a timeout that lapses, from inside
//                     a loop of host calls stops the run within about one host
//                     call, on every way a script reaches host code, including
//                     a run with the debugger enabled.
//   guardrail checks: host-side reads of a wrapped object after a run, or while
//                     the run is parked at a debugger pause, do not trip an
//                     expired limit, and a script that never calls host code,
//                     built-ins included, has its limits looked at no more
//                     often than before.

using System;
using System.Collections.Generic;
using System.Threading;
using Jint;
using Jint.Constraints;
using Jint.Native;
using Jint.Runtime;
using Jint.Runtime.Debugger;
using Jint.Runtime.Interop;
using Xunit;

namespace Jint.Verify;

public class HostBoundaryConstraintTests
{
    // The token is cancelled from inside the 3rd host call, which keeps the
    // assertion deterministic: the run must stop before a 4th call starts.
    private static void AssertCancelledDuringThirdHostCall(
        Func<CancellationTokenSource, Engine, Func<int>> setup, string script, Action<CancellationTokenSource, Options> configure = null)
    {
        using var cts = new CancellationTokenSource();
        var engine = new Engine(cfg =>
        {
            cfg.CancellationToken(cts.Token);
            configure?.Invoke(cts, cfg);
        });
        var hostCallCount = setup(cts, engine);

        Assert.Throws<ExecutionCanceledException>(() => engine.Execute(script));
        Assert.Equal(3, hostCallCount());
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowHostDelegateCalls()
    {
        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            var calls = 0;
            engine.SetValue("work", new Action(() => { if (++calls == 3) { cts.Cancel(); } }));
            return () => calls;
        }, "for (var i = 0; i < 40; i++) { work(); }");
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowHostDelegateCallsInsideAFunction()
    {
        // same loop inside a function body
        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            var calls = 0;
            engine.SetValue("work", new Action(() => { if (++calls == 3) { cts.Cancel(); } }));
            return () => calls;
        }, "function f() { for (var i = 0; i < 40; i++) { work(); } } f();");
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowClrMethodCalls()
    {
        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            var probe = new HostBoundaryProbe();
            probe.OnAccess = () => { if (probe.Accesses == 3) { cts.Cancel(); } };
            engine.SetValue("probe", probe);
            return () => probe.Accesses;
        }, "for (var i = 0; i < 40; i++) { probe.method(); }");
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowGenericClrMethodCalls()
    {
        // a generic method on an exposed object, its type argument inferred from the call
        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            var probe = new HostBoundaryProbe();
            probe.OnAccess = () => { if (probe.Accesses == 3) { cts.Cancel(); } };
            engine.SetValue("probe", probe);
            return () => probe.Accesses;
        }, "for (var i = 0; i < 40; i++) { probe.echo(i); }");
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowMemberAccessorReads()
    {
        // a member served by the embedder's member accessor callback
        var reads = 0;
        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            engine.SetValue("obj", new AccessorTarget());
            return () => reads;
        }, "for (var i = 0; i < 40; i++) { var v = obj.slow; }", (cts, cfg) => cfg.SetMemberAccessor((e, target, member) =>
        {
            if (target is AccessorTarget && member == "slow")
            {
                if (++reads == 3) { cts.Cancel(); }
                return JsNumber.Create(42);
            }

            return null;
        }));
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowClrPropertyReads()
    {
        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            var probe = new HostBoundaryProbe();
            probe.OnAccess = () => { if (probe.Accesses == 3) { cts.Cancel(); } };
            engine.SetValue("probe", probe);
            return () => probe.Accesses;
        }, "for (var i = 0; i < 40; i++) { var x = probe.value; }");
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowClrPropertyWrites()
    {
        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            var probe = new HostBoundaryProbe();
            probe.OnAccess = () => { if (probe.Accesses == 3) { cts.Cancel(); } };
            engine.SetValue("probe", probe);
            return () => probe.Accesses;
        }, "for (var i = 0; i < 40; i++) { probe.value = i; }");
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowClrConstructorCalls()
    {
        try
        {
            AssertCancelledDuringThirdHostCall((cts, engine) =>
            {
                CtorProbe.Constructions = 0;
                CtorProbe.OnConstruct = () => { if (CtorProbe.Constructions == 3) { cts.Cancel(); } };
                engine.SetValue("Probe", TypeReference.CreateTypeReference<CtorProbe>(engine));
                return () => CtorProbe.Constructions;
            }, "for (var i = 0; i < 40; i++) { new Probe(); }");
        }
        finally
        {
            CtorProbe.OnConstruct = static () => { };
        }
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowValueTypeConstructions()
    {
        // an exposed struct the script news up with no arguments
        try
        {
            AssertCancelledDuringThirdHostCall((cts, engine) =>
            {
                ValueProbe.Constructions = 0;
                ValueProbe.OnConstruct = () => { if (ValueProbe.Constructions == 3) { cts.Cancel(); } };
                engine.SetValue("Point", TypeReference.CreateTypeReference<ValueProbe>(engine));
                return () => ValueProbe.Constructions;
            }, "for (var i = 0; i < 40; i++) { new Point(); }");
        }
        finally
        {
            ValueProbe.OnConstruct = static () => { };
        }
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowDictionaryReads()
    {
        // reads through a wrapped string-keyed dictionary must stop on time too
        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            var dictionary = new SlowDictionary { { "someKey", 42 } };
            dictionary.OnAccess = () => { if (dictionary.Accesses == 3) { cts.Cancel(); } };
            engine.SetValue("cfg", dictionary);
            return () => dictionary.Accesses;
        }, "for (var i = 0; i < 40; i++) { var v = cfg.someKey; }");
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowDictionaryWrites()
    {
        // writes through a wrapped dictionary must stop on time too: a token
        // cancelled inside the 3rd write stops the loop before a 4th write starts
        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            var dictionary = new SlowDictionary();
            dictionary.OnAccess = () => { if (dictionary.Accesses == 3) { cts.Cancel(); } };
            engine.SetValue("cfg", dictionary);
            return () => dictionary.Accesses;
        }, "for (var i = 0; i < 40; i++) { cfg.someKey = i; }");
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowNumberKeyedDictionaryReads()
    {
        // reads through a wrapped dictionary whose keys are numbers, not strings
        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            var dictionary = new SlowIntDictionary { { 1, 42 } };
            dictionary.OnAccess = () => { if (dictionary.Accesses == 3) { cts.Cancel(); } };
            engine.SetValue("cfg", dictionary);
            return () => dictionary.Accesses;
        }, "for (var i = 0; i < 40; i++) { var v = cfg[1]; }");
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowNumberKeyedDictionaryWrites()
    {
        // writes through a wrapped dictionary whose keys are numbers
        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            var dictionary = new SlowIntDictionary { { 1, 42 } };
            dictionary.OnAccess = () => { if (dictionary.Accesses == 3) { cts.Cancel(); } };
            engine.SetValue("cfg", dictionary);
            return () => dictionary.Accesses;
        }, "for (var i = 0; i < 40; i++) { cfg[1] = i; }");
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowReadsInheritedFromADictionary()
    {
        // a script object whose prototype is a wrapped dictionary reads through it,
        // with a string key and with a number key
        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            var dictionary = new SlowDictionary { { "someKey", 42 } };
            dictionary.OnAccess = () => { if (dictionary.Accesses == 3) { cts.Cancel(); } };
            engine.SetValue("cfg", dictionary);
            return () => dictionary.Accesses;
        }, "var o = Object.create(cfg); for (var i = 0; i < 40; i++) { var v = o.someKey; }");

        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            var dictionary = new SlowIntDictionary { { 1, 42 } };
            dictionary.OnAccess = () => { if (dictionary.Accesses == 3) { cts.Cancel(); } };
            engine.SetValue("cfg", dictionary);
            return () => dictionary.Accesses;
        }, "var o = Object.create(cfg); for (var i = 0; i < 40; i++) { var v = o[1]; }");
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowTypeFactoryConstructions()
    {
        // construction of an exposed type served by the embedder's object factory
        var created = 0;
        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            engine.SetValue("Probe", TypeReference.CreateTypeReference<FactoryProbe>(engine));
            return () => created;
        }, "for (var i = 0; i < 40; i++) { new Probe(); }", (cts, cfg) => cfg.Interop.CreateTypeReferenceObject = (e, type, args) =>
        {
            if (type != typeof(FactoryProbe))
            {
                return null;
            }

            if (++created == 3) { cts.Cancel(); }
            return new FactoryProbe();
        });
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowEnumerableIterations()
    {
        // for-of over a wrapped collection must stop on time too
        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            var enumerable = new SlowEnumerable();
            enumerable.OnMoveNext = () => { if (enumerable.MoveNextCalls == 3) { cts.Cancel(); } };
            engine.SetValue("items", enumerable);
            return () => enumerable.MoveNextCalls;
        }, "for (const x of items) { }");
    }

    [Fact]
    public void CancellationIsObservedWhileForOfWalksASlowDictionary()
    {
        // for-of over a wrapped dictionary reads each entry from host code
        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            var dictionary = new SlowDictionary();
            for (var k = 0; k < 40; k++) { dictionary.Add("k" + k, k); }
            dictionary.OnAccess = () => { if (dictionary.Accesses == 3) { cts.Cancel(); } };
            engine.SetValue("cfg", dictionary);
            return () => dictionary.Accesses;
        }, "for (const entry of cfg) { }");
    }

    [Fact]
    public void CancellationDuringLoneHostCallStopsTheRunBeforeTheNextCall()
    {
        // the first call cancels the token; the run must stop before the second
        // call starts
        using var cts = new CancellationTokenSource();
        var engine = new Engine(cfg => cfg.CancellationToken(cts.Token));

        var calls = 0;
        engine.SetValue("work", new Action(() => { calls++; cts.Cancel(); }));

        Assert.Throws<ExecutionCanceledException>(() => engine.Execute("work(); work();"));
        Assert.Equal(1, calls);
    }

    [Fact]
    public void ExpiredTimeoutIsObservedBetweenSlowHostDelegateCalls()
    {
        // the timeout lapses while the 3rd host call is still running, so the loop
        // must abort at about that call instead of running the remaining calls.
        // Calls 1 and 2 return at once; the lower bound only tolerates a run that
        // was slow enough to lapse earlier.
        var calls = 0;
        var engine = new Engine(cfg => cfg.TimeoutInterval(TimeSpan.FromSeconds(1)));
        engine.SetValue("work", new Action(() => { if (++calls == 3) { Thread.Sleep(3000); } }));

        Assert.Throws<TimeoutException>(() => engine.Execute("for (var i = 0; i < 40; i++) { work(); }"));
        Assert.InRange(calls, 1, 3);
    }

    [Fact]
    public void CancellationIsObservedBetweenSlowHostDelegateCallsWithDebuggerEnabled()
    {
        // a run with the debugger enabled but not paused is still a live run and
        // must stop on time like any other
        AssertCancelledDuringThirdHostCall((cts, engine) =>
        {
            var calls = 0;
            engine.SetValue("work", new Action(() => { if (++calls == 3) { cts.Cancel(); } }));
            return () => calls;
        }, "for (var i = 0; i < 40; i++) { work(); }", (cts, cfg) => cfg.DebugMode());
    }

    [Fact]
    public void HostFreeStatementsDoNotHaveLimitsCheckedOnEveryStatement()
    {
        // a script that never calls host code must not have its limits looked at
        // more often than today. Checking the token on every statement keeps the
        // overshoot at zero or one for every cancel point.
        var largest = LargestOvershootAfterCancellation(
            "var x = 0; for (var i = 0; i < 10000; i++) { x = x + i; }");
        Assert.True(largest >= 8, $"limits looked at about every statement (largest overshoot {largest})");
    }

    [Fact]
    public void HostFreeBuiltInCallsDoNotHaveLimitsCheckedOnEveryCall()
    {
        // built-ins are not our host code; calling them, constructing them or
        // iterating them in a hot loop must not add a limit check per use
        foreach (var script in new[]
        {
            "var x = 0; for (var i = 0; i < 10000; i++) { x = Math.abs(x - i) + 'ab'.indexOf('b'); }",
            "var x = 0; for (var i = 0; i < 10000; i++) { x = x + new Array(2).length; }",
            "var x = 0; var a = [1, 2]; for (var i = 0; i < 10000; i++) { for (var v of a) { x = x + v; } }",
        })
        {
            var largest = LargestOvershootAfterCancellation(script);
            Assert.True(largest >= 8, $"limits looked at on every built-in use (largest overshoot {largest}): {script}");
        }
    }

    [Fact]
    public void HostFreeLoopDoesNotStopAtOnceOnAPendingCancellation()
    {
        // no statement clock here, so every loop shape the engine has stays in play.
        // The token is already cancelled; once the run reaches the loop, the loop
        // must not stop within its first few iterations. A run stopped before the
        // loop starts says nothing either way.
        foreach (var script in new[]
        {
            "var started = true; var n = 0; for (var i = 0; i < 100000; i++) { n++; }",
            "var started = true; var n = 0; function f() { for (var i = 0; i < 100000; i++) { n++; } } f();",
            "var started = true; var n = 0; while (n < 100000) { n++; }",
        })
        {
            using var cts = new CancellationTokenSource();
            cts.Cancel();
            var engine = new Engine(cfg => cfg.CancellationToken(cts.Token));
            try
            {
                engine.Execute(script);
            }
            catch (ExecutionCanceledException)
            {
            }

            if (engine.GetValue("started").IsUndefined())
            {
                continue;
            }

            Assert.True(engine.GetValue("n").AsNumber() >= 8, $"pending cancellation stopped the loop at once: {script}");
        }
    }

    [Fact]
    public void HostSideAccessToWrappedObjectDoesNotObserveCancellationAfterExecution()
    {
        // cancelling the token after a run must not make later C#-side reads of a
        // wrapped object throw
        using var cts = new CancellationTokenSource();
        var engine = new Engine(cfg => cfg.CancellationToken(cts.Token));
        var probe = new HostBoundaryProbe();
        engine.SetValue("probe", probe);
        engine.Execute("probe.value;");

        cts.Cancel();

        var wrapper = engine.GetValue("probe").AsObject();
        Assert.Equal(42, wrapper.Get("value").AsNumber());
    }

    [Fact]
    public void HostSideAccessToWrappedDictionaryDoesNotObserveCancellationAfterExecution()
    {
        // same guarantee for reads through a wrapped dictionary
        using var cts = new CancellationTokenSource();
        var engine = new Engine(cfg => cfg.CancellationToken(cts.Token));
        var dictionary = new SlowDictionary { { "someKey", 42 } };
        engine.SetValue("cfg", dictionary);
        engine.Execute("cfg.someKey;");

        cts.Cancel();

        var wrapper = engine.GetValue("cfg").AsObject();
        Assert.Equal(42, wrapper.Get("someKey").AsNumber());
    }

    [Fact]
    public void HostSideAccessToWrappedObjectDoesNotObserveExpiredTimeoutAfterExecution()
    {
        // the time limit keeps counting while the engine is idle; an expired timer
        // must not make later C#-side reads throw
        var engine = new Engine(cfg => cfg.TimeoutInterval(TimeSpan.FromMilliseconds(50)));
        var probe = new HostBoundaryProbe();
        engine.SetValue("probe", probe);
        engine.Execute("probe.value;");

        Thread.Sleep(200);

        var wrapper = engine.GetValue("probe").AsObject();
        Assert.Equal(42, wrapper.Get("value").AsNumber());
    }

    [Fact]
    public void WrappedObjectReadWhilePausedInDebuggerDoesNotObserveExpiredTimeout()
    {
        // While execution is suspended at a debugger pause, a watch expression or
        // the embedder's own inspection code reads wrapped objects from C#. The
        // time limit keeps counting across that pause, but a read taken while the
        // run is parked at the break must not trip the lapsed limit. There is no
        // live run to abort. A debugger statement parks us at the break; the read
        // happens from inside the pause, after the limit has already lapsed.
        var engine = new Engine(cfg => cfg
            .TimeoutInterval(TimeSpan.FromMilliseconds(50))
            .DebugMode()
            .DebuggerStatementHandling(DebuggerStatementHandling.Script));

        var probe = new HostBoundaryProbe();
        engine.SetValue("probe", probe);

        double? readWhilePaused = null;
        Exception thrownWhilePaused = null;
        engine.Debugger.Break += (sender, info) =>
        {
            // parked at the debugger statement: let the limit lapse the way a
            // developer stepping through would, then read a wrapped member as a
            // watch expression would
            Thread.Sleep(200);
            try
            {
                readWhilePaused = engine.GetValue("probe").AsObject().Get("value").AsNumber();
            }
            catch (Exception ex)
            {
                thrownWhilePaused = ex;
            }

            return StepMode.None;
        };

        try
        {
            engine.Execute("debugger;");
        }
        catch (TimeoutException)
        {
            // the run resuming past the lapsed limit may abort. That is the live
            // run observing the limit and is not what this check is about
        }

        Assert.Null(thrownWhilePaused);
        Assert.Equal(42, readWhilePaused);
    }

    [Fact]
    public void WrappedObjectReadWhilePausedInDebuggerDoesNotObserveCancellation()
    {
        // Same guarantee for cancellation: a token cancelled while parked at a
        // debugger pause must not make a watch-style read of a wrapped object
        // throw. The suspended run is not advancing, so there is nothing to abort.
        using var cts = new CancellationTokenSource();
        var engine = new Engine(cfg => cfg
            .CancellationToken(cts.Token)
            .DebugMode()
            .DebuggerStatementHandling(DebuggerStatementHandling.Script));

        var probe = new HostBoundaryProbe();
        engine.SetValue("probe", probe);

        double? readWhilePaused = null;
        Exception thrownWhilePaused = null;
        engine.Debugger.Break += (sender, info) =>
        {
            cts.Cancel();
            try
            {
                readWhilePaused = engine.GetValue("probe").AsObject().Get("value").AsNumber();
            }
            catch (Exception ex)
            {
                thrownWhilePaused = ex;
            }

            return StepMode.None;
        };

        try
        {
            engine.Execute("debugger;");
        }
        catch (ExecutionCanceledException)
        {
            // the run resuming past the cancellation may abort. That is the live
            // run observing the token and is not what this check is about
        }

        Assert.Null(thrownWhilePaused);
        Assert.Equal(42, readWhilePaused);
    }

    // A user constraint is checked before every statement, so it works as a
    // statement clock. On its CancelAt-th check it cancels the token; after the
    // abort, Checks - CancelAt is how many more statements ran before the run
    // noticed.
    private sealed class StatementClock : Constraint
    {
        private readonly CancellationTokenSource _cts;
        public int Checks;
        public int CancelAt;

        public StatementClock(CancellationTokenSource cts)
        {
            _cts = cts;
        }

        public override void Check()
        {
            if (++Checks == CancelAt)
            {
                _cts.Cancel();
            }
        }

        public override void Reset()
        {
        }
    }

    // Runs a host-free script once per cancel point 1..128 and returns the largest
    // number of statements that ran after the token was cancelled. A run that never
    // stops counts as int.MaxValue: it cannot have looked at the token more often
    // than before.
    private static int LargestOvershootAfterCancellation(string script)
    {
        var largest = 0;
        for (var cancelAt = 1; cancelAt <= 128; cancelAt++)
        {
            using var cts = new CancellationTokenSource();
            var clock = new StatementClock(cts) { CancelAt = cancelAt };
            var engine = new Engine(cfg => cfg.CancellationToken(cts.Token).Constraint(clock));
            try
            {
                engine.Execute(script);
                return int.MaxValue;
            }
            catch (ExecutionCanceledException)
            {
            }

            largest = System.Math.Max(largest, clock.Checks - cancelAt);
        }

        return largest;
    }

    private sealed class HostBoundaryProbe
    {
        public int Accesses;
        public Action OnAccess = static () => { };

        public int Value
        {
            get
            {
                Accesses++;
                OnAccess();
                return 42;
            }
            set
            {
                Accesses++;
                OnAccess();
            }
        }

        public int Method()
        {
            Accesses++;
            OnAccess();
            return 42;
        }

        public T Echo<T>(T value)
        {
            Accesses++;
            OnAccess();
            return value;
        }
    }

    private sealed class AccessorTarget
    {
    }

    private sealed class FactoryProbe
    {
    }

    private sealed class CtorProbe
    {
        public static int Constructions;
        public static Action OnConstruct = static () => { };

        public CtorProbe()
        {
            Constructions++;
            OnConstruct();
        }
    }

    private struct ValueProbe
    {
        public static int Constructions;
        public static Action OnConstruct = static () => { };
        public int Marker;

        public ValueProbe()
        {
            Marker = 1;
            Constructions++;
            OnConstruct();
        }
    }

    private sealed class SlowDictionary : IDictionary<string, object>
    {
        private readonly Dictionary<string, object> _inner = new();

        public int Accesses;
        public Action OnAccess = static () => { };

        public object this[string key]
        {
            get
            {
                Accesses++;
                OnAccess();
                return _inner[key];
            }
            set
            {
                Accesses++;
                OnAccess();
                _inner[key] = value;
            }
        }

        public bool TryGetValue(string key, out object value)
        {
            Accesses++;
            OnAccess();
            return _inner.TryGetValue(key, out value);
        }

        public ICollection<string> Keys => _inner.Keys;
        public ICollection<object> Values => _inner.Values;
        public int Count => _inner.Count;
        public bool IsReadOnly => false;

        public void Add(string key, object value) => _inner.Add(key, value);
        public bool ContainsKey(string key) => _inner.ContainsKey(key);
        public bool Remove(string key) => _inner.Remove(key);
        public void Add(KeyValuePair<string, object> item) => _inner.Add(item.Key, item.Value);
        public void Clear() => _inner.Clear();
        public bool Contains(KeyValuePair<string, object> item) => _inner.ContainsKey(item.Key);
        public void CopyTo(KeyValuePair<string, object>[] array, int arrayIndex) => ((IDictionary<string, object>) _inner).CopyTo(array, arrayIndex);
        public bool Remove(KeyValuePair<string, object> item) => _inner.Remove(item.Key);
        public IEnumerator<KeyValuePair<string, object>> GetEnumerator() => _inner.GetEnumerator();
        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator() => _inner.GetEnumerator();
    }

    private sealed class SlowIntDictionary : IDictionary<int, object>
    {
        private readonly Dictionary<int, object> _inner = new();

        public int Accesses;
        public Action OnAccess = static () => { };

        public object this[int key]
        {
            get
            {
                Accesses++;
                OnAccess();
                return _inner[key];
            }
            set
            {
                Accesses++;
                OnAccess();
                _inner[key] = value;
            }
        }

        public bool TryGetValue(int key, out object value)
        {
            Accesses++;
            OnAccess();
            return _inner.TryGetValue(key, out value);
        }

        public ICollection<int> Keys => _inner.Keys;
        public ICollection<object> Values => _inner.Values;
        public int Count => _inner.Count;
        public bool IsReadOnly => false;

        public void Add(int key, object value) => _inner.Add(key, value);
        public bool ContainsKey(int key) => _inner.ContainsKey(key);
        public bool Remove(int key) => _inner.Remove(key);
        public void Add(KeyValuePair<int, object> item) => _inner.Add(item.Key, item.Value);
        public void Clear() => _inner.Clear();
        public bool Contains(KeyValuePair<int, object> item) => _inner.ContainsKey(item.Key);
        public void CopyTo(KeyValuePair<int, object>[] array, int arrayIndex) => ((IDictionary<int, object>) _inner).CopyTo(array, arrayIndex);
        public bool Remove(KeyValuePair<int, object> item) => _inner.Remove(item.Key);
        public IEnumerator<KeyValuePair<int, object>> GetEnumerator() => _inner.GetEnumerator();
        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator() => _inner.GetEnumerator();
    }

    private sealed class SlowEnumerable : System.Collections.IEnumerable
    {
        public int MoveNextCalls;
        public Action OnMoveNext = static () => { };

        public System.Collections.IEnumerator GetEnumerator() => new Enumerator(this);

        private sealed class Enumerator : System.Collections.IEnumerator
        {
            private readonly SlowEnumerable _owner;
            private int _index;

            public Enumerator(SlowEnumerable owner)
            {
                _owner = owner;
            }

            public object Current => _index;

            public bool MoveNext()
            {
                _owner.MoveNextCalls++;
                _owner.OnMoveNext();
                return _index++ < 40;
            }

            public void Reset()
            {
            }
        }
    }
}
