#!/usr/bin/env bash
#
# Behavioral verifier for jint-fix-host-boundary-cancellation.
#
# Builds a standalone xUnit project (shipped alongside this script) that links
# the candidate-built Jint library through a ProjectReference, then runs the
# host-boundary constraint checks against it. Every check drives the public
# Jint.Engine / Jint.Options / TypeReference API, so the verifier is independent
# of how the fix is structured internally.
#
# Exit 0 only when every check passes:
#   fail_to_pass: a token cancelled inside a loop of host calls aborts within
#                 about one host call, on each interop lane (counter == 3), a
#                 cancellation in a lone host call stops the run before the next
#                 call (counter == 1), and a timeout that lapses during a host
#                 call aborts the loop at about that call (counter <= 3).
#   pass_to_pass: host-side reads of a wrapped object or dictionary after a run,
#                 or while paused in the debugger, do not trip an expired limit.
#
# cwd at invocation is the repo root (/repo/jint). Any non-zero exit = fail.

set -uo pipefail

# --- locate inputs -----------------------------------------------------------
# Directory holding this script and the C# sources (staged read-only under /tests).
VERIFY_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Repo root: cwd is set to it by the runner, with a couple of fallbacks.
REPO_DIR="${REPO_DIR:-$PWD}"
if [ ! -f "$REPO_DIR/Jint/Jint.csproj" ]; then
    for cand in /repo/jint "$PWD"; do
        if [ -f "$cand/Jint/Jint.csproj" ]; then REPO_DIR="$cand"; break; fi
    done
fi
JINT_CSPROJ="$REPO_DIR/Jint/Jint.csproj"

if [ ! -f "$JINT_CSPROJ" ]; then
    echo "FAIL: could not locate Jint/Jint.csproj under '$REPO_DIR'"
    exit 1
fi

# --- make dotnet available and offline ---------------------------------------
case ":$PATH:" in
    *":/usr/share/dotnet:"*) ;;
    *) export PATH=/usr/share/dotnet:/root/.dotnet/tools:$PATH ;;
esac
export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1
export NUGET_PACKAGES="${NUGET_PACKAGES:-/root/.nuget/packages}"
export DOTNET_CLI_UI_LANGUAGE=en

if ! command -v dotnet >/dev/null 2>&1; then
    echo "FAIL: dotnet CLI not found on PATH"
    exit 1
fi

# --- stage a writable copy of the project ------------------------------------
# The staged /tests tree is read-only; MSBuild needs a writable obj/bin, so copy
# the project sources to a scratch dir and build there.
WORK_DIR="$(mktemp -d)"
trap 'rm -rf "$WORK_DIR"' EXIT
cp "$VERIFY_DIR/HostBoundaryVerify.csproj" "$WORK_DIR/HostBoundaryVerify.csproj"
cp "$VERIFY_DIR/HostBoundaryConstraintTests.cs" "$WORK_DIR/HostBoundaryConstraintTests.cs"

PROJ="$WORK_DIR/HostBoundaryVerify.csproj"
LOG="$WORK_DIR/dotnet-test.log"

echo "Repo:        $REPO_DIR"
echo "Jint.csproj: $JINT_CSPROJ"
echo "Work dir:    $WORK_DIR"

# --- build + run the checks offline ------------------------------------------
# The NuGet closure (Jint deps + xUnit test stack) is warmed into the image, so
# restore/build need no network. --property:JintCsproj points the ProjectReference
# at the candidate's library.
set -o pipefail
dotnet test "$PROJ" \
    -c Release \
    --property:JintCsproj="$JINT_CSPROJ" \
    --property:NuGetAudit=false \
    2>&1 | tee "$LOG"
status=${PIPESTATUS[0]}

if [ "$status" -ne 0 ]; then
    echo "FAIL: host-boundary constraint checks did not all pass (dotnet test exit $status)"
    exit 1
fi

echo "PASS: prompt time/cancellation enforcement restored across host-call boundaries"
exit 0
