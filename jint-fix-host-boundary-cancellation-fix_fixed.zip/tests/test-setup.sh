#!/usr/bin/env bash
#
# Sourced (not exec'd) so the env we set sticks around for the verifier's
# `dotnet test` invocation. Runs once before grading.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/jint}"
cd "$REPO_DIR"

# The .NET SDK lives in the base image; make sure it is on PATH even when the
# harness spawns a scrubbed shell.
case ":$PATH:" in
    *":/usr/share/dotnet:"*) ;;
    *) export PATH=/usr/share/dotnet:/root/.dotnet/tools:$PATH ;;
esac

# Quiet, deterministic, and offline-first. The NuGet package closure for the
# Jint library and its test project was restored at image-build time into
# NUGET_PACKAGES (/root/.nuget/packages), so grade-time restore/build is a
# no-op that needs no network.
export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1
export NUGET_PACKAGES="${NUGET_PACKAGES:-/root/.nuget/packages}"
# English CLI output so the test log reads the same on every host.
export DOTNET_CLI_UI_LANGUAGE=en
