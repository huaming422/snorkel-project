## Task

we embed Jint to run user-supplied scripts and rely on an execution timeout or a cancellation token to stop anything that runs away. that safety net has gotten unreliable when a script spends its time in our C# code: functions we register, properties and methods on objects we expose, types we expose that it constructs, or collections we expose that it loops over with for-of. a cancelled token or an expired timeout no longer takes effect promptly there. a loop that keeps calling into our code runs well past the point it should have stopped, often all the way to the end, when it should stop within about one host call.

scripts that never touch our C# code shouldn't get any slower. and our own C# code reading the engine's wrapped objects after a run has finished, or from a debugger break handler while paused, has to keep working even if the token was cancelled or the timeout ran out by then.
