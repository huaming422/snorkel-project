//! Behavioral checks for the SQL JSON functions (`json`, `json_each`,
//! `json_tree`) driven through a real `turso_core::Connection`.
//!
//! The SQL surface is the stable, public boundary: these functions, their
//! argument shapes, and their result columns are unchanged by the work under
//! test — only the internal number/value parsing and value serialization
//! behavior differs. So every check here speaks SQL and inspects the returned
//! rows (or the fact that a query returned an error); none of them reach into
//! the private `core/json` helpers, name an internal symbol, or match a
//! specific error-message string. A query that must reject malformed input is
//! asserted only to return `Err` — any wording is acceptable.
//!
//! The connection/exec helpers below are deliberately inlined: the repo's
//! integration helpers (`tests/integration/common.rs`) live in a module that
//! is private to the `integration_tests` target and cannot be imported from a
//! sibling integration test. These few functions mirror that module's
//! `TempDatabase` / `try_limbo_exec_rows` shape.

use std::sync::Arc;

use turso_core::{Connection, Database, LimboError};

/// Owned, comparable mirror of `turso_core::Value` so assertions don't depend
/// on the engine value type's lifetime or trait impls.
#[derive(Debug, Clone, PartialEq)]
enum Cell {
    Null,
    Int(i64),
    Real(f64),
    Text(String),
    Blob(Vec<u8>),
}

/// Fresh file-backed temp database + connection, mirroring `TempDatabase`.
fn connect() -> (tempfile::TempDir, Arc<Connection>) {
    let dir = tempfile::TempDir::new().expect("create temp dir");
    let mut path = dir.path().to_path_buf();
    path.push("verify.db");
    let io = Arc::new(turso_core::PlatformIO::new().expect("platform io"));
    let db: Arc<Database> =
        Database::open_file(io, path.to_str().expect("utf8 path")).expect("open db");
    let conn = db.connect().expect("connect");
    // Keep `dir` alive for the lifetime of the connection: dropping it would
    // remove the backing file.
    (dir, conn)
}

/// Run a query and collect its rows, returning `Err` if preparation or
/// execution fails (the engine surfaces malformed input as an execution error).
fn exec(conn: &Arc<Connection>, sql: &str) -> Result<Vec<Vec<Cell>>, LimboError> {
    let mut stmt = conn.prepare(sql)?;
    let mut rows: Vec<Vec<Cell>> = Vec::new();
    stmt.run_with_row_callback(|row| {
        let cells = row
            .get_values()
            .map(|v| match v {
                turso_core::Value::Null => Cell::Null,
                turso_core::Value::Integer(i) => Cell::Int(*i),
                turso_core::Value::Float(f) => Cell::Real(*f),
                turso_core::Value::Text(t) => Cell::Text(t.as_str().to_string()),
                turso_core::Value::Blob(b) => Cell::Blob(b.to_vec()),
            })
            .collect();
        rows.push(cells);
        Ok(())
    })?;
    Ok(rows)
}

/// Single-cell text result from a one-row, one-column query.
fn one_text(conn: &Arc<Connection>, sql: &str) -> String {
    let rows = exec(conn, sql).unwrap_or_else(|e| panic!("query failed unexpectedly: {sql}: {e}"));
    assert_eq!(rows.len(), 1, "expected exactly one row from {sql}");
    assert_eq!(rows[0].len(), 1, "expected exactly one column from {sql}");
    match &rows[0][0] {
        Cell::Text(t) => t.clone(),
        other => panic!("expected a text cell from {sql}, got {other:?}"),
    }
}

/// The first column of every row, as text.
fn first_col_text(conn: &Arc<Connection>, sql: &str) -> Vec<String> {
    let rows = exec(conn, sql).unwrap_or_else(|e| panic!("query failed unexpectedly: {sql}: {e}"));
    rows.iter()
        .map(|r| match &r[0] {
            Cell::Text(t) => t.clone(),
            other => panic!("expected a text cell from {sql}, got {other:?}"),
        })
        .collect()
}

// ---------------------------------------------------------------------------
// Values that must parse and produce a specific result.
// ---------------------------------------------------------------------------

/// `NaN` (in any letter case) is a JSON5 value that maps to the JSON `null`
/// value, matching the reference SQL engine. It must not be rejected.
#[test]
fn json_nan_maps_to_null() {
    let (_dir, conn) = connect();
    assert_eq!(one_text(&conn, "SELECT json('NaN')"), "null");
    assert_eq!(one_text(&conn, "SELECT json('nan')"), "null");
    assert_eq!(one_text(&conn, "SELECT json('nAn')"), "null");
}

// ---------------------------------------------------------------------------
// Malformed inputs that must surface an error to the SQL caller.
// ---------------------------------------------------------------------------

/// A bare sign, an incomplete exponent, or a hex prefix with no digits is not
/// a valid number and must be rejected rather than accepted.
#[test]
fn json_malformed_numbers_are_rejected() {
    let (_dir, conn) = connect();
    for input in ["-", "+", "1e", "1e+", "1e-", "0x"] {
        let sql = format!("SELECT json('{input}')");
        assert!(
            exec(&conn, &sql).is_err(),
            "malformed numeric input {input:?} should surface an error, but it was accepted"
        );
    }
}

/// Leading zeros and doubled signs are not valid numbers under the reference
/// engine's rules and must be rejected.
#[test]
fn json_leading_zeros_and_doubled_signs_are_rejected() {
    let (_dir, conn) = connect();
    for input in ["00", "01", "--1", "++1"] {
        let sql = format!("SELECT json('{input}')");
        assert!(
            exec(&conn, &sql).is_err(),
            "input {input:?} should surface an error, but it was accepted"
        );
    }
}

/// An empty string is not valid JSON and must be rejected.
#[test]
fn json_empty_string_is_rejected() {
    let (_dir, conn) = connect();
    assert!(
        exec(&conn, "SELECT json('')").is_err(),
        "empty-string input should surface an error, but it was accepted"
    );
}

/// A malformed binary JSON value whose numeric payload carries multi-byte
/// UTF-8 must surface an error to the SQL caller and must not crash the engine.
/// The byte sequence (`64 54 EF 97 93 3F 5D`) is a 5-element-type header with a
/// 6-byte payload "T" + U+F5D3 (a 3-byte char) + "?" + "]"; serializing it back
/// to text must handle the non-ASCII bytes without slicing across a character
/// boundary. After the error, the same connection must keep working.
#[test]
fn json_malformed_binary_payload_errors_without_crashing() {
    let (_dir, conn) = connect();
    let res = exec(&conn, "SELECT json(x'6454EF97933F5D')");
    assert!(
        res.is_err(),
        "malformed binary JSON should surface an error, but it was accepted: {res:?}"
    );
    // The connection survived: a subsequent valid query still works.
    assert_eq!(one_text(&conn, "SELECT json('1')"), "1");
}

// ---------------------------------------------------------------------------
// Valid inputs that must keep producing the same output (no over-rejection).
// ---------------------------------------------------------------------------

/// A spread of valid JSON5 inputs must still parse and serialize to the same
/// canonical JSON as before the change: hex integers, trailing-dot decimals,
/// and Infinity. Guards against tightening the parser so far that legitimate
/// values start erroring.
#[test]
fn valid_json5_still_round_trips() {
    let (_dir, conn) = connect();
    assert_eq!(one_text(&conn, "SELECT json('{a: 0x0}')"), r#"{"a":0}"#);
    assert_eq!(one_text(&conn, "SELECT json('{x: 4.}')"), r#"{"x":4.0}"#);
    assert_eq!(
        one_text(&conn, "SELECT json('{x: Infinity}')"),
        r#"{"x":9e999}"#
    );
    // A plain valid number and a plain object are unaffected.
    assert_eq!(one_text(&conn, "SELECT json('-1')"), "-1");
    assert_eq!(one_text(&conn, "SELECT json('{\"k\":1}')"), r#"{"k":1}"#);
}

/// The JSON table-valued functions must keep returning correct text values and
/// full-key paths after the serialization change. `json_tree` exercises
/// object-key path building (`$.b.c`) and array indexing (`$.d[0]`);
/// `json_each` exercises text value extraction.
#[test]
fn json_each_and_tree_valid_inputs_unchanged() {
    let (_dir, conn) = connect();

    let fullkeys = first_col_text(
        &conn,
        r#"SELECT fullkey FROM json_tree('{"a":1,"b":{"c":2},"d":[3,4]}') ORDER BY id"#,
    );
    assert_eq!(
        fullkeys,
        vec!["$", "$.a", "$.b", "$.b.c", "$.d", "$.d[0]", "$.d[1]"]
    );

    let values = first_col_text(
        &conn,
        r#"SELECT value FROM json_each('["x","y","z"]') ORDER BY id"#,
    );
    assert_eq!(values, vec!["x", "y", "z"]);
}
