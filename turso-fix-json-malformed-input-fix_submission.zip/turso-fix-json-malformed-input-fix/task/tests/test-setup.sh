#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
# Investigation/bug task: no services to start, no data to seed. The image
# baked the full Cargo dependency closure and compiled the workspace at the
# base commit, so grading is offline. Export the offline switch right after cd
# so any cache miss fails fast instead of reaching for crates.io.
cd /repo/turso
export CARGO_NET_OFFLINE=true

# Dependencies are already present from the image bake; verify the registry is
# satisfiable offline (logged online fallback only if the bake was stale).
if cargo fetch --locked > /tmp/test-setup-fetch.log 2>&1; then
    echo "[offline-first] cargo registry satisfied from image"
else
    echo "[test-setup] offline cargo fetch failed; retrying online (image bake was stale)"
    CARGO_NET_OFFLINE=false cargo fetch --locked >> /tmp/test-setup-fetch.log 2>&1 \
        || { tail -40 /tmp/test-setup-fetch.log >&2; exit 1; }
fi
