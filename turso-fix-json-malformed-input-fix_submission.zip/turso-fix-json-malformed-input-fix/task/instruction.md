## Task

our JSON support has drifted away from what SQLite does, and it's biting us on edge-case input. some JSON values fed to `json()` actually crash the engine instead of returning anything. a bunch of clearly invalid JSON gets accepted as if it were fine, when SQLite would reject it outright. and some malformed input that should come back as an error instead comes back empty or just wrong, so the caller never finds out anything went sideways.

stock SQLite handles all of these cleanly, and people reach for us expecting to match it. this spans both the `json()` scalar and the related table-valued functions (`json_each`, `json_tree`).

dig in, find the root cause, and make the JSON functions robust and SQLite-compatible.
