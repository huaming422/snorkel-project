"""Deterministic dbt stand-in used by the behavioral verifier."""

from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path
from types import SimpleNamespace

from prefect._internal.concurrency.cancellation import CancelledError


def _control() -> dict[str, str]:
    path = Path(os.environ["VERIFY_DBT_CONTROL_PATH"])
    return json.loads(path.read_text())


class QueuedDbtRunner:
    """Small, spawn-safe replacement for dbt's programmatic runner."""

    def __init__(self, callbacks=None):
        self.callbacks = callbacks or []

    def invoke(self, args):
        control = _control()
        mode = control["mode"]
        if control.get("work_dir"):
            work_dir = Path(control["work_dir"])
            work_dir.mkdir(parents=True, exist_ok=True)
            with (work_dir / "invocations").open("a") as log:
                log.write(args[0] + "\n")

        if mode == "success":
            if args[0] == "parse":
                project = Path(args[args.index("--project-dir") + 1])
                target = Path(args[args.index("--target-path") + 1])
                manifest = project / target / "manifest.json"
                manifest.parent.mkdir(parents=True, exist_ok=True)
                manifest.write_text('{"nodes": {}, "sources": {}}')
            return SimpleNamespace(success=True, exception=None, result=None)
        if mode == "ordinary_failure":
            return SimpleNamespace(
                success=False, exception=RuntimeError("boom"), result=None
            )
        if mode == "returned_cancellation":
            return SimpleNamespace(
                success=False, exception=CancelledError(), result=None
            )

        work_dir = Path(control["work_dir"])
        work_dir.mkdir(parents=True, exist_ok=True)
        shutdown = threading.Event()
        completed = threading.Event()
        remaining = [2]
        remaining_lock = threading.Lock()

        def stopping() -> bool:
            return shutdown.is_set() or (work_dir / "shutdown").exists()

        def dispatch(slot: int) -> None:
            for job in (1, 2):
                if stopping():
                    break
                (work_dir / f"current-{slot}").write_text(str(job))
                heartbeat = work_dir / f"heartbeat-{slot}-{job}"
                cancel = work_dir / f"cancel-{slot}-{job}"
                while not (work_dir / "shutdown").exists() and not cancel.exists():
                    heartbeat.write_text(str(time.time_ns()))
                    time.sleep(0.02)

            with remaining_lock:
                remaining[0] -= 1
                if remaining[0] == 0:
                    completed.set()

        workers = [
            threading.Thread(target=dispatch, args=(slot,), daemon=True)
            for slot in (0, 1)
        ]
        for worker in workers:
            worker.start()
        (work_dir / "started").touch()

        try:
            if mode == "blocking_wait":
                completed.wait()
            else:
                while any(worker.is_alive() for worker in workers):
                    time.sleep(0.01)
        except (KeyboardInterrupt, SystemExit):
            time.sleep(0.6)
            shutdown.set()
            (work_dir / "shutdown").touch()
            for worker in workers:
                worker.join()
            raise

        return SimpleNamespace(success=True, exception=None, result=None)
