"""Make the verifier stand-in available to spawned Python workers."""

import os
import time

if os.getenv("VERIFY_DBT_CONTROL_PATH"):
    time.sleep(float(os.getenv("VERIFY_DBT_CHILD_STARTUP_DELAY", "0")))
    try:
        import dbt.cli.main

        from dbt_timeout_standin import QueuedDbtRunner

        dbt.cli.main.dbtRunner = QueuedDbtRunner
    except ImportError:
        pass
