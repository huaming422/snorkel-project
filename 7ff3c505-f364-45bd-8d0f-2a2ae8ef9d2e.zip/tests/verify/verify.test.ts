// @ts-nocheck
//
// Exercises the public teardown result through `terminateProcessTree`.
//
// The process and clock doubles allow exits at controlled times.

import { EventEmitter } from 'node:events'
import { afterEach, describe, expect, it, vi } from 'vitest'

const { spawnMock } = vi.hoisted(() => ({ spawnMock: vi.fn() }))
vi.mock('node:child_process', () => ({ spawn: spawnMock }))

const { registerOwnedPosixProcessGroup, terminateProcessTree } = await import('./process-tree')

// Minimal ChildProcess stand-in: an EventEmitter (so the exit wait resolves)
// exposing the pid/kill/killed/exitCode surface the code under test touches.
class FakeChild extends EventEmitter {
  kill = vi.fn(() => {
    this.killed = true
    return true
  })
  killed = false
  exitCode: number | null = null
  signalCode: string | null = null
  constructor(public pid: number | undefined) {
    super()
  }
}

// A `ps` stand-in: an EventEmitter with its own stdout EventEmitter, matching
// spawn('ps', ...).
class FakePs extends EventEmitter {
  stdout = new EventEmitter()
  kill = vi.fn(() => true)
}

// Return a usable process snapshot for every scan, including rescans made by
// implementations that refresh descendant discovery during teardown.
const psSnapshots = (output: string, groupState?: () => string): FakePs => {
  const first = new FakePs()
  spawnMock.mockImplementationOnce(() => first)
  spawnMock.mockImplementation((_cmd: string, args: string[]) => {
    const next = new FakePs()
    queueMicrotask(() => {
      next.stdout.emit('data', Buffer.from(args.includes('pgid=,state=') ? (groupState?.() ?? '') : output))
      next.emit('close', 0)
    })
    return next
  })
  return first
}

const esrch = (): NodeJS.ErrnoException => Object.assign(new Error('ESRCH'), { code: 'ESRCH' })

const originalPlatform = process.platform
const setPlatform = (value: string): void => {
  Object.defineProperty(process, 'platform', { value, configurable: true })
}

afterEach(() => {
  setPlatform(originalPlatform)
  vi.restoreAllMocks()
  vi.clearAllMocks()
  vi.useRealTimers()
})

describe('terminateProcessTree shutdown results', () => {
  it.each(['linux', 'darwin'])(
    'confirms a tree after the child and descendant stop at different times on %s',
    async (platform) => {
      vi.useFakeTimers()
      setPlatform(platform)
      const ps = psSnapshots('1000 1\n1001 1000\n')

      // The descendant remains visible briefly after the signal.
      let descendantAlive = true
      const killSpy = vi.spyOn(process, 'kill').mockImplementation((pid, signal) => {
        expect(pid).toBe(1001)
        if (signal === 0 && !descendantAlive) throw esrch()
        if (signal === 'SIGKILL') setTimeout(() => (descendantAlive = false), 100)
        return true
      })
      const child = new FakeChild(1000)
      const settled = vi.fn()
      const pending = terminateProcessTree(child as never).then(settled)

      ps.stdout.emit('data', Buffer.from('1000 1\n1001 1000\n'))
      ps.emit('close', 0)
      await Promise.resolve()
      await Promise.resolve()
      child.emit('exit', 0, null) // parent exits first
      await vi.advanceTimersByTimeAsync(100) // descendant exits asynchronously
      await pending

      expect(killSpy).toHaveBeenCalledWith(1001, 'SIGKILL')
      expect(settled).toHaveBeenCalledExactlyOnceWith({ reaped: true })
    }
  )

  it.each(['linux', 'darwin'])(
    'confirms a tree when the child and two descendants stop at different times on %s',
    async (platform) => {
      vi.useFakeTimers()
      setPlatform(platform)
      const ps = psSnapshots('1000 1\n1001 1000\n1002 1001\n')
      const child = new FakeChild(1000)
      const alive = new Set([1001, 1002])
      const killSpy = vi.spyOn(process, 'kill').mockImplementation((pid, signal) => {
        if (pid === 1000 && signal === 'SIGKILL') {
          setTimeout(() => child.emit('exit', 0, null), 50)
          return true
        }
        if (signal === 0 && !alive.has(pid)) throw esrch()
        if (signal === 'SIGKILL' && pid === 1001) setTimeout(() => alive.delete(pid), 100)
        if (signal === 'SIGKILL' && pid === 1002) setTimeout(() => alive.delete(pid), 200)
        return true
      })

      const pending = terminateProcessTree(child as never)
      ps.stdout.emit('data', Buffer.from('1000 1\n1001 1000\n1002 1001\n'))
      ps.emit('close', 0)
      await vi.advanceTimersByTimeAsync(3_250)

      await expect(pending).resolves.toEqual({ reaped: true })
      expect(killSpy).toHaveBeenCalledWith(1000, 'SIGKILL')
      expect(killSpy).toHaveBeenCalledWith(1001, 'SIGKILL')
      expect(killSpy).toHaveBeenCalledWith(1002, 'SIGKILL')
    }
  )

  it('still reports a non-clean teardown when a descendant never exits within the grace', async () => {
    vi.useFakeTimers()
    setPlatform('linux')
    const ps = psSnapshots('1000 1\n1001 1000\n')

    // The descendant never dies: signal 0 always succeeds.
    const killSpy = vi.spyOn(process, 'kill').mockImplementation(() => true)
    const child = new FakeChild(1000)
    const settled = vi.fn()
    const pending = terminateProcessTree(child as never).then(settled)

    ps.stdout.emit('data', Buffer.from('1000 1\n1001 1000\n'))
    ps.emit('close', 0)
    await Promise.resolve()
    await Promise.resolve()
    child.emit('exit', 0, null) // parent exits first
    await vi.advanceTimersByTimeAsync(12_000)
    expect(settled).toHaveBeenCalledExactlyOnceWith({ reaped: false })
    await pending

    expect(killSpy).toHaveBeenCalledWith(1001, 'SIGKILL')
    expect(settled).toHaveBeenCalledExactlyOnceWith({ reaped: false })
  })

  it('reports reaped without escalation when the child and descendants exit on the graceful signal', async () => {
    setPlatform('linux')
    const ps = psSnapshots('1000 1\n1001 1000\n1002 1001\n')

    // Descendants accept the graceful signal; the liveness probe (signal 0)
    // then reports them gone.
    const killSpy = vi.spyOn(process, 'kill').mockImplementation((_pid, sig) => {
      if (sig === 0) throw esrch()
      return true
    })
    const child = new FakeChild(1000)

    const pending = terminateProcessTree(child as never, 'SIGTERM')
    ps.stdout.emit('data', Buffer.from('1000 1\n1001 1000\n1002 1001\n'))
    ps.emit('close', 0)
    await Promise.resolve()
    await Promise.resolve()
    child.emit('exit', 0, null)

    await expect(pending).resolves.toEqual({ reaped: true })
    expect(killSpy).not.toHaveBeenCalledWith(expect.any(Number), 'SIGKILL')
  })

  it('keeps the Windows taskkill path reporting reaped on a clean taskkill exit', async () => {
    setPlatform('win32')
    const killer = new EventEmitter()
    spawnMock.mockReturnValueOnce(killer)
    const child = new FakeChild(4321)

    const pending = terminateProcessTree(child as never)
    expect(spawnMock).toHaveBeenCalledWith(
      'taskkill',
      ['/pid', '4321', '/T', '/F'],
      expect.objectContaining({ windowsHide: true })
    )
    killer.emit('exit', 0, null)

    await expect(pending).resolves.toEqual({ reaped: true })
    expect(child.kill).not.toHaveBeenCalled()
  })

  it('keeps the owned/detached process-group path reporting reaped when its members exit', async () => {
    vi.useFakeTimers()
    setPlatform('linux')
    let groupAlive = true
    let detachedDescendantAlive = true
    const ps = psSnapshots('1000 1\n1001 1000\n', () => groupAlive ? '1000 S\n' : '1000 Z\n')
    const killSpy = vi.spyOn(process, 'kill').mockImplementation((pid, signal) => {
      if (pid === -1000) {
        if (signal === 0 && !groupAlive) throw esrch()
        if (signal === 'SIGKILL') groupAlive = false
        return true
      }
      expect(pid).toBe(1001)
      if (signal === 0 && !detachedDescendantAlive) throw esrch()
      if (signal === 'SIGKILL') detachedDescendantAlive = false
      return true
    })
    const child = new FakeChild(1000)
    registerOwnedPosixProcessGroup(child as never)

    const pending = terminateProcessTree(child as never)
    ps.stdout.emit('data', Buffer.from('1000 1\n1001 1000\n'))
    ps.emit('close', 0)
    await Promise.resolve()
    await Promise.resolve()
    await vi.advanceTimersByTimeAsync(7_000)

    await expect(pending).resolves.toEqual({ reaped: true })
    expect(killSpy).toHaveBeenCalledWith(-1000, 'SIGKILL')
    expect(killSpy).toHaveBeenCalledWith(1001, 'SIGKILL')
  })
})
