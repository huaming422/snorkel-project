#!/usr/bin/env bash
# Environment bootstrap for the verifier. Sourced (not exec'd) so env vars set
# here stay live for the verifier subprocess. Dependencies are installed in the
# image at the base commit (npm ci in the Dockerfile). This script checks the
# verifier's prerequisites.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/open-science}"
export REPO_DIR
cd "$REPO_DIR"

# js.py reads verify.toml via tomllib (Python 3.11+). The verifier Python
# (/opt/tooling/venv, Python 3.12) ships tomllib in the standard library, so no
# TOML parser needs installing here — the runner uses VERIFIER_PYTHON.

# vitest must be resolvable from the repo root for the native verifier runner.
# It is installed by `npm ci` in the image build; a miss means a corrupted
# node_modules. Reinstall offline from the warm npm cache rather than failing
# later with a confusing "command not found".
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/." \
         "The image build is corrupt — re-running npm ci from the warm cache." >&2
    npm ci --prefer-offline --no-audit --fund=false
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
