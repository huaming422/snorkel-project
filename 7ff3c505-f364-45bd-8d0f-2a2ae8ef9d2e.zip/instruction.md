## Task

We've had a few macOS and Linux quits cancel a pending update because the app
says the backend did not shut down cleanly. In those cases its processes are
already gone. It is intermittent, seems to depend on timing and load, and used
to work reliably. Please track down why a clean stop is sometimes reported as
degraded and fix it. Keep the confirmation bounded so quitting cannot hang.
