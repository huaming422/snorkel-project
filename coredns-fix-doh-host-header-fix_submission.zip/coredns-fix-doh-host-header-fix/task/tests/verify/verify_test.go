// Behavioral checks for DNS-over-HTTPS (https://) upstream forwarding.
//
// All three tests drive the forward plugin through pre-existing, stable
// public entry points only:
//   - parseForward on a caddy controller (config -> plugin),
//   - (*Forward).ServeDNS (a query travels through the whole plugin),
//   - (*Proxy).GetHealthchecker().Check (the periodic upstream probe).
// None of them names or imports any helper, field, or setter that a given
// implementation might introduce; the behavior is observed purely from what
// the upstream HTTPS server receives on the wire. Any implementation that
// makes the outbound request present the configured TLS server name as its
// HTTP host value satisfies these checks, regardless of how it threads that
// value internally.
//
// The test package is `forward` (matching the existing forward tests) so the
// controller-based construction path used by the real server is exercised.

package forward

import (
	"context"
	"crypto/tls"
	"net"
	"net/http"
	"net/http/httptest"
	"sync"
	"testing"

	"github.com/coredns/caddy"
	"github.com/coredns/coredns/plugin/pkg/dnstest"
	"github.com/coredns/coredns/plugin/pkg/doh"
	"github.com/coredns/coredns/plugin/test"

	"github.com/miekg/dns"
)

// recordingDoHServer starts a TLS DoH endpoint that answers every query and
// records the HTTP host value of the most recent request it received. It
// deliberately answers regardless of what host the client presented, which is
// exactly how a permissive public resolver behaves: observing the recorded
// host is the only way to tell what the client actually sent.
func recordingDoHServer(t *testing.T) (srv *httptest.Server, lastHost func() string) {
	t.Helper()

	var mu sync.Mutex
	var seen string

	s := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		seen = r.Host
		mu.Unlock()

		msg, err := doh.RequestToMsg(r)
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}

		ret := new(dns.Msg)
		reply := ret.SetReply(msg)
		if len(msg.Question) > 0 && msg.Question[0].Qtype == dns.TypeA {
			reply.Answer = append(reply.Answer, test.A(msg.Question[0].Name+" IN A 127.0.0.1"))
		}

		buf, err := reply.Pack()
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		w.Header().Set("Content-Type", doh.MimeType)
		w.Write(buf)
	}))

	return s, func() string {
		mu.Lock()
		defer mu.Unlock()
		return seen
	}
}

// hostComponent returns the host portion of an HTTP host value, discarding an
// optional trailing ":port". RFC 7230 allows the host value to carry the
// authority's port, so an upstream reached on a non-default port legitimately
// sees "name:port"; against a real 443 upstream the same implementation sends
// the bare name. Comparing on the host component alone accepts both forms while
// still rejecting an IP literal or an empty host.
func hostComponent(h string) string {
	if host, _, err := net.SplitHostPort(h); err == nil {
		return host
	}
	return h
}

// TestDoHAuthorityUsesServerName drives a real query end-to-end through the
// plugin and asserts that the outbound DoH request presents the configured
// TLS server name (not the upstream IP:port derived from the URL) as its HTTP
// host value. This is the headline behavior: the server name must flow from
// the stanza all the way into request construction. An implementation that
// plumbs the value through the lower layers but never populates it when the
// upstream proxy is wired up still sends the IP:port here and fails.
func TestDoHAuthorityUsesServerName(t *testing.T) {
	const serverName = "dns.example.net"

	s, lastHost := recordingDoHServer(t)
	defer s.Close()

	c := caddy.NewTestController("dns", "forward . "+s.URL+" {\n\ttls_servername "+serverName+"\n}")
	fs, err := parseForward(c)
	if err != nil {
		t.Fatalf("Failed to create forwarder: %s", err)
	}
	f := fs[0]
	// Trust the test server's certificate by reusing its client, exactly as
	// the existing HTTPS forward test does. This keeps the handshake valid so
	// the check is about the HTTP host value, not TLS.
	f.proxies[0].SetHTTPClient(s.Client())
	f.OnStartup()
	defer f.OnShutdown()

	m := new(dns.Msg)
	m.SetQuestion("example.org.", dns.TypeA)
	rec := dnstest.NewRecorder(&test.ResponseWriter{})

	if _, err := f.ServeDNS(context.TODO(), rec, m); err != nil {
		t.Fatalf("Expected to receive reply, but didn't: %v", err)
	}
	if rec.Msg == nil || len(rec.Msg.Answer) == 0 {
		t.Fatalf("Expected an answer in the reply, got %v", rec.Msg)
	}

	if got := hostComponent(lastHost()); got != serverName {
		t.Fatalf("outbound DoH request presented host %q, want the configured server name %q", lastHost(), serverName)
	}
}

// TestDoHHealthAuthority exercises the upstream health probe (a distinct code
// path from the query path) and asserts it, too, presents the configured TLS
// server name as the outbound request's HTTP host value. Both paths must carry
// the server name; a fix that only covers the query path fails here.
func TestDoHHealthAuthority(t *testing.T) {
	const serverName = "dns.example.net"

	s, lastHost := recordingDoHServer(t)
	defer s.Close()

	c := caddy.NewTestController("dns", "forward . "+s.URL+" {\n\ttls_servername "+serverName+"\n}")
	fs, err := parseForward(c)
	if err != nil {
		t.Fatalf("Failed to create forwarder: %s", err)
	}
	f := fs[0]

	// Let the health probe reach the test server: skip certificate verification
	// (the httptest cert is self-signed for 127.0.0.1, not for dns.example.net)
	// while preserving ServerName so implementations that derive the outbound HTTP
	// host value from tls.Config.ServerName see "dns.example.net" exactly as they
	// would in production. Implementations that thread the host through a separate
	// field are equally admitted — the check is on the observed r.Host, not on how
	// each design carries the value internally.
	hc := f.proxies[0].GetHealthchecker()
	hc.SetTLSConfig(&tls.Config{ //nolint:gosec // test-only: self-signed cert
		InsecureSkipVerify: true,
		ServerName:         serverName,
	})

	if err := hc.Check(f.proxies[0]); err != nil {
		t.Fatalf("health probe failed: %v", err)
	}

	if got := hostComponent(lastHost()); got != serverName {
		t.Fatalf("health probe presented host %q, want the configured server name %q", lastHost(), serverName)
	}
}

// TestDoHForwardingStillAnswers guards the existing success path: against a
// permissive upstream that ignores the HTTP host value, a normal query must
// still round-trip and return the expected answer. This continues to hold both
// before and after the server-name change, and catches a regression that would
// break ordinary DoH forwarding.
func TestDoHForwardingStillAnswers(t *testing.T) {
	s, _ := recordingDoHServer(t)
	defer s.Close()

	c := caddy.NewTestController("dns", "forward . "+s.URL)
	fs, err := parseForward(c)
	if err != nil {
		t.Fatalf("Failed to create forwarder: %s", err)
	}
	f := fs[0]
	f.proxies[0].SetHTTPClient(s.Client())
	f.OnStartup()
	defer f.OnShutdown()

	m := new(dns.Msg)
	m.SetQuestion("example.org.", dns.TypeA)
	rec := dnstest.NewRecorder(&test.ResponseWriter{})

	if _, err := f.ServeDNS(context.TODO(), rec, m); err != nil {
		t.Fatalf("Expected to receive reply, but didn't: %v", err)
	}
	if rec.Msg == nil || len(rec.Msg.Answer) == 0 {
		t.Fatalf("Expected an answer in the reply, got %v", rec.Msg)
	}
	if x := rec.Msg.Answer[0].Header().Name; x != "example.org." {
		t.Fatalf("Expected answer for %q, got %q", "example.org.", x)
	}
}
