## Task

we run dbt commands from inside Prefect tasks using the dbt integration, wrapped with a timeout plus automatic retries so a slow run gets retried.

the problem: when a dbt command runs long enough to hit the task timeout, Prefect marks the task timed out and failed, but the dbt work underneath doesn't stop. it keeps running in the background, so when the task retries a second dbt invocation starts while the first is still going. the two overlap: duplicated and conflicting work, warehouse lock contention, runs that look hung. some that hit the timeout never finish failing at all, and just hang instead of reaching their timed-out state.

dig into why timing out or cancelling a dbt command through the integration doesn't stop the in-progress work, and fix it so the work stops before the task resolves. a retry should never overlap a still-running attempt, and a cancelled run should resolve cleanly, not hang.

keep the fix in the integration's command-execution path, not Prefect's core machinery. successful and ordinary-failure runs stay as today; only the timeout/cancellation path changes.
