#!/usr/bin/env bash
# test-setup.sh — runs once before the verifier (sourced, not exec'd).
# The dependency closure for the prefect-dbt integration (editable install with
# `.[all_extras]`, pytest stack, respx, fastapi, build backends) is already baked
# into the integration's `.venv` in the image, so this is an offline no-op in the
# agent/verifier phases. The integration tests use the ephemeral in-process Prefect
# test harness (SQLite) — no standalone server, no credentials, no network.
set -euo pipefail

REPO_DIR=/repo/prefect
INTEGRATION_DIR="${REPO_DIR}/src/integrations/prefect-dbt"

# Force uv to stay offline: the agent phase is no-network, and the baked cache +
# .venv already satisfy every import the focused tests need. Set it HERE, never as
# an image ENV (an image-wide UV_OFFLINE breaks harbor's `uv tool install` during
# trial prep).
export UV_OFFLINE=1
export UV_CACHE_DIR=/opt/uv-cache

cd "$INTEGRATION_DIR"

# The integration's `.venv` is baked in the image with the full offline dependency
# closure (editable `.[all_extras]` + the `dev` group's test runner + fastapi). The
# install is EDITABLE, so any source edits the agent made under the integration are
# already reflected — no reinstall is needed, and the agent phase is offline anyway.
# Fail loudly if the baked venv is missing rather than trying to rebuild it offline.
if [ ! -d .venv ]; then
    echo "[test-setup] FATAL: baked integration .venv is missing at ${INTEGRATION_DIR}/.venv" >&2
    return 1 2>/dev/null || exit 1
fi

# Smoke-import the modules the task touches to fail fast on a broken environment.
.venv/bin/python - <<'PY'
import prefect
import prefect_dbt
import prefect_dbt.core.runner
import prefect_dbt.core._executor
import prefect_dbt.core._tracker
from prefect._internal.concurrency.cancellation import CancelledError, shield  # noqa: F401
from dbt.adapters.factory import FACTORY  # noqa: F401
from dbt.cli.main import dbtRunner  # noqa: F401
print("prefect-dbt env OK")
PY

export REPO_NAME=prefect
