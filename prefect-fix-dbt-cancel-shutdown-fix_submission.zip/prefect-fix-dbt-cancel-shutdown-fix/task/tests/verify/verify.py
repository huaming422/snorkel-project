"""Behavioral verifier for prefect-fix-dbt-cancel-shutdown.

Every check exercises the dbt integration through its pre-existing public
surface only:

  * ``PrefectDbtRunner().invoke([...])`` — the top-level command entry point.
  * ``NodeTaskTracker`` — the per-node waiter machinery
    (``start_task`` / ``wait_for_node_completion`` / ``get_node_status`` /
    ``set_node_status``), all present before this change.
  * ``prefect.task(timeout_seconds=...)`` — a real Prefect timeout driving a
    ``TimedOut`` state.
  * ``prefect._internal.concurrency.cancellation.CancelledError`` — the
    ``BaseException`` Prefect delivers on timeout/cancellation, constructed
    directly and also returned inside a mocked dbt result.

The command runner is always driven with a mocked ``dbtRunner`` so no real
dbt project, warehouse, or credentials are needed. No implementation-internal
helper, module, or attribute introduced by a solution is referenced — the
behaviour is observed, not the mechanism, so any correct approach passes.
"""

from __future__ import annotations

import contextlib
import threading
import time
from unittest.mock import Mock, patch

import pytest

from prefect import task
from prefect._internal.concurrency.cancellation import CancelledError
from prefect.settings import (
    PREFECT_API_SERVICES_TRIGGERS_ENABLED,
    temporary_settings,
)
from prefect.states import StateType
from prefect.testing.utilities import prefect_test_harness

from prefect_dbt.core.runner import FAILURE_STATUSES, PrefectDbtRunner
from prefect_dbt.core.settings import PrefectDbtSettings
from prefect_dbt.core._tracker import NodeTaskTracker


# ---------------------------------------------------------------------------
# Test harness / fixtures
# ---------------------------------------------------------------------------
# The command runner constructs a Prefect client and (for the timeout check)
# runs a real Prefect task, both of which need the ephemeral in-process
# server. Stand it up once for the whole module. This mirrors the integration
# suite's own session-scoped harness; the verifier runs standalone so it
# provides the harness itself rather than relying on the suite's conftest.
@pytest.fixture(scope="session", autouse=True)
def _prefect_server():
    with temporary_settings({PREFECT_API_SERVICES_TRIGGERS_ENABLED: False}):
        with prefect_test_harness(server_startup_timeout=60):
            yield


@pytest.fixture
def mock_dbt_runner_class():
    """Patch the dbt runner the command path instantiates.

    The returned class mock's ``.return_value.invoke`` is where each test
    installs the dbt result (or blocking behaviour) it wants to observe.
    """
    with patch("prefect_dbt.core.runner.dbtRunner") as mock_class:
        mock_class.return_value = Mock()
        yield mock_class


@pytest.fixture
def mock_settings_context_manager():
    """Mock the profiles-dir resolution so no profiles.yml is required."""
    with patch.object(PrefectDbtSettings, "resolve_profiles_yml") as mock_cm:
        mock_cm.return_value.__enter__.return_value = "/profiles/dir"
        yield mock_cm


# ---------------------------------------------------------------------------
# Criterion 1 — a cancellation encoded in the dbt result propagates unchanged.
# ---------------------------------------------------------------------------
def test_returned_cancellation_propagates_unchanged(
    mock_dbt_runner_class, mock_settings_context_manager
):
    """dbt reports an interrupted run by returning an unsuccessful result whose
    ``exception`` is a ``BaseException`` that is not an ``Exception`` (here,
    Prefect's ``CancelledError``).

    That exact exception must come back out of the top-level command entry
    point — not be swallowed or re-wrapped in another error type — so the
    surrounding Prefect task actually sees the cancellation.
    """
    error = CancelledError()
    mock_dbt_runner_class.return_value.invoke.return_value = Mock(
        success=False, exception=error
    )

    with pytest.raises(CancelledError) as raised:
        PrefectDbtRunner().invoke(["run"])

    assert raised.value is error


# ---------------------------------------------------------------------------
# Criterion 3 — node waiters are woken and errored when dbt is cancelled.
# ---------------------------------------------------------------------------
def test_returned_cancellation_wakes_and_errors_incomplete_nodes(
    mock_dbt_runner_class, mock_settings_context_manager
):
    """A node task started from a ``NodeStart`` blocks waiting for the matching
    finished event. When dbt is cancelled that event never arrives on its own,
    so the command path must wake every still-pending node waiter and mark the
    node errored — otherwise the waiter (and the task run behind it) hangs.

    Observed purely through the public tracker interface: the waiter unblocks,
    and the node's recorded status becomes ``error``.
    """
    tracker = NodeTaskTracker()
    tracker.start_task("model.a", Mock())

    woke = threading.Event()

    def _wait_for_node():
        # Pre-existing waiter entry point; blocks until the node's event fires.
        tracker.wait_for_node_completion("model.a")
        woke.set()

    waiter = threading.Thread(target=_wait_for_node, daemon=True)
    waiter.start()

    error = CancelledError()
    mock_dbt_runner_class.return_value.invoke.return_value = Mock(
        success=False, exception=error
    )

    try:
        # The command path builds its own tracker; hand it the one whose node
        # waiter we are observing.
        with patch(
            "prefect_dbt.core.runner.NodeTaskTracker", return_value=tracker
        ):
            with pytest.raises(CancelledError) as raised:
                PrefectDbtRunner().invoke(["run"])

        assert raised.value is error
        assert woke.wait(2), "node waiter was never woken after cancellation"

        # The woken node must land in a failure status (details: waiters are
        # "woken and failed"). Accept any of the integration's pre-existing
        # failure statuses rather than pinning one specific value, so a solution
        # that fails the node with a different dbt failure status still passes.
        status = tracker.get_node_status("model.a")
        assert status is not None, "node status was never recorded"
        node_status = status["event_data"]["node_info"]["node_status"]
        assert node_status in FAILURE_STATUSES, (
            f"expected a failure status after cancellation, got {node_status!r}"
        )
    finally:
        # Release the waiter if it is still blocked (e.g. the behaviour under
        # test was absent), using the pre-existing status setter.
        tracker.set_node_status(
            "model.a", {"node_info": {"node_status": "error"}}, "verify cleanup"
        )
        waiter.join(5)


# ---------------------------------------------------------------------------
# Criterion 2 — a task timeout stops dbt before the task resolves, and runner
# state is reset only after the dbt work has finished.
# ---------------------------------------------------------------------------
def test_task_timeout_stops_dbt_and_resets_runner_state(
    mock_dbt_runner_class, mock_settings_context_manager
):
    """Wrap a blocking dbt command in a ``@task(timeout_seconds=...)``.

    When the timeout fires the task must resolve ``TimedOut`` *and* the dbt
    work underneath must actually have unwound (its blocking call returned, so
    its ``finally`` ran) before the state resolves. A pre-fix runner marks the
    task timed out while its dbt worker keeps running in the background, so a
    retry overlaps a still-running attempt.

    The fix isolates the dbt call to a dedicated worker thread so that
    Prefect's ``KeyboardInterrupt`` (injected into the *task* thread) can be
    caught there while the worker is independently interrupted and joined.  This
    check verifies that isolation is actually in place: the mocked dbt callable
    records the thread it was called from, and after the ``TimedOut`` state
    resolves that thread must be different from the Prefect task thread.
    Without the isolation a lazy solution running the whole call chain in the
    task thread also passes the ``invoke_finished`` assertion (Prefect's KI
    fires directly in the mock's ``finally``), yet such a solution leaves queued
    dbt nodes still dispatching so a retry overlaps a still-running attempt.

    Any interruption primitive (ctypes KI injection, cooperative flag, executor
    future) satisfies this check as long as the dbt callable is isolated to a
    worker thread — the specific mechanism is not asserted.
    """
    from dbt.adapters.factory import FACTORY

    invoke_finished = threading.Event()
    dbt_invoke_thread_id: list[int] = []

    def _blocking_invoke(args):
        # Record which thread is calling us so we can verify it is NOT the
        # Prefect task thread (i.e. the fix really isolated dbt to a worker).
        dbt_invoke_thread_id.append(threading.current_thread().ident)
        try:
            while True:
                time.sleep(0.01)
        except (KeyboardInterrupt, BaseException) as exc:
            return Mock(success=False, exception=exc)
        finally:
            invoke_finished.set()

    mock_dbt_runner_class.return_value.invoke.side_effect = _blocking_invoke

    runner = PrefectDbtRunner()

    task_thread_id: list[int] = []

    @task(timeout_seconds=0.5)
    def run_dbt():
        task_thread_id.append(threading.current_thread().ident)
        runner.invoke(["run"])

    with (
        patch.object(runner, "_build_dbt_hook_selection_cache", return_value={}),
        patch.dict(FACTORY.adapters, {}, clear=True),
    ):
        state = run_dbt(return_state=True)

    assert state.name == "TimedOut"
    assert state.type == StateType.FAILED
    # The dbt work actually unwound (blocking call returned) before resolving.
    assert invoke_finished.is_set(), "dbt work did not stop before the task resolved"
    # The dbt callable must have run in a dedicated worker thread, not in the
    # Prefect task thread.  On a pre-fix or lazy synchronous runner Prefect's KI
    # fires directly in the task thread, which also happens to be running the
    # mock — so the mock's ``finally`` fires trivially.  The fix *isolates* dbt
    # to a worker thread and actively interrupts it, which is the only way to
    # stop real dbt (whose blocking network calls are not interrupted by a KI
    # delivered to a different thread).
    assert dbt_invoke_thread_id, "dbt invoke was never called"
    assert task_thread_id, "task thread id was never captured"
    assert dbt_invoke_thread_id[0] != task_thread_id[0], (
        "dbt was called from the Prefect task thread — the fix must isolate "
        "the dbt call to a dedicated worker thread so it can be actively "
        "interrupted without aborting the task thread's cancellation handler"
    )


# ---------------------------------------------------------------------------
# Criterion 4 — on cancellation the integration cancels open connections on the
# registered dbt adapters itself, instead of relying on dbt's own cleanup (which
# only runs for KeyboardInterrupt/SystemExit and never for a Prefect-delivered
# BaseException). Stopping the worker thread alone leaves an in-flight warehouse
# query running until its connection is cancelled.
# ---------------------------------------------------------------------------
def test_cancellation_cancels_open_adapter_connections(
    mock_dbt_runner_class, mock_settings_context_manager
):
    """A blocking dbt command is wrapped in a ``@task(timeout_seconds=...)``.

    When the timeout fires, interrupting the dbt worker is not enough: an
    in-flight warehouse query is blocked inside the database driver and keeps
    running on the warehouse until its connection is cancelled. dbt cancels
    those connections only for ``KeyboardInterrupt``/``SystemExit``/
    ``FailFastError`` — never for the ``BaseException`` Prefect delivers on
    timeout — so the integration must drive the connection cancellation itself
    against the registered dbt adapters.

    Observed through dbt's own public adapter registry
    (``dbt.adapters.factory.FACTORY``): a registered, cancelable adapter's
    connection-cancel entry point must be invoked. Any interruption primitive
    and any adapter-iteration approach counts — only the fact that open
    connections are cancelled is asserted, so the cooperative-flag and
    executor-level alternatives still pass. A fix that interrupts the worker
    thread but leaves in-flight warehouse queries running fails here.
    """
    from dbt.adapters.factory import FACTORY

    cancelled = threading.Event()

    class _FakeConnectionManager:
        def cancel_open(self):
            # Lower-level entry point adapters delegate to; some solutions call
            # it directly rather than the adapter-level wrapper.
            cancelled.set()
            return []

    class _FakeAdapter:
        """Registered, cancelable dbt adapter stand-in.

        Records a connection cancel via either the adapter-level
        ``cancel_open_connections`` (dbt-core's ``_cancel_connections`` path) or
        the connection-manager-level ``cancel_open`` it delegates to.
        """

        def __init__(self):
            self.connections = _FakeConnectionManager()

        @staticmethod
        def type():
            return "fake"

        @staticmethod
        def is_cancelable():
            return True

        @contextlib.contextmanager
        def connection_named(self, name, *args, **kwargs):
            yield

        def cancel_open_connections(self):
            cancelled.set()
            return []

    def _blocking_invoke(args):
        # Block until interrupted, then unwind like dbt's worker would. The
        # assertion below does not depend on any particular interruption
        # primitive — only that connections were cancelled.
        try:
            while True:
                time.sleep(0.01)
        except BaseException as exc:  # noqa: BLE001 - mirror dbt worker teardown
            return Mock(success=False, exception=exc)

    mock_dbt_runner_class.return_value.invoke.side_effect = _blocking_invoke

    runner = PrefectDbtRunner()

    @task(timeout_seconds=0.5)
    def run_dbt():
        runner.invoke(["run"])

    with (
        patch.object(runner, "_build_dbt_hook_selection_cache", return_value={}),
        patch.dict(FACTORY.adapters, {"fake": _FakeAdapter()}, clear=True),
    ):
        state = run_dbt(return_state=True)

    assert state.name == "TimedOut"
    assert cancelled.wait(5), (
        "open connections on the registered dbt adapter were never cancelled "
        "after the Prefect timeout — in-flight warehouse work would keep running"
    )


# ---------------------------------------------------------------------------
# Criterion 6 (pass-to-pass) — the happy path and ordinary-failure path are
# unchanged.
# ---------------------------------------------------------------------------
def test_successful_run_returns_result(
    mock_dbt_runner_class, mock_settings_context_manager
):
    """A successful dbt result is returned from the command entry point as-is."""
    result = Mock(success=True, exception=None)
    mock_dbt_runner_class.return_value.invoke.return_value = result

    returned = PrefectDbtRunner().invoke(["run"])

    assert returned is result


def test_ordinary_failure_still_raises_valueerror(
    mock_dbt_runner_class, mock_settings_context_manager
):
    """An ordinary dbt failure — an unsuccessful result whose ``exception`` is a
    regular ``Exception`` — still surfaces as the existing ``ValueError`` with
    the failing command in its message, exactly as before.
    """
    mock_dbt_runner_class.return_value.invoke.return_value = Mock(
        success=False, exception=RuntimeError("boom")
    )

    with pytest.raises(ValueError) as raised:
        PrefectDbtRunner().invoke(["run"])

    assert "run" in str(raised.value)
