## Task

Some of our calculated columns give the wrong numbers when a chart uses them as the series dimension with a series limit.
One of them is `state = 'CA' OR state = 'NY'`.
With a limit of 1 the chart has a group in it that isn't the top one, and with a higher limit some rows are counted twice.
Same thing happens with columns built from AND conditions.
We see it with "Group remaining as Others" turned on too, and on our Pinot datasets.
A couple of the affected columns end in a SQL comment, like `-- coasts`, and series charts on those come out wrong as well.
Raw-records tables on them are fine today and should stay that way.
Plain physical columns are fine as the series dimension.
