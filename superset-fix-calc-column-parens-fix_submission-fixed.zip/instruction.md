## Task

Charts that use one of our calculated columns as the series dimension, with a series limit set, show the wrong numbers.
It happens on our Pinot datasets too.
If we build the same chart with a regular table column as the dimension, it looks fine.
