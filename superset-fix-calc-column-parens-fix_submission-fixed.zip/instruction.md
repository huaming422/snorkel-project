## Task

Charts show wrong numbers when a calculated column is the series dimension and a series limit is set.
The first one people noticed is `state = 'CA' OR state = 'NY'`.
At a limit of 1 a second group shows up next to the top one, and at a higher limit some rows get counted twice.
Columns that AND two conditions together are broken too, but there rows drop out of the groups instead.
Turning on "Group remaining as Others" doesn't help, and our Pinot datasets give the same bad results.
A few of these expressions also carry a short note at the end, for example `state = 'CA' OR state = 'NY' -- coasts`.
Series charts on those columns are wrong as well.
A raw-records table that shows those columns works right now, and it has to keep working.
A plain physical column as the series dimension gives correct results.
