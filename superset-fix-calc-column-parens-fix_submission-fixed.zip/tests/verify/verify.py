"""Behavioral checks for calculated-column SQL in Superset dataset queries.

A calculated (expression) dataset column is defined by a SQL expression
instead of a physical table column. These checks build queries through the
dataset query builder (``SqlaTable.get_sqla_query``), run the generated SQL
against an in-memory SQLite table with known rows, and compare the returned
groups and counts with what the expression really evaluates to.

Seeded rows in table ``t``: TX x5, WA x1, CA x2, NY x1. Every calculated
column below is true for the CA and NY rows only, so each one has 6 rows where
it is false (0) and 3 where it is true (1).

Only result rows are compared, never SQL text.

The file is self-contained: it rebuilds a minimal application context, an
in-memory SQLite session and a ``database`` fixture, so it can be collected
from outside the repo test tree. It runs under the project interpreter (see
verify.toml) because it imports Superset source.
"""

from __future__ import annotations

import importlib
import os
from contextlib import contextmanager
from typing import Any, Iterator

import pytest
from pytest_mock import MockerFixture
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm.session import Session
from sqlalchemy.pool import StaticPool

# The column from the bug report.
CALC_EXPR = "state = 'CA' OR state = 'NY'"

# (expression, declared type) for each calculated column variant. All of them
# select the same rows, so they share CALC_COUNTS.
CALC_COLUMNS = {
    "or_boolean": (CALC_EXPR, "BOOLEAN"),
    "or_untyped": (CALC_EXPR, None),
    "and_untyped": ("state <> 'TX' AND state <> 'WA'", None),
}

SEED_ROWS = [("TX", 1)] * 5 + [("WA", 1)] + [("CA", 1)] * 2 + [("NY", 1)]

# Expected counts per value of the calculated column (0 = false, 1 = true).
CALC_COUNTS = {0: 6, 1: 3}

# A chart can send the saved calculated column by name or as an adhoc column
# reference (the form-data shape used when a saved column is dropped into a
# dimension control).
CALC_DIMENSIONS = {
    "by_name": "is_ca_or_ny",
    "by_reference": {
        "label": "is_ca_or_ny",
        "sqlExpression": "is_ca_or_ny",
        "isColumnReference": True,
    },
}


# --------------------------------------------------------------------------- #
# Application context + in-memory SQLite session (mirrors the repo conftest).
# --------------------------------------------------------------------------- #
@pytest.fixture(scope="module")
def app() -> Iterator[Any]:
    from superset.app import SupersetApp
    from superset.extensions import appbuilder
    from superset.initialization import SupersetAppInitializer

    flask_app = SupersetApp(__name__)
    flask_app.config.from_object("superset.config")
    flask_app.config["SQLALCHEMY_DATABASE_URI"] = (
        os.environ.get("SUPERSET__SQLALCHEMY_DATABASE_URI") or "sqlite://"
    )
    flask_app.config["WTF_CSRF_ENABLED"] = False
    flask_app.config["PREVENT_UNSAFE_DB_CONNECTIONS"] = False
    flask_app.config["TESTING"] = True
    flask_app.config["RATELIMIT_ENABLED"] = False
    flask_app.config["CACHE_CONFIG"] = {}
    flask_app.config["DATA_CACHE_CONFIG"] = {}
    flask_app.config["SERVER_NAME"] = "example.com"
    flask_app.config["APPLICATION_ROOT"] = "/"
    flask_app.config["PREFERRED_URL_SCHEME"] = "http"

    # ``appbuilder`` is a singleton; clear registered views so a repeat init in
    # the same process does not double-register routes.
    appbuilder.baseviews = []
    SupersetAppInitializer(flask_app).init_app()
    with flask_app.app_context():
        import superset.views.base

        importlib.reload(superset.views.base)

    yield flask_app


@pytest.fixture(autouse=True)
def app_context(app: Any) -> Iterator[None]:
    # Model construction and ``get_sqla_query`` touch app-context-bound config.
    with app.app_context():
        yield


@pytest.fixture
def session(mocker: MockerFixture) -> Session:
    engine = create_engine("sqlite://")
    session_factory = sessionmaker(bind=engine)
    in_memory_session = session_factory()
    in_memory_session.remove = lambda: None  # Flask calls db.session.remove()

    patched = mocker.patch("superset.security.SupersetSecurityManager.session")
    patched.return_value = in_memory_session
    patched.get_bind.return_value = engine
    patched.query = in_memory_session.query
    mocker.patch("superset.db.session", in_memory_session)
    return in_memory_session


@pytest.fixture
def database(mocker: MockerFixture, session: Session) -> Any:
    from superset.connectors.sqla.models import SqlaTable
    from superset.models.core import Database

    SqlaTable.metadata.create_all(session.get_bind())

    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    database = Database(database_name="db", sqlalchemy_uri="sqlite://")

    connection = engine.raw_connection()
    connection.execute("CREATE TABLE t (state TEXT, a INTEGER)")
    connection.executemany("INSERT INTO t VALUES (?, ?)", SEED_ROWS)
    connection.commit()

    @contextmanager
    def mock_get_sqla_engine(catalog=None, schema=None, **kwargs):
        yield engine

    mocker.patch.object(database, "get_sqla_engine", new=mock_get_sqla_engine)
    return database


# --------------------------------------------------------------------------- #
# Helpers.
# --------------------------------------------------------------------------- #
def _table(
    database: Any, expression: str = CALC_EXPR, type_: str | None = "BOOLEAN"
) -> Any:
    """Dataset over ``t`` with a physical ``state`` column, a calculated column
    and a ``count`` metric."""
    from superset.connectors.sqla.models import SqlaTable, SqlMetric, TableColumn

    return SqlaTable(
        database=database,
        schema=None,
        table_name="t",
        columns=[
            TableColumn(column_name="state", type="TEXT"),
            TableColumn(column_name="a", type="INTEGER"),
            TableColumn(
                column_name="is_ca_or_ny",
                expression=expression,
                type=type_,
            ),
        ],
        metrics=[SqlMetric(metric_name="count", expression="COUNT(*)")],
    )


def _without_joins(mocker: MockerFixture, table: Any) -> None:
    """Make the engine spec report no join or subquery support, as Pinot's
    does. Series limits then fetch the top groups in a separate query."""
    spec = table.db_engine_spec
    mocker.patch.object(spec, "allows_joins", False)
    mocker.patch.object(spec, "allows_subqueries", False)


def _run(database: Any, sqla_query: Any) -> tuple[list[tuple[Any, ...]], str]:
    """Compile the built query, run it against the seeded table and return the
    rows plus the SQL text (for failure messages)."""
    with database.get_sqla_engine() as engine:
        sql = str(
            sqla_query.sqla_query.compile(
                dialect=engine.dialect,
                compile_kwargs={"literal_binds": True},
            )
        )
        connection = engine.raw_connection()
        try:
            rows = connection.execute(sql).fetchall()
        except Exception as ex:  # noqa: BLE001
            pytest.fail(f"Generated SQL does not run: {ex}\nSQL: {sql}")
    return [tuple(row) for row in rows], sql


def _counts(rows: list[tuple[Any, ...]]) -> dict[Any, int]:
    """Map the first selected column (the dimension) to the last one (the
    metric). Positional, so the check does not depend on column aliases."""
    counts: dict[Any, int] = {}
    for row in rows:
        key = int(row[0]) if isinstance(row[0], (bool, int)) else row[0]
        counts[key] = counts.get(key, 0) + row[-1]
    return counts


def _series_query(
    table: Any, column: Any, series_limit: int, group_others: bool = False
) -> Any:
    return table.get_sqla_query(
        groupby=[column],
        metrics=["count"],
        series_columns=[column],
        series_limit=series_limit,
        group_others_when_limit_reached=group_others,
        order_desc=True,
        extras={},
        is_timeseries=False,
    )


# --------------------------------------------------------------------------- #
# Checks.
# --------------------------------------------------------------------------- #
def test_physical_column_series_limit_returns_top_groups(database: Any) -> None:
    """A top-N series on a physical column returns the right groups and counts
    (regression guard for physical columns)."""
    rows, sql = _run(database, _series_query(_table(database), "state", 2))

    assert _counts(rows) == {"TX": 5, "CA": 2}, f"rows={rows}\nSQL: {sql}"


@pytest.mark.parametrize("calc", list(CALC_COLUMNS))
@pytest.mark.parametrize("dimension", list(CALC_DIMENSIONS))
@pytest.mark.parametrize(
    ("series_limit", "expected"),
    [(1, {0: 6}), (10, CALC_COUNTS)],
)
def test_calculated_column_series_limit_returns_correct_groups(
    database: Any,
    calc: str,
    dimension: str,
    series_limit: int,
    expected: dict[int, int],
) -> None:
    """A calculated column that combines two conditions, used as a top-N series
    dimension, returns only the selected groups, with each row counted once in
    the group the expression puts it in. Covers OR and AND expressions, with
    and without a declared column type, sent by name or as a column
    reference."""
    expression, type_ = CALC_COLUMNS[calc]
    table = _table(database, expression=expression, type_=type_)
    column = CALC_DIMENSIONS[dimension]
    rows, sql = _run(database, _series_query(table, column, series_limit))

    assert _counts(rows) == expected, f"rows={rows}\nSQL: {sql}"


@pytest.mark.parametrize("calc", list(CALC_COLUMNS))
@pytest.mark.parametrize("dimension", list(CALC_DIMENSIONS))
def test_calculated_column_series_limit_without_joins_returns_correct_groups(
    database: Any, mocker: MockerFixture, calc: str, dimension: str
) -> None:
    """On an engine that cannot join the top-N subquery back, the top groups are
    fetched first and then applied to the main query. The result still holds
    only the selected group with the right count."""
    expression, type_ = CALC_COLUMNS[calc]
    table = _table(database, expression=expression, type_=type_)
    _without_joins(mocker, table)

    rows, sql = _run(database, _series_query(table, CALC_DIMENSIONS[dimension], 1))

    assert _counts(rows) == {0: 6}, f"rows={rows}\nSQL: {sql}"


@pytest.mark.parametrize("joins", [True, False], ids=["joins", "no_joins"])
@pytest.mark.parametrize("dimension", list(CALC_DIMENSIONS))
def test_calculated_column_series_limit_groups_others(
    database: Any, mocker: MockerFixture, joins: bool, dimension: str
) -> None:
    """With "Group remaining as Others" on, a series limit of 1 keeps the top
    group and puts every other row under "Others", on engines with and without
    join support."""
    table = _table(database)
    if not joins:
        _without_joins(mocker, table)

    sqla_query = _series_query(
        table, CALC_DIMENSIONS[dimension], 1, group_others=True
    )
    rows, sql = _run(database, sqla_query)

    assert _counts(rows) == {0: 6, "Others": 3}, f"rows={rows}\nSQL: {sql}"


def test_calculated_column_reference_filter_returns_matching_rows(
    database: Any,
) -> None:
    """A WHERE filter on an adhoc column that references the saved calculated
    column keeps exactly the rows the expression selects."""
    table = _table(database)

    sqla_query = table.get_sqla_query(
        groupby=["state"],
        metrics=["count"],
        filter=[
            {
                "col": {
                    "label": "is_ca_or_ny",
                    "sqlExpression": "is_ca_or_ny",
                    "isColumnReference": True,
                },
                "op": "==",
                "val": 0,
            },
        ],
        extras={},
        is_timeseries=False,
    )
    rows, sql = _run(database, sqla_query)

    assert _counts(rows) == {"TX": 5, "WA": 1}, f"rows={rows}\nSQL: {sql}"


@pytest.mark.parametrize("dimension", list(CALC_DIMENSIONS))
@pytest.mark.parametrize(
    ("series_limit", "expected"),
    [(1, {0: 6}), (10, CALC_COUNTS)],
)
def test_calculated_column_with_trailing_comment_series_limit_returns_correct_groups(
    database: Any, dimension: str, series_limit: int, expected: dict[int, int]
) -> None:
    """A calculated column whose expression ends in a ``--`` comment works as a
    top-N series dimension, sent by name or as a column reference, and gives
    the same groups and counts as the same column without the comment."""
    table = _table(database, expression=f"{CALC_EXPR} -- coasts")
    column = CALC_DIMENSIONS[dimension]
    rows, sql = _run(database, _series_query(table, column, series_limit))

    assert _counts(rows) == expected, f"rows={rows}\nSQL: {sql}"


@pytest.mark.parametrize("dimension", list(CALC_DIMENSIONS))
def test_calculated_column_with_trailing_comment_raw_records_still_run(
    database: Any, dimension: str
) -> None:
    """A raw-records query (no aggregation) on a calculated column whose
    expression ends in a ``--`` comment, sent by name or as a column reference,
    runs and returns the right value for every row."""
    table = _table(database, expression=f"{CALC_EXPR} -- coasts")

    # metrics=None is what the table chart's raw-records mode sends, so there is
    # no GROUP BY and every seeded row comes back.
    sqla_query = table.get_sqla_query(
        columns=["state", CALC_DIMENSIONS[dimension]],
        metrics=None,
        extras={},
        is_timeseries=False,
    )
    rows, sql = _run(database, sqla_query)

    got = sorted((row[0], int(row[-1])) for row in rows)
    expected = sorted(
        (state, int(state in ("CA", "NY"))) for state, _ in SEED_ROWS
    )
    assert got == expected, f"rows={rows}\nSQL: {sql}"
