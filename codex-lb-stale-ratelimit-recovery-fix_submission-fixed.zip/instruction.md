## Task

Paid accounts are staying benched long after upstream has given them their quota back.
Upstream sometimes rolls a quota window over before the reset time we stored when the account hit its 429.
After that, direct requests on the account go through again, and every background usage refresh records the window as reset with quota free.
We still keep the account out of rotation until the old stored deadline passes, which for the weekly window can be several days.
Free accounts already come back early in this situation.
Paid plans never do, whether the block came from the 5h window or the 7d one.

Paid accounts should come back on the next refresh once usage history shows that the window they were benched on has rolled over.
A reset that shows up on some other window proves nothing about this block and shouldn't release the account.
If a different window on the account is still at 100% and hasn't reached its own reset time, keep the account benched, since it would only earn another 429.
Free accounts have to keep recovering the way they do today.
