## Task

The v1-to-v2 migration is causing migrated servers to stop advertising completions. Can we update the codemod to preserve those?

I think just the changes scoped to the codemod should be enough here.

## User stories / requirements

- Optional completable schemas migrate to v2 as `completable(inner, cb).optional()`, with the optional wrapper outside the call, preserving optionality and completions.
- Schemas that already work in v2 stay the same. They do not have action-required markers.
- If a schema can't be safely rewritten, an action-required marker should flag with guidance. The guidance shows the nullable-inside, optional-outside form for nullish.
- Calls that pass schemas by reference shouldn't change. One advisory per file and no code marker.
- Running the full v1 to v2 migration updates both MCP imports and completable nesting in one pass.
