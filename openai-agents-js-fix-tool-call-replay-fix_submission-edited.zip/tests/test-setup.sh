#!/usr/bin/env bash
# Sourced (not exec'd) by tests/test.sh under `set -euo pipefail`, so any
# env vars / background PIDs set here stay live for the verifier subprocess.
#
# The verifier is a self-contained vitest test file. The js runner
# (src/python/ssb_lib/runners/js.py) discovers verify*.test.ts under
# /tests/verify/, copies each into `repo_dir/test_parent`
# (= packages/agents-core/test), then runs
#   npx vitest run <copied-path> --reporter=json --outputFile=<report>
# from `repo_dir/config_dir` (= packages/agents-core).
#
# The repo's root vitest.config.ts defines a per-package project whose
# `resolve.alias` maps every workspace package (@openai/agents-core,
# @openai/agents-realtime, …) to its own `src/` TypeScript. So the verifier
# sees the agent's edits to packages/*/src/*.ts with NO build step and no
# dist/ to regenerate — the aliases resolve straight to source.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/openai-agents-js}"
export REPO_DIR
cd "$REPO_DIR"

# Offline-first: the image baked the full dependency closure at the base
# commit (pnpm store warm under /opt/cache/pnpm + node_modules). Try to
# satisfy everything from that bake; only fall back to the network if the
# bake was stale, and say which path we took. Keep node_modules install
# scripts off (they are irrelevant native postinstalls; tests run against
# TypeScript source via vitest aliases).
export npm_config_offline=true
if pnpm install --offline --frozen-lockfile --ignore-scripts \
        > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] deps satisfied from image bake"
elif pnpm install --frozen-lockfile --ignore-scripts \
        >> /tmp/test-setup-install.log 2>&1; then
    echo "[test-setup] deps installed online (image bake was stale)"
else
    tail -40 /tmp/test-setup-install.log >&2
    exit 1
fi

# No defensive tomli install is needed: the verifier infrastructure
# (run_verify.py + runners/js.py) runs under VERIFIER_PYTHON from the
# canonical /opt/tooling venv (Python 3.12), which reads verify.toml with
# the stdlib `tomllib`. So `runner = "vitest"` is parsed without any extra
# package.

# Sanity check: vitest must be resolvable from the agents-core package. A
# failure here points at a corrupted node_modules — reinstalling now saves a
# confusing "command not found" later.
cd "$REPO_DIR/packages/agents-core"
if ! npx --no-install vitest --version >/dev/null 2>&1; then
    echo "test-setup.sh: vitest not resolvable in packages/agents-core — " \
         "reinstalling workspace deps." >&2
    cd "$REPO_DIR"
    pnpm install --offline --frozen-lockfile --ignore-scripts \
        || pnpm install --frozen-lockfile --ignore-scripts
    cd "$REPO_DIR/packages/agents-core"
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR vitest=$(npx --no-install vitest --version 2>/dev/null || echo unknown)"
