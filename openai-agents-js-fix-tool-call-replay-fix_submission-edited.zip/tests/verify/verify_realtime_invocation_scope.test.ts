import { describe, expect, it, vi } from 'vitest';
import { z } from 'zod';
import { RunToolApprovalItem, tool } from '@openai/agents-core';
import { RealtimeAgent } from '../src/realtimeAgent';
import { RealtimeSession } from '../src/realtimeSession';
import type { TransportToolCallEvent } from '../src/transportLayerEvents';
import logger from '../src/logger';
import { FakeTransport } from './stubs';

// Give the session a bounded window to act on an emitted transport event. The
// unsafe path runs the inherited tool within this window; the safe path never
// does. The reference realtime suite uses a single macrotask for the same
// "did it run" assertions, so this window is comfortably sufficient and the
// result is deterministic either way.
async function settle(ms = 50): Promise<void> {
  await new Promise((resolve) => setTimeout(resolve, ms));
}

// Everything here is observed through the RealtimeSession public surface and
// the fake transport: whether the tool body ran, and whether a function-call
// output was handed back to the transport. Nothing inspects how a solution
// records which invocation an approval belongs to.
describe('realtime approval binding by invocation', () => {
  // An approval is granted for one invocation at a call ID; the transport then
  // delivers a DIFFERENT invocation (changed arguments) reusing that same call
  // ID. The changed invocation must not run on the inherited approval. When the
  // approval is keyed by the call ID alone, the changed call executes and its
  // output is sent back — which this test forbids.
  it('does not run a changed-argument call that reuses an approved realtime call id', async () => {
    const execute = vi.fn(async () => 'executed');
    const approvalTool = tool({
      name: 'realtime_approval_tool',
      description: 'Requires approval before running.',
      parameters: z.object({ value: z.string() }),
      needsApproval: true,
      execute,
    });
    const agent = new RealtimeAgent({
      name: 'RealtimeChangedArgumentsAgent',
      tools: [approvalTool],
    });
    const transport = new FakeTransport();
    const session = new RealtimeSession(agent, { transport });
    // Drain the safe path's re-gate signal so it never surfaces as an
    // unhandled emission; its contents are intentionally not asserted on.
    session.on('error', () => {});
    const errorSpy = vi.spyOn(logger, 'error').mockImplementation(() => {});
    await session.connect({ apiKey: 'test' });

    const approvedCall: TransportToolCallEvent = {
      type: 'function_call',
      name: approvalTool.name,
      callId: 'realtime-reused-arguments',
      arguments: '{"value":"safe"}',
      responseId: 'realtime-reused-arguments-response',
    };
    session.context.approveTool(
      new RunToolApprovalItem(approvedCall as any, agent as any),
    );

    transport.emit('function_call', {
      ...approvedCall,
      arguments: '{"value":"changed"}',
    });
    await settle();

    expect(execute).not.toHaveBeenCalled();
    expect(transport.sendFunctionCallOutputCalls).toHaveLength(0);
    errorSpy.mockRestore();
  });

  // Identity, not just arguments. The reused call ID now points at a different
  // TOOL than the one that was approved. The approval for the first tool must
  // not authorize the second.
  it('does not run a different tool that reuses an approved realtime call id', async () => {
    const firstExecute = vi.fn(async () => 'first');
    const secondExecute = vi.fn(async () => 'second');
    const firstTool = tool({
      name: 'realtime_first_tool',
      description: 'Receives the approval.',
      parameters: z.object({}),
      needsApproval: true,
      execute: firstExecute,
    });
    const secondTool = tool({
      name: 'realtime_second_tool',
      description: 'Must not reuse the approval.',
      parameters: z.object({}),
      needsApproval: true,
      execute: secondExecute,
    });
    const agent = new RealtimeAgent({
      name: 'RealtimeChangedToolAgent',
      tools: [firstTool, secondTool],
    });
    const transport = new FakeTransport();
    const session = new RealtimeSession(agent, { transport });
    session.on('error', () => {});
    const errorSpy = vi.spyOn(logger, 'error').mockImplementation(() => {});
    await session.connect({ apiKey: 'test' });

    const approvedCall: TransportToolCallEvent = {
      type: 'function_call',
      name: firstTool.name,
      callId: 'realtime-reused-tool',
      arguments: '{}',
      responseId: 'realtime-reused-tool-response',
    };
    session.context.approveTool(
      new RunToolApprovalItem(approvedCall as any, agent as any),
    );

    transport.emit('function_call', {
      ...approvedCall,
      name: secondTool.name,
    });
    await settle();

    expect(firstExecute).not.toHaveBeenCalled();
    expect(secondExecute).not.toHaveBeenCalled();
    expect(transport.sendFunctionCallOutputCalls).toHaveLength(0);
    errorSpy.mockRestore();
  });

  // Ownership survives a reconnect. The approval is granted, the session is
  // closed and reconnected, and only then does a changed-argument call reuse the
  // approved ID. The binding between the approval and its original invocation
  // must persist across the reconnect, so the changed call still does not run on
  // it.
  it('keeps approval bound to its invocation across a realtime reconnect', async () => {
    const execute = vi.fn(async () => 'executed');
    const approvalTool = tool({
      name: 'realtime_reconnect_tool',
      description: 'Requires approval that must survive a reconnect.',
      parameters: z.object({ value: z.string() }),
      needsApproval: true,
      execute,
    });
    const agent = new RealtimeAgent({
      name: 'RealtimeReconnectAgent',
      tools: [approvalTool],
    });
    const transport = new FakeTransport();
    const session = new RealtimeSession(agent, { transport });
    session.on('error', () => {});
    const errorSpy = vi.spyOn(logger, 'error').mockImplementation(() => {});
    await session.connect({ apiKey: 'test' });

    const approvedCall: TransportToolCallEvent = {
      type: 'function_call',
      name: approvalTool.name,
      callId: 'realtime-reconnect-call',
      arguments: '{"value":"safe"}',
      responseId: 'realtime-reconnect-response',
    };
    session.context.approveTool(
      new RunToolApprovalItem(approvedCall as any, agent as any),
    );

    session.close();
    await session.connect({ apiKey: 'test' });

    transport.emit('function_call', {
      ...approvedCall,
      arguments: '{"value":"changed"}',
      responseId: 'realtime-reconnect-second-response',
    });
    await settle();

    expect(execute).not.toHaveBeenCalled();
    expect(transport.sendFunctionCallOutputCalls).toHaveLength(0);
    errorSpy.mockRestore();
  });
});
