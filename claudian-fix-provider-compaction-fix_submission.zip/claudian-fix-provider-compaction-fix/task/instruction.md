## Task

testers keep hitting `/compact` behaving differently per provider, and in spots just broken, across Claude, Codex, Grok, OpenCode (older v1 transport and newer v2), and Pi. a bare `/compact` should compact the conversation; `/compact` plus text should compact using that text as the instructions.

the reports:

- on Pi, a bare `/compact` sent while an editor selection is captured or something is pasted in compacts as if that captured text were the instructions. the command needs to be read from what was actually typed, before that context gets folded in.

- reload a conversation from history, send `/compact`, and sometimes nothing happens: it gets swallowed while the reloaded history is still recovering.

- on OpenCode v2, `/compact` runs as an ordinary message instead of the provider's native compaction.

- the "context was compacted here" divider stopped showing in Grok and OpenCode, live and on reload, while a failed or unfinished compaction sometimes leaves one it shouldn't. it should appear exactly when a compaction succeeded.

- recognition is uneven: some providers want an exact lowercase `/compact` and trip over whitespace or case, and literal steering text that merely contains `/compact` gets taken as the command instead of passing through as typed.

find the root causes across the provider execution and history layers and make `/compact` consistent everywhere, dividers included. it's all in the plugin's own code; the CLIs are fine and you shouldn't need to touch build config or dependencies. don't change the on-disk history format any provider already writes; whatever the dividers need should come from what's already stored.
