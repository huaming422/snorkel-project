// @ts-nocheck
import * as fs from 'node:fs/promises';
import * as os from 'node:os';
import * as path from 'node:path';

import { capturedSelectionPrompt, capturedSelections } from '@test/helpers/capturedSelections';
import { createProviderRecoveryTestHarness } from '@test/helpers/features/chat/ProviderRecoveryTestHarness';
import { testDate, testTime } from '@test/helpers/testClock';

import type {
  ProviderExecutionEvent,
  ProviderExecutionRequest,
  ProviderExecutionRun,
  ProviderInteractionPort,
  ProviderSessionConfig,
  ProviderSessionEvent,
} from '@/core/execution';
import {
  isSteerableExecutionSession,
  ProviderExecutionLifecycleRegistry,
} from '@/core/execution';
import type { ChatMessage, Conversation } from '@/core/types';
import { createPiWorkspaceServices } from '@/providers/pi/app/PiWorkspaceServices';
import {
  PiCommandMetadataProbe,
  PiExecutionBackend,
  type PiExecutionKernel,
  type PiExecutionKernelCallbacks,
} from '@/providers/pi/execution';
import { PiConversationHistoryService } from '@/providers/pi/history/PiConversationHistoryService';
import type { PiLaunchSpec } from '@/providers/pi/runtime/PiLaunchSpecBuilder';

class FakeKernel implements PiExecutionKernel {
  readonly requests: Array<{ payload: Record<string, unknown>; type: string }> = [];
  readonly sent: Array<Record<string, unknown>> = [];
  readonly shutdown = jest.fn(async () => undefined);
  readonly start = jest.fn();
  stderr = '';

  constructor(
    readonly launchSpec: PiLaunchSpec,
    private readonly callbacks: PiExecutionKernelCallbacks,
    private readonly responses: Map<string, unknown>,
    private readonly requestHandler?: <T>(
      type: string,
      payload: Record<string, unknown>,
      timeoutMs?: number,
      signal?: AbortSignal,
    ) => Promise<T>,
  ) {}

  emit(event: Record<string, unknown>): void {
    this.callbacks.onEvent(event);
  }

  close(error = new Error('Pi process exited')): void {
    this.callbacks.onClose(error);
  }

  emitExtensionRequest(request: Record<string, unknown>): boolean {
    return this.callbacks.onExtensionRequest(request);
  }

  getStderrSnapshot(): string {
    return this.stderr;
  }

  async request<T>(
    type: string,
    payload: Record<string, unknown> = {},
    timeoutMs?: number,
    signal?: AbortSignal,
  ): Promise<T> {
    this.requests.push({ payload, type });
    if (this.requestHandler) {
      return this.requestHandler<T>(type, payload, timeoutMs, signal);
    }
    return this.responses.get(type) as T;
  }

  send(record: Record<string, unknown>): void {
    this.sent.push(record);
  }
}

function createHost(): any {
  return {
    app: { vault: { adapter: { basePath: '/vault' } } },
    executionLifecycleRegistry: new ProviderExecutionLifecycleRegistry(),
    getResolvedProviderCliPath: jest.fn(async () => '/bin/pi'),
    settings: {
      effortLevel: 'off',
      mediaFolder: 'media',
      model: 'pi:anthropic/claude-sonnet-4',
      providerConfigs: {
        pi: {
          discoveredModels: [{
            encodedId: 'pi:anthropic/claude-sonnet-4',
            id: 'claude-sonnet-4',
            input: ['text', 'image'],
            label: 'Claude Sonnet 4',
            provider: 'anthropic',
            reasoning: true,
            thinkingLevels: ['off', 'high'],
          }],
          enabled: true,
          visibleModels: ['pi:anthropic/claude-sonnet-4'],
        },
      },
      systemPrompt: '',
      userName: '',
    },
  };
}

function createConfig(
  overrides: Partial<ProviderSessionConfig> = {},
): ProviderSessionConfig {
  return {
    interactionPort: createInteractionPort(),
    lifecycle: 'persistent',
    nativePersistence: 'enabled',
    vaultWorkingDirectory: '/vault',
    ...overrides,
  };
}

function createInteractionPort(): ProviderInteractionPort {
  return {
    askUserQuestion: jest.fn(),
    dismissInteraction: jest.fn(),
    requestApproval: jest.fn(),
  };
}

function createRequest(
  overrides: Partial<ProviderExecutionRequest> = {},
): ProviderExecutionRequest {
  return {
    configuration: {
      model: 'pi:anthropic/claude-sonnet-4',
      reasoning: 'high',
      systemInstructions: { kind: 'provider-default' },
    },
    input: [{ text: 'Hello Pi', type: 'text' }],
    signal: new AbortController().signal,
    toolPolicy: { kind: 'provider-default' },
    ...overrides,
  };
}

async function collect(
  events: AsyncIterable<ProviderExecutionEvent>,
): Promise<ProviderExecutionEvent[]> {
  const collected: ProviderExecutionEvent[] = [];
  for await (const event of events) {
    collected.push(event);
  }
  return collected;
}

async function flush(): Promise<void> {
  await new Promise(resolve => setImmediate(resolve));
}

function createDeferred(): {
  promise: Promise<undefined>;
  resolve: () => void;
} {
  let resolve!: () => void;
  const promise = new Promise<undefined>((settle) => {
    resolve = () => settle(undefined);
  });
  return { promise, resolve };
}

function createRejectableDeferred<T>(): {
  promise: Promise<T>;
  reject: (error: Error) => void;
  resolve: (value: T) => void;
} {
  let reject!: (error: Error) => void;
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((settle, fail) => {
    reject = fail;
    resolve = settle;
  });
  return { promise, reject, resolve };
}

async function waitFor(predicate: () => boolean, timeoutMs = 2_000): Promise<void> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (predicate()) return;
    await new Promise(resolve => setTimeout(resolve, 5));
  }
  throw new Error('Timed out waiting for Pi execution test condition');
}

function createConversationHistory(prefix: string) {
  return [
    { id: `${prefix}-user`, role: 'user' as const, content: `${prefix} question`, timestamp: 1 },
    { id: `${prefix}-assistant`, role: 'assistant' as const, content: `${prefix} answer`, timestamp: 2 },
  ];
}

function completeTurn(kernel: FakeKernel): void {
  kernel.emit({ type: 'agent_start' });
  kernel.emit({ type: 'agent_end' });
  kernel.emit({ type: 'agent_settled' });
}

function getPromptMessages(kernel: FakeKernel): string[] {
  return kernel.requests
    .filter(({ type }) => type === 'prompt')
    .map(({ payload }) => String(payload.message));
}

function createHarness(
  config = createConfig(),
  onKernelCreated?: (kernel: FakeKernel, index: number) => void,
  requestHandler?: <T>(
    type: string,
    payload: Record<string, unknown>,
    timeoutMs?: number,
    signal?: AbortSignal,
  ) => Promise<T>,
  forkLifecycleOptions: Record<string, unknown> = {},
) {
  const host = createHost();
  const kernels: FakeKernel[] = [];
  const responses = new Map<string, unknown>([
    ['get_commands', {
      commands: [{ description: 'Compact context', name: 'compact', source: 'runtime' }],
    }],
    ['get_session_stats', {
      contextWindow: 200_000,
      inputTokens: 10,
      outputTokens: 5,
    }],
    ['get_state', {
      leafEntryId: 'assistant-1',
      parentSession: 'parent-session',
      sessionFile: '/tmp/pi-session.jsonl',
      sessionId: 'pi-session-1',
    }],
    ['prompt', { disposition: 'started' }],
    ['set_model', {}],
    ['set_thinking_level', {}],
    ['steer', { disposition: 'queued' }],
  ]);
  const commandCatalog = {
    getDropdownConfig: jest.fn(),
    listDropdownEntries: jest.fn(async () => []),
    refresh: jest.fn(async () => undefined),
    setCommandSnapshot: jest.fn(),
  };
  const backend = new PiExecutionBackend(
    host,
    { commandCatalog },
    {
      createKernel: (spec, callbacks) => {
        const kernel = new FakeKernel(spec, callbacks, responses, requestHandler);
        kernels.push(kernel);
        onKernelCreated?.(kernel, kernels.length - 1);
        return kernel;
      },
      ...forkLifecycleOptions,
    },
  );
  return {
    backend,
    commandCatalog,
    config,
    host,
    kernels,
    responses,
    session: backend.createSession(config),
  };
}

describe('PiExecutionBackend', () => {
  it.each([
    ['/compact', ''],
    [' \t/CoMpAcT keep recent edits\nFocus on tests  ', 'keep recent edits\nFocus on tests'],
  ])('compacts with only explicit instructions from %j', async (text, instructions) => {
    const { session, kernels, responses } = createHarness();
    responses.set('prompt', { disposition: 'handled' });
    try {
      const events = await collect(session.execute(createRequest({
        input: [{ type: 'text', text }, { type: 'image', image: {
          id: 'capture', name: 'capture.png', data: 'aW1hZ2U=',
          mediaType: 'image/png', size: 5, source: 'paste',
        } }],
        context: { ...capturedSelections, linkedContent: { path: 'note.md' },
          sessionReferences: [{ id: 'ref', title: 'Review', providerId: 'pi', updatedAt: 'updated', snapshotPath: '/tmp/ref.md' }],
        },
      })).events);
      expect(kernels[0].requests.filter(request => request.type === 'compact' || request.type === 'prompt'))
        .toEqual([{ type: 'compact', payload: { customInstructions: instructions } }]);
      expect(events.filter(event => event.type === 'context_compacted')).toHaveLength(1);
      expect(events.at(-1)?.type).toBe('turn_completed');
    } finally { await session.dispose(); }
  });

  it('rejects compact without consuming history that still needs recovery', async () => {
    const { session, kernels, responses } = createHarness();
    responses.set('prompt', { disposition: 'handled' });
    const conversationHistory = [{ id: 'prior', role: 'user' as const, content: 'Remember prior context', timestamp: testDate().getTime() }];
    try {
      const events = await collect(session.execute(createRequest({
        input: [{ type: 'text', text: '/compact' }], conversationHistory,
      })).events);
      // A user-facing error must surface (contract); its wording is the solver's choice.
      expect(events.at(-1)).toMatchObject({ type: 'execution_error', message: expect.any(String) });
      expect(kernels.flatMap(kernel => kernel.requests).filter(request => request.type === 'compact' || request.type === 'prompt')).toEqual([]);
      await collect(session.execute(createRequest({ conversationHistory })).events);
      expect(getPromptMessages(kernels[0])[0]).toContain('Remember prior context');
      expect(getPromptMessages(kernels[0])[0]).toContain('Hello Pi');
    } finally { await session.dispose(); }
  });

});
